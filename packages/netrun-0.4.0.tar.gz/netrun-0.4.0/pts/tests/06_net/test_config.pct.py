# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---

# %% [markdown]
# # Tests for Net Config Module

# %%
#|default_exp net.test_config

# %%
#|export
import pytest
import tempfile
import json
import os
from pathlib import Path
from netrun.net.config import (
    # Port slot spec
    PortSlotSpecInfiniteConfig,
    PortSlotSpecFiniteConfig,
    PortConfig,
    # Port state
    PortStateEmptyConfig,
    PortStateFullConfig,
    PortStateNonEmptyConfig,
    PortStateNonFullConfig,
    PortStateEqualsConfig,
    PortStateLessThanConfig,
    PortStateGreaterThanConfig,
    PortStateEqualsOrLessThanConfig,
    PortStateEqualsOrGreaterThanConfig,
    # Packet count
    PacketCountAllConfig,
    PacketCountNConfig,
    # Max salvos
    MaxSalvosInfiniteConfig,
    MaxSalvosFiniteConfig,
    # Salvo condition term
    SalvoConditionTermTrueConfig,
    SalvoConditionTermFalseConfig,
    SalvoConditionTermPortConfig,
    SalvoConditionTermAndConfig,
    SalvoConditionTermOrConfig,
    SalvoConditionTermNotConfig,
    # Salvo condition
    SalvoConditionConfig,
    # Edge and node
    PortRefConfig,
    EdgeConfig,
    NodeConfig,
    # Graph
    GraphConfig,
    # Net
    NetConfig,
    # Pools
    PoolConfig,
    MainPoolConfig,
    ThreadPoolConfig,
    # Node variables
    NodeVariable,
    NodeExecutionConfig,
    # Subgraph
    ExposedPortConfig,
    SubgraphConfig,
    # Output queues
    OutputQueueConfig,
)
import netrun_sim

# %% [markdown]
# ## Port Slot Spec Tests

# %%
#|export
def test_port_slot_spec_infinite_config():
    """Test PortSlotSpecInfiniteConfig creation and conversion."""
    config = PortSlotSpecInfiniteConfig()
    assert config.type == "infinite"

    # Test conversion to netrun_sim
    result = config.to_netrun_sim()
    assert result == netrun_sim.PortSlotSpec.Infinite

# %%
test_port_slot_spec_infinite_config();

# %%
#|export
def test_port_slot_spec_finite_config():
    """Test PortSlotSpecFiniteConfig creation and conversion."""
    config = PortSlotSpecFiniteConfig(capacity=5)
    assert config.type == "finite"
    assert config.capacity == 5

    # Test conversion to netrun_sim
    result = config.to_netrun_sim()
    assert result.capacity == 5

# %%
test_port_slot_spec_finite_config();

# %%
#|export
def test_port_config_default():
    """Test PortConfig with default (infinite) slot spec."""
    config = PortConfig()
    assert config.slots_spec.type == "infinite"

    port = config.to_netrun_sim()
    assert port.slots_spec == netrun_sim.PortSlotSpec.Infinite

# %%
test_port_config_default();

# %%
#|export
def test_port_config_finite():
    """Test PortConfig with finite slot spec."""
    config = PortConfig(slots_spec=PortSlotSpecFiniteConfig(capacity=10))
    assert config.slots_spec.type == "finite"
    assert config.slots_spec.capacity == 10

    port = config.to_netrun_sim()
    assert port.slots_spec.capacity == 10

# %%
test_port_config_finite();

# %% [markdown]
# ## Port State Tests

# %%
#|export
def test_port_state_empty_config():
    """Test PortStateEmptyConfig."""
    config = PortStateEmptyConfig()
    assert config.type == "empty"
    result = config.to_netrun_sim()
    assert result == netrun_sim.PortState.Empty

# %%
test_port_state_empty_config();

# %%
#|export
def test_port_state_full_config():
    """Test PortStateFullConfig."""
    config = PortStateFullConfig()
    assert config.type == "full"
    result = config.to_netrun_sim()
    assert result == netrun_sim.PortState.Full

# %%
test_port_state_full_config();

# %%
#|export
def test_port_state_non_empty_config():
    """Test PortStateNonEmptyConfig."""
    config = PortStateNonEmptyConfig()
    assert config.type == "non_empty"
    result = config.to_netrun_sim()
    assert result == netrun_sim.PortState.NonEmpty

# %%
test_port_state_non_empty_config();

# %%
#|export
def test_port_state_non_full_config():
    """Test PortStateNonFullConfig."""
    config = PortStateNonFullConfig()
    assert config.type == "non_full"
    result = config.to_netrun_sim()
    assert result == netrun_sim.PortState.NonFull

# %%
test_port_state_non_full_config();

# %%
#|export
def test_port_state_equals_config():
    """Test PortStateEqualsConfig."""
    config = PortStateEqualsConfig(value=3)
    assert config.type == "equals"
    assert config.value == 3
    result = config.to_netrun_sim()
    assert result.kind == "equals"
    assert result.value == 3

# %%
test_port_state_equals_config();

# %%
#|export
def test_port_state_less_than_config():
    """Test PortStateLessThanConfig."""
    config = PortStateLessThanConfig(value=5)
    assert config.type == "less_than"
    assert config.value == 5
    result = config.to_netrun_sim()
    assert result.kind == "less_than"
    assert result.value == 5

# %%
test_port_state_less_than_config();

# %%
#|export
def test_port_state_greater_than_config():
    """Test PortStateGreaterThanConfig."""
    config = PortStateGreaterThanConfig(value=2)
    assert config.type == "greater_than"
    assert config.value == 2
    result = config.to_netrun_sim()
    assert result.kind == "greater_than"
    assert result.value == 2

# %%
test_port_state_greater_than_config();

# %%
#|export
def test_port_state_equals_or_less_than_config():
    """Test PortStateEqualsOrLessThanConfig."""
    config = PortStateEqualsOrLessThanConfig(value=4)
    assert config.type == "equals_or_less_than"
    assert config.value == 4
    result = config.to_netrun_sim()
    assert result.kind == "equals_or_less_than"
    assert result.value == 4

# %%
test_port_state_equals_or_less_than_config();

# %%
#|export
def test_port_state_equals_or_greater_than_config():
    """Test PortStateEqualsOrGreaterThanConfig."""
    config = PortStateEqualsOrGreaterThanConfig(value=1)
    assert config.type == "equals_or_greater_than"
    assert config.value == 1
    result = config.to_netrun_sim()
    assert result.kind == "equals_or_greater_than"
    assert result.value == 1

# %%
test_port_state_equals_or_greater_than_config();

# %% [markdown]
# ## Packet Count Tests

# %%
#|export
def test_packet_count_all_config():
    """Test PacketCountAllConfig."""
    config = PacketCountAllConfig()
    assert config.type == "all"
    result = config.to_netrun_sim()
    assert result == netrun_sim.PacketCount.All

# %%
test_packet_count_all_config();

# %%
#|export
def test_packet_count_n_config():
    """Test PacketCountNConfig."""
    config = PacketCountNConfig(count=5)
    assert config.type == "count"
    assert config.count == 5
    result = config.to_netrun_sim()
    assert result.count == 5

# %%
test_packet_count_n_config();

# %% [markdown]
# ## Max Salvos Tests

# %%
#|export
def test_max_salvos_infinite_config():
    """Test MaxSalvosInfiniteConfig."""
    config = MaxSalvosInfiniteConfig()
    assert config.type == "infinite"
    result = config.to_netrun_sim()
    assert result == netrun_sim.MaxSalvos.Infinite

# %%
test_max_salvos_infinite_config();

# %%
#|export
def test_max_salvos_finite_config():
    """Test MaxSalvosFiniteConfig."""
    config = MaxSalvosFiniteConfig(max=3)
    assert config.type == "finite"
    assert config.max == 3
    result = config.to_netrun_sim()
    assert result.max == 3

# %%
test_max_salvos_finite_config();

# %% [markdown]
# ## Salvo Condition Term Tests

# %%
#|export
def test_salvo_condition_term_true_config():
    """Test SalvoConditionTermTrueConfig."""
    config = SalvoConditionTermTrueConfig()
    assert config.type == "true"
    result = config.to_netrun_sim()
    assert result.kind == "True"

# %%
test_salvo_condition_term_true_config();

# %%
#|export
def test_salvo_condition_term_false_config():
    """Test SalvoConditionTermFalseConfig."""
    config = SalvoConditionTermFalseConfig()
    assert config.type == "false"
    result = config.to_netrun_sim()
    assert result.kind == "False"

# %%
test_salvo_condition_term_false_config();

# %%
#|export
def test_salvo_condition_term_port_config():
    """Test SalvoConditionTermPortConfig."""
    config = SalvoConditionTermPortConfig(
        port_name="in",
        state=PortStateNonEmptyConfig()
    )
    assert config.type == "port"
    assert config.port_name == "in"
    assert config.state.type == "non_empty"

    result = config.to_netrun_sim()
    assert result.kind == "Port"
    assert result.get_port_name() == "in"

# %%
test_salvo_condition_term_port_config();

# %%
#|export
def test_salvo_condition_term_and_config():
    """Test SalvoConditionTermAndConfig."""
    config = SalvoConditionTermAndConfig(
        terms=[
            SalvoConditionTermPortConfig(port_name="in1", state=PortStateNonEmptyConfig()),
            SalvoConditionTermPortConfig(port_name="in2", state=PortStateNonEmptyConfig()),
        ]
    )
    assert config.type == "and"
    assert len(config.terms) == 2

    result = config.to_netrun_sim()
    assert result.kind == "And"
    terms = result.get_terms()
    assert len(terms) == 2

# %%
test_salvo_condition_term_and_config();

# %%
#|export
def test_salvo_condition_term_or_config():
    """Test SalvoConditionTermOrConfig."""
    config = SalvoConditionTermOrConfig(
        terms=[
            SalvoConditionTermPortConfig(port_name="in1", state=PortStateNonEmptyConfig()),
            SalvoConditionTermPortConfig(port_name="in2", state=PortStateNonEmptyConfig()),
        ]
    )
    assert config.type == "or"
    assert len(config.terms) == 2

    result = config.to_netrun_sim()
    assert result.kind == "Or"
    terms = result.get_terms()
    assert len(terms) == 2

# %%
test_salvo_condition_term_or_config();

# %%
#|export
def test_salvo_condition_term_not_config():
    """Test SalvoConditionTermNotConfig."""
    config = SalvoConditionTermNotConfig(
        term=SalvoConditionTermPortConfig(port_name="in", state=PortStateEmptyConfig())
    )
    assert config.type == "not"

    result = config.to_netrun_sim()
    assert result.kind == "Not"
    inner = result.get_inner()
    assert inner.kind == "Port"

# %%
test_salvo_condition_term_not_config();

# %%
#|export
def test_salvo_condition_term_nested():
    """Test nested salvo condition terms."""
    config = SalvoConditionTermAndConfig(
        terms=[
            SalvoConditionTermOrConfig(
                terms=[
                    SalvoConditionTermPortConfig(port_name="a", state=PortStateNonEmptyConfig()),
                    SalvoConditionTermPortConfig(port_name="b", state=PortStateNonEmptyConfig()),
                ]
            ),
            SalvoConditionTermNotConfig(
                term=SalvoConditionTermPortConfig(port_name="c", state=PortStateFullConfig())
            ),
        ]
    )
    assert config.type == "and"
    assert config.terms[0].type == "or"
    assert config.terms[1].type == "not"

    result = config.to_netrun_sim()
    assert result.kind == "And"

# %%
test_salvo_condition_term_nested();

# %% [markdown]
# ## Salvo Condition Tests

# %%
#|export
def test_salvo_condition_config():
    """Test SalvoConditionConfig."""
    config = SalvoConditionConfig(
        max_salvos=MaxSalvosFiniteConfig(max=1),
        ports={"in": PacketCountAllConfig()},
        term=SalvoConditionTermPortConfig(port_name="in", state=PortStateNonEmptyConfig()),
    )
    assert config.max_salvos.type == "finite"
    assert "in" in config.ports
    assert config.term.type == "port"

    result = config.to_netrun_sim()
    assert result.max_salvos.max == 1
    assert "in" in result.ports

# %%
test_salvo_condition_config();

# %%
#|export
def test_salvo_condition_config_multiple_ports():
    """Test SalvoConditionConfig with multiple ports."""
    config = SalvoConditionConfig(
        max_salvos=MaxSalvosFiniteConfig(max=1),
        ports={
            "in1": PacketCountAllConfig(),
            "in2": PacketCountNConfig(count=2),
        },
        term=SalvoConditionTermAndConfig(
            terms=[
                SalvoConditionTermPortConfig(port_name="in1", state=PortStateNonEmptyConfig()),
                SalvoConditionTermPortConfig(port_name="in2", state=PortStateEqualsOrGreaterThanConfig(value=2)),
            ]
        ),
    )
    assert len(config.ports) == 2

    result = config.to_netrun_sim()
    assert len(result.ports) == 2

# %%
test_salvo_condition_config_multiple_ports();

# %% [markdown]
# ## Port Ref and Edge Tests

# %%
#|export
def test_port_ref_config():
    """Test PortRefConfig."""
    config = PortRefConfig(node_name="A", port_type="output", port_name="out")
    assert config.node_name == "A"
    assert config.port_type == "output"
    assert config.port_name == "out"

    result = config.to_netrun_sim()
    assert result.node_name == "A"
    assert result.port_type == netrun_sim.PortType.Output
    assert result.port_name == "out"

# %%
test_port_ref_config();

# %%
#|export
def test_port_ref_config_input():
    """Test PortRefConfig for input port."""
    config = PortRefConfig(node_name="B", port_type="input", port_name="in")
    result = config.to_netrun_sim()
    assert result.port_type == netrun_sim.PortType.Input

# %%
test_port_ref_config_input();

# %%
#|export
def test_edge_config_full_form():
    """Test EdgeConfig with full PortRefConfig objects."""
    config = EdgeConfig(
        source=PortRefConfig(node_name="A", port_type="output", port_name="out"),
        target=PortRefConfig(node_name="B", port_type="input", port_name="in"),
    )
    source = config.get_source()
    target = config.get_target()
    assert source.node_name == "A"
    assert target.node_name == "B"

    result = config.to_netrun_sim()
    assert result.source.node_name == "A"
    assert result.target.node_name == "B"

# %%
test_edge_config_full_form();

# %%
#|export
def test_edge_config_shorthand():
    """Test EdgeConfig with shorthand string notation."""
    config = EdgeConfig(source_str="A.out", target_str="B.in")
    source = config.get_source()
    target = config.get_target()
    assert source.node_name == "A"
    assert source.port_name == "out"
    assert source.port_type == "output"
    assert target.node_name == "B"
    assert target.port_name == "in"
    assert target.port_type == "input"

    result = config.to_netrun_sim()
    assert result.source.node_name == "A"
    assert result.target.node_name == "B"

# %%
test_edge_config_shorthand();

# %%
#|export
def test_edge_config_validation_neither():
    """Test EdgeConfig raises error when neither form provided."""
    with pytest.raises(ValueError, match="Must provide either"):
        EdgeConfig()

# %%
test_edge_config_validation_neither();

# %%
#|export
def test_edge_config_validation_both():
    """Test EdgeConfig raises error when both forms provided."""
    with pytest.raises(ValueError, match="Cannot provide both"):
        EdgeConfig(
            source=PortRefConfig(node_name="A", port_type="output", port_name="out"),
            target=PortRefConfig(node_name="B", port_type="input", port_name="in"),
            source_str="A.out",
            target_str="B.in",
        )

# %%
test_edge_config_validation_both();

# %%
#|export
def test_edge_config_invalid_shorthand():
    """Test EdgeConfig raises error for invalid shorthand format."""
    config = EdgeConfig(source_str="invalid", target_str="B.in")
    with pytest.raises(ValueError, match="Invalid port string"):
        config.get_source()

# %%
test_edge_config_invalid_shorthand();

# %% [markdown]
# ## Node Graph Config Tests

# %%
#|export
def test_node_graph_config_minimal():
    """Test NodeConfig with minimal configuration."""
    config = NodeConfig(name="A")
    assert config.name == "A"
    assert config.in_ports == {}
    assert config.out_ports == {}
    # None means "generate defaults on resolve()"
    assert config.in_salvo_conditions is None
    assert config.out_salvo_conditions is None

    # to_netrun_sim() handles None gracefully (treats as empty)
    result = config.to_netrun_sim()
    assert result.name == "A"

# %%
test_node_graph_config_minimal();

# %%
#|export
def test_node_graph_config_with_ports():
    """Test NodeConfig with ports."""
    config = NodeConfig(
        name="B",
        in_ports={"in1": PortConfig(), "in2": PortConfig(slots_spec=PortSlotSpecFiniteConfig(capacity=5))},
        out_ports={"out": PortConfig()},
    )
    assert len(config.in_ports) == 2
    assert len(config.out_ports) == 1

    result = config.to_netrun_sim()
    assert len(result.in_ports) == 2
    assert len(result.out_ports) == 1

# %%
test_node_graph_config_with_ports();

# %%
#|export
def test_node_graph_config_with_salvo_conditions():
    """Test NodeConfig with salvo conditions."""
    config = NodeConfig(
        name="C",
        in_ports={"in": PortConfig()},
        out_ports={"out": PortConfig()},
        in_salvo_conditions={
            "default": SalvoConditionConfig(
                max_salvos=MaxSalvosFiniteConfig(max=1),
                ports={"in": PacketCountAllConfig()},
                term=SalvoConditionTermPortConfig(port_name="in", state=PortStateNonEmptyConfig()),
            ),
        },
        out_salvo_conditions={
            "send": SalvoConditionConfig(
                max_salvos=MaxSalvosInfiniteConfig(),
                ports={"out": PacketCountAllConfig()},
                term=SalvoConditionTermPortConfig(port_name="out", state=PortStateNonEmptyConfig()),
            ),
        },
    )
    assert len(config.in_salvo_conditions) == 1
    assert len(config.out_salvo_conditions) == 1

    result = config.to_netrun_sim()
    assert len(result.in_salvo_conditions) == 1
    assert len(result.out_salvo_conditions) == 1

# %%
test_node_graph_config_with_salvo_conditions();

# %%
#|export
def test_node_config_resolve_generates_default_salvo_conditions():
    """Test that resolve() generates default salvo conditions when None."""
    # Test with input ports
    config = NodeConfig(
        name="TestNode",
        in_ports={"a": PortConfig(), "b": PortConfig()},
        out_ports={"out": PortConfig()},
        # in_salvo_conditions and out_salvo_conditions default to None
    )
    assert config.in_salvo_conditions is None
    assert config.out_salvo_conditions is None

    resolved = config.resolve()

    # Should have generated "default" salvo condition
    assert "default" in resolved.in_salvo_conditions
    assert "default" in resolved.out_salvo_conditions

    # Input condition should include both ports
    in_cond = resolved.in_salvo_conditions["default"]
    assert "a" in in_cond.ports
    assert "b" in in_cond.ports

    # Output condition should include the output port
    out_cond = resolved.out_salvo_conditions["default"]
    assert "out" in out_cond.ports

# %%
test_node_config_resolve_generates_default_salvo_conditions();

# %%
#|export
def test_node_config_resolve_preserves_empty_dict():
    """Test that resolve() preserves explicit empty dict (no conditions)."""
    config = NodeConfig(
        name="TestNode",
        in_ports={"a": PortConfig()},
        in_salvo_conditions={},  # Explicit empty - means "no conditions"
        out_salvo_conditions={},  # Explicit empty
    )

    resolved = config.resolve()

    # Empty dict should be preserved, not auto-generated
    assert resolved.in_salvo_conditions == {}
    assert resolved.out_salvo_conditions == {}

# %%
test_node_config_resolve_preserves_empty_dict();

# %%
#|export
def test_node_config_resolve_preserves_explicit_conditions():
    """Test that resolve() preserves explicitly provided salvo conditions."""
    custom_condition = SalvoConditionConfig(
        max_salvos=MaxSalvosFiniteConfig(max=1),
        ports={"a": PacketCountAllConfig()},
        term=SalvoConditionTermTrueConfig(),
    )
    config = NodeConfig(
        name="TestNode",
        in_ports={"a": PortConfig()},
        in_salvo_conditions={"custom": custom_condition},
    )

    resolved = config.resolve()

    # Custom condition should be preserved
    assert "custom" in resolved.in_salvo_conditions
    assert "default" not in resolved.in_salvo_conditions

    # out_salvo_conditions was None, should get default
    assert resolved.out_salvo_conditions == {}  # No output ports

# %%
test_node_config_resolve_preserves_explicit_conditions();

# %%
#|export
def test_node_config_resolve_no_input_ports():
    """Test default salvo condition for node with no input ports."""
    config = NodeConfig(
        name="SourceNode",
        out_ports={"out": PortConfig()},
    )

    resolved = config.resolve()

    # Should have "always true" input condition
    assert "default" in resolved.in_salvo_conditions
    in_cond = resolved.in_salvo_conditions["default"]
    assert in_cond.ports == {}
    assert isinstance(in_cond.term, SalvoConditionTermTrueConfig)

    # Should have output condition
    assert "default" in resolved.out_salvo_conditions

# %%
test_node_config_resolve_no_input_ports();

# %%
#|export
def test_node_config_resolve_no_output_ports():
    """Test default salvo condition for node with no output ports."""
    config = NodeConfig(
        name="SinkNode",
        in_ports={"in": PortConfig()},
    )

    resolved = config.resolve()

    # Should have input condition
    assert "default" in resolved.in_salvo_conditions

    # Should have empty output conditions (no output ports)
    assert resolved.out_salvo_conditions == {}

# %%
test_node_config_resolve_no_output_ports();

# %% [markdown]
# ## Graph Config Tests

# %%
#|export
def test_graph_config_simple():
    """Test GraphConfig with simple A -> B graph."""
    config = GraphConfig(
        nodes=[
            NodeConfig(name="A", out_ports={"out": PortConfig()}),
            NodeConfig(
                name="B",
                in_ports={"in": PortConfig()},
                in_salvo_conditions={
                    "default": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"in": PacketCountAllConfig()},
                        term=SalvoConditionTermPortConfig(port_name="in", state=PortStateNonEmptyConfig()),
                    ),
                },
            ),
        ],
        edges=[EdgeConfig(source_str="A.out", target_str="B.in")],
    )
    assert len(config.nodes) == 2
    assert len(config.edges) == 1

    graph = config.get_graph()
    assert len(graph.nodes()) == 2
    assert len(graph.edges()) == 1
    assert len(graph.validate()) == 0

# %%
test_graph_config_simple();

# %%
#|export
def test_graph_config_no_edges():
    """Test GraphConfig with no edges (disconnected nodes)."""
    config = GraphConfig(
        nodes=[
            NodeConfig(name="A", out_ports={"out": PortConfig()}),
            NodeConfig(name="B", in_ports={"in": PortConfig()}),
        ],
        edges=[],
    )
    graph = config.get_graph()
    assert len(graph.nodes()) == 2
    assert len(graph.edges()) == 0

# %%
test_graph_config_no_edges();

# %%
#|export
def test_graph_config_complex():
    """Test GraphConfig with multiple nodes and edges."""
    config = GraphConfig(
        nodes=[
            NodeConfig(name="Source", out_ports={"out": PortConfig()}),
            NodeConfig(
                name="Processor",
                in_ports={"in1": PortConfig(), "in2": PortConfig()},
                out_ports={"out": PortConfig()},
                in_salvo_conditions={
                    "both_ready": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"in1": PacketCountAllConfig(), "in2": PacketCountAllConfig()},
                        term=SalvoConditionTermAndConfig(
                            terms=[
                                SalvoConditionTermPortConfig(port_name="in1", state=PortStateNonEmptyConfig()),
                                SalvoConditionTermPortConfig(port_name="in2", state=PortStateNonEmptyConfig()),
                            ]
                        ),
                    ),
                },
            ),
            NodeConfig(
                name="Sink",
                in_ports={"in": PortConfig()},
                in_salvo_conditions={
                    "default": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"in": PacketCountAllConfig()},
                        term=SalvoConditionTermPortConfig(port_name="in", state=PortStateNonEmptyConfig()),
                    ),
                },
            ),
        ],
        edges=[
            EdgeConfig(source_str="Source.out", target_str="Processor.in1"),
            EdgeConfig(source_str="Processor.out", target_str="Sink.in"),
        ],
    )

    graph = config.get_graph()
    assert len(graph.nodes()) == 3
    assert len(graph.edges()) == 2
    assert len(graph.validate()) == 0

# %%
test_graph_config_complex();

# %%
#|export
def test_graph_config_validates_correctly():
    """Test that GraphConfig produces graphs that validate correctly."""
    # This config has a valid graph
    valid_config = GraphConfig(
        nodes=[
            NodeConfig(name="A", out_ports={"out": PortConfig()}),
            NodeConfig(name="B", in_ports={"in": PortConfig()}),
        ],
        edges=[EdgeConfig(source_str="A.out", target_str="B.in")],
    )
    assert len(valid_config.get_graph().validate()) == 0

# %%
test_graph_config_validates_correctly();

# %% [markdown]
# ## JSON Serialization Tests

# %%
#|export
def test_port_slot_spec_json_roundtrip():
    """Test PortSlotSpec configs JSON roundtrip."""
    configs = [
        PortSlotSpecInfiniteConfig(),
        PortSlotSpecFiniteConfig(capacity=10),
    ]
    for config in configs:
        json_str = config.model_dump_json()
        loaded = type(config).model_validate_json(json_str)
        assert loaded == config

# %%
test_port_slot_spec_json_roundtrip();

# %%
#|export
def test_port_state_json_roundtrip():
    """Test PortState configs JSON roundtrip."""
    configs = [
        PortStateEmptyConfig(),
        PortStateFullConfig(),
        PortStateNonEmptyConfig(),
        PortStateNonFullConfig(),
        PortStateEqualsConfig(value=5),
        PortStateLessThanConfig(value=3),
        PortStateGreaterThanConfig(value=2),
        PortStateEqualsOrLessThanConfig(value=4),
        PortStateEqualsOrGreaterThanConfig(value=1),
    ]
    for config in configs:
        json_str = config.model_dump_json()
        loaded = type(config).model_validate_json(json_str)
        assert loaded == config

# %%
test_port_state_json_roundtrip();

# %%
#|export
def test_packet_count_json_roundtrip():
    """Test PacketCount configs JSON roundtrip."""
    configs = [
        PacketCountAllConfig(),
        PacketCountNConfig(count=5),
    ]
    for config in configs:
        json_str = config.model_dump_json()
        loaded = type(config).model_validate_json(json_str)
        assert loaded == config

# %%
test_packet_count_json_roundtrip();

# %%
#|export
def test_max_salvos_json_roundtrip():
    """Test MaxSalvos configs JSON roundtrip."""
    configs = [
        MaxSalvosInfiniteConfig(),
        MaxSalvosFiniteConfig(max=3),
    ]
    for config in configs:
        json_str = config.model_dump_json()
        loaded = type(config).model_validate_json(json_str)
        assert loaded == config

# %%
test_max_salvos_json_roundtrip();

# %%
#|export
def test_salvo_condition_term_json_roundtrip():
    """Test SalvoConditionTerm configs JSON roundtrip."""
    configs = [
        SalvoConditionTermTrueConfig(),
        SalvoConditionTermFalseConfig(),
        SalvoConditionTermPortConfig(port_name="in", state=PortStateNonEmptyConfig()),
        SalvoConditionTermAndConfig(
            terms=[
                SalvoConditionTermPortConfig(port_name="a", state=PortStateNonEmptyConfig()),
                SalvoConditionTermPortConfig(port_name="b", state=PortStateNonEmptyConfig()),
            ]
        ),
        SalvoConditionTermOrConfig(
            terms=[
                SalvoConditionTermPortConfig(port_name="a", state=PortStateNonEmptyConfig()),
                SalvoConditionTermPortConfig(port_name="b", state=PortStateNonEmptyConfig()),
            ]
        ),
        SalvoConditionTermNotConfig(
            term=SalvoConditionTermPortConfig(port_name="in", state=PortStateEmptyConfig())
        ),
    ]
    for config in configs:
        json_str = config.model_dump_json()
        loaded = type(config).model_validate_json(json_str)
        assert loaded == config

# %%
test_salvo_condition_term_json_roundtrip();

# %%
#|export
def test_graph_config_json_roundtrip():
    """Test GraphConfig complete JSON roundtrip."""
    config = GraphConfig(
        nodes=[
            NodeConfig(name="A", out_ports={"out": PortConfig()}),
            NodeConfig(
                name="B",
                in_ports={"in": PortConfig(slots_spec=PortSlotSpecFiniteConfig(capacity=5))},
                in_salvo_conditions={
                    "default": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"in": PacketCountAllConfig()},
                        term=SalvoConditionTermPortConfig(port_name="in", state=PortStateNonEmptyConfig()),
                    ),
                },
            ),
        ],
        edges=[EdgeConfig(source_str="A.out", target_str="B.in")],
    )

    json_str = config.model_dump_json()
    loaded = GraphConfig.model_validate_json(json_str)

    # Verify structure matches
    assert len(loaded.nodes) == len(config.nodes)
    assert len(loaded.edges) == len(config.edges)

    # Verify the loaded config produces a valid graph
    graph = loaded.get_graph()
    assert len(graph.validate()) == 0

# %%
test_graph_config_json_roundtrip();

# %%
#|export
def test_graph_config_json_roundtrip_complex():
    """Test GraphConfig JSON roundtrip with complex nested terms."""
    config = GraphConfig(
        nodes=[
            NodeConfig(name="Source", out_ports={"out": PortConfig()}),
            NodeConfig(
                name="Processor",
                in_ports={"in1": PortConfig(), "in2": PortConfig()},
                out_ports={"out": PortConfig()},
                in_salvo_conditions={
                    "complex": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"in1": PacketCountAllConfig(), "in2": PacketCountNConfig(count=2)},
                        term=SalvoConditionTermAndConfig(
                            terms=[
                                SalvoConditionTermOrConfig(
                                    terms=[
                                        SalvoConditionTermPortConfig(port_name="in1", state=PortStateNonEmptyConfig()),
                                        SalvoConditionTermPortConfig(port_name="in1", state=PortStateFullConfig()),
                                    ]
                                ),
                                SalvoConditionTermNotConfig(
                                    term=SalvoConditionTermPortConfig(port_name="in2", state=PortStateEmptyConfig())
                                ),
                            ]
                        ),
                    ),
                },
                out_salvo_conditions={
                    "send": SalvoConditionConfig(
                        max_salvos=MaxSalvosInfiniteConfig(),
                        ports={"out": PacketCountAllConfig()},
                        term=SalvoConditionTermPortConfig(port_name="out", state=PortStateNonEmptyConfig()),
                    ),
                },
            ),
        ],
        edges=[EdgeConfig(source_str="Source.out", target_str="Processor.in1")],
    )

    json_str = config.model_dump_json(indent=2)
    loaded = GraphConfig.model_validate_json(json_str)

    # Verify structure matches
    assert len(loaded.nodes) == len(config.nodes)

    # Verify the nested term structure
    processor = next(n for n in loaded.nodes if n.name == "Processor")
    complex_cond = processor.in_salvo_conditions["complex"]
    assert complex_cond.term.type == "and"
    assert len(complex_cond.term.terms) == 2
    assert complex_cond.term.terms[0].type == "or"
    assert complex_cond.term.terms[1].type == "not"

# %%
test_graph_config_json_roundtrip_complex();

# %% [markdown]
# ## Integration Tests

# %%
#|export
def test_config_to_netrun_sim_integration():
    """Test that configs properly integrate with netrun_sim."""
    config = GraphConfig(
        nodes=[
            NodeConfig(name="A", out_ports={"out": PortConfig()}),
            NodeConfig(
                name="B",
                in_ports={"in": PortConfig()},
                in_salvo_conditions={
                    "default": SalvoConditionConfig(
                        max_salvos=MaxSalvosFiniteConfig(max=1),
                        ports={"in": PacketCountAllConfig()},
                        term=SalvoConditionTermPortConfig(port_name="in", state=PortStateNonEmptyConfig()),
                    ),
                },
            ),
        ],
        edges=[EdgeConfig(source_str="A.out", target_str="B.in")],
    )

    graph = config.get_graph()

    # Create a NetSim and verify it works
    net = netrun_sim.NetSim(graph)

    # Create a packet
    response, events = net.do_action(netrun_sim.NetAction.create_packet())
    packet_id = response.packet_id

    # Place it on the edge
    edge = graph.edges()[0]
    net.do_action(netrun_sim.NetAction.transport_packet_to_location(
        packet_id,
        netrun_sim.PacketLocation.edge(edge)
    ))

    # Run the network
    net.do_action(netrun_sim.NetAction.run_step())

    # Check that an epoch was created
    startable = net.get_startable_epochs()
    assert len(startable) == 1

# %%
test_config_to_netrun_sim_integration();

# %% [markdown]
# ## Subgraph Tests

# %%
#|export
def test_exposed_port_config():
    """Test ExposedPortConfig creation."""
    config = ExposedPortConfig(
        internal_node="Processor",
        internal_port="input",
        rename="in",
    )
    assert config.internal_node == "Processor"
    assert config.internal_port == "input"
    assert config.rename == "in"
    assert config.get_exposed_name() == "in"

    # Without rename, should use internal_port
    config2 = ExposedPortConfig(
        internal_node="Processor",
        internal_port="input",
    )
    assert config2.get_exposed_name() == "input"

# %%
test_exposed_port_config();

# %%
#|export
def test_subgraph_config_inline():
    """Test SubgraphConfig with inline nodes."""
    config = SubgraphConfig(
        name="preprocess",
        nodes=[
            NodeConfig(
                name="A",
                in_ports={"in": PortConfig()},
                out_ports={"out": PortConfig()},
            ),
            NodeConfig(
                name="B",
                in_ports={"in": PortConfig()},
                out_ports={"out": PortConfig()},
            ),
        ],
        edges=[EdgeConfig(source_str="A.out", target_str="B.in")],
        exposed_in_ports={"input": ExposedPortConfig(internal_node="A", internal_port="in")},
        exposed_out_ports={"output": ExposedPortConfig(internal_node="B", internal_port="out")},
    )
    assert config.type == "subgraph"
    assert config.name == "preprocess"
    assert len(config.nodes) == 2
    assert len(config.edges) == 1
    assert "input" in config.exposed_in_ports
    assert "output" in config.exposed_out_ports

# %%
test_subgraph_config_inline();

# %%
#|export
def test_subgraph_config_validation_both():
    """Test SubgraphConfig raises error when both nodes and path provided."""
    with pytest.raises(ValueError, match="cannot specify both 'nodes' and 'path'"):
        SubgraphConfig(
            name="test",
            nodes=[NodeConfig(name="A")],
            path="./test.netrun.json",
        )

# %%
test_subgraph_config_validation_both();

# %%
#|export
def test_subgraph_config_validation_neither():
    """Test SubgraphConfig raises error when neither nodes nor path provided."""
    with pytest.raises(ValueError, match="must specify either 'nodes'"):
        SubgraphConfig(name="test")

# %%
test_subgraph_config_validation_neither();

# %%
#|export
def test_subgraph_resolve_inline():
    """Test SubgraphConfig.resolve() with inline nodes."""
    config = SubgraphConfig(
        name="preprocess",
        nodes=[
            NodeConfig(
                name="A",
                in_ports={"in": PortConfig()},
                out_ports={"out": PortConfig()},
            ),
            NodeConfig(
                name="B",
                in_ports={"in": PortConfig()},
                out_ports={"out": PortConfig()},
            ),
        ],
        edges=[EdgeConfig(source_str="A.out", target_str="B.in")],
        exposed_in_ports={"input": ExposedPortConfig(internal_node="A", internal_port="in")},
        exposed_out_ports={"output": ExposedPortConfig(internal_node="B", internal_port="out")},
    )

    nodes, edges, in_map, out_map = config.resolve()

    # Check nodes are prefixed
    assert len(nodes) == 2
    node_names = [n.name for n in nodes]
    assert "preprocess.A" in node_names
    assert "preprocess.B" in node_names

    # Check edges are rewritten
    assert len(edges) == 1
    edge = edges[0]
    assert edge.get_source().node_name == "preprocess.A"
    assert edge.get_target().node_name == "preprocess.B"

    # Check port mappings
    assert in_map == {"input": "preprocess.A.in"}
    assert out_map == {"output": "preprocess.B.out"}

# %%
test_subgraph_resolve_inline();

# %%
#|export
def test_graph_config_with_subgraph():
    """Test GraphConfig with mixed nodes and subgraphs."""
    config = GraphConfig(
        nodes=[
            NodeConfig(
                name="Source",
                out_ports={"out": PortConfig()},
            ),
            SubgraphConfig(
                name="preprocess",
                nodes=[
                    NodeConfig(
                        name="A",
                        in_ports={"in": PortConfig()},
                        out_ports={"out": PortConfig()},
                    ),
                    NodeConfig(
                        name="B",
                        in_ports={"in": PortConfig()},
                        out_ports={"out": PortConfig()},
                    ),
                ],
                edges=[EdgeConfig(source_str="A.out", target_str="B.in")],
                exposed_in_ports={"input": ExposedPortConfig(internal_node="A", internal_port="in")},
                exposed_out_ports={"output": ExposedPortConfig(internal_node="B", internal_port="out")},
            ),
            NodeConfig(
                name="Sink",
                in_ports={"in": PortConfig()},
            ),
        ],
        edges=[
            EdgeConfig(source_str="Source.out", target_str="preprocess.input"),
            EdgeConfig(source_str="preprocess.output", target_str="Sink.in"),
        ],
    )

    assert config.has_subgraphs()

    # Resolve the graph
    resolved = config.resolve()

    # Check that subgraphs are flattened
    assert not resolved.has_subgraphs()
    assert len(resolved.nodes) == 4  # Source + preprocess.A + preprocess.B + Sink

    node_names = [n.name for n in resolved.nodes]
    assert "Source" in node_names
    assert "preprocess.A" in node_names
    assert "preprocess.B" in node_names
    assert "Sink" in node_names

    # Check edges are properly rewritten
    assert len(resolved.edges) == 3  # Source->preprocess.A + preprocess.A->B + preprocess.B->Sink

    # Should now be able to get graph
    graph = resolved.get_graph()
    assert len(graph.nodes()) == 4
    assert len(graph.edges()) == 3

# %%
test_graph_config_with_subgraph();

# %%
#|export
def test_graph_config_get_graph_error_with_subgraphs():
    """Test GraphConfig.get_graph() raises error if subgraphs present."""
    config = GraphConfig(
        nodes=[
            SubgraphConfig(
                name="test",
                nodes=[NodeConfig(name="A")],
            ),
        ],
    )

    with pytest.raises(ValueError, match="Call resolve\\(\\) first"):
        config.get_graph()

# %%
test_graph_config_get_graph_error_with_subgraphs();

# %%
#|export
def test_subgraph_nested():
    """Test nested subgraphs."""
    config = GraphConfig(
        nodes=[
            NodeConfig(name="Source", out_ports={"out": PortConfig()}),
            SubgraphConfig(
                name="outer",
                nodes=[
                    NodeConfig(
                        name="Entry",
                        in_ports={"in": PortConfig()},
                        out_ports={"out": PortConfig()},
                    ),
                    SubgraphConfig(
                        name="inner",
                        nodes=[
                            NodeConfig(
                                name="Process",
                                in_ports={"in": PortConfig()},
                                out_ports={"out": PortConfig()},
                            ),
                        ],
                        exposed_in_ports={"input": ExposedPortConfig(internal_node="Process", internal_port="in")},
                        exposed_out_ports={"output": ExposedPortConfig(internal_node="Process", internal_port="out")},
                    ),
                    NodeConfig(
                        name="Exit",
                        in_ports={"in": PortConfig()},
                        out_ports={"out": PortConfig()},
                    ),
                ],
                edges=[
                    EdgeConfig(source_str="Entry.out", target_str="inner.input"),
                    EdgeConfig(source_str="inner.output", target_str="Exit.in"),
                ],
                exposed_in_ports={"input": ExposedPortConfig(internal_node="Entry", internal_port="in")},
                exposed_out_ports={"output": ExposedPortConfig(internal_node="Exit", internal_port="out")},
            ),
            NodeConfig(name="Sink", in_ports={"in": PortConfig()}),
        ],
        edges=[
            EdgeConfig(source_str="Source.out", target_str="outer.input"),
            EdgeConfig(source_str="outer.output", target_str="Sink.in"),
        ],
    )

    resolved = config.resolve()

    # Check all nodes are flattened with proper prefixes
    node_names = [n.name for n in resolved.nodes]
    assert "Source" in node_names
    assert "outer.Entry" in node_names
    assert "outer.inner.Process" in node_names  # Nested subgraph node
    assert "outer.Exit" in node_names
    assert "Sink" in node_names

    # Verify graph is valid
    graph = resolved.get_graph()
    assert len(graph.nodes()) == 5

# %%
test_subgraph_nested();

# %%
#|export
def test_subgraph_name_collision():
    """Test that name collisions are detected."""
    # Create a config where two subgraphs would produce nodes with the same prefixed name
    config = GraphConfig(
        nodes=[
            SubgraphConfig(
                name="sg",
                nodes=[
                    NodeConfig(name="A", in_ports={"in": PortConfig()}, out_ports={"out": PortConfig()}),
                ],
                exposed_in_ports={"input": ExposedPortConfig(internal_node="A", internal_port="in")},
                exposed_out_ports={"output": ExposedPortConfig(internal_node="A", internal_port="out")},
            ),
            SubgraphConfig(
                name="sg",  # Same name as above
                nodes=[
                    NodeConfig(name="A", in_ports={"in": PortConfig()}),  # Same internal name as above -> collision!
                ],
                exposed_in_ports={"input": ExposedPortConfig(internal_node="A", internal_port="in")},
            ),
        ],
        edges=[
            EdgeConfig(source_str="sg.output", target_str="sg.input"),
        ],
    )

    # This should fail because both subgraphs produce "sg.A"
    with pytest.raises(ValueError, match="Node name collision"):
        config.resolve()

# %%
test_subgraph_name_collision();

# %%
#|export
def test_subgraph_json_roundtrip():
    """Test SubgraphConfig JSON serialization roundtrip."""
    config = SubgraphConfig(
        name="preprocess",
        nodes=[
            NodeConfig(
                name="A",
                in_ports={"in": PortConfig()},
                out_ports={"out": PortConfig()},
            ),
            NodeConfig(
                name="B",
                in_ports={"in": PortConfig()},
                out_ports={"out": PortConfig()},
            ),
        ],
        edges=[EdgeConfig(source_str="A.out", target_str="B.in")],
        exposed_in_ports={"input": ExposedPortConfig(internal_node="A", internal_port="in")},
        exposed_out_ports={"output": ExposedPortConfig(internal_node="B", internal_port="out")},
        extra={"description": "Preprocessing pipeline"},
    )

    json_str = config.model_dump_json()
    loaded = SubgraphConfig.model_validate_json(json_str)

    assert loaded.name == config.name
    assert len(loaded.nodes) == len(config.nodes)
    assert len(loaded.edges) == len(config.edges)
    assert loaded.exposed_in_ports == config.exposed_in_ports
    assert loaded.exposed_out_ports == config.exposed_out_ports
    assert loaded.extra == config.extra

# %%
test_subgraph_json_roundtrip();

# %%
#|export
def test_graph_config_with_subgraph_json_roundtrip():
    """Test GraphConfig with subgraphs JSON serialization roundtrip."""
    config = GraphConfig(
        nodes=[
            NodeConfig(name="Source", out_ports={"out": PortConfig()}),
            SubgraphConfig(
                name="preprocess",
                nodes=[
                    NodeConfig(
                        name="A",
                        in_ports={"in": PortConfig()},
                        out_ports={"out": PortConfig()},
                    ),
                ],
                exposed_in_ports={"input": ExposedPortConfig(internal_node="A", internal_port="in")},
                exposed_out_ports={"output": ExposedPortConfig(internal_node="A", internal_port="out")},
            ),
            NodeConfig(name="Sink", in_ports={"in": PortConfig()}),
        ],
        edges=[
            EdgeConfig(source_str="Source.out", target_str="preprocess.input"),
            EdgeConfig(source_str="preprocess.output", target_str="Sink.in"),
        ],
    )

    json_str = config.model_dump_json(indent=2)
    loaded = GraphConfig.model_validate_json(json_str)

    # Verify structure
    assert len(loaded.nodes) == 3
    assert loaded.has_subgraphs()

    # Find the subgraph
    subgraph = next(n for n in loaded.nodes if isinstance(n, SubgraphConfig))
    assert subgraph.name == "preprocess"
    assert len(subgraph.nodes) == 1

    # Resolve and verify
    resolved = loaded.resolve()
    assert not resolved.has_subgraphs()
    graph = resolved.get_graph()
    assert len(graph.nodes()) == 3

# %%
test_graph_config_with_subgraph_json_roundtrip();

# %%
#|export
def test_subgraph_file_reference():
    """Test SubgraphConfig with file reference."""
    # Create a temporary subgraph file
    with tempfile.TemporaryDirectory() as tmpdir:
        subgraph_path = Path(tmpdir) / "subgraph.netrun.json"

        # Write a graph config to file
        subgraph_data = {
            "nodes": [
                {
                    "type": "node",
                    "name": "Internal",
                    "in_ports": {"in": {"slots_spec": {"type": "infinite"}}},
                    "out_ports": {"out": {"slots_spec": {"type": "infinite"}}},
                },
            ],
            "edges": [],
        }
        with open(subgraph_path, "w") as f:
            json.dump(subgraph_data, f)

        # Create subgraph config referencing the file
        config = SubgraphConfig(
            name="external",
            path=str(subgraph_path),
            exposed_in_ports={"input": ExposedPortConfig(internal_node="Internal", internal_port="in")},
            exposed_out_ports={"output": ExposedPortConfig(internal_node="Internal", internal_port="out")},
        )

        # Resolve
        nodes, edges, in_map, out_map = config.resolve(base_path=Path(tmpdir))

        assert len(nodes) == 1
        assert nodes[0].name == "external.Internal"
        assert in_map == {"input": "external.Internal.in"}
        assert out_map == {"output": "external.Internal.out"}

# %%
test_subgraph_file_reference();

# %%
#|export
def test_subgraph_file_not_found():
    """Test SubgraphConfig raises error when file not found."""
    config = SubgraphConfig(
        name="missing",
        path="./nonexistent.netrun.json",
    )

    with pytest.raises(FileNotFoundError):
        config.resolve()

# %%
test_subgraph_file_not_found();

# %%
#|export
def test_subgraph_circular_reference():
    """Test SubgraphConfig detects circular file references."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create two files that reference each other
        file_a = Path(tmpdir) / "a.netrun.json"
        file_b = Path(tmpdir) / "b.netrun.json"

        # a.netrun.json contains a subgraph referencing b.netrun.json
        a_data = {
            "nodes": [
                {
                    "type": "subgraph",
                    "name": "ref_b",
                    "path": str(file_b),
                    "exposed_in_ports": {},
                    "exposed_out_ports": {},
                },
            ],
            "edges": [],
        }

        # b.netrun.json contains a subgraph referencing a.netrun.json
        b_data = {
            "nodes": [
                {
                    "type": "subgraph",
                    "name": "ref_a",
                    "path": str(file_a),
                    "exposed_in_ports": {},
                    "exposed_out_ports": {},
                },
            ],
            "edges": [],
        }

        with open(file_a, "w") as f:
            json.dump(a_data, f)
        with open(file_b, "w") as f:
            json.dump(b_data, f)

        # Create subgraph config referencing file_a
        config = SubgraphConfig(
            name="start",
            path=str(file_a),
            exposed_in_ports={},
            exposed_out_ports={},
        )

        with pytest.raises(ValueError, match="Circular subgraph reference"):
            config.resolve(base_path=Path(tmpdir))

# %%
test_subgraph_circular_reference();

# %% [markdown]
# ## NetConfig Tests

# %%
#|export
def test_netconfig_project_root_default_cwd():
    """Test project_root_path defaults to cwd when both project_root and _file_path are None."""
    config = NetConfig(
        graph=GraphConfig(nodes=[NodeConfig(name="A")]),
    )
    assert config.project_root is None
    assert config._file_path is None
    assert config.project_root_path == Path(os.getcwd())

# %%
test_netconfig_project_root_default_cwd();

# %%
#|export
def test_netconfig_project_root_absolute():
    """Test project_root_path with an absolute project_root."""
    config = NetConfig(
        project_root="/tmp/my_project",
        graph=GraphConfig(nodes=[NodeConfig(name="A")]),
    )
    assert config.project_root_path == Path("/tmp/my_project")

# %%
test_netconfig_project_root_absolute();

# %%
#|export
def test_netconfig_project_root_relative_with_file():
    """Test project_root_path resolves relative project_root from file location."""
    config = NetConfig(
        project_root="../other",
        graph=GraphConfig(nodes=[NodeConfig(name="A")]),
    )
    config._file_path = Path("/home/user/configs/net.json")
    expected = (Path("/home/user/configs") / "../other").resolve()
    assert config.project_root_path == expected

# %%
test_netconfig_project_root_relative_with_file();

# %%
#|export
def test_netconfig_project_root_none_with_file():
    """Test project_root_path returns file's parent when project_root is None."""
    config = NetConfig(
        graph=GraphConfig(nodes=[NodeConfig(name="A")]),
    )
    config._file_path = Path("/home/user/configs/net.json")
    assert config.project_root_path == Path("/home/user/configs")

# %%
test_netconfig_project_root_none_with_file();

# %%
#|export
def test_netconfig_from_file_json(tmp_path):
    """Test NetConfig.from_file() with a JSON file."""
    data = {
        "project_root": "./src",
        "graph": {
            "nodes": [{"name": "A", "out_ports": {"out": {"slots_spec": {"type": "infinite"}}}}],
            "edges": [],
        },
    }
    file_path = tmp_path / "test.netrun.json"
    file_path.write_text(json.dumps(data))

    config = NetConfig.from_file(file_path)

    assert config.project_root == "./src"
    assert config._file_path == file_path.resolve()
    assert len(config.graph.nodes) == 1

# %%
test_netconfig_from_file_json(Path(tempfile.mkdtemp()));

# %%
#|export
def test_netconfig_from_file_toml(tmp_path):
    """Test NetConfig.from_file() with a TOML file."""
    toml_content = """
project_root = "/absolute/path"

[graph]
nodes = []
edges = []
"""
    file_path = tmp_path / "test.netrun.toml"
    file_path.write_text(toml_content)

    config = NetConfig.from_file(file_path)

    assert config.project_root == "/absolute/path"
    assert config._file_path == file_path.resolve()
    assert len(config.graph.nodes) == 0

# %%
test_netconfig_from_file_toml(Path(tempfile.mkdtemp()));

# %%
#|export
def test_netconfig_serialization_excludes_file_path():
    """Test that _file_path (PrivateAttr) is not included in serialization."""
    config = NetConfig(
        project_root="./src",
        graph=GraphConfig(nodes=[NodeConfig(name="A")]),
    )
    config._file_path = Path("/some/path/net.json")

    dumped = config.model_dump()
    assert "_file_path" not in dumped
    assert "project_root" in dumped
    assert dumped["project_root"] == "./src"

    json_str = config.model_dump_json()
    assert "_file_path" not in json_str
    assert "project_root" in json_str

# %%
test_netconfig_serialization_excludes_file_path();

# %%
#|export
def test_netconfig_resolve_preserves_file_path():
    """Test that resolve() preserves _file_path on the returned copy."""
    config = NetConfig(
        graph=GraphConfig(nodes=[NodeConfig(name="A")]),
    )
    config._file_path = Path("/home/user/configs/net.json")

    resolved = config.resolve()

    # pools was None so resolve() creates a copy with default pools
    assert resolved is not config
    assert resolved._file_path == Path("/home/user/configs/net.json")
    assert resolved.pools is not None

# %%
test_netconfig_resolve_preserves_file_path();

# %% [markdown]
# ## NodeVariable Tests

# %%
#|export
def test_node_variable_resolve_str():
    """Test NodeVariable resolves str type."""
    var = NodeVariable(value="hello", type="str")
    assert var.resolve_value() == "hello"

    # Default type is "str"
    var2 = NodeVariable(value="world")
    assert var2.resolve_value() == "world"

    # Empty string type also resolves as str
    var3 = NodeVariable(value="test", type="")
    assert var3.resolve_value() == "test"

# %%
test_node_variable_resolve_str();

# %%
#|export
def test_node_variable_resolve_int():
    """Test NodeVariable resolves int type."""
    var = NodeVariable(value="42", type="int")
    assert var.resolve_value() == 42
    assert isinstance(var.resolve_value(), int)

# %%
test_node_variable_resolve_int();

# %%
#|export
def test_node_variable_resolve_float():
    """Test NodeVariable resolves float type."""
    var = NodeVariable(value="3.14", type="float")
    assert var.resolve_value() == 3.14
    assert isinstance(var.resolve_value(), float)

# %%
test_node_variable_resolve_float();

# %%
#|export
def test_node_variable_resolve_bool():
    """Test NodeVariable resolves bool type."""
    for true_val in ("true", "True", "TRUE", "1", "yes", "Yes"):
        var = NodeVariable(value=true_val, type="bool")
        assert var.resolve_value() is True, f"Expected True for '{true_val}'"

    for false_val in ("false", "False", "FALSE", "0", "no", "No"):
        var = NodeVariable(value=false_val, type="bool")
        assert var.resolve_value() is False, f"Expected False for '{false_val}'"

# %%
test_node_variable_resolve_bool();

# %%
#|export
def test_node_variable_resolve_json():
    """Test NodeVariable resolves json type."""
    var = NodeVariable(value='{"key": "value", "num": 42}', type="json")
    result = var.resolve_value()
    assert result == {"key": "value", "num": 42}
    assert isinstance(result, dict)

    # JSON array
    var2 = NodeVariable(value='[1, 2, 3]', type="json")
    assert var2.resolve_value() == [1, 2, 3]

# %%
test_node_variable_resolve_json();

# %%
#|export
def test_node_variable_resolve_errors():
    """Test NodeVariable raises errors for invalid values."""
    # Invalid int
    with pytest.raises(ValueError):
        NodeVariable(value="not_an_int", type="int").resolve_value()

    # Invalid float
    with pytest.raises(ValueError):
        NodeVariable(value="not_a_float", type="float").resolve_value()

    # Invalid bool
    with pytest.raises(ValueError, match="Cannot parse"):
        NodeVariable(value="maybe", type="bool").resolve_value()

    # Invalid json
    with pytest.raises(json.JSONDecodeError):
        NodeVariable(value="not json", type="json").resolve_value()

    # Unsupported type
    with pytest.raises(ValueError, match="Unsupported"):
        NodeVariable(value="test", type="unknown_type").resolve_value()

# %%
test_node_variable_resolve_errors();

# %%
#|export
def test_node_variable_serialization_roundtrip():
    """Test NodeVariable Pydantic model_dump / model_validate roundtrip."""
    var = NodeVariable(value="42", type="int")
    dumped = var.model_dump()
    assert dumped == {"value": "42", "type": "int"}

    restored = NodeVariable.model_validate(dumped)
    assert restored.value == "42"
    assert restored.type == "int"
    assert restored.resolve_value() == 42

    # JSON roundtrip
    json_str = var.model_dump_json()
    restored_json = NodeVariable.model_validate_json(json_str)
    assert restored_json == var

# %%
test_node_variable_serialization_roundtrip();

# %%
#|export
def test_node_execution_config_with_vars():
    """Test NodeExecutionConfig with node_vars field."""
    config = NodeExecutionConfig(
        node_vars={
            "api_key": NodeVariable(value="sk-123", type="str"),
            "batch_size": NodeVariable(value="32", type="int"),
        }
    )
    assert config.node_vars is not None
    assert len(config.node_vars) == 2
    assert config.node_vars["api_key"].resolve_value() == "sk-123"
    assert config.node_vars["batch_size"].resolve_value() == 32

# %%
test_node_execution_config_with_vars();

# %%
#|export
def test_net_config_with_vars():
    """Test NetConfig with node_vars field."""
    config = NetConfig(
        graph=GraphConfig(nodes=[NodeConfig(name="A")]),
        node_vars={
            "env": NodeVariable(value="production", type="str"),
            "debug": NodeVariable(value="false", type="bool"),
        }
    )
    assert config.node_vars is not None
    assert len(config.node_vars) == 2
    assert config.node_vars["env"].resolve_value() == "production"
    assert config.node_vars["debug"].resolve_value() is False

# %%
test_net_config_with_vars();

# %%
#|export
def test_net_config_rejects_multiple_main_pools():
    """Multiple pools with type 'main' should be rejected."""
    graph = GraphConfig(nodes=[
        NodeConfig(name="A", in_ports={"in": PortConfig()}, out_ports={"out": PortConfig()}),
    ], edges=[])

    # One main pool is fine
    NetConfig(
        graph=graph,
        pools={
            "main": PoolConfig(spec=MainPoolConfig()),
            "workers": PoolConfig(spec=ThreadPoolConfig(num_workers=4)),
        },
    )

    # Two main pools should fail
    with pytest.raises(ValueError, match="Only one pool may have type 'main'"):
        NetConfig(
            graph=graph,
            pools={
                "main1": PoolConfig(spec=MainPoolConfig()),
                "main2": PoolConfig(spec=MainPoolConfig()),
            },
        )

    # Zero main pools is fine (all thread pools)
    NetConfig(
        graph=graph,
        pools={
            "workers1": PoolConfig(spec=ThreadPoolConfig(num_workers=2)),
            "workers2": PoolConfig(spec=ThreadPoolConfig(num_workers=2)),
        },
    )

# %%
test_net_config_rejects_multiple_main_pools();

# %% [markdown]
# ## File-Path Reference Tests

# %%
#|export
from netrun.net.config import _is_file_path_ref, _import_from_file_path, _import_from_path

# %%
#|export
def test_is_file_path_ref_dotted_paths():
    """Test that dotted import paths are not detected as file refs."""
    assert _is_file_path_ref("myapp.utils.func") is False
    assert _is_file_path_ref("netrun.node_factories.from_function") is False
    assert _is_file_path_ref("json") is False
    assert _is_file_path_ref("") is False

# %%
test_is_file_path_ref_dotted_paths();

# %%
#|export
def test_is_file_path_ref_file_paths():
    """Test that file-path references are detected correctly."""
    # Double colon
    assert _is_file_path_ref("nodes.py::my_func") is True
    assert _is_file_path_ref("./factory.py::get_node_config") is True

    # Forward slash
    assert _is_file_path_ref("path/to/file.py") is True
    assert _is_file_path_ref("./nodes.py") is True

    # Backslash
    assert _is_file_path_ref("path\\to\\file.py") is True

    # Dot prefix
    assert _is_file_path_ref("./module.py") is True
    assert _is_file_path_ref("../lib/factory.py") is True

# %%
test_is_file_path_ref_file_paths();

# %%
#|export
def test_import_from_file_path_basic():
    """Test importing a module from a file path."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        mod_file = tmp / "my_module.py"
        mod_file.write_text(textwrap.dedent("""\
            VALUE = 42
            def hello():
                return "world"
        """))

        result = _import_from_file_path(str(mod_file))
        # Without ::, returns the module
        assert hasattr(result, "VALUE")
        assert result.VALUE == 42
        assert result.hello() == "world"

# %%
test_import_from_file_path_basic();

# %%
#|export
def test_import_from_file_path_with_attr():
    """Test importing a specific attribute with :: syntax."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        mod_file = tmp / "funcs.py"
        mod_file.write_text(textwrap.dedent("""\
            def my_func():
                return "result"
            def other():
                return "other"
        """))

        result = _import_from_file_path(f"{mod_file}::my_func")
        assert callable(result)
        assert result() == "result"

# %%
test_import_from_file_path_with_attr();

# %%
#|export
def test_import_from_file_path_relative_with_project_root():
    """Test that relative paths resolve against project_root."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        mod_file = tmp / "nodes.py"
        mod_file.write_text("GREETING = 'hello'\n")

        result = _import_from_file_path("./nodes.py", project_root=tmp)
        assert hasattr(result, "GREETING")
        assert result.GREETING == "hello"

# %%
test_import_from_file_path_relative_with_project_root();

# %%
#|export
def test_import_from_file_path_nested_relative():
    """Test importing from a subdirectory with relative path."""
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        subdir = tmp / "lib"
        subdir.mkdir()
        mod_file = subdir / "utils.py"
        mod_file.write_text("X = 99\n")

        result = _import_from_file_path("./lib/utils.py", project_root=tmp)
        assert result.X == 99

# %%
test_import_from_file_path_nested_relative();

# %%
#|export
def test_import_from_file_path_missing_file():
    """Test that missing file raises FileNotFoundError."""
    with tempfile.TemporaryDirectory() as tmp_dir:
        with pytest.raises(FileNotFoundError, match="Module file not found"):
            _import_from_file_path(
                "./nonexistent.py", project_root=Path(tmp_dir)
            )

# %%
test_import_from_file_path_missing_file();

# %%
#|export
def test_import_from_path_dispatches_dotted():
    """Test that _import_from_path handles dotted imports correctly."""
    import json as json_mod
    result = _import_from_path("json.dumps")
    assert result is json_mod.dumps

# %%
test_import_from_path_dispatches_dotted();

# %%
#|export
def test_import_from_path_dispatches_file_path():
    """Test that _import_from_path dispatches to file-path import."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        mod_file = tmp / "dispatch_test.py"
        mod_file.write_text(textwrap.dedent("""\
            def target():
                return "dispatched"
        """))

        result = _import_from_path(
            f"{mod_file}::target", project_root=tmp
        )
        assert callable(result)
        assert result() == "dispatched"

# %%
test_import_from_path_dispatches_file_path();

# %%
#|export
def test_node_execution_config_resolve_with_file_path():
    """Test NodeExecutionConfig.resolve() with file-path function references."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        funcs_file = tmp / "node_funcs.py"
        funcs_file.write_text(textwrap.dedent("""\
            def my_exec(ctx):
                pass
            def my_start(ctx):
                pass
        """))

        exec_config = NodeExecutionConfig(
            exec_node_func=f"{funcs_file}::my_exec",
            start_node_func=f"{funcs_file}::my_start",
        )

        resolved = exec_config.resolve(project_root=tmp)

        assert callable(resolved.exec_node_func)
        assert callable(resolved.start_node_func)
        assert resolved.exec_node_func.__name__ == "my_exec"
        assert resolved.start_node_func.__name__ == "my_start"

# %%
test_node_execution_config_resolve_with_file_path();

# %%
#|export
def test_node_config_resolve_factory_file_path():
    """Test NodeConfig.resolve() with a file-path factory reference."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        factory_file = tmp / "my_factory.py"
        factory_file.write_text(textwrap.dedent("""\
            from netrun.net.config import NodeConfig, PortConfig

            def get_node_config(_net_config=None, *, name="FileFactoryNode"):
                return NodeConfig(
                    name=name,
                    in_ports={"input": PortConfig()},
                    out_ports={"output": PortConfig()},
                )
        """))

        config = NodeConfig(
            name="TestNode",
            factory=str(factory_file),
        )

        _nc = NetConfig(project_root=str(tmp), graph=GraphConfig(nodes=[]))
        resolved = config.resolve(net_config=_nc)

        assert resolved.name == "TestNode"
        assert "input" in resolved.in_ports
        assert "output" in resolved.out_ports

# %%
test_node_config_resolve_factory_file_path();

# %%
#|export
def test_node_config_from_factory_file_path():
    """Test NodeConfig.from_factory() with a file-path factory reference."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        factory_file = tmp / "from_factory_test.py"
        factory_file.write_text(textwrap.dedent("""\
            from netrun.net.config import NodeConfig, PortConfig

            def get_node_config(_net_config=None):
                return NodeConfig(
                    name="FromFactoryNode",
                    in_ports={"in": PortConfig()},
                    out_ports={"out": PortConfig()},
                )

            def get_node_funcs(_net_config=None):
                def exec_fn(ctx):
                    pass
                return exec_fn, None, None, None
        """))

        result = NodeConfig.from_factory(
            name="OverriddenName",
            factory=str(factory_file),
            project_root=tmp,
        )

        assert result.name == "OverriddenName"
        assert "in" in result.in_ports
        assert "out" in result.out_ports
        assert result.execution_config is not None
        assert callable(result.execution_config.exec_node_func)

# %%
test_node_config_from_factory_file_path();

# %%
#|export
def test_graph_config_resolve_with_project_root():
    """Test GraphConfig.resolve() passes project_root to nodes."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        factory_file = tmp / "graph_factory.py"
        factory_file.write_text(textwrap.dedent("""\
            from netrun.net.config import NodeConfig, PortConfig

            def get_node_config(_net_config=None):
                return NodeConfig(
                    name="GraphFactoryNode",
                    in_ports={"in": PortConfig()},
                    out_ports={"out": PortConfig()},
                )
        """))

        graph = GraphConfig(
            nodes=[
                NodeConfig(name="FactoryNode", factory=str(factory_file)),
            ],
        )

        _nc = NetConfig(project_root=str(tmp), graph=GraphConfig(nodes=[]))
        resolved = graph.resolve(net_config=_nc)

        # The factory node should have been resolved
        factory_node = next(n for n in resolved.nodes if n.name == "FactoryNode")
        assert "in" in factory_node.in_ports
        assert "out" in factory_node.out_ports

# %%
test_graph_config_resolve_with_project_root();

# %%
#|export
def test_net_config_resolve_with_file_path_factory():
    """Test that NetConfig.resolve() uses project_root_path for file-path factories."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        factory_file = tmp / "net_factory.py"
        factory_file.write_text(textwrap.dedent("""\
            from netrun.net.config import NodeConfig, PortConfig

            def get_node_config(_net_config=None):
                return NodeConfig(
                    name="NetFactoryNode",
                    in_ports={"data": PortConfig()},
                    out_ports={"result": PortConfig()},
                )
        """))

        net = NetConfig(
            graph=GraphConfig(
                nodes=[
                    NodeConfig(
                        name="Worker",
                        factory=str(factory_file),
                    ),
                ],
            ),
            project_root=str(tmp),
        )

        resolved = net.resolve()

        worker = next(n for n in resolved.graph.nodes if n.name == "Worker")
        assert "data" in worker.in_ports
        assert "result" in worker.out_ports

# %%
test_net_config_resolve_with_file_path_factory();

# %%
#|export
def test_net_config_resolve_relative_factory_path():
    """Test NetConfig.resolve() resolves relative factory paths from project_root."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        # Create a net config file in a subdirectory
        config_dir = tmp / "configs"
        config_dir.mkdir()

        # Create factory in project root
        factory_file = tmp / "my_nodes.py"
        factory_file.write_text(textwrap.dedent("""\
            from netrun.net.config import NodeConfig, PortConfig

            def get_node_config(_net_config=None):
                return NodeConfig(
                    name="RelativeNode",
                    in_ports={"in": PortConfig()},
                    out_ports={"out": PortConfig()},
                )
        """))

        net = NetConfig(
            graph=GraphConfig(
                nodes=[
                    NodeConfig(
                        name="Worker",
                        factory="./my_nodes.py",
                    ),
                ],
            ),
            project_root=str(tmp),
        )

        resolved = net.resolve()

        worker = next(n for n in resolved.graph.nodes if n.name == "Worker")
        assert "in" in worker.in_ports
        assert "out" in worker.out_ports

# %%
test_net_config_resolve_relative_factory_path();

# %% [markdown]
# ## Output Queue Tests

# %%
#|export
def test_net_config_default_output_queues():
    """Test that output_queues=None generates queues for unconnected ports."""
    config = NetConfig(
        graph=GraphConfig(
            nodes=[
                NodeConfig(name="Source", out_ports={"out": PortConfig()}),
                NodeConfig(name="Middle", in_ports={"in": PortConfig()}, out_ports={"out1": PortConfig(), "out2": PortConfig()}),
                NodeConfig(name="Sink", in_ports={"in": PortConfig()}, out_ports={"result": PortConfig()}),
            ],
            edges=[
                EdgeConfig(source_str="Source.out", target_str="Middle.in"),
                EdgeConfig(source_str="Middle.out1", target_str="Sink.in"),
                # Middle.out2 and Sink.result are unconnected
            ],
        ),
        # output_queues is None by default
    )

    resolved = config.resolve()

    # Should have auto-generated queues for unconnected output ports
    assert resolved.output_queues is not None
    assert "Middle::out2" in resolved.output_queues
    assert "Sink::result" in resolved.output_queues

    # Connected ports should NOT have queues
    assert "Source::out" not in resolved.output_queues
    assert "Middle::out1" not in resolved.output_queues

    # Check queue configs are correct
    assert resolved.output_queues["Middle::out2"].ports == [("Middle", "out2")]
    assert resolved.output_queues["Sink::result"].ports == [("Sink", "result")]

# %%
test_net_config_default_output_queues()

# %%
#|export
def test_net_config_explicit_output_queues_preserved():
    """Test that explicit output_queues={} is preserved (no auto-generation)."""
    config = NetConfig(
        graph=GraphConfig(
            nodes=[
                NodeConfig(name="Source", out_ports={"out": PortConfig()}),
            ],
        ),
        output_queues={},  # Explicitly empty
    )

    resolved = config.resolve()

    # Empty dict should be preserved, not replaced with auto-generated
    assert resolved.output_queues == {}

# %%
test_net_config_explicit_output_queues_preserved()

# %%
#|export
def test_net_config_custom_output_queues_preserved():
    """Test that custom output_queues config is preserved."""
    config = NetConfig(
        graph=GraphConfig(
            nodes=[
                NodeConfig(name="Sink", out_ports={"out": PortConfig()}),
            ],
        ),
        output_queues={
            "my_results": OutputQueueConfig(ports=[("Sink", "out")]),
        },
    )

    resolved = config.resolve()

    # Custom config should be preserved
    assert "my_results" in resolved.output_queues
    assert resolved.output_queues["my_results"].ports == [("Sink", "out")]

# %%
test_net_config_custom_output_queues_preserved()

# %% [markdown]
# ## Subgraph Factory Tests

# %%
#|export
def test_factory_returns_subgraph_basic():
    """Test that a factory returning SubgraphConfig is flattened correctly."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        factory_file = tmp / "sg_factory.py"
        factory_file.write_text(textwrap.dedent("""\
            from netrun.net.config import (
                NodeConfig, SubgraphConfig, EdgeConfig,
                PortConfig, ExposedPortConfig,
            )

            def get_node_config(_net_config=None, *, num_stages=2):
                nodes = [
                    NodeConfig(
                        name=f"stage_{i}",
                        in_ports={"in": PortConfig()},
                        out_ports={"out": PortConfig()},
                    )
                    for i in range(num_stages)
                ]
                edges = [
                    EdgeConfig(
                        source_str=f"stage_{i}.out",
                        target_str=f"stage_{i+1}.in",
                    )
                    for i in range(num_stages - 1)
                ]
                return SubgraphConfig(
                    name="pipeline",
                    nodes=nodes,
                    edges=edges,
                    exposed_in_ports={"in": ExposedPortConfig(
                        internal_node="stage_0", internal_port="in",
                    )},
                    exposed_out_ports={"out": ExposedPortConfig(
                        internal_node=f"stage_{num_stages - 1}", internal_port="out",
                    )},
                )
        """))

        graph = GraphConfig(
            nodes=[
                NodeConfig(name="pipeline", factory=str(factory_file)),
            ],
        )

        _nc = NetConfig(project_root=str(tmp), graph=GraphConfig(nodes=[]))
        resolved = graph.resolve(net_config=_nc)

        # Should have 2 flattened nodes
        assert len(resolved.nodes) == 2
        node_names = [n.name for n in resolved.nodes]
        assert "pipeline.stage_0" in node_names
        assert "pipeline.stage_1" in node_names

        # Should have internal edge
        assert len(resolved.edges) == 1
        edge = resolved.edges[0]
        assert edge.get_source().node_name == "pipeline.stage_0"
        assert edge.get_target().node_name == "pipeline.stage_1"

# %%
test_factory_returns_subgraph_basic()

# %%
#|export
def test_factory_returns_subgraph_exposed_ports():
    """Test that parent-level edges connect to exposed ports of factory subgraphs."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        factory_file = tmp / "sg_factory2.py"
        factory_file.write_text(textwrap.dedent("""\
            from netrun.net.config import (
                NodeConfig, SubgraphConfig, EdgeConfig,
                PortConfig, ExposedPortConfig,
            )

            def get_node_config(_net_config=None):
                return SubgraphConfig(
                    name="inner",
                    nodes=[
                        NodeConfig(
                            name="A",
                            in_ports={"in": PortConfig()},
                            out_ports={"out": PortConfig()},
                        ),
                        NodeConfig(
                            name="B",
                            in_ports={"in": PortConfig()},
                            out_ports={"out": PortConfig()},
                        ),
                    ],
                    edges=[EdgeConfig(source_str="A.out", target_str="B.in")],
                    exposed_in_ports={"input": ExposedPortConfig(
                        internal_node="A", internal_port="in",
                    )},
                    exposed_out_ports={"output": ExposedPortConfig(
                        internal_node="B", internal_port="out",
                    )},
                )
        """))

        graph = GraphConfig(
            nodes=[
                NodeConfig(name="Source", out_ports={"out": PortConfig()}),
                NodeConfig(name="middle", factory=str(factory_file)),
                NodeConfig(name="Sink", in_ports={"in": PortConfig()}),
            ],
            edges=[
                EdgeConfig(source_str="Source.out", target_str="middle.input"),
                EdgeConfig(source_str="middle.output", target_str="Sink.in"),
            ],
        )

        _nc = NetConfig(project_root=str(tmp), graph=GraphConfig(nodes=[]))
        resolved = graph.resolve(net_config=_nc)

        # 4 nodes: Source, middle.A, middle.B, Sink
        assert len(resolved.nodes) == 4
        node_names = [n.name for n in resolved.nodes]
        assert "Source" in node_names
        assert "middle.A" in node_names
        assert "middle.B" in node_names
        assert "Sink" in node_names

        # 3 edges: Source->middle.A, middle.A->middle.B, middle.B->Sink
        assert len(resolved.edges) == 3

        # Check the rewritten edges connect properly
        edge_pairs = [
            (e.get_source().node_name, e.get_target().node_name)
            for e in resolved.edges
        ]
        assert ("Source", "middle.A") in edge_pairs
        assert ("middle.A", "middle.B") in edge_pairs
        assert ("middle.B", "Sink") in edge_pairs

# %%
test_factory_returns_subgraph_exposed_ports()

# %%
#|export
def test_factory_returns_subgraph_name_override():
    """Test that NodeConfig's name overrides factory SubgraphConfig's name."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        factory_file = tmp / "sg_factory_name.py"
        factory_file.write_text(textwrap.dedent("""\
            from netrun.net.config import (
                NodeConfig, SubgraphConfig, PortConfig, ExposedPortConfig,
            )

            def get_node_config(_net_config=None):
                return SubgraphConfig(
                    name="default_name",
                    nodes=[
                        NodeConfig(name="Inner", in_ports={"in": PortConfig()}, out_ports={"out": PortConfig()}),
                    ],
                    exposed_in_ports={"in": ExposedPortConfig(internal_node="Inner", internal_port="in")},
                    exposed_out_ports={"out": ExposedPortConfig(internal_node="Inner", internal_port="out")},
                )
        """))

        _nc = NetConfig(project_root=str(tmp), graph=GraphConfig(nodes=[]))

        # NodeConfig has explicit name that overrides factory's
        node = NodeConfig(name="custom_name", factory=str(factory_file))
        resolved = node.resolve(net_config=_nc)

        assert isinstance(resolved, SubgraphConfig)
        assert resolved.name == "custom_name"

        # If name is empty, factory name is used
        node2 = NodeConfig(factory=str(factory_file))
        resolved2 = node2.resolve(net_config=_nc)
        assert isinstance(resolved2, SubgraphConfig)
        assert resolved2.name == "default_name"

# %%
test_factory_returns_subgraph_name_override()

# %%
#|export
def test_factory_returns_subgraph_extra_merge():
    """Test that extra dict is merged (NodeConfig overrides factory)."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        factory_file = tmp / "sg_factory_extra.py"
        factory_file.write_text(textwrap.dedent("""\
            from netrun.net.config import (
                NodeConfig, SubgraphConfig, PortConfig, ExposedPortConfig,
            )

            def get_node_config(_net_config=None):
                return SubgraphConfig(
                    name="sg",
                    nodes=[
                        NodeConfig(name="A", in_ports={"in": PortConfig()}),
                    ],
                    exposed_in_ports={"in": ExposedPortConfig(internal_node="A", internal_port="in")},
                    extra={"factory_key": "factory_value", "shared_key": "from_factory"},
                )
        """))

        node = NodeConfig(
            name="sg",
            factory=str(factory_file),
            extra={"node_key": "node_value", "shared_key": "from_node"},
        )
        _nc = NetConfig(project_root=str(tmp), graph=GraphConfig(nodes=[]))
        resolved = node.resolve(net_config=_nc)

        assert isinstance(resolved, SubgraphConfig)
        assert resolved.extra["factory_key"] == "factory_value"
        assert resolved.extra["node_key"] == "node_value"
        # NodeConfig's extra takes precedence
        assert resolved.extra["shared_key"] == "from_node"

# %%
test_factory_returns_subgraph_extra_merge()

# %%
#|export
def test_factory_returns_subgraph_from_factory_raises():
    """Test that NodeConfig.from_factory() raises ValueError for subgraph factories."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        factory_file = tmp / "sg_factory_raise.py"
        factory_file.write_text(textwrap.dedent("""\
            from netrun.net.config import (
                NodeConfig, SubgraphConfig, PortConfig, ExposedPortConfig,
            )

            def get_node_config(_net_config=None):
                return SubgraphConfig(
                    name="sg",
                    nodes=[NodeConfig(name="A", in_ports={"in": PortConfig()})],
                    exposed_in_ports={"in": ExposedPortConfig(internal_node="A", internal_port="in")},
                )

            def get_node_funcs(_net_config=None):
                return None, None, None, None
        """))

        with pytest.raises(ValueError, match="from_factory\\(\\) does not support subgraph factories"):
            NodeConfig.from_factory(factory=str(factory_file), project_root=tmp)

# %%
test_factory_returns_subgraph_from_factory_raises()

# %%
#|export
def test_factory_returns_subgraph_serialization():
    """Test NodeConfig with factory survives JSON roundtrip; after resolve, produces subgraph."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        factory_file = tmp / "sg_factory_serial.py"
        factory_file.write_text(textwrap.dedent("""\
            from netrun.net.config import (
                NodeConfig, SubgraphConfig, PortConfig, ExposedPortConfig,
            )

            def get_node_config(_net_config=None):
                return SubgraphConfig(
                    name="sg",
                    nodes=[
                        NodeConfig(name="X", in_ports={"in": PortConfig()}, out_ports={"out": PortConfig()}),
                    ],
                    exposed_in_ports={"in": ExposedPortConfig(internal_node="X", internal_port="in")},
                    exposed_out_ports={"out": ExposedPortConfig(internal_node="X", internal_port="out")},
                )
        """))

        # Create NodeConfig with factory
        node = NodeConfig(name="my_sg", factory=str(factory_file))

        # JSON roundtrip
        json_str = node.model_dump_json()
        loaded = NodeConfig.model_validate_json(json_str)

        assert loaded.name == "my_sg"
        assert loaded.factory == str(factory_file)

        # Resolve produces subgraph
        _nc = NetConfig(project_root=str(tmp), graph=GraphConfig(nodes=[]))
        resolved = loaded.resolve(net_config=_nc)
        assert isinstance(resolved, SubgraphConfig)
        assert resolved.name == "my_sg"

# %%
test_factory_returns_subgraph_serialization()

# %%
#|export
def test_factory_nodes_inside_subgraph_resolved():
    """Test that factory-based NodeConfig inside an inline subgraph gets resolved."""
    import textwrap
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        factory_file = tmp / "inner_factory.py"
        factory_file.write_text(textwrap.dedent("""\
            from netrun.net.config import NodeConfig, PortConfig

            def get_node_config(_net_config=None):
                return NodeConfig(
                    name="FactoryNode",
                    in_ports={"data": PortConfig()},
                    out_ports={"result": PortConfig()},
                )
        """))

        graph = GraphConfig(
            nodes=[
                NodeConfig(name="Source", out_ports={"out": PortConfig()}),
                SubgraphConfig(
                    name="sg",
                    nodes=[
                        NodeConfig(
                            name="Worker",
                            factory=str(factory_file),
                        ),
                    ],
                    exposed_in_ports={"in": ExposedPortConfig(internal_node="Worker", internal_port="data")},
                    exposed_out_ports={"out": ExposedPortConfig(internal_node="Worker", internal_port="result")},
                ),
                NodeConfig(name="Sink", in_ports={"in": PortConfig()}),
            ],
            edges=[
                EdgeConfig(source_str="Source.out", target_str="sg.in"),
                EdgeConfig(source_str="sg.out", target_str="Sink.in"),
            ],
        )

        _nc = NetConfig(project_root=str(tmp), graph=GraphConfig(nodes=[]))
        resolved = graph.resolve(net_config=_nc)

        # The factory node inside the subgraph should have been resolved
        worker = next(n for n in resolved.nodes if n.name == "sg.Worker")
        assert "data" in worker.in_ports
        assert "result" in worker.out_ports

# %%
test_factory_nodes_inside_subgraph_resolved()

# %% [markdown]
# ## EnvVar Tests

# %%
#|export
from netrun.net.config._base import EnvVar, EnvVarResolvableModel, _cast_env_var_value, _extract_target_type
from netrun.execution_manager import RunAllocationMethod
from netrun.net.config import RemotePoolConfig, MultiprocessPoolConfig

# %%
#|export
def test_env_var_model_basics():
    """EnvVar creation, serialisation with $env alias, model_dump(by_alias=True)."""
    ev = EnvVar(env="MY_VAR")
    assert ev.env == "MY_VAR"
    assert ev.default is None

    ev2 = EnvVar(env="MY_VAR", default=42)
    assert ev2.default == 42

    dumped = ev2.model_dump(by_alias=True)
    assert dumped == {"$env": "MY_VAR", "default": 42}

    # Without by_alias
    dumped2 = ev2.model_dump()
    assert dumped2 == {"env": "MY_VAR", "default": 42}

# %%
test_env_var_model_basics()

# %%
#|export
def test_env_var_model_from_json():
    """Parsing {"$env": "VAR"} and {"$env": "VAR", "default": 42}."""
    ev = EnvVar.model_validate({"$env": "MY_VAR"})
    assert ev.env == "MY_VAR"
    assert ev.default is None

    ev2 = EnvVar.model_validate({"$env": "MY_VAR", "default": 42})
    assert ev2.env == "MY_VAR"
    assert ev2.default == 42

# %%
test_env_var_model_from_json()

# %%
#|export
def test_cast_env_var_value_scalars():
    """int, float, str, bool casting."""
    assert _cast_env_var_value("42", int) == 42
    assert _cast_env_var_value("3.14", float) == 3.14
    assert _cast_env_var_value("hello", str) == "hello"
    assert _cast_env_var_value("true", bool) is True
    assert _cast_env_var_value("false", bool) is False

# %%
test_cast_env_var_value_scalars()

# %%
#|export
def test_cast_env_var_value_bool_parsing():
    """'true'/'false'/'1'/'0'/'yes'/'no' and invalid."""
    assert _cast_env_var_value("true", bool) is True
    assert _cast_env_var_value("True", bool) is True
    assert _cast_env_var_value("TRUE", bool) is True
    assert _cast_env_var_value("1", bool) is True
    assert _cast_env_var_value("yes", bool) is True
    assert _cast_env_var_value("YES", bool) is True

    assert _cast_env_var_value("false", bool) is False
    assert _cast_env_var_value("False", bool) is False
    assert _cast_env_var_value("0", bool) is False
    assert _cast_env_var_value("no", bool) is False
    assert _cast_env_var_value("NO", bool) is False

    with pytest.raises(ValueError, match="Cannot parse"):
        _cast_env_var_value("maybe", bool)

# %%
test_cast_env_var_value_bool_parsing()

# %%
#|export
def test_cast_env_var_value_json_complex():
    """JSON parsing for lists, dicts."""
    result = _cast_env_var_value('[1, 2, 3]', list)
    assert result == [1, 2, 3]

    result = _cast_env_var_value('{"a": 1}', dict)
    assert result == {"a": 1}

# %%
test_cast_env_var_value_json_complex()

# %%
#|export
def test_cast_env_var_value_enum():
    """RunAllocationMethod enum resolution."""
    result = _cast_env_var_value("round-robin", RunAllocationMethod)
    assert result == RunAllocationMethod.ROUND_ROBIN

    result = _cast_env_var_value("random", RunAllocationMethod)
    assert result == RunAllocationMethod.RANDOM

# %%
test_cast_env_var_value_enum()

# %%
#|export
def test_resolve_env_vars_simple_field(monkeypatch):
    """ThreadPoolConfig with EnvVar in num_workers resolves from os.environ."""
    monkeypatch.setenv("NUM_WORKERS", "8")
    cfg = ThreadPoolConfig(num_workers=EnvVar(env="NUM_WORKERS"))
    resolved = cfg.resolve_env_vars()
    assert resolved.num_workers == 8
    assert resolved is not cfg

# %%
test_resolve_env_vars_simple_field()

# %%
#|export
def test_resolve_env_vars_with_default(monkeypatch):
    """EnvVar with default when env var is not set."""
    monkeypatch.delenv("MISSING_VAR", raising=False)
    cfg = ThreadPoolConfig(num_workers=EnvVar(env="MISSING_VAR", default=4))
    resolved = cfg.resolve_env_vars()
    assert resolved.num_workers == 4

# %%
test_resolve_env_vars_with_default()

# %%
#|export
def test_resolve_env_vars_missing_no_default(monkeypatch):
    """ValueError when env var missing and no default."""
    monkeypatch.delenv("MISSING_VAR", raising=False)
    cfg = ThreadPoolConfig(num_workers=EnvVar(env="MISSING_VAR"))
    with pytest.raises(ValueError, match="Environment variable 'MISSING_VAR' is not set"):
        cfg.resolve_env_vars()

# %%
test_resolve_env_vars_missing_no_default()

# %%
#|export
def test_resolve_env_vars_nested_models(monkeypatch):
    """PoolConfig containing ThreadPoolConfig with EnvVar."""
    monkeypatch.setenv("FLUSH_INTERVAL", "0.5")
    cfg = PoolConfig(
        print_flush_interval=EnvVar(env="FLUSH_INTERVAL"),
        spec=ThreadPoolConfig(num_workers=2),
    )
    resolved = cfg.resolve_env_vars()
    assert resolved.print_flush_interval == 0.5

# %%
test_resolve_env_vars_nested_models()

# %%
#|export
def test_resolve_env_vars_in_dict(monkeypatch):
    """NetConfig.node_vars with NodeVariable containing EnvVar."""
    monkeypatch.setenv("MY_SECRET", "secret_value")
    nc = NetConfig(
        graph=GraphConfig(nodes=[]),
        node_vars={
            "api_key": NodeVariable(value=EnvVar(env="MY_SECRET")),
        },
    )
    resolved = nc.resolve_env_vars()
    assert resolved.node_vars["api_key"].value == "secret_value"

# %%
test_resolve_env_vars_in_dict()

# %%
#|export
def test_resolve_env_vars_in_list(monkeypatch):
    """GraphConfig.nodes containing NodeConfig with EnvVar fields."""
    monkeypatch.setenv("NODE_MAX_EPOCHS", "10")
    graph = GraphConfig(
        nodes=[
            NodeConfig(
                name="A",
                execution_config=NodeExecutionConfig(
                    max_epochs=EnvVar(env="NODE_MAX_EPOCHS"),
                ),
            ),
        ],
    )
    resolved = graph.resolve_env_vars()
    node = resolved.nodes[0]
    assert node.execution_config.max_epochs == 10

# %%
test_resolve_env_vars_in_list()

# %%
#|export
def test_resolve_env_vars_idempotent(monkeypatch):
    """Calling resolve_env_vars twice returns same result."""
    monkeypatch.setenv("NUM_WORKERS", "4")
    cfg = ThreadPoolConfig(num_workers=EnvVar(env="NUM_WORKERS"))
    resolved1 = cfg.resolve_env_vars()
    resolved2 = resolved1.resolve_env_vars()
    assert resolved1.num_workers == resolved2.num_workers == 4
    # Second call should return self since no EnvVars remain
    assert resolved2 is resolved1

# %%
test_resolve_env_vars_idempotent()

# %%
#|export
def test_resolve_env_vars_no_envvars_returns_self():
    """No EnvVar instances -> returns self (identity)."""
    cfg = ThreadPoolConfig(num_workers=4)
    resolved = cfg.resolve_env_vars()
    assert resolved is cfg

# %%
test_resolve_env_vars_no_envvars_returns_self()

# %%
#|export
def test_netconfig_resolve_env_vars_before_imports(monkeypatch):
    """Full NetConfig.resolve() with env var in dead_letter_callback."""
    monkeypatch.setenv("DL_CALLBACK", "json.loads")
    nc = NetConfig(
        graph=GraphConfig(nodes=[]),
        dead_letter_callback=EnvVar(env="DL_CALLBACK"),
    )
    resolved = nc.resolve()
    import json as json_mod
    assert resolved.dead_letter_callback is json_mod.loads

# %%
test_netconfig_resolve_env_vars_before_imports()

# %%
#|export
def test_node_execution_config_resolve_with_env_var(monkeypatch):
    """EnvVar in exec_node_func resolves to import path string then to callable."""
    monkeypatch.setenv("EXEC_FUNC", "json.loads")
    cfg = NodeExecutionConfig(exec_node_func=EnvVar(env="EXEC_FUNC"))
    resolved = cfg.resolve()
    import json as json_mod
    assert resolved.exec_node_func is json_mod.loads

# %%
test_node_execution_config_resolve_with_env_var()

# %%
#|export
def test_env_var_json_roundtrip():
    """NetConfig with EnvVar fields -> model_dump_json -> model_validate_json -> same EnvVar."""
    nc = NetConfig(
        graph=GraphConfig(nodes=[]),
        project_root=EnvVar(env="PROJECT_ROOT"),
        type_checking_enabled=EnvVar(env="TYPE_CHECK", default=True),
    )
    json_str = nc.model_dump_json()
    restored = NetConfig.model_validate_json(json_str)
    assert isinstance(restored.project_root, EnvVar)
    assert restored.project_root.env == "PROJECT_ROOT"
    assert isinstance(restored.type_checking_enabled, EnvVar)
    assert restored.type_checking_enabled.env == "TYPE_CHECK"
    assert restored.type_checking_enabled.default is True

# %%
test_env_var_json_roundtrip()

# %%
#|export
def test_env_var_in_graph_topology_with_default(monkeypatch):
    """PortSlotSpecFiniteConfig.capacity as EnvVar with default."""
    monkeypatch.delenv("PORT_CAPACITY", raising=False)
    cfg = PortSlotSpecFiniteConfig(capacity=EnvVar(env="PORT_CAPACITY", default=10))
    resolved = cfg.resolve_env_vars()
    assert resolved.capacity == 10

    # Now set the env var and verify it takes precedence
    monkeypatch.setenv("PORT_CAPACITY", "20")
    resolved2 = cfg.resolve_env_vars()
    assert resolved2.capacity == 20

# %%
test_env_var_in_graph_topology_with_default()
