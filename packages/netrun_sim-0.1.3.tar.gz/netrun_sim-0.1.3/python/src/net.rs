use pyo3::prelude::*;
use pyo3::types::PyList;

use crate::errors::net_action_error_to_py_err;
use crate::graph::Graph;

// Re-export EpochState from core (it has pyclass)
pub use netrun_sim::net::EpochState;

use netrun_sim::graph::Edge as CoreEdge;
use netrun_sim::net::{
    Epoch as CoreEpoch, NetAction as CoreNetSimAction,
    NetActionResponse as CoreNetSimActionResponse,
    NetActionResponseData as CoreNetSimActionResponseData, NetEvent as CoreNetSimEvent,
    NetSim as CoreNetSim, OrphanedPacketInfo as CoreOrphanedPacketInfo, Packet as CorePacket,
    PacketLocation as CorePacketLocation, Salvo as CoreSalvo,
};

/// Convert Rust ULID to Python ulid.ULID
fn ulid_to_python(py: Python<'_>, ulid: &ulid::Ulid) -> PyResult<PyObject> {
    let ulid_module = py.import("ulid")?;
    let ulid_class = ulid_module.getattr("ULID")?;
    // Use from_str class method which accepts the string representation
    let from_str = ulid_class.getattr("from_str")?;
    let result = from_str.call1((ulid.to_string(),))?;
    Ok(result.unbind())
}

/// Convert Python ulid.ULID or string to Rust ULID
fn python_to_ulid(obj: &Bound<'_, PyAny>) -> PyResult<ulid::Ulid> {
    // Try to get as string first
    if let Ok(s) = obj.extract::<String>() {
        return ulid::Ulid::from_string(&s).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID string: {}", e))
        });
    }
    // Try to call str() on the object (for ulid.ULID objects)
    let s = obj.str()?.to_string();
    ulid::Ulid::from_string(&s).map_err(|e| {
        PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
    })
}

/// Where a packet is located in the network.
#[pyclass]
#[derive(Clone)]
pub struct PacketLocation {
    inner: CorePacketLocation,
}

#[pymethods]
impl PacketLocation {
    /// Create a Node location (inside an epoch).
    #[staticmethod]
    fn node(epoch_id: &Bound<'_, PyAny>) -> PyResult<Self> {
        Ok(PacketLocation {
            inner: CorePacketLocation::Node(python_to_ulid(epoch_id)?),
        })
    }

    /// Create an InputPort location.
    #[staticmethod]
    fn input_port(node_name: String, port_name: String) -> Self {
        PacketLocation {
            inner: CorePacketLocation::InputPort(node_name, port_name),
        }
    }

    /// Create an OutputPort location.
    #[staticmethod]
    fn output_port(epoch_id: &Bound<'_, PyAny>, port_name: String) -> PyResult<Self> {
        Ok(PacketLocation {
            inner: CorePacketLocation::OutputPort(python_to_ulid(epoch_id)?, port_name),
        })
    }

    /// Create an Edge location.
    #[staticmethod]
    fn edge(edge: CoreEdge) -> Self {
        // Edge is now directly the core type (re-exported from core)
        PacketLocation {
            inner: CorePacketLocation::Edge(edge),
        }
    }

    /// Create an OutsideNet location.
    #[staticmethod]
    fn outside_net() -> Self {
        PacketLocation {
            inner: CorePacketLocation::OutsideNet,
        }
    }

    /// Get the location kind.
    #[getter]
    fn kind(&self) -> String {
        match &self.inner {
            CorePacketLocation::Node(_) => "Node".to_string(),
            CorePacketLocation::InputPort(_, _) => "InputPort".to_string(),
            CorePacketLocation::OutputPort(_, _) => "OutputPort".to_string(),
            CorePacketLocation::Edge(_) => "Edge".to_string(),
            CorePacketLocation::OutsideNet => "OutsideNet".to_string(),
        }
    }

    /// Get the node name (for InputPort locations).
    #[getter]
    fn node_name(&self) -> Option<String> {
        match &self.inner {
            CorePacketLocation::InputPort(node_name, _) => Some(node_name.clone()),
            _ => None,
        }
    }

    /// Get the port name (for InputPort and OutputPort locations).
    #[getter]
    fn port_name(&self) -> Option<String> {
        match &self.inner {
            CorePacketLocation::InputPort(_, port_name) => Some(port_name.clone()),
            CorePacketLocation::OutputPort(_, port_name) => Some(port_name.clone()),
            _ => None,
        }
    }

    /// Get the epoch ID (for Node and OutputPort locations).
    #[getter]
    fn epoch_id(&self) -> Option<String> {
        match &self.inner {
            CorePacketLocation::Node(epoch_id) => Some(epoch_id.to_string()),
            CorePacketLocation::OutputPort(epoch_id, _) => Some(epoch_id.to_string()),
            _ => None,
        }
    }

    /// Get the edge (for Edge locations).
    fn get_edge(&self) -> Option<CoreEdge> {
        match &self.inner {
            CorePacketLocation::Edge(edge) => Some(edge.clone()),
            _ => None,
        }
    }

    fn __repr__(&self) -> String {
        match &self.inner {
            CorePacketLocation::Node(id) => format!("PacketLocation.node('{}')", id),
            CorePacketLocation::InputPort(node, port) => {
                format!("PacketLocation.input_port({:?}, {:?})", node, port)
            }
            CorePacketLocation::OutputPort(id, port) => {
                format!("PacketLocation.output_port('{}', {:?})", id, port)
            }
            CorePacketLocation::Edge(er) => format!("PacketLocation.edge({})", er),
            CorePacketLocation::OutsideNet => "PacketLocation.outside_net()".to_string(),
        }
    }
}

impl PacketLocation {
    pub fn to_core(&self) -> CorePacketLocation {
        self.inner.clone()
    }

    pub fn from_core(loc: &CorePacketLocation) -> Self {
        PacketLocation { inner: loc.clone() }
    }
}

// EpochState is now re-exported from core (pub use above)

/// A packet in the network.
#[pyclass]
#[derive(Clone)]
pub struct Packet {
    #[pyo3(get)]
    pub id: String, // ULID as string for simplicity
    #[pyo3(get)]
    pub location: PacketLocation,
}

#[pymethods]
impl Packet {
    fn get_id(&self, py: Python<'_>) -> PyResult<PyObject> {
        let ulid = ulid::Ulid::from_string(&self.id).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
        })?;
        ulid_to_python(py, &ulid)
    }

    fn __repr__(&self) -> String {
        format!(
            "Packet(id='{}', location={})",
            self.id,
            self.location.__repr__()
        )
    }
}

impl Packet {
    pub fn from_core(packet: &CorePacket) -> Self {
        Packet {
            id: packet.id.to_string(),
            location: PacketLocation::from_core(&packet.location),
        }
    }
}

/// A collection of packets entering or exiting a node.
#[pyclass]
#[derive(Clone)]
pub struct Salvo {
    #[pyo3(get)]
    pub salvo_condition: String,
    #[pyo3(get)]
    pub packets: Vec<(String, String)>, // (port_name, packet_id)
}

#[pymethods]
impl Salvo {
    #[new]
    fn new(salvo_condition: String, packets: Vec<(String, String)>) -> Self {
        Salvo {
            salvo_condition,
            packets,
        }
    }

    fn __repr__(&self) -> String {
        format!(
            "Salvo(salvo_condition={:?}, packets={:?})",
            self.salvo_condition, self.packets
        )
    }
}

impl Salvo {
    pub fn to_core(&self) -> CoreSalvo {
        CoreSalvo {
            salvo_condition: self.salvo_condition.clone(),
            packets: self
                .packets
                .iter()
                .map(|(port, pid)| {
                    let ulid = ulid::Ulid::from_string(pid).expect("Invalid ULID in salvo");
                    (port.clone(), ulid)
                })
                .collect(),
        }
    }

    pub fn from_core(salvo: &CoreSalvo) -> Self {
        Salvo {
            salvo_condition: salvo.salvo_condition.clone(),
            packets: salvo
                .packets
                .iter()
                .map(|(port, pid)| (port.clone(), pid.to_string()))
                .collect(),
        }
    }
}

/// Information about a packet sent to an unconnected output port.
#[pyclass]
#[derive(Clone)]
pub struct OrphanedPacketInfo {
    #[pyo3(get)]
    pub packet_id: String,
    #[pyo3(get)]
    pub from_port: String,
    #[pyo3(get)]
    pub salvo_condition: String,
}

#[pymethods]
impl OrphanedPacketInfo {
    fn __repr__(&self) -> String {
        format!(
            "OrphanedPacketInfo(packet_id='{}', from_port={:?}, salvo_condition={:?})",
            self.packet_id, self.from_port, self.salvo_condition
        )
    }
}

impl OrphanedPacketInfo {
    pub fn from_core(info: &CoreOrphanedPacketInfo) -> Self {
        OrphanedPacketInfo {
            packet_id: info.packet_id.to_string(),
            from_port: info.from_port.clone(),
            salvo_condition: info.salvo_condition.clone(),
        }
    }

    pub fn to_core(&self) -> PyResult<CoreOrphanedPacketInfo> {
        let packet_id = ulid::Ulid::from_string(&self.packet_id).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
        })?;
        Ok(CoreOrphanedPacketInfo {
            packet_id,
            from_port: self.from_port.clone(),
            salvo_condition: self.salvo_condition.clone(),
        })
    }
}

/// An execution instance of a node.
#[pyclass]
#[derive(Clone)]
pub struct Epoch {
    #[pyo3(get)]
    pub id: String,
    #[pyo3(get)]
    pub node_name: String,
    #[pyo3(get)]
    pub in_salvo: Salvo,
    #[pyo3(get)]
    pub out_salvos: Vec<Salvo>,
    #[pyo3(get)]
    pub state: EpochState,
    #[pyo3(get)]
    pub orphaned_packets: Vec<OrphanedPacketInfo>,
}

#[pymethods]
impl Epoch {
    fn get_id(&self, py: Python<'_>) -> PyResult<PyObject> {
        let ulid = ulid::Ulid::from_string(&self.id).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
        })?;
        ulid_to_python(py, &ulid)
    }

    fn start_time(&self) -> PyResult<u64> {
        let ulid = ulid::Ulid::from_string(&self.id).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
        })?;
        Ok(ulid.timestamp_ms())
    }

    fn __repr__(&self) -> String {
        let state_repr = match &self.state {
            EpochState::Startable => "EpochState.Startable",
            EpochState::Running => "EpochState.Running",
            EpochState::Finished => "EpochState.Finished",
        };
        format!(
            "Epoch(id='{}', node_name={:?}, state={})",
            self.id, self.node_name, state_repr
        )
    }
}

impl Epoch {
    pub fn from_core(epoch: &CoreEpoch) -> Self {
        Epoch {
            id: epoch.id.to_string(),
            node_name: epoch.node_name.clone(),
            in_salvo: Salvo::from_core(&epoch.in_salvo),
            out_salvos: epoch.out_salvos.iter().map(Salvo::from_core).collect(),
            // EpochState is now directly the core type (re-exported from core)
            state: epoch.state.clone(),
            orphaned_packets: epoch
                .orphaned_packets
                .iter()
                .map(OrphanedPacketInfo::from_core)
                .collect(),
        }
    }

    pub fn to_core(&self) -> PyResult<CoreEpoch> {
        let id = ulid::Ulid::from_string(&self.id).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
        })?;
        let orphaned_packets: Result<Vec<_>, _> = self
            .orphaned_packets
            .iter()
            .map(|info| info.to_core())
            .collect();
        Ok(CoreEpoch {
            id,
            node_name: self.node_name.clone(),
            in_salvo: self.in_salvo.to_core(),
            out_salvos: self.out_salvos.iter().map(|s| s.to_core()).collect(),
            state: self.state.clone(),
            orphaned_packets: orphaned_packets?,
        })
    }
}

/// An action to perform on the network.
#[pyclass]
#[derive(Clone)]
pub struct NetAction {
    inner: NetActionKind,
}

#[derive(Clone)]
enum NetActionKind {
    RunStep,
    CreatePacket(Option<String>),
    ConsumePacket(String),
    DestroyPacket(String),
    StartEpoch(String),
    FinishEpoch(String),
    CancelEpoch(String),
    CreateEpoch(String, Salvo),
    LoadPacketIntoOutputPort(String, String),
    SendOutputSalvo(String, String),
    TransportPacketToLocation(String, PacketLocation),
}

#[pymethods]
impl NetAction {
    /// Execute one step of automatic packet flow.
    /// Returns whether progress was made (i.e., not blocked).
    #[staticmethod]
    fn run_step() -> Self {
        NetAction {
            inner: NetActionKind::RunStep,
        }
    }

    /// Create a new packet, optionally inside an epoch.
    #[staticmethod]
    #[pyo3(signature = (epoch_id=None))]
    fn create_packet(epoch_id: Option<&Bound<'_, PyAny>>) -> PyResult<Self> {
        let id_str = match epoch_id {
            Some(obj) => Some(obj.str()?.to_string()),
            None => None,
        };
        Ok(NetAction {
            inner: NetActionKind::CreatePacket(id_str),
        })
    }

    /// Consume a packet (normal removal from the network).
    #[staticmethod]
    fn consume_packet(packet_id: &Bound<'_, PyAny>) -> PyResult<Self> {
        Ok(NetAction {
            inner: NetActionKind::ConsumePacket(packet_id.str()?.to_string()),
        })
    }

    /// Destroy a packet (abnormal removal, e.g., due to error or cancellation).
    #[staticmethod]
    fn destroy_packet(packet_id: &Bound<'_, PyAny>) -> PyResult<Self> {
        Ok(NetAction {
            inner: NetActionKind::DestroyPacket(packet_id.str()?.to_string()),
        })
    }

    /// Transition a startable epoch to running.
    #[staticmethod]
    fn start_epoch(epoch_id: &Bound<'_, PyAny>) -> PyResult<Self> {
        Ok(NetAction {
            inner: NetActionKind::StartEpoch(epoch_id.str()?.to_string()),
        })
    }

    /// Complete a running epoch.
    #[staticmethod]
    fn finish_epoch(epoch_id: &Bound<'_, PyAny>) -> PyResult<Self> {
        Ok(NetAction {
            inner: NetActionKind::FinishEpoch(epoch_id.str()?.to_string()),
        })
    }

    /// Cancel an epoch and destroy packets.
    #[staticmethod]
    fn cancel_epoch(epoch_id: &Bound<'_, PyAny>) -> PyResult<Self> {
        Ok(NetAction {
            inner: NetActionKind::CancelEpoch(epoch_id.str()?.to_string()),
        })
    }

    /// Manually create an epoch with specified packets.
    /// The epoch is created in Startable state - call start_epoch to begin execution.
    #[staticmethod]
    fn create_epoch(node_name: String, salvo: Salvo) -> Self {
        NetAction {
            inner: NetActionKind::CreateEpoch(node_name, salvo),
        }
    }

    /// Move a packet to an output port.
    #[staticmethod]
    fn load_packet_into_output_port(
        packet_id: &Bound<'_, PyAny>,
        port_name: String,
    ) -> PyResult<Self> {
        Ok(NetAction {
            inner: NetActionKind::LoadPacketIntoOutputPort(packet_id.str()?.to_string(), port_name),
        })
    }

    /// Send packets from output ports onto edges.
    #[staticmethod]
    fn send_output_salvo(
        epoch_id: &Bound<'_, PyAny>,
        salvo_condition_name: String,
    ) -> PyResult<Self> {
        Ok(NetAction {
            inner: NetActionKind::SendOutputSalvo(
                epoch_id.str()?.to_string(),
                salvo_condition_name,
            ),
        })
    }

    /// Transport a packet to a new location.
    #[staticmethod]
    fn transport_packet_to_location(
        packet_id: &Bound<'_, PyAny>,
        destination: PacketLocation,
    ) -> PyResult<Self> {
        Ok(NetAction {
            inner: NetActionKind::TransportPacketToLocation(
                packet_id.str()?.to_string(),
                destination,
            ),
        })
    }

    fn __repr__(&self) -> String {
        match &self.inner {
            NetActionKind::RunStep => "NetAction.run_step()".to_string(),
            NetActionKind::CreatePacket(id) => match id {
                Some(id) => format!("NetAction.create_packet('{}')", id),
                None => "NetAction.create_packet()".to_string(),
            },
            NetActionKind::ConsumePacket(id) => format!("NetAction.consume_packet('{}')", id),
            NetActionKind::DestroyPacket(id) => format!("NetAction.destroy_packet('{}')", id),
            NetActionKind::StartEpoch(id) => format!("NetAction.start_epoch('{}')", id),
            NetActionKind::FinishEpoch(id) => format!("NetAction.finish_epoch('{}')", id),
            NetActionKind::CancelEpoch(id) => format!("NetAction.cancel_epoch('{}')", id),
            NetActionKind::CreateEpoch(name, _) => {
                format!("NetAction.create_epoch({:?}, ...)", name)
            }
            NetActionKind::LoadPacketIntoOutputPort(pid, port) => {
                format!(
                    "NetAction.load_packet_into_output_port('{}', {:?})",
                    pid, port
                )
            }
            NetActionKind::SendOutputSalvo(eid, cond) => {
                format!("NetAction.send_output_salvo('{}', {:?})", eid, cond)
            }
            NetActionKind::TransportPacketToLocation(pid, loc) => {
                format!(
                    "NetAction.transport_packet_to_location('{}', {})",
                    pid,
                    loc.__repr__()
                )
            }
        }
    }
}

impl NetAction {
    pub fn to_core(&self) -> PyResult<CoreNetSimAction> {
        match &self.inner {
            NetActionKind::RunStep => Ok(CoreNetSimAction::RunStep),
            NetActionKind::CreatePacket(opt_id) => {
                let ulid_opt = match opt_id {
                    Some(s) => Some(ulid::Ulid::from_string(s).map_err(|e| {
                        PyErr::new::<pyo3::exceptions::PyValueError, _>(format!(
                            "Invalid ULID: {}",
                            e
                        ))
                    })?),
                    None => None,
                };
                Ok(CoreNetSimAction::CreatePacket(ulid_opt))
            }
            NetActionKind::ConsumePacket(id) => {
                let ulid = ulid::Ulid::from_string(id).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimAction::ConsumePacket(ulid))
            }
            NetActionKind::DestroyPacket(id) => {
                let ulid = ulid::Ulid::from_string(id).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimAction::DestroyPacket(ulid))
            }
            NetActionKind::StartEpoch(id) => {
                let ulid = ulid::Ulid::from_string(id).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimAction::StartEpoch(ulid))
            }
            NetActionKind::FinishEpoch(id) => {
                let ulid = ulid::Ulid::from_string(id).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimAction::FinishEpoch(ulid))
            }
            NetActionKind::CancelEpoch(id) => {
                let ulid = ulid::Ulid::from_string(id).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimAction::CancelEpoch(ulid))
            }
            NetActionKind::CreateEpoch(name, salvo) => {
                Ok(CoreNetSimAction::CreateEpoch(name.clone(), salvo.to_core()))
            }
            NetActionKind::LoadPacketIntoOutputPort(pid, port) => {
                let ulid = ulid::Ulid::from_string(pid).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimAction::LoadPacketIntoOutputPort(
                    ulid,
                    port.clone(),
                ))
            }
            NetActionKind::SendOutputSalvo(eid, cond) => {
                let ulid = ulid::Ulid::from_string(eid).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimAction::SendOutputSalvo(ulid, cond.clone()))
            }
            NetActionKind::TransportPacketToLocation(pid, loc) => {
                let ulid = ulid::Ulid::from_string(pid).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimAction::TransportPacketToLocation(
                    ulid,
                    loc.to_core(),
                ))
            }
        }
    }
}

/// An event that occurred during a network action.
#[pyclass]
#[derive(Clone)]
pub struct NetEvent {
    inner: NetEventKind,
}

#[derive(Clone)]
enum NetEventKind {
    PacketCreated(i128, String),
    PacketConsumed(i128, String, PacketLocation), // (ts, packet_id, location)
    PacketDestroyed(i128, String, PacketLocation), // (ts, packet_id, location)
    EpochCreated(i128, String),
    EpochStarted(i128, String),
    EpochFinished(i128, Epoch),  // (ts, epoch) - full epoch for undo
    EpochCancelled(i128, Epoch), // (ts, epoch) - full epoch for undo
    PacketMoved(i128, String, PacketLocation, PacketLocation, usize), // (ts, packet_id, from, to, from_index)
    InputSalvoTriggered(i128, String, String),
    OutputSalvoTriggered(i128, String, String),
    PacketOrphaned(i128, String, String, String, String, String), // (ts, packet_id, epoch_id, node_name, port_name, salvo_condition)
}

#[pymethods]
impl NetEvent {
    #[getter]
    fn kind(&self) -> String {
        match &self.inner {
            NetEventKind::PacketCreated(_, _) => "PacketCreated".to_string(),
            NetEventKind::PacketConsumed(_, _, _) => "PacketConsumed".to_string(),
            NetEventKind::PacketDestroyed(_, _, _) => "PacketDestroyed".to_string(),
            NetEventKind::EpochCreated(_, _) => "EpochCreated".to_string(),
            NetEventKind::EpochStarted(_, _) => "EpochStarted".to_string(),
            NetEventKind::EpochFinished(_, _) => "EpochFinished".to_string(),
            NetEventKind::EpochCancelled(_, _) => "EpochCancelled".to_string(),
            NetEventKind::PacketMoved(_, _, _, _, _) => "PacketMoved".to_string(),
            NetEventKind::InputSalvoTriggered(_, _, _) => "InputSalvoTriggered".to_string(),
            NetEventKind::OutputSalvoTriggered(_, _, _) => "OutputSalvoTriggered".to_string(),
            NetEventKind::PacketOrphaned(_, _, _, _, _, _) => "PacketOrphaned".to_string(),
        }
    }

    #[getter]
    fn timestamp(&self) -> i128 {
        match &self.inner {
            NetEventKind::PacketCreated(ts, _)
            | NetEventKind::PacketConsumed(ts, _, _)
            | NetEventKind::PacketDestroyed(ts, _, _)
            | NetEventKind::EpochCreated(ts, _)
            | NetEventKind::EpochStarted(ts, _)
            | NetEventKind::EpochFinished(ts, _)
            | NetEventKind::EpochCancelled(ts, _)
            | NetEventKind::PacketMoved(ts, _, _, _, _)
            | NetEventKind::InputSalvoTriggered(ts, _, _)
            | NetEventKind::OutputSalvoTriggered(ts, _, _)
            | NetEventKind::PacketOrphaned(ts, _, _, _, _, _) => *ts,
        }
    }

    #[getter]
    fn packet_id(&self) -> Option<String> {
        match &self.inner {
            NetEventKind::PacketCreated(_, id)
            | NetEventKind::PacketConsumed(_, id, _)
            | NetEventKind::PacketDestroyed(_, id, _)
            | NetEventKind::PacketMoved(_, id, _, _, _)
            | NetEventKind::PacketOrphaned(_, id, _, _, _, _) => Some(id.clone()),
            _ => None,
        }
    }

    #[getter]
    fn epoch_id(&self) -> Option<String> {
        match &self.inner {
            NetEventKind::EpochCreated(_, id)
            | NetEventKind::EpochStarted(_, id)
            | NetEventKind::InputSalvoTriggered(_, id, _)
            | NetEventKind::OutputSalvoTriggered(_, id, _) => Some(id.clone()),
            NetEventKind::EpochFinished(_, epoch) | NetEventKind::EpochCancelled(_, epoch) => {
                Some(epoch.id.clone())
            }
            NetEventKind::PacketOrphaned(_, _, epoch_id, _, _, _) => Some(epoch_id.clone()),
            _ => None,
        }
    }

    /// Get the epoch (for EpochFinished and EpochCancelled events).
    #[getter]
    fn epoch(&self) -> Option<Epoch> {
        match &self.inner {
            NetEventKind::EpochFinished(_, epoch) | NetEventKind::EpochCancelled(_, epoch) => {
                Some(epoch.clone())
            }
            _ => None,
        }
    }

    #[getter]
    #[allow(clippy::wrong_self_convention)]
    fn from_location(&self) -> Option<PacketLocation> {
        match &self.inner {
            NetEventKind::PacketMoved(_, _, from_loc, _, _) => Some(from_loc.clone()),
            _ => None,
        }
    }

    #[getter]
    fn to_location(&self) -> Option<PacketLocation> {
        match &self.inner {
            NetEventKind::PacketMoved(_, _, _, to_loc, _) => Some(to_loc.clone()),
            _ => None,
        }
    }

    /// Get the from_index (for PacketMoved events - used for undo).
    #[getter]
    #[allow(clippy::wrong_self_convention)]
    fn from_index(&self) -> Option<usize> {
        match &self.inner {
            NetEventKind::PacketMoved(_, _, _, _, from_index) => Some(*from_index),
            _ => None,
        }
    }

    /// Get the location (for PacketConsumed and PacketDestroyed events).
    #[getter]
    fn location(&self) -> Option<PacketLocation> {
        match &self.inner {
            NetEventKind::PacketConsumed(_, _, loc) | NetEventKind::PacketDestroyed(_, _, loc) => {
                Some(loc.clone())
            }
            _ => None,
        }
    }

    #[getter]
    fn salvo_condition(&self) -> Option<String> {
        match &self.inner {
            NetEventKind::InputSalvoTriggered(_, _, cond)
            | NetEventKind::OutputSalvoTriggered(_, _, cond)
            | NetEventKind::PacketOrphaned(_, _, _, _, _, cond) => Some(cond.clone()),
            _ => None,
        }
    }

    /// Get the node name (for PacketOrphaned events).
    #[getter]
    fn node_name(&self) -> Option<String> {
        match &self.inner {
            NetEventKind::PacketOrphaned(_, _, _, node_name, _, _) => Some(node_name.clone()),
            _ => None,
        }
    }

    /// Get the port name (for PacketOrphaned events - the output port the packet was sent from).
    #[getter]
    fn orphaned_port_name(&self) -> Option<String> {
        match &self.inner {
            NetEventKind::PacketOrphaned(_, _, _, _, port_name, _) => Some(port_name.clone()),
            _ => None,
        }
    }

    fn __repr__(&self) -> String {
        match &self.inner {
            NetEventKind::PacketCreated(ts, id) => {
                format!("NetEvent.PacketCreated(ts={}, packet_id='{}')", ts, id)
            }
            NetEventKind::PacketConsumed(ts, id, loc) => {
                format!(
                    "NetEvent.PacketConsumed(ts={}, packet_id='{}', location={})",
                    ts,
                    id,
                    loc.__repr__()
                )
            }
            NetEventKind::PacketDestroyed(ts, id, loc) => {
                format!(
                    "NetEvent.PacketDestroyed(ts={}, packet_id='{}', location={})",
                    ts,
                    id,
                    loc.__repr__()
                )
            }
            NetEventKind::EpochCreated(ts, id) => {
                format!("NetEvent.EpochCreated(ts={}, epoch_id='{}')", ts, id)
            }
            NetEventKind::EpochStarted(ts, id) => {
                format!("NetEvent.EpochStarted(ts={}, epoch_id='{}')", ts, id)
            }
            NetEventKind::EpochFinished(ts, epoch) => {
                format!(
                    "NetEvent.EpochFinished(ts={}, epoch={})",
                    ts,
                    epoch.__repr__()
                )
            }
            NetEventKind::EpochCancelled(ts, epoch) => {
                format!(
                    "NetEvent.EpochCancelled(ts={}, epoch={})",
                    ts,
                    epoch.__repr__()
                )
            }
            NetEventKind::PacketMoved(ts, id, from_loc, to_loc, from_index) => {
                format!(
                    "NetEvent.PacketMoved(ts={}, packet_id='{}', from={}, to={}, from_index={})",
                    ts,
                    id,
                    from_loc.__repr__(),
                    to_loc.__repr__(),
                    from_index
                )
            }
            NetEventKind::InputSalvoTriggered(ts, eid, cond) => {
                format!(
                    "NetEvent.InputSalvoTriggered(ts={}, epoch_id='{}', condition={:?})",
                    ts, eid, cond
                )
            }
            NetEventKind::OutputSalvoTriggered(ts, eid, cond) => {
                format!(
                    "NetEvent.OutputSalvoTriggered(ts={}, epoch_id='{}', condition={:?})",
                    ts, eid, cond
                )
            }
            NetEventKind::PacketOrphaned(ts, packet_id, epoch_id, node_name, port_name, cond) => {
                format!(
                    "NetEvent.PacketOrphaned(ts={}, packet_id='{}', epoch_id='{}', node={:?}, port={:?}, condition={:?})",
                    ts, packet_id, epoch_id, node_name, port_name, cond
                )
            }
        }
    }
}

impl NetEvent {
    pub fn from_core(event: &CoreNetSimEvent) -> Self {
        let inner = match event {
            CoreNetSimEvent::PacketCreated(ts, id) => {
                NetEventKind::PacketCreated(*ts, id.to_string())
            }
            CoreNetSimEvent::PacketConsumed(ts, id, location) => NetEventKind::PacketConsumed(
                *ts,
                id.to_string(),
                PacketLocation::from_core(location),
            ),
            CoreNetSimEvent::PacketDestroyed(ts, id, location) => NetEventKind::PacketDestroyed(
                *ts,
                id.to_string(),
                PacketLocation::from_core(location),
            ),
            CoreNetSimEvent::EpochCreated(ts, id) => {
                NetEventKind::EpochCreated(*ts, id.to_string())
            }
            CoreNetSimEvent::EpochStarted(ts, id) => {
                NetEventKind::EpochStarted(*ts, id.to_string())
            }
            CoreNetSimEvent::EpochFinished(ts, epoch) => {
                NetEventKind::EpochFinished(*ts, Epoch::from_core(epoch))
            }
            CoreNetSimEvent::EpochCancelled(ts, epoch) => {
                NetEventKind::EpochCancelled(*ts, Epoch::from_core(epoch))
            }
            CoreNetSimEvent::PacketMoved(ts, id, from_loc, to_loc, from_index) => {
                NetEventKind::PacketMoved(
                    *ts,
                    id.to_string(),
                    PacketLocation::from_core(from_loc),
                    PacketLocation::from_core(to_loc),
                    *from_index,
                )
            }
            CoreNetSimEvent::InputSalvoTriggered(ts, eid, cond) => {
                NetEventKind::InputSalvoTriggered(*ts, eid.to_string(), cond.clone())
            }
            CoreNetSimEvent::OutputSalvoTriggered(ts, eid, cond) => {
                NetEventKind::OutputSalvoTriggered(*ts, eid.to_string(), cond.clone())
            }
            CoreNetSimEvent::PacketOrphaned(
                ts,
                packet_id,
                epoch_id,
                node_name,
                port_name,
                cond,
            ) => NetEventKind::PacketOrphaned(
                *ts,
                packet_id.to_string(),
                epoch_id.to_string(),
                node_name.clone(),
                port_name.clone(),
                cond.clone(),
            ),
        };
        NetEvent { inner }
    }

    /// Convert to core NetEvent (for undo_action)
    pub fn to_core(&self) -> PyResult<CoreNetSimEvent> {
        match &self.inner {
            NetEventKind::PacketCreated(ts, id) => {
                let ulid = ulid::Ulid::from_string(id).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimEvent::PacketCreated(*ts, ulid))
            }
            NetEventKind::PacketConsumed(ts, id, loc) => {
                let ulid = ulid::Ulid::from_string(id).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimEvent::PacketConsumed(*ts, ulid, loc.to_core()))
            }
            NetEventKind::PacketDestroyed(ts, id, loc) => {
                let ulid = ulid::Ulid::from_string(id).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimEvent::PacketDestroyed(*ts, ulid, loc.to_core()))
            }
            NetEventKind::EpochCreated(ts, id) => {
                let ulid = ulid::Ulid::from_string(id).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimEvent::EpochCreated(*ts, ulid))
            }
            NetEventKind::EpochStarted(ts, id) => {
                let ulid = ulid::Ulid::from_string(id).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimEvent::EpochStarted(*ts, ulid))
            }
            NetEventKind::EpochFinished(ts, epoch) => {
                Ok(CoreNetSimEvent::EpochFinished(*ts, epoch.to_core()?))
            }
            NetEventKind::EpochCancelled(ts, epoch) => {
                Ok(CoreNetSimEvent::EpochCancelled(*ts, epoch.to_core()?))
            }
            NetEventKind::PacketMoved(ts, id, from_loc, to_loc, from_index) => {
                let ulid = ulid::Ulid::from_string(id).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimEvent::PacketMoved(
                    *ts,
                    ulid,
                    from_loc.to_core(),
                    to_loc.to_core(),
                    *from_index,
                ))
            }
            NetEventKind::InputSalvoTriggered(ts, id, cond) => {
                let ulid = ulid::Ulid::from_string(id).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimEvent::InputSalvoTriggered(
                    *ts,
                    ulid,
                    cond.clone(),
                ))
            }
            NetEventKind::OutputSalvoTriggered(ts, id, cond) => {
                let ulid = ulid::Ulid::from_string(id).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimEvent::OutputSalvoTriggered(
                    *ts,
                    ulid,
                    cond.clone(),
                ))
            }
            NetEventKind::PacketOrphaned(ts, packet_id, epoch_id, node_name, port_name, cond) => {
                let packet_ulid = ulid::Ulid::from_string(packet_id).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                let epoch_ulid = ulid::Ulid::from_string(epoch_id).map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid ULID: {}", e))
                })?;
                Ok(CoreNetSimEvent::PacketOrphaned(
                    *ts,
                    packet_ulid,
                    epoch_ulid,
                    node_name.clone(),
                    port_name.clone(),
                    cond.clone(),
                ))
            }
        }
    }
}

/// Response data from a successful action.
#[pyclass]
#[derive(Clone)]
pub enum NetActionResponseData {
    #[pyo3(constructor = (packet_id))]
    Packet { packet_id: String },
    #[pyo3(constructor = (epoch))]
    CreatedEpoch { epoch: Epoch },
    #[pyo3(constructor = (epoch))]
    StartedEpoch { epoch: Epoch },
    #[pyo3(constructor = (epoch))]
    FinishedEpoch { epoch: Epoch },
    #[pyo3(constructor = (epoch, destroyed_packets))]
    CancelledEpoch {
        epoch: Epoch,
        destroyed_packets: Vec<String>,
    },
    #[pyo3(constructor = (made_progress))]
    StepResult { made_progress: bool },
    #[pyo3(constructor = ())]
    Empty {},
}

/// The runtime state of a flow-based network.
#[pyclass]
pub struct NetSim {
    inner: CoreNetSim,
}

#[pymethods]
impl NetSim {
    #[new]
    fn new(graph: &Graph) -> Self {
        // Clone the inner graph from the Python Graph wrapper
        let core_graph = graph.inner.clone();
        NetSim {
            inner: CoreNetSim::new(core_graph),
        }
    }

    /// Perform an action on the network.
    /// Returns (response_data, events) tuple on success.
    /// Raises an exception on error.
    fn do_action(
        &mut self,
        py: Python<'_>,
        action: &NetAction,
    ) -> PyResult<(NetActionResponseData, Py<PyList>)> {
        let core_action = action.to_core()?;
        let response = self.inner.do_action(&core_action);

        match response {
            CoreNetSimActionResponse::Success(data, events) => {
                let py_data = match data {
                    CoreNetSimActionResponseData::Packet(id) => NetActionResponseData::Packet {
                        packet_id: id.to_string(),
                    },
                    CoreNetSimActionResponseData::CreatedEpoch(epoch) => {
                        NetActionResponseData::CreatedEpoch {
                            epoch: Epoch::from_core(&epoch),
                        }
                    }
                    CoreNetSimActionResponseData::StartedEpoch(epoch) => {
                        NetActionResponseData::StartedEpoch {
                            epoch: Epoch::from_core(&epoch),
                        }
                    }
                    CoreNetSimActionResponseData::FinishedEpoch(epoch) => {
                        NetActionResponseData::FinishedEpoch {
                            epoch: Epoch::from_core(&epoch),
                        }
                    }
                    CoreNetSimActionResponseData::CancelledEpoch(epoch, destroyed) => {
                        NetActionResponseData::CancelledEpoch {
                            epoch: Epoch::from_core(&epoch),
                            destroyed_packets: destroyed.iter().map(|id| id.to_string()).collect(),
                        }
                    }
                    CoreNetSimActionResponseData::StepResult { made_progress } => {
                        NetActionResponseData::StepResult { made_progress }
                    }
                    CoreNetSimActionResponseData::None => NetActionResponseData::Empty {},
                };

                let events_list = PyList::empty(py);
                for event in events {
                    events_list.append(NetEvent::from_core(&event))?;
                }

                Ok((py_data, events_list.unbind()))
            }
            CoreNetSimActionResponse::Error(err) => Err(net_action_error_to_py_err(err)),
        }
    }

    /// Check if the network is blocked (no progress can be made).
    fn is_blocked(&self) -> bool {
        self.inner.is_blocked()
    }

    /// Run the network until blocked, returning all events.
    fn run_until_blocked(&mut self, py: Python<'_>) -> PyResult<Py<PyList>> {
        let events = self.inner.run_until_blocked();
        let events_list = PyList::empty(py);
        for event in events {
            events_list.append(NetEvent::from_core(&event))?;
        }
        Ok(events_list.unbind())
    }

    /// Run one step of automatic packet flow.
    ///
    /// Convenience method equivalent to `do_action(NetAction.run_step())`.
    ///
    /// Returns:
    ///     A tuple of (made_progress, events) where made_progress indicates
    ///     whether any packets were moved.
    fn run_step(&mut self, py: Python<'_>) -> PyResult<(bool, Py<PyList>)> {
        let response = self.inner.do_action(&CoreNetSimAction::RunStep);
        match response {
            CoreNetSimActionResponse::Success(data, events) => {
                let made_progress = match data {
                    CoreNetSimActionResponseData::StepResult { made_progress } => made_progress,
                    _ => false,
                };
                let events_list = PyList::empty(py);
                for event in events {
                    events_list.append(NetEvent::from_core(&event))?;
                }
                Ok((made_progress, events_list.unbind()))
            }
            CoreNetSimActionResponse::Error(err) => Err(net_action_error_to_py_err(err)),
        }
    }

    /// Undo a previously executed action.
    ///
    /// Args:
    ///     action: The original action that was executed
    ///     events: The events that were produced by the action
    ///
    /// Raises:
    ///     UndoError: If the undo operation fails
    fn undo_action(&mut self, action: &NetAction, events: &Bound<'_, PyList>) -> PyResult<()> {
        use crate::errors::undo_error_to_py_err;

        let core_action = action.to_core()?;

        // Convert Python events list to Vec<CoreNetSimEvent>
        let mut core_events = Vec::new();
        for item in events.iter() {
            let event: NetEvent = item.extract()?;
            core_events.push(event.to_core()?);
        }

        self.inner
            .undo_action(&core_action, &core_events)
            .map_err(undo_error_to_py_err)
    }

    /// Get the number of packets at a location.
    fn packet_count_at(&self, location: &PacketLocation) -> usize {
        self.inner.packet_count_at(&location.to_core())
    }

    /// Get all packet IDs at a location.
    fn get_packets_at_location(
        &self,
        py: Python<'_>,
        location: &PacketLocation,
    ) -> PyResult<Py<PyList>> {
        let packets = self.inner.get_packets_at_location(&location.to_core());
        let list = PyList::empty(py);
        for id in packets {
            list.append(ulid_to_python(py, &id)?)?;
        }
        Ok(list.unbind())
    }

    /// Get an epoch by ID.
    fn get_epoch(&self, epoch_id: &Bound<'_, PyAny>) -> PyResult<Option<Epoch>> {
        let ulid = python_to_ulid(epoch_id)?;
        Ok(self.inner.get_epoch(&ulid).map(Epoch::from_core))
    }

    /// Get all startable epoch IDs.
    fn get_startable_epochs(&self, py: Python<'_>) -> PyResult<Py<PyList>> {
        let epochs = self.inner.get_startable_epochs();
        let list = PyList::empty(py);
        for id in epochs {
            list.append(ulid_to_python(py, &id)?)?;
        }
        Ok(list.unbind())
    }

    /// Get a packet by ID.
    fn get_packet(&self, packet_id: &Bound<'_, PyAny>) -> PyResult<Option<Packet>> {
        let ulid = python_to_ulid(packet_id)?;
        Ok(self.inner.get_packet(&ulid).map(Packet::from_core))
    }

    /// Get the underlying graph.
    #[getter]
    fn graph(&self) -> Graph {
        Graph::from_core(self.inner.graph.clone())
    }

    fn __repr__(&self) -> String {
        format!(
            "Net(graph=Graph(nodes={}, edges={}))",
            self.inner.graph.nodes().len(),
            self.inner.graph.edges().len()
        )
    }
}

pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PacketLocation>()?;
    m.add_class::<EpochState>()?;
    m.add_class::<Packet>()?;
    m.add_class::<Salvo>()?;
    m.add_class::<OrphanedPacketInfo>()?;
    m.add_class::<Epoch>()?;
    m.add_class::<NetAction>()?;
    m.add_class::<NetEvent>()?;
    m.add_class::<NetActionResponseData>()?;
    m.add_class::<NetSim>()?;
    Ok(())
}
