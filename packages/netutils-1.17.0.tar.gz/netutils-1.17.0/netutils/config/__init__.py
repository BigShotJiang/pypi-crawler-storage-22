"""Initialization file for config methods."""
