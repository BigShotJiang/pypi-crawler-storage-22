"""Expose uploader configuration models."""
