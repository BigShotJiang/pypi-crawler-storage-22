"""FastAPI application factory."""

from __future__ import annotations

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from neural_memory import __version__
from neural_memory.server.models import HealthResponse
from neural_memory.server.routes import brain_router, memory_router, sync_router
from neural_memory.storage.memory_store import InMemoryStorage

# Static files directory
STATIC_DIR = Path(__file__).parent / "static"


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan handler."""
    # Startup
    app.state.storage = InMemoryStorage()
    yield
    # Shutdown
    pass


def create_app(
    title: str = "NeuralMemory",
    description: str = "Reflex-based memory system for AI agents",
    cors_origins: list[str] | None = None,
) -> FastAPI:
    """
    Create and configure the FastAPI application.

    Args:
        title: API title
        description: API description
        cors_origins: Allowed CORS origins (default: ["*"])

    Returns:
        Configured FastAPI application
    """
    app = FastAPI(
        title=title,
        description=description,
        version=__version__,
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
    )

    # CORS middleware
    if cors_origins is None:
        cors_origins = ["*"]

    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Override storage dependency using the shared module
    from neural_memory.server.dependencies import get_storage as shared_get_storage

    async def get_storage() -> InMemoryStorage:
        return app.state.storage

    app.dependency_overrides[shared_get_storage] = get_storage

    # Include routers
    app.include_router(memory_router)
    app.include_router(brain_router)
    app.include_router(sync_router)

    # Health check endpoint
    @app.get("/health", response_model=HealthResponse, tags=["health"])
    async def health_check() -> HealthResponse:
        """Health check endpoint."""
        return HealthResponse(status="healthy", version=__version__)

    # Root endpoint
    @app.get("/", tags=["health"])
    async def root() -> dict:
        """Root endpoint with API info."""
        return {
            "name": title,
            "description": description,
            "version": __version__,
            "docs": "/docs",
            "health": "/health",
            "ui": "/ui",
        }

    # Graph visualization API
    @app.get("/api/graph", tags=["visualization"])
    async def get_graph_data() -> dict:
        """Get graph data for visualization."""
        from neural_memory.unified_config import get_shared_storage

        storage = await get_shared_storage()

        # Get all data
        neurons = await storage.find_neurons()
        synapses = await storage.get_all_synapses()
        fibers = await storage.get_fibers(limit=1000)

        stats = {
            "neuron_count": len(neurons),
            "synapse_count": len(synapses),
            "fiber_count": len(fibers),
        }

        return {
            "neurons": [
                {
                    "id": n.id,
                    "type": n.type.value,
                    "content": n.content,
                    "metadata": n.metadata,
                }
                for n in neurons
            ],
            "synapses": [
                {
                    "id": s.id,
                    "source_id": s.source_id,
                    "target_id": s.target_id,
                    "type": s.type.value,
                    "weight": s.weight,
                    "direction": s.direction.value,
                }
                for s in synapses
            ],
            "fibers": [
                {
                    "id": f.id,
                    "summary": f.summary,
                    "neuron_count": len(f.neuron_ids) if f.neuron_ids else 0,
                }
                for f in fibers
            ],
            "stats": stats,
        }

    # UI endpoint
    @app.get("/ui", tags=["visualization"])
    async def ui() -> FileResponse:
        """Serve the visualization UI."""
        return FileResponse(STATIC_DIR / "index.html")

    # Mount static files (for potential future assets)
    if STATIC_DIR.exists():
        app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    return app


# Create default app instance for uvicorn
app = create_app()
