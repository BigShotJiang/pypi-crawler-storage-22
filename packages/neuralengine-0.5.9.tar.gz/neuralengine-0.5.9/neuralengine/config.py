import numpy as np
from functools import wraps
from inspect import signature
from typing import Any, Literal, Callable, Iterator, \
ParamSpec, TypeVar, get_origin, get_args, get_type_hints

try: import cupy as cp
except ImportError:
    cp = None
    print("Cupy is not installed or no CUDA device is available. Falling back to NumPy.")


P = ParamSpec('P') # Parameter specification for type hints
R = TypeVar('R') # Return type variable for type hints

xp = np # Backend array provider. Default to NumPy
_current_device: Literal['cpu', 'cuda'] = 'cpu' # Default device
_has_cuda: bool = cp.cuda.is_available() if cp else False # CUDA availability


@(lambda cls: cls()) # Singleton instance
class DType:
    """Data types supported by NeuralEngine."""
    FLOAT = xp.floating
    FLOAT16 = xp.float16
    FLOAT32 = xp.float32
    FLOAT64 = xp.float64
    INT = xp.integer
    INT8 = xp.int8
    INT16 = xp.int16
    INT32 = xp.int32
    INT64 = xp.int64
    UINT = xp.unsignedinteger
    UINT8 = xp.uint8
    UINT16 = xp.uint16
    UINT32 = xp.uint32
    UINT64 = xp.uint64
    BOOL = xp.bool_

    def __getitem__(self, key: str) -> type:
        """Allows access to data types by key."""
        return getattr(self, key)

    def __iter__(self) -> Iterator[type]:
        """Iterator over the data types."""
        return iter(getattr(self, attr) for attr in dir(self) if attr.isupper())
    
    def __repr__(self) -> str:
        """String representation of the DType types."""
        return f"DType({', '.join(attr for attr in dir(self) if attr.isupper())})"


class Typed(type):
    """A metaclass for validating data types.
    Add `STRICT = True` in class definition to enforce strict type checking."""
    _enabled: bool = True

    def __new__(cls, name, bases, dct):
        strict = dct.get('STRICT', False)

        for attr, val in dct.items(): # Only validate public methods and properties
            if not attr.startswith('_') or attr in {'__init__', '__call__'}:
                if isinstance(val, property):
                    methods = (m and cls.validate(m, strict) for m in (val.fget, val.fset, val.fdel))
                    dct[attr] = property(*methods, doc=val.__doc__)
                elif callable(val):
                    dct[attr] = cls.validate(val, strict)
        return super().__new__(cls, name, bases, dct)
    
    @classmethod
    def validation(cls, enabled: bool) -> None:
        """Enables or disables type validation globally.

        :param enabled: If True, enables validation; if False, disables it."""
        cls._enabled = enabled
    
    @classmethod
    def validate(cls, func: Callable[P, R] = None, strict: bool = False) -> Callable[P, R]:
        """Decorator to validate function arguments based on type hints.

        :param func: The function to validate.
        :param strict: Whether to enforce strict type checking."""
        if func is None: return lambda f: cls.validate(f, strict)
        if not cls._enabled or getattr(func, '_validated', False): return func
        sig = signature(func)
        
        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            hints = get_type_hints(func)
            (bound := sig.bind(*args, **kwargs)).apply_defaults()
            for name, val in bound.arguments.items():
                param = sig.parameters[name]
                hint = hints.get(name, param.annotation)
                if hint is param.empty: continue
                # Normalize *args / **kwargs
                norm_val = val if param.kind == param.VAR_POSITIONAL else \
                    val.values() if param.kind == param.VAR_KEYWORD else (val,)    
                  
                if not all(cls._check(v, hint, strict) for v in norm_val):
                    raise TypeError(f"Argument '{name}' expected {hint}, got {type(val)}")

            result: R = func(*args, **kwargs)
            ret_hint = hints.get('return', sig.return_annotation)
            if ret_hint is not sig.empty and not cls._check(result, ret_hint, strict):
                raise TypeError(f"Return value expected {ret_hint}, got {type(result)}")
            return result
        
        wrapper._validated = True
        return wrapper

    @classmethod
    def _check(cls, val: Any, hint: type, strict: bool) -> bool:
        """Recursively checks if a value matches a type hint."""
        # Handle Any, None and Optional
        if not hint or hint is Any or (not strict and val is None): return True
        origin, args = get_origin(hint), get_args(hint)

        # Handle Special Forms
        if 'Union' in str(origin): return any(cls._check(val, a, strict) for a in args)
        if origin is Literal: return val in args

        if not strict: # Non-strict mode relaxations
            if hint is float and isinstance(val, int): return True
            if origin in (list, set, tuple) and not isinstance(val, (list, set, tuple)):
                return any(cls._check(val, a, strict) for a in args if a is not Ellipsis)

        # Basic type check
        if origin is None: return isinstance(val, hint)
        if not isinstance(val, origin): return False

        # Handle Non-Iterable Generics
        if not args or issubclass(origin, (Iterator, Callable)): return True
        if origin is type: return issubclass(val, args[0]) # Type[T] checks

        # Handle Iterable Generics
        if origin is dict:
            val = [x for pair in val.items() for x in pair] # Flatten dict items
        elif origin is tuple and not Ellipsis in args:
            if len(val) != len(args): return False # Length mismatch

        args = args[:args.index(Ellipsis)] if Ellipsis in args else args
        return all(cls._check(v, args[i % len(args)], strict) for i, v in enumerate(val))


@Typed.validate
def set_device(device: Literal['cpu', 'cuda']) -> None:
    """Sets the current device for tensor operations.

    :param device: The device to set, either 'cpu' or 'cuda'."""
    global xp, _current_device
    if device == 'cpu':
        xp = np
    elif device == 'cuda':
        if not _has_cuda:
            raise RuntimeError("Cupy is not installed or no CUDA device is available.")
        xp = cp
    _current_device = device


def get_device() -> Literal['cpu', 'cuda']:
    """Returns the current device being used for tensor operations.

    :return: The current device, either 'cpu' or 'cuda'."""
    return _current_device


def has_cuda() -> bool:
    """Checks if a CUDA device is available.

    :return: True if CUDA is available, False otherwise."""
    return _has_cuda