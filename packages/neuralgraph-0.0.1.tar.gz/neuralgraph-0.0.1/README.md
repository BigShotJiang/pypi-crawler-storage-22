# NeuralGraph

Not quite a neural network. More than a graph. A context engine for AI.

**Coming soon.** Visit [neuralgraph.app](https://neuralgraph.app) for more info.

## Installation

```bash
pip install neuralgraph
```

## Status

This package is under active development. The SDK is not functional yet.
