"""NeuralGraph — A context engine for AI."""

__version__ = "0.0.2"
