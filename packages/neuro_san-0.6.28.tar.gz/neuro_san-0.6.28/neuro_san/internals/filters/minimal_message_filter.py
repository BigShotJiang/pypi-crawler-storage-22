
# Copyright © 2023-2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT
from typing import List

from neuro_san.internals.filters.chat_context_message_filter import ChatContextMessageFilter
from neuro_san.internals.filters.compound_message_filter import CompoundMessageFilter
from neuro_san.internals.filters.message_filter import MessageFilter


class MinimalMessageFilter(CompoundMessageFilter):
    """
    A CompoundMessageFilter that lets the minimal messages needed for an agent interaction
    go through.
    """

    def __init__(self):
        """
        Constructor
        """
        filters: List[MessageFilter] = [
            ChatContextMessageFilter(),
        ]
        super().__init__(filters)
