neurologic
Dead-simple AI training. Build and train neural networks in 3 lines of Python.

Python
from neurologic import Model, Trainer

model = Model.classifier(784, [128, 64], 10)
trainer = Trainer(model)
trainer.fit(X_train, y_train, epochs=10)
Install
Bash
pip install neurologic
Quick Start
Tabular / CSV Data

Python
from neurologic import Model, Trainer, load_csv

X, y = load_csv("data.csv", target="label")

model = Model.classifier(4, [64, 32], 3)
trainer = Trainer(model)

trainer.fit(X, y, epochs=20)
trainer.save("my_model.pt")
Production Inference

For deploying to production, use the lightweight Inference class. It loads the model and handles tensor conversion automatically.

Python
from neurologic import Inference

# Load and predict in 2 lines
engine = Inference("my_model.pt")
prediction = engine.run([0.5, 1.2, 3.3])
Data Loaders
Python
from neurologic import load_csv, load_images, load_text

# CSV -> Tensors
X, y = load_csv("data.csv", target="label")

# Images -> Tensors (auto-resizes and normalizes)
images, labels = load_images("dataset/", image_size=224)

# Text -> Tokenized Tensors
X, y = load_text("reviews.csv", text_col="text", label_col="sentiment")
Advanced Training
Dynamic Learning Rate

Automatically adjust how fast the model learns based on performance.

Python
# Drops LR when improvement stops
trainer = Trainer(model, scheduler="plateau")

# Smoothly decays LR over time
trainer = Trainer(model, scheduler="cosine")
Layer Growth

Let the model architecture expand if the current size isn't enough to solve the problem.

Python
model = Model.classifier(10, [32], 3)
trainer = Trainer(model)

# Add a layer every 10 epochs if the loss plateaus
trainer.fit(X, y, epochs=50, grow_epochs=10, grow_max=3)
API Reference
Inference

Python
engine = Inference(
    model_path,          # Path to .pt file
    device=None          # "cpu", "cuda", or "mps"
)

engine.run(data)         # Returns class index (e.g., 1)
Model.load()

If you want to load a model to continue training rather than just for inference:

Python
model = Model.load("my_model.pt")
trainer = Trainer(model)
trainer.fit(X, y, epochs=5)
Model.vision()

Python
model = Model.vision(
    num_classes=2,       # Number of output categories
    backbone="resnet18", # Pretrained architecture
    pretrained=True      # Use ImageNet weights
)
Trainer.fit()

Python
trainer.fit(
    X, y,                # Tensors
    epochs=10,           # Total passes
    batch_size=32,       # Samples per step
    early_stopping=5     # Stop if no improvement for 5 epochs
)
Tips
Inference vs Trainer: Use Inference for web APIs or mobile apps; use Trainer.load if you need to keep training.

GPU: You don't need to call .to('cuda'). Everything in neurologic detects your hardware automatically.

Growing: If your loss is stuck high, try grow_epochs=5 to let the model add more "brain power" automatically.