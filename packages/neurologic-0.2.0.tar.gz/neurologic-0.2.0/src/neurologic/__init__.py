"""neurologic — Dead-simple AI training."""

from __future__ import annotations

__version__ = "0.2.0"

from neurologic.model import Model
from neurologic.trainer import Trainer
from neurologic.inference import Inference
from neurologic.data import load_csv, load_images, load_text

from dataclasses import dataclass
from typing import Any


@dataclass
class AutoResult:
    """Result returned by ``neurologic.auto()``."""
    model: Any
    trainer: Trainer
    history: dict[str, list[float]]
    metrics: dict[str, float]
    save_path: str


def auto(
    csv_path: str,
    *,
    target: str,
    features: list[str] | None = None,
    epochs: int = 20,
    validation_split: float = 0.2,
    name: str = "neurologic-auto",
) -> AutoResult:
    """One-line training from a CSV file — no torch import needed.

    Args:
        csv_path: Path to the CSV file.
        target: Name of the target/label column.
        features: Columns to use as features (default: all except target).
        epochs: Number of training epochs.
        validation_split: Fraction held out for validation + evaluation.
        name: Friendly name for the model/run.

    Returns:
        ``AutoResult`` with model, trainer, history, metrics, and save_path.

    Examples::

        from neurologic import auto

        result = auto("data.csv", target="label", epochs=20)
        print(result.metrics)
    """
    X, y = load_csv(csv_path, target=target, features=features)

    model = Model.auto(X, y, name=name)
    trainer = Trainer(model, name=name)
    history = trainer.fit(X, y, epochs=epochs, validation_split=validation_split)
    metrics = trainer.evaluate(X, y)

    save_path = f"{name}_autosave.pt"

    return AutoResult(
        model=model,
        trainer=trainer,
        history=history,
        metrics=metrics,
        save_path=save_path,
    )


__all__ = ["Model", "Trainer", "Inference", "load_csv", "load_images", "load_text", "auto", "AutoResult"]
