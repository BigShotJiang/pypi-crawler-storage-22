"""Data loaders — CSV, images, text, and corpus in one line."""

from __future__ import annotations

from collections import Counter
from pathlib import Path
from dataclasses import dataclass, field

import torch


def load_csv(
    path: str | Path,
    target: str,
    features: list[str] | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Load a CSV file and return (X, y) tensors.

    Args:
        path: Path to the CSV file.
        target: Name of the target/label column.
        features: Columns to use as features (default: all except target).

    Returns:
        Tuple of (X, y) as float tensors.
    """
    import pandas as pd

    df = pd.read_csv(path)
    y = torch.tensor(df[target].values, dtype=torch.long)

    if features:
        X = torch.tensor(df[features].values, dtype=torch.float32)
    else:
        X = torch.tensor(df.drop(columns=[target]).values, dtype=torch.float32)

    return X, y


def load_images(
    directory: str | Path,
    image_size: int = 224,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Load images from a directory organized by class folders.

    Expected structure::

        directory/
            class_a/
                img1.jpg
                img2.jpg
            class_b/
                img3.jpg

    Args:
        directory: Root directory with class subfolders.
        image_size: Resize images to this square size.

    Returns:
        Tuple of (images, labels) tensors.
    """
    from torchvision import transforms
    from torchvision.datasets import ImageFolder

    transform = transforms.Compose([
        transforms.Resize((image_size, image_size)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])

    dataset = ImageFolder(str(directory), transform=transform)
    images = torch.stack([img for img, _ in dataset])
    labels = torch.tensor([label for _, label in dataset])
    return images, labels


def load_text(
    path: str | Path,
    text_col: str,
    label_col: str,
    vocab_size: int = 10000,
    max_len: int = 256,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Load text data from a CSV and return tokenized (X, y) tensors.

    Uses a simple whitespace tokenizer with the most frequent words.

    Args:
        path: Path to the CSV file.
        text_col: Name of the text column.
        label_col: Name of the label column.
        vocab_size: Max vocabulary size.
        max_len: Pad/truncate sequences to this length.

    Returns:
        Tuple of (token_ids, labels) tensors.
    """
    import pandas as pd

    df = pd.read_csv(path)
    texts = df[text_col].astype(str).tolist()
    labels = torch.tensor(df[label_col].values, dtype=torch.long)

    # Build vocabulary from most common words
    word_counts: Counter[str] = Counter()
    for text in texts:
        word_counts.update(text.lower().split())

    vocab = {word: i + 1 for i, (word, _) in enumerate(word_counts.most_common(vocab_size - 1))}
    # 0 is reserved for padding

    # Tokenize and pad
    sequences = []
    for text in texts:
        tokens = [vocab.get(w, 0) for w in text.lower().split()]
        if len(tokens) >= max_len:
            tokens = tokens[:max_len]
        else:
            tokens = tokens + [0] * (max_len - len(tokens))
        sequences.append(tokens)

    X = torch.tensor(sequences, dtype=torch.long)
    return X, labels


@dataclass
class Vocabulary:
    """Token ↔ ID mapping built by ``load_corpus``."""
    word2idx: dict[str, int] = field(default_factory=dict)
    idx2word: dict[int, str] = field(default_factory=dict)

    @property
    def size(self) -> int:
        return len(self.word2idx)

    def encode(self, text: str) -> list[int]:
        """Convert text to token IDs."""
        return [self.word2idx.get(w, 0) for w in text.lower().split()]

    def decode(self, ids: list[int]) -> str:
        """Convert token IDs back to text."""
        return " ".join(self.idx2word.get(i, "<unk>") for i in ids if i != 0)


def load_corpus(
    source: str | Path,
    *,
    seq_len: int = 32,
    vocab_size: int = 10000,
    from_file: bool = True,
) -> tuple[torch.Tensor, torch.Tensor, Vocabulary]:
    """Load raw text and prepare (X, y) sequences for next-word prediction.

    Creates overlapping sequences where X = tokens[i:i+seq_len] and
    y = tokens[i+1:i+seq_len+1] (shifted by one).

    Args:
        source: Path to a text file, or a raw string if ``from_file=False``.
        seq_len: Length of each training sequence.
        vocab_size: Maximum vocabulary size (most frequent words kept).
        from_file: If True, ``source`` is a file path. If False, it's raw text.

    Returns:
        Tuple of (X, y, vocab) where X and y are long tensors of shape
        (num_sequences, seq_len), and vocab is a ``Vocabulary`` for
        encoding/decoding.

    Examples::

        X, y, vocab = load_corpus("corpus.txt", seq_len=32)
        X, y, vocab = load_corpus("hello world ...", from_file=False)
    """
    if from_file:
        text = Path(source).read_text(encoding="utf-8")
    else:
        text = str(source)

    words = text.lower().split()
    if len(words) < seq_len + 1:
        raise ValueError(
            f"Corpus too small ({len(words)} words) for seq_len={seq_len}. "
            f"Need at least {seq_len + 1} words."
        )

    # Build vocabulary from most frequent words
    word_counts: Counter[str] = Counter(words)
    # Reserve 0 = pad, 1 = <unk>
    vocab_words = [w for w, _ in word_counts.most_common(vocab_size - 2)]
    word2idx: dict[str, int] = {"<pad>": 0, "<unk>": 1}
    for i, w in enumerate(vocab_words):
        word2idx[w] = i + 2
    idx2word = {i: w for w, i in word2idx.items()}

    vocab = Vocabulary(word2idx=word2idx, idx2word=idx2word)

    # Convert all words to IDs
    token_ids = [word2idx.get(w, 1) for w in words]

    # Create overlapping sequences
    sequences_x = []
    sequences_y = []
    for i in range(len(token_ids) - seq_len):
        sequences_x.append(token_ids[i : i + seq_len])
        sequences_y.append(token_ids[i + 1 : i + seq_len + 1])

    X = torch.tensor(sequences_x, dtype=torch.long)
    y = torch.tensor(sequences_y, dtype=torch.long)

    print(f"Corpus: {len(words)} words, vocab={vocab.size}, sequences={len(X)}")
    return X, y, vocab
