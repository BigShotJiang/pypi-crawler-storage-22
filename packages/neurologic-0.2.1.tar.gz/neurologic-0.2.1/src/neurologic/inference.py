"""Inference — load a saved model and run predictions without training code."""

from __future__ import annotations

from pathlib import Path

import torch
import torch.nn.functional as F

from neurologic.trainer import _best_device, _to_tensor


class Inference:
    """Load a saved NeuroLogic checkpoint and run predictions.

    Handles MPS/CUDA/CPU auto-detection, proper checkpoint unwrapping,
    and automatic task detection.

    Examples::

        engine = Inference("model.pt")
        prediction = engine.run([1.0, 2.0, 3.0])
        batch = engine.run([[1, 2, 3], [4, 5, 6]])
    """

    def __init__(self, model_path: str | Path, *, device: str | None = None):
        self.device = torch.device(device) if device else _best_device()
        checkpoint = torch.load(model_path, map_location=self.device, weights_only=False)

        # Unwrap from Trainer's save format
        if isinstance(checkpoint, dict) and "model" in checkpoint:
            self.model = checkpoint["model"]
        else:
            self.model = checkpoint

        self.model.to(self.device)
        self.model.eval()

        # Auto-detect task from saved model
        self._task = getattr(self.model, "_task", "regression")

    def run(self, data: object) -> list[float] | int:
        """Run inference on input data.

        Args:
            data: Input data — list, nested list, numpy array, pandas object, or tensor.

        Returns:
            For classification: predicted class index (single) or list of indices (batch).
            For regression: list of predicted values.
        """
        tensor = _to_tensor(data)
        if tensor.dim() == 1:
            tensor = tensor.unsqueeze(0)
        tensor = tensor.to(self.device, dtype=torch.float32)

        with torch.no_grad():
            raw_output = self.model(tensor)

            if self._task == "classification":
                preds = torch.argmax(raw_output, dim=1)
                result = preds.cpu().tolist()
                return result[0] if len(result) == 1 else result

            result = raw_output.cpu().view(-1).tolist()
            return result[0] if len(result) == 1 else result

    def generate(
        self,
        prompt_ids: list[int],
        max_tokens: int = 50,
        temperature: float = 0.8,
        top_k: int = 40,
    ) -> list[int]:
        """Generate tokens autoregressively (for text generation models).

        Args:
            prompt_ids: Starting token IDs (from ``Vocabulary.encode``).
            max_tokens: Maximum number of tokens to generate.
            temperature: Sampling temperature (lower = more deterministic).
            top_k: Only sample from the top-k most probable tokens.

        Returns:
            List of generated token IDs (including the prompt).
        """
        tokens = list(prompt_ids)
        input_ids = torch.tensor([tokens], dtype=torch.long, device=self.device)
        hidden = None

        with torch.no_grad():
            for _ in range(max_tokens):
                output = self.model(input_ids, hidden)
                if isinstance(output, tuple):
                    logits, hidden = output
                else:
                    logits = output

                # Take logits for the last token
                next_logits = logits[:, -1, :] / max(temperature, 1e-8)

                # Top-k filtering
                if top_k > 0:
                    k = min(top_k, next_logits.size(-1))
                    top_vals, _ = torch.topk(next_logits, k)
                    threshold = top_vals[:, -1].unsqueeze(-1)
                    next_logits[next_logits < threshold] = float('-inf')

                probs = F.softmax(next_logits, dim=-1)
                next_token = torch.multinomial(probs, 1)

                tokens.append(next_token.item())
                # Feed only the new token (use hidden state for context)
                input_ids = next_token

        return tokens
