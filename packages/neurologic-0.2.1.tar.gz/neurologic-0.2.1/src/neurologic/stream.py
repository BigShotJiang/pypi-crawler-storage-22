from __future__ import annotations

import torch
import torch.nn as nn
from collections import deque
from typing import Optional, Tuple
import numpy as np


class StreamBuffer:
    def __init__(self, max_size: int = 1000):
        self.max_size = max_size
        self.buffer = deque(maxlen=max_size)
        self.stats = {"mean": 0.0, "std": 1.0, "min": 0.0, "max": 1.0}

    def add(self, value: float | np.ndarray):
        if isinstance(value, np.ndarray):
            for v in value.flatten():
                self.buffer.append(float(v))
        else:
            self.buffer.append(float(value))
        self._update_stats()

    def _update_stats(self):
        if len(self.buffer) == 0:
            return
        arr = np.array(list(self.buffer))
        self.stats["mean"] = float(np.mean(arr))
        self.stats["std"] = float(np.std(arr)) if len(arr) > 1 else 1.0
        self.stats["min"] = float(np.min(arr))
        self.stats["max"] = float(np.max(arr))

    def normalize(self, value: float) -> float:
        if self.stats["std"] < 1e-6:
            return 0.0
        return (value - self.stats["mean"]) / (self.stats["std"] + 1e-8)

    def get_state(self) -> torch.Tensor:
        if len(self.buffer) == 0:
            return torch.zeros(1)
        arr = np.array(list(self.buffer))
        normalized = (arr - self.stats["mean"]) / (self.stats["std"] + 1e-8)
        return torch.tensor(normalized[-100:], dtype=torch.float32)


class StreamCell(nn.Module):
    def __init__(self, input_size: int, hidden_size: int, num_layers: int = 1):
        super().__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers

        self.layers = nn.ModuleList()
        self.forget_gates = nn.ModuleList()
        self.update_gates = nn.ModuleList()
        self.output_gates = nn.ModuleList()

        for i in range(num_layers):
            in_size = input_size if i == 0 else hidden_size

            self.layers.append(nn.Linear(in_size + hidden_size, hidden_size * 4))
            self.forget_gates.append(nn.Linear(hidden_size, hidden_size))
            self.update_gates.append(nn.Linear(hidden_size, hidden_size))
            self.output_gates.append(nn.Linear(hidden_size, hidden_size))

    def forward(
        self,
        x: torch.Tensor,
        h: torch.Tensor,
        c: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        batch_size = x.size(0)

        for layer_idx in range(self.num_layers):
            layer = self.layers[layer_idx]
            forget_gate = self.forget_gates[layer_idx]
            update_gate = self.update_gates[layer_idx]
            output_gate = self.output_gates[layer_idx]

            combined = torch.cat([x, h[:, layer_idx:layer_idx+1, :]], dim=-1)
            gates = layer(combined)
            i, f, g, o = torch.chunk(gates, 4, dim=-1)

            f_val = torch.sigmoid(f + forget_gate(h[:, layer_idx:layer_idx+1, :]))
            i_val = torch.sigmoid(i)
            g_val = torch.tanh(g)
            o_val = torch.sigmoid(o + output_gate(h[:, layer_idx:layer_idx+1, :]))

            c_new = f_val * c[:, layer_idx:layer_idx+1, :] + i_val * g_val
            h_new = o_val * torch.tanh(c_new)

            h = torch.cat([h[:, :layer_idx, :], h_new, h[:, layer_idx+1:, :]], dim=1) if layer_idx < self.num_layers - 1 else h_new
            c = torch.cat([c[:, :layer_idx, :], c_new, c[:, layer_idx+1:, :]], dim=1) if layer_idx < self.num_layers - 1 else c_new
            x = h_new

        return x, h, c


class StreamAttention(nn.Module):
    def __init__(self, hidden_size: int, num_heads: int = 4):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads

        assert hidden_size % num_heads == 0

        self.query = nn.Linear(hidden_size, hidden_size)
        self.key = nn.Linear(hidden_size, hidden_size)
        self.value = nn.Linear(hidden_size, hidden_size)
        self.fc_out = nn.Linear(hidden_size, hidden_size)

    def forward(self, query: torch.Tensor, key: torch.Tensor, value: torch.Tensor) -> torch.Tensor:
        batch_size = query.shape[0]

        Q = self.query(query)
        K = self.key(key)
        V = self.value(value)

        Q = Q.view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        K = K.view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        V = V.view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)

        scores = torch.matmul(Q, K.transpose(-2, -1)) / (self.head_dim ** 0.5)
        attn_weights = torch.softmax(scores, dim=-1)
        context = torch.matmul(attn_weights, V)

        context = context.transpose(1, 2).contiguous().view(batch_size, -1, self.hidden_size)
        output = self.fc_out(context)

        return output


class StreamLayer(nn.Module):
    def __init__(self, input_size: int, hidden_size: int, num_heads: int = 4, dropout: float = 0.1):
        super().__init__()
        self.stream_cell = StreamCell(input_size, hidden_size)
        self.attention = StreamAttention(hidden_size, num_heads)
        self.norm1 = nn.LayerNorm(hidden_size)
        self.norm2 = nn.LayerNorm(hidden_size)
        self.dropout = nn.Dropout(dropout)
        self.feed_forward = nn.Sequential(
            nn.Linear(hidden_size, hidden_size * 4),
            nn.ReLU(),
            nn.Linear(hidden_size * 4, hidden_size),
            nn.Dropout(dropout),
        )

    def forward(
        self,
        x: torch.Tensor,
        h: torch.Tensor,
        c: torch.Tensor,
        key_buffer: Optional[torch.Tensor] = None,
        value_buffer: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        batch_size = x.size(0)
        x_expanded = x.unsqueeze(1) if x.dim() == 2 else x

        cell_out, h, c = self.stream_cell(x_expanded, h, c)

        if key_buffer is None:
            key_buffer = cell_out
            value_buffer = cell_out
        else:
            key_buffer = torch.cat([key_buffer, cell_out], dim=1)[:, -100:, :]
            value_buffer = torch.cat([value_buffer, cell_out], dim=1)[:, -100:, :]

        attn_out = self.attention(cell_out, key_buffer, value_buffer)
        attn_out = self.dropout(attn_out)

        out = self.norm1(cell_out + attn_out)
        ff_out = self.feed_forward(out)
        out = self.norm2(out + ff_out)

        return out.squeeze(1) if out.size(1) == 1 else out, h, c, key_buffer, value_buffer


class StreamStack(nn.Module):
    def __init__(
        self,
        input_size: int,
        hidden_size: int = 128,
        num_layers: int = 2,
        num_heads: int = 4,
        output_size: int = 1,
        dropout: float = 0.1,
        name: str = "stream-stack",
    ):
        super().__init__()
        self.name = name
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.output_size = output_size
        self._task = "streaming"

        self.embedding = nn.Linear(input_size, hidden_size) if input_size != hidden_size else nn.Identity()
        self.stream_layers = nn.ModuleList([
            StreamLayer(hidden_size if i > 0 else hidden_size, hidden_size, num_heads, dropout)
            for i in range(num_layers)
        ])
        self.output_layer = nn.Linear(hidden_size, output_size)
        self.buffer = StreamBuffer(max_size=1000)

    def init_state(self, batch_size: int, device: torch.device) -> Tuple[torch.Tensor, torch.Tensor]:
        h = torch.zeros(batch_size, self.num_layers, self.hidden_size, device=device)
        c = torch.zeros(batch_size, self.num_layers, self.hidden_size, device=device)
        return h, c

    def forward(
        self,
        x: torch.Tensor,
        state: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        buffers: Optional[list] = None,
    ) -> Tuple[torch.Tensor, Tuple[torch.Tensor, torch.Tensor], list]:
        batch_size = x.size(0)
        device = x.device

        if state is None:
            h, c = self.init_state(batch_size, device)
        else:
            h, c = state

        if buffers is None:
            buffers = [(None, None) for _ in range(self.num_layers)]

        x = self.embedding(x)

        for layer_idx, stream_layer in enumerate(self.stream_layers):
            key_buf, val_buf = buffers[layer_idx]
            x, h_new, c_new, key_buf, val_buf = stream_layer(
                x, h[:, layer_idx:layer_idx+1, :], c[:, layer_idx:layer_idx+1, :],
                key_buf, val_buf
            )
            h = torch.cat([h[:, :layer_idx, :], h_new, h[:, layer_idx+1:, :]], dim=1)
            c = torch.cat([c[:, :layer_idx, :], c_new, c[:, layer_idx+1:, :]], dim=1)
            buffers[layer_idx] = (key_buf, val_buf)

        output = self.output_layer(x)

        return output, (h, c), buffers

    def stream_forward(self, x: float | np.ndarray) -> float:
        self.buffer.add(x)
        normalized = self.buffer.normalize(x) if isinstance(x, float) else x

        tensor = torch.tensor([[normalized]], dtype=torch.float32)

        if not hasattr(self, '_stream_state'):
            self._stream_state = None
            self._stream_buffers = None

        with torch.no_grad():
            output, self._stream_state, self._stream_buffers = self.forward(
                tensor, self._stream_state, self._stream_buffers
            )

        return float(output[0, 0].cpu())

    def reset(self):
        self._stream_state = None
        self._stream_buffers = None
        self.buffer = StreamBuffer(max_size=1000)

    def __repr__(self) -> str:
        params = sum(p.numel() for p in self.parameters())
        return f"{self.name} (StreamStack, {self.num_layers} layers, {params:,} params)"
