"""Trainer — fit, evaluate, predict, save, load in one line each."""

from __future__ import annotations

from pathlib import Path

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset, random_split
from tqdm import tqdm

import numpy as np


def _best_device() -> torch.device:
    if torch.cuda.is_available():
        return torch.device("cuda")
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def _to_tensor(data: object) -> torch.Tensor:
    """Convert lists, numpy arrays, pandas objects, or tensors to torch.Tensor.

    Auto-detects dtype: integer data → torch.long, float data → torch.float32.
    """
    if isinstance(data, torch.Tensor):
        return data

    # Pandas DataFrame / Series → numpy first
    try:
        import pandas as pd
        if isinstance(data, (pd.DataFrame, pd.Series)):
            data = data.values
    except ImportError:
        pass

    arr = np.asarray(data)
    if np.issubdtype(arr.dtype, np.integer):
        return torch.tensor(arr, dtype=torch.long)
    return torch.tensor(arr, dtype=torch.float32)


class Trainer:
    """Train any ``nn.Module`` with minimal boilerplate.

    Examples::

        trainer = Trainer(model)
        trainer.fit(X_train, y_train, epochs=10)
        metrics = trainer.evaluate(X_test, y_test)
        trainer.save("model.pt")

        # Dynamic LR + layer growth
        trainer = Trainer(model, scheduler="plateau")
        trainer.fit(X, y, epochs=50, grow_epochs=10)
    """

    def __init__(
        self,
        model: nn.Module,
        *,
        lr: float | None = None,
        optimizer: str = "adam",
        loss: nn.Module | None = None,
        device: torch.device | str | None = None,
        scheduler: str | None = "plateau",
        early_stopping: int = 5,
        name: str | None = None,
    ):
        """
        Args:
            model: Any ``nn.Module`` (use ``Model.*`` factories or bring your own).
            lr: Learning rate (auto-picked if None: 1e-3 for Adam/AdamW, 1e-2 for SGD).
            optimizer: One of "adam", "sgd", "adamw".
            loss: Custom loss function (auto-detected if None).
            device: Force a device ("cpu", "cuda", "mps") or auto-detect.
            scheduler: LR scheduler — "plateau" (default), "cosine", "warmup_cosine", "step", or None.
            early_stopping: Stop if val_loss doesn't improve for N epochs (default 5, 0 = off).
            name: Friendly name for this training run.
        """
        self.device = torch.device(device) if device else _best_device()
        self.model = model.to(self.device)
        self.name = name or getattr(model, "name", "neurologic")
        self._task = getattr(model, "_task", "classification")
        self._optimizer_name = optimizer
        self._scheduler_type = scheduler
        self._default_early_stopping = early_stopping

        # Smart LR: pick based on optimizer if not specified
        if lr is None:
            lr = 1e-2 if optimizer == "sgd" else 1e-3
        self._lr = lr

        optim_cls = {"adam": torch.optim.Adam, "sgd": torch.optim.SGD, "adamw": torch.optim.AdamW}
        self._optim_cls = optim_cls[optimizer]
        self.optimizer = self._optim_cls(self.model.parameters(), lr=lr)
        self._scheduler: torch.optim.lr_scheduler.LRScheduler | None = None

        if loss is not None:
            self.loss_fn = loss
        elif self._task == "regression":
            self.loss_fn = nn.MSELoss()
        elif self._task == "generation":
            self.loss_fn = nn.CrossEntropyLoss(ignore_index=0)
        else:
            self.loss_fn = nn.CrossEntropyLoss()

    @property
    def lr(self) -> float:
        """Current learning rate."""
        return self.optimizer.param_groups[0]["lr"]

    def summary(self) -> str:
        """Print a readable summary of the model."""
        total = sum(p.numel() for p in self.model.parameters())
        trainable = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        lines = [
            f"  Name:       {self.name}",
            f"  Model:      {self.model.__class__.__name__}",
            f"  Task:       {self._task}",
            f"  Device:     {self.device}",
            f"  Parameters: {trainable:,} trainable / {total:,} total",
            f"  Optimizer:  {self.optimizer.__class__.__name__} (lr={self._lr})",
            f"  Loss:       {self.loss_fn.__class__.__name__}",
            f"  Scheduler:  {self._scheduler_type or 'none'}",
        ]
        text = "\n".join(lines)
        print(text)
        return text

    # ------------------------------------------------------------------
    # Training
    # ------------------------------------------------------------------

    @staticmethod
    def _auto_batch_size(n: int) -> int:
        """Pick batch size from dataset size."""
        if n <= 256:
            return 16
        if n <= 4096:
            return 32
        return 64

    def fit(
        self,
        X: object,
        y: object,
        *,
        epochs: int = 10,
        batch_size: int | None = None,
        validation_split: float = 0.1,
        early_stopping: int | None = None,
        grow_epochs: int = 0,
        grow_size: int | None = None,
        grow_max: int = 5,
    ) -> dict[str, list[float]]:
        """Train the model.

        Args:
            X: Input data (tensor, list, numpy array, or DataFrame).
            y: Target data (tensor, list, numpy array, or Series).
            epochs: Number of training epochs.
            batch_size: Mini-batch size (auto-picked if None).
            validation_split: Fraction held out for validation (0 to disable).
            early_stopping: Stop if val_loss doesn't improve for N epochs (None = use trainer default, 0 = off).
            grow_epochs: Add a layer every N epochs if loss plateaus (0 = off).
                         Only works with ``Model.classifier`` models.
            grow_size: Width of grown layers (None = match previous layer).
            grow_max: Maximum number of layers to grow.

        Returns:
            Dict with ``"train_loss"``, ``"val_loss"``, and ``"lr"`` lists per epoch.
        """
        X = _to_tensor(X)
        y = _to_tensor(y)

        # Auto batch size
        if batch_size is None:
            batch_size = self._auto_batch_size(len(X))

        # Use trainer default if not overridden
        if early_stopping is None:
            early_stopping = self._default_early_stopping

        dataset = TensorDataset(X, y)

        if validation_split > 0:
            val_size = max(1, int(len(dataset) * validation_split))
            train_size = len(dataset) - val_size
            train_ds, val_ds = random_split(dataset, [train_size, val_size])
        else:
            train_ds = dataset
            val_ds = None

        train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_ds, batch_size=batch_size) if val_ds else None

        # Set up LR scheduler
        self._scheduler = self._make_scheduler(epochs)

        history: dict[str, list[float]] = {"train_loss": [], "val_loss": [], "lr": []}
        best_val_loss = float("inf")
        patience_counter = 0
        grow_count = 0
        last_grow_loss = float("inf")

        print(f"Training '{self.name}' on {self.device} — {len(train_ds)} train samples")

        for epoch in range(1, epochs + 1):
            # Train
            self.model.train()
            running_loss = 0.0
            pbar = tqdm(train_loader, desc=f"Epoch {epoch}/{epochs}", leave=False)
            for xb, yb in pbar:
                xb, yb = xb.to(self.device), yb.to(self.device)
                self.optimizer.zero_grad()
                out = self.model(xb)
                # Generation models return (logits, hidden)
                if isinstance(out, tuple):
                    out = out[0]
                loss = self._compute_batch_loss(out, yb)
                loss.backward()
                # Gradient clipping for generation stability
                if self._task == "generation":
                    nn.utils.clip_grad_norm_(self.model.parameters(), 5.0)
                self.optimizer.step()
                running_loss += loss.item() * xb.size(0)
                pbar.set_postfix(loss=f"{loss.item():.4f}")

            train_loss = running_loss / len(train_ds)
            history["train_loss"].append(train_loss)
            history["lr"].append(self.lr)

            # Validate
            if val_loader:
                val_loss = self._compute_loss(val_loader)
                history["val_loss"].append(val_loss)

                if hasattr(self.model, "should_replicate") and self.model.should_replicate(val_loss):
                    replica = self.model.spawn_replica()
                    replica.to(self.device)
                    print(f"  >> Spawned replica #{len(self.model.replicas)} (val_loss={val_loss:.4f})")

                lr_str = f"  lr={self.lr:.6f}" if self._scheduler_type else ""
                print(f"  Epoch {epoch}/{epochs}  train_loss={train_loss:.4f}  val_loss={val_loss:.4f}{lr_str}")

                # Step scheduler
                if isinstance(self._scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                    self._scheduler.step(val_loss)
                elif self._scheduler:
                    self._scheduler.step()

                # Early stopping
                if early_stopping > 0:
                    if val_loss < best_val_loss:
                        best_val_loss = val_loss
                        patience_counter = 0
                    else:
                        patience_counter += 1
                        if patience_counter >= early_stopping:
                            print(f"  Early stopping at epoch {epoch} (no improvement for {early_stopping} epochs)")
                            break

                # Layer growth
                metric_for_grow = val_loss
            else:
                lr_str = f"  lr={self.lr:.6f}" if self._scheduler_type else ""
                print(f"  Epoch {epoch}/{epochs}  train_loss={train_loss:.4f}{lr_str}")

                if self._scheduler and not isinstance(self._scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                    self._scheduler.step()

                metric_for_grow = train_loss

            # Layer growth check
            if grow_epochs > 0 and epoch % grow_epochs == 0 and grow_count < grow_max:
                if hasattr(self.model, "grow") and metric_for_grow >= last_grow_loss * 0.95:
                    size = self.model.grow(grow_size)
                    self.model = self.model.to(self.device)
                    # Rebuild optimizer to pick up new parameters
                    self.optimizer = self._optim_cls(self.model.parameters(), lr=self.lr)
                    self._scheduler = self._make_scheduler(epochs - epoch)
                    grow_count += 1
                    print(f"  >> Grew layer #{grow_count} (size={size}), model now: {self.model}")
                last_grow_loss = metric_for_grow

        print(f"Done. Final train_loss={history['train_loss'][-1]:.4f}")

        # Auto-save
        save_path = f"{self.name}_autosave.pt"
        self.save(save_path)

        return history

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------

    def evaluate(self, X: object, y: object, *, batch_size: int = 32) -> dict[str, float]:
        """Evaluate the model and return metrics.

        Returns dict with ``"loss"`` and, for classification, ``"accuracy"``.
        """
        X = _to_tensor(X)
        y = _to_tensor(y)
        loader = DataLoader(TensorDataset(X, y), batch_size=batch_size)

        loss = self._compute_loss(loader)
        metrics: dict[str, float] = {"loss": loss}

        if self._task == "classification":
            metrics["accuracy"] = self._compute_accuracy(loader)

        return metrics

    # ------------------------------------------------------------------
    # Prediction
    # ------------------------------------------------------------------

    def predict(self, X: object, *, batch_size: int = 32) -> torch.Tensor:
        """Run inference and return predictions."""
        X = _to_tensor(X)
        self.model.eval()
        preds = []
        loader = DataLoader(TensorDataset(X), batch_size=batch_size)
        with torch.no_grad():
            for (xb,) in loader:
                out = self.model(xb.to(self.device))
                if isinstance(out, tuple):
                    out = out[0]
                if self._task == "generation":
                    # Return the last token's prediction for each sequence
                    out = out[:, -1, :].argmax(dim=1)
                elif self._task == "classification":
                    out = out.argmax(dim=1)
                preds.append(out.cpu())
        return torch.cat(preds)

    # ------------------------------------------------------------------
    # Save / Load
    # ------------------------------------------------------------------

    def save(self, path: str | Path) -> None:
        """Save model + optimizer state."""
        torch.save(
            {
                "model_state": self.model.state_dict(),
                "optimizer_state": self.optimizer.state_dict(),
                "model": self.model,
                "name": self.name,
            },
            path,
        )
        print(f"Saved '{self.name}' to {path}")

    @classmethod
    def load(cls, path: str | Path, *, device: str | None = None) -> "Trainer":
        """Load a saved trainer."""
        checkpoint = torch.load(path, map_location=device or _best_device(), weights_only=False)
        model = checkpoint["model"]
        trainer = cls(model, device=device, name=checkpoint.get("name"))
        trainer.model.load_state_dict(checkpoint["model_state"])
        trainer.optimizer.load_state_dict(checkpoint["optimizer_state"])
        return trainer

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _make_scheduler(self, epochs: int) -> torch.optim.lr_scheduler.LRScheduler | None:
        if self._scheduler_type == "plateau":
            return torch.optim.lr_scheduler.ReduceLROnPlateau(
                self.optimizer, mode="min", factor=0.5, patience=3,
            )
        if self._scheduler_type == "step":
            return torch.optim.lr_scheduler.StepLR(self.optimizer, step_size=max(1, epochs // 3), gamma=0.1)
        if self._scheduler_type == "cosine":
            return torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=max(1, epochs))
        if self._scheduler_type == "warmup_cosine":
            warmup_epochs = max(1, epochs // 10)

            def lr_lambda(epoch: int) -> float:
                if epoch < warmup_epochs:
                    return (epoch + 1) / warmup_epochs
                progress = (epoch - warmup_epochs) / max(1, epochs - warmup_epochs)
                return 0.5 * (1.0 + __import__("math").cos(__import__("math").pi * progress))

            return torch.optim.lr_scheduler.LambdaLR(self.optimizer, lr_lambda)
        return None

    def _compute_batch_loss(self, out: torch.Tensor, yb: torch.Tensor) -> torch.Tensor:
        """Compute loss, handling generation (3D logits) vs classification (2D logits)."""
        if self._task == "generation" and out.dim() == 3:
            # out: (batch, seq_len, vocab_size) → (batch*seq_len, vocab_size)
            # yb:  (batch, seq_len)             → (batch*seq_len,)
            B, S, V = out.shape
            return self.loss_fn(out.reshape(B * S, V), yb.reshape(B * S))
        return self.loss_fn(out, yb)

    def _compute_loss(self, loader: DataLoader) -> float:
        self.model.eval()
        total_loss = 0.0
        total = 0
        with torch.no_grad():
            for xb, yb in loader:
                xb, yb = xb.to(self.device), yb.to(self.device)
                out = self.model(xb)
                if isinstance(out, tuple):
                    out = out[0]
                total_loss += self._compute_batch_loss(out, yb).item() * xb.size(0)
                total += xb.size(0)
        return total_loss / total

    def _compute_accuracy(self, loader: DataLoader) -> float:
        self.model.eval()
        correct = 0
        total = 0
        with torch.no_grad():
            for xb, yb in loader:
                xb, yb = xb.to(self.device), yb.to(self.device)
                out = self.model(xb)
                if isinstance(out, tuple):
                    out = out[0]
                if self._task == "generation" and out.dim() == 3:
                    preds = out.argmax(dim=2).reshape(-1)
                    yb_flat = yb.reshape(-1)
                    mask = yb_flat != 0  # ignore padding
                    correct += (preds[mask] == yb_flat[mask]).sum().item()
                    total += mask.sum().item()
                else:
                    preds = out.argmax(dim=1)
                    correct += (preds == yb).sum().item()
                    total += yb.size(0)
        return correct / total if total > 0 else 0.0
