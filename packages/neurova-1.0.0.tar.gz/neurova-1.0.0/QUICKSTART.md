"""
Neurova Quick Reference Guide

This document provides a quick overview of how to use Neurova and its current capabilities.
"""

# QUICK REFERENCE GUIDE

## Installation

**For detailed installation instructions, see [INSTALLATION.md](INSTALLATION.md)**

```bash
# Basic installation (CPU only)
pip install neurova

# With GPU support (NVIDIA)
pip install neurova cupy-cuda12x

# With all optional features
pip install neurova[all]

# Development installation
git clone https://github.com/neurova/neurova.git
cd neurova
pip install -e ".[dev]"
```

**See [INSTALLATION.md](INSTALLATION.md) for:**

- Platform-specific guides (Linux, Windows, macOS)
- GPU setup instructions
- Troubleshooting
- Dependency information

## Basic Usage

### Reading and Displaying Images

```python
import neurova as nv

# Read an image
img = nv.io.read_image("photo.jpg")

# Access image properties
print(f"Size: {img.width} x {img.height}")
print(f"Channels: {img.channels}")
print(f"Data type: {img.dtype}")
print(f"Color space: {img.color_space}")

# Get underlying numpy array
arr = img.data  # Read-only view
arr_copy = img.as_array()  # Copy
```

### Creating Images

```python
from neurova.core import create_blank_image, create_from_array, ColorSpace
import numpy as np

# Create blank image
blank = create_blank_image(width=640, height=480, channels=3, fill_value=255)

# Create from numpy array
arr = np.zeros((480, 640, 3), dtype=np.uint8)
img = create_from_array(arr, color_space=ColorSpace.RGB)
```

### Color Space Conversion

```python
from neurova.core.color import convert_color_space, to_grayscale
from neurova.core.constants import ColorSpace

# Convert to grayscale
gray = to_grayscale(img.data, from_space=ColorSpace.RGB)

# Convert between color spaces
hsv = convert_color_space(img.data, ColorSpace.RGB, ColorSpace.HSV)
lab = convert_color_space(img.data, ColorSpace.RGB, ColorSpace.LAB)
```

### Array Operations

```python
from neurova.core.array_ops import normalize, standardize, pad_array

# Normalize to [0, 1]
normalized = normalize(img.data, target_min=0.0, target_max=1.0)

# Standardize (zero mean, unit variance)
standardized = standardize(img.data)

# Pad array
padded = pad_array(img.data, pad_width=10, mode='reflect')
```

### Data Type Conversion

```python
from neurova.core.dtypes import convert_dtype, DataType

# Convert with scaling
float_img = convert_dtype(img.data, DataType.FLOAT32, scale=True)

# Convert without scaling
uint16_img = convert_dtype(img.data, DataType.UINT16, scale=False)
```

## Module Organization

### Core (`neurova.core`)

- **Image**: Core image class
- **ColorSpace**: Color space enumeration
- **DataType**: Data type management
- **Array operations**: Normalize, pad, clip, etc.
- **Error handling**: Custom exceptions

### I/O (`neurova.io`)

- **read_image()**: Read image files
- **write_image()**: Write image files (coming soon)
- **read_from_bytes()**: Read from byte data
- Supported formats: PNG, BMP, PPM (native), JPEG (via Pillow)

### Transform (`neurova.transform`)

Coming soon:

- Resize, rotate, flip
- Affine transformations
- Perspective transformations
- Warping

### Filters (`neurova.filters`)

Coming soon:

- Gaussian blur, median blur
- Edge detection (Sobel, Canny)
- Morphological operations
- Custom convolutions

### Features (`neurova.features`)

Coming soon:

- Corner detection (Harris, Shi-Tomasi)
- Keypoint detection
- Feature descriptors (ORB, BRIEF)
- Feature matching

### Neural (`neurova.neural`)

Coming soon:

- Convolutional layers
- Pooling layers
- Activation functions
- Loss functions
- Optimizers

## Error Handling

```python
from neurova.core.errors import (
    NeurovaError,
    ImageError,
    IOError,
    ValidationError
)

try:
    img = nv.io.read_image("nonexistent.jpg")
except IOError as e:
    print(f"Failed to read image: {e}")

try:
    # Invalid color space
    img = Image(data, color_space="INVALID")
except ValidationError as e:
    print(f"Validation error: {e}")
```

## Performance Tips

### 1. Use NumPy Vectorization

```python
# Good: Vectorized operation
result = img.data * 1.5

# Bad: Python loops
for i in range(height):
    for j in range(width):
        result[i, j] = img.data[i, j] * 1.5
```

### 2. Avoid Unnecessary Copies

```python
# Good: Use view when possible
view = img.data  # No copy

# Only copy when needed
copy = img.as_array()  # Explicit copy
```

### 3. Use Appropriate Data Types

```python
# For storage and display
uint8_img = DataType.UINT8  # 0-255 range

# For computation
float32_img = DataType.FLOAT32  # 0.0-1.0 range
```

## API Design Philosophy

### Immutability

```python
# Operations return new objects
gray_img = to_grayscale(img.data)
# Original img is unchanged
```

### Type Hints

```python
# All functions have type hints
def convert_dtype(arr: np.ndarray, target_dtype: DType, scale: bool = True) -> np.ndarray:
    ...
```

### Clear Error Messages

```python
# Errors provide context
ValidationError('mode', 'invalid', "one of: constant, reflect, replicate, wrap")
ShapeError((2, 3), arr.shape, "Array must have 2 or 3 dimensions")
```

## Current Limitations (v0.1.0-alpha)

1. Limited image format support (PNG, BMP, PPM native; JPEG requires Pillow)
2. No transformation functions yet
3. No filtering operations yet
4. No video processing yet
5. Performance not yet optimized

## Roadmap

### Phase 1 (Current)

- [x] Core image operations
- [x] Color space conversions
- [x] Basic I/O

### Phase 2 (Next)

- [ ] Geometric transformations
- [ ] Image filtering
- [ ] Morphological operations

### Phase 3

- [ ] Feature detection
- [ ] Object detection
- [ ] Neural network layers

### Phase 4

- [ ] Video processing
- [ ] Camera calibration
- [ ] Advanced segmentation

## Getting Help

- Documentation: https://neurova.readthedocs.io
- GitHub Issues: https://github.com/neurova/neurova/issues
- GitHub Discussions: https://github.com/neurova/neurova/discussions

## Contributing

Contributions are welcome! See CONTRIBUTING.md for guidelines.

## License

MIT License - see LICENSE file for details.
