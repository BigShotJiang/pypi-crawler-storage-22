# Neurova Computer Vision and Deep Learning Technology

A complete image processing and deep learning library with GPU acceleration, built for both learning and production use. Minimal dependencies, clean APIs, and comprehensive documentation make it easy to go from experimentation to deployment.

[![Python Version](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](https://github.com/nalystresearch/neurova/blob/main/LICENSE)
[![PyPI](https://img.shields.io/badge/pypi-v1.0.0-blue.svg)](https://pypi.org/project/neurova/)

**Navigation:** [Installation](https://github.com/nalystresearch/neurova#installation) · [Quick Start](https://github.com/nalystresearch/neurova#quick-start) · [Core Modules](https://github.com/nalystresearch/neurova#core-modules) · [Examples](https://github.com/nalystresearch/neurova#examples) · [Documentation](https://github.com/nalystresearch/neurova#documentation) · [Contributing](https://github.com/nalystresearch/neurova#contributing)

---

## Overview

Neurova provides everything you need for computer vision and deep learning in a single package. From basic image manipulation to training neural networks on GPUs, it handles the full workflow while keeping dependencies minimal and APIs consistent.

## Why Neurova

- **Complete workflow**: Image processing, computer vision, classical ML, and deep learning in one package
- **GPU acceleration**: Optional CuPy support provides massive speedups (10-100x) on compatible hardware
- **Minimal dependencies**: Just NumPy for core functionality, nothing more unless you need it
- **Consistent APIs**: Learn once, apply everywhere - same patterns across all modules
- **Production ready**: Type hints, comprehensive tests, and clear documentation
- **Beginner friendly**: Start with simple operations, grow into advanced features at your own pace

## What You Can Build

- Image processing pipelines for preprocessing and augmentation
- Custom computer vision applications (object detection, segmentation, tracking)
- Machine learning models for classification, regression, and clustering
- Deep neural networks with automatic differentiation
- GPU-accelerated training and inference
- End-to-end vision systems from data to deployment

## Installation

**For complete installation instructions, see [INSTALLATION.md](https://github.com/nalystresearch/neurova/blob/main/INSTALLATION.md)**

### Quick Install

```bash
# Basic installation (CPU only)
pip install neurova

# With GPU support (NVIDIA GPUs)
pip install neurova
pip install cupy-cuda12x  # Replace 12x with your CUDA version

# With all optional features
pip install neurova[all]
```

**Need help?** See [INSTALLATION.md](https://github.com/nalystresearch/neurova/blob/main/INSTALLATION.md) for:

- Platform-specific instructions (Linux, Windows, macOS)
- GPU setup guide
- Troubleshooting
- Virtual environment setup
- Dependency details

### Development Installation

```bash
git clone https://github.com/nalystresearch/neurova.git
cd neurova
pip install -e ".[dev]"
```

## Quick Start

```python
import neurova as nv

# Load and process an image
img = nv.io.read_image("photo.jpg")

# Apply transformations
img_gray = nv.core.to_grayscale(img)
img_blurred = nv.filters.gaussian_blur(img_gray, kernel_size=5)
edges = nv.filters.canny_edges(img_blurred, low=50, high=150)

# Detect features
corners = nv.features.detect_corners(img_gray, method="harris")
keypoints = nv.features.detect_keypoints(img_gray)

# Save result
nv.io.write_image("result.jpg", edges)
```

## Core Modules

### Image Processing

- **core**: Image representation, color spaces, basic operations
- **transform**: Geometric transformations, resizing, rotation
- **filters**: Convolution, blurring, edge detection, morphology
- **segmentation**: Thresholding, watershed, contours

### Computer Vision

- **features**: Corner, edge, keypoint detection and matching
- **detection**: Object, face, and template detection
- **tracking**: Object tracking algorithms
- **calibration**: Camera calibration and 3D geometry

### Deep Learning

- **neural**: Neural network layers and operations
- **ml**: Machine learning utilities and algorithms
- **augmentation**: Data augmentation pipelines

### Input/Output

- **io**: Image and video reading/writing
- **video**: Video processing and analysis

## Examples

### Image Enhancement

```python
import neurova as nv

# Read image
img = nv.io.read_image("dark_photo.jpg")

# Enhance
enhanced = nv.transform.adjust_brightness(img, factor=1.5)
enhanced = nv.transform.adjust_contrast(enhanced, factor=1.2)
enhanced = nv.filters.sharpen(enhanced)

# Save
nv.io.write_image("enhanced.jpg", enhanced)
```

### Feature Detection and Matching

```python
import neurova as nv

# Load two images
img1 = nv.io.read_image("scene1.jpg")
img2 = nv.io.read_image("scene2.jpg")

# Detect and describe keypoints
kp1, desc1 = nv.features.compute_features(img1, method="orb")
kp2, desc2 = nv.features.compute_features(img2, method="orb")

# Match features
matches = nv.features.match_descriptors(desc1, desc2, method="brute_force")

# Visualize
result = nv.utils.draw_matches(img1, kp1, img2, kp2, matches)
nv.io.write_image("matches.jpg", result)
```

### Face Detection

```python
import neurova as nv

# Load image
img = nv.io.read_image("people.jpg")

# Detect faces
faces = nv.detection.detect_faces(img)

# Draw rectangles
for face in faces:
    x, y, w, h = face.bounds
    nv.utils.draw_rectangle(img, (x, y), (x+w, y+h), color=(0, 255, 0))

# Save
nv.io.write_image("detected_faces.jpg", img)
```

### Neural Network Operations

```python
import neurova as nv
import neurova.neural as nn

# Create a simple CNN
model = nn.Sequential([
    nn.Conv2D(in_channels=3, out_channels=32, kernel_size=3),
    nn.ReLU(),
    nn.MaxPool2D(kernel_size=2),
    nn.Conv2D(in_channels=32, out_channels=64, kernel_size=3),
    nn.ReLU(),
    nn.MaxPool2D(kernel_size=2),
    nn.Flatten(),
    nn.Dense(in_features=1024, out_features=10),
])

# Process image
img = nv.io.read_image("input.jpg")
features = model.forward(img)
```

## Dependencies

### Required

- **Python** >= 3.8
- **NumPy** >= 1.19.0

### Optional

- **Pillow**: Extended image format support
- **SciPy**: Advanced scientific computations

## Documentation

Full documentation is available in the [GitHub repository](https://github.com/nalystresearch/neurova)

- [API Reference](https://github.com/nalystresearch/neurova/blob/main/DOCS_INDEX.md)
- [Tutorials](https://github.com/nalystresearch/neurova/blob/main/examples/)
- [Examples](https://github.com/nalystresearch/neurova/tree/main/examples)
- [Architecture](https://github.com/nalystresearch/neurova/blob/main/ARCHITECTURE.md)

## Comparison with OpenCV

| Feature        | Neurova              | OpenCV                               |
| -------------- | -------------------- | ------------------------------------ |
| Dependencies   | Minimal (NumPy only) | Many (C++ libs, system dependencies) |
| Pure Python    | Yes                  | No (C++ bindings)                    |
| Deep Learning  | Native support       | Limited (DNN module)                 |
| Installation   | Simple               | Complex                              |
| Customization  | Easy                 | Requires C++ knowledge               |
| Learning Curve | Gentle               | Steep                                |

## Performance

Neurova is optimized for performance using:

- NumPy vectorization for fast array operations
- Efficient memory management
- Parallel processing for batch operations
- Caching for repeated computations

## Contributing

Contributions are welcome! Please read [CONTRIBUTING.md](https://github.com/nalystresearch/neurova/blob/main/CONTRIBUTING.md) for details on:

- Setting up your development environment
- Code style and testing requirements
- How to submit pull requests
- Community guidelines

See also:

- [CODE_OF_CONDUCT.md](https://github.com/nalystresearch/neurova/blob/main/CODE_OF_CONDUCT.md) - Community standards
- [SECURITY.md](https://github.com/nalystresearch/neurova/blob/main/SECURITY.md) - Security reporting
- [SUPPORT.md](https://github.com/nalystresearch/neurova/blob/main/SUPPORT.md) - Getting help

## Documentation

**Complete documentation:** [DOCS_INDEX.md](https://github.com/nalystresearch/neurova/blob/main/DOCS_INDEX.md)

**Getting started:**

- [INSTALLATION.md](https://github.com/nalystresearch/neurova/blob/main/INSTALLATION.md) - Installation guide
- [QUICKSTART.md](https://github.com/nalystresearch/neurova/blob/main/QUICKSTART.md) - Quick reference
- [DEVICE_SELECTION_GUIDE.md](https://github.com/nalystresearch/neurova/blob/main/DEVICE_SELECTION_GUIDE.md) - GPU/CPU setup
- [DEPENDENCIES.md](https://github.com/nalystresearch/neurova/blob/main/DEPENDENCIES.md) - Dependencies and licenses

## Publishing

If you're interested in the PyPI publishing process, see [PUBLISHING.md](https://github.com/nalystresearch/neurova/blob/main/PUBLISHING.md).

## License

MIT License - see [LICENSE](https://github.com/nalystresearch/neurova/blob/main/LICENSE) for details.

## Support

- **Documentation**: [DOCS_INDEX.md](https://github.com/nalystresearch/neurova/blob/main/DOCS_INDEX.md)
- **Issues**: [GitHub Issues](https://github.com/nalystresearch/neurova/issues)
- **Questions**: See [SUPPORT.md](https://github.com/nalystresearch/neurova/blob/main/SUPPORT.md)

## Changelog

See [CHANGELOG.md](https://github.com/nalystresearch/neurova/blob/main/CHANGELOG.md) for version history.

- [ ] Pre-trained models
- [ ] Distributed processing

---

Made by the Neurova team
