# copyright (c) 2025 @analytics withharry
# all rights reserved.
# licensed under the mit license.

"""
Neurova - Advanced Image Processing and Deep Learning Library

This package provides comprehensive computer vision and deep learning
functionality with minimal dependencies and optional GPU acceleration.
"""

from neurova.version import (
    __version__,
    __version_info__,
    __build__,
    __date__,
    get_version,
    get_build_info,
)

# import device management for gpu/cpu selection
from neurova.device import (
    set_device,
    get_device,
    get_backend,
    cuda_is_available,
    get_device_count,
    get_device_name,
    get_device_info,
    to_device,
    synchronize,
    empty_cache,
    get_memory_usage,
    device_context,
    array,
    zeros,
    ones,
    empty,
)

# import core modules for convenience
from neurova import core
from neurova import io
from neurova import transform
from neurova import filters
from neurova import features
from neurova import neural
from neurova import segmentation
from neurova import detection
from neurova import utils
from neurova import ml
from neurova import morphology

__all__ = [
    # version info
    "__version__",
    "__version_info__",
    "__build__",
    "__date__",
    "get_version",
    "get_build_info",
    # device management (GPU/CPU selection)
    "set_device",
    "get_device",
    "get_backend",
    "cuda_is_available",
    "get_device_count",
    "get_device_name",
    "get_device_info",
    "to_device",
    "synchronize",
    "empty_cache",
    "get_memory_usage",
    "device_context",
    "array",
    "zeros",
    "ones",
    "empty",
    # modules
    "core",
    "io",
    "transform",
    "filters",
    "features",
    "neural",
    "segmentation",
    "detection",
    "utils",
    "ml",
    "morphology",
]
