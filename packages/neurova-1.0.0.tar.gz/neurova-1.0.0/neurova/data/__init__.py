# copyright (c) 2025 @analytics withharry
# all rights reserved.
# licensed under the mit license.

"""Data files and resources for Neurova"""

__all__ = []
