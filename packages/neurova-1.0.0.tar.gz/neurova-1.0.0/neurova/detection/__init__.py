# copyright (c) 2025 @analytics withharry
# all rights reserved.
# licensed under the mit license.

"""Object detection for Neurova"""

from neurova.detection.template import (
    match_template,
    non_max_suppression,
    sliding_window_detection,
    TemplateDetector,
)

__all__ = [
    "match_template",
    "non_max_suppression",
    "sliding_window_detection",
    "TemplateDetector",
]
