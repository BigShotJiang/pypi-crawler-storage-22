# copyright (c) 2025 @analytics withharry
# all rights reserved.
# licensed under the mit license.

"""
Clustering algorithms for machine learning

All implementations use NumPy only.
"""

import numpy as np
from typing import Optional
from neurova.core.errors import ValidationError


class KMeans:
    """
    K-Means clustering algorithm
    
    Examples:
        >>> kmeans = KMeans(n_clusters=3)
        >>> kmeans.fit(X)
        >>> labels = kmeans.predict(X)
    """
    
    def __init__(self, n_clusters: int = 8, max_iter: int = 300, 
                 n_init: int = 10, random_state: Optional[int] = None):
        """
        Args:
            n_clusters: Number of clusters
            max_iter: Maximum number of iterations
            n_init: Number of times to run with different initializations
            random_state: Random state for reproducibility
        """
        self.n_clusters = n_clusters
        self.max_iter = max_iter
        self.n_init = n_init
        self.random_state = random_state
        self.cluster_centers_ = None
        self.labels_ = None
        self.inertia_ = None
    
    def _initialize_centers(self, X: np.ndarray, rng: np.random.Generator) -> np.ndarray:
        """Initialize cluster centers using k-means++"""
        n_samples = X.shape[0]
        centers = []
        
        # choose first center randomly
        centers.append(X[rng.integers(0, n_samples)])
        
        # choose remaining centers
        for _ in range(1, self.n_clusters):
            # compute distances to nearest center
            distances = np.array([
                np.min([np.linalg.norm(x - c) ** 2 for c in centers])
                for x in X
            ])
            
            # choose new center with probability proportional to distance squared
            probabilities = distances / distances.sum()
            cumulative_probs = np.cumsum(probabilities)
            r = rng.random()
            idx = np.searchsorted(cumulative_probs, r)
            centers.append(X[idx])
        
        return np.array(centers)
    
    def _assign_labels(self, X: np.ndarray, centers: np.ndarray) -> np.ndarray:
        """Assign each sample to nearest center"""
        distances = np.sqrt(((X[:, np.newaxis] - centers) ** 2).sum(axis=2))
        return np.argmin(distances, axis=1)
    
    def _compute_inertia(self, X: np.ndarray, labels: np.ndarray, 
                        centers: np.ndarray) -> float:
        """Compute inertia (sum of squared distances)"""
        return np.sum((X - centers[labels]) ** 2)
    
    def fit(self, X: np.ndarray) -> 'KMeans':
        """Compute k-means clustering"""
        X = np.asarray(X, dtype=np.float64)
        n_samples, n_features = X.shape
        
        if self.n_clusters > n_samples:
            raise ValidationError('n_clusters', self.n_clusters, 
                                f'<= {n_samples} (number of samples)')
        
        rng = np.random.default_rng(self.random_state)
        
        best_inertia = float('inf')
        best_centers = None
        best_labels = None
        
        # run multiple times with different initializations
        for _ in range(self.n_init):
            centers = self._initialize_centers(X, rng)
            labels = np.zeros(n_samples, dtype=int)  # Initialize labels
            
            # iterate until convergence or max_iter
            for iteration in range(self.max_iter):
                # assign labels
                labels = self._assign_labels(X, centers)
                
                # update centers
                new_centers = np.array([
                    X[labels == k].mean(axis=0) if np.sum(labels == k) > 0 else centers[k]
                    for k in range(self.n_clusters)
                ])
                
                # check convergence
                if np.allclose(centers, new_centers):
                    break
                
                centers = new_centers
            
            # compute inertia
            inertia = self._compute_inertia(X, labels, centers)
            
            if inertia < best_inertia:
                best_inertia = inertia
                best_centers = centers
                best_labels = labels
        
        self.cluster_centers_ = best_centers
        self.labels_ = best_labels
        self.inertia_ = best_inertia
        
        return self
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict cluster labels"""
        if self.cluster_centers_ is None:
            raise ValidationError('clusterer', 'not fitted', 'fitted clusterer')
        
        X = np.asarray(X, dtype=np.float64)
        return self._assign_labels(X, self.cluster_centers_)
    
    def fit_predict(self, X: np.ndarray) -> np.ndarray:
        """Fit and predict in one step"""
        return self.fit(X).labels_


class DBSCAN:
    """
    DBSCAN clustering algorithm
    
    Examples:
        >>> dbscan = DBSCAN(eps=0.5, min_samples=5)
        >>> labels = dbscan.fit_predict(X)
    """
    
    def __init__(self, eps: float = 0.5, min_samples: int = 5, metric: str = 'euclidean'):
        """
        Args:
            eps: Maximum distance between two samples
            min_samples: Minimum samples in a neighborhood
            metric: Distance metric
        """
        self.eps = eps
        self.min_samples = min_samples
        self.metric = metric
        self.labels_ = None
        self.core_sample_indices_ = None
    
    def _compute_distances(self, X: np.ndarray) -> np.ndarray:
        """Compute pairwise distances"""
        if self.metric == 'euclidean':
            diff = X[:, np.newaxis, :] - X[np.newaxis, :, :]
            distances = np.sqrt((diff ** 2).sum(axis=2))
        elif self.metric == 'manhattan':
            diff = X[:, np.newaxis, :] - X[np.newaxis, :, :]
            distances = np.abs(diff).sum(axis=2)
        else:
            raise ValidationError('metric', self.metric, 'euclidean or manhattan')
        
        return distances
    
    def fit(self, X: np.ndarray) -> 'DBSCAN':
        """Perform DBSCAN clustering"""
        X = np.asarray(X, dtype=np.float64)
        n_samples = X.shape[0]
        
        # compute pairwise distances
        distances = self._compute_distances(X)
        
        # find neighbors
        neighbors = [np.where(distances[i] <= self.eps)[0] for i in range(n_samples)]
        
        # initialize labels (-1 means noise)
        labels = -np.ones(n_samples, dtype=int)
        
        # find core samples
        core_samples = [i for i in range(n_samples) if len(neighbors[i]) >= self.min_samples]
        self.core_sample_indices_ = np.array(core_samples)
        
        # assign clusters
        cluster_id = 0
        visited = set()
        
        for core_idx in core_samples:
            if core_idx in visited:
                continue
            
            # start new cluster
            queue = [core_idx]
            visited.add(core_idx)
            labels[core_idx] = cluster_id
            
            while queue:
                current = queue.pop(0)
                
                # add neighbors to cluster
                for neighbor in neighbors[current]:
                    if neighbor not in visited:
                        visited.add(neighbor)
                        labels[neighbor] = cluster_id
                        
                        # if neighbor is core sample, add its neighbors to queue
                        if len(neighbors[neighbor]) >= self.min_samples:
                            queue.append(neighbor)
            
            cluster_id += 1
        
        self.labels_ = labels
        return self
    
    def fit_predict(self, X: np.ndarray) -> np.ndarray:
        """Fit and return cluster labels"""
        return self.fit(X).labels_


class AgglomerativeClustering:
    """
    Agglomerative (hierarchical) clustering
    
    Examples:
        >>> agg = AgglomerativeClustering(n_clusters=3)
        >>> labels = agg.fit_predict(X)
    """
    
    def __init__(self, n_clusters: int = 2, linkage: str = 'average'):
        """
        Args:
            n_clusters: Number of clusters
            linkage: Linkage criterion ('single', 'complete', 'average')
        """
        self.n_clusters = n_clusters
        self.linkage = linkage
        self.labels_ = None
    
    def _compute_distances(self, X: np.ndarray) -> np.ndarray:
        """Compute pairwise distances"""
        diff = X[:, np.newaxis, :] - X[np.newaxis, :, :]
        return np.sqrt((diff ** 2).sum(axis=2))
    
    def _linkage_distance(self, cluster1: list, cluster2: list, 
                         distances: np.ndarray) -> float:
        """Compute distance between two clusters"""
        if self.linkage == 'single':
            # minimum distance
            return np.min([distances[i, j] for i in cluster1 for j in cluster2])
        elif self.linkage == 'complete':
            # maximum distance
            return np.max([distances[i, j] for i in cluster1 for j in cluster2])
        elif self.linkage == 'average':
            # average distance
            return float(np.mean([distances[i, j] for i in cluster1 for j in cluster2]))
        else:
            raise ValidationError('linkage', self.linkage, 'single, complete, or average')
    
    def fit(self, X: np.ndarray) -> 'AgglomerativeClustering':
        """Perform hierarchical clustering"""
        X = np.asarray(X, dtype=np.float64)
        n_samples = X.shape[0]
        
        # compute pairwise distances
        distances = self._compute_distances(X)
        
        # initialize each sample as its own cluster
        clusters = [[i] for i in range(n_samples)]
        
        # merge clusters until we have n_clusters
        while len(clusters) > self.n_clusters:
            # find closest pair of clusters
            min_dist = float('inf')
            merge_i, merge_j = 0, 1
            
            for i in range(len(clusters)):
                for j in range(i + 1, len(clusters)):
                    dist = self._linkage_distance(clusters[i], clusters[j], distances)
                    if dist < min_dist:
                        min_dist = dist
                        merge_i, merge_j = i, j
            
            # merge clusters
            clusters[merge_i].extend(clusters[merge_j])
            clusters.pop(merge_j)
        
        # assign labels
        labels = np.zeros(n_samples, dtype=int)
        for cluster_id, cluster in enumerate(clusters):
            for sample_idx in cluster:
                labels[sample_idx] = cluster_id
        
        self.labels_ = labels
        return self
    
    def fit_predict(self, X: np.ndarray) -> np.ndarray:
        """Fit and return cluster labels"""
        return self.fit(X).labels_
