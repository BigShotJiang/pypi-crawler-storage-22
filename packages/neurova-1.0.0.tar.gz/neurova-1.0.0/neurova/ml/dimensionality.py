# copyright (c) 2025 @analytics withharry
# all rights reserved.
# licensed under the mit license.

"""
Dimensionality reduction algorithms

All implementations use NumPy only.
"""

import numpy as np
from typing import Optional
from neurova.core.errors import ValidationError


class PCA:
    """
    Principal Component Analysis (PCA)
    
    Examples:
        >>> pca = PCA(n_components=2)
        >>> X_reduced = pca.fit_transform(X)
    """
    
    def __init__(self, n_components: Optional[int] = None, whiten: bool = False):
        """
        Args:
            n_components: Number of components to keep
            whiten: Whether to whiten the data
        """
        self.n_components = n_components
        self.whiten = whiten
        self.components_ = None
        self.mean_ = None
        self.explained_variance_ = None
        self.explained_variance_ratio_ = None
    
    def fit(self, X: np.ndarray) -> 'PCA':
        """Fit PCA on data"""
        X = np.asarray(X, dtype=np.float64)
        n_samples, n_features = X.shape
        
        # center data
        self.mean_ = X.mean(axis=0)
        X_centered = X - self.mean_
        
        # compute covariance matrix
        cov_matrix = (X_centered.T @ X_centered) / (n_samples - 1)
        
        # eigenvalue decomposition
        eigenvalues, eigenvectors = np.linalg.eigh(cov_matrix)
        
        # sort by eigenvalues (descending)
        idx = np.argsort(eigenvalues)[::-1]
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:, idx]
        
        # select number of components
        if self.n_components is None:
            n_components = n_features
        else:
            n_components = min(self.n_components, n_features)
        
        # store components
        self.components_ = eigenvectors[:, :n_components].T
        self.explained_variance_ = eigenvalues[:n_components]
        
        # calculate explained variance ratio
        total_variance = eigenvalues.sum()
        self.explained_variance_ratio_ = eigenvalues[:n_components] / total_variance
        
        return self
    
    def transform(self, X: np.ndarray) -> np.ndarray:
        """Transform data to PC space"""
        if self.components_ is None:
            raise ValidationError('pca', 'not fitted', 'fitted PCA')
        
        X = np.asarray(X, dtype=np.float64)
        X_centered = X - self.mean_
        X_transformed = X_centered @ self.components_.T
        
        if self.whiten and self.explained_variance_ is not None:
            X_transformed /= np.sqrt(self.explained_variance_)
        
        return X_transformed
    
    def fit_transform(self, X: np.ndarray) -> np.ndarray:
        """Fit and transform in one step"""
        return self.fit(X).transform(X)
    
    def inverse_transform(self, X_transformed: np.ndarray) -> np.ndarray:
        """Transform data back to original space"""
        if self.components_ is None:
            raise ValidationError('pca', 'not fitted', 'fitted PCA')
        
        X_result = X_transformed.copy()
        if self.whiten and self.explained_variance_ is not None:
            X_result = X_result * np.sqrt(self.explained_variance_)
        
        return X_result @ self.components_ + self.mean_


class LDA:
    """
    Linear Discriminant Analysis (LDA)
    
    Examples:
        >>> lda = LDA(n_components=2)
        >>> X_reduced = lda.fit_transform(X, y)
    """
    
    def __init__(self, n_components: Optional[int] = None):
        """
        Args:
            n_components: Number of components to keep
        """
        self.n_components = n_components
        self.components_ = None
        self.mean_ = None
        self.explained_variance_ratio_ = None
    
    def fit(self, X: np.ndarray, y: np.ndarray) -> 'LDA':
        """Fit LDA on data"""
        X = np.asarray(X, dtype=np.float64)
        y = np.asarray(y)
        
        n_samples, n_features = X.shape
        classes = np.unique(y)
        n_classes = len(classes)
        
        # overall mean
        self.mean_ = X.mean(axis=0)
        
        # within-class scatter matrix
        S_W = np.zeros((n_features, n_features))
        
        # between-class scatter matrix
        S_B = np.zeros((n_features, n_features))
        
        for cls in classes:
            X_cls = X[y == cls]
            n_cls = X_cls.shape[0]
            
            # class mean
            mean_cls = X_cls.mean(axis=0)
            
            # within-class scatter
            X_centered = X_cls - mean_cls
            S_W += X_centered.T @ X_centered
            
            # between-class scatter
            mean_diff = (mean_cls - self.mean_).reshape(-1, 1)
            S_B += n_cls * (mean_diff @ mean_diff.T)
        
        # solve generalized eigenvalue problem
        # s_W^{-1} S_B
        try:
            S_W_inv = np.linalg.inv(S_W)
            matrix = S_W_inv @ S_B
        except np.linalg.LinAlgError:
            # if S_W is singular, use pseudo-inverse
            S_W_inv = np.linalg.pinv(S_W)
            matrix = S_W_inv @ S_B
        
        # eigenvalue decomposition
        eigenvalues, eigenvectors = np.linalg.eig(matrix)
        
        # sort by eigenvalues (descending)
        idx = np.argsort(np.abs(eigenvalues))[::-1]
        eigenvalues = eigenvalues[idx].real
        eigenvectors = eigenvectors[:, idx].real
        
        # select number of components
        if self.n_components is None:
            n_components = min(n_features, n_classes - 1)
        else:
            n_components = min(self.n_components, n_features, n_classes - 1)
        
        # store components
        self.components_ = eigenvectors[:, :n_components].T
        
        # calculate explained variance ratio
        total_variance = eigenvalues.sum()
        self.explained_variance_ratio_ = eigenvalues[:n_components] / total_variance
        
        return self
    
    def transform(self, X: np.ndarray) -> np.ndarray:
        """Transform data to LD space"""
        if self.components_ is None:
            raise ValidationError('lda', 'not fitted', 'fitted LDA')
        
        X = np.asarray(X, dtype=np.float64)
        X_centered = X - self.mean_
        return X_centered @ self.components_.T
    
    def fit_transform(self, X: np.ndarray, y: np.ndarray) -> np.ndarray:
        """Fit and transform in one step"""
        return self.fit(X, y).transform(X)
