# copyright (c) 2025 @analytics withharry
# all rights reserved.
# licensed under the mit license.

"""Ensemble learning methods for Neurova."""

from __future__ import annotations
import numpy as np
from typing import Optional, Literal
from neurova.ml.classification import DecisionTreeClassifier
from neurova.core.errors import ValidationError


class RandomForestClassifier:
    """Random Forest classifier using bagging and feature randomness.
    
    Args:
        n_estimators: Number of trees in the forest
        max_depth: Maximum depth of trees
        min_samples_split: Minimum samples required to split
        max_features: Number of features to consider for splits ("sqrt", "log2", or int)
        bootstrap: Whether to use bootstrap samples
        random_state: Random seed
        
    Examples:
        rf = RandomForestClassifier(n_estimators=100, max_depth=10)
        rf.fit(X_train, y_train)
        predictions = rf.predict(X_test)
    """
    
    def __init__(
        self,
        n_estimators: int = 100,
        max_depth: Optional[int] = None,
        min_samples_split: int = 2,
        max_features: str | int = "sqrt",
        bootstrap: bool = True,
        random_state: Optional[int] = None,
    ):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.max_features = max_features
        self.bootstrap = bootstrap
        self.random_state = random_state
        
        self.trees: list[DecisionTreeClassifier] = []
        self.n_classes: int = 0
        self.feature_importances_: Optional[np.ndarray] = None
        
        if random_state is not None:
            np.random.seed(random_state)
    
    def _get_n_features(self, n_total: int) -> int:
        """Get number of features to use."""
        if isinstance(self.max_features, int):
            return min(self.max_features, n_total)
        elif self.max_features == "sqrt":
            return int(np.sqrt(n_total))
        elif self.max_features == "log2":
            return int(np.log2(n_total))
        else:
            return n_total
    
    def fit(self, X: np.ndarray, y: np.ndarray) -> RandomForestClassifier:
        """Fit random forest classifier.
        
        Args:
            X: Training data (n_samples, n_features)
            y: Target labels (n_samples,)
            
        Returns:
            self
        """
        X = np.asarray(X)
        y = np.asarray(y)
        n_samples, n_features = X.shape
        
        self.n_classes = len(np.unique(y))
        self.trees = []
        
        # calculate max features
        max_feat = self._get_n_features(n_features)
        
        # build trees
        for _ in range(self.n_estimators):
            # bootstrap sample
            if self.bootstrap:
                indices = np.random.choice(n_samples, n_samples, replace=True)
                X_sample = X[indices]
                y_sample = y[indices]
            else:
                X_sample = X
                y_sample = y
            
            # random feature subset
            feature_indices = np.random.choice(n_features, max_feat, replace=False)
            X_subset = X_sample[:, feature_indices]
            
            # train tree
            tree = DecisionTreeClassifier(
                max_depth=self.max_depth,
                min_samples_split=self.min_samples_split,
            )
            tree.fit(X_subset, y_sample)
            tree.feature_indices = feature_indices  # Store which features were used
            self.trees.append(tree)
        
        # calculate feature importances (average across trees)
        self._compute_feature_importances(n_features)
        
        return self
    
    def _compute_feature_importances(self, n_features: int) -> None:
        """Compute feature importances from all trees."""
        importances = np.zeros(n_features)
        
        for tree in self.trees:
            if hasattr(tree, 'feature_importances_') and tree.feature_importances_ is not None:
                # map tree importances back to original feature indices
                for idx, feat_idx in enumerate(tree.feature_indices):
                    if idx < len(tree.feature_importances_):
                        importances[feat_idx] += tree.feature_importances_[idx]
        
        # normalize
        if np.sum(importances) > 0:
            importances /= np.sum(importances)
        
        self.feature_importances_ = importances
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict class labels.
        
        Args:
            X: Test data (n_samples, n_features)
            
        Returns:
            Predicted labels (n_samples,)
        """
        proba = self.predict_proba(X)
        return np.argmax(proba, axis=1)
    
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Predict class probabilities.
        
        Args:
            X: Test data (n_samples, n_features)
            
        Returns:
            Class probabilities (n_samples, n_classes)
        """
        X = np.asarray(X)
        n_samples = X.shape[0]
        
        # aggregate predictions from all trees
        all_proba = np.zeros((n_samples, self.n_classes))
        
        for tree in self.trees:
            # get predictions on relevant features
            X_subset = X[:, tree.feature_indices]
            tree_proba = tree.predict_proba(X_subset)
            all_proba += tree_proba
        
        # average
        all_proba /= self.n_estimators
        
        return all_proba


class GradientBoostingClassifier:
    """Gradient Boosting classifier.
    
    Builds an additive model in a forward stage-wise fashion.
    
    Args:
        n_estimators: Number of boosting stages
        learning_rate: Shrinks contribution of each tree
        max_depth: Maximum depth of individual trees
        min_samples_split: Minimum samples to split
        subsample: Fraction of samples for fitting trees
        random_state: Random seed
        
    Examples:
        gb = GradientBoostingClassifier(n_estimators=100, learning_rate=0.1)
        gb.fit(X_train, y_train)
        predictions = gb.predict(X_test)
    """
    
    def __init__(
        self,
        n_estimators: int = 100,
        learning_rate: float = 0.1,
        max_depth: int = 3,
        min_samples_split: int = 2,
        subsample: float = 1.0,
        random_state: Optional[int] = None,
    ):
        self.n_estimators = n_estimators
        self.learning_rate = learning_rate
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.subsample = subsample
        self.random_state = random_state
        
        self.trees: list[DecisionTreeClassifier] = []
        self.init_pred: float = 0.0
        self.n_classes: int = 0
        
        if random_state is not None:
            np.random.seed(random_state)
    
    def _sigmoid(self, x: np.ndarray) -> np.ndarray:
        """Sigmoid activation."""
        return 1.0 / (1.0 + np.exp(-np.clip(x, -500, 500)))
    
    def fit(self, X: np.ndarray, y: np.ndarray) -> GradientBoostingClassifier:
        """Fit gradient boosting classifier.
        
        Args:
            X: Training data (n_samples, n_features)
            y: Target labels (n_samples,)
            
        Returns:
            self
        """
        X = np.asarray(X)
        y = np.asarray(y)
        n_samples = X.shape[0]
        
        self.n_classes = len(np.unique(y))
        
        # binary classification for now
        if self.n_classes > 2:
            raise NotImplementedError("Multi-class gradient boosting not yet implemented")
        
        # initialize with log-odds
        n_pos = np.sum(y == 1)
        n_neg = np.sum(y == 0)
        self.init_pred = np.log((n_pos + 1e-10) / (n_neg + 1e-10))
        
        # initialize predictions
        F = np.full(n_samples, self.init_pred)
        
        # build trees
        self.trees = []
        for _ in range(self.n_estimators):
            # compute negative gradient (residuals)
            p = self._sigmoid(F)
            residuals = y - p
            
            # subsample
            if self.subsample < 1.0:
                n_subsample = int(self.subsample * n_samples)
                indices = np.random.choice(n_samples, n_subsample, replace=False)
                X_sub = X[indices]
                res_sub = residuals[indices]
            else:
                X_sub = X
                res_sub = residuals
            
            # fit tree to residuals
            tree = DecisionTreeClassifier(
                max_depth=self.max_depth,
                min_samples_split=self.min_samples_split,
            )
            # use residuals as pseudo-targets (convert to binary for tree)
            y_pseudo = (res_sub > 0).astype(int)
            tree.fit(X_sub, y_pseudo)
            self.trees.append(tree)
            
            # update predictions
            tree_pred = tree.predict_proba(X)[:, 1] - 0.5  # Center around 0
            F += self.learning_rate * tree_pred * 2  # Scale
        
        return self
    
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Predict class probabilities.
        
        Args:
            X: Test data (n_samples, n_features)
            
        Returns:
            Class probabilities (n_samples, 2)
        """
        X = np.asarray(X)
        n_samples = X.shape[0]
        
        # initialize with base prediction
        F = np.full(n_samples, self.init_pred)
        
        # add tree predictions
        for tree in self.trees:
            tree_pred = tree.predict_proba(X)[:, 1] - 0.5
            F += self.learning_rate * tree_pred * 2
        
        # convert to probabilities
        p1 = self._sigmoid(F)
        p0 = 1 - p1
        
        return np.column_stack([p0, p1])
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict class labels.
        
        Args:
            X: Test data (n_samples, n_features)
            
        Returns:
            Predicted labels (n_samples,)
        """
        proba = self.predict_proba(X)
        return (proba[:, 1] > 0.5).astype(int)


class AdaBoostClassifier:
    """AdaBoost (Adaptive Boosting) classifier.
    
    Args:
        n_estimators: Number of boosting stages
        learning_rate: Weight applied to each classifier
        random_state: Random seed
        
    Examples:
        ada = AdaBoostClassifier(n_estimators=50)
        ada.fit(X_train, y_train)
        predictions = ada.predict(X_test)
    """
    
    def __init__(
        self,
        n_estimators: int = 50,
        learning_rate: float = 1.0,
        random_state: Optional[int] = None,
    ):
        self.n_estimators = n_estimators
        self.learning_rate = learning_rate
        self.random_state = random_state
        
        self.estimators: list[DecisionTreeClassifier] = []
        self.estimator_weights: list[float] = []
        self.n_classes: int = 0
        
        if random_state is not None:
            np.random.seed(random_state)
    
    def fit(self, X: np.ndarray, y: np.ndarray) -> AdaBoostClassifier:
        """Fit AdaBoost classifier.
        
        Args:
            X: Training data (n_samples, n_features)
            y: Target labels (n_samples,) - must be 0/1
            
        Returns:
            self
        """
        X = np.asarray(X)
        y = np.asarray(y)
        n_samples = X.shape[0]
        
        self.n_classes = len(np.unique(y))
        if self.n_classes != 2:
            raise ValidationError("n_classes", self.n_classes, "2 (binary classification only)")
        
        # convert labels to -1/+1
        y_coded = 2 * y - 1
        
        # initialize sample weights
        sample_weights = np.ones(n_samples) / n_samples
        
        self.estimators = []
        self.estimator_weights = []
        
        for _ in range(self.n_estimators):
            # train weak learner (decision stump)
            tree = DecisionTreeClassifier(max_depth=1)  # Stump
            
            # sample with weights (bootstrap with replacement)
            indices = np.random.choice(
                n_samples,
                size=n_samples,
                replace=True,
                p=sample_weights
            )
            tree.fit(X[indices], y[indices])
            
            # predict on full dataset
            y_pred = tree.predict(X)
            y_pred_coded = 2 * y_pred - 1
            
            # calculate error
            incorrect = (y_pred_coded != y_coded)
            error = np.sum(sample_weights * incorrect)
            
            # avoid division by zero
            if error >= 0.5:
                break
            
            # calculate estimator weight
            estimator_weight = self.learning_rate * 0.5 * np.log((1 - error + 1e-10) / (error + 1e-10))
            
            # update sample weights
            sample_weights *= np.exp(-estimator_weight * y_coded * y_pred_coded)
            sample_weights /= np.sum(sample_weights)
            
            self.estimators.append(tree)
            self.estimator_weights.append(estimator_weight)
        
        return self
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict class labels.
        
        Args:
            X: Test data (n_samples, n_features)
            
        Returns:
            Predicted labels (n_samples,)
        """
        X = np.asarray(X)
        n_samples = X.shape[0]
        
        # weighted vote
        predictions = np.zeros(n_samples)
        for estimator, weight in zip(self.estimators, self.estimator_weights):
            y_pred = estimator.predict(X)
            y_pred_coded = 2 * y_pred - 1
            predictions += weight * y_pred_coded
        
        # convert back to 0/1
        return (predictions > 0).astype(int)
    
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Predict class probabilities.
        
        Args:
            X: Test data (n_samples, n_features)
            
        Returns:
            Class probabilities (n_samples, 2)
        """
        X = np.asarray(X)
        n_samples = X.shape[0]
        
        # weighted vote
        scores = np.zeros(n_samples)
        for estimator, weight in zip(self.estimators, self.estimator_weights):
            y_pred = estimator.predict(X)
            y_pred_coded = 2 * y_pred - 1
            scores += weight * y_pred_coded
        
        # convert to probabilities using sigmoid
        p1 = 1.0 / (1.0 + np.exp(-scores))
        p0 = 1 - p1
        
        return np.column_stack([p0, p1])


class BaggingClassifier:
    """Bagging (Bootstrap Aggregating) classifier.
    
    Args:
        base_estimator: Base estimator to use (default: DecisionTreeClassifier)
        n_estimators: Number of estimators
        max_samples: Number/fraction of samples to draw
        max_features: Number/fraction of features to draw
        bootstrap: Whether to use bootstrap samples
        random_state: Random seed
        
    Examples:
        bag = BaggingClassifier(n_estimators=10)
        bag.fit(X_train, y_train)
        predictions = bag.predict(X_test)
    """
    
    def __init__(
        self,
        base_estimator=None,
        n_estimators: int = 10,
        max_samples: float = 1.0,
        max_features: float = 1.0,
        bootstrap: bool = True,
        random_state: Optional[int] = None,
    ):
        self.base_estimator = base_estimator
        self.n_estimators = n_estimators
        self.max_samples = max_samples
        self.max_features = max_features
        self.bootstrap = bootstrap
        self.random_state = random_state
        
        self.estimators: list = []
        self.n_classes: int = 0
        
        if random_state is not None:
            np.random.seed(random_state)
    
    def fit(self, X: np.ndarray, y: np.ndarray) -> BaggingClassifier:
        """Fit bagging classifier.
        
        Args:
            X: Training data (n_samples, n_features)
            y: Target labels (n_samples,)
            
        Returns:
            self
        """
        X = np.asarray(X)
        y = np.asarray(y)
        n_samples, n_features = X.shape
        
        self.n_classes = len(np.unique(y))
        
        # calculate sample and feature sizes
        if self.max_samples <= 1.0:
            n_samples_est = int(self.max_samples * n_samples)
        else:
            n_samples_est = int(self.max_samples)
        
        if self.max_features <= 1.0:
            n_features_est = int(self.max_features * n_features)
        else:
            n_features_est = int(self.max_features)
        
        self.estimators = []
        
        for _ in range(self.n_estimators):
            # bootstrap samples
            if self.bootstrap:
                sample_indices = np.random.choice(n_samples, n_samples_est, replace=True)
            else:
                sample_indices = np.random.choice(n_samples, n_samples_est, replace=False)
            
            # random features
            feature_indices = np.random.choice(n_features, n_features_est, replace=False)
            
            # create estimator
            if self.base_estimator is None:
                estimator = DecisionTreeClassifier()
            else:
                # clone base estimator
                estimator = self.base_estimator.__class__(**self.base_estimator.__dict__)
            
            # train on subset
            X_subset = X[sample_indices][:, feature_indices]
            y_subset = y[sample_indices]
            estimator.fit(X_subset, y_subset)
            
            # store with feature indices
            estimator.feature_indices = feature_indices
            self.estimators.append(estimator)
        
        return self
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict class labels.
        
        Args:
            X: Test data (n_samples, n_features)
            
        Returns:
            Predicted labels (n_samples,)
        """
        proba = self.predict_proba(X)
        return np.argmax(proba, axis=1)
    
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Predict class probabilities.
        
        Args:
            X: Test data (n_samples, n_features)
            
        Returns:
            Class probabilities (n_samples, n_classes)
        """
        X = np.asarray(X)
        n_samples = X.shape[0]
        
        all_proba = np.zeros((n_samples, self.n_classes))
        
        for estimator in self.estimators:
            X_subset = X[:, estimator.feature_indices]
            proba = estimator.predict_proba(X_subset)
            all_proba += proba
        
        all_proba /= self.n_estimators
        
        return all_proba


__all__ = [
    "RandomForestClassifier",
    "GradientBoostingClassifier",
    "AdaBoostClassifier",
    "BaggingClassifier",
]
