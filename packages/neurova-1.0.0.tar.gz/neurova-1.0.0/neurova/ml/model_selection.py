# copyright (c) 2025 @analytics withharry
# all rights reserved.
# licensed under the mit license.

"""
Model selection utilities for machine learning

All implementations use NumPy only.
"""

import numpy as np
from typing import Tuple, Optional, Dict, List, Any
from neurova.core.errors import ValidationError


def train_test_split(X: np.ndarray, y: Optional[np.ndarray] = None,
                    test_size: float = 0.25, random_state: Optional[int] = None,
                    shuffle: bool = True) -> Tuple:
    """
    Split arrays into random train and test subsets
    
    Args:
        X: Features array
        y: Target array (optional)
        test_size: Proportion of dataset to include in test split
        random_state: Random state for reproducibility
        shuffle: Whether to shuffle data before splitting
        
    Returns:
        Tuple of train-test splits
    
    Examples:
        >>> X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)
    """
    X = np.asarray(X)
    n_samples = X.shape[0]
    n_test = int(n_samples * test_size)
    n_train = n_samples - n_test
    
    if shuffle:
        rng = np.random.default_rng(random_state)
        indices = rng.permutation(n_samples)
    else:
        indices = np.arange(n_samples)
    
    train_indices = indices[:n_train]
    test_indices = indices[n_train:]
    
    X_train = X[train_indices]
    X_test = X[test_indices]
    
    if y is not None:
        y = np.asarray(y)
        y_train = y[train_indices]
        y_test = y[test_indices]
        return X_train, X_test, y_train, y_test
    
    return X_train, X_test


def cross_validate(estimator, X: np.ndarray, y: np.ndarray, 
                  cv: int = 5, scoring: str = 'accuracy') -> Dict[str, np.ndarray]:
    """
    Evaluate metric(s) by cross-validation
    
    Args:
        estimator: Estimator object with fit and predict methods
        X: Features array
        y: Target array
        cv: Number of folds
        scoring: Scoring metric ('accuracy', 'precision', 'recall', 'f1')
        
    Returns:
        Dictionary with test scores and fit times
    
    Examples:
        >>> from neurova.ml import KNearestNeighbors
        >>> knn = KNearestNeighbors(n_neighbors=5)
        >>> scores = cross_validate(knn, X, y, cv=5)
    """
    from neurova.ml.metrics import (
        accuracy_score, precision_score, recall_score, f1_score
    )
    import time
    
    X = np.asarray(X)
    y = np.asarray(y)
    n_samples = X.shape[0]
    
    # create fold indices
    fold_size = n_samples // cv
    indices = np.arange(n_samples)
    
    test_scores = []
    fit_times = []
    
    for fold in range(cv):
        # create train/test split for this fold
        test_start = fold * fold_size
        test_end = (fold + 1) * fold_size if fold < cv - 1 else n_samples
        
        test_indices = indices[test_start:test_end]
        train_indices = np.concatenate([indices[:test_start], indices[test_end:]])
        
        X_train, X_test = X[train_indices], X[test_indices]
        y_train, y_test = y[train_indices], y[test_indices]
        
        # fit and predict
        start_time = time.time()
        estimator.fit(X_train, y_train)
        fit_time = time.time() - start_time
        
        y_pred = estimator.predict(X_test)
        
        # calculate score
        if scoring == 'accuracy':
            score = accuracy_score(y_test, y_pred)
        elif scoring == 'precision':
            score = precision_score(y_test, y_pred, average='macro')
        elif scoring == 'recall':
            score = recall_score(y_test, y_pred, average='macro')
        elif scoring == 'f1':
            score = f1_score(y_test, y_pred, average='macro')
        else:
            raise ValidationError('scoring', scoring, 'accuracy, precision, recall, or f1')
        
        test_scores.append(score)
        fit_times.append(fit_time)
    
    return {
        'test_score': np.array(test_scores),
        'fit_time': np.array(fit_times),
    }


class GridSearchCV:
    """
    Exhaustive search over specified parameter values
    
    Examples:
        >>> from neurova.ml import KNearestNeighbors
        >>> param_grid = {'n_neighbors': [3, 5, 7]}
        >>> grid = GridSearchCV(KNearestNeighbors(), param_grid, cv=5)
        >>> grid.fit(X, y)
        >>> print(grid.best_params_)
    """
    
    def __init__(self, estimator, param_grid: Dict[str, List],
                 cv: int = 5, scoring: str = 'accuracy'):
        """
        Args:
            estimator: Estimator object (must be class, not instance)
            param_grid: Dictionary with parameters as keys and lists of values
            cv: Number of cross-validation folds
            scoring: Scoring metric
        """
        self.estimator = estimator
        self.param_grid = param_grid
        self.cv = cv
        self.scoring = scoring
        self.best_params_ = None
        self.best_score_ = None
        self.best_estimator_ = None
        self.cv_results_ = None
    
    def _generate_param_combinations(self) -> List[Dict]:
        """Generate all combinations of parameters"""
        import itertools
        
        keys = list(self.param_grid.keys())
        values = list(self.param_grid.values())
        
        combinations = []
        for combination in itertools.product(*values):
            param_dict = dict(zip(keys, combination))
            combinations.append(param_dict)
        
        return combinations
    
    def fit(self, X: np.ndarray, y: np.ndarray) -> 'GridSearchCV':
        """Run grid search"""
        X = np.asarray(X)
        y = np.asarray(y)
        
        param_combinations = self._generate_param_combinations()
        
        results = []
        best_score = -np.inf
        best_params = None
        
        for params in param_combinations:
            # create estimator with these parameters
            estimator = self.estimator(**params)
            
            # cross-validate
            cv_results = cross_validate(estimator, X, y, cv=self.cv, scoring=self.scoring)
            mean_score = cv_results['test_score'].mean()
            
            results.append({
                'params': params,
                'mean_test_score': mean_score,
                'std_test_score': cv_results['test_score'].std(),
                'mean_fit_time': cv_results['fit_time'].mean(),
            })
            
            if mean_score > best_score:
                best_score = mean_score
                best_params = params
        
        # fit best estimator on full dataset
        self.best_params_ = best_params
        self.best_score_ = best_score
        self.best_estimator_ = self.estimator(**best_params)
        self.best_estimator_.fit(X, y)
        self.cv_results_ = results
        
        return self
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict using best estimator"""
        if self.best_estimator_ is None:
            raise ValidationError('grid_search', 'not fitted', 'fitted grid search')
        
        return self.best_estimator_.predict(X)
