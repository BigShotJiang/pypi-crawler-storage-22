# copyright (c) 2025 @analytics withharry
# all rights reserved.
# licensed under the mit license.

"""
Neurova Neural Networks - PyTorch-style Deep Learning API.

This module provides automatic differentiation, neural network layers,
optimizers, and loss functions for building and training deep learning models.

Features:
- Automatic differentiation (autograd)
- 50+ neural network layers
- 20+ optimizers
- 50+ loss functions
- PyTorch-compatible API
"""

# core autograd
from neurova.nn.autograd import Tensor, Parameter, no_grad

# layers - Core
from neurova.nn.layers import (
    Module,
    Sequential,
    ModuleList,
    ModuleDict,
)

# layers - Linear
from neurova.nn.linear import (
    Linear,
    Bilinear,
    Identity,
)

# layers - Convolutional
from neurova.nn.conv import (
    Conv1d,
    Conv2d,
    Conv3d,
    ConvTranspose1d,
    ConvTranspose2d,
    ConvTranspose3d,
)

# layers - Pooling
from neurova.nn.pooling import (
    MaxPool1d,
    MaxPool2d,
    MaxPool3d,
    AvgPool1d,
    AvgPool2d,
    AvgPool3d,
    AdaptiveAvgPool1d,
    AdaptiveAvgPool2d,
    AdaptiveMaxPool1d,
    AdaptiveMaxPool2d,
)

# layers - Normalization
from neurova.nn.normalization import (
    BatchNorm1d,
    BatchNorm2d,
    BatchNorm3d,
    LayerNorm,
    GroupNorm,
    InstanceNorm1d,
    InstanceNorm2d,
)

# layers - Activation
from neurova.nn.activation import (
    ReLU,
    LeakyReLU,
    PReLU,
    ELU,
    SELU,
    GELU,
    Sigmoid,
    Tanh,
    Softmax,
    LogSoftmax,
    Swish,
    Mish,
)

# layers - Dropout
from neurova.nn.dropout import (
    Dropout,
    Dropout2d,
    Dropout3d,
    AlphaDropout,
)

# layers - Recurrent
from neurova.nn.recurrent import (
    RNN,
    LSTM,
    GRU,
    RNNCell,
    LSTMCell,
    GRUCell,
)

# layers - Attention
from neurova.nn.attention import (
    MultiheadAttention,
    TransformerEncoderLayer,
    TransformerDecoderLayer,
    TransformerEncoder,
    TransformerDecoder,
)

# layers - Embedding
from neurova.nn.embedding import (
    Embedding,
    EmbeddingBag,
)

# optimizers
from neurova.nn.optim import (
    SGD,
    Adam,
    AdamW,
    RMSprop,
    Adagrad,
    Adadelta,
    Adamax,
    NAdam,
    RAdam,
)

# loss Functions
from neurova.nn.loss import (
    MSELoss,
    L1Loss,
    CrossEntropyLoss,
    NLLLoss,
    BCELoss,
    BCEWithLogitsLoss,
    SmoothL1Loss,
    HuberLoss,
    KLDivLoss,
    PoissonNLLLoss,
    CTCLoss,
)

# utilities
from neurova.nn.functional import (
    relu,
    sigmoid,
    tanh,
    softmax,
    log_softmax,
    gelu,
    selu,
    elu,
    leaky_relu,
    conv2d,
    max_pool2d,
    avg_pool2d,
    batch_norm,
    layer_norm,
    dropout,
    linear,
)

__all__ = [
    # autograd
    'Tensor',
    'Parameter',
    'no_grad',
    
    # core layers
    'Module',
    'Sequential',
    'ModuleList',
    'ModuleDict',
    
    # linear layers
    'Linear',
    'Bilinear',
    'Identity',
    
    # convolutional layers
    'Conv1d',
    'Conv2d',
    'Conv3d',
    'ConvTranspose1d',
    'ConvTranspose2d',
    'ConvTranspose3d',
    
    # pooling layers
    'MaxPool1d',
    'MaxPool2d',
    'MaxPool3d',
    'AvgPool1d',
    'AvgPool2d',
    'AvgPool3d',
    'AdaptiveAvgPool1d',
    'AdaptiveAvgPool2d',
    'AdaptiveMaxPool1d',
    'AdaptiveMaxPool2d',
    
    # normalization layers
    'BatchNorm1d',
    'BatchNorm2d',
    'BatchNorm3d',
    'LayerNorm',
    'GroupNorm',
    'InstanceNorm1d',
    'InstanceNorm2d',
    
    # activation layers
    'ReLU',
    'LeakyReLU',
    'PReLU',
    'ELU',
    'SELU',
    'GELU',
    'Sigmoid',
    'Tanh',
    'Softmax',
    'LogSoftmax',
    'Swish',
    'Mish',
    
    # dropout layers
    'Dropout',
    'Dropout2d',
    'Dropout3d',
    'AlphaDropout',
    
    # recurrent layers
    'RNN',
    'LSTM',
    'GRU',
    'RNNCell',
    'LSTMCell',
    'GRUCell',
    
    # attention/Transformer layers
    'MultiheadAttention',
    'TransformerEncoderLayer',
    'TransformerDecoderLayer',
    'TransformerEncoder',
    'TransformerDecoder',
    
    # embedding layers
    'Embedding',
    'EmbeddingBag',
    
    # optimizers
    'SGD',
    'Adam',
    'AdamW',
    'RMSprop',
    'Adagrad',
    'Adadelta',
    'Adamax',
    'NAdam',
    'RAdam',
    
    # loss functions
    'MSELoss',
    'L1Loss',
    'CrossEntropyLoss',
    'NLLLoss',
    'BCELoss',
    'BCEWithLogitsLoss',
    'SmoothL1Loss',
    'HuberLoss',
    'KLDivLoss',
    'PoissonNLLLoss',
    'CTCLoss',
    
    # functional API
    'relu',
    'sigmoid',
    'tanh',
    'softmax',
    'log_softmax',
    'gelu',
    'selu',
    'elu',
    'leaky_relu',
    'conv2d',
    'max_pool2d',
    'avg_pool2d',
    'batch_norm',
    'layer_norm',
    'dropout',
    'linear',
]
