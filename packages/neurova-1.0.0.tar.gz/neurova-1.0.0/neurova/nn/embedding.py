# copyright (c) 2025 @analytics withharry
# all rights reserved.
# licensed under the mit license.

"""Embedding, Functional - Placeholders."""
from neurova.nn.layers import Module

class Embedding(Module):
    def __init__(self, num_embeddings, embedding_dim): super().__init__()
    def forward(self, x): return x
class EmbeddingBag(Module):
    def __init__(self, num_embeddings, embedding_dim): super().__init__()
    def forward(self, x): return x
