# copyright (c) 2025 @analytics withharry
# all rights reserved.
# licensed under the mit license.

"""Functional API - Placeholders."""

def relu(x): return x.relu()
def sigmoid(x): return x.sigmoid()
def tanh(x): return x.tanh()
def softmax(x, dim=-1): return x
def log_softmax(x, dim=-1): return x
def gelu(x): return x
def selu(x): return x
def elu(x): return x
def leaky_relu(x, negative_slope=0.01): return x
def conv2d(x, weight, bias=None): return x
def max_pool2d(x, kernel_size): return x
def avg_pool2d(x, kernel_size): return x
def batch_norm(x, running_mean, running_var): return x
def layer_norm(x, normalized_shape): return x
def dropout(x, p=0.5, training=True): return x
def linear(x, weight, bias=None): return x @ weight.T + (bias if bias is not None else 0)
