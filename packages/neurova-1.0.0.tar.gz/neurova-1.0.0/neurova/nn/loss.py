# copyright (c) 2025 @analytics withharry
# all rights reserved.
# licensed under the mit license.

"""
Loss functions for training neural networks.

Similar to PyTorch's torch.nn loss functions.
"""

from __future__ import annotations
import numpy as np
from neurova.nn.layers import Module
from neurova.nn.autograd import Tensor


class MSELoss(Module):
    """
    Mean Squared Error loss.
    
    Similar to torch.nn.MSELoss.
    
    L = (1/n) * sum((y_pred - y_true)^2)
    """
    
    def forward(self, pred: Tensor, target: Tensor) -> Tensor:
        """Compute MSE loss."""
        diff = pred - target
        return (diff * diff).mean()


class L1Loss(Module):
    """
    Mean Absolute Error loss.
    
    Similar to torch.nn.L1Loss.
    
    L = (1/n) * sum(|y_pred - y_true|)
    """
    
    def forward(self, pred: Tensor, target: Tensor) -> Tensor:
        """Compute L1 loss."""
        diff = pred - target
        # absolute value via sqrt(x^2)
        return (diff * diff).sum() ** 0.5 / pred.size


class CrossEntropyLoss(Module):
    """
    Cross entropy loss for classification.
    
    Similar to torch.nn.CrossEntropyLoss.
    Combines LogSoftmax and NLLLoss.
    """
    
    def forward(self, pred: Tensor, target: Tensor) -> Tensor:
        """
        Compute cross entropy loss.
        
        Parameters
        ----------
        pred : Tensor
            Predictions of shape (N, C) where C is number of classes
        target : Tensor
            Target class indices of shape (N,)
        """
        # log softmax
        exp_x = Tensor(np.exp(pred.data - np.max(pred.data, axis=-1, keepdims=True)))
        log_softmax = pred - Tensor(np.log(exp_x.data.sum(axis=-1, keepdims=True)))
        
        # negative log likelihood
        N = pred.shape[0]
        C = pred.shape[1]
        
        # create one-hot encoding
        target_data = target.data.astype(int).flatten()
        one_hot = np.zeros((N, C), dtype=np.float32)
        one_hot[np.arange(N), target_data] = 1.0
        
        # compute loss
        loss = -(log_softmax * Tensor(one_hot)).sum() / N
        return loss


class NLLLoss(Module):
    """
    Negative Log Likelihood loss.
    
    Similar to torch.nn.NLLLoss.
    """
    
    def forward(self, pred: Tensor, target: Tensor) -> Tensor:
        """Compute NLL loss."""
        N = pred.shape[0]
        C = pred.shape[1]
        
        # create one-hot encoding
        target_data = target.data.astype(int).flatten()
        one_hot = np.zeros((N, C), dtype=np.float32)
        one_hot[np.arange(N), target_data] = 1.0
        
        # compute loss
        loss = -(pred * Tensor(one_hot)).sum() / N
        return loss


class BCELoss(Module):
    """
    Binary Cross Entropy loss.
    
    Similar to torch.nn.BCELoss.
    """
    
    def forward(self, pred: Tensor, target: Tensor) -> Tensor:
        """Compute BCE loss."""
        eps = 1e-7
        pred_clipped = Tensor(np.clip(pred.data, eps, 1 - eps))
        
        # bCE = -[y*log(p) + (1-y)*log(1-p)]
        term1 = target * Tensor(np.log(pred_clipped.data))
        term2 = (1 - target) * Tensor(np.log(1 - pred_clipped.data))
        return -(term1 + term2).mean()


class BCEWithLogitsLoss(Module):
    """
    Binary Cross Entropy with Logits loss (more numerically stable).
    
    Similar to torch.nn.BCEWithLogitsLoss.
    """
    
    def forward(self, pred: Tensor, target: Tensor) -> Tensor:
        """Compute BCE with logits loss."""
        # numerically stable: max(x,0) - x*y + log(1 + exp(-|x|))
        max_val = Tensor(np.maximum(pred.data, 0))
        loss = max_val - pred * target + Tensor(np.log(1 + np.exp(-np.abs(pred.data))))
        return loss.mean()


class SmoothL1Loss(Module):
    """
    Smooth L1 loss (Huber loss).
    
    Similar to torch.nn.SmoothL1Loss.
    """
    
    def __init__(self, beta: float = 1.0):
        super().__init__()
        self.beta = beta
    
    def forward(self, pred: Tensor, target: Tensor) -> Tensor:
        """Compute smooth L1 loss."""
        diff = pred - target
        abs_diff = Tensor(np.abs(diff.data))
        
        # use L2 when |diff| < beta, L1 otherwise
        l2_loss = 0.5 * (diff * diff) / self.beta
        l1_loss = abs_diff - 0.5 * self.beta
        
        # combine using mask
        mask = (abs_diff.data < self.beta).astype(np.float32)
        loss = Tensor(mask) * l2_loss + Tensor(1 - mask) * l1_loss
        return loss.mean()


class HuberLoss(Module):
    """
    Huber loss.
    
    Similar to torch.nn.HuberLoss.
    """
    
    def __init__(self, delta: float = 1.0):
        super().__init__()
        self.delta = delta
    
    def forward(self, pred: Tensor, target: Tensor) -> Tensor:
        """Compute Huber loss."""
        diff = pred - target
        abs_diff = Tensor(np.abs(diff.data))
        
        # quadratic when |diff| <= delta, linear otherwise
        quadratic = 0.5 * (diff * diff)
        linear = self.delta * (abs_diff - 0.5 * self.delta)
        
        mask = (abs_diff.data <= self.delta).astype(np.float32)
        loss = Tensor(mask) * quadratic + Tensor(1 - mask) * linear
        return loss.mean()


class KLDivLoss(Module):
    """
    Kullback-Leibler divergence loss.
    
    Similar to torch.nn.KLDivLoss.
    """
    
    def forward(self, pred: Tensor, target: Tensor) -> Tensor:
        """Compute KL divergence loss."""
        eps = 1e-7
        target_clipped = Tensor(np.clip(target.data, eps, 1))
        pred_clipped = Tensor(np.clip(pred.data, eps, 1))
        
        # kL(P||Q) = sum(P * log(P/Q))
        loss = target * (Tensor(np.log(target_clipped.data)) - Tensor(np.log(pred_clipped.data)))
        return loss.sum()


class PoissonNLLLoss(Module):
    """
    Poisson Negative Log Likelihood loss.
    
    Similar to torch.nn.PoissonNLLLoss.
    """
    
    def __init__(self, log_input: bool = True):
        super().__init__()
        self.log_input = log_input
    
    def forward(self, pred: Tensor, target: Tensor) -> Tensor:
        """Compute Poisson NLL loss."""
        if self.log_input:
            # pred is log(lambda)
            loss = Tensor(np.exp(pred.data)) - target * pred
        else:
            # pred is lambda
            eps = 1e-7
            loss = pred - target * Tensor(np.log(pred.data + eps))
        
        return loss.mean()


class CTCLoss(Module):
    """
    Connectionist Temporal Classification loss (simplified).
    
    Similar to torch.nn.CTCLoss (simplified version).
    Note: Full CTC requires dynamic programming - this is a placeholder.
    """
    
    def forward(self, pred: Tensor, target: Tensor, input_lengths: Tensor, target_lengths: Tensor) -> Tensor:
        """
        Compute CTC loss (simplified).
        
        Note: This is a placeholder. Full CTC implementation requires
        complex dynamic programming algorithms.
        """
        raise NotImplementedError("Full CTC loss requires complex DP - use specialized library")
