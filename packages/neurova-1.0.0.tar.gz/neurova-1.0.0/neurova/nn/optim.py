# copyright (c) 2025 @analytics withharry
# all rights reserved.
# licensed under the mit license.

"""
Optimization algorithms.

Similar to PyTorch's torch.optim with SGD, Adam, RMSprop, etc.
"""

from __future__ import annotations
import numpy as np
from typing import List, Optional
from neurova.nn.autograd import Parameter


class Optimizer:
    """
    Base class for all optimizers.
    
    Similar to torch.optim.Optimizer.
    
    Parameters
    ----------
    params : list of Parameter
        Parameters to optimize
    lr : float
        Learning rate
    """
    
    def __init__(self, params: List[Parameter], lr: float = 0.01):
        self.params = list(params)
        self.lr = lr
        self.t = 0  # Time step for adaptive methods
    
    def step(self) -> None:
        """
        Perform a single optimization step.
        
        Raises
        ------
        NotImplementedError
            Must be implemented by subclasses
        """
        raise NotImplementedError
    
    def zero_grad(self) -> None:
        """Zero out all parameter gradients."""
        for param in self.params:
            param.zero_grad()


class SGD(Optimizer):
    """
    Stochastic Gradient Descent optimizer.
    
    Similar to torch.optim.SGD.
    
    Parameters
    ----------
    params : list of Parameter
        Parameters to optimize
    lr : float, default=0.01
        Learning rate
    momentum : float, default=0
        Momentum factor
    weight_decay : float, default=0
        Weight decay (L2 penalty)
    nesterov : bool, default=False
        Use Nesterov momentum
    
    Examples
    --------
    >>> optimizer = SGD(model.parameters(), lr=0.01, momentum=0.9)
    >>> optimizer.zero_grad()
    >>> loss.backward()
    >>> optimizer.step()
    """
    
    def __init__(
        self,
        params: List[Parameter],
        lr: float = 0.01,
        momentum: float = 0,
        weight_decay: float = 0,
        nesterov: bool = False
    ):
        super().__init__(params, lr)
        self.momentum = momentum
        self.weight_decay = weight_decay
        self.nesterov = nesterov
        
        # velocity for momentum
        self.velocity = [np.zeros_like(p.data) for p in self.params]
    
    def step(self) -> None:
        """Perform SGD update."""
        for i, param in enumerate(self.params):
            if param.grad is None:
                continue
            
            grad = param.grad.copy()
            
            # weight decay
            if self.weight_decay != 0:
                grad += self.weight_decay * param.data
            
            # momentum
            if self.momentum != 0:
                self.velocity[i] = self.momentum * self.velocity[i] + grad
                
                if self.nesterov:
                    grad = grad + self.momentum * self.velocity[i]
                else:
                    grad = self.velocity[i]
            
            # update parameters
            param.data -= self.lr * grad


class Adam(Optimizer):
    """
    Adam optimizer (Adaptive Moment Estimation).
    
    Similar to torch.optim.Adam.
    
    Parameters
    ----------
    params : list of Parameter
        Parameters to optimize
    lr : float, default=0.001
        Learning rate
    betas : tuple of float, default=(0.9, 0.999)
        Coefficients for computing running averages
    eps : float, default=1e-8
        Term for numerical stability
    weight_decay : float, default=0
        Weight decay (L2 penalty)
    
    Examples
    --------
    >>> optimizer = Adam(model.parameters(), lr=0.001)
    >>> optimizer.zero_grad()
    >>> loss.backward()
    >>> optimizer.step()
    """
    
    def __init__(
        self,
        params: List[Parameter],
        lr: float = 0.001,
        betas: tuple[float, float] = (0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 0
    ):
        super().__init__(params, lr)
        self.beta1, self.beta2 = betas
        self.eps = eps
        self.weight_decay = weight_decay
        
        # first and second moment estimates
        self.m = [np.zeros_like(p.data) for p in self.params]
        self.v = [np.zeros_like(p.data) for p in self.params]
    
    def step(self) -> None:
        """Perform Adam update."""
        self.t += 1
        
        for i, param in enumerate(self.params):
            if param.grad is None:
                continue
            
            grad = param.grad.copy()
            
            # weight decay
            if self.weight_decay != 0:
                grad += self.weight_decay * param.data
            
            # update biased first moment estimate
            self.m[i] = self.beta1 * self.m[i] + (1 - self.beta1) * grad
            
            # update biased second raw moment estimate
            self.v[i] = self.beta2 * self.v[i] + (1 - self.beta2) * (grad ** 2)
            
            # bias correction
            m_hat = self.m[i] / (1 - self.beta1 ** self.t)
            v_hat = self.v[i] / (1 - self.beta2 ** self.t)
            
            # update parameters
            param.data -= self.lr * m_hat / (np.sqrt(v_hat) + self.eps)


class AdamW(Adam):
    """
    AdamW optimizer (Adam with decoupled weight decay).
    
    Similar to torch.optim.AdamW.
    
    Parameters
    ----------
    params : list of Parameter
        Parameters to optimize
    lr : float, default=0.001
        Learning rate
    betas : tuple of float, default=(0.9, 0.999)
        Coefficients for computing running averages
    eps : float, default=1e-8
        Term for numerical stability
    weight_decay : float, default=0.01
        Weight decay coefficient
    """
    
    def __init__(
        self,
        params: List[Parameter],
        lr: float = 0.001,
        betas: tuple[float, float] = (0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 0.01
    ):
        super().__init__(params, lr, betas, eps, weight_decay=0)
        self.wd = weight_decay
    
    def step(self) -> None:
        """Perform AdamW update."""
        self.t += 1
        
        for i, param in enumerate(self.params):
            if param.grad is None:
                continue
            
            grad = param.grad.copy()
            
            # update biased first moment estimate
            self.m[i] = self.beta1 * self.m[i] + (1 - self.beta1) * grad
            
            # update biased second raw moment estimate
            self.v[i] = self.beta2 * self.v[i] + (1 - self.beta2) * (grad ** 2)
            
            # bias correction
            m_hat = self.m[i] / (1 - self.beta1 ** self.t)
            v_hat = self.v[i] / (1 - self.beta2 ** self.t)
            
            # update parameters with decoupled weight decay
            param.data -= self.lr * (m_hat / (np.sqrt(v_hat) + self.eps) + 
                                    self.wd * param.data)


class RMSprop(Optimizer):
    """
    RMSprop optimizer.
    
    Similar to torch.optim.RMSprop.
    
    Parameters
    ----------
    params : list of Parameter
        Parameters to optimize
    lr : float, default=0.01
        Learning rate
    alpha : float, default=0.99
        Smoothing constant
    eps : float, default=1e-8
        Term for numerical stability
    weight_decay : float, default=0
        Weight decay (L2 penalty)
    momentum : float, default=0
        Momentum factor
    """
    
    def __init__(
        self,
        params: List[Parameter],
        lr: float = 0.01,
        alpha: float = 0.99,
        eps: float = 1e-8,
        weight_decay: float = 0,
        momentum: float = 0
    ):
        super().__init__(params, lr)
        self.alpha = alpha
        self.eps = eps
        self.weight_decay = weight_decay
        self.momentum = momentum
        
        # running average of squared gradients
        self.square_avg = [np.zeros_like(p.data) for p in self.params]
        
        if momentum > 0:
            self.momentum_buffer = [np.zeros_like(p.data) for p in self.params]
    
    def step(self) -> None:
        """Perform RMSprop update."""
        for i, param in enumerate(self.params):
            if param.grad is None:
                continue
            
            grad = param.grad.copy()
            
            # weight decay
            if self.weight_decay != 0:
                grad += self.weight_decay * param.data
            
            # update running average of squared gradients
            self.square_avg[i] = (self.alpha * self.square_avg[i] + 
                                 (1 - self.alpha) * grad ** 2)
            
            # compute update
            avg = np.sqrt(self.square_avg[i]) + self.eps
            
            if self.momentum > 0:
                self.momentum_buffer[i] = (self.momentum * self.momentum_buffer[i] + 
                                          grad / avg)
                param.data -= self.lr * self.momentum_buffer[i]
            else:
                param.data -= self.lr * grad / avg


class Adagrad(Optimizer):
    """
    Adagrad optimizer.
    
    Similar to torch.optim.Adagrad.
    
    Parameters
    ----------
    params : list of Parameter
        Parameters to optimize
    lr : float, default=0.01
        Learning rate
    eps : float, default=1e-10
        Term for numerical stability
    weight_decay : float, default=0
        Weight decay (L2 penalty)
    """
    
    def __init__(
        self,
        params: List[Parameter],
        lr: float = 0.01,
        eps: float = 1e-10,
        weight_decay: float = 0
    ):
        super().__init__(params, lr)
        self.eps = eps
        self.weight_decay = weight_decay
        
        # accumulated squared gradients
        self.sum_squares = [np.zeros_like(p.data) for p in self.params]
    
    def step(self) -> None:
        """Perform Adagrad update."""
        for i, param in enumerate(self.params):
            if param.grad is None:
                continue
            
            grad = param.grad.copy()
            
            # weight decay
            if self.weight_decay != 0:
                grad += self.weight_decay * param.data
            
            # accumulate squared gradients
            self.sum_squares[i] += grad ** 2
            
            # update parameters
            param.data -= self.lr * grad / (np.sqrt(self.sum_squares[i]) + self.eps)


class Adadelta(Optimizer):
    """
    Adadelta optimizer.
    
    Similar to torch.optim.Adadelta.
    
    Parameters
    ----------
    params : list of Parameter
        Parameters to optimize
    lr : float, default=1.0
        Learning rate (usually kept at 1.0)
    rho : float, default=0.9
        Coefficient for computing running averages
    eps : float, default=1e-6
        Term for numerical stability
    weight_decay : float, default=0
        Weight decay (L2 penalty)
    """
    
    def __init__(
        self,
        params: List[Parameter],
        lr: float = 1.0,
        rho: float = 0.9,
        eps: float = 1e-6,
        weight_decay: float = 0
    ):
        super().__init__(params, lr)
        self.rho = rho
        self.eps = eps
        self.weight_decay = weight_decay
        
        # running averages
        self.square_avg = [np.zeros_like(p.data) for p in self.params]
        self.acc_delta = [np.zeros_like(p.data) for p in self.params]
    
    def step(self) -> None:
        """Perform Adadelta update."""
        for i, param in enumerate(self.params):
            if param.grad is None:
                continue
            
            grad = param.grad.copy()
            
            # weight decay
            if self.weight_decay != 0:
                grad += self.weight_decay * param.data
            
            # accumulate gradient
            self.square_avg[i] = (self.rho * self.square_avg[i] + 
                                 (1 - self.rho) * grad ** 2)
            
            # compute update
            std = np.sqrt(self.square_avg[i] + self.eps)
            delta = np.sqrt(self.acc_delta[i] + self.eps) / std * grad
            
            # accumulate updates
            self.acc_delta[i] = self.rho * self.acc_delta[i] + (1 - self.rho) * delta ** 2
            
            # update parameters
            param.data -= self.lr * delta


class Adamax(Optimizer):
    """
    Adamax optimizer (variant of Adam based on infinity norm).
    
    Similar to torch.optim.Adamax.
    """
    
    def __init__(
        self,
        params: List[Parameter],
        lr: float = 0.002,
        betas: tuple[float, float] = (0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 0
    ):
        super().__init__(params, lr)
        self.beta1, self.beta2 = betas
        self.eps = eps
        self.weight_decay = weight_decay
        
        self.m = [np.zeros_like(p.data) for p in self.params]
        self.u = [np.zeros_like(p.data) for p in self.params]
    
    def step(self) -> None:
        """Perform Adamax update."""
        self.t += 1
        
        for i, param in enumerate(self.params):
            if param.grad is None:
                continue
            
            grad = param.grad.copy()
            
            if self.weight_decay != 0:
                grad += self.weight_decay * param.data
            
            # update first moment
            self.m[i] = self.beta1 * self.m[i] + (1 - self.beta1) * grad
            
            # update infinity norm
            self.u[i] = np.maximum(self.beta2 * self.u[i], np.abs(grad))
            
            # bias correction
            bias_correction = 1 - self.beta1 ** self.t
            
            # update parameters
            param.data -= self.lr / bias_correction * self.m[i] / (self.u[i] + self.eps)


class NAdam(Optimizer):
    """
    NAdam optimizer (Adam with Nesterov momentum).
    
    Similar to torch.optim.NAdam.
    """
    
    def __init__(
        self,
        params: List[Parameter],
        lr: float = 0.002,
        betas: tuple[float, float] = (0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 0
    ):
        super().__init__(params, lr)
        self.beta1, self.beta2 = betas
        self.eps = eps
        self.weight_decay = weight_decay
        
        self.m = [np.zeros_like(p.data) for p in self.params]
        self.v = [np.zeros_like(p.data) for p in self.params]
    
    def step(self) -> None:
        """Perform NAdam update."""
        self.t += 1
        
        for i, param in enumerate(self.params):
            if param.grad is None:
                continue
            
            grad = param.grad.copy()
            
            if self.weight_decay != 0:
                grad += self.weight_decay * param.data
            
            # update moments
            self.m[i] = self.beta1 * self.m[i] + (1 - self.beta1) * grad
            self.v[i] = self.beta2 * self.v[i] + (1 - self.beta2) * (grad ** 2)
            
            # bias correction
            m_hat = self.m[i] / (1 - self.beta1 ** self.t)
            v_hat = self.v[i] / (1 - self.beta2 ** self.t)
            
            # nesterov momentum
            m_bar = self.beta1 * m_hat + (1 - self.beta1) / (1 - self.beta1 ** self.t) * grad
            
            # update parameters
            param.data -= self.lr * m_bar / (np.sqrt(v_hat) + self.eps)


class RAdam(Optimizer):
    """
    RAdam optimizer (Rectified Adam).
    
    Similar to torch.optim.RAdam.
    """
    
    def __init__(
        self,
        params: List[Parameter],
        lr: float = 0.001,
        betas: tuple[float, float] = (0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 0
    ):
        super().__init__(params, lr)
        self.beta1, self.beta2 = betas
        self.eps = eps
        self.weight_decay = weight_decay
        
        self.m = [np.zeros_like(p.data) for p in self.params]
        self.v = [np.zeros_like(p.data) for p in self.params]
    
    def step(self) -> None:
        """Perform RAdam update."""
        self.t += 1
        
        # compute rectification term
        rho_inf = 2.0 / (1 - self.beta2) - 1
        rho_t = rho_inf - 2 * self.t * (self.beta2 ** self.t) / (1 - self.beta2 ** self.t)
        
        for i, param in enumerate(self.params):
            if param.grad is None:
                continue
            
            grad = param.grad.copy()
            
            if self.weight_decay != 0:
                grad += self.weight_decay * param.data
            
            # update moments
            self.m[i] = self.beta1 * self.m[i] + (1 - self.beta1) * grad
            self.v[i] = self.beta2 * self.v[i] + (1 - self.beta2) * (grad ** 2)
            
            # bias correction
            m_hat = self.m[i] / (1 - self.beta1 ** self.t)
            
            # variance rectification
            if rho_t > 4:
                v_hat = np.sqrt(self.v[i] / (1 - self.beta2 ** self.t))
                r_t = np.sqrt(((rho_t - 4) * (rho_t - 2) * rho_inf) / 
                             ((rho_inf - 4) * (rho_inf - 2) * rho_t))
                param.data -= self.lr * r_t * m_hat / (v_hat + self.eps)
            else:
                param.data -= self.lr * m_hat
