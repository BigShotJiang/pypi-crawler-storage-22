# copyright (c) 2025 @analytics withharry
# all rights reserved.
# licensed under the mit license.

"""Video processing for Neurova"""

from neurova.video.capture import VideoCapture, VideoWriter

__all__ = [
    "VideoCapture",
    "VideoWriter",
]
