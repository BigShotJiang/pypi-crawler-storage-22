THINK_TAG_PATTERN = r"(?:<think>)?.*?</think>"
