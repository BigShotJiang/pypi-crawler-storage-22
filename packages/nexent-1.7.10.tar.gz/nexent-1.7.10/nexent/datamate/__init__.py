"""
DataMate SDK client for interacting with DataMate knowledge base APIs.
"""
from .datamate_client import DataMateClient

__all__ = ["DataMateClient"]

