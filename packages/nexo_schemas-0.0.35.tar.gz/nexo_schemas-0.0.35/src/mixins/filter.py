from functools import cached_property
import re
from abc import ABC, abstractmethod
from datetime import date, datetime
from enum import StrEnum
from pydantic import BaseModel, Field, field_validator, model_validator
from typing import (
    Annotated,
    ClassVar,
    Generic,
    Literal,
    Self,
    TypeGuard,
    TypeVar,
    overload,
)
from nexo.types.string import OptStr, ListOfStrs
from ..error.enums import ErrorCode


class RangeType(StrEnum):
    DATE = "date"
    DATETIME = "datetime"
    FLOAT = "float"
    INTEGER = "integer"
    STRING = "string"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


TypeT = TypeVar("TypeT", bound=RangeType)


RANGE_TYPE_TO_REGEX_MAP: dict[RangeType, str] = {
    RangeType.DATE: (
        r"^(?P<type>date)"
        r"\|(?P<name>[a-z_]+)"
        r"(?:\|from::(?P<from>\d{4}-\d{2}-\d{2}))?"
        r"(?:\|to::(?P<to>\d{4}-\d{2}-\d{2}))?$"
    ),
    RangeType.DATETIME: (
        r"^(?P<type>datetime)"
        r"\|(?P<name>[a-z_]+)"
        r"(?:\|from::(?P<from>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})))?"
        r"(?:\|to::(?P<to>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})))?$"
    ),
    RangeType.FLOAT: (
        r"^(?P<type>float)"
        r"\|(?P<name>[a-z_]+)"
        r"(?:\|from::(?P<from>-?\d+(?:\.\d+)?))?"
        r"(?:\|to::(?P<to>-?\d+(?:\.\d+)?))?$"
    ),
    RangeType.INTEGER: (
        r"^(?P<type>integer)"
        r"\|(?P<name>[a-z_]+)"
        r"(?:\|from::(?P<from>-?\d+))?"
        r"(?:\|to::(?P<to>-?\d+))?$"
    ),
    RangeType.STRING: (
        r"^(?P<type>string)"
        r"\|(?P<name>[a-z_]+)"
        r"(?:\|from::(?P<from>[^|]+))?"
        r"(?:\|to::(?P<to>[^|]+))?$"
    ),
}


RANGE_TYPE_TO_PATTERN_MAP: dict[RangeType, re.Pattern[str]] = {
    type: re.compile(regex) for type, regex in RANGE_TYPE_TO_REGEX_MAP.items()
}


RangeValue = date | datetime | float | int | str
ValueT = TypeVar("ValueT", bound=RangeValue)


class GenericRangeFilter(ABC, BaseModel, Generic[TypeT, ValueT]):
    pattern: ClassVar[re.Pattern[str]]

    type: Annotated[TypeT, Field(..., description="Range type")]
    name: Annotated[str, Field(..., description="Name")]
    from_value: Annotated[ValueT | None, Field(None, description="From value")] = None
    to_value: Annotated[ValueT | None, Field(None, description="To value")] = None

    @cached_property
    def from_str(self) -> OptStr:
        return f"|from::{str(self.from_value)}" if self.from_value is not None else None

    @cached_property
    def to_str(self) -> OptStr:
        return f"|to::{str(self.to_value)}" if self.to_value is not None else None

    @model_validator(mode="after")
    def validate_values(self) -> Self:
        if self.from_value is None and self.from_value is None:
            raise ValueError(
                ErrorCode.BAD_REQUEST, "Either 'from_value' or 'to_value' must be given"
            )
        return self

    @classmethod
    def _convert_type(cls, type: str) -> RangeType:
        try:
            return RangeType(type)
        except ValueError as ve:
            raise ValueError(
                ErrorCode.BAD_REQUEST,
                f"Invalid range type: {type}",
                f"Allowed types: {RangeType.choices()}",
            ) from ve

    @classmethod
    @abstractmethod
    def _validate_type(cls, type: str) -> TypeT: ...

    @classmethod
    @abstractmethod
    def _convert_values(
        cls, from_raw: OptStr, to_raw: OptStr
    ) -> tuple[ValueT | None, ValueT | None]: ...

    @classmethod
    def parse_string(
        cls, filter: str
    ) -> tuple[TypeT, str, ValueT | None, ValueT | None]:
        match = cls.pattern.match(filter)
        if not match:
            raise ValueError(
                ErrorCode.BAD_REQUEST, f"Invalid filter format: {filter!r}"
            )

        type = match.group("type")
        if not type:
            raise ValueError(ErrorCode.BAD_REQUEST, "Type part can not be None")

        validated_type = cls._validate_type(type)

        name = match.group("name")
        if not name:
            raise ValueError(ErrorCode.BAD_REQUEST, "Name part can not be None")

        from_raw: OptStr = match.group("from")
        to_raw: OptStr = match.group("to")

        if not from_raw and not to_raw:
            raise ValueError(
                ErrorCode.BAD_REQUEST, "Either from or to part must be given"
            )

        from_value, to_value = cls._convert_values(from_raw, to_raw)

        return (validated_type, name, from_value, to_value)

    @classmethod
    def from_string(cls, filter: str) -> Self:
        type, name, from_value, to_value = cls.parse_string(filter)
        return cls(type=type, name=name, from_value=from_value, to_value=to_value)

    def to_string(self) -> str:
        result = f"{self.type}|{self.name}"
        if self.from_str is not None:
            result += self.from_str
        if self.to_str is not None:
            result += self.to_str
        return result


class DateFilter(GenericRangeFilter[Literal[RangeType.DATE], date]):
    pattern: ClassVar[re.Pattern[str]] = RANGE_TYPE_TO_PATTERN_MAP[RangeType.DATE]

    type: Annotated[
        Literal[RangeType.DATE], Field(RangeType.DATE, description="Range type")
    ] = RangeType.DATE

    @cached_property
    def from_str(self) -> OptStr:
        return (
            f"|from::{self.from_value.isoformat()}"
            if self.from_value is not None
            else None
        )

    @cached_property
    def to_str(self) -> OptStr:
        return (
            f"|to::{self.to_value.isoformat()}" if self.to_value is not None else None
        )

    @classmethod
    def _validate_type(cls, type: str) -> Literal[RangeType.DATE]:
        converted_type = cls._convert_type(type)
        if converted_type is not RangeType.DATE:
            raise ValueError(
                ErrorCode.BAD_REQUEST, f"Filter type must be '{RangeType.DATE}'"
            )
        return converted_type

    @classmethod
    def _convert_values(
        cls, from_raw: OptStr, to_raw: OptStr
    ) -> tuple[date | None, date | None]:
        try:
            from_date = date.fromisoformat(from_raw) if from_raw else None
            to_date = date.fromisoformat(to_raw) if to_raw else None
        except Exception as e:
            raise ValueError(
                ErrorCode.BAD_REQUEST, "Failed converting raw filter value"
            ) from e

        return from_date, to_date


OptDateFilter = DateFilter | None
ListOfDateFilters = list[DateFilter]


class DatetimeFilter(GenericRangeFilter[Literal[RangeType.DATETIME], datetime]):
    pattern: ClassVar[re.Pattern[str]] = RANGE_TYPE_TO_PATTERN_MAP[RangeType.DATETIME]

    type: Annotated[
        Literal[RangeType.DATETIME], Field(RangeType.DATETIME, description="Range type")
    ] = RangeType.DATETIME

    @cached_property
    def from_str(self) -> OptStr:
        return (
            f"|from::{self.from_value.isoformat()}"
            if self.from_value is not None
            else None
        )

    @cached_property
    def to_str(self) -> OptStr:
        return (
            f"|to::{self.to_value.isoformat()}" if self.to_value is not None else None
        )

    @classmethod
    def _validate_type(cls, type: str) -> Literal[RangeType.DATETIME]:
        converted_type = cls._convert_type(type)
        if converted_type is not RangeType.DATETIME:
            raise ValueError(
                ErrorCode.BAD_REQUEST, f"Filter type must be '{RangeType.DATETIME}'"
            )
        return converted_type

    @classmethod
    def _convert_values(
        cls, from_raw: OptStr, to_raw: OptStr
    ) -> tuple[datetime | None, datetime | None]:
        try:
            from_datetime = datetime.fromisoformat(from_raw) if from_raw else None
            to_datetime = datetime.fromisoformat(to_raw) if to_raw else None
        except Exception as e:
            raise ValueError(
                ErrorCode.BAD_REQUEST, "Failed converting raw filter value"
            ) from e

        return from_datetime, to_datetime


OptDatetimeFilter = DatetimeFilter | None
ListOfDatetimeFilters = list[DatetimeFilter]


class FloatFilter(GenericRangeFilter[Literal[RangeType.FLOAT], float]):
    pattern: ClassVar[re.Pattern[str]] = RANGE_TYPE_TO_PATTERN_MAP[RangeType.FLOAT]

    type: Annotated[
        Literal[RangeType.FLOAT], Field(RangeType.FLOAT, description="Range type")
    ] = RangeType.FLOAT

    @classmethod
    def _validate_type(cls, type: str) -> Literal[RangeType.FLOAT]:
        converted_type = cls._convert_type(type)
        if converted_type is not RangeType.FLOAT:
            raise ValueError(
                ErrorCode.BAD_REQUEST, f"Filter type must be '{RangeType.FLOAT}'"
            )
        return converted_type

    @classmethod
    def _convert_values(
        cls, from_raw: OptStr, to_raw: OptStr
    ) -> tuple[float | None, float | None]:
        try:
            from_datetime = float(from_raw) if from_raw else None
            to_datetime = float(to_raw) if to_raw else None
        except Exception as e:
            raise ValueError(
                ErrorCode.BAD_REQUEST, "Failed converting raw filter value"
            ) from e

        return from_datetime, to_datetime


OptFloatFilter = FloatFilter | None
ListOfFloatFilters = list[FloatFilter]


class IntegerFilter(GenericRangeFilter[Literal[RangeType.INTEGER], int]):
    pattern: ClassVar[re.Pattern[str]] = RANGE_TYPE_TO_PATTERN_MAP[RangeType.INTEGER]

    type: Annotated[
        Literal[RangeType.INTEGER], Field(RangeType.INTEGER, description="Range type")
    ] = RangeType.INTEGER

    @classmethod
    def _validate_type(cls, type: str) -> Literal[RangeType.INTEGER]:
        converted_type = cls._convert_type(type)
        if converted_type is not RangeType.INTEGER:
            raise ValueError(
                ErrorCode.BAD_REQUEST, f"Filter type must be '{RangeType.INTEGER}'"
            )
        return converted_type

    @classmethod
    def _convert_values(
        cls, from_raw: OptStr, to_raw: OptStr
    ) -> tuple[int | None, int | None]:
        try:
            from_datetime = int(from_raw) if from_raw else None
            to_datetime = int(to_raw) if to_raw else None
        except Exception as e:
            raise ValueError(
                ErrorCode.BAD_REQUEST, "Failed converting raw filter value"
            ) from e

        return from_datetime, to_datetime


OptIntegerFilter = IntegerFilter | None
ListOfIntegerFilters = list[IntegerFilter]


class StringFilter(GenericRangeFilter[Literal[RangeType.STRING], str]):
    pattern: ClassVar[re.Pattern[str]] = RANGE_TYPE_TO_PATTERN_MAP[RangeType.STRING]

    type: Annotated[
        Literal[RangeType.STRING], Field(RangeType.STRING, description="Range type")
    ] = RangeType.STRING

    @classmethod
    def _validate_type(cls, type: str) -> Literal[RangeType.STRING]:
        converted_type = cls._convert_type(type)
        if converted_type is not RangeType.STRING:
            raise ValueError(
                ErrorCode.BAD_REQUEST, f"Filter type must be '{RangeType.STRING}'"
            )
        return converted_type

    @classmethod
    def _convert_values(
        cls, from_raw: OptStr, to_raw: OptStr
    ) -> tuple[str | None, str | None]:
        return from_raw, to_raw


OptStringFilter = StringFilter | None
ListOfStringFilters = list[StringFilter]


RangeFilter = DateFilter | DatetimeFilter | FloatFilter | IntegerFilter | StringFilter
OptRangeFilter = RangeFilter | None


def is_date_filter(
    filter: RangeFilter,
) -> TypeGuard[DateFilter]:
    return filter.type is RangeType.DATE


def is_datetime_filter(
    filter: RangeFilter,
) -> TypeGuard[DatetimeFilter]:
    return filter.type is RangeType.DATETIME


def is_float_filter(
    filter: RangeFilter,
) -> TypeGuard[FloatFilter]:
    return filter.type is RangeType.FLOAT


def is_integer_filter(
    filter: RangeFilter,
) -> TypeGuard[IntegerFilter]:
    return filter.type is RangeType.INTEGER


def is_string_filter(
    filter: RangeFilter,
) -> TypeGuard[StringFilter]:
    return filter.type is RangeType.STRING


ListOfRangeFilters = list[RangeFilter]
OptListOfRangeFilters = ListOfRangeFilters | None
AnyFilters = ListOfRangeFilters | ListOfStrs


def is_range_filters(
    filters: AnyFilters,
) -> TypeGuard[ListOfRangeFilters]:
    return all(isinstance(filter, RangeFilter) for filter in filters)


def is_filters(
    filters: AnyFilters,
) -> TypeGuard[ListOfStrs]:
    return all(isinstance(filter, str) for filter in filters)


@overload
def filter_from_string(type: Literal[RangeType.DATE], filter: str) -> DateFilter: ...
@overload
def filter_from_string(
    type: Literal[RangeType.DATETIME], filter: str
) -> DatetimeFilter: ...
@overload
def filter_from_string(type: Literal[RangeType.FLOAT], filter: str) -> FloatFilter: ...
@overload
def filter_from_string(
    type: Literal[RangeType.INTEGER], filter: str
) -> IntegerFilter: ...
@overload
def filter_from_string(
    type: Literal[RangeType.STRING], filter: str
) -> StringFilter: ...
def filter_from_string(type: RangeType, filter: str) -> RangeFilter:
    if type is RangeType.DATE:
        return DateFilter.from_string(filter)
    elif type is RangeType.DATETIME:
        return DatetimeFilter.from_string(filter)
    elif type is RangeType.FLOAT:
        return FloatFilter.from_string(filter)
    elif type is RangeType.INTEGER:
        return IntegerFilter.from_string(filter)
    elif type is RangeType.STRING:
        return StringFilter.from_string(filter)


@overload
def convert(filters: ListOfRangeFilters) -> ListOfStrs: ...
@overload
def convert(filters: ListOfStrs) -> ListOfRangeFilters: ...
def convert(filters: AnyFilters) -> AnyFilters:
    if is_range_filters(filters):
        return [filter.to_string() for filter in filters]
    elif is_filters(filters):
        result = []
        for filter in filters:
            selected_type = None
            for type, pattern in RANGE_TYPE_TO_PATTERN_MAP.items():
                match = pattern.match(filter)
                if match:
                    selected_type = type
                    break
            if selected_type:
                result.append(filter_from_string(selected_type, filter))
        return result
    else:
        raise ValueError("Filter type is neither RangeFilter nor string")


class Filters(BaseModel):
    filters: Annotated[
        ListOfStrs,
        Field(
            ListOfStrs(),
            description="Range filters. Format: '<TYPE>|<NAME>|from::<FROM_VALUE>|to::<FROM_VALUE>'",
        ),
    ] = ListOfStrs()

    @field_validator("filters", mode="after")
    @classmethod
    def validate_filters_pattern(cls, value: ListOfStrs) -> ListOfStrs:
        for v in value:
            match = None
            for pattern in RANGE_TYPE_TO_PATTERN_MAP.values():
                match = pattern.match(v)
            if not match:
                raise ValueError(f"No matching pattern for filter: {v!r}")
        return value

    @classmethod
    def from_range_filters(cls, range_filters: ListOfRangeFilters) -> "Filters":
        return cls(filters=[filter.to_string() for filter in range_filters])

    @property
    def range_filters(self) -> ListOfRangeFilters:
        return convert(self.filters)


class RangeFilters(BaseModel):
    range_filters: Annotated[
        ListOfRangeFilters,
        Field(list[RangeFilter](), description="Range filters to be applied"),
    ] = list[RangeFilter]()

    @classmethod
    def from_filters(cls, filters: ListOfStrs) -> Self:
        return cls(range_filters=[DateFilter.from_string(filter) for filter in filters])

    @property
    def filters(self) -> ListOfStrs:
        return convert(self.range_filters)
