from collections.abc import Iterable, Sequence
from Crypto.PublicKey.RSA import RsaKey
from datetime import datetime, timedelta, timezone
from pydantic import BaseModel, Field, model_validator
from typing import (
    Annotated,
    Generic,
    Literal,
    Self,
    TypeGuard,
    TypeVar,
    overload,
)
from uuid import UUID
from nexo.crypto.token import decode, encode
from nexo.enums.expiration import Expiration
from nexo.types.datetime import OptDatetime
from nexo.types.integer import DoubleInts
from nexo.types.misc import BytesOrStr
from nexo.types.string import OptStr
from nexo.types.uuid import OptUUID
from .enums import Domain, OptDomain, DomainT


class Claim(BaseModel):
    iss: Annotated[OptStr, Field(None, description="Issuer")] = None
    sub: Annotated[UUID, Field(..., description="Subject")]
    aud: Annotated[OptStr, Field(None, description="Audience")] = None
    exp: Annotated[int, Field(..., description="Expired at")]
    iat: Annotated[int, Field(..., description="Issued at")]

    @classmethod
    def new_timestamp(
        cls, iat_dt: OptDatetime = None, exp_in: Expiration = Expiration.EXP_15MN
    ) -> DoubleInts:
        if iat_dt is None:
            iat_dt = datetime.now(tz=timezone.utc)
        exp_dt = iat_dt + timedelta(seconds=exp_in.value)
        return int(iat_dt.timestamp()), int(exp_dt.timestamp())


OrganizationT = TypeVar("OrganizationT", bound=OptUUID)


class Credential(BaseModel, Generic[DomainT, OrganizationT]):
    d: Annotated[DomainT, Field(..., description="Domain")]
    u: Annotated[UUID, Field(..., description="User")]
    o: Annotated[OrganizationT, Field(..., description="Organization")]


class GenericToken(
    Credential[DomainT, OrganizationT],
    Claim,
    Generic[DomainT, OrganizationT],
):
    @classmethod
    def from_string(
        cls,
        token: str,
        *,
        key: BytesOrStr | RsaKey,
        audience: str | Iterable[str] | None = None,
        subject: OptStr = None,
        issuer: str | Sequence[str] | None = None,
        leeway: float | timedelta = 0,
    ) -> Self:
        obj = decode(
            token,
            key=key,
            audience=audience,
            subject=subject,
            issuer=issuer,
            leeway=leeway,
        )
        return cls.model_validate(obj)

    @model_validator(mode="after")
    def validate_credential(self) -> Self:
        return self

    @overload
    def to_string(
        self,
        key: RsaKey,
    ) -> str: ...
    @overload
    def to_string(
        self,
        key: BytesOrStr,
        *,
        password: OptStr = None,
    ) -> str: ...
    @overload
    def to_string(
        self,
        key: BytesOrStr | RsaKey,
        *,
        password: OptStr = None,
    ) -> str: ...
    def to_string(
        self,
        key: BytesOrStr | RsaKey,
        *,
        password: OptStr = None,
    ) -> str:
        if isinstance(key, RsaKey):
            return encode(
                payload=self.model_dump(mode="json", exclude_none=True),
                key=key,
            )
        else:
            return encode(
                payload=self.model_dump(mode="json", exclude_none=True),
                key=key,
                password=password,
            )


class PersonalToken(GenericToken[Literal[Domain.PERSONAL], None]):
    d: Annotated[
        Literal[Domain.PERSONAL], Field(Domain.PERSONAL, description="Domain")
    ] = Domain.PERSONAL
    o: None = None

    @model_validator(mode="after")
    def validate_identity(self) -> Self:
        if self.d is not Domain.PERSONAL:
            raise ValueError(f"Value of 'd' claim must be {Domain.PERSONAL}")
        if self.o is not None:
            raise ValueError(f"Value of 'o' claim must be None. Value: {self.o}")
        return self

    @classmethod
    def new(
        cls,
        *,
        iss: OptStr = None,
        sub: UUID,
        aud: OptStr = None,
        iat_dt: OptDatetime = None,
        exp_in: Expiration = Expiration.EXP_15MN,
        u: UUID,
    ) -> Self:
        iat, exp = cls.new_timestamp(iat_dt, exp_in)
        return cls(iss=iss, sub=sub, aud=aud, exp=exp, iat=iat, u=u)


class SystemToken(GenericToken[Literal[Domain.SYSTEM], None]):
    d: Annotated[Literal[Domain.SYSTEM], Field(Domain.SYSTEM, description="Domain")] = (
        Domain.SYSTEM
    )
    o: None = None

    @model_validator(mode="after")
    def validate_identity(self) -> Self:
        if self.d is not Domain.SYSTEM:
            raise ValueError(f"Value of 'd' claim must be {Domain.SYSTEM}")
        if self.o is not None:
            raise ValueError(f"Value of 'o' claim must be None. Value: {self.o}")
        return self

    @classmethod
    def new(
        cls,
        *,
        iss: OptStr = None,
        sub: UUID,
        aud: OptStr = None,
        iat_dt: OptDatetime = None,
        exp_in: Expiration = Expiration.EXP_15MN,
        u: UUID,
    ) -> Self:
        iat, exp = cls.new_timestamp(iat_dt, exp_in)
        return cls(iss=iss, sub=sub, aud=aud, exp=exp, iat=iat, u=u)


class TenantToken(GenericToken[Literal[Domain.TENANT], UUID]):
    d: Annotated[Literal[Domain.TENANT], Field(Domain.TENANT, description="Domain")] = (
        Domain.TENANT
    )

    @model_validator(mode="after")
    def validate_identity(self) -> Self:
        if self.d is not Domain.TENANT:
            raise ValueError(f"Value of 'd' claim must be {Domain.TENANT}")
        if not isinstance(self.o, UUID):
            raise ValueError(f"Value of 'o' claim must be an UUID. Value: {self.o}")
        return self

    @classmethod
    def new(
        cls,
        *,
        sub: UUID,
        iss: OptStr = None,
        aud: OptStr = None,
        iat_dt: OptDatetime = None,
        exp_in: Expiration = Expiration.EXP_15MN,
        u: UUID,
        o: UUID,
    ) -> Self:
        iat, exp = cls.new_timestamp(iat_dt, exp_in)
        return cls(iss=iss, sub=sub, aud=aud, exp=exp, iat=iat, u=u, o=o)


token_models = (PersonalToken, SystemToken, TenantToken)
AnyToken = PersonalToken | SystemToken | TenantToken
AnyTokenT = TypeVar("AnyTokenT", bound=AnyToken)
OptAnyToken = AnyToken | None
OptAnyTokenT = TypeVar("OptAnyTokenT", bound=OptAnyToken)


class TokenMixin(BaseModel, Generic[OptAnyTokenT]):
    token: OptAnyTokenT = Field(..., description="Token")


def is_personal_token(token: AnyToken) -> TypeGuard[PersonalToken]:
    return (
        isinstance(token, PersonalToken)
        and token.d is Domain.PERSONAL
        and token.o is None
    )


def is_system_token(token: AnyToken) -> TypeGuard[SystemToken]:
    return (
        isinstance(token, SystemToken) and token.d is Domain.SYSTEM and token.o is None
    )


def is_tenant_token(token: AnyToken) -> TypeGuard[TenantToken]:
    return (
        isinstance(token, TenantToken)
        and token.d is Domain.TENANT
        and token.o is not None
    )


class TokenFactory:
    @overload
    @staticmethod
    def from_string(
        token: str,
        domain: Literal[Domain.PERSONAL],
        *,
        key: BytesOrStr | RsaKey,
        audience: str | Iterable[str] | None = None,
        subject: OptStr = None,
        issuer: str | Sequence[str] | None = None,
        leeway: float | timedelta = 0,
    ) -> PersonalToken: ...
    @overload
    @staticmethod
    def from_string(
        token: str,
        domain: Literal[Domain.SYSTEM],
        *,
        key: BytesOrStr | RsaKey,
        audience: str | Iterable[str] | None = None,
        subject: OptStr = None,
        issuer: str | Sequence[str] | None = None,
        leeway: float | timedelta = 0,
    ) -> SystemToken: ...
    @overload
    @staticmethod
    def from_string(
        token: str,
        domain: Literal[Domain.TENANT],
        *,
        key: BytesOrStr | RsaKey,
        audience: str | Iterable[str] | None = None,
        subject: OptStr = None,
        issuer: str | Sequence[str] | None = None,
        leeway: float | timedelta = 0,
    ) -> TenantToken: ...
    @overload
    @staticmethod
    def from_string(
        token: str,
        domain: None = None,
        *,
        key: BytesOrStr | RsaKey,
        audience: str | Iterable[str] | None = None,
        subject: OptStr = None,
        issuer: str | Sequence[str] | None = None,
        leeway: float | timedelta = 0,
    ) -> AnyToken: ...
    @staticmethod
    def from_string(
        token: str,
        domain: OptDomain = None,
        *,
        key: BytesOrStr | RsaKey,
        audience: str | Iterable[str] | None = None,
        subject: OptStr = None,
        issuer: str | Sequence[str] | None = None,
        leeway: float | timedelta = 0,
    ) -> AnyToken:
        validated_token = None
        for model in token_models:
            try:
                validated_token = model.from_string(
                    token,
                    key=key,
                    audience=audience,
                    subject=subject,
                    issuer=issuer,
                    leeway=leeway,
                )
            except Exception:
                continue
        if validated_token is None:
            raise ValueError("Unable to validate raw token into known token model")

        if domain is None:
            return validated_token
        elif domain is Domain.PERSONAL:
            if not is_personal_token(validated_token):
                raise ValueError(
                    "Failed parsing Personal Token from string, raw token did not qualify as Personal Token"
                )
            return validated_token
        elif domain is Domain.SYSTEM:
            if not is_system_token(validated_token):
                raise ValueError(
                    "Failed parsing System Token from string, raw token did not qualify as System Token"
                )
            return validated_token
        elif domain is Domain.TENANT:
            if not is_tenant_token(validated_token):
                raise ValueError(
                    "Failed parsing Tenant Token from string, raw token did not qualify as Tenant Token"
                )
            return validated_token
