"""
Page handlers for the generated Nexom server project.
"""