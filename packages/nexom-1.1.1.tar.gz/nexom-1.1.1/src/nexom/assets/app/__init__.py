"""Default app asset templates."""

