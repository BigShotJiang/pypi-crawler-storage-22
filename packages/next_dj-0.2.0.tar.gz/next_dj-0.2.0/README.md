# next.dj

[![PyPI version](https://img.shields.io/pypi/v/next.dj)](https://pypi.python.org/pypi/next.dj/)
[![PyPI Supported Python Versions](https://img.shields.io/pypi/pyversions/next.dj.svg)](https://pypi.python.org/pypi/next.dj/)
[![PyPI Supported Django Versions](https://img.shields.io/pypi/djversions/next.dj.svg)](https://pypi.python.org/pypi/next.dj/)
[![codecov](https://codecov.io/gh/next-dj/next-dj/graph/badge.svg?token=6RY9344W4E)](https://codecov.io/gh/next-dj/next-dj)

A next-gen framework based on Django for cool engineers who love to do complex things!

> [!WARNING]
> This project is currently under active development. The code may be unstable and breaking changes may occur between versions. Many features are still in progress. Please use with caution in production environments.

## What is `next.dj`?

`next.dj` is a modern framework based on Django that provides a unique opportunity - you can build full-stack applications on Django! Now you don't need frontend developers on React or other frameworks. It simplifies Django development by providing intuitive APIs and automatic code generation, offering a file-based routing system similar to Next.js, but built on top of Django's robust ecosystem.

## Documentation

Full documentation is available at: https://next-dj.readthedocs.io/.

## Contributing

We welcome contributions from the community! `next.dj` is designed to make Django development more accessible to frontend developers, and your input is invaluable.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
