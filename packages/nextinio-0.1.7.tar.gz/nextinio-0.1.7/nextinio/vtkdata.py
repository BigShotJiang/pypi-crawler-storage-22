import vtk
import numpy as np
from vtk.util.numpy_support import vtk_to_numpy

def read_vtk_file(filename):
    reader = vtk.vtkPolyDataReader()
    reader.SetFileName(filename)
    reader.Update()
    polydata = reader.GetOutput()

    # Points
    points = np.array([polydata.GetPoint(i) for i in range(polydata.GetNumberOfPoints())])

    # Helper: get array by name safely
    def get_array(name):
        arr = polydata.GetPointData().GetArray(name)
        if arr is None:
            # Try scalars or vectors fallback
            if name == "mass":
                arr = polydata.GetPointData().GetScalars()
            elif name == "velocity":
                arr = polydata.GetPointData().GetVectors()
        return vtk_to_numpy(arr) if arr is not None else None

    return {
        "points": points,
        "point_data": {
            "type": get_array("type"),
            "velocity": get_array("velocity"),
            "mass": get_array("mass"),
        }
    }
