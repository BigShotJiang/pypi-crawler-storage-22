from nextrec.__version__ import __version__

__all__ = [
    "__version__",
]

# Package metadata
__author__ = "zerolovesea"
__email__ = "zyaztec@gmail.com"
__license__ = "Apache 2.0"
__url__ = "https://github.com/zerolovesea/NextRec"
