"""
Date: create on 27/10/2025
Checkpoint: edit on 07/02/2026
Author: Yang Zhou,zyaztec@gmail.com
Reference:
- [1] Guo H, Tang R, Ye Y, et al. DeepFM: A factorization-machine based neural network for CTR prediction[J]. arXiv preprint arXiv:1703.04247, 2017.
URL: https://arxiv.org/abs/1703.04247

DeepFM combines a Factorization Machine (FM) for explicit second-order feature
interactions with a deep MLP for high-order nonlinear patterns. Both parts share
the same embeddings, avoiding manual feature engineering and delivering strong CTR
performance with end-to-end training.

Workflow:
- Shared embeddings encode sparse/sequence fields; dense features are concatenated
- Wide (LR) term models first-order signals
- FM term captures pairwise interactions via inner products
- Deep MLP learns higher-order interactions over concatenated embeddings
- Outputs from wide, FM, and deep parts are summed before the final prediction

DeepFM 将 FM 的显式二阶特征交互与 MLP 的高阶非线性交互结合，三部分共享
embedding，无需手工构造交叉特征即可端到端训练，常用于 CTR/CVR 预估。

流程：
- 共享 embedding 处理稀疏/序列特征，稠密特征拼接
- Wide（LR）建模一阶信号
- FM 建模二阶交互
- MLP 学习高阶非线性交互
- Wide + FM + Deep 求和后进入预测
"""

from nextrec.basic.features import DenseFeature, SequenceFeature, SparseFeature
from nextrec.basic.layers import FM, LR, MLP, EmbeddingLayer
from nextrec.basic.heads import TaskHead
from nextrec.basic.model import BaseModel
from nextrec.utils.types import TaskTypeInput


class DeepFM(BaseModel):
    @property
    def model_name(self):
        return "DeepFM"

    @property
    def default_task(self):
        return "binary"

    def __init__(
        self,
        dense_features: list[DenseFeature] | None = None,
        sparse_features: list[SparseFeature] | None = None,
        sequence_features: list[SequenceFeature] | None = None,
        target: str | list[str] | None = None,
        task: TaskTypeInput | list[TaskTypeInput] | None = None,
        mlp_params: dict | None = None,
        **kwargs,
    ):
        """
        Initialize DeepFM model.
        初始化 DeepFM 模型。

        Args:
            mlp_params: Parameters for deep branch MLP, e.g. {"hidden_dims": [64, 32], "dropout": 0.2}.
                深度分支 MLP 参数。例如 {"hidden_dims": [64, 32], "dropout": 0.2}。
        """

        dense_features = dense_features or []
        sparse_features = sparse_features or []
        sequence_features = sequence_features or []
        mlp_params = mlp_params or {}

        super(DeepFM, self).__init__(
            dense_features=dense_features,
            sparse_features=sparse_features,
            sequence_features=sequence_features,
            target=target,
            task=task,
            **kwargs,
        )

        self.fm_features = sparse_features + sequence_features
        self.deep_features = dense_features + sparse_features + sequence_features
        self.embedding = EmbeddingLayer(features=self.deep_features)
        fm_emb_dim_total = sum([f.embedding_dim for f in self.fm_features])
        # deep_emb_dim_total = sum([f.embedding_dim for f in self.deep_features if not isinstance(f, DenseFeature)])
        # dense_input_dim = sum([(f.embedding_dim or 1) for f in dense_features])
        mlp_input_dim = self.embedding.input_dim
        self.linear = LR(fm_emb_dim_total)
        self.fm = FM(reduce_sum=True)
        self.mlp = MLP(input_dim=mlp_input_dim, **mlp_params)

        self.prediction_layer = TaskHead(task_type=self.task)

        # Register regularization weights
        self.register_regularization_weights(embedding_attr="embedding", include_modules=["linear", "mlp"])

    def forward(self, x):
        input_deep = self.embedding(x=x, features=self.deep_features, squeeze_dim=True)
        input_fm = self.embedding(x=x, features=self.fm_features, squeeze_dim=False)

        y_linear = self.linear(input_fm.flatten(start_dim=1))
        y_fm = self.fm(input_fm)
        y_deep = self.mlp(input_deep)  # [Batch, 1]

        y = y_linear + y_fm + y_deep
        return self.prediction_layer(y)
