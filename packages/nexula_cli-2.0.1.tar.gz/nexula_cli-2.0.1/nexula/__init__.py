"""Nexula CLI - Enterprise AI/ML Supply Chain Security Platform"""

__version__ = "2.0.1"
