# Nexus Agent Frontend

Next.js 16 (App Router) + React 19 기반 프론트엔드. AI 채팅, MCP 서버 관리, Agent Skills 관리, Custom Pages 폴더 브라우저, 테마/LLM 설정 대시보드를 제공합니다.

## 실행

```bash
pnpm install
pnpm dev        # 개발 서버 (http://localhost:3000)
pnpm build      # 프로덕션 빌드
pnpm lint       # ESLint
```

## 구조

```
src/
├── app/
│   ├── layout.tsx                 # 루트 레이아웃 (Sidebar, 배경 효과, ThemeProvider)
│   ├── page.tsx                   # 홈 — ChatInterface
│   ├── tools/page.tsx             # MCP Servers 대시보드
│   ├── skills/page.tsx            # Agent Skills 대시보드
│   ├── pages/page.tsx             # Custom Pages 폴더 브라우저
│   ├── pages/[id]/page.tsx        # 페이지 뷰어 (HTML / iframe)
│   └── settings/page.tsx          # 테마, LLM, 프로필, 헬스체크 설정
├── components/
│   ├── chat/
│   │   ├── ChatInterface.tsx      # 채팅 UI (메시지, 파일 첨부, 배경 편집 모드)
│   │   ├── FilePreviewChips.tsx   # 첨부 파일 미리보기 칩
│   │   └── MCPToolsPanel.tsx      # MCP 도구 사이드 패널
│   ├── mcp/
│   │   ├── MCPServerRow.tsx       # MCP 서버 컴팩트 행 (HoverCard 상세)
│   │   ├── MCPServerCard.tsx      # MCP 서버 카드
│   │   └── AddServerDialog.tsx    # MCP 서버 추가 다이얼로그
│   ├── skills/
│   │   ├── SkillRow.tsx           # 스킬 컴팩트 행 (HoverCard 상세)
│   │   ├── SkillCard.tsx          # 스킬 카드
│   │   └── AddSkillDialog.tsx     # 스킬 추가 다이얼로그 (생성/ZIP/임포트)
│   ├── pages/
│   │   ├── PageRow.tsx            # 페이지/폴더 컴팩트 행 (인라인 이름변경)
│   │   ├── PageCard.tsx           # 페이지 카드
│   │   └── AddPageDialog.tsx      # 페이지 추가 다이얼로그 (업로드/임포트/북마크/폴더)
│   ├── providers/
│   │   ├── ThemeProvider.tsx      # oklch 테마 변수 적용
│   │   └── BackgroundBlobs.tsx    # 글래스모피즘 배경 효과
│   ├── layout/
│   │   └── Sidebar.tsx            # 반응형 사이드바 네비게이션
│   └── ui/                        # shadcn/ui 컴포넌트
├── lib/
│   ├── config.ts                  # API_BASE_URL 중앙 설정
│   ├── utils.ts                   # cn() 헬퍼 (clsx + tailwind-merge)
│   ├── file-utils.ts              # 파일 검증 및 base64 변환
│   ├── api/
│   │   ├── mcp.ts                 # MCP 서버/도구 API 클라이언트
│   │   ├── skills.ts              # Skills API 클라이언트
│   │   ├── pages.ts               # Pages/폴더/북마크 API 클라이언트
│   │   └── settings.ts            # LLM 설정/헬스체크 API 클라이언트
│   └── stores/
│       ├── theme.ts               # 테마 상태 (localStorage, oklch 프리셋)
│       └── profile.ts             # 사용자 프로필 상태 (localStorage)
```

## 페이지

| 경로 | 설명 |
|------|------|
| `/` | AI 채팅 — 메시지 송수신, 이미지 첨부, MCP 도구 패널, 배경 이미지 편집 |
| `/tools` | MCP Servers — 서버 등록/연결/토글, 도구 목록 조회 |
| `/skills` | Agent Skills — 스킬 생성/ZIP 업로드/경로 임포트, SKILL.md 상세 보기 |
| `/pages` | Custom Pages — 폴더 트리 네비게이션, HTML 업로드, URL 북마크, 인라인 이름변경 |
| `/pages/[id]` | 페이지 뷰어 — HTML 콘텐츠 표시 또는 iframe으로 URL 렌더링 |
| `/settings` | 설정 — 테마/배경/LLM/프로필/연결 상태 |

## 백엔드 연결

백엔드 API 주소는 `src/lib/config.ts`에서 중앙 관리됩니다.

- **기본값**: `http://localhost:8000` (설정 없이 동작)
- **변경 시**: `frontend/.env.local` 파일을 생성

```bash
# frontend/.env.local (필요할 때만 생성)
NEXT_PUBLIC_API_URL=http://192.168.0.100:8000
```

| 파일 | 역할 |
|------|------|
| `.env.example` | 환경 변수 템플릿 (git에 커밋됨) |
| `.env.local` | 실제 설정 (git에서 제외, 필요할 때만 생성) |

## 디자인 시스템

- **테마**: 다크/라이트 글래스모피즘 (backdrop-blur, 반투명 보더)
- **색상**: oklch 색공간, 6종 액센트 컬러 (amber, blue, emerald, violet, rose, cyan)
- **배경 톤**: 다크 4종 (default, midnight, charcoal, slate) / 라이트 3종 (default, warm, cool)
- **채팅 배경**: 커스텀 이미지 + 배율/위치/투명도 조정 (Settings 및 채팅 화면 내 드래그 편집)
- **컴포넌트**: shadcn/ui (new-york 스타일, Lucide 아이콘, HoverCard 활용)
- **Path alias**: `@/*` → `./src/*`
- **UI 패턴**: 컴팩트 Row 리스트 (호버 시 상세 HoverCard, 호버 시 액션 버튼 표시)
