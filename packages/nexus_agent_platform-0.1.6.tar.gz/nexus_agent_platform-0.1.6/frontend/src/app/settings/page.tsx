"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { Palette, Brain, UserCircle, Activity, Check, Save, Upload, Sun, Moon, ImageIcon, X, ZoomIn, ZoomOut, RotateCcw, Move } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { API_BASE_URL } from "@/lib/config";
import {
  ACCENT_PRESETS,
  DARK_TONES,
  LIGHT_TONES,
  loadTheme,
  saveTheme,
  applyTheme,
  type AccentColor,
  type ThemeMode,
  type BackgroundTone,
} from "@/lib/stores/theme";
import { loadProfile, saveProfile, type UserProfile } from "@/lib/stores/profile";
import { fetchLLMSettings, updateLLMSettings, checkHealth, type LLMSettings } from "@/lib/api/settings";

// --- Model Presets ---
const MODEL_PRESETS = [
  { label: "Gemini 3 Flash", model: "gemini/gemini-3-flash-preview", api_base: "" },
  { label: "Gemini 2.0 Flash", model: "gemini/gemini-2.0-flash", api_base: "" },
  { label: "Hosted vLLM (사내 LLM)", model: "hosted_vllm/", api_base: "" },
  { label: "직접 입력", model: "", api_base: "" },
];

export default function SettingsPage() {
  // --- Theme ---
  const [accent, setAccent] = useState<AccentColor>("amber");
  const [mode, setMode] = useState<ThemeMode>("dark");
  const [tone, setTone] = useState<BackgroundTone>("default");
  const [showBlobs, setShowBlobs] = useState(true);
  const [chatBgImage, setChatBgImage] = useState("/rubber-track.png");
  const [chatBgOpacity, setChatBgOpacity] = useState(0.3);
  const [chatBgScale, setChatBgScale] = useState(1.1);
  const [chatBgPosX, setChatBgPosX] = useState(50);
  const [chatBgPosY, setChatBgPosY] = useState(50);
  const bgImageInputRef = useRef<HTMLInputElement>(null);
  const previewRef = useRef<HTMLDivElement>(null);
  const [previewDragging, setPreviewDragging] = useState(false);
  const previewDragStart = useRef({ x: 0, y: 0, posX: 50, posY: 50 });

  // --- LLM ---
  const [llm, setLlm] = useState<LLMSettings | null>(null);
  const [llmModel, setLlmModel] = useState("");
  const [llmApiBase, setLlmApiBase] = useState("");
  const [llmApiKey, setLlmApiKey] = useState("");
  const [llmTemp, setLlmTemp] = useState(0.7);
  const [llmMaxTokens, setLlmMaxTokens] = useState(4096);
  const [llmSystemPrompt, setLlmSystemPrompt] = useState("");
  const [llmSaving, setLlmSaving] = useState(false);
  const [llmSaved, setLlmSaved] = useState(false);

  // --- Profile ---
  const [profile, setProfile] = useState<UserProfile>({ name: "", avatar: "" });
  const [profileSaved, setProfileSaved] = useState(false);
  const avatarInputRef = useRef<HTMLInputElement>(null);

  // --- Health ---
  const [health, setHealth] = useState<boolean | null>(null);
  const [checking, setChecking] = useState(false);

  // Load initial state
  useEffect(() => {
    const theme = loadTheme();
    setAccent(theme.accentColor);
    setMode(theme.mode);
    setTone(theme.tone);
    setShowBlobs(theme.showBlobs);
    setChatBgImage(theme.chatBgImage);
    setChatBgOpacity(theme.chatBgOpacity);
    setChatBgScale(theme.chatBgScale);
    setChatBgPosX(theme.chatBgPositionX);
    setChatBgPosY(theme.chatBgPositionY);

    setProfile(loadProfile());

    fetchLLMSettings().then((s) => {
      setLlm(s);
      setLlmModel(s.model);
      setLlmApiBase(s.api_base || "");
      setLlmApiKey("");
      setLlmTemp(s.temperature);
      setLlmMaxTokens(s.max_tokens);
      setLlmSystemPrompt(s.system_prompt);
    }).catch(console.error);

    checkHealth().then(setHealth);
  }, []);

  // --- Theme handlers ---
  const applyAndSave = (updates: Partial<{
    accentColor: AccentColor; mode: ThemeMode; tone: BackgroundTone; showBlobs: boolean;
    chatBgImage: string; chatBgOpacity: number; chatBgScale: number; chatBgPositionX: number; chatBgPositionY: number;
  }>) => {
    const next = {
      accentColor: accent, mode, tone, showBlobs,
      chatBgImage, chatBgOpacity, chatBgScale,
      chatBgPositionX: chatBgPosX, chatBgPositionY: chatBgPosY,
      ...updates,
    };
    if (updates.accentColor) setAccent(updates.accentColor);
    if (updates.mode) setMode(updates.mode);
    if (updates.tone !== undefined) setTone(updates.tone);
    if (updates.showBlobs !== undefined) setShowBlobs(updates.showBlobs);
    if (updates.chatBgImage !== undefined) setChatBgImage(updates.chatBgImage);
    if (updates.chatBgOpacity !== undefined) setChatBgOpacity(updates.chatBgOpacity);
    if (updates.chatBgScale !== undefined) setChatBgScale(updates.chatBgScale);
    if (updates.chatBgPositionX !== undefined) setChatBgPosX(updates.chatBgPositionX);
    if (updates.chatBgPositionY !== undefined) setChatBgPosY(updates.chatBgPositionY);
    saveTheme(next);
    applyTheme(next);
    window.dispatchEvent(new Event("theme-change"));
  };

  // --- Preview drag handlers ---
  const handlePreviewDragStart = (e: React.MouseEvent) => {
    e.preventDefault();
    setPreviewDragging(true);
    previewDragStart.current = { x: e.clientX, y: e.clientY, posX: chatBgPosX, posY: chatBgPosY };
  };

  useEffect(() => {
    if (!previewDragging) return;
    const handleMove = (e: MouseEvent) => {
      const container = previewRef.current;
      if (!container) return;
      const rect = container.getBoundingClientRect();
      const dx = e.clientX - previewDragStart.current.x;
      const dy = e.clientY - previewDragStart.current.y;
      const pctX = (dx / rect.width) * 100;
      const pctY = (dy / rect.height) * 100;
      const newX = Math.max(0, Math.min(100, previewDragStart.current.posX - pctX));
      const newY = Math.max(0, Math.min(100, previewDragStart.current.posY - pctY));
      applyAndSave({ chatBgPositionX: newX, chatBgPositionY: newY });
    };
    const handleUp = () => setPreviewDragging(false);
    window.addEventListener("mousemove", handleMove);
    window.addEventListener("mouseup", handleUp);
    return () => {
      window.removeEventListener("mousemove", handleMove);
      window.removeEventListener("mouseup", handleUp);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [previewDragging]);

  // --- LLM handlers ---
  const handleLLMSave = async () => {
    setLlmSaving(true);
    try {
      const updates: Partial<LLMSettings> = {
        model: llmModel,
        api_base: llmApiBase || null,
        temperature: llmTemp,
        max_tokens: llmMaxTokens,
        system_prompt: llmSystemPrompt,
      };
      if (llmApiKey) {
        updates.api_key = llmApiKey;
      }
      await updateLLMSettings(updates);
      setLlmSaved(true);
      setTimeout(() => setLlmSaved(false), 2000);
    } catch (err) {
      console.error("Failed to save LLM settings:", err);
    } finally {
      setLlmSaving(false);
    }
  };

  const handlePresetSelect = (preset: typeof MODEL_PRESETS[number]) => {
    setLlmModel(preset.model);
    if (preset.api_base) setLlmApiBase(preset.api_base);
  };

  // --- Profile handlers ---
  const handleAvatarSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setProfile((p) => ({ ...p, avatar: dataUrl }));
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const handleProfileSave = () => {
    saveProfile(profile);
    setProfileSaved(true);
    window.dispatchEvent(new Event("profile-change"));
    setTimeout(() => setProfileSaved(false), 2000);
  };

  // --- Health ---
  const handleHealthCheck = useCallback(async () => {
    setChecking(true);
    const ok = await checkHealth();
    setHealth(ok);
    setChecking(false);
  }, []);

  return (
    <div className="h-full overflow-y-auto p-10 space-y-12 bg-background relative">
      <div className="absolute inset-0 opacity-[0.02] pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]" />

      <div className="relative flex flex-col gap-4">
        <div className="flex items-center gap-4">
          <div className="w-2 h-10 bg-primary" />
          <h1 className="text-4xl font-black uppercase tracking-tighter text-foreground">Settings</h1>
        </div>
        <p className="text-muted-foreground text-sm font-bold uppercase tracking-[0.1em] ml-6">
          Platform Configuration
        </p>
      </div>

      <div className="relative max-w-4xl space-y-10">
        {/* ═══════════════════════════════════════════════
            SECTION 1: Theme & Appearance
        ═══════════════════════════════════════════════ */}
        <section className="p-8 bg-card border border-border/30 rounded-[2rem] backdrop-blur-xl space-y-8">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-foreground/5 rounded-2xl border border-foreground/10">
              <Palette className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-black uppercase tracking-tight">Theme & Appearance</h2>
              <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">액센트 컬러 및 배경 설정</p>
            </div>
          </div>

          {/* Mode Toggle */}
          <div className="space-y-4">
            <Label className="text-[10px] font-black uppercase tracking-widest text-primary">Mode</Label>
            <div className="flex gap-3">
              <button
                onClick={() => applyAndSave({ mode: "dark", tone: "default" })}
                className={cn(
                  "flex-1 flex items-center justify-center gap-3 p-4 rounded-2xl border-2 transition-all duration-300",
                  mode === "dark"
                    ? "border-primary/50 bg-primary/10"
                    : "border-foreground/5 bg-foreground/5 hover:border-foreground/10"
                )}
              >
                <Moon className="w-5 h-5" />
                <span className="text-xs font-black uppercase tracking-widest">Dark</span>
              </button>
              <button
                onClick={() => applyAndSave({ mode: "light", tone: "default" })}
                className={cn(
                  "flex-1 flex items-center justify-center gap-3 p-4 rounded-2xl border-2 transition-all duration-300",
                  mode === "light"
                    ? "border-primary/50 bg-primary/10"
                    : "border-foreground/5 bg-foreground/5 hover:border-foreground/10"
                )}
              >
                <Sun className="w-5 h-5" />
                <span className="text-xs font-black uppercase tracking-widest">Light</span>
              </button>
            </div>
          </div>

          {/* Background Tone */}
          <div className="space-y-4">
            <Label className="text-[10px] font-black uppercase tracking-widest text-primary">Background Tone</Label>
            <div className="flex gap-3 flex-wrap">
              {(mode === "dark" ? DARK_TONES : LIGHT_TONES).map((t) => (
                <button
                  key={t.key}
                  onClick={() => applyAndSave({ tone: t.key })}
                  className={cn(
                    "relative flex flex-col items-center gap-2 p-3 rounded-2xl border-2 transition-all duration-300 min-w-[90px]",
                    tone === t.key
                      ? "border-primary/50 bg-primary/10 scale-105"
                      : "border-foreground/5 bg-foreground/5 hover:border-foreground/10"
                  )}
                >
                  <div
                    className="w-12 h-12 rounded-xl border border-foreground/10"
                    style={{ backgroundColor: t.preview }}
                  />
                  <span className="text-[9px] font-black uppercase tracking-widest">{t.label}</span>
                  <span className="text-[8px] text-muted-foreground">{t.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Accent Color */}
          <div className="space-y-4">
            <Label className="text-[10px] font-black uppercase tracking-widest text-primary">Accent Color</Label>
            <div className="flex gap-3 flex-wrap">
              {(Object.entries(ACCENT_PRESETS) as [AccentColor, typeof ACCENT_PRESETS[AccentColor]][]).map(([key, preset]) => (
                <button
                  key={key}
                  onClick={() => applyAndSave({ accentColor: key })}
                  className={cn(
                    "relative w-14 h-14 rounded-2xl border-2 transition-all duration-300 flex items-center justify-center",
                    accent === key
                      ? "border-foreground/40 scale-110 shadow-lg"
                      : "border-foreground/10 hover:border-foreground/20 hover:scale-105"
                  )}
                  style={{ backgroundColor: preset.preview }}
                >
                  {accent === key && <Check className="w-5 h-5 text-white drop-shadow-lg" />}
                  <span className="absolute -bottom-5 text-[8px] font-black uppercase tracking-widest text-muted-foreground">
                    {preset.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Background Blobs */}
          <div className="flex items-center justify-between p-4 bg-card rounded-2xl border border-border/50 mt-8">
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest text-foreground">Background Blobs</span>
              <p className="text-[10px] text-muted-foreground mt-1">배경 글로우 효과 표시</p>
            </div>
            <Switch
              checked={showBlobs}
              onCheckedChange={(checked) => applyAndSave({ showBlobs: checked })}
              className="data-[state=checked]:bg-primary"
            />
          </div>

          {/* Chat Background Image */}
          <div className="space-y-5 mt-8">
            <Label className="text-[10px] font-black uppercase tracking-widest text-primary">Chat Background Image</Label>

            {/* Preset images + custom upload */}
            <div className="flex gap-3 flex-wrap items-end">
              {/* None option */}
              <button
                onClick={() => applyAndSave({ chatBgImage: "" })}
                className={cn(
                  "relative flex flex-col items-center gap-2 p-2 rounded-2xl border-2 transition-all duration-300 min-w-[80px]",
                  !chatBgImage
                    ? "border-primary/50 bg-primary/10 scale-105"
                    : "border-foreground/5 bg-foreground/5 hover:border-foreground/10"
                )}
              >
                <div className="w-16 h-16 rounded-xl border border-foreground/10 bg-foreground/5 flex items-center justify-center">
                  <X className="w-5 h-5 text-muted-foreground/40" />
                </div>
                <span className="text-[9px] font-black uppercase tracking-widest">None</span>
              </button>

              {/* Built-in images */}
              {[
                { url: "/rubber-track.png", label: "Track" },
                { url: "/nano-banana.png", label: "Banana" },
              ].map((preset) => (
                <button
                  key={preset.url}
                  onClick={() => applyAndSave({ chatBgImage: preset.url })}
                  className={cn(
                    "relative flex flex-col items-center gap-2 p-2 rounded-2xl border-2 transition-all duration-300 min-w-[80px]",
                    chatBgImage === preset.url
                      ? "border-primary/50 bg-primary/10 scale-105"
                      : "border-foreground/5 bg-foreground/5 hover:border-foreground/10"
                  )}
                >
                  <div className="w-16 h-16 rounded-xl border border-foreground/10 overflow-hidden bg-black/20">
                    <img src={preset.url} alt={preset.label} className="w-full h-full object-cover grayscale" />
                  </div>
                  <span className="text-[9px] font-black uppercase tracking-widest">{preset.label}</span>
                </button>
              ))}

              {/* Custom upload */}
              <input
                ref={bgImageInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = () => {
                    const dataUrl = reader.result as string;
                    applyAndSave({ chatBgImage: dataUrl });
                  };
                  reader.readAsDataURL(file);
                  e.target.value = "";
                }}
              />
              <button
                onClick={() => bgImageInputRef.current?.click()}
                className={cn(
                  "relative flex flex-col items-center gap-2 p-2 rounded-2xl border-2 transition-all duration-300 min-w-[80px]",
                  chatBgImage && chatBgImage.startsWith("data:")
                    ? "border-primary/50 bg-primary/10 scale-105"
                    : "border-foreground/5 bg-foreground/5 hover:border-foreground/10"
                )}
              >
                <div className="w-16 h-16 rounded-xl border border-dashed border-foreground/10 flex items-center justify-center bg-foreground/5 overflow-hidden">
                  {chatBgImage && chatBgImage.startsWith("data:") ? (
                    <img src={chatBgImage} alt="custom" className="w-full h-full object-cover grayscale" />
                  ) : (
                    <ImageIcon className="w-5 h-5 text-muted-foreground/40" />
                  )}
                </div>
                <span className="text-[9px] font-black uppercase tracking-widest">Custom</span>
              </button>
            </div>

            {chatBgImage && (
              <>
                {/* Opacity slider */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-[10px] font-black uppercase tracking-widest text-primary">Opacity</Label>
                    <span className="text-xs font-mono font-bold text-primary">{(chatBgOpacity * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range" min="0" max="1" step="0.05"
                    value={chatBgOpacity}
                    onChange={(e) => applyAndSave({ chatBgOpacity: parseFloat(e.target.value) })}
                    className="w-full accent-primary h-1.5"
                  />
                </div>

                {/* Scale slider */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-[10px] font-black uppercase tracking-widest text-primary">Scale</Label>
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => applyAndSave({ chatBgScale: Math.max(0.5, chatBgScale - 0.1) })}>
                        <ZoomOut className="w-3 h-3" />
                      </Button>
                      <span className="text-xs font-mono font-bold text-primary w-12 text-center">{(chatBgScale * 100).toFixed(0)}%</span>
                      <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => applyAndSave({ chatBgScale: Math.min(5, chatBgScale + 0.1) })}>
                        <ZoomIn className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                  <input
                    type="range" min="0.5" max="5" step="0.1"
                    value={chatBgScale}
                    onChange={(e) => applyAndSave({ chatBgScale: parseFloat(e.target.value) })}
                    className="w-full accent-primary h-1.5"
                  />
                </div>

                {/* Position X/Y sliders */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-[10px] font-black uppercase tracking-widest text-primary">Position X</Label>
                      <span className="text-[10px] font-mono font-bold text-foreground/60">{chatBgPosX.toFixed(0)}%</span>
                    </div>
                    <input
                      type="range" min="0" max="100" step="1"
                      value={chatBgPosX}
                      onChange={(e) => applyAndSave({ chatBgPositionX: parseFloat(e.target.value) })}
                      className="w-full accent-primary h-1.5"
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-[10px] font-black uppercase tracking-widest text-primary">Position Y</Label>
                      <span className="text-[10px] font-mono font-bold text-foreground/60">{chatBgPosY.toFixed(0)}%</span>
                    </div>
                    <input
                      type="range" min="0" max="100" step="1"
                      value={chatBgPosY}
                      onChange={(e) => applyAndSave({ chatBgPositionY: parseFloat(e.target.value) })}
                      className="w-full accent-primary h-1.5"
                    />
                  </div>
                </div>

                {/* Reset button */}
                <div className="flex justify-end">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-[10px] font-black uppercase tracking-widest text-muted-foreground hover:text-foreground h-8 px-3"
                    onClick={() => applyAndSave({ chatBgScale: 1.1, chatBgPositionX: 50, chatBgPositionY: 50, chatBgOpacity: 0.3 })}
                  >
                    <RotateCcw className="w-3 h-3 mr-1.5" />
                    Reset
                  </Button>
                </div>

                {/* Live preview — 16:9 aspect ratio matching chat screen */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Live Preview</Label>
                    <span className="text-[9px] font-mono text-muted-foreground/40 flex items-center gap-1.5">
                      <Move className="w-3 h-3" /> 드래그하여 위치 조정
                    </span>
                  </div>
                  <div
                    ref={previewRef}
                    className={cn(
                      "relative w-full rounded-2xl border border-foreground/10 overflow-hidden bg-background select-none",
                      previewDragging ? "cursor-grabbing" : "cursor-grab"
                    )}
                    style={{ aspectRatio: "16 / 9" }}
                    onMouseDown={handlePreviewDragStart}
                  >
                    {/* Ambient blobs (matching chat screen) */}
                    <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/5 blur-[60px] rounded-full pointer-events-none" />
                    <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-primary/5 blur-[60px] rounded-full pointer-events-none" />

                    {/* Background image — same rendering as ChatInterface */}
                    <div
                      className="absolute inset-0"
                      style={{
                        backgroundImage: `url("${chatBgImage}")`,
                        backgroundPosition: `${chatBgPosX}% ${chatBgPosY}%`,
                        backgroundSize: `${chatBgScale * 100}%`,
                        backgroundRepeat: "no-repeat",
                        filter: "blur(3px) grayscale(100%)",
                        opacity: chatBgOpacity,
                      }}
                    />

                    {/* Grid overlay */}
                    <div
                      className="absolute inset-0 pointer-events-none opacity-30"
                      style={{
                        backgroundImage: "linear-gradient(rgba(255,255,255,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.04) 1px, transparent 1px)",
                        backgroundSize: "10% 10%",
                      }}
                    />

                    {/* Crosshair center guides */}
                    <div className="absolute top-1/2 left-0 right-0 h-px bg-primary/10 pointer-events-none" />
                    <div className="absolute left-1/2 top-0 bottom-0 w-px bg-primary/10 pointer-events-none" />

                    {/* Mock chat UI elements for realism */}
                    <div className="absolute top-0 left-0 right-0 h-[14%] bg-background/40 backdrop-blur-sm border-b border-foreground/5 flex items-center px-4 pointer-events-none">
                      <div className="w-1 h-[60%] bg-primary/40 rounded-full" />
                      <div className="ml-2 space-y-1">
                        <div className="h-1.5 w-16 bg-foreground/20 rounded-full" />
                        <div className="h-1 w-10 bg-foreground/10 rounded-full" />
                      </div>
                    </div>

                    {/* Mock message bubbles */}
                    <div className="absolute top-[22%] left-4 right-[30%] pointer-events-none space-y-2">
                      <div className="flex items-start gap-2">
                        <div className="w-5 h-5 rounded-lg bg-foreground/10 shrink-0" />
                        <div className="h-6 bg-foreground/5 rounded-xl rounded-tl-none border border-foreground/5 flex-1" />
                      </div>
                    </div>
                    <div className="absolute top-[40%] right-4 left-[30%] pointer-events-none">
                      <div className="flex items-start gap-2 flex-row-reverse">
                        <div className="w-5 h-5 rounded-lg bg-primary/30 shrink-0" />
                        <div className="h-8 bg-primary/10 rounded-xl rounded-tr-none border border-primary/20 flex-1" />
                      </div>
                    </div>
                    <div className="absolute top-[58%] left-4 right-[20%] pointer-events-none space-y-2">
                      <div className="flex items-start gap-2">
                        <div className="w-5 h-5 rounded-lg bg-foreground/10 shrink-0" />
                        <div className="h-10 bg-foreground/5 rounded-xl rounded-tl-none border border-foreground/5 flex-1" />
                      </div>
                    </div>

                    {/* Mock input bar */}
                    <div className="absolute bottom-[6%] left-[8%] right-[8%] h-[12%] bg-background/60 backdrop-blur-sm rounded-full border border-foreground/10 pointer-events-none flex items-center px-4">
                      <div className="flex-1 h-1.5 bg-foreground/5 rounded-full" />
                      <div className="w-6 h-6 rounded-full bg-primary/30 ml-3 shrink-0" />
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </section>

        {/* ═══════════════════════════════════════════════
            SECTION 2: LLM Configuration
        ═══════════════════════════════════════════════ */}
        <section className="p-8 bg-card border border-border/30 rounded-[2rem] backdrop-blur-xl space-y-8">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-foreground/5 rounded-2xl border border-foreground/10">
              <Brain className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-black uppercase tracking-tight">LLM Configuration</h2>
              <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">모델 선택 및 파라미터 설정</p>
            </div>
          </div>

          {/* Model Presets */}
          <div className="space-y-3">
            <Label className="text-[10px] font-black uppercase tracking-widest text-primary">Model Preset</Label>
            <div className="grid grid-cols-2 gap-3">
              {MODEL_PRESETS.map((preset) => (
                <button
                  key={preset.label}
                  onClick={() => handlePresetSelect(preset)}
                  className={cn(
                    "p-4 rounded-2xl border text-left transition-all duration-300",
                    llmModel.startsWith(preset.model) && preset.model
                      ? "border-primary/40 bg-primary/10"
                      : "border-foreground/5 bg-foreground/5 hover:border-foreground/10"
                  )}
                >
                  <span className="text-xs font-black uppercase tracking-wider">{preset.label}</span>
                  {preset.model && (
                    <p className="text-[10px] font-mono text-muted-foreground mt-1">{preset.model}</p>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Model Name */}
          <div className="space-y-3">
            <Label className="text-[10px] font-black uppercase tracking-widest text-primary">Model Name</Label>
            <Input
              value={llmModel}
              onChange={(e) => setLlmModel(e.target.value)}
              placeholder="gemini/gemini-3-flash-preview"
              className="bg-black/20 border-foreground/10 h-11 text-sm font-mono"
            />
          </div>

          {/* API Base URL */}
          <div className="space-y-3">
            <Label className="text-[10px] font-black uppercase tracking-widest text-primary">API Base URL (Optional)</Label>
            <Input
              value={llmApiBase}
              onChange={(e) => setLlmApiBase(e.target.value)}
              placeholder="http://your-vllm-server:8000/v1"
              className="bg-black/20 border-foreground/10 h-11 text-sm font-mono"
            />
            <p className="text-[10px] text-muted-foreground font-mono">hosted_vllm 등 자체 서버 사용 시 입력</p>
          </div>

          {/* API Key Override */}
          <div className="space-y-3">
            <Label className="text-[10px] font-black uppercase tracking-widest text-primary">API Key Override (Optional)</Label>
            <Input
              type="password"
              value={llmApiKey}
              onChange={(e) => setLlmApiKey(e.target.value)}
              placeholder="서버 .env의 GOOGLE_API_KEY를 오버라이드"
              className="bg-black/20 border-foreground/10 h-11 text-sm font-mono"
            />
          </div>

          {/* Temperature */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-[10px] font-black uppercase tracking-widest text-primary">Temperature</Label>
              <span className="text-sm font-mono font-bold text-primary">{llmTemp.toFixed(1)}</span>
            </div>
            <input
              type="range"
              min="0"
              max="2"
              step="0.1"
              value={llmTemp}
              onChange={(e) => setLlmTemp(parseFloat(e.target.value))}
              className="w-full accent-primary h-2"
            />
            <div className="flex justify-between text-[9px] text-muted-foreground font-mono">
              <span>0.0 (정확)</span>
              <span>1.0</span>
              <span>2.0 (창의적)</span>
            </div>
          </div>

          {/* Max Tokens */}
          <div className="space-y-3">
            <Label className="text-[10px] font-black uppercase tracking-widest text-primary">Max Tokens</Label>
            <Input
              type="number"
              value={llmMaxTokens}
              onChange={(e) => setLlmMaxTokens(parseInt(e.target.value) || 4096)}
              className="bg-black/20 border-foreground/10 h-11 text-sm font-mono w-40"
            />
          </div>

          {/* System Prompt */}
          <div className="space-y-3">
            <Label className="text-[10px] font-black uppercase tracking-widest text-primary">System Prompt</Label>
            <textarea
              value={llmSystemPrompt}
              onChange={(e) => setLlmSystemPrompt(e.target.value)}
              placeholder="기본 시스템 프롬프트를 입력하세요 (비어있으면 기본값 사용)"
              className="w-full bg-black/20 border border-foreground/10 rounded-md p-4 text-xs font-mono text-foreground min-h-[120px] resize-y focus:outline-none focus:border-primary/50 transition-colors"
            />
          </div>

          {/* Save Button */}
          <Button
            onClick={handleLLMSave}
            disabled={llmSaving}
            className="h-12 px-8 bg-primary text-primary-foreground font-black uppercase tracking-widest hover:opacity-90"
          >
            {llmSaved ? (
              <><Check className="w-4 h-4 mr-2" /> Saved</>
            ) : (
              <><Save className="w-4 h-4 mr-2" /> {llmSaving ? "Saving..." : "Save LLM Settings"}</>
            )}
          </Button>
        </section>

        {/* ═══════════════════════════════════════════════
            SECTION 3: User Profile
        ═══════════════════════════════════════════════ */}
        <section className="p-8 bg-card border border-border/30 rounded-[2rem] backdrop-blur-xl space-y-8">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-foreground/5 rounded-2xl border border-foreground/10">
              <UserCircle className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-black uppercase tracking-tight">User Profile</h2>
              <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">채팅에 표시될 이름과 사진</p>
            </div>
          </div>

          <div className="flex items-start gap-8">
            {/* Avatar */}
            <div className="space-y-3 flex flex-col items-center">
              <input
                ref={avatarInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleAvatarSelect}
              />
              <div
                className="w-24 h-24 rounded-2xl border-2 border-dashed border-foreground/10 overflow-hidden cursor-pointer hover:border-primary/30 transition-colors flex items-center justify-center bg-foreground/5"
                onClick={() => avatarInputRef.current?.click()}
              >
                {profile.avatar ? (
                  <img src={profile.avatar} alt="avatar" className="w-full h-full object-cover" />
                ) : (
                  <Upload className="w-6 h-6 text-foreground/20" />
                )}
              </div>
              <span className="text-[9px] text-muted-foreground font-mono">클릭하여 변경</span>
            </div>

            {/* Name */}
            <div className="flex-1 space-y-3">
              <Label className="text-[10px] font-black uppercase tracking-widest text-primary">Display Name</Label>
              <Input
                value={profile.name}
                onChange={(e) => setProfile((p) => ({ ...p, name: e.target.value }))}
                placeholder="이름을 입력하세요"
                className="bg-black/20 border-foreground/10 h-11 text-sm"
              />
              <p className="text-[10px] text-muted-foreground">채팅 메시지에 표시됩니다.</p>
            </div>
          </div>

          <Button
            onClick={handleProfileSave}
            className="h-12 px-8 bg-primary text-primary-foreground font-black uppercase tracking-widest hover:opacity-90"
          >
            {profileSaved ? (
              <><Check className="w-4 h-4 mr-2" /> Saved</>
            ) : (
              <><Save className="w-4 h-4 mr-2" /> Save Profile</>
            )}
          </Button>
        </section>

        {/* ═══════════════════════════════════════════════
            SECTION 4: Connection Status
        ═══════════════════════════════════════════════ */}
        <section className="p-8 bg-card border border-border/30 rounded-[2rem] backdrop-blur-xl space-y-8">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-foreground/5 rounded-2xl border border-foreground/10">
              <Activity className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-black uppercase tracking-tight">Connection Status</h2>
              <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest">백엔드 서버 연결 상태</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-foreground/5 rounded-2xl border border-foreground/5">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-foreground">API Server</span>
                <p className="text-xs font-mono text-muted-foreground mt-1">{API_BASE_URL}</p>
              </div>
              <div className="flex items-center gap-3">
                {health === null ? (
                  <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Unknown</span>
                ) : health ? (
                  <span className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-emerald-400">
                    <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_theme(colors.emerald.500)]" />
                    Connected
                  </span>
                ) : (
                  <span className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-red-400">
                    <div className="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_8px_theme(colors.red.500)]" />
                    Disconnected
                  </span>
                )}
              </div>
            </div>

            {llm && (
              <div className="flex items-center justify-between p-4 bg-foreground/5 rounded-2xl border border-foreground/5">
                <div>
                  <span className="text-[10px] font-black uppercase tracking-widest text-foreground">Active Model</span>
                  <p className="text-xs font-mono text-muted-foreground mt-1">{llm.model}</p>
                </div>
                {llm.api_base && (
                  <span className="text-[10px] font-mono text-muted-foreground">{llm.api_base}</span>
                )}
              </div>
            )}

            <Button
              variant="outline"
              onClick={handleHealthCheck}
              disabled={checking}
              className="h-12 rounded-none border-2 px-6 font-black uppercase tracking-widest hover:bg-foreground/5"
            >
              <Activity className={cn("w-4 h-4 mr-2", checking && "animate-spin")} />
              {checking ? "Checking..." : "Check Connection"}
            </Button>
          </div>
        </section>
      </div>
    </div>
  );
}
