"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { Send, User, Bot, Wrench, Plus, Hammer, ImageIcon, Check, X, ZoomIn, ZoomOut, RotateCcw } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

import { cn } from "@/lib/utils";
import { API_BASE_URL } from "@/lib/config";
import { validateFile, fileToBase64, type AttachedFile } from "@/lib/file-utils";
import { FilePreviewChips } from "@/components/chat/FilePreviewChips";
import { MCPToolsPanel } from "@/components/chat/MCPToolsPanel";
import { loadProfile, type UserProfile } from "@/lib/stores/profile";
import { loadTheme, saveTheme, type ThemeSettings } from "@/lib/stores/theme";

type MessageContent =
  | string
  | Array<{ type: "text"; text: string } | { type: "image_url"; image_url: { url: string } }>;

type Message = {
  role: "user" | "assistant" | "tool";
  content: MessageContent;
  name?: string;
  tool_call_id?: string;
  _images?: string[];
};

function getTextContent(content: MessageContent): string {
  if (typeof content === "string") return content;
  const textPart = content.find((p) => p.type === "text");
  return textPart ? (textPart as { type: "text"; text: string }).text : "";
}

function getImageUrls(content: MessageContent): string[] {
  if (typeof content === "string") return [];
  return content
    .filter((p) => p.type === "image_url")
    .map((p) => (p as { type: "image_url"; image_url: { url: string } }).image_url.url);
}

export function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "안녕하세요! Nexus Agent입니다. 무엇을 도와드릴까요?" },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState<AttachedFile[]>([]);
  const [mcpPanelOpen, setMcpPanelOpen] = useState(false);
  const [profile, setProfile] = useState<UserProfile>({ name: "", avatar: "" });

  // Background settings
  const [chatBgImage, setChatBgImage] = useState("/rubber-track.png");
  const [chatBgOpacity, setChatBgOpacity] = useState(0.3);
  const [chatBgScale, setChatBgScale] = useState(1.1);
  const [chatBgPosX, setChatBgPosX] = useState(50);
  const [chatBgPosY, setChatBgPosY] = useState(50);

  // Edit mode for background positioning
  const [bgEditMode, setBgEditMode] = useState(false);
  const [editScale, setEditScale] = useState(1.1);
  const [editPosX, setEditPosX] = useState(50);
  const [editPosY, setEditPosY] = useState(50);
  const [editOpacity, setEditOpacity] = useState(0.3);
  const [dragging, setDragging] = useState(false);
  const dragStartRef = useRef({ x: 0, y: 0, posX: 50, posY: 50 });
  const bgContainerRef = useRef<HTMLDivElement>(null);

  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const loadBgFromTheme = useCallback(() => {
    const t = loadTheme();
    setChatBgImage(t.chatBgImage);
    setChatBgOpacity(t.chatBgOpacity);
    setChatBgScale(t.chatBgScale);
    setChatBgPosX(t.chatBgPositionX);
    setChatBgPosY(t.chatBgPositionY);
  }, []);

  useEffect(() => {
    setProfile(loadProfile());
    loadBgFromTheme();

    const profileHandler = () => setProfile(loadProfile());
    const themeHandler = () => loadBgFromTheme();
    window.addEventListener("profile-change", profileHandler);
    window.addEventListener("theme-change", themeHandler);
    return () => {
      window.removeEventListener("profile-change", profileHandler);
      window.removeEventListener("theme-change", themeHandler);
    };
  }, [loadBgFromTheme]);

  useEffect(() => {
    requestAnimationFrame(() => {
      if (scrollRef.current) {
        scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
      }
    });
  }, [messages]);

  // --- BG Edit handlers ---
  const enterBgEdit = () => {
    setEditScale(chatBgScale);
    setEditPosX(chatBgPosX);
    setEditPosY(chatBgPosY);
    setEditOpacity(chatBgOpacity);
    setBgEditMode(true);
  };

  const saveBgEdit = () => {
    const theme = loadTheme();
    const next: ThemeSettings = {
      ...theme,
      chatBgScale: editScale,
      chatBgPositionX: editPosX,
      chatBgPositionY: editPosY,
      chatBgOpacity: editOpacity,
    };
    saveTheme(next);
    setChatBgScale(editScale);
    setChatBgPosX(editPosX);
    setChatBgPosY(editPosY);
    setChatBgOpacity(editOpacity);
    setBgEditMode(false);
    window.dispatchEvent(new Event("theme-change"));
  };

  const cancelBgEdit = () => {
    setBgEditMode(false);
  };

  const resetBgEdit = () => {
    setEditScale(1.1);
    setEditPosX(50);
    setEditPosY(50);
    setEditOpacity(0.3);
  };

  const handleDragStart = (e: React.MouseEvent) => {
    e.preventDefault();
    setDragging(true);
    dragStartRef.current = { x: e.clientX, y: e.clientY, posX: editPosX, posY: editPosY };
  };

  useEffect(() => {
    if (!dragging) return;
    const handleMove = (e: MouseEvent) => {
      const container = bgContainerRef.current;
      if (!container) return;
      const rect = container.getBoundingClientRect();
      const dx = e.clientX - dragStartRef.current.x;
      const dy = e.clientY - dragStartRef.current.y;
      // Convert pixel delta to percentage (inverted: drag right = position moves left)
      const pctX = (dx / rect.width) * 100;
      const pctY = (dy / rect.height) * 100;
      setEditPosX(Math.max(0, Math.min(100, dragStartRef.current.posX - pctX)));
      setEditPosY(Math.max(0, Math.min(100, dragStartRef.current.posY - pctY)));
    };
    const handleUp = () => setDragging(false);
    window.addEventListener("mousemove", handleMove);
    window.addEventListener("mouseup", handleUp);
    return () => {
      window.removeEventListener("mousemove", handleMove);
      window.removeEventListener("mouseup", handleUp);
    };
  }, [dragging]);

  // Wheel zoom in edit mode
  const handleWheel = useCallback((e: WheelEvent) => {
    e.preventDefault();
    setEditScale((prev) => Math.max(0.5, Math.min(5, prev + (e.deltaY > 0 ? -0.1 : 0.1))));
  }, []);

  useEffect(() => {
    if (!bgEditMode) return;
    const container = bgContainerRef.current;
    if (!container) return;
    container.addEventListener("wheel", handleWheel, { passive: false });
    return () => container.removeEventListener("wheel", handleWheel);
  }, [bgEditMode, handleWheel]);

  // --- File / send handlers ---
  const handleFileSelect = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    for (const file of Array.from(files)) {
      const error = validateFile(file);
      if (error) {
        alert(error);
        continue;
      }
      const base64 = await fileToBase64(file);
      const attached: AttachedFile = {
        id: crypto.randomUUID(),
        file,
        preview: URL.createObjectURL(file),
        base64,
        mimeType: file.type,
      };
      setAttachedFiles((prev) => [...prev, attached]);
    }
    e.target.value = "";
  }, []);

  const removeFile = useCallback((id: string) => {
    setAttachedFiles((prev) => {
      const file = prev.find((f) => f.id === id);
      if (file) URL.revokeObjectURL(file.preview);
      return prev.filter((f) => f.id !== id);
    });
  }, []);

  const handleSend = async () => {
    if ((!input.trim() && attachedFiles.length === 0) || isLoading) return;

    let userContent: MessageContent;
    let displayImages: string[] = [];

    if (attachedFiles.length > 0) {
      const parts: Array<{ type: "text"; text: string } | { type: "image_url"; image_url: { url: string } }> = [];
      for (const f of attachedFiles) {
        parts.push({ type: "image_url", image_url: { url: f.base64 } });
        displayImages.push(f.base64);
      }
      if (input.trim()) {
        parts.push({ type: "text", text: input });
      }
      userContent = parts;
    } else {
      userContent = input;
    }

    const userMessage: Message = {
      role: "user",
      content: userContent,
      _images: displayImages.length > 0 ? displayImages : undefined,
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    attachedFiles.forEach((f) => URL.revokeObjectURL(f.preview));
    setAttachedFiles([]);
    setIsLoading(true);

    try {
      const apiMessages = [...messages, userMessage].map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const response = await fetch(`${API_BASE_URL}/api/chat/`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: apiMessages }),
      });

      if (!response.ok) throw new Error("API request failed");

      const data = await response.json();
      const assistantMessage = data.choices[0].message;

      setMessages((prev) => [...prev, {
        role: "assistant",
        content: assistantMessage.content,
      }]);
    } catch (error) {
      console.error("Chat error:", error);
      setMessages((prev) => [...prev, { role: "assistant", content: "죄송합니다. 오류가 발생했습니다." }]);
    } finally {
      setIsLoading(false);
    }
  };

  // Current BG values (edit mode uses draft, normal uses saved)
  const bgScale = bgEditMode ? editScale : chatBgScale;
  const bgPosX = bgEditMode ? editPosX : chatBgPosX;
  const bgPosY = bgEditMode ? editPosY : chatBgPosY;
  const bgOpacity = bgEditMode ? editOpacity : chatBgOpacity;

  return (
    <div className="flex flex-col h-full bg-background relative overflow-hidden text-foreground" ref={bgContainerRef}>
      {/* Background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/5 blur-[120px] rounded-full" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-primary/5 blur-[120px] rounded-full" />
          {chatBgImage && (
            <div
              className={cn("absolute inset-0 grayscale contrast-125", bgEditMode && "pointer-events-auto cursor-grab", bgEditMode && dragging && "cursor-grabbing")}
              style={{
                backgroundImage: `url("${chatBgImage}")`,
                backgroundPosition: `${bgPosX}% ${bgPosY}%`,
                backgroundSize: `${bgScale * 100}%`,
                backgroundRepeat: 'no-repeat',
                filter: 'blur(3px) grayscale(100%)',
                opacity: bgOpacity,
              }}
              onMouseDown={bgEditMode ? handleDragStart : undefined}
            />
          )}
      </div>

      {/* BG Edit overlay */}
      {bgEditMode && (
        <div className="absolute inset-0 z-40 pointer-events-none">
          {/* Grid overlay */}
          <div className="absolute inset-0 border border-primary/20" style={{
            backgroundImage: 'linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)',
            backgroundSize: '10% 10%',
          }} />
          {/* Crosshair */}
          <div className="absolute top-1/2 left-0 right-0 h-px bg-primary/20" />
          <div className="absolute left-1/2 top-0 bottom-0 w-px bg-primary/20" />

          {/* Controls bar at top */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 pointer-events-auto flex items-center gap-2 bg-background/90 backdrop-blur-xl border border-primary/30 rounded-full px-4 py-2 shadow-2xl z-50">
            <span className="text-[9px] font-black uppercase tracking-widest text-primary mr-2">BG Edit</span>

            <Button variant="ghost" size="icon" className="h-8 w-8 text-foreground/60 hover:text-foreground" onClick={() => setEditScale((s) => Math.max(0.5, s - 0.1))} title="Zoom Out">
              <ZoomOut className="w-4 h-4" />
            </Button>
            <span className="text-[10px] font-mono font-bold text-foreground/80 w-12 text-center">{(editScale * 100).toFixed(0)}%</span>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-foreground/60 hover:text-foreground" onClick={() => setEditScale((s) => Math.min(5, s + 0.1))} title="Zoom In">
              <ZoomIn className="w-4 h-4" />
            </Button>

            <div className="w-px h-5 bg-foreground/10 mx-1" />

            <span className="text-[9px] font-mono text-foreground/50">opacity</span>
            <input
              type="range" min="0" max="1" step="0.05" value={editOpacity}
              onChange={(e) => setEditOpacity(parseFloat(e.target.value))}
              className="w-20 accent-primary h-1.5"
            />
            <span className="text-[10px] font-mono font-bold text-foreground/80 w-9 text-center">{(editOpacity * 100).toFixed(0)}%</span>

            <div className="w-px h-5 bg-foreground/10 mx-1" />

            <Button variant="ghost" size="icon" className="h-8 w-8 text-foreground/60 hover:text-foreground" onClick={resetBgEdit} title="Reset">
              <RotateCcw className="w-3.5 h-3.5" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-red-400 hover:text-red-300 hover:bg-red-500/10" onClick={cancelBgEdit} title="Cancel">
              <X className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10" onClick={saveBgEdit} title="Save">
              <Check className="w-4 h-4" />
            </Button>
          </div>

          {/* Position info */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 pointer-events-none text-[9px] font-mono text-foreground/40 bg-background/60 px-3 py-1 rounded-full backdrop-blur-sm">
            pos: {editPosX.toFixed(0)}%, {editPosY.toFixed(0)}% &middot; scale: {(editScale * 100).toFixed(0)}% &middot; drag to move, scroll to zoom
          </div>
        </div>
      )}

      <header className="px-8 py-6 border-b border-foreground/5 bg-background/40 backdrop-blur-xl sticky top-0 z-10 flex items-center justify-between">
        <div className="flex items-center gap-4">
            <div className="w-1 h-8 bg-gradient-to-b from-primary to-orange-600 rounded-full shadow-[0_0_10px_var(--primary)]" />
            <div className="flex flex-col">
                <h1 className="text-xs font-black uppercase tracking-[0.3em] text-foreground/90">Operational Command</h1>
                <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest opacity-50">Nexus Active Session</span>
            </div>
        </div>
        <div className="flex items-center gap-6">
            {/* BG edit button */}
            {chatBgImage && !bgEditMode && (
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 rounded-full text-muted-foreground/30 hover:text-foreground/60 hover:bg-foreground/10 transition-colors"
                onClick={enterBgEdit}
                title="Edit background position"
              >
                <ImageIcon className="w-3.5 h-3.5" />
              </Button>
            )}
            <div className="flex items-center gap-2 px-3 py-1.5 bg-foreground/5 rounded-full border border-foreground/5">
                <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse shadow-[0_0_8px_var(--primary)]" />
                <span className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest">Link Secure</span>
            </div>
            <span className="text-[10px] font-mono text-muted-foreground/30 uppercase tracking-[0.2em] hidden sm:block">ID: NB-772-X</span>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-4 lg:px-8 py-10" ref={scrollRef}>
        <div className="max-w-4xl mx-auto space-y-12 pb-40">
          {messages.map((msg, idx) => {
            const text = getTextContent(msg.content);
            const images = msg._images ?? getImageUrls(msg.content);

            return (
              <div
                key={idx}
                className={cn(
                  "flex gap-4 lg:gap-6 group animate-in fade-in slide-in-from-bottom-4 duration-700",
                  msg.role === "user" ? "flex-row-reverse" : "flex-row"
                )}
              >
                <div className={cn(
                  "w-10 h-10 lg:w-12 lg:h-12 flex items-center justify-center shrink-0 rounded-2xl transition-all duration-500 shadow-xl overflow-hidden",
                  msg.role === "user"
                    ? "bg-gradient-to-br from-primary to-orange-600 text-primary-foreground shadow-primary/20 scale-95 group-hover:scale-100"
                    : "bg-foreground/5 border border-foreground/10 text-muted-foreground group-hover:bg-foreground/10"
                )}>
                  {msg.role === "user"
                    ? (profile.avatar
                      ? <img src={profile.avatar} alt="avatar" className="w-full h-full object-cover" />
                      : <User size={20} className="lg:w-5 lg:h-5" />)
                    : <Bot size={20} className="lg:w-5 lg:h-5" />
                  }
                </div>

                <div className={cn(
                  "flex flex-col gap-2 max-w-[85%] lg:max-w-[75%]",
                  msg.role === "user" ? "items-end" : "items-start"
                )}>
                  <div className={cn(
                    "relative px-6 py-4 rounded-[2rem] transition-all duration-300 shadow-2xl",
                    msg.role === "user"
                      ? "bg-primary/10 border border-primary/20 text-foreground rounded-tr-none"
                      : "bg-foreground/5 border border-foreground/5 text-foreground rounded-tl-none backdrop-blur-sm hover:bg-foreground/10"
                  )}>
                    {msg.role === "tool" && msg.name && (
                      <div className="flex items-center gap-2 font-mono text-[9px] uppercase font-black text-primary/70 mb-2 tracking-[0.2em]">
                        <Wrench size={12} />
                        <span>
                          {msg.name.includes("__")
                            ? `[${msg.name.split("__")[0]}] ${msg.name.split("__")[1]}`
                            : msg.name}
                        </span>
                      </div>
                    )}

                    {images.length > 0 && (
                      <div className="flex flex-wrap gap-2 mb-3">
                        {images.map((src, i) => (
                          <img
                            key={i}
                            src={src}
                            alt={`attached-${i}`}
                            className="max-w-[200px] max-h-[200px] rounded-xl object-cover border border-foreground/10"
                          />
                        ))}
                      </div>
                    )}

                    {text && (
                      <div className="prose prose-sm dark:prose-invert max-w-none text-inherit leading-relaxed font-medium tracking-tight">
                        <ReactMarkdown remarkPlugins={[remarkGfm]}>
                          {text}
                        </ReactMarkdown>
                      </div>
                    )}
                  </div>

                  <div className="px-2 text-[9px] font-bold text-muted-foreground/30 uppercase tracking-[0.2em]">
                      {msg.role === "user" ? (profile.name || "Authorized Personnel") : "Nexus Platform Core"}
                  </div>

                  {msg.role === "assistant" && idx === messages.length - 1 && isLoading && (
                     <div className="flex items-center gap-3 mt-4 px-4 py-2 bg-foreground/5 rounded-full border border-foreground/5">
                         <div className="flex gap-1.5">
                             <div className="w-1 h-1 bg-primary rounded-full animate-bounce [animation-delay:-0.3s]" />
                             <div className="w-1 h-1 bg-primary rounded-full animate-bounce [animation-delay:-0.15s]" />
                             <div className="w-1 h-1 bg-primary rounded-full animate-bounce" />
                         </div>
                         <span className="text-[9px] font-black text-primary/60 uppercase tracking-widest">Processing Logic...</span>
                     </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/png,image/jpeg,image/gif,image/webp"
        multiple
        onChange={handleFileSelect}
        className="hidden"
      />

      {/* MCP Tools Panel */}
      <MCPToolsPanel open={mcpPanelOpen} onOpenChange={setMcpPanelOpen} />

      <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-10 pointer-events-none">
        <div className="max-w-4xl mx-auto pointer-events-auto">
          <div className="relative group">
            {/* Glow Effect */}
            <div className="absolute -inset-1 bg-gradient-to-r from-primary/20 to-orange-600/20 blur-xl opacity-0 group-focus-within:opacity-100 transition duration-1000" />

            <div className="relative bg-background/60 backdrop-blur-2xl rounded-[2.5rem] border border-foreground/10 shadow-2xl transition-all duration-300 focus-within:border-primary/50 focus-within:shadow-[0_0_40px_-10px_rgba(245,158,11,0.2)]">
              {/* File preview chips */}
              {attachedFiles.length > 0 && (
                <div className="pt-3">
                  <FilePreviewChips files={attachedFiles} onRemove={removeFile} />
                </div>
              )}

              <div className="flex items-center gap-2 p-2 pl-4">
                {/* + button for file attach */}
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => fileInputRef.current?.click()}
                  className="h-10 w-10 rounded-full text-muted-foreground/50 hover:text-foreground hover:bg-foreground/10 transition-colors shrink-0"
                >
                  <Plus className="w-5 h-5" />
                </Button>

                {/* MCP tools button */}
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => setMcpPanelOpen(true)}
                  className="h-10 w-10 rounded-full text-muted-foreground/50 hover:text-foreground hover:bg-foreground/10 transition-colors shrink-0"
                >
                  <Hammer className="w-4 h-4" />
                </Button>

                <Input
                  placeholder="TRANSMIT SYSTEM COMMAND..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSend()}
                  className="flex-1 border-none bg-transparent h-14 text-sm font-bold tracking-tight focus-visible:ring-0 placeholder:text-muted-foreground/20 uppercase"
                />
                <Button
                  onClick={handleSend}
                  disabled={isLoading || (!input.trim() && attachedFiles.length === 0)}
                  className="h-14 w-14 rounded-full bg-gradient-to-br from-primary to-orange-600 text-primary-foreground shadow-lg shadow-primary/20 hover:scale-105 active:scale-95 transition-all duration-300"
                >
                  <Send className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
          <div className="flex justify-between items-center mt-6 px-8">
              <span className="text-[9px] font-black text-muted-foreground/20 uppercase tracking-[0.3em]">Operational Access Restricted</span>
              <div className="flex items-center gap-4">
                  <span className="text-[9px] font-black text-primary/40 uppercase tracking-[0.3em]">Biometric Sync Active</span>
                  <div className="h-1 w-12 bg-foreground/5 rounded-full overflow-hidden">
                      <div className="h-full w-2/3 bg-primary/30" />
                  </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  );
}
