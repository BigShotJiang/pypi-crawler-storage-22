import { API_BASE_URL } from "@/lib/config";

const BASE_URL = API_BASE_URL;

// --- Types ---

export type LLMSettings = {
  model: string;
  api_base: string | null;
  api_key: string | null;
  temperature: number;
  max_tokens: number;
  system_prompt: string;
};

// --- API Functions ---

export async function checkHealth(): Promise<boolean> {
  try {
    const res = await fetch(`${BASE_URL}/api/settings/health`, { signal: AbortSignal.timeout(5000) });
    return res.ok;
  } catch {
    return false;
  }
}

export async function fetchLLMSettings(): Promise<LLMSettings> {
  const res = await fetch(`${BASE_URL}/api/settings/llm`);
  if (!res.ok) throw new Error("Failed to fetch LLM settings");
  return res.json();
}

export async function updateLLMSettings(updates: Partial<LLMSettings>): Promise<LLMSettings> {
  const res = await fetch(`${BASE_URL}/api/settings/llm`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(updates),
  });
  if (!res.ok) throw new Error("Failed to update LLM settings");
  return res.json();
}
