const STORAGE_KEY = "nexus-profile";

export type UserProfile = {
  name: string;
  avatar: string; // base64 data URI or empty
};

const defaults: UserProfile = {
  name: "",
  avatar: "",
};

export function loadProfile(): UserProfile {
  if (typeof window === "undefined") return defaults;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? { ...defaults, ...JSON.parse(raw) } : defaults;
  } catch {
    return defaults;
  }
}

export function saveProfile(profile: UserProfile): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
}
