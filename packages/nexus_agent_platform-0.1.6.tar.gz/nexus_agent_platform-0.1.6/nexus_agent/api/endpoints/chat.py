from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any
from nexus_agent.core.agent import orchestrator

router = APIRouter()

class ChatRequest(BaseModel):
    messages: List[Dict[str, Any]]

@router.post("/")
async def chat(request: ChatRequest):
    try:
        response = await orchestrator.run(request.messages)
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
