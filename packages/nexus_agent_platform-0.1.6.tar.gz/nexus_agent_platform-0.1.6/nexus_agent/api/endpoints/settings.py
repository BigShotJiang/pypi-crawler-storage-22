from fastapi import APIRouter

from nexus_agent.core.settings_manager import settings_manager
from nexus_agent.models.settings import LLMSettings, UpdateLLMRequest

router = APIRouter()


@router.get("/health")
async def health_check():
    return {"status": "ok"}


@router.get("/llm", response_model=LLMSettings)
async def get_llm_settings():
    # api_key를 응답에서 마스킹
    llm = settings_manager.llm.model_copy()
    if llm.api_key:
        llm.api_key = llm.api_key[:4] + "***" + llm.api_key[-4:]
    return llm


@router.patch("/llm", response_model=LLMSettings)
async def update_llm_settings(req: UpdateLLMRequest):
    updated = settings_manager.update_llm(**req.model_dump(exclude_none=True))
    # api_key를 응답에서 마스킹
    result = updated.model_copy()
    if result.api_key:
        result.api_key = result.api_key[:4] + "***" + result.api_key[-4:]
    return result
