import os
from typing import List, Dict, Any, AsyncGenerator
from pydantic import BaseModel
from litellm import acompletion


class Message(BaseModel):
    role: str
    content: str


class LLMClient:
    def _get_config(self) -> Dict[str, Any]:
        """settings_manager에서 현재 설정을 동적으로 읽음"""
        from nexus_agent.core.settings_manager import settings_manager

        llm = settings_manager.llm
        api_key = llm.api_key or os.getenv("GOOGLE_API_KEY")

        config: Dict[str, Any] = {
            "model": llm.model,
            "api_key": api_key,
            "temperature": llm.temperature,
            "max_tokens": llm.max_tokens,
        }
        if llm.api_base:
            config["api_base"] = llm.api_base
        return config

    def get_system_prompt(self) -> str:
        from nexus_agent.core.settings_manager import settings_manager
        return settings_manager.llm.system_prompt

    async def chat_completion(self, messages: List[Dict[str, Any]], tools: List[Dict[str, Any]] = None) -> Dict[str, Any]:
        config = self._get_config()
        kwargs = {
            **config,
            "messages": messages,
        }
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"

        response = await acompletion(**kwargs)
        return response.model_dump()

    async def chat_stream(self, messages: List[Dict[str, Any]]) -> AsyncGenerator[str, None]:
        config = self._get_config()
        kwargs = {
            **config,
            "messages": messages,
            "stream": True,
        }

        response = await acompletion(**kwargs)
        async for chunk in response:
            content = chunk.choices[0].delta.content
            if content:
                yield content


llm_client = LLMClient()
