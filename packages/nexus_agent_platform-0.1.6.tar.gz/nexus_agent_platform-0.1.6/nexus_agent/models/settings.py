from typing import Optional
from pydantic import BaseModel


class LLMSettings(BaseModel):
    model: str = "gemini/gemini-3-flash-preview"
    api_base: Optional[str] = None
    api_key: Optional[str] = None  # override, 미설정 시 env GOOGLE_API_KEY 사용
    temperature: float = 0.7
    max_tokens: int = 4096
    system_prompt: str = ""


class AppSettings(BaseModel):
    llm: LLMSettings = LLMSettings()


class UpdateLLMRequest(BaseModel):
    model: Optional[str] = None
    api_base: Optional[str] = None
    api_key: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    system_prompt: Optional[str] = None
