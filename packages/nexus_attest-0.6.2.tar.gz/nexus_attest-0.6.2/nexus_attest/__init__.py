"""
nexus-attest: Cryptographic attestation and verification layer for MCP tool executions.

Every execution is tied to:
- a cryptographic attestation (signed claims + digest)
- a decision (the request + policy)
- an approval trail (who approved, when, with what authority)
- a nexus-router run_id (for full execution audit)

Everything is exportable, verifiable, and replayable.
"""

__version__ = "0.6.2"

from nexus_attest.audit_export import export_audit_package
from nexus_attest.audit_package import (
    PACKAGE_VERSION,
    AuditPackage,
    VerificationResult,
    verify_audit_package,
)
from nexus_attest.bundle import (
    BUNDLE_VERSION,
    DecisionBundle,
)
from nexus_attest.decision import Decision, DecisionState, TemplateRef
from nexus_attest.events import Actor, EventType
from nexus_attest.export import export_decision
from nexus_attest.import_ import import_bundle
from nexus_attest.lifecycle import (
    DEFAULT_TIMELINE_LIMIT,
    BlockingReason,
    Lifecycle,
    LifecycleEntry,
    LifecycleProgress,
    compute_lifecycle,
)
from nexus_attest.policy import Policy
from nexus_attest.store import DecisionStore
from nexus_attest.template import Template, TemplateStore
from nexus_attest.tool import NexusControlTools, ToolResult

__all__ = [
    "BUNDLE_VERSION",
    "DEFAULT_TIMELINE_LIMIT",
    "PACKAGE_VERSION",
    "Actor",
    "AuditPackage",
    "BlockingReason",
    "Decision",
    "DecisionBundle",
    "DecisionState",
    "DecisionStore",
    "EventType",
    "Lifecycle",
    "LifecycleEntry",
    "LifecycleProgress",
    "NexusControlTools",
    "Policy",
    "Template",
    "TemplateRef",
    "TemplateStore",
    "ToolResult",
    "VerificationResult",
    "compute_lifecycle",
    "export_audit_package",
    "export_decision",
    "import_bundle",
    "verify_audit_package",
]
