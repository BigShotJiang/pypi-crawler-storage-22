"""Tests for nexus-control."""
