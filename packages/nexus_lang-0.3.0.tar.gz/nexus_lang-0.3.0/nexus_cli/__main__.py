"""CLI main entry point"""
from nexus_cli import main

if __name__ == '__main__':
    main()
