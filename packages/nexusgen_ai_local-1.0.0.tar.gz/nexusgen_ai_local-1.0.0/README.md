# NexusGen AI\nIA local de 0.5 Bilhões de parâmetros.
