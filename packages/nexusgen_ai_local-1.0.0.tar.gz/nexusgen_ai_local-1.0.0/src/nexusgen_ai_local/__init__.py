"""NexusGen: IA local de 0.5B para Termux."""
__version__ = "1.0.0"
