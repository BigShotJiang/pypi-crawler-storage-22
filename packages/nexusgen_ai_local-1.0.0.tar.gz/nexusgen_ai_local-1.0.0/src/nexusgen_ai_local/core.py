import os
from huggingface_hub import hf_hub_download
from llama_cpp import Llama

class NexusGen:
    def __init__(self):
        print("🧬 NexusGen: Inicializando sistema...")
        # Baixa o modelo real de 0.5B (Qwen 2.5)
        self.model_path = hf_hub_download(
            repo_id="Qwen/Qwen2.5-0.5B-Instruct-GGUF",
            filename="qwen2.5-0.5b-instruct-q8_0.gguf"
        )
        # Carrega o modelo no motor C++
        self.llm = Llama(model_path=self.model_path, n_ctx=512, n_threads=4)

    def ask(self, prompt):
        output = self.llm(
            f"<|im_start|>user\n{prompt}<|im_end|>\n<|im_start|>assistant\n",
            max_tokens=128,
            stop=["<|im_end|>"],
            echo=False
        )
        return output['choices'][0]['text']
