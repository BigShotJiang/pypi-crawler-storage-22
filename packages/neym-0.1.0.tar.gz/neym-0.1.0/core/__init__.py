"""Core package for neym library."""
