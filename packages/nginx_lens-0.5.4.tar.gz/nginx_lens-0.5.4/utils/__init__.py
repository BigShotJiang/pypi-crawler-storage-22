"""
Утилиты для nginx-lens.
"""

