#ifndef FILE_MESHTENTSLAB_HPP
#define FILE_MESHTENTSLAB_HPP

#ifdef NGS_PYTHON
#include <python_ngstd.hpp>
void ExportMesh1dTents (py::module m);
#endif // NGS_PYTHON

#endif
