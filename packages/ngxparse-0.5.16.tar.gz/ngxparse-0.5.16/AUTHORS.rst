=======
Credits
=======

Development Lead
----------------

* Arie van Luttikhuizen <aluttik@gmail.com> `@aluttik <https://github.com/aluttik>`_

Contributors
------------

* Grant Hulegaard <loki.labrys@gmail.com> `@gshulegaard <https://github.com/gshulegaard>`_ (`GitLab <https://gitlab.com/gshulegaard>`__)
* Ivan Poluyanov <i.poluyanov@icloud.com> `@poluyanov <https://github.com/poluyanov>`_
* Raymond Lau <raymond.lau.ca@gmail.com> `@Raymond26 <https://github.com/Raymond26>`_
* Luca Comellini <luca.com@gmail.com> `@lucacome <https://github.com/lucacome>`_
* Ron Vider <viderron@gmail.com> `@RonVider <https://github.com/RonVider>`_
