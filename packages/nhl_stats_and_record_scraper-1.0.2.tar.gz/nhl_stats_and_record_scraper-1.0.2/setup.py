from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
readme_path = this_directory / "README.md"

long_description = ""
if readme_path.exists():
    long_description = readme_path.read_text(encoding="utf-8")

setup(
    name="nhl_stats_and_record_scraper",
    version="1.0.2",
    packages=find_packages(),
    long_description=long_description,
    long_description_content_type="text/markdown",
    install_requires=[
        "requests"
    ],
)
