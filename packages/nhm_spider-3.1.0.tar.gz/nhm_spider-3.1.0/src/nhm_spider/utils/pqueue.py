from asyncio import PriorityQueue

from nhm_spider.utils.log import get_logger


class SpiderPriorityQueue(PriorityQueue):
    def __init__(self, maxsize=0):
        self._finished = None
        self.logger = get_logger(self.__class__.__name__)
        super().__init__(maxsize=maxsize)

    def close(self):
        """
        封装私密方法，调用此方法会释放 asyncio.join() 的结果
        """
        self.logger.info(f"当前剩余请求{self.qsize()}。")
        self._finished.set()
