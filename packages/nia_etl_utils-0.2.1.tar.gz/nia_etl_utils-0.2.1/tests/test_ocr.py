"""Testes para o módulo de OCR."""

from unittest.mock import MagicMock, patch

import pytest

from nia_etl_utils.ocr import (
    OcrError,
    OcrProcessamentoError,
    OcrSubmissaoError,
    OcrTimeoutError,
    _detectar_extensao,
    _normalizar_para_bytes,
    _resolver_url_base,
    executar_ocr,
)


class TestDetectarExtensao:
    """Testes para _detectar_extensao."""

    def test_detecta_pdf(self) -> None:
        conteudo = b"%PDF-1.4 conteudo do pdf"
        assert _detectar_extensao(conteudo) == ".pdf"

    def test_detecta_png(self) -> None:
        conteudo = b"\x89PNG\r\n\x1a\n resto da imagem"
        assert _detectar_extensao(conteudo) == ".png"

    def test_detecta_jpg(self) -> None:
        conteudo = b"\xff\xd8\xff dados jpeg"
        assert _detectar_extensao(conteudo) == ".jpg"

    def test_detecta_gif87a(self) -> None:
        conteudo = b"GIF87a dados gif"
        assert _detectar_extensao(conteudo) == ".gif"

    def test_detecta_gif89a(self) -> None:
        conteudo = b"GIF89a dados gif"
        assert _detectar_extensao(conteudo) == ".gif"

    def test_detecta_bmp(self) -> None:
        conteudo = b"BM dados bitmap"
        assert _detectar_extensao(conteudo) == ".bmp"

    def test_detecta_tiff_little_endian(self) -> None:
        conteudo = b"II*\x00 dados tiff"
        assert _detectar_extensao(conteudo) == ".tiff"

    def test_detecta_tiff_big_endian(self) -> None:
        conteudo = b"MM\x00* dados tiff"
        assert _detectar_extensao(conteudo) == ".tiff"

    def test_retorna_bin_para_desconhecido(self) -> None:
        conteudo = b"conteudo qualquer sem magic bytes"
        assert _detectar_extensao(conteudo) == ".bin"

    def test_ignora_espacos_iniciais(self) -> None:
        conteudo = b"   %PDF-1.4 conteudo do pdf"
        assert _detectar_extensao(conteudo) == ".pdf"


class TestNormalizarParaBytes:
    """Testes para _normalizar_para_bytes."""

    def test_bytes_retorna_bytes(self) -> None:
        conteudo = b"dados em bytes"
        assert _normalizar_para_bytes(conteudo) == conteudo

    def test_bytearray_retorna_bytes(self) -> None:
        conteudo = bytearray(b"dados em bytearray")
        resultado = _normalizar_para_bytes(conteudo)
        assert isinstance(resultado, bytes)
        assert resultado == b"dados em bytearray"

    def test_memoryview_retorna_bytes(self) -> None:
        dados = b"dados em memoryview"
        conteudo = memoryview(dados)
        resultado = _normalizar_para_bytes(conteudo)
        assert isinstance(resultado, bytes)
        assert resultado == dados

    def test_objeto_com_read_retorna_bytes(self) -> None:
        mock_lob = MagicMock()
        mock_lob.read.return_value = b"dados do LOB"
        resultado = _normalizar_para_bytes(mock_lob)
        assert resultado == b"dados do LOB"
        mock_lob.read.assert_called_once()

    def test_tipo_invalido_levanta_type_error(self) -> None:
        with pytest.raises(TypeError, match="Tipo de blob não suportado"):
            _normalizar_para_bytes("string invalida")

    def test_tipo_invalido_com_numero(self) -> None:
        with pytest.raises(TypeError, match="Tipo de blob não suportado"):
            _normalizar_para_bytes(12345)


class TestResolverUrlBase:
    """Testes para _resolver_url_base."""

    def test_url_http_retorna_direta(self) -> None:
        url = "http://api.exemplo.com"
        assert _resolver_url_base(url) == url

    def test_url_https_retorna_direta(self) -> None:
        url = "https://api.exemplo.com"
        assert _resolver_url_base(url) == url

    def test_remove_barra_final(self) -> None:
        url = "http://api.exemplo.com/"
        assert _resolver_url_base(url) == "http://api.exemplo.com"

    def test_remove_multiplas_barras_finais(self) -> None:
        url = "http://api.exemplo.com///"
        assert _resolver_url_base(url) == "http://api.exemplo.com"

    @patch("nia_etl_utils.ocr.obter_variavel_env")
    def test_busca_variavel_ambiente(self, mock_env: MagicMock) -> None:
        mock_env.return_value = "http://api.via.env.com"
        resultado = _resolver_url_base("MINHA_VAR")
        mock_env.assert_called_once_with("MINHA_VAR")
        assert resultado == "http://api.via.env.com"

    @patch("nia_etl_utils.ocr.obter_variavel_env")
    def test_busca_variavel_ambiente_remove_barra(self, mock_env: MagicMock) -> None:
        mock_env.return_value = "http://api.via.env.com/"
        resultado = _resolver_url_base("MINHA_VAR")
        assert resultado == "http://api.via.env.com"


class TestExecutarOcr:
    """Testes para executar_ocr."""

    @patch("nia_etl_utils.ocr._aguardar_resultado")
    @patch("nia_etl_utils.ocr._submeter_documento")
    @patch("nia_etl_utils.ocr._resolver_url_base")
    def test_fluxo_completo_sucesso(
        self,
        mock_resolver: MagicMock,
        mock_submeter: MagicMock,
        mock_aguardar: MagicMock,
    ) -> None:
        mock_resolver.return_value = "http://api.teste.com"
        mock_submeter.return_value = "doc-123"
        mock_aguardar.return_value = {
            "document_id": "doc-123",
            "full_text": "texto extraido",
            "overall_quality": 0.95,
        }

        resultado = executar_ocr(b"%PDF-1.4 conteudo", url_base="http://api.teste.com")

        assert resultado["full_text"] == "texto extraido"
        assert resultado["overall_quality"] == 0.95
        mock_submeter.assert_called_once()
        mock_aguardar.assert_called_once()

    @patch("nia_etl_utils.ocr._resolver_url_base")
    def test_normaliza_lob_oracle(self, mock_resolver: MagicMock) -> None:
        mock_resolver.return_value = "http://api.teste.com"
        mock_lob = MagicMock()
        mock_lob.read.return_value = b"%PDF-1.4 conteudo"

        with patch("nia_etl_utils.ocr._submeter_documento") as mock_sub:  # noqa
            with patch("nia_etl_utils.ocr._aguardar_resultado") as mock_aguardar:
                mock_sub.return_value = "doc-123"
                mock_aguardar.return_value = {"full_text": "texto"}

                executar_ocr(mock_lob, url_base="http://api.teste.com")

                mock_lob.read.assert_called_once()
                call_args = mock_sub.call_args
                assert call_args[1]["conteudo"] == b"%PDF-1.4 conteudo"

    @patch("nia_etl_utils.ocr._resolver_url_base")
    @patch("nia_etl_utils.ocr._submeter_documento")
    def test_propaga_erro_submissao(
        self,
        mock_submeter: MagicMock,
        mock_resolver: MagicMock,
    ) -> None:
        mock_resolver.return_value = "http://api.teste.com"
        mock_submeter.side_effect = OcrSubmissaoError("Falha na submissão")

        with pytest.raises(OcrSubmissaoError, match="Falha na submissão"):
            executar_ocr(b"%PDF-1.4 conteudo", url_base="http://api.teste.com")

    @patch("nia_etl_utils.ocr._resolver_url_base")
    @patch("nia_etl_utils.ocr._submeter_documento")
    @patch("nia_etl_utils.ocr._aguardar_resultado")
    def test_propaga_erro_processamento(
        self,
        mock_aguardar: MagicMock,
        mock_submeter: MagicMock,
        mock_resolver: MagicMock,
    ) -> None:
        mock_resolver.return_value = "http://api.teste.com"
        mock_submeter.return_value = "doc-123"
        mock_aguardar.side_effect = OcrProcessamentoError("Documento corrompido")

        with pytest.raises(OcrProcessamentoError, match="Documento corrompido"):
            executar_ocr(b"%PDF-1.4 conteudo", url_base="http://api.teste.com")

    @patch("nia_etl_utils.ocr._resolver_url_base")
    @patch("nia_etl_utils.ocr._submeter_documento")
    @patch("nia_etl_utils.ocr._aguardar_resultado")
    def test_propaga_erro_timeout(
        self,
        mock_aguardar: MagicMock,
        mock_submeter: MagicMock,
        mock_resolver: MagicMock,
    ) -> None:
        mock_resolver.return_value = "http://api.teste.com"
        mock_submeter.return_value = "doc-123"
        mock_aguardar.side_effect = OcrTimeoutError("Timeout após 300s")

        with pytest.raises(OcrTimeoutError, match="Timeout após 300s"):
            executar_ocr(b"%PDF-1.4 conteudo", url_base="http://api.teste.com")


class TestSubmeterDocumento:
    """Testes para _submeter_documento."""

    @patch("nia_etl_utils.ocr.requests.post")
    @patch("nia_etl_utils.ocr.time.sleep")
    def test_sucesso_primeira_tentativa(
        self,
        mock_sleep: MagicMock,
        mock_post: MagicMock,
    ) -> None:
        from nia_etl_utils.ocr import _submeter_documento

        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {
            "documents": [{"document_id": "abc-123"}]
        }
        mock_post.return_value = mock_response

        result = _submeter_documento(
            url_base="http://api.teste.com",
            conteudo=b"conteudo",
            extensao=".pdf",
            max_tentativas=3,
            intervalo_retry=5,
        )

        assert result == "abc-123"
        mock_sleep.assert_not_called()

    @patch("nia_etl_utils.ocr.requests.post")
    @patch("nia_etl_utils.ocr.time.sleep")
    def test_sucesso_terceira_tentativa(
        self,
        mock_sleep: MagicMock,
        mock_post: MagicMock,
    ) -> None:
        from nia_etl_utils.ocr import _submeter_documento

        mock_fail = MagicMock()
        mock_fail.ok = False
        mock_fail.status_code = 503
        mock_fail.json.return_value = {"error": "service unavailable"}

        mock_success = MagicMock()
        mock_success.ok = True
        mock_success.json.return_value = {
            "documents": [{"document_id": "abc-123"}]
        }

        mock_post.side_effect = [mock_fail, mock_fail, mock_success]

        result = _submeter_documento(
            url_base="http://api.teste.com",
            conteudo=b"conteudo",
            extensao=".pdf",
            max_tentativas=3,
            intervalo_retry=5,
        )

        assert result == "abc-123"
        assert mock_sleep.call_count == 2

    @patch("nia_etl_utils.ocr.requests.post")
    @patch("nia_etl_utils.ocr.time.sleep")
    def test_falha_todas_tentativas(
        self,
        mock_sleep: MagicMock,  # noqa
        mock_post: MagicMock,
    ) -> None:
        from nia_etl_utils.ocr import _submeter_documento

        mock_fail = MagicMock()
        mock_fail.ok = False
        mock_fail.status_code = 500
        mock_fail.json.return_value = {"error": "internal error"}
        mock_post.return_value = mock_fail

        with pytest.raises(OcrSubmissaoError, match="falhou após 3 tentativas"):
            _submeter_documento(
                url_base="http://api.teste.com",
                conteudo=b"conteudo",
                extensao=".pdf",
                max_tentativas=3,
                intervalo_retry=5,
            )


class TestAguardarResultado:
    """Testes para _aguardar_resultado."""

    @patch("nia_etl_utils.ocr.requests.get")
    @patch("nia_etl_utils.ocr.time.sleep")
    @patch("nia_etl_utils.ocr.time.time")
    def test_sucesso_imediato(
        self,
        mock_time: MagicMock,
        mock_sleep: MagicMock,  # noqa
        mock_get: MagicMock,
    ) -> None:
        from nia_etl_utils.ocr import _aguardar_resultado

        mock_time.return_value = 0

        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {
            "status": "SUCCESS",
            "result": {"full_text": "texto", "overall_quality": 0.9},
        }
        mock_get.return_value = mock_response

        result = _aguardar_resultado(
            url_base="http://api.teste.com",
            document_id="abc-123",
            timeout_polling=300,
            intervalo_polling=1,
        )

        assert result["full_text"] == "texto"

    @patch("nia_etl_utils.ocr.requests.get")
    @patch("nia_etl_utils.ocr.time.sleep")
    @patch("nia_etl_utils.ocr.time.time")
    def test_falha_api(
        self,
        mock_time: MagicMock,
        mock_sleep: MagicMock,  # noqa
        mock_get: MagicMock,
    ) -> None:
        from nia_etl_utils.ocr import _aguardar_resultado

        mock_time.return_value = 0

        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {
            "status": "FAILURE",
            "error": "documento corrompido",
        }
        mock_get.return_value = mock_response

        with pytest.raises(OcrProcessamentoError, match="documento corrompido"):
            _aguardar_resultado(
                url_base="http://api.teste.com",
                document_id="abc-123",
                timeout_polling=300,
                intervalo_polling=1,
            )

    @patch("nia_etl_utils.ocr.requests.get")
    @patch("nia_etl_utils.ocr.time.sleep")
    @patch("nia_etl_utils.ocr.time.time")
    def test_timeout(
        self,
        mock_time: MagicMock,
        mock_sleep: MagicMock,  # noqa
        mock_get: MagicMock,
    ) -> None:
        from nia_etl_utils.ocr import _aguardar_resultado

        mock_time.side_effect = [0, 100, 200, 301]

        mock_response = MagicMock()
        mock_response.ok = True
        mock_response.json.return_value = {"status": "PENDING"}
        mock_get.return_value = mock_response

        with pytest.raises(OcrTimeoutError, match="Timeout após 300s"):
            _aguardar_resultado(
                url_base="http://api.teste.com",
                document_id="abc-123",
                timeout_polling=300,
                intervalo_polling=1,
            )


class TestExcecoesOcr:
    """Testes para exceções de OCR."""

    def test_ocr_error_herda_nia_etl_error(self) -> None:
        from nia_etl_utils.exceptions import NiaEtlError

        erro = OcrError("teste")
        assert isinstance(erro, NiaEtlError)

    def test_ocr_submissao_error_herda_ocr_error(self) -> None:
        erro = OcrSubmissaoError("teste")
        assert isinstance(erro, OcrError)

    def test_ocr_processamento_error_herda_ocr_error(self) -> None:
        erro = OcrProcessamentoError("teste")
        assert isinstance(erro, OcrError)

    def test_ocr_timeout_error_herda_ocr_error(self) -> None:
        erro = OcrTimeoutError("teste")
        assert isinstance(erro, OcrError)

    def test_erro_com_detalhes(self) -> None:
        erro = OcrSubmissaoError(
            "Falha na submissão",
            details={"tentativas": 3, "status": 500}
        )
        assert erro.details["tentativas"] == 3
        assert "tentativas" in str(erro)
