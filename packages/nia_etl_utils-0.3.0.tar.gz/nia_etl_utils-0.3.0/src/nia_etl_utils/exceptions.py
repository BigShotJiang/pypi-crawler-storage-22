"""Exceções customizadas para o pacote nia_etl_utils.

Este módulo define a hierarquia de exceções usada em todo o pacote,
permitindo tratamento granular de erros pelos consumidores da biblioteca.

Hierarquia:
    NiaEtlError (base)
    ├── ConfiguracaoError
    │   └── VariavelAmbienteError
    ├── DatabaseError
    │   └── ConexaoError
    ├── ArquivoError
    │   ├── EscritaArquivoError
    │   ├── LeituraArquivoError
    │   └── DiretorioError
    ├── ExtracaoError
    │   └── ExtracaoVaziaError
    ├── EmailError
    │   ├── DestinatarioError
    │   └── SmtpError
    ├── OcrError
    │   ├── OcrSubmissaoError
    │   ├── OcrProcessamentoError
    │   └── OcrTimeoutError
    └── ValidacaoError

Examples:
    Capturando erros específicos:

    >>> from nia_etl_utils import ConexaoError, OcrTimeoutError
    >>>
    >>> try:
    ...     resultado = executar_ocr(documento)
    ... except OcrTimeoutError as e:
    ...     logger.error(f"Timeout no OCR: {e}")

    Capturando qualquer erro do pacote:

    >>> from nia_etl_utils import NiaEtlError
    >>>
    >>> try:
    ...     executar_pipeline()
    ... except NiaEtlError as e:
    ...     logger.error(f"Erro no pipeline: {e}")
    ...     sys.exit(1)
"""


class NiaEtlError(Exception):
    """Exceção base para todos os erros do pacote nia_etl_utils.

    Todas as exceções customizadas do pacote herdam desta classe,
    permitindo captura genérica quando necessário.

    Attributes:
        message: Descrição do erro.
        details: Informações adicionais opcionais sobre o erro.

    Examples:
        >>> try:
        ...     raise NiaEtlError("Algo deu errado", details={"codigo": 123})
        ... except NiaEtlError as e:
        ...     print(e.message)
        ...     print(e.details)
        Algo deu errado
        {'codigo': 123}
    """

    def __init__(self, message: str, details: dict | None = None):
        self.message = message
        self.details = details or {}
        super().__init__(self.message)

    def __str__(self) -> str:
        if self.details:
            return f"{self.message} | Detalhes: {self.details}"
        return self.message


# =============================================================================
# CONFIGURAÇÃO
# =============================================================================


class ConfiguracaoError(NiaEtlError):
    """Erro de configuração do sistema."""

    pass


class VariavelAmbienteError(ConfiguracaoError):
    """Variável de ambiente ausente ou inválida."""

    def __init__(self, nome_variavel: str):
        self.nome_variavel = nome_variavel
        super().__init__(
            f"Variável de ambiente '{nome_variavel}' não encontrada "
            f"e nenhum valor padrão foi fornecido",
            details={"variavel": nome_variavel}
        )


# =============================================================================
# DATABASE
# =============================================================================


class DatabaseError(NiaEtlError):
    """Erro base para operações de banco de dados."""

    pass


class ConexaoError(DatabaseError):
    """Falha ao estabelecer conexão com banco de dados."""

    pass


# =============================================================================
# ARQUIVOS E DIRETÓRIOS
# =============================================================================


class ArquivoError(NiaEtlError):
    """Erro base para operações de arquivo e diretório."""

    pass


class EscritaArquivoError(ArquivoError):
    """Falha ao escrever arquivo."""

    pass


class LeituraArquivoError(ArquivoError):
    """Falha ao ler arquivo."""

    pass


class DiretorioError(ArquivoError):
    """Falha em operação de diretório."""

    pass


# =============================================================================
# EXTRAÇÃO E PROCESSAMENTO
# =============================================================================


class ExtracaoError(NiaEtlError):
    """Erro base para operações de extração de dados."""

    pass


class ExtracaoVaziaError(ExtracaoError):
    """Extração retornou DataFrame vazio ou None."""

    def __init__(self, nome_extracao: str):
        self.nome_extracao = nome_extracao
        super().__init__(
            f"Nenhum dado retornado para extração '{nome_extracao}'",
            details={"extracao": nome_extracao}
        )


class ProcessamentoError(ExtracaoError):
    """Erro durante processamento de dados."""

    pass


# =============================================================================
# EMAIL
# =============================================================================


class EmailError(NiaEtlError):
    """Erro base para operações de email."""

    pass


class DestinatarioError(EmailError):
    """Erro relacionado a destinatários de email."""

    pass


class SmtpError(EmailError):
    """Erro de comunicação com servidor SMTP."""

    pass


# =============================================================================
# OCR
# =============================================================================


class OcrError(NiaEtlError):
    """Erro base para operações de OCR."""

    pass


class OcrSubmissaoError(OcrError):
    """Falha ao submeter documento para OCR."""

    pass


class OcrProcessamentoError(OcrError):
    """Falha no processamento do documento pela API."""

    pass


class OcrTimeoutError(OcrError):
    """Timeout aguardando resultado do OCR."""

    pass


# =============================================================================
# VALIDAÇÃO
# =============================================================================


class ValidacaoError(NiaEtlError):
    """Erro de validação de parâmetros ou dados."""

    pass
