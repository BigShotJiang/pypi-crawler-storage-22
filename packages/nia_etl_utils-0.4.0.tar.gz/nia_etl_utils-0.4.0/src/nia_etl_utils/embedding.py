"""Módulo responsável por geração de embeddings via Azure OpenAI.

Este módulo fornece funções para gerar embeddings vetoriais de textos
utilizando a API do Azure OpenAI.

Examples:
    Uso básico:

    >>> from nia_etl_utils import gerar_embedding_openai, obter_variavel_env
    >>>
    >>> vetor = gerar_embedding_openai(
    ...     endpoint=obter_variavel_env("AZURE_OPENAI_ENDPOINT"),
    ...     api_key=obter_variavel_env("AZURE_OPENAI_API_KEY"),
    ...     model_embedding=obter_variavel_env("AZURE_OPENAI_MODEL_EMBEDDING"),
    ...     api_version=obter_variavel_env("AZURE_OPENAI_API_VERSION_EMBEDDING"),
    ...     texto="Este é um texto de exemplo para embedding.",
    ... )
    >>> print(len(vetor))  # dimensão do vetor depende do modelo
    1536

    Com parâmetros de retry customizados:

    >>> vetor = gerar_embedding_openai(
    ...     endpoint=endpoint,
    ...     api_key=api_key,
    ...     model_embedding=model_embedding,
    ...     api_version=api_version,
    ...     texto="Outro texto",
    ...     max_retries=5,
    ...     intervalo_segundos=10,
    ... )

    Tratamento de erros:

    >>> from nia_etl_utils import (
    ...     gerar_embedding_openai,
    ...     EmbeddingTimeoutError,
    ...     EmbeddingError,
    ... )
    >>>
    >>> try:
    ...     vetor = gerar_embedding_openai(
    ...         endpoint=endpoint,
    ...         api_key=api_key,
    ...         model_embedding=model_embedding,
    ...         api_version=api_version,
    ...         texto=texto,
    ...     )
    ... except EmbeddingTimeoutError as e:
    ...     logger.error(f"Timeout após retries: {e}")
    ... except EmbeddingError as e:
    ...     logger.error(f"Erro no embedding: {e}")
"""

import time

from loguru import logger
from openai import APITimeoutError, AzureOpenAI

from .exceptions import EmbeddingError, EmbeddingTimeoutError


def gerar_embedding_openai(
    endpoint: str,
    api_key: str,
    model_embedding: str,
    api_version: str,
    texto: str,
    max_retries: int = 3,
    intervalo_segundos: int = 5,
) -> list[float]:
    """Gera embedding vetorial de um texto utilizando Azure OpenAI.

    Args:
        endpoint: URL do endpoint Azure OpenAI.
        api_key: Chave de API do Azure OpenAI.
        model_embedding: Nome do modelo de embedding.
        api_version: Versão da API do Azure OpenAI.
        texto: Texto de entrada para gerar o embedding.
        max_retries: Número máximo de tentativas em caso de timeout.
        intervalo_segundos: Intervalo em segundos entre tentativas.

    Returns:
        Lista de floats representando o vetor de embedding.

    Raises:
        ValueError: Se o texto ou parâmetros obrigatórios estiverem vazios.
        EmbeddingTimeoutError: Se todas as tentativas falharem por timeout.
        EmbeddingError: Para qualquer outro erro na geração do embedding.

    Examples:
        >>> vetor = gerar_embedding_openai(
        ...     endpoint="https://meu-endpoint.openai.azure.com",
        ...     api_key="minha-api-key",
        ...     model_embedding="text-embedding-3-small",
        ...     api_version="2024-02-01",
        ...     texto="Texto para embedding",
        ... )
        >>> isinstance(vetor, list)
        True
        >>> all(isinstance(x, float) for x in vetor)
        True
    """
    if not endpoint or not endpoint.strip():
        raise ValueError("Parâmetro 'endpoint' é obrigatório.")

    if not api_key or not api_key.strip():
        raise ValueError("Parâmetro 'api_key' é obrigatório.")

    if not model_embedding or not model_embedding.strip():
        raise ValueError("Parâmetro 'model_embedding' é obrigatório.")

    if not api_version or not api_version.strip():
        raise ValueError("Parâmetro 'api_version' é obrigatório.")

    if not texto or not isinstance(texto, str) or not texto.strip():
        raise ValueError("Texto para geração de embedding está vazio ou inválido.")

    client = AzureOpenAI(
        api_key=api_key,
        api_version=api_version,
        azure_endpoint=endpoint,
    )

    tentativa = 0

    while tentativa < max_retries:
        try:
            response = client.embeddings.create(
                model=model_embedding,
                input=texto,
            )

            embedding = response.data[0].embedding

            if not isinstance(embedding, list) or not all(
                isinstance(x, (float, int)) for x in embedding
            ):
                raise EmbeddingError(
                    "Resposta inválida: embedding não é uma lista de números",
                    details={
                        "tipo_resposta": type(embedding).__name__,
                        "model": model_embedding,
                    },
                )

            return embedding

        except APITimeoutError as e:
            tentativa += 1
            logger.warning(
                f"Timeout na tentativa {tentativa}/{max_retries}. "
                f"Aguardando {intervalo_segundos}s antes de retry..."
            )

            if tentativa >= max_retries:
                raise EmbeddingTimeoutError(
                    f"Timeout após {max_retries} tentativas",
                    details={
                        "tentativas": max_retries,
                        "intervalo_segundos": intervalo_segundos,
                        "model": model_embedding,
                        "erro_original": str(e),
                    },
                ) from e

            time.sleep(intervalo_segundos)

        except EmbeddingError:
            raise

        except Exception as e:
            raise EmbeddingError(
                "Erro ao gerar embedding via Azure OpenAI",
                details={
                    "model": model_embedding,
                    "erro": str(e),
                    "tipo_erro": type(e).__name__,
                },
            ) from e

    raise EmbeddingTimeoutError(
        f"Timeout após {max_retries} tentativas",
        details={"tentativas": max_retries, "model": model_embedding},
    )
