"""Testes para o módulo de geração de embeddings."""

from unittest.mock import MagicMock, patch

import pytest

from nia_etl_utils.embedding import gerar_embedding_openai
from nia_etl_utils.exceptions import (
    EmbeddingError,
    EmbeddingTimeoutError,
)

# Constantes para testes
ENDPOINT = "https://test.openai.azure.com"
API_KEY = "test-api-key"
MODEL = "text-embedding-ada-002"
API_VERSION = "2023-05-15"


# ============================================================
# Testes de validação de entrada
# ============================================================
def test_texto_vazio_levanta_value_error():
    """Testa que texto vazio levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="",
        )

    assert "vazio ou inválido" in str(exc.value)


def test_texto_none_levanta_value_error():
    """Testa que texto None levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto=None, # type: ignore
        )

    assert "vazio ou inválido" in str(exc.value)


def test_texto_somente_espacos_levanta_value_error():
    """Testa que texto com apenas espaços levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="   \t\n  ",
        )

    assert "vazio ou inválido" in str(exc.value)


def test_texto_nao_string_levanta_value_error():
    """Testa que texto não-string levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto=12345, # type: ignore
        )

    assert "vazio ou inválido" in str(exc.value)


def test_endpoint_vazio_levanta_value_error():
    """Testa que endpoint vazio levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint="",
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="texto válido",
        )

    assert "endpoint" in str(exc.value)


def test_api_key_vazia_levanta_value_error():
    """Testa que api_key vazia levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key="",
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="texto válido",
        )

    assert "api_key" in str(exc.value)


def test_model_embedding_vazio_levanta_value_error():
    """Testa que model_embedding vazio levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding="",
            api_version=API_VERSION,
            texto="texto válido",
        )

    assert "model_embedding" in str(exc.value)


def test_api_version_vazia_levanta_value_error():
    """Testa que api_version vazia levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version="",
            texto="texto válido",
        )

    assert "api_version" in str(exc.value)


def test_endpoint_somente_espacos_levanta_value_error():
    """Testa que endpoint com apenas espaços levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint="   ",
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="texto válido",
        )

    assert "endpoint" in str(exc.value)


# ============================================================
# Testes de sucesso
# ============================================================
@patch("nia_etl_utils.embedding.AzureOpenAI")
def test_gerar_embedding_sucesso(mock_azure_client):
    """Testa geração de embedding bem-sucedida."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [0.1, 0.2, 0.3, 0.4, 0.5]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_azure_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        texto="Texto para embedding",
    )

    assert resultado == [0.1, 0.2, 0.3, 0.4, 0.5]
    mock_client_instance.embeddings.create.assert_called_once_with(
        model=MODEL,
        input="Texto para embedding",
    )


@patch("nia_etl_utils.embedding.AzureOpenAI")
def test_gerar_embedding_retorna_lista_floats(mock_azure_client):
    """Testa que o retorno é uma lista de floats."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [0.1, 0.2, 0.3]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_azure_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        texto="texto",
    )

    assert isinstance(resultado, list)
    assert all(isinstance(x, (float, int)) for x in resultado)


@patch("nia_etl_utils.embedding.AzureOpenAI")
def test_gerar_embedding_aceita_inteiros_na_resposta(mock_azure_client):
    """Testa que aceita inteiros na resposta."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [1, 2, 3]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_azure_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        texto="texto",
    )

    assert resultado == [1, 2, 3]


# ============================================================
# Testes de timeout e retry
# ============================================================
@patch("nia_etl_utils.embedding.time.sleep")
@patch("nia_etl_utils.embedding.AzureOpenAI")
@patch("nia_etl_utils.embedding.logger")
def test_timeout_com_retry_sucesso(mock_logger, mock_azure_client, mock_sleep):
    """Testa retry bem-sucedido após timeout inicial."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [0.1, 0.2]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    from openai import APITimeoutError

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.side_effect = [
        APITimeoutError(request=MagicMock()),
        mock_response,
    ]
    mock_azure_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        texto="texto",
        max_retries=3,
        intervalo_segundos=2,
    )

    assert resultado == [0.1, 0.2]
    mock_sleep.assert_called_once_with(2)
    mock_logger.warning.assert_called_once()
    assert "Timeout" in str(mock_logger.warning.call_args)


@patch("nia_etl_utils.embedding.time.sleep")
@patch("nia_etl_utils.embedding.AzureOpenAI")
def test_timeout_esgota_retries(mock_azure_client, mock_sleep):
    """Testa que esgota retries e levanta EmbeddingTimeoutError."""
    from openai import APITimeoutError

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.side_effect = APITimeoutError(request=MagicMock())
    mock_azure_client.return_value = mock_client_instance

    with pytest.raises(EmbeddingTimeoutError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="texto",
            max_retries=3,
            intervalo_segundos=1,
        )

    assert "Timeout após 3 tentativas" in str(exc.value)
    assert exc.value.details["tentativas"] == 3
    assert mock_sleep.call_count == 2


@patch("nia_etl_utils.embedding.time.sleep")
@patch("nia_etl_utils.embedding.AzureOpenAI")
def test_timeout_respeita_max_retries_customizado(mock_azure_client, mock_sleep):
    """Testa que respeita max_retries customizado."""
    from openai import APITimeoutError

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.side_effect = APITimeoutError(request=MagicMock())
    mock_azure_client.return_value = mock_client_instance

    with pytest.raises(EmbeddingTimeoutError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="texto",
            max_retries=5,
        )

    assert exc.value.details["tentativas"] == 5
    assert mock_client_instance.embeddings.create.call_count == 5


# ============================================================
# Testes de erros
# ============================================================
@patch("nia_etl_utils.embedding.AzureOpenAI")
def test_resposta_invalida_levanta_embedding_error(mock_azure_client):
    """Testa que resposta inválida levanta EmbeddingError."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = "não é lista"

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_azure_client.return_value = mock_client_instance

    with pytest.raises(EmbeddingError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="texto",
        )

    assert "Resposta inválida" in str(exc.value)
    assert "não é uma lista de números" in str(exc.value)


@patch("nia_etl_utils.embedding.AzureOpenAI")
def test_resposta_com_valores_nao_numericos_levanta_erro(mock_azure_client):
    """Testa que lista com valores não numéricos levanta EmbeddingError."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [0.1, "texto", 0.3]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_azure_client.return_value = mock_client_instance

    with pytest.raises(EmbeddingError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="texto",
        )

    assert "Resposta inválida" in str(exc.value)


@patch("nia_etl_utils.embedding.AzureOpenAI")
def test_erro_generico_levanta_embedding_error(mock_azure_client):
    """Testa que erro genérico levanta EmbeddingError."""
    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.side_effect = RuntimeError("erro inesperado")
    mock_azure_client.return_value = mock_client_instance

    with pytest.raises(EmbeddingError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="texto",
        )

    assert "Erro ao gerar embedding" in str(exc.value)
    assert exc.value.details["erro"] == "erro inesperado"
    assert exc.value.details["tipo_erro"] == "RuntimeError"


# ============================================================
# Testes de configuração do cliente
# ============================================================
@patch("nia_etl_utils.embedding.AzureOpenAI")
def test_cliente_configurado_corretamente(mock_azure_client):
    """Testa que cliente Azure é configurado com parâmetros corretos."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [0.1]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_azure_client.return_value = mock_client_instance

    gerar_embedding_openai(
        endpoint="https://meu-endpoint.openai.azure.com",
        api_key="minha-chave-secreta",
        model_embedding="text-embedding-3-large",
        api_version="2024-02-01",
        texto="texto",
    )

    mock_azure_client.assert_called_once_with(
        api_key="minha-chave-secreta",
        api_version="2024-02-01",
        azure_endpoint="https://meu-endpoint.openai.azure.com",
    )


# ============================================================
# Testes de logs
# ============================================================
@patch("nia_etl_utils.embedding.time.sleep")
@patch("nia_etl_utils.embedding.AzureOpenAI")
@patch("nia_etl_utils.embedding.logger")
def test_log_warning_em_timeout(mock_logger, mock_azure_client, mock_sleep):
    """Testa que warning é logado em timeout."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [0.1]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    from openai import APITimeoutError

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.side_effect = [
        APITimeoutError(request=MagicMock()),
        mock_response,
    ]
    mock_azure_client.return_value = mock_client_instance

    gerar_embedding_openai(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        texto="texto",
        intervalo_segundos=7,
    )

    mock_logger.warning.assert_called_once()
    warning_msg = str(mock_logger.warning.call_args)
    assert "Timeout" in warning_msg
    assert "7s" in warning_msg


# ============================================================
# Testes de dimensionalidade
# ============================================================
@patch("nia_etl_utils.embedding.AzureOpenAI")
def test_embedding_com_dimensao_1536(mock_azure_client):
    """Testa embedding com dimensão típica (1536 para ada-002)."""
    embedding_1536 = [0.001 * i for i in range(1536)]

    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = embedding_1536

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_azure_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        texto="texto",
    )

    assert len(resultado) == 1536
