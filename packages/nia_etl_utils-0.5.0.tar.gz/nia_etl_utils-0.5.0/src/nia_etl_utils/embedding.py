"""Módulo responsável por geração de embeddings via Azure OpenAI.

Este módulo fornece funções para gerar embeddings vetoriais de textos
utilizando a API do Azure OpenAI.

Examples:
    Uso básico (texto único):

    >>> from nia_etl_utils import gerar_embedding_openai, obter_variavel_env
    >>>
    >>> vetor = gerar_embedding_openai(
    ...     endpoint=obter_variavel_env("AZURE_OPENAI_ENDPOINT"),
    ...     api_key=obter_variavel_env("AZURE_OPENAI_API_KEY"),
    ...     model_embedding=obter_variavel_env("AZURE_OPENAI_MODEL_EMBEDDING"),
    ...     api_version=obter_variavel_env("AZURE_OPENAI_API_VERSION_EMBEDDING"),
    ...     texto="Este é um texto de exemplo para embedding.",
    ... )
    >>> print(len(vetor))  # dimensão do vetor depende do modelo
    1536

    Uso em batch (múltiplos textos):

    >>> from nia_etl_utils import gerar_embedding_openai_batch, obter_variavel_env
    >>>
    >>> textos = ["Primeiro texto", "Segundo texto", "Terceiro texto"]
    >>> vetores = gerar_embedding_openai_batch(
    ...     endpoint=obter_variavel_env("AZURE_OPENAI_ENDPOINT"),
    ...     api_key=obter_variavel_env("AZURE_OPENAI_API_KEY"),
    ...     model_embedding=obter_variavel_env("AZURE_OPENAI_MODEL_EMBEDDING"),
    ...     api_version=obter_variavel_env("AZURE_OPENAI_API_VERSION_EMBEDDING"),
    ...     textos=textos,
    ... )
    >>> print(len(vetores))  # 3 vetores
    3

    Desabilitando truncamento automático:

    >>> vetor = gerar_embedding_openai(
    ...     endpoint=endpoint,
    ...     api_key=api_key,
    ...     model_embedding=model_embedding,
    ...     api_version=api_version,
    ...     texto="Texto muito longo...",
    ...     max_tokens=None,  # Desabilita truncamento, API pode retornar erro
    ... )

    Tratamento de erros:

    >>> from nia_etl_utils import (
    ...     gerar_embedding_openai,
    ...     EmbeddingTimeoutError,
    ...     EmbeddingError,
    ... )
    >>>
    >>> try:
    ...     vetor = gerar_embedding_openai(
    ...         endpoint=endpoint,
    ...         api_key=api_key,
    ...         model_embedding=model_embedding,
    ...         api_version=api_version,
    ...         texto=texto,
    ...     )
    ... except EmbeddingTimeoutError as e:
    ...     logger.error(f"Timeout após retries: {e}")
    ... except EmbeddingError as e:
    ...     logger.error(f"Erro no embedding: {e}")
"""

import time

import tiktoken
from loguru import logger
from openai import APITimeoutError, AzureOpenAI

from .exceptions import EmbeddingError, EmbeddingTimeoutError

_DEFAULT_MAX_TOKENS = 8191


def _validar_parametros_conexao(
    endpoint: str,
    api_key: str,
    model_embedding: str,
    api_version: str,
) -> None:
    """Valida parâmetros de conexão com Azure OpenAI.

    Args:
        endpoint: URL do endpoint Azure OpenAI.
        api_key: Chave de API do Azure OpenAI.
        model_embedding: Nome do modelo de embedding.
        api_version: Versão da API do Azure OpenAI.

    Raises:
        ValueError: Se algum parâmetro obrigatório estiver vazio.
    """
    if not endpoint or not endpoint.strip():
        raise ValueError("Parâmetro 'endpoint' é obrigatório.")

    if not api_key or not api_key.strip():
        raise ValueError("Parâmetro 'api_key' é obrigatório.")

    if not model_embedding or not model_embedding.strip():
        raise ValueError("Parâmetro 'model_embedding' é obrigatório.")

    if not api_version or not api_version.strip():
        raise ValueError("Parâmetro 'api_version' é obrigatório.")


def _criar_client(endpoint: str, api_key: str, api_version: str) -> AzureOpenAI:
    """Cria cliente Azure OpenAI.

    Args:
        endpoint: URL do endpoint Azure OpenAI.
        api_key: Chave de API do Azure OpenAI.
        api_version: Versão da API do Azure OpenAI.

    Returns:
        Cliente AzureOpenAI configurado.
    """
    return AzureOpenAI(
        api_key=api_key,
        api_version=api_version,
        azure_endpoint=endpoint,
    )


def _truncar_texto_por_tokens(
    texto: str,
    max_tokens: int,
    model_embedding: str,
) -> tuple[str, int, bool]:
    """Trunca texto para respeitar limite de tokens do modelo.

    Args:
        texto: Texto original.
        max_tokens: Número máximo de tokens permitido.
        model_embedding: Nome do modelo para encoding correto.

    Returns:
        Tupla com (texto_processado, tokens_originais, foi_truncado).
    """
    try:
        enc = tiktoken.encoding_for_model(model_embedding)
    except KeyError:
        # Fallback para encoding padrão se modelo não reconhecido
        enc = tiktoken.get_encoding("cl100k_base")

    tokens = enc.encode(texto)
    tokens_originais = len(tokens)

    if tokens_originais <= max_tokens:
        return texto, tokens_originais, False

    tokens_truncados = tokens[:max_tokens]
    texto_truncado = enc.decode(tokens_truncados)

    return texto_truncado, tokens_originais, True


def gerar_embedding_openai(
    endpoint: str,
    api_key: str,
    model_embedding: str,
    api_version: str,
    texto: str,
    max_retries: int = 3,
    intervalo_segundos: int = 5,
    max_tokens: int | None = _DEFAULT_MAX_TOKENS,
) -> list[float]:
    """Gera embedding vetorial de um texto utilizando Azure OpenAI.

    Args:
        endpoint: URL do endpoint Azure OpenAI.
        api_key: Chave de API do Azure OpenAI.
        model_embedding: Nome do modelo de embedding.
        api_version: Versão da API do Azure OpenAI.
        texto: Texto de entrada para gerar o embedding.
        max_retries: Número máximo de tentativas em caso de timeout.
        intervalo_segundos: Intervalo em segundos entre tentativas.
        max_tokens: Limite máximo de tokens. Textos maiores serão truncados.
            Use None para desabilitar truncamento (API pode retornar erro).
            Padrão: 8191 (limite do text-embedding-3-small).

    Returns:
        Lista de floats representando o vetor de embedding.

    Raises:
        ValueError: Se o texto ou parâmetros obrigatórios estiverem vazios.
        EmbeddingTimeoutError: Se todas as tentativas falharem por timeout.
        EmbeddingError: Para qualquer outro erro na geração do embedding.

    Examples:
        >>> vetor = gerar_embedding_openai(
        ...     endpoint="https://meu-endpoint.openai.azure.com",
        ...     api_key="minha-api-key",
        ...     model_embedding="text-embedding-3-small",
        ...     api_version="2024-02-01",
        ...     texto="Texto para embedding",
        ... )
        >>> isinstance(vetor, list)
        True
        >>> all(isinstance(x, float) for x in vetor)
        True
    """
    _validar_parametros_conexao(endpoint, api_key, model_embedding, api_version)

    if not texto or not isinstance(texto, str) or not texto.strip():
        raise ValueError("Texto para geração de embedding está vazio ou inválido.")

    # Truncamento de tokens se habilitado
    texto_processado = texto
    if max_tokens is not None:
        texto_processado, tokens_originais, foi_truncado = _truncar_texto_por_tokens(
            texto, max_tokens, model_embedding
        )
        if foi_truncado:
            logger.info(
                f"Texto truncado de {tokens_originais} para {max_tokens} tokens "
                f"(modelo: {model_embedding})"
            )

    client = _criar_client(endpoint, api_key, api_version)

    tentativa = 0

    while tentativa < max_retries:
        try:
            response = client.embeddings.create(
                model=model_embedding,
                input=texto_processado,
            )

            embedding = response.data[0].embedding

            if not isinstance(embedding, list) or not all(
                isinstance(x, (float, int)) for x in embedding
            ):
                raise EmbeddingError(
                    "Resposta inválida: embedding não é uma lista de números",
                    details={
                        "tipo_resposta": type(embedding).__name__,
                        "model": model_embedding,
                    },
                )

            return embedding

        except APITimeoutError as e:
            tentativa += 1
            logger.warning(
                f"Timeout na tentativa {tentativa}/{max_retries}. "
                f"Aguardando {intervalo_segundos}s antes de retry..."
            )

            if tentativa >= max_retries:
                raise EmbeddingTimeoutError(
                    f"Timeout após {max_retries} tentativas",
                    details={
                        "tentativas": max_retries,
                        "intervalo_segundos": intervalo_segundos,
                        "model": model_embedding,
                        "erro_original": str(e),
                    },
                ) from e

            time.sleep(intervalo_segundos)

        except EmbeddingError:
            raise

        except Exception as e:
            raise EmbeddingError(
                "Erro ao gerar embedding via Azure OpenAI",
                details={
                    "model": model_embedding,
                    "erro": str(e),
                    "tipo_erro": type(e).__name__,
                },
            ) from e

    raise EmbeddingTimeoutError(
        f"Timeout após {max_retries} tentativas",
        details={"tentativas": max_retries, "model": model_embedding},
    )


def gerar_embedding_openai_batch(
    endpoint: str,
    api_key: str,
    model_embedding: str,
    api_version: str,
    textos: list[str],
    max_retries: int = 3,
    intervalo_segundos: int = 5,
    max_tokens: int | None = _DEFAULT_MAX_TOKENS,
) -> list[list[float]]:
    """Gera embeddings vetoriais para múltiplos textos em uma única chamada.

    Mais eficiente que chamar gerar_embedding_openai múltiplas vezes,
    pois envia todos os textos em uma única requisição à API.

    Args:
        endpoint: URL do endpoint Azure OpenAI.
        api_key: Chave de API do Azure OpenAI.
        model_embedding: Nome do modelo de embedding.
        api_version: Versão da API do Azure OpenAI.
        textos: Lista de textos para gerar embeddings.
        max_retries: Número máximo de tentativas em caso de timeout.
        intervalo_segundos: Intervalo em segundos entre tentativas.
        max_tokens: Limite máximo de tokens por texto. Textos maiores serão
            truncados individualmente. Use None para desabilitar truncamento.
            Padrão: 8191 (limite do text-embedding-3-small).

    Returns:
        Lista de vetores de embedding, na mesma ordem dos textos de entrada.
        Textos vazios retornam lista vazia [].

    Raises:
        ValueError: Se parâmetros obrigatórios estiverem vazios.
        EmbeddingTimeoutError: Se todas as tentativas falharem por timeout.
        EmbeddingError: Para qualquer outro erro na geração dos embeddings.

    Examples:
        >>> textos = ["Primeiro texto", "Segundo texto", "Terceiro texto"]
        >>> vetores = gerar_embedding_openai_batch(
        ...     endpoint="https://meu-endpoint.openai.azure.com",
        ...     api_key="minha-api-key",
        ...     model_embedding="text-embedding-3-small",
        ...     api_version="2024-02-01",
        ...     textos=textos,
        ... )
        >>> len(vetores)
        3
        >>> all(isinstance(v, list) for v in vetores)
        True
    """
    _validar_parametros_conexao(endpoint, api_key, model_embedding, api_version)

    if isinstance(textos, str):
        raise ValueError(
            "Parâmetro 'textos' deve ser uma lista de strings, não uma string única. "
            "Use gerar_embedding_openai para texto único."
        )

    if not textos:
        return []

    # Prepara textos: substitui vazios por espaço (API não aceita string vazia)
    # Guarda índices dos textos vazios para retornar lista vazia depois
    textos_processados = []
    indices_vazios = set()
    textos_truncados_count = 0

    for i, texto in enumerate(textos):
        texto_limpo = texto.strip() if texto else ""
        if not texto_limpo:
            indices_vazios.add(i)
            textos_processados.append(" ")  # placeholder para manter ordem
        else:
            # Truncamento de tokens se habilitado
            if max_tokens is not None:
                texto_processado, tokens_originais, foi_truncado = (
                    _truncar_texto_por_tokens(texto_limpo, max_tokens, model_embedding)
                )
                if foi_truncado:
                    textos_truncados_count += 1
                textos_processados.append(texto_processado)
            else:
                textos_processados.append(texto_limpo)

    if textos_truncados_count > 0:
        logger.info(
            f"{textos_truncados_count} texto(s) truncado(s) para {max_tokens} tokens "
            f"(modelo: {model_embedding})"
        )

    client = _criar_client(endpoint, api_key, api_version)

    tentativa = 0

    while tentativa < max_retries:
        try:
            logger.info(f"Gerando embeddings para {len(textos_processados)} textos...")

            response = client.embeddings.create(
                model=model_embedding,
                input=textos_processados,
            )

            # Extrai embeddings mantendo a ordem
            embeddings: list[list[float]] = []
            for i, emb_data in enumerate(response.data):
                if i in indices_vazios:
                    embeddings.append([])  # texto vazio retorna lista vazia
                else:
                    embeddings.append(emb_data.embedding)

            logger.info(f"Embeddings gerados com sucesso: {len(embeddings)} vetores")
            return embeddings

        except APITimeoutError as e:
            tentativa += 1
            logger.warning(
                f"Timeout na tentativa {tentativa}/{max_retries}. "
                f"Aguardando {intervalo_segundos}s antes de retry..."
            )

            if tentativa >= max_retries:
                raise EmbeddingTimeoutError(
                    f"Timeout após {max_retries} tentativas",
                    details={
                        "tentativas": max_retries,
                        "intervalo_segundos": intervalo_segundos,
                        "model": model_embedding,
                        "quantidade_textos": len(textos),
                        "erro_original": str(e),
                    },
                ) from e

            time.sleep(intervalo_segundos)

        except EmbeddingError:
            raise

        except Exception as e:
            raise EmbeddingError(
                "Erro ao gerar embeddings via Azure OpenAI",
                details={
                    "model": model_embedding,
                    "quantidade_textos": len(textos),
                    "erro": str(e),
                    "tipo_erro": type(e).__name__,
                },
            ) from e

    raise EmbeddingTimeoutError(
        f"Timeout após {max_retries} tentativas",
        details={
            "tentativas": max_retries,
            "model": model_embedding,
            "quantidade_textos": len(textos),
        },
    )
