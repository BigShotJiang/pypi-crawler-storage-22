"""Testes para o módulo de geração de embeddings."""

from unittest.mock import MagicMock, patch

import pytest

from nia_etl_utils.embedding import _truncar_texto_por_tokens, gerar_embedding_openai, gerar_embedding_openai_batch
from nia_etl_utils.exceptions import (
    EmbeddingError,
    EmbeddingTimeoutError,
)

# Constantes para testes
ENDPOINT = "https://test.openai.azure.com"
API_KEY = "test-api-key"
MODEL = "text-embedding-ada-002"
API_VERSION = "2023-05-15"


# ============================================================
# Testes de validação de entrada - gerar_embedding_openai
# ============================================================
def test_texto_vazio_levanta_value_error():
    """Testa que texto vazio levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="",
        )

    assert "vazio ou inválido" in str(exc.value)


def test_texto_none_levanta_value_error():
    """Testa que texto None levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto=None,  # type: ignore
        )

    assert "vazio ou inválido" in str(exc.value)


def test_texto_somente_espacos_levanta_value_error():
    """Testa que texto com apenas espaços levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="   \t\n  ",
        )

    assert "vazio ou inválido" in str(exc.value)


def test_texto_nao_string_levanta_value_error():
    """Testa que texto não-string levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto=12345,  # type: ignore
        )

    assert "vazio ou inválido" in str(exc.value)


def test_endpoint_vazio_levanta_value_error():
    """Testa que endpoint vazio levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint="",
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="texto válido",
        )

    assert "endpoint" in str(exc.value)


def test_api_key_vazia_levanta_value_error():
    """Testa que api_key vazia levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key="",
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="texto válido",
        )

    assert "api_key" in str(exc.value)


def test_model_embedding_vazio_levanta_value_error():
    """Testa que model_embedding vazio levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding="",
            api_version=API_VERSION,
            texto="texto válido",
        )

    assert "model_embedding" in str(exc.value)


def test_api_version_vazia_levanta_value_error():
    """Testa que api_version vazia levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version="",
            texto="texto válido",
        )

    assert "api_version" in str(exc.value)


def test_endpoint_somente_espacos_levanta_value_error():
    """Testa que endpoint com apenas espaços levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai(
            endpoint="   ",
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="texto válido",
        )

    assert "endpoint" in str(exc.value)


# ============================================================
# Testes de sucesso - gerar_embedding_openai
# ============================================================
@patch("nia_etl_utils.embedding._criar_client")
def test_gerar_embedding_sucesso(mock_criar_client):
    """Testa geração de embedding bem-sucedida."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [0.1, 0.2, 0.3, 0.4, 0.5]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        texto="Texto para embedding",
    )

    assert resultado == [0.1, 0.2, 0.3, 0.4, 0.5]
    mock_client_instance.embeddings.create.assert_called_once_with(
        model=MODEL,
        input="Texto para embedding",
    )


@patch("nia_etl_utils.embedding._criar_client")
def test_gerar_embedding_retorna_lista_floats(mock_criar_client):
    """Testa que o retorno é uma lista de floats."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [0.1, 0.2, 0.3]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        texto="texto",
    )

    assert isinstance(resultado, list)
    assert all(isinstance(x, (float, int)) for x in resultado)


@patch("nia_etl_utils.embedding._criar_client")
def test_gerar_embedding_aceita_inteiros_na_resposta(mock_criar_client):
    """Testa que aceita inteiros na resposta."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [1, 2, 3]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        texto="texto",
    )

    assert resultado == [1, 2, 3]


# ============================================================
# Testes de timeout e retry - gerar_embedding_openai
# ============================================================
@patch("nia_etl_utils.embedding.time.sleep")
@patch("nia_etl_utils.embedding._criar_client")
@patch("nia_etl_utils.embedding.logger")
def test_timeout_com_retry_sucesso(mock_logger, mock_criar_client, mock_sleep):
    """Testa retry bem-sucedido após timeout inicial."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [0.1, 0.2]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    from openai import APITimeoutError

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.side_effect = [
        APITimeoutError(request=MagicMock()),
        mock_response,
    ]
    mock_criar_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        texto="texto",
        max_retries=3,
        intervalo_segundos=2,
    )

    assert resultado == [0.1, 0.2]
    mock_sleep.assert_called_once_with(2)
    mock_logger.warning.assert_called_once()
    assert "Timeout" in str(mock_logger.warning.call_args)


@patch("nia_etl_utils.embedding.time.sleep")
@patch("nia_etl_utils.embedding._criar_client")
def test_timeout_esgota_retries(mock_criar_client, mock_sleep):
    """Testa que esgota retries e levanta EmbeddingTimeoutError."""
    from openai import APITimeoutError

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.side_effect = APITimeoutError(request=MagicMock())
    mock_criar_client.return_value = mock_client_instance

    with pytest.raises(EmbeddingTimeoutError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="texto",
            max_retries=3,
            intervalo_segundos=1,
        )

    assert "Timeout após 3 tentativas" in str(exc.value)
    assert exc.value.details["tentativas"] == 3
    assert mock_sleep.call_count == 2


@patch("nia_etl_utils.embedding.time.sleep")
@patch("nia_etl_utils.embedding._criar_client")
def test_timeout_respeita_max_retries_customizado(mock_criar_client, mock_sleep):
    """Testa que respeita max_retries customizado."""
    from openai import APITimeoutError

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.side_effect = APITimeoutError(request=MagicMock())
    mock_criar_client.return_value = mock_client_instance

    with pytest.raises(EmbeddingTimeoutError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="texto",
            max_retries=5,
        )

    assert exc.value.details["tentativas"] == 5
    assert mock_client_instance.embeddings.create.call_count == 5


# ============================================================
# Testes de erros - gerar_embedding_openai
# ============================================================
@patch("nia_etl_utils.embedding._criar_client")
def test_resposta_invalida_levanta_embedding_error(mock_criar_client):
    """Testa que resposta inválida levanta EmbeddingError."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = "não é lista"

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    with pytest.raises(EmbeddingError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="texto",
        )

    assert "Resposta inválida" in str(exc.value)
    assert "não é uma lista de números" in str(exc.value)


@patch("nia_etl_utils.embedding._criar_client")
def test_resposta_com_valores_nao_numericos_levanta_erro(mock_criar_client):
    """Testa que lista com valores não numéricos levanta EmbeddingError."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [0.1, "texto", 0.3]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    with pytest.raises(EmbeddingError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="texto",
        )

    assert "Resposta inválida" in str(exc.value)


@patch("nia_etl_utils.embedding._criar_client")
def test_erro_generico_levanta_embedding_error(mock_criar_client):
    """Testa que erro genérico levanta EmbeddingError."""
    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.side_effect = RuntimeError("erro inesperado")
    mock_criar_client.return_value = mock_client_instance

    with pytest.raises(EmbeddingError) as exc:
        gerar_embedding_openai(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            texto="texto",
        )

    assert "Erro ao gerar embedding" in str(exc.value)
    assert exc.value.details["erro"] == "erro inesperado"
    assert exc.value.details["tipo_erro"] == "RuntimeError"


# ============================================================
# Testes de configuração do cliente
# ============================================================
@patch("nia_etl_utils.embedding.AzureOpenAI")
def test_cliente_configurado_corretamente(mock_azure_client):
    """Testa que cliente Azure é configurado com parâmetros corretos."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [0.1]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_azure_client.return_value = mock_client_instance

    gerar_embedding_openai(
        endpoint="https://meu-endpoint.openai.azure.com",
        api_key="minha-chave-secreta",
        model_embedding="text-embedding-3-large",
        api_version="2024-02-01",
        texto="texto",
    )

    mock_azure_client.assert_called_once_with(
        api_key="minha-chave-secreta",
        api_version="2024-02-01",
        azure_endpoint="https://meu-endpoint.openai.azure.com",
    )


# ============================================================
# Testes de logs - gerar_embedding_openai
# ============================================================
@patch("nia_etl_utils.embedding.time.sleep")
@patch("nia_etl_utils.embedding._criar_client")
@patch("nia_etl_utils.embedding.logger")
def test_log_warning_em_timeout(mock_logger, mock_criar_client, mock_sleep):
    """Testa que warning é logado em timeout."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [0.1]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    from openai import APITimeoutError

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.side_effect = [
        APITimeoutError(request=MagicMock()),
        mock_response,
    ]
    mock_criar_client.return_value = mock_client_instance

    gerar_embedding_openai(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        texto="texto",
        intervalo_segundos=7,
    )

    mock_logger.warning.assert_called_once()
    warning_msg = str(mock_logger.warning.call_args)
    assert "Timeout" in warning_msg
    assert "7s" in warning_msg


# ============================================================
# Testes de dimensionalidade
# ============================================================
@patch("nia_etl_utils.embedding._criar_client")
def test_embedding_com_dimensao_1536(mock_criar_client):
    """Testa embedding com dimensão típica (1536 para ada-002)."""
    embedding_1536 = [0.001 * i for i in range(1536)]

    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = embedding_1536

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        texto="texto",
    )

    assert len(resultado) == 1536


# ============================================================
# Testes de validação de entrada - gerar_embedding_openai_batch
# ============================================================
def test_batch_textos_string_unica_levanta_value_error():
    """Testa que passar string única em vez de lista levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai_batch(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            textos="texto único",  # type: ignore
        )

    assert "lista de strings" in str(exc.value)
    assert "gerar_embedding_openai" in str(exc.value)


def test_batch_lista_vazia_retorna_lista_vazia():
    """Testa que lista vazia retorna lista vazia sem chamar API."""
    resultado = gerar_embedding_openai_batch(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        textos=[],
    )

    assert resultado == []


def test_batch_endpoint_vazio_levanta_value_error():
    """Testa que endpoint vazio levanta ValueError."""
    with pytest.raises(ValueError) as exc:
        gerar_embedding_openai_batch(
            endpoint="",
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            textos=["texto"],
        )

    assert "endpoint" in str(exc.value)


# ============================================================
# Testes de sucesso - gerar_embedding_openai_batch
# ============================================================
@patch("nia_etl_utils.embedding._criar_client")
@patch("nia_etl_utils.embedding.logger")
def test_batch_sucesso_multiplos_textos(mock_logger, mock_criar_client):
    """Testa geração de embeddings em batch com múltiplos textos."""
    mock_emb1 = MagicMock()
    mock_emb1.embedding = [0.1, 0.2]
    mock_emb2 = MagicMock()
    mock_emb2.embedding = [0.3, 0.4]
    mock_emb3 = MagicMock()
    mock_emb3.embedding = [0.5, 0.6]

    mock_response = MagicMock()
    mock_response.data = [mock_emb1, mock_emb2, mock_emb3]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai_batch(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        textos=["texto1", "texto2", "texto3"],
    )

    assert len(resultado) == 3
    assert resultado[0] == [0.1, 0.2]
    assert resultado[1] == [0.3, 0.4]
    assert resultado[2] == [0.5, 0.6]

    mock_client_instance.embeddings.create.assert_called_once_with(
        model=MODEL,
        input=["texto1", "texto2", "texto3"],
    )


@patch("nia_etl_utils.embedding._criar_client")
@patch("nia_etl_utils.embedding.logger")
def test_batch_texto_unico_na_lista(mock_logger, mock_criar_client):
    """Testa batch com apenas um texto na lista."""
    mock_emb = MagicMock()
    mock_emb.embedding = [0.1, 0.2, 0.3]

    mock_response = MagicMock()
    mock_response.data = [mock_emb]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai_batch(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        textos=["único texto"],
    )

    assert len(resultado) == 1
    assert resultado[0] == [0.1, 0.2, 0.3]


@patch("nia_etl_utils.embedding._criar_client")
@patch("nia_etl_utils.embedding.logger")
def test_batch_textos_vazios_retornam_lista_vazia(mock_logger, mock_criar_client):
    """Testa que textos vazios na lista retornam lista vazia no resultado."""
    mock_emb1 = MagicMock()
    mock_emb1.embedding = [0.1, 0.2]
    mock_emb2 = MagicMock()
    mock_emb2.embedding = [0.9, 0.9]  # placeholder para texto vazio
    mock_emb3 = MagicMock()
    mock_emb3.embedding = [0.3, 0.4]

    mock_response = MagicMock()
    mock_response.data = [mock_emb1, mock_emb2, mock_emb3]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai_batch(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        textos=["texto1", "", "texto3"],  # texto vazio no meio
    )

    assert len(resultado) == 3
    assert resultado[0] == [0.1, 0.2]
    assert resultado[1] == []  # texto vazio retorna lista vazia
    assert resultado[2] == [0.3, 0.4]


@patch("nia_etl_utils.embedding._criar_client")
@patch("nia_etl_utils.embedding.logger")
def test_batch_textos_somente_espacos_retornam_lista_vazia(mock_logger, mock_criar_client):
    """Testa que textos com apenas espaços retornam lista vazia."""
    mock_emb1 = MagicMock()
    mock_emb1.embedding = [0.1]
    mock_emb2 = MagicMock()
    mock_emb2.embedding = [0.9]

    mock_response = MagicMock()
    mock_response.data = [mock_emb1, mock_emb2]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai_batch(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        textos=["texto válido", "   \t\n  "],
    )

    assert len(resultado) == 2
    assert resultado[0] == [0.1]
    assert resultado[1] == []


@patch("nia_etl_utils.embedding._criar_client")
@patch("nia_etl_utils.embedding.logger")
def test_batch_textos_none_retornam_lista_vazia(mock_logger, mock_criar_client):
    """Testa que textos None retornam lista vazia."""
    mock_emb1 = MagicMock()
    mock_emb1.embedding = [0.1]
    mock_emb2 = MagicMock()
    mock_emb2.embedding = [0.9]

    mock_response = MagicMock()
    mock_response.data = [mock_emb1, mock_emb2]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai_batch(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        textos=["texto válido", None],  # type: ignore
    )

    assert len(resultado) == 2
    assert resultado[0] == [0.1]
    assert resultado[1] == []


# ============================================================
# Testes de timeout e retry - gerar_embedding_openai_batch
# ============================================================
@patch("nia_etl_utils.embedding.time.sleep")
@patch("nia_etl_utils.embedding._criar_client")
@patch("nia_etl_utils.embedding.logger")
def test_batch_timeout_com_retry_sucesso(mock_logger, mock_criar_client, mock_sleep):
    """Testa retry bem-sucedido em batch após timeout inicial."""
    mock_emb = MagicMock()
    mock_emb.embedding = [0.1, 0.2]

    mock_response = MagicMock()
    mock_response.data = [mock_emb]

    from openai import APITimeoutError

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.side_effect = [
        APITimeoutError(request=MagicMock()),
        mock_response,
    ]
    mock_criar_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai_batch(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        textos=["texto"],
        max_retries=3,
        intervalo_segundos=2,
    )

    assert resultado == [[0.1, 0.2]]
    mock_sleep.assert_called_once_with(2)


@patch("nia_etl_utils.embedding.time.sleep")
@patch("nia_etl_utils.embedding._criar_client")
def test_batch_timeout_esgota_retries(mock_criar_client, mock_sleep):
    """Testa que batch esgota retries e levanta EmbeddingTimeoutError."""
    from openai import APITimeoutError

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.side_effect = APITimeoutError(request=MagicMock())
    mock_criar_client.return_value = mock_client_instance

    with pytest.raises(EmbeddingTimeoutError) as exc:
        gerar_embedding_openai_batch(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            textos=["texto1", "texto2"],
            max_retries=3,
        )

    assert "Timeout após 3 tentativas" in str(exc.value)
    assert exc.value.details["quantidade_textos"] == 2


# ============================================================
# Testes de erros - gerar_embedding_openai_batch
# ============================================================
@patch("nia_etl_utils.embedding._criar_client")
def test_batch_erro_generico_levanta_embedding_error(mock_criar_client):
    """Testa que erro genérico em batch levanta EmbeddingError."""
    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.side_effect = RuntimeError("erro API")
    mock_criar_client.return_value = mock_client_instance

    with pytest.raises(EmbeddingError) as exc:
        gerar_embedding_openai_batch(
            endpoint=ENDPOINT,
            api_key=API_KEY,
            model_embedding=MODEL,
            api_version=API_VERSION,
            textos=["texto1", "texto2"],
        )

    assert "Erro ao gerar embeddings" in str(exc.value)
    assert exc.value.details["quantidade_textos"] == 2
    assert exc.value.details["erro"] == "erro API"


# ============================================================
# Testes de logs - gerar_embedding_openai_batch
# ============================================================
@patch("nia_etl_utils.embedding._criar_client")
@patch("nia_etl_utils.embedding.logger")
def test_batch_loga_quantidade_textos(mock_logger, mock_criar_client):
    """Testa que batch loga quantidade de textos processados."""
    mock_emb1 = MagicMock()
    mock_emb1.embedding = [0.1]
    mock_emb2 = MagicMock()
    mock_emb2.embedding = [0.2]

    mock_response = MagicMock()
    mock_response.data = [mock_emb1, mock_emb2]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    gerar_embedding_openai_batch(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        textos=["texto1", "texto2"],
    )

    # Verifica logs de info
    info_calls = [str(call) for call in mock_logger.info.call_args_list]
    assert any("2 textos" in call for call in info_calls)
    assert any("2 vetores" in call for call in info_calls)


def test_truncar_texto_por_tokens_sem_truncamento():
    """Testa que texto curto não é truncado."""
    texto = "Texto curto"
    texto_processado, tokens_originais, foi_truncado = _truncar_texto_por_tokens(
        texto, max_tokens=100, model_embedding=MODEL
    )

    assert texto_processado == texto
    assert foi_truncado is False
    assert tokens_originais > 0


def test_truncar_texto_por_tokens_com_truncamento():
    """Testa que texto longo é truncado."""
    texto = "palavra " * 1000  # texto longo
    texto_processado, tokens_originais, foi_truncado = _truncar_texto_por_tokens(
        texto, max_tokens=10, model_embedding=MODEL
    )

    assert foi_truncado is True
    assert tokens_originais > 10
    assert len(texto_processado) < len(texto)


def test_truncar_texto_por_tokens_modelo_desconhecido_usa_fallback():
    """Testa que modelo desconhecido usa encoding fallback."""
    texto = "Texto de teste"
    texto_processado, tokens_originais, foi_truncado = _truncar_texto_por_tokens(
        texto, max_tokens=100, model_embedding="modelo-inexistente-xyz"
    )

    # Não deve levantar exceção, deve usar fallback
    assert texto_processado == texto
    assert foi_truncado is False


# ============================================================
# Testes de truncamento - gerar_embedding_openai
# ============================================================
@patch("nia_etl_utils.embedding._criar_client")
@patch("nia_etl_utils.embedding._truncar_texto_por_tokens")
@patch("nia_etl_utils.embedding.logger")
def test_gerar_embedding_trunca_texto_longo(mock_logger, mock_truncar, mock_criar_client):
    """Testa que texto longo é truncado e log é emitido."""
    mock_truncar.return_value = ("texto truncado", 10000, True)

    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [0.1, 0.2]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        texto="texto muito longo",
        max_tokens=8191,
    )

    assert resultado == [0.1, 0.2]
    mock_truncar.assert_called_once()
    # Verifica que log de truncamento foi emitido
    mock_logger.info.assert_called()
    info_calls = [str(call) for call in mock_logger.info.call_args_list]
    assert any("truncado" in call for call in info_calls)


@patch("nia_etl_utils.embedding._criar_client")
@patch("nia_etl_utils.embedding._truncar_texto_por_tokens")
def test_gerar_embedding_nao_trunca_quando_max_tokens_none(mock_truncar, mock_criar_client):
    """Testa que truncamento é desabilitado com max_tokens=None."""
    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [0.1]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    gerar_embedding_openai(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        texto="texto",
        max_tokens=None,  # Desabilita truncamento
    )

    mock_truncar.assert_not_called()


@patch("nia_etl_utils.embedding._criar_client")
@patch("nia_etl_utils.embedding._truncar_texto_por_tokens")
@patch("nia_etl_utils.embedding.logger")
def test_gerar_embedding_nao_loga_quando_nao_trunca(mock_logger, mock_truncar, mock_criar_client):
    """Testa que log de truncamento não é emitido quando texto não é truncado."""
    mock_truncar.return_value = ("texto curto", 5, False)  # foi_truncado=False

    mock_embedding_data = MagicMock()
    mock_embedding_data.embedding = [0.1]

    mock_response = MagicMock()
    mock_response.data = [mock_embedding_data]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    gerar_embedding_openai(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        texto="texto curto",
    )

    # Não deve ter log de truncamento
    info_calls = [str(call) for call in mock_logger.info.call_args_list]
    assert not any("truncado" in call.lower() for call in info_calls)


# ============================================================
# Testes de truncamento - gerar_embedding_openai_batch
# ============================================================
@patch("nia_etl_utils.embedding._criar_client")
@patch("nia_etl_utils.embedding._truncar_texto_por_tokens")
@patch("nia_etl_utils.embedding.logger")
def test_batch_trunca_textos_longos(mock_logger, mock_truncar, mock_criar_client):
    """Testa que textos longos são truncados em batch."""
    # Primeiro texto truncado, segundo não
    mock_truncar.side_effect = [
        ("texto1 truncado", 10000, True),
        ("texto2", 100, False),
    ]

    mock_emb1 = MagicMock()
    mock_emb1.embedding = [0.1]
    mock_emb2 = MagicMock()
    mock_emb2.embedding = [0.2]

    mock_response = MagicMock()
    mock_response.data = [mock_emb1, mock_emb2]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai_batch(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        textos=["texto1 longo", "texto2"],
        max_tokens=8191,
    )

    assert len(resultado) == 2
    assert mock_truncar.call_count == 2
    # Verifica log de truncamento (1 texto truncado)
    info_calls = [str(call) for call in mock_logger.info.call_args_list]
    assert any("1 texto(s) truncado(s)" in call for call in info_calls)


@patch("nia_etl_utils.embedding._criar_client")
@patch("nia_etl_utils.embedding._truncar_texto_por_tokens")
@patch("nia_etl_utils.embedding.logger")
def test_batch_nao_trunca_quando_max_tokens_none(mock_logger, mock_truncar, mock_criar_client):
    """Testa que truncamento é desabilitado em batch com max_tokens=None."""
    mock_emb = MagicMock()
    mock_emb.embedding = [0.1]

    mock_response = MagicMock()
    mock_response.data = [mock_emb]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    gerar_embedding_openai_batch(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        textos=["texto"],
        max_tokens=None,
    )

    mock_truncar.assert_not_called()


@patch("nia_etl_utils.embedding._criar_client")
@patch("nia_etl_utils.embedding._truncar_texto_por_tokens")
@patch("nia_etl_utils.embedding.logger")
def test_batch_nao_loga_truncamento_quando_nenhum_truncado(
    mock_logger, mock_truncar, mock_criar_client
):
    """Testa que log de truncamento não é emitido quando nenhum texto é truncado."""
    mock_truncar.side_effect = [
        ("texto1", 10, False),
        ("texto2", 15, False),
    ]

    mock_emb1 = MagicMock()
    mock_emb1.embedding = [0.1]
    mock_emb2 = MagicMock()
    mock_emb2.embedding = [0.2]

    mock_response = MagicMock()
    mock_response.data = [mock_emb1, mock_emb2]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    gerar_embedding_openai_batch(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        textos=["texto1", "texto2"],
    )

    # Não deve ter log de truncamento
    info_calls = [str(call) for call in mock_logger.info.call_args_list]
    assert not any("truncado" in call.lower() for call in info_calls)


@patch("nia_etl_utils.embedding._criar_client")
@patch("nia_etl_utils.embedding.logger")
def test_batch_nao_trunca_textos_vazios(mock_logger, mock_criar_client):
    """Testa que textos vazios não passam pelo truncamento."""
    mock_emb1 = MagicMock()
    mock_emb1.embedding = [0.1]
    mock_emb2 = MagicMock()
    mock_emb2.embedding = [0.9]  # placeholder

    mock_response = MagicMock()
    mock_response.data = [mock_emb1, mock_emb2]

    mock_client_instance = MagicMock()
    mock_client_instance.embeddings.create.return_value = mock_response
    mock_criar_client.return_value = mock_client_instance

    resultado = gerar_embedding_openai_batch(
        endpoint=ENDPOINT,
        api_key=API_KEY,
        model_embedding=MODEL,
        api_version=API_VERSION,
        textos=["texto válido", ""],  # segundo é vazio
    )

    assert resultado[1] == []  # texto vazio retorna lista vazia
    # API foi chamada com placeholder para texto vazio
    call_args = mock_client_instance.embeddings.create.call_args
    assert " " in call_args.kwargs["input"]  # placeholder é espaço


# ============================================================
# Testes de constante padrão
# ============================================================
def test_default_max_tokens_valor():
    """Testa que constante DEFAULT_MAX_TOKENS tem valor esperado."""
    from nia_etl_utils.embedding import _DEFAULT_MAX_TOKENS

    assert _DEFAULT_MAX_TOKENS == 8191
