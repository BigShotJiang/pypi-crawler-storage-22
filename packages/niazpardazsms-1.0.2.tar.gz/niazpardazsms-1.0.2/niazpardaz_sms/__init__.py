"""
NiazpardazSms SDK for Python
کتابخانه رسمی پایتون برای کار با پنل پیامکی نیازپرداز

Example:
    >>> from niazpardaz_sms import NiazpardazSmsClient
    >>> client = NiazpardazSmsClient("YOUR_API_KEY")
    >>> result = client.send("10001234", "09123456789", "سلام!")
    >>> print(result.batch_sms_id)

Async Example:
    >>> from niazpardaz_sms import AsyncNiazpardazSmsClient
    >>> async with AsyncNiazpardazSmsClient("YOUR_API_KEY") as client:
    ...     result = await client.send("10001234", "09123456789", "سلام!")
    ...     print(result.batch_sms_id)
"""

__version__ = "1.0.2"
__author__ = "Niazpardaz"
__license__ = "MIT"

from .client import NiazpardazSmsClient
from .async_client import AsyncNiazpardazSmsClient
from .exceptions import NiazpardazApiException

from .models import (
    # Enums
    SendResultCode,
    DeliveryResultCode,
    SmsDeliveryStatus,
    CreditResultCode,
    SenderNumbersResultCode,
    BlacklistResultCode,
    CheckContentResultCode,
    InboxCountResultCode,
    SmsLangType,
    SmsStatusType,
    SmsSendStatusType,
    SmsSendMethodType,
    SmsDirectionType,
    # Results
    SendBatchSmsResult,
    SendLikeToLikeResult,
    BatchDeliveryResult,
    CreditResult,
    SenderNumbersResult,
    BlacklistNumbersResult,
    IsBlacklistResult,
    CheckContentResult,
    InboxCountResult,
    MessageInfo,
    MessagesResult
)

__all__ = [
    # Version
    '__version__',
    '__author__',
    '__license__',
    # Clients
    'NiazpardazSmsClient',
    'AsyncNiazpardazSmsClient',
    # Exceptions
    'NiazpardazApiException',
    # Enums
    'SendResultCode',
    'DeliveryResultCode',
    'SmsDeliveryStatus',
    'CreditResultCode',
    'SenderNumbersResultCode',
    'BlacklistResultCode',
    'CheckContentResultCode',
    'InboxCountResultCode',
    'SmsLangType',
    'SmsStatusType',
    'SmsSendStatusType',
    'SmsSendMethodType',
    'SmsDirectionType',
    # Results
    'SendBatchSmsResult',
    'SendLikeToLikeResult',
    'BatchDeliveryResult',
    'CreditResult',
    'SenderNumbersResult',
    'BlacklistNumbersResult',
    'IsBlacklistResult',
    'CheckContentResult',
    'InboxCountResult',
    'MessageInfo',
    'MessagesResult'
]
