"""
کلاینت async برای کار با پنل پیامکی نیازپرداز
برای استفاده با فریم‌ورک‌های async مثل FastAPI، aiohttp، Django async و غیره
"""
import json
from datetime import datetime
from typing import List, Optional, TypeVar, Type

try:
    import aiohttp
    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False

try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    HTTPX_AVAILABLE = False

from .exceptions import NiazpardazApiException
from .models import (
    SendBatchSmsResult, SendLikeToLikeResult, BatchDeliveryResult,
    CreditResult, SenderNumbersResult, BlacklistNumbersResult,
    IsBlacklistResult, CheckContentResult, InboxCountResult, MessagesResult
)

T = TypeVar('T')

DEFAULT_BASE_URL = "https://login.niazpardaz.ir/api/v2/RestWebApi"


class AsyncNiazpardazSmsClient:
    """
    کلاینت async برای کار با پنل پیامکی نیازپرداز
    
    این کلاینت برای استفاده با فریم‌ورک‌های async مثل FastAPI، aiohttp و Django async طراحی شده است.
    نیاز به نصب aiohttp یا httpx دارد.
    
    Example:
        >>> async with AsyncNiazpardazSmsClient("YOUR_API_KEY") as client:
        ...     result = await client.send("10001234", "09123456789", "سلام!")
        ...     print(result.batch_sms_id)
    """
    
    def __init__(
        self, 
        api_key: str, 
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = 30,
        use_httpx: bool = False
    ):
        """
        سازنده کلاینت
        
        Args:
            api_key: کلید API دریافتی از پنل
            base_url: آدرس پایه API (اختیاری)
            timeout: زمان انتظار برای درخواست‌ها به ثانیه (پیش‌فرض: 30)
            use_httpx: استفاده از httpx به جای aiohttp (پیش‌فرض: False)
        """
        if not api_key or not api_key.strip():
            raise ValueError("کلید API نمی‌تواند خالی باشد")
        
        self._api_key = api_key
        self._base_url = base_url.rstrip('/')
        self._timeout = timeout
        self._use_httpx = use_httpx
        self._session = None
        self._httpx_client = None
        
        # بررسی وجود کتابخانه‌های مورد نیاز
        if use_httpx and not HTTPX_AVAILABLE:
            raise ImportError(
                "برای استفاده از httpx باید آن را نصب کنید: pip install httpx"
            )
        if not use_httpx and not AIOHTTP_AVAILABLE:
            if HTTPX_AVAILABLE:
                self._use_httpx = True
            else:
                raise ImportError(
                    "برای استفاده از کلاینت async باید aiohttp یا httpx را نصب کنید:\n"
                    "pip install aiohttp\n"
                    "یا\n"
                    "pip install httpx"
                )
    
    async def __aenter__(self):
        """ورود به context manager"""
        if self._use_httpx:
            self._httpx_client = httpx.AsyncClient(timeout=self._timeout)
        else:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=self._timeout)
            )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """خروج از context manager"""
        await self.close()
    
    async def close(self):
        """بستن session"""
        if self._session:
            await self._session.close()
            self._session = None
        if self._httpx_client:
            await self._httpx_client.aclose()
            self._httpx_client = None
    
    # region Send SMS
    
    async def send(
        self,
        from_number: str,
        to_number: str,
        message: str,
        is_flash: bool = False,
        send_delay: Optional[int] = None
    ) -> SendBatchSmsResult:
        """
        ارسال پیامک تکی
        
        Args:
            from_number: شماره فرستنده
            to_number: شماره گیرنده
            message: متن پیامک
            is_flash: آیا فلش باشد؟
            send_delay: تاخیر ارسال (ثانیه)
            
        Returns:
            نتیجه ارسال
        """
        if not from_number:
            raise ValueError("شماره فرستنده نمی‌تواند خالی باشد")
        if not to_number:
            raise ValueError("شماره گیرنده نمی‌تواند خالی باشد")
        if not message:
            raise ValueError("متن پیامک نمی‌تواند خالی باشد")
        
        return await self.send_bulk(from_number, [to_number], message, is_flash, send_delay)
    
    async def send_bulk(
        self,
        from_number: str,
        to_numbers: List[str],
        message: str,
        is_flash: bool = False,
        send_delay: Optional[int] = None
    ) -> SendBatchSmsResult:
        """
        ارسال پیامک گروهی (یک متن به چند شماره)
        
        Args:
            from_number: شماره فرستنده
            to_numbers: لیست شماره گیرندگان
            message: متن پیامک
            is_flash: آیا فلش باشد؟
            send_delay: تاخیر ارسال
            
        Returns:
            نتیجه ارسال
        """
        if not from_number:
            raise ValueError("شماره فرستنده نمی‌تواند خالی باشد")
        if not to_numbers:
            raise ValueError("لیست گیرندگان نمی‌تواند خالی باشد")
        if not message:
            raise ValueError("متن پیامک نمی‌تواند خالی باشد")
        
        payload = {
            "fromNumber": from_number,
            "messageContent": message,
            "toNumbers": ",".join(to_numbers),
            "isFlash": is_flash,
            "sendDelay": send_delay
        }
        
        return await self._post("/SendBatchSms", payload, SendBatchSmsResult)
    
    async def send_like_to_like(
        self,
        from_number: str,
        to_numbers: List[str],
        messages: List[str],
        is_flash: bool = False
    ) -> SendLikeToLikeResult:
        """
        ارسال پیامک LikeToLike (هر شماره پیام مخصوص خودش)
        
        Args:
            from_number: شماره فرستنده
            to_numbers: لیست شماره گیرندگان
            messages: لیست پیام‌ها (هم‌طول با گیرندگان)
            is_flash: آیا فلش باشد؟
            
        Returns:
            نتیجه ارسال
        """
        if not from_number:
            raise ValueError("شماره فرستنده نمی‌تواند خالی باشد")
        if not to_numbers:
            raise ValueError("لیست گیرندگان نمی‌تواند خالی باشد")
        if not messages:
            raise ValueError("لیست پیام‌ها نمی‌تواند خالی باشد")
        
        payload = {
            "fromNumber": from_number,
            "messageContents": ",".join(messages),
            "toNumbers": ",".join(to_numbers),
            "isFlash": is_flash
        }
        
        return await self._post("/SendSmsLikeToLike", payload, SendLikeToLikeResult)
    
    async def send_voice_otp(
        self,
        from_number: str,
        to_number: str,
        otp: str,
        is_flash: bool = False,
        send_delay: Optional[int] = None
    ) -> SendBatchSmsResult:
        """
        ارسال پیامک صوتی OTP
        
        Args:
            from_number: شماره فرستنده
            to_number: شماره گیرنده
            otp: کد OTP
            is_flash: آیا فلش باشد؟
            send_delay: تاخیر ارسال
            
        Returns:
            نتیجه ارسال
        """
        if not from_number:
            raise ValueError("شماره فرستنده نمی‌تواند خالی باشد")
        if not to_number:
            raise ValueError("شماره گیرنده نمی‌تواند خالی باشد")
        if not otp:
            raise ValueError("کد OTP نمی‌تواند خالی باشد")
        
        payload = {
            "fromNumber": from_number,
            "messageContent": otp,
            "toNumbers": to_number,
            "sendDelay": send_delay,
            "isFlash": is_flash
        }
        
        return await self._post("/SendVoiceOtp", payload, SendBatchSmsResult)
    
    # endregion
    
    # region Delivery
    
    async def get_batch_delivery(
        self,
        batch_sms_id: int,
        page_index: int = 1,
        page_size: int = 100
    ) -> BatchDeliveryResult:
        """
        گزارش تحویل پیامک گروهی
        
        Args:
            batch_sms_id: شناسه ارسال گروهی
            page_index: شماره صفحه
            page_size: تعداد رکورد در صفحه
            
        Returns:
            نتیجه گزارش تحویل
        """
        payload = {
            "batchSmsId": batch_sms_id,
            "index": page_index,
            "count": page_size
        }
        
        return await self._post("/GetBatchDelivery", payload, BatchDeliveryResult)
    
    async def get_delivery_like_to_like(self, sms_id: int) -> BatchDeliveryResult:
        """
        گزارش تحویل پیامک LikeToLike
        
        Args:
            sms_id: شناسه پیامک
            
        Returns:
            نتیجه گزارش تحویل
        """
        payload = {"smsId": sms_id}
        return await self._post("/GetDeliveryLikeToLike", payload, BatchDeliveryResult)
    
    # endregion
    
    # region Account
    
    async def get_credit(self) -> CreditResult:
        """
        دریافت اعتبار حساب
        
        Returns:
            نتیجه اعتبار
        """
        return await self._post("/GetCredit", {}, CreditResult)
    
    async def get_sender_numbers(self) -> SenderNumbersResult:
        """
        دریافت لیست شماره‌های فرستنده
        
        Returns:
            نتیجه شماره‌های فرستنده
        """
        return await self._post("/GetSenderNumbers", {}, SenderNumbersResult)
    
    # endregion
    
    # region Inbox
    
    async def get_inbox_count(self, is_read: bool = False) -> InboxCountResult:
        """
        دریافت تعداد پیامک‌های دریافتی
        
        Args:
            is_read: فقط خوانده شده‌ها؟
            
        Returns:
            نتیجه تعداد پیامک‌ها
        """
        payload = {"isRead": is_read}
        return await self._post("/GetInboxCount", payload, InboxCountResult)
    
    async def get_messages(
        self,
        message_type: int,
        from_numbers: str,
        page_index: int = 1,
        page_size: int = 100
    ) -> MessagesResult:
        """
        دریافت پیامک‌ها
        
        Args:
            message_type: نوع پیامک
            from_numbers: شماره‌های فرستنده (با کاما جدا شده)
            page_index: شماره صفحه
            page_size: تعداد رکورد در صفحه
            
        Returns:
            نتیجه پیامک‌ها
        """
        payload = {
            "messageType": message_type,
            "fromNumbers": from_numbers,
            "index": page_index,
            "count": page_size
        }
        
        return await self._post("/GetMessages", payload, MessagesResult)
    
    async def get_messages_by_date_range(
        self,
        message_type: int,
        from_numbers: str,
        from_date: datetime,
        to_date: datetime
    ) -> MessagesResult:
        """
        دریافت پیامک‌ها بر اساس بازه زمانی
        
        Args:
            message_type: نوع پیامک
            from_numbers: شماره‌های فرستنده (با کاما جدا شده)
            from_date: تاریخ شروع
            to_date: تاریخ پایان
            
        Returns:
            نتیجه پیامک‌ها
        """
        payload = {
            "messageType": message_type,
            "fromNumbers": from_numbers,
            "fromDate": from_date.isoformat(),
            "toDate": to_date.isoformat()
        }
        
        return await self._post("/GetMessagesByDateRange", payload, MessagesResult)
    
    # endregion
    
    # region Blacklist
    
    async def extract_telecom_blacklist_numbers(
        self, 
        numbers: List[str]
    ) -> BlacklistNumbersResult:
        """
        استخراج شماره‌های لیست سیاه مخابرات
        
        Args:
            numbers: لیست شماره‌ها
            
        Returns:
            نتیجه شماره‌های لیست سیاه
        """
        payload = {"numbers": ",".join(numbers)}
        return await self._post("/ExtractTelecomBlacklistNumbers", payload, BlacklistNumbersResult)
    
    async def number_is_in_telecom_blacklist(self, number: str) -> IsBlacklistResult:
        """
        بررسی اینکه آیا شماره در لیست سیاه مخابرات هست؟
        
        Args:
            number: شماره موبایل
            
        Returns:
            نتیجه بررسی
        """
        payload = {"number": number}
        return await self._post("/NumberIsInTelecomBlacklist", payload, IsBlacklistResult)
    
    # endregion
    
    # region Validation
    
    async def check_sms_content(self, message: str) -> CheckContentResult:
        """
        بررسی محتوای پیامک (فیلتر کلمات)
        
        Args:
            message: متن پیامک
            
        Returns:
            نتیجه بررسی
        """
        payload = {"message": message}
        return await self._post("/CheckSmsContent", payload, CheckContentResult)
    
    # endregion
    
    # region Private Methods
    
    async def _post(self, endpoint: str, payload: dict, result_type: Type[T]) -> T:
        """
        ارسال درخواست POST به API
        
        Args:
            endpoint: آدرس endpoint
            payload: داده‌های درخواست
            result_type: نوع نتیجه
            
        Returns:
            نتیجه درخواست
        """
        url = f"{self._base_url}{endpoint}"
        headers = {
            'Content-Type': 'application/json',
            'X-API-Key': self._api_key
        }
        
        try:
            if self._use_httpx:
                response_json = await self._post_httpx(url, payload, headers)
            else:
                response_json = await self._post_aiohttp(url, payload, headers)
        except Exception as e:
            if isinstance(e, NiazpardazApiException):
                raise
            raise NiazpardazApiException(
                f"خطا در اتصال به سرور: {str(e)}",
                inner_exception=e
            )
        
        if not response_json.get('success', False):
            raise NiazpardazApiException(
                response_json.get('errorMessage', 'خطای نامشخص')
            )
        
        result_data = response_json.get('result', {})
        return result_type.from_dict(result_data)
    
    async def _post_aiohttp(self, url: str, payload: dict, headers: dict) -> dict:
        """ارسال درخواست با aiohttp"""
        if not self._session:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=self._timeout)
            )
        
        async with self._session.post(url, json=payload, headers=headers) as response:
            if response.status >= 400:
                raise NiazpardazApiException(
                    f"خطا در ارتباط با سرور: {response.status}",
                    error_code=response.status
                )
            return await response.json()
    
    async def _post_httpx(self, url: str, payload: dict, headers: dict) -> dict:
        """ارسال درخواست با httpx"""
        if not self._httpx_client:
            self._httpx_client = httpx.AsyncClient(timeout=self._timeout)
        
        response = await self._httpx_client.post(url, json=payload, headers=headers)
        if response.status_code >= 400:
            raise NiazpardazApiException(
                f"خطا در ارتباط با سرور: {response.status_code}",
                error_code=response.status_code
            )
        return response.json()
    
    # endregion
