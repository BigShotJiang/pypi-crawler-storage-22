"""
کلاینت اصلی برای کار با API پیامکی نیازپرداز
"""
import json
from datetime import datetime
from typing import List, Optional, Union, TypeVar, Type
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

from .exceptions import NiazpardazApiException
from .models import (
    SendBatchSmsResult, SendLikeToLikeResult, BatchDeliveryResult,
    CreditResult, SenderNumbersResult, BlacklistNumbersResult,
    IsBlacklistResult, CheckContentResult, InboxCountResult, MessagesResult
)

T = TypeVar('T')

DEFAULT_BASE_URL = "https://login.niazpardaz.ir/api/v2/RestWebApi"


class NiazpardazSmsClient:
    """
    کلاینت اصلی برای کار با پنل پیامکی نیازپرداز
    
    این کلاینت از کتابخانه استاندارد پایتون استفاده می‌کند و نیازی به وابستگی خارجی ندارد.
    برای استفاده با فریم‌ورک‌های async مثل FastAPI یا Django async از AsyncNiazpardazSmsClient استفاده کنید.
    
    Example:
        >>> client = NiazpardazSmsClient("YOUR_API_KEY")
        >>> result = client.send("10001234", "09123456789", "سلام!")
        >>> print(result.batch_sms_id)
    """
    
    def __init__(
        self, 
        api_key: str, 
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = 30
    ):
        """
        سازنده کلاینت
        
        Args:
            api_key: کلید API دریافتی از پنل
            base_url: آدرس پایه API (اختیاری)
            timeout: زمان انتظار برای درخواست‌ها به ثانیه (پیش‌فرض: 30)
        """
        if not api_key or not api_key.strip():
            raise ValueError("کلید API نمی‌تواند خالی باشد")
        
        self._api_key = api_key
        self._base_url = base_url.rstrip('/')
        self._timeout = timeout
    
    # region Send SMS
    
    def send(
        self,
        from_number: str,
        to_number: str,
        message: str,
        is_flash: bool = False,
        send_delay: Optional[int] = None
    ) -> SendBatchSmsResult:
        """
        ارسال پیامک تکی
        
        Args:
            from_number: شماره فرستنده
            to_number: شماره گیرنده
            message: متن پیامک
            is_flash: آیا فلش باشد؟
            send_delay: تاخیر ارسال (ثانیه)
            
        Returns:
            نتیجه ارسال
        """
        if not from_number:
            raise ValueError("شماره فرستنده نمی‌تواند خالی باشد")
        if not to_number:
            raise ValueError("شماره گیرنده نمی‌تواند خالی باشد")
        if not message:
            raise ValueError("متن پیامک نمی‌تواند خالی باشد")
        
        return self.send_bulk(from_number, [to_number], message, is_flash, send_delay)
    
    def send_bulk(
        self,
        from_number: str,
        to_numbers: List[str],
        message: str,
        is_flash: bool = False,
        send_delay: Optional[int] = None
    ) -> SendBatchSmsResult:
        """
        ارسال پیامک گروهی (یک متن به چند شماره)
        
        Args:
            from_number: شماره فرستنده
            to_numbers: لیست شماره گیرندگان
            message: متن پیامک
            is_flash: آیا فلش باشد؟
            send_delay: تاخیر ارسال
            
        Returns:
            نتیجه ارسال
        """
        if not from_number:
            raise ValueError("شماره فرستنده نمی‌تواند خالی باشد")
        if not to_numbers:
            raise ValueError("لیست گیرندگان نمی‌تواند خالی باشد")
        if not message:
            raise ValueError("متن پیامک نمی‌تواند خالی باشد")
        
        payload = {
            "fromNumber": from_number,
            "messageContent": message,
            "toNumbers": ",".join(to_numbers),
            "isFlash": is_flash,
            "sendDelay": send_delay
        }
        
        return self._post("/SendBatchSms", payload, SendBatchSmsResult)
    
    def send_like_to_like(
        self,
        from_number: str,
        to_numbers: List[str],
        messages: List[str],
        is_flash: bool = False
    ) -> SendLikeToLikeResult:
        """
        ارسال پیامک LikeToLike (هر شماره پیام مخصوص خودش)
        
        Args:
            from_number: شماره فرستنده
            to_numbers: لیست شماره گیرندگان
            messages: لیست پیام‌ها (هم‌طول با گیرندگان)
            is_flash: آیا فلش باشد؟
            
        Returns:
            نتیجه ارسال
        """
        if not from_number:
            raise ValueError("شماره فرستنده نمی‌تواند خالی باشد")
        if not to_numbers:
            raise ValueError("لیست گیرندگان نمی‌تواند خالی باشد")
        if not messages:
            raise ValueError("لیست پیام‌ها نمی‌تواند خالی باشد")
        
        payload = {
            "fromNumber": from_number,
            "messageContents": ",".join(messages),
            "toNumbers": ",".join(to_numbers),
            "isFlash": is_flash
        }
        
        return self._post("/SendSmsLikeToLike", payload, SendLikeToLikeResult)
    
    def send_voice_otp(
        self,
        from_number: str,
        to_number: str,
        otp: str,
        is_flash: bool = False,
        send_delay: Optional[int] = None
    ) -> SendBatchSmsResult:
        """
        ارسال پیامک صوتی OTP
        
        Args:
            from_number: شماره فرستنده
            to_number: شماره گیرنده
            otp: کد OTP
            is_flash: آیا فلش باشد؟
            send_delay: تاخیر ارسال
            
        Returns:
            نتیجه ارسال
        """
        if not from_number:
            raise ValueError("شماره فرستنده نمی‌تواند خالی باشد")
        if not to_number:
            raise ValueError("شماره گیرنده نمی‌تواند خالی باشد")
        if not otp:
            raise ValueError("کد OTP نمی‌تواند خالی باشد")
        
        payload = {
            "fromNumber": from_number,
            "messageContent": otp,
            "toNumbers": to_number,
            "sendDelay": send_delay,
            "isFlash": is_flash
        }
        
        return self._post("/SendVoiceOtp", payload, SendBatchSmsResult)
    
    # endregion
    
    # region Delivery
    
    def get_batch_delivery(
        self,
        batch_sms_id: int,
        page_index: int = 1,
        page_size: int = 100
    ) -> BatchDeliveryResult:
        """
        گزارش تحویل پیامک گروهی
        
        Args:
            batch_sms_id: شناسه ارسال گروهی
            page_index: شماره صفحه
            page_size: تعداد رکورد در صفحه
            
        Returns:
            نتیجه گزارش تحویل
        """
        payload = {
            "batchSmsId": batch_sms_id,
            "index": page_index,
            "count": page_size
        }
        
        return self._post("/GetBatchDelivery", payload, BatchDeliveryResult)
    
    def get_delivery_like_to_like(self, sms_id: int) -> BatchDeliveryResult:
        """
        گزارش تحویل پیامک LikeToLike
        
        Args:
            sms_id: شناسه پیامک
            
        Returns:
            نتیجه گزارش تحویل
        """
        payload = {"smsId": sms_id}
        return self._post("/GetDeliveryLikeToLike", payload, BatchDeliveryResult)
    
    # endregion
    
    # region Account
    
    def get_credit(self) -> CreditResult:
        """
        دریافت اعتبار حساب
        
        Returns:
            نتیجه اعتبار
        """
        return self._post("/GetCredit", {}, CreditResult)
    
    def get_sender_numbers(self) -> SenderNumbersResult:
        """
        دریافت لیست شماره‌های فرستنده
        
        Returns:
            نتیجه شماره‌های فرستنده
        """
        return self._post("/GetSenderNumbers", {}, SenderNumbersResult)
    
    # endregion
    
    # region Inbox
    
    def get_inbox_count(self, is_read: bool = False) -> InboxCountResult:
        """
        دریافت تعداد پیامک‌های دریافتی
        
        Args:
            is_read: فقط خوانده شده‌ها؟
            
        Returns:
            نتیجه تعداد پیامک‌ها
        """
        payload = {"isRead": is_read}
        return self._post("/GetInboxCount", payload, InboxCountResult)
    
    def get_messages(
        self,
        message_type: int,
        from_numbers: str,
        page_index: int = 1,
        page_size: int = 100
    ) -> MessagesResult:
        """
        دریافت پیامک‌ها
        
        Args:
            message_type: نوع پیامک
            from_numbers: شماره‌های فرستنده (با کاما جدا شده)
            page_index: شماره صفحه
            page_size: تعداد رکورد در صفحه
            
        Returns:
            نتیجه پیامک‌ها
        """
        payload = {
            "messageType": message_type,
            "fromNumbers": from_numbers,
            "index": page_index,
            "count": page_size
        }
        
        return self._post("/GetMessages", payload, MessagesResult)
    
    def get_messages_by_date_range(
        self,
        message_type: int,
        from_numbers: str,
        from_date: datetime,
        to_date: datetime
    ) -> MessagesResult:
        """
        دریافت پیامک‌ها بر اساس بازه زمانی
        
        Args:
            message_type: نوع پیامک
            from_numbers: شماره‌های فرستنده (با کاما جدا شده)
            from_date: تاریخ شروع
            to_date: تاریخ پایان
            
        Returns:
            نتیجه پیامک‌ها
        """
        payload = {
            "messageType": message_type,
            "fromNumbers": from_numbers,
            "fromDate": from_date.isoformat(),
            "toDate": to_date.isoformat()
        }
        
        return self._post("/GetMessagesByDateRange", payload, MessagesResult)
    
    # endregion
    
    # region Blacklist
    
    def extract_telecom_blacklist_numbers(
        self, 
        numbers: List[str]
    ) -> BlacklistNumbersResult:
        """
        استخراج شماره‌های لیست سیاه مخابرات
        
        Args:
            numbers: لیست شماره‌ها
            
        Returns:
            نتیجه شماره‌های لیست سیاه
        """
        payload = {"numbers": ",".join(numbers)}
        return self._post("/ExtractTelecomBlacklistNumbers", payload, BlacklistNumbersResult)
    
    def number_is_in_telecom_blacklist(self, number: str) -> IsBlacklistResult:
        """
        بررسی اینکه آیا شماره در لیست سیاه مخابرات هست؟
        
        Args:
            number: شماره موبایل
            
        Returns:
            نتیجه بررسی
        """
        payload = {"number": number}
        return self._post("/NumberIsInTelecomBlacklist", payload, IsBlacklistResult)
    
    # endregion
    
    # region Validation
    
    def check_sms_content(self, message: str) -> CheckContentResult:
        """
        بررسی محتوای پیامک (فیلتر کلمات)
        
        Args:
            message: متن پیامک
            
        Returns:
            نتیجه بررسی
        """
        payload = {"message": message}
        return self._post("/CheckSmsContent", payload, CheckContentResult)
    
    # endregion
    
    # region Private Methods
    
    def _post(self, endpoint: str, payload: dict, result_type: Type[T]) -> T:
        """
        ارسال درخواست POST به API
        
        Args:
            endpoint: آدرس endpoint
            payload: داده‌های درخواست
            result_type: نوع نتیجه
            
        Returns:
            نتیجه درخواست
        """
        url = f"{self._base_url}{endpoint}"
        data = json.dumps(payload).encode('utf-8')
        
        request = Request(url, data=data, method='POST')
        request.add_header('Content-Type', 'application/json')
        request.add_header('X-API-Key', self._api_key)
        
        try:
            with urlopen(request, timeout=self._timeout) as response:
                response_data = response.read().decode('utf-8')
                response_json = json.loads(response_data)
        except HTTPError as e:
            raise NiazpardazApiException(
                f"خطا در ارتباط با سرور: {e.code}",
                error_code=e.code
            )
        except URLError as e:
            raise NiazpardazApiException(
                f"خطا در اتصال به سرور: {e.reason}",
                inner_exception=e
            )
        except json.JSONDecodeError as e:
            raise NiazpardazApiException(
                "پاسخ نامعتبر از سرور",
                inner_exception=e
            )
        
        if not response_json.get('success', False):
            raise NiazpardazApiException(
                response_json.get('errorMessage', 'خطای نامشخص')
            )
        
        result_data = response_json.get('result', {})
        return result_type.from_dict(result_data)
    
    # endregion
