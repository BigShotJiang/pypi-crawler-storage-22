"""
استثناهای مربوط به API پیامکی نیازپرداز
"""
from typing import Optional


class NiazpardazApiException(Exception):
    """استثنای مربوط به خطاهای API نیازپرداز"""
    
    def __init__(
        self, 
        message: str, 
        error_code: Optional[int] = None,
        inner_exception: Optional[Exception] = None
    ):
        """
        سازنده استثنا
        
        Args:
            message: پیام خطا
            error_code: کد خطا (اختیاری)
            inner_exception: استثنای داخلی (اختیاری)
        """
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.inner_exception = inner_exception
    
    def __str__(self) -> str:
        if self.error_code is not None:
            return f"{self.message} (کد خطا: {self.error_code})"
        return self.message
    
    def __repr__(self) -> str:
        return f"NiazpardazApiException(message='{self.message}', error_code={self.error_code})"
