"""
Enum های مربوط به API پیامکی نیازپرداز
"""
from enum import IntEnum


class SendResultCode(IntEnum):
    """کدهای نتیجه ارسال پیامک"""
    
    # ارسال با موفقیت انجام شد
    SEND_WAS_SUCCESSFUL = 0
    # نام کاربر یا کلمه عبور نامعتبر می باشد
    INVALID_USER_NAME_OR_PASSWORD = 1
    # کاربر مسدود شده است
    USER_BLOCKED = 2
    # شماره فرستنده نامعتبر است
    INVALID_SENDER_NUMBER = 3
    # محدودیت در ارسال روزانه
    LIMITATION_IN_DAILY_SEND = 4
    # تعداد گیرندگان حداکثر 1000 شماره می باشد
    LIMITATION_IN_RECEIVER_COUNT = 5
    # خط فرستنده غیرفعال است
    SENDER_LINE_IS_INACTIVE = 6
    # متن پیامک شامل کلمات فیلتر شده است
    SMS_CONTENT_FILTERED_WORDS_IS_INCLUDED = 7
    # اعتبار کافی نیست
    NO_CREDIT = 8
    # سامانه در حال بروز رسانی است
    SYSTEM_BEING_UPDATED = 9
    # وب سرویس غیرفعال است
    WEB_SERVICE_NO_ACTIVE = 10
    # پیاده سازی نشده است
    NOT_IMPLEMENTED = 11
    # تعداد پیامها و شماره ها باید یکسان باشد
    LIKE_TO_LIKE_SEND_RECEIVER_AND_MESSAGE_COUNT_SHOULD_EQUAL = 12
    # تعداد پیامها حداکثر 100 پیام می باشد
    LIMITATION_IN_MESSAGE_CONTENT_COUNT = 13
    # هیچ مقداری برای تعرفه جاری کاربر تعریف نشده است
    USER_TARIFF_NOT_DETERMINED = 14
    # ارسال تکراری متن مشابه به شماره مشابه در مدت زمان مشخص
    DUPLICATE_SEND_SMS = 15
    # شماره موبایل گیرنده یافت نشد (گیرنده خالی، اشتباه یا بلاک لیست است)
    INVALID_NUMBER_EMPTY_OR_BLACK_LIST = 16
    # متن وارد نشده است
    TEXT_NOT_FOUND = 17
    # متن طبق الگوی تعریف شده نیست
    NOT_VALID_TEMPLATE_FOUND = 18
    # کاربر منقضی شده است
    USER_EXPIRED = 19
    # وضعیت کاربر فعال نیست
    USER_IS_NOT_ACTIVE = 20
    # مقدار یکی یا بیشتر از پارامترهای ورودی معتبر نیست
    INVALID_PARAMETERS = 21
    # آی پی موقت بلاک شده است
    IP_BLOCKED = 22
    # عملیات با خطا مواجه شد
    ENQUEUE_FAILED = 23
    # درخواست کاملا تکراری در بازه کوتاه
    DUPLICATE_REQUEST_THRESHOLD = 24
    # ApiKey نامعتبر
    INVALID_API_KEY = 25
    # خطا در ساخت فایل صوتی
    ERROR_CREATE_VOICE_FILE = 26


class DeliveryResultCode(IntEnum):
    """کدهای نتیجه گزارش تحویل"""
    
    # موفق
    SUCCESS = 0
    # خطا در ارتباط با سرویس دهنده
    SERVICE_CONNECTION_ERROR = -1
    # پیام با این کد وجود ندارد (batchSmsId نامعتبر است)
    INVALID_BATCH_SMS_ID = -2
    # مهلت یک هفته ای گرفتن گزارش پایان یافته است
    REPORT_EXPIRED = -3
    # پیام در صف ارسال مخابرات است
    MESSAGE_IN_QUEUE = -4
    # حداقل یک دقیقه بعد از ارسال اقدام نمایید
    TOO_EARLY = -5
    # آی پی موقتا بلاک شده است
    IP_BLOCKED = -6
    # ApiKey نامعتبر
    INVALID_API_KEY = -7


class SmsDeliveryStatus(IntEnum):
    """وضعیت تحویل پیامک"""
    
    # نامشخص
    NONE = -10
    # ارسال شده به مخابرات
    SENT_TO_TELECOM = 0
    # رسیده به گوشی
    DELIVERED = 1
    # نرسیده به گوشی
    NOT_DELIVERED = 2
    # خطای مخابراتی
    SMS_FAILED = 3
    # خطای نامشخص
    UNKNOWN_ERROR = 4
    # رسیده به مخابرات
    RECEIVED_BY_TELECOM = 5
    # نرسیده به مخابرات
    NOT_RECEIVED_BY_TELECOM = 6
    # مسدود شده توسط مقصد
    BLACK_LISTED = 7
    # نامشخص
    UNKNOWN = 8
    # مخابرات پیام را مردود اعلام کرد
    REJECTED_BY_TELECOM = 9
    # کنسل شده توسط اپراتور
    CANCELED = 10
    # ارسال نشده
    NOT_SENT = 11
    # تلگرام ندارد
    NO_TELEGRAM = 12
    # در صف ارسال
    IN_QUEUE = 13


class CreditResultCode(IntEnum):
    """کدهای نتیجه اعتبار"""
    
    # موفق
    SUCCESS = 0
    # نام کاربری و رمز عبور صحیح نمی باشد
    INVALID_CREDENTIALS = -1
    # کاربر غیرفعال می باشد
    USER_DISABLED = -2
    # آی پی موقتا بلاک شده است
    IP_BLOCKED = -6
    # ApiKey نامعتبر
    INVALID_API_KEY = -7


class SenderNumbersResultCode(IntEnum):
    """کدهای نتیجه شماره های ارسال کننده"""
    
    # موفق
    SUCCESS = 0
    # نام کاربری و رمز عبور صحیح نمی باشد
    INVALID_CREDENTIALS = -1
    # کاربر غیرفعال می باشد
    USER_DISABLED = -2
    # آی پی موقتا بلاک شده است
    IP_BLOCKED = -6
    # ApiKey نامعتبر
    INVALID_API_KEY = -7


class BlacklistResultCode(IntEnum):
    """کدهای نتیجه استخراج شماره‌های لیست سیاه"""
    
    # عملیات با موفقیت انجام شد
    SUCCESS = 0
    # نام کاربری و رمز عبور صحیح نمی باشد
    INVALID_CREDENTIALS = -1
    # کاربر غیرفعال می باشد
    USER_DISABLED = -2
    # آرایه شماره های همراه خالی می باشد
    EMPTY_NUMBERS_ARRAY = -3
    # تعداد شماره ها حداکثر 1000 شماره می باشد
    MAX_NUMBERS_EXCEEDED = -4
    # آی پی موقتا بلاک شده است
    IP_BLOCKED = -6
    # ApiKey نامعتبر
    INVALID_API_KEY = -7


class CheckContentResultCode(IntEnum):
    """کدهای نتیجه بررسی محتوای پیامک"""
    
    # موفق
    SUCCESS = 0
    # نام کاربری و رمز عبور صحیح نمی باشد
    INVALID_CREDENTIALS = -1
    # کاربر غیرفعال می باشد
    USER_DISABLED = -2
    # آی پی موقتا بلاک شده است
    IP_BLOCKED = -6
    # ApiKey نامعتبر
    INVALID_API_KEY = -7


class InboxCountResultCode(IntEnum):
    """کدهای نتیجه تعداد پیامک های دریافتی"""
    
    # موفق
    SUCCESS = 0
    # نام کاربری و رمز عبور صحیح نمی باشد
    INVALID_CREDENTIALS = -1
    # کاربر غیرفعال می باشد
    USER_DISABLED = -2
    # آی پی موقتا بلاک شده است
    IP_BLOCKED = -6
    # ApiKey نامعتبر
    INVALID_API_KEY = -7


class SmsLangType(IntEnum):
    """زبان پیامک"""
    
    # نامشخص
    NONE = -10
    # فارسی
    FA = 1
    # انگلیسی
    EN = 2


class SmsStatusType(IntEnum):
    """وضعیت پیامک"""
    
    # نامشخص
    NONE = -10
    # منتظر تایید
    PENDING = 1
    # غیر مجاز
    ILLEGAL = 2
    # در حال ارسال
    SENDING = 3
    # تایید نشده
    NOT_APPROVED = 4
    # ارسال شده
    SENT = 5
    # انصراف
    CANCELED = 6
    # توقف ارسال
    ERROR = 7
    # مبلغ شارژ جهت ارسال کافی نیست
    NO_CREDIT = 8
    # ارسال نشده
    NOT_SENT = 9
    # منتظر ارسال
    WAIT_FOR_SEND = 10
    # در حال کسر هزینه
    PENDING_DEC_COST = 11
    # در صف منتظر ارسال
    IN_QUEUE = 12
    # در حال کسر هزینه چند به چند
    MANY_TO_MANY_CALC_COST = 13


class SmsSendStatusType(IntEnum):
    """وضعیت ارسال پیامک"""
    
    # نامشخص
    NONE = -10
    # ارسال شده
    SENT = 1
    # خطای مخابراتی
    ERROR = 2
    # خط مقصد دریافت از خطوط پیامک را مسدود کرده است
    BLOCK_LIST = 3


class SmsSendMethodType(IntEnum):
    """روش ارسال"""
    
    # نامشخص
    NONE = -10
    # سریع
    QUICK = 1
    # تست
    TEST = 2
    # منطقه ای
    REGIONAL = 3
    # گروهی
    GROUP = 4
    # وب سرویس
    WEB_SERVICE = 5
    # اطلاع رسانی
    ANNOUNCEMENT = 6
    # منشی
    SECRETARY = 7
    # ارسال هوشمند
    INTELLIGENT_SEND = 8
    # ارسال متناظر
    CORRESPONDING_SEND = 9
    # کد خوان
    CODE_READER = 10
    # نظرسنجی
    POLL = 11
    # انتقال پیامک
    TRANSFER = 12
    # پاسخ
    REPLY = 13
    # ارسال از دفتر تلفن
    PHONE_BOOK = 14
    # ارسال کد پستی
    POSTAL_CODE = 15
    # پیامک مناسبت
    SMS_EVENT = 16
    # منشی هوشمند
    INTELLIGENT_SECRETARY = 17
    # اضافه به لیست
    ADD_TO_PHONE_BOOK = 18
    # پیامک فوری
    INSTANT_SMS = 19
    # پیامک زماندار
    SCHEDULE_SMS = 20
    # پیامک سررسید
    USANCE_SMS = 21
    # سن و جنسیت
    AGE_AND_GENDER = 22
    # سیستمی
    SYSTEM = 23
    # ارسال تولد
    BIRTHDAY_SMS = 24
    # کیوسک
    KIOSK_SMS = 25
    # لغو 11
    CANCELLATION_BY_11 = 26


class SmsDirectionType(IntEnum):
    """نوع مسیر پیامک"""
    
    # نامشخص
    NONE = -10
    # دریافتی
    IN = 1
    # ارسالی
    OUT = 2
    # زماندار
    SCHEDULE = 3
    # سررسید
    USANCE = 4
