"""
مدل‌های نتیجه API پیامکی نیازپرداز
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional
from .enums import (
    SendResultCode, DeliveryResultCode, SmsDeliveryStatus,
    CreditResultCode, SenderNumbersResultCode, BlacklistResultCode,
    CheckContentResultCode, InboxCountResultCode,
    SmsLangType, SmsStatusType, SmsSendStatusType, SmsSendMethodType, SmsDirectionType
)


@dataclass
class SendBatchSmsResult:
    """نتیجه ارسال پیامک گروهی"""
    batch_sms_id: int = 0
    result_code: SendResultCode = SendResultCode.SEND_WAS_SUCCESSFUL
    
    @classmethod
    def from_dict(cls, data: dict) -> 'SendBatchSmsResult':
        return cls(
            batch_sms_id=data.get('batchSmsId', 0),
            result_code=SendResultCode(data.get('resultCode', 0))
        )


@dataclass
class SendLikeToLikeResult:
    """نتیجه ارسال پیامک LikeToLike"""
    sms_id: int = 0
    result_code: SendResultCode = SendResultCode.SEND_WAS_SUCCESSFUL
    
    @classmethod
    def from_dict(cls, data: dict) -> 'SendLikeToLikeResult':
        return cls(
            sms_id=data.get('smsId', 0),
            result_code=SendResultCode(data.get('resultCode', 0))
        )


@dataclass
class BatchDeliveryResult:
    """نتیجه گزارش تحویل"""
    result_code: DeliveryResultCode = DeliveryResultCode.SUCCESS
    numbers: List[str] = field(default_factory=list)
    delivery_status: List[SmsDeliveryStatus] = field(default_factory=list)
    
    @classmethod
    def from_dict(cls, data: dict) -> 'BatchDeliveryResult':
        numbers = data.get('numbers', []) or []
        delivery_status_raw = data.get('deliveryStatus', []) or []
        delivery_status = [SmsDeliveryStatus(s) for s in delivery_status_raw]
        
        return cls(
            result_code=DeliveryResultCode(data.get('resultCode', 0)),
            numbers=numbers,
            delivery_status=delivery_status
        )


@dataclass
class CreditResult:
    """نتیجه دریافت اعتبار"""
    credit: float = 0.0
    result_code: CreditResultCode = CreditResultCode.SUCCESS
    
    @classmethod
    def from_dict(cls, data: dict) -> 'CreditResult':
        return cls(
            credit=float(data.get('credit', 0)),
            result_code=CreditResultCode(data.get('resultCode', 0))
        )


@dataclass
class SenderNumbersResult:
    """نتیجه دریافت شماره‌های ارسال‌کننده"""
    senders: List[str] = field(default_factory=list)
    result_code: SenderNumbersResultCode = SenderNumbersResultCode.SUCCESS
    
    @classmethod
    def from_dict(cls, data: dict) -> 'SenderNumbersResult':
        return cls(
            senders=data.get('senders', []) or [],
            result_code=SenderNumbersResultCode(data.get('resultCode', 0))
        )


@dataclass
class BlacklistNumbersResult:
    """نتیجه استخراج شماره‌های لیست سیاه"""
    black_list_numbers: List[str] = field(default_factory=list)
    result_code: BlacklistResultCode = BlacklistResultCode.SUCCESS
    
    @classmethod
    def from_dict(cls, data: dict) -> 'BlacklistNumbersResult':
        return cls(
            black_list_numbers=data.get('blackListNumbers', []) or [],
            result_code=BlacklistResultCode(data.get('resultCode', 0))
        )


@dataclass
class IsBlacklistResult:
    """نتیجه بررسی شماره در لیست سیاه"""
    is_black: bool = False
    result_code: BlacklistResultCode = BlacklistResultCode.SUCCESS
    
    @classmethod
    def from_dict(cls, data: dict) -> 'IsBlacklistResult':
        return cls(
            is_black=data.get('isBlack', False),
            result_code=BlacklistResultCode(data.get('resultCode', 0))
        )


@dataclass
class CheckContentResult:
    """نتیجه بررسی محتوای پیامک"""
    is_valid: bool = False
    result_code: CheckContentResultCode = CheckContentResultCode.SUCCESS
    
    @classmethod
    def from_dict(cls, data: dict) -> 'CheckContentResult':
        return cls(
            is_valid=data.get('isValid', False),
            result_code=CheckContentResultCode(data.get('resultCode', 0))
        )


@dataclass
class InboxCountResult:
    """نتیجه دریافت تعداد پیامک‌های دریافتی"""
    inbox_count: int = 0
    result_code: InboxCountResultCode = InboxCountResultCode.SUCCESS
    
    @classmethod
    def from_dict(cls, data: dict) -> 'InboxCountResult':
        return cls(
            inbox_count=data.get('inboxCount', 0),
            result_code=InboxCountResultCode(data.get('resultCode', 0))
        )


@dataclass
class MessageInfo:
    """اطلاعات پیامک"""
    message_id: int = 0
    user_id: int = 0
    tariff: float = 0.0
    content: str = ""
    action_date_time: Optional[datetime] = None
    message_type: SmsDirectionType = SmsDirectionType.NONE
    sender: str = ""
    receiver: str = ""
    flash: bool = False
    pages: int = 0
    lang: SmsLangType = SmsLangType.NONE
    status: SmsStatusType = SmsStatusType.NONE
    send_status: SmsSendStatusType = SmsSendStatusType.NONE
    send_method: SmsSendMethodType = SmsSendMethodType.NONE
    cost: float = 0.0
    title: str = ""
    count: int = 0
    sent: int = 0
    desc: str = ""
    not_sent: int = 0
    money_is_refunded: bool = False
    is_read: bool = False
    
    @classmethod
    def from_dict(cls, data: dict) -> 'MessageInfo':
        action_date_time = None
        if data.get('actionDateTime'):
            try:
                action_date_time = datetime.fromisoformat(
                    data['actionDateTime'].replace('Z', '+00:00')
                )
            except (ValueError, AttributeError):
                pass
        
        return cls(
            message_id=data.get('messageId', 0),
            user_id=data.get('userId', 0),
            tariff=float(data.get('tariff', 0)),
            content=data.get('content', ''),
            action_date_time=action_date_time,
            message_type=SmsDirectionType(data.get('messageType', -10)),
            sender=data.get('sender', ''),
            receiver=data.get('receiver', ''),
            flash=data.get('flash', False),
            pages=data.get('pages', 0),
            lang=SmsLangType(data.get('lang', -10)),
            status=SmsStatusType(data.get('status', -10)),
            send_status=SmsSendStatusType(data.get('sendStatus', -10)),
            send_method=SmsSendMethodType(data.get('sendMethod', -10)),
            cost=float(data.get('cost', 0)),
            title=data.get('title', ''),
            count=data.get('count', 0),
            sent=data.get('sent', 0),
            desc=data.get('desc', ''),
            not_sent=data.get('notSent', 0),
            money_is_refunded=data.get('moneyIsRefunded', False),
            is_read=data.get('isRead', False)
        )


@dataclass
class MessagesResult:
    """نتیجه دریافت پیامک‌ها"""
    messages: List[MessageInfo] = field(default_factory=list)
    result_code: int = 0
    
    @classmethod
    def from_dict(cls, data: dict) -> 'MessagesResult':
        messages_raw = data.get('messages', []) or []
        messages = [MessageInfo.from_dict(m) for m in messages_raw]
        
        return cls(
            messages=messages,
            result_code=data.get('resultCode', 0)
        )
