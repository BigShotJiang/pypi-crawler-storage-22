"""
Setup script for NiazpardazSms SDK
"""
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="niazpardazSms",
    version="1.0.2",
    author="Niazpardaz",
    description="کتابخانه رسمی پایتون برای کار با پنل پیامکی نیازپرداز",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/NiazpardazSms/niazpardaz-sms-python",
    project_urls={
        "Bug Tracker": "https://github.com/NiazpardazSms/niazpardaz-sms-python/issues",
        "Documentation": "https://niazpardaz-sms.com/webservice",
    },
    packages=find_packages(exclude=["tests", "tests.*", "examples", "examples.*"]),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Communications :: Telephony",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.7",
    install_requires=[],
    extras_require={
        "async": ["aiohttp>=3.8.0"],
        "httpx": ["httpx>=0.24.0"],
        "all": ["aiohttp>=3.8.0", "httpx>=0.24.0"],
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "aiohttp>=3.8.0",
            "httpx>=0.24.0",
        ],
    },
    keywords=[
        "sms",
        "niazpardaz",
        "پیامک",
        "نیازپرداز",
        "api",
        "sdk",
        "iran",
        "persian",
    ],
)
