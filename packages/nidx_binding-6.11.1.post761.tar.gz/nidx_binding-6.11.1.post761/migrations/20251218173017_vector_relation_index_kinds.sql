ALTER TYPE index_kind ADD VALUE 'vector_relation_node';
ALTER TYPE index_kind ADD VALUE 'vector_relation_edge';
