# emacs: -*- mode: python; py-indent-offset: 4; indent-tabs-mode: nil -*-
# vi: set ft=python sts=4 ts=4 sw=4 et:
#
# Copyright The NiPreps Developers <nipreps@gmail.com>
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# We support and encourage derived works from this project, please read
# about our expectations at
#
#     https://www.nipreps.org/community/licensing/
#
"""Models for nuclear imaging."""

from abc import ABC, ABCMeta, abstractmethod
from os import cpu_count
from typing import Union

import nibabel as nb
import numpy as np
from joblib import Parallel, delayed
from nibabel.processing import smooth_image
from scipy.interpolate import BSpline
from scipy.sparse.linalg import cg

from nifreeze.data.pet import PET
from nifreeze.model.base import BaseModel

PET_OBJECT_ERROR_MSG = "Dataset MUST be a PET object."
"""PET object error message."""

PET_MIDFRAME_ERROR_MSG = "Dataset MUST have a 'midframe'."
"""PET midframe error message."""

DEFAULT_TIMEPOINT_TOL = 1e-2
"""Time frame tolerance in seconds."""

START_INDEX_RANGE_ERROR_MSG = """\
'start_index' must be within the range of the dataset 'midframe' length."""
"""PET model fitting start index allowed values error."""


def _exec_fit(model, data, chunk=None, **kwargs):
    return model.fit(data, **kwargs), chunk


def _exec_predict(model, chunk=None, **kwargs):
    """Propagate model parameters and call predict."""
    return np.squeeze(model.predict(**kwargs)), chunk


class BasePETModel(BaseModel, ABC):
    """Interface and default methods for PET models."""

    __metaclass__ = ABCMeta

    __slots__ = {
        "_data_mask": "A mask for the voxels that will be fitted and predicted",
        "_start_index": "Start index frame for fitting",
        "_smooth_fwhm": "FWHM in mm over which to smooth",
        "_thresh_pct": "Thresholding percentile for the signal",
        "_model_class": "Defining a model class",
        "_modelargs": "Arguments acceptable by the underlying model",
        "_models": "List with one or more (if parallel execution) model instances",
    }

    def __init__(
        self,
        dataset: PET,
        start_index: int | None = None,
        smooth_fwhm: float = 10.0,
        thresh_pct: float = 20.0,
        **kwargs,
    ):
        """Initialization.

        Parameters
        ----------
        start_index : :obj:`int`, optional
            If provided, the model will be fitted using only timepoints starting
            from this index (inclusive). Predictions for timepoints earlier than
            the specified start will reuse the predicted volume for the start
            timepoint. This is useful, for example, to discard a number of
            frames at the beginning of the sequence, which due to their little
            SNR may impact registration negatively.
        smooth_fwhm : obj:`float`, optional
            FWHM in mm over which to smooth the signal.
        thresh_pct : obj:`float`, optional
            Thresholding percentile for the signal.
        """

        super().__init__(dataset, **kwargs)

        # Duck typing, instead of explicitly testing for PET type
        if not hasattr(dataset, "total_duration"):
            raise TypeError(PET_OBJECT_ERROR_MSG)

        if not hasattr(dataset, "midframe"):
            raise ValueError(PET_MIDFRAME_ERROR_MSG)

        self._data_mask = (
            dataset.brainmask
            if dataset.brainmask is not None
            else np.ones(dataset.dataobj.shape[:3], dtype=bool)
        )

        self._smooth_fwhm = smooth_fwhm
        self._thresh_pct = thresh_pct

        # Validate start index / time
        if start_index is None:
            self._start_index = 0
        else:
            if start_index < 0 or start_index >= len(dataset.midframe):
                raise ValueError(START_INDEX_RANGE_ERROR_MSG)
            self._start_index = start_index

    def _preprocess_data(self) -> np.ndarray:
        # ToDo
        # data, _, gtab = self._dataset[idxmask]  ### This needs the PET data model to be changed
        data = self._dataset.dataobj
        brainmask = self._dataset.brainmask

        # Preprocess the data
        if self._smooth_fwhm > 0:
            smoothed_img = smooth_image(
                nb.Nifti1Image(data, self._dataset.affine), self._smooth_fwhm
            )
            data = smoothed_img.get_fdata()

        if self._thresh_pct > 0:
            thresh_val = np.percentile(data, self._thresh_pct)
            data[data < thresh_val] = 0

        # Convert data into V (voxels) x T (timepoints)
        return data.reshape((-1, data.shape[-1])) if brainmask is None else data[brainmask]

    @property
    def is_fitted(self) -> bool:
        return self._locked_fit is not None

    @abstractmethod
    def fit_predict(self, index: int | None = None, **kwargs) -> Union[np.ndarray, None]:
        """Predict the corrected volume."""
        return None


class BSplinePETModel(BasePETModel):
    """A PET imaging realignment model based on B-Spline approximation."""

    __slots__ = (
        "_t",
        "_order",
        "_n_ctrl",
    )

    def __init__(
        self,
        dataset: PET,
        n_ctrl: int | None = None,
        order: int = 3,
        **kwargs,
    ):
        """Create the B-Spline interpolating matrix.

        Parameters
        ----------
        n_ctrl : :obj:`int`, optional
            Number of B-Spline control points. If :obj:`None`, then one control
            point every six timepoints will be used. The less control points,
            the smoother is the model.
        order : :obj:`int`, optional
            Order of the B-Spline approximation.
        """

        super().__init__(dataset, **kwargs)

        self._order = order

        # Calculate index coordinates in the B-Spline grid
        self._n_ctrl = n_ctrl or (len(self._dataset.midframe) // 4) + 1

        # B-Spline knots
        self._t = np.arange(-3, self._n_ctrl + 4, dtype="float32")

    def _fit(self, index: int | None = None, n_jobs=None, **kwargs) -> int:
        """Fit the model."""

        n_jobs = n_jobs or min(cpu_count() or 1, 8)

        if self._locked_fit is not None:
            return n_jobs

        if index is not None:
            raise NotImplementedError("Fitting with held-out data is not supported")

        data = self._preprocess_data()

        timepoints_to_fit = np.asarray(self._dataset.midframe, dtype="float32")[
            self._start_index :
        ]
        x = (
            np.asarray(timepoints_to_fit, dtype="float32")
            / self._dataset.total_duration
            * self._n_ctrl
        )

        # If fitting started later than the first frame, drop early columns so the
        # temporal length matches timepoints_to_fit
        if self._start_index > 0:
            data = data[:, self._start_index :]

        # A.shape = (T, K - 4); T= n. timepoints, K= n. knots (with padding)
        A = BSpline.design_matrix(x, self._t, k=self._order)
        AT = A.T
        ATdotA = AT @ A

        # Parallelize process with joblib
        with Parallel(n_jobs=n_jobs) as executor:
            results = executor(delayed(cg)(ATdotA, AT @ v) for v in data)

        self._locked_fit = np.asarray([r[0] for r in results])

        return n_jobs

    def fit_predict(self, index: int | None = None, **kwargs) -> Union[np.ndarray, None]:
        """Return the corrected volume using B-spline interpolation.

        Predictions for times earlier than the configured start time will return
        the prediction for the start time.
        """

        # ToDo
        # Does the below apply to PET ? Martin has the return None statement
        # if index is None:
        #    raise RuntimeError(
        #        f"Model {self.__class__.__name__} does not allow locking.")

        # Fit the BSpline basis on all data
        if self._locked_fit is None:
            self._fit(index, n_jobs=kwargs.pop("n_jobs", None), **kwargs)

        # Make type checking happy by preventing it to signal that None has no
        # attribute T: after this point, _locked_fit should no longer be None
        assert self._locked_fit is not None, "Internal error: _locked_fit has not been set"

        if index is None:  # If no index, just fit the data.
            return None

        # If the requested time is earlier than the configured start time, use the
        # start time's prediction (reuse the transforms estimated for start)
        midframe = (
            self._dataset.midframe[self._start_index]
            if index < self._start_index
            else self._dataset.midframe[index]
        )

        # Project sample timing into B-Spline coordinates
        # ToDo: x is not really a matrix ...
        x = np.asarray((midframe / self._dataset.total_duration) * self._n_ctrl)
        A = BSpline.design_matrix(x, self._t, k=self._order)

        # A is 1 (num. timepoints) x C (num. coeff)
        # self._locked_fit is V (num. voxels) x K - 4
        predicted = np.squeeze(A @ self._locked_fit.T)

        brainmask = self._dataset.brainmask
        datashape = self._dataset.dataobj.shape[:3]

        if brainmask is None:
            return predicted.reshape(datashape)

        retval = np.zeros_like(self._dataset.dataobj[..., 0])
        retval[brainmask] = predicted
        return retval
