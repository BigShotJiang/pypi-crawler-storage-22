from setuptools import setup, find_packages

setup(
    name="niklibrary",
    version="0.54",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        '': ['*.sh', '*.yml'],
        'NikGapps.helper': ['assets/*'],
        'NikGapps.helper.assets': ['*'],
    },
    author="Nikhil Menghani",
    author_email="nikhil@menghani.com",
    description="A short description of your project",
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url="https://github.com/nikhilmenghani/niklibrary",
    install_requires=[
        'colorama~=0.4.6',
        'pytz~=2025.2',
        'setuptools~=80.9.0',
        'nikassets~=0.14',
        'GitPython~=3.1.45',
        'PyGithub~=2.8.1',
        'python-gitlab~=7.0.0',
        'beautifulsoup4==4.14.3',
        'requests~=2.32.5',
        'python-dotenv~=1.2.1',
        'pexpect~=4.9.0',
        'psutil~=7.1.3',
        'cryptography~=46.0.3',
        'paramiko~=4.0.0'
    ],
    entry_points={
        'console_scripts': [
            'niklibrary=main:main',
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    python_requires='>=3.12',
)