# Changelog

## 0.7.0 (2026-02-09)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/Nimbleway/webit-client-python/compare/v0.6.0...v0.7.0)

### Features

* **api:** api update ([ea419a6](https://github.com/Nimbleway/webit-client-python/commit/ea419a6961595418d443f361f30d0cf1b97b5644))
* **api:** manual updates ([d8d33f1](https://github.com/Nimbleway/webit-client-python/commit/d8d33f11ecc9e9aa514733c2b32d14f26276fc80))

## 0.6.0 (2026-02-09)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/Nimbleway/webit-client-python/compare/v0.5.0...v0.6.0)

### Features

* **api:** api update ([abea9f7](https://github.com/Nimbleway/webit-client-python/commit/abea9f7174d07a4324f1c69e77e1300785b92824))
* **api:** api update ([e85e275](https://github.com/Nimbleway/webit-client-python/commit/e85e275458d431a3e329c5899f7962ad8d1ff3e7))

## 0.5.0 (2026-02-08)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/Nimbleway/webit-client-python/compare/v0.4.0...v0.5.0)

### Features

* **api:** Add API v2 ([15ef817](https://github.com/Nimbleway/webit-client-python/commit/15ef8171228fb4a71716d1be09f90eab0a306e7c))
* **api:** Rename to agent ([969c259](https://github.com/Nimbleway/webit-client-python/commit/969c2594f012ed8cfeec8b83bde003e7cd1b418e))

## 0.4.0 (2026-02-08)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/Nimbleway/webit-client-python/compare/v0.3.0...v0.4.0)

### Features

* **api:** Agents ([166f535](https://github.com/Nimbleway/webit-client-python/commit/166f5359a3e867588533c68ac3cc4cd6ba46b2e9))

## 0.3.0 (2026-02-08)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/Nimbleway/webit-client-python/compare/v0.2.0...v0.3.0)

### Features

* **api:** api update ([ba25eef](https://github.com/Nimbleway/webit-client-python/commit/ba25eef3566999ca886772bbb6d1004b37d6f52c))

## 0.2.0 (2026-02-05)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/Nimbleway/webit-client-python/compare/v0.1.0...v0.2.0)

### Features

* **api:** api update ([4d2862f](https://github.com/Nimbleway/webit-client-python/commit/4d2862f53961dc496b9558f6d15c5c536e89586b))
* **api:** manual updates ([df2dfd7](https://github.com/Nimbleway/webit-client-python/commit/df2dfd74a2cabce6af8f7cfdcba89094db0f206e))
* **api:** manual updates ([9e3ba40](https://github.com/Nimbleway/webit-client-python/commit/9e3ba407da0a09725ab0beee872f6c08762524c6))
* **api:** manual updates ([1dc368f](https://github.com/Nimbleway/webit-client-python/commit/1dc368fec9327e88c086cc60c7f92d656b4928d6))

## 0.1.0 (2026-02-05)

Full Changelog: [v0.0.3...v0.1.0](https://github.com/Nimbleway/webit-client-python/compare/v0.0.3...v0.1.0)

### Features

* **api:** api update ([9aae40a](https://github.com/Nimbleway/webit-client-python/commit/9aae40affc9d69a8897530a17e76d52ac946f991))
* **api:** api update ([f6e244b](https://github.com/Nimbleway/webit-client-python/commit/f6e244b0fbc031ec43c212cf24d96a71b49bce25))
* **api:** api update ([6219961](https://github.com/Nimbleway/webit-client-python/commit/6219961ee4f739be035580c9be9f45982f1e6fcc))
* **api:** manual updates ([38d4936](https://github.com/Nimbleway/webit-client-python/commit/38d493651cea8ac555fde0f8dd5f846bf0ee2524))
* **api:** manual updates ([e932f3c](https://github.com/Nimbleway/webit-client-python/commit/e932f3c91f42b2a99b30e10513eaa064f2e99950))
* **client:** add custom JSON encoder for extended type support ([ce9c554](https://github.com/Nimbleway/webit-client-python/commit/ce9c55426b83f8f9662d42e6844e20c1987f11b1))


### Bug Fixes

* **docs:** fix mcp installation instructions for remote servers ([2aefb5f](https://github.com/Nimbleway/webit-client-python/commit/2aefb5fdfa702567b35559d8879b382654a9be09))


### Chores

* configure new SDK language ([8fdf5e0](https://github.com/Nimbleway/webit-client-python/commit/8fdf5e05fa09093681de121f3a6c533dd097589f))

## 0.0.3 (2026-01-25)

Full Changelog: [v0.0.2...v0.0.3](https://github.com/Nimbleway/webit-client-python/compare/v0.0.2...v0.0.3)

### Chores

* update SDK settings ([ce39b97](https://github.com/Nimbleway/webit-client-python/commit/ce39b9788fd6c73153673e36d746251047a5b861))

## 0.0.2 (2026-01-25)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/Nimbleway/webit-client-python/compare/v0.0.1...v0.0.2)

### Chores

* sync repo ([6d4a89f](https://github.com/Nimbleway/webit-client-python/commit/6d4a89f992596917e48a013ba26c74cd9acd6816))
* update SDK settings ([096924f](https://github.com/Nimbleway/webit-client-python/commit/096924f1c75e6f842c600205268c770dd5fc7e66))
* update SDK settings ([9773ffb](https://github.com/Nimbleway/webit-client-python/commit/9773ffb34b7930bed8944c9733fe758fe388db86))
