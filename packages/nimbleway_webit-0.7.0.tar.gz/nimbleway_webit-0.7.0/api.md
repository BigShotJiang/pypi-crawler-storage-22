# V2

Types:

```python
from nimbleway_webit.types import V2ExtractResponse, V2MapResponse
```

Methods:

- <code title="post /extract">client.v2.<a href="./src/nimbleway_webit/resources/v2/v2.py">extract</a>(\*\*<a href="src/nimbleway_webit/types/v2_extract_params.py">params</a>) -> <a href="./src/nimbleway_webit/types/v2_extract_response.py">V2ExtractResponse</a></code>
- <code title="post /map">client.v2.<a href="./src/nimbleway_webit/resources/v2/v2.py">map</a>(\*\*<a href="src/nimbleway_webit/types/v2_map_params.py">params</a>) -> <a href="./src/nimbleway_webit/types/v2_map_response.py">V2MapResponse</a></code>

## Crawl

Types:

```python
from nimbleway_webit.types.v2 import (
    CrawlListResponse,
    CrawlCancelResponse,
    CrawlCrawlResponse,
    CrawlGetResponse,
)
```

Methods:

- <code title="get /crawl">client.v2.crawl.<a href="./src/nimbleway_webit/resources/v2/crawl.py">list</a>(\*\*<a href="src/nimbleway_webit/types/v2/crawl_list_params.py">params</a>) -> <a href="./src/nimbleway_webit/types/v2/crawl_list_response.py">SyncCrawlPagination[CrawlListResponse]</a></code>
- <code title="delete /crawl/{id}">client.v2.crawl.<a href="./src/nimbleway_webit/resources/v2/crawl.py">cancel</a>(id) -> <a href="./src/nimbleway_webit/types/v2/crawl_cancel_response.py">CrawlCancelResponse</a></code>
- <code title="post /crawl">client.v2.crawl.<a href="./src/nimbleway_webit/resources/v2/crawl.py">crawl</a>(\*\*<a href="src/nimbleway_webit/types/v2/crawl_crawl_params.py">params</a>) -> <a href="./src/nimbleway_webit/types/v2/crawl_crawl_response.py">CrawlCrawlResponse</a></code>
- <code title="get /crawl/{id}">client.v2.crawl.<a href="./src/nimbleway_webit/resources/v2/crawl.py">get</a>(id) -> <a href="./src/nimbleway_webit/types/v2/crawl_get_response.py">CrawlGetResponse</a></code>

## Agent

Types:

```python
from nimbleway_webit.types.v2 import AgentAsyncResponse, AgentGetResponse
```

Methods:

- <code title="post /agent/async">client.v2.agent.<a href="./src/nimbleway_webit/resources/v2/agent.py">async\_</a>(\*\*<a href="src/nimbleway_webit/types/v2/agent_async_params.py">params</a>) -> <a href="./src/nimbleway_webit/types/v2/agent_async_response.py">AgentAsyncResponse</a></code>
- <code title="post /agent">client.v2.agent.<a href="./src/nimbleway_webit/resources/v2/agent.py">get</a>(\*\*<a href="src/nimbleway_webit/types/v2/agent_get_params.py">params</a>) -> <a href="./src/nimbleway_webit/types/v2/agent_get_response.py">AgentGetResponse</a></code>
