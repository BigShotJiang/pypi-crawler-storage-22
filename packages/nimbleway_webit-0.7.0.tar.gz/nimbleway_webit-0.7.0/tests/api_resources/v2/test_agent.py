# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tests.utils import assert_matches_type
from nimbleway_webit import Nimbleway, AsyncNimbleway
from nimbleway_webit.types.v2 import AgentGetResponse, AgentAsyncResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestAgent:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_async_overload_1(self, client: Nimbleway) -> None:
        agent = client.v2.agent.async_(
            params={"foo": "bar"},
            template="template",
        )
        assert_matches_type(AgentAsyncResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_async_with_all_params_overload_1(self, client: Nimbleway) -> None:
        agent = client.v2.agent.async_(
            params={"foo": "bar"},
            template="template",
            localization=True,
        )
        assert_matches_type(AgentAsyncResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_async_overload_1(self, client: Nimbleway) -> None:
        response = client.v2.agent.with_raw_response.async_(
            params={"foo": "bar"},
            template="template",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(AgentAsyncResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_async_overload_1(self, client: Nimbleway) -> None:
        with client.v2.agent.with_streaming_response.async_(
            params={"foo": "bar"},
            template="template",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(AgentAsyncResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_async_overload_2(self, client: Nimbleway) -> None:
        agent = client.v2.agent.async_(
            agent="agent",
            params={"foo": "bar"},
        )
        assert_matches_type(AgentAsyncResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_async_with_all_params_overload_2(self, client: Nimbleway) -> None:
        agent = client.v2.agent.async_(
            agent="agent",
            params={"foo": "bar"},
            localization=True,
        )
        assert_matches_type(AgentAsyncResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_async_overload_2(self, client: Nimbleway) -> None:
        response = client.v2.agent.with_raw_response.async_(
            agent="agent",
            params={"foo": "bar"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(AgentAsyncResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_async_overload_2(self, client: Nimbleway) -> None:
        with client.v2.agent.with_streaming_response.async_(
            agent="agent",
            params={"foo": "bar"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(AgentAsyncResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_overload_1(self, client: Nimbleway) -> None:
        agent = client.v2.agent.get(
            params={"foo": "bar"},
            template="template",
        )
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_with_all_params_overload_1(self, client: Nimbleway) -> None:
        agent = client.v2.agent.get(
            params={"foo": "bar"},
            template="template",
            localization=True,
        )
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_overload_1(self, client: Nimbleway) -> None:
        response = client.v2.agent.with_raw_response.get(
            params={"foo": "bar"},
            template="template",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_overload_1(self, client: Nimbleway) -> None:
        with client.v2.agent.with_streaming_response.get(
            params={"foo": "bar"},
            template="template",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(AgentGetResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_overload_2(self, client: Nimbleway) -> None:
        agent = client.v2.agent.get(
            agent="agent",
            params={"foo": "bar"},
        )
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_with_all_params_overload_2(self, client: Nimbleway) -> None:
        agent = client.v2.agent.get(
            agent="agent",
            params={"foo": "bar"},
            localization=True,
        )
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_overload_2(self, client: Nimbleway) -> None:
        response = client.v2.agent.with_raw_response.get(
            agent="agent",
            params={"foo": "bar"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = response.parse()
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_overload_2(self, client: Nimbleway) -> None:
        with client.v2.agent.with_streaming_response.get(
            agent="agent",
            params={"foo": "bar"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = response.parse()
            assert_matches_type(AgentGetResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncAgent:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_async_overload_1(self, async_client: AsyncNimbleway) -> None:
        agent = await async_client.v2.agent.async_(
            params={"foo": "bar"},
            template="template",
        )
        assert_matches_type(AgentAsyncResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_async_with_all_params_overload_1(self, async_client: AsyncNimbleway) -> None:
        agent = await async_client.v2.agent.async_(
            params={"foo": "bar"},
            template="template",
            localization=True,
        )
        assert_matches_type(AgentAsyncResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_async_overload_1(self, async_client: AsyncNimbleway) -> None:
        response = await async_client.v2.agent.with_raw_response.async_(
            params={"foo": "bar"},
            template="template",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(AgentAsyncResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_async_overload_1(self, async_client: AsyncNimbleway) -> None:
        async with async_client.v2.agent.with_streaming_response.async_(
            params={"foo": "bar"},
            template="template",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(AgentAsyncResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_async_overload_2(self, async_client: AsyncNimbleway) -> None:
        agent = await async_client.v2.agent.async_(
            agent="agent",
            params={"foo": "bar"},
        )
        assert_matches_type(AgentAsyncResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_async_with_all_params_overload_2(self, async_client: AsyncNimbleway) -> None:
        agent = await async_client.v2.agent.async_(
            agent="agent",
            params={"foo": "bar"},
            localization=True,
        )
        assert_matches_type(AgentAsyncResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_async_overload_2(self, async_client: AsyncNimbleway) -> None:
        response = await async_client.v2.agent.with_raw_response.async_(
            agent="agent",
            params={"foo": "bar"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(AgentAsyncResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_async_overload_2(self, async_client: AsyncNimbleway) -> None:
        async with async_client.v2.agent.with_streaming_response.async_(
            agent="agent",
            params={"foo": "bar"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(AgentAsyncResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_overload_1(self, async_client: AsyncNimbleway) -> None:
        agent = await async_client.v2.agent.get(
            params={"foo": "bar"},
            template="template",
        )
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_with_all_params_overload_1(self, async_client: AsyncNimbleway) -> None:
        agent = await async_client.v2.agent.get(
            params={"foo": "bar"},
            template="template",
            localization=True,
        )
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_overload_1(self, async_client: AsyncNimbleway) -> None:
        response = await async_client.v2.agent.with_raw_response.get(
            params={"foo": "bar"},
            template="template",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_overload_1(self, async_client: AsyncNimbleway) -> None:
        async with async_client.v2.agent.with_streaming_response.get(
            params={"foo": "bar"},
            template="template",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(AgentGetResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_overload_2(self, async_client: AsyncNimbleway) -> None:
        agent = await async_client.v2.agent.get(
            agent="agent",
            params={"foo": "bar"},
        )
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_with_all_params_overload_2(self, async_client: AsyncNimbleway) -> None:
        agent = await async_client.v2.agent.get(
            agent="agent",
            params={"foo": "bar"},
            localization=True,
        )
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_overload_2(self, async_client: AsyncNimbleway) -> None:
        response = await async_client.v2.agent.with_raw_response.get(
            agent="agent",
            params={"foo": "bar"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        agent = await response.parse()
        assert_matches_type(AgentGetResponse, agent, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_overload_2(self, async_client: AsyncNimbleway) -> None:
        async with async_client.v2.agent.with_streaming_response.get(
            agent="agent",
            params={"foo": "bar"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            agent = await response.parse()
            assert_matches_type(AgentGetResponse, agent, path=["response"])

        assert cast(Any, response.is_closed) is True
