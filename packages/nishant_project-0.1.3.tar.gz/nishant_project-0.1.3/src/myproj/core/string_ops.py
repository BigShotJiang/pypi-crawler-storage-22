def upper(text: str) -> str:
    return text.upper()
