def sub(a: int, b: int) -> int: 
    return a - b
