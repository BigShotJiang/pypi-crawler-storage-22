from myproj import add, greet

def main():
    print(add(2, 3))
    print(greet('Nishant'))
