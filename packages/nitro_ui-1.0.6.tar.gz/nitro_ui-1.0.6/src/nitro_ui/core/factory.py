class ElementFactory:
    def __init__(self, string):
        self.string = string

    @staticmethod
    def inflate(self, data: dict):
        return NotImplementedError("Not implemented - future release.")
