"""
Setup file for backwards compatibility with older pip versions.
The actual configuration is in pyproject.toml.
"""

from setuptools import setup

setup()
