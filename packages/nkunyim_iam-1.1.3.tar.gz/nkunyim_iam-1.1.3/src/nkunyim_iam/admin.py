from django.contrib import admin

from nkunyim_iam.models import (
    User,
    Address,
    Logging,
)
from nkunyim_iam.manager import (
    UserAdmin,
    AddressAdmin,
    LoggingAdmin,
)

admin.site.register(User, UserAdmin)
admin.site.register(Address, AddressAdmin)
admin.site.register(Logging, LoggingAdmin)