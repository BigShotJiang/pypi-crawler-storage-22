from nkunyim_iam.commands import LoggingCommand
from nkunyim_iam.datamodel import LoggingLevel, LoggingModel
from nkunyim_iam.models import Logging


class LoggingHandler:

    def _save(self, logging: LoggingModel) -> Logging:
        command = LoggingCommand(data={
            "level": logging.level,
            "message": logging.message,
            "context": logging.context
        })
        return command.create()
    
    def handle(self, logging: LoggingModel) -> None:
        self._save(logging)
        
    def info(self, message: str, context: dict = {}) -> None:
        logging = LoggingModel(level=LoggingLevel.INFO, message=message, context=context)
        self.handle(logging)
    
    def success(self, message: str, context: dict = {}) -> None:
        logging = LoggingModel(level=LoggingLevel.SUCCESS, message=message, context=context)
        self.handle(logging)
        
    def warning(self, message: str, context: dict = {}) -> None:
        logging = LoggingModel(level=LoggingLevel.WARNING, message=message, context=context)
        self.handle(logging)
        
    def danger(self, message: str, context: dict = {}) -> None:
        logging = LoggingModel(level=LoggingLevel.DANGER, message=message, context=context)
        self.handle(logging)
        
        
    