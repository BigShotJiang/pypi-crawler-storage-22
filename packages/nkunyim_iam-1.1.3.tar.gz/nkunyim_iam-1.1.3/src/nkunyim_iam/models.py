from uuid import uuid4
from django.db import models
from django.contrib.auth.models import (
    BaseUserManager,
    AbstractBaseUser,
    PermissionsMixin,
)

from nkunyim_iam.constants import GENDER_CHOICES, LOGGING_LEVEL_CHOICES



class UserManager(BaseUserManager):

    def create_user(self, username, nickname, first_name, last_name, phone_number, email_address, password):
        """
        Creates and saves a User with the username, nickname, phone_number, email_address.
        """
        if not (username and nickname and first_name and last_name and phone_number and email_address and password):
            raise ValueError('Users must have username, nickname, phone_number, email_address')

        user = self.model(
            username=username,
            nickname=nickname,
            first_name=first_name,
            last_name=last_name,
            phone_number=phone_number,
            email_address=self.normalize_email(email_address),
        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, nickname, first_name, last_name, phone_number, email_address, password):
        """
        Creates and saves a superuser with the username, nickname, phone_number, email_address.
        """
        user = self.create_user(
            username=username,
            nickname=nickname,
            first_name=first_name,
            last_name=last_name,
            phone_number=phone_number,
            email_address=email_address,
            password=password,
        )
        user.is_superuser = True
        user.is_admin = True
        user.save(using=self._db)
        return user


class User(AbstractBaseUser, PermissionsMixin):
    id = models.UUIDField(primary_key=True, default=uuid4, editable=False)
    username = models.CharField(
        verbose_name='Username',
        max_length=80,
        blank=False,
        null=False,
        unique=True,
    )
    nickname = models.CharField(
        verbose_name='Nickname',
        max_length=32,
        blank=False,
        null=False,
    )
    first_name = models.CharField(
        verbose_name='First Name',
        max_length=32,
        blank=False,
        null=False,
    )
    middle_name = models.CharField(
        verbose_name='Middle Name',
        max_length=32,
        blank=True,
        null=True,
    )
    last_name = models.CharField(
        verbose_name='Last Name',
        max_length=32,
        blank=False,
        null=False,
    )
    email_address = models.EmailField(
        verbose_name='Email Address',
        max_length=128,
        unique=True,
        blank=False,
        null=False,
    )
    email_verified = models.BooleanField(default=True, blank=False, null=False)
    email_verified_at = models.DateTimeField(blank=True, null=True)
    phone_number = models.CharField(
        verbose_name='Phone Number',
        max_length=32,
        blank=False,
        null=False,
    )
    phone_verified = models.BooleanField(default=True, blank=False, null=False)
    phone_verified_at = models.DateTimeField(blank=True, null=True)
    serial = models.CharField(
        verbose_name='Serial',
        max_length=128,
        blank=True,
        null=True,
    )
    gender = models.CharField(
        verbose_name='Gender',
        max_length=3,
        choices=GENDER_CHOICES,
        default='N',
        blank=False,
        null=False,
    )
    birth_date = models.DateField(blank=True, null=True)
    photo_url = models.URLField(
        verbose_name='Photo URL',
        max_length=128,
        blank=True,
        null=True,
    )
    photo_verified = models.BooleanField(default=False, blank=False, null=False)
    photo_verified_at = models.DateTimeField(blank=True, null=True)
    profile = models.TextField(
        verbose_name='Profile',
        blank=True,
        null=True,
    )
    is_pwd = models.BooleanField(default=False, blank=False, null=False)
    is_active = models.BooleanField(default=True, blank=False, null=False)
    is_admin = models.BooleanField(default=False, blank=False, null=False)
    is_verified = models.BooleanField(default=False, blank=False, null=False)
    is_deleted = models.BooleanField(default=False, blank=False, null=False)
    created_at = models.DateTimeField(auto_now_add=True, blank=False, null=False)
    updated_at = models.DateTimeField(auto_now=True, blank=False, null=False)
    deleted_at = models.DateTimeField(blank=True, null=True)

    objects = UserManager()

    USERNAME_FIELD = 'username'
    EMAIL_FIELD = 'email_address'
    REQUIRED_FIELDS = [
        'nickname',
        'first_name',
        'last_name',
        'email_address',
        'phone_number',
    ]

    class Meta:
        ordering = ["last_name", "first_name", "is_admin", "is_active",]
        verbose_name = "User"
        verbose_name_plural = "Users"

    def __str__(self):
        return self.full_name

    def get_absolute_url(self):
        return "/users/%s/" % self.id

    @property
    def uid(self):
        return self.id

    @property
    def full_name(self):
        family_name = f"{self.middle_name} {self.last_name}" if self.middle_name else self.last_name
        return "%s %s" % (self.first_name, family_name)

    @property
    def is_staff(self):
        """Is the user a member of staff?"""
        # Simplest possible answer: All admins are staff
        return self.is_admin



class Address(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid4, editable=False)
    user = models.ForeignKey(
        User,
        related_name='addresses',
        on_delete=models.CASCADE
    )
    street_address = models.CharField(
        verbose_name='Street Address',
        max_length=128,
        blank=False,
        null=False
    )
    postal_code = models.CharField(
        verbose_name='Postal Code',
        max_length=32,
        blank=False,
        null=False
    )
    locality = models.CharField(
        verbose_name='Locality',
        max_length=128,
        blank=False,
        null=False,
    )
    city = models.CharField(
        verbose_name='City',
        max_length=125,
        blank=False,
        null=False
    )
    nation_code = models.CharField(
        verbose_name='Country Code',
        max_length=32,
        blank=False,
        null=False,
    )
    timezone = models.CharField(
        verbose_name='Timezone',
        max_length=32,
        blank=False,
        null=False
    )
    language = models.CharField(
        verbose_name='Language',
        max_length=5,
        blank=False,
        null=False
    )
    is_primary = models.BooleanField(default=False, blank=False, null=False)
    is_verified = models.BooleanField(default=False, blank=False, null=False)
    is_active = models.BooleanField(default=True, blank=False, null=False)
    is_deleted = models.BooleanField(default=False, blank=False, null=False)
    created_at = models.DateTimeField(auto_now_add=True, blank=False, null=False)
    updated_at = models.DateTimeField(auto_now=True, blank=False, null=False)
    deleted_at = models.DateTimeField(blank=True, null=True)
    
    class Meta:
        ordering = ["nation_code", "user"]
        verbose_name = "User Address"
        verbose_name_plural = "User Addresses"
        
    def __str__(self):
        return "%s %s" % (self.user, self.street_address)
    
    def get_absolute_url(self):
        return "/addresses/%s/" % self.id


class Logging(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid4, editable=False)
    level = models.CharField(
        verbose_name='Level',
        choices=LOGGING_LEVEL_CHOICES,
        default='info',
        max_length=128,
        blank=False,
        null=False,
    )
    message = models.TextField(
        verbose_name='Message',
        blank=False,
        null=False,
    )
    context = models.JSONField(
        verbose_name='Context',
        blank=True,
        null=True,
    )
    created_at = models.DateTimeField(auto_now_add=True, blank=False, null=False)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "Logging"
        verbose_name_plural = "Loggings"

    def __str__(self):
        return f"{self.level}: {self.message[:50]}"

    def get_absolute_url(self):
        return "/loggings/%s/" % self.id