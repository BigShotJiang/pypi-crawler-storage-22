from rest_framework import serializers

from nkunyim_iam.models import (
    Logging,
    User,
    Address,
)




class AddressSerializer(serializers.ModelSerializer):

    class Meta:
        model = Address
        fields = '__all__'


  
class UserSerializer(serializers.ModelSerializer):
    addresses = AddressSerializer(many=True, read_only=True)
    
    class Meta:
        model = User
        fields = [
            "id",
            "last_login",
            "is_superuser",
            "username",
            "nickname",
            "first_name",
            "middle_name",
            "last_name",
            "email_address",
            "email_verified",
            "email_verified_at",
            "phone_number",
            "phone_verified",
            "phone_verified_at",
            "serial",
            "gender",
            "birth_date",
            "photo_url",
            "photo_verified",
            "photo_verified_at",
            "profile",
            "is_pwd",
            "is_active",
            "is_admin",
            "is_verified",
            "is_deleted",
            "created_at",
            "updated_at",
            "deleted_at",
            "groups",
            "user_permissions",
            'addresses',
        ]
      
      
class LoggingSerializer(serializers.ModelSerializer):

    class Meta:
        model = Logging
        fields = '__all__'