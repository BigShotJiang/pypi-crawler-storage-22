from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional, Sequence
from uuid import UUID


VALID_TYPES = {"int", "bool", "str", "uuid", "float", "decimal", "list", "dict"}


def is_uuid(val: str, ver: int = 4) -> bool:
    try:
        return str(UUID(val, version=ver)) == val
    except ValueError:
        return False


def is_decimal(value: Any) -> bool:
    try:
        if isinstance(value, int):
            value = f"{value}.00"
        elif isinstance(value, float):
            value = str(value)

        if not isinstance(value, str):
            return False

        return "." in value and value.count(".") == 1
    except ValueError:
        return False


@dataclass
class SchemaField:
    name: str
    typ: Optional[str]
    req: bool = True
    min: int = 0
    max: int = 0
    len: int = 0
    iss: str = ""
    prop: Optional[dict[str, dict[str, Any]]] = None
    enum: Optional[Sequence[Any]] = None
    error: Optional[str] = None

    def __init__(self, name: str, schema: dict):
        self.name = name
        self.typ = schema.get("typ")
        self.req = schema.get("req", True)
        self.min = schema.get("min", 0)
        self.max = schema.get("max", 0)
        self.len = schema.get("len", 0)
        self.iss = schema.get("iss", f"Field '{name}' is either missing or invalid.")
        self.prop = schema.get("prop")
        self.enum = schema.get("enum")

        if not self.typ or self.typ not in VALID_TYPES:
            self.error = f"Schema field '{name}' has missing/invalid 'type' attribute."
        else:
            self.error = None


class Validation:
    def __init__(self) -> None:
        self.errors: list[dict[str, Any]] = []
        self.is_valid = True

    def _add_validation_error(self, key: str, field: SchemaField, hints: list[str]) -> None:
        self.errors.append(
            {
                "type": "VALIDATION ERROR",
                "field": key,
                "error": field.iss,
                "hints": hints,
            }
        )

    def _add_schema_error(self, key: str, error: str) -> None:
        self.errors.append(
            {
                "type": "SCHEMA ERROR",
                "field": key,
                "error": error,
            }
        )

    def _string_value(self, value: Any) -> str:
        return str(value) if value is not None else ""

    def _validate_constraints(self, key: str, value: Any, field: SchemaField) -> list[str]:
        hints: list[str] = []
        val_str = self._string_value(value)

        if field.req and (value is None or val_str == ""):
            hints.append(f"Field '{key}' is required.")

        if field.min > 0 and len(val_str) < field.min:
            hints.append(f"Field '{key}' must have a minimum length of {field.min}.")

        if 0 < field.max < len(val_str):
            hints.append(f"Field '{key}' must have a maximum length of {field.max}.")

        if field.len > 0 and len(val_str) != field.len:
            hints.append(f"Field '{key}' must be of length {field.len}.")

        return hints

    def _validate_type(self, key: str, value: Any, field: SchemaField) -> list[str]:
        hints: list[str] = []
        val_str = self._string_value(value)

        if field.typ == "decimal":
            if not is_decimal(val_str):
                hints.append(f"Field '{key}' is not a valid decimal.")
        elif field.typ == "uuid":
            if not is_uuid(val_str):
                hints.append(f"Field '{key}' is not a valid UUID.")
        elif value is not None and type(value).__name__ != field.typ:
            hints.append(
                f"Field '{key}' must be of type {field.typ}, {type(value).__name__} provided."
            )

        return hints

    def _validate_enum(self, key: str, value: Any, field: SchemaField) -> list[str]:
        if field.enum and value not in field.enum:
            enum_str = ", ".join(map(str, field.enum))
            return [f"Field '{key}' must be one of [{enum_str}]."]
        return []

    def parse(self, field: SchemaField, key: str, value: Any) -> None:
        hints = []
        hints.extend(self._validate_constraints(key, value, field))
        hints.extend(self._validate_type(key, value, field))
        hints.extend(self._validate_enum(key, value, field))

        if hints:
            self._add_validation_error(key=key, field=field, hints=hints)

    def check(self, schema: dict[str, dict], data: dict) -> None:
        for key, field_schema in schema.items():
            field = SchemaField(name=key, schema=field_schema)

            if field.error:
                self._add_schema_error(key=key, error=field.error)
                continue

            value: Any = data.get(key)

            if field.typ == "dict" and isinstance(value, dict) and field.prop:
                self.check(schema=field.prop, data=value)

            self.parse(field=field, key=key, value=value)

        if self.errors:
            self.is_valid = False
            raise ValueError("Validation failed with errors: " + str(self.errors))
