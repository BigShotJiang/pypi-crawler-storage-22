import logging
from uuid import UUID
from http import HTTPMethod
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import (
    IsAuthenticatedOrReadOnly,
)


from nkunyim_iam.models import (
    Logging,
    User,
    Address,
)

from nkunyim_iam.commands import (
    LoggingCommand,
    UserCommand,
    AddressCommand,
)

from nkunyim_iam.serializers import (
    LoggingSerializer,
    UserSerializer,
    AddressSerializer,
)

logger = logging.getLogger(__name__)




class UserViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticatedOrReadOnly]
    queryset = User.objects.all()
    serializer_class = UserSerializer
    filterset_fields = [
        'gender',
        'is_pwd',
        'is_superuser',
        'is_admin',
        'is_verified',
        'is_active'
    ]
    search_fields = ['first_name', 'last_name', 'username', 'nickname', 'email_address']

    
    @action(detail=False, methods=[HTTPMethod.GET])
    def userinfo(self, request, format=None):
        try:
            logger.info('UserViewSet "userinfo" called')
            pk = request.user.id
            query = User.objects.get(pk=pk)
            data = UserSerializer(query).data
            
            return Response(
                data=data,
                status=status.HTTP_200_OK
            )
        except Exception as ex:
            return Response(data=str(ex),status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    


    def update(self, request, pk=None, format=None):
        try:
            logger.info('UserViewSet "update" called')
            
            command = UserCommand(
                data=request.data
            )

            if not command.is_valid:
                return Response(
                    data=command.errors,
                    status=status.HTTP_400_BAD_REQUEST
                )

            data = command.update(pk=UUID(pk))
            
            return Response(
                data=data,
                status=status.HTTP_200_OK
            )
        except Exception as ex:
            return Response(data=str(ex),status=status.HTTP_500_INTERNAL_SERVER_ERROR)


    def destroy(self, request, pk=None, format=None):
        try:
            logger.info('UserViewSet "destroy" called')
            
            command = UserCommand(
                data=request.data
            )

            data = command.delete(pk=UUID(pk))
            
            return Response(
                data=data,
                status=status.HTTP_200_OK
            )
        except Exception as ex:
            return Response(data=str(ex),status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class AddressViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticatedOrReadOnly]
    queryset = Address.objects.all()
    serializer_class = AddressSerializer
    filterset_fields = [
        'user_id',
        'nation_code',
        'is_primary',
        'is_verified',
        'is_active'
    ]
    search_fields = ['street_address']
  

    def create(self, request, format=None):
        try:
            logger.info('AddressViewSet "create" called')
            
            command = AddressCommand(
                data=request.data
            )
            
            if not command.is_valid:
                return Response(
                    data=command.errors,
                    status=status.HTTP_400_BAD_REQUEST
                )
             
            data = command.create()
            
            return Response(
                data=data,
                status=status.HTTP_200_OK
            )
        except Exception as ex:
            return Response(data=str(ex),status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    

    def update(self, request, pk=None, format=None):
        try:
            logger.info('AddressViewSet "update" called')
            
            command = AddressCommand(
                data=request.data
            )
            if not command.is_valid:
                return Response(
                    data=command.errors,
                    status=status.HTTP_400_BAD_REQUEST
                )

            data = command.update(pk=UUID(pk))
            
            return Response(
                data=data,
                status=status.HTTP_200_OK
            )
        except Exception as ex:
            return Response(data=str(ex),status=status.HTTP_500_INTERNAL_SERVER_ERROR)


    def destroy(self, request, pk=None, format=None):
        try:
            logger.info('AddressViewSet "destroy" called')
            
            command = AddressCommand(
                data=request.data
            )
            
            data = command.delete(pk=UUID(pk))
            
            return Response(
                data=data,
                status=status.HTTP_200_OK
            )
        except Exception as ex:
            return Response(data=str(ex),status=status.HTTP_500_INTERNAL_SERVER_ERROR)



class LoggingViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticatedOrReadOnly]
    queryset = Logging.objects.all()
    serializer_class = LoggingSerializer
    filterset_fields = [
        'level',
    ]
    search_fields = ['message', 'context']
  
    def create(self, request, format=None):
        try:
            logger.info('LoggingViewSet "create" called')
            
            command = LoggingCommand(
                data=request.data
            )
            
            if not command.is_valid:
                return Response(
                    data=command.errors,
                    status=status.HTTP_400_BAD_REQUEST
                )
             
            data = command.create()
            
            return Response(
                data=data,
                status=status.HTTP_200_OK
            )
        except Exception as ex:
            return Response(data=str(ex),status=status.HTTP_500_INTERNAL_SERVER_ERROR)