import random
import requests
import string

from datetime import datetime, timedelta
from typing import Optional
from uuid import uuid4

from django.contrib import auth
from django.http import HttpRequest

from nkunyim_iam.commands import UserCommand
from nkunyim_iam.datamodel import (
    SessionModel,
    TokenModel,
    UserModel,
    IdentityConfigModel,
)
from nkunyim_iam.encryption import Hashing
from nkunyim_iam.handlers import LoggingHandler
from nkunyim_iam.models import User
from nkunyim_iam.signals import token_data_updated, userinfo_data_updated, user_data_updated


class IdentityService:
    """_summary_
    Django OAuth Toolkit
    https://django-oauth-toolkit.readthedocs.io/en/latest/install.html
    """

    def __init__(self, config: IdentityConfigModel, req: HttpRequest) -> None:
        self.req = req
        self.config = config
        self.headers = {
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded",
            "Cache-Control": "no-cache",
        }

        self.key = self.get_session_key()
        self.model: Optional[SessionModel] = None
        self.logging = LoggingHandler()
        
        # Load session data if available - ensure this is done last to capture any logs during initialization
        self.get_session_data()


    def _log_exception(self, message: str, ex: Exception) -> None:
        self.logging.danger(
            message=message,
            context={"exception": str(ex)},
        )

    def _post(self, path: str, data: Optional[dict] = None) -> Optional[requests.Response]:
        token = self.get_access_token()
        if token:
            self.headers["Authorization"] = "JWT " + token
        
        response = requests.post(
            url=self.config.back_url + path,
            data=data,
            headers=self.headers,
        )
        if not response.ok:
            self.logging.danger(
                message="Failed to retrieve data from API at " + self.config.back_url + path,
                context={
                    "status_code": response.status_code,
                    "response": response.text,
                    "reason": response.reason,
                    "method": "POST",
                    "headers": str(self.headers),
                    "data": str(data),
                },
            )
            return None
        return response
    
    def _get(self, path: str) -> Optional[requests.Response]:
        token = self.get_access_token()
        if token:
            self.headers["Authorization"] = "Bearer " + token
        
        response = requests.get(
            url=self.config.back_url + path,
            headers=self.headers,
        )
        if not response.ok:
            self.logging.danger(
                message="Failed to retrieve data from API at " + self.config.back_url + path,
                context={
                    "status_code": response.status_code,
                    "response": response.text,
                    "reason": response.reason,
                    "method": "GET",
                    "headers": str(self.headers),
                },
            )
            return None
        return response

    def get_session_key(self) -> str:
        parts = self.req.get_host().lower().split(".")
        if len(parts) < 2:
            key = "www.localhost"
        else:
            domain = ".".join(parts[-2:])
            subdomain = parts[-3] if len(parts) > 2 else "www"
            key = f"{subdomain}.{domain}"

        return f"oauth2.{key}"


    def set_session_data(self) -> None:
        if self.model:
            self.req.session[self.key] = self.model.model_dump()
            self.req.session.modified = True


    def get_session_data(self) -> None:
        if bool(self.key in self.req.session and self.req.session[self.key]):
            session = self.req.session[self.key]
            self.model = SessionModel(**session)


    def get_authorization_url(self) -> str:
        state = str(uuid4())
        nonce = uuid4().hex
        next = self.req.GET.get("next", "/home/")
        code_verifier = "".join(
            random.choice(string.ascii_uppercase + string.digits)
            for _ in range(random.randint(43, 128))
        )
        self.model = SessionModel(
            next=next,
            state=state,
            nonce=nonce,
            code="",
            verifier=code_verifier,
            token=None,
        )
        self.set_session_data()

        code_challenge = Hashing(input_string=code_verifier).make(
            algo=self.config.hash_algo
        )

        authorize_url = (
            f"{self.config.front_url}{self.config.authorize_path}?"
            + f"response_type={self.config.response_type}&"
            + f"client_id={self.config.client_id}&"
            + f"redirect_uri={self.config.redirect_uri}&"
            + f"scope={self.config.client_scope}&"
            + f"state={state}&"
            + f"nonce={nonce}&"
            + f"code_challenge={code_challenge}&"
            + f"code_challenge_method={self.config.hash_algo.value}"
        )

        return authorize_url


    def process_token(self, token_data: dict) -> Optional[TokenModel]:
        try:
            self.get_session_data()
            if not self.model:
                return None

            # Calculate token expiration time
            expires_in = int(token_data.get("expires_in", 300))
            token_data["expires_at"] = datetime.now() + timedelta(
                seconds=expires_in
            )
            
            token_model = TokenModel(**token_data)

            self.model.token = token_model
            self.set_session_data()

            # Inform interested parties
            token_data_updated.send(sender=TokenModel, instance=token_model)

            return token_model
        except Exception as ex:
            self._log_exception("Failed to process token data from API.", ex)
            return None


    def authorize_access_token(self) -> Optional[TokenModel]:
        try:
            self.get_session_data()
            if not self.model:
                return None

            code = self.req.GET.get("code", "")
            state = self.req.GET.get("state", None)

            if not bool(state and self.model.state == state):
                self.logging.danger(
                    message="OAuth2 state mismatch.",
                )
                return None

            error = self.req.GET.get("error", None)
            error_description = self.req.GET.get("error_description", None)
            if bool(error):
                self.logging.danger(
                    message="OAuth2 authorization failed.",
                    context={"error": error, "error_description": error_description},
                )
                return None

            self.model.code = code
            self.set_session_data()

            data = {
                "client_id": self.config.client_id,
                "client_secret": self.config.client_secret,
                "redirect_uri": self.config.redirect_uri,
                "grant_type": self.config.grant_type,
                "code": code,
                "code_verifier": self.model.verifier,
            }

            response = self._post(path=self.config.token_path, data=data)
            if not response:
                return None

            return self.process_token(token_data=response.json())
        except Exception as ex:
            self._log_exception("Failed to retrieve token data from API.", ex)
            return None


    def refresh_access_token(self) -> Optional[TokenModel]:
        try:
            if not self.model or not self.model.token:
                self.logging.danger(
                    message="No refresh token available.",
                )
                return None

            data = {
                "client_id": self.config.client_id,
                "client_secret": self.config.client_secret,
                "grant_type": "refresh_token",
                "refresh_token": self.model.token.refresh_token,
            }
            response = self._post(path=self.config.token_path, data=data)
            if not response:
                return None

            return self.process_token(token_data=response.json())
        except Exception as ex:
            self._log_exception("Failed to refresh token data from API.", ex)
            return None


    def get_userinfo(self, access_token: str) -> Optional[UserModel]:
        try:
            self.headers["Authorization"] = "JWT " + access_token
            response = self._get(path=self.config.userinfo_path)
            if not response:
                return None

            json_data = response.json()
            userinfo_data = UserModel(**json_data)

            # Inform interested parties
            userinfo_data_updated.send(sender=UserModel, instance=userinfo_data)
            return userinfo_data
        except Exception as ex:
            self._log_exception("Failed to retrieve userinfo data from API.", ex)
            return None


    def get_access_token(self) -> Optional[str]:
        self.get_session_data()
        if self.model and self.model.token:
            token = self.model.token
            if token.expires_at <= datetime.now():
                # If token is expired, refresh it
                token_data = self.refresh_access_token()
                if token_data:
                    self.model.token = token_data
                    self.set_session_data()

            return self.model.token.access_token

        return None


    def login(self, user: UserModel) -> Optional[User]:
        try:
            user_command = UserCommand(data=user.model_dump())
            user_model = User.objects.filter(id=user.id).first()
            if not user_model:
                user_model = user_command.create()
            else:
                user_model = user_command.update(pk=user.id)

            # Inform interested parties
            user_data_updated.send(sender=User, instance=user_model)

            # Log the user in
            auth.login(self.req, user_model)

            return user_model
        except Exception as ex:
            self._log_exception("Failed to set user data from API.", ex)
            return None


    def authenticate(self, token: str) -> Optional[User]:
        try:
            user = self.get_userinfo(access_token=token)
            if not user:
                return None

            return self.login(user=user)
        except Exception as ex:
            self._log_exception("Failed to retrieve user data from API.", ex)
            return None


    def authorize(self) -> Optional[User]:
        try:
            token_data = self.authorize_access_token()
            if not token_data:
                return None

            return self.authenticate(token=token_data.access_token)
        except Exception as ex:
            self._log_exception("Failed to retrieve user data from API.", ex)
            return None

