from datetime import datetime
from enum import Enum
from typing import List, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from nkunyim_iam.encryption import HashingAlgo


class IdentityConfigModel(BaseModel):
    base_url: str = "https://identity.nkunyim.local"
    back_url: str = "http://identity.nkunyim.local"
    front_url: str = "https://identity.nkunyim.local"
    issuer: str = "https://identity.nkunyim.local"
    client_id: str
    client_secret: str
    client_scope: str = "openid profile email phone offline_access"
    redirect_uri: str = "https://app.nkunyim.local/auth/callback/"
    response_type: str = "code"
    grant_type: str = "authorization_code"
    hash_algo: HashingAlgo = HashingAlgo.S256
    authorize_path: str = "/oauth2/authorize/"
    userinfo_path: str = "/iam/users/userinfo/"
    token_path: str = "/oauth2/token/"
    logout_path: str = "/oauth2/logout/"


class LoggingLevel(str, Enum):
    INFO = "info"
    SUCCESS = "success"
    WARNING = "warning"
    DANGER = "danger"


LoggingContext = dict[str, str | int | float | bool | None]


class LoggingModel(BaseModel):
    model_config = ConfigDict(use_enum_values=True)
    level: LoggingLevel = LoggingLevel.INFO
    message: str
    context: LoggingContext = Field(default_factory=dict)


class TokenModel(BaseModel):
    model_config = ConfigDict(use_enum_values=True)
    access_token: str
    refresh_token: str
    token_type: str
    expires_in: int
    expires_at: datetime
    scope: str


class SessionModel(BaseModel):
    code: str = ""
    verifier: str = ""
    state: str = ""
    nonce: str = ""
    next: str = "/home/"
    token: Optional[TokenModel] = None


class AddressModel(BaseModel):
    id: UUID
    street_address: str
    postal_code: str
    locality: str
    city: str
    nation_id: UUID
    timezone: str
    language: str
    is_primary: bool
    is_verified: bool
    is_active: bool
    created_at: datetime
    updated_at: datetime
    

class UserModel(BaseModel):
    id: UUID
    username: str
    nickname: str
    first_name: str
    middle_name: Optional[str]
    last_name: str
    email_address: str
    email_verified: bool
    email_verified_at: Optional[datetime]
    phone_number: str
    phone_verified: bool
    phone_verified_at: Optional[datetime]
    serial: Optional[str]
    gender: str
    birth_date: Optional[datetime]
    photo_url: Optional[str]
    photo_verified: bool
    photo_verified_at: Optional[datetime]
    profile: Optional[str]
    is_pwd: bool
    is_active: bool
    is_admin: bool
    is_superuser: bool
    is_verified: bool
    last_login: datetime
    created_at: datetime
    updated_at: datetime
    addresses: Optional[List[AddressModel]]
    groups: Optional[List[str]]
    user_permissions: Optional[List[str]]
  