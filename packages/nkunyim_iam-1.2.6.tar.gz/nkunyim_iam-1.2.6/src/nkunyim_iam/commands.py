from datetime import datetime
from uuid import UUID

from nkunyim_iam.encryption import Base64Util, Hashing, HashingAlgo
from nkunyim_iam.models import Address, Logging, User
from nkunyim_iam.validation import Validation


class UserCommand(Validation):
    BASE_SCHEMA = {
        "id": {"typ": "uuid"},
        "username": {"typ": "str"},
        "nickname": {"typ": "str"},
        "first_name": {"typ": "str"},
        "last_name": {"typ": "str"},
        "email_address": {"typ": "str"},
        "phone_number": {"typ": "str"},
        "gender": {"typ": "str"},
    }

    def __init__(self, data: dict):
        super().__init__()
        
        self.check(schema=self.BASE_SCHEMA, data=data)

        self.id = data["id"]
        self.username = data["username"]
        self.nickname = data["nickname"]
        self.first_name = data["first_name"]
        self.last_name = data["last_name"]
        self.email_address = data["email_address"]
        self.phone_number = data["phone_number"]
        self.gender = data["gender"]

        self.password = data.get("password") or Hashing(input_string=self.id.hex).make(
            algo=HashingAlgo.S512
        )
        self.serial = Base64Util.encode(self.password)
        self.middle_name = data.get("middle_name")
        self.email_verified = bool(data.get("email_verified", False))
        self.phone_verified = bool(data.get("phone_verified", False))
        self.birth_date = data.get("birth_date")
        self.photo_url = data.get("photo_url")
        self.photo_verified = bool(data.get("photo_verified", False))
        self.photo_verified_at = data.get("photo_verified_at")
        self.profile = data.get("profile")
        self.is_pwd = bool(data.get("is_pwd", False))
        self.is_admin = bool(data.get("is_admin", False))
        self.is_superuser = bool(data.get("is_superuser", False))
        self.is_verified = bool(data.get("is_verified", False))
        self.is_active = bool(data.get("is_active", True))

    def _apply_core_fields(self, user: User) -> None:
        user.username = self.username
        user.nickname = self.nickname
        user.first_name = self.first_name
        user.last_name = self.last_name
        user.email_address = self.email_address
        user.phone_number = self.phone_number
        user.gender = self.gender
        user.serial = self.serial
        user.is_pwd = self.is_pwd
        user.is_verified = self.is_verified
        user.is_active = self.is_active
        user.is_admin = self.is_admin
        user.is_superuser = self.is_superuser

    def _apply_optional_fields(self, user: User) -> None:
        if self.email_verified and self.email_verified != user.email_verified:
            user.email_verified = self.email_verified

        if self.phone_verified and self.phone_verified != user.phone_verified:
            user.phone_verified = self.phone_verified

        if self.middle_name and self.middle_name != user.middle_name:
            user.middle_name = self.middle_name

        if self.birth_date and self.birth_date != user.birth_date:
            user.birth_date = self.birth_date

        if self.photo_url and self.photo_url != user.photo_url:
            user.photo_url = self.photo_url

        if self.profile and self.profile != user.profile:
            user.profile = self.profile

    def create(self) -> User:
        user = User(id=self.id)
        self._apply_core_fields(user)
        self._apply_optional_fields(user)

        user.set_password(self.password)
        user.save()
        return user

    def update(self, pk: UUID) -> User:
        user = User.objects.get(pk=pk)

        self._apply_core_fields(user)
        self._apply_optional_fields(user)
        user.save()

        return user



class AddressCommand(Validation):
    BASE_SCHEMA = {
        "user_id": {"typ": "uuid"},
        "street_address": {"typ": "str"},
        "locality": {"typ": "str"},
        "postal_code": {"typ": "str"},
        "city": {"typ": "str"},
        "nation_code": {"typ": "str"},
        "timezone": {"typ": "str"},
        "language": {"typ": "str"},
    }

    def __init__(self, data: dict):
        super().__init__()
        
        self.check(schema=self.BASE_SCHEMA, data=data)

        self.user_id = data["user_id"]
        self.street_address = data["street_address"]
        self.locality = data["locality"]
        self.postal_code = data["postal_code"]
        self.city = data["city"]
        self.nation_code = data["nation_code"]
        self.timezone = data["timezone"]
        self.language = data["language"]
        self.is_active = bool(data.get("is_active", True))

    def _apply_fields(self, address: Address) -> None:
        address.user_id = self.user_id
        address.street_address = self.street_address
        address.locality = self.locality
        address.postal_code = self.postal_code
        address.city = self.city
        address.nation_code = self.nation_code
        address.timezone = self.timezone
        address.language = self.language
        address.is_active = self.is_active

    def create(self) -> Address:
        address = Address()
        self._apply_fields(address)
        address.save()
        return address

    def update(self, pk: UUID) -> Address:
        address = Address.objects.get(pk=pk)
        self._apply_fields(address)
        address.save()
        return address


class LoggingCommand(Validation):
    BASE_SCHEMA = {
        "level": {"typ": "str"},
        "message": {"typ": "str"},
        "context": {"typ": "dict", "req": False},
    }

    def __init__(self, data: dict):
        super().__init__()
        
        self.check(schema=self.BASE_SCHEMA, data=data)

        self.level = data["level"]
        self.message = data["message"]
        self.context = data.get("context", {})
        
    def create(self) -> Logging:
        logging = Logging()
        logging.level = self.level
        logging.message = self.message
        logging.context = self.context
        logging.save()
        return logging
