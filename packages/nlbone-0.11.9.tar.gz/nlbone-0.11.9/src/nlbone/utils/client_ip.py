import ipaddress

from starlette.requests import Request

TYPESOURCEIP_ALL = [
    "HTTP_CLIENT_IP",
    "HTTP_AR_REAL_IP",
    "HTTP_X_REAL_IP",
    "HTTP_X_FORWARDED_FOR",
    "HTTP_X_FORWARDED",
    "HTTP_FORWARDED_FOR",
    "HTTP_FORWARDED",
    "REMOTE_ADDR",
]

def validate_ip(ip: str) -> bool:
    try:
        ipaddress.ip_address(ip.strip())
        return True
    except ValueError:
        return False

def first_ip(value: str) -> str:
    return (value or "").split(",")[0].strip()

def get_client_ip_and_source(request: Request) -> tuple[str, str]:
    httpclientip = ""
    typesourceip = ""

    # 1) Cloudflare: CF-Connecting-IP
    cf_ip = request.headers.get("cf-connecting-ip")
    if not httpclientip and cf_ip:
        candidate = first_ip(cf_ip)
        if validate_ip(candidate):
            httpclientip = candidate
            typesourceip = "HTTP_CF_CONNECTING_IP"

    # helper: map PHP-style names to actual header / source in FastAPI
    def read_source(name: str) -> str | None:
        n = name.upper()
        if n == "REMOTE_ADDR":
            return request.client.host if request.client else None

        # PHP names look like HTTP_X_FORWARDED_FOR -> header "x-forwarded-for"
        if n.startswith("HTTP_"):
            header_name = n[5:].lower().replace("_", "-")
            return request.headers.get(header_name)

        return None

    if not httpclientip:
        for src in TYPESOURCEIP_ALL:
            if httpclientip:
                break
            raw = read_source(src)
            if raw:
                candidate = first_ip(raw)
                if validate_ip(candidate):
                    httpclientip = candidate
                    typesourceip = src
                else:
                    httpclientip = ""

    if not httpclientip:
        for src in TYPESOURCEIP_ALL:
            if httpclientip:
                break
            raw = read_source(src)
            if raw:
                candidate = first_ip(raw)
                if validate_ip(candidate):
                    httpclientip = candidate
                    typesourceip = src
                else:
                    httpclientip = ""

    return httpclientip, typesourceip