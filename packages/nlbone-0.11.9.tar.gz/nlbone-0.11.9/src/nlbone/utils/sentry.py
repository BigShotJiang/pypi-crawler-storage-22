from __future__ import annotations

from typing import Any, Optional

import sentry_sdk
from sentry_sdk import configure_scope
from sentry_sdk.integrations.logging import LoggingIntegration
from sentry_sdk.integrations.starlette import StarletteIntegration

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

from nlbone.config.settings import get_settings
from nlbone.utils.context import request_id_ctx, user_id_ctx, ip_ctx, user_agent_ctx, _current_locale, request_ctx

setting = get_settings()
def _get_status_code(event: dict, hint: dict) -> Optional[int]:
    status = (
        event.get("contexts", {})
        .get("response", {})
        .get("status_code")
    )
    if isinstance(status, int):
        return status

    status = event.get("request", {}).get("status_code")
    if isinstance(status, int):
        return status

    exc_info = hint.get("exc_info")
    if exc_info:
        exc = exc_info[1]
        code = getattr(exc, "status_code", None) or getattr(exc, "code", None)
        if isinstance(code, int):
            return code

    return None


def _enrich_event_with_project_context(event: dict) -> dict:
    request_id = request_id_ctx.get()
    user_id = user_id_ctx.get()
    req_obj = request_ctx.get()

    tags = event.setdefault("tags", {})
    # if request_id:
    #     tags["request_id"] = request_id
    # if user_id:
    #     event.setdefault("user", {})
    #     event["user"]["id"] = str(user_id)

    contexts = event.setdefault("contexts", {})
    contexts.setdefault("app", {})
    contexts["app"].update({
        "request_id": request_id,
    })
    if req_obj is not None:
        method = getattr(req_obj, "method", None)
        path = getattr(req_obj, "url", None) or getattr(req_obj, "path", None)
        if method or path:
            contexts.setdefault("http", {})
            if method:
                contexts["http"]["method"] = str(method)
            if path:
                contexts["http"]["path"] = str(path)

    return event


def before_send(event, hint):
    status = _get_status_code(event, hint)
    if isinstance(status, int) and 400 <= status < 500:
        return None

    event = _enrich_event_with_project_context(event)

    return event


sentry_logging = LoggingIntegration(
    level=None,  # breadcrumbs
    event_level="ERROR"  # events
)


def init_sentry(dsn=setting.SENTRY_SDK, environment=setting.ENV, sample_rate=0.10, send_default_pii=False, before_send_func=before_send) -> None:
    sentry_sdk.init(
        dsn=dsn,
        environment=environment,
        integrations=[
            sentry_logging,
            StarletteIntegration(),  # یا FastApiIntegration()
        ],
        sample_rate=sample_rate,
        before_send=before_send_func,
        send_default_pii=send_default_pii,
    )


class SentryContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        with configure_scope() as scope:
            request_id = request_id_ctx.get()
            user_id = user_id_ctx.get()

            if request_id:
                scope.set_tag("request_id", request_id)

            if user_id:
                scope.set_user({"id": str(user_id)})

            scope.set_context("http", {
                "method": request.method,
                "path": request.url.path,
            })

        return await call_next(request)
