from typing import List, Any, Dict
from collections import defaultdict

# Accuracy
def accuracy_score(y_true: List[Any], y_pred: List[Any]) -> float:
    if len(y_true) != len(y_pred):
        raise ValueError("y_true and y_pred must have same length")

    correct = sum(1 for yt, yp in zip(y_true, y_pred) if yt == yp)
    return correct / len(y_true) if y_true else 0.0

# Confusion Matrix
def confusion_matrix(y_true: List[Any], y_pred: List[Any]) -> Dict[Any, Dict[Any, int]]:
    if len(y_true) != len(y_pred):
        raise ValueError("y_true and y_pred must have same length")

    labels = set(y_true) | set(y_pred)

    matrix = {
        true_label: {pred_label: 0 for pred_label in labels}
        for true_label in labels
    }

    for yt, yp in zip(y_true, y_pred):
        matrix[yt][yp] += 1

    return matrix

# Precision
def precision_score(
    y_true: List[Any],
    y_pred: List[Any],
    average: str = "macro"
) -> float:

    cm = confusion_matrix(y_true, y_pred)
    labels = list(cm.keys())

    if average == "binary":
        label = labels[0]
        tp = cm[label][label]
        fp = sum(cm[other][label] for other in labels if other != label)
        return tp / (tp + fp) if (tp + fp) > 0 else 0.0

    # macro
    precisions = []

    for label in labels:
        tp = cm[label][label]
        fp = sum(cm[other][label] for other in labels if other != label)
        score = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        precisions.append(score)

    return sum(precisions) / len(precisions)

# Recall
def recall_score(
    y_true: List[Any],
    y_pred: List[Any],
    average: str = "macro"
) -> float:

    cm = confusion_matrix(y_true, y_pred)
    labels = list(cm.keys())

    if average == "binary":
        label = labels[0]
        tp = cm[label][label]
        fn = sum(cm[label][other] for other in labels if other != label)
        return tp / (tp + fn) if (tp + fn) > 0 else 0.0

    recalls = []

    for label in labels:
        tp = cm[label][label]
        fn = sum(cm[label][other] for other in labels if other != label)
        score = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        recalls.append(score)

    return sum(recalls) / len(recalls)

# F1 Score
def f1_score(
    y_true: List[Any],
    y_pred: List[Any],
    average: str = "macro"
) -> float:

    precision = precision_score(y_true, y_pred, average=average)
    recall = recall_score(y_true, y_pred, average=average)

    if precision + recall == 0:
        return 0.0

    return 2 * (precision * recall) / (precision + recall)
