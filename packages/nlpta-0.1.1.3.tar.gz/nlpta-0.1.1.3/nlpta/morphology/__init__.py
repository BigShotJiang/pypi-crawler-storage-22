"""
Public morphology API.
"""

from collections.abc import Iterable
from typing import Any, Dict, List

from .affixes import PREFIXES, SUFFIXES, get_all_prefixes, get_all_suffixes
from .detection import detect_affixes as _legacy_detect_affixes
from .hornmorpho import HornMorphoAnalyzer

_DEFAULT_ANALYZER = HornMorphoAnalyzer()


def _get_analyzer(
    engine: str = "auto",
    language: str = "a",
    normalize: bool = True,
    min_stem_length: int = 2,
    max_iterations: int = 2,
    allow_fallback: bool = True,
) -> HornMorphoAnalyzer:
    if (
        engine == "auto"
        and language == "a"
        and normalize
        and min_stem_length == 2
        and max_iterations == 2
        and allow_fallback
    ):
        return _DEFAULT_ANALYZER
    return HornMorphoAnalyzer(
        engine=engine,
        language=language,
        normalize=normalize,
        min_stem_length=min_stem_length,
        max_iterations=max_iterations,
        allow_fallback=allow_fallback,
    )


def analyze(
    word: str,
    engine: str = "auto",
    language: str = "a",
    normalize: bool = True,
    min_stem_length: int = 2,
    max_iterations: int = 2,
    allow_fallback: bool = True,
) -> Dict[str, Any]:
    analyzer = _get_analyzer(
        engine=engine,
        language=language,
        normalize=normalize,
        min_stem_length=min_stem_length,
        max_iterations=max_iterations,
        allow_fallback=allow_fallback,
    )
    return analyzer.analyze(word)


def lemmatize(
    word: str,
    engine: str = "auto",
    language: str = "a",
    normalize: bool = True,
    min_stem_length: int = 2,
    max_iterations: int = 2,
    allow_fallback: bool = True,
) -> str:
    analyzer = _get_analyzer(
        engine=engine,
        language=language,
        normalize=normalize,
        min_stem_length=min_stem_length,
        max_iterations=max_iterations,
        allow_fallback=allow_fallback,
    )
    return analyzer.lemmatize(word)


def stem(
    word: str,
    engine: str = "auto",
    language: str = "a",
    normalize: bool = True,
    min_stem_length: int = 2,
    max_iterations: int = 2,
    allow_fallback: bool = True,
) -> str:
    analyzer = _get_analyzer(
        engine=engine,
        language=language,
        normalize=normalize,
        min_stem_length=min_stem_length,
        max_iterations=max_iterations,
        allow_fallback=allow_fallback,
    )
    return analyzer.stem(word)


def analyze_batch(
    words: Iterable[str],
    engine: str = "auto",
    language: str = "a",
    normalize: bool = True,
    min_stem_length: int = 2,
    max_iterations: int = 2,
    allow_fallback: bool = True,
    workers: int = 1,
    use_multiprocessing: bool = False,
) -> List[Dict[str, Any]]:
    analyzer = _get_analyzer(
        engine=engine,
        language=language,
        normalize=normalize,
        min_stem_length=min_stem_length,
        max_iterations=max_iterations,
        allow_fallback=allow_fallback,
    )
    return analyzer.analyze_batch(
        words,
        workers=workers,
        use_multiprocessing=use_multiprocessing,
    )


def detect_affixes(
    token: str,
    min_stem_length: int = 2,
    max_iterations: int = 2,
) -> Dict[str, Any]:
    """
    Backward-compatible API for legacy detection output shape.
    """
    return _legacy_detect_affixes(
        token,
        min_stem_length=min_stem_length,
        max_iterations=max_iterations,
    )


__all__ = [
    "PREFIXES",
    "SUFFIXES",
    "HornMorphoAnalyzer",
    "get_all_prefixes",
    "get_all_suffixes",
    "analyze",
    "lemmatize",
    "stem",
    "analyze_batch",
    "detect_affixes",
]
