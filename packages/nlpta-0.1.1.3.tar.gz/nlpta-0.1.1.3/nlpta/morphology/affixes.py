"""
Affix inventory and rule-based stemming utilities for Amharic morphology.
"""

from typing import Any, Dict, List

# Affix inventories
PREFIXES = ["በ", "ለ", "ከ", "የ", "እንደ", "እስከ"]
SUFFIXES = ["ኝ", "ህ", "ሽ", "ው", "ች", "ነት"]

# Prefix role mappings
PREFIX_ROLES = {
    "በ": ["locative", "instrumental"],
    "ለ": ["dative", "benefactive"],
    "ከ": ["ablative", "source"],
    "የ": ["genitive", "possessive"],
    "እንደ": ["comparative", "manner"],
    "እስከ": ["temporal_limit", "spatial_limit"],
}

# Suffix role mappings
SUFFIX_ROLES = {
    "ኝ": ["1st_person_object"],
    "ህ": ["2nd_person_masc_possessive"],
    "ሽ": ["2nd_person_fem_possessive"],
    "ው": ["3rd_person_masc_object"],
    "ች": ["plural_feminine"],
    "ነት": ["abstract_noun"],
}


def _sort_by_length(values: List[str]) -> List[str]:
    return sorted(values, key=len, reverse=True)


def get_all_prefixes() -> List[str]:
    """
    Return all known prefix forms used for detection and stemming.
    """
    return list(PREFIXES)


def get_all_suffixes() -> List[str]:
    """
    Return all known suffix forms used for detection and stemming.
    """
    return list(SUFFIXES)


def stem(token: str, min_stem_length: int = 2, max_iterations: int = 2) -> str:
    """
    Strip known prefixes/suffixes conservatively and return a stem-like base form.

    The algorithm is intentionally simple and rule-based:
    - Longest matching prefix is removed first (if safe)
    - Longest matching suffix is removed next (if safe)
    - The process can repeat for stacked affixes
    - A minimum stem length prevents over-stemming
    """
    if not token or not isinstance(token, str):
        return token
    if min_stem_length < 1:
        raise ValueError("min_stem_length must be >= 1")
    if max_iterations < 1:
        return token

    stemmed = token
    sorted_prefixes = _sort_by_length(PREFIXES)
    sorted_suffixes = _sort_by_length(SUFFIXES)

    for _ in range(max_iterations):
        changed = False

        for prefix in sorted_prefixes:
            if stemmed.startswith(prefix) and (len(stemmed) - len(prefix)) >= min_stem_length:
                stemmed = stemmed[len(prefix) :]
                changed = True
                break

        for suffix in sorted_suffixes:
            if stemmed.endswith(suffix) and (len(stemmed) - len(suffix)) >= min_stem_length:
                stemmed = stemmed[: -len(suffix)]
                changed = True
                break

        if not changed:
            break

    return stemmed


def detect_affixes(token: str, min_stem_length: int = 2) -> Dict[str, Any]:
    """
    Detect affixes in an Amharic token and provide a stripped stem candidate.
    """
    if not token or not isinstance(token, str):
        return {
            "token": token,
            "prefixes": [],
            "suffixes": [],
            "stem_candidate": None,
            "stem": token,
        }

    result = {"token": token, "prefixes": [], "suffixes": []}

    for prefix in PREFIXES:
        if token.startswith(prefix):
            result["prefixes"].append(
                {
                    "form": prefix,
                    "category": "prepositions",
                    "roles": PREFIX_ROLES.get(prefix, []),
                }
            )

    for suffix in SUFFIXES:
        if token.endswith(suffix):
            result["suffixes"].append(
                {
                    "form": suffix,
                    "category": "possessive",
                    "roles": SUFFIX_ROLES.get(suffix, []),
                }
            )

    stemmed = stem(token, min_stem_length=min_stem_length)
    result["stem"] = stemmed
    result["stem_candidate"] = stemmed if stemmed != token else None
    return result
