"""
Core data model for morphology analysis outputs.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


FeatureMap = Dict[str, str]


@dataclass(frozen=True)
class MorphAnalysis:
    """
    One possible analysis for a token.
    """

    surface: str
    lemma: str
    stem: str
    pos: Optional[str] = None
    features: FeatureMap = field(default_factory=dict)
    prefixes: List[str] = field(default_factory=list)
    suffixes: List[str] = field(default_factory=list)
    source: str = "rules"
    confidence: str = "medium"
    score: Optional[float] = None
    raw: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "surface": self.surface,
            "lemma": self.lemma,
            "stem": self.stem,
            "pos": self.pos,
            "features": dict(self.features),
            "prefixes": list(self.prefixes),
            "suffixes": list(self.suffixes),
            "source": self.source,
            "confidence": self.confidence,
            "score": self.score,
        }


@dataclass(frozen=True)
class MorphResult:
    """
    Aggregate result for a token, including all possible analyses.
    """

    token: str
    normalized: str
    engine: str
    analyses: List[MorphAnalysis] = field(default_factory=list)
    failed: bool = False
    error: Optional[str] = None
    elapsed_ms: Optional[float] = None

    def best(self) -> Optional[MorphAnalysis]:
        if not self.analyses:
            return None
        return self.analyses[0]

    def to_dict(self) -> Dict[str, Any]:
        best = self.best()
        best_stem = best.stem if best else self.normalized
        return {
            "token": self.token,
            "normalized": self.normalized,
            "engine": self.engine,
            "analyses": [analysis.to_dict() for analysis in self.analyses],
            "failed": self.failed,
            "error": self.error,
            "elapsed_ms": self.elapsed_ms,
            "lemma": best.lemma if best else self.normalized,
            "stem": best_stem,
            "prefixes": best.prefixes if best else [],
            "suffixes": best.suffixes if best else [],
            "stem_candidate": (
                best_stem if best and best_stem != self.normalized else None
            ),
        }
