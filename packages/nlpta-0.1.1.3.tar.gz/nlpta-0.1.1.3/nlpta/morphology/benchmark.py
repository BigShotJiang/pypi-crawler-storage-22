"""
Morphology evaluation and benchmarking helpers.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from pathlib import Path
from time import perf_counter
from typing import Any, Dict, Iterable, List

from . import analyze_batch

AMHARIC_TOKEN_RE = re.compile(r"[\u1200-\u137F]+")
DEFAULT_CORPUS_PATH = Path(__file__).resolve().parents[2] / "data" / "merged_large_corpus.txt"
DEFAULT_NORMALIZATION_GOLD = [
    {"word": "እሥከቤትነት", "expected_stem": "ቤት"},
    {"word": "እሥከሰውነት", "expected_stem": "ሰው"},
    {"word": "እሥከመንገድነት", "expected_stem": "መንገድ"},
    {"word": "እሥከሀገርነት", "expected_stem": "ሀገር"},
    {"word": "እሥከትምህርትነት", "expected_stem": "ትምህርት"},
]


def collect_benchmark_words(
    path: str | Path | None = None,
    min_words: int = 500,
    max_words: int = 1000,
) -> List[str]:
    """
    Collect unique Amharic words from corpus text for benchmarking.
    """
    if min_words < 1:
        raise ValueError("min_words must be >= 1")
    if max_words < min_words:
        raise ValueError("max_words must be >= min_words")

    corpus_path = Path(path) if path is not None else DEFAULT_CORPUS_PATH
    if not corpus_path.exists():
        raise FileNotFoundError(f"Corpus file not found: {corpus_path}")

    text = corpus_path.read_text(encoding="utf-8")
    tokens = AMHARIC_TOKEN_RE.findall(text)

    unique_words: List[str] = []
    seen = set()
    for token in tokens:
        if token in seen:
            continue
        seen.add(token)
        unique_words.append(token)
        if len(unique_words) >= max_words:
            break

    if len(unique_words) < min_words:
        raise ValueError(
            f"Only {len(unique_words)} unique words collected, below required minimum {min_words}."
        )
    return unique_words


def benchmark_morphology(
    words: Iterable[str],
    engine: str = "auto",
    language: str = "a",
    workers: int = 1,
    use_multiprocessing: bool = False,
) -> Dict[str, float | int | Dict[str, int]]:
    """
    Measure coverage, ambiguity, speed, and failure rate.
    """
    word_list = list(words)
    if not word_list:
        raise ValueError("words must not be empty")

    start = perf_counter()
    results = analyze_batch(
        word_list,
        engine=engine,
        language=language,
        workers=workers,
        use_multiprocessing=use_multiprocessing,
    )
    elapsed_s = perf_counter() - start

    total = len(results)
    analyzed = 0
    ambiguous = 0
    failed = 0
    engine_counts: Counter[str] = Counter()

    for result in results:
        analyses = result.get("analyses", [])
        if analyses:
            analyzed += 1
        if len(analyses) > 1:
            ambiguous += 1
        if result.get("failed"):
            failed += 1
        engine_name = str(result.get("engine", "unknown"))
        engine_counts[engine_name] += 1

    coverage = analyzed / total if total else 0.0
    ambiguity_rate = ambiguous / analyzed if analyzed else 0.0
    failure_rate = failed / total if total else 0.0
    words_per_second = total / elapsed_s if elapsed_s else 0.0

    return {
        "total_words": total,
        "analyzed_words": analyzed,
        "coverage": coverage,
        "ambiguity_rate": ambiguity_rate,
        "failure_rate": failure_rate,
        "elapsed_seconds": elapsed_s,
        "words_per_second": words_per_second,
        "engine_counts": dict(engine_counts),
    }


def run_default_benchmark(
    output_path: str | Path | None = None,
    sample_size: int = 750,
    engine: str = "auto",
    language: str = "a",
    workers: int = 1,
    use_multiprocessing: bool = False,
) -> Dict[str, float | int | Dict[str, int]]:
    """
    Run benchmark with 500-1000 token target and optionally persist metrics.
    """
    sample_size = max(500, min(1000, sample_size))
    words = collect_benchmark_words(min_words=500, max_words=sample_size)
    metrics = benchmark_morphology(
        words,
        engine=engine,
        language=language,
        workers=workers,
        use_multiprocessing=use_multiprocessing,
    )

    if output_path is not None:
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(metrics, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    return metrics


def evaluate_normalization_impact(
    engine: str = "rules",
    language: str = "a",
    gold_samples: List[Dict[str, str]] | None = None,
) -> Dict[str, Any]:
    """
    Compare stem accuracy with and without normalization on a small gold set.
    """
    samples = gold_samples if gold_samples is not None else DEFAULT_NORMALIZATION_GOLD
    if not samples:
        raise ValueError("gold_samples must not be empty")

    words = [sample["word"] for sample in samples]
    expected = [sample["expected_stem"] for sample in samples]

    without_norm = analyze_batch(words, engine=engine, language=language, normalize=False)
    with_norm = analyze_batch(words, engine=engine, language=language, normalize=True)

    without_correct = 0
    with_correct = 0
    details = []

    for word, expected_stem, raw_result, norm_result in zip(
        words, expected, without_norm, with_norm
    ):
        raw_stem = str(raw_result.get("stem", ""))
        norm_stem = str(norm_result.get("stem", ""))
        raw_ok = raw_stem == expected_stem
        norm_ok = norm_stem == expected_stem
        without_correct += int(raw_ok)
        with_correct += int(norm_ok)
        details.append(
            {
                "word": word,
                "expected_stem": expected_stem,
                "stem_without_normalization": raw_stem,
                "stem_with_normalization": norm_stem,
                "raw_correct": raw_ok,
                "normalized_correct": norm_ok,
            }
        )

    total = len(samples)
    without_accuracy = without_correct / total
    with_accuracy = with_correct / total

    return {
        "engine": engine,
        "language": language,
        "samples": total,
        "accuracy_without_normalization": without_accuracy,
        "accuracy_with_normalization": with_accuracy,
        "accuracy_improvement": with_accuracy - without_accuracy,
        "details": details,
    }
