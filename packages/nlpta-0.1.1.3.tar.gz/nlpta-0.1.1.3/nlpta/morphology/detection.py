"""
Amharic affix detection and stemming.
"""

from .affixes import get_all_prefixes, get_all_suffixes, stem as _stem


def stem(token: str, min_stem_length: int = 2, max_iterations: int = 2) -> str:
    """
    Strip known prefixes/suffixes from a token using rule-based morphology.
    """
    return _stem(
        token, min_stem_length=min_stem_length, max_iterations=max_iterations
    )


def detect_affixes(
    token: str, min_stem_length: int = 2, max_iterations: int = 2
) -> dict:
    """
    Analyzes a token to detect potential Amharic prefixes and suffixes.

    Args:
        token (str): The normalized word token to analyze.

    Returns:
        dict: A dictionary containing:
            - "token": The original input string.
            - "prefixes": List of all matching prefixes.
            - "suffixes": List of all matching suffixes.
            - "stem_candidate": A stem candidate if affixes were stripped.
            - "stem": Stemmed surface form (token if no safe stripping applies).
    """
    if not token:
        return {
            "token": token,
            "prefixes": [],
            "suffixes": [],
            "stem_candidate": None,
            "stem": token,
        }

    all_prefixes = get_all_prefixes()
    all_suffixes = get_all_suffixes()

    detected_prefixes = sorted(
        [p for p in all_prefixes if token.startswith(p)], key=len, reverse=True
    )
    detected_suffixes = sorted(
        [s for s in all_suffixes if token.endswith(s)], key=len, reverse=True
    )

    stemmed = stem(
        token, min_stem_length=min_stem_length, max_iterations=max_iterations
    )
    has_detected_affix = bool(detected_prefixes or detected_suffixes)

    return {
        "token": token,
        "prefixes": detected_prefixes,
        "suffixes": detected_suffixes,
        "stem_candidate": stemmed if has_detected_affix and stemmed != token else None,
        "stem": stemmed,
    }
