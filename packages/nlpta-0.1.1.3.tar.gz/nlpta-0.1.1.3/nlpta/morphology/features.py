"""
Feature schema normalization and validation for morphology outputs.
"""

from typing import Any, Dict, Iterable, Mapping, Set


ALLOWED_FEATURE_KEYS: Set[str] = {
    "aspect",
    "case",
    "definiteness",
    "gender",
    "mood",
    "number",
    "person",
    "polarity",
    "pos",
    "tense",
    "voice",
}

FEATURE_KEY_ALIASES = {
    "part_of_speech": "pos",
    "category": "pos",
    "cat": "pos",
    "num": "number",
    "gen": "gender",
    "pers": "person",
    "morph": "features",
}


def normalize_feature_key(key: str) -> str:
    """
    Map a raw feature key to a canonical key.
    """
    normalized = key.strip().lower().replace("-", "_").replace(" ", "_")
    return FEATURE_KEY_ALIASES.get(normalized, normalized)


def normalize_features(raw_features: Mapping[str, Any] | None) -> Dict[str, str]:
    """
    Normalize feature keys and cast feature values to strings.
    Unknown keys are dropped to preserve a stable schema.
    """
    if not raw_features:
        return {}

    normalized: Dict[str, str] = {}
    for key, value in raw_features.items():
        canonical_key = normalize_feature_key(str(key))
        if canonical_key in ALLOWED_FEATURE_KEYS:
            normalized[canonical_key] = str(value)

    return normalized


def invalid_feature_keys(features: Mapping[str, Any]) -> Iterable[str]:
    """
    Yield all keys that are outside the allowed schema.
    """
    for key in features:
        canonical_key = normalize_feature_key(str(key))
        if canonical_key not in ALLOWED_FEATURE_KEYS:
            yield str(key)


def validate_features(features: Mapping[str, Any], strict: bool = False) -> bool:
    """
    Validate feature dictionary keys.
    """
    invalid = list(invalid_feature_keys(features))
    if invalid and strict:
        raise ValueError(f"Unsupported feature keys: {', '.join(invalid)}")
    return not invalid
