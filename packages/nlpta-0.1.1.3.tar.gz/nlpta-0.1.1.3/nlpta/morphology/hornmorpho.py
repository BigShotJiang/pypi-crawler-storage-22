"""
HornMorpho engine integration with fallback analysis support.
"""

from __future__ import annotations

import importlib
import re
from collections.abc import Iterable, Mapping
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from time import perf_counter
from typing import Any, Callable, Dict, List, Optional

from .base import MorphAnalysis, MorphResult
from .features import normalize_features
from .normalizer import normalize_for_morphology
from .rules import RuleBasedStemmer

_CONFIDENCE_RANK = {"low": 0, "medium": 1, "high": 2}


def _as_list(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return []
        if "," in text:
            return [item.strip() for item in text.split(",") if item.strip()]
        if "+" in text:
            return [item.strip() for item in text.split("+") if item.strip()]
        return [text]
    if isinstance(value, Iterable):
        return [str(item) for item in value if str(item).strip()]
    return [str(value)]


def _coerce_score(value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return float(str(value))
    except (TypeError, ValueError):
        return None


def _coerce_confidence(value: Any) -> str:
    if value is None:
        return "medium"
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in _CONFIDENCE_RANK:
            return lowered
    if isinstance(value, (int, float)):
        numeric = float(value)
        if numeric >= 0.8:
            return "high"
        if numeric >= 0.45:
            return "medium"
        return "low"
    return "medium"


def _discover_hornmorpho_callable(language: str) -> Optional[Callable[[str], Any]]:
    try:
        hm_module = importlib.import_module("hm")
    except Exception:
        hm_module = None

    if hm_module is not None:
        hm_anal = getattr(hm_module, "anal", None)
        if callable(hm_anal):
            return lambda token: hm_anal(language, token)

    module_candidates = ("hornmorpho", "hornmorpho.analyzer")
    function_names = ("analyze", "parse", "morph_analyze")
    class_names = ("HornMorpho", "Analyzer", "MorphAnalyzer")

    for module_name in module_candidates:
        try:
            module = importlib.import_module(module_name)
        except Exception:
            continue

        for function_name in function_names:
            function = getattr(module, function_name, None)
            if callable(function):
                return function

        for class_name in class_names:
            analyzer_class = getattr(module, class_name, None)
            if analyzer_class is None:
                continue
            try:
                analyzer = analyzer_class()
            except Exception:
                continue

            for function_name in function_names:
                method = getattr(analyzer, function_name, None)
                if callable(method):
                    return method

    return None


def _extract_hm_affixes(value: Any) -> List[str]:
    if not isinstance(value, list):
        return []
    results: List[str] = []
    for item in value:
        if isinstance(item, Mapping):
            segment = item.get("seg")
            if segment:
                results.append(str(segment))
    return results


def _split_ud_features(value: str) -> Dict[str, str]:
    if not value:
        return {}
    feature_map: Dict[str, str] = {}
    for chunk in value.split("|"):
        if "=" not in chunk:
            continue
        key, raw_value = chunk.split("=", 1)
        clean_key = re.sub(r"\[.*?\]", "", key).strip().lower()
        if clean_key and raw_value:
            feature_map[clean_key] = raw_value.strip()
    return feature_map


def _extract_stem(candidate: Mapping[str, Any], lemma: str, token: str) -> str:
    stem_value = candidate.get("stem")
    if isinstance(stem_value, Mapping):
        segment = stem_value.get("seg")
        if segment:
            return str(segment)
    if isinstance(stem_value, str) and stem_value.strip():
        return stem_value
    root = candidate.get("root")
    if isinstance(root, str) and root.strip():
        return root
    return lemma or token


def _extract_features(candidate: Mapping[str, Any], pos: Optional[str]) -> Dict[str, str]:
    feature_map: Dict[str, str] = {}
    udfeats = candidate.get("udfeats")
    if isinstance(udfeats, str):
        feature_map.update(_split_ud_features(udfeats))

    raw_features = candidate.get("features")
    if isinstance(raw_features, Mapping):
        feature_map.update({str(key): str(val) for key, val in raw_features.items()})

    if pos:
        feature_map["pos"] = pos
    return normalize_features(feature_map)


def _score_for_candidate(candidate: Mapping[str, Any]) -> Optional[float]:
    return _coerce_score(
        candidate.get("score")
        or candidate.get("probability")
        or candidate.get("freq")
    )


def _confidence_for_candidate(candidate: Mapping[str, Any]) -> str:
    explicit = _coerce_confidence(candidate.get("confidence"))
    if candidate.get("confidence") is not None:
        return explicit

    pos = str(candidate.get("pos") or "").upper()
    if pos == "UNK":
        return "low"
    if candidate.get("lemma") or candidate.get("root"):
        return "high"
    return "medium"


def _candidate_to_analysis(candidate: Any, token: str) -> MorphAnalysis:
    if not isinstance(candidate, Mapping):
        text = str(candidate)
        return MorphAnalysis(
            surface=token,
            lemma=text,
            stem=text,
            source="hornmorpho",
            confidence="medium",
            score=None,
            raw={"value": candidate},
        )

    lemma = str(
        candidate.get("lemma")
        or candidate.get("lexeme")
        or candidate.get("citation")
        or candidate.get("root")
        or token
    )
    stem = _extract_stem(candidate, lemma=lemma, token=token)
    pos = candidate.get("pos") or candidate.get("part_of_speech") or candidate.get("category")
    pos_value = str(pos) if pos is not None else None
    features = _extract_features(candidate, pos=pos_value)

    prefixes = _as_list(candidate.get("prefixes") or candidate.get("prefix"))
    if not prefixes:
        prefixes = _extract_hm_affixes(candidate.get("pre"))

    suffixes = _as_list(candidate.get("suffixes") or candidate.get("suffix"))
    if not suffixes:
        suffixes = _extract_hm_affixes(candidate.get("suf"))

    return MorphAnalysis(
        surface=str(candidate.get("surface") or candidate.get("token") or token),
        lemma=lemma,
        stem=stem,
        pos=pos_value,
        features=features,
        prefixes=prefixes,
        suffixes=suffixes,
        source="hornmorpho",
        confidence=_confidence_for_candidate(candidate),
        score=_score_for_candidate(candidate),
        raw=dict(candidate),
    )


def _extract_analyses(raw: Any, token: str) -> List[MorphAnalysis]:
    if raw is None:
        return []

    if isinstance(raw, Mapping):
        if isinstance(raw.get("analyses"), list):
            candidates = raw.get("analyses", [])
        else:
            candidates = [raw]
    elif isinstance(raw, list):
        candidates = raw
    else:
        candidates = [raw]

    analyses = [_candidate_to_analysis(candidate, token) for candidate in candidates]
    analyses.sort(
        key=lambda item: (
            item.score if item.score is not None else -1.0,
            _CONFIDENCE_RANK.get(item.confidence, 1),
            len(item.stem),
        ),
        reverse=True,
    )
    return analyses


def _analyze_worker(payload: tuple[str, Dict[str, Any]]) -> Dict[str, Any]:
    token, settings = payload
    analyzer = HornMorphoAnalyzer(**settings)
    return analyzer.analyze(token)


class HornMorphoAnalyzer:
    """
    Engine wrapper that prefers HornMorpho and falls back to rules when needed.
    """

    def __init__(
        self,
        engine: str = "auto",
        language: str = "a",
        normalize: bool = True,
        min_stem_length: int = 2,
        max_iterations: int = 2,
        allow_fallback: bool = True,
        external_callable: Optional[Callable[[str], Any]] = None,
    ) -> None:
        if engine not in {"auto", "hornmorpho", "rules"}:
            raise ValueError("engine must be one of: 'auto', 'hornmorpho', 'rules'")
        self.engine = engine
        self.language = language
        self.normalize = normalize
        self.min_stem_length = min_stem_length
        self.max_iterations = max_iterations
        self.allow_fallback = allow_fallback
        self._external_callable = external_callable
        self._rules = RuleBasedStemmer(
            min_stem_length=min_stem_length,
            max_iterations=max_iterations,
        )

        if self._external_callable is None and engine in {"auto", "hornmorpho"}:
            self._external_callable = _discover_hornmorpho_callable(language=language)

    def _analyze_hornmorpho(self, token: str) -> List[MorphAnalysis]:
        if not callable(self._external_callable):
            return []
        raw = self._external_callable(token)
        return _extract_analyses(raw, token=token)

    def _build_result(
        self,
        token: str,
        normalized: str,
        engine_name: str,
        analyses: List[MorphAnalysis],
        start_time: float,
        error: Optional[str] = None,
    ) -> Dict[str, Any]:
        result = MorphResult(
            token=token,
            normalized=normalized,
            engine=engine_name,
            analyses=analyses,
            failed=not bool(analyses) and bool(error),
            error=error,
            elapsed_ms=(perf_counter() - start_time) * 1000.0,
        )
        return result.to_dict()

    def analyze(self, token: str) -> Dict[str, Any]:
        start_time = perf_counter()
        if token is None:
            return self._build_result(
                token=token,
                normalized=token,
                engine_name="none",
                analyses=[],
                start_time=start_time,
                error="token is None",
            )

        normalized = normalize_for_morphology(token) if self.normalize else token
        analyses: List[MorphAnalysis] = []
        engine_name = "rules"

        try:
            if self.engine == "rules":
                analyses = self._rules.analyze(normalized)
                engine_name = "rules"
            else:
                analyses = self._analyze_hornmorpho(normalized)
                if analyses:
                    engine_name = "hornmorpho"
                elif self.allow_fallback:
                    analyses = self._rules.analyze(normalized)
                    engine_name = "rules"
                elif self.engine == "hornmorpho":
                    return self._build_result(
                        token=token,
                        normalized=normalized,
                        engine_name="hornmorpho",
                        analyses=[],
                        start_time=start_time,
                        error="HornMorpho engine is unavailable",
                    )
        except Exception as exc:
            if self.allow_fallback:
                analyses = self._rules.analyze(normalized)
                engine_name = "rules"
                return self._build_result(
                    token=token,
                    normalized=normalized,
                    engine_name=engine_name,
                    analyses=analyses,
                    start_time=start_time,
                    error=f"HornMorpho failed: {exc}",
                )
            return self._build_result(
                token=token,
                normalized=normalized,
                engine_name="hornmorpho",
                analyses=[],
                start_time=start_time,
                error=str(exc),
            )

        return self._build_result(
            token=token,
            normalized=normalized,
            engine_name=engine_name,
            analyses=analyses,
            start_time=start_time,
        )

    def stem(self, token: str) -> str:
        return str(self.analyze(token).get("stem", token))

    def lemmatize(self, token: str) -> str:
        return str(self.analyze(token).get("lemma", token))

    def analyze_batch(
        self,
        tokens: Iterable[str],
        workers: int = 1,
        use_multiprocessing: bool = False,
    ) -> List[Dict[str, Any]]:
        token_list = list(tokens)
        if workers <= 1 or len(token_list) <= 1:
            return [self.analyze(token) for token in token_list]

        if use_multiprocessing:
            settings = {
                "engine": self.engine,
                "language": self.language,
                "normalize": self.normalize,
                "min_stem_length": self.min_stem_length,
                "max_iterations": self.max_iterations,
                "allow_fallback": self.allow_fallback,
            }
            payload = [(token, settings) for token in token_list]
            with ProcessPoolExecutor(max_workers=workers) as executor:
                return list(executor.map(_analyze_worker, payload))

        with ThreadPoolExecutor(max_workers=workers) as executor:
            return list(executor.map(self.analyze, token_list))


__all__ = ["HornMorphoAnalyzer"]
