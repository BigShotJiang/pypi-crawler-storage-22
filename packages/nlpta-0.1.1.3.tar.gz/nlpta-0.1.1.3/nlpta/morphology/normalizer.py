"""
Morphology-specific orthographic normalization helpers.
"""

import re

from .affixes import get_all_prefixes, get_all_suffixes


CHARACTER_FAMILY_GROUPS = [
    ("ሀሁሂሃሄህሆ", "ሐሑሒሓሔሕሖ", "ኀኁኂኃኄኅኆ"),
    ("ሰሱሲሳሴስሶ", "ሠሡሢሣሤሥሦ"),
    ("ፀፁፂፃፄፅፆ", "ጸጹጺጻጼጽጾ"),
    ("አኡኢኣኤእኦ", "ዐዑዒዓዔዕዖ"),
]

_NON_WORD_RE = re.compile(r"[^\u1200-\u137F]")
_MULTI_SPACE_RE = re.compile(r"\s+")


def _build_character_map() -> dict[str, str]:
    mapping: dict[str, str] = {}
    for family in CHARACTER_FAMILY_GROUPS:
        canonical = family[0]
        for variant in family[1:]:
            for source_char, target_char in zip(variant, canonical):
                mapping[source_char] = target_char
    return mapping


_CHARACTER_MAP = _build_character_map()
_TRANSLATION_TABLE = str.maketrans(_CHARACTER_MAP)


def normalize_characters(text: str) -> str:
    """
    Canonicalize orthographic character variants (e.g., ሐ -> ሀ).
    """
    if not text or not isinstance(text, str):
        return text
    return text.translate(_TRANSLATION_TABLE)


def normalize_for_morphology(token: str) -> str:
    """
    Pre-analysis normalization pipeline:
    1. Trim and collapse spacing.
    2. Normalize character variants.
    3. Remove non-Ge'ez symbols from token-level input.
    """
    if not token or not isinstance(token, str):
        return token

    normalized = _MULTI_SPACE_RE.sub(" ", token).strip()
    normalized = normalize_characters(normalized)
    normalized = _NON_WORD_RE.sub("", normalized)
    return normalized


def strip_known_affix_punctuation(token: str) -> str:
    """
    Conservative cleanup around affixes using known inventory.
    """
    if not token or not isinstance(token, str):
        return token

    normalized = normalize_for_morphology(token)
    if not normalized:
        return normalized

    prefixes = sorted(get_all_prefixes(), key=len, reverse=True)
    suffixes = sorted(get_all_suffixes(), key=len, reverse=True)

    for prefix in prefixes:
        if normalized.startswith(prefix):
            normalized = prefix + normalized[len(prefix) :]
            break
    for suffix in suffixes:
        if normalized.endswith(suffix):
            normalized = normalized[: -len(suffix)] + suffix
            break

    return normalized
