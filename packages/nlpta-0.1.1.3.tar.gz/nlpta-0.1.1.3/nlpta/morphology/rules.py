"""
Lightweight fallback morphology rules.
"""

from __future__ import annotations

from typing import List

from .base import MorphAnalysis
from .confidence import get_confidence
from .detection import detect_affixes, stem as detect_stem


def _rank_confidence(levels: List[str]) -> str:
    if not levels:
        return "medium"
    if "low" in levels:
        return "low"
    if all(level == "high" for level in levels):
        return "high"
    return "medium"


class RuleBasedStemmer:
    """
    Conservative rule-based fallback analyzer.
    """

    def __init__(self, min_stem_length: int = 2, max_iterations: int = 2) -> None:
        self.min_stem_length = min_stem_length
        self.max_iterations = max_iterations

    def stem(self, token: str) -> str:
        return detect_stem(
            token,
            min_stem_length=self.min_stem_length,
            max_iterations=self.max_iterations,
        )

    def lemmatize(self, token: str) -> str:
        return self.stem(token)

    def analyze(self, token: str) -> List[MorphAnalysis]:
        detected = detect_affixes(
            token,
            min_stem_length=self.min_stem_length,
            max_iterations=self.max_iterations,
        )
        prefixes = list(detected.get("prefixes", []))
        suffixes = list(detected.get("suffixes", []))
        stem_value = detected.get("stem", token)

        confidence_levels = [get_confidence(item) for item in prefixes + suffixes]
        analyses = [
            MorphAnalysis(
                surface=token,
                lemma=stem_value,
                stem=stem_value,
                prefixes=prefixes,
                suffixes=suffixes,
                source="rules",
                confidence=_rank_confidence(confidence_levels),
                score=1.0 if stem_value != token else 0.8,
                raw=detected,
            )
        ]

        # Preserve ambiguity by also returning the no-strip reading when affixes are detected.
        if prefixes or suffixes:
            analyses.append(
                MorphAnalysis(
                    surface=token,
                    lemma=token,
                    stem=token,
                    prefixes=[],
                    suffixes=[],
                    source="rules",
                    confidence="low",
                    score=0.3,
                    raw=detected,
                )
            )

        return analyses
