def _build_homophone_map():
    """
    Build canonical mappings for Amharic homophone character families.

    Each tuple preserves vowel slots while mapping variant families to a
    canonical family in the first position.
    """
    groups = [
        ("ሀሁሂሃሄህሆ", "ሐሑሒሓሔሕሖ", "ኀኁኂኃኄኅኆ"),
        ("ሰሱሲሳሴስሶ", "ሠሡሢሣሤሥሦ"),
        ("ፀፁፂፃፄፅፆ", "ጸጹጺጻጼጽጾ"),
        ("አኡኢኣኤእኦ", "ዐዑዒዓዔዕዖ"),
    ]

    mapping = {}
    for family in groups:
        canonical = family[0]
        for variant in family[1:]:
            for source_char, target_char in zip(variant, canonical):
                mapping[source_char] = target_char
    return mapping


CANONICAL_MAP = _build_homophone_map()

# Pre-compute translation table for performance (single pass)
_TRANSLATION_TABLE = str.maketrans(CANONICAL_MAP)


def normalize_characters(text: str) -> str:
    """
    Reduce orthographic variation by mapping Amharic homophone variants
    to canonical characters while preserving vowel slots.
    """
    if not text or not isinstance(text, str):
        return text

    return text.translate(_TRANSLATION_TABLE)
