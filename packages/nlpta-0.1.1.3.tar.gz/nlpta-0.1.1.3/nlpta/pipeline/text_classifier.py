from typing import List, Any

from nlpta.tokenization import tokenize
from nlpta.stopwords import remove_stopwords
from nlpta.features import (
    build_vocabulary,
    inverse_document_frequency,
    tfidf_vector,
    bag_of_words
)
from nlpta.models import MultinomialNaiveBayes

# Text Classifier
class TextClassifier:
    """
    High-level text classification pipeline.

    Supports:
    - BoW
    - TF-IDF
    - Multinomial Naive Bayes
    """

    def __init__(
        self,
        vectorizer: str = "tfidf",
        language: str = "en",
        remove_stopword: bool = True,
        alpha: float = 1.0
    ):
        self.vectorizer = vectorizer
        self.language = language
        self.remove_stopword = remove_stopword

        self.vocabulary_ = None
        self.idf_ = None
        self.model = MultinomialNaiveBayes(alpha=alpha)

# Internal Preprocessing
    def _preprocess(self, texts: List[str]) -> List[List[str]]:
        processed = []

        for text in texts:
            tokens = tokenize(text, level="word")

            if self.remove_stopword:
                tokens = remove_stopwords(tokens, language=self.language)

            processed.append(tokens)

        return processed

#Vectorization
    def _vectorize(self, tokenized_texts: List[List[str]]):
        vectors = []

        for tokens in tokenized_texts:
            if self.vectorizer == "bow":
                vec = bag_of_words(tokens, self.vocabulary_)
            elif self.vectorizer == "tfidf":
                vec = tfidf_vector(tokens, self.vocabulary_, self.idf_)
            else:
                raise ValueError("Unsupported vectorizer type")

            vectors.append(vec)

        return vectors

#Fit Method
    def fit(self, texts: List[str], labels: List[Any]):

        tokenized = self._preprocess(texts)

        self.vocabulary_ = build_vocabulary(tokenized)

        if self.vectorizer == "tfidf":
            self.idf_ = inverse_document_frequency(tokenized)

        X = self._vectorize(tokenized)

        self.model.fit(X, labels)

        return self
    
#Predict Method
    def predict(self, texts: List[str]) -> List[Any]:

        if self.vocabulary_ is None:
            raise ValueError("Model has not been fitted yet")

        tokenized = self._preprocess(texts)
        X = self._vectorize(tokenized)

        return self.model.predict(X)

# Predict Probabilities
    def predict_proba(self, texts: List[str]):

        if self.vocabulary_ is None:
            raise ValueError("Model has not been fitted yet")

        tokenized = self._preprocess(texts)
        X = self._vectorize(tokenized)

        return self.model.predict_proba(X)
