from pathlib import Path

PACKAGE_STOPWORDS_PATH = Path(__file__).resolve().parent / "data" / "stopwords.txt"
REPO_STOPWORDS_PATH = Path(__file__).resolve().parents[2] / "data" / "stopwords.txt"


def _resolve_default_stopwords_path() -> Path:
    if PACKAGE_STOPWORDS_PATH.exists():
        return PACKAGE_STOPWORDS_PATH
    if REPO_STOPWORDS_PATH.exists():
        return REPO_STOPWORDS_PATH
    raise FileNotFoundError(
        "Stopwords file not found. Expected package data at "
        f"'{PACKAGE_STOPWORDS_PATH}' or repository data at '{REPO_STOPWORDS_PATH}'."
    )


def load_stopwords(path=None):
    """
    Load stopwords from a file.

    Args:
        path (str | Path | None): Optional path to the stopwords file.
            If omitted, package data is used first, then repository fallback.

    Returns:
        set[str]: A set of stopwords.
    """
    resolved_path = Path(path) if path is not None else _resolve_default_stopwords_path()

    if not resolved_path.exists():
        raise FileNotFoundError(f"Stopwords file not found at '{resolved_path}'.")

    stopwords = set()
    with resolved_path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                stopwords.add(line)

    return stopwords


def remove_stopwords(tokens, stopwords=None):
    """
    Remove stopwords from a list of tokens.

    Args:
        tokens (list[str]): The list of tokens.
        stopwords (set[str] | None): The set of stopwords.
            If None, default stopwords are loaded from disk.

    Returns:
        list[str]: The filtered list of tokens.
    """
    if stopwords is None:
        stopwords = load_stopwords()

    return [token for token in tokens if token not in stopwords]
