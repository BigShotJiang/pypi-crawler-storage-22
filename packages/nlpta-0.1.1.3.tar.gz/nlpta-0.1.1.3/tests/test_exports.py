import nlpta
from nlpta.tokenization import tokenize


def test_top_level_exports_exist():
    assert callable(nlpta.load_stopwords)
    assert callable(nlpta.load_embeddings)
    assert callable(nlpta.generate_ngrams)
    assert callable(nlpta.analyze)
    assert callable(nlpta.analyze_batch)
    assert callable(nlpta.lemmatize)
    assert callable(nlpta.detect_affixes)
    assert callable(nlpta.stem)


def test_tokenize_export():
    assert tokenize("a b c") == ["a", "b", "c"]
