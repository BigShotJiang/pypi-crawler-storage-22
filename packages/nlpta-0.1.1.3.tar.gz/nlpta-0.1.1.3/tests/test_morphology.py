from nlpta.morphology import analyze, analyze_batch, detect_affixes, lemmatize, stem
from nlpta.morphology.benchmark import evaluate_normalization_impact
from nlpta.morphology.hornmorpho import HornMorphoAnalyzer


def test_stem_strips_known_prefix_and_suffix():
    assert stem("እስከቤትነት") == "ቤት"


def test_stem_prevents_over_stemming_with_min_length_guard():
    assert stem("ነት", min_stem_length=2) == "ነት"


def test_detect_affixes_returns_stemmed_form():
    result = detect_affixes("የቤትነት")
    assert result["prefixes"] == ["የ"]
    assert result["suffixes"] == ["ነት"]
    assert result["stem"] == "ቤት"


def test_single_word_analysis_shape_and_best_fields():
    result = analyze("የቤትነት", engine="rules")
    assert result["token"] == "የቤትነት"
    assert result["engine"] == "rules"
    assert isinstance(result["analyses"], list)
    assert len(result["analyses"]) >= 1
    assert result["stem"] == "ቤት"
    assert result["lemma"] == "ቤት"


def test_ambiguous_word_returns_multiple_analyses():
    result = analyze("የቤትነት", engine="rules")
    assert len(result["analyses"]) >= 2


def test_unknown_word_analysis_does_not_fail():
    result = analyze("አብይ", engine="rules")
    assert result["failed"] is False
    assert result["stem"] == "አብይ"
    assert result["lemma"] == "አብይ"


def test_batch_processing_returns_aligned_results():
    words = ["የቤትነት", "አብይ", "እስከቤትነት"]
    results = analyze_batch(words, engine="rules", workers=2)
    assert len(results) == len(words)
    assert [item["token"] for item in results] == words


def test_normalization_behavior_for_character_variants():
    normalized = analyze("ሐውልት", engine="rules", normalize=True)
    raw = analyze("ሐውልት", engine="rules", normalize=False)
    assert normalized["normalized"] == "ሀውልት"
    assert raw["normalized"] == "ሐውልት"


def test_lemmatize_and_stem_entry_points():
    assert lemmatize("የቤትነት", engine="rules") == "ቤት"
    assert stem("የቤትነት", engine="rules") == "ቤት"


def test_hornmorpho_adapter_supports_hm_style_output():
    hm_output = [
        {
            "token": "የቤታችን",
            "lemma": "ቤት",
            "pos": "N",
            "stem": {"seg": "ቤት"},
            "pre": [{"seg": "የ", "pos": "ADP"}, ""],
            "suf": ["", "", {"seg": "ኣችን", "pos": "PRON"}],
            "udfeats": "Case=Gen|Number[psor]=Plur|Person[psor]=1",
            "freq": 2109,
        }
    ]
    analyzer = HornMorphoAnalyzer(
        engine="hornmorpho",
        allow_fallback=False,
        external_callable=lambda token: hm_output,
    )
    result = analyzer.analyze("የቤታችን")
    assert result["engine"] == "hornmorpho"
    assert result["stem"] == "ቤት"
    assert result["lemma"] == "ቤት"
    assert result["prefixes"] == ["የ"]
    assert result["suffixes"] == ["ኣችን"]
    assert result["analyses"][0]["features"]["case"] == "Gen"
    assert result["analyses"][0]["features"]["number"] == "Plur"


def test_hornmorpho_adapter_handles_multiple_analyses():
    hm_output = [
        {"token": "አበበ", "lemma": "አበበ", "pos": "V", "freq": 8},
        {"token": "አበበ", "lemma": "አበበ", "pos": "PROPN", "freq": 15},
    ]
    analyzer = HornMorphoAnalyzer(
        engine="hornmorpho",
        allow_fallback=False,
        external_callable=lambda token: hm_output,
    )
    result = analyzer.analyze("አበበ")
    assert result["engine"] == "hornmorpho"
    assert len(result["analyses"]) == 2
    assert result["analyses"][0]["pos"] == "PROPN"
    assert result["analyses"][1]["pos"] == "V"


def test_normalization_impact_metric_improves_on_gold_samples():
    metrics = evaluate_normalization_impact(engine="rules")
    assert metrics["accuracy_with_normalization"] > metrics["accuracy_without_normalization"]
