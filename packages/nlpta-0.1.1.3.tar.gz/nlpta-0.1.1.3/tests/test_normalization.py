from nlpta.normalization.characters import normalize_characters


def test_normalize_characters_handles_homophone_families():
    assert normalize_characters("ሐሑሒሓሔሕሖ") == "ሀሁሂሃሄህሆ"
    assert normalize_characters("ጸጹጺጻጼጽጾ") == "ፀፁፂፃፄፅፆ"
    assert normalize_characters("ዐዑዒዓዔዕዖ") == "አኡኢኣኤእኦ"
