"""ELM web search functions"""

from .run import web_search_links_as_docs
