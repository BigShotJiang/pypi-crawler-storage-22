"""CLI entrypoints for nlweb-core."""

import argparse
import importlib.resources
import shutil
import sys
from pathlib import Path


def _copy_example_config(dest: Path, force: bool = False) -> None:
    """Copy the bundled example config.yaml to dest."""
    if dest.exists() and not force:
        print(
            f"Warning: {dest} already exists. Use --force to overwrite.",
            file=sys.stderr,
        )
        sys.exit(1)

    data_pkg = importlib.resources.files("nlweb_core.data")
    source = data_pkg.joinpath("config.yaml")

    with importlib.resources.as_file(source) as src_path:
        shutil.copy2(src_path, dest)

    print(f"Created {dest}")


def main() -> None:
    """Entry point for the nlweb-init CLI command."""
    parser = argparse.ArgumentParser(
        description="Initialize an NLWeb project with an example configuration"
    )
    parser.add_argument(
        "dest",
        type=Path,
        help="Output path for the config file (e.g. config.yaml)",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite an existing file",
    )
    args = parser.parse_args()

    _copy_example_config(dest=args.dest, force=args.force)
