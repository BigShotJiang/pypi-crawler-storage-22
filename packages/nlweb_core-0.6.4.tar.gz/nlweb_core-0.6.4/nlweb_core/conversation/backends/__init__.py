# Copyright (c) 2025 Microsoft Corporation.
# Licensed under the MIT License

"""
Conversation storage backends.

WARNING: This code is under development and may undergo changes in future releases.
Backwards compatibility is not guaranteed at this time.
"""
