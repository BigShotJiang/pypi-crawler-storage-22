"""Bundled data files for nlweb-core."""
