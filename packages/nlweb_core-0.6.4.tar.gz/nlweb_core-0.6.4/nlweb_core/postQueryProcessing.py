# Copyright (c) 2025 Microsoft Corporation.
# Licensed under the MIT License

"""
Post-query processing for NLWeb handlers.
Handles summarization and other post-ranking tasks.

WARNING: This code is under development and may undergo changes in future releases.
Backwards compatibility is not guaranteed at this time.
"""

from collections.abc import Awaitable, Callable

from nlweb_core.handler import get_site_prompt_file, get_site_summarization_prompt
from nlweb_core.summarizer import (
    ResultsSummarizer,
    create_default_summarizer,
    create_hindi_summarizer,
    create_summarizer_from_prompt_ref,
)


class PostQueryProcessing:
    """Post-processing after ranking is complete."""

    def __init__(
        self, summarizer: ResultsSummarizer | None = None, site: str | None = None
    ):
        """Initialize post-query processing.

        Args:
            summarizer: Optional ResultsSummarizer instance. If not provided,
                       a site-appropriate summarizer will be created.
            site: Site domain (e.g., 'aajtak.in'). Used to select language-specific
                 summarizer if no custom summarizer is provided.

        Note:
            This constructor is deprecated for site-specific configuration.
            Use `create_for_site()` instead to load prompts from site config.
        """
        if summarizer:
            self._summarizer = summarizer
        elif site == "aajtak.in":
            self._summarizer = create_hindi_summarizer()
        else:
            self._summarizer = create_default_summarizer()

    @classmethod
    async def create_for_site(
        cls, site: str | None = None, summarizer: ResultsSummarizer | None = None
    ) -> "PostQueryProcessing":
        """Create PostQueryProcessing with site-specific configuration.

        This factory method loads the summarization prompt reference from site config
        and creates the appropriate summarizer.

        Args:
            site: Site domain (e.g., 'aajtak.in'). Will look up summarization_prompt
                 from site config.
            summarizer: Optional custom ResultsSummarizer. If provided, site config
                       is ignored.

        Returns:
            PostQueryProcessing instance configured for the site.
        """
        if summarizer:
            return cls(summarizer=summarizer)

        # Get site-specific prompt reference and optional custom prompt file
        prompt_ref = await get_site_summarization_prompt(site)
        prompt_file = await get_site_prompt_file(site)

        if prompt_ref:
            # Load prompt from custom file (if configured) or default XML
            try:
                site_summarizer = create_summarizer_from_prompt_ref(
                    prompt_ref, prompt_file=prompt_file
                )
                return cls(summarizer=site_summarizer)
            except ValueError:
                # Fall through to defaults if prompt_ref is invalid
                pass

        # Fall back to hardcoded defaults (backward compatibility)
        return cls(site=site)

    async def process(
        self,
        final_ranked_answers: list[dict],
        query_text: str,
        modes: list[str],
        send_results: Callable[[list], Awaitable[None]],
        start_num: int = 0,
    ) -> None:
        """Execute post-query processing based on mode.

        Args:
            final_ranked_answers: The ranked search results.
            query_text: The query text (decontextualized or original).
            modes: List of processing modes (e.g., ['list', 'summarize']).
            send_results: Async callback to send results to the client.
        """
        if "summarize" in modes:
            await self._summarize_results(
                final_ranked_answers, query_text, send_results, start_num
            )

    async def _summarize_results(
        self,
        results: list[dict],
        query_text: str,
        send_results: Callable[[list], Awaitable[None]],
        start_num: int = 0,
    ) -> None:
        """Generate and send a summary of the top results."""
        if not results:
            return

        summary_result = await self._summarizer.summarize(
            query=query_text, results=results[:3], start_num=start_num
        )

        if summary_result:
            await send_results([summary_result.to_result_object()])
