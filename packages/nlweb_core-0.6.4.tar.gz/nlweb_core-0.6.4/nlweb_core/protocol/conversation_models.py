# Copyright (c) 2025 Microsoft Corporation.
# Licensed under the MIT License

"""
Pydantic models for Conversation API endpoints.

These models define the request/response structures for conversation management,
following the same pattern as the NLWeb /ask endpoint.
"""

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from nlweb_core.protocol.models import AskRequest, Meta, ResultObject

# ============================================================================
# Request Models
# ============================================================================


class ConversationFilter(BaseModel):
    """Filter criteria for listing conversations."""

    site: str | None = Field(None, description="Filter by site")
    date_from: datetime | None = Field(None, description="Start date filter")
    date_to: datetime | None = Field(None, description="End date filter")


class Pagination(BaseModel):
    """Pagination parameters."""

    limit: int = Field(20, ge=1, le=100, description="Number of items to return")
    offset: int = Field(0, ge=0, description="Number of items to skip")


class ListConversationsRequest(BaseModel):
    """Request to list conversations for a user."""

    meta: Meta = Field(..., description="Request metadata with user info")
    filter: ConversationFilter | None = Field(None, description="Filter criteria")
    pagination: Pagination | None = Field(
        default_factory=Pagination,  # type: ignore[reportArgumentType]
        description="Pagination parameters",
    )


class GetConversationRequest(BaseModel):
    """Request to get messages for a specific conversation."""

    meta: Meta = Field(..., description="Request metadata with user info")
    pagination: Pagination | None = Field(
        default_factory=lambda: Pagination(limit=100),  # type: ignore[arg-type]
        description="Pagination parameters",
    )


class DeleteConversationRequest(BaseModel):
    """Request to delete a conversation."""

    meta: Meta = Field(..., description="Request metadata with user info")


class ConversationSearchFilter(BaseModel):
    """Search filter criteria."""

    site: str | None = None
    date_from: datetime | None = None
    date_to: datetime | None = None


class ConversationSearch(BaseModel):
    """Search parameters for conversations."""

    query: str = Field(..., description="Search query text")
    filter: ConversationSearchFilter | None = None


class SearchConversationsRequest(BaseModel):
    """Request to search conversations."""

    meta: Meta = Field(..., description="Request metadata with user info")
    search: ConversationSearch = Field(..., description="Search parameters")
    pagination: Pagination | None = Field(
        default_factory=Pagination,  # type: ignore[reportArgumentType]
        description="Pagination parameters",
    )


# ============================================================================
# Response Models
# ============================================================================


class ConversationPreview(BaseModel):
    """Preview of conversation content."""

    query: str = Field(..., description="First query in conversation")
    result_count: int = Field(..., description="Number of results returned")


class ConversationSummary(BaseModel):
    """Summary of a conversation."""

    conversation_id: str
    message_count: int
    first_message_timestamp: datetime
    last_message_timestamp: datetime
    site: str | None
    preview: ConversationPreview


class PaginationResponse(BaseModel):
    """Pagination metadata in response."""

    total: int = Field(..., description="Total number of items")
    limit: int = Field(..., description="Items per page")
    offset: int = Field(..., description="Current offset")
    has_more: bool = Field(..., description="Whether more items exist")


class ListConversationsResponse(BaseModel):
    """Response with list of conversations."""

    field_meta: dict[str, Any] = Field(..., alias="_meta")
    conversations: list[ConversationSummary]
    pagination: PaginationResponse


class ConversationInfo(BaseModel):
    """Information about a conversation."""

    conversation_id: str
    user_id: str
    created_at: datetime
    updated_at: datetime


class ConversationMessage(BaseModel):
    """A single message in the conversation."""

    message_id: str
    timestamp: datetime
    request: AskRequest
    results: list[ResultObject] | None
    metadata: dict[str, Any] | None


class GetConversationResponse(BaseModel):
    """Response with conversation messages."""

    field_meta: dict[str, Any] = Field(..., alias="_meta")
    conversation: ConversationInfo
    messages: list[ConversationMessage]
    pagination: PaginationResponse


class DeleteConversationResponse(BaseModel):
    """Response confirming conversation deletion."""

    field_meta: dict[str, Any] = Field(..., alias="_meta")
    conversation_id: str
    status: str = "deleted"
    messages_deleted: int


class SearchMatch(BaseModel):
    """A search result match."""

    conversation_id: str
    message_id: str
    match_type: str = Field(..., description="Type of match: query, result, metadata")
    match_text: str = Field(..., description="Text that matched")
    timestamp: datetime
    context: dict[str, Any] = Field(..., description="Context around the match")


class SearchConversationsResponse(BaseModel):
    """Response with search results."""

    field_meta: dict[str, Any] = Field(..., alias="_meta")
    results: list[SearchMatch]
    pagination: PaginationResponse


class ErrorResponse(BaseModel):
    """Error response."""

    field_meta: dict[str, Any] = Field(..., alias="_meta")
    error: dict[str, str] = Field(
        ..., description="Error details with code and message"
    )
