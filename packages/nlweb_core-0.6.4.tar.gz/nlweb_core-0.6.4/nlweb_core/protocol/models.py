# NLWeb Protocol v0.54 Data Models
# Compliant with NLWeb Protocol Specification v0.54

from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

# ============================================================================
# Request Models
# ============================================================================


class Query(BaseModel):
    """
    Query section - specifies the user's current request.

    Required field:
    - text: The natural language query string

    Fields with defaults:
    - site: Site filter for the query (default: "all")
    - num_results: Number of results to retrieve (default: 50)
    - max_results: Maximum results after ranking (default: 9)
    - min_score: Minimum relevance score threshold (default: 51)

    Optional fields:
    - decontextualized_query: Decontextualized version after processing context

    Properties:
    - effective_query: Returns decontextualized_query if set, otherwise text
    """

    model_config = ConfigDict(extra="forbid")

    text: str = Field(..., description="Natural language query from user (required)")
    decontextualized_query: str | None = Field(
        default=None,
        description="Decontextualized version of the query after processing context (internal use)",
    )
    site: str = Field(
        default="all",
        description='Site filter for the query (use "all" for cross-site search)',
    )
    num_results: int = Field(
        default=50,
        ge=1,
        le=1000,
        description="Number of results to retrieve from the index",
    )
    max_results: int = Field(
        default=9, ge=1, le=100, description="Maximum number of results after ranking"
    )
    min_score: int = Field(
        default=51,
        ge=0,
        le=100,
        description="Minimum relevance score threshold for results",
    )

    @property
    def effective_query(self) -> str:
        """Returns decontextualized_query if set, otherwise text."""
        return self.decontextualized_query or self.text


class Context(BaseModel):
    """Context section - provides contextual information about the query."""

    model_config = ConfigDict(populate_by_name=True, ser_json_by_alias=True)  # type: ignore[call-overload]

    schema_type: str | None = Field(  # type: ignore[call-overload]
        default="ConversationalContext",
        alias="@type",
        serialization_alias="@type",
        description="Type of Context, determines attributes and semantics (default: ConversationalContext)",
    )
    prev: list[str] | None = Field(
        default=None,
        description="Array of previous queries in the conversation (optional)",
    )
    text: str | None = Field(
        default=None,
        description="Free-form text paragraph describing the broader context (optional)",
    )
    memory: list[str] | None = Field(
        default=None,
        description="Persistent information about the user's preferences, constraints, or characteristics (optional)",
    )


class Prefer(BaseModel):
    """Prefer section - specifies expectations for response format and delivery."""

    streaming: bool | None = Field(
        default=None,
        description="Boolean indicating whether streaming response is desired (optional)",
    )
    response_format: str | None = Field(
        default="chatgpt_app",
        description='Preferred response format: "chatgpt_app" (default) or "conv_search" (optional)',
    )
    mode: str | None = Field(
        default=None,
        description="Response mode such as list, summarize, etc. (optional)",
    )
    accept_language: str | None = Field(
        default=None,
        alias="accept-language",
        description="Language code for the response (e.g., en) (optional)",
    )
    user_agent: str | None = Field(
        default=None,
        alias="user-agent",
        description="Type of client making the request (mobile, desktop, etc.) (optional)",
    )


class SessionContext(BaseModel):
    """Session context for tracking state across requests."""

    conversation_id: str | None = Field(
        default=None, description="Conversation identifier (optional)"
    )
    state_token: str | None = Field(
        default=None, description="Encrypted state blob (optional)"
    )


class Meta(BaseModel):
    """Meta section - contains metadata about the request."""

    api_version: str | None = Field(
        default=None, description="API version number being used (optional)"
    )
    session_context: SessionContext | None = Field(
        default=None, description="Session state context (optional)"
    )
    user: dict[str, Any] | None = Field(
        default=None, description="User identifier object (optional)"
    )
    remember: bool | None = Field(
        default=None,
        description="Whether to remember this interaction in conversation history (optional)",
    )
    start_num: int | None = Field(
        default=0, description="The start offset for the returned results"
    )


class AskRequest(BaseModel):
    """NLWeb Ask Request - v0.54 compliant."""

    query: Query = Field(
        ...,
        description="Specifies the user's current request and associated query parameters (required)",
    )
    context: Context | None = Field(
        default=None,
        description="Provides contextual information about the query (optional)",
    )
    prefer: Prefer | None = Field(
        default=None,
        description="Specifies expectations for how the response should be formatted and delivered (optional)",
    )
    meta: Meta | None = Field(
        default=None,
        description="Contains metadata about the request itself (optional)",
    )


# ============================================================================
# Response Models
# ============================================================================


class ResponseType(Enum):
    """Response type enumeration."""

    Answer = "Answer"
    Elicitation = "Elicitation"
    Promise = "Promise"
    Failure = "Failure"


class AskResponseMeta(BaseModel):
    """Response metadata section."""

    response_type: str = Field(
        ...,
        description="Type of response: Answer | Elicitation | Promise | Failure (required)",
    )
    response_format: str | None = Field(
        default=None,
        description='The response format of the answer: "chatgpt_app" or "conv_search" (optional)',
    )
    version: str = Field(..., description="API version number (required)")
    decontextualized_query: str | None = Field(
        default=None,
        description="Decontextualized version of the query (included when context was used) (optional)",
    )
    session_context: SessionContext | None = Field(
        default=None,
        description="Session context to include in future calls (optional)",
    )


class Grounding(BaseModel):
    """Grounding information for provenance."""

    source_urls: list[str] | None = Field(
        default=None, description="Source URLs for citations (optional)"
    )
    citations: list[str] | None = Field(
        default=None, description="Citation references (optional)"
    )


class Action(BaseModel):
    """Action definition for result objects."""

    model_config = ConfigDict(populate_by_name=True, ser_json_by_alias=True)  # type: ignore[call-overload]

    schema_context: str | None = Field(  # type: ignore[call-overload]
        default=None,
        alias="@context",
        serialization_alias="@context",
        description="Schema context (e.g., http://schema.org/) (optional)",
    )
    schema_type: str | None = Field(  # type: ignore[call-overload]
        default=None,
        alias="@type",
        serialization_alias="@type",
        description="Action type using schema.org vocabulary (e.g., AddToCartAction) (optional)",
    )
    name: str | None = Field(default=None, description="Action name (optional)")
    description: str | None = Field(
        default=None, description="Action description (optional)"
    )
    protocol: str | None = Field(
        default=None, description="Protocol (e.g., HTTP, MCP, A2A) (optional)"
    )
    method: str | None = Field(
        default=None, description="HTTP method (e.g., POST, GET) (optional)"
    )
    endpoint: str | None = Field(
        default=None, description="Action endpoint URL (optional)"
    )
    params: dict[str, Any] | None = Field(
        default=None, description="Action-specific parameters (optional)"
    )


class ResultObject(BaseModel):
    """Individual result object with semi-structured data."""

    model_config = ConfigDict(
        extra="allow", populate_by_name=True, ser_json_by_alias=True
    )  # type: ignore[call-overload]

    schema_type: str | None = Field(  # type: ignore[call-overload]
        default=None,
        alias="@type",
        serialization_alias="@type",
        description="Object type using schema.org vocabulary (e.g., Restaurant, Movie, Product, Recipe) (optional)",
    )
    grounding: Grounding | None = Field(
        default=None, description="Provenance information (optional)"
    )
    actions: list[Action] | None = Field(
        default=None,
        description="Executable actions associated with this item (optional)",
    )


class Promise(BaseModel):
    """Promise object for async operations."""

    token: str = Field(..., description="Promise token for checking status (required)")
    estimated_time: int | None = Field(
        default=None, description="Estimated time to completion in seconds (optional)"
    )


class Question(BaseModel):
    """Elicitation question."""

    id: str = Field(..., description="Question identifier (required)")
    text: str = Field(..., description="Question text (required)")
    type: str = Field(
        ...,
        description="Question type (e.g., single_select, multi_select, text) (required)",
    )
    options: list[str] | None = Field(
        default=None, description="Options for select-type questions (optional)"
    )


class Elicitation(BaseModel):
    """Elicitation object when agent needs more information."""

    text: str = Field(
        ..., description="Introductory text for the elicitation (required)"
    )
    questions: list[Question] = Field(
        ..., description="List of questions to ask (required)"
    )


class Error(BaseModel):
    """Error object for failure responses."""

    code: str = Field(..., description="Error code (required)")
    message: str = Field(..., description="Error message (required)")


# Answer response models (two formats supported)


class TextContent(BaseModel):
    """Text content for ChatGPT app format."""

    Type: Literal["text"] = Field(..., description='Must be "text" (required)')
    Text: str = Field(..., description="Natural language description (required)")


class AnswerResponseConvSearch(BaseModel):
    """Answer response for conversational search format (conv_search)."""

    field_meta: AskResponseMeta = Field(
        ..., alias="_meta", description="Response metadata (required)"
    )
    results: list[ResultObject] = Field(
        ..., description="Array of typed semi-structured result objects (required)"
    )


class AnswerResponseChatGPT(BaseModel):
    """Answer response for ChatGPT app format (chatgpt_app)."""

    field_meta: AskResponseMeta = Field(
        ..., alias="_meta", description="Response metadata (required)"
    )
    content: list[TextContent] = Field(
        ..., description="Natural language descriptions for LLM consumption (required)"
    )
    structuredData: list[ResultObject] = Field(
        ..., description="Structured data for client consumption (required)"
    )


class PromiseResponse(BaseModel):
    """Promise response for async operations."""

    field_meta: AskResponseMeta = Field(
        ..., alias="_meta", description="Response metadata (required)"
    )
    promise: Promise = Field(..., description="Promise object (required)")


class ElicitationResponse(BaseModel):
    """Elicitation response when more information is needed."""

    field_meta: AskResponseMeta = Field(
        ..., alias="_meta", description="Response metadata (required)"
    )
    elicitation: Elicitation = Field(..., description="Elicitation object (required)")


class FailureResponse(BaseModel):
    """Failure response."""

    field_meta: AskResponseMeta = Field(
        ..., alias="_meta", description="Response metadata (required)"
    )
    error: Error = Field(..., description="Error object (required)")


# ============================================================================
# Await Models
# ============================================================================


class AwaitRequest(BaseModel):
    """Await request to check status of a promise."""

    promise_token: str = Field(
        ..., description="Promise token from previous response (required)"
    )
    action: Literal["checkin", "cancel"] = Field(
        ..., description="Action to perform: checkin or cancel (required)"
    )
    meta: Meta | None = Field(default=None, description="Request metadata (optional)")


# ============================================================================
# Legacy support models (kept for compatibility with existing code)
# ============================================================================


class Agent(BaseModel):
    model_config = ConfigDict(populate_by_name=True, ser_json_by_alias=True)  # type: ignore[call-overload]

    schema_type: str = Field(  # type: ignore[call-overload]
        ...,
        alias="@type",
        serialization_alias="@type",
        description='Type of agent, e.g., "Search Agent" or "Analytics Agent". (required)',
    )
    agentSpec: dict[str, Any] = Field(
        ...,
        description="Agent specification - structure will depend on agent type (required)",
    )


class Resource(BaseModel):
    uri: str | None = Field(
        default=None,
        description="Resource identifier/template reference (optional)",
    )
    mimeType: str | None = Field(
        default=None,
        description="MIME type (optional)",
    )
    text: str | None = Field(default=None, description="Raw content (optional)")
    data: dict[str, Any] | list[dict[str, Any]] = Field(
        ...,
        description="Structured data payload (required)",
    )


class ResourceContent(BaseModel):
    type: Literal["resource"] = Field(..., description='must be "resource"')
    resource: Resource = Field(..., description="Resource details")


class ClientType(Enum):
    mobile = "mobile"
    desktop = "desktop"
    tablet = "tablet"
    web = "web"


class ReturnResponse(BaseModel):
    streaming: bool | None = Field(
        default=True,
        description="Boolean indicating whether streaming response is desired (optional)",
    )
    format: str | None = Field(
        default=None,
        description="Response format specification (optional)",
    )
    mode: str | None = Field(default=None, description="Response mode (optional)")
    lang: str | None = Field(
        default=None,
        description="Language code (optional)",
    )
    client_type: ClientType | None = Field(
        default=None,
        description="Type of client (optional)",
    )


class WhoRequest(BaseModel):
    query: str = Field(
        ..., description="Natural language query for agent discovery (required)"
    )
    streaming: bool | None = Field(
        default=True, description="Enable streaming response (optional)"
    )
    conversation_id: str | None = Field(
        default=None,
        description="Conversational identifier (optional)",
    )
    constr: dict[str, Any] | None = Field(
        default=None, description="Additional Constraints (optional)"
    )


class WhoResponseMeta(BaseModel):
    conversation_id: str | None = Field(
        default=None,
        description="Conversational identifier (optional)",
    )
    version: str | None = Field(default=None, description="Protocol version (optional)")


class WhoResponse(BaseModel):
    field_meta: WhoResponseMeta = Field(
        ..., alias="_meta", description="Metadata about the response"
    )
    content: list[TextContent | ResourceContent] = Field(
        ...,
        description="Array of content items containing agent descriptions",
        min_length=1,
    )
