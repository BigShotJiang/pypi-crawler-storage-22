# Copyright (c) 2025 Microsoft Corporation.
# Licensed under the MIT License

"""
Query analysis handler that dynamically loads and executes enabled query analysis modules.

WARNING: This code is under development and may undergo changes in future releases.
Backwards compatibility is not guaranteed at this time.
"""

import asyncio
import importlib
import logging
import os
from xml.etree import ElementTree as ET

from nlweb_core.query_analysis.response_models import get_response_model
from nlweb_core.utils import fill_prompt_variables

logger = logging.getLogger(__name__)

# Load query_analysis.xml once at module level
query_analysis_tree = None

# Cache for custom prompt files (keyed by absolute path)
_custom_tree_cache: dict[str, ET.Element] = {}


def read_xml_file(file_path):
    try:
        return ET.parse(file_path).getroot()
    except Exception:
        raise


def load_prompt_tree_from_file(file_path: str):
    """
    Load a custom prompt tree from an external XML file.

    This allows sites to provide their own prompt definitions in external XML files,
    enabling customization without modifying the nlweb-core package.

    Args:
        file_path: Path to XML file (absolute or relative to working directory)

    Returns:
        Parsed XML ElementTree root node

    Raises:
        FileNotFoundError: If the specified file doesn't exist
        ET.ParseError: If the XML is malformed

    Example:
        # In config.yaml:
        site_config:
          prompts:
            sites:
              mysite.com:
                prompt_file: "/app/prompts/custom_prompts.xml"

        # In handler code:
        custom_tree = load_prompt_tree_from_file("/app/prompts/custom_prompts.xml")
        handler = DefaultQueryAnalysisHandler(request, root_node=custom_tree, ...)
    """
    # Convert to absolute path if relative
    if not os.path.isabs(file_path):
        file_path = os.path.abspath(file_path)

    if file_path in _custom_tree_cache:
        return _custom_tree_cache[file_path]

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Prompt file not found: {file_path}")

    logger.info(f"Loading custom prompt tree from: {file_path}")
    tree = read_xml_file(file_path)
    _custom_tree_cache[file_path] = tree
    return tree


# Initialize on module load
try:
    # Get the directory where this module is located
    module_dir = os.path.dirname(__file__)
    query_analysis_xml_path = os.path.join(module_dir, "query_analysis.xml")

    query_analysis_tree = read_xml_file(query_analysis_xml_path)

    # Try to load decontextualizer.xml if it exists
    decontextualizer_xml_path = os.path.join(module_dir, "decontextualizer.xml")
    if os.path.exists(decontextualizer_xml_path):
        decontextualizer_tree = read_xml_file(decontextualizer_xml_path)
    else:
        decontextualizer_tree = query_analysis_tree
except Exception:
    import traceback

    traceback.print_exc()
    logger.error("Error loading query analysis XML files", exc_info=True)
    raise


class QueryAnalysisHandler:
    """
    Handler that executes enabled query analysis modules in parallel.

    Each enabled QueryAnalysis node in the XML configuration is dynamically loaded,
    instantiated, and executed asynchronously. Results are stored in the results
    dictionary with the ref attribute as the key.
    """

    def __init__(self, request, site_config: dict):
        """
        Initialize the handler with an empty results dictionary.

        Args:
            request: The AskRequest containing query and context
            site_config: Optional site configuration dict to pass to analysis handlers
        """
        from nlweb_core.protocol.models import AskRequest

        self.results = {}
        self.request: AskRequest = request
        self.site_config = site_config
        self.done = False

    async def do(self):
        """
        Execute all enabled query analysis modules in parallel.

        This method:
        1. Reads the query_analysis.xml tree
        2. Finds all enabled QueryAnalysis nodes
        3. Dynamically imports the class specified in the ref attribute from the module in method field
        4. Creates instances passing self as the handler
        5. Executes their do() methods in parallel
        6. Collects results in self.results dictionary
        """
        global query_analysis_tree

        if query_analysis_tree is None:
            return

        # Create tasks as we iterate through enabled QueryAnalysis nodes
        tasks = []

        for node in query_analysis_tree.findall(".//QueryAnalysis"):
            enabled = node.get("enabled", "false").lower() == "true"
            ref = node.get("ref")

            if enabled and ref:
                try:
                    # Get the method child element
                    method_node = node.find("method")
                    if method_node is None or not method_node.text:
                        self.results[ref] = {"error": "No method element found in XML"}
                        continue

                    module_name = method_node.text.strip()

                    # Special case for defaultQueryAnalysisHandler
                    if module_name == "defaultQueryAnalysisHandler":
                        instance = DefaultQueryAnalysisHandler(
                            self.request, xml_node=node, site_config=self.site_config
                        )
                    else:
                        # For other handlers, import from the specified module
                        full_module_name = f"nlweb_core.query_analysis.{module_name}"
                        class_name = ref

                        module = importlib.import_module(full_module_name)
                        analysis_class = getattr(module, class_name)

                        # Create instance passing self as handler and the XML node
                        instance = analysis_class(self, node)

                    # Create task for async execution
                    task = asyncio.create_task(self._execute_analysis(ref, instance))
                    tasks.append(task)

                except (ImportError, AttributeError) as e:
                    logger.error(
                        f"Error loading analysis module for ref {ref}: {e}",
                        exc_info=True,
                    )
                    raise

        # Execute all tasks in parallel and update results as they complete
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

        # Mark as done
        self.done = True
        return self.results

    async def _execute_analysis(self, ref, instance):
        """Execute a single analysis and store the result."""
        try:
            result = await instance.do()
            self.results[ref] = result
        except Exception as e:
            logger.error(f"Error executing analysis for ref {ref}: {e}", exc_info=True)
            raise


class DefaultQueryAnalysisHandler:
    """
    Default handler for query analysis that extracts prompt and response structure
    from XML, performs variable substitution, and calls the LLM.
    """

    def __init__(
        self,
        request,
        site_config: dict,
        xml_node=None,
        prompt_ref=None,
        root_node=query_analysis_tree,
    ):
        """
        Initialize with request and XML node.

        Args:
            request: The AskRequest containing query and context
            xml_node: The XML QueryAnalysis node with promptString and returnStruc
            prompt_ref: Reference to find the XML node if xml_node is not provided
            root_node: Root XML tree to search for prompt_ref
            site_config: Optional site configuration dict. If provided with an
                'item_type' key, it will be used instead of doing a lookup.
        """
        from nlweb_core.protocol.models import AskRequest

        self.request: AskRequest = request
        self.site_config = site_config
        if prompt_ref is None and xml_node is None:
            raise ValueError(
                "Both prompt_ref and xml_node cannot be None. One must be provided."
            )
        if xml_node is None:
            # Try to find the xml_node from the root_node using prompt_ref
            tree = root_node
            if tree is not None and prompt_ref is not None:
                for node in tree.findall(".//QueryAnalysis"):
                    ref = node.get("ref")
                    if ref == prompt_ref:
                        xml_node = node
                        break
            if xml_node is None:
                raise ValueError("Could not find xml_node for given prompt_ref.")
        self.xml_node = xml_node

    def _build_prompt_params(self) -> dict:
        """Build prompt variable substitution dict from the request object."""
        query = self.request.query
        context = self.request.context

        # Get item_type from site_config if provided, otherwise do lookup
        if self.site_config and "item_type" in self.site_config:
            site_item_type = self.site_config["item_type"]
        else:
            site_item_type = "item"

        params = {
            "request.rawQuery": query.text,
            "request.query": query.text,
            "request.site": query.site,
            "site.itemType": site_item_type,
        }

        # Add context-related params if available
        if context:
            if context.prev:
                params["request.previousQueries"] = ", ".join(context.prev)
            if context.text:
                params["request.context"] = context.text

        return params

    async def do(self):
        """
        Execute the default query analysis:
        1. Extract promptString from XML node
        2. Get responseModel from XML attribute
        3. Substitute variables in the prompt
        4. Call ask_llm with Pydantic model
        5. Return the result as a dict
        """
        # Extract promptString
        prompt_node = self.xml_node.find("promptString")
        if prompt_node is None or not prompt_node.text:
            return {"error": "No promptString found in XML"}

        prompt_str = prompt_node.text.strip()

        # Get responseModel from XML attribute
        response_model_name = self.xml_node.get("responseModel")
        if not response_model_name:
            return {"error": "No responseModel attribute found in XML"}

        # Look up the Pydantic model class
        try:
            response_model = get_response_model(response_model_name)
        except ValueError as e:
            logger.error(f"Invalid responseModel: {e}", exc_info=True)
            raise

        # Build and substitute variables in the prompt
        prompt_params = self._build_prompt_params()
        filled_prompt = fill_prompt_variables(prompt_str, prompt_params)

        # Call the LLM with Pydantic model for type-safe response
        try:
            from nlweb_core.llm import ask_llm

            result = await ask_llm(
                filled_prompt,
                response_model,
                level="low",
                timeout=8,
                query_params=prompt_params,
            )
            # Convert Pydantic model to dict for compatibility with existing code
            return result.model_dump()
        except Exception as e:
            logger.error(f"LLM call failed: {e}", exc_info=True)
            raise
