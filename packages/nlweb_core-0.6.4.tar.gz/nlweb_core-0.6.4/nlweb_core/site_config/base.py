"""
Base class for site configuration lookup providers.
"""

import logging
from abc import ABC, abstractmethod
from typing import Any

logger = logging.getLogger(__name__)


class SiteConfigLookup(ABC):
    """Abstract base class defining the interface for site configuration lookup providers."""

    @abstractmethod
    def __init__(self, **kwargs: Any) -> None:
        """Initialize the site config lookup provider."""
        ...

    @abstractmethod
    async def get_config(self, site: str) -> dict[str, Any] | None:
        """Retrieve site configuration with caching.

        Args:
            site: Site filter (URL or domain, e.g., "yelp.com", "https://www.yelp.com")

        Returns:
            Configuration dict or None if not found
        """
        ...

    @abstractmethod
    async def get_config_type(self, site: str, config_type: str) -> Any | None:
        """Retrieve a specific config type for a site.

        Args:
            site: Site filter (URL or domain, e.g., "yelp.com", "https://www.yelp.com")
            config_type: Config type name (e.g., "elicitation", "item_types")

        Returns:
            Configuration value or None if not found
        """
        ...

    @abstractmethod
    async def close(self) -> None:
        """Close the client and release resources."""
        ...

    async def update_config_type(
        self, site: str, config_type: str | None, config_data: Any
    ) -> dict[str, Any] | None:
        """Update a specific config type for a site.

        Args:
            site: Site filter (URL or domain)
            config_type: Config type name (e.g., "freshness_config")
            config_data: Configuration data to set

        Returns:
            Result dict with operation details (e.g., {"created": True, "id": "..."})
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not support update_config_type"
        )

    async def delete_config_type(
        self, site: str, config_type: str
    ) -> dict[str, Any] | None:
        """Delete a specific config type for a site.

        Args:
            site: Site filter (URL or domain)
            config_type: Config type name

        Returns:
            Result dict if deleted, None if not found
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not support delete_config_type"
        )

    async def delete_full_config(self, site: str) -> dict[str, Any] | None:
        """Delete all config for a site.

        Args:
            site: Site filter (URL or domain)

        Returns:
            Result dict if deleted, None if not found
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not support delete_full_config"
        )
