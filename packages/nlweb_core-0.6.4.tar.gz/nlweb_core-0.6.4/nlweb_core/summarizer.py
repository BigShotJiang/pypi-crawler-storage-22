# Copyright (c) 2025 Microsoft Corporation.
# Licensed under the MIT License

"""
Standalone summarizer with injectable LLM for evaluation and testing.

This module provides a ResultsSummarizer class that can be used independently
of the handler for summarizing search results. It supports injectable LLM
callables for flexibility in testing and evaluation scenarios.

WARNING: This code is under development and may undergo changes in future releases.
Backwards compatibility is not guaranteed at this time.
"""

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from functools import partial
from typing import Any

from pydantic import BaseModel

from nlweb_core.llm_models import SummaryResponse


@dataclass
class SummaryResult:
    """Result of a summarization operation."""

    summary: str
    raw_response: dict[str, Any]

    def to_result_object(self) -> dict[str, Any]:
        """Convert to v0.54 protocol format."""
        return {"@type": "Summary", "text": self.summary}


class ResultsSummarizer:
    """Standalone summarizer with injectable LLM.

    This class extracts summarization logic from PostQueryProcessing to allow:
    1. Independent usage in evaluation harnesses
    2. Testing with mock LLMs
    3. Custom prompt configurations

    Example usage with custom LLM:
        async def my_test_llm(prompt, schema):
            return {"summary": "Test summary"}

        summarizer = ResultsSummarizer(llm=my_test_llm)
        result = await summarizer.summarize(query="test", results=[...])

    Example with partial for production:
        from functools import partial
        from nlweb_core.llm import ask_llm

        llm = partial(ask_llm, level='high', timeout=20)
        summarizer = ResultsSummarizer(llm=llm)
    """

    DEFAULT_PROMPT_TEMPLATE = """\
Summarize the following AI results in 2-3 sentences (*DO NOT mention 'search results' or 'results' in your output*), highlighting the key information that answers the user's question: {query}
{query_constraints}
Results:
{results}"""

    HINDI_PROMPT_TEMPLATE = """\
Summarize the following AI results in 2-3 sentences in Hindi. *Your output MUST be in Hindi.* (*DO NOT mention 'search results' or 'results' in your output*) Highlight the key information that answers the user's question: {query}
{query_constraints}
Results:
{results}"""

    # Pydantic model for type-safe schema
    SCHEMA: type[SummaryResponse] = SummaryResponse

    def __init__(
        self,
        llm: Callable[[str, type[BaseModel]], Awaitable[BaseModel]],
        prompt_template: str | None = None,
    ):
        """Initialize the summarizer.

        Args:
            llm: Async callable with signature (prompt, schema) -> response.
                 Takes a Pydantic model class and returns a model instance.
                 Use functools.partial to bind level/timeout if needed.
            prompt_template: Optional custom prompt template. Should include
                            {query} and {results} placeholders.
        """
        self._llm = llm
        self._prompt_template = prompt_template or self.DEFAULT_PROMPT_TEMPLATE

    def format_results(self, results: list[dict]) -> str:
        """Format results list into text for the prompt.

        Args:
            results: List of result dictionaries with 'name' and 'description' keys.
                    Caller should slice to desired length before calling.

        Returns:
            Formatted string with numbered results.
        """
        results_text = []
        for i, result in enumerate(results, 1):
            name = result.get("name", "Unknown")
            description = result.get("description", "")
            results_text.append(f"{i}. {name}: {description}")
        return "\n".join(results_text)

    def build_prompt(self, query: str, results: list[dict], start_num: int = 0) -> str:
        """Build the full prompt for summarization.

        Args:
            query: The user's query text.
            results: List of result dictionaries.

        Returns:
            Formatted prompt string ready for the LLM.
        """
        results_text = self.format_results(results)
        # If some constraints on query, ie pagination, make sure summary aware of it.
        query_constraints = ""
        if start_num:
            query_constraints = f"""\
The query was issued again for more results, starting at the {start_num} entry. Start of the summary by indicating these items were retrieved after looking for additional items."""
        return self._prompt_template.format(
            query=query, results=results_text, query_constraints=query_constraints
        )

    async def summarize(
        self, query: str, results: list[dict], start_num: int = 0
    ) -> SummaryResult | None:
        """Generate a summary of the search results.

        Args:
            query: The user's query text.
            results: List of result dictionaries to summarize.
                    Caller should slice to desired length before calling.

        Returns:
            SummaryResult if successful, None if no results or LLM fails.
        """
        if not results:
            return None

        prompt = self.build_prompt(query, results, start_num)

        try:
            response = await self._llm(prompt, self.SCHEMA)
        except Exception:
            raise

        # Response is guaranteed to be a SummaryResponse Pydantic model
        if not isinstance(response, SummaryResponse):
            raise ValueError(f"Expected SummaryResponse, got {type(response).__name__}")

        return SummaryResult(
            summary=response.summary, raw_response={"summary": response.summary}
        )


def create_default_summarizer() -> ResultsSummarizer:
    """Factory function to create a summarizer with the default ask_llm.

    Returns:
        ResultsSummarizer configured with the production ask_llm function.
    """
    from nlweb_core.llm import ask_llm

    llm = partial(ask_llm, level="high", timeout=20)
    return ResultsSummarizer(llm=llm)


def create_hindi_summarizer() -> ResultsSummarizer:
    """Factory function to create a Hindi summarizer with the default ask_llm.

    Returns:
        ResultsSummarizer configured with Hindi prompt template.
    """
    from nlweb_core.llm import ask_llm

    llm = partial(ask_llm, level="high", timeout=20)
    return ResultsSummarizer(
        llm=llm, prompt_template=ResultsSummarizer.HINDI_PROMPT_TEMPLATE
    )


def create_summarizer_from_prompt_ref(
    prompt_ref: str, prompt_file: str | None = None
) -> ResultsSummarizer:
    """Factory function to create a summarizer using a prompt from XML config.

    Searches for the prompt reference in the custom prompt file first (if provided),
    then falls back to the default query_analysis.xml. This mirrors the behavior
    of decontextualization prompt loading.

    Args:
        prompt_ref: Reference to the QueryAnalysis node
                   (e.g., "DefaultSummarization", "HindiSummarization")
        prompt_file: Optional path to a custom prompt XML file. If provided,
                    this file is searched first before falling back to the default.

    Returns:
        ResultsSummarizer configured with the prompt from XML.

    Raises:
        ValueError: If the prompt_ref is not found in any XML source.
    """
    import logging

    from nlweb_core.llm import ask_llm
    from nlweb_core.query_analysis.query_analysis import (
        load_prompt_tree_from_file,
        query_analysis_tree,
    )

    logger = logging.getLogger(__name__)

    xml_node = None

    # Try custom prompt file first
    if prompt_file:
        try:
            custom_tree = load_prompt_tree_from_file(prompt_file)
            for node in custom_tree.findall(".//QueryAnalysis"):
                if node.get("ref") == prompt_ref:
                    xml_node = node
                    logger.info(
                        f"Loaded summarization prompt '{prompt_ref}' from {prompt_file}"
                    )
                    break
        except Exception as e:
            logger.warning(f"Could not load custom prompt file: {e}")

    # Fall back to default query_analysis.xml
    if xml_node is None:
        if query_analysis_tree is None:
            raise ValueError("query_analysis_tree is not loaded")
        for node in query_analysis_tree.findall(".//QueryAnalysis"):
            if node.get("ref") == prompt_ref:
                xml_node = node
                break

    if xml_node is None:
        raise ValueError(f"Prompt reference '{prompt_ref}' not found in any XML source")

    # Extract the prompt template from XML
    prompt_node = xml_node.find("promptString")
    if prompt_node is None or not prompt_node.text:
        raise ValueError(f"No promptString found for prompt reference '{prompt_ref}'")

    prompt_template = prompt_node.text.strip()

    llm = partial(ask_llm, level="high", timeout=20)
    return ResultsSummarizer(llm=llm, prompt_template=prompt_template)
