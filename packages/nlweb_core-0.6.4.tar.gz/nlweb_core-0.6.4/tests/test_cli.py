"""Tests for the nlweb-init CLI entrypoint."""

from pathlib import Path
from unittest.mock import patch

import pytest
import yaml
from nlweb_core.cli import _copy_example_config, main


class TestCopyExampleConfig:
    """Tests for _copy_example_config."""

    def test_copies_config_to_dest(self, tmp_path: Path) -> None:
        dest = tmp_path / "config.yaml"
        _copy_example_config(dest=dest)
        assert dest.exists()
        content = dest.read_text()
        assert "generative_model:" in content

    def test_warns_if_exists(self, tmp_path: Path) -> None:
        dest = tmp_path / "config.yaml"
        dest.write_text("existing")
        with pytest.raises(SystemExit):
            _copy_example_config(dest=dest)

    def test_force_overwrites(self, tmp_path: Path) -> None:
        dest = tmp_path / "config.yaml"
        dest.write_text("existing")
        _copy_example_config(dest=dest, force=True)
        content = dest.read_text()
        assert "generative_model:" in content

    def test_bundled_config_is_valid_yaml(self, tmp_path: Path) -> None:
        dest = tmp_path / "config.yaml"
        _copy_example_config(dest=dest)
        with open(dest) as f:
            data = yaml.safe_load(f)
        assert isinstance(data, dict)
        assert "generative_model" in data


class TestMain:
    """Tests for the main() CLI entrypoint."""

    def test_main_writes_to_path(self, tmp_path: Path) -> None:
        dest = tmp_path / "my-config.yaml"
        with patch("sys.argv", ["nlweb-init", str(dest)]):
            main()
        assert dest.exists()

    def test_main_force(self, tmp_path: Path) -> None:
        dest = tmp_path / "config.yaml"
        dest.write_text("old")
        with patch("sys.argv", ["nlweb-init", str(dest), "--force"]):
            main()
        content = dest.read_text()
        assert "generative_model:" in content
