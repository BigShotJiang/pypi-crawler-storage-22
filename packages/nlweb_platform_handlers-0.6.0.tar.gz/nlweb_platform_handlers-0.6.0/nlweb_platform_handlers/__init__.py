# Copyright (c) 2025 Microsoft Corporation.
# Licensed under the MIT License

"""Platform-specific retrieval handlers for NLWeb.

These handlers query platform search APIs directly (e.g., Shopify MCP, Wix MCP)
instead of using a pre-indexed vector database. They extend DefaultAskHandler,
inheriting the full query pipeline (decontextualization, elicitation, ranking,
summarization) and only replacing the retrieval step.

Configure via site_config handler section in config.yaml:

    site_config:
      handler:
        sites:
          mystore.myshopify.com:
            ask_handler_class: ShopifyMCPHandler
            ask_handler_import_path: nlweb_platform_handlers.shopify
          mybusiness.wixsite.com/mysite:
            ask_handler_class: WixMCPHandler
            ask_handler_import_path: nlweb_platform_handlers.wix
"""

from nlweb_platform_handlers.base import KeywordRetrievalHandler
from nlweb_platform_handlers.shopify import ShopifyMCPHandler
from nlweb_platform_handlers.wix import WixMCPHandler

__all__ = [
    "KeywordRetrievalHandler",
    "ShopifyMCPHandler",
    "WixMCPHandler",
]
