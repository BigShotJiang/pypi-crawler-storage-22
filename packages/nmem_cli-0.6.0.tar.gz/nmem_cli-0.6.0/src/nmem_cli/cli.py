"""
Nowledge Mem CLI - AI agent-friendly memory management.

Aliases:
  m  = memories
  t  = threads
  c  = communities
"""

import argparse
import json as json_module
import os
import platform
import shutil
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any
from urllib.parse import quote, urlsplit, urlunsplit

import httpx
from rich import box
from rich.console import Console
from rich.markdown import Markdown
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Confirm
from rich.table import Table

from . import __version__

DEFAULT_API_URL = "http://127.0.0.1:14242"

# Server-only commands (serve) are only shown on Linux where headless mode is used.
# On macOS/Windows the Tauri desktop app manages the backend lifecycle.
_is_server_platform = platform.system() == "Linux"

console = Console()
_json_mode = False


def set_json_mode(enabled: bool) -> None:
    global _json_mode
    _json_mode = enabled


def is_json_mode() -> bool:
    return _json_mode


def output_json(data: Any) -> None:
    print(json_module.dumps(data, indent=2, default=str, ensure_ascii=False))


def get_api_url() -> str:
    return os.environ.get("NMEM_API_URL", DEFAULT_API_URL)


def get_api_key() -> str:
    return os.environ.get("NMEM_API_KEY", "").strip()


def get_api_headers() -> dict[str, str]:
    api_key = get_api_key()
    if not api_key:
        return {}
    # Send both standard bearer auth and explicit key header.
    # Some proxies strip one header but preserve the other.
    return {
        "Authorization": f"Bearer {api_key}",
        "X-NMEM-API-Key": api_key,
    }


def get_api_cookies() -> dict[str, str]:
    api_key = get_api_key()
    if not api_key:
        return {}
    return {"nmem_api_key": api_key}


def _build_params_with_query_key(
    params: dict[str, Any] | list[tuple[str, Any]] | Any | None,
) -> dict[str, Any] | list[tuple[str, Any]] | Any | None:
    api_key = get_api_key()
    if not api_key:
        return params

    if params is None:
        return {"nmem_api_key": api_key}

    if isinstance(params, dict):
        if "nmem_api_key" in params:
            return params
        merged = dict(params)
        merged["nmem_api_key"] = api_key
        return merged

    if isinstance(params, list):
        has_key = any(str(key).lower() == "nmem_api_key" for key, _ in params)
        if has_key:
            return params
        return [*params, ("nmem_api_key", api_key)]

    return params


def _strip_remote_api_path_prefix(url: str) -> str:
    """Compatibility fallback for legacy tunnel URLs ending in /remote-api.

    Some earlier tunnel setups surfaced URLs like:
      https://<random>.trycloudflare.com/remote-api
    while Cloudflare already routed requests at root paths.
    """

    parts = urlsplit(url)
    path = parts.path or ""

    if path == "/remote-api":
        path = "/"
    elif path.startswith("/remote-api/"):
        path = path[len("/remote-api") :]
    else:
        return url

    return urlunsplit((parts.scheme, parts.netloc, path, parts.query, parts.fragment))


def _response_detail(response: httpx.Response) -> str:
    try:
        payload = response.json()
        if isinstance(payload, dict):
            detail = payload.get("detail")
            if isinstance(detail, str):
                return detail
    except Exception:
        pass
    return response.text


def _is_missing_api_key_response(response: httpx.Response) -> bool:
    if response.status_code != 401:
        return False
    return "missing api key" in _response_detail(response).lower()


def api_request(
    method: str,
    url: str,
    *,
    timeout: float,
    headers: dict[str, str] | None = None,
    params: dict[str, Any] | list[tuple[str, Any]] | Any | None = None,
    json: dict[str, Any] | None = None,
) -> httpx.Response:
    merged_headers = get_api_headers()
    if headers:
        merged_headers.update(headers)

    cookies = get_api_cookies() or None
    response = httpx.request(
        method,
        url,
        params=params,
        json=json,
        timeout=timeout,
        headers=merged_headers,
        cookies=cookies,
    )

    # Proxy-compat retry:
    # If auth headers are stripped in transit, retry once with query-key fallback.
    if get_api_key() and _is_missing_api_key_response(response):
        retry_params = _build_params_with_query_key(params)
        response = httpx.request(
            method,
            url,
            params=retry_params,
            json=json,
            timeout=timeout,
            headers=merged_headers,
            cookies=cookies,
        )

    # Legacy URL compatibility retry:
    # Earlier tunnel URLs used ".../remote-api". For quick tunnels the correct
    # public URL is root-based, so retry once with the prefix removed.
    if get_api_key() and _is_missing_api_key_response(response):
        compat_url = _strip_remote_api_path_prefix(url)
        if compat_url != url:
            retry_params = _build_params_with_query_key(params)
            response = httpx.request(
                method,
                compat_url,
                params=retry_params,
                json=json,
                timeout=timeout,
                headers=merged_headers,
                cookies=cookies,
            )

    return response


def print_error(title: str, message: str, hint: str | None = None) -> None:
    if is_json_mode():
        return
    console.print(f"[bold red]x[/bold red] [bold]{title}[/bold]")
    console.print(f"  [dim]{message}[/dim]")
    if hint:
        console.print(f"  [dim cyan]Hint: {hint}[/dim cyan]")


def print_success(message: str, detail: str | None = None) -> None:
    if is_json_mode():
        return
    if detail:
        console.print(f"[green]ok[/green] {message}: [cyan]{detail}[/cyan]")
    else:
        console.print(f"[green]ok[/green] {message}")


# ═══════════════════════════════════════════════════════════════════════════════
# API Client
# ═══════════════════════════════════════════════════════════════════════════════


def api_get(endpoint: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
    url = f"{get_api_url()}{endpoint}"
    try:
        response = api_request(
            "GET",
            url,
            params=params,
            timeout=30.0,
        )
        response.raise_for_status()
        return response.json()
    except httpx.ConnectError:
        error = {
            "error": "connection_failed",
            "message": f"Cannot connect to {get_api_url()}",
        }
        if is_json_mode():
            output_json(error)
        else:
            print_error(
                "Connection Failed",
                f"Cannot reach {get_api_url()}",
                "Make sure Nowledge Mem is running",
            )
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        error = {"error": "api_error", "status_code": e.response.status_code}
        try:
            error["detail"] = e.response.json().get("detail", "")
        except Exception:
            pass
        if is_json_mode():
            output_json(error)
        else:
            status = e.response.status_code
            if status == 404:
                print_error("Not Found", "Resource doesn't exist", "Check the ID")
            else:
                print_error(
                    f"API Error ({status})", error.get("detail", "Request failed")
                )
        sys.exit(1)


def api_post(endpoint: str, data: dict[str, Any]) -> dict[str, Any]:
    url = f"{get_api_url()}{endpoint}"
    try:
        response = api_request(
            "POST",
            url,
            json=data,
            timeout=60.0,
        )
        response.raise_for_status()
        return response.json()
    except httpx.ConnectError:
        error = {
            "error": "connection_failed",
            "message": f"Cannot connect to {get_api_url()}",
        }
        if is_json_mode():
            output_json(error)
        else:
            print_error("Connection Failed", f"Cannot reach {get_api_url()}")
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        error = {"error": "api_error", "status_code": e.response.status_code}
        try:
            error["detail"] = e.response.json().get("detail", "")
        except Exception:
            pass
        if is_json_mode():
            output_json(error)
        else:
            print_error(
                f"API Error ({e.response.status_code})",
                error.get("detail", "Request failed"),
            )
        sys.exit(1)


def api_delete(
    endpoint: str, params: dict[str, Any] | None = None
) -> dict[str, Any]:
    url = f"{get_api_url()}{endpoint}"
    try:
        response = api_request(
            "DELETE",
            url,
            params=params,
            timeout=30.0,
        )
        response.raise_for_status()
        return response.json()
    except httpx.ConnectError:
        error = {"error": "connection_failed", "message": "Cannot connect"}
        if is_json_mode():
            output_json(error)
        else:
            print_error("Connection Failed", "Cannot reach server")
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        error = {"error": "api_error", "status_code": e.response.status_code}
        if is_json_mode():
            output_json(error)
        else:
            if e.response.status_code == 404:
                print_error("Not Found", "Already deleted or invalid ID")
            else:
                print_error(
                    f"Delete Failed ({e.response.status_code})", "Could not delete"
                )
        sys.exit(1)


def api_patch(endpoint: str, data: dict[str, Any]) -> dict[str, Any]:
    url = f"{get_api_url()}{endpoint}"
    try:
        response = api_request(
            "PATCH",
            url,
            json=data,
            timeout=30.0,
        )
        response.raise_for_status()
        return response.json()
    except httpx.ConnectError:
        error = {"error": "connection_failed", "message": "Cannot connect"}
        if is_json_mode():
            output_json(error)
        else:
            print_error("Connection Failed", "Cannot reach server")
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        error = {"error": "api_error", "status_code": e.response.status_code}
        if is_json_mode():
            output_json(error)
        else:
            print_error(f"Update Failed ({e.response.status_code})", "Could not update")
        sys.exit(1)


def _extract_mcp_json(response_text: str) -> dict[str, Any]:
    """Parse FastMCP stateless HTTP response (JSON or SSE data envelope)."""
    text = response_text.strip()
    if not text:
        raise ValueError("Empty MCP response")

    if text.startswith("{"):
        return json_module.loads(text)

    for line in response_text.splitlines():
        if line.startswith("data: "):
            return json_module.loads(line[6:])

    raise ValueError("No MCP data event found in response")


def api_mcp_tool_call(tool_name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    """Call an MCP tool via /mcp/ and return structuredContent if present."""
    url = f"{get_api_url()}/mcp/"
    headers = get_api_headers()
    headers["Accept"] = "application/json, text/event-stream"
    headers["Connection"] = "close"

    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {
            "name": tool_name,
            "arguments": arguments,
        },
    }

    try:
        response = api_request(
            "POST",
            url,
            json=payload,
            timeout=60.0,
            headers=headers,
        )
        response.raise_for_status()

        parsed = _extract_mcp_json(response.text)
        if "error" in parsed:
            raise RuntimeError(parsed["error"].get("message", "Unknown MCP error"))

        result = parsed.get("result", {})
        if isinstance(result, dict) and isinstance(result.get("structuredContent"), dict):
            return result["structuredContent"]

        return result if isinstance(result, dict) else {"result": result}

    except httpx.ConnectError:
        if is_json_mode():
            output_json({"error": "connection_failed", "message": "Cannot connect"})
        else:
            print_error("Connection Failed", "Cannot reach server")
        sys.exit(1)
    except Exception as e:
        if is_json_mode():
            output_json({"error": "mcp_error", "message": str(e)})
        else:
            print_error("MCP Error", str(e), "Check MCP endpoint availability")
        sys.exit(1)


def api_put(endpoint: str, data: dict[str, Any]) -> dict[str, Any]:
    url = f"{get_api_url()}{endpoint}"
    try:
        response = api_request(
            "PUT",
            url,
            json=data,
            timeout=30.0,
        )
        response.raise_for_status()
        return response.json()
    except httpx.ConnectError:
        error = {"error": "connection_failed", "message": "Cannot connect"}
        if is_json_mode():
            output_json(error)
        else:
            print_error("Connection Failed", "Cannot reach server")
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        error = {"error": "api_error", "status_code": e.response.status_code}
        try:
            error["detail"] = e.response.json().get("detail", "")
        except Exception:
            pass
        if is_json_mode():
            output_json(error)
        else:
            print_error(
                f"API Error ({e.response.status_code})",
                error.get("detail", "Request failed"),
            )
        sys.exit(1)


# ═══════════════════════════════════════════════════════════════════════════════
# Utilities
# ═══════════════════════════════════════════════════════════════════════════════


def format_date(date_str: str | None) -> str:
    if not date_str:
        return "-"
    try:
        dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d")
    except (ValueError, AttributeError):
        return date_str[:10] if date_str else "-"


def truncate(text: str, max_len: int = 50) -> str:
    if not text:
        return ""
    text = text.replace("\n", " ").strip()
    if len(text) <= max_len:
        return text
    return text[: max_len - 1] + "..."


def format_score(score: float) -> str:
    if score >= 0.8:
        return f"[bold green]{score:.2f}[/bold green]"
    elif score >= 0.5:
        return f"[green]{score:.2f}[/green]"
    elif score >= 0.3:
        return f"[yellow]{score:.2f}[/yellow]"
    else:
        return f"[dim]{score:.2f}[/dim]"


def format_importance(imp: float) -> str:
    if imp >= 0.7:
        return f"[green]{imp:.1f}[/green]"
    elif imp >= 0.4:
        return f"[yellow]{imp:.1f}[/yellow]"
    else:
        return f"[dim]{imp:.1f}[/dim]"


def parse_time_filter(time_str: str) -> str | None:
    now = datetime.now()
    time_map = {
        "today": now - timedelta(days=1),
        "yesterday": now - timedelta(days=2),
        "week": now - timedelta(weeks=1),
        "month": now - timedelta(days=30),
        "year": now - timedelta(days=365),
    }
    if time_str in time_map:
        return time_map[time_str].strftime("%Y-%m-%d")
    return time_str


# ═══════════════════════════════════════════════════════════════════════════════
# Commands: Status & Stats
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_status() -> None:
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Connecting...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/health")
    else:
        data = api_get("/health")

    result = {
        "status": data.get("status", "ok"),
        "version": data.get("version", __version__),
        "api_url": get_api_url(),
        "database": data.get("database_connected", True),
    }

    if is_json_mode():
        output_json(result)
    else:
        status_color = "green" if result["status"] == "ok" else "yellow"
        console.print()
        console.print(f"[bold]nmem[/bold] v{result['version']}")
        console.print(f"  status   [{status_color}]{result['status']}[/{status_color}]")
        console.print(f"  api      {result['api_url']}")
        console.print(
            f"  database {'connected' if result['database'] else 'disconnected'}"
        )
        console.print()


def cmd_stats() -> None:
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/stats")
    else:
        data = api_get("/stats")

    result = {
        "memories": data.get("memory_count", data.get("memories", 0)),
        "threads": data.get("thread_count", data.get("threads", 0)),
        "entities": data.get("entity_count", data.get("entities", 0)),
        "labels": data.get("label_count", data.get("labels", 0)),
        "communities": data.get("community_count", 0),
    }

    if is_json_mode():
        output_json(result)
    else:
        console.print()
        console.print("[bold]Database Statistics[/bold]")
        console.print(f"  memories    [cyan]{result['memories']:,}[/cyan]")
        console.print(f"  threads     [cyan]{result['threads']:,}[/cyan]")
        console.print(f"  entities    [magenta]{result['entities']:,}[/magenta]")
        console.print(f"  labels      [yellow]{result['labels']:,}[/yellow]")
        console.print(f"  communities [green]{result['communities']:,}[/green]")
        console.print()


# ═══════════════════════════════════════════════════════════════════════════════
# Community Commands
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_communities_list(limit: int = 20) -> None:
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading communities...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/communities", params={"limit": limit})
    else:
        data = api_get("/communities", params={"limit": limit})

    communities = data.get("communities", [])

    if is_json_mode():
        output_json(data)
        return

    if not communities:
        console.print()
        console.print("[dim]No communities detected yet.[/dim]")
        console.print("[dim]Run community detection to discover knowledge themes.[/dim]")
        console.print()
        return

    console.print()
    console.print(f"[bold]Knowledge Communities[/bold]  [dim]({len(communities)} found)[/dim]")
    console.print()

    for c in communities:
        name = c.get("name", "Unnamed")
        member_count = c.get("member_count", 0)
        summary = c.get("summary", c.get("description", ""))
        cid = c.get("id", "")

        console.print(f"  [bold cyan]{name}[/bold cyan]  [dim]({member_count} entities)[/dim]")
        if summary:
            # Truncate summary to ~100 chars for list view
            short = summary[:120] + "..." if len(summary) > 120 else summary
            console.print(f"    [dim]{short}[/dim]")
        console.print(f"    [dim]id: {cid}[/dim]")
        console.print()


def cmd_communities_show(community_id: str) -> None:
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading community...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get(f"/communities/{community_id}")
    else:
        data = api_get(f"/communities/{community_id}")

    if is_json_mode():
        output_json(data)
        return

    community = data.get("community", {})
    entities = data.get("entities", [])
    sample_memories = data.get("sample_memories", [])

    console.print()
    console.print(f"[bold]{community.get('name', 'Unnamed')}[/bold]")
    console.print(f"  [dim]{community.get('member_count', 0)} entities[/dim]")
    console.print()

    summary = community.get("summary", "")
    if summary:
        console.print(Markdown(summary))
        console.print()

    if entities:
        table = Table(box=box.SIMPLE, show_header=True, header_style="bold")
        table.add_column("Entity", style="cyan")
        table.add_column("Type", style="dim")
        table.add_column("Memories", justify="right")
        for e in entities[:15]:
            table.add_row(
                e.get("name", "?"),
                e.get("entity_type", ""),
                str(e.get("memory_count", 0)),
            )
        console.print(table)

    if sample_memories:
        console.print()
        console.print("[bold]Sample Memories[/bold]")
        for m in sample_memories:
            title = m.get("title", "Untitled")
            preview = m.get("content_preview", "")
            unit_type = m.get("unit_type", "")
            console.print(f"  [cyan]{title}[/cyan]  [dim]{unit_type}[/dim]")
            if preview:
                short = preview[:100] + "..." if len(preview) > 100 else preview
                console.print(f"    [dim]{short}[/dim]")

    console.print()


def cmd_communities_detect(resolution: float = 1.0) -> None:
    url = f"{get_api_url()}/agent/trigger/community-detection"
    try:
        response = api_request(
            "POST",
            url,
            params={"resolution": resolution, "generate_ai_summary": True},
            timeout=30.0,
        )
        response.raise_for_status()
        data = response.json()
    except httpx.ConnectError:
        print_error("Connection failed", "Cannot reach the backend server")
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        print_error("Request failed", str(e))
        sys.exit(1)

    if is_json_mode():
        output_json(data)
    else:
        console.print("[green]ok[/green] Community detection triggered")
        if data.get("message"):
            console.print(f"  [dim]{data['message']}[/dim]")


# ═══════════════════════════════════════════════════════════════════════════════
# Memory Commands
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_memories_list(limit: int = 10, importance_min: float | None = None) -> None:
    """List memories. Only importance filter is supported by the /memories API."""
    params: dict[str, Any] = {"limit": limit, "offset": 0}
    if importance_min is not None and importance_min > 0:
        params["importance_min"] = importance_min

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/memories", params=params)
    else:
        data = api_get("/memories", params=params)

    memories = data.get("memories", [])
    pagination = data.get("pagination", {})

    result = {
        "memories": [
            {
                "id": m.get("id", ""),
                "title": m.get("title", ""),
                "content": m.get("content", ""),
                "importance": m.get("importance", 0),
                "source": m.get("source", ""),
                "created_at": m.get("created_at", ""),
            }
            for m in memories
        ],
        "total": pagination.get("total", len(memories)),
    }

    if is_json_mode():
        output_json(result)
    else:
        if not memories:
            if importance_min and importance_min > 0:
                console.print(
                    f"[dim]No memories found with importance >= {importance_min}[/dim]"
                )
            else:
                console.print("[dim]No memories found.[/dim]")
            return
        console.print()
        if importance_min and importance_min > 0:
            console.print(f"[dim]Filter: importance >= {importance_min}[/dim]")
            console.print()
        table = Table(box=box.SIMPLE, header_style="bold", show_edge=False)
        table.add_column("ID", style="dim cyan", no_wrap=True)
        table.add_column("Title", min_width=30)
        table.add_column("Imp", justify="right", width=4)
        table.add_column("Source", style="yellow", width=10)
        table.add_column("Date", style="dim", width=10)
        for m in result["memories"]:
            table.add_row(
                m["id"],
                truncate(m["title"], 35),
                format_importance(m["importance"]),
                truncate(m["source"], 10),
                format_date(m["created_at"]),
            )
        console.print(table)
        if result["total"] > len(result["memories"]):
            console.print(
                f"[dim]Showing {len(result['memories'])} of {result['total']}[/dim]"
            )
        console.print()


def cmd_memories_search(
    query: str,
    limit: int = 10,
    labels: list[str] | None = None,
    time_range: str | None = None,
    importance_min: float | None = None,
    mode: str = "normal",
) -> None:
    params: dict[str, Any] = {"q": query, "limit": limit}
    if labels:
        # Pass labels as repeated query params (labels=x&labels=y)
        params["labels"] = labels
    if time_range:
        # Use time_range directly - backend handles conversion
        params["time_range"] = time_range
    if importance_min is not None and importance_min > 0:
        params["importance_min"] = importance_min
    # Map CLI mode to API mode: "normal" -> "fast", "deep" -> "deep"
    api_mode = "fast" if mode == "normal" else "deep"
    params["mode"] = api_mode

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn(f"[cyan]Searching '{query}'...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/memories/search", params=params)
    else:
        data = api_get("/memories/search", params=params)

    memories = data.get("memories", [])
    meta = data.get("search_metadata", {})

    result = {
        "query": query,
        "total": meta.get("total_found", len(memories)),
        "memories": [
            {
                "id": m.get("id", ""),
                "title": m.get("title", ""),
                "content": m.get("content", ""),
                "score": m.get("confidence", m.get("similarity_score", 0)),
                "source": m.get("source", ""),
                "source_thread": m.get("source_thread"),  # Include thread info
            }
            for m in memories
        ],
    }

    if is_json_mode():
        output_json(result)
    else:
        console.print()
        if not memories:
            filter_info = []
            if labels:
                filter_info.append(f"labels={','.join(labels)}")
            if time_range:
                filter_info.append(f"time={time_range}")
            if importance_min:
                filter_info.append(f"importance>={importance_min}")
            if filter_info:
                console.print(
                    f"[dim]No results for '{query}' with filters: {' '.join(filter_info)}[/dim]"
                )
            else:
                console.print(f"[dim]No results for '{query}'[/dim]")
            return

        # Show filter info if any
        filter_parts = []
        if labels:
            filter_parts.append(f"[magenta]{','.join(labels)}[/magenta]")
        if time_range:
            filter_parts.append(f"[cyan]{time_range}[/cyan]")
        if importance_min:
            filter_parts.append(f"[green]imp>={importance_min}[/green]")

        if filter_parts:
            console.print(
                f"[green]Found {result['total']} matches[/green] for [cyan]{query}[/cyan] [dim]({' '.join(filter_parts)})[/dim]"
            )
        else:
            console.print(
                f"[green]Found {result['total']} matches[/green] for [cyan]{query}[/cyan]"
            )
        console.print()
        table = Table(box=box.SIMPLE, header_style="bold", show_edge=False)
        table.add_column("ID", style="dim cyan", no_wrap=True)
        table.add_column("Title", min_width=25)
        table.add_column("Score", justify="right", width=5)
        table.add_column("Source", style="yellow", width=10)
        table.add_column("Thread", style="dim magenta", width=15)
        for m in result["memories"]:
            # Format thread info
            thread_info = ""
            if m.get("source_thread"):
                thread_title = m["source_thread"].get("title", "")
                thread_info = truncate(thread_title, 15) if thread_title else ""
            table.add_row(
                m["id"],
                truncate(m["title"], 30),
                format_score(m["score"]),
                truncate(m["source"], 10),
                thread_info,
            )
        console.print(table)
        console.print()


def cmd_memories_show(memory_id: str, content_limit: int | None = None) -> None:
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get(f"/memories/{memory_id}")
    else:
        data = api_get(f"/memories/{memory_id}")

    labels = [
        l.get("name", str(l)) if isinstance(l, dict) else str(l)
        for l in data.get("labels", [])
    ]
    result = {
        "id": data.get("id", memory_id),
        "title": data.get("title", ""),
        "content": data.get("content", ""),
        "importance": data.get("importance", 0),
        "confidence": data.get("confidence", 0),
        "source": data.get("source", ""),
        "created_at": data.get("created_at", ""),
        "labels": labels,
    }

    if is_json_mode():
        output_json(result)
    else:
        console.print()
        console.print(f"[bold]{result['title'] or 'Untitled'}[/bold]")
        console.print(f"[dim]ID:[/dim] [cyan]{result['id']}[/cyan]")
        console.print(
            f"[dim]Importance:[/dim] {format_importance(result['importance'])}  [dim]Source:[/dim] [yellow]{result['source']}[/yellow]"
        )
        if labels:
            console.print(f"[dim]Labels:[/dim] [magenta]{', '.join(labels)}[/magenta]")
        console.print()
        content = result["content"]
        if content_limit and len(content) > content_limit:
            console.print(content[:content_limit])
            console.print(f"[dim]... ({len(result['content'])} chars total)[/dim]")
        else:
            console.print(Markdown(content))
        console.print()


def cmd_memories_add(
    content: str,
    title: str | None = None,
    importance: float = 0.5,
    labels: list[str] | None = None,
    source: str = "cli",
) -> None:
    payload: dict[str, Any] = {
        "content": content,
        "importance": importance,
        "source": source,
    }
    if title:
        payload["title"] = title
    if labels:
        payload["labels"] = labels

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Creating...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_post("/memories", payload)
    else:
        data = api_post("/memories", payload)

    memory_data = data.get("memory", {})
    memory_id = memory_data.get("id", data.get("memory_id", data.get("id", "")))
    result: dict[str, Any] = {
        "success": True,
        "id": memory_id,
        "title": memory_data.get("title", title or ""),
    }
    if labels:
        result["labels"] = labels

    if is_json_mode():
        output_json(result)
    else:
        label_info = f" [dim]labels: {','.join(labels)}[/dim]" if labels else ""
        print_success("Created", f"{result['id']}{label_info}")


def cmd_memories_update(
    memory_id: str,
    title: str | None = None,
    content: str | None = None,
    importance: float | None = None,
) -> None:
    payload: dict[str, Any] = {"memory_id": memory_id}
    if title is not None:
        payload["title"] = title
    if content is not None:
        payload["content"] = content
    if importance is not None:
        payload["importance"] = importance

    if len(payload) == 1:
        if is_json_mode():
            output_json({"error": "no_updates", "message": "No updates specified"})
        else:
            console.print("[yellow]No updates specified[/yellow]")
        return

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Updating...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_patch(f"/memories/{memory_id}", payload)
    else:
        data = api_patch(f"/memories/{memory_id}", payload)

    if is_json_mode():
        output_json({"success": True, "id": data.get("id", memory_id)})
    else:
        print_success("Updated", data.get("id", memory_id))


def cmd_memories_delete(memory_ids: list[str], force: bool = False) -> None:
    normalized_ids: list[str] = []
    seen: set[str] = set()
    for memory_id in memory_ids:
        clean_id = memory_id.strip()
        if not clean_id or clean_id in seen:
            continue
        normalized_ids.append(clean_id)
        seen.add(clean_id)

    if not normalized_ids:
        if is_json_mode():
            output_json({"error": "invalid_input", "message": "No memory IDs provided"})
        else:
            print_error("Invalid Input", "No memory IDs provided")
        return

    if not force and not is_json_mode():
        if len(normalized_ids) == 1:
            prompt = f"Delete {normalized_ids[0]}?"
        else:
            prompt = f"Delete {len(normalized_ids)} memories?"
        if not Confirm.ask(prompt):
            console.print("[dim]Cancelled[/dim]")
            return

    if len(normalized_ids) == 1:
        target_id = normalized_ids[0]
        if not is_json_mode():
            with Progress(
                SpinnerColumn(),
                TextColumn("[cyan]Deleting...[/cyan]"),
                console=console,
                transient=True,
            ) as p:
                p.add_task("", total=None)
                api_delete(f"/memories/{target_id}")
        else:
            api_delete(f"/memories/{target_id}")

        if is_json_mode():
            output_json({"success": True, "id": target_id})
        else:
            print_success("Deleted", target_id)
        return

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Bulk deleting...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            result = api_mcp_tool_call("memory_delete", {"memory_ids": normalized_ids})
    else:
        result = api_mcp_tool_call("memory_delete", {"memory_ids": normalized_ids})

    summary = result.get("summary", {})
    deleted_count = int(summary.get("deleted_count", 0))
    failed_count = int(summary.get("failed_count", 0))

    if is_json_mode():
        output_json({
            "success": failed_count == 0,
            "bulk": True,
            "requested_ids": normalized_ids,
            **result,
        })
        return

    if failed_count == 0:
        print_success("Bulk deleted", f"{deleted_count} memories")
    else:
        print_error(
            "Bulk delete completed with failures",
            f"Deleted {deleted_count}, failed {failed_count}",
        )


# ═══════════════════════════════════════════════════════════════════════════════
# Thread Commands
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_threads_list(limit: int = 10) -> None:
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/threads", params={"limit": limit, "offset": 0})
    else:
        data = api_get("/threads", params={"limit": limit, "offset": 0})

    threads = data.get("threads", [])
    pagination = data.get("pagination", {})

    result = {
        "threads": [
            {
                "id": t.get("id", ""),
                "title": t.get("title", ""),
                "messages": t.get("messages", 0),
                "source": t.get("source", ""),
                "created_at": t.get("date", t.get("created_at", "")),
            }
            for t in threads
        ],
        "total": pagination.get("total", len(threads)),
    }

    if is_json_mode():
        output_json(result)
    else:
        if not threads:
            console.print("[dim]No threads found.[/dim]")
            return
        console.print()
        table = Table(box=box.SIMPLE, header_style="bold", show_edge=False)
        table.add_column("ID", style="dim cyan", no_wrap=True)
        table.add_column("Title", min_width=35)
        table.add_column("Msgs", justify="right", width=4)
        table.add_column("Source", style="yellow", width=10)
        table.add_column("Date", style="dim", width=10)
        for t in result["threads"]:
            table.add_row(
                t["id"],
                truncate(t["title"], 40),
                str(t["messages"]),
                truncate(t["source"], 10),
                t["created_at"][:10] if t["created_at"] else "-",
            )
        console.print(table)
        if result["total"] > len(result["threads"]):
            console.print(
                f"[dim]Showing {len(result['threads'])} of {result['total']}[/dim]"
            )
        console.print()


def cmd_threads_show(
    thread_id: str, messages_limit: int = 10, content_limit: int | None = None
) -> None:
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get(f"/threads/{quote(thread_id, safe='')}")
    else:
        data = api_get(f"/threads/{quote(thread_id, safe='')}")

    thread = data.get("thread", {})
    messages = data.get("messages", [])

    result = {
        "id": thread.get("thread_id", thread_id),
        "title": thread.get("title", ""),
        "source": thread.get("source", ""),
        "created_at": thread.get("created_at", ""),
        "message_count": len(messages),
        "messages": [
            {
                "index": i,
                "role": m.get("role", "unknown"),
                "content": m.get("content", ""),
            }
            for i, m in enumerate(messages)
        ],
    }

    if is_json_mode():
        if messages_limit and messages_limit < len(result["messages"]):
            result["messages"] = result["messages"][-messages_limit:]
            result["truncated"] = True
        output_json(result)
    else:
        console.print()
        console.print(f"[bold]{result['title'] or 'Untitled'}[/bold]")
        console.print(
            f"[dim]ID:[/dim] [cyan]{result['id']}[/cyan]  [dim]Messages:[/dim] {result['message_count']}  [dim]Source:[/dim] [yellow]{result['source']}[/yellow]"
        )
        console.print()
        display_msgs = messages[-messages_limit:] if messages_limit else messages
        if len(messages) > len(display_msgs):
            console.print(
                f"[dim]... {len(messages) - len(display_msgs)} earlier messages ...[/dim]"
            )
            console.print()
        for m in display_msgs:
            role = m.get("role", "unknown")
            content = m.get("content", "")
            if content_limit and len(content) > content_limit:
                content = (
                    content[:content_limit] + f"... ({len(m.get('content', ''))} chars)"
                )
            role_color = "blue" if role == "user" else "green"
            if len(content) > 300:
                console.print(f"[bold {role_color}]{role.upper()}[/bold {role_color}]")
                console.print(content)
                console.print()
            else:
                console.print(
                    f"[bold {role_color}]{role.upper()}:[/bold {role_color}] {truncate(content, 200)}"
                )
        console.print()


def cmd_threads_search(query: str, limit: int = 10) -> None:
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn(f"[cyan]Searching '{query}'...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/threads/search", params={"query": query, "limit": limit})
    else:
        data = api_get("/threads/search", params={"query": query, "limit": limit})

    threads = data.get("threads", [])

    # Get matches (message-level) and message count from API response
    result = {
        "query": query,
        "total": data.get("total_found", len(threads)),
        "threads": [
            {
                "id": t.get("thread_id", t.get("id", "")),
                "title": t.get("title", ""),
                "message_count": t.get("message_count", 0),
                "matches": t.get("total_matches", t.get("matched_messages_count", 0)),
                "source": t.get("source", ""),
            }
            for t in threads
        ],
    }

    if is_json_mode():
        output_json(result)
    else:
        console.print()
        if not threads:
            console.print(f"[dim]No results for '{query}'[/dim]")
            return
        console.print(
            f"[green]Found {result['total']} threads[/green] for [cyan]{query}[/cyan]"
        )
        console.print()
        table = Table(box=box.SIMPLE, header_style="bold", show_edge=False)
        table.add_column("ID", style="dim cyan", no_wrap=True)
        table.add_column("Title", min_width=35)
        table.add_column("Msgs", justify="right", width=5)
        table.add_column("Hits", justify="right", width=5)
        table.add_column("Source", style="yellow", width=10)
        for t in result["threads"]:
            table.add_row(
                t["id"],
                truncate(t["title"], 40),
                str(t["message_count"]),
                str(t["matches"]),
                truncate(t["source"], 10),
            )
        console.print(table)
        console.print()


def cmd_threads_create(
    title: str,
    content: str | None = None,
    messages_json: str | None = None,
    file: str | None = None,
    source: str = "cli",
) -> None:
    """Create a new thread from content, messages JSON, or file."""
    import hashlib

    if file:
        # File-based creation
        file_path = Path(file).resolve()
        if not file_path.exists():
            if is_json_mode():
                output_json({"error": "file_not_found", "path": str(file_path)})
            else:
                print_error("File Not Found", str(file_path))
            sys.exit(1)

        payload = {"file_path": str(file_path), "format": "auto"}
        if title:
            payload["title"] = title

        if not is_json_mode():
            with Progress(
                SpinnerColumn(),
                TextColumn("[cyan]Creating from file...[/cyan]"),
                console=console,
                transient=True,
            ) as p:
                p.add_task("", total=None)
                data = api_post("/threads/from-file", payload)
        else:
            data = api_post("/threads/from-file", payload)

        result = {
            "success": data.get("success", True),
            "id": data.get("thread_id", ""),
            "title": data.get("title", title),
            "messages": data.get("message_count", 0),
        }
    else:
        # Content or messages-based creation
        messages: list[dict[str, str]] = []

        if messages_json:
            # Parse JSON messages array
            try:
                messages = json_module.loads(messages_json)
                if not isinstance(messages, list):
                    raise ValueError("Must be a JSON array")
                for i, msg in enumerate(messages):
                    if not isinstance(msg, dict):
                        raise ValueError(f"Message {i} must be an object")
                    if "role" not in msg or "content" not in msg:
                        raise ValueError(f"Message {i} missing 'role' or 'content'")
            except (json_module.JSONDecodeError, ValueError) as e:
                if is_json_mode():
                    output_json({"error": "invalid_messages", "message": str(e)})
                else:
                    print_error(
                        "Invalid Messages JSON",
                        str(e),
                        'Format: [{"role":"user","content":"..."},{"role":"assistant","content":"..."}]',
                    )
                sys.exit(1)
        elif content:
            # Single content becomes a user message
            messages = [{"role": "user", "content": content}]
        else:
            if is_json_mode():
                output_json(
                    {
                        "error": "missing_content",
                        "message": "Provide --content, --messages, or --file",
                    }
                )
            else:
                print_error(
                    "Missing Content", "Provide --content, --messages, or --file"
                )
            sys.exit(1)

        # Generate thread_id from title and timestamp
        ts = datetime.now().strftime("%Y%m%d%H%M%S")
        title_hash = hashlib.md5(title.encode()).hexdigest()[:6]
        thread_id = f"cli-{ts}-{title_hash}"

        payload = {
            "thread_id": thread_id,
            "title": title,
            "messages": messages,
            "source": source,
        }

        if not is_json_mode():
            with Progress(
                SpinnerColumn(),
                TextColumn("[cyan]Creating...[/cyan]"),
                console=console,
                transient=True,
            ) as p:
                p.add_task("", total=None)
                data = api_post("/threads", payload)
        else:
            data = api_post("/threads", payload)

        # Response has thread object with thread_id
        thread_data = data.get("thread", {})
        result = {
            "success": True,
            "id": thread_data.get("thread_id", thread_id),
            "title": thread_data.get("title", title),
            "messages": len(data.get("messages", [])),
        }

    if is_json_mode():
        output_json(result)
    else:
        print_success("Created", f"{result['id']} ({result['messages']} messages)")


def cmd_threads_delete(
    thread_id: str, force: bool = False, cascade: bool = False
) -> None:
    if not force and not is_json_mode():
        msg = f"Delete {thread_id}?" + (" (with memories)" if cascade else "")
        if not Confirm.ask(msg):
            console.print("[dim]Cancelled[/dim]")
            return

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Deleting...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_delete(
                f"/threads/{quote(thread_id, safe='')}", params={"cascade_delete_memories": cascade}
            )
    else:
        data = api_delete(
            f"/threads/{quote(thread_id, safe='')}", params={"cascade_delete_memories": cascade}
        )

    result = {
        "success": True,
        "id": thread_id,
        "deleted_messages": data.get("deleted_messages", 0),
        "deleted_memories": data.get("deleted_memories", 0) if cascade else 0,
    }

    if is_json_mode():
        output_json(result)
    else:
        print_success("Deleted", thread_id)


def cmd_threads_save(
    client: str,
    project_path: str,
    mode: str = "current",
    session_id: str | None = None,
    summary: str | None = None,
    truncate: bool = False,
) -> None:
    """Save coding session(s) as conversation thread(s).

    Supports Claude Code and Codex. Auto-detects sessions from project path.
    """
    # Validate client
    if client not in ["claude-code", "codex"]:
        if is_json_mode():
            output_json(
                {"error": "invalid_client", "message": f"Must be claude-code or codex"}
            )
        else:
            print_error(
                "Invalid Client",
                f"'{client}' is not supported",
                "Use 'claude-code' or 'codex'",
            )
        sys.exit(1)

    # Resolve project path
    resolved_path = Path(project_path).resolve()
    if not resolved_path.exists():
        if is_json_mode():
            output_json({"error": "path_not_found", "path": str(resolved_path)})
        else:
            print_error("Path Not Found", str(resolved_path))
        sys.exit(1)

    payload = {
        "client": client,
        "project_path": str(resolved_path),
        "persist_mode": mode,
        "truncate_large_content": truncate,
    }
    if session_id:
        payload["session_id"] = session_id
    if summary:
        payload["summary"] = summary

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn(f"[cyan]Saving {client} session...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_post("/threads/sessions/save", payload)
    else:
        data = api_post("/threads/sessions/save", payload)

    if data.get("status") == "error":
        if is_json_mode():
            output_json(data)
        else:
            print_error(
                "Save Failed",
                data.get("error", "Unknown error"),
                data.get("hint"),
            )
        sys.exit(1)

    if is_json_mode():
        output_json(data)
    else:
        results = data.get("results", [])
        if len(results) == 1:
            r = results[0]
            action = r["action"]
            if action == "created":
                print_success(
                    "Created",
                    f"{r['thread_id']} ({r['message_count']} messages)",
                )
            else:
                print_success(
                    "Updated",
                    f"{r['thread_id']} (+{r['messages_added']} messages)",
                )
        else:
            created = sum(1 for r in results if r["action"] == "created")
            appended = sum(1 for r in results if r["action"] == "appended")
            console.print(
                f"[green]ok[/green] Processed {len(results)} sessions: "
                f"{created} created, {appended} updated"
            )


# ═══════════════════════════════════════════════════════════════════════════════
# Working Memory Commands
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_wm_read(date: str | None = None) -> None:
    """Read Working Memory (today or archived)."""
    params: dict[str, Any] = {}
    if date:
        params["date"] = date

    if not is_json_mode():
        label = f"Loading WM for {date}..." if date else "Loading Working Memory..."
        with Progress(
            SpinnerColumn(),
            TextColumn(f"[cyan]{label}[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/agent/working-memory", params=params)
    else:
        data = api_get("/agent/working-memory", params=params)

    if is_json_mode():
        output_json(data)
    else:
        if not data.get("exists"):
            target = date or "today"
            console.print(f"[dim]No Working Memory for {target}.[/dim]")
            return
        console.print()
        console.print(f"[bold]Working Memory[/bold] [dim]({data.get('date', '')})[/dim]")
        console.print()
        console.print(Markdown(data.get("content", "")))
        console.print()


def cmd_wm_edit(message: str | None = None) -> None:
    """Edit Working Memory — set from -m or open $EDITOR."""
    if message:
        content = message
    else:
        # Fetch current content, open in $EDITOR
        data = api_get("/agent/working-memory")
        current = data.get("content", "") if data.get("exists") else _wm_template()

        import subprocess
        import tempfile

        editor = os.environ.get("EDITOR", os.environ.get("VISUAL", "nano"))
        with tempfile.NamedTemporaryFile(
            suffix=".md", mode="w", delete=False, encoding="utf-8"
        ) as f:
            f.write(current)
            tmp_path = f.name

        try:
            result = subprocess.run([editor, tmp_path])
            if result.returncode != 0:
                print_error("Editor Error", f"Editor exited with code {result.returncode}")
                return
            content = Path(tmp_path).read_text(encoding="utf-8")
        finally:
            Path(tmp_path).unlink(missing_ok=True)

        if content.strip() == current.strip():
            if not is_json_mode():
                console.print("[dim]No changes made.[/dim]")
            return

    data = api_put("/agent/working-memory", {"content": content})

    if is_json_mode():
        output_json(data)
    else:
        if data.get("success"):
            print_success(
                "Working Memory updated",
                f"{data.get('size_bytes', 0)} bytes, "
                f"{data.get('focus_areas', 0)} focus areas, "
                f"{data.get('flags', 0)} flags",
            )
        else:
            print_error("Update Failed", str(data))


def cmd_wm_history(limit: int = 30) -> None:
    """List archived Working Memory dates."""
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Loading history...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_get("/agent/working-memory/history", params={"limit": limit})
    else:
        data = api_get("/agent/working-memory/history", params={"limit": limit})

    if is_json_mode():
        output_json(data)
    else:
        dates = data.get("dates", [])
        if not dates:
            console.print("[dim]No Working Memory history found.[/dim]")
            return

        console.print()
        console.print("[bold]Working Memory History[/bold]")
        console.print()
        table = Table(box=box.SIMPLE, header_style="bold", show_edge=False)
        table.add_column("Date", style="cyan", no_wrap=True)
        table.add_column("Size", justify="right", width=10)
        table.add_column("", width=8)
        for entry in dates:
            size_kb = entry.get("size_bytes", 0) / 1024
            label = "[green]current[/green]" if entry.get("current") else ""
            table.add_row(
                entry["date"],
                f"{size_kb:.1f} KB",
                label,
            )
        console.print(table)
        console.print(f"[dim]{len(dates)} entries[/dim]")
        console.print()


def _wm_template() -> str:
    """Default template for new Working Memory."""
    return """## Focus Areas

-

## Briefing

"""


# ═══════════════════════════════════════════════════════════════════════════════
# Serve Command
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_serve(host: str = "0.0.0.0", port: int = 14242) -> None:
    """Start the Nowledge Mem server in the foreground (Ctrl+C to stop).

    This runs the server directly in the current terminal session.
    For production deployments, use 'nmem service install' to set up
    a systemd service that runs in the background and starts on boot.
    """
    try:
        import uvicorn
    except ImportError:
        print_error(
            "Server Not Available",
            "uvicorn is not installed.",
            "Run from the bundled Nowledge Mem installation, or install uvicorn manually.",
        )
        sys.exit(1)

    console.print()
    console.print("[bold]Starting Nowledge Mem server (foreground)[/bold]")
    console.print(f"  host   {host}")
    console.print(f"  port   {port}")
    console.print(
        f"  docs   http://{'127.0.0.1' if host == '0.0.0.0' else host}:{port}/docs"
    )
    console.print()
    console.print("[dim]Press Ctrl+C to stop. For background service: nmem service install[/dim]")
    console.print()

    uvicorn.run(
        "nowledge_graph_server.fastapi_server:app",
        host=host,
        port=port,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Service Commands (systemd lifecycle — Linux only)
# ═══════════════════════════════════════════════════════════════════════════════

_SYSTEMD_UNIT = "nmem"
_SYSTEM_UNIT_DIR = Path("/etc/systemd/system")
_USER_UNIT_DIR = Path.home() / ".config" / "systemd" / "user"


def _nmem_exe_path() -> str:
    """Find the nmem executable path for the systemd unit file."""
    # Check the symlink first (DEB install)
    if Path("/usr/local/bin/nmem").exists():
        return "/usr/local/bin/nmem"
    # Fallback: wherever we're running from
    return shutil.which("nmem") or "/usr/local/bin/nmem"


def _generate_unit_content(host: str, port: int) -> str:
    """Generate a systemd unit file."""
    exe = _nmem_exe_path()
    return f"""\
[Unit]
Description=Nowledge Mem Server
After=network.target

[Service]
Type=simple
ExecStart={exe} serve --host {host} --port {port}
Restart=on-failure
RestartSec=5
Environment=NMEM_API_URL=http://127.0.0.1:{port}

StandardOutput=journal
StandardError=journal
SyslogIdentifier=nmem

[Install]
WantedBy=default.target
"""


def _run_systemctl(args: list[str], user: bool = False, check: bool = True) -> subprocess.CompletedProcess:
    """Run a systemctl command."""
    cmd = ["systemctl"]
    if user:
        cmd.append("--user")
    cmd.extend(args)
    return subprocess.run(cmd, capture_output=True, text=True, check=check)


def cmd_service_install(host: str, port: int, user: bool) -> None:
    """Install and enable the nmem systemd service."""
    unit_content = _generate_unit_content(host, port)

    if user:
        unit_dir = _USER_UNIT_DIR
        scope = "user"
    else:
        unit_dir = _SYSTEM_UNIT_DIR
        scope = "system"

    unit_file = unit_dir / f"{_SYSTEMD_UNIT}.service"

    # Check permissions
    if not user and os.geteuid() != 0:
        print_error(
            "Root Required",
            "System-wide service installation requires root.",
            "Run with sudo, or use --user for a user-level service.",
        )
        sys.exit(1)

    unit_dir.mkdir(parents=True, exist_ok=True)
    unit_file.write_text(unit_content)

    # Reload, enable, and start
    _run_systemctl(["daemon-reload"], user=user)
    _run_systemctl(["enable", f"{_SYSTEMD_UNIT}.service"], user=user)
    _run_systemctl(["start", f"{_SYSTEMD_UNIT}.service"], user=user)

    print_success(
        "Service installed",
        f"Unit file: {unit_file}\n"
        f"  Scope:     {scope}\n"
        f"  Binding:   {host}:{port}\n"
        f"  Status:    nmem service status" + (" --user" if user else ""),
    )


def cmd_service_uninstall(user: bool) -> None:
    """Stop, disable, and remove the nmem systemd service."""
    if not user and os.geteuid() != 0:
        print_error(
            "Root Required",
            "System-wide service removal requires root.",
            "Run with sudo, or use --user for a user-level service.",
        )
        sys.exit(1)

    unit_dir = _USER_UNIT_DIR if user else _SYSTEM_UNIT_DIR
    unit_file = unit_dir / f"{_SYSTEMD_UNIT}.service"

    if not unit_file.exists():
        scope = "user" if user else "system"
        print_error("Not Installed", f"No {scope} service found at {unit_file}")
        sys.exit(1)

    _run_systemctl(["stop", f"{_SYSTEMD_UNIT}.service"], user=user, check=False)
    _run_systemctl(["disable", f"{_SYSTEMD_UNIT}.service"], user=user, check=False)
    unit_file.unlink()
    _run_systemctl(["daemon-reload"], user=user)

    print_success("Service uninstalled", f"Removed {unit_file}")


def cmd_service_status(user: bool) -> None:
    """Show nmem systemd service status."""
    result = _run_systemctl(
        ["status", f"{_SYSTEMD_UNIT}.service"], user=user, check=False,
    )
    if result.returncode == 4:
        # Unit not found
        scope = "user" if user else "system"
        print_error(
            "Not Installed",
            f"No {scope} service found.",
            "Run 'nmem service install' to set up the service.",
        )
        sys.exit(1)
    # Print raw systemctl output (it's already well-formatted)
    console.print(result.stdout)
    if result.stderr:
        console.print(f"[dim]{result.stderr}[/dim]")


def cmd_service_start(user: bool) -> None:
    """Start the nmem systemd service."""
    result = _run_systemctl(["start", f"{_SYSTEMD_UNIT}.service"], user=user, check=False)
    if result.returncode != 0:
        msg = result.stderr.strip() or result.stdout.strip() or "Unknown error"
        print_error("Failed to start service", msg, "Is the service installed? Run 'nmem service install' first.")
        sys.exit(1)
    print_success("Service started")


def cmd_service_stop(user: bool) -> None:
    """Stop the nmem systemd service."""
    result = _run_systemctl(["stop", f"{_SYSTEMD_UNIT}.service"], user=user, check=False)
    if result.returncode != 0:
        msg = result.stderr.strip() or result.stdout.strip() or "Unknown error"
        print_error("Failed to stop service", msg)
        sys.exit(1)
    print_success("Service stopped")


def cmd_service_logs(user: bool, follow: bool, lines: int) -> None:
    """Show nmem service logs via journalctl."""
    cmd = ["journalctl"]
    if user:
        cmd.append("--user")
    cmd.extend(["-u", f"{_SYSTEMD_UNIT}.service", "-n", str(lines)])
    if follow:
        cmd.append("-f")
    # Stream directly to terminal (don't capture)
    subprocess.run(cmd)


# ═══════════════════════════════════════════════════════════════════════════════
# Models Commands
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_models_status() -> None:
    """Show status of embedding and search models."""
    data = api_get("/models/status")
    if is_json_mode():
        output_json(data)
        return

    console.print()
    console.print("[bold]Model Status[/bold]")
    console.print()

    table = Table(box=box.SIMPLE)
    table.add_column("Model", style="bold")
    table.add_column("Status")
    table.add_column("Details")

    # Embedding model
    embedding_exists = data.get("embedding", False)
    status_str = "[green]ready[/green]" if embedding_exists else "[dim]not installed[/dim]"
    cache_info = data.get("cache_info", {})
    embedding_info = cache_info.get("embedding", {})
    embedding_detail = ""
    if isinstance(embedding_info, dict):
        embedding_detail = embedding_info.get("model", embedding_info.get("path", ""))
    table.add_row("Embedding", status_str, str(embedding_detail))

    # Search embedding model (BGE-M3 / Qwen3-Embedding)
    bge_m3_exists = data.get("bge_m3", False)
    status_str = "[green]ready[/green]" if bge_m3_exists else "[dim]not installed[/dim]"
    bge_info = cache_info.get("bge_m3", {})
    bge_detail = ""
    if isinstance(bge_info, dict):
        bge_detail = bge_info.get("model", "")
        size_mb = bge_info.get("size_mb", 0)
        if bge_detail and size_mb:
            bge_detail = f"{bge_detail} (~{size_mb}MB)"
    table.add_row("Search Embedding", status_str, str(bge_detail))

    # Local LLM
    llm_exists = data.get("local_llm", False)
    status_str = "[green]ready[/green]" if llm_exists else "[dim]not installed[/dim]"
    table.add_row("Local LLM", status_str, "")

    console.print(table)

    needs_install = data.get("needs_installation", False)
    if needs_install:
        console.print("  [yellow]Some models need installation.[/yellow]")
        console.print("  Run [bold]nmem models download[/bold] to install embedding model.")

    console.print()


def cmd_models_download(force: bool = False) -> None:
    """Download the embedding model for hybrid search."""
    # First check current status
    status = api_get("/models/bge-m3/status")
    if not force and status.get("exists"):
        if is_json_mode():
            output_json({"status": "already_installed", "model": status})
            return
        console.print()
        console.print("[green]ok[/green] Embedding model already installed")
        model_name = status.get("model_name", "")
        if model_name:
            console.print(f"  Model: [cyan]{model_name}[/cyan]")
        console.print("  Use [bold]--force[/bold] to reinstall")
        console.print()
        return

    if not is_json_mode():
        console.print()
        console.print("[bold]Downloading embedding model...[/bold]")
        console.print("  This may take several minutes depending on your connection.")
        console.print()

    # Use longer timeout for model download (10 minutes)
    url = f"{get_api_url()}/models/bge-m3/install"
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Downloading and installing model...[/cyan]"),
            console=console,
            transient=True,
            disable=is_json_mode(),
        ) as p:
            p.add_task("", total=None)
            response = api_request(
                "POST",
                url,
                json={"force_reinstall": force},
                timeout=600.0,
            )
            response.raise_for_status()
            result = response.json()
    except httpx.ConnectError:
        if is_json_mode():
            output_json({"error": "connection_failed"})
        else:
            print_error("Connection Failed", f"Cannot reach {get_api_url()}")
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        if is_json_mode():
            output_json({"error": "api_error", "status_code": e.response.status_code})
        else:
            print_error(
                f"Download Failed ({e.response.status_code})",
                "Model installation failed",
            )
        sys.exit(1)

    if is_json_mode():
        output_json(result)
        return

    if result.get("success", result.get("installed")):
        console.print("[green]ok[/green] Embedding model installed successfully")
        model_name = result.get("model_name", "")
        if model_name:
            console.print(f"  Model: [cyan]{model_name}[/cyan]")
    else:
        msg = result.get("error", result.get("message", "Unknown error"))
        print_error("Installation Failed", msg)


def cmd_models_reindex() -> None:
    """Rebuild the search index from the database."""
    if not is_json_mode():
        console.print()
        console.print("[bold]Rebuilding search index...[/bold]")
        console.print("  This reindexes all memories, threads, and entities.")
        console.print()

    url = f"{get_api_url()}/search-index/reindex"
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Reindexing...[/cyan]"),
            console=console,
            transient=True,
            disable=is_json_mode(),
        ) as p:
            p.add_task("", total=None)
            response = api_request(
                "POST",
                url,
                timeout=600.0,
            )
            response.raise_for_status()
            result = response.json()
    except httpx.ConnectError:
        if is_json_mode():
            output_json({"error": "connection_failed"})
        else:
            print_error("Connection Failed", f"Cannot reach {get_api_url()}")
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        if is_json_mode():
            output_json({"error": "api_error", "status_code": e.response.status_code})
        else:
            print_error(
                f"Reindex Failed ({e.response.status_code})",
                "Search index rebuild failed",
            )
        sys.exit(1)

    if is_json_mode():
        output_json(result)
        return

    if result.get("success"):
        console.print("[green]ok[/green] Search index rebuilt successfully")
        count = result.get("indexed_count", result.get("count", ""))
        if count:
            console.print(f"  Indexed: [cyan]{count}[/cyan] records")
    else:
        msg = result.get("error", result.get("message", "Unknown error"))
        print_error("Reindex Failed", msg)


# ═══════════════════════════════════════════════════════════════════════════════
# License Commands
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_license_status() -> None:
    """Show license status."""
    data = api_get("/api/license/status")
    if is_json_mode():
        output_json(data)
        return

    tier = data.get("tier", "free")
    email = data.get("email")
    activated = data.get("is_device_activated", False)
    activation_status = data.get("activation_status", "not_activated")
    device_id = data.get("device_id", "")
    memory_count = data.get("memory_count", 0)
    memory_limit = data.get("memory_limit", 20)

    console.print()
    console.print("[bold]License Status[/bold]")
    console.print()

    tier_display = "[green]Pro[/green]" if tier == "pro" else "[dim]Free[/dim]"
    console.print(f"  Tier:        {tier_display}")
    if email:
        console.print(f"  Email:       [cyan]{email}[/cyan]")
    console.print(f"  Activated:   {'[green]Yes[/green]' if activated else '[yellow]No[/yellow]'}")
    console.print(f"  Status:      {activation_status}")
    limit_str = "unlimited" if memory_limit == -1 else str(memory_limit)
    console.print(f"  Memories:    {memory_count} / {limit_str}")
    if device_id:
        console.print(f"  Device ID:   [dim]{device_id[:16]}...[/dim]")
    console.print()


def cmd_license_activate(license_code: str, email: str) -> None:
    """Activate a license key."""
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Activating license...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_post(
                "/api/license/activate",
                {"license_code": license_code, "email": email},
            )
    else:
        data = api_post(
            "/api/license/activate",
            {"license_code": license_code, "email": email},
        )

    if is_json_mode():
        output_json(data)
    else:
        status = data.get("status", "error")
        message = data.get("message", "")
        if status == "activated":
            print_success("License activated", message)
        elif status == "verified_offline":
            console.print(f"[yellow]![/yellow] {message}")
        else:
            print_error("Activation failed", message)


def cmd_license_deactivate() -> None:
    """Deactivate the current license."""
    if not is_json_mode():
        if not Confirm.ask("Deactivate license? This will remove all license data"):
            return

    data = api_post("/api/license/deactivate", {})

    if is_json_mode():
        output_json(data)
    else:
        if data.get("success"):
            print_success("License deactivated")
        else:
            print_error("Deactivation failed", str(data))


# ═══════════════════════════════════════════════════════════════════════════════
# Config Commands
# ═══════════════════════════════════════════════════════════════════════════════


def cmd_config_provider_list() -> None:
    """List configured LLM providers."""
    data = api_get("/remote-llm/config")
    if is_json_mode():
        output_json(data)
        return

    console.print()
    console.print("[bold]LLM Providers[/bold]")
    console.print()

    enabled = data.get("enabled", False)
    active = data.get("active_provider", "")
    console.print(f"  Remote LLM:    {'[green]Enabled[/green]' if enabled else '[dim]Disabled[/dim]'}")
    console.print(f"  Active:        [cyan]{active}[/cyan]" if active else "  Active:        [dim]none[/dim]")
    console.print()

    providers = data.get("providers", {})
    if providers:
        table = Table(box=box.SIMPLE, header_style="bold", show_edge=False)
        table.add_column("Provider", style="cyan")
        table.add_column("Type")
        table.add_column("Model")
        table.add_column("API Key")
        table.add_column("Active")

        for pid, p in providers.items():
            is_active = pid == active
            table.add_row(
                p.get("display_name") or pid,
                p.get("provider_type", ""),
                p.get("model", ""),
                "[green]set[/green]" if p.get("has_api_key") else "[dim]none[/dim]",
                "[green]>>>[/green]" if is_active else "",
            )
        console.print(table)
    else:
        console.print("  [dim]No providers configured.[/dim]")

    # Show purpose selections
    purposes = data.get("purposes", {})
    if purposes:
        console.print()
        console.print("[bold]Purpose Assignments[/bold]")
        for purpose, info in purposes.items():
            eff_provider = info.get("effective_provider", "")
            eff_model = info.get("effective_model", "")
            console.print(f"  {purpose}: [cyan]{eff_provider}[/cyan] / {eff_model}")
    console.print()


def cmd_config_provider_set(
    provider: str,
    api_key: str | None = None,
    model: str | None = None,
    api_base: str | None = None,
) -> None:
    """Configure an LLM provider."""
    payload: dict[str, Any] = {
        "enabled": True,
        "provider": provider,
        "model": model or "",
        "temperature": 0.7,
        "max_tokens": 8192,
        "timeout": 60.0,
    }
    if api_key:
        payload["api_key"] = api_key
    if api_base:
        payload["api_base"] = api_base

    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Saving provider config...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_post("/remote-llm/config", payload)
    else:
        data = api_post("/remote-llm/config", payload)

    if is_json_mode():
        output_json(data)
    else:
        if "error" in data:
            print_error("Failed to save provider config", data["error"])
        else:
            print_success(f"Provider '{provider}' configured")


def cmd_config_provider_test() -> None:
    """Test connection to the active LLM provider."""
    if not is_json_mode():
        with Progress(
            SpinnerColumn(),
            TextColumn("[cyan]Testing connection...[/cyan]"),
            console=console,
            transient=True,
        ) as p:
            p.add_task("", total=None)
            data = api_post("/remote-llm/test", {})
    else:
        data = api_post("/remote-llm/test", {})

    if is_json_mode():
        output_json(data)
    else:
        success = data.get("success", False)
        message = data.get("message", "")
        if success:
            provider = data.get("provider", "")
            model = data.get("model", "")
            print_success(f"Connection OK — {provider}/{model}", message)
        else:
            print_error("Connection test failed", message)


def cmd_config_provider_activate(provider: str) -> None:
    """Activate a specific LLM provider."""
    data = api_post("/remote-llm/activate", {"provider": provider})
    if is_json_mode():
        output_json(data)
    else:
        if "error" in data:
            print_error("Failed to activate provider", data["error"])
        else:
            print_success(f"Provider '{provider}' activated")


def cmd_config_settings_show() -> None:
    """Show knowledge processing settings."""
    data = api_get("/api/settings/knowledge-processing")
    if is_json_mode():
        output_json(data)
        return

    settings = data.get("settings", {})
    console.print()
    console.print("[bold]Knowledge Processing Settings[/bold]")
    console.print()

    # Boolean toggles
    toggles = [
        ("backgroundIntelligence", "Background Intelligence"),
        ("autoDailyBriefing", "Daily Briefing"),
        ("autoKGExtraction", "KG Extraction"),
        ("autoCommunityDetection", "Community Detection"),
        ("autoEVOLVESDetection", "EVOLVES Detection"),
        ("autoCrystallization", "Crystallization"),
        ("autoInsightDetection", "Insight Detection"),
        ("autoWMRefresh", "Working Memory Refresh"),
        ("generateCommunityAISummary", "Community AI Summaries"),
    ]

    for key, label in toggles:
        val = settings.get(key, False)
        indicator = "[green]on[/green]" if val else "[dim]off[/dim]"
        console.print(f"  {label:<30} {indicator}")

    console.print()

    # Numeric settings
    console.print(f"  Briefing Hour:               {settings.get('briefingHour', 5)}:00")
    console.print(f"  Community Interval:          {settings.get('communityDetectionIntervalDays', 14)} days")
    console.print(f"  Community Resolution:        {settings.get('communityResolution', 1.0)}")
    console.print(f"  KG Extraction Confidence:    {settings.get('kgExtractionConfidence', 0.7)}")
    console.print()


def cmd_config_settings_set(key: str, value: str) -> None:
    """Update a knowledge processing setting."""
    # Coerce value to appropriate type
    bool_keys = {
        "backgroundIntelligence", "autoKGExtraction", "autoCommunityDetection",
        "autoEVOLVESDetection", "autoDailyBriefing", "autoCrystallization",
        "autoInsightDetection", "autoWMRefresh", "generateCommunityAISummary",
    }
    int_keys = {"briefingHour", "communityDetectionIntervalDays"}
    float_keys = {"communityResolution", "kgExtractionConfidence"}

    if key in bool_keys:
        parsed: Any = value.lower() in ("true", "1", "yes", "on")
    elif key in int_keys:
        parsed = int(value)
    elif key in float_keys:
        parsed = float(value)
    else:
        print_error("Unknown setting", f"'{key}' is not a valid knowledge processing setting")
        return

    data = api_post("/api/settings/knowledge-processing", {key: parsed})

    if is_json_mode():
        output_json(data)
    else:
        if "error" in data:
            print_error("Failed to update setting", data["error"])
        else:
            print_success(f"Set {key} = {parsed}")


# ═══════════════════════════════════════════════════════════════════════════════
# Argument Parser
# ═══════════════════════════════════════════════════════════════════════════════


def create_parser() -> argparse.ArgumentParser:
    _server_examples = """\
  nmem serve                        Start server in foreground
  nmem serve --port 8080            Start on custom port
  nmem service install              Install + enable + start systemd service
  nmem service install --user       User-level service (no root)
  nmem service status               Show service status
  nmem service logs -f              Follow service logs
  nmem service stop                 Stop the service
  nmem service uninstall            Remove the service
""" if _is_server_platform else ""

    epilog = f"""
EXAMPLES
{_server_examples}\
  nmem status                       Check server
  nmem tui                          Launch interactive TUI
  nmem m                            List memories (alias)
  nmem m search "query"             Search memories
  nmem m add "content"              Add memory
  nmem t                            List threads (alias)
  nmem t create -t "Title" -f x.md  Create from file
  nmem wm                           Read today's Working Memory
  nmem wm --date 2026-02-12         Read archived WM
  nmem wm edit                      Edit WM in $EDITOR
  nmem wm edit -m "## Focus..."     Set WM content directly
  nmem wm history                   List past WM dates
  nmem models status                Show embedding model status
  nmem models download              Download embedding model
  nmem models reindex               Rebuild search index
  nmem license status               Check license
  nmem license activate <key> <email> Activate license
  nmem config provider list         List LLM providers
  nmem config provider set openai --api-key sk-xxx --model gpt-4o
  nmem config provider test         Test active provider
  nmem config settings              Show processing settings
  nmem config settings set briefingHour 8
  nmem --json m search "x"          JSON output

ALIASES
  m  = memories
  t  = threads
  wm = working-memory

SEARCH FILTERS (for 'm search' only)
  -l, --label LABEL    Filter by label
  -t, --time RANGE     today, week, month, year
  --importance MIN     Minimum importance
  --mode MODE          Search mode: normal (fast, default) or deep

ENVIRONMENT
  NMEM_API_URL         Override API URL
  NMEM_API_KEY         Optional API key (Bearer auth + proxy-safe fallback)
"""

    parser = argparse.ArgumentParser(
        prog="nmem",
        description="Nowledge Mem CLI",
        epilog=epilog,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "-v", "--version", action="version", version=f"nmem {__version__}"
    )
    parser.add_argument("--api-url", help="API server URL")
    parser.add_argument("-j", "--json", action="store_true", help="JSON output")

    subparsers = parser.add_subparsers(dest="command", metavar="COMMAND")

    # status
    subparsers.add_parser("status", help="Check server status")

    # stats
    subparsers.add_parser("stats", help="Show statistics")

    # tui - Interactive Terminal UI
    subparsers.add_parser("tui", help="Launch interactive TUI (Textual-based)")

    # serve / service — Linux only; on macOS/Windows the desktop app manages the backend
    if _is_server_platform:
        serve_parser = subparsers.add_parser(
            "serve", help="Run the server in the foreground (Ctrl+C to stop)",
        )
        serve_parser.add_argument(
            "--host", default="0.0.0.0", help="Host to bind to (default: 0.0.0.0)"
        )
        serve_parser.add_argument(
            "--port", type=int, default=14242, help="Port to bind to (default: 14242)"
        )

        svc_parser = subparsers.add_parser(
            "service", help="Manage background systemd service (install/start/stop)",
        )
        svc_subs = svc_parser.add_subparsers(dest="action")

        # Shared --user flag inherited by all service subcommands
        _user_parent = argparse.ArgumentParser(add_help=False)
        _user_parent.add_argument(
            "--user", action="store_true",
            help="User-level service (no root required)",
        )

        svc_install = svc_subs.add_parser(
            "install", help="Install, enable, and start the systemd service",
            parents=[_user_parent],
        )
        svc_install.add_argument(
            "--host", default="127.0.0.1",
            help="Host to bind to (default: 127.0.0.1)",
        )
        svc_install.add_argument(
            "--port", type=int, default=14242,
            help="Port to bind to (default: 14242)",
        )

        svc_subs.add_parser("uninstall", help="Stop, disable, and remove the service", parents=[_user_parent])
        svc_subs.add_parser("start", help="Start the service", parents=[_user_parent])
        svc_subs.add_parser("stop", help="Stop the service", parents=[_user_parent])
        svc_subs.add_parser("status", help="Show service status", parents=[_user_parent])

        svc_logs = svc_subs.add_parser("logs", help="Show service logs (journalctl)", parents=[_user_parent])
        svc_logs.add_argument(
            "-f", "--follow", action="store_true", help="Follow log output",
        )
        svc_logs.add_argument(
            "-n", "--lines", type=int, default=50,
            help="Number of log lines (default: 50)",
        )

    # models
    models_parser = subparsers.add_parser("models", help="Embedding model management")
    models_subs = models_parser.add_subparsers(dest="action")

    models_subs.add_parser("status", help="Show model status")

    dl = models_subs.add_parser("download", help="Download embedding model")
    dl.add_argument(
        "-f", "--force", action="store_true", help="Force reinstall"
    )

    models_subs.add_parser("reindex", help="Rebuild search index")

    # memories (with alias 'm')
    for name in ["memories", "m"]:
        mem_parser = subparsers.add_parser(name, help="Memory operations")
        mem_parser.add_argument("-n", "--limit", type=int, default=10)
        mem_parser.add_argument(
            "--importance", type=float, help="Filter by min importance (list only)"
        )
        mem_subs = mem_parser.add_subparsers(dest="action")

        s = mem_subs.add_parser("search", help="Search memories")
        s.add_argument("query", nargs="+")
        s.add_argument("-n", "--limit", type=int, default=10)
        s.add_argument(
            "-l", "--label", action="append", dest="labels", help="Filter by label"
        )
        s.add_argument("-t", "--time", dest="time_range", help="today/week/month/year")
        s.add_argument("--importance", type=float, help="Minimum importance")
        s.add_argument(
            "--mode",
            choices=["normal", "deep"],
            default="normal",
            help="Search mode: normal (fast, default) or deep (Graph and LLM-enhanced)",
        )

        sh = mem_subs.add_parser("show", help="Show details")
        sh.add_argument("id")
        sh.add_argument("--content-limit", type=int)

        a = mem_subs.add_parser("add", help="Add memory")
        a.add_argument("content")
        a.add_argument("-t", "--title")
        a.add_argument("-i", "--importance", type=float, default=0.5)
        a.add_argument(
            "-l", "--label", action="append", dest="labels", help="Add label (repeatable)"
        )
        a.add_argument(
            "-s", "--source", default="cli", help="Source identifier (default: cli)"
        )

        u = mem_subs.add_parser("update", help="Update")
        u.add_argument("id")
        u.add_argument("-t", "--title")
        u.add_argument("-c", "--content")
        u.add_argument("-i", "--importance", type=float)

        d = mem_subs.add_parser("delete", help="Delete")
        d.add_argument("id", nargs="+", help="Memory ID(s) to delete")
        d.add_argument("-f", "--force", action="store_true")

    # threads (with alias 't')
    for name in ["threads", "t"]:
        thr_parser = subparsers.add_parser(name, help="Thread operations")
        thr_parser.add_argument("-n", "--limit", type=int, default=10)
        thr_subs = thr_parser.add_subparsers(dest="action")

        s = thr_subs.add_parser("search", help="Search")
        s.add_argument("query", nargs="+")
        s.add_argument("-n", "--limit", type=int, default=10)

        sh = thr_subs.add_parser("show", help="Show details")
        sh.add_argument("id")
        sh.add_argument("-m", "--messages", type=int, default=10)
        sh.add_argument("--content-limit", type=int)

        c = thr_subs.add_parser("create", help="Create thread from content or file")
        c.add_argument("-t", "--title", required=True, help="Thread title")
        c.add_argument("-c", "--content", help="Text content (creates 1 user message)")
        c.add_argument(
            "-m",
            "--messages",
            help='JSON: [{"role":"user|assistant","content":"..."},...]',
        )
        c.add_argument(
            "-f", "--file", help="Import from file (1 msg unless Cursor format)"
        )
        c.add_argument(
            "-s", "--source", default="cli", help="Source tag (default: cli)"
        )

        d = thr_subs.add_parser("delete", help="Delete")
        d.add_argument("id")
        d.add_argument("-f", "--force", action="store_true")
        d.add_argument("--cascade", action="store_true")

        # save - Save coding session as thread
        sv = thr_subs.add_parser(
            "save", help="Save Claude Code or Codex session as thread"
        )
        sv.add_argument(
            "--from",
            dest="source_app",
            required=True,
            choices=["claude-code", "codex"],
            help="Source app: claude-code or codex",
        )
        sv.add_argument(
            "-p",
            "--project",
            default=".",
            help="Project directory path (default: current dir)",
        )
        sv.add_argument(
            "-m",
            "--mode",
            choices=["current", "all"],
            default="current",
            help="Save mode: current (latest) or all sessions",
        )
        sv.add_argument(
            "--session-id", help="Specific session ID (Codex only)"
        )
        sv.add_argument(
            "-s", "--summary", help="Brief session summary"
        )
        sv.add_argument(
            "--truncate",
            action="store_true",
            help="Truncate large tool results (>10KB)",
        )

    # working-memory (with alias 'wm')
    for name in ["working-memory", "wm"]:
        wm_parser = subparsers.add_parser(
            name, help="Working Memory — daily focus surface"
        )
        wm_parser.add_argument(
            "--date", help="Read archived WM for YYYY-MM-DD"
        )
        wm_subs = wm_parser.add_subparsers(dest="action")

        wm_subs.add_parser("read", help="Read working memory (default)")

        e = wm_subs.add_parser("edit", help="Edit working memory")
        e.add_argument(
            "-m", "--message", help="Set content directly (markdown string)"
        )

        h = wm_subs.add_parser("history", help="List archived dates")
        h.add_argument("-n", "--limit", type=int, default=30)

    # communities (with alias 'c')
    for name in ["communities", "c"]:
        com_parser = subparsers.add_parser(
            name, help="Knowledge communities — topic clusters"
        )
        com_parser.add_argument(
            "-n", "--limit", type=int, default=20, help="Max communities to show"
        )
        com_subs = com_parser.add_subparsers(dest="action")

        com_subs.add_parser("list", help="List communities (default)")

        sh = com_subs.add_parser("show", help="Show community details")
        sh.add_argument("id", help="Community UUID")

        det = com_subs.add_parser("detect", help="Trigger community detection")
        det.add_argument(
            "--resolution", type=float, default=1.0,
            help="Louvain resolution (higher = more communities)"
        )

    # license
    lic_parser = subparsers.add_parser("license", help="License management")
    lic_subs = lic_parser.add_subparsers(dest="action")

    lic_subs.add_parser("status", help="Show license status")

    act = lic_subs.add_parser("activate", help="Activate license")
    act.add_argument("code", help="Base64-encoded license key")
    act.add_argument("email", help="Email associated with the license")

    lic_subs.add_parser("deactivate", help="Deactivate license")

    # config
    cfg_parser = subparsers.add_parser("config", help="Configuration management")
    cfg_subs = cfg_parser.add_subparsers(dest="section")

    # config provider
    prov_parser = cfg_subs.add_parser("provider", help="LLM provider configuration")
    prov_subs = prov_parser.add_subparsers(dest="action")

    prov_subs.add_parser("list", help="List configured providers")

    ps = prov_subs.add_parser("set", help="Configure a provider")
    ps.add_argument("provider", help="Provider name (openai, anthropic, ollama, etc.)")
    ps.add_argument("--api-key", help="API key")
    ps.add_argument("--model", help="Model name")
    ps.add_argument("--api-base", help="Custom API base URL")

    prov_subs.add_parser("test", help="Test active provider connection")

    pa = prov_subs.add_parser("activate", help="Set active provider")
    pa.add_argument("provider", help="Provider name to activate")

    # config settings
    set_parser = cfg_subs.add_parser("settings", help="Knowledge processing settings")
    set_subs = set_parser.add_subparsers(dest="action")

    ss = set_subs.add_parser("set", help="Update a setting")
    ss.add_argument("key", help="Setting key (e.g. briefingHour, autoDailyBriefing)")
    ss.add_argument("value", help="New value")

    return parser


def main() -> int:
    parser = create_parser()
    args = parser.parse_args()

    if args.api_url:
        os.environ["NMEM_API_URL"] = args.api_url
    if getattr(args, "json", False):
        set_json_mode(True)

    cmd = args.command

    if cmd == "status":
        cmd_status()
    elif cmd == "stats":
        cmd_stats()
    elif cmd == "tui":
        # Launch the interactive TUI
        from .tui import run_tui

        run_tui()
    elif cmd == "serve":
        if not _is_server_platform:
            print_error(
                "Not Available",
                "'nmem serve' is for Linux server deployments.",
                "The desktop app manages the backend automatically. Use 'nmem status' to check.",
            )
            return 1
        cmd_serve(args.host, args.port)
    elif cmd == "service":
        if not _is_server_platform:
            print_error(
                "Not Available",
                "'nmem service' is for Linux server deployments.",
                "The desktop app manages the backend automatically. Use 'nmem status' to check.",
            )
            return 1
        user = getattr(args, "user", False)
        action = args.action
        if action == "install":
            cmd_service_install(args.host, args.port, user)
        elif action == "uninstall":
            cmd_service_uninstall(user)
        elif action == "start":
            cmd_service_start(user)
        elif action == "stop":
            cmd_service_stop(user)
        elif action == "logs":
            cmd_service_logs(user, getattr(args, "follow", False), getattr(args, "lines", 50))
        else:
            cmd_service_status(user)
    elif cmd == "models":
        action = args.action
        if action == "download":
            cmd_models_download(getattr(args, "force", False))
        elif action == "reindex":
            cmd_models_reindex()
        else:
            cmd_models_status()
    elif cmd in ("memories", "m"):
        action = args.action
        if action == "search":
            cmd_memories_search(
                " ".join(args.query),
                args.limit,
                getattr(args, "labels", None),
                getattr(args, "time_range", None),
                getattr(args, "importance", None),
                getattr(args, "mode", "normal"),
            )
        elif action == "show":
            cmd_memories_show(args.id, getattr(args, "content_limit", None))
        elif action == "add":
            cmd_memories_add(
                args.content,
                args.title,
                args.importance,
                getattr(args, "labels", None),
                getattr(args, "source", "cli"),
            )
        elif action == "update":
            cmd_memories_update(args.id, args.title, args.content, args.importance)
        elif action == "delete":
            cmd_memories_delete(args.id, args.force)
        else:
            cmd_memories_list(args.limit, getattr(args, "importance", None))
    elif cmd in ("threads", "t"):
        action = args.action
        if action == "search":
            cmd_threads_search(" ".join(args.query), args.limit)
        elif action == "show":
            cmd_threads_show(
                args.id,
                getattr(args, "messages", 10),
                getattr(args, "content_limit", None),
            )
        elif action == "create":
            cmd_threads_create(
                args.title,
                args.content,
                getattr(args, "messages", None),
                args.file,
                args.source,
            )
        elif action == "delete":
            cmd_threads_delete(args.id, args.force, getattr(args, "cascade", False))
        elif action == "save":
            cmd_threads_save(
                client=args.source_app,
                project_path=args.project,
                mode=args.mode,
                session_id=getattr(args, "session_id", None),
                summary=getattr(args, "summary", None),
                truncate=getattr(args, "truncate", False),
            )
        else:
            cmd_threads_list(args.limit)
    elif cmd in ("working-memory", "wm"):
        action = args.action
        if action == "edit":
            cmd_wm_edit(getattr(args, "message", None))
        elif action == "history":
            cmd_wm_history(getattr(args, "limit", 30))
        else:
            # Default: read (also handles explicit "read" action)
            cmd_wm_read(getattr(args, "date", None))
    elif cmd in ("communities", "c"):
        action = args.action
        if action == "show":
            cmd_communities_show(args.id)
        elif action == "detect":
            cmd_communities_detect(getattr(args, "resolution", 1.0))
        else:
            # Default: list
            cmd_communities_list(getattr(args, "limit", 20))
    elif cmd == "license":
        action = args.action
        if action == "activate":
            cmd_license_activate(args.code, args.email)
        elif action == "deactivate":
            cmd_license_deactivate()
        else:
            cmd_license_status()
    elif cmd == "config":
        section = getattr(args, "section", None)
        if section == "provider":
            action = getattr(args, "action", None)
            if action == "set":
                cmd_config_provider_set(
                    args.provider,
                    getattr(args, "api_key", None),
                    getattr(args, "model", None),
                    getattr(args, "api_base", None),
                )
            elif action == "test":
                cmd_config_provider_test()
            elif action == "activate":
                cmd_config_provider_activate(args.provider)
            else:
                cmd_config_provider_list()
        elif section == "settings":
            action = getattr(args, "action", None)
            if action == "set":
                cmd_config_settings_set(args.key, args.value)
            else:
                cmd_config_settings_show()
        else:
            if is_json_mode():
                output_json({"error": "no_section", "sections": ["provider", "settings"]})
            else:
                console.print("[bold]Available config sections:[/bold]")
                console.print("  provider  — LLM provider configuration")
                console.print("  settings  — Knowledge processing settings")
    else:
        if is_json_mode():
            cmds = ["status", "stats", "models", "m", "t", "wm", "c", "license", "config"]
            if _is_server_platform:
                cmds = ["serve", "service"] + cmds
            output_json({"error": "no_command", "commands": cmds})
        else:
            parser.print_help()
        return 0

    return 0


if __name__ == "__main__":
    sys.exit(main())
