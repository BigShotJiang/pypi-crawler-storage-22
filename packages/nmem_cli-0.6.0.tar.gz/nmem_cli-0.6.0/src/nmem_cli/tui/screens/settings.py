"""
Settings Screen - Configuration and preferences for server/headless deployments.

Provides license activation, LLM provider configuration, embedding model
management, knowledge processing settings, and keyboard shortcuts reference.
"""

from typing import Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Rule, Static

from ..api_client import ApiClient


# =============================================================================
# Modal: License Activation
# =============================================================================


class LicenseActivateModal(ModalScreen):
    """Modal for entering license key and email."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    DEFAULT_CSS = """
    LicenseActivateModal { align: center middle; }
    LicenseActivateModal > Vertical {
        width: 70%;
        max-width: 80;
        height: auto;
        max-height: 20;
        background: $surface;
        border: round $primary;
        padding: 1 2;
    }
    LicenseActivateModal .modal-title {
        text-style: bold;
        color: $primary;
        text-align: center;
        margin-bottom: 1;
    }
    LicenseActivateModal .field-label {
        color: $secondary;
        margin-top: 1;
    }
    LicenseActivateModal Input {
        margin-bottom: 1;
        border: round $boost;
    }
    LicenseActivateModal Input:focus { border: round $primary; }
    LicenseActivateModal .hint { color: $text-muted; text-align: center; }
    """

    def __init__(self, api_client: ApiClient) -> None:
        super().__init__()
        self.api_client = api_client

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("ACTIVATE LICENSE", classes="modal-title")
            yield Static("License Key (base64):", classes="field-label")
            yield Input(placeholder="Paste your license key...", id="lic-key-input")
            yield Static("Email:", classes="field-label")
            yield Input(placeholder="email@example.com", id="lic-email-input")
            yield Static("Press Enter on email field to activate  |  Esc to cancel", classes="hint")

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "lic-email-input":
            key_input = self.query_one("#lic-key-input", Input)
            email_input = self.query_one("#lic-email-input", Input)
            key = key_input.value.strip()
            email = email_input.value.strip()
            if not key or not email:
                return
            result = await self.api_client.activate_license(key, email)
            self.dismiss(result)

    def action_cancel(self) -> None:
        self.dismiss(None)


# =============================================================================
# Modal: Provider Configuration
# =============================================================================


class ProviderConfigModal(ModalScreen):
    """Modal for configuring an LLM provider."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
    ]

    DEFAULT_CSS = """
    ProviderConfigModal { align: center middle; }
    ProviderConfigModal > Vertical {
        width: 70%;
        max-width: 80;
        height: auto;
        max-height: 26;
        background: $surface;
        border: round $primary;
        padding: 1 2;
    }
    ProviderConfigModal .modal-title {
        text-style: bold;
        color: $primary;
        text-align: center;
        margin-bottom: 1;
    }
    ProviderConfigModal .field-label {
        color: $secondary;
        margin-top: 1;
    }
    ProviderConfigModal Input {
        margin-bottom: 1;
        border: round $boost;
    }
    ProviderConfigModal Input:focus { border: round $primary; }
    ProviderConfigModal .hint { color: $text-muted; text-align: center; }
    """

    def __init__(self, api_client: ApiClient) -> None:
        super().__init__()
        self.api_client = api_client

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("CONFIGURE LLM PROVIDER", classes="modal-title")
            yield Static("Provider (openai, anthropic, ollama, ...):", classes="field-label")
            yield Input(placeholder="e.g. anthropic", id="prov-name-input")
            yield Static("API Key:", classes="field-label")
            yield Input(placeholder="sk-...", password=True, id="prov-key-input")
            yield Static("Model:", classes="field-label")
            yield Input(placeholder="e.g. claude-sonnet-4-20250514", id="prov-model-input")
            yield Static("Base URL (optional):", classes="field-label")
            yield Input(placeholder="Leave empty for default", id="prov-base-input")
            yield Static("Press Enter on Base URL to save  |  Esc to cancel", classes="hint")

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "prov-base-input":
            provider = self.query_one("#prov-name-input", Input).value.strip()
            api_key = self.query_one("#prov-key-input", Input).value.strip()
            model = self.query_one("#prov-model-input", Input).value.strip()
            api_base = self.query_one("#prov-base-input", Input).value.strip()
            if not provider:
                return
            config: dict[str, Any] = {
                "enabled": True,
                "provider": provider,
                "model": model or "",
                "temperature": 0.7,
                "max_tokens": 8192,
                "timeout": 60.0,
            }
            if api_key:
                config["api_key"] = api_key
            if api_base:
                config["api_base"] = api_base
            result = await self.api_client.update_remote_llm_config(config)
            self.dismiss(result)

    def action_cancel(self) -> None:
        self.dismiss(None)


# =============================================================================
# Main Settings Screen
# =============================================================================


class SettingsScreen(VerticalScroll):
    """Screen for managing settings and configuration."""

    DEFAULT_CSS = """
    SettingsScreen {
        padding: 1 2;
    }

    SettingsScreen > .section-title {
        text-style: bold;
        color: $primary;
        margin-top: 1;
        padding: 0 1;
    }

    SettingsScreen > .setting {
        padding: 0 2;
        color: $text;
    }

    SettingsScreen > .setting-muted {
        padding: 0 2;
        color: $text-muted;
    }

    SettingsScreen > .key-group {
        margin-top: 1;
        padding: 0 2;
        color: $secondary;
    }

    SettingsScreen > .about-text {
        padding: 0 2;
        color: $primary;
    }

    SettingsScreen Rule {
        margin: 1 0;
        color: $boost;
    }

    SettingsScreen > .status-row {
        padding: 0 2;
        height: auto;
    }

    SettingsScreen > .status-row > Static {
        width: auto;
    }

    SettingsScreen > .status-row > Button {
        min-width: 12;
        margin-left: 2;
    }

    SettingsScreen > .action-button {
        margin: 0 2;
        min-width: 16;
    }

    SettingsScreen > .success-text {
        padding: 0 2;
        color: $success;
    }

    SettingsScreen > .warning-text {
        padding: 0 2;
        color: $warning;
    }

    SettingsScreen > .error-text {
        padding: 0 2;
        color: $error;
    }
    """

    def __init__(self, api_client: ApiClient, **kwargs) -> None:
        super().__init__(**kwargs)
        self.api_client = api_client

    def compose(self) -> ComposeResult:
        yield Static("◈ SETTINGS", classes="section-title")
        yield Rule()

        # --- Connection ---
        yield Static("◇ CONNECTION", classes="section-title")
        yield Static(f"API URL: {self.api_client.base_url}", classes="setting")
        yield Static("Status: ◌ checking...", id="server-status", classes="setting")

        yield Rule()

        # --- License ---
        yield Static("◇ LICENSE", classes="section-title")
        yield Static("Tier: ◌ checking...", id="license-tier", classes="setting")
        yield Static("", id="license-email", classes="setting")
        yield Static("", id="license-activation", classes="setting")
        yield Static("", id="license-device-id", classes="setting-muted")
        yield Button("Activate License", id="btn-activate-license", variant="primary", classes="action-button")
        yield Button("Deactivate", id="btn-deactivate-license", variant="error", classes="action-button", disabled=True)
        yield Static("", id="license-action-status", classes="setting-muted")

        yield Rule()

        # --- LLM Providers ---
        yield Static("◇ LLM PROVIDERS", classes="section-title")
        yield Static(
            "Configure remote LLM providers for AI features (Knowledge Agent, insights, etc.).",
            classes="setting-muted",
        )
        yield Static("Provider: ◌ checking...", id="llm-provider-status", classes="setting")
        yield Static("", id="llm-model-status", classes="setting")
        yield Static("", id="llm-providers-list", classes="setting-muted")
        yield Button("Configure Provider", id="btn-config-provider", variant="primary", classes="action-button")
        yield Button("Test Connection", id="btn-test-llm", variant="default", classes="action-button", disabled=True)
        yield Static("", id="llm-action-status", classes="setting-muted")

        yield Rule()

        # --- Search Index ---
        yield Static("◇ SEARCH INDEX", classes="section-title")
        yield Static(
            "Hybrid search uses semantic embeddings for better results.",
            classes="setting-muted",
        )
        yield Static("Embedding Model: ◌ checking...", id="bge-m3-status", classes="setting")
        yield Static("Search Index: ◌ checking...", id="search-index-status", classes="setting")
        yield Button("Download Model", id="btn-install-bge-m3", variant="primary", classes="action-button", disabled=True)
        yield Button("Rebuild Index", id="btn-reindex", variant="default", classes="action-button", disabled=True)
        yield Static("", id="search-action-status", classes="setting-muted")

        yield Rule()

        # --- Knowledge Processing ---
        yield Static("◇ KNOWLEDGE PROCESSING", classes="section-title")
        yield Static(
            "Background intelligence features (require LLM provider).",
            classes="setting-muted",
        )
        yield Static("◌ loading...", id="kp-settings-display", classes="setting")
        yield Button("Toggle Background Intelligence", id="btn-toggle-bg-intel", variant="default", classes="action-button")
        yield Button("Toggle Daily Briefing", id="btn-toggle-briefing", variant="default", classes="action-button")
        yield Button("Toggle KG Extraction", id="btn-toggle-kg-extract", variant="default", classes="action-button")
        yield Button("Toggle Community Detection", id="btn-toggle-community", variant="default", classes="action-button")
        yield Button("Toggle Crystallization", id="btn-toggle-crystal", variant="default", classes="action-button")
        yield Button("Toggle Insight Detection", id="btn-toggle-insight", variant="default", classes="action-button")
        yield Static("", id="kp-action-status", classes="setting-muted")

        yield Rule()

        # --- Keyboard Shortcuts ---
        yield Static("◇ KEYBOARD SHORTCUTS", classes="section-title")

        yield Static("◇ Navigation", classes="key-group")
        yield Static("  1-5       Switch between tabs", classes="setting-muted")
        yield Static("  /         Focus search input", classes="setting-muted")
        yield Static("  ?         Show help overlay", classes="setting-muted")
        yield Static("  q         Quit application", classes="setting-muted")

        yield Static("◇ Lists", classes="key-group")
        yield Static("  j / Down  Move down in list", classes="setting-muted")
        yield Static("  k / Up    Move up in list", classes="setting-muted")
        yield Static("  Enter     Select / Open item", classes="setting-muted")
        yield Static("  Esc       Go back / Close", classes="setting-muted")

        yield Static("◇ Memories", classes="key-group")
        yield Static("  a         Add new memory", classes="setting-muted")
        yield Static("  e         Edit selected memory", classes="setting-muted")
        yield Static("  c         Copy memory content", classes="setting-muted")
        yield Static("  d         Delete selected memory", classes="setting-muted")
        yield Static("  r         Refresh list", classes="setting-muted")

        yield Static("◇ Detail Views", classes="key-group")
        yield Static("  c         Copy content to clipboard", classes="setting-muted")
        yield Static("  y         Copy ID to clipboard", classes="setting-muted")

        yield Static("◇ Threads", classes="key-group")
        yield Static("  d         Distill to memories", classes="setting-muted")
        yield Static("  x         Delete thread", classes="setting-muted")
        yield Static("  r         Refresh list", classes="setting-muted")

        yield Static("◇ Graph", classes="key-group")
        yield Static("  e         Expand all nodes", classes="setting-muted")
        yield Static("  c         Collapse all nodes", classes="setting-muted")
        yield Static("  r         Refresh graph", classes="setting-muted")

        yield Rule()
        yield Static("◇ ABOUT", classes="section-title")
        yield Static("◈ Nowledge Mem", classes="about-text")
        yield Static("  AI that remembers your world", classes="setting-muted")
        yield Static(
            "  TUI built with Textual (textual.textualize.io)", classes="setting-muted"
        )
        yield Static("  Your data stays only on your device.", classes="setting-muted")

    def on_mount(self) -> None:
        self.run_worker(self._check_status(), exclusive=True, thread=False)
        self.run_worker(self._check_search_index_status(), exclusive=False, thread=False)
        self.run_worker(self._check_license_status(), exclusive=False, thread=False)
        self.run_worker(self._check_llm_status(), exclusive=False, thread=False)
        self.run_worker(self._check_kp_settings(), exclusive=False, thread=False)

    # =========================================================================
    # Status checks
    # =========================================================================

    async def _check_status(self) -> None:
        try:
            health = await self.api_client.get_health()
            status = health.get("status", "unknown")
            version = health.get("version", "unknown")

            status_widget = self.query_one("#server-status", Static)
            if status == "ok":
                status_widget.update(f"Status: ● Online (v{version})")
            else:
                status_widget.update(f"Status: ○ {status}")
        except Exception as e:
            self.query_one("#server-status", Static).update(f"Status: ✗ Error - {e}")

    async def _check_license_status(self) -> None:
        try:
            data = await self.api_client.get_license_status()
            if "error" in data:
                self.query_one("#license-tier", Static).update(f"Tier: ✗ {data['error']}")
                return

            tier = data.get("tier", "free")
            email = data.get("email", "")
            activated = data.get("is_device_activated", False)
            activation_status = data.get("activation_status", "not_activated")
            device_id = data.get("device_id", "")

            tier_display = "● Pro" if tier == "pro" else "○ Free"
            self.query_one("#license-tier", Static).update(f"Tier: {tier_display}")

            if email:
                self.query_one("#license-email", Static).update(f"Email: {email}")

            act_icon = "●" if activated else "○"
            self.query_one("#license-activation", Static).update(
                f"Activation: {act_icon} {activation_status}"
            )

            if device_id:
                self.query_one("#license-device-id", Static).update(
                    f"Device: {device_id[:16]}..."
                )

            # Enable/disable buttons based on state
            activate_btn = self.query_one("#btn-activate-license", Button)
            deactivate_btn = self.query_one("#btn-deactivate-license", Button)
            if tier == "pro":
                activate_btn.disabled = True
                activate_btn.label = "Licensed"
                activate_btn.variant = "success"
                deactivate_btn.disabled = False
            else:
                activate_btn.disabled = False
                activate_btn.label = "Activate License"
                activate_btn.variant = "primary"
                deactivate_btn.disabled = True

        except Exception as e:
            try:
                self.query_one("#license-tier", Static).update(f"Tier: ✗ Error - {e}")
            except Exception:
                pass

    async def _check_llm_status(self) -> None:
        try:
            data = await self.api_client.get_remote_llm_config()
            if "error" in data:
                self.query_one("#llm-provider-status", Static).update(
                    f"Provider: ✗ {data['error']}"
                )
                return

            enabled = data.get("enabled", False)
            active = data.get("active_provider", "")
            model = data.get("model", "")
            has_key = data.get("has_api_key", False)

            if enabled and active:
                key_str = "● key set" if has_key else "○ no key"
                self.query_one("#llm-provider-status", Static).update(
                    f"Provider: ● {active} ({key_str})"
                )
                self.query_one("#llm-model-status", Static).update(
                    f"Model: {model}" if model else ""
                )
                self.query_one("#btn-test-llm", Button).disabled = not has_key
            else:
                self.query_one("#llm-provider-status", Static).update(
                    "Provider: ○ Not configured"
                )
                self.query_one("#btn-test-llm", Button).disabled = True

            # Show provider list summary
            providers = data.get("providers", {})
            if providers:
                names = [
                    f"{p.get('display_name') or pid}"
                    + (" [key]" if p.get("has_api_key") else "")
                    for pid, p in providers.items()
                ]
                self.query_one("#llm-providers-list", Static).update(
                    f"Configured: {', '.join(names)}"
                )

        except Exception as e:
            try:
                self.query_one("#llm-provider-status", Static).update(
                    f"Provider: ✗ Error - {e}"
                )
            except Exception:
                pass

    async def _check_search_index_status(self) -> None:
        """Check embedding model and search index status."""
        try:
            model_status = await self.api_client.get_bge_m3_status()
            model_widget = self.query_one("#bge-m3-status", Static)
            install_btn = self.query_one("#btn-install-bge-m3", Button)
            reindex_btn = self.query_one("#btn-reindex", Button)

            model_name = model_status.get("model_name", "Embedding Model")
            size_mb = model_status.get("size_mb", 500)

            if "error" in model_status:
                model_widget.update(f"Embedding Model: ✗ Error - {model_status['error']}")
                install_btn.disabled = True
            elif model_status.get("exists"):
                model_widget.update(f"Embedding Model: ● {model_name} (~{size_mb}MB)")
                install_btn.disabled = True
                install_btn.label = "Installed"
                install_btn.variant = "success"
            else:
                model_widget.update(f"Embedding Model: ○ {model_name} (~{size_mb}MB)")
                install_btn.disabled = False

            index_status = await self.api_client.get_search_index_status()
            index_widget = self.query_one("#search-index-status", Static)

            if "error" in index_status:
                index_widget.update(f"Search Index: ✗ Error - {index_status['error']}")
                reindex_btn.disabled = True
            elif index_status.get("available"):
                index_widget.update("Search Index: ● Ready for hybrid search")
                reindex_btn.disabled = False
            elif index_status.get("model_cached"):
                index_widget.update("Search Index: ○ Model cached, index not initialized")
                reindex_btn.disabled = False
            else:
                index_widget.update(f"Search Index: ○ {model_name} required")
                reindex_btn.disabled = True

        except Exception as e:
            try:
                self.query_one("#bge-m3-status", Static).update(f"Embedding Model: ✗ Error - {e}")
                self.query_one("#search-index-status", Static).update(f"Search Index: ✗ Error - {e}")
            except Exception:
                pass

    async def _check_kp_settings(self) -> None:
        """Load knowledge processing settings."""
        try:
            data = await self.api_client.get_knowledge_processing_settings()
            if "error" in data:
                self.query_one("#kp-settings-display", Static).update(
                    f"✗ {data['error']}"
                )
                return

            settings = data.get("settings", {})
            self._render_kp_settings(settings)
        except Exception as e:
            try:
                self.query_one("#kp-settings-display", Static).update(f"✗ Error - {e}")
            except Exception:
                pass

    def _render_kp_settings(self, settings: dict[str, Any]) -> None:
        """Render knowledge processing settings display."""
        toggles = [
            ("backgroundIntelligence", "Background Intelligence"),
            ("autoDailyBriefing", "Daily Briefing"),
            ("autoKGExtraction", "KG Extraction"),
            ("autoCommunityDetection", "Community Detection"),
            ("autoCrystallization", "Crystallization"),
            ("autoInsightDetection", "Insight Detection"),
        ]
        lines = []
        for key, label in toggles:
            val = settings.get(key, False)
            icon = "●" if val else "○"
            lines.append(f"  {icon} {label}")

        hour = settings.get("briefingHour", 5)
        lines.append(f"  Briefing Hour: {hour}:00")

        self.query_one("#kp-settings-display", Static).update("\n".join(lines))

    # =========================================================================
    # Button handlers
    # =========================================================================

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id

        # Search index buttons
        if button_id == "btn-install-bge-m3":
            status_widget = self.query_one("#search-action-status", Static)
            await self._install_bge_m3(status_widget)
        elif button_id == "btn-reindex":
            status_widget = self.query_one("#search-action-status", Static)
            await self._reindex_search_index(status_widget)

        # License buttons
        elif button_id == "btn-activate-license":
            self.app.push_screen(
                LicenseActivateModal(self.api_client),
                callback=self._on_license_activate_result,
            )
        elif button_id == "btn-deactivate-license":
            result = await self.api_client.deactivate_license()
            status_widget = self.query_one("#license-action-status", Static)
            if result.get("success"):
                status_widget.update("License deactivated.")
            else:
                status_widget.update(f"✗ {result}")
            await self._check_license_status()

        # LLM provider buttons
        elif button_id == "btn-config-provider":
            self.app.push_screen(
                ProviderConfigModal(self.api_client),
                callback=self._on_provider_config_result,
            )
        elif button_id == "btn-test-llm":
            status_widget = self.query_one("#llm-action-status", Static)
            status_widget.update("Testing connection...")
            test_btn = self.query_one("#btn-test-llm", Button)
            test_btn.disabled = True
            try:
                result = await self.api_client.test_remote_llm_connection()
                if result.get("success"):
                    provider = result.get("provider", "")
                    model = result.get("model", "")
                    status_widget.update(f"● Connection OK — {provider}/{model}")
                else:
                    status_widget.update(f"✗ {result.get('message', 'Test failed')}")
            except Exception as e:
                status_widget.update(f"✗ Error: {e}")
            finally:
                test_btn.disabled = False

        # Knowledge processing toggles
        elif button_id and button_id.startswith("btn-toggle-"):
            await self._handle_kp_toggle(button_id)

    async def _on_license_activate_result(self, result: dict | None) -> None:
        """Callback for license activation modal."""
        if result:
            status = result.get("status", "error")
            msg = result.get("message", "")
            status_widget = self.query_one("#license-action-status", Static)
            if status in ("activated", "verified_offline"):
                status_widget.update(f"● {msg}")
            else:
                status_widget.update(f"✗ {msg}")
            await self._check_license_status()

    async def _on_provider_config_result(self, result: dict | None) -> None:
        """Callback for provider configuration modal."""
        if result:
            status_widget = self.query_one("#llm-action-status", Static)
            if "error" in result:
                status_widget.update(f"✗ {result['error']}")
            else:
                status_widget.update("Provider configured.")
            await self._check_llm_status()

    async def _handle_kp_toggle(self, button_id: str) -> None:
        """Toggle a knowledge processing setting."""
        toggle_map = {
            "btn-toggle-bg-intel": "backgroundIntelligence",
            "btn-toggle-briefing": "autoDailyBriefing",
            "btn-toggle-kg-extract": "autoKGExtraction",
            "btn-toggle-community": "autoCommunityDetection",
            "btn-toggle-crystal": "autoCrystallization",
            "btn-toggle-insight": "autoInsightDetection",
        }
        key = toggle_map.get(button_id)
        if not key:
            return

        status_widget = self.query_one("#kp-action-status", Static)

        # Get current value and flip it
        current = await self.api_client.get_knowledge_processing_settings()
        settings = current.get("settings", {})
        new_val = not settings.get(key, False)

        result = await self.api_client.update_knowledge_processing_settings({key: new_val})
        if "error" in result:
            status_widget.update(f"✗ {result['error']}")
        else:
            state = "on" if new_val else "off"
            status_widget.update(f"Set {key} = {state}")
            self._render_kp_settings(result.get("settings", {}))

    # =========================================================================
    # Existing action handlers
    # =========================================================================

    async def _install_bge_m3(self, status_widget: Static) -> None:
        """Download and install embedding model."""
        try:
            install_btn = self.query_one("#btn-install-bge-m3", Button)
            install_btn.disabled = True
            install_btn.label = "Downloading..."
            status_widget.update("Downloading embedding model... This may take a few minutes.")

            result = await self.api_client.install_bge_m3()

            if result.get("success"):
                status_widget.update("Model installed successfully! Click 'Rebuild Index' to enable hybrid search.")
                install_btn.label = "Installed"
                install_btn.variant = "success"
                await self._check_search_index_status()
            else:
                error_msg = result.get("error") or result.get("message", "Unknown error")
                status_widget.update(f"Installation failed: {error_msg}")
                install_btn.label = "Download Model"
                install_btn.disabled = False

        except Exception as e:
            status_widget.update(f"Installation error: {e}")
            try:
                install_btn = self.query_one("#btn-install-bge-m3", Button)
                install_btn.label = "Download Model"
                install_btn.disabled = False
            except Exception:
                pass

    async def _reindex_search_index(self, status_widget: Static) -> None:
        """Rebuild the search index."""
        try:
            reindex_btn = self.query_one("#btn-reindex", Button)
            reindex_btn.disabled = True
            reindex_btn.label = "Reindexing..."
            status_widget.update("Rebuilding search index... This may take a while for large databases.")

            result = await self.api_client.reindex_search_index()

            if result.get("success"):
                memories = result.get("memories", 0)
                messages = result.get("messages", 0)
                communities = result.get("communities", 0)
                entities = result.get("entities", 0)
                status_widget.update(
                    f"Reindex complete! Indexed {memories} memories, {messages} messages, "
                    f"{communities} communities, {entities} entities."
                )
                await self._check_search_index_status()
            else:
                error_msg = result.get("error") or result.get("message", "Unknown error")
                status_widget.update(f"Reindex failed: {error_msg}")

            reindex_btn.label = "Rebuild Index"
            reindex_btn.disabled = False

        except Exception as e:
            status_widget.update(f"Reindex error: {e}")
            try:
                reindex_btn = self.query_one("#btn-reindex", Button)
                reindex_btn.label = "Rebuild Index"
                reindex_btn.disabled = False
            except Exception:
                pass
