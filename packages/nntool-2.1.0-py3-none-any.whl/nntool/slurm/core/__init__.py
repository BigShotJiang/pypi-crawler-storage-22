from ._slurm import SlurmFunction as SlurmBackend


__all__ = ["SlurmBackend"]
