# noapi-google-search-mcp - Promotion Plan

## LinkedIn Post

---

Just shipped something I've been working on and I'm pretty excited about it.

**noapi-google-search-mcp** - an MCP server that gives local LLMs real Google search and browsing abilities. No API keys, no token limits, no Google Cloud setup. It uses a local headless Chromium browser under the hood, so your LLM gets the same Google results you'd see in your browser.

The problem it solves: most Google search integrations for LLMs require API keys, paid quotas, and return limited Custom Search Engine results. This just works out of the box with a single pip install.

It comes with 14 tools:
- Google Search (with time filtering, site filtering, language/region support)
- Google Shopping, Flights, Hotels
- Google Translate
- Google Maps, Weather, Finance
- Google News, Scholar, Books, Images, Trends
- A page fetcher to read full articles from search results

Works with LM Studio, Claude Desktop, and any MCP-compatible client.

Everything runs locally through Playwright and Chromium - no data goes through third-party APIs, no usage limits, completely free.

pip install noapi-google-search-mcp

GitHub: https://github.com/VincentKaufmann/noapi-google-search-mcp
PyPI: https://pypi.org/project/noapi-google-search-mcp/

Would love to hear feedback from anyone running local LLMs or building with MCP.

#MCP #LocalLLM #OpenSource #LMStudio #AI #DeveloperTools

---

## Where to Share

### MCP Directories (submit to all of these)

| Platform | URL | How to Submit |
|----------|-----|---------------|
| Smithery.ai | https://smithery.ai/ | Largest MCP marketplace (7,300+ tools). Follow their docs at https://smithery.ai/docs |
| mcp.so | https://mcp.so/ | Open an issue at https://github.com/chatmcp/mcp-directory/issues/1 |
| mcpservers.org | https://mcpservers.org/submit | Submission form |
| Glama.ai | https://glama.ai/mcp/servers | Get "server author" flair |
| LobeHub | https://lobehub.com/mcp | Click "Submit MCP" |
| Cline Marketplace | https://github.com/cline/mcp-marketplace | Open an issue with repo URL |
| PulseMCP | https://www.pulsemcp.com/servers | 8,200+ servers indexed |
| MCPMarket | https://mcpmarket.com/submit | Submit GitHub repo URL |
| Portkey | https://portkey.ai/mcp-servers | Curated listing |
| MCP Server Finder | https://www.mcpserverfinder.com/ | Another directory |

### GitHub Awesome Lists (open PRs)

| Repository | Notes |
|-----------|-------|
| https://github.com/punkpeye/awesome-mcp-servers | Major list, submit via mcpservers.org |
| https://github.com/wong2/awesome-mcp-servers | Very popular curated list |
| https://github.com/appcypher/awesome-mcp-servers | Production-ready servers |
| https://github.com/modelcontextprotocol/servers | Official MCP reference servers |
| https://github.com/rafska/awesome-local-llm | Local LLM tools - great fit for "no API key" angle |

### Reddit

| Subreddit | Members | Why |
|-----------|---------|-----|
| r/LocalLLaMA | ~620k | #1 target. "No API key" angle resonates perfectly |
| r/ClaudeAI | Large | Claude Desktop integration |
| r/selfhosted | Very large | Self-hosted, no third-party dependencies |
| r/ChatGPTCoding | Large | Developers using AI for coding |
| r/ollama | Growing | Local LLM users |
| r/artificial | Large | Broad AI community |
| r/ArtificialIntelligence | ~1.4M | Trending AI subreddit |
| r/MachineLearning | Very large | Accepts project demos |

### Discord Servers

| Community | Invite | Members |
|-----------|--------|---------|
| LM Studio | https://discord.com/invite/lmstudio | ~78k |
| MCP Official | https://discord.com/invite/model-context-protocol-1312302100125843476 | ~11k |
| MCP Contributors | https://discord.com/invite/6CSzBmMkjX | ~3.6k |

### Hacker News

| Channel | URL |
|---------|-----|
| Show HN | https://news.ycombinator.com/submit |

Title format: "Show HN: noapi-google-search-mcp - Google Search MCP for local LLMs, no API key"

### Hugging Face

| Channel | URL |
|---------|-----|
| LM Studio Community | https://huggingface.co/lmstudio-community |
| HF Discussions | https://huggingface.co/discussions |

### LLM Enthusiast Forums and Communities

| Platform | URL | Notes |
|----------|-----|-------|
| LM Studio GitHub Discussions | https://github.com/lmstudio-ai/lmstudio/discussions | Feature showcases welcome |
| Ollama GitHub Discussions | https://github.com/ollama/ollama/discussions | Active local LLM community |
| LocalAI Community | https://github.com/mudler/LocalAI/discussions | Self-hosted AI enthusiasts |
| Jan.ai Discord | https://discord.gg/jan | Open-source ChatGPT alternative community |
| AI Stack Exchange | https://ai.stackexchange.com/ | Q&A format, good for visibility |
| LangChain Discord | https://discord.gg/langchain | Large developer community building with LLMs |
| Weights & Biases Community | https://community.wandb.ai/ | ML practitioners |
| MLOps Community Slack | https://mlops.community/ | ML infrastructure and tooling |
| TheBloke Discord | Discord for quantized model users | Overlaps heavily with local LLM crowd |

### Blog Posts / Tutorials

| Platform | Strategy |
|----------|----------|
| Dev.to | "How to add Google Search to LM Studio with no API key" |
| Medium | Publish under AI/MCP tags |
| Hashnode | Developer-focused blogging platform |
| Product Hunt | Launch as a developer tool |

### Key Messaging

Lead with these selling points:
1. **No API key required** - just pip install and go
2. **Free, no usage limits** - no Google Cloud project, no paid quotas
3. **14 tools** - search, shopping, flights, hotels, translate, maps, weather, finance, news, scholar, books, images, trends, page fetcher
4. **Real Google results** - not Custom Search Engine (different ranking)
5. **Works with LM Studio + Claude Desktop** - the two biggest MCP clients
6. **Runs locally** - headless Chromium via Playwright, no data through third-party APIs
