"""Test all new v0.1.5 tools + sanity check existing ones."""

import asyncio
import sys
import time

sys.path.insert(0, "/home/xentureon/google-search-mcp/src")

from google_search_mcp.server import (
    _do_google_search,
    _do_google_news,
    _do_google_scholar,
    _do_google_images,
    _do_google_trends,
    _do_google_maps,
    _do_google_finance,
    _do_google_weather,
    _do_google_shopping,
    _do_google_books,
    _do_google_translate,
    _do_google_flights,
    _do_google_hotels,
    _fetch_page_text,
)

PASS = "PASS"
FAIL = "FAIL"


async def test_tool(name, coro, success_check):
    print(f"\n{'='*60}")
    print(f"Testing: {name}")
    print(f"{'='*60}")
    start = time.time()
    try:
        result = await coro
        elapsed = time.time() - start
        passed = success_check(result)
        status = PASS if passed else FAIL
        print(f"Result preview: {result[:400]}...")
        print(f"Status: {status} ({elapsed:.1f}s)")
        return name, status
    except Exception as e:
        elapsed = time.time() - start
        print(f"Exception: {e}")
        print(f"Status: {FAIL} ({elapsed:.1f}s)")
        return name, FAIL


async def main():
    results = []

    # NEW TOOLS
    r = await test_tool("google_shopping", _do_google_shopping("Sony WH-1000XM5", 3),
        lambda r: "failed" not in r.lower() and "No shopping" not in r)
    results.append(r)

    r = await test_tool("google_books", _do_google_books("machine learning", 3),
        lambda r: "failed" not in r.lower() and "No book" not in r)
    results.append(r)

    r = await test_tool("google_translate", _do_google_translate("Hello world", "Spanish"),
        lambda r: "failed" not in r.lower() and "Could not" not in r)
    results.append(r)

    r = await test_tool("google_flights", _do_google_flights("New York", "London"),
        lambda r: "failed" not in r.lower())
    results.append(r)

    r = await test_tool("google_hotels", _do_google_hotels("Paris", 3),
        lambda r: "failed" not in r.lower())
    results.append(r)

    # EXISTING TOOLS (sanity check)
    r = await test_tool("google_search", _do_google_search("Python", num_results=2),
        lambda r: "URL:" in r)
    results.append(r)

    r = await test_tool("google_news", _do_google_news("AI", 2),
        lambda r: "URL:" in r)
    results.append(r)

    r = await test_tool("google_maps", _do_google_maps("coffee shops Berlin", 2),
        lambda r: "failed" not in r.lower())
    results.append(r)

    r = await test_tool("google_finance", _do_google_finance("AAPL:NASDAQ"),
        lambda r: "Price:" in r)
    results.append(r)

    r = await test_tool("google_weather", _do_google_weather("Tokyo"),
        lambda r: "Temperature:" in r)
    results.append(r)

    r = await test_tool("google_scholar", _do_google_scholar("attention", 2),
        lambda r: "URL:" in r)
    results.append(r)

    r = await test_tool("google_images", _do_google_images("cat", 2),
        lambda r: "http" in r)
    results.append(r)

    r = await test_tool("visit_page", _fetch_page_text("https://example.com"),
        lambda r: "Example Domain" in r)
    results.append(r)

    # Summary
    print(f"\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")
    passed = sum(1 for _, s in results if s == PASS)
    failed_list = [(n, s) for n, s in results if s == FAIL]
    for name, status in results:
        print(f"  [{'OK' if status == PASS else 'FAILED'}] {name}")
    print(f"\n{passed}/{len(results)} passed, {len(failed_list)} failed")
    if failed_list:
        print("\nFailed:")
        for n, _ in failed_list:
            print(f"  - {n}")


if __name__ == "__main__":
    asyncio.run(main())
