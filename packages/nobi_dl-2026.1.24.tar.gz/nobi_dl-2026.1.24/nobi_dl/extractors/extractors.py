from .bollyflix import BollyFlixME
from .hdhub import Hdhub4uME
from .vegamovies import VegaMoviesME
from .fourkhdhub import FourkhdhubME
from .moviesmod import MoviesModME

ALL = [BollyFlixME, Hdhub4uME, VegaMoviesME, FourkhdhubME, MoviesModME]
