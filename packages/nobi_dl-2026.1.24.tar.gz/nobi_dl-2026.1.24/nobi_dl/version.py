__version__ = "2026.1.24"

REPOSITORY = "0xvd/nobi-dl"
