__version__ = "2026.1.31.post1"

REPOSITORY = "0xvd/nobi-dl"
