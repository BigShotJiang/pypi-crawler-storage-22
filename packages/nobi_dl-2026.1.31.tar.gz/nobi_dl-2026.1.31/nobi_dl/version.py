__version__ = "2026.1.31"

REPOSITORY = "0xvd/nobi-dl"
