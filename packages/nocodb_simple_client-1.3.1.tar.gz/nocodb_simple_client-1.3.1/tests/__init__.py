"""Tests for nocodb-simple-client."""
