from .nofuture import *

__doc__ = nofuture.__doc__
if hasattr(nofuture, "__all__"):
    __all__ = nofuture.__all__