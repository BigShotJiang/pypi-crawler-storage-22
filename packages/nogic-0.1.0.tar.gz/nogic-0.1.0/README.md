# Nogic CLI

Graph visualization for Developers and AI Agents.

## Installation

### Prerequisites

- Python 3.11 or higher

### Install from PyPI

```bash
pip install nogic
```

### Install from Source

```bash
git clone https://github.com/nogic/cli.git
cd cli
pip install .
```

## Quick Start

### 1. Login with your API key

```bash
nogic login
```

You'll be prompted to enter your API key from the Nogic dashboard.

### 2. Initialize a project

```bash
cd /path/to/your/project
nogic init
```

This creates a `.nogic/` directory with project configuration.

### 3. Sync your codebase

One-time sync:

```bash
nogic sync
```

Or watch for continuous syncing:

```bash
nogic watch
```

## Commands

### `nogic login`

Authenticate with the Nogic API.

```bash
nogic login
nogic login --api-key YOUR_API_KEY
```

### `nogic init`

Initialize a project for Nogic tracking.

```bash
nogic init                           # Initialize current directory
nogic init /path/to/project          # Initialize specific directory
nogic init --name "My Project"       # Set project name
nogic init --project-id UUID         # Use existing project ID
```

### `nogic sync`

Perform a one-time full sync of your codebase.

```bash
nogic sync                           # Sync current directory
nogic sync /path/to/project          # Sync specific directory
nogic sync --ignore "*.log"          # Ignore specific patterns
```

### `nogic watch`

Continuously monitor and sync file changes.

```bash
nogic watch                          # Watch current directory
nogic watch /path/to/project         # Watch specific directory
nogic watch --ignore "*.log"         # Ignore specific patterns
```

Press `Ctrl+C` to stop watching.

### `nogic projects`

Manage your Nogic projects.

```bash
nogic projects list                  # List all projects
nogic projects create "Project Name" # Create new project
nogic projects create "Name" --use   # Create and set as current
nogic projects use PROJECT_ID        # Set current project
```

## Configuration

### Environment Variables

Create a `.env` file or set environment variables:

```bash
NOGIC_API_URL=http://localhost:8000  # Backend API URL
NOGIC_API_KEY=your-api-key           # API key (alternative to login)
```

### Config Files

- **Global config**: `~/.nogic/config.json` - Stores API key and telemetry preference
- **Project config**: `.nogic/config.json` - Stores project ID

## Telemetry

Nogic collects anonymous usage data to improve the product. All data is anonymized.

### Manage Telemetry

```bash
nogic telemetry status   # Check current status
nogic telemetry disable  # Opt out
nogic telemetry enable   # Opt back in
```

### Environment Variables

```bash
NOGIC_TELEMETRY_DISABLED=1  # Disable telemetry
DO_NOT_TRACK=1              # Standard opt-out (also works)
```

### Default Ignore Patterns

The following patterns are ignored by default:

- `.git/`
- `__pycache__/`
- `node_modules/`
- `.venv/`
- `.nogic/`
- `*.pyc`
- `.DS_Store`

Add custom patterns with the `--ignore` flag.

## License

MIT
