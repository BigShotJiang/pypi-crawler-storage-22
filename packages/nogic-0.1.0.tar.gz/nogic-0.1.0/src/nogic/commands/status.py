"""Status command - show project status and verify configuration."""

from pathlib import Path
from datetime import datetime
from typing import Annotated

import httpx
import typer

from nogic.config import Config, CONFIG_DIR, is_dev_mode, get_api_url
from nogic.api import NogicClient
from nogic.api.client import get_directory_hash
from nogic import ui


def status(
    directory: Annotated[Path, typer.Argument(help="Path to the project directory.")] = Path("."),
):
    """Show project status and verify configuration."""
    directory = directory.resolve()
    nogic_dir = directory / CONFIG_DIR
    current_dir_hash = get_directory_hash(str(directory))

    if not nogic_dir.exists():
        ui.error("Not a Nogic project.")
        ui.dim("Run `nogic init` to initialize your project.")
        raise typer.Exit(1)

    config = Config.load(directory)

    if is_dev_mode():
        ui.dev_banner(get_api_url())

    ui.banner("nogic status")

    ui.section("Local Configuration")
    ui.kv("Directory", str(directory))
    ui.kv("Project ID", config.project_id or "(not set)")
    ui.kv("Project Name", config.project_name or "(not set)")
    ui.kv("Directory Hash", f"{current_dir_hash[:16]}...")
    ui.kv("Logged in", "Yes" if config.api_key else "[red]No[/]")

    if config.directory_hash and config.directory_hash != current_dir_hash:
        ui.console.print()
        ui.warn("Directory hash mismatch!")
        ui.kv("Config hash", f"{config.directory_hash[:16]}...", indent=4)
        ui.kv("Current hash", f"{current_dir_hash[:16]}...", indent=4)
        ui.dim("    Project may have been moved. Run 'nogic init --link' to update.")

    # Backend verification
    if config.api_key and config.project_id:
        client = NogicClient(config)
        try:
            with ui.status_spinner("Checking backend..."):
                backend_project = client.get_project_by_directory(current_dir_hash)

            ui.section("Backend Status")
            if backend_project:
                ui.kv("Project found", backend_project.name)
                ui.kv("Project ID", backend_project.id)
                if backend_project.created_at:
                    ui.kv("Created", _format_datetime(backend_project.created_at))
                if backend_project.updated_at:
                    ui.kv("Updated", _format_datetime(backend_project.updated_at))

                if backend_project.id != config.project_id:
                    ui.console.print()
                    ui.warn("Project ID mismatch!")
                    ui.kv("Local config", config.project_id, indent=4)
                    ui.kv("Backend", backend_project.id, indent=4)
                    ui.dim("    Run 'nogic init --link' to fix.")
            else:
                ui.dim("  No project found for this directory in backend")
                if config.project_id:
                    ui.dim(f"  Local config has project ID: {config.project_id}")
                    ui.dim("  Consider running 'nogic init --link' to link it.")

        except httpx.HTTPStatusError as e:
            ui.section("Backend Status")
            ui.error(f"Error ({e.response.status_code})")
            if e.response.status_code == 401:
                ui.dim("  Authentication failed. Run: nogic login")
        except httpx.RequestError:
            ui.section("Backend Status")
            ui.error("Connection failed")
        finally:
            client.close()
    elif not config.api_key:
        ui.section("Backend Status")
        ui.dim("  Not logged in. Run `nogic login` to authenticate.")
    else:
        ui.section("Backend Status")
        ui.dim("  No project configured. Run `nogic init` to set up.")

    ui.console.print()


def _format_datetime(dt_string: str) -> str:
    try:
        dt = datetime.fromisoformat(dt_string.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except (ValueError, AttributeError):
        return dt_string
