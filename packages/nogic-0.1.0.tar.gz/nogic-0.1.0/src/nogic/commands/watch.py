"""Watch command for file syncing."""

import time
from pathlib import Path
from typing import Annotated, Optional

import typer

from nogic.config import Config, is_dev_mode, get_api_url
from nogic.ignore import build_ignore_matcher
from nogic.watcher import FileMonitor, SyncService
from nogic import ui


def watch(
    directory: Annotated[Path, typer.Argument(help="Path to the directory to watch.")] = Path("."),
    ignore: Annotated[Optional[list[str]], typer.Option("--ignore", help="Patterns to ignore.")] = None,
):
    """Watch a directory for file changes and sync to backend."""
    directory = directory.resolve()
    nogic_dir = directory / ".nogic"
    ignore = ignore or []

    if not nogic_dir.exists():
        ui.error("Not a Nogic project.")
        ui.dim("Run `nogic init` to initialize your project.")
        raise typer.Exit(1)

    config = Config.load(directory)

    if not config.api_key:
        ui.error("Not logged in.")
        ui.dim("Run `nogic login` to authenticate.")
        raise typer.Exit(1)

    if not config.project_id:
        ui.error("No project configured.")
        ui.dim("Run `nogic init` to initialize your project.")
        raise typer.Exit(1)

    if is_dev_mode():
        ui.dev_banner(get_api_url())

    ui.banner("nogic watch", str(directory))
    ui.kv("Project", f"{config.project_id[:8]}...")

    sync_service = SyncService(config, directory, log=lambda msg: ui.dim(f"  {msg}"))

    should_ignore = build_ignore_matcher(directory, extra_patterns=ignore)

    # Initial scan
    try:
        sync_service.initial_scan(directory, should_ignore)
    except KeyboardInterrupt:
        ui.console.print()
        ui.dim("Interrupted during initial scan. Cleaning up...")
        try:
            sync_service.client.clear_staging(config.project_id)
        except Exception:
            pass
        sync_service.close()
        raise typer.Exit(1)

    def on_change(path: Path):
        try:
            rel = path.relative_to(directory)
        except ValueError:
            return
        try:
            if sync_service.sync_file_immediate(path):
                ui.console.print(f"  [green]SYNCED[/] {rel}")
        except Exception as e:
            err_msg = str(e)
            if "413" in err_msg:
                ui.console.print(f"  [yellow]SKIP[/] {rel} (file too large for API)")
            elif "503" in err_msg or "502" in err_msg:
                ui.console.print(f"  [red]ERROR[/] {rel} (backend unavailable, will sync on next change)")
            else:
                ui.console.print(f"  [red]ERROR[/] {rel}: {err_msg[:120]}")

    def on_delete(path: Path):
        try:
            rel = path.relative_to(directory)
        except ValueError:
            return
        try:
            if sync_service.delete_file_immediate(path):
                ui.console.print(f"  [red]DELETED[/] {rel}")
            else:
                ui.console.print(f"  [dim]DELETED[/] {rel} (not indexed)")
        except Exception as e:
            ui.console.print(f"  [red]DELETED[/] {rel} (error: {str(e)[:80]})")

    monitor = FileMonitor(
        root_path=directory,
        on_change=on_change,
        on_delete=on_delete,
        should_ignore=should_ignore,
    )

    ui.console.print()
    ui.info("Watching for changes... (Ctrl+C to stop)")
    ui.console.print()

    monitor.start()
    try:
        while monitor.is_alive():
            time.sleep(1)
    except KeyboardInterrupt:
        ui.console.print()
        ui.dim("Stopping...")
    finally:
        monitor.stop()
        sync_service.close()

    ui.success("Done.")
