"""Main CLI entry point."""

import atexit

import typer

from nogic import __version__
from nogic import telemetry

app = typer.Typer(
    name="nogic",
    help="Nogic CLI - Code Intelligence for AI Agents.",
    no_args_is_help=True,
    rich_markup_mode="rich",
    pretty_exceptions_enable=False,
)


def version_callback(value: bool):
    if value:
        typer.echo(f"nogic {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(None, "--version", "-V", callback=version_callback, is_eager=True, help="Show version."),
):
    """Nogic CLI - Code Intelligence for AI Agents."""
    atexit.register(telemetry.shutdown)


# Import and register commands
from nogic.commands.login import login
from nogic.commands.init import init
from nogic.commands.watch import watch
from nogic.commands.sync import sync
from nogic.commands.reindex import reindex
from nogic.commands.status import status
from nogic.commands.projects import projects_app
from nogic.commands.telemetry_cmd import telemetry_app

app.command()(login)
app.command()(init)
app.command()(watch)
app.command()(sync)
app.command()(reindex)
app.command()(status)
app.add_typer(projects_app, name="projects", help="Manage Nogic projects.")
app.add_typer(telemetry_app, name="telemetry", help="Manage telemetry settings.")


def entry():
    app()


if __name__ == "__main__":
    entry()
