"""
Data classes for extracted code elements.
"""

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from tree_sitter import Node


@dataclass
class ExtractedFunction:
    """Extracted function or method information."""

    name: str
    qualified_name: str
    start_line: int
    end_line: int
    signature: str
    docstring: str | None = None
    decorators: list[str] = field(default_factory=list)
    is_async: bool = False
    is_method: bool = False
    class_name: str | None = None
    parameters: list[str] = field(default_factory=list)
    return_type: str | None = None
    source_code: str = ""
    node: "Node | None" = field(default=None, repr=False)


@dataclass
class ExtractedClass:
    """Extracted class information."""

    name: str
    qualified_name: str
    start_line: int
    end_line: int
    docstring: str | None = None
    decorators: list[str] = field(default_factory=list)
    bases: list[str] = field(default_factory=list)
    methods: list[ExtractedFunction] = field(default_factory=list)
    source_code: str = ""
    node: "Node | None" = field(default=None, repr=False)


@dataclass
class ExtractedCall:
    """Extracted function call information."""

    name: str
    line: int
    caller_qualified_name: str
    receiver: str | None = None
    arguments: list[str] = field(default_factory=list)


@dataclass
class ExtractedImport:
    """Extracted import statement."""

    module: str
    name: str | None = None
    alias: str | None = None
    is_wildcard: bool = False
    line: int = 0


@dataclass
class ParseResult:
    """Container for all extracted elements from a file."""

    file_path: str
    language: str
    functions: list[ExtractedFunction] = field(default_factory=list)
    classes: list[ExtractedClass] = field(default_factory=list)
    imports: list[ExtractedImport] = field(default_factory=list)
    calls: list[ExtractedCall] = field(default_factory=list)
    error: str | None = None
