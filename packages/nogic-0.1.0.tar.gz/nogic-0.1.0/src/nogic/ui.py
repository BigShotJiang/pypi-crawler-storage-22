"""CLI output styling utilities."""

from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule

console = Console()
error_console = Console(stderr=True)


def banner(title: str, subtitle: str | None = None):
    """Display a styled command header."""
    console.print()
    console.print(Rule(f"[bold cyan]{title}[/]", style="dim"))
    if subtitle:
        dim(f"  {subtitle}")


def dev_banner(url: str):
    """Display dev mode warning."""
    console.print(Panel(
        f"[yellow bold]DEV MODE[/] Using {url}",
        border_style="yellow",
        padding=(0, 1),
    ))


def success(msg: str):
    console.print(f"[green bold]>[/] {msg}")


def info(msg: str):
    console.print(f"[blue]>[/] {msg}")


def warn(msg: str):
    console.print(f"[yellow bold]![/] {msg}")


def error(msg: str):
    error_console.print(f"[red bold]![/] {msg}")


def dim(msg: str):
    console.print(f"[dim]{msg}[/]")


def kv(key: str, value: str, indent: int = 2):
    """Print a key-value pair."""
    pad = " " * indent
    console.print(f"{pad}[dim]{key}:[/] {value}")


def section(title: str):
    console.print(f"\n[bold]{title}[/]")


def status_spinner(msg: str):
    """Return a Rich status context manager for spinners."""
    return console.status(f"[dim]{msg}[/]", spinner="dots")
