# noml-class
NoML is a text classifier that does not use machine learning (as stated in its name).

Fore more information, see https://dim0n122.github.io/noml-docs/