import json
import re

class noml:
    def __init__(self):
        # In-memory storage: { intent: [text1, text2, ...] }
        self._data = {}

    def _clean_text(self, text):
        """Remove punctuation and lowercase the text."""
        text = text.lower()
        text = re.sub(r"[^\w\s]", "", text)  # Remove punctuation
        return text.strip()

    def _get_bigrams(self, text):
        """Split text into 2-character chunks, ignoring spaces."""
        text = self._clean_text(text)
        text = text.replace(" ", "")  # Join all words into one string
        bigrams = set()
        for i in range(0, len(text) - 1, 2):  # Step by 2: pr, iv, et
            bigrams.add(text[i:i+2])
        return bigrams

    def _get_data(self):
        """An internal method that returns a dataset. Designed for debugging and error handling."""
        return self._data

    def train(self, json_path):
        """Load JSON dataset and loads it into memory."""
        self._data = {}  # Reset before training

        try:
            with open(json_path, encoding="utf-8") as f:
                self._data = json.load(f)
        except FileNotFoundError:
            print("Error training NoML: File not found")
            return
        except json.JSONDecodeError:
            print("Error training NoML: Invalid JSON file")
            return

        if self._data == {}:
            print("Error training NoML: Dataset is empty")
            return

    def predict(self, text) -> str | None:
        """Predict intent by counting bigram matches. Returns None if no match found."""
        input_bigrams = self._get_bigrams(text)

        if not input_bigrams:
            return None

        scores = {}

        for intent, examples in self._data.items():
            total_matches = 0
            for example in examples:
                # Count how many bigrams from input match this example
                matches = len(input_bigrams & self._get_bigrams(example))
                total_matches += matches
            scores[intent] = total_matches

        # Find the winner
        best_intent = max(scores, key=lambda k: scores[k])

        # If no matches at all — return None
        if scores[best_intent] == 0:
            return None

        return best_intent

