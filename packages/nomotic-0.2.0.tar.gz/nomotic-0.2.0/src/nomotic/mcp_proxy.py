"""MCP Governance Proxy — governs MCP tool calls through Nomotic.

Sits between an MCP client (the agent) and an MCP server (tools).
Intercepts tool-call requests, evaluates governance, and forwards
approved calls. Denied calls return a governance denial response.

This is an *adapter* — thin, replaceable, and clearly separated from
core governance logic. MCP wire-format translation happens here;
all governance decisions are delegated to GovernedToolExecutor.

Architecture:
    Agent -> MCP Client -> [Nomotic Proxy] -> MCP Server -> Tools

The proxy appears as an MCP server to the client and as an MCP client
to the actual server. It's transparent — the agent doesn't know
governance is happening.

Usage:
    # Start the proxy (stdio mode)
    nomotic mcp-proxy \\
        --agent-id claims-bot \\
        --upstream "python my_mcp_server.py"

    # Start the proxy (HTTP mode)
    nomotic mcp-proxy \\
        --agent-id claims-bot \\
        --upstream-url http://localhost:3000 \\
        --port 8421

    # Programmatically:
    from nomotic.mcp_proxy import MCPGovernanceProxy

    proxy = MCPGovernanceProxy(
        agent_id="claims-bot",
        upstream_command="python my_mcp_server.py",
    )
    proxy.run()
"""

from __future__ import annotations

import json
import subprocess
import sys
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any
from urllib.request import Request, urlopen
from urllib.error import URLError

from nomotic.executor import GovernedToolExecutor

__all__ = [
    "MCPGovernanceProxy",
    "MCPHTTPGovernanceProxy",
]


# ── Stdio Proxy ──────────────────────────────────────────────────────────


class MCPGovernanceProxy:
    """Governance proxy for MCP tool calls (stdio transport).

    Intercepts JSON-RPC messages between client and server,
    applying governance evaluation on tools/call requests.
    All governance decisions are delegated to GovernedToolExecutor.
    """

    def __init__(
        self,
        agent_id: str,
        upstream_command: str | list[str],
        *,
        base_dir: Path | None = None,
        test_mode: bool = False,
        log_level: str = "info",
    ):
        """
        Args:
            agent_id: Nomotic agent identity for governance.
            upstream_command: Command to start the upstream MCP server (stdio mode).
            base_dir: Nomotic config directory.
            test_mode: Use testlog and simulated trust.
            log_level: Logging verbosity ("debug", "info", "quiet").
        """
        self._agent_id = agent_id
        self._upstream_cmd = (
            upstream_command
            if isinstance(upstream_command, list)
            else upstream_command.split()
        )

        kw: dict[str, Any] = {"test_mode": test_mode}
        if base_dir:
            kw["base_dir"] = base_dir
        self._executor = GovernedToolExecutor.connect(agent_id, **kw)

        self._upstream_proc: subprocess.Popen | None = None
        self._log_level = log_level

    # ── Public API ────────────────────────────────────────────────────

    def run(self) -> None:
        """Run the proxy — reads from stdin, writes to stdout.

        The proxy itself acts as an MCP server (stdio transport).
        It launches the upstream MCP server as a subprocess and
        proxies messages between the client and server, intercepting
        tool calls for governance.
        """
        self._upstream_proc = subprocess.Popen(
            self._upstream_cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        upstream_reader = threading.Thread(
            target=self._read_upstream, daemon=True
        )
        upstream_reader.start()

        try:
            self._read_client()
        except KeyboardInterrupt:
            pass
        finally:
            if self._upstream_proc:
                self._upstream_proc.terminate()

    # ── Message routing ───────────────────────────────────────────────

    def _read_client(self) -> None:
        """Read JSON-RPC messages from the client (stdin)."""
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue

            try:
                message = json.loads(line)
            except json.JSONDecodeError:
                # Pass through non-JSON (headers, etc.)
                self._send_to_upstream(line)
                continue

            if self._is_tool_call(message):
                self._handle_tool_call(message)
            else:
                self._send_to_upstream(json.dumps(message))

    def _read_upstream(self) -> None:
        """Read responses from the upstream MCP server and forward to client."""
        if self._upstream_proc is None or self._upstream_proc.stdout is None:
            return
        for line in self._upstream_proc.stdout:
            decoded = line.decode("utf-8").strip()
            if decoded:
                self._send_to_client(decoded)

    # ── Governance interception ───────────────────────────────────────

    @staticmethod
    def _is_tool_call(message: dict) -> bool:
        """Check if a JSON-RPC message is an MCP tools/call request."""
        return message.get("method") == "tools/call" and "params" in message

    def _handle_tool_call(self, message: dict) -> None:
        """Evaluate governance on a tool call and decide whether to forward."""
        params = message.get("params", {})
        tool_name = params.get("name", "")
        tool_args = params.get("arguments", {})
        request_id = message.get("id")

        target = _extract_target(tool_name, tool_args)

        result = self._executor.check(
            action=tool_name,
            target=target,
            params=tool_args,
        )

        if self._log_level in ("info", "debug"):
            verdict_str = "ALLOW" if result.allowed else "DENY"
            sys.stderr.write(
                f"[nomotic] {tool_name} -> {target}: {verdict_str} "
                f"(trust: {result.trust_after:.3f})\n"
            )

        if result.allowed:
            forwarded = _attach_governance_token(message, result)
            self._send_to_upstream(json.dumps(forwarded))
        else:
            denial = _build_denial_response(request_id, tool_name, target, result.reason)
            self._send_to_client(json.dumps(denial))

    # ── Wire I/O ──────────────────────────────────────────────────────

    def _send_to_upstream(self, message: str) -> None:
        """Send a message to the upstream MCP server."""
        if self._upstream_proc and self._upstream_proc.stdin:
            self._upstream_proc.stdin.write((message + "\n").encode("utf-8"))
            self._upstream_proc.stdin.flush()

    def _send_to_client(self, message: str) -> None:
        """Send a message to the client (stdout)."""
        sys.stdout.write(message + "\n")
        sys.stdout.flush()


# ── HTTP/SSE Proxy ────────────────────────────────────────────────────────


class MCPHTTPGovernanceProxy:
    """HTTP-based MCP governance proxy.

    Runs as an HTTP server that proxies MCP JSON-RPC requests to an
    upstream MCP server over HTTP, applying governance on tool calls.

    Usage:
        nomotic mcp-proxy \\
            --agent-id claims-bot \\
            --upstream-url http://localhost:3000 \\
            --port 8421
    """

    def __init__(
        self,
        agent_id: str,
        upstream_url: str,
        *,
        port: int = 8421,
        host: str = "127.0.0.1",
        base_dir: Path | None = None,
        test_mode: bool = False,
        log_level: str = "info",
    ):
        """
        Args:
            agent_id: Nomotic agent identity for governance.
            upstream_url: URL of the upstream MCP server.
            port: Port for this proxy to listen on.
            host: Host to bind to.
            base_dir: Nomotic config directory.
            test_mode: Use testlog and simulated trust.
            log_level: Logging verbosity.
        """
        self._agent_id = agent_id
        self._upstream_url = upstream_url.rstrip("/")
        self._port = port
        self._host = host
        self._log_level = log_level

        kw: dict[str, Any] = {"test_mode": test_mode}
        if base_dir:
            kw["base_dir"] = base_dir
        self._executor = GovernedToolExecutor.connect(agent_id, **kw)

    def run(self) -> None:
        """Start the HTTP proxy server."""
        proxy = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self) -> None:
                content_len = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(content_len)

                try:
                    message = json.loads(body)
                except json.JSONDecodeError:
                    self._respond(400, {"error": "invalid JSON"})
                    return

                if MCPGovernanceProxy._is_tool_call(message):
                    response_body = proxy._handle_tool_call_http(message)
                    if response_body is not None:
                        # Governance denied — return denial directly
                        self._respond(200, response_body)
                        return

                    # Governance approved — forward with token
                    params = message.get("params", {})
                    tool_name = params.get("name", "")
                    tool_args = params.get("arguments", {})
                    target = _extract_target(tool_name, tool_args)

                    result = proxy._executor.check(
                        action=tool_name,
                        target=target,
                        params=tool_args,
                    )
                    forwarded = _attach_governance_token(message, result)
                    upstream_resp = proxy._forward_to_upstream(json.dumps(forwarded).encode())
                    self._respond(200, upstream_resp)
                else:
                    upstream_resp = proxy._forward_to_upstream(body)
                    self._respond(200, upstream_resp)

            def _respond(self, status: int, body: Any) -> None:
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                if isinstance(body, dict):
                    self.wfile.write(json.dumps(body).encode("utf-8"))
                elif isinstance(body, bytes):
                    self.wfile.write(body)
                else:
                    self.wfile.write(str(body).encode("utf-8"))

            def log_message(self, format: str, *log_args: Any) -> None:
                if proxy._log_level == "debug":
                    sys.stderr.write(
                        f"[nomotic-http] {self.address_string()} "
                        f"{format % log_args}\n"
                    )

        server = HTTPServer((self._host, self._port), Handler)

        sys.stderr.write(
            f"[nomotic] MCP HTTP proxy listening on {self._host}:{self._port}\n"
            f"[nomotic] Upstream: {self._upstream_url}\n"
            f"[nomotic] Agent: {self._agent_id}\n"
        )

        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            server.server_close()

    def _handle_tool_call_http(self, message: dict) -> dict | None:
        """Evaluate governance; return denial dict or None if allowed."""
        params = message.get("params", {})
        tool_name = params.get("name", "")
        tool_args = params.get("arguments", {})
        request_id = message.get("id")

        target = _extract_target(tool_name, tool_args)

        result = self._executor.check(
            action=tool_name,
            target=target,
            params=tool_args,
        )

        if self._log_level in ("info", "debug"):
            verdict_str = "ALLOW" if result.allowed else "DENY"
            sys.stderr.write(
                f"[nomotic] {tool_name} -> {target}: {verdict_str} "
                f"(trust: {result.trust_after:.3f})\n"
            )

        if result.allowed:
            return None

        return _build_denial_response(request_id, tool_name, target, result.reason)

    def _forward_to_upstream(self, body: bytes) -> Any:
        """Forward a request body to the upstream MCP server and return the response."""
        req = Request(
            self._upstream_url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urlopen(req, timeout=30) as resp:
                return json.loads(resp.read())
        except (URLError, json.JSONDecodeError) as exc:
            return {"jsonrpc": "2.0", "error": {"code": -32603, "message": str(exc)}}


# ── Shared helpers (no MCP domain leakage) ────────────────────────────────


def _extract_target(tool_name: str, tool_args: dict) -> str:
    """Extract a governance target from tool call arguments.

    Looks for common resource-identifying keys, then falls back to
    the first string argument value, then the tool name itself.
    """
    for key in ("target", "path", "file", "table", "url", "resource", "database", "uri"):
        if key in tool_args:
            return str(tool_args[key])
    for val in tool_args.values():
        if isinstance(val, str):
            return val
    return tool_name


def _build_denial_response(
    request_id: Any,
    tool_name: str,
    target: str,
    reason: str,
) -> dict:
    """Build a JSON-RPC 2.0 denial response for a governed tool call."""
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "result": {
            "content": [
                {
                    "type": "text",
                    "text": (
                        f"[GOVERNANCE DENIED] Action '{tool_name}' on '{target}' "
                        f"was denied by Nomotic governance. Reason: {reason}"
                    ),
                }
            ],
            "isError": True,
        },
    }


def _attach_governance_token(message: dict, result: Any) -> dict:
    """Attach Nomotic governance metadata to a forwarded tool call.

    Adds a ``_nomotic`` key inside ``params`` so downstream services
    can verify that governance occurred. Returns a shallow copy of
    the message — the original is not mutated.
    """
    forwarded = dict(message)
    forwarded["params"] = dict(forwarded.get("params", {}))
    forwarded["params"]["_nomotic"] = {
        "governance_token": result.action_id,
        "trust_score": result.trust_after,
        "verdict": result.verdict,
        "timestamp": time.time(),
    }
    return forwarded
