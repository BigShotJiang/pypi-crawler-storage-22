"""HTTP Governance Proxy -- intercepts and governs HTTP requests.

Sits between an agent and its target service. Every request is
evaluated through Nomotic governance before being forwarded.

Usage:
    nomotic proxy --agent-id claims-bot --listen 0.0.0.0:8421 --upstream https://api.target.com

The proxy intercepts:
    - The HTTP method -> governance action (GET=read, POST=write, DELETE=delete)
    - The URL path -> governance target
    - Request headers and body -> governance parameters
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any, ClassVar

from nomotic.executor import GovernedToolExecutor

__all__ = [
    "GovernanceProxyHandler",
    "METHOD_ACTION_MAP",
    "start_proxy",
]


# Map HTTP methods to governance actions
METHOD_ACTION_MAP: dict[str, str] = {
    "GET": "read",
    "POST": "write",
    "PUT": "write",
    "PATCH": "write",
    "DELETE": "delete",
    "HEAD": "read",
    "OPTIONS": "read",
}


class GovernanceProxyHandler(BaseHTTPRequestHandler):
    """HTTP request handler that applies governance before proxying."""

    executor: ClassVar[GovernedToolExecutor | None] = None
    upstream_url: ClassVar[str] = ""

    def do_GET(self) -> None:
        self._handle()

    def do_POST(self) -> None:
        self._handle()

    def do_PUT(self) -> None:
        self._handle()

    def do_PATCH(self) -> None:
        self._handle()

    def do_DELETE(self) -> None:
        self._handle()

    def _handle(self) -> None:
        assert self.executor is not None, "executor must be set before handling requests"

        method = self.command
        path = self.path
        action = METHOD_ACTION_MAP.get(method, "read")
        target = path.strip("/").split("/")[0] if path.strip("/") else "root"

        # Read request body
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length) if content_length else b""

        # Evaluate governance
        result = self.executor.check(
            action=action,
            target=target,
            params={"method": method, "path": path, "body_size": len(body)},
        )

        if not result.allowed:
            # Return 403 with governance denial
            response = json.dumps({
                "error": "governance_denied",
                "reason": result.reason,
                "verdict": result.verdict,
                "trust": result.trust_after,
                "action": action,
                "target": target,
            }).encode("utf-8")

            self.send_response(403)
            self.send_header("Content-Type", "application/json")
            self.send_header("X-Nomotic-Verdict", "DENY")
            self.send_header("X-Nomotic-Reason", result.reason[:200])
            self.send_header("Content-Length", str(len(response)))
            self.end_headers()
            self.wfile.write(response)
            return

        # Forward to upstream
        upstream = f"{self.upstream_url}{path}"
        req = urllib.request.Request(
            upstream, data=body if body else None, method=method
        )

        # Copy relevant headers
        for header, value in self.headers.items():
            if header.lower() not in ("host", "content-length"):
                req.add_header(header, value)

        # Add governance headers
        req.add_header("X-Nomotic-Verdict", "ALLOW")
        req.add_header("X-Nomotic-Trust", str(result.trust_after))
        req.add_header("X-Nomotic-Agent", self.executor.agent_id)

        try:
            with urllib.request.urlopen(req) as resp:
                resp_body = resp.read()
                self.send_response(resp.status)
                for header, value in resp.headers.items():
                    if header.lower() != "transfer-encoding":
                        self.send_header(header, value)
                self.end_headers()
                self.wfile.write(resp_body)
        except urllib.error.HTTPError as e:
            resp_body = e.read()
            self.send_response(e.code)
            for header, value in e.headers.items():
                if header.lower() != "transfer-encoding":
                    self.send_header(header, value)
            self.end_headers()
            self.wfile.write(resp_body)

    def log_message(self, format: str, *args: Any) -> None:
        """Suppress default logging -- we log through governance."""
        pass


def start_proxy(
    agent_id: str,
    listen: str,
    upstream: str,
    *,
    test_mode: bool = False,
    base_dir: str | None = None,
) -> None:
    """Start the governance proxy server.

    Args:
        agent_id: Nomotic agent identity (must have an existing certificate).
        listen: Address to bind to, e.g. ``"0.0.0.0:8421"``.
        upstream: Upstream service URL, e.g. ``"https://api.target.com"``.
        test_mode: If True, use testlog and simulated trust.
        base_dir: Nomotic data directory (default: ~/.nomotic).
    """
    host, port_str = listen.rsplit(":", 1)
    port = int(port_str)

    from pathlib import Path

    kwargs: dict[str, Any] = {"test_mode": test_mode}
    if base_dir is not None:
        kwargs["base_dir"] = Path(base_dir)

    executor = GovernedToolExecutor.connect(agent_id, **kwargs)

    GovernanceProxyHandler.executor = executor
    GovernanceProxyHandler.upstream_url = upstream.rstrip("/")

    server = HTTPServer((host, port), GovernanceProxyHandler)
    print(f"Nomotic governance proxy running on {listen}")
    print(f"Upstream: {upstream}")
    print(f"Agent: {agent_id} (trust: {executor.trust:.3f})")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down proxy...")
        server.shutdown()
