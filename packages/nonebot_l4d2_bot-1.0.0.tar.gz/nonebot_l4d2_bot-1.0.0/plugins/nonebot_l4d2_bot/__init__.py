from nonebot import get_driver, get_plugin_config
from nonebot.plugin import PluginMetadata

from .config import BridgeConfig
from .ws_server import setup_ws_server
from .http_server import setup_http_server
from .forwarder import setup_forwarder
from .commands import setup_commands

__plugin_meta__ = PluginMetadata(
    name="L4D2 Bridge",
    description="NoneBot2 与 Left 4 Dead 2 SourceMod 双向消息/文件桥接",
    usage="自动运行，无需手动命令",
    config=BridgeConfig,
)

driver = get_driver()
config = get_plugin_config(BridgeConfig)


@driver.on_startup
async def _startup():
    setup_ws_server(config)
    setup_http_server(config)
    setup_forwarder(config)
    setup_commands(config)
