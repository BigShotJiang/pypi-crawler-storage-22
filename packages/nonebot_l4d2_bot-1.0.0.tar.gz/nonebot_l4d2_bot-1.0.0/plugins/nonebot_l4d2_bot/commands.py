import base64

from nonebot import on_startswith, Bot
from nonebot.adapters.onebot.v11 import GroupMessageEvent, MessageSegment
from nonebot.rule import Rule

from .config import BridgeConfig
from .connection import conn_mgr
from .server_query import query_server_auto, parse_server_addr
from .render import render_server_info, render_server_offline, render_bridge_status

_config: BridgeConfig = None


def _is_bridge_group() -> Rule:
    async def checker(event: GroupMessageEvent) -> bool:
        return str(event.group_id) in _config.l4d2_bridge_qq_groups
    return Rule(checker)


def setup_commands(config: BridgeConfig):
    global _config
    _config = config

    grp = _is_bridge_group()

    on_startswith("状态", rule=grp, priority=10).handle()(
        _handle_status_cmd)

    on_startswith("connect", rule=grp, priority=10).handle()(
        _handle_query_cmd)


async def _handle_status_cmd(bot: Bot, event: GroupMessageEvent):
    conns = conn_mgr.all_connections
    if not conns:
        await bot.send(event, "当前无服务器连接")
        return

    data = [
        (sid, int(conn.alive_seconds / 60))
        for sid, conn in conns.items()
    ]
    img = render_bridge_status(data)
    b64 = base64.b64encode(img).decode()
    await bot.send(event, MessageSegment.image(f"base64://{b64}"))


async def _handle_query_cmd(bot: Bot, event: GroupMessageEvent):
    raw = str(event.get_message()).strip()
    if raw.startswith("connect"):
        raw = raw[7:].strip()

    if not raw:
        return

    _, host, port = parse_server_addr(raw)
    info = await query_server_auto(host, port)

    if info is None:
        display_port = port if port > 0 else 27015
        img = render_server_offline(host, display_port)
    else:
        img = render_server_info(
            info.server_name, info.map_display,
            info.real_players, info.max_players,
        )

    b64 = base64.b64encode(img).decode()
    await bot.send(event, MessageSegment.image(f"base64://{b64}"))
