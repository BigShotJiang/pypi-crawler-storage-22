from pathlib import Path
from typing import List

from pydantic import BaseModel, Field


class BridgeConfig(BaseModel):
    l4d2_bridge_token: str = "change_me_to_a_secure_token"
    l4d2_bridge_ws_path: str = "/ws/l4d2"
    l4d2_bridge_file_path: str = "/v1/files"
    l4d2_bridge_heartbeat_interval: int = 15
    l4d2_bridge_upload_max_mb: int = 20
    l4d2_bridge_download_dir: str = "data/l4d2_bridge/inbox"
    l4d2_bridge_upload_dir: str = "data/l4d2_bridge/outbox"
    l4d2_bridge_allowed_extensions: List[str] = Field(
        default_factory=lambda: ["vpk"]
    )
    l4d2_bridge_game_servers: List[str] = Field(
        default_factory=list
    )
    l4d2_bridge_qq_groups: List[str] = Field(default_factory=lambda: [])
    l4d2_bridge_hmac_window_sec: int = 30
    l4d2_bridge_msg_dedup_window_sec: int = 600
    l4d2_bridge_reconnect_max_retries: int = -1

    @property
    def download_path(self) -> Path:
        p = Path(self.l4d2_bridge_download_dir)
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def upload_path(self) -> Path:
        p = Path(self.l4d2_bridge_upload_dir)
        p.mkdir(parents=True, exist_ok=True)
        return p
