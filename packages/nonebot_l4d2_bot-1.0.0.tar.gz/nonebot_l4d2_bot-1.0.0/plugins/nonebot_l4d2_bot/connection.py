import asyncio
import time
from typing import Dict, Optional

from nonebot.log import logger

from .log import _clog, _TAG
from .protocol import BridgePacket


class GameServerConn:

    def __init__(self, server_id: str, ws):
        self.server_id = server_id
        self.ws = ws
        self.connected_at: float = time.time()
        self.last_ping: float = time.time()
        self.authenticated: bool = False
        self._send_lock = asyncio.Lock()

    async def send_packet(self, pkt: BridgePacket):
        async with self._send_lock:
            try:
                await self.ws.send_text(pkt.model_dump_json())
            except Exception as e:
                _clog.error(f"{_TAG} 发送数据包到 {self.server_id} 失败: {e}")
                raise

    @property
    def alive_seconds(self) -> float:
        return time.time() - self.connected_at


class ConnectionManager:

    def __init__(self):
        self._conns: Dict[str, GameServerConn] = {}

    def add(self, server_id: str, ws) -> GameServerConn:
        if server_id in self._conns:
            _clog.warning(f"{_TAG} 覆盖已有连接: {server_id}")
        conn = GameServerConn(server_id, ws)
        self._conns[server_id] = conn
        _clog.info(f"{_TAG} 服务器已连接: {server_id}")
        return conn

    def remove(self, server_id: str):
        if server_id in self._conns:
            del self._conns[server_id]
            _clog.info(f"{_TAG} 服务器已断开: {server_id}")

    def get(self, server_id: str) -> Optional[GameServerConn]:
        return self._conns.get(server_id)

    @property
    def all_connections(self) -> Dict[str, GameServerConn]:
        return dict(self._conns)

    @property
    def count(self) -> int:
        return len(self._conns)

    async def broadcast(self, pkt: BridgePacket, exclude: str = ""):
        for sid, conn in list(self._conns.items()):
            if sid == exclude or not conn.authenticated:
                continue
            try:
                await conn.send_packet(pkt)
            except Exception as e:
                _clog.error(f"{_TAG} 广播到 {sid} 失败: {e}")
                self.remove(sid)


conn_mgr = ConnectionManager()
