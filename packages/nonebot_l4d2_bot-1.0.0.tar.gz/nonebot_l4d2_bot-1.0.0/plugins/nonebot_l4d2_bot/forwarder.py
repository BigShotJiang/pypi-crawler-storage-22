import re
import time
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse, unquote
from typing import Optional, Tuple

import httpx
import nonebot
from nonebot import on_message, Bot
from nonebot.adapters.onebot.v11 import (
    GroupMessageEvent,
    Message,
)
from nonebot.rule import Rule

from .config import BridgeConfig
from .log import _clog, _TAG
from .connection import conn_mgr
from .protocol import make_file_in_notice
from .ws_server import on_file_out
from .http_server import save_file_for_game, get_file_meta

_URL_RE = re.compile(r'https?://[^\s"<>\]\)}{,]+', re.IGNORECASE)

_FLASH_RE = re.compile(
    r'(?:'
    r'\[flashtransfer:fileSetId=([a-f0-9\-]+)\]'
    r'|'
    r'\[CQ:flashtransfer,fileSetId=([a-f0-9\-]+)\]'
    r')',
    re.IGNORECASE,
)

_CD_NAME_RE = re.compile(r'filename[*]?=["\']?([^"\'\;]+)')

_DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
}

_QQ_HEADERS = {
    **_DEFAULT_HEADERS,
    "User-Agent": _DEFAULT_HEADERS["User-Agent"] + " QQ/9.9.15",
    "Referer": "https://qq.com",
}

_config: BridgeConfig = None


def _is_bridge_group() -> Rule:
    async def checker(event: GroupMessageEvent) -> bool:
        return str(event.group_id) in _config.l4d2_bridge_qq_groups
    return Rule(checker)


def _starts_with_download() -> Rule:
    async def checker(event: GroupMessageEvent) -> bool:
        text = event.get_plaintext().strip()
        if not text.startswith("下载"):
            return False
        return bool(_URL_RE.search(text))
    return Rule(checker)


def setup_forwarder(config: BridgeConfig):
    global _config
    _config = config

    _register_game_to_bot_handlers()

    grp = _is_bridge_group()

    on_message(rule=grp, priority=85, block=False).handle()(
        _handle_flash_message)

    on_message(rule=grp, priority=90, block=False).handle()(
        _handle_card_message)

    on_message(rule=grp & _starts_with_download(), priority=10).handle()(
        _handle_download_cmd)


def _filename_from_url(url: str, fallback: str = "download") -> str:
    try:
        parsed = urlparse(url)
        path = unquote(parsed.path)
        name = PurePosixPath(path).name
        if name:
            return name
    except Exception:
        pass
    return fallback


def _cd_filename(headers: httpx.Headers) -> Optional[str]:
    cd = headers.get("content-disposition", "")
    if cd:
        m = _CD_NAME_RE.search(cd)
        if m:
            return unquote(m.group(1).strip()) or None
    return None


def _is_vpk_url(url: str) -> bool:
    try:
        return unquote(urlparse(url).path).lower().endswith(".vpk")
    except Exception:
        return False


def _sender_name(event: GroupMessageEvent) -> str:
    return (
        event.sender.card or event.sender.nickname
        or str(event.user_id)
    )


async def _stream_download(
        url: str,
        headers: Optional[dict] = None,
        verify: bool = True,
) -> Tuple[bytes, float]:
    hdrs = headers or _DEFAULT_HEADERS
    t0 = time.monotonic()
    async with httpx.AsyncClient(
        timeout=120, follow_redirects=True, verify=verify,
    ) as client:
        async with client.stream("GET", url, headers=hdrs) as resp:
            resp.raise_for_status()
            cd_name = _cd_filename(resp.headers)
            chunks = []
            async for chunk in resp.aiter_bytes(65536):
                chunks.append(chunk)
    content = b"".join(chunks)
    dl_sec = time.monotonic() - t0
    return content, dl_sec, cd_name


async def _save_and_push(
        bot: Bot, event: GroupMessageEvent,
        content: bytes, file_name: str,
        channel: str, sender: str, dl_sec: float,
        label: str):
    meta = await save_file_for_game(content, file_name)
    if not meta:
        size_mb = len(content) / (1024 * 1024)
        max_mb = _config.l4d2_bridge_upload_max_mb
        if size_mb > max_mb:
            await bot.send(event,
                f"{label} 超出大小限制: {size_mb:.1f}MB > {max_mb}MB")
        else:
            await bot.send(event, f"{label} 保存失败: {file_name}")
        return

    pkt = make_file_in_notice(
        channel=channel,
        file_id=meta["file_id"],
        file_name=meta["file_name"],
        size=meta["size"],
        sha256=meta["sha256"],
        secret=_config.l4d2_bridge_token,
    )
    await conn_mgr.broadcast(pkt)

    size_mb = meta["size"] / (1024 * 1024)
    speed = size_mb / dl_sec if dl_sec > 0 else 0
    await bot.send(event,
        f"下载进度: 100%\n"
        f"{label} 已推送至 {conn_mgr.count} 台服务器\n"
        f"文件: {meta['file_name']}\n"
        f"大小: {size_mb:.2f} MB | 速率: {speed:.2f} MB/s")
    _clog.info(
        f"{_TAG} {label}→Game: {file_name} "
        f"({meta['size']} bytes) from {sender}")


async def _handle_card_message(bot: Bot, event: GroupMessageEvent):
    urls = set()
    for seg in event.message:
        if seg.type in ("json", "xml"):
            urls.update(_URL_RE.findall(seg.data.get("data", "")))
        elif seg.type == "share":
            url = seg.data.get("url", "")
            if url:
                urls.add(url)

    vpk_urls = [u for u in urls if _is_vpk_url(u)]
    if not vpk_urls:
        return

    sender = _sender_name(event)
    channel = f"qq_group:{event.group_id}"

    for url in vpk_urls:
        file_name = _filename_from_url(url, "download.vpk")
        _clog.info(f"{_TAG} VPK下载开始: {file_name} from {sender}")
        await bot.send(event, f"检测到 VPK 链接，开始下载: {file_name}")

        try:
            content, dl_sec, cd_name = await _stream_download(url)
            if cd_name and cd_name.lower().endswith(".vpk"):
                file_name = cd_name
        except Exception as e:
            _clog.error(f"{_TAG} 下载 VPK 失败: {e}")
            await bot.send(event, f"VPK 下载失败: {e}")
            continue

        await _save_and_push(
            bot, event, content, file_name,
            channel, sender, dl_sec, "VPK 文件")


async def _handle_flash_message(bot: Bot, event: GroupMessageEvent):
    fileset_id = ""
    for seg in event.message:
        if seg.type == "flashtransfer":
            fileset_id = seg.data.get("fileSetId", "")
            break
    if not fileset_id:
        raw = str(event.get_message())
        m = _FLASH_RE.search(raw)
        if not m:
            return
        fileset_id = m.group(1) or m.group(2)

    sender = _sender_name(event)
    channel = f"qq_group:{event.group_id}"
    _clog.info(f"{_TAG} 检测到闪传: fileSetId={fileset_id}")

    try:
        resp = await bot.call_api(
            "get_flash_file_list", fileset_id=fileset_id)
    except Exception as e:
        _clog.warning(f"{_TAG} 获取闪传文件列表失败: {e}")
        return

    files = []
    if isinstance(resp, dict):
        for fl in resp.get("fileLists", []):
            for item in fl.get("fileList", []):
                name = item.get("name", "")
                size = int(item.get("fileSize", 0))
                if name:
                    files.append({"file_name": name, "size": size})
    elif isinstance(resp, list):
        files = [
            {"file_name": f.get("file_name", ""),
                "size": f.get("size", 0)} for f in resp
        ]

    vpk_files = [
        f for f in files
        if f["file_name"].lower().endswith(".vpk")
    ]
    if not vpk_files:
        if files:
            names = [f["file_name"] for f in files]
            _clog.info(f"{_TAG} 闪传无VPK文件: {names}")
        return

    for f in vpk_files:
        file_name = f.get("file_name", "download.vpk")
        await bot.send(event, f"检测到 VPK 文件，开始下载: {file_name}")

        try:
            url_resp = await bot.call_api(
                "get_flash_file_url",
                fileset_id=fileset_id,
                file_name=file_name)
        except Exception as e:
            _clog.error(f"{_TAG} 获取闪传文件URL失败: {e}")
            await bot.send(event, f"闪传文件URL获取失败: {e}")
            continue

        file_url = ""
        if isinstance(url_resp, str):
            file_url = url_resp
        elif isinstance(url_resp, dict):
            file_url = (
                url_resp.get("transferUrl", "")
                or url_resp.get("url", ""))
        if not file_url:
            _clog.warning(
                f"{_TAG} 闪传文件URL为空: {file_name}, resp={url_resp}")
            continue

        try:
            content, dl_sec, _ = await _stream_download(
                file_url, headers=_QQ_HEADERS, verify=False)
        except Exception as e:
            _clog.error(
                f"{_TAG} 下载闪传VPK失败: {type(e).__name__}: {e}")
            await bot.send(
                event, f"VPK 下载失败: {type(e).__name__}: {e}")
            continue

        await _save_and_push(
            bot, event, content, file_name,
            channel, sender, dl_sec, "VPK 文件")


async def _handle_download_cmd(bot: Bot, event: GroupMessageEvent):
    raw = event.get_plaintext().strip().lstrip("下载").strip()

    urls = _URL_RE.findall(raw)
    if not urls:
        await bot.send(
            event, "请提供下载链接，例如：下载 https://example.com/file.vpk")
        return

    sender = _sender_name(event)
    channel = f"qq_group:{event.group_id}"

    for url in urls:
        file_name = _filename_from_url(url)
        _clog.info(f"{_TAG} 直链下载: {file_name} from {sender}")
        await bot.send(event, f"开始解析直链: {file_name}")

        try:
            content, dl_sec, cd_name = await _stream_download(url)
            if cd_name:
                file_name = cd_name
        except Exception as e:
            _clog.error(f"{_TAG} 直链下载失败: {e}")
            await bot.send(event, f"下载失败：{e}")
            continue

        await _save_and_push(
            bot, event, content, file_name,
            channel, sender, dl_sec, "文件")


def _register_game_to_bot_handlers():

    @on_file_out
    async def _game_file_to_qq(
            server_id: str, channel: str, file_id: str,
            file_name: str, size: int, sha256: str):
        meta = get_file_meta(file_id)
        if meta and Path(meta["path"]).exists():
            await _send_file_to_qq_groups(
                str(Path(meta["path"]).resolve()), file_name)
            size_kb = size / 1024
            await _send_to_qq_groups(
                f"[{server_id}] 上传文件: {file_name}\n"
                f"大小: {size_kb:.1f} KB")
        else:
            _clog.warning(f"{_TAG} 文件未找到: {file_id}")
            await _send_to_qq_groups(
                f"[{server_id}] 上传文件: {file_name} (文件不可用)")


async def _send_to_qq_groups(text: str):
    try:
        bot = nonebot.get_bot()
    except ValueError:
        _clog.warning(f"{_TAG} 没有可用的 Bot 实例")
        return

    for gid in _config.l4d2_bridge_qq_groups:
        try:
            await bot.send_group_msg(
                group_id=int(gid), message=Message(text))
        except Exception as e:
            _clog.error(f"{_TAG} 发送到群 {gid} 失败: {e}")


async def _send_file_to_qq_groups(file_path: str, file_name: str):
    try:
        bot = nonebot.get_bot()
    except ValueError:
        _clog.warning(f"{_TAG} 没有可用的 Bot 实例")
        return

    for gid in _config.l4d2_bridge_qq_groups:
        try:
            await bot.call_api(
                "upload_group_file",
                group_id=int(gid),
                file=file_path,
                name=file_name,
            )
        except Exception as e:
            _clog.error(f"{_TAG} 发送文件到群 {gid} 失败: {e}")
