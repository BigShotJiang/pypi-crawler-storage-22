import asyncio
import hashlib
import hmac
import json
import re
import time
import uuid
from pathlib import Path
from typing import Dict

import aiofiles
from nonebot import get_driver
from nonebot.drivers import ASGIMixin, HTTPServerSetup, Request
from nonebot.drivers import Response
from nonebot.log import logger
from starlette.requests import URL

from .config import BridgeConfig
from .log import _clog, _TAG

_config: BridgeConfig = None

_FILE_ID_RE = re.compile(r'^[0-9a-f]{1,32}$')
_MAX_REGISTRY_SIZE = 500
_REGISTRY_TTL = 3600

_file_registry: Dict[str, dict] = {}


def get_file_meta(file_id: str) -> dict | None:
    return _file_registry.get(file_id)


def register_file(file_id: str, meta: dict):
    meta['_registered_at'] = time.time()
    _file_registry[file_id] = meta
    _cleanup_registry()


def _cleanup_registry():
    if len(_file_registry) <= _MAX_REGISTRY_SIZE:
        return
    now = time.time()
    expired = [
        k for k, v in _file_registry.items()
        if now - v.get('_registered_at', 0) > _REGISTRY_TTL
    ]
    for k in expired:
        del _file_registry[k]
    if len(_file_registry) > _MAX_REGISTRY_SIZE:
        oldest = sorted(_file_registry, key=lambda k: _file_registry[k].get('_registered_at', 0))
        for k in oldest[:len(_file_registry) - _MAX_REGISTRY_SIZE]:
            del _file_registry[k]


def setup_http_server(config: BridgeConfig):
    global _config
    _config = config

    driver = get_driver()
    if not isinstance(driver, ASGIMixin):
        _clog.error(f"{_TAG} 当前驱动不支持 ASGI，无法挂载 HTTP 端点")
        return

    upload_setup = HTTPServerSetup(
        path=URL(f"{config.l4d2_bridge_file_path}/upload"),
        method="POST",
        name="l4d2_bridge_upload",
        handle_func=_handle_upload,
    )
    driver.setup_http_server(upload_setup)

    download_setup = HTTPServerSetup(
        path=URL(f"{config.l4d2_bridge_file_path}/download"),
        method="GET",
        name="l4d2_bridge_download",
        handle_func=_handle_download,
    )
    driver.setup_http_server(download_setup)

    list_setup = HTTPServerSetup(
        path=URL(f"{config.l4d2_bridge_file_path}/list"),
        method="GET",
        name="l4d2_bridge_file_list",
        handle_func=_handle_list,
    )
    driver.setup_http_server(list_setup)

    _clog.info(f"{_TAG} HTTP 文件端点已挂载: {config.l4d2_bridge_file_path}")


def _check_auth(request: Request) -> bool:
    auth = request.headers.get("authorization", "")
    if auth.startswith("Bearer "):
        return hmac.compare_digest(auth[7:], _config.l4d2_bridge_token)
    return False


def _check_extension(filename: str) -> bool:
    ext = Path(filename).suffix.lstrip(".").lower()
    return ext in _config.l4d2_bridge_allowed_extensions


def _safe_filename(filename: str) -> str:
    name = Path(filename).name
    name = re.sub(r'[\x00-\x1f/\\:*?"<>|]', '_', name)
    while '..' in name:
        name = name.replace('..', '')
    name = name.strip('. ')
    if not name:
        name = "unnamed"
    return name


async def _handle_upload(request: Request) -> Response:
    if not _check_auth(request):
        return Response(401, content=json.dumps({"error": "unauthorized"}))

    if not request.files:
        return Response(400, content=json.dumps({"error": "no file in request"}))

    file_field = list(request.files)[0]
    file_tuple = request.files[file_field] if isinstance(request.files, dict) else request.files[0]

    if isinstance(file_tuple, tuple) and len(file_tuple) >= 2:
        file_info = file_tuple[1] if isinstance(file_tuple[1], tuple) else file_tuple
        filename = file_info[0] if len(file_info) > 0 else "unnamed"
        file_data = file_info[1] if len(file_info) > 1 else b""
    else:
        return Response(400, content=json.dumps({"error": "invalid file format"}))

    if hasattr(file_data, "read"):
        content = file_data.read()
        if asyncio.iscoroutine(content):
            content = await content
    elif isinstance(file_data, bytes):
        content = file_data
    else:
        content = bytes(file_data)

    filename = _safe_filename(filename)

    if not _check_extension(filename):
        return Response(403, content=json.dumps({
            "error": f"extension not allowed: {Path(filename).suffix}",
            "allowed": _config.l4d2_bridge_allowed_extensions,
        }))

    max_bytes = _config.l4d2_bridge_upload_max_mb * 1024 * 1024
    if len(content) > max_bytes:
        return Response(413, content=json.dumps({
            "error": f"file too large: {len(content)} > {max_bytes}",
        }))

    sha256 = hashlib.sha256(content).hexdigest()

    file_id = uuid.uuid4().hex[:16]
    save_dir = _config.upload_path
    save_path = save_dir / f"{file_id}_{filename}"

    async with aiofiles.open(save_path, "wb") as f:
        await f.write(content)

    meta = {
        "file_id": file_id,
        "file_name": filename,
        "size": len(content),
        "sha256": sha256,
        "path": str(save_path),
    }
    register_file(file_id, meta)

    _clog.info(f"{_TAG} 文件已上传: {filename} ({len(content)} bytes, id={file_id})")

    return Response(200, content=json.dumps(meta))


async def _handle_download(request: Request) -> Response:
    if not _check_auth(request):
        return Response(401, content=json.dumps({"error": "unauthorized"}))

    url_str = str(request.url)
    file_id = ""
    if "file_id=" in url_str:
        file_id = url_str.split("file_id=")[1].split("&")[0]

    if not file_id:
        return Response(400, content=json.dumps({"error": "missing file_id parameter"}))

    if not _FILE_ID_RE.match(file_id):
        return Response(400, content=json.dumps({"error": "invalid file_id format"}))

    meta = get_file_meta(file_id)
    if not meta:
        return Response(404, content=json.dumps({"error": "file not found"}))

    file_path = Path(meta["path"]).resolve()
    allowed_dirs = (_config.upload_path.resolve(), _config.download_path.resolve())
    if not any(str(file_path).startswith(str(d)) for d in allowed_dirs):
        return Response(403, content=json.dumps({"error": "access denied"}))
    if not file_path.exists():
        return Response(404, content=json.dumps({"error": "file missing on disk"}))

    async with aiofiles.open(file_path, "rb") as f:
        content = await f.read()

    safe_dl_name = _safe_filename(meta["file_name"])
    headers = {
        "Content-Disposition": f'attachment; filename="{safe_dl_name}"',
        "Content-Type": "application/octet-stream",
        "X-File-SHA256": meta["sha256"],
    }
    return Response(200, headers=headers, content=content)


async def _handle_list(request: Request) -> Response:
    if not _check_auth(request):
        return Response(401, content=json.dumps({"error": "unauthorized"}))

    file_list = []
    for fid, meta in _file_registry.items():
        file_list.append({
            "file_id": fid,
            "file_name": meta.get("file_name", ""),
            "size": meta.get("size", 0),
            "sha256": meta.get("sha256", ""),
        })

    return Response(200, content=json.dumps({"files": file_list}))


async def save_file_for_game(content: bytes, filename: str) -> dict | None:
    filename = _safe_filename(filename)
    if not _check_extension(filename):
        return None

    max_bytes = _config.l4d2_bridge_upload_max_mb * 1024 * 1024
    if len(content) > max_bytes:
        return None

    sha256 = hashlib.sha256(content).hexdigest()
    file_id = uuid.uuid4().hex[:16]
    save_dir = _config.download_path
    save_path = save_dir / f"{file_id}_{filename}"

    async with aiofiles.open(save_path, "wb") as f:
        await f.write(content)

    meta = {
        "file_id": file_id,
        "file_name": filename,
        "size": len(content),
        "sha256": sha256,
        "path": str(save_path),
    }
    register_file(file_id, meta)
    _clog.info(f"{_TAG} 文件已就绪: {filename} ({len(content)} bytes, id={file_id})")
    return meta
