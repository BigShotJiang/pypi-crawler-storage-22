from nonebot.log import logger

_clog = logger.opt(colors=True)
_TAG = "<fg 208><b>[LyBot]</b></>"
