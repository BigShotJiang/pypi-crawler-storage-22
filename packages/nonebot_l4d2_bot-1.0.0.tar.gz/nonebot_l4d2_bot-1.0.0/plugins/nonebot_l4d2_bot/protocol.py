import hashlib
import hmac
import time
import uuid
from enum import Enum
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class MsgType(str, Enum):
    HELLO = "hello"
    HELLO_ACK = "hello_ack"
    PING = "ping"
    PONG = "pong"
    TEXT_OUT = "text_out"
    TEXT_IN = "text_in"
    FILE_OUT = "file_out"
    FILE_IN_NOTICE = "file_in_notice"
    ACK = "ack"
    RESULT = "result"
    ERROR = "error"
    MAP_DICT = "map_dict"


class ErrCode(int, Enum):
    OK = 0
    AUTH_FAILED = 1001
    INVALID_SIG = 1002
    EXPIRED = 1003
    DUPLICATE = 1004
    INVALID_PAYLOAD = 2001
    FILE_TOO_LARGE = 3001
    FILE_EXT_DENIED = 3002
    FILE_NOT_FOUND = 3003
    INTERNAL = 5000


class BridgePacket(BaseModel):
    v: int = 1
    type: MsgType
    msg_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    server_id: str = ""
    ts: int = Field(default_factory=lambda: int(time.time()))
    channel: str = ""
    payload: Dict[str, Any] = Field(default_factory=dict)
    sig: str = ""

    def compute_sig(self, secret: str) -> str:
        raw = f"{self.v}|{self.type}|{self.msg_id}|{self.server_id}|{self.ts}|{self.channel}"
        return hmac.new(
            secret.encode(), raw.encode(), hashlib.sha256
        ).hexdigest()

    def sign(self, secret: str) -> "BridgePacket":
        self.sig = self.compute_sig(secret)
        return self

    def verify_sig(self, secret: str) -> bool:
        expected = self.compute_sig(secret)
        return hmac.compare_digest(self.sig, expected)

    def verify_ts(self, window_sec: int = 30) -> bool:
        return abs(time.time() - self.ts) <= window_sec


def make_hello_ack(server_id: str, secret: str) -> BridgePacket:
    return BridgePacket(
        type=MsgType.HELLO_ACK,
        server_id="bridge",
        payload={"accepted_server": server_id},
    ).sign(secret)


def make_pong(secret: str) -> BridgePacket:
    return BridgePacket(type=MsgType.PONG, server_id="bridge").sign(secret)


def make_text_in(
        channel: str, sender: str, text: str, secret: str,
        raw_json: str = "{}") -> BridgePacket:
    return BridgePacket(
        type=MsgType.TEXT_IN,
        server_id="bridge",
        channel=channel,
        payload={"sender": sender, "text": text, "raw_json": raw_json},
    ).sign(secret)


def make_file_in_notice(
        channel: str, file_id: str, file_name: str,
        size: int, sha256: str, secret: str) -> BridgePacket:
    return BridgePacket(
        type=MsgType.FILE_IN_NOTICE,
        server_id="bridge",
        channel=channel,
        payload={
            "file_id": file_id,
            "file_name": file_name,
            "size": size,
            "sha256": sha256,
        },
    ).sign(secret)


def make_ack(ref_msg_id: str, secret: str) -> BridgePacket:
    return BridgePacket(
        type=MsgType.ACK,
        server_id="bridge",
        payload={"ref_msg_id": ref_msg_id},
    ).sign(secret)


def make_error(
        code: ErrCode, msg: str, secret: str,
        ref_msg_id: str = "") -> BridgePacket:
    return BridgePacket(
        type=MsgType.ERROR,
        server_id="bridge",
        payload={"code": code.value, "message": msg, "ref_msg_id": ref_msg_id},
    ).sign(secret)


def make_result(
        task_id: str, ok: bool, secret: str,
        err_code: int = 0, err_msg: str = "",
        extra: Optional[Dict] = None) -> BridgePacket:
    p: Dict[str, Any] = {
        "task_id": task_id, "ok": ok,
        "err_code": err_code, "err_msg": err_msg,
    }
    if extra:
        p.update(extra)
    return BridgePacket(
        type=MsgType.RESULT,
        server_id="bridge",
        payload=p,
    ).sign(secret)


class DedupWindow:

    def __init__(self, window_sec: int = 600):
        self._window = window_sec
        self._seen: Dict[str, float] = {}

    def is_dup(self, msg_id: str) -> bool:
        now = time.time()
        self._cleanup(now)
        if msg_id in self._seen:
            return True
        self._seen[msg_id] = now
        return False

    def _cleanup(self, now: float):
        expired = [k for k, t in self._seen.items() if now - t > self._window]
        for k in expired:
            del self._seen[k]
