import io
from typing import List, Tuple

from PIL import Image, ImageDraw, ImageFont, ImageFilter

_FONT_PATH = "C:/Windows/Fonts/msyh.ttc"
_FONT_BOLD_PATH = "C:/Windows/Fonts/msyhbd.ttc"

_BG_TOP = (236, 242, 255)
_BG_BOT = (248, 251, 255)
_CARD_BG = (255, 255, 255)
_CARD_BORDER = (226, 233, 246)
_SHADOW_ALPHA = 28

_TEXT_DARK = (30, 35, 50)
_TEXT_MID = (70, 80, 100)
_TEXT_LIGHT = (90, 100, 120)

_ICON_GREEN = (16, 185, 129)
_ICON_GREEN_BG = (220, 252, 240)
_ICON_RED = (239, 68, 68)
_ICON_RED_BG = (254, 226, 226)
_ICON_BLUE = (59, 130, 246)
_ICON_BLUE_BG = (219, 234, 254)
_ICON_AMBER = (245, 158, 11)
_ICON_AMBER_BG = (255, 243, 219)

_PROGRESS_BG = (232, 238, 250)
_SEP = (239, 242, 249)
_TILE_BG = (248, 250, 255)
_TILE_BORDER = (232, 238, 248)

_CARD_PAD_X = 24
_CARD_PAD_Y = 22
_CARD_R = 0
_ICON_R = 18
_PROGRESS_H = 8
_PROGRESS_R = 4
_S = 2


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    try:
        path = _FONT_BOLD_PATH if bold else _FONT_PATH
        return ImageFont.truetype(path, size, index=1)
    except OSError:
        try:
            return ImageFont.truetype(path, size, index=0)
        except OSError:
            return ImageFont.load_default()


def _ts(draw: ImageDraw.ImageDraw, text: str,
        font: ImageFont.FreeTypeFont) -> Tuple[int, int]:
    bbox = draw.textbbox((0, 0), text, font=font)
    return bbox[2] - bbox[0], bbox[3] - bbox[1]


def _vcenter(
        draw: ImageDraw.ImageDraw, text: str,
        font: ImageFont.FreeTypeFont, container_h: int) -> int:
    bbox = draw.textbbox((0, 0), text, font=font)
    vis_center = (bbox[1] + bbox[3]) / 2
    return round(container_h / 2 - vis_center)


def _ellipsize(
        draw: ImageDraw.ImageDraw, text: str,
        font: ImageFont.FreeTypeFont, max_width: int) -> str:
    if _ts(draw, text, font)[0] <= max_width:
        return text
    ellipsis = "…"
    lo, hi = 0, len(text)
    while lo < hi:
        mid = (lo + hi) // 2
        cand = text[:mid] + ellipsis
        if _ts(draw, cand, font)[0] <= max_width:
            lo = mid + 1
        else:
            hi = mid
    cut = max(0, lo - 1)
    return text[:cut] + ellipsis


def _format_minutes(mins: int) -> str:
    if mins < 60:
        return f"{mins} 分钟"
    return f"{mins // 60}h {mins % 60}m"


def _badge_style_by_ratio(ratio: float) -> Tuple[str, Tuple[int, int, int], Tuple[int, int, int]]:
    if ratio >= 1.0:
        return "满员", _ICON_RED_BG, _ICON_RED
    if ratio >= 0.8:
        return "偏满", _ICON_AMBER_BG, _ICON_AMBER
    return "在线", _ICON_GREEN_BG, _ICON_GREEN


def _gradient_bg(w: int, h: int) -> Image.Image:
    img = Image.new("RGB", (w, h))
    draw = ImageDraw.Draw(img)
    for y in range(h):
        r = int(_BG_TOP[0] + (_BG_BOT[0] - _BG_TOP[0]) * y / h)
        g = int(_BG_TOP[1] + (_BG_BOT[1] - _BG_TOP[1]) * y / h)
        b = int(_BG_TOP[2] + (_BG_BOT[2] - _BG_TOP[2]) * y / h)
        draw.line([(0, y), (w, y)], fill=(r, g, b))

    glow = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([w - 220*_S, -90*_S, w + 120*_S, 200*_S], fill=(190, 230, 255, 90))
    gd.ellipse([-180*_S, h - 180*_S, 140*_S, h + 120*_S], fill=(198, 224, 255, 70))
    glow = glow.filter(ImageFilter.GaussianBlur(50 * _S))

    out = img.convert("RGBA")
    out = Image.alpha_composite(out, glow)
    return out.convert("RGB")


def _draw_icon(
        draw: ImageDraw.ImageDraw, cx: int, cy: int,
        bg: Tuple[int, int, int], fg: Tuple[int, int, int],
        kind: str):
    S = _S
    r = _ICON_R * S
    draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=bg)
    if kind == "online":
        draw.line(
            [(cx - 6*S, cy), (cx - 1*S, cy + 5*S), (cx + 7*S, cy - 5*S)],
            fill=fg, width=3*S)
    elif kind == "offline":
        draw.line([(cx - 5*S, cy - 5*S), (cx + 5*S, cy + 5*S)], fill=fg, width=3*S)
        draw.line([(cx + 5*S, cy - 5*S), (cx - 5*S, cy + 5*S)], fill=fg, width=3*S)
    else:
        draw.rounded_rectangle([cx - 6*S, cy - 6*S, cx - 2*S, cy + 6*S], radius=2*S, fill=fg)
        draw.rounded_rectangle([cx + 1*S, cy - 2*S, cx + 5*S, cy + 6*S], radius=2*S, fill=fg)


def _draw_badge(draw: ImageDraw.ImageDraw, x: int, y: int,
                text: str, bg: Tuple[int, int, int], fg: Tuple[int, int, int],
                font: ImageFont.FreeTypeFont) -> Tuple[int, int]:
    S = _S
    bbox = draw.textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0]
    w = tw + 18 * S
    h = 24 * S
    draw.rounded_rectangle([x, y, x + w, y + h], radius=h // 2, fill=bg)
    tx = x + (w - tw) // 2 - bbox[0]
    ty = y + _vcenter(draw, text, font, h) + S
    draw.text((tx, ty), text, fill=fg, font=font)
    return w, h


def _draw_tile(
        draw: ImageDraw.ImageDraw,
        x: int, y: int, w: int, h: int):
    draw.rounded_rectangle(
        [x, y, x + w, y + h],
        radius=12 * _S, fill=_TILE_BG,
        outline=_TILE_BORDER, width=_S)


def _draw_progress(
        draw: ImageDraw.ImageDraw,
        x: int, y: int, w: int,
        ratio: float, color: Tuple[int, int, int]):
    S = _S
    ph = _PROGRESS_H * S
    pr = _PROGRESS_R * S
    draw.rounded_rectangle(
        [x, y, x + w, y + ph],
        radius=pr, fill=_PROGRESS_BG)
    fill_w = max(int(w * ratio), pr * 2) if ratio > 0 else 0
    if fill_w > 0:
        draw.rounded_rectangle(
            [x, y, x + fill_w, y + ph],
            radius=pr, fill=color)


def _make_card(card_w: int, card_h: int) -> Image.Image:
    S = _S
    img_w = card_w
    img_h = card_h

    img = _gradient_bg(img_w, img_h).convert("RGBA")

    shadow = Image.new("RGBA", (img_w, img_h), (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    sd.rounded_rectangle(
        [2*S, 4*S, card_w - 2*S, card_h + 6*S],
        radius=_CARD_R * S, fill=(0, 0, 0, _SHADOW_ALPHA))
    shadow = shadow.filter(ImageFilter.GaussianBlur(10 * S))
    img = Image.alpha_composite(img, shadow)

    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle(
        [0, 0, card_w, card_h],
        radius=_CARD_R * S, fill=_CARD_BG,
        outline=_CARD_BORDER, width=S)
    return img.convert("RGB")


def render_server_info(
        server_name: str, map_display: str,
        players: int, max_players: int) -> bytes:
    S = _S
    f_name = _font(22 * S, bold=True)
    f_label = _font(13 * S)
    f_val = _font(15 * S, bold=True)
    f_count = _font(30 * S, bold=True)
    f_max = _font(14 * S)
    f_badge = _font(11 * S, bold=True)

    tmp = Image.new("RGB", (1, 1))
    d = ImageDraw.Draw(tmp)

    icon_space = (_ICON_R * 2 + 16) * S
    nw, _ = _ts(d, server_name, f_name)
    mv_w, _ = _ts(d, map_display, f_val)

    count_text = str(players)
    max_text = f" / {max_players}"
    cw, _ = _ts(d, count_text, f_count)
    mxw, _ = _ts(d, max_text, f_max)

    content_w = max(icon_space + nw + 70*S, mv_w + 28*S,
                    cw + mxw + 28*S, 380*S)
    card_w = _CARD_PAD_X*S + content_w + _CARD_PAD_X*S

    map_tile_h = 58 * S
    player_tile_h = 74 * S
    icon_h = _ICON_R * 2 * S
    card_h = (
        _CARD_PAD_Y*S + icon_h + 18*S
        + map_tile_h + 12*S
        + player_tile_h
        + _CARD_PAD_Y*S
    )

    ratio = players / max_players if max_players > 0 else 0
    badge_text, badge_bg, accent = _badge_style_by_ratio(ratio)

    img = _make_card(card_w, card_h)
    draw = ImageDraw.Draw(img)

    cx = _CARD_PAD_X * S
    cy = _CARD_PAD_Y * S
    right_edge = card_w - _CARD_PAD_X * S

    icon_cx = cx + _ICON_R * S
    icon_cy = cy + icon_h // 2
    icon_bg = {
        _ICON_GREEN: _ICON_GREEN_BG, _ICON_AMBER: _ICON_AMBER_BG,
        _ICON_RED: _ICON_RED_BG,
    }.get(accent, _ICON_GREEN_BG)
    icon_kind = "offline" if ratio >= 1.0 else "online"
    _draw_icon(draw, icon_cx, icon_cy, icon_bg, accent, icon_kind)

    tx = cx + icon_space
    title_y = cy + _vcenter(draw, server_name, f_name, icon_h)
    badge_w = _ts(draw, badge_text, f_badge)[0] + 18*S
    badge_y = cy + (icon_h - 24*S) // 2
    title_max_w = max(90*S, right_edge - tx - badge_w - 12*S)
    title = _ellipsize(draw, server_name, f_name, title_max_w)
    draw.text((tx, title_y), title, fill=_TEXT_DARK, font=f_name)

    _draw_badge(draw, right_edge - badge_w, badge_y,
                badge_text, badge_bg, accent, f_badge)

    cy += icon_h + 18*S

    draw.line([(cx, cy - 8*S), (right_edge, cy - 8*S)], fill=_SEP, width=S)

    _draw_tile(draw, cx, cy, content_w, 58*S)
    draw.text((cx + 14*S, cy + 10*S), "当前地图", fill=_TEXT_LIGHT, font=f_label)
    map_text = _ellipsize(draw, map_display, f_val, content_w - 28*S)
    draw.text((cx + 14*S, cy + 28*S), map_text, fill=_TEXT_DARK, font=f_val)
    cy += 58*S + 12*S

    _draw_tile(draw, cx, cy, content_w, 74*S)
    draw.text((cx + 14*S, cy + 12*S), "在线玩家", fill=_TEXT_LIGHT, font=f_label)

    num_x = right_edge - 14*S - cw - mxw
    draw.text((num_x, cy + 4*S), count_text, fill=accent, font=f_count)
    draw.text(
        (num_x + cw, cy + 17*S), max_text,
        fill=_TEXT_LIGHT, font=f_max)
    _draw_progress(draw, cx + 14*S, cy + 52*S, content_w - 28*S, ratio, accent)

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def render_server_offline(host: str, port: int) -> bytes:
    S = _S
    f_name = _font(22 * S, bold=True)
    f_label = _font(13 * S)
    f_status = _font(15 * S, bold=True)
    f_badge = _font(11 * S, bold=True)

    tmp = Image.new("RGB", (1, 1))
    d = ImageDraw.Draw(tmp)

    icon_space = (_ICON_R * 2 + 16) * S
    addr = f"{host}:{port}"
    nw, _ = _ts(d, addr, f_name)
    sv_w, _ = _ts(d, "离线 / 无响应", f_status)

    content_w = max(icon_space + nw + 90*S, sv_w + 28*S, 340*S)
    card_w = _CARD_PAD_X*S + content_w + _CARD_PAD_X*S
    status_tile_h = 58 * S
    icon_h = _ICON_R * 2 * S
    card_h = (
        _CARD_PAD_Y*S + icon_h + 18*S
        + status_tile_h
        + _CARD_PAD_Y*S
    )

    img = _make_card(card_w, card_h)
    draw = ImageDraw.Draw(img)

    cx = _CARD_PAD_X * S
    cy = _CARD_PAD_Y * S
    right_edge = card_w - _CARD_PAD_X * S

    icon_cx = cx + _ICON_R * S
    icon_cy = cy + icon_h // 2
    _draw_icon(draw, icon_cx, icon_cy, _ICON_RED_BG, _ICON_RED, "offline")

    tx = cx + icon_space
    title_y = cy + _vcenter(draw, addr, f_name, icon_h)
    badge_text = "离线"
    badge_w = _ts(draw, badge_text, f_badge)[0] + 18*S
    badge_y = cy + (icon_h - 24*S) // 2
    title_max_w = max(90*S, right_edge - tx - badge_w - 12*S)
    title = _ellipsize(draw, addr, f_name, title_max_w)
    draw.text((tx, title_y), title, fill=_TEXT_DARK, font=f_name)

    _draw_badge(draw, right_edge - badge_w, badge_y,
                badge_text, _ICON_RED_BG, _ICON_RED, f_badge)

    cy += icon_h + 18*S

    draw.line([(cx, cy - 8*S), (right_edge, cy - 8*S)], fill=_SEP, width=S)

    _draw_tile(draw, cx, cy, content_w, 58*S)
    draw.text((cx + 14*S, cy + 10*S), "连接状态", fill=_TEXT_LIGHT, font=f_label)
    draw.text(
        (cx + 14*S, cy + 28*S), "离线 / 无响应",
        fill=_ICON_RED, font=f_status)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def render_bridge_status(conns: List[Tuple[str, int]]) -> bytes:
    S = _S
    f_title = _font(22 * S, bold=True)
    f_count = _font(26 * S, bold=True)
    f_label = _font(13 * S)
    f_sid = _font(13 * S, bold=True)
    f_time = _font(12 * S)
    f_badge = _font(11 * S, bold=True)

    tmp = Image.new("RGB", (1, 1))
    d = ImageDraw.Draw(tmp)

    icon_space = (_ICON_R * 2 + 16) * S
    title = "Bridge 状态"
    tw, _ = _ts(d, title, f_title)

    count = len(conns)
    ctext = str(count)
    ctw, cth = _ts(d, ctext, f_count)
    ul = " 台在线"
    ulw, _ = _ts(d, ul, f_label)

    rows_data = []
    max_row_w = 0
    for sid, mins in conns:
        sw, sh = _ts(d, sid, f_sid)
        time_str = _format_minutes(mins)
        ttw, _ = _ts(d, time_str, f_time)
        row_w = sw + 40*S + ttw
        max_row_w = max(max_row_w, row_w)
        rows_data.append((sid, time_str, sw, sh))

    avg_mins = int(sum(mins for _, mins in conns) / count) if count > 0 else 0
    avg_text = _format_minutes(avg_mins) if count > 0 else "-"
    avg_w, _ = _ts(d, avg_text, f_label)

    content_w = max(icon_space + tw, ctw + ulw + 8*S,
                    max_row_w + 24*S, avg_w + 180*S, 390*S)
    card_w = _CARD_PAD_X*S + content_w + _CARD_PAD_X*S

    row_h = 34 * S
    row_gap = 6 * S
    row_block_h = len(rows_data) * row_h
    if len(rows_data) > 1:
        row_block_h += (len(rows_data) - 1) * row_gap

    icon_h = _ICON_R * 2 * S
    card_h = (
        _CARD_PAD_Y*S + icon_h + 18*S
        + 72*S
        + row_block_h + _CARD_PAD_Y*S
    )

    img = _make_card(card_w, card_h)
    draw = ImageDraw.Draw(img)

    cx = _CARD_PAD_X * S
    cy = _CARD_PAD_Y * S
    right_edge = card_w - _CARD_PAD_X * S

    icon_cx = cx + _ICON_R * S
    icon_cy = cy + icon_h // 2
    _draw_icon(draw, icon_cx, icon_cy, _ICON_BLUE_BG, _ICON_BLUE, "bridge")

    tx = cx + icon_space
    title_y = cy + _vcenter(draw, title, f_title, icon_h)
    badge_text = "在线"
    badge_w = _ts(draw, badge_text, f_badge)[0] + 18*S
    badge_y = cy + (icon_h - 24*S) // 2
    title_max_w = max(90*S, right_edge - tx - badge_w - 12*S)
    title = _ellipsize(draw, title, f_title, title_max_w)
    draw.text((tx, title_y), title, fill=_TEXT_DARK, font=f_title)

    _draw_badge(draw, right_edge - badge_w, badge_y,
                badge_text, _ICON_GREEN_BG, _ICON_GREEN, f_badge)

    cy += icon_h + 18*S

    draw.line([(cx, cy - 8*S), (right_edge, cy - 8*S)], fill=_SEP, width=S)

    tile_w = (content_w - 10*S) // 2
    _draw_tile(draw, cx, cy, tile_w, 58*S)
    draw.text((cx + 14*S, cy + 10*S), "在线数量", fill=_TEXT_LIGHT, font=f_label)
    draw.text((cx + 14*S, cy + 26*S), ctext, fill=_ICON_GREEN, font=f_count)
    draw.text((cx + 14*S + ctw, cy + 38*S), ul, fill=_TEXT_MID, font=f_label)

    tile2_x = cx + tile_w + 10*S
    _draw_tile(draw, tile2_x, cy, tile_w, 58*S)
    draw.text((tile2_x + 14*S, cy + 10*S), "平均在线时长", fill=_TEXT_LIGHT, font=f_label)
    draw.text((tile2_x + 14*S, cy + 30*S), avg_text, fill=_TEXT_DARK, font=f_sid)

    cy += 58*S + 14*S

    for sid, time_str, sw, sh in rows_data:
        _draw_tile(draw, cx, cy, content_w, row_h)
        draw.ellipse(
            [cx + 12*S, cy + 13*S, cx + 20*S, cy + 21*S],
            fill=_ICON_GREEN)
        sid_text = _ellipsize(draw, sid, f_sid, content_w - 130*S)
        draw.text((cx + 26*S, cy + 8*S), sid_text, fill=_TEXT_DARK, font=f_sid)
        tw2 = _ts(draw, time_str, f_time)[0]
        draw.text(
            (right_edge - tw2 - 10*S, cy + 9*S), time_str,
            fill=_TEXT_MID, font=f_time)
        cy += row_h + row_gap

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()
