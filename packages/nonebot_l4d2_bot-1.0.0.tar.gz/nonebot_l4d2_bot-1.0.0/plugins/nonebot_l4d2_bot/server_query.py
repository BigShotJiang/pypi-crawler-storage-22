import asyncio
import struct
from typing import Dict, Optional, Tuple

from nonebot.log import logger

from .log import _clog, _TAG

A2S_INFO_REQUEST = b'\xFF\xFF\xFF\xFF\x54Source Engine Query\x00'
A2S_INFO_HEADER = 0x49
A2S_CHALLENGE_HEADER = 0x41

L4D2_MAP_TABLE: Dict[str, Tuple[str, str]] = {
    "c1m1_hotel":              ("死亡中心", "旅馆"),
    "c1m2_streets":            ("死亡中心", "街道"),
    "c1m3_mall":               ("死亡中心", "购物中心"),
    "c1m4_atrium":             ("死亡中心", "中厅"),
    "c6m1_riverbank":          ("短暂时刻", "河畔"),
    "c6m2_bedlam":             ("短暂时刻", "地下通道"),
    "c6m3_port":               ("短暂时刻", "港口"),
    "c2m1_highway":            ("黑色狂欢节", "高速公路"),
    "c2m2_fairgrounds":        ("黑色狂欢节", "游乐场"),
    "c2m3_coaster":            ("黑色狂欢节", "过山车"),
    "c2m4_barns":              ("黑色狂欢节", "谷仓"),
    "c2m5_concert":            ("黑色狂欢节", "音乐会"),
    "c3m1_plankcountry":       ("沼泽激战", "乡村"),
    "c3m2_swamp":              ("沼泽激战", "沼泽"),
    "c3m3_shantytown":         ("沼泽激战", "贫民窟"),
    "c3m4_plantation":         ("沼泽激战", "种植园"),
    "c4m1_milltown_a":         ("暴风骤雨", "密尔城"),
    "c4m2_sugarmill_a":        ("暴风骤雨", "糖厂"),
    "c4m3_sugarmill_b":        ("暴风骤雨", "逃离工厂"),
    "c4m4_milltown_b":         ("暴风骤雨", "重返小镇"),
    "c4m5_milltown_escape":    ("暴风骤雨", "逃离小镇"),
    "c5m1_waterfront":         ("教区", "码头"),
    "c5m2_park":               ("教区", "公园"),
    "c5m3_cemetery":           ("教区", "墓地"),
    "c5m4_quarter":            ("教区", "特区"),
    "c5m5_bridge":             ("教区", "桥"),
    "c7m1_docks":              ("牺牲", "码头"),
    "c7m2_barge":              ("牺牲", "驳船"),
    "c7m3_port":               ("牺牲", "港口"),
    "c8m1_apartment":          ("毫不留情", "公寓"),
    "c8m2_subway":             ("毫不留情", "地铁"),
    "c8m3_sewers":             ("毫不留情", "下水道"),
    "c8m4_interior":           ("毫不留情", "医院"),
    "c8m5_rooftop":            ("毫不留情", "屋顶"),
    "c9m1_alleys":             ("坠机险途", "小巷"),
    "c9m2_lots":               ("坠机险途", "卡车停车场"),
    "c10m1_caves":             ("死亡丧钟", "收费公路"),
    "c10m2_drainage":          ("死亡丧钟", "水沟"),
    "c10m3_ranchhouse":        ("死亡丧钟", "教堂"),
    "c10m4_mainstreet":        ("死亡丧钟", "小镇"),
    "c10m5_houseboat":         ("死亡丧钟", "码头"),
    "c11m1_greenhouse":        ("静寂时分", "花房"),
    "c11m2_offices":           ("静寂时分", "起重机"),
    "c11m3_garage":            ("静寂时分", "建筑工地"),
    "c11m4_terminal":          ("静寂时分", "航空机场"),
    "c11m5_runway":            ("静寂时分", "飞机跑道"),
    "c12m1_hilltop":           ("血腥收获", "森林"),
    "c12m2_traintunnel":       ("血腥收获", "隧道"),
    "c12m3_bridge":            ("血腥收获", "桥"),
    "c12m4_barn":              ("血腥收获", "火车站"),
    "c12m5_cornfield":         ("血腥收获", "农舍"),
    "c13m1_alpinecreek":       ("刺骨寒溪", "高山小溪"),
    "c13m2_southpinestream":   ("刺骨寒溪", "松木之河"),
    "c13m3_memorialbridge":    ("刺骨寒溪", "纪念大桥"),
    "c13m4_cutthroatcreek":    ("刺骨寒溪", "残酷溪流"),
    "c14m1_junkyard":          ("临死一搏", "废物场"),
    "c14m2_lighthouse":        ("临死一搏", "灯塔终章"),
}


_ext_dict: Dict[str, str] = {}
_ext_groups: Dict[str, str] = {}


def _parse_kv_line(line: str) -> Tuple[str, str]:
    key = ""
    val = ""
    s = line.strip()
    if s.startswith('\ufeff'):
        s = s[1:]
    in_quote = False
    for i, ch in enumerate(s):
        if ch == '"':
            in_quote = not in_quote
        elif not in_quote and i + 1 < len(s) and s[i] == '/' and s[i + 1] == '/':
            s = s[:i].rstrip()
            break

    if not s or s[0] in ('/', '#', '{', '}'):
        return "", ""

    parts = []
    i = 0
    while i < len(s) and len(parts) < 2:
        while i < len(s) and s[i] in (' ', '\t'):
            i += 1
        if i >= len(s):
            break
        if s[i] == '"':
            i += 1
            end = s.find('"', i)
            if end == -1:
                break
            parts.append(s[i:end])
            i = end + 1
        else:
            start = i
            while i < len(s) and s[i] not in (' ', '\t'):
                i += 1
            parts.append(s[start:i])

    if len(parts) >= 1:
        key = parts[0]
    if len(parts) >= 2:
        val = parts[1]
    return key, val


def _parse_kv_dict(text: str) -> Tuple[Dict[str, str], Dict[str, str]]:
    result: Dict[str, str] = {}
    groups: Dict[str, str] = {}
    depth = 0
    current_group = ""
    current_group_translated = ""

    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue

        if stripped == '{':
            depth += 1
            continue
        if stripped == '}':
            if depth == 2:
                current_group = ""
                current_group_translated = ""
            depth -= 1
            continue

        key, val = _parse_kv_line(line)
        if not key:
            continue

        if depth == 1 and not val:
            current_group = key
            continue

        if val:
            result[key.lower()] = val
            if depth == 2 and current_group:
                if key.lower() == current_group.lower():
                    current_group_translated = val
                else:
                    if current_group_translated:
                        groups[key.lower()] = current_group_translated

    return result, groups


def update_dict_from_text(text: str) -> int:
    global _ext_dict, _ext_groups
    new_dict, new_groups = _parse_kv_dict(text)
    _ext_dict = new_dict
    _ext_groups = new_groups
    return len(new_dict)


def resolve_map_name(map_code: str) -> str:
    key = map_code.lower().strip()
    translated = _ext_dict.get(key)
    if translated:
        campaign = _ext_groups.get(key, "")
        if campaign and campaign != translated:
            return f"{campaign} - {translated}"
        return translated
    if key in L4D2_MAP_TABLE:
        campaign, chapter = L4D2_MAP_TABLE[key]
        return f"{campaign} - {chapter}"
    return map_code


class A2SInfoResult:

    def __init__(self):
        self.server_name: str = ""
        self.map_name: str = ""
        self.folder: str = ""
        self.game: str = ""
        self.players: int = 0
        self.max_players: int = 0
        self.bots: int = 0
        self._map_display: Optional[str] = None

    @property
    def map_display(self) -> str:
        if self._map_display is not None:
            return self._map_display
        return resolve_map_name(self.map_name)

    @map_display.setter
    def map_display(self, value: str):
        self._map_display = value

    @property
    def real_players(self) -> int:
        return max(0, self.players - self.bots)


def _read_string(data: bytes, offset: int) -> Tuple[str, int]:
    end = data.index(b'\x00', offset)
    return data[offset:end].decode('utf-8', errors='replace'), end + 1


def _parse_a2s_info(data: bytes) -> Optional[A2SInfoResult]:
    if len(data) < 6:
        return None

    header = struct.unpack_from('<I', data, 0)[0]
    if header != 0xFFFFFFFF:
        return None

    resp_type = data[4]
    if resp_type != A2S_INFO_HEADER:
        return None

    result = A2SInfoResult()
    offset = 6

    try:
        result.server_name, offset = _read_string(data, offset)
        result.map_name, offset = _read_string(data, offset)
        result.folder, offset = _read_string(data, offset)
        result.game, offset = _read_string(data, offset)

        if offset + 7 <= len(data):
            _app_id = struct.unpack_from('<H', data, offset)[0]
            offset += 2
            result.players = data[offset]
            result.max_players = data[offset + 1]
            result.bots = data[offset + 2]
    except (ValueError, IndexError, struct.error) as e:
        _clog.warning(f"{_TAG} A2S_INFO 解析异常: {e}")
        return None

    return result


async def query_server(
        host: str, port: int,
        timeout: float = 5.0) -> Optional[A2SInfoResult]:
    loop = asyncio.get_running_loop()
    future = loop.create_future()

    class A2SProtocol(asyncio.DatagramProtocol):
        def __init__(self):
            self.transport = None

        def connection_made(self, transport):
            self.transport = transport
            transport.sendto(A2S_INFO_REQUEST)

        def datagram_received(self, data, addr):
            if len(data) < 5:
                return
            if data[4] == A2S_CHALLENGE_HEADER and len(data) >= 9:
                challenge = data[5:9]
                self.transport.sendto(A2S_INFO_REQUEST + challenge)
                return
            if not future.done():
                future.set_result(data)

        def error_received(self, exc):
            if not future.done():
                future.set_exception(exc)

        def connection_lost(self, exc):
            if not future.done():
                future.set_exception(exc or ConnectionError("连接丢失"))

    transport = None
    try:
        transport, _ = await loop.create_datagram_endpoint(
            A2SProtocol,
            remote_addr=(host, port),
        )
        data = await asyncio.wait_for(future, timeout=timeout)
        info = _parse_a2s_info(data)
        if info:
            info.map_display = resolve_map_name(info.map_name)
        return info
    except asyncio.TimeoutError:
        _clog.warning(f"{_TAG} 查询 {host}:{port} 超时")
        return None
    except Exception as e:
        _clog.warning(f"{_TAG} 查询 {host}:{port} 失败: {e}")
        return None
    finally:
        if transport:
            transport.close()


async def query_server_auto(
        host: str, port: int = 0,
        timeout: float = 5.0) -> Optional[A2SInfoResult]:
    if port > 0:
        return await query_server(host, port, timeout)

    found: Optional[A2SInfoResult] = None
    stop = asyncio.Event()
    queue: asyncio.Queue[int] = asyncio.Queue()

    for p in range(1, 65536):
        queue.put_nowait(p)

    async def _worker():
        nonlocal found
        while not stop.is_set():
            try:
                p = queue.get_nowait()
            except asyncio.QueueEmpty:
                return
            result = await query_server(host, p, 2.0)
            if result and not stop.is_set():
                result._port = p
                found = result
                stop.set()

    workers = [asyncio.create_task(_worker()) for _ in range(1000)]
    try:
        await asyncio.wait_for(stop.wait(), timeout=timeout)
    except asyncio.TimeoutError:
        pass
    stop.set()
    for w in workers:
        w.cancel()

    return found


def parse_server_addr(addr: str) -> Tuple[str, str, int]:
    name = ""
    if "|" in addr:
        name, addr = addr.split("|", 1)
        name = name.strip()

    addr = addr.strip()
    if ":" in addr:
        h, p = addr.rsplit(":", 1)
        host = h.strip()
        port = int(p.strip())
    else:
        host = addr
        port = 0

    if not name:
        name = f"{host}:{port}"

    return name, host, port
