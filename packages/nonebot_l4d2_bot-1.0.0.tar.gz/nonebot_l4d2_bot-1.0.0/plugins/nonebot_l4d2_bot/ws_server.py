import asyncio
import json
import re
import time

from nonebot import get_driver
from nonebot.drivers import ASGIMixin, WebSocketServerSetup, Request, WebSocket
from nonebot.log import logger
from starlette.requests import URL

from .config import BridgeConfig
from .log import _clog, _TAG
from .connection import conn_mgr
from .protocol import (
    BridgePacket, MsgType, ErrCode, DedupWindow,
    make_hello_ack, make_pong, make_ack, make_error,
)
from .server_query import update_dict_from_text

_MAX_CONNECTIONS = 16
_SERVER_ID_RE = re.compile(r'^[\w.\-]{1,64}$')

_dedup = DedupWindow()
_config: BridgeConfig = None

_file_out_handlers = []


def on_file_out(func):
    _file_out_handlers.append(func)
    return func


def setup_ws_server(config: BridgeConfig):
    global _config
    _config = config
    _dedup._window = config.l4d2_bridge_msg_dedup_window_sec

    driver = get_driver()
    if not isinstance(driver, ASGIMixin):
        _clog.error(f"{_TAG} 当前驱动不支持 ASGI，无法挂载 WebSocket")
        return

    ws_setup = WebSocketServerSetup(
        path=URL(config.l4d2_bridge_ws_path),
        name="l4d2_bridge_ws",
        handle_func=_handle_ws,
    )
    driver.setup_websocket_server(ws_setup)
    _clog.info(f"{_TAG} WebSocket 服务已挂载: {config.l4d2_bridge_ws_path}")


async def _handle_ws(ws: WebSocket):
    if conn_mgr.count >= _MAX_CONNECTIONS:
        _clog.warning(f"{_TAG} 连接数已达上限 ({_MAX_CONNECTIONS})，拒绝新连接")
        await ws.accept()
        await ws.close()
        return

    await ws.accept()
    server_id = ""
    try:
        server_id = await _do_handshake(ws)
        if not server_id:
            return

        conn = conn_mgr.add(server_id, ws)
        conn.authenticated = True

        heartbeat_task = asyncio.create_task(_heartbeat_monitor(server_id))

        try:
            await _message_loop(ws, server_id)
        finally:
            heartbeat_task.cancel()
            conn_mgr.remove(server_id)
    except Exception as e:
        _clog.error(f"{_TAG} WebSocket 异常 ({server_id}): {e}")
    finally:
        try:
            await ws.close()
        except Exception:
            pass


async def _do_handshake(ws: WebSocket) -> str:
    try:
        data = await asyncio.wait_for(ws.receive(), timeout=10)
        raw = data if isinstance(data, str) else data.decode("utf-8")
    except asyncio.TimeoutError:
        _clog.warning(f"{_TAG} 握手超时")
        return ""

    try:
        pkt = BridgePacket.model_validate_json(raw)
    except Exception:
        _clog.warning(f"{_TAG} 握手包解析失败")
        return ""

    if pkt.type != MsgType.HELLO:
        await _send(ws, make_error(ErrCode.AUTH_FAILED, "期望 hello", _config.l4d2_bridge_token))
        return ""

    token_in = pkt.payload.get("token", "")
    if token_in != _config.l4d2_bridge_token:
        await _send(ws, make_error(ErrCode.AUTH_FAILED, "token 错误", _config.l4d2_bridge_token))
        return ""

    if not pkt.verify_sig(_config.l4d2_bridge_token):
        await _send(ws, make_error(ErrCode.INVALID_SIG, "签名校验失败", _config.l4d2_bridge_token))
        return ""

    if not pkt.verify_ts(_config.l4d2_bridge_hmac_window_sec):
        await _send(ws, make_error(ErrCode.EXPIRED, "时间戳过期", _config.l4d2_bridge_token))
        return ""

    server_id = pkt.server_id or "unknown"
    if not _SERVER_ID_RE.match(server_id):
        server_id = re.sub(r'[^\w.\-]', '_', server_id)[:64]
        if not server_id:
            server_id = "unknown"
    ack = make_hello_ack(server_id, _config.l4d2_bridge_token)
    await _send(ws, ack)
    _clog.info(f"{_TAG} 认证成功: {server_id}")
    return server_id


async def _message_loop(ws: WebSocket, server_id: str):
    while True:
        try:
            data = await ws.receive()
            raw = data if isinstance(data, str) else data.decode("utf-8")
        except Exception:
            _clog.info(f"{_TAG} 连接关闭: {server_id}")
            break

        try:
            pkt = BridgePacket.model_validate_json(raw)
        except Exception as e:
            _clog.warning(f"{_TAG} 数据包解析失败 ({server_id}): {e}")
            continue

        if not pkt.verify_sig(_config.l4d2_bridge_token):
            await _send(ws, make_error(
                ErrCode.INVALID_SIG, "签名错误",
                _config.l4d2_bridge_token, pkt.msg_id))
            continue

        if pkt.type not in (MsgType.PING, MsgType.ACK) and _dedup.is_dup(pkt.msg_id):
            _clog.debug(f"{_TAG} 重复消息已跳过: {pkt.msg_id}")
            await _send(ws, make_ack(pkt.msg_id, _config.l4d2_bridge_token))
            continue

        conn = conn_mgr.get(server_id)
        if conn:
            conn.last_ping = time.time()

        await _dispatch(ws, server_id, pkt)


async def _dispatch(ws: WebSocket, server_id: str, pkt: BridgePacket):
    if pkt.type == MsgType.PING:
        await _send(ws, make_pong(_config.l4d2_bridge_token))

    elif pkt.type == MsgType.FILE_OUT:
        await _send(ws, make_ack(pkt.msg_id, _config.l4d2_bridge_token))
        file_id = pkt.payload.get("file_id", "")
        file_name = pkt.payload.get("file_name", "")
        size = pkt.payload.get("size", 0)
        sha256 = pkt.payload.get("sha256", "")
        for handler in _file_out_handlers:
            try:
                await handler(server_id, pkt.channel, file_id, file_name, size, sha256)
            except Exception as e:
                _clog.error(f"{_TAG} file_out 处理器异常: {e}")

    elif pkt.type == MsgType.MAP_DICT:
        await _send(ws, make_ack(pkt.msg_id, _config.l4d2_bridge_token))
        dict_text = pkt.payload.get("dict", "")
        if dict_text:
            count = update_dict_from_text(dict_text)
            _clog.info(f"{_TAG} 收到地图翻译字典 ({server_id}): {count} 条")

    elif pkt.type == MsgType.ACK:
        _clog.debug(f"{_TAG} 收到 ACK ({server_id}): {pkt.payload.get('ref_msg_id')}")

    else:
        _clog.warning(f"{_TAG} 未知消息类型: {pkt.type} ({server_id})")


async def _heartbeat_monitor(server_id: str):
    timeout = _config.l4d2_bridge_heartbeat_interval * 3
    while True:
        await asyncio.sleep(_config.l4d2_bridge_heartbeat_interval)
        conn = conn_mgr.get(server_id)
        if not conn:
            break
        if time.time() - conn.last_ping > timeout:
            _clog.warning(f"{_TAG} 心跳超时，断开连接: {server_id}")
            try:
                await conn.ws.close()
            except Exception:
                pass
            conn_mgr.remove(server_id)
            break


async def _send(ws: WebSocket, pkt: BridgePacket):
    try:
        await ws.send_text(pkt.model_dump_json())
    except Exception as e:
        _clog.error(f"{_TAG} 发送失败: {e}")
