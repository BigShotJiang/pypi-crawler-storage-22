<div align="center">
    <a href="https://v2.nonebot.dev/store">
    <img src="https://github.com/Misty02600/nonebot-plugin-template/releases/download/assets/NoneBotPlugin.png" width="310" alt="logo"></a>

## ✨ nonebot-plugin-actme ✨
[![LICENSE](https://img.shields.io/github/license/Misty02600/nonebot-plugin-actme.svg)](./LICENSE)
[![python](https://img.shields.io/badge/python-3.11+-blue.svg?logo=python&logoColor=white)](https://www.python.org)
[![Adapters](https://img.shields.io/badge/Adapters-OneBot%20v11-blue)](#supported-adapters)
<br/>

[![uv](https://img.shields.io/badge/package%20manager-uv-black?logo=uv)](https://github.com/astral-sh/uv)
[![ruff](https://img.shields.io/badge/code%20style-ruff-black?logo=ruff)](https://github.com/astral-sh/ruff)

</div>

## 📖 介绍

唔唔？你想被xx嘛~？一个有趣的群互动插件，包含三大功能：
- **禁言**：发送 `禁我` / `口我` / `踩我`，bot 会随机禁言你一段时间
- **点赞**：发送 `赞我` / `超我`，bot 会给你点赞；也支持 `赞他 @user` 给别人点赞
- **戳一戳**：发送 `戳我` / `亲我` / `捏我` / `揉我`，bot 会戳你；也支持 `戳他 @user` 戳别人

## 💿 安装

<details open>
<summary>使用 nb-cli 安装</summary>
在 nonebot2 项目的根目录下打开命令行, 输入以下指令即可安装

    nb plugin install nonebot-plugin-actme --upgrade
使用 **pypi** 源安装

    nb plugin install nonebot-plugin-actme --upgrade -i "https://pypi.org/simple"
使用**清华源**安装

    nb plugin install nonebot-plugin-actme --upgrade -i "https://pypi.tuna.tsinghua.edu.cn/simple"

</details>

<details>
<summary>使用包管理器安装</summary>
在 nonebot2 项目的插件目录下, 打开命令行, 根据你使用的包管理器, 输入相应的安装命令

<details open>
<summary>uv</summary>

    uv add nonebot-plugin-actme
安装仓库 main 分支

    uv add git+https://github.com/Misty02600/nonebot-plugin-actme@main
</details>

<details>
<summary>pdm</summary>

    pdm add nonebot-plugin-actme
安装仓库 main 分支

    pdm add git+https://github.com/Misty02600/nonebot-plugin-actme@main
</details>
<details>
<summary>poetry</summary>

    poetry add nonebot-plugin-actme
安装仓库 main 分支

    poetry add git+https://github.com/Misty02600/nonebot-plugin-actme@main
</details>

打开 nonebot2 项目根目录下的 `pyproject.toml` 文件, 在 `[tool.nonebot]` 部分追加写入

    plugins = ["nonebot_plugin_actme"]

</details>

<details>
<summary>使用 nbr 安装(使用 uv 管理依赖可用)</summary>

[nbr](https://github.com/fllesser/nbr) 是一个基于 uv 的 nb-cli，可以方便地管理 nonebot2

    nbr plugin install nonebot-plugin-actme
使用 **pypi** 源安装

    nbr plugin install nonebot-plugin-actme -i "https://pypi.org/simple"
使用**清华源**安装

    nbr plugin install nonebot-plugin-actme -i "https://pypi.tuna.tsinghua.edu.cn/simple"

</details>


## ⚙️ 配置

在 nonebot2 项目的 `.env` 文件中添加以下配置：

| 配置项             | 必填  |      默认值      | 说明                           |
| :----------------- | :---: | :--------------: | :----------------------------- |
| `mute_times`       |  否   | `[1, 5, 10, 30]` | 禁言时间列表（分钟），随机选取 |
| `poke_refuse_prob` |  否   |       0.3        | 拒绝戳一戳的概率 (0-1)         |
| `poke_super_prob`  |  否   |       0.1        | 超级戳一戳（连戳）的概率 (0-1) |
| `poke_more_prob`   |  否   |       0.2        | 连续戳一戳（追加）的概率 (0-1) |

```dotenv
# 自定义禁言时间（分钟）
mute_times=[1, 3, 5, 10, 30]

# 自定义戳一戳概率
poke_refuse_prob=0.3
poke_super_prob=0.1
poke_more_prob=0.2
```

## 🎉 使用

### 指令表

| 指令                              | 权限  | 需要@ |   范围    | 说明                                     |
| :-------------------------------- | :---: | :---: | :-------: | :--------------------------------------- |
| `禁我` / `口我` / `踩我`          | 群员  |  否   |   群聊    | bot 随机禁言你一段时间                   |
| `赞我` / `超我`                   | 所有  |  否   | 私聊/群聊 | bot 给你点赞（最多 50 个）               |
| `赞他 @user` / `超他 @user`       | 群员  |  否   |   群聊    | bot 给指定用户点赞                       |
| `戳我` / `亲我` / `捏我` / `揉我` | 所有  |  否   | 私聊/群聊 | bot 戳你（含拒绝/超级/普通三种随机效果） |
| `戳他 @user` / `亲他 @user` 等    | 群员  |  否   |   群聊    | bot 戳指定用户                           |

### 注意事项

- **禁言功能**需要 bot 拥有群管理员权限，且不能禁言管理员/群主
- **点赞功能**每次执行会尝试点 50 个赞，受 QQ 每日上限限制
- **戳一戳**有 30% 概率拒绝、10% 概率超级连戳、60% 概率正常戳
