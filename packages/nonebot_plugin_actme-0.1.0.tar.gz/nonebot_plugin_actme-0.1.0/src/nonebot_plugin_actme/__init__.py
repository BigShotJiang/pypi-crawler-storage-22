"""
nonebot-plugin-actme

唔唔？你想被xx嘛~？禁言/点赞/戳一戳互动插件
"""

from nonebot.plugin import PluginMetadata

from . import handlers as handlers
from .config import Config

__plugin_meta__ = PluginMetadata(
    name="actme",
    description="唔唔？你想被xx嘛~？禁言/点赞/戳一戳互动插件",
    usage="禁我 / 赞我 / 戳我",
    type="application",
    homepage="https://github.com/Misty02600/nonebot-plugin-actme",
    config=Config,
    supported_adapters={"~onebot.v11"},
)
