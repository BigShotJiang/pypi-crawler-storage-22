from nonebot import get_plugin_config
from pydantic import BaseModel, Field


class Config(BaseModel):
    mute_times: list[int] = Field(
        default=[1, 5, 10, 30],
        description="禁言时间列表（分钟），随机选取。",
    )

    poke_refuse_prob: float = Field(
        default=0.3,
        description="拒绝戳一戳的概率",
    )
    poke_super_prob: float = Field(
        default=0.1,
        description="超级戳一戳的概率",
    )
    poke_more_prob: float = Field(
        default=0.2,
        description="连续戳一戳的概率",
    )


plugin_config = get_plugin_config(Config)
