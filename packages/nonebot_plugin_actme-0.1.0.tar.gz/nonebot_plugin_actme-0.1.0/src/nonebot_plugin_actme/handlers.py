"""命令处理器"""

import asyncio
import random
from typing import Any

from nonebot import on_regex
from nonebot.adapters.onebot.v11 import (
    ActionFailed,
    Bot,
    GroupMessageEvent,
    MessageEvent,
    MessageSegment,
)
from nonebot.log import logger
from nonebot.matcher import Matcher
from nonebot.params import RegexGroup

from .config import plugin_config

mute_times = plugin_config.mute_times


def _extract_target_user_id(event: GroupMessageEvent) -> str | None:
    """从消息中提取目标用户 ID。

    仅支持从 AT 消息段中提取。
    """
    for seg in event.get_message():
        if seg.type == "at" and seg.data.get("qq") and seg.data["qq"] != "all":
            return str(seg.data["qq"])

    return None


# region 禁言

ban = on_regex("^(禁|口|踩)我$")


async def ban_me(bot: Bot, matcher: Matcher, user_id: str, group_id: str) -> None:
    """执行随机禁言。

    NapCat 在 bot 无管理权限或目标为管理员时会返回 failed，
    nonebot-adapter-onebot 会将其转化为 ActionFailed 异常。
    """
    mute_time = random.choice(mute_times)

    try:
        await bot.set_group_ban(
            group_id=int(group_id),
            user_id=int(user_id),
            duration=mute_time * 60,
        )
    except ActionFailed:
        await matcher.send("满足不了你的愿望呢")
        return

    await matcher.send(
        random.choice(
            [
                "理解不能...",
                "真是奇怪的癖好...",
                "不愧是下等生物的请求，咱就满足你这杂鱼吧！",
            ]
        )
    )


@ban.handle()
async def handle_mute(bot: Bot, matcher: Matcher, event: GroupMessageEvent) -> None:
    """处理禁言请求"""
    await ban_me(bot, matcher, str(event.user_id), str(event.group_id))


# endregion

# region 点赞

zan = on_regex("^(超|赞)(市|)我$")
zan_other = on_regex(r"^(超|赞)(市|)(他|她|它|TA|ta)\s*(.*)$")


async def send_likes(bot: Bot, user_id: str) -> int:
    """给指定用户点赞，返回成功次数。"""
    count = 0
    try:
        for _ in range(5):
            await bot.send_like(user_id=int(user_id), times=10)
            count += 10
            await asyncio.sleep(3)
    except Exception:
        pass
    logger.info(f"点了{count}个赞")
    return count


@zan.handle()
async def handle_zan(bot: Bot, matcher: Matcher, event: MessageEvent) -> None:
    """处理自身点赞请求"""
    msg = await matcher.send("正在为你点赞...请稍等", reply_message=True)
    count = await send_likes(bot, str(event.user_id))
    await bot.delete_msg(message_id=msg["message_id"])

    if count != 0:
        await matcher.finish(f"已经给你点了{count}个赞！", reply_message=True)
    else:
        await matcher.finish("我给不了你更多了哟~", reply_message=True)


@zan_other.handle()
async def handle_zan_other(
    bot: Bot, matcher: Matcher, event: GroupMessageEvent
) -> None:
    """处理给他人点赞请求"""
    user_id = _extract_target_user_id(event)
    if user_id is None:
        await matcher.finish("请@目标用户", reply_message=True)

    msg = await matcher.send(
        MessageSegment.at(user_id) + " 正在为你点赞...请稍等", reply_message=True
    )
    count = await send_likes(bot, user_id)
    await bot.delete_msg(message_id=msg["message_id"])
    if count > 0:
        await matcher.finish(
            MessageSegment.at(user_id) + f" 已点了{count}个赞！",
            reply_message=True,
        )
    else:
        await matcher.finish("我给不了他更多了哟~", reply_message=True)


# endregion

# region 戳一戳

poke = on_regex("^(戳|亲|捏|揉)我$")
poke_other = on_regex(r"^(戳|亲|捏|揉)(他|她|它|TA|ta)\s*(.*)$")


async def _send_poke_action(bot: Bot, group_id: str | None, user_id: str) -> None:
    """发送单个戳一戳"""
    if group_id:
        await bot.send_poke(group_id=int(group_id), user_id=int(user_id))
    else:
        await bot.send_poke(user_id=int(user_id))


async def poke_user(
    bot: Bot, matcher: Matcher, group_id: str | None, user_id: str, action: str
) -> None:
    """执行戳一戳逻辑，含拒绝/超级/普通三种随机分支。"""
    rand_value = random.random()
    if rand_value < plugin_config.poke_refuse_prob:
        logger.success("拒绝戳戳")
        await matcher.send(random.choice(["我就不~", "下次一定"]))
    elif rand_value < plugin_config.poke_super_prob + plugin_config.poke_refuse_prob:
        logger.success("超级戳戳")
        for _ in range(10):
            await _send_poke_action(bot, group_id, user_id)
        await asyncio.sleep(1)
        await matcher.send(f"疾风连{action}！")
    else:
        logger.success("普通戳戳")
        await matcher.send(f"我{action}！")
        await _send_poke_action(bot, group_id, user_id)
        if random.random() < plugin_config.poke_more_prob:
            await asyncio.sleep(3)
            await matcher.send(f"我再{action}！")
            await _send_poke_action(bot, group_id, user_id)
            if random.random() < plugin_config.poke_more_prob:
                await asyncio.sleep(3)
                await matcher.send(f"我还{action}！")
                await _send_poke_action(bot, group_id, user_id)


@poke.handle()
async def handle_poke(
    bot: Bot, matcher: Matcher, event: MessageEvent, foo: tuple[Any, ...] = RegexGroup()
) -> None:
    """处理戳自己请求"""
    action = foo[0]
    user_id = event.user_id

    try:
        group_id = str(event.group_id)  # type: ignore[attr-defined]
    except AttributeError:
        group_id = None

    await poke_user(bot, matcher, group_id, str(user_id), action)


@poke_other.handle()
async def handle_poke_other(
    bot: Bot,
    matcher: Matcher,
    event: GroupMessageEvent,
    foo: tuple[Any, ...] = RegexGroup(),
) -> None:
    """处理戳他人请求"""
    action = foo[0]
    group_id = event.group_id

    user_id = _extract_target_user_id(event)
    if user_id is None:
        await poke_other.finish("请@目标用户", reply_message=True)

    await poke_user(bot, matcher, str(group_id), user_id, action)


# endregion
