from nonebot.plugin import PluginMetadata

__plugin_meta__ = PluginMetadata(
    name="The Betterest Mute Cat",
    description="极致的禁言猫猫 - 功能强大的QQ群禁言插件，支持定时禁言、全员禁言、解禁全员、禁我等功能",
    usage="""
📖 猫猫教你用禁言功能喵~
═══════════════════
▎禁言别人
[@我] 禁言 @猫猫 [时长]
比如：5、5分钟、1小时、30s都可以哦

▎取消禁言
[@我] 取消 @猫猫
（解除/取消/解禁 都行喵）

▎全员禁言
[@我] 全员禁言 [时长]
不加时长就一直禁言，加时间就代表定时

▎解禁全员
[@我] 解禁全员 / 取消全员 / 解除全员
（会解除全员禁言+所有个人禁言）

▎禁自己
[@我] 禁我
随机禁言自己 1/3/5 分钟，也可能不禁言喵~

▎定时禁言
[@我] 禁言 @猫猫 14:30 15:30
[@我] 禁言 @猫猫 14:30 1小时

▎查看状态
[@我] 查看状态
可以看看谁被禁言啦~
    """,
    type="application",
    homepage="https://github.com/binglang001/nonebot-plugin-mute-cat",
    config=None,
    supported_adapters={"~onebot.v11"},
    extra={
        "author": "binglang",
        "priority": 1,
        "version": "1.0.0",
    }
)

import re
import time
import random
import json
from datetime import datetime, timedelta
from typing import List, Optional, Tuple, Dict, Any
from pathlib import Path
from nonebot import on_message, require
from nonebot.adapters.onebot.v11 import Bot, GroupMessageEvent, Message, MessageSegment
from nonebot.log import logger
import pytz

# ==================== 配置 ====================
require("nonebot_plugin_apscheduler")
from nonebot_plugin_apscheduler import scheduler

MUTE_DEFAULT_MINUTES = 5
BEIJING_TZ = pytz.timezone('Asia/Shanghai')
MUTE_SELF_OPTIONS = [1, 3, 5, 0]  # 禁我功能的随机选项：1分钟、3分钟、5分钟、不禁言

# ==================== 持久化存储 ====================

class SimpleStorage:
    """简单的 JSON 文件存储"""
    
    def __init__(self, plugin_name: str):
        self.plugin_name = plugin_name
        # 在项目根目录创建 data 文件夹
        self.data_dir = Path("data") / plugin_name
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.at_required_file = self.data_dir / "at_required.json"
        self.states_file = self.data_dir / "group_states.json"
        
        logger.debug(f"存储目录: {self.data_dir.absolute()}")
    
    def save_at_required(self, data: Dict[int, bool]):
        """保存@开关状态"""
        try:
            serializable = {str(k): v for k, v in data.items()}
            self.at_required_file.write_text(
                json.dumps(serializable, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )
            logger.debug(f"@开关状态已保存到: {self.at_required_file}")
        except Exception as e:
            logger.error(f"保存@开关状态失败: {e}")
    
    def load_at_required(self) -> Dict[int, bool]:
        """加载@开关状态"""
        try:
            if not self.at_required_file.exists():
                return {}
            data = json.loads(self.at_required_file.read_text(encoding="utf-8"))
            result = {int(k): v for k, v in data.items()}
            return result
        except Exception as e:
            logger.error(f"加载@开关状态失败: {e}")
            return {}
    
    def save_states(self, data: Dict[int, Dict]):
        """保存群状态"""
        try:
            simplified = {}
            for group_id, state in data.items():
                whole_mute = state["whole_mute"]
                simplified[str(group_id)] = {
                    "whole_mute": {
                        "enabled": whole_mute["enabled"],
                        "end_time": whole_mute["end_time"].isoformat() if whole_mute["end_time"] else None,
                        "duration": whole_mute["duration"]  # None 表示永久
                    },
                    "individual_mutes": {
                        str(uid): {
                            "end_time": info["end_time"].isoformat() if info["end_time"] else None,
                            "duration": info["duration"]
                        }
                        for uid, info in state["individual_mutes"].items()
                    }
                }
            self.states_file.write_text(
                json.dumps(simplified, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )
        except Exception as e:
            logger.error(f"保存群状态失败: {e}")

    def load_states(self) -> Dict[int, Dict]:
        """加载群状态"""
        try:
            if not self.states_file.exists():
                return {}
            data = json.loads(self.states_file.read_text(encoding="utf-8"))
            result = {}
            for group_id_str, state in data.items():
                group_id = int(group_id_str)
                
                # 恢复全员禁言状态
                whole_mute = state["whole_mute"]
                end_time = None
                if whole_mute["end_time"]:
                    try:
                        end_time = datetime.fromisoformat(whole_mute["end_time"])
                    except:
                        pass
                
                # 恢复个人禁言状态
                individual_mutes = {}
                for uid_str, info in state["individual_mutes"].items():
                    user_end_time = None
                    if info["end_time"]:
                        try:
                            user_end_time = datetime.fromisoformat(info["end_time"])
                        except:
                            pass
                    individual_mutes[int(uid_str)] = {
                        "end_time": user_end_time,
                        "duration": info["duration"]
                    }
                
                result[group_id] = {
                    "whole_mute": {
                        "enabled": whole_mute["enabled"],
                        "end_time": end_time,
                        "duration": whole_mute["duration"]  # None 表示永久
                    },
                    "individual_mutes": individual_mutes,
                    "tasks": {}
                }
            return result
        except Exception as e:
            logger.error(f"加载群状态失败: {e}")
            return {}

# ==================== 初始化存储 ====================
storage = SimpleStorage("nonebot_plugin_mute_cat")

# ==================== 全局状态存储 ====================
group_states: Dict[int, Dict] = storage.load_states()
at_required: Dict[int, bool] = storage.load_at_required()

logger.debug(f"已加载 {len(group_states)} 个群的状态")
logger.debug(f"已加载 {len(at_required)} 个群的@开关状态")

# ==================== 响应器 ====================
mute_matcher = on_message(priority=1, block=True)

# ==================== 工具函数 ====================

def parse_at_targets(message: str) -> List[str]:
    """解析被@的多个用户"""
    pattern = r'\[CQ:at,qq=(\d+)\]'
    return re.findall(pattern, message)

def format_at_message(user_ids: List[int]) -> str:
    """格式化@消息，使用 MessageSegment"""
    if not user_ids:
        return ""
    if len(user_ids) == 1:
        return str(MessageSegment.at(user_ids[0]))
    else:
        msg = Message()
        for i, uid in enumerate(user_ids):
            if i > 0:
                msg += " "
            msg += MessageSegment.at(uid)
        return str(msg)

def parse_duration(text: str) -> Optional[int]:
    """解析持续时间，返回分钟数"""
    if not text or not isinstance(text, str):
        return None
    
    text = text.strip()
    logger.debug(f"解析时长文本: {text}")
    
    # 纯数字（默认分钟）
    if text.isdigit():
        return int(text)
    
    # 单位映射表 (单位 -> 转换为分钟的倍数)
    units = {
        # 秒
        '秒': 1/60, 's': 1/60, 'sec': 1/60,
        # 分钟
        '分钟': 1, '分': 1, 'm': 1, 'min': 1,
        # 小时
        '小时': 60, '时': 60, 'h': 60,
    }
    
    # 匹配数字和单位（支持 "5m"、"5分钟"、"5 min" 等格式）
    for unit, multiplier in units.items():
        # 匹配模式：数字 + 可能的空格 + 单位
        pattern = rf'(\d+)\s*{unit}'
        match = re.search(pattern, text)
        if match:
            minutes = int(match.group(1)) * multiplier
            logger.debug(f"匹配到单位 {unit}, 数字 {match.group(1)}, 计算结果 {minutes} 分钟")
            
            if minutes == int(minutes):
                result = int(minutes)
            else:
                if multiplier < 1:
                    result = max(1, int(minutes) + 1)
                else:
                    result = round(minutes)
            
            logger.debug(f"最终结果: {result} 分钟")
            return result
    
    # 如果没有匹配到任何单位，但包含数字，尝试只提取数字
    number_match = re.search(r'(\d+)', text)
    if number_match:
        logger.debug(f"未匹配到单位，只提取数字: {number_match.group(1)}")
        return int(number_match.group(1))
    
    return None

def parse_time_range(text: str) -> Optional[Tuple[datetime, int]]:
    """解析时间范围"""
    if not text:
        return None
    
    now = datetime.now(BEIJING_TZ)
    
    # 12:00~13:00 或 12:00-13:00
    range_match = re.search(
        r'(\d{1,2})[:：](\d{2})\s*[~\-]\s*(\d{1,2})[:：](\d{2})', 
        text
    )
    if range_match:
        start_h, start_m, end_h, end_m = map(int, range_match.groups())
        start_time = now.replace(hour=start_h, minute=start_m, second=0, microsecond=0)
        end_time = now.replace(hour=end_h, minute=end_m, second=0, microsecond=0)
        
        if start_time <= now:
            start_time += timedelta(days=1)
        if end_time <= start_time:
            end_time += timedelta(days=1)
        
        duration = int((end_time - start_time).total_seconds() / 60)
        return start_time, duration
    
    # 12:00 13:00
    time_pair = re.findall(r'(\d{1,2})[:：](\d{2})', text)
    if len(time_pair) == 2:
        start_h, start_m = time_pair[0]
        end_h, end_m = time_pair[1]
        start_h, start_m = int(start_h), int(start_m)
        end_h, end_m = int(end_h), int(end_m)
        
        start_time = now.replace(hour=start_h, minute=start_m, second=0, microsecond=0)
        end_time = now.replace(hour=end_h, minute=end_m, second=0, microsecond=0)
        
        if start_time <= now:
            start_time += timedelta(days=1)
        if end_time <= start_time:
            end_time += timedelta(days=1)
        
        duration = int((end_time - start_time).total_seconds() / 60)
        return start_time, duration
    
    # 12:00 30分钟
    time_duration_match = re.search(
        r'(\d{1,2})[:：](\d{2})\s+(\d+(?:\s*(?:分钟|分|min|m|小时|时|h|秒|s)?)?)', 
        text
    )
    if time_duration_match:
        h = int(time_duration_match.group(1))
        m = int(time_duration_match.group(2))
        duration_str = time_duration_match.group(3)
        
        duration = parse_duration(duration_str)
        if duration:
            start_time = now.replace(hour=h, minute=m, second=0, microsecond=0)
            if start_time <= now:
                start_time += timedelta(days=1)
            return start_time, duration
    
    # 只有开始时间（如 12:00），默认禁言5分钟
    only_time_match = re.search(r'^(\d{1,2})[:：](\d{2})$', text.strip())
    if only_time_match:
        h = int(only_time_match.group(1))
        m = int(only_time_match.group(2))
        start_time = now.replace(hour=h, minute=m, second=0, microsecond=0)
        if start_time <= now:
            start_time += timedelta(days=1)
        return start_time, MUTE_DEFAULT_MINUTES
    
    return None

def generate_job_id(group_id: int, prefix: str = "mute", unique: str = "") -> str:
    """生成唯一的任务ID"""
    timestamp = int(time.time() * 1000)
    if unique:
        return f"{prefix}_{group_id}_{unique}_{timestamp}"
    return f"{prefix}_{group_id}_{timestamp}"

def is_command(text: str, keywords: List[str]) -> bool:
    """判断是否是命令（需要是完整词语匹配）"""
    # 将消息按空白符分割成词语
    words = text.split()
    return any(word in words for word in keywords)

def is_cancel_command(text: str) -> bool:
    """判断是否为取消/解除/解禁命令（完整词语匹配）"""
    cancel_keywords = ["解除", "取消", "解禁"]
    return is_command(text, cancel_keywords)

def is_mute_command(text: str) -> bool:
    """判断是否为禁言命令（完整词语匹配）"""
    mute_keywords = ["禁言", "全员禁言"]
    return is_command(text, mute_keywords)

def is_self_mute_command(text: str) -> bool:
    """判断是否为禁我命令"""
    return text.strip() == "禁我"

def is_whole_mute_command(text: str) -> bool:
    """判断是否为全员禁言命令"""
    # 移除空格以便判断
    text_no_spaces = text.replace(" ", "")
    
    # 匹配 "全员禁言"、"全体禁言"、"始终禁言" 等
    mute_combinations = [
        "全员禁言", "全体禁言", "始终禁言",
        "全员", "全体", "始终"
    ]
    
    # 检查是否以这些词开头（后面可能跟时间参数）
    for combo in mute_combinations:
        if text_no_spaces.startswith(combo):
            return True
    
    # 检查是否包含关键词且后面可能跟时间
    keywords = ["全体成员", "全员", "所有人", "全体", "始终"]
    words = text.split()
    
    # 如果第一个词是关键词，可能是 "全员 5分钟" 这样的格式
    if words and words[0] in keywords:
        return True
    
    return False

def is_whole_unmute_command(text: str) -> bool:
    """判断是否为解禁全员命令"""
    # 匹配各种解禁全员的表达方式
    unmute_patterns = [
        r"^解禁\s*(全员|全体|所有人)$",
        r"^取消\s*(全员|全体|所有人|全员禁言)$",
        r"^解除\s*(全员|全体|所有人|全员禁言)$",
        r"^(全员|全体|所有人)\s*解禁$",
        r"^(全员|全体|所有人|全员禁言)\s*取消$",
        r"^(全员|全体|所有人|全员禁言)\s*解除$"
    ]
    
    text_no_spaces = text.replace(" ", "")
    
    # 检查各种组合
    for pattern in unmute_patterns:
        if re.search(pattern, text):
            return True
    
    # 检查无空格版本
    unmute_combinations = [
        "解禁全员", "解禁全体", "解禁所有人",
        "取消全员", "取消全体", "取消所有人", "取消全员禁言",
        "解除全员", "解除全体", "解除所有人", "解除全员禁言", "关闭全员禁言", "解除始终禁言", "关闭始终禁言", "解除全体禁言", "关闭全体禁言",
        "全员解禁", "全体解禁", "所有人解禁",
        "全员取消", "全体取消", "所有人取消", "全员禁言取消", "始终禁言取消", "全体禁言取消",
        "全员解除", "全体解除", "所有人解除", "全员禁言解除", "全员禁言关闭", "全体禁言解除", "全体禁言关闭", "始终禁言解除", "始终禁言关闭"
    ]
    
    return text_no_spaces in unmute_combinations

def format_time_display(dt: datetime) -> str:
    """格式化时间显示"""
    return dt.strftime("%H:%M")

def format_duration_display(minutes: int) -> str:
    """格式化时长显示"""
    if minutes < 60:
        return f"{minutes}min"
    else:
        hours = minutes // 60
        mins = minutes % 60
        if mins == 0:
            return f"{hours}h"
        else:
            return f"{hours}h{mins}min"

def init_group_state(group_id: int):
    """初始化群状态"""
    if group_id not in group_states:
        group_states[group_id] = {
            "whole_mute": {
                "enabled": False,
                "end_time": None,
                "duration": 0
            },
            "individual_mutes": {},
            "tasks": {}
        }

def find_tasks_for_target(group_id: int, target_key: str) -> List[str]:
    """查找指定目标的所有定时任务"""
    if group_id not in group_states:
        return []
    
    task_ids = []
    for job_id, task_info in group_states[group_id]["tasks"].items():
        if task_info.get("target_key") == target_key:
            task_ids.append(job_id)
    
    return task_ids

def cancel_tasks_for_target(group_id: int, target_key: str) -> bool:
    """取消指定目标的所有定时任务"""
    if group_id not in group_states:
        return False
    
    cancelled = False
    for job_id, task_info in list(group_states[group_id]["tasks"].items()):
        if task_info.get("target_key") == target_key:
            try:
                scheduler.remove_job(job_id)
            except:
                pass
            del group_states[group_id]["tasks"][job_id]
            cancelled = True
    
    return cancelled

# ==================== 状态管理函数 ====================

async def update_mute_state(group_id: int, user_id: int, duration: int):
    """更新单个禁言状态"""
    init_group_state(group_id)
    end_time = datetime.now(BEIJING_TZ) + timedelta(minutes=duration)
    group_states[group_id]["individual_mutes"][user_id] = {
        "end_time": end_time,
        "duration": duration
    }
    storage.save_states(group_states)

async def update_whole_mute_state(group_id: int, enabled: bool, duration: Optional[int] = None):
    """更新全员禁言状态
    Args:
        duration: 禁言时长，None 表示永久
    """
    init_group_state(group_id)
    group_states[group_id]["whole_mute"]["enabled"] = enabled
    if enabled:
        if duration is None:
            # 永久禁言
            group_states[group_id]["whole_mute"]["end_time"] = None
            group_states[group_id]["whole_mute"]["duration"] = None
        else:
            # 定时禁言
            end_time = datetime.now(BEIJING_TZ) + timedelta(minutes=duration)
            group_states[group_id]["whole_mute"]["end_time"] = end_time
            group_states[group_id]["whole_mute"]["duration"] = duration
    else:
        group_states[group_id]["whole_mute"]["end_time"] = None
        group_states[group_id]["whole_mute"]["duration"] = 0
    storage.save_states(group_states)

async def remove_mute_state(group_id: int, user_id: int):
    """移除单个禁言状态"""
    if group_id in group_states:
        if user_id in group_states[group_id]["individual_mutes"]:
            del group_states[group_id]["individual_mutes"][user_id]
            storage.save_states(group_states)

async def add_task_record(group_id: int, job_id: str, task_type: str, targets: List[int], 
                          execute_time: datetime, duration: int = 0, target_key: str = ""):
    """记录定时任务"""
    init_group_state(group_id)
    group_states[group_id]["tasks"][job_id] = {
        "type": task_type,
        "targets": targets,
        "time": execute_time,
        "duration": duration,
        "target_key": target_key
    }

async def remove_task_record(group_id: int, job_id: str):
    """移除任务记录"""
    if group_id in group_states and job_id in group_states[group_id]["tasks"]:
        del group_states[group_id]["tasks"][job_id]

async def is_group_admin(bot: Bot, group_id: int, user_id: int) -> bool:
    """检查用户是否为群管理员或群主"""
    try:
        member_info = await bot.get_group_member_info(
            group_id=group_id,
            user_id=user_id,
            no_cache=True  # 不使用缓存，获取最新信息
        )
        role = member_info.get('role', 'member')
        # role 可能的值: owner(群主), admin(管理员), member(普通成员)
        return role in ['owner', 'admin']
    except Exception as e:
        logger.error(f"获取群成员信息失败: {e}")
        # 如果获取失败，保守起见假设不是管理员
        return False

# ==================== 执行函数 ====================

async def execute_mute(bot: Bot, group_id: int, user_ids: List[int], duration: int, job_id: str = None):
    """执行禁言"""
    try:
        success_count = 0
        fail_list = []
        success_users = []
        admin_users = []  # 记录被检测出的管理员
        
        for user_id in user_ids:
            try:
                # 先检查是否为群管理员
                is_admin = await is_group_admin(bot, group_id, user_id)
                if is_admin:
                    admin_users.append(user_id)
                    fail_list.append(f"{user_id}(人家不能禁言群管理啦~)")
                    continue
                
                # 不是管理员，执行禁言
                await bot.set_group_ban(
                    group_id=group_id,
                    user_id=user_id,
                    duration=duration * 60
                )
                success_count += 1
                success_users.append(user_id)
                await update_mute_state(group_id, user_id, duration)
                
            except Exception as e:
                # 提取错误信息
                error_msg = str(e)
                if "1200" in error_msg:
                    fail_list.append(f"{user_id}(呜呜权限不够...)")
                elif "1202" in error_msg:
                    fail_list.append(f"{user_id}(这个人不在群里呢)")
                elif "1203" in error_msg:
                    fail_list.append(f"{user_id}(不能欺负群主大人)")
                elif "1204" in error_msg:
                    fail_list.append(f"{user_id}(不能禁言管理喵)")
                elif "1211" in error_msg:
                    fail_list.append(f"{user_id}(已经被禁言啦)")
                else:
                    fail_list.append(f"{user_id}({error_msg})")
        
        # 构建回复消息
        if success_count > 0:
            end_time = datetime.now(BEIJING_TZ) + timedelta(minutes=duration)
            
            msg = Message()
            msg.append("呜...禁言了 ")
            msg.append(format_at_message(success_users))
            msg.append(f" {format_duration_display(duration)} 呢~\n")
            msg.append(f"* {format_time_display(end_time)} 才能说话哦 *")
            
            if admin_users:
                admin_msg = "、".join([format_at_message([uid]) for uid in admin_users])
                msg.append(f"\n⚠️ 诶嘿~群管理不能禁言呢 {admin_msg}")
            
            if fail_list:
                msg.append(f"\n❌ 出错了喵... {', '.join(fail_list)}")
            
            await bot.send_group_msg(group_id=group_id, message=msg)
        elif admin_users:
            # 全是管理员的情况
            admin_msg = "、".join([format_at_message([uid]) for uid in admin_users])
            await bot.send_group_msg(
                group_id=group_id,
                message=f"⚠️ 诶嘿~群管理不能禁言呢 {admin_msg}"
            )
        elif fail_list:
            await bot.send_group_msg(
                group_id=group_id,
                message=f"❌ 禁言失败啦...{', '.join(fail_list)}"
            )
        
        if job_id:
            await remove_task_record(group_id, job_id)
        
    except Exception as e:
        logger.error(f"禁言执行失败: {e}")
        if job_id:
            await remove_task_record(group_id, job_id)

async def execute_whole_mute(bot: Bot, group_id: int, duration: Optional[int] = None, job_id: str = None):
    """执行全员禁言
    Args:
        duration: 禁言时长（分钟），None 表示永久禁言，有值表示定时禁言（需要APScheduler）
    """
    try:
        logger.debug(f"执行全员禁言，时长: {duration} 分钟")
        
        # 开启全员禁言
        await bot.set_group_whole_ban(group_id=group_id, enable=True)
        
        if duration is None or duration <= 0:
            # 永久禁言
            logger.debug("永久禁言")
            await update_whole_mute_state(group_id, True, None)
            await bot.send_group_msg(
                group_id=group_id,
                message="⌈全员禁言⌋ 开始啦~ 大家要一直安静到天荒地老喵~"
            )
        else:
            # 定时禁言 - 需要APScheduler定时解除
            logger.debug(f"定时禁言 {duration} 分钟")
            await update_whole_mute_state(group_id, True, duration)
            
            end_time = datetime.now(BEIJING_TZ) + timedelta(minutes=duration)
            
            # 添加定时解除任务
            unmute_job_id = generate_job_id(group_id, "whole_unmute")
            logger.debug(f"添加定时解除任务: {unmute_job_id}, 解除时间: {end_time}")
            
            scheduler.add_job(
                func=execute_whole_unmute,
                trigger="date",
                run_date=end_time,
                args=[bot, group_id, unmute_job_id],
                id=unmute_job_id,
                replace_existing=False
            )
            await add_task_record(group_id, unmute_job_id, "whole_unmute", [], end_time, 0, f"whole_unmute_{group_id}")
            
            msg = f"⌈全员禁言⌋ {format_duration_display(duration)} 哦~\n"
            msg += f"* {format_time_display(end_time)} 才能说话喵 *"
            
            await bot.send_group_msg(group_id=group_id, message=msg)
        
        if job_id:
            await remove_task_record(group_id, job_id)
        
    except Exception as e:
        error_msg = str(e)
        if "1200" in error_msg:
            msg = "❌ 全员禁言失败：呜...人家权限不够呢"
        elif "1287" in error_msg:
            msg = "❌ 全员禁言失败：人家不是管理员啦~"
        else:
            msg = f"❌ 全员禁言失败：{error_msg}"
        
        await bot.send_group_msg(group_id=group_id, message=msg)
        if job_id:
            await remove_task_record(group_id, job_id)

async def execute_cancel(bot: Bot, group_id: int, user_ids: List[int], is_whole: bool = False):
    """执行取消/解除/解禁操作"""
    try:
        if is_whole:
            # 先检查是否处于全员禁言状态
            is_whole_muted = group_id in group_states and group_states[group_id]["whole_mute"]["enabled"]
            
            # 解除所有个人禁言
            success_count = 0
            fail_list = []
            success_users = []
            
            # 获取所有被禁言的用户
            muted_users = list(group_states.get(group_id, {}).get("individual_mutes", {}).keys())
            
            for user_id in muted_users:
                try:
                    await bot.set_group_ban(
                        group_id=group_id,
                        user_id=user_id,
                        duration=0
                    )
                    success_count += 1
                    success_users.append(user_id)
                    await remove_mute_state(group_id, user_id)
                except Exception as e:
                    error_msg = str(e)
                    if "1200" in error_msg:
                        fail_list.append(f"{user_id}(权限不够啦)")
                    elif "1202" in error_msg:
                        fail_list.append(f"{user_id}(找不到这个人)")
                    else:
                        fail_list.append(f"{user_id}({error_msg})")
            
            # 如果处于全员禁言状态，关闭全员禁言
            whole_mute_closed = False
            if is_whole_muted:
                try:
                    await bot.set_group_whole_ban(group_id=group_id, enable=False)
                    whole_mute_closed = True
                    await update_whole_mute_state(group_id, False)
                except Exception as e:
                    logger.warning(f"关闭全员禁言失败: {e}")
            
            # 取消所有相关的定时任务
            target_key = f"whole_mute_{group_id}"
            cancel_tasks_for_target(group_id, target_key)
            target_key = f"whole_unmute_{group_id}"
            cancel_tasks_for_target(group_id, target_key)
            
            # 构建回复消息
            msg = Message()
            
            if success_count > 0:
                msg.append("解除了 ")
                msg.append(format_at_message(success_users))
                if whole_mute_closed:
                    msg.append("\n⌈全员禁言⌋ 也关掉啦~")
            else:
                if whole_mute_closed:
                    msg.append("⌈全员禁言⌋ 关掉啦~")
                elif not is_whole_muted:
                    # 既没有个人被禁言，也没有全员禁言
                    msg.append("诶？现在本来就没有全员禁言呢")
                else:
                    msg.append("现在没有成员被禁言喵~")
            
            if fail_list:
                msg.append(f"\n❌ 出错了... {', '.join(fail_list)}")
            
            await bot.send_group_msg(group_id=group_id, message=msg)
        else:
            success_count = 0
            fail_list = []
            success_users = []
            
            for user_id in user_ids:
                try:
                    await bot.set_group_ban(
                        group_id=group_id,
                        user_id=user_id,
                        duration=0
                    )
                    success_count += 1
                    success_users.append(user_id)
                    await remove_mute_state(group_id, user_id)
                    
                    target_key = f"mute_{'_'.join(map(str, sorted([user_id])))}"
                    cancel_tasks_for_target(group_id, target_key)
                    target_key = f"unmute_{'_'.join(map(str, sorted([user_id])))}"
                    cancel_tasks_for_target(group_id, target_key)
                    
                except Exception as e:
                    error_msg = str(e)
                    if "1200" in error_msg:
                        fail_list.append(f"{user_id}(权限不够啦)")
                    elif "1202" in error_msg:
                        fail_list.append(f"{user_id}(找不到这个人)")
                    elif "1203" in error_msg:
                        fail_list.append(f"{user_id}(不能欺负群主大人)")
                    elif "1204" in error_msg:
                        fail_list.append(f"{user_id}(不能禁言管理喵)")
                    else:
                        fail_list.append(f"{user_id}({error_msg})")
            
            if success_count > 0:
                msg = Message()
                msg.append(format_at_message(success_users))
                msg.append(" 可以说话啦~")
                
                if fail_list:
                    msg.append(f"\n❌ 出错了... {', '.join(fail_list)}")
                
                await bot.send_group_msg(group_id=group_id, message=msg)
            elif fail_list:
                await bot.send_group_msg(
                    group_id=group_id,
                    message=f"❌ 解除禁言失败啦...{', '.join(fail_list)}"
                )
        
    except Exception as e:
        logger.error(f"取消操作失败: {e}")
        await bot.send_group_msg(
            group_id=group_id, 
            message=f"❌ 操作失败了喵...{str(e)}"
        )

async def execute_self_mute(bot: Bot, group_id: int, user_id: int):
    """执行禁我功能"""
    try:
        # 先检查自己是否为群管理
        is_admin = await is_group_admin(bot, group_id, user_id)
        if is_admin:
            await bot.send_group_msg(
                group_id=group_id,
                message="你是群管理呢，人家不能禁言你啦~"
            )
            return
        
        # 随机选择时长
        duration = random.choice(MUTE_SELF_OPTIONS)
        
        if duration == 0:
            # 不禁言
            await bot.send_group_msg(
                group_id=group_id,
                message="今天心情好，就不禁言你了喵~"
            )
            return
        
        # 执行禁言
        await bot.set_group_ban(
            group_id=group_id,
            user_id=user_id,
            duration=duration * 60
        )
        
        await update_mute_state(group_id, user_id, duration)
        
        end_time = datetime.now(BEIJING_TZ) + timedelta(minutes=duration)
        
        msg = Message()
        msg.append("满足你喵~\n禁言")
        msg.append(format_at_message([user_id]))
        msg.append(f" {format_duration_display(duration)}\n")
        msg.append(f"* {format_time_display(end_time)} 结束 *")
        
        await bot.send_group_msg(group_id=group_id, message=msg)
        
    except Exception as e:
        error_msg = str(e)
        if "1200" in error_msg:
            msg = "❌ 禁言失败：呜...人家权限不够呢"
        elif "1202" in error_msg:
            msg = "❌ 禁言失败：找不到这个人啦"
        else:
            msg = f"❌ 禁言失败：{error_msg}"
        
        await bot.send_group_msg(group_id=group_id, message=msg)


async def execute_whole_unmute(bot: Bot, group_id: int, job_id: str = None):
    """自动解除全员禁言（定时任务专用）"""
    try:
        logger.debug(f"执行定时解除全员禁言，group_id={group_id}, job_id={job_id}")
        
        # 检查是否已被手动取消
        if group_id in group_states and not group_states[group_id]["whole_mute"]["enabled"]:
            logger.debug("全员禁言已被手动取消，跳过自动解除")
            if job_id:
                await remove_task_record(group_id, job_id)
            return
        
        # 解除全员禁言
        await bot.set_group_whole_ban(group_id=group_id, enable=False)
        await update_whole_mute_state(group_id, False)
        
        await bot.send_group_msg(
            group_id=group_id,
            message="⌈全员禁言⌋ 结束啦~大家可以说话咯"
        )
        
        if job_id:
            await remove_task_record(group_id, job_id)
        
    except Exception as e:
        logger.error(f"解除全员禁言失败: {e}")
        if job_id:
            await remove_task_record(group_id, job_id)

# ==================== 主处理函数 ====================

@mute_matcher.handle()
async def handle_message(bot: Bot, event: GroupMessageEvent):
    """处理所有消息，根据@开关决定是否响应"""
    if not isinstance(event, GroupMessageEvent):
        return
    
    raw_msg = event.get_plaintext().strip()
    msg_str = str(event.message)
    group_id = event.group_id
    user_id = event.get_user_id()
    
    logger.debug(f"收到消息: {raw_msg}")
    logger.debug(f"消息原始内容: {msg_str}")
    
    # 使用 event.is_tome() 检测是否@机器人
    is_at = event.is_tome()
    logger.debug(f"是否@机器人 (is_tome): {is_at}")
    
    # 首先检查是否是@开关命令（这些命令始终需要@，不受模式影响）
    if is_at:
        logger.debug("检测到@机器人")
        if "开启at" in raw_msg or "开启@" in raw_msg:
            at_required[group_id] = True
            storage.save_at_required(at_required)
            await mute_matcher.finish("✅ 好啦~以后要@人家才能用命令喵~")
        elif "关闭at" in raw_msg or "关闭@" in raw_msg:
            at_required[group_id] = False
            storage.save_at_required(at_required)
            await mute_matcher.finish("✅ 知道啦~现在可以直接用命令不用@人家咯")
    
    # 检查是否需要@才能触发
    if at_required.get(group_id, True):  # 默认需要@
        if not is_at:
            logger.debug("需要@模式但未@机器人，忽略")
            return
    
    # 帮助功能
    if "帮助" in raw_msg:
        at_status = "需要@人家" if at_required.get(group_id, True) else "不需要@人家"
        help_text = (
            "📖 人家来教你用禁言功能喵~\n"
            "═══════════════════\n"
            f"📌 现在呢：{at_status}\n\n"
            "▎@开关（要@人家才行喵）\n"
            "@我 开启at  - 开启需要@模式\n"
            "@我 关闭at  - 关闭需要@模式\n\n"
            "▎禁言别人\n"
            "[@我] 禁言 @人家 [时长]\n"
            "比如：5、5分钟、1小时、30s都可以哦\n\n"
            "▎取消禁言\n"
            "[@我] 取消 @人家\n"
            "（解除/取消/解禁 都行喵）\n\n"
            "▎全员禁言\n"
            "[@我] 全员禁言 [时长]\n"
            "不加时长就一直禁言，加时间就代表定时\n\n"
            "▎解禁全员\n"
            "[@我] 解禁全员\n"
            "[@我] 取消全员\n"
            "[@我] 解除全员\n"
            "[@我] 解除所有人\n"
            "（会解除全员禁言+所有个人禁言）\n\n"
            "▎禁自己\n"
            "[@我] 禁我\n"
            "随机禁言自己 1/3/5 分钟，也可能不禁言喵~\n\n"
            "▎定时禁言\n"
            "[@我] 禁言 @人家 14:30 15:30\n"
            "[@我] 禁言 @人家 14:30 1小时\n"
            "[@我] 禁言 @人家 14:30（默认5分钟）\n\n"
            "▎查看状态\n"
            "[@我] 查看状态\n"
            "可以看看谁被禁言啦~"
        )
        await mute_matcher.finish(help_text)
        return
    
    # 查看状态
    if "查看状态" in raw_msg:
        init_group_state(group_id)
        state = group_states[group_id]
        now = datetime.now(BEIJING_TZ)
        
        msg = Message("📊 这里是群状态喵~\n")
        msg.append("═══════════════════\n")
        
        at_status = "需要@人家" if at_required.get(group_id, True) else "不需要@人家"
        msg.append(f"📌 触发模式：{at_status}\n")
        
        if state["whole_mute"]["enabled"]:
            if state["whole_mute"]["duration"] is None:
                msg.append("👥 全员禁言中（永久...）\n")
            else:
                end_time = state["whole_mute"]["end_time"]
                if end_time and end_time > now:
                    remaining = int((end_time - now).total_seconds() / 60)
                    remaining_seconds = int((end_time - now).total_seconds())
                    
                    if remaining_seconds < 60:
                        time_left = f"{remaining_seconds}秒"
                    elif remaining_seconds < 3600:
                        minutes = remaining_seconds // 60
                        seconds = remaining_seconds % 60
                        if seconds == 0:
                            time_left = f"{minutes}分钟"
                        else:
                            time_left = f"{minutes}分{seconds}秒"
                    else:
                        hours = remaining_seconds // 3600
                        minutes = (remaining_seconds % 3600) // 60
                        if minutes == 0:
                            time_left = f"{hours}小时"
                        else:
                            time_left = f"{hours}小时{minutes}分钟"
                    
                    msg.append(f"👥 全员禁言中\n  还有 {time_left} 就能说话啦~\n")
                else:
                    msg.append("👥 全员禁言中（永久...）\n")
        else:
            msg.append("👥 全员禁言：没有开哦\n")
        
        if state["individual_mutes"]:
            msg.append("\n👤 被禁言的可怜孩子：\n")
            for user_id, info in state["individual_mutes"].items():
                if info["end_time"] and info["end_time"] > now:
                    remaining = int((info["end_time"] - now).total_seconds() / 60)
                    remaining_seconds = int((info["end_time"] - now).total_seconds())
                    
                    if remaining_seconds < 60:
                        time_left = f"{remaining_seconds}秒"
                    elif remaining_seconds < 3600:
                        minutes = remaining_seconds // 60
                        seconds = remaining_seconds % 60
                        if seconds == 0:
                            time_left = f"{minutes}分钟"
                        else:
                            time_left = f"{minutes}分{seconds}秒"
                    else:
                        hours = remaining_seconds // 3600
                        minutes = (remaining_seconds % 3600) // 60
                        if minutes == 0:
                            time_left = f"{hours}小时"
                        else:
                            time_left = f"{hours}小时{minutes}分钟"
                    
                    msg.append("  ")
                    msg.append(MessageSegment.at(user_id))
                    msg.append(f" 还要等 {time_left}\n")
        else:
            msg.append("\n👤 没有被禁言的可怜孩子呢\n")
        
        if state["tasks"]:
            msg.append("\n⏰ 人家记下的定时任务：\n")
            for job_id, task_info in state["tasks"].items():
                if task_info["time"] and task_info["time"] > now:
                    time_str = format_time_display(task_info["time"])
                    if task_info["type"] == "mute":
                        msg.append("  • 到时候禁言 ")
                        for i, uid in enumerate(task_info["targets"]):
                            if i > 0:
                                msg.append(" ")
                            msg.append(MessageSegment.at(uid))
                        msg.append(f" 在 {time_str}\n")
                    elif task_info["type"] == "whole_mute":
                        msg.append(f"  • 到时候全员禁言 在 {time_str}\n")
                    elif task_info["type"] == "whole_unmute":
                        msg.append(f"  • 到时候解除全员禁言 在 {time_str}\n")
        else:
            msg.append("\n⏰ 定时任务：没有喵~\n")
        
        await mute_matcher.finish(msg)
        return
    
    # 检查是否是"禁我"命令（精确匹配）
    if is_self_mute_command(raw_msg):
        logger.debug("禁我命令")
        await execute_self_mute(bot, group_id, int(user_id))
        return
    
    # 修复：检查是否是禁言相关命令（包括取消/解除/解禁等操作）
    # 不再要求必须包含"禁言"二字
    if (is_mute_command(raw_msg) or 
        is_cancel_command(raw_msg) or 
        is_whole_mute_command(raw_msg) or 
        is_whole_unmute_command(raw_msg)):
        logger.debug("是禁言相关命令，开始处理")
    else:
        logger.debug("不是禁言相关命令，忽略")
        return
    
    is_cancel = is_cancel_command(raw_msg)
    action = "取消" if is_cancel else "禁言"
    logger.debug(f"操作类型: {action}")
    
    targets = parse_at_targets(msg_str)
    logger.debug(f"被@的目标: {targets}")
    
    # 检查是否是全员操作
    is_all = is_whole_mute_command(raw_msg)
    is_all_unmute = is_whole_unmute_command(raw_msg)
    
    if is_all or is_all_unmute:
        logger.debug("全员操作")
        
        # 检查是否是解禁全员命令
        if is_all_unmute or (is_cancel and is_all):
            logger.debug("解禁全员")
            await execute_cancel(bot, group_id, [], True)
        else:
            logger.debug("全员禁言")
            
            # 尝试从消息中提取时长
            duration = None  # 默认为永久禁言
            
            # 提取时间参数 - 更精确的方法
            # 移除命令词，只保留可能的时长部分
            remaining = raw_msg
            
            # 移除各种可能的命令前缀
            command_prefixes = ["全员禁言", "全体禁言", "始终禁言", "全员", "全体", "始终"]
            for prefix in command_prefixes:
                if remaining.startswith(prefix):
                    remaining = remaining[len(prefix):].strip()
                    break
            
            logger.debug(f"提取时长的剩余文本: {remaining}")
            
            # 如果剩余文本不为空，尝试解析时长
            if remaining:
                # 尝试直接解析时长（如 "5m"、"5分钟"、"5" 等）
                parsed = parse_duration(remaining)
                if parsed is not None:
                    duration = parsed
                    logger.debug(f"解析到时长: {duration} 分钟")
                else:
                    # 尝试从文本中提取数字（如 "禁言 5分钟" 中的 "5"）
                    numbers = re.findall(r'(\d+)', remaining)
                    if numbers:
                        # 检查数字后面是否有时间单位
                        time_match = re.search(r'(\d+)\s*(?:分钟|分|min|m|小时|时|h)?', remaining)
                        if time_match:
                            parsed = parse_duration(time_match.group(0))
                            if parsed:
                                duration = parsed
                                logger.debug(f"从文本中解析到时长: {duration} 分钟")
            
            target_key = f"whole_mute_{group_id}"
            cancel_tasks_for_target(group_id, target_key)
            
            # 调用 execute_whole_mute，传入 duration（None=永久，有值=定时）
            logger.debug(f"执行全员禁言，duration={duration}")
            await execute_whole_mute(bot, group_id, duration)
        return
    
    remaining = msg_str
    for target in targets:
        remaining = remaining.replace(f"[CQ:at,qq={target}]", "")
    
    remaining = re.sub(r'^(禁言|取消|解除|解禁)\s*', '', remaining)
    remaining = remaining.strip()
    
    logger.debug(f"剩余参数: {remaining}")
    
    user_ids = [int(qq) for qq in targets]
    
    if is_cancel:
        await execute_cancel(bot, group_id, user_ids, False)
        return
    
    time_range = parse_time_range(remaining)
    
    if time_range:
        start_time, duration = time_range
        target_key = f"mute_{'_'.join(map(str, sorted(user_ids)))}"
        
        old_tasks = find_tasks_for_target(group_id, target_key)
        for job_id in old_tasks:
            try:
                scheduler.remove_job(job_id)
                await remove_task_record(group_id, job_id)
            except:
                pass
        
        job_id = generate_job_id(group_id, "mute")
        scheduler.add_job(
            func=execute_mute,
            trigger="date",
            run_date=start_time,
            args=[bot, group_id, user_ids, duration, job_id],
            id=job_id,
            replace_existing=False
        )
        await add_task_record(group_id, job_id, "mute", user_ids, start_time, duration, target_key)
        
        end_time = start_time + timedelta(minutes=duration)
        
        msg = Message()
        msg.append(f"人家记住了~在 {format_time_display(start_time)} 禁言 ")
        msg.append(format_at_message(user_ids))
        msg.append(f" {format_duration_display(duration)} 喵~\n")
        msg.append(f"* {format_time_display(end_time)} 就能说话啦 *")
        
        await mute_matcher.finish(msg)
    else:
        duration = parse_duration(remaining)
        if duration is None:
            duration = MUTE_DEFAULT_MINUTES
        
        await execute_mute(bot, group_id, user_ids, duration)

# ==================== 插件加载成功提示 ====================

logger.opt(colors=True).success("<green>✅ 猫娘禁言插件加载成功！人家准备好啦~</green>")
logger.opt(colors=True).success(f"<blue>📁 数据存储目录: {storage.data_dir.absolute()}</blue>")