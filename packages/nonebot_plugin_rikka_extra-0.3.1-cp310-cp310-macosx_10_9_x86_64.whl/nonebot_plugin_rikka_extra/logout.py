import json
import logging

import httpx

from .sdgb import MaimaiClient
from .sdgb.chime import qr_api
from .sdgb.payload import userlogout_payload, userpreview_payload

logger = logging.getLogger("sdgb_workflow")


async def force_logout(qr_code: str):
    """
    尝试强制登出
    """
    maimai_client = MaimaiClient()

    async with httpx.AsyncClient(verify=False) as client:
        # QR Code 解析
        qr_response = await qr_api(qr_code)
        if qr_response["errorID"] != 0:
            raise RuntimeError("二维码解析失败。")
        user_id = qr_response["userID"]
        token = qr_response["token"]

        # Preview 探测
        preview_payload = userpreview_payload(user_id, token)
        response = await maimai_client.call_api(
            client, "GetUserPreviewApi", preview_payload, user_id
        )
        assert response is not None, "Preview 请求失败。"

        preview_response = json.loads(response)
        if not preview_response.get("isLogin"):
            raise RuntimeError("未监测到登录情况，或许当前未在登录状态")

        request_payload = userlogout_payload(user_id)
        result = await maimai_client.call_api(
            client, "UserLogoutApi", request_payload, user_id
        )
        if not result:
            logger.warning("Logout 请求可能失败。")

        logger.debug(f"登出结果: {result}")
