import json
import logging
from typing import TypedDict

import httpx

from ._client import sdgb_client
from .sdgb.sdgb import MaimaiClient

logger = logging.getLogger("sdgb_workflow")


class UserMusicDetail(TypedDict):
    musicId: int
    level: int
    playCount: int
    achievement: int
    comboStatus: int
    syncStatus: int
    deluxscoreMax: int
    scoreRank: int
    extNum1: int
    extNum2: int


class UserMusicEntry(TypedDict, total=False):
    userMusicDetailList: list[UserMusicDetail]
    length: int


class GetUserMusicResponse(TypedDict, total=False):
    userId: int
    length: int
    nextIndex: int
    userMusicList: list[UserMusicEntry]


async def get_all_score(
    sdgb_client: MaimaiClient, client: httpx.AsyncClient, user_id: int, token: str
) -> list[UserMusicDetail]:
    user_music_list: list[UserMusicDetail] = []
    next_index = 0
    max_count = 200  # 每次获取的数量

    while True:
        data = {
            "userId": user_id,
            "nextIndex": next_index,
            "maxCount": max_count,
            "token": token,
        }

        try:
            resp_str = await sdgb_client.call_api(
                client, "GetUserMusicApi", data, user_id
            )
            if not resp_str:
                logger.info("Empty response, breaking loop")
                break

            resp: GetUserMusicResponse = json.loads(resp_str)
        except Exception as e:
            logger.error(f"Error parsing response: {e}")
            break

        # 检查响应内容
        current_list = resp.get("userMusicList", [])
        length = resp.get("length", 0)
        new_next_index = resp.get("nextIndex", 0)

        if current_list:
            for entry in current_list:
                detail_list = entry.get("userMusicDetailList", [])
                for detail in detail_list:
                    if isinstance(detail, dict):
                        user_music_list.append(detail)  # type: ignore[arg-type]

        logger.debug(f"Fetched {length} items. Next index: {new_next_index}")

        # 如果 nextIndex 为 0，说明没有更多数据了
        if new_next_index == 0 or not current_list:
            break

        next_index = new_next_index

    return user_music_list


async def run_workflow(qr_code: str) -> list[UserMusicDetail]:
    async with sdgb_client(qr_code) as ctx:
        # UserData 等
        player_scores = await get_all_score(
            ctx.maimai_client, ctx.client, ctx.user_id, ctx.token
        )
        logger.info(f"获取到总计 {len(player_scores)} 首歌曲记录。")

        return player_scores
