import asyncio
import json
import logging
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import AsyncGenerator

import httpx

from .sdgb import MaimaiClient
from .sdgb.chime import qr_api
from .sdgb.payload import userlogin_payload, userlogout_payload, userpreview_payload

logger = logging.getLogger("sdgb_workflow")


class TitleServerError(RuntimeError):
    """Raised when the title server returns an error response."""


@dataclass
class GameSessionContext:
    maimai_client: MaimaiClient
    client: httpx.AsyncClient
    user_id: int
    login_id: int
    token: str
    last_login_date: str


async def _background_logout(user_id: int, cookies: httpx.Cookies) -> None:
    logger.debug(f"User {user_id} 将在后台等待 70秒 后登出...")
    await asyncio.sleep(70)

    maimai_client = MaimaiClient()
    logger.debug(f"User {user_id} 开始执行后台登出")

    try:
        async with httpx.AsyncClient(verify=False, cookies=cookies) as client:
            request_payload = userlogout_payload(user_id)
            result = await maimai_client.call_api(
                client, "UserLogoutApi", request_payload, user_id
            )
            if not result:
                logger.warning(f"User {user_id} 后台 Logout 请求可能失败。")
            else:
                logger.debug(f"User {user_id} 后台登出成功。")
    except Exception as e:
        logger.error(f"User {user_id} 后台登出发生错误: {e}")


@asynccontextmanager
async def sdgb_client(
    qr_code: str,
) -> AsyncGenerator[GameSessionContext, None]:
    maimai_client = MaimaiClient()

    async with httpx.AsyncClient(verify=False) as client:
        # QR Code 解析
        qr_response = await qr_api(qr_code)
        if qr_response["errorID"] != 0:
            raise RuntimeError("二维码解析失败。")
        user_id = qr_response["userID"]
        token = qr_response["token"]

        # Preview 探测
        preview_payload = userpreview_payload(user_id, token)
        response = await maimai_client.call_api(
            client, "GetUserPreviewApi", preview_payload, user_id
        )
        assert response is not None, "Preview 请求失败。"

        preview_response = json.loads(response)
        if preview_response.get("isLogin"):
            raise RuntimeError("已在他处登录。")

        # UserLogin
        login_payload = userlogin_payload(user_id, token)
        response = await maimai_client.call_api(
            client, "UserLoginApi", login_payload, user_id
        )
        assert response is not None, "Login 请求失败。"

        login_response = json.loads(response)
        return_code = login_response.get("returnCode")

        if return_code in [100, 110]:
            raise RuntimeError("用户正在上机或未正常登出，请等待 15 分钟后再试")
        if return_code == 102:
            raise RuntimeError("二维码已失效。")
        if return_code == 103:
            raise RuntimeError("该用户不存在")
        if return_code != 1:
            raise RuntimeError(f"登录失败：未知错误 (Code: {return_code})")

        login_id = login_response["loginId"]
        last_login_date = login_response["lastLoginDate"]

        try:
            yield GameSessionContext(
                maimai_client, client, user_id, login_id, token, last_login_date
            )
        finally:
            asyncio.create_task(_background_logout(user_id, client.cookies))
