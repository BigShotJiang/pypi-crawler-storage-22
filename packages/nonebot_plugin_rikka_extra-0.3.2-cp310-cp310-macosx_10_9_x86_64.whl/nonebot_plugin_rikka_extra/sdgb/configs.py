from pydantic_settings import BaseSettings, SettingsConfigDict


class SDGBConfig(BaseSettings):
    region_id: int = 1
    region_name: str = "北京"
    place_id: int = 1403
    place_name: str = "插电师北京王府井银泰店"
    client_id: str = "A63E01C2805"
    keychip_id: str = "A63E-01C28055905"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


config = SDGBConfig()
