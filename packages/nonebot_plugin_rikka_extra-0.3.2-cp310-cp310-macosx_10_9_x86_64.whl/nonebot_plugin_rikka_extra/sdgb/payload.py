import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from logging import getLogger
from typing import Any

import pytz

from .configs import config
from .encrypt import CalcRandom

logger = getLogger("sdgb_payload")


@dataclass
class GeneralUserInfo:
    user_data: Any
    user_extend: Any
    user_option: Any
    user_rating: Any
    user_charge_list: Any
    user_activity: Any
    user_mission_datalist: Any


def userpreview_payload(userId: int, token: str):
    requestData_UserPreview = {
        "userId": userId,
        "segaIdAuthKey": "",
        "token": token,
        "clientId": config.client_id,
    }
    return requestData_UserPreview


def userlogin_payload(userId: int, token: str):
    timestamp = datetime.now(pytz.timezone("Asia/Shanghai"))
    TimeStamp = int(time.mktime(timestamp.timetuple()))
    requestData_UserLogin = {
        "userId": userId,
        "accessCode": "",
        "regionId": config.region_id,
        "placeId": config.place_id,
        "clientId": config.client_id,
        "dateTime": TimeStamp - 600,
        "loginDateTime": TimeStamp,
        "isContinue": False,
        "genericFlag": 0,
        "token": token,
    }
    return requestData_UserLogin


def userdata_payload(userId: int):
    requestData_UserData = {"userId": userId}
    return requestData_UserData


def userticket_payload(userId: int):
    return {
        "userId": userId,
        "userCharge": {
            "chargeId": 6,
            "stock": 1,
            "purchaseDate": (datetime.now(pytz.timezone("Asia/Shanghai"))).strftime(
                "%Y-%m-%d %H:%M:%S.0"
            ),
            "validDate": (
                datetime.now(pytz.timezone("Asia/Shanghai")) + timedelta(days=90)
            )
            .replace(hour=4, minute=0, second=0)
            .strftime("%Y-%m-%d %H:%M:%S"),
        },
        "userChargelog": {
            "chargeId": 6,
            "price": 0,
            "purchaseDate": (datetime.now(pytz.timezone("Asia/Shanghai"))).strftime(
                "%Y-%m-%d %H:%M:%S.0"
            ),
            "placeId": config.place_id,
            "regionId": config.region_id,
            "clientId": config.client_id,
        },
    }


def userlogout_payload(userId: int):
    timestamp = datetime.now(pytz.timezone("Asia/Shanghai"))
    TimeStamp = int(time.mktime(timestamp.timetuple()))
    requestData_UserLogout = {
        "userId": userId,
        "accessCode": "",
        "regionId": config.region_id,
        "placeId": config.place_id,
        "clientId": config.client_id,
        "loginDateTime": TimeStamp,
        "type": 1,
    }
    return requestData_UserLogout


def UserAll_payload(
    userId: int,
    loginId: int,
    loginDate: str,
    general_user_info: GeneralUserInfo,
    userItemList: list | None = None,
):
    timestamp = datetime.now(pytz.timezone("Asia/Shanghai"))
    TimeStamp = int(time.mktime(timestamp.timetuple()))

    userData = general_user_info.user_data
    userExtend = general_user_info.user_extend
    userOption = general_user_info.user_option
    userRating = general_user_info.user_rating
    userChargeList = general_user_info.user_charge_list
    userActivity = general_user_info.user_activity
    userMissionDataList = general_user_info.user_mission_datalist

    requestData_UserAll = {
        "userId": userId,
        "playlogId": loginId,
        "isEventMode": False,
        "isFreePlay": False,
        "loginDateTime": TimeStamp,
        "userPlaylogList": [],
        "upsertUserAll": {
            "userData": [
                {
                    "accessCode": "",
                    "userName": userData["userData"]["userName"],
                    "isNetMember": 1,
                    "point": userData["userData"]["point"],
                    "totalPoint": userData["userData"]["totalPoint"],
                    "iconId": userData["userData"]["iconId"],
                    "plateId": userData["userData"]["plateId"],
                    "titleId": userData["userData"]["titleId"],
                    "partnerId": userData["userData"]["partnerId"],
                    "frameId": userData["userData"]["frameId"],
                    "selectMapId": userData["userData"]["selectMapId"],
                    "totalAwake": userData["userData"]["totalAwake"],
                    "gradeRating": userData["userData"]["gradeRating"],
                    "musicRating": userData["userData"]["musicRating"],
                    "playerRating": userData["userData"]["playerRating"],
                    "highestRating": userData["userData"]["highestRating"],
                    "gradeRank": userData["userData"]["gradeRank"],
                    "classRank": userData["userData"]["classRank"],
                    "courseRank": userData["userData"]["courseRank"],
                    "charaSlot": userData["userData"]["charaSlot"],
                    "charaLockSlot": userData["userData"]["charaLockSlot"],
                    "contentBit": userData["userData"]["contentBit"],
                    "playCount": userData["userData"]["playCount"] + 1,
                    "currentPlayCount": userData["userData"]["currentPlayCount"] + 1,
                    "renameCredit": userData["userData"]["renameCredit"],
                    "mapStock": userData["userData"]["mapStock"],
                    "eventWatchedDate": userData["userData"]["eventWatchedDate"],
                    "lastGameId": "SDGB",
                    "lastRomVersion": userData["userData"]["lastRomVersion"],
                    "lastDataVersion": userData["userData"]["lastDataVersion"],
                    "lastLoginDate": loginDate,
                    "lastPlayDate": datetime.now(
                        pytz.timezone("Asia/Shanghai")
                    ).strftime("%Y-%m-%d %H:%M:%S")
                    + ".0",
                    "lastPlayCredit": 1,
                    "lastPlayMode": 0,
                    "lastPlaceId": config.place_id,
                    "lastPlaceName": config.place_name,
                    "lastAllNetId": 0,
                    "lastRegionId": config.region_id,
                    "lastRegionName": config.region_name,
                    "lastClientId": config.client_id,
                    "lastCountryCode": "CHN",
                    "lastSelectEMoney": userData["userData"]["lastSelectEMoney"],
                    "lastSelectTicket": userData["userData"]["lastSelectTicket"],
                    "lastSelectCourse": userData["userData"]["lastSelectCourse"],
                    "lastCountCourse": userData["userData"]["lastCountCourse"],
                    "firstGameId": userData["userData"]["firstGameId"],
                    "firstRomVersion": userData["userData"]["firstRomVersion"],
                    "firstDataVersion": userData["userData"]["firstDataVersion"],
                    "firstPlayDate": userData["userData"]["firstPlayDate"],
                    "compatibleCmVersion": userData["userData"]["compatibleCmVersion"],
                    "dailyBonusDate": userData["userData"]["dailyBonusDate"],
                    "dailyCourseBonusDate": userData["userData"][
                        "dailyCourseBonusDate"
                    ],
                    "lastPairLoginDate": userData["userData"]["lastPairLoginDate"],
                    "lastTrialPlayDate": userData["userData"]["lastTrialPlayDate"],
                    "playVsCount": userData["userData"]["playVsCount"],
                    "playSyncCount": userData["userData"]["playSyncCount"],
                    "winCount": userData["userData"]["winCount"],
                    "helpCount": userData["userData"]["helpCount"],
                    "comboCount": userData["userData"]["comboCount"],
                    "totalDeluxscore": userData["userData"]["totalDeluxscore"],
                    "totalBasicDeluxscore": userData["userData"][
                        "totalBasicDeluxscore"
                    ],
                    "totalAdvancedDeluxscore": userData["userData"][
                        "totalAdvancedDeluxscore"
                    ],
                    "totalExpertDeluxscore": userData["userData"][
                        "totalExpertDeluxscore"
                    ],
                    "totalMasterDeluxscore": userData["userData"][
                        "totalMasterDeluxscore"
                    ],
                    "totalReMasterDeluxscore": userData["userData"][
                        "totalReMasterDeluxscore"
                    ],
                    "totalSync": userData["userData"]["totalSync"],
                    "totalBasicSync": userData["userData"]["totalBasicSync"],
                    "totalAdvancedSync": userData["userData"]["totalAdvancedSync"],
                    "totalExpertSync": userData["userData"]["totalExpertSync"],
                    "totalMasterSync": userData["userData"]["totalMasterSync"],
                    "totalReMasterSync": userData["userData"]["totalReMasterSync"],
                    "totalAchievement": userData["userData"]["totalAchievement"],
                    "totalBasicAchievement": userData["userData"][
                        "totalBasicAchievement"
                    ],
                    "totalAdvancedAchievement": userData["userData"][
                        "totalAdvancedAchievement"
                    ],
                    "totalExpertAchievement": userData["userData"][
                        "totalExpertAchievement"
                    ],
                    "totalMasterAchievement": userData["userData"][
                        "totalMasterAchievement"
                    ],
                    "totalReMasterAchievement": userData["userData"][
                        "totalReMasterAchievement"
                    ],
                    "playerOldRating": userData["userData"]["playerOldRating"],
                    "playerNewRating": userData["userData"]["playerNewRating"],
                    "banState": userData["banState"],
                    "friendRegistSkip": userData["userData"]["friendRegistSkip"],
                    "dateTime": TimeStamp,
                }
            ],
            "userExtend": [userExtend["userExtend"]],
            "userOption": [userOption["userOption"]],
            "userCharacterList": [],
            "userGhost": [],
            "userMapList": [],
            "userLoginBonusList": [],
            "userRatingList": [userRating["userRating"]],
            "userItemList": userItemList or [],
            "userMusicDetailList": [],
            "userCourseList": [],
            "userFriendSeasonRankingList": [],
            "userChargeList": userChargeList["userChargeList"],
            "userFavoriteList": [
                {"itemKind": 3, "itemIdList": []},
                {"itemKind": 1, "itemIdList": []},
                {"itemKind": 2, "itemIdList": []},
                {"itemKind": 10, "itemIdList": []},
                {"itemKind": 11, "itemIdList": []},
            ],
            "userActivityList": [userActivity["userActivity"]],
            "userMissionDataList": [
                {
                    "type": userMissionDataList["userMissionDataList"][0]["type"],
                    "difficulty": userMissionDataList["userMissionDataList"][0][
                        "difficulty"
                    ],
                    "targetGenreId": userMissionDataList["userMissionDataList"][0][
                        "targetGenreId"
                    ],
                    "targetGenreTableId": userMissionDataList["userMissionDataList"][0][
                        "targetGenreTableId"
                    ],
                    "conditionGenreId": userMissionDataList["userMissionDataList"][0][
                        "conditionGenreId"
                    ],
                    "conditionGenreTableId": userMissionDataList["userMissionDataList"][
                        0
                    ]["conditionGenreTableId"],
                    "clearFlag": userMissionDataList["userMissionDataList"][0][
                        "clearFlag"
                    ],
                },
                {
                    "type": userMissionDataList["userMissionDataList"][1]["type"],
                    "difficulty": userMissionDataList["userMissionDataList"][1][
                        "difficulty"
                    ],
                    "targetGenreId": userMissionDataList["userMissionDataList"][1][
                        "targetGenreId"
                    ],
                    "targetGenreTableId": userMissionDataList["userMissionDataList"][1][
                        "targetGenreTableId"
                    ],
                    "conditionGenreId": userMissionDataList["userMissionDataList"][1][
                        "conditionGenreId"
                    ],
                    "conditionGenreTableId": userMissionDataList["userMissionDataList"][
                        1
                    ]["conditionGenreTableId"],
                    "clearFlag": userMissionDataList["userMissionDataList"][1][
                        "clearFlag"
                    ],
                },
                {
                    "type": userMissionDataList["userMissionDataList"][2]["type"],
                    "difficulty": userMissionDataList["userMissionDataList"][2][
                        "difficulty"
                    ],
                    "targetGenreId": userMissionDataList["userMissionDataList"][2][
                        "targetGenreId"
                    ],
                    "targetGenreTableId": userMissionDataList["userMissionDataList"][2][
                        "targetGenreTableId"
                    ],
                    "conditionGenreId": userMissionDataList["userMissionDataList"][2][
                        "conditionGenreId"
                    ],
                    "conditionGenreTableId": userMissionDataList["userMissionDataList"][
                        2
                    ]["conditionGenreTableId"],
                    "clearFlag": userMissionDataList["userMissionDataList"][2][
                        "clearFlag"
                    ],
                },
                {
                    "type": userMissionDataList["userMissionDataList"][3]["type"],
                    "difficulty": userMissionDataList["userMissionDataList"][3][
                        "difficulty"
                    ],
                    "targetGenreId": userMissionDataList["userMissionDataList"][3][
                        "targetGenreId"
                    ],
                    "targetGenreTableId": userMissionDataList["userMissionDataList"][3][
                        "targetGenreTableId"
                    ],
                    "conditionGenreId": userMissionDataList["userMissionDataList"][3][
                        "conditionGenreId"
                    ],
                    "conditionGenreTableId": userMissionDataList["userMissionDataList"][
                        3
                    ]["conditionGenreTableId"],
                    "clearFlag": userMissionDataList["userMissionDataList"][3][
                        "clearFlag"
                    ],
                },
                {
                    "type": userMissionDataList["userMissionDataList"][4]["type"],
                    "difficulty": userMissionDataList["userMissionDataList"][4][
                        "difficulty"
                    ],
                    "targetGenreId": userMissionDataList["userMissionDataList"][4][
                        "targetGenreId"
                    ],
                    "targetGenreTableId": userMissionDataList["userMissionDataList"][4][
                        "targetGenreTableId"
                    ],
                    "conditionGenreId": userMissionDataList["userMissionDataList"][4][
                        "conditionGenreId"
                    ],
                    "conditionGenreTableId": userMissionDataList["userMissionDataList"][
                        4
                    ]["conditionGenreTableId"],
                    "clearFlag": userMissionDataList["userMissionDataList"][4][
                        "clearFlag"
                    ],
                },
                {
                    "type": userMissionDataList["userMissionDataList"][5]["type"],
                    "difficulty": userMissionDataList["userMissionDataList"][5][
                        "difficulty"
                    ],
                    "targetGenreId": userMissionDataList["userMissionDataList"][5][
                        "targetGenreId"
                    ],
                    "targetGenreTableId": userMissionDataList["userMissionDataList"][5][
                        "targetGenreTableId"
                    ],
                    "conditionGenreId": userMissionDataList["userMissionDataList"][5][
                        "conditionGenreId"
                    ],
                    "conditionGenreTableId": userMissionDataList["userMissionDataList"][
                        5
                    ]["conditionGenreTableId"],
                    "clearFlag": userMissionDataList["userMissionDataList"][5][
                        "clearFlag"
                    ],
                },
            ],
            "userWeeklyData": {
                "lastLoginWeek": userMissionDataList["userWeeklyData"]["lastLoginWeek"],
                "beforeLoginWeek": userMissionDataList["userWeeklyData"][
                    "beforeLoginWeek"
                ],
                "friendBonusFlag": userMissionDataList["userWeeklyData"][
                    "friendBonusFlag"
                ],
            },
            "userGamePlaylogList": [
                {
                    "playlogId": loginId,
                    "version": userData["userData"]["lastRomVersion"],
                    "playDate": datetime.now(pytz.timezone("Asia/Shanghai")).strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )
                    + ".0",
                    "playMode": 0,
                    "useTicketId": -1,
                    "playCredit": 1,
                    "playTrack": 1,
                    "clientId": config.client_id,
                    "isPlayTutorial": False,
                    "isEventMode": False,
                    "isNewFree": False,
                    "playCount": 0,
                    "playSpecial": CalcRandom(),
                    "playOtherUserId": 0,
                }
            ],
            "user2pPlaylog": {
                "userId1": 0,
                "userId2": 0,
                "userName1": "",
                "userName2": "",
                "regionId": 0,
                "placeId": 0,
                "user2pPlaylogDetailList": [],
            },
            "userIntimateList": [],
            "userShopItemStockList": [],
            "userGetPointList": [],
            "userTradeItemList": [],
            "userFavoritemusicList": [],
            "userKaleidxScopeList": [],
            "isNewCharacterList": "",
            "isNewMapList": "",
            "isNewLoginBonusList": "",
            "isNewItemList": "",
            "isNewMusicDetailList": "0",
            "isNewCourseList": "",
            "isNewFavoriteList": (
                "11111" if not userItemList else "1" * len(userItemList)
            ),
            "isNewFriendSeasonRankingList": "",
            "isNewUserIntimateList": "",
            "isNewFavoritemusicList": "",
            "isNewKaleidxScopeList": "",
        },
    }

    logger.info(
        f"🫥 [INFO] userId: '{userId}', loginId: '{loginId}', loginDate: '{loginDate}', timestamp: '{TimeStamp}'"
    )
    return requestData_UserAll
