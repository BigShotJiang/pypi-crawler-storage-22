import json
import logging

from ._client import sdgb_client
from .sdgb.payload import userticket_payload

logger = logging.getLogger("sdgb_workflow")


async def run_workflow(qr_code: str):
    async with sdgb_client(qr_code) as ctx:
        # Get Ticket
        ticket_payload = userticket_payload(ctx.user_id)
        result = await ctx.maimai_client.call_api(
            ctx.client, "UpsertUserChargelogApi", ticket_payload, ctx.user_id
        )
        assert result is not None, "发票请求失败。"
        response = json.loads(result)
        assert response["returnCode"] != 1, "发票请求失败。"
