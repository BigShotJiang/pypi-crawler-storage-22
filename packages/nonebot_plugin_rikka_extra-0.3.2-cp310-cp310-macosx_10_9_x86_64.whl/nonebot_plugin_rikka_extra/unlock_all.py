import json
import logging
from typing import Any, Dict, List, TypedDict

from ._client import GameSessionContext, TitleServerError, sdgb_client
from .sdgb.payload import GeneralUserInfo, UserAll_payload

logger = logging.getLogger("sdgb_workflow")


class UserItem(TypedDict):
    itemKind: int
    itemId: int
    stock: int
    isValid: bool


async def fetch_user_data_components(
    ctx: GameSessionContext,
) -> GeneralUserInfo:
    """获取构建 UserAll 所需的所有用户数据组件"""
    # 1. UserData
    resp = await ctx.maimai_client.call_api(
        ctx.client, "GetUserDataApi", {"userId": ctx.user_id}, ctx.user_id
    )
    if not resp:
        raise RuntimeError("GetUserDataApi failed")
    user_data = json.loads(resp)

    # 2. UserExtend
    resp = await ctx.maimai_client.call_api(
        ctx.client, "GetUserExtendApi", {"userId": ctx.user_id}, ctx.user_id
    )
    if not resp:
        raise RuntimeError("GetUserExtendApi failed")
    user_extend = json.loads(resp)

    # 3. UserOption
    resp = await ctx.maimai_client.call_api(
        ctx.client, "GetUserOptionApi", {"userId": ctx.user_id}, ctx.user_id
    )
    if not resp:
        raise RuntimeError("GetUserOptionApi failed")
    user_option = json.loads(resp)

    # 4. UserRating
    resp = await ctx.maimai_client.call_api(
        ctx.client, "GetUserRatingApi", {"userId": ctx.user_id}, ctx.user_id
    )
    if not resp:
        raise RuntimeError("GetUserRatingApi failed")
    user_rating = json.loads(resp)

    # 5.UserCharge
    resp = await ctx.maimai_client.call_api(
        ctx.client, "GetUserChargeApi", {"userId": ctx.user_id}, ctx.user_id
    )
    if not resp:
        raise RuntimeError("GetUserChargeApi failed")
    user_charge = json.loads(resp)

    # 6. UserActivity
    resp = await ctx.maimai_client.call_api(
        ctx.client, "GetUserActivityApi", {"userId": ctx.user_id}, ctx.user_id
    )
    if not resp:
        raise RuntimeError("GetUserActivityApi failed")
    user_activity = json.loads(resp)

    # 7. UserMissionData
    resp = await ctx.maimai_client.call_api(
        ctx.client,
        "GetUserMissionDataApi",
        {"userId": ctx.user_id},
        ctx.user_id,
    )
    if not resp:
        raise RuntimeError("GetUserMissionDataApi failed")
    user_mission_data = json.loads(resp)

    return GeneralUserInfo(
        user_data=user_data,
        user_extend=user_extend,
        user_option=user_option,
        user_rating=user_rating,
        user_charge_list=user_charge,
        user_activity=user_activity,
        user_mission_datalist=user_mission_data,
    )


# 固定需要解锁的 Item ID 列表
FIXED_ITEM_IDS: List[int] = [
    10070,
    10145,
    10146,
    10188,
    10190,
    10191,
    10193,
    10202,
    10235,
    10256,
    10288,
    10301,
    10302,
    10315,
    10316,
    10319,
    10363,
    10404,
    10420,
    10536,
    10552,
    10572,
    10593,
    10602,
    10625,
    10641,
    10665,
    10690,
    10702,
    10706,
    10734,
]


def get_dynamic_item_ids() -> List[int]:
    """从 rikka 数据库动态获取需要解锁的曲目 Item ID"""
    try:
        from nonebot_plugin_rikka.database import MaiSongORM
    except ImportError:
        logger.warning(
            "无法导入 nonebot_plugin_rikka，跳过动态曲目解锁。请在 NoneBot 环境中运行此脚本。"
        )
        return []

    # 尝试直接从缓存获取，如果在 Bot 进程中运行，缓存应该已经初始化
    if not MaiSongORM._cache:
        logger.warning(
            "MaiSongORM 缓存为空，可能未连接数据库或未初始化。跳过动态曲目解锁。"
        )
        return []

    dynamic_ids = []
    for song in MaiSongORM._cache.values():
        # 筛选条件: version >= 20000 且 dx 谱面不为空
        if song.version >= 20000 and song.difficulties.dx:
            dynamic_ids.append(song.id + 10000)

    logger.info(f"动态获取到 {len(dynamic_ids)} 个曲目 ID")
    return dynamic_ids


def generate_user_item_list(item_ids: List[int]) -> List[UserItem]:
    """生成 userItemList，每个 item_id 同时生成 itemKind 5 和 6"""
    items: list[UserItem] = []
    for item_id in item_ids:
        # 添加 itemKind 5
        items.append(
            {
                "itemKind": 5,
                "itemId": item_id,
                "stock": 1,
                "isValid": True,
            }
        )
        # 添加 itemKind 6
        items.append(
            {
                "itemKind": 6,
                "itemId": item_id,
                "stock": 1,
                "isValid": True,
            }
        )
    return items


def construct_upsert_user_all(
    user_id: int,
    login_id: int,
    components: Dict[str, Any],
    padding_items: List[UserItem],
) -> Dict[str, Any]:
    """构建 UpsertUserAllApi 的 payload"""

    user_data_src = components["user_data"]["userData"]
    user_extend_src = components["user_extend"]["userExtend"]
    user_option_src = components["user_option"]["userOption"]
    user_rating_src = components["user_rating"]["userRating"]

    # 注意：根据原始脚本逻辑，我们主要关注 userItemList 的修改，其他部分尽量保持原样或更新必要的时间戳
    # 这里我们直接复用获取到的数据结构

    # UserData 中的某些字段可能需要重置或更新，例如 lastLoginDate 等
    # 但在 UserAll 接口中，通常可以直接回传最新获取的状态

    payload = {
        "userId": user_id,
        "playlogId": login_id,
        "isEventMode": False,
        "isFreePlay": False,
        "upsertUserAll": {
            "userData": [user_data_src],
            "userExtend": [user_extend_src],
            "userOption": [user_option_src],
            "userCharacterList": [],
            "userGhost": [],
            "userMapList": [],
            "userLoginBonusList": [],
            "userRatingList": [user_rating_src],
            # 这里的 userItemList 是我们要 "unlock" 的核心部分
            "userItemList": padding_items,
        },
    }
    return payload


async def run_workflow(qr_code: str):
    async with sdgb_client(qr_code) as ctx:
        logger.debug("开始获取用户数据...")
        components = await fetch_user_data_components(ctx)

        # 获取动态 Item IDs
        dynamic_ids = get_dynamic_item_ids()

        # 合并所有 Item IDs
        all_item_ids = list(set(FIXED_ITEM_IDS + dynamic_ids))
        logger.debug(
            f"成功获取用户数据, 准备构建 {len(all_item_ids)} 个物品的解锁请求..."
        )

        unlock_items = generate_user_item_list(all_item_ids)
        logger.debug(f"生成了 {len(unlock_items)} 个 userItem 条目 (ItemKind 5 & 6)")

        payload = UserAll_payload(
            ctx.user_id, ctx.login_id, ctx.last_login_date, components, unlock_items
        )

        logger.debug("发送 UpsertUserAllApi 请求...")
        # UpsertUserAllApi 比较特殊，数据量可能很大
        result = await ctx.maimai_client.call_api(
            ctx.client, "UpsertUserAllApi", payload, ctx.user_id
        )

        if result:
            resp_json = json.loads(result)
            if resp_json.get("returnCode") == 1:
                logger.info("服务器返回成功。")
            else:
                raise TitleServerError(
                    f"服务器返回非成功状态码: {resp_json.get('returnCode')}"
                )
        else:
            raise TitleServerError("UpsertUserAllApi 调用失败，无响应。")
