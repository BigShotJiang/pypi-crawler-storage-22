"""
语录排行榜命令处理器。

通过 @inject 装饰器自动从 dishka 容器获取服务依赖。
"""

from __future__ import annotations

import datetime
from nonebot import logger
from typing import List

from nonebot.adapters.onebot.v11 import (
    GroupMessageEvent,
    MessageSegment as MsgSeg,
)
from nonebot.adapters import Message
from nonebot.params import CommandArg

from ..command_definition import matcher_get_ranking, default_cfg
from ...di import Inject, inject
from ...services import (
    GroupService,
    QuoteCollectionService,
    QuoteReadService,
    StatisticsService,
    UserService,
)
from ...services.html_render_service import HtmlRenderServiceBase
from ._error_handlers import command_error_handler
from ...utils.base64_encoder import to_data_uri
from ...templates.registry import RANK
from ...templates.schema.rank import (
    TemplateBasicRankingItemData,
    TemplateLineChartData,
    TemplateRankingData,
    TemplateRankingStatsData,
    render_rank,
)

def _generate_date_range_mm_dd(
    start_date: datetime.date, end_date: datetime.date,
) -> List[str]:
    """
    生成 MM-DD 格式的日期范围列表。

    :param start_date: 起始日期
    :type start_date: datetime.date
    :param end_date: 结束日期
    :type end_date: datetime.date
    :returns: MM-DD 格式的日期字符串列表
    :rtype: List[str]
    """
    date_list: List[str] = []
    current = start_date
    while current <= end_date:
        date_list.append(current.strftime("%m-%d"))
        current += datetime.timedelta(days=1)
    return date_list

@matcher_get_ranking.handle()
@inject
async def handle_get_ranking(
    event: GroupMessageEvent,
    arg: Message = CommandArg(),
    stats_svc: StatisticsService = Inject(StatisticsService),
    user_svc: UserService = Inject(UserService),
    group_svc: GroupService = Inject(GroupService),
    quote_read_svc: QuoteReadService = Inject(QuoteReadService),
    collection_svc: QuoteCollectionService = Inject(QuoteCollectionService),
    html_render_svc: HtmlRenderServiceBase = Inject(HtmlRenderServiceBase),
) -> None:
    """
    处理语录排行榜命令。

    获取群组统计数据、个人排行和近 15 天走势，渲染为排行榜图片发送。

    :param event: 群消息事件
    :type event: GroupMessageEvent
    :param arg: 命令参数消息体
    :type arg: Message
    :param stats_svc: 统计服务（DI 注入）
    :type stats_svc: StatisticsService
    :param user_svc: 用户服务（DI 注入）
    :type user_svc: UserService
    :param group_svc: 群组服务（DI 注入）
    :type group_svc: GroupService
    :param quote_read_svc: 语录读取服务（DI 注入）
    :type quote_read_svc: QuoteReadService
    :param html_render_svc: HTML 渲染服务（DI 注入）
    :type html_render_svc: HtmlRenderServiceBase
    """
    group_id = str(event.group_id)

    # 解析参数，获取展示数量
    key = arg.extract_plain_text().strip()
    max_rank = default_cfg.showcase.max_rank_user_num
    if key and key.isnumeric() and int(key) > 0:
        max_showcase_number = min(int(key), max(1, max_rank))
    else:
        max_showcase_number = max_rank

    async with command_error_handler(matcher_get_ranking, "获取语录排行"):
        # 获取统计数据
        stat = await stats_svc.get_group_statistics(group_id)
        total_count = stat["total_quotes"]
        contributors = stat["unique_authors"]
        total_shows = stat["total_shows"]

        if total_count == 0:
            raise ValueError("当前群组语录数为 0")

        # 从消息队列获取待收集语录数
        pending_count = await collection_svc.get_queue_count(group_id)

        stats_data = TemplateRankingStatsData(
            total_quotes=total_count,
            pending_quotes=pending_count,
            contributors=contributors,
            average_quotes=(
                0.0 if contributors == 0
                else total_count / contributors
            ),
            total_shows=total_shows,
        )

        # 获取群组名称
        group_info = await group_svc.get_group(group_id)
        if group_info is None:
            raise ValueError(f"无法在数据库中找到群组 {group_id}")
        group_name = group_info.name

        # 获取个人排行
        member_counts = await stats_svc.get_group_member_quote_counts(
            group_id,
        )
        ranking_data: List[TemplateBasicRankingItemData] = []
        for item in member_counts:
            qq_id = item["qq_id"]
            count = item["quote_count"]
            name = await user_svc.get_display_name(qq_id, group_id)

            # 获取头像
            avatar_bytes = await user_svc.get_avatar(qq_id)
            avatar_uri = to_data_uri(avatar_bytes) if avatar_bytes else None

            ranking_data.append(TemplateBasicRankingItemData(
                qq=qq_id,
                author=name,
                count=count,
                avatar=avatar_uri,
            ))

        if not ranking_data:
            raise ValueError("排行数据为空")

        ranking_data.sort(key=lambda x: x.count, reverse=True)
        ranking_data = ranking_data[:max_showcase_number]

        # 折线图数据（近 15 天走势）
        top_n = min(5, len(ranking_data))
        today_start = datetime.datetime.now()
        fifteen_days_ago = (
            today_start - datetime.timedelta(days=15)
        ).replace(hour=0, minute=0, second=0, microsecond=0)

        frontiers_series: List[List[int]] = []
        for i in range(top_n):
            qq_id = ranking_data[i].qq
            all_quotes = list(
                await quote_read_svc.get_quotes_by_group_and_author(
                    group_id, qq_id,
                )
            )
            daily_counts: List[int] = []
            current_date = fifteen_days_ago
            while current_date <= today_start:
                next_day = current_date + datetime.timedelta(days=1)
                cnt = sum(
                    1 for q in all_quotes if q.time_stamp < next_day
                )
                daily_counts.append(cnt)
                current_date = next_day
            frontiers_series.append(daily_counts)

        line_chart_data = TemplateLineChartData(
            topN=top_n,
            dates=_generate_date_range_mm_dd(
                fifteen_days_ago.date(), today_start.date(),
            ),
            seriesData=frontiers_series,
        )

        # 渲染 HTML 并截图
        time_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        html = render_rank(TemplateRankingData(
            group_name=group_name,
            date_time=time_str,
            basic_ranking=ranking_data,
            line_chart=line_chart_data,
            stats=stats_data,
        ))
        img = await html_render_svc.render(
            html, width=RANK.width, height=RANK.height, wait=RANK.wait,
        )
        await matcher_get_ranking.finish(MsgSeg.image(img))
