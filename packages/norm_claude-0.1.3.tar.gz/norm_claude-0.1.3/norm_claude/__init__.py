"""
norm-claude: Situational awareness layer for Claude Code
Designed for lawyers and coding novices.
"""

__version__ = "0.1.3"
__author__ = "Nathan Igbokwe"
__email__ = "nigbokwe@norm.ai"
