# Scenario 1: Editing a Prompt File (Low Risk)

## Context
User asks: "Update my contract review prompt to check for force majeure clauses"

This is a **LOW RISK** action because it only involves editing a text/documentation file.

---

## Expected STATUS Output

```markdown
## STATUS REPORT

**Mode:** Editing

**What We Just Did:**
• Opened `contract_review_prompt.md` in your Documents/prompts folder
• Added instruction to check for force majeure clauses (lines 18-20)

**What Changed:**
• File: `~/Documents/prompts/contract_review_prompt.md` (saved with new instructions)

**What Did NOT Change:**
• No code executed
• No software installed
• No other files modified

**Risk Level:** Low — This is text editing only, like updating a Word document.

**If You Need to Undo This:**
1. Open the file and delete lines 18-20, or
2. Restore from Time Machine/backups, or
3. Ask me to revert to the previous version

**Safe Next Actions:**
• Review the changes to confirm they match your intent
• Test the prompt with a sample contract
• Continue editing or add more instructions

---
*Need clarity? Type /status anytime or ask "what changed?"*
```

**Word count:** ~145 words (within target)

---

## Key Reassurance Points

1. **Explicitly states no code ran:** Reduces fear that something executed without permission
2. **Uses Word doc analogy:** Relates to familiar tool
3. **Offers multiple undo paths:** Including non-technical option (Time Machine/Finder)
4. **Safe next actions are low-pressure:** "Review", "test", "continue" — no urgency

---

## Validation Checklist

- [ ] STATUS includes all 7 sections
- [ ] "What did NOT change" has 2-3 bullets (no code executed, no software installed, no other files)
- [ ] Risk level = Low with clear analogy
- [ ] Word count 120-160
- [ ] No jargon (all terms understandable)
- [ ] Rollback doesn't assume git (offers Finder/Time Machine alternatives)

---

## Why This Scenario Matters

This is the **confidence-builder scenario**. It shows that:
- Not everything is scary (Low risk exists!)
- STATUS reports are helpful even for simple actions
- "What did NOT change" provides reassurance
- Undo is always available, even for trivial changes

If users see this scenario and think "Oh, that's helpful and not overwhelming," Norm Mode is working.
