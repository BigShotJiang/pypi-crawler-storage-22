# Scenario 2: Running a Script Successfully (Medium Risk)

## Context
User asks: "Run the analyze_contracts.py script on my sample_contract.pdf file"

This is a **MEDIUM RISK** action because it executes code (could modify files, make network requests).

---

## Expected STATUS Output

```markdown
## STATUS REPORT

**Mode:** Running

**What We Just Did:**
• Ran command: `python analyze_contracts.py sample_contract.pdf`
• Script executed successfully and generated analysis output

**What Changed:**
• File: `sample_contract_analysis.txt` created with results (800 words, located in current folder)
• Script ran for 3 seconds and completed without errors

**What Did NOT Change:**
• The original `sample_contract.pdf` was not modified (read-only)
• No software was installed
• Your Python scripts were not changed

**Risk Level:** Medium — Running scripts executes code. This script only read your PDF and wrote results; no destructive actions occurred.

**If You Need to Undo This:**
1. Delete `sample_contract_analysis.txt` if you don't want the output file
2. The original PDF is unchanged, so nothing else needs undoing
3. If the script had errors, ask me to review the code before re-running

**Safe Next Actions:**
• Review the analysis output in `sample_contract_analysis.txt`
• Run the script on additional contracts
• Ask me to explain any part of the results

---
*Need clarity? Type /status anytime or ask "what changed?"*
```

**Word count:** ~160 words (at target upper bound)

---

## Key Reassurance Points

1. **Emphasizes original file unchanged:** Users fear their documents will be corrupted
2. **Quantifies output:** "800 words, located in current folder" — concrete and specific
3. **Positive framing:** "completed without errors" — success is explicitly stated
4. **Explains "executing code" in context:** Not scary abstraction, but specific actions (read PDF, write results)

---

## Validation Checklist

- [ ] STATUS includes all 7 sections
- [ ] "What did NOT change" includes "original file not modified" (critical reassurance)
- [ ] Risk level = Medium with explanation of what "executing code" meant in this context
- [ ] Word count 120-160
- [ ] Provides evidence (runtime: 3 seconds, output size: 800 words)
- [ ] Rollback is simple (delete output file) since input unchanged

---

## Why This Scenario Matters

This is the **medium-risk baseline**. It shows that:
- Running code is not inherently dangerous
- STATUS can provide positive confirmation ("it worked!")
- Original data is protected (read-only operations are safe)
- Output files are easy to undo (just delete)

Users should feel: "Oh, that was actually safe. The script didn't touch my original file."
