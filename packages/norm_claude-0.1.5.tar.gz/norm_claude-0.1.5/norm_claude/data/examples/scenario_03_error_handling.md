# Scenario 3: Error Handling with Stack Trace (Medium Risk)

## Context
User ran a script and hit an error: `ValueError: invalid literal for int() with base 10: 'abc'`

This is a **MEDIUM RISK** situation because code executed and failed (but didn't break anything).

---

## Expected ERROR_OPINION Output

```markdown
## ERROR OPINION

**Issue Identification:**
The script tried to convert text ('abc') into a number but failed because 'abc' is not a valid number.

**Error Message (Verbatim):**
```
Traceback (most recent call last):
  File "parse_dates.py", line 15, in <module>
    year = int(date_string)
ValueError: invalid literal for int() with base 10: 'abc'
```

**Analysis:**

1. **What This Error Means:**
   The code at line 15 in `parse_dates.py` is trying to use the `int()` function (which converts text to numbers) to turn the text 'abc' into a number. It can't do this because 'abc' is not a valid number. This is like asking Excel to sum cells that contain words instead of numbers.

2. **What Likely Caused This:**
   The variable `date_string` contained 'abc' (probably from malformed input data or a parsing error earlier in the script), and the code didn't check if it was a valid number before trying to convert it.

3. **What This Does NOT Mean:**
   • It does NOT mean Python is broken
   • It does NOT mean your entire script is wrong
   • It does NOT mean you lost any data — this error stopped execution before any changes

**Recommended Course of Action:**

**Primary Approach:**
1. Open `parse_dates.py` and look at line 15 to see what `date_string` should contain
2. Add a check before line 15: `if date_string.isdigit():` to validate the input
3. Add an else clause to handle invalid input gracefully (e.g., skip or log it)
4. Re-run the script

**Alternative Approach** (if Primary fails):
1. Print the value of `date_string` right before line 15 to see what's actually there
2. Trace back where `date_string` comes from to find the root cause
3. Fix the data source or add better error handling

**Risk Assessment:**
Low — Fixing this error only requires editing code. No data is at risk, and you can test changes safely.

**Precedent:**
This is extremely common when processing user input or external data. Every developer encounters this. It's a sign your code needs better input validation, which is a normal part of development.

---
*This is my professional opinion based on the error evidence. Let me know if you want me to proceed or if you have questions.*
```

---

## Key Reassurance Points

1. **Excel analogy:** Makes the error relatable to non-programmers
2. **"What This Does NOT Mean" section:** Explicitly addresses anxiety (Python isn't broken, data isn't lost)
3. **Normalizes the error:** "Every developer encounters this" — not a failure, but normal development
4. **Provides Primary + Alternative:** Like legal strategy options
5. **Risk of fix is Low:** Separate from risk of what caused error

---

## Validation Checklist

- [ ] ERROR_OPINION includes all 6 sections
- [ ] Error message is verbatim in code block
- [ ] Analysis has all 3 subsections (What Means, What Caused, What NOT)
- [ ] "What This Does NOT Mean" has 2-3 bullets addressing fears
- [ ] Primary + Alternative approaches provided
- [ ] Risk assessment is about the FIX, not the original error
- [ ] Precedent section normalizes the error
- [ ] Uses legal-opinion style language ("likely," "based on evidence")
- [ ] Excel analogy makes it understandable

---

## Why This Scenario Matters

This is the **error normalization scenario**. It shows that:
- Errors are not catastrophic
- Claude can translate technical errors into plain language
- "What did NOT mean" dispels worst-case fears
- Everyone hits these errors (not a personal failure)
- Errors provide information (they're clues, not punishments)

Users should feel: "Oh, this is fixable. I'm not alone. I didn't break anything."

---

## Common Variations

### Import Error (Module Not Found)
Same structure, but:
- Analogy: "Like opening a Word doc that references a template you don't have installed"
- Primary fix: Install missing library with pip
- Risk: High (installation)

### File Not Found Error
Same structure, but:
- Analogy: "Like double-clicking a shortcut to a file that's been moved"
- Primary fix: Check file path and current directory
- Risk: Low (no changes needed)

### Syntax Error
Same structure, but:
- Analogy: "Like a typo or grammar mistake in a legal document — the computer can't understand it"
- Primary fix: Fix the typo on the specified line
- Risk: Low (just editing)
