# Scenario 6: User Orientation ("I'm Lost") (Low Risk)

## Context
User says: "I'm not sure what's happening" or "What should I do now?" or just "/status"

This is a **LOW RISK** situation — user needs orientation, not action.

---

## Expected STATUS Output

```markdown
## STATUS REPORT

**Mode:** Reviewing

**What We Just Did:**
• Taking stock of where we are in the workflow
• No actions taken since last status check

**What Changed:**
• Nothing has changed since our last action (editing `contract_prompt.md` 5 minutes ago)

**What Did NOT Change:**
• All files remain as they were
• No commands have run
• Your system state is stable

**Risk Level:** Low — We're reviewing status. No changes are happening.

**Current Situation:**
We last edited a prompt file for contract review. That file is saved and ready to use. We haven't run any code or installed anything since then.

**Safe Next Actions:**
• Tell me what you'd like to accomplish next (I can suggest steps)
• Ask me to test the prompt we edited
• Take a break — nothing is in an unstable state
• Ask me to explain anything that's unclear

**If You Want to Understand Better:**
• Ask "What files have we touched?" — I'll list everything
• Ask "What's in this folder?" — I'll show you the contents
• Type /status anytime you need clarity

---
*You're in a safe place. Nothing is broken or unstable. Let me know how I can help.*
```

**Word count:** ~175 words (slightly over target, but acceptable for orientation scenario)

---

## Key Reassurance Points

1. **Explicitly states nothing is broken:** Addresses the fear behind "I'm lost"
2. **Validates the question:** "Taking stock" — not dismissive, this is legitimate
3. **Offers multiple paths forward:** Doesn't push user in one direction
4. **Low-pressure options:** "Take a break" is explicitly listed as safe
5. **Meta-commands provided:** Shows how to self-service clarity

---

## Validation Checklist

- [ ] STATUS includes all 7 sections
- [ ] "What did NOT change" emphasizes stability ("all files remain", "system state is stable")
- [ ] Risk level = Low (just reviewing)
- [ ] No jargon
- [ ] Safe next actions are diverse (not just "keep working")
- [ ] Explicitly states "nothing is broken"
- [ ] Offers meta-help ("ask what files we touched", "ask what's in folder")

---

## Why This Scenario is Critical

This is the **confidence checkpoint scenario**. It shows that:
- Asking "what's happening" is valid (not shameful)
- STATUS can be used for orientation, not just after actions
- System is stable (nothing is on fire)
- User has time to think (no urgency)
- There are multiple ways to get unblocked

Users should feel: "Oh, I can just ask for STATUS and get oriented. I'm not stupid for being confused."

---

## Common Variations

### User returns after hours/days
```markdown
**Current Situation:**
I can see your last session was 2 days ago. At that time, we were editing `contract_prompt.md`. That file is still saved. Nothing has changed since then — your system is in the same stable state.

**Safe Next Actions:**
• Tell me what you'd like to work on today
• Ask me to remind you what we were working on last time
• Start fresh with a new task
```

### Mid-multi-step task
```markdown
**Current Situation:**
We're in the middle of setting up a Python environment. So far we've:
1. Created the project folder
2. Created a virtual environment

**What's left:**
3. Install dependencies
4. Test the setup

Your system is stable. We can continue, pause, or start over.
```

### After complex session
```markdown
**Current Situation:**
We've made several changes in this session:
• Edited 3 files (contract_prompt.md, analyze.py, requirements.txt)
• Ran 2 scripts (both successful)
• Did NOT install anything or change config

Everything is saved. You can safely close this session or continue working.
```
