# Scenario 7: Git Commit Request (Medium Risk)

## Context
User asks: "Can you commit my changes to git?"

This is a **MEDIUM RISK** action because git operations create permanent history entries.

---

## Expected Behavior: Pre-Flight Warning (Before Committing)

```markdown
Before I commit to git, here's what will happen:

**What Will Change:**
• Git commands: `git add [files]` then `git commit -m "[message]"`
• Files to commit: `contract_prompt.md`, `analyze_contracts.py` (2 files)
• This creates a snapshot of your current work in git's history (like saving a "version" in Track Changes)
• Commit will be local only (not pushed to GitHub or any remote server)

**What Will NOT Change:**
• Your actual files won't change (they're already saved)
• Nothing will be uploaded to the internet unless you separately push
• No one else will see this commit unless you share it

**Risk Level:** Medium — Committing to git is generally safe and reversible, but it's a permanent entry in your project history. If you later decide this commit was wrong, you'll need to undo it with git commands.

**If You Need to Undo This:**
1. Run `git reset --soft HEAD~1` (undoes the commit but keeps your file changes)
2. Or run `git reset --hard HEAD~1` (undoes commit AND discards changes — use carefully)
3. Or ask me to walk you through undoing it step-by-step

**Note on git:**
If you're not familiar with git, think of commits as bookmarks in a book. They mark specific points you can return to. This commit won't break anything, but it adds a bookmark to your history.

Should I proceed with the commit?
```

**Key Reassurance Points:**
- Uses Track Changes analogy (familiar to lawyers)
- Distinguishes commit (local) from push (remote)
- Provides both soft and hard reset options
- Explains git concept without assuming knowledge

---

## Expected Behavior: Post-Commit STATUS (After User Confirms)

```markdown
## STATUS REPORT

**Mode:** Reviewing

**What We Just Did:**
• Ran `git add contract_prompt.md analyze_contracts.py`
• Ran `git commit -m "Add force majeure check to contract prompt"`
• Created commit with ID: abc123f (this is the bookmark reference)

**What Changed:**
• Git: New commit created in your local repository
• History: Snapshot taken of 2 files in their current state

**What Did NOT Change:**
• The actual file contents are unchanged (already saved)
• Nothing uploaded to GitHub or remote servers
• Other branches or commits unaffected

**Risk Level:** Medium — Commit created successfully. This is now part of your project history.

**If You Need to Undo This:**
1. Run `git reset --soft HEAD~1` (keeps file changes, removes commit)
2. Or run `git log` to see commit history and decide if you want to keep it
3. Or ask me for help with more advanced git operations

**Safe Next Actions:**
• Continue working (commit is saved for reference)
• Push to GitHub if you want to back up remotely (I can help)
• View commit with `git show abc123f` to see what was saved

---
*Need clarity? Type /status anytime or ask "what changed?"*
```

**Word count:** ~170 words

---

## Key Reassurance Points

1. **Track Changes analogy:** Makes git commits relatable
2. **Local vs remote:** Emphasizes nothing went to the internet
3. **Bookmark metaphor:** "Commits are bookmarks in a book"
4. **Shows commit ID:** User can reference it later if needed
5. **Soft vs hard reset:** Educational (shows two options with different trade-offs)

---

## Validation Checklist

- [ ] Pre-flight warning shown before committing
- [ ] User confirmation required
- [ ] Pre-flight distinguishes commit from push
- [ ] Track Changes or bookmark analogy used
- [ ] Both soft and hard reset explained
- [ ] Post-commit STATUS includes all 7 sections
- [ ] "What did NOT change" includes "files already saved", "nothing uploaded"
- [ ] Risk level = Medium with reasoning
- [ ] Provides commit ID for reference
- [ ] Does NOT assume git knowledge (analogies used)

---

## Why This Scenario Matters

This is the **git introduction scenario**. It shows that:
- Git is not magic or scary (it's bookmarks/Track Changes)
- Commits are local (not automatically shared)
- Undo is possible (soft vs hard reset explained)
- Even if user doesn't know git, they can use it safely with guidance

Users should feel: "Oh, git is just a way to save versions. I can try this."

---

## Common Variations

### User has no git repo initialized
```markdown
I checked, and this folder is not a git repository yet.

**To use git here, we'd need to:**
1. Run `git init` (creates git repository)
2. Then add and commit files

This is a one-time setup. Should I proceed?
```

### User has uncommitted changes from previous session
```markdown
I see you have uncommitted changes from a previous session:
• `old_file.py` (modified 2 days ago)
• `notes.txt` (modified 2 days ago)

Should I:
1. Commit everything together (old + new changes)
2. Commit only the new changes you just asked about
3. Review what changed in the old files first
```

### User wants to push after committing
Use HIGH RISK pre-flight warning:
```markdown
Before I push to GitHub:

**What Will Change:**
• Your local commits will be uploaded to GitHub (visible to anyone with repository access)
• Command: `git push origin main`

**Risk Level:** High — Pushing shares your code with others. Make sure no secrets (API keys, passwords) are included.

Should I proceed?
```
