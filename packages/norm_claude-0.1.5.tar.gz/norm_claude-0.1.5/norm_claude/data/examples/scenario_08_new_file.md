# Scenario 8: Creating a New File (Low-Medium Risk)

## Context
User asks: "Create a new script called extract_clauses.py that finds liability clauses"

This is a **LOW-MEDIUM RISK** action because it creates a new file with code (not destructive, but code could be run later).

---

## Expected STATUS Output

```markdown
## STATUS REPORT

**Mode:** Editing

**What We Just Did:**
• Created a new file: `extract_clauses.py` in your current folder
• Wrote 45 lines of Python code to search for liability clauses in text

**What Changed:**
• File: `~/legal-tools/extract_clauses.py` created (new file, ~1.5KB)
• Code includes a function to parse text and identify liability language

**What Did NOT Change:**
• No existing files were modified
• No code was executed (file created, not run)
• No software installed

**Risk Level:** Low-Medium — Creating new files is low risk, but this file contains code. If you run it later, that becomes medium risk (executing code).

**If You Need to Undo This:**
1. Delete the file: `rm extract_clauses.py` or delete via Finder
2. Or move it to trash: `mv extract_clauses.py ~/.Trash/`
3. Or rename it to deactivate: `mv extract_clauses.py extract_clauses.py.backup`

**Safe Next Actions:**
• Review the code in the file to understand what it does
• Ask me to explain how the clause extraction works
• Test it on a sample document (this will be medium risk when you run it)

---
*Need clarity? Type /status anytime or ask "what changed?"*
```

**Word count:** ~185 words (slightly over, but acceptable for code creation)

---

## Key Reassurance Points

1. **Distinguishes creating from running:** "file created, not run" — reduces fear
2. **Offers non-technical undo:** Finder drag-to-trash (not just command line)
3. **Preview future risk:** "If you run it later, that becomes medium risk" — sets expectations
4. **Encourages review:** "Review the code" is first safe next action

---

## Validation Checklist

- [ ] STATUS includes all 7 sections
- [ ] "What did NOT change" includes "no code executed", "no existing files modified"
- [ ] Risk level = Low-Medium with clear distinction (creating vs running)
- [ ] Word count close to target (under 200)
- [ ] Undo includes non-technical option (Finder)
- [ ] Safe next actions include "review" before "run"
- [ ] File size quantified (~1.5KB, 45 lines)

---

## Why This Scenario Matters

This is the **creation vs execution scenario**. It shows that:
- Creating code files is safer than running them
- Undo is simple (just delete)
- User should review before running (educational nudge)
- Risk increases when code is executed (not just created)

Users should feel: "Oh, I can create code files safely. I'll review before running."

---

## Common Variations

### Creating a configuration file
```markdown
**Risk Level:** Medium — Config files control app behavior, even though no code runs.
```

### Creating a test file
```markdown
**Risk Level:** Low — Test files are designed to be run safely (they test other code without modifying production data).
```

### Creating a data file (CSV, JSON, etc.)
```markdown
**Risk Level:** Low — Data files don't execute. They're like creating a spreadsheet.
```

### Creating a requirements.txt or package.json
```markdown
**Risk Level:** Low — Dependency lists don't execute. They're just documentation until you run `pip install` or `npm install` (which is high risk).

**Safe Next Actions:**
• Review the dependencies listed
• Research any unfamiliar packages before installing
• Ask me what each dependency does
```

### User wants to run the new file immediately
Provide Medium Risk pre-flight:
```markdown
Before I run the new script:

**What Will Happen:**
• Command: `python extract_clauses.py sample.txt`
• The code we just created will execute
• It will read `sample.txt` and search for liability clauses

**Risk Level:** Medium — Running code can modify files or make network requests. This script only reads and prints results, but it's good practice to review code before running.

Should I proceed?
```
