# Scenario 9: Debugging Session (Multiple Actions)

## Context
User has been debugging a script for 10 minutes with multiple actions taken. User asks: "Where are we now?"

This scenario tests STATUS ability to **summarize multi-step sessions** concisely.

---

## Expected STATUS Output

```markdown
## STATUS REPORT

**Mode:** Debugging

**What We Just Did (Last 10 Minutes):**
• Ran `test_parser.py` three times to diagnose an error
• Edited `test_parser.py` twice to add print statements for debugging (lines 8, 15)
• Identified the issue: input file has wrong encoding (UTF-16 instead of UTF-8)

**What Changed:**
• File: `test_parser.py` modified (2 debugging print statements added)
• Commands: Ran script 3 times (read-only, no data changed)
• Status: Error identified but not yet fixed

**What Did NOT Change:**
• Your data files remain unchanged
• No dependencies installed
• Main application code (`parser.py`) not modified yet

**Risk Level:** Low — Debugging so far has only involved reading and printing. We haven't fixed the encoding issue yet (that will be medium risk when we edit `parser.py`).

**Where We Are:**
We've narrowed down the problem: your script expects UTF-8 encoded text files, but the input file uses UTF-16. Next step would be to update `parser.py` to handle both encodings.

**If You Need to Undo This:**
1. Remove the print statements from `test_parser.py` (lines 8, 15) if you don't want them
2. Or keep them for future debugging
3. No critical changes to undo — everything is safe

**Safe Next Actions:**
• Proceed with fixing the encoding issue in `parser.py` (I'll show you before changing)
• Convert your input file to UTF-8 instead of modifying code
• Take a break — we're at a stable checkpoint

---
*Need clarity? Type /status anytime or ask "what changed?"*
```

**Word count:** ~220 words (over target, but acceptable for multi-step summary)

---

## Key Reassurance Points

1. **Summarizes session:** "Last 10 minutes" — shows Claude is tracking context
2. **Shows progress:** "Error identified" — not stuck, making progress
3. **Marks checkpoint:** "We're at a stable checkpoint" — safe to pause
4. **Previews next risk:** "that will be medium risk when we edit parser.py"
5. **Optional cleanup:** Print statements can stay or be removed

---

## Validation Checklist

- [ ] STATUS includes all 7 sections
- [ ] Summary of multiple actions (ran 3 times, edited twice)
- [ ] "What did NOT change" includes data files, dependencies, main code
- [ ] Risk level = Low (so far) with preview of next risk
- [ ] "Where We Are" section provides progress summary
- [ ] Undo is optional (debugging changes can stay)
- [ ] Safe next actions include "take a break" (acknowledges mental load)
- [ ] Word count acceptable for complex scenario (under 250)

---

## Why This Scenario is Critical

This is the **session summary scenario**. It shows that:
- STATUS can handle multi-step workflows (not just single actions)
- Progress is being made (error identified)
- User can pause at stable checkpoints
- Next step's risk is previewed (medium risk edit coming)
- Debugging is normal work (not failure)

Users should feel: "Oh, I'm making progress. I can see where we are and where we're going. I can pause if needed."

---

## Common Variations

### Long session with many actions
```markdown
**What We Just Did (Last Hour):**
• Created 3 new files (script.py, config.yaml, README.md)
• Installed 2 libraries (pandas, requests)
• Ran script successfully twice
• Fixed one bug (import error)

**Summary:** Your project is set up and working. All files saved.
```
Prioritize most important changes, not exhaustive list.

### Session interrupted and resumed
```markdown
**What We Just Did:**
• Resuming from 2 days ago
• Last action was editing `contract_prompt.md`
• That file is still saved; nothing changed since then

**Where We Are:**
Your project is in the same stable state as when you left. Nothing has changed. We can continue where we left off or start something new.
```

### Complex error still unresolved
```markdown
**Where We Are:**
We've tried 3 approaches to fix the error, but it persists. The issue appears to be with the library itself, not your code.

**What Did NOT Change:**
• Your original code is intact
• No data was lost
• We can safely try other approaches or seek help

**Safe Next Actions:**
• Research if others have hit this error (I can search)
• Try a different library
• Ask for help from the library maintainers
```
Frame as "puzzle to solve", not "we failed".

### Successful multi-step task completion
```markdown
**What We Just Did (Last 30 Minutes):**
• Set up Python virtual environment
• Installed all dependencies (5 libraries)
• Created main script (`analyze.py`)
• Tested successfully on sample data

**Summary:** Your project is fully set up and working. You can now use it for real tasks.

**Risk Level:** Medium — Setup is complete. Running on real data will be the same medium risk as testing.
```
Celebrates completion, sets expectations for next phase.
