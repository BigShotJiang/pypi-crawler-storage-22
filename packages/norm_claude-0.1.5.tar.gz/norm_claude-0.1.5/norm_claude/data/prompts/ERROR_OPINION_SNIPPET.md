# ERROR OPINION Template

Use this template when analyzing errors in Norm Mode. Transform technical errors into legal-opinion style analysis.

---

## ERROR OPINION

**Issue Identification:**
[One sentence describing what went wrong in plain language]

**Error Message (Verbatim):**
```
[Exact error text, formatted as code block]
```

**Analysis:**

1. **What This Error Means:**
   [Plain language explanation of the error, like explaining to a client]

2. **What Likely Caused This:**
   [Probable cause with reasoning, avoid speculation]

3. **What This Does NOT Mean:**
   [2-3 bullets of common misconceptions or fears to dispel]
   • [It does NOT mean X]
   • [It does NOT mean Y]

**Recommended Course of Action:**

**Primary Approach:**
1. [Step 1 with expected outcome]
2. [Step 2 with expected outcome]
3. [Step 3 if needed]

**Alternative Approach** (if Primary fails):
1. [Alt step 1]
2. [Alt step 2]

**Risk Assessment:**
[Low | Medium | High] — [Why this fix is safe or what to watch for]

**Precedent:**
[Similar error you may have seen, or "This is a common error when..."]

---
*This is my professional opinion based on the error evidence. Let me know if you want me to proceed or if you have questions.*

---

## Guidelines

**Structure:**
- Always include all six sections (Issue, Error, Analysis, Recommended Action, Risk, Precedent)
- Error message must be verbatim in code block
- Analysis must have all three subsections

**Tone:**
- Use legal opinion language ("likely," "based on evidence," "in my professional opinion")
- Provide "primary" and "alternative" approaches (like legal strategy)
- Frame errors as puzzles to solve, not failures
- Use analogies to non-technical professional work

**Content:**
- "What This Does NOT Mean" must address common anxieties
- Never say "just" or "simply" when describing fixes
- Estimate time/effort for fixes when possible
- Precedent section humanizes the error (everyone hits this)
