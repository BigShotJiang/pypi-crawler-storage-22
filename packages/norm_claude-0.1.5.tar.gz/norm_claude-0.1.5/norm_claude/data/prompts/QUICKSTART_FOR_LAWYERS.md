# Norm Mode for Claude Code — Quickstart for Lawyers

Welcome to Norm Mode! This guide will help you use Claude Code with confidence, even if you're new to programming.

---

## What is Norm Mode?

Norm Mode is a special way to use Claude Code that provides extra safety and clarity. It's designed for people who aren't programmers but need to build small tools or automate tasks.

**Key features:**
- Always tells you what changed AND what didn't change
- Explains risks before taking action
- Provides clear undo steps (without assuming you know git)
- Uses plain language instead of jargon

---

## Getting Started

### Option 1: Using the CLI Wrapper (Recommended)
```bash
norm-claude
```
This launches Claude Code with Norm Mode automatically enabled.

### Option 2: Manual Setup
1. Start Claude Code normally
2. Copy and paste the contents of `NORM_MODE_SYSTEM_PROMPT.md` into your first message
3. Claude will now operate in Norm Mode for this session

---

## Key Commands

While using Claude Code in Norm Mode, you can type these special commands as plain text (no slash needed):

**Note:** These are plain text commands, not slash commands. Type them without the `/` prefix to avoid conflicts with Claude Code's built-in commands.

### `status`
**When to use:** Anytime you're confused or want to understand what just happened

**What it does:** Shows you a STATUS report with:
- What we just did
- What changed on your computer
- What did NOT change (reassurance)
- How risky the action was
- How to undo it
- Safe next steps

**Example:**
```
You: status
```

### `opinion`
**When to use:** After seeing an error message

**What it does:** Translates the error into plain language, explains what it does NOT mean (to reduce anxiety), and suggests how to fix it

**Example:**
```
You: opinion
```

### `explain [term]`
**When to use:** When you encounter a technical term you don't understand

**What it does:** Defines the term in plain language

**Example:**
```
You: explain virtual environment
```

### `risk`
**When to use:** When you want to understand how risky the last action was

**What it does:** Explains the risk level (Low/Medium/High) and why

---

## Understanding Risk Levels

Norm Mode labels every action with a risk level to help you make informed decisions:

### Low Risk (Green Light)
- Reading files
- Viewing code
- Editing documentation or comments
- Asking for explanations

**Example:** "Can you show me what's in this file?"

### Medium Risk (Yellow Light)
- Editing code files
- Running scripts
- Creating new files
- Git commits

**What to know:** These actions change your project but are usually reversible. Claude will tell you how to undo them.

**Example:** "Update this function to handle edge cases"

### High Risk (Red Light)
- Installing software (pip, npm, brew, etc.)
- Editing configuration files (.env, config.yaml, etc.)
- Deleting files
- Changing system settings

**What to know:** These actions affect your environment or system. Claude will ask for permission before proceeding and will explain exactly what will change.

**Example:** "Install the pandas library"

---

## What to Expect

### Before High-Risk Actions
Claude will show you:
- What will change
- What will NOT change
- Risk level and why
- How to undo it
- Then ask: "Should I proceed?"

**You're in control.** Review the information and respond "yes" to proceed or "no" to skip.

### After Any Action
Claude will provide a STATUS report showing:
- What just happened
- What changed
- **What did NOT change** (this is important!)
- How to undo it if needed
- Safe next steps

### If You're Ever Confused
Just type `status` or ask "What's happening?" Claude will give you a clear picture of where you are.

---

## Common Scenarios

### "I'm not sure what's happening"
```
You: What's happening? or status
Claude: [Provides STATUS report showing current state, what changed, what didn't change, and safe next steps]
```

### "Something went wrong and I see an error"
```
You: opinion
Claude: [Provides ERROR OPINION explaining the error in plain language, what it does NOT mean, and how to fix it]
```

### "Can I undo what we just did?"
```
You: How do I undo this?
Claude: [Provides step-by-step rollback instructions that don't assume git knowledge]
```

### "I want to take a break but I'm not sure if it's safe"
```
You: Is everything in a stable state? Can I close this?
Claude: [Provides STATUS report confirming system is stable or warning if action is incomplete]
```

---

## Safety Tips

1. **Read before confirming:** When Claude asks "Should I proceed?" for high-risk actions, read the details first

2. **Use status frequently:** It's like checking a map — helps you stay oriented

3. **Ask for explanations:** If something is unclear, ask! There are no dumb questions

4. **One step at a time:** Don't rush. Make sure you understand each action before moving to the next

5. **Backups are your friend:** If you're working on important files, keep backups (Time Machine on Mac, or manual copies)

---

## What Norm Mode Does NOT Do

- **Does not assume you know git:** All undo instructions work without git (though git is mentioned as an optional tool)
- **Does not use jargon without explaining:** Every technical term gets defined inline
- **Does not skip "what didn't change":** You'll always see explicit reassurance about what stayed safe
- **Does not rush you:** Takes time to explain and get confirmation for risky actions

---

## Troubleshooting

### "Claude isn't providing STATUS reports"
- Make sure you loaded the Norm Mode system prompt at the start of your session
- Or use `norm-claude` CLI to launch with Norm Mode pre-loaded

### "I want more detail about a technical term"
- Type `explain [term]` to get a plain-language definition

### "I'm worried I broke something"
- Type `status` to see what changed
- Claude will tell you how to undo it if needed
- Remember: "What did NOT change" section shows what's still safe

---

## Getting Help

- **In-session:** Type `status` to understand current state
- **For errors:** Type `opinion` to get error analysis
- **For terms:** Type `explain [term]` for definitions
- **Anytime:** Just ask "Can you explain this?" or "What should I do?"

---

## Remember

You're not expected to understand everything about programming. Norm Mode is here to help you work safely and confidently. When in doubt, ask for STATUS or OPINION — that's what they're for.

**You're doing great.** Taking the time to learn this tool shows initiative and courage. Keep asking questions, and you'll build confidence quickly.

---

*Questions or feedback? Let Claude know in your session, or reach out to your team lead.*
