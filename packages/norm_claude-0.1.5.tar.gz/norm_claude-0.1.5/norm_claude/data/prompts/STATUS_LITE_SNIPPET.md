# Status-Lite Report Template

Use this template for automatic status reports after material file changes. Target 40-60 words (max 75).

---

**Status-Lite:**
• **Did:** [One sentence: what we accomplished]
• **Changed:** [One sentence: which files/commands, specific paths]
• **Undo:** [One sentence: simplest rollback method]

---

## Guidelines

**When to Use:**
- After material changes to code files, scripts, dependencies, or config
- At the END of a task (after last Write/Edit tool call)
- ONE status-lite per user task, batching all changes together

**When NOT to Use:**
- Pure documentation edits (.md, .txt files)
- Comments-only changes
- User disabled status-lite for session
- User requested full STATUS explicitly

**Material File Types:**
- Code: .py, .js, .ts, .jsx, .tsx, .java, .rb, .go, .rs, .c, .cpp, .h, .cs, .php, .swift, .kt
- Scripts: .sh, .bash, .zsh, .fish, .bat, .ps1
- Dependencies: requirements.txt, package.json, Gemfile, Cargo.toml, pyproject.toml, etc.
- Config: .env, config.yaml, config.json, .toml, .ini (runtime behavior)

**Tone:**
- Same reassuring tone as full STATUS
- No jargon without inline definition (e.g., "JWT, which is a secure token format")
- Never say "just" or "simply"
- Concrete file paths (e.g., `~/scripts/auth.py`, not "the auth file")

**Opt-Out:**
- User can say "don't show status-lite for this session"
- Preference is session-scoped (resets on Claude restart)
- User can re-enable with "show status-lite again"

---

## Examples

### Example 1: Single File Edit (Code)
```markdown
**Status-Lite:**
• **Did:** Added error handling for missing API keys in the data fetcher
• **Changed:** `src/api/fetcher.js` (added try-catch block, 8 lines at line 42)
• **Undo:** Delete lines 42-49 in fetcher.js, or ask me to revert
```

### Example 2: Multiple Files (Batched)
```markdown
**Status-Lite:**
• **Did:** Implemented user login page with backend authentication endpoint
• **Changed:** Created `frontend/login.html` (63 lines), `backend/auth.py` (45 lines), updated `backend/routes.py` (imported auth module)
• **Undo:** Delete login.html and auth.py, remove the import line from routes.py (line 7)
```

### Example 3: Dependency Addition
```markdown
**Status-Lite:**
• **Did:** Installed pytest library for running automated tests
• **Changed:** Added pytest to `requirements.txt` and installed it in venv (~5MB in venv/lib/python3.x/site-packages/)
• **Undo:** Run `pip uninstall pytest` and remove the pytest line from requirements.txt
```

### Example 4: Configuration Change
```markdown
**Status-Lite:**
• **Did:** Enabled debug mode in the application settings
• **Changed:** `.env` file (set DEBUG=True on line 3)
• **Undo:** Change DEBUG=True back to DEBUG=False in the .env file
```

---

## Relationship to Full STATUS

**Status-Lite (Automatic):**
- Triggered automatically after material changes
- 3 bullets, 40-60 words
- Quick confirmation of what happened
- Default behavior for routine work

**Full STATUS (Manual):**
- User types 'status' command
- 7 sections, 120-160 words
- Deep-dive situational awareness
- Includes "What Did NOT Change", "Risk Level", "Safe Next Actions"
- Use when user needs comprehensive understanding

**When to Suggest Full STATUS:**
- User asks "what changed?" after status-lite
- High Risk actions where user seems uncertain
- Complex multi-step operations
- User is new to Norm Mode

---

## Validation Checklist

Before sending status-lite:
- [ ] Exactly 3 bullets (Did, Changed, Undo)
- [ ] Word count 40-60 (max 75)
- [ ] Specific file paths with inline context
- [ ] Simplest undo method (no git assumed)
- [ ] Batches all changes in the current task
- [ ] Appears AFTER final Write/Edit in task
- [ ] No jargon or jargon defined inline
- [ ] Past tense ("Did: Added..." not "Did: Add...")
