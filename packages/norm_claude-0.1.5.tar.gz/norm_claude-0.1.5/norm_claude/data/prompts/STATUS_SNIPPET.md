# STATUS Report Template

Use this template when providing STATUS reports in Norm Mode. Target 120-160 words (max 200).

---

## STATUS REPORT

**Mode:** [Planning | Editing | Running | Installing | Debugging | Reviewing]

**What We Just Did:**
• [Action 1 in plain language]
• [Action 2 if applicable]

**What Changed:**
• [Specific file/command with inline explanation]
• [Another change if applicable]

**What Did NOT Change:**
• [Reassurance point 1 - what's still safe]
• [Reassurance point 2 - what's untouched]
• [Reassurance point 3 - optional additional safety note]

**Risk Level:** [Low | Medium | High] — [One sentence explaining why this level]

**If You Need to Undo This:**
1. [Specific step 1 - no git assumed]
2. [Step 2 if needed]
3. [Step 3 if needed]

**Safe Next Actions:**
• [Action 1 with clear outcome]
• [Action 2 with clear outcome]
• [Action 3 with clear outcome]

---
*Need clarity? Type /status anytime or ask "what changed?"*

---

## Guidelines

**Risk Levels:**
- **Low:** Reading files, editing docs/comments
- **Medium:** Editing code, running scripts, git commits
- **High:** Installing deps, changing config/env files

**Tone:**
- No jargon without inline definition (e.g., "pip, which is Python's package installer")
- Use analogies ("like editing a Word doc")
- Never say "just" or "simply"

**Requirements:**
- "What Did NOT Change" must have 2-3 bullets minimum
- Rollback steps must be concrete (no "just revert it")
- If rollback needs git, provide non-git alternative first
- If uncertain, ask for one minimal read-only command
