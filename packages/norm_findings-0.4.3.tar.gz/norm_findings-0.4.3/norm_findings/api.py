import os
import json
import importlib
import importlib.util
from pathlib import Path
try:
    from importlib.resources import files  # Python 3.9+
except ImportError:
    from importlib_resources import files  # Fallback for older Python
from norm_findings.stubs.models import Test
from norm_findings.stubs.utils import serialize_finding

def _load_parser_mapping():
    """Load parser mapping from package resources"""
    try:
        # Try to load from package resources (works when installed)
        mapping_text = files('norm_findings').joinpath('parser_mapping.json').read_text()
        return json.loads(mapping_text)
    except Exception:
        # Fallback to file path (works in development)
        mapping_path = os.path.join(os.path.dirname(__file__), "parser_mapping.json")
        if os.path.exists(mapping_path):
            with open(mapping_path, 'r') as f:
                return json.load(f)
    return {}

import logging
import io

def parse_findings(parser_name: str, input_file: str, test_label: str = None, output_file: str = None, return_details: bool = False) -> list:
    """
    Standard function to receive parser name (case-insensitive) and input/output file names, and return findings.
    
    If return_details is True, returns a dictionary:
    {
        'findings': list[Finding],
        'errors': list[str], # Captured log warnings/errors
        'success': bool # True if no errors, or partial success with findings
    }
    Otherwise, returns list[Finding].
    """
    # Setup capturing logger if details requested
    log_capture = None
    log_handler = None
    if return_details:
        log_capture = io.StringIO()
        log_handler = logging.StreamHandler(log_capture)
        log_handler.setLevel(logging.WARNING)
        # Capture logs from the parser package
        logging.getLogger('norm_findings.parsers').addHandler(log_handler)

    try:
        # 1. Load the parser mapping to find the file
        mapping = _load_parser_mapping()
        
        # ... [Unchanged loading logic] ...
        # (This is a simplified replacement for brevity, in reality we keep the original logic)
        # To avoid deleting code, I should probably use replace_file_content carefully or just rewrite the function body
        # Let's assume I am rewriting the whole function for safety as I'm adding a param and wrapping everything.
        
        # 2. Determine module path and class name (case-insensitive)
        parser_key = parser_name[:-6] if parser_name.lower().endswith('parser') else parser_name
        mapping_lower = {k.lower(): (k, v) for k, v in mapping.items()}
        
        parser_path = None
        actual_parser_key = None
        
        if parser_name.lower() in mapping_lower:
            actual_parser_key, parser_path = mapping_lower[parser_name.lower()]
        elif parser_key.lower() in mapping_lower:
            actual_parser_key, parser_path = mapping_lower[parser_key.lower()]
        
        parser_key = actual_parser_key if actual_parser_key else parser_key
        base_module_name = f"norm_findings.parsers.{parser_key.lower()}.parser"

        # 3. Load the module
        try:
            module = importlib.import_module(base_module_name)
        except ImportError:
            if not parser_path:
                 parser_path = os.path.join(os.path.dirname(__file__), "parsers", parser_key.lower(), "parser.py")
            
            if os.path.exists(parser_path):
                spec = importlib.util.spec_from_file_location(base_module_name, os.path.abspath(parser_path))
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
            else:
                raise ValueError(f"Could not find parser: {parser_name}")

        # 4. Instantiate parser
        ParserClass = None
        possible_names = [f"{parser_key}Parser", parser_key, parser_name]
        class_map = {}
        for attr in dir(module):
            obj = getattr(module, attr)
            if isinstance(obj, type):
                class_map[attr.lower()] = obj
        
        for possible_name in possible_names:
            if possible_name.lower() in class_map:
                ParserClass = class_map[possible_name.lower()]
                break
        
        if not ParserClass:
            for attr_lower, obj in class_map.items():
                if attr_lower.endswith('parser'):
                    ParserClass = obj
                    break
        
        if not ParserClass:
            raise ValueError(f"Could not find parser class for: {parser_name}. Available parsers: {list(mapping.keys())}")

        parser_instance = ParserClass()

        # 5. Prepare test object
        test_obj = Test(product=test_label or "Standardized Parse")

        # 6. Call get_findings
        with open(input_file, 'rb') as f:
            findings = parser_instance.get_findings(f, test_obj)

        # 7. Convert findings
        if findings is not None:
            findings = list(findings)
        else:
            findings = []

        # Serialize findings to pure JSON objects (dicts)
        # This ensures no internal objects (Finding, Test, Product) leak to the API consumer
        # We use a round-trip to guarantee compatibility with the file output format
        findings = json.loads(json.dumps(findings, default=serialize_finding))

        # 8. Write output
        if output_file:
            with open(output_file, 'w') as f:
                json.dump(findings, f, indent=4) # No default needed, already serializable

        if return_details:
            errors = []
            if log_capture:
                 errors = [line for line in log_capture.getvalue().splitlines() if line]
            
            return {
                'findings': findings,
                'errors': errors,
                'success': len(errors) == 0
            }

        return findings

    finally:
        if log_handler:
            logging.getLogger('norm_findings.parsers').removeHandler(log_handler)
            log_capture.close()
