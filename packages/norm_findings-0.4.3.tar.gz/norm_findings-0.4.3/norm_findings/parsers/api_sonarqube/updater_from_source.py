# Converted from DefectDojo parser
import typing
import datetime
# Required stubs: Risk_Acceptance, Finding

import logging
from norm_findings.stubs.django.utils import timezone
from norm_findings.stubs.models import Finding, Risk_Acceptance
from .importer import SonarQubeApiImporter
logger = logging.getLogger(__name__)

class SonarQubeApiUpdaterFromSource():
    "\n    The responsibility of this class is to update the Finding status if current SonarQube issue status doesn't match.\n\n    This way, findings will be updated based on SonarQube information when SonarQube is updated manually and\n    already imported in DefectDojo.\n    "

    @staticmethod
    def get_findings_to_update():
        return Finding.objects.filter(sonarqube_issue__isnull=False, active=True).select_related('sonarqube_issue')

    def update(self, finding):
        sonarqube_issue = finding.sonarqube_issue
        if (not sonarqube_issue):
            return
        (client, _) = SonarQubeApiImporter.prepare_client(finding.test)
        issue = client.get_issue(sonarqube_issue.key)
        if issue:
            current_status = (issue.get('resolution') or issue.get('status'))
            current_finding_status = self.get_sonarqube_status_for(finding)
            logger.debug('--> SQ Current status: %s. Finding status: %s', current_status, current_finding_status)
            if (current_status not in {'OPEN', current_finding_status}):
                logger.info("Original SonarQube issue '%s' has changed. Updating DefectDojo finding '%s'...", sonarqube_issue, finding)
                self.update_finding_status(finding, current_status)

    @staticmethod
    def get_sonarqube_status_for(finding):
        target_status = None
        if finding.false_p:
            target_status = 'FALSE-POSITIVE'
        elif (finding.mitigated or finding.is_mitigated):
            target_status = 'FIXED'
        elif finding.risk_accepted:
            target_status = 'WONTFIX'
        elif finding.active:
            target_status = ('CONFIRMED' if finding.verified else 'REOPENED')
        return target_status

    @staticmethod
    def update_finding_status(finding, sonarqube_status):
        if (sonarqube_status in {'OPEN', 'REOPENED'}):
            finding.active = True
            finding.verified = False
            finding.false_p = False
            finding.mitigated = None
            finding.is_mitigated = False
            ra_helper.remove_finding.from_any_risk_acceptance(finding)
        elif (sonarqube_status == 'CONFIRMED'):
            finding.active = True
            finding.verified = True
            finding.false_p = False
            finding.mitigated = None
            finding.is_mitigated = False
            ra_helper.remove_finding.from_any_risk_acceptance(finding)
        elif (sonarqube_status == 'FIXED'):
            finding.active = False
            finding.verified = True
            finding.false_p = False
            finding.mitigated = timezone.now()
            finding.is_mitigated = True
            ra_helper.remove_finding.from_any_risk_acceptance(finding)
        elif (sonarqube_status == 'WONTFIX'):
            finding.active = False
            finding.verified = True
            finding.false_p = False
            finding.mitigated = None
            finding.is_mitigated = False
            Risk_Acceptance.objects.create(owner=finding.reporter).accepted_findings.set([finding])
        elif (sonarqube_status == 'FALSE-POSITIVE'):
            finding.active = False
            finding.verified = False
            finding.false_p = True
            finding.mitigated = None
            finding.is_mitigated = False
            ra_helper.remove_finding.from_any_risk_acceptance(finding)
        finding.save(issue_updater_option=False, dedupe_option=False)
