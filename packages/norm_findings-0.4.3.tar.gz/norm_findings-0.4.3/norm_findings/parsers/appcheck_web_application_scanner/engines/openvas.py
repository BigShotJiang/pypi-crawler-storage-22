
import typing
import datetime
from norm_findings.parsers.appcheck_web_application_scanner.engines.base import BaseEngineParser
import logging
logger = logging.getLogger(__name__)

class OpenVASScannerEngineParser(BaseEngineParser):
    '\n    Parser for data from the OpenVAS scanning engine.\n\n    Shares all functionality with BaseEngineParser, but registered under an explicit name.\n    '
    SCANNING_ENGINE = 'OpenVASScanner'
