
import typing
import datetime
import json
import logging
import re
from json.decoder import JSONDecodeError
from norm_findings.stubs.models import Finding
from norm_findings.stubs.utils import parse_cvss_data
logger = logging.getLogger(__name__)

class AuditJSParser():
    'Parser for AuditJS Scan tool'

    def get_scan_types(self):
        return ['AuditJS Scan']

    def get_label_for_scan_types(self, scan_type):
        return 'AuditJS Scan'

    def get_description_for_scan_types(self, scan_type):
        return 'AuditJS Scanning tool using SonaType OSSIndex database with JSON output format'

    def get_severity(self, cvss):
        cvss = float(cvss)
        if ((cvss > 0) and (cvss < 4)):
            return 'Low'
        if ((cvss >= 4) and (cvss < 7)):
            return 'Medium'
        if ((cvss >= 7) and (cvss < 9)):
            return 'High'
        if (cvss >= 9):
            return 'Critical'
        return 'Informational'

    def get_findings(self, scan_file, test):
        try:
            data = json.load(scan_file)
        except JSONDecodeError:
            msg = 'Invalid JSON format. Are you sure you used --json option ?'
            raise ValueError(msg)
        dupes = {}
        for dependency in data:
            if ('coordinates' in dependency):
                file_path = dependency['coordinates']
                file_path_splitted = file_path.split('/')
                pacakge_full_name = (f'{file_path_splitted[1]}/{file_path_splitted[2]}' if (len(file_path_splitted) == 3) else file_path_splitted[1])
                (component_name, component_version) = pacakge_full_name.split('@')
            if dependency['vulnerabilities']:
                for vulnerability in dependency['vulnerabilities']:
                    try:
                        unique_id_from_tool = title = description = cvss_score = cvssv3 = cvssv4 = cvssv3_score = cvssv4_score = vulnerability_id = cwe = references = severity = None
                        if (('id' in vulnerability) and ('title' in vulnerability) and ('description' in vulnerability)):
                            unique_id_from_tool = vulnerability['id']
                            title = vulnerability['title']
                            description = vulnerability['description']
                            cwe_find = re.findall('^CWE-[0-9]{1,4}', title)
                            if cwe_find:
                                cwe = int(cwe_find[0][4:])
                        else:
                            msg = 'Missing mandatory attributes (id, title, description). Please check your report or ask community.'
                            raise ValueError(msg)
                        if ('cvssScore' in vulnerability):
                            cvss_score = vulnerability['cvssScore']
                        cvss_data = parse_cvss_data(vulnerability.get('cvssVector'))
                        if cvss_data:
                            severity = cvss_data['severity']
                            cvssv3 = cvss_data['cvssv3']
                            cvssv4 = cvss_data['cvssv4']
                            if (cvss_data['major_version'] == 2):
                                description += (((('\nCVSS V2 Vector:' + cvss_data['cvssv2']) + ' (Score: ') + str(cvss_score)) + ')')
                        else:
                            severity = self.get_severity(cvss_score)
                        if ('cve' in vulnerability):
                            vulnerability_id = vulnerability['cve']
                        if ('reference' in vulnerability):
                            references = vulnerability['reference']
                        finding = Finding(title=title, test=test, cwe=cwe, description=description, severity=severity, cvssv3=cvssv3, cvssv3_score=cvssv3_score, cvssv4=cvssv4, cvssv4_score=cvssv4_score, references=references, file_path=file_path, component_name=component_name, component_version=component_version, static_finding=True, dynamic_finding=False, unique_id_from_tool=unique_id_from_tool)
                        logger.debug('Finding fields:')
                        for (field, value) in finding.__dict__.items():
                            logger.debug('  %s: %r', field, value)
                        if vulnerability_id:
                            finding.unsaved_vulnerability_ids = [vulnerability_id]
                        dupe_key = unique_id_from_tool
                        if (dupe_key in dupes):
                            find = dupes[dupe_key]
                            if finding.description:
                                find.description += ('\n' + finding.description)
                            find.unsaved_endpoints.extend(finding.unsaved_endpoints)
                            dupes[dupe_key] = find
                        else:
                            dupes[dupe_key] = finding
                    except Exception as e:
                        logger.warning('Error processing finding: %s', e, exc_info=True)
                        continue
        return list(dupes.values())
