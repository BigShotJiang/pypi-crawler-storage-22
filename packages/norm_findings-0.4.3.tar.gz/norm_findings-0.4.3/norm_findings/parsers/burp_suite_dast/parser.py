
import typing
import datetime
import logging
import re
from lxml import etree, html
from norm_findings.stubs.models import Endpoint, Finding
logger = logging.getLogger(__name__)

class BurpSuiteDASTParser():
    vulnerability_list_xpath = "/html/body/div/div[contains(@class, 'section details')]/div[contains(@class, 'issue-container')]"
    table_contents_xpath = "/html/body/div/div[contains(@class, 'section') and .//table[contains(@class, 'issue-table')]]"
    description_headers = ['issue detail', 'issue description']
    request_response_headers = ['request', 'response']
    impact_headers = ['issue background', 'issue remediation']
    mitigation_headers = ['remediation detail', 'remediation background']
    references_headers = ['vulnerability classifications', 'references']

    def get_scan_types(self):
        return ['Burp Suite DAST Scan', 'Burp Enterprise Scan']

    def get_label_for_scan_types(self, scan_type):
        return (scan_type if (scan_type == 'Burp Suite DAST Scan') else 'Burp Enterprise Scan (RENAMED to Burp Suite DAST Scan)')

    def get_description_for_scan_types(self, scan_type):
        if (scan_type == 'Burp Suite DAST Scan'):
            return 'Import Burp Suite DAST findings in HTML format'
        return 'Import Burp Enterprise Edition findings in HTML format (RENAMED to Burp Suite DAST Scan)'

    def get_findings(self, scan_file, test):
        tree = html.parse(scan_file)
        if tree:
            return self.get_items(tree, test)
        return ()

    def _get_endpoints_title_severity_mapping(self, tree: etree.ElementTree) -> dict[(str, str)]:
        '\n        Construct a dict that contains mappings of endpoints and severities by a a title key.\n\n        Example: {\n            "finding-title": {\n                "title": "finding-title",\n                "severity: "Medium",\n                "cwe": None,\n                "endpoints: [\n                    "http://127.0.0.1/path/A",\n                    "http://127.0.0.1/path/B",\n                ],\n            }\n        }\n        '
        finding_mapping = {}
        table_contents = tree.xpath(self.table_contents_xpath)
        for table in table_contents:
            base_endpoint = table.xpath('h1')[0].text.replace('Issues found on ', '').removesuffix('/')
            title = None
            for entry in table.xpath("table[contains(@class, 'issue-table')]/tbody/tr"):
                if ('issue-type-row' in entry.classes):
                    title = ' '.join(entry.xpath('td')[0].text.strip().split(' ')[:(- 1)])
                    if (title not in finding_mapping):
                        finding_mapping[title] = {'title': title, 'severity': None, 'cwe': None, 'endpoints': []}
                else:
                    path = entry.xpath('td')[0].text.strip()
                    severity = entry.xpath('td')[1].text.strip()
                    finding_mapping[title]['endpoints'].append(f"{base_endpoint}/{path.removeprefix('/')}")
                    finding_mapping[title]['severity'] = severity
        return finding_mapping

    def _get_content(self, container: etree.Element):
        s = ''
        if ((container is None) or (isinstance(container, list) and (len(list) == 0))):
            return s
        if ((container.tag == 'div') and (container.text is not None) and (not container.text.isspace()) and (len(container.text) > 0)):
            s += re.sub('[ \\t]+', ' ', ''.join(container.itertext()).strip().replace('Snip', '\n<-------------- Snip -------------->').replace('\t', ''))
        else:
            for elem in container.iterchildren():
                if ((elem.text is not None) and elem.text.strip()):
                    stripped_text = elem.text.strip()
                    if (elem.tag == 'a'):
                        value = ((((('[' + stripped_text) + '](') + elem.attrib['href']) + ')') + '\n')
                    elif (elem.tag == 'p'):
                        value = elem.text_content().strip().replace('\n', '')
                    elif (elem.tag == 'b'):
                        value = f'**{stripped_text}**'
                    elif (elem.tag == 'li'):
                        value = '- '
                        if (stripped_text is not None):
                            value += (stripped_text + '\n')
                    elif stripped_text.isspace():
                        value = list(elem.itertext())[0]
                    elif (elem.tag in {'div', 'span'}):
                        value = (elem.text_content().strip().replace('\n', '') + '\n')
                    else:
                        continue
                    s += re.sub('\\s+', ' ', value)
                else:
                    s += self._get_content(elem)
        return s

    def _format_bulleted_lists(self, finding_details: dict, div_element: etree.ElementTree) -> tuple[(str, list[str])]:
        'Create a mapping of bulleted lists with links into a formatted list, as well as the raw values.'
        formatted_string = ''
        content_list = []
        for a_tag in div_element.xpath('ul/li/a'):
            content = re.sub('\\s+', ' ', a_tag.text.strip())
            link = a_tag.attrib['href']
            formatted_string += f'''- [{content}]({link})
'''
            content_list.append(content)
        return (formatted_string, content_list)

    def _set_or_append_content(self, finding_details: dict, header: str, div_element: etree.ElementTree) -> None:
        'Determine whether we should set or append content in a given place.'
        header = header.replace(':', '')
        field = None
        if (header.lower() in self.description_headers):
            field = 'description'
            content = self._get_content(div_element)
        elif (header.lower() in self.impact_headers):
            field = 'impact'
            content = self._get_content(div_element)
        elif (header.lower() in self.mitigation_headers):
            field = 'mitigation'
            content = self._get_content(div_element)
        elif (header.lower() in self.references_headers):
            field = 'references'
            (content, data_list) = self._format_bulleted_lists(finding_details, div_element)
            if (header.lower() == 'vulnerability classifications'):
                for item in data_list:
                    cleaned_item = item.split(':')[0]
                    if ((finding_details['cwe'] is None) and (cwe_search := re.search('CWE-([0-9]*)', cleaned_item, re.IGNORECASE))):
                        finding_details['cwe'] = int(cwe_search.group(1))
                    if ('vulnerability_ids' not in finding_details):
                        finding_details['vulnerability_ids'] = [cleaned_item]
                    else:
                        finding_details['vulnerability_ids'].append(cleaned_item)
        elif (header.lower() in self.request_response_headers):
            field = 'request_response'
            content = self._get_content(div_element)
            if (header.lower() == 'request'):
                if ('requests' not in finding_details):
                    finding_details['requests'] = [content]
                else:
                    finding_details['requests'].append(content)
            if (header.lower() == 'response'):
                if ('responses' not in finding_details):
                    finding_details['responses'] = [content]
                else:
                    finding_details['responses'].append(content)
            return
        else:
            return
        formatted_content = f'''**{header}**:
{content}
'''
        if ((existing_field := finding_details.get(field)) is not None):
            if (header not in existing_field):
                finding_details[field] += f'''{formatted_content}
---
'''
        else:
            finding_details[field] = f'''{formatted_content}
---
'''

    def _parse_elements_by_h3_element(self, issue: etree.Element, finding_details: dict) -> None:
        for header_element in issue.xpath('h3'):
            if (((div_element := header_element.getnext()) is not None) and (div_element.tag == 'div')):
                self._set_or_append_content(finding_details, header_element.text.strip(), div_element)

    def get_items(self, tree: etree.ElementTree, test):
        finding_details = self._get_endpoints_title_severity_mapping(tree)
        for issue in tree.xpath(self.vulnerability_list_xpath):
            title = issue.xpath('h2')[0].text.strip()
            self._parse_elements_by_h3_element(issue, finding_details[title])
            for request_response_div in issue.xpath("div[contains(@class, 'evidence-container')]"):
                self._parse_elements_by_h3_element(request_response_div, finding_details[title])
            requests = finding_details[title].pop('requests', [])
            responses = finding_details[title].pop('responses', [])
            finding_details[title]['request_response_pairs'] = [{'request': (requests[i] if (i < len(requests)) else None), 'response': (responses[i] if (i < len(responses)) else None)} for i in range(max(len(requests), len(responses)))]
        return list(self.create_findings(finding_details, test))

    def create_findings(self, findings_dict: dict[(str, dict)], test):
        findings = []
        for finding_dict in findings_dict.values():
            try:
                endpoints = finding_dict.pop('endpoints', [])
                request_response_pairs = finding_dict.pop('request_response_pairs', [])
                vulnerability_ids = finding_dict.pop('vulnerability_ids', [])
                finding = Finding(test=test, false_p=False, duplicate=False, out_of_scope=False, mitigated=None, static_finding=False, dynamic_finding=True, **finding_dict)
                finding.unsaved_endpoints = [Endpoint.from_uri(endpoint) for endpoint in endpoints]
                finding.unsaved_req_resp = [{'req': request_response.get('request'), 'resp': request_response.get('response')} for request_response in request_response_pairs]
                finding.unsaved_vulnerability_ids = vulnerability_ids
                findings.append(finding)
            except Exception as e:
                logger.warning('Error processing finding: %s', e, exc_info=True)
                continue
        return findings
