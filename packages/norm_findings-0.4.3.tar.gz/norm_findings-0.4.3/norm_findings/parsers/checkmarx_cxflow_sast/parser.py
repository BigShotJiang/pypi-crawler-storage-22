
import typing
import datetime
import json
import logging
from dataclasses import dataclass
import dateutil.parser
from norm_findings.stubs.models import Finding
logger = logging.getLogger(__name__)

class _PathNode():

    def __init__(self, file: str, line: str, column: str, node_object: str, length: str, snippet: str):
        self.file = file
        self.line = line
        self.column = int(column)
        self.node_object = node_object
        self.length = int(length)
        self.snippet = snippet

    @classmethod
    def from_json_object(cls, data):
        return _PathNode(data.get('file'), data.get('line'), data.get('column'), data.get('object'), data.get('length'), data.get('snippet'))

@dataclass
class _Path():
    sink: _PathNode
    source: _PathNode
    state: str
    paths: [_PathNode]

class CheckmarxCXFlowSastParser():

    def __init__(self):
        pass

    def get_scan_types(self):
        return ['Checkmarx CxFlow SAST']

    def get_label_for_scan_types(self, scan_type):
        return scan_type

    def get_description_for_scan_types(self, scan_type):
        return 'Detailed Report. Import all vulnerabilities from checkmarx without aggregation'

    def get_findings(self, scan_file, test):
        if scan_file.name.strip().lower().endswith('.json'):
            return self._get_findings_json(scan_file, test)
        logger.warning('Not supported file format $%s', scan_file)
        return []

    def _get_findings_json(self, file, test):
        data = json.load(file)
        findings = []
        additional_details = data.get('additionalDetails')
        scan_start_date = additional_details.get('scanStartDate')
        issues = data.get('xissues', [])
        for issue in issues:
            vulnerability = issue.get('vulnerability')
            status = issue.get('vulnerabilityStatus')
            cwe = issue.get('cwe')
            description = issue.get('description')
            language = issue.get('language')
            severity = issue.get('severity')
            link = issue.get('link')
            filename = issue.get('filename')
            similarity_id = issue.get('similarityId')
            issue_additional_details = issue.get('additionalDetails')
            categories = issue_additional_details.get('categories')
            results = issue_additional_details.get('results')
            map_paths = {}
            for result in results:
                path_keys = sorted(filter((lambda k: (isinstance(k, str) and k.isnumeric())), result.keys()))
                path = _Path(sink=_PathNode.from_json_object(result.get('sink')), source=_PathNode.from_json_object(result.get('source')), state=result.get('state'), paths=[result[k] for k in path_keys])
                map_paths[str(path.source.line)] = path
            for detail_key in issue.get('details'):
                try:
                    if (detail_key not in map_paths):
                        logger.warning('%s not found in path, ignore', detail_key)
                    else:
                        detail = map_paths[detail_key]
                        finding_detail = f'''**Category:** {categories}
'''
                        finding_detail += f'''**Language:** {language}
'''
                        finding_detail += f'''**Status:** {status}
'''
                        finding_detail += f'''**Finding link:** [{link}]({link})
'''
                        finding_detail += f'''**Description:** {description}
'''
                        finding_detail += f'''**Source snippet:** `{(detail.source.snippet if (detail.source is not None) else '')}`
'''
                        finding_detail += f'''**Sink snippet:** `{(detail.sink.snippet if (detail.sink is not None) else '')}`
'''
                        finding = Finding(title=(((vulnerability.replace('_', ' ') + ' ') + detail.sink.file.split('/')[(- 1)]) if (detail.sink is not None) else ''), cwe=int(cwe), date=dateutil.parser.parse(scan_start_date), static_finding=True, test=test, sast_source_object=(detail.source.node_object if (detail.source is not None) else None), sast_sink_object=(detail.sink.node_object if (detail.sink is not None) else None), sast_source_file_path=(detail.source.file if (detail.source is not None) else None), sast_source_line=(detail.source.line if (detail.source is not None) else None), vuln_id_from_tool=similarity_id, severity=severity, file_path=filename, line=detail.sink.line, false_p=(issue.get('details')[detail_key].get('falsePositive') or self.is_not_exploitable(detail.state)), description=finding_detail, verified=self.is_verify(detail.state), active=self.is_active(detail.state))
                        findings.append(finding)
                except Exception as e:
                    logger.warning('Error processing finding: %s', e, exc_info=True)
                    continue
        return findings

    def is_verify(self, state):
        verifiedStates = ['2', '3']
        return (state in verifiedStates)

    def is_active(self, state):
        activeStates = ['0', '2', '3', '4']
        return (state in activeStates)

    def is_not_exploitable(self, state):
        return (state == '1')
