
import typing
import datetime
import csv
import hashlib
import io
from norm_findings.stubs.models import Finding
import logging
logger = logging.getLogger(__name__)
__author__ = 'dr3dd589'

class CobaltParser():

    def get_scan_types(self):
        return ['Cobalt.io Scan']

    def get_label_for_scan_types(self, scan_type):
        return scan_type

    def get_description_for_scan_types(self, scan_type):
        return 'CSV Report'

    def get_findings(self, scan_file, test):
        if (scan_file is None):
            return []
        content = scan_file.read()
        if isinstance(content, bytes):
            content = content.decode('utf-8')
        reader = csv.DictReader(io.StringIO(content), delimiter=',', quotechar='"')
        dupes = {}
        for row in reader:
            try:
                finding = Finding(test=test)
                finding.title = (row['Title'] if (row['Title'][0] != "'") else row['Title'][1:])
                Type = (row['Type'] if (row['Type'][0] != "'") else row['Type'][1:])
                Description = (row['Description'] if (row['Description'][0] != "'") else row['Description'][1:])
                finding.description = ((((('**Type** : ' + Type) + '\n\n') + '**Description** : ') + Description) + '\n')
                finding.mitigation = (row['SuggestedFix'] if (row['SuggestedFix'][0] != "'") else row['SuggestedFix'][1:])
                finding.references = (row['ResearcherUrl'] if (row['ResearcherUrl'][0] != "'") else row['ResearcherUrl'][1:])
                finding.steps_to_reproduce = (row['StepsToReproduce'] if (row['StepsToReproduce'][0] != "'") else row['StepsToReproduce'][1:])
                finding.severity_justification = (row['CriticalityJustification'] if (row['CriticalityJustification'][0] != "'") else row['CriticalityJustification'][1:])
                finding.severity = 'Info'
                if (finding is not None):
                    if (finding.title is None):
                        finding.title = ''
                    if (finding.description is None):
                        finding.description = ''
                    key = hashlib.md5(((finding.title + '|') + finding.description).encode('utf-8'), usedforsecurity=False).hexdigest()
                    if (key not in dupes):
                        dupes[key] = finding
            except Exception as e:
                logger.warning('Error processing finding: %s', e, exc_info=True)
                continue
        return list(dupes.values())
