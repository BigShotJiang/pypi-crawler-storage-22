
import typing
import datetime
import json
from norm_findings.stubs.models import Finding
import logging
logger = logging.getLogger(__name__)

class GCloudArtifactScanParser():

    def get_scan_types(self):
        return ['Google Cloud Artifact Vulnerability Scan']

    def get_label_for_scan_types(self, scan_type):
        return scan_type

    def get_description_for_scan_types(self, scan_type):
        return 'Import Google Cloud Artifact Vulnerability scans in JSON format.'

    def parse_json(self, json_output):
        try:
            data = json_output.read()
            try:
                tree = json.loads(str(data, 'utf-8'))
            except Exception:
                tree = json.loads(data)
        except Exception:
            msg = 'Invalid format'
            raise ValueError(msg)
        return tree

    def get_findings(self, scan_file, test):
        findings = []
        if (scan_file is None):
            return findings
        tree = self.parse_json(scan_file)
        if tree:
            for severity in tree['package_vulnerability_summary']['vulnerabilities']:
                for vuln in tree['package_vulnerability_summary']['vulnerabilities'][severity]:
                    try:
                        description = (('name: ' + str(vuln['name'])) + '\n\n')
                        description += (('resourceUri: ' + str(vuln['resourceUri'])) + '\n')
                        description += (('packageIssue: ' + str(vuln['vulnerability']['packageIssue'])) + '\n')
                        description += (('CVE: ' + str(vuln['vulnerability']['shortDescription'])) + '\n')
                        reference = ''
                        for ref in vuln['vulnerability']['relatedUrls']:
                            reference += (ref['url'] + '\n')
                        finding = Finding(title=vuln['noteName'], test=test, description=description, severity=self.severity_mapper(severity), references=reference, component_name=((('affectedCPEUri: ' + vuln['vulnerability']['packageIssue'][0]['affectedCpeUri']) + ' affectedPackage: ') + vuln['vulnerability']['packageIssue'][0]['affectedPackage']), component_version=vuln['vulnerability']['packageIssue'][0]['affectedVersion']['fullName'], static_finding=True, dynamic_finding=False)
                        if vuln['vulnerability'].get('fixAvailable'):
                            finding.fix_available = vuln['vulnerability'].get('fixAvailable')
                        if vuln['vulnerability'].get('cvssScore'):
                            finding.cvssv3_score = vuln['vulnerability'].get('cvssScore')
                        if vuln['vulnerability']['shortDescription']:
                            finding.unsaved_vulnerability_ids = [vuln['vulnerability']['shortDescription']]
                        findings.append(finding)
                    except Exception as e:
                        logger.warning('Error processing finding: %s', e, exc_info=True)
                        continue
        return findings

    def severity_mapper(self, severity):
        if (severity.lower().capitalize() in {'Critical', 'High', 'Medium', 'Low', 'Info'}):
            return severity.lower().capitalize()
        if (severity == 'Minimal'):
            return 'Low'
        return 'Info'
