
import typing
import datetime
import csv
import hashlib
import io
from cvss import parser as cvss_parser
from dateutil.parser import parse
from norm_findings.stubs.models import Endpoint, Finding
import logging
logger = logging.getLogger(__name__)

class GenericCSVParser():
    ID = 'Generic Findings Import'

    def _get_findings_csv(self, filename):
        content = filename.read()
        if isinstance(content, bytes):
            content = content.decode('utf-8')
        reader = csv.DictReader(io.StringIO(content), delimiter=',', quotechar='"')
        dupes = {}
        for row in reader:
            try:
                finding = Finding(title=row['Title'], description=row['Description'], date=parse(row['Date']).date(), severity=self.get_severity(row['Severity']), duplicate=self._convert_bool(row.get('Duplicate', 'FALSE')), nb_occurences=1)
                if ('Active' in row):
                    finding.active = self._convert_bool(row.get('Active'))
                if ('IsMitigated' in row):
                    finding.is_mitigated = self._convert_bool(row.get('IsMitigated'))
                if ('MitigatedDate' in row):
                    finding.mitigated = parse(row['MitigatedDate'])
                if ('Mitigation' in row):
                    finding.mitigation = row['Mitigation']
                if ('Impact' in row):
                    finding.impact = row['Impact']
                if ('References' in row):
                    finding.references = row['References']
                if ('Verified' in row):
                    finding.verified = self._convert_bool(row.get('Verified'))
                if ('FalsePositive' in row):
                    finding.false_p = self._convert_bool(row.get('FalsePositive'))
                if (('CVE' in row) and [row['CVE']]):
                    finding.unsaved_vulnerability_ids = [row['CVE']]
                if row.get('Vulnerability Id'):
                    if finding.unsaved_vulnerability_ids:
                        finding.unsaved_vulnerability_ids.append(row['Vulnerability Id'])
                    else:
                        finding.unsaved_vulnerability_ids = [row['Vulnerability Id']]
                if ('CweId' in row):
                    finding.cwe = int(row['CweId'])
                if ('epss_score' in row):
                    finding.epss_score = float(row['epss_score'])
                if ('epss_percentile' in row):
                    finding.epss_percentile = float(row['epss_percentile'])
                if ('CVSSV3' in row):
                    cvss_objects = cvss_parser.parse_cvss_from_text(row['CVSSV3'])
                    if (len(cvss_objects) > 0):
                        finding.cvssv3 = cvss_objects[0].clean_vector()
                if ('CVSSV4' in row):
                    cvss4_objects = cvss_parser.parse_cvss_from_text(row['CVSSV4'])
                    if (len(cvss4_objects) > 0):
                        finding.cvssv4 = cvss4_objects[0].clean_vector()
                if ('CVSSV4_score' in row):
                    finding.cvssv4_score = float(row['CVSSV4_score'])
                if ('kev_date' in row):
                    finding.kev_date = parse(row['kev_date'])
                if ('known_exploited' in row):
                    finding.known_exploited = bool(row['known_exploited'])
                if ('ransomware_used' in row):
                    finding.ransomware_used = bool(row['ransomware_used'])
                if ('fix_available' in row):
                    finding.fix_available = bool(row['fix_available'])
                if ('Url' in row):
                    finding.unsaved_endpoints = [(Endpoint.from_uri(row['Url']) if ('://' in row['Url']) else Endpoint.from_uri(('//' + row['Url'])))]
                key = hashlib.sha256(f'{finding.severity}|{finding.title}|{finding.description}'.encode()).hexdigest()
                if (key in dupes):
                    find = dupes[key]
                    find.unsaved_endpoints.extend(finding.unsaved_endpoints)
                    if find.unsaved_vulnerability_ids:
                        find.unsaved_vulnerability_ids.extend(finding.unsaved_vulnerability_ids)
                    else:
                        find.unsaved_vulnerability_ids = finding.unsaved_vulnerability_ids
                    find.nb_occurences += 1
                else:
                    dupes[key] = finding
            except Exception as e:
                logger.warning('Error processing finding: %s', e, exc_info=True)
                continue
        return list(dupes.values())

    def _convert_bool(self, val):
        return (val.lower()[0:1] == 't')

    def get_severity(self, severity_input):
        if (severity_input in {'Info', 'Low', 'Medium', 'High', 'Critical'}):
            return severity_input
        return 'Info'
