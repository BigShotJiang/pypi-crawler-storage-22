# Converted from DefectDojo parser
import typing
import datetime
# Required stubs: Finding

import contextlib
import logging
from xml.dom import NamespaceErr
from defusedxml import ElementTree
from norm_findings.stubs.models import Finding
from norm_findings.parsers.openvas.parser_v2.common import OpenVASFindingAuxData, cleanup_openvas_text, deduplicate, is_valid_severity, postprocess_finding, setup_finding
from norm_findings.stubs.utils import parse_cvss_data
logger = logging.getLogger(__name__)

def get_findings_from_xml(file, test) -> list[Finding]:
    'Returns list of findings as defectdojo factory contract expects'
    dupes = {}
    tree = ElementTree.parse(file)
    root = tree.getroot()
    if ('report' not in root.tag):
        msg = "This doesn't seem to be a valid Greenbone/ OpenVAS XML file."
        raise NamespaceErr(msg)
    report = root.find('report')
    results = report.find('results')
    parser = XMLParserV2()
    for result in results:
        (finding, aux_info) = setup_finding(test)
        for element in result:
            parser.process_element(element, finding, aux_info)
        postprocess_finding(finding, aux_info)
        deduplicate(dupes, finding)
    return list(dupes.values())

class XMLParserV2():

    def __init__(self):
        self.tag_handlers = {'nvt': self._handle_nvt, 'qod': self._handle_qod, 'name': self._handle_name, 'host': self._handle_host, 'port': self._handle_port, 'severity': self._handle_severity, 'threat': self._handle_threat, 'description': self._handle_description}

    def process_element(self, field, finding: Finding, aux_info: OpenVASFindingAuxData):
        self.finding = finding
        self.aux_info = aux_info
        handler = self.tag_handlers.get(field.tag)
        try:
            if handler:
                handler(field)
        except ValueError as e:
            logger.debug('openvas parser v2: error parsing field %s: %s', field.tag, e)

    def _handle_nvt(self, field):
        self.finding.vuln_id_from_tool = field.get('oid')
        nvt_name = field.find('name').text
        if nvt_name:
            self.finding.title = nvt_name
        solution = field.find('solution')
        if (solution is not None):
            self.finding.mitigation = cleanup_openvas_text(solution.text)
        refs_node = field.find('refs')
        if (refs_node is not None):
            refs = refs_node.findall('.//ref')
            self.finding.unsaved_vulnerability_ids = [ref.get('id') for ref in refs if (ref.get('type') == 'cve')]
            self.aux_info.references = [ref.get('id') for ref in refs if (ref.get('type') != 'cve')]
        tag_field = field.find('tags')
        tags = self._parse_nvt_tags(tag_field.text)
        summary = tags.get('summary', None)
        if summary:
            self.aux_info.summary = summary
        impact = tags.get('impact', None)
        if impact:
            self.finding.impact = cleanup_openvas_text(impact)
        cvss_base_vector = tags.get('cvss_base_vector', None)
        if cvss_base_vector:
            cvss_data = parse_cvss_data(cvss_base_vector)
            self.finding.cvssv3 = cvss_data['cvssv3']
            self.finding.cvssv4 = cvss_data['cvssv4']
            if (cvss_data['major_version'] == 2):
                self.finding.cvssv3_score = cvss_data['cvssv2_score']

    def _handle_qod(self, field):
        self.aux_info.qod = field.find('value').text

    def _handle_name(self, field):
        if field.text:
            self.finding.title = field.text

    def _handle_host(self, field):
        if field.text:
            hostname_field = field.find('hostname')
            if ((hostname_field is not None) and hostname_field.text):
                self.finding.unsaved_endpoints[0].host = hostname_field.text.strip()
            else:
                self.finding.unsaved_endpoints[0].host = field.text.strip()

    def _handle_port(self, field):
        if field.text:
            (port_str, protocol) = field.text.split('/')
            self.finding.unsaved_endpoints[0].protocol = protocol
            with contextlib.suppress(ValueError):
                self.finding.unsaved_endpoints[0].port = int(port_str)

    def _handle_severity(self, field):
        if field.text:
            self.aux_info.fallback_cvss_score = float(field.text)

    def _handle_threat(self, field):
        if (field.text and is_valid_severity(field.text)):
            self.finding.severity = field.text

    def _handle_description(self, field):
        if field.text:
            self.aux_info.openvas_result = field.text.strip()

    def _parse_nvt_tags(self, text: str) -> dict[(str, str)]:
        '\n        Parse tags in nvt field into dict\n        Example:\n\n            Input: "summary=This is a test|impact=High|solution=Update software"\n            Output: {"summary": "This is a test", "impact": "High", "solution": "Update software"}\n        '
        parts = text.strip().split('|')
        tags = {}
        for part in parts:
            idx = part.find('=')
            if ((idx == (- 1)) or (len(part) < (idx + 2))):
                continue
            key = part[0:idx]
            val = part[(idx + 1):]
            tags[key] = val
        return tags
