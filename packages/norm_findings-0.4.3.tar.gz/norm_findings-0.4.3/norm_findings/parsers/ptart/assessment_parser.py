
import typing
import datetime
from norm_findings.stubs.models import Finding
from norm_findings.stubs.utils import parse_cvss_data
from . import ptart_parser_tools as ptart_tools
import logging
logger = logging.getLogger(__name__)

class PTARTAssessmentParser():

    def __init__(self):
        self.cvss_type = None

    def get_test_data(self, tree):
        if ('assessments' not in tree):
            return []
        self.cvss_type = tree.get('cvss_type', None)
        assessments = tree['assessments']
        return [finding for assessment in assessments for finding in self.parse_assessment(assessment)]

    def parse_assessment(self, assessment):
        hits = assessment.get('hits', [])
        return [self.get_finding(assessment, hit) for hit in hits]

    def get_finding(self, assessment, hit):
        effort = ptart_tools.parse_ptart_fix_effort(hit.get('fix_complexity'))
        finding = Finding(title=ptart_tools.parse_title_from_hit(hit), severity=ptart_tools.parse_ptart_severity(hit.get('severity')), effort_for_fixing=effort, component_name=assessment.get('title', 'Unknown Component'), date=ptart_tools.parse_date_added_from_hit(hit))
        if hit['body']:
            finding.description = hit.get('body')
        if hit['remediation']:
            finding.mitigation = hit.get('remediation')
        if hit['id']:
            finding.unique_id_from_tool = hit.get('id')
            finding.vuln_id_from_tool = hit.get('id')
            finding.cve = hit.get('id')
        cvss_vector = hit.get('cvss_vector', None)
        if cvss_vector:
            cvss_data = parse_cvss_data(cvss_vector)
            if cvss_data:
                finding.cvssv3 = cvss_data['cvssv3']
                finding.cvssv4 = cvss_data['cvssv4']
        if ('labels' in hit):
            finding.unsaved_tags = hit['labels']
        finding.cwe = ptart_tools.parse_cwe_from_hit(hit)
        finding.unsaved_endpoints = ptart_tools.parse_endpoints_from_hit(hit)
        finding.unsaved_files = ptart_tools.parse_screenshots_from_hit(hit)
        finding.unsaved_files.extend(ptart_tools.parse_attachment_from_hit(hit))
        finding.references = ptart_tools.parse_references_from_hit(hit)
        return finding
