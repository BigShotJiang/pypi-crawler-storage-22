
import typing
import datetime
from norm_findings.stubs.models import Finding
from norm_findings.stubs.utils import parse_cvss_data
from . import ptart_parser_tools as ptart_tools
import logging
logger = logging.getLogger(__name__)

def generate_retest_hit_title(hit, original_hit):
    title = original_hit.get('title', '')
    hit_id = hit.get('id', None)
    if ('status' in hit):
        title = f"{title} ({ptart_tools.parse_retest_status(hit['status'])})"
    fake_retest_hit = {'title': title, 'id': hit_id}
    return ptart_tools.parse_title_from_hit(fake_retest_hit)

class PTARTRetestParser():

    def get_test_data(self, tree):
        if ('retests' in tree):
            retests = tree['retests']
        else:
            return []
        return [finding for retest in retests for finding in self.parse_retest(retest)]

    def parse_retest(self, retest):
        hits = retest.get('hits', [])
        all_findings = [self.get_finding(retest, hit) for hit in hits]
        return [finding for finding in all_findings if (finding is not None)]

    def get_finding(self, retest, hit):
        if (('original_hit' not in hit) or (not hit['original_hit'])):
            return None
        original_hit = hit['original_hit']
        finding_title = generate_retest_hit_title(hit, original_hit)
        finding = Finding(title=finding_title, severity=ptart_tools.parse_ptart_severity(original_hit.get('severity')), effort_for_fixing=ptart_tools.parse_ptart_fix_effort(original_hit.get('fix_complexity')), component_name=f"Retest: {retest.get('name', 'Retest')}", date=ptart_tools.parse_date(retest.get('start_date'), '%Y-%m-%d'))
        if hit['body']:
            finding.description = hit.get('body')
        if original_hit['remediation']:
            finding.mitigation = original_hit.get('remediation')
        if hit['id']:
            finding.unique_id_from_tool = hit.get('id')
            finding.vuln_id_from_tool = original_hit.get('id')
            finding.cve = original_hit.get('id')
        cvss_vector = original_hit.get('cvss_vector', None)
        if cvss_vector:
            cvss_data = parse_cvss_data(cvss_vector)
            if cvss_data:
                finding.cvssv3 = cvss_data['cvssv3']
                finding.cvssv4 = cvss_data['cvssv4']
        if ('labels' in original_hit):
            finding.unsaved_tags = original_hit['labels']
        finding.cwe = ptart_tools.parse_cwe_from_hit(original_hit)
        finding.unsaved_endpoints = ptart_tools.parse_endpoints_from_hit(original_hit)
        finding.unsaved_files = ptart_tools.parse_screenshots_from_hit(hit)
        return finding
