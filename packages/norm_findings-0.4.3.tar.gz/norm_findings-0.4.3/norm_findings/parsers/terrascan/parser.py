
import typing
import datetime
import hashlib
import json
from norm_findings.stubs.models import Finding
import logging
logger = logging.getLogger(__name__)

class TerrascanParser():
    'A class that can be used to parse the terrascan JSON report file'
    SEVERITY = {'HIGH': 'High', 'MEDIUM': 'Medium', 'LOW': 'Low'}

    def get_scan_types(self):
        return ['Terrascan Scan']

    def get_label_for_scan_types(self, scan_type):
        return 'Terrascan Scan'

    def get_description_for_scan_types(self, scan_type):
        return 'Import JSON output for Terrascan scan report.'

    def get_findings(self, scan_file, test):
        data = json.load(scan_file)
        dupes = {}
        if (('results' not in data) and ('violations' not in data.get('results'))):
            msg = "missing mandatory attribute 'results'"
            raise ValueError(msg)
        if (data.get('results').get('violations') is None):
            return []
        for item in data.get('results').get('violations'):
            try:
                rule_name = item.get('rule_name')
                description = item.get('description')
                severity = self.SEVERITY.get(item.get('severity'), 'Info')
                rule_id = item.get('rule_id')
                category = item.get('category')
                resource_name = item.get('resource_name')
                resource_type = item.get('resource_type')
                file = item.get('file')
                line = item.get('line')
                dupe_key = hashlib.sha256((((((rule_id + rule_name) + resource_name) + resource_type) + file) + str(line)).encode('utf-8')).hexdigest()
                if (dupe_key in dupes):
                    finding = dupes[dupe_key]
                    finding.nb_occurences += 1
                else:
                    finding = Finding(title=f'{category}: {rule_name}', test=test, severity=severity, description=description, file_path=file, line=line, component_name=f'{resource_type}/{resource_name}', vuln_id_from_tool=rule_id, nb_occurences=1)
                    dupes[dupe_key] = finding
            except Exception as e:
                logger.warning('Error processing finding: %s', e, exc_info=True)
                continue
        return list(dupes.values())
