
import typing
import datetime
import hashlib
import json
from datetime import datetime
from cpe import CPE
from norm_findings.stubs.models import Endpoint, Finding
import logging
logger = logging.getLogger(__name__)

class TrustwaveFusionAPIParser():
    'Import Trustwave Fusion Report from its API in JSON format'

    def get_scan_types(self):
        return ['Trustwave Fusion API Scan']

    def get_label_for_scan_types(self, scan_type):
        return 'Trustwave Fusion API Scan'

    def get_description_for_scan_types(self, scan_type):
        return 'Trustwave Fusion API report file can be imported in JSON format'

    def get_findings(self, scan_file, test):
        tree = json.load(scan_file)
        items = {}
        for node in tree['items']:
            item = get_item(node, test)
            item_key = hashlib.sha256(f'{item.severity}|{item.title}|{item.description}'.encode()).hexdigest()
            if (item_key in items):
                items[item_key].unsaved_endpoints.extend(item.unsaved_endpoints)
                items[item_key].nb_occurences += 1
            else:
                items[item_key] = item
        return list(items.values())

    def convert_severity(self, num_severity):
        'Convert severity value'
        if (num_severity >= (- 10)):
            return 'Low'
        if ((- 11) >= num_severity > (- 26)):
            return 'Medium'
        if (num_severity <= (- 26)):
            return 'High'
        return 'Info'

def get_item(vuln, test):
    finding = Finding(test=test, unique_id_from_tool=vuln['id'], nb_occurences=1)
    location = vuln['location']
    if (('url' in location) and location['url'] and (location['url'] != 'None')):
        endpoint = Endpoint.from_uri(location['url'])
    elif (('domain' in location) and location['domain'] and (location['domain'] != 'None')):
        endpoint = Endpoint(host=str(location['domain']))
    elif (('ip' in location) and location['ip'] and (location['ip'] != 'None')):
        endpoint = Endpoint(host=str(location['ip']))
    if (('applicationProtocol' in location) and location['applicationProtocol'] and (location['applicationProtocol'] != 'None')):
        endpoint.protocol = location['applicationProtocol']
    if (('port' in location) and (location['port'] in location) and (location['port'] != 'None')):
        endpoint.port = location['port']
    finding.unsaved_endpoints = [endpoint]
    finding.title = vuln['name']
    description = vuln['classification']
    cves = 'no match'
    if ('CVE-NO-MATCH' not in vuln['kb']['cves']):
        finding.unsaved_vulnerability_ids = vuln['kb']['cves']
        cves = ''
        for cve in vuln['kb']['cves']:
            cves += f'{cve}, '
        cves = cves[:(len(cves) - 2)]
    finding.description = description
    finding.severity = vuln['severity'].title()
    date_str = vuln['createdOn']
    date_str = (date_str[:(len(date_str) - 3)] + date_str[(- 2):])
    finding.date = datetime.strptime(date_str, '%Y-%m-%dT%H:%M:%S.%f%z')
    if (('applicationCpe' in location) and location['applicationCpe'] and (location['applicationCpe'] != 'None')):
        cpe = CPE(location['applicationCpe'])
        component_name = ((cpe.get_vendor()[0] + ':') if (len(cpe.get_vendor()) > 0) else '')
        component_name += (cpe.get_product()[0] if (len(cpe.get_product()) > 0) else '')
        finding.component_name = (component_name or None)
        finding.component_version = (cpe.get_version()[0] if (len(cpe.get_version()) > 0) else None)
    return finding
