# Documentazione di progetto

Questa directory contiene documentazione, analisi e materiali di supporto.

La landing page del progetto è stata spostata in `site/`.
Per istruzioni su build e deploy del sito, vedi `site/README.md`.
