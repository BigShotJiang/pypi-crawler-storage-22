## 1. Implementation

- [x] 1.1 Add version argument to argparse with action='version'
- [x] 1.2 Extract version from package metadata using importlib.metadata
- [x] 1.3 Test --version flag displays correct version
- [x] 1.4 Test -v short flag works identically
- [x] 1.5 Verify version display exits without processing
