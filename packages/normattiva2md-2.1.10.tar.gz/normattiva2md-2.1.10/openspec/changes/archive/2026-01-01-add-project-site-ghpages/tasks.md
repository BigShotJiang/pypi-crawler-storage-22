## 1. Implementation
- [x] 1.1 Inventariare i file del sito oggi in `docs/` e definire il contenuto da spostare in `site/`
- [x] 1.2 Spostare i file del sito in `site/` e aggiornare eventuali riferimenti
- [x] 1.3 Aggiungere workflow GitHub Actions per build/publish su branch `gh-pages`
- [x] 1.4 Aggiornare la documentazione (README o docs) con il nuovo percorso e la pubblicazione
- [ ] 1.5 Verificare pubblicazione su Pages (branch `gh-pages`)
