## ADDED Requirements
### Requirement: Project Website Content
Il sito MUST includere una sezione "Uso delle API" che descriva l'API programmabile (api.py, models.py, exceptions.py) e le funzioni standalone convert_url(), convert_xml(), search_law().

#### Scenario: Sezione API visibile
- **WHEN** un utente visita la landing page
- **THEN** trova una sezione dedicata con descrizione ed esempi d'uso delle API
