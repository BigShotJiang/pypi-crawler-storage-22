## 1. Implementation
- [x] 1.1 Definire contenuti della sezione "Uso delle API" con esempi per API programmabile e funzioni standalone
- [x] 1.2 Inserire la nuova sezione in site/index.md con struttura coerente alla landing
- [x] 1.3 Verificare che la sezione rispetti lo stile e non introduca badge/annunci
