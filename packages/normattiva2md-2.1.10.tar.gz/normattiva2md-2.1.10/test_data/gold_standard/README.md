# Gold Standard Data\n\nThis directory contains XML files and their expected Markdown outputs for regression testing.
