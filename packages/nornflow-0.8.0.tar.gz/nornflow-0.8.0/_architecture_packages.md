# NornFlow Packages — Architecture Document

## Table of Contents
- [Overview](#overview)
- [Configuration](#configuration)
  - [The `packages` Setting](#the-packages-setting)
  - [Package Descriptor Fields](#package-descriptor-fields)
  - [Validation Rules](#validation-rules)
  - [Configuration Examples](#configuration-examples)
  - [Environment Variable Support](#environment-variable-support)
- [Package Structure Convention](#package-structure-convention)
- [Discovery and Cataloging Flow](#discovery-and-cataloging-flow)
  - [High-Level Initialization Flow](#high-level-initialization-flow)
  - [Resource Type to Discovery Mapping](#resource-type-to-discovery-mapping)
  - [Package Path Resolution](#package-path-resolution)
  - [Loading Order and Precedence](#loading-order-and-precedence)
  - [Name Conflict Resolution](#name-conflict-resolution)
  - [The Built-in Protection Mechanism](#the-built-in-protection-mechanism)
  - [Hook Override Behavior](#hook-override-behavior)
- [Implementation Architecture](#implementation-architecture)
  - [New Module: `nornflow/packages/`](#new-module-nornflowpackages)
  - [PackageDescriptor Model](#packagedescriptor-model)
  - [PackageLoader](#packageloader)
  - [Integration with NornFlow Initialization](#integration-with-nornflow-initialization)
  - [Integration with Settings](#integration-with-settings)
  - [Integration with Constants](#integration-with-constants)
- [Error Handling](#error-handling)
- [CLI Impact](#cli-impact)
- [Testing Strategy](#testing-strategy)
- [Limitations](#limitations)
- [Files to Create or Modify](#files-to-create-or-modify)

## Overview

NornFlow's `packages` setting lets users pull resources from external Python packages installed in their environment. The user installs a NornFlow-compatible package (`pip install acme_nornflow_toolkit`), declares it in `nornflow.yaml`, and NornFlow discovers and catalogs resources from it using the exact same mechanisms it uses for local directories.

NornFlow does **not** install packages. The package must already be available in the Python environment. NornFlow merely imports from it and catalogs what it finds.

This feature is scoped exclusively to **NornFlow-native packages** — packages that follow NornFlow's own directory layout convention (see [Package Structure Convention](#package-structure-convention)). Packages with arbitrary internal structures (e.g., generic Nornir ecosystem packages like `nornir_napalm` or `nornir_netmiko`) do not follow this convention and are not compatible with this feature. Users who want to leverage resources from arbitrarily-structured packages should wrap those resources in local tasks, filters, or hooks.

## Configuration

### The `packages` Setting

Configured in `nornflow.yaml` as a list of package descriptors:

```yaml
packages:
  - name: acme_nornflow_toolkit
    include:
      - tasks
      - blueprints
      - workflows
  - name: acme_nornflow_hooks
    include:
      - j2_filters
      - hooks
  - name: acme_nornflow_full
```

Each entry specifies a package `name` and an optional `include` list. If `include` is omitted, NornFlow imports **all** seven resource types from that package. If `include` is present, only the listed resource types are imported.

### Package Descriptor Fields

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `name` | `str` | Yes | — | Python package import path (e.g., `"acme_nornflow_toolkit"`) |
| `include` | `list[str]` | No | `None` (all types) | Which resource types to import. If omitted, all types are imported. |

### Validation Rules

| Rule | Behavior |
|------|----------|
| `name` is empty or whitespace | `SettingsError` at settings load time |
| `include` is present but empty (`[]`) | `SettingsError` — if you specify `include`, it must contain at least one item |
| `include` contains an invalid resource type string | `SettingsError` — only valid identifiers accepted |
| `include` is omitted entirely | All resource types are imported from that package |
| Duplicate package names in the list | `SettingsError` — each package may only appear once |

Valid resource type identifiers for `include`:

```
tasks, workflows, blueprints, filters, hooks, j2_filters, processors
```

### Configuration Examples

**Import specific resource types from each package:**
```yaml
packages:
  - name: acme_nornflow_toolkit
    include:
      - tasks
      - filters
  - name: acme_nornflow_hooks
    include:
      - hooks
      - j2_filters
```

**Import everything from a package (no `include` key):**
```yaml
packages:
  - name: acme_nornflow_toolkit
```

**Mixed — some selective, some everything:**
```yaml
packages:
  - name: acme_nornflow_toolkit
    include:
      - tasks
      - workflows
  - name: acme_nornflow_full
```

**No packages (default):**
```yaml
packages: []
```

Or simply omit the `packages` key entirely.

### Environment Variable Support

**The `packages` setting does NOT support environment variable configuration.** This is intentional.

The setting's structure — a list of dicts with nested lists — is too complex for environment variable representation. Package imports are structural project decisions made at design time, not deployment-time overrides.

The `packages` key will be added to `NORNFLOW_INVALID_INIT_KWARGS` in `nornflow/constants.py` to also prevent it from being passed via `NornFlow.__init__()` kwargs.

## Package Structure Convention

NornFlow-compatible packages **must** follow NornFlow's own directory layout convention. This is non-negotiable — packages that do not follow this structure will not be discovered.

The convention mirrors the `local_*` settings structure: resource subdirectories are placed at the package root, named exactly after the resource type they contain.

```
acme_nornflow_toolkit/                 # Installed Python package root
├── __init__.py
│
├── tasks/                             # Nornir task functions
│   ├── __init__.py
│   ├── backup.py                      #   def backup_config(task: Task) -> Result: ...
│   └── provisioning.py               #   def provision_device(task: Task) -> Result: ...
│
├── workflows/                         # Workflow YAML definitions
│   ├── backup_workflow.yaml
│   └── full_deploy.yaml
│
├── blueprints/                        # Blueprint YAML definitions
│   └── common_checks.yaml
│
├── filters/                           # Nornir inventory filter functions
│   ├── __init__.py
│   └── site_filters.py               #   def by_region(host: Host, ...) -> bool: ...
│
├── hooks/                             # Hook subclasses
│   ├── __init__.py
│   └── custom_hooks.py               #   class MyHook(Hook): ...
│
├── j2_filters/                        # Jinja2 filter functions
│   ├── __init__.py
│   └── net_filters.py                #   def mask_to_prefix(value): ...
│
└── processors/                        # Processor subclasses
    ├── __init__.py
    └── custom_processor.py            #   class MyProcessor(Processor): ...
```

**Key rules:**

- All seven resource subdirectories are optional. A package may provide any combination of them — all seven, just one, or anything in between. If a package provides none of them, NornFlow logs a warning during initialization (a package with zero discoverable resources is likely a misconfiguration).
- Python resource directories (`tasks/`, `filters/`, `hooks/`, `j2_filters/`, `processors/`) must be proper Python packages (contain `__init__.py`).
- File-based resource directories (`workflows/`, `blueprints/`) contain YAML files directly (`.yaml` / `.yml`).
- If the user's `include` list explicitly requests a resource type but the corresponding subdirectory doesn't exist in the package, NornFlow logs a **WARNING** and skips that type — the user asked for something the package doesn't have, which likely indicates a misconfiguration. If `include` is omitted (meaning "import whatever exists"), missing subdirectories are logged at **DEBUG** level — NornFlow is simply scanning for what's available.
- **Packages that do not follow this convention are not supported by this feature.** Users who want to consume resources from arbitrarily-structured packages should wrap those resources in local tasks, filters, hooks, etc.

## Discovery and Cataloging Flow

### High-Level Initialization Flow

The `packages` feature integrates into NornFlow's existing initialization sequence. A `PackageLoader` instance is created after settings validation but before catalog loading. Each catalog load method then queries the `PackageLoader` for resource directories, inserting package discovery between built-ins and local directories.

```
NornFlow.__init__()
    │
    ├── _initialize_settings()
    │       └── NornFlowSettings validates `packages` schema
    │           └── Each entry validated as PackageDescriptor
    │
    ├── _initialize_package_loader()                          ← NEW
    │       └── PackageLoader(settings.packages)
    │
    ├── _initialize_catalogs()
    │       │
    │       ├── _load_tasks_catalog()
    │       │       ├── 1. Register builtins
    │       │       ├── 2. Discover from packages (tasks)     ← NEW
    │       │       └── 3. Discover from local_tasks dirs
    │       │
    │       ├── _load_filters_catalog()
    │       │       ├── 1. Register builtins
    │       │       ├── 2. Discover from packages (filters)   ← NEW
    │       │       └── 3. Discover from local_filters dirs
    │       │
    │       ├── _load_workflows_catalog()
    │       │       ├── 1. Discover from packages (workflows) ← NEW
    │       │       └── 2. Discover from local_workflows dirs
    │       │
    │       └── _load_blueprints_catalog()
    │               ├── 1. Discover from packages (blueprints)← NEW
    │               └── 2. Discover from local_blueprints dirs
    │
    ├── _initialize_j2_service()
    │       ├── 1. Register builtins
    │       ├── 2. Discover from packages (j2_filters)        ← NEW
    │       └── 3. Discover from local_j2_filters dirs
    │
    ├── _initialize_hooks()
    │       ├── 1. (Built-in hooks already imported)
    │       ├── 2. Import package hook modules                ← NEW
    │       └── 3. Import local hook modules
    │
    └── _initialize_processors()
            ├── 1. Import package processor modules           ← NEW
            └── 2. (User references processors explicitly in settings)
```

### Resource Type to Discovery Mapping

Each resource type maps to a specific catalog type and discovery mechanism. Package discovery uses the **exact same predicates and methods** as local directory discovery:

| Resource Type | Catalog Type | Discovery Method | Predicate / Mechanism |
|--------------|-------------|-----------------|----------------------|
| `tasks` | `CallableCatalog` | `discover_items_in_dir()` | `is_nornir_task` |
| `filters` | `CallableCatalog` | `discover_items_in_dir()` | `is_nornir_filter` + `process_filter` |
| `workflows` | `FileCatalog` | `discover_items_in_dir()` | `is_yaml_file` |
| `blueprints` | `FileCatalog` | `discover_items_in_dir()` | `is_yaml_file` |
| `hooks` | `HOOK_REGISTRY` (global dict) | `import_modules_recursively()` | `__init_subclass__` auto-registration |
| `j2_filters` | Via `Jinja2Service` | `discover_items_in_dir()` | `is_public_callable` |
| `processors` | N/A (explicit reference) | `import_modules_recursively()` | Makes `Processor` subclasses importable |

### Package Path Resolution

The core path resolution operation converts a Python package name into a filesystem directory, then checks for the resource type subdirectory:

```
Input: package_name="acme_nornflow_toolkit", resource_type="tasks"
    │
    ├── importlib.import_module("acme_nornflow_toolkit")
    │       └── Returns module object
    │
    ├── module.__file__
    │       └── "/path/to/site-packages/acme_nornflow_toolkit/__init__.py"
    │
    ├── Path(module.__file__).parent
    │       └── "/path/to/site-packages/acme_nornflow_toolkit/"
    │
    ├── package_root / "tasks"
    │       └── "/path/to/site-packages/acme_nornflow_toolkit/tasks/"
    │
    └── .is_dir()?
            ├── Yes → return Path
            └── No  → return None (caller decides log level)
```

This approach works for:
- Regular `pip install` packages
- Editable installs (`pip install -e .`)
- Packages installed via `uv`, `poetry`, `pdm`, etc.

This approach does **not** work for:
- Namespace packages (no `__init__.py`, no `__file__` attribute)
- Packages with non-standard structures (detected and skipped with a warning)

### Loading Order and Precedence

Catalog-based resources and hooks follow **different precedence models** due to fundamental differences in their registration architectures. This is intentional and reflects the distinct roles each plays in NornFlow's runtime.

#### Catalog-Based Resources (Tasks, Filters, Workflows, Blueprints, J2 Filters)

Resources are loaded in this strict order — **last write wins** since catalogs are dictionaries:

```
┌─────────────────────────────────┐
│ 1. Built-in resources           │  ← Loaded first, marked is_builtin=True
│    └── nornflow.builtins.*      │     PROTECTED — cannot be overridden
├─────────────────────────────────┤
│ 2. Package resources            │  ← Loaded in order listed in `packages`
│    ├── packages[0]              │     CatalogError if name clashes with builtin
│    ├── packages[1]              │     Later packages override earlier ones
│    └── packages[N]              │
├─────────────────────────────────┤
│ 3. Local directory resources    │  ← Loaded last
│    └── local_* settings dirs    │     CatalogError if name clashes with builtin
│                                 │     Overrides package resources
└─────────────────────────────────┘
```

This means:
- **Built-in resources are protected** — any attempt to register a resource with the same name as a built-in, whether from a package or from a local directory, raises `CatalogError` and halts initialization
- **Package resources** can be overridden by local resources (later write wins)
- Between packages, later entries in the `packages` list override earlier ones for same-named resources
- Between local directories (e.g., multiple `local_tasks` entries), later entries override earlier ones (existing behavior, unchanged)

#### Hooks (Separate Registration Architecture)

Hooks use a **completely different** precedence model. See [Hook Override Behavior](#hook-override-behavior) for full details.

### Name Conflict Resolution

NornFlow uses **flat names** — no fully qualified namespacing. All resources are registered by their simple name (function name for tasks/filters/j2_filters, stem for YAML files, `hook_name` for hooks). For catalog-based resources, conflicts between non-builtin resources are resolved purely by load order. Conflicts involving builtins are hard errors.

```
Conflict scenario (non-builtin):
    acme_nornflow_toolkit/tasks/backup.py → registers "backup_config"
    local tasks/backup.py                 → registers "backup_config"

Resolution:
    ┌─────────────────────────────────────────────────────┐
    │ Package "backup_config" loaded at step 2            │
    │ Local "backup_config" loaded at step 3              │
    │ Dict overwrites → local version wins                │
    │ WARNING log emitted: local overrides package source │
    └─────────────────────────────────────────────────────┘
```

```
Conflict scenario (builtin):
    acme_nornflow_toolkit/tasks/echo.py → registers "echo"
    OR
    local tasks/echo.py                 → registers "echo"

Resolution:
    ┌─────────────────────────────────────────────────────────┐
    │ Built-in "echo" loaded at step 1, marked is_builtin    │
    │ Package or local "echo" attempted at step 2 or 3       │
    │ CatalogError raised → initialization halts              │
    │ User must rename their resource to avoid the conflict  │
    └─────────────────────────────────────────────────────────┘
```

A `WARNING`-level log is emitted on non-builtin overrides:

```
WARNING - Task 'backup_config' from local directory 'tasks/' overrides 'backup_config' from package 'acme_nornflow_toolkit'
```

**No fully qualified names are implemented.** The catalog system is dict-based and NornFlow's entire workflow/blueprint/CLI ecosystem references resources by simple names. Introducing namespacing would require invasive changes across the entire codebase for marginal benefit. If you need both versions, rename one.

### The Built-in Protection Mechanism

`CallableCatalog.register()` contains explicit protection against overriding built-in items:

```python
if name in self and self.sources.get(name, {}).get("is_builtin", False):
    raise CatalogError(
        f"Cannot override built-in '{name}' with a custom implementation",
        catalog_name=self.name,
    )
```

This protection is unconditional and applies to **all** sources — packages and local directories alike. If a package or local resource attempts to register a name that collides with a built-in, NornFlow raises `CatalogError` and initialization fails immediately.

**This is intentional and will not change.** Built-in tasks (e.g., `echo`, `set`, `write_file`) and built-in filters (e.g., `hosts`, `groups`) are integral to NornFlow's core runtime. The `set` task powers the runtime variable system. The `hosts` and `groups` filters are referenced implicitly by Nornir's inventory filtering pipeline. Allowing any external code — whether from an installed package or a local directory — to silently replace these resources would create subtle, hard-to-diagnose failures in fundamental NornFlow operations.

The hard error makes the problem immediately obvious: the user (or package author) must rename their resource. There is no ambiguity, no silent behavior change, no debugging session to figure out why variables stopped working.

```
Built-in protection flow:
    ┌────────────────────────────────────────────────────────────────────┐
    │ Step 1: Built-in "echo" registered, is_builtin=True              │
    ├────────────────────────────────────────────────────────────────────┤
    │ Step 2: Package tries to register "echo"                         │
    │         → CatalogError: "Cannot override built-in 'echo'..."     │
    │         → NornFlow initialization HALTS                          │
    │         → User sees clear error message                          │
    │         → Fix: rename the package resource                       │
    ├────────────────────────────────────────────────────────────────────┤
    │ Step 3: (never reached if step 2 fails)                          │
    │         Local tries to register "echo"                           │
    │         → Same CatalogError, same halt                           │
    │         → Fix: rename the local resource                         │
    └────────────────────────────────────────────────────────────────────┘
```

### Hook Override Behavior

Hooks follow a fundamentally different override model than catalog-based resources, and this is by design.

**Hooks use strict name uniqueness — duplicate `hook_name` values raise `HookRegistrationError` at import time.** This applies regardless of source: a package hook cannot share a name with a built-in hook, a local hook cannot share a name with a package hook, and so on.

```
Hook registration (at import time via __init_subclass__):
    ┌────────────────────────────────────────────────────────────┐
    │ 1. Built-in hooks imported (via nornflow.builtins)         │
    │    HOOK_REGISTRY["set_to"] = SetToHook          ✅         │
    │    HOOK_REGISTRY["if"]     = IfHook             ✅         │
    │    HOOK_REGISTRY["shush"]  = ShushHook          ✅         │
    ├────────────────────────────────────────────────────────────┤
    │ 2. Package hooks imported                                  │
    │    hook_name = "audit"  → registers PkgAuditHook ✅        │
    │    hook_name = "set_to" → HookRegistrationError  ❌        │
    │    (cannot reuse existing hook_name)                       │
    ├────────────────────────────────────────────────────────────┤
    │ 3. Local hooks imported                                    │
    │    hook_name = "notify" → registers MyNotifyHook ✅        │
    │    hook_name = "audit"  → HookRegistrationError  ❌        │
    │    (cannot reuse package hook_name)                        │
    └────────────────────────────────────────────────────────────┘
```

**Why catalog-based resources and hooks share the same "no override" outcome but through different mechanisms:**

Both catalog-based resources and hooks enforce strict uniqueness against their respective built-ins, but the enforcement mechanisms differ because the registration architectures are fundamentally different.

Catalog-based resources use `CallableCatalog.register()`, which is a dict-based storage that checks `is_builtin` flags. The protection is explicit: the `register()` method inspects existing entries and raises `CatalogError` if the target name belongs to a built-in. This mechanism lives in the catalog layer and is invoked during directory discovery.

Hooks use `__init_subclass__` class registration into `HOOK_REGISTRY`, a global dict populated at import time. The protection is inherent to the registration mechanism itself: `__init_subclass__` checks if the `hook_name` already exists in `HOOK_REGISTRY` and raises `HookRegistrationError` if it does. There is no `is_builtin` flag — the protection applies equally to all hook name collisions, regardless of source.

The net effect is identical: **no resource — builtin task, builtin filter, or builtin hook — can be replaced by external code.** The user always sees a hard error and must choose a different name.

**Why this design is appropriate for hooks specifically:**

NornFlow's built-in hooks (`if`, `set_to`, `shush`) were designed with two purposes: **(1)** provide genuinely useful task-level behavior extensions (conditional execution, result capture, output suppression), and **(2)** serve as reference implementations demonstrating the hook extension pattern for developers building their own. They function as both utility and documentation.

Allowing hook overrides would undermine both purposes: it would break users relying on the documented behavior of `if`, `set_to`, and `shush`, and it would invalidate their role as stable reference implementations. And because hooks are **behavioral extensions** — they inject logic into the task execution lifecycle via configuration keys in workflow YAML (`if:`, `set_to:`, `shush:`) — a silent replacement would mean a workflow referencing `set_to:` could get a completely different implementation depending on what packages are installed. That class of bug is extremely difficult to diagnose.

The strict uniqueness constraint ensures that hook behavior is always explicit and deterministic: every `hook_name` maps to exactly one implementation, regardless of how many packages or local modules are loaded.

**Practical impact:** Package and local hook authors must choose unique `hook_name` values. If a package wants to provide enhanced conditional execution, it should use `hook_name = "when"` or `hook_name = "conditional"`, not `hook_name = "if"`. The `HookRegistrationError` message clearly identifies the conflict, making resolution straightforward.

## Implementation Architecture

### New Module: `nornflow/packages/`

```
nornflow/packages/
├── __init__.py          # Exports PackageDescriptor, PackageLoader
├── constants.py         # VALID_RESOURCE_TYPES frozenset
├── descriptor.py        # PackageDescriptor pydantic model
└── loader.py            # PackageLoader class — path resolution & resource dir discovery
```

This follows the existing codebase pattern: `nornflow/blueprints/`, `nornflow/hooks/`, `nornflow/vars/`, `nornflow/j2/`.

### PackageDescriptor Model

Lives in `nornflow/packages/descriptor.py`. Validates and represents a single entry in the `packages` setting list. Imports `VALID_RESOURCE_TYPES` from `nornflow/packages/constants.py`.

```python
from pydantic import BaseModel, field_validator

from nornflow.exceptions import SettingsError
from nornflow.packages.constants import VALID_RESOURCE_TYPES


class PackageDescriptor(BaseModel):
    """Validates and represents a single entry in the `packages` setting.

    Attributes:
        name: Python import path for the NornFlow-compatible package.
        include: Resource types to import. None means all seven types.
    """

    name: str
    include: list[str] | None = None

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if not v or not v.strip():
            raise SettingsError(
                "Package name cannot be empty",
                setting="packages",
            )
        return v.strip()

    @field_validator("include")
    @classmethod
    def validate_include(cls, v: list[str] | None) -> list[str] | None:
        if not v:
            return None
        if not v:
            raise SettingsError(
                "If 'include' is specified, it must be a non-empty list",
                setting="packages",
            )
        invalid = set(v) - VALID_RESOURCE_TYPES
        if invalid:
            raise SettingsError(
                f"Invalid resource type(s): {sorted(invalid)}. "
                f"Valid: {sorted(VALID_RESOURCE_TYPES)}",
                setting="packages",
            )
        return v

    def should_import(self, resource_type: str) -> bool:
        """Whether this descriptor requests importing the given resource type.

        Args:
            resource_type: A resource type string (e.g. "tasks", "hooks").

        Returns:
            True if this package should provide that resource type.
        """
        if not self.include:
            return True
        return resource_type in self.include

    def explicitly_includes(self, resource_type: str) -> bool:
        """Whether this descriptor's include list explicitly names the resource type.

        Returns False when include is None (i.e. "import everything"
        mode), even though should_import() would return True.

        Args:
            resource_type: A resource type string (e.g. "tasks", "hooks").

        Returns:
            True only if include is set and contains resource_type.
        """
        if not self.include:
            return False
        return resource_type in self.include
```

### PackageLoader

Lives in `nornflow/packages/loader.py`. Resolves installed package paths and returns resource subdirectories for each requested resource type. The log level for missing subdirectories depends on whether the resource type was explicitly listed in the descriptor's `include`:

- **`include` explicitly lists the resource type** → `WARNING` — the user asked for something the package doesn't provide, likely a misconfiguration.
- **`include` is `None` (import everything)** → `DEBUG` — NornFlow is scanning for whatever the package has; a missing subdirectory is perfectly normal.

```python
import importlib
from pathlib import Path

from nornflow.exceptions import ResourceError
from nornflow.logger import logger
from nornflow.packages.descriptor import PackageDescriptor


class PackageLoader:
    """Resolves installed package paths and discovers resource subdirectories.

    Instantiated once during NornFlow initialization with validated
    PackageDescriptor instances. Queried by each catalog load method
    to get filesystem paths for package resource directories.

    Args:
        descriptors: Validated PackageDescriptor instances from settings.
    """

    def __init__(self, descriptors: list[PackageDescriptor]):
        self._descriptors = descriptors

    def get_resource_dirs(self, resource_type: str) -> list[tuple[str, Path]]:
        """Get (package_name, directory_path) pairs for a given resource type.

        Iterates through all package descriptors, filters by include
        configuration, and resolves filesystem paths. Packages whose
        include list doesn't mention this resource type are skipped.

        When a package should provide a resource type but the
        subdirectory doesn't exist, the log level depends on context:
        WARNING if the user explicitly listed the type in include,
        DEBUG if include was omitted (scan-everything mode).

        Args:
            resource_type: One of the valid resource type strings.

        Returns:
            List of (package_name, path_to_resource_dir) tuples.
        """
        result = []
        for desc in self._descriptors:
            if not desc.should_import(resource_type):
                continue

            resource_dir = self._resolve_resource_dir(desc.name, resource_type)
            if resource_dir:
                result.append((desc.name, resource_dir))
            elif desc.explicitly_includes(resource_type):
                logger.warning(
                    f"Package '{desc.name}' does not have a '{resource_type}/' "
                    f"directory, but '{resource_type}' is explicitly listed in "
                    f"its include configuration. Skipping."
                )
            else:
                logger.debug(
                    f"Package '{desc.name}' has no '{resource_type}/' directory. "
                    f"Skipping {resource_type} for this package."
                )
        return result

    def _resolve_resource_dir(
        self, package_name: str, resource_type: str
    ) -> Path | None:
        """Resolve the filesystem path for a resource type within a package.

        Imports the package, locates its installation directory via
        __file__, and checks for the resource type subdirectory.
        Does not log on missing subdirectories — the caller handles
        log level selection based on whether the type was explicitly
        requested.

        Args:
            package_name: Python package import path.
            resource_type: Resource type subdirectory name.

        Returns:
            Path to the resource directory if it exists, None otherwise.

        Raises:
            ResourceError: If the package cannot be imported.
        """
        try:
            package = importlib.import_module(package_name)
        except ImportError as e:
            raise ResourceError(
                f"Package '{package_name}' could not be imported. "
                f"Is it installed in the current environment?",
                resource_type="package",
                resource_name=package_name,
            ) from e

        package_file = getattr(package, "__file__", None)
        if not package_file:
            logger.warning(
                f"Package '{package_name}' has no __file__ attribute "
                f"(namespace packages are not supported). Skipping."
            )
            return None

        resource_dir = Path(package_file).parent / resource_type
        if not resource_dir.is_dir():
            return None

        logger.info(
            f"Found {resource_type} in package '{package_name}': {resource_dir}"
        )
        return resource_dir
```

### Integration with NornFlow Initialization

In `nornflow/nornflow.py`, a `PackageLoader` instance is created after settings validation. Each catalog load method is updated to query the loader **after** built-ins but **before** local directories.

**New instance attribute:**
```python
self._package_loader: PackageLoader | None = None
```

**New initialization step:**
```python
def _initialize_package_loader(self) -> None:
    if self._settings.packages:
        self._package_loader = PackageLoader(self._settings.packages)
```

**Updated catalog load pattern (applied to each `_load_*_catalog` method):**

```
def _load_tasks_catalog(self):
    # 1. Register built-in tasks (existing code — unchanged)

    # 2. Discover from packages                                    ← NEW
    if self._package_loader:
        for pkg_name, resource_dir in self._package_loader.get_resource_dirs("tasks"):
            self._tasks_catalog.discover_items_in_dir(
                str(resource_dir), predicate=is_nornir_task
            )

    # 3. Discover from local_tasks directories (existing code — unchanged)
```

The same pattern applies to filters, workflows, blueprints, and j2_filters: builtins first, then packages, then local.

For workflows and blueprints (which have no builtins), the pattern is simpler:

```
def _load_workflows_catalog(self):
    # 1. Discover from packages                                    ← NEW
    if self._package_loader:
        for pkg_name, resource_dir in self._package_loader.get_resource_dirs("workflows"):
            self._workflows_catalog.discover_items_in_dir(
                str(resource_dir), predicate=is_yaml_file
            )

    # 2. Discover from local_workflows directories (existing code — unchanged)
```

**Updated hook initialization:**

```
def _initialize_hooks(self):
    # 1. (Built-in hooks already imported via builtins __init__)

    # 2. Import package hook modules                               ← NEW
    if self._package_loader:
        for pkg_name, resource_dir in self._package_loader.get_resource_dirs("hooks"):
            import_modules_recursively(resource_dir)

    # 3. Import local hook modules (existing code — unchanged)
```

**Updated processor initialization:**

```
    # Import package processor modules so classes become available  ← NEW
    if self._package_loader:
        for pkg_name, resource_dir in self._package_loader.get_resource_dirs("processors"):
            import_modules_recursively(resource_dir)

    # (Processors are still explicitly referenced by class path in the `processors` setting)
```

### Integration with Settings

In `nornflow/settings.py`:

- Remove the `imported_packages` field entirely.
- Add `packages: list[PackageDescriptor]` field with `default_factory=list`.
- Import `PackageDescriptor` from `nornflow.packages.descriptor`.
- Add a `field_validator` for duplicate package name detection:

```python
@field_validator("packages")
@classmethod
def validate_no_duplicate_packages(
    cls, v: list[PackageDescriptor]
) -> list[PackageDescriptor]:
    names = [d.name for d in v]
    dupes = [n for n in names if names.count(n) > 1]
    if dupes:
        raise SettingsError(
            f"Duplicate package names: {sorted(set(dupes))}",
            setting="packages",
        )
    return v
```

### Integration with Constants

In `nornflow/constants.py`:

- Add `"packages"` to `NORNFLOW_INVALID_INIT_KWARGS`.
- Update `NORNFLOW_SETTINGS_OPTIONAL` — remove `"imported_packages"`, add `"packages"`.

In `nornflow/packages/constants.py` (new file):

```python
VALID_RESOURCE_TYPES = frozenset({
    "tasks",
    "workflows",
    "blueprints",
    "filters",
    "hooks",
    "j2_filters",
    "processors",
})
```

## Error Handling

All exceptions use NornFlow's existing hierarchy from `nornflow/exceptions.py`:

| Scenario | Exception | When |
|----------|-----------|------|
| Empty `name` | `SettingsError` | Settings validation |
| Empty `include` list | `SettingsError` | Settings validation |
| Invalid `include` entry | `SettingsError` | Settings validation |
| Duplicate package names | `SettingsError` | Settings validation |
| Package not installed / import fails | `ResourceError` | `PackageLoader._resolve_resource_dir()` |
| Namespace package (no `__file__`) | Warning logged, package skipped | `PackageLoader._resolve_resource_dir()` |
| Resource subdir missing, explicitly in `include` | WARNING logged, resource type skipped | `PackageLoader.get_resource_dirs()` |
| Resource subdir missing, `include` omitted | DEBUG logged, resource type skipped | `PackageLoader.get_resource_dirs()` |
| Package or local task/filter name clashes with builtin | `CatalogError` | `CallableCatalog.register()` |
| Package or local hook name clashes with any existing hook | `HookRegistrationError` | `Hook.__init_subclass__()` at import time |

**Fail-fast on missing packages:** If a user declares a package in `packages` and it cannot be imported, NornFlow raises `ResourceError` and stops. The user explicitly asked for that package — not having it is a hard failure.

**Context-aware logging on missing subdirectories:** If the user explicitly listed a resource type in `include` but the package has no corresponding subdirectory, NornFlow logs a WARNING — they asked for something the package doesn't have. If `include` is omitted (meaning "import whatever exists"), a missing subdirectory is logged at DEBUG — the package simply doesn't provide that type, and that's fine.

**Hard failure on builtin collisions:** If a package or local resource attempts to register a name that collides with a built-in task or filter, NornFlow raises `CatalogError` and initialization halts. If a package or local hook uses a `hook_name` that already exists in `HOOK_REGISTRY`, `HookRegistrationError` is raised at import time. In both cases, the fix is to rename the offending resource.

## CLI Impact

- `nornflow show --settings` displays the `packages` configuration.
- `nornflow show --catalogs` / `--tasks` / `--filters` etc. show package-sourced resources alongside local and built-in ones. The source module path makes origins clear.
- No new CLI commands needed.

## Testing Strategy

| Test Category | What to Test |
|---------------|-------------|
| **Settings Validation** | Valid configs, empty name, empty include, invalid include entries, duplicate names, omitted include defaults to all |
| **Package Resolution** | Installed package found, missing package raises `ResourceError`, namespace package warning, missing subdirectory skipped |
| **Catalog Integration** | Tasks/filters/workflows/blueprints from package registered in correct catalogs |
| **Include Filtering** | Only specified types imported, unspecified types ignored, no `include` = everything |
| **Missing Subdir Logging** | WARNING when `include` explicitly lists a type with no subdir, DEBUG when `include` is omitted |
| **Precedence: Local vs Package** | Local overrides package resource with same name |
| **Precedence: Package vs Package** | Later package overrides earlier package for same name |
| **Built-in Protection: Package** | Package task/filter with builtin name raises `CatalogError` |
| **Built-in Protection: Local** | Local task/filter with builtin name raises `CatalogError` |
| **Hook Name Conflicts** | Package hook with same name as builtin raises `HookRegistrationError` |
| **Hook Name Conflicts** | Local hook with same name as package hook raises `HookRegistrationError` |
| **End-to-End** | Full workflow referencing resources from a test fixture package |

A test fixture package (e.g., `tests/fixtures/acme_nornflow_toolkit/`) following the NornFlow package structure convention should be created and installed in editable mode for test runs.

## Limitations

1. **NornFlow-native packages only**: Packages **must** follow NornFlow's directory layout convention — `tasks/`, `filters/`, `hooks/`, `j2_filters/`, `workflows/`, `blueprints/`, `processors/` at the package root. Packages with arbitrary internal structures are not supported. Users who want to leverage those packages should wrap their functionality in local resources.

2. **No package installation**: NornFlow does not install packages. Users manage their own environments.

3. **No version management**: NornFlow uses whatever version is installed.

4. **No namespace isolation**: All resources share flat namespaces within their catalogs. Conflicts resolved by precedence (non-builtins) or hard error (builtins and hooks).

5. **No ENV var support**: The `packages` setting is YAML-only.

6. **No namespace packages**: Python namespace packages (without `__init__.py` / without `__file__`) are not supported.

7. **No lazy loading**: All declared packages are discovered during NornFlow initialization.

8. **Built-in names are reserved**: No package or local resource may use the same name as a built-in task, filter, or hook. Attempts to do so are hard errors.

## Files to Create or Modify

| File | Action | Description |
|------|--------|-------------|
| `nornflow/packages/__init__.py` | **Create** | Module exports: `PackageDescriptor`, `PackageLoader` |
| `nornflow/packages/constants.py` | **Create** | `VALID_RESOURCE_TYPES` frozenset |
| `nornflow/packages/descriptor.py` | **Create** | `PackageDescriptor` model with `should_import()` and `explicitly_includes()` |
| `nornflow/packages/loader.py` | **Create** | `PackageLoader` class with context-aware missing-directory logging |
| `nornflow/settings.py` | **Modify** | Remove `imported_packages`, add `packages: list[PackageDescriptor]` field, add duplicate name validator |
| `nornflow/constants.py` | **Modify** | Add `"packages"` to `NORNFLOW_INVALID_INIT_KWARGS`, update `NORNFLOW_SETTINGS_OPTIONAL` (remove `"imported_packages"`, add `"packages"`) |
| `nornflow/nornflow.py` | **Modify** | Add `_initialize_package_loader()`, update all `_load_*_catalog` methods (package discovery after builtins, before local), update `_initialize_hooks`, update processor init |
| `nornflow/catalogs.py` | **No changes** | Existing `is_builtin` protection in `CallableCatalog.register()` works as-is |
| `nornflow/hooks/base.py` | **No changes** | Existing `HookRegistrationError` on duplicate `hook_name` works as-is |
| `nornflow/exceptions.py` | **No changes** | Existing exceptions (`SettingsError`, `ResourceError`, `CatalogError`, `HookRegistrationError`) are sufficient |
| `nornflow/cli/samples/nornflow.yaml` | **Modify** | Replace `imported_packages: []` with `packages: []` |
| `docs/nornflow_settings.md` | **Modify** | Document the `packages` setting, remove `imported_packages` documentation |