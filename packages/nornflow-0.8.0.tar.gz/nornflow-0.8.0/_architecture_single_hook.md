## `single` Hook — Architecture Decision Record

### 1. Purpose
Execute a task on exactly **one host** from the inventory instead of all hosts. All other hosts are silently skipped — no output, no statistics counted.

### 2. Hook Name & Branch
- **Hook name**: `single`
- **YAML key**: `single`
- **Branch name**: `feat/single-hook`

### 3. Value Semantics
| Value | Behavior |
|---|---|
| `single: true` | Activate single-host execution |
| `single: false` | No effect, task runs normally on all hosts |
| `single: "{{ expr }}"` | Resolve Jinja2 to bool; if true, activate |
| `single: null` / omitted | No effect, same as `false` |

### 4. Mixins & Inheritance
```
class SingleHook(Hook, Jinja2ResolvableMixin)
```
- `Jinja2ResolvableMixin` provides automatic Jinja2 validation during `execute_hook_validations` and `get_resolved_value()` for resolution at runtime.

### 5. Host Selection Strategy
- **No explicit failed-host filtering needed.** Nornir's own mechanics (via `NornFlowFailureStrategyProcessor`) ensure that by the time `task_instance_started` fires, the host is already a valid, non-failed host across all three failure strategies (SKIP_FAILED, RUN_ALL, FAIL_FAST).
- The first host whose `task_instance_started` fires and finds no delegate assigned yet becomes **the delegate**. All subsequent hosts are silently skipped.
- A **threading lock** (`threading.Lock`) protects the delegate assignment since `task_instance_started` can be called concurrently from multiple threads.

### 6. Lifecycle Flow

**`task_started`**:
1. Resolve the `single` value (via `get_resolved_value(as_bool=True, default=False)`).
2. If `false`, return immediately — no effect.
3. If `true`, initialize `self._delegate_host = None` and `self._lock = threading.Lock()`.
4. Wrap `task.task` with a **new, separate decorator** (`skip_if_silent_flagged`) — distinct from the `if` hook's `skip_if_condition_flagged`.

**`task_instance_started`**:
1. Under `self._lock`: if `self._delegate_host` is not set, assign it to `host.name` → this host runs the task.
2. If `self._delegate_host` is already set to a different host, set `host.data["nornflow_silent_skip_flag"] = True`.

**`task_completed`**:
1. Reset `self._delegate_host = None` for clean state (though hooks are per-task-model, this is defensive).

### 7. The `skip_if_silent_flagged` Decorator
- Lives in `single_hook.py` (not shared with if_hook.py — different semantics).
- Checks for `nornflow_silent_skip_flag` on `task.host.data`.
- If flagged: cleans up the flag, returns `Result(host=task.host, result=None, changed=False, failed=False, skipped=True)`.
- If not flagged: calls the original task function normally (no deferred template resolution needed — `single` does not use `requires_deferred_templates`).

### 8. `DefaultNornFlowProcessor` Changes
Two methods need modification:

**`task_instance_started`**: Check `host.data.get("nornflow_silent_skip_flag")`. If set, **do not** increment `self.task_executions` and **do not** record `start_times`. Early return.

**`task_instance_completed`**: Check `host.data.get("nornflow_silent_skip_flag")`. If set, **do not** increment any counters (`successful_executions`, `failed_executions`, `skipped_executions`), **do not** print anything. Clean up the flag. Early return.

The silently-skipped hosts are **completely invisible** in all statistics and output.

### 9. Validation Rules
- `execute_hook_validations`: Validate that the value is a bool, a Jinja2 string expression, or `None`. Reject dicts, lists, numbers, empty strings.
- **Mutual exclusion with `if` hook**: If both `single` and `if` are present on the same task, raise `HookValidationError`. This check happens in `SingleHook.execute_hook_validations` by inspecting `task_model.hooks` for the presence of the `"if"` key.

### 10. `requires_deferred_templates`
- **Not set** (defaults to `False`). The `single` hook doesn't need deferred template processing — it doesn't affect which templates get resolved. The delegate host runs the task normally with standard parameter resolution.

### 11. `run_once_per_task`
- **`False`**. The hook needs `task_instance_started` called for every host so it can set the silent skip flag on non-delegate hosts.

### 12. Files Affected

| File | Change |
|---|---|
| `nornflow/builtins/hooks/single_hook.py` | **New file** — `SingleHook` class + `skip_if_silent_flagged` decorator |
| __init__.py | Add `SingleHook` import/export |
| default_processor.py | Add silent skip checks in `task_instance_started` and `task_instance_completed` |

### 13. YAML Example
```yaml
workflow:
  name: example
  tasks:
    - task: gather_global_config
      single: true

    - task: push_config_to_all_hosts

    - task: conditional_single
      single: "{{ run_as_single }}"
```

---

**Does this match your expectations fully? Any corrections or additions before I write the code?**