"""Email provider adapters (BYOP)."""
