"""Middleware: auth, logging."""
