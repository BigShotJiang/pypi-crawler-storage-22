"""Tests for Urdr (storage)."""
