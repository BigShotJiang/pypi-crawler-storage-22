# Nory LangChain Tools

**Give your LangChain agents the ability to pay.**

Nory LangChain Tools provides a set of LangChain-compatible tools that enable AI agents to make instant payments using the x402 protocol. Payments settle on Solana in under 1 second.

## Installation

```bash
pip install nory-langchain
```

## Quick Start

```python
from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI
from nory_langchain import get_nory_tools

# Initialize LLM
llm = ChatOpenAI(model="gpt-4")

# Get all Nory payment tools
tools = get_nory_tools()

# Create agent with payment capabilities
agent = initialize_agent(
    tools=tools,
    llm=llm,
    agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True
)

# Your agent can now make payments!
agent.run("Check my Nory wallet balance")
agent.run("Pay 5 USDC to GkXn...abc for the API access")
agent.run("Use x402 to fetch data from https://api.example.com/premium-data")
```

## Configuration

Set your environment variables:

```bash
export NORY_WALLET_KEY="your-solana-wallet-private-key"
export NORY_API_URL="https://api.noryx402.com"  # Optional, this is the default
```

## Available Tools

### `nory_check_balance`
Check your wallet balance before making payments.

```python
from nory_langchain import NoryCheckBalanceTool

tool = NoryCheckBalanceTool()
result = tool.run({"currency": "USDC"})
```

### `nory_pay`
Make direct payments to any Solana wallet address.

```python
from nory_langchain import NoryPayTool

tool = NoryPayTool()
result = tool.run({
    "recipient": "GkXn9FqJ4pT1qVz8hQJ9X5...",
    "amount": 5.0,
    "memo": "Payment for API access"
})
```

### `nory_x402_request`
Access x402-enabled APIs with automatic payment handling. When the server returns HTTP 402 (Payment Required), Nory automatically pays and retries.

```python
from nory_langchain import NoryX402RequestTool

tool = NoryX402RequestTool()
result = tool.run({
    "url": "https://api.noryx402.com/data/crypto",
    "method": "GET"
})
```

### `nory_discover_services`
Find available x402-enabled services and APIs.

```python
from nory_langchain import NoryDiscoverServicesTool

tool = NoryDiscoverServicesTool()
result = tool.run({
    "category": "ai",
    "max_price": 0.01
})
```

### `nory_payment_history`
View your recent payment transactions.

```python
from nory_langchain import NoryPaymentHistoryTool

tool = NoryPaymentHistoryTool()
result = tool.run({"limit": 10})
```

## Using with Different Agent Types

### ReAct Agent

```python
from langchain.agents import create_react_agent
from langchain import hub
from nory_langchain import get_nory_tools

prompt = hub.pull("hwchase17/react")
tools = get_nory_tools()

agent = create_react_agent(llm, tools, prompt)
```

### OpenAI Functions Agent

```python
from langchain.agents import create_openai_functions_agent
from langchain import hub
from nory_langchain import get_nory_tools

prompt = hub.pull("hwchase17/openai-functions-agent")
tools = get_nory_tools()

agent = create_openai_functions_agent(llm, tools, prompt)
```

### Tool Calling Agent (Recommended)

```python
from langchain.agents import create_tool_calling_agent, AgentExecutor
from langchain_core.prompts import ChatPromptTemplate
from nory_langchain import get_nory_tools

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant with payment capabilities."),
    ("human", "{input}"),
    ("placeholder", "{agent_scratchpad}"),
])

tools = get_nory_tools()
agent = create_tool_calling_agent(llm, tools, prompt)
executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

executor.invoke({"input": "Check my balance and pay 1 USDC to Alice"})
```

## How x402 Works

1. **Request** - Agent makes HTTP request to x402-enabled endpoint
2. **402 Response** - Server returns HTTP 402 with payment requirements
3. **Payment** - Nory creates and signs a Solana transaction
4. **Settlement** - Transaction confirms in ~400ms
5. **Access** - Agent retries with payment proof, receives the resource

All of this happens automatically when using `nory_x402_request`.

## Use Cases

- **API Access**: Pay-per-call access to premium APIs
- **AI Services**: Pay for model inference, image generation
- **Data Feeds**: Access premium market data, research reports
- **Compute**: Purchase serverless compute, GPU time
- **Agent-to-Agent**: Agents paying other agents for services

## Security

- **Non-custodial**: Your private key stays on your machine
- **Per-transaction limits**: Configure maximum payment amounts
- **Audit logging**: All transactions are logged

## Links

- [Nory Website](https://noryx402.com)
- [x402 Protocol](https://noryx402.com/docs/x402)
- [API Documentation](https://noryx402.com/docs/api)
- [MCP Server](https://npmjs.com/package/nory-mcp-server)

## License

MIT
