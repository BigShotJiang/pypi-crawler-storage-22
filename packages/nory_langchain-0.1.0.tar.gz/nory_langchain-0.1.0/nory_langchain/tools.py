"""
Nory LangChain Tools - x402 Payment Tools for AI Agents

These tools enable LangChain agents to make instant payments using the x402 protocol.
Payments settle on Solana in under 1 second.
"""

from typing import Optional, Type, List, Dict, Any
from pydantic import BaseModel, Field
from langchain.tools import BaseTool
import os
import json
import httpx


# Configuration
NORY_API_URL = os.environ.get("NORY_API_URL", "https://api.noryx402.com")
NORY_WALLET_KEY = os.environ.get("NORY_WALLET_KEY", "")


class NoryClient:
    """HTTP client for Nory API interactions."""

    def __init__(self, api_url: str = NORY_API_URL, wallet_key: str = NORY_WALLET_KEY):
        self.api_url = api_url
        self.wallet_key = wallet_key
        self.client = httpx.Client(timeout=30.0)

    def get_balance(self, currency: str = "USDC") -> Dict[str, Any]:
        """Get wallet balance."""
        response = self.client.get(
            f"{self.api_url}/wallet/balance",
            headers={"Authorization": f"Bearer {self.wallet_key}"},
            params={"currency": currency}
        )
        response.raise_for_status()
        return response.json()

    def make_payment(self, recipient: str, amount: float, memo: Optional[str] = None) -> Dict[str, Any]:
        """Make a direct payment."""
        response = self.client.post(
            f"{self.api_url}/payments",
            headers={"Authorization": f"Bearer {self.wallet_key}"},
            json={"recipient": recipient, "amount": amount, "memo": memo}
        )
        response.raise_for_status()
        return response.json()

    def x402_request(
        self,
        url: str,
        method: str = "GET",
        body: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """Make an x402-enabled HTTP request with automatic payment."""
        response = self.client.post(
            f"{self.api_url}/x402/request",
            headers={"Authorization": f"Bearer {self.wallet_key}"},
            json={"url": url, "method": method, "body": body, "headers": headers}
        )
        response.raise_for_status()
        return response.json()

    def discover_services(
        self,
        category: Optional[str] = None,
        max_price: Optional[float] = None
    ) -> Dict[str, Any]:
        """Discover x402-enabled services."""
        params = {}
        if category:
            params["category"] = category
        if max_price is not None:
            params["maxPrice"] = max_price

        response = self.client.get(
            f"{self.api_url}/services",
            headers={"Authorization": f"Bearer {self.wallet_key}"},
            params=params
        )
        response.raise_for_status()
        return response.json()

    def get_payment_history(self, limit: int = 10, offset: int = 0) -> Dict[str, Any]:
        """Get payment history."""
        response = self.client.get(
            f"{self.api_url}/payments/history",
            headers={"Authorization": f"Bearer {self.wallet_key}"},
            params={"limit": limit, "offset": offset}
        )
        response.raise_for_status()
        return response.json()


# Shared client instance
_client: Optional[NoryClient] = None

def get_client() -> NoryClient:
    global _client
    if _client is None:
        _client = NoryClient()
    return _client


# Input Schemas
class CheckBalanceInput(BaseModel):
    """Input for checking wallet balance."""
    currency: str = Field(
        default="USDC",
        description="Currency to check balance for (default: USDC)"
    )


class PayInput(BaseModel):
    """Input for making a payment."""
    recipient: str = Field(
        description="The recipient's wallet address (Solana public key)"
    )
    amount: float = Field(
        description="Amount to pay in USDC",
        gt=0
    )
    memo: Optional[str] = Field(
        default=None,
        description="Optional memo/description for the payment"
    )


class X402RequestInput(BaseModel):
    """Input for making an x402 HTTP request."""
    url: str = Field(
        description="The x402-enabled API endpoint URL"
    )
    method: str = Field(
        default="GET",
        description="HTTP method (GET, POST, PUT, DELETE)"
    )
    body: Optional[str] = Field(
        default=None,
        description="Request body for POST/PUT requests (JSON string)"
    )
    headers: Optional[Dict[str, str]] = Field(
        default=None,
        description="Additional headers to include"
    )


class DiscoverServicesInput(BaseModel):
    """Input for discovering x402 services."""
    category: Optional[str] = Field(
        default=None,
        description="Filter services by category (e.g., 'data', 'compute', 'ai')"
    )
    max_price: Optional[float] = Field(
        default=None,
        description="Maximum price per request in USDC"
    )


class PaymentHistoryInput(BaseModel):
    """Input for getting payment history."""
    limit: int = Field(
        default=10,
        description="Number of transactions to return",
        ge=1,
        le=100
    )
    offset: int = Field(
        default=0,
        description="Offset for pagination",
        ge=0
    )


# Tools
class NoryCheckBalanceTool(BaseTool):
    """Tool for checking wallet balance before making payments."""

    name: str = "nory_check_balance"
    description: str = (
        "Check your Nory wallet balance. Use this before making payments to ensure "
        "sufficient funds. Returns available balance in USDC and SOL."
    )
    args_schema: Type[BaseModel] = CheckBalanceInput

    def _run(self, currency: str = "USDC") -> str:
        """Check wallet balance."""
        try:
            client = get_client()
            result = client.get_balance(currency)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})

    async def _arun(self, currency: str = "USDC") -> str:
        """Async version - currently falls back to sync."""
        return self._run(currency)


class NoryPayTool(BaseTool):
    """Tool for making direct payments to wallet addresses."""

    name: str = "nory_pay"
    description: str = (
        "Make a direct USDC payment to a Solana wallet address. Use this to send funds "
        "to a specific recipient. Payments settle in under 1 second. "
        "Requires: recipient address and amount. Optional: memo."
    )
    args_schema: Type[BaseModel] = PayInput

    def _run(self, recipient: str, amount: float, memo: Optional[str] = None) -> str:
        """Make a payment."""
        try:
            client = get_client()
            result = client.make_payment(recipient, amount, memo)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})

    async def _arun(self, recipient: str, amount: float, memo: Optional[str] = None) -> str:
        """Async version - currently falls back to sync."""
        return self._run(recipient, amount, memo)


class NoryX402RequestTool(BaseTool):
    """Tool for making HTTP requests to x402-enabled APIs with automatic payment."""

    name: str = "nory_x402_request"
    description: str = (
        "Make an HTTP request to an x402-enabled API endpoint. This tool automatically "
        "handles the payment negotiation: if the server returns HTTP 402 (Payment Required), "
        "Nory will pay the required amount and retry the request. Use this to access "
        "paid APIs, premium data sources, and x402-enabled services. "
        "Settlement happens on Solana in under 1 second."
    )
    args_schema: Type[BaseModel] = X402RequestInput

    def _run(
        self,
        url: str,
        method: str = "GET",
        body: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None
    ) -> str:
        """Make an x402 request."""
        try:
            client = get_client()
            result = client.x402_request(url, method, body, headers)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})

    async def _arun(
        self,
        url: str,
        method: str = "GET",
        body: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None
    ) -> str:
        """Async version - currently falls back to sync."""
        return self._run(url, method, body, headers)


class NoryDiscoverServicesTool(BaseTool):
    """Tool for discovering available x402-enabled services."""

    name: str = "nory_discover_services"
    description: str = (
        "Discover available x402-enabled services and APIs. Use this to find services "
        "you can pay for with micropayments. Filter by category (ai, data, compute) "
        "or maximum price per request."
    )
    args_schema: Type[BaseModel] = DiscoverServicesInput

    def _run(
        self,
        category: Optional[str] = None,
        max_price: Optional[float] = None
    ) -> str:
        """Discover services."""
        try:
            client = get_client()
            result = client.discover_services(category, max_price)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})

    async def _arun(
        self,
        category: Optional[str] = None,
        max_price: Optional[float] = None
    ) -> str:
        """Async version - currently falls back to sync."""
        return self._run(category, max_price)


class NoryPaymentHistoryTool(BaseTool):
    """Tool for viewing payment history."""

    name: str = "nory_payment_history"
    description: str = (
        "Get your recent payment history. Use this to review past transactions, "
        "check payment status, and track spending."
    )
    args_schema: Type[BaseModel] = PaymentHistoryInput

    def _run(self, limit: int = 10, offset: int = 0) -> str:
        """Get payment history."""
        try:
            client = get_client()
            result = client.get_payment_history(limit, offset)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})

    async def _arun(self, limit: int = 10, offset: int = 0) -> str:
        """Async version - currently falls back to sync."""
        return self._run(limit, offset)


def get_nory_tools() -> List[BaseTool]:
    """
    Get all Nory payment tools for use with LangChain agents.

    Returns:
        List of LangChain tools for x402 payments.

    Example:
        ```python
        from langchain.agents import initialize_agent, AgentType
        from langchain_openai import ChatOpenAI
        from nory_langchain import get_nory_tools

        llm = ChatOpenAI(model="gpt-4")
        tools = get_nory_tools()

        agent = initialize_agent(
            tools=tools,
            llm=llm,
            agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION,
            verbose=True
        )

        agent.run("Check my Nory wallet balance")
        ```
    """
    return [
        NoryCheckBalanceTool(),
        NoryPayTool(),
        NoryX402RequestTool(),
        NoryDiscoverServicesTool(),
        NoryPaymentHistoryTool(),
    ]
