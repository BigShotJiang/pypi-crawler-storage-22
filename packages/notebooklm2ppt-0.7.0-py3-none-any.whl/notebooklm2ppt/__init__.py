"""NotebookLM2PPT - 将PDF文档转换为PowerPoint演示文稿的自动化工具"""

__version__ = "0.7.0"
__author__ = "Elliott Zheng"
