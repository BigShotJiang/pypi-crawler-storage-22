"""NotebookLM MCP Server.

This MCP provides access to NotebookLM (notebooklm.google.com)
using undocumented internal APIs. Tested with personal/free tier accounts.
May work with Google Workspace accounts but has not been tested.

WARNING: This uses undocumented internal APIs that may change at any time.
"""

__version__ = "0.2.5"
