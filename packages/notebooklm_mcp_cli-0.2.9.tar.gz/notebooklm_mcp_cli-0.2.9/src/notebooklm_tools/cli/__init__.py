"""CLI interface for NotebookLM."""
