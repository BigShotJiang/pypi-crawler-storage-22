"""Tests for nothx."""
