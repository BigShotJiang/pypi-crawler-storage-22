Django Notification Kit
Django Notification Kit, Django projeleri için tasarlanmış; çok kanallı (Email / SMS / Push) bildirim gönderimini yöneten, modüler ve genişletilebilir bir altyapıdır. Sistemin temel amacı; bildirim gönderim süreçlerini API – Service – Backend – Task katmanlarına ayırarak yüksek test edilebilirlik ve sürdürülebilirlik sağlamaktır.



Kapsam (v1.0.0 – MVP)
Bu versiyon, profesyonel bir bildirim sistemi için gerekli olan şu temel bileşenleri sunar:

Abstract Model Yapısı: Genişletilmeye hazır taban modeller.

Concrete Modeller: Notification, Template, Preference ve Log yapıları.

SMTP Email Backend: Standart e-posta gönderim desteği.

Base Notification Service: İş mantığını yöneten merkezi servis.

Celery Task Factory: Ölçeklenebilir, asenkron gönderim desteği.

DRF API: Standartlara uygun API uçları ve Serializer'lar.

Merkezi Ayar Yönetimi: NOTIFICATION_KIT üzerinden tam kontrol.

Full Testing: Unit, API ve Performans testleri.



Mimari Genel Bakış
Sistem, sorumlulukların net ayrıştırıldığı Layered Architecture (Katmanlı Mimari) prensibiyle tasarlanmıştır.Katmanların SorumluluklarıKatmanSorumluluk AlanıAPIRequest validation, permission kontrolü, throttling.Serviceİş kuralları, kanal seçimi, retry logic yönetimi.BackendKanal spesifik (Email, SMS vb.) düşük seviyeli implementasyon.TaskAsenkron (Async) ve toplu (Batch) işlem yönetimi (Celery).ModelsVeri şeması; Notification, Template ve Kullanıcı tercihleri.SettingsMerkezi ve projeye özel override edilebilir konfigürasyon.



Ayar Yönetimi
Paket içi ayarlar notification_kit/settings.py dosyasında tanımlıdır. Proje bazlı özelleştirmeler için ana settings.py dosyanızda NOTIFICATION_KIT sözlüğünü kullanabilirsiniz.

Python
# project/settings.py

NOTIFICATION_KIT = {
    "ASYNC": True,
    "MAX_RETRIES": 5,
    "EMAIL": {
        "FROM_EMAIL": "noreply@example.com",
        "RATE_LIMIT": 200,
    },
}
Not: Hassas veriler (API Key, Şifre vb.) her zaman çevre değişkenleri (environment variables) üzerinden yönetilmelidir.



Teknik Implementasyon
1. Backend Yapısı
Her kanal (SMS, Email, Push) için bir backend sınıfı bulunur. Yeni bir sağlayıcı eklemek oldukça basittir:

Python
class BaseBackend:
    def send(self, notification):
        raise NotImplementedError("Bu metod implemente edilmelidir.")
2. Service Katmanı
İş mantığının kalbidir. API'den gelen isteği alır, hangi kanalın kullanılacağına karar verir ve gerekirse işi Celery'ye devreder.

Kanal Seçimi: Template üzerinden dinamik kanal yönetimi.

Soyutlama: Backend implementasyonundan bağımsız çalışma.

3. API Katmanı
Yalnızca bildirim oluşturma ve tetikleme sorumluluğunu taşır.

Validation: Serializer'lar ile veri doğruluğu garanti edilir.

Security: Permission sınıfları ile yetkisiz erişim engellenir.



Güvenlik Yaklaşımı
Veri Gizliliği: Kişisel veriler (PII) kesinlikle loglanmaz.

Hız Sınırı: API düzeyinde Throttling ile brute-force ve aşırı yüklenme engellenir.

Denetim: Tüm gönderim denemeleri ve sonuçları NotificationLog üzerinden izlenebilir.



Test Stratejisi
Sistem, Pytest altyapısı kullanılarak aşağıdaki seviyelerde test edilmektedir:

Model: Veri bütünlüğü ve ilişki testleri.

Service: İş mantığı ve kanal yönlendirme testleri.

Backend: Provider entegrasyon (mock) testleri.

API: Endpoint erişim ve veri formatı testleri.

