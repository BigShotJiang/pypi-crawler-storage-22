"""
Reusable Django Notification Kit
"""

__version__ = "1.0.1"
