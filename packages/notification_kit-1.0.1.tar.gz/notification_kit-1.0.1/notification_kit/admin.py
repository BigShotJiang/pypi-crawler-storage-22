from django.contrib import admin

from notification_kit.models.concrete import (
    Notification,
    NotificationTemplate,
    NotificationPreference,
    NotificationLog,
)


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    """
    Ana Notification modeli için admin ayarları
    """

    list_display = (
        "id",
        "user",
        "channel",
        "status",
        "priority",
        "created_at",
    )

    list_filter = (
        "channel",
        "status",
        "priority",
    )

    search_fields = (
        "title",
        "body",
        "user__username",
        "user__email",
    )

    readonly_fields = (
        "sent_at",
        "read_at",
        "created_at",
        "updated_at",
    )

    ordering = ("-created_at",)


@admin.register(NotificationTemplate)
class NotificationTemplateAdmin(admin.ModelAdmin):
    """
    Bildirim şablonları için admin ayarları
    """

    list_display = (
        "code",
        "name",
        "channel",
        "is_active",
    )

    list_filter = (
        "channel",
        "is_active",
    )

    search_fields = (
        "code",
        "name",
        "description",
    )

    ordering = ("code",)


@admin.register(NotificationPreference)
class NotificationPreferenceAdmin(admin.ModelAdmin):
    """
    Kullanıcı bildirim tercihleri admin ayarları
    """

    list_display = (
        "id",
        "user",
        "channel",
        "is_enabled",
        "frequency",
    )

    list_filter = (
        "channel",
        "is_enabled",
        "frequency",
    )

    search_fields = (
        "user__username",
        "user__email",
    )


@admin.register(NotificationLog)
class NotificationLogAdmin(admin.ModelAdmin):
    """
    Bildirim logları admin ayarları
    """

    list_display = (
        "notification_id",
        "action",
        "old_status",
        "new_status",
        "created_at",
    )

    list_filter = (
        "action",
        "created_at",
    )

    search_fields = (
        "notification_id",
        "action",
    )

    readonly_fields = (
        "notification_id",
        "action",
        "old_status",
        "new_status",
        "details",
        "ip_address",
        "user_agent",
        "created_at",
    )

    ordering = ("-created_at",)
