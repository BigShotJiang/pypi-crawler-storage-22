from rest_framework.permissions import BasePermission, SAFE_METHODS


class IsAdminOrReadOnly(BasePermission):
    """
    Okuma işlemleri herkese açık olabilir.
    Yazma / silme işlemleri sadece admin (staff) kullanıcıya izinlidir.
    """

    def has_permission(self, request, view):
        # GET, HEAD, OPTIONS serbest
        if request.method in SAFE_METHODS:
            return True

        # Yazma işlemleri için admin şartı
        return bool(request.user and request.user.is_staff)
