from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import NotificationViewSet, NotificationPreferenceViewSet, admin_send_notification

router = DefaultRouter()
router.register(r"notifications", NotificationViewSet, basename="notification")
router.register(r"preferences", NotificationPreferenceViewSet, basename="preference")

urlpatterns = [
    path("api/", include(router.urls)),
    path(
        "admin/notifications/send/",
        admin_send_notification,
        name="admin-notifications-send",
    ),
]
