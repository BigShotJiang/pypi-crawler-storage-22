from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .serializers import NotificationSerializer, NotificationPreferenceSerializer
from ..models.concrete import Notification, NotificationPreference
from notification_kit.api.permissions import IsAdminOrReadOnly
from django.contrib.auth import get_user_model
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated

from ..models import Notification  # concrete Notification

class NotificationViewSet(viewsets.ModelViewSet):
    queryset = Notification.objects.all()
    serializer_class = NotificationSerializer
    permission_classes = [IsAdminOrReadOnly]

    @action(detail=True, methods=["post"])
    def read(self, request, pk=None):
        notification = self.get_object()
        notification.mark_as_read()
        return Response({"status": "ok"})

    @action(detail=False, methods=["post"])
    def read_all(self, request):
        notifications = Notification.objects.all()  # filtreleme eklenebilir
        for n in notifications:
            n.mark_as_read()
        return Response({"status": "ok"})

    @action(detail=False, methods=["get"])
    def unread_count(self, request):
        count = Notification.objects.filter(read_at__isnull=True).count()
        return Response({"unread_count": count})

class NotificationPreferenceViewSet(viewsets.ModelViewSet):
    queryset = NotificationPreference.objects.all()
    serializer_class = NotificationPreferenceSerializer

User = get_user_model()


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def admin_send_notification(request):
    """
    Admin/System endpoint:
    recipient_id + title + body alır, Notification kaydı üretir.
    Testin aradığı url-name: admin-notifications-send
    """
    recipient_id = request.data.get("recipient_id")
    title = request.data.get("title")
    body = request.data.get("body")

    if not recipient_id or not title or not body:
        return Response(
            {"detail": "recipient_id, title ve body zorunlu."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    try:
        user = User.objects.get(id=recipient_id)
    except User.DoesNotExist:
        return Response(
            {"detail": "recipient bulunamadı."},
            status=status.HTTP_404_NOT_FOUND,
        )

    channel = request.data.get("channel", "email")
    priority = request.data.get("priority", getattr(Notification, "PRIORITY_NORMAL", "normal"))

    n = Notification.objects.create(
        user=user,  # <- sizin modelde NOT NULL olan alan bu
        channel=channel,
        status=getattr(Notification, "STATUS_PENDING", "pending"),
        title=title,
        body=body,
        priority=priority,
        metadata=request.data.get("metadata", {}),
    )

    return Response(
        {"id": n.id, "status": n.status},
        status=status.HTTP_201_CREATED,
    )