from django.apps import AppConfig


class NotificationKitConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "notification_kit"
    verbose_name = "Notification Kit"
