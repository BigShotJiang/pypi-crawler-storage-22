# notification_kit/backends/base.py
from __future__ import annotations

import logging
import time
from abc import ABC
from typing import Any

from notification_kit.settings import get_settings
from notification_kit.utils.validators import mask_pii

logger = logging.getLogger(__name__)


class BaseNotificationBackend(ABC):
    """
    Tüm bildirim backend'lerinin uyması gereken temel arayüz.
    Email, SMS ve Push backend'leri bu sınıftan türetilmelidir.
    """

    name: str = ""
    channel: str = ""

    def __init__(self) -> None:
        settings = get_settings()

        self.max_retries: int = settings.get("MAX_RETRIES", 3)
        self.retry_delay: int = settings.get("RETRY_DELAY", 300)

        channel_settings = settings.get(self.channel.upper(), {})
        self.batch_size: int = channel_settings.get("BATCH_SIZE", 1)
        self.rate_limit: int = channel_settings.get("RATE_LIMIT", 60)

    # -------------------------------------------------
    # Interface (Varsayılan: override edilmesi beklenir)
    # Not: abstract bırakmıyoruz ki testlerde DummyBackend
    # rahat instantiate olabilsin.
    # -------------------------------------------------
    def send(self, notification: Any) -> bool:
        """
        Bildirimi gönderir.
        Başarılıysa True, başarısızsa False döner.
        """
        raise NotImplementedError(f"{self.__class__.__name__}.send() implement edilmedi")

    def validate_recipient(self, recipient: Any) -> bool:
        """
        Alıcı bilgisini doğrular.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__}.validate_recipient() implement edilmedi"
        )

    def get_delivery_status(self, notification: Any) -> str:
        """
        Bildirimin teslim durumunu sorgular.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__}.get_delivery_status() implement edilmedi"
        )

    # --------------------
    # Ortak yardımcı metodlar
    # --------------------
    def format_message(self, template: str, context: dict) -> str:
        """
        Template ve context kullanarak mesaj içeriğini oluşturur.
        (Bu format, str.format bazlıdır. Django Template değil.)
        """
        try:
            return template.format(**context)
        except KeyError as exc:
            raise ValueError(f"Eksik template değişkeni: {exc}") from exc

    def sanitize_content(self, content: str) -> str:
        """
        İçeriği güvenli hale getirir.
        Zararlı karakterler ve gereksiz boşluklar temizlenir.
        """
        return (content or "").strip()

    # --------------------
    # Log + Retry helpers
    # --------------------
    def log_send_attempt(self, notification: Any, success: bool, error: Exception | None = None) -> None:
        """
        Bildirim gönderim denemesini loglar.
        PII veriler maskelenerek yazılır.
        """
        recipient = ""
        if hasattr(notification, "get_recipient_identifier"):
            try:
                recipient = str(notification.get_recipient_identifier())
            except Exception:
                recipient = ""

        safe_recipient = mask_pii(recipient) if recipient else ""

        payload = {
            "backend": self.name or self.__class__.__name__,
            "channel": self.channel,
            "recipient": safe_recipient,
            "success": success,
            "error": str(error) if error else None,
        }

        # stdout yerine logger kullanalım (testlerde de temiz)
        logger.info("[NOTIFICATION LOG] %s", payload)

    def handle_error(self, notification: Any, error: Exception) -> None:
        """
        Hata durumunda loglama + notification state günceller.
        """
        self.log_send_attempt(notification, success=False, error=error)

        if hasattr(notification, "mark_as_failed"):
            try:
                notification.mark_as_failed(str(error))
            except Exception:
                # notification mark_as_failed patlarsa testleri kırmayalım
                logger.exception("mark_as_failed çağrısı hata verdi")

    def should_retry(self, notification: Any, error: Exception) -> bool:
        """
        Bildirim tekrar denenmeli mi?
        """
        retry_count = getattr(notification, "retry_count", None)
        if retry_count is None:
            return False

        if retry_count >= self.max_retries:
            return False

        # basit backoff (settings.RETRY_DELAY)
        time.sleep(self.retry_delay)
        return True
