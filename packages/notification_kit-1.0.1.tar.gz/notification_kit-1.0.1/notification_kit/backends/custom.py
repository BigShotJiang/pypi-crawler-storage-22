from .email import BaseSMTPBackend
from .sms import BaseSMSBackend
from .push import BasePushBackend

class EmailBackend(BaseSMTPBackend):
    def build_email_message(self, notification):
        message = super().build_email_message(notification)
        # Proje özel footer ekle
        message.body += "\n\n-- Proje Footer --"
        return message

class SMSBackend(BaseSMSBackend):
    def send_sms(self, phone_number, message):
        # Örnek: Twilio API entegrasyonu
        return super().send_sms(phone_number, message)

class PushBackend(BasePushBackend):
    def build_payload(self, notification):
        payload = super().build_payload(notification)
        payload["custom"] = "Proje özel data"
        return payload
