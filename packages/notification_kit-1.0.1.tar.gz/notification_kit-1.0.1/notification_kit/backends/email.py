from abc import abstractmethod
from typing import Any, List
from django.core.mail import EmailMessage, get_connection

from notification_kit.backends.base import BaseNotificationBackend
from notification_kit.settings import get_settings


class BaseSMTPBackend(BaseNotificationBackend):
    """
    SMTP tabanlı email gönderimi için temel backend.
    """

    name = "smtp"
    channel = "email"

    # --------------------
    # Zorunlu metodlar
    # --------------------

    def send(self, notification: Any) -> bool:
        """
        Email bildirimi gönderir.
        """
        try:
            message = self.build_email_message(notification)
            connection = self.get_connection()
            message.connection = connection
            message.send(fail_silently=False)
            return True
        except Exception as exc:
            self.handle_error(notification, exc)
            return False

    def validate_recipient(self, recipient: str) -> bool:
        """
        Email adresi doğrulaması.
        """
        return "@" in recipient

    def get_delivery_status(self, notification: Any) -> str:
        """
        SMTP tarafında teslim durumu doğrudan bilinemez.
        """
        return "UNKNOWN"

    # --------------------
    # Email'e özel metodlar
    # --------------------

    def get_connection(self):
        """
        SMTP bağlantısını oluşturur.
        """
        return get_connection()

    def build_email_message(self, notification: Any) -> EmailMessage:
        """
        Django EmailMessage objesini oluşturur.
        """
        settings = get_settings()
        email_settings = settings.get("EMAIL", {})

        subject = notification.title
        body = notification.body
        from_email = self.get_from_email()
        to = [notification.get_recipient_identifier()]

        message = EmailMessage(
            subject=subject,
            body=body,
            from_email=from_email,
            to=to,
            reply_to=self.get_reply_to(),
        )

        if notification.html_body:
            message.content_subtype = "html"

        return message

    def add_attachments(self, message: EmailMessage, attachments: List[Any]) -> None:
        """
        Email eklerini mesaja ekler.
        """
        for attachment in attachments:
            message.attach(*attachment)

    def get_from_email(self) -> str:
        """
        Gönderen email adresini döner.
        """
        settings = get_settings()
        email_settings = settings.get("EMAIL", {})
        return email_settings.get("FROM_EMAIL") or ""

    def get_reply_to(self) -> list:
        """
        Yanıt adreslerini döner.
        """
        settings = get_settings()
        return settings.get("EMAIL", {}).get("REPLY_TO", [])
