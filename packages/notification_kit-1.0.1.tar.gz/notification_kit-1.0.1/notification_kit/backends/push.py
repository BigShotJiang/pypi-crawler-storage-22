from abc import abstractmethod
from typing import Any, Dict, List

from notification_kit.backends.base import BaseNotificationBackend


class BasePushBackend(BaseNotificationBackend):
    """
    Push notification gönderimi için temel backend.
    """

    name = "push"
    channel = "push"

    # --------------------
    # Zorunlu metodlar
    # --------------------

    @abstractmethod
    def send_push(self, device_token: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    def send_multicast(
        self, device_tokens: List[str], payload: Dict[str, Any]
    ) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    def register_device(
        self, user: Any, device_token: str, platform: str
    ) -> bool:
        raise NotImplementedError

    @abstractmethod
    def unregister_device(self, device_token: str) -> bool:
        raise NotImplementedError

    # --------------------
    # Ortak yardımcı metodlar
    # --------------------

    def build_payload(self, notification: Any) -> Dict[str, Any]:
        return {
            "title": notification.title,
            "body": notification.body,
            "metadata": notification.metadata,
        }

    def validate_device_token(self, token: str) -> bool:
        return bool(token)
