from abc import abstractmethod
from typing import Any, Dict

from notification_kit.backends.base import BaseNotificationBackend


class BaseSMSBackend(BaseNotificationBackend):
    """
    SMS gönderimi için temel backend.
    """

    name = "sms"
    channel = "sms"

    # --------------------
    # Zorunlu metodlar
    # --------------------

    @abstractmethod
    def send_sms(self, phone_number: str, message: str) -> Dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    def check_balance(self) -> float:
        raise NotImplementedError

    @abstractmethod
    def get_delivery_report(self, message_id: str) -> Dict[str, Any]:
        raise NotImplementedError

    # --------------------
    # Ortak yardımcı metodlar
    # --------------------

    def format_phone_number(self, number: str) -> str:
        return number.replace(" ", "").replace("-", "")

    def validate_phone_number(self, number: str) -> bool:
        return number.isdigit() and len(number) >= 10

    def truncate_message(self, message: str, max_length: int) -> str:
        return message[:max_length]

    def calculate_sms_count(self, message: str) -> int:
        return max(1, len(message) // 160)
