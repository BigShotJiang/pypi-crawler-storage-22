"""
notification_kit.exceptions

Bu dosya, bildirim sistemi boyunca kullanılacak tüm domain-level
exception sınıflarını içerir.

Amaç:
- Teknik hatalar ile iş (domain) hatalarını ayırmak
- Backend, template, validation ve rate-limit senaryolarını
  açık ve standart bir yapı ile temsil etmek
- Celery, service ve backend katmanlarında tutarlı hata yönetimi sağlamak
"""


class NotificationException(Exception):
    """
    Bildirim sistemi için temel exception sınıfı.

    Tüm özel bildirim hataları bu sınıftan türemelidir.
    Üst katmanlar (service, celery task, API) bu sınıfı
    tek noktadan yakalayabilir.
    """

    def __init__(self, message: str | None = None):
        super().__init__(message or "Bildirim islemi sirasinda bir hata olustu.")


class NotificationSendError(NotificationException):
    """
    Bildirim backend uzerinden gonderilirken olusan hatalar.

    Ornek senaryolar:
    - SMTP baglanti hatasi
    - SMS saglayici timeout
    - Push provider authentication hatasi
    """

    def __init__(
        self,
        notification,
        backend,
        original_error: Exception | None = None,
    ):
        self.notification = notification
        self.backend = backend
        self.original_error = original_error

        message = (
            "Bildirim gonderimi basarisiz. "
            f"Backend: {getattr(backend, 'name', backend)}"
        )
        super().__init__(message)


class NotificationTemplateError(NotificationException):
    """
    Bildirim sablonu render edilirken olusan hatalar.

    Ornek:
    - Context icinde eksik degiskenler
    - Hatali template syntax
    """

    def __init__(
        self,
        template_code: str,
        missing_variables: list[str] | None = None,
    ):
        self.template_code = template_code
        self.missing_variables = missing_variables or []

        message = f"Sablon hatasi. Template kodu: {template_code}"
        if self.missing_variables:
            message += f" | Eksik degiskenler: {', '.join(self.missing_variables)}"

        super().__init__(message)


class NotificationValidationError(NotificationException):
    """
    Bildirim verisi dogrulama asamasinda olusan hatalar.

    Ornek:
    - Gecersiz alici bilgisi
    - Desteklenmeyen kanal
    - Eksik zorunlu alanlar
    """

    def __init__(
        self,
        notification,
        errors,
    ):
        self.notification = notification
        self.errors = errors

        message = "Bildirim dogrulama hatasi."
        super().__init__(message)


class NotificationBackendError(NotificationException):
    """
    Backend konfigürasyonu veya backend seviyesinde olusan hatalar.

    Ornek:
    - Backend tanimli degil
    - Yanlis backend class path
    - Gerekli ayarlar eksik
    """

    def __init__(
        self,
        backend_name: str,
        original_error: Exception | None = None,
    ):
        self.backend_name = backend_name
        self.original_error = original_error

        message = f"Backend hatasi. Backend adi: {backend_name}"
        super().__init__(message)


class NotificationRateLimitError(NotificationException):
    """
    Backend hiz limiti asildiginda kullanilir.

    Ornek:
    - Dakikada maksimum SMS sayisi asildi
    - Email provider rate limit uyguladi
    """

    def __init__(
        self,
        backend_name: str,
        retry_after: int | None = None,
    ):
        self.backend_name = backend_name
        self.retry_after = retry_after

        message = f"Hiz limiti asildi. Backend: {backend_name}"
        if retry_after:
            message += f" | Tekrar deneme suresi: {retry_after} saniye"

        super().__init__(message)


class NotificationQuotaExceededError(NotificationException):
    """
    Provider tarafindan tanimlanan kota asildiginda kullanilir.

    Ornek:
    - Gunluk SMS kotasi bitti
    - Aylik push notification limiti doldu
    """

    def __init__(
        self,
        backend_name: str,
        quota_type: str | None = None,
    ):
        self.backend_name = backend_name
        self.quota_type = quota_type

        message = f"Kota asimi. Backend: {backend_name}"
        if quota_type:
            message += f" | Kota tipi: {quota_type}"

        super().__init__(message)
