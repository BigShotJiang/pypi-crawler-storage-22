import logging

logger = logging.getLogger("notification_audit")


class NotificationAuditMiddleware:
    """
    API erişimlerini audit amaçlı loglar.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        user = request.user if request.user.is_authenticated else "anonymous"

        logger.info(
            "API_ACCESS",
            extra={
                "user": str(user),
                "method": request.method,
                "path": request.path,
                "status_code": response.status_code,
            },
        )

        return response
