from __future__ import annotations

from typing import Any, Dict
from abc import ABCMeta, abstractmethod
from datetime import time

from django.db import models
from django.utils import timezone
from django.template import Template, Context
from django.core.exceptions import ValidationError

# =========================================================
# Ortak metaclass: Django ModelBase + ABCMeta uyumu
# =========================================================
class ModelABCMeta(ABCMeta, type(models.Model)):
    """
    Django model abstract sınıfları ile Python ABC sınıflarını uyumlu hale getirir.
    Böylece metaclass conflict hatası ortadan kalkar.
    """
    pass

# =========================================================
# Bildirim abstract modeli
# =========================================================
class AbstractNotification(models.Model, metaclass=ModelABCMeta):
    """
    Tüm bildirim modellerinin temel abstract sınıfıdır.
    Email, SMS, Push gibi tüm bildirimler bu sınıftan türetilmelidir.
    """
    # --------------------
    # Durum seçenekleri
    # --------------------
    STATUS_PENDING = "pending"
    STATUS_QUEUED = "queued"
    STATUS_SENDING = "sending"
    STATUS_SENT = "sent"
    STATUS_DELIVERED = "delivered"
    STATUS_READ = "read"
    STATUS_FAILED = "failed"
    STATUS_CANCELLED = "cancelled"

    STATUS_CHOICES = [
        (STATUS_PENDING, "Bekliyor"),
        (STATUS_QUEUED, "Kuyrukta"),
        (STATUS_SENDING, "Gönderiliyor"),
        (STATUS_SENT, "Gönderildi"),
        (STATUS_DELIVERED, "Teslim Edildi"),
        (STATUS_READ, "Okundu"),
        (STATUS_FAILED, "Başarısız"),
        (STATUS_CANCELLED, "İptal Edildi"),
    ]

    # --------------------
    # Öncelik seçenekleri
    # --------------------
    PRIORITY_LOW = "low"
    PRIORITY_NORMAL = "normal"
    PRIORITY_HIGH = "high"
    PRIORITY_URGENT = "urgent"

    PRIORITY_CHOICES = [
        (PRIORITY_LOW, "Düşük"),
        (PRIORITY_NORMAL, "Normal"),
        (PRIORITY_HIGH, "Yüksek"),
        (PRIORITY_URGENT, "Acil"),
    ]

    # --------------------
    # Temel alanlar
    # --------------------
    channel = models.CharField(max_length=20, help_text="Bildirim kanalı (email, sms, push vb.)")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_PENDING)
    title = models.CharField(max_length=255, help_text="Bildirim başlığı")
    body = models.TextField(help_text="Bildirim içeriği (plain text)")
    html_body = models.TextField(blank=True, help_text="HTML formatındaki içerik")
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default=PRIORITY_NORMAL)
    scheduled_at = models.DateTimeField(null=True, blank=True, help_text="Zamanlanmış gönderim zamanı")
    sent_at = models.DateTimeField(null=True, blank=True, help_text="Gerçek gönderim zamanı")
    read_at = models.DateTimeField(null=True, blank=True, help_text="Okunma zamanı")
    error_message = models.TextField(blank=True, help_text="Hata mesajı")
    retry_count = models.PositiveIntegerField(default=0, help_text="Kaç kez tekrar denendi")
    max_retries = models.PositiveIntegerField(default=3, help_text="Maksimum tekrar deneme sayısı")
    metadata = models.JSONField(default=dict, blank=True, help_text="Ek metadata bilgileri")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # --------------------
    # Davranış metodları
    # --------------------
    def mark_as_sent(self) -> None:
        """Bildirim gönderildi olarak işaretler."""
        self.status = self.STATUS_SENT
        self.sent_at = timezone.now()
        self.save(update_fields=["status", "sent_at", "updated_at"])

    def mark_as_failed(self, error_message: str) -> None:
        """Bildirim başarısız olarak işaretler ve retry sayısını artırır."""
        self.status = self.STATUS_FAILED
        self.error_message = error_message
        self.retry_count += 1
        self.save(update_fields=["status", "error_message", "retry_count", "updated_at"])

    def mark_as_read(self) -> None:
        """Bildirim okundu olarak işaretler."""
        self.status = self.STATUS_READ
        self.read_at = timezone.now()
        self.save(update_fields=["status", "read_at", "updated_at"])

    def can_retry(self) -> bool:
        """Bildirim tekrar denenebilir mi kontrol eder."""
        return self.retry_count < self.max_retries

    @abstractmethod
    def get_recipient_identifier(self) -> str:
        """
        Bildirimin gönderileceği alıcıyı döndürmelidir.
        Örn: email adresi, telefon numarası, device token
        """
        raise NotImplementedError

    def get_channel_backend(self) -> str:
        """Bildirimin ait olduğu kanal backend bilgisini döndürür."""
        return self.channel

    class Meta:
        abstract = True
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["channel", "status"]),
            models.Index(fields=["status", "scheduled_at"]),
            models.Index(fields=["priority", "status"]),
        ]

# =========================================================
# Bildirim Template abstract modeli
# =========================================================
class AbstractNotificationTemplate(models.Model, metaclass=ModelABCMeta):
    """
    Bildirim şablonlarının temel abstract sınıfıdır.
    """
    code = models.CharField(max_length=100, unique=True, help_text="Şablon kodu")
    name = models.CharField(max_length=255, help_text="Şablon adı")
    description = models.TextField(blank=True, help_text="Şablon açıklaması")
    channel = models.CharField(max_length=20, help_text="Hedef kanal")
    subject_template = models.CharField(max_length=500, help_text="Konu şablonu")
    body_template = models.TextField(help_text="İçerik şablonu")
    html_template = models.TextField(blank=True, help_text="HTML içerik şablonu")
    default_priority = models.CharField(max_length=10, default=AbstractNotification.PRIORITY_NORMAL)
    is_active = models.BooleanField(default=True)
    variables = models.JSONField(default=list, help_text="Kullanılabilir değişkenler")

    # --------------------
    # Template render metodları
    # --------------------
    def validate_context(self, context: Dict[str, Any]) -> None:
        """Context içinde eksik değişken var mı kontrol eder."""
        missing = set(self.variables) - set(context.keys())
        if missing:
            raise ValidationError(f"Eksik şablon değişkenleri: {', '.join(missing)}")

    def render_subject(self, context: Dict[str, Any]) -> str:
        """Subject şablonunu context ile renderlar."""
        self.validate_context(context)
        return Template(self.subject_template).render(Context(context))

    def render_body(self, context: Dict[str, Any]) -> str:
        """Body şablonunu context ile renderlar."""
        self.validate_context(context)
        return Template(self.body_template).render(Context(context))

    def render_html(self, context: Dict[str, Any]) -> str:
        """HTML şablonu varsa context ile renderlar, yoksa boş döner."""
        if not self.html_template:
            return ""
        self.validate_context(context)
        return Template(self.html_template).render(Context(context))

    def get_sample_context(self) -> Dict[str, Any]:
        """Örnek context üretir."""
        return {key: f"<{key}>" for key in self.variables}

    class Meta:
        abstract = True
        ordering = ["name"]
        indexes = [
            models.Index(fields=["code"]),
            models.Index(fields=["channel", "is_active"]),
        ]

# =========================================================
# Bildirim Tercih abstract modeli
# =========================================================
class AbstractNotificationPreference(models.Model, metaclass=ModelABCMeta):
    """
    Kullanıcı bildirim tercihlerini tutan temel abstract sınıf.
    """
    FREQUENCY_INSTANT = "instant"
    FREQUENCY_HOURLY = "hourly"
    FREQUENCY_DAILY = "daily"
    FREQUENCY_WEEKLY = "weekly"

    FREQUENCY_CHOICES = [
        (FREQUENCY_INSTANT, "Anlık"),
        (FREQUENCY_HOURLY, "Saatlik"),
        (FREQUENCY_DAILY, "Günlük"),
        (FREQUENCY_WEEKLY, "Haftalık"),
    ]

    channel = models.CharField(max_length=20)
    is_enabled = models.BooleanField(default=True)
    quiet_hours_start = models.TimeField(null=True, blank=True)
    quiet_hours_end = models.TimeField(null=True, blank=True)
    frequency = models.CharField(max_length=20, choices=FREQUENCY_CHOICES, default=FREQUENCY_INSTANT)
    categories = models.JSONField(default=list)

    def is_channel_enabled(self, channel: str) -> bool:
        """Verilen kanalda bildirim aktif mi kontrol eder."""
        return self.is_enabled and self.channel == channel

    def is_within_quiet_hours(self) -> bool:
        """Şu an sessiz saatler içinde mi kontrol eder."""
        if not self.quiet_hours_start or not self.quiet_hours_end:
            return False

        now = timezone.localtime().time()

        if self.quiet_hours_start < self.quiet_hours_end:
            return self.quiet_hours_start <= now <= self.quiet_hours_end

        return now >= self.quiet_hours_start or now <= self.quiet_hours_end

    def should_send_now(self) -> bool:
        """Bildirim şimdi gönderilebilir mi kontrol eder."""
        if not self.is_enabled:
            return False
        if self.is_within_quiet_hours():
            return False
        return True

    class Meta:
        abstract = True

# =========================================================
# Bildirim Log abstract modeli
# =========================================================
class AbstractNotificationLog(models.Model, metaclass=ModelABCMeta):
    """
    Bildirim aksiyonlarının loglandığı abstract model.
    """
    ACTION_CREATED = "created"
    ACTION_QUEUED = "queued"
    ACTION_SENT = "sent"
    ACTION_DELIVERED = "delivered"
    ACTION_OPENED = "opened"
    ACTION_CLICKED = "clicked"
    ACTION_BOUNCED = "bounced"
    ACTION_FAILED = "failed"
    ACTION_RETRIED = "retried"

    ACTION_CHOICES = [
        (ACTION_CREATED, "Oluşturuldu"),
        (ACTION_QUEUED, "Kuyruğa Eklendi"),
        (ACTION_SENT, "Gönderildi"),
        (ACTION_DELIVERED, "Teslim Edildi"),
        (ACTION_OPENED, "Açıldı"),
        (ACTION_CLICKED, "Tıklandı"),
        (ACTION_BOUNCED, "Geri Döndü"),
        (ACTION_FAILED, "Başarısız"),
        (ACTION_RETRIED, "Tekrar Denendi"),
    ]

    notification_id = models.PositiveIntegerField()
    action = models.CharField(max_length=50, choices=ACTION_CHOICES)
    old_status = models.CharField(max_length=20, blank=True)
    new_status = models.CharField(max_length=20, blank=True)
    details = models.JSONField(default=dict)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.CharField(max_length=500, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        abstract = True
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["notification_id"]),
            models.Index(fields=["action", "created_at"]),
        ]
