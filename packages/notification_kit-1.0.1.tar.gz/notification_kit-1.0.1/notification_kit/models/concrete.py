from django.db import models
from django.conf import settings

from notification_kit.models.abstract import (
    AbstractNotification,
    AbstractNotificationTemplate,
    AbstractNotificationPreference,
    AbstractNotificationLog,
)


class Notification(AbstractNotification):
    """
    Concrete Notification modeli.

    Not:
    - AbstractNotification içindeki abstract method olan get_recipient_identifier()
      mutlaka concrete sınıfta implement edilmelidir.
    - Testlerin ve servislerin sağlıklı çalışması için recipient bilgisini tutuyoruz.
    """

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="notifications",
        help_text="Bildirimin sahibi / hedef kullanıcısı",
    )

    recipient = models.CharField(
        max_length=255,
        help_text="Alıcı adresi (email/telefon/token gibi)",
    )

    extra_data = models.JSONField(
        default=dict,
        blank=True,
        help_text="Ek kanal-spesifik bilgiler",
    )

    def get_recipient_identifier(self) -> str:
        """
        AbstractNotification contract'ı gereği:
        bildirimin gönderileceği alıcıyı döndürür.
        """
        return self.recipient


class NotificationTemplate(AbstractNotificationTemplate):
    category = models.CharField(max_length=50, blank=True)
    extra_variables = models.JSONField(default=list)


class NotificationPreference(AbstractNotificationPreference):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    custom_setting = models.BooleanField(default=True)


class NotificationLog(AbstractNotificationLog):
    metadata = models.JSONField(default=dict)
