from __future__ import annotations

from django.db import models


class TimeStampedMixin(models.Model):
    """
    Zaman damgasi (timestamp) mixin'i.

    Bu mixin'i kullanan modeller otomatik olarak:
    - created_at  -> kaydin olusturulma zamani
    - updated_at  -> kaydin son guncellenme zamani
    alanlarini kazanir.

    Core paket genelinde tum modellerde ortak olarak kullanilir.
    """

    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="Kaydin olusturulma zamani",
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        help_text="Kaydin son guncellenme zamani",
    )

    class Meta:
        abstract = True


class StatusTransitionMixin(models.Model):
    """
    Durum (status) gecisleri icin yardimci mixin.

    Bu mixin:
    - status alani olan modeller icin
    - kontrollu ve merkezi durum degisimi saglar

    Dogrudan disaridan status degistirmek yerine,
    bu mixin uzerinden yapilmasi tavsiye edilir.
    """

    status: str

    class Meta:
        abstract = True

    def _set_status(self, new_status: str) -> None:
        """
        Modelin durumunu (status) gunceller.

        Bu method internal (private) olarak dusunulmelidir.
        """
        self.status = new_status
        self.save(update_fields=["status", "updated_at"])


class RetryMixin(models.Model):
    """
    Tekrar deneme (retry) mantigi icin mixin.

    Bildirim gonderimi basarisiz oldugunda:
    - retry_count artirilir
    - max_retries asilmamis mi kontrol edilir
    """

    retry_count: int
    max_retries: int

    class Meta:
        abstract = True

    def increment_retry(self) -> None:
        """
        Tekrar deneme sayisini 1 artirir.
        """
        self.retry_count += 1
        self.save(update_fields=["retry_count", "updated_at"])

    def can_retry(self) -> bool:
        """
        Bildirim tekrar denenebilir mi?

        retry_count < max_retries ise True doner.
        """
        return self.retry_count < self.max_retries
