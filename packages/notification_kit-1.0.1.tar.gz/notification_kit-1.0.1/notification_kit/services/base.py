from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Optional

from django.utils import timezone

from notification_kit.models.abstract import AbstractNotification


@dataclass
class BaseNotificationService:
    notification_model: Any
    template_model: Any
    backends: dict[str, Any]
    default_channel: str = "email"
    settings: dict[str, Any] = None

    def __post_init__(self) -> None:
        if self.settings is None:
            self.settings = {}

    def create_notification(
        self,
        recipient: Any,
        channel: Optional[str] = None,
        **kwargs: Any,
    ):
        """
        Yeni bir notification oluşturur.
        - Django model ise: objects.create(...)
        - Plain python ise: class(**kwargs)
        """
        channel = channel or self.default_channel

        # priority/metadata’yı tek yerde yönet (duplicate fix)
        priority = kwargs.pop("priority", self.settings.get("DEFAULT_PRIORITY", AbstractNotification.PRIORITY_NORMAL))
        metadata = kwargs.pop("metadata", {})

        # recipient bir User instance ise user alanına koy
        if "user" not in kwargs and hasattr(recipient, "_meta"):
            kwargs["user"] = recipient

        data = {
            "channel": channel,
            # ✅ lowercase constant
            "status": AbstractNotification.STATUS_PENDING,
            "priority": priority,
            "metadata": metadata,
            **kwargs,
        }

        if hasattr(self.notification_model, "objects"):
            return self.notification_model.objects.create(**data)

        return self.notification_model(**data)

    def send_notification(self, notification: Any) -> bool:
        backend = self.backends.get(getattr(notification, "channel", None))
        if backend is None:
            if hasattr(notification, "mark_as_failed"):
                notification.mark_as_failed("Backend bulunamadı")
            return False

        try:
            ok = backend.send(notification)
            if ok and hasattr(notification, "mark_as_sent"):
                notification.mark_as_sent()
            return bool(ok)
        except Exception as exc:
            if hasattr(notification, "mark_as_failed"):
                notification.mark_as_failed(str(exc))
            return False

    def send_bulk(self, notifications: list[Any]) -> list[bool]:
        return [self.send_notification(n) for n in notifications]

    def schedule_notification(self, notification: Any, scheduled_time: datetime) -> None:
        # ✅ naive datetime gelirse timezone-aware yap
        if timezone.is_naive(scheduled_time):
            scheduled_time = timezone.make_aware(scheduled_time, timezone.get_current_timezone())

        notification.scheduled_at = scheduled_time

        # ✅ Django model ise persist et
        if hasattr(notification, "save"):
            notification.save(update_fields=["scheduled_at"])

    def cancel_notification(self, notification: Any) -> bool:
        # ✅ statüyü domain constant’a çek
        notification.status = AbstractNotification.STATUS_CANCELLED

        # ✅ Django model ise persist et
        if hasattr(notification, "save"):
            notification.save(update_fields=["status"])
        return True
