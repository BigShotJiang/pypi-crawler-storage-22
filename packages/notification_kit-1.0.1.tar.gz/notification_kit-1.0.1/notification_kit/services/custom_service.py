from notification_kit.services.base import BaseNotificationService
from notification_kit.models.concrete import Notification, NotificationTemplate

class ProjectNotificationService(BaseNotificationService):
    def __init__(self, backends=None):
        super().__init__(
            notification_model=Notification,
            template_model=NotificationTemplate,
            backends=backends or {}
        )

    def create_project_notification(self, user, title, body, **kwargs):
        return self.create_notification(
            recipient=user,
            channel=kwargs.get("channel", "email"),
            title=title,
            body=body,
            **kwargs
        )
