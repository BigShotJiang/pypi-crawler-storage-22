"""
notification_kit.settings

Bu dosya, Notification Kit icin tum ayar yonetimini merkezi olarak saglar.

Amac:
- Varsayilan ayarlari tanimlamak
- Django settings.py icinden override edilen degerleri almak
- Service, backend ve task katmanlari icin tek tip erisim saglamak
- Hassas verileri environment variable uzerinden yonetmek
"""

import os
from typing import Any, Dict
from django.conf import settings as django_settings


# -------------------------------------------------
# Varsayilan Ayarlar (Core Paket Defaults)
# -------------------------------------------------

DEFAULTS: Dict[str, Any] = {
    # -------------------------------------------------
    # Genel Ayarlar
    # -------------------------------------------------
    "DEFAULT_CHANNEL": "email",
    "DEFAULT_PRIORITY": "normal",
    "MAX_RETRIES": 3,
    "RETRY_DELAY": 300,  # saniye
    "ASYNC": True,
    "FAIL_SILENTLY": False,

    # -------------------------------------------------
    # Email Ayarlari
    # -------------------------------------------------
    "EMAIL": {
        # Backend class path (env ile override edilebilir)
        "BACKEND": os.environ.get(
            "NOTIFICATION_EMAIL_BACKEND",
            "notification_kit.backends.email.SMTPBackend",
        ),

        # Gonderici email (PII - env uzerinden alinmali)
        "FROM_EMAIL": os.environ.get("NOTIFICATION_FROM_EMAIL"),

        # Reply-to adresleri
        "REPLY_TO": os.environ.get(
            "NOTIFICATION_REPLY_TO", ""
        ).split(",") if os.environ.get("NOTIFICATION_REPLY_TO") else [],

        # Performans & limitler
        "BATCH_SIZE": int(os.environ.get("NOTIFICATION_EMAIL_BATCH_SIZE", 100)),
        "RATE_LIMIT": int(os.environ.get("NOTIFICATION_EMAIL_RATE_LIMIT", 100)),  # dk
    },

    # -------------------------------------------------
    # SMS Ayarlari
    # -------------------------------------------------
    "SMS": {
        "BACKEND": os.environ.get("NOTIFICATION_SMS_BACKEND"),
        "SENDER_ID": os.environ.get("NOTIFICATION_SMS_SENDER_ID"),
        "MAX_LENGTH": int(os.environ.get("NOTIFICATION_SMS_MAX_LENGTH", 160)),
        "RATE_LIMIT": int(os.environ.get("NOTIFICATION_SMS_RATE_LIMIT", 60)),
    },

    # -------------------------------------------------
    # Push Ayarlari
    # -------------------------------------------------
    "PUSH": {
        "BACKEND": os.environ.get("NOTIFICATION_PUSH_BACKEND"),
        "BATCH_SIZE": int(os.environ.get("NOTIFICATION_PUSH_BATCH_SIZE", 500)),
    },

    # -------------------------------------------------
    # Zamanlama (Celery / Beat)
    # -------------------------------------------------
    "SCHEDULING": {
        "ENABLED": True,
        "CHECK_INTERVAL": 60,   # saniye
        "BATCH_SIZE": 100,
    },

    # -------------------------------------------------
    # Temizlik (Cleanup / Retention)
    # -------------------------------------------------
    "CLEANUP": {
        "ENABLED": True,
        "RETENTION_DAYS": 30,
        "BATCH_SIZE": 1000,
    },

    # -------------------------------------------------
    # Loglama & Audit
    # -------------------------------------------------
    "LOGGING": {
        "ENABLED": True,
        "LOG_LEVEL": "INFO",

        # ⚠️ Güvenlik:
        # Bildirim body / content loglanmasin (PII riski)
        "LOG_BODY": False,

        # Backend denemeleri loglansin mi
        "LOG_SEND_ATTEMPTS": True,
    },
}


# -------------------------------------------------
# Kullanici Ayarlarini Alma
# -------------------------------------------------

def get_user_settings() -> Dict[str, Any]:
    """
    Django settings.py icinde tanimlanan NOTIFICATION_KIT ayarlarini alir.

    Ornek:
        NOTIFICATION_KIT = {
            "DEFAULT_CHANNEL": "sms",
            "SMS": {
                "BACKEND": "project.notifications.backends.CustomSMSBackend"
            }
        }
    """
    return getattr(django_settings, "NOTIFICATION_KIT", {})


# -------------------------------------------------
# Ayarlari Merge Etme (Deep Merge)
# -------------------------------------------------

def deep_merge(defaults: Dict[str, Any], overrides: Dict[str, Any]) -> Dict[str, Any]:
    """
    Ic ice dictionary'leri guvenli sekilde merge eder.

    - defaults bozulmaz
    - overrides sadece belirtilen alanlari ezer
    """
    result = defaults.copy()

    for key, value in overrides.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value

    return result


def get_settings() -> Dict[str, Any]:
    """
    Varsayilan ayarlar ile kullanici override ayarlarini birlestirir.

    Tek giris noktasi (single source of truth)
    """
    user_settings = get_user_settings()
    return deep_merge(DEFAULTS, user_settings)


# -------------------------------------------------
# Kanal Bazli Yardimci Fonksiyonlar
# -------------------------------------------------

def get_channel_settings(channel: str) -> Dict[str, Any]:
    """
    Belirli bir kanal icin ayarlari dondurur.

    Ornek:
        get_channel_settings("email")
        get_channel_settings("sms")
    """
    settings = get_settings()
    return settings.get(channel.upper(), {})


def get_backend_path(channel: str) -> str | None:
    """
    Kanal icin tanimli backend class path'ini dondurur.
    """
    channel_settings = get_channel_settings(channel)
    return channel_settings.get("BACKEND")


def get_max_retries() -> int:
    """
    Maksimum tekrar deneme sayisini dondurur.
    """
    return int(get_settings().get("MAX_RETRIES", 3))


def get_retry_delay() -> int:
    """
    Tekrar deneme gecikmesini (saniye) dondurur.
    """
    return int(get_settings().get("RETRY_DELAY", 300))


def is_async_enabled() -> bool:
    """
    Bildirimler async mi gonderilecek?
    """
    return bool(get_settings().get("ASYNC", True))


def is_logging_enabled() -> bool:
    """
    Loglama aktif mi?
    """
    return bool(get_settings().get("LOGGING", {}).get("ENABLED", True))


def should_log_body() -> bool:
    """
    Bildirim body/content loglanabilir mi?
    (Varsayilan: HAYIR – PII riski)
    """
    return bool(get_settings().get("LOGGING", {}).get("LOG_BODY", False))

