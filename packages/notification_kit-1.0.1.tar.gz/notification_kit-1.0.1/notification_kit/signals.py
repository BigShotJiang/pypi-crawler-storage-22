from django.dispatch import Signal
from django.db.models.signals import post_save
from django.dispatch import receiver

from notification_kit.models.abstract import AbstractNotification, AbstractNotificationLog
from notification_kit.models import NotificationLog
from notification_kit.utils.validators import mask_pii

"""
Bu dosya, bildirim yaşam döngüsündeki tüm önemli olaylar için
Django signal tanımlarını içerir.

Buradaki sinyaller:
- Core servisleri kirletmez
- Side-effect işlemleri (log, audit, webhook, metric vb.)
  için extension noktası sağlar
"""


# Bildirim oluşturulduğunda tetiklenir
notification_created = Signal()
"""
Parametreler:
- sender: Bildirimi oluşturan servis veya sınıf
- notification: Oluşturulan Notification instance
- created_by: Bildirimi oluşturan kullanıcı veya sistem
"""


# Bildirim kuyruğa eklendiğinde tetiklenir
notification_queued = Signal()
"""
Parametreler:
- sender: İşlemi yapan servis
- notification: Kuyruğa alınan Notification
"""


# Bildirim gönderim işleminden hemen önce tetiklenir
notification_sending = Signal()
"""
Parametreler:
- sender: İşlemi yapan servis
- notification: Gönderilecek Notification
- backend: Kullanılacak backend instance
"""


# Bildirim gönderimi backend tarafından tamamlandığında tetiklenir
notification_sent = Signal()
"""
Parametreler:
- sender: İşlemi yapan servis
- notification: Gönderilen Notification
- response: Backend dönüş objesi
"""


# Bildirim karşı tarafa teslim edildiğinde tetiklenir
notification_delivered = Signal()
"""
Parametreler:
- sender: İşlemi yapan servis
- notification: Teslim edilen Notification
- delivery_info: Teslimat bilgileri (provider response vb.)
"""


# Bildirim gönderimi başarısız olduğunda tetiklenir
notification_failed = Signal()
"""
Parametreler:
- sender: İşlemi yapan servis
- notification: Başarısız olan Notification
- error: Hata objesi veya mesajı
- will_retry: Tekrar denenecek mi? (bool)
"""


# Bildirim okunduğunda tetiklenir
notification_read = Signal()
"""
Parametreler:
- sender: İşlemi yapan servis veya view
- notification: Okunan Notification
- read_by: Bildirimi okuyan kullanıcı
"""


# Bildirim iptal edildiğinde tetiklenir
notification_cancelled = Signal()
"""
Parametreler:
- sender: İşlemi yapan servis
- notification: İptal edilen Notification
- cancelled_by: İptali yapan kullanıcı veya sistem
"""

@receiver(post_save)
def audit_notification(sender, instance, created, **kwargs):
    """
    Bildirim lifecycle olaylarını audit log olarak kaydeder.
    """
    if not isinstance(instance, AbstractNotification):
        return

    action = "CREATED" if created else "UPDATED"

    NotificationLog.objects.create(
        notification_id=instance.pk,
        action=action,
        old_status="",
        new_status=instance.status,
        details={
            "recipient": mask_pii(str(instance.get_recipient_identifier())),
            "channel": instance.channel,
        },
    )