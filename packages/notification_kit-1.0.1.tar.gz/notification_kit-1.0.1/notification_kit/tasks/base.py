from typing import Type, List
from datetime import timedelta

from celery import shared_task
from django.utils import timezone

from notification_kit.settings import get_settings


def create_send_task(service_class: Type):
    """
    Tekil bildirim gönderimi için Celery task oluşturur.
    """

    @shared_task(bind=True, autoretry_for=(), retry_backoff=False)
    def send_notification_task(self, notification_id: int, retry_on_failure: bool = True):
        service = service_class()

        try:
            notification = service.notification_model.objects.get(id=notification_id)
        except service.notification_model.DoesNotExist:
            return False

        try:
            return service.send_notification(notification)

        except Exception as exc:
            if retry_on_failure:
                raise self.retry(exc=exc)
            return False

    return send_notification_task


def create_bulk_send_task(service_class: Type):
    """
    Toplu bildirim gönderimi için Celery task oluşturur.
    """

    @shared_task(bind=True)
    def send_bulk_notifications_task(
        self,
        notification_ids: List[int],
        batch_size: int = 100,
    ):
        service = service_class()

        results = {
            "success": 0,
            "failed": 0,
        }

        queryset = service.notification_model.objects.filter(
            id__in=notification_ids
        )

        for notification in queryset.iterator(chunk_size=batch_size):
            if service.send_notification(notification):
                results["success"] += 1
            else:
                results["failed"] += 1

        return results

    return send_bulk_notifications_task


def create_scheduled_task(service_class: Type):
    """
    Zamanlanmış bildirimleri işlemek için periodic task oluşturur.
    """

    @shared_task
    def process_scheduled_notifications_task():
        service = service_class()
        settings = get_settings()

        if not settings.get("SCHEDULING", {}).get("ENABLED", True):
            return 0

        now = timezone.now()

        scheduled_notifications = service.notification_model.objects.filter(
            status="QUEUED",
            scheduled_at__lte=now,
        )

        processed = 0

        for notification in scheduled_notifications:
            if service.send_notification(notification):
                processed += 1

        return processed

    return process_scheduled_notifications_task


def create_cleanup_task(service_class: Type):
    """
    Eski bildirim kayıtlarını temizlemek için Celery task oluşturur.
    """

    @shared_task
    def cleanup_notifications_task(days: int = 30):
        service = service_class()
        settings = get_settings()

        if not settings.get("CLEANUP", {}).get("ENABLED", True):
            return 0

        cutoff = timezone.now() - timedelta(days=days)

        queryset = service.notification_model.objects.filter(
            created_at__lt=cutoff
        )

        deleted_count = queryset.count()
        queryset.delete()

        return deleted_count

    return cleanup_notifications_task


def create_retry_failed_task(service_class: Type):
    """
    Başarısız bildirimleri yeniden denemek için Celery task oluşturur.
    """

    @shared_task
    def retry_failed_notifications_task(max_age_hours: int = 24):
        service = service_class()
        return service.retry_failed_notifications(
            max_age_hours=max_age_hours
        )

    return retry_failed_notifications_task
