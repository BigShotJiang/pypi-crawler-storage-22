import re
from typing import Any, Iterable, Tuple

from django.template import Context, Template
from django.template.exceptions import TemplateSyntaxError


_VAR_RE = re.compile(r"{{\s*([a-zA-Z_][\w\.]*)\s*}}")

def render_template_string(tpl: str, context: dict[str, Any]) -> str:
    """
    Verilen template string'ini context ile render eder.
    """
    ctx = Context(context)
    return Template(tpl).render(ctx)


def render_with_fallback(templates: Iterable[str], context: dict[str, Any]) -> str:
    """
    Template listesinde sırayla dener.
    - Render sonucu boş string ise fallback'e devam eder.
    - TemplateSyntaxError varsa fallback'e devam eder.
    Hiçbiri çalışmazsa "" döner.
    """
    ctx = Context(context)
    for tpl in templates:
        try:
            rendered = Template(tpl).render(ctx)
        except TemplateSyntaxError:
            continue

        # Django "missing var" durumunda exception atmayıp ""/boş üretebilir.
        # Bu yüzden boş ise fallback dene.
        if rendered and rendered.strip():
            return rendered

    return ""


def extract_template_variables(tpl: str) -> list[str]:
    """
    Basit ve test-dostu değişken çıkarımı:
    - "Merhaba {{ name }}! Bugün {{ day }}." -> ["name", "day"]
    """
    return sorted(set(_VAR_RE.findall(tpl)))


def validate_template_syntax(tpl: str) -> Tuple[bool, str]:
    """
    1) Basit denge kontrolü ({{ }} sayısı)
    2) Django Template compile kontrolü
    """
    if tpl.count("{{") != tpl.count("}}"):
        return False, "Unbalanced template braces"

    try:
        Template(tpl)  # compile
        return True, ""
    except TemplateSyntaxError as e:
        return False, str(e)
