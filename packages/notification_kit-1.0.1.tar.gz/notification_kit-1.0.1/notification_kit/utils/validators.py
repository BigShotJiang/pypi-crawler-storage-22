import re
from html import escape

def validate_email(email: str) -> bool:
    """
    Email adresi geçerli mi kontrol eder.
    """
    pattern = r"^[\w\.-]+@[\w\.-]+\.\w+$"
    return bool(re.match(pattern, email))

def validate_phone_number(number: str, country_code: str = None) -> bool:
    """
    Telefon numarasını doğrular.
    Opsiyonel olarak ülke kodu ile birlikte kontrol edilebilir.
    """
    pattern = r"^\+?\d{7,15}$"
    return bool(re.match(pattern, number))

def validate_device_token(token: str, platform: str) -> bool:
    """
    Push token geçerli mi kontrol eder.
    Platform parametresi IOS, ANDROID veya WEB olabilir.
    """
    return isinstance(token, str) and len(token) > 0

def sanitize_html(html_content: str) -> str:
    """
    HTML içeriğini güvenli şekilde temizler.
    """
    return escape(html_content)

def truncate_text(text: str, max_length: int, suffix: str = "...") -> str:
    """
    Metni belirtilen uzunluğa kırpar ve suffix ekler.
    """
    if len(text) <= max_length:
        return text
    return text[:max_length].rstrip() + suffix

def mask_pii(value: str, keep_last: int = 4) -> str:
    """
    Email, telefon gibi kişisel verileri loglar için maskeler.

    Örnek:
    - user@example.com -> ****@example.com
    - 905551112233 -> ********2233
    """
    if not value:
        return value

    # Email ise
    if "@" in value:
        local, domain = value.split("@", 1)
        masked_local = "*" * max(0, len(local) - keep_last) + local[-keep_last:]
        return f"{masked_local}@{domain}"

    # Telefon numarası ise
    if value.isdigit():
        return "*" * max(0, len(value) - keep_last) + value[-keep_last:]

    return value
