DEFAULT_SERVER = "https://api.notif.sh"
DEFAULT_TIMEOUT = 30.0  # seconds
ENV_VAR_NAME = "NOTIF_API_KEY"
API_KEY_PREFIX = "nsh_"
