"""
Parsers de lojas específicas para extração de produtos.

Este módulo fornece parsers especializados para diferentes lojas de e-commerce,
permitindo extrair produtos de JSON ou HTML de APIs específicas.

Estrutura:
- StoresParserInterface: Interface abstrata para parsers
- StoresParserEnum: Enum com parsers disponíveis
- ParserFactory: Factory para obter parser por tipo
- Parsers específicos: NikeAPIGatewayJSONParser, MazeAPIJSONParser, BelezaNaWebHTMLParser

Uso básico (JSON):
    >>> from notify_utils.parsers import ParserFactory, StoresParserEnum
    >>> parser = ParserFactory.get_parser(StoresParserEnum.MAZE_API_JSON)
    >>> products = parser.from_json(json_data)

Uso básico (HTML):
    >>> parser_html = ParserFactory.get_parser(StoresParserEnum.BELEZA_NA_WEB_HTML)
    >>> products = parser_html.from_html(html_data)

Parsers disponíveis:
- NIKE_APIGATEWAY_JSON: Parser para API Gateway da Nike (JSON)
- MAZE_API_JSON: Parser para API da Maze Shop (JSON)
- BELEZA_NA_WEB_HTML: Parser para Beleza na Web (HTML com deduplicação)
"""

from .stores_parser_interface import StoresParserInterface
from .stores_parser import (
    ParserError,
    NikeAPIGatewayJSONParser,
    MazeAPIJSONParser,
    BelezaNaWebHTMLParser
)
from .stores_parser_enum import StoresParserEnum
from .stores_parser_factory import ParserFactory

__all__ = [
    # Interface
    "StoresParserInterface",

    # Enum e Factory
    "StoresParserEnum",
    "ParserFactory",

    # Exceções
    "ParserError",

    # Parsers específicos
    "NikeAPIGatewayJSONParser",
    "MazeAPIJSONParser",
    "BelezaNaWebHTMLParser",
]