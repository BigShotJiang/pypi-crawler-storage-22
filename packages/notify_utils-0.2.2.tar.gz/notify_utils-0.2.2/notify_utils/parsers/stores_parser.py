"""
Parsers específicos para lojas de e-commerce.

Implementações concretas da interface StoresParserInterface para
diferentes lojas (Nike, Maze Shop, Beleza na Web, etc).
"""

import logging
import json
import html
from typing import Optional
from notify_utils.models import Product
from notify_utils.parsers.stores_parser_interface import StoresParserInterface
from notify_utils.parser import parse_price

logger = logging.getLogger(__name__)


class ParserError(Exception):
    """
    Exceção customizada para erros de parsing.

    Levantada quando:
    - Formato de dados inválido
    - Parser não suporta o tipo de dados (JSON/HTML)
    - Dados obrigatórios estão ausentes
    """
    pass

class NikeAPIGatewayJSONParser(StoresParserInterface):
    """
    Parser para API Gateway da Nike.

    Extrai produtos de respostas JSON da API Gateway da Nike.

    Exemplo:
        >>> parser = NikeAPIGatewayJSONParser()
        >>> products = parser.from_json(nike_api_response)
    """

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da Nike de dados JSON.

        Args:
            json_data: Dicionário contendo resposta JSON da API Gateway da Nike

        Returns:
            Lista de objetos Product extraídos (implementação pendente)

        Note:
            Implementação ainda não finalizada - retorna lista vazia
        """
        # TODO: Implementar lógica de parsing para Nike API Gateway
        logger.warning("NikeAPIGatewayJSONParser.from_json() não implementado ainda")
        return []

    def from_html(self, html_data: str) -> list[Product]:
        """
        HTML não suportado para Nike API Gateway.

        Args:
            html_data: String contendo HTML

        Raises:
            ParserError: Sempre - Nike API usa JSON, não HTML
        """
        raise ParserError("HTML parsing is not supported for Nike API Gateway.")


class MazeAPIJSONParser(StoresParserInterface):
    """
    Parser para API da Maze Shop.

    Extrai produtos de respostas JSON da API da Maze Shop, incluindo:
    - ID do produto
    - Nome e descrição
    - Preços (atual e promocional)
    - Estoque e disponibilidade
    - URLs (produto e imagem)
    - SKU

    Validações automáticas:
    - Ignora produtos com preço inválido (≤ 0)
    - Converte preços com fallback seguro
    - Trata ausência de campos opcionais

    Exemplo:
        >>> parser = MazeAPIJSONParser()
        >>> products = parser.from_json(maze_api_response)
        >>> for product in products:
        ...     print(f"{product.name}: R$ {product.current_price}")
    """

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da Maze Shop de dados JSON.

        Args:
            json_data: Dicionário contendo resposta JSON da API da Maze Shop
                      Estrutura esperada:
                      {
                          "products": [
                              {
                                  "idProduct": "123",
                                  "name": "Nome Produto",
                                  "price": 129.90,
                                  "pricePromotion": 99.90,
                                  "stock": 10,
                                  "urlFriendly": "produto-slug",
                                  "imageHome": "//cdn.maze.com.br/img.jpg",
                                  "code": "SKU123"
                              }
                          ]
                      }

        Returns:
            Lista de objetos Product extraídos e formatados.
            Lista vazia se não houver produtos ou se campo 'products' não existir.

        Note:
            - Produtos com preço inválido (≤ 0 ou None) são ignorados
            - Se pricePromotion existe, é usado como current_price
            - Caso contrário, price é usado como current_price
            - URLs são automaticamente formatadas com prefixo da loja
        """
        products: list[Product] = []
        logger.debug("Parsing Maze Shop products from JSON")

        products_json = json_data.get("products", [])
        if not products_json:
            logger.warning("No products found in JSON data.")
            return []

        for product_json in products_json:
            # Extrai preços com fallback seguro
            price_promotion = product_json.get("pricePromotion")
            price = product_json.get("price")
            available = product_json.get("stock", 0) > 0

            # Converte para float, tratando None e valores inválidos
            try:
                current_price = float(price_promotion) if price_promotion else float(price)
                old_price = float(price) if price else 0.0
            except (ValueError, TypeError):
                logger.warning(f"Preço inválido para produto {product_json.get('idProduct')}, pulando.")
                continue

            # Valida se o preço atual é válido (> 0)
            if current_price <= 0:
                logger.debug(f"Produto {product_json.get('idProduct')} tem preço atual inválido (R$ {current_price}), pulando.")
                continue

            product = Product(
                product_id=str(product_json.get("idProduct", None)),
                name=product_json.get("name", None),
                current_price_float=current_price,
                old_price_float=old_price,
                url=f"https://www.maze.com.br/{product_json.get('urlFriendly', '')}",
                image_url=f'https:{product_json.get("imageHome", "")}',
                sku=product_json.get("code", None),
                available=available,
                marketplace_name="Maze Shop",
                seller="Maze Shop"
            )

            products.append(product)
        return products

    def from_html(self, html_data: str) -> list[Product]:
        raise ParserError("HTML parsing is not supported for Maze API.")


class BelezaNaWebHTMLParser(StoresParserInterface):
    """
    Parser para HTML da Beleza na Web.

    Extrai produtos de páginas HTML da Beleza na Web (belezanaweb.com.br),
    com deduplicação automática de produtos repetidos em carrosséis.

    Características:
    - Parse híbrido: JSON embedded (data-event) + HTML estruturado
    - Deduplicação automática por SKU
    - Extrai: ID, nome, marca, preços (atual + antigo), URLs, desconto
    - Validações: ignora produtos sem SKU ou preço inválido

    Estrutura HTML esperada:
    - `<article class="showcase-item">` com atributo `data-event` (JSON)
    - Preço atual no JSON `data-event.price`
    - Preço antigo em `.item-price-max` (quando disponível)
    - URLs em `.showcase-card-link-overlay` e `img.showcase-image[data-src]`

    Exemplo:
        >>> parser = BelezaNaWebHTMLParser()
        >>> with open('beleza.html', 'r', encoding='utf-8') as f:
        ...     html = f.read()
        >>> products = parser.from_html(html)
        >>> print(f"Extraídos {len(products)} produtos únicos")
        Extraídos 36 produtos únicos
    """

    def __init__(self):
        """Inicializa parser e verifica dependência BeautifulSoup."""
        try:
            from bs4 import BeautifulSoup
            self.BeautifulSoup = BeautifulSoup
        except ImportError:
            raise ImportError(
                "beautifulsoup4 é necessário para BelezaNaWebHTMLParser. "
                "Instale com: pip install beautifulsoup4 lxml"
            )

    def from_json(self, json_data: dict) -> list[Product]:
        """
        JSON não suportado para Beleza na Web.

        Args:
            json_data: Dicionário JSON

        Raises:
            ParserError: Sempre - Beleza na Web usa HTML, não JSON
        """
        raise ParserError("Beleza na Web usa HTML parsing, não JSON. Use from_html().")

    def from_html(self, html_data: str) -> list[Product]:
        """
        Extrai produtos da Beleza na Web de HTML.

        Args:
            html_data: String contendo HTML da página de produtos
                      Estrutura esperada:
                      ```html
                      <article class="showcase-item" data-event="{...}">
                          <a class="showcase-card-link-overlay" href="/produto">...</a>
                          <img class="showcase-image" data-src="https://...">
                          <div class="item-price-max">R$ 599,00</div>
                          <span class="price-value">R$ 138,00</span>
                      </article>
                      ```

        Returns:
            Lista de objetos Product únicos (deduplicados por SKU).
            Lista vazia se não houver produtos válidos.

        Note:
            - Produtos duplicados (carrossel) são automaticamente removidos
            - Produtos sem SKU ou preço são ignorados com log de warning
            - Preço antigo é opcional (pode ser 0.0 se não disponível)
            - URLs relativas são convertidas para absolutas

        Example:
            >>> parser = BelezaNaWebHTMLParser()
            >>> products = parser.from_html(html_content)
            >>> for p in products:
            ...     print(f"{p.product_id}: {p.name} - R$ {p.current_price}")
        """
        products: list[Product] = []
        seen_skus: set[str] = set()
        logger.debug("Parsing Beleza na Web products from HTML")

        try:
            # Parse HTML com lxml (mais rápido) ou html.parser (fallback)
            soup = self.BeautifulSoup(html_data, 'lxml')
        except Exception:
            # Fallback para html.parser se lxml não estiver instalado
            soup = self.BeautifulSoup(html_data, 'html.parser')
            logger.debug("lxml not available, using html.parser")

        # Encontrar todos os artigos de produtos
        articles = soup.find_all('article', class_='showcase-item')
        logger.debug(f"Found {len(articles)} article elements in HTML")

        duplicates_count = 0

        for article in articles:
            try:
                # 1. Parse JSON do data-event
                data_event_str = article.get('data-event', '{}')
                if not data_event_str or data_event_str == '{}':
                    logger.debug("Article without data-event, skipping")
                    continue

                # Unescape HTML entities (&quot; → ")
                data_event_str = html.unescape(data_event_str)
                data_event = json.loads(data_event_str)

                # 2. Extrair SKU e verificar duplicata
                sku = data_event.get('sku')
                if not sku:
                    logger.warning("Product without SKU in data-event, skipping")
                    continue

                if sku in seen_skus:
                    duplicates_count += 1
                    continue  # Skip duplicata

                seen_skus.add(sku)

                # 3. Extrair dados do JSON embedded
                current_price = float(data_event.get('price', 0))
                product_name = data_event.get('productName', '')
                brand = data_event.get('brand', '')

                # Validar preço
                if current_price <= 0:
                    logger.warning(f"Product {sku} has invalid price ({current_price}), skipping")
                    continue

                # 4. Extrair URL do produto
                url_elem = article.find('a', class_='showcase-card-link-overlay')
                relative_url = url_elem.get('href', '') if url_elem else ''
                product_url = self._make_absolute_url(relative_url)

                # 5. Extrair URL da imagem
                img_elem = article.find('img', class_='showcase-image')
                image_url = img_elem.get('data-src', '') if img_elem else ''

                # 6. Extrair preço antigo (opcional)
                old_price = self._extract_old_price(article)

                # 7. Criar objeto Product
                product = Product(
                    product_id=sku,
                    name=product_name,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=sku,
                    available=True,
                    marketplace_name="Beleza na Web",
                    seller="Beleza na Web"
                )

                products.append(product)

            except json.JSONDecodeError as e:
                logger.warning(f"Failed to parse data-event JSON: {e}")
                continue
            except (ValueError, TypeError) as e:
                logger.warning(f"Error processing product: {e}")
                continue
            except Exception as e:
                logger.error(f"Unexpected error processing article: {e}")
                continue

        logger.info(
            f"Extracted {len(products)} unique products "
            f"({duplicates_count} duplicates ignored)"
        )

        return products

    def _make_absolute_url(self, relative_url: str) -> str:
        """
        Converte URL relativa para absoluta.

        Args:
            relative_url: URL relativa ou absoluta

        Returns:
            URL absoluta com domínio completo
        """
        if not relative_url:
            return ''

        if relative_url.startswith('http'):
            return relative_url

        if relative_url.startswith('/'):
            return f"https://www.belezanaweb.com.br{relative_url}"

        return f"https://www.belezanaweb.com.br/{relative_url}"

    def _extract_old_price(self, article) -> float:
        """
        Extrai preço antigo (preço "de") do HTML.

        Args:
            article: Elemento BeautifulSoup do article

        Returns:
            Preço antigo como float, ou 0.0 se não disponível
        """
        try:
            old_price_elem = article.find('div', class_='item-price-max')
            if old_price_elem:
                old_price_text = old_price_elem.get_text(strip=True)
                # Parse usando função do projeto (normaliza "R$ 599,00" → 599.0)
                return parse_price(old_price_text)
        except Exception as e:
            logger.debug(f"Could not extract old price: {e}")

        return 0.0
