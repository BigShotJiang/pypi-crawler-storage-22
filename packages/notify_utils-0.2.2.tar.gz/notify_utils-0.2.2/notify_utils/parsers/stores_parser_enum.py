"""
Enum de parsers disponíveis para lojas.
"""

from enum import Enum
from notify_utils.parsers.stores_parser import (
    MazeAPIJSONParser,
    NikeAPIGatewayJSONParser,
    BelezaNaWebHTMLParser
)


class StoresParserEnum(Enum):
    """
    Enum com todos os parsers disponíveis.

    Cada valor é uma instância do parser correspondente,
    pronta para uso via ParserFactory.

    Parsers disponíveis:
    - NIKE_APIGATEWAY_JSON: Parser para API Gateway da Nike (JSON)
    - MAZE_API_JSON: Parser para API da Maze Shop (JSON)
    - BELEZA_NA_WEB_HTML: Parser para Beleza na Web (HTML)

    Exemplo:
        >>> from notify_utils.parsers import ParserFactory, StoresParserEnum
        >>> parser = ParserFactory.get_parser(StoresParserEnum.MAZE_API_JSON)
        >>> products = parser.from_json(json_data)
        >>>
        >>> # Para Beleza na Web (HTML)
        >>> parser_html = ParserFactory.get_parser(StoresParserEnum.BELEZA_NA_WEB_HTML)
        >>> products_html = parser_html.from_html(html_data)
    """

    NIKE_APIGATEWAY_JSON = NikeAPIGatewayJSONParser()
    MAZE_API_JSON = MazeAPIJSONParser()
    BELEZA_NA_WEB_HTML = BelezaNaWebHTMLParser()