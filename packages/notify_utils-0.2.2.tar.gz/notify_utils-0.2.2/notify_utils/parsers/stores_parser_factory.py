"""
Factory para obter parsers de lojas.
"""

from notify_utils.parsers.stores_parser import ParserError
from notify_utils.parsers.stores_parser_enum import StoresParserEnum
from notify_utils.parsers.stores_parser_interface import StoresParserInterface


class ParserFactory:
    """
    Factory para obter instâncias de parsers de lojas.

    Uso:
        >>> from notify_utils.parsers import ParserFactory, StoresParserEnum
        >>> parser = ParserFactory.get_parser(StoresParserEnum.MAZE_API_JSON)
        >>> products = parser.from_json(api_response)

    Vantagens:
    - Desacoplamento: código não precisa conhecer classes concretas
    - Extensibilidade: novos parsers via StoresParserEnum
    - Type hints: retorna StoresParserInterface
    """

    @staticmethod
    def get_parser(parser_type: StoresParserEnum) -> StoresParserInterface:
        """
        Retorna instância do parser solicitado.

        Args:
            parser_type: Tipo do parser (valor de StoresParserEnum)

        Returns:
            Instância do parser implementando StoresParserInterface

        Raises:
            ParserError: Se parser não estiver implementado

        Example:
            >>> parser = ParserFactory.get_parser(StoresParserEnum.MAZE_API_JSON)
            >>> isinstance(parser, StoresParserInterface)
            True
        """
        for parser in StoresParserEnum:
            if parser == parser_type:
                return parser.value

        # Se chegou aqui, parser não existe
        raise ParserError(f"Parser for {parser_type} is not implemented.")
