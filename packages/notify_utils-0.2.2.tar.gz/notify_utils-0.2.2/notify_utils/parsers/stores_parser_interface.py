"""
Interface abstrata para parsers de lojas.
"""

from abc import ABC, abstractmethod


class StoresParserInterface(ABC):
    """
    Interface abstrata para parsers de lojas específicas.

    Define métodos obrigatórios que cada parser deve implementar
    para extrair produtos de JSON ou HTML.

    Implementações devem herdar desta classe e fornecer lógica
    específica para cada loja (Nike, Maze, etc).
    """

    @abstractmethod
    def from_json(self, json_data: dict):
        """
        Extrai produtos de dados JSON.

        Args:
            json_data: Dicionário contendo resposta JSON da API

        Returns:
            Lista de objetos Product extraídos

        Raises:
            ParserError: Se parser não suportar JSON
        """
        raise NotImplementedError("JSON parsing is not implemented yet.")

    @abstractmethod
    def from_html(self, html_data: str):
        """
        Extrai produtos de HTML.

        Args:
            html_data: String contendo HTML da página

        Returns:
            Lista de objetos Product extraídos

        Raises:
            ParserError: Se parser não suportar HTML
        """
        raise NotImplementedError("HTML parsing is not implemented yet.")
