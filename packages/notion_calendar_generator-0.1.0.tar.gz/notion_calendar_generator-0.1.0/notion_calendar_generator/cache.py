"""SQLite caching for Notion page IDs."""

import sqlite3
import logging
from enum import Enum
from pathlib import Path
from typing import Optional, Union, List, Dict, TYPE_CHECKING

if TYPE_CHECKING:
    from notion_calendar_generator.notion import API


class StaleMode(Enum):
    """Enum for stale cache handling modes."""
    ERROR = "error"
    REFRESH_CACHE = "refresh_cache"
    REFRESH_NOTION = "refresh_notion"


class StaleCacheError(Exception):
    """Raised when a cached page no longer exists in Notion."""

    def __init__(self, page_id: str, title: str, page_type: str):
        self.page_id = page_id
        self.title = title
        self.page_type = page_type
        super().__init__(
            f"Cached {page_type} page '{title}' (ID: {page_id}) no longer exists in Notion. "
            f"Use --refresh-cache to clear stale entries or --refresh-notion to recreate."
        )


class PageCache:
    """SQLite cache for Notion page IDs."""

    CACHE_DIR = ".nocage"
    CACHE_FILE = "cache.db"

    def __init__(self, base_path: str = ".", logger: logging.Logger = None):
        """
        Initialize the cache.

        Args:
            base_path: Directory where .nocage/ will be created
            logger: Logger instance for cache operations
        """
        self.base_path = Path(base_path)
        self.logger = logger or logging.getLogger(__name__)
        self._ensure_cache_dir()
        self._conn = self._open_connection()
        self._init_db()

    def _get_db_path(self) -> Path:
        """Get the full path to the cache database."""
        return self.base_path / self.CACHE_DIR / self.CACHE_FILE

    def _ensure_cache_dir(self) -> None:
        """Create .nocage directory if it doesn't exist."""
        cache_dir = self.base_path / self.CACHE_DIR
        cache_dir.mkdir(parents=True, exist_ok=True)

    def _open_connection(self) -> sqlite3.Connection:
        """Open a persistent database connection."""
        conn = sqlite3.connect(self._get_db_path())
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        """Initialize the database schema if not exists."""
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS pages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                page_id TEXT NOT NULL UNIQUE,
                title TEXT NOT NULL,
                page_type TEXT NOT NULL CHECK(page_type IN ('year', 'quarter', 'month', 'week', 'day', 'step')),
                start_date TEXT NOT NULL,
                end_date TEXT,
                year INTEGER NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(title, page_type, year)
            )
        """)
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_lookup ON pages(title, page_type, year)")
        self._conn.execute("CREATE INDEX IF NOT EXISTS idx_year ON pages(year)")
        self._conn.commit()

    def close(self) -> None:
        """Close the database connection."""
        self._conn.close()

    def lookup(self, title: str, page_type: str, year: int) -> Optional[str]:
        """
        Look up a page ID by title, type, and year.

        Args:
            title: Page title (e.g., "2025", "25-Q1", "25-January")
            page_type: One of "year", "quarter", "month", "week", "day"
            year: The calendar year

        Returns:
            Page ID if found, None otherwise
        """
        cursor = self._conn.execute(
            "SELECT page_id FROM pages WHERE title = ? AND page_type = ? AND year = ?",
            (title, page_type, year)
        )
        row = cursor.fetchone()
        return row["page_id"] if row else None

    def store(self, page_id: str, title: str, page_type: str,
              start_date: str, year: int, end_date: str = None) -> None:
        """
        Store a page entry in the cache.

        Args:
            page_id: Notion page ID
            title: Page title
            page_type: Type of page
            start_date: Start date (YYYY-MM-DD format)
            year: Calendar year
            end_date: Optional end date for range-based pages
        """
        self._conn.execute(
            """
            INSERT OR REPLACE INTO pages (page_id, title, page_type, start_date, end_date, year)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (page_id, title, page_type, start_date, end_date, year)
        )
        self._conn.commit()
        self.logger.debug(f"Cached {page_type} '{title}' with ID {page_id}")

    def delete(self, page_id: str) -> None:
        """
        Delete a cache entry by page ID.

        Args:
            page_id: Notion page ID to remove from cache
        """
        self._conn.execute("DELETE FROM pages WHERE page_id = ?", (page_id,))
        self._conn.commit()
        self.logger.debug(f"Deleted cache entry for page ID {page_id}")

    def get_all_for_year(self, year: int) -> List[Dict]:
        """
        Get all cached pages for a specific year.

        Args:
            year: Calendar year

        Returns:
            List of cache entries as dictionaries
        """
        cursor = self._conn.execute(
            "SELECT page_id, title, page_type, start_date, end_date, year FROM pages WHERE year = ?",
            (year,)
        )
        return [dict(row) for row in cursor.fetchall()]

    def clear_year(self, year: int) -> int:
        """
        Clear all cache entries for a specific year.

        Args:
            year: Calendar year to clear

        Returns:
            Number of entries deleted
        """
        cursor = self._conn.execute("DELETE FROM pages WHERE year = ?", (year,))
        self._conn.commit()
        count = cursor.rowcount
        self.logger.info(f"Cleared {count} cache entries for year {year}")
        return count


class CachedAPI:
    """API wrapper that adds caching to Notion operations."""

    def __init__(self, api: 'API', cache: PageCache, year: int,
                 stale_mode: StaleMode = StaleMode.ERROR,
                 logger: logging.Logger = None):
        """
        Initialize the cached API wrapper.

        Args:
            api: Underlying API instance
            cache: PageCache instance
            year: Calendar year being processed
            stale_mode: How to handle stale cache entries
            logger: Logger instance
        """
        self._api = api
        self._cache = cache
        self._year = year
        self._stale_mode = stale_mode
        self._logger = logger or logging.getLogger(__name__)

    @property
    def year_id(self):
        return self._api.year_id

    @property
    def quarter_id(self):
        return self._api.quarter_id

    @property
    def month_id(self):
        return self._api.month_id

    @property
    def week_id(self):
        return self._api.week_id

    @property
    def day_id(self):
        return self._api.day_id

    @property
    def step_id(self):
        return self._api.step_id

    def add_connection_strs(self, *args, **kwargs):
        """Delegate to underlying API."""
        return self._api.add_connection_strs(*args, **kwargs)

    def post_page(self, destination: str, data: Union[dict, list, tuple],
                  page_type: str) -> Union[str, List[str]]:
        """
        Post page(s) with caching support.

        Args:
            destination: Database ID to post to
            data: Page data (single dict or list/tuple)
            page_type: Type of page being created ('year', 'quarter', 'month', 'week', 'day')

        Returns:
            Page ID(s) - either from cache or newly created
        """
        if isinstance(data, (list, tuple)):
            return [self._post_single_with_cache(destination, d, page_type) for d in data]
        return self._post_single_with_cache(destination, data, page_type)

    def _post_single_with_cache(self, destination: str, data: dict,
                                 page_type: str) -> str:
        """
        Post a single page with cache check.

        Args:
            destination: Database ID
            data: Page data dict with 'title', 'start', optionally 'end'
            page_type: Type of page

        Returns:
            Page ID (from cache or newly created)
        """
        title = data['title']
        cached_id = self._cache.lookup(title, page_type, self._year)

        if cached_id:
            self._logger.info(f"Cache hit for {page_type} '{title}'")
            if self._api.page_exists(cached_id):
                self._logger.info(f"Verified {page_type} '{title}' exists in Notion")
                return cached_id
            else:
                return self._handle_stale_entry(cached_id, data, destination, page_type)

        # Cache miss - create new page
        self._logger.info(f"Cache miss for {page_type} '{title}', creating...")
        page_id = self._api.post_page(destination, data)
        self._cache.store(
            page_id=page_id,
            title=title,
            page_type=page_type,
            start_date=data['start'],
            year=self._year,
            end_date=data.get('end')
        )
        return page_id

    def _handle_stale_entry(self, cached_id: str, data: dict,
                            destination: str, page_type: str) -> str:
        """
        Handle a stale cache entry based on configured mode.

        Both REFRESH_CACHE and REFRESH_NOTION delete the stale entry and
        recreate the page. The two flags exist as semantic aliases:
        --refresh-cache implies "my cache is wrong", --refresh-notion
        implies "Notion is missing pages".

        Args:
            cached_id: The stale page ID from cache
            data: Page data for potential recreation
            destination: Database ID
            page_type: Type of page

        Returns:
            Valid page ID (recreated)

        Raises:
            StaleCacheError: If mode is ERROR
        """
        title = data['title']
        self._logger.warning(f"Stale cache entry: {page_type} '{title}' (ID: {cached_id}) not found in Notion")

        if self._stale_mode == StaleMode.ERROR:
            raise StaleCacheError(cached_id, title, page_type)

        self._logger.info(f"Refreshing stale entry for '{title}'")
        self._cache.delete(cached_id)
        page_id = self._api.post_page(destination, data)
        self._cache.store(
            page_id=page_id,
            title=title,
            page_type=page_type,
            start_date=data['start'],
            year=self._year,
            end_date=data.get('end')
        )
        return page_id
