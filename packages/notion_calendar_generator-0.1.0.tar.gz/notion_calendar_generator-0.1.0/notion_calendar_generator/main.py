import click
import importlib.metadata
import logging
from typing import Union

from notion_calendar_generator.notion import API
from notion_calendar_generator.calendar_generator import Calendar
from notion_calendar_generator.utils import logging_setup, load_envs
from notion_calendar_generator.cache import PageCache, CachedAPI, StaleMode
from notion_calendar_generator.tasks import TaskConfig, TaskGenerator

logger = logging_setup()
package_name = "notion-calendar-generator"

try:
    version = importlib.metadata.version(package_name)
except importlib.metadata.PackageNotFoundError:
    version = 'unknown'


def generate_calendar(notion: Union[API, CachedAPI], calendar: Calendar,
                      logger_instance: logging.Logger = logger) -> None:
    """
    Generate a calendar.

    Args:
        notion: An instance of the API or CachedAPI class.
        calendar: An instance of the Calendar class.
        logger_instance: A logger instance. Defaults to the logger set up at the start of this file.
    """
    logger_instance.info('create year')
    year_page_id = notion.post_page(notion.year_id, calendar.year, page_type='year')

    logger_instance.info('create quarters')
    calendar.update_quarters(year_page_id)
    quarter_page_ids = notion.post_page(notion.quarter_id, calendar.quarters, page_type='quarter')

    logger_instance.info('create months')
    calendar.update_months(year_page_id, quarter_page_ids)
    month_page_ids = notion.post_page(notion.month_id, calendar.months, page_type='month')

    logger_instance.info('create weeks')
    calendar.update_weeks(month_page_ids)
    week_page_ids = notion.post_page(notion.week_id, calendar.weeks, page_type='week')

    logger_instance.info('create days')
    calendar.update_days(week_page_ids)
    notion.post_page(notion.day_id, calendar.days, page_type='day')


def generate_tasks(notion: Union[API, CachedAPI], task_config: TaskConfig, year: int,
                   logger_instance: logging.Logger = logger) -> None:
    """
    Generate recurring task steps in Notion.

    Args:
        notion: An instance of the API or CachedAPI class.
        task_config: A loaded TaskConfig instance.
        year: The year to generate steps for.
        logger_instance: A logger instance.
    """
    generator = TaskGenerator(task_config, year, logger_instance)
    steps = generator.generate_steps()

    if not steps:
        logger_instance.info('no steps to create')
        return

    logger_instance.info(f'creating {len(steps)} steps')
    notion.post_page(notion.step_id, steps, page_type='step')


@click.command()
@click.version_option(version, prog_name="notion-page-generator")
@click.argument("year", type=int)
@click.option("--env-path", default=".env", help="Path to the .env file. Defaults to .env.")
@click.option('--test', default=False, is_flag=True, help='Run in test mode against a different set of databases.')
@click.option('--refresh-cache', 'stale_mode', flag_value='refresh_cache',
              help='If cached page missing from Notion, delete cache entry and recreate.')
@click.option('--refresh-notion', 'stale_mode', flag_value='refresh_notion',
              help='If cached page missing from Notion, recreate it.')
@click.option('--no-cache', is_flag=True, default=False,
              help='Disable caching entirely (creates duplicates like before).')
@click.option('--tasks', default=None, type=click.Path(exists=True),
              help='Path to recurring tasks YAML config.')
def main(year: int, env_path: str = ".env", test: bool = False,
         stale_mode: str = None, no_cache: bool = False, tasks: str = None,
         logger_instance: logging.Logger = logger) -> None:
    """
    The main function.

    Args:
        env_path (str): Path to the .env file. Defaults to ".env".
        year (int): The year for which to generate the calendar.
        test (bool): A flag to determine if the function should run in test mode. Defaults to True.
        stale_mode (str): How to handle stale cache entries ('refresh_cache' or 'refresh_notion').
        no_cache (bool): If True, disable caching entirely.
        logger_instance (logging.Logger): A logger instance. Defaults to the logger set up at the start of this file.
    """
    logger_instance.info("loading API KEYS")
    (NOTION_KEY, DAILY_DATA_ID, WEEKLY_DATA_ID, MONTHLY_DATA_ID, QUARTERLY_DATA_ID, YEARLY_DATA_ID, STEPS_DATA_ID) = load_envs(
        env_path,
        test=test)

    url = "https://api.notion.com/v1/pages"
    headers = {
        'Authorization': f"Bearer {NOTION_KEY}",
        'Content-Type': 'application/json',
        'Notion-Version': '2021-08-16',
    }
    logger_instance.info('loaded url and header')

    notion_api = API(url, headers, logger_instance)
    notion_api.add_connection_strs(DAILY_DATA_ID, WEEKLY_DATA_ID, MONTHLY_DATA_ID, QUARTERLY_DATA_ID, YEARLY_DATA_ID,
                                    step=STEPS_DATA_ID)

    if no_cache:
        logger_instance.info('caching disabled')
        notion = notion_api
    else:
        # Set up caching
        cache = PageCache(base_path=".", logger=logger_instance)
        mode = StaleMode.ERROR
        if stale_mode == 'refresh_cache':
            mode = StaleMode.REFRESH_CACHE
            logger_instance.info('stale mode: refresh-cache')
        elif stale_mode == 'refresh_notion':
            mode = StaleMode.REFRESH_NOTION
            logger_instance.info('stale mode: refresh-notion')
        else:
            logger_instance.info('stale mode: error (default)')

        notion = CachedAPI(notion_api, cache, year=year, stale_mode=mode, logger=logger_instance)

    calendar = Calendar(year)
    generate_calendar(notion, calendar)

    if tasks:
        logger_instance.info(f'loading task config from {tasks}')
        task_config = TaskConfig(tasks, logger_instance)
        task_config.load()
        logger_instance.info('verifying alias page IDs')
        task_config.verify_aliases(notion_api)
        generate_tasks(notion, task_config, year)


if __name__ == "__main__":
    main()
