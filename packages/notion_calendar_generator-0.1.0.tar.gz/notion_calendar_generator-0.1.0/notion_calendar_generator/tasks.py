"""Config-driven recurring task generation for Notion."""

import calendar
import logging
from datetime import date, timedelta
from pathlib import Path
from typing import List, Dict, Optional

import yaml


RELATION_MAP = {
    "trees": "\U0001f332 trees",
    "seas": "\U0001f30a seas",
    "hikes": "\U0001f9d7 hike",
}

VALID_UNITS = {"days", "weeks", "months", "quarters", "years"}

VALID_DAYS_OF_WEEK = {
    "monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3,
    "friday": 4, "saturday": 5, "sunday": 6,
}

VALID_POSITIONS = {"first", "second", "third", "fourth", "last"}

VALID_MONTHS = {
    "january": 1, "february": 2, "march": 3, "april": 4,
    "may": 5, "june": 6, "july": 7, "august": 8,
    "september": 9, "october": 10, "november": 11, "december": 12,
}


class TaskConfigError(Exception):
    """Raised when the task config file is invalid."""
    pass


class TaskConfig:
    """Parses and validates the YAML task config."""

    def __init__(self, config_path: str, logger: logging.Logger = None):
        self.config_path = Path(config_path)
        self.logger = logger or logging.getLogger(__name__)
        self._raw = None
        self.aliases = {}
        self.tasks = []

    def load(self) -> None:
        """Load and validate the YAML config file."""
        with open(self.config_path) as f:
            self._raw = yaml.safe_load(f)

        if not isinstance(self._raw, dict):
            raise TaskConfigError(f"Config file must be a YAML mapping, got {type(self._raw).__name__}")

        self.aliases = self._raw.get("aliases", {})
        self._validate_aliases()

        self.tasks = self._raw.get("tasks", [])
        self._validate_tasks()

    def _validate_aliases(self) -> None:
        """Validate the aliases section."""
        for db_name in self.aliases:
            if db_name not in RELATION_MAP:
                raise TaskConfigError(
                    f"Unknown database '{db_name}' in aliases. Valid: {', '.join(RELATION_MAP.keys())}"
                )
            if not isinstance(self.aliases[db_name], dict):
                raise TaskConfigError(f"aliases.{db_name} must be a mapping of alias_name → page_id")

    def _validate_tasks(self) -> None:
        """Validate the tasks section."""
        if not isinstance(self.tasks, list):
            raise TaskConfigError("'tasks' must be a list")

        for i, task in enumerate(self.tasks):
            if "name" not in task:
                raise TaskConfigError(f"Task {i} missing 'name'")
            if "frequency" not in task:
                continue

            freq = task["frequency"]
            has_interval = "every" in freq and "unit" in freq
            has_days_of_week = "days_of_week" in freq
            has_day_of_month = "day_of_month" in freq
            has_weekday_of_month = "weekday_of_month" in freq

            freq_count = sum([has_interval, has_days_of_week, has_day_of_month, has_weekday_of_month])
            if freq_count == 0:
                raise TaskConfigError(
                    f"Task '{task['name']}': frequency must have one of: "
                    "'every'+'unit', 'days_of_week', 'day_of_month', or 'weekday_of_month'"
                )
            if freq_count > 1:
                raise TaskConfigError(
                    f"Task '{task['name']}': frequency must have exactly one type, got multiple"
                )

            if has_interval:
                if freq["unit"] not in VALID_UNITS:
                    raise TaskConfigError(
                        f"Task '{task['name']}': invalid unit '{freq['unit']}'. Valid: {', '.join(VALID_UNITS)}"
                    )
                if not isinstance(freq["every"], int) or freq["every"] < 1:
                    raise TaskConfigError(f"Task '{task['name']}': 'every' must be a positive integer")

            if has_days_of_week:
                for day in freq["days_of_week"]:
                    if day.lower() not in VALID_DAYS_OF_WEEK:
                        raise TaskConfigError(
                            f"Task '{task['name']}': invalid day '{day}'. Valid: {', '.join(VALID_DAYS_OF_WEEK.keys())}"
                        )

            if has_day_of_month:
                val = freq["day_of_month"]
                if val not in ("even", "odd"):
                    raise TaskConfigError(
                        f"Task '{task['name']}': day_of_month must be 'even' or 'odd', got '{val}'"
                    )

            if has_weekday_of_month:
                wom = freq["weekday_of_month"]
                if "position" not in wom or "day" not in wom:
                    raise TaskConfigError(
                        f"Task '{task['name']}': weekday_of_month requires 'position' and 'day'"
                    )
                if wom["position"] not in VALID_POSITIONS:
                    raise TaskConfigError(
                        f"Task '{task['name']}': invalid position '{wom['position']}'. "
                        f"Valid: {', '.join(VALID_POSITIONS)}"
                    )
                if wom["day"].lower() not in VALID_DAYS_OF_WEEK:
                    raise TaskConfigError(
                        f"Task '{task['name']}': invalid day '{wom['day']}'. "
                        f"Valid: {', '.join(VALID_DAYS_OF_WEEK.keys())}"
                    )
                if "months" in wom:
                    for m in wom["months"]:
                        if m.lower() not in VALID_MONTHS:
                            raise TaskConfigError(
                                f"Task '{task['name']}': invalid month '{m}'. "
                                f"Valid: {', '.join(VALID_MONTHS.keys())}"
                            )

            # Validate relations reference existing aliases
            for db_name, alias in task.get("relations", {}).items():
                if db_name not in RELATION_MAP:
                    raise TaskConfigError(
                        f"Task '{task['name']}': unknown database '{db_name}' in relations"
                    )
                if db_name not in self.aliases or alias not in self.aliases[db_name]:
                    raise TaskConfigError(
                        f"Task '{task['name']}': alias '{alias}' not found in aliases.{db_name}"
                    )

    def verify_aliases(self, api) -> None:
        """
        Verify all alias page IDs exist in Notion. Fails fast before any generation.

        Args:
            api: An API or CachedAPI instance with a page_exists() method.

        Raises:
            TaskConfigError: If any alias page ID is invalid or inaccessible.
        """
        invalid = []
        seen = set()
        for db_name, aliases in self.aliases.items():
            for alias_name, page_id in aliases.items():
                if page_id in seen:
                    continue
                seen.add(page_id)
                self.logger.info(f"Verifying alias {db_name}.{alias_name} ({page_id})")
                if not api.page_exists(page_id):
                    invalid.append(f"  {db_name}.{alias_name}: {page_id}")

        if invalid:
            details = "\n".join(invalid)
            raise TaskConfigError(
                f"The following alias page IDs do not exist in Notion:\n{details}"
            )
        self.logger.info("All alias page IDs verified")

    def resolve_relations(self, task: dict) -> Dict[str, List[str]]:
        """
        Resolve a task's relations from alias names to Notion page IDs.

        Args:
            task: A task dict from the config

        Returns:
            Dict mapping Notion property names to lists of page IDs
        """
        relations = {}
        for db_name, alias in task.get("relations", {}).items():
            notion_property = RELATION_MAP[db_name]
            page_id = self.aliases[db_name][alias]
            relations[notion_property] = [page_id]
        return relations


class TaskGenerator:
    """Generates step page data from task definitions."""

    def __init__(self, config: TaskConfig, year: int, logger: logging.Logger = None):
        self.config = config
        self.year = year
        self.logger = logger or logging.getLogger(__name__)
        self._year_start = date(year, 1, 1)
        self._year_end = date(year, 12, 31)

    def generate_steps(self) -> List[dict]:
        """
        Generate all step page dicts for the configured year.

        Returns:
            List of step dicts ready for post_page(), each with
            'title', 'start', and optionally 'relations'.
        """
        all_steps = []
        for task in self.config.tasks:
            if "frequency" not in task:
                continue
            dates = self._compute_dates(task)
            relations = self.config.resolve_relations(task)
            for d in dates:
                step = {
                    "title": f"{task['name']} - {d.isoformat()}",
                    "start": d.isoformat(),
                }
                if relations:
                    step["relations"] = relations
                all_steps.append(step)
        self.logger.info(f"Generated {len(all_steps)} steps for year {self.year}")
        return all_steps

    def _compute_dates(self, task: dict) -> List[date]:
        """Compute all occurrence dates for a task within the year."""
        freq = task["frequency"]

        if "days_of_week" in freq:
            return self._dates_by_days_of_week(freq["days_of_week"])

        if "day_of_month" in freq:
            return self._dates_by_day_of_month(freq["day_of_month"])

        if "weekday_of_month" in freq:
            wom = freq["weekday_of_month"]
            months = None
            if "months" in wom:
                months = [VALID_MONTHS[m.lower()] for m in wom["months"]]
            return self._dates_by_weekday_of_month(wom["position"], wom["day"], months)

        every = freq["every"]
        unit = freq["unit"]
        start_date = self._parse_start_date(freq.get("start_date"))

        if unit == "days":
            return self._dates_by_interval(start_date, timedelta(days=every))
        elif unit == "weeks":
            return self._dates_by_interval(start_date, timedelta(weeks=every))
        elif unit == "months":
            return self._dates_by_months(start_date, every)
        elif unit == "quarters":
            return self._dates_by_months(start_date, every * 3)
        elif unit == "years":
            return self._dates_by_months(start_date, every * 12)

        return []

    def _parse_start_date(self, start_date_str: Optional[str]) -> date:
        """Parse start_date from config, defaulting to Jan 1 of the year."""
        if start_date_str is None:
            return self._year_start
        if isinstance(start_date_str, date):
            return start_date_str
        return date.fromisoformat(str(start_date_str))

    def _dates_by_interval(self, start: date, delta: timedelta) -> List[date]:
        """Generate dates at a fixed interval within the year."""
        # If start is before our year, advance to first occurrence in the year
        current = start
        if current < self._year_start:
            # How many intervals to skip to reach the year
            days_behind = (self._year_start - current).days
            intervals_to_skip = days_behind // delta.days
            current = current + delta * intervals_to_skip
            if current < self._year_start:
                current += delta

        dates = []
        while current <= self._year_end:
            if current >= self._year_start:
                dates.append(current)
            current += delta
        return dates

    def _dates_by_months(self, start: date, month_step: int) -> List[date]:
        """Generate dates stepping by N months, clamping day to month's last day."""
        target_day = start.day
        dates = []

        # Start from the start_date's month, advance by month_step
        current_year = start.year
        current_month = start.month

        # If start is before our year, advance to first occurrence in the year
        if date(current_year, current_month, 1) < date(self.year, 1, 1):
            months_behind = (self.year - current_year) * 12 + (1 - current_month)
            steps_to_skip = months_behind // month_step
            total_months_to_add = steps_to_skip * month_step
            current_month += total_months_to_add
            current_year += (current_month - 1) // 12
            current_month = (current_month - 1) % 12 + 1

        while True:
            # Clamp day to last day of month
            max_day = calendar.monthrange(current_year, current_month)[1]
            day = min(target_day, max_day)
            d = date(current_year, current_month, day)

            if d > self._year_end:
                break
            if d >= self._year_start:
                dates.append(d)

            # Advance by month_step
            current_month += month_step
            current_year += (current_month - 1) // 12
            current_month = (current_month - 1) % 12 + 1

        return dates

    def _dates_by_days_of_week(self, days: List[str]) -> List[date]:
        """Generate all dates matching the specified days of the week in the year."""
        target_weekdays = {VALID_DAYS_OF_WEEK[d.lower()] for d in days}
        dates = []
        current = self._year_start
        while current <= self._year_end:
            if current.weekday() in target_weekdays:
                dates.append(current)
            current += timedelta(days=1)
        return dates

    def _dates_by_day_of_month(self, pattern: str) -> List[date]:
        """Generate dates where day-of-month is even or odd."""
        is_even = pattern == "even"
        dates = []
        current = self._year_start
        while current <= self._year_end:
            if (current.day % 2 == 0) == is_even:
                dates.append(current)
            current += timedelta(days=1)
        return dates

    def _dates_by_weekday_of_month(self, position: str, day: str,
                                    months: Optional[List[int]] = None) -> List[date]:
        """
        Generate dates for the Nth weekday of specified months.

        Args:
            position: 'first', 'second', 'third', 'fourth', or 'last'
            day: Day of week name (e.g. 'saturday')
            months: List of month numbers (1-12). If None, all 12 months.
        """
        target_weekday = VALID_DAYS_OF_WEEK[day.lower()]
        target_months = months if months else list(range(1, 13))
        dates = []

        for month in target_months:
            if month < 1 or month > 12:
                continue
            d = self._find_weekday_in_month(self.year, month, target_weekday, position)
            if d and self._year_start <= d <= self._year_end:
                dates.append(d)

        dates.sort()
        return dates

    @staticmethod
    def _find_weekday_in_month(year: int, month: int, weekday: int, position: str) -> Optional[date]:
        """Find the Nth occurrence of a weekday in a given month."""
        _, last_day = calendar.monthrange(year, month)

        if position == "last":
            # Start from last day, go backwards
            d = date(year, month, last_day)
            while d.day >= 1:
                if d.weekday() == weekday:
                    return d
                d -= timedelta(days=1)
            return None

        # first, second, third, fourth
        position_map = {"first": 1, "second": 2, "third": 3, "fourth": 4}
        target_n = position_map[position]
        count = 0
        for day_num in range(1, last_day + 1):
            d = date(year, month, day_num)
            if d.weekday() == weekday:
                count += 1
                if count == target_n:
                    return d
        return None
