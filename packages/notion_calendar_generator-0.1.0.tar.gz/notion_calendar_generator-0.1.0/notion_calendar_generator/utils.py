import logging
import dotenv
import os


class MissingEnvError(Exception):
    """Raised when required environment variables are missing."""
    pass


ENV_KEYS = [
    "NOTION_KEY", "DAILY_DATA_ID", "WEEKLY_DATA_ID",
    "MONTHLY_DATA_ID", "QUARTERLY_DATA_ID", "YEARLY_DATA_ID", "STEPS_DATA_ID",
]


def load_envs(env_path: str, test: bool = False) -> tuple:
    """
    Load environment variables from a .env file.

    Args:
        env_path: Path to the .env file.
        test: If True, load TEST_-prefixed variables.

    Returns:
        tuple: (NOTION_KEY, DAILY_DATA_ID, WEEKLY_DATA_ID,
                MONTHLY_DATA_ID, QUARTERLY_DATA_ID, YEARLY_DATA_ID, STEPS_DATA_ID)

    Raises:
        MissingEnvError: If any required variable (except STEPS_DATA_ID) is missing.
    """
    dotenv.load_dotenv(env_path)
    prefix = "TEST_" if test else ""
    values = tuple(os.getenv(f"{prefix}{key}") for key in ENV_KEYS)

    missing = [
        f"{prefix}{key}" for key, val in zip(ENV_KEYS, values)
        if val is None and key != "STEPS_DATA_ID"
    ]
    if missing:
        raise MissingEnvError(f"Missing environment variables: {', '.join(missing)}")

    return values


def logging_setup() -> logging.Logger:
    """
    Set up a logger with a specific format and level.

    Returns:
        logging.Logger: A logger instance.
    """
    logger = logging.getLogger('nocage')
    fmt = logging.Formatter(
        fmt='%(asctime)s %(levelname)-8s (%(module)s:%(funcName)s:%(lineno)d): %(message)s',
        datefmt='%H:%M'
    )

    logger.setLevel(logging.DEBUG)
    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)
    console.setFormatter(fmt)
    logger.addHandler(console)
    return logger
