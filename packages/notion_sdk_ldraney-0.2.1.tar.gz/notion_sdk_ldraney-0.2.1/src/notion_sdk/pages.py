"""Page operations."""

from __future__ import annotations

from typing import Any


class PagesMixin:
    """Mixin providing page API methods."""

    def create_page(
        self,
        parent: dict[str, Any],
        properties: dict[str, Any],
        children: list[dict[str, Any]] | None = None,
        template: dict[str, Any] | None = None,
        icon: dict[str, Any] | None = None,
        cover: dict[str, Any] | None = None,
        position: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """POST /v1/pages — Create a new page.

        Args:
            parent: Parent object, e.g. ``{"type": "page_id", "page_id": "..."}``.
            properties: Page properties mapping.
            children: Optional list of block children to append to the page.
                Cannot be used when *template* is specified — they are mutually
                exclusive.
            template: Optional data-source template dict to create the page
                from.  Cannot be used together with *children*.  Expected
                format is one of::

                    {"type": "none"}
                    {"type": "default"}
                    {"type": "template_id", "template_id": "<uuid>"}
            icon: Optional icon object, e.g. ``{"type": "emoji", "emoji": "..."}``.
            cover: Optional cover object, e.g.
                ``{"type": "external", "external": {"url": "..."}}``.
            position: Optional position object controlling where the page is
                placed within its parent.  Valid formats::

                    {"type": "page_start"}
                    {"type": "page_end"}
                    {"type": "after_block", "after_block": {"id": "<block_id>"}}

        """
        body: dict[str, Any] = {"parent": parent, "properties": properties}
        if children is not None:
            body["children"] = children
        if template is not None:
            body["template"] = template
        if icon is not None:
            body["icon"] = icon
        if cover is not None:
            body["cover"] = cover
        if position is not None:
            body["position"] = position
        body.update(kwargs)
        return self._post("/pages", json=body)

    def get_page(
        self,
        page_id: str,
        filter_properties: list[str] | None = None,
    ) -> dict[str, Any]:
        """GET /v1/pages/{page_id} — Retrieve a page.

        Args:
            page_id: The UUID of the page to retrieve.
            filter_properties: Optional list of property IDs to include in
                the response.  Only the specified properties will be returned.
        """
        params: dict[str, Any] = {}
        if filter_properties is not None:
            params["filter_properties"] = filter_properties
        return self._get(f"/pages/{page_id}", params=params or None)

    def get_page_property_item(
        self,
        page_id: str,
        property_id: str,
        start_cursor: str | None = None,
        page_size: int | None = None,
    ) -> dict[str, Any]:
        """GET /v1/pages/{page_id}/properties/{property_id} — Retrieve a page property item.

        Args:
            page_id: The UUID of the page.
            property_id: The ID of the property to retrieve.
            start_cursor: Cursor for paginated property values (e.g. rollups).
            page_size: Number of results per page for paginated properties.
        """
        params: dict[str, Any] = {}
        if start_cursor is not None:
            params["start_cursor"] = start_cursor
        if page_size is not None:
            params["page_size"] = page_size
        return self._get(
            f"/pages/{page_id}/properties/{property_id}", params=params or None
        )

    def update_page(
        self,
        page_id: str,
        erase_content: bool | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """PATCH /v1/pages/{page_id} — Update page properties.

        Args:
            erase_content: If True, clears all block content from the page.

                .. warning::
                    This is a **destructive, irreversible** operation.  All
                    block children of the page will be permanently deleted and
                    cannot be recovered.
        """
        body = dict(kwargs)
        if erase_content is not None:
            body["erase_content"] = erase_content
        return self._patch(f"/pages/{page_id}", json=body)

    def archive_page(self, page_id: str) -> dict[str, Any]:
        """PATCH /v1/pages/{page_id} — Archive (soft-delete) a page."""
        return self._patch(f"/pages/{page_id}", json={"archived": True})

    def move_page(
        self,
        page_id: str,
        parent: dict[str, Any],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """POST /v1/pages/{page_id}/move — Move a page to a new parent.

        Args:
            parent: New parent object, e.g. {"type": "page_id", "page_id": "..."}
        """
        body: dict[str, Any] = {"parent": parent}
        body.update(kwargs)
        return self._post(f"/pages/{page_id}/move", json=body)
