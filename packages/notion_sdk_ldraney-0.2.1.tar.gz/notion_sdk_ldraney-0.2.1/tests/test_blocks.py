"""Integration tests for block operations."""

from notion_sdk import NotionClient


def test_get_block(client: NotionClient, test_page_id: str):
    """GET /v1/blocks/{block_id} — a page is also a block."""
    block = client.get_block(test_page_id)
    assert block["id"]
    assert block["object"] == "block"


def test_get_block_children(client: NotionClient, test_page_id: str):
    """GET /v1/blocks/{block_id}/children returns a list."""
    result = client.get_block_children(test_page_id)
    assert result["object"] == "list"
    assert "results" in result


def test_append_update_delete_block(
    client: NotionClient, test_page_id: str, cleanup_ids: dict
):
    """Append a paragraph block, update it, then delete it."""
    # Append
    appended = client.append_block_children(
        test_page_id,
        children=[
            {
                "object": "block",
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [{"type": "text", "text": {"content": "Hello from SDK"}}]
                },
            }
        ],
    )
    block_id = appended["results"][0]["id"]
    cleanup_ids["blocks"].append(block_id)

    # Update
    updated = client.update_block(
        block_id,
        paragraph={
            "rich_text": [{"type": "text", "text": {"content": "Updated from SDK"}}]
        },
    )
    assert updated["id"] == block_id

    # Delete
    deleted = client.delete_block(block_id)
    assert deleted["archived"] is True
    # Already deleted, remove from cleanup
    cleanup_ids["blocks"].remove(block_id)


def test_append_block_children_with_position(
    client: NotionClient, test_page_id: str, cleanup_ids: dict
):
    """append_block_children accepts a position parameter and inserts in order."""
    # Create a dedicated sub-page so other tests don't pollute the children list
    parent_page = client.create_page(
        parent={"type": "page_id", "page_id": test_page_id},
        properties={"title": [{"text": {"content": "Position Test Page"}}]},
    )
    parent_id = parent_page["id"]
    cleanup_ids["pages"].append(parent_id)

    # Append first block
    first = client.append_block_children(
        parent_id,
        children=[
            {
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [{"type": "text", "text": {"content": "First block"}}]
                },
            }
        ],
    )
    first_id = first["results"][0]["id"]

    # Append third block (will be at the end)
    third = client.append_block_children(
        parent_id,
        children=[
            {
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [{"type": "text", "text": {"content": "Third block"}}]
                },
            }
        ],
    )
    third_id = third["results"][0]["id"]

    # Insert second block after the first using the position param
    second = client.append_block_children(
        parent_id,
        children=[
            {
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [{"type": "text", "text": {"content": "After first"}}]
                },
            }
        ],
        position={"type": "after_block", "after_block": {"id": first_id}},
    )
    second_id = second["results"][0]["id"]

    assert second["results"][0]["type"] == "paragraph"

    # Verify insertion order: first, second, third
    children = client.get_block_children(parent_id)
    child_ids = [c["id"] for c in children["results"]]
    first_idx = child_ids.index(first_id)
    second_idx = child_ids.index(second_id)
    third_idx = child_ids.index(third_id)
    assert first_idx < second_idx < third_idx, (
        f"Expected first < second < third, got indices {first_idx}, {second_idx}, {third_idx}"
    )
