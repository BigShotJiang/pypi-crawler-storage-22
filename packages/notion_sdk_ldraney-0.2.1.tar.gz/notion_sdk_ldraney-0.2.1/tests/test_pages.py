"""Integration tests for page operations."""

from notion_sdk import NotionClient


def test_get_page(client: NotionClient, test_page_id: str):
    """GET /v1/pages/{page_id} retrieves the test page."""
    page = client.get_page(test_page_id)
    assert page["id"].replace("-", "") == test_page_id.replace("-", "")
    assert page["object"] == "page"


def test_create_and_archive_page(
    client: NotionClient, test_page_id: str, cleanup_ids: dict
):
    """Create a child page, verify it exists, then archive it."""
    page = client.create_page(
        parent={"type": "page_id", "page_id": test_page_id},
        properties={"title": [{"text": {"content": "SDK Test Page"}}]},
    )
    cleanup_ids["pages"].append(page["id"])

    assert page["object"] == "page"
    assert page["archived"] is False

    # Retrieve
    fetched = client.get_page(page["id"])
    assert fetched["id"] == page["id"]

    # Archive
    archived = client.archive_page(page["id"])
    assert archived["archived"] is True


def test_update_page_icon(
    client: NotionClient, test_page_id: str, cleanup_ids: dict
):
    """Create a page then update its icon."""
    page = client.create_page(
        parent={"type": "page_id", "page_id": test_page_id},
        properties={"title": [{"text": {"content": "Icon Test"}}]},
    )
    cleanup_ids["pages"].append(page["id"])

    updated = client.update_page(
        page["id"],
        icon={"type": "emoji", "emoji": "🧪"},
    )
    assert updated["icon"]["emoji"] == "\U0001f9ea"


def test_create_page_with_template_param(
    client: NotionClient, test_page_id: str, cleanup_ids: dict
):
    """create_page accepts a template parameter without error.

    We pass template=None (the default) and verify the page is created
    normally.  The ``template`` parameter accepts a dict such as
    ``{"type": "default"}`` or ``{"type": "template_id", "template_id": "<uuid>"}``.
    A full dict-based template test requires a database with templates
    configured, so this validates the parameter plumbing only.
    """
    page = client.create_page(
        parent={"type": "page_id", "page_id": test_page_id},
        properties={"title": [{"text": {"content": "Template Param Test"}}]},
        template=None,
    )
    cleanup_ids["pages"].append(page["id"])
    assert page["object"] == "page"

    # NOTE: We cannot test template={"type": "default"} or
    # template={"type": "template_id", "template_id": "..."} here because
    # that requires a database with pre-configured templates.  The type
    # annotation (dict[str, Any] | None) ensures callers pass the correct
    # shape at development time.


def test_update_page_erase_content(
    client: NotionClient, test_page_id: str, cleanup_ids: dict
):
    """Create a page with content, then erase it with erase_content=True."""
    # Create page
    page = client.create_page(
        parent={"type": "page_id", "page_id": test_page_id},
        properties={"title": [{"text": {"content": "Erase Content Test"}}]},
        children=[
            {
                "type": "paragraph",
                "paragraph": {
                    "rich_text": [{"text": {"content": "This will be erased"}}]
                },
            }
        ],
    )
    cleanup_ids["pages"].append(page["id"])

    # Verify content exists
    blocks = client.get_block_children(page["id"])
    assert len(blocks["results"]) >= 1

    # Erase content
    updated = client.update_page(page["id"], erase_content=True)
    assert updated["object"] == "page"

    # Verify content is gone
    blocks_after = client.get_block_children(page["id"])
    assert len(blocks_after["results"]) == 0


def test_move_page(
    client: NotionClient, test_page_id: str, cleanup_ids: dict
):
    """Create two pages, move one under the other."""
    # Create parent page
    parent_page = client.create_page(
        parent={"type": "page_id", "page_id": test_page_id},
        properties={"title": [{"text": {"content": "Move Target"}}]},
    )
    cleanup_ids["pages"].append(parent_page["id"])

    # Create page to move
    child_page = client.create_page(
        parent={"type": "page_id", "page_id": test_page_id},
        properties={"title": [{"text": {"content": "Page To Move"}}]},
    )
    cleanup_ids["pages"].append(child_page["id"])

    # Move child under parent
    moved = client.move_page(
        child_page["id"],
        parent={"type": "page_id", "page_id": parent_page["id"]},
    )
    assert moved["object"] == "page"
    assert moved["parent"]["page_id"].replace("-", "") == parent_page["id"].replace("-", "")


def test_create_page_with_icon_and_cover(
    client: NotionClient, test_page_id: str, cleanup_ids: dict
):
    """create_page accepts icon and cover as explicit params."""
    page = client.create_page(
        parent={"type": "page_id", "page_id": test_page_id},
        properties={"title": [{"text": {"content": "Icon+Cover Test"}}]},
        icon={"type": "emoji", "emoji": "🚀"},
    )
    cleanup_ids["pages"].append(page["id"])
    assert page["object"] == "page"
    assert page["icon"]["emoji"] == "\U0001f680"


def test_get_page_with_filter_properties(
    client: NotionClient, test_page_id: str, cleanup_ids: dict
):
    """GET /v1/pages/{page_id} with filter_properties returns only requested properties.

    Creates a page inside a database with multiple properties so we can
    assert that non-requested properties are genuinely absent from the
    response (not just trivially passing because there's only one property).
    """
    # Create a database with multiple properties
    db = client.create_database(
        parent={"type": "page_id", "page_id": test_page_id},
        title=[{"text": {"content": "Filter Props Test DB"}}],
        initial_data_source={
            "properties": {
                "Name": {"type": "title", "title": {}},
                "Category": {
                    "type": "select",
                    "select": {
                        "options": [{"name": "A", "color": "green"}]
                    },
                },
                "Priority": {
                    "type": "select",
                    "select": {
                        "options": [{"name": "High", "color": "red"}]
                    },
                },
            }
        },
    )
    cleanup_ids["databases"].append(db["id"])

    # Create a page (row) in the database
    page = client.create_page(
        parent={"type": "database_id", "database_id": db["id"]},
        properties={
            "Name": {"title": [{"text": {"content": "Filter Test Row"}}]},
            "Category": {"select": {"name": "A"}},
            "Priority": {"select": {"name": "High"}},
        },
    )
    cleanup_ids["pages"].append(page["id"])

    # Confirm the unfiltered page has all three properties
    unfiltered = client.get_page(page["id"])
    assert "Name" in unfiltered["properties"]
    assert "Category" in unfiltered["properties"]
    assert "Priority" in unfiltered["properties"]

    # Get the Name property ID and filter for only that property
    name_prop_id = unfiltered["properties"]["Name"]["id"]
    filtered = client.get_page(page["id"], filter_properties=[name_prop_id])
    assert filtered["object"] == "page"
    assert filtered["id"] == page["id"]
    # Only the requested property should be present
    assert "Name" in filtered["properties"]
    assert "Category" not in filtered["properties"], (
        "Category should be excluded by filter_properties"
    )
    assert "Priority" not in filtered["properties"], (
        "Priority should be excluded by filter_properties"
    )


def test_get_page_property_item(
    client: NotionClient, test_page_id: str, cleanup_ids: dict
):
    """GET /v1/pages/{page_id}/properties/{property_id} retrieves a property item."""
    # Create a page so we have a known property to query
    page = client.create_page(
        parent={"type": "page_id", "page_id": test_page_id},
        properties={"title": [{"text": {"content": "Prop Item Test"}}]},
    )
    cleanup_ids["pages"].append(page["id"])

    # The "title" property always exists — find its property ID
    title_prop_id = page["properties"]["title"]["id"]

    result = client.get_page_property_item(page["id"], title_prop_id)
    # Title properties return a paginated list of rich_text items
    assert result["object"] == "list"
    assert "results" in result
    assert len(result["results"]) >= 1
    # The first result should be a title-type rich_text item
    assert result["results"][0]["type"] == "title"
