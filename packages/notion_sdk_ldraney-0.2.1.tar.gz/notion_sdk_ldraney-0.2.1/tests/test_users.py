"""Integration tests for user operations."""

from notion_sdk import NotionClient


def test_get_users(client: NotionClient):
    """GET /v1/users returns a list."""
    result = client.get_users()
    assert result["object"] == "list"
    assert "results" in result


def test_get_self(client: NotionClient):
    """GET /v1/users/me returns the bot user."""
    bot = client.get_self()
    assert bot["object"] == "user"
    assert bot["type"] == "bot"


def test_get_user(client: NotionClient):
    """GET /v1/users/{user_id} retrieves a single user by ID."""
    # Use the bot's own ID (retrieved via get_self) as the target
    bot = client.get_self()
    user = client.get_user(bot["id"])
    assert user["object"] == "user"
    assert user["id"] == bot["id"]
