"""Legacy v1 implementation namespace."""
