from enum import StrEnum


class OrderByDirections(StrEnum):
    ASC = 'asc'
    DESC = 'desc'
