"""
Nous namespace package.
"""
