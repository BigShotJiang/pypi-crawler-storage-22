from nova_cli.cli.main import main

if __name__ == "__main__":
    main()
