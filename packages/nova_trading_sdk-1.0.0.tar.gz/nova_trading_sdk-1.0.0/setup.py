from setuptools import setup, find_packages

setup(
    name="nova-trading-sdk",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "httpx>=0.24.0",
        "pydantic>=2.0.0",
        "python-dotenv>=1.0.0"
    ],
    author="Nova Trading",
    description="Nova Trading SDK for Bybit Broker Integration",
    url="https://github.com/novaglobal/nova-sdk",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    python_requires=">=3.8",
)
