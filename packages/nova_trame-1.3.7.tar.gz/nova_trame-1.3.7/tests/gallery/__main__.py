"""Entry point for the widget gallery."""

from tests.gallery import main

main()
