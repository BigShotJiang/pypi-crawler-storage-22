"""
NovaLang Repository Generator - Auto-generated CRUD operations
Generates repository implementations for database entities
"""

from typing import Dict, List, Any, Optional
import mysql.connector
import sqlite3

class BaseRepository:
    """Base repository with CRUD operations"""
    
    def __init__(self, entity_class: str, table_name: str, db_connection: Any):
        self.entity_class = entity_class
        self.table_name = table_name
        self.db_connection = db_connection
        self.is_mysql = isinstance(db_connection, mysql.connector.connection.MySQLConnection)
    
    def _to_snake_case(self, camel_str: str) -> str:
        """Convert camelCase to snake_case"""
        result = []
        for i, char in enumerate(camel_str):
            if char.isupper() and i > 0:
                result.append('_')
                result.append(char.lower())
            else:
                result.append(char.lower())
        return ''.join(result)
    
    def _convert_entity_to_db(self, entity: Dict[str, Any]) -> Dict[str, Any]:
        """Convert camelCase entity fields to snake_case database columns"""
        return {self._to_snake_case(key): value for key, value in entity.items()}
    
    def find_all(self) -> List[Dict[str, Any]]:
        """Get all records"""
        cursor = self.db_connection.cursor(dictionary=True if self.is_mysql else None)
        cursor.execute(f"SELECT * FROM {self.table_name}")
        
        if self.is_mysql:
            results = cursor.fetchall()
        else:
            # SQLite - convert to dict
            columns = [desc[0] for desc in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
        
        cursor.close()
        return results
    
    def find_by_id(self, id_value: Any) -> Optional[Dict[str, Any]]:
        """Find by primary key"""
        cursor = self.db_connection.cursor(dictionary=True if self.is_mysql else None)
        cursor.execute(f"SELECT * FROM {self.table_name} WHERE id = %s", (id_value,))
        
        if self.is_mysql:
            result = cursor.fetchone()
        else:
            # SQLite
            columns = [desc[0] for desc in cursor.description]
            row = cursor.fetchone()
            result = dict(zip(columns, row)) if row else None
        
        cursor.close()
        return result
    
    def save(self, entity: Dict[str, Any]) -> Dict[str, Any]:
        """Insert or update record"""
        from datetime import datetime
        cursor = self.db_connection.cursor()
        
        # Convert camelCase to snake_case for database
        db_entity = self._convert_entity_to_db(entity)
        
        # Check if entity has ID (update) or not (insert)
        if 'id' in db_entity and db_entity['id']:
            # Update - set updated_at timestamp
            db_entity['updated_at'] = datetime.now()
            
            set_clause = ', '.join([f"{k} = %s" for k in db_entity.keys() if k != 'id'])
            values = [v for k, v in db_entity.items() if k != 'id']
            values.append(db_entity['id'])
            
            sql = f"UPDATE {self.table_name} SET {set_clause} WHERE id = %s"
            cursor.execute(sql, values)
            entity['id'] = db_entity['id']
            entity['updatedAt'] = db_entity['updated_at']
        else:
            # Insert - set both created_at and updated_at timestamps
            db_entity['created_at'] = datetime.now()
            db_entity['updated_at'] = datetime.now()
            
            columns = [k for k in db_entity.keys() if k != 'id' or db_entity[k]]
            placeholders = ', '.join(['%s'] * len(columns))
            values = [db_entity[k] for k in columns]
            
            sql = f"INSERT INTO {self.table_name} ({', '.join(columns)}) VALUES ({placeholders})"
            cursor.execute(sql, values)
            
            # Get last inserted ID and add to original entity
            if self.is_mysql:
                entity['id'] = cursor.lastrowid
            else:
                entity['id'] = cursor.lastrowid
            entity['createdAt'] = db_entity['created_at']
            entity['updatedAt'] = db_entity['updated_at']
        
        self.db_connection.commit()
        cursor.close()
        return entity
    
    def delete_by_id(self, id_value: Any) -> bool:
        """Delete by primary key"""
        cursor = self.db_connection.cursor()
        cursor.execute(f"DELETE FROM {self.table_name} WHERE id = %s", (id_value,))
        self.db_connection.commit()
        affected = cursor.rowcount
        cursor.close()
        return affected > 0
    
    def count(self) -> int:
        """Count all records"""
        cursor = self.db_connection.cursor()
        cursor.execute(f"SELECT COUNT(*) FROM {self.table_name}")
        count = cursor.fetchone()[0]
        cursor.close()
        return count
    
    def exists_by_id(self, id_value: Any) -> bool:
        """Check if record exists"""
        cursor = self.db_connection.cursor()
        cursor.execute(f"SELECT 1 FROM {self.table_name} WHERE id = %s LIMIT 1", (id_value,))
        exists = cursor.fetchone() is not None
        cursor.close()
        return exists
    
    def execute_query(self, query: str, params: tuple = ()) -> List[Dict[str, Any]]:
        """Execute custom query"""
        cursor = self.db_connection.cursor(dictionary=True if self.is_mysql else None)
        cursor.execute(query, params)
        
        if self.is_mysql:
            results = cursor.fetchall()
        else:
            columns = [desc[0] for desc in cursor.description]
            results = [dict(zip(columns, row)) for row in cursor.fetchall()]
        
        cursor.close()
        return results

class RepositoryFactory:
    """Factory to create repository instances"""
    
    @staticmethod
    def create_repository(entity_class: str, table_name: str, 
                         db_connection: Any) -> BaseRepository:
        """Create a repository instance for an entity"""
        return BaseRepository(entity_class, table_name, db_connection)
