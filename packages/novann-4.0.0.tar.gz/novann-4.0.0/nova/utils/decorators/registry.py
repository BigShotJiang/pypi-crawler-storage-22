from __future__ import annotations
from typing import Callable, Type, TYPE_CHECKING, TypeVar

if TYPE_CHECKING:
    from nova.autograd.function import Function
    from nova._typing import ModuleTypes

_MODULES: dict[tuple[str, str], ModuleTypes] = {}
_OPS_REGISTERED: dict[str, Type[Function]] = {}

T = TypeVar("T", bound=type)


def registry_class(cls: T):
    """
    Register a class for safe serialization and deserialization.

    This decorator registers the given class using its fully qualified
    name (module + class name). Registered classes can later be resolved
    during safe unpickling.

    The registration is idempotent: re-registering the same class has
    no effect.

    Args:
        cls: Class to register.

    Returns:
        The original class, unmodified.
    """
    key = (cls.__module__, cls.__name__)
    if key not in _MODULES:
        _MODULES[key] = cls
    return cls


def registry_op(op_name: str) -> Callable[[Type[Function]], Type[Function]]:
    """
    Register an autograd Function under a public operation name.

    This decorator associates a string operation name with a subclass
    of `Function`. The mapping is later used during deserialization
    to safely reconstruct computation graphs.

    Args:
        op_name: Public name of the operation (e.g., "add", "relu").

    Returns:
        A decorator that registers a Function subclass.

    Raises:
        ValueError: If the decorated object is not a subclass of `Function`.

    Example:
        >>> from nova.autograd.function import Function
        >>> from nova.utils.decorators.registry import registry_op
        >>>
        >>> @registry_op("add")
        ... class Add(Function):
        ...     @staticmethod
        ...     def forward(ctx, x, y):
        ...         return x + y
        ...
        >>> # The operation "add" is now safely registered
    """

    from nova.autograd.function import Function

    def register(cls: Type[Function]):
        if not (isinstance(cls, type) and issubclass(cls, Function)):
            raise ValueError(
                f"Only Function classes can be registered, but got "
                f"'{cls.__name__ if hasattr(cls, '__name__') else cls}'"
            )

        if op_name not in _OPS_REGISTERED:
            _OPS_REGISTERED.setdefault(op_name, cls)
        return cls

    return register


def get_registered_classes(module, name) -> ModuleTypes:
    """
    Retrieve a previously registered class by module and name.

    This function is used during safe deserialization to resolve
    classes that were explicitly registered via `registry_class`.

    Args:
        module: Module path of the class.
        name: Class name.

    Returns:
        The registered class or None if not found.

    Raises:
        KeyError: If the class is not found in the registry.
    """
    return _MODULES.get((module, name), None)
