# Novyx SDK

Unified SDK for Novyx Core + RAM + Sentinel.

## Install (local)

```bash
pip install -e ./sdk
```

## Quick Start

```python
from novyx import Novyx

nx = Novyx(
    api_key="nram_...",
    api_url="https://novyx-ram-api.fly.dev",
    sentinel_url="https://novyx-sentinel.fly.dev",
    strict=False,
)

result = nx.remember("User prefers dark mode", tags=["ui", "preference"])
memories = nx.recall("UI preferences", limit=5)
nx.act("send_email", {"to": "user@example.com"})
nx.rollback("2025-01-30T14:00:00Z")
```

## Four Verbs

- `remember(content, tags=[])` → store memory with cryptographic hash
- `recall(query, limit=5)` → semantic search (uses `q` param)
- `act(action_name, params)` → Sentinel policy check before action
- `rollback(target)` → Magic Rollback™ (timestamp or artifact id)

## Enterprise Telemetry

Set `NOVYX_TIER=enterprise` to enable audit pulse logging to the Core audit trail.

## Test Drive

```bash
python sdk/test_drive.py
```
