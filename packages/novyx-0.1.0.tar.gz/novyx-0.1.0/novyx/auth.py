from extensions.novyx_ram.sdk import NovyxRAMClient, AuthenticationError, NovyxRAMError

from .exceptions import NovyxAuthError, NovyxStorageError


def validate_api_key(api_key: str, api_url: str) -> None:
    """
    Validate RAM API key by calling an authenticated endpoint.

    Raises:
        NovyxAuthError: If the API key is invalid.
        NovyxStorageError: If the API is unreachable.
    """
    try:
        client = NovyxRAMClient(api_key=api_key, base_url=api_url)
        _ = client.stats()
    except AuthenticationError as exc:
        raise NovyxAuthError("Invalid Novyx API key.") from exc
    except NovyxRAMError as exc:
        raise NovyxStorageError(str(exc)) from exc
