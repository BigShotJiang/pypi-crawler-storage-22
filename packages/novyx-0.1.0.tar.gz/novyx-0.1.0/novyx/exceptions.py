class NovyxAuthError(Exception):
    """Raised when API key authentication fails."""


class NovyxSecurityError(Exception):
    """Raised when Sentinel blocks an action or integrity check fails."""


class NovyxStorageError(Exception):
    """Raised when RAM or Core storage operations fail."""
