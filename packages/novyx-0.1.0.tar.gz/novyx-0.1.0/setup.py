from setuptools import setup, find_packages


setup(
    name="novyx",
    version="0.1.0",
    description="Unified Novyx SDK (Core + RAM + Sentinel)",
    package_dir={"": "."},
    packages=find_packages("."),
    install_requires=[
        "requests",
        "pydantic",
    ],
    python_requires=">=3.9",
)
