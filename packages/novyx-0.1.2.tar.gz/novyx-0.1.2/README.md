# Novyx SDK

**Memory + security layer for AI agents.** Give your AI persistent memory, semantic search, and Magic Rollback to undo mistakes. Works with LangChain, CrewAI, or any Python agent framework.

## Installation

```bash
pip install novyx
```

## Quick Start

```python
from novyx import Novyx

# Initialize with your API key
nx = Novyx(api_key="nram_your_key_here")

# Store a memory
nx.remember("User prefers dark mode and async communication", tags=["preferences"])

# Search memories semantically
memories = nx.recall("communication style", limit=5)
for mem in memories:
    print(f"{mem['observation']} (relevance: {mem['score']:.2f})")

# Magic Rollback - undo to any point in time
nx.rollback("2025-01-30T14:00:00Z")
```

## Features

### Persistent Memory
Store observations about users, contexts, and decisions. Your AI remembers everything across sessions.

```python
nx.remember("Customer mentioned budget is $50K for Q1", tags=["sales", "budget"])
nx.remember("User is building a real estate AI assistant", tags=["project"])
```

### Semantic Search
Find relevant memories using natural language queries. No exact keyword matching required.

```python
memories = nx.recall("what is the user working on?", limit=3)
# Returns: "User is building a real estate AI assistant"
```

### Magic Rollback
Made a mistake? Roll back your AI's memory to any point in time.

```python
# Undo the last hour of changes
nx.rollback("2025-01-30T14:00:00Z")

# Or use dry_run to preview what would change
nx.rollback("2025-01-30T14:00:00Z", dry_run=True)
```

### Security Layer (Sentinel)
Optional policy enforcement before critical actions.

```python
# Check if action is allowed before executing
nx.act("send_email", {"to": "user@example.com", "subject": "Follow up"})
```

## API Reference

| Method | Description |
|--------|-------------|
| `remember(content, tags=[])` | Store a memory with optional tags |
| `recall(query, limit=5)` | Semantic search for relevant memories |
| `rollback(timestamp)` | Restore memory state to a point in time |
| `act(action, params)` | Policy-checked action execution |

## Pricing

- **Free**: 10K memories, 5K API calls/month, 3 rollbacks
- **Starter** ($29/mo): 50K memories, 25K API calls/month, 5 rollbacks/month
- **Pro** ($99/mo): Unlimited memories, 100K API calls/month, unlimited rollbacks
- **Enterprise**: Custom limits, SSO, dedicated support

## Links

- [Documentation](https://novyxlabs.com/docs)
- [GitHub](https://github.com/novyxlabs/novyx-core)
- [Pricing](https://novyxlabs.com/pricing)
- [Get API Key](https://novyxlabs.com)

## License

MIT License - see [LICENSE](https://github.com/novyxlabs/novyx-core/blob/main/LICENSE) for details.
