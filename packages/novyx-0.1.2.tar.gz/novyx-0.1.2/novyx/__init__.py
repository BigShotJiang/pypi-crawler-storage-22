"""
Novyx SDK - Memory + security layer for AI agents.

Quick Start:
    >>> from novyx import Novyx
    >>> nx = Novyx(api_key="nram_your_key_here")
    >>> nx.remember("User prefers dark mode", tags=["ui"])
    >>> memories = nx.recall("user preferences")
"""

from .client import Novyx
from .exceptions import (
    NovyxError,
    NovyxAuthError,
    NovyxSecurityError,
    NovyxUpgradeRequired,
)

__version__ = "0.1.2"
__all__ = [
    "Novyx",
    "NovyxError",
    "NovyxAuthError",
    "NovyxSecurityError",
    "NovyxUpgradeRequired",
]
