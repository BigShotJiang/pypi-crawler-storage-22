"""
Novyx SDK - Pure API Client

Memory + security layer for AI agents.
"""

import requests
from typing import Any, Dict, List, Optional

from .exceptions import NovyxError, NovyxAuthError, NovyxSecurityError, NovyxUpgradeRequired


class Novyx:
    """
    Novyx SDK client for AI agent memory and security.

    Four verbs:
    - remember(content, tags) - Store a memory
    - recall(query, limit) - Search memories semantically
    - act(action, params) - Execute a policy-checked action
    - rollback(target) - Restore memory to a point in time

    Example:
        >>> nx = Novyx(api_key="nram_your_key_here")
        >>> nx.remember("User prefers dark mode", tags=["ui"])
        >>> memories = nx.recall("user preferences")
        >>> nx.rollback("2025-01-30T14:00:00Z")
    """

    def __init__(
        self,
        api_key: str,
        api_url: str = "https://novyx-ram-api.fly.dev",
        timeout: int = 30,
    ):
        """
        Initialize Novyx client.

        Args:
            api_key: Your Novyx API key (format: nram_tenant_signature)
            api_url: Base URL for the API (default: production)
            timeout: Request timeout in seconds
        """
        self.api_key = api_key
        self.api_url = api_url.rstrip("/")
        self.timeout = timeout
        self._validate_key()

    def _headers(self) -> Dict[str, str]:
        """Get request headers with auth."""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _validate_key(self) -> None:
        """Validate API key format."""
        if not self.api_key or not self.api_key.startswith("nram_"):
            raise NovyxAuthError("Invalid API key format. Expected: nram_<tenant>_<signature>")

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        json_data: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """Make an API request with error handling."""
        url = f"{self.api_url}{endpoint}"

        try:
            response = requests.request(
                method=method,
                url=url,
                headers=self._headers(),
                params=params,
                json=json_data,
                timeout=self.timeout,
            )

            # Handle specific error codes
            if response.status_code == 401:
                raise NovyxAuthError("Invalid API key or unauthorized")

            if response.status_code == 403:
                data = response.json() if response.text else {}
                error_msg = data.get("error", "Forbidden")
                code = data.get("code", "")

                # Check for upgrade required (tier limits)
                if "limit" in code or "upgrade" in error_msg.lower():
                    raise NovyxUpgradeRequired(error_msg, data)

                raise NovyxSecurityError(error_msg)

            if response.status_code == 429:
                data = response.json() if response.text else {}
                raise NovyxUpgradeRequired(
                    data.get("error", "Rate limit exceeded"),
                    data
                )

            response.raise_for_status()

            # Handle empty responses
            if response.status_code == 204 or not response.text:
                return {}

            return response.json()

        except requests.exceptions.Timeout:
            raise NovyxError(f"Request timed out after {self.timeout}s")
        except requests.exceptions.ConnectionError:
            raise NovyxError(f"Failed to connect to {self.api_url}")
        except requests.exceptions.RequestException as e:
            raise NovyxError(f"Request failed: {e}")

    def remember(
        self,
        content: str,
        tags: Optional[List[str]] = None,
        context: Optional[str] = None,
        importance: int = 5,
    ) -> Dict[str, Any]:
        """
        Store a memory.

        Args:
            content: The observation/memory to store
            tags: Optional list of tags for categorization
            context: Optional context string
            importance: Importance score 1-10 (default: 5)

        Returns:
            Dict with uuid, message, and conflict info

        Example:
            >>> result = nx.remember("User prefers async communication", tags=["prefs"])
            >>> print(result["uuid"])
        """
        return self._request(
            "POST",
            "/v1/memories",
            params={"conflict_strategy": "lww"},
            json_data={
                "observation": content,
                "tags": tags or [],
                "context": context,
                "importance": importance,
            },
        )

    def recall(
        self,
        query: str,
        limit: int = 5,
        tags: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Search memories semantically.

        Args:
            query: Natural language search query
            limit: Maximum results to return (default: 5)
            tags: Optional tag filter

        Returns:
            List of matching memories with scores

        Example:
            >>> memories = nx.recall("communication preferences")
            >>> for mem in memories:
            ...     print(f"{mem['observation']} (score: {mem['score']:.2f})")
        """
        params = {"q": query, "limit": limit}
        if tags:
            params["tags"] = ",".join(tags)

        result = self._request("GET", "/v1/memories/search", params=params)
        return result.get("memories", [])

    def act(
        self,
        action: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Execute a policy-checked action via Sentinel.

        Args:
            action: Action name (e.g., "send_email", "delete_file")
            params: Action parameters

        Returns:
            Dict with action status

        Raises:
            NovyxSecurityError: If action is blocked by policy

        Example:
            >>> result = nx.act("send_email", {"to": "user@example.com"})
        """
        # Note: This endpoint may not exist yet - placeholder for Sentinel integration
        return self._request(
            "POST",
            "/v1/actions",
            json_data={"action": action, "params": params or {}},
        )

    def rollback(
        self,
        target: str,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """
        Rollback memory to a point in time.

        Args:
            target: ISO 8601 timestamp (e.g., "2025-01-30T14:00:00Z")
            dry_run: If True, preview changes without applying

        Returns:
            Dict with rollback results (artifacts affected, restored, removed)

        Raises:
            NovyxUpgradeRequired: If rollback limit exceeded

        Example:
            >>> result = nx.rollback("2025-01-30T14:00:00Z")
            >>> print(f"Rolled back {result['artifacts_affected']} artifacts")
        """
        params = {
            "target_timestamp": target,
            "dry_run": str(dry_run).lower(),
        }

        return self._request(
            "POST",
            "/v1/memories/rollback",
            params=params,
        )

    def list_memories(
        self,
        limit: int = 100,
        offset: int = 0,
        tags: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        List all memories with pagination.

        Args:
            limit: Maximum results per page (default: 100)
            offset: Pagination offset
            tags: Optional tag filter

        Returns:
            Dict with memories list and total count
        """
        params = {"limit": limit, "offset": offset}
        if tags:
            params["tags"] = ",".join(tags)

        return self._request("GET", "/v1/memories", params=params)

    def get_memory(self, memory_id: str) -> Dict[str, Any]:
        """
        Get a specific memory by ID.

        Args:
            memory_id: The memory UUID

        Returns:
            Memory details
        """
        return self._request("GET", f"/v1/memories/{memory_id}")

    def delete_memory(self, memory_id: str) -> Dict[str, Any]:
        """
        Delete a specific memory.

        Args:
            memory_id: The memory UUID

        Returns:
            Deletion confirmation
        """
        return self._request("DELETE", f"/v1/memories/{memory_id}")

    def stats(self) -> Dict[str, Any]:
        """
        Get memory statistics for your account.

        Returns:
            Dict with total_memories, avg_importance, tag distribution, etc.
        """
        return self._request("GET", "/v1/memories/stats")

    def health(self) -> Dict[str, Any]:
        """
        Check API health status.

        Returns:
            Dict with status, version, timestamp
        """
        try:
            response = requests.get(
                f"{self.api_url}/health",
                timeout=self.timeout,
            )
            return response.json()
        except Exception as e:
            return {"status": "error", "error": str(e)}
