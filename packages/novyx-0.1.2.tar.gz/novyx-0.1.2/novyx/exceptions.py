"""
Novyx SDK Exceptions
"""


class NovyxError(Exception):
    """Base exception for all Novyx errors."""
    pass


class NovyxAuthError(NovyxError):
    """Authentication failed - invalid or expired API key."""
    pass


class NovyxSecurityError(NovyxError):
    """Security policy violation - action blocked by Sentinel."""
    pass


class NovyxUpgradeRequired(NovyxError):
    """
    Feature or limit requires upgrade.

    Raised when:
    - Memory limit exceeded
    - API call limit exceeded
    - Rollback limit exceeded
    - Rate limit hit

    Attributes:
        data: Dict with details (current, limit, tier, upgrade_url)
    """
    def __init__(self, message: str, data: dict = None):
        super().__init__(message)
        self.data = data or {}
        self.current = data.get("current") if data else None
        self.limit = data.get("limit") if data else None
        self.tier = data.get("tier") if data else None
        self.upgrade_url = data.get("upgrade_url", "https://novyxlabs.com/pricing") if data else "https://novyxlabs.com/pricing"
