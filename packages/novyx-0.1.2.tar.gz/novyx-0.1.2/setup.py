from setuptools import setup, find_packages
from pathlib import Path

# Read README for long description
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="novyx",
    version="0.1.2",
    description="Memory + security layer for AI agents. Persistent memory, semantic search, and Magic Rollback.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Novyx Labs",
    author_email="blake@novyxlabs.com",
    url="https://novyxlabs.com",
    project_urls={
        "Documentation": "https://novyxlabs.com/docs",
        "Source": "https://github.com/novyxlabs/novyx-core",
    },
    package_dir={"": "."},
    packages=find_packages("."),
    install_requires=[
        "requests>=2.28.0",
    ],
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords=["ai", "agents", "memory", "llm", "langchain", "semantic-search", "rollback"],
)
