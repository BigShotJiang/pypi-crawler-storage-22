"""
Novyx SDK Exceptions
"""


class NovyxError(Exception):
    """Base exception for all Novyx errors."""
    pass


class NovyxAuthError(NovyxError):
    """Authentication failed - invalid or expired API key."""
    pass


class NovyxForbiddenError(NovyxError):
    """
    Feature not available on current plan.

    Raised when trying to access Pro+ features on Free tier.

    Attributes:
        feature: Feature that requires upgrade
        tier_required: Minimum tier required
        upgrade_url: URL to upgrade plan
    """
    def __init__(self, message: str, data: dict = None):
        super().__init__(message)
        self.data = data or {}
        self.feature = data.get("feature")
        self.tier_required = data.get("tier_required", "pro")
        self.upgrade_url = data.get("upgrade_url", "https://novyxlabs.com/pricing")


class NovyxRateLimitError(NovyxError):
    """
    Rate limit exceeded.

    Raised when API call limit, rollback limit, or memory limit is exceeded.

    Attributes:
        limit_type: Type of limit exceeded (api_calls, rollbacks, memories)
        current: Current usage count
        limit: Maximum allowed
        tier: Current tier
        upgrade_url: URL to upgrade plan
        retry_after: Seconds until rate limit resets (if available)
    """
    def __init__(self, message: str, data: dict = None):
        super().__init__(message)
        self.data = data or {}
        self.limit_type = data.get("limit")
        self.current = data.get("current")
        self.limit = data.get("max") or data.get("limit")
        self.tier = data.get("tier")
        self.upgrade_url = data.get("upgrade_url", "https://novyxlabs.com/pricing")
        self.retry_after = data.get("retry_after")


class NovyxNotFoundError(NovyxError):
    """Resource not found (404)."""
    pass


class NovyxSecurityError(NovyxError):
    """Security policy violation - action blocked by Sentinel."""
    pass


# Legacy alias for backward compatibility
class NovyxUpgradeRequired(NovyxRateLimitError):
    """
    Feature or limit requires upgrade.

    Deprecated: Use NovyxRateLimitError or NovyxForbiddenError instead.
    Kept for backward compatibility.
    """
    pass
