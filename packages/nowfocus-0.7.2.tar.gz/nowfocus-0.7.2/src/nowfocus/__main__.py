import os
import subprocess, sys
import signal
import json
import time
from datetime import datetime, timezone, timedelta
import importlib
from importlib.metadata import version
from urllib.request import urlopen
import requests
import threading
import copy
from playsound3 import playsound
import setproctitle
import psutil
import argparse 
import traceback

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk, Gio

gi.require_version('Notify', '0.7')
from gi.repository import Notify as notify

try:
    gi.require_version('AyatanaAppIndicator3', '0.1')
    from gi.repository import AyatanaAppIndicator3 as appindicator
except Exception as e:
    gi.require_version('AppIndicator3', '0.1')
    from gi.repository import AppIndicator3 as appindicator 

# Set working dir to file location 
os.chdir(os.path.dirname(os.path.realpath(__file__)))

# Add working dir to path
sys.path.append(os.path.dirname(__file__))

# from . import conf # this works in module context but not running as pile-of-files 
import conf # this works running as pile-of-files but not in module context without sys.path.append 

from user_idle_time import UserIdleTime

import utils
from utils import *

from settings import SettingsWindow
from task_window import TaskWindow
from new_task_dialog import NewTaskWDialog
from session_options import SessionOptionsDialog 

dbg(conf.user,l=3,s='user_settings')

setproctitle.setproctitle(conf.app_name)

print(conf.app_name +" running from " + os.path.dirname(os.path.realpath(__file__)))

class Application(Gtk.Application):
    icon_tick_number = 0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, application_id="org.nowfocus.nowfocus", **kwargs)

        try:
            threading.excepthook = thread_excepthook
            
            self.is_running = False
            self.device_is_active = True
            self.user_last_inactive = now()
            self.user_last_active = now()
            self.UserIdleTime = UserIdleTime()
            dbg('self.UserIdleTime.platform', self.UserIdleTime.platform,s='user_away')
            self.last_user_idle_check_time = None
            self.session = default_session()

            self.menu = Gtk.Menu()
            self.menu_tasks = {}
            self.list_menus = {}

            self.indicator = appindicator.Indicator.new(conf.app_name, os.path.abspath('icon/icon-1.svg'), appindicator.IndicatorCategory.APPLICATION_STATUS)
            self.indicator.set_status(appindicator.IndicatorStatus.ACTIVE)
            self.indicator.set_menu(self.menu)

            if conf.is_first_load:
                import install
                install.run_first_load_actions()

            try:
                self.version = version(conf.app_id)
                print('nowfocus version', self.version)
            except Exception as e:
                dbg(e=e,l=0)

            if get_system_db_value('db_schema_version') != self.version:

                from upgrade import do_upgrades
                do_upgrades(self)


            self.async_refresh()

            # utils.db_cleanup()

            main_tick_timer = GLib.timeout_add_seconds(1, self.tick)

            self.resume_session_from_db()

            self.start_pipe()
            self.open_task_window()


            # Testing

            # Have an error
            # 1/0 
            # TODO: enable these automatically with dbg system
            # self.open_session_options_dialog('test_param')
            # self.open_settings_window(page_number=3) #for testing
            # self.open_new_task_dialog() #for testing
            # self.print_time_totals()
            # self.new_task_dialog()
            # error_dialog_inst = ErrorDialog(None,"test\n Test")
            # error_dialog_inst.show_all()

            signal.signal(signal.SIGINT, self.quit)
            signal.signal(signal.SIGUSR1, self.signal_handler)
            signal.signal(signal.SIGUSR2, self.signal_handler)

            Gtk.main()

        except Exception as e:

            dbg(notification='Total error happened', e=e, l=0)
            pass
            # print(conf.app_name +' had a pretty bad error. Please submit the following trace as an issue on the git repo or email it to the developers ')
            # print(e)
            # traceback.print_tb(e.__traceback__)
            # self.quit()


    def time_totals_report(self = None, widget = None, show_tasks = False, widget_to_add_label_to = None):
        ''' returns a string '''

        timeframe = hours_search_timeframes(conf.user['hours_search_timeframe'])
        prev_l = {}
        o = 'Time by project for '+conf.user['hours_search_timeframe']+ "\n\n"

        for l_id, l in lists_cache(reset=True).items():

            nested_list_count = l['extended_label'].count(' > ')

            if l['parent_id'] == None:

                o += "\n"
            else:
                nested_list_count = nested_list_count+1

            total_time = get_total_time(l_id,'lists',timeframe[0],timeframe[1])

            if total_time > 0:
                o += f'{" · " * nested_list_count}' + GLib.markup_escape_text(l['label']) +" "+str(sec_to_time(total_time)) +"\n"

            prev_l = l

            # print(o)
            # if show_tasks:
                # TODO: The Thing

        if widget_to_add_label_to:
            # print('time_totals_report got widget_to_add_label_to')
            widget_to_add_label_to.foreach(lambda child: child.destroy())
            label = Gtk.Label(o)
            label.set_halign(Gtk.Align.START)
            label.set_selectable(True)
            widget_to_add_label_to.add(label)
            label.show_all()
        else:
            return o


    def quit(self, widget_or_signal_source=None, condition=None):
        print("Adios ", conf.app_name)
        
        if self.is_running:
            dbg('Caching active session', self.session['label'])
            db_set_session_cache(self.session)

        try:
            os.remove(conf.pipe)
        except Exception as e:
            dbg("Error removing conf.pipe in quit",e=e)

        notify.uninit()
        Gtk.main_quit()
        exit()


    def get_seconds_since_user_active(self):
       
        if self.last_user_idle_check_time != now().replace(microsecond=0):
            self.last_user_idle_check_time = now().replace(microsecond=0)
            self.seconds_since_user_active = self.UserIdleTime.get()

        return self.seconds_since_user_active


    def toggle_do_not_disturb(self, widget=None):
        if 'do-not-disturb' in self.session:
            del self.session['do-not-disturb']
            self.do_not_disturb_menu_item.set_label("Enable Do Not Disturb")
            self.indicator.set_label("Do Not Disturb Disabled", "")

        else:
            self.session['do-not-disturb'] = True
            self.indicator.set_label("Do Not Disturb Enabled", "")
            self.do_not_disturb_menu_item.set_label("Disable Do Not Disturb")

        return True


    def tick(self):

        # check for suspend indicated by gap in tick intervals
        time_since_last_tick = round(time_difference(self.session['start_time']) - self.session['duration'])
        if time_since_last_tick > 10:

            dbg(time_since_last_tick, " seconds since last tick. Probably just woke from suspend. ")
            self.user_last_inactive = now()
            if self.is_running:
                self.open_task_window(None,{'user_inactive_time':time_since_last_tick})
            else:
                self.session['start_time'] = now()

        duration = self.session['duration'] = int(time_difference(self.session['start_time']))

        if num_is_multiple_of(duration,60):
            self.tock()

        if self.is_running == True:
            self.icon_tick_number += 1
            
            if self.icon_tick_number > 8:
                self.icon_tick_number = 1    

            label = self.session['label'] + ": " + sec_to_time(duration)

            icon = 'icon-'+str(self.icon_tick_number)+'.svg'

        else:

            label = conf.user['default_text'] +" "+ sec_to_time(duration)

            if duration > 60 and num_is_multiple_of(duration, 2):
                icon = 'icon-red.svg'
            else:
                icon = 'icon-1.svg'

        # https://lazka.github.io/pgi-docs/#AyatanaAppIndicator3-0.1/classes/Indicator.html#AyatanaAppIndicator3.Indicator.set_label

        if num_is_multiple_of(duration,5): # check every 5 seconds 
            if self.device_is_active == False:
                if self.get_seconds_since_user_active() < 60:
                    self.handle_device_became_active()

            if self.device_is_active:
                self.refresh_all_changed_todo_files()

            else:
                # TODO: increment a user away timer?
                dbg("User is still away")

        if self.device_is_active:
            self.indicator.set_icon_full(os.path.abspath('icon/'+icon),label)
            self.indicator.set_label(label,label)

        return True


    def tock(self):

        user_inactive_time = self.get_seconds_since_user_active()
        # print("user_inactive_time: "+str(user_inactive_time))

        dbg('Last todo todo_sync_time', conf.todo_sync_time, 'Time diff',int(time_difference(conf.todo_sync_time)),'Auto refresh interval * 60', (conf.user['todolist_refresh_interval'] * 60), s="todoloading", l=3 )

        if (int(time_difference(conf.todo_sync_time)) / 60) > conf.user['todolist_refresh_interval'] * 60:
            # TODO: use individual todo_refresh_times
            self.async_refresh()

        minutes = (int(self.session['duration']) / 60)
        
        if self.check_device_became_inactive():
            self.handle_device_became_inactive()
            return None
        
        elif self.device_is_active == False or 'do-not-disturb' in self.session:
            dbg("Do not disturb is on or device is inactive")
            return None

        self.pomodoro()

        if self.is_running:

            self.check_notify_session_target_reached(minutes)

        elif num_is_multiple_of(minutes,conf.user['randomness_interrupt_interval']):
                    
            notify.Notification.new("What Am I doing?","Your randomness timer is at "+str(minutes)+" minutes. ", None).show()

            self.open_task_window()
                
            playsound('sound/dinner-bell.mp3',False)


    def pomodoro(self):
        device_active_minutes = round(divide(time_difference(self.user_last_inactive),60))
        dbg("pomodoro check: device has been active for:", device_active_minutes,l=-1)

        if conf.user['pomodoro_interval'] == 0: 
            return False 

        if (device_active_minutes > conf.user['pomodoro_interval'] and conf.user['insistent_pomodoro']) or num_is_multiple_of(device_active_minutes, conf.user['pomodoro_interval']):
            notify.Notification.new("Time for a Break?","You've been going at it for "+str(device_active_minutes)+" minutes. ", None).show()

            playsound('sound/bell-xylophone-g.mp3',False)

            if conf.user['pomodoro_command']:
                subprocess.Popen(conf.user['pomodoro_command'], shell=True)


    def check_notify_session_target_reached(self,minutes):

        if 'target' in self.session:
            target = self.session['target']

            target['percent'] = round(( (target['minutes_tracked'] + minutes) / target['value'] ) * 100,1)

            print("At", target['percent'], "% of ", target['scope'],  " target")
            if round(target['minutes_tracked'] + minutes) == target['value']:
                reindex(t=self.session['task'])

                if target['type'] == 'min':

                    notify.Notification.new("Good job on doing "+self.session['label'],"You've reached your target of "+str(target['value'])+" minutes "+str(target['within_value'])+" "+ target['within_unit'], None).show()
                    
                    playsound('sound/xylophone-chord.mp3',False)

            if target['type'] == 'max':
                if target['percent'] >= 100:

                    notify.Notification.new("Time is up for this "+target['scope'],"You'r at "+str(round(target['percent']))+"% of your "+str(target['value'])+" minutes in the last "+str(target['within_value'])+" "+ target['within_unit'], None).show()

                    playsound('sound/dinner-bell.mp3',False)


    def check_device_became_inactive(self):
        if self.get_seconds_since_user_active() > (conf.user['device_not_in_use_threshold'] * 60):
            if self.device_is_active == True:
                return True

        return False


    def handle_device_became_inactive(self):

        dbg('device became inactive ',l=-1)
        self.device_is_active = False

        user_inactive_time = self.get_seconds_since_user_active()

        self.user_last_active = now() - timedelta(user_inactive_time)

        if self.is_running and 'do-not-disturb' not in self.session:

            self.open_task_window(None,{'user_inactive_time':user_inactive_time})

        else:
            self.session['duration'] = self.session['duration'] - user_inactive_time
            if self.session['duration'] > 60:
                utils.db_save_session(self.session) 

                self.session['duration'] = 0
                self.session['start_time'] = now()

                self.indicator.set_icon_full(os.path.abspath('icon/icon-0.svg'),"Device not in use")
                self.indicator.set_label("Device not in use","Device not in use")

                if 'do-not-disturb' not in self.session and conf.user['randomness_interrupt_interval'] > 0:
                    self.open_task_window(None)


    def handle_device_became_active(self):
        dbg('device became active!',l=-1)
        self.device_is_active = True
        self.user_last_inactive = now()
        self.user_last_active = now()

        if self.is_running == False:
            self.session['start_time'] = now()
            self.session['duration'] = 0


    def refresh_all_changed_todo_files(self):
        for id, todo_config in conf.user['todolists'].items():
            if todo_config['status'] and 'watch_file' in todo_config:
                self.refresh_todo_if_file_changed(todo_config)


    def refresh_todo_if_file_changed(self, todo_config):

        try:
            todo_m_time = round(os.stat(todo_config['file']).st_mtime)
               
            if todo_config['id'] not in conf.todo_file_change_times:
                conf.todo_file_change_times[todo_config['id']] = todo_m_time

            elif todo_m_time != conf.todo_file_change_times[todo_config['id']]:
                dbg(todo_config['id']+" file was changed!",s='todoloading')
                self.async_refresh(None,todo_config)
                conf.todo_file_change_times[todo_config['id']] = todo_m_time
        
        except Exception as e:
            # TODO: consider how to quietly handle errors when refresh is not prompted by the user and temporarily disabling  
            handle_todo_read_error(todo_config,e)


    def resume_session_from_db(self):
        try:
            s = get_session_from_system_db()
            if s:
                self.session = s
                self.is_running = True
                dbg("resuming session",s['label'],l=2, s='session')
        except Exception as e:
            dbg("Error resuming session",e=e ,l=1)


    def start_task(self, w = None, task_data_or_id = None, transfer_current_session_time = False):

        if isinstance(task_data_or_id, dict):
            task_data = task_data_or_id
        else:
            task_data = utils.db_get_item_by_id(task_data_or_id)

        task_label = task_data['label']
        dbg("starting "+ task_label,l=1)

        if transfer_current_session_time:
            start_time = self.session['start_time']
            duration = self.session['duration']

            if(self.is_running == True):
                self.stop_task(None,'cancel')

        else:
            start_time = now()
            duration = 0

            if(self.is_running == True):
                self.stop_task()
            elif(self.session['duration'] > 60):
                # Log randomness session (to internal db only) if longer than one minute
                utils.db_save_session(self.session)
  
        
        self.is_running = True
        
        s = {
            "label": task_label,
            "extended_label": utils.extended_label(task_data),
            "start_time": start_time,
            "duration":duration,
            "task":task_data,
            "notes":'',
        }

        if 'target' in task_data:
            s['target'] = task_data['target']
            
            dbg("session with list target started",s,s="targets",l=3)

        self.session = s       

        utils.db_set_session_cache(self.session)

        self.tick()

        self.task_running_menu_additions()

        self.menu.show_all()
        dbg("Starting",task_data['extended_label'],l=-1)

        if task_data['id'] in conf.user['task_commands']:
            command_data = conf.user['task_commands'][task_data['id']]
            if command_data['status']:
                thread = threading.Thread(target=self.run_task_command,args=(command_data['command'],))
                print("found task command:", command_data['command'])
                thread.start()


    def run_task_command(self,command):
        dbg("running task command:", command,l=-1)

        self.running_command_task_label = copy.copy(self.session['label'])

        # Check if already running 
        process = None
        for proc in psutil.process_iter():
            pinfo = proc.as_dict(attrs=['pid', 'name'])
            dbg("Check process", pinfo['name'], s='commands', l=3)
            if pinfo['name'] == command:
                process = proc
                break
            else:
                continue
                
        if process:
            dbg("waiting for already running command with psutils", command, s='commands')
            # subprocess.run('wmctrl', '-a', command) # Doesn't work on wayland
            process.wait()
        else:
            dbg("Launching command with subprocess.run", command, s='commands')
            subprocess.run(command,shell=True) 

        dbg("running task command complete:", command, s='commands')

        # stop timer on command completion if duration is more an 3 seconds and session is still the same task

        if self.session['duration'] > 3 and self.session['label'] == self.running_command_task_label:
            GLib.idle_add(self.stop_task)
            GLib.idle_add(self.open_task_window)


    def mark_done(self, w=None, task = None):
        ''' second (task) argument is required and must be a task object '''
        
        print("Mark Task done",task['label'])
        # print(task)

        todolist_conf = conf.user['todolists'][task['todolist']]

        try:

            done_thread = threading.Thread(target=conf.todo_connectors[todolist_conf['type']].mark_task_done, args=(task,) )

            conf.todo_sync_times[todolist_conf['id']] = now() # this is to avoid causing a refresh, perhaps not the best though
            
            done_thread.start()
            
            db_query("UPDATE tasks set status = '0' WHERE id = ? ",(task['id'],) )
            utils.reindex_one(task)

            self.menu_tasks[task['id']].destroy()

            playsound('sound/xylophone-chord.mp3',False)

        except Exception as e:
            dbg(notification="Marking "+ task['label']+" as done in "+todolist_conf['label']+" had a serious failure", e=e,l=0 )


    def stop_task(self, w = '', action = 'save', custom_end_time=None):
        ''' supported actions are save, cancel, mark_done '''

        list_menus = self.list_menus
        menu_tasks = self.menu_tasks
        session = self.session
        
        print("Stopping ", session['label'])
        task = session['task']
        if self.is_running == True:
            session['duration'] = time_difference(session['start_time'],custom_end_time)
            db_query("DELETE FROM system WHERE field = 'session' ")

            if action != 'cancel':

                # Get time tracker for this tasks todolist 
                todolist_conf = conf.user['todolists'][task['todolist']]
                
                if todolist_conf['timetracker']:

                    dbg("Save Session to "+ str(todolist_conf['timetracker']))
                    try:

                        timetracker_conf = conf.user['timetrackers'][todolist_conf['timetracker']]
                        save_thread = threading.Thread(target=conf.timetracker_connectors[timetracker_conf['type']].save_session, args=(session,timetracker_conf) )
                        save_thread.start()
                    except Exception as e:
                        dbg('Error Saving Time Data',notification="Recording timetracking for "+ task['label']+"  in "+timetracker_conf['label']+" had a serious failure",e=e, l=0 )

                session['timetracker'] = todolist_conf['timetracker']

                utils.db_save_session(session)

                if action == 'mark_done':
                    self.mark_done(None,task)

                else: 
                    # print("add ",utils.extended_label(task)," to recent tasks")
                    i = Gtk.MenuItem.new_with_label(utils.extended_label(task))
                    i.connect('activate',self.start_task,task)
                    try:
                        list_menus['recent'].prepend(i)
                        list_menus['recent'].get_children()[11].destroy()
                    except Exception as e:
                        dbg("Exception trying to rotate recent tasks. probably are less than 11",l=2,s="recent")

                    # Check de-hoist completed time targets
                    ballance = utils.get_time_target_ballance(task)
                    dbg('time target ballance:', ballance,l=2,s='time_targets')

                    if ballance != False and ballance < 0:
                        dbg('un-hoist completed time target',l=2,s='time_targets')
                        try:
                            self.menu.remove(menu_tasks[task['id']]) # how to check that this actually worked/ it was hoisted?
                            list_menus[task['parent_id']].append(menu_tasks[task['id']])
                        except Exception as e:
                            # Boo Hoo?
                            dbg('de-hoisting failed',e)
                        playsound('sound/xylophone-chord.mp3',False)

                    self.menu.show_all()

            self.is_running = False
            if action != 'cancel':
                notify.Notification.new("Focused on "+session['label']+" for "+sec_to_time(session['duration']),utils.pretty_dict(utils.get_times(task)), None).show()
        
            # Start randomness timer
            self.session = default_session()

            self.tick()

            # Rm stop task menu item
            self.menu.get_children()[0].destroy()
            self.menu.get_children()[0].destroy()
            self.do_not_disturb_menu_item.set_label("Do Not Disturb")


    def task_running_menu_additions(self):
        
        i = Gtk.ImageMenuItem.new_with_label("Edit Session")
        i.set_image(Gtk.Image.new_from_file(os.path.abspath('icon/edit.svg'))) 

        i.set_always_show_image(True) 
        i.connect("activate", self.open_session_options_dialog,'from_menu')
        self.menu.insert(i,0)    

        i = Gtk.ImageMenuItem.new_with_label("Pause" )
        i.set_image(Gtk.Image.new_from_file(os.path.abspath('icon/pause.svg'))) 

        i.set_always_show_image(True) 
        i.connect("activate", self.stop_task)
        self.menu.insert(i,0)


    def async_refresh(self, w=None, single_todo = None):

        self.indicator.set_label("Refreshing Todolists", "Refreshing Todolists")
        menu_item = Gtk.MenuItem.new_with_label("Refreshing Todolists")
        self.menu.append(menu_item) 
        self.menu.show_all()

        connectors_thread = threading.Thread(target=self.async_refresh_inner,args=(single_todo,))
        connectors_thread.start()


    def async_refresh_inner(self, single_todo = None):
        # dbg("async refresh started",s="todoloading",l=3)
        if single_todo:
            utils.refresh_todolist(single_todo)
            utils.reindex()

        else:
            utils.get_todolists()

        dbg("async refresh complete",s="todoloading",l=3)
        GLib.idle_add(self.update_menu)
        

    def update_menu(self, w = ''):
        menu = self.menu

        self.menu_tasks = {}
        self.list_menus = {}

        menu_tasks = self.menu_tasks
        list_menus = self.list_menus


        menu.foreach(lambda child: child.destroy()) 

        utils.add_todos_to_menu(menu, menu_tasks, list_menus, self.start_task)

        menu.append(Gtk.SeparatorMenuItem.new())

        # Recent Tasks Menu
        list_menus['recent'] = Gtk.Menu() # the sub_list that items get added to
        recents = Gtk.MenuItem.new_with_mnemonic("Recent Tasks") # the "item" that gets added 
        recents.set_submenu(list_menus['recent'])
        menu.append(recents)

        for id, t in utils.get_recent_tasks().items():
            # print('recent task',t)
            try:
                i = Gtk.MenuItem.new_with_label(utils.extended_label(t))
                i.connect('activate',self.start_task,t)
                list_menus['recent'].append(i)

            except Exception as e:
                pass
                # Because a key error if the task has was completed or todolist removed
                dbg('recent_tasks error', e=e)
        menu.append(Gtk.SeparatorMenuItem.new())


        # Todolist openables
        openables = []
        for id, todolist in conf.user['todolists'].items():
            if todolist['status']:
                openable = get_connector_openable(None, todolist,False)
                if openable not in openables:            
                    openables.append(openable)
                    
                    menu_aw = Gtk.MenuItem.new_with_label("Open "+todolist['label']+" ")
                    menu_aw.connect("activate", get_connector_openable, todolist)
                    menu.append(menu_aw)
            
        # Timetrackers
        for id, timetracker in conf.user['timetrackers'].items():
            if timetracker['status']:
                openable = get_connector_openable(None, timetracker,False)
                if openable not in openables:            
                    openables.append(openable)
                    menu_aw = Gtk.MenuItem.new_with_label("Open "+timetracker['label']+" ")
                    menu_aw.connect("activate", get_connector_openable, timetracker)
                    menu.append(menu_aw)

        # Update List
        # Lots of spaces to make menu wide-ish in preparation for opening wide sub menus 
        menu_update = Gtk.MenuItem.new_with_label("Refresh Lists                                                                    ")
        menu_update.connect("activate", self.async_refresh)
        menu.append(menu_update)

        setting_menu_item = Gtk.MenuItem.new_with_label("Settings")
        setting_menu_item.connect("activate",self.open_settings_window)
        menu.append(setting_menu_item)    
        
        task_window_menu_item = Gtk.MenuItem.new_with_label("Tasks")
        task_window_menu_item.connect("activate",self.open_task_window)
        menu.prepend(task_window_menu_item)
        self.indicator.set_secondary_activate_target(task_window_menu_item)


        new_task_menu_item = Gtk.MenuItem.new_with_label("New Task")
        new_task_menu_item.connect("activate",self.open_new_task_dialog)
        menu.append(new_task_menu_item)
        
        self.do_not_disturb_menu_item = Gtk.MenuItem.new_with_label("Do Not Disturb")
        if 'do-not-disturb' in self.session:
            self.do_not_disturb_menu_item.set_label("Disable Do Not Disturb")
        self.do_not_disturb_menu_item.connect("activate",self.toggle_do_not_disturb)
        menu.append(self.do_not_disturb_menu_item)
        
        quit_menu_item = Gtk.MenuItem.new_with_label("Quit")
        quit_menu_item.connect("activate",self.quit)
        menu.append(quit_menu_item)
        
        if self.is_running:
            self.task_running_menu_additions()

        menu.show_all()


    def open_session_options_dialog(self, w = None, params = None):

        if hasattr(self, 'session_options_dialog'):
            # print("present existing session_options_dialog",self.session_options_dialog)
            self.session_options_dialog.present()
        else:
            self.session_options_dialog = SessionOptionsDialog(self,params)
            self.session_options_dialog.show_all()


    def open_settings_window(self, w = None, page_number=0, **kwargs):

        if hasattr(self, 'settings_window'):
            self.settings_window.present()
        else:
            self.settings_window = SettingsWindow(self, page_number, **kwargs)
            self.settings_window.show_all()


    def open_task_window(self, w = None, data = None):
        self.taskwindow = TaskWindow(self, data)


    def open_new_task_dialog(self, w = None, passed_data = None):

        if hasattr(self, 'new_task_dialog'):
            self.new_task_dialog.present()
        else:
            self.new_task_dialog = NewTaskWDialog(self,passed_data)
            self.new_task_dialog.show_all()


    def signal_handler(self, sig, frame):
        dbg('Signal received',sig,s='signals')

        if sig == signal.SIGUSR1:
            self.open_task_window()
        elif sig == signal.SIGUSR2:
            self.open_session_options_dialog()
        else: 
            dbg("no handler for received signal",s='signals',l=3)


    def start_pipe(self):
        self.pipethread = threading.Thread(target=self.check_pipe)
        self.pipethread.daemon = True
        self.pipethread.start()


    def check_pipe(self):

        try:
            with open(conf.pipe, "r") as pipe:
                data = pipe.read().strip()

            print("check_pipe ")
            print(data)

            pipe.close()

            # TODO: add registry of special commands 
            # How to handle function arguments? (for example refresh a todolist with it's id)
            # if data in ['quit','open_task_window']:

            if data == 'quit':
                GLib.idle_add(self.quit)

            elif data == 'open_task_window':
                GLib.idle_add(self.open_task_window)            
                
            elif data == 'stop':
                GLib.idle_add(self.stop_task)


            else:
                search_results = utils.taskindex_search('"'+str(data)+'"')
                if len(search_results) > 0:
                    self.start_task(None, utils.first(search_results)['id'])
                
                else:
                    error_notice('Commandline Task failed','Could not find a task matching argument '+str(data))
         
        except FileNotFoundError as e:
            dbg(notification="Error starting pip listener, CLI will not work",e=e,l=0)

        # keep listening
        self.check_pipe()


def startup():
    # print("startup ",sys.argv)
    
    ''' if called with no arguments send shutdown to pipe, wait 2 seconds delete pipe file and launch application. if called with arguments send args to pipe if it exist otherwise ''' 

    parser = argparse.ArgumentParser(
                    # prog='ProgramName',
                    # description='What the program does',
                    # epilog='Text at the bottom of help'
                    )

    parser.add_argument('task',nargs='?')             # optional positional argument
    parser.add_argument('-s', '--debug_systems', nargs="*", default=[])      # option that takes a value
    parser.add_argument('-l', '--debug_level', default=1)       # option that takes a value
    parser.add_argument('-f', '--force', action='store_true', help="Force restart by deleting existing named pipe")  # on/off flag
    # parser.add_argument('-v', '--verbose', action='store_true')  # on/off flag

    args = parser.parse_args()
    dbg(args)

    conf.debug_level = int(args.debug_level)
    conf.debug_systems = args.debug_systems

    if args.force:
        print("Lanched with --force flag, forcibly deleting old pipe")
        try:
            os.remove(conf.pipe)
        except Exception as e:
            print(e)

    try:
        os.mkfifo(conf.pipe)
        dbg("Named pipe created successfully!", s="cli")

        signal.signal(signal.SIGUSR1, Application.signal_handler) 
        app = Application()

        if args.task:
            print("Writing args.task to pipe", args.task)
            with open(conf.pipe, "w") as pipeout:
                pipeout.write(args.task)
                pipeout.close()


    except FileExistsError:
        print("Named pipe exists, application must be running (or improperly shut down.) ")

        # if args: pass to pipe and exit
        if args.task:
            pipe_line = args.task
        else:
            #otherwise open task window
            pipe_line = "open_task_window"
        

        dbg("Writing arg to pipe ",pipe_line, s="cli")

        with open(conf.pipe, "w") as pipeout:
            pipeout.write(pipe_line)
            pipeout.close()

        exit()



    except Exception as e:
        dbg("Named pipe creation failed",e=e,l=0)


if __name__ == "__main__":
    startup()
    # print("called with garv",sys.argv)
    # signal.signal(signal.SIGUSR1, Application.signal_handler) # works
    # app = Application()



