<div align="center"><img src="https://www.nowfocus.org/android-chrome-192x192.png" width="60"  align="center">  

# <a href="https://www.nowfocus.org/">*Nowfocus*</a> <br> Open-source task timer for Linux  

**Avoid multifailing. Master your todo lists. Track your time.**

</div>

Nowfocus is a clean, keyboard-driven time management dashboard that flexibly connects multiple todo lists with multiple time trackers and displays your current task and time spent in the status bar. 

## Features

- Unlimited, flexible combinations of todo lists and time tracking apps
- Inactivity detection that automatically pauses time tracking 
- Task prioritization   
- Infinitely nestable lists  
- Pomodoro timer  
- Time targets: set a minimum or maximum time for any task or list of tasks and get reminded to follow-through  
- Randomness interrupt bell (optional) to keep you on track with tracking your time
- Keyboard-driven interface 
- Offline todo list cache 
- CLI interface
- Run a command (or launch an application) when a task is started
- Not built with Electron ♥
- Follows system dark-mode
- Lightening fast task search

<table><tr><td>
<a href="https://gitlab.com/GitFr33/nowfocus/-/raw/main/docs/darkmode.webp"><img src="https://gitlab.com/GitFr33/nowfocus/-/raw/main/docs/darkmode.webp" height="200"></a></td><td>
<a href="https://gitlab.com/GitFr33/nowfocus/-/raw/main/docs/Screenshot-25-09-23-11-42-56.webp"><img src="https://gitlab.com/GitFr33/nowfocus/-/raw/main/docs/Screenshot-25-09-23-11-42-56.webp" height="200"></a></td><td>
<a href="https://gitlab.com/GitFr33/nowfocus/-/raw/main/docs/Screenshot-25-09-23-11-46-14.webp"><img src="https://gitlab.com/GitFr33/nowfocus/-/raw/main/docs/Screenshot-25-09-23-11-46-14.webp" height="200"></a></td><td>
<a href="https://gitlab.com/GitFr33/nowfocus/-/raw/main/docs/Screenshot-25-09-23-11-53-22.webp"><img src="https://gitlab.com/GitFr33/nowfocus/-/raw/main/docs/Screenshot-25-09-23-11-53-22.webp" height="200"></a></td></tr></table>

<br>

### Currently Supported Todo List Backends

- [Trello](https://www.trello.com)
- [TaskWarrior](https://taskwarrior.org/)
- [todo.txt format](http://todotxt.org/)
- [Vikunja](https://www.vikunja.io)
- [Photosynthesis Timetracker](https://github.com/Photosynthesis/Timetracker/)  
- Simple text file with indentation-based sub-lists
- Any todo list that supports [CalDav todos](https://en.wikipedia.org/wiki/CalDAV) 



### Currently Supported Time Tracker Backends 
- CSV file  
- [ActivityWatch](https://www.activitywatch.net)      
- [Photosynthesis Timetracker](https://github.com/Photosynthesis/Timetracker/)  
- [TimeWarrior](https://timewarrior.net)


## Installation

<!-- # ubuntu 20.04 
note: gir1.2-appindicator3-0.1 can be substituted for gir1.2-ayatanaappindicator3-0.1 
    
sudo apt install pipx gir1.2-appindicator3-0.1 libgirepository1.0-dev gcc libcairo2-dev pkg-config python3-dev xprintidle 

make sure that your using python 3.12

sudo add-apt-repository ppa:deadsnakes/ppa -y

-->

1. Run the following in terminal:  
    ```
    # Install dependencies
    sudo apt install pipx gir1.2-ayatanaappindicator3-0.1 libgirepository1.0-dev gcc libcairo2-dev pkg-config python3-dev xprintidle 

    # Set up pipx (not necessary if you already use pipx)
    pipx ensurepath
    source ~/.bashrc 

    # Install
    pipx install nowfocus

    # and now Focus!
    nowfocus

    ```

2. Check for errors, if all looks good you can leave terminal running or quit Nowfocus with ` Ctrl + C ` on the terminal and launch Nowfocus from your app launcher menu.  

3. Set up a keybinding (on Ubuntu or Linux Mint), open **System Settings > Keyboard > Keyboard Shortcuts > Custom Shortcuts**, set the keystroke to ` Ctrl + Space ` (or the combination of your choice) set the **command** to:
    ```
    bash -c "echo 'open_task_window' > /tmp/nowfocus-pipe"
    ```
 
### Updating

1. Quit Nowfocus from the system tray menu
2. Run the following command in terminal: ``` pipx upgrade nowfocus ```
3. Start Nowfocus from app launcher


## Usage

#### Set up todo lists and time trackers:

Open **Nowfocus > Settings > Todo lists and Time Trackers** pick the type of backend you'd like to add from *Connect a new todo lists* menu click *go* and fill in the necessary fields.



#### Task Window Keybindings

- `F11` Toggle fullscreen
- `Esc` Close task window
- `Enter` Start top/selected task (or make a new task with current search phrase if no results)
- `Shift Enter` or `Shift Click` Transfer current session time to selected task (or top task if none selected)
- `Control Enter` or `Control Click` show options menu for selected (or top) task
- `Alt Enter` or `Alt Click` Open external todo list for selected (or top) task
- `Conrol + S` Pause and **save** current session
- `Conrol + D` Pause current session and mark task **Done**
- `Conrol + Q` **Quit** and discard current session
- `Ctrl + N` **New** task
- `Ctrl + R` **Refresh** todolists
- `Ctrl + L` or `Ctrl + F` **Focus** the task search



#### Time Targets


- From the task window use a tasks right click menu (`Ctrl + Enter`) click **Set Time Target**
- Choose between targeting a *maximum* and *minimum* amount of time for the task. 
    - Max: Task will be displayed as **done** and a reminder bell will ring one a minute once that amount of time has been spent on th task
    - Min: Task will be displayed as **priority 1** until the chosen amount of time has been spent on th task

- To set a target for a list of tasks open **Nowfocus > Settings > Time Targets** and *Add List Time Target*. List targets are timed recursively 


#### Task Commands
Task Commands can be used to run your chosen shell command when a task is started. Nowfocus will wait until the process completes (if it is a long running process) and stops timing the task and open when the command finishes. 

Warning: Task Commands are run with subprocess.run using `shell` option, so use at your own risk and please don't enter something stupid! (Also — it's not recommended for sensetive tasks like backups because if Nowfocus crashes the subprocess will be effected.)

To set up a command use **Nowfocus > Settings > Task Commands** or the task window right click menu for a task.



#### Commandline Interface

- To raise the task window use simply: `nowfocus`  
- If nowfocus has crashed or failed to shut down nicely use `nowfocus --force`
- To start timing a task: add the task name as the first positional argument. `nowfocus "checking email"` 
- To stop timing use `nowfocus stop`
- Start with verbose logging use: `nowfocus -l 3`
- Start with targeted verbose logging use: `nowfocus -s trello`


## Reporting Issues 
[Open an issue on Codeberg](https://codeberg.org/AltruistEnterprises/nowfocus/issues) (Please include as much detail as you can.)


## Development
[Fork **nowfocus** source code on Codeberg (GPL)](https://codeberg.org/AltruistEnterprises/nowfocus/issues)

### Install From Source
```
git clone https://codeberg.org/AltruistEnterprises/nowfocus.git
cd nowfocus
python3 -m venv .venv/nowfocus-build
source .venv/nowfocus-build/bin/activate
pip install -r build-requirements.txt
python3 -m build
pipx install -e --force YOUR_INSTALL_PATH
```
<!--built with python + GTK -->
