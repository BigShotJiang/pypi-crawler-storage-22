import os
import time
from datetime import datetime, timezone
import csv

import conf
import utils

def save_session(session,user_conf):
    ''' date,duration(minutes),project,task,start time, notes '''

    session['start_time'] = session['start_time'].astimezone()

    row = [session['start_time'].date(),str(round(utils.divide(session['duration'],60),2)),session['task']['parent_label'],session['label'],session['start_time'].strftime('%H:%M:%S'),session.get('notes','')]

    with open(user_conf['file'],'a') as f:
        writer = csv.writer(f)
        writer.writerow(row)
