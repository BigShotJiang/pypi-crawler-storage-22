import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gdk
from importlib.metadata import version
import conf
import utils

from utils import *


class ErrorDialog(Gtk.Dialog):

    def __init__(self, parent, error_details_str, system = ''):

        super().__init__(title=conf.app_name + " Error ", transient_for=parent, flags=0)
        self.error_details = str(error_details_str) 
        self.error_details += "\n Version: "+ str(version(conf.app_id)) 

        print("error dialog init")

        # self.app = parent.app
        self.set_default_size(600,400)

        self.set_border_width(15)

        dialog = self.get_content_area()

        dialog.set_spacing(15)

        intro_text = conf.app_name+" "+system+" has hit a bump in the road..."

        intro = Gtk.Label(intro_text)

        dialog.add(intro)

        box = Gtk.Box()
        error_label = Gtk.Label(self.error_details)
        error_label.set_selectable(True)
        box.add(error_label)

        scrolled_window = Gtk.ScrolledWindow()
        scrolled_window.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        # scrolled_window.set_size_request(-1, 350)

        scrolled_window.set_shadow_type(Gtk.ShadowType.ETCHED_IN)
        scrolled_window.add(box)
        
        dialog.pack_end(scrolled_window,1,1,True)

        # dialog.add(Gtk.Box(border_width=10)) #spacer

        self.add_button("Okay Whatever", 1)

        self.add_button("Send to developers", 2)

        self.set_default_response(2)

        self.show_all()
        self.connect("response", self.on_response,)

    def on_response(self, widget, response):
        if response == 2:

            import subprocess

            subprocess.Popen([
                "xdg-email",
                "--subject", conf.app_name+" Error Report",
                "--body", self.error_details ,
                conf.contact_email
            ])

        self.destroy()
