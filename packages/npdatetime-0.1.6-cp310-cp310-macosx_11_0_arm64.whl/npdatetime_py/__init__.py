from .npdatetime_py import *

__doc__ = npdatetime_py.__doc__
if hasattr(npdatetime_py, "__all__"):
    __all__ = npdatetime_py.__all__