from .npdatetime import *

__doc__ = npdatetime.__doc__
if hasattr(npdatetime, "__all__"):
    __all__ = npdatetime.__all__