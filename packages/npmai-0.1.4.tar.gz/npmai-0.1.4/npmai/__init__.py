__version__ = "0.1.3"
from .npmai import Ollama,Memory,Rag