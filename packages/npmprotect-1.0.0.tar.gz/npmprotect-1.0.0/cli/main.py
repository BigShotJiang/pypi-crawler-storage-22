import click
import httpx
import asyncio
import os
import hashlib
from datetime import datetime
from dotenv import load_dotenv
from supabase import create_client

load_dotenv()

# ─── CONFIG ───────────────────────────────────────────────────────────────────

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
VT_KEY       = os.getenv("VT_API_KEY1")

supabase = create_client(SUPABASE_URL, SUPABASE_KEY) if SUPABASE_URL and SUPABASE_KEY else None

# ─── HELPERS ──────────────────────────────────────────────────────────────────

def banner():
    click.echo(click.style("\n  🛡️  NpmProtect CLI", fg="red", bold=True) +
               click.style(" | Vynex Labs\n", fg="white"))

def success(msg): click.echo(click.style("  ✅ ", fg="green") + msg)
def warn(msg):    click.echo(click.style("  ⚠️  ", fg="yellow") + msg)
def error(msg):   click.echo(click.style("  ❌ ", fg="red") + msg)
def info(msg):    click.echo(click.style("  ℹ️  ", fg="blue") + msg)
def sep():        click.echo(click.style("  ─────────────────────────────────────────────", fg="red"))

def format_date(iso: str) -> str:
    try:
        return datetime.fromisoformat(iso).strftime("%d/%m/%Y %H:%M")
    except:
        return iso

def score_color(score: int, total: int) -> str:
    pct = score / total if total else 0
    if pct == 0:     return "green"
    if pct < 0.1:    return "yellow"
    return "red"

# ─── VERIFICAÇÃO REAL ─────────────────────────────────────────────────────────

async def check_npm_registry(package: str) -> dict:
    """Verifica se o pacote existe no npm e retorna metadados."""
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(f"https://registry.npmjs.org/{package}")
            if resp.status_code == 200:
                data = resp.json()
                latest = data.get("dist-tags", {}).get("latest", "?")
                version_data = data.get("versions", {}).get(latest, {})
                return {
                    "exists": True,
                    "name": data.get("name"),
                    "version": latest,
                    "description": data.get("description", "Sem descrição"),
                    "author": version_data.get("_npmUser", {}).get("name", "Desconhecido"),
                    "created": data.get("time", {}).get("created", ""),
                    "modified": data.get("time", {}).get("modified", ""),
                    "downloads_url": f"https://www.npmjs.com/package/{package}",
                }
            return {"exists": False}
    except Exception as e:
        return {"exists": False, "error": str(e)}

async def check_npm_downloads(package: str) -> int:
    """Retorna downloads semanais do pacote."""
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(f"https://api.npmjs.org/downloads/point/last-week/{package}")
            if resp.status_code == 200:
                return resp.json().get("downloads", 0)
    except:
        pass
    return 0

async def check_vt_package(package: str) -> dict | None:
    """Busca o pacote no VirusTotal por URL do npm."""
    if not VT_KEY:
        return None
    try:
        # Codifica a URL do pacote em base64 sem padding (padrão VT)
        import base64
        url = f"https://www.npmjs.com/package/{package}"
        url_id = base64.urlsafe_b64encode(url.encode()).rstrip(b"=").decode()

        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(
                f"https://www.virustotal.com/api/v3/urls/{url_id}",
                headers={"x-apikey": VT_KEY}
            )
            if resp.status_code == 200:
                stats = resp.json()["data"]["attributes"]["last_analysis_stats"]
                return {
                    "malicious":  stats.get("malicious", 0),
                    "suspicious": stats.get("suspicious", 0),
                    "harmless":   stats.get("harmless", 0),
                    "undetected": stats.get("undetected", 0),
                    "total": sum(stats.values()),
                }
    except:
        pass
    return None

async def check_typosquat(package: str) -> list[str]:
    """Detecta possíveis pacotes legítimos que o nome se parece."""
    # Lista de pacotes populares para comparar
    popular = [
        "express", "lodash", "react", "vue", "axios", "moment", "chalk",
        "webpack", "babel", "typescript", "eslint", "prettier", "jest",
        "mocha", "mongoose", "sequelize", "dotenv", "cors", "helmet",
        "socket.io", "next", "nuxt", "gatsby", "vite", "rollup",
        "nodemon", "pm2", "commander", "inquirer", "yargs", "uuid",
    ]
    suspects = []
    pkg = package.lower()
    for p in popular:
        if pkg != p and (
            pkg in p or p in pkg or
            _levenshtein(pkg, p) <= 2
        ):
            suspects.append(p)
    return suspects[:3]

def _levenshtein(a: str, b: str) -> int:
    if len(a) < len(b): a, b = b, a
    if not b: return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a):
        curr = [i + 1]
        for j, cb in enumerate(b):
            curr.append(min(prev[j+1]+1, curr[j]+1, prev[j]+(ca!=cb)))
        prev = curr
    return prev[-1]

# ─── CLI ──────────────────────────────────────────────────────────────────────

@click.group()
def cli():
    """🛡️  NpmProtect — Threat Intelligence para o ecossistema npm."""
    pass

# ── check ──

@cli.command()
@click.argument("package")
@click.option("--vt", is_flag=True, help="Incluir análise do VirusTotal")
def check(package, vt):
    """Verifica se um pacote npm é seguro.\n\n  Exemplo: npmprotect check lodahs\n  Exemplo: npmprotect check express --vt"""
    banner()
    info(f"Analisando: {click.style(package, bold=True, fg='white')}\n")

    async def run():
        # 1. npm registry
        click.echo(click.style("  [1/3] ", fg="red") + "Consultando npm registry...")
        npm = await check_npm_registry(package)

        if not npm["exists"]:
            click.echo()
            error(f"Pacote '{package}' NÃO encontrado no npm registry.")
            typos = await check_typosquat(package)
            if typos:
                click.echo()
                warn("Possível typosquatting! Você quis dizer:")
                for t in typos:
                    click.echo(click.style(f"    → {t}", fg="yellow"))
            click.echo()
            return

        # Exibe info do pacote
        click.echo()
        sep()
        click.echo(click.style("  PACOTE:      ", fg="red", bold=True) + npm["name"])
        click.echo(click.style("  VERSÃO:      ", fg="red", bold=True) + npm["version"])
        click.echo(click.style("  DESCRIÇÃO:   ", fg="red", bold=True) + npm["description"][:60])
        click.echo(click.style("  AUTOR:       ", fg="red", bold=True) + npm["author"])
        click.echo(click.style("  CRIADO:      ", fg="red", bold=True) + format_date(npm["created"]))
        click.echo(click.style("  MODIFICADO:  ", fg="red", bold=True) + format_date(npm["modified"]))

        # 2. Downloads
        click.echo()
        click.echo(click.style("  [2/3] ", fg="red") + "Verificando popularidade...")
        downloads = await check_npm_downloads(package)
        dl_color = "green" if downloads > 10000 else "yellow" if downloads > 100 else "red"
        click.echo(click.style("  DOWNLOADS:   ", fg="red", bold=True) +
                   click.style(f"{downloads:,} / semana", fg=dl_color, bold=True))
        if downloads < 100:
            warn("Poucos downloads — pacote pouco conhecido, atenção!")

        # 3. Typosquatting
        typos = await check_typosquat(package)
        if typos:
            click.echo()
            warn(f"Nome similar a pacotes populares: {', '.join(typos)}")
            warn("Verifique se não é um typosquat!")

        # 4. VirusTotal (opcional)
        sep()
        click.echo(click.style("  [3/3] ", fg="red") + "Verificando base NpmProtect...")

        db_resp = supabase.table("reports") \
            .select("hash, report_id, created_at") \
            .ilike("content", f"%{package}%") \
            .limit(3).execute() if supabase else None

        if db_resp and db_resp.data:
            click.echo()
            warn(f"{len(db_resp.data)} relatório(s) na base NpmProtect associado(s) a '{package}'!")
            for r in db_resp.data:
                click.echo(click.style(f"    • {r['hash'][:32]}...", fg="red") +
                           click.style(f"  [{format_date(r['created_at'])}]", fg="bright_black"))
        else:
            click.echo(click.style("  BASE:        ", fg="red", bold=True) +
                       click.style("Nenhuma ameaça registrada.", fg="green"))

        # VirusTotal
        if vt:
            click.echo()
            click.echo(click.style("  [VT] ", fg="red") + "Consultando VirusTotal...")
            vt_result = await check_vt_package(package)
            if vt_result:
                mal = vt_result["malicious"]
                sus = vt_result["suspicious"]
                tot = vt_result["total"]
                color = score_color(mal + sus, tot)
                click.echo(click.style("  VT SCORE:    ", fg="red", bold=True) +
                           click.style(f"{mal} malicioso(s) / {sus} suspeito(s) de {tot} engines", fg=color, bold=True))
                if mal > 0:
                    error("VirusTotal detectou engines marcando como MALICIOSO!")
                elif sus > 0:
                    warn("VirusTotal detectou engines marcando como suspeito.")
                else:
                    success("VirusTotal: limpo.")
            else:
                info("VirusTotal: sem dados ou VT_API_KEY1 não configurada.")

        sep()
        click.echo()

        # Veredicto final
        is_safe = downloads > 1000 and not (db_resp and db_resp.data) and not typos
        if is_safe:
            success(f"'{package}' parece seguro para uso.")
        else:
            warn(f"'{package}' tem pontos de atenção. Revise antes de instalar.")
        click.echo()

    asyncio.run(run())

# ── report ──

@cli.command()
@click.argument("hash_value")
def report(hash_value):
    """Busca o relatório completo de um hash SHA-256.\n\n  Exemplo: npmprotect report abc123..."""
    banner()
    info(f"Buscando relatório: {click.style(hash_value[:20] + '...', bold=True)}")

    if not supabase:
        error("Supabase não configurado. Verifique seu .env")
        return

    try:
        resp = supabase.table("reports").select("*").eq("hash", hash_value).limit(1).execute()
        if resp.data:
            r = resp.data[0]
            click.echo()
            sep()
            click.echo(click.style("  Hash:      ", fg="red", bold=True) + r["hash"])
            click.echo(click.style("  Report ID: ", fg="red", bold=True) + r["report_id"])
            click.echo(click.style("  Analista:  ", fg="red", bold=True) + r["analyst"])
            click.echo(click.style("  Data:      ", fg="red", bold=True) + format_date(r["created_at"]))
            sep()
            click.echo()
            for line in r["content"].split("\n")[:30]:
                click.echo("  " + line)
            if len(r["content"].split("\n")) > 30:
                click.echo()
                info("Relatório completo: https://npmprotect.vercel.app")
        else:
            warn("Nenhum relatório encontrado para esse hash.")
    except Exception as e:
        error(f"Erro: {e}")

# ── latest ──

@cli.command()
@click.option("--limit", default=10, help="Número de resultados (padrão: 10)")
def latest(limit):
    """Lista os últimos malwares detectados.\n\n  Exemplo: npmprotect latest --limit 5"""
    banner()
    info(f"Últimos {limit} malwares detectados:\n")

    if not supabase:
        error("Supabase não configurado. Verifique seu .env")
        return

    try:
        resp = supabase.table("reports").select("hash, report_id, created_at") \
            .order("created_at", desc=True).limit(limit).execute()
        if resp.data:
            for i, r in enumerate(resp.data, 1):
                click.echo(
                    click.style(f"  {i:02d}. ", fg="red", bold=True) +
                    click.style(r["hash"][:40] + "...", fg="white") +
                    click.style(f"  [{format_date(r['created_at'])}]", fg="bright_black")
                )
            click.echo()
            info("Dashboard: https://npmprotect.vercel.app")
        else:
            warn("Nenhum relatório encontrado.")
    except Exception as e:
        error(f"Erro: {e}")

# ── stats ──

@cli.command()
def stats():
    """Estatísticas gerais da base de inteligência."""
    banner()
    if not supabase:
        error("Supabase não configurado. Verifique seu .env")
        return
    try:
        resp = supabase.table("reports").select("created_at", count="exact").execute()
        total = resp.count or 0
        latest_resp = supabase.table("reports").select("created_at") \
            .order("created_at", desc=True).limit(1).execute()
        last_date = format_date(latest_resp.data[0]["created_at"]) if latest_resp.data else "N/A"
        sep()
        click.echo(click.style("  Total de relatórios: ", fg="white") + click.style(str(total), fg="red", bold=True))
        click.echo(click.style("  Última detecção:     ", fg="white") + last_date)
        click.echo(click.style("  Dashboard:           ", fg="white") + "https://npmprotect.vercel.app")
        click.echo(click.style("  Analista:            ", fg="white") + "Mozart_Dev · Vynex Labs")
        sep()
        click.echo()
    except Exception as e:
        error(f"Erro: {e}")

# ─── ENTRY POINT ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    cli()
