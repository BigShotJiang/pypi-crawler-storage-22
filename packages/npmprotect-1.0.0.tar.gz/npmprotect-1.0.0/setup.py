from setuptools import setup, find_packages

setup(
    name="npmprotect",
    version="1.0.0",
    description="🛡️ NpmProtect CLI — Threat Intelligence para o ecossistema npm",
    author="Mozart_Dev",
    url="https://github.com/mozartdev-0/NpmProtect",
    packages=find_packages(),
    install_requires=[
        "click",
        "httpx",
        "python-dotenv",
        "supabase",
    ],
    entry_points={
        "console_scripts": [
            "npmprotect=cli.main:cli",
        ],
    },
    python_requires=">=3.10",
)
