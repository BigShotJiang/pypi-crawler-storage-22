from setuptools import setup, find_packages

setup(
    name="npmprotect",
    version="1.1.0",
    packages=find_packages(),
    install_requires=["click", "httpx", "python-dotenv", "supabase"],
    entry_points={
        "console_scripts": [
            "npmprotect=cli.main:cli",
        ],
    },
    python_requires=">=3.10",
)
