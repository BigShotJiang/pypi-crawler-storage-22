from setuptools import setup

setup(
    name="npmprotect",
    version="1.1.3",
    py_modules=["main"],
    package_dir={"": "."},
    install_requires=["click", "httpx", "python-dotenv", "supabase"],
    entry_points={
        "console_scripts": [
            "np=main:cli",
        ],
    },
    python_requires=">=3.10",
)