# NPMS - Unified Data Science Package

A simple Python package that bundles pandas, numpy, matplotlib, and scikit-learn under one unified namespace.

## Installation
```bash
pip install npms
```

## Usage
```python
import npms as ns

# Pandas
df = ns.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})
print(df)

# Numpy
arr = ns.array([1, 2, 3, 4, 5])
print(ns.mean(arr))

# Matplotlib
ns.plot([1, 2, 3, 4], [1, 4, 9, 16])
xlabel = plt.xlabel
ylabel = plt.ylabel
title = plt.title
ns.xlabel('X')
ns.ylabel('Y')
ns.show()

# Scikit-learn
from npms import linear_model
model = linear_model.LinearRegression()
```

## Features

- Single import for all major data science libraries
- Simplified namespace (use `ns.` for everything)
- Automatically installs dependencies via pip (pandas, numpy, matplotlib, scikit-learn)
