import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sklearn

# Re-export everything under simple names
# Pandas
DataFrame = pd.DataFrame
Series = pd.Series
read_csv = pd.read_csv
read_excel = pd.read_excel

# Numpy
array = np.array
zeros = np.zeros
ones = np.ones
mean = np.mean
std = np.std

# Matplotlib
plot = plt.plot
figure = plt.figure
show = plt.show
scatter = plt.scatter
xlabel = plt.xlabel
ylabel = plt.ylabel
title = plt.title


# Sklearn - you can expose specific modules
from sklearn import linear_model, tree, ensemble, metrics

__version__ = "0.1.3"