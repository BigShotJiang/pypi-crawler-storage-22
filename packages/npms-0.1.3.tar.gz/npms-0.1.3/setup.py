from setuptools import setup, find_packages

setup(
    name="npms",
    version="0.1.3",
    author="Toki Tahmid Toufa",
    author_email="toufa6.2832@gmail.com",
    description="A simple Python package that bundles pandas, numpy, matplotlib, and scikit-learn under one unified namespace.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "matplotlib",
        "numpy",
        "scikit-learn",
    ],
    python_requires=">=3.8",
)
