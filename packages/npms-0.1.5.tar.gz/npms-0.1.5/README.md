# npms 📦

[![PyPI version](https://badge.fury.io/py/npms.svg)](https://pypi.org/project/npms/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey.svg)](https://pypi.org/project/npms/)

Unified Python package for data science — **pandas, numpy, matplotlib, and scikit-learn** under one single import.

---

## Install

```bash
pip install npms
```

---

## Usage

```python
import npms as ns

# Pandas
df = ns.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})
print(df)

# NumPy
arr = ns.array([1, 2, 3, 4, 5])
print(ns.mean(arr))

# Matplotlib
ns.plot([1, 2, 3], [1, 4, 9])
ns.xlabel('X')
ns.ylabel('Y')
ns.show()

# Scikit-learn
from npms import linear_model
model = linear_model.LinearRegression()
```

---

## What's included

| Library | Purpose |
|---|---|
| [pandas](https://pandas.pydata.org/) | Data manipulation and analysis |
| [numpy](https://numpy.org/) | Numerical computing |
| [matplotlib](https://matplotlib.org/) | Data visualization |
| [scikit-learn](https://scikit-learn.org/) | Machine learning |

---

## Features

- ✅ Single import for all major data science libraries
- ✅ Simplified namespace — use `ns.` for everything
- ✅ Auto-installs all dependencies
- ✅ Works on Windows, macOS, Linux

---

## License

[MIT](LICENSE) © 2026 tokitahmidtoufa
