"""
npms - Unified Python package for data science.

pandas, numpy, matplotlib, and scikit-learn under one import.

Usage:
    import npms as ns
    df = ns.DataFrame({'A': [1, 2, 3]})
"""

import pandas as _pd
import numpy as _np
import matplotlib.pyplot as _plt
import sklearn as _sklearn
from sklearn import linear_model, tree, ensemble, metrics

# ── Pandas ──────────────────────────────
DataFrame   = _pd.DataFrame
Series      = _pd.Series
read_csv    = _pd.read_csv
read_excel  = _pd.read_excel
concat      = _pd.concat
merge       = _pd.merge
groupby     = _pd.DataFrame.groupby

# ── NumPy ───────────────────────────────
array       = _np.array
mean        = _np.mean
std         = _np.std
sum         = _np.sum
min         = _np.min
max         = _np.max
zeros       = _np.zeros
ones        = _np.ones
linspace    = _np.linspace
arange      = _np.arange
dot         = _np.dot
reshape     = _np.reshape
linalg      = _np.linalg
random      = _np.random

# ── Matplotlib ──────────────────────────
plot        = _plt.plot
show        = _plt.show
xlabel      = _plt.xlabel
ylabel      = _plt.ylabel
title       = _plt.title
figure      = _plt.figure
subplot     = _plt.subplot
subplots    = _plt.subplots
legend      = _plt.legend
savefig     = _plt.savefig
close       = _plt.close
bar         = _plt.bar
hist        = _plt.hist
scatter     = _plt.scatter
pie         = _plt.pie
xlim        = _plt.xlim
ylim        = _plt.ylim
grid        = _plt.grid
xticks      = _plt.xticks
yticks      = _plt.yticks

__version__ = "0.1.5"
