from oarepo_runtime.resources.resource import BaseRecordResource


class DataResource(BaseRecordResource):
    """DataRecord resource."""

    # here you can for example redefine
    # create_url_rules function to add your own rules
