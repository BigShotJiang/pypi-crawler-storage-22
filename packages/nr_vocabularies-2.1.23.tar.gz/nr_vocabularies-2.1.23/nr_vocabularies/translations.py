# just for translations


def _(x):
    return x


translations = [
    _("vocabulary.access-rights"),
    _("vocabulary.contributor-roles"),
    _("vocabulary.countries"),
    _("vocabulary.funders"),
    _("vocabulary.institutions"),
    _("vocabulary.item-relation-types"),
    _("vocabulary.languages"),
    _("vocabulary.licenses"),
    _("vocabulary.resource-types"),
    _("vocabulary.subject-categories"),
    _("vocabulary.relatedURI_COAR"),
    _("vocabulary.marcCode"),
    _("vocabulary.dataCiteCode"),
    _("vocabulary.alpha3Code"),
    _("vocabulary.nonpreferredLabels_en"),
    _("vocabulary.acronym"),
    _("vocabulary.relatedURI_CrossrefFunderID"),
    _("vocabulary.relatedURI_ROR"),
    _("vocabulary.contexts"),
    _("vocabulary.tags"),
    _("vocabulary.RID"),
    _("vocabulary.ICO"),
    _("vocabulary.relatedURI_URL"),
    _("vocabulary.nameType"),
    _("vocabulary.nonpreferredLabels_cs"),
    _("vocabulary.pair"),
    _("vocabulary.hint_en"),
    _("vocabulary.hint_cs"),
    _("vocabulary.alpha3CodeENG"),
    _("vocabulary.alpha3CodeNative"),
    _("vocabulary.icon"),
    _("vocabulary.coarType"),
    _("vocabulary.dataCiteType"),
]
