from erad.systems.hazard_system import HazardSystem
from erad.systems.asset_system import AssetSystem
