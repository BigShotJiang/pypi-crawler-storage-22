# Get groups using kmeans


```{eval-rst}
.. autofunction:: shift.get_kmeans_clusters
```