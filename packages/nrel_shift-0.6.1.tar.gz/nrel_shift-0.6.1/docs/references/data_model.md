# Model

```{eval-rst}
.. autoclass:: shift.GeoLocation
    :members: 

```


```{eval-rst}
.. autopydantic_model:: shift.ParcelModel
    :members: 

```


```{eval-rst}
.. autopydantic_model:: shift.GroupModel
    :members: 

```