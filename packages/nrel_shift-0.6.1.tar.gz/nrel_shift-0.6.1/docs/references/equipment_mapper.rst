
=================
Equipment Mappers
=================

.. autoclass:: shift.BaseEquipmentMapper
    :members: