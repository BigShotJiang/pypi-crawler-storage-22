# Get mesh network

```{eval-rst}
.. autofunction:: shift.get_mesh_network
```