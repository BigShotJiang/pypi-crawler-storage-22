# Get nearest points

```{eval-rst}
.. autofunction:: shift.get_nearest_points
```