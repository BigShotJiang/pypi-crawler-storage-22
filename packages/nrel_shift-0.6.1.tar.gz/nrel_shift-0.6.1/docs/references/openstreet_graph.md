# OpenStreetGraphBuilder


```{eval-rst}
.. currentmodule:: shift
.. autoclass:: OpenStreetGraphBuilder
```

## Methods

```{eval-rst}
.. autosummary::

   OpenStreetGraphBuilder.__init__
   OpenStreetGraphBuilder.get_distribution_graph
```
