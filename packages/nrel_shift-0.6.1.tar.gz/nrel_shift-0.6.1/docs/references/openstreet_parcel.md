# Openstreet Parcel


```{eval-rst}
.. autofunction:: shift.parcels_from_geodataframe
```

