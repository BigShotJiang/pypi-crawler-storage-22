# Openstreet Roads


```{eval-rst}
.. autofunction:: shift.get_road_network
```

