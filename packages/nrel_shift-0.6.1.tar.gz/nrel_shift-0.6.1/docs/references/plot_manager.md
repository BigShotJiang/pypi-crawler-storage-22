# Plot Manager


```{eval-rst}
.. currentmodule:: shift
.. autoclass:: PlotManager
```

## Methods

```{eval-rst}
.. autosummary::

   PlotManager.__init__
   PlotManager.add_plot
   PlotManager.show
```
