# Adding data to plots


## Adding Parcels to Plots
```{eval-rst}
.. autofunction:: shift.add_parcels_to_plot
```

# Adding Network to Plots

```{eval-rst}
.. autofunction:: shift.add_xy_network_to_plot
```