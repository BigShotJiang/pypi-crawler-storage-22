# Polygon from points

```{eval-rst}
.. autofunction:: shift.get_polygon_from_points
```