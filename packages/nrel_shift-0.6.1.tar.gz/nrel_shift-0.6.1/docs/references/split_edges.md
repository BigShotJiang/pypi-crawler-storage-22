# Splitting edges

```{eval-rst}
.. autofunction:: shift.split_network_edges
```