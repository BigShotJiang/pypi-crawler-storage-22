"""Enhancement perturber implementations."""
