"""Noise perturber implementations."""
