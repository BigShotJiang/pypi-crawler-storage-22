class DTOAuditavel:

    @classmethod
    def get_params_normalizados(
        cls, body, query_args=None, path_args=None
    ) -> list | dict:
        return {}
