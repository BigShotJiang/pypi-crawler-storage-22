import logging
import os

APP_NAME = os.getenv("APP_NAME", "nsj_audit_lib")


def get_logger():
    return logging.getLogger(APP_NAME)


DATABASE_NAME = os.getenv("DATABASE_NAME", "")
DATABASE_USER = os.getenv("DATABASE_USER", "")
DATABASE_DRIVER = os.getenv("DATABASE_DRIVER", "POSTGRES")

AUDIT_REDIS_URL = os.getenv("AUDIT_REDIS_URL")
AUDIT_STREAM_KEY = os.getenv("AUDIT_STREAM_KEY", "audit:requests")
AUDIT_OUTBOX_TRANSACTION = (
    os.getenv("AUDIT_OUTBOX_TRANSACTION", "true").lower() == "true"
)
