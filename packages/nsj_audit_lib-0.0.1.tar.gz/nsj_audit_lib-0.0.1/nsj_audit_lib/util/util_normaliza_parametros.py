from nsj_audit_lib.dto.dto_auditavel import DTOAuditavel


def _normalize_query_args(query_args):
    if query_args is None:
        return {}
    if hasattr(query_args, "to_dict"):
        return query_args.to_dict(flat=True)
    return dict(query_args)


def get_params_normalizados(
    query_args, body, dto_class: type[DTOAuditavel] | None, path_args=None
):
    """
    Normaliza os parâmetros da requisição para auditoria.

    - query_args: parâmetros da query string.
    - body: corpo da requisição (dict ou lista de dicts).
    - dto_class: DTO associado à rota, usado para selecionar campos resumo.
    - path_args: argumentos da rota (kwargs).
    """
    normalized_query_args = _normalize_query_args(query_args)

    if dto_class is None or body is None or body == {}:
        normalized_body = {}
    else:
        normalized_body = dto_class.get_params_normalizados(body, query_args, path_args)

    return {
        "query_args": normalized_query_args,
        "body": normalized_body,
        "path_args": path_args or {},
    }
