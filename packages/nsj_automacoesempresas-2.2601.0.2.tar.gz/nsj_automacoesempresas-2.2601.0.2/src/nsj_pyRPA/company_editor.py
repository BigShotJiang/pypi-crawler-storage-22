"""
Company settings dialog used by the Qt front-end.
It receives DTO data from the service layer and simply returns user edits so
controllers can persist them via the shared business services.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, List, Optional

from PyQt5.QtCore import Qt, QTime, QPoint
from PyQt5.QtGui import QColor, QFont, QFontMetrics, QIcon, QPainter, QPixmap, QPolygon
from PyQt5.QtWidgets import (
    QAction,
    QAbstractSpinBox,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QGridLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QScrollArea,
    QSpinBox,
    QTabWidget,
    QTimeEdit,
    QToolBar,
    QToolButton,
    QVBoxLayout,
    QWidget,
    QSizePolicy,
    QStyle,
    QProxyStyle,
    QStyleOption,
)

from nsj_pyRPA.dto.company_dto import CompanyDTO, CompanySettingsDTO, ScheduleConfig
from nsj_pyRPA.dto.notification_team_dto import NotificationTeamDTO
from nsj_pyRPA.resources.automation_types import (
    AUTOMATION_TYPES,
    automation_default_values,
    automation_type_label
)

ICON_PATH = Path(__file__).resolve().parent / "resources" / "Persona.ico"

MDL2_GLYPHS = {
    "save": "\uE74E",
    "cancel": "\uE711",
    "exit": "\uF3B1",
    "members": "\uE72D",
    "clear": "\uE711",
}


def persona_icon() -> QIcon:
    if not ICON_PATH.exists():
        return QIcon()
    return QIcon(str(ICON_PATH))


def mdl2_icon(glyph: str, color: QColor) -> QIcon:
    font = QFont("Segoe MDL2 Assets")
    font.setPixelSize(16)
    metrics = QFontMetrics(font)
    size = max(metrics.height(), 16) + 6
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    painter.setFont(font)
    painter.setPen(color)
    painter.drawText(pixmap.rect(), Qt.AlignCenter, glyph)
    painter.end()
    return QIcon(pixmap)



class SpinArrowStyle(QProxyStyle):
    def drawPrimitive(self, element, option: QStyleOption, painter, widget=None):
        if element in (QStyle.PE_IndicatorSpinUp, QStyle.PE_IndicatorSpinDown):
            painter.save()
            painter.setRenderHint(QPainter.Antialiasing, True)
            rect = option.rect.adjusted(2, 2, -2, -2)
            cx = rect.center().x()
            cy = rect.center().y()
            color = QColor("#4a4a4a") if option.state & QStyle.State_Enabled else QColor("#8a8a8a")
            painter.setPen(Qt.NoPen)
            painter.setBrush(color)
            if element == QStyle.PE_IndicatorSpinUp:
                points = [QPoint(cx - 4, cy + 2), QPoint(cx + 4, cy + 2), QPoint(cx, cy - 3)]
            else:
                points = [QPoint(cx - 4, cy - 2), QPoint(cx + 4, cy - 2), QPoint(cx, cy + 3)]
            painter.drawPolygon(QPolygon(points))
            painter.restore()
            return
        super().drawPrimitive(element, option, painter, widget)

@dataclass
class SectionDefinition:
    label: str
    automation_type: str


@dataclass
class SectionWidgets:
    group: QGroupBox
    enabled: QCheckBox
    frequency: QComboBox
    day_month: Optional[QSpinBox]
    day_month_row: Optional[QWidget]
    day_week: Optional[QComboBox]
    day_week_row: Optional[QWidget]
    time: QTimeEdit
    time_row: QWidget
    summary: QLabel
    allowed_frequencies: List[str]


class RoundedComboBox(QComboBox):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setEditable(False)
        self.setFrame(False)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        rect = self.rect().adjusted(0, 0, -1, -1)
        border = QColor("#b9bcc2")
        bg = QColor("#ffffff") if self.isEnabled() else QColor("#f0f0f0")
        painter.setBrush(bg)
        painter.setPen(border)
        painter.drawRoundedRect(rect, 4, 4)

        arrow_w = 18
        sep_x = rect.right() - arrow_w
        painter.setPen(QColor("#c7c9ce"))
        painter.drawLine(sep_x, rect.top() + 2, sep_x, rect.bottom() - 2)

        text_rect = rect.adjusted(6, 0, -(arrow_w + 4), 0)
        painter.setPen(QColor("#1e1e1e") if self.isEnabled() else QColor("#6e6e6e"))
        painter.drawText(text_rect, Qt.AlignVCenter | Qt.AlignLeft, self.currentText())

        arrow_rect = rect.adjusted(rect.width() - arrow_w, 0, 0, 0)
        arrow_color = QColor("#4a4a4a") if self.isEnabled() else QColor("#8a8a8a")
        painter.setBrush(arrow_color)
        painter.setPen(Qt.NoPen)
        cx = arrow_rect.center().x()
        cy = arrow_rect.center().y()
        triangle = QPolygon([QPoint(cx - 4, cy - 2), QPoint(cx + 4, cy - 2), QPoint(cx, cy + 3)])
        painter.drawPolygon(triangle)
        painter.end()


class CompanyEditorDialog(QDialog):
    def __init__(
        self,
        company: CompanyDTO,
        settings: CompanySettingsDTO,
        assigned_team: Optional[NotificationTeamDTO] = None,
        available_teams: Optional[List[NotificationTeamDTO]] = None,
        parent=None,
    ):
        super().__init__(parent)
        self.setWindowIcon(persona_icon())
        self.company = company
        self.company_ref = company.automacaoempresa
        self.settings = settings
        self.updated_settings: Optional[CompanySettingsDTO] = None
        self.updated_use_default: bool = company.use_default
        self.updated_notified_teams: str = company.notified_teams
        self.updated_team_id: Optional[str] = assigned_team.equipe_id if assigned_team else None
        self.selected_team: Optional[NotificationTeamDTO] = assigned_team
        self._available_teams: List[NotificationTeamDTO] = sorted(
            available_teams or [],
            key=lambda dto: (dto.codigo or "").lower(),
        )
        self.combo_days = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"]
        self.combo_frequency = ["Mensalmente", "Semanalmente", "Diariamente"]
        self.section_list = AUTOMATION_TYPES
        self.section_defs = list()
        for i in self.section_list: 
            self.section_defs.append(SectionDefinition(automation_type_label(i), i))
        self.sections: Dict[str, SectionWidgets] = {}
        self.setWindowTitle(f"Editar Empresa - {company.nome}")
        self.resize(1200, 500)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        toolbar = QToolBar("Ações", self)
        toolbar.setMovable(False)
        toolbar.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        toolbar.setIconSize(toolbar.iconSize())

        def add_action(text: str, glyph_key: str, fallback: QStyle.StandardPixmap, handler):
            glyph = MDL2_GLYPHS.get(glyph_key, "")
            icon = mdl2_icon(glyph, QColor("#1e1e1e")) if glyph else QIcon()
            if icon.isNull():
                icon = self.style().standardIcon(fallback)
            act = QAction(icon, text, self)
            act.triggered.connect(handler)
            toolbar.addAction(act)
            button = toolbar.widgetForAction(act)
            if button:
                button.setToolTip("")

        add_action("Gravar", "save", QStyle.SP_DialogApplyButton, self._handle_save)
        add_action("Cancelar", "cancel", QStyle.SP_DialogCancelButton, self.reject)
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        toolbar.addWidget(spacer)
        add_action("Sair", "exit", QStyle.SP_DialogCloseButton, self.close)
        layout.addWidget(toolbar)

        info = QLabel("Itens e periodicidade (marcados = automatizados; desmarcados = execução manual)")
        info.setStyleSheet("padding: 6px 10px; font-weight: 600; color: #4c4c4c;")
        layout.addWidget(info)

        tabs = QTabWidget(self)
        tabs.setTabPosition(QTabWidget.South)
        tabs.setStyleSheet(
            """
            QTabBar::tab {
                background: #e0e0e0;
                border: 1px solid #b9bcc2;
                padding: 4px 10px;
                margin: 0 2px;
                min-width: 120px;
            }
            QTabBar::tab:selected {
                background: #ffffff;
                color: #1e1e1e;
            }
            QTabWidget::pane {
                border-top: 1px solid #7f7f7f;
            }
            """
        )
        tabs.addTab(self._build_schedule_tab(), "Cálculo Folhas")
        tabs.addTab(self._placeholder_tab("Demais cálculos em desenvolvimento"), "Demais Cálculos")
        tabs.addTab(self._placeholder_tab("Configurações do E-social em desenvolvimento"), "E-social")

        layout.addWidget(tabs)

        self.setStyleSheet(
            """
            QWidget {
                background: #e6e6e6;
                color: #1e1e1e;
                font-family: Tahoma, Arial, sans-serif;
                font-size: 13px;
            }
            QToolBar {
                background: #e6e6e6;
                border: none;
                border-bottom: 1px solid #b9b9b9;
                padding: 4px 8px;
                spacing: 8px;
            }
            QGroupBox {
                background: #e9e9e9;
                border: 1px solid #bcbec4;
                margin-top: 16px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                subcontrol-position: top left;
                padding: 2px 6px;
                background: #dfe0e2;
                color: #3a3a3a;
                font-weight: 600;
            }
            QLineEdit, QComboBox, QSpinBox, QTimeEdit {
                background: #ffffff;
                border: 1px solid #b9bcc2;
                border-radius: 4px;
                padding: 1px 4px;
                min-height: 18px;
            }
            QLineEdit:disabled, QComboBox:disabled, QSpinBox:disabled, QTimeEdit:disabled {
                background: #f0f0f0;
                color: #6e6e6e;
            }
            QComboBox::drop-down {
                subcontrol-origin: padding;
                subcontrol-position: top right;
                width: 18px;
                border-left: 1px solid #c7c9ce;
                background: #f3f3f3;
                border-top-right-radius: 4px;
                border-bottom-right-radius: 4px;
            }
            QComboBox::drop-down:hover {
                background: #e9e9e9;
            }
            QSpinBox::up-button, QSpinBox::down-button,
            QTimeEdit::up-button, QTimeEdit::down-button {
                width: 16px;
                border-left: 1px solid #c7c9ce;
                background: #f3f3f3;
            }
            QSpinBox::up-button, QTimeEdit::up-button {
                subcontrol-position: top right;
                border-top-right-radius: 4px;
            }
            QSpinBox::down-button, QTimeEdit::down-button {
                subcontrol-position: bottom right;
                border-bottom-right-radius: 4px;
            }
            QSpinBox::up-button:hover, QSpinBox::down-button:hover,
            QTimeEdit::up-button:hover, QTimeEdit::down-button:hover {
                background: #e9e9e9;
            }
            QToolButton, QPushButton {
                background: #f2f2f2;
                border: 1px solid #b9bcc2;
                border-radius: 4px;
                padding: 4px 10px;
            }
            QToolButton:hover, QPushButton:hover {
                background: #e7e7e7;
            }
            QToolButton:pressed, QPushButton:pressed {
                background: #dcdcdc;
            }
            """
        )

    def _build_schedule_tab(self) -> QWidget:
        container = QWidget(self)
        layout = QVBoxLayout(container)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)

        header_row = QHBoxLayout()
        header_row.addWidget(self._build_default_section(), 1)
        header_row.addWidget(self._build_notifications_section(), 1)
        layout.addLayout(header_row)

        sections_grid = QGridLayout()
        sections_grid.setSpacing(6)
        sections_grid.setColumnStretch(0, 1)
        sections_grid.setColumnStretch(1, 1)
        sections_grid.setContentsMargins(0, 0, 0, 0)
        for idx, definition in enumerate(self.section_defs):
            section_widget = self._build_schedule_section(definition)
            sections_grid.addWidget(section_widget, idx // 2, idx % 2)
        layout.addLayout(sections_grid)
        layout.addStretch()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(container)
        return scroll

    def _open_team_selector(self):
        if not self._available_teams:
            QMessageBox.information(
                self,
                "Destinatários notificados",
                "Nenhum grupo de destinatários cadastrado. Cadastre destinatários antes de vinculá-los.",
            )
            return
        dialog = NotificationTeamSelectorDialog(
            self._available_teams,
            self.selected_team,
            self,
        )
        if dialog.exec() == QDialog.Accepted and dialog.selected_team:
            self._set_selected_team(dialog.selected_team)

    def _selected_team_label(self) -> str:
        if not self.selected_team:
            return ""
        base = f"{self.selected_team.codigo} - {self.selected_team.nome}"
        if self.selected_team.membros:
            return f"{base} ({self.selected_team.membros} membros)"
        return base

    def _set_selected_team(self, team: Optional[NotificationTeamDTO]) -> None:
        self.selected_team = team
        self.updated_team_id = team.equipe_id if team else None
        if hasattr(self, "notified_teams_edit"):
            self.notified_teams_edit.setText(self._selected_team_label())
        if hasattr(self, "clear_team_btn"):
            self.clear_team_btn.setEnabled(team is not None)

    def _clear_selected_team(self) -> None:
        self._set_selected_team(None)

    def _build_default_section(self) -> QGroupBox:
        box = QGroupBox("Configuração padrão")
        box.setStyleSheet(
            "QGroupBox { background: #e9e9e9; border: 1px solid #bcbec4; margin-top: 16px; }"
            "QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top left; padding: 2px 6px;"
            " background: #dfe0e2; color: #3a3a3a; font-weight: 600; }"
        )
        layout = QHBoxLayout(box)
        layout.setContentsMargins(6, 4, 6, 4)
        self.use_default_cb = QCheckBox()
        self.use_default_cb.setChecked(self.company.use_default)
        layout.addWidget(self.use_default_cb)
        layout.addWidget(QLabel("Usar configuração da empresa marcada como padrão"))
        layout.addStretch()
        return box

    def _build_notifications_section(self) -> QGroupBox:
        box = QGroupBox("Destinatários notificados")
        form = QHBoxLayout(box)
        form.setContentsMargins(8, 6, 8, 6)
        initial_team_text = self._selected_team_label() or self.company.notified_teams
        self.notified_teams_edit = QLineEdit(initial_team_text)
        self.notified_teams_edit.setReadOnly(True)
        self.notified_teams_edit.setPlaceholderText("Selecione um destinatário para notificações")
        self.notified_teams_edit.setStyleSheet("background: #f6f6f6;")
        form.addWidget(self.notified_teams_edit, 1)

        icon_users = mdl2_icon(MDL2_GLYPHS["members"], QColor("#1e1e1e"))
        teams_btn = QToolButton()
        teams_btn.setIcon(icon_users)
        teams_btn.setToolTip("")
        teams_btn.setCursor(Qt.PointingHandCursor)
        teams_btn.clicked.connect(self._open_team_selector)
        form.addWidget(teams_btn)

        icon_clear = mdl2_icon(MDL2_GLYPHS["clear"], QColor("#1e1e1e"))
        self.clear_team_btn = QToolButton()
        self.clear_team_btn.setIcon(icon_clear)
        self.clear_team_btn.setToolTip("")
        self.clear_team_btn.setCursor(Qt.PointingHandCursor)
        self.clear_team_btn.clicked.connect(self._clear_selected_team)
        self.clear_team_btn.setEnabled(self.selected_team is not None)
        form.addWidget(self.clear_team_btn)
        return box

    def _schedule_for(self, automation_type: str) -> ScheduleConfig:
        defaults = automation_default_values(automation_type)
        schedule = self.settings.schedules.get(automation_type)
        allowed = list(defaults["allowed_frequencies"])
        if schedule:
            if schedule.allowed_frequencies:
                return schedule
            return replace(schedule, allowed_frequencies=allowed)
        return ScheduleConfig(
            enabled=defaults["enabled"],
            frequency=defaults["frequency"],
            day_of_month=defaults["day_of_month"],
            weekday=defaults["weekday"],
            time=defaults["time"],
            allowed_frequencies=allowed,
        )

    def _build_schedule_section(self, definition: SectionDefinition) -> QGroupBox:
        config = self._schedule_for(definition.automation_type)
        box = QGroupBox()
        box.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        box.setStyleSheet(
            "QGroupBox { background: #e9e9e9; border: 1px solid #bcbec4; padding: 2px 4px; }"
        )
        form = QVBoxLayout(box)
        form.setSpacing(3)
        form.setContentsMargins(4, 3, 4, 3)

        header = QHBoxLayout()
        enabled_cb = self._styled_checkbox()
        enabled_cb.setChecked(config.enabled)
        header.addWidget(enabled_cb)
        section_label = QLabel(definition.label)
        section_label.setStyleSheet("font-weight: 600;")
        header.addWidget(section_label)
        header.addStretch()
        summary_label = self._schedule_summary_label()
        summary_label.setStyleSheet("color: #4c4c4c; font-weight: 600;")
        header.addWidget(summary_label)
        form.addLayout(header)

        allowed_options = config.allowed_frequencies or self.combo_frequency
        allowed_options = list(allowed_options)
        current_frequency = config.frequency if config.frequency in allowed_options else allowed_options[0]
        frequency_combo = self._combo(allowed_options, current_frequency)
        control_row = QHBoxLayout()
        control_row.setSpacing(12)

        freq_field = self._inline_field("Executar:", frequency_combo)
        freq_field.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        control_row.addWidget(freq_field, 1)
        show_day_month = "Mensalmente" in allowed_options
        show_day_week = "Semanalmente" in allowed_options

        day_month = None
        day_month_row = None
        if show_day_month:
            day_month = QSpinBox()
            day_month.setStyle(SpinArrowStyle())
            day_month.setRange(1, 31)
            day_month.setValue(config.day_of_month or 1)
            day_month_row = self._inline_field("Dia do mês:", day_month)
            control_row.addWidget(day_month_row, 1)

        day_week = None
        day_week_row = None
        if show_day_week:
            day_week = self._combo(self.combo_days, config.weekday or "Segunda")
            day_week_row = self._inline_field("Dia da semana:", day_week)
            control_row.addWidget(day_week_row, 1)

        time_edit = self._time_edit(config.time)
        time_row = self._inline_field("Horário:", time_edit)
        control_row.addWidget(time_row, 1)

        form.addLayout(control_row)

        widgets = SectionWidgets(
            group=box,
            enabled=enabled_cb,
            frequency=frequency_combo,
            day_month=day_month,
            day_month_row=day_month_row,
            day_week=day_week,
            day_week_row=day_week_row,
            time=time_edit,
            time_row=time_row,
            summary=summary_label,
            allowed_frequencies=allowed_options,
        )
        key = definition.automation_type
        self.sections[key] = widgets
        self._register_section_signals(key, widgets)
        self._apply_section_enabled_state(key)
        return box

    def _register_section_signals(self, key: str, widgets: SectionWidgets) -> None:
        widgets.enabled.toggled.connect(lambda checked, k=key: self._apply_section_enabled_state(k))
        widgets.frequency.currentTextChanged.connect(lambda value, k=key: self._handle_frequency_change(k, value))
        if widgets.day_month is not None:
            widgets.day_month.valueChanged.connect(lambda _=0, k=key: self._update_schedule_summary(k))
        if widgets.day_week is not None:
            widgets.day_week.currentTextChanged.connect(lambda _=0, k=key: self._update_schedule_summary(k))
        widgets.time.timeChanged.connect(lambda _=0, k=key: self._update_schedule_summary(k))

    def _placeholder_tab(self, text: str) -> QWidget:
        tab = QWidget(self)
        layout = QVBoxLayout(tab)
        label = QLabel(text)
        label.setStyleSheet("color: #666;")
        layout.addWidget(label, alignment=Qt.AlignTop)
        layout.addStretch()
        return tab

    def _combo(self, values, current):
        combo = RoundedComboBox()
        combo.addItems(values)
        idx = combo.findText(current)
        if idx >= 0:
            combo.setCurrentIndex(idx)
        combo.setMinimumWidth(130)
        return combo

    def _labeled_field(self, label_text: str, widget: QWidget) -> QWidget:
        wrapper_widget = QWidget()
        wrapper = QVBoxLayout(wrapper_widget)
        wrapper.setSpacing(2)
        label = QLabel(label_text)
        label.setStyleSheet("color: #4a4a4a;")
        wrapper.addWidget(label)
        wrapper.addWidget(widget)
        return wrapper_widget

    def _inline_field(self, label_text: str, widget: QWidget) -> QWidget:
        container = QWidget()
        layout = QHBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)
        label = QLabel(label_text)
        label.setStyleSheet("color: #4a4a4a;")
        layout.addWidget(label)
        layout.addWidget(widget)
        return container

    @staticmethod
    def _styled_checkbox() -> QCheckBox:
        cb = QCheckBox()
        cb.setCursor(Qt.PointingHandCursor)
        cb.setStyleSheet(
            """
            QCheckBox {
                spacing: 6px;
            }
            QCheckBox::indicator {
                width: 14px;
                height: 14px;
            }
            """
        )
        return cb

    def _row(self, label: str, widget: QWidget) -> QWidget:
        container = QWidget()
        layout = QHBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(QLabel(label))
        layout.addWidget(widget)
        layout.addStretch()
        return container

    @staticmethod
    def _schedule_summary_label() -> QLabel:
        label = QLabel()
        label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        label.setMinimumWidth(180)
        label.setStyleSheet("color: #555; font-style: italic;")
        return label

    def _time_edit(self, value: str) -> QTimeEdit:
        editor = QTimeEdit()
        editor.setStyle(SpinArrowStyle())
        editor.setDisplayFormat("HH:mm")
        try:
            hour, minute = map(int, value.split(":"))
        except ValueError:
            hour, minute = (8, 0)
        editor.setTime(QTime(hour, minute))
        editor.setMinimumWidth(50)
        return editor

    def _handle_save(self):
        schedules = {
            definition.automation_type: self._collect_schedule(definition.automation_type)
            for definition in self.section_defs
        }
        new_settings = CompanySettingsDTO(
            automacaoempresa=self.company_ref,
            schedules=schedules,
        )
        self.updated_settings = new_settings
        self.updated_use_default = self.use_default_cb.isChecked()
        self.updated_notified_teams = self.notified_teams_edit.text()
        self.updated_team_id = self.selected_team.equipe_id if self.selected_team else None
        self.settings = new_settings
        self.accept()

    def _handle_frequency_change(self, key: str, frequency: str):
        self._toggle_schedule_rows(frequency, key)
        widgets = self.sections[key]
        self._set_schedule_inputs_enabled(key, widgets.enabled.isChecked())
        self._update_schedule_summary(key)

    def _toggle_schedule_rows(self, frequency: str, key: str):
        show_month = frequency == "Mensalmente"
        show_week = frequency == "Semanalmente"
        widgets = self.sections[key]
        if widgets.day_month_row is not None:
            widgets.day_month_row.setVisible(show_month)
        if widgets.day_week_row is not None:
            widgets.day_week_row.setVisible(show_week)

    def _collect_schedule(self, key: str) -> ScheduleConfig:
        widgets = self.sections[key]
        enabled = widgets.enabled.isChecked()
        frequency = widgets.frequency.currentText()
        day_of_month = widgets.day_month.value() if widgets.day_month is not None else None
        weekday = widgets.day_week.currentText() if widgets.day_week is not None else None
        time_value = widgets.time.time().toString("HH:mm")
        config = ScheduleConfig(
            enabled=enabled,
            frequency=frequency,
            day_of_month=day_of_month,
            weekday=weekday,
            time=time_value,
            allowed_frequencies=list(widgets.allowed_frequencies),
        )
        return self._normalize_schedule(config)

    def _apply_section_enabled_state(self, key: str) -> None:
        widgets = self.sections[key]
        self._toggle_schedule_rows(widgets.frequency.currentText(), key)
        self._set_schedule_inputs_enabled(key, widgets.enabled.isChecked())
        self._update_schedule_summary(key)

    def _set_schedule_inputs_enabled(self, key: str, enabled: bool) -> None:
        widgets = self.sections[key]
        widgets.frequency.setEnabled(enabled)
        widgets.time.setEnabled(enabled)
        widgets.time_row.setEnabled(enabled)

        frequency = widgets.frequency.currentText()
        show_month = frequency == "Mensalmente"
        show_week = frequency == "Semanalmente"

        if widgets.day_month_row is not None:
            widgets.day_month_row.setVisible(show_month)
        if widgets.day_week_row is not None:
            widgets.day_week_row.setVisible(show_week)

        if widgets.day_month_row is not None:
            widgets.day_month_row.setEnabled(enabled)
        if widgets.day_month is not None:
            widgets.day_month.setEnabled(enabled and show_month)

        if widgets.day_week_row is not None:
            widgets.day_week_row.setEnabled(enabled)
        if widgets.day_week is not None:
            widgets.day_week.setEnabled(enabled and show_week)

        bg = "#f1f1f1" if enabled else "#e3e4e8"
        combo_bg = "#ffffff" if enabled else bg
        widgets.group.setStyleSheet(
            f"""
            QGroupBox {{ 
                border: 1px solid #c9c9c9;
                margin-top: 4px; 
                background: {bg}; 
            }} 
            
            QWidget, QLabel {{ 
                background: {bg};
            }}
            
            QComboBox QAbstractItemView {{
                background: #ffffff;
                color: #1e1e1e;
                selection-background-color: #cfdcf4;
            }}
            
            
            QLineEdit, QComboBox, QSpinBox, QTimeEdit {{ 
                background: {combo_bg};
                border: 1px solid #bfc1c7;
                border-radius: 2px;
                padding: 3px;
            }}

            QSpinBox::up-button, QSpinBox::down-button,
            QTimeEdit::up-button, QTimeEdit::down-button {{
                width: 16px;
                border-left: 1px solid #c7c9ce;
                background: #f3f3f3;
            }}
            QSpinBox::up-button, QTimeEdit::up-button {{
                subcontrol-position: top right;
                border-top-right-radius: 2px;
            }}
            QSpinBox::down-button, QTimeEdit::down-button {{
                subcontrol-position: bottom right;
                border-bottom-right-radius: 2px;
            }}
            QSpinBox::up-button:hover, QSpinBox::down-button:hover,
            QTimeEdit::up-button:hover, QTimeEdit::down-button:hover {{
                background: #e9e9e9;
            }}

            """
        )
        widgets.summary.setStyleSheet("color: #2f2f2f; font-style: normal;" if enabled else "color: #7a1f1f; font-style: italic;")
        self._update_schedule_summary(key)

    def _update_schedule_summary(self, key: str) -> None:
        widgets = self.sections[key]
        if not widgets.enabled.isChecked():
            widgets.summary.setText("Ação manual")
            widgets.summary.setStyleSheet("color: #7a1f1f; font-style: italic;")
            return
        summary = self._summarize_schedule(key)
        widgets.summary.setText(summary)
        widgets.summary.setStyleSheet("color: #2f2f2f; font-style: normal;")

    def _summarize_schedule(self, key: str) -> str:
        widgets = self.sections[key]
        frequency = widgets.frequency.currentText()
        time_text = widgets.time.time().toString("HH:mm")
        if frequency == "Mensalmente":
            day = widgets.day_month.value() if widgets.day_month is not None else 1
            return f"Todo dia {day} às {time_text}"
        if frequency == "Semanalmente":
            weekday = widgets.day_week.currentText().lower() if widgets.day_week is not None else "segunda"
            return f"Toda {weekday} às {time_text}"
        return f"Diariamente às {time_text}"

    @staticmethod
    def _normalize_schedule(config: ScheduleConfig) -> ScheduleConfig:
        if config.frequency == "Mensalmente":
            return replace(config, weekday=None)
        if config.frequency == "Semanalmente":
            return replace(config, day_of_month=None)
        return replace(config, day_of_month=None, weekday=None)


class NotificationTeamSelectorDialog(QDialog):
    """Lightweight dialog that lists notification teams for selection."""

    def __init__(
        self,
        teams: List[NotificationTeamDTO],
        selected_team: Optional[NotificationTeamDTO] = None,
        parent=None,
    ):
        super().__init__(parent)
        self.setWindowIcon(persona_icon())
        self._teams = teams
        self._selected_id = selected_team.equipe_id if selected_team else None
        self.selected_team: Optional[NotificationTeamDTO] = None
        self.setWindowTitle("Selecionar equipe")
        self.resize(420, 360)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(8)

        self.filter_edit = QLineEdit()
        self.filter_edit.setPlaceholderText("Filtrar por código, nome ou e-mail")
        self.filter_edit.textChanged.connect(self._apply_filter)
        layout.addWidget(self.filter_edit)

        self.list_widget = QListWidget()
        self.list_widget.setAlternatingRowColors(True)
        self.list_widget.itemDoubleClicked.connect(lambda *_: self._accept_current())
        layout.addWidget(self.list_widget, 1)
        self._populate()

        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self._accept_current)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

        self.setStyleSheet(
            """
            QListWidget {
                background: #ffffff;
                border: 1px solid #bfc1c7;
                border-radius: 4px;
            }
            QListWidget::item:selected {
                background: #cfdcf4;
                color: #1e1e1e;
            }
            QLineEdit {
                background: #ffffff;
                border: 1px solid #bfc1c7;
                border-radius: 4px;
                padding: 4px 6px;
            }
            """
        )

    def _populate(self) -> None:
        self.list_widget.clear()
        for team in self._teams:
            display = f"{team.codigo} - {team.nome}"
            if team.membros:
                display = f"{display} ({team.membros} membros)"
            item = QListWidgetItem(display)
            item.setData(Qt.UserRole, team)
            if team.emails:
                item.setToolTip(team.emails)
            self.list_widget.addItem(item)
            if team.equipe_id == self._selected_id:
                self.list_widget.setCurrentItem(item)

    def _apply_filter(self, text: str) -> None:
        needle = text.strip().lower()
        for idx in range(self.list_widget.count()):
            item = self.list_widget.item(idx)
            if not needle:
                item.setHidden(False)
                continue
            team: NotificationTeamDTO = item.data(Qt.UserRole)
            haystack = f"{team.codigo} {team.nome} {team.emails}".lower()
            item.setHidden(needle not in haystack)

    def _accept_current(self) -> None:
        item = self.list_widget.currentItem()
        if item is None:
            QMessageBox.information(
                self,
                "Selecionar equipe",
                "Selecione uma equipe antes de confirmar.",
            )
            return
        self.selected_team = item.data(Qt.UserRole)
        self.accept()
