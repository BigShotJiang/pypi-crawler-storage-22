from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class ExecutionDTO:
    execucao_id: str
    empresa_id: str
    empresa_codigo: str
    empresa_nome: str
    processo: str
    status: int
    detalhes: Optional[str]
    data_inicio: Optional[datetime]
    data_fim: Optional[datetime]


@dataclass
class ExecutionCompanyDTO:
    empresa_id: str
    codigo: str
    nome: str
