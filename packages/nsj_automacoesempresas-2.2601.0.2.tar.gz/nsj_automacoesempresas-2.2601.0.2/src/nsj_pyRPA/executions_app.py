"""
PyQt5 UI for execution observability aligned with the provided prototype.
UI acts as controller; data access lives in service/repository layers.
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable, List, Optional

from PyQt5.QtCore import QAbstractTableModel, QModelIndex, Qt, QSortFilterProxyModel, QSize
from PyQt5.QtGui import QColor, QFont, QFontMetrics, QIcon, QPalette, QPainter, QPixmap
from PyQt5.QtWidgets import (
    QApplication,
    QAction,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFrame,
    QFileDialog,
    QGridLayout,
    QHeaderView,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSizePolicy,
    QStyle,
    QStyledItemDelegate,
    QTableView,
    QToolBar,
    QToolButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from nsj_pyRPA.dto.execution_dto import ExecutionCompanyDTO, ExecutionDTO
from nsj_pyRPA.services.bootstrap import DatabaseConfig, ExecutionServiceFactory
from nsj_pyRPA.services.execution_interfaces import ExecutionFilter
from nsj_pyRPA.services.execution_service import ExecutionService

ICON_PATH = Path(__file__).resolve().parent / "resources" / "Persona.ico"

STATUS_LABELS = {
    0: "Em andamento",
    1: "Sucesso",
    2: "Falha",
}

STATUS_COLORS = {
    0: QColor("#4a4a4a"),
    1: QColor("#1e7d32"),
    2: QColor("#b71c1c"),
}

MDL2_GLYPHS = {
    "details": "\uE8A7",
    "refresh": "\uE72C",
    "exit": "\uF3B1",
    "search": "\uE721",
    "clear": "\uE711",
}


def persona_icon() -> QIcon:
    if not ICON_PATH.exists():
        return QIcon()
    return QIcon(str(ICON_PATH))


def mdl2_icon(glyph: str, color: QColor) -> QIcon:
    font = QFont("Segoe MDL2 Assets")
    font.setPixelSize(16)
    metrics = QFontMetrics(font)
    size = max(metrics.height(), 16) + 6
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    painter.setFont(font)
    painter.setPen(color)
    painter.drawText(pixmap.rect(), Qt.AlignCenter, glyph)
    painter.end()
    return QIcon(pixmap)


def _coerce_datetime(value) -> Optional[datetime]:
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value)
        except ValueError:
            return None
    return None


class ExecutionTableModel(QAbstractTableModel):
    HEADERS = ["Data", "Hora", "Processo", "Empresa", "Status"]

    def __init__(self, rows: Optional[List[ExecutionDTO]] = None, parent=None):
        super().__init__(parent)
        self._rows = rows or []

    def rowCount(self, parent=QModelIndex()) -> int:  # type: ignore[override]
        return len(self._rows)

    def columnCount(self, parent=QModelIndex()) -> int:  # type: ignore[override]
        return len(self.HEADERS)

    def headerData(self, section: int, orientation: Qt.Orientation, role=Qt.DisplayRole):  # type: ignore[override]
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return self.HEADERS[section]
        return super().headerData(section, orientation, role)

    def data(self, index: QModelIndex, role=Qt.DisplayRole):  # type: ignore[override]
        if not index.isValid():
            return None

        row = self._rows[index.row()]
        column = index.column()

        if role == Qt.DisplayRole:
            if column == 0:
                return self._format_date(row.data_inicio)
            if column == 1:
                return self._format_time(row.data_inicio)
            if column == 2:
                return row.processo
            if column == 3:
                return row.empresa_nome or row.empresa_codigo
            if column == 4:
                return STATUS_LABELS.get(row.status, "Desconhecido")
        if role == Qt.UserRole and column == 4:
            return row.status
        if role == Qt.TextAlignmentRole:
            if column in (0, 1, 4):
                return Qt.AlignCenter
            return Qt.AlignVCenter | Qt.AlignLeft
        return None

    def update_rows(self, rows: List[ExecutionDTO]):
        self.beginResetModel()
        self._rows = rows
        self.endResetModel()

    def row_at(self, index: int) -> ExecutionDTO:
        if index < 0 or index >= len(self._rows):
            raise IndexError("Row out of range")
        return self._rows[index]

    @staticmethod
    def _format_date(value) -> str:
        dt = _coerce_datetime(value)
        if not dt:
            return ""
        return dt.strftime("%d/%m/%Y")

    @staticmethod
    def _format_time(value) -> str:
        dt = _coerce_datetime(value)
        if not dt:
            return ""
        return dt.strftime("%H:%M:%S")
    
    @staticmethod
    def _format_datetime_string(value) -> str:
        dt = _coerce_datetime(value)
        if not dt:
            return ""
        return dt.strftime("%Y-%m-%dT%H:%M:%S")


class StatusBadgeDelegate(QStyledItemDelegate):
    H_PADDING = 10
    V_PADDING = 2

    def paint(self, painter: QPainter, option, index):
        status_value = index.data(Qt.UserRole)
        label = index.data(Qt.DisplayRole) or ""
        color = STATUS_COLORS.get(status_value, QColor("#6c6c6c"))
        font = QFont(option.font)
        font.setBold(True)

        painter.save()
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setFont(font)

        rect = option.rect.adjusted(6, 4, -6, -4)
        painter.setBrush(color)
        painter.setPen(Qt.NoPen)
        radius = min(10, rect.height() / 2)
        painter.drawRoundedRect(rect, radius, radius)

        painter.setPen(QColor("#ffffff"))
        painter.drawText(rect, Qt.AlignCenter, label)
        painter.restore()

    def sizeHint(self, option, index):  # type: ignore[override]
        label = index.data(Qt.DisplayRole) or ""
        font = QFont(option.font)
        font.setBold(True)
        metrics = QFontMetrics(font)
        text_width = metrics.horizontalAdvance(label)
        text_height = metrics.height()
        width = text_width + (self.H_PADDING * 2)
        height = text_height + (self.V_PADDING * 2)
        base = super().sizeHint(option, index)
        return QSize(max(width, base.width()), max(height, base.height()))


class ContainsFilterProxy(QSortFilterProxyModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._needle = ""
        self.setFilterCaseSensitivity(Qt.CaseInsensitive)

    def set_search_term(self, text: str):
        self._needle = text.strip()
        self.invalidateFilter()

    def filterAcceptsRow(self, row: int, parent: QModelIndex) -> bool:  # type: ignore[override]
        if not self._needle:
            return True
        model = self.sourceModel()
        for column in range(model.columnCount()):
            idx = model.index(row, column, parent)
            value = model.data(idx, Qt.DisplayRole)
            if value and self._needle.lower() in str(value).lower():
                return True
        return False


class CompanyOptionModel(QAbstractTableModel):
    HEADERS = ["Codigo", "Empresa"]

    def __init__(self, rows: List[ExecutionCompanyDTO], parent=None):
        super().__init__(parent)
        self._rows = rows

    def rowCount(self, parent=QModelIndex()) -> int:  # type: ignore[override]
        return len(self._rows)

    def columnCount(self, parent=QModelIndex()) -> int:  # type: ignore[override]
        return len(self.HEADERS)

    def headerData(self, section: int, orientation: Qt.Orientation, role=Qt.DisplayRole):  # type: ignore[override]
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return self.HEADERS[section]
        return super().headerData(section, orientation, role)

    def data(self, index: QModelIndex, role=Qt.DisplayRole):  # type: ignore[override]
        if not index.isValid():
            return None
        row = self._rows[index.row()]
        if role == Qt.DisplayRole:
            if index.column() == 0:
                return row.codigo
            if index.column() == 1:
                return row.nome
        if role == Qt.TextAlignmentRole:
            return Qt.AlignCenter if index.column() == 0 else Qt.AlignVCenter | Qt.AlignLeft
        return None

    def row_at(self, index: int) -> ExecutionCompanyDTO:
        if index < 0 or index >= len(self._rows):
            raise IndexError("Row out of range")
        return self._rows[index]


class CompanyPickerDialog(QDialog):
    def __init__(self, companies: List[ExecutionCompanyDTO], parent=None):
        super().__init__(parent)
        self.setWindowTitle("Selecionar empresa")
        self.setWindowIcon(persona_icon())
        self._model = CompanyOptionModel(companies, self)
        self._proxy = ContainsFilterProxy(self)
        self._proxy.setSourceModel(self._model)

        layout = QVBoxLayout(self)
        search = QLineEdit(self)
        search.setPlaceholderText("Pesquisar")
        search.textChanged.connect(self._proxy.set_search_term)
        layout.addWidget(search)

        self.table = QTableView(self)
        self.table.setModel(self._proxy)
        self.table.setSelectionBehavior(QTableView.SelectRows)
        self.table.setSelectionMode(QTableView.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        layout.addWidget(self.table)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, parent=self)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self.resize(520, 360)

    def selected_company(self) -> Optional[ExecutionCompanyDTO]:
        selection = self.table.selectionModel()
        if not selection:
            return None
        idx = selection.currentIndex()
        if not idx.isValid():
            return None
        source_idx = self._proxy.mapToSource(idx)
        try:
            return self._model.row_at(source_idx.row())
        except IndexError:
            return None


class ExecutionDetailsDialog(QDialog):
    def __init__(self, execution: ExecutionDTO, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Detalhes da execução")
        self.setWindowIcon(persona_icon())
        
        empresa_value = f"{execution.empresa_codigo} - {execution.empresa_nome}".strip(" -")
        data_inicio = ExecutionTableModel._format_date(execution.data_inicio)
        hora_inicio = ExecutionTableModel._format_time(execution.data_inicio)
        
        self._details_text = execution.detalhes or "Sem detalhes."
        self.datahora = ExecutionTableModel._format_datetime_string(execution.data_inicio)

        layout = QVBoxLayout(self)
        content = QWidget(self)
        grid = QGridLayout(content)
        grid.setContentsMargins(12, 12, 12, 12)
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(8)
        grid.setColumnStretch(0, 0)
        grid.setColumnStretch(1, 1)

        label_empresa = QLabel("Empresa:")
        label_empresa.setStyleSheet("font-weight: 600;")
        grid.addWidget(label_empresa, 0, 0)
        empresa_label = QLabel(empresa_value)
        empresa_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        grid.addWidget(empresa_label, 0, 1, Qt.AlignLeft | Qt.AlignVCenter)
        label_item = QLabel("Item:")
        label_item.setStyleSheet("font-weight: 600;")
        grid.addWidget(label_item, 1, 0)
        item_value = QLabel(execution.processo)
        item_value.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        grid.addWidget(item_value, 1, 1, Qt.AlignLeft | Qt.AlignVCenter)
        label_data = QLabel("Data/Hora:")
        label_data.setStyleSheet("font-weight: 600;")
        grid.addWidget(label_data, 2, 0)
        data_label = QLabel(f"{data_inicio} - {hora_inicio}".strip(" -"))
        data_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        grid.addWidget(data_label, 2, 1, Qt.AlignLeft | Qt.AlignVCenter)
        detail_label = QLabel("Detalhes da execução:")
        detail_label.setStyleSheet("font-weight: 600;")
        grid.addWidget(detail_label, 3, 0, 1, 2)
        detail_field = QTextEdit(self)
        detail_field.setReadOnly(True)
        detail_field.setPlainText(self._details_text)
        detail_field.setMinimumHeight(90)
        detail_field.setFrameStyle(QFrame.Box)
        detail_field.setStyleSheet(
            "background: #ffffff; border: 1px solid #d0d2d8; border-radius: 4px;"
        )
        detail_field.setToolTip("Campo somente leitura, é possível selecionar e copiar.")
        grid.addWidget(detail_field, 4, 0, 1, 2)

        layout.addWidget(content)

        button_bar = QDialogButtonBox(parent=self)
        save_btn = button_bar.addButton(
            "Salvar como arquivo", QDialogButtonBox.ActionRole
        )
        copy_btn = button_bar.addButton(
            "Copiar para área de transferência", QDialogButtonBox.ActionRole
        )
        close_btn = button_bar.addButton("Fechar", QDialogButtonBox.RejectRole)
        save_btn.clicked.connect(self._save_details)
        copy_btn.clicked.connect(self._copy_details)
        close_btn.clicked.connect(self.reject)
        layout.addWidget(button_bar)

        self.resize(600, 400)

    def _copy_details(self):
        QApplication.clipboard().setText(self._details_text)

    def _save_details(self):
        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Salvar detalhes da execução",
            f"execucao_{self.datahora}.txt",
            "Text files (*.txt);;All files (*)",
        )
        if not filename:
            return
        with open(filename, "w", encoding="utf-8") as handle:
            handle.write(self._details_text)
            
    def _format_datetime_string(self, value) -> str:
        dt = _coerce_datetime(value)
        if not dt:
            return ""
        return dt.strftime("%d-%m-%YT%H:%M:%S")


class ExecutionsWindow(QMainWindow):
    def __init__(self, service: ExecutionService, dispose_callback: Callable[[], None]):
        super().__init__()
        self.service = service
        self._dispose_callback = dispose_callback
        self._selected_company: Optional[ExecutionCompanyDTO] = None
        self.setWindowTitle("Automação - Execuções")
        self.setWindowIcon(persona_icon())
        self._create_toolbar()
        self._create_layout()
        self._set_theme()
        self._load_executions()

    def _create_toolbar(self):
        toolbar = QToolBar("Acoes", self)
        toolbar.setMovable(False)
        toolbar.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)

        def add_action(text: str, glyph_key: str, fallback: QStyle.StandardPixmap, handler):
            glyph = MDL2_GLYPHS.get(glyph_key, "")
            icon = mdl2_icon(glyph, QColor("#1e1e1e")) if glyph else QIcon()
            if icon.isNull():
                icon = self.style().standardIcon(fallback)
            act = QAction(icon, text, self)
            act.triggered.connect(handler)
            toolbar.addAction(act)
            return act

        add_action("Ver detalhes", "details", QStyle.SP_FileDialogContentsView, self._show_details)
        add_action("Atualizar", "refresh", QStyle.SP_BrowserReload, self._load_executions)

        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        toolbar.addWidget(spacer)
        add_action("Sair", "exit", QStyle.SP_DialogCloseButton, self.close)

        self.addToolBar(toolbar)

    def _create_layout(self):
        container = QWidget(self)
        layout = QVBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)

        self.filter_toggle = QToolButton(container)
        self.filter_toggle.setText("Filtros")
        self.filter_toggle.setCheckable(True)
        self.filter_toggle.setChecked(False)
        self.filter_toggle.setArrowType(Qt.DownArrow)
        self.filter_toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.filter_toggle.clicked.connect(self._toggle_filters)

        header_bar = QWidget(container)
        header_layout = QHBoxLayout(header_bar)
        header_layout.setContentsMargins(8, 6, 8, 6)
        header_layout.addWidget(self.filter_toggle)
        header_layout.addStretch(1)
        layout.addWidget(header_bar)

        self.filter_panel = QWidget(container)
        filter_layout = QGridLayout(self.filter_panel)
        filter_layout.setContentsMargins(12, 8, 12, 8)
        filter_layout.setHorizontalSpacing(12)
        filter_layout.setVerticalSpacing(6)

        filter_layout.addWidget(QLabel("Empresas"), 0, 0)
        filter_layout.addWidget(QLabel("Status"), 0, 1)
        filter_layout.addWidget(QLabel("Janela de tempo"), 0, 2)

        self.company_edit = QLineEdit(self.filter_panel)
        self.company_edit.setPlaceholderText("Selecione ou digite")
        self.company_edit.textChanged.connect(self._handle_company_text_changed)

        company_container = QWidget(self.filter_panel)
        company_layout = QHBoxLayout(company_container)
        company_layout.setContentsMargins(0, 0, 0, 0)
        company_layout.addWidget(self.company_edit)

        self.company_pick_btn = QToolButton(company_container)
        self.company_pick_btn.setIcon(mdl2_icon(MDL2_GLYPHS["search"], QColor("#1e1e1e")))
        self.company_pick_btn.clicked.connect(self._open_company_picker)
        company_layout.addWidget(self.company_pick_btn)

        self.company_clear_btn = QToolButton(company_container)
        self.company_clear_btn.setIcon(mdl2_icon(MDL2_GLYPHS["clear"], QColor("#1e1e1e")))
        self.company_clear_btn.clicked.connect(self._clear_company_filter)
        company_layout.addWidget(self.company_clear_btn)

        filter_layout.addWidget(company_container, 1, 0)

        self.status_combo = QComboBox(self.filter_panel)
        self.status_combo.addItem("Todos", None)
        self.status_combo.addItem("Em andamento", 0)
        self.status_combo.addItem("Sucesso", 1)
        self.status_combo.addItem("Falha", 2)
        filter_layout.addWidget(self.status_combo, 1, 1)

        self.window_combo = QComboBox(self.filter_panel)
        self.window_combo.addItem("Tudo", "all")
        self.window_combo.addItem("Hoje", "today")
        self.window_combo.addItem("Ultimos 7 dias", "7d")
        self.window_combo.addItem("Ultimos 30 dias", "30d")
        filter_layout.addWidget(self.window_combo, 1, 2)

        button_row = QWidget(self.filter_panel)
        button_layout = QHBoxLayout(button_row)
        button_layout.setContentsMargins(0, 0, 0, 0)
        button_layout.addStretch(1)

        self.apply_btn = QPushButton("Aplicar filtros", button_row)
        self.apply_btn.clicked.connect(self._load_executions)
        button_layout.addWidget(self.apply_btn)

        self.clear_btn = QPushButton("Limpar filtros", button_row)
        self.clear_btn.clicked.connect(self._reset_filters)
        button_layout.addWidget(self.clear_btn)

        filter_layout.addWidget(button_row, 2, 0, 1, 3)

        layout.addWidget(self.filter_panel)

        divider = QFrame(container)
        divider.setFrameShape(QFrame.HLine)
        divider.setFrameShadow(QFrame.Sunken)
        layout.addWidget(divider)

        self.table = QTableView(container)
        self.table.setSelectionBehavior(QTableView.SelectRows)
        self.table.setSelectionMode(QTableView.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)

        self.model = ExecutionTableModel([], self)
        self.table.setModel(self.model)
        self.table.setItemDelegateForColumn(4, StatusBadgeDelegate(self.table))

        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.Stretch)
        header.setSectionResizeMode(3, QHeaderView.Stretch)
        header.setSectionResizeMode(4, QHeaderView.ResizeToContents)

        layout.addWidget(self.table)
        self.filter_panel.setVisible(False)
        self.setCentralWidget(container)

    def _set_theme(self):
        self.setStyleSheet(
            """
            QWidget {
                background: #e3e4e8;
                color: #1e1e1e;
                font-family: Tahoma, Arial, sans-serif;
                font-size: 13px;
            }
            QToolBar {
                background: #e3e4e8;
                border: none;
                padding: 4px 10px;
                spacing: 8px;
                border-bottom: 1px solid #bfc1c7;
                border-top: 1px solid #bfc1c7;
            }
            QLineEdit, QComboBox {
                background: #ffffff;
                border: 1px solid #b7b8bc;
                border-radius: 4px;
                padding: 4px 6px;
                color: #1e1e1e;
            }
            QLineEdit:focus, QComboBox:focus {
                border: 1px solid #3b7bd4;
            }
            QToolButton {
                background: #f5f5f7;
                border: 1px solid #b7b8bc;
                border-radius: 4px;
                padding: 2px 8px;
            }
            QToolButton:hover {
                background: #e7e7e7;
            }
            QToolButton:pressed {
                background: #dcdcdc;
            }
            QPushButton {
                background: #f5f5f7;
                border: 1px solid #b7b8bc;
                border-radius: 4px;
                padding: 4px 10px;
            }
            QPushButton:hover {
                background: #e7e7e7;
            }
            QPushButton:pressed {
                background: #dcdcdc;
            }
            QTableView {
                background: #ffffff;
                alternate-background-color: #f5f5f7;
                gridline-color: #d0d2d8;
                selection-background-color: #cfdcf4;
                selection-color: #151515;
            }
            QHeaderView::section {
                background: #f0f0f2;
                border: 1px solid #d0d2d8;
                padding: 6px;
                font-weight: 600;
                color: #4a4a4a;
            }
            """
        )

    def _toggle_filters(self, checked: bool):
        self.filter_panel.setVisible(checked)
        self.filter_toggle.setArrowType(Qt.UpArrow if checked else Qt.DownArrow)

    def _handle_company_text_changed(self, text: str):
        if self._selected_company and text.strip() != self._company_display_text(self._selected_company).strip():
            self._selected_company = None

    def _company_display_text(self, company: ExecutionCompanyDTO) -> str:
        if company.codigo and company.nome:
            return f"{company.codigo} - {company.nome}"
        return company.codigo or company.nome

    def _open_company_picker(self):
        try:
            companies = self.service.list_companies()
        except Exception as exc:
            self._show_error("Erro ao carregar empresas", str(exc))
            return
        dialog = CompanyPickerDialog(companies, self)
        if dialog.exec() != QDialog.Accepted:
            return
        selected = dialog.selected_company()
        if not selected:
            return
        self._selected_company = selected
        self.company_edit.setText(self._company_display_text(selected))

    def _clear_company_filter(self):
        self._selected_company = None
        self.company_edit.clear()

    def _selected_execution(self) -> Optional[ExecutionDTO]:
        selection = self.table.selectionModel()
        if not selection:
            return None
        index = selection.currentIndex()
        if not index.isValid():
            return None
        try:
            return self.model.row_at(index.row())
        except IndexError:
            return None

    def _show_details(self):
        execution = self._selected_execution()
        if not execution:
            QMessageBox.information(self, "Automação - Execuções", "Selecione uma execução.")
            return
        dialog = ExecutionDetailsDialog(execution, self)
        dialog.exec()

    def _reset_filters(self):
        self._selected_company = None
        self.company_edit.clear()
        self.status_combo.setCurrentIndex(0)
        self.window_combo.setCurrentIndex(0)
        self._load_executions()

    def _build_filters(self) -> ExecutionFilter:
        company_id = self._selected_company.empresa_id if self._selected_company else None
        company_term = self.company_edit.text().strip() if not company_id else None
        if company_term and " - " in company_term:
            _, name_part = company_term.split(" - ", 1)
            company_term = name_part.strip() or company_term

        status = self.status_combo.currentData()

        start_at = None
        end_at = None
        window_value = self.window_combo.currentData()
        now = datetime.now()
        if window_value == "today":
            start_at = datetime(now.year, now.month, now.day)
            end_at = now
        elif window_value == "7d":
            start_at = now - timedelta(days=7)
            end_at = now
        elif window_value == "30d":
            start_at = now - timedelta(days=30)
            end_at = now

        return ExecutionFilter(
            company_id=company_id,
            company_term=company_term,
            status=status,
            start_at=start_at,
            end_at=end_at,
        )

    def _load_executions(self):
        filters = self._build_filters()
        try:
            executions = self.service.list_executions(filters)
        except Exception as exc:
            self._show_error("Erro ao carregar execucoes", str(exc))
            return
        self.model.update_rows(executions)

    def _show_error(self, title: str, message: str):
        QMessageBox.critical(self, title, message)

    def closeEvent(self, event):
        try:
            self._dispose_callback()
        finally:
            super().closeEvent(event)


def _parse_cli_args(argv: Optional[List[str]] = None):
    parser = argparse.ArgumentParser(description="Automacao - Execucoes UI")
    parser.add_argument("--bd-nome", dest="bd_nome", default="integratto2_dev", help="Nome do banco")
    parser.add_argument("--bd-user", dest="bd_user", default="postgres", help="Usuario base")
    parser.add_argument("--bd-senha", dest="bd_senha", default="postgres", help="Senha")
    parser.add_argument("--bd-host", dest="bd_host", default="localhost", help="Host")
    parser.add_argument("--bd-porta", dest="bd_porta", default="5433", help="Porta")
    return parser.parse_known_args(argv)


def main(argv: Optional[List[str]] = None):
    args, qt_args = _parse_cli_args(argv)
    config = DatabaseConfig(
        database=args.bd_nome,
        user=args.bd_user,
        password=args.bd_senha,
        host=args.bd_host,
        port=args.bd_porta,
    )
    factory = ExecutionServiceFactory(config)
    try:
        service = factory.build()
    except Exception as exc:
        print(f"Erro ao inicializar servico: {exc}", file=sys.stderr)
        return 1

    qt_argv = [sys.argv[0]] + qt_args
    app = QApplication(qt_argv)
    _apply_light_palette(app)
    window = ExecutionsWindow(service, factory.dispose)
    window.resize(980, 560)
    window.show()
    exit_code = app.exec()
    factory.dispose()
    return exit_code


def _apply_light_palette(app: QApplication) -> None:
    palette = QPalette()
    palette.setColor(QPalette.Window, QColor("#f2f2f4"))
    palette.setColor(QPalette.Base, QColor("#f2f2f4"))
    palette.setColor(QPalette.AlternateBase, QColor("#f5f5f7"))
    palette.setColor(QPalette.Text, QColor("#1e1e1e"))
    palette.setColor(QPalette.WindowText, QColor("#1e1e1e"))
    palette.setColor(QPalette.Button, QColor("#e3e4e8"))
    palette.setColor(QPalette.ButtonText, QColor("#1e1e1e"))
    palette.setColor(QPalette.Highlight, QColor("#3b7bd4"))
    palette.setColor(QPalette.HighlightedText, QColor("#f2f2f4"))
    app.setPalette(palette)


if __name__ == "__main__":
    raise SystemExit(main())
