import traceback
from typing import Optional

from nsj_pyRPA.resources.db_adapter3 import DBAdapter3
from nsj_pyRPA.resources.envConfig import EnvConfig, getLog, getVersaoMinimaAtendida
from nsj_pyRPA.resources.locking_banco import *

from nsj_pyRPA.nasajonRPA.rotinas.configuracoes import *
from nsj_pyRPA.nasajonRPA.orquestrador import Orquestrar
from nsj_pyRPA.repositories.execution_log_repository import DbExecutionLogRepository
from nsj_pyRPA.services.execution_log_service import ExecutionLogService

class pyRPA:

    def __init__(self):
        pass

    def processar(self, a_roteiro, execution_logger: Optional[ExecutionLogService] = None):
        status_code = 0
        tem_sucesso = False
        status_msg = None
        
        for item in a_roteiro :
            execucao_id = None
            if execution_logger is not None:
                execucao_id = execution_logger.try_start_execution(item)

            collector = execution_logger.start_log_collection() if execution_logger else None
            aux_sts_code, aux_sts_msg = item.Processa()
            detalhes = (
                execution_logger.finish_log_collection(collector, aux_sts_msg)
                if execution_logger
                else aux_sts_msg
            )

            if execucao_id and execution_logger is not None:
                status_value = 1 if aux_sts_code == 0 else 2
                execution_logger.try_finish_execution(execucao_id, status_value, detalhes)

            if aux_sts_code == 3:
                status_code = aux_sts_code
                status_msg = aux_sts_msg
                break
            
            if aux_sts_msg is not None:
                if status_msg is not None:
                    status_msg = status_msg + "\n" + aux_sts_msg
                else:
                    status_msg = aux_sts_msg
                
            if aux_sts_code == 0 :
                tem_sucesso = True
            else:
                status_code = aux_sts_code

        if aux_sts_code == 3:
            return status_code, status_msg   
        
        if tem_sucesso :
            if (status_code != 0) and (status_msg is not None):
                status_code = 1
                status_msg = "Alguns processos foram executados com sucesso. " + "\n" + status_msg
        else :
            status_code = 2

        return status_code, status_msg 

    def executar(self, entrada: dict, job, db: DBAdapter3, log, registro_execucao):
        EnvConfig.instance().set_log(log)
        EnvConfig.instance().set_db(db)     

        if not getVersaoMinimaAtendida():
            log.atencao("Verificamos que a versão do PostgreSQL está desatualizada, para melhor " +
                        "execução do utilitário recomendamos sua atualização para a versão 9.5.25+")            

        log.info("Verificando se há locks no banco para a rotina")
        if not advisory_lock():
            return 3, ("Não foi possível iniciar as rotinas do pyRPA "+
                       "pois outro processo já está em execução. Favor aguardar.")
        
        execution_logger = ExecutionLogService(DbExecutionLogRepository(db))
        orchestration_exec_id = None
        has_orchestration_keys = (
            entrada.get("automacaotipo") is not None
            and entrada.get("automacaoempresaparametro") is not None
        )
            
        orchestration_context = (
            execution_logger.build_orchestration_context(entrada)
            if has_orchestration_keys
            else None
        )
            
        collector = execution_logger.start_log_collection()
        try:
            if orchestration_context is not None:
                orchestration_exec_id = execution_logger.try_start_execution_with_context(
                    orchestration_context
                )
            elif has_orchestration_keys:
                orchestration_exec_id = execution_logger.try_start_execution_without_context(
                    entrada
                )
                getLog().atencao(
                    "Execucao nao registrada: contexto de orquestracao indisponivel."
                )

            DetalhaEntradasLog(entrada)
                        
            log.info("Orquestrando Operacoes")
            try:
                _roteiro = Orquestrar(entrada)
            except Exception as exc:
                log.erro(f"Falha ao orquestrar operacoes: {exc}")
                log.erro(traceback.format_exc())
                execution_logger.try_finish_orchestration_execution(
                    orchestration_exec_id,
                    collector,
                    2,
                    exc,
                )
                collector = None
                raise

            use_orchestration = orchestration_exec_id is not None
            item_logger = None if use_orchestration else execution_logger
            try:
                status_code, status_msg = self.processar(_roteiro, item_logger)
            except Exception as exc:
                log.erro(f"Falha ao processar operacoes: {exc}")
                log.erro(traceback.format_exc())
                if use_orchestration:
                    execution_logger.try_finish_orchestration_execution(
                        orchestration_exec_id,
                        collector,
                        2,
                        exc,
                    )
                    collector = None
                raise

            if use_orchestration:
                execution_logger.try_finish_orchestration_execution(
                    orchestration_exec_id,
                    collector,
                    1 if status_code in (0, 1) else 2,
                    status_msg,
                )
                collector = None
            return status_code, status_msg 
        finally:
            if collector is not None:
                execution_logger.finish_log_collection(collector, None)
            advisory_unlock()  


def DetalhaEntradasLog(a_entrada):
    getLog().info("Entrada de dados:", a_entrada)
    #getLog().info(f"    Empresa {RecuperaCodigoEmpresa(a_entrada.get(ent_empresa, None))}")
