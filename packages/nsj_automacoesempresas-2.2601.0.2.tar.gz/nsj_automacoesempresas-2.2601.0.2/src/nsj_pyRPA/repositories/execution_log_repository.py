from __future__ import annotations

from typing import Optional

from nsj_pyRPA.services.execution_log_interfaces import ExecutionContext, ExecutionLogRepository


class DbExecutionLogRepository(ExecutionLogRepository):
    def __init__(self, db_adapter):
        self._db = db_adapter

    def create_execution(self, context: ExecutionContext) -> str:
        sql = """
            INSERT INTO persona.automacoesexecucoes (
                tenant,
                empresa,
                automacaoempresa,
                automacaoempresaparametro,
                processo,
                detalhes,
                status
            ) VALUES (
                :tenant,
                :empresa,
                :automacaoempresa,
                :automacaoempresaparametro,
                :processo,
                :detalhes,
                :status
            )
            RETURNING execucao
        """
        params = {
            "tenant": context.tenant,
            "empresa": context.empresa_id,
            "automacaoempresa": context.automacaoempresa,
            "automacaoempresaparametro": context.automacaoempresaparametro,
            "processo": context.processo,
            "detalhes": "Em execução",
            "status": 0,
        }
        _, returning = self._db.execute(sql, **params)
        if not returning:
            raise RuntimeError("Falha ao criar execucao")
        return str(returning[0]["execucao"])

    def finish_execution(self, execucao_id: str, status: int, detalhes: Optional[str]) -> None:
        sql = """
            UPDATE persona.automacoesexecucoes
            SET
                status = :status,
                detalhes = :detalhes,
                datafim = now(),
                lastupdate = now()
            WHERE execucao = :execucao
        """
        self._db.execute(sql, status=status, detalhes=detalhes, execucao=execucao_id)

    def fetch_company_by_parametro(self, parametro_id: str) -> Optional[dict]:
        sql = """
            SELECT a.empresa, a.automacaoempresa, a.tenant
            FROM persona.automacoesempresas a
            INNER JOIN persona.automacoesempresasparametros ap
                ON a.automacaoempresa = ap.automacaoempresa
            WHERE ap.automacaoempresaparametro = :parametro
            LIMIT 1
        """
        return self._db.execute_query_first_result(sql, parametro=parametro_id)

    def fetch_empresa_by_codigo(self, codigo: str) -> Optional[dict]:
        sql = """
            SELECT empresa, tenant
            FROM ns.empresas
            WHERE codigo = :codigo
            LIMIT 1
        """
        return self._db.execute_query_first_result(sql, codigo=codigo)

    def fetch_empresa_by_automacaoempresa(self, automacaoempresa: str) -> Optional[str]:
        sql = """
            SELECT empresa
            FROM persona.automacoesempresas
            WHERE automacaoempresa = :automacaoempresa
            LIMIT 1
        """
        row = self._db.execute_query_first_result(
            sql, automacaoempresa=automacaoempresa
        )
        if not row:
            return None
        return row.get("empresa")
