from __future__ import annotations

from typing import List

from nsj_pyRPA.dto.execution_dto import ExecutionCompanyDTO, ExecutionDTO
from nsj_pyRPA.services.execution_interfaces import ExecutionFilter, ExecutionRepository


class DbExecutionRepository(ExecutionRepository):
    def __init__(self, db_adapter):
        self._db = db_adapter

    def list_executions(self, filters: ExecutionFilter) -> List[ExecutionDTO]:
        sql = """
            SELECT
                ex.execucao AS execucao_id,
                ex.empresa AS empresa_id,
                e.codigo AS empresa_codigo,
                COALESCE(e.razaosocial, e.descricao, '') AS empresa_nome,
                ex.processo AS processo,
                ex.status AS status,
                ex.detalhes AS detalhes,
                ex.datainicio AS data_inicio,
                ex.datafim AS data_fim
            FROM persona.automacoesexecucoes ex
            LEFT JOIN ns.empresas e
                ON e.empresa = ex.empresa
        """
        conditions = []
        params = {}

        if filters.company_id:
            conditions.append("ex.empresa = :empresa_id")
            params["empresa_id"] = filters.company_id
        elif filters.company_term:
            conditions.append(
                "(e.codigo ILIKE :empresa_term OR e.razaosocial ILIKE :empresa_term OR e.descricao ILIKE :empresa_term)"
            )
            params["empresa_term"] = f"%{filters.company_term}%"

        if filters.status is not None:
            conditions.append("ex.status = :status")
            params["status"] = filters.status

        if filters.start_at is not None:
            conditions.append("ex.datainicio >= :start_at")
            params["start_at"] = filters.start_at

        if filters.end_at is not None:
            conditions.append("ex.datainicio <= :end_at")
            params["end_at"] = filters.end_at

        if conditions:
            sql += " WHERE " + " AND ".join(conditions)

        sql += " ORDER BY ex.datainicio DESC"

        rows = self._db.execute_query(sql, **params)
        return [
            ExecutionDTO(
                execucao_id=str(row["execucao_id"]),
                empresa_id=str(row["empresa_id"]),
                empresa_codigo=str(row.get("empresa_codigo") or ""),
                empresa_nome=str(row.get("empresa_nome") or "Empresa não identificada"),
                processo=str(row.get("processo") or ""),
                status=int(row.get("status") or 0),
                detalhes=row.get("detalhes"),
                data_inicio=row.get("data_inicio"),
                data_fim=row.get("data_fim"),
            )
            for row in rows
        ]

    def list_companies(self) -> List[ExecutionCompanyDTO]:
        sql = """
            SELECT DISTINCT
                e.empresa AS empresa_id,
                e.codigo AS codigo,
                COALESCE(e.razaosocial, e.descricao, '') AS nome
            FROM persona.automacoesexecucoes ex
            INNER JOIN ns.empresas e
                ON e.empresa = ex.empresa
            ORDER BY e.codigo
        """
        rows = self._db.execute_query(sql)
        return [
            ExecutionCompanyDTO(
                empresa_id=str(row["empresa_id"]),
                codigo=str(row.get("codigo") or ""),
                nome=str(row.get("nome") or ""),
            )
            for row in rows
        ]
