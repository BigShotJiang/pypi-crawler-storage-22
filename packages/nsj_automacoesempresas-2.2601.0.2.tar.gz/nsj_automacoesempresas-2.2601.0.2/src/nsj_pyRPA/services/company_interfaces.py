from __future__ import annotations

from typing import List, Optional, Protocol

from nsj_pyRPA.dto.company_dto import CompanyDTO
from nsj_pyRPA.dto.notification_team_dto import NotificationTeamDTO


class CompanyRepository(Protocol):
    """Abstraction for company CRUD operations."""

    def list_companies(self) -> List[CompanyDTO]:
        ...

    def save_company(self, company: CompanyDTO) -> Optional[CompanyDTO]:
        ...


class NotificationTeamAssignmentStore(Protocol):
    """Abstraction for linking companies and notification teams."""

    def get_assigned_team(self, automacaoempresa: str) -> Optional[NotificationTeamDTO]:
        ...

    def assign_team(self, automacaoempresa: str, equipe_id: str) -> None:
        ...

    def clear_assignment(self, automacaoempresa: str) -> None:
        ...
