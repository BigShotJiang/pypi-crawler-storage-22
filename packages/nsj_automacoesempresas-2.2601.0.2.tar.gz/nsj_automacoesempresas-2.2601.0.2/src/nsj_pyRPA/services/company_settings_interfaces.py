from __future__ import annotations

from typing import Dict, List, Optional, Protocol

from nsj_pyRPA.dto.jobschedule_dto import JobScheduleDTO


class CompanySettingsPersistence(Protocol):
    def fetch_active_settings(self, company_code: str) -> List[Dict]:
        ...

    def list_existing_types(self, company_code: str) -> set[str]:
        ...

    def upsert_parameter(
        self,
        company_code: str,
        automation_type: str,
        payload: str,
        ativo: bool,
    ) -> Dict:
        ...

    def save_job_schedule(self, parametro_id, job: JobScheduleDTO) -> Optional[str]:
        ...

    def automation_jobtype(self) -> str:
        ...
