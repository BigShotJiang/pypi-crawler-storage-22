from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional, Protocol

from nsj_pyRPA.dto.execution_dto import ExecutionCompanyDTO, ExecutionDTO


@dataclass(frozen=True)
class ExecutionFilter:
    company_id: Optional[str] = None
    company_term: Optional[str] = None
    status: Optional[int] = None
    start_at: Optional[datetime] = None
    end_at: Optional[datetime] = None


class ExecutionRepository(Protocol):
    def list_executions(self, filters: ExecutionFilter) -> List[ExecutionDTO]:
        ...

    def list_companies(self) -> List[ExecutionCompanyDTO]:
        ...
