from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Protocol


@dataclass(frozen=True)
class ExecutionContext:
    empresa_id: str
    automacaoempresa: Optional[str]
    automacaoempresaparametro: Optional[str]
    processo: str
    tenant: Optional[int] = None


class ExecutionLogRepository(Protocol):
    def create_execution(self, context: ExecutionContext) -> str:
        ...

    def finish_execution(self, execucao_id: str, status: int, detalhes: Optional[str]) -> None:
        ...

    def fetch_company_by_parametro(self, parametro_id: str) -> Optional[dict]:
        ...

    def fetch_empresa_by_codigo(self, codigo: str) -> Optional[dict]:
        ...

    def fetch_empresa_by_automacaoempresa(self, automacaoempresa: str) -> Optional[str]:
        ...
