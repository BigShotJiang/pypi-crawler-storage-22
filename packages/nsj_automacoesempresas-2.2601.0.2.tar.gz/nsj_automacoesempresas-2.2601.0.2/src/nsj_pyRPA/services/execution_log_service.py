from __future__ import annotations

import logging
import traceback
from typing import Optional

from nsj_pyRPA.resources.envConfig import EnvConfig, getLog
from nsj_pyRPA.resources import automation_types
from nsj_pyRPA.services.execution_log_interfaces import (
    ExecutionContext,
    ExecutionLogRepository,
)


class ExecutionLogService:
    def __init__(self, repository: ExecutionLogRepository):
        self._repository = repository

    def start_execution(self, context: ExecutionContext) -> str:
        return self._repository.create_execution(context)

    def finish_execution(self, execucao_id: str, status: int, detalhes: Optional[str]) -> None:
        self._repository.finish_execution(execucao_id, status, detalhes)

    def start_log_collection(self) -> Optional["ExecutionLogCollector"]:
        logger = logging.getLogger()
        if not logger:
            return None
        formatter = self._build_log_formatter()
        handler = ExecutionLogCollector(formatter)
        logger.addHandler(handler)
        return handler

    def finish_log_collection(
        self,
        handler: Optional["ExecutionLogCollector"],
        fallback: Optional[str],
    ) -> Optional[str]:
        if handler is None:
            return fallback
        logger = logging.getLogger()
        logger.removeHandler(handler)
        detalhes = handler.text()
        if fallback and (not detalhes or fallback not in detalhes):
            detalhes = f"{detalhes}\n{fallback}".strip() if detalhes else fallback
        return detalhes

    def try_start_execution(self, item) -> Optional[str]:
        context = getattr(item, "execucao_context", None)
        if not isinstance(context, ExecutionContext):
            return None
        return self.try_start_execution_with_context(context)

    def try_start_execution_with_context(self, context: ExecutionContext) -> Optional[str]:
        try:
            return self.start_execution(context)
        except Exception as exc:
            getLog().atencao(f"Falha ao registrar execucao: {exc}")
            return None

    def try_start_execution_without_context(
        self,
        entrada: dict,
    ) -> Optional[str]:
        context = self._build_fallback_context_without_id(entrada)
        return self.try_start_execution_with_context(context)

    def try_finish_execution(
        self,
        execucao_id: str,
        status_value: int,
        detalhes: Optional[str],
    ) -> None:
        try:
            self.finish_execution(execucao_id, status_value, detalhes)
        except Exception as exc:
            getLog().atencao(f"Falha ao atualizar execucao: {exc}")

    def try_finish_orchestration_execution(
        self,
        execucao_id: Optional[str],
        collector: Optional["ExecutionLogCollector"],
        status_value: int,
        detalhes: Optional[object],
    ) -> None:
        if execucao_id is None:
            if collector is not None:
                self.finish_log_collection(collector, None)
            return
        detalhes_text = None
        if isinstance(detalhes, Exception):
            detalhes_text = f"{detalhes}\n{traceback.format_exc()}".strip()
        elif detalhes is not None:
            detalhes_text = str(detalhes)
        detalhes_text = self.finish_log_collection(collector, detalhes_text)
        try:
            self.finish_execution(execucao_id, status_value, detalhes_text)
        except Exception as log_exc:
            getLog().atencao(f"Falha ao atualizar execucao de orquestracao: {log_exc}")

    def build_orchestration_context(
        self,
        entrada: dict,
    ) -> Optional[ExecutionContext]:
        parametro_id = entrada.get("automacaoempresaparametro")
        tipo = entrada.get("automacaotipo")
        if parametro_id:
            row = self._repository.fetch_company_by_parametro(parametro_id)
            if row:
                processo = automation_types.automation_type_label(str(tipo or ""))
                return ExecutionContext(
                    empresa_id=str(row.get("empresa")),
                    automacaoempresa=row.get("automacaoempresa"),
                    automacaoempresaparametro=str(parametro_id),
                    processo=processo,
                    tenant=row.get("tenant"),
                )
        return self._build_fallback_context(entrada, tipo, parametro_id)

    def _build_fallback_context(
        self,
        entrada: dict,
        tipo: Optional[str],
        parametro_id: Optional[str] = None,
    ) -> Optional[ExecutionContext]:
        empresa_id = entrada.get("empresa")
        automacaoempresa = entrada.get("automacaoempresa")
        tenant = None
        if not empresa_id and automacaoempresa:
            empresa_id = self._repository.fetch_empresa_by_automacaoempresa(automacaoempresa)
        if not empresa_id:
            codigo = entrada.get("codigo")
            if codigo:
                row = self._repository.fetch_empresa_by_codigo(codigo)
                if row:
                    empresa_id = row.get("empresa")
                    tenant = row.get("tenant")
        if not empresa_id:
            return None
        processo = automation_types.automation_type_label(str(tipo or ""))
        return ExecutionContext(
            empresa_id=str(empresa_id),
            automacaoempresa=automacaoempresa,
            automacaoempresaparametro=str(parametro_id) if parametro_id else None,
            processo=processo,
            tenant=tenant,
        )

    def _build_fallback_context_without_id(
        self,
        entrada: dict,
    ) -> ExecutionContext:
        tipo = entrada.get("automacaotipo", None)
        parametro_id = entrada.get("automacaoempresaparametro", None)
        empresa_id = None
        automacaoempresa = None
        tenant = None

        if parametro_id:
            row = self._repository.fetch_company_by_parametro(parametro_id)
            if row:
                empresa_id = str(row.get("empresa"))
                automacaoempresa = row.get("automacaoempresa")
                tenant = row.get("tenant")
            else:
                parametro_id = None

        processo = automation_types.automation_type_label(str(tipo or ""))
        return ExecutionContext(
            empresa_id=empresa_id,
            automacaoempresa=automacaoempresa,
            automacaoempresaparametro=str(parametro_id) if parametro_id else None,
            processo=processo,
            tenant=tenant,
        )

    @staticmethod
    def _build_log_formatter() -> logging.Formatter:
        if EnvConfig.instance().notimelog:
            return logging.Formatter("%(message)s")
        return logging.Formatter(
            "%(levelname)s:%(asctime)s - %(message)s",
            datefmt="%H:%M:%S",
        )


class ExecutionLogCollector(logging.Handler):
    def __init__(self, formatter: logging.Formatter):
        super().__init__()
        self._lines = []
        self.setFormatter(formatter)

    def emit(self, record: logging.LogRecord) -> None:
        try:
            message = self.format(record)
        except Exception:
            message = record.getMessage()
        self._lines.append(message)

    def text(self) -> Optional[str]:
        if not self._lines:
            return None
        return "\n".join(self._lines)
