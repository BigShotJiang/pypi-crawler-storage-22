from __future__ import annotations

from typing import List

from nsj_pyRPA.dto.execution_dto import ExecutionCompanyDTO, ExecutionDTO
from nsj_pyRPA.services.execution_interfaces import ExecutionFilter, ExecutionRepository


class ExecutionService:
    def __init__(self, repository: ExecutionRepository):
        self._repository = repository

    def list_executions(self, filters: ExecutionFilter) -> List[ExecutionDTO]:
        return self._repository.list_executions(filters)

    def list_companies(self) -> List[ExecutionCompanyDTO]:
        return self._repository.list_companies()
