from __future__ import annotations

from typing import List, Protocol

from nsj_pyRPA.dto.notification_team_dto import NotificationTeamDTO


class NotificationTeamRepository(Protocol):
    def list_teams(self) -> List[NotificationTeamDTO]:
        ...

    def get_team(self, codigo: str) -> NotificationTeamDTO:
        ...

    def save_team(self, team: NotificationTeamDTO) -> NotificationTeamDTO:
        ...

    def delete_team(self, codigo: str) -> None:
        ...
