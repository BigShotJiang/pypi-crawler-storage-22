# PyRPA

### **Objetivo**

Utilitário para orquestar e gerar automações de execuções do Persona SQL

### **Configuração**
> Clonar o repositório e abir o repositório com algum editor, sugerimos o **VSCode**

> Copiar o arquivo **.env.dist** e renomea-lo para **.env**

> Abrir o terminal e execute os seguintes comandos 

    python -m venv ./.venv
    ./.venv/Scripts/Activate.ps1
    pip install -r .\requirements.txt

> Se usar o VSCode, é recomendado criar um arquivo de execução *launch.json*, clicando no icone de **Run and Debug**(icone com um inseto e um play), em seguida em **create a launch.json** > **Python** > **Python File** e use o seguinte conteudo.

```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Python: Arquivo Atual",
            "type": "python",
            "request": "launch",
            "program": "__main__.py",
            "console": "integratedTerminal",
            "args": [
                "-d", "integratto",  
                "-u",  "MESTRE", 
                "-p", "999999", 
                ... //demais argumentos
            ],
            "env": {
                "PATH_PERSONACLI": "C:\\Nasajon Sistemas\\Versao2502\\Integratto2\\personacli.exe"
            },
            "justMyCode": false //Informando "false" é possível depurar código que não pertençam ao projeto
        }
    ]
}
```
### **IMPORTANTE**
Para execução local durante do desenvolvimento, altere o valor do *PATH_PERSONACLI* no arquivo launch.json, para o caminho do personacli.exe do seu local.

### **Escopo**

Atualmente, o utilitário executa automações de processamento de cálculo de folha de funcionários e envio de eventos ao eSocial



### **Funcionamento**

O utilitário desenvolvido na linguagem Python e funciona através de linha de comando usando a biblioteca **argparse**.

### Execução

Para a execução do utilitário é necessário a passagem de parâmetros:

**Conexão**

| Parâmetro        | Curto | Descrição | Obrigatório? | Default |
|------------------|-------| --------- | ------------ | ------- |
| *-\-database* | *-d* | Nome do banco de dados para conexão | Sim * ||
| *-\-user* | *-u* | Usuário para conexão com o banco de dados | Não | postgres|
| *-\-password* | *-p* | Senha para conexão com o banco de dados | Não | postgres|
| *-\-host* | *-t* | IP ou nome do servidor do banco de dados | Não | localhost|
| *-\-port* | *-o* | Porta para conexão com o banco de dados | Não | 5432 |

**Processo**

| Parâmetro | Descrição | Obrigatório? |
|------------------| --------- | --------- |
| *-\-empresas* | Inicia a tela de configurações de automação por empresas | Não |
| *-\-notificacoes* | Inicia a tela de gerenciamento dos destinatários de notificações | Não |
| *-\-execucoes* | Inicia a tela para verificar logs de execução | Não |
| *-\-automacaoempresaparametro* | Informar o guid dos parametrôs de execução da automação | Sim |
| *-\-single_run* | Informar que o processo será executado sem referência do jobmanager  | Não |

### Exemplo
> python main.py -d integratto_master -u MESTRE -p 999999 -t localhost -o 5432 --automacaotipo "CALC_FOLHA_FUNC" --automacaoempresaparametro "970c5267-bdf1-4181-81ad-2135406431e3"

### **Algoritmo**
1. 

### **Gerar executável**

Para compilar um executável do utilitário PyRPA, execute o comando `.\build.bat` no cmd ou o arquivo **build.bat** presente na pasta raiz do projeto

Obs: No arquivo **version_info.txt** contém as informações relacionadas ao versionamento do executável, sempre que for feita uma alteração e em seguida for gerar um novo .exe para subir no instalador, deve-se alterar as informações de versão que existem nesse arquivo, considerando o padrão da Nasajon 2.YYMM.incremental, nos campos **filevers**, **prodvers** e **ProductVersion**.

Adicione o argumento **--noconsole** para gerar um executável que não abra o terminal, para casos em que aplicações chamaram o utilitário.

Também é possível gerar o executável usando o arquivo **build_local.bat** para executá-lo será necessário rodar o camanho pelo cmd.

