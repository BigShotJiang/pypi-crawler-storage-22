from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class ApuracaoInfoDTO:
    apuracao_id: str
    inicio: Optional[datetime]
    termino: Optional[datetime]
    status: int
