from __future__ import annotations

from dataclasses import dataclass


@dataclass
class WorkerDTO:
    trabalhador_id: str
    nome: str
