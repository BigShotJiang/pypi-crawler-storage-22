import json
import os
import subprocess
from pathlib import Path
from typing import Optional, Sequence, Union

from nsj_pyRPA.resources.const import UTILITARIO_PYMEURH, UTILITARIO_PYMEURH_DEB
from nsj_pyRPA.resources.envConfig import EnvConfig, getLog
from nsj_pyRPA.resources.criptografia_erp2 import CriptografiaERP2

class PyMeuRHRoteiro:
    def __init__(
        self,
        roteiro: str,
        empresa: Optional[str] = None,
        empresas: Optional[dict[str, str]] = None,
        grupo: Optional[str] = None,
        apuracao: Optional[str] = None,
        trabalhadores: Optional[Union[Sequence[str], str]] = None,
    ):
        self.roteiro = roteiro
        self.empresa = empresa
        self.empresas = empresas
        self.grupo = grupo
        self.apuracao = apuracao
        self.trabalhadores = trabalhadores

    def GetNomeAutomacao(self) -> str:
        return f"PyMeuRH - Roteiro {self.roteiro}"

    def _get_executable(self) -> Path:
        env_path = os.environ.get("PATH_PYMEURH")
        exe = Path(env_path) if env_path else Path(UTILITARIO_PYMEURH)
        if not exe.exists():
            raise Exception("Utilitario PyMeuRH.exe nao localizado")
        return exe

    def _args_padrao(self) -> list[str]:
        env = EnvConfig.instance()
        return [
            str(self._get_executable()),
            "-d",
            env.getDataBase_name(),
            "-u",
            env.getDataBase_user(),
            "-p",
            env.getDataBase_pass(),
            "-t",
            env.getDataBase_host(),
            "-o",
            str(env.getDataBase_port()),
            "-r",
            self.roteiro,
        ]

    def _args_roteiro(self) -> list[str]:
        args = []
        if self.empresa:
            args.extend(["-e", self.empresa])
        if self.empresas:
            args.extend(["-s", json.dumps(self.empresas)])
        if self.grupo:
            args.extend(["-g", self.grupo])
        if self.apuracao:
            args.extend(["-a", self.apuracao])
        if self.trabalhadores:
            args.extend(["-c", self._normalize_trabalhadores(self.trabalhadores)])
        return args

    @staticmethod
    def _normalize_trabalhadores(value) -> str:
        if value is None:
            return ""
        if isinstance(value, (list, tuple)):
            return json.dumps({"trabalhadores": [str(item) for item in value if str(item).strip()]})
        cleaned = str(value).strip()
        if not cleaned:
            return cleaned
        try:
            json.loads(cleaned)
            return cleaned
        except json.JSONDecodeError:
            pass
        lista = [item.strip() for item in cleaned.split(",") if item.strip()]
        return json.dumps({"trabalhadores": lista})

    def Processa(self):
        status_code = 0
        status_msg = None
        try:
            getLog().info(f"Executando automacao {self.GetNomeAutomacao()}")
            full_args = self._args_padrao() + self._args_roteiro()
            result = subprocess.run(full_args, capture_output=True, text=True)
            if result.stdout:
                for line in result.stdout.splitlines():
                    if line.strip():
                        getLog().info(line)
                status_msg = result.stdout
            if result.stderr:
                for line in result.stderr.splitlines():
                    if line.strip():
                        getLog().atencao(line)
                status_msg = (status_msg + "\n" if status_msg else "") + result.stderr
            if result.returncode is not None: status_code = result.returncode
            return status_code, status_msg
        except Exception as exc:
            return 3, f"[{self.GetNomeAutomacao()}] {exc}"
