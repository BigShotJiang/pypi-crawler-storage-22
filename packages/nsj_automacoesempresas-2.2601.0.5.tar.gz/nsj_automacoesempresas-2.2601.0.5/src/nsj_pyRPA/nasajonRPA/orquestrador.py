import ast, re
from datetime import datetime, timedelta

from nsj_gcf_utils.json_util import json_loads

from nsj_pyRPA.resources.const import *
import nsj_pyRPA.resources.automation_types as automation_types

from nsj_pyRPA.nasajonRPA.automacoes.processamentocalculofolha import ProcessamentoCalculoFolha
from nsj_pyRPA.nasajonRPA.automacoes.processamentocalculoadiantamentofolha import ProcessamentoCalculoAdiantamentoFolha
from nsj_pyRPA.nasajonRPA.automacoes.processamentocalculoferias import ProcessamentoCalculoFerias
from nsj_pyRPA.nasajonRPA.automacoes.AbstractPyMeuRH import PyMeuRHRoteiro

from nsj_pyRPA.nasajonRPA.automacoes.sincroniaesocialenvio import SincroniaESocialEnvio
from nsj_pyRPA.nasajonRPA.automacoes.sincroniaesocialconsulta import SincroniaESocialConsulta
from nsj_pyRPA.nasajonRPA.controller.rotinaautomatizada import RecuperaRotinaAutomatizada
from nsj_pyRPA.nasajonRPA.controller.automacoesempresas import RecuperaAutomacoesEmpresas
from nsj_pyRPA.repositories.company_repository import DbCompanyRepository
from nsj_pyRPA.services.execution_log_service import ExecutionContext
from nsj_pyRPA.resources.envConfig import getDb

opConsideraExcluido = "consideraeventoexcluido"
opConsideraRejeitado = "consideraeventorejeitado"


def Orquestrar(a_entrada : dict):
    
    _automacoes = []
    _single_run = a_entrada.get('single_run', False)
    
    if a_entrada.get('automacaoempresaparametro') is not None:
        _automacoesempresa = RecuperaAutomacoesEmpresas(a_entrada[automacaoempresaparametro], a_entrada[automacaotipo])
        tipo = _automacoesempresa.get('tipo')

        if tipo in automation_types.CALC_TYPES:
            _automacoes.extend( OrquestrarAutomacoesEmpresasCalculo(_automacoesempresa, _single_run) )
        elif tipo == automation_types.AUTOMATION_TYPE_PYMEURH_PONTO:
            _automacoes.extend( OrquestrarAutomacoesEmpresasPyMeuRH(_automacoesempresa, _single_run) )
        return _automacoes
    
    _rotina = RecuperaRotinaAutomatizada(a_entrada[ent_rotina].upper())

    if _rotina.processacalculo:
        _automacoes.extend( OrquestrarProcessamentoCalculo(a_entrada, _rotina.parametroprocessamentocalculo) )
    
    if _rotina.sincronizaesocial:
        _automacoes.extend( OrquestrarSincroniaESocial(a_entrada, _rotina.parametrosincronizacaoesocial) )
    
    if False :#_rotina.sincronizaesocialConsulta:
        _automacoes.extend( [SincroniaESocialConsulta(a_escopo=a_entrada[ent_escopo], a_faixa=a_entrada[ent_faixa] )] )
    
    
    return _automacoes

def OrquestrarSincroniaESocial(a_entrada : dict, a_parametros):
    _automacoes = []
    _parametros = json_loads( ast.literal_eval( a_parametros ) )

    _considera_excluido = opConsideraExcluido in _parametros
    _considera_rejeitado = opConsideraRejeitado in _parametros

    for chave, valor in _parametros.items():
        if bool(re.fullmatch(r"S-\d{4}", chave)):
            _automacoes.append( SincroniaESocialEnvio(a_escopo=a_entrada[ent_escopo],
                                                      a_faixa=a_entrada[ent_faixa],
                                                      a_tipo_evento=chave,
                                                      a_considera_excluido=_considera_excluido, 
                                                      a_considera_rejeitado=_considera_rejeitado ) ) 
            
    return _automacoes

def OrquestrarProcessamentoCalculo(a_entrada : dict, a_parametros):
    _automacoes = []

    _parametros = json_loads( ast.literal_eval( a_parametros ) )

    for chave, valor in _parametros.items():
        if chave == "Fo":
            _automacoes.append( ProcessamentoCalculoFolha( a_escopo=a_entrada[ent_escopo],
                                                           a_faixa=a_entrada[ent_faixa],
                                                           a_mes=a_entrada[ent_competencia],
                                                           a_ano=a_entrada[ent_ano],
                                                           a_semana=a_entrada[ent_semana],
                                                           a_situacoes=valor["situacoes"] ) )
            
        if chave == "Ad":
            _automacoes.append( ProcessamentoCalculoAdiantamentoFolha( a_escopo=a_entrada[ent_escopo],
                                                                       a_faixa=a_entrada[ent_faixa],
                                                                       a_mes=a_entrada[ent_competencia],
                                                                       a_ano=a_entrada[ent_ano],
                                                                       a_semana=a_entrada[ent_semana],
                                                                       a_semanadesconto=a_entrada[ent_semana_desc],
                                                                       a_situacoes=valor["situacoes"] ) )
            
        if chave == "Fe":
            _automacoes.append( ProcessamentoCalculoFerias( a_escopo=a_entrada[ent_escopo],
                                                            a_faixa=a_entrada[ent_faixa],
                                                            a_mes=a_entrada[ent_competencia],
                                                            a_ano=a_entrada[ent_ano],
                                                            a_ferias_em_dobro=valor["ferias_em_dobro"],
                                                            a_atualiza_pa=valor["atualizar_pa"]  ) )
            
    return _automacoes


def OrquestrarAutomacoesEmpresasCalculo(a_entrada: dict, _single_run: bool):
    _automacoes = []
    
    data_agendamento = a_entrada.get('agendamento')
    atraso_aceito = a_entrada.get('atrasoaceito', 0)
    _validate_agendamento(data_agendamento, atraso_aceito, _single_run)

    if a_entrada.get('tipo') == automation_types.AUTOMATION_TYPE_EMPLOYEES:
        automacao = ProcessamentoCalculoFolha(
            a_escopo='EMPRESA',
            a_faixa=a_entrada.get('codigo'),
            a_mes=str(data_agendamento.month),
            a_ano=str(data_agendamento.year),
            a_semana=None,
            a_situacoes=a_entrada.get('situacoes', "01,03..17") # variavel, adicionar arg na main
        )
        _attach_execution_context(automacao, a_entrada)
        _automacoes.append(automacao)
    
    return _automacoes


def OrquestrarAutomacoesEmpresasPyMeuRH(a_entrada: dict, _single_run: bool):
    _automacoes = []

    data_agendamento = a_entrada.get('agendamento')
    atraso_aceito = a_entrada.get('atrasoaceito', 0)
    _validate_agendamento(data_agendamento, atraso_aceito, _single_run)

    parametros = _coerce_payload(a_entrada.get("parametros"))
    params = parametros.get("params") if isinstance(parametros, dict) else {}
    if not isinstance(params, dict):
        params = {}

    empresa = str(a_entrada.get("empresa") or "").strip()
    tenant = a_entrada.get("tenant")
    if not empresa or tenant is None:
        raise Exception("Empresa ou tenant nao informados para executar o MeuRH.")

    repo = _get_company_repository()
    grupo = repo.get_company_group(empresa)
    use_workers = bool(params.get("use_workers", False))
    trabalhadores = params.get("trabalhadores") if use_workers else []
    if isinstance(trabalhadores, str):
        trabalhadores = []

    trabalhador_ref = str(trabalhadores[0]) if trabalhadores else None
    apuracao = repo.get_current_apuracao_id(tenant, empresa, trabalhador_ref)

    pre_automacao = PyMeuRHRoteiro(
        roteiro="APURACAO",
        empresas={'empresas': [empresa]},
    )
    automacao = PyMeuRHRoteiro(
        roteiro="PONTO",
        empresa=empresa,
        grupo=grupo,
        apuracao=apuracao,
        trabalhadores=trabalhadores or None,
    )
    _attach_execution_context_with_type(
        pre_automacao, a_entrada, automation_types.AUTOMATION_TYPE_PYMEURH_APURACOES
    )
    _automacoes.append(pre_automacao)

    _attach_execution_context(automacao, a_entrada)
    _automacoes.append(automacao)
    return _automacoes


def _attach_execution_context(automacao, a_entrada: dict) -> None:
    empresa_id = a_entrada.get("empresa")
    if not empresa_id:
        return
    processo = automation_types.automation_type_label(str(a_entrada.get("tipo") or ""))
    context = ExecutionContext(
        empresa_id=str(empresa_id),
        automacaoempresa=a_entrada.get("automacaoempresa"),
        automacaoempresaparametro=a_entrada.get("automacaoempresaparametro"),
        processo=processo,
        tenant=None,
    )
    setattr(automacao, "execucao_context", context)


def _attach_execution_context_with_type(automacao, a_entrada: dict, automation_type: str) -> None:
    empresa_id = a_entrada.get("empresa")
    if not empresa_id:
        return
    processo = automation_types.automation_type_label(str(automation_type))
    context = ExecutionContext(
        empresa_id=str(empresa_id),
        automacaoempresa=a_entrada.get("automacaoempresa"),
        automacaoempresaparametro=a_entrada.get("automacaoempresaparametro"),
        processo=processo,
        tenant=None,
    )
    setattr(automacao, "execucao_context", context)


def _validate_agendamento(data_agendamento, atraso_aceito, _single_run) -> None:
    hoje = datetime.now()
    if data_agendamento is None:
        raise Exception('A operacao nao pode ser realizada sem data de agendamento definida.')
    if _single_run:
        return
    fora_janela = hoje < data_agendamento
    if atraso_aceito is not None:
        limite = data_agendamento + timedelta(minutes=atraso_aceito or 0)
        fora_janela = fora_janela or hoje > limite
    if fora_janela:
        raise Exception('A operação não está agendada para o presente momento.');


def _coerce_payload(payload) -> dict:
    if payload is None:
        return {}
    if isinstance(payload, dict):
        return payload
    try:
        return json_loads(payload)
    except Exception:
        return {}

def _get_company_repository() -> DbCompanyRepository:
    db = getDb()
    if db is None:
        raise RuntimeError("Conexao com o banco nao configurada.")
    return DbCompanyRepository(db)
