from __future__ import annotations

from typing import Dict, List, Optional, Protocol
from datetime import date

from nsj_pyRPA.dto.company_dto import CompanyDTO
from nsj_pyRPA.dto.apuracao_dto import ApuracaoInfoDTO
from nsj_pyRPA.dto.worker_dto import WorkerDTO
from nsj_pyRPA.services.company_interfaces import CompanyRepository


def _to_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().lower()
    return text in {"1", "true", "t", "y", "yes", "sim", "s"}


class DbCompanyRepository(CompanyRepository):
    """Database-backed implementation that reads companies from Persona tables."""

    def __init__(self, db_adapter):
        self._db = db_adapter

    def list_companies(self) -> List[CompanyDTO]:
        sql = f"""
            SELECT
                e.codigo AS codigo,
                e.razaosocial AS nome,
                e.empresa as empresa,
                e.tenant AS tenant,
                ae.automacaoempresa AS automacaoempresa,
                ae.padrao AS padrao,
                ae.ativo AS ativo,
                ae.usapadrao AS use_default
            FROM ns.empresas e
            LEFT JOIN persona.automacoesempresas ae
            ON ae.empresa = e.empresa
            ORDER BY e.codigo
        """
        rows = self._db.execute_query(sql)
        return [
            CompanyDTO(
                codigo=str(row["codigo"]),
                nome=str(row.get("nome") or ""),
                padrao=_to_bool(row.get("padrao")),
                ativo=_to_bool(row.get("ativo", True)),
                empresa=str(row.get("empresa")),
                automacaoempresa=row.get("automacaoempresa"),
                tenant=int(row.get("tenant")),
                use_default=_to_bool(row.get("use_default")),
                notified_teams=str(row.get("notified_teams") or ""),
            )
            for row in rows
        ]
        
    def get_company_by_id(self, empresa_id: str) -> CompanyDTO:
        sql = f"""
            SELECT
                e.codigo AS codigo,
                e.razaosocial AS nome,
                e.empresa  AS empresa,
                e.tenant AS tenant,
                ae.padrao AS padrao,
                ae.usapadrao AS use_default,
                ae.automacaoempresa AS automacaoempresa,
                ae.ativo AS ativo
            FROM ns.empresas e
            LEFT JOIN persona.automacoesempresas ae
              ON ae.empresa = e.empresa
            WHERE e.empresa = :empresa
        """
        row = self._db.execute_query_first_result(sql, empresa=empresa_id)
        if row is None:
            raise ValueError(f"Empresa '{empresa_id}' não encontrada")

        return CompanyDTO(
            codigo=str(row["codigo"]),
            nome=str(row.get("nome") or ""),
            padrao=_to_bool(row.get("padrao")),
            ativo=_to_bool(row.get("ativo", True)),
            empresa=str(row["empresa"]),
            automacaoempresa=row.get("automacaoempresa"),
            tenant=int(row.get("tenant")),
            use_default=_to_bool(row.get("use_default")),
            notified_teams=str(row.get("notified_teams") or ""),
        )

        
    def save_company(self, company: CompanyDTO) -> CompanyDTO:
        columns = [
            "empresa",
            "codigo",
            "nome",
            "ativo",
            "padrao",
            "tenant",
            "usapadrao",
            # "equipesnotificadas",
        ]
        values = [
            ":empresa",
            ":codigo",
            ":nome",
            ":ativo",
            ":padrao",
            ":tenant",
            ":use_default",
            # ":notified_teams",
        ]
        updates = [
            "ativo = :ativo",
            "padrao = :padrao",
            "usapadrao = :use_default",
            # "equipesnotificadas = :notified_teams",
        ]

        sql = f"""    
            INSERT INTO persona.automacoesempresas (
                {', '.join(columns)}
            ) VALUES (
                {', '.join(values)}
            ) ON CONFLICT (empresa)
            DO UPDATE
                SET {', '.join(updates)}
            RETURNING empresa;
        """

        params = {
            "empresa": company.empresa,
            "codigo": company.codigo,
            "nome": company.nome,
            "ativo": company.ativo,
            "padrao": company.padrao,
            "tenant": company.tenant,
            "use_default": company.use_default,
            # "notified_teams": company.notified_teams,
        }

        affected, returning = self._db.execute(sql, **params)
        print("affected:", affected, "returning:", returning)
        if not returning:
            raise RuntimeError("Insert/update did not return data")

        empresa = returning[0]["empresa"]
        
        updated = self.get_company_by_id(empresa)
        return updated

    def list_workers(self, tenant: int, empresa_id: str) -> List[WorkerDTO]:
        sql = """
            SELECT
                t.trabalhador AS trabalhador_id,
                t.nome AS nome
            FROM persona.trabalhadores t
            WHERE t.tenant = :tenant
              AND t.empresa = :empresa
            ORDER BY t.nome
        """
        rows = self._db.execute_query(sql, tenant=tenant, empresa=empresa_id)
        return [
            WorkerDTO(
                trabalhador_id=str(row.get("trabalhador_id") or row.get("trabalhador")),
                nome=str(row.get("nome") or ""),
            )
            for row in rows
        ]

    def get_company_group(self, empresa_id: str) -> str:
        sql = """
            SELECT grupoempresarial
            FROM ns.empresas
            WHERE empresa = :empresa
            LIMIT 1
        """
        row = self._db.execute_query_first_result(sql, empresa=empresa_id)
        grupo = row.get("grupoempresarial") if row else None
        if not grupo:
            raise Exception("Grupo empresarial nao encontrado para a empresa informada.")
        return str(grupo)

    def get_current_apuracao_id(
        self, tenant: int, empresa_id: str, trabalhador_id: Optional[str]
    ) -> str:
        dias_apuracao = 1
        sql = """
            WITH
                trabalhadores_apuracoes as
                (
                    SELECT ap.apuracaoponto, ap.inicioapuracao, ap.terminoapuracao, ap.status,
                        CASE WHEN (ap.trabalhador IS NOT NULL)      THEN 1
                             WHEN (ap.estabelecimento IS NOT NULL)  THEN 3
                        ELSE 4 END as nivel
                    FROM ponto.apuracoesponto ap
                    WHERE (
                         ap.trabalhador = :trabalhador
                        OR ap.empresa = :empresa
                    ) AND (
                        :dia BETWEEN ap.inicioapuracao AND ap.terminoapuracao
                        OR (ap.terminoapuracao > :dia::date - INTERVAL '1 month' AND ap.status = 1)
                    )
                )
                SELECT apuracaoponto, inicioapuracao, terminoapuracao
                FROM trabalhadores_apuracoes
                WHERE status = 0
                OR (status = 1 AND terminoapuracao = :dia::date - :dias_ap::interval)
                ORDER BY nivel LIMIT 1;
        """
        row = self._db.execute_query_first_result(
            sql,
            tenant=tenant,
            dia=date.today(),
            trabalhador=trabalhador_id,
            empresa=empresa_id,
            dias_ap=dias_apuracao,
        )
        apuracao = row.get("apuracaoponto") if row else None
        if not apuracao:
            raise Exception("Apuracao atual nao encontrada para a empresa informada.")
        return str(apuracao)

    def get_current_apuracao(self, tenant: int, empresa_id: str) -> Optional[ApuracaoInfoDTO]:
        sql = """
            WITH
                trabalhadores_apuracoes as
                (
                    SELECT ap.apuracaoponto, ap.inicioapuracao, ap.terminoapuracao, ap.status,
                        CASE WHEN (ap.trabalhador IS NOT NULL)      THEN 1
                             WHEN (ap.estabelecimento IS NOT NULL)  THEN 3
                        ELSE 4 END as nivel
                    FROM ponto.apuracoesponto ap
                    WHERE ap.empresa = :empresa
                    AND (
                        :dia BETWEEN ap.inicioapuracao AND ap.terminoapuracao
                        OR (ap.terminoapuracao > :dia::date - INTERVAL '1 month' AND ap.status = 1)
                    )
                )
                SELECT apuracaoponto, inicioapuracao, terminoapuracao, status
                FROM trabalhadores_apuracoes
                WHERE status = 0
                OR (status = 1 AND terminoapuracao = :dia::date - interval '1 day')
                ORDER BY terminoapuracao asc
                LIMIT 1;
        """
        row = self._db.execute_query_first_result(
            sql,
            dia=date.today(),
            empresa=empresa_id,
        )
        if not row:
            return None
        return ApuracaoInfoDTO(
            apuracao_id=str(row.get("apuracaoponto")),
            inicio=row.get("inicioapuracao"),
            termino=row.get("terminoapuracao"),
            status=int(row.get("status") or 0),
        )

    def get_last_execution(self, automacaoempresa: str, automation_type: str) -> Optional[dict]:
        sql = """
            SELECT
                ex.datainicio AS data_inicio,
                ex.datafim AS data_fim,
                ex.status AS status
            FROM persona.automacoesexecucoes ex
            INNER JOIN persona.automacoesempresasparametros ap
                ON ap.automacaoempresaparametro = ex.automacaoempresaparametro
            WHERE ap.automacaoempresa = :automacaoempresa
              AND ap.tipo = :tipo
            ORDER BY ex.datainicio DESC
            LIMIT 1
        """
        return self._db.execute_query_first_result(
            sql,
            automacaoempresa=automacaoempresa,
            tipo=automation_type,
        )
