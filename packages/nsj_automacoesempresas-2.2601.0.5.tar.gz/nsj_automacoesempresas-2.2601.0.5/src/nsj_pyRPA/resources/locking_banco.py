advLockExportador = 100
advLockPyMeuRH = 101
advLockPyRPA = 102

from nsj_pyRPA.resources.envConfig import getDb


def _lock_key(value=None):
    return advLockPyRPA if value is None else value

def advisory_lock(lock_key=None):
    try:
        _execute = getDb().execute_query(
            "select pg_try_advisory_lock(:identificador) resultado",
            identificador=_lock_key(lock_key),
        )

        if len(_execute) > 0:
            return _execute[0]["resultado"]
        else :
            return False
    except:
        return False
    

def advisory_unlock(lock_key=None):
    try:
        _execute = getDb().execute_query(
            "select pg_advisory_unlock(:identificador) resultado",
            identificador=_lock_key(lock_key),
        )

        if len(_execute) > 0:
            return _execute[0]["resultado"]
        else :
            return False
    except:
        return False
    

def advisory_unlock_all():
    try:
        _execute = getDb().execute("select pg_advisory_unlock_all()")
    except:
        return False
