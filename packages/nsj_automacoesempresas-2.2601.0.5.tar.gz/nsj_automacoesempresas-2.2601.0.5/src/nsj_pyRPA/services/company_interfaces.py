from __future__ import annotations

from typing import List, Optional, Protocol

from nsj_pyRPA.dto.company_dto import CompanyDTO
from nsj_pyRPA.dto.notification_team_dto import NotificationTeamDTO
from nsj_pyRPA.dto.apuracao_dto import ApuracaoInfoDTO
from nsj_pyRPA.dto.worker_dto import WorkerDTO


class CompanyRepository(Protocol):
    """Abstraction for company CRUD operations."""

    def list_companies(self) -> List[CompanyDTO]:
        ...

    def save_company(self, company: CompanyDTO) -> Optional[CompanyDTO]:
        ...

    def list_workers(self, tenant: int, empresa_id: str) -> List[WorkerDTO]:
        ...

    def get_company_group(self, empresa_id: str) -> str:
        ...

    def get_current_apuracao_id(
        self, tenant: int, empresa_id: str, trabalhador_id: Optional[str]
    ) -> str:
        ...

    def get_current_apuracao(
        self, tenant: int, empresa_id: str
    ) -> Optional[ApuracaoInfoDTO]:
        ...

    def get_last_execution(
        self, automacaoempresa: str, automation_type: str
    ) -> Optional[dict]:
        ...


class NotificationTeamAssignmentStore(Protocol):
    """Abstraction for linking companies and notification teams."""

    def get_assigned_team(self, automacaoempresa: str) -> Optional[NotificationTeamDTO]:
        ...

    def assign_team(self, automacaoempresa: str, equipe_id: str) -> None:
        ...

    def clear_assignment(self, automacaoempresa: str) -> None:
        ...
