import ctypes
import logging
import sys

from ctypes import wintypes

GWL_EXSTYLE = -20
GWLP_HWNDPARENT = -8

WS_EX_APPWINDOW = 0x00040000
WS_EX_TOOLWINDOW = 0x00000080

SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_NOZORDER = 0x0004
SWP_NOACTIVATE = 0x0010
SWP_FRAMECHANGED = 0x0020


def set_owned_and_hide_taskbar(hwnd_child: int, hwnd_owner: int, *, use_toolwindow_fallback: bool = False, logger=None) -> bool:
    if not _is_windows():
        return False
    if not _is_valid_hwnd(hwnd_child) or not _is_valid_hwnd(hwnd_owner):
        _log_warning(logger, f"owner-hwnd ignorado (child={hwnd_child}, owner={hwnd_owner})")
        return False

    try:
        setter = _get_set_window_long()
        getter = _get_get_window_long()
        user32 = ctypes.windll.user32

        ctypes.set_last_error(0)
        previous = setter(hwnd_child, GWLP_HWNDPARENT, hwnd_owner)
        error = ctypes.get_last_error()
        if previous == 0 and error != 0:
            _log_warning(logger, f"SetWindowLongPtrW(GWLP_HWNDPARENT) falhou (erro={error})")
            return False

        ex_style = getter(hwnd_child, GWL_EXSTYLE)
        ex_style = ex_style & ~WS_EX_APPWINDOW
        if use_toolwindow_fallback:
            ex_style = ex_style | WS_EX_TOOLWINDOW
        setter(hwnd_child, GWL_EXSTYLE, ex_style)

        user32.SetWindowPos(
            hwnd_child,
            0,
            0,
            0,
            0,
            0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED | SWP_NOACTIVATE,
        )
        return True
    except Exception as exc:
        _log_warning(logger, f"Falha ao ajustar taskbar window: {exc}")
        return False


def _get_set_window_long():
    user32 = ctypes.windll.user32
    if ctypes.sizeof(ctypes.c_void_p) == ctypes.sizeof(ctypes.c_longlong) and hasattr(user32, "SetWindowLongPtrW"):
        func = user32.SetWindowLongPtrW
        func.restype = ctypes.c_void_p
        func.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_void_p]
        return func
    func = user32.SetWindowLongW
    func.restype = ctypes.c_long
    func.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_long]
    return func


def _get_get_window_long():
    user32 = ctypes.windll.user32
    if ctypes.sizeof(ctypes.c_void_p) == ctypes.sizeof(ctypes.c_longlong) and hasattr(user32, "GetWindowLongPtrW"):
        func = user32.GetWindowLongPtrW
        func.restype = ctypes.c_void_p
        func.argtypes = [wintypes.HWND, ctypes.c_int]
        return func
    func = user32.GetWindowLongW
    func.restype = ctypes.c_long
    func.argtypes = [wintypes.HWND, ctypes.c_int]
    return func


def _is_windows() -> bool:
    return sys.platform == "win32"


def _is_valid_hwnd(value) -> bool:
    try:
        return int(value) > 0
    except (TypeError, ValueError):
        return False


def _log_warning(logger, message: str) -> None:
    if logger is None:
        logging.getLogger(__name__).warning(message)
        return
    if hasattr(logger, "atencao"):
        logger.atencao(message)
    elif hasattr(logger, "warning"):
        logger.warning(message)
    else:
        logging.getLogger(__name__).warning(message)
