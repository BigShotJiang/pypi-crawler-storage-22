from nsj_rest_lib.decorator.function_type import FunctionType
from nsj_rest_lib.entity.function_type_base import ListFunctionTypeBase


class ListFunctionType(FunctionType):
    type_base_class = ListFunctionTypeBase
