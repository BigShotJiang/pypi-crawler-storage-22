from nsj_gcf_utils.log_time import log_time
from nsj_gcf_utils.log_time import log_time_context
