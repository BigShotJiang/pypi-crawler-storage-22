from django.conf import settings
from django.urls import include, path

from . import routers, views

# Register all endpoints as a top-level resource
router = routers.BulkRouter(trailing_slash=settings.APPEND_SLASH)

# Resources pinned to API index at /
router.register(r"sites", views.SiteViewSet)
router.register(r"attributes", views.AttributeViewSet)
router.register(r"changes", views.ChangeViewSet)
router.register(r"circuits", views.CircuitViewSet)
router.register(r"devices", views.DeviceViewSet)
router.register(r"interfaces", views.InterfaceViewSet)
router.register(r"networks", views.NetworkViewSet)
router.register(r"protocols", views.ProtocolViewSet)
router.register(r"protocol_types", views.ProtocolTypeViewSet)
router.register(r"users", views.UserViewSet)
router.register(r"values", views.ValueViewSet)

# Nested router for resources under /sites
sites_router = routers.BulkNestedRouter(
    router, r"sites", lookup="site", trailing_slash=settings.APPEND_SLASH
)

# Resources that are nested under /sites
sites_router.register(r"attributes", views.AttributeViewSet)
sites_router.register(r"changes", views.ChangeViewSet)
sites_router.register(r"circuits", views.CircuitViewSet)
sites_router.register(r"devices", views.DeviceViewSet)
sites_router.register(r"interfaces", views.InterfaceViewSet)
sites_router.register(r"networks", views.NetworkViewSet)
sites_router.register(r"protocols", views.ProtocolViewSet)
sites_router.register(r"protocol_types", views.ProtocolTypeViewSet)
sites_router.register(r"values", views.ValueViewSet)

# Wire up our API using automatic URL routing.
# Additionally, we include login URLs for the browsable API.
urlpatterns = [
    # API routes
    path("", include(router.urls)),
    path("", include(sites_router.urls)),
    # Browsable API auth login
    path("auth/", include("rest_framework.urls", namespace="rest_framework")),
    # API auth_token login/verify (email/secret_key)
    path(
        "authenticate/",
        views.AuthTokenLoginView.as_view(),
        name="authenticate",
    ),
    path(
        "verify_token/",
        views.AuthTokenVerifyView.as_view(),
        name="verify_token",
    ),
]
