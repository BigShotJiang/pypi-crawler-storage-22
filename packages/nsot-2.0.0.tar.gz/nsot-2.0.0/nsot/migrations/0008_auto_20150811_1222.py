# -*- coding: utf-8 -*-

from django.db import models, migrations
import django.db.models.deletion

class Migration(migrations.Migration):

    dependencies = [
        ("nsot", "0007_auto_20150811_1201"),
    ]

    operations = [
        migrations.AlterField(
            model_name="assignment",
            name="address",
            field=models.ForeignKey(
                related_name="assignments",
                to="nsot.Network",
                on_delete=django.db.models.deletion.CASCADE,
            ),
        ),
    ]
