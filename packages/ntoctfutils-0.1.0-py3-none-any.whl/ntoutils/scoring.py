import math
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass


@dataclass
class Task:
    id: str
    name: str
    base_score: int
    min_score: int
    category: str
    solves_count: int = 0
    first_solve_time: Optional[datetime] = None


@dataclass
class Solve:
    task_id: str
    user_id: str
    team_id: Optional[str]
    solved_at: datetime
    flag: str


class ScoreCalculator:
    """
    Калькулятор динамического скоринга задач.
    """

    def __init__(self, decay_factor: float = 0.1):
        self.decay_factor = decay_factor

    def calculate_score(
            self,
            base_score: int,
            min_score: int,
            solves_count: int
    ) -> int:
        """
        Вычисляет текущий балл задачи на основе количества решений.

        """
        if solves_count == 0:
            return base_score

        diff = base_score - min_score
        decay = math.exp(-self.decay_factor * solves_count)
        score = min_score + diff * decay

        return int(round(score))

def calculate_dynamic_score(
        base_score: int,
        min_score: int,
        solves_count: int,
        decay_factor: float = 0.1
) -> int:
    """
    Вычисляет динамический балл задачи.
    """
    calculator = ScoreCalculator(decay_factor)
    return calculator.calculate_score(base_score, min_score, solves_count)


def get_task_score(
        task: Task,
        calculator: Optional[ScoreCalculator] = None
) -> int:
    """
    Получает текущий балл задачи с учётом динамического скоринга.
    """
    if calculator is None:
        calculator = ScoreCalculator()

    return calculator.calculate_score(
        task.base_score,
        task.min_score,
        task.solves_count
    )