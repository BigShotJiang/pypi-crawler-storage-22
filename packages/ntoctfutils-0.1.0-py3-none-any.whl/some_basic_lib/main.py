def main():
    print("Called main function from utils.py")
if __name__ == "__main__":
    main()
