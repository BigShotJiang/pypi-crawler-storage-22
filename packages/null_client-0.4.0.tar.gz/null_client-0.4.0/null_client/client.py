from typing import Any, Self, NewType, TypedDict, Unpack
import enum
from collections.abc import Iterator

import httpx
from pydantic import BaseModel

Hash = NewType("Hash", str)


class NullClientError(Exception):
    """Base exception for null client errors."""

    pass


class RecordConflictError(NullClientError):
    """Raised when record hash conflict occurs (optimistic locking failure)."""

    def __init__(self, expected: str, current: str, message: str):
        self.expected = expected
        self.current = current
        super().__init__(message)


class RecordAlreadyDeletedError(NullClientError):
    """Raised when record is already deleted."""

    def __init__(self, deleted_at: int):
        self.deleted_at = deleted_at
        super().__init__(f"Record already deleted at {deleted_at}")


class BlobNotFoundError(NullClientError):
    def __init__(self, hash_: Hash):
        self.hash = hash_
        super().__init__(f"blob not found: {hash_}")


class TreeNodeType(enum.StrEnum):
    DATA = "data"
    TREE = "tree"


class SortOrder(enum.StrEnum):
    ASC = "asc"
    DESC = "desc"


class SortBy:
    """
    Sort field for list_records. Use one of the constants or SortBy.metadata(path).
    """

    CREATED_AT = "created_at"
    ID = "id"
    KIND = "kind"
    NAMESPACE = "namespace"

    @staticmethod
    def metadata(path: str) -> str:
        """Sort by a JSON metadata field. Path uses dot notation. Missing field sorts last."""
        return f"metadata:{path}"


class TreeNode(BaseModel):
    hash: Hash
    type: TreeNodeType


class TreeResponse(BaseModel):
    hash: Hash
    nodes: list[TreeNode]


class RecordResponse(BaseModel):
    hash: Hash
    id: str | None = None  # None for immutable records
    content: Hash
    prev: Hash | None = None
    kind: str
    namespace: str | None = None
    created_at: int | None = None  # None for immutable records
    deleted_at: int | None = None
    metadata: dict[str, Any] = {}
    # GC policy: keep at most this many versions per record (None = keep all)
    max_versions: int | None = None


class ListRecordsResponse(BaseModel):
    records: list[RecordResponse]
    next_cursor: str | None = None
    has_more: bool


class BatchBlobStatus(enum.StrEnum):
    CREATED = "created"
    ALREADY_EXISTS = "already_exists"


class BatchBlobResult(BaseModel):
    hash: Hash
    status: BatchBlobStatus
    size: int


class BatchBlobsResponse(BaseModel):
    results: list[BatchBlobResult]


class CreatedAtFilter:
    """
    Filter for created_at timestamp field.

    Usage:
        from null_client import created_at

        # Records created after a timestamp
        records = client.list_records(
            created_at_filters=[created_at > 1738108800000000000]
        )

        # Records created in a time range
        records = client.list_records(
            created_at_filters=[
                created_at >= 1735908800000000000,
                created_at < 1738108800000000000,
            ]
        )
    """

    def __init__(self) -> None:
        self._op: str | None = None
        self._value: int | None = None

    def __eq__(self, value: int) -> Self:  # type: ignore[override]
        return self._create_filter("eq", value)

    def __ne__(self, value: int) -> Self:  # type: ignore[override]
        return self._create_filter("ne", value)

    def __gt__(self, value: int) -> Self:
        return self._create_filter("gt", value)

    def __lt__(self, value: int) -> Self:
        return self._create_filter("lt", value)

    def __ge__(self, value: int) -> Self:
        return self._create_filter("gte", value)

    def __le__(self, value: int) -> Self:
        return self._create_filter("lte", value)

    def _create_filter(self, op: str, value: int) -> Self:
        f = type(self)()
        f._op = op
        f._value = value
        return f

    def to_query_param(self) -> str:
        if self._op is None or self._value is None:
            raise ValueError("Filter must have an operator (use ==, !=, >, <, >=, <=)")
        return f"{self._op}:{self._value}"


# Singleton instance for building created_at filters
created_at = CreatedAtFilter()


class MetadataFilter:
    """
    Filter for metadata fields.

    Usage:
        from null_client import MetadataFilter as m

        # Filter by metadata field
        records = client.list_records(
            metadata_filters=[m("priority") > 5]
        )
    """

    def __init__(self, path: str):
        self.path = path
        self._op: str | None = None
        self._value: Any = None

    def __eq__(self, value: Any) -> Self:  # type: ignore[override]
        return self._create_filter("eq", value)

    def __ne__(self, value: Any) -> Self:  # type: ignore[override]
        return self._create_filter("ne", value)

    def __gt__(self, value: Any) -> Self:
        return self._create_filter("gt", value)

    def __lt__(self, value: Any) -> Self:
        return self._create_filter("lt", value)

    def __ge__(self, value: Any) -> Self:
        return self._create_filter("gte", value)

    def __le__(self, value: Any) -> Self:
        return self._create_filter("lte", value)

    def contains(self, value: str) -> Self:
        return self._create_filter("contains", value)

    def exists(self) -> Self:
        return self._create_filter("exists", None)

    def _create_filter(self, op: str, value: Any) -> Self:
        f = type(self)(self.path)
        f._op = op
        f._value = value
        return f

    def to_query_param(self) -> str:
        """Convert to the API query parameter format: path:op:value"""
        if self._op is None:
            raise ValueError(
                "Filter must have an operator (use ==, !=, >, <, >=, <=, contains(), or exists())"
            )

        if self._op == "exists":
            return f"{self.path}:{self._op}"

        if isinstance(self._value, bool):
            value_str = "true" if self._value else "false"
        elif self._value is None:
            value_str = "null"
        else:
            value_str = str(self._value)

        return f"{self.path}:{self._op}:{value_str}"


class ListRecordsParams(TypedDict, total=False):
    kind: str | list[str] | None
    namespace: str | None
    metadata_filters: list[MetadataFilter | str] | None
    sort_by: str | None
    sort_order: SortOrder | None
    limit: int | None
    as_of: int | None
    include_deleted: bool


class Client:
    def __init__(
        self,
        base_url: str = "http://localhost:3001",
        timeout: float = 10.0,
    ):
        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(timeout=timeout)

    def __enter__(self) -> "Client":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def _check_record_errors(self, resp: httpx.Response) -> None:
        if resp.status_code == 409:
            data = resp.json()
            raise RecordConflictError(
                expected=data.get("expected", ""),
                current=data.get("current", ""),
                message=data.get("message", "Hash conflict"),
            )
        if resp.status_code == 410:
            data = resp.json()
            raise RecordAlreadyDeletedError(deleted_at=data.get("deleted_at", 0))
        resp.raise_for_status()

    def close(self) -> None:
        self._client.close()

    def put_blob(self, data: bytes) -> Hash:
        resp = self._client.post(f"{self.base_url}/blobs", content=data)
        resp.raise_for_status()
        return Hash(resp.text.strip())

    def put_blobs_batch(self, blobs: list[bytes]) -> BatchBlobsResponse:
        """
        Upload multiple blobs in one multipart request.

        Args:
            blobs: List of blob payloads (bytes).

        Returns:
            BatchBlobsResponse with one result per blob (hash, status, size).
            status is "created" for new blobs or "already_exists" for deduplicated.
        """
        if not blobs:
            return BatchBlobsResponse(results=[])
        files = [(f"blob{i}", (None, blob)) for i, blob in enumerate(blobs)]
        resp = self._client.post(
            f"{self.base_url}/blobs/batch",
            files=files,
        )
        resp.raise_for_status()
        return BatchBlobsResponse.model_validate(resp.json())

    def get_blob(self, hash_: Hash) -> bytes:
        resp = self._client.get(f"{self.base_url}/blobs/{hash_}")
        if resp.status_code == 404:
            raise BlobNotFoundError(hash_)

        resp.raise_for_status()
        return resp.content

    def get_blobs_batch(self, hashes: list[Hash]) -> list[bytes]:
        """
        Download multiple blobs in one request.

        Args:
            hashes: List of blob hashes to fetch.

        Returns:
            List of blob contents in the same order as hashes.

        Raises:
            BlobNotFoundError: If any requested blob is missing (server returns 404).
        """
        if not hashes:
            return []
        payload = {"hashes": [h for h in hashes]}
        resp = self._client.post(
            f"{self.base_url}/blobs/batch/get",
            json=payload,
        )
        if resp.status_code == 404:
            raise BlobNotFoundError(hashes[0])  # Server doesn't indicate which
        resp.raise_for_status()
        buf = resp.content
        result: list[bytes] = []
        pos = 0
        while pos < len(buf):
            if pos + 4 > len(buf):
                raise ValueError("Batch response truncated at length prefix")
            length = int.from_bytes(buf[pos : pos + 4], "big")
            pos += 4
            if pos + length > len(buf):
                raise ValueError("Batch response truncated at blob data")
            result.append(bytes(buf[pos : pos + length]))
            pos += length
        if len(result) != len(hashes):
            raise ValueError(
                f"Batch response blob count {len(result)} does not match request {len(hashes)}"
            )
        return result

    def has_blob(self, hash_: Hash) -> bool:
        resp = self._client.head(f"{self.base_url}/blobs/{hash_}")
        return resp.status_code == 200

    def create_tree(self, hashes: list[Hash]) -> TreeResponse:
        resp = self._client.post(
            f"{self.base_url}/trees",
            json={"hashes": hashes},
        )
        resp.raise_for_status()
        return TreeResponse.model_validate(resp.json())

    def get_tree(self, hash_: Hash, flatten: bool = False) -> TreeResponse:
        params = {"flatten": "true"} if flatten else {}
        resp = self._client.get(f"{self.base_url}/trees/{hash_}", params=params)
        resp.raise_for_status()
        return TreeResponse.model_validate(resp.json())

    def create_record(
        self,
        kind: str,
        content: Hash,
        metadata: dict[str, Any] | None = None,
        namespace: str | None = None,
        immutable: bool = False,
        max_versions: int | None = None,
    ) -> RecordResponse:
        """
        Create a new record.

        Args:
            kind: Record type
            content: Content hash
            metadata: Record metadata
            namespace: Optional namespace
            immutable: If True, creates an immutable record (no id/created_at, deterministic hash).
                      If False, creates a versioned record (with id/created_at, queryable).
            max_versions: GC policy: keep at most this many versions (None = keep all). Min 1 if set.

        Returns:
            The created record
        """
        payload: dict[str, Any] = {"kind": kind, "content": content}
        if namespace is not None:
            payload["namespace"] = namespace
        if immutable:
            payload["immutable"] = immutable
        if metadata:
            payload["metadata"] = metadata
        if max_versions is not None:
            payload["max_versions"] = max_versions

        resp = self._client.post(f"{self.base_url}/records", json=payload)
        resp.raise_for_status()
        return RecordResponse.model_validate(resp.json())

    def update_record(
        self,
        id_: str,
        hash_: Hash,
        kind: str,
        content: Hash,
        prev: Hash | None,
        metadata: dict[str, Any] | None = None,
        namespace: str | None = None,
        max_versions: int | None = None,
    ) -> RecordResponse:
        """
        Update an existing record with optimistic locking.

        Args:
            id_: Record ID to update
            hash_: Current hash (for optimistic locking)
            kind: Record type
            content: Content hash
            prev: Optional previous record hash, if unset, the previous record will get GCed
            metadata: Record metadata
            namespace: Optional namespace
            max_versions: GC policy: keep at most this many versions (None = keep all). Min 1 if set.

        Returns:
            The updated record

        Raises:
            RecordConflictError: If hash doesn't match current version
            RecordAlreadyDeletedError: If record is deleted
            httpx.HTTPStatusError: For other HTTP errors (404, 500, etc.)
        """
        payload: dict[str, Any] = {"kind": kind, "content": content, "prev": prev}
        if namespace is not None:
            payload["namespace"] = namespace
        if metadata:
            payload["metadata"] = metadata
        if max_versions is not None:
            payload["max_versions"] = max_versions

        resp = self._client.put(
            f"{self.base_url}/records-by-id/{id_}", params={"hash": hash_}, json=payload
        )

        self._check_record_errors(resp)
        return RecordResponse.model_validate(resp.json())

    def get_record(self, hash_: Hash) -> RecordResponse:
        resp = self._client.get(f"{self.base_url}/records/{hash_}")
        resp.raise_for_status()
        return RecordResponse.model_validate(resp.json())

    def get_record_by_id(self, id_: str) -> RecordResponse:
        resp = self._client.get(f"{self.base_url}/records-by-id/{id_}")
        resp.raise_for_status()
        return RecordResponse.model_validate(resp.json())

    def list_records(
        self,
        kind: str | list[str] | None = None,
        namespace: str | None = None,
        metadata_filters: list[MetadataFilter | str] | None = None,
        created_at_filters: list[CreatedAtFilter | str] | None = None,
        sort_by: str | None = None,
        sort_order: SortOrder | None = None,
        limit: int | None = None,
        cursor: str | None = None,
        as_of: int | None = None,
        include_deleted: bool = False,
    ) -> ListRecordsResponse:
        """
        List records with optional filtering.

        Args:
            kind: Filter by record type (single kind or list of kinds)
            namespace: Filter by namespace
            metadata_filters: Filter by metadata fields
            created_at_filters: Filter by created_at timestamp (nanoseconds)
            sort_by: Field to sort by: "created_at", "id", "kind", "namespace", or
                "metadata:path" (e.g. SortBy.metadata("priority")). Metadata sort uses nulls last.
            sort_order: Sort order ("asc" or "desc")
            limit: Maximum number of records to return
            cursor: Pagination cursor
            as_of: Time-travel query (show records as of this timestamp)
            include_deleted: Include soft-deleted records

        Returns:
            ListRecordsResponse with records, next_cursor, and has_more
        """
        params: dict[str, Any] = {}

        if kind is not None:
            params["kind"] = [kind] if isinstance(kind, str) else list(kind)
        if namespace is not None:
            params["namespace"] = namespace
        if sort_by is not None:
            params["sort_by"] = sort_by
        if sort_order is not None:
            params["sort_order"] = sort_order
        if limit is not None:
            params["limit"] = limit
        if cursor is not None:
            params["cursor"] = cursor
        if as_of is not None:
            params["as_of"] = as_of
        if include_deleted:
            params["include_deleted"] = "true"

        if metadata_filters:
            params["metadata_filter"] = [
                f.to_query_param() if isinstance(f, MetadataFilter) else f
                for f in metadata_filters
            ]

        if created_at_filters:
            params["created_at_filter"] = [
                f.to_query_param() if isinstance(f, CreatedAtFilter) else f
                for f in created_at_filters
            ]

        resp = self._client.get(f"{self.base_url}/records", params=params)
        resp.raise_for_status()
        return ListRecordsResponse.model_validate(resp.json())

    def list_records_by_id_prefix(self, prefix: str) -> ListRecordsResponse:
        """
        List records whose id starts with the given prefix.

        Args:
            prefix: Hex prefix or UUID-style string; must be non-empty and valid hex.

        Returns:
            ListRecordsResponse with matching records (has_more is always false).
        """
        if not prefix or not prefix.replace("-", "").strip():
            raise ValueError("prefix is required")
        resp = self._client.get(
            f"{self.base_url}/records-by-id",
            params={"prefix": prefix},
        )
        if resp.status_code == 400:
            msg = (resp.json() or {}).get("message", resp.text) or "Bad request"
            raise NullClientError(msg)
        resp.raise_for_status()
        return ListRecordsResponse.model_validate(resp.json())

    def iter_records(
        self, **kwargs: Unpack[ListRecordsParams]
    ) -> Iterator[RecordResponse]:
        cursor = None
        while True:
            page = self.list_records(**kwargs, cursor=cursor)
            yield from page.records
            if not page.has_more:
                break
            cursor = page.next_cursor

    def delete_record(self, id_: str, hash_: Hash) -> RecordResponse:
        """
        Delete a record (soft delete with optimistic locking).

        Args:
            id_: Record ID to delete (UUID string)
            hash_: Hash of current version (for optimistic locking)

        Returns:
            The deletion record with deleted_at set

        Raises:
            RecordConflictError: If hash doesn't match current version
            RecordAlreadyDeletedError: If record is already deleted
            httpx.HTTPStatusError: For other HTTP errors (404, 500, etc.)
        """
        resp = self._client.delete(
            f"{self.base_url}/records-by-id/{id_}", params={"hash": hash_}
        )
        self._check_record_errors(resp)
        return RecordResponse.model_validate(resp.json())
