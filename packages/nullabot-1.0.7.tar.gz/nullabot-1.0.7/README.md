# Nullabot

24/7 AI agents that think, design, and code - controlled via Telegram.

## Requirements

1. **Python 3.11+**
2. **Claude Code CLI** (requires Claude Max subscription ~$100-200/month)
   ```bash
   npm install -g @anthropic-ai/claude-code
   claude login
   ```

## Install

```bash
pip install nullabot
nullabot setup
```

The setup wizard asks for:
- **Bot token** - Create at [@BotFather](https://t.me/BotFather) on Telegram
- **Your user ID** - Get from [@userinfobot](https://t.me/userinfobot) on Telegram
- **Other users** (optional) - Friends who can use your bot

## Start the Bot

```bash
nullabot bot
```

Now open Telegram and message your bot!

## Telegram Commands

| Command | Description |
|---------|-------------|
| `/start` | Show main menu |
| `/usage` | Show project costs |
| `/rules` | View/add global rules |
| `/chat <question>` | Ask anything |
| `/help` | All commands |

**Admin commands:**
| Command | Description |
|---------|-------------|
| `/users` | List all users |
| `/approve <id>` | Approve a user |
| `/revoke <id>` | Remove user |

## CLI Commands

```bash
nullabot new myproject              # Create project
nullabot think myproject "task"     # Research agent
nullabot design myproject "task"    # Design agent
nullabot code myproject "task"      # Coding agent
nullabot projects                   # List projects
nullabot usage                      # Show costs
```

## Three Agents

| Agent | What it does |
|-------|--------------|
| **Thinker** | Research, analyze, brainstorm |
| **Designer** | UI/UX specs, component design |
| **Coder** | Write code, tests, docs |

Agents automatically hand off context to each other.

## Global Rules

Tell agents what to always/never do:

```
/rules add do Always use TypeScript
/rules add dont Never use console.log
```

Or just say it naturally in any message - it auto-saves!

## Run 24/7

```bash
# Manual (stops when terminal closes)
./run_nullabot.sh bot

# Auto-start on Mac login
./setup_autostart.sh
```

## License

MIT
