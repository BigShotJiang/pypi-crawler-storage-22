"""Nullabot Telegram Bot"""

from nullabot.bot.telegram import TelegramBot

__all__ = ["TelegramBot"]
