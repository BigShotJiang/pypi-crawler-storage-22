"""
Telegram Bot - Visual interface for Nullabot.

Features:
- Multi-user support (admin + regular users)
- User-specific project directories
- Interactive buttons and menus
- Cost tracking display
- Memory status
"""

import asyncio
import json
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, BotCommand
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

# Conversation states
WAITING_TASK = 1


class TelegramBot:
    """
    Visual Telegram bot with multi-user support.

    - Admins: See all projects, manage all users
    - Users: See only their own projects
    """

    def __init__(
        self,
        token: str,
        projects_dir: Path,
        allowed_users: Optional[list[int]] = None,
        admins: Optional[list[int]] = None,
    ):
        self.token = token
        self.base_projects_dir = Path(projects_dir)
        self.base_projects_dir.mkdir(parents=True, exist_ok=True)

        self.allowed_users = set(allowed_users or [])
        self.admins = set(admins or [])

        # Users file for persistence
        self._users_file = self.base_projects_dir / ".users.json"
        self._load_users()

        # Active agents: key = "user_id:project_name"
        self._active_agents: dict[str, asyncio.Task] = {}
        self._agent_chat_ids: dict[str, int] = {}

        # Pending actions (for conversation flow)
        self._pending_action: dict[int, dict] = {}

        # Chat conversation history (temporary, per chat_id)
        self._chat_history: dict[int, list] = {}

        # Running dev servers: key = project_name, value = {process, tunnel_process, url}
        self._running_servers: dict[str, dict] = {}

        self._app: Optional[Application] = None

    def _load_users(self) -> None:
        """Load users from persistent file."""
        if self._users_file.exists():
            try:
                data = json.loads(self._users_file.read_text())
                # Merge file users with config users
                self.allowed_users.update(data.get("allowed", []))
                self._pending_users = set(data.get("pending", []))
                self._user_names = data.get("names", {})
            except:
                self._pending_users = set()
                self._user_names = {}
        else:
            self._pending_users = set()
            self._user_names = {}

    def _save_users(self) -> None:
        """Save users to persistent file."""
        data = {
            "allowed": list(self.allowed_users - self.admins),
            "pending": list(self._pending_users),
            "names": self._user_names,
        }
        self._users_file.write_text(json.dumps(data, indent=2))

    def _check_user(self, user_id: int, user=None) -> bool:
        """Check if user is allowed. Also updates stored name if user object provided."""
        if user:
            self._update_user_name(user)
        if not self.allowed_users and not self.admins:
            return True
        return user_id in self.allowed_users or user_id in self.admins

    def _is_admin(self, user_id: int) -> bool:
        """Check if user is admin."""
        return user_id in self.admins

    def _update_user_name(self, user) -> None:
        """Update stored name for a user from Telegram user object."""
        if user:
            name = user.full_name or user.username or str(user.id)
            if user.username:
                name = f"{name} (@{user.username})"
            self._user_names[str(user.id)] = name

    def _get_user_display(self, user_id: int) -> str:
        """Get display name for a user."""
        name = self._user_names.get(str(user_id))
        if name:
            return name
        return str(user_id)

    async def _fetch_user_names(self, app) -> None:
        """Fetch names for all configured users from Telegram API."""
        all_user_ids = self.admins | self.allowed_users | self._pending_users
        updated = False

        for uid in all_user_ids:
            if str(uid) not in self._user_names:
                try:
                    chat = await app.bot.get_chat(uid)
                    if chat:
                        name = chat.full_name or chat.username or str(uid)
                        if chat.username:
                            name = f"{name} (@{chat.username})"
                        self._user_names[str(uid)] = name
                        updated = True
                        print(f"  Fetched name for {uid}: {name}")
                except Exception:
                    # User hasn't interacted with bot yet
                    pass

        if updated:
            self._save_users()

    def _get_user_projects_dir(self, user_id: int) -> Path:
        """Get projects directory for a user."""
        if self._is_admin(user_id):
            # Admins use the base directory (can see all)
            return self.base_projects_dir
        # Regular users get their own subdirectory
        user_dir = self.base_projects_dir / str(user_id)
        user_dir.mkdir(parents=True, exist_ok=True)
        return user_dir

    def _get_project_path(self, user_id: int, name: str) -> Path:
        """Get path to a specific project."""
        return self._get_user_projects_dir(user_id) / name

    def _get_agent_key(self, user_id: int, project_name: str) -> str:
        """Get unique key for agent tracking."""
        return f"{user_id}:{project_name}"

    def _list_projects(self, user_id: int) -> list[Path]:
        """List projects for a user."""
        projects_dir = self._get_user_projects_dir(user_id)
        if not projects_dir.exists():
            return []

        projects = []
        for p in projects_dir.iterdir():
            if p.is_dir() and (p / ".nullabot").exists():
                projects.append(p)
            # For admins, also check user subdirectories
            elif self._is_admin(user_id) and p.is_dir() and p.name.isdigit():
                for subp in p.iterdir():
                    if subp.is_dir() and (subp / ".nullabot").exists():
                        projects.append(subp)

        return projects

    def _get_project_state(self, project_path: Path, agent_type: str = None) -> dict:
        """Get state of a project (or specific agent)."""
        nulla_dir = project_path / ".nullabot"

        if agent_type:
            # Get specific agent's state
            state_file = nulla_dir / f"state_{agent_type}.json"
            if state_file.exists():
                try:
                    return json.loads(state_file.read_text())
                except:
                    pass
            return {}

        # Get most recent agent state
        latest_state = {}
        latest_time = None

        for state_file in nulla_dir.glob("state_*.json"):
            try:
                state = json.loads(state_file.read_text())
                updated = state.get("updated_at", "")
                if not latest_time or updated > latest_time:
                    latest_time = updated
                    latest_state = state
            except:
                pass

        # Fallback to old format
        if not latest_state:
            old_state_file = nulla_dir / "state.json"
            if old_state_file.exists():
                try:
                    return json.loads(old_state_file.read_text())
                except:
                    pass

        return latest_state

    def _get_all_agent_states(self, project_path: Path) -> dict[str, dict]:
        """Get states of all agents in a project."""
        states = {}
        nulla_dir = project_path / ".nullabot"

        for agent_type in ["thinker", "designer", "coder"]:
            state_file = nulla_dir / f"state_{agent_type}.json"
            if state_file.exists():
                try:
                    states[agent_type] = json.loads(state_file.read_text())
                except:
                    pass

        return states

    def _get_project_usage(self, project_path: Path) -> dict:
        """Get usage/cost info for a project."""
        usage_file = project_path / ".nullabot" / "usage.json"
        if usage_file.exists():
            try:
                return json.loads(usage_file.read_text())
            except:
                pass
        return {"total_cost_usd": 0, "total_cycles": 0}

    def _get_project_memory(self, project_path: Path) -> dict:
        """Get memory info for a project."""
        memory_file = project_path / ".nullabot" / "memory.json"
        if memory_file.exists():
            try:
                data = json.loads(memory_file.read_text())
                return {
                    "long_term": len(data.get("long_term", [])),
                    "short_term": len(data.get("short_term", [])),
                    "agents": list(k for k, v in data.get("agent_summaries", {}).items() if v),
                }
            except:
                pass
        return {"long_term": 0, "short_term": 0, "agents": []}

    async def _send_notification(self, chat_id: int, message: str, buttons: list = None) -> None:
        """Send notification to user."""
        if self._app:
            try:
                reply_markup = InlineKeyboardMarkup(buttons) if buttons else None
                await self._app.bot.send_message(
                    chat_id=chat_id,
                    text=message,
                    parse_mode="Markdown",
                    reply_markup=reply_markup,
                )
            except Exception as e:
                print(f"Notification error: {e}")

    def _main_menu_keyboard(self, user_id: int) -> InlineKeyboardMarkup:
        """Main menu with visual buttons."""
        keyboard = [
            [
                InlineKeyboardButton("📁 Projects", callback_data="menu:projects"),
                InlineKeyboardButton("➕ New Project", callback_data="menu:new"),
            ],
            [
                InlineKeyboardButton("🧠 Think", callback_data="agent:thinker"),
                InlineKeyboardButton("🎨 Design", callback_data="agent:designer"),
                InlineKeyboardButton("💻 Code", callback_data="agent:coder"),
            ],
            [
                InlineKeyboardButton("▶️ Resume", callback_data="menu:resume"),
                InlineKeyboardButton("📊 Status", callback_data="menu:status"),
                InlineKeyboardButton("🛑 Stop", callback_data="menu:stop"),
            ],
            [
                InlineKeyboardButton("💰 Costs", callback_data="menu:costs"),
                InlineKeyboardButton("💬 Chat", callback_data="menu:chat"),
            ],
            [
                InlineKeyboardButton("🚀 Run & Preview", callback_data="menu:run"),
            ],
        ]

        # Admin-only options
        if self._is_admin(user_id):
            keyboard.append([
                InlineKeyboardButton("👥 All Users", callback_data="admin:users"),
            ])

        return InlineKeyboardMarkup(keyboard)

    def _get_paused_projects(self, user_id: int) -> list[tuple[Path, dict]]:
        """Get projects with paused agents."""
        paused = []
        for p in self._list_projects(user_id):
            # Check each agent type for paused state
            agent_states = self._get_all_agent_states(p)
            for agent_type, state in agent_states.items():
                agent_key = self._get_agent_key(user_id, f"{p.name}:{agent_type}")
                if agent_key in self._active_agents:
                    continue
                if state.get("status") == "paused" and state.get("task"):
                    # Include agent_type in state for resume
                    state["_agent_type"] = agent_type
                    state["_project_name"] = p.name
                    paused.append((p, state))
        return paused

    def _projects_keyboard(self, user_id: int, action: str = "select") -> InlineKeyboardMarkup:
        """Keyboard with project buttons."""
        projects = self._list_projects(user_id)
        keyboard = []

        for p in sorted(projects, key=lambda x: x.name)[:10]:
            agent_key = self._get_agent_key(user_id, p.name)
            state = self._get_project_state(p)
            usage = self._get_project_usage(p)

            status = "🟢" if agent_key in self._active_agents else "⚪"
            cost = usage.get("total_cost_usd", 0)

            label = f"{status} {p.name}"
            if cost > 0:
                label += f" (${cost:.2f})"

            keyboard.append([
                InlineKeyboardButton(label, callback_data=f"project:{action}:{p.name}")
            ])

        keyboard.append([InlineKeyboardButton("⬅️ Back", callback_data="menu:main")])
        return InlineKeyboardMarkup(keyboard)

    def _agent_keyboard(self, project_name: str) -> InlineKeyboardMarkup:
        """Agent selection for a project."""
        keyboard = [
            [InlineKeyboardButton("🧠 Thinker", callback_data=f"start:thinker:{project_name}")],
            [InlineKeyboardButton("🎨 Designer", callback_data=f"start:designer:{project_name}")],
            [InlineKeyboardButton("💻 Coder", callback_data=f"start:coder:{project_name}")],
            [InlineKeyboardButton("⬅️ Back", callback_data="menu:projects")],
        ]
        return InlineKeyboardMarkup(keyboard)

    def _running_agents_keyboard(self, user_id: int) -> InlineKeyboardMarkup:
        """Keyboard with running agents to stop."""
        keyboard = []
        prefix = f"{user_id}:" if not self._is_admin(user_id) else ""

        for key in self._active_agents:
            if prefix and not key.startswith(prefix):
                continue
            # Extract project name
            parts = key.split(":", 1)
            project_name = parts[1] if len(parts) > 1 else parts[0]
            keyboard.append([
                InlineKeyboardButton(f"🛑 Stop {project_name}", callback_data=f"stop:{project_name}")
            ])

        keyboard.append([InlineKeyboardButton("⬅️ Back", callback_data="menu:main")])
        return InlineKeyboardMarkup(keyboard)

    # === Command Handlers ===

    async def cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /start command."""
        user_id = update.effective_user.id
        self._update_user_name(update.effective_user)
        user_display = self._get_user_display(user_id)

        if not self._check_user(user_id):
            # Add to pending if not already
            if user_id not in self._pending_users:
                self._pending_users.add(user_id)
                self._save_users()

                # Notify admins
                for admin_id in self.admins:
                    try:
                        await context.bot.send_message(
                            admin_id,
                            f"🆕 *Access Request*\n\n"
                            f"👤 {user_display}\n\n"
                            f"To approve: `/approve {user_id}`\n"
                            f"To deny: `/deny {user_id}`",
                            parse_mode="Markdown",
                        )
                    except:
                        pass

            await update.message.reply_text(
                f"👋 *Welcome to Nullabot!*\n\n"
                f"Your access request has been sent to the admin.\n"
                f"Please wait for approval.",
                parse_mode="Markdown",
            )
            return

        role = "👑 Admin" if self._is_admin(user_id) else "👤 User"
        await update.message.reply_text(
            f"👋 *Welcome to Nullabot*\n\n"
            f"🤖 24/7 AI Workforce powered by *Claude Opus*\n"
            f"🔐 Role: {role}\n\n"
            f"Choose an action below:",
            parse_mode="Markdown",
            reply_markup=self._main_menu_keyboard(user_id),
        )

    async def cmd_menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Show main menu."""
        user_id = update.effective_user.id
        if not self._check_user(user_id, update.effective_user):
            return
        await update.message.reply_text(
            "🏠 *Main Menu*\n\nChoose an action:",
            parse_mode="Markdown",
            reply_markup=self._main_menu_keyboard(user_id),
        )

    async def cmd_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Show help."""
        user_id = update.effective_user.id
        if not self._check_user(user_id, update.effective_user):
            return

        help_text = (
            "📖 *Nullabot Help*\n\n"
            "*Commands:*\n"
            "/start - Start bot & show menu\n"
            "/menu - Show main menu\n"
            "/usage - Show 5hr window & costs\n"
            "/chat <question> - Ask about status/limits\n"
            "/files <project> - List project files\n"
            "/rules - View/manage global rules\n"
            "/help - Show this help\n\n"
            "*Buttons:*\n"
            "📁 *Projects* - View all projects\n"
            "➕ *New Project* - Create new project\n"
            "🧠 *Think* - Research & ideation agent\n"
            "🎨 *Design* - UI/UX design agent\n"
            "💻 *Code* - Software engineering agent\n"
            "▶️ *Resume* - Continue paused agents\n"
            "📊 *Status* - View running agents\n"
            "🛑 *Stop* - Stop running agents\n"
            "💰 *Costs* - View project costs\n\n"
            "*Agent Handoff:*\n"
            "Agents automatically see what previous agents did!\n"
            "Thinker → Designer → Coder flow works seamlessly.\n\n"
            "*Memory System:*\n"
            "- 👤 User memory: Your preferences across all projects\n"
            "- 📁 Project memory: Context for this specific project\n"
            "- 🔄 Short-term: Recent session activity\n"
            "- Agents share context automatically"
        )

        if self._is_admin(user_id):
            help_text += (
                "\n\n*Admin Commands:*\n"
                "/users - List all users\n"
                "/approve <id> - Approve pending user\n"
                "/deny <id> - Deny pending user\n"
                "/revoke <id> - Remove user access"
            )

        await update.message.reply_text(
            help_text,
            parse_mode="Markdown",
            reply_markup=self._main_menu_keyboard(user_id),
        )

    async def cmd_approve(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Approve a pending user (admin only)."""
        user_id = update.effective_user.id
        if not self._is_admin(user_id):
            return

        if not context.args:
            await update.message.reply_text("Usage: `/approve <user_id>`", parse_mode="Markdown")
            return

        try:
            target_id = int(context.args[0])
        except ValueError:
            await update.message.reply_text("Invalid user ID")
            return

        # Remove from pending, add to allowed
        self._pending_users.discard(target_id)
        self.allowed_users.add(target_id)
        self._save_users()

        name = self._get_user_display(target_id)
        await update.message.reply_text(f"✅ Approved: {name}", parse_mode="Markdown")

        # Notify the approved user
        try:
            await context.bot.send_message(
                target_id,
                "🎉 *Access Granted!*\n\n"
                "Your access request has been approved.\n"
                "Use /start to begin!",
                parse_mode="Markdown",
            )
        except:
            pass

    async def cmd_deny(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Deny a pending user (admin only)."""
        user_id = update.effective_user.id
        if not self._is_admin(user_id):
            return

        if not context.args:
            await update.message.reply_text("Usage: `/deny <user_id>`", parse_mode="Markdown")
            return

        try:
            target_id = int(context.args[0])
        except ValueError:
            await update.message.reply_text("Invalid user ID")
            return

        self._pending_users.discard(target_id)
        self._save_users()

        name = self._get_user_display(target_id)
        await update.message.reply_text(f"❌ Denied: {name}", parse_mode="Markdown")

    async def cmd_users(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """List all users (admin only)."""
        user_id = update.effective_user.id
        if not self._is_admin(user_id):
            return

        lines = ["👥 *Users*\n"]

        # Admins
        if self.admins:
            lines.append("*Admins:*")
            for uid in self.admins:
                name = self._get_user_display(uid)
                lines.append(f"  👑 {name}")

        # Allowed users
        non_admin_users = self.allowed_users - self.admins
        if non_admin_users:
            lines.append("\n*Allowed:*")
            for uid in non_admin_users:
                name = self._get_user_display(uid)
                lines.append(f"  ✅ {name}")

        # Pending (show ID for /approve command)
        if self._pending_users:
            lines.append("\n*Pending:*")
            for uid in self._pending_users:
                name = self._get_user_display(uid)
                lines.append(f"  ⏳ {name}")
                lines.append(f"      `/approve {uid}`")

        if len(lines) == 1:
            lines.append("No users yet")

        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

    async def cmd_revoke(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Revoke user access (admin only)."""
        user_id = update.effective_user.id
        if not self._is_admin(user_id):
            return

        if not context.args:
            await update.message.reply_text("Usage: `/revoke <user_id>`", parse_mode="Markdown")
            return

        try:
            target_id = int(context.args[0])
        except ValueError:
            await update.message.reply_text("Invalid user ID")
            return

        if target_id in self.admins:
            await update.message.reply_text("Cannot revoke admin access")
            return

        self.allowed_users.discard(target_id)
        self._save_users()

        name = self._get_user_display(target_id)
        await update.message.reply_text(f"🚫 Revoked: {name}", parse_mode="Markdown")

    async def cmd_chat(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /chat command - ask Claude about projects, usage, etc."""
        user_id = update.effective_user.id
        if not self._check_user(user_id, update.effective_user):
            return

        question = " ".join(context.args) if context.args else ""
        chat_id = update.effective_chat.id

        if not question:
            # Start new conversation - clear history
            self._chat_history[chat_id] = []
            self._pending_action[chat_id] = {"action": "chat_mode", "user_id": user_id}
            await update.message.reply_text(
                "💬 *New Conversation*\n\n"
                "Type your question. I'll remember our chat until you end it.\n\n"
                "_Examples:_\n"
                "• How is my 5hr limit?\n"
                "• What's my total cost?\n"
                "• Summarize real-estate-agent",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔚 End Chat", callback_data="menu:main")],
                ]),
            )
            return

        # Process the question
        await self._process_chat_question(update, user_id, question)

    async def _process_chat_question(self, update: Update, user_id: int, question: str) -> None:
        """Process a chat question using Claude CLI with conversation history."""
        import subprocess

        # Show typing indicator
        await update.message.reply_chat_action("typing")

        chat_id = update.effective_chat.id
        continue_keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔚 End Chat", callback_data="menu:main")],
        ])

        # Build prompt with conversation history
        history = self._chat_history.get(chat_id, [])

        if history:
            # Include conversation context
            context_parts = ["Previous conversation:"]
            for h in history[-6:]:  # Last 6 exchanges max
                context_parts.append(f"User: {h['q']}")
                context_parts.append(f"Assistant: {h['a'][:500]}")
            context_parts.append(f"\nNew question: {question}")
            full_prompt = "\n".join(context_parts)
        else:
            full_prompt = question

        try:
            # Use Claude CLI to answer
            result = subprocess.run(
                ["claude", "-p", full_prompt, "--output-format", "json"],
                capture_output=True,
                text=True,
                timeout=120,
                cwd=str(self.base_projects_dir.parent),
            )

            if result.returncode == 0:
                import json as json_module
                data = json_module.loads(result.stdout)
                response = data.get("result", "No response")

                # Save to history
                if chat_id not in self._chat_history:
                    self._chat_history[chat_id] = []
                self._chat_history[chat_id].append({"q": question, "a": response})

                # Truncate if too long for Telegram (4096 char limit)
                if len(response) > 3500:
                    response = response[:3500] + "\n\n_...truncated_"

                # Show message count
                msg_count = len(self._chat_history.get(chat_id, []))
                await update.message.reply_text(
                    f"💬 {response}\n\n_Message {msg_count} in this chat_",
                    parse_mode="Markdown",
                    reply_markup=continue_keyboard,
                )
            else:
                await update.message.reply_text(
                    f"❌ Error: {result.stderr[:500] if result.stderr else 'Unknown error'}",
                    reply_markup=continue_keyboard,
                )

        except subprocess.TimeoutExpired:
            await update.message.reply_text(
                "⏱ Request timed out. Try a simpler question.",
                reply_markup=continue_keyboard,
            )
        except Exception as e:
            await update.message.reply_text(
                f"❌ Error: {str(e)[:200]}",
                reply_markup=continue_keyboard,
            )

    def _make_progress_bar(self, percentage: float, width: int = 10) -> str:
        """Create a text progress bar."""
        filled = int(width * percentage / 100)
        empty = width - filled
        return f"[{'█' * filled}{'░' * empty}]"

    async def callback_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle all button callbacks."""
        query = update.callback_query
        await query.answer()

        user_id = update.effective_user.id
        if not self._check_user(user_id, update.effective_user):
            return

        data = query.data
        chat_id = update.effective_chat.id

        # Clear pending actions on menu navigation
        if data.startswith("menu:"):
            self._pending_action.pop(chat_id, None)

        # Menu navigation
        if data == "menu:main":
            # Clear chat history when returning to main menu
            self._chat_history.pop(chat_id, None)
            await query.edit_message_text(
                "🏠 *Main Menu*\n\nChoose an action:",
                parse_mode="Markdown",
                reply_markup=self._main_menu_keyboard(user_id),
            )

        elif data == "menu:projects":
            projects = self._list_projects(user_id)
            if not projects:
                await query.edit_message_text(
                    "📁 *No projects yet*\n\nCreate one first!",
                    parse_mode="Markdown",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("➕ New Project", callback_data="menu:new")],
                        [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
                    ]),
                )
            else:
                await query.edit_message_text(
                    "📁 *Select a Project*\n\nTap to start an agent:",
                    parse_mode="Markdown",
                    reply_markup=self._projects_keyboard(user_id, "select"),
                )

        elif data == "menu:new":
            self._pending_action[chat_id] = {"action": "create_project", "user_id": user_id}
            await query.edit_message_text(
                "➕ *Create New Project*\n\n"
                "Send me the project name:\n"
                "(e.g., `my-app` or `website-redesign`)\n\n"
                "_Or tap Back to cancel_",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
                ]),
            )

        elif data == "menu:status":
            await self._show_status(query, user_id)

        elif data == "menu:stop":
            # Check for running agents for this user
            user_agents = [k for k in self._active_agents if k.startswith(f"{user_id}:") or self._is_admin(user_id)]
            if not user_agents:
                await query.edit_message_text(
                    "No agents running.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
                    ]),
                )
            else:
                await query.edit_message_text(
                    "🛑 *Stop Agent*\n\nSelect agent to stop:",
                    parse_mode="Markdown",
                    reply_markup=self._running_agents_keyboard(user_id),
                )

        elif data == "menu:resume":
            paused = self._get_paused_projects(user_id)
            if not paused:
                await query.edit_message_text(
                    "▶️ *No paused projects*\n\nNo agents to resume.",
                    parse_mode="Markdown",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
                    ]),
                )
            else:
                keyboard = []
                for p, state in paused:
                    cycles = state.get("cycles", 0)
                    agent_type = state.get("_agent_type", state.get("agent_type", "thinker"))
                    emoji = {"thinker": "🧠", "designer": "🎨", "coder": "💻"}.get(agent_type, "🤖")
                    keyboard.append([
                        InlineKeyboardButton(
                            f"▶️ {p.name} {emoji} {agent_type} ({cycles} cycles)",
                            callback_data=f"resume:{p.name}:{agent_type}"
                        )
                    ])
                keyboard.append([InlineKeyboardButton("⬅️ Back", callback_data="menu:main")])

                await query.edit_message_text(
                    "▶️ *Resume Paused Agent*\n\nSelect to continue:",
                    parse_mode="Markdown",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                )

        elif data == "menu:costs":
            await self._show_costs(query, user_id)

        elif data == "menu:chat":
            # Start new conversation - clear history
            self._chat_history[chat_id] = []
            self._pending_action[chat_id] = {"action": "chat_mode", "user_id": user_id}
            await query.edit_message_text(
                "💬 *New Conversation*\n\n"
                "Type your question. I'll remember our chat until you go back.\n\n"
                "_Examples:_\n"
                "• How is my 5hr limit?\n"
                "• What's my total cost?\n"
                "• Summarize real-estate-agent",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔚 End Chat", callback_data="menu:main")],
                ]),
            )

        elif data == "menu:run":
            # Show projects that have a coder folder (runnable)
            projects = self._list_projects(user_id)
            runnable = []
            for p in projects:
                coder_dir = p / "coder"
                if coder_dir.exists() and (coder_dir / "package.json").exists():
                    is_running = p.name in self._running_servers
                    runnable.append((p, is_running))

            if not runnable:
                await query.edit_message_text(
                    "🚀 *Run & Preview*\n\n"
                    "No runnable projects found.\n\n"
                    "_Projects need a `coder/package.json` to be runnable._",
                    parse_mode="Markdown",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
                    ]),
                )
            else:
                keyboard = []
                for p, is_running in runnable:
                    if is_running:
                        server_info = self._running_servers.get(p.name, {})
                        url = server_info.get("url", "")
                        keyboard.append([
                            InlineKeyboardButton(f"🟢 {p.name}", callback_data=f"run:view:{p.name}"),
                            InlineKeyboardButton("🛑 Stop", callback_data=f"run:stop:{p.name}"),
                        ])
                    else:
                        keyboard.append([
                            InlineKeyboardButton(f"▶️ Start {p.name}", callback_data=f"run:start:{p.name}"),
                        ])
                keyboard.append([InlineKeyboardButton("⬅️ Back", callback_data="menu:main")])

                await query.edit_message_text(
                    "🚀 *Run & Preview*\n\n"
                    "Start a dev server and get a public preview link:\n",
                    parse_mode="Markdown",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                )

        elif data.startswith("run:start:"):
            project_name = data.split(":")[2]
            await self._start_dev_server(query, user_id, project_name)

        elif data.startswith("run:stop:"):
            project_name = data.split(":")[2]
            await self._stop_dev_server(query, project_name)

        elif data.startswith("run:view:"):
            project_name = data.split(":")[2]
            server_info = self._running_servers.get(project_name, {})
            url = server_info.get("url", "Not available")
            await query.edit_message_text(
                f"🟢 *{project_name}* is running\n\n"
                f"🔗 *Preview URL:*\n{url}\n\n"
                f"_Link is public and accessible from anywhere._",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🛑 Stop Server", callback_data=f"run:stop:{project_name}")],
                    [InlineKeyboardButton("⬅️ Back", callback_data="menu:run")],
                ]),
            )

        # Admin: show all users
        elif data == "admin:users" and self._is_admin(user_id):
            await self._show_all_users(query)

        # Refresh usage
        elif data == "usage:refresh":
            await self._show_usage_inline(query, user_id)

        # Continue chat mode
        elif data == "chat:continue":
            self._pending_action[chat_id] = {"action": "chat_mode", "user_id": user_id}
            await query.edit_message_text(
                "💬 *Chat Mode*\n\n"
                "Type your question and send.",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
                ]),
            )

        # Resume a paused project
        elif data.startswith("resume:"):
            parts = data.split(":")
            project_name = parts[1]
            agent_type = parts[2] if len(parts) > 2 else "thinker"

            project_path = self._get_project_path(user_id, project_name)
            state = self._get_project_state(project_path, agent_type)
            task = state.get("task", "")
            cycles = state.get("cycles", 0)

            if not task:
                await query.edit_message_text(
                    f"❌ No task found for `{project_name}`",
                    parse_mode="Markdown",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
                    ]),
                )
                return

            await self._resume_agent(user_id, project_name, agent_type, task, chat_id)

            emoji = {"thinker": "🧠", "designer": "🎨", "coder": "💻"}.get(agent_type, "🤖")
            await query.edit_message_text(
                f"▶️ *Resumed!*\n\n"
                f"{emoji} *Type:* {agent_type.upper()}\n"
                f"📁 *Project:* `{project_name}`\n"
                f"🔄 *From cycle:* {cycles}\n\n"
                f"📋 *Task:*\n_{task[:150]}_",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🛑 Stop", callback_data=f"stop:{project_name}")],
                    [InlineKeyboardButton("📊 Status", callback_data="menu:status")],
                ]),
            )

        # Agent type selection (before project)
        elif data.startswith("agent:"):
            agent_type = data.split(":")[1]
            projects = self._list_projects(user_id)

            if not projects:
                await query.edit_message_text(
                    f"📁 *No projects yet*\n\nCreate a project first to use {agent_type}!",
                    parse_mode="Markdown",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("➕ New Project", callback_data="menu:new")],
                        [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
                    ]),
                )
            else:
                keyboard = []
                for p in sorted(projects, key=lambda x: x.name)[:10]:
                    agent_key = self._get_agent_key(user_id, p.name)
                    status = "🟢" if agent_key in self._active_agents else "⚪"
                    memory = self._get_project_memory(p)
                    agents_done = ", ".join(memory.get("agents", [])) or "none"

                    keyboard.append([
                        InlineKeyboardButton(
                            f"{status} {p.name} ({agents_done})",
                            callback_data=f"start:{agent_type}:{p.name}"
                        )
                    ])
                keyboard.append([InlineKeyboardButton("⬅️ Back", callback_data="menu:main")])

                emoji = {"thinker": "🧠", "designer": "🎨", "coder": "💻"}.get(agent_type, "🤖")
                await query.edit_message_text(
                    f"{emoji} *{agent_type.upper()}*\n\n"
                    f"Select project:\n"
                    f"_(shows which agents already ran)_",
                    parse_mode="Markdown",
                    reply_markup=InlineKeyboardMarkup(keyboard),
                )

        # Project selection
        elif data.startswith("project:select:"):
            project_name = data.split(":")[2]
            project_path = self._get_project_path(user_id, project_name)
            memory = self._get_project_memory(project_path)
            usage = self._get_project_usage(project_path)

            agents_done = ", ".join(memory.get("agents", [])) or "none yet"

            await query.edit_message_text(
                f"📁 *{project_name}*\n\n"
                f"💰 Cost: ${usage.get('total_cost_usd', 0):.2f}\n"
                f"🧠 Agents completed: {agents_done}\n"
                f"📝 Memories: {memory.get('long_term', 0)} long-term\n\n"
                f"Select agent type:",
                parse_mode="Markdown",
                reply_markup=self._agent_keyboard(project_name),
            )

        # Start agent
        elif data.startswith("start:"):
            parts = data.split(":")
            agent_type = parts[1]
            project_name = parts[2]
            agent_key = self._get_agent_key(user_id, project_name)

            if agent_key in self._active_agents:
                await query.edit_message_text(
                    f"⚠️ Agent already running on `{project_name}`!\n\n"
                    f"Stop it first to start a new one.",
                    parse_mode="Markdown",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton(f"🛑 Stop {project_name}", callback_data=f"stop:{project_name}")],
                        [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
                    ]),
                )
                return

            # Ask for task
            self._pending_action[chat_id] = {
                "action": "start_agent",
                "user_id": user_id,
                "agent_type": agent_type,
                "project": project_name,
            }

            # Show context hint
            project_path = self._get_project_path(user_id, project_name)
            memory = self._get_project_memory(project_path)
            agents_done = memory.get("agents", [])

            context_hint = ""
            if agents_done:
                context_hint = f"\n\n✨ _{agent_type} will automatically see work from: {', '.join(agents_done)}_"

            emoji = {"thinker": "🧠", "designer": "🎨", "coder": "💻"}.get(agent_type, "🤖")
            await query.edit_message_text(
                f"{emoji} *{agent_type.upper()}* on `{project_name}`\n\n"
                f"📝 Send me the task:{context_hint}\n\n"
                f"_Example: Research AI features for a real estate app_\n\n"
                f"_Or tap Back to cancel_",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
                ]),
            )

        # Stop agent
        elif data.startswith("stop:"):
            project_name = data.split(":")[1]
            await self._stop_agent(user_id, project_name, query)

    async def _show_status(self, query, user_id: int) -> None:
        """Show status with visual formatting."""
        from datetime import datetime as dt
        now = dt.now().strftime("%H:%M:%S")

        # Get running agents for this user
        user_agents = []
        for key in self._active_agents:
            if key.startswith(f"{user_id}:") or self._is_admin(user_id):
                parts = key.split(":", 1)
                owner_id = int(parts[0])
                project_name = parts[1]
                user_agents.append((owner_id, project_name))

        if not user_agents:
            text = f"📊 *Status* _{now}_\n\n✨ No agents running\n\nStart one from the menu!"
        else:
            lines = [f"📊 *Running Agents* _{now}_\n"]
            for owner_id, project_name in user_agents:
                project_path = self._get_project_path(owner_id, project_name)
                state = self._get_project_state(project_path)
                usage = self._get_project_usage(project_path)
                cycles = state.get("cycles", 0)
                files = len(state.get("files_created", []))
                cost = usage.get("total_cost_usd", 0)
                task = state.get("task", "")[:40]

                owner_label = "" if owner_id == user_id else f" (user {owner_id})"
                lines.append(f"🟢 *{project_name}*{owner_label}")
                lines.append(f"   📍 Cycles: {cycles} | Files: {files} | Cost: ${cost:.2f}")
                if task:
                    lines.append(f"   📋 _{task}..._")
                lines.append("")

            text = "\n".join(lines)

        try:
            await query.edit_message_text(
                text,
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔄 Refresh", callback_data="menu:status")],
                    [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
                ]),
            )
        except Exception:
            pass

    async def _show_costs(self, query, user_id: int) -> None:
        """Show cost summary for all projects."""
        projects = self._list_projects(user_id)

        if not projects:
            await query.edit_message_text(
                "💰 *Costs*\n\nNo projects yet.",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
                ]),
            )
            return

        total_cost = 0
        total_cycles = 0
        lines = ["💰 *Cost Summary*\n"]

        for p in sorted(projects, key=lambda x: x.name):
            usage = self._get_project_usage(p)
            cost = usage.get("total_cost_usd", 0)
            cycles = usage.get("total_cycles", 0)
            total_cost += cost
            total_cycles += cycles

            if cost > 0:
                lines.append(f"• `{p.name}`: ${cost:.2f} ({cycles} cycles)")

        lines.append(f"\n*Total: ${total_cost:.2f}* ({total_cycles} cycles)")

        await query.edit_message_text(
            "\n".join(lines),
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
            ]),
        )

    async def _show_usage_inline(self, query, user_id: int) -> None:
        """Show usage stats inline (for refresh button)."""
        from nullabot.core.memory import UsageTracker
        from datetime import datetime

        base_dir = self.base_projects_dir.parent

        # Format token counts
        def fmt_tokens(n):
            if n >= 1_000_000:
                return f"{n/1_000_000:.1f}M"
            elif n >= 1_000:
                return f"{n/1_000:.1f}K"
            return str(n)

        lines = [
            "📈 *Nullabot Usage*\n",
        ]

        # Per-project costs
        total_cost = 0
        total_cycles = 0
        total_hours = 0
        total_tokens = 0

        for item in self.base_projects_dir.iterdir():
            if item.is_dir() and (item / ".nullabot").exists():
                try:
                    tracker = UsageTracker(item, base_dir)
                    summary = tracker.get_summary()
                    if summary["total_cycles"] > 0:
                        tokens = summary.get("total_tokens", 0)
                        lines.append(f"📁 *{item.name}*")
                        lines.append(f"   {summary['total_cycles']} cycles · {fmt_tokens(tokens)} tokens · ${summary['total_cost_usd']:.2f}")
                        total_cost += summary["total_cost_usd"]
                        total_cycles += summary["total_cycles"]
                        total_hours += summary["total_hours"]
                        total_tokens += tokens
                except:
                    pass

        if total_cycles > 0:
            lines.append(f"\n💰 *Total:* {total_cycles} cycles · {fmt_tokens(total_tokens)} tokens · ${total_cost:.2f}")
        else:
            lines.append("_No usage yet_")

        lines.append(f"\n_Updated: {datetime.now().strftime('%H:%M:%S')}_")
        lines.append("\n─────────────────")
        lines.append("ℹ️ _For real Claude limits:_")
        lines.append("_`claude` → `/usage` in terminal_")

        await query.edit_message_text(
            "\n".join(lines),
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Refresh", callback_data="usage:refresh")],
                [InlineKeyboardButton("⬅️ Menu", callback_data="menu:main")],
            ]),
        )

    async def _show_all_users(self, query) -> None:
        """Admin: Show all users and their projects."""
        lines = ["👥 *All Users*\n"]

        # Show admin projects first
        admin_projects = []
        user_sections = []

        # Scan base projects directory
        for item in self.base_projects_dir.iterdir():
            if item.is_dir():
                if item.name.isdigit():
                    # User subdirectory
                    uid = int(item.name)
                    name = self._get_user_display(uid)
                    projects = [p for p in item.iterdir() if p.is_dir() and (p / ".nullabot").exists()]
                    if projects:
                        user_sections.append(f"👤 *{name}*")
                        for p in projects:
                            user_sections.append(f"   📁 {p.name}")
                elif (item / ".nullabot").exists():
                    # Direct project (admin's)
                    admin_projects.append(item.name)

        # Add admin projects with admin's name
        if admin_projects and self.admins:
            admin_id = list(self.admins)[0]
            admin_name = self._get_user_display(admin_id)
            lines.append(f"👑 *{admin_name}*")
            for proj_name in admin_projects:
                lines.append(f"   📁 {proj_name}")

        # Add user sections
        if user_sections:
            if admin_projects:
                lines.append("")
            lines.extend(user_sections)

        if len(lines) == 1:
            lines.append("No projects yet")

        await query.edit_message_text(
            "\n".join(lines),
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
            ]),
        )

    async def _stop_agent(self, user_id: int, project_name: str, query) -> None:
        """Stop an agent."""
        agent_key = self._get_agent_key(user_id, project_name)

        if agent_key not in self._active_agents:
            await query.edit_message_text(
                f"No agent running on `{project_name}`.",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
                ]),
            )
            return

        task = self._active_agents[agent_key]
        task.cancel()

        project_path = self._get_project_path(user_id, project_name)
        state_file = project_path / ".nullabot" / "state.json"
        if state_file.exists():
            state = json.loads(state_file.read_text())
            state["status"] = "paused"
            state_file.write_text(json.dumps(state, indent=2))

        self._active_agents.pop(agent_key, None)
        self._agent_chat_ids.pop(agent_key, None)

        await query.edit_message_text(
            f"🛑 *Stopped* `{project_name}`\n\n"
            f"State saved. You can resume later with the same task.",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏠 Menu", callback_data="menu:main")],
            ]),
        )

    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle text messages for conversations."""
        from nullabot.core.memory import UserMemory

        user_id = update.effective_user.id
        if not self._check_user(user_id, update.effective_user):
            return

        chat_id = update.effective_chat.id
        text = update.message.text.strip()

        # Auto-extract rules from user messages
        try:
            user_memory = UserMemory(self.base_projects_dir.parent, user_id)
            user_memory.extract_from_response(text)
        except:
            pass

        if chat_id in self._pending_action:
            action = self._pending_action[chat_id]

            if action["action"] == "create_project":
                await self._create_project(update, user_id, text)
                del self._pending_action[chat_id]

            elif action["action"] == "start_agent":
                await self._start_agent_with_task(
                    update,
                    action["user_id"],
                    action["project"],
                    action["agent_type"],
                    text,
                )
                del self._pending_action[chat_id]

            elif action["action"] == "chat_mode":
                # Process as chat question, keep chat mode active
                await self._process_chat_question(update, user_id, text)

        else:
            await update.message.reply_text(
                "👋 Tap a button below to get started!",
                reply_markup=self._main_menu_keyboard(user_id),
            )

    async def _create_project(self, update: Update, user_id: int, name: str) -> None:
        """Create a new project."""
        name = name.lower().replace(" ", "-")
        project_path = self._get_project_path(user_id, name)

        if project_path.exists():
            await update.message.reply_text(
                f"❌ Project `{name}` already exists!",
                parse_mode="Markdown",
                reply_markup=self._main_menu_keyboard(user_id),
            )
            return

        project_path.mkdir(parents=True)
        (project_path / ".nullabot").mkdir()
        config = {"name": name, "created_at": datetime.now().isoformat(), "user_id": user_id}
        (project_path / ".nullabot" / "config.json").write_text(json.dumps(config, indent=2))

        await update.message.reply_text(
            f"✅ *Project Created!*\n\n"
            f"📁 `{name}`\n\n"
            f"Now start an agent:",
            parse_mode="Markdown",
            reply_markup=self._agent_keyboard(name),
        )

    async def _start_agent_with_task(
        self,
        update: Update,
        user_id: int,
        project_name: str,
        agent_type: str,
        task: str,
    ) -> None:
        """Start agent with the given task."""
        chat_id = update.effective_chat.id
        project_path = self._get_project_path(user_id, project_name)
        agent_key = self._get_agent_key(user_id, project_name)

        if agent_key in self._active_agents:
            await update.message.reply_text(
                f"⚠️ Agent already running on `{project_name}`!",
                parse_mode="Markdown",
            )
            return

        self._agent_chat_ids[agent_key] = chat_id

        from nullabot.agents.claude_agent import ClaudeAgent

        async def on_notify(event: str, message: str, data: dict = None):
            buttons = None
            if event == "complete":
                buttons = [[
                    InlineKeyboardButton("📁 View Files", callback_data=f"files:{project_name}"),
                    InlineKeyboardButton("🏠 Menu", callback_data="menu:main"),
                ]]
            elif event == "error":
                buttons = [[
                    InlineKeyboardButton("🔄 Retry", callback_data=f"start:{agent_type}:{project_name}"),
                    InlineKeyboardButton("🏠 Menu", callback_data="menu:main"),
                ]]
            await self._send_notification(chat_id, message, buttons)

        async def run_agent():
            try:
                agent = ClaudeAgent(
                    workspace=project_path,
                    agent_type=agent_type,
                    model="opus",
                    on_notify=on_notify,
                    user_id=user_id,
                    base_dir=self.base_projects_dir.parent,
                )
                await agent.start(task, continuous=True)
            except Exception as e:
                await self._send_notification(
                    chat_id,
                    f"❌ *Error:* `{str(e)[:200]}`",
                    [[InlineKeyboardButton("🏠 Menu", callback_data="menu:main")]],
                )
            finally:
                self._active_agents.pop(agent_key, None)
                self._agent_chat_ids.pop(agent_key, None)

        agent_task = asyncio.create_task(run_agent())
        self._active_agents[agent_key] = agent_task

        # Get memory info
        memory = self._get_project_memory(project_path)
        agents_done = memory.get("agents", [])
        context_note = ""
        if agents_done:
            context_note = f"\n✨ Using context from: {', '.join(agents_done)}"

        emoji = {"thinker": "🧠", "designer": "🎨", "coder": "💻"}.get(agent_type, "🤖")
        await update.message.reply_text(
            f"🚀 *Agent Started!*\n\n"
            f"{emoji} *Type:* {agent_type.upper()}\n"
            f"📁 *Project:* `{project_name}`\n"
            f"🤖 *Model:* Opus\n"
            f"⏱ *Timeout:* 30 min{context_note}\n\n"
            f"📋 *Task:*\n_{task[:200]}_\n\n"
            f"📢 You'll receive updates for every cycle!",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🛑 Stop", callback_data=f"stop:{project_name}")],
                [InlineKeyboardButton("📊 Status", callback_data="menu:status")],
            ]),
        )

    async def _resume_agent(
        self,
        user_id: int,
        project_name: str,
        agent_type: str,
        task: str,
        chat_id: int,
    ) -> None:
        """Resume an agent."""
        agent_key = self._get_agent_key(user_id, project_name)
        if agent_key in self._active_agents:
            return

        project_path = self._get_project_path(user_id, project_name)
        self._agent_chat_ids[agent_key] = chat_id

        from nullabot.agents.claude_agent import ClaudeAgent

        async def on_notify(event: str, message: str, data: dict = None):
            buttons = None
            if event == "complete":
                buttons = [[
                    InlineKeyboardButton("📁 View Files", callback_data=f"files:{project_name}"),
                    InlineKeyboardButton("🏠 Menu", callback_data="menu:main"),
                ]]
            elif event == "error":
                buttons = [[
                    InlineKeyboardButton("🔄 Retry", callback_data=f"start:{agent_type}:{project_name}"),
                    InlineKeyboardButton("🏠 Menu", callback_data="menu:main"),
                ]]
            await self._send_notification(chat_id, message, buttons)

        async def run_agent():
            try:
                agent = ClaudeAgent(
                    workspace=project_path,
                    agent_type=agent_type,
                    model="opus",
                    on_notify=on_notify,
                    user_id=user_id,
                    base_dir=self.base_projects_dir.parent,
                )
                await agent.start(task, continuous=True)
            except Exception as e:
                await self._send_notification(
                    chat_id,
                    f"❌ *Error:* `{str(e)[:200]}`",
                    [[InlineKeyboardButton("🏠 Menu", callback_data="menu:main")]],
                )
            finally:
                self._active_agents.pop(agent_key, None)
                self._agent_chat_ids.pop(agent_key, None)

        agent_task = asyncio.create_task(run_agent())
        self._active_agents[agent_key] = agent_task

    def _find_resumable_projects(self) -> list[tuple[str, dict]]:
        """Find projects that were running and can be resumed."""
        resumable = []
        for p in self.base_projects_dir.rglob(".nullabot/state.json"):
            try:
                state = json.loads(p.read_text())
                if state.get("status") == "running" and state.get("task"):
                    project_path = p.parent.parent
                    resumable.append((project_path.name, state))
            except:
                pass
        return resumable

    async def _auto_resume_agents(self, app: Application) -> None:
        """Auto-resume agents that were running before restart."""
        resumable = self._find_resumable_projects()

        if not resumable:
            print("📋 No agents to resume")
            return

        print(f"🔄 Found {len(resumable)} agent(s) to resume...")

        for project_name, state in resumable:
            task = state.get("task", "")
            agent_type = state.get("agent_type", "thinker")

            chat_id = None
            if self.admins:
                chat_id = list(self.admins)[0]
            elif self.allowed_users:
                chat_id = list(self.allowed_users)[0]

            if not chat_id:
                print(f"⚠️ Cannot resume {project_name}: no chat_id available")
                continue

            print(f"▶️ Resuming {agent_type} on {project_name}...")

            # Use admin ID for resumed agents
            await self._resume_agent(list(self.admins)[0] if self.admins else chat_id, project_name, agent_type, task, chat_id)

            await self._send_notification(
                chat_id,
                f"🔄 *Auto-resumed* `{project_name}`\n\n"
                f"📋 Task: _{task[:100]}_\n"
                f"🔄 Cycles so far: {state.get('cycles', 0)}",
                [[InlineKeyboardButton("🛑 Stop", callback_data=f"stop:{project_name}")]],
            )

    async def cmd_files(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /files command."""
        user_id = update.effective_user.id
        if not self._check_user(user_id, update.effective_user):
            return

        if not context.args:
            await update.message.reply_text(
                "📂 *View Files*\n\nSelect a project:",
                parse_mode="Markdown",
                reply_markup=self._projects_keyboard(user_id, "files"),
            )
            return

        project_name = context.args[0]
        await self._show_files(update.message, user_id, project_name)

    async def cmd_rules(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /rules command - view and manage global rules."""
        from nullabot.core.memory import UserMemory

        user_id = update.effective_user.id
        if not self._check_user(user_id, update.effective_user):
            return

        # Load user memory
        user_memory = UserMemory(self.base_projects_dir.parent, user_id)

        # Check for subcommands: /rules add do <rule> or /rules add dont <rule>
        if context.args:
            action = context.args[0].lower()

            if action == "add" and len(context.args) >= 3:
                rule_type = context.args[1].lower()
                rule_text = " ".join(context.args[2:])

                if rule_type in ["do", "dont", "don't"]:
                    rule_type = "do" if rule_type == "do" else "dont"
                    user_memory.add_rule(rule_text, rule_type)
                    emoji = "✅" if rule_type == "do" else "❌"
                    await update.message.reply_text(
                        f"{emoji} Rule added: {rule_text}",
                        parse_mode="Markdown",
                    )
                    return
                else:
                    await update.message.reply_text(
                        "Usage: `/rules add do <rule>` or `/rules add dont <rule>`",
                        parse_mode="Markdown",
                    )
                    return

            elif action == "clear":
                user_memory._memory["rules"] = []
                user_memory._save()
                await update.message.reply_text("🗑️ All rules cleared.")
                return

        # Show current rules
        rules = user_memory.get_rules()

        if not rules:
            await update.message.reply_text(
                "📋 *Global Rules*\n\n"
                "No rules yet.\n\n"
                "*Add rules:*\n"
                "`/rules add do Always use TypeScript`\n"
                "`/rules add dont Never use console.log`",
                parse_mode="Markdown",
            )
            return

        lines = ["📋 *Global Rules*\n"]

        do_rules = [r for r in rules if r.get("type") == "do"]
        dont_rules = [r for r in rules if r.get("type") == "dont"]

        if do_rules:
            lines.append("✅ *ALWAYS DO:*")
            for r in do_rules:
                lines.append(f"  • {r['rule']}")

        if dont_rules:
            if do_rules:
                lines.append("")
            lines.append("❌ *NEVER DO:*")
            for r in dont_rules:
                lines.append(f"  • {r['rule']}")

        lines.append("\n*Commands:*")
        lines.append("`/rules add do <rule>`")
        lines.append("`/rules add dont <rule>`")
        lines.append("`/rules clear`")

        await update.message.reply_text(
            "\n".join(lines),
            parse_mode="Markdown",
        )

    async def cmd_usage(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /usage command - show nullabot usage and costs."""
        from nullabot.core.memory import get_global_window_tracker, UsageTracker

        user_id = update.effective_user.id
        if not self._check_user(user_id, update.effective_user):
            return

        base_dir = self.base_projects_dir.parent

        # Format token counts
        def fmt_tokens(n):
            if n >= 1_000_000:
                return f"{n/1_000_000:.1f}M"
            elif n >= 1_000:
                return f"{n/1_000:.1f}K"
            return str(n)

        lines = [
            "📈 *Nullabot Usage*\n",
        ]

        # Per-project costs
        total_cost = 0
        total_cycles = 0
        total_hours = 0
        total_tokens = 0

        for item in self.base_projects_dir.iterdir():
            if item.is_dir() and (item / ".nullabot").exists():
                try:
                    tracker = UsageTracker(item, base_dir)
                    summary = tracker.get_summary()
                    if summary["total_cycles"] > 0:
                        tokens = summary.get("total_tokens", 0)
                        lines.append(f"📁 *{item.name}*")
                        lines.append(f"   {summary['total_cycles']} cycles · {fmt_tokens(tokens)} tokens · ${summary['total_cost_usd']:.2f}")
                        total_cost += summary["total_cost_usd"]
                        total_cycles += summary["total_cycles"]
                        total_hours += summary["total_hours"]
                        total_tokens += tokens
                except:
                    pass

        if total_cycles > 0:
            lines.append(f"\n💰 *Total:* {total_cycles} cycles · {fmt_tokens(total_tokens)} tokens · ${total_cost:.2f}")
        else:
            lines.append("_No usage yet_")

        lines.append("\n─────────────────")
        lines.append("ℹ️ _For real Claude Code limits:_")
        lines.append("_Run `claude` → `/usage` in terminal_")

        await update.message.reply_text(
            "\n".join(lines),
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Refresh", callback_data="usage:refresh")],
                [InlineKeyboardButton("⬅️ Menu", callback_data="menu:main")],
            ]),
        )

    def _find_available_port(self, start_port: int = 3000) -> int:
        """Find an available port starting from start_port."""
        import socket
        port = start_port
        while port < 65535:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind(('localhost', port))
                    return port
            except OSError:
                port += 1
        return start_port  # Fallback

    async def _start_dev_server(self, query, user_id: int, project_name: str) -> None:
        """Start dev server with tunnel for a project."""
        import asyncio
        import subprocess
        import re

        project_path = self._get_project_path(user_id, project_name)
        coder_dir = project_path / "coder"

        if not coder_dir.exists():
            await query.edit_message_text(
                f"❌ No coder folder found in `{project_name}`",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Back", callback_data="menu:run")],
                ]),
            )
            return

        # Find an available port first
        port = self._find_available_port(3000)

        # Show starting message
        await query.edit_message_text(
            f"🚀 *Starting {project_name}...*\n\n"
            f"🔍 Found available port: {port}\n"
            f"📦 Installing dependencies...",
            parse_mode="Markdown",
        )

        # Detect package manager
        if (coder_dir / "bun.lockb").exists():
            pkg_manager = "bun"
        elif (coder_dir / "yarn.lock").exists():
            pkg_manager = "yarn"
        elif (coder_dir / "pnpm-lock.yaml").exists():
            pkg_manager = "pnpm"
        else:
            pkg_manager = "npm"

        try:
            # Install dependencies
            install_cmd = f"{pkg_manager} install"
            install_proc = await asyncio.create_subprocess_shell(
                install_cmd,
                cwd=str(coder_dir),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            await install_proc.wait()

            await query.edit_message_text(
                f"🚀 *Starting {project_name}...*\n\n"
                f"✅ Dependencies installed\n"
                f"🔧 Starting dev server...",
                parse_mode="Markdown",
            )

            # Detect framework from package.json to use correct port flag
            import os
            framework = "unknown"
            try:
                pkg_json = json.loads((coder_dir / "package.json").read_text())
                deps = {**pkg_json.get("dependencies", {}), **pkg_json.get("devDependencies", {})}
                if "next" in deps:
                    framework = "next"
                elif "vite" in deps:
                    framework = "vite"
                elif "react-scripts" in deps:
                    framework = "cra"
            except:
                pass

            # Build command with correct port flag for each framework
            env = os.environ.copy()
            env["PORT"] = str(port)

            if framework == "next":
                # Next.js uses -p flag
                if pkg_manager == "bun":
                    dev_cmd = f"bun run dev -- -p {port}"
                else:
                    dev_cmd = f"{pkg_manager} run dev -- -p {port}"
            elif framework == "vite":
                # Vite uses --port flag
                if pkg_manager == "bun":
                    dev_cmd = f"bun run dev -- --port {port}"
                else:
                    dev_cmd = f"{pkg_manager} run dev -- --port {port}"
            else:
                # Fallback: use PORT env var (works for CRA and many others)
                if pkg_manager == "bun":
                    dev_cmd = f"bun run dev"
                else:
                    dev_cmd = f"{pkg_manager} run dev"

            dev_proc = await asyncio.create_subprocess_shell(
                dev_cmd,
                cwd=str(coder_dir),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )

            # Wait for server to start
            await asyncio.sleep(5)

            await query.edit_message_text(
                f"🚀 *Starting {project_name}...*\n\n"
                f"✅ Dependencies installed\n"
                f"✅ Dev server running on port {port}\n"
                f"🌐 Creating public tunnel...",
                parse_mode="Markdown",
            )

            # Start cloudflared tunnel
            tunnel_proc = await asyncio.create_subprocess_exec(
                "cloudflared", "tunnel", "--url", f"http://localhost:{port}",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            # Read tunnel output to get URL (it's in stderr)
            tunnel_url = None
            for _ in range(30):  # Wait up to 30 seconds
                await asyncio.sleep(1)
                if tunnel_proc.stderr:
                    try:
                        # Read available data
                        data = await asyncio.wait_for(
                            tunnel_proc.stderr.read(4096),
                            timeout=0.5
                        )
                        output = data.decode()
                        # Look for URL in output
                        match = re.search(r'https://[a-zA-Z0-9-]+\.trycloudflare\.com', output)
                        if match:
                            tunnel_url = match.group(0)
                            break
                    except asyncio.TimeoutError:
                        continue

            if tunnel_url:
                # Save server info
                self._running_servers[project_name] = {
                    "dev_process": dev_proc,
                    "tunnel_process": tunnel_proc,
                    "url": tunnel_url,
                    "port": port,
                }

                await query.edit_message_text(
                    f"🟢 *{project_name}* is running!\n\n"
                    f"🔗 *Preview URL:*\n{tunnel_url}\n\n"
                    f"_This link is public and works from anywhere._\n"
                    f"_Server will run until you stop it._",
                    parse_mode="Markdown",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("🛑 Stop Server", callback_data=f"run:stop:{project_name}")],
                        [InlineKeyboardButton("⬅️ Back", callback_data="menu:run")],
                    ]),
                )
            else:
                # Tunnel failed, clean up
                dev_proc.terminate()
                tunnel_proc.terminate()
                await query.edit_message_text(
                    f"❌ Failed to create tunnel.\n\n"
                    f"Make sure `cloudflared` is installed:\n"
                    f"`brew install cloudflared`",
                    parse_mode="Markdown",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("⬅️ Back", callback_data="menu:run")],
                    ]),
                )

        except Exception as e:
            await query.edit_message_text(
                f"❌ Error starting server:\n`{str(e)[:200]}`",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Back", callback_data="menu:run")],
                ]),
            )

    async def _stop_dev_server(self, query, project_name: str) -> None:
        """Stop a running dev server and tunnel."""
        if project_name not in self._running_servers:
            await query.edit_message_text(
                f"Server for `{project_name}` is not running.",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Back", callback_data="menu:run")],
                ]),
            )
            return

        server_info = self._running_servers[project_name]

        # Terminate processes
        try:
            if server_info.get("dev_process"):
                server_info["dev_process"].terminate()
            if server_info.get("tunnel_process"):
                server_info["tunnel_process"].terminate()
        except:
            pass

        del self._running_servers[project_name]

        await query.edit_message_text(
            f"🛑 *{project_name}* stopped.\n\n"
            f"Dev server and tunnel have been terminated.",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Back", callback_data="menu:run")],
            ]),
        )

    async def _show_files(self, message, user_id: int, project_name: str) -> None:
        """Show files in a project."""
        project_path = self._get_project_path(user_id, project_name)

        if not project_path.exists():
            await message.reply_text(f"❌ Project `{project_name}` not found.", parse_mode="Markdown")
            return

        files = []
        for f in project_path.rglob("*"):
            if f.is_file() and ".nullabot" not in str(f):
                rel = str(f.relative_to(project_path))
                size = f.stat().st_size
                files.append((rel, size))

        if not files:
            await message.reply_text(
                f"📁 `{project_name}` has no files yet.",
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
                ]),
            )
            return

        lines = [f"📂 *{project_name}* ({len(files)} files)\n"]
        for fname, size in sorted(files)[:20]:
            size_str = f"{size}B" if size < 1024 else f"{size // 1024}KB"
            lines.append(f"• `{fname}` _{size_str}_")

        if len(files) > 20:
            lines.append(f"\n_+{len(files) - 20} more files_")

        await message.reply_text(
            "\n".join(lines),
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Back", callback_data="menu:main")],
            ]),
        )

    def run(self) -> None:
        """Run the bot."""
        self._app = Application.builder().token(self.token).build()

        # Command handlers
        self._app.add_handler(CommandHandler("start", self.cmd_start))
        self._app.add_handler(CommandHandler("menu", self.cmd_menu))
        self._app.add_handler(CommandHandler("help", self.cmd_help))
        self._app.add_handler(CommandHandler("files", self.cmd_files))
        self._app.add_handler(CommandHandler("chat", self.cmd_chat))
        self._app.add_handler(CommandHandler("rules", self.cmd_rules))
        self._app.add_handler(CommandHandler("usage", self.cmd_usage))
        # Admin commands
        self._app.add_handler(CommandHandler("approve", self.cmd_approve))
        self._app.add_handler(CommandHandler("deny", self.cmd_deny))
        self._app.add_handler(CommandHandler("users", self.cmd_users))
        self._app.add_handler(CommandHandler("revoke", self.cmd_revoke))

        # Callback handler for buttons
        self._app.add_handler(CallbackQueryHandler(self.callback_handler))

        # Message handler
        self._app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message))

        print("🤖 Nullabot Telegram Bot started!")
        print("📢 Notifications enabled for all events")
        print("🎯 Using Claude Code CLI with Opus model")
        print("💰 Cost tracking enabled")
        print("🧠 Memory system enabled")

        # Set up bot commands menu and auto-resume
        async def post_init(app):
            # Register commands in Telegram menu
            await app.bot.set_my_commands([
                BotCommand("start", "Start"),
                BotCommand("menu", "Main menu"),
                BotCommand("chat", "Chat with Claude"),
                BotCommand("usage", "Project costs"),
                BotCommand("rules", "Global rules"),
                BotCommand("users", "Manage users"),
                BotCommand("help", "Help"),
            ])
            # Fetch names for configured users (if they've interacted before)
            await self._fetch_user_names(app)
            # Auto-resume agents
            await self._auto_resume_agents(app)

        self._app.post_init = post_init

        self._app.run_polling()
