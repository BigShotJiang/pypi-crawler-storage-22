"""
Nullabot CLI - Command line interface.

Uses Claude Code CLI as the backend (your subscription).

Usage:
    nullabot setup                Interactive setup wizard
    nullabot new <name>           Create new project
    nullabot think <project>      Start Thinker agent
    nullabot design <project>     Start Designer agent
    nullabot code <project>       Start Coder agent
    nullabot status               Show status
    nullabot bot                  Start Telegram bot
"""

import asyncio
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

import click
import yaml
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.prompt import Prompt, Confirm

console = Console()

# Default projects directory
DEFAULT_PROJECTS_DIR = Path.cwd() / "projects"


def get_projects_dir(projects_dir: str | None = None) -> Path:
    """Get projects directory from arg, config, or default."""
    if projects_dir:
        return Path(projects_dir)

    # Try to load from config.yaml in current dir or package dir
    for config_path in [Path.cwd() / "config.yaml", Path(__file__).parent.parent / "config.yaml"]:
        if config_path.exists():
            try:
                config = yaml.safe_load(config_path.read_text())
                cfg_projects = config.get("paths", {}).get("projects_dir")
                if cfg_projects:
                    # Resolve relative to config file location
                    p = Path(cfg_projects)
                    if not p.is_absolute():
                        p = config_path.parent / p
                    return p.resolve()
            except:
                pass

    return DEFAULT_PROJECTS_DIR


def get_project_path(projects_dir: Path, name: str) -> Path:
    """Get path to a project."""
    return projects_dir / name


def list_all_projects(projects_dir: Path) -> list[Path]:
    """List all project directories."""
    if not projects_dir.exists():
        return []
    return [
        p for p in projects_dir.iterdir()
        if p.is_dir() and (p / ".nullabot").exists()
    ]


@click.group()
@click.option(
    "--projects-dir",
    envvar="NULLA_PROJECTS_DIR",
    help="Projects directory (default: ./projects)",
)
@click.pass_context
def cli(ctx, projects_dir: str | None):
    """Nullabot - 24/7 AI Workforce (powered by Claude Code)"""
    ctx.ensure_object(dict)
    ctx.obj["projects_dir"] = get_projects_dir(projects_dir)


@cli.command("setup")
def setup_wizard():
    """Interactive setup wizard - run this first!"""
    console.print(Panel(
        "[bold cyan]Welcome to Nullabot Setup![/bold cyan]\n\n"
        "This wizard will help you configure everything step by step.",
        title="🚀 Nullabot Setup",
    ))

    # Check for existing config
    config_path = Path.cwd() / "config.yaml"
    existing_config = None
    if config_path.exists():
        try:
            existing_config = yaml.safe_load(config_path.read_text())
            console.print("\n[green]✓[/green] Found existing config.yaml")
        except:
            pass

    # Step 1: Check Python
    console.print("\n[bold]Step 1/5: Checking Python...[/bold]")
    python_version = sys.version_info
    if python_version >= (3, 11):
        console.print(f"  [green]✓[/green] Python {python_version.major}.{python_version.minor} installed")
    else:
        console.print(f"  [red]✗[/red] Python 3.11+ required (you have {python_version.major}.{python_version.minor})")
        console.print("  Install Python 3.11+: https://python.org/downloads")
        sys.exit(1)

    # Step 2: Check Claude Code CLI
    console.print("\n[bold]Step 2/5: Checking Claude Code CLI...[/bold]")
    try:
        result = subprocess.run(["claude", "--version"], capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            version = result.stdout.strip() or "installed"
            console.print(f"  [green]✓[/green] Claude Code CLI {version}")
        else:
            raise FileNotFoundError()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        console.print("  [red]✗[/red] Claude Code CLI not found")
        console.print()
        console.print("  [bold]Install Claude Code CLI:[/bold]")
        console.print("  1. npm install -g @anthropic-ai/claude-code")
        console.print("  2. claude login")
        console.print()
        console.print("  [dim]Requires Claude Max subscription ($100-$200/month)[/dim]")

        if not Confirm.ask("  Continue setup anyway?", default=False):
            sys.exit(1)

    # Step 3: Telegram Setup
    console.print("\n[bold]Step 3/5: Telegram Setup[/bold]")
    console.print("  [dim]Control your agents remotely via Telegram[/dim]")

    # Check for existing config
    existing_token = None
    existing_admin = None
    existing_users = []
    if existing_config:
        telegram_cfg = existing_config.get("telegram", {})
        existing_token = telegram_cfg.get("bot_token")
        if existing_token and existing_token.startswith("$"):
            existing_token = None  # Placeholder, not real token
        existing_admin = telegram_cfg.get("admins", [None])[0] if telegram_cfg.get("admins") else telegram_cfg.get("user_id")
        existing_users = telegram_cfg.get("allowed_users", [])

    use_telegram = Confirm.ask("  Do you want to use Telegram?", default=True)
    bot_token = None
    admin_id = None
    allowed_users = []

    if use_telegram:
        # Bot token
        console.print()
        console.print("  [bold]Step 3a: Create a Telegram Bot[/bold]")
        console.print("  1. Open Telegram, search @BotFather")
        console.print("  2. Send /newbot, follow the prompts")
        console.print("  3. Copy the token (looks like: 123456789:ABCxyz...)")
        console.print()

        default_token = existing_token or ""
        bot_token = Prompt.ask("  Bot token", default=default_token)

        # Admin user ID
        console.print()
        console.print("  [bold]Step 3b: Your Telegram User ID (Admin)[/bold]")
        console.print("  1. Open Telegram, search @userinfobot")
        console.print("  2. Send /start")
        console.print("  3. Copy your ID (a number like: 123456789)")
        console.print()

        default_admin = str(existing_admin) if existing_admin else ""
        admin_id = Prompt.ask("  Your user ID (admin)", default=default_admin)

        # Additional users
        console.print()
        console.print("  [bold]Step 3c: Additional Users (optional)[/bold]")
        console.print("  [dim]Add friends who can use your bot. You can also add them later with /approve[/dim]")
        console.print()

        if existing_users:
            console.print(f"  [dim]Existing users: {existing_users}[/dim]")

        add_users = Prompt.ask("  Additional user IDs (comma-separated, or Enter to skip)", default="")
        if add_users.strip():
            for uid in add_users.split(","):
                uid = uid.strip()
                if uid.isdigit():
                    allowed_users.append(int(uid))

    # Step 4: Configuration
    console.print("\n[bold]Step 4/5: Creating configuration...[/bold]")

    telegram_config = {}
    if bot_token:
        telegram_config["bot_token"] = bot_token
    if admin_id and admin_id.isdigit():
        telegram_config["admins"] = [int(admin_id)]
    if allowed_users:
        telegram_config["allowed_users"] = allowed_users

    config = {
        "telegram": telegram_config,
        "agent": {
            "model": "opus",
            "timeout": 1800,
            "max_errors": 3,
        },
        "reliability": {
            "plan": "max_200",
            "exit_detection": {
                "enabled": True,
                "max_cycles": 100,
            },
        },
        "paths": {
            "projects_dir": "./projects",
        },
    }

    config_path = Path.cwd() / "config.yaml"
    with open(config_path, "w") as f:
        f.write("# Nullabot Configuration\n")
        f.write("# Generated by: nullabot setup\n\n")
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)

    console.print(f"  [green]✓[/green] Created config.yaml")

    # Create projects directory
    projects_dir = Path.cwd() / "projects"
    projects_dir.mkdir(exist_ok=True)
    console.print(f"  [green]✓[/green] Created projects/ directory")

    # Step 5: Done!
    console.print("\n[bold]Step 5/5: Setup complete![/bold]")
    console.print()

    telegram_info = ""
    if bot_token:
        telegram_info = (
            "\n[bold]Telegram Bot:[/bold]\n"
            "  nullabot bot                        Start the bot\n"
        )
        if allowed_users:
            telegram_info += f"  Users: admin + {len(allowed_users)} allowed\n"
        telegram_info += "  /approve <id>                       Add users later\n"

    console.print(Panel(
        "[bold green]Setup complete![/bold green]\n\n"
        "[bold]Quick start:[/bold]\n"
        "  nullabot new myproject              Create a project\n"
        "  nullabot think myproject \"task\"     Start thinking\n"
        + telegram_info +
        "\n[bold]Useful commands:[/bold]\n"
        "  nullabot projects                   List projects\n"
        "  nullabot status                     Show running agents\n"
        "  nullabot --help                     All commands",
        title="✅ Ready!",
    ))


@cli.command("projects")
@click.pass_context
def list_projects(ctx):
    """List all projects."""
    projects_dir = ctx.obj["projects_dir"]
    projects = list_all_projects(projects_dir)

    if not projects:
        console.print("[yellow]No projects yet.[/yellow]")
        console.print("Create one with: [bold]nullabot new <name>[/bold]")
        return

    table = Table(title="Projects")
    table.add_column("Name", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Cycles")
    table.add_column("Task")

    import json
    for p in sorted(projects, key=lambda x: x.name):
        state_file = p / ".nullabot" / "state.json"
        if state_file.exists():
            try:
                state = json.loads(state_file.read_text())
                status = state.get("status", "unknown")
                cycles = str(state.get("cycles", 0))
                task = state.get("task", "-")
                if task and len(task) > 40:
                    task = task[:40] + "..."

                status_icon = {
                    "running": "🟢 Running",
                    "paused": "⏸️  Paused",
                    "completed": "✅ Done",
                    "idle": "⚪ Idle",
                }.get(status, f"❓ {status}")
            except:
                status_icon = "❓ Unknown"
                cycles = "-"
                task = "-"
        else:
            status_icon = "⚪ Idle"
            cycles = "0"
            task = "-"

        table.add_row(p.name, status_icon, cycles, task)

    console.print(table)


@cli.command("new")
@click.argument("name")
@click.option("--description", "-d", default="", help="Project description")
@click.pass_context
def new_project(ctx, name: str, description: str):
    """Create a new project."""
    projects_dir = ctx.obj["projects_dir"]
    project_path = projects_dir / name

    if project_path.exists():
        console.print(f"[red]Project already exists:[/red] {name}")
        sys.exit(1)

    # Create project structure
    project_path.mkdir(parents=True)
    (project_path / ".nullabot").mkdir()

    # Save config
    import json
    config = {
        "name": name,
        "description": description,
        "created_at": __import__("datetime").datetime.now().isoformat(),
    }
    (project_path / ".nullabot" / "config.json").write_text(json.dumps(config, indent=2))

    console.print(f"[green]✅ Created project:[/green] {name}")
    console.print(f"[dim]Location: {project_path}[/dim]")
    console.print()
    console.print("Start an agent:")
    console.print(f'  [bold]nullabot think {name} "your research task"[/bold]')
    console.print(f'  [bold]nullabot design {name} "your design task"[/bold]')
    console.print(f'  [bold]nullabot code {name} "your coding task"[/bold]')


@cli.command("status")
@click.argument("project", required=False)
@click.pass_context
def show_status(ctx, project: str | None):
    """Show status of project(s)."""
    import json
    projects_dir = ctx.obj["projects_dir"]

    if project:
        # Show specific project
        project_path = projects_dir / project
        if not project_path.exists():
            console.print(f"[red]Project not found:[/red] {project}")
            sys.exit(1)

        state_file = project_path / ".nullabot" / "state.json"
        if not state_file.exists():
            console.print(f"[yellow]No agent has run on {project} yet[/yellow]")
            return

        state = json.loads(state_file.read_text())
        console.print(Panel(
            f"[bold]Task:[/bold] {state.get('task', 'None')}\n"
            f"[bold]Status:[/bold] {state.get('status', 'unknown')}\n"
            f"[bold]Cycles:[/bold] {state.get('cycles', 0)}\n"
            f"[bold]Started:[/bold] {state.get('started_at', 'N/A')}\n"
            f"[bold]Updated:[/bold] {state.get('updated_at', 'N/A')}\n\n"
            f"[bold]Last checkpoint:[/bold]\n{(state.get('last_checkpoint') or 'None')[:500]}",
            title=f"📁 {project}",
        ))

        # Show files created
        workspace_files = list(project_path.glob("**/*"))
        workspace_files = [f for f in workspace_files if f.is_file() and ".nullabot" not in str(f)]
        if workspace_files:
            console.print("\n[bold]Files created:[/bold]")
            for f in workspace_files[:20]:
                rel = f.relative_to(project_path)
                console.print(f"  {rel}")
            if len(workspace_files) > 20:
                console.print(f"  ... and {len(workspace_files) - 20} more")
    else:
        # Show all running projects
        projects = list_all_projects(projects_dir)
        running = []

        for p in projects:
            state_file = p / ".nullabot" / "state.json"
            if state_file.exists():
                state = json.loads(state_file.read_text())
                if state.get("status") == "running":
                    running.append((p.name, state))

        if not running:
            console.print("[yellow]No agents currently running.[/yellow]")
            return

        for name, state in running:
            console.print(Panel(
                f"[bold]Task:[/bold] {state.get('task', 'None')}\n"
                f"[bold]Cycles:[/bold] {state.get('cycles', 0)}",
                title=f"🟢 {name}",
                border_style="green",
            ))


async def run_agent(
    project_path: Path,
    task: str,
    agent_type: str,
    model: str,
    continuous: bool,
):
    """Run an agent on a project."""
    from nullabot.agents.claude_agent import ClaudeAgent

    agent = ClaudeAgent(
        workspace=project_path,
        agent_type=agent_type,
        model=model,
    )

    await agent.start(task, continuous=continuous)


@cli.command("think")
@click.argument("project")
@click.argument("task")
@click.option("--model", "-m", default="opus", help="Model: opus, sonnet, haiku")
@click.option("--once", is_flag=True, help="Run single cycle only")
@click.pass_context
def start_thinker(ctx, project: str, task: str, model: str, once: bool):
    """Start Thinker agent (research & ideation)."""
    project_path = ctx.obj["projects_dir"] / project

    if not project_path.exists():
        console.print(f"[red]Project not found:[/red] {project}")
        console.print(f"Create it with: [bold]nullabot new {project}[/bold]")
        sys.exit(1)

    asyncio.run(run_agent(project_path, task, "thinker", model, not once))


@cli.command("design")
@click.argument("project")
@click.argument("task")
@click.option("--model", "-m", default="opus", help="Model: opus, sonnet, haiku")
@click.option("--once", is_flag=True, help="Run single cycle only")
@click.pass_context
def start_designer(ctx, project: str, task: str, model: str, once: bool):
    """Start Designer agent (UI/UX specs)."""
    project_path = ctx.obj["projects_dir"] / project

    if not project_path.exists():
        console.print(f"[red]Project not found:[/red] {project}")
        sys.exit(1)

    asyncio.run(run_agent(project_path, task, "designer", model, not once))


@cli.command("code")
@click.argument("project")
@click.argument("task")
@click.option("--model", "-m", default="opus", help="Model: opus, sonnet, haiku")
@click.option("--once", is_flag=True, help="Run single cycle only")
@click.pass_context
def start_coder(ctx, project: str, task: str, model: str, once: bool):
    """Start Coder agent (write code & tests)."""
    project_path = ctx.obj["projects_dir"] / project

    if not project_path.exists():
        console.print(f"[red]Project not found:[/red] {project}")
        sys.exit(1)

    asyncio.run(run_agent(project_path, task, "coder", model, not once))


@cli.command("run")
@click.argument("project")
@click.argument("task")
@click.option("--type", "-t", "agent_type", default="thinker", help="Agent type")
@click.option("--model", "-m", default="opus", help="Model: opus, sonnet, haiku")
@click.pass_context
def run_once(ctx, project: str, task: str, agent_type: str, model: str):
    """Run a single cycle (no continuous loop)."""
    project_path = ctx.obj["projects_dir"] / project

    if not project_path.exists():
        console.print(f"[red]Project not found:[/red] {project}")
        sys.exit(1)

    asyncio.run(run_agent(project_path, task, agent_type, model, continuous=False))


@cli.command("stop")
@click.argument("project")
@click.pass_context
def stop_agent(ctx, project: str):
    """Mark agent as stopped (updates state file)."""
    import json

    project_path = ctx.obj["projects_dir"] / project

    if not project_path.exists():
        console.print(f"[red]Project not found:[/red] {project}")
        sys.exit(1)

    state_file = project_path / ".nullabot" / "state.json"
    if state_file.exists():
        state = json.loads(state_file.read_text())
        state["status"] = "paused"
        state_file.write_text(json.dumps(state, indent=2))
        console.print(f"[green]Marked {project} as paused[/green]")
    else:
        console.print(f"[yellow]No agent state found for {project}[/yellow]")


@cli.command("delete")
@click.argument("project")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
@click.pass_context
def delete_project(ctx, project: str, yes: bool):
    """Delete a project and all its files."""
    import shutil

    project_path = ctx.obj["projects_dir"] / project

    if not project_path.exists():
        console.print(f"[red]Project not found:[/red] {project}")
        sys.exit(1)

    if not yes:
        confirm = console.input(f"[red]Delete '{project}' and all files?[/red] [y/N]: ")
        if confirm.lower() != "y":
            console.print("Cancelled.")
            return

    shutil.rmtree(project_path)
    console.print(f"[green]Deleted project:[/green] {project}")


@cli.command("logs")
@click.argument("project")
@click.option("--lines", "-n", default=20, help="Number of lines to show")
@click.pass_context
def show_logs(ctx, project: str, lines: int):
    """Show agent logs for a project."""
    project_path = ctx.obj["projects_dir"] / project

    if not project_path.exists():
        console.print(f"[red]Project not found:[/red] {project}")
        sys.exit(1)

    log_file = project_path / ".nullabot" / "log.jsonl"
    if not log_file.exists():
        console.print("[yellow]No logs yet[/yellow]")
        return

    import json
    log_lines = log_file.read_text().strip().split("\n")

    for line in log_lines[-lines:]:
        try:
            entry = json.loads(line)
            ts = entry.get("timestamp", "")[:19]
            event = entry.get("event", "")
            data = entry.get("data", {})

            if event == "started":
                console.print(f"[dim]{ts}[/dim] [green]Started:[/green] {data.get('task', '')[:60]}")
            elif event == "stopped":
                console.print(f"[dim]{ts}[/dim] [yellow]Stopped:[/yellow] {data.get('cycles', 0)} cycles")
            elif event == "error":
                console.print(f"[dim]{ts}[/dim] [red]Error:[/red] {data.get('message', '')[:60]}")
            elif event == "response":
                content = data.get("content", "")[:80]
                console.print(f"[dim]{ts}[/dim] [blue]Response:[/blue] {content}...")
        except:
            pass


@cli.command("usage")
@click.option("--watch", "-w", is_flag=True, help="Watch mode - refresh every 5 seconds")
@click.pass_context
def show_usage(ctx, watch: bool):
    """Show nullabot project usage and costs."""
    import time
    from nullabot.core.memory import UsageTracker

    projects_dir = ctx.obj["projects_dir"]
    base_dir = projects_dir.parent

    def render():
        # Per-project breakdown
        projects = list_all_projects(projects_dir)
        if projects:
            table = Table(title="Nullabot Project Usage", show_header=True)
            table.add_column("Project", style="cyan")
            table.add_column("Cycles", justify="right")
            table.add_column("Hours", justify="right")
            table.add_column("Cost", justify="right", style="green")

            total_cost = 0
            total_cycles = 0
            total_hours = 0

            for p in sorted(projects, key=lambda x: x.name):
                try:
                    tracker = UsageTracker(p, base_dir)
                    summary = tracker.get_summary()
                    if summary["total_cycles"] > 0:
                        table.add_row(
                            p.name,
                            str(summary["total_cycles"]),
                            f"{summary['total_hours']:.2f}",
                            f"${summary['total_cost_usd']:.2f}",
                        )
                        total_cost += summary["total_cost_usd"]
                        total_cycles += summary["total_cycles"]
                        total_hours += summary["total_hours"]
                except:
                    pass

            if total_cycles > 0:
                table.add_section()
                table.add_row(
                    "[bold]Total[/bold]",
                    f"[bold]{total_cycles}[/bold]",
                    f"[bold]{total_hours:.2f}[/bold]",
                    f"[bold]${total_cost:.2f}[/bold]",
                )
                console.print(table)
            else:
                console.print("[dim]No nullabot usage yet[/dim]")
        else:
            console.print("[dim]No projects yet[/dim]")

        # Note about real usage
        console.print()
        console.print(Panel(
            "[bold]For real Claude Code limits:[/bold]\n\n"
            "Run [cyan]claude[/cyan] in terminal, then type [cyan]/usage[/cyan]\n\n"
            "[dim]Shows actual 5hr session & weekly limits from Anthropic[/dim]",
            title="ℹ️  Claude Code CLI Usage",
            border_style="blue",
        ))

    if watch:
        console.print("[dim]Watching usage... Press Ctrl+C to stop[/dim]\n")
        try:
            while True:
                console.clear()
                render()
                console.print(f"\n[dim]Last updated: {datetime.now().strftime('%H:%M:%S')} (refreshing every 5s)[/dim]")
                time.sleep(5)
        except KeyboardInterrupt:
            console.print("\n[yellow]Stopped watching[/yellow]")
    else:
        render()


@cli.command("bot")
@click.option("--token", envvar="TELEGRAM_BOT_TOKEN", help="Telegram bot token")
@click.pass_context
def start_bot(ctx, token: str):
    """Start Telegram bot for remote control."""
    # Load config
    config_path = Path.cwd() / "config.yaml"
    allowed_users = []
    admins = []
    config_token = None

    if config_path.exists():
        try:
            config = yaml.safe_load(config_path.read_text())
            telegram_config = config.get("telegram", {})
            config_token = telegram_config.get("bot_token")
            allowed_users = telegram_config.get("allowed_users", [])
            admins = telegram_config.get("admins", [])
            # Fallback: treat user_id as admin if no admins configured
            if not admins and telegram_config.get("user_id"):
                admins = [telegram_config.get("user_id")]
        except:
            pass

    # Use token from: CLI arg > env var > config
    token = token or config_token
    if not token:
        console.print("[red]✗ No bot token found[/red]")
        console.print("Run: nullabot setup")
        console.print("Or set: export TELEGRAM_BOT_TOKEN=your-token")
        sys.exit(1)

    projects_dir = ctx.obj["projects_dir"]

    console.print(Panel(
        f"[bold green]Starting Nullabot Telegram Bot[/bold green]\n\n"
        f"Projects dir: {projects_dir}\n"
        f"Admins: {admins or 'none'}\n"
        f"Allowed users: {allowed_users or 'all'}\n\n"
        f"[bold]Features:[/bold]\n"
        f"  💰 Cost tracking enabled\n"
        f"  🧠 Memory system enabled\n"
        f"  🔄 Agent handoff enabled\n"
        f"  ⏱ 30 min timeout",
        title="🤖 Nullabot Bot",
    ))

    from nullabot.bot.telegram import TelegramBot

    bot = TelegramBot(
        token=token,
        projects_dir=projects_dir,
        allowed_users=allowed_users,
        admins=admins,
    )
    bot.run()


def main():
    """Entry point."""
    cli(obj={})


if __name__ == "__main__":
    main()
