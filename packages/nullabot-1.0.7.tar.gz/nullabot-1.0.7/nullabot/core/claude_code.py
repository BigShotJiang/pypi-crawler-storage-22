"""
Claude Code CLI Client - Uses claude command instead of API.

This allows Nullabot to use your Claude Code subscription ($200/month)
instead of requiring a separate Anthropic API key.
"""

import asyncio
import json
import os
import subprocess
from pathlib import Path
from typing import Any, Optional

from pydantic import BaseModel


class ClaudeResponse(BaseModel):
    """Response from Claude Code CLI."""

    content: str
    tool_calls: list[dict[str, Any]] = []
    cost_usd: float = 0.0
    duration_ms: int = 0


class ClaudeCodeClient:
    """
    Client that uses Claude Code CLI as the backend.

    Instead of calling Anthropic API directly, this spawns
    `claude` processes to use your Claude Code subscription.
    """

    def __init__(
        self,
        working_dir: Optional[Path] = None,
        model: str = "opus",  # opus, sonnet, haiku
        max_turns: int = 1,
    ):
        """
        Initialize Claude Code client.

        Args:
            working_dir: Directory for Claude to work in (sandbox)
            model: Model to use (opus, sonnet, haiku)
            max_turns: Max conversation turns per request
        """
        self.working_dir = working_dir or Path.cwd()
        self.model = model
        self.max_turns = max_turns

        # Verify claude is installed
        self._verify_claude_installed()

    def _verify_claude_installed(self) -> None:
        """Check if claude CLI is available."""
        try:
            result = subprocess.run(
                ["claude", "--version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                raise RuntimeError("claude command failed")
        except FileNotFoundError:
            raise RuntimeError(
                "Claude Code CLI not found. Install it first:\n"
                "  npm install -g @anthropic-ai/claude-code"
            )

    def _build_command(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        allowed_tools: Optional[list[str]] = None,
    ) -> list[str]:
        """Build the claude command."""
        cmd = [
            "claude",
            "-p",  # Print mode (non-interactive)
            "--output-format", "json",  # JSON output for parsing
            "--model", self.model,
            "--max-turns", str(self.max_turns),
        ]

        # Add allowed tools if specified
        if allowed_tools:
            cmd.extend(["--allowedTools", ",".join(allowed_tools)])

        # Add the prompt
        cmd.append(prompt)

        return cmd

    def _parse_response(self, output: str) -> ClaudeResponse:
        """Parse JSON output from claude CLI."""
        try:
            # Claude outputs JSON with result
            data = json.loads(output)

            # Extract content from response
            content = ""
            tool_calls = []

            if isinstance(data, dict):
                # Handle different response formats
                if "result" in data:
                    content = data["result"]
                elif "content" in data:
                    content = data["content"]
                elif "message" in data:
                    content = data.get("message", "")
                else:
                    content = str(data)

                # Extract cost info if available
                cost = data.get("cost_usd", 0.0)
                duration = data.get("duration_ms", 0)
            else:
                content = str(data)
                cost = 0.0
                duration = 0

            return ClaudeResponse(
                content=content,
                tool_calls=tool_calls,
                cost_usd=cost,
                duration_ms=duration,
            )
        except json.JSONDecodeError:
            # If not JSON, treat as plain text
            return ClaudeResponse(content=output.strip())

    def chat(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        allowed_tools: Optional[list[str]] = None,
        timeout: int = 300,
    ) -> ClaudeResponse:
        """
        Send a prompt to Claude Code CLI.

        Args:
            prompt: The prompt to send
            system_prompt: Optional system prompt (prepended to prompt)
            allowed_tools: List of allowed tools (None = all tools)
            timeout: Timeout in seconds

        Returns:
            ClaudeResponse with content and metadata
        """
        # Combine system prompt with user prompt if provided
        full_prompt = prompt
        if system_prompt:
            full_prompt = f"{system_prompt}\n\n---\n\n{prompt}"

        cmd = self._build_command(full_prompt, system_prompt, allowed_tools)

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd=str(self.working_dir),
                timeout=timeout,
                env={**os.environ, "CLAUDE_CODE_ENTRYPOINT": "nullabot"},
            )

            if result.returncode != 0:
                error_msg = result.stderr or result.stdout or "Unknown error"
                return ClaudeResponse(content=f"Error: {error_msg}")

            return self._parse_response(result.stdout)

        except subprocess.TimeoutExpired:
            return ClaudeResponse(content="Error: Request timed out")
        except Exception as e:
            return ClaudeResponse(content=f"Error: {str(e)}")

    async def chat_async(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        allowed_tools: Optional[list[str]] = None,
        timeout: int = 300,
    ) -> ClaudeResponse:
        """Async version of chat."""
        # Combine system prompt with user prompt if provided
        full_prompt = prompt
        if system_prompt:
            full_prompt = f"{system_prompt}\n\n---\n\n{prompt}"

        cmd = self._build_command(full_prompt, system_prompt, allowed_tools)

        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(self.working_dir),
                env={**os.environ, "CLAUDE_CODE_ENTRYPOINT": "nullabot"},
            )

            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=timeout,
            )

            if process.returncode != 0:
                error_msg = stderr.decode() or stdout.decode() or "Unknown error"
                return ClaudeResponse(content=f"Error: {error_msg}")

            return self._parse_response(stdout.decode())

        except asyncio.TimeoutError:
            return ClaudeResponse(content="Error: Request timed out")
        except Exception as e:
            return ClaudeResponse(content=f"Error: {str(e)}")


class ClaudeCodeAgent:
    """
    Simplified agent that lets Claude Code do the heavy lifting.

    Instead of managing tools ourselves, we let Claude Code
    handle file operations directly in the sandboxed workspace.
    """

    def __init__(
        self,
        workspace: Path,
        model: str = "opus",
    ):
        self.workspace = workspace.resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)

        self.client = ClaudeCodeClient(
            working_dir=self.workspace,
            model=model,
            max_turns=5,  # Allow multiple turns for complex tasks
        )

        # State file for persistence
        self.state_file = self.workspace / ".nullabot_state.json"

    def _load_state(self) -> dict:
        """Load agent state."""
        if self.state_file.exists():
            return json.loads(self.state_file.read_text())
        return {"history": [], "checkpoint": None}

    def _save_state(self, state: dict) -> None:
        """Save agent state."""
        self.state_file.write_text(json.dumps(state, indent=2, default=str))

    async def run(
        self,
        task: str,
        system_prompt: Optional[str] = None,
        on_output: Optional[callable] = None,
    ) -> str:
        """
        Run a task using Claude Code.

        Args:
            task: What to do
            system_prompt: Custom system prompt
            on_output: Callback for streaming output

        Returns:
            Final response content
        """
        state = self._load_state()

        # Build context from history
        context = ""
        if state.get("checkpoint"):
            context = f"\n\nPrevious progress:\n{state['checkpoint']}\n\nContinue from where you left off.\n"

        full_task = f"{task}{context}"

        # Run Claude
        response = await self.client.chat_async(
            prompt=full_task,
            system_prompt=system_prompt,
            allowed_tools=["Read", "Write", "Edit", "Bash", "Glob", "Grep"],
        )

        # Update state
        state["history"].append({
            "task": task,
            "response": response.content[:500],  # Truncate for storage
        })
        state["checkpoint"] = response.content[:1000]
        self._save_state(state)

        if on_output:
            on_output(response.content)

        return response.content
