"""
Memory System - Like ChatGPT's memory.

Three levels:
1. User Memory (global): Preferences, patterns, learnings across ALL projects
2. Project Memory (long-term): Decisions, context for ONE project
3. Session Memory (short-term): Current session context
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Optional


class UserMemory:
    """
    User-level memory shared across ALL projects.

    Stores:
    - User preferences (coding style, frameworks, etc.)
    - Learned patterns (what user likes/dislikes)
    - Global context (company info, common requirements)

    Storage location: {base_dir}/users/{user_id}/memory.json
    """

    def __init__(self, base_dir: Path, user_id: int):
        """
        Initialize user memory.

        Args:
            base_dir: Base directory (nullabot repo root)
            user_id: User ID (required - from Telegram user ID)
        """
        if not user_id:
            raise ValueError("user_id is required for UserMemory")

        self.base_dir = Path(base_dir)
        self.user_id = user_id

        # Location: {base_dir}/users/{user_id}/
        self.memory_dir = self.base_dir / "users" / str(user_id)
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self.memory_file = self.memory_dir / "memory.json"
        self._memory = self._load()

    def _load(self) -> dict:
        """Load user memory from disk."""
        if self.memory_file.exists():
            try:
                return json.loads(self.memory_file.read_text())
            except:
                pass
        return {
            "preferences": [],      # User preferences
            "patterns": [],         # Learned patterns
            "context": [],          # Global context
            "rules": [],            # Explicit rules: DO this / DON'T do this
            "projects_summary": {}, # Brief summary of each project
            "created_at": datetime.now().isoformat(),
        }

    def _save(self) -> None:
        """Save user memory to disk."""
        self._memory["updated_at"] = datetime.now().isoformat()
        self.memory_file.write_text(json.dumps(self._memory, indent=2))

    # === Preferences ===

    def add_preference(self, preference: str, category: str = "general") -> None:
        """
        Store a user preference.

        Examples:
        - "Prefers React over Vue"
        - "Always use TypeScript"
        - "Likes minimal UI design"
        """
        # Check for duplicates
        for p in self._memory["preferences"]:
            if p["preference"].lower() == preference.lower():
                return

        self._memory["preferences"].append({
            "preference": preference,
            "category": category,
            "timestamp": datetime.now().isoformat(),
        })
        # Keep last 50 preferences
        self._memory["preferences"] = self._memory["preferences"][-50:]
        self._save()

    def get_preferences(self, category: str = None) -> list[str]:
        """Get user preferences."""
        prefs = self._memory["preferences"]
        if category:
            prefs = [p for p in prefs if p.get("category") == category]
        return [p["preference"] for p in prefs]

    # === Patterns ===

    def learn_pattern(self, pattern: str) -> None:
        """
        Learn a pattern about the user.

        Examples:
        - "User often asks for detailed comments"
        - "User prefers functional programming style"
        """
        for p in self._memory["patterns"]:
            if p["pattern"].lower() == pattern.lower():
                return

        self._memory["patterns"].append({
            "pattern": pattern,
            "timestamp": datetime.now().isoformat(),
        })
        self._memory["patterns"] = self._memory["patterns"][-30:]
        self._save()

    def get_patterns(self) -> list[str]:
        """Get learned patterns."""
        return [p["pattern"] for p in self._memory["patterns"]]

    # === Rules (DO / DON'T) ===

    def add_rule(self, rule: str, rule_type: str = "do") -> None:
        """
        Store an explicit user rule.

        Args:
            rule: The rule text
            rule_type: "do" (always do this) or "dont" (never do this)

        Examples:
        - ("Use TypeScript everywhere", "do")
        - ("Never use console.log in production", "dont")
        - ("Always add error handling", "do")
        """
        # Check for duplicates
        for r in self._memory.get("rules", []):
            if r["rule"].lower() == rule.lower():
                return

        if "rules" not in self._memory:
            self._memory["rules"] = []

        self._memory["rules"].append({
            "rule": rule,
            "type": rule_type,  # "do" or "dont"
            "timestamp": datetime.now().isoformat(),
        })
        # Keep last 50 rules
        self._memory["rules"] = self._memory["rules"][-50:]
        self._save()

    def get_rules(self, rule_type: str = None) -> list[dict]:
        """Get user rules, optionally filtered by type."""
        rules = self._memory.get("rules", [])
        if rule_type:
            rules = [r for r in rules if r.get("type") == rule_type]
        return rules

    def remove_rule(self, rule: str) -> bool:
        """Remove a rule by its text."""
        rules = self._memory.get("rules", [])
        for i, r in enumerate(rules):
            if r["rule"].lower() == rule.lower():
                rules.pop(i)
                self._save()
                return True
        return False

    # === Global Context ===

    def add_context(self, context: str) -> None:
        """
        Add global context.

        Examples:
        - "User works at a real estate company"
        - "Target market is Mongolia"
        """
        for c in self._memory["context"]:
            if c["context"].lower() == context.lower():
                return

        self._memory["context"].append({
            "context": context,
            "timestamp": datetime.now().isoformat(),
        })
        self._memory["context"] = self._memory["context"][-20:]
        self._save()

    def get_context(self) -> list[str]:
        """Get global context."""
        return [c["context"] for c in self._memory["context"]]

    # === Project Summaries ===

    def update_project_summary(self, project_name: str, summary: str) -> None:
        """Update summary for a project (for cross-project awareness)."""
        self._memory["projects_summary"][project_name] = {
            "summary": summary,
            "timestamp": datetime.now().isoformat(),
        }
        self._save()

    def get_project_summaries(self) -> dict[str, str]:
        """Get summaries of all projects."""
        return {
            name: data["summary"]
            for name, data in self._memory["projects_summary"].items()
        }

    # === Build Context ===

    def build_user_context(self) -> str:
        """Build user context string for prompts."""
        lines = []

        # Rules are most important - show first
        do_rules = self.get_rules("do")
        dont_rules = self.get_rules("dont")

        if do_rules or dont_rules:
            lines.append("## User Rules (IMPORTANT - Follow these!)")
            if do_rules:
                lines.append("✅ ALWAYS DO:")
                for r in do_rules[-10:]:
                    lines.append(f"  - {r['rule']}")
            if dont_rules:
                lines.append("❌ NEVER DO:")
                for r in dont_rules[-10:]:
                    lines.append(f"  - {r['rule']}")
            lines.append("")

        prefs = self.get_preferences()
        if prefs:
            lines.append("## User Preferences")
            for p in prefs[-10:]:
                lines.append(f"- {p}")
            lines.append("")

        patterns = self.get_patterns()
        if patterns:
            lines.append("## Known Patterns")
            for p in patterns[-5:]:
                lines.append(f"- {p}")
            lines.append("")

        context = self.get_context()
        if context:
            lines.append("## User Context")
            for c in context[-5:]:
                lines.append(f"- {c}")
            lines.append("")

        return "\n".join(lines) if lines else ""

    def extract_from_response(self, response: str) -> None:
        """Auto-extract user preferences and rules from response."""
        response_lower = response.lower()

        # Look for explicit DONT rules
        dont_phrases = [
            "don't ever", "dont ever", "never use", "never do",
            "don't use", "dont use", "stop using", "avoid",
            "we cannot", "we can't", "don't want", "dont want",
        ]
        for phrase in dont_phrases:
            if phrase in response_lower:
                for line in response.split("\n"):
                    if phrase in line.lower() and len(line) < 150:
                        self.add_rule(line.strip(), "dont")
                        break

        # Look for explicit DO rules
        do_phrases = [
            "always use", "use this everywhere", "always do",
            "make sure to", "from now on", "use this one",
            "remember to", "must use", "should always",
        ]
        for phrase in do_phrases:
            if phrase in response_lower:
                for line in response.split("\n"):
                    if phrase in line.lower() and len(line) < 150:
                        self.add_rule(line.strip(), "do")
                        break

        # Look for preference indicators
        pref_phrases = [
            ("prefer", "preference"),
            ("like to", "pattern"),
            ("style is", "pattern"),
        ]

        for phrase, category in pref_phrases:
            if phrase in response_lower:
                for line in response.split("\n"):
                    if phrase in line.lower() and len(line) < 100:
                        if category == "preference":
                            self.add_preference(line.strip())
                        else:
                            self.learn_pattern(line.strip())
                        break


class ProjectMemory:
    """
    Memory system for a project.

    Stores:
    - Long-term: Important facts, decisions, learnings (persists forever)
    - Short-term: Recent context, current session info (cleared on new session)
    - Agent summaries: What each agent type has accomplished
    """

    def __init__(self, project_path: Path):
        self.project_path = project_path
        self.nullabot_dir = project_path / ".nullabot"
        self.nullabot_dir.mkdir(exist_ok=True)

        self.memory_file = self.nullabot_dir / "memory.json"
        self._memory = self._load()

    def _load(self) -> dict:
        """Load memory from disk."""
        if self.memory_file.exists():
            try:
                return json.loads(self.memory_file.read_text())
            except:
                pass
        return {
            "long_term": [],
            "short_term": [],
            "agent_summaries": {
                "thinker": None,
                "designer": None,
                "coder": None,
            },
            "key_decisions": [],
            "files_purpose": {},  # file path -> what it's for
            "created_at": datetime.now().isoformat(),
        }

    def _save(self) -> None:
        """Save memory to disk."""
        self._memory["updated_at"] = datetime.now().isoformat()
        self.memory_file.write_text(json.dumps(self._memory, indent=2))

    # === Long-term Memory ===

    def remember(self, fact: str, category: str = "general") -> None:
        """
        Store a long-term memory (persists across sessions).

        Use for: Important decisions, user preferences, key learnings
        """
        self._memory["long_term"].append({
            "fact": fact,
            "category": category,
            "timestamp": datetime.now().isoformat(),
        })
        # Keep last 100 long-term memories
        self._memory["long_term"] = self._memory["long_term"][-100:]
        self._save()

    def get_long_term_memories(self, category: str = None, limit: int = 20) -> list[str]:
        """Get long-term memories, optionally filtered by category."""
        memories = self._memory["long_term"]
        if category:
            memories = [m for m in memories if m.get("category") == category]
        return [m["fact"] for m in memories[-limit:]]

    # === Short-term Memory ===

    def note(self, context: str) -> None:
        """
        Store short-term context (current session).

        Use for: What we're working on now, recent actions
        """
        self._memory["short_term"].append({
            "context": context,
            "timestamp": datetime.now().isoformat(),
        })
        # Keep last 20 short-term notes
        self._memory["short_term"] = self._memory["short_term"][-20:]
        self._save()

    def get_short_term_context(self, limit: int = 10) -> list[str]:
        """Get recent short-term context."""
        return [n["context"] for n in self._memory["short_term"][-limit:]]

    def clear_short_term(self) -> None:
        """Clear short-term memory (new session)."""
        self._memory["short_term"] = []
        self._save()

    # === Agent Summaries (for handoff) ===

    def save_agent_summary(self, agent_type: str, summary: str) -> None:
        """
        Save what an agent accomplished (for handoff to next agent).
        """
        self._memory["agent_summaries"][agent_type] = {
            "summary": summary,
            "timestamp": datetime.now().isoformat(),
        }
        self._save()

    def get_agent_summary(self, agent_type: str) -> Optional[str]:
        """Get what an agent accomplished."""
        data = self._memory["agent_summaries"].get(agent_type)
        if data:
            return data.get("summary")
        return None

    def get_all_agent_summaries(self) -> dict[str, str]:
        """Get summaries from all agents that have run."""
        summaries = {}
        for agent_type, data in self._memory["agent_summaries"].items():
            if data and data.get("summary"):
                summaries[agent_type] = data["summary"]
        return summaries

    # === Key Decisions ===

    def record_decision(self, decision: str, reasoning: str = "") -> None:
        """Record a key decision made during the project."""
        self._memory["key_decisions"].append({
            "decision": decision,
            "reasoning": reasoning,
            "timestamp": datetime.now().isoformat(),
        })
        self._memory["key_decisions"] = self._memory["key_decisions"][-50:]
        self._save()

    def get_decisions(self, limit: int = 10) -> list[dict]:
        """Get recent key decisions."""
        return self._memory["key_decisions"][-limit:]

    # === File Purpose Tracking ===

    def set_file_purpose(self, file_path: str, purpose: str) -> None:
        """Track what a file is for."""
        self._memory["files_purpose"][file_path] = purpose
        self._save()

    def get_file_purposes(self) -> dict[str, str]:
        """Get purposes of all tracked files."""
        return self._memory["files_purpose"]

    # === Context Building ===

    def build_context_for_agent(self, agent_type: str) -> str:
        """
        Build full context for an agent, including:
        - What other agents have done
        - Long-term memories
        - Recent short-term context
        - Key decisions
        """
        lines = []

        # Previous agent work
        summaries = self.get_all_agent_summaries()
        if summaries:
            lines.append("## Previous Work on This Project\n")
            for atype, summary in summaries.items():
                if atype != agent_type:  # Don't include own summary
                    emoji = {"thinker": "🧠", "designer": "🎨", "coder": "💻"}.get(atype, "🤖")
                    lines.append(f"### {emoji} {atype.upper()} completed:\n{summary}\n")

        # Key decisions
        decisions = self.get_decisions(5)
        if decisions:
            lines.append("## Key Decisions Made\n")
            for d in decisions:
                lines.append(f"- {d['decision']}")
            lines.append("")

        # Long-term memories
        memories = self.get_long_term_memories(limit=10)
        if memories:
            lines.append("## Important Context\n")
            for m in memories:
                lines.append(f"- {m}")
            lines.append("")

        # Recent context
        recent = self.get_short_term_context(5)
        if recent:
            lines.append("## Recent Activity\n")
            for r in recent:
                lines.append(f"- {r}")
            lines.append("")

        # File purposes
        files = self.get_file_purposes()
        if files:
            lines.append("## Project Files\n")
            for fpath, purpose in list(files.items())[:15]:
                lines.append(f"- `{fpath}`: {purpose}")
            lines.append("")

        return "\n".join(lines) if lines else ""

    def extract_memories_from_response(self, response: str) -> None:
        """
        Auto-extract important info from agent response.
        Look for decisions, facts, file creations.
        """
        response_lower = response.lower()

        # Look for decision indicators
        decision_phrases = ["decided to", "choosing", "will use", "going with", "selected"]
        for phrase in decision_phrases:
            if phrase in response_lower:
                # Extract sentence containing the phrase
                for line in response.split("\n"):
                    if phrase in line.lower() and len(line) < 200:
                        self.record_decision(line.strip())
                        break

        # Look for file creation indicators
        file_phrases = ["created", "wrote", "generated", "saved"]
        for line in response.split("\n"):
            line_lower = line.lower()
            for phrase in file_phrases:
                if phrase in line_lower and ("file" in line_lower or "/" in line):
                    # Try to extract file info
                    if len(line) < 150:
                        self.note(line.strip())
                    break


class GlobalWindowTracker:
    """
    Track the GLOBAL 5-hour window for Claude Code subscription.

    This is SHARED across all projects because Claude Code CLI uses
    a single 5-hour rolling window for the entire subscription.
    """

    FIVE_HOUR_WINDOW = 5 * 60 * 60  # 18000 seconds

    def __init__(self, base_dir: Path):
        """
        Initialize global window tracker.

        Args:
            base_dir: Base directory (nullabot repo root) for storing global state.
        """
        if not base_dir:
            raise ValueError("base_dir is required for GlobalWindowTracker")

        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self.window_file = self.base_dir / "global_window.json"
        self._data = self._load()

    def _load(self) -> dict:
        """Load global window state."""
        default = {
            "window_start": None,
            "window_duration": 0.0,
            "is_limit_reached": False,
            "limit_reached_at": None,
            "last_updated": None,
        }

        if self.window_file.exists():
            try:
                data = json.loads(self.window_file.read_text())
                for key, val in default.items():
                    if key not in data:
                        data[key] = val
                return data
            except:
                pass

        return default

    def _save(self) -> None:
        """Save global window state."""
        self._data["last_updated"] = datetime.now().isoformat()
        self.window_file.write_text(json.dumps(self._data, indent=2))

    def _check_window_reset(self) -> None:
        """Check if 5-hour window has expired and reset if needed."""
        if not self._data.get("window_start"):
            return

        try:
            window_start = datetime.fromisoformat(self._data["window_start"])
            elapsed = (datetime.now() - window_start).total_seconds()

            # If more than 5 hours since window start, reset
            if elapsed >= self.FIVE_HOUR_WINDOW:
                self._data["window_start"] = None
                self._data["window_duration"] = 0.0
                self._data["is_limit_reached"] = False
                self._data["limit_reached_at"] = None
                self._save()
        except:
            pass

    def record_usage(self, duration_seconds: float) -> dict:
        """
        Record usage time in the global 5-hour window.

        Returns:
            dict with window status info
        """
        self._check_window_reset()

        # Start window if not started
        if not self._data.get("window_start"):
            self._data["window_start"] = datetime.now().isoformat()
            self._data["window_duration"] = 0.0

        # Add duration
        self._data["window_duration"] += duration_seconds
        self._save()

        return self.get_status()

    def mark_limit_reached(self) -> None:
        """Mark that the 5-hour limit was reached (detected from error)."""
        self._data["is_limit_reached"] = True
        self._data["limit_reached_at"] = datetime.now().isoformat()
        self._data["window_duration"] = self.FIVE_HOUR_WINDOW  # Set to 100%
        self._save()

    def get_status(self) -> dict:
        """Get current window status."""
        self._check_window_reset()

        window_duration = self._data.get("window_duration", 0.0)
        window_pct = min(100, (window_duration / self.FIVE_HOUR_WINDOW) * 100)
        remaining = max(0, self.FIVE_HOUR_WINDOW - window_duration)

        return {
            "window_start": self._data.get("window_start"),
            "used_seconds": round(window_duration, 1),
            "used_hours": round(window_duration / 3600, 2),
            "remaining_seconds": round(remaining, 1),
            "remaining_hours": round(remaining / 3600, 2),
            "usage_pct": round(window_pct, 1),
            "is_limit_reached": self._data.get("is_limit_reached", False),
            "is_near_limit": window_pct >= 90,
        }


# Global singleton instance
_global_window_tracker: Optional[GlobalWindowTracker] = None


def get_global_window_tracker(base_dir: Path) -> GlobalWindowTracker:
    """Get or create the global window tracker singleton."""
    global _global_window_tracker
    if _global_window_tracker is None:
        _global_window_tracker = GlobalWindowTracker(base_dir)
    return _global_window_tracker


class UsageTracker:
    """
    Track usage for Claude Code subscription.

    Per-project stats (cycles, cost) + global 5-hour window tracking.
    """

    # 5-hour window in seconds
    FIVE_HOUR_WINDOW = 5 * 60 * 60  # 18000 seconds

    # Estimated cost per hour (for $200/month Max plan)
    COST_PER_HOUR = {
        "opus": 8.33,    # ~$200/24 hours weekly limit
        "sonnet": 0.83,  # ~$200/240 hours weekly limit
        "haiku": 0.42,   # Cheaper
    }

    def __init__(self, project_path: Path, base_dir: Path = None):
        self.project_path = project_path
        self.nullabot_dir = project_path / ".nullabot"
        self.nullabot_dir.mkdir(exist_ok=True)

        self.usage_file = self.nullabot_dir / "usage.json"
        self._usage = self._load()

        # Base dir for global tracking (default: grandparent of project)
        self.base_dir = base_dir or project_path.parent.parent

        # Use global window tracker for 5-hour limit
        self._global_window = get_global_window_tracker(self.base_dir)

    def _load(self) -> dict:
        """Load usage from disk, migrating old format if needed."""
        default = {
            "total_cycles": 0,
            "total_duration_seconds": 0.0,
            "total_cost_usd": 0.0,
            "current_window_start": None,
            "current_window_duration": 0.0,
            "sessions": [],
            "by_model": {},
            "by_agent": {},
            "created_at": datetime.now().isoformat(),
        }

        if self.usage_file.exists():
            try:
                data = json.loads(self.usage_file.read_text())

                # Migrate old format to new format
                if "total_duration_seconds" not in data:
                    # Old format had tokens, estimate duration from sessions
                    total_duration = 0.0
                    for session in data.get("sessions", []):
                        total_duration += session.get("duration", 0)

                    data["total_duration_seconds"] = total_duration
                    data["current_window_start"] = data.get("current_window_start")
                    data["current_window_duration"] = data.get("current_window_duration", 0.0)

                    # Migrate by_model format
                    for model, info in data.get("by_model", {}).items():
                        if "duration" not in info:
                            info["duration"] = 0.0

                    # Migrate by_agent format
                    for agent, info in data.get("by_agent", {}).items():
                        if "duration" not in info:
                            info["duration"] = 0.0

                # Ensure all required keys exist
                for key, val in default.items():
                    if key not in data:
                        data[key] = val

                return data
            except:
                pass

        return default

    def _save(self) -> None:
        """Save usage to disk."""
        self._usage["updated_at"] = datetime.now().isoformat()
        self.usage_file.write_text(json.dumps(self._usage, indent=2))

    def _check_window_reset(self) -> None:
        """Check if 5-hour window has reset and update accordingly."""
        if not self._usage.get("current_window_start"):
            self._usage["current_window_start"] = datetime.now().isoformat()
            self._usage["current_window_duration"] = 0.0
            return

        try:
            window_start = datetime.fromisoformat(self._usage["current_window_start"])
            elapsed = (datetime.now() - window_start).total_seconds()

            # If more than 5 hours since window start, reset
            if elapsed >= self.FIVE_HOUR_WINDOW:
                self._usage["current_window_start"] = datetime.now().isoformat()
                self._usage["current_window_duration"] = 0.0
        except:
            self._usage["current_window_start"] = datetime.now().isoformat()
            self._usage["current_window_duration"] = 0.0

    def record_cycle(
        self,
        model: str,
        agent_type: str,
        input_tokens: int = 0,
        output_tokens: int = 0,
        duration_seconds: float = 0,
    ) -> dict:
        """Record a cycle's usage based on actual duration and tokens."""
        # Calculate cost based on time (more accurate for subscriptions)
        hourly_rate = self.COST_PER_HOUR.get(model, self.COST_PER_HOUR["opus"])
        cost = (duration_seconds / 3600) * hourly_rate

        # Initialize token tracking if not present
        if "total_input_tokens" not in self._usage:
            self._usage["total_input_tokens"] = 0
            self._usage["total_output_tokens"] = 0

        # Update project totals
        self._usage["total_cycles"] += 1
        self._usage["total_duration_seconds"] += duration_seconds
        self._usage["total_cost_usd"] += cost
        self._usage["total_input_tokens"] += input_tokens
        self._usage["total_output_tokens"] += output_tokens

        # By model
        if model not in self._usage["by_model"]:
            self._usage["by_model"][model] = {
                "cycles": 0, "duration": 0.0, "cost": 0.0,
                "input_tokens": 0, "output_tokens": 0
            }
        self._usage["by_model"][model]["cycles"] += 1
        self._usage["by_model"][model]["duration"] += duration_seconds
        self._usage["by_model"][model]["cost"] += cost
        self._usage["by_model"][model]["input_tokens"] += input_tokens
        self._usage["by_model"][model]["output_tokens"] += output_tokens

        # By agent
        if agent_type not in self._usage["by_agent"]:
            self._usage["by_agent"][agent_type] = {
                "cycles": 0, "duration": 0.0, "cost": 0.0,
                "input_tokens": 0, "output_tokens": 0
            }
        self._usage["by_agent"][agent_type]["cycles"] += 1
        self._usage["by_agent"][agent_type]["duration"] += duration_seconds
        self._usage["by_agent"][agent_type]["cost"] += cost
        self._usage["by_agent"][agent_type]["input_tokens"] += input_tokens
        self._usage["by_agent"][agent_type]["output_tokens"] += output_tokens

        # Session log
        self._usage["sessions"].append({
            "timestamp": datetime.now().isoformat(),
            "model": model,
            "agent": agent_type,
            "duration": round(duration_seconds, 1),
            "cost": round(cost, 4),
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
        })
        # Keep last 500 sessions
        self._usage["sessions"] = self._usage["sessions"][-500:]

        self._save()

        # Update GLOBAL 5-hour window (shared across all projects)
        window_status = self._global_window.record_usage(duration_seconds)

        total_tokens = self._usage["total_input_tokens"] + self._usage["total_output_tokens"]

        return {
            "cycle_cost": round(cost, 2),
            "total_cost": round(self._usage["total_cost_usd"], 2),
            "total_cycles": self._usage["total_cycles"],
            "cycle_duration": round(duration_seconds, 1),
            "total_duration": round(self._usage["total_duration_seconds"], 1),
            "cycle_input_tokens": input_tokens,
            "cycle_output_tokens": output_tokens,
            "cycle_tokens": input_tokens + output_tokens,
            "total_input_tokens": self._usage["total_input_tokens"],
            "total_output_tokens": self._usage["total_output_tokens"],
            "total_tokens": total_tokens,
            "window_usage_pct": window_status["usage_pct"],
            "window_duration": window_status["used_seconds"],
            "window_hours": window_status["used_hours"],
            "window_remaining_hours": window_status["remaining_hours"],
        }

    def get_summary(self) -> dict:
        """Get usage summary with GLOBAL window status."""
        total_hours = self._usage["total_duration_seconds"] / 3600

        # Get global window status
        window_status = self._global_window.get_status()

        # Token totals (with backwards compatibility)
        total_input = self._usage.get("total_input_tokens", 0)
        total_output = self._usage.get("total_output_tokens", 0)

        return {
            "total_cycles": self._usage["total_cycles"],
            "total_cost_usd": round(self._usage["total_cost_usd"], 2),
            "total_hours": round(total_hours, 2),
            "total_input_tokens": total_input,
            "total_output_tokens": total_output,
            "total_tokens": total_input + total_output,
            "window_hours": window_status["used_hours"],
            "window_usage_pct": window_status["usage_pct"],
            "window_remaining_hours": window_status["remaining_hours"],
            "is_limit_reached": window_status["is_limit_reached"],
            "by_model": self._usage["by_model"],
            "by_agent": self._usage["by_agent"],
        }

    def get_recent_sessions(self, limit: int = 10) -> list[dict]:
        """Get recent session logs."""
        return self._usage["sessions"][-limit:]

    def get_window_status(self) -> dict:
        """Get current GLOBAL 5-hour window status."""
        return self._global_window.get_status()

    def mark_limit_reached(self) -> None:
        """Mark that the 5-hour limit was reached (detected from error)."""
        self._global_window.mark_limit_reached()
