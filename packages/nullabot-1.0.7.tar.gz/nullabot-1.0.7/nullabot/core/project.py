"""
Project Management - Create and manage project groups.

Each project is an isolated workspace with its own agent and state.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Optional

from pydantic import BaseModel, Field

from nullabot.core.sandbox import Sandbox
from nullabot.core.state import AgentState, AgentStatus, AgentType, Checkpoint


class ProjectConfig(BaseModel):
    """Project configuration stored in .nullabot/config.json"""

    name: str
    description: str = ""
    created_at: datetime = Field(default_factory=datetime.now)

    # Active agent (only one at a time)
    active_agent: Optional[AgentType] = None

    # Project-specific settings
    allowed_paths: list[str] = Field(default_factory=list)  # Extra paths agent can access
    telegram_chat_id: Optional[int] = None  # For notifications


class Project:
    """
    A project workspace with isolated sandbox and agent state.
    """

    def __init__(self, root: Path):
        """
        Initialize project from existing folder.

        Args:
            root: Path to project folder
        """
        self.root = root.resolve()
        self.sandbox = Sandbox(self.root)
        self._config_path = self.sandbox._aurora_dir / "config.json"
        self._config: Optional[ProjectConfig] = None

    @property
    def name(self) -> str:
        return self.config.name

    @property
    def config(self) -> ProjectConfig:
        """Load or create project config."""
        if self._config is None:
            if self._config_path.exists():
                data = json.loads(self._config_path.read_text())
                self._config = ProjectConfig.model_validate(data)
            else:
                # Shouldn't happen - use create() for new projects
                self._config = ProjectConfig(name=self.root.name)
                self._save_config()
        return self._config

    def _save_config(self) -> None:
        """Save config to disk."""
        if self._config:
            self._config_path.write_text(self._config.model_dump_json(indent=2))

    @classmethod
    def create(cls, root: Path, name: str, description: str = "") -> "Project":
        """
        Create a new project.

        Args:
            root: Parent directory for project
            name: Project name (will be folder name)
            description: Optional description

        Returns:
            New Project instance
        """
        project_path = root / name
        if project_path.exists():
            raise ValueError(f"Project already exists: {project_path}")

        # Create directory structure
        project_path.mkdir(parents=True)
        (project_path / ".nullabot").mkdir()
        (project_path / "workspace").mkdir()

        # Create config
        config = ProjectConfig(name=name, description=description)
        config_path = project_path / ".nullabot" / "config.json"
        config_path.write_text(config.model_dump_json(indent=2))

        return cls(project_path)

    def get_agent_state(self, agent_type: AgentType) -> AgentState:
        """Get or create agent state."""
        state = AgentState.load(self.sandbox.state_file)
        if state is None or state.agent_type != agent_type:
            state = AgentState(
                agent_type=agent_type,
                project_name=self.name,
            )
        return state

    def save_agent_state(self, state: AgentState) -> None:
        """Save agent state."""
        state.save(self.sandbox.state_file)

    def get_checkpoint(self) -> Optional[Checkpoint]:
        """Load last checkpoint if exists."""
        return Checkpoint.load(self.sandbox.checkpoint_file)

    def save_checkpoint(self, checkpoint: Checkpoint) -> None:
        """Save checkpoint."""
        checkpoint.save(self.sandbox.checkpoint_file)

    def set_active_agent(self, agent_type: AgentType) -> None:
        """Set the active agent for this project."""
        self._config = self.config  # Ensure loaded
        self._config.active_agent = agent_type
        self._save_config()

    def clear_active_agent(self) -> None:
        """Clear active agent (when stopping)."""
        self._config = self.config
        self._config.active_agent = None
        self._save_config()

    def __repr__(self) -> str:
        return f"Project(name={self.name}, root={self.root})"


class ProjectManager:
    """
    Manages all projects.
    """

    def __init__(self, projects_dir: Path):
        """
        Initialize project manager.

        Args:
            projects_dir: Root directory containing all projects
        """
        self.projects_dir = projects_dir.resolve()
        self.projects_dir.mkdir(parents=True, exist_ok=True)

    def list_projects(self) -> list[Project]:
        """List all projects."""
        projects = []
        for path in self.projects_dir.iterdir():
            if path.is_dir() and (path / ".nullabot").exists():
                projects.append(Project(path))
        return sorted(projects, key=lambda p: p.name)

    def get_project(self, name: str) -> Optional[Project]:
        """Get project by name."""
        project_path = self.projects_dir / name
        if project_path.exists() and (project_path / ".nullabot").exists():
            return Project(project_path)
        return None

    def create_project(self, name: str, description: str = "") -> Project:
        """Create new project."""
        return Project.create(self.projects_dir, name, description)

    def delete_project(self, name: str) -> bool:
        """
        Delete a project.

        Warning: This deletes all project files!
        """
        import shutil

        project_path = self.projects_dir / name
        if project_path.exists():
            shutil.rmtree(project_path)
            return True
        return False

    def get_running_projects(self) -> list[Project]:
        """Get all projects with running agents."""
        running = []
        for project in self.list_projects():
            state = AgentState.load(project.sandbox.state_file)
            if state and state.status == AgentStatus.RUNNING:
                running.append(project)
        return running
