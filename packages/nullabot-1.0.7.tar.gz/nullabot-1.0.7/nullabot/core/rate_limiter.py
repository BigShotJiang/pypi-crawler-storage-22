"""
Rate Limiter - Don't burn API credits.

Handles Claude Code subscription limits:
- 5-hour rolling window
- Weekly limits
- Automatic wait when limit reached

For $200/month Max plan:
- 240-480 hours of Sonnet 4 per week
- 24-40 hours of Opus 4 per week
"""

import asyncio
import json
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Callable

from pydantic import BaseModel, Field


class FiveHourWindow(BaseModel):
    """Track the 5-hour rolling window for Claude Code."""

    window_start: Optional[datetime] = None
    requests_in_window: int = 0
    tokens_in_window: int = 0
    is_limit_reached: bool = False
    limit_reached_at: Optional[datetime] = None
    estimated_reset_at: Optional[datetime] = None

    def start_window(self) -> None:
        """Start a new 5-hour window."""
        self.window_start = datetime.now()
        self.requests_in_window = 0
        self.tokens_in_window = 0
        self.is_limit_reached = False
        self.limit_reached_at = None

    def check_window_expired(self) -> bool:
        """Check if current 5-hour window has expired."""
        if not self.window_start:
            return True
        elapsed = datetime.now() - self.window_start
        return elapsed.total_seconds() >= 5 * 3600  # 5 hours

    def record_request(self, tokens: int = 0) -> None:
        """Record a request in current window."""
        if self.check_window_expired():
            self.start_window()
        self.requests_in_window += 1
        self.tokens_in_window += tokens

    def mark_limit_reached(self) -> datetime:
        """Mark that limit was reached, return estimated reset time."""
        self.is_limit_reached = True
        self.limit_reached_at = datetime.now()
        # Reset happens 5 hours after window start
        if self.window_start:
            self.estimated_reset_at = self.window_start + timedelta(hours=5)
        else:
            # Fallback: 5 hours from now
            self.estimated_reset_at = datetime.now() + timedelta(hours=5)
        return self.estimated_reset_at

    def get_wait_time(self) -> float:
        """Get seconds to wait until window resets."""
        if not self.is_limit_reached:
            return 0.0
        if not self.estimated_reset_at:
            return 300.0  # 5 min fallback

        wait = (self.estimated_reset_at - datetime.now()).total_seconds()
        return max(0.0, wait)


class WeeklyUsage(BaseModel):
    """Track weekly usage limits."""

    week_start: Optional[datetime] = None
    total_hours_used: float = 0.0
    sonnet_hours: float = 0.0
    opus_hours: float = 0.0

    # Limits for $200 Max plan (conservative estimates)
    max_sonnet_hours: float = 240.0  # 240-480, use lower bound
    max_opus_hours: float = 24.0     # 24-40, use lower bound

    def check_week_reset(self) -> None:
        """Reset if new week."""
        now = datetime.now()
        if not self.week_start:
            # Start of current week (Monday)
            self.week_start = now - timedelta(days=now.weekday())
            self.week_start = self.week_start.replace(hour=0, minute=0, second=0, microsecond=0)
            return

        # Check if it's been a week
        if (now - self.week_start).days >= 7:
            self.week_start = now - timedelta(days=now.weekday())
            self.week_start = self.week_start.replace(hour=0, minute=0, second=0, microsecond=0)
            self.total_hours_used = 0.0
            self.sonnet_hours = 0.0
            self.opus_hours = 0.0

    def record_usage(self, seconds: float, model: str = "opus") -> None:
        """Record usage time."""
        self.check_week_reset()
        hours = seconds / 3600.0
        self.total_hours_used += hours

        if "opus" in model.lower():
            self.opus_hours += hours
        else:
            self.sonnet_hours += hours

    def is_limit_reached(self, model: str = "opus") -> bool:
        """Check if weekly limit reached."""
        self.check_week_reset()
        if "opus" in model.lower():
            return self.opus_hours >= self.max_opus_hours
        return self.sonnet_hours >= self.max_sonnet_hours

    def get_remaining_hours(self, model: str = "opus") -> float:
        """Get remaining hours for the week."""
        self.check_week_reset()
        if "opus" in model.lower():
            return max(0, self.max_opus_hours - self.opus_hours)
        return max(0, self.max_sonnet_hours - self.sonnet_hours)


class RateLimitStats(BaseModel):
    """Statistics for rate limiting."""

    total_requests: int = 0
    total_tokens_used: int = 0
    total_wait_time_seconds: float = 0.0
    five_hour_limit_hits: int = 0
    weekly_limit_hits: int = 0
    last_request_time: Optional[datetime] = None
    session_start: Optional[datetime] = None


class ClaudeCodeRateLimiter:
    """
    Rate limiter specifically for Claude Code subscriptions.

    Handles:
    - 5-hour rolling window limits
    - Weekly usage limits
    - Automatic detection and waiting for limit reset
    - Graceful backoff on errors
    """

    # Error patterns that indicate rate limit
    LIMIT_PATTERNS = [
        r"5.?hour.*limit",
        r"limit.*reached",
        r"usage.*limit",
        r"rate.*limit",
        r"too.*many.*requests",
        r"quota.*exceeded",
        r"try.*again.*later",
        r"429",
        r"overloaded",
        r"capacity",
        r"exceeded.*quota",
        r"usage.*cap",
        r"rolling.*window",
        r"subscription.*limit",
        r"daily.*limit",
        r"hourly.*limit",
        r"wait.*before",
        r"cool.*down",
        r"throttl",
    ]

    def __init__(
        self,
        plan: str = "max_200",  # "pro", "max_100", "max_200"
        on_limit_reached: Optional[Callable[[str, float], None]] = None,
        auto_wait: bool = True,
    ):
        """
        Initialize rate limiter.

        Args:
            plan: Subscription plan ("pro", "max_100", "max_200")
            on_limit_reached: Callback when limit hit (reason, wait_seconds)
            auto_wait: Automatically wait when limit reached
        """
        self.plan = plan
        self.on_limit_reached = on_limit_reached
        self.auto_wait = auto_wait

        # 5-hour window tracking
        self.five_hour = FiveHourWindow()

        # Weekly tracking
        self.weekly = WeeklyUsage()
        self._configure_plan_limits()

        # Stats
        self.stats = RateLimitStats(session_start=datetime.now())

        # Backoff
        self.backoff_multiplier = 1.0
        self.consecutive_errors = 0

        # Lock for async safety
        self._lock = asyncio.Lock()

        # Cycle timing (for weekly hour calculation)
        self._cycle_start: Optional[datetime] = None

    def _configure_plan_limits(self) -> None:
        """Configure limits based on plan."""
        if self.plan == "pro":
            self.weekly.max_sonnet_hours = 40.0
            self.weekly.max_opus_hours = 0.0  # Pro doesn't get Opus
        elif self.plan == "max_100":
            self.weekly.max_sonnet_hours = 140.0
            self.weekly.max_opus_hours = 15.0
        else:  # max_200
            self.weekly.max_sonnet_hours = 240.0
            self.weekly.max_opus_hours = 24.0

    def is_limit_error(self, error_message: str) -> bool:
        """Check if error message indicates rate limit."""
        error_lower = error_message.lower()
        for pattern in self.LIMIT_PATTERNS:
            if re.search(pattern, error_lower):
                return True
        return False

    def parse_wait_time_from_error(self, error_message: str) -> Optional[float]:
        """Try to parse wait time from error message."""
        # Look for patterns like "try again in X minutes/hours"
        patterns = [
            r"(\d+)\s*hour",
            r"(\d+)\s*minute",
            r"(\d+)\s*second",
        ]
        multipliers = [3600, 60, 1]

        for pattern, mult in zip(patterns, multipliers):
            match = re.search(pattern, error_message.lower())
            if match:
                return int(match.group(1)) * mult

        return None

    async def acquire(
        self,
        model: str = "opus",
        estimated_tokens: int = 4000,
    ) -> tuple[bool, str, float]:
        """
        Acquire permission to make a request.

        Args:
            model: Model being used ("sonnet" or "opus")
            estimated_tokens: Estimated tokens for request

        Returns:
            Tuple of (can_proceed, status_message, wait_time)
        """
        async with self._lock:
            # Check weekly limit
            if self.weekly.is_limit_reached(model):
                remaining = self.weekly.get_remaining_hours(model)
                msg = f"Weekly {model} limit reached. {remaining:.1f}h remaining."
                self.stats.weekly_limit_hits += 1

                if self.on_limit_reached:
                    # Wait until next week
                    wait = 7 * 24 * 3600  # Simplified
                    self.on_limit_reached("weekly_limit", wait)

                return False, msg, 0.0

            # Check 5-hour window
            if self.five_hour.is_limit_reached:
                wait_time = self.five_hour.get_wait_time()

                if wait_time > 0:
                    msg = f"5-hour limit reached. Resets in {wait_time/60:.0f} minutes."

                    if self.auto_wait and wait_time <= 18000:  # Max 5 hours
                        # Wait with progress updates
                        await self._wait_with_countdown(wait_time, "5-hour limit")
                        self.five_hour.is_limit_reached = False
                        self.five_hour.start_window()
                    else:
                        if self.on_limit_reached:
                            self.on_limit_reached("five_hour_limit", wait_time)
                        return False, msg, wait_time
                else:
                    # Window has reset
                    self.five_hour.is_limit_reached = False
                    self.five_hour.start_window()

            # Apply backoff if we've had errors
            if self.backoff_multiplier > 1.0:
                backoff_wait = (self.backoff_multiplier - 1) * 10  # 10s base
                await asyncio.sleep(backoff_wait)

            # Record the request
            self.five_hour.record_request(estimated_tokens)
            self.stats.total_requests += 1
            self.stats.total_tokens_used += estimated_tokens
            self.stats.last_request_time = datetime.now()

            # Start cycle timer for weekly tracking
            self._cycle_start = datetime.now()

            return True, "ok", 0.0

    async def _wait_with_countdown(self, wait_seconds: float, reason: str) -> None:
        """Wait with periodic status updates."""
        from rich.console import Console
        console = Console()

        start = datetime.now()
        total_wait = wait_seconds

        while wait_seconds > 0:
            hours = int(wait_seconds // 3600)
            minutes = int((wait_seconds % 3600) // 60)
            seconds = int(wait_seconds % 60)

            console.print(
                f"\r[yellow]{reason}: waiting {hours:02d}:{minutes:02d}:{seconds:02d}[/yellow]",
                end=""
            )

            # Sleep in chunks to allow interruption
            sleep_time = min(60, wait_seconds)
            await asyncio.sleep(sleep_time)
            wait_seconds -= sleep_time

        elapsed = (datetime.now() - start).total_seconds()
        self.stats.total_wait_time_seconds += elapsed
        console.print(f"\n[green]{reason}: wait complete, resuming...[/green]")

    def record_success(self, model: str = "opus") -> None:
        """Record successful API call."""
        self.consecutive_errors = 0
        self.backoff_multiplier = max(1.0, self.backoff_multiplier * 0.8)

        # Record time for weekly tracking
        if self._cycle_start:
            elapsed = (datetime.now() - self._cycle_start).total_seconds()
            self.weekly.record_usage(elapsed, model)
            self._cycle_start = None

    def record_error(self, error_message: str) -> tuple[bool, float]:
        """
        Record an API error.

        Returns:
            Tuple of (is_rate_limit, wait_time_seconds)
        """
        self.consecutive_errors += 1

        # Check if it's a rate limit error
        if self.is_limit_error(error_message):
            self.stats.five_hour_limit_hits += 1

            # Try to parse wait time
            parsed_wait = self.parse_wait_time_from_error(error_message)

            if parsed_wait:
                wait_time = parsed_wait
            else:
                # Default: assume 5-hour window needs to reset
                wait_time = self.five_hour.get_wait_time()
                if wait_time <= 0:
                    # Start fresh window tracking
                    self.five_hour.mark_limit_reached()
                    wait_time = self.five_hour.get_wait_time()

            self.five_hour.is_limit_reached = True

            if self.on_limit_reached:
                self.on_limit_reached("api_rate_limit", wait_time)

            return True, wait_time

        # Regular error - increase backoff
        self.backoff_multiplier = min(8.0, self.backoff_multiplier * 1.5)
        return False, 0.0

    async def handle_limit_error(self, error_message: str) -> bool:
        """
        Handle a rate limit error with automatic waiting.

        Returns:
            True if waited and ready to retry, False if should stop
        """
        is_limit, wait_time = self.record_error(error_message)

        if not is_limit:
            return False

        if self.auto_wait and wait_time > 0:
            # Cap at 5 hours
            wait_time = min(wait_time, 5 * 3600)
            await self._wait_with_countdown(wait_time, "Rate limit")
            self.five_hour.is_limit_reached = False
            return True

        return False

    def get_status(self) -> dict:
        """Get current status."""
        return {
            "plan": self.plan,
            "five_hour": {
                "window_start": self.five_hour.window_start.isoformat() if self.five_hour.window_start else None,
                "requests": self.five_hour.requests_in_window,
                "is_limited": self.five_hour.is_limit_reached,
                "reset_in_minutes": self.five_hour.get_wait_time() / 60 if self.five_hour.is_limit_reached else 0,
            },
            "weekly": {
                "sonnet_hours_used": round(self.weekly.sonnet_hours, 2),
                "sonnet_hours_remaining": round(self.weekly.get_remaining_hours("sonnet"), 2),
                "opus_hours_used": round(self.weekly.opus_hours, 2),
                "opus_hours_remaining": round(self.weekly.get_remaining_hours("opus"), 2),
            },
            "stats": {
                "total_requests": self.stats.total_requests,
                "total_wait_seconds": round(self.stats.total_wait_time_seconds, 0),
                "limit_hits": self.stats.five_hour_limit_hits,
            },
        }

    def save(self, path: Path) -> None:
        """Save state to disk."""
        state = {
            "plan": self.plan,
            "five_hour": self.five_hour.model_dump(),
            "weekly": self.weekly.model_dump(),
            "stats": self.stats.model_dump(),
            "backoff_multiplier": self.backoff_multiplier,
            "saved_at": datetime.now().isoformat(),
        }
        path.write_text(json.dumps(state, indent=2, default=str), encoding="utf-8")

    @classmethod
    def load(cls, path: Path, **kwargs) -> Optional["ClaudeCodeRateLimiter"]:
        """Load state from disk."""
        if not path.exists():
            return None

        try:
            data = json.loads(path.read_text(encoding="utf-8"))

            limiter = cls(plan=data.get("plan", "max_200"), **kwargs)

            # Restore 5-hour window
            if "five_hour" in data:
                limiter.five_hour = FiveHourWindow.model_validate(data["five_hour"])

            # Restore weekly
            if "weekly" in data:
                limiter.weekly = WeeklyUsage.model_validate(data["weekly"])

            # Restore stats
            if "stats" in data:
                limiter.stats = RateLimitStats.model_validate(data["stats"])

            limiter.backoff_multiplier = data.get("backoff_multiplier", 1.0)

            return limiter
        except Exception:
            return None


# Alias for backward compatibility
RateLimiter = ClaudeCodeRateLimiter
AdaptiveRateLimiter = ClaudeCodeRateLimiter
