"""
Sandbox - Secure folder isolation for projects.

Each project can ONLY access its own folder. No escape allowed.
"""

import os
from pathlib import Path
from typing import Optional


class SandboxViolation(Exception):
    """Raised when agent tries to access outside its sandbox."""

    pass


class Sandbox:
    """
    Enforces folder isolation for a project.

    All file operations must go through this class to ensure
    the agent cannot access files outside its designated folder.
    """

    def __init__(self, project_root: Path):
        """
        Initialize sandbox with project root folder.

        Args:
            project_root: Absolute path to project folder
        """
        self.root = project_root.resolve()
        self.workspace = self.root / "workspace"
        self._aurora_dir = self.root / ".nullabot"

        # Ensure directories exist
        self.workspace.mkdir(parents=True, exist_ok=True)
        self._aurora_dir.mkdir(parents=True, exist_ok=True)

    def validate_path(self, path: str | Path) -> Path:
        """
        Validate and resolve a path, ensuring it's within sandbox.

        Args:
            path: Relative or absolute path to validate

        Returns:
            Resolved absolute path within sandbox

        Raises:
            SandboxViolation: If path escapes sandbox
        """
        # Convert to Path object
        path = Path(path)

        # If relative, resolve from workspace
        if not path.is_absolute():
            resolved = (self.workspace / path).resolve()
        else:
            resolved = path.resolve()

        # Check if within sandbox (workspace or .nullabot)
        try:
            resolved.relative_to(self.root)
        except ValueError:
            raise SandboxViolation(
                f"Access denied: '{path}' is outside project sandbox.\n"
                f"Allowed: {self.root}"
            )

        return resolved

    def read_file(self, path: str | Path) -> str:
        """Safely read a file within sandbox."""
        safe_path = self.validate_path(path)
        if not safe_path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        if not safe_path.is_file():
            raise IsADirectoryError(f"Not a file: {path}")
        return safe_path.read_text(encoding="utf-8")

    def write_file(self, path: str | Path, content: str) -> Path:
        """Safely write a file within sandbox."""
        safe_path = self.validate_path(path)
        safe_path.parent.mkdir(parents=True, exist_ok=True)
        safe_path.write_text(content, encoding="utf-8")
        return safe_path

    def list_dir(self, path: str | Path = ".") -> list[Path]:
        """Safely list directory contents within sandbox."""
        safe_path = self.validate_path(path)
        if not safe_path.is_dir():
            raise NotADirectoryError(f"Not a directory: {path}")
        return list(safe_path.iterdir())

    def exists(self, path: str | Path) -> bool:
        """Check if path exists within sandbox."""
        try:
            safe_path = self.validate_path(path)
            return safe_path.exists()
        except SandboxViolation:
            return False

    def mkdir(self, path: str | Path) -> Path:
        """Safely create directory within sandbox."""
        safe_path = self.validate_path(path)
        safe_path.mkdir(parents=True, exist_ok=True)
        return safe_path

    def delete_file(self, path: str | Path) -> None:
        """Safely delete a file within sandbox."""
        safe_path = self.validate_path(path)
        if safe_path.is_file():
            safe_path.unlink()
        elif safe_path.is_dir():
            raise IsADirectoryError(f"Cannot delete directory with delete_file: {path}")

    def get_relative_path(self, path: str | Path) -> Path:
        """Get path relative to workspace."""
        safe_path = self.validate_path(path)
        try:
            return safe_path.relative_to(self.workspace)
        except ValueError:
            return safe_path.relative_to(self.root)

    @property
    def state_file(self) -> Path:
        """Path to agent state file."""
        return self._aurora_dir / "state.json"

    @property
    def checkpoint_file(self) -> Path:
        """Path to checkpoint file."""
        return self._aurora_dir / "checkpoint.json"

    @property
    def history_file(self) -> Path:
        """Path to conversation history file."""
        return self._aurora_dir / "history.jsonl"

    def __repr__(self) -> str:
        return f"Sandbox(root={self.root})"
