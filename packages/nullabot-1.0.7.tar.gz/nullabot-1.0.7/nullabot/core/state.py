"""
State Management - Never lose progress.

Handles checkpointing, state persistence, and crash recovery.
"""

import json
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from pydantic import BaseModel, Field


class AgentType(str, Enum):
    """Types of agents available."""

    THINKER = "thinker"
    DESIGNER = "designer"
    CODER = "coder"


class AgentStatus(str, Enum):
    """Current status of an agent."""

    IDLE = "idle"  # Not running
    RUNNING = "running"  # Actively working
    PAUSED = "paused"  # User requested pause
    BLOCKED = "blocked"  # Needs user input
    ERROR = "error"  # Encountered error


class Message(BaseModel):
    """A single message in conversation history."""

    role: str  # "user", "assistant", "system"
    content: str
    timestamp: datetime = Field(default_factory=datetime.now)
    metadata: dict[str, Any] = Field(default_factory=dict)


class Checkpoint(BaseModel):
    """
    Checkpoint - saved state that survives crashes.

    Contains everything needed to resume work exactly where agent left off.
    """

    # Identity
    agent_type: AgentType
    project_name: str

    # Current task
    task: str  # What user asked for
    task_context: str = ""  # Additional context

    # Progress
    current_step: str = ""  # What agent is doing now
    completed_steps: list[str] = Field(default_factory=list)
    next_steps: list[str] = Field(default_factory=list)

    # Outputs created
    outputs: list[str] = Field(default_factory=list)  # File paths

    # Thinking (agent's internal notes)
    thoughts: str = ""
    learnings: list[str] = Field(default_factory=list)

    # Metadata
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)
    cycle_count: int = 0  # How many think cycles completed

    def save(self, path: Path) -> None:
        """Save checkpoint to file."""
        self.updated_at = datetime.now()
        path.write_text(self.model_dump_json(indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> Optional["Checkpoint"]:
        """Load checkpoint from file if exists."""
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return cls.model_validate(data)
        except Exception:
            return None


class AgentState(BaseModel):
    """
    Full agent state including runtime information.
    """

    # Core
    agent_type: AgentType
    status: AgentStatus = AgentStatus.IDLE
    project_name: str

    # Current checkpoint
    checkpoint: Optional[Checkpoint] = None

    # Conversation
    messages: list[Message] = Field(default_factory=list)

    # Runtime
    started_at: Optional[datetime] = None
    error_count: int = 0
    last_error: Optional[str] = None

    # User interaction
    pending_question: Optional[str] = None  # Question waiting for user
    pending_options: list[str] = Field(default_factory=list)

    # === Ralph-inspired reliability features ===

    # Circuit breaker state
    circuit_state: str = "closed"  # closed, open, half_open
    circuit_failure_count: int = 0
    circuit_last_failure: Optional[datetime] = None

    # Progress tracking
    cycles_without_progress: int = 0
    last_output_hash: Optional[str] = None
    completion_signals: int = 0
    total_cycles: int = 0

    # Rate limiting stats
    total_tokens_used: int = 0
    total_requests: int = 0
    rate_limited_waits: int = 0
    total_wait_time_seconds: float = 0.0

    # Exit detection
    exit_reason: Optional[str] = None
    explicit_exit_signal: bool = False

    def save(self, path: Path) -> None:
        """Save state to file."""
        path.write_text(self.model_dump_json(indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> Optional["AgentState"]:
        """Load state from file if exists."""
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return cls.model_validate(data)
        except Exception:
            return None

    def add_message(self, role: str, content: str, **metadata: Any) -> None:
        """Add message to history."""
        self.messages.append(Message(role=role, content=content, metadata=metadata))

    def start(self) -> None:
        """Mark agent as running."""
        self.status = AgentStatus.RUNNING
        self.started_at = datetime.now()
        self.error_count = 0

    def pause(self) -> None:
        """Mark agent as paused (user requested)."""
        self.status = AgentStatus.PAUSED

    def block(self, question: str, options: list[str] | None = None) -> None:
        """Mark agent as blocked, waiting for user input."""
        self.status = AgentStatus.BLOCKED
        self.pending_question = question
        self.pending_options = options or []

    def unblock(self, answer: str) -> None:
        """Resume after user provides input."""
        self.add_message("user", answer)
        self.status = AgentStatus.RUNNING
        self.pending_question = None
        self.pending_options = []

    def error(self, message: str) -> None:
        """Record an error."""
        self.error_count += 1
        self.last_error = message
        if self.error_count >= 3:
            self.status = AgentStatus.ERROR


class HistoryWriter:
    """Append-only history writer for crash safety."""

    def __init__(self, path: Path):
        self.path = path

    def append(self, message: Message) -> None:
        """Append message to history file."""
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(message.model_dump_json() + "\n")

    def load_all(self) -> list[Message]:
        """Load all messages from history."""
        if not self.path.exists():
            return []
        messages = []
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        messages.append(Message.model_validate_json(line))
                    except Exception:
                        continue
        return messages
