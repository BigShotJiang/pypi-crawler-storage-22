#!/bin/bash
#
# Nullabot 24/7 Runner Script
# Keeps your Mac awake and runs nullabot continuously
#
# Usage:
#   ./run_nullabot.sh bot              # Run Telegram bot mode
#   ./run_nullabot.sh think project    # Run thinker on project
#   ./run_nullabot.sh code project     # Run coder on project
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}╔═══════════════════════════════════════╗${NC}"
echo -e "${GREEN}║       Nullabot 24/7 Runner            ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════╝${NC}"

# Check if caffeinate is available (macOS)
if command -v caffeinate &> /dev/null; then
    KEEP_AWAKE="caffeinate -dims"
    echo -e "${GREEN}✓ Using caffeinate to prevent sleep${NC}"
else
    KEEP_AWAKE=""
    echo -e "${YELLOW}⚠ caffeinate not found - laptop may sleep${NC}"
fi

# Activate virtual environment
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
    echo -e "${GREEN}✓ Virtual environment activated${NC}"
else
    echo -e "${RED}✗ Virtual environment not found. Run: python -m venv venv && pip install -e .${NC}"
    exit 1
fi

# Check for Telegram bot token
if [ -z "$TELEGRAM_BOT_TOKEN" ]; then
    echo -e "${YELLOW}⚠ TELEGRAM_BOT_TOKEN not set (required for bot mode)${NC}"
fi

# Parse arguments
MODE="${1:-bot}"
PROJECT="${2:-}"
TASK="${3:-}"

echo -e "\n${YELLOW}Mode: $MODE${NC}"
if [ -n "$PROJECT" ]; then
    echo -e "${YELLOW}Project: $PROJECT${NC}"
fi

# Function to run nullabot with restart on crash
run_with_restart() {
    local cmd="$1"
    local max_restarts=10
    local restart_count=0
    local restart_delay=30

    while true; do
        echo -e "\n${GREEN}Starting nullabot...${NC}"

        # Run with caffeinate if available
        if [ -n "$KEEP_AWAKE" ]; then
            $KEEP_AWAKE $cmd
        else
            $cmd
        fi

        exit_code=$?

        if [ $exit_code -eq 0 ]; then
            echo -e "${GREEN}Nullabot exited normally${NC}"
            break
        fi

        restart_count=$((restart_count + 1))

        if [ $restart_count -ge $max_restarts ]; then
            echo -e "${RED}Max restarts ($max_restarts) reached. Stopping.${NC}"
            break
        fi

        echo -e "${YELLOW}Nullabot crashed (exit $exit_code). Restarting in ${restart_delay}s... (attempt $restart_count/$max_restarts)${NC}"
        sleep $restart_delay

        # Increase delay for repeated crashes
        restart_delay=$((restart_delay * 2))
        if [ $restart_delay -gt 300 ]; then
            restart_delay=300  # Cap at 5 minutes
        fi
    done
}

# Build and run command
case "$MODE" in
    bot)
        echo -e "\n${GREEN}Starting Telegram bot mode...${NC}"
        echo -e "${YELLOW}You can now control nullabot via Telegram${NC}"
        run_with_restart "nullabot bot"
        ;;
    think)
        if [ -z "$PROJECT" ]; then
            echo -e "${RED}Usage: ./run_nullabot.sh think <project> [task]${NC}"
            exit 1
        fi
        echo -e "\n${GREEN}Starting thinker agent...${NC}"
        run_with_restart "nullabot think $PROJECT \"$TASK\""
        ;;
    design)
        if [ -z "$PROJECT" ]; then
            echo -e "${RED}Usage: ./run_nullabot.sh design <project> [task]${NC}"
            exit 1
        fi
        echo -e "\n${GREEN}Starting designer agent...${NC}"
        run_with_restart "nullabot design $PROJECT \"$TASK\""
        ;;
    code)
        if [ -z "$PROJECT" ]; then
            echo -e "${RED}Usage: ./run_nullabot.sh code <project> [task]${NC}"
            exit 1
        fi
        echo -e "\n${GREEN}Starting coder agent...${NC}"
        run_with_restart "nullabot code $PROJECT \"$TASK\""
        ;;
    *)
        echo -e "${RED}Unknown mode: $MODE${NC}"
        echo -e "Usage: ./run_nullabot.sh [bot|think|design|code] [project] [task]"
        exit 1
        ;;
esac

echo -e "\n${GREEN}Nullabot session ended${NC}"
