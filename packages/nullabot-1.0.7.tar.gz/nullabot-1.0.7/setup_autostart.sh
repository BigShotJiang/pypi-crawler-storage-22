#!/bin/bash
#
# Setup Nullabot to run automatically on Mac startup
#
# This creates a LaunchAgent that:
# - Starts nullabot when you log in
# - Keeps it running (restarts on crash)
# - Prevents Mac from sleeping while running
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLIST_NAME="com.nullabot.agent.plist"
PLIST_PATH="$HOME/Library/LaunchAgents/$PLIST_NAME"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}╔═══════════════════════════════════════╗${NC}"
echo -e "${GREEN}║    Nullabot Auto-Start Setup          ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════╝${NC}"

# Check for required environment variables
if [ -z "$ANTHROPIC_API_KEY" ]; then
    echo -e "${RED}✗ ANTHROPIC_API_KEY not set${NC}"
    echo -e "Please set it first: export ANTHROPIC_API_KEY=your-key"
    read -p "Enter your ANTHROPIC_API_KEY: " ANTHROPIC_API_KEY
fi

if [ -z "$TELEGRAM_BOT_TOKEN" ]; then
    echo -e "${YELLOW}⚠ TELEGRAM_BOT_TOKEN not set (optional for bot mode)${NC}"
    read -p "Enter your TELEGRAM_BOT_TOKEN (or press Enter to skip): " TELEGRAM_BOT_TOKEN
fi

# Create LaunchAgents directory if needed
mkdir -p "$HOME/Library/LaunchAgents"

# Create the plist file
cat > "$PLIST_PATH" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.nullabot.agent</string>

    <key>WorkingDirectory</key>
    <string>$SCRIPT_DIR</string>

    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>-c</string>
        <string>source venv/bin/activate && caffeinate -dims nullabot bot</string>
    </array>

    <key>EnvironmentVariables</key>
    <dict>
        <key>ANTHROPIC_API_KEY</key>
        <string>$ANTHROPIC_API_KEY</string>
EOF

if [ -n "$TELEGRAM_BOT_TOKEN" ]; then
cat >> "$PLIST_PATH" << EOF
        <key>TELEGRAM_BOT_TOKEN</key>
        <string>$TELEGRAM_BOT_TOKEN</string>
EOF
fi

cat >> "$PLIST_PATH" << EOF
        <key>PATH</key>
        <string>/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
    </dict>

    <key>KeepAlive</key>
    <dict>
        <key>SuccessfulExit</key>
        <false/>
        <key>Crashed</key>
        <true/>
    </dict>

    <key>RunAtLoad</key>
    <true/>

    <key>StandardOutPath</key>
    <string>$SCRIPT_DIR/nullabot.log</string>

    <key>StandardErrorPath</key>
    <string>$SCRIPT_DIR/nullabot.error.log</string>

    <key>ThrottleInterval</key>
    <integer>30</integer>
</dict>
</plist>
EOF

echo -e "${GREEN}✓ Created $PLIST_PATH${NC}"

# Unload if already loaded
launchctl unload "$PLIST_PATH" 2>/dev/null || true

# Load the agent
launchctl load "$PLIST_PATH"
echo -e "${GREEN}✓ LaunchAgent loaded${NC}"

# Prevent sleep settings
echo -e "\n${YELLOW}Configuring sleep prevention...${NC}"

# Check if we can modify power settings
if command -v pmset &> /dev/null; then
    echo -e "${YELLOW}To prevent sleep when lid is closed, run:${NC}"
    echo -e "  sudo pmset -b disablesleep 1  # Disable sleep on battery"
    echo -e "  sudo pmset -c disablesleep 1  # Disable sleep when charging"
    echo -e "\n${YELLOW}To re-enable sleep later:${NC}"
    echo -e "  sudo pmset -b disablesleep 0"
    echo -e "  sudo pmset -c disablesleep 0"
fi

echo -e "\n${GREEN}═══════════════════════════════════════${NC}"
echo -e "${GREEN}Setup complete!${NC}"
echo -e "${GREEN}═══════════════════════════════════════${NC}"
echo -e "\nNullabot will now:"
echo -e "  • Start automatically when you log in"
echo -e "  • Restart if it crashes"
echo -e "  • Keep your Mac awake while running"
echo -e "\n${YELLOW}Commands:${NC}"
echo -e "  View logs:    tail -f $SCRIPT_DIR/nullabot.log"
echo -e "  Stop nullabot:   launchctl unload $PLIST_PATH"
echo -e "  Start nullabot:  launchctl load $PLIST_PATH"
echo -e "  Check status: launchctl list | grep nullabot"
