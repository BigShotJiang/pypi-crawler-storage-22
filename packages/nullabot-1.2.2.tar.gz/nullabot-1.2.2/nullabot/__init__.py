"""Nullabot - 24/7 AI Workforce"""

__version__ = "1.2.0"
