"""
Modal API Client - GLM-5 model integration for Nullabot.

Uses Modal's hosted GLM-5 API instead of Claude Code CLI.
This allows Nullabot to use an alternative AI model.
"""

import asyncio
import json
import os
from pathlib import Path
from typing import Any, Optional, AsyncIterator
from dataclasses import dataclass, field

import httpx


@dataclass
class StreamEvent:
    """A single event from the streaming response."""

    event_type: str  # assistant, tool_use, tool_result, result, error
    content: str  # text content
    session_id: Optional[str] = None
    data: dict = field(default_factory=dict)


@dataclass
class ModalResponse:
    """Response from Modal GLM-5 API."""

    content: str
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    cost_usd: float = 0.0
    duration_ms: int = 0
    model: str = ""


class ModalClient:
    """
    Client for Modal-hosted GLM-5 model API.

    This is an alternative to Claude Code CLI that uses
    Modal's hosted GLM-5 endpoint instead.
    """

    DEFAULT_API_URL = "https://api.us-west-2.modal.direct/v1/chat/completions"
    DEFAULT_MODEL = "zai-org/GLM-5-FP8"

    def __init__(
        self,
        working_dir: Optional[Path] = None,
        api_key: Optional[str] = None,
        api_url: Optional[str] = None,
        model: Optional[str] = None,
        max_tokens: int = 32000,
        temperature: float = 0.7,
    ):
        """
        Initialize Modal API client.

        Args:
            working_dir: Directory context (for compatibility with ClaudeCodeClient)
            api_key: Modal API token (defaults to MODAL_TOKEN env var)
            api_url: API endpoint URL
            model: Model identifier (defaults to GLM-5)
            max_tokens: Maximum tokens in response
            temperature: Sampling temperature
        """
        self.working_dir = working_dir or Path.cwd()
        self.api_key = api_key or os.environ.get("MODAL_TOKEN")
        self.api_url = api_url or self.DEFAULT_API_URL
        self.model = model or self.DEFAULT_MODEL
        self.max_tokens = max_tokens
        self.temperature = temperature

        if not self.api_key:
            raise RuntimeError(
                "Modal API key required. Set MODAL_TOKEN env var or pass api_key."
            )

    def _build_headers(self) -> dict[str, str]:
        """Build API request headers."""
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

    def _build_payload(
        self,
        messages: list[dict[str, str]],
        stream: bool = False,
    ) -> dict[str, Any]:
        """Build API request payload."""
        return {
            "model": self.model,
            "messages": messages,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "stream": stream,
        }

    def chat(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        allowed_tools: Optional[list[str]] = None,
        timeout: int = 300,
    ) -> ModalResponse:
        """
        Send a prompt to Modal GLM-5 API (synchronous).

        Args:
            prompt: The prompt to send
            system_prompt: Optional system prompt
            allowed_tools: Ignored (for compatibility with ClaudeCodeClient)
            timeout: Timeout in seconds

        Returns:
            ModalResponse with content and metadata
        """
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        payload = self._build_payload(messages, stream=False)

        try:
            with httpx.Client(timeout=timeout) as client:
                response = client.post(
                    self.api_url,
                    headers=self._build_headers(),
                    json=payload,
                )
                response.raise_for_status()
                data = response.json()

                # Extract content from response
                content = ""
                if "choices" in data and len(data["choices"]) > 0:
                    choice = data["choices"][0]
                    if "message" in choice:
                        content = choice["message"].get("content", "")
                    elif "text" in choice:
                        content = choice["text"]

                # Get usage info if available
                usage = data.get("usage", {})
                prompt_tokens = usage.get("prompt_tokens", 0)
                completion_tokens = usage.get("completion_tokens", 0)

                # Rough cost estimate (GLM-5 pricing may vary)
                # This is a placeholder - update with actual pricing
                cost_usd = (prompt_tokens + completion_tokens) * 0.000002

                return ModalResponse(
                    content=content,
                    cost_usd=cost_usd,
                    model=data.get("model", self.model),
                )

        except httpx.TimeoutException:
            return ModalResponse(content="Error: Request timed out")
        except httpx.HTTPStatusError as e:
            return ModalResponse(content=f"Error: HTTP {e.response.status_code} - {e.response.text[:200]}")
        except Exception as e:
            return ModalResponse(content=f"Error: {str(e)}")

    async def chat_async(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        allowed_tools: Optional[list[str]] = None,
        timeout: int = 300,
    ) -> ModalResponse:
        """Async version of chat."""
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        payload = self._build_payload(messages, stream=False)

        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                response = await client.post(
                    self.api_url,
                    headers=self._build_headers(),
                    json=payload,
                )
                response.raise_for_status()
                data = response.json()

                # Extract content from response
                content = ""
                if "choices" in data and len(data["choices"]) > 0:
                    choice = data["choices"][0]
                    if "message" in choice:
                        content = choice["message"].get("content", "")
                    elif "text" in choice:
                        content = choice["text"]

                # Get usage info if available
                usage = data.get("usage", {})
                prompt_tokens = usage.get("prompt_tokens", 0)
                completion_tokens = usage.get("completion_tokens", 0)

                # Rough cost estimate
                cost_usd = (prompt_tokens + completion_tokens) * 0.000002

                return ModalResponse(
                    content=content,
                    cost_usd=cost_usd,
                    model=data.get("model", self.model),
                )

        except httpx.TimeoutException:
            return ModalResponse(content="Error: Request timed out")
        except httpx.HTTPStatusError as e:
            return ModalResponse(content=f"Error: HTTP {e.response.status_code} - {e.response.text[:200]}")
        except Exception as e:
            return ModalResponse(content=f"Error: {str(e)}")

    async def stream_chat(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        timeout: int = 300,
    ) -> AsyncIterator[StreamEvent]:
        """
        Stream a chat response from Modal API.

        Yields StreamEvent objects for real-time updates.
        """
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        payload = self._build_payload(messages, stream=True)

        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                async with client.stream(
                    "POST",
                    self.api_url,
                    headers=self._build_headers(),
                    json=payload,
                ) as response:
                    response.raise_for_status()

                    full_content = []
                    async for line in response.aiter_lines():
                        line = line.strip()
                        if not line:
                            continue
                        if line.startswith("data: "):
                            line = line[6:]  # Remove "data: " prefix

                        if line == "[DONE]":
                            break

                        try:
                            data = json.loads(line)
                            if "choices" in data and len(data["choices"]) > 0:
                                choice = data["choices"][0]
                                delta = choice.get("delta", {})
                                content_chunk = delta.get("content", "")
                                if content_chunk:
                                    full_content.append(content_chunk)
                                    yield StreamEvent(
                                        event_type="assistant",
                                        content=content_chunk,
                                    )
                        except json.JSONDecodeError:
                            continue

                    # Final result
                    final_content = "".join(full_content)
                    yield StreamEvent(
                        event_type="result",
                        content=final_content,
                    )

        except httpx.TimeoutException:
            yield StreamEvent(event_type="error", content="Request timed out")
        except httpx.HTTPStatusError as e:
            error_text = await e.response.aread()
            yield StreamEvent(
                event_type="error",
                content=f"HTTP {e.response.status_code}: {error_text[:200]}"
            )
        except Exception as e:
            yield StreamEvent(event_type="error", content=str(e))


class ModalAgent:
    """
    Simplified agent interface for Modal GLM-5 (similar to ClaudeCodeAgent).

    Provides a compatible interface for the Telegram bot to use
    either Claude or Modal interchangeably.
    """

    def __init__(
        self,
        workspace: Path,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
    ):
        self.workspace = workspace.resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)

        self.client = ModalClient(
            working_dir=self.workspace,
            api_key=api_key,
            model=model,
        )

        # State file for persistence
        self.state_file = self.workspace / ".nullabot_state.json"

    def _load_state(self) -> dict:
        """Load agent state."""
        if self.state_file.exists():
            return json.loads(self.state_file.read_text())
        return {"history": [], "checkpoint": None}

    def _save_state(self, state: dict) -> None:
        """Save agent state."""
        self.state_file.write_text(json.dumps(state, indent=2, default=str))

    async def run(
        self,
        task: str,
        system_prompt: Optional[str] = None,
        on_output: Optional[callable] = None,
    ) -> str:
        """
        Run a task using Modal GLM-5.

        Args:
            task: What to do
            system_prompt: Custom system prompt
            on_output: Callback for streaming output

        Returns:
            Final response content
        """
        state = self._load_state()

        # Build context from history
        context = ""
        if state.get("checkpoint"):
            context = f"\n\nPrevious progress:\n{state['checkpoint']}\n\nContinue from where you left off.\n"

        full_task = f"{task}{context}"

        # Run Modal API
        response = await self.client.chat_async(
            prompt=full_task,
            system_prompt=system_prompt,
        )

        # Update state
        state["history"].append({
            "task": task,
            "response": response.content[:500],  # Truncate for storage
        })
        state["checkpoint"] = response.content[:1000]
        self._save_state(state)

        if on_output:
            on_output(response.content)

        return response.content
