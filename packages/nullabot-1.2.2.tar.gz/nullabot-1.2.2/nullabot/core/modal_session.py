"""
Modal Session - Streaming Modal API session for Nullabot work mode.

Used by work mode to interact with Modal-hosted GLM-5 model,
providing a similar interface to WorkSession for Claude Code.
"""

import asyncio
import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import AsyncIterator, Optional

import httpx


@dataclass
class StreamEvent:
    """A single event from the Modal API stream."""

    event_type: str  # assistant, result, error
    content: str  # text content
    session_id: Optional[str] = None
    data: dict = field(default_factory=dict)


class ModalSession:
    """
    Manages a streaming Modal API session.

    Provides a similar interface to WorkSession but uses Modal's
    GLM-5 API instead of Claude Code CLI.
    """

    DEFAULT_API_URL = "https://api.us-west-2.modal.direct/v1/chat/completions"
    DEFAULT_MODEL = "zai-org/GLM-5-FP8"

    def __init__(
        self,
        workspace: Path,
        api_key: Optional[str] = None,
        api_url: Optional[str] = None,
        model: Optional[str] = None,
        max_tokens: int = 32000,
        temperature: float = 0.7,
        allowed_paths: Optional[list[str]] = None,
    ):
        """
        Initialize Modal API session.

        Args:
            workspace: Working directory for context
            api_key: Modal API token (defaults to MODAL_TOKEN env var)
            api_url: API endpoint URL
            model: Model identifier
            max_tokens: Maximum tokens in response
            temperature: Sampling temperature
            allowed_paths: List of allowed paths (for compatibility)
        """
        self.workspace = Path(workspace).resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)

        self.api_key = api_key or os.environ.get("MODAL_TOKEN")
        self.api_url = api_url or self.DEFAULT_API_URL
        self.model = model or self.DEFAULT_MODEL
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.allowed_paths = allowed_paths or []

        # Session state
        self.session_id: Optional[str] = None
        self.prompt_count: int = 0
        self.conversation_history: list[dict] = []
        self._busy = False

        if not self.api_key:
            raise RuntimeError(
                "Modal API key required. Set MODAL_TOKEN env var or pass api_key."
            )

    @property
    def is_busy(self) -> bool:
        return self._busy

    def _build_headers(self) -> dict[str, str]:
        """Build API request headers."""
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

    def _build_payload(
        self,
        messages: list[dict],
        stream: bool = False,
    ) -> dict:
        """Build API request payload."""
        return {
            "model": self.model,
            "messages": messages,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "stream": stream,
        }

    async def send(self, prompt: str) -> AsyncIterator[StreamEvent]:
        """
        Send a prompt to Modal API and yield streaming events.

        This maintains conversation history for context.
        """
        if self._busy:
            yield StreamEvent(
                event_type="error",
                content="Session is busy. Wait for the current prompt to finish.",
            )
            return

        self._busy = True
        self.prompt_count += 1

        # Add user message to history
        self.conversation_history.append({"role": "user", "content": prompt})

        # Keep only last 20 messages to stay within context limits
        messages = self.conversation_history[-20:]

        # Add system message at the beginning if not present
        if not any(m.get("role") == "system" for m in messages):
            system_msg = (
                "You are Nullabot, a helpful AI assistant. "
                "You can help with coding, analysis, and general tasks. "
                f"Current working directory: {self.workspace}"
            )
            messages = [{"role": "system", "content": system_msg}] + messages

        payload = self._build_payload(messages, stream=True)

        try:
            full_content = []
            buffer = ""

            async with httpx.AsyncClient(timeout=600) as client:
                async with client.stream(
                    "POST",
                    self.api_url,
                    headers=self._build_headers(),
                    json=payload,
                ) as response:
                    response.raise_for_status()

                    async for line in response.aiter_lines():
                        line = line.strip()
                        if not line:
                            continue
                        if line.startswith("data: "):
                            line = line[6:]  # Remove "data: " prefix

                        if line == "[DONE]":
                            break

                        try:
                            data = json.loads(line)
                            if "choices" in data and len(data["choices"]) > 0:
                                choice = data["choices"][0]
                                delta = choice.get("delta", {})
                                content_chunk = delta.get("content", "")

                                if content_chunk:
                                    full_content.append(content_chunk)
                                    buffer += content_chunk

                                    # Yield every ~50 chars or on punctuation
                                    if len(buffer) >= 50 or any(c in buffer for c in ".!?\n"):
                                        yield StreamEvent(
                                            event_type="assistant",
                                            content=buffer,
                                        )
                                        buffer = ""

                        except json.JSONDecodeError:
                            continue

                    # Yield any remaining buffer
                    if buffer:
                        yield StreamEvent(
                            event_type="assistant",
                            content=buffer,
                        )

                    # Final result
                    final_content = "".join(full_content)

                    # Add assistant response to history
                    self.conversation_history.append({
                        "role": "assistant",
                        "content": final_content,
                    })

                    yield StreamEvent(
                        event_type="result",
                        content=final_content,
                    )

        except httpx.TimeoutException:
            yield StreamEvent(event_type="error", content="Request timed out")
        except httpx.HTTPStatusError as e:
            try:
                error_text = await e.response.aread()
            except (ValueError, OSError, httpx.StreamError):
                error_text = "<stream closed>"
            yield StreamEvent(
                event_type="error",
                content=f"HTTP {e.response.status_code}: {error_text[:500]}"
            )
        except (ValueError, OSError, httpx.StreamError) as e:
            # Stream closed errors during HTTP streaming
            if "stream" in str(e).lower() or "closed" in str(e).lower():
                yield StreamEvent(
                    event_type="error",
                    content="Connection was interrupted. Please try again.",
                )
            else:
                yield StreamEvent(event_type="error", content=str(e))
        except Exception as e:
            yield StreamEvent(event_type="error", content=str(e))
        finally:
            self._busy = False

    def new_session(self) -> None:
        """Clear conversation history to start fresh."""
        self.conversation_history = []
        self.prompt_count = 0
        self.session_id = None

    async def cancel(self) -> None:
        """Cancel is a no-op for Modal API (no persistent process)."""
        self._busy = False
