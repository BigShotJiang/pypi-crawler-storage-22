"""
Work Session - Streaming Claude Code subprocess with session continuation.

Used by work mode to run Claude Code prompts on real project files,
with streaming progress and conversation continuation via --resume.
"""

import asyncio
import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import AsyncIterator, Optional


@dataclass
class StreamEvent:
    """A single event from the Claude Code stream-json output."""

    event_type: str  # assistant, tool_use, tool_result, result, error
    content: str  # text or tool summary
    session_id: Optional[str] = None
    data: dict = field(default_factory=dict)


class WorkSession:
    """
    Manages a streaming Claude Code subprocess with session continuation.

    Each prompt spawns `claude -p` with `--output-format stream-json`.
    After the first result, subsequent prompts use `--resume <session_id>`
    so Claude remembers the full conversation context.
    """

    def __init__(
        self,
        workspace: Path,
        model: str = "opus",
        max_turns: int = 50,
        allowed_paths: Optional[list[str]] = None,
    ):
        self.workspace = Path(workspace).resolve()
        self.model = model
        self.max_turns = max_turns
        self.allowed_paths = allowed_paths or []
        self.session_id: Optional[str] = None
        self.prompt_count: int = 0
        self._process: Optional[asyncio.subprocess.Process] = None
        self._busy = False

    @property
    def is_busy(self) -> bool:
        return self._busy

    async def send(self, prompt: str) -> AsyncIterator[StreamEvent]:
        """
        Send a prompt to Claude Code and yield streaming events.

        Builds command with --output-format stream-json for real-time progress.
        If session_id exists, appends --resume <session_id> for continuation.
        """
        if self._busy:
            yield StreamEvent(
                event_type="error",
                content="Session is busy. Wait for the current prompt to finish.",
            )
            return

        self._busy = True
        self.prompt_count += 1

        # Inject allowed_paths constraint on first prompt of a session
        if self.allowed_paths and not self.session_id:
            paths_list = "\n".join(f"  - {p}" for p in self.allowed_paths)
            prompt = (
                f"IMPORTANT PATH RESTRICTIONS:\n"
                f"You can READ files from anywhere, but you may ONLY create/edit/delete files "
                f"within these allowed paths:\n{paths_list}\n\n"
                f"Do NOT modify files outside these paths. If a task requires changes outside "
                f"these paths, tell the user which files need changing and why.\n\n"
                f"---\n\n{prompt}"
            )

        try:
            cmd = [
                "claude",
                "-p",
                prompt,
                "--output-format", "stream-json",
                "--verbose",
                "--model", self.model,
                "--max-turns", str(self.max_turns),
                "--dangerously-skip-permissions",
            ]

            if self.session_id:
                cmd.extend(["--resume", self.session_id])

            self._process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(self.workspace),
                env={**os.environ, "CLAUDE_CODE_ENTRYPOINT": "nullabot-work"},
            )

            async for line in self._process.stdout:
                line = line.decode("utf-8", errors="replace").strip()
                if not line:
                    continue

                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    continue

                event = self._parse_stream_event(data)
                if event:
                    yield event

            # Wait for process to finish
            await self._process.wait()

            if self._process.returncode != 0:
                stderr = ""
                if self._process.stderr:
                    try:
                        stderr_bytes = await self._process.stderr.read()
                        stderr = stderr_bytes.decode("utf-8", errors="replace").strip()
                    except (ValueError, OSError):
                        # Stream was closed, ignore stderr
                        pass
                if stderr:
                    yield StreamEvent(
                        event_type="error",
                        content=f"Process exited with code {self._process.returncode}: {stderr[:500]}",
                        data={"returncode": self._process.returncode},
                    )

        except asyncio.CancelledError:
            if self._process:
                try:
                    self._process.terminate()
                    await asyncio.wait_for(self._process.wait(), timeout=2.0)
                except (ProcessLookupError, asyncio.TimeoutError, asyncio.CancelledError):
                    pass
            yield StreamEvent(event_type="error", content="Cancelled")
        except (ValueError, OSError) as e:
            # Stream closed or other I/O errors during subprocess communication
            if "stream" in str(e).lower() and "closed" in str(e).lower():
                yield StreamEvent(
                    event_type="error",
                    content="Session was interrupted (stream closed). Please try again.",
                )
            else:
                yield StreamEvent(event_type="error", content=str(e))
        except Exception as e:
            yield StreamEvent(event_type="error", content=str(e))
        finally:
            # Ensure process is properly cleaned up
            if self._process and self._process.returncode is None:
                try:
                    self._process.kill()
                    await asyncio.wait_for(self._process.wait(), timeout=1.0)
                except (ProcessLookupError, asyncio.TimeoutError):
                    pass
            self._process = None
            self._busy = False

    def _parse_stream_event(self, data: dict) -> Optional[StreamEvent]:
        """Parse a stream-json event into a StreamEvent.

        Stream-json format:
        - {"type": "system", ...} — init event with session info
        - {"type": "assistant", "message": {"content": [...]}} — text or tool_use blocks
        - {"type": "user", "tool_use_result": {...}} — tool results
        - {"type": "result", "result": "...", "session_id": "..."} — final result
        """
        event_type = data.get("type", "")

        # Assistant message — may contain text blocks and/or tool_use blocks
        if event_type == "assistant":
            message = data.get("message", {})
            content_blocks = message.get("content", [])

            # Check for tool_use blocks first (progress reporting)
            for block in content_blocks:
                if block.get("type") == "tool_use":
                    name = block.get("name", "unknown")
                    tool_input = block.get("input", {})
                    summary = self._summarize_tool_use(name, tool_input)
                    return StreamEvent(
                        event_type="tool_use",
                        content=summary,
                        data=data,
                    )

            # Otherwise extract text
            text_parts = []
            for block in content_blocks:
                if block.get("type") == "text":
                    text_parts.append(block.get("text", ""))
            if text_parts:
                return StreamEvent(
                    event_type="assistant",
                    content="\n".join(text_parts),
                    data=data,
                )

        # Tool result (type "user" with tool_use_result)
        elif event_type == "user" and "tool_use_result" in data:
            return StreamEvent(
                event_type="tool_result",
                content="",
                data=data,
            )

        # Final result
        elif event_type == "result":
            session_id = data.get("session_id")
            if session_id:
                self.session_id = session_id

            text = data.get("result", "")
            if not isinstance(text, str):
                # Handle list of content blocks
                parts = []
                if isinstance(text, list):
                    for block in text:
                        if isinstance(block, dict) and block.get("type") == "text":
                            parts.append(block.get("text", ""))
                        elif isinstance(block, str):
                            parts.append(block)
                text = "\n".join(parts)

            return StreamEvent(
                event_type="result",
                content=text,
                session_id=session_id,
                data=data,
            )

        # Error
        elif event_type == "error":
            error = data.get("error", {})
            message = error.get("message", str(error)) if isinstance(error, dict) else str(error)
            return StreamEvent(
                event_type="error",
                content=message,
                data=data,
            )

        return None

    @staticmethod
    def _summarize_tool_use(name: str, tool_input: dict) -> str:
        """Human-readable summary of what Claude is doing."""
        if name == "Read":
            path = tool_input.get("file_path", "file")
            return f"Reading {Path(path).name}"
        elif name == "Write":
            path = tool_input.get("file_path", "file")
            return f"Writing {Path(path).name}"
        elif name == "Edit":
            path = tool_input.get("file_path", "file")
            return f"Editing {Path(path).name}"
        elif name == "Bash":
            cmd = tool_input.get("command", "")
            if len(cmd) > 60:
                cmd = cmd[:57] + "..."
            return f"Running: {cmd}"
        elif name == "Glob":
            pattern = tool_input.get("pattern", "")
            return f"Finding: {pattern}"
        elif name == "Grep":
            pattern = tool_input.get("pattern", "")
            return f"Searching: {pattern}"
        elif name == "Task":
            desc = tool_input.get("description", "subtask")
            return f"Agent: {desc}"
        elif name == "WebSearch":
            query = tool_input.get("query", "")
            return f"Searching web: {query[:40]}"
        elif name == "WebFetch":
            url = tool_input.get("url", "")
            return f"Fetching: {url[:40]}"
        else:
            return f"Using {name}"

    def new_session(self) -> None:
        """Clear session_id so the next prompt starts fresh."""
        self.session_id = None
        self.prompt_count = 0

    async def cancel(self) -> None:
        """Terminate the running subprocess."""
        if self._process:
            try:
                self._process.terminate()
                await asyncio.sleep(0.5)
                if self._process.returncode is None:
                    self._process.kill()
            except ProcessLookupError:
                pass
            self._process = None
            self._busy = False
