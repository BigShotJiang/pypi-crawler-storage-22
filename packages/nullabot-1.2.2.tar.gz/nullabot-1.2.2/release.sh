#!/bin/bash
set -e

# Nullabot release script
# Usage: ./release.sh 1.2.0

if [ -z "$1" ]; then
    # Show current version and prompt
    CURRENT=$(grep '^version' pyproject.toml | head -1 | sed 's/.*"\(.*\)"/\1/')
    echo "Current version: $CURRENT"
    echo "Usage: ./release.sh <new-version>"
    echo "Example: ./release.sh 1.2.0"
    exit 1
fi

VERSION=$1

# Validate version format
if ! echo "$VERSION" | grep -qE '^[0-9]+\.[0-9]+\.[0-9]+$'; then
    echo "Error: Version must be in format X.Y.Z (e.g. 1.2.0)"
    exit 1
fi

CURRENT=$(grep '^version' pyproject.toml | head -1 | sed 's/.*"\(.*\)"/\1/')
echo "Updating $CURRENT → $VERSION"

# Update version in all files
sed -i '' "s/^version = \".*\"/version = \"$VERSION\"/" pyproject.toml
sed -i '' "s/^__version__ = \".*\"/__version__ = \"$VERSION\"/" nullabot/__init__.py

# Verify
echo ""
echo "Updated files:"
grep -n "version" pyproject.toml | head -1
grep -n "__version__" nullabot/__init__.py

# Git commit and tag
echo ""
echo "Committing..."
git add pyproject.toml nullabot/__init__.py
git commit -m "v$VERSION"
git tag "v$VERSION"
git push origin main --tags

# Build and publish
echo ""
echo "Building..."
rm -rf dist/
python3 -m build

echo ""
echo "Publishing to PyPI..."
python3 -m twine upload dist/*

echo ""
echo "Done! https://pypi.org/project/nullabot/$VERSION/"
