def nullberry0():
    print("______INITIATING NULLBERRY0 STUDIO___________")
