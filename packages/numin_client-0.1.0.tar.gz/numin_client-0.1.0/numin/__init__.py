"""Numin Python SDK - Financial Market Analysis API Client."""

from ._async_client import AsyncNumin
from ._client import Numin
from ._constants import SDK_VERSION as __version__
from ._constants import VALID_TIMEFRAMES, Timeframe
from ._exceptions import (
    AuthenticationError,
    BadRequestError,
    ConnectionError,
    InternalServerError,
    NotFoundError,
    NuminError,
    PermissionDeniedError,
    RateLimitError,
    TimeoutError,
)
from ._types import (
    HarmonicsResult,
    OHLCVBar,
    ProjectionResult,
    ReportDownload,
    ValidatedTrade,
)

__all__ = [
    "Numin",
    "AsyncNumin",
    "__version__",
    "VALID_TIMEFRAMES",
    "Timeframe",
    # Exceptions
    "NuminError",
    "AuthenticationError",
    "PermissionDeniedError",
    "NotFoundError",
    "BadRequestError",
    "RateLimitError",
    "InternalServerError",
    "ConnectionError",
    "TimeoutError",
    # Types
    "OHLCVBar",
    "ProjectionResult",
    "ValidatedTrade",
    "HarmonicsResult",
    "ReportDownload",
]
