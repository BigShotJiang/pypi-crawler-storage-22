from __future__ import annotations

from typing import Optional

import httpx

from ._base_client import BaseClient
from .resources.harmonics import AsyncHarmonics
from .resources.market_data import AsyncMarketData
from .resources.projections import AsyncProjections
from .resources.reports import AsyncReports


class AsyncNumin(BaseClient):
    """Asynchronous client for the Numin API.

    Usage::

        import asyncio
        from numin import AsyncNumin

        async def main():
            async with AsyncNumin(api_key="numin_xxxxx") as client:
                result = await client.projections.single_ticker(
                    ticker="SPY", timeframe="daily", start_date="2026-01-01"
                )

        asyncio.run(main())
    """

    projections: AsyncProjections
    harmonics: AsyncHarmonics
    market_data: AsyncMarketData
    reports: AsyncReports

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )

        transport = httpx.AsyncHTTPTransport(retries=self.max_retries)
        self._http_client = http_client or httpx.AsyncClient(
            headers=self._default_headers,
            timeout=self.timeout,
            transport=transport,
        )
        self._owns_client = http_client is None

        self.projections = AsyncProjections(self, self._http_client)
        self.harmonics = AsyncHarmonics(self, self._http_client)
        self.market_data = AsyncMarketData(self, self._http_client)
        self.reports = AsyncReports(self, self._http_client)

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._owns_client:
            await self._http_client.aclose()

    async def __aenter__(self) -> AsyncNumin:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
