from __future__ import annotations

import os
from typing import Any, Dict, Optional

import httpx

from ._constants import DEFAULT_BASE_URL, DEFAULT_MAX_RETRIES, DEFAULT_TIMEOUT, SDK_VERSION
from ._exceptions import (
    AuthenticationError,
    BadRequestError,
    ConnectionError,
    InternalServerError,
    NotFoundError,
    NuminError,
    PermissionDeniedError,
    RateLimitError,
    TimeoutError,
)


class BaseClient:
    """Shared configuration and logic for sync/async clients."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
    ) -> None:
        self.api_key = api_key or os.environ.get("NUMIN_API_KEY", "")
        if not self.api_key:
            raise AuthenticationError(
                "API key is required. Pass it as api_key= or set the NUMIN_API_KEY environment variable."
            )

        self.base_url = (
            base_url or os.environ.get("NUMIN_BASE_URL", DEFAULT_BASE_URL)
        ).rstrip("/")
        self.timeout = timeout if timeout is not None else DEFAULT_TIMEOUT
        self.max_retries = max_retries if max_retries is not None else DEFAULT_MAX_RETRIES

    @property
    def _default_headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "User-Agent": f"numin-python/{SDK_VERSION}",
            "Accept": "application/json",
        }

    def _build_url(self, path: str) -> str:
        """Build full URL from a relative path like '/projection/single-ticker'."""
        return f"{self.base_url}{path}"

    def _raise_for_status(self, response: httpx.Response) -> None:
        """Convert HTTP error responses to typed exceptions."""
        if response.is_success:
            return

        status = response.status_code
        try:
            body = response.json()
            detail = body.get("detail", response.text)
        except Exception:
            detail = response.text

        error_map: Dict[int, type] = {
            400: BadRequestError,
            401: AuthenticationError,
            403: PermissionDeniedError,
            404: NotFoundError,
            429: RateLimitError,
        }

        exc_class = error_map.get(
            status, InternalServerError if status >= 500 else NuminError
        )
        raise exc_class(
            message=str(detail), status_code=status, response=response
        )

    def _handle_request_error(self, exc: Exception) -> None:
        """Convert httpx transport errors to Numin exceptions."""
        if isinstance(exc, httpx.TimeoutException):
            raise TimeoutError(message=f"Request timed out: {exc}") from exc
        if isinstance(exc, httpx.ConnectError):
            raise ConnectionError(message=f"Connection failed: {exc}") from exc
        if isinstance(exc, httpx.HTTPStatusError):
            self._raise_for_status(exc.response)
        raise NuminError(message=f"Request failed: {exc}") from exc
