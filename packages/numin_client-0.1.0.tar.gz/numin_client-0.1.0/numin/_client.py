from __future__ import annotations

from typing import Optional

import httpx

from ._base_client import BaseClient
from .resources.harmonics import SyncHarmonics
from .resources.market_data import SyncMarketData
from .resources.projections import SyncProjections
from .resources.reports import SyncReports


class Numin(BaseClient):
    """Synchronous client for the Numin API.

    Usage::

        from numin import Numin

        client = Numin(api_key="numin_xxxxx")
        result = client.projections.single_ticker(
            ticker="SPY", timeframe="daily", start_date="2026-01-01"
        )
        client.close()

    Or as a context manager::

        with Numin(api_key="numin_xxxxx") as client:
            result = client.projections.single_ticker(
                ticker="SPY", timeframe="daily", start_date="2026-01-01"
            )
    """

    projections: SyncProjections
    harmonics: SyncHarmonics
    market_data: SyncMarketData
    reports: SyncReports

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
        http_client: Optional[httpx.Client] = None,
    ) -> None:
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )

        transport = httpx.HTTPTransport(retries=self.max_retries)
        self._http_client = http_client or httpx.Client(
            headers=self._default_headers,
            timeout=self.timeout,
            transport=transport,
        )
        self._owns_client = http_client is None

        self.projections = SyncProjections(self, self._http_client)
        self.harmonics = SyncHarmonics(self, self._http_client)
        self.market_data = SyncMarketData(self, self._http_client)
        self.reports = SyncReports(self, self._http_client)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._owns_client:
            self._http_client.close()

    def __enter__(self) -> Numin:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
