from __future__ import annotations

from typing import Literal

SDK_VERSION = "0.1.0"
DEFAULT_BASE_URL = "https://api.numin.com"
DEFAULT_TIMEOUT = 120.0
DEFAULT_MAX_RETRIES = 2

VALID_TIMEFRAMES = [
    "daily", "weekly", "monthly",
    "1min", "5min", "10min", "15min", "30min",
    "1hour", "2hour", "4hour",
]

Timeframe = Literal[
    "daily", "weekly", "monthly",
    "1min", "5min", "10min", "15min", "30min",
    "1hour", "2hour", "4hour",
]
