from __future__ import annotations

from typing import Any, Optional


class NuminError(Exception):
    """Base exception for all Numin SDK errors."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response: Any = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response = response


class AuthenticationError(NuminError):
    """401 - Invalid or missing API key."""


class PermissionDeniedError(NuminError):
    """403 - API key lacks permission for the requested resource."""


class NotFoundError(NuminError):
    """404 - Requested data not found."""


class BadRequestError(NuminError):
    """400 - Invalid parameters."""


class RateLimitError(NuminError):
    """429 - Rate limit exceeded."""


class InternalServerError(NuminError):
    """500+ - Server-side error."""


class ConnectionError(NuminError):
    """Network connectivity issues."""


class TimeoutError(NuminError):
    """Request timed out."""
