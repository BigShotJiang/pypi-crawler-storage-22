from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel


class OHLCVBar(BaseModel):
    """A single OHLCV data point from the market-data endpoint."""

    model_config = {"extra": "allow"}


class ProjectionResult(BaseModel):
    """Wrapper for projection response data.

    The API returns dynamic structures with clustering and consolidated
    projection data, so fields are kept flexible.
    """

    model_config = {"extra": "allow"}


class ValidatedTrade(BaseModel):
    """A single validated trade from harmonics analysis."""

    pattern: str
    dir: str
    entry: str
    t1: str
    t2: Optional[str] = None
    sl: str
    age: int
    is_bullish: bool
    t1_valid: bool = False
    t2_valid: bool = False
    sl_hit_before_t2: bool = False
    validation_reason: str = ""

    model_config = {"extra": "allow"}


class HarmonicsResult(BaseModel):
    """Full harmonics response (comprehensive=True)."""

    patterns: List[Dict[str, Any]]
    pattern_table: List[Dict[str, Any]]
    statistics_table: List[Dict[str, Any]]
    analysis: Dict[str, Any]
    zigzag_points: List[Any]
    zigzag_directions: List[Any]
    predicted_points: List[Any]
    drawings: Dict[str, Any]
    validated_trades: List[Dict[str, Any]]

    model_config = {"extra": "allow"}


class ReportDownload(BaseModel):
    """Metadata about a downloaded report file."""

    filename: str
    content: bytes
    content_type: str
