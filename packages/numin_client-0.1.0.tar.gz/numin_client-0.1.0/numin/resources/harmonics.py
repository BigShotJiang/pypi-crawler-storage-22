from __future__ import annotations

from typing import Any, Dict, Optional, TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from .._base_client import BaseClient


class SyncHarmonics:
    """Synchronous harmonics endpoints."""

    def __init__(self, client: BaseClient, http_client: httpx.Client) -> None:
        self._client = client
        self._http = http_client

    def single_ticker(
        self,
        ticker: str,
        timeframe: str,
        start_date: Optional[str] = None,
        bars: int = 20,
        comprehensive: bool = True,
        use_harmonic: bool = False,
        limit: int = 10,
        download: bool = False,
    ) -> Dict[str, Any]:
        """Get harmonic patterns and BCD predictions for a single ticker.

        Args:
            ticker: Stock symbol (e.g., "SPY").
            timeframe: Timeframe string.
            start_date: Start date for replay mode (YYYY-MM-DD), optional.
            bars: Bars ahead for pattern validation (5-100, default 20).
            comprehensive: True for full response, False for validated_trades only.
            use_harmonic: False for BCD predictions (default), True for harmonic patterns.
            limit: Max validated trades when comprehensive=False (1-100).
            download: If True, returns raw JSON as bytes.

        Returns:
            Dictionary with patterns, analysis, predictions, and validated trades.
        """
        params: Dict[str, Any] = {
            "ticker": ticker,
            "timeframe": timeframe,
            "bars": bars,
            "comprehensive": comprehensive,
            "useHarmonic": use_harmonic,
            "limit": limit,
            "download": download,
        }
        if start_date is not None:
            params["startDate"] = start_date

        try:
            response = self._http.get(
                self._client._build_url("/harmonics/single-ticker"),
                params=params,
            )
        except httpx.HTTPError as exc:
            self._client._handle_request_error(exc)

        self._client._raise_for_status(response)
        return response.json()


class AsyncHarmonics:
    """Asynchronous harmonics endpoints."""

    def __init__(self, client: BaseClient, http_client: httpx.AsyncClient) -> None:
        self._client = client
        self._http = http_client

    async def single_ticker(
        self,
        ticker: str,
        timeframe: str,
        start_date: Optional[str] = None,
        bars: int = 20,
        comprehensive: bool = True,
        use_harmonic: bool = False,
        limit: int = 10,
        download: bool = False,
    ) -> Dict[str, Any]:
        """Get harmonic patterns and BCD predictions for a single ticker.

        Args:
            ticker: Stock symbol (e.g., "SPY").
            timeframe: Timeframe string.
            start_date: Start date for replay mode (YYYY-MM-DD), optional.
            bars: Bars ahead for pattern validation (5-100, default 20).
            comprehensive: True for full response, False for validated_trades only.
            use_harmonic: False for BCD predictions (default), True for harmonic patterns.
            limit: Max validated trades when comprehensive=False (1-100).
            download: If True, returns raw JSON as bytes.

        Returns:
            Dictionary with patterns, analysis, predictions, and validated trades.
        """
        params: Dict[str, Any] = {
            "ticker": ticker,
            "timeframe": timeframe,
            "bars": bars,
            "comprehensive": comprehensive,
            "useHarmonic": use_harmonic,
            "limit": limit,
            "download": download,
        }
        if start_date is not None:
            params["startDate"] = start_date

        try:
            response = await self._http.get(
                self._client._build_url("/harmonics/single-ticker"),
                params=params,
            )
        except httpx.HTTPError as exc:
            self._client._handle_request_error(exc)

        self._client._raise_for_status(response)
        return response.json()
