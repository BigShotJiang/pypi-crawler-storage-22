from __future__ import annotations

from typing import Any, Dict, List, TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from .._base_client import BaseClient


class SyncMarketData:
    """Synchronous market data endpoints."""

    def __init__(self, client: BaseClient, http_client: httpx.Client) -> None:
        self._client = client
        self._http = http_client

    def get(
        self,
        ticker: str,
        timeframe: str,
    ) -> List[Dict[str, Any]]:
        """Get raw OHLCV market data for a ticker.

        Args:
            ticker: Stock symbol (e.g., "SPY").
            timeframe: Timeframe string.

        Returns:
            List of OHLCV bar dictionaries.
        """
        try:
            response = self._http.get(
                self._client._build_url("/market-data/"),
                params={"ticker": ticker, "timeframe": timeframe},
            )
        except httpx.HTTPError as exc:
            self._client._handle_request_error(exc)

        self._client._raise_for_status(response)
        return response.json()


class AsyncMarketData:
    """Asynchronous market data endpoints."""

    def __init__(self, client: BaseClient, http_client: httpx.AsyncClient) -> None:
        self._client = client
        self._http = http_client

    async def get(
        self,
        ticker: str,
        timeframe: str,
    ) -> List[Dict[str, Any]]:
        """Get raw OHLCV market data for a ticker.

        Args:
            ticker: Stock symbol (e.g., "SPY").
            timeframe: Timeframe string.

        Returns:
            List of OHLCV bar dictionaries.
        """
        try:
            response = await self._http.get(
                self._client._build_url("/market-data/"),
                params={"ticker": ticker, "timeframe": timeframe},
            )
        except httpx.HTTPError as exc:
            self._client._handle_request_error(exc)

        self._client._raise_for_status(response)
        return response.json()
