from __future__ import annotations

from typing import Any, Dict, List, TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from .._base_client import BaseClient


class SyncProjections:
    """Synchronous projection endpoints."""

    def __init__(self, client: BaseClient, http_client: httpx.Client) -> None:
        self._client = client
        self._http = http_client

    def single_ticker(
        self,
        ticker: str,
        timeframe: str,
        start_date: str,
    ) -> Dict[str, Any]:
        """Get projection for a single ticker and timeframe.

        Args:
            ticker: Stock symbol (e.g., "SPY", "AAPL").
            timeframe: One of: daily, weekly, monthly, 1min, 5min, 10min,
                       15min, 30min, 1hour, 2hour, 4hour.
            start_date: Analysis start date in YYYY-MM-DD format.

        Returns:
            Dictionary with clustering and consolidated projection data.
        """
        try:
            response = self._http.get(
                self._client._build_url("/projection/single-ticker"),
                params={
                    "ticker": ticker,
                    "timeframe": timeframe,
                    "start_date": start_date,
                },
            )
        except httpx.HTTPError as exc:
            self._client._handle_request_error(exc)

        self._client._raise_for_status(response)
        return response.json()

    def multi_ticker(
        self,
        tickers: List[str],
        timeframe: str,
        start_date: str,
    ) -> Dict[str, Any]:
        """Get projections for multiple tickers on the same timeframe.

        Args:
            tickers: List of stock symbols (e.g., ["SPY", "QQQ", "AAPL"]).
            timeframe: Timeframe string.
            start_date: Analysis start date in YYYY-MM-DD format.

        Returns:
            Dictionary keyed by ticker, each containing projection data.
        """
        try:
            response = self._http.get(
                self._client._build_url("/projection/multi-ticker"),
                params={
                    "tickers": ",".join(tickers),
                    "timeframe": timeframe,
                    "start_date": start_date,
                },
            )
        except httpx.HTTPError as exc:
            self._client._handle_request_error(exc)

        self._client._raise_for_status(response)
        return response.json()

    def multi_ticker_multi_timeframe(
        self,
        tickers: List[str],
        timeframes: List[str],
        start_date: str,
    ) -> Dict[str, Dict[str, Any]]:
        """Get projections for multiple tickers across multiple timeframes.

        Args:
            tickers: List of stock symbols.
            timeframes: List of timeframe strings.
            start_date: Analysis start date in YYYY-MM-DD format.

        Returns:
            Nested dict: {ticker: {timeframe: projection_data}}.
        """
        try:
            response = self._http.get(
                self._client._build_url("/projection/multi-ticker-multi-timeframe"),
                params={
                    "tickers": ",".join(tickers),
                    "timeframes": ",".join(timeframes),
                    "start_date": start_date,
                },
            )
        except httpx.HTTPError as exc:
            self._client._handle_request_error(exc)

        self._client._raise_for_status(response)
        return response.json()


class AsyncProjections:
    """Asynchronous projection endpoints."""

    def __init__(self, client: BaseClient, http_client: httpx.AsyncClient) -> None:
        self._client = client
        self._http = http_client

    async def single_ticker(
        self,
        ticker: str,
        timeframe: str,
        start_date: str,
    ) -> Dict[str, Any]:
        """Get projection for a single ticker and timeframe.

        Args:
            ticker: Stock symbol (e.g., "SPY", "AAPL").
            timeframe: Timeframe string.
            start_date: Analysis start date in YYYY-MM-DD format.

        Returns:
            Dictionary with clustering and consolidated projection data.
        """
        try:
            response = await self._http.get(
                self._client._build_url("/projection/single-ticker"),
                params={
                    "ticker": ticker,
                    "timeframe": timeframe,
                    "start_date": start_date,
                },
            )
        except httpx.HTTPError as exc:
            self._client._handle_request_error(exc)

        self._client._raise_for_status(response)
        return response.json()

    async def multi_ticker(
        self,
        tickers: List[str],
        timeframe: str,
        start_date: str,
    ) -> Dict[str, Any]:
        """Get projections for multiple tickers on the same timeframe.

        Args:
            tickers: List of stock symbols.
            timeframe: Timeframe string.
            start_date: Analysis start date in YYYY-MM-DD format.

        Returns:
            Dictionary keyed by ticker, each containing projection data.
        """
        try:
            response = await self._http.get(
                self._client._build_url("/projection/multi-ticker"),
                params={
                    "tickers": ",".join(tickers),
                    "timeframe": timeframe,
                    "start_date": start_date,
                },
            )
        except httpx.HTTPError as exc:
            self._client._handle_request_error(exc)

        self._client._raise_for_status(response)
        return response.json()

    async def multi_ticker_multi_timeframe(
        self,
        tickers: List[str],
        timeframes: List[str],
        start_date: str,
    ) -> Dict[str, Dict[str, Any]]:
        """Get projections for multiple tickers across multiple timeframes.

        Args:
            tickers: List of stock symbols.
            timeframes: List of timeframe strings.
            start_date: Analysis start date in YYYY-MM-DD format.

        Returns:
            Nested dict: {ticker: {timeframe: projection_data}}.
        """
        try:
            response = await self._http.get(
                self._client._build_url("/projection/multi-ticker-multi-timeframe"),
                params={
                    "tickers": ",".join(tickers),
                    "timeframes": ",".join(timeframes),
                    "start_date": start_date,
                },
            )
        except httpx.HTTPError as exc:
            self._client._handle_request_error(exc)

        self._client._raise_for_status(response)
        return response.json()
