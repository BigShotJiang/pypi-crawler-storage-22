from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional, Union, TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from .._base_client import BaseClient


class SyncReports:
    """Synchronous report endpoints."""

    def __init__(self, client: BaseClient, http_client: httpx.Client) -> None:
        self._client = client
        self._http = http_client

    def download(
        self,
        ticker: str,
        timeframe: str,
        start_date: Optional[str] = None,
        *,
        file_path: Optional[Union[str, Path]] = None,
    ) -> bytes:
        """Download a prediction report as DOCX.

        Args:
            ticker: Stock symbol (e.g., "SPY").
            timeframe: Timeframe string.
            start_date: Start date (YYYY-MM-DD). Defaults to today on server.
            file_path: If provided, saves the DOCX to this path.

        Returns:
            Raw DOCX file bytes.
        """
        params: Dict[str, Any] = {"ticker": ticker, "timeframe": timeframe}
        if start_date is not None:
            params["start_date"] = start_date

        try:
            response = self._http.get(
                self._client._build_url("/report/download"),
                params=params,
                headers={**self._client._default_headers, "Accept": "*/*"},
            )
        except httpx.HTTPError as exc:
            self._client._handle_request_error(exc)

        self._client._raise_for_status(response)
        content = response.content

        if file_path is not None:
            path = Path(file_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)

        return content


class AsyncReports:
    """Asynchronous report endpoints."""

    def __init__(self, client: BaseClient, http_client: httpx.AsyncClient) -> None:
        self._client = client
        self._http = http_client

    async def download(
        self,
        ticker: str,
        timeframe: str,
        start_date: Optional[str] = None,
        *,
        file_path: Optional[Union[str, Path]] = None,
    ) -> bytes:
        """Download a prediction report as DOCX.

        Args:
            ticker: Stock symbol (e.g., "SPY").
            timeframe: Timeframe string.
            start_date: Start date (YYYY-MM-DD). Defaults to today on server.
            file_path: If provided, saves the DOCX to this path.

        Returns:
            Raw DOCX file bytes.
        """
        params: Dict[str, Any] = {"ticker": ticker, "timeframe": timeframe}
        if start_date is not None:
            params["start_date"] = start_date

        try:
            response = await self._http.get(
                self._client._build_url("/report/download"),
                params=params,
                headers={**self._client._default_headers, "Accept": "*/*"},
            )
        except httpx.HTTPError as exc:
            self._client._handle_request_error(exc)

        self._client._raise_for_status(response)
        content = response.content

        if file_path is not None:
            path = Path(file_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)

        return content
