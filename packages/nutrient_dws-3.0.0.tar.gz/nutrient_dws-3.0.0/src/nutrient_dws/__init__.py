"""Nutrient DWS Python Client.

A Python client library for the Nutrient Document Web Services API.
"""

from nutrient_dws.client import NutrientClient
from nutrient_dws.errors import (
    APIError,
    AuthenticationError,
    NetworkError,
    NutrientError,
    ValidationError,
)
from nutrient_dws.inputs import (
    FileInput,
    LocalFileInput,
    UrlFileInput,
    is_remote_file_input,
    process_file_input,
    validate_file_input,
)
from nutrient_dws.utils import get_library_version, get_user_agent

__all__ = [
    "APIError",
    "AuthenticationError",
    "FileInput",
    "LocalFileInput",
    "NetworkError",
    "NutrientClient",
    "NutrientError",
    "UrlFileInput",
    "ValidationError",
    "get_library_version",
    "get_user_agent",
    "is_remote_file_input",
    "process_file_input",
    "validate_file_input",
]
