"""Nuvu - Multi-Cloud Data Asset Control."""

__version__ = "2.0.0"
