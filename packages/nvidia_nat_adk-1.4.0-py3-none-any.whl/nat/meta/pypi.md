<!--
SPDX-FileCopyrightText: Copyright (c) 2025-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: Apache-2.0

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-->

![NVIDIA NeMo Agent Toolkit](https://raw.githubusercontent.com/NVIDIA/NeMo-Agent-Toolkit/main/docs/source/_static/banner.png "NeMo Agent Toolkit banner")

# NVIDIA NeMo Agent Toolkit — Google ADK Subpackage
Subpackage providing Google ADK integration for the NVIDIA NeMo Agent Toolkit.
