# 🌈 nvlogger

[![PyPI version](https://img.shields.io/pypi/v/nvlogger.svg)](https://pypi.org/project/nvlogger/)
[![Python versions](https://img.shields.io/pypi/pyversions/nvlogger.svg)](https://pypi.org/project/nvlogger/)
[![License](https://img.shields.io/pypi/l/nvlogger.svg)](https://github.com/NullVoidDev/nvlogger/blob/main/LICENSE)

> **Logging bonito e zero configuração para Python** ✨

Transforme seu terminal em uma experiência visual agradável. `nvlogger` substitui `print()` e logging básico com mensagens coloridas, emojis e formatação elegante — tudo com zero configuração.

## 📦 Instalação

```bash
pip install nvlogger
```

## 🚀 Uso Rápido

```python
from nvlogger import setup, log, success, info, warning, error, debug

setup()  # Configura tudo automaticamente

log("Mensagem normal")
success("Operação concluída com sucesso!")
info("Iniciando download...")
warning("Atenção: arquivo grande detectado")
error("Falha na conexão com a API")
debug("Valor intermediário: 42.50")
```

**Saída:**

```
   agora 📝 Mensagem normal
   agora ✅ Operação concluída com sucesso!
   agora ℹ️  Iniciando download...
   agora ⚠️  Atenção: arquivo grande detectado
   agora ❌ Falha na conexão com a API
   agora 🔍 Valor intermediário: 42.50
```

## 📋 Funcionalidades

### 🎨 Cores e Emojis Automáticos

| Função    | Emoji | Cor      |
|-----------|-------|----------|
| `log()`     | 📝    | Branco   |
| `success()` | ✅    | Verde    |
| `info()`    | ℹ️     | Azul     |
| `warning()` | ⚠️     | Amarelo  |
| `error()`   | ❌    | Vermelho |
| `debug()`   | 🔍    | Cinza    |

### ⏱️ Timestamp Relativo

Cada mensagem mostra um timestamp relativo: `agora`, `há 2s`, `há 1min`, etc.

### 📦 Variáveis Extras

Adicione contexto às suas mensagens:

```python
log("Login realizado", user="joao", ip="192.168.1.1")
# agora 📝 Login realizado user=joao ip=192.168.1.1
```

### 🔴 Exceções Formatadas

Capture e exiba exceções de forma elegante:

```python
try:
    resultado = 1 / 0
except ZeroDivisionError:
    error("Erro no cálculo", exc_info=True)
```

### 📦 Seções

Agrupe logs relacionados visualmente:

```python
with log.section("Processamento de imagens"):
    log("Carregando imagens...")
    info("Processando 100 arquivos")
    success("Concluído!")
```

**Saída:**

```
┌─ Processamento de imagens
│
   agora 📝 Carregando imagens...
   agora ℹ️  Processando 100 arquivos
   agora ✅ Concluído!
│
└────────────────────
```

## ⚙️ Configuração

### Nível de Log

Controle quais mensagens são exibidas via variável de ambiente:

```bash
# Mostra apenas WARNING e ERROR
set NVLOGGER_LEVEL=WARNING

# Mostra tudo incluindo DEBUG
set NVLOGGER_LEVEL=DEBUG
```

Ou configure diretamente:

```python
setup(level="DEBUG")
```

### Opções de setup()

```python
setup(
    level="INFO",           # Nível de log (DEBUG, INFO, WARNING, ERROR)
    force_terminal=True,    # Força saída de terminal (útil em pipes)
    no_color=False,         # Desabilita cores
)
```

## 📄 Licença

MIT License - use à vontade! 🎉

---

Feito com ❤️ usando [rich](https://github.com/Textualize/rich)
