"""
nvlogger - Logging bonito e zero configuração para Python.

A modern, minimalist logging library that makes terminal output
beautiful using the rich library.

Example:
    >>> from nvlogger import setup, log, success, info, warning, error, debug
    >>> setup()
    >>> log("Normal message")
    >>> success("Operation completed!")
    >>> info("Starting download...")
    >>> warning("Large file detected")
    >>> error("Connection failed", exc_info=True)
    >>> debug("Debug info")
    >>>
    >>> # Using sections
    >>> with log.section("Processing"):
    ...     log("Working...")
    ...     success("Done!")
"""

from __future__ import annotations

from .__version__ import __version__
from .setup import setup
from .core import log, success, info, warning, error, debug
from .context import section

# Attach section method to log function for log.section() syntax
log.section = section  # type: ignore[attr-defined]

__all__ = [
    "__version__",
    "setup",
    "log",
    "success",
    "info",
    "warning",
    "error",
    "debug",
    "section",
]
