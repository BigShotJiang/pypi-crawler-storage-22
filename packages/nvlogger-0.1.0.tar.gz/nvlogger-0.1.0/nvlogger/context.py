"""
nvlogger context manager module.

Provides the Section context manager for grouping log messages.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Generator

from rich.panel import Panel

from .setup import get_console


@contextmanager
def section(title: str) -> Generator[None, None, None]:
    """
    Context manager for creating a visual section in logs.
    
    Creates a panel-like section with a title, visually grouping
    all log messages within the context.
    
    Args:
        title: The title of the section.
    
    Yields:
        None
    
    Example:
        >>> from nvlogger import log, success
        >>> with log.section("Processing"):
        ...     log("Loading data...")
        ...     success("Done!")
    """
    console = get_console()
    
    # Print section header
    console.print()
    console.print(
        f"[bold cyan]┌─[/bold cyan] [bold white]{title}[/bold white]",
    )
    console.print("[bold cyan]│[/bold cyan]")
    
    try:
        yield
    finally:
        # Print section footer
        console.print("[bold cyan]│[/bold cyan]")
        console.print("[bold cyan]└────────────────────[/bold cyan]")
        console.print()
