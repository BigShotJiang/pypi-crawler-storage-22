"""
nvlogger core logging functions.

This module provides the main logging functions: log, success, info,
warning, error, and debug with beautiful colored output.
"""

from __future__ import annotations

import sys
import traceback
from datetime import datetime
from typing import Any, Optional

from rich.text import Text

from .setup import get_console, get_start_time, get_log_level


# Log level constants
LEVEL_DEBUG = 0
LEVEL_INFO = 1
LEVEL_WARNING = 2
LEVEL_ERROR = 3

# Style configuration for each log level
STYLES = {
    "log": {
        "emoji": "📝",
        "color": "white",
        "level": LEVEL_INFO,
    },
    "success": {
        "emoji": "✅",
        "color": "green",
        "level": LEVEL_INFO,
    },
    "info": {
        "emoji": "ℹ️",
        "color": "blue",
        "level": LEVEL_INFO,
    },
    "warning": {
        "emoji": "⚠️",
        "color": "yellow",
        "level": LEVEL_WARNING,
    },
    "error": {
        "emoji": "❌",
        "color": "red",
        "level": LEVEL_ERROR,
    },
    "debug": {
        "emoji": "🔍",
        "color": "dim",
        "level": LEVEL_DEBUG,
    },
}


def _format_relative_time(start_time: datetime) -> str:
    """
    Format the elapsed time since start as a relative string.
    
    Args:
        start_time: The reference start time.
    
    Returns:
        A human-readable relative time string in Portuguese.
    """
    delta = datetime.now() - start_time
    seconds = int(delta.total_seconds())
    
    if seconds < 1:
        return "agora"
    elif seconds < 60:
        return f"há {seconds}s"
    elif seconds < 3600:
        minutes = seconds // 60
        return f"há {minutes}min"
    else:
        hours = seconds // 3600
        return f"há {hours}h"


def _format_kwargs(kwargs: dict[str, Any]) -> str:
    """
    Format extra keyword arguments for display.
    
    Args:
        kwargs: Dictionary of extra parameters.
    
    Returns:
        Formatted string of key=value pairs.
    """
    if not kwargs:
        return ""
    
    parts = [f"[dim]{k}=[/dim][italic]{v}[/italic]" for k, v in kwargs.items()]
    return " " + " ".join(parts)


def _log_message(
    message: str,
    style_name: str,
    exc_info: bool = False,
    **kwargs: Any,
) -> None:
    """
    Internal function to log a message with the specified style.
    
    Args:
        message: The message to log.
        style_name: The style key (log, success, info, etc.).
        exc_info: If True, include exception traceback.
        **kwargs: Extra parameters to display.
    """
    style = STYLES[style_name]
    
    # Check log level
    if style["level"] < get_log_level():
        return
    
    console = get_console()
    start_time = get_start_time()
    
    # Format timestamp
    timestamp = _format_relative_time(start_time)
    
    # Format extra kwargs
    extras = _format_kwargs(kwargs)
    
    # Build the output
    emoji = style["emoji"]
    color = style["color"]
    
    output = (
        f"[dim]{timestamp:>8}[/dim] "
        f"{emoji} "
        f"[{color}]{message}[/{color}]"
        f"{extras}"
    )
    
    console.print(output)
    
    # Handle exception info
    if exc_info:
        exc_type, exc_value, exc_tb = sys.exc_info()
        if exc_type is not None:
            tb_lines = traceback.format_exception(exc_type, exc_value, exc_tb)
            console.print()
            console.print("[red]" + "".join(tb_lines) + "[/red]")


def log(message: str, **kwargs: Any) -> None:
    """
    Log a generic message.
    
    Args:
        message: The message to log.
        **kwargs: Extra parameters to display (e.g., user="joao").
    
    Example:
        >>> log("Processing started")
        >>> log("User action", user="joao", action="login")
    """
    _log_message(message, "log", **kwargs)


def success(message: str, **kwargs: Any) -> None:
    """
    Log a success message (green with ✅ emoji).
    
    Args:
        message: The success message.
        **kwargs: Extra parameters to display.
    
    Example:
        >>> success("Operation completed successfully!")
        >>> success("File saved", filename="data.json")
    """
    _log_message(message, "success", **kwargs)


def info(message: str, **kwargs: Any) -> None:
    """
    Log an informational message (blue with ℹ️ emoji).
    
    Args:
        message: The info message.
        **kwargs: Extra parameters to display.
    
    Example:
        >>> info("Starting download...")
        >>> info("Connecting to server", host="localhost")
    """
    _log_message(message, "info", **kwargs)


def warning(message: str, **kwargs: Any) -> None:
    """
    Log a warning message (yellow with ⚠️ emoji).
    
    Args:
        message: The warning message.
        **kwargs: Extra parameters to display.
    
    Example:
        >>> warning("Large file detected")
        >>> warning("Slow response", latency_ms=500)
    """
    _log_message(message, "warning", **kwargs)


def error(message: str, exc_info: bool = False, **kwargs: Any) -> None:
    """
    Log an error message (red with ❌ emoji).
    
    Args:
        message: The error message.
        exc_info: If True, include the current exception traceback.
        **kwargs: Extra parameters to display.
    
    Example:
        >>> error("Connection failed")
        >>> try:
        ...     risky_operation()
        ... except Exception:
        ...     error("Operation failed", exc_info=True)
    """
    _log_message(message, "error", exc_info=exc_info, **kwargs)


def debug(message: str, **kwargs: Any) -> None:
    """
    Log a debug message (gray with 🔍 emoji).
    
    Only displayed when log level is DEBUG.
    
    Args:
        message: The debug message.
        **kwargs: Extra parameters to display.
    
    Example:
        >>> debug("Variable state", x=42, y=3.14)
        >>> debug(f"Intermediate value: {result:.2f}")
    """
    _log_message(message, "debug", **kwargs)
