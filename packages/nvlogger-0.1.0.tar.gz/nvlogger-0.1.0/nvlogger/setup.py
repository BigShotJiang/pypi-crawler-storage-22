"""
nvlogger setup and configuration module.

This module provides the setup() function for initializing the logging system.
"""

from __future__ import annotations

import os
from datetime import datetime
from typing import Optional

from rich.console import Console

# Global state
_console: Optional[Console] = None
_start_time: Optional[datetime] = None
_log_level: int = 1  # 0=DEBUG, 1=INFO, 2=WARNING, 3=ERROR

# Log level mapping
LOG_LEVELS = {
    "DEBUG": 0,
    "INFO": 1,
    "WARNING": 2,
    "ERROR": 3,
}


def get_console() -> Console:
    """
    Get the global Console instance.
    
    Returns:
        Console: The rich Console instance used for output.
    
    Raises:
        RuntimeError: If setup() has not been called.
    """
    global _console
    if _console is None:
        # Auto-setup if not initialized
        setup()
    return _console


def get_start_time() -> datetime:
    """
    Get the start time for relative timestamps.
    
    Returns:
        datetime: The time when setup() was called.
    """
    global _start_time
    if _start_time is None:
        _start_time = datetime.now()
    return _start_time


def get_log_level() -> int:
    """
    Get the current log level.
    
    Returns:
        int: The current log level (0=DEBUG, 1=INFO, 2=WARNING, 3=ERROR).
    """
    return _log_level


def setup(
    level: Optional[str] = None,
    force_terminal: Optional[bool] = None,
    no_color: bool = False,
) -> None:
    """
    Configure the nvlogger logging system.
    
    This function initializes the Console and sets up the logging level.
    The log level can be set via the `level` parameter or the NVLOGGER_LEVEL
    environment variable (DEBUG, INFO, WARNING, ERROR).
    
    Args:
        level: Log level string (DEBUG, INFO, WARNING, ERROR).
               Defaults to NVLOGGER_LEVEL env var or INFO.
        force_terminal: Force terminal output even when not a TTY.
        no_color: Disable colored output.
    
    Example:
        >>> from nvlogger import setup
        >>> setup()  # Use defaults
        >>> setup(level="DEBUG")  # Enable debug messages
    """
    global _console, _start_time, _log_level
    
    # Initialize console
    _console = Console(
        force_terminal=force_terminal,
        no_color=no_color,
        highlight=False,
    )
    
    # Set start time for relative timestamps
    _start_time = datetime.now()
    
    # Determine log level
    if level is None:
        level = os.environ.get("NVLOGGER_LEVEL", "INFO").upper()
    else:
        level = level.upper()
    
    _log_level = LOG_LEVELS.get(level, 1)
