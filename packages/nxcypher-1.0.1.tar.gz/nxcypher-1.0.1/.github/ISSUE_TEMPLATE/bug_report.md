---
name: Bug Report
about: Report a bug in nxCypher
title: '[BUG] '
labels: bug
---

## Description

A clear description of what the bug is.

## Cypher Query

```cypher
MATCH (n) RETURN n
```

## Expected Behavior

What you expected to happen.

## Actual Behavior

What actually happened. Include the error message or incorrect output.

## Minimal Reproduction

```python
import networkx as nx
from nxcypher import NXCypher

G = nx.DiGraph()
# ... setup graph ...

result = NXCypher(G).run("YOUR QUERY HERE")
print(result)
```

## Environment

- Python version:
- nxCypher version:
- NetworkX version:
- OS:
