---
name: Feature Request
about: Suggest a new Cypher feature or function
title: '[FEATURE] '
labels: enhancement
---

## Feature Description

A clear description of the feature you'd like to see.

## Cypher Reference

If this is a standard Cypher/OpenCypher feature, link to the relevant documentation:
- Neo4j docs: https://neo4j.com/docs/cypher-manual/current/
- OpenCypher spec: https://opencypher.org/

## Example Query

```cypher
-- Show how the feature would be used
MATCH (n) RETURN newFunction(n.property)
```

## Expected Result

Describe what the query should return.

## Use Case

Why is this feature important for your use case?
