## Description

Brief description of the changes.

## Type of Change

- [ ] Bug fix
- [ ] New feature (Cypher function, clause, etc.)
- [ ] Performance improvement
- [ ] Documentation update
- [ ] Other (describe):

## Checklist

- [ ] All tests pass (`uv run pytest nxcypher/ -v`)
- [ ] Linter passes (`uv run ruff check nxcypher/`)
- [ ] New tests added for new functionality
- [ ] All commits are signed off (DCO: `git commit -s`)

## Testing

Describe how you tested these changes:

```python
# Example test or query used to verify
```
