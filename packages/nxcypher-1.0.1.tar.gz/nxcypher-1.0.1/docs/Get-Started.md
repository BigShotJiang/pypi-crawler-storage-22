# Getting Started

nxCypher is a Python implementation of the [openCypher](https://opencypher.org) graph query language. It enables you to query NetworkX graphs using openCypher syntax.

## Installation

```shell
pip install nxcypher
```

## First Steps

```python
from nxcypher import NXCypher
import networkx as nx

my_graph = nx.read_graphml("my-fun-graph.graphml")

# Get a list of all edges in the graph:
results = NXCypher(my_graph).run("""
MATCH (A)-[]->(B)
RETURN A, B
""")
```
