# nyc_ai_events

Python package that returns a structured list of NYC-based AI events.

## Planned data sources

1. Eventbrite API (requires `EVENTBRITE_TOKEN`)
2. HTML scraping fallback (BeautifulSoup4)
3. AI-driven extraction placeholder (disabled by default)

## Dev quickstart (once Poetry is installed)

- Initialize (src layout): `poetry new nyc_ai_events --src`
- Or initialize in an existing folder: `poetry init`

### Point Poetry to PyPy 3

- `poetry env use pypy3`
- Or: `poetry env use $(command -v pypy3)`

### Install dependencies

- `poetry add requests beautifulsoup4 lxml`
- Dev/test deps: `poetry add --group dev pytest pytest-mock responses`

### Run tests

- `poetry run pytest`

### Build for distribution

- `poetry build`

## CLI

- Poetry: `poetry run nyc-ai-events --limit 10 --source auto`
- Without Poetry (uses this repo's venv Python):
  - `PYTHONPATH=src NYC_AI_EVENTS_ENABLE_SCRAPE=1 ./.venv/bin/python -m nyc_ai_events.cli --source scrape --limit 10`
  - `PYTHONPATH=src NYC_AI_EVENTS_ENABLE_SCRAPE=1 ./.venv/bin/python -m nyc_ai_events.cli --source auto --limit 10`

Note: don’t paste commands where `python` appears as a clickable markdown link like `[python](...)` (that text is not a real executable).

## Install locally in another project (for testing)

### Option A: pip editable

- From the other project: `pip install -e /absolute/path/to/PyPack_EventBrite`

### Option B: poetry add path

- From the other project: `poetry add --editable /absolute/path/to/PyPack_EventBrite`

## Install from PyPI (once published)

- `pip install nyc-ai-events`
- Then run: `nyc-ai-events --limit 10 --source auto`

## Release to PyPI (maintainers)

This repo is set up to publish on git tags like `v0.1.0` via GitHub Actions.

- Create a PyPI account and enable 2FA.
- Create a PyPI API token.
- Add it to this GitHub repo as an Actions secret named `PYPI_API_TOKEN`.
- Push a version tag like `v0.1.0` to publish.

## Public API

- `nyc_ai_events.get_nyc_ai_events()` → `list[dict]` with keys: `name`, `date`, `location`, `link`

## License

MIT (see `LICENSE`).
