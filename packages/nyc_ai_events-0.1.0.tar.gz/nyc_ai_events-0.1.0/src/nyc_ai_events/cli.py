from __future__ import annotations

import argparse
import json
import sys
from typing import Sequence

from nyc_ai_events.providers.eventbrite_api import EventbriteApiProvider, EventbriteNotConfiguredError
from nyc_ai_events.providers.eventbrite_scrape import EventbriteScrapeProvider

from nyc_ai_events.getter import NoSourcesConfiguredError, get_nyc_ai_events


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="nyc-ai-events")
    parser.add_argument("--limit", type=int, default=25)
    parser.add_argument(
        "--source",
        choices=["auto", "api", "scrape"],
        default="auto",
        help="Data source preference.",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)

    try:
        # In auto mode, give a clear configuration error if neither API nor scrape is available.
        if args.source == "auto":
            api_provider = EventbriteApiProvider()
            scrape_provider = EventbriteScrapeProvider()
            api_configured = True
            try:
                api_provider._get_token()
            except EventbriteNotConfiguredError:
                api_configured = False

            if not api_configured and not scrape_provider.enabled():
                raise NoSourcesConfiguredError(
                    "No sources configured: set EVENTBRITE_TOKEN or enable scraping."
                )

        events = get_nyc_ai_events(limit=args.limit, source=args.source)
    except NoSourcesConfiguredError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    print(json.dumps(events, indent=2, sort_keys=True))
    return 0


def cli_entry() -> None:
    raise SystemExit(main())


if __name__ == "__main__":
    cli_entry()
