from __future__ import annotations

from typing import Any

from nyc_ai_events.providers.eventbrite_api import (
    EventbriteApiProvider,
    EventbriteError,
    EventbriteNotConfiguredError,
    EventbriteServerError,
)
from nyc_ai_events.providers.eventbrite_scrape import EventbriteScrapeProvider


class NoSourcesConfiguredError(RuntimeError):
    pass


def get_nyc_ai_events(*, limit: int = 25, source: str = "auto") -> list[dict[str, Any]]:
    """Return a list of NYC-based AI events.

    Output is a list of records:
        {"name": str, "date": str, "location": str, "link": str}
    """
    if limit <= 0:
        raise ValueError("limit must be > 0")

    if source not in {"auto", "api", "scrape"}:
        raise ValueError("source must be one of: auto, api, scrape")

    api_provider = EventbriteApiProvider()
    scrape_provider = EventbriteScrapeProvider()

    events = []

    if source == "api":
        try:
            events = api_provider.search_nyc_ai_events(limit=limit)
            return [e.to_record() for e in events]
        except EventbriteServerError:
            # Best-effort: if Eventbrite API is having an outage, allow scrape fallback.
            if scrape_provider.enabled():
                events = scrape_provider.search_nyc_ai_events(limit=limit)
                return [e.to_record() for e in events]
            raise

    if source == "scrape":
        if not scrape_provider.enabled():
            raise NoSourcesConfiguredError(
                "Scraping is disabled (NYC_AI_EVENTS_ENABLE_SCRAPE=0)."
            )
        events = scrape_provider.search_nyc_ai_events(limit=limit)
        return [e.to_record() for e in events]

    # auto
    api_configured = True
    try:
        events = api_provider.search_nyc_ai_events(limit=limit)
    except EventbriteNotConfiguredError:
        api_configured = False
    except EventbriteError:
        # If API is configured but fails (auth/rate-limit/etc), try scrape fallback.
        pass

    if not events:
        # For library usage, prefer returning an empty list over raising.
        # The CLI uses explicit `--source` modes to validate configuration.
        if scrape_provider.enabled():
            events = scrape_provider.search_nyc_ai_events(limit=limit)

    return [e.to_record() for e in events]
