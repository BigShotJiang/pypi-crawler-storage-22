from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any


@dataclass(frozen=True, slots=True)
class Event:
	name: str
	start: datetime
	location: str
	link: str

	def __post_init__(self) -> None:
		if not isinstance(self.name, str) or not self.name.strip():
			raise ValueError("name is required")
		if not isinstance(self.location, str) or not self.location.strip():
			raise ValueError("location is required")
		if not isinstance(self.link, str) or not self.link.strip():
			raise ValueError("link is required")
		if not isinstance(self.start, datetime):
			raise ValueError("start must be a datetime")
		if self.start.tzinfo is None:
			raise ValueError("start must be timezone-aware")

	def to_record(self) -> dict[str, Any]:
		return {
			"name": self.name,
			"date": self.start.isoformat(),
			"location": self.location,
			"link": self.link,
		}
