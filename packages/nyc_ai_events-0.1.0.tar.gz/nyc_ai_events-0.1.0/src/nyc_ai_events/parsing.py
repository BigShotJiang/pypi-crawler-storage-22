from __future__ import annotations

from datetime import datetime
from zoneinfo import ZoneInfo
from urllib.parse import urlparse, urlunparse

NYC_TZ = ZoneInfo("America/New_York")


def parse_start_datetime(value: str | datetime, tz: ZoneInfo = NYC_TZ) -> datetime:
    """Parse an event start time into a timezone-aware datetime.

    Accepts:
    - datetime (returned as-is)
    - ISO8601 strings, including trailing 'Z'
    - naive 'YYYY-MM-DD HH:MM' treated as tz-local
    """
    if isinstance(value, datetime):
        return value

    if not isinstance(value, str) or not value.strip():
        raise ValueError("datetime string is required")

    text = value.strip()

    # Handle common ISO8601 Zulu suffix.
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"

    # Fast path: fromisoformat handles offsets and many ISO variations.
    try:
        dt = datetime.fromisoformat(text)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=tz)
        return dt
    except ValueError:
        pass

    # Common fallback: 'YYYY-MM-DD HH:MM'
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(text, fmt)
            return dt.replace(tzinfo=tz)
        except ValueError:
            continue

    raise ValueError(f"Unrecognized datetime format: {value!r}")


def normalize_url(value: str) -> str:
    """Normalize a URL.

    - Adds https:// if scheme is missing.
    - Rejects URLs without a network location.
    """
    if not isinstance(value, str) or not value.strip():
        raise ValueError("url is required")

    text = value.strip()

    if any(ch.isspace() for ch in text):
        raise ValueError("url must not contain whitespace")

    # Reject protocol-relative and obvious invalid inputs.
    if text.startswith("//"):
        raise ValueError("url must include a scheme")

    parsed = urlparse(text)
    if not parsed.scheme:
        parsed = urlparse("https://" + text)

    if parsed.scheme not in {"http", "https"}:
        raise ValueError("unsupported url scheme")

    if not parsed.netloc:
        raise ValueError("url must include a host")

    # Normalize: lowercase scheme/host; keep path/query/fragment.
    normalized = parsed._replace(scheme=parsed.scheme.lower(), netloc=parsed.netloc.lower())
    return urlunparse(normalized)
