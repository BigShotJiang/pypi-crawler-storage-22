from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import os
from typing import Any

import requests

from nyc_ai_events.models import Event
from nyc_ai_events.parsing import normalize_url, parse_start_datetime


class EventbriteError(RuntimeError):
    """Base exception for Eventbrite API failures."""


class EventbriteHttpError(EventbriteError):
    def __init__(self, message: str, *, status_code: int, url: str) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.url = url


class EventbriteServerError(EventbriteHttpError):
    pass


class EventbriteNotConfiguredError(EventbriteError):
    pass


class EventbriteAuthError(EventbriteError):
    pass


class EventbriteRateLimitError(EventbriteError):
    pass


@dataclass(frozen=True, slots=True)
class EventbriteApiProvider:
    base_url: str = "https://www.eventbriteapi.com/v3"
    token_env_var: str = "EVENTBRITE_TOKEN"
    timeout_seconds: float = 15.0
    # Eventbrite appears to have migrated search from /events/search/ to /destination/search/.
    search_paths: tuple[str, ...] = ("/destination/search/", "/events/search/")

    def _get_token(self) -> str:
        token = os.getenv(self.token_env_var, "").strip()
        if not token:
            raise EventbriteNotConfiguredError(
                f"Missing {self.token_env_var}; cannot use Eventbrite API"
            )
        return token

    def search_nyc_ai_events(self, *, limit: int = 25) -> list[Event]:
        """Search Eventbrite for AI events in NYC.

        Uses the Eventbrite events search endpoint:
        - GET /events/search/
        - query=AI
        - location.address=New York, NY
        - expand=venue (for better location strings)

        Returns a list of `Event`.
        """
        if limit <= 0:
            raise ValueError("limit must be > 0")

        token = self._get_token()

        urls = [f"{self.base_url}{path}" for path in self.search_paths]
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
        }
        params = {
            "q": "AI",
            "location.address": "New York, NY",
            "location.within": "10mi",
            "page_size": min(limit, 50),
        }

        resp: requests.Response | None = None
        for url in urls:
            # Try GET first.
            resp = requests.get(
                url, headers=headers, params=params, timeout=self.timeout_seconds
            )

            # Some Eventbrite endpoints (notably destination search) may require POST.
            if resp.status_code == 405:
                resp = requests.post(
                    url,
                    headers=headers,
                    data=params,
                    timeout=self.timeout_seconds,
                )

            # If an endpoint truly doesn't exist, try the next one.
            if resp.status_code == 404:
                continue

            break

        assert resp is not None

        if resp.status_code in (401, 403):
            raise EventbriteAuthError("Eventbrite API unauthorized")
        if resp.status_code == 429:
            raise EventbriteRateLimitError("Eventbrite API rate-limited")
        if resp.status_code >= 500:
            raise EventbriteServerError(
                f"Eventbrite API server error: {resp.status_code}",
                status_code=resp.status_code,
                url=resp.url,
            )
        if resp.status_code >= 400:
            raise EventbriteHttpError(
                f"Eventbrite API error: {resp.status_code}",
                status_code=resp.status_code,
                url=resp.url,
            )

        payload: dict[str, Any] = resp.json()
        events_payload = list(_extract_event_items(payload))

        results: list[Event] = []
        for item in events_payload:
            parsed = _event_from_eventbrite_json(item)
            if parsed is not None:
                results.append(parsed)
            if len(results) >= limit:
                break

        return results


def _extract_event_items(payload: dict[str, Any]) -> list[dict[str, Any]]:
    """Extract a list of Event-like dicts from various Eventbrite search payload shapes."""

    def as_event_dict(obj: Any) -> dict[str, Any] | None:
        if isinstance(obj, dict):
            return obj
        return None

    # Common legacy shape.
    events = payload.get("events")
    if isinstance(events, list):
        return [e for e in (as_event_dict(x) for x in events) if e]

    # Destination search sometimes returns `results`.
    results = payload.get("results")
    if isinstance(results, list):
        extracted: list[dict[str, Any]] = []
        for r in results:
            if not isinstance(r, dict):
                continue

            if isinstance(r.get("event"), dict):
                extracted.append(r["event"])
                continue

            if isinstance(r.get("events"), list):
                for e in r["events"]:
                    ev = as_event_dict(e)
                    if ev:
                        extracted.append(ev)
                continue

            # Some APIs nest the payload under `item`.
            if isinstance(r.get("item"), dict):
                extracted.append(r["item"])

        return extracted

    # Fallback: nothing recognized.
    return []


def _event_from_eventbrite_json(item: dict[str, Any]) -> Event | None:
    # Name
    name = ((item.get("name") or {}).get("text") or "").strip()
    if not name:
        return None

    # Link
    link_raw = (item.get("url") or "").strip()
    if not link_raw:
        return None
    link = normalize_url(link_raw)

    # Start datetime
    start_obj = item.get("start") or {}
    start_str = (start_obj.get("utc") or start_obj.get("local") or "").strip()
    if not start_str:
        return None

    start: datetime = parse_start_datetime(start_str)

    # Location
    venue = item.get("venue") or {}
    address = venue.get("address") or {}
    location = (
        (address.get("localized_address_display") or "").strip()
        or ", ".join(
            part
            for part in [
                (address.get("address_1") or "").strip(),
                (address.get("city") or "").strip(),
                (address.get("region") or "").strip(),
            ]
            if part
        )
    )
    if not location:
        location = "New York, NY"

    try:
        return Event(name=name, start=start, location=location, link=link)
    except ValueError:
        # If the data is malformed, skip.
        return None
