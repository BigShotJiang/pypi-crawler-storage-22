from __future__ import annotations

from dataclasses import dataclass
import json
import os
from typing import Iterable

import requests
from bs4 import BeautifulSoup

from nyc_ai_events.models import Event
from nyc_ai_events.parsing import normalize_url, parse_start_datetime


class EventbriteScrapeError(RuntimeError):
    pass


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    text = raw.strip().lower()
    if text in {"1", "true", "yes", "y", "on"}:
        return True
    if text in {"0", "false", "no", "n", "off"}:
        return False
    return default


@dataclass(frozen=True, slots=True)
class EventbriteScrapeProvider:
    """Scrape Eventbrite public pages for AI events in NYC.

    This is a fallback when the API is not configured or fails.
    """

    search_url: str = "https://www.eventbrite.com/d/ny--new-york/ai--events/"
    timeout_seconds: float = 20.0
    enable_env_var: str = "NYC_AI_EVENTS_ENABLE_SCRAPE"

    def enabled(self) -> bool:
        return _env_bool(self.enable_env_var, default=True)

    def search_nyc_ai_events(self, *, limit: int = 25) -> list[Event]:
        if limit <= 0:
            raise ValueError("limit must be > 0")
        if not self.enabled():
            return []

        headers = {
            "Accept": "text/html,application/xhtml+xml",
            "User-Agent": "nyc_ai_events/0.1 (+https://example.invalid)",
        }
        resp = requests.get(self.search_url, headers=headers, timeout=self.timeout_seconds)
        if resp.status_code >= 400:
            raise EventbriteScrapeError(f"scrape fetch failed: {resp.status_code}")

        return parse_eventbrite_search_html(resp.text, limit=limit)


def parse_eventbrite_search_html(html: str, *, limit: int = 25) -> list[Event]:
    """Parse Eventbrite-ish search HTML into Events.

    This parser is intentionally conservative: it extracts only when it can
    find a link + a datetime + a title.
    """
    if limit <= 0:
        raise ValueError("limit must be > 0")

    soup = BeautifulSoup(html, "lxml")

    jsonld_events = _parse_eventbrite_jsonld(soup, limit=limit)
    if jsonld_events:
        return jsonld_events

    cards: Iterable = soup.select("article.event-card")
    if not cards:
        # Try a more generic fallback: any link to an Eventbrite /e/ page.
        cards = soup.select("a[href*='eventbrite.com/e/']")

    results: list[Event] = []

    # Card-shaped parsing
    for card in soup.select("article.event-card"):
        link_el = card.select_one("a[href]")
        time_el = card.select_one("time[datetime]")
        loc_el = card.select_one(".location")

        if not link_el or not time_el:
            continue

        name = (link_el.get_text(" ", strip=True) or "").strip()
        href = (link_el.get("href") or "").strip()
        dt_str = (time_el.get("datetime") or "").strip()
        location = (loc_el.get_text(" ", strip=True) if loc_el else "").strip() or "New York, NY"

        if not name or not href or not dt_str:
            continue

        try:
            event = Event(
                name=name,
                start=parse_start_datetime(dt_str),
                location=location,
                link=normalize_url(href),
            )
        except ValueError:
            continue

        results.append(event)
        if len(results) >= limit:
            return results

    # Generic anchor parsing (last resort within scraping)
    if results:
        return results

    for a in soup.select("a[href*='eventbrite.com/e/']"):
        href = (a.get("href") or "").strip()
        text = (a.get_text(" ", strip=True) or "").strip()
        if not href or not text:
            continue

        # Try to find a nearby datetime.
        time_el = a.find_next("time")
        dt_str = (time_el.get("datetime") if time_el else "") or ""
        dt_str = dt_str.strip()
        if not dt_str:
            continue

        try:
            event = Event(
                name=text,
                start=parse_start_datetime(dt_str),
                location="New York, NY",
                link=normalize_url(href),
            )
        except ValueError:
            continue

        results.append(event)
        if len(results) >= limit:
            break

    return results


def _parse_eventbrite_jsonld(soup: BeautifulSoup, *, limit: int) -> list[Event]:
    """Extract events from JSON-LD blocks.

    Eventbrite search pages commonly embed an ItemList of events via JSON-LD.
    This is significantly more stable than scraping the rendered DOM.
    """

    def iter_json_objects(value: object) -> Iterable[dict]:
        if isinstance(value, dict):
            yield value
            graph = value.get("@graph")
            if isinstance(graph, list):
                for v in graph:
                    yield from iter_json_objects(v)
            return

        if isinstance(value, list):
            for v in value:
                yield from iter_json_objects(v)

    def to_location_string(location: object) -> str:
        if not isinstance(location, dict):
            return "New York, NY"

        place_name = (location.get("name") or "").strip() if isinstance(location.get("name"), str) else ""
        address = location.get("address")
        if not isinstance(address, dict):
            return place_name or "New York, NY"

        locality = (address.get("addressLocality") or "").strip() if isinstance(address.get("addressLocality"), str) else ""
        region = (address.get("addressRegion") or "").strip() if isinstance(address.get("addressRegion"), str) else ""

        parts = [p for p in [locality, region] if p]
        city_state = ", ".join(parts)

        if place_name and city_state:
            return f"{place_name}, {city_state}"
        return place_name or city_state or "New York, NY"

    results: list[Event] = []

    for script in soup.select("script[type='application/ld+json']"):
        text = (script.get_text() or "").strip()
        if not text:
            continue

        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            continue

        for obj in iter_json_objects(data):
            item_list = obj.get("itemListElement")
            if not isinstance(item_list, list):
                continue

            for elem in item_list:
                if not isinstance(elem, dict):
                    continue
                item = elem.get("item")
                if not isinstance(item, dict):
                    continue

                name = (item.get("name") or "").strip() if isinstance(item.get("name"), str) else ""
                href = (item.get("url") or item.get("@id") or "").strip() if isinstance(item.get("url") or item.get("@id"), str) else ""
                start = (item.get("startDate") or "").strip() if isinstance(item.get("startDate"), str) else ""
                location = to_location_string(item.get("location"))

                if not (name and href and start):
                    continue

                try:
                    event = Event(
                        name=name,
                        start=parse_start_datetime(start),
                        location=location,
                        link=normalize_url(href),
                    )
                except ValueError:
                    continue

                results.append(event)
                if len(results) >= limit:
                    return results

    return results
