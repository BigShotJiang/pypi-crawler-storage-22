"""Test suite for oaichat."""
