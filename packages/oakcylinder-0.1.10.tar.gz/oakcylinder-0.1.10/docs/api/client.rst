Client API
==========

The main entry points for interacting with Pinecone services.

Pinecone
--------

Synchronous client for Pinecone operations.

.. autoclass:: pinecone.Pinecone
   :members:
   :show-inheritance:
   :special-members: __init__

**Example:**

.. code-block:: python

   from pinecone import Pinecone

   # With explicit API key
   pc = Pinecone(api_key="your-api-key")

   # Or use PINECONE_API_KEY environment variable
   pc = Pinecone()

   # Use inference
   response = pc.inference.embed(
       model="multilingual-e5-large",
       texts=["Hello world"]
   )

AsyncPinecone
-------------

Asynchronous client for Pinecone operations.

.. autoclass:: pinecone.AsyncPinecone
   :members:
   :show-inheritance:
   :special-members: __init__

**Example:**

.. code-block:: python

   import asyncio
   from pinecone import AsyncPinecone

   async def main():
       async with AsyncPinecone(api_key="your-api-key") as pc:
           response = await pc.inference.embed(
               model="multilingual-e5-large",
               texts=["Hello world"]
           )
           print(f"Generated {len(response.embeddings)} embeddings")

   asyncio.run(main())
