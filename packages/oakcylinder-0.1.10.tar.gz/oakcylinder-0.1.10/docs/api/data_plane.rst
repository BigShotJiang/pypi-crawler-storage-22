Data Plane API
==============

Data plane clients for vector operations on Pinecone indexes.

Index
-----

Synchronous client for data plane operations.

.. autoclass:: pinecone.Index
   :members:
   :show-inheritance:
   :special-members: __init__

**Example:**

.. code-block:: python

   from pinecone import Index

   index = Index(host="my-index-abc123.svc.pinecone.io", api_key="...")

   # Vector operations
   index.upsert(vectors=[{"id": "v1", "values": [0.1, 0.2, 0.3]}])
   results = index.query(vector=[0.1, 0.2, 0.3], top_k=10)

AsyncIndex
----------

Asynchronous client for data plane operations.

.. autoclass:: pinecone.AsyncIndex
   :members:
   :show-inheritance:
   :special-members: __init__

**Example:**

.. code-block:: python

   import asyncio
   from pinecone import AsyncIndex

   async def main():
       async with AsyncIndex(host="my-index-abc123.svc.pinecone.io", api_key="...") as index:
           await index.upsert(vectors=[{"id": "v1", "values": [0.1, 0.2, 0.3]}])
           results = await index.query(vector=[0.1, 0.2, 0.3], top_k=10)

   asyncio.run(main())

Documents Namespace
-------------------

Sub-namespace for document operations with schema-based indexing.

.. autoclass:: pinecone.Documents
   :members:
   :undoc-members:

.. autoclass:: pinecone.AsyncDocuments
   :members:
   :undoc-members:

**Example:**

.. code-block:: python

   # Sync
   response = index.documents.upsert(
       namespace="my-namespace",
       documents=[
           {"_id": "doc1", "title": "Hello world", "my_vector": [0.1, 0.2, 0.3]},
           {"_id": "doc2", "title": "Example", "my_vector": [0.4, 0.5, 0.6]},
       ],
   )

   # Search documents
   results = index.documents.search(
       namespace="my-namespace",
       top_k=10,
       score_by=[{"type": "text", "field": "title", "text_query": "hello"}],
       include_fields=["_id", "title"],
   )

   # Async
   response = await index.documents.upsert(
       namespace="my-namespace",
       documents=[{"_id": "doc1", "title": "Hello"}],
   )

Records Namespace
-----------------

Sub-namespace for records API operations.

.. autoclass:: pinecone.Records
   :members:
   :undoc-members:

.. autoclass:: pinecone.AsyncRecords
   :members:
   :undoc-members:

Namespaces
----------

Sub-namespace for namespace management.

.. autoclass:: pinecone.Namespaces
   :members:
   :undoc-members:

.. autoclass:: pinecone.AsyncNamespaces
   :members:
   :undoc-members:

Bulk Imports
------------

Sub-namespace for bulk import operations.

.. autoclass:: pinecone.BulkImports
   :members:
   :undoc-members:

.. autoclass:: pinecone.AsyncBulkImports
   :members:
   :undoc-members:
