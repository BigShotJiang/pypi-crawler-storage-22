Index Management API
====================

The Index Management API provides operations for creating, configuring, and managing Pinecone indexes.

IndexNamespace
--------------

Synchronous index management operations.

.. autoclass:: pinecone.IndexNamespace
   :members:
   :show-inheritance:
   :special-members: __init__

Methods
^^^^^^^

.. automethod:: pinecone.IndexNamespace.list
.. automethod:: pinecone.IndexNamespace.create
.. automethod:: pinecone.IndexNamespace.configure
.. automethod:: pinecone.IndexNamespace.create_for_model
.. automethod:: pinecone.IndexNamespace.describe
.. automethod:: pinecone.IndexNamespace.delete

AsyncIndexNamespace
-------------------

Asynchronous index management operations.

.. autoclass:: pinecone.AsyncIndexNamespace
   :members:
   :show-inheritance:
   :special-members: __init__

Methods
^^^^^^^

.. automethod:: pinecone.AsyncIndexNamespace.list
.. automethod:: pinecone.AsyncIndexNamespace.create
.. automethod:: pinecone.AsyncIndexNamespace.configure
.. automethod:: pinecone.AsyncIndexNamespace.create_for_model
.. automethod:: pinecone.AsyncIndexNamespace.describe
.. automethod:: pinecone.AsyncIndexNamespace.delete
