Inference API
=============

Pinecone's inference services for embeddings and reranking.

Inference
---------

Synchronous inference operations.

.. autoclass:: pinecone.Inference
   :members:
   :show-inheritance:
   :special-members: __init__

**Embedding Example:**

.. code-block:: python

   from pinecone import Pinecone

   pc = Pinecone(api_key="your-api-key")

   response = pc.inference.embed(
       model="multilingual-e5-large",
       texts=["Hello world", "Goodbye world"],
       parameters={"input_type": "passage", "truncate": "END"}
   )

   for i, embedding in enumerate(response.embeddings):
       print(f"Text {i}: {len(embedding)} dimensions")

**Reranking Example:**

.. code-block:: python

   from pinecone import Pinecone, RerankDocument

   pc = Pinecone(api_key="your-api-key")

   documents = [
       RerankDocument(id="1", text="Pinecone is a vector database"),
       RerankDocument(id="2", text="Python is a programming language"),
   ]

   response = pc.inference.rerank(
       model="bge-reranker-v2-m3",
       query="What is Pinecone?",
       documents=documents,
       top_n=1
   )

   for result in response.results:
       print(f"Document {result.document.id}: score {result.score}")

AsyncInference
--------------

Asynchronous inference operations.

.. autoclass:: pinecone.AsyncInference
   :members:
   :show-inheritance:
   :special-members: __init__

**Async Embedding Example:**

.. code-block:: python

   import asyncio
   from pinecone import AsyncPinecone

   async def main():
       async with AsyncPinecone(api_key="your-api-key") as pc:
           response = await pc.inference.embed(
               model="multilingual-e5-large",
               texts=["Hello world", "Goodbye world"],
               parameters={"input_type": "passage", "truncate": "END"}
           )

           for i, embedding in enumerate(response.embeddings):
               print(f"Text {i}: {len(embedding)} dimensions")

   asyncio.run(main())

**Async Reranking Example:**

.. code-block:: python

   import asyncio
   from pinecone import AsyncPinecone, RerankDocument

   async def main():
       async with AsyncPinecone(api_key="your-api-key") as pc:
           documents = [
               RerankDocument(id="1", text="Pinecone is a vector database"),
               RerankDocument(id="2", text="Python is a programming language"),
           ]

           response = await pc.inference.rerank(
               model="bge-reranker-v2-m3",
               query="What is Pinecone?",
               documents=documents,
               top_n=1
           )

           for result in response.results:
               print(f"Document {result.document.id}: score {result.score}")

   asyncio.run(main())
