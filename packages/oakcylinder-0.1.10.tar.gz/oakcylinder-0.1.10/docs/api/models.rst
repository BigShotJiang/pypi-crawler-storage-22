Data Models
===========

Request and response models for Pinecone API operations. All models are based on ``msgspec.Struct`` for high performance serialization.

Embedding Models
----------------

.. autoclass:: pinecone.EmbedRequest
   :no-index:

   Request model for embedding generation.

   :param str model: Model name (e.g., "multilingual-e5-large")
   :param list inputs: List of text inputs as dicts with "text" key
   :param dict parameters: Optional model parameters (input_type, truncate)

.. autoclass:: pinecone.EmbedResponse
   :no-index:

   Response model for embedding generation.

   :param list data: List of Embedding objects
   :param str model: Model name used
   :param str vector_type: Vector type (e.g., "float32")
   :param Usage usage: Token usage information

.. autoclass:: pinecone.Embedding
   :no-index:

   Single embedding vector.

   :param list values: Embedding values as list of floats
   :param int index: Position index in request

Reranking Models
----------------

.. autoclass:: pinecone.RerankRequest
   :no-index:

   Request model for document reranking.

   :param str model: Reranking model name (e.g., "bge-reranker-v2-m3")
   :param str query: Query text
   :param list documents: List of RerankDocument objects
   :param int top_n: Optional number of top results to return
   :param bool return_documents: Whether to include document text in results (default: False)
   :param dict parameters: Optional model parameters

.. autoclass:: pinecone.RerankResponse
   :no-index:

   Response model for document reranking.

   :param list data: List of RerankResult objects
   :param str model: Model name used
   :param Usage usage: Token usage information

.. autoclass:: pinecone.RerankResult
   :no-index:

   Single reranking result.

   :param int index: Original document index
   :param float score: Relevance score (higher is more relevant)
   :param RerankDocument document: Document object (if return_documents=True)

.. autoclass:: pinecone.RerankDocument
   :no-index:

   Document for reranking.

   :param str text: Document text content
   :param str id: Optional document identifier

Usage Information
-----------------

.. autoclass:: pinecone.Usage
   :no-index:

   Token usage information.

   :param int total_tokens: Total number of tokens used
