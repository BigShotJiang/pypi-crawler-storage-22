Restore Jobs
============

The ``RestoreJobs`` namespace provides read-only access to restore job operations.
Restore jobs are created automatically when restoring an index from a backup.

.. automodule:: pinecone.client.restore_jobs
   :members:
   :undoc-members:
   :show-inheritance:

Async Restore Jobs
------------------

.. automodule:: pinecone.async_client.restore_jobs
   :members:
   :undoc-members:
   :show-inheritance:
