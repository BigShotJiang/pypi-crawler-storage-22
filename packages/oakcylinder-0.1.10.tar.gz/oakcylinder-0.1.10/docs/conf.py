"""Sphinx configuration for Pinecone Python SDK documentation."""

import sys

from pathlib import Path


# Add project root to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

import pinecone


# Project information
project = "Pinecone Python SDK"
author = "Pinecone Systems, Inc."
version = pinecone.__version__
release = version
copyright = "2026, Pinecone Systems, Inc."  # noqa: A001

# General configuration
extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx.ext.viewcode",
    "sphinx.ext.intersphinx",
    "sphinx.ext.doctest",
    "sphinx.ext.coverage",
    "myst_parser",
]

# Template and static paths
templates_path = ["_templates"]
html_static_path = ["_static"]
exclude_patterns = [
    "_build",
    "Thumbs.db",
    ".DS_Store",
    # Exclude individual doc files that are linked from READMEs but not in toctrees
    # (Keep README.md files as they are referenced in the main toctree)
    "architecture/ai-development.md",
    "architecture/api-structure.md",
    "architecture/overview.md",
    "architecture/specifications.md",
    "architecture/verification.md",
    "conventions/api-stability.md",
    "conventions/architecture.md",
    "conventions/async.md",
    "conventions/commit-messages.md",
    "conventions/documentation.md",
    "conventions/errors.md",
    "conventions/http-client.md",
    "conventions/interactive-discovery.md",
    "conventions/linting-formatting.md",
    "conventions/logging.md",
    "conventions/naming.md",
    "conventions/pagination.md",
    "conventions/performance.md",
    "conventions/pull-requests.md",
    "conventions/testing.md",
    "conventions/type-checking.md",
    "conventions/types.md",
    "conventions/usability.md",
    "conventions/validation.md",
    "conventions/versioning.md",
    "development/ci-pipeline.md",
]

# Source file suffixes
source_suffix = {
    ".rst": "restructuredtext",
    ".md": "markdown",
}

# Suppress warnings for cross-references to excluded internal docs
suppress_warnings = [
    "myst.xref_missing",  # Missing cross-references to excluded internal docs
]

# Master document
master_doc = "index"

# Language
language = "en"

# -- Extension Configuration ------------------------------------------------

# Napoleon settings for Google-style docstrings
napoleon_google_docstring = True
napoleon_numpy_docstring = False
napoleon_include_init_with_doc = True
napoleon_include_private_with_doc = False
napoleon_include_special_with_doc = True
napoleon_use_admonition_for_examples = False
napoleon_use_admonition_for_notes = True
napoleon_use_admonition_for_references = False
napoleon_use_ivar = False
napoleon_use_param = True
napoleon_use_rtype = True
napoleon_preprocess_types = True
napoleon_type_aliases = None
napoleon_attr_annotations = True

# Autodoc settings
autodoc_default_options = {
    "members": True,
    "member-order": "bysource",
    "special-members": "__init__",
    "undoc-members": False,
    "exclude-members": "__weakref__",
    "show-inheritance": True,
}
autodoc_typehints = "description"
autodoc_typehints_description_target = "documented"
autodoc_class_signature = "separated"
autodoc_member_order = "bysource"


# Skip internal and protocol modules
def skip_internal_modules(app, what, name, obj, skip, options):
    """Skip internal implementation and protocol modules."""
    if name.startswith("_") and not name.startswith("__"):
        return True
    if "._internal" in str(obj):
        return True
    if ".__interface__" in str(obj):
        return True
    return skip


def setup(app):
    """Sphinx application setup hook."""
    app.connect("autodoc-skip-member", skip_internal_modules)
    app.add_css_file("custom.css")


# Intersphinx mapping to link to other documentation
intersphinx_mapping = {
    "python": ("https://docs.python.org/3", None),
}

# Doctest configuration
doctest_global_setup = """
import os
os.environ["PINECONE_API_KEY"] = "test-api-key"
"""
doctest_test_doctest_blocks = "default"

# Skip async examples that can't run in doctest (await/async with outside functions)
# and other non-executable examples (TAB completion, decorators, etc.)
doctest_default_flags = (
    0
    | __import__("doctest").ELLIPSIS
    | __import__("doctest").NORMALIZE_WHITESPACE
    | __import__("doctest").IGNORE_EXCEPTION_DETAIL
)

# Coverage extension configuration
coverage_show_missing_items = True

# -- HTML Output Configuration ----------------------------------------------

html_theme = "alabaster"
html_theme_options = {
    "logo": "pinecone-logo.svg",
    "description": "Pinecone Python SDK",
    "github_user": "pinecone-io",
    "github_repo": "python-sdk",
    "github_button": True,
    "fixed_sidebar": True,
    "page_width": "1140px",
    "sidebar_width": "300px",
    "show_related": False,
    "show_powered_by": False,
    "extra_nav_links": {
        "Github Source": "https://github.com/pinecone-io/python-sdk",
        "Pinecone Home": "https://pinecone.io",
        "Pinecone Docs": "https://docs.pinecone.io",
        "Pinecone Console": "https://app.pinecone.io",
    },
}

html_title = f"{project} {version}"
html_short_title = project
html_baseurl = "https://sdk.pinecone.io/python"
html_favicon = "_static/favicon-32x32.png"

# Code highlighting
highlight_language = "python"
pygments_style = "sphinx"

# Show source links
html_show_sourcelink = True
html_copy_source = False

# Additional HTML options
html_domain_indices = True
html_use_index = True
html_split_index = False
html_show_sphinx = False
