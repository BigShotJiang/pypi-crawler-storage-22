Pinecone Python SDK Documentation
===================================

The Pinecone Python SDK provides a simple and efficient way to interact with Pinecone's vector database services.

Quick Start
-----------

Install the SDK:

.. code-block:: bash

   pip install pinecone

Basic usage:

.. code-block:: python

   from pinecone import Pinecone

   pc = Pinecone(api_key="your-api-key")

   # Use inference
   response = pc.inference.embed(
       model="multilingual-e5-large",
       texts=["Hello world"],
       parameters={"input_type": "passage", "truncate": "END"}
   )

   print(f"Generated {len(response.embeddings)} embeddings")

Features
--------

- **Sync and Async Support**: Choose between synchronous and asynchronous APIs
- **Type-Safe**: Full type hints for better IDE support and code completion
- **Modern Python**: Supports Python 3.10+
- **Efficient**: Built on httpx with HTTP/2 support and connection pooling
- **Well-Documented**: Comprehensive docstrings and examples

API Reference
-------------

.. toctree::
   :maxdepth: 2
   :caption: API Documentation

   api/client
   api/data_plane
   api/indexes
   api/inference
   api/restore_jobs
   api/models
   api/exceptions

User Guides
-----------

.. toctree::
   :maxdepth: 2
   :caption: Guides

   guides/quickstart
   guides/configuration
   guides/error-handling

Developer Documentation
-----------------------

.. toctree::
   :maxdepth: 1
   :caption: Development

   architecture/README
   conventions/README
   development-workflow

Indices and Tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
