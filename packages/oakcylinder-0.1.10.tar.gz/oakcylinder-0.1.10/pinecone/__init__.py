"""Pinecone Python SDK."""

from typing import Any


__version__ = "0.1.10"

# Core client - always available (lightweight, no heavy imports)
from pinecone._async_client import AsyncPinecone
from pinecone._client import Pinecone
from pinecone.exceptions import (
    APIConnectionError,
    APIError,
    BadRequestError,
    ConfigurationError,
    ConflictError,
    ConnectionError,
    ForbiddenError,
    InvalidAPIKeyError,
    InvalidConfigError,
    NotFoundError,
    PineconeError,
    RateLimitError,
    ServerError,
    TimeoutError,
    UnauthorizedError,
)


# HTTPClient, AsyncHTTPClient, HTTPConfig are now lazy-loaded via __getattr__


# Lazy-loaded namespace classes and models (imported on demand via __getattr__)


def __getattr__(name: str) -> Any:  # noqa: PLR0911, PLR0912
    """Lazy-load namespace classes, models, and HTTP clients on demand.

    This prevents paying import costs for components that aren't used.
    For example, if you only use Inference, you don't pay the cost of
    importing Collections, Indexes, and their models. HTTPClient and related
    classes are also lazy-loaded to avoid importing httpx until needed.
    """
    # HTTP clients (lazy-load to avoid importing httpx until instantiation)
    if name == "HTTPClient":
        from pinecone._internal.http import HTTPClient

        return HTTPClient
    if name == "AsyncHTTPClient":
        from pinecone._internal.http import AsyncHTTPClient

        return AsyncHTTPClient
    if name == "HTTPConfig":
        from pinecone._internal.http import HTTPConfig

        return HTTPConfig

    # Data plane clients
    if name == "Index":
        from pinecone.index import Index

        return Index
    if name == "AsyncIndex":
        from pinecone.async_index import AsyncIndex

        return AsyncIndex

    # Data plane sub-namespace classes
    if name == "AsyncBulkImports":
        from pinecone.async_index.bulk_imports import AsyncBulkImports

        return AsyncBulkImports
    if name == "AsyncDocuments":
        from pinecone.async_index.documents import AsyncDocuments

        return AsyncDocuments
    if name == "AsyncNamespaces":
        from pinecone.async_index.namespaces import AsyncNamespaces

        return AsyncNamespaces
    if name == "AsyncRecords":
        from pinecone.async_index.records import AsyncRecords

        return AsyncRecords
    if name == "BulkImports":
        from pinecone.index.bulk_imports import BulkImports

        return BulkImports
    if name == "Documents":
        from pinecone.index.documents import Documents

        return Documents
    if name == "Namespaces":
        from pinecone.index.namespaces import Namespaces

        return Namespaces
    if name == "Records":
        from pinecone.index.records import Records

        return Records

    # Namespace classes
    if name == "AsyncBackups":
        from pinecone.async_client.backups import AsyncBackups

        return AsyncBackups
    if name == "AsyncCollections":
        from pinecone.async_client.collections import AsyncCollections

        return AsyncCollections
    if name == "AsyncIndexNamespace":
        # Legacy name for backward compatibility
        from pinecone.async_client.indexes_old import AsyncIndexNamespace

        return AsyncIndexNamespace
    if name == "AsyncInference":
        from pinecone.async_client.inference import AsyncInference

        return AsyncInference
    if name == "Backups":
        from pinecone.client.backups import Backups

        return Backups
    if name == "Collections":
        from pinecone.client.collections import Collections

        return Collections
    if name == "IndexNamespace":
        # Legacy name for backward compatibility
        from pinecone.client.indexes_old import IndexNamespaceOld

        return IndexNamespaceOld
    if name == "Inference":
        from pinecone.client.inference import Inference

        return Inference
    if name == "RestoreJobs":
        from pinecone.client.restore_jobs import RestoreJobs

        return RestoreJobs
    if name == "AsyncRestoreJobs":
        from pinecone.async_client.restore_jobs import AsyncRestoreJobs

        return AsyncRestoreJobs

    # Models - import from models package
    if name in {
        "AsyncPaginator",
        "BackupModel",
        "BatchError",
        "BatchResult",
        "ByocSpec",
        "CancelImportResponse",
        "CollectionList",
        "CollectionModel",
        "CreateBackupRequest",
        "CreateCollectionRequest",
        "DataPlaneUsage",
        "DeleteNamespaceResponse",
        "DeleteResponse",
        "DescribeIndexStatsResponse",
        "Document",
        "DocumentSearchResponse",
        "DocumentUpsertResponse",
        "Embedding",
        "EmbedRequest",
        "EmbedResponse",
        "FetchByMetadataResponse",
        "FetchResponse",
        "FieldConfig",
        "Hit",
        "ImportModel",
        "IndexConfig",
        "IndexList",
        "IndexModel",
        "IndexSpec",
        "IndexStatus",
        "IndexedFields",
        "ListImportsResponse",
        "ListItem",
        "ListModelsResponse",
        "ListNamespacesResponse",
        "ListVectorsResponse",
        "ModelInfo",
        "ModelInfoSupportedParameter",
        "NamespaceDescription",
        "NamespaceSchema",
        "NamespaceSummary",
        "Page",
        "Paginator",
        "PodSpec",
        "QueryResponse",
        "RerankDocument",
        "RerankRequest",
        "RerankResponse",
        "RerankResult",
        "RestoreJobModel",
        "SchemaBuilder",
        "ScoredVector",
        "SearchRecordsResponse",
        "SearchUsage",
        "ServerlessReadCapacity",
        "ServerlessReadCapacityDedicated",
        "ServerlessReadCapacityManual",
        "ServerlessReadCapacityStatus",
        "ServerlessSpec",
        "SparseValues",
        "StartImportResponse",
        "UpdateResponse",
        "UpsertResponse",
        "Usage",
        "Vector",
    }:
        from pinecone import models

        return getattr(models, name)

    raise AttributeError(f"module 'pinecone' has no attribute '{name}'")


__all__ = [
    "APIConnectionError",
    "APIError",
    "AsyncBackups",
    "AsyncBulkImports",
    "AsyncCollections",
    "AsyncDocuments",
    "AsyncHTTPClient",
    "AsyncIndex",
    "AsyncIndexNamespace",
    "AsyncInference",
    "AsyncNamespaces",
    "AsyncPaginator",
    "AsyncPinecone",
    "AsyncRecords",
    "AsyncRestoreJobs",
    "BackupModel",
    "Backups",
    "BadRequestError",
    "BatchError",
    "BatchResult",
    "BulkImports",
    "ByocSpec",
    "CancelImportResponse",
    "CollectionList",
    "CollectionModel",
    "Collections",
    "ConfigurationError",
    "ConflictError",
    "ConnectionError",
    "CreateBackupRequest",
    "CreateCollectionRequest",
    "DataPlaneUsage",
    "DeleteNamespaceResponse",
    "DeleteResponse",
    "DescribeIndexStatsResponse",
    "Document",
    "DocumentSearchResponse",
    "DocumentUpsertResponse",
    "Documents",
    "EmbedRequest",
    "EmbedResponse",
    "Embedding",
    "FetchByMetadataResponse",
    "FetchResponse",
    "FieldConfig",
    "ForbiddenError",
    "HTTPClient",
    "HTTPConfig",
    "Hit",
    "ImportModel",
    "Index",
    "IndexConfig",
    "IndexList",
    "IndexModel",
    "IndexNamespace",
    "IndexSpec",
    "IndexStatus",
    "IndexedFields",
    "Inference",
    "InvalidAPIKeyError",
    "InvalidConfigError",
    "ListImportsResponse",
    "ListItem",
    "ListModelsResponse",
    "ListNamespacesResponse",
    "ListVectorsResponse",
    "ModelInfo",
    "ModelInfoSupportedParameter",
    "NamespaceDescription",
    "NamespaceSchema",
    "NamespaceSummary",
    "Namespaces",
    "NotFoundError",
    "Page",
    "Paginator",
    "Pinecone",
    "PineconeError",
    "PodSpec",
    "QueryResponse",
    "RateLimitError",
    "Records",
    "RerankDocument",
    "RerankRequest",
    "RerankResponse",
    "RerankResult",
    "RestoreJobModel",
    "RestoreJobs",
    "SchemaBuilder",
    "ScoredVector",
    "SearchRecordsResponse",
    "SearchUsage",
    "ServerError",
    "ServerlessReadCapacity",
    "ServerlessReadCapacityDedicated",
    "ServerlessReadCapacityManual",
    "ServerlessReadCapacityStatus",
    "ServerlessSpec",
    "SparseValues",
    "StartImportResponse",
    "TimeoutError",
    "UnauthorizedError",
    "UpdateResponse",
    "UpsertResponse",
    "Usage",
    "Vector",
    "__version__",
]
