"""Pinecone SDK protocol definitions.

This package contains protocol definitions that specify the public interface
of the Pinecone SDK. Protocols enable duck typing and allow for multiple
implementations without tight coupling.

All protocols use typing.Protocol with @runtime_checkable for both static
type checking and runtime validation.
"""

# Client protocols
# Backup namespace protocols (includes types)
from pinecone.__interface__.backups import (
    BackupInfoProtocol,
    BackupNamespaceProtocol,
    BackupStatus,
)
from pinecone.__interface__.client import (
    AsyncPineconeProtocol,
    PineconeProtocol,
)

# Collection namespace protocols (includes types)
from pinecone.__interface__.collections import (
    CollectionInfoProtocol,
    CollectionNamespaceProtocol,
    CollectionStatus,
)

# Index protocols (includes data plane types)
from pinecone.__interface__.index import (
    AsyncIndexProtocol,
    DeleteResponseProtocol,
    DescribeIndexStatsResponseProtocol,
    FetchResponseProtocol,
    IndexProtocol,
    Metadata,
    QueryResponseProtocol,
    ScoredVectorProtocol,
    SparseValues,
    UpsertResponseProtocol,
    VectorProtocol,
)

# Index namespace protocols (includes control plane types)
from pinecone.__interface__.indexes import (
    AsyncIndexNamespaceProtocol,
    ByocSpec,
    CloudProviderType,
    IndexConfigProtocol,
    IndexInfoProtocol,
    IndexNamespaceProtocol,
    IndexSpec,
    MetricType,
    PodSpec,
    PodType,
    ServerlessSpec,
)

# Inference namespace protocols (includes types)
from pinecone.__interface__.inference import (
    AsyncInferenceNamespaceProtocol,
    EmbeddingResponseProtocol,
    EmbedParameters,
    InferenceNamespaceProtocol,
    InputType,
    ListModelsResponseProtocol,
    RerankResponseProtocol,
    RerankResultProtocol,
    TruncateMode,
    UsageProtocol,
)

# Restore job namespace protocols (includes types)
from pinecone.__interface__.restore_jobs import (
    AsyncRestoreJobNamespaceProtocol,
    RestoreJobInfoProtocol,
    RestoreJobNamespaceProtocol,
    RestoreJobStatus,
)


__all__ = [
    "AsyncIndexNamespaceProtocol",
    "AsyncIndexProtocol",
    "AsyncInferenceNamespaceProtocol",
    "AsyncPineconeProtocol",
    "AsyncRestoreJobNamespaceProtocol",
    "BackupInfoProtocol",
    "BackupNamespaceProtocol",
    "BackupStatus",
    "ByocSpec",
    "CloudProviderType",
    "CollectionInfoProtocol",
    "CollectionNamespaceProtocol",
    "CollectionStatus",
    "DeleteResponseProtocol",
    "DescribeIndexStatsResponseProtocol",
    "EmbedParameters",
    "EmbeddingResponseProtocol",
    "FetchResponseProtocol",
    "IndexConfigProtocol",
    "IndexInfoProtocol",
    "IndexNamespaceProtocol",
    "IndexProtocol",
    "IndexSpec",
    "InferenceNamespaceProtocol",
    "InputType",
    "ListModelsResponseProtocol",
    "Metadata",
    "MetricType",
    "PineconeProtocol",
    "PodSpec",
    "PodType",
    "QueryResponseProtocol",
    "RerankResponseProtocol",
    "RerankResultProtocol",
    "RestoreJobInfoProtocol",
    "RestoreJobNamespaceProtocol",
    "RestoreJobStatus",
    "ScoredVectorProtocol",
    "ServerlessSpec",
    "SparseValues",
    "TruncateMode",
    "UpsertResponseProtocol",
    "UsageProtocol",
    "VectorProtocol",
]
