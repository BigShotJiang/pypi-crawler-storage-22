"""Backup metadata protocol."""

from typing import Protocol, runtime_checkable

from pinecone.__interface__.backups.types import BackupStatus


@runtime_checkable
class BackupInfoProtocol(Protocol):
    """Protocol for backup metadata.

    Example:
        >>> backups = pc.backups.list()
        >>> for backup in backups:
        ...     print(f"{backup.backup_id}: {backup.status}")
    """

    @property
    def backup_id(self) -> str:
        """Unique backup identifier."""
        ...

    @property
    def source_index_name(self) -> str:
        """Name of the source index."""
        ...

    @property
    def source_index_id(self) -> str:
        """ID of the source index."""
        ...

    @property
    def name(self) -> str | None:
        """Optional user-defined backup name."""
        ...

    @property
    def description(self) -> str | None:
        """Optional backup description."""
        ...

    @property
    def status(self) -> BackupStatus:
        """Current status of the backup (Initializing, Ready, Failed)."""
        ...

    @property
    def cloud(self) -> str:
        """Cloud provider where backup is stored."""
        ...

    @property
    def region(self) -> str:
        """Cloud region where backup is stored."""
        ...

    @property
    def dimension(self) -> int | None:
        """Vector dimensionality (None for sparse indexes)."""
        ...

    @property
    def metric(self) -> str | None:
        """Distance metric used by the index."""
        ...

    @property
    def record_count(self) -> int | None:
        """Total number of records in backup."""
        ...

    @property
    def namespace_count(self) -> int | None:
        """Number of namespaces in backup."""
        ...

    @property
    def size_bytes(self) -> int | None:
        """Backup size in bytes."""
        ...

    @property
    def created_at(self) -> str:
        """ISO 8601 timestamp when backup was created."""
        ...
