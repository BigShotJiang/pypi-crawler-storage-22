"""Type definitions for backup management namespace."""

from typing import Literal


# Backup status
BackupStatus = Literal["Initializing", "Ready", "Failed"]
