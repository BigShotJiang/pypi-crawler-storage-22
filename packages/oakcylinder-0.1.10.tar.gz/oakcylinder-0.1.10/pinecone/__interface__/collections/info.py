"""Collection metadata protocol."""

from typing import Protocol, runtime_checkable

from pinecone.__interface__.collections.types import CollectionStatus


@runtime_checkable
class CollectionInfoProtocol(Protocol):
    """Protocol for collection metadata.

    Example:
        >>> collections = pc.collections.list()
        >>> for coll in collections:
        ...     print(f"{coll.name}: {coll.status}")
    """

    @property
    def name(self) -> str:
        """Collection name."""
        ...

    @property
    def size(self) -> int:
        """Collection size in bytes."""
        ...

    @property
    def status(self) -> CollectionStatus:
        """Collection status."""
        ...

    @property
    def dimension(self) -> int:
        """Vector dimensionality."""
        ...

    @property
    def vector_count(self) -> int:
        """Number of vectors in collection."""
        ...

    @property
    def environment(self) -> str:
        """Environment name."""
        ...
