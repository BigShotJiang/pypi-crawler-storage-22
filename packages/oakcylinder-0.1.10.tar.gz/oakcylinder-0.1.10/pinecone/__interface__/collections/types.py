"""Type definitions for collection management namespace."""

from typing import Literal


# Collection status
CollectionStatus = Literal["Initializing", "Ready", "Terminating"]
