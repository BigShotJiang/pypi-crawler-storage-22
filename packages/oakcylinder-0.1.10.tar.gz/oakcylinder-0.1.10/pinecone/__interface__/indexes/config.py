"""Index configuration protocol."""

from typing import Protocol, runtime_checkable

from pinecone.__interface__.indexes.types import IndexSpec, MetricType


@runtime_checkable
class IndexConfigProtocol(Protocol):
    """Protocol for index configuration data.

    Example:
        >>> config = index_info.config
        >>> print(f"Dimension: {config.dimension}")
        >>> print(f"Metric: {config.metric}")
    """

    @property
    def dimension(self) -> int:
        """Vector dimensionality."""
        ...

    @property
    def metric(self) -> MetricType:
        """Distance metric used."""
        ...

    @property
    def spec(self) -> IndexSpec:
        """Index specification (serverless or pod-based)."""
        ...
