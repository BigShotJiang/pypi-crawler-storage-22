"""Index metadata protocol."""

from typing import Protocol, runtime_checkable

from pinecone.__interface__.indexes.config import IndexConfigProtocol


@runtime_checkable
class IndexInfoProtocol(Protocol):
    """Protocol for index metadata.

    Example:
        >>> for index in pc.indexes.list():
        ...     print(f"Name: {index.name}")
        ...     print(f"Dimension: {index.config.dimension}")
    """

    @property
    def name(self) -> str:
        """Index name."""
        ...

    @property
    def host(self) -> str:
        """Index host URL."""
        ...

    @property
    def config(self) -> IndexConfigProtocol:
        """Index configuration."""
        ...

    @property
    def status(self) -> str:
        """Index status."""
        ...
