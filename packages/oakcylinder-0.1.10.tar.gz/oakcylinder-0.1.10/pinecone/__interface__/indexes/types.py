"""Type definitions for index management namespace."""

from typing import Any, Literal, TypedDict


# Metric types for similarity search
MetricType = Literal["cosine", "euclidean", "dotproduct"]

# Cloud providers
CloudProviderType = Literal["aws", "gcp", "azure"]

# Pod types
PodType = Literal[
    "s1.x1",
    "s1.x2",
    "s1.x4",
    "s1.x8",
    "p1.x1",
    "p1.x2",
    "p1.x4",
    "p1.x8",
    "p2.x1",
    "p2.x2",
    "p2.x4",
    "p2.x8",
]


# Index configuration types
class ServerlessSpec(TypedDict, total=False):
    """Serverless index specification (user input format)."""

    cloud: CloudProviderType
    region: str
    read_capacity: dict[str, Any] | None


class PodSpec(TypedDict, total=False):
    """Pod-based index specification."""

    environment: str
    pod_type: PodType
    pods: int
    replicas: int
    shards: int
    metadata_config: dict[str, Any] | None
    source_collection: str | None


class ByocSpec(TypedDict, total=False):
    """BYOC index specification (user input format)."""

    environment: str
    read_capacity: dict[str, Any] | None


IndexSpec = ServerlessSpec | PodSpec | ByocSpec
