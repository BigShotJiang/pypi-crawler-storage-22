"""Reranking result protocol."""

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class RerankResultProtocol(Protocol):
    """Protocol for a single reranking result.

    Example:
        >>> result = response.results[0]
        >>> print(f"Document {result.index}: score {result.score:.3f}")
        >>> if result.document:
        ...     print(f"Text: {result.document['text']}")
    """

    @property
    def index(self) -> int:
        """Index of the document in the original input list."""
        ...

    @property
    def score(self) -> float:
        """Relevance score indicating how relevant the document is to the query.

        Higher scores indicate more relevance.
        """
        ...

    @property
    def document(self) -> dict[str, Any] | None:
        """Optional document data (if return_documents=True).

        When present, contains a dict with 'text' and 'id' fields.
        """
        ...
