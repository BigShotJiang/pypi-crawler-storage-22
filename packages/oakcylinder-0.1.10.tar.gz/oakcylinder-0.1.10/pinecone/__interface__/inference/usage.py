"""Token usage protocol."""

from typing import Protocol, runtime_checkable


@runtime_checkable
class UsageProtocol(Protocol):
    """Protocol for token usage information.

    Example:
        >>> response = pc.inference.embed(model="multilingual-e5-large", texts=["Hello world"])
        >>> print(f"Tokens used: {response.usage.total_tokens}")
    """

    @property
    def total_tokens(self) -> int | None:
        """Total number of tokens used."""
        ...

    @property
    def read_units(self) -> int | None:
        """Number of read units consumed (for document operations)."""
        ...
