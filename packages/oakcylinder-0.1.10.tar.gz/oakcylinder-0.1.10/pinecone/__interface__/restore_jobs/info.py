"""Restore job information protocol."""

from typing import Protocol, runtime_checkable

from pinecone.__interface__.restore_jobs.types import RestoreJobStatus


@runtime_checkable
class RestoreJobInfoProtocol(Protocol):
    """Protocol for restore job metadata.

    This protocol defines the interface for restore job information objects.
    Restore jobs are created automatically when restoring an index from a backup.

    Attributes:
        restore_job_id: Unique identifier for the restore job.
        backup_id: ID of the backup being restored.
        target_index_name: Name of the index being restored to.
        target_index_id: ID of the target index.
        status: Current status (Pending, InProgress, Completed, Failed).
        created_at: ISO 8601 timestamp when job was created.
        completed_at: ISO 8601 timestamp when job completed (None if in progress).
        percent_complete: Progress percentage (0-100, None if not available).
    """

    restore_job_id: str
    backup_id: str
    target_index_name: str
    target_index_id: str
    status: RestoreJobStatus
    created_at: str
    completed_at: str | None
    percent_complete: float | None
