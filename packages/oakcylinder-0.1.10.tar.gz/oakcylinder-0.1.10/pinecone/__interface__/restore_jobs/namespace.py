"""Restore job management protocol."""

from typing import TYPE_CHECKING, Protocol, runtime_checkable

from pinecone.__interface__.restore_jobs.info import RestoreJobInfoProtocol


if TYPE_CHECKING:
    from pinecone.models.pagination import Paginator


@runtime_checkable
class RestoreJobNamespaceProtocol(Protocol):
    """Protocol for restore job management operations.

    Restore jobs are created automatically when restoring an index from a backup.
    This namespace provides read-only access to monitor restore job progress.

    Example:
        >>> from pinecone import Pinecone
        >>> pc = Pinecone(api_key="...")
        >>>
        >>> # List all restore jobs
        >>> for job in pc.restore_jobs.list():
        ...     print(f"{job.restore_job_id}: {job.status} ({job.percent_complete}%)")
    """

    def list(
        self,
        *,
        limit: int | None = None,
        pagination_token: str | None = None,
    ) -> "Paginator[RestoreJobInfoProtocol]":
        """List all restore jobs in the project.

        Args:
            limit: Maximum number of items to return (across all pages).
            pagination_token: Token to resume pagination from a previous call.

        Returns:
            Paginator over RestoreJobInfo objects. Iterate directly for items,
            or use .pages() for page-level access.

        Example:
            >>> # List all restore jobs
            >>> for job in pc.restore_jobs.list():
            ...     print(f"{job.restore_job_id}: {job.status}")

        Example with pagination:
            >>> for page in pc.restore_jobs.list().pages():
            ...     print(f"Got {len(page.items)} jobs")
        """
        ...

    def describe(self, job_id: str) -> RestoreJobInfoProtocol:
        """Get details of a specific restore job.

        Args:
            job_id: Unique identifier of the restore job.

        Returns:
            RestoreJobInfo with complete job metadata.

        Raises:
            ValueError: If job_id is empty.
            PineconeException: If job not found or operation fails.

        Example:
            >>> job = pc.restore_jobs.describe("670e8400-e29b-41d4-a716-446655440001")
            >>> print(f"Status: {job.status}")
            >>> print(f"Progress: {job.percent_complete}%")
            >>> if job.completed_at:
            ...     print(f"Completed: {job.completed_at}")
        """
        ...
