"""Type definitions for restore job management."""

from enum import Enum


class RestoreJobStatus(str, Enum):
    """Status of a restore job.

    Attributes:
        PENDING: Restore job is pending and has not started yet.
        IN_PROGRESS: Restore job is currently in progress.
        COMPLETED: Restore job has completed successfully.
        FAILED: Restore job has failed.
    """

    PENDING = "Pending"
    IN_PROGRESS = "InProgress"
    COMPLETED = "Completed"
    FAILED = "Failed"
