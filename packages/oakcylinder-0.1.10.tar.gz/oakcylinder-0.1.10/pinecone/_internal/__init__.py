"""Internal implementation layer."""
