"""Adapter for transforming Backup API responses to SDK models.

This adapter provides minimal transformation from raw API responses to typed SDK models.
All transformations are documented to explain why they're needed.
"""

from typing import Any

import msgspec

from pinecone.models.backups import BackupModel


class DescribeBackupAdapter:
    """Adapter for describe_backup operation.

    Transforms raw backup API responses into typed BackupModel.
    """

    def from_response(self, data: dict[str, Any]) -> BackupModel:
        """Transform backup API response to BackupModel.

        Args:
            data: Raw API response dictionary

        Returns:
            Typed BackupModel

        Transformations:
            - Uses msgspec.convert() for forward compatibility with extra fields
            - All fields map directly from API response to model
        """
        # Use msgspec.convert() for forward compatibility - extra fields are ignored
        return msgspec.convert(data, BackupModel)


class ListBackupsAdapter:
    """Adapter for list_backups operation.

    Transforms paginated backup list responses into list of BackupModel.
    """

    def from_response(self, data: dict[str, Any]) -> list[BackupModel]:
        """Transform paginated list response to list of BackupModel.

        Args:
            data: Raw API response dictionary with 'data' field containing list

        Returns:
            List of typed BackupModel objects

        Transformations:
            - Iterates through 'data' array from API response
            - Transforms each item using DescribeBackupAdapter
        """
        describe_adapter = DescribeBackupAdapter()
        return [describe_adapter.from_response(item) for item in data["data"]]


# For backward compatibility, provide BackupsAdapter with old method names
class BackupsAdapter:
    """Legacy adapter for Backup API responses.

    This class is maintained for backward compatibility. New code should use
    the operation-specific adapters (DescribeBackupAdapter, ListBackupsAdapter)
    with the parse_response_with_validation() helper.
    """

    def __init__(self) -> None:
        self._describe_adapter = DescribeBackupAdapter()
        self._list_adapter = ListBackupsAdapter()

    def to_backup_model(self, data: dict[str, Any]) -> BackupModel:
        """Transform backup API response to BackupModel.

        Deprecated: Use DescribeBackupAdapter.from_response() instead.
        """
        return self._describe_adapter.from_response(data)

    def to_backup_list(self, data: dict[str, Any]) -> list[BackupModel]:
        """Transform paginated list response to list of BackupModel.

        Deprecated: Use ListBackupsAdapter.from_response() instead.
        """
        return self._list_adapter.from_response(data)


# Adapter instances for use with parse_response_with_validation()
describe_backup_adapter = DescribeBackupAdapter()
list_backups_adapter = ListBackupsAdapter()
