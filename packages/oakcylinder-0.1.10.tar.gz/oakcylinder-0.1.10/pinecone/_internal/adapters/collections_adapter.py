"""Adapter for transforming Collections API responses to SDK models.

This adapter provides minimal transformation from raw API responses to typed SDK models.
All transformations are documented to explain why they're needed.
"""

from typing import Any

import msgspec

from pinecone.models.collections import CollectionList, CollectionModel


class DescribeCollectionAdapter:
    """Adapter for describe_collection operation.

    Transforms raw collection API responses into typed CollectionModel.
    """

    def from_response(self, data: dict[str, Any]) -> CollectionModel:
        """Transform collection API response to CollectionModel.

        Args:
            data: Raw API response dictionary

        Returns:
            Typed CollectionModel

        Transformations:
            - Uses msgspec.convert() for forward compatibility with extra fields
            - All fields map directly from API response to model
        """
        # Use msgspec.convert() for forward compatibility - extra fields are ignored
        return msgspec.convert(data, CollectionModel)


class ListCollectionsAdapter:
    """Adapter for list_collections operation.

    Transforms raw collection list API responses into typed CollectionList.
    """

    def from_response(self, data: dict[str, Any]) -> CollectionList:
        """Transform list collections API response to CollectionList model.

        Args:
            data: Raw API response dictionary

        Returns:
            Typed CollectionList model

        Transformations:
            - Wraps collection data in CollectionModel objects
            - Preserves all collection metadata from API response
        """
        describe_adapter = DescribeCollectionAdapter()
        collections = [describe_adapter.from_response(item) for item in data["collections"]]

        return CollectionList(collections=collections)


# For backward compatibility, provide CollectionsAdapter with old method names
class CollectionsAdapter:
    """Legacy adapter for Collections API responses.

    This class is maintained for backward compatibility. New code should use
    the operation-specific adapters (DescribeCollectionAdapter, ListCollectionsAdapter)
    with the parse_response_with_validation() helper.
    """

    def __init__(self) -> None:
        self._describe_adapter = DescribeCollectionAdapter()
        self._list_adapter = ListCollectionsAdapter()

    def to_collection_model(self, data: dict[str, Any]) -> CollectionModel:
        """Transform collection API response to CollectionModel.

        Deprecated: Use DescribeCollectionAdapter.from_response() instead.
        """
        return self._describe_adapter.from_response(data)

    def to_collection_list(self, data: dict[str, Any]) -> CollectionList:
        """Transform list collections API response to CollectionList model.

        Deprecated: Use ListCollectionsAdapter.from_response() instead.
        """
        return self._list_adapter.from_response(data)


# Adapter instances for use with parse_response_with_validation()
describe_collection_adapter = DescribeCollectionAdapter()
list_collections_adapter = ListCollectionsAdapter()
