"""Adapter for configure_index operation (2026-01.alpha API)."""

from __future__ import annotations

from typing import Any

import msgspec

from pinecone.models.indexes import ConfigureIndexRequest, IndexModel


class ConfigureIndexAdapter:
    """Adapter for configure_index operation.

    Transforms ConfigureIndexRequest to API JSON and parses API responses to IndexModel.
    Uses msgspec for fast serialization/deserialization with type validation.
    """

    def to_request(self, request: ConfigureIndexRequest) -> bytes:
        """Convert ConfigureIndexRequest to API JSON bytes.

        Uses msgspec for fast serialization.

        Args:
            request: ConfigureIndexRequest model

        Returns:
            JSON bytes ready to send in HTTP request body

        Example:
            >>> from pinecone.models.indexes import ConfigureIndexRequest
            >>> request = ConfigureIndexRequest(deletion_protection="enabled")
            >>> adapter = ConfigureIndexAdapter()
            >>> json_bytes = adapter.to_request(request)
            >>> # Send json_bytes in HTTP PATCH body
        """
        encoder = msgspec.json.Encoder()
        return encoder.encode(request)

    def from_response(self, response_dict: dict[str, Any]) -> IndexModel:
        """Parse API response JSON to IndexModel.

        Uses msgspec for fast deserialization with automatic type validation.

        Args:
            response_dict: Dictionary from orjson.loads()

        Returns:
            IndexModel instance with updated configuration

        Raises:
            msgspec.ValidationError: If response doesn't match IndexModel schema

        Example:
            >>> response = requests.patch(...)
            >>> response_dict = orjson.loads(response.content)
            >>> adapter = ConfigureIndexAdapter()
            >>> index = adapter.from_response(response_dict)
            >>> print(f"Updated: {index.name}")
        """
        return msgspec.convert(response_dict, IndexModel)


# For backward compatibility, expose adapter instance
configure_adapter = ConfigureIndexAdapter()

__all__ = ["ConfigureIndexAdapter", "configure_adapter"]
