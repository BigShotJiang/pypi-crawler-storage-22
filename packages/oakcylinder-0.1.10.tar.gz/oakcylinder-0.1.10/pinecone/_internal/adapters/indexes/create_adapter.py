"""Adapter for create_index operation (2026-01.alpha API)."""

from __future__ import annotations

from typing import Any

import msgspec
import orjson

from pinecone.models.indexes import CreateIndexRequest, IndexModel


class CreateIndexAdapter:
    """Adapter for create_index operation.

    Transforms CreateIndexRequest to API JSON and parses API responses to IndexModel.
    Uses msgspec for fast serialization/deserialization with type validation.
    """

    def to_request(self, request: CreateIndexRequest) -> bytes:
        """Convert CreateIndexRequest to API JSON bytes.

        Uses msgspec to convert to dict, then orjson for fast serialization.
        Fields with None values are omitted from the serialized JSON
        (the API expects fields to be absent, not null).

        Args:
            request: CreateIndexRequest model

        Returns:
            JSON bytes ready to send in HTTP request body

        Example:
            >>> from pinecone.models.indexes import CreateIndexRequest, Schema, DenseVectorField
            >>> request = CreateIndexRequest(
            ...     schema=Schema(fields={"embedding": DenseVectorField(...)}), name="my-index"
            ... )
            >>> adapter = CreateIndexAdapter()
            >>> json_bytes = adapter.to_request(request)
            >>> # Send json_bytes in HTTP POST body
        """
        # Convert to dict (msgspec handles nested structs)
        request_dict = msgspec.to_builtins(request)

        def filter_none_and_defaults(obj: Any) -> Any:
            """Recursively filter None values and False booleans from dicts.

            The API expects optional fields to be omitted entirely, not sent as null or false.
            """
            if isinstance(obj, dict):
                return {
                    k: filter_none_and_defaults(v)
                    for k, v in obj.items()
                    if v is not None and v is not False
                }
            if isinstance(obj, list):
                return [filter_none_and_defaults(item) for item in obj]
            return obj

        filtered_dict = filter_none_and_defaults(request_dict)
        return orjson.dumps(filtered_dict)

    def from_response(self, response_dict: dict[str, Any]) -> IndexModel:
        """Parse API response JSON to IndexModel.

        Uses msgspec for fast deserialization with automatic type validation.

        Args:
            response_dict: Dictionary from orjson.loads()

        Returns:
            IndexModel instance

        Raises:
            msgspec.ValidationError: If response doesn't match IndexModel schema

        Example:
            >>> response = requests.post(...)
            >>> response_dict = orjson.loads(response.content)
            >>> adapter = CreateIndexAdapter()
            >>> index = adapter.from_response(response_dict)
            >>> print(f"Created: {index.name}")
        """
        return msgspec.convert(response_dict, IndexModel)


# For backward compatibility, expose adapter instance
create_adapter = CreateIndexAdapter()

__all__ = ["CreateIndexAdapter", "create_adapter"]
