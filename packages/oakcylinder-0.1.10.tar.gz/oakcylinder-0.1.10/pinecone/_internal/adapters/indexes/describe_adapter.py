"""Adapter for describe_index operation (2026-01.alpha API)."""

from __future__ import annotations

from typing import Any

import msgspec

from pinecone.models.indexes import IndexModel


class DescribeIndexAdapter:
    """Adapter for describe_index operation.

    Parses API responses to IndexModel.
    Uses msgspec for fast deserialization with type validation.
    """

    def from_response(self, response_dict: dict[str, Any]) -> IndexModel:
        """Parse API response JSON to IndexModel.

        Uses msgspec for fast deserialization with automatic type validation.

        Args:
            response_dict: Dictionary from orjson.loads()

        Returns:
            IndexModel instance

        Raises:
            msgspec.ValidationError: If response doesn't match IndexModel schema

        Example:
            >>> response = requests.get(...)
            >>> response_dict = orjson.loads(response.content)
            >>> adapter = DescribeIndexAdapter()
            >>> index = adapter.from_response(response_dict)
            >>> print(f"{index.name}: {len(index.schema.fields)} fields")
        """
        return msgspec.convert(response_dict, IndexModel)


# For backward compatibility, expose adapter instance
describe_adapter = DescribeIndexAdapter()

__all__ = ["DescribeIndexAdapter", "describe_adapter"]
