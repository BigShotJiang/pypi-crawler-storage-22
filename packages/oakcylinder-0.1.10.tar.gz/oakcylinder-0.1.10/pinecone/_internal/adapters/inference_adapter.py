"""Adapter for transforming Inference API responses to SDK models.

This adapter provides minimal transformation from raw API responses to typed SDK models.
All transformations are documented to explain why they're needed.
"""

from typing import Any

import msgspec

from pinecone.models.inference import (
    EmbedResponse,
    ListModelsResponse,
    RerankResponse,
)


class EmbedAdapter:
    """Adapter for embed operation.

    Transforms raw embed API responses into typed EmbedResponse models.
    """

    def from_response(self, data: dict[str, Any]) -> EmbedResponse:
        """Transform embed API response to EmbedResponse model.

        Args:
            data: Raw API response dictionary

        Returns:
            Typed EmbedResponse model

        Transformations:
            - Adds index field to each embedding (API doesn't include this)
            - Uses msgspec.convert() for forward compatibility with extra fields
        """
        # Pre-process: Add index to each embedding (API doesn't include this field)
        data_with_indices = data.copy()
        data_with_indices["data"] = [{**item, "index": i} for i, item in enumerate(data["data"])]

        # Default vector_type to "dense" for backwards compatibility if not present
        if "vector_type" not in data_with_indices:
            data_with_indices["vector_type"] = "dense"

        # Use msgspec.convert() for forward compatibility - extra fields are ignored
        return msgspec.convert(data_with_indices, EmbedResponse)


class RerankAdapter:
    """Adapter for rerank operation.

    Transforms raw rerank API responses into typed RerankResponse models.
    """

    def from_response(self, data: dict[str, Any]) -> RerankResponse:
        """Transform rerank API response to RerankResponse model.

        Args:
            data: Raw API response dictionary

        Returns:
            Typed RerankResponse model

        Transformations:
            - Normalizes usage.rerank_units to usage.total_tokens for consistency
            - Uses msgspec.convert() for forward compatibility with extra fields
        """
        # Pre-process: Normalize usage field (API returns "rerank_units", SDK expects "total_tokens")
        data_normalized = data.copy()
        if "usage" in data_normalized:
            usage_data = data_normalized["usage"].copy()
            # If API returns rerank_units instead of total_tokens, normalize it
            if "rerank_units" in usage_data and "total_tokens" not in usage_data:
                usage_data["total_tokens"] = usage_data.get("rerank_units", 0)
            data_normalized["usage"] = usage_data

        # Use msgspec.convert() for forward compatibility - extra fields are ignored
        return msgspec.convert(data_normalized, RerankResponse)


class ListModelsAdapter:
    """Adapter for list_models operation.

    Transforms raw list models API responses into typed ListModelsResponse models.
    """

    def from_response(self, data: dict[str, Any]) -> ListModelsResponse:
        """Transform list models API response to ListModelsResponse model.

        Args:
            data: Raw API response dictionary

        Returns:
            Typed ListModelsResponse model

        Transformations:
            - Uses msgspec.convert() for forward compatibility with extra fields
            - Nested structures (ModelInfo, ModelInfoSupportedParameter) are automatically parsed
        """
        # Use msgspec.convert() for forward compatibility - extra fields are ignored
        # msgspec automatically handles nested structures (ModelInfo, ModelInfoSupportedParameter)
        return msgspec.convert(data, ListModelsResponse)


# For backward compatibility, provide InferenceAdapter with old method names
class InferenceAdapter:
    """Legacy adapter for Inference API responses.

    This class is maintained for backward compatibility. New code should use
    the operation-specific adapters (EmbedAdapter, RerankAdapter, ListModelsAdapter)
    with the parse_response_with_validation() helper.
    """

    def __init__(self) -> None:
        self._embed_adapter = EmbedAdapter()
        self._rerank_adapter = RerankAdapter()
        self._list_models_adapter = ListModelsAdapter()

    def to_embed_response(self, data: dict[str, Any]) -> EmbedResponse:
        """Transform embed API response to EmbedResponse model.

        Deprecated: Use EmbedAdapter.from_response() instead.
        """
        return self._embed_adapter.from_response(data)

    def to_rerank_response(self, data: dict[str, Any]) -> RerankResponse:
        """Transform rerank API response to RerankResponse model.

        Deprecated: Use RerankAdapter.from_response() instead.
        """
        return self._rerank_adapter.from_response(data)

    def to_list_models_response(self, data: dict[str, Any]) -> ListModelsResponse:
        """Transform list models API response to ListModelsResponse model.

        Deprecated: Use ListModelsAdapter.from_response() instead.
        """
        return self._list_models_adapter.from_response(data)


# Adapter instances for use with parse_response_with_validation()
embed_adapter = EmbedAdapter()
rerank_adapter = RerankAdapter()
list_models_adapter = ListModelsAdapter()
