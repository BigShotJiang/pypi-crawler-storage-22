"""Adapter for transforming Restore Job API responses to SDK models.

This adapter provides minimal transformation from raw API responses to typed SDK models.
All transformations are documented to explain why they're needed.
"""

from typing import Any

import msgspec

from pinecone.models.restore_jobs import RestoreJobModel


class DescribeRestoreJobAdapter:
    """Adapter for describe_restore_job operation.

    Transforms raw restore job API responses into typed RestoreJobModel.
    """

    def from_response(self, data: dict[str, Any]) -> RestoreJobModel:
        """Transform restore job API response to RestoreJobModel.

        Args:
            data: Raw API response dictionary

        Returns:
            Typed RestoreJobModel

        Transformations:
            - Convert to model with msgspec (10-30x faster than manual construction)
        """
        return msgspec.convert(data, RestoreJobModel)


class ListRestoreJobsAdapter:
    """Adapter for list_restore_jobs operation.

    Transforms paginated restore job list responses into list of RestoreJobModel.
    """

    def from_response(self, data: dict[str, Any]) -> list[RestoreJobModel]:
        """Transform paginated list response to list of RestoreJobModel.

        Args:
            data: Raw API response dictionary containing paginated list

        Returns:
            List of typed RestoreJobModel objects

        Transformations:
            - Extract 'data' array from response
            - Convert each item using msgspec (10-30x faster than manual construction)
        """
        items = data.get("data", [])
        return [msgspec.convert(item, RestoreJobModel) for item in items]


# For backward compatibility, provide RestoreJobsAdapter with old method names
class RestoreJobsAdapter:
    """Legacy adapter for Restore Job API responses.

    This class is maintained for backward compatibility. New code should use
    the operation-specific adapters (DescribeRestoreJobAdapter, ListRestoreJobsAdapter)
    with the parse_response_with_validation() helper.
    """

    def __init__(self) -> None:
        self._describe_adapter = DescribeRestoreJobAdapter()
        self._list_adapter = ListRestoreJobsAdapter()

    def to_restore_job_model(self, data: dict[str, Any]) -> RestoreJobModel:
        """Transform restore job API response to RestoreJobModel.

        Deprecated: Use DescribeRestoreJobAdapter.from_response() instead.
        """
        return self._describe_adapter.from_response(data)

    def to_restore_job_list(self, data: dict[str, Any]) -> list[RestoreJobModel]:
        """Transform paginated list response to list of RestoreJobModel.

        Deprecated: Use ListRestoreJobsAdapter.from_response() instead.
        """
        return self._list_adapter.from_response(data)


# Adapter instances for use with parse_response_with_validation()
describe_restore_job_adapter = DescribeRestoreJobAdapter()
list_restore_jobs_adapter = ListRestoreJobsAdapter()
