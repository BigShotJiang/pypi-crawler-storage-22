"""Synchronous OAuth token manager for service account authentication.

This module provides thread-safe token exchange and caching using the OAuth 2.0
client credentials flow.
"""

from __future__ import annotations

import threading
import time

from typing import Any

import httpx
import orjson

from pinecone._internal.logging import get_logger


logger = get_logger(__name__)


class TokenManager:
    """Manages OAuth token exchange and caching with thread-safe access.

    Automatically exchanges client credentials for access tokens and caches them
    with expiry tracking. Uses double-checked locking for performance: fast path
    checks validity without acquiring lock, slow path acquires lock only when
    refresh is needed.

    Security features:
        - HTTPS-only token endpoint (validated at initialization)
        - No credentials in error messages or logs
        - Explicit clear() method for token cleanup
        - Token refresh margin prevents edge-case expiry

    Args:
        client_id: OAuth client ID (service account)
        client_secret: OAuth client secret (service account)
        token_url: OAuth token endpoint (must use HTTPS)
        refresh_margin_seconds: Refresh token N seconds before expiry.
            Default: 300 (5 minutes)

    Raises:
        ValueError: If token_url doesn't use HTTPS

    Example:
        >>> manager = TokenManager(
        ...     client_id="client-id",
        ...     client_secret="client-secret",
        ...     token_url="https://auth.pinecone.io/oauth/token",
        ... )
        >>> token = manager.get_token()  # Exchange credentials
        >>> token2 = manager.get_token()  # Cached, no exchange
        >>> manager.clear()  # Clean up
    """

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        token_url: str,
        refresh_margin_seconds: int = 300,
    ):
        """Initialize token manager with OAuth credentials.

        Args:
            client_id: OAuth client ID
            client_secret: OAuth client secret
            token_url: OAuth token endpoint (must use HTTPS)
            refresh_margin_seconds: Refresh token N seconds before expiry

        Raises:
            ValueError: If token_url doesn't use HTTPS
        """
        # Security: Validate HTTPS
        if not token_url.startswith("https://"):
            raise ValueError("token_url must use HTTPS for security")

        self._client_id = client_id
        self._client_secret = client_secret
        self._token_url = token_url
        self._refresh_margin = refresh_margin_seconds

        # Token cache
        self._cached_token: str | None = None
        self._token_expiry: float | None = None

        # Thread safety
        self._lock = threading.Lock()

        # HTTP client for token requests
        self._http_client: httpx.Client | None = httpx.Client(
            http2=True,
            timeout=httpx.Timeout(30.0),
        )

    def get_token(self) -> str:
        """Get valid access token, refreshing if needed.

        Uses double-checked locking for performance:
        - Fast path: Check validity without lock (common case, minimal contention)
        - Slow path: Acquire lock and recheck before refresh (rare case)

        Returns:
            Valid access token

        Raises:
            ValueError: If OAuth authentication fails
            RuntimeError: If HTTP client has been closed
        """
        # Fast path: check without lock (reduces contention)
        # Capture token atomically to avoid race with clear()
        cached_token = self._cached_token
        if cached_token is not None and self._is_token_valid():
            return cached_token

        # Slow path: acquire lock and recheck
        with self._lock:
            # Recheck after acquiring lock (another thread may have refreshed)
            if self._is_token_valid():
                return self._cached_token  # type: ignore[return-value]

            return self._refresh_token()

    def _is_token_valid(self) -> bool:
        """Check if cached token is valid with safety margin.

        Returns:
            True if token exists and hasn't expired (with margin)
        """
        if not self._cached_token or not self._token_expiry:
            return False

        # Check if token is still valid (with margin)
        return time.time() < (self._token_expiry - self._refresh_margin)

    def _refresh_token(self) -> str:
        """Exchange credentials for new access token.

        IMPORTANT: Must be called with lock held.

        Makes POST request to token endpoint with client_credentials grant type.
        Never logs credentials or tokens.

        Returns:
            Fresh access token

        Raises:
            ValueError: If OAuth authentication fails
            RuntimeError: If HTTP client has been closed
        """
        if self._http_client is None:
            raise RuntimeError("TokenManager has been closed. Create a new instance.")

        logger.debug("Refreshing OAuth token")

        try:
            # Prepare OAuth request
            # Using form-urlencoded as per OAuth 2.0 spec
            response = self._http_client.post(
                self._token_url,
                data={
                    "grant_type": "client_credentials",
                    "client_id": self._client_id,
                    "client_secret": self._client_secret,
                },
                headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                },
            )

            # Check response
            if response.status_code != 200:
                # Security: Don't include credentials in error message
                logger.error(
                    "OAuth token exchange failed",
                    status_code=response.status_code,
                )
                raise ValueError(
                    f"OAuth authentication failed with status {response.status_code}. "
                    "Check your client_id and client_secret."
                )

            # Parse response
            data = orjson.loads(response.content)
            access_token = data.get("access_token")
            expires_in = data.get("expires_in", 3600)  # Default 1 hour

            if not access_token or not isinstance(access_token, str):
                raise ValueError("OAuth response missing access_token field")

            # Type narrowed to str by isinstance check above
            assert isinstance(access_token, str)  # For mypy

            # Cache token and calculate expiry
            self._cached_token = access_token
            self._token_expiry = time.time() + float(expires_in)

            logger.debug(
                "OAuth token refreshed successfully",
                expires_in=expires_in,
            )

            return access_token  # noqa: TRY300

        except httpx.HTTPError as e:
            # Security: Don't include credentials in error message
            logger.exception("OAuth token exchange failed due to network error")
            raise ValueError(
                "OAuth authentication failed due to network error. "
                "Check your connection and token_url."
            ) from e

    def clear(self) -> None:
        """Clear cached token from memory.

        Called by Admin.close() to ensure tokens are cleaned up when client
        is no longer needed. This is important for security.

        Example:
            >>> manager = TokenManager(...)
            >>> token = manager.get_token()
            >>> manager.clear()  # Token removed from memory
            >>> token2 = manager.get_token()  # Will exchange for fresh token
        """
        with self._lock:
            self._cached_token = None
            self._token_expiry = None
        logger.debug("OAuth token cleared from cache")

    def close(self) -> None:
        """Close HTTP client and clean up resources.

        After calling close(), the TokenManager cannot be used again.
        Create a new instance if you need to continue making token requests.
        """
        self.clear()  # Clear token first
        if self._http_client is not None:
            self._http_client.close()
            self._http_client = None

    def __enter__(self) -> TokenManager:
        """Enter context manager."""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit context manager and clean up resources."""
        self.close()
