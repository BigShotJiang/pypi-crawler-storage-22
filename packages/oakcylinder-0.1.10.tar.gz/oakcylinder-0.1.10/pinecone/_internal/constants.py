"""Internal constants used across the SDK.

This module contains shared constants that are used by multiple components
but are not part of the public API.
"""

# API version used in X-Pinecone-Api-Version header for Inference API
INFERENCE_API_VERSION = "2025-10"

# API version used in X-Pinecone-Api-Version header for Control Plane API.
# This applies to backups, indexes, and collections endpoints.
CONTROL_PLANE_API_VERSION = "2025-10"

# API version used in X-Pinecone-Api-Version header for Index management API (legacy)
INDEXES_API_VERSION_OLD = "2025-10"  # For indexes_old namespace
INDEXES_API_VERSION = "2025-10"  # Kept for backward compatibility, will be updated

# API version for new schema-driven indexes (2026-01.alpha)
INDEXES_API_VERSION_ALPHA = "2026-01.alpha"

# API version used in X-Pinecone-Api-Version header for Data Plane API
DATA_PLANE_API_VERSION = "2025-10"

# API version used in X-Pinecone-Api-Version header for Documents API
DOCUMENTS_API_VERSION = "2026-01.alpha"

# Pre-built header dicts for data plane requests, avoiding per-request allocation
DATA_PLANE_HEADERS: dict[str, str] = {
    "X-Pinecone-Api-Version": DATA_PLANE_API_VERSION,
}

DOCUMENTS_HEADERS: dict[str, str] = {
    "X-Pinecone-Api-Version": DOCUMENTS_API_VERSION,
}

NDJSON_HEADERS: dict[str, str] = {
    "X-Pinecone-Api-Version": DATA_PLANE_API_VERSION,
    "Content-Type": "application/x-ndjson",
}

# API version used in X-Pinecone-Api-Version header for Admin API
ADMIN_API_VERSION = "2025-10"

# Default timeout in seconds for HTTP requests
DEFAULT_TIMEOUT = 30

# User-Agent source tag field name (for partner integrations)
SOURCE_TAG = "source_tag"
