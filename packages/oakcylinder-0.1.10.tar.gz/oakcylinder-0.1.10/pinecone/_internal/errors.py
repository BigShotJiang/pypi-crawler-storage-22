"""Error handling utilities for consistent error wrapping across namespaces."""

from __future__ import annotations

from typing import overload

from pinecone.exceptions import (
    APIConnectionError,
    APIError,
    BadRequestError,
    ConflictError,
    ConnectionError as PineconeConnectionError,
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError as PineconeTimeoutError,
    UnauthorizedError,
)


@overload
def wrap_api_error(error: APIError, operation: str) -> APIError: ...


@overload
def wrap_api_error(error: APIConnectionError, operation: str) -> APIConnectionError: ...


def wrap_api_error(  # noqa: PLR0911
    error: APIError | APIConnectionError, operation: str
) -> APIError | APIConnectionError:
    """Wrap an API error with operation context while preserving exception type.

    This utility adds operation context to error messages while preserving:
    - Original exception type and hierarchy
    - All exception metadata (retry_after, status_code, etc.)
    - Exception chaining (via raise ... from e)

    Args:
        error: The original API error to wrap
        operation: Operation context (e.g., "Collections.create", "Inference.embed")

    Returns:
        New exception instance of same type with enhanced message

    Example:
        >>> try:
        ...     response = self._http.get(...)
        ... except APIError as e:
        ...     raise wrap_api_error(e, "Collections.list") from e
    """
    # Enhance message with operation context
    enhanced_message = f"{operation} failed: {error.message}"

    # Preserve exception type and all metadata
    if isinstance(error, RateLimitError):
        return RateLimitError(
            retry_after=error.retry_after,
            message=enhanced_message,
            response_body=error.response_body,
            request_id=error.request_id,
            error_code=error.error_code,
            url=error.url,
            method=error.method,
        )
    if isinstance(error, BadRequestError):
        return BadRequestError(
            message=enhanced_message,
            response_body=error.response_body,
            request_id=error.request_id,
            error_code=error.error_code,
            url=error.url,
            method=error.method,
        )
    if isinstance(error, UnauthorizedError):
        return UnauthorizedError(
            message=enhanced_message,
            response_body=error.response_body,
            request_id=error.request_id,
            error_code=error.error_code,
            url=error.url,
            method=error.method,
        )
    if isinstance(error, ForbiddenError):
        return ForbiddenError(
            message=enhanced_message,
            response_body=error.response_body,
            request_id=error.request_id,
            error_code=error.error_code,
            url=error.url,
            method=error.method,
        )
    if isinstance(error, NotFoundError):
        return NotFoundError(
            message=enhanced_message,
            response_body=error.response_body,
            request_id=error.request_id,
            error_code=error.error_code,
            url=error.url,
            method=error.method,
        )
    if isinstance(error, ConflictError):
        return ConflictError(
            message=enhanced_message,
            response_body=error.response_body,
            request_id=error.request_id,
            error_code=error.error_code,
            url=error.url,
            method=error.method,
        )
    if isinstance(error, ServerError):
        return ServerError(
            message=enhanced_message,
            status_code=error.status_code,
            response_body=error.response_body,
            request_id=error.request_id,
            error_code=error.error_code,
            url=error.url,
            method=error.method,
        )
    if isinstance(error, PineconeTimeoutError):
        # TimeoutError generates its own message in __init__, so we need to recreate it
        # with enhanced message
        wrapped = PineconeTimeoutError(timeout=error.timeout)
        wrapped.message = enhanced_message
        # Update Exception args so str() works correctly
        wrapped.args = (enhanced_message,)
        return wrapped
    if isinstance(error, PineconeConnectionError):
        # ConnectionError has a cause attribute that must be preserved
        return PineconeConnectionError(enhanced_message, cause=error.cause)
    if isinstance(error, APIConnectionError):
        return APIConnectionError(enhanced_message)
    # Generic APIError
    return APIError(
        message=enhanced_message,
        status_code=error.status_code,
        response_body=error.response_body,
        request_id=error.request_id,
        error_code=error.error_code,
        url=error.url,
        method=error.method,
    )
