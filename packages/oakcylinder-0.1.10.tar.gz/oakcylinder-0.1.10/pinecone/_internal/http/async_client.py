"""Asynchronous HTTP client with retries and connection pooling."""

from __future__ import annotations

import asyncio
import warnings

from typing import TYPE_CHECKING, Any, Literal

import httpx


if TYPE_CHECKING:
    from types import TracebackType

    from pinecone._internal.auth import AsyncTokenManager
    from pinecone._internal.http.config import HTTPConfig

from pinecone._internal.http.base import HTTPClientBase
from pinecone._internal.http.curl_debug import CURL_DEBUG_ENABLED
from pinecone._internal.logging import get_logger


logger = get_logger(__name__)


class AsyncHTTPClient(HTTPClientBase):
    """Asynchronous HTTP client with retries and rate limiting.

    The underlying httpx.AsyncClient is created lazily on the first async
    method call, ensuring it's initialized in the correct async context.
    This makes the client safe to instantiate in any context (including
    sync code) and use across different event loops.

    Supports both API key and OAuth bearer token authentication.

    Args:
        api_key: Pinecone API key (required if auth_type="api_key")
        config: HTTP client configuration (uses defaults if not provided)
        additional_headers: Extra headers to include in every request
        auth_type: Authentication mode - "api_key" or "bearer"
        token_manager: Async token manager for bearer auth (required if auth_type="bearer")
        source_tag: Optional identifier for tracking SDK usage by source (partner integrations)
    """

    def __init__(
        self,
        api_key: str | None = None,
        config: HTTPConfig | None = None,
        additional_headers: dict[str, str] | None = None,
        auth_type: Literal["api_key", "bearer"] = "api_key",
        token_manager: AsyncTokenManager | None = None,
        source_tag: str | None = None,
    ):
        super().__init__(api_key, config, additional_headers, auth_type, token_manager, source_tag)

        # Validate token manager type for async client
        if auth_type == "bearer" and token_manager is not None:
            from pinecone._internal.auth import TokenManager

            if isinstance(token_manager, TokenManager):  # type: ignore[unreachable]
                raise TypeError(
                    "AsyncHTTPClient requires AsyncTokenManager, not TokenManager (sync). "
                    "Use HTTPClient with TokenManager instead, or use AsyncTokenManager."
                )

        # Defer httpx.AsyncClient creation until first async call
        # This ensures it's created in the correct async context
        self._client: httpx.AsyncClient | None = None
        self._client_lock: asyncio.Lock | None = None
        self._closed: bool = False

    async def _default_headers_async(self) -> dict[str, str]:
        """Generate default HTTP headers asynchronously (for bearer auth).

        For bearer auth with AsyncTokenManager, awaits token fetch.
        For API key auth, returns headers synchronously.

        Returns:
            Dictionary of default headers
        """
        if self._auth_type == "bearer":
            # Get token (async-safe, cached, auto-refreshed)
            # Cast to AsyncTokenManager since we're in bearer mode
            from pinecone._internal.auth import AsyncTokenManager

            token_manager = self._token_manager
            assert isinstance(token_manager, AsyncTokenManager)
            token = await token_manager.get_token()
            headers = {
                "Authorization": f"Bearer {token}",
                "User-Agent": self._user_agent_string,
                "Content-Type": "application/json",
            }
        else:
            headers = {
                "Api-Key": self._api_key,  # type: ignore[dict-item]
                "User-Agent": self._user_agent_string,
                "Content-Type": "application/json",
            }

        if self._additional_headers:
            headers.update(self._additional_headers)
        return headers

    async def _ensure_client(self) -> httpx.AsyncClient:
        """Ensure httpx.AsyncClient is initialized in async context.

        Uses double-checked locking pattern to safely initialize the client
        when multiple concurrent async calls are made. This protects against
        race conditions within the same event loop, not across OS threads.

        Returns:
            Initialized httpx.AsyncClient instance.

        Raises:
            RuntimeError: If client has been explicitly closed via close()
        """
        # Check if client was explicitly closed
        if self._closed:
            raise RuntimeError("HTTP client has been closed. Create a new client to make requests.")

        # Fast path: client already initialized (no lock needed)
        if self._client is not None:
            return self._client

        # Initialize lock if needed (first time only)
        if self._client_lock is None:
            self._client_lock = asyncio.Lock()

        # Slow path: acquire lock and initialize client
        async with self._client_lock:
            # Double-check after acquiring lock
            if self._client is None:
                # keepalive_expiry ensures connections are closed after 5s of inactivity
                # This helps prevent SSL socket leaks in test environments
                # For bearer auth, we can't get default headers here (async),
                # so we'll merge them per-request instead
                default_headers = None if self._auth_type == "bearer" else self._default_headers()

                self._client = httpx.AsyncClient(
                    http2=self._config.http2,
                    timeout=self._create_timeout(),
                    limits=httpx.Limits(
                        max_connections=self._config.max_connections,
                        max_keepalive_connections=self._config.max_keepalive_connections,
                        keepalive_expiry=5.0,  # Close idle connections after 5 seconds
                    ),
                    headers=default_headers,
                )

        return self._client

    async def request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        """Make HTTP request with automatic retries.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE, PATCH)
            url: URL to request
            **kwargs: Additional arguments passed to httpx

        Returns:
            HTTP response

        Raises:
            APIConnectionError: If connection fails after all retries
            TimeoutError: If request times out
            APIError: If server returns an error response
            asyncio.CancelledError: If the operation is cancelled
        """
        # Ensure client is initialized in async context before fetching token
        # This prevents token fetch on closed client
        client = await self._ensure_client()

        # Merge custom headers with default headers (custom headers take precedence)
        # For bearer auth, we need to await token fetch
        default_headers = await self._default_headers_async()
        if "headers" in kwargs:
            merged_headers = {**default_headers, **kwargs["headers"]}
            kwargs["headers"] = merged_headers
        else:
            kwargs["headers"] = default_headers

        # Define async request function that uses async client
        async def make_request() -> httpx.Response:
            return await client.request(method, url, **kwargs)

        # Use shared retry logic with async sleep
        return await self._execute_with_retry_async(
            method=method,
            url=url,
            request_fn=make_request,
            sleep_fn=asyncio.sleep,
            kwargs=kwargs,
            curl_debug_enabled=CURL_DEBUG_ENABLED,
            client_logger=logger,
        )

    async def get(self, url: str, **kwargs: Any) -> httpx.Response:
        """Make GET request.

        Args:
            url: URL to request
            **kwargs: Additional arguments passed to httpx

        Returns:
            HTTP response
        """
        return await self.request("GET", url, **kwargs)

    async def post(self, url: str, **kwargs: Any) -> httpx.Response:
        """Make POST request.

        Args:
            url: URL to request
            **kwargs: Additional arguments passed to httpx

        Returns:
            HTTP response
        """
        return await self.request("POST", url, **kwargs)

    async def put(self, url: str, **kwargs: Any) -> httpx.Response:
        """Make PUT request.

        Args:
            url: URL to request
            **kwargs: Additional arguments passed to httpx

        Returns:
            HTTP response
        """
        return await self.request("PUT", url, **kwargs)

    async def delete(self, url: str, **kwargs: Any) -> httpx.Response:
        """Make DELETE request.

        Args:
            url: URL to request
            **kwargs: Additional arguments passed to httpx

        Returns:
            HTTP response
        """
        return await self.request("DELETE", url, **kwargs)

    async def patch(self, url: str, **kwargs: Any) -> httpx.Response:
        """Make PATCH request.

        Args:
            url: URL to request
            **kwargs: Additional arguments passed to httpx

        Returns:
            HTTP response
        """
        return await self.request("PATCH", url, **kwargs)

    @property
    def is_closed(self) -> bool:
        """Check if HTTP client is closed.

        Returns:
            True if client is closed or not yet initialized, False otherwise.
        """
        return self._client is None or self._client.is_closed

    async def close(self) -> None:
        """Close HTTP client and clean up resources.

        This method is idempotent - calling it multiple times is safe.
        """
        if self._client is not None:
            await self._client.aclose()
            self._client = None  # Make close() truly idempotent
        self._closed = True  # Mark as closed to prevent reuse

    async def __aenter__(self) -> AsyncHTTPClient:
        """Enter async context manager."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit async context manager and clean up resources."""
        await self.close()

    def __del__(self) -> None:
        """Warn if client wasn't properly closed."""
        try:
            if self._client is not None and not self._client.is_closed:
                warnings.warn(
                    f"Unclosed {self.__class__.__name__}. Use 'async with' or call 'await client.close()'",
                    ResourceWarning,
                    stacklevel=2,
                )
        except Exception:  # noqa: BLE001, S110
            # Ignore errors during cleanup (e.g., during interpreter shutdown)
            pass
