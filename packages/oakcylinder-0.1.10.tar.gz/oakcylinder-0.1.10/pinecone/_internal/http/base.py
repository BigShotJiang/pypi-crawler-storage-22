"""Base class for HTTP clients with shared logic."""

from __future__ import annotations

import asyncio
import logging
import random
import re
import time

from typing import TYPE_CHECKING, Any, Literal

import httpx

from pinecone import __version__
from pinecone._internal.constants import DEFAULT_TIMEOUT, SOURCE_TAG
from pinecone._internal.http.config import HTTPConfig
from pinecone._internal.logging import get_logger
from pinecone.exceptions import (
    APIConnectionError,
    APIError,
    BadRequestError,
    ConflictError,
    ConnectionError,  # noqa: A004 - Custom Pinecone exception, not builtin
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError,  # noqa: A004 - Custom Pinecone exception, not builtin
    UnauthorizedError,
)


if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from pinecone._internal.auth import AsyncTokenManager, TokenManager


logger = get_logger(__name__)


class HTTPClientBase:
    """Shared logic for sync and async HTTP clients.

    Supports two authentication modes:
    - API key authentication (default): Uses Api-Key header
    - Bearer token authentication: Uses Authorization: Bearer header with OAuth tokens

    Args:
        api_key: Pinecone API key for authentication (required if auth_type="api_key")
        config: HTTP client configuration (uses defaults if not provided)
        additional_headers: Extra headers to include in every request
        auth_type: Authentication mode - "api_key" or "bearer"
        token_manager: Token manager for bearer auth (required if auth_type="bearer")
        source_tag: Optional identifier for tracking SDK usage by source (partner integrations)

    Raises:
        ValueError: If auth_type="bearer" but token_manager not provided,
            or if auth_type="api_key" but api_key not provided
    """

    def __init__(
        self,
        api_key: str | None = None,
        config: HTTPConfig | None = None,
        additional_headers: dict[str, str] | None = None,
        auth_type: Literal["api_key", "bearer"] = "api_key",
        token_manager: TokenManager | AsyncTokenManager | None = None,
        source_tag: str | None = None,
    ):
        # Validate auth_type is valid
        if auth_type not in ("api_key", "bearer"):
            raise ValueError(f"auth_type must be 'api_key' or 'bearer', got: {auth_type!r}")

        # Validate auth configuration
        if auth_type == "bearer" and token_manager is None:
            raise ValueError("token_manager is required when auth_type='bearer'")
        if auth_type == "api_key" and not api_key:
            raise ValueError("api_key is required when auth_type='api_key'")

        self._api_key = api_key
        self._config = config or HTTPConfig()
        self._additional_headers = additional_headers or {}
        self._auth_type = auth_type
        self._token_manager = token_manager
        self._source_tag = source_tag

        # Cache normalized user-agent string for performance
        self._user_agent_string = self._build_user_agent()

    def _default_headers(self) -> dict[str, str]:
        """Generate default HTTP headers based on auth type.

        For bearer auth, gets token from TokenManager (which handles
        caching and refresh with minimal lock contention).

        Includes any additional_headers provided at construction time.
        Additional headers take precedence over built-in defaults.
        """
        if self._auth_type == "bearer":
            # Get token (thread-safe, cached, auto-refreshed)
            token = self._token_manager.get_token()  # type: ignore[union-attr]
            headers = {
                "Authorization": f"Bearer {token}",
                "User-Agent": self._user_agent_string,
                "Content-Type": "application/json",
            }
        else:
            headers = {
                "Api-Key": self._api_key,  # type: ignore[dict-item]
                "User-Agent": self._user_agent_string,
                "Content-Type": "application/json",
            }

        if self._additional_headers:
            headers.update(self._additional_headers)
        return headers

    def _normalize_source_tag(self, source_tag: str) -> str:
        """Normalize source_tag to match legacy SDK format.

        Normalization rules (matching legacy SDK):
        1. Lowercase
        2. Limit charset to [a-z0-9_ :]
        3. Trim left/right whitespace
        4. Condense multiple spaces to one, and replace with underscore

        Args:
            source_tag: Raw source tag string

        Returns:
            Normalized source tag string
        """
        tag = source_tag.lower()
        tag = re.sub(r"[^a-z0-9_ :]", "", tag)
        tag = tag.strip()
        return "_".join(tag.split())

    def _build_user_agent(self) -> str:
        """Build User-Agent string matching legacy SDK format.

        Format:
        - Without source_tag: python-client-{version}
        - With source_tag: python-client-{version}; source_tag={normalized_tag}

        Returns:
            User-Agent string
        """
        client_id = f"python-client-{__version__}"

        if self._source_tag:
            normalized_tag = self._normalize_source_tag(self._source_tag)
            # Only append source_tag if normalization produced a non-empty string
            if normalized_tag:
                return f"{client_id}; {SOURCE_TAG}={normalized_tag}"

        return client_id

    def _create_timeout(self) -> httpx.Timeout:
        """Convert timeout config to httpx.Timeout object.

        Returns:
            httpx.Timeout object with appropriate timeout values
        """
        if isinstance(self._config.timeout, dict):
            # For partial dicts, use DEFAULT_TIMEOUT as default for unspecified timeout types
            return httpx.Timeout(DEFAULT_TIMEOUT, **self._config.timeout)
        return httpx.Timeout(self._config.timeout)

    def _resolve_timeout_value(self, exception: httpx.TimeoutException) -> float:
        """Determine which timeout value to report based on exception type.

        Args:
            exception: The httpx timeout exception that was raised

        Returns:
            The timeout value in seconds that corresponds to the exception type
        """
        if isinstance(self._config.timeout, (int, float)):
            return float(self._config.timeout)

        # Timeout is a dict - check which specific timeout fired
        if isinstance(exception, httpx.ConnectTimeout):
            return float(self._config.timeout.get("connect", DEFAULT_TIMEOUT))
        if isinstance(exception, httpx.ReadTimeout):
            return float(self._config.timeout.get("read", DEFAULT_TIMEOUT))
        if isinstance(exception, httpx.WriteTimeout):
            return float(self._config.timeout.get("write", DEFAULT_TIMEOUT))
        if isinstance(exception, httpx.PoolTimeout):
            return float(self._config.timeout.get("pool", DEFAULT_TIMEOUT))

        # Generic timeout or unspecified timeout type
        return float(DEFAULT_TIMEOUT)

    def _backoff_time(self, attempt: int, response: httpx.Response | None = None) -> float:
        """Calculate exponential backoff time with jitter.

        Args:
            attempt: Current attempt number (0-indexed)
            response: Optional HTTP response to check for Retry-After header

        Returns:
            Number of seconds to wait before next retry
        """
        # Check for Retry-After header
        if response and "Retry-After" in response.headers:
            try:
                return float(response.headers["Retry-After"])
            except ValueError:
                pass

        # Exponential backoff with jitter to prevent thundering herd
        base_delay = min(
            self._config.retry_backoff_factor**attempt,
            self._config.retry_max_wait,
        )
        return base_delay * random.uniform(0.5, 1.0)  # noqa: S311

    def _raise_for_status(self, response: httpx.Response) -> None:  # noqa: PLR0912
        """Raise appropriate exception for error status codes.

        Args:
            response: HTTP response to check

        Raises:
            BadRequestError: For 400 status codes
            UnauthorizedError: For 401 status codes
            ForbiddenError: For 403 status codes
            NotFoundError: For 404 status codes
            ConflictError: For 409 status codes
            RateLimitError: For 429 status codes
            ServerError: For 5xx status codes
            APIError: For other error status codes
        """
        if response.is_success:
            return

        # Extract structured error data
        error_code = None
        message = None

        try:
            error_data = response.json()
            message = error_data.get("message")
            # Try to extract error code from various common patterns
            if isinstance(error_data.get("error"), dict):
                error_code = error_data["error"].get("code")
            elif "code" in error_data:
                error_code = error_data["code"]
            elif "error_code" in error_data:
                error_code = error_data["error_code"]
        except (ValueError, KeyError):
            pass

        # Fall back to response text if no message in JSON
        if not message:
            message = response.text or None

        # Extract metadata for debugging and support
        request_id = response.headers.get("X-Request-Id") or response.headers.get("x-request-id")
        url = str(response.url)
        method = response.request.method if response.request else None

        # Log error with full context
        logger.error(
            f"HTTP {response.status_code} error from {method or 'UNKNOWN'} {url}: {message or 'no details available'}",
            status=response.status_code,
            error_message=message,
            request_id=request_id,
            error_code=error_code,
            url=url,
            method=method,
        )

        # Build common kwargs for all exceptions
        kwargs = {
            "response_body": response.text,
            "request_id": request_id,
            "error_code": error_code,
            "url": url,
            "method": method,
        }

        # Map status code to specific exception with full context
        if response.status_code == 400:
            raise BadRequestError(message, **kwargs)
        if response.status_code == 401:
            raise UnauthorizedError(message=message, **kwargs)
        if response.status_code == 403:
            raise ForbiddenError(message, **kwargs)
        if response.status_code == 404:
            raise NotFoundError(message, **kwargs)
        if response.status_code == 409:
            raise ConflictError(message, **kwargs)
        if response.status_code == 429:
            retry_after = response.headers.get("Retry-After")
            raise RateLimitError(
                retry_after=int(retry_after) if retry_after else None,
                message=message,
                **kwargs,
            )
        if 500 <= response.status_code < 600:
            raise ServerError(message, status_code=response.status_code, **kwargs)

        # Ensure message is not None for generic APIError
        if message is None:
            message = f"HTTP {response.status_code}"
        raise APIError(message, response.status_code, **kwargs)

    def _execute_with_retry(  # noqa: PLR0912, PLR0915 - Consolidates retry logic
        self,
        method: str,
        url: str,
        request_fn: Callable[[], httpx.Response],
        sleep_fn: Callable[[float], None],
        kwargs: dict[str, Any],
        curl_debug_enabled: bool = False,
        client_logger: Any = None,
    ) -> httpx.Response:
        """Execute HTTP request with retry logic.

        This method contains the shared retry logic used by both sync and async clients.
        It abstracts the differences between sync/async using callback functions.

        Args:
            method: HTTP method (GET, POST, etc.)
            url: URL to request
            request_fn: Function that makes the actual HTTP request and returns response
            sleep_fn: Function to sleep for given duration (sync or async)
            kwargs: Request arguments (headers, content, etc.)
            curl_debug_enabled: Whether curl debugging is enabled
            client_logger: Logger instance to use (defaults to base logger)

        Returns:
            HTTP response from request_fn

        Raises:
            TimeoutError: If request times out after all retries
            ConnectionError: If connection fails after all retries
            APIConnectionError: If request fails after all retries
            APIError: If server returns error response
        """
        log = client_logger or logger
        last_error: Exception | None = None

        for attempt in range(self._config.max_retries):
            try:
                # Log request (with guard for hot-path performance)
                if log._logger.isEnabledFor(logging.DEBUG):
                    # Include request body for debugging
                    request_body = None
                    if "content" in kwargs:
                        content = kwargs["content"]
                        if isinstance(content, bytes):
                            request_body = content.decode("utf-8")[:1000]
                        elif isinstance(content, str):
                            request_body = content[:1000]
                        if request_body and len(str(kwargs.get("content", ""))) > 1000:
                            request_body += "... (truncated)"

                    log.debug(
                        "HTTP request",
                        method=method,
                        url=url,
                        attempt=attempt + 1,
                        body=request_body,
                    )

                # Print curl equivalent when PINECONE_DEBUG_CURL=true
                if curl_debug_enabled:
                    from pinecone._internal.http.curl_debug import print_curl_debug

                    print_curl_debug(
                        method,
                        url,
                        kwargs.get("headers") or self._default_headers(),
                        kwargs.get("content"),
                    )

                # Make request
                start = time.perf_counter()
                response = request_fn()
                duration = time.perf_counter() - start

                # Print raw response when PINECONE_DEBUG_CURL=true
                if curl_debug_enabled:
                    from pinecone._internal.http.curl_debug import print_response_debug

                    print_response_debug(response)

                # Log response (with guard for hot-path performance)
                if log._logger.isEnabledFor(logging.DEBUG):
                    # Include response body for debugging
                    response_body = response.text[:1000] if response.text else ""
                    if len(response.text) > 1000:
                        response_body += "... (truncated)"

                    log.debug(
                        "HTTP response",
                        method=method,
                        url=url,
                        status=response.status_code,
                        duration=duration,
                        body=response_body,
                    )

                # Check if should retry based on status code
                if (
                    response.status_code in self._config.retry_statuses
                    and attempt < self._config.max_retries - 1
                ):
                    wait_time = self._backoff_time(attempt, response)
                    log.info(
                        f"Retrying after {wait_time}s",
                        status=response.status_code,
                        attempt=attempt + 1,
                    )
                    sleep_fn(wait_time)
                    continue

                # Raise for error status codes
                self._raise_for_status(response)

                return response  # noqa: TRY300

            except httpx.TimeoutException as e:
                last_error = e
                if attempt < self._config.max_retries - 1:
                    wait_time = self._backoff_time(attempt)
                    log.warning(
                        f"Request timed out, retrying after {wait_time}s",
                        error=str(e),
                        attempt=attempt + 1,
                    )
                    sleep_fn(wait_time)
                    continue
                log.exception(
                    "Request timed out after all retries",
                    timeout=self._config.timeout,
                    attempts=attempt + 1,
                )
                raise TimeoutError(timeout=self._resolve_timeout_value(e)) from e

            except httpx.ConnectError as e:
                last_error = e
                if attempt < self._config.max_retries - 1:
                    wait_time = self._backoff_time(attempt)
                    log.warning(
                        f"Connection failed, retrying after {wait_time}s",
                        error=str(e),
                        attempt=attempt + 1,
                    )
                    sleep_fn(wait_time)
                    continue
                log.exception(
                    "Connection failed after all retries",
                    url=url,
                    attempts=attempt + 1,
                )
                raise ConnectionError(f"Failed to connect to {url}") from e

            except httpx.RequestError as e:
                last_error = e
                if attempt < self._config.max_retries - 1:
                    wait_time = self._backoff_time(attempt)
                    log.warning(
                        f"Request failed, retrying after {wait_time}s",
                        error=str(e),
                        attempt=attempt + 1,
                    )
                    sleep_fn(wait_time)
                    continue

        # All retries exhausted
        log.error(
            "Request failed after all retries",
            method=method,
            url=url,
            attempts=self._config.max_retries,
        )
        raise APIConnectionError(
            f"Request failed after {self._config.max_retries} attempts"
        ) from last_error

    async def _execute_with_retry_async(  # noqa: PLR0912, PLR0915 - Consolidates retry logic
        self,
        method: str,
        url: str,
        request_fn: Callable[[], Awaitable[httpx.Response]],
        sleep_fn: Callable[[float], Awaitable[None]],
        kwargs: dict[str, Any],
        curl_debug_enabled: bool = False,
        client_logger: Any = None,
    ) -> httpx.Response:
        """Execute HTTP request with retry logic (async version).

        This method contains the shared retry logic used by async client.
        It handles asyncio.CancelledError separately to ensure proper cancellation.

        Args:
            method: HTTP method (GET, POST, etc.)
            url: URL to request
            request_fn: Async function that makes the actual HTTP request and returns response
            sleep_fn: Async function to sleep for given duration
            kwargs: Request arguments (headers, content, etc.)
            curl_debug_enabled: Whether curl debugging is enabled
            client_logger: Logger instance to use (defaults to base logger)

        Returns:
            HTTP response from request_fn

        Raises:
            asyncio.CancelledError: If the operation is cancelled
            TimeoutError: If request times out after all retries
            ConnectionError: If connection fails after all retries
            APIConnectionError: If request fails after all retries
            APIError: If server returns error response
        """
        log = client_logger or logger
        last_error: Exception | None = None

        for attempt in range(self._config.max_retries):
            try:
                # Log request (with guard for hot-path performance)
                if log._logger.isEnabledFor(logging.DEBUG):
                    # Include request body for debugging
                    request_body = None
                    if "content" in kwargs:
                        content = kwargs["content"]
                        if isinstance(content, bytes):
                            request_body = content.decode("utf-8")[:1000]
                        elif isinstance(content, str):
                            request_body = content[:1000]
                        if request_body and len(str(kwargs.get("content", ""))) > 1000:
                            request_body += "... (truncated)"

                    log.debug(
                        "HTTP request",
                        method=method,
                        url=url,
                        attempt=attempt + 1,
                        body=request_body,
                    )

                # Print curl equivalent when PINECONE_DEBUG_CURL=true
                if curl_debug_enabled:
                    from pinecone._internal.http.curl_debug import print_curl_debug

                    print_curl_debug(
                        method,
                        url,
                        kwargs.get("headers") or self._default_headers(),
                        kwargs.get("content"),
                    )

                # Make request
                start = time.perf_counter()
                response = await request_fn()
                duration = time.perf_counter() - start

                # Print raw response when PINECONE_DEBUG_CURL=true
                if curl_debug_enabled:
                    from pinecone._internal.http.curl_debug import print_response_debug

                    print_response_debug(response)

                # Log response (with guard for hot-path performance)
                if log._logger.isEnabledFor(logging.DEBUG):
                    # Include response body for debugging
                    response_body = response.text[:1000] if response.text else ""
                    if len(response.text) > 1000:
                        response_body += "... (truncated)"

                    log.debug(
                        "HTTP response",
                        method=method,
                        url=url,
                        status=response.status_code,
                        duration=duration,
                        body=response_body,
                    )

                # Check if should retry based on status code
                if (
                    response.status_code in self._config.retry_statuses
                    and attempt < self._config.max_retries - 1
                ):
                    wait_time = self._backoff_time(attempt, response)
                    log.info(
                        f"Retrying after {wait_time}s",
                        status=response.status_code,
                        attempt=attempt + 1,
                    )
                    await sleep_fn(wait_time)
                    continue

                # Raise for error status codes
                self._raise_for_status(response)

                return response  # noqa: TRY300

            except asyncio.CancelledError:
                log.debug("Request cancelled", method=method, url=url)
                raise

            except httpx.TimeoutException as e:
                last_error = e
                if attempt < self._config.max_retries - 1:
                    wait_time = self._backoff_time(attempt)
                    log.warning(
                        f"Request timed out, retrying after {wait_time}s",
                        error=str(e),
                        attempt=attempt + 1,
                    )
                    await sleep_fn(wait_time)
                    continue
                log.exception(
                    "Request timed out after all retries",
                    timeout=self._config.timeout,
                    attempts=attempt + 1,
                )
                raise TimeoutError(timeout=self._resolve_timeout_value(e)) from e

            except httpx.ConnectError as e:
                last_error = e
                if attempt < self._config.max_retries - 1:
                    wait_time = self._backoff_time(attempt)
                    log.warning(
                        f"Connection failed, retrying after {wait_time}s",
                        error=str(e),
                        attempt=attempt + 1,
                    )
                    await sleep_fn(wait_time)
                    continue
                log.exception(
                    "Connection failed after all retries",
                    url=url,
                    attempts=attempt + 1,
                )
                raise ConnectionError(f"Failed to connect to {url}") from e

            except httpx.RequestError as e:
                last_error = e
                if attempt < self._config.max_retries - 1:
                    wait_time = self._backoff_time(attempt)
                    log.warning(
                        f"Request failed, retrying after {wait_time}s",
                        error=str(e),
                        attempt=attempt + 1,
                    )
                    await sleep_fn(wait_time)
                    continue

        # All retries exhausted
        log.error(
            "Request failed after all retries",
            method=method,
            url=url,
            attempts=self._config.max_retries,
        )
        raise APIConnectionError(
            f"Request failed after {self._config.max_retries} attempts"
        ) from last_error
