"""Synchronous HTTP client with retries and connection pooling."""

from __future__ import annotations

import time
import warnings

from typing import TYPE_CHECKING, Any, Literal

import httpx


if TYPE_CHECKING:
    from types import TracebackType

    from pinecone._internal.auth import TokenManager
    from pinecone._internal.http.config import HTTPConfig

from pinecone._internal.http.base import HTTPClientBase
from pinecone._internal.http.curl_debug import CURL_DEBUG_ENABLED
from pinecone._internal.logging import get_logger


logger = get_logger(__name__)


class HTTPClient(HTTPClientBase):
    """Synchronous HTTP client with retries and rate limiting.

    Supports both API key and OAuth bearer token authentication.

    Args:
        api_key: Pinecone API key (required if auth_type="api_key")
        config: HTTP client configuration (uses defaults if not provided)
        additional_headers: Extra headers to include in every request
        auth_type: Authentication mode - "api_key" or "bearer"
        token_manager: Token manager for bearer auth (required if auth_type="bearer")
        source_tag: Optional identifier for tracking SDK usage by source (partner integrations)
    """

    def __init__(
        self,
        api_key: str | None = None,
        config: HTTPConfig | None = None,
        additional_headers: dict[str, str] | None = None,
        auth_type: Literal["api_key", "bearer"] = "api_key",
        token_manager: TokenManager | None = None,
        source_tag: str | None = None,
    ):
        super().__init__(api_key, config, additional_headers, auth_type, token_manager, source_tag)

        # Validate token manager type for sync client
        if auth_type == "bearer" and token_manager is not None:
            from pinecone._internal.auth import AsyncTokenManager

            if isinstance(token_manager, AsyncTokenManager):  # type: ignore[unreachable]
                raise TypeError(
                    "HTTPClient (sync) requires TokenManager, not AsyncTokenManager. "
                    "Use AsyncHTTPClient with AsyncTokenManager instead."
                )

        # Create httpx client with connection pooling
        # keepalive_expiry ensures connections are closed after 5s of inactivity
        # This helps prevent SSL socket leaks in test environments
        # For bearer auth, we fetch headers per-request (tokens can expire)
        default_headers = None if auth_type == "bearer" else self._default_headers()

        self._client: httpx.Client | None = httpx.Client(
            http2=self._config.http2,
            timeout=self._create_timeout(),
            limits=httpx.Limits(
                max_connections=self._config.max_connections,
                max_keepalive_connections=self._config.max_keepalive_connections,
                keepalive_expiry=5.0,  # Close idle connections after 5 seconds
            ),
            headers=default_headers,
        )

    def request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        """Make HTTP request with automatic retries.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE, PATCH)
            url: URL to request
            **kwargs: Additional arguments passed to httpx

        Returns:
            HTTP response

        Raises:
            APIConnectionError: If connection fails after all retries
            TimeoutError: If request times out
            APIError: If server returns an error response
            RuntimeError: If client has been closed
        """
        if self._client is None:
            raise RuntimeError("HTTP client has been closed. Create a new client to make requests.")

        # Merge custom headers with default headers (custom headers take precedence)
        # For bearer auth, this ensures fresh tokens are fetched per-request
        default_headers = self._default_headers()
        if "headers" in kwargs:
            merged_headers = {**default_headers, **kwargs["headers"]}
            kwargs["headers"] = merged_headers
        else:
            kwargs["headers"] = default_headers

        # Capture client in local variable for closure (helps mypy)
        client = self._client

        # Define request function that uses sync client
        def make_request() -> httpx.Response:
            return client.request(method, url, **kwargs)

        # Use shared retry logic with sync sleep
        return self._execute_with_retry(
            method=method,
            url=url,
            request_fn=make_request,
            sleep_fn=time.sleep,
            kwargs=kwargs,
            curl_debug_enabled=CURL_DEBUG_ENABLED,
            client_logger=logger,
        )

    def get(self, url: str, **kwargs: Any) -> httpx.Response:
        """Make GET request.

        Args:
            url: URL to request
            **kwargs: Additional arguments passed to httpx

        Returns:
            HTTP response
        """
        return self.request("GET", url, **kwargs)

    def post(self, url: str, **kwargs: Any) -> httpx.Response:
        """Make POST request.

        Args:
            url: URL to request
            **kwargs: Additional arguments passed to httpx

        Returns:
            HTTP response
        """
        return self.request("POST", url, **kwargs)

    def put(self, url: str, **kwargs: Any) -> httpx.Response:
        """Make PUT request.

        Args:
            url: URL to request
            **kwargs: Additional arguments passed to httpx

        Returns:
            HTTP response
        """
        return self.request("PUT", url, **kwargs)

    def delete(self, url: str, **kwargs: Any) -> httpx.Response:
        """Make DELETE request.

        Args:
            url: URL to request
            **kwargs: Additional arguments passed to httpx

        Returns:
            HTTP response
        """
        return self.request("DELETE", url, **kwargs)

    def patch(self, url: str, **kwargs: Any) -> httpx.Response:
        """Make PATCH request.

        Args:
            url: URL to request
            **kwargs: Additional arguments passed to httpx

        Returns:
            HTTP response
        """
        return self.request("PATCH", url, **kwargs)

    @property
    def is_closed(self) -> bool:
        """Check if HTTP client is closed.

        Returns:
            True if client is closed or None, False otherwise.
        """
        return self._client is None or self._client.is_closed

    def close(self) -> None:
        """Close HTTP client and clean up resources.

        This method ensures all connections are properly closed and resources
        are released. It's important to call this method when done with the
        client to avoid resource leaks, especially in test environments.

        This method is idempotent - calling it multiple times is safe.
        """
        # Explicitly close the client to ensure all connections are released
        # This is especially important with HTTP/2 and connection pooling
        if hasattr(self, "_client") and self._client is not None:
            self._client.close()
            self._client = None  # Make close() truly idempotent

    def __enter__(self) -> HTTPClient:
        """Enter context manager."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit context manager and clean up resources."""
        self.close()

    def __del__(self) -> None:
        """Warn if client wasn't properly closed."""
        try:
            if self._client is not None and not self._client.is_closed:
                warnings.warn(
                    f"Unclosed {self.__class__.__name__}. Use 'with' or call 'client.close()'",
                    ResourceWarning,
                    stacklevel=2,
                )
        except Exception:  # noqa: BLE001, S110
            # Ignore all exceptions during cleanup to avoid issues during interpreter shutdown
            pass
