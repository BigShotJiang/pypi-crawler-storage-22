"""Mixins for data plane request handling.

These mixins provide a unified interface for making HTTP requests to the Pinecone
data plane API, supporting GET, POST, and DELETE methods with optional request
bodies and query parameters.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import orjson

from pinecone._internal.constants import DATA_PLANE_HEADERS


if TYPE_CHECKING:
    from pinecone._internal.http import AsyncHTTPClient, HTTPClient


class DataPlaneRequestMixin:
    """Mixin for synchronous data plane HTTP requests.

    Classes using this mixin must have:
    - self._base_url: Base URL for the data plane API
    - self._http: HTTPClient instance
    """

    _base_url: str
    _http: HTTPClient

    def _make_data_plane_request(
        self,
        method: str,
        path: str,
        *,
        body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> bytes:
        """Make an HTTP request to the data plane API.

        Args:
            method: HTTP method (GET, POST, or DELETE).
            path: API path relative to base_url.
            body: Optional request body to serialize as JSON.
            params: Optional query parameters.

        Returns:
            Raw response content as bytes.
        """
        url = f"{self._base_url}{path}"
        content = orjson.dumps(body) if body is not None else None

        if method == "GET":
            response = self._http.get(url, headers=DATA_PLANE_HEADERS, params=params)
        elif method == "DELETE":
            response = self._http.request("DELETE", url, headers=DATA_PLANE_HEADERS, params=params)
        else:
            response = self._http.post(
                url, headers=DATA_PLANE_HEADERS, content=content, params=params
            )

        return response.content


class AsyncDataPlaneRequestMixin:
    """Mixin for asynchronous data plane HTTP requests.

    Classes using this mixin must have:
    - self._base_url: Base URL for the data plane API
    - self._http: AsyncHTTPClient instance
    """

    _base_url: str
    _http: AsyncHTTPClient

    async def _make_data_plane_request(
        self,
        method: str,
        path: str,
        *,
        body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> bytes:
        """Make an async HTTP request to the data plane API.

        Args:
            method: HTTP method (GET, POST, or DELETE).
            path: API path relative to base_url.
            body: Optional request body to serialize as JSON.
            params: Optional query parameters.

        Returns:
            Raw response content as bytes.
        """
        url = f"{self._base_url}{path}"
        content = orjson.dumps(body) if body is not None else None

        if method == "GET":
            response = await self._http.get(url, headers=DATA_PLANE_HEADERS, params=params)
        elif method == "DELETE":
            response = await self._http.request(
                "DELETE", url, headers=DATA_PLANE_HEADERS, params=params
            )
        else:
            response = await self._http.post(
                url, headers=DATA_PLANE_HEADERS, content=content, params=params
            )

        return response.content
