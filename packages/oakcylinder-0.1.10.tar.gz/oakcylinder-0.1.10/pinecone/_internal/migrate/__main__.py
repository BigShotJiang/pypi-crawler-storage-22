"""CLI entry point for pinecone-migrate command."""


def main() -> None:
    """Main entry point for the pinecone-migrate CLI."""
    print("Pinecone migration tool")
    print("Version: 0.1.0")


if __name__ == "__main__":
    main()
