"""Async sub-namespace for bulk import operations on a Pinecone index."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

import msgspec

from pinecone._internal.http.data_plane_mixin import AsyncDataPlaneRequestMixin
from pinecone._internal.validation import require_non_empty
from pinecone.models.bulk_imports.cancel import CancelImportResponse
from pinecone.models.bulk_imports.import_model import ImportModel
from pinecone.models.bulk_imports.list import ListImportsResponse
from pinecone.models.bulk_imports.start import StartImportResponse


if TYPE_CHECKING:
    from pinecone._internal.http import AsyncHTTPClient


# Module-level decoders
_START_DECODER = msgspec.json.Decoder(StartImportResponse)
_LIST_DECODER = msgspec.json.Decoder(ListImportsResponse)
_DESCRIBE_DECODER = msgspec.json.Decoder(ImportModel)
_CANCEL_DECODER = msgspec.json.Decoder(CancelImportResponse)


class AsyncBulkImports(AsyncDataPlaneRequestMixin):
    """Async sub-namespace for bulk import operations on a Pinecone index.

    Access via the ``bulk_imports`` property on an AsyncIndex instance::

        async with AsyncIndex(host="...", api_key="...") as index:
            imports = await index.bulk_imports.list()

    Args:
        http: Async HTTP client for making requests.
        base_url: Base URL for the index data plane.
    """

    def __init__(self, *, http: AsyncHTTPClient, base_url: str) -> None:
        self._http = http
        self._base_url = base_url

    async def start(
        self,
        *,
        uri: str,
        integration_id: str | None = None,
        error_mode: Literal["abort", "continue"] | None = None,
    ) -> StartImportResponse:
        """Start a bulk import operation.

        Args:
            uri: Source URI (S3, GCS, or Azure) containing the data to import.
            integration_id: Storage integration ID for authentication.
            error_mode: How to handle errors during import. Either ``"abort"`` to
                stop on first error, or ``"continue"`` to skip bad records.

        Returns:
            StartImportResponse with the import operation ID.

        Raises:
            ValueError: If required parameters are empty.
            PineconeApiException: If the API request fails.

        Examples:
            >>> response = await index.bulk_imports.start(uri="s3://my-bucket/my-data/")
            >>> print(f"Import started: {response.id}")
        """
        require_non_empty("uri", uri)

        body: dict[str, Any] = {"uri": uri}
        if integration_id is not None:
            body["integrationId"] = integration_id
        if error_mode is not None:
            body["errorMode"] = {"onError": error_mode}

        data = await self._make_data_plane_request("POST", "/bulk/imports", body=body)
        return _START_DECODER.decode(data)

    async def list(
        self,
        *,
        limit: int | None = None,
        pagination_token: str | None = None,
    ) -> ListImportsResponse:
        """List bulk import operations.

        Args:
            limit: Maximum number of imports to return (default 100, max 100).
            pagination_token: Token to resume from a previous call.

        Returns:
            ListImportsResponse with import operations and pagination info.

        Raises:
            PineconeApiException: If the API request fails.

        Examples:
            >>> response = await index.bulk_imports.list(limit=10)
            >>> for imp in response.data:
            ...     print(f"{imp.id}: {imp.status}")
        """
        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if pagination_token is not None:
            params["paginationToken"] = pagination_token

        data = await self._make_data_plane_request("GET", "/bulk/imports", params=params)
        return _LIST_DECODER.decode(data)

    async def describe(
        self,
        *,
        id: str,  # noqa: A002
    ) -> ImportModel:
        """Describe a bulk import operation.

        Args:
            id: The import operation ID.

        Returns:
            ImportModel with details about the import operation.

        Raises:
            ValueError: If required parameters are empty.
            PineconeApiException: If the API request fails.

        Examples:
            >>> imp = await index.bulk_imports.describe(id="import-123")
            >>> print(f"{imp.status}: {imp.percent_complete}%")
        """
        require_non_empty("id", id)

        data = await self._make_data_plane_request("GET", f"/bulk/imports/{id}")
        return _DESCRIBE_DECODER.decode(data)

    async def cancel(
        self,
        *,
        id: str,  # noqa: A002
    ) -> CancelImportResponse:
        """Cancel a bulk import operation.

        Args:
            id: The import operation ID to cancel.

        Returns:
            CancelImportResponse (empty on success).

        Raises:
            ValueError: If required parameters are empty.
            PineconeApiException: If the API request fails.

        Examples:
            >>> await index.bulk_imports.cancel(id="import-123")
        """
        require_non_empty("id", id)

        data = await self._make_data_plane_request("DELETE", f"/bulk/imports/{id}")
        return _CANCEL_DECODER.decode(data)

    def __repr__(self) -> str:
        """Return string representation."""
        return f"AsyncBulkImports(base_url={self._base_url!r})"
