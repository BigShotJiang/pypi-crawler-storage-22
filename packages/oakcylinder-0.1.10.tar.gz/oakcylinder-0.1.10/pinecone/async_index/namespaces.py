"""Async namespace management operations for a Pinecone index."""

from __future__ import annotations

from typing import Any

import msgspec

from pinecone._internal.http.data_plane_mixin import AsyncDataPlaneRequestMixin
from pinecone._internal.validation import require_non_empty
from pinecone.models.namespaces.delete import DeleteNamespaceResponse
from pinecone.models.namespaces.list import ListNamespacesResponse
from pinecone.models.namespaces.namespace import FieldConfig, NamespaceDescription


__all__ = ["AsyncNamespaces"]


# Module-level decoders for hot-path operations
_CREATE_DECODER = msgspec.json.Decoder(NamespaceDescription)
_LIST_DECODER = msgspec.json.Decoder(ListNamespacesResponse)
_DESCRIBE_DECODER = msgspec.json.Decoder(NamespaceDescription)
_DELETE_DECODER = msgspec.json.Decoder(DeleteNamespaceResponse)


class AsyncNamespaces(AsyncDataPlaneRequestMixin):
    """Async sub-namespace for namespace management operations on a Pinecone index.

    Access via the ``namespaces`` property on an AsyncIndex instance::

        async with AsyncIndex(host="...", api_key="...") as index:
            ns_list = await index.namespaces.list()

    Args:
        http: Async HTTP client for making requests.
        base_url: Base URL for the index data plane API.
    """

    def __init__(self, *, http: Any, base_url: str) -> None:
        self._http = http
        self._base_url = base_url

    async def create(
        self,
        *,
        name: str,
        schema: dict[str, dict[str, bool]] | dict[str, FieldConfig] | None = None,
    ) -> NamespaceDescription:
        """Create a new namespace in the index.

        Args:
            name (str): The name of the namespace to create.
            schema (dict[str, dict[str, bool]] | dict[str, FieldConfig] | None): Optional
                schema definition mapping field names to their configuration.
                Each field maps to a dict with configuration options such as
                ``{"filterable": True}`` or a ``FieldConfig`` object.

        Returns:
            NamespaceDescription for the newly created namespace.

        Raises:
            ValueError: If required parameters are empty.
            PineconeApiException: If the API request fails.

        Examples:
            >>> ns = await index.namespaces.create(name="my-namespace")
            >>> ns = await index.namespaces.create(
            ...     name="my-namespace",
            ...     schema={"category": {"filterable": True}},
            ... )
        """
        require_non_empty("name", name)
        body: dict[str, Any] = {"name": name}
        if schema is not None:
            fields: dict[str, Any] = {}
            for field_name, config in schema.items():
                if isinstance(config, FieldConfig):
                    fields[field_name] = {"filterable": config.filterable}
                else:
                    fields[field_name] = config
            body["schema"] = {"fields": fields}

        data = await self._make_data_plane_request("POST", "/namespaces", body=body)
        return _CREATE_DECODER.decode(data)

    async def list(
        self,
        *,
        limit: int | None = None,
        pagination_token: str | None = None,
        prefix: str | None = None,
    ) -> ListNamespacesResponse:
        """List namespaces in the index.

        Args:
            limit (int | None): Maximum number of namespaces to return.
            pagination_token (str | None): Token to resume from a previous call.
            prefix (str | None): Filter namespaces by name prefix.

        Returns:
            ListNamespacesResponse with namespace descriptions and pagination info.

        Raises:
            PineconeApiException: If the API request fails.

        Examples:
            >>> response = await index.namespaces.list()
            >>> for ns in response.namespaces:
            ...     print(f"{ns.name}: {ns.record_count} records")
        """
        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if pagination_token is not None:
            params["paginationToken"] = pagination_token
        if prefix is not None:
            params["prefix"] = prefix

        data = await self._make_data_plane_request("GET", "/namespaces", params=params)
        return _LIST_DECODER.decode(data)

    async def describe(self, *, name: str) -> NamespaceDescription:
        """Describe a specific namespace in the index.

        Args:
            name (str): The name of the namespace to describe.

        Returns:
            NamespaceDescription with the namespace details.

        Raises:
            ValueError: If required parameters are empty.
            PineconeApiException: If the API request fails.

        Examples:
            >>> ns = await index.namespaces.describe(name="my-namespace")
            >>> print(f"{ns.name}: {ns.record_count} records")
        """
        require_non_empty("name", name)
        data = await self._make_data_plane_request("GET", f"/namespaces/{name}")
        return _CREATE_DECODER.decode(data)

    async def delete(self, *, name: str) -> DeleteNamespaceResponse:
        """Delete a namespace from the index.

        Args:
            name (str): The name of the namespace to delete.

        Returns:
            DeleteNamespaceResponse (empty on success).

        Raises:
            ValueError: If required parameters are empty.
            PineconeApiException: If the API request fails.

        Examples:
            >>> await index.namespaces.delete(name="my-namespace")
        """
        require_non_empty("name", name)
        data = await self._make_data_plane_request("DELETE", f"/namespaces/{name}")
        return _DELETE_DECODER.decode(data)

    def __repr__(self) -> str:
        """Return string representation."""
        return f"AsyncNamespaces(base_url={self._base_url!r})"
