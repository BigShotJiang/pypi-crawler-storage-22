"""Control plane namespace implementations for Pinecone and AsyncPinecone clients."""
