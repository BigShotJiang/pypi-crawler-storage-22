"""Common models shared across multiple Pinecone API domains."""

from pinecone.models._base import BaseModel


class Usage(BaseModel, kw_only=True):  # pyright: ignore[reportCallIssue]
    """Usage information for API requests.

    This model supports usage tracking for different API endpoints:
    - Inference API: tracks total_tokens
    - Documents API: tracks read_units

    Attributes:
        total_tokens: Total number of tokens used (for inference operations).
        read_units: Number of read units consumed (for document operations).
    """

    total_tokens: int | None = None
    read_units: int | None = None
