"""Data models for Backup management API.

Uses lazy loading via __getattr__ to maintain import performance.
"""

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from pinecone.models.backups.backup import BackupModel
    from pinecone.models.backups.create import CreateBackupRequest

__all__ = [
    "BackupModel",
    "CreateBackupRequest",
]

_LAZY_IMPORTS = {
    "BackupModel": "pinecone.models.backups.backup",
    "CreateBackupRequest": "pinecone.models.backups.create",
}


def __getattr__(name: str) -> Any:
    """Lazy-load models on first access."""
    if name in _LAZY_IMPORTS:
        from importlib import import_module

        module = import_module(_LAZY_IMPORTS[name])
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
