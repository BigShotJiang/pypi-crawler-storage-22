"""Create backup request model."""

from __future__ import annotations

from pinecone.models._base import BaseModel


class CreateBackupRequest(BaseModel, kw_only=True, omit_defaults=True):  # pyright: ignore[reportCallIssue]
    """Request model for creating a backup.

    Attributes:
        name: Optional user-defined name for the backup.
        description: Optional description providing context for the backup.
    """

    name: str | None = None
    description: str | None = None
