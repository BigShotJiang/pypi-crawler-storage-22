"""Data models for bulk import operations.

Uses lazy loading via __getattr__ to avoid loading all models when only one is needed.
"""

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from pinecone.models.bulk_imports.cancel import CancelImportResponse
    from pinecone.models.bulk_imports.import_model import ImportModel
    from pinecone.models.bulk_imports.list import ListImportsResponse
    from pinecone.models.bulk_imports.start import StartImportResponse

__all__ = [
    "CancelImportResponse",
    "ImportModel",
    "ListImportsResponse",
    "StartImportResponse",
]

_LAZY_IMPORTS = {
    "CancelImportResponse": "pinecone.models.bulk_imports.cancel",
    "ImportModel": "pinecone.models.bulk_imports.import_model",
    "ListImportsResponse": "pinecone.models.bulk_imports.list",
    "StartImportResponse": "pinecone.models.bulk_imports.start",
}


def __getattr__(name: str) -> Any:
    """Lazy-load models on first access."""
    if name in _LAZY_IMPORTS:
        from importlib import import_module

        module = import_module(_LAZY_IMPORTS[name])
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
