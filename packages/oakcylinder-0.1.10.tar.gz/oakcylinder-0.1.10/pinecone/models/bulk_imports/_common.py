"""Shared data models for bulk import operations."""

from pinecone.models.index._common import _Pagination


__all__ = ["_Pagination"]
