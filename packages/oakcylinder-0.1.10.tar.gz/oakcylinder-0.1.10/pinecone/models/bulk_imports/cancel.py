"""Data model for cancelling a bulk import."""

from pinecone.models._base import BaseModel


class CancelImportResponse(BaseModel, kw_only=True):
    """Response from cancelling a bulk import operation.

    This is an empty response indicating success.
    """
