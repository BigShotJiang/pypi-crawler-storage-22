"""Data model for a bulk import operation."""

from typing import Any

from pinecone.models._base import BaseModel
from pinecone.models._display import render_table


class ImportModel(BaseModel, kw_only=True, rename="camel"):
    """A bulk import operation on a Pinecone index.

    Attributes:
        id: Unique identifier for the import operation.
        uri: Source URI (S3, GCS, or Azure) for the import data.
        status: Current status of the import operation.
        created_at: Timestamp when the import was created.
        finished_at: Timestamp when the import finished, if completed.
        percent_complete: Percentage of the import completed (0-100).
        records_imported: Number of records imported so far.
        error: Error message if the import failed.
    """

    id: str
    uri: str = ""
    status: str = ""
    created_at: str = ""
    finished_at: str | None = None
    percent_complete: float = 0.0
    records_imported: int = 0
    error: str | None = None

    def __repr__(self) -> str:
        parts = [f"id={self.id!r}", f"status={self.status!r}"]
        if self.percent_complete > 0:
            parts.append(f"progress={self.percent_complete}%")
        if self.records_imported > 0:
            parts.append(f"records={self.records_imported}")
        return f"ImportModel({', '.join(parts)})"

    def __dir__(self) -> list[str]:
        """Return public API, hiding internal attributes."""
        attrs = set(super().__dir__())
        public = {name for name in attrs if not name.startswith("_")}
        return sorted(public)

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        """IPython pretty-printer support."""
        if cycle:
            p.text("ImportModel(...)")
            return

        p.text("ImportModel(")
        with p.group(2, "", ")"):
            p.breakable()
            p.text(f"id={self.id!r},")
            p.breakable()
            p.text(f"uri={self.uri!r},")
            p.breakable()
            p.text(f"status={self.status!r},")
            p.breakable()
            p.text(f"created_at={self.created_at!r},")
            p.breakable()
            p.text(f"percent_complete={self.percent_complete},")
            p.breakable()
            p.text(f"records_imported={self.records_imported}")

            if self.finished_at is not None:
                p.breakable()
                p.text(f"finished_at={self.finished_at!r}")
            if self.error is not None:
                p.breakable()
                p.text(f"error={self.error!r}")

    def _repr_html_(self) -> str:
        """Jupyter notebook HTML representation."""
        rows: list[tuple[str, str | int | float]] = [
            ("ID:", self.id),
            ("URI:", self.uri),
            ("Status:", self.status),
            ("Created:", self.created_at),
            ("Progress:", f"{self.percent_complete}%"),
            ("Records Imported:", self.records_imported),
        ]

        if self.finished_at is not None:
            rows.append(("Finished:", self.finished_at))
        if self.error is not None:
            rows.append(("Error:", self.error))

        return render_table("ImportModel", rows)
