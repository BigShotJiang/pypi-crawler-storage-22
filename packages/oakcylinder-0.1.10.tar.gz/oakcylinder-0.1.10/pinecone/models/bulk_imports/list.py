"""Data model for listing bulk imports."""

from pinecone.models._base import BaseModel
from pinecone.models.bulk_imports._common import _Pagination
from pinecone.models.bulk_imports.import_model import ImportModel


class ListImportsResponse(BaseModel, kw_only=True, rename="camel"):
    """Response from listing bulk import operations.

    Attributes:
        data: List of import operations.
        pagination: Pagination envelope from the API.
    """

    data: list[ImportModel]
    pagination: _Pagination | None = None

    @property
    def imports(self) -> list[ImportModel]:
        """The import operations in this response."""
        return self.data

    @property
    def pagination_token(self) -> str | None:
        """Token for fetching the next page, or None."""
        return self.pagination.next if self.pagination else None

    def __repr__(self) -> str:
        return f"ListImportsResponse(data={len(self.data)})"
