"""Data model for starting a bulk import."""

from pinecone.models._base import BaseModel


class StartImportResponse(BaseModel, kw_only=True):
    """Response from starting a bulk import operation.

    Attributes:
        id: Unique identifier for the created import operation.
    """

    id: str
