"""Data models for Collections API.

Uses lazy loading via __getattr__ to maintain import performance.
"""

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from pinecone.models.collections.collection import CollectionModel
    from pinecone.models.collections.create import CreateCollectionRequest
    from pinecone.models.collections.list import CollectionList

__all__ = [
    "CollectionList",
    "CollectionModel",
    "CreateCollectionRequest",
]

_LAZY_IMPORTS = {
    "CollectionModel": "pinecone.models.collections.collection",
    "CollectionList": "pinecone.models.collections.list",
    "CreateCollectionRequest": "pinecone.models.collections.create",
}


def __getattr__(name: str) -> Any:
    """Lazy-load models on first access."""
    if name in _LAZY_IMPORTS:
        from importlib import import_module

        module = import_module(_LAZY_IMPORTS[name])
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
