"""Collection metadata model."""

from __future__ import annotations

from typing import Any

from pinecone.__interface__ import CollectionStatus  # noqa: TC001
from pinecone.models._base import BaseModel
from pinecone.models._display import render_table


class CollectionModel(BaseModel, kw_only=True, omit_defaults=True):  # pyright: ignore[reportCallIssue]
    """Collection metadata model.

    This model satisfies the CollectionInfoProtocol.

    Attributes:
        name: Collection name.
        size: Collection size in bytes.
        status: Collection status (Initializing, Ready, or Terminating).
        dimension: Vector dimensionality.
        vector_count: Number of vectors in collection.
        environment: Environment name where collection is hosted.
    """

    name: str
    size: int
    status: CollectionStatus
    dimension: int
    vector_count: int
    environment: str

    def __repr__(self) -> str:
        """Return developer-friendly representation.

        Shows key metadata without overwhelming with all fields.
        """
        return (
            f"CollectionModel(name={self.name!r}, status={self.status!r}, "
            f"vectors={self.vector_count}, dimension={self.dimension})"
        )

    def __dir__(self) -> list[str]:
        """Return public API, hiding internal attributes."""
        attrs = set(super().__dir__())
        public = {name for name in attrs if not name.startswith("_")}
        return sorted(public)

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        """IPython pretty-printer support."""
        if cycle:
            p.text("CollectionModel(...)")
            return

        p.text("CollectionModel(")
        with p.group(2, "", ")"):
            p.breakable()
            p.text(f"name={self.name!r},")
            p.breakable()
            p.text(f"status={self.status!r},")
            p.breakable()
            p.text(f"size={self.size},")
            p.breakable()
            p.text(f"dimension={self.dimension},")
            p.breakable()
            p.text(f"vector_count={self.vector_count},")
            p.breakable()
            p.text(f"environment={self.environment!r}")

    def _repr_html_(self) -> str:
        """Jupyter notebook HTML representation."""
        rows: list[tuple[str, str | int]] = [
            ("Name:", self.name),
            ("Status:", self.status),
            ("Size:", f"{self.size} bytes"),
            ("Dimension:", self.dimension),
            ("Vectors:", self.vector_count),
            ("Environment:", self.environment),
        ]

        return render_table("CollectionModel", rows)
