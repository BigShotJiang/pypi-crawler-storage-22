"""Create collection request model."""

from __future__ import annotations

from pinecone.models._base import BaseModel


class CreateCollectionRequest(BaseModel, kw_only=True, omit_defaults=True):  # pyright: ignore[reportCallIssue]
    """Request model for creating a collection.

    Attributes:
        name: Collection name (1-45 chars, lowercase alphanumeric or '-').
        source: Source index name to create collection from.
    """

    name: str
    source: str
