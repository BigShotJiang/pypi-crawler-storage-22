"""Collection list response model."""

from __future__ import annotations

from typing import TYPE_CHECKING

from pinecone.models._base import BaseModel


if TYPE_CHECKING:
    from pinecone.models.collections.collection import CollectionModel


class CollectionList(BaseModel, kw_only=True, omit_defaults=True):  # pyright: ignore[reportCallIssue]
    """Response model for list collections endpoint.

    Attributes:
        collections: List of collection metadata objects.
    """

    collections: list[CollectionModel]

    def __repr__(self) -> str:
        """Return developer-friendly representation.

        Shows count rather than full list to avoid overwhelming output.
        """
        return f"CollectionList(collections={len(self.collections)} items)"
