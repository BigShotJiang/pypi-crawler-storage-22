"""Data models for document operations.

Uses lazy loading via __getattr__ to maintain import performance.
"""

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from pinecone.models._common import Usage
    from pinecone.models.documents.score_by import (
        DenseVectorQuery,
        QueryStringQuery,
        ScoreByQuery,
        SparseVectorQuery,
        TextQuery,
    )
    from pinecone.models.documents.search import Document, DocumentSearchResponse
    from pinecone.models.documents.upsert import DocumentUpsertResponse
    from pinecone.models.index._common import SparseValues

__all__ = [
    "DenseVectorQuery",
    "Document",
    "DocumentSearchResponse",
    "DocumentUpsertResponse",
    "QueryStringQuery",
    "ScoreByQuery",
    "SparseValues",
    "SparseVectorQuery",
    "TextQuery",
    "Usage",
]

_LAZY_IMPORTS = {
    "DenseVectorQuery": "pinecone.models.documents.score_by",
    "Document": "pinecone.models.documents.search",
    "DocumentSearchResponse": "pinecone.models.documents.search",
    "DocumentUpsertResponse": "pinecone.models.documents.upsert",
    "QueryStringQuery": "pinecone.models.documents.score_by",
    "ScoreByQuery": "pinecone.models.documents.score_by",
    "SparseValues": "pinecone.models.index._common",
    "SparseVectorQuery": "pinecone.models.documents.score_by",
    "TextQuery": "pinecone.models.documents.score_by",
    "Usage": "pinecone.models._common",
}


def __getattr__(name: str) -> Any:
    """Lazy-load models on first access."""
    if name in _LAZY_IMPORTS:
        # PLC0415: import should be at the top-level of a file (ruff error)
        # Intentionally inside __getattr__ for lazy loading performance.
        from importlib import import_module

        module = import_module(_LAZY_IMPORTS[name])
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
