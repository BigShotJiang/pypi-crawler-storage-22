"""Models for document search operation."""

from typing import Any

import orjson

from pinecone.models._base import BaseModel
from pinecone.models._common import Usage
from pinecone.models._display import render_table


__all__ = ["Document", "DocumentSearchResponse", "Usage"]


class Document:
    """A document returned from search.

    This class provides type-safe access to document fields with typed properties
    for known fields (id, score) while maintaining flexibility for arbitrary custom
    fields from API responses.

    Attributes:
        id: The unique identifier of the document.
        _id: Alias for id (backward compatibility).
        score: The relevance score for this document (if applicable).

    Note:
        Additional fields from the API response are accessible as attributes or
        via dictionary-style access with get(). The implementation stores all
        fields internally and provides typed access to common fields.

    Example:
        >>> for doc in response.documents:
        ...     print(f"{doc.id}: {doc.score}")
        ...     # Access custom fields via get() method with type safety
        ...     title: str | None = doc.get("title")
        ...     price: float = doc.get("price", 0.0)
        ...     # Or via attribute access for dynamic fields
        ...     if hasattr(doc, "category"):
        ...         print(f"  Category: {doc.category}")
    """

    __slots__ = ("_extras", "_id_value", "_score_value")

    # Type annotations for __slots__ attributes
    _id_value: str
    _score_value: float | None
    _extras: dict[str, Any]

    def __init__(self, data: dict[str, Any]) -> None:
        """Initialize document from dictionary.

        Args:
            data: Raw document data from API.

        Raises:
            ValueError: If document has neither '_id' nor 'id' field.
        """
        # Extract and validate id (handle both _id and id)
        id_value = data.get("_id") or data.get("id")
        if not id_value:
            raise ValueError("Document must have either '_id' or 'id' field")

        # Extract score with type coercion
        score_value: float | None = None
        if "score" in data and data["score"] is not None:
            score_value = float(data["score"])

        # Store known fields
        object.__setattr__(self, "_id_value", str(id_value))
        object.__setattr__(self, "_score_value", score_value)

        # Store all fields for flexible access (including id/score for serialization)
        object.__setattr__(self, "_extras", data.copy())

    @property
    def id(self) -> str:
        """The unique identifier of the document."""
        return self._id_value

    @property
    def _id(self) -> str:
        """Alias for id to maintain backward compatibility."""
        return self._id_value

    @property
    def score(self) -> float | None:
        """The relevance score for this document (if applicable)."""
        return self._score_value

    def get(self, key: str, default: Any = None) -> Any:
        """Get a field value by key.

        This method provides type-safe access to document fields with support
        for default values. The return type is inferred from the default value type.

        Args:
            key: The field name to retrieve.
            default: Default value if field is not present. Defaults to None.

        Returns:
            The field value if present, otherwise the default value.

        Examples:
            >>> doc.get("title")  # Returns Any | None
            >>> doc.get("price", 0.0)  # Returns Any | float
            >>> doc.get("count", 0)  # Returns Any | int
        """
        # Handle special cases for id/score to return typed values
        if key in ("id", "_id"):
            return self._id_value
        if key == "score":
            return self._score_value if self._score_value is not None else default
        return self._extras.get(key, default)

    def __getattr__(self, name: str) -> Any:
        """Allow attribute-style access to document fields.

        Args:
            name: The field name.

        Returns:
            The field value.

        Raises:
            AttributeError: If the field doesn't exist.
        """
        # Prevent infinite recursion on private attributes
        if name.startswith("_"):
            raise AttributeError(f"'Document' object has no attribute '{name}'")

        try:
            return self._extras[name]
        except KeyError as e:
            raise AttributeError(f"'Document' object has no attribute '{name}'") from e

    def __repr__(self) -> str:
        """Return string representation."""
        return f"Document(_id={self._id_value!r}, score={self._score_value!r}, ...)"

    def to_dict(self) -> dict[str, Any]:
        """Convert document to a Python dictionary.

        Returns:
            A shallow copy of the underlying document data.

        Examples:
            >>> doc = response.documents[0]
            >>> data = doc.to_dict()
            >>> data["_id"]
            'doc-1'
        """
        return dict(self._extras)

    def to_json(self) -> str:
        """Convert document to a JSON string.

        Returns:
            JSON string representation of the document.

        Examples:
            >>> doc = response.documents[0]
            >>> print(doc.to_json())
            '{"_id":"doc-1","score":0.95,"title":"Example"}'
        """
        return orjson.dumps(self._extras).decode("utf-8")

    def __dir__(self) -> list[str]:
        """Return list of available attributes and fields."""
        base_attrs = ["_id", "id", "score", "get", "to_dict", "to_json"]
        doc_fields = [k for k in self._extras if not k.startswith("_") and k not in ("id", "score")]
        return sorted(base_attrs + doc_fields)


class DocumentSearchResponse(BaseModel, kw_only=True):
    """Response from document search operation.

    Contains matching documents, the namespace searched, and usage statistics.

    Attributes:
        matches: List of matching documents, sorted by relevance score.
        namespace: Namespace that was searched.
        usage: API usage statistics for the request (read units consumed).

    Examples:
        >>> response = index.documents.search(...)
        >>> print(f"Found {len(response.matches)} documents")
        >>> print(f"Namespace: {response.namespace}")
        >>> if response.usage:
        ...     print(f"Read units: {response.usage.read_units}")
    """

    matches: list[Document]
    namespace: str
    usage: "Usage | None" = None

    def __repr__(self) -> str:
        return f"DocumentSearchResponse(matches={len(self.matches)}, namespace={self.namespace!r}, usage={self.usage!r})"

    def __dir__(self) -> list[str]:
        """Return public API, hiding internal attributes."""
        attrs = set(super().__dir__())
        public = {name for name in attrs if not name.startswith("_")}
        return sorted(public)

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        """Pretty-printer support for IPython."""
        if cycle:
            p.text("DocumentSearchResponse(...)")
            return

        p.text("DocumentSearchResponse(")
        with p.group(2, "", ")"):
            p.breakable()
            p.text(f"matches={len(self.matches)},")
            p.breakable()
            p.text(f"namespace={self.namespace!r},")
            p.breakable()
            p.text(f"usage={self.usage!r}")

    def _repr_html_(self) -> str:
        """Jupyter notebook HTML representation."""
        rows: list[tuple[str, str | int]] = [
            ("Matches:", len(self.matches)),
            ("Namespace:", self.namespace),
        ]

        if self.usage is not None and self.usage.read_units is not None:
            rows.append(("Read Units:", self.usage.read_units))

        return render_table("DocumentSearchResponse", rows)
