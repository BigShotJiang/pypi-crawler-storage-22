"""Models for document upsert operation."""

from typing import Any

from pinecone.models._base import BaseModel
from pinecone.models._display import render_table


class DocumentUpsertResponse(BaseModel, kw_only=True):
    """Response from document upsert operation.

    Attributes:
        upserted_count: Number of documents successfully upserted.

    Example:
        >>> response = index.documents.upsert(
        ...     namespace="ns",
        ...     documents=[{"_id": "doc1", "text": "hello"}],
        ... )
        >>> print(response.upserted_count)
        1
    """

    upserted_count: int

    def __repr__(self) -> str:
        return f"DocumentUpsertResponse(upserted_count={self.upserted_count})"

    def __dir__(self) -> list[str]:
        """Return public API, hiding internal attributes."""
        attrs = set(super().__dir__())
        public = {name for name in attrs if not name.startswith("_")}
        return sorted(public)

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        """Pretty-printer support for IPython."""
        if cycle:
            p.text("DocumentUpsertResponse(...)")
            return

        p.text(f"DocumentUpsertResponse(upserted_count={self.upserted_count})")

    def _repr_html_(self) -> str:
        """Jupyter notebook HTML representation."""
        rows: list[tuple[str, str | int]] = [
            ("Upserted:", self.upserted_count),
        ]
        return render_table("DocumentUpsertResponse", rows)
