"""Data models for Pinecone data plane operations.

Uses lazy loading via __getattr__ to avoid loading all models when only one is needed.
"""

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from pinecone.models.index._common import (
        DataPlaneUsage,
        ListItem,
        NamespaceSummary,
        ScoredVector,
        SparseValues,
        Vector,
    )
    from pinecone.models.index.delete import DeleteRequest, DeleteResponse
    from pinecone.models.index.describe_index_stats import (
        DescribeIndexStatsRequest,
        DescribeIndexStatsResponse,
    )
    from pinecone.models.index.fetch import FetchResponse
    from pinecone.models.index.fetch_by_metadata import (
        FetchByMetadataRequest,
        FetchByMetadataResponse,
    )
    from pinecone.models.index.list_vectors import ListVectorsResponse
    from pinecone.models.index.query import QueryRequest, QueryResponse
    from pinecone.models.index.update import UpdateRequest, UpdateResponse
    from pinecone.models.index.upsert import UpsertRequest, UpsertResponse

__all__ = [
    "DataPlaneUsage",
    "DeleteRequest",
    "DeleteResponse",
    "DescribeIndexStatsRequest",
    "DescribeIndexStatsResponse",
    "FetchByMetadataRequest",
    "FetchByMetadataResponse",
    "FetchResponse",
    "ListItem",
    "ListVectorsResponse",
    "NamespaceSummary",
    "QueryRequest",
    "QueryResponse",
    "ScoredVector",
    "SparseValues",
    "UpdateRequest",
    "UpdateResponse",
    "UpsertRequest",
    "UpsertResponse",
    "Vector",
]

_LAZY_IMPORTS = {
    "DataPlaneUsage": "pinecone.models.index._common",
    "ListItem": "pinecone.models.index._common",
    "NamespaceSummary": "pinecone.models.index._common",
    "ScoredVector": "pinecone.models.index._common",
    "SparseValues": "pinecone.models.index._common",
    "Vector": "pinecone.models.index._common",
    "DeleteRequest": "pinecone.models.index.delete",
    "DeleteResponse": "pinecone.models.index.delete",
    "DescribeIndexStatsRequest": "pinecone.models.index.describe_index_stats",
    "DescribeIndexStatsResponse": "pinecone.models.index.describe_index_stats",
    "FetchResponse": "pinecone.models.index.fetch",
    "FetchByMetadataRequest": "pinecone.models.index.fetch_by_metadata",
    "FetchByMetadataResponse": "pinecone.models.index.fetch_by_metadata",
    "ListVectorsResponse": "pinecone.models.index.list_vectors",
    "QueryRequest": "pinecone.models.index.query",
    "QueryResponse": "pinecone.models.index.query",
    "UpdateRequest": "pinecone.models.index.update",
    "UpdateResponse": "pinecone.models.index.update",
    "UpsertRequest": "pinecone.models.index.upsert",
    "UpsertResponse": "pinecone.models.index.upsert",
}


def __getattr__(name: str) -> Any:
    """Lazy-load models on first access."""
    if name in _LAZY_IMPORTS:
        from importlib import import_module

        module = import_module(_LAZY_IMPORTS[name])
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
