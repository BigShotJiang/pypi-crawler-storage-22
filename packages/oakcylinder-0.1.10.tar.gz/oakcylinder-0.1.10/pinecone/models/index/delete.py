"""Data models for delete operations."""

from typing import Any

from pinecone.models._base import BaseModel


class DeleteRequest(BaseModel, kw_only=True):
    """Request model for vector delete.

    Attributes:
        ids: Vector IDs to delete.
        delete_all: Whether to delete all vectors.
        namespace: Target namespace.
        filter: Metadata filter for deletion.
    """

    ids: list[str] | None = None
    delete_all: bool = False
    namespace: str = ""
    filter: dict[str, Any] | None = None


class DeleteResponse(BaseModel, kw_only=True):
    """Response model for vector delete.

    The delete API returns an empty response on success.
    """
