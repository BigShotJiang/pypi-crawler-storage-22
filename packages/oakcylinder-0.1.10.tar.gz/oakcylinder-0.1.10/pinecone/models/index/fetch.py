"""Data models for fetch operations."""

from typing import Any

from pinecone.models._base import BaseModel
from pinecone.models._display import render_table
from pinecone.models.index._common import DataPlaneUsage, Vector


class FetchResponse(BaseModel, kw_only=True, rename="camel"):
    """Response model for vector fetch.

    Attributes:
        vectors: Dictionary mapping vector IDs to vectors.
        namespace: Namespace fetched from.
        usage: Read unit usage.
    """

    vectors: dict[str, Vector]
    namespace: str = ""
    usage: DataPlaneUsage | None = None

    def __repr__(self) -> str:
        return f"FetchResponse(vectors={len(self.vectors)}, namespace={self.namespace!r})"

    def __dir__(self) -> list[str]:
        """Return public API, hiding internal attributes."""
        attrs = set(super().__dir__())
        public = {name for name in attrs if not name.startswith("_")}
        return sorted(public)

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        """IPython pretty-printer support."""
        if cycle:
            p.text("FetchResponse(...)")
            return

        p.text("FetchResponse(")
        with p.group(2, "", ")"):
            p.breakable()
            p.text(f"vectors={len(self.vectors)},")
            p.breakable()
            p.text(f"namespace={self.namespace!r}")
            if self.usage is not None:
                p.breakable()
                p.text(f"usage={self.usage!r}")

    def _repr_html_(self) -> str:
        """Jupyter notebook HTML representation."""
        rows: list[tuple[str, str | int]] = [
            ("Vectors:", len(self.vectors)),
            ("Namespace:", self.namespace),
        ]

        if self.usage is not None:
            rows.append(("Read Units:", self.usage.read_units))

        return render_table("FetchResponse", rows)
