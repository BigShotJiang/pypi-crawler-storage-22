"""Data models for list vectors operations."""

from typing import Any

from pinecone.models._base import BaseModel
from pinecone.models._display import render_table
from pinecone.models.index._common import DataPlaneUsage, ListItem, _Pagination


class ListVectorsResponse(BaseModel, kw_only=True, rename="camel"):
    """Response model for list vectors.

    Attributes:
        vectors: List of vector ID items.
        namespace: Namespace listed from.
        pagination: Pagination envelope from the API.
        usage: Read unit usage.
    """

    vectors: list[ListItem]
    namespace: str | None = None
    pagination: _Pagination | None = None
    usage: DataPlaneUsage | None = None

    @property
    def pagination_token(self) -> str | None:
        """Token for fetching the next page, or None."""
        return self.pagination.next if self.pagination else None

    def __repr__(self) -> str:
        return f"ListVectorsResponse(vectors={len(self.vectors)}, namespace={self.namespace!r})"

    def __dir__(self) -> list[str]:
        """Return public API, hiding internal attributes."""
        attrs = set(super().__dir__())
        public = {name for name in attrs if not name.startswith("_")}
        return sorted(public)

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        """IPython pretty-printer support."""
        if cycle:
            p.text("ListVectorsResponse(...)")
            return

        p.text("ListVectorsResponse(")
        with p.group(2, "", ")"):
            p.breakable()
            p.text(f"vectors={len(self.vectors)},")
            p.breakable()
            p.text(f"namespace={self.namespace!r}")
            if self.usage is not None:
                p.breakable()
                p.text(f"usage={self.usage!r}")
            if self.pagination_token is not None:
                p.breakable()
                p.text(f"pagination_token={self.pagination_token!r}")

    def _repr_html_(self) -> str:
        """Jupyter notebook HTML representation."""
        rows: list[tuple[str, str | int]] = [
            ("Vectors:", len(self.vectors)),
            ("Namespace:", self.namespace if self.namespace else "(default)"),
        ]

        if self.usage is not None:
            rows.append(("Read Units:", self.usage.read_units))
        if self.pagination_token is not None:
            rows.append(("Has More Pages:", "Yes"))

        return render_table("ListVectorsResponse", rows)
