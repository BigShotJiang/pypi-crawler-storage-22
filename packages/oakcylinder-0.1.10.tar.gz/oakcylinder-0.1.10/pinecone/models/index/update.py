"""Data models for update operations."""

from typing import Any

from pinecone.models._base import BaseModel


class UpdateRequest(BaseModel, kw_only=True):
    """Request model for vector update.

    Attributes:
        id: Vector ID to update.
        values: New dense vector values.
        sparse_values: New sparse vector values.
        set_metadata: Metadata fields to set or overwrite.
        namespace: Target namespace.
    """

    id: str
    values: list[float] | None = None
    sparse_values: dict[str, Any] | None = None
    set_metadata: dict[str, Any] | None = None
    namespace: str = ""


class UpdateResponse(BaseModel, kw_only=True, rename="camel"):
    """Response model for vector update.

    Attributes:
        matched_records: Number of records matched.
    """

    matched_records: int = 0
