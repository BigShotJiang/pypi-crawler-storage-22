"""Data models for upsert operations."""

from typing import Any

from pinecone.models._base import BaseModel


class UpsertRequest(BaseModel, kw_only=True):
    """Request model for vector upsert.

    Attributes:
        vectors: List of vectors to upsert.
        namespace: Target namespace.
    """

    vectors: list[dict[str, Any]]
    namespace: str = ""


class UpsertResponse(BaseModel, kw_only=True, rename="camel"):
    """Response model for vector upsert.

    Attributes:
        upserted_count: Number of vectors upserted.
    """

    upserted_count: int
