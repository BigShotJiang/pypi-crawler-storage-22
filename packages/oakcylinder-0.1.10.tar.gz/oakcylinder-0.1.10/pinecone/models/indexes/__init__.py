"""Models for index management (2026-01.alpha API).

This module provides models for the schema-driven index management API.
Models are lazy-loaded to minimize import-time costs.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from .configure import ConfigureIndexRequest
    from .create import CreateIndexRequest
    from .deployment import (
        ByocDeployment,
        Deployment,
        ManagedDeployment,
        PodDeployment,
    )
    from .index import IndexList, IndexModel, IndexStatus
    from .read_capacity import (
        ReadCapacityDedicatedResponse,
        ReadCapacityDedicatedSpec,
        ReadCapacityManualScaling,
        ReadCapacityOnDemandResponse,
        ReadCapacityOnDemandSpec,
        ReadCapacityResponse,
        ReadCapacitySpec,
        ReadCapacityStatus,
    )
    from .schema import (
        DenseVectorField,
        IntegerField,
        Schema,
        SchemaBuilder,
        SchemaField,
        SemanticTextField,
        SparseVectorField,
        StringField,
    )


__all__ = [
    "ByocDeployment",
    "ConfigureIndexRequest",
    "CreateIndexRequest",
    "DenseVectorField",
    "Deployment",
    "IndexList",
    "IndexModel",
    "IndexStatus",
    "IntegerField",
    "ManagedDeployment",
    "PodDeployment",
    "ReadCapacityDedicatedResponse",
    "ReadCapacityDedicatedSpec",
    "ReadCapacityManualScaling",
    "ReadCapacityOnDemandResponse",
    "ReadCapacityOnDemandSpec",
    "ReadCapacityResponse",
    "ReadCapacitySpec",
    "ReadCapacityStatus",
    "Schema",
    "SchemaBuilder",
    "SchemaField",
    "SemanticTextField",
    "SparseVectorField",
    "StringField",
]


def __getattr__(name: str) -> Any:  # noqa: PLR0911, PLR0912, PLR0915
    """Lazy-load models on demand."""
    # Create/Configure requests
    if name == "CreateIndexRequest":
        from .create import CreateIndexRequest

        return CreateIndexRequest
    if name == "ConfigureIndexRequest":
        from .configure import ConfigureIndexRequest

        return ConfigureIndexRequest

    # Index response models
    if name == "IndexModel":
        from .index import IndexModel

        return IndexModel
    if name == "IndexList":
        from .index import IndexList

        return IndexList
    if name == "IndexStatus":
        from .index import IndexStatus

        return IndexStatus

    # Schema models
    if name == "Schema":
        from .schema import Schema

        return Schema
    if name == "SchemaField":
        from .schema import SchemaField

        return SchemaField
    if name == "DenseVectorField":
        from .schema import DenseVectorField

        return DenseVectorField
    if name == "SparseVectorField":
        from .schema import SparseVectorField

        return SparseVectorField
    if name == "SemanticTextField":
        from .schema import SemanticTextField

        return SemanticTextField
    if name == "StringField":
        from .schema import StringField

        return StringField
    if name == "IntegerField":
        from .schema import IntegerField

        return IntegerField
    if name == "SchemaBuilder":
        from .schema import SchemaBuilder

        return SchemaBuilder

    # Deployment models
    if name == "Deployment":
        from .deployment import Deployment

        return Deployment
    if name == "ManagedDeployment":
        from .deployment import ManagedDeployment

        return ManagedDeployment
    if name == "PodDeployment":
        from .deployment import PodDeployment

        return PodDeployment
    if name == "ByocDeployment":
        from .deployment import ByocDeployment

        return ByocDeployment

    # Read capacity models
    if name == "ReadCapacitySpec":
        from .read_capacity import ReadCapacitySpec

        return ReadCapacitySpec
    if name == "ReadCapacityOnDemandSpec":
        from .read_capacity import ReadCapacityOnDemandSpec

        return ReadCapacityOnDemandSpec
    if name == "ReadCapacityDedicatedSpec":
        from .read_capacity import ReadCapacityDedicatedSpec

        return ReadCapacityDedicatedSpec
    if name == "ReadCapacityManualScaling":
        from .read_capacity import ReadCapacityManualScaling

        return ReadCapacityManualScaling
    if name == "ReadCapacityResponse":
        from .read_capacity import ReadCapacityResponse

        return ReadCapacityResponse
    if name == "ReadCapacityDedicatedResponse":
        from .read_capacity import ReadCapacityDedicatedResponse

        return ReadCapacityDedicatedResponse
    if name == "ReadCapacityOnDemandResponse":
        from .read_capacity import ReadCapacityOnDemandResponse

        return ReadCapacityOnDemandResponse
    if name == "ReadCapacityStatus":
        from .read_capacity import ReadCapacityStatus

        return ReadCapacityStatus

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
