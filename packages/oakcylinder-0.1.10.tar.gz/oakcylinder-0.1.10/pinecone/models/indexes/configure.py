"""Configure index request model (2026-01.alpha API)."""

from __future__ import annotations

from pinecone.models._base import BaseModel

from .deployment import Deployment  # noqa: TC001
from .read_capacity import ReadCapacitySpec  # noqa: TC001
from .schema import Schema  # noqa: TC001


class ConfigureIndexRequest(BaseModel, omit_defaults=True):  # pyright: ignore[reportCallIssue]
    """Request to configure an existing index.

    The 2026-01.alpha API supports partial updates - only provided fields
    will be updated. You can update the schema (add fields), read capacity,
    deployment configuration, deletion protection, or tags.

    Attributes:
        schema: Updated schema (can add new fields)
        deployment: Updated deployment configuration (limited updates supported)
        read_capacity: Updated read capacity specification
        deletion_protection: Enable/disable deletion protection
        tags: Updated tags (replaces existing tags)

    Example - Update schema (add field):
        >>> request = ConfigureIndexRequest(
        ...     schema=Schema(
        ...         fields={
        ...             "embedding": DenseVectorField(
        ...                 type="dense_vector", dimension=1536, metric="cosine"
        ...             ),
        ...             "description": StringField(  # New field
        ...                 type="string", full_text_searchable=True
        ...             ),
        ...         }
        ...     )
        ... )

    Example - Update read capacity:
        >>> request = ConfigureIndexRequest(
        ...     read_capacity=ReadCapacityDedicatedSpec(
        ...         dedicated=ReadCapacityDedicatedInner(
        ...             node_type="t1",
        ...             scaling="Manual",
        ...             manual=ReadCapacityManualScaling(shards=2, replicas=4),
        ...         )
        ...     )
        ... )

    Example - Update tags:
        >>> request = ConfigureIndexRequest(tags={"environment": "staging", "version": "v2"})

    Example - Enable deletion protection:
        >>> request = ConfigureIndexRequest(deletion_protection="enabled")
    """

    schema: Schema | None = None  # Can update schema
    deployment: Deployment | None = None  # Limited deployment updates
    read_capacity: ReadCapacitySpec | None = None
    deletion_protection: str | None = None
    tags: dict[str, str] | None = None


__all__ = ["ConfigureIndexRequest"]
