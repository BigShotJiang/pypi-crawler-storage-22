"""Create index request model (2026-01.alpha API)."""

from __future__ import annotations

from pinecone.models._base import BaseModel

from .deployment import Deployment  # noqa: TC001
from .read_capacity import ReadCapacitySpec  # noqa: TC001
from .schema import Schema  # noqa: TC001


class CreateIndexRequest(BaseModel):
    """Request to create an index.

    In the 2026-01.alpha API, indexes are schema-driven with field-level
    definitions instead of top-level dimension/metric parameters.

    Attributes:
        schema: Field-level schema definition (REQUIRED)
        name: Index name (auto-generated if not provided)
        deployment: Deployment configuration (defaults to managed if not provided)
        read_capacity: Read capacity specification (managed indexes only)
        deletion_protection: Enable/disable deletion protection ("enabled" or "disabled")
        tags: User-defined tags as key-value pairs
        source_collection: Create index from an existing collection

    Example with minimal config:
        >>> request = CreateIndexRequest(
        ...     schema=Schema(
        ...         fields={
        ...             "embedding": DenseVectorField(
        ...                 type="dense_vector", dimension=1536, metric="cosine"
        ...             )
        ...         }
        ...     )
        ... )

    Example with full config:
        >>> request = CreateIndexRequest(
        ...     name="my-index",
        ...     schema=Schema(
        ...         fields={
        ...             "embedding": DenseVectorField(
        ...                 type="dense_vector",
        ...                 dimension=1536,
        ...                 metric="cosine",
        ...                 description="OpenAI embeddings",
        ...             ),
        ...             "title": StringField(
        ...                 type="string", full_text_searchable=True, description="Document title"
        ...             ),
        ...             "category": StringField(
        ...                 type="string", filterable=True, description="Document category"
        ...             ),
        ...             "year": IntegerField(
        ...                 type="float", filterable=True, description="Publication year"
        ...             ),
        ...         }
        ...     ),
        ...     deployment=ManagedDeployment(
        ...         environment="aped-4627-b74a", cloud="aws", region="us-east-1"
        ...     ),
        ...     read_capacity=ReadCapacityOnDemandSpec(mode="OnDemand"),
        ...     deletion_protection="enabled",
        ...     tags={"environment": "production", "team": "ml"},
        ... )
    """

    schema: Schema  # REQUIRED
    name: str | None = None  # Auto-generated if not provided
    deployment: Deployment | None = None  # Defaults to managed
    read_capacity: ReadCapacitySpec | None = None
    deletion_protection: str | None = None  # enabled, disabled
    tags: dict[str, str] | None = None
    source_collection: str | None = None


__all__ = ["CreateIndexRequest"]
