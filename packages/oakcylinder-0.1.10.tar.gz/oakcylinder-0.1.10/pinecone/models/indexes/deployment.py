"""Deployment configuration models for indexes (2026-01.alpha API)."""

from __future__ import annotations

from typing import Any

from pinecone.models._base import BaseModel


class PodDeployment(BaseModel, tag="pod", tag_field="deployment_type"):
    """Pod-based deployment configuration.

    Pod-based indexes provide dedicated compute resources with predictable
    performance. They are ideal for applications with consistent workloads
    that require guaranteed capacity.

    Attributes:
        environment: Environment identifier (e.g., "us-east1-gcp", "us-west1-gcp")
        pod_type: Pod type (e.g., "p1.x1", "p1.x2", "p2.x1", "s1.x1", "s1.x2")
        pods: Number of pods (optional, derived from replicas * shards if not provided)
        replicas: Number of replicas for high availability (optional)
        shards: Number of shards for horizontal scaling (optional)
        metadata_config: Metadata fields to index for filtering (optional)
        source_collection: Collection to create index from (optional)

    Note:
        The "deployment_type" field is automatically set to "pod" by msgspec's
        tagged union system and should not be included in the struct definition.

    Example:
        >>> deployment = PodDeployment(
        ...     environment="us-east1-gcp",
        ...     pod_type="p1.x2",
        ...     replicas=2,
        ...     shards=2,
        ...     metadata_config={"indexed": ["genre", "year"]},
        ... )
    """

    environment: str
    pod_type: str
    pods: int | None = None
    replicas: int | None = None
    shards: int | None = None
    metadata_config: dict[str, Any] | None = None
    source_collection: str | None = None


class ManagedDeployment(BaseModel, tag="managed", tag_field="deployment_type"):
    """Managed deployment configuration (default in 2026-01.alpha).

    Managed deployments are the default deployment type when no deployment
    is specified. They provide cloud provider and region configuration along
    with an environment identifier.

    Attributes:
        environment: Environment identifier
        cloud: Cloud provider ("aws", "gcp", or "azure")
        region: Cloud region (e.g., "us-east-1", "us-west-2", "europe-west1")

    Note:
        The "deployment_type" field is automatically set to "managed" by msgspec's
        tagged union system and should not be included in the struct definition.

    Example:
        >>> deployment = ManagedDeployment(
        ...     environment="aped-4627-b74a", cloud="aws", region="us-east-1"
        ... )
    """

    environment: str
    cloud: str
    region: str


class ByocDeployment(BaseModel, tag="byoc", tag_field="deployment_type"):
    """Bring Your Own Cloud (BYOC) deployment configuration.

    BYOC deployments run in your own cloud account, giving you full control
    over data residency and cloud infrastructure while using Pinecone's
    managed database service.

    Attributes:
        environment: BYOC environment identifier
        cloud: Cloud provider (optional, for 2026-01.alpha)
        region: Cloud region (optional, for 2026-01.alpha)

    Note:
        The "deployment_type" field is automatically set to "byoc" by msgspec's
        tagged union system and should not be included in the struct definition.

    Example:
        >>> deployment = ByocDeployment(
        ...     environment="us-east1-gcp-byoc", cloud="gcp", region="us-east1"
        ... )
    """

    environment: str
    cloud: str | None = None
    region: str | None = None


# Union type for discriminated deployment
Deployment = PodDeployment | ManagedDeployment | ByocDeployment


__all__ = [
    "ByocDeployment",
    "Deployment",
    "ManagedDeployment",
    "PodDeployment",
]
