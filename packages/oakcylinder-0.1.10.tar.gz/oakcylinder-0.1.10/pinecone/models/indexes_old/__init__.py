"""Data models for Index management API.

Uses lazy loading via __getattr__ to maintain import performance.
"""

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from pinecone.models.indexes_old._common import IndexStatus
    from pinecone.models.indexes_old.index import IndexConfig, IndexModel
    from pinecone.models.indexes_old.list import IndexList
    from pinecone.models.indexes_old.specs import (
        ByocSpec,
        IndexSpec,
        PodSpec,
        ServerlessReadCapacity,
        ServerlessReadCapacityDedicated,
        ServerlessReadCapacityManual,
        ServerlessReadCapacityStatus,
        ServerlessSpec,
    )

__all__ = [
    "ByocSpec",
    "IndexConfig",
    "IndexList",
    "IndexModel",
    "IndexSpec",
    "IndexStatus",
    "PodSpec",
    "ServerlessReadCapacity",
    "ServerlessReadCapacityDedicated",
    "ServerlessReadCapacityManual",
    "ServerlessReadCapacityStatus",
    "ServerlessSpec",
]

_LAZY_IMPORTS = {
    "IndexStatus": "pinecone.models.indexes_old._common",
    "ServerlessSpec": "pinecone.models.indexes_old.specs",
    "PodSpec": "pinecone.models.indexes_old.specs",
    "ByocSpec": "pinecone.models.indexes_old.specs",
    "IndexSpec": "pinecone.models.indexes_old.specs",
    "ServerlessReadCapacity": "pinecone.models.indexes_old.specs",
    "ServerlessReadCapacityDedicated": "pinecone.models.indexes_old.specs",
    "ServerlessReadCapacityManual": "pinecone.models.indexes_old.specs",
    "ServerlessReadCapacityStatus": "pinecone.models.indexes_old.specs",
    "IndexModel": "pinecone.models.indexes_old.index",
    "IndexConfig": "pinecone.models.indexes_old.index",
    "IndexList": "pinecone.models.indexes_old.list",
}


def __getattr__(name: str) -> Any:
    """Lazy-load models on first access."""
    if name in _LAZY_IMPORTS:
        from importlib import import_module

        module = import_module(_LAZY_IMPORTS[name])
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
