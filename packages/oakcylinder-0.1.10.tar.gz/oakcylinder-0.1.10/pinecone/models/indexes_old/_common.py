"""Common models shared across Index management API operations."""

from __future__ import annotations

from pinecone.models._base import BaseModel


class IndexStatus(BaseModel, kw_only=True):
    """Index status information.

    Indicates whether an index is ready to serve requests and its current state.

    Attributes:
        ready: Whether the index is ready to serve requests
        state: Current index state (e.g., "Ready", "Initializing", "Scaling")

    Example:
        >>> info = pc.indexes.describe("my-index")
        >>> if info.status.ready:
        ...     print(f"Index is {info.status.state}")
    """

    ready: bool
    state: str
