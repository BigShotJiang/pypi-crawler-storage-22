"""Index list response model."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from pinecone.models._base import BaseModel
from pinecone.models._display import render_table


if TYPE_CHECKING:
    from pinecone.models.indexes_old.index import IndexModel


class IndexList(BaseModel, kw_only=True):
    """List of indexes response."""

    indexes: list[IndexModel]

    def __repr__(self) -> str:
        """Return summary representation."""
        return f"IndexList(indexes={len(self.indexes)})"

    def __dir__(self) -> list[str]:
        """Return public API."""
        attrs = set(super().__dir__())
        public = {name for name in attrs if not name.startswith("_")}
        return sorted(public)

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        """Pretty-printer support for Ipython."""
        if cycle:
            p.text("IndexList(...)")
            return

        p.text(f"IndexList(indexes={len(self.indexes)})")

    def _repr_html_(self) -> str:
        """Jupyter notebook HTML representation."""
        return render_table(
            "IndexList",
            [("Indexes:", len(self.indexes))],
        )
