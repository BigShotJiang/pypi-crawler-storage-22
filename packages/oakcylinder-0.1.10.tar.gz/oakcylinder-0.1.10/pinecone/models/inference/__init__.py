"""Data models for Pinecone Inference API.

Uses lazy loading via __getattr__ to avoid loading all models when only one is needed.
This maintains the same import performance as the current single-file structure.

API Version: 2025-10
"""

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    # Type hints for static analysis - no runtime cost
    from pinecone.models._common import Usage
    from pinecone.models.inference.embed import Embedding, EmbedRequest, EmbedResponse
    from pinecone.models.inference.list_models import (
        ListModelsResponse,
        ModelInfo,
        ModelInfoSupportedParameter,
    )
    from pinecone.models.inference.rerank import (
        RerankDocument,
        RerankRequest,
        RerankResponse,
        RerankResult,
    )

__all__ = [
    "EmbedRequest",
    "EmbedResponse",
    "Embedding",
    "ListModelsResponse",
    "ModelInfo",
    "ModelInfoSupportedParameter",
    "RerankDocument",
    "RerankRequest",
    "RerankResponse",
    "RerankResult",
    "Usage",
]

# Lazy loading map: model name -> module path
_LAZY_IMPORTS = {
    "Usage": "pinecone.models._common",
    "EmbedRequest": "pinecone.models.inference.embed",
    "EmbedResponse": "pinecone.models.inference.embed",
    "Embedding": "pinecone.models.inference.embed",
    "RerankRequest": "pinecone.models.inference.rerank",
    "RerankResponse": "pinecone.models.inference.rerank",
    "RerankResult": "pinecone.models.inference.rerank",
    "RerankDocument": "pinecone.models.inference.rerank",
    "ListModelsResponse": "pinecone.models.inference.list_models",
    "ModelInfo": "pinecone.models.inference.list_models",
    "ModelInfoSupportedParameter": "pinecone.models.inference.list_models",
}


def __getattr__(name: str) -> Any:
    """Lazy-load models on first access.

    Only loads the specific module containing the requested model,
    not all models in the namespace. This maintains performance
    equivalent to the current single-file structure.
    """
    if name in _LAZY_IMPORTS:
        from importlib import import_module

        module = import_module(_LAZY_IMPORTS[name])
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
