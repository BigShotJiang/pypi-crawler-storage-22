"""Common models shared across Inference API operations.

API Version: 2025-10
"""

# Re-export Usage from shared location for backward compatibility
from pinecone.models._common import Usage


__all__ = ["Usage"]
