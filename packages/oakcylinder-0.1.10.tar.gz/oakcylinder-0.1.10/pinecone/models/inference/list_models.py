"""Data models for list models API.

API Version: 2025-10
"""

from typing import Any

from pinecone.models._base import BaseModel
from pinecone.models._display import render_table


class ModelInfoSupportedParameter(BaseModel, kw_only=True):  # pyright: ignore[reportCallIssue]
    """Parameter supported by a model.

    Attributes:
        parameter: Name of the parameter
        type: Parameter type (e.g., 'one_of', 'numeric_range', 'any')
        value_type: Type of value (e.g., 'string', 'integer', 'float', 'boolean')
        required: Whether the parameter is required
        allowed_values: Allowed values for 'one_of' type parameters
        min: Minimum value for 'numeric_range' type parameters
        max: Maximum value for 'numeric_range' type parameters
        default: Default value when parameter is optional
    """

    parameter: str
    type: str
    value_type: str
    required: bool
    allowed_values: list[str | int] | None = None
    min: float | None = None
    max: float | None = None
    default: str | int | float | bool | None = None


class ModelInfo(BaseModel, kw_only=True):  # pyright: ignore[reportCallIssue]
    """Information about an available model.

    Attributes:
        model: Model name
        short_description: Brief description of the model
        type: Model type ('embed' or 'rerank')
        vector_type: Vector type ('dense' or 'sparse') for embedding models
        default_dimension: Default dimension for dense embedding models
        modality: Model modality (e.g., 'text')
        max_sequence_length: Maximum tokens per sequence
        max_batch_size: Maximum batch size (number of sequences)
        provider_name: Name of the model provider
        supported_dimensions: List of supported dimensions for embedding models
        supported_metrics: List of supported distance metrics for embedding models
        supported_parameters: List of parameters supported by the model
    """

    model: str
    short_description: str
    type: str
    modality: str
    max_sequence_length: int
    max_batch_size: int
    provider_name: str
    supported_parameters: list[ModelInfoSupportedParameter]
    vector_type: str | None = None
    default_dimension: int | None = None
    supported_dimensions: list[int] | None = None
    supported_metrics: list[str] | None = None


class ListModelsResponse(BaseModel, kw_only=True):  # pyright: ignore[reportCallIssue]
    """Response model for list_models operation.

    Attributes:
        models: List of available models
    """

    models: list[ModelInfo]

    def __repr__(self) -> str:
        """Return summary representation."""
        return f"ListModelsResponse(models={len(self.models)})"

    def __dir__(self) -> list[str]:
        """Return public API."""
        attrs = set(super().__dir__())
        public = {name for name in attrs if not name.startswith("_")}
        return sorted(public)

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        """IPython pretty-printer support."""
        if cycle:
            p.text("ListModelsResponse(...)")
            return

        p.text(f"ListModelsResponse(models={len(self.models)})")

    def _repr_html_(self) -> str:
        """Jupyter notebook HTML representation."""
        return render_table(
            "ListModelsResponse",
            [("Models:", len(self.models))],
        )
