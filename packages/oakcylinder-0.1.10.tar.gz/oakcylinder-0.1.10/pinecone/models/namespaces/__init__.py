"""Data models for namespace operations.

Uses lazy loading via __getattr__ to avoid loading all models when only one is needed.
"""

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from pinecone.models.namespaces.delete import DeleteNamespaceResponse
    from pinecone.models.namespaces.list import ListNamespacesResponse
    from pinecone.models.namespaces.namespace import (
        FieldConfig,
        IndexedFields,
        NamespaceDescription,
        NamespaceSchema,
    )

__all__ = [
    "DeleteNamespaceResponse",
    "FieldConfig",
    "IndexedFields",
    "ListNamespacesResponse",
    "NamespaceDescription",
    "NamespaceSchema",
]

_LAZY_IMPORTS = {
    "DeleteNamespaceResponse": "pinecone.models.namespaces.delete",
    "FieldConfig": "pinecone.models.namespaces.namespace",
    "IndexedFields": "pinecone.models.namespaces.namespace",
    "ListNamespacesResponse": "pinecone.models.namespaces.list",
    "NamespaceDescription": "pinecone.models.namespaces.namespace",
    "NamespaceSchema": "pinecone.models.namespaces.namespace",
}


def __getattr__(name: str) -> Any:
    """Lazy-load models on first access."""
    if name in _LAZY_IMPORTS:
        from importlib import import_module

        module = import_module(_LAZY_IMPORTS[name])
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
