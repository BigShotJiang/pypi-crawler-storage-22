"""Data model for delete namespace operation."""

from pinecone.models._base import BaseModel


class DeleteNamespaceResponse(BaseModel, kw_only=True):
    """Response from deleting a namespace.

    The API returns an empty object on success.
    """
