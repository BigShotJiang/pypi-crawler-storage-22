"""Data models for list namespaces operation."""

from msgspec import field

from pinecone.models._base import BaseModel
from pinecone.models.index._common import _Pagination
from pinecone.models.namespaces.namespace import NamespaceDescription


class ListNamespacesResponse(BaseModel, kw_only=True):
    """Response from listing namespaces in a Pinecone index.

    Attributes:
        namespaces: List of namespace descriptions.
        pagination: Pagination information, if more results are available.
        total_count: Total number of namespaces.
    """

    namespaces: list[NamespaceDescription] = field(default_factory=list)
    pagination: _Pagination | None = None
    total_count: int = 0

    @property
    def pagination_token(self) -> str | None:
        """Return the next pagination token, if available."""
        if self.pagination is not None:
            return self.pagination.next
        return None

    def __repr__(self) -> str:
        return (
            f"ListNamespacesResponse(namespaces={len(self.namespaces)}, "
            f"total_count={self.total_count})"
        )
