"""Data models for namespace operations."""

from typing import Any

from pinecone.models._base import BaseModel
from pinecone.models._display import render_table


class FieldConfig(BaseModel, kw_only=True):
    """Configuration for a single field in a namespace schema.

    Attributes:
        filterable: Whether this field is filterable.
    """

    filterable: bool = False


class NamespaceSchema(BaseModel, kw_only=True):
    """Schema definition for a namespace.

    Attributes:
        fields: Mapping of field names to their configuration.
    """

    fields: dict[str, FieldConfig]


class IndexedFields(BaseModel, kw_only=True):
    """Fields that have been indexed in a namespace.

    Attributes:
        fields: List of indexed field names.
    """

    fields: list[str]


class NamespaceDescription(BaseModel, kw_only=True):
    """Description of a namespace in a Pinecone index.

    Attributes:
        name: The namespace name.
        record_count: Number of records in the namespace.
        schema: Optional schema definition for the namespace.
        indexed_fields: Optional list of indexed fields.
    """

    name: str = ""
    record_count: int = 0
    schema: NamespaceSchema | None = None
    indexed_fields: IndexedFields | None = None

    def __repr__(self) -> str:
        return f"NamespaceDescription(name={self.name!r}, record_count={self.record_count})"

    def __dir__(self) -> list[str]:
        """Return public API, hiding internal attributes."""
        attrs = set(super().__dir__())
        public = {name for name in attrs if not name.startswith("_")}
        return sorted(public)

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        """IPython pretty-printer support."""
        if cycle:
            p.text("NamespaceDescription(...)")
            return

        p.text("NamespaceDescription(")
        with p.group(2, "", ")"):
            p.breakable()
            p.text(f"name={self.name!r},")
            p.breakable()
            p.text(f"record_count={self.record_count}")

            if self.schema is not None:
                p.breakable()
                p.text(f"schema={self.schema!r}")
            if self.indexed_fields is not None:
                p.breakable()
                p.text(f"indexed_fields={self.indexed_fields!r}")

    def _repr_html_(self) -> str:
        """Jupyter notebook HTML representation."""
        rows: list[tuple[str, str | int]] = [
            ("Name:", self.name),
            ("Record Count:", self.record_count),
        ]

        if self.schema is not None:
            field_names = ", ".join(self.schema.fields.keys()) if self.schema.fields else "none"
            rows.append(("Schema Fields:", field_names))
        if self.indexed_fields is not None:
            indexed = (
                ", ".join(self.indexed_fields.fields) if self.indexed_fields.fields else "none"
            )
            rows.append(("Indexed Fields:", indexed))

        return render_table("NamespaceDescription", rows)
