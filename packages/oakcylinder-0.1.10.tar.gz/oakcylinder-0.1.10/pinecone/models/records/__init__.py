"""Data models for Pinecone records API operations.

Uses lazy loading via __getattr__ to avoid loading all models when only one is needed.
"""

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from pinecone.models.records.search import (
        Hit,
        SearchRecordsResponse,
        SearchUsage,
    )

__all__ = [
    "Hit",
    "SearchRecordsResponse",
    "SearchUsage",
]

_LAZY_IMPORTS = {
    "Hit": "pinecone.models.records.search",
    "SearchRecordsResponse": "pinecone.models.records.search",
    "SearchUsage": "pinecone.models.records.search",
}


def __getattr__(name: str) -> Any:
    """Lazy-load models on first access."""
    if name in _LAZY_IMPORTS:
        from importlib import import_module

        module = import_module(_LAZY_IMPORTS[name])
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
