"""Data models for Restore Job API.

Uses lazy loading via __getattr__ to maintain import performance.
"""

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from pinecone.models.restore_jobs.restore_job import RestoreJobModel

__all__ = [
    "RestoreJobModel",
]

_LAZY_IMPORTS = {
    "RestoreJobModel": "pinecone.models.restore_jobs.restore_job",
}


def __getattr__(name: str) -> Any:
    """Lazy-load models on first access."""
    if name in _LAZY_IMPORTS:
        from importlib import import_module

        module = import_module(_LAZY_IMPORTS[name])
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
