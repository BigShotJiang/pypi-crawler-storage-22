"""Restore job metadata model."""

from __future__ import annotations

from typing import Any

from pinecone.__interface__ import RestoreJobStatus  # noqa: TC001
from pinecone.models._base import BaseModel
from pinecone.models._display import render_table


class RestoreJobModel(BaseModel, kw_only=True, omit_defaults=True):  # pyright: ignore[reportCallIssue]
    """Restore job metadata from API.

    This model represents the complete restore job information returned by the
    Pinecone API. All fields map directly to the API response schema.

    Attributes:
        restore_job_id: Unique identifier for the restore job.
        backup_id: ID of the backup being restored.
        target_index_name: Name of the index being restored to.
        target_index_id: ID of the target index.
        status: Current status of the restore job.
        created_at: ISO 8601 timestamp when the job was created.
        completed_at: ISO 8601 timestamp when job completed (None if in progress).
        percent_complete: Progress percentage (0-100, None if not available).
    """

    restore_job_id: str
    backup_id: str
    target_index_name: str
    target_index_id: str
    status: RestoreJobStatus
    created_at: str
    completed_at: str | None = None
    percent_complete: float | None = None

    def __repr__(self) -> str:
        """Return developer-friendly representation.

        Shows key metadata without overwhelming with all fields.
        """
        status_str = f"status={self.status!r}"
        progress_str = (
            f"progress={self.percent_complete}%"
            if self.percent_complete is not None
            else "progress=unknown"
        )

        return (
            f"RestoreJobModel(restore_job_id={self.restore_job_id!r}, "
            f"target={self.target_index_name!r}, {status_str}, {progress_str})"
        )

    def __dir__(self) -> list[str]:
        """Return public API, hiding internal attributes."""
        attrs = set(super().__dir__())
        public = {name for name in attrs if not name.startswith("_")}
        return sorted(public)

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        """IPython pretty-printer support."""
        if cycle:
            p.text("RestoreJobModel(...)")
            return

        p.text("RestoreJobModel(")
        with p.group(2, "", ")"):
            p.breakable()
            p.text(f"restore_job_id={self.restore_job_id!r},")
            p.breakable()
            p.text(f"backup_id={self.backup_id!r},")
            p.breakable()
            p.text(f"target_index_name={self.target_index_name!r},")
            p.breakable()
            p.text(f"target_index_id={self.target_index_id!r},")
            p.breakable()
            p.text(f"status={self.status!r},")
            p.breakable()
            p.text(f"created_at={self.created_at!r}")

            if self.completed_at is not None:
                p.breakable()
                p.text(f"completed_at={self.completed_at!r}")
            if self.percent_complete is not None:
                p.breakable()
                p.text(f"percent_complete={self.percent_complete}")

    def _repr_html_(self) -> str:
        """Jupyter notebook HTML representation."""
        rows: list[tuple[str, str | int | float]] = [
            ("Restore Job ID:", self.restore_job_id),
            ("Backup ID:", self.backup_id),
            ("Target Index:", self.target_index_name),
            ("Target Index ID:", self.target_index_id),
            ("Status:", self.status),
            ("Created:", self.created_at),
        ]

        if self.completed_at is not None:
            rows.append(("Completed:", self.completed_at))
        if self.percent_complete is not None:
            rows.append(("Progress:", f"{self.percent_complete}%"))

        return render_table("RestoreJobModel", rows)
