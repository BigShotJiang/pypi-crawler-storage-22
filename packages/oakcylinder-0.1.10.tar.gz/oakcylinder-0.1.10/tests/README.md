# Test Suite

This directory contains the test suite for the Pinecone Python SDK.

## Directory Structure

```
tests/
├── conftest.py          # Shared fixtures and pytest configuration
├── specification/       # Protocol compliance and API surface tests
├── unit/                # Fast, isolated unit tests
├── integration/         # End-to-end tests against real API
└── examples/            # Executable docstring examples
```

## Running Tests

### All Tests

```bash
uv run pytest
```

### By Test Type

```bash
# Unit tests only
uv run pytest -m unit

# Integration tests only (requires PINECONE_API_KEY)
uv run pytest -m integration

# Exclude slow tests
uv run pytest -m "not slow"
```

### Specific Directories

```bash
# Specification tests
uv run pytest tests/specification/

# Unit tests
uv run pytest tests/unit/

# Integration tests
uv run pytest tests/integration/
```

## Test Markers

The test suite uses pytest markers to categorize tests:

- `unit` - Fast unit tests that don't require external services
- `integration` - Tests that require a real Pinecone API connection
- `asyncio` - Async tests
- `slow` - Tests that take longer to run

## Environment Variables

For integration tests, set these environment variables:

```bash
export PINECONE_API_KEY="your-api-key"
export PINECONE_INDEX_HOST="your-index-host"  # Optional
export PINECONE_TEST_INDEX_NAME="test-index"  # Optional, defaults to "test-index"
```

Or create a `.env` file in the `tests/` directory (gitignored).

## Coverage

Coverage reports are generated automatically when running tests:

```bash
# Terminal report (default)
uv run pytest

# HTML report
open htmlcov/index.html
```

## Writing Tests

See the README in each subdirectory for patterns and conventions specific to that test type.
