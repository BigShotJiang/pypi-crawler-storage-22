# Example Tests

Executable tests for docstring examples and documentation code blocks.

## Purpose

- Verify docstring examples work correctly
- Test README code examples
- Ensure documentation stays in sync with code

## Running

```bash
uv run pytest tests/examples/
```

## Patterns

### Testing Docstring Examples

Use pytest's doctest integration or extract and execute examples:

```python
def test_client_docstring_example():
    """Test example from Pinecone client docstring."""
    # Extract example code from docstring
    # Execute in controlled environment
    # Verify expected behavior
```

### Mocking for Examples

Examples that require API access should be mocked:

```python
@respx.mock
def test_readme_quickstart():
    """Test the README quickstart example."""
    # Mock API responses
    respx.post(...).mock(...)

    # Execute example code
    pc = Pinecone(api_key="test-key")
    # ...
```

## Maintenance

When updating docstrings or documentation:

1. Run example tests to verify changes
2. Update tests if example behavior changes
3. Add new tests for new examples
