"""Executable docstring example tests."""
