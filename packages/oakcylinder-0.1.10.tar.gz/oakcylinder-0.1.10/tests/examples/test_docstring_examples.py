"""Docstring example tests.

Tests that verify docstring examples are correct and executable.
"""

from __future__ import annotations

import httpx
import pytest
import respx

from pinecone import (
    APIError,
    HTTPClient,
    HTTPConfig,
    NotFoundError,
    RateLimitError,
)


class TestHTTPClientExamples:
    """Test examples from HTTPClient docstrings."""

    @respx.mock
    def test_basic_get_request(self):
        """Test basic GET request pattern from docs."""
        # Mock the API response
        respx.get("https://api.pinecone.io/indexes").mock(
            return_value=httpx.Response(200, json={"indexes": []})
        )

        # Example pattern: create client and make request
        client = HTTPClient(api_key="test-key")
        response = client.get("https://api.pinecone.io/indexes")

        assert response.status_code == 200
        assert response.json() == {"indexes": []}

    @respx.mock
    def test_context_manager_pattern(self):
        """Test context manager pattern from docs."""
        respx.get("https://api.pinecone.io/indexes").mock(
            return_value=httpx.Response(200, json={"indexes": []})
        )

        # Example pattern: use client as context manager
        with HTTPClient(api_key="test-key") as client:
            response = client.get("https://api.pinecone.io/indexes")
            assert response.status_code == 200


class TestHTTPConfigExamples:
    """Test examples from HTTPConfig docstrings."""

    def test_custom_config_pattern(self):
        """Test custom config pattern from docs."""
        # Example pattern: create config with custom values
        config = HTTPConfig(
            timeout=60,
            max_retries=5,
            http2=True,
        )

        client = HTTPClient(api_key="test-key", config=config)

        assert client._config.timeout == 60
        assert client._config.max_retries == 5
        assert client._config.http2 is True


class TestExceptionExamples:
    """Test exception handling patterns from docs."""

    @respx.mock
    def test_catch_api_error(self):
        """Test catching API errors pattern."""
        respx.get("https://api.pinecone.io/test").mock(
            return_value=httpx.Response(400, json={"message": "Bad request"})
        )

        client = HTTPClient(api_key="test-key")

        # Example pattern: catch specific API error
        with pytest.raises(APIError) as exc_info:
            client.get("https://api.pinecone.io/test")

        assert exc_info.value.status_code == 400
        assert "Bad request" in str(exc_info.value)

    @respx.mock
    def test_catch_not_found_error(self):
        """Test catching not found error pattern."""
        respx.get("https://api.pinecone.io/indexes/nonexistent").mock(
            return_value=httpx.Response(404, json={"message": "Index not found"})
        )

        client = HTTPClient(api_key="test-key")

        # Example pattern: catch not found
        with pytest.raises(NotFoundError):
            client.get("https://api.pinecone.io/indexes/nonexistent")

    @respx.mock
    def test_catch_rate_limit_with_retry_after(self):
        """Test handling rate limit with Retry-After header."""
        respx.get("https://api.pinecone.io/test").mock(
            return_value=httpx.Response(429, headers={"Retry-After": "60"})
        )

        # Disable retries for this test
        config = HTTPConfig(max_retries=1)
        client = HTTPClient(api_key="test-key", config=config)

        with pytest.raises(RateLimitError) as exc_info:
            client.get("https://api.pinecone.io/test")

        assert exc_info.value.retry_after == 60
