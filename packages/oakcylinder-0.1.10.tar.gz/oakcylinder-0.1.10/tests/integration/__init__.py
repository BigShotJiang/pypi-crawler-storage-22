"""Integration tests requiring real Pinecone API access."""
