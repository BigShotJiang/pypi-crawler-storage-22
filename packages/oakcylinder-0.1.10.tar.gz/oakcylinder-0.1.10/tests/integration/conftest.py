"""Integration test fixtures and configuration.

This module provides fixtures specific to integration tests that run
against the real Pinecone API.
"""

from __future__ import annotations

import os
import uuid

import pytest

from pinecone import Pinecone  # noqa: TC001


@pytest.fixture()
def unique_index_name() -> str:
    """Generate a unique index name for tests.

    Creates a unique name using UUID to avoid collisions between test runs.

    Returns:
        A unique index name string.
    """
    return f"test-{uuid.uuid4().hex[:8]}"


@pytest.fixture()
def test_namespace() -> str:
    """Get test namespace name.

    Returns:
        Namespace name for test isolation.
    """
    return f"test-ns-{uuid.uuid4().hex[:8]}"


@pytest.fixture(scope="session")
def integration_index_name() -> str:
    """Get or create an index name for integration tests.

    Uses PINECONE_TEST_INDEX_NAME if set, otherwise generates a unique name.
    The session scope means the same index is reused across all tests in
    the session.

    Returns:
        Index name for integration tests.
    """
    return os.getenv("PINECONE_TEST_INDEX_NAME", f"integration-test-{uuid.uuid4().hex[:8]}")


@pytest.fixture()
def cleanup_index(
    integration_client: Pinecone,
) -> list[str]:
    """Fixture that tracks and cleans up indexes created during tests.

    Returns a list that tests can append index names to. After the test
    completes, all listed indexes should be deleted.

    Args:
        integration_client: The Pinecone client fixture.

    Returns:
        A list to append index names for cleanup.

    Note:
        Index deletion is currently not implemented as the indexes namespace
        doesn't exist yet. When index management is added (SDK-551), update this
        fixture to use a generator pattern with teardown that calls:
        integration_client.indexes.delete(index_name) for each index in the list.
    """
    indexes_to_cleanup: list[str] = []
    return indexes_to_cleanup
