"""Test async integration fixtures."""

from __future__ import annotations

import pytest

from pinecone import AsyncPinecone


pytestmark = [pytest.mark.integration, pytest.mark.asyncio]


class TestAsyncFixtures:
    """Test async integration test fixtures."""

    async def test_async_integration_client_fixture(
        self,
        async_integration_client: AsyncPinecone,
    ) -> None:
        """Test that async_integration_client fixture provides AsyncPinecone instance.

        Args:
            async_integration_client: The async Pinecone client fixture.
        """
        assert isinstance(async_integration_client, AsyncPinecone)
