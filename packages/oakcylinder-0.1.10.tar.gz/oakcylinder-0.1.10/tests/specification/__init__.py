"""Specification tests for protocol compliance and API surface verification."""
