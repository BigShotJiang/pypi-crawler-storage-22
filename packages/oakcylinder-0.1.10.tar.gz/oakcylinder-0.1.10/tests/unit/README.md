# Unit Tests

Fast, isolated tests that verify individual components work correctly.

## Purpose

- Test individual functions, methods, and classes in isolation
- Mock external dependencies (HTTP, filesystem, etc.)
- Run quickly without external services

## Running

```bash
# All unit tests
uv run pytest tests/unit/

# Specific module
uv run pytest tests/unit/http/

# With marker
uv run pytest -m unit
```

## Patterns

### Mocking HTTP Requests

Use `respx` to mock HTTP requests:

```python
import respx
import httpx

@respx.mock
def test_api_call():
    respx.get("https://api.pinecone.io/indexes").mock(
        return_value=httpx.Response(200, json={"indexes": []})
    )
    # Test code that makes HTTP requests
```

### Test Organization

Group related tests in classes:

```python
class TestIndexOperations:
    """Tests for index CRUD operations."""

    def test_create_index(self):
        ...

    def test_delete_index(self):
        ...
```

### Fixtures

Common fixtures are available from `conftest.py`:

- `mock_http_client` - Pre-configured respx mock router
- `sample_vectors` - Sample vector data for testing

## Directory Structure

```
unit/
├── conftest.py      # Unit test fixtures
├── http/            # HTTP client tests
├── adapters/        # Adapter tests
└── models/          # Model tests
```
