"""Unit test fixtures and configuration.

This module provides fixtures specific to unit tests, focusing on
fast, isolated testing with mocked dependencies.
"""

from __future__ import annotations

import pytest


@pytest.fixture()
def test_api_key() -> str:
    """Test API key for unit tests.

    Returns a fake API key for use in unit tests that don't make real API calls.

    Returns:
        A fake API key string.
    """
    return "test-api-key-12345"


@pytest.fixture()
def test_index_host() -> str:
    """Test index host for unit tests.

    Returns a fake index host for use in unit tests.

    Returns:
        A fake index host URL.
    """
    return "test-index-12345.svc.pinecone.io"
