"""HTTP client tests."""
