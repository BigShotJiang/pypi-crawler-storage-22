"""Tests for configure() validation (2026-01.alpha API).

Tests that configure() properly validates parameters and rejects empty dicts,
matching the behavior of the old API (indexes_old.configure()).
"""

import pytest
import respx

from httpx import Response

from pinecone import AsyncPinecone, Pinecone


class TestConfigureValidation:
    """Test configure() parameter validation."""

    def test_configure_requires_at_least_one_parameter(self):
        """Test that at least one parameter is required."""
        pc = Pinecone(api_key="test-key")
        with pytest.raises(ValueError, match="At least one configuration parameter"):
            pc.indexes.configure("test-index")

    def test_configure_rejects_empty_schema_dict(self):
        """Test that empty schema dict is rejected."""
        pc = Pinecone(api_key="test-key")
        with pytest.raises(ValueError, match="schema cannot be an empty dict"):
            pc.indexes.configure("test-index", schema={})

    def test_configure_rejects_empty_deployment_dict(self):
        """Test that empty deployment dict is rejected."""
        pc = Pinecone(api_key="test-key")
        with pytest.raises(ValueError, match="deployment cannot be an empty dict"):
            pc.indexes.configure("test-index", deployment={})

    def test_configure_rejects_empty_read_capacity_dict(self):
        """Test that empty read_capacity dict is rejected."""
        pc = Pinecone(api_key="test-key")
        with pytest.raises(ValueError, match="read_capacity cannot be an empty dict"):
            pc.indexes.configure("test-index", read_capacity={})

    def test_configure_rejects_empty_tags_dict(self):
        """Test that empty tags dict is rejected."""
        pc = Pinecone(api_key="test-key")
        with pytest.raises(ValueError, match="tags cannot be an empty dict"):
            pc.indexes.configure("test-index", tags={})

    def test_configure_rejects_empty_schema_dict_with_valid_parameter(self):
        """Test that empty schema dict is rejected even when combined with valid parameter."""
        pc = Pinecone(api_key="test-key")
        with pytest.raises(ValueError, match="schema cannot be an empty dict"):
            pc.indexes.configure("test-index", deletion_protection="enabled", schema={})

    def test_configure_rejects_empty_deployment_dict_with_valid_parameter(self):
        """Test that empty deployment dict is rejected even when combined with valid parameter."""
        pc = Pinecone(api_key="test-key")
        with pytest.raises(ValueError, match="deployment cannot be an empty dict"):
            pc.indexes.configure("test-index", deletion_protection="enabled", deployment={})

    def test_configure_rejects_empty_read_capacity_dict_with_valid_parameter(self):
        """Test that empty read_capacity dict is rejected even when combined with valid parameter."""
        pc = Pinecone(api_key="test-key")
        with pytest.raises(ValueError, match="read_capacity cannot be an empty dict"):
            pc.indexes.configure("test-index", deletion_protection="enabled", read_capacity={})

    def test_configure_rejects_empty_tags_dict_with_valid_parameter(self):
        """Test that empty tags dict is rejected even when combined with valid parameter."""
        pc = Pinecone(api_key="test-key")
        with pytest.raises(ValueError, match="tags cannot be an empty dict"):
            pc.indexes.configure("test-index", deletion_protection="enabled", tags={})

    def test_configure_validates_tag_key_length(self):
        """Test validation of tag key length."""
        pc = Pinecone(api_key="test-key")
        long_key = "x" * 81
        with pytest.raises(ValueError, match=r"Tag key.*exceeds 80 character limit"):
            pc.indexes.configure("test-index", tags={long_key: "value"})

    def test_configure_validates_tag_value_length(self):
        """Test validation of tag value length."""
        pc = Pinecone(api_key="test-key")
        long_value = "x" * 121
        with pytest.raises(ValueError, match=r"Tag value.*exceeds 120 character limit"):
            pc.indexes.configure("test-index", tags={"key": long_value})


class TestConfigureAsyncValidation:
    """Test async configure() parameter validation."""

    @pytest.mark.asyncio()
    async def test_configure_requires_at_least_one_parameter(self):
        """Test that at least one parameter is required."""
        async with AsyncPinecone(api_key="test-key") as pc:
            with pytest.raises(ValueError, match="At least one configuration parameter"):
                await pc.indexes.configure("test-index")

    @pytest.mark.asyncio()
    async def test_configure_rejects_empty_schema_dict(self):
        """Test that empty schema dict is rejected."""
        async with AsyncPinecone(api_key="test-key") as pc:
            with pytest.raises(ValueError, match="schema cannot be an empty dict"):
                await pc.indexes.configure("test-index", schema={})

    @pytest.mark.asyncio()
    async def test_configure_rejects_empty_deployment_dict(self):
        """Test that empty deployment dict is rejected."""
        async with AsyncPinecone(api_key="test-key") as pc:
            with pytest.raises(ValueError, match="deployment cannot be an empty dict"):
                await pc.indexes.configure("test-index", deployment={})

    @pytest.mark.asyncio()
    async def test_configure_rejects_empty_read_capacity_dict(self):
        """Test that empty read_capacity dict is rejected."""
        async with AsyncPinecone(api_key="test-key") as pc:
            with pytest.raises(ValueError, match="read_capacity cannot be an empty dict"):
                await pc.indexes.configure("test-index", read_capacity={})

    @pytest.mark.asyncio()
    async def test_configure_rejects_empty_tags_dict(self):
        """Test that empty tags dict is rejected."""
        async with AsyncPinecone(api_key="test-key") as pc:
            with pytest.raises(ValueError, match="tags cannot be an empty dict"):
                await pc.indexes.configure("test-index", tags={})

    @pytest.mark.asyncio()
    async def test_configure_rejects_empty_schema_dict_with_valid_parameter(self):
        """Test that empty schema dict is rejected even when combined with valid parameter."""
        async with AsyncPinecone(api_key="test-key") as pc:
            with pytest.raises(ValueError, match="schema cannot be an empty dict"):
                await pc.indexes.configure("test-index", deletion_protection="enabled", schema={})

    @pytest.mark.asyncio()
    async def test_configure_rejects_empty_deployment_dict_with_valid_parameter(self):
        """Test that empty deployment dict is rejected even when combined with valid parameter."""
        async with AsyncPinecone(api_key="test-key") as pc:
            with pytest.raises(ValueError, match="deployment cannot be an empty dict"):
                await pc.indexes.configure(
                    "test-index", deletion_protection="enabled", deployment={}
                )

    @pytest.mark.asyncio()
    async def test_configure_rejects_empty_read_capacity_dict_with_valid_parameter(self):
        """Test that empty read_capacity dict is rejected even when combined with valid parameter."""
        async with AsyncPinecone(api_key="test-key") as pc:
            with pytest.raises(ValueError, match="read_capacity cannot be an empty dict"):
                await pc.indexes.configure(
                    "test-index", deletion_protection="enabled", read_capacity={}
                )

    @pytest.mark.asyncio()
    async def test_configure_rejects_empty_tags_dict_with_valid_parameter(self):
        """Test that empty tags dict is rejected even when combined with valid parameter."""
        async with AsyncPinecone(api_key="test-key") as pc:
            with pytest.raises(ValueError, match="tags cannot be an empty dict"):
                await pc.indexes.configure("test-index", deletion_protection="enabled", tags={})

    @pytest.mark.asyncio()
    async def test_configure_validates_tag_key_length(self):
        """Test validation of tag key length."""
        async with AsyncPinecone(api_key="test-key") as pc:
            long_key = "x" * 81
            with pytest.raises(ValueError, match=r"Tag key.*exceeds 80 character limit"):
                await pc.indexes.configure("test-index", tags={long_key: "value"})

    @pytest.mark.asyncio()
    async def test_configure_validates_tag_value_length(self):
        """Test validation of tag value length."""
        async with AsyncPinecone(api_key="test-key") as pc:
            long_value = "x" * 121
            with pytest.raises(ValueError, match=r"Tag value.*exceeds 120 character limit"):
                await pc.indexes.configure("test-index", tags={"key": long_value})


@respx.mock
class TestConfigureRequestBody:
    """Test that configure() request bodies omit null values and empty dicts."""

    def test_configure_request_omits_null_values(self):
        """Test that only provided parameters are sent in request body."""
        # Mock API response
        route = respx.patch("https://api.pinecone.io/indexes/test-index").mock(
            return_value=Response(
                200,
                json={
                    "name": "test-index",
                    "schema": {
                        "fields": {
                            "embedding": {
                                "type": "dense_vector",
                                "dimension": 1536,
                                "metric": "cosine",
                            }
                        }
                    },
                    "deployment": {
                        "deployment_type": "managed",
                        "environment": "test",
                        "cloud": "aws",
                        "region": "us-east-1",
                    },
                    "host": "test-index.svc.pinecone.io",
                    "status": {"ready": True, "state": "Ready"},
                    "deletion_protection": "enabled",
                },
            )
        )

        pc = Pinecone(api_key="test-key")
        pc.indexes.configure("test-index", deletion_protection="enabled")

        # Verify request body only contains deletion_protection, not null values
        request = route.calls[0].request
        body = request.content.decode()
        assert "deletion_protection" in body
        assert body.count("null") == 0, f"Request body should not contain null values: {body}"

    def test_configure_with_tags_only_sends_tags(self):
        """Test that configure with only tags sends minimal request body."""
        route = respx.patch("https://api.pinecone.io/indexes/test-index").mock(
            return_value=Response(
                200,
                json={
                    "name": "test-index",
                    "schema": {
                        "fields": {
                            "embedding": {
                                "type": "dense_vector",
                                "dimension": 1536,
                                "metric": "cosine",
                            }
                        }
                    },
                    "deployment": {
                        "deployment_type": "managed",
                        "environment": "test",
                        "cloud": "aws",
                        "region": "us-east-1",
                    },
                    "host": "test-index.svc.pinecone.io",
                    "status": {"ready": True, "state": "Ready"},
                    "tags": {"env": "prod"},
                },
            )
        )

        pc = Pinecone(api_key="test-key")
        pc.indexes.configure("test-index", tags={"env": "prod"})

        # Verify request body only contains tags, not null values
        request = route.calls[0].request
        body = request.content.decode()
        assert "tags" in body
        assert "env" in body
        assert "prod" in body
        assert body.count("null") == 0, f"Request body should not contain null values: {body}"

    def test_configure_with_multiple_params(self):
        """Test that configure with multiple parameters sends all of them."""
        route = respx.patch("https://api.pinecone.io/indexes/test-index").mock(
            return_value=Response(
                200,
                json={
                    "name": "test-index",
                    "schema": {
                        "fields": {
                            "embedding": {
                                "type": "dense_vector",
                                "dimension": 1536,
                                "metric": "cosine",
                            }
                        }
                    },
                    "deployment": {
                        "deployment_type": "managed",
                        "environment": "test",
                        "cloud": "aws",
                        "region": "us-east-1",
                    },
                    "host": "test-index.svc.pinecone.io",
                    "status": {"ready": True, "state": "Ready"},
                    "deletion_protection": "enabled",
                    "tags": {"env": "staging"},
                },
            )
        )

        pc = Pinecone(api_key="test-key")
        pc.indexes.configure("test-index", deletion_protection="enabled", tags={"env": "staging"})

        # Verify request body contains both parameters, no nulls
        request = route.calls[0].request
        body = request.content.decode()
        assert "deletion_protection" in body
        assert "enabled" in body
        assert "tags" in body
        assert "env" in body
        assert "staging" in body
        assert body.count("null") == 0, f"Request body should not contain null values: {body}"


@respx.mock
class TestConfigureAsyncRequestBody:
    """Test that async configure() request bodies omit null values."""

    @pytest.mark.asyncio()
    async def test_configure_request_omits_null_values(self):
        """Test that only provided parameters are sent in request body."""
        route = respx.patch("https://api.pinecone.io/indexes/test-index").mock(
            return_value=Response(
                200,
                json={
                    "name": "test-index",
                    "schema": {
                        "fields": {
                            "embedding": {
                                "type": "dense_vector",
                                "dimension": 1536,
                                "metric": "cosine",
                            }
                        }
                    },
                    "deployment": {
                        "deployment_type": "managed",
                        "environment": "test",
                        "cloud": "aws",
                        "region": "us-east-1",
                    },
                    "host": "test-index.svc.pinecone.io",
                    "status": {"ready": True, "state": "Ready"},
                    "deletion_protection": "enabled",
                },
            )
        )

        async with AsyncPinecone(api_key="test-key") as pc:
            await pc.indexes.configure("test-index", deletion_protection="enabled")

        # Verify request body only contains deletion_protection, not null values
        request = route.calls[0].request
        body = request.content.decode()
        assert "deletion_protection" in body
        assert body.count("null") == 0, f"Request body should not contain null values: {body}"

    @pytest.mark.asyncio()
    async def test_configure_with_tags_only_sends_tags(self):
        """Test that configure with only tags sends minimal request body."""
        route = respx.patch("https://api.pinecone.io/indexes/test-index").mock(
            return_value=Response(
                200,
                json={
                    "name": "test-index",
                    "schema": {
                        "fields": {
                            "embedding": {
                                "type": "dense_vector",
                                "dimension": 1536,
                                "metric": "cosine",
                            }
                        }
                    },
                    "deployment": {
                        "deployment_type": "managed",
                        "environment": "test",
                        "cloud": "aws",
                        "region": "us-east-1",
                    },
                    "host": "test-index.svc.pinecone.io",
                    "status": {"ready": True, "state": "Ready"},
                    "tags": {"env": "prod"},
                },
            )
        )

        async with AsyncPinecone(api_key="test-key") as pc:
            await pc.indexes.configure("test-index", tags={"env": "prod"})

        # Verify request body only contains tags, not null values
        request = route.calls[0].request
        body = request.content.decode()
        assert "tags" in body
        assert "env" in body
        assert "prod" in body
        assert body.count("null") == 0, f"Request body should not contain null values: {body}"
