"""Basic unit tests for indexes namespace (2026-01.alpha API)."""

import respx

from httpx import Response

from pinecone import Pinecone


@respx.mock
def test_list_indexes():
    """Test list operation returns iterable Paginator."""
    # Mock API response
    respx.get("https://api.pinecone.io/indexes").mock(
        return_value=Response(
            200,
            json={
                "indexes": [
                    {
                        "name": "test-index",
                        "schema": {
                            "fields": {
                                "embedding": {
                                    "type": "dense_vector",
                                    "dimension": 1536,
                                    "metric": "cosine",
                                }
                            }
                        },
                        "deployment": {
                            "deployment_type": "managed",
                            "environment": "aped-4627-b74a",
                            "cloud": "aws",
                            "region": "us-east-1",
                        },
                        "host": "test-index-abc123.svc.us-east-1-aws.pinecone.io",
                        "status": {"ready": True, "state": "Ready"},
                        "deletion_protection": "disabled",
                    }
                ]
            },
        )
    )

    # Call list
    pc = Pinecone(api_key="test-key")
    paginator = pc.indexes.list()

    # Verify result is iterable
    indexes = list(paginator)
    assert len(indexes) == 1
    assert indexes[0].name == "test-index"
    assert indexes[0].schema.fields["embedding"].dimension == 1536  # type: ignore[attr-defined]
    # Deployment is correctly deserialized as ManagedDeployment
    from pinecone.models.indexes import ManagedDeployment

    assert isinstance(indexes[0].deployment, ManagedDeployment)
    assert indexes[0].deployment.cloud == "aws"
    assert indexes[0].deployment.region == "us-east-1"


@respx.mock
def test_describe_index():
    """Test describe operation returns IndexModel."""
    # Mock API response
    respx.get("https://api.pinecone.io/indexes/test-index").mock(
        return_value=Response(
            200,
            json={
                "name": "test-index",
                "schema": {
                    "fields": {
                        "embedding": {
                            "type": "dense_vector",
                            "dimension": 768,
                            "metric": "cosine",
                            "description": "BERT embeddings",
                        },
                        "title": {"type": "string", "full_text_searchable": True},
                    }
                },
                "deployment": {
                    "deployment_type": "managed",
                    "environment": "aped-4627-b74a",
                    "cloud": "aws",
                    "region": "us-east-1",
                },
                "host": "test-index-abc123.svc.us-east-1-aws.pinecone.io",
                "status": {"ready": True, "state": "Ready"},
                "deletion_protection": "enabled",
                "tags": {"environment": "production"},
            },
        )
    )

    # Call describe
    pc = Pinecone(api_key="test-key")
    index = pc.indexes.describe("test-index")

    # Verify result
    assert index.name == "test-index"
    assert len(index.schema.fields) == 2
    # Verify field types via isinstance
    from pinecone.models.indexes import DenseVectorField, StringField

    assert isinstance(index.schema.fields["embedding"], DenseVectorField)
    assert isinstance(index.schema.fields["title"], StringField)
    assert index.schema.fields["embedding"].dimension == 768  # type: ignore[attr-defined]
    assert index.schema.fields["title"].full_text_searchable is True  # type: ignore[attr-defined]
    assert index.deletion_protection == "enabled"
    assert index.tags == {"environment": "production"}


@respx.mock
def test_create_index_minimal():
    """Test create with minimal configuration."""
    # Mock API response
    respx.post("https://api.pinecone.io/indexes").mock(
        return_value=Response(
            201,
            json={
                "name": "my-index",
                "schema": {
                    "fields": {
                        "embedding": {"type": "dense_vector", "dimension": 1536, "metric": "cosine"}
                    }
                },
                "deployment": {
                    "deployment_type": "managed",
                    "environment": "aped-4627-b74a",
                    "cloud": "aws",
                    "region": "us-east-1",
                },
                "host": "my-index-abc123.svc.us-east-1-aws.pinecone.io",
                "status": {"ready": False, "state": "Initializing"},
                "deletion_protection": "disabled",
            },
        )
    )

    # Call create
    pc = Pinecone(api_key="test-key")
    index = pc.indexes.create(
        name="my-index",
        schema={
            "fields": {"embedding": {"type": "dense_vector", "dimension": 1536, "metric": "cosine"}}
        },
    )

    # Verify result
    assert index.name == "my-index"
    assert index.status.state == "Initializing"
    assert index.status.ready is False


@respx.mock
def test_delete_index():
    """Test delete operation."""
    # Mock API response
    respx.delete("https://api.pinecone.io/indexes/test-index").mock(return_value=Response(202))

    # Call delete
    pc = Pinecone(api_key="test-key")
    pc.indexes.delete("test-index")

    # Verify no exception raised


@respx.mock
def test_configure_index():
    """Test configure operation."""
    # Mock API response
    respx.patch("https://api.pinecone.io/indexes/test-index").mock(
        return_value=Response(
            202,
            json={
                "name": "test-index",
                "schema": {
                    "fields": {
                        "embedding": {"type": "dense_vector", "dimension": 1536, "metric": "cosine"}
                    }
                },
                "deployment": {
                    "deployment_type": "managed",
                    "environment": "aped-4627-b74a",
                    "cloud": "aws",
                    "region": "us-east-1",
                },
                "host": "test-index-abc123.svc.us-east-1-aws.pinecone.io",
                "status": {"ready": True, "state": "Ready"},
                "deletion_protection": "enabled",
            },
        )
    )

    # Call configure
    pc = Pinecone(api_key="test-key")
    index = pc.indexes.configure("test-index", deletion_protection="enabled")

    # Verify result
    assert index.deletion_protection == "enabled"


@respx.mock
def test_indexes_old_still_works():
    """Verify old API is still accessible via indexes_old."""
    # Mock API response for old API
    respx.get("https://api.pinecone.io/indexes").mock(
        return_value=Response(200, json={"indexes": []})
    )

    # Call old API
    pc = Pinecone(api_key="test-key")
    result = pc.indexes_old.list()

    # Verify it works
    assert hasattr(result, "__iter__")
