"""Tests for Jupyter display utilities."""

from pinecone.models._display import render_table


class TestRenderTable:
    """Tests for render_table function."""

    def test_renders_basic_table(self) -> None:
        """Should render an HTML table with title and rows."""
        html = render_table("TestResponse", [("Label:", "value"), ("Count:", 42)])

        assert "TestResponse" in html
        assert "Label:" in html
        assert "value" in html
        assert "Count:" in html
        assert "42" in html
        assert "<table" in html
        assert "<tr>" in html
        assert "<td" in html

    def test_escapes_html_in_title(self) -> None:
        """Should HTML-escape the title."""
        html = render_table("<script>alert('xss')</script>", [("Label:", "value")])

        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_escapes_html_in_labels(self) -> None:
        """Should HTML-escape label text."""
        html = render_table("Title", [("<b>Bold:</b>", "value")])

        assert "<b>Bold:</b>" not in html
        assert "&lt;b&gt;Bold:&lt;/b&gt;" in html

    def test_escapes_html_in_values(self) -> None:
        """Should HTML-escape value text."""
        html = render_table("Title", [("Label:", "<script>alert('xss')</script>")])

        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_converts_int_values_to_string(self) -> None:
        """Should handle integer values."""
        html = render_table("Title", [("Count:", 123)])

        assert "123" in html

    def test_handles_empty_rows(self) -> None:
        """Should handle empty rows list."""
        html = render_table("EmptyResponse", [])

        assert "EmptyResponse" in html
        assert "<table" in html
        assert "<tr>" not in html

    def test_handles_single_row(self) -> None:
        """Should handle a single row."""
        html = render_table("SingleRow", [("Only:", "one")])

        assert "SingleRow" in html
        assert "Only:" in html
        assert "one" in html
        assert html.count("<tr>") == 1

    def test_includes_consistent_styling(self) -> None:
        """Should include expected CSS styling for consistency."""
        html = render_table("Test", [("A:", "B")])

        # Check for key styling elements
        assert "font-family:" in html
        assert "padding:" in html
        assert "border:" in html
        assert "border-radius:" in html
        assert "background-color:" in html
        assert "max-width:" in html
        assert "text-align: left" in html  # Left-aligned values
        assert "width: 140px" in html  # Fixed label width
