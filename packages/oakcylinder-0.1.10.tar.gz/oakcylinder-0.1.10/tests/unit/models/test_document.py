"""Tests for Document serialization methods."""

import json

from pinecone.models.documents.search import Document


class TestDocumentToDict:
    def test_returns_all_fields(self):
        data = {"_id": "doc-1", "score": 0.95, "title": "Hello", "category": "greeting"}
        doc = Document(data)
        result = doc.to_dict()

        assert result == data

    def test_returns_copy(self):
        data = {"_id": "doc-1", "score": 0.5}
        doc = Document(data)
        result = doc.to_dict()

        result["extra"] = "modified"
        # Verify the original document is not modified
        assert doc.get("extra") is None
        assert "extra" not in doc.to_dict()

    def test_minimal_document(self):
        data = {"_id": "doc-1"}
        doc = Document(data)
        result = doc.to_dict()

        assert result == {"_id": "doc-1"}

    def test_with_nested_values(self):
        data = {"_id": "doc-1", "metadata": {"tags": ["a", "b"]}, "count": 42}
        doc = Document(data)
        result = doc.to_dict()

        assert result["metadata"] == {"tags": ["a", "b"]}
        assert result["count"] == 42


class TestDocumentToJson:
    def test_returns_valid_json(self):
        data = {"_id": "doc-1", "score": 0.95, "title": "Hello"}
        doc = Document(data)
        result = doc.to_json()

        parsed = json.loads(result)
        assert parsed == data

    def test_preserves_all_fields(self):
        data = {"_id": "doc-1", "score": 0.5, "category": "test", "count": 42}
        doc = Document(data)
        parsed = json.loads(doc.to_json())

        assert parsed["_id"] == "doc-1"
        assert parsed["score"] == 0.5
        assert parsed["category"] == "test"
        assert parsed["count"] == 42

    def test_returns_string(self):
        doc = Document({"_id": "doc-1"})
        result = doc.to_json()

        assert isinstance(result, str)

    def test_with_unicode(self):
        data = {"_id": "doc-1", "title": "Héllo wörld"}
        doc = Document(data)
        parsed = json.loads(doc.to_json())

        assert parsed["title"] == "Héllo wörld"

    def test_with_none_score(self):
        data = {"_id": "doc-1", "score": None, "title": "Test"}
        doc = Document(data)
        parsed = json.loads(doc.to_json())

        assert parsed["score"] is None


class TestDocumentDir:
    def test_includes_serialization_methods(self):
        doc = Document({"_id": "doc-1", "score": 0.5, "title": "Test"})
        attrs = dir(doc)

        assert "to_dict" in attrs
        assert "to_json" in attrs
