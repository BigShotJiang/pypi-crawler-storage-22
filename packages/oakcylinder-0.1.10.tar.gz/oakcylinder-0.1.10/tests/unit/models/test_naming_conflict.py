"""Document the naming conflict that led to removing dict-style access.

This test file documents why BaseModel does NOT provide dict-style access
(__getitem__, __contains__, .get()). The conflict between Python attribute names
and msgspec serialized names would create confusion for users.

Solution: Use attribute access for fields, and .to_dict() for dict operations.
"""

from msgspec import field

from pinecone.models._base import BaseModel


class CamelCaseModel(BaseModel, kw_only=True, rename="camel"):
    """Model with rename='camel' - would conflict with dict-style access."""

    sparse_values: list[float]
    user_name: str


class FieldNameModel(BaseModel, kw_only=True):
    """Model with field(name=...) - would also conflict."""

    id: str = field(name="_id")
    score: float = field(name="_score")


def test_camel_case_no_conflict():
    """Attribute access and to_dict() use different naming conventions - this is OK."""
    model = CamelCaseModel(sparse_values=[0.1, 0.2], user_name="alice")

    # Python attribute access uses snake_case
    assert model.sparse_values == [0.1, 0.2]
    assert model.user_name == "alice"

    # to_dict() uses serialized names (camelCase from rename="camel")
    data = model.to_dict()
    assert "sparseValues" in data  # Serialized name
    assert "userName" in data  # Serialized name
    assert data["sparseValues"] == [0.1, 0.2]
    assert data["userName"] == "alice"

    # Python names NOT in serialized dict (this is expected)
    assert "sparse_values" not in data
    assert "user_name" not in data

    # This is FINE because:
    # 1. model.sparse_values uses Python attribute naming
    # 2. model.to_dict()["sparseValues"] uses msgspec serialization naming
    # They serve different purposes and don't claim equivalence


def test_field_name_no_conflict():
    """field(name=...) creates custom serialization - separate from attributes."""
    model = FieldNameModel(id="vec-123", score=0.95)

    # Python attribute access uses attribute names
    assert model.id == "vec-123"
    assert model.score == 0.95

    # to_dict() uses custom field names
    data = model.to_dict()
    assert "_id" in data
    assert "_score" in data
    assert data["_id"] == "vec-123"
    assert data["_score"] == 0.95

    # Attribute names NOT in serialized dict (expected)
    assert "id" not in data
    assert "score" not in data

    # This is FINE because they serve different purposes:
    # - Attributes: Python naming conventions
    # - Serialization: API/JSON naming conventions


def test_consistent_usage_pattern():
    """The correct usage pattern: attribute access + to_dict() for dict ops."""
    model = CamelCaseModel(sparse_values=[0.1, 0.2], user_name="alice")

    # Pattern 1: Attribute access (recommended)
    assert model.sparse_values == [0.1, 0.2]
    assert model.user_name == "alice"

    # Pattern 2: Convert to dict for dict operations
    data = model.to_dict()
    assert "sparseValues" in data
    field_name = "sparseValues"  # Dynamic field access
    assert data[field_name] == [0.1, 0.2]

    # Pattern 3: Iterate over fields
    for key in data:
        assert isinstance(key, str)  # Serialized names

    # No confusion because we DON'T provide model["field"] syntax
    # Users must explicitly convert: data = model.to_dict()
