"""Unit tests for AsyncBulkImports data plane operations."""

from __future__ import annotations

import pytest
import respx

from httpx import Response

from pinecone._internal.http import AsyncHTTPClient, HTTPConfig
from pinecone.async_index.bulk_imports import AsyncBulkImports


pytestmark = pytest.mark.unit

BASE_URL = "https://my-index-abc123.svc.pinecone.io"


def _make_async_bulk_imports() -> AsyncBulkImports:
    return AsyncBulkImports(
        http=AsyncHTTPClient(api_key="test-key", config=HTTPConfig()),
        base_url=BASE_URL,
    )


class TestAsyncStart:
    """Tests for AsyncBulkImports.start()."""

    @respx.mock
    @pytest.mark.asyncio()
    async def test_start_basic(self):
        route = respx.post(f"{BASE_URL}/bulk/imports").mock(
            return_value=Response(200, json={"id": "import-123"})
        )

        bi = _make_async_bulk_imports()
        result = await bi.start(uri="s3://my-bucket/my-data/")

        assert route.called
        assert result.id == "import-123"

    @respx.mock
    @pytest.mark.asyncio()
    async def test_start_with_integration_id(self):
        route = respx.post(f"{BASE_URL}/bulk/imports").mock(
            return_value=Response(200, json={"id": "import-456"})
        )

        bi = _make_async_bulk_imports()
        await bi.start(uri="s3://bucket/data/", integration_id="int-abc")

        request = route.calls.last.request
        assert b'"integrationId"' in request.content
        assert b'"int-abc"' in request.content

    @respx.mock
    @pytest.mark.asyncio()
    async def test_start_with_error_mode(self):
        route = respx.post(f"{BASE_URL}/bulk/imports").mock(
            return_value=Response(200, json={"id": "import-789"})
        )

        bi = _make_async_bulk_imports()
        await bi.start(uri="s3://bucket/data/", error_mode="continue")

        request = route.calls.last.request
        assert b'"errorMode"' in request.content
        assert b'"onError"' in request.content
        assert b'"continue"' in request.content

    @respx.mock
    @pytest.mark.asyncio()
    async def test_start_sends_api_version_header(self):
        route = respx.post(f"{BASE_URL}/bulk/imports").mock(
            return_value=Response(200, json={"id": "import-abc"})
        )

        bi = _make_async_bulk_imports()
        await bi.start(uri="s3://bucket/data/")

        request = route.calls.last.request
        assert request.headers["X-Pinecone-Api-Version"] == "2025-10"

    @pytest.mark.asyncio()
    async def test_start_empty_uri_raises(self):
        bi = _make_async_bulk_imports()
        with pytest.raises(ValueError):
            await bi.start(uri="")


class TestAsyncList:
    """Tests for AsyncBulkImports.list()."""

    @respx.mock
    @pytest.mark.asyncio()
    async def test_list_basic(self):
        route = respx.get(f"{BASE_URL}/bulk/imports").mock(
            return_value=Response(
                200,
                json={
                    "data": [
                        {
                            "id": "import-1",
                            "uri": "s3://bucket/data1/",
                            "status": "Completed",
                            "createdAt": "2025-01-01T00:00:00Z",
                            "percentComplete": 100.0,
                            "recordsImported": 1000,
                        },
                        {
                            "id": "import-2",
                            "uri": "s3://bucket/data2/",
                            "status": "InProgress",
                            "createdAt": "2025-01-02T00:00:00Z",
                            "percentComplete": 50.0,
                            "recordsImported": 500,
                        },
                    ],
                },
            )
        )

        bi = _make_async_bulk_imports()
        result = await bi.list()

        assert route.called
        assert len(result.data) == 2
        assert result.data[0].id == "import-1"
        assert result.data[0].status == "Completed"
        assert result.data[0].percent_complete == 100.0
        assert result.data[1].id == "import-2"

    @respx.mock
    @pytest.mark.asyncio()
    async def test_list_with_limit(self):
        route = respx.get(f"{BASE_URL}/bulk/imports").mock(
            return_value=Response(200, json={"data": []})
        )

        bi = _make_async_bulk_imports()
        await bi.list(limit=10)

        request = route.calls.last.request
        assert "limit=10" in str(request.url)

    @respx.mock
    @pytest.mark.asyncio()
    async def test_list_with_pagination(self):
        respx.get(f"{BASE_URL}/bulk/imports").mock(
            return_value=Response(
                200,
                json={
                    "data": [
                        {
                            "id": "import-3",
                            "status": "Pending",
                            "createdAt": "2025-01-03T00:00:00Z",
                            "percentComplete": 0.0,
                            "recordsImported": 0,
                        },
                    ],
                    "pagination": {"next": "token-xyz"},
                },
            )
        )

        bi = _make_async_bulk_imports()
        result = await bi.list(limit=1)

        assert result.pagination_token == "token-xyz"

    @respx.mock
    @pytest.mark.asyncio()
    async def test_list_no_pagination(self):
        respx.get(f"{BASE_URL}/bulk/imports").mock(return_value=Response(200, json={"data": []}))

        bi = _make_async_bulk_imports()
        result = await bi.list()

        assert result.pagination_token is None


class TestAsyncDescribe:
    """Tests for AsyncBulkImports.describe()."""

    @respx.mock
    @pytest.mark.asyncio()
    async def test_describe_basic(self):
        route = respx.get(f"{BASE_URL}/bulk/imports/import-123").mock(
            return_value=Response(
                200,
                json={
                    "id": "import-123",
                    "uri": "s3://bucket/data/",
                    "status": "Completed",
                    "createdAt": "2025-01-01T00:00:00Z",
                    "finishedAt": "2025-01-01T01:00:00Z",
                    "percentComplete": 100.0,
                    "recordsImported": 5000,
                },
            )
        )

        bi = _make_async_bulk_imports()
        result = await bi.describe(id="import-123")

        assert route.called
        assert result.id == "import-123"
        assert result.uri == "s3://bucket/data/"
        assert result.status == "Completed"
        assert result.finished_at == "2025-01-01T01:00:00Z"
        assert result.percent_complete == 100.0
        assert result.records_imported == 5000

    @respx.mock
    @pytest.mark.asyncio()
    async def test_describe_with_error(self):
        respx.get(f"{BASE_URL}/bulk/imports/import-fail").mock(
            return_value=Response(
                200,
                json={
                    "id": "import-fail",
                    "uri": "s3://bucket/bad-data/",
                    "status": "Failed",
                    "createdAt": "2025-01-01T00:00:00Z",
                    "percentComplete": 25.0,
                    "recordsImported": 100,
                    "error": "Invalid record format at line 101",
                },
            )
        )

        bi = _make_async_bulk_imports()
        result = await bi.describe(id="import-fail")

        assert result.status == "Failed"
        assert result.error == "Invalid record format at line 101"

    @respx.mock
    @pytest.mark.asyncio()
    async def test_describe_url_includes_id(self):
        route = respx.get(f"{BASE_URL}/bulk/imports/my-import-id").mock(
            return_value=Response(
                200,
                json={
                    "id": "my-import-id",
                    "status": "Pending",
                    "createdAt": "2025-01-01T00:00:00Z",
                    "percentComplete": 0.0,
                    "recordsImported": 0,
                },
            )
        )

        bi = _make_async_bulk_imports()
        await bi.describe(id="my-import-id")

        assert route.called
        assert "/bulk/imports/my-import-id" in str(route.calls.last.request.url)

    @pytest.mark.asyncio()
    async def test_describe_empty_id_raises(self):
        bi = _make_async_bulk_imports()
        with pytest.raises(ValueError):
            await bi.describe(id="")


class TestAsyncCancel:
    """Tests for AsyncBulkImports.cancel()."""

    @respx.mock
    @pytest.mark.asyncio()
    async def test_cancel_basic(self):
        route = respx.delete(f"{BASE_URL}/bulk/imports/import-123").mock(
            return_value=Response(200, json={})
        )

        bi = _make_async_bulk_imports()
        result = await bi.cancel(id="import-123")

        assert route.called
        assert result is not None

    @respx.mock
    @pytest.mark.asyncio()
    async def test_cancel_url_includes_id(self):
        route = respx.delete(f"{BASE_URL}/bulk/imports/my-cancel-id").mock(
            return_value=Response(200, json={})
        )

        bi = _make_async_bulk_imports()
        await bi.cancel(id="my-cancel-id")

        assert route.called
        assert "/bulk/imports/my-cancel-id" in str(route.calls.last.request.url)

    @pytest.mark.asyncio()
    async def test_cancel_empty_id_raises(self):
        bi = _make_async_bulk_imports()
        with pytest.raises(ValueError):
            await bi.cancel(id="")


class TestAsyncModelRepr:
    """Tests for model __repr__ methods."""

    def test_import_model_repr(self):
        from pinecone.models.bulk_imports.import_model import ImportModel

        imp = ImportModel(id="import-123", status="Completed")
        assert repr(imp) == "ImportModel(id='import-123', status='Completed')"

    @respx.mock
    @pytest.mark.asyncio()
    async def test_list_imports_response_repr(self):
        respx.get(f"{BASE_URL}/bulk/imports").mock(
            return_value=Response(
                200,
                json={
                    "data": [
                        {
                            "id": "import-1",
                            "status": "Completed",
                            "createdAt": "2025-01-01T00:00:00Z",
                            "percentComplete": 100.0,
                            "recordsImported": 1000,
                        },
                    ],
                },
            )
        )

        bi = _make_async_bulk_imports()
        result = await bi.list()

        assert "data=1" in repr(result)


class TestAsyncImportsConvenienceProperty:
    """Tests for ListImportsResponse.imports property."""

    @respx.mock
    @pytest.mark.asyncio()
    async def test_imports_returns_same_as_data(self):
        respx.get(f"{BASE_URL}/bulk/imports").mock(
            return_value=Response(
                200,
                json={
                    "data": [
                        {
                            "id": "import-1",
                            "status": "Completed",
                            "createdAt": "2025-01-01T00:00:00Z",
                            "percentComplete": 100.0,
                            "recordsImported": 1000,
                        },
                        {
                            "id": "import-2",
                            "status": "InProgress",
                            "createdAt": "2025-01-02T00:00:00Z",
                            "percentComplete": 50.0,
                            "recordsImported": 500,
                        },
                    ],
                },
            )
        )

        bi = _make_async_bulk_imports()
        result = await bi.list()

        assert result.imports is result.data
        assert len(result.imports) == 2
        assert result.imports[0].id == "import-1"
        assert result.imports[1].id == "import-2"

    @respx.mock
    @pytest.mark.asyncio()
    async def test_imports_empty_list(self):
        respx.get(f"{BASE_URL}/bulk/imports").mock(return_value=Response(200, json={"data": []}))

        bi = _make_async_bulk_imports()
        result = await bi.list()

        assert result.imports == []
