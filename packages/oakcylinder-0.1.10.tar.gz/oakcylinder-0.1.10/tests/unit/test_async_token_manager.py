"""Tests for asynchronous OAuth TokenManager."""

import asyncio
import time

import httpx
import pytest
import respx

from pinecone._internal.auth import AsyncTokenManager


class TestAsyncTokenManagerInitialization:
    """Test AsyncTokenManager initialization and validation."""

    def test_init_validates_https(self):
        """AsyncTokenManager requires HTTPS token endpoint."""
        with pytest.raises(ValueError, match="token_url must use HTTPS"):
            AsyncTokenManager(
                client_id="test-client",
                client_secret="test-secret",
                token_url="http://insecure.example.com/token",
            )

    def test_init_accepts_https(self):
        """AsyncTokenManager accepts HTTPS token endpoint."""
        manager = AsyncTokenManager(
            client_id="test-client",
            client_secret="test-secret",
            token_url="https://secure.example.com/token",
        )
        assert manager._token_url == "https://secure.example.com/token"

    def test_init_sets_default_refresh_margin(self):
        """AsyncTokenManager defaults to 300s refresh margin."""
        manager = AsyncTokenManager(
            client_id="test-client",
            client_secret="test-secret",
            token_url="https://auth.example.com/token",
        )
        assert manager._refresh_margin == 300

    def test_init_accepts_custom_refresh_margin(self):
        """AsyncTokenManager accepts custom refresh margin."""
        manager = AsyncTokenManager(
            client_id="test-client",
            client_secret="test-secret",
            token_url="https://auth.example.com/token",
            refresh_margin_seconds=600,
        )
        assert manager._refresh_margin == 600


class TestAsyncTokenManagerTokenExchange:
    """Test OAuth token exchange logic."""

    @pytest.mark.asyncio()
    @respx.mock
    async def test_get_token_exchanges_credentials(self):
        """get_token() exchanges credentials for access token."""
        # Mock OAuth endpoint
        respx.post("https://auth.example.com/token").mock(
            return_value=httpx.Response(
                200,
                json={
                    "access_token": "test-token-abc123",
                    "token_type": "Bearer",
                    "expires_in": 3600,
                },
            )
        )

        manager = AsyncTokenManager(
            client_id="test-client-id",
            client_secret="test-client-secret",
            token_url="https://auth.example.com/token",
        )

        token = await manager.get_token()

        assert token == "test-token-abc123"
        assert manager._cached_token == "test-token-abc123"
        assert manager._token_expiry is not None

        await manager.close()

    @pytest.mark.asyncio()
    @respx.mock
    async def test_get_token_sends_correct_request(self):
        """get_token() sends OAuth client_credentials request."""
        route = respx.post("https://auth.example.com/token").mock(
            return_value=httpx.Response(
                200,
                json={
                    "access_token": "token",
                    "expires_in": 3600,
                },
            )
        )

        manager = AsyncTokenManager(
            client_id="my-client-id",
            client_secret="my-client-secret",
            token_url="https://auth.example.com/token",
        )

        await manager.get_token()

        # Verify request was made correctly
        assert route.called
        request = route.calls.last.request
        assert request.method == "POST"
        assert request.headers["content-type"] == "application/x-www-form-urlencoded"

        # Parse form data
        body = request.content.decode("utf-8")
        assert "grant_type=client_credentials" in body
        assert "client_id=my-client-id" in body
        assert "client_secret=my-client-secret" in body

        await manager.close()

    @pytest.mark.asyncio()
    @respx.mock
    async def test_get_token_caches_token(self):
        """get_token() caches token to avoid repeated exchanges."""
        call_count = 0

        def response_callback(request):
            nonlocal call_count
            call_count += 1
            return httpx.Response(
                200,
                json={
                    "access_token": f"token-{call_count}",
                    "expires_in": 3600,
                },
            )

        respx.post("https://auth.example.com/token").mock(side_effect=response_callback)

        manager = AsyncTokenManager(
            client_id="test-client",
            client_secret="test-secret",
            token_url="https://auth.example.com/token",
        )

        # First call exchanges token
        token1 = await manager.get_token()
        assert token1 == "token-1"
        assert call_count == 1

        # Second call uses cached token
        token2 = await manager.get_token()
        assert token2 == "token-1"  # Same token
        assert call_count == 1  # No new exchange

        await manager.close()

    @pytest.mark.asyncio()
    @respx.mock
    async def test_get_token_refreshes_when_expired(self):
        """get_token() refreshes token when expired."""
        respx.post("https://auth.example.com/token").mock(
            return_value=httpx.Response(
                200,
                json={
                    "access_token": "fresh-token",
                    "expires_in": 3600,
                },
            )
        )

        manager = AsyncTokenManager(
            client_id="test-client",
            client_secret="test-secret",
            token_url="https://auth.example.com/token",
            refresh_margin_seconds=0,  # No margin for testing
        )

        # Get initial token
        await manager.get_token()

        # Manually expire token
        manager._token_expiry = time.time() - 1

        # Next call should refresh
        token2 = await manager.get_token()
        assert token2 == "fresh-token"

        await manager.close()

    @pytest.mark.asyncio()
    @respx.mock
    async def test_get_token_refreshes_with_margin(self):
        """get_token() refreshes before expiry with margin."""
        respx.post("https://auth.example.com/token").mock(
            return_value=httpx.Response(
                200,
                json={
                    "access_token": "refreshed-token",
                    "expires_in": 3600,
                },
            )
        )

        manager = AsyncTokenManager(
            client_id="test-client",
            client_secret="test-secret",
            token_url="https://auth.example.com/token",
            refresh_margin_seconds=300,  # 5 minutes
        )

        # Get initial token
        await manager.get_token()

        # Set expiry to be within margin (but not actually expired)
        manager._token_expiry = time.time() + 200  # Expires in 200s, margin is 300s

        # Should refresh because within margin
        token = await manager.get_token()
        assert token == "refreshed-token"

        await manager.close()


class TestAsyncTokenManagerErrors:
    """Test AsyncTokenManager error handling."""

    @pytest.mark.asyncio()
    @respx.mock
    async def test_get_token_raises_on_401(self):
        """get_token() raises ValueError on authentication failure."""
        respx.post("https://auth.example.com/token").mock(
            return_value=httpx.Response(
                401,
                json={"error": "invalid_client"},
            )
        )

        manager = AsyncTokenManager(
            client_id="bad-client",
            client_secret="bad-secret",
            token_url="https://auth.example.com/token",
        )

        with pytest.raises(ValueError, match="OAuth authentication failed"):
            await manager.get_token()

        await manager.close()

    @pytest.mark.asyncio()
    @respx.mock
    async def test_get_token_error_does_not_leak_credentials(self):
        """get_token() error messages don't contain credentials."""
        respx.post("https://auth.example.com/token").mock(
            return_value=httpx.Response(401, json={"error": "invalid_client"})
        )

        manager = AsyncTokenManager(
            client_id="secret-client-id",
            client_secret="super-secret-value",
            token_url="https://auth.example.com/token",
        )

        try:
            await manager.get_token()
        except ValueError as e:
            error_msg = str(e)
            assert "secret-client-id" not in error_msg
            assert "super-secret-value" not in error_msg

        await manager.close()

    @pytest.mark.asyncio()
    @respx.mock
    async def test_get_token_raises_on_missing_access_token(self):
        """get_token() raises if response missing access_token."""
        respx.post("https://auth.example.com/token").mock(
            return_value=httpx.Response(
                200,
                json={"token_type": "Bearer"},  # Missing access_token
            )
        )

        manager = AsyncTokenManager(
            client_id="test-client",
            client_secret="test-secret",
            token_url="https://auth.example.com/token",
        )

        with pytest.raises(ValueError, match="missing access_token"):
            await manager.get_token()

        await manager.close()

    @pytest.mark.asyncio()
    @respx.mock
    async def test_get_token_raises_on_network_error(self):
        """get_token() raises ValueError on network errors."""
        respx.post("https://auth.example.com/token").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )

        manager = AsyncTokenManager(
            client_id="test-client",
            client_secret="test-secret",
            token_url="https://auth.example.com/token",
        )

        with pytest.raises(ValueError, match="network error"):
            await manager.get_token()

        await manager.close()

    @pytest.mark.asyncio()
    async def test_get_token_raises_if_closed(self):
        """get_token() raises if manager has been closed."""
        manager = AsyncTokenManager(
            client_id="test-client",
            client_secret="test-secret",
            token_url="https://auth.example.com/token",
        )

        await manager.close()

        with pytest.raises(RuntimeError, match="has been closed"):
            await manager.get_token()


class TestAsyncTokenManagerCleanup:
    """Test AsyncTokenManager cleanup and resource management."""

    @pytest.mark.asyncio()
    @respx.mock
    async def test_clear_removes_cached_token(self):
        """clear() removes cached token from memory."""
        respx.post("https://auth.example.com/token").mock(
            return_value=httpx.Response(
                200,
                json={"access_token": "token", "expires_in": 3600},
            )
        )

        manager = AsyncTokenManager(
            client_id="test-client",
            client_secret="test-secret",
            token_url="https://auth.example.com/token",
        )

        # Get and cache token
        await manager.get_token()
        assert manager._cached_token is not None

        # Clear cache
        await manager.clear()
        assert manager._cached_token is None
        assert manager._token_expiry is None

        await manager.close()

    @pytest.mark.asyncio()
    @respx.mock
    async def test_clear_forces_refresh_on_next_call(self):
        """clear() forces token exchange on next get_token()."""
        call_count = 0

        def response_callback(request):
            nonlocal call_count
            call_count += 1
            return httpx.Response(
                200,
                json={"access_token": f"token-{call_count}", "expires_in": 3600},
            )

        respx.post("https://auth.example.com/token").mock(side_effect=response_callback)

        manager = AsyncTokenManager(
            client_id="test-client",
            client_secret="test-secret",
            token_url="https://auth.example.com/token",
        )

        token1 = await manager.get_token()
        assert token1 == "token-1"

        await manager.clear()

        token2 = await manager.get_token()
        assert token2 == "token-2"  # New token, not cached
        assert call_count == 2

        await manager.close()

    @pytest.mark.asyncio()
    async def test_close_clears_token(self):
        """close() clears cached token."""
        manager = AsyncTokenManager(
            client_id="test-client",
            client_secret="test-secret",
            token_url="https://auth.example.com/token",
        )

        manager._cached_token = "test-token"
        manager._token_expiry = time.time() + 3600

        await manager.close()

        assert manager._cached_token is None
        assert manager._token_expiry is None

    @pytest.mark.asyncio()
    async def test_close_closes_http_client(self):
        """close() closes the HTTP client."""
        manager = AsyncTokenManager(
            client_id="test-client",
            client_secret="test-secret",
            token_url="https://auth.example.com/token",
        )

        assert manager._http_client is not None

        await manager.close()

        assert manager._http_client is None

    @pytest.mark.asyncio()
    @respx.mock
    async def test_context_manager_closes_on_exit(self):
        """AsyncTokenManager context manager closes on exit."""
        respx.post("https://auth.example.com/token").mock(
            return_value=httpx.Response(
                200,
                json={"access_token": "token", "expires_in": 3600},
            )
        )

        async with AsyncTokenManager(
            client_id="test-client",
            client_secret="test-secret",
            token_url="https://auth.example.com/token",
        ) as manager:
            token = await manager.get_token()
            assert token == "token"
            assert manager._http_client is not None

        # After exiting context, should be closed
        assert manager._http_client is None
        assert manager._cached_token is None


class TestAsyncTokenManagerConcurrency:
    """Test AsyncTokenManager async-safety."""

    @pytest.mark.asyncio()
    @respx.mock
    async def test_concurrent_get_token_calls_single_exchange(self):
        """Concurrent get_token() calls result in single exchange."""
        call_count = 0

        async def response_callback(request):
            nonlocal call_count
            call_count += 1
            # Simulate slow token exchange
            await asyncio.sleep(0.1)
            return httpx.Response(
                200,
                json={"access_token": f"token-{call_count}", "expires_in": 3600},
            )

        respx.post("https://auth.example.com/token").mock(side_effect=response_callback)

        manager = AsyncTokenManager(
            client_id="test-client",
            client_secret="test-secret",
            token_url="https://auth.example.com/token",
        )

        # Simulate concurrent calls
        tokens = await asyncio.gather(*[manager.get_token() for _ in range(5)])

        # All tasks should get the same token
        assert len(set(tokens)) == 1
        assert tokens[0] == "token-1"

        # Only one exchange should have occurred
        assert call_count == 1

        await manager.close()
