"""Tests for conftest.py fixtures and configuration."""

from __future__ import annotations

import os

from pathlib import Path

import pytest


pytestmark = pytest.mark.unit


# Import dotenv only if available
try:
    import dotenv

    HAS_DOTENV = True
except ImportError:
    dotenv = None  # type: ignore[assignment]
    HAS_DOTENV = False


class TestEnvironmentLoading:
    """Test environment variable loading from .env files."""

    @pytest.mark.skipif(not HAS_DOTENV, reason="python-dotenv not installed")
    def test_dotenv_module_available(self):
        """Test that python-dotenv is installed and importable."""
        assert dotenv is not None

    def test_env_file_in_gitignore(self):
        """Test that .env files are properly gitignored."""
        repo_root = Path(__file__).parent.parent.parent
        gitignore_path = repo_root / ".gitignore"

        assert gitignore_path.exists(), ".gitignore file should exist"

        content = gitignore_path.read_text()
        assert ".env" in content, ".env should be in .gitignore"

    def test_env_example_exists(self):
        """Test that .env.example file exists."""
        repo_root = Path(__file__).parent.parent.parent
        env_example = repo_root / ".env.example"

        assert env_example.exists(), ".env.example should exist"
        assert env_example.is_file(), ".env.example should be a file"

        # Check it has some expected content
        content = env_example.read_text()
        assert "PINECONE_API_KEY" in content
        assert "your-api-key-here" in content


class TestFixtures:
    """Test pytest fixtures defined in conftest.py."""

    def test_test_index_name_fixture_has_default(self, test_index_name):
        """Test that test_index_name fixture has a default value."""
        # This fixture has a default and won't skip
        assert test_index_name == "test-index"

    def test_test_index_name_fixture_uses_env_var(self, monkeypatch, test_index_name):
        """Test that test_index_name fixture uses env var when set."""
        custom_name = "my-custom-test-index"
        monkeypatch.setenv("PINECONE_TEST_INDEX_NAME", custom_name)

        # When fixture is called in a new test, it will use the env var
        # For this test, just verify the env var is set
        assert os.getenv("PINECONE_TEST_INDEX_NAME") == custom_name
