"""Protocol compliance tests for document operations."""

from pinecone.__interface__.documents import (
    AsyncDocumentOperationsProtocol,
    DocumentOperationsProtocol,
)
from pinecone._internal.http import AsyncHTTPClient, HTTPClient, HTTPConfig
from pinecone.async_index.documents import AsyncDocuments
from pinecone.index.documents import Documents


def test_documents_satisfies_protocol():
    """Verify Documents class satisfies DocumentOperationsProtocol."""
    client = HTTPClient(api_key="test", config=HTTPConfig(http2=False))
    documents = Documents(http=client, base_url="https://test.io")
    assert isinstance(documents, DocumentOperationsProtocol)


def test_async_documents_satisfies_protocol():
    """Verify AsyncDocuments class satisfies AsyncDocumentOperationsProtocol."""
    client = AsyncHTTPClient(api_key="test", config=HTTPConfig(http2=False))
    documents = AsyncDocuments(http=client, base_url="https://test.io")
    assert isinstance(documents, AsyncDocumentOperationsProtocol)
