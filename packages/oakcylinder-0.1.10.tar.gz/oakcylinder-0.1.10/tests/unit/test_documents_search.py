"""Unit tests for document search operation."""

import httpx
import pytest
import respx

from pinecone._internal.http import HTTPClient, HTTPConfig
from pinecone.index.documents import Documents


@respx.mock
def test_search_text_query():
    """Test text-based document search."""
    respx.post("https://test.io/namespaces/my-ns/documents/search").mock(
        return_value=httpx.Response(
            200,
            json={
                "matches": [
                    {"_id": "doc1", "score": 0.95, "title": "Hello World"},
                    {"_id": "doc2", "score": 0.85, "title": "Test"},
                ],
                "namespace": "my-ns",
                "usage": {"read_units": 5},
            },
        )
    )

    client = HTTPClient(api_key="test", config=HTTPConfig(http2=False))
    documents = Documents(http=client, base_url="https://test.io")

    response = documents.search(
        namespace="my-ns",
        top_k=10,
        score_by=[{"type": "text", "field": "title", "text_query": "hello"}],
        include_fields=["_id", "title"],
    )

    assert len(response.matches) == 2
    assert response.matches[0].id == "doc1"
    assert response.matches[0].score == 0.95
    assert response.namespace == "my-ns"
    assert response.usage.read_units == 5


@respx.mock
def test_search_vector_query():
    """Test vector-based document search."""
    respx.post("https://test.io/namespaces/my-ns/documents/search").mock(
        return_value=httpx.Response(
            200,
            json={
                "matches": [{"_id": "doc1", "score": 0.92}],
                "namespace": "my-ns",
                "usage": {"read_units": 3},
            },
        )
    )

    client = HTTPClient(api_key="test", config=HTTPConfig(http2=False))
    documents = Documents(http=client, base_url="https://test.io")

    response = documents.search(
        namespace="my-ns",
        top_k=5,
        score_by=[{"type": "dense_vector", "field": "vec", "values": [0.1, 0.2, 0.3]}],
    )

    assert len(response.matches) == 1
    assert response.matches[0].id == "doc1"
    assert response.namespace == "my-ns"


@respx.mock
def test_search_validates_empty_namespace():
    """Test that empty namespace raises ValueError."""
    client = HTTPClient(api_key="test", config=HTTPConfig(http2=False))
    documents = Documents(http=client, base_url="https://test.io")

    with pytest.raises(ValueError, match="namespace"):
        documents.search(
            namespace="",
            top_k=10,
            score_by=[{"type": "text", "field": "title", "text_query": "test"}],
        )


@respx.mock
def test_search_validates_top_k_range():
    """Test that top_k out of range raises ValueError."""
    client = HTTPClient(api_key="test", config=HTTPConfig(http2=False))
    documents = Documents(http=client, base_url="https://test.io")

    with pytest.raises(ValueError, match="top_k"):
        documents.search(
            namespace="my-ns",
            top_k=0,
            score_by=[{"type": "text", "field": "title", "text_query": "test"}],
        )

    with pytest.raises(ValueError, match="top_k"):
        documents.search(
            namespace="my-ns",
            top_k=10001,
            score_by=[{"type": "text", "field": "title", "text_query": "test"}],
        )


@respx.mock
def test_search_validates_empty_score_by():
    """Test that empty score_by raises ValueError."""
    client = HTTPClient(api_key="test", config=HTTPConfig(http2=False))
    documents = Documents(http=client, base_url="https://test.io")

    with pytest.raises(ValueError, match="score_by must not be empty"):
        documents.search(namespace="my-ns", top_k=10, score_by=[])


@respx.mock
def test_search_without_include_fields_sends_empty_array():
    """Test that include_fields defaults to empty array when not provided."""
    route = respx.post("https://test.io/namespaces/my-ns/documents/search").mock(
        return_value=httpx.Response(
            200,
            json={
                "matches": [{"_id": "doc1", "score": 0.92}],
                "namespace": "my-ns",
                "usage": {"read_units": 3},
            },
        )
    )

    client = HTTPClient(api_key="test", config=HTTPConfig(http2=False))
    documents = Documents(http=client, base_url="https://test.io")

    response = documents.search(
        namespace="my-ns",
        top_k=5,
        score_by=[{"type": "text", "field": "title", "text_query": "hello"}],
        # include_fields not provided - should default to []
    )

    assert len(response.matches) == 1
    assert response.matches[0].id == "doc1"

    # Verify the request body contains include_fields: []
    assert route.called
    request = route.calls.last.request
    import orjson

    body = orjson.loads(request.content)
    assert "include_fields" in body
    assert body["include_fields"] == []


@respx.mock
def test_search_with_typed_models():
    """Test search with typed query models."""
    from pinecone.models import DenseVectorQuery, SparseVectorQuery
    from pinecone.models.documents import SparseValues

    respx.post("https://test.io/namespaces/my-ns/documents/search").mock(
        return_value=httpx.Response(
            200,
            json={
                "matches": [{"_id": "doc1", "score": 0.92}],
                "namespace": "my-ns",
                "usage": {"read_units": 3},
            },
        )
    )

    client = HTTPClient(api_key="test", config=HTTPConfig(http2=False))
    documents = Documents(http=client, base_url="https://test.io")

    # Test with DenseVectorQuery
    response = documents.search(
        namespace="my-ns",
        top_k=5,
        score_by=[DenseVectorQuery(field="vec", values=[0.1, 0.2, 0.3])],
    )

    assert len(response.matches) == 1
    assert response.namespace == "my-ns"

    # Test with SparseVectorQuery
    respx.clear()
    respx.post("https://test.io/namespaces/my-ns/documents/search").mock(
        return_value=httpx.Response(
            200,
            json={
                "matches": [{"_id": "doc2", "score": 0.85}],
                "namespace": "my-ns",
                "usage": {"read_units": 2},
            },
        )
    )

    response = documents.search(
        namespace="my-ns",
        top_k=5,
        score_by=[
            SparseVectorQuery(
                field="sparse_vec",
                sparse_values=SparseValues(indices=[0, 5, 10], values=[0.5, 0.3, 0.8]),
            )
        ],
    )

    assert len(response.matches) == 1
    assert response.matches[0].id == "doc2"


def test_document_dir_no_duplicates():
    """Test that dir() on Document returns no duplicate entries."""
    from pinecone.models.documents.search import Document

    # Test with API response containing "id" field (not "_id")
    doc_with_id = Document({"id": "doc1", "score": 0.95, "title": "Test", "content": "Hello"})
    dir_result = dir(doc_with_id)

    # Verify no duplicates
    assert len(dir_result) == len(set(dir_result)), f"Found duplicates in dir(): {dir_result}"

    # Verify both _id and id appear exactly once
    assert dir_result.count("_id") == 1, "Expected '_id' to appear exactly once"
    assert dir_result.count("id") == 1, "Expected 'id' to appear exactly once"

    # Verify other expected attributes are present
    assert "score" in dir_result
    assert "get" in dir_result
    assert "title" in dir_result
    assert "content" in dir_result

    # Test with API response containing "_id" field (not "id")
    doc_with_underscore_id = Document({"_id": "doc2", "score": 0.85, "name": "Another"})
    dir_result2 = dir(doc_with_underscore_id)

    # Verify no duplicates
    assert len(dir_result2) == len(set(dir_result2)), f"Found duplicates in dir(): {dir_result2}"

    # Verify both _id and id appear exactly once
    assert dir_result2.count("_id") == 1, "Expected '_id' to appear exactly once"
    assert dir_result2.count("id") == 1, "Expected 'id' to appear exactly once"

    # Verify other document fields appear correctly
    assert "name" in dir_result2

    # Verify _id is the only underscore-prefixed attribute
    underscore_attrs = [k for k in dir_result2 if k.startswith("_")]
    assert underscore_attrs == ["_id"], (
        f"Expected only '_id' attribute with underscore, got: {underscore_attrs}"
    )


def test_document_get_respects_default_for_none_score():
    """Test that get() method respects default parameter when score is None."""
    from pinecone.models.documents.search import Document

    # Document without score (score is None)
    doc = Document({"_id": "doc1", "title": "Test"})
    assert doc.score is None

    # get() should return the default value when score is None
    assert doc.get("score") is None  # No default provided
    assert doc.get("score", 0.0) == 0.0  # Default should be used
    assert doc.get("score", -1.0) == -1.0  # Different default

    # Document with explicit score
    doc_with_score = Document({"_id": "doc2", "score": 0.95})
    assert doc_with_score.score == 0.95

    # get() should return actual score, ignoring default
    assert doc_with_score.get("score") == 0.95
    assert doc_with_score.get("score", 0.0) == 0.95  # Default ignored
    assert doc_with_score.get("score", -1.0) == 0.95  # Default ignored
