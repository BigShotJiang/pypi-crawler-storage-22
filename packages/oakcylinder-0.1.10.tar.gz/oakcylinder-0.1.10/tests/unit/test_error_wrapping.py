"""Test error wrapping utility for consistent error handling across namespaces."""

from pinecone._internal.errors import wrap_api_error
from pinecone.exceptions import (
    APIConnectionError,
    APIError,
    BadRequestError,
    ConflictError,
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError as PineconeTimeoutError,
    UnauthorizedError,
)


class TestWrapAPIError:
    """Test wrap_api_error preserves exception types and metadata."""

    def test_wraps_generic_api_error(self):
        """Test wrapping generic APIError preserves attributes."""
        original = APIError(
            message="Original error",
            status_code=418,
            response_body='{"error": "test"}',
            request_id="req-123",
            error_code="TEST_ERROR",
            url="https://api.pinecone.io/test",
            method="POST",
        )

        wrapped = wrap_api_error(original, "TestNamespace.test_method")

        assert isinstance(wrapped, APIError)
        assert type(wrapped) == APIError  # Not a subclass  # noqa: E721
        assert wrapped.message == "TestNamespace.test_method failed: Original error"
        assert wrapped.status_code == 418
        assert wrapped.response_body == '{"error": "test"}'
        assert wrapped.request_id == "req-123"
        assert wrapped.error_code == "TEST_ERROR"
        assert wrapped.url == "https://api.pinecone.io/test"
        assert wrapped.method == "POST"

    def test_wraps_rate_limit_error(self):
        """Test RateLimitError wrapping preserves retry_after."""
        original = RateLimitError(
            retry_after=60,
            message="Rate limit exceeded",
            request_id="req-456",
            error_code="RATE_LIMIT",
        )

        wrapped = wrap_api_error(original, "Inference.embed")

        assert isinstance(wrapped, RateLimitError)
        assert type(wrapped) == RateLimitError  # noqa: E721
        assert wrapped.message == "Inference.embed failed: Rate limit exceeded. Retry after 60s"
        assert wrapped.retry_after == 60
        assert wrapped.status_code == 429
        assert wrapped.request_id == "req-456"
        assert wrapped.error_code == "RATE_LIMIT"

    def test_wraps_bad_request_error(self):
        """Test BadRequestError wrapping preserves all attributes."""
        original = BadRequestError(
            message="Invalid parameter: dimension",
            response_body='{"error": "Invalid dimension"}',
            request_id="req-789",
        )

        wrapped = wrap_api_error(original, "Indexes.create")

        assert isinstance(wrapped, BadRequestError)
        assert type(wrapped) == BadRequestError  # noqa: E721
        assert wrapped.message == "Indexes.create failed: Invalid parameter: dimension"
        assert wrapped.status_code == 400
        assert wrapped.response_body == '{"error": "Invalid dimension"}'
        assert wrapped.request_id == "req-789"

    def test_wraps_unauthorized_error(self):
        """Test UnauthorizedError wrapping."""
        original = UnauthorizedError(
            message="Invalid API key",
            request_id="req-001",
        )

        wrapped = wrap_api_error(original, "Collections.list")

        assert isinstance(wrapped, UnauthorizedError)
        assert type(wrapped) == UnauthorizedError  # noqa: E721
        assert wrapped.message == "Collections.list failed: Invalid API key"
        assert wrapped.status_code == 401
        assert wrapped.request_id == "req-001"

    def test_wraps_forbidden_error(self):
        """Test ForbiddenError wrapping."""
        original = ForbiddenError(
            message="Permission denied",
            request_id="req-002",
        )

        wrapped = wrap_api_error(original, "Backups.delete")

        assert isinstance(wrapped, ForbiddenError)
        assert type(wrapped) == ForbiddenError  # noqa: E721
        assert wrapped.message == "Backups.delete failed: Permission denied"
        assert wrapped.status_code == 403

    def test_wraps_not_found_error(self):
        """Test NotFoundError wrapping."""
        original = NotFoundError(
            message="Index not found",
            request_id="req-003",
        )

        wrapped = wrap_api_error(original, "Indexes.describe")

        assert isinstance(wrapped, NotFoundError)
        assert type(wrapped) == NotFoundError  # noqa: E721
        assert wrapped.message == "Indexes.describe failed: Index not found"
        assert wrapped.status_code == 404

    def test_wraps_conflict_error(self):
        """Test ConflictError wrapping."""
        original = ConflictError(
            message="Index already exists",
            request_id="req-004",
        )

        wrapped = wrap_api_error(original, "Indexes.create")

        assert isinstance(wrapped, ConflictError)
        assert type(wrapped) == ConflictError  # noqa: E721
        assert wrapped.message == "Indexes.create failed: Index already exists"
        assert wrapped.status_code == 409

    def test_wraps_server_error(self):
        """Test ServerError wrapping with custom status code."""
        original = ServerError(
            message="Internal server error",
            status_code=503,
            response_body='{"error": "Service unavailable"}',
            request_id="req-005",
        )

        wrapped = wrap_api_error(original, "Inference.rerank")

        assert isinstance(wrapped, ServerError)
        assert type(wrapped) == ServerError  # noqa: E721
        assert wrapped.message == "Inference.rerank failed: Internal server error"
        assert wrapped.status_code == 503
        assert wrapped.response_body == '{"error": "Service unavailable"}'

    def test_wraps_timeout_error(self):
        """Test TimeoutError wrapping preserves timeout value."""
        original = PineconeTimeoutError(timeout=30.0)

        wrapped = wrap_api_error(original, "Collections.create")

        assert isinstance(wrapped, PineconeTimeoutError)
        assert type(wrapped) == PineconeTimeoutError  # noqa: E721
        assert wrapped.timeout == 30.0
        assert "30.0" in wrapped.message

    def test_wraps_api_connection_error(self):
        """Test APIConnectionError wrapping."""
        original = APIConnectionError("Connection failed")

        wrapped = wrap_api_error(original, "Backups.list")

        assert isinstance(wrapped, APIConnectionError)
        assert type(wrapped) == APIConnectionError  # noqa: E721
        assert wrapped.message == "Backups.list failed: Connection failed"

    def test_wraps_connection_error(self):
        """Test ConnectionError wrapping preserves cause attribute."""
        from pinecone.exceptions import ConnectionError as PineconeConnectionError

        # Create ConnectionError with a cause
        underlying_error = ValueError("Network error")
        original = PineconeConnectionError("Failed to connect to server", cause=underlying_error)

        wrapped = wrap_api_error(original, "Collections.describe")

        # Verify type is preserved
        assert isinstance(wrapped, PineconeConnectionError)
        assert type(wrapped) == PineconeConnectionError  # noqa: E721

        # Verify message is enhanced
        assert wrapped.message == "Collections.describe failed: Failed to connect to server"

        # Verify cause attribute is preserved
        assert wrapped.cause is underlying_error

    def test_preserves_exception_hierarchy(self):
        """Test that exception type checking still works after wrapping."""
        # RateLimitError is a subclass of APIError
        original = RateLimitError(retry_after=30)
        wrapped = wrap_api_error(original, "Test.method")

        # Should match both specific and parent types
        assert isinstance(wrapped, RateLimitError)
        assert isinstance(wrapped, APIError)

    def test_operation_context_formatting(self):
        """Test various operation context string formats."""
        original = BadRequestError(message="Invalid request")

        # Namespace.method format
        wrapped1 = wrap_api_error(original, "Collections.create")
        assert wrapped1.message == "Collections.create failed: Invalid request"

        # Descriptive format
        wrapped2 = wrap_api_error(original, "Creating collection")
        assert wrapped2.message == "Creating collection failed: Invalid request"

        # Nested namespace format
        wrapped3 = wrap_api_error(original, "Index.Documents.upsert")
        assert wrapped3.message == "Index.Documents.upsert failed: Invalid request"

    def test_usage_with_exception_chaining(self):
        """Test typical usage pattern with exception chaining."""
        original = NotFoundError(message="Resource not found")

        try:
            try:
                # Simulating HTTP call that raises error
                raise original
            except APIError as e:
                # Wrap and re-raise with chaining
                raise wrap_api_error(e, "TestNamespace.method") from e
        except NotFoundError as caught:
            # Verify exception chain is preserved
            assert caught.message == "TestNamespace.method failed: Resource not found"  # noqa: PT017
            assert caught.__cause__ is original  # noqa: PT017
            assert isinstance(caught, NotFoundError)  # noqa: PT017


class TestWrapAPIErrorEdgeCases:
    """Test edge cases and special scenarios."""

    def test_empty_operation_string(self):
        """Test wrapping with empty operation string."""
        original = APIError(message="Error", status_code=500)
        wrapped = wrap_api_error(original, "")
        assert wrapped.message == " failed: Error"

    def test_long_operation_string(self):
        """Test wrapping with very long operation string."""
        original = APIError(message="Error", status_code=500)
        long_operation = "Very.Long.Nested.Namespace.Operation.Name"
        wrapped = wrap_api_error(original, long_operation)
        assert wrapped.message.startswith(long_operation)
        assert "failed: Error" in wrapped.message

    def test_error_message_already_contains_operation(self):
        """Test wrapping when error message already contains operation context."""
        original = BadRequestError(message="Collections.create failed: Invalid name")
        wrapped = wrap_api_error(original, "Collections.create")
        # Should still add context (not deduplicate)
        assert (
            wrapped.message == "Collections.create failed: Collections.create failed: Invalid name"
        )

    def test_none_optional_attributes(self):
        """Test wrapping error with None optional attributes."""
        original = APIError(
            message="Simple error",
            status_code=500,
            response_body=None,
            request_id=None,
            error_code=None,
            url=None,
            method=None,
        )

        wrapped = wrap_api_error(original, "Test.operation")

        assert wrapped.message == "Test.operation failed: Simple error"
        assert wrapped.response_body is None
        assert wrapped.request_id is None
        assert wrapped.error_code is None
        assert wrapped.url is None
        assert wrapped.method is None
