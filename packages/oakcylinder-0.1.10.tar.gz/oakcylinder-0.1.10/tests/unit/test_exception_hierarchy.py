"""Test exception hierarchy matches documentation.

This test ensures that:
1. All exceptions documented in docs/conventions/errors.md exist in the code
2. All exceptions exported from pinecone.__init__ exist
3. Exception hierarchy is correctly structured
"""

import pinecone

from pinecone.exceptions import (
    APIConnectionError,
    APIError,
    BadRequestError,
    ConfigurationError,
    ConflictError,
    ConnectionError as PineconeConnectionError,
    ForbiddenError,
    InvalidAPIKeyError,
    InvalidConfigError,
    NotFoundError,
    PineconeError,
    RateLimitError,
    ServerError,
    TimeoutError as PineconeTimeoutError,
    UnauthorizedError,
)


class TestExceptionHierarchy:
    """Verify exception hierarchy structure."""

    def test_all_exceptions_exist(self):
        """Test that all documented exceptions exist and are importable."""
        # Base exception
        assert PineconeError is not None
        assert issubclass(PineconeError, Exception)

        # Connection errors
        assert APIConnectionError is not None
        assert issubclass(APIConnectionError, PineconeError)
        assert PineconeTimeoutError is not None
        assert issubclass(PineconeTimeoutError, APIConnectionError)
        assert PineconeConnectionError is not None
        assert issubclass(PineconeConnectionError, APIConnectionError)

        # API errors
        assert APIError is not None
        assert issubclass(APIError, PineconeError)
        assert BadRequestError is not None
        assert issubclass(BadRequestError, APIError)
        assert UnauthorizedError is not None
        assert issubclass(UnauthorizedError, APIError)
        assert ForbiddenError is not None
        assert issubclass(ForbiddenError, APIError)
        assert NotFoundError is not None
        assert issubclass(NotFoundError, APIError)
        assert ConflictError is not None
        assert issubclass(ConflictError, APIError)
        assert RateLimitError is not None
        assert issubclass(RateLimitError, APIError)
        assert ServerError is not None
        assert issubclass(ServerError, APIError)

        # Configuration errors
        assert ConfigurationError is not None
        assert issubclass(ConfigurationError, PineconeError)
        assert InvalidAPIKeyError is not None
        assert issubclass(InvalidAPIKeyError, ConfigurationError)
        assert InvalidConfigError is not None
        assert issubclass(InvalidConfigError, ConfigurationError)

    def test_exceptions_exported_from_main_module(self):
        """Test that all exceptions are exported from pinecone module."""
        # All exceptions should be accessible from the main pinecone module
        assert hasattr(pinecone, "PineconeError")
        assert hasattr(pinecone, "APIConnectionError")
        assert hasattr(pinecone, "TimeoutError")
        assert hasattr(pinecone, "ConnectionError")
        assert hasattr(pinecone, "APIError")
        assert hasattr(pinecone, "BadRequestError")
        assert hasattr(pinecone, "UnauthorizedError")
        assert hasattr(pinecone, "ForbiddenError")
        assert hasattr(pinecone, "NotFoundError")
        assert hasattr(pinecone, "ConflictError")
        assert hasattr(pinecone, "RateLimitError")
        assert hasattr(pinecone, "ServerError")
        assert hasattr(pinecone, "ConfigurationError")
        assert hasattr(pinecone, "InvalidAPIKeyError")
        assert hasattr(pinecone, "InvalidConfigError")

        # Verify they're the same classes
        assert pinecone.PineconeError is PineconeError
        assert pinecone.APIConnectionError is APIConnectionError
        assert pinecone.BadRequestError is BadRequestError

    def test_non_existent_exceptions_do_not_exist(self):
        """Test that documented-as-non-existent exceptions really don't exist.

        These exceptions were mentioned in old documentation but never existed:
        - ValidationError (use ValueError or BadRequestError instead)
        - AuthenticationError (use UnauthorizedError instead)
        - PermissionError (use ForbiddenError instead)
        """
        # Verify these do NOT exist in pinecone.exceptions
        from pinecone import exceptions

        assert not hasattr(exceptions, "ValidationError")
        assert not hasattr(exceptions, "AuthenticationError")
        assert not hasattr(exceptions, "PermissionError")

        # Verify they're not exported from main module
        assert not hasattr(pinecone, "ValidationError")
        assert not hasattr(pinecone, "AuthenticationError")
        assert not hasattr(pinecone, "PermissionError")

    def test_api_error_has_required_attributes(self):
        """Test that APIError has all documented attributes."""
        error = APIError(
            message="Test error",
            status_code=400,
            response_body="test body",
            request_id="test-id",
            error_code="TEST_CODE",
            url="https://api.pinecone.io/test",
            method="POST",
        )

        assert error.message == "Test error"
        assert error.status_code == 400
        assert error.response_body == "test body"
        assert error.request_id == "test-id"
        assert error.error_code == "TEST_CODE"
        assert error.url == "https://api.pinecone.io/test"
        assert error.method == "POST"

    def test_rate_limit_error_has_retry_after(self):
        """Test that RateLimitError has retry_after attribute."""
        error = RateLimitError(retry_after=60)

        assert error.retry_after == 60
        assert error.status_code == 429
        assert "60" in error.message

    def test_timeout_error_has_timeout_attribute(self):
        """Test that TimeoutError has timeout attribute."""
        error = PineconeTimeoutError(timeout=30.0)

        assert error.timeout == 30.0
        assert "30.0" in error.message

    def test_connection_error_has_cause(self):
        """Test that ConnectionError can store a cause."""
        cause = Exception("Original error")
        error = PineconeConnectionError("Connection failed", cause=cause)

        assert error.cause is cause
        assert error.message == "Connection failed"

    def test_invalid_config_error_has_field_and_value(self):
        """Test that InvalidConfigError stores field and value."""
        error = InvalidConfigError(field="dimension", value=0, reason="must be positive")

        assert error.field == "dimension"
        assert error.value == 0
        assert "dimension" in error.message
        assert "must be positive" in error.message

    def test_exception_repr_is_detailed(self):
        """Test that exceptions have detailed repr for debugging."""
        error = APIError(
            message="Test error",
            status_code=400,
            request_id="req-123",
            error_code="TEST",
            url="https://api.pinecone.io/test",
            method="POST",
        )

        repr_str = repr(error)
        assert "APIError" in repr_str
        assert "Test error" in repr_str
        assert "400" in repr_str
        assert "req-123" in repr_str
        assert "TEST" in repr_str


class TestExceptionUsagePatterns:
    """Test that exceptions follow documented usage patterns."""

    def test_bad_request_error_default_message(self):
        """Test BadRequestError has helpful default message."""
        error = BadRequestError()

        assert "Bad request" in error.message
        assert "parameters" in error.message
        assert error.status_code == 400

    def test_unauthorized_error_default_message(self):
        """Test UnauthorizedError mentions API key and help URL."""
        error = UnauthorizedError()

        assert "API key" in error.message
        assert "https://app.pinecone.io" in error.message
        assert error.status_code == 401

    def test_forbidden_error_default_message(self):
        """Test ForbiddenError mentions permissions and plan limits."""
        error = ForbiddenError()

        assert "Permission denied" in error.message or "permission" in error.message.lower()
        assert "https://app.pinecone.io" in error.message
        assert error.status_code == 403

    def test_not_found_error_default_message(self):
        """Test NotFoundError mentions list methods."""
        error = NotFoundError()

        assert "not found" in error.message.lower()
        assert "list" in error.message.lower()
        assert error.status_code == 404

    def test_conflict_error_default_message(self):
        """Test ConflictError mentions resource already exists."""
        error = ConflictError()

        assert "already exists" in error.message or "conflict" in error.message.lower()
        assert error.status_code == 409

    def test_server_error_default_message(self):
        """Test ServerError mentions retry and support."""
        error = ServerError()

        assert "Server error" in error.message
        assert "retry" in error.message.lower()
        assert error.status_code == 500

    def test_invalid_api_key_error_message(self):
        """Test InvalidAPIKeyError has clear message about setting API key."""
        error = InvalidAPIKeyError()

        assert "API key is required" in error.message
        assert "PINECONE_API_KEY" in error.message or "api_key" in error.message
