"""Tests for forward compatibility with API responses containing extra fields.

Verifies that the SDK handles API responses with unknown/future fields gracefully,
allowing the API to add new fields before the SDK is updated (forward compatibility).

This is critical for non-breaking API evolution: the API team can add new fields
without requiring coordinated SDK releases.
"""

import respx

from httpx import Response

from pinecone import Pinecone


class TestInferenceAPIForwardCompatibility:
    """Test that Inference API responses with extra fields are handled correctly."""

    @respx.mock
    def test_embed_response_with_extra_fields(self):
        """Verify embed responses with extra fields parse successfully."""
        # Mock API response with extra fields that don't exist in current SDK
        respx.post("https://api.pinecone.io/embed").mock(
            return_value=Response(
                200,
                json={
                    "data": [
                        {"values": [0.1, 0.2, 0.3], "future_field": "ignored"},
                        {"values": [0.4, 0.5, 0.6], "another_extra": 123},
                    ],
                    "model": "test-model",
                    "vector_type": "dense",
                    "usage": {"total_tokens": 10, "extra_usage_field": "ignored"},
                    "future_field": "value",  # Unknown top-level field
                    "experimental_flag": True,  # Another unknown field
                },
            )
        )

        pc = Pinecone(api_key="test-key")
        response = pc.inference.embed(model="test-model", texts=["hello", "world"])

        # Should parse successfully, ignoring unknown fields
        assert response.model == "test-model"
        assert len(response.embeddings) == 2
        assert response.embeddings[0] == [0.1, 0.2, 0.3]
        assert response.embeddings[1] == [0.4, 0.5, 0.6]
        assert response.usage.total_tokens == 10

    @respx.mock
    def test_rerank_response_with_extra_fields(self):
        """Verify rerank responses with extra fields parse successfully."""
        respx.post("https://api.pinecone.io/rerank").mock(
            return_value=Response(
                200,
                json={
                    "data": [
                        {
                            "index": 0,
                            "score": 0.95,
                            "document": {"text": "ML is a subset of AI", "id": "doc1"},
                            "future_relevance_score": 0.98,  # Extra field
                        },
                        {
                            "index": 1,
                            "score": 0.80,
                            "document": {"text": "Python is a language", "id": "doc2"},
                            "experimental_metadata": {"key": "value"},  # Extra field
                        },
                    ],
                    "model": "bge-reranker-v2-m3",
                    "usage": {"rerank_units": 50, "advanced_metrics": [1, 2, 3]},
                    "request_id": "abc-123",  # Unknown top-level field
                },
            )
        )

        pc = Pinecone(api_key="test-key")
        response = pc.inference.rerank(
            model="bge-reranker-v2-m3",
            query="What is machine learning?",
            documents=["ML is a subset of AI", "Python is a language"],
            return_documents=True,
        )

        # Should parse successfully, ignoring unknown fields
        assert response.model == "bge-reranker-v2-m3"
        assert len(response.results) == 2
        assert response.results[0].index == 0
        assert response.results[0].score == 0.95
        assert response.results[0].document == {"text": "ML is a subset of AI", "id": "doc1"}
        assert response.usage.total_tokens == 50

    @respx.mock
    def test_list_models_response_with_extra_fields(self):
        """Verify list_models responses with extra fields parse successfully."""
        respx.get("https://api.pinecone.io/models").mock(
            return_value=Response(
                200,
                json={
                    "models": [
                        {
                            "model": "test-embed-model",
                            "short_description": "Test embedding model",
                            "type": "embed",
                            "modality": "text",
                            "max_sequence_length": 512,
                            "max_batch_size": 96,
                            "provider_name": "test-provider",
                            "supported_parameters": [
                                {
                                    "parameter": "input_type",
                                    "type": "string",
                                    "value_type": "string",
                                    "required": False,
                                    "future_param_field": "ignored",  # Extra field
                                }
                            ],
                            "vector_type": "dense",
                            "default_dimension": 768,
                            "beta_feature": "experimental",  # Unknown field
                            "version": "2.0",  # Unknown field
                        }
                    ],
                    "total_count": 1,  # Unknown top-level field
                    "api_version": "2025-10",  # Unknown field
                },
            )
        )

        pc = Pinecone(api_key="test-key")
        response = pc.inference.list_models()

        # Should parse successfully, ignoring unknown fields
        assert len(response.models) == 1
        assert response.models[0].model == "test-embed-model"
        assert response.models[0].type == "embed"
        assert response.models[0].default_dimension == 768


class TestCollectionsAPIForwardCompatibility:
    """Test that Collections API responses with extra fields are handled correctly."""

    @respx.mock
    def test_describe_collection_with_extra_fields(self):
        """Verify describe collection responses with extra fields parse successfully."""
        respx.get("https://api.pinecone.io/collections/test-collection").mock(
            return_value=Response(
                200,
                json={
                    "name": "test-collection",
                    "size": 1000000,
                    "status": "Ready",
                    "dimension": 768,
                    "vector_count": 5000,
                    "environment": "us-east-1",
                    "created_at": "2026-01-01T00:00:00Z",  # Future field
                    "tags": {"key": "value"},  # Future field
                    "metadata_config": {"indexed": ["field1"]},  # Future field
                },
            )
        )

        pc = Pinecone(api_key="test-key")
        collection = pc.collections.describe("test-collection")

        # Should parse successfully, ignoring unknown fields
        assert collection.name == "test-collection"
        assert collection.size == 1000000
        assert collection.status == "Ready"
        assert collection.dimension == 768
        assert collection.vector_count == 5000

    @respx.mock
    def test_list_collections_with_extra_fields(self):
        """Verify list collections responses with extra fields parse successfully."""
        respx.get("https://api.pinecone.io/collections").mock(
            return_value=Response(
                200,
                json={
                    "collections": [
                        {
                            "name": "coll1",
                            "size": 1000,
                            "status": "Ready",
                            "dimension": 128,
                            "vector_count": 100,
                            "environment": "us-east-1",
                            "cost_estimate": "$5/month",  # Future field
                        },
                        {
                            "name": "coll2",
                            "size": 2000,
                            "status": "Ready",
                            "dimension": 256,
                            "vector_count": 200,
                            "environment": "us-west-1",
                            "performance_tier": "standard",  # Future field
                        },
                    ],
                    "total_count": 2,  # Unknown top-level field
                    "pagination": {"next": None},
                },
            )
        )

        pc = Pinecone(api_key="test-key")
        collections = list(pc.collections.list())

        # Should parse successfully, ignoring unknown fields
        assert len(collections) == 2
        assert collections[0].name == "coll1"
        assert collections[0].dimension == 128
        assert collections[1].name == "coll2"
        assert collections[1].dimension == 256


class TestBackupsAPIForwardCompatibility:
    """Test that Backups API responses with extra fields are handled correctly."""

    @respx.mock
    def test_describe_backup_with_extra_fields(self):
        """Verify describe backup responses with extra fields parse successfully."""
        respx.get("https://api.pinecone.io/backups/backup-123").mock(
            return_value=Response(
                200,
                json={
                    "backup_id": "backup-123",
                    "source_index_name": "my-index",
                    "source_index_id": "index-456",
                    "status": "Ready",
                    "cloud": "aws",
                    "region": "us-east-1",
                    "created_at": "2026-01-01T00:00:00Z",
                    "name": "my-backup",
                    "dimension": 768,
                    "record_count": 5000,
                    "encryption_type": "aes-256",  # Future field
                    "retention_policy": "30d",  # Future field
                    "cost_to_date": "$2.50",  # Future field
                },
            )
        )

        pc = Pinecone(api_key="test-key")
        backup = pc.backups.describe("backup-123")

        # Should parse successfully, ignoring unknown fields
        assert backup.backup_id == "backup-123"
        assert backup.source_index_name == "my-index"
        assert backup.status == "Ready"
        assert backup.dimension == 768
        assert backup.record_count == 5000

    @respx.mock
    def test_list_backups_with_extra_fields(self):
        """Verify list backups responses with extra fields parse successfully."""
        respx.get("https://api.pinecone.io/backups").mock(
            return_value=Response(
                200,
                json={
                    "data": [
                        {
                            "backup_id": "backup-1",
                            "source_index_name": "index-1",
                            "source_index_id": "id-1",
                            "status": "Ready",
                            "cloud": "aws",
                            "region": "us-east-1",
                            "created_at": "2026-01-01T00:00:00Z",
                            "backup_type": "full",  # Future field
                        },
                        {
                            "backup_id": "backup-2",
                            "source_index_name": "index-2",
                            "source_index_id": "id-2",
                            "status": "Ready",
                            "cloud": "gcp",
                            "region": "us-central1",
                            "created_at": "2026-01-02T00:00:00Z",
                            "compression_ratio": 0.75,  # Future field
                        },
                    ],
                    "total_count": 2,  # Unknown top-level field
                    "pagination": {"next": None},
                },
            )
        )

        pc = Pinecone(api_key="test-key")
        backups = list(pc.backups.list())

        # Should parse successfully, ignoring unknown fields
        assert len(backups) == 2
        assert backups[0].backup_id == "backup-1"
        assert backups[0].cloud == "aws"
        assert backups[1].backup_id == "backup-2"
        assert backups[1].cloud == "gcp"


class TestIndexAPIForwardCompatibility:
    """Test that Index API responses with extra fields are handled correctly.

    Note: Index API adapters already use msgspec.convert() and are comprehensively
    tested in test_indexes.py and test_indexes_basic.py with various response
    structures. This demonstrates that msgspec-based adapters naturally support
    forward compatibility without requiring migration.
    """

    def test_index_adapters_use_msgspec(self):
        """Document that Index adapters already use msgspec.convert() for forward compatibility."""
        # This is a documentation test to note that index adapters already use
        # the forward-compatible msgspec.convert() pattern and don't need migration.
        # See tests/unit/test_indexes.py for comprehensive index response testing.
        from pinecone._internal.adapters.indexes import describe_adapter

        # Verify the adapter uses msgspec.convert() internally
        assert hasattr(describe_adapter, "from_response")
        # The actual forward compatibility is tested in test_indexes.py
