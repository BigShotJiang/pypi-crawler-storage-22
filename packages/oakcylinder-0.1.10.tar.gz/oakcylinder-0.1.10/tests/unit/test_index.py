"""Unit tests for Index data plane client."""

import os

import pytest

from pinecone.index import Index


pytestmark = pytest.mark.unit


class TestIndexConstruction:
    """Tests for Index initialization and configuration."""

    def test_construction_with_host_and_api_key(self):
        index = Index(host="my-index-abc123.svc.pinecone.io", api_key="test-key")

        assert index._host == "my-index-abc123.svc.pinecone.io"
        assert index._api_key == "test-key"

    def test_requires_api_key(self):
        original_api_key = os.environ.get("PINECONE_API_KEY")

        try:
            if "PINECONE_API_KEY" in os.environ:
                del os.environ["PINECONE_API_KEY"]

            with pytest.raises(ValueError, match="api_key is required"):
                Index(host="my-index.svc.pinecone.io")
        finally:
            if original_api_key is not None:
                os.environ["PINECONE_API_KEY"] = original_api_key

    def test_uses_env_var_api_key(self):
        original_api_key = os.environ.get("PINECONE_API_KEY")

        try:
            os.environ["PINECONE_API_KEY"] = "env-test-key"
            index = Index(host="my-index.svc.pinecone.io")
            assert index._api_key == "env-test-key"
        finally:
            if original_api_key is not None:
                os.environ["PINECONE_API_KEY"] = original_api_key
            elif "PINECONE_API_KEY" in os.environ:
                del os.environ["PINECONE_API_KEY"]

    def test_parameter_overrides_env_var(self):
        original_api_key = os.environ.get("PINECONE_API_KEY")

        try:
            os.environ["PINECONE_API_KEY"] = "env-key"
            index = Index(host="my-index.svc.pinecone.io", api_key="param-key")
            assert index._api_key == "param-key"
        finally:
            if original_api_key is not None:
                os.environ["PINECONE_API_KEY"] = original_api_key
            elif "PINECONE_API_KEY" in os.environ:
                del os.environ["PINECONE_API_KEY"]

    def test_default_timeout(self):
        index = Index(host="my-index.svc.pinecone.io", api_key="test-key")
        assert index._timeout == 30
        assert index._http._config.timeout == 30

    def test_custom_timeout(self):
        index = Index(host="my-index.svc.pinecone.io", api_key="test-key", timeout=60)
        assert index._timeout == 60
        assert index._http._config.timeout == 60

    def test_granular_timeout(self):
        timeout_config = {"connect": 5, "read": 120}
        index = Index(host="my-index.svc.pinecone.io", api_key="test-key", timeout=timeout_config)
        assert index._timeout == timeout_config
        assert index._http._config.timeout == timeout_config

    def test_additional_headers_stored(self):
        headers = {"X-Custom": "value"}
        index = Index(
            host="my-index.svc.pinecone.io",
            api_key="test-key",
            additional_headers=headers,
        )
        assert index._additional_headers == headers

    def test_keyword_only_args(self):
        with pytest.raises(TypeError):
            Index("my-index.svc.pinecone.io", "test-key")  # type: ignore[misc]


class TestIndexLifecycle:
    """Tests for Index context manager and close()."""

    def test_context_manager(self):
        with Index(host="my-index.svc.pinecone.io", api_key="test-key") as index:
            assert index is not None
            assert isinstance(index, Index)

    def test_close(self):
        index = Index(host="my-index.svc.pinecone.io", api_key="test-key")
        index.close()  # Should not raise

    def test_repr(self):
        index = Index(host="my-index-abc123.svc.pinecone.io", api_key="test-key")
        assert repr(index) == "Index(host='my-index-abc123.svc.pinecone.io')"

    def test_multiple_instances(self):
        idx1 = Index(host="host-a.svc.pinecone.io", api_key="key1")
        idx2 = Index(host="host-b.svc.pinecone.io", api_key="key2")

        assert idx1 is not idx2
        assert idx1._host != idx2._host


class TestIndexExport:
    """Tests for Index availability from pinecone package."""

    def test_importable_from_package(self):
        from pinecone import Index as PineconeIndex

        assert PineconeIndex is Index
