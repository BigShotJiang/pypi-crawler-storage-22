"""Test integration of Documents namespace with Index."""

from pinecone.async_index import AsyncIndex
from pinecone.index import Index


def test_index_has_documents_property():
    """Test that Index has documents property."""
    index = Index(host="test.io", api_key="test")

    assert hasattr(index, "documents")

    # Access property to trigger lazy loading
    documents = index.documents
    assert documents is not None

    # Verify it's cached - accessing again returns same instance
    documents2 = index.documents
    assert documents2 is documents


def test_async_index_has_documents_property():
    """Test that AsyncIndex has documents property."""
    index = AsyncIndex(host="test.io", api_key="test")

    assert hasattr(index, "documents")

    documents = index.documents
    assert documents is not None

    # Verify it's cached
    documents2 = index.documents
    assert documents2 is documents
