"""Unit tests for Inference namespace."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import httpx
import orjson
import pytest

from pinecone.__interface__.inference import (
    EmbeddingResponseProtocol,
    InferenceNamespaceProtocol,
    ListModelsResponseProtocol,
    RerankResponseProtocol,
)
from pinecone._internal.constants import INFERENCE_API_VERSION
from pinecone._internal.http import HTTPClient
from pinecone.client.inference import Inference
from pinecone.exceptions import (
    APIConnectionError,
    APIError,
    TimeoutError as PineconeTimeoutError,
)


pytestmark = pytest.mark.unit


class TestInferenceProtocolCompliance:
    """Tests for protocol compliance."""

    def test_inference_satisfies_protocol(self):
        """Test that Inference class satisfies InferenceNamespaceProtocol."""
        http_client = MagicMock(spec=HTTPClient)
        inference = Inference(http_client=http_client)

        assert isinstance(inference, InferenceNamespaceProtocol)


class TestInferenceEmbed:
    """Tests for the embed() method."""

    @pytest.fixture()
    def mock_http_client(self) -> MagicMock:
        """Create a mock HTTP client."""
        return MagicMock(spec=HTTPClient)

    @pytest.fixture()
    def inference(self, mock_http_client: MagicMock) -> Inference:
        """Create an Inference instance with mock HTTP client."""
        return Inference(http_client=mock_http_client)

    @pytest.fixture()
    def embed_response_data(self) -> dict[str, Any]:
        """Sample embed API response data."""
        return {
            "data": [
                {"values": [0.1, 0.2, 0.3]},
                {"values": [0.4, 0.5, 0.6]},
            ],
            "model": "multilingual-e5-large",
            "vector_type": "dense",
            "usage": {"total_tokens": 10},
        }

    def test_embed_success(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
        embed_response_data: dict[str, Any],
    ):
        """Test successful embedding generation."""
        # Setup mock response
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(embed_response_data)
        mock_http_client.post.return_value = mock_response

        # Call embed
        result = inference.embed(
            model="multilingual-e5-large",
            texts=["Hello world", "Goodbye world"],
        )

        # Verify response
        assert isinstance(result, EmbeddingResponseProtocol)
        assert result.model == "multilingual-e5-large"
        assert len(result.embeddings) == 2
        assert result.embeddings[0] == [0.1, 0.2, 0.3]
        assert result.embeddings[1] == [0.4, 0.5, 0.6]
        assert result.usage.total_tokens == 10

        # Verify HTTP call
        mock_http_client.post.assert_called_once()
        call_args = mock_http_client.post.call_args
        assert "embed" in call_args[0][0]
        assert call_args[1]["headers"]["X-Pinecone-Api-Version"] == INFERENCE_API_VERSION

    def test_embed_with_parameters(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
        embed_response_data: dict[str, Any],
    ):
        """Test embedding with optional parameters."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(embed_response_data)
        mock_http_client.post.return_value = mock_response

        result = inference.embed(
            model="multilingual-e5-large",
            texts=["Hello world"],
            parameters={"input_type": "query", "truncate": "END"},
        )

        assert isinstance(result, EmbeddingResponseProtocol)
        assert result.model == "multilingual-e5-large"

    def test_embed_empty_texts_raises_error(self, inference: Inference):
        """Test that empty texts list raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            inference.embed(model="test-model", texts=[])

        assert "texts" in str(exc_info.value)
        assert "non-empty" in str(exc_info.value)

    def test_embed_missing_model_raises_error(self, inference: Inference):
        """Test that missing model raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            inference.embed(model="", texts=["Hello"])

        assert "model" in str(exc_info.value)
        assert "non-empty" in str(exc_info.value)

    def test_embed_single_text(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
    ):
        """Test embedding a single text string."""
        response_data = {
            "data": [{"values": [0.1, 0.2, 0.3]}],
            "model": "test-model",
            "vector_type": "dense",
            "usage": {"total_tokens": 5},
        }
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(response_data)
        mock_http_client.post.return_value = mock_response

        result = inference.embed(model="test-model", texts=["Single text"])

        assert len(result.embeddings) == 1
        assert result.embeddings[0] == [0.1, 0.2, 0.3]


class TestInferenceRerank:
    """Tests for the rerank() method."""

    @pytest.fixture()
    def mock_http_client(self) -> MagicMock:
        """Create a mock HTTP client."""
        return MagicMock(spec=HTTPClient)

    @pytest.fixture()
    def inference(self, mock_http_client: MagicMock) -> Inference:
        """Create an Inference instance with mock HTTP client."""
        return Inference(http_client=mock_http_client)

    @pytest.fixture()
    def rerank_response_data(self) -> dict[str, Any]:
        """Sample rerank API response data."""
        return {
            "data": [
                {"index": 0, "score": 0.95},
                {"index": 2, "score": 0.85},
                {"index": 1, "score": 0.45},
            ],
            "model": "bge-reranker-v2-m3",
            "usage": {"rerank_units": 3},
        }

    def test_rerank_success(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
        rerank_response_data: dict[str, Any],
    ):
        """Test successful document reranking."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(rerank_response_data)
        mock_http_client.post.return_value = mock_response

        result = inference.rerank(
            model="bge-reranker-v2-m3",
            query="What is machine learning?",
            documents=[
                "Machine learning is a subset of AI",
                "Python is a programming language",
                "Deep learning uses neural networks",
            ],
        )

        assert isinstance(result, RerankResponseProtocol)
        assert result.model == "bge-reranker-v2-m3"
        assert len(result.results) == 3
        assert result.results[0].index == 0
        assert result.results[0].score == 0.95

        # Verify HTTP call
        mock_http_client.post.assert_called_once()
        call_args = mock_http_client.post.call_args
        assert "rerank" in call_args[0][0]
        assert call_args[1]["headers"]["X-Pinecone-Api-Version"] == INFERENCE_API_VERSION

    def test_rerank_with_top_n(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
    ):
        """Test reranking with top_n parameter."""
        response_data = {
            "data": [
                {"index": 0, "score": 0.95},
                {"index": 2, "score": 0.85},
            ],
            "model": "bge-reranker-v2-m3",
            "usage": {"rerank_units": 2},
        }
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(response_data)
        mock_http_client.post.return_value = mock_response

        result = inference.rerank(
            model="bge-reranker-v2-m3",
            query="What is AI?",
            documents=["Doc 1", "Doc 2", "Doc 3"],
            top_n=2,
        )

        assert len(result.results) == 2

    def test_rerank_with_return_documents(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
    ):
        """Test reranking with return_documents=True."""
        response_data = {
            "data": [
                {
                    "index": 0,
                    "score": 0.95,
                    "document": {"text": "Machine learning is AI", "id": "doc1"},
                },
            ],
            "model": "bge-reranker-v2-m3",
            "usage": {"rerank_units": 1},
        }
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(response_data)
        mock_http_client.post.return_value = mock_response

        result = inference.rerank(
            model="bge-reranker-v2-m3",
            query="What is AI?",
            documents=["Machine learning is AI"],
            return_documents=True,
        )

        assert len(result.results) == 1
        assert result.results[0].document == {"text": "Machine learning is AI", "id": "doc1"}

    def test_rerank_empty_query_raises_error(self, inference: Inference):
        """Test that empty query raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            inference.rerank(
                model="test-model",
                query="",
                documents=["Doc 1"],
            )

        assert "query" in str(exc_info.value)
        assert "non-empty" in str(exc_info.value)

    def test_rerank_empty_documents_raises_error(self, inference: Inference):
        """Test that empty documents list raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            inference.rerank(
                model="test-model",
                query="What is AI?",
                documents=[],
            )

        assert "documents" in str(exc_info.value)
        assert "non-empty" in str(exc_info.value)

    def test_rerank_missing_model_raises_error(self, inference: Inference):
        """Test that missing model raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            inference.rerank(
                model="",
                query="What is AI?",
                documents=["Doc 1"],
            )

        assert "model" in str(exc_info.value)
        assert "non-empty" in str(exc_info.value)

    def test_rerank_top_n_too_small_raises_error(self, inference: Inference):
        """Test that top_n < 1 raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            inference.rerank(
                model="test-model",
                query="What is AI?",
                documents=["Doc 1", "Doc 2"],
                top_n=0,
            )

        assert "top_n" in str(exc_info.value)
        assert "between 1 and 2" in str(exc_info.value)

    def test_rerank_top_n_too_large_raises_error(self, inference: Inference):
        """Test that top_n > len(documents) raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            inference.rerank(
                model="test-model",
                query="What is AI?",
                documents=["Doc 1", "Doc 2"],
                top_n=5,
            )

        assert "top_n" in str(exc_info.value)
        assert "between 1 and 2" in str(exc_info.value)

    def test_rerank_top_n_equal_to_documents_succeeds(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
    ):
        """Test that top_n == len(documents) is valid."""
        response_data = {
            "data": [
                {"index": 0, "score": 0.95},
                {"index": 1, "score": 0.85},
            ],
            "model": "test-model",
            "usage": {"rerank_units": 2},
        }
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(response_data)
        mock_http_client.post.return_value = mock_response

        result = inference.rerank(
            model="test-model",
            query="What is AI?",
            documents=["Doc 1", "Doc 2"],
            top_n=2,
        )

        assert len(result.results) == 2


class TestInferenceConfiguration:
    """Tests for Inference configuration."""

    def test_custom_base_url(self):
        """Test that custom base_url is used in requests."""
        mock_http_client = MagicMock(spec=HTTPClient)
        inference = Inference(
            http_client=mock_http_client,
            base_url="https://custom.pinecone.io",
        )

        # Setup mock response
        response_data = {
            "data": [{"values": [0.1, 0.2]}],
            "model": "test-model",
            "vector_type": "dense",
            "usage": {"total_tokens": 5},
        }
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(response_data)
        mock_http_client.post.return_value = mock_response

        inference.embed(model="test-model", texts=["Hello"])

        # Verify custom base URL is used
        call_args = mock_http_client.post.call_args
        assert call_args[0][0] == "https://custom.pinecone.io/embed"

    def test_repr_with_default_base_url(self):
        """Test __repr__ with default base_url."""
        mock_http_client = MagicMock(spec=HTTPClient)
        inference = Inference(http_client=mock_http_client)

        assert repr(inference) == "Inference(base_url='https://api.pinecone.io')"

    def test_repr_with_custom_base_url(self):
        """Test __repr__ with custom base_url."""
        mock_http_client = MagicMock(spec=HTTPClient)
        inference = Inference(
            http_client=mock_http_client,
            base_url="https://custom.pinecone.io",
        )

        assert repr(inference) == "Inference(base_url='https://custom.pinecone.io')"


class TestInferenceTimeout:
    """Tests for timeout parameter support."""

    @pytest.fixture()
    def mock_http_client(self) -> MagicMock:
        """Create a mock HTTP client."""
        return MagicMock(spec=HTTPClient)

    @pytest.fixture()
    def inference(self, mock_http_client: MagicMock) -> Inference:
        """Create an Inference instance with mock HTTP client."""
        return Inference(http_client=mock_http_client)

    @pytest.fixture()
    def embed_response_data(self) -> dict[str, Any]:
        """Sample embed API response data."""
        return {
            "data": [{"values": [0.1, 0.2, 0.3]}],
            "model": "multilingual-e5-large",
            "vector_type": "dense",
            "usage": {"total_tokens": 5},
        }

    @pytest.fixture()
    def rerank_response_data(self) -> dict[str, Any]:
        """Sample rerank API response data."""
        return {
            "data": [{"index": 0, "score": 0.95}],
            "model": "bge-reranker-v2-m3",
            "usage": {"total_tokens": 10},
        }

    def test_embed_with_timeout(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
        embed_response_data: dict[str, Any],
    ):
        """Test that timeout parameter is passed to HTTP client."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(embed_response_data)
        mock_http_client.post.return_value = mock_response

        inference.embed(
            model="multilingual-e5-large",
            texts=["Hello world"],
            timeout=5.0,
        )

        # Verify timeout was passed to HTTP client
        call_args = mock_http_client.post.call_args
        assert call_args[1]["timeout"] == 5.0

    def test_embed_without_timeout(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
        embed_response_data: dict[str, Any],
    ):
        """Test that timeout parameter is omitted when None."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(embed_response_data)
        mock_http_client.post.return_value = mock_response

        inference.embed(
            model="multilingual-e5-large",
            texts=["Hello world"],
        )

        # Verify timeout was not passed to HTTP client
        call_args = mock_http_client.post.call_args
        assert "timeout" not in call_args[1]

    def test_rerank_with_timeout(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
        rerank_response_data: dict[str, Any],
    ):
        """Test that timeout parameter is passed to HTTP client for rerank."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(rerank_response_data)
        mock_http_client.post.return_value = mock_response

        inference.rerank(
            model="bge-reranker-v2-m3",
            query="What is AI?",
            documents=["AI is..."],
            timeout=10.0,
        )

        # Verify timeout was passed to HTTP client
        call_args = mock_http_client.post.call_args
        assert call_args[1]["timeout"] == 10.0

    def test_rerank_without_timeout(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
        rerank_response_data: dict[str, Any],
    ):
        """Test that timeout parameter is omitted when None for rerank."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(rerank_response_data)
        mock_http_client.post.return_value = mock_response

        inference.rerank(
            model="bge-reranker-v2-m3",
            query="What is AI?",
            documents=["AI is..."],
        )

        # Verify timeout was not passed to HTTP client
        call_args = mock_http_client.post.call_args
        assert "timeout" not in call_args[1]


class TestInferenceListModels:
    """Tests for the list_models() method."""

    @pytest.fixture()
    def mock_http_client(self) -> MagicMock:
        """Create a mock HTTP client."""
        return MagicMock(spec=HTTPClient)

    @pytest.fixture()
    def inference(self, mock_http_client: MagicMock) -> Inference:
        """Create an Inference instance with mock HTTP client."""
        return Inference(http_client=mock_http_client)

    @pytest.fixture()
    def list_models_response_data(self) -> dict[str, Any]:
        """Sample list_models API response data."""
        return {
            "models": [
                {
                    "model": "multilingual-e5-large",
                    "short_description": "A high-performance dense embedding model",
                    "type": "embed",
                    "vector_type": "dense",
                    "default_dimension": 1024,
                    "modality": "text",
                    "max_sequence_length": 512,
                    "max_batch_size": 96,
                    "provider_name": "Microsoft",
                    "supported_dimensions": [1024],
                    "supported_metrics": ["cosine", "euclidean"],
                    "supported_parameters": [
                        {
                            "parameter": "input_type",
                            "required": True,
                            "type": "one_of",
                            "value_type": "string",
                            "allowed_values": ["query", "passage"],
                        },
                        {
                            "parameter": "truncate",
                            "required": False,
                            "default": "END",
                            "type": "one_of",
                            "value_type": "string",
                            "allowed_values": ["END", "NONE"],
                        },
                    ],
                },
                {
                    "model": "bge-reranker-v2-m3",
                    "short_description": "A high-performance multilingual reranking model",
                    "type": "rerank",
                    "modality": "text",
                    "max_sequence_length": 1024,
                    "max_batch_size": 100,
                    "provider_name": "BAAI",
                    "supported_parameters": [
                        {
                            "parameter": "truncate",
                            "required": False,
                            "default": "NONE",
                            "type": "one_of",
                            "value_type": "string",
                            "allowed_values": ["END", "NONE"],
                        }
                    ],
                },
            ]
        }

    def test_list_models_success(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
        list_models_response_data: dict[str, Any],
    ):
        """Test successful list_models operation."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(list_models_response_data)
        mock_http_client.get.return_value = mock_response

        result = inference.list_models()

        assert isinstance(result, ListModelsResponseProtocol)
        assert len(result.models) == 2

        # Check first model (embed)
        embed_model = result.models[0]
        assert embed_model.model == "multilingual-e5-large"
        assert embed_model.type == "embed"
        assert embed_model.vector_type == "dense"
        assert embed_model.default_dimension == 1024
        assert embed_model.provider_name == "Microsoft"
        assert len(embed_model.supported_parameters) == 2

        # Check parameter structure
        input_type_param = embed_model.supported_parameters[0]
        assert input_type_param.parameter == "input_type"
        assert input_type_param.required is True
        assert input_type_param.type == "one_of"
        assert input_type_param.value_type == "string"
        assert input_type_param.allowed_values == ["query", "passage"]

        # Check second model (rerank)
        rerank_model = result.models[1]
        assert rerank_model.model == "bge-reranker-v2-m3"
        assert rerank_model.type == "rerank"
        assert rerank_model.vector_type is None  # rerank models don't have vector_type

        # Verify HTTP call
        mock_http_client.get.assert_called_once()
        call_args = mock_http_client.get.call_args
        assert "models" in call_args[0][0]
        assert call_args[1]["headers"]["X-Pinecone-Api-Version"] == INFERENCE_API_VERSION

    def test_list_models_with_type_filter(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
    ):
        """Test list_models with type filter."""
        response_data = {
            "models": [
                {
                    "model": "multilingual-e5-large",
                    "short_description": "Embedding model",
                    "type": "embed",
                    "vector_type": "dense",
                    "default_dimension": 1024,
                    "modality": "text",
                    "max_sequence_length": 512,
                    "max_batch_size": 96,
                    "provider_name": "Microsoft",
                    "supported_dimensions": [1024],
                    "supported_metrics": ["cosine"],
                    "supported_parameters": [],
                }
            ]
        }
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(response_data)
        mock_http_client.get.return_value = mock_response

        result = inference.list_models(model_type="embed")

        assert len(result.models) == 1
        assert result.models[0].type == "embed"

        # Verify query params were sent
        call_args = mock_http_client.get.call_args
        assert call_args[1]["params"]["type"] == "embed"

    def test_list_models_with_vector_type_filter(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
    ):
        """Test list_models with vector_type filter."""
        response_data = {
            "models": [
                {
                    "model": "pinecone-sparse-english-v0",
                    "short_description": "Sparse embedding model",
                    "type": "embed",
                    "vector_type": "sparse",
                    "modality": "text",
                    "max_sequence_length": 512,
                    "max_batch_size": 96,
                    "provider_name": "Pinecone",
                    "supported_metrics": ["dotproduct"],
                    "supported_parameters": [],
                }
            ]
        }
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(response_data)
        mock_http_client.get.return_value = mock_response

        result = inference.list_models(model_type="embed", vector_type="sparse")

        assert len(result.models) == 1
        assert result.models[0].vector_type == "sparse"

        # Verify query params were sent
        call_args = mock_http_client.get.call_args
        assert call_args[1]["params"]["type"] == "embed"
        assert call_args[1]["params"]["vector_type"] == "sparse"

    def test_list_models_with_timeout(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
        list_models_response_data: dict[str, Any],
    ):
        """Test that timeout parameter is passed to HTTP client."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(list_models_response_data)
        mock_http_client.get.return_value = mock_response

        inference.list_models(timeout=5.0)

        # Verify timeout was passed to HTTP client
        call_args = mock_http_client.get.call_args
        assert call_args[1]["timeout"] == 5.0

    def test_list_models_without_filters(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
        list_models_response_data: dict[str, Any],
    ):
        """Test list_models without any filters."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.content = _json_bytes(list_models_response_data)
        mock_http_client.get.return_value = mock_response

        result = inference.list_models()

        assert len(result.models) == 2

        # Verify no params were sent
        call_args = mock_http_client.get.call_args
        assert "params" not in call_args[1] or call_args[1]["params"] is None


class TestInferenceErrorContext:
    """Tests for error context in _make_inference_request."""

    @pytest.fixture()
    def mock_http_client(self) -> MagicMock:
        """Create a mock HTTP client."""
        return MagicMock(spec=HTTPClient)

    @pytest.fixture()
    def inference(self, mock_http_client: MagicMock) -> Inference:
        """Create an Inference instance with mock HTTP client."""
        return Inference(http_client=mock_http_client)

    def test_embed_api_error_includes_context(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
    ):
        """Test that APIError from embed includes operation context."""
        # Setup mock to raise APIError
        original_error = APIError(
            "Invalid model", status_code=400, response_body='{"error": "invalid"}'
        )
        mock_http_client.post.side_effect = original_error

        # Call embed and verify error message includes context
        with pytest.raises(APIError) as exc_info:
            inference.embed(model="test-model", texts=["Hello"])

        assert "Inference.embed failed" in str(exc_info.value)
        assert "Invalid model" in str(exc_info.value)
        assert exc_info.value.status_code == 400
        assert exc_info.value.response_body == '{"error": "invalid"}'
        assert exc_info.value.__cause__ is original_error

    def test_rerank_api_error_includes_context(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
    ):
        """Test that APIError from rerank includes operation context."""
        # Setup mock to raise APIError
        original_error = APIError("Rate limit exceeded", status_code=429)
        mock_http_client.post.side_effect = original_error

        # Call rerank and verify error message includes context
        with pytest.raises(APIError) as exc_info:
            inference.rerank(
                model="test-model",
                query="What is AI?",
                documents=["AI is..."],
            )

        assert "Inference.rerank failed" in str(exc_info.value)
        assert "Rate limit exceeded" in str(exc_info.value)
        assert exc_info.value.status_code == 429
        assert exc_info.value.__cause__ is original_error

    def test_embed_connection_error_includes_context(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
    ):
        """Test that APIConnectionError from embed includes operation context."""
        # Setup mock to raise APIConnectionError
        original_error = APIConnectionError("Failed to connect")
        mock_http_client.post.side_effect = original_error

        # Call embed and verify error message includes context
        with pytest.raises(APIConnectionError) as exc_info:
            inference.embed(model="test-model", texts=["Hello"])

        assert "Inference.embed failed" in str(exc_info.value)
        assert "Failed to connect" in str(exc_info.value)
        assert exc_info.value.__cause__ is original_error

    def test_rerank_timeout_error_includes_context(
        self,
        inference: Inference,
        mock_http_client: MagicMock,
    ):
        """Test that TimeoutError from rerank includes operation context."""
        # Setup mock to raise TimeoutError (subclass of APIConnectionError)
        original_error = PineconeTimeoutError(timeout=30.0)
        mock_http_client.post.side_effect = original_error

        # Call rerank and verify error message includes context
        with pytest.raises(APIConnectionError) as exc_info:
            inference.rerank(
                model="test-model",
                query="What is AI?",
                documents=["AI is..."],
            )

        assert "Inference.rerank failed" in str(exc_info.value)
        assert "timed out" in str(exc_info.value).lower()
        assert exc_info.value.__cause__ is original_error


class TestInferenceIntrospection:
    """Tests for interactive introspection features (__dir__ and __getattr__)."""

    @pytest.fixture()
    def inference(self) -> Inference:
        """Create an Inference instance for testing."""
        mock_http_client = MagicMock(spec=HTTPClient)
        return Inference(http_client=mock_http_client)

    def test_dir_returns_public_methods_only(self, inference: Inference):
        """Test that __dir__ returns only public methods, not private attributes."""
        methods = dir(inference)

        # Should include public methods
        assert "embed" in methods
        assert "rerank" in methods

        # Should NOT include private attributes
        assert "_http" not in methods
        assert "_base_url" not in methods
        assert "_adapter" not in methods
        assert "_make_inference_request" not in methods

        # Should NOT include dunder methods
        assert "__init__" not in methods
        assert "__repr__" not in methods

    def test_dir_returns_sorted_list(self, inference: Inference):
        """Test that __dir__ returns a sorted list for consistency."""
        methods = dir(inference)

        # Should be sorted alphabetically
        assert methods == sorted(methods)

    def test_getattr_nonexistent_attribute_shows_helpful_error(self, inference: Inference):
        """Test that accessing non-existent attribute shows helpful error."""
        with pytest.raises(AttributeError) as exc_info:
            _ = inference.embeddings  # Typo: should be "embed"

        error_message = str(exc_info.value)

        # Should mention the attribute that was accessed
        assert "embeddings" in error_message

        # Should list available methods
        assert "embed" in error_message
        assert "rerank" in error_message

        # Should suggest how to explore
        assert "dir(" in error_message or "help(" in error_message

    def test_getattr_uses_dynamic_discovery(self, inference: Inference):
        """Test that __getattr__ dynamically discovers available methods."""
        with pytest.raises(AttributeError) as exc_info:
            _ = inference.nonexistent_method

        error_message = str(exc_info.value)

        # Should include actual available methods
        assert "embed" in error_message
        assert "rerank" in error_message

        # Should NOT include private methods
        assert "_http" not in error_message
        assert "_make_inference_request" not in error_message

    def test_dir_filters_only_callable_methods(self, inference: Inference):
        """Test that __dir__ only includes callable methods, not properties."""
        methods = dir(inference)

        # All returned items should be callable
        for method_name in methods:
            attr = getattr(type(inference), method_name)
            assert callable(attr), f"{method_name} should be callable"

    def test_dir_includes_all_eagerly_bound_methods(self, inference: Inference):
        """Test that dir() includes all methods from subpackage files after eager binding.

        This test verifies that the eager method binding in __init__ correctly
        makes all methods discoverable via dir(). Methods are bound from separate
        files (_embed.py, _rerank.py, _list_models.py) to enable parallel development.
        """
        methods = dir(inference)

        # Verify all public methods from subpackage files are bound and discoverable
        expected_methods = ["embed", "list_models", "rerank"]
        for method in expected_methods:
            assert method in methods, f"Method '{method}' should be in dir() output"

        # Verify methods are actually callable and bound to the instance
        for method_name in expected_methods:
            method = getattr(inference, method_name)
            assert callable(method), f"{method_name} should be callable"
            assert hasattr(method, "__self__"), f"{method_name} should be a bound method"
            assert method.__self__ is inference, f"{method_name} should be bound to instance"

        # Verify the exact set matches (no extras, no missing)
        assert set(methods) == set(expected_methods), (
            "dir() should return exactly the public methods"
        )


def _json_bytes(data: dict[str, Any]) -> bytes:
    """Convert dict to JSON bytes for mock responses."""
    return orjson.dumps(data)
