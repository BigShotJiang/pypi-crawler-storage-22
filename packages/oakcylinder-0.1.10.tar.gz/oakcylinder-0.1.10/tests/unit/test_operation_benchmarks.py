"""Performance benchmarks for core SDK operations.

Measures SDK overhead (serialization, validation, parsing) for:
- Document upsert and search
- Vector upsert and query

Uses respx mocking to eliminate network and server latency from measurements.
Tests multiple batch sizes for both sync and async clients.

These benchmarks are marked as opt-in only to avoid adding overhead to normal
test runs. Run them explicitly when measuring performance:

    # Run only benchmarks
    pytest -m benchmark

    # Run unit tests WITHOUT benchmarks (default workflow)
    pytest tests/unit/ -m "not benchmark"

    # Run everything
    pytest tests/unit/
"""

from __future__ import annotations

import csv
import time

from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

import pytest
import respx

from httpx import Response

from pinecone._internal.http import AsyncHTTPClient, HTTPClient, HTTPConfig
from pinecone.async_index import AsyncIndex
from pinecone.async_index.documents import AsyncDocuments
from pinecone.index import Index
from pinecone.index.documents import Documents


if TYPE_CHECKING:
    from collections.abc import Callable


pytestmark = [pytest.mark.unit, pytest.mark.benchmark]

# Test configuration
HOST = "benchmark-index.svc.pinecone.io"
API_KEY = "test-key"
BASE_URL = f"https://{HOST}"
VECTOR_DIMENSION = 768  # Realistic embedding dimension

# Benchmark configuration
WARMUP_ITERATIONS = 10
BENCHMARK_ITERATIONS = 1000

# Output directory (gitignored)
OUTPUT_DIR = Path("scratch/benchmark-results")


# ============================================================================
# Test Data Generators
# ============================================================================


def generate_documents(count: int) -> list[dict[str, Any]]:
    """Generate documents with _id, _values (768-dim), and metadata.

    Args:
        count: Number of documents to generate

    Returns:
        List of document dictionaries
    """
    return [
        {
            "_id": f"doc{i}",
            "_values": [0.1] * VECTOR_DIMENSION,
            "title": f"Document {i}",
            "category": "benchmark",
            "index": i,
        }
        for i in range(count)
    ]


def generate_vectors(count: int) -> list[tuple[str, list[float]]]:
    """Generate vector tuples (id, 768-dim values).

    Args:
        count: Number of vectors to generate

    Returns:
        List of (id, values) tuples
    """
    return [(f"v{i}", [0.1] * VECTOR_DIMENSION) for i in range(count)]


def generate_search_response(count: int) -> dict[str, Any]:
    """Generate realistic document search response.

    Args:
        count: Number of matches to include

    Returns:
        Document search response dict
    """
    return {
        "matches": [
            {
                "_id": f"doc{i}",
                "score": 0.95 - (i * 0.01),
                "title": f"Document {i}",
                "category": "benchmark",
                "index": i,
            }
            for i in range(count)
        ],
        "namespace": "test",
        "usage": {"read_units": 5},
    }


def generate_query_response(count: int) -> dict[str, Any]:
    """Generate realistic vector query response.

    Args:
        count: Number of matches to include

    Returns:
        Vector query response dict
    """
    return {
        "matches": [
            {
                "id": f"v{i}",
                "score": 0.95 - (i * 0.01),
                "values": [0.1] * VECTOR_DIMENSION,
                "metadata": {"category": "benchmark", "index": i},
            }
            for i in range(count)
        ],
        "namespace": "",
        "usage": {"readUnits": 5},
    }


# ============================================================================
# Core Benchmark Function
# ============================================================================


def benchmark_operation(
    name: str,
    operation_func: Callable[..., Any],
    warmup_iterations: int = WARMUP_ITERATIONS,
    benchmark_iterations: int = BENCHMARK_ITERATIONS,
) -> float:
    """Run operation with warmup, return average time per iteration in ms.

    Args:
        name: Operation name for display
        operation_func: Callable that performs the operation
        warmup_iterations: Number of warmup runs
        benchmark_iterations: Number of timed runs

    Returns:
        Average time per iteration in milliseconds
    """
    # Warmup phase
    for _ in range(warmup_iterations):
        _ = operation_func()

    # Benchmark phase
    start = time.perf_counter()
    for _ in range(benchmark_iterations):
        _ = operation_func()
    elapsed = time.perf_counter() - start

    return (elapsed / benchmark_iterations) * 1000  # Return ms per operation


async def benchmark_async_operation(
    name: str,
    operation_func: Callable[..., Any],
    warmup_iterations: int = WARMUP_ITERATIONS,
    benchmark_iterations: int = BENCHMARK_ITERATIONS,
) -> float:
    """Run async operation with warmup, return average time per iteration in ms.

    Args:
        name: Operation name for display
        operation_func: Async callable that performs the operation
        warmup_iterations: Number of warmup runs
        benchmark_iterations: Number of timed runs

    Returns:
        Average time per iteration in milliseconds
    """
    # Warmup phase
    for _ in range(warmup_iterations):
        _ = await operation_func()

    # Benchmark phase
    start = time.perf_counter()
    for _ in range(benchmark_iterations):
        _ = await operation_func()
    elapsed = time.perf_counter() - start

    return (elapsed / benchmark_iterations) * 1000  # Return ms per operation


# ============================================================================
# Results Storage
# ============================================================================


class BenchmarkResults:
    """Stores benchmark results for output."""

    def __init__(self):
        self.results: list[dict[str, Any]] = []

    def add(
        self,
        operation: str,
        sync_async: str,
        batch_size: int,
        avg_time_ms: float,
        iterations: int,
    ):
        """Add a benchmark result."""
        self.results.append(
            {
                "operation": operation,
                "sync_async": sync_async,
                "batch_size": batch_size,
                "avg_time_ms": avg_time_ms,
                "iterations": iterations,
            }
        )

    def print_console(self):
        """Print results to console in readable format."""
        print("\n" + "=" * 70)
        print("SDK PERFORMANCE BENCHMARKS")
        print("=" * 70)

        # Group by operation
        operations: dict[tuple[str, str], list[dict[str, Any]]] = {}
        for result in self.results:
            key = (result["operation"], result["sync_async"])
            if key not in operations:
                operations[key] = []
            operations[key].append(result)

        # Print grouped results
        for (operation, sync_async), results in sorted(operations.items()):
            print(f"\n{operation.replace('_', ' ').title()} ({sync_async.title()}):")
            for result in sorted(results, key=lambda x: x["batch_size"]):
                print(
                    f"  Batch size {result['batch_size']:>4}: "
                    f"{result['avg_time_ms']:>7.3f}ms per operation "
                    f"({result['iterations']} iterations)"
                )

        print("\n" + "=" * 70)

    def save_csv(self):
        """Save results to CSV file."""
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now(tz=timezone.utc).strftime("%Y%m%d_%H%M%S")
        filepath = OUTPUT_DIR / f"operations-benchmark-{timestamp}.csv"

        with filepath.open("w", newline="") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "operation",
                    "sync_async",
                    "batch_size",
                    "avg_time_ms",
                    "iterations",
                ],
            )
            writer.writeheader()
            writer.writerows(self.results)

        print(f"\nResults saved to: {filepath}")


# ============================================================================
# Document Operation Benchmarks
# ============================================================================


class TestDocumentOperationBenchmarks:
    """Benchmark document upsert and search operations."""

    @respx.mock
    def test_document_upsert_sync(self):
        """Benchmark sync document upsert with multiple batch sizes."""
        results = BenchmarkResults()

        # Setup mock response
        respx.post(f"{BASE_URL}/namespaces/test/documents/upsert").mock(
            side_effect=lambda request: Response(200, json={"upserted_count": len(request.content)})
        )

        # Create client and documents instance
        client = HTTPClient(api_key=API_KEY, config=HTTPConfig(http2=False))
        documents = Documents(http=client, base_url=BASE_URL)

        # Test different batch sizes
        for batch_size in [1, 10, 100]:
            test_docs = generate_documents(batch_size)

            avg_time = benchmark_operation(
                f"document_upsert_sync_{batch_size}",
                lambda docs=test_docs: documents.upsert(namespace="test", documents=docs),
            )

            results.add("document_upsert", "sync", batch_size, avg_time, BENCHMARK_ITERATIONS)

        # Close client
        client.close()

        # Output results
        results.print_console()
        results.save_csv()

    @respx.mock
    @pytest.mark.asyncio()
    async def test_document_upsert_async(self):
        """Benchmark async document upsert with multiple batch sizes."""
        results = BenchmarkResults()

        # Setup mock response
        respx.post(f"{BASE_URL}/namespaces/test/documents/upsert").mock(
            side_effect=lambda request: Response(200, json={"upserted_count": len(request.content)})
        )

        # Create client and documents instance
        client = AsyncHTTPClient(api_key=API_KEY, config=HTTPConfig(http2=False))
        documents = AsyncDocuments(http=client, base_url=BASE_URL)

        # Test different batch sizes
        for batch_size in [1, 10, 100]:
            test_docs = generate_documents(batch_size)

            avg_time = await benchmark_async_operation(
                f"document_upsert_async_{batch_size}",
                lambda docs=test_docs: documents.upsert(namespace="test", documents=docs),
            )

            results.add("document_upsert", "async", batch_size, avg_time, BENCHMARK_ITERATIONS)

        # Close client
        await client.close()

        # Output results
        results.print_console()
        results.save_csv()

    @respx.mock
    def test_document_search_sync(self):
        """Benchmark sync document search with multiple result sizes."""
        results = BenchmarkResults()

        # Create client and documents instance
        client = HTTPClient(api_key=API_KEY, config=HTTPConfig(http2=False))
        documents = Documents(http=client, base_url=BASE_URL)

        # Test different result sizes
        for result_size in [10, 100, 1000]:
            # Setup mock response with appropriate size
            respx.post(f"{BASE_URL}/namespaces/test/documents/search").mock(
                return_value=Response(200, json=generate_search_response(result_size))
            )

            score_by = [
                {"type": "dense_vector", "field": "_values", "values": [0.1] * VECTOR_DIMENSION}
            ]

            avg_time = benchmark_operation(
                f"document_search_sync_{result_size}",
                lambda k=result_size, sb=score_by: documents.search(
                    namespace="test",
                    top_k=k,
                    score_by=sb,
                    include_fields=["title", "category"],
                ),
            )

            results.add("document_search", "sync", result_size, avg_time, BENCHMARK_ITERATIONS)

        # Close client
        client.close()

        # Output results
        results.print_console()
        results.save_csv()

    @respx.mock
    @pytest.mark.asyncio()
    async def test_document_search_async(self):
        """Benchmark async document search with multiple result sizes."""
        results = BenchmarkResults()

        # Create client and documents instance
        client = AsyncHTTPClient(api_key=API_KEY, config=HTTPConfig(http2=False))
        documents = AsyncDocuments(http=client, base_url=BASE_URL)

        # Test different result sizes
        for result_size in [10, 100, 1000]:
            # Setup mock response with appropriate size
            respx.post(f"{BASE_URL}/namespaces/test/documents/search").mock(
                return_value=Response(200, json=generate_search_response(result_size))
            )

            score_by = [
                {"type": "dense_vector", "field": "_values", "values": [0.1] * VECTOR_DIMENSION}
            ]

            avg_time = await benchmark_async_operation(
                f"document_search_async_{result_size}",
                lambda k=result_size, sb=score_by: documents.search(
                    namespace="test",
                    top_k=k,
                    score_by=sb,
                    include_fields=["title", "category"],
                ),
            )

            results.add("document_search", "async", result_size, avg_time, BENCHMARK_ITERATIONS)

        # Close client
        await client.close()

        # Output results
        results.print_console()
        results.save_csv()


# ============================================================================
# Vector Operation Benchmarks
# ============================================================================


class TestVectorOperationBenchmarks:
    """Benchmark vector upsert and query operations."""

    @respx.mock
    def test_vector_upsert_sync(self):
        """Benchmark sync vector upsert with multiple batch sizes."""
        results = BenchmarkResults()

        # Create index
        index = Index(host=HOST, api_key=API_KEY)

        # Test different batch sizes
        for batch_size in [1, 10, 100, 1000]:
            # Setup mock response
            respx.post(f"{BASE_URL}/vectors/upsert").mock(
                return_value=Response(200, json={"upsertedCount": batch_size})
            )

            test_vectors = generate_vectors(batch_size)

            avg_time = benchmark_operation(
                f"vector_upsert_sync_{batch_size}",
                lambda vecs=test_vectors: index.upsert(vectors=vecs),
            )

            results.add("vector_upsert", "sync", batch_size, avg_time, BENCHMARK_ITERATIONS)

        # Close index
        index.close()

        # Output results
        results.print_console()
        results.save_csv()

    @respx.mock
    @pytest.mark.asyncio()
    async def test_vector_upsert_async(self):
        """Benchmark async vector upsert with multiple batch sizes."""
        results = BenchmarkResults()

        # Create async index
        index = AsyncIndex(host=HOST, api_key=API_KEY)

        # Test different batch sizes
        for batch_size in [1, 10, 100, 1000]:
            # Setup mock response
            respx.post(f"{BASE_URL}/vectors/upsert").mock(
                return_value=Response(200, json={"upsertedCount": batch_size})
            )

            test_vectors = generate_vectors(batch_size)

            avg_time = await benchmark_async_operation(
                f"vector_upsert_async_{batch_size}",
                lambda vecs=test_vectors: index.upsert(vectors=vecs),
            )

            results.add("vector_upsert", "async", batch_size, avg_time, BENCHMARK_ITERATIONS)

        # Close async index
        await index.close()

        # Output results
        results.print_console()
        results.save_csv()

    @respx.mock
    def test_vector_query_sync(self):
        """Benchmark sync vector query with multiple result sizes."""
        results = BenchmarkResults()

        # Create index
        index = Index(host=HOST, api_key=API_KEY)

        # Test different result sizes
        for result_size in [10, 100, 1000]:
            # Setup mock response with appropriate size
            respx.post(f"{BASE_URL}/query").mock(
                return_value=Response(200, json=generate_query_response(result_size))
            )

            query_vector = [0.1] * VECTOR_DIMENSION

            avg_time = benchmark_operation(
                f"vector_query_sync_{result_size}",
                lambda vec=query_vector, k=result_size: index.query(
                    vector=vec,
                    top_k=k,
                    include_values=True,
                    include_metadata=True,
                ),
            )

            results.add("vector_query", "sync", result_size, avg_time, BENCHMARK_ITERATIONS)

        # Close index
        index.close()

        # Output results
        results.print_console()
        results.save_csv()

    @respx.mock
    @pytest.mark.asyncio()
    async def test_vector_query_async(self):
        """Benchmark async vector query with multiple result sizes."""
        results = BenchmarkResults()

        # Create async index
        index = AsyncIndex(host=HOST, api_key=API_KEY)

        # Test different result sizes
        for result_size in [10, 100, 1000]:
            # Setup mock response with appropriate size
            respx.post(f"{BASE_URL}/query").mock(
                return_value=Response(200, json=generate_query_response(result_size))
            )

            query_vector = [0.1] * VECTOR_DIMENSION

            avg_time = await benchmark_async_operation(
                f"vector_query_async_{result_size}",
                lambda vec=query_vector, k=result_size: index.query(
                    vector=vec,
                    top_k=k,
                    include_values=True,
                    include_metadata=True,
                ),
            )

            results.add("vector_query", "async", result_size, avg_time, BENCHMARK_ITERATIONS)

        # Close async index
        await index.close()

        # Output results
        results.print_console()
        results.save_csv()
