"""Unit tests for score_by query models."""

from __future__ import annotations

import json

import pytest

from pinecone.models.documents.score_by import (
    DenseVectorQuery,
    QueryStringQuery,
    SparseValues,
    SparseVectorQuery,
    TextQuery,
)


pytestmark = pytest.mark.unit


class TestSparseValues:
    def test_to_dict(self) -> None:
        sparse = SparseValues(indices=[0, 5, 10], values=[0.5, 0.3, 0.8])
        data = sparse.to_dict()
        assert data["indices"] == [0, 5, 10]
        assert data["values"] == [0.5, 0.3, 0.8]
        assert isinstance(data, dict)

    def test_to_json(self) -> None:
        sparse = SparseValues(indices=[0, 5, 10], values=[0.5, 0.3, 0.8])
        json_str = sparse.to_json()
        assert isinstance(json_str, str)
        data = json.loads(json_str)
        assert data["indices"] == [0, 5, 10]
        assert data["values"] == [0.5, 0.3, 0.8]


class TestDenseVectorQuery:
    def test_to_dict(self) -> None:
        query = DenseVectorQuery(field="vec", values=[0.1, 0.2, 0.3])
        data = query.to_dict()
        assert data["type"] == "dense_vector"
        assert data["field"] == "vec"
        assert data["values"] == [0.1, 0.2, 0.3]
        assert isinstance(data, dict)

    def test_to_json(self) -> None:
        query = DenseVectorQuery(field="vec", values=[0.1, 0.2, 0.3])
        json_str = query.to_json()
        assert isinstance(json_str, str)
        data = json.loads(json_str)
        assert data["type"] == "dense_vector"
        assert data["field"] == "vec"


class TestSparseVectorQuery:
    def test_to_dict(self) -> None:
        sparse = SparseValues(indices=[0, 5], values=[0.5, 0.3])
        query = SparseVectorQuery(field="sparse_vec", sparse_values=sparse)
        data = query.to_dict()
        assert data["type"] == "sparse_vector"
        assert data["field"] == "sparse_vec"
        assert data["sparse_values"]["indices"] == [0, 5]
        assert isinstance(data, dict)

    def test_to_json(self) -> None:
        sparse = SparseValues(indices=[0, 5], values=[0.5, 0.3])
        query = SparseVectorQuery(field="sparse_vec", sparse_values=sparse)
        json_str = query.to_json()
        assert isinstance(json_str, str)
        data = json.loads(json_str)
        assert data["type"] == "sparse_vector"
        assert data["sparse_values"]["indices"] == [0, 5]


class TestTextQuery:
    def test_to_dict(self) -> None:
        query = TextQuery(field="text", text_query="action movie")
        data = query.to_dict()
        assert data["type"] == "text"
        assert data["field"] == "text"
        assert data["text_query"] == "action movie"
        assert isinstance(data, dict)

    def test_to_json(self) -> None:
        query = TextQuery(field="text", text_query="action movie")
        json_str = query.to_json()
        assert isinstance(json_str, str)
        data = json.loads(json_str)
        assert data["type"] == "text"
        assert data["text_query"] == "action movie"


class TestQueryStringQuery:
    def test_to_dict(self) -> None:
        query = QueryStringQuery(field="text", query="robots AND action")
        data = query.to_dict()
        assert data["type"] == "query_string"
        assert data["field"] == "text"
        assert data["query"] == "robots AND action"
        assert isinstance(data, dict)

    def test_to_json(self) -> None:
        query = QueryStringQuery(field="text", query="robots AND action")
        json_str = query.to_json()
        assert isinstance(json_str, str)
        data = json.loads(json_str)
        assert data["type"] == "query_string"
        assert data["query"] == "robots AND action"
