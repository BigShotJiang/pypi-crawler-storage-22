"""Test that search result objects have consistent display methods.

This test verifies that nested objects (Hit, Document) follow the convention
of not implementing _repr_pretty_ or _repr_html_, while parent response
objects (SearchRecordsResponse, DocumentSearchResponse) implement both.
"""

from pinecone.models.documents.search import Document, DocumentSearchResponse, Usage
from pinecone.models.records.search import Hit, SearchRecordsResponse, SearchUsage, _SearchResult


class TestSearchResultDisplayConsistency:
    """Test display method consistency for search results."""

    def test_hit_follows_convention(self):
        """Hit is a nested object and correctly has no display methods."""
        hit = Hit(id="test-id", score=0.95, fields={"title": "Test"})

        # Hit should follow conventions for nested objects
        assert not hasattr(hit, "_repr_pretty_"), "Hit should not have _repr_pretty_"
        assert not hasattr(hit, "_repr_html_"), "Hit should not have _repr_html_"

    def test_document_follows_convention(self):
        """Document correctly follows convention - no display methods."""
        doc = Document({"_id": "test-id", "score": 0.95, "title": "Test"})

        # Document correctly has neither method (follows convention)
        assert not hasattr(doc, "_repr_pretty_"), "Document correctly has no _repr_pretty_"
        assert not hasattr(doc, "_repr_html_"), "Document correctly has no _repr_html_"

    def test_search_records_response_has_both(self):
        """SearchRecordsResponse is a top-level response and should have both methods."""
        response = SearchRecordsResponse(
            result=_SearchResult(hits=[Hit(id="test", score=0.9)]),
            usage=SearchUsage(read_units=5),
        )

        # Top-level responses should have both
        assert hasattr(response, "_repr_pretty_"), "Response should have _repr_pretty_"
        assert hasattr(response, "_repr_html_"), "Response should have _repr_html_"

    def test_document_search_response_has_both(self):
        """DocumentSearchResponse is a top-level response and should have both methods."""
        response = DocumentSearchResponse(
            matches=[Document({"_id": "test", "score": 0.9})],
            namespace="test-ns",
            usage=Usage(read_units=5),
        )

        # Top-level responses should have both
        assert hasattr(response, "_repr_pretty_"), "Response should have _repr_pretty_"
        assert hasattr(response, "_repr_html_"), "Response should have _repr_html_"

    def test_hit_uses_standard_repr(self):
        """Hit should use standard __repr__ instead of display methods."""
        hit = Hit(id="test-id", score=0.95, fields={"title": "Test"})

        # Hit should have a good __repr__
        repr_str = repr(hit)
        assert "Hit(" in repr_str
        assert "test-id" in repr_str
        assert "0.95" in repr_str

        # But no special display methods for nested objects
        assert not hasattr(hit, "_repr_pretty_")
        assert not hasattr(hit, "_repr_html_")


class TestDisplayMethodConventions:
    """Test that we follow the conventions documented in docs/conventions/interactive-discovery.md."""

    def test_nested_objects_should_not_have_display_methods(self):
        """Nested objects like Hit and Document should not have _repr_pretty_ or _repr_html_."""
        # Document follows this correctly
        doc = Document({"_id": "test", "score": 0.9})
        assert not hasattr(doc, "_repr_pretty_")
        assert not hasattr(doc, "_repr_html_")

        # Hit should also follow this convention
        hit = Hit(id="test", score=0.9)
        assert not hasattr(hit, "_repr_pretty_"), "Hit should not have _repr_pretty_"
        assert not hasattr(hit, "_repr_html_"), "Hit should not have _repr_html_"

    def test_response_objects_should_have_both_display_methods(self):
        """Response objects should implement both _repr_pretty_ and _repr_html_."""
        responses = [
            SearchRecordsResponse(
                result=_SearchResult(hits=[]),
                usage=SearchUsage(read_units=5),
            ),
            DocumentSearchResponse(
                matches=[],
                namespace="test",
            ),
        ]

        for response in responses:
            assert hasattr(response, "_repr_pretty_"), (
                f"{response.__class__.__name__} should have _repr_pretty_"
            )
            assert hasattr(response, "_repr_html_"), (
                f"{response.__class__.__name__} should have _repr_html_"
            )
