"""Tests for forward compatibility with convert_with_validation.

Verifies that msgspec's default behavior (strict=True) already provides forward
compatibility by ignoring unknown fields, while maintaining strict type validation
for known fields.
"""

import pytest

from pinecone._internal.validation import convert_with_validation
from pinecone.models.indexes.schema import StringField


def test_convert_with_validation_allows_unknown_fields():
    """Verify msgspec ignores unknown fields by default (forward compatibility).

    Msgspec's default behavior (strict=True) already ignores unknown fields,
    enabling forward compatibility when the API adds new parameters before
    the SDK is updated. No strict=False needed.
    """
    # Dict with known and unknown fields
    data = {
        "type": "string",
        "filterable": True,
        "description": "Test field",
        "case_sensitive": True,  # Future/unknown field
        "experimental_option": "value",  # Another unknown field
    }

    # Should not raise ValidationError - unknown fields are ignored
    field = convert_with_validation(data, StringField, "test field")

    # Known fields should be accessible
    assert field.filterable is True
    assert field.description == "Test field"

    # Unknown fields are silently ignored by msgspec


def test_convert_with_validation_strict_type_checking():
    """Verify type validation remains strict to catch bugs.

    Unlike strict=False which would coerce "not_a_boolean" -> True,
    the default strict=True properly rejects type mismatches.
    """
    # Invalid data - wrong type for known field
    data = {
        "type": "string",
        "filterable": "not_a_boolean",  # Should be bool, not string
    }

    # Should raise ValueError due to strict type validation
    with pytest.raises(ValueError, match="Invalid test field"):
        convert_with_validation(data, StringField, "test field")


def test_schema_builder_with_future_params_validates():
    """Test that SchemaBuilder's **additional_options work with forward compatibility.

    SchemaBuilder passes unknown parameters through to the schema dict.
    When convert_with_validation processes the request, msgspec ignores
    these unknown fields by default, enabling forward compatibility.
    """
    from pinecone import SchemaBuilder
    from pinecone.models.indexes import CreateIndexRequest

    # Build schema with future API parameters via **additional_options
    schema = (
        SchemaBuilder()
        .add_string_field(
            "title",
            full_text_searchable=True,
            case_sensitive=True,  # Future parameter via **additional_options
            analyzer="custom",  # Another future parameter
        )
        .build()
    )

    # Create request dict with schema
    request_dict = {"schema": schema, "name": "test-index"}

    # Should not raise ValidationError - msgspec ignores unknown fields by default
    request = convert_with_validation(request_dict, CreateIndexRequest, "create index request")

    # Request should be created successfully
    assert request.name == "test-index"
    assert request.schema is not None
