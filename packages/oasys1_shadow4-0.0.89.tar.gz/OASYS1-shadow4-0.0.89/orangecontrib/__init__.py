# namespace declaration.
__import__("pkg_resources").declare_namespace(__name__)
#__path__ = __import__("importlib.util").find_spec(__name__).submodule_search_locations