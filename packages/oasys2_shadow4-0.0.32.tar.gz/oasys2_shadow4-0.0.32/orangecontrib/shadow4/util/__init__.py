from dabax.dabax_xraylib import DabaxXraylib
materials_library = DabaxXraylib()

# OASYS2 Shadow4 do not use Xraylib