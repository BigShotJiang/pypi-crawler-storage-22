# ObalaPalava

A Python SDK for **ObalaPalava**, a live translation system for **Pidgin → English**, developed by WAIT Technologies.

---

## Installation

Install the SDK via PyPI:

```bash
pip install obalapalava
```

---

## Usage

Basic usage example:

```python
from obalapalava import ObalaPalavaClient

# Initialize the client
client = ObalaPalavaClient()

# Translate a Pidgin sentence to English
pidgin_text = "How far boss"
english_text = client.translate(pidgin_text)

print("Pidgin:", pidgin_text)
print("English:", english_text)
```

**Expected Output:**
```
Pidgin: How far boss
English: How are you?
```

---

## Quickstart with Live Demo & Voice Feature

Try the translation live with voice support: [ObalaPalava Live Demo](https://obala-palava.vercel.app)

```python
# The same client can be used to integrate with web or TTS features
# Check the live demo link for examples and audio playback
```

---

## Features

- Translate **Ghanaian & Nigerian Pidgin** to English
- Simple Python SDK for developers
- Ready for integration in web apps, chatbots, or scripts
- Supports **voice output** via the live demo

---


---

*Developed by WAIT Technologies 🚀*

