from obalapalava import ObalaPalavaClient

client = ObalaPalavaClient()

pidgin_text = "How you dey?"
english_text = client.translate(pidgin_text)

print("Pidgin:", pidgin_text)
print("English:", english_text)
