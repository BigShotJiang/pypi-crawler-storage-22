import inspect

EMPTY = inspect._empty

__all__ = ["EMPTY"]
