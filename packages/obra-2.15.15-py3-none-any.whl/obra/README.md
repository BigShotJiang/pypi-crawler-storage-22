# Obra

AI orchestration for autonomous software development.

## Install

```bash
pipx install obra
```

## Get Started

```bash
obra briefing
```

This opens the quickstart guide with everything you need to begin.

When running `obra` from a project, the CLI prefers `--dir`, then stored session/project working_dir, then the current shell directory, and prompts only if stored and current differ.

## Plan Visibility

```bash
obra sessions plan <session_id>   # View execution plan tree
obra sync plan <session_id>       # Export session plan (YAML/JSON)
```

## License

Proprietary - All Rights Reserved. Copyright (c) 2024-2025 Unpossible Creations, Inc.
