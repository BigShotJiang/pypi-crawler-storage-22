"""Error handling and classification for autonomous runner.

This module provides exit code classification and error handling
strategies for the autonomous workplan runner.

Exit Code Categories:
    - SUCCESS (0): Story completed successfully
    - BREAKPOINT (130): Intentional halt, requires human attention
    - TRANSIENT (1, 124, 137, 143): Temporary failures, can retry
    - FATAL (2+, except transient codes): Permanent failures, skip story

Retry Strategy:
    1. Classify exit code
    2. If transient: retry N times with delay
    3. If still failing: skip story or escalate
    4. If fatal: skip immediately or escalate
    5. If breakpoint: escalate immediately
"""

import logging
import time
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class ErrorCategory(Enum):
    """Exit code categories for error classification."""
    SUCCESS = "success"
    BREAKPOINT = "breakpoint"
    TRANSIENT = "transient"
    FATAL = "fatal"


class ErrorDecision(Enum):
    """Decisions for handling errors."""
    RETRY = "retry"
    SKIP = "skip"
    ESCALATE = "escalate"


# Exit code mappings
EXIT_CODE_SUCCESS = 0
EXIT_CODE_BREAKPOINT = 130  # Ctrl+C / intentional halt
EXIT_CODE_TRANSIENT = {
    1,    # Generic error (may be transient)
    124,  # Timeout
    137,  # SIGKILL (may be resource-related)
    143,  # SIGTERM (may be recoverable)
}


def classify_exit_code(exit_code: int) -> ErrorCategory:
    """Classify an exit code into error category.

    Args:
        exit_code: Process exit code

    Returns:
        ErrorCategory indicating classification
    """
    if exit_code == EXIT_CODE_SUCCESS:
        return ErrorCategory.SUCCESS
    if exit_code == EXIT_CODE_BREAKPOINT:
        return ErrorCategory.BREAKPOINT
    if exit_code in EXIT_CODE_TRANSIENT:
        return ErrorCategory.TRANSIENT
    return ErrorCategory.FATAL


class ErrorHandler:
    """Handles error classification, retry, skip, and escalation logic."""

    def __init__(
        self,
        retry_count: int = 2,
        retry_delay_seconds: int = 30,
        escalate_on_skip: bool = True,
        error_assessor: Any | None = None
    ):
        """Initialize error handler.

        Args:
            retry_count: Number of retries for transient failures
            retry_delay_seconds: Delay between retries (seconds)
            escalate_on_skip: If True, escalate (halt) when story is skipped
            error_assessor: Optional ErrorAssessor for LLM-based assessment
        """
        self.retry_count = retry_count
        self.retry_delay_seconds = retry_delay_seconds
        self.escalate_on_skip = escalate_on_skip
        self.error_assessor = error_assessor

    def handle_error(
        self,
        story_id: str,
        exit_code: int,
        attempt: int = 1,
        story: dict[str, Any] | None = None,
        logs: str = ""
    ) -> tuple[ErrorDecision, str]:
        """Determine how to handle an error.

        Args:
            story_id: Story identifier
            exit_code: Process exit code
            attempt: Current attempt number (1-indexed)
            story: Optional story dictionary (for assessor context)
            logs: Optional execution logs (for assessor context)

        Returns:
            Tuple of (decision, reason_message)
        """
        category = classify_exit_code(exit_code)

        # Try LLM assessment for ambiguous cases if assessor is configured
        llm_decision = None
        if self.error_assessor and story:
            try:
                from obra.auto.assessor import AssessmentDecision
                llm_decision = self.error_assessor.assess_error(story, exit_code, logs, attempt)

                if llm_decision:
                    # Map AssessmentDecision to ErrorDecision
                    if llm_decision == AssessmentDecision.RETRY:
                        decision = ErrorDecision.RETRY
                    elif llm_decision == AssessmentDecision.SKIP:
                        decision = ErrorDecision.SKIP
                    elif llm_decision == AssessmentDecision.ESCALATE:
                        decision = ErrorDecision.ESCALATE
                    else:
                        decision = None

                    if decision:
                        reason = (
                            f"Story {story_id} error (exit {exit_code}). "
                            f"LLM assessment: {decision.value}"
                        )
                        logger.info(f"Using LLM assessment: {decision.value}")
                        return decision, reason
            except Exception as e:
                logger.warning(f"LLM assessment failed, falling back to deterministic: {e}")

        # Fall back to deterministic logic
        category = classify_exit_code(exit_code)

        # Success - no error handling needed
        if category == ErrorCategory.SUCCESS:
            return ErrorDecision.RETRY, "Success (no error)"

        # Breakpoint - always escalate immediately
        if category == ErrorCategory.BREAKPOINT:
            reason = (
                f"Story {story_id} halted with breakpoint (exit {exit_code}). "
                f"Requires human attention."
            )
            logger.warning(reason)
            return ErrorDecision.ESCALATE, reason

        # Transient error - retry if attempts remaining
        if category == ErrorCategory.TRANSIENT:
            if attempt <= self.retry_count:
                reason = (
                    f"Story {story_id} transient failure (exit {exit_code}). "
                    f"Retrying (attempt {attempt}/{self.retry_count})..."
                )
                logger.info(reason)
                return ErrorDecision.RETRY, reason
            # Out of retries
            if self.escalate_on_skip:
                reason = (
                    f"Story {story_id} failed after {self.retry_count} retries. "
                    f"Escalating."
                )
                logger.error(reason)
                return ErrorDecision.ESCALATE, reason
            reason = (
                f"Story {story_id} failed after {self.retry_count} retries. "
                f"Skipping."
            )
            logger.warning(reason)
            return ErrorDecision.SKIP, reason

        # Fatal error - skip or escalate immediately
        if category == ErrorCategory.FATAL:
            if self.escalate_on_skip:
                reason = (
                    f"Story {story_id} fatal error (exit {exit_code}). "
                    f"Escalating."
                )
                logger.error(reason)
                return ErrorDecision.ESCALATE, reason
            reason = (
                f"Story {story_id} fatal error (exit {exit_code}). "
                f"Skipping."
            )
            logger.warning(reason)
            return ErrorDecision.SKIP, reason

        # Fallback (should not reach here)
        reason = f"Story {story_id} unknown error (exit {exit_code}). Escalating."
        logger.error(reason)
        return ErrorDecision.ESCALATE, reason

    def wait_before_retry(self) -> None:
        """Wait before retrying (with logging)."""
        logger.info(f"Waiting {self.retry_delay_seconds} seconds before retry...")
        time.sleep(self.retry_delay_seconds)
