"""Core autonomous runner loop.

This module implements the main orchestration loop for autonomous
workplan execution. It reads the machine plan, executes stories
sequentially, and updates status.

Usage:
    runner = AutoRunner(plan_path="AUTO-RUN-001_MACHINE_PLAN.json")
    runner.run(max_stories=None, dry_run=False)

Architecture:
    - Story-level automation (not task-level)
    - Each story = separate `obra run` subprocess
    - Deterministic core loop (no LLM required for happy path)
"""

import logging
import subprocess
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from obra.auto.error_handler import ErrorDecision, ErrorHandler
from obra.auto.plan_reader import PlanReader
from obra.constants import AUTO_STORY_TIMEOUT_S
from obra.execution.delivered_summary import build_delivered_summary, format_summary_json
from obra.execution.intent_gap_check import IntentGapResult, run_intent_gap_check
from obra.execution.skip_classifier import classify_skip_reason
from obra.execution.skip_record import create_skip_record, SkipSource
from obra.intent.storage import IntentStorage
from obra.intent.templates import render_intent_template
from obra.utils.file_tracker import FileSnapshot, FileStateTracker
from obra.config import load_config

# Set up logger
logger = logging.getLogger(__name__)


class StoryExecutionOutcome:
    """Execution outcome for a single story."""

    def __init__(self, story_id: str, status: str, exit_code: int) -> None:
        self.story_id = story_id
        self.status = status
        self.exit_code = exit_code


def setup_progress_logging(log_file: str = "obra-auto.log") -> None:
    """Configure progress logging to file.

    Args:
        log_file: Path to log file (default: obra-auto.log)
    """
    # Only add handler if not already present (avoid duplicates)
    if not logger.handlers:
        # Create file handler
        handler = logging.FileHandler(log_file, mode="a")
        handler.setLevel(logging.INFO)

        # Create formatter
        formatter = logging.Formatter(
            "%(asctime)s - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        handler.setFormatter(formatter)

        # Add handler to logger
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)


class AutoRunner:
    """Main orchestration loop for autonomous workplan execution."""

    def __init__(
        self,
        plan_path: str,
        log_file: str = "obra-auto.log",
        retry_count: int = 2,
        retry_delay_seconds: int = 30,
        escalate_on_skip: bool = True,
        error_assessor: Any | None = None,
        parallel_enabled: bool = False,
        parallel_max_workers: int = 4,
    ):
        """Initialize the auto runner.

        Args:
            plan_path: Path to MACHINE_PLAN.json file
            log_file: Path to progress log file
            retry_count: Number of retries for transient failures
            retry_delay_seconds: Delay between retries (seconds)
            escalate_on_skip: If True, escalate (halt) when story is skipped
            error_assessor: Optional ErrorAssessor for LLM-based error assessment
            parallel_enabled: Enable parallel execution for stories with parallel_group
            parallel_max_workers: Maximum concurrent workers for parallel execution
        """
        self.plan_path = plan_path
        self.plan_reader = PlanReader(plan_path)
        self.error_handler = ErrorHandler(
            retry_count=retry_count,
            retry_delay_seconds=retry_delay_seconds,
            escalate_on_skip=escalate_on_skip,
            error_assessor=error_assessor
        )
        self._file_tracker = FileStateTracker(Path.cwd())
        self._story_snapshots: dict[str, FileSnapshot] = {}
        self._intent_markdown: str | None = None
        self._intent_objective: str | None = None
        self._parallel_enabled = parallel_enabled
        self._parallel_max_workers = max(1, int(parallel_max_workers))
        self._plan_lock = threading.Lock()

        # Set up progress logging
        setup_progress_logging(log_file)
        logger.info(f"=== Auto-runner initialized: {plan_path} ===")

    def run(self, max_stories: int | None = None, dry_run: bool = False) -> int:
        """Execute the workplan.

        Args:
            max_stories: Maximum number of stories to execute (None = all)
            dry_run: If True, show execution plan without running

        Returns:
            Exit code (0 = success, non-zero = error)
        """
        # Load the plan
        self.plan_reader.load()
        assert self.plan_reader.plan_data is not None  # load() guarantees this
        work_id = self.plan_reader.plan_data.get("work_id", "UNKNOWN")

        logger.info(f"Starting execution for work_id: {work_id}")
        if dry_run:
            logger.info("DRY-RUN mode enabled")
        if max_stories:
            logger.info(f"Max stories limit: {max_stories}")

        stories_executed = 0

        try:
            if self._parallel_enabled:
                result = self._run_parallel_loop(max_stories, dry_run, stories_executed)
            else:
                result = self._run_loop(max_stories, dry_run, stories_executed)
            logger.info(
                f"Execution completed. Stories executed: {stories_executed}. "
                f"Exit code: {result}"
            )
            return result
        except KeyboardInterrupt:
            print("\n⚠ Ctrl+C received. Completing current story and exiting gracefully...")
            logger.warning(f"Execution interrupted by user. Stories executed: {stories_executed}")
            # Save plan state
            self.plan_reader.save()
            print("✓ Plan state saved. Exiting.")
            logger.info("Plan state saved. Exiting gracefully.")
            return 0

    def _run_loop(self, max_stories: int | None, dry_run: bool, stories_executed: int) -> int:
        """Internal loop for executing stories.

        Args:
            max_stories: Maximum number of stories to execute
            dry_run: If True, show execution plan without running
            stories_executed: Counter for executed stories

        Returns:
            Exit code (0 = success, non-zero = error)
        """
        while True:
            # Check max_stories limit
            if max_stories is not None and stories_executed >= max_stories:
                print(f"Reached max_stories limit ({max_stories}), stopping.")
                break

            # Get next pending story
            story = self.plan_reader.get_next_pending_story()
            if story is None:
                print("No more pending stories. Workplan complete.")
                break

            story_id = story["id"]
            story_title = story["title"]

            if dry_run:
                print(f"[DRY-RUN] Would execute: {story_id} - {story_title}")
                logger.info(f"[DRY-RUN] Would execute: {story_id} - {story_title}")
                stories_executed += 1
                # Mark as completed in memory (but don't save) to move to next story
                self.plan_reader.update_story_status(story_id, "completed")
                continue

            # Execute story with retry logic
            outcome = self._execute_story_with_retries(story)
            if outcome.status == "escalated":
                return outcome.exit_code if outcome.exit_code else 1
            stories_executed += 1

        return 0

    def _run_parallel_loop(
        self,
        max_stories: int | None,
        dry_run: bool,
        stories_executed: int,
    ) -> int:
        """Execute stories using parallel groups."""
        while True:
            if max_stories is not None and stories_executed >= max_stories:
                print(f"Reached max_stories limit ({max_stories}), stopping.")
                break

            pending_stories = self._get_pending_stories()
            if not pending_stories:
                print("No more pending stories. Workplan complete.")
                break

            remaining = None
            if max_stories is not None:
                remaining = max_stories - stories_executed
                if remaining <= 0:
                    break
                pending_stories = pending_stories[:remaining]

            groups = self._build_parallel_groups(pending_stories)
            for group_index, group in enumerate(groups, start=1):
                if max_stories is not None and stories_executed >= max_stories:
                    break
                group_id, stories = group
                if not stories:
                    continue
                if max_stories is not None:
                    remaining = max_stories - stories_executed
                    if remaining <= 0:
                        break
                    stories = stories[:remaining]

                if dry_run:
                    for story in stories:
                        story_id = story.get("id", "unknown")
                        story_title = story.get("title", "")
                        print(f"[DRY-RUN] Would execute: {story_id} - {story_title}")
                        logger.info(f"[DRY-RUN] Would execute: {story_id} - {story_title}")
                        self.plan_reader.update_story_status(story_id, "completed")
                        stories_executed += 1
                    continue

                group_label = str(group_id) if group_id is not None else f"seq-{group_index}"
                story_ids = [story.get("id", "unknown") for story in stories]
                logger.info(
                    "Parallel group %s start: %s (workers=%d)",
                    group_label,
                    ", ".join(story_ids),
                    self._parallel_max_workers,
                )

                outcomes = self._execute_story_group(stories)
                logger.info(
                    "Parallel group %s end: %s",
                    group_label,
                    ", ".join(story_ids),
                )

                for outcome in outcomes:
                    stories_executed += 1
                    if outcome.status == "escalated":
                        return outcome.exit_code if outcome.exit_code else 1

        return 0

    def _execute_story_group(self, stories: list[dict[str, Any]]) -> list[StoryExecutionOutcome]:
        """Execute a group of stories in parallel."""
        outcomes: list[StoryExecutionOutcome] = []
        with ThreadPoolExecutor(max_workers=self._parallel_max_workers) as executor:
            futures = {
                executor.submit(self._execute_story_with_retries, story): story for story in stories
            }
            halted = False
            for future in as_completed(futures):
                outcome = future.result()
                outcomes.append(outcome)
                if outcome.status == "escalated":
                    halted = True
                    for pending in futures:
                        if not pending.done():
                            pending.cancel()
                    break

            if halted:
                for future in futures:
                    if future.cancelled() or future.done():
                        continue
                    try:
                        outcomes.append(future.result())
                    except Exception as exc:
                        story = futures[future]
                        story_id = story.get("id", "unknown")
                        logger.error("Parallel story execution failed for %s: %s", story_id, exc)
                        outcomes.append(StoryExecutionOutcome(story_id, "escalated", 1))

        return outcomes

    def _execute_story_with_retries(self, story: dict[str, Any]) -> StoryExecutionOutcome:
        """Execute a story with retry handling."""
        story_id = story["id"]
        story_title = story.get("title", story_id)

        print(f"Executing story {story_id}: {story_title}")
        logger.info("Starting story %s: %s", story_id, story_title)

        with self._plan_lock:
            self.plan_reader.update_story_status(story_id, "in_progress")
            self.plan_reader.save()
        self._capture_story_snapshot(story_id)

        attempt = 1
        max_attempts = self.error_handler.retry_count + 1
        exit_code = None

        while attempt <= max_attempts:
            exit_code = self._execute_story(story)
            if exit_code == 0:
                with self._plan_lock:
                    self.plan_reader.update_story_status(story_id, "completed")
                    self._run_story_gap_check(story)
                    self.plan_reader.save()
                print(f"✓ Story {story_id} completed successfully.")
                assert self.plan_reader.plan_data is not None
                work_id = self.plan_reader.plan_data.get("work_id", "UNKNOWN")
                print(
                    f"  Tip: Use 'obra auto --plan {work_id}' for "
                    "hands-off execution of remaining stories"
                )
                logger.info("Story %s completed successfully", story_id)
                self._run_epic_gap_check_if_complete(story_id)
                return StoryExecutionOutcome(story_id, "completed", 0)

            decision, reason = self.error_handler.handle_error(
                story_id=story_id,
                exit_code=exit_code,
                attempt=attempt,
                story=story,
                logs="",
            )

            if decision == ErrorDecision.RETRY:
                if attempt < max_attempts:
                    print(f"⚠ {reason}")
                    self.error_handler.wait_before_retry()
                    attempt += 1
                    continue
                print(f"✗ Story {story_id} failed after {attempt} attempts")
                break

            if decision == ErrorDecision.SKIP:
                if self._is_skip_tracking_enabled():
                    reason, _tier = classify_skip_reason(exit_code=exit_code, logs="")
                    assessment_context: dict[str, Any] | None = None
                    if self.error_handler.error_assessor:
                        assessor = self.error_handler.error_assessor
                        if getattr(assessor, "last_decision", None) is not None:
                            assessment_context = {
                                "assessment_decision": getattr(assessor, "last_decision").value,
                                "assessment_response": getattr(assessor, "last_response", ""),
                            }
                    create_skip_record(
                        session_id="",
                        task_id=story_id,
                        source=SkipSource.AUTO_RUNNER,
                        reason=reason,
                        description=f"Story {story_id} skipped after {attempt} attempts: {reason}",
                        error_logs="",
                        source_context={
                            "exit_code": exit_code,
                            "attempt": attempt,
                            "work_id": self.plan_reader.plan_data.get("work_id", ""),
                            "assessment": assessment_context or {},
                        },
                    )
                    logger.info("Run 'obra skips list' to review skipped items")
                with self._plan_lock:
                    self.plan_reader.update_story_status(story_id, "skipped")
                    self.plan_reader.save()
                print(f"⊘ {reason}")
                print(f"  Story {story_id} marked as skipped. Continuing to next story.")
                logger.warning("Story %s skipped after failure", story_id)
                return StoryExecutionOutcome(story_id, "skipped", exit_code or 1)

            if decision == ErrorDecision.ESCALATE:
                print(f"✗ {reason}")
                print("  Halting execution. Manual intervention required.")
                assert self.plan_reader.plan_data is not None
                work_id = self.plan_reader.plan_data.get("work_id", "UNKNOWN")
                print(
                    f"  Tip: After fixing the issue, use 'obra auto --plan {work_id}' "
                    "to resume execution"
                )
                logger.error("Execution halted at story %s", story_id)
                return StoryExecutionOutcome(story_id, "escalated", exit_code or 1)

            print(f"✗ Unknown error decision: {decision}")
            return StoryExecutionOutcome(story_id, "escalated", 1)

        return StoryExecutionOutcome(story_id, "escalated", exit_code or 1)

    def _get_pending_stories(self) -> list[dict[str, Any]]:
        """Return pending or in_progress stories in plan order."""
        assert self.plan_reader.plan_data is not None
        stories = self.plan_reader.get_stories()
        return [
            story
            for story in stories
            if story.get("status") in ["pending", "in_progress"]
        ]

    def _is_skip_tracking_enabled(self) -> bool:
        config = load_config()
        skip_config = config.get("orchestration", {}).get("skip_tracking", {})
        return bool(skip_config.get("enabled", True)) and bool(
            skip_config.get("sources", {}).get("auto_runner", True)
        )

    def _build_parallel_groups(
        self, stories: list[dict[str, Any]]
    ) -> list[tuple[int | None, list[dict[str, Any]]]]:
        """Group stories by parallel_group with deterministic ordering."""
        grouped: dict[int, list[dict[str, Any]]] = {}
        sequential_groups: list[list[dict[str, Any]]] = []

        for story in stories:
            group_id = self._normalize_parallel_group(story.get("parallel_group"))
            if group_id is None:
                sequential_groups.append([story])
            else:
                grouped.setdefault(group_id, []).append(story)

        ordered_groups: list[tuple[int | None, list[dict[str, Any]]]] = []
        for group_id in sorted(grouped.keys()):
            ordered_groups.append((group_id, grouped[group_id]))
        for seq_group in sequential_groups:
            ordered_groups.append((None, seq_group))

        return ordered_groups

    @staticmethod
    def _normalize_parallel_group(value: Any) -> int | None:
        """Normalize parallel_group to an int when possible."""
        if value is None:
            return None
        if isinstance(value, bool):
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    def _execute_story(self, story: dict) -> int:
        """Execute a single story by spawning an obra run subprocess.

        Args:
            story: Story dictionary from machine plan

        Returns:
            Exit code (0 = success, non-zero = error)
        """
        story_id = story["id"]
        assert self.plan_reader.plan_data is not None
        work_id = self.plan_reader.plan_data.get("work_id", "UNKNOWN")

        # Build command to execute story
        # Pattern: obra run "Read and continue
        #   .obra/prompts/_active/{WORK_ID}_{SLUG}/PLAN.md"
        # For now, we'll use a simpler command that can be tested
        # This will be enhanced in later stories to use actual execution prompts

        # Generate slug from story title (lowercase, replace spaces with underscores)
        story_title = story.get("title", story_id)
        slug = story_title.lower().replace(" ", "_").replace("-", "_")

        # Build prompt path
        prompt_path = Path.cwd() / ".obra" / "prompts" / "_active" / f"{work_id}_{slug}" / "PLAN.md"

        # Check if execution prompt exists
        if prompt_path.exists():
            # Use execution prompt if available
            command = [
                "obra",
                "run",
                f"Read and continue {prompt_path}",
            ]
        else:
            # Fallback: simulate execution for testing (no actual subprocess)
            # This allows tests to pass without requiring full obra run setup
            print(f"  [Simulated] No execution prompt found at {prompt_path}")
            print(f"  [Simulated] Story {story_id} would execute via: obra run")
            return 0

        try:
            # Spawn subprocess and wait for completion
            print(f"  Spawning: {' '.join(command)}")

            # Build monitoring context for long-running subprocess
            monitoring_context = {
                "operation": "story_execution",
                "story_id": story_id,
                "work_id": work_id,
                "command": " ".join(command),
            }

            _ = monitoring_context  # Context defined but monitoring handled by child process
            # MONITORING EXEMPTION: Delegated to nested obra run subprocess (which has its own monitoring)
            result = subprocess.run(
                command,
                capture_output=False,  # Let output stream to console
                text=True,
                timeout=AUTO_STORY_TIMEOUT_S,  # 1 hour timeout per story
                check=False,  # Don't raise exception on non-zero exit codes
            )
            return result.returncode

        except subprocess.TimeoutExpired:
            print(f"  Story {story_id} timed out after 1 hour")
            return 124  # Standard timeout exit code
        except subprocess.CalledProcessError as e:
            print(f"  Story {story_id} failed: {e}")
            return e.returncode
        except KeyboardInterrupt:
            print(f"\n  Story {story_id} interrupted by user")
            raise  # Re-raise to parent run() method which handles graceful shutdown
        except Exception as e:
            print(f"  Story {story_id} execution error: {e}")
            return 1

    def _capture_story_snapshot(self, story_id: str) -> None:
        """Capture file snapshot before executing a story."""
        self._story_snapshots[story_id] = self._file_tracker.snapshot()

    def _get_intent_markdown(self) -> tuple[str | None, str | None]:
        """Load active intent markdown and objective."""
        if self._intent_markdown is not None:
            return self._intent_markdown, self._intent_objective

        try:
            storage = IntentStorage()
            project_id = storage.get_project_id(Path.cwd())
            intent = storage.load_active(project_id)
            if not intent:
                return None, None
            self._intent_markdown = render_intent_template(intent)
            self._intent_objective = intent.problem_statement or intent.raw_objective
            return self._intent_markdown, self._intent_objective
        except Exception as exc:
            logger.warning("Failed to load active intent: %s", exc)
            return None, None

    def _build_story_summary(self, story_id: str) -> dict[str, Any] | None:
        """Build a delivered work summary for a story."""
        before = self._story_snapshots.get(story_id)
        if before is None:
            return None
        changes = self._file_tracker.diff(before)
        changed_files = changes.added + changes.modified + changes.deleted
        diffstat = {
            "added": len(changes.added),
            "modified": len(changes.modified),
            "deleted": len(changes.deleted),
            "total": changes.total_changed,
        }
        docs_updated = [path for path in changed_files if path.startswith("docs/")]
        changelog_updated = "CHANGELOG.md" in changed_files
        summary = build_delivered_summary(
            changed_files=changed_files,
            diffstat=diffstat,
            tests_run=[],
            docs_updated=docs_updated,
            changelog_updated=changelog_updated,
        )
        return summary

    def _run_story_gap_check(self, story: dict[str, Any]) -> None:
        """Run story-level intent gap check after completion."""
        intent_markdown, objective = self._get_intent_markdown()
        if not intent_markdown:
            return
        summary = self._build_story_summary(story["id"])
        if summary is None:
            return
        self.plan_reader.attach_story_summary(story["id"], summary)
        delivered_summary_json = format_summary_json(summary)
        work_id = None
        if self.plan_reader.plan_data:
            work_id = self.plan_reader.plan_data.get("work_id")
        result = run_intent_gap_check(
            working_dir=Path.cwd(),
            scope_type="story",
            scope_id=story.get("id", ""),
            scope_title=story.get("title", ""),
            objective=objective or "Objective unavailable",
            intent_markdown=intent_markdown,
            delivered_summary_json=delivered_summary_json,
            llm_config={},
            plan_id=work_id,
        )
        if result is None:
            return
        if self.plan_reader.plan_data is not None:
            if "gap_reports" not in self.plan_reader.plan_data:
                self.plan_reader.plan_data["gap_reports"] = []
            self.plan_reader.plan_data["gap_reports"].append(
                _serialize_gap_result(result, scope_type="story", scope_id=story.get("id", ""))
            )
        logger.info(
            "Intent gap check story complete: %s (%s)",
            story.get("id"),
            result.coverage_status,
        )

    def _run_epic_gap_check_if_complete(self, story_id: str) -> None:
        """Run epic-level gap check when epic is complete."""
        epic = self.plan_reader.get_epic_for_story(story_id)
        if not epic:
            return
        epic_id = epic.get("id", "")
        if not epic_id or not self.plan_reader.is_epic_completed(epic_id):
            return

        intent_markdown, objective = self._get_intent_markdown()
        if not intent_markdown:
            return

        summary = _aggregate_epic_summary(epic)
        delivered_summary_json = format_summary_json(summary)
        work_id = None
        if self.plan_reader.plan_data:
            work_id = self.plan_reader.plan_data.get("work_id")
        result = run_intent_gap_check(
            working_dir=Path.cwd(),
            scope_type="epic",
            scope_id=epic_id,
            scope_title=epic.get("title", ""),
            objective=objective or "Objective unavailable",
            intent_markdown=intent_markdown,
            delivered_summary_json=delivered_summary_json,
            llm_config={},
            plan_id=work_id,
        )
        if result is None:
            return

        appended = self._append_followup_stories(epic_id, result)
        if appended:
            self.plan_reader.save()

        if self.plan_reader.plan_data is not None:
            if "gap_reports" not in self.plan_reader.plan_data:
                self.plan_reader.plan_data["gap_reports"] = []
            self.plan_reader.plan_data["gap_reports"].append(
                _serialize_gap_result(result, scope_type="epic", scope_id=epic_id)
            )
        logger.info(
            "Intent gap check epic complete: %s (%s)",
            epic_id,
            result.coverage_status,
        )

    def _append_followup_stories(self, epic_id: str, result: IntentGapResult) -> int:
        """Append follow-up stories based on gap check output."""
        followups = result.followup_stories
        if not followups:
            return 0

        config = {}
        try:
            from obra.config.loaders import load_layered_config

            config, _, _ = load_layered_config(include_defaults=True)
        except Exception as exc:
            logger.warning("Failed to load intent gap config: %s", exc)

        gap_cfg = config.get("planning", {}).get("intent_gap_check", {}) if config else {}
        auto_append = gap_cfg.get("auto_append", True)
        max_new = int(gap_cfg.get("max_new_stories", len(followups) or 0))

        if not auto_append:
            return 0

        appended = 0
        for followup in followups[:max_new]:
            story_id = _next_story_id(self.plan_reader)
            title = str(followup.get("title") or "Follow-up gap coverage")
            description = str(followup.get("description") or title)
            acceptance = followup.get("acceptance_criteria") or []
            if not isinstance(acceptance, list):
                acceptance = [str(acceptance)]
            task = {
                "id": f"{story_id}.T1",
                "desc": description,
                "status": "pending",
                "verify": "Acceptance criteria: " + "; ".join(str(item) for item in acceptance),
                "depends_on": [],
            }
            story = {
                "id": story_id,
                "title": title,
                "status": "pending",
                "acceptance_criteria": acceptance,
                "tasks": [task],
                "depends_on": [epic_id],
            }
            self.plan_reader.add_story_to_epic(epic_id, story)
            appended += 1
        return appended


def _serialize_gap_result(result: IntentGapResult, *, scope_type: str, scope_id: str) -> dict[str, Any]:
    return {
        "scope_type": scope_type,
        "scope_id": scope_id,
        "coverage_status": result.coverage_status,
        "missing_requirements": result.missing_requirements,
        "scope_creep": result.scope_creep,
        "followup_stories": result.followup_stories,
        "notes": result.notes,
        "duration_s": result.duration_s,
    }


def _aggregate_epic_summary(epic: dict[str, Any]) -> dict[str, Any]:
    changed_files: list[str] = []
    docs_updated: list[str] = []
    diffstat = {"added": 0, "modified": 0, "deleted": 0, "total": 0}
    changelog_updated = False

    for story in epic.get("stories", []):
        summary = story.get("delivery_summary")
        if not isinstance(summary, dict):
            continue
        files = summary.get("changed_files", [])
        if isinstance(files, list):
            changed_files.extend([str(path) for path in files])
        diff = summary.get("diffstat", {})
        if isinstance(diff, dict):
            diffstat["added"] += int(diff.get("added", 0))
            diffstat["modified"] += int(diff.get("modified", 0))
            diffstat["deleted"] += int(diff.get("deleted", 0))
            diffstat["total"] += int(diff.get("total", 0))
        docs = summary.get("docs_updated", [])
        if isinstance(docs, list):
            docs_updated.extend([str(path) for path in docs])
        if summary.get("changelog_updated"):
            changelog_updated = True

    return build_delivered_summary(
        changed_files=sorted(set(changed_files)),
        diffstat=diffstat,
        tests_run=[],
        docs_updated=sorted(set(docs_updated)),
        changelog_updated=changelog_updated,
    )


def _next_story_id(plan_reader: PlanReader) -> str:
    max_id = 0
    if plan_reader.plan_data is None:
        return "S1"
    stories = plan_reader.plan_data.get("epics", [])
    for epic in stories:
        for story in epic.get("stories", []):
            story_id = str(story.get("id", ""))
            if story_id.startswith("S") and story_id[1:].isdigit():
                max_id = max(max_id, int(story_id[1:]))
    return f"S{max_id + 1}"
