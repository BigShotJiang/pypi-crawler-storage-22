"""File filtering for business domain.

These constants define which files to include/exclude during document analysis
for business workflow automation.

Related:
    - obra/domains/interface.py (FileFilterConfig)
"""

# Business documents to include
BUSINESS_DOCUMENT_EXTENSIONS: frozenset[str] = frozenset({
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".csv", ".json", ".xml", ".yaml", ".yml",
    ".txt", ".md", ".rtf",
})

# Files to exclude
EXCLUDED_FILES: frozenset[str] = frozenset({
    ".DS_Store",
    "Thumbs.db",
    "desktop.ini",
    "package-lock.json",
    "pnpm-lock.yaml",
    "yarn.lock",
    "go.sum",
    "Cargo.lock",
    "Gemfile.lock",
    "composer.lock",
})

EXCLUDED_PATTERNS: list[str] = [
    "**/~$*",  # Office temp files
    "**/*.tmp",
    "**/*.bak",
]

# Binary files (different from software - fewer code artifacts)
BINARY_EXTENSIONS: frozenset[str] = frozenset({
    ".exe", ".dll", ".so",
    ".zip", ".tar", ".gz", ".rar",
    ".png", ".jpg", ".jpeg", ".gif", ".bmp",
    ".mp3", ".mp4", ".wav", ".avi",
    ".db", ".sqlite",
})

IGNORE_DIRS: frozenset[str] = frozenset({
    ".git",
    ".obra",
    ".idea",
    ".vscode",
    "node_modules",
    "__pycache__",
    ".cache",
    ".venv",
    "venv",
    "dist",
    "build",
    "target",
    "vendor",
    ".gradle",
    ".cargo",
    "Archive",
    "Old",
})

IGNORE_DIR_SUFFIXES: tuple[str, ...] = (
    "_backup",
    "_old",
)
