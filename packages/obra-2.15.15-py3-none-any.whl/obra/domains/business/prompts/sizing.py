"""Sizing guidance prompt text for business domain."""

from __future__ import annotations

__all__ = ["SIZING_GUIDANCE"]

SIZING_GUIDANCE = """
## Business Workflow Sizing Guidance

**Good items:**
- ONE primary action per item (validate, transform, review, approve)
- Clear input and output documents/data
- Defined acceptance criteria
- Target: 1-3 documents processed, clear deliverable

**Avoid:**
- Multiple approval levels in one item (split by approver)
- Undefined data sources
- Vague criteria ("looks good", "seems complete")
"""
