"""Decomposition patterns for software development domain.

These patterns define how to break down complex software development
objectives into manageable subtasks.

Related:
    - obra/hybrid/derivation/decomposition_generator.py (original source)
    - obra/domains/interface.py (DomainModule protocol)
"""

from dataclasses import dataclass


@dataclass
class DecompositionPattern:
    """Pattern for decomposing objectives into subtasks."""

    name: str
    keywords: list[str]
    suggested_phases: list[str]
    typical_subtask_count: int


DECOMPOSITION_PATTERNS: list[DecompositionPattern] = [
    DecompositionPattern(
        name="feature_implementation",
        keywords=["implement", "create", "build", "add feature", "develop"],
        suggested_phases=["design", "implement core", "add tests", "integrate"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="refactoring",
        keywords=["refactor", "restructure", "reorganize", "improve", "clean"],
        suggested_phases=["analyze current", "design new structure", "migrate incrementally", "validate"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="database",
        keywords=["database", "schema", "migration", "query", "model"],
        suggested_phases=["design schema", "create migrations", "implement models", "optimize queries"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="integration",
        keywords=["integrate", "connect", "api", "external", "third-party"],
        suggested_phases=["design interface", "implement adapter", "add error handling", "test integration"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="security",
        keywords=["security", "auth", "permission", "encrypt", "protect"],
        suggested_phases=["design security model", "implement authentication", "implement authorization", "security audit"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="distributed",
        keywords=["distributed", "microservice", "scale", "cluster", "replicate"],
        suggested_phases=["design architecture", "implement boundaries", "add communication", "deploy and test"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="migration",
        keywords=["migrate", "upgrade", "convert", "port", "transfer"],
        suggested_phases=["assess scope", "create migration plan", "execute migration", "validate results"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="testing",
        keywords=["test", "coverage", "spec", "verify", "validate"],
        suggested_phases=["identify test cases", "write unit tests", "write integration tests", "verify coverage"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="documentation",
        keywords=["document", "docs", "readme", "guide", "tutorial"],
        suggested_phases=["outline structure", "write content", "add examples", "review and polish"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="performance",
        keywords=["optimize", "performance", "speed", "cache", "efficient"],
        suggested_phases=["profile bottlenecks", "design optimizations", "implement changes", "benchmark results"],
        typical_subtask_count=4,
    ),
]
