"""Transient error classification and task outcome tracking for retry logic.

This module provides error classification to distinguish between:
- Transient errors: Temporary failures that may succeed on retry (rate limits, timeouts, network issues)
- Non-transient errors: Permanent failures that should fail fast (validation, auth, not found)

It also provides TaskOutcome enum for standardized execution result reporting.

Metrics:
    - obra_decomposition_triggers_total: Counter of auto-decomposition trigger events
      Labels: trigger_type (failure/budget), task_id

Usage:
    from obra.execution.errors import TransientError, NonTransientError, is_transient
    from obra.execution.errors import TaskOutcome, TaskResult

    # Raise specific error types
    raise TransientError("Rate limit exceeded", retry_after=60)
    raise NonTransientError("Invalid input: missing required field")

    # Classify arbitrary exceptions
    if is_transient(some_exception):
        # Retry with backoff
    else:
        # Fail fast

    # Report task outcomes
    result = TaskResult(
        outcome=TaskOutcome.SUCCESS,
        outcome_message="Task completed successfully"
    )

Related:
    - obra/execution/retry.py (retry metrics)
    - obra/execution/derivation_metrics.py (derivation metrics)
    - obra/review/metrics.py (quality gate metrics)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

# Metric names following Prometheus naming convention
METRIC_DECOMPOSITION_TRIGGERS = "obra_decomposition_triggers_total"
METRIC_ERRORS_CLASSIFIED = "obra_errors_classified_total"

# Global metrics storage for error classification
_error_classification_metrics: list[dict[str, Any]] = []


def emit_error_classification_metric(
    classification: str,
    error_type: str,
    log_event: Any | None = None,
    trace_id: str | None = None,
) -> dict[str, Any]:
    """Emit an error classification counter metric.

    Args:
        classification: "transient" or "non_transient"
        error_type: Name of the exception type
        log_event: Optional event logger callback
        trace_id: Optional trace ID for correlation

    Returns:
        The emitted metric dict
    """
    metric = {
        "metric_name": METRIC_ERRORS_CLASSIFIED,
        "value": 1,
        "labels": {
            "classification": classification,
            "error_type": error_type,
        },
        "timestamp": datetime.now(UTC).isoformat(),
        "metadata": {},
    }

    _error_classification_metrics.append(metric)

    if log_event:
        try:
            log_event(
                "error_classification_metric",
                session_id=None,
                trace_id=trace_id,
                **metric,
            )
        except Exception as e:
            logger.debug("Failed to log error classification metric: %s", e)

    logger.debug(
        "Emitted error classification metric: classification=%s, error_type=%s",
        classification,
        error_type,
    )

    return metric


def get_error_classification_metrics_summary() -> dict[str, Any]:
    """Get summary of error classification metrics.

    Returns:
        Summary dict with totals by classification and error type.
    """
    if not _error_classification_metrics:
        return {"total": 0, "transient": 0, "non_transient": 0, "by_error_type": {}}

    transient_count = sum(
        1 for m in _error_classification_metrics
        if m.get("labels", {}).get("classification") == "transient"
    )
    non_transient_count = len(_error_classification_metrics) - transient_count

    by_error_type: dict[str, int] = {}
    for m in _error_classification_metrics:
        error_type = m.get("labels", {}).get("error_type", "unknown")
        by_error_type[error_type] = by_error_type.get(error_type, 0) + 1

    return {
        "total": len(_error_classification_metrics),
        "transient": transient_count,
        "non_transient": non_transient_count,
        "by_error_type": by_error_type,
    }


@dataclass
class DecompositionTriggerMetric:
    """Structured metric event for auto-decomposition trigger.

    Attributes:
        metric_name: Name of the metric (obra_decomposition_triggers_total)
        value: Metric value (1 for counter increment)
        labels: Metric labels (trigger_type, task_id)
        timestamp: ISO-8601 timestamp when metric was recorded
        metadata: Additional context (threshold, consumption_ratio, etc.)
    """

    metric_name: str
    value: float
    labels: dict[str, str]
    timestamp: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Initialize timestamp if not provided."""
        if self.timestamp is None:
            self.timestamp = datetime.now(UTC).isoformat()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for event logging."""
        return {
            "metric_name": self.metric_name,
            "value": self.value,
            "labels": self.labels,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }


class DecompositionMetricsCollector:
    """Collects and aggregates decomposition trigger metrics.

    Thread-safety:
        This class is NOT thread-safe. Use external synchronization if
        accessing from multiple threads.

    Usage:
        from obra.execution.errors import get_decomposition_metrics_collector

        collector = get_decomposition_metrics_collector()

        # Record a failure-triggered decomposition
        collector.record_trigger(
            trigger_type="failure",
            task_id="S1.T1",
            threshold=3,
            current_value=3,
        )

        # Get summary
        summary = collector.get_summary()
    """

    def __init__(self) -> None:
        """Initialize the metrics collector."""
        self._failure_triggers: int = 0
        self._budget_triggers: int = 0
        self._metrics_buffer: list[DecompositionTriggerMetric] = []

    def record_trigger(
        self,
        trigger_type: str,
        task_id: str,
        threshold: float | int,
        current_value: float | int,
        reason: str | None = None,
        log_event: Any | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
    ) -> DecompositionTriggerMetric:
        """Record a decomposition trigger event.

        Args:
            trigger_type: Type of trigger ("failure" or "budget")
            task_id: The task identifier that triggered decomposition
            threshold: The threshold that was reached/exceeded
            current_value: The current value that triggered (failure count or consumption ratio)
            reason: Optional additional reason/context
            log_event: Optional event logger callback
            trace_id: Optional trace ID for correlation
            parent_span_id: Optional parent span ID for correlation

        Returns:
            The DecompositionTriggerMetric that was recorded
        """
        timestamp = datetime.now(UTC).isoformat()

        # Update counters
        if trigger_type == "failure":
            self._failure_triggers += 1
        elif trigger_type == "budget":
            self._budget_triggers += 1

        metric = DecompositionTriggerMetric(
            metric_name=METRIC_DECOMPOSITION_TRIGGERS,
            value=1.0,
            labels={
                "trigger_type": trigger_type,
                "task_id": task_id,
            },
            timestamp=timestamp,
            metadata={
                "threshold": threshold,
                "current_value": current_value,
                "reason": reason or "",
            },
        )
        self._metrics_buffer.append(metric)

        # Log metric event
        if log_event:
            try:
                log_event(
                    "decomposition_trigger_metric",
                    session_id=None,
                    trace_id=trace_id,
                    parent_span_id=parent_span_id,
                    **metric.to_dict(),
                )
            except Exception as e:
                logger.debug("Failed to log decomposition trigger metric: %s", e)

        logger.info(
            "Decomposition triggered for task %s: type=%s, threshold=%s, value=%s",
            task_id,
            trigger_type,
            threshold,
            current_value,
        )

        return metric

    def get_summary(self) -> dict[str, Any]:
        """Get a summary of decomposition trigger metrics.

        Returns:
            Dict with:
            - total_triggers: Total number of decomposition triggers
            - failure_triggers: Number of failure-based triggers
            - budget_triggers: Number of budget-based triggers
        """
        return {
            "total_triggers": self._failure_triggers + self._budget_triggers,
            "failure_triggers": self._failure_triggers,
            "budget_triggers": self._budget_triggers,
        }

    def get_buffered_metrics(self) -> list[DecompositionTriggerMetric]:
        """Get all buffered metrics.

        Returns:
            List of DecompositionTriggerMetric instances recorded since last clear
        """
        return list(self._metrics_buffer)

    def clear(self) -> None:
        """Clear all metrics and reset counters."""
        self._failure_triggers = 0
        self._budget_triggers = 0
        self._metrics_buffer.clear()


# Global singleton instance
_decomposition_metrics_collector: DecompositionMetricsCollector | None = None


def get_decomposition_metrics_collector() -> DecompositionMetricsCollector:
    """Get the global decomposition metrics collector singleton.

    Returns:
        The global DecompositionMetricsCollector instance
    """
    global _decomposition_metrics_collector
    if _decomposition_metrics_collector is None:
        _decomposition_metrics_collector = DecompositionMetricsCollector()
    return _decomposition_metrics_collector


class TaskOutcome(str, Enum):
    """Enum for standardized task execution result reporting.

    Used to classify the outcome of task execution across the system.

    Attributes:
        SUCCESS: Task completed fully without any issues
        SUCCESS_WITH_LIMITS: Completed but hit budget/time limits during execution
        PARTIAL: Some work completed successfully, some failed
        FAILED: Task failed completely, no useful work done
        BLOCKED: Task cannot proceed, needs human intervention
    """

    SUCCESS = "success"
    SUCCESS_WITH_LIMITS = "success_with_limits"
    PARTIAL = "partial"
    FAILED = "failed"
    BLOCKED = "blocked"


@dataclass
class TaskResult:
    """Container for task execution result with outcome and message.

    Provides a standardized way to report task execution results
    with both a machine-readable outcome and a human-readable message.

    Attributes:
        outcome: The TaskOutcome enum value classifying the result
        outcome_message: Human-readable explanation of the outcome
        details: Optional dictionary with additional result details
    """

    outcome: TaskOutcome
    outcome_message: str
    details: dict[str, Any] = field(default_factory=dict)


# HTTP status codes that indicate transient errors (retryable)
TRANSIENT_HTTP_STATUS_CODES: frozenset[int] = frozenset({
    408,  # Request Timeout
    425,  # Too Early
    429,  # Too Many Requests (rate limit)
    500,  # Internal Server Error
    502,  # Bad Gateway
    503,  # Service Unavailable
    504,  # Gateway Timeout
})

# HTTP status codes that indicate non-transient errors (fail fast)
NON_TRANSIENT_HTTP_STATUS_CODES: frozenset[int] = frozenset({
    400,  # Bad Request
    401,  # Unauthorized
    403,  # Forbidden
    404,  # Not Found
    405,  # Method Not Allowed
    409,  # Conflict
    410,  # Gone
    422,  # Unprocessable Entity
})


class TransientError(Exception):
    """Base class for transient (retryable) errors.

    Transient errors are temporary failures that may succeed if retried.
    Examples: rate limits, network timeouts, temporary service unavailability.

    Attributes:
        retry_after: Optional number of seconds to wait before retrying
        original_error: Optional original exception that caused this error
    """

    def __init__(
        self,
        message: str,
        *,
        retry_after: float | None = None,
        original_error: Exception | None = None,
    ) -> None:
        """Initialize TransientError.

        Args:
            message: Error message describing the transient failure
            retry_after: Suggested seconds to wait before retrying (None if unknown)
            original_error: The underlying exception that was classified as transient
        """
        super().__init__(message)
        self.retry_after = retry_after
        self.original_error = original_error


class RateLimitError(TransientError):
    """Rate limit exceeded - retry after backoff.

    This is a specific transient error for rate limiting (HTTP 429).
    """

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        *,
        retry_after: float | None = None,
        original_error: Exception | None = None,
    ) -> None:
        """Initialize RateLimitError.

        Args:
            message: Error message
            retry_after: Seconds to wait before retrying (from Retry-After header)
            original_error: The underlying exception
        """
        super().__init__(message, retry_after=retry_after, original_error=original_error)


class TimeoutError(TransientError):
    """Operation timed out - may succeed on retry.

    This is a specific transient error for timeouts.
    """

    def __init__(
        self,
        message: str = "Operation timed out",
        *,
        retry_after: float | None = None,
        original_error: Exception | None = None,
    ) -> None:
        """Initialize TimeoutError.

        Args:
            message: Error message
            retry_after: Suggested backoff time
            original_error: The underlying exception
        """
        super().__init__(message, retry_after=retry_after, original_error=original_error)


class NetworkError(TransientError):
    """Temporary network issue - may succeed on retry.

    This is a specific transient error for network connectivity issues.
    """

    def __init__(
        self,
        message: str = "Network error",
        *,
        retry_after: float | None = None,
        original_error: Exception | None = None,
    ) -> None:
        """Initialize NetworkError.

        Args:
            message: Error message
            retry_after: Suggested backoff time
            original_error: The underlying exception
        """
        super().__init__(message, retry_after=retry_after, original_error=original_error)


class ServiceUnavailableError(TransientError):
    """Service temporarily unavailable - retry later.

    This is a specific transient error for HTTP 503 responses.
    """

    def __init__(
        self,
        message: str = "Service temporarily unavailable",
        *,
        retry_after: float | None = None,
        original_error: Exception | None = None,
    ) -> None:
        """Initialize ServiceUnavailableError.

        Args:
            message: Error message
            retry_after: Seconds to wait (from Retry-After header)
            original_error: The underlying exception
        """
        super().__init__(message, retry_after=retry_after, original_error=original_error)


class NonTransientError(Exception):
    """Base class for non-transient (non-retryable) errors.

    Non-transient errors are permanent failures that will not succeed on retry.
    Examples: validation errors, authentication failures, resource not found.

    Attributes:
        error_code: Optional error code for programmatic handling
        original_error: Optional original exception that caused this error
    """

    def __init__(
        self,
        message: str,
        *,
        error_code: str | None = None,
        original_error: Exception | None = None,
    ) -> None:
        """Initialize NonTransientError.

        Args:
            message: Error message describing the permanent failure
            error_code: Optional error code (e.g., "VALIDATION_ERROR", "AUTH_FAILED")
            original_error: The underlying exception that was classified as non-transient
        """
        super().__init__(message)
        self.error_code = error_code
        self.original_error = original_error


class ValidationError(NonTransientError):
    """Input validation failed - do not retry.

    This is a specific non-transient error for validation failures.
    """

    def __init__(
        self,
        message: str = "Validation failed",
        *,
        error_code: str | None = None,
        original_error: Exception | None = None,
        field: str | None = None,
    ) -> None:
        """Initialize ValidationError.

        Args:
            message: Error message
            error_code: Optional error code
            original_error: The underlying exception
            field: Optional field name that failed validation
        """
        super().__init__(message, error_code=error_code or "VALIDATION_ERROR", original_error=original_error)
        self.field = field


class AuthenticationError(NonTransientError):
    """Authentication failed - do not retry.

    This is a specific non-transient error for auth failures.
    """

    def __init__(
        self,
        message: str = "Authentication failed",
        *,
        error_code: str | None = None,
        original_error: Exception | None = None,
    ) -> None:
        """Initialize AuthenticationError.

        Args:
            message: Error message
            error_code: Optional error code
            original_error: The underlying exception
        """
        super().__init__(message, error_code=error_code or "AUTH_FAILED", original_error=original_error)


class NotFoundError(NonTransientError):
    """Resource not found - do not retry.

    This is a specific non-transient error for HTTP 404 responses.
    """

    def __init__(
        self,
        message: str = "Resource not found",
        *,
        error_code: str | None = None,
        original_error: Exception | None = None,
        resource_type: str | None = None,
        resource_id: str | None = None,
    ) -> None:
        """Initialize NotFoundError.

        Args:
            message: Error message
            error_code: Optional error code
            original_error: The underlying exception
            resource_type: Type of resource that was not found
            resource_id: ID of the resource that was not found
        """
        super().__init__(message, error_code=error_code or "NOT_FOUND", original_error=original_error)
        self.resource_type = resource_type
        self.resource_id = resource_id


class ForbiddenError(NonTransientError):
    """Access forbidden - do not retry.

    This is a specific non-transient error for HTTP 403 responses.
    """

    def __init__(
        self,
        message: str = "Access forbidden",
        *,
        error_code: str | None = None,
        original_error: Exception | None = None,
    ) -> None:
        """Initialize ForbiddenError.

        Args:
            message: Error message
            error_code: Optional error code
            original_error: The underlying exception
        """
        super().__init__(message, error_code=error_code or "FORBIDDEN", original_error=original_error)


def is_transient(error: BaseException, *, emit_metric: bool = True) -> bool:
    """Classify whether an error is transient (retryable).

    This function inspects an exception and determines if it represents a
    transient failure that may succeed on retry.

    Classification rules (in order of precedence):
    1. TransientError instances -> True
    2. NonTransientError instances -> False
    3. HTTP status code analysis (from APIError, HTTPError, etc.)
    4. Exception message heuristics (timeout, rate limit, connection)
    5. Exception type matching (OSError, ConnectionError, TimeoutError)

    Args:
        error: The exception to classify
        emit_metric: Whether to emit a classification metric (default True)

    Returns:
        True if the error is transient and should be retried,
        False if the error is non-transient and should fail fast
    """
    error_type = type(error).__name__
    result: bool

    # Rule 1: Explicit TransientError types
    if isinstance(error, TransientError):
        result = True
    # Rule 2: Explicit NonTransientError types
    elif isinstance(error, NonTransientError):
        result = False
    else:
        # Rule 3: Check for HTTP status codes
        status_code = _extract_status_code(error)
        if status_code is not None:
            if status_code in TRANSIENT_HTTP_STATUS_CODES:
                result = True
            elif status_code in NON_TRANSIENT_HTTP_STATUS_CODES:
                result = False
            else:
                result = _classify_by_heuristics(error)
        else:
            result = _classify_by_heuristics(error)

    # Emit error classification metric (P1 observability)
    if emit_metric:
        emit_error_classification_metric(
            classification="transient" if result else "non_transient",
            error_type=error_type,
        )

    return result


def _classify_by_heuristics(error: BaseException) -> bool:
    """Classify error by message and type heuristics.

    Args:
        error: The exception to classify

    Returns:
        True if transient, False otherwise
    """
    # Rule 4: Exception message heuristics
    error_message = str(error).lower()
    if _has_transient_message(error_message):
        return True
    if _has_non_transient_message(error_message):
        return False

    # Rule 5: Exception type matching
    if _is_transient_exception_type(error):
        return True

    # Default: treat unknown errors as non-transient (fail fast)
    return False


def _extract_status_code(error: BaseException) -> int | None:
    """Extract HTTP status code from an exception if available.

    Handles common patterns:
    - error.status_code (requests, httpx, obra.exceptions.APIError)
    - error.response.status_code (requests, httpx)
    - error.code (urllib)

    Args:
        error: The exception to extract status code from

    Returns:
        HTTP status code if found, None otherwise
    """
    # Direct status_code attribute (APIError, HTTPStatusError, etc.)
    if hasattr(error, "status_code"):
        code = error.status_code
        if isinstance(code, int):
            return code

    # Response object with status_code (requests.HTTPError, httpx.HTTPStatusError)
    if hasattr(error, "response"):
        response = error.response
        if response is not None and hasattr(response, "status_code"):
            code = response.status_code
            if isinstance(code, int):
                return code

    # urllib-style code attribute
    if hasattr(error, "code"):
        code = error.code
        if isinstance(code, int):
            return code

    return None


def _has_transient_message(message: str) -> bool:
    """Check if error message indicates a transient error.

    Args:
        message: Lowercase error message to check

    Returns:
        True if message suggests a transient error
    """
    transient_patterns = [
        "rate limit",
        "rate-limit",
        "ratelimit",
        "too many requests",
        "throttl",
        "timeout",
        "timed out",
        "connection reset",
        "connection refused",
        "connection error",
        "temporarily unavailable",
        "service unavailable",
        "server overloaded",
        "try again later",
        "retry",
        "temporary",
        "transient",
        "overloaded",
        "capacity",
    ]
    return any(pattern in message for pattern in transient_patterns)


def _has_non_transient_message(message: str) -> bool:
    """Check if error message indicates a non-transient error.

    Args:
        message: Lowercase error message to check

    Returns:
        True if message suggests a non-transient error
    """
    non_transient_patterns = [
        "invalid",
        "validation",
        "not found",
        "does not exist",
        "unauthorized",
        "forbidden",
        "permission denied",
        "access denied",
        "authentication failed",
        "bad request",
        "malformed",
    ]
    return any(pattern in message for pattern in non_transient_patterns)


def _is_transient_exception_type(error: BaseException) -> bool:
    """Check if exception type indicates a transient error.

    Args:
        error: The exception to check

    Returns:
        True if exception type is typically transient
    """
    # Built-in timeout and connection errors
    # Note: We check class names to avoid import dependencies
    transient_type_names = {
        "TimeoutError",
        "ConnectionError",
        "ConnectionResetError",
        "ConnectionRefusedError",
        "ConnectionAbortedError",
        "BrokenPipeError",
        "OSError",  # Often indicates network issues
        # Common library exceptions
        "ConnectTimeout",
        "ReadTimeout",
        "Timeout",
        "ConnectionTimeout",
        "PoolError",
        "MaxRetryError",
        "NewConnectionError",
    }

    error_type_name = type(error).__name__
    if error_type_name in transient_type_names:
        return True

    # Check base classes
    for base in type(error).__mro__:
        if base.__name__ in transient_type_names:
            return True

    return False


def get_retry_after(error: BaseException) -> float | None:
    """Extract retry-after delay from an error if available.

    Checks common patterns:
    - error.retry_after (TransientError)
    - error.response.headers["Retry-After"]
    - Parse from error message

    Args:
        error: The exception to extract retry-after from

    Returns:
        Seconds to wait before retrying, or None if not specified
    """
    # Direct retry_after attribute (TransientError)
    if hasattr(error, "retry_after"):
        retry_after = error.retry_after
        if isinstance(retry_after, (int, float)) and retry_after > 0:
            return float(retry_after)

    # Response headers (HTTP libraries)
    if hasattr(error, "response"):
        response = error.response
        if response is not None and hasattr(response, "headers"):
            headers = response.headers
            if headers is not None:
                retry_after = headers.get("Retry-After") or headers.get("retry-after")
                if retry_after is not None:
                    try:
                        return float(retry_after)
                    except (ValueError, TypeError):
                        pass

    return None


@dataclass
class FailureRecord:
    """Record of consecutive failures for a single task.

    Tracks failure count and context for auto-decomposition decisions.

    Attributes:
        task_id: The task identifier (e.g., "S1.T1")
        consecutive_failures: Number of consecutive failures
        needs_decomposition: Flag set when failure threshold is reached
        last_error_message: The most recent error message for context
        failure_reasons: List of error messages from each failure
    """

    task_id: str
    consecutive_failures: int = 0
    needs_decomposition: bool = False
    last_error_message: str = ""
    failure_reasons: list[str] = field(default_factory=list)


class FailureTracker:
    """Tracks consecutive failures per task for auto-decomposition triggering.

    The tracker maintains failure counts per task ID. When a task fails
    consecutively N times (where N is the configured threshold), the
    `needs_decomposition` flag is set to True on the FailureRecord.

    The counter resets to 0 when a task succeeds.

    Auto-decomposition can be globally disabled via the config flag:
    features.userplan.auto_decompose.enabled = false

    When disabled, failure tracking still occurs (for monitoring), but
    needs_decomposition will never be set to True.

    Usage:
        from obra.execution.errors import FailureTracker

        tracker = FailureTracker(threshold=3)

        # Track a failure
        record = tracker.record_failure("S1.T1", "Connection timeout")
        if record.needs_decomposition:
            # Trigger auto-decomposition logic
            pass

        # Track a success (resets counter)
        record = tracker.record_success("S1.T1")
        assert record.consecutive_failures == 0

    Thread-safety:
        This class is NOT thread-safe. Use external synchronization if
        accessing from multiple threads.
    """

    def __init__(self, threshold: int | None = None) -> None:
        """Initialize FailureTracker.

        Args:
            threshold: Number of consecutive failures before needs_decomposition
                is set. If None, uses AUTO_DECOMPOSE_FAILURE_THRESHOLD from
                constants (default: 3).
        """
        if threshold is None:
            from obra.constants import AUTO_DECOMPOSE_FAILURE_THRESHOLD

            threshold = AUTO_DECOMPOSE_FAILURE_THRESHOLD

        self._threshold = threshold
        self._records: dict[str, FailureRecord] = {}
        self._auto_decompose_enabled: bool | None = None  # Lazy-loaded from config

    @property
    def threshold(self) -> int:
        """The failure threshold for triggering decomposition."""
        return self._threshold

    def _is_auto_decompose_enabled(self) -> bool:
        """Check if auto-decomposition is enabled via config flag.

        Reads the features.userplan.auto_decompose.enabled config value.
        Defaults to True if not set (preserves existing behavior).

        The result is cached to avoid repeated config reads.

        Returns:
            True if auto-decomposition is enabled, False if disabled via config.
        """
        if self._auto_decompose_enabled is not None:
            return self._auto_decompose_enabled

        try:
            from obra.config.loaders import load_layered_config

            config, _, _ = load_layered_config(include_defaults=True)
            features = config.get("features", {})
            userplan = features.get("userplan", {})
            auto_decompose = userplan.get("auto_decompose", {})
            # Default to True to preserve existing behavior
            self._auto_decompose_enabled = auto_decompose.get("enabled", True)
        except Exception as e:
            # Log warning but default to enabled (fail-safe: don't break existing behavior)
            logger.warning(
                "Failed to read auto_decompose config flag, defaulting to enabled: %s", e
            )
            self._auto_decompose_enabled = True

        return self._auto_decompose_enabled

    def record_failure(self, task_id: str, error_message: str = "") -> FailureRecord:
        """Record a failure for a task.

        Increments the consecutive failure count for the task. If the count
        reaches the threshold, sets needs_decomposition=True and logs a
        warning.

        Args:
            task_id: The task identifier (e.g., "S1.T1")
            error_message: Optional error message for context

        Returns:
            The updated FailureRecord for the task
        """
        if task_id not in self._records:
            self._records[task_id] = FailureRecord(task_id=task_id)

        record = self._records[task_id]
        record.consecutive_failures += 1
        record.last_error_message = error_message

        if error_message:
            record.failure_reasons.append(error_message)

        # Check if threshold is reached
        if record.consecutive_failures >= self._threshold:
            if not record.needs_decomposition:
                # Check if auto-decomposition is enabled via config flag
                if self._is_auto_decompose_enabled():
                    # First time reaching threshold - flag for decomposition
                    record.needs_decomposition = True
                    logger.warning(
                        "Task %s reached %d consecutive failures (threshold: %d). "
                        "Flagging for auto-decomposition. Last error: %s",
                        task_id,
                        record.consecutive_failures,
                        self._threshold,
                        error_message or "(no message)",
                    )
                    # Emit decomposition trigger metric
                    get_decomposition_metrics_collector().record_trigger(
                        trigger_type="failure",
                        task_id=task_id,
                        threshold=self._threshold,
                        current_value=record.consecutive_failures,
                        reason=error_message or None,
                    )
                else:
                    # Auto-decomposition disabled - log but don't flag
                    logger.info(
                        "Task %s reached %d consecutive failures (threshold: %d). "
                        "Auto-decomposition skipped (disabled via config). Last error: %s",
                        task_id,
                        record.consecutive_failures,
                        self._threshold,
                        error_message or "(no message)",
                    )
        else:
            logger.debug(
                "Task %s failed (%d/%d consecutive failures): %s",
                task_id,
                record.consecutive_failures,
                self._threshold,
                error_message or "(no message)",
            )

        return record

    def record_success(self, task_id: str) -> FailureRecord:
        """Record a success for a task.

        Resets the consecutive failure count to 0 and clears the
        needs_decomposition flag. The failure_reasons list is preserved
        for historical context.

        Args:
            task_id: The task identifier (e.g., "S1.T1")

        Returns:
            The updated FailureRecord for the task
        """
        if task_id not in self._records:
            self._records[task_id] = FailureRecord(task_id=task_id)

        record = self._records[task_id]
        previous_failures = record.consecutive_failures

        # Reset on success
        record.consecutive_failures = 0
        record.needs_decomposition = False
        record.last_error_message = ""

        if previous_failures > 0:
            logger.info(
                "Task %s succeeded after %d consecutive failure(s). Counter reset.",
                task_id,
                previous_failures,
            )

        return record

    def get_record(self, task_id: str) -> FailureRecord | None:
        """Get the failure record for a task.

        Args:
            task_id: The task identifier

        Returns:
            The FailureRecord if it exists, None otherwise
        """
        return self._records.get(task_id)

    def needs_decomposition(self, task_id: str) -> bool:
        """Check if a task needs decomposition.

        Args:
            task_id: The task identifier

        Returns:
            True if the task has reached the failure threshold
        """
        record = self._records.get(task_id)
        return record.needs_decomposition if record else False

    def get_failure_count(self, task_id: str) -> int:
        """Get the consecutive failure count for a task.

        Args:
            task_id: The task identifier

        Returns:
            The number of consecutive failures (0 if task not tracked)
        """
        record = self._records.get(task_id)
        return record.consecutive_failures if record else 0

    def clear(self, task_id: str | None = None) -> None:
        """Clear failure tracking data.

        Args:
            task_id: If provided, clears only that task's record.
                If None, clears all records.
        """
        if task_id is not None:
            self._records.pop(task_id, None)
        else:
            self._records.clear()

    def get_all_needing_decomposition(self) -> list[FailureRecord]:
        """Get all tasks that need decomposition.

        Returns:
            List of FailureRecords where needs_decomposition is True
        """
        return [
            record for record in self._records.values() if record.needs_decomposition
        ]


@dataclass
class BudgetRecord:
    """Record of budget consumption for a single task.

    Tracks token and cost budget usage for auto-decomposition decisions.

    Attributes:
        task_id: The task identifier (e.g., "S1.T1")
        token_budget: Total token budget allocated to this task
        cost_budget_usd: Total cost budget in USD allocated to this task
        tokens_consumed: Tokens consumed so far
        cost_consumed_usd: Cost consumed so far in USD
        needs_decomposition: Flag set when budget threshold is reached
        decomposition_reason: Reason for decomposition trigger
    """

    task_id: str
    token_budget: int = 0
    cost_budget_usd: float = 0.0
    tokens_consumed: int = 0
    cost_consumed_usd: float = 0.0
    needs_decomposition: bool = False
    decomposition_reason: str = ""

    @property
    def token_consumption_ratio(self) -> float:
        """Calculate the ratio of tokens consumed to token budget.

        Returns:
            Float between 0.0 and 1.0+ (can exceed 1.0 if over budget)
        """
        if self.token_budget <= 0:
            return 0.0
        return self.tokens_consumed / self.token_budget

    @property
    def cost_consumption_ratio(self) -> float:
        """Calculate the ratio of cost consumed to cost budget.

        Returns:
            Float between 0.0 and 1.0+ (can exceed 1.0 if over budget)
        """
        if self.cost_budget_usd <= 0:
            return 0.0
        return self.cost_consumed_usd / self.cost_budget_usd

    @property
    def remaining_tokens(self) -> int:
        """Calculate remaining token budget.

        Returns:
            Remaining tokens (can be negative if over budget)
        """
        return self.token_budget - self.tokens_consumed

    @property
    def remaining_cost_usd(self) -> float:
        """Calculate remaining cost budget in USD.

        Returns:
            Remaining cost in USD (can be negative if over budget)
        """
        return self.cost_budget_usd - self.cost_consumed_usd

    def to_decomposition_context(self) -> dict[str, Any]:
        """Create decomposition context with remaining budget info.

        Returns:
            Dict with budget context for subtask decomposition
        """
        return {
            "parent_task_id": self.task_id,
            "remaining_token_budget": max(0, self.remaining_tokens),
            "remaining_cost_budget_usd": max(0.0, self.remaining_cost_usd),
            "consumed_tokens": self.tokens_consumed,
            "consumed_cost_usd": self.cost_consumed_usd,
            "budget_triggered_decomposition": self.needs_decomposition,
            "decomposition_reason": self.decomposition_reason,
        }


class BudgetMonitor:
    """Monitors budget consumption per task for auto-decomposition triggering.

    The monitor tracks token and cost usage per task ID. When a task's budget
    consumption exceeds the configured threshold without completion, the
    `needs_decomposition` flag is set to True on the BudgetRecord.

    This enables the orchestrator to automatically decompose tasks that are
    consuming too many resources, creating smaller subtasks that can be
    completed within budget.

    Auto-decomposition can be globally disabled via the config flag:
    features.userplan.auto_decompose.enabled = false

    When disabled, budget tracking still occurs (for monitoring), but
    needs_decomposition will never be set to True.

    Usage:
        from obra.execution.errors import BudgetMonitor

        monitor = BudgetMonitor()

        # Initialize budget for a task
        record = monitor.initialize_budget(
            "S1.T1",
            token_budget=100000,
            cost_budget_usd=0.50
        )

        # Record consumption during execution
        record = monitor.record_consumption(
            "S1.T1",
            tokens=5000,
            cost_usd=0.025
        )

        # Check if decomposition is needed
        if record.needs_decomposition:
            # Get context for subtask decomposition
            context = record.to_decomposition_context()
            # Trigger auto-decomposition logic

    Thread-safety:
        This class is NOT thread-safe. Use external synchronization if
        accessing from multiple threads.
    """

    def __init__(
        self,
        decompose_threshold: float | None = None,
        warning_threshold: float | None = None,
    ) -> None:
        """Initialize BudgetMonitor.

        Args:
            decompose_threshold: Budget consumption ratio (0.0-1.0) that triggers
                decomposition. If None, uses BUDGET_DECOMPOSE_THRESHOLD from
                constants (default: 0.80).
            warning_threshold: Budget consumption ratio (0.0-1.0) that triggers
                a warning. If None, uses BUDGET_WARNING_THRESHOLD from
                constants (default: 0.60).
        """
        from obra.constants import (
            BUDGET_DECOMPOSE_THRESHOLD,
            BUDGET_WARNING_THRESHOLD,
        )

        self._decompose_threshold = (
            decompose_threshold if decompose_threshold is not None else BUDGET_DECOMPOSE_THRESHOLD
        )
        self._warning_threshold = (
            warning_threshold if warning_threshold is not None else BUDGET_WARNING_THRESHOLD
        )
        self._records: dict[str, BudgetRecord] = {}
        self._auto_decompose_enabled: bool | None = None  # Lazy-loaded from config

    @property
    def decompose_threshold(self) -> float:
        """The budget consumption threshold for triggering decomposition."""
        return self._decompose_threshold

    @property
    def warning_threshold(self) -> float:
        """The budget consumption threshold for logging warnings."""
        return self._warning_threshold

    def _is_auto_decompose_enabled(self) -> bool:
        """Check if auto-decomposition is enabled via config flag.

        Reads the features.userplan.auto_decompose.enabled config value.
        Defaults to True if not set (preserves existing behavior).

        The result is cached to avoid repeated config reads.

        Returns:
            True if auto-decomposition is enabled, False if disabled via config.
        """
        if self._auto_decompose_enabled is not None:
            return self._auto_decompose_enabled

        try:
            from obra.config.loaders import load_layered_config

            config, _, _ = load_layered_config(include_defaults=True)
            features = config.get("features", {})
            userplan = features.get("userplan", {})
            auto_decompose = userplan.get("auto_decompose", {})
            # Default to True to preserve existing behavior
            self._auto_decompose_enabled = auto_decompose.get("enabled", True)
        except Exception as e:
            # Log warning but default to enabled (fail-safe: don't break existing behavior)
            logger.warning(
                "Failed to read auto_decompose config flag, defaulting to enabled: %s", e
            )
            self._auto_decompose_enabled = True

        return self._auto_decompose_enabled

    def initialize_budget(
        self,
        task_id: str,
        token_budget: int | None = None,
        cost_budget_usd: float | None = None,
    ) -> BudgetRecord:
        """Initialize budget tracking for a task.

        If the task already exists, its budget is updated (useful for adjusting
        budget allocations mid-execution).

        Args:
            task_id: The task identifier (e.g., "S1.T1")
            token_budget: Token budget for the task. If None, uses
                DEFAULT_TASK_TOKEN_BUDGET from constants.
            cost_budget_usd: Cost budget in USD. If None, uses
                DEFAULT_TASK_COST_BUDGET_USD from constants.

        Returns:
            The initialized BudgetRecord for the task
        """
        from obra.constants import (
            DEFAULT_TASK_COST_BUDGET_USD,
            DEFAULT_TASK_TOKEN_BUDGET,
        )

        effective_token_budget = (
            token_budget if token_budget is not None else DEFAULT_TASK_TOKEN_BUDGET
        )
        effective_cost_budget = (
            cost_budget_usd if cost_budget_usd is not None else DEFAULT_TASK_COST_BUDGET_USD
        )

        if task_id in self._records:
            # Update existing record's budget (preserve consumption)
            record = self._records[task_id]
            record.token_budget = effective_token_budget
            record.cost_budget_usd = effective_cost_budget
            logger.debug(
                "Updated budget for task %s: tokens=%d, cost_usd=%.4f",
                task_id,
                effective_token_budget,
                effective_cost_budget,
            )
        else:
            # Create new record
            record = BudgetRecord(
                task_id=task_id,
                token_budget=effective_token_budget,
                cost_budget_usd=effective_cost_budget,
            )
            self._records[task_id] = record
            logger.debug(
                "Initialized budget for task %s: tokens=%d, cost_usd=%.4f",
                task_id,
                effective_token_budget,
                effective_cost_budget,
            )

        return record

    def record_consumption(
        self,
        task_id: str,
        tokens: int = 0,
        cost_usd: float = 0.0,
    ) -> BudgetRecord:
        """Record budget consumption for a task.

        Increments the consumption counters and checks if thresholds are reached.
        If the task hasn't been initialized, it will be auto-initialized with
        default budgets.

        Args:
            task_id: The task identifier (e.g., "S1.T1")
            tokens: Number of tokens consumed in this increment
            cost_usd: Cost consumed in USD in this increment

        Returns:
            The updated BudgetRecord for the task
        """
        # Auto-initialize if not tracked
        if task_id not in self._records:
            self.initialize_budget(task_id)

        record = self._records[task_id]
        record.tokens_consumed += tokens
        record.cost_consumed_usd += cost_usd

        # Check thresholds
        token_ratio = record.token_consumption_ratio
        cost_ratio = record.cost_consumption_ratio
        max_ratio = max(token_ratio, cost_ratio)

        # Determine which budget triggered (for decomposition context)
        trigger_type = "token" if token_ratio >= cost_ratio else "cost"

        # Log warning if approaching threshold
        if max_ratio >= self._warning_threshold and max_ratio < self._decompose_threshold:
            logger.warning(
                "Task %s approaching budget threshold: %.1f%% consumed "
                "(tokens: %d/%d, cost: $%.4f/$%.4f)",
                task_id,
                max_ratio * 100,
                record.tokens_consumed,
                record.token_budget,
                record.cost_consumed_usd,
                record.cost_budget_usd,
            )

        # Check if decomposition threshold is reached
        if max_ratio >= self._decompose_threshold:
            if not record.needs_decomposition:
                # Check if auto-decomposition is enabled via config flag
                if self._is_auto_decompose_enabled():
                    # First time reaching threshold - flag for decomposition
                    record.needs_decomposition = True
                    record.decomposition_reason = (
                        f"Budget threshold exceeded: {trigger_type} at {max_ratio:.1%} "
                        f"(threshold: {self._decompose_threshold:.0%})"
                    )
                    logger.warning(
                        "Task %s exceeded budget threshold (%.1f%% consumed). "
                        "Flagging for auto-decomposition. "
                        "Tokens: %d/%d (%.1f%%), Cost: $%.4f/$%.4f (%.1f%%)",
                        task_id,
                        max_ratio * 100,
                        record.tokens_consumed,
                        record.token_budget,
                        token_ratio * 100,
                        record.cost_consumed_usd,
                        record.cost_budget_usd,
                        cost_ratio * 100,
                    )
                    # Emit decomposition trigger metric
                    get_decomposition_metrics_collector().record_trigger(
                        trigger_type="budget",
                        task_id=task_id,
                        threshold=self._decompose_threshold,
                        current_value=max_ratio,
                        reason=record.decomposition_reason,
                    )
                else:
                    # Auto-decomposition disabled - log but don't flag
                    record.decomposition_reason = (
                        f"Budget threshold exceeded: {trigger_type} at {max_ratio:.1%} "
                        f"(threshold: {self._decompose_threshold:.0%}) - auto-decomposition disabled"
                    )
                    logger.info(
                        "Task %s exceeded budget threshold (%.1f%% consumed). "
                        "Auto-decomposition skipped (disabled via config). "
                        "Tokens: %d/%d (%.1f%%), Cost: $%.4f/$%.4f (%.1f%%)",
                        task_id,
                        max_ratio * 100,
                        record.tokens_consumed,
                        record.token_budget,
                        token_ratio * 100,
                        record.cost_consumed_usd,
                        record.cost_budget_usd,
                        cost_ratio * 100,
                    )
        else:
            logger.debug(
                "Task %s budget consumption: %.1f%% (tokens: %d/%d, cost: $%.4f/$%.4f)",
                task_id,
                max_ratio * 100,
                record.tokens_consumed,
                record.token_budget,
                record.cost_consumed_usd,
                record.cost_budget_usd,
            )

        return record

    def record_success(self, task_id: str) -> BudgetRecord:
        """Record successful task completion.

        Clears the needs_decomposition flag since the task completed.
        The consumption data is preserved for historical/reporting purposes.

        Args:
            task_id: The task identifier (e.g., "S1.T1")

        Returns:
            The updated BudgetRecord for the task
        """
        if task_id not in self._records:
            self.initialize_budget(task_id)

        record = self._records[task_id]
        was_flagged = record.needs_decomposition

        # Clear decomposition flag on success
        record.needs_decomposition = False
        record.decomposition_reason = ""

        if was_flagged:
            logger.info(
                "Task %s completed despite budget threshold. "
                "Final consumption: tokens=%d (%.1f%%), cost=$%.4f (%.1f%%)",
                task_id,
                record.tokens_consumed,
                record.token_consumption_ratio * 100,
                record.cost_consumed_usd,
                record.cost_consumption_ratio * 100,
            )
        else:
            logger.debug(
                "Task %s completed successfully. "
                "Final consumption: tokens=%d (%.1f%%), cost=$%.4f (%.1f%%)",
                task_id,
                record.tokens_consumed,
                record.token_consumption_ratio * 100,
                record.cost_consumed_usd,
                record.cost_consumption_ratio * 100,
            )

        return record

    def get_record(self, task_id: str) -> BudgetRecord | None:
        """Get the budget record for a task.

        Args:
            task_id: The task identifier

        Returns:
            The BudgetRecord if it exists, None otherwise
        """
        return self._records.get(task_id)

    def needs_decomposition(self, task_id: str) -> bool:
        """Check if a task needs decomposition due to budget.

        Args:
            task_id: The task identifier

        Returns:
            True if the task has reached the budget threshold
        """
        record = self._records.get(task_id)
        return record.needs_decomposition if record else False

    def get_decomposition_context(self, task_id: str) -> dict[str, Any] | None:
        """Get decomposition context for a task.

        Args:
            task_id: The task identifier

        Returns:
            Dict with budget context for subtask decomposition, or None if
            task is not being tracked
        """
        record = self._records.get(task_id)
        return record.to_decomposition_context() if record else None

    def get_remaining_budget(
        self, task_id: str
    ) -> tuple[int, float] | None:
        """Get remaining budget for a task.

        Args:
            task_id: The task identifier

        Returns:
            Tuple of (remaining_tokens, remaining_cost_usd) or None if
            task is not being tracked
        """
        record = self._records.get(task_id)
        if record is None:
            return None
        return (record.remaining_tokens, record.remaining_cost_usd)

    def clear(self, task_id: str | None = None) -> None:
        """Clear budget tracking data.

        Args:
            task_id: If provided, clears only that task's record.
                If None, clears all records.
        """
        if task_id is not None:
            self._records.pop(task_id, None)
        else:
            self._records.clear()

    def get_all_needing_decomposition(self) -> list[BudgetRecord]:
        """Get all tasks that need decomposition due to budget.

        Returns:
            List of BudgetRecords where needs_decomposition is True
        """
        return [
            record for record in self._records.values() if record.needs_decomposition
        ]

    def get_status_summary(self, task_id: str) -> dict[str, Any] | None:
        """Get a summary of budget status for a task.

        Useful for logging and observability.

        Args:
            task_id: The task identifier

        Returns:
            Dict with budget status summary, or None if task not tracked
        """
        record = self._records.get(task_id)
        if record is None:
            return None

        return {
            "task_id": task_id,
            "token_budget": record.token_budget,
            "tokens_consumed": record.tokens_consumed,
            "token_consumption_pct": round(record.token_consumption_ratio * 100, 1),
            "cost_budget_usd": record.cost_budget_usd,
            "cost_consumed_usd": record.cost_consumed_usd,
            "cost_consumption_pct": round(record.cost_consumption_ratio * 100, 1),
            "remaining_tokens": record.remaining_tokens,
            "remaining_cost_usd": round(record.remaining_cost_usd, 4),
            "needs_decomposition": record.needs_decomposition,
            "decomposition_reason": record.decomposition_reason,
        }


__all__ = [
    "METRIC_DECOMPOSITION_TRIGGERS",
    "METRIC_ERRORS_CLASSIFIED",
    "NON_TRANSIENT_HTTP_STATUS_CODES",
    "TRANSIENT_HTTP_STATUS_CODES",
    "AuthenticationError",
    "BudgetMonitor",
    "BudgetRecord",
    "DecompositionMetricsCollector",
    "DecompositionTriggerMetric",
    "FailureRecord",
    "FailureTracker",
    "ForbiddenError",
    "NetworkError",
    "NonTransientError",
    "NotFoundError",
    "RateLimitError",
    "ServiceUnavailableError",
    "TaskOutcome",
    "TaskResult",
    "TimeoutError",
    "TransientError",
    "ValidationError",
    "emit_error_classification_metric",
    "get_decomposition_metrics_collector",
    "get_error_classification_metrics_summary",
    "get_retry_after",
    "is_transient",
]
