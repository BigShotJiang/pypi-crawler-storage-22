"""Local cache helpers for UserPlan artifacts."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import json

from obra.schemas.userplan_schema import UserPlan
from obra.utils.obra_home import get_obra_home


def get_userplan_cache_dir(project_id: str) -> Path:
    """Return the local cache directory for UserPlans."""
    return get_obra_home() / "userplans" / project_id


def write_userplan_cache(userplan: UserPlan, project_id: str) -> tuple[bool, str | None]:
    """Write a UserPlan cache file locally.

    Returns:
        (success, error_message)
    """
    try:
        cache_dir = get_userplan_cache_dir(project_id)
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_path = cache_dir / f"{userplan.id}.json"
        payload = userplan.model_dump(mode="json")
        cache_path.write_text(
            json.dumps(payload, indent=2, sort_keys=False) + "\n",
            encoding="utf-8",
        )
        return True, None
    except Exception as exc:  # pylint: disable=broad-exception-caught
        return False, f"Failed to write UserPlan cache: {exc}"


def write_userplan_mapping(
    userplan: UserPlan,
    project_id: str,
    source: dict[str, Any],
) -> tuple[bool, str | None]:
    """Write a UserPlan step mapping file locally.

    Returns:
        (success, error_message)
    """
    try:
        cache_dir = get_userplan_cache_dir(project_id)
        cache_dir.mkdir(parents=True, exist_ok=True)
        mapping_path = cache_dir / f"{userplan.id}_mapping.json"
        source_type = _normalize_source_type(source.get("type"))
        source_path = source.get("path")
        original_ids = _extract_original_step_ids(source, len(userplan.steps))

        steps_payload: list[dict[str, Any]] = []
        for idx, step in enumerate(userplan.steps):
            entry: dict[str, Any] = {
                "step_id": step.id,
                "index": step.index,
                "title": step.title,
            }
            if original_ids and idx < len(original_ids) and original_ids[idx] is not None:
                entry["original_id"] = original_ids[idx]
            steps_payload.append(entry)

        payload = {
            "userplan_id": userplan.id,
            "project_id": project_id,
            "source": {
                "type": source_type,
                "path": source_path,
            },
            "steps": steps_payload,
        }

        mapping_path.write_text(
            json.dumps(payload, indent=2, sort_keys=False) + "\n",
            encoding="utf-8",
        )
        return True, None
    except Exception as exc:  # pylint: disable=broad-exception-caught
        return False, f"Failed to write UserPlan mapping: {exc}"


def _normalize_source_type(source_type: Any) -> str | None:
    if source_type is None:
        return None
    if hasattr(source_type, "value"):
        return str(source_type.value)
    return str(source_type)


def _extract_original_step_ids(source: dict[str, Any], step_count: int) -> list[str | None]:
    if step_count <= 0:
        return []

    original_step_ids = source.get("original_step_ids")
    if isinstance(original_step_ids, list):
        return [str(value) if value is not None else None for value in original_step_ids]

    original_step_id_map = source.get("original_step_id_map")
    if isinstance(original_step_id_map, dict):
        return _map_indexed_ids(original_step_id_map, step_count)

    steps_payload = source.get("steps")
    if isinstance(steps_payload, list):
        extracted: list[str | None] = []
        for item in steps_payload:
            if isinstance(item, dict):
                extracted.append(item.get("id"))
        if extracted:
            return extracted

    plan_context = source.get("plan_context")
    if isinstance(plan_context, dict):
        extracted = _extract_story_ids(plan_context)
        if extracted:
            return extracted

    return []


def _map_indexed_ids(mapping: dict[Any, Any], step_count: int) -> list[str | None]:
    ids: list[str | None] = [None] * step_count
    for raw_key, raw_value in mapping.items():
        if raw_value is None:
            continue
        try:
            index = int(raw_key)
        except (TypeError, ValueError):
            continue
        if index == 0 and 0 < step_count:
            ids[0] = str(raw_value)
        elif 1 <= index <= step_count:
            ids[index - 1] = str(raw_value)
    return ids


def _extract_story_ids(plan_context: dict[str, Any]) -> list[str | None]:
    epics = plan_context.get("epics")
    if not isinstance(epics, list):
        return []
    story_ids: list[str | None] = []
    for epic in epics:
        if not isinstance(epic, dict):
            continue
        stories = epic.get("stories")
        if not isinstance(stories, list):
            continue
        for story in stories:
            if not isinstance(story, dict):
                continue
            story_ids.append(story.get("id"))
    return story_ids


__all__ = [
    "get_userplan_cache_dir",
    "write_userplan_cache",
    "write_userplan_mapping",
]
