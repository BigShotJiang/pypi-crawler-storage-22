"""Derivation utilities for Obra hybrid orchestration.

This module provides derivation analysis tools including:
- Parallelization analysis: Identify independent items for concurrent execution

Related:
    - obra/hybrid/handlers/derive.py (main derive handler)
    - docs/design/prds/USERPLAN_DOBRA_ENHANCEMENTS_PRD.md
"""

from obra.hybrid.derivation.parallelization import (
    ParallelizationAnalyzer,
    ParallelizationResult,
)

__all__ = [
    "ParallelizationAnalyzer",
    "ParallelizationResult",
]
