"""Mission-level sizing and routing for pipeline decisions.

This module provides sizing classification at the mission/objective level
to determine optimal pipeline routing. The LLM-based sizing gate classifies
objectives into size classes, and this module provides routing logic.

Architecture:
    - SizingGate: LLM-based classification (in sizing_gate.py)
    - SizingGuidance: Dataclass with size class and routing hints
    - Helper functions: Derive skip flags and validation intensity from size class

Related:
    - docs/design/briefs/COMPLEXITY_BASED_PIPELINE_ROUTING_BRIEF.md
    - obra/hybrid/derivation/sizing_gate.py (LLM-based sizing)
    - obra/intent/models.py (IntentModel structure)
"""

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class PlanningMode(str, Enum):
    """Planning mode for pipeline routing.

    Determines how aggressively to optimize the derivation pipeline:
    - AUTO: Assess complexity and route automatically
    - LIGHT: Simple objectives - skip scaffolded stages, minimal validation (default)
    - THOROUGH: Complex objectives - full scaffolded pipeline, thorough validation
    """

    AUTO = "auto"
    LIGHT = "light"
    THOROUGH = "thorough"


class SizeClass(str, Enum):
    """Sizing classification for objectives."""

    TRIVIAL = "trivial"
    SIMPLE = "simple"
    MODERATE = "moderate"
    COMPLEX = "complex"


@dataclass
class SizingGuidance:
    """Sizing guidance derived from objective classification."""

    size_class: SizeClass
    description: str
    scope: str
    use_single_shot: bool
    rationale: str = field(default="")
    method: str = field(default="")

    def to_dict(self) -> dict[str, Any]:
        """Serialize sizing guidance to a dictionary."""
        return {
            "size_class": self.size_class.value,
            "description": self.description,
            "scope": self.scope,
            "use_single_shot": self.use_single_shot,
            "rationale": self.rationale,
            "method": self.method,
        }

    @property
    def skip_analogues(self) -> bool:
        """Whether to skip analogues/expert alignment stage.

        TRIVIAL/SIMPLE/MODERATE skip analogues (focused scope).
        COMPLEX runs full scaffolded pipeline.
        """
        return self.size_class != SizeClass.COMPLEX

    @property
    def skip_brief(self) -> bool:
        """Whether to skip brief generation stage.

        TRIVIAL/SIMPLE skip brief (minimal overhead).
        MODERATE/COMPLEX generate briefs for structure.
        """
        return self.size_class in (SizeClass.TRIVIAL, SizeClass.SIMPLE)

    @property
    def validation_intensity(self) -> str:
        """Validation intensity based on size class.

        TRIVIAL/SIMPLE: light validation
        MODERATE: standard validation
        COMPLEX: thorough validation
        """
        if self.size_class in (SizeClass.TRIVIAL, SizeClass.SIMPLE):
            return "light"
        if self.size_class == SizeClass.MODERATE:
            return "standard"
        return "thorough"

    @property
    def planning_mode(self) -> PlanningMode:
        """Planning mode based on size class.

        TRIVIAL/SIMPLE: LIGHT mode
        MODERATE/COMPLEX: THOROUGH mode
        """
        if self.size_class in (SizeClass.TRIVIAL, SizeClass.SIMPLE):
            return PlanningMode.LIGHT
        return PlanningMode.THOROUGH


@dataclass
class PreFilterResult:
    """Result for the pre-filter classification."""

    is_trivial: bool
    reason: str
    method: str


def get_default_sizing_guidance(size_class: SizeClass | str) -> SizingGuidance:
    """Get default sizing guidance for a size class.

    Used as fallback when sizing gate fails or for forced modes.

    Args:
        size_class: Size class enum or string value

    Returns:
        SizingGuidance with appropriate defaults
    """
    if isinstance(size_class, str):
        size_class = SizeClass(size_class.lower())

    defaults = {
        SizeClass.TRIVIAL: {
            "description": "A quick fix or minor tweak",
            "scope": "Single file or tiny change",
            "use_single_shot": True,
        },
        SizeClass.SIMPLE: {
            "description": "A focused, self-contained change",
            "scope": "Small surface area, limited dependencies",
            "use_single_shot": True,
        },
        SizeClass.MODERATE: {
            "description": "A cohesive feature with clear boundaries",
            "scope": "Multiple files, keep boundaries explicit",
            "use_single_shot": False,
        },
        SizeClass.COMPLEX: {
            "description": "A cross-cutting change requiring architectural consideration",
            "scope": "Multiple subsystems, plan for sequencing",
            "use_single_shot": False,
        },
    }

    config = defaults.get(size_class, defaults[SizeClass.MODERATE])
    return SizingGuidance(
        size_class=size_class,
        description=config["description"],
        scope=config["scope"],
        use_single_shot=config["use_single_shot"],
        rationale="default",
        method="fallback",
    )


# Convenience exports
__all__ = [
    "PlanningMode",
    "PreFilterResult",
    "SizeClass",
    "SizingGuidance",
    "get_default_sizing_guidance",
]
