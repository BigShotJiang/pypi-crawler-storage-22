"""Parallelization analysis for DerivedPlan items.

This module provides dependency graph construction and parallel group assignment
for derived plan items. LLM agents can use parallel groups to schedule independent
items concurrently.

Architecture:
    - ParallelizationAnalyzer: Main class for analyzing parallelization opportunities
    - ParallelizationResult: Result container with parallel groups and speedup estimate

Related:
    - docs/design/prds/USERPLAN_DOBRA_ENHANCEMENTS_PRD.md (FR-1 through FR-4)
    - obra/hybrid/handlers/derive.py (integration point)
"""

import logging
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ParallelizationResult:
    """Result of parallelization analysis.

    Attributes:
        parallel_groups: Mapping of group_id -> list of item_ids in that group
        item_groups: Mapping of item_id -> parallel_group (for easy lookup)
        parallelizable_count: Number of items that can run in parallel (items in groups > 1)
        group_count: Total number of parallel groups
        estimated_speedup_pct: Estimated percentage speedup from parallelization
        dependency_graph: The computed dependency graph (for debugging/audit)
    """

    parallel_groups: dict[int, list[str]] = field(default_factory=dict)
    item_groups: dict[str, int] = field(default_factory=dict)
    parallelizable_count: int = 0
    group_count: int = 0
    estimated_speedup_pct: float = 0.0
    dependency_graph: dict[str, list[str]] = field(default_factory=dict)


class ParallelizationAnalyzer:
    """Analyzer for identifying parallel execution opportunities.

    Builds a dependency graph from DerivedPlan items and assigns parallel groups
    using topological sort. Items in the same group have no interdependencies
    and can execute concurrently.

    Example:
        >>> analyzer = ParallelizationAnalyzer()
        >>> items = [
        ...     {"id": "T1", "dependencies": []},
        ...     {"id": "T2", "dependencies": ["T1"]},
        ...     {"id": "T3", "dependencies": ["T1"]},
        ...     {"id": "T4", "dependencies": ["T2", "T3"]},
        ... ]
        >>> result = analyzer.analyze(items)
        >>> print(result.parallel_groups)
        {0: ['T1'], 1: ['T2', 'T3'], 2: ['T4']}
        >>> print(result.estimated_speedup_pct)
        25.0  # 4 items -> 3 groups = 25% speedup
    """

    def __init__(self) -> None:
        """Initialize the analyzer."""
        self._graph: dict[str, set[str]] = {}  # item_id -> set of dependent item_ids
        self._reverse_graph: dict[str, set[str]] = {}  # item_id -> set of dependencies
        self._items_by_id: dict[str, dict[str, Any]] = {}

    def analyze(self, items: list[dict[str, Any]]) -> ParallelizationResult:
        """Analyze plan items for parallelization opportunities.

        Args:
            items: List of plan item dictionaries with id and dependencies fields

        Returns:
            ParallelizationResult with parallel groups and speedup estimate
        """
        if not items:
            logger.debug("No items to analyze for parallelization")
            return ParallelizationResult()

        # Build the dependency graph
        self._build_graph(items)

        # Assign parallel groups using topological sort
        parallel_groups, item_groups = self._assign_parallel_groups()

        # Calculate speedup estimate
        speedup_pct = self._estimate_speedup(items, parallel_groups)

        # Count parallelizable items (items in groups with multiple members)
        parallelizable_count = sum(
            len(group_items) for group_items in parallel_groups.values() if len(group_items) > 1
        )

        # Build dependency graph for result (convert sets to lists)
        dependency_graph = {
            item_id: list(deps) for item_id, deps in self._reverse_graph.items()
        }

        result = ParallelizationResult(
            parallel_groups=parallel_groups,
            item_groups=item_groups,
            parallelizable_count=parallelizable_count,
            group_count=len(parallel_groups),
            estimated_speedup_pct=speedup_pct,
            dependency_graph=dependency_graph,
        )

        logger.info(
            "Parallelization analysis complete: %d groups, %d parallelizable items, "
            "estimated %.1f%% speedup",
            result.group_count,
            result.parallelizable_count,
            result.estimated_speedup_pct,
        )

        return result

    def _build_graph(self, items: list[dict[str, Any]]) -> None:
        """Build dependency graph from plan items.

        Creates both forward graph (item -> dependents) and reverse graph
        (item -> dependencies) for efficient traversal.

        Args:
            items: List of plan item dictionaries
        """
        self._graph = defaultdict(set)
        self._reverse_graph = defaultdict(set)
        self._items_by_id = {}

        # First pass: index all items by ID
        for item in items:
            item_id = item.get("id", "")
            if not item_id:
                logger.warning("Skipping item without id: %s", item)
                continue
            self._items_by_id[item_id] = item
            # Initialize empty sets for items with no dependencies
            self._graph[item_id] = set()
            self._reverse_graph[item_id] = set()

        # Second pass: build edges from dependencies
        for item in items:
            item_id = item.get("id", "")
            if not item_id:
                continue

            dependencies = item.get("dependencies", [])
            if not isinstance(dependencies, list):
                dependencies = [dependencies] if dependencies else []

            for dep_id in dependencies:
                if not dep_id:
                    continue
                # Only add edge if dependency exists in our item set
                if dep_id in self._items_by_id:
                    self._graph[dep_id].add(item_id)  # dep_id blocks item_id
                    self._reverse_graph[item_id].add(dep_id)  # item_id depends on dep_id
                else:
                    logger.debug(
                        "Dependency '%s' for item '%s' not found in item set, ignoring",
                        dep_id,
                        item_id,
                    )

        logger.debug(
            "Built dependency graph: %d items, %d edges",
            len(self._items_by_id),
            sum(len(deps) for deps in self._reverse_graph.values()),
        )

    def _assign_parallel_groups(self) -> tuple[dict[int, list[str]], dict[str, int]]:
        """Assign parallel groups using topological sort (Kahn's algorithm).

        Items are assigned to groups based on their topological level:
        - Group 0: Items with no dependencies (can start immediately)
        - Group N: Items whose dependencies are all in groups < N

        Returns:
            Tuple of (parallel_groups, item_groups):
            - parallel_groups: group_id -> list of item_ids
            - item_groups: item_id -> group_id
        """
        if not self._items_by_id:
            return {}, {}

        # Calculate in-degree for each node
        in_degree: dict[str, int] = {
            item_id: len(deps) for item_id, deps in self._reverse_graph.items()
        }

        # Initialize with items that have no dependencies
        current_level: list[str] = [
            item_id for item_id, degree in in_degree.items() if degree == 0
        ]

        parallel_groups: dict[int, list[str]] = {}
        item_groups: dict[str, int] = {}
        group_id = 0
        processed_count = 0

        while current_level:
            # All items in current_level can execute in parallel
            parallel_groups[group_id] = sorted(current_level)  # Sort for determinism
            for item_id in current_level:
                item_groups[item_id] = group_id
            processed_count += len(current_level)

            # Find next level: items whose all dependencies are now processed
            next_level: list[str] = []
            for item_id in current_level:
                # For each item we just processed, decrement in-degree of its dependents
                for dependent_id in self._graph[item_id]:
                    in_degree[dependent_id] -= 1
                    if in_degree[dependent_id] == 0:
                        next_level.append(dependent_id)

            current_level = next_level
            group_id += 1

        # Check for cycles (items that were never processed)
        if processed_count < len(self._items_by_id):
            unprocessed = set(self._items_by_id.keys()) - set(item_groups.keys())
            logger.warning(
                "Dependency cycle detected! %d items could not be assigned groups: %s",
                len(unprocessed),
                list(unprocessed)[:5],  # Show first 5
            )
            # Assign remaining items to final group (conservative fallback)
            for item_id in unprocessed:
                item_groups[item_id] = group_id
            if unprocessed:
                parallel_groups[group_id] = sorted(unprocessed)

        return parallel_groups, item_groups

    def _estimate_speedup(
        self,
        items: list[dict[str, Any]],
        parallel_groups: dict[int, list[str]],
    ) -> float:
        """Estimate percentage speedup from parallelization.

        Uses a simple model: speedup = (sequential_time - parallel_time) / sequential_time
        where sequential_time = N items and parallel_time = number of groups.

        This assumes all items take equal time, which is a simplification.
        More accurate estimation would require complexity scores per item.

        Args:
            items: Original list of plan items
            parallel_groups: Computed parallel groups

        Returns:
            Estimated speedup percentage (0-100)
        """
        n_items = len(items)
        n_groups = len(parallel_groups)

        if n_items <= 1 or n_groups <= 0:
            return 0.0

        # Sequential time: N items
        # Parallel time: N_groups (assuming items in each group run in parallel)
        # Speedup = (N - N_groups) / N * 100
        speedup = ((n_items - n_groups) / n_items) * 100

        return round(speedup, 1)


__all__ = [
    "ParallelizationAnalyzer",
    "ParallelizationResult",
]
