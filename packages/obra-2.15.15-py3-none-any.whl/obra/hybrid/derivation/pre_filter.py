"""LLM-based pre-filter for objective complexity classification before intent enrichment.

Classifies objectives as TRIVIAL (obvious fast-path) or UNCERTAIN (needs full analysis).
"""
# pylint: disable=broad-exception-caught,duplicate-code

from __future__ import annotations

import logging
from inspect import isawaitable
from typing import Any

from obra.hybrid.derivation.mission_complexity import PreFilterResult
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline

logger = logging.getLogger(__name__)

PRE_FILTER_TEMPLATE_SCHEMA = {
    "classification": "",
    "_instructions": (
        "Classify as exactly one of:\n"
        "- TRIVIAL: Obviously simple (fix typo, remove unused import, rename variable)\n"
        "- UNCERTAIN: Needs deeper analysis (any feature, refactor, or ambiguous scope)\n\n"
        "When in doubt, choose UNCERTAIN."
    ),
}

PRE_FILTER_PROMPT = (
    "You are classifying whether an objective is trivial or requires full analysis.\n\n"
    "Objective:\n{objective}\n\n"
    "Classify as TRIVIAL only for obvious small changes (examples: 'fix typo in README', "
    "'remove unused import').\n"
    "Classify as UNCERTAIN for anything else (examples: 'add auth', 'build minesweeper')."
)

_TEMPLATE_FALLBACK_STATUSES = {"template_fallback", "template_error", "validation_failed"}


def get_pre_filter_llm_config(config: dict[str, Any]) -> dict[str, Any]:
    """Return LLM config for the pre-filter classification call."""
    sizing_config = (
        config.get("derivation", {})
        .get("sizing", {})
        .get("pre_filter", {})
    )
    model = sizing_config.get("model")
    if model is None:
        model = config.get("llm", {}).get("model")
    return {
        "provider": config.get("llm", {}).get("provider"),
        "model": model,
        "thinking": "medium",
        "auth": config.get("llm", {}).get("auth", "oauth"),
    }


class PreFilter:  # pylint: disable=too-few-public-methods
    """Pre-filter that identifies trivial objectives before intent enrichment."""

    def __init__(self, config: dict[str, Any]) -> None:
        self._config = config
        self._logger = logging.getLogger(__name__)

    async def classify(self, objective: str, pipeline: TemplateEditPipeline) -> PreFilterResult:
        """Classify objective as trivial or uncertain using template edit pipeline."""
        prompt = PRE_FILTER_PROMPT.format(objective=objective)
        pre_filter_config = (
            self._config.get("derivation", {})
            .get("sizing", {})
            .get("pre_filter", {})
        )
        timeout_s = pre_filter_config.get("timeout_s", 15)
        max_retries = pre_filter_config.get("max_retries", 1)

        def validator(data: dict[str, Any]) -> tuple[bool, str | None]:
            classification = str(data.get("classification", "")).upper()
            if classification not in {"TRIVIAL", "UNCERTAIN"}:
                return (
                    False,
                    "classification must be TRIVIAL or UNCERTAIN, got "
                    f"'{classification}'",
                )
            return (True, None)

        def fallback() -> dict[str, str]:
            return {"classification": "UNCERTAIN"}

        try:
            result = pipeline.execute(
                base_prompt=prompt,
                template_schema=PRE_FILTER_TEMPLATE_SCHEMA,
                validator=validator,
                fallback_fn=fallback,
                llm_config=get_pre_filter_llm_config(self._config),
                timeout_s=timeout_s,
                max_retries=max_retries,
            )
            if isawaitable(result):
                result = await result
            data, metadata = result
        except Exception as exc:
            self._logger.warning("Pre-filter LLM failed: %s", exc)
            return PreFilterResult(
                is_trivial=False,
                reason="LLM error, defaulting to full analysis",
                method="heuristic_fallback",
            )

        status = (metadata or {}).get("status")
        if status in _TEMPLATE_FALLBACK_STATUSES:
            return PreFilterResult(
                is_trivial=False,
                reason="Template fallback, defaulting to full analysis",
                method="heuristic_fallback",
            )

        classification = str(data.get("classification", "UNCERTAIN")).upper()
        if classification not in {"TRIVIAL", "UNCERTAIN"}:
            self._logger.warning("Invalid pre-filter classification: %s", classification)
            return PreFilterResult(
                is_trivial=False,
                reason="Invalid classification, defaulting to full analysis",
                method="heuristic_fallback",
            )

        if classification == "TRIVIAL":
            return PreFilterResult(
                is_trivial=True,
                reason="LLM classified as TRIVIAL",
                method="llm",
            )

        return PreFilterResult(
            is_trivial=False,
            reason="LLM classified as UNCERTAIN",
            method="llm",
        )
