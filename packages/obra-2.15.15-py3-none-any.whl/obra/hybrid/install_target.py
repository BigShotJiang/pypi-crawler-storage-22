"""Install target strategy for language-agnostic tooling."""

from __future__ import annotations

import logging
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class ToolchainInfo:
    ecosystem: str
    manager: str | None
    env_path: Path | None
    is_active: bool


class InstallTargetManager:
    """Manage environment creation and install command construction."""

    def __init__(self) -> None:
        self._logger = logger

    def detect_toolchain(self, working_dir: Path) -> dict[str, ToolchainInfo]:
        working_dir = Path(working_dir)
        toolchains: dict[str, ToolchainInfo] = {}

        python_env_paths = [
            working_dir / ".venv",
            working_dir / "venv",
            working_dir / ".conda",
        ]
        python_env = next((path for path in python_env_paths if path.exists()), None)
        python_manager = None
        if python_env is not None:
            python_manager = "conda" if python_env.name == ".conda" else "venv"
        if (working_dir / "uv.lock").exists():
            python_manager = "uv"
        pyproject_path = working_dir / "pyproject.toml"
        if pyproject_path.exists():
            try:
                content = pyproject_path.read_text(encoding="utf-8")
                if "[tool.poetry]" in content:
                    python_manager = "poetry"
            except OSError:
                pass
        if python_env is not None or pyproject_path.exists() or (working_dir / "uv.lock").exists():
            toolchains["python"] = ToolchainInfo(
                ecosystem="python",
                manager=python_manager,
                env_path=python_env,
                is_active=python_env is not None,
            )

        node_modules = working_dir / "node_modules"
        node_lockfiles = {
            "pnpm": working_dir / "pnpm-lock.yaml",
            "yarn": working_dir / "yarn.lock",
            "bun": working_dir / "bun.lockb",
            "npm": working_dir / "package-lock.json",
        }
        node_manager = None
        for manager, lockfile in node_lockfiles.items():
            if lockfile.exists():
                node_manager = manager
                break
        if node_modules.exists() or any(path.exists() for path in node_lockfiles.values()):
            toolchains["node"] = ToolchainInfo(
                ecosystem="node",
                manager=node_manager or "npm",
                env_path=None,
                is_active=node_modules.exists(),
            )

        cargo_toml = working_dir / "Cargo.toml"
        if cargo_toml.exists() or (working_dir / "target").exists():
            toolchains["rust"] = ToolchainInfo(
                ecosystem="rust",
                manager="cargo",
                env_path=None,
                is_active=cargo_toml.exists(),
            )

        go_mod = working_dir / "go.mod"
        if go_mod.exists() or (working_dir / "go.sum").exists():
            toolchains["go"] = ToolchainInfo(
                ecosystem="go",
                manager="go",
                env_path=None,
                is_active=go_mod.exists(),
            )

        gemfile = working_dir / "Gemfile"
        if gemfile.exists() or (working_dir / ".bundle").exists():
            toolchains["ruby"] = ToolchainInfo(
                ecosystem="ruby",
                manager="bundler" if gemfile.exists() else "gem",
                env_path=None,
                is_active=gemfile.exists(),
            )

        return toolchains

    def create_environment(
        self,
        ecosystem: str,
        working_dir: Path,
        policy: str,
        manager_preference: str,
    ) -> Path | None:
        # Node/Ruby environments are handled via manifests (package.json, Gemfile)
        # and scaffolding logic elsewhere.
        working_dir = Path(working_dir)
        if policy == "never":
            return None

        if ecosystem != "python":
            if ecosystem in {"rust", "go"}:
                return working_dir
            return None

        env_path = working_dir / ".venv"
        toolchains = self.detect_toolchain(working_dir)
        existing_env = toolchains.get("python")
        if policy == "when_missing" and existing_env and existing_env.env_path:
            return existing_env.env_path

        if policy == "always" and env_path.exists():
            shutil.rmtree(env_path)

        manager = manager_preference
        if manager_preference == "auto":
            manager = "uv" if shutil.which("uv") else "venv"

        if manager == "uv":
            self._run_command(["uv", "venv", ".venv"], cwd=working_dir)
        else:
            self._run_command(["python", "-m", "venv", ".venv"], cwd=working_dir)

        if not env_path.exists():
            env_path.mkdir(parents=True, exist_ok=True)
        return env_path

    def get_package_manager(self, ecosystem: str, preference: str, working_dir: Path) -> str:
        working_dir = Path(working_dir)
        if preference != "auto":
            return preference

        if ecosystem == "python":
            if (working_dir / "uv.lock").exists():
                return "uv"
            if (working_dir / "poetry.lock").exists():
                return "poetry"
            if (working_dir / "Pipfile.lock").exists():
                return "pipenv"
            return "pip"
        if ecosystem == "node":
            if (working_dir / "pnpm-lock.yaml").exists():
                return "pnpm"
            if (working_dir / "yarn.lock").exists():
                return "yarn"
            if (working_dir / "bun.lockb").exists():
                return "bun"
            return "npm"
        if ecosystem == "rust":
            return "cargo"
        if ecosystem == "go":
            return "go"
        if ecosystem == "ruby":
            if (working_dir / "Gemfile").exists():
                return "bundler"
            return "gem"
        return preference

    def build_install_command(
        self,
        ecosystem: str,
        packages: list[str],
        target: str,
        manager: str,
        env_path: Path | None,
    ) -> list[str]:
        if ecosystem == "python":
            if manager == "poetry":
                return ["poetry", "add", *packages]
            if manager == "uv":
                command = ["uv", "pip", "install"]
                if target == "project_local" and env_path is not None:
                    python_path = env_path / "bin" / "python"
                    command.extend(["--python", str(python_path)])
                return command + packages
            if target == "project_local" and env_path is not None:
                pip_path = env_path / "bin" / "pip"
                return [str(pip_path), "install", *packages]
            return ["python", "-m", "pip", "install", *packages]

        if ecosystem == "node":
            if manager == "pnpm":
                command = ["pnpm", "add"]
            elif manager == "yarn":
                command = ["yarn", "add"]
            elif manager == "bun":
                command = ["bun", "add"]
            else:
                command = ["npm", "install"]
            if target == "system":
                if command[0] == "yarn":
                    command = ["yarn", "global", "add"]
                elif command[0] == "npm":
                    command = ["npm", "install", "-g"]
                elif command[0] == "pnpm":
                    command = ["pnpm", "add", "-g"]
                elif command[0] == "bun":
                    command = ["bun", "add", "-g"]
            return command + packages

        if ecosystem == "rust":
            if target == "system":
                return ["cargo", "install", *packages]
            return ["cargo", "add", *packages]

        if ecosystem == "go":
            if target == "system":
                return ["go", "install", *packages]
            return ["go", "get", *packages]

        if ecosystem == "ruby":
            if manager == "bundler" and target != "system":
                return ["bundle", "add", *packages]
            return ["gem", "install", *packages]

        return [manager, *packages]

    def normalize_inferred_package_name(self, name: str) -> str:
        """Cheap normalization of LLM-inferred package name.

        Does basic string cleanup only - no hard filtering. Let pip validate,
        LLM fixes failures.

        Args:
            name: Raw package name from LLM inference

        Returns:
            Normalized package name (never None - always returns something to try)
        """
        if not name:
            return ""

        normalized = name.strip()
        if not normalized:
            return ""

        # Strip parenthetical annotations: "tkinter (with TCL/TK)" → "tkinter"
        if "(" in normalized:
            normalized = normalized.split("(")[0].strip()

        # Strip version specifiers: "requests>=2.0" → "requests"
        for token in ["==", ">=", "<=", "~=", "!=", ">", "<", "@"]:
            if token in normalized:
                normalized = normalized.split(token, 1)[0].strip()

        # Strip extras: "requests[security]" → "requests"
        if "[" in normalized:
            normalized = normalized.split("[", 1)[0].strip()

        # Strip comments: "requests ; python_version >= '3.8'" → "requests"
        if ";" in normalized:
            normalized = normalized.split(";", 1)[0].strip()

        return normalized

    def _run_command(self, command: list[str], cwd: Path) -> None:
        try:
            subprocess.run(
                command,
                cwd=cwd,
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
        except subprocess.CalledProcessError as exc:
            self._logger.warning("Failed to create environment: %s", exc)
            raise
