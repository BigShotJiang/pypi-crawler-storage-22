"""Prompt file lifecycle management for hybrid orchestration."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any
from uuid import uuid4

from obra.constants import MAX_PROMPT_FILES

logger = logging.getLogger(__name__)


class PromptFileManager:
    """Manage prompt file creation and cleanup for LLM invocations."""

    DEFAULT_PROMPT_MAX_FILES = MAX_PROMPT_FILES
    INDEX_FILENAME = ".prompt-index.json"

    def __init__(
        self,
        working_dir: Path,
        retain: bool = False,
        run_id: str | None = None,
        max_files: int | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._retain = retain
        self._defer_cleanup = False
        self._run_id = run_id or uuid4().hex
        self._prompt_root = self._working_dir / ".obra" / "prompts"
        self._run_dir = self._prompt_root / self._run_id
        self._max_files = max_files or self.DEFAULT_PROMPT_MAX_FILES
        self._index_path = self._prompt_root / self.INDEX_FILENAME

    def write_prompt(self, prompt: str, use_absolute: bool = False) -> tuple[Path, str]:
        """Write prompt to a file and return (path, instruction).

        Args:
            prompt: The prompt content to write
            use_absolute: If True, use absolute paths in instruction for Windows Codex

        Returns:
            Tuple of (filepath, instruction) where instruction contains the path to read
        """
        self._run_dir.mkdir(parents=True, exist_ok=True)
        filename = f".obra-prompt-{uuid4().hex[:8]}.txt"
        filepath = self._run_dir / filename
        filepath.write_text(prompt, encoding="utf-8")
        self._record_prompt(filepath)
        instruction_path = self.instruction_path(filepath, use_absolute=use_absolute)
        instruction = f"Read and execute all instructions in {instruction_path}"
        return filepath, instruction

    def cleanup(self, filepath: Path) -> None:
        """Remove the specific prompt file unless retention is enabled.

        This method only deletes the single file that was used by this handler,
        not other prompt files. Cap-based cleanup is handled separately via
        explicit cleanup commands to avoid race conditions with parallel sessions.
        """
        if self._retain or self._defer_cleanup:
            return
        try:
            filepath.unlink(missing_ok=True)
            self._cleanup_run_dir_path(filepath.parent)
        except OSError as e:
            logger.debug("Could not remove prompt file %s: %s", filepath, e)

    def defer_cleanup(self) -> None:
        """Defer cleanup until the next invocation."""
        self._defer_cleanup = True

    def cleanup_stale_prompt_artifacts(self) -> int:
        """Remove prompt artifacts that exceed the max-files cap."""
        removed = self._cleanup_over_cap(protected_run_ids={self._run_id})
        if removed:
            logger.debug("Removed %d prompt artifact(s) during preflight cleanup.", removed)
        return removed

    @classmethod
    def cleanup_orphaned(cls, working_dir: Path, max_files: int | None = None) -> int:
        """Remove prompt artifacts over the max-files cap in the working directory."""
        manager = cls(working_dir, retain=False, max_files=max_files)
        return manager.cleanup_stale_prompt_artifacts()

    def _cleanup_run_dir_path(self, run_dir: Path) -> None:
        if not run_dir.exists():
            return
        if any(run_dir.iterdir()):
            return
        run_dir.rmdir()

    def _relative_instruction_path(self, filepath: Path) -> str:
        try:
            relative = filepath.relative_to(self._working_dir)
        except ValueError:
            return filepath.as_posix()
        return relative.as_posix()

    def _relative_index_path(self, filepath: Path) -> str:
        try:
            relative = filepath.relative_to(self._working_dir)
        except ValueError:
            return str(filepath)
        return relative.as_posix()

    def _record_prompt(self, filepath: Path) -> None:
        index = self._load_index()
        path_key = self._relative_index_path(filepath)
        for entry in index["entries"]:
            if isinstance(entry, dict) and entry.get("path") == path_key:
                self._save_index(index)
                return
        entry = {
            "id": index["next_id"],
            "run_id": self._run_id,
            "path": path_key,
        }
        index["next_id"] += 1
        index["entries"].append(entry)
        self._save_index(index)

    def _load_index(self) -> dict[str, Any]:
        if not self._prompt_root.exists():
            return {"next_id": 1, "entries": []}
        if self._index_path.exists():
            try:
                data = json.loads(self._index_path.read_text(encoding="utf-8"))
                if isinstance(data, dict) and "entries" in data and "next_id" in data:
                    return data
            except (OSError, json.JSONDecodeError):
                logger.warning("Failed to load prompt index; rebuilding.")
        return self._build_index_from_scan()

    def _build_index_from_scan(self) -> dict[str, object]:
        prompt_files = list(self._prompt_root.rglob(".obra-prompt-*.txt"))
        prompt_files.sort(key=lambda path: (self._safe_mtime(path), path.as_posix()))
        entries = []
        next_id = 1
        for path in prompt_files:
            entries.append(
                {
                    "id": next_id,
                    "run_id": path.parent.name,
                    "path": self._relative_index_path(path),
                }
            )
            next_id += 1
        return {"next_id": next_id, "entries": entries}

    def _save_index(self, index: dict[str, object]) -> None:
        self._prompt_root.mkdir(parents=True, exist_ok=True)
        self._index_path.write_text(json.dumps(index, indent=2), encoding="utf-8")

    def _entry_path(self, entry: dict[str, object]) -> Path:
        path = entry.get("path")
        if isinstance(path, str):
            candidate = Path(path)
            if candidate.is_absolute():
                return candidate
            return self._working_dir / candidate
        return self._working_dir

    def instruction_path(self, filepath: Path, use_absolute: bool = False) -> str:
        """Return a normalized prompt instruction path.

        Args:
            filepath: The prompt file path
            use_absolute: If True, return absolute path for Windows Codex compatibility

        Returns:
            Path string for use in prompt instructions. Uses POSIX format (forward slashes).
        """
        if use_absolute:
            # BUG-c2e0a391: Codex on Windows doesn't properly resolve relative paths
            # against the -C workspace flag. Use absolute paths for reliability.
            return filepath.as_posix()
        return self._relative_instruction_path(filepath)

    def resolve_instruction_path(self, instruction_path: str) -> Path:
        """Resolve an instruction path relative to the workspace root."""
        candidate = Path(instruction_path)
        if candidate.is_absolute():
            return candidate
        return self._working_dir / candidate

    def ensure_prompt_available(self, filepath: Path) -> Path:
        """Ensure the prompt file exists and resolves under the workspace root."""
        instruction_path = self._relative_instruction_path(filepath)
        if not filepath.exists():
            raise FileNotFoundError(
                "Prompt file missing for Codex CLI: "
                f"{instruction_path} (workspace root: {self._working_dir})"
            )
        resolved = self.resolve_instruction_path(instruction_path)
        if not resolved.exists():
            raise FileNotFoundError(
                "Prompt file missing for Codex CLI: "
                f"{instruction_path} (workspace root: {self._working_dir})"
            )
        return resolved

    def _cleanup_over_cap(self, protected_run_ids: set[str] | None = None) -> int:
        if self._max_files <= 0:
            return 0
        index = self._load_index()
        entries = []
        for entry in index["entries"]:
            if not isinstance(entry, dict):
                continue
            entry_path = self._entry_path(entry)
            if entry_path.exists():
                entries.append(entry)
            else:
                logger.debug("Pruned missing prompt entry: %s", entry.get("path"))
        index["entries"] = entries

        legacy_files = list(self._working_dir.glob(".obra-prompt-*.txt"))
        legacy_files.sort(key=lambda path: (self._safe_mtime(path), path.as_posix()))
        total_existing = len(entries) + len(legacy_files)
        if total_existing == 0 and not self._prompt_root.exists():
            return 0
        if total_existing <= self._max_files:
            self._save_index(index)
            return 0

        to_delete = total_existing - self._max_files
        removed = 0
        for legacy in legacy_files:
            if removed >= to_delete:
                break
            legacy.unlink(missing_ok=True)
            removed += 1

        protected = protected_run_ids or set()
        kept_entries = []
        for entry in sorted(entries, key=self._entry_sort_key):
            if removed >= to_delete:
                kept_entries.append(entry)
                continue
            if entry.get("run_id") in protected:
                kept_entries.append(entry)
                continue
            entry_path = self._entry_path(entry)
            entry_path.unlink(missing_ok=True)
            removed += 1
            self._cleanup_run_dir_path(entry_path.parent)

        index["entries"] = kept_entries
        self._save_index(index)
        return removed

    @staticmethod
    def _entry_sort_key(entry: dict[str, Any]) -> int:
        try:
            return int(entry.get("id", 0))
        except (TypeError, ValueError):
            return 0

    @staticmethod
    def _safe_mtime(path: Path) -> float:
        try:
            return path.stat().st_mtime
        except OSError:
            return 0.0


__all__ = ["PromptFileManager"]
