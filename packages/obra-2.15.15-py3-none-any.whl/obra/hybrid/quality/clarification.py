"""Clarification loop for iterative UserPlan quality refinement.

This module implements the clarification loop that iteratively improves
UserPlan quality through structured field-level feedback. The loop runs
after the quality gate passes, providing refinement for acceptable plans.

Architecture:
    - ClarificationLoop: Main orchestrator for iterative refinement
    - QualityDeltaCalculator: Tracks quality improvement between iterations
    - FieldFeedbackGenerator: Generates structured feedback for specific fields

Termination Conditions (per PRD):
    1. Quality score meets or exceeds target threshold (threshold_reached)
    2. Maximum iterations reached (max_iterations)
    3. Quality delta below threshold (diminishing_returns)
    4. No improvements identified (no_improvements)

Related:
    - docs/design/prds/USERPLAN_DOBRA_ENHANCEMENTS_PRD.md (FR-10 through FR-13c)
    - obra/schemas/clarification_schema.py (feedback schemas)
    - obra/config/default_config.yaml (clarification.loop config)
"""

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

import yaml

from obra.schemas.clarification_schema import (
    ClarificationFeedback,
    ClarificationResult,
    FieldFeedback,
    IssueType,
    TerminalReason,
)

if TYPE_CHECKING:
    from obra.schemas.userplan_schema import UserPlan, UserPlanStep

logger = logging.getLogger(__name__)

# Default config path
DEFAULT_CONFIG_PATH = Path(__file__).parent.parent.parent.parent / "obra" / "config" / "default_config.yaml"


class FieldFeedbackGenerator:
    """Generates field-level feedback for UserPlan quality issues.

    Analyzes UserPlan steps to identify specific field deficiencies
    and generate actionable improvement suggestions.

    Example:
        >>> generator = FieldFeedbackGenerator()
        >>> feedback = generator.analyze_step(step)
        >>> for item in feedback:
        ...     print(f"{item.field}: {item.issue} - {item.suggestion}")
    """

    # Fields to analyze and their expected characteristics
    FIELD_CRITERIA = {
        "deliverables": {
            "min_items": 1,
            "vague_patterns": ["stuff", "things", "etc", "various"],
            "required": True,
        },
        "success_criteria": {
            "min_length": 10,
            "vague_patterns": ["works", "done", "complete", "finished"],
            "required": True,
        },
        "requirements": {
            "min_items": 0,
            "required": False,
        },
        "tech_stack": {
            "min_items": 0,
            "required": False,
        },
        "constraints": {
            "min_items": 0,
            "required": False,
        },
        "assumptions": {
            "min_items": 0,
            "required": False,
        },
    }

    def analyze_step(self, step: "UserPlanStep") -> list[FieldFeedback]:
        """Analyze a UserPlan step and generate feedback for deficient fields.

        Args:
            step: The UserPlan step to analyze

        Returns:
            List of FieldFeedback items for fields needing improvement
        """
        feedback: list[FieldFeedback] = []
        context = step.context

        if context is None:
            # No context at all - generate feedback for all required fields
            for field_name, criteria in self.FIELD_CRITERIA.items():
                if criteria.get("required", False):
                    feedback.append(
                        FieldFeedback(
                            field=field_name,
                            issue=IssueType.MISSING,
                            description=f"No {field_name} specified for this step",
                            suggestion=self._get_suggestion(field_name, IssueType.MISSING, step),
                            resolved=False,
                            step_id=step.id,
                        )
                    )
            return feedback

        # Analyze each field
        for field_name, criteria in self.FIELD_CRITERIA.items():
            field_feedback = self._analyze_field(field_name, criteria, context, step)
            if field_feedback:
                feedback.append(field_feedback)

        return feedback

    def _analyze_field(
        self,
        field_name: str,
        criteria: dict[str, Any],
        context: Any,
        step: "UserPlanStep",
    ) -> FieldFeedback | None:
        """Analyze a specific field for issues.

        Args:
            field_name: Name of the field to analyze
            criteria: Criteria for the field
            context: The step context object
            step: The parent step

        Returns:
            FieldFeedback if issues found, None otherwise
        """
        value = getattr(context, field_name, None)

        # Check for missing required field
        if value is None:
            if criteria.get("required", False):
                return FieldFeedback(
                    field=field_name,
                    issue=IssueType.MISSING,
                    description=f"Required field '{field_name}' is not specified",
                    suggestion=self._get_suggestion(field_name, IssueType.MISSING, step),
                    resolved=False,
                    step_id=step.id,
                )
            return None

        # Check list fields
        if isinstance(value, list):
            min_items = criteria.get("min_items", 0)
            if len(value) < min_items:
                return FieldFeedback(
                    field=field_name,
                    issue=IssueType.INCOMPLETE,
                    description=f"Field '{field_name}' has {len(value)} items, needs at least {min_items}",
                    suggestion=self._get_suggestion(field_name, IssueType.INCOMPLETE, step),
                    resolved=False,
                    step_id=step.id,
                )
            # Check for vague content in list items
            vague_patterns = criteria.get("vague_patterns", [])
            for item in value:
                if isinstance(item, str) and self._is_vague(item, vague_patterns):
                    return FieldFeedback(
                        field=field_name,
                        issue=IssueType.VAGUE,
                        description=f"Item in '{field_name}' is too vague: '{item[:50]}...'",
                        suggestion=self._get_suggestion(field_name, IssueType.VAGUE, step),
                        resolved=False,
                        step_id=step.id,
                    )
            return None

        # Check string fields
        if isinstance(value, str):
            min_length = criteria.get("min_length", 0)
            if len(value) < min_length:
                return FieldFeedback(
                    field=field_name,
                    issue=IssueType.INCOMPLETE,
                    description=f"Field '{field_name}' is too short ({len(value)} chars, needs {min_length}+)",
                    suggestion=self._get_suggestion(field_name, IssueType.INCOMPLETE, step),
                    resolved=False,
                    step_id=step.id,
                )
            # Check for vague content
            vague_patterns = criteria.get("vague_patterns", [])
            if self._is_vague(value, vague_patterns):
                return FieldFeedback(
                    field=field_name,
                    issue=IssueType.VAGUE,
                    description=f"Field '{field_name}' contains vague language",
                    suggestion=self._get_suggestion(field_name, IssueType.VAGUE, step),
                    resolved=False,
                    step_id=step.id,
                )

        return None

    def _is_vague(self, text: str, patterns: list[str]) -> bool:
        """Check if text contains vague patterns."""
        text_lower = text.lower()
        return any(pattern in text_lower for pattern in patterns)

    def _get_suggestion(self, field_name: str, issue: IssueType, step: "UserPlanStep") -> str:
        """Generate an actionable suggestion for a field issue."""
        suggestions = {
            "deliverables": {
                IssueType.MISSING: f"Add specific deliverables for '{step.title}' (e.g., files, modules, or artifacts to produce)",
                IssueType.INCOMPLETE: "Add more deliverables to fully specify what will be produced",
                IssueType.VAGUE: "Replace vague terms with specific, measurable deliverables",
            },
            "success_criteria": {
                IssueType.MISSING: f"Define how to verify '{step.title}' is complete (e.g., tests pass, feature works)",
                IssueType.INCOMPLETE: "Expand success criteria to be more specific and testable",
                IssueType.VAGUE: "Replace vague criteria with specific, verifiable conditions",
            },
            "requirements": {
                IssueType.MISSING: "List any prerequisites or requirements for this step",
                IssueType.INCOMPLETE: "Add more requirements to clarify dependencies",
                IssueType.VAGUE: "Make requirements more specific and actionable",
            },
            "tech_stack": {
                IssueType.MISSING: "Specify technologies, frameworks, or tools to use",
                IssueType.INCOMPLETE: "Add more technology details",
                IssueType.VAGUE: "Specify exact technology versions or choices",
            },
            "constraints": {
                IssueType.MISSING: "Document any limitations or boundaries",
                IssueType.INCOMPLETE: "Add more constraints if applicable",
                IssueType.VAGUE: "Make constraints more specific",
            },
            "assumptions": {
                IssueType.MISSING: "Document assumptions being made",
                IssueType.INCOMPLETE: "Add more assumptions if applicable",
                IssueType.VAGUE: "Clarify assumptions",
            },
        }
        return suggestions.get(field_name, {}).get(issue, f"Improve the {field_name} field")


class QualityDeltaCalculator:
    """Calculates and tracks quality improvement between iterations.

    Monitors quality score changes to detect diminishing returns
    and determine when to terminate the clarification loop.

    Example:
        >>> calc = QualityDeltaCalculator(threshold=0.05)
        >>> is_diminishing = calc.is_diminishing_returns(0.75, 0.77)
        >>> print(is_diminishing)  # True (delta = 0.02 < 0.05)
    """

    def __init__(self, threshold: float = 0.05) -> None:
        """Initialize the calculator.

        Args:
            threshold: Minimum improvement to not be considered diminishing returns
        """
        self.threshold = threshold
        self._history: list[tuple[float, float]] = []

    def calculate_delta(self, quality_before: float, quality_after: float) -> float:
        """Calculate quality delta between two scores.

        Args:
            quality_before: Quality score before refinement
            quality_after: Quality score after refinement

        Returns:
            Quality delta (quality_after - quality_before)
        """
        delta = quality_after - quality_before
        self._history.append((quality_before, quality_after))
        return round(delta, 3)

    def is_diminishing_returns(self, quality_before: float, quality_after: float) -> bool:
        """Check if quality improvement is below threshold.

        Args:
            quality_before: Quality score before refinement
            quality_after: Quality score after refinement

        Returns:
            True if improvement is below threshold (diminishing returns)
        """
        delta = quality_after - quality_before
        return delta < self.threshold

    def get_history(self) -> list[tuple[float, float]]:
        """Get history of quality measurements."""
        return self._history.copy()


class ClarificationLoop:
    """Orchestrates iterative quality refinement for UserPlans.

    The clarification loop runs after the quality gate passes, providing
    iterative refinement for acceptable plans. It generates field-level
    feedback and tracks quality improvement.

    Termination conditions:
        1. Quality score meets target (threshold_reached)
        2. Max iterations reached (max_iterations)
        3. Quality delta below threshold (diminishing_returns)
        4. No improvements identified (no_improvements)

    Example:
        >>> loop = ClarificationLoop()
        >>> result = loop.run(userplan)
        >>> print(f"Improved from {result.initial_quality} to {result.final_quality}")
    """

    def __init__(
        self,
        max_iterations: int = 3,
        quality_delta_threshold: float = 0.05,
        target_quality: float = 0.8,
        config_path: Path | None = None,
    ) -> None:
        """Initialize the clarification loop.

        Args:
            max_iterations: Maximum number of iterations (default from config or 3)
            quality_delta_threshold: Minimum improvement to continue (default 0.05)
            target_quality: Target quality score (default 0.8)
            config_path: Path to config file (uses default if None)
        """
        # Load config
        self._config = self._load_config(config_path)
        loop_config = self._config.get("clarification", {}).get("loop", {})

        # Apply config with fallback to constructor args
        self.max_iterations = loop_config.get("max_iterations", max_iterations)
        self.quality_delta_threshold = loop_config.get("quality_delta_threshold", quality_delta_threshold)
        self.target_quality = loop_config.get("target_quality", target_quality)
        self.enabled = loop_config.get("enabled", True)

        # Initialize components
        self._feedback_generator = FieldFeedbackGenerator()
        self._delta_calculator = QualityDeltaCalculator(threshold=self.quality_delta_threshold)

        logger.debug(
            "ClarificationLoop initialized: max_iterations=%d, delta_threshold=%.2f, target=%.2f",
            self.max_iterations,
            self.quality_delta_threshold,
            self.target_quality,
        )

    def _load_config(self, config_path: Path | None) -> dict[str, Any]:
        """Load configuration from YAML file."""
        path = config_path or DEFAULT_CONFIG_PATH
        try:
            if path.exists():
                with open(path) as f:
                    return yaml.safe_load(f) or {}
        except Exception as e:
            logger.warning("Failed to load config from %s: %s", path, e)
        return {}

    def run(
        self,
        userplan: "UserPlan",
        quality_assessor: Any | None = None,
    ) -> ClarificationResult:
        """Run the clarification loop on a UserPlan.

        Args:
            userplan: The UserPlan to refine
            quality_assessor: Optional quality assessment function that takes
                a UserPlan and returns a quality score (0.0-1.0)

        Returns:
            ClarificationResult with all iteration feedback and metrics
        """
        if not self.enabled:
            logger.info("Clarification loop disabled, skipping")
            return ClarificationResult(
                userplan_id=userplan.id,
                initial_quality=userplan.quality_score or 0.0,
                final_quality=userplan.quality_score or 0.0,
                total_improvement=0.0,
                iterations_run=0,
                iterations=[],
                final_terminal_reason=TerminalReason.NO_IMPROVEMENTS,
            )

        # Initialize tracking
        initial_quality = userplan.quality_score or 0.0
        current_quality = initial_quality
        iterations: list[ClarificationFeedback] = []
        total_auto_filled = 0
        total_fields_improved = 0

        logger.info(
            "Starting clarification loop for %s (initial quality: %.2f, target: %.2f)",
            userplan.id,
            initial_quality,
            self.target_quality,
        )

        # Check if already at target
        if current_quality >= self.target_quality:
            logger.info("Quality already at target, no refinement needed")
            return ClarificationResult(
                userplan_id=userplan.id,
                initial_quality=initial_quality,
                final_quality=current_quality,
                total_improvement=0.0,
                iterations_run=0,
                iterations=[],
                final_terminal_reason=TerminalReason.THRESHOLD_REACHED,
            )

        terminal_reason: TerminalReason | None = None

        for iteration_num in range(1, self.max_iterations + 1):
            logger.debug("Starting iteration %d/%d", iteration_num, self.max_iterations)

            # Generate feedback for all steps
            all_feedback: list[FieldFeedback] = []
            for step in userplan.steps:
                step_feedback = self._feedback_generator.analyze_step(step)
                all_feedback.extend(step_feedback)

            # Check if no improvements found
            if not all_feedback:
                logger.info("No improvements identified at iteration %d", iteration_num)
                terminal_reason = TerminalReason.NO_IMPROVEMENTS
                break

            # Simulate quality improvement (in production, would call quality_assessor)
            # For now, estimate improvement based on feedback resolution
            quality_before = current_quality
            estimated_improvement = len(all_feedback) * 0.02  # ~2% per issue addressed
            quality_after = min(1.0, quality_before + estimated_improvement)

            # If quality assessor provided, use it
            if quality_assessor is not None:
                try:
                    quality_after = quality_assessor(userplan)
                except Exception as e:
                    logger.warning("Quality assessor failed: %s", e)

            # Calculate delta
            delta = self._delta_calculator.calculate_delta(quality_before, quality_after)
            current_quality = quality_after

            # Track auto-filled fields (none auto-filled in this implementation)
            auto_filled: list[str] = []

            # Create iteration feedback
            is_terminal = False
            iter_terminal_reason: TerminalReason | None = None

            # Check termination conditions
            if current_quality >= self.target_quality:
                is_terminal = True
                iter_terminal_reason = TerminalReason.THRESHOLD_REACHED
                terminal_reason = TerminalReason.THRESHOLD_REACHED
            elif self._delta_calculator.is_diminishing_returns(quality_before, quality_after):
                is_terminal = True
                iter_terminal_reason = TerminalReason.DIMINISHING_RETURNS
                terminal_reason = TerminalReason.DIMINISHING_RETURNS
            elif iteration_num >= self.max_iterations:
                is_terminal = True
                iter_terminal_reason = TerminalReason.MAX_ITERATIONS
                terminal_reason = TerminalReason.MAX_ITERATIONS

            iteration_feedback = ClarificationFeedback(
                iteration=iteration_num,
                quality_before=quality_before,
                quality_after=quality_after,
                quality_delta=delta,
                fields_improved=all_feedback,
                terminal=is_terminal,
                terminal_reason=iter_terminal_reason,
                auto_filled_fields=auto_filled,
            )
            iterations.append(iteration_feedback)

            # Update totals
            total_auto_filled += len(auto_filled)
            total_fields_improved += len(all_feedback)

            logger.info(
                "Iteration %d: quality %.2f -> %.2f (delta: %.3f), fields: %d",
                iteration_num,
                quality_before,
                quality_after,
                delta,
                len(all_feedback),
            )

            # Exit if terminal
            if is_terminal:
                logger.info(
                    "Terminating at iteration %d: %s",
                    iteration_num,
                    iter_terminal_reason.value if iter_terminal_reason else "unknown",
                )
                break

        # Ensure we have a terminal reason
        if terminal_reason is None:
            terminal_reason = TerminalReason.MAX_ITERATIONS

        # Build result
        final_quality = current_quality
        total_improvement = final_quality - initial_quality

        logger.info(
            "Clarification complete: %s -> %.2f -> %.2f (improved %.3f) in %d iterations",
            userplan.id,
            initial_quality,
            final_quality,
            total_improvement,
            len(iterations),
        )

        return ClarificationResult(
            userplan_id=userplan.id,
            initial_quality=initial_quality,
            final_quality=final_quality,
            total_improvement=total_improvement,
            iterations_run=len(iterations),
            iterations=iterations,
            final_terminal_reason=terminal_reason,
            fields_auto_filled=total_auto_filled,
            fields_improved_count=total_fields_improved,
        )

    def run_single_iteration(
        self,
        userplan: "UserPlan",
        iteration: int = 1,
        quality_before: float | None = None,
    ) -> ClarificationFeedback:
        """Run a single clarification iteration.

        Useful for integration with external quality assessment systems.

        Args:
            userplan: The UserPlan to analyze
            iteration: Iteration number (1-based)
            quality_before: Quality score before this iteration (uses userplan.quality_score if None)

        Returns:
            ClarificationFeedback for this iteration
        """
        quality = quality_before if quality_before is not None else (userplan.quality_score or 0.0)

        # Generate feedback for all steps
        all_feedback: list[FieldFeedback] = []
        for step in userplan.steps:
            step_feedback = self._feedback_generator.analyze_step(step)
            all_feedback.extend(step_feedback)

        # Estimate quality improvement
        estimated_improvement = len(all_feedback) * 0.02
        quality_after = min(1.0, quality + estimated_improvement)
        delta = round(quality_after - quality, 3)

        # Determine termination
        is_terminal = False
        terminal_reason: TerminalReason | None = None

        if not all_feedback:
            is_terminal = True
            terminal_reason = TerminalReason.NO_IMPROVEMENTS
        elif quality_after >= self.target_quality:
            is_terminal = True
            terminal_reason = TerminalReason.THRESHOLD_REACHED
        elif delta < self.quality_delta_threshold:
            is_terminal = True
            terminal_reason = TerminalReason.DIMINISHING_RETURNS
        elif iteration >= self.max_iterations:
            is_terminal = True
            terminal_reason = TerminalReason.MAX_ITERATIONS

        return ClarificationFeedback(
            iteration=iteration,
            quality_before=quality,
            quality_after=quality_after,
            quality_delta=delta,
            fields_improved=all_feedback,
            terminal=is_terminal,
            terminal_reason=terminal_reason,
            auto_filled_fields=[],
        )


# Convenience exports
__all__ = [
    "ClarificationLoop",
    "FieldFeedbackGenerator",
    "QualityDeltaCalculator",
]
