"""LLM prompt templates for intent generation.

This module provides a single adaptive prompt that trusts frontier LLMs
to calibrate response depth to task complexity. Replaces the previous
rule-based approach with extensive rubrics and checklists.

Design philosophy:
    - Trust LLM intelligence over brittle rules
    - State the goal clearly, let the LLM reason
    - Match output depth to task complexity
    - Omit sections that don't add value

Project state awareness:
    - EMPTY projects: LLM may propose foundation choices
    - EXISTING projects: LLM may suggest investigation questions

Related:
    - docs/design/briefs/AUTO_INTENT_GENERATION_BRIEF.md
    - obra/intent/models.py
    - obra/hybrid/handlers/intent.py
"""

from obra.intent.models import InputType


def build_intent_generation_prompt(
    objective: str,
    input_type: InputType,
    project_state: str | None = None,
) -> str:
    """Build LLM prompt for intent generation.

    Uses a single adaptive prompt that trusts the LLM to calibrate
    response depth to the task's actual complexity.

    Args:
        objective: User objective or input text
        input_type: Classification of input type (used for context, not routing)
        project_state: Optional project state (EMPTY or EXISTING)

    Returns:
        Formatted prompt string for LLM

    Example:
        >>> prompt = build_intent_generation_prompt("add auth", InputType.VAGUE_NL, "EMPTY")
        >>> "OBJECTIVE:" in prompt
        True
    """
    return _build_adaptive_prompt(objective, input_type, project_state)


def _build_adaptive_prompt(
    objective: str,
    input_type: InputType,
    project_state: str | None = None,
) -> str:
    """Build the unified adaptive prompt.

    This prompt trusts the LLM to:
    - Understand the task's inherent complexity
    - Generate appropriately-sized output
    - Skip sections that don't add value
    - Expand sections that matter for complex tasks

    Args:
        objective: User objective or input text
        input_type: Classification of input type
        project_state: Optional project state (EMPTY or EXISTING)

    Returns:
        Adaptive prompt string
    """
    # Build context section based on project state
    project_context = _get_project_context(project_state)

    # Build input context based on input type
    input_context = _get_input_context(input_type)

    # ISSUE-HYBRID-021: Removed YAML format instructions since template edit pattern
    # now handles the output format via JSON template files. The old YAML instructions
    # conflicted with the template edit instructions, causing the LLM to output YAML
    # to a JSON template file, which then failed to parse.
    return f"""Expand this objective into a structured intent document.

OBJECTIVE:
{objective}
{input_context}{project_context}
GUIDING PRINCIPLE: Match your response's depth to the task's actual complexity.

Calibration examples:
- "Hello world script" → 1-2 requirements, 1 acceptance criterion, skip risks/non_goals
- "Add user authentication" → Full treatment with security considerations
- "Rename variable" → Minimal: just the requirement and acceptance criterion

Guidelines:
- Keep all fields in the template. Use empty lists when a section adds no value.
- Use [MUST HAVE]/[SHOULD HAVE]/[COULD HAVE] labels only if they improve clarity.
- For trivial tasks, keep it minimal. Brevity beats padding.
- When in doubt, be concise. We can always ask for more detail.
- If the input is a PRD or plan, preserve explicit requirements verbatim.
"""


def _get_project_context(project_state: str | None) -> str:
    """Get project-state-specific context for the prompt.

    Args:
        project_state: EMPTY, EXISTING, or None

    Returns:
        Context string to append to prompt
    """
    if project_state == "EMPTY":
        return """
PROJECT CONTEXT: This is a new/minimal project.
If relevant, you may propose foundational technology choices (framework, database, key libraries).
"""
    if project_state == "EXISTING":
        return """
PROJECT CONTEXT: This is an existing codebase.
If relevant, you may note questions that need investigation before implementation.
"""
    return ""


def _get_input_context(input_type: InputType) -> str:
    """Get input-type-specific context for the prompt.

    Args:
        input_type: The classified input type

    Returns:
        Context string to prepend to prompt
    """
    if input_type == InputType.PRD:
        return """
INPUT TYPE: Product Requirements Document
Preserve explicit requirements, acceptance criteria, and constraints verbatim.
"""
    if input_type == InputType.PROSE_PLAN:
        return """
INPUT TYPE: Implementation plan document
Extract WHAT outcomes are needed, not HOW to implement them.
"""
    if input_type == InputType.STRUCTURED_PLAN:
        return """
INPUT TYPE: Structured MACHINE_PLAN (JSON/YAML)
Synthesize intent from the plan structure. Preserve explicit fields verbatim.
"""
    # VAGUE_NL and RICH_NL don't need special context
    return ""


def _get_optional_json_sections(project_state: str | None) -> str:
    """Get optional JSON sections based on project state.

    Args:
        project_state: EMPTY, EXISTING, or None

    Returns:
        Optional JSON section string
    """
    if project_state == "EMPTY":
        return """\"foundation_proposals\": [\"Proposed technology choice with brief rationale\"]"""
    if project_state == "EXISTING":
        return """\"derivation_questions\": [\"Question to investigate before implementation\"]"""
    return ""


def build_project_classification_prompt(files: list) -> str:
    """Build prompt for LLM-based project state classification.

    Generates a prompt with file listing that asks the LLM to classify
    the project as EMPTY or EXISTING based on the presence of substantial
    implementation code.

    Note: This prompt is used with TemplateEditPipeline which handles output
    format via JSON template files. Format instructions removed per ISSUE-HYBRID-021.

    Args:
        files: List of meaningful files in project (relative paths)

    Returns:
        Formatted prompt string for classification task

    Example:
        >>> from pathlib import Path
        >>> files = [Path("README.md"), Path("src/main.py")]
        >>> prompt = build_project_classification_prompt(files)
        >>> "EMPTY" in prompt
        True
        >>> "EXISTING" in prompt
        True
    """
    file_listing = "\n".join(f"  - {f}" for f in sorted(files))

    # ISSUE-HYBRID-021: Removed JSON format instructions since this prompt is used
    # with TemplateEditPipeline which handles output format via JSON template files.
    # The old "Respond with JSON only" instruction conflicted with template edit
    # instructions, causing parse failures.
    return f"""Analyze this project's file structure to determine if it's a new/minimal project (EMPTY) or an established codebase (EXISTING).

Project has {len(files)} files:
{file_listing}

Classification Definitions:

EMPTY: New or minimal project with:
- Only documentation/config files (README, .gitignore, package.json, etc.)
- Minimal starter code or scaffolding
- No substantial implementation yet
- Examples: Fresh repo, starter template, initial setup

EXISTING: Established project with:
- Substantial implementation code
- Multiple modules/components
- Clear project structure with implementation
- Examples: Working application, library with features, active codebase

Classify this project based on the file listing above."""


__all__ = ["build_intent_generation_prompt", "build_project_classification_prompt"]
