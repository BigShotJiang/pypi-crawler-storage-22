"""Prompt builders for scaffolded intent enrichment stages."""

from __future__ import annotations

from collections.abc import Iterable


def build_assumptions_prompt(
    objective: str,
    intent_markdown: str,
    non_inferable_categories: Iterable[str],
    *,
    unresolved_questions: Iterable[str] | None = None,
    non_inferable_questions: Iterable[str] | None = None,
    proceed_override: bool = False,
) -> str:
    """Build prompt for assumptions + question generation."""
    categories = ", ".join(non_inferable_categories)
    prior_questions = "\n".join(f"- {q}" for q in (unresolved_questions or []))
    prior_non_inferable = "\n".join(f"- {q}" for q in (non_inferable_questions or []))
    prior_section = ""
    if prior_questions or prior_non_inferable:
        prior_section = "\nPreviously asked questions (do not repeat):\n"
        if prior_questions:
            prior_section += f"{prior_questions}\n"
        if prior_non_inferable:
            prior_section += f"{prior_non_inferable}\n"
    override_section = ""
    if proceed_override:
        override_section = (
            "\nProceed override is set. Do not ask new questions. "
            "Return empty lists for questions and non_inferable_questions.\n"
        )
    return f"""You are refining a user intent before planning.

Objective:
"{objective}"

Current intent:
{intent_markdown}
{prior_section}{override_section}

Task:
1) Identify missing context or assumptions required to plan successfully.
2) Generate explicit questions for gaps that CANNOT be safely inferred.
3) Keep answers intent-level (requirements/constraints), not implementation details.

Non-inferable categories (ASK if these are missing or ambiguous):
- {categories}

IMPORTANT - Question Generation Rules:
- For VAGUE objectives (short, underspecified): You MUST ask 1-3 clarifying questions.
  A vague objective lacks specific requirements, constraints, or acceptance criteria.
- For RICH objectives (detailed specs): Questions are optional, only for true ambiguities.
- When in doubt, ASK. Wrong assumptions waste more time than asking.

Lean guidance:
- Focus on minimum viable scope.
- Do not add speculative features or future-proofing.
- Keep questions few, high-impact, and answerable in one sentence.
- Ask for acceptance criteria or constraints when missing.
- Do not repeat prior questions.
- You may ask user questions via the questions list, but NEVER run interactive shell commands.

Quality check:
- Set ready_to_proceed: false if the objective is vague and you have questions.
- Set ready_to_proceed: true only if you have enough context to plan confidently.

Output format (JSON only, no prose):
```json
{{
  "assumptions_add": ["Assumption to add"],
  "questions": ["General clarification question"],
  "non_inferable_questions": ["Question that must be answered by the user"],
  "quality_signal": {{
    "ready_to_proceed": true,
    "missing_sections": ["requirements", "constraints", "acceptance_criteria"]
  }},
  "rationale": "Short rationale"
}}
```
"""


def build_expert_alignment_prompt(
    objective: str,
    intent_markdown: str,
    analogue_cache: str | None = None,
) -> str:
    cache_section = ""
    if analogue_cache:
        cache_section = f"\nAnalogue cache (use only if relevant):\n{analogue_cache}\n"

    return f"""You are performing expert-aligned intent enrichment.

Objective:
"{objective}"

Current intent:
{intent_markdown}
{cache_section}

Task:
1) Infer domain(s) and expert roles (include top 2 if ambiguous).
2) Describe how experts in those domains approach similar problems.
3) Compare current intent to expert approach and identify gaps.
4) Propose intent-level updates only (requirements, constraints, non-goals, risks, acceptance criteria, assumptions).

Lean expert guidance:
- Focus on minimum viable steps.
- Do NOT add speculative features, future-proofing, or extra abstractions.
- Prefer reversible, incremental scope.
- Flag scope creep explicitly.

Output format (JSON only, no prose):
```json
{{
  "domain_inference": [
    {{
      "domain": "example",
      "confidence": 0.72,
      "expert_roles": ["Expert role"]
    }}
  ],
  "expert_approach": ["Approach bullet"],
  "intent_gaps": ["Gap bullet"],
  "proposed_intent_updates": {{
    "assumptions_add": ["Assumption"],
    "requirements_add": ["Requirement"],
    "constraints_add": ["Constraint"],
    "non_goals_add": ["Non-goal"],
    "risks_add": ["Risk"],
    "acceptance_criteria_add": ["Acceptance criterion"]
  }},
  "rationale": "Short rationale"
}}
```
"""


def build_brief_prompt(objective: str, intent_markdown: str) -> str:
    return f"""You are consolidating an updated intent after expert alignment.

Objective:
"{objective}"

Current intent:
{intent_markdown}

Task:
- Produce a cleaned, consolidated intent with the same sections.
- Keep it lean and scoped to the objective.
- Do NOT add speculative features or implementation details.

Output format (JSON only, no prose):
```json
{{
  "problem_statement": "...",
  "assumptions": ["..."],
  "requirements": ["..."],
  "constraints": ["..."],
  "acceptance_criteria": ["..."],
  "non_goals": ["..."],
  "risks": ["..."]
}}
```
"""


def build_review_prompt(
    objective: str,
    intent_markdown: str,
    story_json: str,
    tasks_json: str,
) -> str:
    """Build a story-level review prompt.

    Reviews a single story and its tasks for correctness and completeness.
    Designed for one-pass, parsimonious evaluation.
    """
    return f"""Review this story for correctness and completeness.

## Context

Objective: "{objective}"

Intent:
{intent_markdown}

## Story to Review

{story_json}

## Tasks for This Story

{tasks_json}

## Evaluate

1. Are tasks sufficient to complete the story's acceptance criteria?
2. Any over-engineering, unnecessary abstraction, or scope drift?
3. Any missing tasks required to complete the story?
4. Do tasks have clear, actionable descriptions?

## Guidelines

- Favor minimal viable scope
- Do NOT add speculative features or extra abstractions
- Each task should be atomic and directly serve the story

## Output

Edit the template file to record your review:
- changes_required: true if any issues found, false if story is sound
- issues: list each issue concisely (empty array if none)
- tasks: corrected task array if changes needed (omit or [] if no changes)

### Task Schema (REQUIRED when tasks are provided)
Each task MUST be a full task object with:
- id: "E#.S#.T#"
- item_type: "task"
- title: string
- description: string
- acceptance_criteria: array of strings (can be empty)
- dependencies: array of item IDs (can be empty)
- parent_id: MUST equal the story id under review

Rules:
- Do NOT return partial task objects (no missing fields)
- Do NOT invent epic/story IDs; use the story id provided
- If you cannot produce valid tasks, set changes_required=false and tasks=[]

You MUST edit the file to record your conclusion.
"""
