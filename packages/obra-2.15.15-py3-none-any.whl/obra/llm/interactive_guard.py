"""Interactive output detection for LLM subprocess runs."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Pattern

INTERACTIVE_GUARD_ERROR_CODE = "LLM_INTERACTIVE_BLOCKED"


@dataclass(frozen=True)
class InteractiveMatch:
    """Structured match for interactive prompt detection."""

    pattern_id: str
    line: str
    source: str


@dataclass(frozen=True)
class InteractivePattern:
    """Pattern definition for interactive prompt detection."""

    pattern_id: str
    regex: Pattern[str]


@dataclass(frozen=True)
class InteractiveGuardFailure:
    """Structured failure data for interactive guard triggers."""

    code: str
    pattern_id: str | None
    line: str | None
    source: str | None

    @classmethod
    def from_match(cls, match: InteractiveMatch) -> "InteractiveGuardFailure":
        return cls(
            code=INTERACTIVE_GUARD_ERROR_CODE,
            pattern_id=match.pattern_id,
            line=match.line,
            source=match.source,
        )

    @classmethod
    def from_error_message(
        cls,
        error_message: str,
        *,
        code: str = INTERACTIVE_GUARD_ERROR_CODE,
    ) -> "InteractiveGuardFailure | None":
        if not error_message.startswith(code):
            return None
        remainder = error_message[len(code):].lstrip(": ").strip()
        if not remainder:
            return cls(code=code, pattern_id=None, line=None, source=None)
        parts = remainder.split(":", 1)
        if len(parts) == 2:
            return cls(
                code=code,
                pattern_id=parts[0].strip() or None,
                line=parts[1].strip() or None,
                source=None,
            )
        return cls(code=code, pattern_id=None, line=remainder.strip(), source=None)


@dataclass(frozen=True)
class SanitizedInteractiveLine:
    """Sanitized output for interactive guard logging."""

    line: str
    redacted: bool
    truncated: bool


def sanitize_interactive_line(
    line: str | None,
    *,
    max_len: int = 160,
) -> SanitizedInteractiveLine | None:
    """Sanitize matched interactive lines for logs and UI."""
    if not line:
        return None
    cleaned = re.sub(r"[\r\n\t]+", " ", line).strip()
    redacted = False
    keywords = ("password", "passphrase", "token", "secret", "api key", "apikey")
    lower = cleaned.lower()
    for keyword in keywords:
        if keyword in lower:
            cleaned = f"{keyword} prompt [redacted]"
            redacted = True
            break
    truncated = False
    if len(cleaned) > max_len:
        cleaned = f"{cleaned[:max_len].rstrip()}…"
        truncated = True
    return SanitizedInteractiveLine(line=cleaned, redacted=redacted, truncated=truncated)


def extract_interactive_failure(
    error_message: str | None,
    match: InteractiveMatch | None,
) -> InteractiveGuardFailure | None:
    """Return interactive guard failure details from match or error message."""
    if match is not None:
        return InteractiveGuardFailure.from_match(match)
    if error_message:
        return InteractiveGuardFailure.from_error_message(error_message)
    return None


class InteractiveGuard:
    """Scan stdout/stderr for interactive prompt patterns."""

    def __init__(self, patterns: list[InteractivePattern]) -> None:
        self._patterns = patterns

    @classmethod
    def from_patterns(cls, patterns: list[str]) -> InteractiveGuard:
        """Build guard from regex strings with deterministic pattern IDs."""
        compiled: list[InteractivePattern] = []
        for idx, pattern in enumerate(patterns, start=1):
            regex = re.compile(pattern, re.IGNORECASE)
            compiled.append(InteractivePattern(pattern_id=f"pattern_{idx}", regex=regex))
        return cls(compiled)

    def scan_line(self, line: str, source: str) -> InteractiveMatch | None:
        """Scan a single line for interactive prompts."""
        for pattern in self._patterns:
            if pattern.regex.search(line):
                return InteractiveMatch(
                    pattern_id=pattern.pattern_id,
                    line=line.rstrip("\n"),
                    source=source,
                )
        return None

    def scan_output(self, stdout: str, stderr: str) -> InteractiveMatch | None:
        """Scan stdout then stderr for interactive prompt patterns."""
        for line in stdout.splitlines():
            match = self.scan_line(line, "stdout")
            if match:
                return match
        for line in stderr.splitlines():
            match = self.scan_line(line, "stderr")
            if match:
                return match
        return None
