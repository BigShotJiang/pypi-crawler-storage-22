"""Observability module for production event logging.

This module provides structured event logging for production observability,
supporting the derivation pipeline, quality assessment, and complexity estimation.

Architecture:
    - ProductionLogger: Main logger with JSON Lines output and file rotation
    - EventTypes: Constants for all supported event types
    - Uses session_id and work_unit_id for event correlation

Related:
    - docs/design/prds/USERPLAN_DOBRA_ENHANCEMENTS_PRD.md (FR-14 through FR-17)
    - obra/hybrid/handlers/derive.py (integration point)
    - obra/hybrid/quality/clarification.py (integration point)
"""

from obra.observability.production_logger import (
    EventTypes,
    ProductionLogger,
    get_production_logger,
)

__all__ = [
    "EventTypes",
    "ProductionLogger",
    "get_production_logger",
]
