"""Pydantic schemas for complexity estimation.

This module provides schemas for complexity estimation and decomposition
suggestions. Used by the ComplexityEstimator to evaluate task complexity
and suggest when tasks should be broken down.

Architecture:
    - ComplexityEstimate: Result of complexity analysis for a task
    - DecompositionSuggestion: Suggested subtask when decomposition is recommended

Related:
    - docs/design/prds/USERPLAN_DOBRA_ENHANCEMENTS_PRD.md (FR-5 through FR-8)
    - config/complexity_heuristics.yaml (text analysis patterns)
    - config/complexity_thresholds.yaml (decomposition thresholds)
    - obra/hybrid/derivation/complexity_estimator.py (uses these schemas)
"""

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator


class DecompositionSuggestion(BaseModel):
    """Schema for a suggested subtask when decomposition is recommended.

    When a task is flagged for decomposition, this schema represents
    one suggested subtask that the original task could be broken into.

    Attributes:
        title: Short title for the suggested subtask
        description: Detailed description of what this subtask should accomplish
        estimated_complexity: Predicted complexity score for this subtask (0-100)
        dependencies: List of other suggested subtask indices this depends on
        rationale: Why this subtask was identified as a logical unit

    Example:
        >>> suggestion = DecompositionSuggestion(
        ...     title="Create database schema",
        ...     description="Define SQLAlchemy models for the user entity",
        ...     estimated_complexity=25.0,
        ...     dependencies=[],
        ...     rationale="Database layer is independent and should be done first"
        ... )
    """

    title: str = Field(
        ...,
        min_length=1,
        description="Short title for the suggested subtask",
    )
    description: str = Field(
        ...,
        min_length=1,
        description="Detailed description of what this subtask should accomplish",
    )
    estimated_complexity: float = Field(
        default=30.0,
        ge=0.0,
        le=100.0,
        description="Predicted complexity score for this subtask (0-100)",
    )
    dependencies: list[int] = Field(
        default_factory=list,
        description="Indices of other suggested subtasks this depends on",
    )
    rationale: str | None = Field(
        default=None,
        description="Why this subtask was identified as a logical unit",
    )

    model_config = ConfigDict(extra="forbid")


class ComplexityEstimate(BaseModel):
    """Schema for complexity estimation result.

    ComplexityEstimate represents the result of analyzing a task's
    complexity using heuristic and/or LLM-based analysis. It provides
    a complexity score and decomposition suggestions when appropriate.

    Ported from Dobra's orchestration/complexity_estimate.py pattern.

    Attributes:
        task_id: Identifier for the task being analyzed
        complexity_score: Overall complexity score (0-100 scale)
        estimated_tokens: Estimated tokens needed for implementation
        estimated_loc: Estimated lines of code for implementation
        estimated_files: Estimated number of files to modify
        obra_suggests_decomposition: True if Obra recommends breaking down this task
        obra_suggestion_confidence: Confidence in the decomposition suggestion (0.0-1.0)
        suggested_subtasks: List of suggested subtasks if decomposition recommended
        suggestion_rationale: Explanation for why decomposition is suggested
        heuristic_breakdown: Breakdown of score by heuristic category (for debugging)
        analysis_method: Method used for estimation ("heuristic" or "llm")

    Example:
        >>> estimate = ComplexityEstimate(
        ...     task_id="T1",
        ...     complexity_score=75.0,
        ...     estimated_tokens=4000,
        ...     estimated_loc=200,
        ...     estimated_files=3,
        ...     obra_suggests_decomposition=True,
        ...     obra_suggestion_confidence=0.85,
        ...     suggested_subtasks=[subtask1, subtask2],
        ...     suggestion_rationale="Task involves multiple independent components"
        ... )
    """

    task_id: str = Field(
        ...,
        description="Identifier for the task being analyzed",
    )
    complexity_score: float = Field(
        ...,
        ge=0.0,
        le=100.0,
        description="Overall complexity score (0-100 scale)",
    )
    estimated_tokens: int = Field(
        default=0,
        ge=0,
        description="Estimated tokens needed for implementation",
    )
    estimated_loc: int = Field(
        default=0,
        ge=0,
        description="Estimated lines of code for implementation",
    )
    estimated_files: int = Field(
        default=1,
        ge=1,
        description="Estimated number of files to modify",
    )
    obra_suggests_decomposition: bool = Field(
        default=False,
        description="True if Obra recommends breaking down this task",
    )
    obra_suggestion_confidence: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
        description="Confidence in the decomposition suggestion (0.0-1.0)",
    )
    suggested_subtasks: list[DecompositionSuggestion] = Field(
        default_factory=list,
        description="List of suggested subtasks if decomposition recommended",
    )
    suggestion_rationale: str | None = Field(
        default=None,
        description="Explanation for why decomposition is suggested",
    )
    heuristic_breakdown: dict[str, Any] = Field(
        default_factory=dict,
        description="Breakdown of score by heuristic category (for debugging)",
    )
    analysis_method: str = Field(
        default="heuristic",
        description="Method used for estimation ('heuristic' or 'llm')",
    )

    model_config = ConfigDict(extra="allow")

    @field_validator("complexity_score")
    @classmethod
    def validate_complexity_score(cls, v: float) -> float:
        """Ensure complexity score is within valid range and rounded."""
        return round(v, 1)

    @field_validator("obra_suggestion_confidence")
    @classmethod
    def validate_confidence(cls, v: float) -> float:
        """Ensure confidence is within valid range and rounded."""
        return round(v, 2)


# Convenience exports
__all__ = [
    "ComplexityEstimate",
    "DecompositionSuggestion",
]
