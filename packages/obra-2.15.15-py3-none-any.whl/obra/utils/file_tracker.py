"""Git-independent file state tracking for Obra.

This module provides file change detection without requiring git. It uses
file hashes and modification times to track changes, respecting Obra's
own IGNORE_DIRS patterns.

ISSUE-REVIEW-AGENTS-002: Replaces brittle git dependency with native tracking.

Usage:
    tracker = FileStateTracker(working_dir)

    # Snapshot before operation
    before = tracker.snapshot()

    # ... do work ...

    # Detect changes
    changes = tracker.diff(before)
    print(f"Modified: {changes.modified}")
    print(f"Added: {changes.added}")
    print(f"Deleted: {changes.deleted}")
"""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterator

logger = logging.getLogger(__name__)

# Directories to ignore when scanning (mirrors BaseAgent.IGNORE_DIRS)
# Centralized here to avoid import cycles with agents module
IGNORE_DIRS: frozenset[str] = frozenset({
    ".git",
    ".obra",
    "__pycache__",
    "node_modules",
    ".venv",
    "venv",
    ".tox",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".coverage",
    "dist",
    "build",
    "eggs",
    ".eggs",
    "site-packages",
    ".nox",
    ".cache",
    "htmlcov",
    ".next",
    ".nuxt",
    ".output",
    ".svelte-kit",
    ".vercel",
    ".turbo",
})

# Directory suffixes to ignore
IGNORE_DIR_SUFFIXES: tuple[str, ...] = (".egg-info",)

# Binary extensions to skip (no point hashing these for change detection)
BINARY_EXTENSIONS: frozenset[str] = frozenset({
    ".pyc", ".pyo", ".pyd", ".egg", ".whl",
    ".exe", ".dll", ".so", ".dylib", ".o", ".a", ".lib",
    ".tar", ".gz", ".zip", ".rar", ".7z", ".bz2", ".xz",
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg", ".webp",
    ".mp3", ".mp4", ".wav", ".avi", ".mov",
    ".pdf", ".doc", ".docx", ".xls", ".xlsx",
    ".ttf", ".otf", ".woff", ".woff2", ".eot",
    ".db", ".sqlite", ".sqlite3",
})

# Max file size to hash (skip huge files)
MAX_FILE_SIZE_BYTES: int = 10 * 1024 * 1024  # 10MB


@dataclass(frozen=True)
class FileState:
    """State of a single file at a point in time."""

    path: str  # Relative path from working_dir
    mtime: float  # Modification time
    size: int  # File size in bytes
    content_hash: str | None = None  # SHA256 hash (None for large/binary files)


@dataclass
class FileSnapshot:
    """Snapshot of all tracked files at a point in time."""

    working_dir: Path
    files: dict[str, FileState] = field(default_factory=dict)

    def __len__(self) -> int:
        return len(self.files)


@dataclass
class FileChanges:
    """Result of comparing two snapshots."""

    added: list[str] = field(default_factory=list)  # New files
    modified: list[str] = field(default_factory=list)  # Changed files
    deleted: list[str] = field(default_factory=list)  # Removed files

    @property
    def total_changed(self) -> int:
        """Total number of changed files."""
        return len(self.added) + len(self.modified) + len(self.deleted)

    @property
    def all_changed_files(self) -> list[str]:
        """All files that changed (added + modified)."""
        return self.added + self.modified

    def __bool__(self) -> bool:
        """True if any changes detected."""
        return self.total_changed > 0


class FileStateTracker:
    """Track file state changes without git dependency.

    Uses file hashes and modification times to detect changes.
    Respects IGNORE_DIRS patterns for filtering.

    Example:
        >>> tracker = FileStateTracker(Path("/my/project"))
        >>> before = tracker.snapshot()
        >>> # ... make changes ...
        >>> changes = tracker.diff(before)
        >>> print(f"Files changed: {changes.total_changed}")
    """

    def __init__(self, working_dir: Path) -> None:
        """Initialize tracker for a working directory.

        Args:
            working_dir: Root directory to track
        """
        self._working_dir = working_dir.resolve()

    def snapshot(self) -> FileSnapshot:
        """Create a snapshot of current file states.

        Scans all files in working_dir, respecting IGNORE_DIRS.

        Returns:
            FileSnapshot with current state of all tracked files
        """
        snapshot = FileSnapshot(working_dir=self._working_dir)

        for file_path in self._iter_files():
            try:
                state = self._get_file_state(file_path)
                if state:
                    snapshot.files[state.path] = state
            except OSError as e:
                logger.debug(f"Could not stat file {file_path}: {e}")

        logger.debug(f"Snapshot captured: {len(snapshot)} files in {self._working_dir}")
        return snapshot

    def diff(self, before: FileSnapshot) -> FileChanges:
        """Compare current state against a previous snapshot.

        Args:
            before: Previous snapshot to compare against

        Returns:
            FileChanges with added, modified, and deleted files
        """
        after = self.snapshot()
        changes = FileChanges()

        before_paths = set(before.files.keys())
        after_paths = set(after.files.keys())

        # Deleted files
        for path in before_paths - after_paths:
            changes.deleted.append(path)

        # Added files
        for path in after_paths - before_paths:
            changes.added.append(path)

        # Modified files (exist in both, check for changes)
        for path in before_paths & after_paths:
            before_state = before.files[path]
            after_state = after.files[path]

            if self._file_changed(before_state, after_state):
                changes.modified.append(path)

        # Sort for deterministic output
        changes.added.sort()
        changes.modified.sort()
        changes.deleted.sort()

        logger.debug(
            f"Diff result: {len(changes.added)} added, "
            f"{len(changes.modified)} modified, {len(changes.deleted)} deleted"
        )
        return changes

    def get_all_files(self) -> list[str]:
        """Get all tracked files (relative paths).

        Useful when you need to analyze all files without a baseline.

        Returns:
            List of relative file paths
        """
        return [
            str(p.relative_to(self._working_dir))
            for p in self._iter_files()
        ]

    def count_lines(self, files: list[str] | None = None) -> int:
        """Count total lines in specified files.

        Args:
            files: List of relative paths. If None, counts all files.

        Returns:
            Total line count
        """
        total = 0
        paths = files if files else self.get_all_files()

        for rel_path in paths:
            file_path = self._working_dir / rel_path
            try:
                if file_path.exists() and file_path.is_file():
                    if file_path.suffix.lower() not in BINARY_EXTENSIONS:
                        content = file_path.read_text(encoding="utf-8", errors="ignore")
                        total += len(content.splitlines())
            except OSError:
                pass

        return total

    def _iter_files(self) -> Iterator[Path]:
        """Iterate over all trackable files in working_dir.

        Yields:
            Path objects for each file (excludes ignored dirs and binary files)
        """
        for path in self._working_dir.rglob("*"):
            if not path.is_file():
                continue

            if self._should_ignore(path):
                continue

            yield path

    def _should_ignore(self, path: Path) -> bool:
        """Check if a path should be ignored.

        Args:
            path: Absolute path to check

        Returns:
            True if path should be ignored
        """
        try:
            rel_path = path.relative_to(self._working_dir)
        except ValueError:
            return True  # Outside working dir

        # Check directory components
        for part in rel_path.parts[:-1]:  # Exclude filename
            if part in IGNORE_DIRS:
                return True
            if part.endswith(IGNORE_DIR_SUFFIXES):
                return True

        # Check file extension
        if path.suffix.lower() in BINARY_EXTENSIONS:
            return True

        return False

    def _get_file_state(self, path: Path) -> FileState | None:
        """Get state for a single file.

        Args:
            path: Absolute path to file

        Returns:
            FileState or None if file cannot be read
        """
        try:
            stat = path.stat()
            rel_path = str(path.relative_to(self._working_dir))

            # Skip huge files
            if stat.st_size > MAX_FILE_SIZE_BYTES:
                return FileState(
                    path=rel_path,
                    mtime=stat.st_mtime,
                    size=stat.st_size,
                    content_hash=None,
                )

            # Compute hash for smaller files
            content_hash = self._hash_file(path)

            return FileState(
                path=rel_path,
                mtime=stat.st_mtime,
                size=stat.st_size,
                content_hash=content_hash,
            )
        except OSError:
            return None

    def _hash_file(self, path: Path) -> str | None:
        """Compute SHA256 hash of file contents.

        Args:
            path: Path to file

        Returns:
            Hex digest or None on error
        """
        try:
            hasher = hashlib.sha256()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(8192), b""):
                    hasher.update(chunk)
            return hasher.hexdigest()
        except OSError:
            return None

    def _file_changed(self, before: FileState, after: FileState) -> bool:
        """Check if a file changed between states.

        Uses hash if available, falls back to mtime + size.

        Args:
            before: Previous state
            after: Current state

        Returns:
            True if file appears changed
        """
        # If we have hashes, use them (most reliable)
        if before.content_hash and after.content_hash:
            return before.content_hash != after.content_hash

        # Fall back to mtime + size
        return before.mtime != after.mtime or before.size != after.size


__all__ = [
    "FileChanges",
    "FileSnapshot",
    "FileState",
    "FileStateTracker",
    "IGNORE_DIRS",
    "IGNORE_DIR_SUFFIXES",
    "BINARY_EXTENSIONS",
]
