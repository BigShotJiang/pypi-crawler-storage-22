"""Obra home directory management utilities.

Handles initialization and documentation of the ~/.obra/ directory structure.
"""

from dataclasses import dataclass
from datetime import datetime
import os
from pathlib import Path


def get_obra_home() -> Path:
    """Get the Obra home directory path (~/.obra/)."""
    return Path.home() / ".obra"


@dataclass(frozen=True)
class RuntimeDirSelection:
    """Resolved runtime directory selection."""

    path: Path
    source: str
    is_legacy: bool


def resolve_runtime_dir() -> RuntimeDirSelection:
    """Resolve the runtime directory with env override and legacy fallback."""
    env_value = os.environ.get("OBRA_RUNTIME_DIR")
    if env_value and env_value.strip():
        path = Path(env_value).expanduser()
        is_legacy = path == Path.home() / "obra-runtime"
        selection = RuntimeDirSelection(path=path, source="env", is_legacy=is_legacy)
        _ensure_runtime_dir(selection.path)
        return selection

    canonical = Path.home() / ".obra-runtime"
    legacy = Path.home() / "obra-runtime"

    if canonical.exists() and legacy.exists():
        selection = RuntimeDirSelection(path=canonical, source="canonical", is_legacy=False)
    elif legacy.exists() and not canonical.exists():
        selection = RuntimeDirSelection(path=legacy, source="legacy", is_legacy=True)
    else:
        selection = RuntimeDirSelection(path=canonical, source="canonical", is_legacy=False)

    _ensure_runtime_dir(selection.path)
    return selection


def _ensure_runtime_dir(path: Path) -> None:
    try:
        path.mkdir(parents=True, exist_ok=True, mode=0o700)
    except OSError as exc:
        raise RuntimeError(f"Failed to create runtime directory: {path}") from exc


def get_runtime_dir() -> Path:
    """Get the resolved Obra runtime directory path."""
    return resolve_runtime_dir().path


def legacy_notice_needed(selection: RuntimeDirSelection) -> bool:
    """Return True when legacy runtime path notice should be shown."""
    if not selection.is_legacy:
        return False
    return not (selection.path / ".legacy_runtime_notice_shown").exists()


def mark_legacy_notice_shown(selection: RuntimeDirSelection) -> None:
    """Persist legacy runtime notice marker to avoid repeated notices."""
    marker_path = selection.path / ".legacy_runtime_notice_shown"
    try:
        marker_path.write_text(
            f"shown_at={datetime.now().isoformat()}\n",
            encoding="utf-8",
        )
    except OSError:
        # Best-effort marker; notice suppression shouldn't break runtime.
        pass


def get_obra_runtime() -> Path:
    """Get the Obra runtime directory path."""
    return get_runtime_dir()


def ensure_obra_home_readme() -> Path:
    """Ensure README.md exists in ~/.obra/ with current paths.

    Creates or updates the README with actual paths specific to this environment.
    This helps users find logs, config, and other Obra files.

    Returns:
        Path to the README.md file
    """
    obra_home = get_obra_home()
    obra_runtime = get_runtime_dir()
    readme_path = obra_home / "README.md"

    # Ensure directory exists
    obra_home.mkdir(parents=True, exist_ok=True)

    # Generate README with actual paths
    # pylint: disable=line-too-long
    content = f"""# Obra Home Directory

This directory contains Obra configuration, logs, and session data.

**Generated**: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

## Directory Structure

### Logs (for monitoring Obra sessions)

| Log File | Path | Description |
|----------|------|-------------|
| **hybrid.jsonl** | `{obra_runtime / "logs" / "hybrid.jsonl"}` | Orchestration events: phases, tasks, LLM calls |
| **production.jsonl** | `{obra_runtime / "logs" / "production.jsonl"}` | Detailed metrics: derivation, quality, complexity |
| **Session logs** | `{obra_runtime / "logs" / "sessions"}/` | Per-session detailed logs |

### Configuration

| File | Path | Description |
|------|------|-------------|
| **User config** | `{obra_home / "config-layers" / "01-user.yaml"}` | Your personal settings |
| **Legacy config** | `{obra_home / "client-config.yaml"}` | Legacy config (deprecated) |

### Data

| Directory | Path | Description |
|-----------|------|-------------|
| **Intents** | `{obra_home / "intents"}/` | Saved user intents |
| **Feedback** | `{obra_home / "feedback"}/` | Bug reports and feedback drafts |
| **Memory** | `{obra_home / "memory"}/` | Session memory and activity logs |

## Monitoring Commands

### Watch logs in real-time
```bash
# Orchestration events (phases, tasks, LLM calls)
tail -f "{obra_runtime / "logs" / "hybrid.jsonl"}" | jq .

# Detailed metrics (derivation, quality, complexity)
tail -f "{obra_runtime / "logs" / "production.jsonl"}" | jq .

# Both logs side-by-side (requires tmux or two terminals)
tail -f "{obra_runtime / "logs" / "hybrid.jsonl"}"
```

### Use the monitoring skill (in Claude Code)
```
/monitor-obra
```

### Check recent activity
```bash
# Last 10 orchestration events
tail -n 10 "{obra_runtime / "logs" / "hybrid.jsonl"}" | jq .

# Last 10 derivation/quality metrics
tail -n 10 "{obra_runtime / "logs" / "production.jsonl"}" | jq .

# Filter by event type
grep '"event_type":"phase_' "{obra_runtime / "logs" / "hybrid.jsonl"}" | tail -5 | jq .
grep '"event_type":"derivation_' "{obra_runtime / "logs" / "production.jsonl"}" | tail -5 | jq .
```

## Verbosity Levels

When running Obra, use these flags for more output:

| Flag | Level | Output |
|------|-------|--------|
| (none) | 0 | Minimal - errors and results only |
| `-v` | 1 | Basic - phase transitions |
| `-vv` | 2 | Detailed - LLM prompts/responses |
| `-vvv` | 3 | Debug - full traces |
| `--stream` | - | Real-time LLM output |

Example: `obra run "your task" --stream -vv`

## Cleanup

To reset Obra configuration:
```bash
# Remove all config (keeps logs)
rm -rf "{obra_home / "config-layers"}"

# Remove everything (full reset)
rm -rf "{obra_home}"
```

---
*This file is auto-generated by Obra. Edit at your own risk.*
"""
    # pylint: enable=line-too-long

    # Write the README
    readme_path.write_text(content)
    return readme_path


def ensure_obra_directories() -> dict[str, Path]:
    """Ensure all Obra directories exist and return their paths.

    Returns:
        Dict mapping directory names to their paths
    """
    obra_home = get_obra_home()
    obra_runtime = get_runtime_dir()

    directories = {
        "home": obra_home,
        "runtime": obra_runtime,
        "logs": obra_home / "logs",
        "runtime_logs": obra_runtime / "logs",
        "config": obra_home / "config-layers",
        "intents": obra_home / "intents",
        "feedback": obra_home / "feedback",
        "memory": obra_home / "memory",
    }

    for path in directories.values():
        path.mkdir(parents=True, exist_ok=True)

    # Also ensure README exists
    ensure_obra_home_readme()

    return directories
