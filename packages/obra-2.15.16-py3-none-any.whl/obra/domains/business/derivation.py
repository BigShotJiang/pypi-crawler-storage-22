"""Derivation keywords for business domain.

These definitions are used for work type detection and task sizing guidance
in business workflow automation.

Related:
    - obra/domains/interface.py (DomainModule protocol)
"""

from obra.domains.business.prompts.sizing import (
    SIZING_GUIDANCE as DOMAIN_SIZING_GUIDANCE,
)

# Keywords for detecting work types from objective text
WORK_TYPE_KEYWORDS: dict[str, list[str]] = {
    "document_processing": ["process", "document", "extract", "parse", "transform"],
    "approval_workflow": ["approve", "review", "sign-off", "authorization", "escalate"],
    "data_validation": ["validate", "verify", "check", "audit", "reconcile"],
    "report_generation": ["report", "generate", "summarize", "aggregate", "compile"],
    "compliance_review": ["compliance", "regulatory", "policy", "audit", "requirement"],
}

SIZING_GUIDANCE = DOMAIN_SIZING_GUIDANCE

# Valid business workflow phases
VALID_PHASES = ["gather", "validate", "process", "deliver"]
