"""Revision prompts extracted from obra/execution/revision.py.

This module contains prompt templates and builder functions for the
revision engine, enabling iterative improvement of implementation plans.

Related:
    - obra/execution/revision.py (RevisionEngine)
    - REFACTOR-PROMPT-LIBRARY-001

Prompts:
    - build_revision_prompt: Revision prompt builder
"""

__all__ = [
    "build_revision_prompt",
]


def build_revision_prompt(
    objective: str,
    iteration: int,
    current_plan_json: str,
    issues_section: str,
    blocking_section: str,
) -> str:
    """Build the revision prompt for plan improvement.

    Args:
        objective: The original task objective
        iteration: Current revision iteration number
        current_plan_json: JSON representation of current plan
        issues_section: Formatted issues to address
        blocking_section: Formatted blocking issues (P0/P1)

    Returns:
        Formatted revision prompt string
    """
    return f"""You are an expert software architect revising an implementation plan.
Your job is to address identified issues while preserving what works well.

## Original Objective
{objective}

## Current Plan (Version {iteration})
```json
{current_plan_json}
```

## Issues to Address
{issues_section}
{blocking_section}
## Revision Guidelines

1. **Address all P0 and P1 issues first** - these block implementation
2. **Modify only the tasks that need changes** - keep stable tasks unchanged
3. **Maintain coherence and dependencies** after changes
4. **Preserve task IDs** where possible for traceability
5. **Document what you changed** in the changes_made array

## Output Format

Return a JSON object with:
- revised_plan: Object with plan_items array (same format as input)
- changes_made: Array of change records
- remaining_concerns: Array of issues deferred to future iterations

```json
{{
  "revised_plan": {{
    "plan_items": [
      {{
        "id": "T1",
        "item_type": "task",
        "title": "Updated title",
        "description": "Updated description",
        "acceptance_criteria": ["..."],
        "dependencies": [],
        "work_phase": "implement"
      }}
    ]
  }},
  "changes_made": [
    {{
      "task_ref": "T1",
      "issue_addressed": "P1: Unclear acceptance criteria",
      "change": "Added specific metrics",
      "old_value": "Response should be fast",
      "new_value": "Response time < 200ms"
    }}
  ],
  "remaining_concerns": [
    "P2: Consider adding caching (deferred)"
  ]
}}
```

Return ONLY the JSON object, no additional text.
"""
