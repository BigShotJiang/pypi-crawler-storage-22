"""LLM-based sizing gate for 4-tier objective classification after intent enrichment.

Uses full intent context (requirements, acceptance criteria) for accurate semantic
classification.
"""

# pylint: disable=broad-exception-caught,duplicate-code

from __future__ import annotations

import logging
from inspect import isawaitable
from typing import Any

from obra.hybrid.derivation.mission_complexity import SizeClass, SizingGuidance
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.intent.models import IntentModel

logger = logging.getLogger(__name__)

SIZING_TEMPLATE_SCHEMA = {
    "size_class": "",
    "rationale": "",
    "_instructions": (
        "Classify the objective complexity based on requirements and acceptance criteria.\n\n"
        "Size classes:\n"
        "- TRIVIAL: A quick fix or minor tweak\n"
        "- SIMPLE: A focused, self-contained change\n"
        "- MODERATE: A cohesive feature with clear boundaries\n"
        "- COMPLEX: A cross-cutting change requiring architectural consideration\n\n"
        "Set size_class to exactly one of: TRIVIAL, SIMPLE, MODERATE, COMPLEX\n"
        "Provide brief rationale (under 15 words)."
    ),
}

SIZING_PROMPT_TEMPLATE = (
    "Classify the objective size class based on the problem statement, requirements, "
    "and acceptance criteria.\n\n"
    "Problem Statement:\n{problem_statement}\n\n"
    "Requirements:\n{requirements}\n\n"
    "Acceptance Criteria:\n{acceptance_criteria}\n\n"
    "Examples:\n"
    "- Objective: 'fix typo in README' -> TRIVIAL\n"
    "- Objective: 'add a settings toggle' -> SIMPLE\n"
    "- Objective: 'add REST endpoints for user profiles' -> MODERATE\n"
    "- Objective: 'implement multi-tenant auth across services' -> COMPLEX\n"
)

_TEMPLATE_FALLBACK_STATUSES = {
    "template_fallback",
    "template_error",
    "validation_failed",
}


def get_sizing_llm_config(config: dict[str, Any]) -> dict[str, Any]:
    """Return LLM config for sizing gate assessment."""
    sizing_config = config.get("derivation", {}).get("sizing", {}).get("llm", {})
    model = sizing_config.get("model")
    if model is None:
        model = config.get("llm", {}).get("model")
    return {
        "provider": config.get("llm", {}).get("provider"),
        "model": model,
        "auth": config.get("llm", {}).get("auth", "oauth"),
    }


def assess_size_class_heuristic(intent: IntentModel) -> SizeClass:
    """Fallback heuristic sizing based on intent size."""
    if len(intent.requirements) <= 1 and len(intent.acceptance_criteria) <= 1:
        return SizeClass.SIMPLE
    if len(intent.requirements) <= 3 and len(intent.acceptance_criteria) <= 3:
        return SizeClass.MODERATE
    return SizeClass.COMPLEX


class SizingGate:  # pylint: disable=too-few-public-methods
    """LLM-based sizing gate for objective classification."""

    def __init__(self, config: dict[str, Any]) -> None:
        self._config = config
        self._logger = logging.getLogger(__name__)

    async def assess(  # pylint: disable=too-many-locals
        self,
        intent: IntentModel,
        pipeline: TemplateEditPipeline,
    ) -> SizingGuidance:
        """Assess objective size class from intent using template edit pipeline."""
        requirements = "\n".join(f"- {req}" for req in intent.requirements[:8])
        acceptance = "\n".join(f"- {crit}" for crit in intent.acceptance_criteria[:5])

        prompt = SIZING_PROMPT_TEMPLATE.format(
            problem_statement=intent.problem_statement,
            requirements=requirements or "- (none)",
            acceptance_criteria=acceptance or "- (none)",
        )

        llm_config = get_sizing_llm_config(self._config)
        sizing_llm_config = (
            self._config.get("derivation", {}).get("sizing", {}).get("llm", {})
        )
        timeout_s = sizing_llm_config.get("timeout_s", 30)
        max_retries = sizing_llm_config.get("max_retries", 2)

        def validator(data: dict[str, Any]) -> tuple[bool, str | None]:
            size_class = str(data.get("size_class", "")).upper()
            rationale = str(data.get("rationale", "")).strip()
            if size_class not in {"TRIVIAL", "SIMPLE", "MODERATE", "COMPLEX"}:
                return (
                    False,
                    "size_class must be TRIVIAL, SIMPLE, MODERATE, or COMPLEX",
                )
            if not rationale:
                return (False, "rationale must be provided")
            return (True, None)

        def fallback() -> dict[str, str]:
            fallback_class = assess_size_class_heuristic(intent)
            return {
                "size_class": fallback_class.name,
                "rationale": "heuristic fallback",
            }

        try:
            result = pipeline.execute(
                base_prompt=prompt,
                template_schema=SIZING_TEMPLATE_SCHEMA,
                validator=validator,
                fallback_fn=fallback,
                llm_config=llm_config,
                timeout_s=timeout_s,
                max_retries=max_retries,
            )
            if isawaitable(result):
                result = await result
            data, metadata = result
        except Exception as exc:
            self._logger.warning("Sizing gate LLM failed: %s", exc)
            size_class = assess_size_class_heuristic(intent)
            return self._build_guidance(
                size_class,
                rationale="heuristic fallback",
                method="heuristic",
            )

        status = (metadata or {}).get("status")
        if status in _TEMPLATE_FALLBACK_STATUSES:
            size_class = assess_size_class_heuristic(intent)
            return self._build_guidance(
                size_class,
                rationale="heuristic fallback",
                method="heuristic",
            )

        size_class_value = str(data.get("size_class", "")).upper()
        if size_class_value not in {"TRIVIAL", "SIMPLE", "MODERATE", "COMPLEX"}:
            self._logger.warning("Invalid size_class: %s", size_class_value)
            size_class = assess_size_class_heuristic(intent)
            return self._build_guidance(
                size_class,
                rationale="heuristic fallback",
                method="heuristic",
            )

        size_class = SizeClass[size_class_value]
        rationale = str(data.get("rationale", "")).strip()
        return self._build_guidance(size_class, rationale=rationale, method="llm")

    def _build_guidance(
        self,
        size_class: SizeClass,
        *,
        rationale: str,
        method: str,
    ) -> SizingGuidance:
        guidance_config = (
            self._config.get("derivation", {})
            .get("sizing", {})
            .get("guidance", {})
            .get(size_class.value, {})
        )
        return SizingGuidance(
            size_class=size_class,
            description=str(guidance_config.get("description", "")),
            scope=str(guidance_config.get("scope", "")),
            use_single_shot=bool(guidance_config.get("use_single_shot", False)),
            rationale=rationale,
            method=method,
        )
