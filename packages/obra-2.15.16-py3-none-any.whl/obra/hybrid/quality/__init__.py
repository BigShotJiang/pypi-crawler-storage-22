"""Quality assessment utilities for Obra hybrid orchestration.

This module provides quality assessment tools including:
- Clarification loop: Iterative quality refinement for UserPlans
- Field feedback generator: Structured feedback for specific fields
- Quality delta calculator: Track quality improvement over iterations

Related:
    - obra/hybrid/handlers/derive.py (integrates with quality assessment)
    - docs/design/prds/USERPLAN_DOBRA_ENHANCEMENTS_PRD.md (FR-10 through FR-13c)
"""

from obra.hybrid.quality.clarification import (
    ClarificationLoop,
    FieldFeedbackGenerator,
    QualityDeltaCalculator,
)

__all__ = [
    "ClarificationLoop",
    "FieldFeedbackGenerator",
    "QualityDeltaCalculator",
]
