"""Work type detector for UserPlan and Intent analysis.

This module provides functionality to detect work types from UserPlan or Intent
data by analyzing text content against configurable patterns.

Architecture:
    - WorkTypePatterns: Pydantic model for loading patterns from JSON config
    - WorkTypeDetector: Main detection class
    - detect_work_type: Convenience function for quick detection

Related:
    - obra/config/defaults/work_type_patterns.json (pattern definitions)
    - obra/schemas/userplan_schema.py (UserPlan model)
    - obra/intent/models.py (IntentModel)
"""

import logging
import re
import warnings
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path
from typing import TYPE_CHECKING, Any

import json
import yaml
from pydantic import BaseModel, Field

from obra.intent.models import IntentModel
from obra.schemas.userplan_schema import UserPlan

if TYPE_CHECKING:
    from obra.domains.interface import DomainModule

logger = logging.getLogger(__name__)

# Default fallback work type
DEFAULT_WORK_TYPE = "general"

# Customer override path
CUSTOMER_CONFIG_PATH = Path(".obra/config/work_type_patterns.json")
LEGACY_CUSTOMER_CONFIG_PATH = Path(".obra/config/work_type_patterns.yaml")


class RegexPattern(BaseModel):
    """A regex pattern with description."""

    pattern: str = Field(..., description="Regex pattern string")
    description: str = Field(
        default="", description="Description of what this pattern matches"
    )


class DecompositionGuidance(BaseModel):
    """Guidance for decomposing work into tasks for a specific work type.

    This provides recommended phases, typical task counts, and work-type-specific
    patterns to help break down work into manageable tasks.
    """

    phases: list[str] = Field(
        default_factory=list,
        description="Recommended phases for this work type (e.g., ['explore', 'plan', 'implement', 'commit'])",
    )
    typical_task_count: str = Field(
        default="3-6",
        description="Typical number of tasks for this work type (e.g., '4-8', '2-4')",
    )
    patterns: list[str] = Field(
        default_factory=list,
        description="Work-type-specific patterns or considerations for task breakdown",
    )
    notes: str = Field(
        default="",
        description="Additional notes or guidance for this work type",
    )


class DetectionConfig(BaseModel):
    """Detection configuration for a work type."""

    keywords: list[str] = Field(
        default_factory=list, description="Simple keyword matches"
    )
    phrases: list[str] = Field(
        default_factory=list, description="Multi-word phrase patterns"
    )
    structural_signals: list[dict[str, Any]] = Field(
        default_factory=list, description="Structural signal patterns"
    )
    regex_patterns: list[RegexPattern] = Field(
        default_factory=list, description="Regex patterns for complex matching"
    )


class WorkTypeDefinition(BaseModel):
    """Definition of a single work type with detection patterns."""

    id: str = Field(..., description="Unique identifier (snake_case)")
    name: str = Field(..., description="Human-readable display name")
    description: str = Field(default="", description="Explanation of work type")
    priority: int = Field(
        default=50, description="Detection priority (higher = checked first)"
    )
    aliases: list[str] = Field(default_factory=list, description="Alternative names")
    detection: DetectionConfig = Field(
        default_factory=DetectionConfig, description="Detection patterns"
    )
    decomposition_guidance: DecompositionGuidance | None = Field(
        default=None,
        description="Guidance for decomposing work of this type into tasks",
    )


class DetectionSettings(BaseModel):
    """Global detection configuration settings."""

    confidence_threshold: float = Field(
        default=0.6,
        ge=0.0,
        le=1.0,
        description="Minimum confidence to assign work type",
    )
    multi_match_strategy: str = Field(
        default="highest_priority",
        description="Strategy for multiple matches: highest_priority, highest_confidence, all",
    )
    signal_weights: dict[str, float] = Field(
        default_factory=lambda: {
            "keywords": 0.25,
            "phrases": 0.35,
            "structural_signals": 0.25,
            "regex_patterns": 0.15,
        },
        description="Weight factors for different signal types",
    )
    case_sensitive: bool = Field(
        default=False, description="Case sensitivity for matching"
    )
    fuzzy_matching: dict[str, Any] = Field(
        default_factory=lambda: {"enabled": True, "max_distance": 2},
        description="Fuzzy matching settings",
    )


class FallbackConfig(BaseModel):
    """Fallback work type configuration."""

    id: str = Field(default="general", description="Fallback work type ID")
    name: str = Field(default="General", description="Fallback display name")
    description: str = Field(
        default="Work type could not be determined from available signals",
        description="Fallback description",
    )


class WorkTypePatternsConfig(BaseModel):
    """Complete work type patterns configuration."""

    schema_version: str = Field(default="1.0", description="Schema version")
    work_types: list[WorkTypeDefinition] = Field(
        default_factory=list, description="Work type definitions"
    )
    detection_settings: DetectionSettings = Field(
        default_factory=DetectionSettings, description="Detection settings"
    )
    fallback: FallbackConfig = Field(
        default_factory=FallbackConfig, description="Fallback config"
    )


@dataclass
class DetectionResult:
    """Result of work type detection."""

    work_type: str
    """The detected work type ID (e.g., 'feature_implementation', 'bug_fix')."""

    confidence: float
    """Confidence score from 0.0 to 1.0."""

    matched_signals: dict[str, list[str]] = field(default_factory=dict)
    """Signals that contributed to the detection."""

    all_matches: list[tuple[str, float]] = field(default_factory=list)
    """All work types that matched with their confidence scores."""


class WorkTypeDetector:
    """Detector for identifying work types from UserPlan or Intent data.

    Loads patterns from configuration and applies pattern matching logic
    to determine the work type of a given plan or intent.

    Example:
        >>> detector = WorkTypeDetector()
        >>> result = detector.detect(userplan)
        >>> print(result.work_type)
        'feature_implementation'
    """

    def __init__(
        self,
        config_path: Path | None = None,
        config: WorkTypePatternsConfig | None = None,
        domain: "DomainModule | None" = None,
    ) -> None:
        """Initialize the detector.

        Args:
            config_path: Optional path to custom config file.
            config: Optional pre-loaded configuration (for testing).
            domain: Optional domain module for domain-specific patterns.
        """
        self._domain = domain
        if domain is not None:
            # Load from domain module (takes precedence)
            patterns_data = domain.get_work_type_patterns()
            self._config = WorkTypePatternsConfig.model_validate(patterns_data)
        elif config is not None:
            self._config = config
        else:
            self._config = self._load_config(config_path)

        # Build lookup tables
        self._work_types_by_id: dict[str, WorkTypeDefinition] = {
            wt.id: wt for wt in self._config.work_types
        }
        self._alias_to_id: dict[str, str] = {}
        for wt in self._config.work_types:
            for alias in wt.aliases:
                self._alias_to_id[alias.lower()] = wt.id

        # Pre-compile regex patterns
        self._compiled_patterns: dict[str, list[re.Pattern[str]]] = {}
        for wt in self._config.work_types:
            patterns = []
            for rp in wt.detection.regex_patterns:
                try:
                    flags = (
                        0
                        if self._config.detection_settings.case_sensitive
                        else re.IGNORECASE
                    )
                    patterns.append(re.compile(rp.pattern, flags))
                except re.error as e:
                    logger.warning(
                        "Invalid regex pattern for %s: %s - %s", wt.id, rp.pattern, e
                    )
            self._compiled_patterns[wt.id] = patterns

    def _load_config(self, config_path: Path | None = None) -> WorkTypePatternsConfig:
        """Load configuration from file.

        Priority:
        1. Explicit config_path parameter
        2. Customer override at .obra/config/work_type_patterns.json
        3. Default patterns from obra/config/defaults/work_type_patterns.json

        Note: When domain parameter is provided, this method is not called.
        """
        # Priority 1: Explicit path
        if config_path is not None:
            return self._load_config_file(config_path)

        # Priority 2: Customer override
        if CUSTOMER_CONFIG_PATH.exists():
            logger.debug(
                "Loading customer work type patterns from %s", CUSTOMER_CONFIG_PATH
            )
            return self._load_config_file(CUSTOMER_CONFIG_PATH)
        if LEGACY_CUSTOMER_CONFIG_PATH.exists():
            logger.debug(
                "Loading legacy customer work type patterns from %s",
                LEGACY_CUSTOMER_CONFIG_PATH,
            )
            return self._load_config_file(LEGACY_CUSTOMER_CONFIG_PATH)

        # Emit deprecation warning when falling back to default config
        warnings.warn(
            "Loading work type patterns from default config path is deprecated. "
            "Use domain parameter instead: WorkTypeDetector(domain=SoftwareDomain())",
            DeprecationWarning,
            stacklevel=3,
        )

        # Priority 3: Default patterns
        return self._load_default_config()

    def _load_config_file(self, path: Path) -> WorkTypePatternsConfig:
        """Load configuration from a JSON file (YAML supported for migration)."""
        try:
            content = path.read_text(encoding="utf-8")
            if path.suffix in {".yaml", ".yml"}:
                data = yaml.safe_load(content) or {}
                json_path = path.with_suffix(".json")
                if not json_path.exists() and isinstance(data, dict):
                    json_path.write_text(
                        json.dumps(data, indent=2, sort_keys=False) + "\n",
                        encoding="utf-8",
                    )
            else:
                data = json.loads(content) if content.strip() else {}
            return WorkTypePatternsConfig.model_validate(data)
        except (OSError, yaml.YAMLError, json.JSONDecodeError) as e:
            logger.warning(
                "Failed to load config from %s: %s. Using defaults.", path, e
            )
            return self._load_default_config()

    def _load_default_config(self) -> WorkTypePatternsConfig:
        """Load default configuration from package resources."""
        try:
            default_path = resources.files("obra.config.defaults").joinpath(
                "work_type_patterns.json"
            )
            if not default_path.exists():
                default_path = resources.files("obra.config.defaults").joinpath(
                    "work_type_patterns.yaml"
                )
            content = default_path.read_text(encoding="utf-8")
            if default_path.suffix in {".yaml", ".yml"}:
                data = yaml.safe_load(content) or {}
            else:
                data = json.loads(content) if content.strip() else {}
            return WorkTypePatternsConfig.model_validate(data)
        except Exception as e:
            logger.warning("Failed to load default work type patterns: %s", e)
            return WorkTypePatternsConfig()

    def detect(
        self, input_data: UserPlan | IntentModel | dict[str, Any] | str
    ) -> DetectionResult:
        """Detect work type from input data.

        Args:
            input_data: UserPlan, IntentModel, dict, or raw text string.

        Returns:
            DetectionResult with work type, confidence, and matched signals.
        """
        # Extract text content from input
        text = self._extract_text(input_data)

        if not text or not text.strip():
            return DetectionResult(
                work_type=self._config.fallback.id,
                confidence=0.0,
                matched_signals={},
                all_matches=[],
            )

        # Normalize text for matching
        normalized_text = (
            text if self._config.detection_settings.case_sensitive else text.lower()
        )

        # Score each work type
        scores: list[tuple[str, float, dict[str, list[str]]]] = []
        weights = self._config.detection_settings.signal_weights

        # Sort by priority (higher first)
        sorted_work_types = sorted(
            self._config.work_types, key=lambda wt: wt.priority, reverse=True
        )

        for wt in sorted_work_types:
            matched_signals: dict[str, list[str]] = {
                "keywords": [],
                "phrases": [],
                "regex_patterns": [],
            }
            score = 0.0
            total_weight_possible = 0.0

            # Keyword matching
            if wt.detection.keywords:
                total_weight_possible += weights.get("keywords", 0.25)
                keyword_matches = self._match_keywords(
                    normalized_text, wt.detection.keywords
                )
                if keyword_matches:
                    matched_signals["keywords"] = keyword_matches
                    # Base score: any match gives 0.5, each additional match adds up to 0.5
                    match_ratio = len(keyword_matches) / len(wt.detection.keywords)
                    keyword_score = 0.5 + min(match_ratio, 1.0) * 0.5
                    score += keyword_score * weights.get("keywords", 0.25)

            # Phrase matching
            if wt.detection.phrases:
                total_weight_possible += weights.get("phrases", 0.35)
                phrase_matches = self._match_phrases(
                    normalized_text, wt.detection.phrases
                )
                if phrase_matches:
                    matched_signals["phrases"] = phrase_matches
                    # Phrases are more specific - any match is significant
                    match_ratio = len(phrase_matches) / len(wt.detection.phrases)
                    phrase_score = 0.6 + min(match_ratio, 1.0) * 0.4
                    score += phrase_score * weights.get("phrases", 0.35)

            # Regex pattern matching
            if wt.detection.regex_patterns:
                total_weight_possible += weights.get("regex_patterns", 0.15)
                regex_matches = self._match_regex(text, wt.id)
                if regex_matches:
                    matched_signals["regex_patterns"] = regex_matches
                    match_ratio = len(regex_matches) / len(wt.detection.regex_patterns)
                    regex_score = 0.5 + min(match_ratio, 1.0) * 0.5
                    score += regex_score * weights.get("regex_patterns", 0.15)

            # Structural signals (only applicable for dict/model inputs)
            if isinstance(input_data, (UserPlan, IntentModel, dict)):
                if wt.detection.structural_signals:
                    total_weight_possible += weights.get("structural_signals", 0.25)
                    structural_score = self._check_structural_signals(
                        input_data, wt.detection
                    )
                    if structural_score > 0:
                        score += structural_score * weights.get(
                            "structural_signals", 0.25
                        )

            # Normalize score by the weight of signals that could apply
            if score > 0 and total_weight_possible > 0:
                # Scale to 0-1 range based on applicable weights
                normalized_score = min(score / total_weight_possible, 1.0)
                scores.append((wt.id, normalized_score, matched_signals))

        # Handle no matches
        if not scores:
            return DetectionResult(
                work_type=self._config.fallback.id,
                confidence=0.0,
                matched_signals={},
                all_matches=[],
            )

        # Sort by score descending
        scores.sort(key=lambda x: x[1], reverse=True)
        all_matches = [(wt_id, conf) for wt_id, conf, _ in scores]

        # Apply multi-match strategy
        strategy = self._config.detection_settings.multi_match_strategy
        threshold = self._config.detection_settings.confidence_threshold

        if strategy == "highest_priority":
            # Already sorted by priority during iteration, take highest scoring
            best = scores[0]
        elif strategy == "highest_confidence":
            best = scores[0]  # Already sorted by score
        else:
            best = scores[0]

        work_type_id, confidence, matched_signals = best

        # Check confidence threshold
        if confidence < threshold:
            return DetectionResult(
                work_type=self._config.fallback.id,
                confidence=confidence,
                matched_signals=matched_signals,
                all_matches=all_matches,
            )

        return DetectionResult(
            work_type=work_type_id,
            confidence=confidence,
            matched_signals=matched_signals,
            all_matches=all_matches,
        )

    def _extract_text(
        self, input_data: UserPlan | IntentModel | dict[str, Any] | str
    ) -> str:
        """Extract searchable text from input data."""
        if isinstance(input_data, str):
            return input_data

        if isinstance(input_data, UserPlan):
            parts = []
            # Add step descriptions and titles
            for step in input_data.steps:
                parts.append(step.title)
                parts.append(step.description)
                if step.raw_text:
                    parts.append(step.raw_text)
            # Add context if available
            if input_data.context:
                parts.extend(input_data.context.deliverables)
                parts.extend(input_data.context.requirements)
            # Add source info
            if input_data.source and input_data.source.raw_objective:
                parts.append(input_data.source.raw_objective)
            return " ".join(filter(None, parts))

        if isinstance(input_data, IntentModel):
            parts = [
                input_data.problem_statement,
                input_data.raw_objective,
            ]
            parts.extend(input_data.requirements)
            parts.extend(input_data.assumptions)
            parts.extend(input_data.acceptance_criteria)
            return " ".join(filter(None, parts))

        if isinstance(input_data, dict):
            # Handle dict input (e.g., raw JSON/YAML data)
            parts = []
            for key in [
                "problem_statement",
                "raw_objective",
                "objective",
                "description",
                "title",
                "summary",
            ]:
                if key in input_data and isinstance(input_data[key], str):
                    parts.append(input_data[key])
            # Handle steps
            if "steps" in input_data and isinstance(input_data["steps"], list):
                for step in input_data["steps"]:
                    if isinstance(step, dict):
                        for key in ["title", "description", "raw_text"]:
                            if key in step and isinstance(step[key], str):
                                parts.append(step[key])
            # Handle requirements
            for key in ["requirements", "assumptions", "acceptance_criteria"]:
                if key in input_data and isinstance(input_data[key], list):
                    parts.extend(str(item) for item in input_data[key] if item)
            return " ".join(filter(None, parts))

        return ""

    def _match_keywords(self, text: str, keywords: list[str]) -> list[str]:
        """Match keywords in text."""
        matched = []
        for keyword in keywords:
            search_keyword = (
                keyword
                if self._config.detection_settings.case_sensitive
                else keyword.lower()
            )
            # Use word boundary matching
            pattern = rf"\b{re.escape(search_keyword)}\b"
            if re.search(pattern, text, re.IGNORECASE):
                matched.append(keyword)
        return matched

    def _match_phrases(self, text: str, phrases: list[str]) -> list[str]:
        """Match phrases in text."""
        matched = []
        for phrase in phrases:
            search_phrase = (
                phrase
                if self._config.detection_settings.case_sensitive
                else phrase.lower()
            )
            if search_phrase in text:
                matched.append(phrase)
        return matched

    def _match_regex(self, text: str, work_type_id: str) -> list[str]:
        """Match regex patterns for a work type."""
        matched = []
        patterns = self._compiled_patterns.get(work_type_id, [])
        for pattern in patterns:
            if pattern.search(text):
                matched.append(pattern.pattern)
        return matched

    def _check_structural_signals(
        self,
        input_data: UserPlan | IntentModel | dict[str, Any],
        detection: DetectionConfig,
    ) -> float:
        """Check structural signals and return a score."""
        if not detection.structural_signals:
            return 0.0

        matches = 0
        total = len(detection.structural_signals)

        for signal in detection.structural_signals:
            for key, expected_value in signal.items():
                if self._check_single_signal(input_data, key, expected_value):
                    matches += 1
                    break  # Each signal dict counts once

        return matches / total if total > 0 else 0.0

    def _check_single_signal(
        self,
        input_data: UserPlan | IntentModel | dict[str, Any],
        signal_key: str,
        expected_value: Any,
    ) -> bool:
        """Check a single structural signal."""
        # Convert to dict for uniform handling
        if isinstance(input_data, UserPlan):
            data = input_data.model_dump()
        elif isinstance(input_data, IntentModel):
            data = input_data.model_dump()
        else:
            data = input_data

        # Signal checks based on key
        if signal_key == "has_new_files":
            # Check if steps mention creating new files
            steps = data.get("steps", [])
            for step in steps:
                desc = step.get("description", "") if isinstance(step, dict) else ""
                if any(
                    kw in desc.lower()
                    for kw in ["create", "add", "new file", "new module"]
                ):
                    return expected_value
            return not expected_value

        if signal_key == "has_error_reference":
            # Check for error-related content
            text = str(data)
            return (
                any(
                    kw in text.lower()
                    for kw in ["error", "exception", "crash", "bug", "issue"]
                )
                == expected_value
            )

        if signal_key == "modifies_existing_files":
            steps = data.get("steps", [])
            for step in steps:
                desc = step.get("description", "") if isinstance(step, dict) else ""
                if any(
                    kw in desc.lower()
                    for kw in ["modify", "update", "change", "edit", "fix"]
                ):
                    return expected_value
            return not expected_value

        if signal_key == "targets_test_files":
            steps = data.get("steps", [])
            for step in steps:
                desc = step.get("description", "") if isinstance(step, dict) else ""
                title = step.get("title", "") if isinstance(step, dict) else ""
                if any(
                    kw in (desc + title).lower()
                    for kw in ["test", "spec", "unittest", "pytest"]
                ):
                    return expected_value
            return not expected_value

        # Default: signal not recognized
        return False

    def get_work_type_info(self, work_type_id: str) -> WorkTypeDefinition | None:
        """Get information about a work type by ID or alias.

        Args:
            work_type_id: Work type ID or alias.

        Returns:
            WorkTypeDefinition if found, None otherwise.
        """
        # Check direct ID
        if work_type_id in self._work_types_by_id:
            return self._work_types_by_id[work_type_id]

        # Check aliases
        normalized = work_type_id.lower()
        if normalized in self._alias_to_id:
            return self._work_types_by_id.get(self._alias_to_id[normalized])

        return None

    def list_work_types(self) -> list[str]:
        """Get list of all available work type IDs."""
        return [wt.id for wt in self._config.work_types]


def detect_work_type(
    input_data: UserPlan | IntentModel | dict[str, Any] | str,
    config_path: Path | None = None,
    domain: "DomainModule | None" = None,
) -> str:
    """Convenience function to detect work type from input.

    Args:
        input_data: UserPlan, IntentModel, dict, or raw text string.
        config_path: Optional path to custom config file.
        domain: Optional domain module for domain-specific patterns.

    Returns:
        Detected work type ID (e.g., 'feature_implementation', 'bug_fix', 'general').
    """
    detector = WorkTypeDetector(config_path=config_path, domain=domain)
    result = detector.detect(input_data)
    return result.work_type


# Public exports
__all__ = [
    "DEFAULT_WORK_TYPE",
    "DecompositionGuidance",
    "DetectionResult",
    "DetectionSettings",
    "WorkTypeDefinition",
    "WorkTypeDetector",
    "WorkTypePatternsConfig",
    "detect_work_type",
]
