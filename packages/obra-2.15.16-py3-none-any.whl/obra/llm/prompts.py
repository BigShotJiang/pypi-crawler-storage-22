"""Prompt helpers for LLM subsystem."""

from __future__ import annotations

__all__ = ["RESPONSE_PROTOCOL_INSTRUCTIONS", "get_response_protocol_instructions"]

RESPONSE_PROTOCOL_INSTRUCTIONS = """
## Response Protocol
End your response with one of these status indicators:

TASK_COMPLETE: <brief summary of what was accomplished>
TASK_BLOCKED: <what's blocking progress and why>
TASK_PARTIAL: <what was done and what remains>
TASK_CLARIFY: <missing external resource blocking progress - credentials, permissions, safety>

When requirements are ambiguous, document assumptions and proceed:
ASSUMPTION: <what you assumed and why>

Do NOT use TASK_CLARIFY for ambiguous requirements - make an assumption instead.

Example: TASK_COMPLETE: Implemented user authentication with JWT tokens
""".strip()


def get_response_protocol_instructions() -> str:
    """Return the response protocol instructions for prompt injection."""
    return RESPONSE_PROTOCOL_INSTRUCTIONS
