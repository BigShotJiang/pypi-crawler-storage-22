"""Retry utilities for LLM invocations with exponential backoff.

Provides configurable retry logic for transient errors across all LLM providers.
Reads settings from orchestration.retry config section.

Features:
    - Exponential backoff with configurable jitter (prevents thundering herd)
    - Error classification (retryable vs terminal)
    - Special handling for auth errors (configurable retry count)
    - Rate limit awareness (longer backoff for 429s)
    - Detailed logging for observability

Example:
    >>> from obra.llm.retry import with_retry, RetryConfig
    >>> config = RetryConfig.from_obra_config()
    >>> result = with_retry(
    ...     lambda: invoke_llm(...),
    ...     config=config,
    ...     operation_name="codex_invoke",
    ... )
"""

from __future__ import annotations

import logging
import random
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, TypeVar

from obra.constants import (
    DEFAULT_RETRY_BACKOFF_S,
    LLM_RETRY_DEFAULT_AUTH_MAX_ATTEMPTS,
    LLM_RETRY_DEFAULT_MAX_ATTEMPTS,
    LLM_RETRY_DEFAULT_MAX_DELAY_S,
)

logger = logging.getLogger(__name__)

T = TypeVar("T")


# Default retry configuration (matches default_config.yaml)
# High defaults (20) tuned for environments with intermittent network/auth issues.
# Users can lower via config if they have stable networks.
DEFAULT_MAX_ATTEMPTS = LLM_RETRY_DEFAULT_MAX_ATTEMPTS
DEFAULT_BASE_DELAY = DEFAULT_RETRY_BACKOFF_S
DEFAULT_MAX_DELAY = LLM_RETRY_DEFAULT_MAX_DELAY_S
DEFAULT_BACKOFF_MULTIPLIER = 2.0
DEFAULT_JITTER = 0.1
DEFAULT_AUTH_MAX_ATTEMPTS = LLM_RETRY_DEFAULT_AUTH_MAX_ATTEMPTS  # Auth errors - high default for flaky OAuth validation

# Error patterns that indicate retryable conditions
DEFAULT_RETRYABLE_PATTERNS = [
    "rate limit",
    "rate_limit",
    "too many requests",
    "timeout",
    "timed out",
    "connection",
    "network",
    "service unavailable",
    "temporarily unavailable",
    "try again",
    "ssl",
    "handshake",
    "connection reset",
    "broken pipe",
    "eof occurred",
    "remote end closed",
]

# Error patterns that indicate auth issues (retryable with limit)
AUTH_ERROR_PATTERNS = [
    "authentication",
    "auth",
    "unauthorized",
    "401",
    "token",
    "credential",
    "not logged in",
    "login required",
    "session expired",
    "invalid api key",
]

# Error patterns that are definitely NOT retryable
TERMINAL_ERROR_PATTERNS = [
    "invalid prompt",
    "invalid request",
    "bad request",
    "400",
    "403",  # Permission denied (sandbox, etc.)
    "permission denied",
    "not found",
    "404",
    "invalid model",
    "model not found",
    "context length exceeded",
    "content policy",
    "safety",
]


@dataclass
class RetryConfig:
    """Configuration for retry behavior.

    Attributes:
        max_attempts: Maximum number of retry attempts for general errors
        auth_max_attempts: Maximum retries specifically for auth errors
        base_delay: Initial delay in seconds before first retry
        max_delay: Maximum delay between retries (caps exponential growth)
        backoff_multiplier: Multiplier for exponential backoff
        jitter: Random jitter factor (0.0-1.0) to prevent thundering herd
        retryable_patterns: Error message patterns that trigger retry
    """

    max_attempts: int = DEFAULT_MAX_ATTEMPTS
    auth_max_attempts: int = DEFAULT_AUTH_MAX_ATTEMPTS
    base_delay: float = DEFAULT_BASE_DELAY
    max_delay: float = DEFAULT_MAX_DELAY
    backoff_multiplier: float = DEFAULT_BACKOFF_MULTIPLIER
    jitter: float = DEFAULT_JITTER
    retryable_patterns: list[str] = field(
        default_factory=lambda: DEFAULT_RETRYABLE_PATTERNS.copy()
    )

    @classmethod
    def from_obra_config(cls) -> RetryConfig:
        """Load retry configuration from Obra's layered config.

        Reads from orchestration.retry section in config files.
        Falls back to defaults if config not available.
        """
        try:
            from obra.config.loaders import get_retry_config

            return get_retry_config()
        except Exception as e:
            logger.debug(f"Could not load retry config, using defaults: {e}")
            return cls()


@dataclass
class RetryResult:
    """Result of a retry operation.

    Attributes:
        success: Whether the operation ultimately succeeded
        value: Return value if successful
        attempts: Total number of attempts made
        total_delay: Total time spent in retry delays (not including execution)
        last_error: Last error if failed
        error_type: Classification of the last error
    """

    success: bool
    value: Any = None
    attempts: int = 1
    total_delay: float = 0.0
    last_error: Exception | None = None
    error_type: str = "unknown"


class ErrorClassifier:
    """Classifies errors into retryable categories."""

    def __init__(self, retryable_patterns: list[str] | None = None) -> None:
        """Initialize classifier with custom patterns.

        Args:
            retryable_patterns: Additional patterns to consider retryable
        """
        self._retryable_patterns = retryable_patterns or DEFAULT_RETRYABLE_PATTERNS

    def classify(self, error: Exception) -> str:
        """Classify an error.

        Args:
            error: The exception to classify

        Returns:
            One of: "terminal", "auth", "rate_limit", "transient", "unknown"
        """
        error_str = str(error).lower()

        # Check terminal patterns first (these should never retry)
        for pattern in TERMINAL_ERROR_PATTERNS:
            if pattern in error_str:
                return "terminal"

        # Check for rate limiting (special handling with longer backoff)
        if any(
            p in error_str
            for p in ["rate limit", "rate_limit", "429", "too many requests"]
        ):
            return "rate_limit"

        # Check for auth errors (limited retries)
        for pattern in AUTH_ERROR_PATTERNS:
            if pattern in error_str:
                return "auth"

        # Check for retryable transient errors
        for pattern in self._retryable_patterns:
            if pattern in error_str:
                return "transient"

        # Check for common exception types
        error_type = type(error).__name__.lower()
        if any(t in error_type for t in ["timeout", "connection", "network", "ssl"]):
            return "transient"

        return "unknown"

    def is_retryable(self, error: Exception, error_type: str | None = None) -> bool:
        """Check if an error should be retried.

        Args:
            error: The exception
            error_type: Pre-classified error type (optional)

        Returns:
            True if the error should be retried
        """
        if error_type is None:
            error_type = self.classify(error)

        # Terminal errors are never retried
        if error_type == "terminal":
            return False

        # All other classified errors are retryable
        return error_type in ("auth", "rate_limit", "transient", "unknown")


def calculate_delay(
    attempt: int,
    base_delay: float,
    backoff_multiplier: float,
    max_delay: float,
    jitter: float,
    error_type: str = "transient",
) -> float:
    """Calculate delay for a retry attempt with exponential backoff and jitter.

    Args:
        attempt: Current attempt number (1-indexed)
        base_delay: Base delay in seconds
        backoff_multiplier: Multiplier for exponential growth
        max_delay: Maximum delay cap
        jitter: Jitter factor (0.0-1.0)
        error_type: Type of error (rate_limit gets longer delays)

    Returns:
        Delay in seconds
    """
    # Calculate exponential backoff
    delay = base_delay * (backoff_multiplier ** (attempt - 1))

    # Rate limit errors get 2x longer delays to be a good API tenant
    if error_type == "rate_limit":
        delay *= 2

    # Cap at max delay
    delay = min(delay, max_delay)

    # Add jitter (±jitter%)
    if jitter > 0:
        jitter_range = delay * jitter
        delay += random.uniform(-jitter_range, jitter_range)

    # Ensure non-negative
    return max(0.0, delay)


def with_retry(
    operation: Callable[[], T],
    config: RetryConfig | None = None,
    operation_name: str = "operation",
    on_retry: Callable[[int, Exception, float], None] | None = None,
) -> RetryResult:
    """Execute an operation with retry logic.

    Args:
        operation: The callable to execute
        config: Retry configuration (uses defaults if not provided)
        operation_name: Name for logging purposes
        on_retry: Optional callback called before each retry with
            (attempt_number, exception, delay_seconds)

    Returns:
        RetryResult with success status and value or error
    """
    if config is None:
        config = RetryConfig()

    classifier = ErrorClassifier(config.retryable_patterns)
    last_error: Exception | None = None
    error_type = "unknown"
    total_delay = 0.0
    auth_attempts = 0

    for attempt in range(1, config.max_attempts + 1):
        try:
            result = operation()
            return RetryResult(
                success=True,
                value=result,
                attempts=attempt,
                total_delay=total_delay,
            )

        except Exception as e:
            last_error = e
            error_type = classifier.classify(e)

            # Track auth attempts separately
            if error_type == "auth":
                auth_attempts += 1
                if auth_attempts >= config.auth_max_attempts:
                    logger.warning(
                        f"{operation_name}: Auth error after {auth_attempts} auth retries, "
                        f"giving up: {e}"
                    )
                    return RetryResult(
                        success=False,
                        attempts=attempt,
                        total_delay=total_delay,
                        last_error=e,
                        error_type=error_type,
                    )

            # Check if error is retryable
            if not classifier.is_retryable(e, error_type):
                logger.warning(
                    f"{operation_name}: Terminal error on attempt {attempt}, not retrying: {e}"
                )
                return RetryResult(
                    success=False,
                    attempts=attempt,
                    total_delay=total_delay,
                    last_error=e,
                    error_type=error_type,
                )

            # Check if we've exhausted retries
            if attempt >= config.max_attempts:
                logger.warning(
                    f"{operation_name}: Exhausted {config.max_attempts} attempts, "
                    f"last error: {e}"
                )
                break

            # Calculate delay and wait
            delay = calculate_delay(
                attempt=attempt,
                base_delay=config.base_delay,
                backoff_multiplier=config.backoff_multiplier,
                max_delay=config.max_delay,
                jitter=config.jitter,
                error_type=error_type,
            )
            total_delay += delay

            logger.info(
                f"{operation_name}: Attempt {attempt}/{config.max_attempts} failed "
                f"({error_type}), retrying in {delay:.1f}s: {e}"
            )

            if on_retry:
                on_retry(attempt, e, delay)

            time.sleep(delay)

    return RetryResult(
        success=False,
        attempts=config.max_attempts,
        total_delay=total_delay,
        last_error=last_error,
        error_type=error_type,
    )


def retry_subprocess(
    cmd_runner: Callable[[], tuple[str, str, int]],
    config: RetryConfig | None = None,
    operation_name: str = "subprocess",
) -> tuple[str, str, int]:
    """Retry a subprocess operation that returns (stdout, stderr, returncode).

    This is a convenience wrapper for subprocess-based LLM invocations
    that translates non-zero return codes into exceptions for retry logic.

    Args:
        cmd_runner: Callable that returns (stdout, stderr, returncode)
        config: Retry configuration
        operation_name: Name for logging

    Returns:
        (stdout, stderr, returncode) tuple

    Raises:
        RuntimeError: If all retries exhausted or terminal error
    """

    def wrapped() -> tuple[str, str, int]:
        stdout, stderr, returncode = cmd_runner()
        if returncode != 0:
            # Create error message from stderr/stdout for classification
            error_msg = stderr or stdout or f"Command failed with code {returncode}"
            raise RuntimeError(error_msg[:500])
        return stdout, stderr, returncode

    result = with_retry(wrapped, config=config, operation_name=operation_name)

    if result.success:
        return result.value

    # Re-raise the last error
    if result.last_error:
        raise result.last_error

    raise RuntimeError(f"{operation_name} failed after {result.attempts} attempts")


__all__ = [
    "ErrorClassifier",
    "RetryConfig",
    "RetryResult",
    "calculate_delay",
    "retry_subprocess",
    "with_retry",
]
