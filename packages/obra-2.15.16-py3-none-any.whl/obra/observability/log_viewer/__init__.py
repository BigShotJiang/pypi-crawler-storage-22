"""Local log viewer for aggregated hybrid + production logs."""

from obra.observability.log_viewer.server import run_log_viewer

__all__ = ["run_log_viewer"]
