"""Quality gate metrics for tracking block rate and score distribution.

This module provides metrics instrumentation for quality gate execution,
emitting Prometheus-style metrics via the event logging system.

Metrics:
    - obra_quality_gate_blocks_total: Counter for quality gate outcomes
      Labels: source_type (user/generated), blocked (true/false)
    - obra_quality_gate_score: Histogram of quality scores
      Labels: source_type (user/generated)

The metrics are emitted as structured events that can be:
- Aggregated in log analysis tools (e.g., grep/jq on hybrid.jsonl)
- Scraped by Prometheus via a metrics endpoint (if enabled)
- Used for dashboard visualization

Example:
    >>> from obra.review.metrics import emit_quality_gate_metrics
    >>> from obra.schemas.userplan_schema import SourceType
    >>> emit_quality_gate_metrics(
    ...     score=0.75,
    ...     blocked=False,
    ...     source_type=SourceType.INTENT,
    ...     threshold=0.6,
    ...     userplan_id="UP-20260117-abc",
    ... )

Related:
    - obra/hybrid/event_logger.py (event logging infrastructure)
    - obra/execution/quality.py (quality assessment handler)
    - obra/hybrid/handlers/derive.py (quality gate integration)
"""

import logging
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from obra.schemas.userplan_schema import SourceType

logger = logging.getLogger(__name__)

# Metric names following Prometheus naming convention
METRIC_BLOCKS_TOTAL = "obra_quality_gate_blocks_total"
METRIC_SCORE = "obra_quality_gate_score"

# Score histogram buckets (for distribution analysis)
SCORE_BUCKETS = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]


@dataclass
class QualityGateMetric:
    """Structured metric event for quality gate execution.

    Attributes:
        metric_name: Name of the metric (obra_quality_gate_blocks_total or obra_quality_gate_score)
        value: Metric value (1 for counter increment, score for histogram)
        labels: Metric labels (source_type, blocked)
        userplan_id: ID of the UserPlan being assessed
        threshold: Quality threshold used for pass/fail determination
        timestamp: ISO-8601 timestamp when metric was recorded
    """

    metric_name: str
    value: float
    labels: dict[str, str]
    userplan_id: str
    threshold: float | None = None
    timestamp: str | None = None

    def __post_init__(self) -> None:
        if self.timestamp is None:
            self.timestamp = datetime.now(UTC).isoformat()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for event logging."""
        return {
            "metric_name": self.metric_name,
            "value": self.value,
            "labels": self.labels,
            "userplan_id": self.userplan_id,
            "threshold": self.threshold,
            "timestamp": self.timestamp,
        }


def _get_source_type_label(source_type: "SourceType | None") -> str:
    """Convert SourceType to metric label string.

    Args:
        source_type: Source type enum or None

    Returns:
        Label string: "generated" for Obra-generated plans, "user" otherwise
    """
    if source_type is None:
        return "user"

    # Check if this is a generated plan
    # SourceType values: INTENT, PLAN_FILE, CHAT, etc.
    # The "generated" label is determined by source.generated field, not source_type
    # But for metric labels, we use a simplified categorization
    return source_type.value if source_type else "user"


def _get_score_bucket(score: float) -> str:
    """Determine which histogram bucket a score falls into.

    Args:
        score: Quality score (0.0 to 1.0)

    Returns:
        Bucket label string (e.g., "0.6-0.7")
    """
    if score <= 0.0:
        return "0.0"
    if score >= 1.0:
        return "1.0"

    for i, bucket in enumerate(SCORE_BUCKETS[:-1]):
        if score < SCORE_BUCKETS[i + 1]:
            return f"{bucket:.1f}-{SCORE_BUCKETS[i + 1]:.1f}"

    return "1.0"


def emit_quality_gate_metrics(
    score: float | None,
    blocked: bool,
    source_type: "SourceType | None",
    threshold: float,
    userplan_id: str,
    is_generated: bool = False,
    log_event: Any | None = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
) -> list[QualityGateMetric]:
    """Emit quality gate metrics for a single assessment.

    Emits two metrics:
    1. obra_quality_gate_blocks_total: Counter incremented for each assessment
       Labels: source_type (from SourceType), blocked (true/false)
    2. obra_quality_gate_score: Score value for histogram distribution
       Labels: source_type (from SourceType), bucket (score range)

    Args:
        score: Quality score (0.0 to 1.0), or None if not assessed
        blocked: Whether the quality gate blocked derivation
        source_type: SourceType of the UserPlan
        threshold: Quality threshold used for pass/fail
        userplan_id: ID of the UserPlan
        is_generated: Whether the plan was Obra-generated (affects label)
        log_event: Optional event logger callback
        trace_id: Optional trace ID for correlation
        parent_span_id: Optional parent span ID for correlation

    Returns:
        List of QualityGateMetric instances that were emitted

    Example:
        >>> metrics = emit_quality_gate_metrics(
        ...     score=0.75,
        ...     blocked=False,
        ...     source_type=SourceType.INTENT,
        ...     threshold=0.6,
        ...     userplan_id="UP-20260117-abc",
        ... )
        >>> print(f"Emitted {len(metrics)} metrics")
    """
    metrics: list[QualityGateMetric] = []
    timestamp = datetime.now(UTC).isoformat()

    # Determine source label based on generation status
    source_label = "generated" if is_generated else _get_source_type_label(source_type)

    # Metric 1: Block counter
    block_metric = QualityGateMetric(
        metric_name=METRIC_BLOCKS_TOTAL,
        value=1.0,  # Counter increment
        labels={
            "source_type": source_label,
            "blocked": str(blocked).lower(),
        },
        userplan_id=userplan_id,
        threshold=threshold,
        timestamp=timestamp,
    )
    metrics.append(block_metric)

    # Log block counter event
    if log_event:
        try:
            log_event(
                "quality_gate_metric",
                session_id=None,
                trace_id=trace_id,
                parent_span_id=parent_span_id,
                **block_metric.to_dict(),
            )
        except Exception as e:
            logger.debug("Failed to log quality gate block metric: %s", e)

    # Metric 2: Score histogram (only if score is available)
    if score is not None:
        bucket = _get_score_bucket(score)
        score_metric = QualityGateMetric(
            metric_name=METRIC_SCORE,
            value=score,
            labels={
                "source_type": source_label,
                "bucket": bucket,
            },
            userplan_id=userplan_id,
            threshold=threshold,
            timestamp=timestamp,
        )
        metrics.append(score_metric)

        # Log score histogram event
        if log_event:
            try:
                log_event(
                    "quality_gate_metric",
                    session_id=None,
                    trace_id=trace_id,
                    parent_span_id=parent_span_id,
                    **score_metric.to_dict(),
                )
            except Exception as e:
                logger.debug("Failed to log quality gate score metric: %s", e)

    logger.debug(
        "Emitted %d quality gate metrics for %s: blocked=%s, score=%s",
        len(metrics),
        userplan_id,
        blocked,
        score,
    )

    return metrics


def get_quality_gate_summary(
    metrics: list[QualityGateMetric],
) -> dict[str, Any]:
    """Aggregate quality gate metrics into a summary.

    Useful for batch analysis or dashboard display.

    Args:
        metrics: List of QualityGateMetric instances

    Returns:
        Summary dict with:
        - total_assessments: Total number of assessments
        - blocked_count: Number of blocked assessments
        - block_rate: Percentage of blocked assessments
        - score_distribution: Count of scores per bucket
        - avg_score: Average quality score
    """
    if not metrics:
        return {
            "total_assessments": 0,
            "blocked_count": 0,
            "block_rate": 0.0,
            "score_distribution": {},
            "avg_score": None,
        }

    # Count blocks
    block_metrics = [m for m in metrics if m.metric_name == METRIC_BLOCKS_TOTAL]
    blocked_count = sum(1 for m in block_metrics if m.labels.get("blocked") == "true")
    total_assessments = len(block_metrics)

    # Calculate block rate
    block_rate = (
        (blocked_count / total_assessments * 100) if total_assessments > 0 else 0.0
    )

    # Score distribution
    score_metrics = [m for m in metrics if m.metric_name == METRIC_SCORE]
    score_distribution: dict[str, int] = {}
    scores: list[float] = []

    for m in score_metrics:
        bucket = m.labels.get("bucket", "unknown")
        score_distribution[bucket] = score_distribution.get(bucket, 0) + 1
        scores.append(m.value)

    # Average score
    avg_score = sum(scores) / len(scores) if scores else None

    return {
        "total_assessments": total_assessments,
        "blocked_count": blocked_count,
        "block_rate": block_rate,
        "score_distribution": score_distribution,
        "avg_score": avg_score,
    }


__all__ = [
    "METRIC_BLOCKS_TOTAL",
    "METRIC_SCORE",
    "SCORE_BUCKETS",
    "QualityGateMetric",
    "emit_quality_gate_metrics",
    "get_quality_gate_summary",
]
