# Builtin open() Usage Audit - Migration Safety Categorization

This document categorizes all builtin `open()` calls in the `obra/` directory by migration risk.
Total instances found: **79** (73 builtin `open()` + 6 `Path.open()`)

---

## Summary

| Category | Count | Description |
|----------|-------|-------------|
| LOW-RISK | 31 | Test code, simple utility reads/writes |
| MEDIUM-RISK | 41 | Config loading, file generation with context managers |
| HIGH-RISK | 1 | Long-lived file handle management |
| NOT-APPLICABLE | 6 | Path.open() (already pathlib) or webbrowser.open() |

---

## NOT-APPLICABLE (6 instances)

These are either `Path.open()` calls (already pathlib-based) or unrelated `open()` calls.

| File | Line | Usage | Reason |
|------|------|-------|--------|
| `version_check.py` | 158 | `CACHE_FILE.open("r", encoding="utf-8")` | Path.open() - already pathlib |
| `version_check.py` | 194 | `CACHE_FILE.open("w", encoding="utf-8")` | Path.open() - already pathlib |
| `review/config.py` | 118 | `config_path.open(encoding="utf-8")` | Path.open() - already pathlib |
| `config/llm.py` | 686 | `config_path.open(encoding="utf-8")` | Path.open() - already pathlib |
| `intent/telemetry.py` | 17 | `path.open("a", encoding="utf-8")` | Path.open() - already pathlib |
| `agents/tier_config.py` | 64 | `config_path.open(encoding="utf-8")` | Path.open() - already pathlib |
| `auth/oauth.py` | 372 | `webbrowser.open(auth_url)` | webbrowser.open() - not file I/O |

---

## HIGH-RISK (1 instance)

These require careful migration due to complex lifecycle management or special requirements.

### feedback/session_logger.py:94
```python
self._file = open(self._log_path, "w", encoding="utf-8")
```
**Risk factors:**
- Long-lived file handle (not context manager)
- File handle stored as instance attribute
- Manually closed later in `_cleanup()` method
- Used for tee-style stdout/stderr capture
- Thread-safe operations via lock

**Migration consideration:** This is intentionally not using a context manager because the file needs to remain open across multiple method calls. Migration requires restructuring the class or using a deferred close pattern.

---

## MEDIUM-RISK (41 instances)

These use context managers but handle configuration, resources, or have multiple related operations.

### api/client.py (5 instances)
| Line | Mode | Purpose |
|------|------|---------|
| 322 | read | Load config file (JSON) |
| 335 | write | Save config file (JSON) |
| 357 | read | Load config file (JSON) |
| 390 | read | Load config file (JSON) |
| 1217 | docstring | Example in docstring (not actual code) |

### cli.py (8 instances)
| Line | Mode | Purpose |
|------|------|---------|
| 1176 | read | Load plan YAML |
| 1577 | read | Load plan file |
| 3759 | read | Read project context file |
| 3766 | read | Read project context file |
| 3817 | append | Append usage tracking |
| 7377 | write | Write output file |
| 8523 | read | Load default config |
| 8529 | read | Load customer config |
| 8548 | read | Load customer config |
| 8557 | write | Save customer config |

### config/loaders.py (2 instances)
| Line | Mode | Purpose |
|------|------|---------|
| 226 | read | Load config file |
| 446 | write | Save config file |

### feedback/collector.py (8 instances)
| Line | Mode | Purpose |
|------|------|---------|
| 352 | read | Read draft file |
| 379 | read | Read draft path |
| 469 | read | Load config path |
| 489 | write | Save draft path |
| 520 | read | Load default config |
| 526 | read | Load customer config |
| 669 | write | Save pending file |
| 793 | read | Read pending file |

### feedback/observability.py (1 instance)
| Line | Mode | Purpose |
|------|------|---------|
| 129 | read | Read log path |

### hybrid/event_logger.py (1 instance)
| Line | Mode | Purpose |
|------|------|---------|
| 178 | append | Append JSONL event log |

### hybrid/handlers/execute.py (2 instances)
| Line | Mode | Purpose |
|------|------|---------|
| 888 | read | Load config file |
| 1196 | read | Read file content |

### hybrid/handlers/fix.py (2 instances)
| Line | Mode | Purpose |
|------|------|---------|
| 1161 | read | Load config file |
| 1416 | read | Read file content |

### legal/__init__.py (2 instances)
| Line | Mode | Purpose |
|------|------|---------|
| 27 | read | Read beta terms file |
| 37 | read | Read terms summary file |

### project/context.py (2 instances)
| Line | Mode | Purpose |
|------|------|---------|
| 190 | read | Read notes path |
| 212 | write | Write notes path |

### validation/plan_validator.py (2 instances)
| Line | Mode | Purpose |
|------|------|---------|
| 252 | read | Parse JSON file |
| 258 | read | Parse YAML file |

### workflow/customer_tier.py (5 instances)
| Line | Mode | Purpose |
|------|------|---------|
| 100 | read | Load manifest |
| 160 | read | Read file content |
| 182 | read | Read template |
| 463 | write | Save manifest |
| 492 | write | Save example file |

### workflow/feedback_triage.py (1 instance)
| Line | Mode | Purpose |
|------|------|---------|
| 115 | read | Load config file |

### workflow/obra_tier.py (3 instances)
| Line | Mode | Purpose |
|------|------|---------|
| 87 | read | Load manifest |
| 128 | read | Read file content |
| 155 | read | Read file content |

### workflow/sota_tier.py (2 instances)
| Line | Mode | Purpose |
|------|------|---------|
| 83 | read | Load manifest |
| 121 | read | Read file content |

### workflow/tiered_resolver.py (1 instance)
| Line | Mode | Purpose |
|------|------|---------|
| 632 | read | Read file content |

### auto/plan_reader.py (2 instances)
| Line | Mode | Purpose |
|------|------|---------|
| 48 | read | Read plan YAML |
| 110 | write | Write plan YAML |

### cli_commands/upload_plan.py (1 instance)
| Line | Mode | Purpose |
|------|------|---------|
| 114 | read | Read plan file |

---

## LOW-RISK (31 instances)

Test code and simple utility operations that are straightforward to migrate.

### tests/test_auto_plan_reader.py (4 instances)
| Line | Mode | Purpose |
|------|------|---------|
| 51 | write | Write test plan fixture |
| 94 | write | Write test plan fixture |
| 116 | write | Write test plan fixture |
| 151 | read | Read test plan |

### tests/test_cli_plans.py (5 instances)
| Line | Mode | Purpose |
|------|------|---------|
| 124 | write | Write test plan |
| 144 | write | Write test plan |
| 382 | write | Write invalid YAML test |
| 407 | write | Write list file test |
| 435 | write (binary) | Write binary file test |

### tests/test_auto_runner.py (10 instances)
| Line | Mode | Purpose |
|------|------|---------|
| 46 | write | Write test plan |
| 72 | read | Read test plan |
| 91 | read | Read test plan |
| 111 | read | Read test plan |
| 128 | read | Read test plan |
| 147 | write | Write test plan |
| 295 | read | Read test plan |
| 336 | read | Read test plan |
| 377 | read | Read test plan |

---

## Migration Priority Recommendations

### Phase 1: Low-Risk (Test Code) - 31 instances
- All test files can be migrated first as they have no production impact
- Simple find-and-replace with `Path(path).read_text(encoding="utf-8")` or `Path(path).write_text(content, encoding="utf-8")`

### Phase 2: Medium-Risk (Config/Resource Loading) - 41 instances
- Migrate config loaders and utility functions
- These all use context managers, so migration is straightforward
- Watch for error handling differences

### Phase 3: High-Risk (Special Cases) - 1 instance
- `feedback/session_logger.py:94` requires class restructuring
- Consider keeping as-is if the current pattern is intentional for performance/lifecycle reasons

### Keep As-Is
- Path.open() calls (6 instances) - already using pathlib
- `webbrowser.open()` - not file I/O

---

## Notes

1. All identified `open()` calls already specify `encoding="utf-8"` (good practice)
2. No instances of binary mode reads without explicit encoding were found (except one test case)
3. The codebase consistently uses context managers (`with` statements) except for one high-risk case
4. No raw `open()` without context managers in production code (except session_logger.py)
