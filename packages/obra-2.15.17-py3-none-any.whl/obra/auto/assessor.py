"""Optional LLM error assessor for autonomous runner.

This module provides LLM-based error assessment for ambiguous failures
in the autonomous workplan runner. Uses fast-tier model for cost control.

Architecture:
    - Optional component (enabled via config)
    - Fast-tier LLM (defaults from config) for cost control
    - Returns retry/skip/escalate decision
    - Falls back to deterministic logic if unavailable
    - Uses CLI subprocess invocation (REVIEW-CLI-001 pattern)

Configuration:
    orchestration.auto.error_assessor: null (disabled), "fast" (use fast-tier), or model name

Usage:
    llm_config = {"provider": "anthropic", "model": "haiku", ...}
    assessor = ErrorAssessor(enabled=True, llm_config=llm_config)
    if assessor.enabled:
        decision = assessor.assess_error(story, exit_code, logs)
"""

import logging
import subprocess
from enum import Enum
from typing import Any

# Import at module level for easier mocking in tests
from obra.auto.prompts import build_assessment_prompt
from obra.config import (
    build_llm_args,
    build_subprocess_env,
    get_llm_api_timeout,
    get_llm_cli,
)

logger = logging.getLogger(__name__)


class AssessmentDecision(Enum):
    """Decisions from LLM error assessment."""

    RETRY = "retry"
    SKIP = "skip"
    ESCALATE = "escalate"


class ErrorAssessor:
    """LLM-based error assessor for ambiguous failures.

    Uses CLI subprocess invocation following REVIEW-CLI-001 pattern.
    """

    def __init__(self, enabled: bool = False, llm_config: dict[str, Any] | None = None):
        """Initialize error assessor.

        Args:
            enabled: Enable LLM assessment
            llm_config: LLM configuration dict with provider, model, etc.
        """
        self.enabled = enabled
        self.llm_config = llm_config
        self.last_response: str | None = None
        self.last_decision: AssessmentDecision | None = None

        if enabled and not llm_config:
            logger.warning(
                "Error assessor enabled but no LLM config provided. "
                "Assessment will be disabled."
            )
            self.enabled = False

    def assess_error(
        self, story: dict[str, Any], exit_code: int, logs: str, attempt: int = 1
    ) -> AssessmentDecision | None:
        """Assess error and return recommended decision.

        Args:
            story: Story dictionary from machine plan
            exit_code: Process exit code
            logs: Output logs from failed execution
            attempt: Current attempt number

        Returns:
            AssessmentDecision if assessment successful, None if unavailable
        """
        if not self.enabled:
            return None

        try:
            # Build assessment prompt
            prompt = self._build_assessment_prompt(story, exit_code, logs, attempt)

            # Call LLM for assessment
            response = self._call_llm(prompt)

            # Parse response to decision
            decision = self._parse_response(response)
            self.last_response = response
            self.last_decision = decision

            logger.info(
                "LLM assessment for story %s: %s", story.get("id"), decision.value
            )
            return decision

        except Exception:
            logger.exception("Error assessment failed")
            return None

    def _build_assessment_prompt(
        self, story: dict[str, Any], exit_code: int, logs: str, attempt: int
    ) -> str:
        """Build assessment prompt for LLM.

        Args:
            story: Story dictionary
            exit_code: Process exit code
            logs: Output logs
            attempt: Current attempt number

        Returns:
            Formatted prompt string
        """
        return build_assessment_prompt(story, exit_code, logs, attempt)

    def _call_llm(self, prompt: str, timeout_s: int | None = None) -> str:
        """Call LLM via CLI subprocess for error assessment.

        Follows REVIEW-CLI-001 pattern: uses get_llm_cli(), build_llm_args(),
        build_subprocess_env() to invoke LLM via CLI subprocess.

        Args:
            prompt: Assessment prompt
            timeout_s: Maximum execution time in seconds. Defaults to get_llm_api_timeout().

        Returns:
            LLM response text

        Raises:
            subprocess.TimeoutExpired: If invocation exceeds timeout
            subprocess.CalledProcessError: If CLI invocation fails
        """
        if not self.llm_config:
            raise RuntimeError("LLM config not available")

        # Resolve timeout from config if not provided
        effective_timeout = (
            timeout_s if timeout_s is not None else get_llm_api_timeout()
        )

        try:
            # Build CLI command and args from llm_config
            provider = self.llm_config.get("provider", "anthropic")
            cli_command = get_llm_cli(provider)
            # Use mode="text" for assessment (--print with JSON output, no file writes)
            cli_args = build_llm_args(self.llm_config, mode="text")

            cmd = [cli_command, *cli_args]

            # Build subprocess environment with auth-aware API key handling
            env = build_subprocess_env(self.llm_config)

            logger.debug(
                f"Calling LLM for error assessment: {cmd[0]} (timeout={effective_timeout}s)"
            )

            # Execute subprocess with stdin/stdout pipes
            result = subprocess.run(
                cmd,
                input=prompt,
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=effective_timeout,
                env=env,
                check=True,  # Raise CalledProcessError on non-zero exit
            )

            response = result.stdout.strip()
            logger.debug(f"LLM response: {response[:100]}...")
            return response

        except subprocess.TimeoutExpired:
            logger.exception(f"LLM call timed out after {timeout_s}s")
            raise
        except subprocess.CalledProcessError as e:
            logger.exception(f"LLM CLI invocation failed: {e.stderr}")
            raise
        except Exception:
            logger.exception("LLM call failed")
            raise

    def _parse_response(self, response: str) -> AssessmentDecision:
        """Parse LLM response to decision.

        Args:
            response: LLM response text

        Returns:
            AssessmentDecision

        Raises:
            ValueError: If response cannot be parsed
        """
        # Normalize response
        normalized = response.strip().upper()

        # Map to decision
        if "RETRY" in normalized:
            return AssessmentDecision.RETRY
        if "SKIP" in normalized:
            return AssessmentDecision.SKIP
        if "ESCALATE" in normalized:
            return AssessmentDecision.ESCALATE

        logger.warning("Ambiguous LLM response: %s. Defaulting to ESCALATE.", response)
        return AssessmentDecision.ESCALATE
