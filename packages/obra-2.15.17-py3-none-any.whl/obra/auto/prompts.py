"""Prompts for autonomous workplan execution.

Contains prompts extracted from obra/auto/assessor.py as part of
the prompt library refactoring (REFACTOR-PROMPT-LIBRARY-001).

Prompts:
    build_assessment_prompt: Builder for failure assessment prompts
"""

from __future__ import annotations

__all__ = ["build_assessment_prompt"]


def build_assessment_prompt(
    story: dict,
    exit_code: int,
    logs: str,
    attempt: int,
) -> str:
    """Build prompt for assessing autonomous workplan runner failure.

    Args:
        story: Story dict with 'id' and 'title' keys
        exit_code: Process exit code
        logs: Output logs (will be truncated to last 2000 chars)
        attempt: Current attempt number

    Returns:
        Formatted assessment prompt string
    """
    # Truncate logs if too long (keep last 2000 chars for context)
    max_log_chars = 2000
    truncated_logs = logs[-max_log_chars:] if len(logs) > max_log_chars else logs

    return f"""Assess this autonomous workplan runner failure and decide: \
retry, skip, or escalate.

Story: {story.get('id')} - {story.get('title')}
Exit Code: {exit_code}
Attempt: {attempt}

Recent Output:
```
{truncated_logs}
```

Decision Criteria:
- RETRY: Transient failure (network, timeout, resource contention).
  Worth retrying.
- SKIP: Non-critical failure, can continue with other stories.
  Story is optional.
- ESCALATE: Critical failure or requires human intervention.
  Stop execution.

Respond with ONLY one word: RETRY, SKIP, or ESCALATE
"""
