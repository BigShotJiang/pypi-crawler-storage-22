"""Shared interrupt handling utilities."""

from __future__ import annotations

import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass


class GracefulInterrupt(BaseException):
    """Raised at safe checkpoints after a deferred interrupt request."""


@dataclass
class _InterruptState:
    requested: bool = False
    reason: str = ""
    requested_at: float = 0.0
    deferred_depth: int = 0


_STATE = _InterruptState()
_LOCK = threading.Lock()


def request_interrupt(reason: str) -> None:
    """Record a graceful interrupt request."""
    with _LOCK:
        _STATE.requested = True
        _STATE.reason = reason
        _STATE.requested_at = time.time()


def interrupt_requested() -> bool:
    """Return True if a graceful interrupt has been requested."""
    with _LOCK:
        return _STATE.requested


def interrupt_reason() -> str:
    """Return the interrupt reason (empty string if none)."""
    with _LOCK:
        return _STATE.reason


def clear_interrupt_request() -> None:
    """Clear any pending interrupt request."""
    with _LOCK:
        _STATE.requested = False
        _STATE.reason = ""
        _STATE.requested_at = 0.0


def should_defer_interrupts() -> bool:
    """Return True if interrupts should be deferred to checkpoints."""
    with _LOCK:
        return _STATE.deferred_depth > 0


@contextmanager
def defer_interrupts() -> None:
    """Defer interrupts to explicit checkpoints while in this context."""
    with _LOCK:
        _STATE.deferred_depth += 1
    try:
        yield
    finally:
        with _LOCK:
            _STATE.deferred_depth = max(0, _STATE.deferred_depth - 1)


def checkpoint(label: str) -> None:
    """Raise GracefulInterrupt if a deferred interrupt was requested."""
    if interrupt_requested():
        raise GracefulInterrupt(label)
