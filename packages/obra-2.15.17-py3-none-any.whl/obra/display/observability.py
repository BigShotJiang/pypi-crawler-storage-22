"""Observability infrastructure for Obra CLI operations.

This module provides progressive verbosity levels and progress emission
for CLI commands, allowing users to observe LLM streaming, orchestration
phases, and execution progress in real-time.

Verbosity Levels:
    0 (QUIET): Minimal output - final results only
    1 (PROGRESS): Phase transitions with timestamps
    2 (DETAIL): Item-level details and LLM summaries
    3 (DEBUG): Full protocol info and debug messages

Usage:
    config = ObservabilityConfig(verbosity=VerbosityLevel.PROGRESS, stream=True)
    emitter = ProgressEmitter(config, console)
    emitter.phase_started("DERIVATION")
    emitter.llm_streaming("Here is my response...")
    emitter.phase_completed("DERIVATION", duration_ms=1500)

Security:
    - NEVER emit user prompts or LLM system prompts (IP protection)
    - NEVER emit API keys, credentials, or secrets
    - LLM responses are safe to show (user-requested observability)
"""

import sys
from dataclasses import dataclass
from datetime import datetime
from enum import IntEnum

from rich.console import Console


class VerbosityLevel(IntEnum):
    """Progressive verbosity levels for CLI output.

    Attributes:
        QUIET: Minimal output - final results only
        PROGRESS: Phase transitions with timestamps
        DETAIL: Item-level details and LLM summaries
        DEBUG: Full protocol info and debug messages
    """

    QUIET = 0
    PROGRESS = 1
    DETAIL = 2
    DEBUG = 3


_STAGE_USER_LABELS: dict[str, str] = {
    "assumptions": "Understanding requirements",
    "analogues": "Researching approach",
    "brief": "Structuring plan",
    "derive": "Detailing plan",
    "review": "Validating plan",
    "intent_alignment": "Checking intent coverage",
}

_RUNTIME_VERBOSITY: int = VerbosityLevel.PROGRESS


def set_runtime_verbosity(verbosity: int) -> None:
    """Update global verbosity hint for modules that lack direct config."""
    global _RUNTIME_VERBOSITY
    _RUNTIME_VERBOSITY = int(verbosity)


def get_runtime_verbosity() -> int:
    """Return global verbosity hint for modules that lack direct config."""
    return _RUNTIME_VERBOSITY


@dataclass
class ObservabilityConfig:
    """Configuration for CLI observability features.

    Attributes:
        verbosity: Output detail level (0-3)
        stream: Whether to show LLM responses as they stream
        timestamps: Whether to include timestamps in output
        dashboard_enabled: Master toggle for dashboard UI elements
        footer_hint_enabled: Toggle for Ctrl+C footer hint
        task_tracker_enabled: Toggle for task tracker output
        task_tracker_max_next: Max number of upcoming tasks to show
    """

    verbosity: int = VerbosityLevel.PROGRESS
    stream: bool = False
    timestamps: bool = True
    dashboard_enabled: bool = True
    footer_hint_enabled: bool = True
    task_tracker_enabled: bool = True
    task_tracker_max_next: int = 3


class ProgressEmitter:
    """Emits progress events based on observability configuration.

    This class formats and displays orchestration progress events according
    to the configured verbosity level, supporting real-time LLM streaming
    and progressive detail disclosure.

    Attributes:
        config: Observability configuration (None uses defaults)
        console: Rich Console for formatted output
    """

    _ALLOWED_LLM_STATES = {"idle", "waiting", "streaming", "processing"}

    def __init__(self, config: ObservabilityConfig | None, console: Console) -> None:
        """Initialize the progress emitter.

        Args:
            config: Observability config, or None for defaults
            console: Rich Console instance for output
        """
        import threading

        self.config = config or ObservabilityConfig()
        self.console = console
        self._total_tasks: int = 0
        self._current_task_index: int = 0
        self._files_created: int = 0
        self._files_modified: int = 0
        self._heartbeat_count: int = 0
        self._is_tty: bool = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
        self._session_id: str | None = None
        self._review_attempt: int = 0
        self._review_max_attempts: int = 0
        self._review_agents: dict[str, str] = {}
        self._lock = threading.Lock()
        self._llm_state: str = "idle"
        self._dashboard_enabled: bool = bool(self.config.dashboard_enabled)
        self._footer_hint_enabled: bool = bool(self.config.footer_hint_enabled)
        self._task_tracker_enabled: bool = bool(self.config.task_tracker_enabled)
        self._task_tracker_max_next: int = max(
            0, int(self.config.task_tracker_max_next)
        )
        self._task_tracker_items: list[dict[str, str]] = []
        self._task_tracker_index: dict[str, int] = {}
        self._task_tracker_done: set[str] = set()
        self._task_tracker_current_id: str | None = None
        self._task_tracker_current_title: str | None = None
        self._plan_items: list[dict[str, object]] = []
        self._plan_index: dict[str, dict[str, object]] = {}
        self._plan_children: dict[str | None, list[str]] = {}
        self._plan_status: dict[str, str] = {}
        self._plan_order: dict[str, int] = {}
        self._completed_stories: set[str] = set()
        self._completed_epics: set[str] = set()
        self._last_plan_render_s: float | None = None
        self._last_plan_render_reason: str | None = None
        self._plan_render_min_interval_s: float = 2.0
        self._spinner_chars: list[str] = [
            "⠋",
            "⠙",
            "⠹",
            "⠸",
            "⠼",
            "⠴",
            "⠦",
            "⠧",
            "⠇",
            "⠏",
        ]
        self._spinner_index: int = 0
        self._stage_live_active: bool = False
        self._stage_live_last_len: int = 0
        self._stage_live_last_update_ts: float = 0.0
        self._stage_live_min_interval_s: float = 1.5
        self._stage_heartbeat_last_emit: dict[str, float] = {}
        self._stage_heartbeat_emit_interval_s: float = 60.0
        self._current_stage_context: dict | None = None
        # Footer hint rate limiting - avoid cluttering output on rapid phase changes
        self._last_footer_hint_s: float | None = None
        self._footer_hint_min_interval_s: float = 30.0
        # Unified derivation step tracking (3-step pipeline)
        self._derive_current_step: int | None = None
        self._derive_current_step_name: str | None = None
        self._derive_step_start_time: float | None = None
        self._derive_last_output_time: float | None = None
        self._last_plan_summary: dict[str, int] | None = None
        self._plan_source: str | None = None
        self._plan_mode: str | None = None

    def _get_stage_label(self, stage: str) -> str:
        base_stage = stage.split("_pass_")[0]
        return _STAGE_USER_LABELS.get(base_stage, base_stage.replace("_", " ").title())

    def update_plan_snapshot(
        self,
        plan_items: list[dict],
        source: str | None = None,
        session_id: str | None = None,
        mode: str | None = None,
    ) -> None:
        """Update cached plan items and render the plan tree."""
        if mode == "partial":
            self._render_partial_plan_snapshot(plan_items, source)
            return
        if session_id:
            self._session_id = session_id

        previous_items = list(self._plan_items)

        normalized_items: list[dict[str, object]] = []
        plan_index: dict[str, dict[str, object]] = {}
        plan_children: dict[str | None, list[str]] = {}
        plan_status: dict[str, str] = {}
        plan_order: dict[str, int] = {}

        for item in plan_items:
            if not isinstance(item, dict):
                continue
            item_id = str(item.get("id") or item.get("item_id") or "").strip()
            if not item_id:
                continue
            title = str(item.get("title") or item.get("description") or "").strip()
            description = str(item.get("description") or "").strip()
            item_type = str(item.get("item_type") or "").strip().lower()
            if not item_type:
                item_type = self._infer_item_type(item_id)
            parent_id = item.get("parent_id")
            parent_id = str(parent_id).strip() if parent_id is not None else None
            depth = item.get("depth")
            try:
                depth_value = int(depth) if depth is not None else 0
            except (TypeError, ValueError):
                depth_value = 0
            order_value = item.get("order")
            try:
                order = int(order_value) if order_value is not None else -1
            except (TypeError, ValueError):
                order = -1
            status = self._normalize_status(str(item.get("status", "")).strip())

            normalized = {
                "id": item_id,
                "title": title,
                "description": description,
                "item_type": item_type,
                "parent_id": parent_id or "",
                "depth": depth_value,
            }
            normalized_items.append(normalized)
            plan_index[item_id] = normalized
            plan_status[item_id] = status
            plan_order[item_id] = order
            plan_children.setdefault(parent_id or None, []).append(item_id)

        self._plan_items = normalized_items
        self._plan_index = plan_index
        self._plan_children = plan_children
        self._plan_status = plan_status
        self._plan_order = plan_order
        if source:
            self._plan_source = source
        if mode:
            self._plan_mode = mode
        self._last_plan_summary = {
            "epic": sum(
                1 for item in normalized_items if item.get("item_type") == "epic"
            ),
            "story": sum(
                1 for item in normalized_items if item.get("item_type") == "story"
            ),
            "task": sum(
                1 for item in normalized_items if item.get("item_type") == "task"
            ),
        }
        self._completed_stories.clear()
        self._completed_epics.clear()

        reason = "Plan updated"
        if source == "derive":
            reason = "Plan derived"
        elif source == "revise":
            reason = "Plan revised"

        # Only force render on first plan snapshot; let debouncing work for subsequent updates
        is_first_render = self._last_plan_render_s is None
        self.render_plan_tree(reason=reason, source=source or None, force=is_first_render)
        if source == "revise" and self.config.verbosity >= VerbosityLevel.PROGRESS:
            summary = self._summarize_plan_changes(previous_items, normalized_items)
            if summary:
                self._print(summary, style="dim")

    def _render_partial_plan_snapshot(
        self, plan_items: list[dict], source: str | None
    ) -> None:
        """Render a compact, in-progress plan snapshot at DETAIL verbosity."""
        if self.config.verbosity < VerbosityLevel.DETAIL:
            return
        if not plan_items:
            return

        epic_item = None
        stories: list[dict] = []
        tasks: list[dict] = []
        for item in plan_items:
            if not isinstance(item, dict):
                continue
            item_type = str(item.get("item_type") or "").lower()
            if item_type == "epic" and epic_item is None:
                epic_item = item
            elif item_type == "story":
                stories.append(item)
            elif item_type == "task":
                tasks.append(item)

        if not epic_item:
            return

        epic_id = str(epic_item.get("id", "")).strip()
        epic_title = str(epic_item.get("title", "")).strip() or "Untitled"
        header = "Plan snapshot (partial)"
        if source:
            header = f"{header}, source: {source}"
        header = f"{header} - {epic_id}: {epic_title}"

        timestamp = self._timestamp()
        self._print_persistent(f"{timestamp}{header}", style="cyan")

        story_map: dict[str, list[dict]] = {}
        for task in tasks:
            parent_id = str(task.get("parent_id") or "").strip()
            if parent_id:
                story_map.setdefault(parent_id, []).append(task)

        max_stories = 5
        max_tasks = 5
        for story in stories[:max_stories]:
            story_id = str(story.get("id", "")).strip()
            story_title = str(story.get("title", "")).strip() or "Untitled"
            task_count = len(story_map.get(story_id, []))
            self._print_persistent(
                f"  - {story_id}: {story_title} ({task_count} tasks)",
                style="dim",
            )
            for task in story_map.get(story_id, [])[:max_tasks]:
                task_id = str(task.get("id", "")).strip()
                task_title = str(task.get("title", "")).strip() or "Untitled"
                self._print_persistent(f"    - {task_id}: {task_title}", style="dim")
            if task_count > max_tasks:
                self._print_persistent(
                    f"    - +{task_count - max_tasks} more tasks",
                    style="dim",
                )

        if len(stories) > max_stories:
            self._print_persistent(
                f"  - +{len(stories) - max_stories} more stories",
                style="dim",
            )

    def item_skipped(self, item: dict) -> None:
        """Emit event when processing a plan item is skipped."""
        item_id = item.get("id", "?")
        normalized_id = str(item_id).strip()
        if normalized_id and normalized_id != "?":
            self._task_tracker_done.add(normalized_id)
            if self._task_tracker_current_id == normalized_id:
                self._task_tracker_current_id = None
                self._task_tracker_current_title = None
            self._plan_status[normalized_id] = "skipped"
            self._maybe_render_story_completion(normalized_id)

    def render_plan_tree(
        self, reason: str, source: str | None, *, force: bool = False
    ) -> None:
        """Render the full plan tree at PROGRESS verbosity or higher."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        if not self._plan_items:
            return
        if not force and self._last_plan_render_s is not None:
            now = datetime.now().timestamp()
            elapsed = now - self._last_plan_render_s
            if (
                self._last_plan_render_reason == reason
                and elapsed < self._plan_render_min_interval_s
            ):
                return

        header = "Plan"
        if source:
            header = f"{header} (source: {source})"
        if self.config.verbosity >= VerbosityLevel.DETAIL and self._plan_mode:
            header = f"{header}, mode: {self._plan_mode}"
        if reason:
            header = f"{header} - {reason}"
        self._print("")
        self._print(header, style="bold cyan")
        self._last_plan_render_s = datetime.now().timestamp()
        self._last_plan_render_reason = reason

        roots: set[str] = set()
        for item_id, item in self._plan_index.items():
            parent_id = item.get("parent_id") or None
            if not parent_id or parent_id not in self._plan_index:
                roots.add(item_id)
        roots_list = self._sort_plan_ids(list(roots))

        for root_id in roots_list:
            self._render_plan_node(root_id, level=0)

        if self._last_plan_summary:
            epic_count = self._last_plan_summary.get("epic", 0)
            story_count = self._last_plan_summary.get("story", 0)
            task_count = self._last_plan_summary.get("task", 0)
            self._print(
                f"\nPlan: {epic_count} Epics, {story_count} Stories, {task_count} Tasks",
                style="dim",
            )

    def _render_plan_node(self, item_id: str, level: int) -> None:
        item = self._plan_index.get(item_id, {})
        title = str(item.get("title", ""))
        item_type = str(item.get("item_type", "task")).upper()
        status = self._aggregate_status(item_id)
        status_label = self._format_status_label(status)
        indent = "  " * level
        display_title = title if title else "untitled"
        line = f"{indent}[{status_label}] {item_id} {item_type}: {display_title}"
        self._print(line, style="dim" if status in ("pending", "skipped") else None)

        children = self._sort_plan_ids(self._plan_children.get(item_id, []))
        for child_id in children:
            self._render_plan_node(child_id, level=level + 1)

    def _sort_plan_ids(self, ids: list[str]) -> list[str]:
        def sort_key(item_id: str) -> tuple[int, str]:
            order = self._plan_order.get(item_id, -1)
            if order < 0:
                order = 1_000_000
            return (order, item_id)

        return sorted(ids, key=sort_key)

    def _normalize_status(self, status: str) -> str:
        normalized = status.lower()
        if normalized in {"completed", "complete", "done", "success", "ok"}:
            return "completed"
        if normalized in {"in_progress", "running", "started"}:
            return "in_progress"
        if normalized in {"failed", "error", "failure"}:
            return "failed"
        if normalized in {"skipped", "skip"}:
            return "skipped"
        return "pending"

    def _format_status_label(self, status: str) -> str:
        return {
            "completed": "done",
            "in_progress": "running",
            "failed": "failed",
            "skipped": "skipped",
            "pending": "pending",
        }.get(status, "pending")

    def _aggregate_status(self, item_id: str) -> str:
        children = self._plan_children.get(item_id)
        if not children:
            return self._plan_status.get(item_id, "pending")

        child_statuses = [self._aggregate_status(child_id) for child_id in children]
        if any(status == "failed" for status in child_statuses):
            return "failed"
        if any(status == "in_progress" for status in child_statuses):
            return "in_progress"
        if all(status in {"completed", "skipped"} for status in child_statuses):
            return "completed"
        return "pending"

    def _infer_item_type(self, item_id: str) -> str:
        if item_id.startswith("E"):
            return "epic"
        if item_id.startswith("S") and ".T" not in item_id:
            return "story"
        if ".T" in item_id:
            if item_id.count(".") >= 2:
                return "subtask"
            return "task"
        return "task"

    def _summarize_plan_changes(
        self,
        previous_items: list[dict[str, object]],
        current_items: list[dict[str, object]],
    ) -> str | None:
        if not previous_items:
            return None

        def to_map(items: list[dict[str, object]]) -> dict[str, dict[str, object]]:
            result: dict[str, dict[str, object]] = {}
            for item in items:
                item_id = str(item.get("id", "")).strip()
                if item_id:
                    result[item_id] = item
            return result

        prev_map = to_map(previous_items)
        curr_map = to_map(current_items)
        prev_ids = set(prev_map.keys())
        curr_ids = set(curr_map.keys())

        added_ids = sorted(curr_ids - prev_ids)
        removed_ids = sorted(prev_ids - curr_ids)

        updated_ids: list[str] = []
        moved_ids: list[str] = []
        for item_id in sorted(prev_ids & curr_ids):
            prev = prev_map[item_id]
            curr = curr_map[item_id]
            if (prev.get("parent_id") or "") != (curr.get("parent_id") or ""):
                moved_ids.append(item_id)
            if (
                (prev.get("title") or "") != (curr.get("title") or "")
                or (prev.get("description") or "") != (curr.get("description") or "")
                or (prev.get("item_type") or "") != (curr.get("item_type") or "")
            ):
                updated_ids.append(item_id)

        def format_ids(label: str, ids: list[str], prefix: str) -> str:
            count = len(ids)
            if count == 0:
                return f"{prefix}{count} {label}"
            shown = ids[:5]
            extra = count - len(shown)
            extra_label = f", ...+{extra} more" if extra > 0 else ""
            joined = ", ".join(shown)
            return f"{prefix}{count} {label} ({joined}{extra_label})"

        parts = [
            format_ids("added", added_ids, "+"),
            format_ids("removed", removed_ids, "-"),
            format_ids("updated", updated_ids, "~"),
        ]
        if moved_ids:
            parts.append(format_ids("moved", moved_ids, ""))
        return f"Changes: {', '.join(parts)}"

    def _find_ancestor(self, item_id: str, target_type: str) -> str | None:
        current_id = item_id
        while current_id:
            current = self._plan_index.get(current_id)
            if not current:
                return None
            if current.get("item_type") == target_type:
                return current_id
            parent_id = current.get("parent_id") or None
            if not parent_id:
                return None
            current_id = parent_id
        return None

    def _iter_descendants(self, item_id: str) -> list[str]:
        descendants: list[str] = []
        stack = list(self._plan_children.get(item_id, []))
        while stack:
            current = stack.pop()
            descendants.append(current)
            stack.extend(self._plan_children.get(current, []))
        return descendants

    def _is_story_complete(self, story_id: str) -> bool:
        descendants = self._iter_descendants(story_id)
        if not descendants:
            return False
        leaf_ids = [
            desc
            for desc in descendants
            if not self._plan_children.get(desc)
            and self._plan_index.get(desc, {}).get("item_type") in {"task", "subtask"}
        ]
        if not leaf_ids:
            return False
        return all(
            self._plan_status.get(leaf_id, "pending") in {"completed", "skipped"}
            for leaf_id in leaf_ids
        )

    def _is_epic_complete(self, epic_id: str) -> bool:
        descendants = self._iter_descendants(epic_id)
        story_ids = [
            desc
            for desc in descendants
            if self._plan_index.get(desc, {}).get("item_type") == "story"
        ]
        if not story_ids:
            return False
        return all(self._is_story_complete(story_id) for story_id in story_ids)

    def _maybe_render_story_completion(self, item_id: str) -> None:
        story_id = self._find_ancestor(item_id, "story")
        if story_id and story_id not in self._completed_stories:
            if self._is_story_complete(story_id):
                self._completed_stories.add(story_id)
                self.render_plan_tree(reason=f"Story {story_id} complete", source=None)

                epic_id = self._find_ancestor(story_id, "epic")
                if epic_id and epic_id not in self._completed_epics:
                    if self._is_epic_complete(epic_id):
                        self._completed_epics.add(epic_id)
                        self.render_plan_tree(
                            reason=f"Epic {epic_id} complete", source=None
                        )

    def set_session_id(self, session_id: str) -> None:
        """Set the session ID for footer hints and correlation.

        Shows resume hint immediately so user knows how to recover
        if something goes wrong during derivation or execution.

        Args:
            session_id: Session identifier for the current run
        """
        self._session_id = session_id
        self.render_footer_hint()

    def set_plan_items(self, items: list[dict]) -> None:
        """Set plan items for task tracker rendering.

        Args:
            items: List of plan item dicts with id/title fields
        """
        if not items:
            return

        normalized: list[dict[str, str]] = []
        index_map: dict[str, int] = {}
        for item in items:
            if not isinstance(item, dict):
                continue
            item_id = str(item.get("id", "")).strip()
            if not item_id:
                continue
            title = str(item.get("title", "")).strip()
            normalized.append({"id": item_id, "title": title})
            index_map[item_id] = len(normalized) - 1

        if not normalized:
            return

        self._task_tracker_items = normalized
        self._task_tracker_index = index_map
        if self._total_tasks == 0:
            self._total_tasks = len(normalized)

        if self._task_tracker_current_id and not self._task_tracker_current_title:
            current_index = self._task_tracker_index.get(self._task_tracker_current_id)
            if current_index is not None:
                current_title = self._task_tracker_items[current_index].get("title")
                if current_title:
                    self._task_tracker_current_title = current_title

        self._task_tracker_done = {
            task_id for task_id in self._task_tracker_done if task_id in index_map
        }

    def _dashboard_feature_enabled(self, enabled: bool) -> bool:
        """Return True if a dashboard UI element should render."""
        return (
            self._dashboard_enabled
            and enabled
            and self.config.verbosity >= VerbosityLevel.PROGRESS
        )

    def _timestamp(self) -> str:
        """Get current timestamp in [HH:MM:SS] format.

        Returns:
            Formatted timestamp string if timestamps enabled, empty string otherwise
        """
        if self.config.timestamps:
            return f"[{datetime.now().strftime('%H:%M:%S')}] "
        return ""

    def _format_status_line(self, status: str, message: str) -> str:
        """Format a status-first line with an optional timestamp."""
        timestamp = self._timestamp().strip()
        if timestamp:
            return f"{status} {timestamp} {message}"
        return f"{status} {message}"

    def _next_spinner(self) -> str:
        """Return the next spinner character and advance the index."""
        spinner_char = self._spinner_chars[self._spinner_index]
        self._spinner_index = (self._spinner_index + 1) % len(self._spinner_chars)
        return spinner_char

    def _clear_spinner_line(self) -> None:
        """Clear the spinner line to allow persistent progress messages.

        When a spinner is active (using \\r carriage return), we need to
        clear it before printing messages that should persist. This prints
        a newline to move to the next line, preventing the spinner from
        overwriting the message.
        """
        if self._stage_live_active and self._is_tty:
            # Clear the current line and move to next line
            # Print spaces to overwrite spinner, then newline
            self._console.print(" " * self._stage_live_last_len, end="\r")
            self._stage_live_active = False

    def _print_persistent(self, message: str, style: str | None = None) -> None:
        """Print a message that persists above the spinner.

        Clears any active spinner line first, then prints the message
        on its own line so it won't be overwritten.
        """
        self._clear_spinner_line()
        self._print(message, style=style)

    def reset_derive_step_state(self) -> None:
        """Reset unified derivation step tracking (call when step ends or derive phase ends)."""
        self._derive_current_step = None
        self._derive_current_step_name = None
        self._derive_step_start_time = None
        self._derive_last_output_time = None

    def set_total_tasks(self, total: int) -> None:
        """Set the total task count and reset progress tracking.

        Args:
            total: Total number of tasks expected in this session
        """
        self._total_tasks = total
        self._current_task_index = 0
        self._heartbeat_count = 0

        if self.config.verbosity >= VerbosityLevel.DEBUG:
            self._print(
                f"[DEBUG] ProgressEmitter: task count set to {total}",
                style="dim",
            )

    def reset_review_state(self) -> None:
        """Reset review loop tracking state to defaults."""
        self._review_attempt = 0
        self._review_max_attempts = 0
        self._review_agents = {}

    def set_llm_state(self, state: str) -> None:
        """Set the current LLM state.

        Args:
            state: LLM state string ("idle", "waiting", "streaming", "processing")
        """
        if state not in self._ALLOWED_LLM_STATES:
            raise ValueError(f"Invalid LLM state: {state}")
        self._llm_state = state

    def get_llm_state(self) -> str:
        """Return the current LLM state."""
        return self._llm_state

    def review_loop_started(self, attempt: int, max_attempts: int) -> None:
        """Emit event when a review loop begins."""
        self._review_attempt = attempt
        self._review_max_attempts = max_attempts
        self._review_agents = {}

        if self.config.verbosity == VerbosityLevel.QUIET:
            self._print(f"Review [attempt {attempt}/{max_attempts}]")
            return

        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._timestamp()
        self._print(
            f"{timestamp}Review [attempt {attempt}/{max_attempts}]",
            style="cyan",
        )

    def review_agent_started(self, agent_name: str) -> None:
        """Emit event when a review agent starts running."""
        with self._lock:
            self._review_agents[agent_name] = "running"

        if self.config.verbosity == VerbosityLevel.QUIET:
            return

        if self.config.verbosity == VerbosityLevel.PROGRESS:
            self._print(f"[{agent_name}] running...", style="dim")
            return

        if self.config.verbosity >= VerbosityLevel.DETAIL:
            timestamp = self._timestamp()
            self._print(f"{timestamp}[{agent_name}] running...", style="dim")

    def review_agent_completed(
        self,
        agent_name: str,
        passed: bool,
        details: str | None = None,
    ) -> None:
        """Emit event when a review agent finishes."""
        status = "passed" if passed else "failed"
        symbol = "✓" if passed else "✗"
        style = "green" if passed else "red"

        with self._lock:
            self._review_agents[agent_name] = status

        if self.config.verbosity == VerbosityLevel.QUIET:
            return

        if self.config.verbosity == VerbosityLevel.PROGRESS:
            self._print(f"[{agent_name}] {symbol} {status}", style=style)
            return

        if self.config.verbosity >= VerbosityLevel.DETAIL:
            timestamp = self._timestamp()
            message = f"{timestamp}[{agent_name}] {symbol} {status}"
            if details:
                self._print(message, style=style)
                self._print(f"  - {details}", style="dim")
            else:
                self._print(message, style=style)

    def scorecard_available(
        self,
        scores: dict[str, int],
        total: int,
        threshold: int,
        item_id: str | None = None,
    ) -> None:
        """Emit event when a scorecard summary is available.

        Args:
            scores: Mapping of scorecard categories to scores
            total: Total score (0-100)
            threshold: Passing threshold
            item_id: Optional item ID for context (which item was reviewed)
        """
        passed = total >= threshold
        style = "green" if passed else "yellow"
        status = "pass" if passed else "fail"

        # Format item context for display
        item_context = f" ({item_id})" if item_id else ""

        if self.config.verbosity == VerbosityLevel.QUIET:
            self._print(
                f"Score{item_context}: {total}/100 (threshold: {threshold}) - {status}",
                style=style,
            )
            return

        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        self._print(
            f"Review score{item_context}: {total}/100 (pass \u2265 {threshold})",
            style=style,
        )

        if self.config.verbosity < VerbosityLevel.DETAIL or not scores:
            return

        max_score = 100
        for category, score in scores.items():
            self._print(f"  ├─ {category}: {score}/{max_score}", style=style)

    def scorecard_warning(self, message: str) -> None:
        """Emit a single-line scorecard warning."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        self._print(f"Scorecard: {message}", style="yellow")

    def session_completed(
        self,
        items_completed: int,
        quality_score: float,
        session_summary: str,
        *,
        was_escalated: bool = False,
    ) -> None:
        """Emit completion message when session ends.

        FIX-COMPLETION-001: Provides clear visual feedback that the mission is done.
        FIX-ESCALATION-COMPLETION-001: Shows appropriate message for escalated sessions.

        Args:
            items_completed: Number of items completed in the session
            quality_score: Quality score (0.0-1.0 or 0-100)
            session_summary: Summary of what was accomplished
            was_escalated: If True, session ended via escalation (not celebratory)
        """
        # Normalize quality score to 0-100
        if quality_score <= 1.0:
            quality_score = quality_score * 100

        # Build completion message - different for escalated vs successful sessions
        self._print("")  # Blank line for visual separation

        if was_escalated:
            # FIX-ESCALATION-COMPLETION-001: Don't celebrate escalated sessions
            self._print("Session Ended (Escalated)", style="bold yellow")
            if self.config.verbosity >= VerbosityLevel.PROGRESS:
                timestamp = self._timestamp()
                self._print(
                    f"{timestamp}Completed {items_completed} items before escalation",
                    style="yellow",
                )
        else:
            # Normal successful completion
            self._print("Mission Complete!", style="bold green")
            if self.config.verbosity >= VerbosityLevel.PROGRESS:
                timestamp = self._timestamp()
                self._print(
                    f"{timestamp}Completed {items_completed} items (quality: {quality_score:.0f}/100)",
                    style="green",
                )
                if session_summary and self.config.verbosity >= VerbosityLevel.DETAIL:
                    self._print(f"Summary: {session_summary}", style="dim")

    def track_file_created(self) -> None:
        """Increment the file created counter."""
        self._files_created += 1

    def track_file_modified(self) -> None:
        """Increment the file modified counter."""
        self._files_modified += 1

    def get_file_summary(self) -> str:
        """Get a summary of file activity for the current session."""
        if self._files_created == 0 and self._files_modified == 0:
            return ""
        return (
            f"Files: +{self._files_created} created, ~{self._files_modified} modified"
        )

    def render_footer_hint(self, force: bool = False) -> None:
        """Render the session resume footer hint when a session ID is set.

        Rate-limited to avoid cluttering output during rapid phase transitions.
        By default, shows at most once every 30 seconds.

        Args:
            force: If True, bypass rate limiting and always render
        """
        if not self._dashboard_feature_enabled(self._footer_hint_enabled):
            return
        if self._session_id is None:
            return

        # Rate limiting: skip if rendered recently (unless forced)
        if not force and self._last_footer_hint_s is not None:
            now = datetime.now().timestamp()
            elapsed = now - self._last_footer_hint_s
            if elapsed < self._footer_hint_min_interval_s:
                return

        from obra.display.recovery_hints import build_resume_continue_hints

        self._print("─────────────────────────────────────────────────────────────────")
        self._print("Ctrl+C: pause safely at next checkpoint", style="dim")
        for line in build_resume_continue_hints(self._session_id).splitlines():
            self._print(line, style="dim")

        # Update timestamp for rate limiting
        self._last_footer_hint_s = datetime.now().timestamp()

    def render_task_tracker(self) -> None:
        """Render task tracker summary when enabled."""
        if not self._dashboard_feature_enabled(self._task_tracker_enabled):
            return

        if (
            self._task_tracker_current_id is None
            and not self._task_tracker_items
            and self._total_tasks == 0
        ):
            return

        done_count = len(self._task_tracker_done)
        total_count = (
            self._total_tasks
            if self._total_tasks > 0
            else len(self._task_tracker_items)
        )
        total_label = str(total_count) if total_count > 0 else "?"

        if self._task_tracker_current_id:
            current_title = self._task_tracker_current_title or ""
            if current_title:
                current_label = f"{self._task_tracker_current_id}: {current_title}"
            else:
                current_label = self._task_tracker_current_id
        else:
            current_label = "idle"

        max_next = self._task_tracker_max_next
        next_label = "none"
        if self._task_tracker_items and max_next > 0:
            start_index = 0
            if self._task_tracker_current_id in self._task_tracker_index:
                start_index = (
                    self._task_tracker_index[self._task_tracker_current_id] + 1
                )

            upcoming: list[str] = []
            for item in self._task_tracker_items[start_index:]:
                item_id = item.get("id", "")
                if not item_id or item_id == self._task_tracker_current_id:
                    continue
                if item_id in self._task_tracker_done:
                    continue
                title = item.get("title", "")
                if title:
                    upcoming.append(f"{item_id}: {title}")
                else:
                    upcoming.append(item_id)
                if len(upcoming) >= max_next:
                    break
            next_label = ", ".join(upcoming) if upcoming else "none"
        elif total_count > 0:
            next_label = "n/a"

        self._print(
            f"Tracker: {done_count}/{total_label} | Current: {current_label} | Next: {next_label}",
            style="dim",
        )

    def _print(self, message: str, style: str | None = None, end: str = "\n") -> None:
        """Print message with or without Rich formatting based on TTY detection.

        Args:
            message: Message to print
            style: Rich style to apply (only if TTY)
            end: String appended after the message (default: newline)
        """
        if self._is_tty:
            # TTY: use Rich formatting with markup and optional style
            self.console.print(message, style=style, end=end)
        else:
            # Plain text output for non-TTY (CI, piped output)
            # Disable markup to avoid printing raw tags
            self.console.print(message, end=end, markup=False)

    def phase_started(self, phase: str, context: dict | None = None) -> None:
        """Emit event when an orchestration phase starts.

        Args:
            phase: Phase name (e.g., "USERPLAN_GENERATION", "DERIVATION", "REFINEMENT", "EXECUTION")
            context: Optional context information about the phase
        """
        normalized_phase = str(phase).upper()
        # Level 0 (QUIET): Show minimal phase indicator
        if self.config.verbosity == VerbosityLevel.QUIET:
            phase_label = {
                "USERPLAN_GENERATION": "Generating UserPlan from objective",
                "DERIVATION": "Deriving execution plan",
                "REFINEMENT": "Examining plan",
                "EXECUTION": "Executing",
            }.get(normalized_phase, phase)
            self._print(f"{phase_label}...", end="")
            return

        # Level 1+ (PROGRESS and above): Show with timestamp
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._timestamp()
        self._print(f"{timestamp}Phase: {phase}", style="bold cyan")

        if self.config.verbosity >= VerbosityLevel.DEBUG and context:
            # Truncate verbose context output
            ctx_str = str(context)
            max_chars = 300
            display_ctx = (
                ctx_str if len(ctx_str) <= max_chars else ctx_str[:max_chars] + "..."
            )
            self._print(f"[DEBUG] Context: {display_ctx}", style="dim")

        if normalized_phase == "EXECUTION":
            # Note: Footer hint removed from here - it was too noisy (showed 17+ times per session)
            # Footer hint now shows only: once at set_session_id(), and in completion footer
            self.render_task_tracker()

    def phase_completed(
        self, phase: str, result: dict | None = None, duration_ms: int = 0
    ) -> None:
        """Emit event when an orchestration phase completes.

        Args:
            phase: Phase name that completed
            result: Optional result data from the phase
            duration_ms: Phase duration in milliseconds
        """
        # Level 0 (QUIET): Complete the line with result count
        if self.config.verbosity == VerbosityLevel.QUIET:
            if phase == "USERPLAN_GENERATION":
                # S1.T7: Two-step generation feedback for UserPlan
                title = (result or {}).get("title", "UserPlan")
                self._print(" done")
                self._print(f"Generated UserPlan: {title}")
            elif phase == "DERIVATION":
                # S1.T7: Two-step generation feedback for derivation
                task_count = (result or {}).get("item_count", 0)
                self._print(" done")
                self._print(f"Derived execution plan with {task_count} tasks")
            elif result and "item_count" in result:
                item_count = result["item_count"]
                self._print(f" done ({item_count} items)")
            elif result and "issue_count" in result:
                issue_count = result["issue_count"]
                self._print(f" done ({issue_count} issues)")
            else:
                self._print(" done")
            return

        # Level 1+ (PROGRESS and above): Show with timestamp and duration
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._timestamp()
        duration_sec = duration_ms / 1000.0

        # Build completion message with item count if available
        if phase == "USERPLAN_GENERATION":
            # S1.T7: Two-step generation feedback for UserPlan (PROGRESS+ level)
            title = (result or {}).get("title", "UserPlan")
            message = f"{timestamp}Generated UserPlan: {title} ({duration_sec:.1f}s)"
            self._print(message, style="green")
        elif result and "item_count" in result:
            item_count = result["item_count"]
            message = f"{timestamp}"
            if phase == "DERIVATION":
                # S1.T7: Two-step generation feedback for derivation (PROGRESS+ level)
                message += f"Derived execution plan with {item_count} tasks ({duration_sec:.1f}s)"
            elif phase == "REFINEMENT":
                issues = result.get("issue_count", 0)
                message += f"Found {issues} issues ({duration_sec:.1f}s)"
            else:
                message += f"Phase {phase} complete ({duration_sec:.1f}s)"
            self._print(message, style="green")

            # At PROGRESS level, show item list if available
            if self.config.verbosity == VerbosityLevel.PROGRESS and "items" in result:
                for item in result["items"]:
                    item_id = item.get("id", "?")
                    item_title = item.get("title", "untitled")
                    self._print(f"           {item_id}: {item_title}")
        else:
            self._print(
                f"{timestamp}Phase {phase} complete ({duration_sec:.1f}s)",
                style="green",
            )

        if self.config.verbosity >= VerbosityLevel.DETAIL and result:
            # Show result summary at detail level
            if "items" in result and self.config.verbosity > VerbosityLevel.PROGRESS:
                # Show detailed plan items with descriptions and dependencies
                for item in result["items"]:
                    item_id = item.get("id", "?")
                    item_title = item.get("title", "untitled")
                    depends_on = item.get("depends_on", [])

                    # Show item with dependency info
                    if depends_on:
                        deps_str = ", ".join(depends_on)
                        self._print(f"  {item_id}: {item_title} (depends: {deps_str})")
                    else:
                        self._print(f"  {item_id}: {item_title}")

                    # Show description or acceptance criteria if available
                    description = item.get("description", "")
                    acceptance_criteria = item.get("acceptance_criteria", [])

                    if description:
                        # Multi-line description - show indented
                        for line in description.split("\n"):
                            if line.strip():
                                self._print(f"      - {line.strip()}", style="dim")
                    elif acceptance_criteria:
                        # Show acceptance criteria as bullet points
                        for criterion in acceptance_criteria:
                            self._print(f"      - {criterion}", style="dim")

        if self.config.verbosity >= VerbosityLevel.DEBUG and result:
            # Truncate verbose result output
            result_str = str(result)
            max_chars = 500
            display_result = (
                result_str
                if len(result_str) <= max_chars
                else result_str[:max_chars] + "..."
            )
            self._print(
                f"[DEBUG] Full result ({len(result_str)} chars): {display_result}",
                style="dim",
            )

    def stage_started(self, stage: str, context: dict | None = None) -> None:
        """Emit event when a pipeline stage starts."""
        if self._stage_live_active:
            self._print("")
            self._stage_live_active = False
            self._stage_live_last_len = 0
            self._stage_live_last_update_ts = 0.0
        self._current_stage_context = context
        if self.config.verbosity < VerbosityLevel.DETAIL:
            return
        timestamp = self._timestamp()
        self._print(f"{timestamp}Stage: {stage}", style="bold cyan")
        if self.config.verbosity >= VerbosityLevel.DEBUG and context:
            # Truncate verbose context output
            ctx_str = str(context)
            max_chars = 300
            display_ctx = (
                ctx_str if len(ctx_str) <= max_chars else ctx_str[:max_chars] + "..."
            )
            self._print(f"[DEBUG] Stage context: {display_ctx}", style="dim")

        # Show objective at derive start (DETAIL verbosity)
        if (
            stage == "derive"
            and context
            and self.config.verbosity >= VerbosityLevel.DETAIL
        ):
            objective = context.get("objective", "")
            if objective:
                display_obj = (
                    objective[:60] + "..." if len(objective) > 60 else objective
                )
                self._print(f'  Deriving: "{display_obj}"', style="cyan")

    def stage_completed(
        self, stage: str, result: dict | None = None, duration_ms: int = 0
    ) -> None:
        """Emit event when a pipeline stage completes."""
        if self._stage_live_active:
            self._print("")
            self._stage_live_active = False
            self._stage_live_last_len = 0
            self._stage_live_last_update_ts = 0.0

        if self.config.verbosity < VerbosityLevel.DETAIL:
            return
        timestamp = self._timestamp()
        duration_sec = duration_ms / 1000.0
        message = f"{timestamp}Stage {stage} complete ({duration_sec:.1f}s)"
        self._print(message, style="green")

        # Show hierarchy summary for derive stage completion (DETAIL only)
        if stage == "derive" and result:
            epic_count = result.get("epic_count", 0)
            story_count = result.get("story_count", 0)
            task_count = result.get("task_count", 0)
            if epic_count or story_count or task_count:
                epic_str = f"{epic_count} Epic" + ("s" if epic_count != 1 else "")
                story_str = f"{story_count} Stor" + ("ies" if story_count != 1 else "y")
                task_str = f"{task_count} Task" + ("s" if task_count != 1 else "")
                self._print(
                    f"  └─ Derived: {epic_str}, {story_str}, {task_str}", style="green"
                )

        if self.config.verbosity >= VerbosityLevel.DEBUG and result:
            # Truncate verbose result output
            result_str = str(result)
            max_chars = 300
            display_result = (
                result_str
                if len(result_str) <= max_chars
                else result_str[:max_chars] + "..."
            )
            self._print(f"[DEBUG] Stage result: {display_result}", style="dim")
        self._current_stage_context = None

    def planning_started(self, objective: str) -> None:
        """Emit event when planning begins."""
        if self.config.verbosity == VerbosityLevel.QUIET:
            self._print("Planning...", end="")
            return
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        display_obj = objective.strip()
        if display_obj:
            if len(display_obj) > 60:
                display_obj = display_obj[:60] + "..."
            self._print(f'{timestamp}Planning "{display_obj}"...', style="bold cyan")
        else:
            self._print(f"{timestamp}Planning...", style="bold cyan")

    def planning_stage_started(self, stage: str, user_label: str) -> None:
        """Emit event when a planning stage starts (user-facing)."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        label = user_label.strip() if user_label else self._get_stage_label(stage)
        self._print(f"{timestamp}{label}...", style="cyan")

    def planning_stage_completed(
        self,
        stage: str,
        user_label: str,
        duration_s: float,
        summary: str | None = None,
    ) -> None:
        """Emit event when a planning stage completes (user-facing)."""
        if self.config.verbosity == VerbosityLevel.QUIET:
            if stage == "review":
                summary_line = ""
                if self._last_plan_summary:
                    epic_count = self._last_plan_summary.get("epic", 0)
                    story_count = self._last_plan_summary.get("story", 0)
                    task_count = self._last_plan_summary.get("task", 0)
                    summary_line = f" ({epic_count} epics, {story_count} stories, {task_count} tasks)"
                self._print(f" done{summary_line}")
            return
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        label = user_label.strip() if user_label else self._get_stage_label(stage)
        completion = summary or f"{label} complete"
        self._print(
            f"{timestamp}✓ {completion} ({duration_s:.1f}s)",
            style="green",
        )

    def story0_started(self) -> None:
        """Emit event when Story 0 environment preparation starts."""
        if self.config.verbosity == VerbosityLevel.QUIET:
            self._print("Environment...", end="")
            return
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(f"{timestamp}Environment (Story 0)", style="bold cyan")

    def story0_prerequisite_status(
        self,
        category: str,
        name: str,
        status: str,
        reason: str | None = None,
    ) -> None:
        """Emit progress for a Story 0 prerequisite."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        symbol_map = {
            "installed": ("✓", "green"),
            "mocked": ("✓", "green"),
            "skipped": ("✓", "green"),
            "failed": ("✗", "red"),
            "user_input_needed": ("⚠", "yellow"),
        }
        symbol, color = symbol_map.get(status, ("•", "dim"))
        timestamp = self._timestamp()
        display = f"{category}: {name}".strip()
        if status == "failed" and reason:
            display = f"{name}: {reason}"
        self._print(f"{timestamp}  {symbol} {display}", style=color)

    def story0_message(self, message: str) -> None:
        """Emit a Story 0 informational message."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        for line in str(message).splitlines():
            self._print(f"{timestamp}  • {line}", style="dim")

    def verification_preflight_started(self, message: str) -> None:
        """Emit verification preflight start message."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(f"{timestamp}  • {message}", style="dim")

    def verification_preflight_installing(self, message: str) -> None:
        """Emit verification preflight install message."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(f"{timestamp}  • {message}", style="dim")

    def verification_preflight_completed(self, message: str) -> None:
        """Emit verification preflight completion message."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(f"{timestamp}  ✓ {message}", style="green")

    def story0_completed(
        self, blocking_failures: int, non_blocking_warnings: int
    ) -> None:
        """Emit Story 0 completion summary."""
        if self.config.verbosity == VerbosityLevel.QUIET:
            if blocking_failures:
                self._print(" blocked")
            else:
                self._print(" ready")
            return
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        if blocking_failures:
            self._print(
                f"{timestamp}  ✗ Environment blocked ({blocking_failures} failures)",
                style="red",
            )
            return
        warning_note = (
            f" ({non_blocking_warnings} warnings)" if non_blocking_warnings else ""
        )
        self._print(f"{timestamp}  ✓ Environment ready{warning_note}", style="green")

    def story0_blocked(self, failures_summary: str) -> None:
        """Emit aggregated Story 0 failure summary (non-TTY)."""
        if not failures_summary:
            return
        self._print(failures_summary)

    def epic_derivation_heartbeat(
        self,
        epic_index: int,
        epic_count: int,
        epic_title: str,
        items_so_far: int,
        elapsed_s: int,
    ) -> None:
        """Emit heartbeat during long per-epic derivation."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        title = epic_title[:40] + "..." if len(epic_title) > 40 else epic_title
        if items_so_far > 0:
            detail = f"{items_so_far} items, {elapsed_s}s"
        else:
            detail = f"{elapsed_s}s"
        self._print(
            f"{timestamp}  Epic {epic_index}/{epic_count}: {title} ({detail})...",
            style="cyan",
        )

    def debug_tokens(
        self,
        total: int,
        input_tokens: int,
        output_tokens: int,
        source: str | None = None,
    ) -> None:
        """Emit token usage details at DETAIL verbosity."""
        if self.config.verbosity < VerbosityLevel.DETAIL:
            return
        source_label = f" [{source}]" if source else ""
        self._print(
            f"Tokens: {total:,} (in: {input_tokens:,}, out: {output_tokens:,}){source_label}",
            style="dim",
        )

    def debug_quality(self, message: str) -> None:
        """Emit quality gate details at DETAIL verbosity."""
        if self.config.verbosity < VerbosityLevel.DETAIL:
            return
        self._print(message, style="dim")

    def stage_failed(
        self,
        stage: str,
        error: str,
        duration_ms: int = 0,
        timeout_s: int | None = None,
    ) -> None:
        """Emit event when a pipeline stage fails."""
        if self._stage_live_active:
            self._print("")
            self._stage_live_active = False
            self._stage_live_last_len = 0
            self._stage_live_last_update_ts = 0.0

        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        duration_sec = duration_ms / 1000.0
        timeout_note = f" timeout={timeout_s}s" if timeout_s else ""
        self._print(
            f"{timestamp}Stage {stage} failed ({duration_sec:.1f}s){timeout_note}: {error}",
            style="bold red",
        )

    def stage_heartbeat(self, stage: str, elapsed_s: int) -> None:
        """Emit heartbeat during long-running stage execution.

        For derive stage, shows current derivation progress in the spinner
        (e.g., "derive running... (2m 30s) [S1 tasks...]").
        """
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        if elapsed_s < 60:
            elapsed_str = f"{elapsed_s}s"
        else:
            mins = elapsed_s // 60
            secs = elapsed_s % 60
            elapsed_str = f"{mins}m {secs}s" if secs > 0 else f"{mins}m"

        timestamp = self._timestamp()

        # Build status indicator based on current LLM activity
        status_indicator = ""
        if self._llm_state == "waiting":
            status_indicator = " [waiting for LLM]"
        elif self._llm_state == "streaming":
            status_indicator = " [LLM streaming...]"
        elif self._llm_state == "processing":
            status_indicator = " [processing]"

        if status_indicator and self._is_tty:
            status_indicator = f"[dim]{status_indicator}[/dim]"

        message = f"{stage} running... ({elapsed_str})"
        if stage == "derive":
            if self._derive_current_step_name == "serialize":
                message = f"Serializing plan... ({elapsed_str})"
            elif self._derive_current_step_name == "tasks":
                message = f"Detailing plan... ({elapsed_str})"
            elif self._derive_current_step_name == "structure":
                message = f"Structuring plan... ({elapsed_str})"
            else:
                message = f"Detailing plan... ({elapsed_str})"
        if self._current_stage_context and self._current_stage_context.get(
            "epic_index"
        ):
            epic_index = self._current_stage_context.get("epic_index")
            epic_count = self._current_stage_context.get("epic_count")
            epic_title = self._current_stage_context.get("epic_title")
            if epic_index and epic_count:
                title = epic_title or "Epic"
                title = title[:40] + "..." if len(title) > 40 else title
                message = f"Epic {epic_index}/{epic_count}: {title} deriving... ({elapsed_str})"

        if self._is_tty:
            # Spinner disabled - it interferes with debug output and doesn't add much value
            # Just print periodic static updates every 30 seconds instead
            now = datetime.now().timestamp()
            if (now - self._stage_live_last_update_ts) < 30.0:  # Only update every 30s
                return
            self._stage_live_last_update_ts = now
            if status_indicator:
                message = f"{message}{status_indicator}"
            self._print(f"{timestamp}{message}", style="cyan")
            return

        now = datetime.now().timestamp()
        last_emit = self._stage_heartbeat_last_emit.get(stage, 0.0)
        if (now - last_emit) < self._stage_heartbeat_emit_interval_s:
            return
        self._stage_heartbeat_last_emit[stage] = now
        message = f"{timestamp}{message}"
        if status_indicator:
            message = f"{message}{status_indicator}"
        self._print(message, style="cyan")

    def story_review_started(
        self,
        story_id: str,
        story_title: str,
        story_index: int,
        total_stories: int,
        task_count: int,
    ) -> None:
        """Emit event when reviewing a story starts."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        # Truncate long titles
        title = story_title[:40] + "..." if len(story_title) > 40 else story_title
        self._print(
            f"{timestamp} Reviewing story {story_index}/{total_stories}: {title} ({task_count} tasks)...",
            style="cyan",
        )

    def story_review_completed(
        self,
        story_id: str,
        story_title: str,
        story_index: int,
        total_stories: int,
        changes_required: bool,
        issue_count: int,
        duration_s: float,
    ) -> None:
        """Emit event when a story review completes."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        # Truncate long titles
        title = story_title[:40] + "..." if len(story_title) > 40 else story_title
        if changes_required:
            status = f"[yellow]{issue_count} issue(s)[/yellow]"
        else:
            status = "[green]OK[/green]"
        self._print(
            self._format_status_line(
                status,
                f"Story {story_index}/{total_stories}: {title} ({duration_s:.1f}s)",
            )
        )

    def intent_alignment_started(self, epic_count: int, story_count: int) -> None:
        """Emit event when intent alignment starts."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(
            f"{timestamp}Checking intent coverage ({epic_count} epic(s), {story_count} story/stories)...",
            style="cyan",
        )

    def intent_story_assessed(
        self,
        story_id: str,
        story_title: str,
        story_index: int,
        total_stories: int,
        status: str,
        note: str,
    ) -> None:
        """Emit event for per-story intent assessment."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        title = story_title[:40] + "..." if len(story_title) > 40 else story_title
        if status == "ok":
            status_str = "[green]OK[/green]"
        elif status == "scope_creep":
            status_str = "[red]SCOPE CREEP[/red]"
        else:
            status_str = f"[yellow]{status.upper()}[/yellow]"
        msg = self._format_status_line(
            status_str, f"Story {story_index}/{total_stories}: {title}"
        )
        if note and status != "ok":
            note_text = note[:50] + "..." if len(note) > 50 else note
            msg += f" - {note_text}"
        self._print(msg)

    def intent_story_added(self, title: str, parent_id: str | None) -> None:
        """Emit event when intent alignment adds a story."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        title_text = title[:50] + "..." if len(title) > 50 else title
        self._print(f"{timestamp}  [green]+[/green] Adding story: {title_text}")

    def intent_alignment_completed(
        self,
        coverage_status: str,
        changes_required: bool,
        missing_count: int,
        scope_creep_count: int,
        stories_added: int,
        stories_removed: int,
        duration_s: float,
    ) -> None:
        """Emit event when intent alignment completes."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        if coverage_status == "pass" or (not changes_required and missing_count == 0):
            status = "[green]OK[/green]"
            detail = ""
        elif coverage_status == "warn":
            status = "[yellow]WARN[/yellow]"
            issues = []
            if missing_count > 0:
                issues.append(f"{missing_count} gap(s)")
            if scope_creep_count > 0:
                issues.append(f"{scope_creep_count} scope creep")
            detail = f" ({', '.join(issues)})" if issues else ""
        else:
            status = "[red]FAIL[/red]"
            issues = []
            if missing_count > 0:
                issues.append(f"{missing_count} gap(s)")
            if scope_creep_count > 0:
                issues.append(f"{scope_creep_count} scope creep")
            detail = f" ({', '.join(issues)})" if issues else ""

        # Show fixes if any were applied
        fixes = []
        if stories_added > 0:
            fixes.append(f"+{stories_added} story/stories")
        if stories_removed > 0:
            fixes.append(f"-{stories_removed} story/stories")
        fix_detail = f" [cyan][{', '.join(fixes)}][/cyan]" if fixes else ""

        self._print(
            self._format_status_line(
                status,
                f"Intent alignment:{detail}{fix_detail} ({duration_s:.1f}s)",
            )
        )

    def intent_alignment_fixes_applied(
        self, stories_added: list[str], stories_removed: list[str]
    ) -> None:
        """Emit event when intent alignment applies fixes."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        if stories_added:
            for title in stories_added:
                self._print(f"{timestamp}  [green]+[/green] Added story: {title}")
        if stories_removed:
            for story_id in stories_removed:
                self._print(f"{timestamp}  [red]-[/red] Removed story: {story_id}")

    def intent_gap_detection_started(self, story_count: int) -> None:
        """Emit event when gap detection starts."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(
            f"{timestamp}Checking for missing requirements ({story_count} stories)...",
            style="cyan",
        )

    def intent_gap_detection_completed(
        self,
        gaps_found: bool,
        missing_count: int,
        stories_to_add: int,
        duration_s: float,
    ) -> None:
        """Emit event when gap detection completes."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        if gaps_found:
            status = "[yellow]GAPS FOUND[/yellow]"
            detail = f" ({missing_count} missing)"
        else:
            status = "[green]OK[/green]"
            detail = ""
        fix_detail = (
            f" [cyan][+{stories_to_add} story/stories][/cyan]"
            if stories_to_add > 0
            else ""
        )
        self._print(
            self._format_status_line(
                status,
                f"Gap detection:{detail}{fix_detail} ({duration_s:.1f}s)",
            )
        )

    def review_issues_found(
        self, story_id: str, story_title: str, issues: list[str]
    ) -> None:
        """Emit event when review finds issues in a story."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        title = story_title[:40] + "..." if len(story_title) > 40 else story_title
        for issue in issues[:3]:  # Show up to 3 issues
            issue_text = issue[:60] + "..." if len(issue) > 60 else issue
            self._print(f"{timestamp}    [dim]- {issue_text}[/dim]")

    def review_no_fixes(self, item_id: str | None = None) -> None:
        """Emit event when review finds no issues (no fixes required)."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        item_label = (
            f" for {item_id}"
            if item_id and self.config.verbosity >= VerbosityLevel.DETAIL
            else ""
        )
        self._print(
            f"{timestamp}No fix required{item_label} (0 findings)", style="green"
        )

    def fix_started(self, issue_count: int) -> None:
        """Emit event when fix pass starts."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(f"{timestamp}Fix started: {issue_count} issue(s)", style="cyan")

    def fix_completed(self, fixed: int, failed: int, skipped: int) -> None:
        """Emit event when fix pass completes."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        self._print(
            f"{timestamp}Fix completed: {fixed} fixed, {failed} failed, {skipped} skipped",
            style="green",
        )
        # Clarify that review will re-evaluate code quality (independent of fix success/failure)
        if self.config.verbosity >= VerbosityLevel.PROGRESS:
            self._print("Re-reviewing current code quality...", style="dim")

    def derivation_step_started(self, step: int, step_name: str) -> None:
        """Emit event when a unified derivation step starts (3-step pipeline).

        Updates step tracking state and prints progress at PROGRESS verbosity.

        Args:
            step: Step number (1, 2, or 3)
            step_name: Step name (e.g., 'structure', 'tasks', 'serialize')
        """
        import time

        # Update tracking state
        self._derive_current_step = step
        self._derive_current_step_name = step_name
        self._derive_step_start_time = time.perf_counter()
        self._derive_last_output_time = time.perf_counter()
        if step_name == "tasks" and not self._plan_mode:
            self._plan_mode = "one-shot"

        # Emit at DETAIL verbosity (internal detail only)
        if self.config.verbosity < VerbosityLevel.DETAIL:
            return

        timestamp = self._timestamp()
        self._print(
            f"{timestamp}Derivation step {step}/3: {step_name}...",
            style="cyan",
        )

    def epic_derivation_started(
        self,
        epic_index: int,
        epic_count: int,
        epic_id: str,
        epic_title: str,
    ) -> None:
        """Emit event when per-epic derivation starts."""
        self._current_stage_context = {
            "epic_index": epic_index,
            "epic_count": epic_count,
            "epic_title": epic_title,
        }
        self._plan_mode = "per-epic"
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        title = epic_title[:40] + "..." if len(epic_title) > 40 else epic_title
        self._print(
            f"{timestamp}  Epic {epic_index}/{epic_count}: {title} (deriving...)",
            style="cyan",
        )

    def epic_derivation_completed(
        self,
        epic_index: int,
        epic_count: int,
        epic_id: str,
        epic_title: str | None,
        stories_derived: int,
        tasks_derived: int,
    ) -> None:
        """Emit event when per-epic derivation completes."""
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._timestamp()
        title = epic_title or epic_id
        title = title[:40] + "..." if len(title) > 40 else title
        self._print(
            f"{timestamp}  Epic {epic_index}/{epic_count}: {title} → {stories_derived} stories, {tasks_derived} tasks",
            style="green",
        )
        self._current_stage_context = None

    def derivation_step_completed(
        self,
        step: int,
        step_name: str,
        duration_ms: int,
        items_produced: int,
        prose: str | None = None,
        raw_json: str | None = None,
    ) -> None:
        """Emit event when a unified derivation step completes.

        Clears step state and emits counts at DETAIL verbosity.

        Args:
            step: Step number (1, 2, or 3)
            step_name: Step name (e.g., 'structure', 'tasks', 'serialize')
            duration_ms: Step duration in milliseconds
            items_produced: Number of items produced by this step
            prose: Optional prose output (for steps 1 and 2) to show at DEBUG
            raw_json: Optional raw JSON (for step 3) to show at DEBUG
        """
        # Clear step state
        self.reset_derive_step_state()

        # Emit user-facing summary at PROGRESS (only for structure step)
        if (
            self.config.verbosity >= VerbosityLevel.PROGRESS
            and step_name == "structure"
        ):
            timestamp = self._timestamp()
            self._print(
                f"{timestamp}✓ Structure: {items_produced} Epics identified",
                style="green",
            )

        if self.config.verbosity >= VerbosityLevel.DETAIL:
            timestamp = self._timestamp()
            self._print(
                f"{timestamp}  └─ {step_name} → {items_produced} items", style="dim"
            )

        # At DEBUG verbosity (>= 3), log full prose or raw JSON
        if self.config.verbosity >= VerbosityLevel.DEBUG:
            if prose:
                self._print(f"[DEBUG] Step {step} prose output:", style="dim")
                # Truncate if too long
                max_chars = 1000
                display_prose = (
                    prose if len(prose) <= max_chars else prose[:max_chars] + "..."
                )
                self._print(display_prose, style="dim")
            elif raw_json:
                self._print(f"[DEBUG] Step {step} raw JSON:", style="dim")
                # Truncate if too long
                max_chars = 1000
                display_json = (
                    raw_json
                    if len(raw_json) <= max_chars
                    else raw_json[:max_chars] + "..."
                )
                self._print(display_json, style="dim")

    def derivation_step_failed(
        self, step: int, step_name: str, error: str, duration_ms: int
    ) -> None:
        """Emit event when a unified derivation step fails.

        Args:
            step: Step number (1, 2, or 3)
            step_name: Step name (e.g., 'structure', 'tasks', 'serialize')
            error: Error message
            duration_ms: Step duration in milliseconds
        """
        # Clear step state
        self.reset_derive_step_state()

        # Emit at PROGRESS verbosity
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        duration_sec = duration_ms / 1000.0
        timestamp = self._timestamp()
        self._print(
            f"{timestamp}[derive] Step {step}/3 ({step_name}) failed after {duration_sec:.1f}s: {error}",
            style="red",
        )

    def derivation_stall_warning(
        self, step: int, step_name: str, no_output_seconds: int
    ) -> None:
        """Emit warning when derivation step appears stalled (no output for threshold).

        Args:
            step: Step number (1, 2, or 3)
            step_name: Step name (e.g., 'structure', 'tasks', 'serialize')
            no_output_seconds: Number of seconds without output
        """
        # Emit at PROGRESS verbosity
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._timestamp()
        self._print(
            f"{timestamp}[derive] Step {step}/3 ({step_name}) appears stalled "
            f"(no output for {no_output_seconds}s)...",
            style="yellow",
        )

    def derivation_streaming_heartbeat(self, step: int, elapsed_seconds: int) -> None:
        """Update spinner during long derivation step with streaming output.

        Args:
            step: Step number (1, 2, or 3)
            elapsed_seconds: Elapsed seconds since step start
        """
        # Only update spinner at PROGRESS verbosity
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # Update spinner (no print, just internal state for potential future use)
        self._spinner_index = (self._spinner_index + 1) % len(self._spinner_chars)

    def derivation_validation_started(self, pass_num: int, max_passes: int) -> None:
        """Emit event when plan validation/refinement starts.

        Args:
            pass_num: Current validation pass number (1-indexed)
            max_passes: Maximum number of validation passes
        """
        # Emit at PROGRESS verbosity
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._timestamp()
        self._print(
            f"{timestamp}[derive] Validating plan... (pass {pass_num}/{max_passes})",
            style="cyan",
        )

    def derivation_validation_completed(
        self, pass_num: int, violations: int, passed: bool
    ) -> None:
        """Emit event when plan validation/refinement completes.

        Args:
            pass_num: Current validation pass number (1-indexed)
            violations: Number of validation violations found
            passed: Whether validation passed (no violations)
        """
        # Emit at PROGRESS verbosity (>= 1) - surface validation progress at -v
        if self.config.verbosity < VerbosityLevel.PROGRESS:
            return

        if passed:
            self._print(
                self._format_status_line(
                    "[green]✓[/green]",
                    f"Validation passed (pass {pass_num})",
                ),
                style=None,
            )
        else:
            self._print(
                self._format_status_line(
                    "[yellow]![/yellow]",
                    f"Validation found {violations} issues (pass {pass_num})",
                ),
                style=None,
            )

    def llm_started(self, purpose: str) -> None:
        """Emit event when an LLM invocation starts.

        Args:
            purpose: Description of what the LLM is being asked to do
        """
        self.set_llm_state("waiting")

        if self.config.verbosity < VerbosityLevel.DETAIL:
            return

        timestamp = self._timestamp()
        self._print(f"{timestamp}LLM invocation: {purpose}", style="yellow")

    def llm_streaming(self, chunk: str) -> None:
        """Emit LLM response chunk during streaming.

        Args:
            chunk: Text chunk from the streaming LLM response
        """
        self.set_llm_state("streaming")

        if not self.config.stream:
            return

        # Stream output with [LLM] prefix
        # Don't add timestamp per chunk (would be noisy)
        if self._is_tty:
            self.console.print(f"  [LLM] {chunk}", end="", style="blue")
        else:
            # Line-by-line for non-TTY (no streaming animation)
            self.console.print(f"  [LLM] {chunk}")

    def llm_completed(self, summary: str, tokens: int = 0) -> None:
        """Emit event when an LLM invocation completes.

        Args:
            summary: Summary of the LLM response
            tokens: Token count for the response
        """
        if self.config.verbosity < VerbosityLevel.DETAIL:
            self.set_llm_state("idle")
            return

        timestamp = self._timestamp()
        token_info = f" ({tokens} tokens)" if tokens > 0 else ""
        self._print(f"{timestamp}LLM complete{token_info}: {summary}", style="green")

        if self.config.verbosity >= VerbosityLevel.DEBUG:
            self._print(f"[DEBUG] Token count: {tokens}", style="dim")

        self.set_llm_state("idle")

    def item_started(self, item: dict) -> None:
        """Emit event when processing a plan item starts.

        Args:
            item: Plan item being processed
        """
        item_id = item.get("id", "?")
        normalized_id = str(item_id).strip()
        if normalized_id and normalized_id != "?":
            self._plan_status[normalized_id] = "in_progress"
        item_title = item.get("title", "")
        normalized_title = str(item_title).strip()
        if normalized_id and normalized_id != "?":
            self._task_tracker_current_id = normalized_id
            if normalized_title:
                self._task_tracker_current_title = normalized_title
            if normalized_id not in self._task_tracker_index:
                self._task_tracker_items.append(
                    {"id": normalized_id, "title": normalized_title}
                )
                self._task_tracker_index[normalized_id] = (
                    len(self._task_tracker_items) - 1
                )
            elif normalized_title and not self._task_tracker_items[
                self._task_tracker_index[normalized_id]
            ].get("title"):
                self._task_tracker_items[self._task_tracker_index[normalized_id]][
                    "title"
                ] = normalized_title
        progress_prefix = ""
        if self._total_tasks > 0:
            display_index = self._current_task_index + 1
            progress_prefix = f"[Attempt {display_index}/{self._total_tasks}] "

        # Level 0 (QUIET): Show minimal "Executing TX..."
        if self.config.verbosity == VerbosityLevel.QUIET:
            self._print(f"{progress_prefix}Executing {item_id}...", end="")
            if self._total_tasks > 0:
                self._current_task_index += 1
            return

        # Level 1 (PROGRESS): Show item with title
        if self.config.verbosity == VerbosityLevel.PROGRESS:
            timestamp = self._timestamp()
            item_title = item.get("title", "")
            if item_title:
                self._print(
                    f"{progress_prefix}{timestamp}Executing {item_id}: {item_title}...",
                    style="cyan",
                )
            else:
                self._print(
                    f"{progress_prefix}{timestamp}Executing {item_id}...", style="cyan"
                )
            if self._total_tasks > 0:
                self._current_task_index += 1
            self.render_task_tracker()
            return

        # Level 2+ (DETAIL and above): Show full details
        timestamp = self._timestamp()
        item_title = item.get("title", "untitled")
        self._print(f"{timestamp}Item {item_id}: {item_title}", style="cyan")

        if self.config.verbosity >= VerbosityLevel.DEBUG:
            # Truncate verbose item output
            item_str = str(item)
            max_chars = 300
            display_item = (
                item_str if len(item_str) <= max_chars else item_str[:max_chars] + "..."
            )
            self._print(f"[DEBUG] Full item: {display_item}", style="dim")
        self.render_task_tracker()

    def item_completed(self, item: dict, result: dict | None = None) -> None:
        """Emit event when processing a plan item completes.

        Args:
            item: Plan item that was processed
            result: Optional result data from processing
        """
        item_id = item.get("id", "?")
        normalized_id = str(item_id).strip()
        if normalized_id and normalized_id != "?":
            self._task_tracker_done.add(normalized_id)
            if self._task_tracker_current_id == normalized_id:
                self._task_tracker_current_id = None
                self._task_tracker_current_title = None
            status = self._normalize_status(
                str((result or {}).get("status", "")).strip()
            )
            if status == "pending":
                status = "completed"
            self._plan_status[normalized_id] = status
            self._maybe_render_story_completion(normalized_id)

        # Level 0 (QUIET): Complete the line with " done"
        if self.config.verbosity == VerbosityLevel.QUIET:
            self._print(" done")
            return

        # Level 1 (PROGRESS): Show completion with timestamp
        if self.config.verbosity == VerbosityLevel.PROGRESS:
            timestamp = self._timestamp()
            self._print(f"{timestamp}{item_id} complete", style="green")
            self.render_task_tracker()
            return

        # Level 2+ (DETAIL and above): Show full details
        timestamp = self._timestamp()
        self._print(f"{timestamp}Item {item_id} complete", style="green")

        if self.config.verbosity >= VerbosityLevel.DEBUG and result:
            # Truncate verbose result output
            result_str = str(result)
            max_chars = 300
            display_result = (
                result_str
                if len(result_str) <= max_chars
                else result_str[:max_chars] + "..."
            )
            self._print(f"[DEBUG] Result: {display_result}", style="dim")
        self.render_task_tracker()

    def item_heartbeat(
        self,
        item_id: str,
        elapsed_s: int,
        file_count: int,
        liveness_indicators: dict | None = None,
    ) -> None:
        """Emit heartbeat during long-running item execution.

        Args:
            item_id: ID of the item being executed
            elapsed_s: Seconds elapsed since execution started
            file_count: Number of files changed so far
            liveness_indicators: Optional dict with liveness status (DETAIL level only)
                                 Expected keys: log, cpu, files, db, proc (bool values)
        """
        self._heartbeat_count += 1
        # Note: Footer hint removed from heartbeat - was too noisy
        # Footer now shows only at start and completion

        # QUIET (0): No heartbeat output
        if self.config.verbosity == VerbosityLevel.QUIET:
            return

        # Format elapsed time in human-readable format
        if elapsed_s < 60:
            elapsed_str = f"{elapsed_s}s"
        else:
            mins = elapsed_s // 60
            secs = elapsed_s % 60
            elapsed_str = f"{mins}m {secs}s" if secs > 0 else f"{mins}m"

        timestamp = self._timestamp()

        # PROGRESS (1): Show heartbeat with elapsed time and file count
        if self.config.verbosity == VerbosityLevel.PROGRESS:
            file_summary = self.get_file_summary()
            llm_indicator = ""
            if self._llm_state == "waiting":
                llm_indicator = " [waiting for LLM]"
            elif self._llm_state == "streaming":
                llm_indicator = " [LLM streaming...]"
            elif self._llm_state == "processing":
                llm_indicator = " [processing]"
            if llm_indicator and self._is_tty:
                llm_indicator = f"[dim]{llm_indicator}[/dim]"
            if self._is_tty:
                spinner = self._next_spinner()
                message = f"{spinner} {item_id} executing... ({elapsed_str})"
            else:
                message = f"{timestamp}{item_id} executing... ({elapsed_str})"
            if file_summary:
                message = f"{message} | {file_summary}"
            if llm_indicator:
                message = f"{message}{llm_indicator}"
            self._print(message, style="cyan")
            if self._task_tracker_current_id:
                self.render_task_tracker()
            return

        # DETAIL (2+): Show heartbeat with liveness indicators
        if self.config.verbosity >= VerbosityLevel.DETAIL:
            file_str = f", {file_count} files" if file_count > 0 else ""
            base_msg = f"{timestamp}{item_id} executing... ({elapsed_str}{file_str})"

            # Add liveness indicators if provided
            if liveness_indicators:
                indicators = []
                for key in ["log", "cpu", "files", "db", "proc"]:
                    value = liveness_indicators.get(key, False)
                    indicators.append(f"{key}={'Y' if value else 'N'}")
                liveness_str = " [liveness: " + " ".join(indicators) + "]"
                self._print(base_msg + liveness_str, style="cyan")
            else:
                self._print(base_msg, style="cyan")
            if self._task_tracker_current_id:
                self.render_task_tracker()

    def file_event(
        self,
        filepath: str,
        event_type: str,
        line_count: int | None = None,
    ) -> None:
        """Emit file change event.

        Args:
            filepath: Path to the file that changed (relative to working dir)
            event_type: Type of event - "new" or "modified"
            line_count: Number of lines in the file (DETAIL level only)
        """
        # FIX-FILE-TRACKING-001: Filter out build artifacts from file tracking
        # These are generated files that shouldn't inflate file activity counts
        excluded_patterns = (
            "build/",
            "dist/",
            "__pycache__/",
            ".coverage",
            ".pytest_cache/",
            ".tox/",
            ".egg-info/",
            "node_modules/",
            ".pyc",
            ".pyo",
            ".pyz",
            ".pkg",
            ".toc",
            ".zip",
        )
        if any(pattern in filepath for pattern in excluded_patterns):
            return  # Skip build artifacts

        if event_type == "new":
            self.track_file_created()
        elif event_type == "modified":
            self.track_file_modified()

        # QUIET (0): No file events
        if self.config.verbosity == VerbosityLevel.QUIET:
            return

        # PROGRESS (1): Show file event with type indicator
        timestamp = self._timestamp()
        symbol = "+" if event_type == "new" else "~"

        if self.config.verbosity == VerbosityLevel.PROGRESS:
            self._print(f"{timestamp}  {symbol} {filepath} ({event_type})", style="dim")
            return

        # DETAIL (2+): Show file event with line count
        if self.config.verbosity >= VerbosityLevel.DETAIL:
            if line_count is not None:
                self._print(
                    f"{timestamp}  {symbol} {filepath} ({event_type}, {line_count} lines)",
                    style="dim",
                )
            else:
                self._print(
                    f"{timestamp}  {symbol} {filepath} ({event_type})", style="dim"
                )

    def render_file_list(self, recent_files: list[str], max_display: int = 5) -> None:
        """Render a recent file list at DETAIL verbosity and above.

        Args:
            recent_files: Recent file paths to display
            max_display: Max entries to show before truncating
        """
        if self.config.verbosity < VerbosityLevel.DETAIL:
            return

        if not recent_files:
            return

        if len(recent_files) > max_display:
            display_limit = max(max_display - 1, 0)
            visible_files = recent_files[:display_limit]
            remaining = len(recent_files) - display_limit
            file_list = ", ".join(visible_files)
            if file_list:
                file_list = f"{file_list}, ... and {remaining} more"
            else:
                file_list = f"... and {remaining} more"
        else:
            file_list = ", ".join(recent_files[:max_display])
            if not file_list:
                return

        self._print(f"    └─ Recent: {file_list}", style="dim")

    def error(
        self,
        message: str,
        hint: str | None = None,
        phase: str | None = None,
        affected_items: list | None = None,
        stack_trace: str | None = None,
        raw_response: dict | None = None,
    ) -> None:
        """Display error with detail based on verbosity level.

        Args:
            message: Error message
            hint: Recovery hint (shown at all levels)
            phase: Current phase when error occurred (shown at PROGRESS+)
            affected_items: Plan items affected by error (shown at DETAIL+)
            stack_trace: Full stack trace (shown at DEBUG only)
            raw_response: Raw server/LLM response (shown at DEBUG only)
        """
        timestamp = self._timestamp()

        # Level 0 (QUIET): Basic error + hint
        self._print(f"Error: {message}", style="bold red")
        if hint:
            self._print(f"Hint: {hint}", style="yellow")

        # Level 1 (PROGRESS): + timestamp + phase context
        if self.config.verbosity >= VerbosityLevel.PROGRESS:
            if timestamp:
                self._print(f"{timestamp}Error occurred", style="dim")
            if phase:
                self._print(f"Phase: {phase}", style="dim")

        # Level 2 (DETAIL): + affected items
        if self.config.verbosity >= VerbosityLevel.DETAIL and affected_items:
            self._print("Affected items:", style="yellow")
            for item in affected_items:
                item_id = item.get("id", "?")
                item_title = item.get("title", "untitled")
                self._print(f"  - {item_id}: {item_title}", style="dim")

        # Level 3 (DEBUG): + stack trace + raw response
        if self.config.verbosity >= VerbosityLevel.DEBUG:
            if stack_trace:
                self._print("[DEBUG] Stack trace:", style="dim")
                for line in str(stack_trace).splitlines():
                    self._print(line, style="dim")
            if raw_response:
                self._print("[DEBUG] Raw response:", style="dim")
                self._print(str(raw_response), style="dim")

    def warning(self, message: str) -> None:
        """Display a warning message."""
        timestamp = self._timestamp()
        if self.config.verbosity >= VerbosityLevel.PROGRESS and timestamp:
            self._print(f"{timestamp}Warning", style="dim")
        self._print(f"Warning: {message}", style="yellow")

    def interactive_guard_notice(
        self,
        message: str,
        affected_items: list[dict] | None = None,
        stack_trace: str | None = None,
        raw_response: str | None = None,
    ) -> None:
        """Display an interactive guard notice."""
        timestamp = self._timestamp()
        if self.config.verbosity >= VerbosityLevel.PROGRESS and timestamp:
            self._print(f"{timestamp}Interactive guard", style="dim")
        self._print(f"Interactive guard: {message}", style="yellow")

        # Level 2 (DETAIL): + affected items + partial results
        if self.config.verbosity >= VerbosityLevel.DETAIL and affected_items:
            self._print("Affected items:", style="yellow")
            for item in affected_items:
                item_id = item.get("id", "?")
                item_title = item.get("title", "unknown")
                self._print(f"  - {item_id}: {item_title}", style="dim")

        # Level 3 (DEBUG): + stack trace + raw response
        if self.config.verbosity >= VerbosityLevel.DEBUG:
            if stack_trace:
                self._print("[DEBUG] Stack trace:", style="dim")
                for line in stack_trace.split("\n"):
                    if line.strip():
                        self._print(f"  {line}", style="dim")
            if raw_response:
                self._print(f"[DEBUG] Raw response: {raw_response}", style="dim")
