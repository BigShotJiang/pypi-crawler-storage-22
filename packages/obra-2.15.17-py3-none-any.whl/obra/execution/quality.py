"""Quality assessment handler for UserPlan evaluation.

This module provides the quality assessment handler that evaluates UserPlan
quality using LLM and returns structured assessment results.

The handler:
    1. Accepts a UserPlan and optional threshold
    2. Uses LLM with quality assessment prompt (via template edit pattern)
    3. Parses structured response (score + hints)
    4. Returns assessment with score, status, and hints
    5. Handles LLM errors gracefully (defaults to NOT_ASSESSED)

Example:
    >>> from obra.llm.invoker import LLMInvoker
    >>> from obra.execution.quality import assess_user_plan_quality
    >>> assessment = await assess_user_plan_quality(
    ...     user_plan=my_plan,
    ...     llm_invoker=LLMInvoker(),
    ...     threshold=0.6
    ... )
    >>> print(f"Score: {assessment.score}, Status: {assessment.status}")

Related:
    - obra/schemas/userplan_schema.py (UserPlan, QualityStatus)
    - obra/execution/prompts/quality_assessment.py (prompt template)
    - obra/execution/intent_to_userplan.py (similar pattern)
"""

import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from obra.execution.prompts.quality_assessment import build_quality_assessment_prompt
from obra.hybrid.json_utils import parse_planning_json_response
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.schemas.userplan_schema import QualityStatus, UserPlan

if TYPE_CHECKING:
    from obra.llm.invoker import LLMInvoker

logger = logging.getLogger(__name__)

# Constants for quality assessment
DEFAULT_QUALITY_THRESHOLD = 0.6
GENERATED_PLAN_QUALITY_THRESHOLD = 0.4  # Relaxed threshold for Obra-generated plans
MIN_HINTS = 0
MAX_HINTS = 10
MIN_SCORE = 0.0
MAX_SCORE = 1.0


@dataclass
class AssessmentConfig:
    """Configuration for quality assessment LLM invocation.

    Attributes:
        thinking_enabled: Whether to use extended thinking
        thinking_level: Thinking level (off, minimal, standard, high, maximum)
        provider: LLM provider to use
        model: Model to use (default for provider if not specified)
        auth_method: Authentication method ("oauth" or "api_key").
            When "oauth", uses CLI runner instead of direct SDK to support
            OAuth authentication without API keys.
        working_dir: Working directory for CLI runner (required when auth_method="oauth")
    """

    thinking_enabled: bool = False
    thinking_level: str = "minimal"
    provider: str = "anthropic"
    model: str = "sonnet"
    auth_method: str = "api_key"
    working_dir: str | None = None


@dataclass
class QualityAssessment:
    """Result from UserPlan quality assessment.

    Attributes:
        score: Quality score from 0.0 to 1.0 (None if not assessed)
        status: QualityStatus indicating pass/fail/skipped/not_assessed
        hints: List of improvement suggestions
        threshold: Threshold used for pass/fail determination
        raw_response: Raw LLM response for debugging
        duration_seconds: Time taken for assessment
        tokens_used: Tokens used in LLM call
        error_message: Error message if assessment failed
    """

    score: float | None = None
    status: QualityStatus = QualityStatus.NOT_ASSESSED
    hints: list[str] = field(default_factory=list)
    threshold: float = DEFAULT_QUALITY_THRESHOLD
    raw_response: str = ""
    duration_seconds: float = 0.0
    tokens_used: int = 0
    error_message: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "score": self.score,
            "status": self.status.value,
            "hints": self.hints,
            "threshold": self.threshold,
            "raw_response": self.raw_response,
            "duration_seconds": self.duration_seconds,
            "tokens_used": self.tokens_used,
            "error_message": self.error_message,
        }

    @property
    def passed(self) -> bool:
        """Check if assessment passed threshold."""
        return self.status == QualityStatus.PASSED

    @property
    def needs_improvement(self) -> bool:
        """Check if plan needs improvement."""
        return self.status == QualityStatus.FAILED and len(self.hints) > 0


def get_threshold_for_userplan(user_plan: UserPlan) -> float:
    """Determine the appropriate quality threshold for a UserPlan.

    Returns a relaxed threshold for Obra-generated plans (source.generated=True)
    and the standard threshold for user-provided plans.

    The thresholds are configurable via:
    - Environment variables: OBRA_QUALITY_THRESHOLD, OBRA_GENERATED_PLAN_QUALITY_THRESHOLD
    - Config file: quality.threshold, quality.generated_plan_threshold

    Args:
        user_plan: UserPlan to determine threshold for

    Returns:
        Appropriate quality threshold (0.0 to 1.0)

    Example:
        >>> user_plan = UserPlan(source=UserPlanSource(generated=True, ...))
        >>> threshold = get_threshold_for_userplan(user_plan)
        >>> # Returns 0.4 (relaxed threshold for generated plans)
    """
    from obra.config.loaders import (
        get_generated_plan_quality_threshold,
        get_quality_threshold,
    )

    # Check if UserPlan was generated by Obra
    is_generated = user_plan.source.generated if user_plan.source else False

    if is_generated:
        threshold = get_generated_plan_quality_threshold()
        logger.debug(
            "Using relaxed threshold %.2f for Obra-generated UserPlan %s",
            threshold,
            user_plan.id,
        )
    else:
        threshold = get_quality_threshold()
        logger.debug(
            "Using standard threshold %.2f for user-provided UserPlan %s",
            threshold,
            user_plan.id,
        )

    return threshold


async def assess_user_plan_quality(
    user_plan: UserPlan,
    llm_invoker: "LLMInvoker | None" = None,
    threshold: float = DEFAULT_QUALITY_THRESHOLD,
    config: AssessmentConfig | None = None,
) -> QualityAssessment:
    """Assess the quality of a UserPlan using LLM.

    Evaluates the UserPlan against quality criteria and returns a structured
    assessment with score, status, and improvement hints.

    Args:
        user_plan: UserPlan to assess
        llm_invoker: LLMInvoker instance for LLM calls (optional)
        threshold: Score threshold for PASSED status (default 0.6)
        config: LLM configuration (thinking, provider). Defaults to AssessmentConfig().

    Returns:
        QualityAssessment with score, status, and hints

    Example:
        >>> assessment = await assess_user_plan_quality(
        ...     user_plan=my_plan,
        ...     llm_invoker=LLMInvoker(),
        ...     threshold=0.6
        ... )
        >>> if assessment.passed:
        ...     print("Plan is ready for derivation")
        ... else:
        ...     for hint in assessment.hints:
        ...         print(f"- {hint}")
    """
    start_time = time.time()

    # Use default config if not provided
    cfg = config or AssessmentConfig()

    # Validate threshold
    if not MIN_SCORE <= threshold <= MAX_SCORE:
        logger.warning(
            f"Invalid threshold {threshold}, using default {DEFAULT_QUALITY_THRESHOLD}"
        )
        threshold = DEFAULT_QUALITY_THRESHOLD

    # Check if we can proceed based on auth method
    # OAuth mode uses CLI runner (no llm_invoker needed)
    # API key mode requires llm_invoker
    use_cli = cfg.auth_method == "oauth"

    if not use_cli and llm_invoker is None:
        logger.warning(
            "No LLM invoker provided and not using OAuth, returning NOT_ASSESSED"
        )
        return QualityAssessment(
            status=QualityStatus.NOT_ASSESSED,
            threshold=threshold,
            duration_seconds=time.time() - start_time,
            error_message="No LLM invoker provided",
        )

    if use_cli and cfg.working_dir is None:
        logger.warning(
            "OAuth mode requires working_dir in config, returning NOT_ASSESSED"
        )
        return QualityAssessment(
            status=QualityStatus.NOT_ASSESSED,
            threshold=threshold,
            duration_seconds=time.time() - start_time,
            error_message="working_dir required for OAuth mode",
        )

    try:
        # Build prompt from UserPlan
        prompt = _build_assessment_prompt(user_plan)

        # Invoke LLM in thread pool to keep event loop responsive
        # This allows asyncio.wait_for() timeout to work properly
        # See ISSUE-HYBRID-002: _invoke_llm is synchronous and blocks the event loop
        import asyncio

        if use_cli:
            # OAuth mode: use template edit pipeline which handles OAuth auth
            # and eliminates preamble contamination issues
            logger.info(
                "Using template pipeline for quality assessment (auth_method=oauth)"
            )
            result_data, tokens_used = await asyncio.to_thread(
                _invoke_llm_via_template_pipeline,
                prompt,
                cfg,
            )
            # Extract score and hints from parsed result
            score = result_data.get("score")
            if score is not None:
                try:
                    score = float(score)
                    score = max(MIN_SCORE, min(MAX_SCORE, score))
                except (TypeError, ValueError):
                    score = None
            hints = result_data.get("hints", [])
            if not isinstance(hints, list):
                hints = []
            else:
                hints = [str(h) for h in hints if h][:MAX_HINTS]
            raw_response = json.dumps(result_data)
        else:
            # API key mode: use direct SDK via LLMInvoker
            raw_response, tokens_used = await asyncio.to_thread(
                _invoke_llm,
                llm_invoker,
                prompt,
                cfg,
            )
            # Parse response using legacy parser for SDK mode
            score, hints = _parse_assessment_response(raw_response)

        # Determine status based on score vs threshold
        if score is None:
            status = QualityStatus.NOT_ASSESSED
        elif score >= threshold:
            status = QualityStatus.PASSED
        else:
            status = QualityStatus.FAILED

        duration = time.time() - start_time
        logger.info(
            f"Quality assessment complete: score={score}, status={status.value}, "
            f"hints={len(hints)}, duration={duration:.2f}s, tokens={tokens_used}"
        )

        return QualityAssessment(
            score=score,
            status=status,
            hints=hints,
            threshold=threshold,
            raw_response=raw_response,
            duration_seconds=duration,
            tokens_used=tokens_used,
        )

    except Exception as exc:
        duration = time.time() - start_time
        error_msg = str(exc)
        logger.exception(f"Quality assessment failed: {error_msg}")

        # Return NOT_ASSESSED on error (graceful degradation)
        return QualityAssessment(
            status=QualityStatus.NOT_ASSESSED,
            threshold=threshold,
            duration_seconds=duration,
            error_message=error_msg,
        )


async def assess_user_plan_quality_with_timeout(
    user_plan: UserPlan,
    llm_invoker: "LLMInvoker | None" = None,
    threshold: float = DEFAULT_QUALITY_THRESHOLD,
    config: AssessmentConfig | None = None,
    timeout: float | None = None,
) -> QualityAssessment:
    """Assess UserPlan quality with timeout enforcement.

    Wraps assess_user_plan_quality with asyncio.wait_for() to prevent
    indefinite blocking when LLM providers become unresponsive.

    This function was added to fix ISSUE-HYBRID-002: Quality assessment
    LLM call hangs indefinitely without timeout.

    Args:
        user_plan: UserPlan to assess
        llm_invoker: LLMInvoker instance for LLM calls (optional)
        threshold: Score threshold for PASSED status (default 0.6)
        config: LLM configuration (thinking, provider). Defaults to AssessmentConfig().
        timeout: Maximum seconds to wait for assessment. Defaults to get_llm_api_timeout().

    Returns:
        QualityAssessment with score, status, and hints.
        Returns NOT_ASSESSED status on timeout with appropriate error message.

    Example:
        >>> from obra.config import get_llm_api_timeout
        >>> assessment = await assess_user_plan_quality_with_timeout(
        ...     user_plan=my_plan,
        ...     llm_invoker=LLMInvoker(),
        ...     threshold=0.6,
        ...     timeout=get_llm_api_timeout()
        ... )
    """
    import asyncio

    from obra.config import get_llm_api_timeout

    start_time = time.time()

    # Use default timeout if not provided (configurable via orchestration.timeouts.llm_request)
    effective_timeout = timeout if timeout is not None else get_llm_api_timeout()

    try:
        # Wrap the assessment call with timeout
        assessment = await asyncio.wait_for(
            assess_user_plan_quality(
                user_plan=user_plan,
                llm_invoker=llm_invoker,
                threshold=threshold,
                config=config,
            ),
            timeout=effective_timeout,
        )
        return assessment

    except asyncio.TimeoutError:
        duration = time.time() - start_time
        error_msg = (
            f"Quality assessment timed out after {effective_timeout:.1f} seconds"
        )
        logger.warning(error_msg)

        return QualityAssessment(
            status=QualityStatus.NOT_ASSESSED,
            threshold=threshold,
            duration_seconds=duration,
            error_message=error_msg,
        )


def _build_assessment_prompt(user_plan: UserPlan) -> str:
    """Build the quality assessment prompt from UserPlan.

    Args:
        user_plan: UserPlan to assess

    Returns:
        Formatted prompt string
    """
    # Convert steps to dict format for prompt builder
    steps = []
    for step in user_plan.steps:
        step_dict: dict[str, Any] = {
            "title": step.title,
            "description": step.description,
        }
        if step.context:
            step_dict["context"] = {
                "deliverables": step.context.deliverables,
                "success_criteria": step.context.success_criteria,
                "requirements": step.context.requirements,
            }
        steps.append(step_dict)

    # Convert context to dict format
    context_dict = None
    if user_plan.context:
        context_dict = {
            "deliverables": user_plan.context.deliverables,
            "success_criteria": user_plan.context.success_criteria,
            "requirements": user_plan.context.requirements,
            "tech_stack": user_plan.context.tech_stack,
            "constraints": user_plan.context.constraints,
            "assumptions": user_plan.context.assumptions,
        }

    return build_quality_assessment_prompt(
        plan_id=user_plan.id,
        work_type=user_plan.work_type.value if user_plan.work_type else None,
        steps=steps,
        context=context_dict,
    )


def _invoke_llm(
    llm_invoker: "LLMInvoker",
    prompt: str,
    config: AssessmentConfig,
) -> tuple[str, int]:
    """Invoke LLM for quality assessment using direct SDK.

    Args:
        llm_invoker: LLMInvoker instance
        prompt: Assessment prompt
        config: Assessment configuration with LLM settings

    Returns:
        Tuple of (raw_response, tokens_used)
    """
    # Determine thinking level
    level = config.thinking_level if config.thinking_enabled else None

    # Invoke LLM
    result = llm_invoker.invoke(
        prompt=prompt,
        provider=config.provider,
        thinking_level=level,
        response_format="json",
    )

    return result.content, result.tokens_used


def _invoke_llm_via_template_pipeline(
    prompt: str,
    config: AssessmentConfig,
) -> tuple[dict[str, Any], int]:
    """Invoke LLM for quality assessment using template edit pattern.

    This function uses TemplateEditPipeline to eliminate preamble contamination
    issues that occur when LLMs add prose before JSON output.

    Uses file editing (tool action, structural) instead of text response parsing,
    ensuring reliable JSON extraction.

    Args:
        prompt: Assessment prompt
        config: Assessment configuration with LLM settings.
            Must have working_dir set when auth_method="oauth".

    Returns:
        Tuple of (parsed_result_dict, tokens_estimate)

    Raises:
        ValueError: If working_dir is not set when auth_method="oauth"
    """
    if config.working_dir is None:
        raise ValueError(
            "working_dir is required in AssessmentConfig when using auth_method='oauth'"
        )

    working_dir = Path(config.working_dir)

    # Determine thinking level
    level = config.thinking_level if config.thinking_enabled else "off"

    # Create template edit pipeline
    pipeline = TemplateEditPipeline(
        working_dir=working_dir,
        action_name="quality_assessment",
        max_retries=2,
    )

    # Template schema for quality assessment
    template_schema = {
        "score": 0.0,
        "hints": [],
        "_instructions": (
            "Assess the UserPlan quality and fill in:\n"
            "- score: Float from 0.0 to 1.0 indicating overall quality\n"
            "- hints: List of specific improvement suggestions (max 10)"
        ),
    }

    def validator(data: dict) -> tuple[bool, str | None]:
        score = data.get("score")
        if score is not None:
            try:
                score_val = float(score)
                if not 0.0 <= score_val <= 1.0:
                    return (
                        False,
                        f"score must be between 0.0 and 1.0, got {score_val}",
                    )
            except (TypeError, ValueError):
                return (False, f"score must be a number, got {type(score).__name__}")
        hints = data.get("hints")
        if hints is not None and not isinstance(hints, list):
            return (False, f"hints must be a list, got {type(hints).__name__}")
        return (True, None)

    def fallback() -> dict:
        return {"score": None, "hints": []}

    result_data, metadata = pipeline.execute(
        base_prompt=prompt,
        template_schema=template_schema,
        validator=validator,
        fallback_fn=fallback,
        llm_config={
            "provider": config.provider,
            "model": config.model,
            "thinking": level,
            "auth": config.auth_method,
        },
    )

    if metadata.get("status") == "template_fallback":
        logger.warning("Quality assessment used fallback after retries")

    # Estimate tokens (pipeline doesn't track this)
    tokens_estimate = len(prompt) // 4 + 100  # rough estimate
    return result_data, tokens_estimate


def _parse_assessment_response(raw_response: str) -> tuple[float | None, list[str]]:
    """Parse the LLM assessment response.

    Extracts score and hints from the JSON response.

    Args:
        raw_response: Raw LLM response string

    Returns:
        Tuple of (score, hints) where score may be None on parse failure
    """
    if not raw_response or not raw_response.strip():
        logger.warning("Empty LLM response for quality assessment")
        return None, []

    data, error_reason = parse_planning_json_response(raw_response)
    if error_reason:
        logger.warning("Failed to parse quality assessment JSON: %s", error_reason)
        return None, []

    # Validate response structure
    if not isinstance(data, dict):
        logger.warning("Quality assessment response is not a dict")
        return None, []

    # Extract score
    score = data.get("score")
    if score is not None:
        try:
            score = float(score)
            # Clamp to valid range
            score = max(MIN_SCORE, min(MAX_SCORE, score))
        except (TypeError, ValueError) as e:
            logger.warning(f"Invalid score value: {score}, error: {e}")
            score = None

    # Extract hints
    hints = data.get("hints", [])
    if not isinstance(hints, list):
        logger.warning(f"Hints is not a list: {type(hints)}")
        hints = []
    else:
        # Filter to valid strings and limit count
        hints = [str(h) for h in hints if h][:MAX_HINTS]

    return score, hints


def apply_assessment_to_userplan(
    user_plan: UserPlan,
    assessment: QualityAssessment,
) -> UserPlan:
    """Apply quality assessment results to a UserPlan.

    Updates the UserPlan's quality fields based on assessment results.
    Returns a new UserPlan instance (immutable update pattern).

    Args:
        user_plan: Original UserPlan
        assessment: Quality assessment results

    Returns:
        New UserPlan with quality fields updated

    Example:
        >>> assessment = await assess_user_plan_quality(plan, invoker)
        >>> updated_plan = apply_assessment_to_userplan(plan, assessment)
        >>> print(updated_plan.quality_status)
    """
    return UserPlan(
        id=user_plan.id,
        project_id=user_plan.project_id,
        session_id=user_plan.session_id,
        version=user_plan.version,
        etag=user_plan.etag,
        created_at=user_plan.created_at,
        updated_at=user_plan.updated_at,
        status=user_plan.status,
        source=user_plan.source,
        quality_score=assessment.score,
        quality_status=assessment.status,
        quality_hints=assessment.hints if assessment.hints else None,
        quality_threshold=assessment.threshold,
        work_type=user_plan.work_type,
        context=user_plan.context,
        steps=user_plan.steps,
        metadata=user_plan.metadata,
    )


__all__ = [
    "DEFAULT_QUALITY_THRESHOLD",
    "GENERATED_PLAN_QUALITY_THRESHOLD",
    "AssessmentConfig",
    "QualityAssessment",
    "apply_assessment_to_userplan",
    "assess_user_plan_quality",
    "get_threshold_for_userplan",
]
