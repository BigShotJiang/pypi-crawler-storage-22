"""Skip record data model and persistence for capturing execution gaps.

This module provides a structured SkipRecord model and persistence helpers
for tracking non-blocking execution gaps across the orchestration pipeline.
Skips are "continue-with-gap" events (distinct from breakpoints).
"""

from __future__ import annotations

import json
import logging
import re
import uuid
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from enum import Enum
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from obra.config import load_config

logger = logging.getLogger(__name__)

DEFAULT_SKIP_TRACKING_DIR = ".obra/skip-tracking"
SKIP_REGISTRY_FILENAME = "skip-registry.json"

# Metric name for skip tracking
METRIC_SKIPS_TOTAL = "obra_skips_total"

# Global metrics storage for skip counts
_skip_metrics: list[dict[str, Any]] = []


@runtime_checkable
class SkipRecordStorageProtocol(Protocol):
    """Protocol for SkipRecord storage operations.

    StateManager implementations should provide these methods.
    """

    def create_skip_record(self, skip_data: dict[str, Any]) -> dict[str, Any]:
        """Persist a skip record to storage."""
        ...

    def list_skip_records(self) -> list[dict[str, Any]]:
        """List skip records from storage."""
        ...


class SkipSource(str, Enum):
    """Origin of the skip event."""

    AUTO_RUNNER = "auto_runner"
    STORY0 = "story0"
    ORCHESTRATOR = "orchestrator"
    QUALITY_LOOP = "quality_loop"
    REVISION = "revision"
    DERIVE_HANDLER = "derive_handler"
    USER_BYPASS = "user_bypass"
    PERMISSIVE_MODE = "permissive_mode"


class SkipReason(str, Enum):
    """Classification of why skip occurred."""

    # Tier 1: Real gaps needing resolution
    MISSING_SECRET = "missing_secret"
    DESIGN_DECISION = "design_decision"
    EXTERNAL_DEPENDENCY = "external_dependency"
    TRANSIENT_EXHAUSTED = "transient_exhausted"
    QUALITY_THRESHOLD = "quality_threshold"
    DEFERRED_CONCERN = "deferred_concern"
    PERMISSION_DENIED = "permission_denied"
    SCOPE_BOUNDARY = "scope_boundary"

    # Tier 2: Context (usually expected)
    CONTAINER_EXECUTION = "container_execution"
    RESUME_RECOVERY = "resume_recovery"
    MAX_ITERATIONS = "max_iterations"
    DIMINISHING_RETURNS = "diminishing_returns"
    NO_IMPROVEMENTS = "no_improvements"

    # Tier 3: Intentional (user choice)
    USER_TIMEOUT = "user_timeout"
    USER_DECLINED = "user_declined"
    BYPASS_FLAG = "bypass_flag"

    # Catch-all
    UNKNOWN = "unknown"


class SkipStatus(str, Enum):
    """Resolution status of a skip."""

    PENDING = "pending"
    RESOLVED = "resolved"
    DEFERRED = "deferred"
    WONT_FIX = "wont_fix"
    AUTO_RESOLVED = "auto_resolved"


@dataclass
class SkipRecord:
    """Unified model for all skip events."""

    id: str
    session_id: str
    task_id: str
    source: SkipSource
    reason: SkipReason
    created_at: str
    description: str
    required_input: dict[str, Any] = field(default_factory=dict)
    attempted_resolution: str = ""
    file_context: list[str] = field(default_factory=list)
    error_logs: str = ""
    source_context: dict[str, Any] = field(default_factory=dict)
    tier: int = 1
    auto_retryable: bool = False
    status: SkipStatus = SkipStatus.PENDING
    resolution_notes: str = ""
    resolved_at: str | None = None
    resolved_by: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert the skip record to a dictionary."""
        data = asdict(self)
        data["source"] = self.source.value
        data["reason"] = self.reason.value
        data["status"] = self.status.value
        return data

    def to_json(self, indent: int | None = 2) -> str:
        """Serialize the skip record to JSON."""
        return json.dumps(self.to_dict(), indent=indent)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SkipRecord:
        """Create a SkipRecord from a dictionary."""
        data = dict(data)

        source_value = data.get("source")
        if isinstance(source_value, str):
            data["source"] = SkipSource(source_value)
        elif not isinstance(source_value, SkipSource):
            msg = f"Invalid source type: {type(source_value)}"
            raise TypeError(msg)

        reason_value = data.get("reason")
        if isinstance(reason_value, str):
            data["reason"] = SkipReason(reason_value)
        elif not isinstance(reason_value, SkipReason):
            msg = f"Invalid reason type: {type(reason_value)}"
            raise TypeError(msg)

        status_value = data.get("status", SkipStatus.PENDING)
        if isinstance(status_value, str):
            data["status"] = SkipStatus(status_value)
        elif not isinstance(status_value, SkipStatus):
            msg = f"Invalid status type: {type(status_value)}"
            raise TypeError(msg)

        return cls(**data)

    @classmethod
    def from_json(cls, json_str: str) -> SkipRecord:
        """Deserialize a SkipRecord from JSON."""
        data = json.loads(json_str)
        return cls.from_dict(data)

    def is_resolved(self) -> bool:
        """Return True if skip is resolved/deferred/wont_fix/auto_resolved."""
        return self.status in {
            SkipStatus.RESOLVED,
            SkipStatus.DEFERRED,
            SkipStatus.WONT_FIX,
            SkipStatus.AUTO_RESOLVED,
        }

    def add_resolution_notes(self, notes: str, resolved_by: str = "user") -> None:
        """Add resolution notes and mark as resolved."""
        self.resolution_notes = notes
        self.resolved_by = resolved_by
        self.resolved_at = datetime.now(UTC).isoformat()
        self.status = SkipStatus.RESOLVED


def get_skip_tracking_dir(base_dir: str | Path | None = None) -> Path:
    """Get skip tracking storage directory."""
    if base_dir is None:
        base_dir = Path.cwd()
    elif isinstance(base_dir, str):
        base_dir = Path(base_dir)

    return base_dir / DEFAULT_SKIP_TRACKING_DIR


def _generate_skip_filename(task_id: str, source: SkipSource, timestamp: str) -> str:
    """Generate a filename for a skip record file."""
    try:
        dt = datetime.fromisoformat(timestamp)
    except ValueError:
        dt = datetime.now(UTC)

    time_part = dt.strftime("%Y%m%d_%H%M%S")
    safe_task_id = task_id.replace(".", "_")
    return f"{time_part}_{source.value}_{safe_task_id}.json"


def _load_skip_registry(registry_path: Path) -> dict[str, Any]:
    if not registry_path.exists():
        return {"version": 1, "updated_at": None, "entries": []}
    return json.loads(registry_path.read_text())


def _write_skip_registry(registry_path: Path, registry: dict[str, Any]) -> None:
    registry["updated_at"] = datetime.now(UTC).isoformat()
    registry_path.write_text(json.dumps(registry, indent=2))


def _get_redact_patterns(extra_patterns: list[str] | None = None) -> list[re.Pattern]:
    patterns = [
        re.compile(
            r"(password|secret|key|token|api[_-]?key|auth)[\s]*[=:][\"']?[^\s\"']+",
            re.IGNORECASE,
        ),
        re.compile(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", re.IGNORECASE),
    ]
    if extra_patterns:
        for pattern in extra_patterns:
            try:
                patterns.append(re.compile(pattern))
            except re.error:
                logger.debug("Invalid redaction pattern ignored: %s", pattern)
    return patterns


def redact_sensitive_data(text: str, extra_patterns: list[str] | None = None) -> str:
    """Redact secrets and PII in a string."""
    if not text:
        return text

    config = load_config()
    config_patterns = (
        config.get("orchestration", {})
        .get("skip_tracking", {})
        .get("redact_patterns", [])
    )
    patterns = _get_redact_patterns(
        extra_patterns=config_patterns + (extra_patterns or [])
    )
    redacted = text
    for pattern in patterns:
        redacted = pattern.sub("[REDACTED]", redacted)
    return redacted


def _redact_structure(value: Any, patterns: list[re.Pattern]) -> Any:
    if isinstance(value, str):
        redacted = value
        for pattern in patterns:
            redacted = pattern.sub("[REDACTED]", redacted)
        return redacted
    if isinstance(value, dict):
        sanitized: dict[str, Any] = {}
        for key, val in value.items():
            if isinstance(key, str) and re.search(
                r"(password|secret|key|token|api[_-]?key|auth)", key, re.IGNORECASE
            ):
                sanitized[key] = "[REDACTED]"
            else:
                sanitized[key] = _redact_structure(val, patterns)
        return sanitized
    if isinstance(value, list):
        return [_redact_structure(item, patterns) for item in value]
    return value


def redact_sensitive_structure(
    value: Any, extra_patterns: list[str] | None = None
) -> Any:
    """Redact sensitive data in nested structures."""
    if value is None:
        return value
    config = load_config()
    config_patterns = (
        config.get("orchestration", {})
        .get("skip_tracking", {})
        .get("redact_patterns", [])
    )
    patterns = _get_redact_patterns(
        extra_patterns=config_patterns + (extra_patterns or [])
    )
    return _redact_structure(value, patterns)


def truncate_logs(logs: str, max_chars: int | None = None) -> str:
    """Truncate logs to a max length with a suffix."""
    if logs is None:
        return ""

    if max_chars is None:
        config = load_config()
        max_chars = (
            config.get("orchestration", {})
            .get("skip_tracking", {})
            .get("max_logs_chars", 2000)
        )
    if max_chars <= 0:
        return ""
    if len(logs) <= max_chars:
        return logs
    return f"{logs[:max_chars]}\n... [truncated]"


def _sanitize_for_persistence(skip: SkipRecord) -> dict[str, Any]:
    data = skip.to_dict()
    config = load_config()
    redact_enabled = (
        config.get("orchestration", {})
        .get("skip_tracking", {})
        .get("redact_secrets", True)
    )
    if redact_enabled:
        data["error_logs"] = redact_sensitive_data(data.get("error_logs", ""))
        data["required_input"] = redact_sensitive_structure(
            data.get("required_input", {})
        )
        data["source_context"] = redact_sensitive_structure(
            data.get("source_context", {})
        )
    data["error_logs"] = truncate_logs(data.get("error_logs", ""))
    return data


def persist_skip_record(
    skip: SkipRecord,
    base_dir: str | Path | None = None,
    state_manager: SkipRecordStorageProtocol | None = None,
) -> Path:
    """Persist a skip record to the filesystem and registry index."""
    if state_manager:
        try:
            state_manager.create_skip_record(_sanitize_for_persistence(skip))
        except Exception as e:
            logger.debug("Failed to persist skip record to StateManager: %s", e)

    skip_dir = get_skip_tracking_dir(base_dir)
    skip_dir.mkdir(parents=True, exist_ok=True)

    filename = _generate_skip_filename(skip.task_id, skip.source, skip.created_at)
    file_path = skip_dir / filename

    sanitized = _sanitize_for_persistence(skip)
    file_path.write_text(json.dumps(sanitized, indent=2))

    registry_path = skip_dir / SKIP_REGISTRY_FILENAME
    registry = _load_skip_registry(registry_path)
    entries = [e for e in registry.get("entries", []) if e.get("id") != skip.id]
    entries.append(
        {
            "id": skip.id,
            "file": str(file_path),
            "source": skip.source.value,
            "reason": skip.reason.value,
            "status": skip.status.value,
            "created_at": skip.created_at,
        }
    )
    entries.sort(key=lambda e: e.get("created_at", ""), reverse=True)
    registry["entries"] = entries
    _write_skip_registry(registry_path, registry)

    logger.info(
        "Skip record created for task %s: %s (source: %s)",
        skip.task_id,
        file_path,
        skip.source.value,
    )

    return file_path


def load_skip_record(file_path: Path) -> SkipRecord:
    """Load a skip record from JSON file."""
    json_str = Path(file_path).read_text()
    return SkipRecord.from_json(json_str)


def list_skip_records(
    base_dir: str | Path | None = None,
    source: SkipSource | None = None,
    status: SkipStatus | None = None,
    state_manager: SkipRecordStorageProtocol | None = None,
) -> list[SkipRecord]:
    """List skip records, preferring StateManager when available."""
    if state_manager:
        try:
            records = [
                SkipRecord.from_dict(item) for item in state_manager.list_skip_records()
            ]
            if source:
                records = [r for r in records if r.source == source]
            if status:
                records = [r for r in records if r.status == status]
            records.sort(key=lambda r: r.created_at, reverse=True)
        except Exception as e:
            logger.debug("Failed to list skip records from StateManager: %s", e)
        else:
            return records

    skip_dir = get_skip_tracking_dir(base_dir)

    if not skip_dir.exists():
        return []

    skip_files = [
        f for f in skip_dir.glob("*.json") if f.name != SKIP_REGISTRY_FILENAME
    ]

    records: list[SkipRecord] = []
    for skip_file in skip_files:
        try:
            record = load_skip_record(skip_file)
        except Exception as e:
            logger.debug("Failed to load skip record %s: %s", skip_file, e)
            continue
        if source and record.source != source:
            continue
        if status and record.status != status:
            continue
        records.append(record)

    records.sort(key=lambda r: r.created_at, reverse=True)
    return records


def emit_skip_metric(  # noqa: PLR0913
    source: SkipSource,
    reason: SkipReason,
    task_id: str,
    tier: int,
    log_event: Any | None = None,
    trace_id: str | None = None,
) -> dict[str, Any]:
    """Emit a skip counter metric."""
    metric = {
        "metric_name": METRIC_SKIPS_TOTAL,
        "value": 1,
        "labels": {
            "source": source.value,
            "reason": reason.value,
            "tier": str(tier),
        },
        "timestamp": datetime.now(UTC).isoformat(),
        "metadata": {
            "task_id": task_id,
        },
    }
    _skip_metrics.append(metric)

    if log_event:
        try:
            log_event(
                "skip_metric",
                session_id=None,
                trace_id=trace_id,
                **metric,
            )
        except Exception as e:
            logger.debug("Failed to log skip metric: %s", e)

    logger.debug(
        "Emitted skip metric: source=%s, reason=%s, task_id=%s",
        source.value,
        reason.value,
        task_id,
    )
    return metric


def get_skip_metrics_summary(
    base_dir: str | Path | None = None,
) -> dict[str, Any]:
    """Get summary of skip records by source/reason/status."""
    records = list_skip_records(base_dir=base_dir)
    if not records:
        return {
            "total": 0,
            "by_source": {},
            "by_reason": {},
            "by_status": {},
        }

    by_source: dict[str, int] = {}
    by_reason: dict[str, int] = {}
    by_status: dict[str, int] = {}
    for record in records:
        by_source[record.source.value] = by_source.get(record.source.value, 0) + 1
        by_reason[record.reason.value] = by_reason.get(record.reason.value, 0) + 1
        by_status[record.status.value] = by_status.get(record.status.value, 0) + 1

    return {
        "total": len(records),
        "by_source": by_source,
        "by_reason": by_reason,
        "by_status": by_status,
    }


def build_skip_record(  # noqa: PLR0913
    *,
    session_id: str,
    task_id: str,
    source: SkipSource,
    reason: SkipReason,
    description: str,
    required_input: dict[str, Any] | None = None,
    attempted_resolution: str = "",
    file_context: list[str] | None = None,
    error_logs: str = "",
    source_context: dict[str, Any] | None = None,
    tier: int = 1,
    auto_retryable: bool = False,
    status: SkipStatus = SkipStatus.PENDING,
    created_at: str | None = None,
) -> SkipRecord:
    """Construct a SkipRecord with defaults."""
    return SkipRecord(
        id=str(uuid.uuid4()),
        session_id=session_id,
        task_id=task_id,
        source=source,
        reason=reason,
        created_at=created_at or datetime.now(UTC).isoformat(),
        description=description,
        required_input=required_input or {},
        attempted_resolution=attempted_resolution,
        file_context=file_context or [],
        error_logs=error_logs,
        source_context=source_context or {},
        tier=tier,
        auto_retryable=auto_retryable,
        status=status,
    )


def create_skip_record(  # noqa: PLR0913
    *,
    session_id: str,
    task_id: str,
    source: SkipSource,
    reason: SkipReason,
    description: str,
    required_input: dict[str, Any] | None = None,
    attempted_resolution: str = "",
    file_context: list[str] | None = None,
    error_logs: str = "",
    source_context: dict[str, Any] | None = None,
    base_dir: str | Path | None = None,
    state_manager: SkipRecordStorageProtocol | None = None,
    log_event: Any | None = None,
    trace_id: str | None = None,
) -> SkipRecord | None:
    """Create and persist a SkipRecord if skip tracking is enabled."""
    config = load_config()
    skip_config = config.get("orchestration", {}).get("skip_tracking", {})
    if not skip_config.get("enabled", True):
        return None
    sources = skip_config.get("sources", {})
    if not sources.get(source.value, True):
        return None

    from obra.execution.skip_classifier import get_tier

    tier = get_tier(reason)
    record = build_skip_record(
        session_id=session_id,
        task_id=task_id,
        source=source,
        reason=reason,
        description=description,
        required_input=required_input,
        attempted_resolution=attempted_resolution,
        file_context=file_context,
        error_logs=error_logs,
        source_context=source_context,
        tier=tier,
    )

    persist_skip_record(record, base_dir=base_dir, state_manager=state_manager)
    emit_skip_metric(
        source, reason, task_id, tier, log_event=log_event, trace_id=trace_id
    )
    return record


__all__ = [
    "METRIC_SKIPS_TOTAL",
    "SkipReason",
    "SkipRecord",
    "SkipRecordStorageProtocol",
    "SkipSource",
    "SkipStatus",
    "build_skip_record",
    "create_skip_record",
    "emit_skip_metric",
    "get_skip_metrics_summary",
    "get_skip_tracking_dir",
    "list_skip_records",
    "load_skip_record",
    "persist_skip_record",
    "redact_sensitive_data",
    "redact_sensitive_structure",
    "truncate_logs",
]
