"""Template Edit Pipeline for LLM JSON Responses.

This module provides a unified pipeline for requesting structured JSON outputs
from LLMs using file editing instead of text response parsing. This approach
eliminates preamble/prose contamination issues where LLMs naturally add
explanatory text before JSON ("I need to carefully examine..."), causing
parse failures.

The Template Method pattern separates pipeline mechanics (retry, validation,
observability) from domain logic (schemas, validators, fallbacks).
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from tempfile import mkdtemp
from typing import Any, Callable

from obra.config.llm import DEFAULT_THINKING_LEVEL
from obra.config.loaders import get_template_retention_settings
from obra.hybrid.prompts.template_edit import build_template_edit_prompt
from obra.hybrid.json_utils import extract_json_payload
from obra.llm.cli_runner import invoke_llm_via_cli

logger = logging.getLogger(__name__)


class TemplateEditPipeline:
    """Pipeline for structured JSON responses via file editing.

    This class handles the mechanics of template-based JSON generation:
    - Creates template files with schema guidance
    - Invokes LLM with file editing instructions
    - Validates responses and retries on failure
    - Provides observability hooks for monitoring

    Handlers provide domain-specific components:
    - Template schema (initial JSON structure with _instructions)
    - Validator function (checks fields, types, constraints)
    - Fallback function (safe default on validation failure)

    Example:
        pipeline = TemplateEditPipeline(
            working_dir=Path('/project'),
            action_name='examine',
            max_retries=3
        )

        def validator(data: dict) -> tuple[bool, str | None]:
            if 'issues' not in data:
                return (False, 'Missing issues field')
            return (True, None)

        def fallback() -> list:
            return []

        result, metadata = pipeline.execute(
            base_prompt="Examine this code",
            template_schema={'issues': [], '_instructions': '...'},
            validator=validator,
            fallback_fn=fallback,
            llm_config={'provider': 'claude'}
        )
    """

    def __init__(
        self,
        working_dir: Path,
        action_name: str,
        on_stream: Callable[[str], None] | None = None,
        log_event: Callable[..., None] | None = None,
        production_logger: Any | None = None,
        max_retries: int = 3,
    ):
        """Initialize the template edit pipeline.

        Args:
            working_dir: Project working directory (base for relative paths)
            action_name: Action identifier (e.g., 'examine', 'derive')
            on_stream: Optional callback for streaming LLM output
            log_event: Optional callback for observability events
            max_retries: Maximum validation retry attempts (default: 3)
        """
        self._working_dir = working_dir
        self._action_name = action_name
        self._on_stream = on_stream
        self._log_event = log_event
        self._production_logger = production_logger
        self._max_retries = max_retries

    def _emit_log_event(self, event_type: str, **kwargs: Any) -> None:
        """Emit a log event using the configured callback.

        This wrapper normalizes the calling convention to use **kwargs,
        matching HybridOrchestrator._log_session_event signature.

        Args:
            event_type: Event type string (e.g., 'template_created')
            **kwargs: Event-specific data as keyword arguments
        """
        if self._log_event:
            try:
                self._log_event(event_type, **kwargs)
            except Exception as e:
                logger.debug(f"Failed to log event '{event_type}': {e}")
        if self._production_logger:
            try:
                self._production_logger.log_event(event_type, **kwargs)
            except Exception as e:
                logger.debug(f"Failed to log production event '{event_type}': {e}")

    def _create_template(self, template_schema: dict[str, Any]) -> Path:
        """Create a template file with the given schema.

        The template file is a JSON file containing the schema structure with
        an _instructions field providing guidance to the LLM about how to
        populate the template.

        Args:
            template_schema: Dictionary with schema structure and _instructions
                field (e.g., {'issues': [], '_instructions': 'Add issues...'})

        Returns:
            Path to the created template file

        Example:
            >>> template_path = pipeline._create_template({
            ...     'issues': [],
            ...     '_instructions': 'Add examination issues to the issues array'
            ... })
            >>> # Creates .obra/llm_output/examine_20260124_143022.json
        """
        # Create output directory if it doesn't exist
        output_dir = self._working_dir / ".obra" / "llm_output"
        output_dir.mkdir(parents=True, exist_ok=True)

        # Generate timestamp for unique filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{self._action_name}_{timestamp}.json"
        template_path = output_dir / filename

        # Write schema to template file
        template_path.write_text(json.dumps(template_schema, indent=2))

        logger.debug(f"Created template file: {template_path}")
        return template_path

    def _build_template_edit_prompt(self, base_prompt: str, template_path: Path) -> str:
        """Build augmented prompt with file editing instructions.

        Transforms a base prompt into a template edit prompt by adding
        instructions to edit the template file instead of responding with prose.
        This forces the LLM to use tool actions (structural) rather than text
        responses (prose), eliminating preamble contamination.

        Args:
            base_prompt: Original prompt describing the task
            template_path: Path to the template file to edit

        Returns:
            Augmented prompt with file editing instructions

        Example:
            >>> prompt = pipeline._build_template_edit_prompt(
            ...     "Examine this code for issues",
            ...     Path("/project/.obra/llm_output/examine_20260124_143022.json")
            ... )
            >>> # Returns: "Examine this code for issues\n\nIMPORTANT: Edit the file..."
        """
        # Calculate relative path if possible, fallback to absolute
        try:
            relative_path = template_path.relative_to(self._working_dir)
        except ValueError:
            # Template path is not relative to working_dir, use absolute
            relative_path = template_path

        # Build augmented prompt with editing instructions
        augmented_prompt = build_template_edit_prompt(base_prompt, relative_path)

        return augmented_prompt

    def _recover_json_payload(
        self, content: str
    ) -> tuple[dict[str, Any] | None, int | None]:
        payload = extract_json_payload(content)
        if not payload:
            return (None, None)
        try:
            parsed = json.loads(payload)
        except json.JSONDecodeError as e:
            repaired = self._repair_missing_comma(payload, e)
            if repaired is None:
                return (None, None)
            return (repaired, len(payload))
        if not isinstance(parsed, dict):
            return (None, None)
        return (parsed, len(payload))

    def _repair_missing_comma(
        self,
        content: str,
        error: json.JSONDecodeError,
    ) -> dict[str, Any] | None:
        if error.msg != "Expecting ',' delimiter":
            return None
        insert_at = error.pos
        if insert_at <= 0 or insert_at > len(content):
            return None
        prev_index = insert_at - 1
        while prev_index >= 0 and content[prev_index].isspace():
            prev_index -= 1
        if prev_index < 0:
            return None
        if content[prev_index] in "{[,":
            return None
        repaired_text = f"{content[:insert_at]},{content[insert_at:]}"
        try:
            repaired = json.loads(repaired_text)
        except json.JSONDecodeError:
            return None
        if not isinstance(repaired, dict):
            return None
        return repaired

    def execute(
        self,
        base_prompt: str,
        template_schema: dict[str, Any],
        validator: Callable[[dict], tuple[bool, str | None]],
        fallback_fn: Callable[[], Any],
        llm_config: dict[str, Any],
        timeout_s: int | None = None,
        max_retries: int | None = None,
    ) -> tuple[Any, dict[str, Any]]:
        """Execute the template edit pipeline with retry loop.

        This is the main entry point for the pipeline. It orchestrates:
        1. Template creation
        2. LLM invocation with editing instructions
        3. Response validation with retry on failure
        4. Fallback on exhausted retries

        Args:
            base_prompt: The task description prompt
            template_schema: Initial JSON structure with _instructions field
            validator: Function that validates parsed data and returns
                (is_valid, error_msg). Return (True, None) if valid.
            fallback_fn: Function that returns a safe default value if
                all retry attempts fail
            llm_config: LLM configuration dict with keys:
                - provider: str (e.g., 'anthropic', 'openai')
                - model: str (model identifier)
                - thinking: str (thinking level)
                - auth: str (auth method, default 'oauth')
            timeout_s: Optional timeout override for the LLM call.
            max_retries: Optional retry override for this execution.

        Returns:
            Tuple of (result_data, metadata). Metadata includes:
            - status: 'template_success' (first attempt), 'template_retry_success' (retry succeeded), or 'template_fallback' (all retries failed)
            - attempts: number of attempts made

        Example:
            >>> def validator(data: dict) -> tuple[bool, str | None]:
            ...     if 'issues' not in data:
            ...         return (False, 'Missing issues field')
            ...     return (True, None)
            >>> def fallback() -> list:
            ...     return []
            >>> result, meta = pipeline.execute(
            ...     base_prompt="Examine this code",
            ...     template_schema={'issues': [], '_instructions': '...'},
            ...     validator=validator,
            ...     fallback_fn=fallback,
            ...     llm_config={'provider': 'anthropic', 'model': 'claude-3-5-sonnet-20241022', 'thinking': 'off', 'auth': 'oauth'}
            ... )
        """
        # Create template file
        template_path = self._create_template(template_schema)
        initial_content = template_path.read_text(encoding="utf-8")

        # Log template creation
        self._emit_log_event(
            "template_created",
            template_path=str(template_path),
            action=self._action_name,
        )

        # Build augmented prompt with editing instructions
        augmented_prompt = self._build_template_edit_prompt(base_prompt, template_path)

        max_attempts = self._max_retries if max_retries is None else max_retries

        # Retry loop
        for attempt in range(max_attempts):
            try:
                # Invoke LLM
                invoke_llm_via_cli(
                    prompt=augmented_prompt,
                    cwd=self._working_dir,
                    provider=llm_config["provider"],
                    model=llm_config["model"],
                    thinking_level=llm_config.get("thinking", DEFAULT_THINKING_LEVEL),
                    auth_method=llm_config.get("auth", "oauth"),
                    timeout_s=timeout_s,
                    on_stream=self._on_stream,
                    log_event=self._log_event,
                    call_site=f"template_edit:{self._action_name}",
                    mode="execute",
                    response_format="text",
                )

                # Read template file
                content = template_path.read_text(encoding="utf-8")
                if content == initial_content:
                    # LLM completed successfully but didn't edit the file.
                    # This indicates "reviewed, no changes needed" - not a failure.
                    # The LLM saw the template defaults matched its conclusion and
                    # optimized away the no-op write.
                    self._emit_log_event(
                        "template_unchanged_accepted",
                        attempt=attempt + 1,
                        template_path=str(template_path),
                    )
                    logger.debug(
                        "Template unchanged after LLM call - accepting as 'no changes required'"
                    )
                    self._schedule_cleanup(template_path, on_error=False)
                    # Return the template schema defaults (minus _instructions)
                    default_result = {
                        k: v for k, v in template_schema.items() if k != "_instructions"
                    }
                    return (
                        default_result,
                        {"status": "no_changes_required", "attempts": attempt + 1},
                    )
                try:
                    data = json.loads(content)
                except json.JSONDecodeError as e:
                    repaired_data = self._repair_missing_comma(content, e)
                    if repaired_data is not None:
                        data = repaired_data
                        self._emit_log_event(
                            "parse_repaired",
                            attempt=attempt + 1,
                            error_msg=str(e),
                            repair_type="missing_comma",
                            source="content",
                        )
                    else:
                        recovered_data, extracted_length = self._recover_json_payload(
                            content
                        )
                        if recovered_data is None:
                            raise
                        data = recovered_data
                        self._emit_log_event(
                            "parse_recovered",
                            attempt=attempt + 1,
                            error_msg=str(e),
                            extracted_length=extracted_length or 0,
                        )
                for key, value in template_schema.items():
                    if key == "_instructions":
                        continue
                    if key not in data:
                        data[key] = value

                # Log template read
                self._emit_log_event(
                    "template_read", file_size=len(content), attempt=attempt + 1
                )

                # Remove _instructions field (not part of result)
                data.pop("_instructions", None)

                # Log parse attempt
                self._emit_log_event(
                    "parse_attempt", attempt=attempt + 1, max_retries=max_attempts
                )

                # Validate result
                is_valid, error_msg = validator(data)

                if is_valid:
                    # Success! Log and return result
                    self._emit_log_event("parse_success", attempts=attempt + 1)

                    # Schedule cleanup on success
                    self._schedule_cleanup(template_path, on_error=False)

                    # Use 3-tier status: template_success on first attempt, template_retry_success after retries
                    status = (
                        "template_success" if attempt == 0 else "template_retry_success"
                    )
                    return (data, {"status": status, "attempts": attempt + 1})
                else:
                    # Validation failed
                    self._emit_log_event(
                        "parse_error", error_msg=error_msg, attempt=attempt + 1
                    )

                    if attempt + 1 < max_attempts:
                        # Build error fix prompt and retry, preserving original context
                        augmented_prompt = self._build_template_edit_prompt(
                            base_prompt, template_path
                        )
                        augmented_prompt += (
                            f"\n\nNote: Previous attempt had validation error: {error_msg}. "
                            f"Please fix this specific issue."
                        )
                        logger.warning(
                            f"Validation failed (attempt {attempt + 1}/{max_attempts}): {error_msg}"
                        )

                        self._emit_log_event(
                            "retry_attempt",
                            reason="validation_error",
                            error_msg=error_msg,
                            new_prompt_preview=augmented_prompt[:100],
                        )
                    else:
                        # All retries exhausted, use fallback
                        logger.error(
                            "Validation failed after %d attempts. Using fallback.",
                            max_attempts,
                        )

                        # Schedule cleanup on error
                        self._schedule_cleanup(template_path, on_error=True)

                        fallback_result = fallback_fn()
                        return (
                            fallback_result,
                            {"status": "template_fallback", "attempts": max_attempts},
                        )

            except json.JSONDecodeError as e:
                # JSON parsing error
                self._emit_log_event(
                    "parse_error",
                    error_msg=f"JSON parse error: {str(e)}",
                    attempt=attempt + 1,
                )

                if attempt + 1 < max_attempts:
                    # Build JSON fix prompt and retry, preserving original context
                    augmented_prompt = self._build_template_edit_prompt(
                        base_prompt, template_path
                    )
                    augmented_prompt += (
                        f"\n\nNote: Previous attempt had JSON parse error: {str(e)}. "
                        f"Fix the JSON syntax."
                    )
                    logger.warning(
                        f"JSON parse error (attempt {attempt + 1}/{max_attempts}): {str(e)}"
                    )

                    self._emit_log_event(
                        "retry_attempt",
                        reason="json_parse_error",
                        error_msg=str(e),
                        new_prompt_preview=augmented_prompt[:100],
                    )
                else:
                    # All retries exhausted, use fallback
                    logger.error(
                        "JSON parse error after %d attempts. Using fallback.",
                        max_attempts,
                    )

                    # Schedule cleanup on error
                    self._schedule_cleanup(template_path, on_error=True)

                    fallback_result = fallback_fn()
                    return (
                        fallback_result,
                        {"status": "template_fallback", "attempts": max_attempts},
                    )

            except Exception as e:
                self._emit_log_event(
                    "template_error", error_msg=str(e), attempt=attempt + 1
                )
                if attempt + 1 < max_attempts:
                    logger.warning(
                        "Template edit failed (attempt %d/%d): %s",
                        attempt + 1,
                        max_attempts,
                        e,
                    )
                    continue

                logger.error(
                    "Template edit failed after %d attempts. Using fallback.",
                    max_attempts,
                )
                self._schedule_cleanup(template_path, on_error=True)
                fallback_result = fallback_fn()
                return (
                    fallback_result,
                    {"status": "template_error", "attempts": max_attempts},
                )

        # Should never reach here, but add fallback for safety
        self._schedule_cleanup(template_path, on_error=True)
        fallback_result = fallback_fn()
        return (
            fallback_result,
            {"status": "validation_failed", "attempts": max_attempts},
        )

    def _schedule_cleanup(self, template_path: Path, on_error: bool) -> None:
        """Clean up template file based on retention policy.

        Retention policy:
        - Success: Delete template unless retention configured
        - Error: Keep template unless retention disabled

        Args:
            template_path: Path to template file
            on_error: Whether the pipeline ended in error state
        """
        keep_on_success, keep_on_error = get_template_retention_settings()
        should_keep = keep_on_error if on_error else keep_on_success
        if should_keep:
            logger.debug(
                "Template kept (on_error=%s, keep_on_success=%s, keep_on_error=%s): %s",
                on_error,
                keep_on_success,
                keep_on_error,
                template_path,
            )
            return

        try:
            template_path.unlink()
            logger.debug("Template cleaned up: %s", template_path)
        except Exception as e:
            logger.warning("Failed to cleanup template %s: %s", template_path, e)
