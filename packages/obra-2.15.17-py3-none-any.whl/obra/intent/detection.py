"""Input type detection for intent generation.

This module provides classification of user input to determine
the appropriate intent generation strategy:
- vague_nl: Short, underspecified natural language (~2-5s LLM)
- rich_nl: Detailed natural language description (~2-5s LLM)
- prd: Product requirements document (~2-5s LLM extraction)
- prose_plan: Unstructured plan document (~2-5s LLM extraction)
- structured_plan: MACHINE_PLAN JSON/YAML (~0ms mechanical)

And project state detection:
- EMPTY: New/minimal project (<5 meaningful files)
- EXISTING: Established project with codebase (>50 files or LLM classification)

Related:
    - docs/design/briefs/AUTO_INTENT_GENERATION_BRIEF.md
    - docs/design/briefs/AUTO_INTENT_POLISH_BRIEF.md
    - obra/intent/models.py
"""

import json
import logging
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

import yaml

from obra.config.llm import resolve_tier_config
from obra.constants import (
    INTENT_DETECTION_EMPTY_THRESHOLD,
    INTENT_DETECTION_EXISTING_THRESHOLD,
    INTENT_VAGUE_MAX_CHARS,
    INTENT_VAGUE_MAX_WORDS,
)
from obra.intent.models import InputType
from obra.intent.prompts import build_project_classification_prompt

logger = logging.getLogger(__name__)


class ProjectState(str, Enum):
    """Project state classification for context-aware intent generation.

    Determines whether intent should include technology assumptions (EMPTY)
    or questions for derivation to investigate existing codebase (EXISTING).
    """

    EMPTY = "EMPTY"  # New/minimal project - provide foundation proposals
    EXISTING = "EXISTING"  # Established codebase - ask questions for derivation


@dataclass
class ProjectStateResult:
    """Result of project state detection.

    Attributes:
        state: Detected project state (EMPTY or EXISTING)
        method: Detection method used (deterministic_fast_path or llm_classification)
        rationale: Explanation of why this state was chosen
        file_count: Number of meaningful files found in project
    """

    state: ProjectState
    method: str  # "deterministic_fast_path" or "llm_classification"
    rationale: str
    file_count: int


# Infrastructure directories to exclude from project state detection
EXCLUDED_DIRS = {
    ".git",
    ".obra",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".venv",
    "venv",
    ".env",
    "dist",
    "build",
    ".next",
    ".nuxt",
    "target",  # Rust
    "bin",
    "obj",  # C#
}

# File patterns to exclude
EXCLUDED_PATTERNS = {
    ".pyc",
    ".pyo",
    ".so",
    ".dll",
    ".dylib",
    ".log",
    ".lock",
    "package-lock.json",
    "yarn.lock",
    "Cargo.lock",
}


def list_meaningful_files(project_dir: Path) -> list[Path]:
    """List meaningful files in project directory.

    Excludes infrastructure directories and build artifacts.
    Returns relative paths from project root.

    Args:
        project_dir: Root directory of project

    Returns:
        List of Path objects (relative to project_dir)

    Examples:
        >>> files = list_meaningful_files(Path("/path/to/project"))
        >>> len(files)
        23
        >>> Path("src/main.py") in files
        True
        >>> Path(".git/HEAD") in files
        False
    """
    meaningful_files: list[Path] = []

    if not project_dir.exists():
        return meaningful_files

    for item in project_dir.rglob("*"):
        # Skip if not a file
        if not item.is_file():
            continue

        # Get relative path
        try:
            rel_path = item.relative_to(project_dir)
        except ValueError:
            continue

        # Check if any parent directory is excluded
        if any(part in EXCLUDED_DIRS for part in rel_path.parts):
            continue

        # Check if filename matches excluded pattern
        if any(pattern in item.name for pattern in EXCLUDED_PATTERNS):
            continue

        meaningful_files.append(rel_path)

    return meaningful_files


def detect_project_state(
    project_dir: Path,
    empty_threshold: int = INTENT_DETECTION_EMPTY_THRESHOLD,
    existing_threshold: int = INTENT_DETECTION_EXISTING_THRESHOLD,
    llm_config: dict | None = None,
    force_state: ProjectState | None = None,
) -> ProjectStateResult:
    """Detect project state using hybrid detection (deterministic + LLM).

    Uses file count thresholds with LLM classification for gray areas:
    - < empty_threshold files → EMPTY (deterministic)
    - > existing_threshold files → EXISTING (deterministic)
    - Between thresholds → LLM classification (with fallback to EXISTING on error)

    Args:
        project_dir: Root directory of project
        empty_threshold: Max files for EMPTY classification (default: 5)
        existing_threshold: Min files for EXISTING classification (default: 50)
        llm_config: Optional LLM configuration dict
        force_state: Optional forced state (bypasses all detection)

    Returns:
        ProjectStateResult with classification

    Examples:
        >>> result = detect_project_state(Path("/new/project"))
        >>> result.state
        ProjectState.EMPTY
        >>> result.method
        'deterministic_fast_path'

        >>> result = detect_project_state(Path("/large/project"))
        >>> result.state
        ProjectState.EXISTING
        >>> result.file_count
        127
    """
    # User-facing message
    logger.info("Analyzing project structure...")

    # Count meaningful files
    files = list_meaningful_files(project_dir)
    file_count = len(files)

    logger.debug(
        "Project state detection triggered: dir=%s, files=%d, thresholds=(%d, %d)",
        project_dir,
        file_count,
        empty_threshold,
        existing_threshold,
    )

    # Force state if requested (for --force-empty, --force-existing flags)
    if force_state is not None:
        logger.info("Using forced project state: %s", force_state.value)
        result = ProjectStateResult(
            state=force_state,
            method="forced_override",
            rationale=f"Manually forced to {force_state.value}",
            file_count=file_count,
        )
        _log_classification_result(result)
        return result

    # Deterministic fast path: very few files → EMPTY
    if file_count < empty_threshold:
        result = ProjectStateResult(
            state=ProjectState.EMPTY,
            method="deterministic_fast_path",
            rationale=f"Project has {file_count} files (< {empty_threshold} threshold)",
            file_count=file_count,
        )
        _log_classification_result(result)
        return result

    # Deterministic fast path: many files → EXISTING
    if file_count > existing_threshold:
        result = ProjectStateResult(
            state=ProjectState.EXISTING,
            method="deterministic_fast_path",
            rationale=f"Project has {file_count} files (> {existing_threshold} threshold)",
            file_count=file_count,
        )
        _log_classification_result(result)
        return result

    # Gray area: requires LLM classification
    logger.debug(
        "Project has %d files (between %d and %d) - attempting LLM classification",
        file_count,
        empty_threshold,
        existing_threshold,
    )

    try:
        result = classify_project_state_with_llm(project_dir, files, llm_config)
        _log_classification_result(result)
        return result
    except Exception as e:
        # Fallback to EXISTING (conservative choice) on any error
        logger.warning(
            "LLM classification failed (%s), falling back to EXISTING (conservative)",
            str(e),
        )
        result = ProjectStateResult(
            state=ProjectState.EXISTING,
            method="error_fallback",
            rationale=f"LLM classification failed ({str(e)[:100]}), defaulting to EXISTING (conservative)",
            file_count=file_count,
        )
        _log_classification_result(result)
        return result


def _log_classification_result(result: ProjectStateResult) -> None:
    """Log structured classification result with all metadata.

    Args:
        result: ProjectStateResult to log
    """
    logger.info(
        "Project state classified: state=%s, method=%s, files=%d, rationale='%s'",
        result.state.value,
        result.method,
        result.file_count,
        result.rationale,
    )


# NOTE: build_project_classification_prompt moved to obra/intent/prompts.py
# (REFACTOR-PROMPT-LIBRARY-001)


def classify_project_state_with_llm(
    project_dir: Path,
    files: list[Path],
    llm_config: dict | None = None,
) -> ProjectStateResult:
    """Classify project state using LLM for gray-area cases.

    Uses template edit pattern to eliminate preamble contamination issues.
    LLM edits a template file instead of responding with prose + JSON.

    Args:
        project_dir: Root directory of project
        files: List of meaningful files (from list_meaningful_files)
        llm_config: Optional LLM configuration dict with provider/model/thinking_level

    Returns:
        ProjectStateResult with LLM classification

    Raises:
        Exception: If LLM invocation fails after all retries (caller handles fallback)

    Example:
        >>> files = [Path("README.md"), Path("src/main.py"), Path("src/utils.py")]
        >>> result = classify_project_state_with_llm(Path.cwd(), files)
        >>> result.state in [ProjectState.EMPTY, ProjectState.EXISTING]
        True
        >>> result.method
        'llm_classification'
    """
    from obra.hybrid.template_edit_pipeline import TemplateEditPipeline

    # Build classification prompt
    prompt = build_project_classification_prompt(files)

    # Resolve LLM config (use fast tier for quick classification)
    # Handle 'per-tier' and 'per-role' values by resolving through tier config
    config = llm_config or {}
    raw_provider = config.get("provider")
    raw_model = config.get("model")

    if raw_model in ("per-tier", "per-role", None) or raw_provider in (
        "per-tier",
        "per-role",
        None,
    ):
        resolved = resolve_tier_config("fast", role="orchestrator")
        provider = resolved.get("provider", "anthropic")
        model = resolved.get("model", "default")
        thinking_level = resolved.get("thinking_level", "low")
        auth_method = resolved.get("auth_method", "oauth")
    else:
        provider = raw_provider or "anthropic"
        model = raw_model or "default"
        thinking_level = config.get("thinking_level", "low")
        auth_method = config.get("auth_method", "oauth")

    logger.info("Analyzing project structure with LLM...")

    # Create template edit pipeline (FEAT-TEMPLATE-JSON-001)
    pipeline = TemplateEditPipeline(
        working_dir=project_dir,
        action_name="project_classification",
        max_retries=2,  # Quick classification, fewer retries
    )

    # Template schema for project classification
    template_schema = {
        "state": "",
        "rationale": "",
        "_instructions": (
            "Set 'state' to exactly 'EMPTY' or 'EXISTING' based on the project analysis. "
            "Set 'rationale' to a brief explanation of why this classification was chosen."
        ),
    }

    # Validator: check state is valid enum and rationale is non-empty
    def validator(data: dict) -> tuple[bool, str | None]:
        state = data.get("state", "").upper()
        if state not in {"EMPTY", "EXISTING"}:
            return (False, f"state must be 'EMPTY' or 'EXISTING', got '{state}'")
        if not data.get("rationale"):
            return (False, "rationale is required")
        return (True, None)

    # Fallback: conservative default to EXISTING
    def fallback() -> dict:
        return {
            "state": "EXISTING",
            "rationale": "Classification failed after retries, defaulting to EXISTING (conservative)",
        }

    # Execute pipeline
    result, metadata = pipeline.execute(
        base_prompt=prompt,
        template_schema=template_schema,
        validator=validator,
        fallback_fn=fallback,
        llm_config={
            "provider": provider,
            "model": model,
            "thinking": thinking_level,
            "auth": auth_method,
        },
    )

    # Extract state and rationale from result
    state_str = result.get("state", "EXISTING").upper()
    rationale = result.get("rationale", "LLM classification")

    # Map to ProjectState enum
    state = ProjectState(state_str)

    # Log if fallback was used
    if metadata.get("status") == "template_fallback":
        logger.warning(
            "Project classification used fallback after %d attempts",
            metadata.get("attempts", 0),
        )

    return ProjectStateResult(
        state=state,
        method="llm_classification",
        rationale=rationale,
        file_count=len(files),
    )


# Thresholds for classification
VAGUE_MAX_WORDS = INTENT_VAGUE_MAX_WORDS
VAGUE_MAX_CHARS = INTENT_VAGUE_MAX_CHARS
RICH_MIN_WORDS = 50
MIN_KEYWORD_MATCHES = 2
MIN_DETAIL_MARKERS = 2
PRD_KEYWORDS = {
    "product requirements",
    "user stories",
    "use cases",
    "stakeholders",
    "scope",
    "deliverables",
    "acceptance criteria",
    "functional requirements",
    "non-functional requirements",
}
PLAN_KEYWORDS = {
    "implementation plan",
    "technical design",
    "architecture",
    "milestones",
    "phases",
    "timeline",
    "tasks",
    "stories",
}


def detect_input_type(
    text: str,
    file_path: Path | None = None,
) -> InputType:
    """Detect the input type for intent generation.

    Classifies input into one of:
    - vague_nl: Short/underspecified natural language
    - rich_nl: Detailed natural language description
    - prd: Product requirements document
    - prose_plan: Unstructured plan document
    - structured_plan: MACHINE_PLAN JSON/YAML format

    Args:
        text: Input text content
        file_path: Optional file path for context

    Returns:
        InputType classification

    Examples:
        >>> detect_input_type("add auth")
        InputType.VAGUE_NL

        >>> detect_input_type("Add user authentication with JWT...")
        InputType.RICH_NL
    """
    # Check for structured plan first (file or JSON content)
    if file_path and is_structured_plan_file(file_path):
        return InputType.STRUCTURED_PLAN

    # Try to detect structured plan from content
    if is_structured_plan_content(text):
        return InputType.STRUCTURED_PLAN

    # ISSUE-HYBRID-013: Only check for file-based input types (PRD, PROSE_PLAN)
    # if the text could plausibly be a file path. This prevents long prose
    # objectives with plan-like keywords from being misclassified as file paths,
    # which would cause OSError [Errno 36] File name too long.
    if _could_be_file_path(text):
        # Check for PRD keywords
        if is_prd_content(text):
            return InputType.PRD

        # Check for prose plan keywords
        if is_prose_plan_content(text):
            return InputType.PROSE_PLAN

    # Classify natural language by length/detail
    return classify_natural_language(text)


def is_vague(text: str) -> bool:
    """Check if input is vague/underspecified.

    Args:
        text: Input text

    Returns:
        True if vague (short, lacks detail)

    Examples:
        >>> is_vague("add auth")
        True

        >>> is_vague("Add user authentication with JWT tokens...")
        False
    """
    return classify_natural_language(text) == InputType.VAGUE_NL


def classify_natural_language(text: str) -> InputType:
    """Classify natural language input as vague or rich.

    Args:
        text: Input text

    Returns:
        InputType.VAGUE_NL or InputType.RICH_NL
    """
    text = text.strip()
    words = text.split()
    word_count = len(words)
    char_count = len(text)

    # Short inputs are vague
    if word_count <= VAGUE_MAX_WORDS or char_count <= VAGUE_MAX_CHARS:
        return InputType.VAGUE_NL

    # Rich inputs have substantial detail
    if word_count >= RICH_MIN_WORDS:
        return InputType.RICH_NL

    # Medium length - check for detail markers
    detail_markers = [
        "should",
        "must",
        "will",
        "requires",
        "including",
        "such as",
        "for example",
        "specifically",
    ]

    marker_count = sum(1 for m in detail_markers if m in text.lower())
    if marker_count >= MIN_DETAIL_MARKERS:
        return InputType.RICH_NL

    # Default medium-length to vague (safer to expand)
    return InputType.VAGUE_NL


def is_structured_plan_file(file_path: Path) -> bool:
    """Check if file is a structured MACHINE_PLAN format.

    Args:
        file_path: Path to file

    Returns:
        True if file appears to be a MACHINE_PLAN
    """
    if not file_path.exists():
        return False

    # Check file extension
    suffix = file_path.suffix.lower()
    if suffix not in {".json", ".yaml", ".yml"}:
        return False

    # Check filename patterns
    name = file_path.name.lower()
    if "machine_plan" in name or "_machine_plan" in name:
        return True

    # Check content structure
    try:
        content = file_path.read_text(encoding="utf-8")
        return is_structured_plan_content(content)
    except Exception as e:
        logger.debug("Failed to read file for plan detection: %s", e)
        return False


def is_structured_plan_content(text: str) -> bool:
    """Check if content is structured MACHINE_PLAN format.

    Validates for:
    - JSON with work_id and epics keys
    - YAML with work_id and epics keys

    Args:
        text: Content text

    Returns:
        True if structured plan format
    """
    text = text.strip()

    # Try JSON
    if text.startswith("{"):
        try:
            data = json.loads(text)
            return is_valid_machine_plan(data)
        except json.JSONDecodeError:
            pass

    # Try YAML
    try:
        data = yaml.safe_load(text)
        if isinstance(data, dict):
            return is_valid_machine_plan(data)
    except Exception:
        pass

    return False


def is_valid_machine_plan(data: dict) -> bool:
    """Validate if data structure is a valid MACHINE_PLAN.

    Checks for required fields:
    - work_id: Work identifier
    - epics: List of stories with tasks (nested under epics)

    Args:
        data: Parsed JSON/YAML data

    Returns:
        True if valid machine plan structure
    """
    if not isinstance(data, dict):
        return False

    # Must have work_id
    if "work_id" not in data:
        return False

    stories = _extract_plan_stories(data)
    if not stories:
        return False

    # First story must have tasks or be story-shaped
    first_story = stories[0]
    if not isinstance(first_story, dict):
        return False

    # Check for story structure (id, title/desc, tasks)
    has_id = "id" in first_story
    has_title = "title" in first_story or "desc" in first_story
    has_tasks = "tasks" in first_story and isinstance(first_story["tasks"], list)

    return has_id and has_title and has_tasks


def is_prd_content(text: str) -> bool:
    """Check if content appears to be a PRD.

    Args:
        text: Content text

    Returns:
        True if PRD-like content
    """
    text_lower = text.lower()
    keyword_count = sum(1 for k in PRD_KEYWORDS if k in text_lower)
    return keyword_count >= MIN_KEYWORD_MATCHES


def is_prose_plan_content(text: str) -> bool:
    """Check if content appears to be a prose plan.

    Args:
        text: Content text

    Returns:
        True if prose plan-like content
    """
    text_lower = text.lower()
    keyword_count = sum(1 for k in PLAN_KEYWORDS if k in text_lower)
    return keyword_count >= MIN_KEYWORD_MATCHES


# ISSUE-HYBRID-013: Maximum path length for filesystem validation
# Most filesystems limit filenames to 255 bytes
MAX_PATH_LENGTH = 255


def _could_be_file_path(text: str) -> bool:
    """Check if text could plausibly be a file path.

    ISSUE-HYBRID-013: Guards against treating long prose objectives as file paths.
    Used to prevent false positives in PRD/prose plan detection that would cause
    OSError [Errno 36] File name too long when the system tries to construct
    working_dir / objective_text.

    Args:
        text: Input text to check

    Returns:
        True if text could be a valid file path, False if clearly prose/too long

    Examples:
        >>> _could_be_file_path("requirements.md")
        True
        >>> _could_be_file_path("Build a distributed system with multiple components...")
        False
    """
    text = text.strip()

    # Empty text is not a path
    if not text:
        return False

    # Text exceeding filesystem path length limit is not a valid path
    # (Most filesystems limit filenames to 255 bytes)
    if len(text) > MAX_PATH_LENGTH:
        return False

    # Text with multiple consecutive spaces is prose, not a path
    if "  " in text:
        return False

    # Text with newlines is prose, not a path
    if "\n" in text:
        return False

    # Paths typically don't start with lowercase articles or pronouns
    # (indicates natural language prose)
    prose_starters = {"a ", "an ", "the ", "i ", "we ", "they ", "build ", "create "}
    text_lower = text.lower()
    if any(text_lower.startswith(starter) for starter in prose_starters):
        return False

    return True


def extract_objective_from_plan(data: dict) -> str:
    """Extract objective text from structured plan data.

    Uses work_id and first story title as basis.

    Args:
        data: Machine plan data

    Returns:
        Objective string
    """
    work_id = data.get("work_id", "")

    # Try to get objective from context
    context = data.get("context", {})
    if isinstance(context, dict) and "objective" in context:
        return str(context["objective"])

    # Fall back to work_id + first story
    stories = _extract_plan_stories(data)
    if stories and isinstance(stories[0], dict):
        first_title = stories[0].get("title", stories[0].get("desc", ""))
        if first_title:
            return f"{work_id}: {first_title}"

    return work_id


def _extract_plan_stories(data: dict) -> list[dict[str, Any]]:
    """Extract stories from plan data with epics."""
    epics = data.get("epics")
    if not isinstance(epics, list) or not epics:
        return []

    extracted: list[dict[str, Any]] = []
    for epic in epics:
        if not isinstance(epic, dict):
            continue
        epic_stories = epic.get("stories", [])
        if not isinstance(epic_stories, list):
            continue
        extracted.extend([story for story in epic_stories if isinstance(story, dict)])

    return extracted


# Convenience exports
__all__ = [
    "ProjectState",
    "ProjectStateResult",
    "build_project_classification_prompt",
    "classify_project_state_with_llm",
    "detect_input_type",
    "detect_project_state",
    "extract_objective_from_plan",
    "is_prd_content",
    "is_prose_plan_content",
    "is_structured_plan_content",
    "is_structured_plan_file",
    "is_vague",
    "is_valid_machine_plan",
    "list_meaningful_files",
]
