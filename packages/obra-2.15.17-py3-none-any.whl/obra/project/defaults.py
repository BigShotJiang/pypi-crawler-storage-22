"""Default file templates for Obra projects.

This module provides templates and utilities for initializing Obra-managed
projects with the correct configuration files.
"""

import logging
from pathlib import Path

from obra.project.prompts import DEFAULT_OBRA_CLAUDE_MD
from obra.utils.git_utils import ensure_gitignore_has_obra

logger = logging.getLogger(__name__)


def ensure_obra_claude_md(workspace_path: Path) -> Path:
    """Ensure .obra/CLAUDE.md exists with default content.

    Creates the `.obra/` directory and `.obra/CLAUDE.md` file if they don't exist.
    Also ensures `.obra/` is in `.gitignore` to prevent internal files from being
    tracked by git (which causes review agent issues with large prompt files).

    This follows additive-only behavior - existing files are NEVER overwritten.

    Args:
        workspace_path: Path to the workspace/project root directory

    Returns:
        Path to .obra/CLAUDE.md file

    Raises:
        OSError: If directory or file creation fails
    """
    obra_dir = workspace_path / ".obra"
    claude_md_path = obra_dir / "CLAUDE.md"

    # Ensure .obra directory exists
    obra_dir.mkdir(parents=True, exist_ok=True)

    # Ensure .obra/ is in .gitignore (prevents review agents from analyzing prompts)
    # ISSUE-REVIEW-AGENTS-002: Large prompt files were being included in analysis
    ensure_gitignore_has_obra(workspace_path)

    # Create CLAUDE.md only if it doesn't exist
    if not claude_md_path.exists():
        claude_md_path.write_text(DEFAULT_OBRA_CLAUDE_MD, encoding="utf-8")
        logger.info(f"Created {claude_md_path}")
    else:
        logger.debug(f"CLAUDE.md already exists at {claude_md_path}")

    return claude_md_path
