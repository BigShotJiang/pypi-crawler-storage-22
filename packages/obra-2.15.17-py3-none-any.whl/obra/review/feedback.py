"""Review feedback model for capturing review feedback that updates quality scores.

This module provides models for capturing structured review feedback from
human reviewers or automated review processes. The feedback can be used
to adjust quality scores and track review issues.

Architecture:
    - ReviewFlag: Enum of common review issue types
    - ReviewFeedback: Model for capturing review feedback with scoring

Related:
    - obra/review/config.py (review configuration)
    - obra/execution/quality.py (quality assessment)
    - obra/schemas/userplan_schema.py (QualityStatus patterns)
"""

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any


class ReviewFlag(str, Enum):
    """Common review issue types that can be flagged during review.

    These flags represent categories of issues found during review that
    affect the quality score. Each flag has an associated severity weight
    used for quality score adjustment.

    Attributes:
        INCOMPLETE: Work is missing required components or functionality
        INCORRECT: Implementation has errors or produces wrong results
        UNCLEAR: Code/docs are hard to understand or ambiguous
        OFF_TOPIC: Work doesn't address the original requirements
        QUALITY_ISSUE: General quality problems (style, maintainability)

    Example:
        >>> flags = [ReviewFlag.INCOMPLETE, ReviewFlag.QUALITY_ISSUE]
        >>> feedback = ReviewFeedback(
        ...     source_step_id="UP-20260115-auth:S1",
        ...     flags=flags,
        ...     rating=2
        ... )
    """

    INCOMPLETE = "incomplete"
    INCORRECT = "incorrect"
    UNCLEAR = "unclear"
    OFF_TOPIC = "off_topic"
    QUALITY_ISSUE = "quality_issue"

    @property
    def severity_weight(self) -> float:
        """Return the severity weight for quality score adjustment.

        Higher weights indicate more severe issues that have a larger
        negative impact on quality scores.

        Returns:
            Float weight between 0.0 and 1.0

        Weights:
            - INCORRECT: 0.3 (most severe - wrong results)
            - OFF_TOPIC: 0.25 (doesn't address requirements)
            - INCOMPLETE: 0.2 (missing functionality)
            - UNCLEAR: 0.15 (maintainability impact)
            - QUALITY_ISSUE: 0.1 (minor quality concerns)
        """
        weights = {
            ReviewFlag.INCORRECT: 0.3,
            ReviewFlag.OFF_TOPIC: 0.25,
            ReviewFlag.INCOMPLETE: 0.2,
            ReviewFlag.UNCLEAR: 0.15,
            ReviewFlag.QUALITY_ISSUE: 0.1,
        }
        return weights[self]

    @property
    def description(self) -> str:
        """Human-readable description of the flag."""
        descriptions = {
            ReviewFlag.INCOMPLETE: "Work is missing required components or functionality",
            ReviewFlag.INCORRECT: "Implementation has errors or produces wrong results",
            ReviewFlag.UNCLEAR: "Code or documentation is hard to understand",
            ReviewFlag.OFF_TOPIC: "Work doesn't address the original requirements",
            ReviewFlag.QUALITY_ISSUE: "General quality problems (style, maintainability)",
        }
        return descriptions[self]


class ReviewerType(str, Enum):
    """Type of reviewer providing feedback.

    Attributes:
        HUMAN: Human reviewer
        AUTO: Automated review system (e.g., review agents)
    """

    HUMAN = "human"
    AUTO = "auto"


# Rating bounds
MIN_RATING = 1
MAX_RATING = 5
PASS_RATING_THRESHOLD = 3  # Ratings >= 3 are considered passing


@dataclass
class ReviewFeedback:
    """Model for capturing review feedback that can update quality scores.

    Captures structured feedback from review processes (human or automated)
    including ratings, flags, and comments. Provides methods to convert
    the feedback into quality score adjustments.

    Attributes:
        review_id: Unique identifier for this review feedback
        source_step_id: ID of the step/task being reviewed (e.g., "UP-20260115-auth:S1", "S1.T2")
        rating: Rating from 1-5 (1=poor, 5=excellent) or None for pass/fail
        passed: Pass/fail result (True=passed, False=failed, None if using rating)
        flags: List of issue types found during review
        comments: Optional reviewer comments
        reviewer: Type of reviewer (human or auto)
        created_at: Timestamp when feedback was created (ISO-8601)

    Example:
        >>> feedback = ReviewFeedback(
        ...     source_step_id="S1.T2",
        ...     rating=4,
        ...     flags=[ReviewFlag.QUALITY_ISSUE],
        ...     comments="Minor style issues but overall good"
        ... )
        >>> adjustment = feedback.calculate_quality_adjustment()
        >>> print(f"Quality adjustment: {adjustment}")
    """

    source_step_id: str
    rating: int | None = None
    passed: bool | None = None
    flags: list[ReviewFlag] = field(default_factory=list)
    comments: str = ""
    reviewer: ReviewerType = ReviewerType.HUMAN
    review_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())

    def __post_init__(self) -> None:
        """Validate feedback fields after initialization."""
        if self.rating is not None:
            if not MIN_RATING <= self.rating <= MAX_RATING:
                msg = f"Rating must be between {MIN_RATING} and {MAX_RATING}, got: {self.rating}"
                raise ValueError(msg)

        if self.rating is None and self.passed is None:
            msg = "Either rating or passed must be provided"
            raise ValueError(msg)

        if not self.source_step_id:
            msg = "source_step_id is required"
            raise ValueError(msg)

    def calculate_quality_adjustment(self) -> float:
        """Calculate quality score adjustment based on feedback.

        Combines rating/pass-fail result with flag severity weights to
        produce a quality score adjustment value.

        Returns:
            Float adjustment between -1.0 and 1.0:
            - Positive values indicate quality improvement or confirmation
            - Negative values indicate quality degradation
            - 0.0 indicates neutral (no adjustment)

        Algorithm:
            1. Calculate base adjustment from rating or pass/fail:
               - Rating 5: +0.2 (excellent)
               - Rating 4: +0.1 (good)
               - Rating 3: 0.0 (acceptable/neutral)
               - Rating 2: -0.15 (below expectations)
               - Rating 1: -0.3 (poor)
               - Pass: +0.1
               - Fail: -0.2

            2. Subtract flag penalty (sum of flag severity weights, capped at 0.5)

            3. Clamp result to [-1.0, 1.0]

        Example:
            >>> feedback = ReviewFeedback(
            ...     source_step_id="S1.T1",
            ...     rating=4,
            ...     flags=[ReviewFlag.QUALITY_ISSUE]
            ... )
            >>> feedback.calculate_quality_adjustment()
            0.0  # +0.1 (rating 4) - 0.1 (quality_issue) = 0.0
        """
        # Base adjustment from rating or pass/fail
        if self.rating is not None:
            rating_adjustments = {
                5: 0.2,  # Excellent
                4: 0.1,  # Good
                3: 0.0,  # Acceptable
                2: -0.15,  # Below expectations
                1: -0.3,  # Poor
            }
            base_adjustment = rating_adjustments.get(self.rating, 0.0)
        elif self.passed is not None:
            base_adjustment = 0.1 if self.passed else -0.2
        else:
            base_adjustment = 0.0

        # Calculate flag penalty (capped at 0.5)
        flag_penalty = sum(flag.severity_weight for flag in self.flags)
        flag_penalty = min(flag_penalty, 0.5)

        # Calculate final adjustment
        adjustment = base_adjustment - flag_penalty

        # Clamp to valid range
        return max(-1.0, min(1.0, adjustment))

    def is_passing(self) -> bool:
        """Determine if this feedback indicates a passing review.

        Returns:
            True if the review passed (rating >= 3 or passed=True)
        """
        if self.passed is not None:
            return self.passed

        if self.rating is not None:
            return self.rating >= PASS_RATING_THRESHOLD

        return False

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization.

        Returns:
            Dictionary representation of the feedback
        """
        return {
            "review_id": self.review_id,
            "source_step_id": self.source_step_id,
            "rating": self.rating,
            "passed": self.passed,
            "flags": [flag.value for flag in self.flags],
            "comments": self.comments,
            "reviewer": self.reviewer.value,
            "created_at": self.created_at,
            "quality_adjustment": self.calculate_quality_adjustment(),
            "is_passing": self.is_passing(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ReviewFeedback":
        """Create a ReviewFeedback instance from a dictionary.

        Args:
            data: Dictionary with feedback fields

        Returns:
            ReviewFeedback instance

        Raises:
            KeyError: If required fields are missing
            ValueError: If field values are invalid
        """
        flags = [ReviewFlag(f) for f in data.get("flags", [])]
        reviewer = ReviewerType(data.get("reviewer", "human"))

        return cls(
            review_id=data.get("review_id", str(uuid.uuid4())),
            source_step_id=data["source_step_id"],
            rating=data.get("rating"),
            passed=data.get("passed"),
            flags=flags,
            comments=data.get("comments", ""),
            reviewer=reviewer,
            created_at=data.get("created_at", datetime.now(UTC).isoformat()),
        )


DEFAULT_INITIAL_QUALITY_SCORE = 0.7
REDERIVATION_THRESHOLD = 0.4


@dataclass
class FeedbackResult:
    """Result of applying review feedback to a UserPlan step.

    Captures the outcome of applying feedback, including score changes
    and any triggered actions like re-derivation marking.

    Attributes:
        step_id: ID of the step that was updated
        score_before: Quality score before applying feedback (None if not set)
        score_after: Quality score after applying feedback
        adjustment: The adjustment that was applied
        marked_for_rederivation: Whether the step was marked for re-derivation
        rederivation_reason: Reason for re-derivation marking (if applicable)
    """

    step_id: str
    score_before: float | None
    score_after: float
    adjustment: float
    marked_for_rederivation: bool = False
    rederivation_reason: str | None = None

    def __str__(self) -> str:
        """Human-readable representation of the feedback result."""
        before_str = (
            f"{self.score_before:.2f}" if self.score_before is not None else "None"
        )
        rederiv_str = (
            " [MARKED FOR RE-DERIVATION]" if self.marked_for_rederivation else ""
        )
        return (
            f"Step {self.step_id}: {before_str} -> {self.score_after:.2f} "
            f"(adjustment: {self.adjustment:+.2f}){rederiv_str}"
        )


def apply_review_feedback(
    feedback: ReviewFeedback,
    user_plan: Any,
    rederivation_threshold: float = REDERIVATION_THRESHOLD,
    initial_quality_score: float = DEFAULT_INITIAL_QUALITY_SCORE,
    logger: Any | None = None,
) -> FeedbackResult:
    """Apply review feedback to update quality score on the source UserPlan step.

    Looks up the source step by source_step_id and adjusts its quality_score
    based on the feedback. Negative flags decrease score, positive ratings
    increase score. If the score drops below the threshold, the step is marked
    for re-derivation.

    Args:
        feedback: ReviewFeedback containing the review results
        user_plan: UserPlan instance containing the step to update
        rederivation_threshold: Score threshold below which step is marked for re-derivation
        initial_quality_score: Initial score to use if step has no quality_score
        logger: Optional logger for recording score changes

    Returns:
        FeedbackResult with before/after scores and re-derivation status

    Raises:
        ValueError: If source_step_id is not found in the UserPlan

    Example:
        >>> from obra.review.feedback import apply_review_feedback, ReviewFeedback, ReviewFlag
        >>> feedback = ReviewFeedback(
        ...     source_step_id="UP-20260115-auth:S1",
        ...     rating=2,
        ...     flags=[ReviewFlag.INCOMPLETE]
        ... )
        >>> result = apply_review_feedback(feedback, user_plan)
        >>> print(result)
        Step UP-20260115-auth:S1: 0.70 -> 0.35 (adjustment: -0.35) [MARKED FOR RE-DERIVATION]
    """
    from obra.schemas.userplan_schema import DerivationStatus

    source_step_id = feedback.source_step_id
    target_step = None

    for step in user_plan.steps:
        if step.id == source_step_id:
            target_step = step
            break

    if target_step is None:
        msg = (
            f"Source step '{source_step_id}' not found in UserPlan '{user_plan.id}'. "
            f"Available steps: {[s.id for s in user_plan.steps]}"
        )
        raise ValueError(msg)

    score_before = target_step.quality_score
    current_score = score_before if score_before is not None else initial_quality_score

    adjustment = feedback.calculate_quality_adjustment()
    new_score = max(0.0, min(1.0, current_score + adjustment))

    target_step.quality_score = new_score

    marked_for_rederivation = False
    rederivation_reason = None

    if new_score < rederivation_threshold:
        target_step.derivation_status = DerivationStatus.STALE
        marked_for_rederivation = True
        rederivation_reason = f"Quality score {new_score:.2f} dropped below threshold {rederivation_threshold:.2f}"

    result = FeedbackResult(
        step_id=source_step_id,
        score_before=score_before,
        score_after=new_score,
        adjustment=adjustment,
        marked_for_rederivation=marked_for_rederivation,
        rederivation_reason=rederivation_reason,
    )

    if logger is not None:
        before_str = f"{score_before:.2f}" if score_before is not None else "None"
        logger.info(
            f"Quality score update for {source_step_id}: "
            f"{before_str} -> {new_score:.2f} (adjustment: {adjustment:+.2f})"
        )
        if marked_for_rederivation:
            logger.warning(
                f"Step {source_step_id} marked for re-derivation: {rederivation_reason}"
            )

    return result


def apply_multiple_feedbacks(
    feedbacks: list[ReviewFeedback],
    user_plan: Any,
    rederivation_threshold: float = REDERIVATION_THRESHOLD,
    initial_quality_score: float = DEFAULT_INITIAL_QUALITY_SCORE,
    logger: Any | None = None,
) -> list[FeedbackResult]:
    """Apply multiple review feedbacks to a UserPlan.

    Applies feedbacks in order, allowing them to accumulate on the same steps.
    This is useful when multiple reviews target the same step.

    Args:
        feedbacks: List of ReviewFeedback instances to apply
        user_plan: UserPlan instance containing the steps to update
        rederivation_threshold: Score threshold below which step is marked for re-derivation
        initial_quality_score: Initial score to use if step has no quality_score
        logger: Optional logger for recording score changes

    Returns:
        List of FeedbackResult instances, one per feedback applied

    Example:
        >>> feedbacks = [
        ...     ReviewFeedback(source_step_id="UP-20260115-auth:S1", rating=4),
        ...     ReviewFeedback(source_step_id="UP-20260115-auth:S1", rating=2),
        ... ]
        >>> results = apply_multiple_feedbacks(feedbacks, user_plan)
        >>> for r in results:
        ...     print(r)
    """
    results = []
    for feedback in feedbacks:
        result = apply_review_feedback(
            feedback=feedback,
            user_plan=user_plan,
            rederivation_threshold=rederivation_threshold,
            initial_quality_score=initial_quality_score,
            logger=logger,
        )
        results.append(result)
    return results


__all__ = [
    "DEFAULT_INITIAL_QUALITY_SCORE",
    "FeedbackResult",
    "MAX_RATING",
    "MIN_RATING",
    "PASS_RATING_THRESHOLD",
    "REDERIVATION_THRESHOLD",
    "ReviewFeedback",
    "ReviewFlag",
    "ReviewerType",
    "apply_multiple_feedbacks",
    "apply_review_feedback",
]
