"""Verification tools resolution and detection helpers."""

from __future__ import annotations

from dataclasses import dataclass
from importlib.util import find_spec
from pathlib import Path
import shutil
from typing import Any

from obra.config.loaders import (
    get_verification_discovery_enabled,
    get_verification_force_refresh,
)
from obra.hybrid.tooling_discovery import ToolingDiscovery

DEFAULT_CATEGORIES: tuple[str, ...] = ("tests", "lint", "typecheck")

SOURCE_PRIORITY: dict[str, int] = {
    "config": 5,
    "install": 4,
    "installed": 3,
    "discovery": 2,
    "none": 1,
    "error": 0,
}

CATEGORY_PROBES: dict[str, dict[str, tuple[str, ...]]] = {
    "tests": {"commands": ("pytest",), "modules": ("pytest",)},
    "lint": {"commands": ("ruff",), "modules": ("ruff",)},
    "typecheck": {"commands": ("mypy",), "modules": ("mypy",)},
}


@dataclass(frozen=True)
class VerificationTools:
    """Normalized verification tools report."""

    available: list[str]
    missing: list[str]
    source: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "available": self.available,
            "missing": self.missing,
            "source": self.source,
        }


def _normalize_list(values: Any) -> list[str]:
    if not values:
        return []
    if not isinstance(values, list):
        return []
    normalized: list[str] = []
    for value in values:
        if isinstance(value, str) and value.strip():
            normalized.append(value.strip())
    return normalized


def _normalize_tools_payload(
    payload: dict[str, Any] | None,
) -> VerificationTools | None:
    if not payload or not isinstance(payload, dict):
        return None
    available = _normalize_list(payload.get("available"))
    missing = _normalize_list(payload.get("missing"))
    source = str(payload.get("source") or "")
    if not available and not missing and not source:
        return None
    if not source:
        source = "unknown"
    return VerificationTools(available=available, missing=missing, source=source)


def _priority(source: str) -> int:
    return SOURCE_PRIORITY.get(source, 0)


def merge_verification_tools(
    existing: dict[str, Any] | None,
    incoming: dict[str, Any] | None,
    *,
    prefer_existing: bool = True,
) -> dict[str, Any]:
    """Merge verification tool reports without downgrading availability."""

    existing_norm = _normalize_tools_payload(existing)
    incoming_norm = _normalize_tools_payload(incoming)
    if existing_norm is None:
        return incoming or {}
    if incoming_norm is None:
        return existing or {}

    if not prefer_existing:
        if _priority(incoming_norm.source) >= _priority(existing_norm.source):
            return incoming_norm.to_dict()
        return existing_norm.to_dict()

    if _priority(incoming_norm.source) > _priority(existing_norm.source):
        return incoming_norm.to_dict()
    if _priority(incoming_norm.source) < _priority(existing_norm.source):
        return _merge_union(existing_norm, incoming_norm, source=existing_norm.source)

    # Same priority: union available/missing, keep existing source
    return _merge_union(existing_norm, incoming_norm, source=existing_norm.source)


def _merge_union(
    left: VerificationTools,
    right: VerificationTools,
    *,
    source: str,
) -> dict[str, Any]:
    available = sorted(set(left.available) | set(right.available))
    missing = sorted((set(left.missing) | set(right.missing)) - set(available))
    return {
        "available": available,
        "missing": missing,
        "source": source,
    }


def detect_installed_verification_categories() -> list[str]:
    """Detect installed verification tools in the active environment."""

    available: list[str] = []
    for category, probes in CATEGORY_PROBES.items():
        found = False
        for command in probes.get("commands", ()):
            if shutil.which(command):
                found = True
                break
        if not found:
            for module in probes.get("modules", ()):
                if find_spec(module) is not None:
                    found = True
                    break
        if found:
            available.append(category)
    return available


def _extract_configured_categories(config: dict[str, Any]) -> list[str]:
    tools = config.get("fix", {}).get("verification", {}).get("tools", [])
    if not isinstance(tools, list) or not tools:
        return []
    categories: list[str] = []
    for tool in tools:
        if isinstance(tool, dict):
            value = tool.get("category") or tool.get("name")
            if isinstance(value, str) and value.strip():
                categories.append(value.strip())
    return categories


def resolve_verification_tools(
    working_dir: Path,
    llm_config: dict[str, Any] | None,
    config: dict[str, Any],
    *,
    existing: dict[str, Any] | None = None,
    prefer_existing: bool = True,
    force_refresh: bool | None = None,
) -> dict[str, Any]:
    """Resolve verification tools with precedence: config > install > installed > discovery."""

    configured = _extract_configured_categories(config)
    if configured:
        resolved = {
            "available": sorted(set(configured)),
            "missing": [],
            "source": "config",
        }
        return merge_verification_tools(
            existing, resolved, prefer_existing=prefer_existing
        )

    installed = detect_installed_verification_categories()
    if installed:
        resolved = {
            "available": sorted(set(installed)),
            "missing": sorted(
                [cat for cat in DEFAULT_CATEGORIES if cat not in installed]
            ),
            "source": "installed",
        }
        return merge_verification_tools(
            existing, resolved, prefer_existing=prefer_existing
        )

    if get_verification_discovery_enabled():
        refresh = (
            get_verification_force_refresh() if force_refresh is None else force_refresh
        )
        tooling = ToolingDiscovery(working_dir, llm_config or {}).discover(
            force_refresh=refresh
        )
        verification = tooling.get("verification", {})
        available: list[str] = []
        missing: list[str] = []
        for category in ["test", "lint", "typecheck"]:
            tool_config = verification.get(category, {})
            cat_name = "tests" if category == "test" else category
            if isinstance(tool_config, dict) and tool_config.get("command"):
                available.append(cat_name)
            else:
                missing.append(cat_name)
        resolved = {
            "available": sorted(set(available)),
            "missing": sorted(set(missing) - set(available)),
            "source": "discovery",
        }
        return merge_verification_tools(
            existing, resolved, prefer_existing=prefer_existing
        )

    resolved = {
        "available": [],
        "missing": list(DEFAULT_CATEGORIES),
        "source": "none",
    }
    return merge_verification_tools(existing, resolved, prefer_existing=prefer_existing)
