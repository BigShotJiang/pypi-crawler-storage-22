"""Setting descriptions for the Configuration Explorer.

Provides human-readable descriptions for all configuration options,
used for inline documentation in the TUI.
"""

from typing import Any

# Mapping from dot-notation path to description text.
# Descriptions should be concise but informative, explaining what the
# setting does and any important considerations.
CONFIG_DESCRIPTIONS: dict[str, str] = {
    # ==========================================================================
    # Advanced / Diagnostics
    # ==========================================================================
    "advanced": "Advanced and diagnostic settings (use with care).",
    "advanced.monitoring": "File/output monitoring and production logging settings.",
    "advanced.logging": "CLI logging settings (level, format, file rotation).",
    "advanced.debug": "Development/debug flags (disable in production).",
    "advanced.audit": "Audit logging settings for destructive operations.",
    "advanced.metrics": "Work unit metrics reporting configuration.",
    "advanced.observability": "Observability event emission settings.",
    # ==========================================================================
    # LLM Settings - Local Config
    # ==========================================================================
    "llm": "LLM provider configuration for orchestration and implementation layers.",
    "llm.thinking_level": (
        "Default reasoning level used when stage defaults are not specified. "
        "Normalized levels: off, low, medium, high, maximum."
    ),
    "llm.reasoning": (
        "Reasoning selection overrides and constraints applied after stage defaults."
    ),
    "llm.reasoning.force_level": (
        "Force a fixed reasoning level across operations. Set to null to allow stage defaults."
    ),
    "llm.reasoning.strict_mode": (
        "Error when a requested reasoning level is unsupported. "
        "When false, Obra warns and downgrades."
    ),
    "llm.reasoning.tiers": "Per-tier reasoning bounds (fast/medium/high).",
    "llm.reasoning.tiers.fast": "Reasoning bounds for fast tier models.",
    "llm.reasoning.tiers.fast.min_level": "Minimum reasoning level for fast tier.",
    "llm.reasoning.tiers.fast.max_level": "Maximum reasoning level for fast tier.",
    "llm.reasoning.tiers.medium": "Reasoning bounds for medium tier models.",
    "llm.reasoning.tiers.medium.min_level": "Minimum reasoning level for medium tier.",
    "llm.reasoning.tiers.medium.max_level": "Maximum reasoning level for medium tier.",
    "llm.reasoning.tiers.high": "Reasoning bounds for high tier models.",
    "llm.reasoning.tiers.high.min_level": "Minimum reasoning level for high tier.",
    "llm.reasoning.tiers.high.max_level": "Maximum reasoning level for high tier.",
    "llm.orchestrator": (
        "Settings for the orchestration layer LLM (planning, validation, decisions)."
    ),
    "llm.orchestrator.provider": (
        "LLM provider for the orchestration layer. "
        "Handles planning, validation, and decision-making. "
        "Options: anthropic (Claude), openai (OpenAI Codex), "
        "google (Gemini), ollama (local models)."
    ),
    "llm.orchestrator.model": (
        "Model to use for orchestration. "
        "Options vary by provider: "
        "Anthropic: sonnet, opus, haiku | "
        "Google: gemini-2.5-pro, gemini-2.5-flash, gemini-3-flash-preview | "
        "OpenAI: codex, gpt-5.2, gpt-5.2-codex, gpt-5.1-codex-max, gpt-5.1-codex-mini, gpt-5.1 | "
        "Ollama: qwen2.5-coder, qwen2.5, llama3.3, deepseek-r1, phi3. "
        "'default' is recommended."
    ),
    "llm.orchestrator.auth_method": (
        "Authentication method for the orchestration LLM. "
        "'oauth' uses flat-rate billing through Obra subscription. "
        "'api_key' bills directly to your provider account (pay-per-token)."
    ),
    "llm.orchestrator.thinking_level": (
        "Default reasoning level for orchestration calls. "
        "Normalized levels: off, low, medium, high, maximum."
    ),
    "llm.orchestrator.tiers": (
        "Tiered model configuration for orchestrator adaptive complexity handling. "
        "Define fast/medium/high tiers to automatically select appropriate models "
        "based on task complexity. "
        "Tiers use the orchestrator provider (llm.orchestrator.provider)."
    ),
    "llm.orchestrator.tiers.fast": (
        "Fast tier model for orchestrator - simple, low-complexity tasks. "
        "Use lightweight models (e.g., Anthropic: 'haiku', "
        "OpenAI: 'gpt-5.1-codex-mini', Google: 'gemini-2.5-flash'). "
        "Dropdown options match the orchestrator provider."
    ),
    "llm.orchestrator.tiers.medium": (
        "Medium tier model for orchestrator - moderate-complexity tasks. "
        "Use balanced models (e.g., Anthropic: 'sonnet', "
        "OpenAI: 'gpt-5.1-codex-max', Google: 'gemini-2.5-pro'). "
        "Dropdown options match the orchestrator provider."
    ),
    "llm.orchestrator.tiers.high": (
        "High tier model for orchestrator - complex, critical tasks. "
        "Use frontier models (e.g., Anthropic: 'opus', "
        "OpenAI: 'gpt-5.1-codex-max', Google: 'gemini-2.5-pro'). "
        "Dropdown options match the orchestrator provider."
    ),
    "llm.implementation": (
        "Settings for the implementation layer LLM (code generation, file modifications)."
    ),
    "llm.implementation.provider": (
        "LLM provider for the implementation layer. "
        "Handles code generation and file modifications. "
        "Options: anthropic (Claude Code), openai (OpenAI Codex), "
        "google (Gemini CLI), ollama (local models)."
    ),
    "llm.implementation.model": (
        "Model to use for implementation. "
        "Options vary by provider: "
        "Anthropic: sonnet, opus, haiku | "
        "Google: gemini-2.5-pro, gemini-2.5-flash, gemini-3-flash-preview | "
        "OpenAI: codex, gpt-5.2, gpt-5.2-codex, gpt-5.1-codex-max, gpt-5.1-codex-mini, gpt-5.1 | "
        "Ollama: qwen2.5-coder, qwen2.5, llama3.3, deepseek-r1, phi3. "
        "'default' is recommended."
    ),
    "llm.implementation.auth_method": (
        "Authentication method for the implementation LLM. "
        "'oauth' uses your provider's CLI authentication. "
        "'api_key' requires setting the provider's API key environment variable."
    ),
    "llm.implementation.thinking_level": (
        "Default reasoning level for implementation calls. "
        "Normalized levels: off, low, medium, high, maximum."
    ),
    "llm.implementation.tiers": (
        "Tiered model configuration for implementation adaptive complexity handling. "
        "Define fast/medium/high tiers to automatically select appropriate models "
        "based on task complexity. "
        "Tiers use the implementation provider (llm.implementation.provider)."
    ),
    "llm.implementation.tiers.fast": (
        "Fast tier model for implementation - simple, low-complexity tasks. "
        "Use lightweight models (e.g., Anthropic: 'haiku', "
        "OpenAI: 'gpt-5.1-codex-mini', Google: 'gemini-2.5-flash'). "
        "Dropdown options match the implementation provider."
    ),
    "llm.implementation.tiers.medium": (
        "Medium tier model for implementation - moderate-complexity tasks. "
        "Use balanced models (e.g., Anthropic: 'sonnet', "
        "OpenAI: 'gpt-5.1-codex-max', Google: 'gemini-2.5-pro'). "
        "Dropdown options match the implementation provider."
    ),
    "llm.implementation.tiers.high": (
        "High tier model for implementation - complex, critical tasks. "
        "Use frontier models (e.g., Anthropic: 'opus', "
        "OpenAI: 'gpt-5.1-codex-max', Google: 'gemini-2.5-pro'). "
        "Dropdown options match the implementation provider."
    ),
    # ==========================================================================
    # LLM Git Repository Settings (GIT-HARD-001)
    # ==========================================================================
    "llm.git": "Git repository validation settings for LLM execution.",
    "llm.git.skip_check": (
        "Skip git repository validation before LLM execution. "
        "Auto-enabled when using OpenAI Codex (required for Codex trust compatibility). "
        "When false, Obra requires projects to be in a git repository "
        "for change tracking and safe rollbacks. "
        "You can manually override this setting if needed."
    ),
    "llm.git.auto_init": (
        "Auto-initialize git repository if not present. "
        "When true, Obra will run 'git init' and create a default .gitignore "
        "if the project directory is not already a git repository. "
        "Useful for new projects. Default: false."
    ),
    "llm.git.auto_init_require_depth": (
        "Minimum depth from home directory for auto-init safety. "
        "Prevents auto-init in shallow paths like ~/ or ~/myapp. "
        "Example: ~/projects/myapp has depth 2 (projects, myapp). "
        "Default: 2."
    ),
    "llm.git.auto_init_max_files": (
        "Maximum files allowed for auto-init safety. "
        "Blocks auto-init if directory has more than this many files. "
        "Prevents polluting existing projects. "
        "Default: 1000."
    ),
    "llm.git.auto_init_blacklist": (
        "Additional paths to block from auto-init. "
        "List of absolute paths that should never be auto-initialized "
        "(e.g., ['/srv', '/mnt']). System paths like / and /tmp are "
        "always blocked. Default: []."
    ),
    # ==========================================================================
    # LLM Role-Based Configuration (ADR-069)
    # ==========================================================================
    "llm.roles": (
        "Configure which model handles each pipeline action. "
        "Each role can reference a profile (orchestrator/implementation) or "
        "specify custom provider/model settings."
    ),
    # Planning phase roles
    "llm.roles.derive": (
        "Model for plan derivation. Breaks down objectives into executable plans. "
        "Defaults to orchestrator profile."
    ),
    "llm.roles.examine": (
        "Model for plan examination. Reviews plans for issues and improvements. "
        "Defaults to orchestrator profile."
    ),
    "llm.roles.revise": (
        "Model for plan revision. Updates plans based on examination feedback. "
        "Defaults to orchestrator profile."
    ),
    # Execution phase roles
    "llm.roles.execute": (
        "Model for task execution. Implements code changes and file operations. "
        "Defaults to implementation profile."
    ),
    "llm.roles.fix": (
        "Model for fixing issues. Resolves problems found during execution. "
        "Defaults to implementation profile."
    ),
    "llm.roles.review": (
        "Model for code review. Performs quality and architecture review. "
        "Defaults to implementation profile."
    ),
    # Pre-planning phase roles (intent enrichment)
    "llm.roles.enrichment_assumptions": (
        "Model for gathering assumptions. Identifies what is not explicitly stated. "
        "Defaults to orchestrator profile."
    ),
    "llm.roles.enrichment_analogues": (
        "Model for finding analogous solutions. Identifies similar problems/patterns. "
        "Defaults to orchestrator profile."
    ),
    "llm.roles.enrichment_brief": (
        "Model for generating planning briefs. Creates structured planning documents. "
        "Defaults to orchestrator profile."
    ),
    # ==========================================================================
    # Planning - Intent Enrichment
    # ==========================================================================
    "planning": "Planning configuration for derivation and intent enrichment.",
    "planning.enrichment": "Intent enrichment stages before derivation.",
    "planning.enrichment.enabled": (
        "Enable intent enrichment (assumptions, analogues, brief, review)."
    ),
    "planning.enrichment.always_on": (
        "When enabled, always run enrichment stages for derive (unless --no-enrich)."
    ),
    "planning.enrichment.stages": "Stage-specific configuration for intent enrichment.",
    "planning.enrichment.stages.assumptions": (
        "Stage A: gather assumptions and non-inferable questions."
    ),
    "planning.enrichment.stages.assumptions.model_tier": (
        "Model tier for the assumptions stage (fast/medium/high)."
    ),
    "planning.enrichment.stages.assumptions.reasoning_level": (
        "Reasoning level for the assumptions stage."
    ),
    "planning.enrichment.stages.assumptions.max_passes": (
        "Max attempts for the assumptions stage."
    ),
    "planning.enrichment.stages.assumptions.timeout_s": (
        "Timeout in seconds for the assumptions stage."
    ),
    "planning.enrichment.stages.assumptions.max_questions": (
        "Max non-inferable questions to ask in interactive runs."
    ),
    "planning.enrichment.stages.analogues": (
        "Stage B: domain inference and expert-aligned intent updates."
    ),
    "planning.enrichment.stages.analogues.model_tier": (
        "Model tier for the analogues stage (fast/medium/high)."
    ),
    "planning.enrichment.stages.analogues.reasoning_level": (
        "Reasoning level for the analogues stage."
    ),
    "planning.enrichment.stages.analogues.max_passes": ("Max attempts for the analogues stage."),
    "planning.enrichment.stages.analogues.timeout_s": (
        "Timeout in seconds for the analogues stage."
    ),
    "planning.enrichment.stages.brief": ("Stage C: consolidate a clean intent brief."),
    "planning.enrichment.stages.brief.model_tier": (
        "Model tier for the brief stage (fast/medium/high)."
    ),
    "planning.enrichment.stages.brief.reasoning_level": ("Reasoning level for the brief stage."),
    "planning.enrichment.stages.brief.max_passes": ("Max attempts for the brief stage."),
    "planning.enrichment.stages.brief.timeout_s": ("Timeout in seconds for the brief stage."),
    "planning.enrichment.stages.derive": ("Stage D: derive plan from enriched intent."),
    "planning.enrichment.stages.derive.model_tier": (
        "Model tier for the derive stage (fast/medium/high)."
    ),
    "planning.enrichment.stages.derive.reasoning_level": ("Reasoning level for the derive stage."),
    "planning.enrichment.stages.derive.max_passes": ("Max attempts for the derive stage."),
    "planning.enrichment.stages.derive.timeout_s": ("Timeout in seconds for the derive stage."),
    "planning.enrichment.stages.review": ("Stage E: expert-aligned plan review for scope creep."),
    "planning.enrichment.stages.review.model_tier": (
        "Model tier for the review stage (fast/medium/high)."
    ),
    "planning.enrichment.stages.review.reasoning_level": ("Reasoning level for the review stage."),
    "planning.enrichment.stages.review.max_passes": ("Max attempts for the review stage."),
    "planning.enrichment.stages.review.timeout_s": ("Timeout in seconds for the review stage."),
    "planning.enrichment.non_inferable_categories": (
        "Categories that require user input when missing (interactive only)."
    ),
    "planning.enrichment.diff": "Intent diff output settings.",
    "planning.enrichment.diff.path_template": (
        "Template for intent diff path (supports {intent_id})."
    ),
    "planning.enrichment.diff.retention": "Retention policy for intent diffs.",
    "planning.enrichment.diff.retention.max_files": ("Max diff files to retain."),
    "planning.enrichment.artifacts": "Stage artifact output settings.",
    "planning.enrichment.artifacts.dir": "Directory for enrichment stage artifacts.",
    "planning.enrichment.artifacts.retention": "Retention policy for stage artifacts.",
    "planning.enrichment.artifacts.retention.max_files": ("Max artifacts to retain."),
    # ==========================================================================
    # Derivation - Hierarchical Planning
    # ==========================================================================
    "derivation": "Derivation engine settings for structured plan generation.",
    "derivation.hierarchy": "Hierarchical derivation settings (epic/story/task/subtask).",
    "derivation.hierarchy.task.max_files": (
        "Maximum estimated files touched per task before triggering validation violations."
    ),
    "derivation.hierarchy.task.max_loc": (
        "Maximum estimated LOC per task before triggering validation violations."
    ),
    "derivation.hierarchy.task.max_words": (
        "Maximum estimated words per task before triggering validation violations."
    ),
    "derivation.hierarchy.subtask.max_files": (
        "Maximum estimated files touched per subtask before triggering validation violations."
    ),
    "derivation.hierarchy.subtask.max_loc": (
        "Maximum estimated LOC per subtask before triggering validation violations."
    ),
    "derivation.hierarchy.subtask.max_words": (
        "Maximum estimated words per subtask before triggering validation violations."
    ),
    "derivation.hierarchy.validation": "Validation gating for hierarchical derivation.",
    "derivation.hierarchy.validation.max_passes": (
        "Maximum re-prompt attempts per hierarchy level when validation fails."
    ),
    "derivation.hierarchy.validation.block_on_fail": (
        "Block derivation and raise an error when validation violations persist."
    ),
    "planning.enrichment.analogue_cache": "Analogue cache paths for expert guidance.",
    "planning.enrichment.analogue_cache.global_path": (
        "Global analogue cache path (shared across projects)."
    ),
    "planning.enrichment.analogue_cache.project_path": ("Project-scoped analogue cache path."),
    "planning.enrichment.telemetry": "Telemetry output settings for enrichment runs.",
    "planning.enrichment.telemetry.enabled": "Enable local telemetry logging.",
    "planning.enrichment.telemetry.include_content": (
        "Include raw model outputs in telemetry logs."
    ),
    "planning.enrichment.telemetry.output_path": "Telemetry JSONL output path.",
    "planning.intent_alignment": "Intent alignment QA settings for derived epics/stories.",
    "planning.intent_alignment.model_tier": (
        "Model tier for intent alignment QA (fast/medium/high)."
    ),
    "planning.intent_alignment.reasoning_level": ("Reasoning level for intent alignment QA."),
    "planning.intent_alignment.max_passes": "Max attempts for intent alignment QA.",
    "planning.intent_alignment.timeout_s": "Timeout in seconds for intent alignment QA.",
    "planning.intent_alignment.block_on_fail": (
        "Block derivation when intent alignment fails (coverage_status=fail)."
    ),
    "planning.intent_gap_check": "Post-execution intent gap check settings.",
    "planning.intent_gap_check.story_enabled": "Enable story-level gap checks.",
    "planning.intent_gap_check.epic_enabled": "Enable epic-level gap checks.",
    "planning.intent_gap_check.auto_append": (
        "Auto-append follow-up stories when gaps are detected."
    ),
    "planning.intent_gap_check.max_new_stories": (
        "Maximum number of follow-up stories to append per epic."
    ),
    "planning.intent_gap_check.model_tier": (
        "Model tier for intent gap checks (fast/medium/high)."
    ),
    "planning.intent_gap_check.reasoning_level": ("Reasoning level for intent gap checks."),
    "planning.intent_gap_check.max_passes": "Max attempts for intent gap checks.",
    "planning.intent_gap_check.timeout_s": "Timeout in seconds for intent gap checks.",
    "planning.intent_gap_check.artifacts_dir": ("Directory for intent gap report artifacts."),
    # ==========================================================================
    # Local Settings
    # ==========================================================================
    "api_base_url": (
        "Obra SaaS API endpoint URL. "
        "Only change this for testing, self-hosted instances, or staging environments. "
        "Default: production Obra API."
    ),
    "llm_timeout": (
        "Maximum time in seconds to wait for LLM responses. "
        "Increase for complex tasks that may take longer. "
        "Default: 1800 (30 minutes)."
    ),
    # ==========================================================================
    # Orchestration Settings - Timeouts
    # ==========================================================================
    "orchestration": "Orchestration settings for workflow execution and agent management.",
    "orchestration.template_retention": (
        "Retention policy for template-edit JSON outputs (ADR-063)."
    ),
    "orchestration.template_retention.keep_on_success": (
        "Keep template files after successful validation. Default: false."
    ),
    "orchestration.template_retention.keep_on_error": (
        "Keep template files when validation fails for debugging. Default: true."
    ),
    "orchestration.timeouts": "Timeout configurations for various orchestration operations.",
    "orchestration.timeouts.agent_execution_s": (
        "Timeout in seconds for agent execution (execute and fix handlers). "
        "Controls how long Obra waits for agent task completion. "
        "Can be overridden with OBRA_AGENT_EXECUTION_TIMEOUT environment variable. "
        "Default: 5400 (90 minutes)."
    ),
    "orchestration.timeouts.review_agent_s": (
        "Timeout in seconds for review agents (security, testing, code quality, documentation). "
        "Controls how long each review agent runs before timing out. "
        "Can be overridden with OBRA_REVIEW_AGENT_TIMEOUT environment variable. "
        "Default: 1800 (30 minutes)."
    ),
    "orchestration.timeouts.cli_runner_s": (
        "Timeout in seconds for CLI LLM runner when no explicit timeout is provided. "
        "Fallback timeout for LLM operations via CLI. "
        "Default: 7200 (120 minutes)."
    ),
    "orchestration.timeouts.llm_stream_idle_s": (
        "Idle timeout in seconds for streaming LLM output. "
        "If no stdout/stderr arrives within this window, the subprocess is terminated "
        "and retried. Set to 0 to disable. Default: 300 (5 minutes)."
    ),
    # ==========================================================================
    # Orchestration Settings - Progress Visibility
    # ==========================================================================
    "orchestration.progress": "Progress visibility settings for execution monitoring.",
    "orchestration.progress.heartbeat_interval_s": (
        "Interval in seconds between heartbeat progress messages during agent execution. "
        "Automatically scaled by verbosity: QUIET (3x), PROGRESS (1x), DETAIL (0.5x). "
        "Can be overridden with OBRA_HEARTBEAT_INTERVAL environment variable. "
        "Default: 60 seconds."
    ),
    "orchestration.progress.heartbeat_initial_delay_s": (
        "Delay in seconds before first heartbeat message is shown. "
        "Prevents noise for quick tasks. Set to 0 for immediate heartbeat visibility. "
        "Can be overridden with OBRA_HEARTBEAT_INITIAL_DELAY environment variable. "
        "Default: 30 seconds."
    ),
    # ==========================================================================
    # Orchestration Settings - Quality Gates (ADR-068)
    # ==========================================================================
    "orchestration.quality": "Quality gate thresholds for review scoring.",
    "orchestration.quality.pass_threshold": (
        "Minimum score to pass quality gate (default: 0.7). "
        "Scores at or above this threshold result in PASS decision."
    ),
    "orchestration.quality.warn_threshold": (
        "Minimum score before warning (default: 0.5). "
        "Scores below pass but at or above this threshold result in WARN decision."
    ),
    # ==========================================================================
    # Orchestration Settings - Content Limits (ADR-068)
    # ==========================================================================
    "orchestration.content": (
        "Content truncation settings derived from model context windows. "
        "Used by ContentChunker for safe content sizing."
    ),
    "orchestration.content.safety_margin": (
        "Fraction of context window to use (default: 0.8). "
        "Reserves headroom for system prompts and response tokens."
    ),
    "orchestration.content.chars_per_token": (
        "Average characters per token estimate (default: 4). "
        "Used to convert token limits to character limits."
    ),
    "orchestration.content.preserve_ends": (
        "Keep start and end when truncating (default: true). "
        "When true, preserves context from both ends with middle truncation marker."
    ),
    # ==========================================================================
    # Orchestration Settings - Resilience Policies (ADR-068)
    # ==========================================================================
    "orchestration.resilience": (
        "Handler-specific retry and timeout policies. "
        "Loaded via ResiliencePolicy.for_handler(name)."
    ),
    "orchestration.resilience.default": ("Default resilience policy for unspecified handlers."),
    "orchestration.resilience.default.max_retries": (
        "Maximum retry attempts (default: 3). "
        "Number of times to retry a failed operation before giving up."
    ),
    "orchestration.resilience.default.base_delay_s": (
        "Initial backoff delay in seconds (default: 1.0). "
        "Starting delay between retries, used with backoff strategy."
    ),
    "orchestration.resilience.default.max_delay_s": (
        "Maximum backoff delay in seconds (default: 60.0). "
        "Upper bound on delay regardless of backoff calculation."
    ),
    "orchestration.resilience.default.timeout_window_s": (
        "Total timeout window in seconds (default: 3600). "
        "Maximum time to spend on all retry attempts combined."
    ),
    "orchestration.resilience.derive": (
        "Resilience policy for derivation handler (planning phase)."
    ),
    "orchestration.resilience.derive.max_retries": (
        "Maximum retry attempts for derivation (default: 5)."
    ),
    "orchestration.resilience.derive.base_delay_s": (
        "Initial backoff delay for derivation (default: 1.0)."
    ),
    "orchestration.resilience.derive.max_delay_s": (
        "Maximum backoff delay for derivation (default: 60.0)."
    ),
    "orchestration.resilience.derive.timeout_window_s": (
        "Total timeout window for derivation (default: 900)."
    ),
    "orchestration.resilience.fix": ("Resilience policy for fix handler (issue resolution phase)."),
    "orchestration.resilience.fix.max_retries": ("Maximum retry attempts for fix (default: 3)."),
    "orchestration.resilience.fix.base_delay_s": ("Initial backoff delay for fix (default: 1.0)."),
    "orchestration.resilience.fix.max_delay_s": ("Maximum backoff delay for fix (default: 60.0)."),
    "orchestration.resilience.fix.timeout_window_s": (
        "Total timeout window for fix (default: 600)."
    ),
    # ==========================================================================
    # Execution Settings
    # ==========================================================================
    "execution": "Execution settings for DerivedPlan items.",
    "execution.parallel": "Parallel execution settings for DerivedPlan items.",
    "execution.parallel.enabled": (
        "Enable parallel execution of DerivedPlan items when --parallel is used. Default: false."
    ),
    "execution.parallel.max_workers": (
        "Maximum number of concurrent workers for parallel execution. Default: 4."
    ),
    # ==========================================================================
    # Orchestration Settings - Session Watchdog (ISSUE-HYBRID-003)
    # ==========================================================================
    "orchestration.watchdog": "Session stall detection settings.",
    "orchestration.watchdog.enabled": (
        "Enable session stall detection. When enabled, monitors for sessions that "
        "make no progress (no events logged) while no LLM subprocess is active. "
        "Default: true."
    ),
    "orchestration.watchdog.stall_timeout_s": (
        "Seconds of no events before a session is considered stalled. "
        "Only triggers when no LLM subprocess is active (LLM calls have their own monitoring). "
        "Increase for slow network environments. "
        "Default: 300 (5 minutes)."
    ),
    # ==========================================================================
    # Orchestration Settings - Interactive Guard
    # ==========================================================================
    "orchestration.interactive_guard": (
        "Interactive command guard settings for detecting and blocking prompts."
    ),
    "orchestration.interactive_guard.enabled": (
        "Enable interactive prompt detection on LLM subprocess output. Default: true."
    ),
    "orchestration.interactive_guard.patterns": (
        "List of regex patterns used to detect interactive shell prompts. "
        "Matched lines trigger LLM_INTERACTIVE_BLOCKED. "
        "Default: curated list for password/confirmation prompts."
    ),
    "orchestration.interactive_guard.retry_max": (
        "Maximum retries after interactive guard triggers. Default: 1."
    ),
    "orchestration.interactive_guard.rollback": ("Rollback policy for interactive guard triggers."),
    "orchestration.interactive_guard.rollback.enabled": (
        "Restore workspace snapshot when a rollback-triggered error occurs. Default: true."
    ),
    "orchestration.interactive_guard.rollback.trigger_codes": (
        "Error codes that trigger rollback + retry in handlers. "
        "Default: ['LLM_INTERACTIVE_BLOCKED']."
    ),
    "terms_accepted": "Terms of Service and Privacy Policy acceptance state.",
    "terms_accepted.version": "Version of Terms of Service that was accepted.",
    "terms_accepted.privacy_version": "Version of Privacy Policy that was accepted.",
    "terms_accepted.accepted_at": "Timestamp when terms were accepted.",
    # ==========================================================================
    # Auth Display Fields (read-only)
    # ==========================================================================
    "user_email": "Your authenticated email address (read-only).",
    "firebase_uid": (
        "Your unique Obra user identifier (read-only). "
        "This ID is used to identify your account in the Obra system."
    ),
    "auth_provider": (
        "Authentication provider used for sign-in (read-only). Examples: google.com, github.com."
    ),
    "display_name": "Your display name from the authentication provider (read-only).",
    "user_id": "Your email address used as user identifier (read-only).",
    # ==========================================================================
    # Server Settings - Features
    # ==========================================================================
    "features": "Feature flags and capabilities that can be enabled or disabled.",
    "features.performance_control": "Performance and resource management settings.",
    "features.performance_control.budgets": "Unified budget control for orchestration sessions.",
    "features.performance_control.budgets.enabled": (
        "Enable unified budget control for orchestration sessions. "
        "When enabled, Obra tracks time, iteration, token, and progress budgets. "
        "Sessions pause when budgets are exceeded, preventing runaway costs."
    ),
    "features.performance_control.budgets.defaults": (
        "Default budget limits when budgets are enabled."
    ),
    "features.performance_control.budgets.defaults.time_minutes": (
        "Default time budget in minutes for a single orchestration session. "
        "Session pauses when this limit is reached."
    ),
    "features.performance_control.budgets.defaults.iterations": (
        "Default iteration budget (number of LLM calls) per session. "
        "Helps prevent infinite loops or excessive API usage."
    ),
    "features.quality_automation": "Quality automation tools and agents.",
    "features.quality_automation.enabled": (
        "Master toggle for quality automation features. "
        "When disabled, all quality automation agents are inactive regardless of individual settings."
    ),
    "features.quality_automation.agents": "Specialized agents for automated tasks.",
    "features.quality_automation.agents.security_audit": (
        "Enable automatic security vulnerability scanning. "
        "Runs OWASP Top 10 checks on code changes. "
        "Recommended for production codebases."
    ),
    "features.quality_automation.agents.rca_agent": (
        "Enable root cause analysis agent. "
        "Automatically investigates test failures, errors, and unexpected behavior. "
        "Provides detailed analysis reports."
    ),
    "features.quality_automation.agents.doc_audit": (
        "Enable documentation audit agent. "
        "Checks documentation for accuracy, completeness, and staleness. "
        "Uses ROT methodology (Redundant, Outdated, Trivial)."
    ),
    "features.quality_automation.agents.test_generation": (
        "Enable test generation agent. "
        "Creates or updates tests based on code changes and objectives."
    ),
    "features.quality_automation.agents.test_execution": (
        "Enable test execution agent. Runs relevant test suites during review and verification."
    ),
    "features.quality_automation.agents.code_review": (
        "Enable automatic code review agent. "
        "Reviews code changes for best practices, potential issues, and style consistency."
    ),
    "features.quality_automation.agents.ignore_patterns": (
        "Glob patterns or directory names to exclude from agent file scanning. "
        "Use short names to match any path component (e.g., 'logs', 'research')."
    ),
    # Alternative paths for quality_automation features (direct placement in some configs)
    "features.quality_automation.code_review": (
        "Enable automatic code review. "
        "Reviews code changes for best practices, potential issues, and style consistency."
    ),
    "features.quality_automation.advanced_planning": (
        "Enable advanced planning capabilities. "
        "Includes derivative plan architecture and enhanced task breakdown."
    ),
    "features.quality_automation.documentation_governance": (
        "Enable documentation governance (DG-001). "
        "Keeps documentation synchronized with code through INDEX.yaml coupling."
    ),
    "features.advanced_planning": "Advanced planning capabilities.",
    "features.advanced_planning.enabled": (
        "Enable advanced planning features. "
        "Includes derivative plan architecture and enhanced task breakdown capabilities."
    ),
    "features.userplan": "UserPlan pipeline feature flags.",
    "features.userplan.intent_alignment": "Intent alignment QA controls for derived plans.",
    "features.userplan.intent_alignment.enabled": (
        "Run epic/story intent alignment QA during derivation."
    ),
    "features.userplan.intent_gap_check": "Post-execution intent gap check controls.",
    "features.userplan.intent_gap_check.enabled": (
        "Run story/epic intent gap checks after execution."
    ),
    "features.documentation_governance": "Documentation governance settings.",
    "features.documentation_governance.enabled": (
        "Enable documentation governance (DG-001). "
        "Keeps documentation synchronized with code through INDEX.yaml coupling."
    ),
    "features.user_experience": "User experience and interactive CLI settings.",
    "features.user_experience.enabled": (
        "Enable user experience features like clarification and dashboard output."
    ),
    "features.user_experience.dashboard": "CLI dashboard display settings.",
    "features.user_experience.dashboard.enabled": ("Master toggle for CLI dashboard UI elements."),
    "features.user_experience.dashboard.footer_hint": (
        "Show the Ctrl+C footer hint with resume instructions."
    ),
    "features.user_experience.dashboard.task_tracker": (
        "Show a task tracker with current and upcoming plan items."
    ),
    "features.user_experience.dashboard.task_tracker_max_next": (
        "Maximum number of upcoming tasks to display in the tracker."
    ),
    "features.workflow": "Workflow orchestration settings.",
    "features.workflow.enabled": (
        "Enable pattern-guided workflow execution. "
        "Uses ProcessGuardian for validation and guided execution patterns."
    ),
    "features.workflow.process_patterns": "Process pattern configurations for workflow execution.",
    # ==========================================================================
    # Server Settings - Presets
    # ==========================================================================
    "preset": (
        "Configuration preset name. "
        "Presets are curated configurations for different use cases. "
        "Your overrides are applied on top of the preset defaults."
    ),
    # ==========================================================================
    # Advanced Settings (additional entries)
    # ==========================================================================
    "advanced.debug_mode": (
        "Enable debug mode for verbose logging. "
        "Useful for troubleshooting but produces much more output."
    ),
    "advanced.experimental_features": (
        "Enable experimental features that may be unstable. "
        "These features are in development and may change or be removed."
    ),
    "advanced.telemetry": "Telemetry and usage analytics settings.",
    "advanced.telemetry.enabled": (
        "Enable anonymous usage telemetry. "
        "Helps improve Obra by sending anonymized usage statistics. "
        "No personal data or code is ever sent."
    ),
}

# Metadata for configuration paths (used by CLI and TUI helpers)
# Currently supports: sensitive (bool)
CONFIG_METADATA: dict[str, dict[str, object]] = {
    # Auth/session secrets
    "auth_token": {"sensitive": True},
    "refresh_token": {"sensitive": True},
    "firebase_uid": {"sensitive": True},
    "firebase_api_key": {"sensitive": True},
    "token_expires_at": {"sensitive": True},
    # Core orchestration toggles - locked to prevent breaking the system
    "features.core_orchestration.enabled": {
        "locked": True,
        "lock_reason": "Core system setting; use presets instead.",
    },
    "features.core_orchestration.state_manager": {
        "locked": True,
        "lock_reason": "Core system setting; disabling breaks state management.",
    },
    "features.core_orchestration.orchestrator": {
        "locked": True,
        "lock_reason": "Core system setting; disabling breaks orchestration.",
    },
    "features.core_orchestration.llm_provider": {
        "locked": True,
        "lock_reason": "Core system setting; disabling breaks provider selection.",
    },
    "features.core_orchestration.implementation_agent": {
        "locked": True,
        "lock_reason": "Core system setting; disabling breaks implementation.",
    },
    "features.core_orchestration.config_loading": {
        "locked": True,
        "lock_reason": "Core system setting; disabling breaks config loading.",
    },
    "features.core_orchestration.response_validation": {
        "locked": True,
        "lock_reason": "Core system setting; disabling breaks validation.",
    },
    "features.core_orchestration.context_awareness": {
        "locked": True,
        "lock_reason": "Core system setting; disabling breaks context handling.",
    },
    "features.core_orchestration.working_memory": {
        "locked": True,
        "lock_reason": "Core system setting; disabling breaks working memory.",
    },
}


def get_description(path: str) -> str | None:
    """Get description for a configuration path.

    Args:
        path: Dot-notation path like "llm.orchestrator.provider"

    Returns:
        Description string or None if not found
    """
    return CONFIG_DESCRIPTIONS.get(path)


def is_sensitive(path: str) -> bool:
    """Check if a configuration path is marked as sensitive.

    Args:
        path: Dot-notation path like "llm.orchestrator.provider"

    Returns:
        True if the path should be redacted by default
    """
    meta = CONFIG_METADATA.get(path)
    if meta:
        return bool(meta.get("sensitive"))

    # Fallback pattern checks for unknown paths
    if path.startswith(("auth.", "providers.")):
        return True
    return bool(path.endswith((".api_key", ".token")))


def is_locked(path: str) -> bool:
    """Check if a configuration path is locked (read-only)."""
    meta = CONFIG_METADATA.get(path)
    if meta:
        return bool(meta.get("locked"))
    return False


def get_lock_reason(path: str) -> str | None:
    """Return lock reason for a path, if any."""
    meta = CONFIG_METADATA.get(path)
    if meta:
        reason = meta.get("lock_reason")
        if isinstance(reason, str):
            return reason
    return None


def get_all_paths() -> list[str]:
    """Get all documented configuration paths.

    Returns:
        List of all paths that have descriptions
    """
    return list(CONFIG_DESCRIPTIONS.keys())


# Provider-specific model choices - DYNAMICALLY LOADED from obra.model_registry
# This ensures config command always shows correct, up-to-date model lists
def _load_provider_model_choices() -> dict[str, list[str]]:
    """Load model choices from authoritative MODEL_REGISTRY.

    Returns dict mapping provider name to list of usable model IDs.
    Smart alias filtering:
    - Prefer explicit full names (claude-sonnet-4-5) over short aliases (sonnet)
    - When multiple aliases point to same target, prefer the longer/explicit one
    - Skip deprecated models

    Note: Returns actual model names only. Callers add "per-tier" or other
    special options as needed for their context.
    """
    from obra.model_registry import MODEL_REGISTRY, ModelStatus

    choices: dict[str, list[str]] = {}
    for provider_name, provider_config in MODEL_REGISTRY.items():
        # Start with empty list - actual model names only (no "default")
        model_list: list[str] = []

        # Group models by their resolve target
        # Key: target (or model_id if no target), Value: list of (model_id, length)
        target_groups: dict[str, list[tuple[str, int]]] = {}

        for model_id, model_info in provider_config.models.items():
            # Skip deprecated models
            if model_info.status == ModelStatus.DEPRECATED:
                continue

            # Determine the target (what this model resolves to)
            target = getattr(model_info, "resolves_to", None) or model_id

            if target not in target_groups:
                target_groups[target] = []
            target_groups[target].append((model_id, len(model_id)))

        # For each target, pick the LONGEST model_id (most explicit name)
        for _target, model_ids in target_groups.items():
            # Sort by length descending, pick longest
            model_ids.sort(key=lambda x: -x[1])
            best_model_id = model_ids[0][0]
            model_list.append(best_model_id)

        choices[provider_name] = model_list

    return choices


# Lazy-loaded to avoid circular imports
_PROVIDER_MODEL_CHOICES_CACHE: dict[str, list[str]] | None = None


def _get_provider_model_choices() -> dict[str, list[str]]:
    """Get cached provider model choices, loading on first access."""
    global _PROVIDER_MODEL_CHOICES_CACHE
    if _PROVIDER_MODEL_CHOICES_CACHE is None:
        _PROVIDER_MODEL_CHOICES_CACHE = _load_provider_model_choices()
    return _PROVIDER_MODEL_CHOICES_CACHE


# Mapping of paths to their choices (for enum types)
# Note: model choices are dynamically determined by provider via MODEL_REGISTRY
# Provider list is also dynamically loaded from MODEL_REGISTRY
def _get_provider_list(include_local: bool = True) -> list[str]:
    """Get list of supported providers from MODEL_REGISTRY.

    Args:
        include_local: Include local providers like Ollama.
    """
    from obra.model_registry import get_provider_names

    providers = get_provider_names()
    if include_local:
        return providers
    return [p for p in providers if p != "ollama"]


CONFIG_CHOICES: dict[str, list[str] | None] = {
    # Providers loaded dynamically - will be populated by get_choices()
    "llm.orchestrator.provider": None,
    "llm.orchestrator.model": ["per-tier"],  # Fallback - dynamically populated by provider
    "llm.orchestrator.auth_method": ["oauth", "api_key"],
    "llm.thinking_level": ["off", "low", "medium", "high", "extra high", "maximum"],
    "llm.reasoning.force_level": ["null", "off", "low", "medium", "high", "maximum"],
    "llm.reasoning.tiers.fast.min_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.reasoning.tiers.fast.max_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.reasoning.tiers.medium.min_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.reasoning.tiers.medium.max_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.reasoning.tiers.high.min_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.reasoning.tiers.high.max_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.orchestrator.thinking_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.orchestrator.tiers.fast": None,  # Dynamically populated by orchestrator provider
    "llm.orchestrator.tiers.medium": None,  # Dynamically populated by orchestrator provider
    "llm.orchestrator.tiers.high": None,  # Dynamically populated by orchestrator provider
    "llm.implementation.provider": None,
    "llm.implementation.model": ["per-tier"],  # Fallback - dynamically populated by provider
    "llm.implementation.auth_method": ["oauth", "api_key"],
    "llm.implementation.thinking_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.implementation.tiers.fast": None,  # Dynamically populated by implementation provider
    "llm.implementation.tiers.medium": None,  # Dynamically populated by implementation provider
    "llm.implementation.tiers.high": None,  # Dynamically populated by implementation provider
    "planning.enrichment.stages.assumptions.model_tier": ["fast", "medium", "high"],
    "planning.enrichment.stages.analogues.model_tier": ["fast", "medium", "high"],
    "planning.enrichment.stages.brief.model_tier": ["fast", "medium", "high"],
    "planning.enrichment.stages.derive.model_tier": ["fast", "medium", "high"],
    "planning.enrichment.stages.review.model_tier": ["fast", "medium", "high"],
    "planning.intent_alignment.model_tier": ["fast", "medium", "high"],
    "planning.intent_gap_check.model_tier": ["fast", "medium", "high"],
    "planning.enrichment.stages.assumptions.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "maximum",
    ],
    "planning.enrichment.stages.analogues.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "maximum",
    ],
    "planning.enrichment.stages.brief.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "maximum",
    ],
    "planning.enrichment.stages.derive.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "maximum",
    ],
    "planning.enrichment.stages.review.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "maximum",
    ],
    "planning.intent_alignment.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "maximum",
    ],
    "planning.intent_gap_check.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "maximum",
    ],
}


def get_choices(path: str, current_config: dict | None = None) -> list[str] | None:
    """Get valid choices for an enum-type setting.

    For model settings, returns provider-specific choices if provider is known.
    For provider settings, returns dynamic list from MODEL_REGISTRY.

    Args:
        path: Dot-notation path
        current_config: Optional current config dict to determine provider

    Returns:
        List of valid choices or None if not an enum type
    """
    # Handle top-level llm.provider with "per-role" fast-config option
    if path == "llm.provider":
        return ["per-role", *_get_provider_list()]

    # Handle top-level llm.model with "per-tier" fast-config option
    if path == "llm.model":
        # Collect all models from non-Ollama providers (Ollama is advanced/local only)
        # Note: 'default' is NOT included here - use 'per-tier' for default behavior
        all_models = ["per-tier"]
        model_choices = _get_provider_model_choices()
        seen = {"per-tier", "default"}  # Skip 'default' from provider lists
        # Get the provider list that excludes Ollama
        visible_providers = set(_get_provider_list(include_local=False))
        for provider, models in model_choices.items():
            # Skip Ollama models (advanced local use only)
            if provider not in visible_providers:
                continue
            for m in models:
                if m not in seen:
                    all_models.append(m)
                    seen.add(m)
        return all_models

    # Handle provider choices dynamically (role-specific)
    # Role-level providers (llm.orchestrator.provider, llm.implementation.provider)
    # get "per-tier" option to allow per-tier provider selection
    if path in ("llm.orchestrator.provider", "llm.implementation.provider"):
        return ["per-tier", *_get_provider_list()]

    # Other provider paths (tier-level, etc.) get standard provider list
    if path.endswith(".provider"):
        return _get_provider_list()

    # Handle role-level model choices (llm.orchestrator.model, llm.implementation.model)
    if path in ("llm.orchestrator.model", "llm.implementation.model") and current_config:
        # Determine provider path
        if "orchestrator" in path:
            provider_path = "llm.orchestrator.provider"
        else:
            provider_path = "llm.implementation.provider"

        # Get the current provider from config (with fast-config fallback)
        role_provider: Any = _get_nested_value(current_config, provider_path)
        if not isinstance(role_provider, str) or role_provider == "per-role":
            top_provider = _get_nested_value(current_config, "llm.provider")
            if isinstance(top_provider, str) and top_provider != "per-role":
                role_provider = top_provider

        if isinstance(role_provider, str) and role_provider != "per-role":
            model_choices = _get_provider_model_choices()
            if role_provider in model_choices:
                # Role-level: prepend "per-tier" to allow delegation to tier settings
                return ["per-tier"] + model_choices[role_provider]

    # Handle tier model choices (fast/medium/high)
    # Tiers are leaf-level - only actual model names, no "per-tier" or "default"
    if current_config and ".tiers." in path and (path.endswith((".fast", ".medium", ".high"))):
        # Determine if this is orchestrator or implementation tier
        if "llm.orchestrator.tiers" in path:
            provider_path = "llm.orchestrator.provider"
        elif "llm.implementation.tiers" in path:
            provider_path = "llm.implementation.provider"
        else:
            return CONFIG_CHOICES.get(path)

        # Get the role provider from config (with fast-config fallback)
        tier_provider: Any = _get_nested_value(current_config, provider_path)

        # Fast-config fallback: if role provider not set, use top-level llm.provider
        if not isinstance(tier_provider, str) or tier_provider == "per-role":
            top_provider = _get_nested_value(current_config, "llm.provider")
            if isinstance(top_provider, str) and top_provider != "per-role":
                tier_provider = top_provider

        # If provider is "per-tier", show all models from all providers
        # This allows mixing providers across tiers
        if tier_provider == "per-tier":
            model_choices = _get_provider_model_choices()
            tier_models: list[str] = []
            tier_seen: set[str] = {"default"}  # Skip 'default'
            visible_providers = set(_get_provider_list())
            for prov, models in model_choices.items():
                if prov not in visible_providers:
                    continue
                for m in models:
                    if m not in tier_seen:
                        tier_models.append(m)
                        tier_seen.add(m)
            return tier_models if tier_models else None

        if isinstance(tier_provider, str) and tier_provider not in ("per-role", "per-tier"):
            model_choices = _get_provider_model_choices()
            if tier_provider in model_choices:
                # Tiers get actual model names only (already no "default")
                return model_choices[tier_provider]

    return CONFIG_CHOICES.get(path)


def _get_nested_value(config: dict, path: str) -> object | None:
    """Get a nested value from config dict using dot notation.

    Args:
        config: Configuration dictionary
        path: Dot-notation path like "llm.orchestrator.provider"

    Returns:
        Value at that path or None if not found
    """
    parts = path.split(".")
    current = config
    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


# Mapping of paths to their default values
CONFIG_DEFAULTS: dict[str, object] = {
    # Quick settings - special defaults for fast-config pattern
    "llm.provider": "per-role",  # per-role = children decide their own provider
    "llm.model": "per-tier",  # per-tier = tiers decide their own model
    "llm.thinking_level": "medium",
    "llm.reasoning.force_level": None,
    "llm.reasoning.strict_mode": False,
    "llm.reasoning.tiers.fast.min_level": "off",
    "llm.reasoning.tiers.fast.max_level": "maximum",
    "llm.reasoning.tiers.medium.min_level": "off",
    "llm.reasoning.tiers.medium.max_level": "maximum",
    "llm.reasoning.tiers.high.min_level": "off",
    "llm.reasoning.tiers.high.max_level": "maximum",
    # Role-specific defaults
    "llm.orchestrator.provider": "anthropic",
    "llm.orchestrator.model": "per-tier",  # per-tier = tiers decide their own model
    "llm.orchestrator.auth_method": "oauth",
    "llm.orchestrator.thinking_level": "medium",
    "llm.git.skip_check": True,
    "llm.git.auto_init": False,
    "llm.git.auto_init_require_depth": 2,
    "llm.git.auto_init_max_files": 1000,
    "llm.git.auto_init_blacklist": [],
    # Tier defaults use explicit model names (not "default")
    "llm.orchestrator.tiers.fast": "claude-haiku-4-5",
    "llm.orchestrator.tiers.medium": "claude-sonnet-4-5",
    "llm.orchestrator.tiers.high": "claude-opus-4-5",
    "llm.implementation.provider": "anthropic",
    "llm.implementation.model": "per-tier",  # per-tier = tiers decide their own model
    "llm.implementation.auth_method": "oauth",
    "llm.implementation.thinking_level": "medium",
    "llm.implementation.tiers.fast": "claude-haiku-4-5",
    "llm.implementation.tiers.medium": "claude-sonnet-4-5",
    "llm.implementation.tiers.high": "claude-opus-4-5",
    # Role-based LLM configuration defaults (ADR-069)
    "llm.roles.derive": "orchestrator",
    "llm.roles.examine": "orchestrator",
    "llm.roles.revise": "orchestrator",
    "llm.roles.execute": "implementation",
    "llm.roles.fix": "implementation",
    "llm.roles.review": "implementation",
    "llm.roles.enrichment_assumptions": "orchestrator",
    "llm.roles.enrichment_analogues": "orchestrator",
    "llm.roles.enrichment_brief": "orchestrator",
    "llm_timeout": 1800,
    "orchestration.template_retention.keep_on_success": False,
    "orchestration.template_retention.keep_on_error": True,
    "orchestration.timeouts.agent_execution_s": 5400,
    "orchestration.timeouts.review_agent_s": 1800,
    "orchestration.timeouts.cli_runner_s": 7200,
    "orchestration.timeouts.llm_stream_idle_s": 300,
    "orchestration.progress.heartbeat_interval_s": 60,
    "orchestration.progress.heartbeat_initial_delay_s": 30,
    "orchestration.watchdog.enabled": True,
    "orchestration.watchdog.stall_timeout_s": 300,
    "orchestration.interactive_guard.enabled": True,
    "orchestration.interactive_guard.patterns": [
        r"(?i)\bpassword\b",
        r"(?i)enter passphrase",
        r"(?i)are you sure.*\?(\s*\[y/n\]|\s*\(y/n\))?",
        r"(?i)continue\?\s*(\[y/n\]|\(y/n\))?",
        r"(?i)press any key",
        r"(?i)enter .* to continue",
    ],
    "orchestration.interactive_guard.retry_max": 1,
    "orchestration.interactive_guard.rollback.enabled": True,
    "orchestration.interactive_guard.rollback.trigger_codes": ["LLM_INTERACTIVE_BLOCKED"],
    "features.performance_control.budgets.enabled": True,
    "features.performance_control.budgets.defaults.time_minutes": 30,
    "features.performance_control.budgets.defaults.iterations": 50,
    "features.quality_automation.agents.security_audit": False,
    "features.quality_automation.agents.rca_agent": True,
    "features.quality_automation.agents.doc_audit": False,
    "features.quality_automation.agents.code_review": True,
    "features.quality_automation.agents.test_generation": True,
    "features.quality_automation.agents.test_execution": True,
    "features.quality_automation.agents.ignore_patterns": [
        "logs",
        "firebase-seed-data",
        "research",
        "emulator-backup",
    ],
    "features.workflow.enabled": True,
    "advanced.debug_mode": False,
    "advanced.experimental_features": False,
    "advanced.telemetry.enabled": True,
    "planning.enrichment.enabled": False,
    "planning.enrichment.always_on": True,
    "planning.enrichment.stages.assumptions.model_tier": "medium",
    "planning.enrichment.stages.assumptions.reasoning_level": "medium",
    "planning.enrichment.stages.assumptions.max_passes": 1,
    "planning.enrichment.stages.assumptions.timeout_s": 1800,
    "planning.enrichment.stages.assumptions.max_questions": 3,
    "planning.enrichment.stages.analogues.model_tier": "high",
    "planning.enrichment.stages.analogues.reasoning_level": "high",
    "planning.enrichment.stages.analogues.max_passes": 1,
    "planning.enrichment.stages.analogues.timeout_s": 1800,
    "planning.enrichment.stages.brief.model_tier": "medium",
    "planning.enrichment.stages.brief.reasoning_level": "medium",
    "planning.enrichment.stages.brief.max_passes": 1,
    "planning.enrichment.stages.brief.timeout_s": 1800,
    "planning.enrichment.stages.derive.model_tier": "high",
    "planning.enrichment.stages.derive.reasoning_level": "high",
    "planning.enrichment.stages.derive.max_passes": 1,
    "planning.enrichment.stages.derive.timeout_s": 1800,
    "planning.enrichment.stages.review.model_tier": "high",
    "planning.enrichment.stages.review.reasoning_level": "high",
    "planning.enrichment.stages.review.max_passes": 1,
    "planning.enrichment.stages.review.timeout_s": 1800,
    "planning.enrichment.non_inferable_categories": [],  # Empty by default
    "planning.enrichment.diff.path_template": "~/.obra/intents/{intent_id}.diff.json",
    "planning.enrichment.diff.retention.max_files": 200,
    "planning.enrichment.artifacts.dir": "~/.obra/intents/artifacts",
    "planning.enrichment.artifacts.retention.max_files": 200,
    "planning.enrichment.analogue_cache.global_path": "~/.obra/analogue_cache.json",
    "planning.enrichment.analogue_cache.project_path": ".obra/analogue_cache.json",
    "planning.enrichment.telemetry.enabled": False,
    "planning.enrichment.telemetry.include_content": False,
    "planning.enrichment.telemetry.output_path": "~/.obra/telemetry/enrichment.jsonl",
    "planning.intent_alignment.model_tier": "high",
    "planning.intent_alignment.reasoning_level": "high",
    "planning.intent_alignment.max_passes": 3,
    "planning.intent_alignment.timeout_s": 900,
    "planning.intent_alignment.block_on_fail": False,
    "planning.intent_gap_check.story_enabled": True,
    "planning.intent_gap_check.epic_enabled": True,
    "planning.intent_gap_check.auto_append": True,
    "planning.intent_gap_check.max_new_stories": 3,
    "planning.intent_gap_check.model_tier": "high",
    "planning.intent_gap_check.reasoning_level": "high",
    "planning.intent_gap_check.max_passes": 3,
    "planning.intent_gap_check.timeout_s": 900,
    "planning.intent_gap_check.artifacts_dir": "~/.obra/intent_gap_reports",
}


def get_default(path: str) -> object:
    """Get default value for a setting.

    Args:
        path: Dot-notation path

    Returns:
        Default value or None if not defined
    """
    return CONFIG_DEFAULTS.get(path)


# Setting tier mapping (basic, standard, advanced)
SETTING_TIERS: dict[str, str] = {
    # Basic - most users need these
    "llm.orchestrator.provider": "basic",
    "llm.orchestrator.model": "basic",
    "llm.implementation.provider": "basic",
    "llm.implementation.model": "basic",
    "preset": "basic",
    # Standard - common use
    "llm.thinking_level": "standard",
    "llm.reasoning": "standard",
    "llm.reasoning.force_level": "standard",
    "llm.reasoning.strict_mode": "standard",
    "llm.reasoning.tiers": "standard",
    "llm.reasoning.tiers.fast": "standard",
    "llm.reasoning.tiers.fast.min_level": "standard",
    "llm.reasoning.tiers.fast.max_level": "standard",
    "llm.reasoning.tiers.medium": "standard",
    "llm.reasoning.tiers.medium.min_level": "standard",
    "llm.reasoning.tiers.medium.max_level": "standard",
    "llm.reasoning.tiers.high": "standard",
    "llm.reasoning.tiers.high.min_level": "standard",
    "llm.reasoning.tiers.high.max_level": "standard",
    "llm.orchestrator.thinking_level": "standard",
    "llm.implementation.thinking_level": "standard",
    "llm.orchestrator.auth_method": "standard",
    "llm.implementation.auth_method": "standard",
    "llm.orchestrator.tiers": "standard",
    "llm.orchestrator.tiers.fast": "standard",
    "llm.orchestrator.tiers.medium": "standard",
    "llm.orchestrator.tiers.high": "standard",
    "llm.implementation.tiers": "standard",
    "llm.implementation.tiers.fast": "standard",
    "llm.implementation.tiers.medium": "standard",
    "llm.implementation.tiers.high": "standard",
    "features.performance_control.budgets.enabled": "standard",
    "features.quality_automation.agents.security_audit": "standard",
    "features.quality_automation.agents.rca_agent": "standard",
    "features.quality_automation.agents.doc_audit": "standard",
    "features.quality_automation.agents.code_review": "standard",
    "features.quality_automation.agents.test_generation": "standard",
    "features.quality_automation.agents.test_execution": "standard",
    "features.quality_automation.agents.ignore_patterns": "standard",
    "features.workflow.enabled": "standard",
    # Git settings - visible for provider-aware auto-configuration
    "llm.git": "basic",
    "llm.git.skip_check": "basic",
    "llm.git.auto_init": "standard",
    "llm.git.auto_init_require_depth": "standard",
    "llm.git.auto_init_max_files": "standard",
    "llm.git.auto_init_blacklist": "advanced",
    # Role-based LLM configuration (ADR-069) - advanced for fine-grained control
    "llm.roles": "advanced",
    "llm.roles.derive": "advanced",
    "llm.roles.examine": "advanced",
    "llm.roles.revise": "advanced",
    "llm.roles.execute": "advanced",
    "llm.roles.fix": "advanced",
    "llm.roles.review": "advanced",
    "llm.roles.enrichment_assumptions": "advanced",
    "llm.roles.enrichment_analogues": "advanced",
    "llm.roles.enrichment_brief": "advanced",
    # Advanced - expert users
    "api_base_url": "advanced",
    "llm_timeout": "advanced",
    "orchestration.template_retention": "advanced",
    "orchestration.template_retention.keep_on_success": "advanced",
    "orchestration.template_retention.keep_on_error": "advanced",
    "orchestration.timeouts.agent_execution_s": "advanced",
    "orchestration.timeouts.review_agent_s": "advanced",
    "orchestration.timeouts.cli_runner_s": "advanced",
    "orchestration.timeouts.llm_stream_idle_s": "advanced",
    "orchestration.progress.heartbeat_interval_s": "advanced",
    "orchestration.progress.heartbeat_initial_delay_s": "advanced",
    "orchestration.watchdog.enabled": "advanced",
    "orchestration.watchdog.stall_timeout_s": "advanced",
    "orchestration.interactive_guard.enabled": "advanced",
    "orchestration.interactive_guard.patterns": "advanced",
    "orchestration.interactive_guard.retry_max": "advanced",
    "orchestration.interactive_guard.rollback.enabled": "advanced",
    "orchestration.interactive_guard.rollback.trigger_codes": "advanced",
    "advanced.debug_mode": "advanced",
    "advanced.experimental_features": "advanced",
    "advanced.telemetry.enabled": "advanced",
    "features.performance_control.budgets.defaults.time_minutes": "advanced",
    "features.performance_control.budgets.defaults.iterations": "advanced",
    "planning": "advanced",
    "planning.enrichment": "advanced",
    "planning.enrichment.enabled": "advanced",
    "planning.enrichment.always_on": "advanced",
    "planning.enrichment.stages": "advanced",
    "planning.enrichment.stages.assumptions": "advanced",
    "planning.enrichment.stages.assumptions.model_tier": "advanced",
    "planning.enrichment.stages.assumptions.reasoning_level": "advanced",
    "planning.enrichment.stages.assumptions.max_passes": "advanced",
    "planning.enrichment.stages.assumptions.timeout_s": "advanced",
    "planning.enrichment.stages.assumptions.max_questions": "advanced",
    "planning.enrichment.stages.analogues": "advanced",
    "planning.enrichment.stages.analogues.model_tier": "advanced",
    "planning.enrichment.stages.analogues.reasoning_level": "advanced",
    "planning.enrichment.stages.analogues.max_passes": "advanced",
    "planning.enrichment.stages.analogues.timeout_s": "advanced",
    "planning.enrichment.stages.brief": "advanced",
    "planning.enrichment.stages.brief.model_tier": "advanced",
    "planning.enrichment.stages.brief.reasoning_level": "advanced",
    "planning.enrichment.stages.brief.max_passes": "advanced",
    "planning.enrichment.stages.brief.timeout_s": "advanced",
    "planning.enrichment.stages.derive": "advanced",
    "planning.enrichment.stages.derive.model_tier": "advanced",
    "planning.enrichment.stages.derive.reasoning_level": "advanced",
    "planning.enrichment.stages.derive.max_passes": "advanced",
    "planning.enrichment.stages.derive.timeout_s": "advanced",
    "planning.enrichment.stages.review": "advanced",
    "planning.enrichment.stages.review.model_tier": "advanced",
    "planning.enrichment.stages.review.reasoning_level": "advanced",
    "planning.enrichment.stages.review.max_passes": "advanced",
    "planning.enrichment.stages.review.timeout_s": "advanced",
    "planning.enrichment.non_inferable_categories": "advanced",
    "planning.enrichment.diff": "advanced",
    "planning.enrichment.diff.path_template": "advanced",
    "planning.enrichment.diff.retention": "advanced",
    "planning.enrichment.diff.retention.max_files": "advanced",
    "planning.enrichment.artifacts": "advanced",
    "planning.enrichment.artifacts.dir": "advanced",
    "planning.enrichment.artifacts.retention": "advanced",
    "planning.enrichment.artifacts.retention.max_files": "advanced",
    "planning.enrichment.analogue_cache": "advanced",
    "planning.enrichment.analogue_cache.global_path": "advanced",
    "planning.enrichment.analogue_cache.project_path": "advanced",
    "planning.enrichment.telemetry": "advanced",
    "planning.enrichment.telemetry.enabled": "advanced",
    "planning.enrichment.telemetry.include_content": "advanced",
    "planning.enrichment.telemetry.output_path": "advanced",
}


def get_tier(path: str) -> str:
    """Get visibility tier for a setting.

    Args:
        path: Dot-notation path

    Returns:
        "basic", "standard", or "advanced" (defaults to "standard")
    """
    if path.startswith("advanced."):
        return "advanced"
    return SETTING_TIERS.get(path, "standard")
