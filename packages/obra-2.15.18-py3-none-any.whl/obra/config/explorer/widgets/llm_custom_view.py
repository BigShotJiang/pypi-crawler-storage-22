"""Custom LLM Configuration View widget.

Provides a detailed interface for configuring which model handles each
pipeline action, grouped by execution phase. This is the most flexible
LLM configuration option, allowing per-action model customization.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, ScrollableContainer, Vertical
from textual.message import Message
from textual.widgets import Collapsible, Select, Static

from obra.config.explorer.llm_registry import (
    get_model_cost,
    get_models,
    get_providers,
    get_role_tier_defaults,
    supports_thinking,
)
from obra.config.explorer.widgets.navigation_menu import get_menu_info
from obra.config.explorer.widgets.saveable_view import SaveableViewMixin
from obra.model_registry import MODEL_REGISTRY

if TYPE_CHECKING:
    pass


# Pipeline phases with their actions
PHASE_ACTIONS: dict[str, list[dict[str, str]]] = {
    "pre_planning": [
        {
            "id": "enrichment_assumptions",
            "name": "Assumptions",
            "description": "Gather assumptions and non-inferable questions",
        },
        {
            "id": "enrichment_analogues",
            "name": "Analogues",
            "description": "Find similar problems and patterns",
        },
        {
            "id": "enrichment_brief",
            "name": "Brief",
            "description": "Generate planning brief document",
        },
    ],
    "planning": [
        {
            "id": "derive",
            "name": "Derive",
            "description": "Break down objectives into executable plans",
        },
        {
            "id": "examine",
            "name": "Examine",
            "description": "Review plans for issues and improvements",
        },
        {
            "id": "revise",
            "name": "Revise",
            "description": "Update plans based on examination feedback",
        },
    ],
    "execution": [
        {
            "id": "execute",
            "name": "Execute",
            "description": "Implement code changes and file operations",
        },
        {
            "id": "fix",
            "name": "Fix",
            "description": "Resolve problems found during execution",
        },
    ],
    "review": [
        {
            "id": "review",
            "name": "Review",
            "description": "Perform quality and architecture review",
        },
    ],
}

PHASE_LABELS: dict[str, str] = {
    "pre_planning": "Pre-Planning (Enrichment)",
    "planning": "Planning",
    "execution": "Execution",
    "review": "Review",
}

# Phase descriptions for subtitle hints
PHASE_DESCRIPTIONS: dict[str, str] = {
    "pre_planning": "Expands your prompt with inferred requirements and context",
    "planning": "Breaks down objectives into executable work items",
    "execution": "Implements code changes and resolves issues",
    "review": "Validates quality and architecture compliance",
}

# Pipeline breadcrumb - maps phase_id to which phases to bold
# Format: list of (label, is_bold_for_this_phase)
PIPELINE_PHASES = ["Enrich", "Plan", "Execute", "Review", "Fix"]

PHASE_BOLD_MAP: dict[str, list[str]] = {
    "pre_planning": ["Enrich"],
    "planning": ["Plan"],
    "execution": ["Execute", "Fix"],  # Both are in this section
    "review": ["Review"],
}

# Actions that benefit from high-capability models (warn on downgrade)
HIGH_CAPABILITY_ACTIONS = {"derive", "examine", "review"}

# Default role to profile mappings (matches llm.py DEFAULT_ROLE_MAPPINGS)
# Legacy mapping for backward compatibility
DEFAULT_MAPPINGS: dict[str, str] = {
    "derive": "orchestrator",
    "examine": "orchestrator",
    "revise": "orchestrator",
    "execute": "implementation",
    "fix": "implementation",
    "review": "implementation",
    "enrichment_assumptions": "orchestrator",
    "enrichment_analogues": "orchestrator",
    "enrichment_brief": "orchestrator",
}

# Obra's recommended defaults per action: profile, tier, and reasoning level
# These are the optimized settings that cascade from Menu 1 → Menu 2 → Menu 3
# Format: {profile: orchestrator|implementation, tier: fast|medium|high, reasoning: off|low|medium|high|maximum}
DEFAULT_ACTION_CONFIG: dict[str, dict[str, str]] = {
    # Pre-Planning (Enrichment): All use orchestrator.high for complex analysis
    "enrichment_assumptions": {"profile": "orchestrator", "tier": "high", "reasoning": "medium"},
    "enrichment_analogues": {"profile": "orchestrator", "tier": "high", "reasoning": "medium"},
    "enrichment_brief": {"profile": "orchestrator", "tier": "high", "reasoning": "medium"},
    # Planning: All use orchestrator.high for strategic reasoning
    "derive": {"profile": "orchestrator", "tier": "high", "reasoning": "medium"},
    "examine": {"profile": "orchestrator", "tier": "high", "reasoning": "medium"},
    "revise": {"profile": "orchestrator", "tier": "high", "reasoning": "medium"},
    # Execution: execute uses medium (high volume), fix uses high (complex debugging)
    "execute": {"profile": "implementation", "tier": "medium", "reasoning": "medium"},
    "fix": {"profile": "implementation", "tier": "high", "reasoning": "medium"},
    # Review: Uses implementation.high for thorough quality assessment
    "review": {"profile": "implementation", "tier": "high", "reasoning": "medium"},
}

# Available reasoning levels with descriptions (for tooltips/hints)
REASONING_LEVELS = ["off", "low", "medium", "high", "maximum"]

REASONING_DESCRIPTIONS: dict[str, str] = {
    "off": "No extended reasoning",
    "low": "Fast, lighter reasoning",
    "medium": "Balanced speed and depth",
    "high": "Deeper reasoning for complex problems",
    "maximum": "Maximum reasoning depth",
}


@dataclass
class RoleConfig:
    """Configuration for a single pipeline role."""

    role_id: str
    profile: str  # 'orchestrator' or 'implementation'
    tier: str  # 'fast', 'medium', or 'high' - which tier to inherit from
    provider: str | None  # None = inherit from profile
    model: str | None  # None = inherit from profile.tier
    reasoning_level: str | None  # None = use default reasoning

    @property
    def is_inherited(self) -> bool:
        """Check if model is inherited from profile.tier."""
        return self.model is None and self.provider is None


class CustomLLMView(SaveableViewMixin, Static):
    """Custom LLM configuration view with per-action model selection.

    Shows all pipeline actions grouped by phase:
    - Pre-Planning: enrichment stages (assumptions, analogues, brief)
    - Planning: derive, examine, revise
    - Execution: execute, fix
    - Review: review

    Each action can be configured with:
    - Profile reference (orchestrator/implementation)
    - Explicit model override
    - Reasoning level override

    Emits:
        Changed: When any role configuration changes.
    """

    BINDINGS = [
        Binding("r", "reset_section", "Reset Section", show=True),
    ]

    DEFAULT_CSS = """
    CustomLLMView {
        width: 100%;
        height: auto;
        padding: 1 2;
    }

    CustomLLMView > Vertical {
        width: 100%;
        height: auto;
    }

    CustomLLMView .header {
        text-style: bold;
        text-align: center;
        margin-bottom: 1;
        width: 100%;
    }

    CustomLLMView .description {
        color: $text-muted;
        text-align: center;
        margin-bottom: 2;
        width: 100%;
    }

    CustomLLMView .reasoning-hint {
        color: $text-disabled;
        text-align: center;
        margin-bottom: 1;
        padding: 0 2;
        text-style: italic;
        width: 100%;
    }

    CustomLLMView .provider-section {
        width: 100%;
        margin-bottom: 1;
        align: center middle;
    }

    CustomLLMView .provider-container {
        width: 60;
        height: auto;
    }

    CustomLLMView .phase-section {
        width: 100%;
        margin-bottom: 1;
    }

    CustomLLMView .role-row {
        width: 100%;
        height: auto;
        padding: 0 1;
        margin-bottom: 1;
    }

    CustomLLMView .role-info {
        width: 1fr;
        height: auto;
    }

    CustomLLMView .role-name {
        text-style: bold;
    }

    CustomLLMView .role-description {
        color: $text-muted;
    }

    CustomLLMView .role-controls {
        width: 2fr;
        height: auto;
    }

    CustomLLMView .inheritance-indicator {
        color: $text-muted;
        text-style: italic;
    }

    CustomLLMView .explicit-indicator {
        color: $success;
    }

    CustomLLMView Select {
        width: 100%;
        margin-bottom: 0;
    }

    CustomLLMView .control-row {
        width: 100%;
        height: auto;
    }

    CustomLLMView .column-headers {
        width: 100%;
        height: auto;
        margin-bottom: 0;
    }

    CustomLLMView .column-header {
        text-style: bold;
        color: $text-muted;
    }

    CustomLLMView .provider-header {
        width: 24;
    }

    CustomLLMView .model-header {
        width: 1fr;
    }

    CustomLLMView .reasoning-header {
        width: 16;
    }

    CustomLLMView .provider-select {
        width: 24;
    }

    CustomLLMView .model-select {
        width: 1fr;
    }

    CustomLLMView .reasoning-select {
        width: 16;
    }

    CustomLLMView .phase-subtitle {
        width: 1fr;
        color: $text-muted;
        text-style: italic;
        padding-left: 2;
        margin-bottom: 1;
    }

    CustomLLMView .phase-breadcrumb {
        width: auto;
        color: $text-disabled;
        text-align: right;
        padding-right: 2;
    }

    CustomLLMView .phase-header-row {
        width: 100%;
        height: auto;
        margin-bottom: 1;
    }

    CustomLLMView .downgrade-warning {
        color: $warning;
        text-style: italic;
        padding-left: 2;
        margin-bottom: 1;
    }

    CustomLLMView .help-text {
        color: $text-muted;
        margin-top: 2;
        text-align: center;
        width: 100%;
    }

    CustomLLMView Collapsible {
        width: 100%;
    }

    CustomLLMView #phases-scroll {
        width: 100%;
        height: 1fr;
        min-height: 20;
    }
    """

    class Changed(Message):
        """Message emitted when LLM configuration changes."""

        def __init__(self, role_configs: dict[str, RoleConfig]) -> None:
            """Initialize the Changed message.

            Args:
                role_configs: Dict mapping role_id to RoleConfig
            """
            super().__init__()
            self.role_configs = role_configs

    def __init__(
        self,
        current_configs: dict[str, RoleConfig] | None = None,
        orchestrator_provider: str = "anthropic",
        orchestrator_tiers: dict[str, str] | None = None,
        implementation_provider: str = "anthropic",
        implementation_tiers: dict[str, str] | None = None,
        **kwargs,
    ) -> None:
        """Initialize the CustomLLMView.

        Args:
            current_configs: Current role configurations (or None for defaults)
            orchestrator_provider: Provider configured for orchestrator profile
            orchestrator_tiers: Tier models for orchestrator {fast, medium, high}
            implementation_provider: Provider configured for implementation profile
            implementation_tiers: Tier models for implementation {fast, medium, high}
        """
        super().__init__(**kwargs)
        self._role_configs: dict[str, RoleConfig] = current_configs or {}

        # Store profile tier configs for dynamic inheritance resolution
        # This is what Menu 2 (Moderate) sets - tier-based models per profile
        self._profile_tier_configs = {
            "orchestrator": {
                "provider": orchestrator_provider,
                "tiers": orchestrator_tiers
                or {"fast": "default", "medium": "default", "high": "default"},
            },
            "implementation": {
                "provider": implementation_provider,
                "tiers": implementation_tiers
                or {"fast": "default", "medium": "default", "high": "default"},
            },
        }

        # Initialize defaults using DEFAULT_ACTION_CONFIG if not provided
        for role_id, action_config in DEFAULT_ACTION_CONFIG.items():
            if role_id not in self._role_configs:
                self._role_configs[role_id] = RoleConfig(
                    role_id=role_id,
                    profile=action_config["profile"],
                    tier=action_config["tier"],
                    provider=None,  # Inherit from profile
                    model=None,  # Inherit from profile.tier
                    reasoning_level=None,  # Use default
                )

        # Suppress change emissions during initial mount
        self._initializing = True
        # Take snapshot for dirty tracking
        self._snapshot_state()

    def on_mount(self) -> None:
        """Allow change emissions after mount completes."""
        from obra.config.explorer.debug import is_debug_enabled, log_action

        # CRITICAL: Use call_after_refresh to delay setting _initializing = False
        # until AFTER all queued Select.Changed events from initial value setting
        # have been processed. This prevents phantom changes from mount events.
        def finish_initialization() -> None:
            self._initializing = False
            # Re-snapshot state AFTER all mount events are processed
            self._snapshot_state()
            if is_debug_enabled():
                log_action(
                    "CustomLLMView.on_mount.finish_init",
                    f"_initializing={self._initializing}, snapshot taken",
                )

        self.call_after_refresh(finish_initialization)

    def compose(self) -> ComposeResult:
        """Create the view content."""
        menu_info = get_menu_info("custom_llm")
        yield Static(menu_info["label"], classes="header")
        yield Static(menu_info["subtitle"], classes="description")

        # Hint about reasoning level support
        yield Static(
            "Reasoning: Off → Low (fast) → Medium (balanced) → High/Maximum (thorough). "
            "OpenAI only.",
            classes="reasoning-hint",
        )

        # Scrollable container for phase sections
        with ScrollableContainer(id="phases-scroll"):
            # Phase sections (collapsible)
            for phase_id, phase_label in PHASE_LABELS.items():
                with Collapsible(title=phase_label, collapsed=False, id=f"phase-{phase_id}"):
                    # Phase header with breadcrumb
                    yield from self._compose_phase_header(phase_id)
                    # Column headers
                    yield from self._compose_column_headers()
                    for action in PHASE_ACTIONS[phase_id]:
                        yield from self._compose_role_row(action)

        yield Static(
            "★ = benefits from high-capability models. "
            "Inherit = default from LLM Config. "
            "r = reset section.",
            classes="help-text",
        )

    def _compose_phase_header(self, phase_id: str) -> ComposeResult:
        """Compose phase subtitle and pipeline breadcrumb.

        Args:
            phase_id: The phase identifier (pre_planning, planning, etc.)
        """
        # Build breadcrumb with current phase(s) bolded
        bold_phases = PHASE_BOLD_MAP.get(phase_id, [])
        breadcrumb_parts = []
        for phase_name in PIPELINE_PHASES:
            if phase_name in bold_phases:
                breadcrumb_parts.append(f"[bold]{phase_name}[/bold]")
            else:
                breadcrumb_parts.append(phase_name)
        breadcrumb = " · ".join(breadcrumb_parts)

        with Horizontal(classes="phase-header-row"):
            # Left: Phase description
            description = PHASE_DESCRIPTIONS.get(phase_id, "")
            yield Static(description, classes="phase-subtitle", markup=False)
            # Right: Pipeline breadcrumb
            yield Static(breadcrumb, classes="phase-breadcrumb", markup=True)

    def _compose_column_headers(self) -> ComposeResult:
        """Compose column headers for the role controls."""
        with Horizontal(classes="role-row column-headers"):
            # Spacer for role info column
            yield Static("", classes="role-info")
            # Headers for controls
            with Vertical(classes="role-controls"), Horizontal(classes="control-row"):
                yield Static("Provider", classes="column-header provider-header")
                yield Static("Model", classes="column-header model-header")
                yield Static("Reasoning", classes="column-header reasoning-header")

    def _is_high_capability_action(self, role_id: str) -> bool:
        """Check if an action benefits from high-capability models."""
        return role_id in HIGH_CAPABILITY_ACTIONS

    def _compose_role_row(self, action: dict[str, str]) -> ComposeResult:
        """Compose a single role configuration row.

        Args:
            action: Action definition dict with id, name, description
        """
        role_id = action["id"]
        config = self._role_configs.get(role_id)

        # Get inherited values for display
        inherited_provider, inherited_model = self._get_inherited_config(config)
        effective_provider = config.provider if config and config.provider else inherited_provider

        # Check if this is a high-capability action
        is_critical = self._is_high_capability_action(role_id)
        description = action["description"]
        if is_critical:
            description = f"{description} ★"

        with Horizontal(classes="role-row", id=f"role-{role_id}"):
            # Left: Role info
            with Vertical(classes="role-info"):
                yield Static(action["name"], classes="role-name")
                yield Static(description, classes="role-description")

            # Right: Controls - Provider, Model, Reasoning
            with Vertical(classes="role-controls"), Horizontal(classes="control-row"):
                # Provider dropdown
                yield Select(
                    self._build_provider_options(
                        include_inherit=True,
                        inherited_provider=inherited_provider,
                    ),
                    id=f"provider-{role_id}",
                    value=config.provider if config and config.provider else "inherit",
                    allow_blank=False,
                    classes="provider-select",
                )

                # Model dropdown (filtered to effective provider)
                yield Select(
                    self._build_model_options(
                        effective_provider,
                        include_inherit=True,
                        inherited_model=inherited_model,
                        inherited_provider=inherited_provider,
                    ),
                    id=f"model-{role_id}",
                    value=config.model if config and config.model else "inherit",
                    allow_blank=False,
                    classes="model-select",
                )

                # Reasoning dropdown
                reasoning_disabled = not self._model_supports_thinking(
                    effective_provider, config.model if config else None
                )
                reasoning_value = "inherit"
                if config and config.reasoning_level:
                    reasoning_value = config.reasoning_level
                yield Select(
                    self._build_reasoning_options(),
                    id=f"reasoning-{role_id}",
                    value=reasoning_value,
                    allow_blank=False,
                    disabled=reasoning_disabled,
                    classes="reasoning-select",
                )

    def _build_provider_options(
        self,
        include_inherit: bool = False,
        inherited_provider: str | None = None,
    ) -> list[tuple[str, str]]:
        """Build provider options for Select widget.

        Args:
            include_inherit: Whether to include 'inherit' option
            inherited_provider: Provider ID to show as inherited value (will be resolved to display name)
        """
        options = []

        if include_inherit:
            if inherited_provider:
                # Resolve provider ID to display name
                provider_display = inherited_provider
                for provider_id, display_name, _desc in get_providers():
                    if provider_id == inherited_provider:
                        provider_display = display_name
                        break
                # Show resolved value - source is LLM Config (Menu 2)
                inherit_label = f"Inherit ({provider_display})"
            else:
                inherit_label = "Inherit"
            options.append((inherit_label, "inherit"))

        providers = get_providers()
        for provider_id, display_name, _description in providers:
            options.append((display_name, provider_id))
        return options

    def _get_inherited_config(self, config: RoleConfig | None) -> tuple[str, str]:
        """Get the provider and model that would be inherited from the profile.tier.

        Resolves the inheritance chain: action → profile.tier → actual model

        Args:
            config: Role configuration to get inherited values for

        Returns:
            Tuple of (provider, model_id) that would be inherited from profile.tier
        """
        if not config:
            return ("anthropic", "default")

        # Use profile tier configs (from Menu 2) if available
        if hasattr(self, "_profile_tier_configs") and self._profile_tier_configs:
            profile_cfg = self._profile_tier_configs.get(config.profile, {})
            provider = str(profile_cfg.get("provider", "anthropic"))
            tiers = profile_cfg.get("tiers", {})
            # Resolve the specific tier for this action
            if isinstance(tiers, dict):
                model = tiers.get(config.tier, "default")
            else:
                model = "default"

            # If model is "default", resolve to tier-specific model using role defaults
            if model == "default":
                role_defaults = get_role_tier_defaults(provider, config.profile)
                model = role_defaults.get(config.tier, "default")

            return (provider, str(model))

        # Fallback defaults
        return ("anthropic", "default")

    def _resolve_model_display(self, provider: str, model_id: str) -> str:
        """Resolve a model ID to its display name.

        Args:
            provider: Provider ID (anthropic, openai, etc.)
            model_id: Model ID to resolve (may be 'default' or specific model)

        Returns:
            Human-readable model name (e.g., "Claude Opus 4.5")
        """
        provider_config = MODEL_REGISTRY.get(provider)
        if not provider_config:
            return model_id

        # Handle 'default' by resolving to the provider's default model
        if model_id == "default":
            actual_id = provider_config.default_model or "auto"
            model_info = provider_config.models.get(actual_id)
            return model_info.display_name if model_info else actual_id

        model_info = provider_config.models.get(model_id)
        return model_info.display_name if model_info else model_id

    def _build_model_options(
        self,
        provider: str,
        include_inherit: bool = False,
        inherited_model: str | None = None,
        inherited_provider: str | None = None,
    ) -> list[tuple[str, str]]:
        """Build model options for a specific provider.

        Args:
            provider: Provider ID to get models for.
            include_inherit: Whether to include 'inherit' option.
            inherited_model: Model ID to show as inherited value (will be resolved to display name).
            inherited_provider: Provider for resolving the inherited model display name.

        Returns:
            List of (display_text, value) tuples for Select options.
        """
        options = []

        if include_inherit:
            # Resolve model ID to display name for the inherit label
            if inherited_model:
                resolve_provider = inherited_provider or provider
                display_name = self._resolve_model_display(resolve_provider, inherited_model)
                inherit_label = f"Inherit ({display_name})"
            else:
                inherit_label = "Inherit"
            options.append((inherit_label, "inherit"))

        all_models = get_models()
        models = all_models.get(provider, all_models.get("anthropic", []))

        for model_id, display, _tier in models:
            cost = get_model_cost(provider, model_id)
            # Recommended gets a star, others get cost indicator
            label = f"★  {display}" if model_id == "default" else f"{cost} {display}"
            options.append((label, model_id))
        return options

    def _build_reasoning_options(self) -> list[tuple[str, str]]:
        """Build reasoning level options with descriptions."""
        options = [("Inherit", "inherit")]
        for level in REASONING_LEVELS:
            # Keep labels concise but informative
            if level == "off":
                label = "Off"
            else:
                label = level.capitalize()
            options.append((label, level))
        return options

    def _model_supports_thinking(self, provider: str, model: str | None) -> bool:
        """Check if a model supports extended thinking."""
        if model is None or model == "inherit":
            # For inherited models, assume thinking is supported
            # (will be checked again at runtime)
            return True
        return supports_thinking(provider, model)

    def on_select_changed(self, event: Select.Changed) -> None:
        """Handle select widget changes."""
        # Skip processing during initial mount to prevent spurious state changes
        if self._initializing:
            return

        select_id = event.select.id
        if not select_id:
            return

        if select_id.startswith("provider-"):
            role_id = select_id.replace("provider-", "")
            self._handle_role_provider_change(role_id, str(event.value))
        elif select_id.startswith("model-"):
            role_id = select_id.replace("model-", "")
            self._handle_model_change(role_id, str(event.value))
        elif select_id.startswith("reasoning-"):
            role_id = select_id.replace("reasoning-", "")
            self._handle_reasoning_change(role_id, str(event.value))

    def _handle_role_provider_change(self, role_id: str, new_provider: str) -> None:
        """Handle provider selection change for a specific role."""
        if role_id not in self._role_configs:
            return

        config = self._role_configs[role_id]
        config.provider = None if new_provider == "inherit" else new_provider

        # Get effective provider for model dropdown
        inherited_provider, inherited_model = self._get_inherited_config(config)
        effective_provider = config.provider if config.provider else inherited_provider

        # Update model dropdown for this role with new provider's models
        try:
            model_select = self.query_one(f"#model-{role_id}", Select)
            new_options = self._build_model_options(
                effective_provider,
                include_inherit=True,
                inherited_model=inherited_model if not config.provider else None,
                inherited_provider=inherited_provider if not config.provider else None,
            )
            model_select.set_options(new_options)

            # Reset model to inherit if current model isn't valid for new provider
            if config.model and config.model != "inherit":
                valid_model_ids = [opt[1] for opt in new_options]
                if config.model not in valid_model_ids:
                    config.model = None
                    model_select.value = "inherit"
        except Exception:
            pass

        # Update reasoning disabled state
        self._update_reasoning_disabled(role_id)

        self._emit_change()

    def _handle_model_change(self, role_id: str, new_model: str) -> None:
        """Handle model selection change for a role."""
        if role_id not in self._role_configs:
            return

        config = self._role_configs[role_id]
        config.model = None if new_model == "inherit" else new_model

        # Update reasoning selector disabled state
        self._update_reasoning_disabled(role_id)

        self._emit_change()

    def _handle_reasoning_change(self, role_id: str, new_level: str) -> None:
        """Handle reasoning level change for a role."""
        if role_id not in self._role_configs:
            return

        config = self._role_configs[role_id]
        config.reasoning_level = None if new_level == "inherit" else new_level
        self._emit_change()

    def _update_reasoning_disabled(self, role_id: str) -> None:
        """Update reasoning selector disabled state based on model."""
        try:
            config = self._role_configs[role_id]
            reasoning_select = self.query_one(f"#reasoning-{role_id}", Select)

            # Get effective provider
            inherited_provider, _ = self._get_inherited_config(config)
            effective_provider = config.provider if config.provider else inherited_provider

            supports = self._model_supports_thinking(effective_provider, config.model)
            reasoning_select.disabled = not supports
        except Exception:
            pass

    def _emit_change(self) -> None:
        """Emit the Changed message with current configuration.

        Skips emission during initial mount to prevent spurious changes.
        """
        if self._initializing:
            return
        self.post_message(self.Changed(self._role_configs.copy()))

    def action_reset_section(self) -> None:
        """Reset the currently focused section to defaults."""
        # Find which collapsible is focused or contains focus
        for phase_id in PHASE_LABELS:
            try:
                from textual.widget import Widget

                collapsible = self.query_one(f"#phase-{phase_id}", Collapsible)
                if collapsible.has_focus or any(
                    child.has_focus
                    for child in collapsible.walk_children()
                    if isinstance(child, Widget)
                ):
                    self._reset_phase(phase_id)
                    self.notify(f"Reset {PHASE_LABELS[phase_id]} to defaults")
                    return
            except Exception:
                pass

        self.notify("Focus a section to reset it", severity="warning")

    def _reset_phase(self, phase_id: str) -> None:
        """Reset all roles in a phase to their defaults."""
        for action in PHASE_ACTIONS[phase_id]:
            role_id = action["id"]
            if role_id in self._role_configs:
                config = self._role_configs[role_id]
                config.provider = None  # Reset to inherit
                config.model = None  # Reset to inherit
                config.reasoning_level = None  # Reset to inherit

                # Update UI - reset all selects to inherit
                try:
                    provider_select = self.query_one(f"#provider-{role_id}", Select)
                    inherited_provider, inherited_model = self._get_inherited_config(config)
                    provider_select.set_options(
                        self._build_provider_options(
                            include_inherit=True, inherited_provider=inherited_provider
                        )
                    )
                    provider_select.value = "inherit"
                except Exception:
                    pass

                try:
                    model_select = self.query_one(f"#model-{role_id}", Select)
                    inherited_provider, inherited_model = self._get_inherited_config(config)
                    model_select.set_options(
                        self._build_model_options(
                            inherited_provider,
                            include_inherit=True,
                            inherited_model=inherited_model,
                            inherited_provider=inherited_provider,
                        )
                    )
                    model_select.value = "inherit"
                except Exception:
                    pass

                try:
                    reasoning_select = self.query_one(f"#reasoning-{role_id}", Select)
                    reasoning_select.value = "inherit"
                except Exception:
                    pass

        self._emit_change()

    def get_config_changes(self) -> dict[str, Any]:
        """Get config changes to apply.

        Returns:
            Dict mapping config paths to values. Each role is stored as a dict
            with profile, tier, and any explicit overrides.
        """
        changes: dict[str, Any] = {}
        for role_id, config in self._role_configs.items():
            # Build the role config dict
            role_value: dict[str, str] = {
                "profile": config.profile,
                "tier": config.tier,
            }

            # Add explicit overrides if present
            if config.provider:
                role_value["provider"] = config.provider
            if config.model:
                role_value["model"] = config.model
            if config.reasoning_level:
                role_value["reasoning_level"] = config.reasoning_level

            changes[f"llm.roles.{role_id}"] = role_value

        return changes

    def update_tier_configs(
        self,
        orchestrator_provider: str | None = None,
        orchestrator_tiers: dict[str, str] | None = None,
        implementation_provider: str | None = None,
        implementation_tiers: dict[str, str] | None = None,
    ) -> None:
        """Update tier configs from Menu 1 or Menu 2 cascade.

        Called when Menu 1 (Simple) or Menu 2 (Moderate) changes to propagate
        new tier settings down to Menu 3. Updates the inherited values shown
        in "Inherit (model)" labels.

        Args:
            orchestrator_provider: New orchestrator provider (or None to keep current)
            orchestrator_tiers: New orchestrator tier models {fast, medium, high}
            implementation_provider: New implementation provider (or None to keep current)
            implementation_tiers: New implementation tier models {fast, medium, high}
        """
        # Update stored tier configs
        if orchestrator_provider is not None:
            self._profile_tier_configs["orchestrator"]["provider"] = orchestrator_provider
        if orchestrator_tiers is not None:
            self._profile_tier_configs["orchestrator"]["tiers"] = orchestrator_tiers
        if implementation_provider is not None:
            self._profile_tier_configs["implementation"]["provider"] = implementation_provider
        if implementation_tiers is not None:
            self._profile_tier_configs["implementation"]["tiers"] = implementation_tiers

        # Refresh all "Inherit" labels to show new resolved models
        self._refresh_inherit_labels()

    def _refresh_inherit_labels(self) -> None:
        """Refresh all dropdown "Inherit" labels to reflect current tier configs.

        Called after tier configs change (cascade from Menu 1/2) to update
        the displayed inherited model names.
        """
        for role_id, config in self._role_configs.items():
            inherited_provider, inherited_model = self._get_inherited_config(config)

            # Update provider dropdown inherit label
            try:
                provider_select = self.query_one(f"#provider-{role_id}", Select)
                current_value = provider_select.value
                provider_select.set_options(
                    self._build_provider_options(
                        include_inherit=True, inherited_provider=inherited_provider
                    )
                )
                provider_select.value = current_value
            except Exception:
                pass

            # Update model dropdown inherit label
            try:
                model_select = self.query_one(f"#model-{role_id}", Select)
                current_value = model_select.value
                effective_provider = config.provider if config.provider else inherited_provider
                model_select.set_options(
                    self._build_model_options(
                        effective_provider,
                        include_inherit=True,
                        inherited_model=inherited_model,
                        inherited_provider=inherited_provider,
                    )
                )
                model_select.value = current_value
            except Exception:
                pass

    # --- SaveableViewMixin implementation ---

    def _get_saveable_state(self) -> dict[str, Any]:
        """Get current state for dirty tracking.

        Returns config paths mapped to current values (role configs as dicts).
        """
        state: dict[str, Any] = {}
        for role_id, config in self._role_configs.items():
            role_value: dict[str, Any] = {
                "profile": config.profile,
                "tier": config.tier,
            }
            if config.provider:
                role_value["provider"] = config.provider
            if config.model:
                role_value["model"] = config.model
            if config.reasoning_level:
                role_value["reasoning_level"] = config.reasoning_level
            state[f"llm.roles.{role_id}"] = role_value
        return state

    def _restore_state(self, state: dict[str, Any]) -> None:
        """Restore state from snapshot and update UI."""
        for path, value in state.items():
            if not path.startswith("llm.roles."):
                continue
            role_id = path.replace("llm.roles.", "")
            if role_id in self._role_configs and isinstance(value, dict):
                config = self._role_configs[role_id]
                config.profile = value.get("profile", config.profile)
                config.tier = value.get("tier", config.tier)
                config.provider = value.get("provider")
                config.model = value.get("model")
                config.reasoning_level = value.get("reasoning_level")

        # Refresh all dropdowns
        self._refresh_inherit_labels()
