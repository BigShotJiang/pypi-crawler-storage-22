"""Preset Picker modal for configuration presets (Personas).

Provides a modal dialog for selecting configuration personas with
comparison view showing what each persona includes.

Personas use tier references (fast/medium/high) instead of hardcoded model names.
At apply time, tiers are resolved to provider-appropriate models via
get_provider_tier_defaults().
"""

import contextlib
from dataclasses import dataclass
from typing import Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical
from textual.message import Message
from textual.screen import ModalScreen
from textual.widgets import Button, Label, OptionList, Static
from textual.widgets.option_list import Option

from obra.config.explorer.widgets.navigation_menu import get_menu_info

# Persona definitions with user profiles for self-identification.
#
# Each persona includes:
#   - name: Display name
#   - user_profile: Who this persona is for (helps users self-identify)
#   - description: What this persona does
#   - warning: Optional prominent warning (for risky personas like Autonomous)
#   - features: Config feature toggles
#   - llm_profiles: Base provider/model for orchestrator and implementation
#   - llm_tiers: Specific tier overrides for individual roles
#
# Order matters: Recommended first, then by increasing risk/specialization.
PERSONAS: dict[str, dict[str, Any]] = {
    "recommended": {
        "name": "Recommended",
        "user_profile": "Most users, production work",
        "description": "Guided mode: Story 0 asks before installs/scaffolding",
        "details": {
            "story0_behavior": "Prompts before environment setup",
            "install_behavior": "Asks before installing packages",
            "env_creation": "Creates virtual env only when missing",
        },
        "setup_tips": [
            "Add requirements.txt or pyproject.toml for Python dependencies",
            "Add package.json for Node.js dependencies",
            "Configure linters/formatters in Menu 6 (Validation & Tooling)",
            "Story 0 will prompt you to approve detected dependencies",
        ],
        "features": {
            # Checkpoints enabled for safety
            "automation_mode": "guided",
        },
        # No llm_profiles - uses whatever LLM settings user has configured
        # LLM selection is handled by Menu 1/2/3, not personas
        "llm_profiles": {},
        "llm_tiers": {},
    },
    "genie": {
        "name": "Autonomous (Genie)",
        "user_profile": "Power users, CI/CD pipelines",
        "description": "Ideal but Dangerous - full auto, no confirmations",
        "warning": {
            "headline": "IDEAL BUT DANGEROUS - REDUCED SAFETY RAILS",
            "enables": [
                "Story 0 auto-approves all package installs",
                "Environment setup without confirmation",
                "Virtual environment auto-creation",
            ],
            "risks": [
                "Unwanted packages may be installed automatically",
                "Project structure changes without review",
            ],
            "recommended_for": [
                "Trusted, isolated environments",
                "CI/CD pipelines with rollback capability",
                "Experienced users who review changes after",
            ],
        },
        "features": {
            "automation_mode": "auto_full",
        },
        # No llm_profiles - uses whatever LLM settings user has configured
        # LLM selection is handled by Menu 1/2/3, not personas
        "llm_profiles": {},
        "llm_tiers": {},
    },
    "quick_start": {
        "name": "Quick Start",
        "user_profile": "New to Obra, simple tasks",
        "description": "Fast + cheap models, skip pre-planning",
        "details": {
            "model_tier": "Uses fast-tier models (Haiku for Anthropic)",
            "pre_planning": "Skips intent enrichment stages",
            "review_workers": "Reduced to 2 parallel workers",
        },
        "features": {
            "planning.enrichment.enabled": False,
            "review.agents.max_workers": 2,
        },
        # Set LLM profiles to use fast-tier models
        # Uses "tier:fast" syntax - resolved to actual model at apply time
        # No provider specified = keeps user's current provider
        "llm_profiles": {
            "orchestrator": {"model": "tier:fast"},
            "implementation": {"model": "tier:fast"},
        },
        "llm_tiers": {},
    },
    "local_only": {
        "name": "Local Only",
        "user_profile": "Privacy / offline environments",
        "description": "Ollama only, no cloud API calls",
        "details": {
            "provider": "Switches to Ollama (local inference)",
            "privacy": "No data sent to cloud APIs",
            "requirement": "Ollama must be installed and running",
        },
        "features": {},
        # Local Only DOES set LLM - switches to Ollama provider
        "llm_profiles": {
            "orchestrator": {"provider": "ollama", "model": "default"},
            "implementation": {"provider": "ollama", "model": "default"},
        },
        "llm_tiers": {},
    },
}

# Backward compatibility alias
PRESETS = PERSONAS


def resolve_persona_models(persona_id: str, provider: str) -> dict[str, str]:
    """Resolve tier references to actual model names for current provider.

    Handles edge cases:
    - Unknown provider: returns empty dict (persona features still apply)
    - Missing tier: falls back to 'medium', then first available tier

    Args:
        persona_id: Persona identifier (fast, balanced, thorough, cost_optimized)
        provider: Provider name (anthropic, openai, google, ollama)

    Returns:
        Dict mapping role names to actual model IDs for the provider.

    Example:
        >>> resolve_persona_models("fast", "anthropic")
        {'derive': 'claude-haiku-4-5', 'execute': 'claude-haiku-4-5', 'review': 'claude-sonnet-4-5'}
    """
    from obra.config.llm import get_provider_tier_defaults

    all_tier_defaults = get_provider_tier_defaults()
    tier_defaults = all_tier_defaults.get(provider, {})
    if not tier_defaults:
        # Unknown provider - can't resolve tiers, but persona features still apply
        return {}

    persona = PERSONAS.get(persona_id, {})
    result: dict[str, str] = {}

    for role, tier in persona.get("llm_tiers", {}).items():
        # Defensive: try requested tier, then medium, then first available
        model = (
            tier_defaults.get(tier)
            or tier_defaults.get("medium")
            or next(iter(tier_defaults.values()), None)
        )
        if model:
            result[role] = model

    return result


def get_persona_changes_preview(persona_id: str, provider: str) -> list[str]:
    """Get a preview of what changes a persona will make.

    Args:
        persona_id: Persona identifier
        provider: Current provider for tier resolution

    Returns:
        List of human-readable change descriptions.
    """
    persona = PERSONAS.get(persona_id, {})
    changes = []

    # Feature changes
    for feature_path, value in persona.get("features", {}).items():
        value_str = "enabled" if value else "disabled"
        if isinstance(value, int):
            value_str = str(value)
        changes.append(f"{feature_path}: {value_str}")

    # LLM tier changes (resolved to model names)
    resolved_models = resolve_persona_models(persona_id, provider)
    for role, model in resolved_models.items():
        changes.append(f"{role} model: {model}")

    return changes


def detect_active_persona(
    current_features: dict[str, Any],
    current_roles: dict[str, str],
    provider: str,
) -> str:
    """Detect which persona matches the current configuration.

    Compares current config values against all persona definitions to find
    the best match.

    Args:
        current_features: Current feature settings (e.g., planning.scaffolded.enabled)
        current_roles: Current role model assignments (e.g., {derive: 'opus'})
        provider: Current provider for tier resolution

    Returns:
        Persona name if matched, 'Custom' if no match.
    """
    for persona_id, persona in PERSONAS.items():
        # Check if all features match
        features_match = True
        for feature_path, expected_value in persona.get("features", {}).items():
            actual_value = current_features.get(feature_path)
            if actual_value != expected_value:
                features_match = False
                break

        if not features_match:
            continue

        # Check if LLM tiers match
        llm_tiers = persona.get("llm_tiers", {})
        if not llm_tiers:
            # Balanced persona has no tier requirements - matches if features match
            return persona.get("name", persona_id)

        resolved_models = resolve_persona_models(persona_id, provider)
        roles_match = True
        for role, expected_model in resolved_models.items():
            actual_model = current_roles.get(role)
            # Allow match if actual is None (inherited) or matches exactly
            if actual_model is not None and actual_model != expected_model:
                roles_match = False
                break

        if features_match and roles_match:
            return persona.get("name", persona_id)

    return "Custom"


@dataclass
class PresetSelection:
    """Result of persona picker selection."""

    preset_id: str
    preset_name: str
    features: dict[str, Any]
    llm_models: dict[str, str]  # Resolved role -> model mappings
    llm_profiles: dict[str, dict[str, str]] | None = (
        None  # {orchestrator/implementation: {provider, model}}
    )


class PresetPicker(ModalScreen[PresetSelection | None]):
    """Modal dialog for selecting configuration personas.

    Shows available personas with descriptions and a comparison view
    of what features and LLM tiers each persona configures.
    """

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
        Binding("enter", "apply", "Apply", priority=True),
        Binding("tab", "compare", "Compare", show=False),
    ]

    DEFAULT_CSS = """
    PresetPicker {
        align: center middle;
    }

    PresetPicker > Container {
        width: 80;
        height: auto;
        max-height: 40;
        background: $surface;
        border: thick $accent;
        padding: 1 2;
    }

    PresetPicker #title {
        text-style: bold;
        width: 100%;
        text-align: center;
        margin-bottom: 1;
    }

    PresetPicker #description {
        color: $text-muted;
        margin-bottom: 1;
    }

    PresetPicker OptionList {
        height: auto;
        max-height: 10;
        margin-bottom: 1;
    }

    PresetPicker .buttons {
        height: 3;
        align: center middle;
    }

    PresetPicker Button {
        margin: 0 1;
    }

    PresetPicker #comparison {
        background: $surface-darken-1;
        padding: 1;
        margin-bottom: 1;
        height: auto;
        max-height: 18;
    }

    PresetPicker #comparison-title {
        text-style: bold;
        margin-bottom: 1;
    }

    PresetPicker .feature-enabled {
        color: $success;
    }

    PresetPicker .feature-disabled {
        color: $text-muted;
    }

    PresetPicker .llm-tier {
        color: $primary;
    }

    PresetPicker .warning-text {
        color: $warning;
    }
    """

    def __init__(
        self,
        current_preset: str = "recommended",
        current_provider: str = "anthropic",
    ) -> None:
        """Initialize the persona picker.

        Args:
            current_preset: Currently active persona ID
            current_provider: Current LLM provider for tier resolution
        """
        super().__init__()
        self._current_preset = current_preset
        self._current_provider = current_provider
        self._selected_preset: str | None = None

    def compose(self) -> ComposeResult:
        """Create the modal content."""
        with Container():
            yield Label("Select Configuration Persona", id="title")
            yield Static(
                "Pick the one that sounds like you:",
                id="description",
            )

            yield OptionList(id="presets")

            # Comparison panel - shows what persona will change
            with Vertical(id="comparison"):
                yield Static("This persona will set:", id="comparison-title")
                yield Static("", id="comparison-content")

            with Horizontal(classes="buttons"):
                yield Button("Cancel", variant="default", id="cancel")
                yield Button("Apply", variant="primary", id="apply")

    def on_mount(self) -> None:
        """Initialize the persona list with user profiles.

        Uses multiple visual cues for the active indicator:
        - Bullet on LEFT: ● for active, ○ for inactive (first thing eye hits)
        - Bold white text for visibility on both dark bg and teal highlight
        - "← ACTIVE" on RIGHT: explicit text backup for accessibility
        """
        option_list = self.query_one("#presets", OptionList)

        for persona_id, persona_info in PERSONAS.items():
            is_current = persona_id == self._current_preset
            name = persona_info["name"]
            user_profile = persona_info.get("user_profile", "")
            description = persona_info["description"]

            if is_current:
                # Bold white bullet and ACTIVE label - visible on dark bg AND teal highlight
                label = (
                    f"[bold white]●[/bold white] [bold]{name}[/bold] "
                    f"For: {user_profile}  [bold white]← ACTIVE[/bold white]\n"
                    f"    {description}"
                )
            else:
                # Dim bullet, normal weight
                label = f"[dim]○[/dim] {name}  For: {user_profile}\n    {description}"
            option_list.add_option(Option(label, id=persona_id))

        option_list.focus()
        option_list.highlighted = 0
        self._update_comparison(next(iter(PERSONAS.keys())))

    def on_option_list_option_highlighted(self, event: OptionList.OptionHighlighted) -> None:
        """Update comparison when selection changes."""
        if event.option and event.option.id:
            self._update_comparison(str(event.option.id))

    def _format_feature_line(self, feature: str, value: Any) -> str:
        """Format a feature setting for display."""
        icon = "+" if value is True else "-" if value is False else "="
        status = "enabled" if value is True else "disabled" if value is False else str(value)
        feature_name = feature.replace(".", " > ").replace("_", " ").title()
        return f"  {icon} {feature_name}: {status}"

    def _format_warning(self, warning: dict[str, Any]) -> list[str]:
        """Format a prominent warning block for risky personas."""
        lines: list[str] = []

        # Headline in warning color
        headline = warning.get("headline", "WARNING")
        lines.append(f"[bold yellow]⚠️  {headline}[/bold yellow]")
        lines.append("")

        # What this enables
        enables = warning.get("enables", [])
        if enables:
            lines.append("[bold]What this enables:[/bold]")
            lines.extend(f"  • {item}" for item in enables)
            lines.append("")

        # Risks
        risks = warning.get("risks", [])
        if risks:
            lines.append("[bold yellow]Risks you accept:[/bold yellow]")
            lines.extend(f"  • {item}" for item in risks)
            lines.append("")

        # Recommended for
        recommended = warning.get("recommended_for", [])
        if recommended:
            lines.append("[bold]Recommended only for:[/bold]")
            lines.extend(f"  • {item}" for item in recommended)

        return lines

    def _update_comparison(self, persona_id: str) -> None:
        """Update the comparison panel for a persona."""
        self._selected_preset = persona_id
        persona = PERSONAS.get(persona_id, {})
        lines: list[str] = []

        # Show warning first if present (prominent for Autonomous)
        warning = persona.get("warning")
        if warning:
            lines.extend(self._format_warning(warning))

        # Show details if present (human-readable explanation)
        details = persona.get("details", {})
        if details:
            if lines:
                lines.append("")
            lines.append("[bold]What this means:[/bold]")
            for key, value in details.items():
                label = key.replace("_", " ").title()
                lines.append(f"  • {label}: {value}")

        # Show setup tips if present
        setup_tips = persona.get("setup_tips", [])
        if setup_tips:
            lines.append("")
            lines.append("[bold]Setup tips:[/bold]")
            for tip in setup_tips:
                lines.append(f"  • {tip}")

        # LLM configuration section
        llm_profiles = persona.get("llm_profiles", {})
        if llm_profiles:
            if lines:
                lines.append("")
            lines.append("[bold]LLM Configuration:[/bold]")
            for profile in ("orchestrator", "implementation"):
                cfg = llm_profiles.get(profile, {})
                if cfg:
                    label = "Planning Model" if profile == "orchestrator" else "Coding Model"
                    lines.append(
                        f"  {label}: {cfg.get('provider', 'anthropic')}/{cfg.get('model', 'default')}"
                    )
        else:
            # Persona does NOT change LLM settings
            if lines:
                lines.append("")
            lines.append("[bold]LLM Configuration:[/bold]")
            lines.append("  [dim]Unchanged - use Menu 1-3 to configure models[/dim]")

        # Feature changes (raw config - for technical users)
        features = persona.get("features", {})
        if features:
            lines.append("")
            lines.append("[bold]Config Changes:[/bold]")
            lines.extend(self._format_feature_line(f, v) for f, v in features.items())

        # LLM tier overrides
        llm_tiers = persona.get("llm_tiers", {})
        if llm_tiers:
            lines.append("")
            lines.append("[bold]Model Tiers:[/bold]")
            lines.extend(f"  {role}: {tier}" for role, tier in llm_tiers.items())

        content = self.query_one("#comparison-content", Static)
        if not lines:
            content.update("[dim]Uses safe defaults - recommended for most users[/dim]")
        else:
            content.update("\n".join(lines))

    def action_cancel(self) -> None:
        """Cancel and close modal."""
        self.dismiss(None)

    def action_apply(self) -> None:
        """Apply selected persona and close modal."""
        if self._selected_preset:
            persona = PERSONAS.get(self._selected_preset, {})
            # Resolve tier references to actual model names for current provider
            resolved_models = resolve_persona_models(self._selected_preset, self._current_provider)
            self.dismiss(
                PresetSelection(
                    preset_id=self._selected_preset,
                    preset_name=persona.get("name", self._selected_preset),
                    features=persona.get("features", {}),
                    llm_models=resolved_models,
                    llm_profiles=persona.get("llm_profiles"),
                )
            )

    def action_compare(self) -> None:
        """Toggle comparison view (placeholder for future side-by-side)."""
        # Future enhancement: show side-by-side comparison of all personas

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button clicks."""
        if event.button.id == "cancel":
            self.action_cancel()
        elif event.button.id == "apply":
            self.action_apply()

    def on_option_list_option_selected(self, _event: OptionList.OptionSelected) -> None:
        """Handle option double-click/enter."""
        self.action_apply()

    class PresetChanged(Message):
        """Message posted when preset is changed."""

        def __init__(self, selection: PresetSelection) -> None:
            super().__init__()
            self.selection = selection


class PersonaView(Static):
    """Full-screen persona configuration view.

    Provides a full-screen interface for selecting configuration personas,
    following the same top-to-bottom layout as SimpleLLMView:
    - Top: Persona selection list
    - Bottom: Live preview of what the persona configures

    Emits:
        Changed: When a persona is selected and applied.
    """

    DEFAULT_CSS = """
    PersonaView {
        width: 100%;
        height: 100%;
        padding: 1 2;
    }

    PersonaView > Vertical {
        width: 100%;
        height: 100%;
        align: center top;
    }

    PersonaView .header {
        text-style: bold;
        text-align: center;
        margin-bottom: 1;
        width: 100%;
    }

    PersonaView .description {
        color: $text-muted;
        text-align: center;
        margin-bottom: 2;
        width: 100%;
    }

    PersonaView #persona-list {
        width: 100%;
        height: auto;
        max-height: 12;
        margin-bottom: 1;
    }

    PersonaView .preview-box {
        width: 100%;
        height: auto;
        min-height: 8;
        background: $surface-darken-1;
        padding: 1 2;
        margin-top: 1;
    }

    PersonaView .preview-title {
        text-style: bold;
        margin-bottom: 1;
    }

    PersonaView .preview-content {
        color: $text;
    }

    PersonaView .warning-headline {
        color: $warning;
        text-style: bold;
    }

    PersonaView .warning-section {
        margin-top: 1;
    }

    PersonaView .hint {
        color: $text-muted;
        text-align: center;
        margin-top: 1;
    }

    PersonaView .button-row {
        width: 100%;
        height: auto;
        align: center middle;
        margin-top: 1;
    }

    PersonaView #apply-btn {
        min-width: 20;
    }
    """

    class Changed(Message):
        """Message sent when persona selection changes."""

        def __init__(self, selection: PresetSelection) -> None:
            super().__init__()
            self.selection = selection

    def __init__(
        self,
        current_persona: str = "recommended",
        current_provider: str = "anthropic",
        **kwargs: Any,
    ) -> None:
        """Initialize the persona view.

        Args:
            current_persona: Currently active persona ID
            current_provider: Current LLM provider for tier resolution
        """
        super().__init__(**kwargs)
        self._current_persona = current_persona
        self._current_provider = current_provider
        self._selected_persona: str = current_persona

    def compose(self) -> ComposeResult:
        """Create the view content."""
        menu_info = get_menu_info("personas")
        with Vertical():
            yield Static(menu_info["label"], classes="header")
            yield Static(menu_info["subtitle"], classes="description")

            yield OptionList(id="persona-list")

            # Preview panel (like SimpleLLMView)
            with Vertical(classes="preview-box"):
                yield Static("This persona will set:", classes="preview-title")
                yield Static("", id="preview-content", classes="preview-content")

            # Apply button - explicit action required
            with Horizontal(classes="button-row"):
                yield Button("Apply Persona", variant="primary", id="apply-btn")

            yield Static(
                "Navigate with arrow keys, review changes above, then click Apply.",
                classes="hint",
            )

    def on_mount(self) -> None:
        """Initialize the persona list."""
        option_list = self.query_one("#persona-list", OptionList)

        for persona_id, persona_info in PERSONAS.items():
            is_current = persona_id == self._current_persona
            name = persona_info["name"]
            user_profile = persona_info.get("user_profile", "")
            description = persona_info["description"]

            if is_current:
                # Bold white bullet and ACTIVE label for visibility
                label = (
                    f"[bold white]●[/bold white] [bold]{name}[/bold]  "
                    f"For: {user_profile}  [bold white]← ACTIVE[/bold white]\n"
                    f"    {description}"
                )
            else:
                # Dim bullet for inactive
                label = f"[dim]○[/dim] {name}  For: {user_profile}\n    {description}"

            option_list.add_option(Option(label, id=persona_id))

        # Set initial highlight to current persona
        for idx, persona_id in enumerate(PERSONAS.keys()):
            if persona_id == self._current_persona:
                option_list.highlighted = idx
                break

        option_list.focus()
        self._update_preview(self._current_persona)

    def on_option_list_option_highlighted(self, event: OptionList.OptionHighlighted) -> None:
        """Update preview when selection changes."""
        if event.option and event.option.id:
            self._selected_persona = str(event.option.id)
            self._update_preview(self._selected_persona)

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        """Handle Enter on option list - focus the Apply button.

        We don't auto-apply on selection so users can review the preview first.
        """
        # Just ensure the selection is updated, don't apply yet
        if event.option and event.option.id:
            self._selected_persona = str(event.option.id)
            self._update_preview(self._selected_persona)
        # Focus the Apply button so user can press Enter again to apply
        with contextlib.suppress(Exception):
            self.query_one("#apply-btn", Button).focus()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle Apply button click."""
        if event.button.id == "apply-btn":
            self._apply_persona(self._selected_persona)

    def _update_preview(self, persona_id: str) -> None:
        """Update the preview panel for the highlighted persona."""
        persona = PERSONAS.get(persona_id, {})
        lines: list[str] = []

        # Show warning first if present (for Autonomous/Genie)
        warning = persona.get("warning")
        if warning:
            lines.extend(self._format_warning(warning))

        # Show details if present (human-readable explanation)
        details = persona.get("details", {})
        if details:
            if lines:
                lines.append("")
            lines.append("[bold]What this means:[/bold]")
            for key, value in details.items():
                # Convert key from snake_case to readable label
                label = key.replace("_", " ").title()
                lines.append(f"  • {label}: {value}")

        # Show setup tips if present (for guided modes that need user prep)
        setup_tips = persona.get("setup_tips", [])
        if setup_tips:
            lines.append("")
            lines.append("[bold]Setup tips:[/bold]")
            for tip in setup_tips:
                lines.append(f"  • {tip}")

        # LLM configuration section
        llm_profiles = persona.get("llm_profiles", {})
        if llm_profiles:
            # Persona changes LLM settings
            if lines:
                lines.append("")
            lines.append("[bold]LLM Configuration:[/bold]")
            for profile in ("orchestrator", "implementation"):
                cfg = llm_profiles.get(profile, {})
                if cfg:
                    label = "Planning Model" if profile == "orchestrator" else "Coding Model"
                    lines.append(
                        f"  {label}: {cfg.get('provider', 'anthropic')}/"
                        f"{cfg.get('model', 'default')}"
                    )
        else:
            # Persona does NOT change LLM settings
            if lines:
                lines.append("")
            lines.append("[bold]LLM Configuration:[/bold]")
            lines.append("  [dim]Unchanged - use Menu 1-3 to configure models[/dim]")

        # Feature changes (raw config keys - show after details for technical users)
        features = persona.get("features", {})
        if features:
            lines.append("")
            lines.append("[bold]Config Changes:[/bold]")
            for feature, value in features.items():
                icon = "+" if value is True else "-" if value is False else "="
                status = (
                    "enabled" if value is True else "disabled" if value is False else str(value)
                )
                lines.append(f"  {icon} {feature}: {status}")

        # LLM tier overrides
        llm_tiers = persona.get("llm_tiers", {})
        if llm_tiers:
            lines.append("")
            lines.append("[bold]Model Tiers:[/bold]")
            for role, tier in llm_tiers.items():
                lines.append(f"  {role}: {tier}")

        content = self.query_one("#preview-content", Static)
        if not lines:
            content.update("[dim]Uses safe defaults - recommended for most users[/dim]")
        else:
            content.update("\n".join(lines))

    def _format_warning(self, warning: dict[str, Any]) -> list[str]:
        """Format a prominent warning block for risky personas."""
        lines: list[str] = []

        headline = warning.get("headline", "WARNING")
        lines.append(f"[bold yellow]⚠️  {headline}[/bold yellow]")
        lines.append("")

        enables = warning.get("enables", [])
        if enables:
            lines.append("[bold]What this enables:[/bold]")
            lines.extend(f"  • {item}" for item in enables)
            lines.append("")

        risks = warning.get("risks", [])
        if risks:
            lines.append("[bold yellow]Risks you accept:[/bold yellow]")
            lines.extend(f"  • {item}" for item in risks)
            lines.append("")

        recommended = warning.get("recommended_for", [])
        if recommended:
            lines.append("[bold]Recommended only for:[/bold]")
            lines.extend(f"  • {item}" for item in recommended)

        return lines

    def _apply_persona(self, persona_id: str) -> None:
        """Apply the selected persona and emit Changed message."""
        persona = PERSONAS.get(persona_id, {})
        resolved_models = resolve_persona_models(persona_id, self._current_provider)

        selection = PresetSelection(
            preset_id=persona_id,
            preset_name=persona.get("name", persona_id),
            features=persona.get("features", {}),
            llm_models=resolved_models,
            llm_profiles=persona.get("llm_profiles"),
        )

        self.post_message(self.Changed(selection))

    def set_current_persona(self, persona_id: str) -> None:
        """Update the current persona and refresh the list.

        Called after a persona is applied to update the visual state.
        """
        self._current_persona = persona_id
        self._selected_persona = persona_id
        # Refresh the option list to show new ACTIVE state
        self._refresh_persona_list()

    def _refresh_persona_list(self) -> None:
        """Refresh the persona list to reflect current state."""
        option_list = self.query_one("#persona-list", OptionList)
        option_list.clear_options()

        for persona_id, persona_info in PERSONAS.items():
            is_current = persona_id == self._current_persona
            name = persona_info["name"]
            user_profile = persona_info.get("user_profile", "")
            description = persona_info["description"]

            if is_current:
                label = (
                    f"[bold white]●[/bold white] [bold]{name}[/bold]  "
                    f"For: {user_profile}  [bold white]← ACTIVE[/bold white]\n"
                    f"    {description}"
                )
            else:
                label = f"[dim]○[/dim] {name}  For: {user_profile}\n    {description}"

            option_list.add_option(Option(label, id=persona_id))

        # Re-highlight current persona
        for idx, pid in enumerate(PERSONAS.keys()):
            if pid == self._current_persona:
                option_list.highlighted = idx
                break
