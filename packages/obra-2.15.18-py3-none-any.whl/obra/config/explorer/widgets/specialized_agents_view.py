"""Specialized Agents View widget.

Provides an interface for enabling/disabling review agents
that provide specialized analysis during Obra sessions.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from textual.app import ComposeResult
from textual.containers import Horizontal, ScrollableContainer, Vertical
from textual.message import Message
from textual.widgets import Static, Switch

from obra.config.explorer.widgets.navigation_menu import get_menu_info
from obra.config.explorer.widgets.saveable_view import SaveableViewMixin


@dataclass
class AgentInfo:
    """Metadata for a specialized agent."""

    id: str
    name: str
    description: str
    trigger: str
    config_path: str


# Agent definitions with canonical config paths.
# IMPORTANT: Use canonical paths (features.quality_automation.agents.*)
# NOT shortcut paths (agents.*) which are semantic overlays.
AGENTS: list[AgentInfo] = [
    AgentInfo(
        id="rca_agent",
        name="RCA Agent",
        description="Root cause analysis for bugs and issues",
        trigger="Activated on bug/issue keywords in objective",
        config_path="features.quality_automation.agents.rca_agent",
    ),
    AgentInfo(
        id="code_review",
        name="Code Review Agent",
        description="Architecture and quality review",
        trigger="Runs during review phase on modified files",
        config_path="features.quality_automation.agents.code_review",
    ),
    AgentInfo(
        id="security_audit",
        name="Security Audit Agent",
        description="OWASP vulnerability scanning",
        trigger="Activated on security-related files (.py, .js, .ts)",
        config_path="features.quality_automation.agents.security_audit",
    ),
    AgentInfo(
        id="test_generation",
        name="Test Generation Agent",
        description="Intelligent test generation",
        trigger="Runs when new code is created without tests",
        config_path="features.quality_automation.agents.test_generation",
    ),
    AgentInfo(
        id="test_execution",
        name="Test Execution Agent",
        description="Run tests during review",
        trigger="Runs existing tests after code changes",
        config_path="features.quality_automation.agents.test_execution",
    ),
    AgentInfo(
        id="doc_audit",
        name="Doc Audit Agent",
        description="Documentation freshness checks",
        trigger="Activated on *.md files and doc directories",
        config_path="features.quality_automation.agents.doc_audit",
    ),
]


class SpecializedAgentsView(SaveableViewMixin, Static):
    """Specialized agents configuration view.

    Shows a list of specialized review agents that can be enabled/disabled.
    Each agent has a toggle switch, description, and trigger condition.

    Emits:
        Changed: When an agent toggle state changes.
    """

    DEFAULT_CSS = """
    SpecializedAgentsView {
        width: 100%;
        height: 100%;
        padding: 1 2;
    }

    SpecializedAgentsView > Vertical {
        width: 100%;
        height: 100%;
    }

    SpecializedAgentsView #content-scroll {
        width: 100%;
        height: 1fr;
        min-height: 10;
    }

    SpecializedAgentsView .header {
        text-style: bold;
        text-align: center;
        margin-bottom: 1;
        width: 100%;
    }

    SpecializedAgentsView .description {
        color: $text-muted;
        text-align: center;
        margin-bottom: 2;
        width: 100%;
    }

    SpecializedAgentsView .agent-row {
        width: 100%;
        height: auto;
        padding: 1;
        margin-bottom: 1;
        background: $surface;
        border: solid $primary-background;
    }

    SpecializedAgentsView .agent-row:focus-within {
        border: solid $primary;
    }

    SpecializedAgentsView .agent-info {
        width: 2fr;
        height: auto;
    }

    SpecializedAgentsView .agent-name {
        text-style: bold;
    }

    SpecializedAgentsView .agent-description {
        color: $text-muted;
    }

    SpecializedAgentsView .agent-trigger {
        color: $text-disabled;
        text-style: italic;
        margin-top: 1;
    }

    SpecializedAgentsView .agent-control {
        width: auto;
        height: auto;
        align: right middle;
        padding-right: 1;
    }

    SpecializedAgentsView Switch {
        width: auto;
    }

    SpecializedAgentsView .help-text {
        color: $text-muted;
        margin-top: 2;
        text-align: center;
        width: 100%;
    }
    """

    class Changed(Message):
        """Message emitted when an agent toggle changes."""

        def __init__(self, agent_id: str, config_path: str, enabled: bool) -> None:
            """Initialize the Changed message.

            Args:
                agent_id: ID of the agent that changed
                config_path: Canonical config path for the agent
                enabled: New enabled state
            """
            super().__init__()
            self.agent_id = agent_id
            self.config_path = config_path
            self.enabled = enabled

    def __init__(
        self,
        current_values: dict[str, bool] | None = None,
        **kwargs,
    ) -> None:
        """Initialize the SpecializedAgentsView.

        Args:
            current_values: Dict mapping canonical config paths to enabled state
        """
        super().__init__(**kwargs)
        self._current_values: dict[str, bool] = current_values or {}

        # Suppress change emissions during initial mount
        self._initializing = True
        # Take snapshot for dirty tracking
        self._snapshot_state()

    def on_mount(self) -> None:
        """Allow change emissions after mount completes."""
        from obra.config.explorer.debug import is_debug_enabled, log_action

        # CRITICAL: Use call_after_refresh to delay setting _initializing = False
        # until AFTER all queued widget Changed events from initial value setting
        # have been processed. This prevents phantom changes from mount events.
        def finish_initialization() -> None:
            self._initializing = False
            # Re-snapshot state AFTER all mount events are processed
            self._snapshot_state()
            if is_debug_enabled():
                log_action(
                    "SpecializedAgentsView.on_mount.finish_init",
                    f"_initializing={self._initializing}, snapshot taken",
                )

        self.call_after_refresh(finish_initialization)

    def compose(self) -> ComposeResult:
        """Create the view content."""
        menu_info = get_menu_info("agents")
        with Vertical():
            yield Static(menu_info["label"], classes="header")
            yield Static(menu_info["subtitle"], classes="description")

            # Scrollable container for agent rows
            with ScrollableContainer(id="content-scroll"):
                # Render each agent row
                for agent in AGENTS:
                    yield from self._compose_agent_row(agent)

            yield Static(
                "Changes are applied when you save. Use 's' to save.",
                classes="help-text",
            )

    def _compose_agent_row(self, agent: AgentInfo) -> ComposeResult:
        """Compose a single agent configuration row.

        Args:
            agent: Agent metadata
        """
        # Get current enabled state from canonical config path
        current_value = self._current_values.get(agent.config_path, False)

        with Horizontal(classes="agent-row", id=f"agent-{agent.id}"):
            # Left: Agent info
            with Vertical(classes="agent-info"):
                yield Static(agent.name, classes="agent-name")
                yield Static(agent.description, classes="agent-description")
                yield Static(f"Triggers: {agent.trigger}", classes="agent-trigger")

            # Right: Toggle switch
            with Vertical(classes="agent-control"):
                yield Switch(
                    value=bool(current_value),
                    id=f"switch-{agent.id}",
                )

    def on_switch_changed(self, event: Switch.Changed) -> None:
        """Handle switch toggle changes."""
        # Skip processing during initial mount to prevent spurious state changes
        if self._initializing:
            return

        switch_id = event.switch.id
        if not switch_id or not switch_id.startswith("switch-"):
            return

        # Extract agent ID from switch ID
        agent_id = switch_id.replace("switch-", "")

        # Find the agent to get the canonical config path
        for agent in AGENTS:
            if agent.id == agent_id:
                self._current_values[agent.config_path] = event.value
                self.post_message(
                    self.Changed(
                        agent_id=agent_id,
                        config_path=agent.config_path,
                        enabled=event.value,
                    )
                )
                break

    def get_current_values(self) -> dict[str, bool]:
        """Get all current agent enabled states.

        Returns:
            Dict mapping canonical config paths to enabled state
        """
        return self._current_values.copy()

    def update_values(self, values: dict[str, Any]) -> None:
        """Update agent values from a config dict.

        Args:
            values: Dict mapping config paths to values
        """
        for agent in AGENTS:
            if agent.config_path in values:
                self._current_values[agent.config_path] = bool(values[agent.config_path])
                # Update the switch widget if it exists
                try:
                    switch = self.query_one(f"#switch-{agent.id}", Switch)
                    switch.value = bool(values[agent.config_path])
                except Exception:
                    pass  # Widget not mounted yet

    # --- SaveableViewMixin implementation ---

    def _get_saveable_state(self) -> dict[str, Any]:
        """Get current state for dirty tracking.

        Returns config paths mapped to current values.
        """
        return dict(self._current_values)

    def _restore_state(self, state: dict[str, Any]) -> None:
        """Restore state from snapshot and update UI."""
        self._current_values = {k: bool(v) for k, v in state.items()}
        # Update all switch widgets
        for agent in AGENTS:
            if agent.config_path in self._current_values:
                try:
                    switch = self.query_one(f"#switch-{agent.id}", Switch)
                    switch.value = self._current_values[agent.config_path]
                except Exception:
                    pass
