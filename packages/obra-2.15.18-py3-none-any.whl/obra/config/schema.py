"""Configuration schema validation for Obra.

This module defines the configuration schema and provides validation to ensure
config integrity at startup. All operational parameters must be defined in
default_config.yaml with proper types and ranges.

Related:
    - ADR-047: Config single source of truth
    - Rule 22: Configuration-wired operations
"""

from typing import Any


class ConfigSchema:
    """Comprehensive configuration schema for Obra.

    Defines expected structure, types, and value ranges for all config keys.
    Used by validate_config() to ensure config integrity at startup.
    """

    # Type validators
    INT = int
    FLOAT = float
    STR = str
    BOOL = bool
    LIST = list
    DICT = dict

    # Schema definition: path -> (type, validator_func or None)
    # validator_func signature: (value: Any) -> Tuple[bool, Optional[str]]
    # Type can be a single type or tuple of types for union validation
    SCHEMA: dict[str, tuple[type | tuple[type, ...], Any]] = {
        # API Client (E1)
        "api.client.default_timeout_s": (INT, lambda v: (v >= 120, "must be >= 120s per Rule 22")),
        # Auto Runner (E3 S0)
        "orchestration.auto.story_timeout_s": (INT, lambda v: (v > 0, "must be positive")),
        "orchestration.auto.parallel_max_workers": (INT, lambda v: (v > 0, "must be positive")),
        # Cleanup (E3 S0)
        "orchestration.cleanup.sleep_cap_s": (FLOAT, lambda v: (v > 0, "must be positive")),
        "orchestration.cleanup.investigation.max_hints": (
            INT,
            lambda v: (v > 0, "must be positive"),
        ),
        "orchestration.cleanup.investigation.tier_gap": (
            INT,
            lambda v: (v >= 0, "must be non-negative"),
        ),
        "orchestration.cleanup.investigation.tier_context": (
            INT,
            lambda v: (v >= 0, "must be non-negative"),
        ),
        # Intent Detection (E3 S1)
        "intent.detection.rich_min_words": (INT, lambda v: (v > 0, "must be positive")),
        "intent.detection.min_keyword_matches": (INT, lambda v: (v >= 0, "must be non-negative")),
        "intent.detection.min_detail_markers": (INT, lambda v: (v >= 0, "must be non-negative")),
        "intent.templates.summary_preview_length": (INT, lambda v: (v > 0, "must be positive")),
        # File Tracking (E3 S1)
        "file_tracking.max_file_size_bytes": (INT, lambda v: (v > 0, "must be positive")),
        # Cache Monitor (E3 S1)
        "observability.cache_monitor.subdir_threshold_mb": (
            INT,
            lambda v: (v > 0, "must be positive"),
        ),
        "observability.cache_monitor.top_subdirs_count": (
            INT,
            lambda v: (v > 0, "must be positive"),
        ),
        # Derivation (E3 S2)
        "derivation.preview.readme_limit": (INT, lambda v: (v > 0, "must be positive")),
        "derivation.preview.raw_response_limit": (INT, lambda v: (v > 0, "must be positive")),
        "derivation.preview.raw_response_warn_limit": (INT, lambda v: (v > 0, "must be positive")),
        "derivation.epic_output_token_limit": (INT, lambda v: (v > 0, "must be positive")),
        "derivation.epic_item_rederive_threshold": (INT, lambda v: (v > 0, "must be positive")),
        "derivation.max_depth_warning_threshold": (
            FLOAT,
            lambda v: (0 < v <= 1, "must be between 0 and 1"),
        ),
        # Intake (E3 S2)
        "intake.min_words": (INT, lambda v: (v > 0, "must be positive")),
        # Skip Tracking (E3 S2)
        "skip_tracking.max_logs_chars": (INT, lambda v: (v > 0, "must be positive")),
        # Tooling Discovery (E3 S2)
        "tooling_discovery.max_manifest_bytes": (INT, lambda v: (v > 0, "must be positive")),
        # Process Registry (E3 S2)
        "process_registry.terminate_timeout_s": (FLOAT, lambda v: (v > 0, "must be positive")),
        # Execution Quality (E3 S2)
        "execution.quality.default_threshold": (
            FLOAT,
            lambda v: (0 <= v <= 1, "must be between 0 and 1"),
        ),
        "execution.quality.generated_plan_threshold": (
            FLOAT,
            lambda v: (0 <= v <= 1, "must be between 0 and 1"),
        ),
        # Intent Thresholds (E3 S2)
        "intent.thresholds.detection_empty": (INT, lambda v: (v > 0, "must be positive")),
        "intent.thresholds.detection_existing": (INT, lambda v: (v > 0, "must be positive")),
        "intent.thresholds.interrogative_ratio": (
            FLOAT,
            lambda v: (0 <= v <= 1, "must be between 0 and 1"),
        ),
        "intent.thresholds.token_warning": (
            FLOAT,
            lambda v: (0 <= v <= 1, "must be between 0 and 1"),
        ),
        # Log Viewer (E3 S3)
        "observability.log_viewer.host": (STR, None),
        "observability.log_viewer.port": (
            INT,
            lambda v: (0 < v < 65536, "must be valid port (1-65535)"),
        ),
        "observability.log_viewer.tail_limit": (INT, lambda v: (v > 0, "must be positive")),
        "observability.log_viewer.max_events": (INT, lambda v: (v > 0, "must be positive")),
        "observability.log_viewer.max_snapshot_bytes": (INT, lambda v: (v > 0, "must be positive")),
        "observability.log_viewer.stream_sleep_s": (FLOAT, lambda v: (v > 0, "must be positive")),
        "observability.log_viewer.graceful_shutdown_delay_s": (
            FLOAT,
            lambda v: (v >= 0, "must be non-negative"),
        ),
        # Production Logger (E3 S3)
        "observability.production_logger.max_size_bytes": (
            INT,
            lambda v: (v > 0, "must be positive"),
        ),
        "observability.production_logger.backup_count": (
            INT,
            lambda v: (v >= 0, "must be non-negative"),
        ),
        # CLI Retry (E3 S3)
        "cli.retry.max_attempts": (INT, lambda v: (v > 0, "must be positive")),
        "cli.retry.initial_delay_s": ((INT, FLOAT), lambda v: (v >= 0, "must be non-negative")),
        "cli.retry.backoff_multiplier": ((INT, FLOAT), lambda v: (v >= 1, "must be >= 1")),
        "cli.force_quit_window_s": ((INT, FLOAT), lambda v: (v > 0, "must be positive")),
        # CLI Cache (E3 S3)
        "cli.cache.warn_threshold_mb": (INT, lambda v: (v > 0, "must be positive")),
        "cli.cache.critical_threshold_mb": (INT, lambda v: (v > 0, "must be positive")),
        # Auth OAuth (E3 S3)
        "auth.oauth.poll_interval_s": (FLOAT, lambda v: (v > 0, "must be positive")),
        "auth.oauth.thread_join_timeout_s": (FLOAT, lambda v: (v > 0, "must be positive")),
        # Plan Item Validation (E3 S3)
        "validation.plan_item.max_acceptance_criteria": (
            INT,
            lambda v: (v > 0, "must be positive"),
        ),
        "validation.plan_item.max_description_words": (INT, lambda v: (v > 0, "must be positive")),
        "validation.plan_item.max_tasks": (INT, lambda v: (v > 0, "must be positive")),
        "validation.plan_item.max_loc": (INT, lambda v: (v > 0, "must be positive")),
        "validation.plan_item.max_files_per_task": (INT, lambda v: (v > 0, "must be positive")),
        # Config Explorer (E3 S3)
        "config_explorer.notification_timeout_s": (INT, lambda v: (v > 0, "must be positive")),
    }


def _get_nested_value(config: dict[str, Any], path: str) -> tuple[Any, bool]:
    """Get a value from nested dict using dot notation path.

    Args:
        config: Configuration dictionary
        path: Dot-separated path (e.g., "orchestration.auto.story_timeout_s")

    Returns:
        Tuple of (value, found) where found is True if path exists
    """
    keys = path.split(".")
    current = config

    for key in keys:
        if not isinstance(current, dict) or key not in current:
            return None, False
        current = current[key]

    return current, True


def validate_config(config: dict[str, Any]) -> tuple[bool, list[str]]:
    """Validate configuration against schema.

    Checks:
        1. All required keys exist
        2. Values have correct types
        3. Values pass range/constraint validation

    Args:
        config: Configuration dictionary to validate

    Returns:
        Tuple of (is_valid, error_messages)
        - is_valid: True if config passes all checks
        - error_messages: List of validation errors (empty if valid)

    Example:
        >>> config = load_layered_config()[0]
        >>> valid, errors = validate_config(config)
        >>> if not valid:
        ...     print("\\n".join(errors))
    """
    errors: list[str] = []

    for path, (expected_type, validator) in ConfigSchema.SCHEMA.items():
        # Check if key exists
        value, found = _get_nested_value(config, path)
        if not found:
            errors.append(f"Missing required config key: {path}")
            continue

        # Check type
        if not isinstance(value, expected_type):
            # Format expected type name (handle both single types and tuples)
            if isinstance(expected_type, tuple):
                type_names = " | ".join(t.__name__ for t in expected_type)
            else:
                type_names = expected_type.__name__
            errors.append(
                f"Config key '{path}' has wrong type: "
                f"expected {type_names}, got {type(value).__name__}"
            )
            continue

        # Run custom validator if provided
        if validator is not None:
            is_valid, error_msg = validator(value)
            if not is_valid:
                errors.append(f"Config key '{path}' validation failed: {error_msg} (got {value})")

    return (len(errors) == 0, errors)
