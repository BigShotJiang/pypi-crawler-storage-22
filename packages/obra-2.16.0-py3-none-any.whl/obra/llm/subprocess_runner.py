"""Unified LLM subprocess runner for Obra.

This module consolidates LLM CLI subprocess invocation logic that was previously
duplicated across multiple modules (cli_runner, base, execute, fix handlers).

Features:
    - Unified command building and subprocess execution
    - Provider-specific handling (Claude, Codex, Gemini)
    - Automatic retries with exponential backoff
    - Auth error detection with provider-specific hints
    - Streaming and non-streaming modes
    - Prompt file management with deferred cleanup for Codex

Architecture Decision:
    See docs/decisions/ADR-047-UNIFIED-LLM-SUBPROCESS-RUNNER.md

Trigger Issue:
    BUG-215c2476 revealed 8 pattern deviations between review agents and
    execute/fix handlers, motivating this consolidation.

Related:
    - obra/llm/cli_runner.py (original non-streaming implementation)
    - obra/hybrid/handlers/execute.py (original streaming implementation)
    - obra/agents/base.py (original review agent implementation)
    - obra/hybrid/handlers/fix.py (original fix handler implementation)
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
import re
import subprocess
import tempfile
import threading
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

from obra.config.loaders import (
    get_llm_logging_preview_enabled,
    get_llm_logging_preview_max_prompt_chars,
    get_llm_logging_preview_max_response_chars,
    get_llm_stream_idle_timeout,
    get_subprocess_runner_timeouts,
)
from obra.constants import (
    LLM_MONITOR_STOP_TIMEOUT_S,
    LLM_STDERR_JOIN_TIMEOUT_S,
    LLM_SUBPROCESS_TIMEOUT_S,
)
from obra.core.process_registry import ProcessRegistry, get_prctl_death_signal_fn
from obra.exceptions import SecurityError
from obra.hybrid.prompt_file import PromptFileManager
from obra.llm.interactive_guard import (
    INTERACTIVE_GUARD_ERROR_CODE,
    InteractiveGuard,
    InteractiveGuardFailure,
    InteractiveMatch,
)
from obra.llm.retry import RetryConfig, with_retry

logger = logging.getLogger(__name__)

CODEX_POLICY_ERROR_CODE = "LLM_CODEX_POLICY_ERROR"

# Import monitoring support with graceful fallback
try:
    from obra.monitoring.agent_monitor import MonitoringThread

    MONITORING_AVAILABLE = True
except ImportError:
    MONITORING_AVAILABLE = False
    logger.debug("MonitoringThread not available, monitoring will be disabled")

# FIX-STREAMING-001: Status lines to filter from LLM CLI output
# These are CLI status indicators that shouldn't be echoed to the user
STREAMING_FILTER_PATTERNS = [
    "wait",
    "waiting",
    "running",
]


def _should_filter_streaming_line(line: str) -> bool:
    """Check if a streaming line should be filtered from output.

    Filters status/spinner text that LLM CLIs emit during processing.
    These are internal status indicators, not actual response content.

    Args:
        line: The line to check

    Returns:
        True if the line should be filtered (not shown to user)
    """
    stripped = line.strip().lower()
    # Filter exact matches of status words (not substrings in actual content)
    return stripped in STREAMING_FILTER_PATTERNS


def _build_interactive_guard() -> InteractiveGuard | None:
    """Construct InteractiveGuard from config if enabled."""
    try:
        from obra.config.loaders import (
            get_interactive_guard_enabled,
            get_interactive_guard_patterns,
        )
    except Exception as exc:  # pragma: no cover - config import failures should not break runs
        logger.debug("Interactive guard config unavailable: %s", exc)
        return None

    if not get_interactive_guard_enabled():
        return None

    try:
        patterns = get_interactive_guard_patterns()
        if not patterns:
            return None
        return InteractiveGuard.from_patterns(patterns)
    except Exception as exc:
        logger.warning("Interactive guard disabled due to pattern error: %s", exc)
        return None


def _interactive_guard_error(match: InteractiveMatch) -> str:
    """Format interactive guard error message."""
    return f"{INTERACTIVE_GUARD_ERROR_CODE}: {match.pattern_id}: {match.line}"


def validate_working_dir_scope(working_dir: Path) -> None:
    """Validate that working directory is safe for LLM subprocess execution.

    This function provides defense-in-depth by validating the working directory
    before subprocess execution. It checks:
    1. The path exists and is a directory
    2. The path resolves to a real location (no symlink escapes)

    Note: This validates the working_dir itself, not file operations within it.
    File operation enforcement happens at the LLM CLI level via sandbox flags.
    This validation ensures the subprocess starts in a legitimate directory.

    Args:
        working_dir: The working directory for subprocess execution

    Raises:
        SecurityError: If the working directory fails validation

    Example:
        >>> from pathlib import Path
        >>> validate_working_dir_scope(Path("/home/user/project"))
        >>> # Passes validation
        >>>
        >>> validate_working_dir_scope(Path("/nonexistent"))
        SecurityError: Working directory does not exist: /nonexistent
    """
    from obra.config.loaders import get_working_dir_enforcement_enabled

    if not get_working_dir_enforcement_enabled():
        logger.debug("Working directory enforcement disabled by config")
        return

    # Resolve the path to eliminate symlinks and relative components
    try:
        resolved = working_dir.resolve()
    except OSError as e:
        msg = f"Failed to resolve working directory: {working_dir}"
        raise SecurityError(
            msg,
            attempted_path=str(working_dir),
            allowed_root="",
        ) from e

    # Verify the directory exists
    if not resolved.exists():
        msg = f"Working directory does not exist: {resolved}"
        raise SecurityError(
            msg,
            attempted_path=str(resolved),
            allowed_root="",
        )

    # Verify it's a directory, not a file
    if not resolved.is_dir():
        msg = f"Working directory path is not a directory: {resolved}"
        raise SecurityError(
            msg,
            attempted_path=str(resolved),
            allowed_root="",
        )

    logger.debug(f"Working directory validation passed: {resolved}")


@dataclass
class LLMSubprocessConfig:
    """Configuration for LLM subprocess execution.

    Attributes:
        prompt: The prompt to send to the LLM
        cwd: Working directory for subprocess execution
        provider: LLM provider (anthropic, openai, google)
        model: Model identifier
        thinking_level: Thinking level (off, low, medium, high, maximum)
        auth_method: Authentication method (oauth, api_key)
        timeout_s: Timeout in seconds (default 600)
        stream_idle_timeout_s: Idle timeout in seconds for streaming output (None uses config default)
        skip_git_check: Whether to add --skip-git-repo-check for Codex
        bypass_sandbox: Whether to use --dangerously-bypass-approvals-and-sandbox for Codex
        approval_mode: Codex approval mode (suggest, auto-edit, full-auto)
        retry_enabled: Whether to retry on transient errors
        retry_config: Optional retry configuration
        streaming: Whether to stream output via on_stream callback
        on_stream: Optional callback for streaming output (receives line)
        log_event: Optional callback for logging events
        trace_id: Optional trace ID for observability
        parent_span_id: Optional parent span ID for tracing
        call_site: Optional call site identifier for logging
        monitoring_context: Optional dict with monitoring configuration
        session_id: Optional session ID for trace correlation
        run_id: Optional run ID for prompt file management
        mode: CLI mode - "text" for derive/examine (adds --print), "execute" for
            execute/fix phases (no --print, allows file writes). Default "text".
    """

    prompt: str
    cwd: Path
    provider: str
    model: str
    thinking_level: str
    auth_method: str = "oauth"
    timeout_s: int = LLM_SUBPROCESS_TIMEOUT_S
    stream_idle_timeout_s: int | None = None
    skip_git_check: bool = False
    bypass_sandbox: bool = False
    approval_mode: str | None = None
    retry_enabled: bool = True
    retry_config: RetryConfig | None = None
    streaming: bool = False
    on_stream: Callable[[str], None] | None = None
    log_event: Callable[..., None] | None = None
    trace_id: str | None = None
    parent_span_id: str | None = None
    call_site: str | None = None
    monitoring_context: dict[str, Any] | None = None
    session_id: str | None = None
    run_id: str | None = None
    process_registry: ProcessRegistry | None = None
    mode: str = "text"  # ISSUE-EXEC-003: "text" for derive/examine, "execute" for execute/fix
    response_format: str = "json"  # "text" for prose output, "json" for structured output


@dataclass
class LLMErrorDetails:
    """Parsed error details from provider CLI output."""

    status_code: int | None
    request_id: str | None
    error_type: str | None
    message: str
    raw: str


def _extract_cli_error_details(stderr: str, stdout: str, provider: str) -> LLMErrorDetails:
    """Extract structured error details from CLI stdout/stderr."""
    combined = (stderr or stdout or "").strip()
    provider_lower = provider.lower() if provider else ""
    status_code: int | None = None
    request_id: str | None = None
    error_type: str | None = None
    message = combined

    if combined:
        status_match = re.search(r"API Error:\s*(\d{3})", combined)
        if status_match:
            status_code = int(status_match.group(1))

        json_payload = None
        if "{" in combined and "}" in combined:
            start = combined.find("{")
            end = combined.rfind("}")
            if start != -1 and end != -1 and end > start:
                payload_text = combined[start : end + 1]
                try:
                    json_payload = json.loads(payload_text)
                except json.JSONDecodeError:
                    json_payload = None

        if isinstance(json_payload, dict):
            request_id = json_payload.get("request_id")
            error_obj = json_payload.get("error", {})
            if isinstance(error_obj, dict):
                error_type = error_obj.get("type")
                error_message = error_obj.get("message")
                if isinstance(error_message, str) and error_message.strip():
                    message = error_message.strip()

        if request_id is None and provider_lower == "anthropic":
            req_match = re.search(r"request_id\"?\s*[:=]\s*\"([\\w-]+)\"", combined)
            if req_match:
                request_id = req_match.group(1)

        if status_code is None:
            status_inline = re.search(r"(status code|http)\s*[:=]?\s*(\d{3})", combined)
            if status_inline:
                status_code = int(status_inline.group(2))
            else:
                status_5xx = re.search(r"\b(5\d{2})\b", combined)
                if status_5xx:
                    status_code = int(status_5xx.group(1))

    if not message:
        message = combined or "Unknown error"

    return LLMErrorDetails(
        status_code=status_code,
        request_id=request_id,
        error_type=error_type,
        message=message,
        raw=combined,
    )


def _format_retry_summary(details: LLMErrorDetails | None) -> str:
    """Format a concise retry summary string for UX."""
    if details is None:
        return "Transient provider error"
    summary_parts = []
    if details.status_code:
        summary_parts.append(str(details.status_code))
    if details.message:
        summary_parts.append(details.message)
    summary = ": ".join(summary_parts).strip()
    return summary or "Transient provider error"


def _format_error_message(details: LLMErrorDetails) -> str:
    """Format a user-facing error message from details."""
    parts: list[str] = []
    if details.status_code:
        parts.append(str(details.status_code))
    if details.message:
        parts.append(details.message)
    msg = " ".join(parts).strip() or details.raw or "Unknown error"
    if details.request_id:
        msg = f"{msg} (request_id={details.request_id})"
    return msg


def _make_retry_callback(
    provider: str,
    retry_config: RetryConfig,
) -> Callable[[int, Exception, float], None]:
    """Build a retry callback that shows a rate-limited banner."""

    def _on_retry(attempt: int, exc: Exception, delay_s: float) -> None:
        details = _extract_cli_error_details(str(exc), "", provider)
        summary = _format_retry_summary(details)
        next_attempt = min(attempt + 1, retry_config.max_attempts)
        try:
            from obra.display.retry import maybe_show_retry_banner

            maybe_show_retry_banner(
                attempt=next_attempt,
                max_attempts=retry_config.max_attempts,
                delay_s=delay_s,
                provider=provider,
                summary=summary,
            )
        except Exception:
            pass

    return _on_retry


@dataclass
class LLMSubprocessResult:
    """Result from LLM subprocess execution.

    Attributes:
        success: Whether the subprocess executed successfully
        output: The stdout output from the subprocess
        error: Error message if execution failed
        returncode: The subprocess return code
        duration_ms: Execution duration in milliseconds
        retry_count: Number of retries attempted
        interactive_failure: Interactive guard failure details (if applicable)
    """

    success: bool
    output: str
    error: str | None = None
    returncode: int = 0
    duration_ms: int = 0
    retry_count: int = 0
    interactive_failure: InteractiveGuardFailure | None = None
    error_details: LLMErrorDetails | None = None


@dataclass
class LLMCallContext:
    """Context for logging an LLM call.

    Groups execution-specific parameters for _log_llm_call.
    """

    prompt: str
    response: str
    start_time: float
    span_id: str
    status: str = "success"
    error_message: str | None = None
    retry_count: int = 0


def _prepare_prompt(prompt: str, provider: str, thinking_level: str) -> str:
    """Prepare prompt with provider-specific keywords if needed.

    Args:
        prompt: Base prompt text
        provider: LLM provider
        thinking_level: Thinking level setting

    Returns:
        Prepared prompt with keywords if applicable
    """
    from obra.config import get_thinking_keyword

    keyword = get_thinking_keyword({"provider": provider, "thinking_level": thinking_level})
    if keyword:
        return f"{keyword}: {prompt}"
    return prompt


def _get_default_retry_config() -> RetryConfig:
    """Get retry config from Obra settings or defaults.

    Returns:
        RetryConfig with settings from Obra config or sensible defaults
    """
    try:
        return RetryConfig.from_obra_config()
    except Exception as e:
        logger.debug(f"Could not load retry config, using defaults: {e}")
        return RetryConfig()


def _resolve_codex_profile(
    config: LLMSubprocessConfig,
    *,
    force_bypass: bool = False,
) -> dict[str, Any]:
    """Resolve effective Codex CLI profile settings."""
    bypass = bool(config.bypass_sandbox) or force_bypass
    approval_mode = config.approval_mode
    forced = False
    if config.mode == "text" and not force_bypass:
        # Text mode must remain non-executable; ignore bypass_sandbox.
        bypass = False
    if force_bypass:
        forced = True
        if not approval_mode:
            approval_mode = "full-auto"
    return {
        "bypass": bypass,
        "approval_mode": approval_mode,
        "forced": forced,
    }


def _is_codex_policy_error(response_text: str) -> bool:
    policy_error_indicators = [
        "blocked by policy",
        "rejected: blocked",
        "approval policy is never",
        '"type": "error"',
        '"error":',
        "can't run shell commands",
        "cannot run shell commands",
    ]
    response_lower = response_text.lower()
    return any(indicator.lower() in response_lower for indicator in policy_error_indicators)


def run_llm_subprocess(
    config: LLMSubprocessConfig,
) -> LLMSubprocessResult:
    """Execute an LLM via its provider CLI subprocess.

    This is the unified entry point for all LLM subprocess invocations in Obra.
    It handles:
    - Command building from provider/model/thinking_level
    - Prompt file management with deferred cleanup for Codex
    - Subprocess execution with optional streaming
    - Error detection and automatic retries
    - Auth error hints for provider CLIs
    - Monitoring thread support for hang detection

    Args:
        config: LLMSubprocessConfig with all execution parameters

    Returns:
        LLMSubprocessResult with success status and output

    Example:
        >>> from pathlib import Path
        >>> config = LLMSubprocessConfig(
        ...     prompt="Write a hello world function",
        ...     cwd=Path("/path/to/project"),
        ...     provider="anthropic",
        ...     model="claude-sonnet-4",
        ...     thinking_level="medium",
        ... )
        >>> result = run_llm_subprocess(config)
        >>> print(result.output)
    """
    from obra.config import (
        build_llm_args,
        build_subprocess_env,
        get_llm_cli,
        get_prompt_max_files,
        get_prompt_retention,
    )

    # Defense-in-depth: Validate working directory before any subprocess execution
    # Only validates in execute mode (when file writes are allowed)
    if config.mode == "execute":
        validate_working_dir_scope(config.cwd)

    start_time = time.time()
    span_id = uuid.uuid4().hex
    status = "success"
    error_message: str | None = None
    retry_count = 0

    # Prepare prompt with thinking keywords if needed
    from obra.config.llm import resolve_reasoning_selection

    forced_level = None
    strict_mode = False
    try:
        from obra.config.loaders import load_layered_config

        config_data, _, _ = load_layered_config(include_defaults=True)
        reasoning_config = config_data.get("llm", {}).get("reasoning", {})
        if isinstance(reasoning_config, dict):
            forced_level = reasoning_config.get("force_level")
            strict_mode = bool(reasoning_config.get("strict_mode", False))
    except Exception:
        forced_level = None
        strict_mode = False

    reasoning_selection = resolve_reasoning_selection(
        provider=config.provider,
        model=config.model,
        stage_level=config.thinking_level,
        user_forced_level=forced_level,
        tier_min_level=None,
        tier_max_level=None,
        cli_override=None,
        strict_mode=strict_mode,
    )
    if reasoning_selection.clamped:
        logger.warning(
            "Reasoning level clamped for %s:%s (requested=%s resolved=%s reason=%s)",
            config.provider,
            config.model,
            config.thinking_level,
            reasoning_selection.normalized_level,
            reasoning_selection.clamp_reason,
        )

    prepared_prompt = _prepare_prompt(
        config.prompt,
        config.provider,
        reasoning_selection.normalized_level,
    )

    # Interactive guard configuration (optional)
    interactive_guard = _build_interactive_guard()

    # Get CLI command and args
    cli_command = get_llm_cli(config.provider)
    # ISSUE-EXEC-003: Pass mode to distinguish text (derive/examine) vs execute phases
    cli_args = build_llm_args(
        {
            "provider": config.provider,
            "model": config.model,
            "thinking_level": reasoning_selection.normalized_level,
            "provider_reasoning_level": reasoning_selection.provider_level,
        },
        mode=config.mode,
        response_format=config.response_format,
    )

    # Build subprocess environment with auth-aware API key handling
    subprocess_env = build_subprocess_env(config.auth_method)

    # Set up prompt file manager
    prompt_manager = PromptFileManager(
        config.cwd,
        retain=get_prompt_retention(),
        max_files=get_prompt_max_files(),
        run_id=config.run_id,
    )
    # BUG-c2e0a391: Use absolute paths for Codex on Windows to work around
    # Codex CLI not properly resolving relative paths against -C workspace flag
    use_absolute_for_codex = config.provider == "openai"
    prompt_path, prompt_instruction = prompt_manager.write_prompt(
        prepared_prompt, use_absolute=use_absolute_for_codex
    )
    prompt_argument = prompt_instruction
    if config.provider == "openai" and config.mode == "text":
        # Use inline prompt for short inputs; fall back to prompt file for long inputs.
        # 4000 chars is a shell command-line buffer limit - protocol constant
        force_prompt_file = os.environ.get("OBRA_OPENAI_TEXT_FORCE_PROMPT_FILE") == "1"
        if force_prompt_file or len(prepared_prompt) > 4000:
            logger.debug(
                "Using prompt file for OpenAI text mode (force=%s, chars=%s)",
                force_prompt_file,
                len(prepared_prompt),
            )
            prompt_argument = prompt_instruction
        else:
            prompt_argument = prepared_prompt

    # Provider-specific handling: OpenAI Codex
    if config.provider == "openai":
        # Defer cleanup for Codex - it needs prompt files to persist between attempts
        prompt_manager.defer_cleanup()
        logger.debug("Deferring prompt cleanup for Codex; cleanup will run on next invocation.")

        # Build Codex-specific command
        # BUG-a377298b: Must pass approval_mode to override user's Codex config.
        # Without this, Codex may use approval_policy=never which forces read-only sandbox.
        def _build_codex_cmd(profile: dict[str, Any]) -> list[str]:
            base_cmd = [
                cli_command,
                "exec",
                "-C",
                str(config.cwd),
            ]
            if config.mode == "text":
                if profile["bypass"]:
                    base_cmd.append("--dangerously-bypass-approvals-and-sandbox")
                    logger.debug(
                        "Codex: Using --dangerously-bypass-approvals-and-sandbox (text mode)"
                    )
                else:
                    base_cmd.extend(["--sandbox", "read-only"])
                    logger.debug("Codex: Using --sandbox read-only for text mode")
                    if profile["approval_mode"]:
                        base_cmd.extend(
                            [
                                "--config",
                                f"defaults.approval_mode={profile['approval_mode']}",
                            ]
                        )
                        logger.debug(
                            "Codex: Using defaults.approval_mode=%s (text mode)",
                            profile["approval_mode"],
                        )
            elif profile["bypass"]:
                base_cmd.append("--dangerously-bypass-approvals-and-sandbox")
                logger.debug("Codex: Using --dangerously-bypass-approvals-and-sandbox")
            else:
                base_cmd.extend(["--sandbox", "workspace-write"])
                if profile["approval_mode"]:
                    base_cmd.extend(
                        [
                            "--config",
                            f"defaults.approval_mode={profile['approval_mode']}",
                        ]
                    )
                    logger.debug(
                        "Codex: Using defaults.approval_mode=%s",
                        profile["approval_mode"],
                    )

            if config.skip_git_check:
                base_cmd.append("--skip-git-repo-check")
                logger.debug("Codex: Adding --skip-git-repo-check (skip_git_check=True)")
            if config.model and config.model not in ("default", "auto"):
                base_cmd.extend(["--model", config.model])
            return base_cmd

        def _run_codex(profile: dict[str, Any]) -> str:
            """Execute Codex CLI with output capture."""
            # Create fresh temp file for each attempt (handles retry correctly)
            with tempfile.NamedTemporaryFile(mode="w+", delete=False, encoding="utf-8") as f:
                output_path = f.name

            base_cmd = _build_codex_cmd(profile)
            cmd = [*base_cmd, "--output-last-message", output_path]
            sandbox_mode = (
                "bypass"
                if profile["bypass"]
                else ("read-only" if config.mode == "text" else "workspace-write")
            )
            model_label = config.model or "default"
            approval_label = profile["approval_mode"] or "default"
            prompt_name = Path(prompt_path).name
            logger.info(
                "Codex invoke: mode=%s sandbox=%s approval=%s model=%s cwd=%s prompt=%s",
                config.mode,
                sandbox_mode,
                approval_label,
                model_label,
                config.cwd,
                prompt_name,
            )
            logger.debug("Codex CLI command: %s", [*cmd, prompt_argument])
            logger.debug("Codex workspace root set via -C: %s", config.cwd)
            logger.debug("Codex prompt file: %s", prompt_path)

            try:
                prompt_manager.ensure_prompt_available(prompt_path)
                result = subprocess.run(
                    [*cmd, prompt_argument],
                    cwd=config.cwd,
                    text=True,
                    encoding="utf-8",
                    capture_output=True,
                    timeout=config.timeout_s,
                    check=False,
                    env=subprocess_env,
                )

                # Check for error in stderr that indicates retryable failure
                if result.returncode != 0:
                    error_output = result.stderr or result.stdout or "Unknown error"
                    msg = f"Codex CLI failed: {error_output[:500]}"
                    raise RuntimeError(msg)

                return Path(output_path).read_text(encoding="utf-8")
            finally:
                with contextlib.suppress(Exception):
                    Path(output_path).unlink(missing_ok=True)

        try:
            profile = _resolve_codex_profile(config)
            logger.debug(
                "Codex profile resolved: mode=%s bypass=%s approval_mode=%s forced=%s",
                config.mode,
                profile["bypass"],
                profile["approval_mode"],
                profile["forced"],
            )
            # Apply retry logic for transient errors
            if config.retry_enabled:
                cfg = config.retry_config or _get_default_retry_config()
                on_retry = _make_retry_callback(config.provider, cfg)
                result = with_retry(
                    lambda: _run_codex(profile),
                    config=cfg,
                    operation_name=f"codex_invoke_{config.model}",
                    on_retry=on_retry,
                )
                retry_count = result.attempts - 1
                if not result.success:
                    status = "error"
                    error_details = _extract_cli_error_details(
                        str(result.last_error) if result.last_error else "",
                        "",
                        config.provider,
                    )
                    error_message = _format_error_message(error_details)
                    duration_ms = int((time.time() - start_time) * 1000)
                    _log_llm_call(
                        config,
                        LLMCallContext(
                            prompt=prepared_prompt,
                            response="",
                            start_time=start_time,
                            span_id=span_id,
                            status=status,
                            error_message=error_message,
                        ),
                    )
                    return LLMSubprocessResult(
                        success=False,
                        output="",
                        error=error_message,
                        returncode=1,
                        duration_ms=duration_ms,
                        retry_count=retry_count,
                        error_details=error_details,
                    )
                response_text = result.value
            else:
                response_text = _run_codex(profile)

            # BUG-a377298b: Check for Codex policy errors in output
            # Codex may return exit code 0 but with error content when blocked by policy
            if _is_codex_policy_error(response_text):
                logger.warning(
                    "Codex policy error context: mode=%s bypass=%s approval_mode=%s forced=%s",
                    config.mode,
                    profile["bypass"],
                    profile["approval_mode"],
                    profile["forced"],
                )
                if config.mode != "text":
                    retry_profile = _resolve_codex_profile(config, force_bypass=True)
                    if retry_profile != profile:
                        logger.warning(
                            "Codex policy error: retrying once with forced bypass profile"
                        )
                        response_text = _run_codex(retry_profile)
                        profile = retry_profile
                if _is_codex_policy_error(response_text):
                    error_message = f"{CODEX_POLICY_ERROR_CODE}: {response_text[:500]}"
                    logger.warning(error_message)
                    status = "error"
                    duration_ms = int((time.time() - start_time) * 1000)
                    error_details = _extract_cli_error_details(
                        error_message,
                        "",
                        config.provider,
                    )
                    _log_llm_call(
                        config,
                        LLMCallContext(
                            prompt=prepared_prompt,
                            response=response_text,
                            start_time=start_time,
                            span_id=span_id,
                            status=status,
                            error_message=error_message,
                        ),
                    )
                    return LLMSubprocessResult(
                        success=False,
                        output=response_text,
                        error=error_message,
                        returncode=0,  # Codex returned 0 but with error content
                        duration_ms=duration_ms,
                        retry_count=retry_count,
                        error_details=error_details,
                    )

            if interactive_guard:
                interactive_match = interactive_guard.scan_output(response_text, "")
                if interactive_match:
                    interactive_failure = InteractiveGuardFailure.from_match(interactive_match)
                    error_message = _interactive_guard_error(interactive_match)
                    status = "error"
                    duration_ms = int((time.time() - start_time) * 1000)
                    error_details = _extract_cli_error_details(
                        error_message,
                        "",
                        config.provider,
                    )
                    _log_llm_call(
                        config,
                        LLMCallContext(
                            prompt=prepared_prompt,
                            response=response_text,
                            start_time=start_time,
                            span_id=span_id,
                            status=status,
                            error_message=error_message,
                        ),
                    )
                    return LLMSubprocessResult(
                        success=False,
                        output=response_text,
                        error=error_message,
                        returncode=1,
                        duration_ms=duration_ms,
                        retry_count=retry_count,
                        interactive_failure=interactive_failure,
                        error_details=error_details,
                    )

        except FileNotFoundError as exc:
            status = "error"
            error_message = str(exc)
            duration_ms = int((time.time() - start_time) * 1000)
            error_details = _extract_cli_error_details(error_message, "", config.provider)
            _log_llm_call(
                config,
                LLMCallContext(
                    prompt=prepared_prompt,
                    response="",
                    start_time=start_time,
                    span_id=span_id,
                    status=status,
                    error_message=error_message,
                ),
            )
            return LLMSubprocessResult(
                success=False,
                output="",
                error=error_message,
                returncode=1,
                duration_ms=duration_ms,
                retry_count=retry_count,
                error_details=error_details,
            )
        except Exception as exc:
            status = "error"
            error_message = str(exc)
            duration_ms = int((time.time() - start_time) * 1000)
            error_details = _extract_cli_error_details(error_message, "", config.provider)
            _log_llm_call(
                config,
                LLMCallContext(
                    prompt=prepared_prompt,
                    response="",
                    start_time=start_time,
                    span_id=span_id,
                    status=status,
                    error_message=error_message,
                ),
            )
            return LLMSubprocessResult(
                success=False,
                output="",
                error=error_message,
                returncode=1,
                duration_ms=duration_ms,
                retry_count=retry_count,
                error_details=error_details,
            )
        finally:
            prompt_manager.cleanup(prompt_path)

        duration_ms = int((time.time() - start_time) * 1000)
        _log_llm_call(
            config,
            LLMCallContext(
                prompt=prepared_prompt,
                response=response_text,
                start_time=start_time,
                span_id=span_id,
                status=status,
                error_message=error_message,
            ),
        )
        return LLMSubprocessResult(
            success=True,
            output=response_text,
            returncode=0,
            duration_ms=duration_ms,
            retry_count=retry_count,
        )

    # Non-Codex providers (Claude, Gemini, etc.)
    cmd = [cli_command, *cli_args, prompt_instruction]

    # Initialize response_text to avoid UnboundLocalError in finally block
    response_text = ""
    stderr_text = ""

    # Non-streaming execution
    if not config.streaming:
        # Get preexec_fn for Linux prctl (orphan prevention)
        preexec_fn = get_prctl_death_signal_fn()

        def _run_cli_non_streaming() -> tuple[str, str]:
            """Execute CLI command without streaming, with monitoring support."""
            # Use Popen + MonitoringThread for hang detection (ADR-043)
            proc = subprocess.Popen(
                cmd,
                cwd=config.cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                env=subprocess_env,
                preexec_fn=preexec_fn,
            )

            # Register PID with ProcessRegistry for lifecycle tracking
            if config.process_registry:
                config.process_registry.register(proc.pid, f"{config.provider}-cli")

            # Initialize MonitoringThread if context provided
            monitor: Any | None = None
            if config.monitoring_context and MONITORING_AVAILABLE:
                try:
                    ctx = config.monitoring_context
                    mon_config = ctx.get("config")
                    workspace_path = ctx.get("workspace_path")
                    production_logger = ctx.get("production_logger")
                    session_id = ctx.get("session_id")

                    if isinstance(mon_config, dict):
                        monitoring_enabled = (
                            mon_config
                            and "orchestration" in mon_config
                            and "monitoring" in mon_config["orchestration"]
                            and mon_config["orchestration"]["monitoring"].get("enabled", False)
                        )
                    else:
                        monitoring_enabled = (
                            mon_config
                            and hasattr(mon_config, "orchestration")
                            and hasattr(mon_config.orchestration, "monitoring")
                            and mon_config.orchestration.monitoring.enabled
                        )

                    if monitoring_enabled and workspace_path and production_logger and session_id:
                        assert mon_config is not None
                        monitor = MonitoringThread(
                            process=proc,
                            config=cast(dict, mon_config),
                            workspace_path=Path(workspace_path),
                            production_logger=production_logger,
                            session_id=session_id,
                            state_manager=None,
                            task_id=None,
                            base_timeout=config.timeout_s,
                        )
                        monitor.start()
                        logger.info(
                            f"Monitoring thread started for non-streaming LLM call: PID={proc.pid}, "
                            f"provider={config.provider}, timeout={config.timeout_s}s"
                        )
                except Exception as e:
                    logger.error(f"Failed to start monitoring thread: {e}", exc_info=True)
                    monitor = None

            try:
                stdout, stderr = proc.communicate(timeout=config.timeout_s)
                if proc.returncode != 0:
                    raise RuntimeError((stderr or stdout or "Unknown CLI error")[:500])
                return stdout, stderr
            except subprocess.TimeoutExpired as exc:
                proc.kill()
                proc.communicate()
                msg = f"LLM CLI timed out after {config.timeout_s}s"
                raise RuntimeError(msg) from exc
            finally:
                # Unregister PID from ProcessRegistry
                if config.process_registry:
                    config.process_registry.unregister(proc.pid)
                if monitor:
                    try:
                        monitor.stop(timeout=LLM_MONITOR_STOP_TIMEOUT_S)
                    except Exception as e:
                        logger.warning(f"Error stopping monitoring thread: {e}")

        try:
            # Apply retry logic for transient errors
            if config.retry_enabled:
                cfg = config.retry_config or _get_default_retry_config()
                on_retry = _make_retry_callback(config.provider, cfg)
                result = with_retry(
                    _run_cli_non_streaming,
                    config=cfg,
                    operation_name=f"{config.provider}_invoke_{config.model}",
                    on_retry=on_retry,
                )
                retry_count = result.attempts - 1
                if not result.success:
                    status = "error"
                    error_details = _extract_cli_error_details(
                        str(result.last_error) if result.last_error else "",
                        "",
                        config.provider,
                    )
                    error_message = _format_error_message(error_details)
                    duration_ms = int((time.time() - start_time) * 1000)
                    _log_llm_call(
                        config,
                        LLMCallContext(
                            prompt=prepared_prompt,
                            response="",
                            start_time=start_time,
                            span_id=span_id,
                            status=status,
                            error_message=error_message,
                        ),
                    )
                    return LLMSubprocessResult(
                        success=False,
                        output="",
                        error=error_message,
                        returncode=1,
                        duration_ms=duration_ms,
                        retry_count=retry_count,
                        error_details=error_details,
                    )
                result_value = result.value
                if isinstance(result_value, tuple):
                    response_text, stderr_text = result_value
                else:
                    response_text = result_value
                    stderr_text = ""
            else:
                response_text, stderr_text = _run_cli_non_streaming()

        except Exception as exc:
            status = "error"
            error_message = str(exc)
            duration_ms = int((time.time() - start_time) * 1000)
            error_details = _extract_cli_error_details(error_message, "", config.provider)
            _log_llm_call(
                config,
                LLMCallContext(
                    prompt=prepared_prompt,
                    response="",
                    start_time=start_time,
                    span_id=span_id,
                    status=status,
                    error_message=error_message,
                ),
            )
            return LLMSubprocessResult(
                success=False,
                output="",
                error=error_message,
                returncode=1,
                duration_ms=duration_ms,
                retry_count=retry_count,
                error_details=error_details,
            )
        finally:
            # Display token usage
            if response_text and status == "success":
                _display_token_usage(config.provider, prepared_prompt, response_text)

            # Cleanup Claude Code CLI temp files
            if config.provider == "anthropic":
                _cleanup_claude_temp_files(config.cwd)

            prompt_manager.cleanup(prompt_path)

        if interactive_guard:
            interactive_match = interactive_guard.scan_output(response_text, stderr_text)
            if interactive_match:
                interactive_failure = InteractiveGuardFailure.from_match(interactive_match)
                error_message = _interactive_guard_error(interactive_match)
                status = "error"
                duration_ms = int((time.time() - start_time) * 1000)
                error_details = _extract_cli_error_details(
                    error_message,
                    "",
                    config.provider,
                )
                _log_llm_call(
                    config,
                    LLMCallContext(
                        prompt=prepared_prompt,
                        response=response_text,
                        start_time=start_time,
                        span_id=span_id,
                        status=status,
                        error_message=error_message,
                    ),
                )
                return LLMSubprocessResult(
                    success=False,
                    output=response_text,
                    error=error_message,
                    returncode=1,
                    duration_ms=duration_ms,
                    retry_count=retry_count,
                    interactive_failure=interactive_failure,
                    error_details=error_details,
                )

        duration_ms = int((time.time() - start_time) * 1000)
        _log_llm_call(
            config,
            LLMCallContext(
                prompt=prepared_prompt,
                response=response_text,
                start_time=start_time,
                span_id=span_id,
                status=status,
                error_message=error_message,
            ),
        )
        return LLMSubprocessResult(
            success=True,
            output=response_text,
            returncode=0,
            duration_ms=duration_ms,
            retry_count=retry_count,
        )

    # Streaming execution path
    # Get preexec_fn for Linux prctl (orphan prevention)
    streaming_preexec_fn = get_prctl_death_signal_fn()
    stream_idle_timeout_s = config.stream_idle_timeout_s
    if stream_idle_timeout_s is None:
        stream_idle_timeout_s = get_llm_stream_idle_timeout()
    if stream_idle_timeout_s is not None and stream_idle_timeout_s <= 0:
        stream_idle_timeout_s = None

    def _run_streaming() -> tuple[int, str, str, InteractiveMatch | None]:
        """Execute subprocess with streaming output.

        Returns:
            Tuple of (returncode, stdout, stderr, interactive_match)

        Raises:
            RuntimeError: On retryable errors (triggers retry)
        """
        proc = subprocess.Popen(
            cmd,
            cwd=config.cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            env=subprocess_env,
            preexec_fn=streaming_preexec_fn,
        )

        # Emit streaming started event (FEAT-LLM-LOG-VIEWER-001)
        if config.log_event:
            config.log_event(
                "llm_streaming_started",
                provider=config.provider,
                model=config.model,
                call_site=config.call_site,
                trace_id=config.trace_id,
            )

        # Register PID with ProcessRegistry for lifecycle tracking
        if config.process_registry:
            config.process_registry.register(proc.pid, f"{config.provider}-cli")

        # Initialize MonitoringThread if context provided (ISSUE-CLI-016/CLI-017 fix)
        monitor: Any | None = None
        if config.monitoring_context and MONITORING_AVAILABLE:
            try:
                ctx = config.monitoring_context
                mon_config = ctx.get("config")
                workspace_path = ctx.get("workspace_path")
                production_logger = ctx.get("production_logger")
                session_id = ctx.get("session_id")

                # Support both dict configs (hybrid orchestrator) and object configs (legacy)
                if isinstance(mon_config, dict):
                    monitoring_enabled = (
                        mon_config
                        and "orchestration" in mon_config
                        and "monitoring" in mon_config["orchestration"]
                        and mon_config["orchestration"]["monitoring"].get("enabled", False)
                    )
                else:
                    monitoring_enabled = (
                        mon_config
                        and hasattr(mon_config, "orchestration")
                        and hasattr(mon_config.orchestration, "monitoring")
                        and mon_config.orchestration.monitoring.enabled
                    )

                if monitoring_enabled and workspace_path and production_logger and session_id:
                    assert mon_config is not None
                    monitor = MonitoringThread(
                        process=proc,
                        config=cast(dict, mon_config),
                        workspace_path=Path(workspace_path),
                        production_logger=production_logger,
                        session_id=session_id,
                        state_manager=None,
                        task_id=None,
                        base_timeout=config.timeout_s,
                    )
                    monitor.start()
                    logger.info(
                        f"Monitoring thread started for streaming LLM call: PID={proc.pid}, "
                        f"provider={config.provider}, timeout={config.timeout_s}s"
                    )
            except Exception as e:
                logger.error(f"Failed to start monitoring thread: {e}", exc_info=True)
                monitor = None

        activity_lock = threading.Lock()
        last_activity_time = time.time()

        def note_activity() -> None:
            nonlocal last_activity_time
            with activity_lock:
                last_activity_time = time.time()

        # Start stderr reader thread to prevent pipe buffer deadlock (ISSUE-DOBRA-009)
        stderr_chunks: list[str] = []
        interactive_match: InteractiveMatch | None = None
        interactive_lock = threading.Lock()

        def record_interactive(match: InteractiveMatch) -> None:
            nonlocal interactive_match
            with interactive_lock:
                if interactive_match is None:
                    interactive_match = match
                    with contextlib.suppress(Exception):
                        proc.kill()

        def stderr_reader() -> None:
            """Read stderr in background thread to prevent buffer deadlock."""
            try:
                if proc.stderr:
                    for line in proc.stderr:
                        note_activity()
                        if interactive_guard:
                            match = interactive_guard.scan_line(line, "stderr")
                            if match:
                                stderr_chunks.append(line)
                                record_interactive(match)
                                break
                        stderr_chunks.append(line)
            except (ValueError, OSError):
                pass  # Stream closed, process terminated

        stderr_thread = threading.Thread(target=stderr_reader, daemon=True)
        stderr_thread.start()

        # Stream stdout with callback (ISSUE-HYBRID-012: timeout-aware streaming)
        assert proc.stdout is not None
        chunks: list[str] = []
        stdout_error: Exception | None = None
        stdout_complete = threading.Event()

        def stdout_reader() -> None:
            """Read stdout in background thread with line-by-line streaming."""
            nonlocal stdout_error
            if proc.stdout is None:
                return
            try:
                for line in proc.stdout:
                    note_activity()
                    if interactive_guard:
                        match = interactive_guard.scan_line(line, "stdout")
                        if match:
                            chunks.append(line)
                            record_interactive(match)
                            break
                    chunks.append(line)
                    # FIX-STREAMING-001: Filter status lines from streaming output
                    if config.on_stream and not _should_filter_streaming_line(line):
                        config.on_stream(line)
            except Exception as e:
                stdout_error = e
            finally:
                stdout_complete.set()

        # Start stdout reader thread
        stdout_thread = threading.Thread(target=stdout_reader, daemon=True)
        stdout_thread.start()

        # Wait for stdout reading to complete OR timeout
        # ISSUE-HYBRID-012 FIX: This ensures timeout is checked even if no output is produced
        try:
            # Load subprocess runner timeouts from config
            subprocess_timeouts = get_subprocess_runner_timeouts()
            poll_interval = subprocess_timeouts["poll_interval_s"]
            process_wait_timeout = subprocess_timeouts["process_wait_s"]
            error_cleanup_timeout = subprocess_timeouts["error_cleanup_s"]
            overall_deadline = time.time() + config.timeout_s
            while not stdout_complete.wait(timeout=poll_interval):
                now = time.time()
                if now >= overall_deadline:
                    # Timeout occurred - kill process
                    proc.kill()
                    proc.wait(timeout=process_wait_timeout)  # Give it time to die gracefully
                    msg = f"LLM CLI timed out after {config.timeout_s}s"
                    raise RuntimeError(msg)
                if stream_idle_timeout_s is not None:
                    with activity_lock:
                        elapsed_idle = now - last_activity_time
                    if elapsed_idle >= stream_idle_timeout_s:
                        proc.kill()
                        proc.wait(timeout=process_wait_timeout)
                        print_info_fn: Callable[[str], None] | None = None
                        try:
                            from obra.display import print_info

                            print_info_fn = print_info
                        except Exception:
                            pass
                        if print_info_fn is not None:
                            print_info_fn(
                                "Streaming output idle for "
                                f"{stream_idle_timeout_s}s; terminating and retrying..."
                            )
                        if config.log_event:
                            config.log_event(
                                "llm_stream_idle_timeout",
                                provider=config.provider,
                                model=config.model,
                                call_site=config.call_site,
                                idle_timeout_s=stream_idle_timeout_s,
                                elapsed_s=elapsed_idle,
                                trace_id=config.trace_id,
                            )
                        msg = f"LLM CLI stream idle timeout after {stream_idle_timeout_s}s"
                        raise RuntimeError(msg)

            # Check if stdout reader encountered error
            if stdout_error:
                raise stdout_error

            # Wait for process to finish (should be quick if stdout closed)
            proc.wait(timeout=process_wait_timeout)
        except subprocess.TimeoutExpired as exc:
            proc.kill()
            msg = f"LLM CLI timed out after {config.timeout_s}s"
            raise RuntimeError(msg) from exc
        finally:
            # FIX-ZOMBIE-001: Ensure process is reaped to prevent zombie processes
            # This is critical - without wait(), child processes become zombies when
            # exceptions occur (stdout_error, TimeoutExpired, interactive guard kill)
            with contextlib.suppress(Exception):
                proc.wait(timeout=error_cleanup_timeout)

            # Unregister PID from ProcessRegistry
            if config.process_registry:
                config.process_registry.unregister(proc.pid)
            # Stop monitoring thread if started
            if monitor:
                try:
                    monitor.stop(timeout=LLM_MONITOR_STOP_TIMEOUT_S)
                except Exception as e:
                    logger.warning(f"Error stopping monitoring thread: {e}")

            # Wait for stderr reader thread to finish
            stderr_thread.join(timeout=LLM_STDERR_JOIN_TIMEOUT_S)

        returncode = proc.returncode or 0
        stdout_text = "".join(chunks)
        stderr_text = "".join(stderr_chunks)

        if interactive_match:
            return 1, stdout_text, stderr_text, interactive_match

        if returncode != 0:
            error_details = _extract_cli_error_details(stderr_text, stdout_text, config.provider)
            msg = _format_error_message(error_details)
            raise RuntimeError(msg)

        return returncode, stdout_text, stderr_text, None

    try:
        # Execute with retry support
        if config.retry_enabled:
            cfg = config.retry_config or _get_default_retry_config()
            on_retry = _make_retry_callback(config.provider, cfg)
            result = with_retry(
                _run_streaming,
                config=cfg,
                operation_name=f"{config.provider}_invoke_streaming_{config.model}",
                on_retry=on_retry,
            )
            retry_count = result.attempts - 1

            if result.success:
                returncode, response_text, stderr_text, interactive_match = result.value
            else:
                # All retries exhausted
                error_details = _extract_cli_error_details(
                    str(result.last_error) if result.last_error else "",
                    "",
                    config.provider,
                )
                error_msg = _format_error_message(error_details)
                status = "error"
                error_message = error_msg
                duration_ms = int((time.time() - start_time) * 1000)
                _log_llm_call(
                    config,
                    LLMCallContext(
                        prompt=prepared_prompt,
                        response="",
                        start_time=start_time,
                        span_id=span_id,
                        status=status,
                        error_message=error_message,
                    ),
                )
                return LLMSubprocessResult(
                    success=False,
                    output="",
                    error=error_message,
                    returncode=1,
                    duration_ms=duration_ms,
                    retry_count=retry_count,
                    error_details=error_details,
                )
        else:
            returncode, response_text, stderr_text, interactive_match = _run_streaming()

        if interactive_match:
            interactive_failure = InteractiveGuardFailure.from_match(interactive_match)
            error_message = _interactive_guard_error(interactive_match)
            status = "error"
            duration_ms = int((time.time() - start_time) * 1000)
            error_details = _extract_cli_error_details(
                error_message,
                "",
                config.provider,
            )
            _log_llm_call(
                config,
                LLMCallContext(
                    prompt=prepared_prompt,
                    response=response_text,
                    start_time=start_time,
                    span_id=span_id,
                    status=status,
                    error_message=error_message,
                ),
            )
            return LLMSubprocessResult(
                success=False,
                output=response_text,
                error=error_message,
                returncode=1,
                duration_ms=duration_ms,
                retry_count=retry_count,
                interactive_failure=interactive_failure,
                error_details=error_details,
            )

        # Check for errors
        if returncode != 0:
            # Exit code 130 = SIGINT (Ctrl+C) - Unix signal protocol constant
            if returncode == 130:
                msg = "LLM process cancelled by user"
                raise KeyboardInterrupt(msg)
            status = "error"
            error_details = _extract_cli_error_details(stderr_text, response_text, config.provider)
            error_message = _format_error_message(error_details)
            duration_ms = int((time.time() - start_time) * 1000)
            _log_llm_call(
                config,
                LLMCallContext(
                    prompt=prepared_prompt,
                    response=response_text,
                    start_time=start_time,
                    span_id=span_id,
                    status=status,
                    error_message=error_message,
                ),
            )
            return LLMSubprocessResult(
                success=False,
                output=response_text,
                error=error_message,
                returncode=returncode,
                duration_ms=duration_ms,
                retry_count=retry_count,
                error_details=error_details,
            )

    except Exception as exc:
        status = "error"
        error_message = str(exc)
        duration_ms = int((time.time() - start_time) * 1000)
        error_details = _extract_cli_error_details(error_message, "", config.provider)
        _log_llm_call(
            config,
            LLMCallContext(
                prompt=prepared_prompt,
                response="",
                start_time=start_time,
                span_id=span_id,
                status=status,
                error_message=error_message,
            ),
        )
        return LLMSubprocessResult(
            success=False,
            output="",
            error=error_message,
            returncode=1,
            duration_ms=duration_ms,
            retry_count=retry_count,
            error_details=error_details,
        )
    finally:
        # Display token usage
        if response_text and status == "success":
            _display_token_usage(config.provider, prepared_prompt, response_text)

        # Cleanup Claude Code CLI temp files
        if config.provider == "anthropic":
            _cleanup_claude_temp_files(config.cwd)

        prompt_manager.cleanup(prompt_path)

    duration_ms = int((time.time() - start_time) * 1000)
    _log_llm_call(
        config,
        LLMCallContext(
            prompt=prepared_prompt,
            response=response_text,
            start_time=start_time,
            span_id=span_id,
            status=status,
            error_message=error_message,
        ),
    )
    return LLMSubprocessResult(
        success=True,
        output=response_text,
        returncode=0,
        duration_ms=duration_ms,
        retry_count=retry_count,
    )


# TODO: Will enable provider-specific token counting (e.g., different tokenizers
# for Claude vs GPT, provider-specific cost calculations)
def _display_token_usage(_provider: str, prompt: str, response: str) -> None:
    """Display token usage to user.

    Args:
        provider: LLM provider
        prompt: Input prompt text
        response: Output response text
    """
    from obra.display import print_info
    from obra.display.observability import VerbosityLevel, get_runtime_verbosity
    from obra.hybrid.json_utils import extract_usage_from_cli_response

    # Try to extract actual token counts from CLI response
    usage = extract_usage_from_cli_response(response)

    # Estimate tokens from character count (4 chars per token is reasonable)
    estimated_input = len(prompt) // 4
    estimated_output = len(response) // 4

    # CLI sometimes reports only the literal message tokens, not the full prompt.
    # If CLI input_tokens is suspiciously low (<10% of estimated), use estimation.
    # 100 tokens = small prompt threshold where 10% rule doesn't apply - heuristic constant
    cli_input_seems_valid = usage["input_tokens"] > 0 and (
        estimated_input < 100 or usage["input_tokens"] >= estimated_input * 0.1
    )

    if cli_input_seems_valid and usage["output_tokens"] > 0:
        # Use CLI token counts (they look reasonable)
        input_tokens = usage["input_tokens"]
        output_tokens = usage["output_tokens"]
        total_tokens = input_tokens + output_tokens
        source = "CLI"
    else:
        # Fall back to character-based estimation
        input_tokens = estimated_input
        output_tokens = estimated_output
        total_tokens = input_tokens + output_tokens
        source = "estimated"

    if get_runtime_verbosity() < VerbosityLevel.DETAIL:
        return
    print_info(
        f"Tokens: {total_tokens:,} (in: {input_tokens:,}, out: {output_tokens:,}) [{source}]"
    )


def _cleanup_claude_temp_files(cwd: Path) -> None:
    """Cleanup Claude Code CLI temp files.

    Claude Code CLI creates temp files that aren't cleaned up:
    - tmpclaude-*-cwd: Created to track cwd but not cleaned up
    - nul: Windows NUL device written as literal file (Claude Code bug)

    Args:
        cwd: Working directory to clean
    """
    for tmp_file in cwd.glob("tmpclaude-*-cwd"):
        with contextlib.suppress(OSError):
            tmp_file.unlink()
    nul_file = cwd / "nul"
    if nul_file.exists() and nul_file.is_file():
        with contextlib.suppress(OSError):
            nul_file.unlink()


def _log_llm_call(
    config: LLMSubprocessConfig,
    ctx: LLMCallContext,
) -> None:
    """Emit a best-effort LLM call timing event.

    Args:
        config: LLMSubprocessConfig with log_event callback
        ctx: LLMCallContext with execution-specific parameters
    """
    if not config.log_event:
        return

    duration_ms = int((time.time() - ctx.start_time) * 1000)
    prompt_text = ctx.prompt or ""
    response_text = ctx.response or ""
    prompt_chars = len(prompt_text)
    response_chars = len(response_text)
    prompt_bytes = len(prompt_text.encode("utf-8"))
    response_bytes = len(response_text.encode("utf-8"))
    prompt_tokens = prompt_chars // 4
    response_tokens = response_chars // 4
    tokens_per_second = None
    if duration_ms > 0:
        tokens_per_second = (prompt_tokens + response_tokens) / (duration_ms / 1000)

    # Compute prompt/response previews if enabled (FEAT-LLM-LOG-VIEWER-001)
    prompt_preview = None
    response_preview = None
    if get_llm_logging_preview_enabled():
        max_prompt_chars = get_llm_logging_preview_max_prompt_chars()
        max_response_chars = get_llm_logging_preview_max_response_chars()
        prompt_preview = prompt_text[:max_prompt_chars]
        response_preview = response_text[:max_response_chars]

    # Include prompt file path if available (FEAT-LLM-LOG-VIEWER-001)
    prompt_file_path = None
    if hasattr(config, "prompt_path") and config.prompt_path is not None:
        prompt_path = Path(config.prompt_path)
        if prompt_path.exists():
            prompt_file_path = str(prompt_path)

    config.log_event(
        "llm_call",
        provider=config.provider,
        model=config.model,
        thinking_level=config.thinking_level,
        duration_ms=duration_ms,
        prompt_chars=prompt_chars,
        response_chars=response_chars,
        prompt_bytes=prompt_bytes,
        response_bytes=response_bytes,
        prompt_tokens=prompt_tokens,
        response_tokens=response_tokens,
        total_tokens=prompt_tokens + response_tokens,
        tokens_per_second=tokens_per_second,
        status=ctx.status,
        error_message=ctx.error_message,
        trace_id=config.trace_id,
        span_id=ctx.span_id,
        parent_span_id=config.parent_span_id,
        call_site=config.call_site,
        token_estimate_source="chars_per_token",
        prompt_preview=prompt_preview,
        response_preview=response_preview,
        prompt_file_path=prompt_file_path,
        run_id=config.run_id,
    )


__all__ = [
    "LLMCallContext",
    "LLMErrorDetails",
    "LLMSubprocessConfig",
    "LLMSubprocessResult",
    "run_llm_subprocess",
]
