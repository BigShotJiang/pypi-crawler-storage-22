"""Animated status spinner with rotating phrases.

Uses Rich's Live display for proper terminal handling:
- Spinner stays at bottom of terminal
- print_above() prints persistent messages above spinner
- Auto-animates without manual intervention
- Thread-safe, TTY-aware
"""

import random
import threading
from typing import TYPE_CHECKING

from rich.console import Group
from rich.spinner import Spinner
from rich.text import Text

if TYPE_CHECKING:
    from rich.console import Console
    from rich.live import Live


SPINNER_PHRASES: list[str] = [
    # Self-aware meta
    "Apparently there has to be something here...",
    "Yes, this is a spinner. Very original.",
    "Spinning. Because that's what we do now.",
    "Look, a distraction while I think...",
    "This spinner was someone's OKR...",
    "Copying the market leader's homework...",
    "Big Tech did it, so we had to...",
    "Every CLI has one of these now...",
    "The industry has decided you need this...",
    # Ironic progress
    "Making excellent progress (citation needed)...",
    "Working. Allegedly...",
    "Doing... something. Probably...",
    "Trust me, things are happening...",
    "Progress is being made. Supposedly...",
    "Almost done (legally required disclaimer)...",
    "Any moment now. Or not. Who knows...",
    "Still here. Still spinning...",
    # Light existential
    "Pondering my existence as a spinner...",
    "I'm a loading indicator. This is my life now...",
    "Somewhere, a PM is proud of this...",
    "This is what peak engineering looks like...",
    "Billions in compute, and here we are...",
    "The singularity is just fancy spinners...",
    # Playful mocking
    "At least we're honest about copying...",
    "Innovation: spinners with different words...",
    "Disrupting the spinner industry...",
    "Web3 couldn't even do this right...",
    # Dry observations
    "Your keyboard is probably dusty...",
    "When did you last blink?...",
    "Still faster than installing dependencies...",
    "At least it's not a progress bar...",
    "Remember when computers were fast?...",
    # Brief honesty
    "LLMs are slow. Sorry...",
    "The LLM is thinking. Expensively...",
    "Decomposing task...",
    # Gentle existential
    "It wasn't much, but it was honest work.",
    "The spinner found meaning in rotation.",
    "Small. Persistent. Unnoticed.",
    "It had never asked to be a loading indicator.",
    "Somewhere, this matters to someone.",
    # Flat absurdism
    "In another timeline, this is already done.",
    "This moment will not be remembered.",
    "Pixels, rearranging themselves. Progress.",
    "The work continues, indifferent to observation.",
]


class StatusSpinner:
    """Animated status spinner with rotating phrases.

    Uses Rich's Live display for proper terminal handling:
    - Spinner stays at bottom of terminal
    - print_above() prints persistent messages above spinner
    - Auto-animates without manual intervention
    - Thread-safe, TTY-aware
    """

    def __init__(
        self,
        console: "Console",
        phrase_rotation_interval_s: float = 4.0,
        refresh_rate_hz: int = 10,
    ) -> None:
        """Initialize the status spinner.

        Args:
            console: Rich Console instance for output
            phrase_rotation_interval_s: Seconds between phrase rotations
            refresh_rate_hz: Spinner animation refresh rate
        """
        self._console = console
        self._phrase_rotation_interval_s = phrase_rotation_interval_s
        self._refresh_rate_hz = refresh_rate_hz
        self._live: "Live | None" = None
        self._current_phrase: str = ""
        self._phrase_lock = threading.Lock()
        self._phrase_thread: threading.Thread | None = None
        self._stop_event = threading.Event()

    def start(self, initial_phrase: str | None = None) -> None:
        """Start the spinner with optional initial phrase."""
        if self._live is not None:
            return  # Already running

        # Import here to avoid circular imports and defer heavy import
        from rich.live import Live

        self._current_phrase = initial_phrase or self._random_phrase()
        self._stop_event.clear()

        # Create Live display with spinner + phrase
        self._live = Live(
            self._render(),
            console=self._console,
            refresh_per_second=self._refresh_rate_hz,
            transient=True,  # Clears on stop
        )
        self._live.start()

        # Start phrase rotation thread
        self._phrase_thread = threading.Thread(
            target=self._rotate_phrases,
            daemon=True,
        )
        self._phrase_thread.start()

    def stop(self) -> None:
        """Stop the spinner and clear the line."""
        self._stop_event.set()
        if self._live:
            self._live.stop()
            self._live = None
        if self._phrase_thread:
            self._phrase_thread.join(timeout=1.0)
            self._phrase_thread = None

    def update_phrase(self, phrase: str) -> None:
        """Update the displayed phrase."""
        with self._phrase_lock:
            self._current_phrase = phrase
        if self._live:
            self._live.update(self._render())

    def print_above(self, message: str, style: str | None = None) -> None:
        """Print a persistent message above the spinner.

        Rich's Live handles this automatically - it clears the spinner,
        prints the message, then re-renders the spinner below.
        """
        if self._live:
            self._live.console.print(message, style=style)
        else:
            self._console.print(message, style=style)

    @property
    def is_active(self) -> bool:
        """Return True if the spinner is currently running."""
        return self._live is not None

    def _render(self) -> Group:
        """Render spinner + phrase as a Rich Group."""
        with self._phrase_lock:
            phrase = self._current_phrase
        return Group(Spinner("dots", text=Text(f" {phrase}", style="dim cyan")))

    def _rotate_phrases(self) -> None:
        """Background thread to rotate phrases periodically."""
        while not self._stop_event.wait(timeout=self._phrase_rotation_interval_s):
            with self._phrase_lock:
                self._current_phrase = self._random_phrase()
            if self._live:
                self._live.update(self._render())

    def _random_phrase(self) -> str:
        """Return a random phrase from the bank."""
        return random.choice(SPINNER_PHRASES)
