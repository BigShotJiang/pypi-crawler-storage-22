"""Intent stage handler for Hybrid Orchestrator.

This module handles the INTENT action from the server. It generates an intent,
optionally enriches it, and returns a structured payload for server-side
SenseCheck validation prior to derivation.
"""

from __future__ import annotations

import logging
import sys
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.api.protocol import IntentRequest
from obra.config.loaders import load_layered_config
from obra.hybrid.derivation.sizing_gate import SizingGate
from obra.hybrid.handlers.intent import IntentHandler
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.intent.detection import detect_input_type
from obra.intent.intent_enricher import IntentEnricher
from obra.intent.storage import IntentStorage

logger = logging.getLogger(__name__)


class IntentStageHandler:  # pylint: disable=too-few-public-methods
    """Handle INTENT action requests."""

    def __init__(
        self,
        working_dir: Path,
        *,
        on_stream: Callable[[str, str], None] | None = None,
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        llm_config: dict[str, Any] | None = None,
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        monitoring_context: dict[str, Any] | None = None,
        production_logger: Any | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._on_stream = on_stream
        self._on_progress = on_progress
        self._llm_config = llm_config or {}
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._monitoring_context = monitoring_context
        self._production_logger = production_logger
        self._config, _, _ = load_layered_config(include_defaults=True)

    def _run_async(self, coroutine: Any) -> Any:
        import asyncio

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        if loop.is_running():
            new_loop = asyncio.new_event_loop()
            try:
                return new_loop.run_until_complete(coroutine)
            finally:
                new_loop.close()

        return loop.run_until_complete(coroutine)

    def _build_sizing_pipeline(self, action_name: str) -> TemplateEditPipeline:
        return TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name=action_name,
            on_stream=None,
            log_event=self._log_event,
            production_logger=self._production_logger,
        )

    def handle(self, request: IntentRequest) -> dict[str, Any]:
        """Generate, enrich, and report intent for SenseCheck validation."""
        input_type = detect_input_type(request.objective)
        logger.info("Intent stage input type: %s", input_type.value)

        intent_handler = IntentHandler(
            self._working_dir,
            on_stream=self._on_stream,
            on_progress=self._on_progress,
            llm_config=self._llm_config,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
            monitoring_context=self._monitoring_context,
            production_logger=self._production_logger,
        )
        intent = intent_handler.generate(
            request.objective,
            input_type=input_type,
            base_prompt=request.base_prompt,
            userplan_id=request.userplan_id,
            userplan_version=request.userplan_version,
        )

        storage = IntentStorage()
        intent_path = storage.save(intent)
        logger.info("Saved intent to %s", intent_path)

        sizing_guidance = None
        sizing_enabled = bool(
            self._config.get("derivation", {}).get("sizing", {}).get("enabled", False)
        )
        if sizing_enabled:
            try:
                sizing_pipeline = self._build_sizing_pipeline("sizing_gate")
                sizing_guidance = self._run_async(
                    SizingGate(self._config).assess(intent, sizing_pipeline)
                )
            except Exception as exc:
                logger.warning("Sizing gate failed in intent stage: %s", exc)

        enricher = IntentEnricher(
            self._working_dir,
            llm_config=self._llm_config,
            on_stream=self._on_stream,
            on_progress=self._on_progress,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
        )

        diff_path = None
        if enricher.should_run(input_type):
            skip_analogues = sizing_guidance.skip_analogues if sizing_guidance else False
            skip_brief = sizing_guidance.skip_brief if sizing_guidance else False
            intent, diff_path = enricher.run(
                request.objective,
                intent,
                interactive=sys.stdin.isatty(),
                skip_analogues=skip_analogues,
                skip_brief=skip_brief,
            )

        return {
            "intent": {
                "id": intent.id,
                "problem_statement": intent.problem_statement,
                "assumptions": intent.assumptions,
                "requirements": intent.requirements,
                "acceptance_criteria": intent.acceptance_criteria,
                "non_goals": intent.non_goals,
                "constraints": intent.constraints,
            },
            "intent_enrichment": {
                "enrichment_level": intent.enrichment_level.value,
                "diff_path": str(diff_path) if diff_path else None,
            },
        }


__all__ = ["IntentStageHandler"]
