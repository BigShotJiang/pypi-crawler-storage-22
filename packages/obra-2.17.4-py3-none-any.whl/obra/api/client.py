"""API client for Obra Firebase Cloud Functions with retry logic and error handling.

Provides HTTP client wrapper for communicating with Cloud Functions endpoints,
implementing retry logic, timeout handling, and optional compression.
"""

import logging
import secrets
import time
from datetime import UTC, datetime, timedelta
from http import HTTPStatus
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any, cast
from urllib.parse import urljoin

import requests  # type: ignore[import-untyped]
import yaml  # type: ignore[import-untyped]
from pydantic import BaseModel, ValidationError
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from obra.config import CONFIG_PATH, FIREBASE_API_KEY
from obra.config.loaders import (
    get_api_base_url,
    get_api_client_config,
    get_api_connection_pool_config,
    get_api_retry_delays,
)
from obra.constants import (
    API_DEFAULT_TIMEOUT_S,
    API_EVENTS_DEFAULT_LIMIT,
    API_LIMIT_MAX,
    API_MAX_RETRIES,
    API_PLANS_DEFAULT_LIMIT,
    API_SESSIONS_DEFAULT_LIMIT,
    API_TOKEN_REFRESH_THRESHOLD_MINUTES,
    API_USER_FEEDBACK_DEFAULT_LIMIT,
)
from obra.exceptions import (
    APIError,
    ConfigurationError,
    ErrorContext,
    TermsNotAcceptedError,
)
from obra.messages import get_message

logger = logging.getLogger(__name__)


class APIClient:
    """HTTP client for Obra Cloud Functions API.

    Implements:
    - Automatic retry with exponential backoff
    - Timeout handling
    - Auth token management
    - Optional gzip compression for large payloads
    - Standardized error handling

    Example:
        client = APIClient(
            base_url="https://us-central1-obra-205b0.cloudfunctions.net",
            auth_token="your-firebase-token"
        )
        response = client.orchestrate(
            user_id="user123",
            project_id="proj456",
            working_dir="/home/user/project",
            objective="Add user authentication"
        )
    """

    DEFAULT_TIMEOUT = API_DEFAULT_TIMEOUT_S  # seconds
    MAX_RETRIES = API_MAX_RETRIES
    # Lazy-loaded from config to avoid circular imports
    RETRY_DELAYS: list[int] | None = None  # seconds (exponential backoff)
    TOKEN_REFRESH_THRESHOLD = timedelta(
        minutes=API_TOKEN_REFRESH_THRESHOLD_MINUTES
    )  # Refresh if <5 minutes until expiration

    # Firebase Token Refresh API endpoint
    FIREBASE_TOKEN_URL = "https://securetoken.googleapis.com/v1/token"

    @staticmethod
    def _get_client_version() -> str:
        """Get the installed obra package version.

        Returns:
            Version string from package metadata, or "0.0.0-dev" if not installed.
        """
        try:
            return version("obra")
        except PackageNotFoundError:
            return "0.0.0-dev"

    # TRY301: Helper methods to raise API errors outside try blocks
    @staticmethod
    def _raise_invalid_response(status_code: int, response_data: Any) -> None:
        """Raise APIError for invalid response format."""
        raise APIError(
            message="Expected JSON object in response",
            status_code=status_code,
            response_body=str(response_data),
        )

    @staticmethod
    def _raise_terms_not_accepted(error_json: dict[str, Any]) -> None:
        """Raise TermsNotAcceptedError for terms acceptance requirement."""
        raise TermsNotAcceptedError(
            message=error_json.get(
                "message",
                "You must accept the Obra Beta Software Agreement.",
            ),
            required_version=error_json.get("required_version", ""),
            terms_url=error_json.get("terms_url", "https://obra.dev/terms"),
            action=error_json.get("action", get_message("recovery.auth.terms")),
        )

    @staticmethod
    def _raise_validation_error(detailed_message: str, error_body: str) -> None:
        """Raise APIError for validation failures (400)."""
        raise APIError(
            message=detailed_message,
            status_code=HTTPStatus.BAD_REQUEST.value,
            response_body=error_body,
        )

    @staticmethod
    def _raise_auth_expired(error_body: str) -> None:
        """Raise APIError for expired authentication."""
        raise APIError(
            message=f"Authentication token expired. {get_message('recovery.auth.login')}",
            status_code=HTTPStatus.UNAUTHORIZED.value,
            response_body=error_body,
        )

    @staticmethod
    def _raise_api_error(
        status_code: int,
        error_message: str,
        error_body: str,
        error_context: ErrorContext | None = None,
    ) -> None:
        """Raise generic APIError for non-retryable client errors."""
        raise APIError(
            message=f"API error {status_code}: {error_message}",
            status_code=status_code,
            response_body=error_body,
            error_context=error_context,
        )

    @staticmethod
    def _extract_server_context(
        error_json: dict[str, Any], response_headers: dict[str, str] | None = None
    ) -> ErrorContext | None:
        """Extract server context from error response.

        CHORE-SERVER-ERROR-CONTEXT-001: Parse server-provided investigation context.

        Args:
            error_json: Parsed error response JSON
            response_headers: Response headers from server

        Returns:
            ErrorContext populated from server data, or None if no context
        """
        server_ctx = error_json.get("context", {})
        if not server_ctx and not response_headers:
            return None

        # Extract from headers if available
        request_id = None
        server_trace_id = None
        if response_headers:
            request_id = response_headers.get("X-Obra-Request-Id")
            server_trace_id = response_headers.get("X-Obra-Server-Trace-Id")

        # Override with context body values if present
        if server_ctx:
            request_id = server_ctx.get("request_id", request_id)
            server_trace_id = server_ctx.get("server_trace_id", server_trace_id)

        # Build ErrorContext
        return ErrorContext(
            session_id=server_ctx.get("session_id"),
            request_id=request_id,
            server_trace_id=server_trace_id,
            phase=server_ctx.get("session_phase"),
            error_classification=server_ctx.get("error_classification"),
            recovery_suggestion=server_ctx.get("recovery_suggestion"),
            recent_activity=server_ctx.get("recent_activity"),
        )

    def __init__(
        self,
        base_url: str,
        auth_token: str | None = None,
        refresh_token: str | None = None,
        firebase_api_key: str | None = None,
        timeout: int = DEFAULT_TIMEOUT,
        enable_compression: bool = True,
        auto_refresh: bool = True,
        pool_retries: bool = True,
    ) -> None:
        """Initialize APIClient.

        Args:
            base_url: Base URL for Cloud Functions (e.g., https://us-central1-obra-205b0.cloudfunctions.net)
            auth_token: Firebase ID token for authentication
            refresh_token: Firebase refresh token for token renewal
            firebase_api_key: Firebase Web API key (required for token refresh)
            timeout: Request timeout in seconds (default: 30)
            enable_compression: Enable gzip compression for requests >5KB
            auto_refresh: Automatically refresh token when close to expiration
            pool_retries: Enable connection pool retries for transient connect errors

        Raises:
            ConfigurationError: If base_url is invalid
        """
        if not base_url or not base_url.startswith("http"):
            msg = f"Invalid base_url: {base_url}"
            raise ConfigurationError(msg)

        # Ensure base_url ends with / for proper urljoin() behavior
        self.base_url = base_url.rstrip("/") + "/"
        self.auth_token = auth_token
        self.refresh_token = refresh_token
        self.firebase_api_key = firebase_api_key or FIREBASE_API_KEY
        self.timeout = timeout
        self.enable_compression = enable_compression
        self.auto_refresh = auto_refresh

        # Token expiration tracking
        self.token_expires_at: datetime | None = None

        # Trace context for end-to-end observability
        self.trace_id: str | None = None
        self.trace_span_id: str | None = None

        self.session = requests.Session()

        # ISSUE-HYBRID-001: Configure connection pool with explicit retry for CLOSE_WAIT handling
        # Default HTTPAdapter has Retry(total=0) which means connection failures are not retried
        # at the pool level. This causes hangs when server closes connections (CLOSE_WAIT state).
        # By enabling connection-level retries, the pool will attempt to reconnect on failure.
        pool_cfg = get_api_connection_pool_config()
        if pool_retries:
            retry_strategy = Retry(
                total=int(pool_cfg["retry_total"]),
                connect=int(pool_cfg["retry_connect"]),
                read=0,  # Don't retry on read errors (handled by application-level retry)
                backoff_factor=pool_cfg["retry_backoff"],
                status_forcelist=None,  # Don't retry on HTTP status codes (handled by _request)
                allowed_methods=frozenset(["GET", "POST", "PUT", "PATCH", "DELETE"]),
            )
        else:
            retry_strategy = Retry(
                total=0,
                connect=0,
                read=0,
                backoff_factor=0,
                status_forcelist=None,
                allowed_methods=frozenset(["GET", "POST", "PUT", "PATCH", "DELETE"]),
            )
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=int(pool_cfg["connections"]),
            pool_maxsize=int(pool_cfg["maxsize"]),
        )
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)

        # Get client version for headers
        client_version = self._get_client_version()

        # Set default headers
        self.session.headers.update(
            {
                "Content-Type": "application/json",
                "User-Agent": f"obra/{client_version}",
                "X-Obra-Client-Version": client_version,
            }
        )

    def set_trace_context(self, trace_id: str, span_id: str | None = None) -> None:
        """Set trace context headers for end-to-end observability.

        Args:
            trace_id: Trace ID for correlating client/server events
            span_id: Optional span ID (if not provided, generated per request)
        """
        self.trace_id = trace_id
        self.trace_span_id = span_id

    def _build_trace_header(self) -> str | None:
        """Build X-Cloud-Trace-Context header value.

        Returns:
            Header value if trace_id is set, otherwise None
        """
        if not self.trace_id:
            return None
        span_id = self.trace_span_id or str(secrets.randbits(63))
        return f"{self.trace_id}/{span_id};o=1"

    def refresh_auth_token(self) -> bool:
        """Refresh authentication token using Firebase refresh token.

        Uses Firebase Auth REST API to exchange refresh token for new ID token.

        Returns:
            True if refresh succeeded, False otherwise

        Note:
            This is called automatically if auto_refresh is enabled and
            token is close to expiration.
        """
        if not self.refresh_token or not self.firebase_api_key:
            return False

        try:
            # Firebase Token Refresh API endpoint
            url = f"https://securetoken.googleapis.com/v1/token?key={self.firebase_api_key}"

            # Use requests.post directly instead of self.session.post to avoid
            # the session's Content-Type: application/json header conflicting
            # with form-encoded data that Firebase expects
            response = requests.post(
                url,
                data={
                    "grant_type": "refresh_token",
                    "refresh_token": self.refresh_token,
                },
                timeout=self.timeout,
            )

            if response.status_code == HTTPStatus.OK:
                data = response.json()
                new_id_token = data.get("id_token")
                new_refresh_token = data.get("refresh_token")

                if new_id_token:
                    self.set_auth_token(new_id_token)
                    if new_refresh_token:
                        self.refresh_token = new_refresh_token

                    # Firebase ID tokens expire in 1 hour
                    self.token_expires_at = datetime.now(UTC) + timedelta(hours=1)

                    # Save updated tokens to config
                    self._save_token_to_config(
                        new_id_token, self.token_expires_at, new_refresh_token
                    )
                    return True

            return False

        except Exception as e:
            logger.error(
                "Token refresh failed with exception: %s (type: %s)",
                str(e),
                type(e).__name__,
                exc_info=True,
            )
            return False

    def _check_token_expiration(self) -> None:
        """Check if token needs refresh and refresh if necessary.

        Called before authenticated requests if auto_refresh is enabled.
        """
        if not self.auto_refresh or not self.refresh_token:
            return

        if not self.token_expires_at:
            return

        # Check if token is close to expiration
        time_until_expiry = self.token_expires_at - datetime.now(UTC)

        if time_until_expiry < self.TOKEN_REFRESH_THRESHOLD:
            # Token is close to expiration, refresh it
            try:
                self.refresh_auth_token()
            except Exception:
                # Refresh failed, continue with existing token
                pass

    def _save_token_to_config(
        self,
        token: str,
        expires_at: datetime | None = None,
        refresh_token: str | None = None,
    ) -> None:
        """Save auth token to config file for persistence.

        Args:
            token: Firebase ID token
            expires_at: Token expiration datetime
            refresh_token: Firebase refresh token (optional)
        """
        config_path = CONFIG_PATH
        if not config_path.exists():
            config_path.parent.mkdir(parents=True, exist_ok=True)
            config_path.write_text("{}\n", encoding="utf-8")

        try:
            # Load existing config
            with config_path.open(encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}

            # Update token fields
            config["auth_token"] = token

            if expires_at:
                config["token_expires_at"] = expires_at.isoformat()

            if refresh_token:
                config["refresh_token"] = refresh_token

            # Save updated config
            with config_path.open("w", encoding="utf-8") as f:
                yaml.safe_dump(config, f, default_flow_style=False, sort_keys=False)

        except Exception as e:
            # Failed to save token, but continue (token is still in memory)
            logger.error(
                "Failed to save auth token to config file at %s: %s (type: %s)",
                config_path,
                str(e),
                type(e).__name__,
                exc_info=True,
            )
            return  # Exit early on I/O errors

        # Validate token save succeeded (after successful write)
        # TRY301: Validation checks outside try block, only wrap file I/O
        if not config_path.exists():
            msg = f"Token save validation failed: Config file does not exist after write at {config_path}"
            raise ConfigurationError(msg)

        # Verify token was actually written by reading back the file
        try:
            with config_path.open(encoding="utf-8") as f:
                saved_config = yaml.safe_load(f)
        except Exception as e:
            # Validation itself failed (e.g., can't read file after writing)
            msg = f"Token save validation failed: Unable to verify token was saved to {config_path}: {e}"
            raise ConfigurationError(msg) from e

        # Check token match outside try block (TRY301)
        if not saved_config or saved_config.get("auth_token") != token:
            msg = f"Token save validation failed: Token mismatch after write to {config_path}"
            raise ConfigurationError(msg)

    @classmethod
    def from_config(
        cls,
        config_path: Path | None = None,
        *,
        pool_retries: bool = True,
    ) -> "APIClient":
        """Create APIClient from configuration file.

        Args:
            config_path: Path to config file (default: ~/.obra/config-layers/01-user.yaml)
            pool_retries: Enable connection pool retries for transient connect errors

        Returns:
            Configured APIClient instance

        Raises:
            ConfigurationError: If config file doesn't exist or is invalid
        """
        if config_path is None:
            config_path = CONFIG_PATH

        if not config_path.exists():
            msg = (
                f"Configuration file not found: {config_path}\n{get_message('recovery.auth.login')}"
            )
            raise ConfigurationError(msg)

        try:
            with config_path.open(encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
        except Exception as e:
            msg = f"Failed to load config: {e}"
            raise ConfigurationError(msg) from e

        # Get API base URL with proper precedence:
        # 1. OBRA_API_BASE_URL env var (for local emulator/staging)
        # 2. api_base_url from config file
        # 3. Default production URL
        base_url = get_api_base_url()

        auth_token = config.get("auth_token")
        refresh_token = config.get("refresh_token")
        firebase_api_key = config.get("firebase_api_key") or FIREBASE_API_KEY

        # Check for authentication
        if not auth_token:
            msg = f"Not authenticated.\n{get_message('recovery.auth.login')}"
            raise ConfigurationError(msg)

        # Parse token expiration
        token_expires_at = None
        expires_at_str = config.get("token_expires_at")
        if expires_at_str:
            try:
                token_expires_at = datetime.fromisoformat(expires_at_str)
                # Ensure timezone-aware for comparison with datetime.now(timezone.utc)
                if token_expires_at.tzinfo is None:
                    token_expires_at = token_expires_at.replace(tzinfo=UTC)
            except Exception as e:
                logger.warning(
                    "Failed to parse token expiration date '%s': %s (type: %s)",
                    expires_at_str,
                    str(e),
                    type(e).__name__,
                )

        # Create client
        client = cls(
            base_url=base_url,
            auth_token=auth_token,
            refresh_token=refresh_token,
            firebase_api_key=firebase_api_key,
            auto_refresh=True,
            pool_retries=pool_retries,
        )

        client.token_expires_at = token_expires_at

        # Refresh token if expired (or close to expiration)
        if token_expires_at and token_expires_at < datetime.now(UTC):
            if refresh_token and firebase_api_key:
                if not client.refresh_auth_token():
                    msg = (
                        "Authentication token expired and refresh failed.\n"
                        f"{get_message('recovery.auth.login')}"
                    )
                    raise ConfigurationError(msg)
            else:
                msg = f"Authentication token expired.\n{get_message('recovery.auth.login')}"
                raise ConfigurationError(msg)

        return client

    def health_check(self) -> dict[str, Any]:
        """Check API health.

        Returns:
            Health status dictionary

        Raises:
            APIError: If health check fails
        """
        return self._request("GET", "health", skip_auth_check=True)

    def get_version(self) -> dict[str, Any]:
        """Get API version and client compatibility info.

        Returns:
            Version info dictionary with fields:
            - api_version: Server API version
            - min_client_version: Minimum compatible client version
            - features: List of enabled features

        Raises:
            APIError: If version check fails
        """
        return self._request("GET", "version", skip_auth_check=True)

    def orchestrate(
        self,
        user_id: str,
        project_id: str | None,
        working_dir: str | None,
        objective: str,
        task_type: str = "feature",
        requirements: list[str] | None = None,
        constraints: list[str] | None = None,
        validation_rules: list[str] | None = None,
    ) -> dict[str, Any]:
        """Start orchestration session.

        Args:
            user_id: User ID
            project_id: Project ID
            working_dir: Project working directory path
            objective: Task objective/goal
            task_type: Type of task (feature, bug_fix, refactor, etc.)
            requirements: List of requirements
            constraints: List of constraints
            validation_rules: List of validation rules

        Returns:
            Response dictionary with fields:
            - session_id: Session ID for subsequent calls
            - metadata: Additional metadata
            - status: Session status
            - iteration: Current iteration number
            Note: base_prompt is generated client-side; server no longer returns it.

        Raises:
            APIError: If orchestration request fails
        """
        normalized_project_id = self._normalize_project_id(project_id)
        payload = {
            "user_id": user_id,
            "project_id": normalized_project_id,
            "working_dir": working_dir,
            "objective": objective,
            "task_type": task_type,
            "requirements": requirements or [],
            "constraints": constraints or [],
            "validation_rules": validation_rules or [],
        }

        return self._request("POST", "orchestrate", json=payload)

    def llm_result(
        self,
        session_id: str,
        result: str,
        status: str = "success",
        validation_errors: list[str] | None = None,
    ) -> dict[str, Any]:
        """Submit LLM execution result.

        Args:
            session_id: Session ID from /orchestrate
            result: LLM output/result
            status: Result status (success, partial, failure)
            validation_errors: List of validation errors (if any)

        Returns:
            Response dictionary with fields:
            - action: Next action (continue, complete, error)
            - base_prompt: Next iteration prompt (if action="continue")
            - iteration: Current iteration number
            - feedback: Feedback from server (if any)
            - message: Completion message (if action="complete")

        Raises:
            APIError: If result submission fails
        """
        payload = {
            "session_id": session_id,
            "result": result,
            "status": status,
            "validation_errors": validation_errors or [],
        }

        return self._request("POST", "llm_result", json=payload)

    def get_status(self, session_id: str) -> dict[str, Any]:
        """Query session status.

        Args:
            session_id: Session ID to query

        Returns:
            Status dictionary with fields:
            - session_id: Session ID
            - status: Current status (active, completed, expired, failed)
            - current_iteration: Current iteration number
            - objective: Task objective
            - task_type: Task type

        Raises:
            APIError: If status query fails
        """
        return self._request("GET", f"get_status?session_id={session_id}")

    def _expand_session_id(self, session_id: str) -> str:
        """Expand a short session ID to full UUID.

        Supports Git-style short IDs for better UX. If the provided ID is already
        a full UUID (36 chars with 4 dashes), returns it unchanged. Otherwise,
        queries recent sessions and finds the first match by prefix.

        Args:
            session_id: Full UUID or short ID prefix (e.g., "54439c55")

        Returns:
            Full UUID string

        Raises:
            APIError: If session not found (404) or ID is ambiguous (400)
        """
        # Check if it's already a full UUID (36 chars, 4 dashes)
        if len(session_id) == 36 and session_id.count("-") == 4:
            return session_id

        # Treat as short ID - query sessions and find match
        sessions = self.list_sessions(limit=API_PLANS_DEFAULT_LIMIT)
        matches = [s for s in sessions if s.get("session_id", "").startswith(session_id)]

        if len(matches) == 0:
            raise APIError(
                message="Session not found",
                status_code=HTTPStatus.NOT_FOUND.value,
                response_body=f"No session found matching ID prefix '{session_id}'",
            )

        if len(matches) > 1:
            # Multiple matches - require more specific ID
            match_ids = [s["session_id"][:16] + "..." for s in matches[:3]]
            raise APIError(
                message=f"Ambiguous session ID '{session_id}' matches {len(matches)} sessions",
                status_code=HTTPStatus.BAD_REQUEST.value,
                response_body=f"Matches: {', '.join(match_ids)}. Please provide more characters.",
            )

        # Exactly one match found
        session_id_value = matches[0].get("session_id")
        if not isinstance(session_id_value, str):
            raise APIError(
                message="Session ID missing or invalid in API response",
                status_code=HTTPStatus.INTERNAL_SERVER_ERROR.value,
                response_body=str(matches[0]),
            )

        return session_id_value

    def _normalize_project_id(self, project_id: str | int | None) -> str | None:
        """Normalize project identifiers to strings for API payloads."""
        if project_id is None:
            return None
        return str(project_id)

    def get_session(self, session_id: str) -> dict[str, Any]:
        """Get session details with resume context.

        This is the enhanced session endpoint per PRD Pre-Implementation #2.

        Supports both full UUIDs and short ID prefixes (Git-style). Short IDs
        are automatically expanded to full UUIDs by querying recent sessions.

        Args:
            session_id: Session ID (full UUID or short prefix like "54439c55")

        Returns:
            Session dictionary with fields:
            - session_id: Session ID
            - objective: Task objective
            - state: Current state
            - current_phase: Current orchestration phase
            - iteration: Current iteration number
            - resume_context: Context for resuming (if applicable)
            - quality_scorecard: Quality metrics (if available)
            - pending_escalation: Pending escalation notice (if any)
            - created_at: Session creation timestamp
            - updated_at: Last update timestamp
            - working_dir: Working directory path (for resume)
            - project_id: Project ID (for resume)

        Raises:
            APIError: If session query fails, session not found (404), or ID is ambiguous (400)
        """
        # Expand short ID to full UUID if needed (ISSUE-SAAS-044 fix)
        full_id = self._expand_session_id(session_id)

        try:
            return self._request("GET", f"get_hybrid_session?session_id={full_id}")
        except APIError as e:
            if e.status_code == HTTPStatus.NOT_FOUND:
                return self.get_status(full_id)
            raise

    def list_sessions(
        self,
        limit: int = API_SESSIONS_DEFAULT_LIMIT,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List recent sessions for the current user.

        Args:
            limit: Maximum number of sessions to return (default: 10)
            status: Filter by session status (active, completed, expired)

        Returns:
            List of session dictionaries with summary info

        Raises:
            APIError: If list request fails
        """
        params = [f"limit={limit}"]
        if status:
            params.append(f"status={status}")

        query_string = "&".join(params)
        # ISSUE-SAAS-020: Fixed endpoint name to match deployed Firebase function
        response = self._request("GET", f"list_sessions?{query_string}")
        sessions = response.get("sessions")
        if isinstance(sessions, list):
            return [session for session in sessions if isinstance(session, dict)]
        logger.warning("Unexpected sessions payload shape: %s", type(sessions).__name__)
        return []

    def cancel_session(self, session_id: str) -> dict[str, Any]:
        """Cancel a session by setting status to abandoned.

        Supports both full UUIDs and short ID prefixes (Git-style).

        Args:
            session_id: Session ID to cancel (full UUID or short prefix)

        Returns:
            Response dictionary with fields:
            - success: bool - Whether cancellation succeeded
            - session_id: str - The cancelled session ID
            - message: str - Success message

        Raises:
            APIError: If cancellation request fails (403: not owner, 404: not found, 400: ambiguous)
        """
        # Expand short ID to full UUID if needed (ISSUE-SAAS-044 fix)
        full_id = self._expand_session_id(session_id)
        payload = {"session_id": full_id}
        return self._request("POST", "cancel_session", json=payload)

    def repair_session(self, session_id: str) -> dict[str, Any]:
        """Repair a session by auto-detecting and fixing common issues.

        Supports both full UUIDs and short ID prefixes (Git-style).

        Args:
            session_id: Session ID to repair (full UUID or short prefix)

        Returns:
            Response dictionary with fields:
            - success: bool - Whether repair succeeded
            - message: str - Result message
            - repairs_applied: list[dict] - List of repairs, each with:
                - field: str - Field that was repaired (e.g., 'item_id', 'phase', 'status')
                - action: str - Action taken (e.g., 'recovered', 'advanced', 'reconciled')

        Possible repairs:
            - missing_item_id: Recovers missing item_id from execution_results
            - stuck_wait_state: Advances phase when stuck in WAIT status
            - inconsistent_status: Reconciles status/phase mismatches

        Raises:
            APIError: If repair request fails (403: not owner, 404: not found, 400: ambiguous, 500: server error)
        """
        # Expand short ID to full UUID if needed
        full_id = self._expand_session_id(session_id)
        payload = {"session_id": full_id}
        return self._request("POST", "repair_session", json=payload)

    def force_complete_session(self, session_id: str, reason: str | None = None) -> dict[str, Any]:
        """Force-complete a session regardless of current phase.

        Marks the session as COMPLETED and preserves all execution results.
        Use this for stuck sessions that have completed work but cannot progress.

        Supports both full UUIDs and short ID prefixes (Git-style).

        Args:
            session_id: Session ID to force-complete (full UUID or short prefix)
            reason: Optional reason for force completion (for audit trail)

        Returns:
            Response dictionary with fields:
            - success: bool - Whether force-complete succeeded
            - message: str - Result message
            - preserved_results: int - Count of execution results preserved
            - warnings: list[str] - Warnings about incomplete work

        Raises:
            APIError: If request fails (403: not owner, 404: not found, 400: ambiguous, 500: server error)
        """
        # Expand short ID to full UUID if needed
        full_id = self._expand_session_id(session_id)
        payload = {"session_id": full_id, "reason": reason}
        return self._request("POST", "force_complete_session", json=payload)

    def reset_review(self, session_id: str) -> dict[str, Any]:
        """Reset a session's review state and return to execution phase.

        Clears review results for the current item and resets the session phase
        to EXECUTION, allowing the item to be re-executed. Useful when review
        keeps failing or incorrect review results need to be discarded.

        Supports both full UUIDs and short ID prefixes (Git-style).

        Args:
            session_id: Session ID to reset review for (full UUID or short prefix)

        Returns:
            Response dictionary with fields:
            - success: bool - Whether reset succeeded
            - message: str - Result message
            - item_id: str - Item ID that was reset (if in review phase)
            - previous_phase: str - Phase before reset (if in review phase)

        Raises:
            APIError: If request fails (403: not owner, 404: not found, 400: ambiguous, 500: server error)
        """
        # Expand short ID to full UUID if needed
        full_id = self._expand_session_id(session_id)
        payload = {"session_id": full_id}
        return self._request("POST", "reset_review", json=payload)

    def list_projects(self, include_deleted: bool = False) -> list[dict[str, Any]]:
        """List projects for the current user."""
        query_string = "all=true" if include_deleted else "all=false"
        response = self._request("GET", f"list_projects?{query_string}")
        projects = response.get("projects")
        if isinstance(projects, list):
            return [project for project in projects if isinstance(project, dict)]
        logger.warning("Unexpected projects payload shape: %s", type(projects).__name__)
        return []

    def list_projects_with_selection(self, include_deleted: bool = False) -> dict[str, Any]:
        """List projects with the user's default selection.

        Returns:
            Dictionary with:
            - projects: List of project dictionaries
            - default_project_id: The user's selected default project ID (or None)
        """
        query_string = "all=true" if include_deleted else "all=false"
        response = self._request("GET", f"list_projects?{query_string}")
        projects = response.get("projects")
        if isinstance(projects, list):
            projects = [project for project in projects if isinstance(project, dict)]
        else:
            logger.warning("Unexpected projects payload shape: %s", type(projects).__name__)
            projects = []
        return {
            "projects": projects,
            "default_project_id": response.get("default_project_id"),
        }

    def get_project(self, project_id: str) -> dict[str, Any]:
        """Get a project by ID."""
        normalized_project_id = self._normalize_project_id(project_id)
        return self._request("GET", f"get_project?project_id={normalized_project_id}")

    def create_project(
        self,
        name: str,
        working_dir: str,
        description: str = "",
        config: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a project."""
        payload = {
            "name": name,
            "working_dir": working_dir,
            "description": description,
            "config": config or {},
        }
        return self._request("POST", "create_project", json=payload)

    def update_project(
        self,
        project_id: str,
        name: str | None = None,
        working_dir: str | None = None,
    ) -> dict[str, Any]:
        """Update a project."""
        normalized_project_id = self._normalize_project_id(project_id)
        payload: dict[str, Any] = {"project_id": normalized_project_id}
        if name is not None:
            payload["name"] = name
        if working_dir is not None:
            payload["working_dir"] = working_dir
        return self._request("POST", "update_project", json=payload)

    def delete_project(self, project_id: str) -> dict[str, Any]:
        """Soft delete a project."""
        normalized_project_id = self._normalize_project_id(project_id)
        return self._request("POST", "delete_project", json={"project_id": normalized_project_id})

    def select_project(self, project_id: str) -> dict[str, Any]:
        """Set default project for the user."""
        normalized_project_id = self._normalize_project_id(project_id)
        return self._request("POST", "select_project", json={"project_id": normalized_project_id})

    def resume(self, session_id: str) -> dict[str, Any]:
        """Resume an interrupted orchestration session.

        Args:
            session_id: Session ID to resume

        Returns:
            Response dictionary with fields:
            - session_id: Session ID
            - base_prompt: Continuation prompt
            - metadata: Prompt metadata
            - status: Session status ("active")
            - iteration: Current iteration number

        Raises:
            APIError: If resume request fails
        """
        payload = {"session_id": session_id}
        return self._request("POST", "resume", json=payload)

    def get_session_events(
        self,
        session_id: str,
        limit: int = API_EVENTS_DEFAULT_LIMIT,
        offset: int = 0,
        event_type: str | None = None,
        severity: str | None = None,
    ) -> dict[str, Any]:
        """Query event history for a session.

        Args:
            session_id: Session ID to query events for
            limit: Maximum number of events to return (default 100, max 1000)
            offset: Number of events to skip for pagination
            event_type: Filter by event type
            severity: Filter by severity level (INFO, WARNING, ERROR)

        Returns:
            Response dictionary with fields:
            - session_id: Session ID
            - events: List of event dicts
            - count: Number of events returned
            - has_more: Whether more events exist

        Raises:
            APIError: If request fails
        """
        params = [f"session_id={session_id}", f"limit={limit}", f"offset={offset}"]
        if event_type:
            params.append(f"event_type={event_type}")
        if severity:
            params.append(f"severity={severity}")

        query_string = "&".join(params)
        return self._request("GET", f"get_session_events?{query_string}")

    def _request(
        self,
        method: str,
        endpoint: str,
        json: dict[str, Any] | None = None,
        retry: bool = True,
        skip_auth_check: bool = False,
        response_schema: type[BaseModel] | None = None,
        request_id: str | None = None,
        client_request_start_ts: float | None = None,
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Make HTTP request with retry logic and optional response validation.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint (e.g., "/orchestrate")
            json: JSON payload for POST/PUT
            retry: Enable retry logic (default: True)
            skip_auth_check: Skip token expiration check
            response_schema: Optional Pydantic model class for response validation
            timeout: Request timeout in seconds (default: use instance timeout)

        Returns:
            Response JSON as dictionary (validated against schema if provided)

        Raises:
            APIError: If request fails after retries or response validation fails
        """
        # Check token expiration and refresh if needed (unless skipped)
        if not skip_auth_check:
            self._check_token_expiration()

        url = urljoin(self.base_url, endpoint)

        # Determine retry attempts
        max_attempts = self.MAX_RETRIES if retry else 1

        last_error: Exception | None = None

        for attempt in range(max_attempts):
            try:
                headers: dict[str, str] = {}
                trace_header = self._build_trace_header()
                if trace_header:
                    headers["X-Cloud-Trace-Context"] = trace_header
                if request_id:
                    headers["X-Obra-Request-Id"] = request_id
                if client_request_start_ts is not None:
                    headers["X-Obra-Request-Start"] = str(int(client_request_start_ts * 1000))

                # ISSUE-HYBRID-001: Use timeout tuple (connect, read) for better control
                # Connect timeout: how long to wait for connection establishment
                # Read timeout: how long to wait for response data
                # Using tuples helps detect hung connections vs slow responses
                request_timeout = timeout if timeout is not None else self.timeout
                if isinstance(request_timeout, (int, float)):
                    # Convert single timeout to tuple: (connect, read)
                    # Connect timeout is shorter as connection should be fast
                    pool_cfg = get_api_connection_pool_config()
                    connect_timeout = min(pool_cfg["timeout_s"], request_timeout)
                    timeout_tuple = (connect_timeout, request_timeout)
                else:
                    timeout_tuple = request_timeout  # Already a tuple

                response = self.session.request(
                    method=method,
                    url=url,
                    json=json,
                    timeout=timeout_tuple,
                    headers=headers or None,
                )

                # Handle response - check for success (2xx)
                if response.ok:
                    response_data = response.json()
                    if not isinstance(response_data, dict):
                        self._raise_invalid_response(response.status_code, response_data)

                    # Validate response against schema if provided
                    if response_schema is not None:
                        try:
                            validated = response_schema(**response_data)
                            # Return the validated data as a dictionary
                            return cast(dict[str, Any], validated.model_dump())
                        except ValidationError as e:
                            # Convert Pydantic validation error to APIError
                            error_details = "; ".join(
                                [
                                    f"{'.'.join(map(str, err['loc']))}: {err['msg']}"
                                    for err in e.errors()
                                ]
                            )
                            raise APIError(
                                message=f"Response validation failed: {error_details}",
                                status_code=response.status_code,
                                response_body=str(response_data),
                            ) from e

                    return response_data

                # Handle error status codes
                error_body = response.text
                error_json: dict[str, Any] = {}
                try:
                    parsed_error = response.json()
                    if isinstance(parsed_error, dict):
                        error_json = parsed_error
                        error_message = error_json.get("error", error_body)
                    else:
                        error_message = error_body
                except Exception:
                    error_message = error_body

                # Don't retry client errors (4xx), except 401 which gets token refresh
                if (
                    HTTPStatus.BAD_REQUEST
                    <= response.status_code
                    < HTTPStatus.INTERNAL_SERVER_ERROR
                ):
                    # Check for specific terms_not_accepted error (403)
                    if (
                        response.status_code == HTTPStatus.FORBIDDEN
                        and error_json.get("error") == "terms_not_accepted"
                    ):
                        self._raise_terms_not_accepted(error_json)

                    # Enhanced 400 error messages with validation details
                    if response.status_code == HTTPStatus.BAD_REQUEST:
                        # Extract detailed validation error information
                        error_code = error_json.get("code", "validation_error")
                        error_details = str(
                            error_json.get("details", error_json.get("message", error_message))
                        )

                        # Build detailed error message
                        detailed_message = f"API validation error: {error_message}"

                        # Add error code if available
                        if error_code and error_code != "validation_error":
                            detailed_message = f"API error ({error_code}): {error_message}"

                        # Add additional details if present
                        if error_details and error_details != error_message:
                            detailed_message += f"\nDetails: {error_details}"

                        # Add missing fields information if available
                        if "missing_fields" in error_json:
                            detailed_message += (
                                f"\nMissing required fields: {error_json['missing_fields']}"
                            )

                        # Add invalid fields information if available
                        if "invalid_fields" in error_json:
                            detailed_message += f"\nInvalid fields: {error_json['invalid_fields']}"

                        # Include endpoint for debugging
                        detailed_message += f"\nEndpoint: POST /{endpoint}"

                        self._raise_validation_error(detailed_message, error_body)

                    # Handle 401 Unauthorized - attempt token refresh and retry once
                    if response.status_code == HTTPStatus.UNAUTHORIZED and not skip_auth_check:
                        if self.refresh_token and self.firebase_api_key:
                            # Try to refresh the token
                            if self.refresh_auth_token():
                                # Token refreshed, retry the request
                                return self._request(
                                    method=method,
                                    endpoint=endpoint,
                                    json=json,
                                    retry=False,
                                    skip_auth_check=True,
                                    response_schema=response_schema,
                                )

                        # Refresh failed or not possible
                        self._raise_auth_expired(error_body)

                    # Extract server context for debugging (CHORE-SERVER-ERROR-CONTEXT-001)
                    error_ctx = self._extract_server_context(error_json, dict(response.headers))
                    self._raise_api_error(
                        response.status_code, error_message, error_body, error_ctx
                    )

                # Retry server errors (5xx) - extract context for debugging
                error_ctx = self._extract_server_context(error_json, dict(response.headers))
                last_error = APIError(
                    message=f"API error {response.status_code}: {error_message}",
                    status_code=response.status_code,
                    response_body=error_body,
                    error_context=error_ctx,
                )

            except requests.exceptions.Timeout as e:
                last_error = APIError(
                    message=f"Request timed out after {self.timeout}s ({type(e).__name__}: {e})",
                    status_code=0,
                    response_body=str(e),
                )
                # Preserve original exception chain for debugging
                last_error.__cause__ = e

            except requests.exceptions.ConnectionError as e:
                last_error = APIError(
                    message=f"Connection error ({type(e).__name__}: {e})",
                    status_code=0,
                    response_body=str(e),
                )
                # Preserve original exception chain for debugging
                last_error.__cause__ = e

            except (APIError, TermsNotAcceptedError):
                # Re-raise API errors and terms errors
                raise

            except Exception as e:
                last_error = APIError(
                    message=f"Request failed ({type(e).__name__}: {e})",
                    status_code=0,
                    response_body=str(e),
                )
                # Preserve original exception chain for debugging
                last_error.__cause__ = e

            # Retry with exponential backoff
            if attempt < max_attempts - 1:
                retry_delays = get_api_retry_delays()
                delay = retry_delays[attempt] if attempt < len(retry_delays) else retry_delays[-1]
                time.sleep(delay)
            else:
                break

        # All retries exhausted
        if last_error:
            raise last_error

        msg = "Request failed with unknown error"
        raise APIError(msg)

    def set_auth_token(self, token: str) -> None:
        """Update authentication token.

        Args:
            token: New Firebase custom token
        """
        self.auth_token = token
        self.session.headers.update({"Authorization": f"Bearer {token}"})

    def log_terms_acceptance(
        self,
        terms_version: str,
        privacy_version: str,
        client_version: str,
        source: str = "cli_setup",
        user_id: str | None = None,
        email: str | None = None,
    ) -> bool:
        """Log terms acceptance to server for legal compliance audit trail.

        Args:
            terms_version: Version of terms accepted (e.g., "2.1")
            privacy_version: Version of privacy policy (e.g., "1.3")
            client_version: obra package version
            source: Where acceptance occurred (default: "cli_setup")
            user_id: Firebase UID (preferred identifier)
            email: User email address (fallback identifier)

        Returns:
            True if server logging succeeded, False otherwise
        """
        payload: dict[str, Any] = {
            "terms_version": terms_version,
            "privacy_version": privacy_version,
            "client_version": client_version,
            "source": source,
        }

        if user_id:
            payload["user_id"] = user_id
        if email:
            payload["email"] = email

        try:
            response = self._request(
                method="POST",
                endpoint="terms_accept",
                json=payload,
                retry=True,
                skip_auth_check=False,
            )

            success_value = response.get("success")
            if isinstance(success_value, bool):
                return success_value
            logger.warning(
                "Unexpected success flag type in terms_accept response: %s",
                type(success_value).__name__,
            )
            return False

        except Exception as e:
            # Graceful degradation: don't raise, just return False
            logger.warning(
                "Terms acceptance logging failed for endpoint=%s: %s",
                "terms_accept",
                str(e),
            )
            return False

    def close(self) -> None:
        """Close HTTP session and cleanup resources."""
        self.session.close()

    # =========================================================================
    # User Configuration Methods
    # =========================================================================

    def get_user_config(
        self,
        *,
        retry: bool = True,
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Get user's configuration (preset + overrides + resolved).

        Returns:
            Dictionary with fields:
            - preset: str - Current preset name
            - overrides: dict - User's custom overrides
            - resolved: dict - Full merged configuration
            - created_at: str - When config was created
            - updated_at: str - When config was last updated

        Args:
            retry: Whether to retry on transient failures
            timeout: Optional request timeout override (seconds)

        Raises:
            APIError: If request fails
        """
        return self._request("GET", "get_user_config", retry=retry, timeout=timeout)

    def update_user_config(
        self,
        preset: str | None = None,
        overrides: dict[str, Any] | None = None,
        clear_overrides: bool = False,
    ) -> dict[str, Any]:
        """Update user's configuration.

        Args:
            preset: New preset name (optional)
            overrides: Dict of dot-notation path overrides to merge
            clear_overrides: If True, clear all existing overrides

        Returns:
            Dictionary with updated config

        Raises:
            APIError: If request fails
        """
        payload: dict[str, Any] = {}

        if preset is not None:
            payload["preset"] = preset

        if overrides is not None:
            payload["overrides"] = overrides

        if clear_overrides:
            payload["clear_overrides"] = True

        if not payload:
            return self.get_user_config()

        return self._request("POST", "update_user_config", json=payload)

    def list_presets(self) -> dict[str, Any]:
        """List available configuration presets.

        Returns:
            Dictionary with fields:
            - presets: list of preset info dicts

        Raises:
            APIError: If request fails
        """
        return self._request("GET", "list_presets")

    # =========================================================================
    # Plan Management Methods
    # =========================================================================

    def upload_plan(self, name: str, plan_data: dict) -> dict[str, Any]:
        """Upload a MACHINE_PLAN.yaml to the server.

        Uploads a parsed plan structure to Firestore for later use.
        The plan is stored in users/{uid}/plans/{plan_id} and can be
        referenced in subsequent derive commands via --plan-id.

        Args:
            name: Plan name (typically work_id from YAML)
            plan_data: Parsed YAML structure (dict representation)

        Returns:
            Dictionary with fields:
            - plan_id: UUID for the uploaded plan
            - name: Plan name
            - story_count: Number of stories in the plan
            - created_at: Timestamp when plan was uploaded

        Raises:
            APIError: If upload fails or validation fails

        Example:
            >>> client = APIClient.from_config()
            >>> with open("plan.yaml") as f:
            ...     plan_data = yaml.safe_load(f)
            >>> result = client.upload_plan("FEAT-AUTH-001", plan_data)
            >>> print(f"Plan ID: {result['plan_id']}")
        """
        payload = {
            "name": name,
            "plan_data": plan_data,
        }
        return self._request("POST", "upload_plan", json=payload)

    def list_plans(self, limit: int = API_PLANS_DEFAULT_LIMIT) -> list[dict[str, Any]]:
        """List user's uploaded plans.

        Returns a list of plans uploaded by the current user, ordered
        by creation time (most recent first).

        Args:
            limit: Maximum number of plans to return (default: 50, max: 100)

        Returns:
            List of plan dictionaries with fields:
            - plan_id: UUID for the plan
            - name: Plan name
            - story_count: Number of stories
            - created_at: Upload timestamp
            - used_count: How many times plan was used (optional)

        Raises:
            APIError: If list request fails

        Example:
            >>> client = APIClient.from_config()
            >>> plans = client.list_plans(limit=10)
            >>> for plan in plans:
            ...     print(f"{plan['name']}: {plan['story_count']} stories")
        """
        params = f"limit={min(limit, API_LIMIT_MAX)}"
        # ISSUE-SAAS-019: Fixed endpoint name to match deployed Firebase function
        response = self._request("GET", f"list_plans?{params}")
        plans = response.get("plans")
        if isinstance(plans, list):
            return [plan for plan in plans if isinstance(plan, dict)]
        logger.warning("Unexpected plans payload shape: %s", type(plans).__name__)
        return []

    def get_plan(self, plan_id: str) -> dict[str, Any]:
        """Get details of a specific plan.

        Args:
            plan_id: UUID of the plan to retrieve

        Returns:
            Dictionary with fields:
            - plan_id: UUID
            - name: Plan name
            - plan_data: Full plan structure
            - story_count: Number of stories
            - created_at: Upload timestamp

        Raises:
            APIError: If plan not found or request fails

        Example:
            >>> client = APIClient.from_config()
            >>> plan = client.get_plan("abc123-uuid")
            >>> print(f"Plan: {plan['name']}")
        """
        return self._request("GET", f"get_plan?plan_id={plan_id}")

    def delete_plan(self, plan_id: str) -> dict[str, Any]:
        """Delete a plan from the server.

        Permanently removes the plan from Firestore. This cannot be undone.
        Sessions using this plan are not affected (they have their own copy).

        Args:
            plan_id: UUID of the plan to delete

        Returns:
            Dictionary with fields:
            - success: True if deletion succeeded
            - plan_id: UUID of deleted plan

        Raises:
            APIError: If plan not found or deletion fails

        Example:
            >>> client = APIClient.from_config()
            >>> result = client.delete_plan("abc123-uuid")
            >>> print("Plan deleted" if result['success'] else "Failed")
        """
        return self._request("DELETE", f"delete_plan?plan_id={plan_id}")

    # -------------------------------------------------------------------------
    # UserPlan Methods (S2.T3)
    # -------------------------------------------------------------------------

    def create_userplan(
        self,
        userplan_id: str,
        project_id: str,
        source: dict[str, Any],
        steps: list[dict[str, Any]],
        session_id: str | None = None,
        status: str = "draft",
        quality_score: float | None = None,
        quality_status: str = "not_assessed",
        work_type: str | None = None,
        context: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new UserPlan in storage.

        S2.T3: Plan file imports must create a UserPlan before derivation.
        This method persists the UserPlan to server storage.

        Args:
            userplan_id: Unique identifier (format: UP-<timestamp>-<slug>)
            project_id: Project identifier
            source: Metadata about how the UserPlan was created
            steps: List of UserPlan steps (at least 1 required)
            session_id: Optional session context reference
            status: UserPlan lifecycle status (default: 'draft')
            quality_score: Quality assessment score (0.0-1.0)
            quality_status: Quality assessment status (default: 'not_assessed')
            work_type: Detected or specified work type
            context: Top-level context inherited by all steps
            metadata: Optional extensibility metadata

        Returns:
            Dictionary with created UserPlan data including:
            - id: UserPlan ID
            - project_id: Project identifier
            - created_at: Creation timestamp

        Raises:
            APIError: If creation fails or validation fails

        Example:
            >>> client = APIClient.from_config()
            >>> result = client.create_userplan(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     project_id="my-app",
            ...     source={"type": "plan_file", "generated": False},
            ...     steps=[{"id": "UP-20260116-auth-feature:S1", "index": 1, ...}]
            ... )
            >>> print(f"Created: {result['id']}")
        """
        normalized_project_id = self._normalize_project_id(project_id)
        payload: dict[str, Any] = {
            "userplan_id": userplan_id,
            "project_id": normalized_project_id,
            "source": source,
            "steps": steps,
            "status": status,
            "quality_status": quality_status,
        }
        if session_id is not None:
            payload["session_id"] = session_id
        if quality_score is not None:
            payload["quality_score"] = quality_score
        if work_type is not None:
            payload["work_type"] = work_type
        if context is not None:
            payload["context"] = context
        if metadata is not None:
            payload["metadata"] = metadata

        return self._request("POST", "create_userplan", json=payload)

    def get_userplan(self, userplan_id: str) -> dict[str, Any] | None:
        """Get a UserPlan by ID.

        Args:
            userplan_id: UserPlan ID (format: UP-<timestamp>-<slug>)

        Returns:
            UserPlan data dictionary or None if not found

        Raises:
            APIError: If request fails (other than not found)

        Example:
            >>> client = APIClient.from_config()
            >>> userplan = client.get_userplan("UP-20260116-auth-feature")
            >>> if userplan:
            ...     print(f"Found: {userplan['id']}")
        """
        try:
            return self._request("GET", f"get_userplan?userplan_id={userplan_id}")
        except APIError as e:
            if e.status_code == HTTPStatus.NOT_FOUND:
                return None
            raise

    def list_userplans(
        self,
        project_id: str | None = None,
        status: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """List UserPlans with optional filters.

        Args:
            project_id: Filter by project identifier (optional)
            status: Filter by status (draft, active, completed, archived)
            limit: Maximum number of UserPlans to return (default: 50, max: 100)

        Returns:
            List of UserPlan dictionaries with fields:
            - id: UserPlan ID
            - project_id: Project identifier
            - status: UserPlan lifecycle status
            - source: Source metadata
            - step_count: Number of steps
            - created_at: Creation timestamp
            - updated_at: Last update timestamp
            - quality_score: Quality assessment score (if assessed)
            - quality_status: Quality assessment status

        Raises:
            APIError: If list request fails

        Example:
            >>> client = APIClient.from_config()
            >>> userplans = client.list_userplans(project_id="my-app", limit=10)
            >>> for up in userplans:
            ...     print(f"{up['id']}: {up['step_count']} steps")
        """
        normalized_project_id = self._normalize_project_id(project_id)
        params: list[str] = [f"limit={min(limit, API_LIMIT_MAX)}"]
        if normalized_project_id:
            params.append(f"project_id={normalized_project_id}")
        if status:
            params.append(f"status={status}")

        query_string = "&".join(params)
        response = self._request("GET", f"list_userplans?{query_string}")
        userplans = response.get("userplans")
        if isinstance(userplans, list):
            return userplans
        return []

    def update_userplan_quality(
        self,
        userplan_id: str,
        quality_score: float | None,
        quality_status: str,
        quality_hints: list[str] | None = None,
        quality_threshold: float = 0.6,
    ) -> dict[str, Any]:
        """Update UserPlan with quality assessment results.

        Args:
            userplan_id: UserPlan ID to update
            quality_score: Quality score (0.0-1.0), or None if not assessed
            quality_status: Quality status (passed, failed, skipped, not_assessed)
            quality_hints: Optional list of improvement suggestions
            quality_threshold: Threshold used for assessment (default 0.6)

        Returns:
            Updated UserPlan data dictionary

        Raises:
            APIError: If request fails

        Example:
            >>> client = APIClient.from_config()
            >>> result = client.update_userplan_quality(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     quality_score=0.75,
            ...     quality_status="passed",
            ...     quality_hints=[]
            ... )
        """
        payload: dict[str, Any] = {
            "userplan_id": userplan_id,
            "quality_status": quality_status,
            "quality_threshold": quality_threshold,
        }
        if quality_score is not None:
            payload["quality_score"] = quality_score
        if quality_hints is not None:
            payload["quality_hints"] = quality_hints

        return self._request("PATCH", "update_userplan_quality", json=payload)

    def update_userplan_step(
        self,
        userplan_id: str,
        step_index: int,
        title: str | None = None,
        description: str | None = None,
        expected_version: int | None = None,
        cascade: bool = False,
    ) -> dict[str, Any]:
        """Update a specific step in a UserPlan.

        When step content (title or description) is modified, the step's
        derivation_status is automatically set to STALE to indicate that
        re-derivation is needed.

        Args:
            userplan_id: UserPlan ID (format: UP-<timestamp>-<slug>)
            step_index: 1-based index of the step to update
            title: New step title (optional)
            description: New step description (optional)
            expected_version: Optional version for optimistic locking
            cascade: If True, mark sibling steps (steps after the edited step)
                    as STALE to handle staleness propagation

        Returns:
            Updated UserPlan data dictionary with the modified step.
            Includes 'cascaded_steps' list of step indices that were marked STALE.

        Raises:
            APIError: If request fails or step not found
            ValueError: If neither title nor description is provided

        Example:
            >>> client = APIClient.from_config()
            >>> result = client.update_userplan_step(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     step_index=1,
            ...     title="Implement JWT authentication",
            ...     description="Create JWT token handling with refresh tokens",
            ...     cascade=True
            ... )
            >>> # Step derivation_status is now STALE
            >>> print(result['updated_step']['derivation_status'])
            'stale'
            >>> # Sibling steps after step 1 are also marked STALE
            >>> print(result['cascaded_steps'])
            [2, 3]
        """
        if title is None and description is None:
            msg = "At least one of 'title' or 'description' must be provided"
            raise ValueError(msg)

        payload: dict[str, Any] = {
            "step_index": step_index,
        }
        if title is not None:
            payload["title"] = title
        if description is not None:
            payload["description"] = description
        if expected_version is not None:
            payload["expected_version"] = expected_version
        if cascade:
            payload["cascade"] = cascade

        payload["userplan_id"] = userplan_id
        payload["step_index"] = step_index
        return self._request(
            "PATCH",
            "update_userplan_step",
            json=payload,
        )

    def update_userplan_step_status(
        self,
        userplan_id: str,
        step_index: int,
        derivation_status: str,
        expected_version: int | None = None,
    ) -> dict[str, Any]:
        """Update the derivation status of a specific step in a UserPlan.

        Used for --from-step re-derivation to mark steps as DERIVING before
        derivation and DERIVED after completion.

        Args:
            userplan_id: UserPlan ID (format: UP-<timestamp>-<slug>)
            step_index: 1-based index of the step to update
            derivation_status: New status (not_derived, deriving, derived, stale)
            expected_version: Optional version for optimistic locking

        Returns:
            Updated UserPlan data dictionary with the modified step

        Raises:
            APIError: If request fails or step not found

        Example:
            >>> client = APIClient.from_config()
            >>> # Mark step 3 as deriving before re-derivation
            >>> result = client.update_userplan_step_status(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     step_index=3,
            ...     derivation_status="deriving"
            ... )
            >>> print(result['steps'][2]['derivation_status'])
            'deriving'
        """
        # Route single step status update through batch endpoint
        payload: dict[str, Any] = {
            "userplan_id": userplan_id,
            "step_indices": [step_index],
            "derivation_status": derivation_status,
        }
        if expected_version is not None:
            payload["expected_version"] = expected_version

        return self._request(
            "PATCH",
            "update_userplan_steps_status_batch",
            json=payload,
        )

    def update_userplan_steps_status_batch(
        self,
        userplan_id: str,
        step_indices: list[int],
        derivation_status: str,
        expected_version: int | None = None,
    ) -> dict[str, Any]:
        """Update the derivation status of multiple steps in a UserPlan.

        Batch operation to update status of multiple steps at once,
        useful for --from-step re-derivation which affects steps N through end.

        Args:
            userplan_id: UserPlan ID (format: UP-<timestamp>-<slug>)
            step_indices: List of 1-based indices of steps to update
            derivation_status: New status (not_derived, deriving, derived, stale)
            expected_version: Optional version for optimistic locking

        Returns:
            Updated UserPlan data dictionary with modified steps

        Raises:
            APIError: If request fails or any step not found

        Example:
            >>> client = APIClient.from_config()
            >>> # Mark steps 3, 4, 5 as deriving before re-derivation
            >>> result = client.update_userplan_steps_status_batch(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     step_indices=[3, 4, 5],
            ...     derivation_status="deriving"
            ... )
        """
        payload: dict[str, Any] = {
            "userplan_id": userplan_id,
            "step_indices": step_indices,
            "derivation_status": derivation_status,
        }
        if expected_version is not None:
            payload["expected_version"] = expected_version

        return self._request(
            "PATCH",
            "update_userplan_steps_status_batch",
            json=payload,
        )

    def add_userplan_step(
        self,
        userplan_id: str,
        title: str,
        description: str,
        index: int | None = None,
        context: dict[str, Any] | None = None,
        expected_version: int | None = None,
    ) -> dict[str, Any]:
        """Add a new step to a UserPlan.

        Inserts a new step at the specified index (or appends to end if not specified).
        Steps after the insertion point are re-indexed automatically.

        Args:
            userplan_id: UserPlan ID (format: UP-<timestamp>-<slug>)
            title: Step title (required)
            description: Step description (required)
            index: 1-based index for insertion (default: append to end)
            context: Optional step context (deliverables, requirements, etc.)
            expected_version: Optional version for optimistic locking

        Returns:
            Updated UserPlan data dictionary with the new step.
            Includes:
            - added_step: The newly added step
            - steps: All steps with updated indices

        Raises:
            APIError: If request fails or UserPlan not found

        Example:
            >>> client = APIClient.from_config()
            >>> result = client.add_userplan_step(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     title="Add password validation",
            ...     description="Implement password strength validation rules",
            ...     index=2  # Insert as second step
            ... )
            >>> print(result['added_step']['id'])
            'UP-20260116-auth-feature:S2'
        """
        payload: dict[str, Any] = {
            "userplan_id": userplan_id,
            "title": title,
            "description": description,
        }
        if index is not None:
            payload["index"] = index
        if context is not None:
            payload["context"] = context
        if expected_version is not None:
            payload["expected_version"] = expected_version

        return self._request(
            "POST",
            "add_userplan_step",
            json=payload,
        )

    def remove_userplan_step(
        self,
        userplan_id: str,
        step_index: int,
        expected_version: int | None = None,
    ) -> dict[str, Any]:
        """Remove a step from a UserPlan.

        Removes the step at the specified index. Steps after the removed step
        are re-indexed automatically. This operation cannot be undone.

        Args:
            userplan_id: UserPlan ID (format: UP-<timestamp>-<slug>)
            step_index: 1-based index of the step to remove
            expected_version: Optional version for optimistic locking

        Returns:
            Updated UserPlan data dictionary without the removed step.
            Includes:
            - removed_step: The step that was removed
            - steps: Remaining steps with updated indices

        Raises:
            APIError: If request fails, UserPlan not found, or step not found

        Example:
            >>> client = APIClient.from_config()
            >>> result = client.remove_userplan_step(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     step_index=2
            ... )
            >>> print(f"Removed: {result['removed_step']['title']}")
        """
        params = f"userplan_id={userplan_id}&step_index={step_index}"
        if expected_version is not None:
            params += f"&expected_version={expected_version}"

        return self._request(
            "DELETE",
            f"remove_userplan_step?{params}",
        )

    def get_userplan_step(
        self,
        userplan_id: str,
        step_index: int,
    ) -> dict[str, Any] | None:
        """Get a specific step from a UserPlan.

        Retrieves detailed information about a single step including
        its context and derivation status.

        Args:
            userplan_id: UserPlan ID (format: UP-<timestamp>-<slug>)
            step_index: 1-based index of the step to retrieve

        Returns:
            Step data dictionary or None if not found.
            Includes:
            - id: Step ID
            - index: Step index
            - title: Step title
            - description: Step description
            - context: Step context (if set)
            - derivation_status: Current derivation status

        Raises:
            APIError: If request fails (other than not found)

        Example:
            >>> client = APIClient.from_config()
            >>> step = client.get_userplan_step(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     step_index=1
            ... )
            >>> if step:
            ...     print(f"Step: {step['title']}")
        """
        try:
            return self._request(
                "GET",
                f"get_userplan_step?userplan_id={userplan_id}&step_index={step_index}",
            )
        except APIError as e:
            if e.status_code == HTTPStatus.NOT_FOUND:
                return None
            raise

    def update_userplan_step_context(
        self,
        userplan_id: str,
        step_index: int,
        context: dict[str, Any],
        expected_version: int | None = None,
    ) -> dict[str, Any]:
        """Update the context of a specific step in a UserPlan.

        Updates the step's context fields (deliverables, success_criteria,
        requirements, tech_stack, constraints, assumptions).

        Args:
            userplan_id: UserPlan ID (format: UP-<timestamp>-<slug>)
            step_index: 1-based index of the step to update
            context: Context fields to update (merged with existing)
            expected_version: Optional version for optimistic locking

        Returns:
            Updated UserPlan data dictionary with the modified step.

        Raises:
            APIError: If request fails or step not found

        Example:
            >>> client = APIClient.from_config()
            >>> result = client.update_userplan_step_context(
            ...     userplan_id="UP-20260116-auth-feature",
            ...     step_index=1,
            ...     context={
            ...         "deliverables": ["JWT middleware", "Token refresh endpoint"],
            ...         "tech_stack": ["Python", "FastAPI", "PyJWT"]
            ...     }
            ... )
        """
        payload: dict[str, Any] = {
            "userplan_id": userplan_id,
            "step_index": step_index,
            "context": context,
        }
        if expected_version is not None:
            payload["expected_version"] = expected_version

        return self._request(
            "PATCH",
            "update_userplan_step_context",
            json=payload,
        )

    # -------------------------------------------------------------------------
    # Feedback Methods
    # -------------------------------------------------------------------------

    def submit_feedback(self, feedback_data: dict[str, Any]) -> dict[str, Any]:
        """Submit beta tester feedback to the server.

        Sends bug reports, feature requests, or general feedback to Firestore
        for analysis. Supports anonymous submissions.

        Args:
            feedback_data: Feedback report dictionary containing:
                - metadata: Report metadata (report_id, privacy_level, etc.)
                - system_info: Auto-collected system information
                - feedback_type: "bug", "feature", or "comment"
                - summary: One-line summary
                - description: Detailed description
                - Additional fields based on feedback type

        Returns:
            Dictionary with fields:
            - success: True if submission succeeded
            - report_id: Server-assigned report ID
            - message: Success/error message

        Raises:
            APIError: If submission fails

        Example:
            >>> from obra.feedback import FeedbackCollector, PrivacyLevel
            >>> collector = FeedbackCollector(privacy_level=PrivacyLevel.STANDARD)
            >>> report = collector.create_bug_report(summary="App crashes on start")
            >>> client = APIClient.from_config()
            >>> result = client.submit_feedback(report.to_dict())
            >>> print(f"Submitted: {result['report_id']}")
        """
        return self._request(
            "POST",
            "feedback",
            json=feedback_data,
            timeout=get_api_client_config()[
                "default_timeout_s"
            ],  # E1 regression fix (CHORE-CONFIG-DEFAULTS-001-E3 S3)
        )

    def get_feedback(self, report_id: str) -> dict[str, Any]:
        """Get a feedback report by ID.

        Args:
            report_id: UUID of the feedback report

        Returns:
            Feedback report dictionary

        Raises:
            APIError: If report not found

        Example:
            >>> client = APIClient.from_config()
            >>> report = client.get_feedback("abc123-uuid")
            >>> print(f"Type: {report['feedback_type']}")
        """
        return self._request("GET", f"feedback?report_id={report_id}")

    def list_user_feedback(self, limit: int = API_USER_FEEDBACK_DEFAULT_LIMIT) -> dict[str, Any]:
        """List feedback reports submitted by the current user.

        Args:
            limit: Maximum number of reports to return (default: 20)

        Returns:
            Dictionary with fields:
            - reports: List of feedback report summaries
            - total: Total count of user's feedback

        Example:
            >>> client = APIClient.from_config()
            >>> result = client.list_user_feedback(limit=10)
            >>> for report in result['reports']:
            ...     print(f"{report['report_id']}: {report['summary']}")
        """
        return self._request("GET", f"feedback?limit={limit}")

    # -------------------------------------------------------------------------
    # Session Plan Methods
    # -------------------------------------------------------------------------

    def get_session_plan(self, session_id: str) -> dict[str, Any]:
        """Get plan items with execution status for a session.

        Retrieves the derived execution plan for a session, including
        the status of each task (pending, in_progress, completed, failed).

        Supports both full UUIDs and short ID prefixes (Git-style).

        Args:
            session_id: Session ID (full UUID or short prefix like "54439c55")

        Returns:
            Dictionary with fields:
            - session_id: Full session UUID
            - plan_items: List of plan item dictionaries with:
                - item_id: Unique task identifier
                - title: Task title/description
                - status: pending | in_progress | completed | failed
                - order: Execution order (1-based)
                - started_at: Timestamp when task started (if applicable)
                - completed_at: Timestamp when task completed (if applicable)
            - total_count: Total number of plan items
            - completed_count: Number of completed items
            - objective: Session objective

        Raises:
            APIError: If session not found (404), ID ambiguous (400), or request fails

        Example:
            >>> client = APIClient.from_config()
            >>> plan = client.get_session_plan("abc123")
            >>> for item in plan['plan_items']:
            ...     status = '✓' if item['status'] == 'completed' else '○'
            ...     print(f"{status} {item['title']}")
        """
        # Expand short ID to full UUID if needed
        full_id = self._expand_session_id(session_id)
        return self._request("GET", f"get_session_plan?session_id={full_id}")

    def get_quality_scorecard(self, session_id: str, item_id: str) -> dict[str, Any]:
        """Get quality scorecard for a specific plan item.

        Args:
            session_id: Session ID (full UUID or short prefix)
            item_id: Plan item identifier

        Returns:
            Dictionary with field:
            - scorecard: Quality scorecard dict
        """
        full_id = self._expand_session_id(session_id)
        return self._request(
            "GET",
            f"get_quality_scorecard?session_id={full_id}&item_id={item_id}",
        )
