"""Story 0 execution handler for environment preparation."""

from __future__ import annotations

import contextlib
import fnmatch
import hashlib
import json
import logging
import os
import socket
import subprocess
import time
import tomllib
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from getpass import getpass
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from obra.config.loaders import (
    get_story0_docker_timeout,
    get_story0_llm_schema_timeout,
    get_story0_port_mapping,
    get_story0_service_image,
    get_story0_timeout,
    get_timeout,
)
from obra.display import print_info
from obra.execution.skip_record import SkipReason, SkipSource, create_skip_record
from obra.hybrid.install_target import InstallTargetManager
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.hybrid.tooling_discovery import ToolingDiscovery
from obra.models.story0_state import (
    Prerequisite,
    PrerequisiteCategory,
    PrerequisiteSource,
    PrerequisiteStatus,
    Story0State,
    Story0Status,
    load_story0_state,
)
from obra.prompts.story0.prerequisites import build_story0_manifest_prompt
from obra.validation.verification_tools import (
    merge_verification_tools,
    resolve_verification_tools,
)

logger = logging.getLogger(__name__)

MANIFEST_TYPE_MAP = {
    "python": "pyproject.toml",
    "node": "package.json",
    "rust": "Cargo.toml",
    "go": "go.mod",
    "ruby": "Gemfile",
}

MINIMAL_MANIFEST_TEMPLATES = {
    "pyproject.toml": ('[project]\nname = "obra-project"\nversion = "0.1.0"\n'),
    "package.json": json.dumps({"name": "obra-project", "version": "0.1.0"}, indent=2),
    "Cargo.toml": '[package]\nname = "obra_project"\nversion = "0.1.0"\n',
    "go.mod": "module obra_project\n\ngo 1.21\n",
    "Gemfile": 'source "https://rubygems.org"\n',
}


def is_effectively_empty(directory: Path, markers: list[str]) -> bool:
    if not directory.exists():
        return True
    for item in directory.iterdir():
        if any(fnmatch.fnmatch(item.name, marker) for marker in markers):
            continue
        return False
    return True


@dataclass
class Story0Result:
    """Result payload for Story 0 execution."""

    status: str
    completed: list[str]
    failed: list[str]
    skipped: list[str]
    blocking_failures: list[str]
    non_blocking_failures: list[str]
    state_path: Path
    verification_tools: dict[str, Any]
    mocked_credentials: list[str]


class Story0Handler:
    """Execute Story 0 environment preparation prerequisites."""

    def __init__(
        self,
        working_dir: Path,
        config: dict[str, Any],
        on_progress: Callable[[str, dict[str, Any]], None] | None,
        session_id: str,
        objective: str,
        is_tty: bool = True,
        llm_config: dict[str, Any] | None = None,
    ) -> None:
        self._working_dir = Path(working_dir)
        self._config = config
        self._story0_config = dict(config.get("story0", {}))
        self._on_progress = on_progress
        self._session_id = session_id
        self._objective = objective
        self._is_tty = is_tty
        self._llm_config = llm_config or config.get("llm", {}) or {}
        self._tooling_discovery = ToolingDiscovery(self._working_dir, self._llm_config)
        self._install_target = InstallTargetManager()
        self._state_path = self._working_dir / ".obra" / "story0_state.yaml"
        self._containers: list[dict[str, Any]] = []
        self._mocked_credentials: list[str] = []
        self._prereq_state: list[Prerequisite] = []
        self._env_setup_performed = False
        self._generated_manifest_paths: list[str] = []
        self._generated_manifest_type: str | None = None
        self._verification_tools_state: dict[str, Any] = {}
        self._automation_mode_requested = config.get("automation_mode")
        self._automation_mode_effective = self._automation_mode_requested
        self._installs_by_source: dict[str, list[str]] = {
            "manifest": [],
            "inferred": [],
        }
        self._log_decisions = bool(self._story0_config.get("log_decisions", True))
        self._genie_hint_shown = False  # Track if we've shown the Genie mode hint

    def handle(
        self,
        prerequisites: list[dict[str, Any]],
        resume_reason: str | None = None,
        missing_tools: list[str] | None = None,
    ) -> Story0Result:
        """Run Story 0 environment preparation."""
        mode = self._config.get("automation_mode", "auto_safe")
        if mode == "guided" and not self._is_tty:
            self._emit_progress(
                "[Story0] Guided mode requested but no TTY available. "
                "Falling back to auto_safe behavior."
            )
            self._automation_mode_requested = "guided"
            self._automation_mode_effective = "auto_safe"
            mode = "auto_safe"
            self._story0_config.update(
                {
                    "auto_env_setup": True,
                    "prompt_for_env_setup": False,
                    "install_policy": "manifest_then_inferred",
                    "allow_inferred_installs": True,
                    "auto_approve": False,
                    "install_target": "project_local",
                    "env_creation": "when_missing",
                }
            )
        else:
            self._automation_mode_effective = mode

        self._emit_progress(f"[Story0] Automation mode: {mode}")
        self._emit_decision_event(
            "automation_mode_selected",
            {
                "mode": mode,
            },
        )
        self._emit_story0_started()
        if resume_reason == "verification_tools_missing":
            state = self._load_state()
            if state:
                self._apply_state(state)
            return self._run_verification_preflight(missing_tools)

        self._emit_progress(f"[Story0] Install policy: {self._story0_config.get('install_policy')}")

        ecosystems = self._detect_ecosystems()
        if ecosystems:
            self._emit_progress("[Story0] Detected ecosystems: " + ", ".join(ecosystems))

        state = self._load_state()
        if state:
            self._apply_state(state)
            if state.mocked_credentials:
                self._check_mock_upgrades(state)
                refreshed = self._load_state()
                if refreshed:
                    state = refreshed
                    self._apply_state(state)
        verification_tools = self._discover_verification_tools()

        if state and state.status == Story0Status.COMPLETE:
            current_hash = hashlib.sha256(self._objective.encode()).hexdigest()[:16]
            if state.objective_hash != current_hash:
                self._emit_progress(
                    "Objective changed since Story 0 completed.\n"
                    f"  Previous: {state.objective_hash[:8]}...\n"
                    f"  Current:  {current_hash[:8]}...\n"
                    "Prerequisites may need updating. Recommend: obra run --resume <id> --from story-0"
                )
                state = None
                self._reset_state_cache()
            else:
                valid, _failures = self._quick_validate()
                if valid:
                    self._emit_progress(
                        "Environment preflight (Story 0) already validated from a previous run.\n"
                        "No setup changes detected, so this step is skipped and execution continues."
                    )
                    self._emit_story0_completed(0, 0)
                    return self._finalize_result(
                        status="complete",
                        completed=[],
                        failed=[],
                        skipped=[],
                        blocking_failures=[],
                        non_blocking_failures=[],
                        verification_tools=verification_tools,
                    )
                state = None
                self._reset_state_cache()

        markers = self._story0_config.get(
            "allowed_empty_markers",
            [".git", ".obra", "README*", ".gitignore"],
        )
        auto_env_setup = self._story0_config.get("auto_env_setup", True)

        if not self._working_dir.exists() or (
            auto_env_setup and is_effectively_empty(self._working_dir, markers)
        ):
            if auto_env_setup and not self._handle_inbox_project(self._objective):
                self._emit_story0_completed(1, 0)
                return self._finalize_result(
                    status="failed",
                    completed=[],
                    failed=["inbox_project"],
                    skipped=[],
                    blocking_failures=["inbox_project"],
                    non_blocking_failures=[],
                    verification_tools=verification_tools,
                )
        elif auto_env_setup and mode == "auto_full":
            existing_manifests = self._detect_existing_manifests()
            if existing_manifests:
                self._emit_progress(
                    "[Story0] Skipped environment setup: existing manifests found "
                    f"({len(existing_manifests)})"
                )
            elif not self._handle_inbox_project(self._objective):
                self._emit_story0_completed(1, 0)
                return self._finalize_result(
                    status="failed",
                    completed=[],
                    failed=["inbox_project"],
                    skipped=[],
                    blocking_failures=["inbox_project"],
                    non_blocking_failures=[],
                    verification_tools=verification_tools,
                )
        elif auto_env_setup:
            self._emit_progress(
                "[Story0] Manifest not generated (populated repo). "
                "Hint: Use automation_mode=auto_full to generate in any repo."
            )

        if not prerequisites:
            message = (
                "Environment preflight (Story 0) found no prerequisites for this objective.\n"
                "Setup is skipped because no dependencies, credentials, or services are required."
            )
            self._emit_progress(message)
            self._save_state(status=Story0Status.COMPLETE)
            self._emit_story0_completed(0, 0)
            return self._finalize_result(
                status="complete",
                completed=[],
                failed=[],
                skipped=[],
                blocking_failures=[],
                non_blocking_failures=[],
                verification_tools=verification_tools,
            )

        completed: list[str] = []
        failed: list[str] = []
        skipped: list[str] = []
        blocking_failures: list[str] = []
        non_blocking_failures: list[str] = []
        failures: list[tuple[dict[str, Any], str]] = []
        prereqs_to_process = prerequisites

        if state and state.status == Story0Status.PARTIAL:
            completed = [
                prereq.id
                for prereq in self._prereq_state
                if prereq.status in (PrerequisiteStatus.INSTALLED, PrerequisiteStatus.MOCKED)
            ]
            total = len(self._prereq_state)
            self._emit_progress(f"Resuming Story 0 ({len(completed)}/{total} complete)...")
            by_id = {prereq.id: prereq for prereq in self._prereq_state}
            by_name = {prereq.name: prereq for prereq in self._prereq_state}

            def _is_completed(entry: dict[str, Any]) -> bool:
                key = str(entry.get("id") or entry.get("name") or "unknown")
                name = str(entry.get("name") or "")
                existing = by_id.get(key) or by_name.get(name)
                if not existing:
                    return False
                return existing.status in (
                    PrerequisiteStatus.INSTALLED,
                    PrerequisiteStatus.MOCKED,
                )

            prereqs_to_process = [prereq for prereq in prerequisites if not _is_completed(prereq)]

        for prereq in prereqs_to_process:
            prereq_id = str(prereq.get("id") or prereq.get("name") or "unknown")
            prereq_entry = self._coerce_prereq(prereq)
            category = prereq_entry.category
            handler = self._resolve_handler(category)

            self._emit_prereq_progress(prereq, "Processing")
            status, detail = handler(prereq)

            if status in (
                PrerequisiteStatus.INSTALLED.value,
                PrerequisiteStatus.MOCKED.value,
            ):
                completed.append(prereq_id)
            elif status == PrerequisiteStatus.SKIPPED.value:
                skipped.append(prereq_id)
                if self._is_skip_tracking_enabled():
                    create_skip_record(
                        session_id=self._session_id or "",
                        task_id=prereq_id,
                        source=SkipSource.STORY0,
                        reason=self._map_story0_detail_to_reason(detail),
                        description=f"Prerequisite {prereq.get('name', 'unknown')}: {detail}",
                        source_context={
                            "prereq_category": prereq.get("category"),
                            "prereq_name": prereq.get("name"),
                            "detail": detail,
                        },
                    )
                    logger.info("Run 'obra skips list' to review skipped items")
            else:
                failed.append(prereq_id)
                failures.append((prereq, detail))
                if self._is_blocking(category):
                    blocking_failures.append(prereq_id)
                else:
                    non_blocking_failures.append(prereq_id)
                    # Create skip record for non-blocking failures (e.g. service failures in mock mode)
                    if self._is_skip_tracking_enabled():
                        create_skip_record(
                            session_id=self._session_id or "",
                            task_id=prereq_id,
                            source=SkipSource.STORY0,
                            reason=self._map_story0_detail_to_reason(detail),
                            description=f"Non-blocking failure bypassed: {detail}",
                            source_context={
                                "category": (
                                    category.value if hasattr(category, "value") else str(category)
                                ),
                                "detail": detail,
                                "mock_mode": self._story0_config.get("mock_credentials", False),
                            },
                        )
                        logger.info("Run 'obra skips list' to review bypassed items")

            prereq_entry.status = PrerequisiteStatus(status)
            if status == PrerequisiteStatus.MOCKED.value:
                prereq_entry.mock_type = self._story0_config.get("default_mock_level")
            if (
                status == PrerequisiteStatus.INSTALLED.value
                and category == PrerequisiteCategory.SERVICE
            ):
                prereq_entry.container_name = prereq.get("container_name")
                prereq_entry.port = prereq.get("port")
            self._update_prereq_state(prereq_entry)
            self._save_state(status=Story0Status.PARTIAL)
            self._emit_story0_prereq_status(prereq_entry, status, detail)

        if failures and not self._is_tty:
            self._emit_story0_blocked(self._build_failure_summary(failures))

        self._emit_summary()

        if blocking_failures:
            status = "failed"
        elif failed:
            status = "partial"
        else:
            status = "complete"

        self._emit_story0_completed(len(blocking_failures), len(non_blocking_failures))
        return self._finalize_result(
            status=status,
            completed=completed,
            failed=failed,
            skipped=skipped,
            blocking_failures=blocking_failures,
            non_blocking_failures=non_blocking_failures,
            verification_tools=verification_tools,
        )

    def _map_story0_detail_to_reason(self, detail: str) -> SkipReason:
        detail_lower = (detail or "").lower()
        if "input timeout" in detail_lower:
            return SkipReason.USER_TIMEOUT
        if "user declined" in detail_lower:
            return SkipReason.USER_DECLINED
        if "no value provided" in detail_lower:
            return SkipReason.USER_DECLINED
        if "user skipped" in detail_lower:
            return SkipReason.USER_DECLINED
        if "automation mode" in detail_lower:
            return SkipReason.SCOPE_BOUNDARY
        if "llm determined" in detail_lower:
            return SkipReason.EXTERNAL_DEPENDENCY
        return SkipReason.UNKNOWN

    def _is_skip_tracking_enabled(self) -> bool:
        skip_config = self._config.get("orchestration", {}).get("skip_tracking", {})
        return bool(skip_config.get("enabled", True)) and bool(
            skip_config.get("sources", {}).get("story0", True)
        )

    def _resolve_handler(
        self, category: PrerequisiteCategory
    ) -> Callable[[dict[str, Any]], tuple[str, str]]:
        if category == PrerequisiteCategory.AUTO:
            return self._handle_auto
        if category == PrerequisiteCategory.AUTO_CONFIRM:
            return self._handle_auto_confirm
        if category == PrerequisiteCategory.CREDENTIAL:
            return self._handle_credential
        if category == PrerequisiteCategory.SERVICE:
            return self._handle_service
        if category == PrerequisiteCategory.USER_ACTION:
            return self._handle_user_action
        if category == PrerequisiteCategory.ACCOUNT:
            return self._handle_account
        return self._handle_auto

    def _handle_auto(self, prereq: dict[str, Any]) -> tuple[str, str]:
        registry = self._installer_registry()
        manifest = self._detect_manifest(registry)
        if not manifest:
            return (
                PrerequisiteStatus.FAILED.value,
                "No supported manifest found for auto-installation.",
            )

        reason = prereq.get("reason", "")
        self._emit_prereq_progress(prereq, "Installing")
        self._emit_progress(f"Installing {prereq.get('name')}: {reason}")
        try:
            return registry[manifest](prereq)
        except subprocess.TimeoutExpired:
            return (PrerequisiteStatus.FAILED.value, "Install timed out")
        except Exception as exc:
            return (PrerequisiteStatus.FAILED.value, str(exc))

    def _handle_auto_confirm(self, prereq: dict[str, Any]) -> tuple[str, str]:
        reason = prereq.get("reason", "")
        name = prereq.get("name", "unknown")
        source = prereq.get("source", "UNKNOWN")

        if not self._is_tty:
            self._emit_progress(f"Auto-approved (non-interactive mode): {name} - {reason}")
            return self._handle_auto(prereq)
        if self._story0_config.get("auto_approve"):
            self._emit_progress(f"Auto-approved (auto-approve enabled): {name} - {reason}")
            return self._handle_auto(prereq)

        self._emit_story0_prereq_status(
            self._coerce_prereq(prereq),
            "user_input_needed",
            "Awaiting user confirmation",
        )

        # Show Genie mode hint once per session
        if not self._genie_hint_shown:
            self._genie_hint_shown = True
            self._emit_progress(
                "[dim]Tip: For fewer prompts, try 'Genie Mode' via `obra config` → Personas. "
                "It auto-approves these decisions (best for sandboxed environments).[/dim]"
            )

        prompt = f"{name}\nSource: {source}\nReason: {reason}\nProceed with {name}? [Y/n] "
        response = self._prompt_text(prompt, default="y")
        if response is None:
            return (PrerequisiteStatus.SKIPPED.value, "Input timeout")
        if response.lower().startswith("n"):
            return (PrerequisiteStatus.SKIPPED.value, "User declined")
        return self._handle_auto(prereq)

    def _handle_credential(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "unknown")
        reason = prereq.get("reason", "")

        if self._story0_config.get("mock_credentials"):
            mock_value = self._create_mock_credential(name)
            os.environ[name] = mock_value
            self._mocked_credentials.append(name)
            return (
                PrerequisiteStatus.MOCKED.value,
                self._story0_config.get("default_mock_level", "fixture"),
            )

        if not self._is_tty:
            return (
                PrerequisiteStatus.FAILED.value,
                "Credential required: "
                f"{name}\nNeeded for: {reason}\n\n"
                "Running in non-interactive mode. Either:\n"
                f"  1. Set {name} environment variable before running\n"
                "  2. Run with --mock-credentials flag\n"
                "  3. Run interactively (TTY required)",
            )

        self._emit_progress(f"{name} not found in environment.\nNeeded for: {reason}")
        self._emit_story0_prereq_status(
            self._coerce_prereq(prereq),
            "user_input_needed",
            "Credential input required",
        )
        choice = self._prompt_text(
            "[1] Enter value [2] Mock for testing [3] Skip: ",
            default="3",
        )
        if choice is None:
            return (PrerequisiteStatus.SKIPPED.value, "Input timeout")
        choice = choice.strip() or "3"
        if choice == "1":
            value = getpass(f"Enter value for {name}: ")
            if value:
                os.environ[name] = value
                return (PrerequisiteStatus.INSTALLED.value, "Set from user input")
            return (PrerequisiteStatus.SKIPPED.value, "No value provided")
        if choice == "2":
            mock_value = self._create_mock_credential(name)
            os.environ[name] = mock_value
            self._mocked_credentials.append(name)
            return (
                PrerequisiteStatus.MOCKED.value,
                self._story0_config.get("default_mock_level", "fixture"),
            )
        return (PrerequisiteStatus.SKIPPED.value, "User skipped")

    def _handle_service(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "unknown").lower()
        reason = prereq.get("reason", "")
        port = self._default_service_port(name)
        if port and self._check_tcp("127.0.0.1", port):
            return (
                PrerequisiteStatus.INSTALLED.value,
                "Service already running on default port",
            )

        if not self._docker_available():
            return (
                PrerequisiteStatus.FAILED.value,
                f"Service {name} not running and Docker not available.\n"
                f"Needed for: {reason}\n\n"
                f"To resolve:\n  1. Start {name} manually, or\n  2. Install Docker for auto-start",
            )

        if not self._story0_config.get("docker", {}).get("enabled", True):
            return (
                PrerequisiteStatus.FAILED.value,
                f"Service {name} not running and Docker auto-start disabled.\nNeeded for: {reason}",
            )

        image = self._service_image(name)
        container_name = f"obra-{name}-{self._session_id[:8]}"
        try:
            subprocess.run(
                ["docker", "pull", image],
                check=False,
                capture_output=True,
                text=True,
            )
            subprocess.run(
                [
                    "docker",
                    "run",
                    "-d",
                    "--name",
                    container_name,
                    "--label",
                    "obra.managed=true",
                    "--label",
                    f"obra.session={self._session_id}",
                    "-P",
                    image,
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            assigned_port = self._resolve_container_port(container_name)
            self._containers.append(
                {
                    "container_name": container_name,
                    "port": assigned_port,
                    "image": image,
                    "started_at": datetime.now(UTC).isoformat(),
                }
            )
            prereq["container_name"] = container_name
            prereq["port"] = assigned_port
            if assigned_port and self._wait_for_service("127.0.0.1", assigned_port):
                self._emit_progress(f"Started {name} via Docker: {reason}")
                return (
                    PrerequisiteStatus.INSTALLED.value,
                    f"Started via Docker on port {assigned_port}",
                )
            return (
                PrerequisiteStatus.FAILED.value,
                f"Service {name} container started but did not become ready.",
            )
        except subprocess.CalledProcessError as exc:
            return (PrerequisiteStatus.FAILED.value, exc.stderr or str(exc))

    def _handle_user_action(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "unknown")
        reason = prereq.get("reason", "")

        # In mock_credentials mode, auto-skip user action prompts (simulation mode)
        if self._story0_config.get("mock_credentials"):
            return (
                PrerequisiteStatus.INSTALLED.value,
                f"User action mocked (simulation mode): {name}",
            )

        if not self._is_tty:
            return (
                PrerequisiteStatus.FAILED.value,
                f"Manual action required: {reason}. Cannot proceed in non-interactive mode.",
            )

        self._emit_story0_prereq_status(
            self._coerce_prereq(prereq),
            "user_input_needed",
            "Waiting for manual action",
        )
        prompt = (
            f"{name}\n\nRequired action: {reason}\n\n"
            "Please complete this action manually, then press Enter to continue..."
        )
        response = self._prompt_text(prompt, default="")
        if response is None:
            return (PrerequisiteStatus.SKIPPED.value, "Input timeout")
        return (PrerequisiteStatus.INSTALLED.value, "User confirmed completion")

    def _handle_account(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "unknown")
        reason = prereq.get("reason", "")
        url = prereq.get("url")

        # In mock_credentials mode, auto-skip account prompts (simulation mode)
        if self._story0_config.get("mock_credentials"):
            return (
                PrerequisiteStatus.INSTALLED.value,
                f"Account mocked (simulation mode): {name}",
            )

        if not self._is_tty:
            url_hint = (
                f" Create account at {url} before running in non-interactive mode."
                if url
                else " Create account before running in non-interactive mode."
            )
            return (
                PrerequisiteStatus.FAILED.value,
                f"External account required: {name}.{url_hint}",
            )

        self._emit_story0_prereq_status(
            self._coerce_prereq(prereq),
            "user_input_needed",
            "Waiting for account setup",
        )
        message = f"{name} account required\n\nReason: {reason}"
        if url:
            message += f"\nSign up at: {url}"
        message += "\nPress Enter when account is created..."
        response = self._prompt_text(message, default="")
        if response is None:
            return (PrerequisiteStatus.SKIPPED.value, "Input timeout")
        return (PrerequisiteStatus.INSTALLED.value, "Account created")

    def _handle_inbox_project(self, objective: str) -> Path | None:
        prompt_for_env_setup = self._story0_config.get("prompt_for_env_setup", False)
        if prompt_for_env_setup and not self._is_tty:
            self._emit_progress("Inbox project requires interactive confirmation. Run in TTY mode.")
            return None

        prompt = (
            "Analyze this objective and determine the most appropriate project type. "
            "What type of project best fits this objective? Explain your reasoning.\n\n"
            f"Objective: {objective}\n\n"
            'Return JSON: {"project_type": "<freeform - your determination>", '
            '"reasoning": "...", "suggested_structure": {...}, '
            '"manifest_type": "<appropriate manifest for this project type>"}'
        )
        pipeline = TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name="story0_inbox",
        )

        template_schema = {
            "project_type": "",
            "reasoning": "",
            "suggested_structure": {},
            "manifest_type": "",
            "_instructions": "Fill project_type, reasoning, suggested_structure, manifest_type.",
        }

        def validator(data: dict) -> tuple[bool, str | None]:
            required = [
                "project_type",
                "reasoning",
                "suggested_structure",
                "manifest_type",
            ]
            for key in required:
                if key not in data:
                    return False, f"Missing {key}"
            if not isinstance(data.get("suggested_structure"), (dict, list)):
                return False, "suggested_structure must be dict or list"
            return True, None

        def fallback() -> dict[str, Any]:
            return {}

        if not self._llm_config:
            self._emit_progress("LLM config missing; cannot set up inbox project.")
            return None

        result, _meta = pipeline.execute(
            base_prompt=prompt,
            template_schema=template_schema,
            validator=validator,
            fallback_fn=fallback,
            llm_config=self._llm_config,
        )

        if not result:
            self._emit_progress("Inbox project analysis failed.")
            return None

        project_type = result.get("project_type", "unknown")
        reasoning = result.get("reasoning", "")
        structure = result.get("suggested_structure", {})
        _manifest_type = result.get("manifest_type", "")

        if prompt_for_env_setup and self._is_tty:
            response = self._prompt_text(
                "Based on objective analysis:\n"
                f"  Project type: {project_type}\n"
                f"  Reasoning: {reasoning}\n"
                f"  Structure: {structure}\n\n"
                "Create this project? [Y/n/customize] ",
                default="y",
            )
            if response is None:
                return None
            response = response.strip().lower() or "y"
            if response.startswith("n"):
                return None
            if response.startswith("c"):
                project_type = (
                    self._prompt_text("Project type: ", default=project_type) or project_type
                )
                structure_text = self._prompt_text(
                    "Structure JSON (blank to keep suggested): ",
                    default="",
                )
                if structure_text:
                    try:
                        structure = json.loads(structure_text)
                    except json.JSONDecodeError:
                        self._emit_progress("Invalid structure JSON; using suggested structure.")

        self._working_dir.mkdir(parents=True, exist_ok=True)
        self._create_structure(structure)

        manifests, _meta = self._generate_manifests_llm(objective)
        manifest_source = "LLM-generated"
        if not manifests:
            self._emit_progress("[Story0] LLM manifest generation failed, using fallback")
            manifests = self._generate_fallback_manifests()
            manifest_source = "fallback"

        validated: list[dict[str, Any]] = []
        for manifest in manifests:
            if not isinstance(manifest, dict):
                continue
            manifest_type = str(manifest.get("type") or "").strip()
            manifest_path = str(manifest.get("path") or ".").strip() or "."
            contents = manifest.get("contents")
            if not manifest_type or contents is None:
                self._emit_progress("[Story0] Skipped: manifest missing required fields")
                continue

            contents_text = str(contents)
            is_valid, reason = self._validate_manifest_contents(manifest_type, contents_text)
            if not is_valid:
                self._emit_progress(f"[Story0] Manifest invalid ({manifest_type}): {reason}")
                repaired = self._repair_manifest_llm(manifest_type, contents_text, reason)
                if repaired is not None:
                    repaired_valid, repaired_reason = self._validate_manifest_contents(
                        manifest_type, repaired
                    )
                    if repaired_valid:
                        contents_text = repaired
                    else:
                        self._emit_progress(
                            f"[Story0] Manifest repair failed ({manifest_type}): {repaired_reason}"
                        )
                        contents_text = MINIMAL_MANIFEST_TEMPLATES.get(manifest_type, contents_text)
                else:
                    contents_text = MINIMAL_MANIFEST_TEMPLATES.get(manifest_type, contents_text)

            validated.append(
                {
                    "type": manifest_type,
                    "path": manifest_path,
                    "contents": contents_text,
                    "rationale": manifest.get("rationale", ""),
                }
            )

        created_manifests: list[str] = []
        for manifest in validated:
            manifest_type = manifest["type"]
            manifest_path = str(manifest.get("path") or ".").strip() or "."
            path_obj = Path(manifest_path)
            if path_obj.is_absolute() or ".." in path_obj.parts:
                self._emit_progress(f"[Story0] Skipped: invalid manifest path {manifest_path}")
                continue

            target_dir = (
                self._working_dir if manifest_path in (".", "./") else self._working_dir / path_obj
            )
            target_dir.mkdir(parents=True, exist_ok=True)

            ecosystem = self._manifest_ecosystem(manifest_type)
            if ecosystem and self._has_conflict_markers(target_dir, ecosystem):
                rel_dir = (
                    target_dir.relative_to(self._working_dir)
                    if target_dir != self._working_dir
                    else Path()
                )
                self._emit_progress(
                    f"[Story0] Skipped: {rel_dir} contains existing ecosystem config"
                )
                continue

            target_path = target_dir / manifest_type
            if target_path.exists() and self._story0_config.get("never_overwrite_manifest", True):
                rel_path = (
                    target_path.relative_to(self._working_dir)
                    if target_path.exists()
                    else target_path
                )
                self._emit_progress(
                    f"[Story0] Skipped: {rel_path} exists; never_overwrite_manifest=true"
                )
                continue

            target_path.write_text(manifest["contents"], encoding="utf-8")
            rel_path = (
                target_path.relative_to(self._working_dir) if target_path.exists() else target_path
            )
            self._emit_progress(f"[Story0] Manifest created: {rel_path} ({manifest_source})")
            created_manifests.append(str(rel_path))

        if created_manifests:
            self._env_setup_performed = True
            self._generated_manifest_paths = created_manifests
            self._generated_manifest_type = validated[0]["type"] if len(validated) == 1 else None
            self._emit_decision_event(
                "manifest_generated",
                {
                    "packages": created_manifests,
                    "target": str(self._working_dir),
                },
            )

        return self._working_dir

    def _generate_manifests_llm(
        self, objective: str
    ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        if not self._llm_config:
            return [], {"status": "missing_llm"}

        tooling_info: dict[str, Any] = {}
        try:
            tooling_info = self._tooling_discovery.discover()
        except Exception as exc:
            logger.debug("Tooling discovery failed for manifests: %s", exc)

        repo_structure = self._describe_repo_structure()
        prompt = build_story0_manifest_prompt(objective, tooling_info, repo_structure)

        pipeline = TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name="story0_manifest",
            max_retries=2,
        )
        template_schema = {
            "manifests": [],
            "_instructions": (
                "Populate manifests array with entries containing type, path, contents, rationale."
            ),
        }

        def validator(data: dict) -> tuple[bool, str | None]:
            if "manifests" in data and isinstance(data.get("manifests"), list):
                return True, None
            if "manifest_type" in data or "manifest_contents" in data:
                return True, None
            return False, "Missing manifests array"

        def fallback() -> dict[str, Any]:
            return {}

        result, meta = pipeline.execute(
            base_prompt=prompt,
            template_schema=template_schema,
            validator=validator,
            fallback_fn=fallback,
            llm_config=self._llm_config,
        )

        manifests = self._normalize_manifest_response(result)
        return manifests, meta

    def _normalize_manifest_response(self, result: Any) -> list[dict[str, Any]]:
        if isinstance(result, dict):
            if isinstance(result.get("manifests"), list):
                return [entry for entry in result.get("manifests", []) if isinstance(entry, dict)]
            legacy_type = result.get("manifest_type")
            legacy_contents = result.get("manifest_contents") or result.get("contents")
            if legacy_type and legacy_contents:
                return [
                    {
                        "type": legacy_type,
                        "path": ".",
                        "contents": legacy_contents,
                        "rationale": "legacy response",
                    }
                ]
        return []

    def _describe_repo_structure(self) -> list[str]:
        ignore = {
            ".git",
            ".obra",
            ".venv",
            "venv",
            ".conda",
            "__pycache__",
            "node_modules",
        }
        entries: list[str] = []
        for root, dirs, files in os.walk(self._working_dir):
            dirs[:] = [d for d in dirs if d not in ignore]
            rel_root = Path(root).relative_to(self._working_dir)
            if rel_root != Path():
                entries.append(f"{rel_root}/")
            for filename in files:
                rel_path = (rel_root / filename) if rel_root != Path() else Path(filename)
                entries.append(str(rel_path))
            if len(entries) >= 200:
                break
        return entries[:200]

    def _generate_fallback_manifests(self) -> list[dict[str, Any]]:
        counts: defaultdict[str, int] = defaultdict(int)
        ext_map = {
            "python": {".py"},
            "node": {".js", ".ts", ".jsx", ".tsx"},
            "rust": {".rs"},
            "go": {".go"},
            "ruby": {".rb"},
        }
        for path in self._working_dir.rglob("*"):
            if not path.is_file():
                continue
            if any(
                part in {".git", ".obra", ".venv", "venv", ".conda", "node_modules"}
                for part in path.parts
            ):
                continue
            ext = path.suffix.lower()
            for ecosystem, extensions in ext_map.items():
                if ext in extensions:
                    counts[ecosystem] += 1
                    break

        selected = None
        if counts:
            selected = sorted(counts.items(), key=lambda item: (-item[1], item[0]))[0][0]
        else:
            selected = None

        manifest_type = MANIFEST_TYPE_MAP.get(
            selected or "",
            self._story0_config.get("default_manifest_type", "pyproject.toml"),
        )
        if manifest_type is None:
            manifest_type = "pyproject.toml"
        contents = MINIMAL_MANIFEST_TEMPLATES.get(
            manifest_type, MINIMAL_MANIFEST_TEMPLATES["pyproject.toml"]
        )
        return [
            {
                "type": manifest_type,
                "path": ".",
                "contents": contents,
                "rationale": "fallback",
            }
        ]

    def _detect_ecosystems(self) -> list[str]:
        ecosystems: set[str] = set()
        for manifest in self._detect_existing_manifests():
            name = Path(manifest).name
            for ecosystem, manifest_type in MANIFEST_TYPE_MAP.items():
                if name == manifest_type:
                    ecosystems.add(ecosystem)
        if ecosystems:
            return sorted(ecosystems)

        ext_map = {
            "python": {".py"},
            "node": {".js", ".ts", ".jsx", ".tsx"},
            "rust": {".rs"},
            "go": {".go"},
            "ruby": {".rb"},
        }
        for path in self._working_dir.rglob("*"):
            if not path.is_file():
                continue
            ext = path.suffix.lower()
            for ecosystem, extensions in ext_map.items():
                if ext in extensions:
                    ecosystems.add(ecosystem)
        return sorted(ecosystems)

    def _validate_manifest_contents(self, manifest_type: str, contents: str) -> tuple[bool, str]:
        if manifest_type == "pyproject.toml":
            try:
                data = tomllib.loads(contents)
            except Exception as exc:
                return False, f"Invalid TOML: {exc}"
            project = data.get("project")
            if not isinstance(project, dict) or not project.get("name"):
                return False, "Missing [project].name"
            return True, ""
        if manifest_type == "package.json":
            try:
                data = json.loads(contents)
            except json.JSONDecodeError as exc:
                return False, f"Invalid JSON: {exc}"
            if not isinstance(data, dict) or not data.get("name") or not data.get("version"):
                return False, "Missing name/version"
            return True, ""
        if manifest_type == "Cargo.toml":
            try:
                data = tomllib.loads(contents)
            except Exception as exc:
                return False, f"Invalid TOML: {exc}"
            package = data.get("package")
            if not isinstance(package, dict) or not package.get("name"):
                return False, "Missing [package].name"
            return True, ""
        if manifest_type == "go.mod":
            if "module " not in contents:
                return False, "Missing module declaration"
            return True, ""
        if manifest_type == "Gemfile":
            if "source" not in contents:
                return False, "Missing source declaration"
            return True, ""
        return True, ""

    def _repair_manifest_llm(self, manifest_type: str, contents: str, reason: str) -> str | None:
        if not self._llm_config:
            return None
        prompt = (
            "Fix the manifest to satisfy validation requirements.\n"
            f"Manifest type: {manifest_type}\n"
            f"Validation error: {reason}\n\n"
            "Return ONLY the corrected manifest contents, no JSON, no markdown.\n\n"
            f"Current contents:\n{contents}\n"
        )
        try:
            from obra.config.llm import DEFAULT_THINKING_LEVEL
            from obra.llm import LLMSubprocessConfig, run_llm_subprocess

            provider = self._llm_config.get("provider", "anthropic")
            model = self._llm_config.get("model", "default")
            thinking_level = self._llm_config.get("thinking_level", DEFAULT_THINKING_LEVEL)
            auth_method = self._llm_config.get("auth_method", "oauth")

            config = LLMSubprocessConfig(
                prompt=prompt,
                cwd=self._working_dir,
                provider=provider,
                model=model,
                thinking_level=thinking_level,
                auth_method=auth_method,
                timeout_s=get_story0_llm_schema_timeout(),
                skip_git_check=True,
                streaming=False,
                call_site="story0_manifest_repair",
                run_id=self._session_id,
            )
            result = run_llm_subprocess(config)
            if not result.success:
                logger.warning("Manifest repair failed: %s", result.error)
                return None
            return result.output.strip()
        except Exception as exc:
            logger.warning("Manifest repair error: %s", exc)
            return None

    def _manifest_ecosystem(self, manifest_type: str) -> str | None:
        for ecosystem, manifest in MANIFEST_TYPE_MAP.items():
            if manifest == manifest_type:
                return ecosystem
        return None

    def _has_conflict_markers(self, target_dir: Path, ecosystem: str) -> bool:
        markers = self._config.get("ecosystem_conflict_markers", {}).get(ecosystem, [])
        return any((target_dir / marker).exists() for marker in markers)

    def _emit_prereq_progress(self, prereq: dict[str, Any], status: str) -> None:
        name = prereq.get("name", "unknown")
        source = prereq.get("source", "")
        reason = prereq.get("reason", "")
        if source == PrerequisiteSource.INFERRED.value:
            self._emit_progress(f"[INFERRED] {status} {name}: {reason}")
        elif source == PrerequisiteSource.MANIFEST.value:
            self._emit_progress(f"[MANIFEST] {status} {name}")
        else:
            self._emit_progress(f"{status} {name}: {reason}")

    def _build_failure_summary(self, failures: list[tuple[dict[str, Any], str]]) -> str:
        grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for prereq, _detail in failures:
            category = prereq.get("category", "UNKNOWN")
            grouped[str(category)].append(prereq)

        def _lines(title: str, items: list[dict[str, Any]]) -> list[str]:
            if not items:
                return []
            lines = [title + ":"]
            for item in items:
                name = item.get("name", "unknown")
                reason = item.get("reason", "")
                lines.append(f"  - {name} - {reason}")
            return lines

        sections = []
        sections += _lines(
            "Missing credentials (cannot auto-resolve)",
            grouped.get(PrerequisiteCategory.CREDENTIAL.value, []),
        )
        sections += _lines(
            "Services unavailable",
            grouped.get(PrerequisiteCategory.SERVICE.value, []),
        )
        sections += _lines(
            "Manual actions required",
            grouped.get(PrerequisiteCategory.USER_ACTION.value, []),
        )
        sections += _lines(
            "External accounts required",
            grouped.get(PrerequisiteCategory.ACCOUNT.value, []),
        )
        summary = [
            "[Story 0] Environment preparation failed (non-interactive mode)",
            "",
        ]
        summary += sections
        summary += [
            "",
            "To proceed:",
            "  1. Set required environment variables, OR",
            '  2. Run interactively: obra run "..." (TTY required), OR',
            '  3. Use mocks: obra run "..." --mock-credentials',
        ]
        return "\n".join(summary)

    def _save_state(self, status: Story0Status) -> None:
        try:
            self._state_path.parent.mkdir(parents=True, exist_ok=True)
            objective_hash = hashlib.sha256(self._objective.encode()).hexdigest()[:16]
            manifest_hash = self._compute_manifest_hash()
            payload = Story0State(
                status=status,
                objective_hash=objective_hash,
                manifest_hash=manifest_hash,
                prerequisites=self._prereq_state,
                containers=self._containers,
                mocked_credentials=self._mocked_credentials,
                automation_mode_effective=self._automation_mode_effective,
                automation_mode_requested=self._automation_mode_requested,
                env_setup_performed=self._env_setup_performed,
                generated_manifest_type=self._generated_manifest_type,
                generated_manifest_paths=self._generated_manifest_paths,
                installs_by_source=self._installs_by_source,
                verification_tools=self._verification_tools_state,
                completed_at=(datetime.now(UTC) if status == Story0Status.COMPLETE else None),
            )
            self._state_path.write_text(
                yaml.safe_dump(payload.model_dump(mode="json"), sort_keys=False),
                encoding="utf-8",
            )
        except OSError as exc:
            logger.warning("Failed to save Story 0 state: %s", exc)

    def _load_state(self) -> Story0State | None:
        if not self._state_path.exists():
            return None
        try:
            state = load_story0_state(self._state_path)
            if state.status == Story0Status.FAILED and state.reason == "state_corrupted":
                self._emit_progress(
                    "Previous environment state corrupted. Re-analyzing prerequisites..."
                )
                return None
            return state
        except OSError as exc:
            logger.warning("Failed to load Story 0 state: %s", exc)
            return None

    def _apply_state(self, state: Story0State) -> None:
        self._prereq_state = list(state.prerequisites)
        self._containers = list(state.containers)
        self._mocked_credentials = list(state.mocked_credentials)
        self._automation_mode_effective = state.automation_mode_effective
        self._automation_mode_requested = state.automation_mode_requested
        self._env_setup_performed = state.env_setup_performed
        self._generated_manifest_type = state.generated_manifest_type
        self._generated_manifest_paths = list(state.generated_manifest_paths)
        self._installs_by_source = dict(state.installs_by_source)
        self._verification_tools_state = dict(state.verification_tools)

    def _reset_state_cache(self) -> None:
        self._prereq_state = []
        self._containers = []
        self._mocked_credentials = []
        self._env_setup_performed = False
        self._generated_manifest_type = None
        self._generated_manifest_paths = []
        self._installs_by_source = {"manifest": [], "inferred": []}
        self._verification_tools_state = {}

    def _update_prereq_state(self, entry: Prerequisite) -> None:
        for index, existing in enumerate(self._prereq_state):
            if existing.id == entry.id or existing.name == entry.name:
                self._prereq_state[index] = entry
                return
        self._prereq_state.append(entry)

    def _is_container_running(self, container_name: str) -> bool:
        try:
            result = subprocess.run(
                ["docker", "inspect", container_name, "--format", "{{.State.Running}}"],
                capture_output=True,
                text=True,
                check=False,
            )
        except FileNotFoundError:
            return False
        if result.returncode != 0:
            return False
        return result.stdout.strip().lower() == "true"

    def _quick_validate(self) -> tuple[bool, list[str]]:
        state = self._load_state()
        if state is None or state.status != Story0Status.COMPLETE:
            early_failures = ["State incomplete or corrupted"]
            self._emit_progress(
                "Environment validation failed:\n"
                f"  - {early_failures[0]}\n"
                "Recommend: obra run --resume <id> --from story-0"
            )
            return False, early_failures

        failures: list[str] = []

        # Check if automation mode upgraded (e.g., off -> auto_full)
        # If current mode is more capable, re-run Story 0 to apply installs
        mode_order = {"off": 0, "guided": 1, "auto_safe": 2, "auto_full": 3}
        stored_mode = state.automation_mode_effective or "off"
        current_mode = self._automation_mode_effective or "auto_safe"
        stored_level = mode_order.get(stored_mode, 0)
        current_level = mode_order.get(current_mode, 2)
        if current_level > stored_level:
            failures.append(f"Automation mode upgraded ({stored_mode} -> {current_mode})")

        if state.manifest_hash:
            current_hash = self._compute_manifest_hash()
            if not current_hash or current_hash != state.manifest_hash:
                failures.append("Manifest changed since Story 0")

        for prereq in state.prerequisites:
            if (
                prereq.category == PrerequisiteCategory.SERVICE
                and prereq.status == PrerequisiteStatus.INSTALLED
            ):
                if not prereq.port:
                    failures.append(f"Service {prereq.name} missing port info")
                elif not self._check_tcp("127.0.0.1", prereq.port):
                    failures.append(f"Service {prereq.name} not reachable on port {prereq.port}")
            if (
                prereq.category == PrerequisiteCategory.CREDENTIAL
                and prereq.status in (PrerequisiteStatus.INSTALLED, PrerequisiteStatus.MOCKED)
                and not os.environ.get(prereq.name)
            ):
                failures.append(f"Credential missing: {prereq.name}")

        for container in state.containers:
            name = str(container.get("container_name") or "") or str(container.get("name") or "")
            if name and not self._is_container_running(name):
                failures.append(f"Docker container not running: {name}")

        if failures:
            lines = ["Environment validation failed:"]
            lines += [f"  - {reason}" for reason in failures]
            lines.append("Recommend: obra run --resume <id> --from story-0")
            self._emit_progress("\n".join(lines))
            return False, failures

        return True, []

    def _check_mock_upgrades(self, state: Story0State) -> None:
        if not self._is_tty:
            return
        if not state.mocked_credentials:
            return

        updated = False
        fixture_dir = self._working_dir / ".obra" / "mocks"
        for cred_name in list(state.mocked_credentials):
            env_value = os.environ.get(cred_name)
            if not env_value:
                continue
            fixture_path = fixture_dir / f"{cred_name}.json"
            mock_value = None
            if fixture_path.exists():
                try:
                    payload = json.loads(fixture_path.read_text(encoding="utf-8"))
                    mock_value = payload.get("mock_value")
                except json.JSONDecodeError:
                    mock_value = None
            if mock_value is not None and env_value == mock_value:
                continue

            response = self._prompt_text(
                f"{cred_name} was mocked but real value now detected in environment.\n"
                "Upgrade to real credential? [Y/n] ",
                default="y",
            )
            if response is None or response.strip().lower().startswith("n"):
                continue

            for prereq in state.prerequisites:
                if cred_name in (prereq.name, prereq.id):
                    prereq.status = PrerequisiteStatus.INSTALLED
            state.mocked_credentials = [
                name for name in state.mocked_credentials if name != cred_name
            ]
            if fixture_path.exists():
                try:
                    payload = json.loads(fixture_path.read_text(encoding="utf-8"))
                except json.JSONDecodeError:
                    payload = {}
            else:
                payload = {}
            payload["upgraded_at"] = datetime.now(UTC).isoformat()
            fixture_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
            updated = True

        if updated:
            self._apply_state(state)
            self._save_state(status=state.status)

    def _emit_summary(self) -> None:
        manifest_count = sum(
            1
            for prereq in self._prereq_state
            if prereq.source == PrerequisiteSource.MANIFEST
            and prereq.status == PrerequisiteStatus.INSTALLED
        )
        inferred_count = sum(
            1
            for prereq in self._prereq_state
            if prereq.source == PrerequisiteSource.INFERRED
            and prereq.status == PrerequisiteStatus.INSTALLED
        )
        services = [
            prereq.name
            for prereq in self._prereq_state
            if prereq.category == PrerequisiteCategory.SERVICE
            and prereq.status == PrerequisiteStatus.INSTALLED
        ]
        summary = (
            "Environment preparation complete:\n"
            f"  Manifest dependencies: {manifest_count} installed\n"
            f"  Inferred dependencies: {inferred_count} installed\n"
            f"  Mocked credentials: {self._mocked_credentials}\n"
            f"  Services started: {services}"
        )
        self._emit_progress(summary)

    def _emit_progress(self, message: str) -> None:
        if self._on_progress:
            try:
                self._on_progress("story0_message", {"message": message})
                return
            except Exception:
                pass
        print_info(message)

    def _emit_story0_event(self, action: str, payload: dict[str, Any]) -> None:
        if self._on_progress:
            try:
                self._on_progress(action, payload)
                return
            except Exception:
                pass

    def _emit_story0_started(self) -> None:
        self._emit_story0_event("story0_started", {})

    def _emit_story0_completed(self, blocking_failures: int, non_blocking_warnings: int) -> None:
        self._emit_story0_event(
            "story0_completed",
            {
                "blocking_failures": blocking_failures,
                "non_blocking_warnings": non_blocking_warnings,
            },
        )

    def _emit_story0_blocked(self, failures_summary: str) -> None:
        self._emit_story0_event("story0_blocked", {"failures_summary": failures_summary})

    def _emit_story0_prereq_status(
        self, prereq: Prerequisite, status: str, reason: str | None = None
    ) -> None:
        category_label = {
            PrerequisiteCategory.AUTO: "Dependencies",
            PrerequisiteCategory.AUTO_CONFIRM: "Dependencies",
            PrerequisiteCategory.CREDENTIAL: "Credentials",
            PrerequisiteCategory.SERVICE: "Services",
            PrerequisiteCategory.USER_ACTION: "Manual Actions",
            PrerequisiteCategory.ACCOUNT: "Manual Actions",
        }.get(prereq.category, "Prerequisites")
        self._emit_story0_event(
            "story0_prerequisite_status",
            {
                "category": category_label,
                "name": prereq.name,
                "status": status,
                "reason": reason,
            },
        )

    def _prompt_text(self, prompt: str, default: str | None = None) -> str | None:
        if not self._is_tty:
            return default
        print_info(prompt)
        # Flush to ensure prompt is visible before waiting for input
        import sys

        sys.stdout.flush()
        timeout_seconds = get_story0_timeout()
        return self._read_input(timeout_seconds, default)

    def _read_input(self, timeout_seconds: int, default: str | None) -> str | None:
        """Read input with timeout, avoiding daemon thread race conditions.

        Uses select() on Unix systems for clean timeout handling.
        Falls back to threading on Windows (where select() doesn't work on stdin).
        """
        if timeout_seconds <= 0:
            return default

        import sys

        # Try select-based approach first (Unix/WSL2) - avoids daemon thread issues
        try:
            import select

            # Flush stdout to ensure prompt is visible before waiting for input
            sys.stdout.flush()

            # Wait for input with timeout
            readable, _, _ = select.select([sys.stdin], [], [], timeout_seconds)
            if readable:
                try:
                    line = sys.stdin.readline()
                    if line:
                        return line.strip() or default
                    return default  # EOF
                except (EOFError, OSError):
                    return default
            return None  # Timeout
        except (ImportError, OSError, ValueError):
            # select() doesn't work on Windows stdin or in some edge cases
            # Fall back to threading approach
            pass

        # Fallback: threading approach (Windows)
        # Note: This can have race conditions with daemon threads if prompts timeout
        result: list[str | None] = [None]

        def _reader() -> None:
            try:
                result[0] = input().strip()
            except EOFError:
                result[0] = None

        try:
            import threading

            thread = threading.Thread(target=_reader, daemon=True)
            thread.start()
            thread.join(timeout=min(timeout_seconds, 300))
            if thread.is_alive():
                return None
        except Exception:
            return default
        return result[0] if result[0] else default

    def _create_mock_credential(self, name: str) -> str:
        mock_value = f"mock-{name.lower()}-value"
        source_path = Path("obra") / "mocks" / f"{name.lower()}.json"
        fixture_dir = self._working_dir / ".obra" / "mocks"
        fixture_dir.mkdir(parents=True, exist_ok=True)
        fixture_path = fixture_dir / f"{name}.json"
        payload = {
            "name": name,
            "mock_type": self._story0_config.get("default_mock_level", "fixture"),
            "created_at": datetime.now(UTC).isoformat(),
            "mock_value": mock_value,
        }
        if source_path.exists():
            with contextlib.suppress(json.JSONDecodeError):
                payload.update(json.loads(source_path.read_text(encoding="utf-8")))
        fixture_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return mock_value

    def _installer_registry(
        self,
    ) -> dict[str, Callable[[dict[str, Any]], tuple[str, str]]]:
        return {
            "pyproject.toml": self._install_dependency,
            "requirements-dev.txt": self._install_dependency,
            "package.json": self._install_dependency,
            "Cargo.toml": self._install_dependency,
            "go.mod": self._install_dependency,
            "Gemfile": self._install_dependency,
        }

    def _detect_manifest(self, registry: dict[str, Callable[..., Any]]) -> str | None:
        for manifest in registry:
            if (self._working_dir / manifest).exists():
                return manifest
        return None

    def _install_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        registry = self._installer_registry()
        manifest = self._detect_manifest(registry)
        if not manifest:
            return (
                PrerequisiteStatus.FAILED.value,
                "No supported manifest found for auto-installation.",
            )

        raw_name = str(prereq.get("name") or "").strip()
        source = str(prereq.get("source") or "MANIFEST").upper()
        ecosystem = self._ecosystem_from_manifest(manifest)

        prereq_with_manifest = dict(prereq)
        prereq_with_manifest.setdefault("manifest_type", manifest)
        allowed, reason = self._should_install(prereq_with_manifest, source)
        if not allowed:
            detail = reason or "Install blocked by policy"
            self._emit_progress(f"[Story0] Skipped: {raw_name} ({detail})")
            self._emit_decision_event(
                "package_skipped",
                {
                    "mode": self._automation_mode_effective or "auto_safe",
                    "ecosystem": ecosystem,
                    "packages": [raw_name] if raw_name else None,
                    "target": self._story0_config.get("install_target"),
                    "reason": detail,
                },
            )
            return (PrerequisiteStatus.SKIPPED.value, detail)

        # Handle requirements file installs (no retry logic needed)
        if manifest == "requirements-dev.txt":
            manager = self._install_target.get_package_manager(
                ecosystem,
                self._story0_config.get("package_manager_preference", {}).get(ecosystem, "auto"),
                self._working_dir,
            )
            env_path = None
            if ecosystem == "python":
                toolchains = self._install_target.detect_toolchain(self._working_dir)
                python_toolchain = toolchains.get("python")
                env_path = python_toolchain.env_path if python_toolchain else None
            base_cmd = self._install_target.build_install_command(
                ecosystem,
                [],
                self._story0_config.get("install_target", "project_local"),
                manager,
                env_path,
            )
            cmd = [*base_cmd, "-r", "requirements-dev.txt"]
            status, detail = self._run_install(cmd)
        else:
            # Single package install with LLM retry on failure
            status, detail = self._install_with_llm_retry(
                raw_name=raw_name,
                ecosystem=ecosystem,
                max_retries=3,
            )

        if status == PrerequisiteStatus.INSTALLED.value:
            source_key = "manifest" if source == "MANIFEST" else "inferred"
            self._installs_by_source.setdefault(source_key, []).append(raw_name)
            self._emit_progress(f"[Story0] Installed from {source_key}: {raw_name}")
            self._emit_decision_event(
                "package_installed",
                {
                    "mode": self._automation_mode_effective or "auto_safe",
                    "ecosystem": ecosystem,
                    "packages": [raw_name] if raw_name else None,
                    "target": self._story0_config.get("install_target"),
                    "reason": "",
                },
            )
        return status, detail

    def _ecosystem_from_manifest(self, manifest: str | None) -> str:
        if not manifest:
            return "python"
        if manifest in ("pyproject.toml", "requirements-dev.txt", "requirements.txt"):
            return "python"
        if manifest == "package.json":
            return "node"
        if manifest == "Cargo.toml":
            return "rust"
        if manifest == "go.mod":
            return "go"
        if manifest == "Gemfile":
            return "ruby"
        return "python"

    def _should_install(self, prereq: dict[str, Any], source: str) -> tuple[bool, str]:
        install_policy = self._story0_config.get("install_policy", "manifest_then_inferred")
        allow_inferred = self._story0_config.get("allow_inferred_installs", True)
        mode = self._config.get("automation_mode", "auto_safe")
        normalized_source = source.upper()

        if install_policy == "manifest_only" and normalized_source != "MANIFEST":
            return (
                False,
                f"policy={install_policy}. Hint: Use automation_mode=auto_full to allow "
                "unrestricted installs.",
            )
        if install_policy == "manifest_then_inferred":
            if normalized_source == "INFERRED" and not allow_inferred:
                return (
                    False,
                    "inferred installs disabled. Hint: Use automation_mode=auto_full to "
                    "allow inferred installs.",
                )
        if install_policy not in (
            "manifest_only",
            "manifest_then_inferred",
            "manifest_or_inferred",
        ):
            return False, f"unsupported install policy: {install_policy}"

        if normalized_source == "INFERRED":
            self._emit_decision_event(
                "policy_applied",
                {
                    "mode": self._automation_mode_effective or "auto_safe",
                    "ecosystem": prereq.get("ecosystem"),
                    "packages": [prereq.get("name")] if prereq.get("name") else None,
                    "target": self._story0_config.get("install_target"),
                    "reason": f"policy={install_policy}",
                },
            )

        if normalized_source == "INFERRED":
            ecosystem = str(prereq.get("ecosystem") or "").strip().lower()
            if not ecosystem:
                ecosystem = self._ecosystem_from_manifest(prereq.get("manifest_type"))
            if mode != "auto_full":
                allowed, kind = self._is_in_allowlist(str(prereq.get("name") or ""), ecosystem)
                if not allowed:
                    return (
                        False,
                        f"{prereq.get('name')} not in allowlist. Hint: Add to "
                        f"inferred_install_allowlist.{ecosystem} or use auto_full mode.",
                    )
                if mode == "auto_safe" and kind == "runtime":
                    if not self._objective_mentions_package(str(prereq.get("name") or "")):
                        return (
                            False,
                            "runtime install blocked in auto_safe mode. Hint: Use "
                            "automation_mode=auto_full to allow runtime installs.",
                        )
        return True, ""

    def _is_in_allowlist(self, package: str, ecosystem: str) -> tuple[bool, str]:
        allowlist = self._config.get("inferred_install_allowlist", {})
        if not isinstance(allowlist, dict) or not allowlist:
            return True, "both"
        entries = []
        entries.extend(allowlist.get("_common", []))
        entries.extend(allowlist.get(ecosystem, []))
        package_lower = package.lower()
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            name = str(entry.get("name") or "").lower()
            if name and name == package_lower:
                kind = str(entry.get("kind") or "both").lower()
                if kind not in {"dev", "runtime", "both"}:
                    kind = "both"
                return True, kind
        return False, "unknown"

    def _objective_mentions_package(self, package: str) -> bool:
        if not package:
            return False
        objective_text = self._objective.lower()
        return package.lower() in objective_text

    def _emit_decision_event(self, event_type: str, data: dict[str, Any]) -> None:
        if not self._on_progress or not self._log_decisions:
            return
        payload = {
            "type": event_type,
            "timestamp": datetime.now(UTC).isoformat(),
            "mode": data.get("mode", self._automation_mode_effective),
            "ecosystem": data.get("ecosystem"),
            "packages": data.get("packages"),
            "target": data.get("target"),
            "reason": data.get("reason"),
        }
        with contextlib.suppress(Exception):
            self._on_progress(event_type, payload)

    def _detect_existing_manifests(self) -> list[str]:
        manifest_names = set(MANIFEST_TYPE_MAP.values())
        manifest_names.update(
            [
                "requirements.txt",
                "requirements-dev.txt",
                "Pipfile",
                "Pipfile.lock",
                "poetry.lock",
                "uv.lock",
            ]
        )
        if not self._working_dir.exists():
            return []
        found: list[str] = []
        for name in sorted(manifest_names):
            for path in self._working_dir.rglob(name):
                if not path.is_file():
                    continue
                try:
                    found.append(str(path.relative_to(self._working_dir)))
                except ValueError:
                    found.append(str(path))
        return found

    def _install_python_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "")
        cmd = ["python", "-m", "pip", "install", name]
        return self._run_install(cmd)

    def _install_requirements_dev(self, prereq: dict[str, Any]) -> tuple[str, str]:
        cmd = ["python", "-m", "pip", "install", "-r", "requirements-dev.txt"]
        return self._run_install(cmd)

    def _install_node_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "")
        cmd = ["npm", "install", name]
        return self._run_install(cmd)

    def _install_rust_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "")
        cmd = ["cargo", "add", name]
        return self._run_install(cmd)

    def _install_go_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "")
        cmd = ["go", "get", name]
        return self._run_install(cmd)

    def _install_ruby_dependency(self, prereq: dict[str, Any]) -> tuple[str, str]:
        name = prereq.get("name", "")
        cmd = ["bundle", "add", name]
        return self._run_install(cmd)

    def _install_with_llm_retry(
        self,
        raw_name: str,
        ecosystem: str,
        max_retries: int = 3,
    ) -> tuple[str, str]:
        """Install a package with LLM-assisted retry on failure.

        Flow:
        1. Pattern-match normalize the original name → pip install
        2. If fails: LLM analyzes error → suggests fix → pip install (no pattern matching)
        3. Repeat up to max_retries times
        4. Return failure after max_retries

        Args:
            raw_name: Original package name from LLM inference
            ecosystem: Target ecosystem (python, node, etc.)
            max_retries: Maximum LLM retry attempts (default 3)

        Returns:
            Tuple of (status, detail)
        """
        if not raw_name:
            return (PrerequisiteStatus.FAILED.value, "Missing package name")

        # Build install command helper
        def build_cmd(package_name: str) -> list[str]:
            manager = self._install_target.get_package_manager(
                ecosystem,
                self._story0_config.get("package_manager_preference", {}).get(ecosystem, "auto"),
                self._working_dir,
            )
            env_path = None
            if ecosystem == "python":
                toolchains = self._install_target.detect_toolchain(self._working_dir)
                python_toolchain = toolchains.get("python")
                env_path = python_toolchain.env_path if python_toolchain else None
            return self._install_target.build_install_command(
                ecosystem,
                [package_name],
                self._story0_config.get("install_target", "project_local"),
                manager,
                env_path,
            )

        # Attempt 1: Pattern-match normalization on original name
        normalized_name = self._install_target.normalize_inferred_package_name(raw_name)
        if not normalized_name:
            return (
                PrerequisiteStatus.FAILED.value,
                f"Empty package name after normalization: {raw_name}",
            )

        cmd = build_cmd(normalized_name)
        status, error = self._run_install(cmd)

        if status == PrerequisiteStatus.INSTALLED.value:
            return (status, error)

        # Track attempt history for LLM context
        attempts: list[dict[str, str]] = [{"package": normalized_name, "error": error}]

        # LLM retry loop (no pattern matching on LLM suggestions)
        for retry_num in range(max_retries):
            llm_suggestion = self._llm_fix_package_name(
                raw_name=raw_name,
                ecosystem=ecosystem,
                attempts=attempts,
            )

            if llm_suggestion is None:
                # LLM unavailable, skip retries
                logger.warning("LLM unavailable for install retry, giving up")
                break

            if llm_suggestion.upper() == "SKIP":
                # LLM determined this is not installable
                detail = f"LLM determined not pip-installable: {raw_name}"
                self._emit_progress(f"[Story0] Skipped: {raw_name} ({detail})")
                return (PrerequisiteStatus.SKIPPED.value, detail)

            # Try LLM's suggestion (no pattern matching)
            self._emit_progress(
                f"[Story0] Retry {retry_num + 1}/{max_retries}: trying '{llm_suggestion}' for '{raw_name}'"
            )
            cmd = build_cmd(llm_suggestion)
            status, error = self._run_install(cmd)

            if status == PrerequisiteStatus.INSTALLED.value:
                return (status, error)

            attempts.append({"package": llm_suggestion, "error": error})

        # All retries exhausted
        return (PrerequisiteStatus.FAILED.value, error)

    def _llm_fix_package_name(
        self,
        raw_name: str,
        ecosystem: str,
        attempts: list[dict[str, str]],
    ) -> str | None:
        """Ask LLM to fix a failed package install.

        Args:
            raw_name: Original package name from inference
            ecosystem: Target ecosystem
            attempts: List of {"package": name, "error": error_msg} for prior attempts

        Returns:
            Suggested package name, "SKIP" if not installable, or None if LLM unavailable
        """
        if not self._llm_config:
            return None

        # Build attempt history for context
        history_lines = []
        for i, attempt in enumerate(attempts, 1):
            history_lines.append(
                f"Attempt {i}: '{attempt['package']}'\n"
                f"Error: {attempt['error'][:500]}"  # Truncate long errors
            )
        history = "\n\n".join(history_lines)

        prompt = f"""A package install failed. Analyze the errors and suggest the correct package name.

Original requested package: "{raw_name}"
Ecosystem: {ecosystem}

{history}

Instructions:
- If this is a language runtime (Python, Node.js, Go, etc.), respond with just: SKIP
- If this is a stdlib module that can't be pip-installed (tkinter, sqlite3), respond with just: SKIP
- If you can determine the correct package name, respond with just the package name (nothing else)
- If you're unsure, respond with just: SKIP

Your response (package name or SKIP):"""

        try:
            pipeline = TemplateEditPipeline(
                working_dir=self._working_dir,
                action_name="story0_install_fix",
            )

            # Simple text response, no JSON structure needed
            result, _meta = pipeline.execute(
                base_prompt=prompt,
                template_schema={"suggestion": ""},
                validator=lambda d: (bool(d.get("suggestion")), "Missing suggestion"),
                fallback_fn=lambda: {"suggestion": "SKIP"},
                llm_config=self._llm_config,
                max_retries=1,  # Fast, single attempt
            )

            suggestion = str(result.get("suggestion", "")).strip()
            if not suggestion:
                return "SKIP"

            # Clean up response (LLM might add quotes or extra text)
            suggestion = suggestion.strip("\"'` \n")
            if " " in suggestion and suggestion.upper() != "SKIP":
                # Multi-word response that isn't SKIP - probably explanation, skip it
                logger.debug("LLM returned multi-word response, treating as SKIP: %s", suggestion)
                return "SKIP"

            return suggestion

        except Exception as exc:
            logger.warning("LLM install fix failed: %s", exc)
            return None

    def _run_install(self, cmd: list[str]) -> tuple[str, str]:
        timeout_seconds = get_story0_timeout()
        logger.info("Running install command: %s", " ".join(cmd))
        result = subprocess.run(
            cmd,
            cwd=self._working_dir,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
        output = result.stdout.strip() or result.stderr.strip()
        if result.returncode == 0:
            return (PrerequisiteStatus.INSTALLED.value, output)
        return (PrerequisiteStatus.FAILED.value, output)

    def _default_service_port(self, name: str) -> int | None:
        # Normalize service names (postgresql -> postgres, mongo -> mongodb)
        normalized = name
        if name == "postgresql":
            normalized = "postgres"
        elif name == "mongo":
            normalized = "mongodb"
        return get_story0_port_mapping(normalized)

    def _service_image(self, name: str) -> str:
        # Normalize service names (postgresql -> postgres, mongo -> mongodb)
        normalized = name
        if name == "postgresql":
            normalized = "postgres"
        elif name == "mongo":
            normalized = "mongodb"
        return get_story0_service_image(normalized)

    def _resolve_container_port(self, container_name: str) -> int | None:
        result = subprocess.run(
            ["docker", "port", container_name],
            capture_output=True,
            text=True,
            check=False,
        )
        for line in result.stdout.splitlines():
            if "->" in line:
                right = line.split("->", maxsplit=1)[-1].strip()
                if ":" in right:
                    try:
                        return int(right.split(":")[-1])
                    except ValueError:
                        continue
        return None

    def _docker_available(self) -> bool:
        try:
            result = subprocess.run(
                ["docker", "info"],
                capture_output=True,
                text=True,
                check=False,
            )
            return result.returncode == 0
        except FileNotFoundError:
            return False

    def _check_tcp(self, host: str, port: int) -> bool:
        try:
            with socket.create_connection(
                (host, port), timeout=int(get_timeout("handler", "socket_connect_s"))
            ):
                return True
        except OSError:
            return False

    def _wait_for_service(self, host: str, port: int, attempts: int = 20) -> bool:
        for _ in range(attempts):
            if self._check_tcp(host, port):
                return True
            time.sleep(0.2)
        return False

    def _compute_manifest_hash(self) -> str | None:
        manifest_candidates = ["pyproject.toml", "package.json"]
        for filename in manifest_candidates:
            path = self._working_dir / filename
            if path.exists():
                content = path.read_bytes()
                return hashlib.sha256(content).hexdigest()
        return None

    def _create_manifest(self, manifest_type: str, project_type: str) -> None:
        if not manifest_type:
            return
        manifest_path = self._working_dir / manifest_type
        if manifest_path.exists():
            if self._story0_config.get("never_overwrite_manifest", True):
                self._emit_progress(
                    f"[Story0] Skipped: {manifest_path.name} exists; never_overwrite_manifest=true"
                )
                return
        if manifest_type == "package.json":
            payload = {"name": project_type or "obra-project", "version": "0.1.0"}
            manifest_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        elif manifest_type == "pyproject.toml":
            manifest_path.write_text(
                '[project]\nname = "obra-project"\nversion = "0.1.0"\n',
                encoding="utf-8",
            )
        elif manifest_type == "Cargo.toml":
            manifest_path.write_text(
                '[package]\nname = "obra_project"\nversion = "0.1.0"\n',
                encoding="utf-8",
            )
        elif manifest_type == "go.mod":
            manifest_path.write_text("module obra_project\n\ngo 1.21\n", encoding="utf-8")
        elif manifest_type == "Gemfile":
            manifest_path.write_text('source "https://rubygems.org"\n', encoding="utf-8")
        else:
            manifest_path.write_text("", encoding="utf-8")

    def _create_structure(self, structure: Any, base: Path | None = None) -> None:
        base = base or self._working_dir
        if isinstance(structure, dict):
            for key, value in structure.items():
                path = base / str(key)
                if isinstance(value, (dict, list)):
                    path.mkdir(parents=True, exist_ok=True)
                    self._create_structure(value, path)
                else:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.touch(exist_ok=True)
        elif isinstance(structure, list):
            for item in structure:
                self._create_structure(item, base)

    def _coerce_prereq(self, prereq: dict[str, Any]) -> Prerequisite:
        category = prereq.get("category", PrerequisiteCategory.AUTO)
        source = prereq.get("source", PrerequisiteSource.INFERRED)
        try:
            category = PrerequisiteCategory(category)
        except ValueError:
            category = PrerequisiteCategory.AUTO
        try:
            source = PrerequisiteSource(source)
        except ValueError:
            source = PrerequisiteSource.INFERRED
        return Prerequisite(
            id=str(prereq.get("id") or prereq.get("name") or "unknown"),
            category=category,
            name=str(prereq.get("name") or "unknown"),
            source=source,
            reason=str(prereq.get("reason") or ""),
            status=PrerequisiteStatus.PENDING,
        )

    def _is_blocking(self, category: PrerequisiteCategory) -> bool:
        # In mock_credentials mode, service and credential failures are non-blocking
        # since the user is running in simulation mode
        if self._story0_config.get("mock_credentials") and category in (
            PrerequisiteCategory.CREDENTIAL,
            PrerequisiteCategory.SERVICE,
        ):
            return False
        return category in (
            PrerequisiteCategory.CREDENTIAL,
            PrerequisiteCategory.SERVICE,
            PrerequisiteCategory.USER_ACTION,
            PrerequisiteCategory.ACCOUNT,
        )

    def _finalize_result(
        self,
        status: str,
        completed: list[str],
        failed: list[str],
        skipped: list[str],
        blocking_failures: list[str],
        non_blocking_failures: list[str],
        verification_tools: dict[str, Any],
    ) -> Story0Result:
        verification_tools = self._sanitize_verification_tools(verification_tools)
        self._verification_tools_state = verification_tools
        if status == "complete":
            self._save_state(status=Story0Status.COMPLETE)
        elif status == "failed":
            self._save_state(status=Story0Status.FAILED)
        else:
            self._save_state(status=Story0Status.PARTIAL)
        return Story0Result(
            status=status,
            completed=completed,
            failed=failed,
            skipped=skipped,
            blocking_failures=blocking_failures,
            non_blocking_failures=non_blocking_failures,
            state_path=self._state_path,
            verification_tools=verification_tools,
            mocked_credentials=self._mocked_credentials,
        )

    @staticmethod
    def _sanitize_verification_tools(
        verification_tools: dict[str, Any],
    ) -> dict[str, Any]:
        if not isinstance(verification_tools, dict):
            return {}
        allowed_keys = {"available", "missing", "source"}
        return {key: value for key, value in verification_tools.items() if key in allowed_keys}

    def _discover_verification_tools(
        self,
        force_refresh: bool | None = None,
    ) -> dict[str, Any]:
        return resolve_verification_tools(
            self._working_dir,
            self._llm_config,
            self._config,
            existing=self._verification_tools_state,
            prefer_existing=True,
            force_refresh=force_refresh,
        )

    def _run_verification_preflight(
        self,
        missing_tools: list[str] | None,
    ) -> Story0Result:
        from obra.config.loaders import (
            get_verification_auto_install,
            get_verification_discovery_enabled,
            get_verification_force_refresh,
            get_verification_tool_installs,
        )

        self._emit_story0_event(
            "verification_preflight_started",
            {"message": "Verification tools missing → running preflight"},
        )

        verification_tools = self._discover_verification_tools()
        missing_seed = missing_tools or verification_tools.get("missing", []) or []
        missing = {tool.strip() for tool in missing_seed if isinstance(tool, str) and tool.strip()}
        available = {
            tool.strip()
            for tool in (verification_tools.get("available", []) or [])
            if isinstance(tool, str) and tool.strip()
        }
        missing_list = sorted(missing - available)

        if not missing_list:
            self._emit_story0_event(
                "verification_preflight_completed",
                {"message": "Verification preflight complete"},
            )
            return self._finalize_result(
                status="complete",
                completed=[],
                failed=[],
                skipped=[],
                blocking_failures=[],
                non_blocking_failures=[],
                verification_tools=verification_tools,
            )

        install_map = get_verification_tool_installs()
        discovery_tooling: dict[str, Any] = {}
        if get_verification_discovery_enabled():
            discovery_tooling = self._tooling_discovery.discover(
                force_refresh=get_verification_force_refresh()
            )
        install_plan = self._build_verification_install_plan(
            missing_list,
            install_map,
            discovery_tooling,
        )
        install_plan = self._filter_install_plan(install_plan)
        missing_installs = [category for category, commands in install_plan.items() if not commands]

        # Bug fix: Check auto_install BEFORE early return for missing_installs
        # When auto_full mode is enabled, use default install commands for Python tools
        auto_install = get_verification_auto_install()
        mode = self._config.get("automation_mode", "auto_safe")
        if missing_installs and auto_install and mode == "auto_full":
            # Apply default install commands for common Python verification tools
            default_installs = self._get_default_verification_installs(missing_installs)
            for category, commands in default_installs.items():
                if commands:
                    install_plan[category] = commands
            # Re-check missing_installs after applying defaults
            missing_installs = [
                category for category, commands in install_plan.items() if not commands
            ]

        installable = [category for category, commands in install_plan.items() if commands]

        if missing_installs:
            message = (
                "No install commands configured for verification tools: "
                f"{', '.join(sorted(missing_installs))}.\n"
                "Add install commands under fix.verification.tools[].install or enable "
                "discovery to populate install commands."
            )
            self._emit_progress(message)
            self._emit_story0_event(
                "verification_preflight_completed",
                {"message": "Verification preflight complete"},
            )
            return self._finalize_result(
                status="complete",
                completed=[],
                failed=[],
                skipped=[],
                blocking_failures=[],
                non_blocking_failures=[],
                verification_tools=verification_tools,
            )
        if not auto_install:
            if not self._is_tty:
                message = self._build_install_instructions(install_plan)
                self._emit_progress(message)
                self._emit_story0_event(
                    "verification_preflight_completed",
                    {"message": "Verification preflight complete"},
                )
                return self._finalize_result(
                    status="complete",
                    completed=[],
                    failed=[],
                    skipped=[],
                    blocking_failures=[],
                    non_blocking_failures=[],
                    verification_tools=verification_tools,
                )

            prompt = (
                "Missing verification tools: "
                f"{', '.join(sorted(installable))}.\n"
                "Install now? [y/N] "
            )
            response = self._prompt_text(prompt, default="n")
            if response is None or response.strip().lower().startswith("n"):
                message = self._build_install_instructions(install_plan)
                self._emit_progress(message)
                self._emit_story0_event(
                    "verification_preflight_completed",
                    {"message": "Verification preflight complete"},
                )
                return self._finalize_result(
                    status="complete",
                    completed=[],
                    failed=[],
                    skipped=[],
                    blocking_failures=[],
                    non_blocking_failures=[],
                    verification_tools=verification_tools,
                )

        self._emit_story0_event(
            "verification_preflight_installing",
            {"message": f"Installing: {', '.join(sorted(installable))}"},
        )
        installed_categories: list[str] = []
        for category, commands in install_plan.items():
            for command in commands:
                self._run_verification_install(command, category)
            # Track which categories we installed
            if commands:
                installed_categories.append(category)

        # After installing tools, resolve and merge with prior state to avoid downgrades.
        verification_tools = resolve_verification_tools(
            self._working_dir,
            self._llm_config,
            self._config,
            existing=verification_tools,
            prefer_existing=True,
            force_refresh=True,
        )
        verification_tools = merge_verification_tools(
            self._verification_tools_state,
            verification_tools,
            prefer_existing=True,
        )
        if installed_categories:
            available_sorted = sorted(
                set(verification_tools.get("available", [])) | set(installed_categories)
            )
            missing_sorted = sorted(
                set(verification_tools.get("missing", [])) - set(available_sorted)
            )
            verification_tools = {
                "available": available_sorted,
                "missing": missing_sorted,
                "source": "install",
            }
        # Debug: Log what verification_tools we're returning
        logger.info(
            "Verification preflight complete - returning verification_tools: %s",
            verification_tools,
        )
        self._emit_story0_event(
            "verification_preflight_completed",
            {"message": "Verification preflight complete"},
        )
        return self._finalize_result(
            status="complete",
            completed=[],
            failed=[],
            skipped=[],
            blocking_failures=[],
            non_blocking_failures=[],
            verification_tools=verification_tools,
        )

    def _build_install_instructions(self, install_plan: dict[str, list[str]]) -> str:
        lines = ["Install verification tools with the following commands:"]
        for category, commands in sorted(install_plan.items()):
            if not commands:
                continue
            lines.append(f"  {category}:")
            for command in commands:
                lines.append(f"    - {command}")
        return "\n".join(lines)

    def _run_verification_install(self, command: str, category: str) -> None:
        import shlex

        if not self._is_safe_install_command(command):
            self._emit_progress(f"Install command rejected for {category}: {command}")
            return

        try:
            cmd = shlex.split(command)
        except ValueError:
            self._emit_progress(f"Install command invalid for {category}: {command}")
            return

        try:
            result = subprocess.run(
                cmd,
                check=False,
                capture_output=True,
                text=True,
                cwd=self._working_dir,
                timeout=get_story0_docker_timeout(),
            )
        except subprocess.TimeoutExpired:
            self._emit_progress(f"Install command timed out for {category}: {command}")
            return
        except Exception as exc:
            self._emit_progress(f"Install command failed for {category}: {command}\n{exc}")
            return

        if result.returncode != 0:
            detail = result.stderr.strip() or result.stdout.strip() or "Unknown error"
            self._emit_progress(f"Install command failed for {category}: {command}\n{detail}")

    def _build_verification_install_plan(
        self,
        missing: list[str],
        config_installs: dict[str, list[str]],
        discovery_tooling: dict[str, Any],
    ) -> dict[str, list[str]]:
        plan: dict[str, list[str]] = {}
        for category in missing:
            commands = config_installs.get(category, [])
            if not commands:
                commands = self._extract_discovery_installs(discovery_tooling, category)
            plan[category] = list(commands) if commands else []
        return plan

    def _get_default_verification_installs(
        self,
        missing_categories: list[str],
    ) -> dict[str, list[str]]:
        """Get default install commands for common verification tools.

        Used when auto_full mode is enabled and discovery doesn't provide
        install commands. Returns pip install commands for Python tools.
        """
        # Default install commands for Python verification tools
        # These match the tools used by the FIX handler's auto-install
        defaults: dict[str, list[str]] = {
            "tests": ["pip install pytest"],
            "lint": ["pip install ruff"],
            "typecheck": ["pip install mypy"],
        }
        return {
            category: defaults.get(category, [])
            for category in missing_categories
            if category in defaults
        }

    def _extract_discovery_installs(
        self,
        discovery_tooling: dict[str, Any],
        category: str,
    ) -> list[str]:
        if not isinstance(discovery_tooling, dict):
            return []
        verification = discovery_tooling.get("verification", {})
        if not isinstance(verification, dict):
            return []
        lookup = "test" if category == "tests" else category
        entry = verification.get(lookup, {})
        if not isinstance(entry, dict):
            return []
        install = entry.get("install", [])
        if isinstance(install, str):
            install = [install]
        if not isinstance(install, list):
            return []
        return [str(cmd).strip() for cmd in install if str(cmd).strip()]

    def _filter_install_plan(self, install_plan: dict[str, list[str]]) -> dict[str, list[str]]:
        filtered: dict[str, list[str]] = {}
        for category, commands in install_plan.items():
            safe_commands = []
            for command in commands:
                if self._is_safe_install_command(command):
                    safe_commands.append(command)
                else:
                    self._emit_progress(f"Install command rejected for {category}: {command}")
            filtered[category] = safe_commands
        return filtered

    @staticmethod
    def _is_safe_install_command(command: str) -> bool:
        import shlex

        try:
            tokens = shlex.split(command)
        except ValueError:
            return False
        if not tokens:
            return False
        first = tokens[0].lower()
        allowed = {
            "pip",
            "pip3",
            "pipx",
            "pipenv",
            "poetry",
            "uv",
            "python",
            "python3",
            "npm",
            "yarn",
            "pnpm",
            "bun",
            "cargo",
            "go",
            "dotnet",
            "gem",
            "bundle",
            "composer",
            "mvn",
            "gradle",
            "./gradlew",
            "./mvnw",
        }
        if first not in allowed:
            return False
        lowered = command.lower()
        blocked_tokens = [
            "curl ",
            "wget ",
            "sudo",
            "powershell",
            "pwsh",
            "bash",
            " sh ",
            "|",
            "&&",
            "||",
            ";",
            "http://",
            "https://",
        ]
        return not any(token in lowered for token in blocked_tokens)


def cleanup_containers(session_id: str) -> int:
    """Stop and remove Obra-managed Docker containers for a session."""
    containers = _list_containers_by_label(f"obra.session={session_id}")
    if not containers:
        return 0
    cleaned = 0
    for name in containers:
        subprocess.run(["docker", "stop", name], capture_output=True, text=True, check=False)
        subprocess.run(["docker", "rm", name], capture_output=True, text=True, check=False)
        cleaned += 1
    logger.info("Cleaned up %d Obra-managed containers", cleaned)
    return cleaned


def check_orphaned_containers(is_tty: bool = True) -> int:
    """Offer cleanup for orphaned Obra-managed containers."""
    containers = _list_containers_by_label("obra.managed=true")
    if not containers:
        return 0
    session_groups: dict[str, list[str]] = defaultdict(list)
    for name in containers:
        labels = _get_container_labels(name)
        session_id = labels.get("obra.session", "unknown")
        session_groups[session_id].append(name)

    total = sum(len(items) for items in session_groups.values())
    if not is_tty:
        logger.info(
            "Found %d Obra-managed containers (non-interactive); skipping cleanup prompt",
            total,
        )
        return 0

    response = _prompt_cleanup(
        f"Found {total} orphaned containers from previous sessions. Clean up? [Y/n] "
    )
    if response is None or response.strip().lower().startswith("n"):
        return 0

    cleaned = 0
    for names in session_groups.values():
        for name in names:
            subprocess.run(["docker", "stop", name], capture_output=True, text=True, check=False)
            subprocess.run(["docker", "rm", name], capture_output=True, text=True, check=False)
            cleaned += 1
    logger.info("Cleaned up %d orphaned Obra-managed containers", cleaned)
    return cleaned


def _list_containers_by_label(label: str) -> list[str]:
    try:
        result = subprocess.run(
            [
                "docker",
                "ps",
                "-a",
                "--filter",
                f"label={label}",
                "--format",
                "{{.Names}}",
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        return [line.strip() for line in result.stdout.splitlines() if line.strip()]
    except FileNotFoundError:
        return []


def _get_container_labels(container_name: str) -> dict[str, str]:
    try:
        result = subprocess.run(
            [
                "docker",
                "inspect",
                container_name,
                "--format",
                "{{json .Config.Labels}}",
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.stdout.strip():
            return json.loads(result.stdout.strip()) or {}
    except Exception:
        return {}
    return {}


def _prompt_cleanup(prompt: str) -> str | None:
    print_info(prompt)
    try:
        response = input().strip()
    except EOFError:
        return None
    return response


__all__ = [
    "Story0Handler",
    "Story0Result",
    "check_orphaned_containers",
    "cleanup_containers",
]
