"""Simple LLM Configuration View widget.

Provides a simple interface with a one-click provider selector that auto-populates
detailed settings, plus manual override capability for orchestrator and implementation.
"""

from __future__ import annotations

from typing import Any

from textual.app import ComposeResult
from textual.containers import Horizontal, ScrollableContainer, Vertical
from textual.message import Message
from textual.widgets import Label, Rule, Select, Static

from obra.config.explorer.llm_registry import (
    build_tier_preview,
    get_model_cost,
    get_models,
    get_providers,
    resolve_tier_model_display,
)
from obra.config.explorer.widgets.navigation_menu import get_menu_info
from obra.config.explorer.widgets.saveable_view import SaveableViewMixin


class SimpleLLMView(SaveableViewMixin, Static):
    """Simple LLM configuration view with one-click provider + detailed settings.

    Features:
    - One-Click Setting: Pick a provider and auto-populate all settings
    - Detailed Settings: Manual control over orchestrator and implementation
      providers and models (4 dropdowns total)

    Emits:
        Changed: When any configuration changes.
    """

    DEFAULT_CSS = """
    SimpleLLMView {
        width: 100%;
        height: 100%;
        padding: 1 2;
    }

    SimpleLLMView > Vertical {
        width: 100%;
        height: 100%;
        align: center top;
    }

    SimpleLLMView #content-scroll {
        width: 100%;
        height: 1fr;
        min-height: 10;
        min-width: 80;
    }

    SimpleLLMView .header {
        text-style: bold;
        text-align: center;
        margin-bottom: 1;
        width: 100%;
    }

    SimpleLLMView .description {
        color: $text-muted;
        text-align: center;
        margin-bottom: 2;
        width: 100%;
    }

    SimpleLLMView .section-header {
        text-style: bold;
        margin-top: 1;
        margin-bottom: 1;
        color: $primary;
    }

    SimpleLLMView .one-click-section {
        width: 100%;
        height: auto;
        padding: 1;
        background: $surface;
        margin-bottom: 1;
    }

    SimpleLLMView .one-click-row {
        width: 100%;
        height: auto;
    }

    SimpleLLMView .one-click-label {
        width: 20;
    }

    SimpleLLMView .one-click-select {
        width: 1fr;
    }

    SimpleLLMView .detailed-section {
        width: 100%;
        height: auto;
        padding: 1;
    }

    SimpleLLMView .role-section {
        width: 100%;
        height: auto;
        margin-bottom: 1;
    }

    SimpleLLMView .role-header {
        text-style: bold;
        margin-bottom: 0;
    }

    SimpleLLMView .role-row {
        width: 100%;
        height: auto;
        margin-bottom: 1;
    }

    SimpleLLMView .role-label {
        width: 15;
    }

    SimpleLLMView .role-select {
        width: 1fr;
    }

    SimpleLLMView .model-hint {
        color: $text-muted;
        margin-left: 15;
        margin-bottom: 1;
    }

    SimpleLLMView .model-hint-resolved {
        color: $success;
    }

    SimpleLLMView .help-text {
        color: $text-muted;
        margin-top: 2;
        text-align: center;
    }

    SimpleLLMView .preview-box {
        width: 100%;
        height: auto;
        min-height: 6;
        margin-top: 2;
        padding: 1 2;
        background: $surface;
        border: solid $primary-darken-2;
        text-align: left;
    }

    SimpleLLMView .preview-title {
        text-style: bold;
        margin-bottom: 1;
    }

    SimpleLLMView .preview-content {
        color: $text;
    }

    SimpleLLMView Rule {
        margin: 1 0;
    }
    """

    class Changed(Message):
        """Message emitted when LLM configuration changes."""

        def __init__(
            self,
            orchestrator_provider: str,
            orchestrator_model: str,
            implementation_provider: str,
            implementation_model: str,
        ) -> None:
            """Initialize the Changed message.

            Args:
                orchestrator_provider: Selected orchestrator provider ID
                orchestrator_model: Selected orchestrator model ID
                implementation_provider: Selected implementation provider ID
                implementation_model: Selected implementation model ID
            """
            super().__init__()
            self.orchestrator_provider = orchestrator_provider
            self.orchestrator_model = orchestrator_model
            self.implementation_provider = implementation_provider
            self.implementation_model = implementation_model

    def __init__(
        self,
        current_provider: str = "anthropic",
        current_model: str = "default",
        orchestrator_provider: str | None = None,
        orchestrator_model: str | None = None,
        implementation_provider: str | None = None,
        implementation_model: str | None = None,
        **kwargs,
    ) -> None:
        """Initialize the SimpleLLMView.

        Args:
            current_provider: Default provider (for backward compat)
            current_model: Default model (for backward compat)
            orchestrator_provider: Orchestrator provider (overrides current_provider)
            orchestrator_model: Orchestrator model (overrides current_model)
            implementation_provider: Implementation provider (overrides current_provider)
            implementation_model: Implementation model (overrides current_model)
        """
        from obra.config.explorer.debug import is_debug_enabled, log_action

        super().__init__(**kwargs)
        # Use explicit values or fall back to current_provider/model
        self._orchestrator_provider = orchestrator_provider or current_provider
        self._orchestrator_model = orchestrator_model or current_model
        self._implementation_provider = implementation_provider or current_provider
        self._implementation_model = implementation_model or current_model
        # Track one-click selection (None = manual/mixed)
        self._one_click_provider: str | None = self._detect_one_click_provider()
        # Suppress change emissions during initial mount
        self._initializing = True

        if is_debug_enabled():
            log_action(
                "SimpleLLMView.__init__",
                f"_initializing=True, orch={self._orchestrator_provider}/{self._orchestrator_model}, "
                f"impl={self._implementation_provider}/{self._implementation_model}",
            )

        # Take snapshot for dirty tracking
        self._snapshot_state()

        if is_debug_enabled():
            log_action(
                "SimpleLLMView.__init__.snapshot",
                f"snapshot={self._initial_snapshot}",
            )

    def _detect_one_click_provider(self) -> str | None:
        """Detect if current settings match a one-click preset.

        Returns:
            Provider ID if all settings match a preset, None otherwise.
        """
        if self._orchestrator_provider != self._implementation_provider:
            return None  # Mixed providers = manual
        return self._orchestrator_provider

    def compose(self) -> ComposeResult:
        """Create the view content."""
        menu_info = get_menu_info("simple_llm")
        with Vertical():
            yield Static(menu_info["label"], classes="header")
            yield Static(menu_info["subtitle"], classes="description")

            with ScrollableContainer(id="content-scroll"):
                # One-Click Setting section
                with Vertical(classes="one-click-section"):
                    yield Static("One-Click Setting", classes="section-header")
                    with Horizontal(classes="one-click-row"):
                        yield Label("Provider", classes="one-click-label")
                        yield Select(
                            self._build_one_click_options(),
                            id="one-click-select",
                            value=self._one_click_provider or "manual",
                            allow_blank=False,
                            classes="one-click-select",
                        )

                yield Rule()

                # Detailed Settings section
                with Vertical(classes="detailed-section"):
                    yield Static("Detailed Settings", classes="section-header")

                    # Orchestrator section
                    with Vertical(classes="role-section"):
                        yield Static("Orchestrator (Planning)", classes="role-header")
                        with Horizontal(classes="role-row"):
                            yield Label("Provider", classes="role-label")
                            yield Select(
                                self._build_provider_options(),
                                id="orch-provider-select",
                                value=self._orchestrator_provider,
                                allow_blank=False,
                                classes="role-select",
                            )
                        with Horizontal(classes="role-row"):
                            yield Label("Model", classes="role-label")
                            yield Select(
                                self._build_model_options(self._orchestrator_provider),
                                id="orch-model-select",
                                value=self._orchestrator_model,
                                allow_blank=False,
                                classes="role-select",
                            )
                        yield Static("", id="orch-model-hint", classes="model-hint")

                    # Implementation section
                    with Vertical(classes="role-section"):
                        yield Static("Implementation (Execution)", classes="role-header")
                        with Horizontal(classes="role-row"):
                            yield Label("Provider", classes="role-label")
                            yield Select(
                                self._build_provider_options(),
                                id="impl-provider-select",
                                value=self._implementation_provider,
                                allow_blank=False,
                                classes="role-select",
                            )
                        with Horizontal(classes="role-row"):
                            yield Label("Model", classes="role-label")
                            yield Select(
                                self._build_model_options(self._implementation_provider),
                                id="impl-model-select",
                                value=self._implementation_model,
                                allow_blank=False,
                                classes="role-select",
                            )
                        yield Static("", id="impl-model-hint", classes="model-hint")

                # Preview box
                with Vertical(classes="preview-box"):
                    yield Static("What Obra will use:", classes="preview-title")
                    yield Static(
                        self._build_preview_text(),
                        id="preview-content",
                        classes="preview-content",
                    )

            yield Static(
                "One-Click applies Obra-recommended defaults.\n"
                "For tier-based config, use 'Configure LLM - Moderate' (press 2).",
                classes="help-text",
            )

    def on_mount(self) -> None:
        """Initialize preview and hints after widget is mounted."""
        from obra.config.explorer.debug import is_debug_enabled, log_action

        if is_debug_enabled():
            log_action(
                "SimpleLLMView.on_mount.start",
                f"_initializing={self._initializing}, state={self._get_saveable_state()}",
            )

        self._update_preview()
        self._update_model_hints()

        # CRITICAL: Use call_after_refresh to delay setting _initializing = False
        # until AFTER all queued Select.Changed events from initial value setting
        # have been processed. This prevents phantom changes from mount events.
        def finish_initialization() -> None:
            self._initializing = False
            # Re-snapshot state AFTER all mount events are processed
            # This ensures the snapshot matches the actual widget state
            self._snapshot_state()
            if is_debug_enabled():
                log_action(
                    "SimpleLLMView.on_mount.finish_init",
                    f"_initializing={self._initializing}, snapshot={self._initial_snapshot}",
                )

        self.call_after_refresh(finish_initialization)

        if is_debug_enabled():
            log_action(
                "SimpleLLMView.on_mount.end",
                f"_initializing still={self._initializing} (deferred to call_after_refresh)",
            )

    def _build_one_click_options(self) -> list[tuple[str, str]]:
        """Build options for the one-click provider selector.

        Returns:
            List of (display_text, value) tuples including 'Manual' option.
        """
        options = [("Manual (customize below)", "manual")]
        providers = get_providers()
        for provider_id, display_name, description in providers:
            label = f"{display_name} - {description}"
            options.append((label, provider_id))
        return options

    def _build_provider_options(self) -> list[tuple[str, str]]:
        """Build provider options for Select widget.

        Returns:
            List of (display_text, value) tuples for Select options.
        """
        providers = get_providers()
        options = []
        for provider_id, display_name, _description in providers:
            options.append((display_name, provider_id))
        return options

    def _build_model_options(self, provider: str) -> list[tuple[str, str]]:
        """Build model options for a specific provider.

        Options are sorted by tier: Recommended → High → Medium → Fast.
        Each option shows a cost indicator ($, $$, $$$).

        Args:
            provider: Provider ID to get models for.

        Returns:
            List of (display_text, value) tuples for Select options.
        """
        all_models = get_models()
        models = all_models.get(provider, all_models.get("anthropic", []))

        options = []
        for model_id, display, _tier in models:
            cost = get_model_cost(provider, model_id)
            # Recommended gets a star, others get cost indicator
            label = f"★  {display}" if model_id == "default" else f"{cost} {display}"
            options.append((label, model_id))
        return options

    def _build_preview_text(self) -> str:
        """Build preview text showing tier assignments side-by-side.

        Uses shared build_tier_preview for consistent display across views.
        """
        return build_tier_preview(
            orch_provider=self._orchestrator_provider,
            orch_model=self._orchestrator_model,
            impl_provider=self._implementation_provider,
            impl_model=self._implementation_model,
        )

    def _update_preview(self) -> None:
        """Update the preview box with current selection."""
        try:
            preview = self.query_one("#preview-content", Static)
            preview.update(self._build_preview_text())
        except Exception:
            pass

    def _get_model_hint(self, role: str, provider: str, model_id: str) -> str:
        """Get hint text showing resolved model for 'Let Obra choose'.

        Args:
            role: Role name (orchestrator, implementation)
            provider: Provider ID
            model_id: Current model selection (may be 'default')

        Returns:
            Hint text to display, or empty string if specific model chosen.
        """
        if model_id != "default":
            return ""

        # Show what Obra will use for medium tier (the default tier for single-model)
        resolved = resolve_tier_model_display(provider, role, "medium", "default")
        return f"→ {resolved} (and Obra picks per-tier models)"

    def _update_model_hints(self) -> None:
        """Update model hint labels to show resolved models."""
        try:
            # Orchestrator hint
            orch_hint = self.query_one("#orch-model-hint", Static)
            orch_text = self._get_model_hint(
                "orchestrator", self._orchestrator_provider, self._orchestrator_model
            )
            orch_hint.update(orch_text)
            orch_hint.set_class(bool(orch_text), "model-hint-resolved")

            # Implementation hint
            impl_hint = self.query_one("#impl-model-hint", Static)
            impl_text = self._get_model_hint(
                "implementation",
                self._implementation_provider,
                self._implementation_model,
            )
            impl_hint.update(impl_text)
            impl_hint.set_class(bool(impl_text), "model-hint-resolved")
        except Exception:
            pass

    def _update_one_click_indicator(self) -> None:
        """Update the one-click dropdown to reflect manual if settings diverged."""
        detected = self._detect_one_click_provider()
        if detected != self._one_click_provider:
            self._one_click_provider = detected
            try:
                one_click = self.query_one("#one-click-select", Select)
                one_click.value = detected or "manual"
            except Exception:
                pass

    def on_select_changed(self, event: Select.Changed) -> None:
        """Handle select widget changes."""
        from obra.config.explorer.debug import is_debug_enabled, log_action

        select_id = event.select.id

        if is_debug_enabled():
            log_action(
                "SimpleLLMView.on_select_changed",
                f"id={select_id}, value={event.value}, _initializing={self._initializing}",
            )

        # Skip processing during initial mount to prevent spurious state changes
        if self._initializing:
            if is_debug_enabled():
                log_action("SimpleLLMView.on_select_changed.SKIPPED", "still initializing")
            return

        # Handle Select.BLANK sentinel - use "default" as safe fallback
        value = "default" if event.value is Select.BLANK else str(event.value)

        if select_id == "one-click-select":
            self._handle_one_click_change(value)
        elif select_id == "orch-provider-select":
            self._handle_orch_provider_change(value)
        elif select_id == "orch-model-select":
            self._handle_orch_model_change(value)
        elif select_id == "impl-provider-select":
            self._handle_impl_provider_change(value)
        elif select_id == "impl-model-select":
            self._handle_impl_model_change(value)

    def _handle_one_click_change(self, value: str) -> None:
        """Handle one-click provider selection.

        When a provider is selected, set both roles to that provider with
        "default" model (Let Obra choose). The preview will show the actual
        models that will be used via ROLE_TIER_DEFAULTS.

        Args:
            value: Selected provider ID or 'manual'.
        """
        if value == "manual":
            self._one_click_provider = None
            return  # Don't change anything, user wants manual control

        self._one_click_provider = value

        # Set both roles to selected provider with "default" (Let Obra choose)
        # The preview will show the resolved models via ROLE_TIER_DEFAULTS
        self._orchestrator_provider = value
        self._orchestrator_model = "default"
        self._implementation_provider = value
        self._implementation_model = "default"

        # Update UI (includes hints via _update_all_dropdowns)
        self._update_all_dropdowns()
        self._update_preview()
        self._emit_change()

    def _update_all_dropdowns(self) -> None:
        """Update all 4 detail dropdowns and hints to reflect current state."""
        try:
            # Orchestrator provider
            orch_prov = self.query_one("#orch-provider-select", Select)
            orch_prov.value = self._orchestrator_provider

            # Orchestrator model
            orch_model = self.query_one("#orch-model-select", Select)
            orch_model.set_options(self._build_model_options(self._orchestrator_provider))
            orch_model.value = self._orchestrator_model

            # Implementation provider
            impl_prov = self.query_one("#impl-provider-select", Select)
            impl_prov.value = self._implementation_provider

            # Implementation model
            impl_model = self.query_one("#impl-model-select", Select)
            impl_model.set_options(self._build_model_options(self._implementation_provider))
            impl_model.value = self._implementation_model

            # Update hints
            self._update_model_hints()
        except Exception:
            pass

    def _handle_orch_provider_change(self, new_provider: str) -> None:
        """Handle orchestrator provider change."""
        self._orchestrator_provider = new_provider

        # Update model dropdown
        try:
            model_select = self.query_one("#orch-model-select", Select)
            new_options = self._build_model_options(new_provider)
            model_select.set_options(new_options)

            valid_ids = [opt[1] for opt in new_options]
            if self._orchestrator_model not in valid_ids:
                self._orchestrator_model = valid_ids[0] if valid_ids else "default"
                model_select.value = self._orchestrator_model
        except Exception:
            pass

        self._update_one_click_indicator()
        self._update_preview()
        self._update_model_hints()
        self._emit_change()

    def _handle_orch_model_change(self, new_model: str) -> None:
        """Handle orchestrator model change."""
        self._orchestrator_model = new_model
        self._update_one_click_indicator()
        self._update_preview()
        self._update_model_hints()
        self._emit_change()

    def _handle_impl_provider_change(self, new_provider: str) -> None:
        """Handle implementation provider change."""
        self._implementation_provider = new_provider

        # Update model dropdown
        try:
            model_select = self.query_one("#impl-model-select", Select)
            new_options = self._build_model_options(new_provider)
            model_select.set_options(new_options)

            valid_ids = [opt[1] for opt in new_options]
            if self._implementation_model not in valid_ids:
                self._implementation_model = valid_ids[0] if valid_ids else "default"
                model_select.value = self._implementation_model
        except Exception:
            pass

        self._update_one_click_indicator()
        self._update_preview()
        self._update_model_hints()
        self._emit_change()

    def _handle_impl_model_change(self, new_model: str) -> None:
        """Handle implementation model change."""
        self._implementation_model = new_model
        self._update_one_click_indicator()
        self._update_preview()
        self._update_model_hints()
        self._emit_change()

    def _emit_change(self) -> None:
        """Emit the Changed message with current configuration.

        Skips emission during initial mount to prevent spurious changes.
        """
        # Don't emit during initial mount - only after user interaction
        if self._initializing:
            return

        from obra.config.explorer.debug import is_debug_enabled, log_action

        if is_debug_enabled():
            log_action(
                "emit_changed",
                f"orch={self._orchestrator_provider}/{self._orchestrator_model}, "
                f"impl={self._implementation_provider}/{self._implementation_model}",
            )

        self.post_message(
            self.Changed(
                self._orchestrator_provider,
                self._orchestrator_model,
                self._implementation_provider,
                self._implementation_model,
            )
        )

    def set_values(
        self,
        provider: str | None = None,
        model: str | None = None,
        orchestrator_provider: str | None = None,
        orchestrator_model: str | None = None,
        implementation_provider: str | None = None,
        implementation_model: str | None = None,
    ) -> None:
        """Set the current values.

        Args:
            provider: Legacy single provider (used if specific values not provided)
            model: Legacy single model (used if specific values not provided)
            orchestrator_provider: Orchestrator provider
            orchestrator_model: Orchestrator model
            implementation_provider: Implementation provider
            implementation_model: Implementation model
        """
        # Use explicit values or fall back to legacy single values
        self._orchestrator_provider = orchestrator_provider or provider or "anthropic"
        self._orchestrator_model = orchestrator_model or model or "default"
        self._implementation_provider = implementation_provider or provider or "anthropic"
        self._implementation_model = implementation_model or model or "default"

        self._one_click_provider = self._detect_one_click_provider()
        self._update_all_dropdowns()
        self._update_one_click_indicator()
        self._update_preview()

    # --- SaveableViewMixin implementation ---

    def _get_saveable_state(self) -> dict[str, Any]:
        """Get current state for dirty tracking.

        Returns config paths mapped to current values.
        """
        return {
            "llm.orchestrator.provider": self._orchestrator_provider,
            "llm.orchestrator.model": self._orchestrator_model,
            "llm.implementation.provider": self._implementation_provider,
            "llm.implementation.model": self._implementation_model,
        }

    def _restore_state(self, state: dict[str, Any]) -> None:
        """Restore state from snapshot and update UI."""
        self._orchestrator_provider = state.get(
            "llm.orchestrator.provider", self._orchestrator_provider
        )
        self._orchestrator_model = state.get("llm.orchestrator.model", self._orchestrator_model)
        self._implementation_provider = state.get(
            "llm.implementation.provider", self._implementation_provider
        )
        self._implementation_model = state.get(
            "llm.implementation.model", self._implementation_model
        )
        self._one_click_provider = self._detect_one_click_provider()
        self._update_all_dropdowns()
        self._update_one_click_indicator()
        self._update_preview()
