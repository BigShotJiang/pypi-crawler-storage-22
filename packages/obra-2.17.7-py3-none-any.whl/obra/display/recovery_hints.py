"""Recovery hint helpers for consistent CLI messaging."""

import logging

from obra.messages.recovery import build_resume_hints

_logger = logging.getLogger(__name__)
_logger.debug("obra.display.recovery_hints is deprecated. Use obra.messages.recovery instead.")


def build_resume_continue_hints(session_id: str) -> str:
    """Return standard resume/continue guidance for a session."""
    return build_resume_hints(session_id)


def has_resume_continue_hints(text: str) -> bool:
    """Check if recovery text already includes resume/continue guidance."""
    if not text:
        return False
    return "obra run --resume" in text or "obra run --continue-from" in text


__all__ = [
    "build_resume_continue_hints",
    "has_resume_continue_hints",
]
