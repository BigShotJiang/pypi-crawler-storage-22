"""Software development domain module.

This domain provides specialized configuration for software development
workflows including feature implementation, bug fixes, refactoring, and more.

This is the default domain used when no --domain flag is specified.

Usage:
    >>> from obra.domains.software import SoftwareDomain
    >>> domain = SoftwareDomain()
    >>> print(domain.name)
    software
    >>> work_types = domain.get_work_type_patterns()
    >>> print(len(work_types['work_types']))
    10

Related:
    - obra/domains/interface.py (protocol definition)
    - docs/guides/domains/using-domains.md
"""

import importlib.resources
from functools import lru_cache
from typing import Any

import yaml

from obra.domains.interface import FileFilterConfig

from .derivation import SIZING_GUIDANCE, WORK_TYPE_KEYWORDS
from .filters import (
    BINARY_EXTENSIONS,
    EXCLUDED_FILES,
    EXCLUDED_PATTERNS,
    IGNORE_DIR_SUFFIXES,
    IGNORE_DIRS,
)


class SoftwareDomain:
    """Domain module for software development workflows.

    Provides work types, quality prompts, and file filters optimized for
    software development tasks.
    """

    @property
    def name(self) -> str:
        """Return domain name."""
        return "software"

    @lru_cache(maxsize=1)  # noqa: B019 - singleton domain, no memory leak concern
    def _load_work_types(self) -> dict[str, Any]:
        """Load work type patterns from YAML."""
        files = importlib.resources.files("obra.domains.software")
        content = (files / "work_types.yaml").read_text()
        return yaml.safe_load(content)

    def get_work_type_patterns(self) -> dict[str, Any]:
        """Return work type definitions for software development.

        Returns:
            Dictionary with work_types list, detection_settings, and fallback
        """
        return self._load_work_types()

    def get_quality_prompts(self) -> dict[str, str]:
        """Return quality assessment prompts for software development.

        Returns:
            Dictionary mapping prompt name to prompt content
        """
        return self._load_prompts()

    @lru_cache(maxsize=1)  # noqa: B019 - singleton domain, no memory leak concern
    def _load_prompts(self) -> dict[str, str]:
        """Load quality prompts from prompt files."""
        files = importlib.resources.files("obra.domains.software.prompts")
        prompts = {}
        prompt_names = [
            "code_quality",
            "testing_coverage",
            "docs_analysis",
            "security_sweep",
            "security_deep",
        ]
        for name in prompt_names:
            try:
                prompts[name] = (files / f"{name}.txt").read_text()
            except FileNotFoundError:
                prompts[name] = f"# {name} prompt (placeholder)"
        return prompts

    def get_file_filters(self) -> FileFilterConfig:
        """Return file exclusion/inclusion patterns for software projects.

        Returns:
            FileFilterConfig with software-specific exclusion rules
        """
        return FileFilterConfig(
            excluded_files=EXCLUDED_FILES,
            excluded_patterns=EXCLUDED_PATTERNS,
            binary_extensions=BINARY_EXTENSIONS,
            ignore_dirs=IGNORE_DIRS,
            ignore_dir_suffixes=IGNORE_DIR_SUFFIXES,
        )

    def get_derivation_keywords(self) -> dict[str, list[str]]:
        """Return keywords for work type detection.

        Returns:
            Dictionary mapping work type ID to list of detection keywords
        """
        return WORK_TYPE_KEYWORDS

    def get_sizing_guidance(self) -> str:
        """Return sizing guidance text for software development.

        Returns:
            Markdown-formatted sizing guidance
        """
        return SIZING_GUIDANCE
