"""Prompt builders for template edit instructions."""

from __future__ import annotations

from pathlib import Path

__all__ = ["build_template_edit_prompt"]


def build_template_edit_prompt(base_prompt: str, template_path: Path | str) -> str:
    """Build the prompt to instruct an LLM to edit a template file.

    Args:
        base_prompt: Original task prompt
        template_path: Path to the template file to edit (relative or absolute)

    Returns:
        Augmented prompt with file editing instructions
    """
    return (
        f"{base_prompt}\n\n"
        f"IMPORTANT: Edit the file {template_path} to add your findings. "
        f"Populate the structure with your analysis. "
        f"Do not remove keys; keep all fields and use empty lists when needed. "
        f"Use strict JSON syntax only: double-quoted keys/strings, no trailing commas, "
        f"no comments, and no code fences or extra prose. "
        f"DO NOT respond with prose - only edit the file."
    )
