# Obra Quick Start for AI Agents

**Version**: 1.2
**Read time**: ~2 minutes (~1,700 tokens)
**Purpose**: Essential input quality requirements before submitting tasks to Obra

---

## LLM Operator Fast Path (Deterministic)

Use this before you run the task:

- **Models**: `obra models` -> pick names. Use `obra run --model X --fast-model X --high-model X --impl-provider openai`.
  - Or env vars: `OBRA_MODEL`, `OBRA_FAST_MODEL`, `OBRA_HIGH_MODEL`, `OBRA_PROVIDER`.
- Do NOT use `obra config set llm.*.model` (unsupported).
- **Help**: `obra help run` for single-level help. Subcommand help uses `--help` (ex: `obra projects create --help`).
- **[!] WSL paths**: map `C:\Projects\...` -> `/mnt/c/Projects/...` and pass with `obra run --dir /mnt/c/...`.
- **Native Windows**: use `C:\...` directly (no `/mnt/c` mapping).
- **Working directory**: Run from inside your project, or use `--dir /path`. The `--project` flag is rarely needed. If stored working_dir differs from current directory, Obra prompts to choose (TTY only).
- **User story generation**: Automatically generates behavioral user stories with verification methods after intent enrichment. Stories flow through derivation (with traceability via `[US-1, US-2]` markers), review (prioritized context), and gap detection. Configure via `intent.user_stories.enabled` (default: true).
- **Story 0**: Environment preparation ALWAYS runs after derivation (even if no prerequisites). Use `--skip-story0` to bypass or `obra run --resume <id> --from story-0` to re-run setup.
- **Automation**: `automation_mode: off | guided | auto_safe | auto_full (default)` controls Story0 and FIX automation level. See `obra help automation-mode`.
- **Verbosity**: default is PROGRESS (same as `-v`). Use `-vv/-vvv` for more detail or `-q` for quiet output (not `--vvv`).
- **Resume verbosity**: `obra run --resume` and `--continue-from` follow the same default (PROGRESS) unless `-q/-v` is supplied.
- **Continue-from objective**: `--continue-from` reuses the original objective unless you pass a new one after the flags.
- **Completion output**: phase-aware; escalations show warnings and omit quality scores. File totals come from the CLI git-status footer.
- **Scorecard (PROGRESS)**: `Review score: <total>/100 (pass ≥ <threshold>)`.
- **Progress visibility**: default PROGRESS (`-v`) shows task progress [X/Y], file activity summaries, review agent status, and elapsed time; this helps monitor long-running sessions and distinguish working vs stuck states.
- **Monitoring**: capture `session_id` from run output, then `obra status <session_id>`.
- **Long-running runs**: do NOT use short timeouts that kill the process. If your tool enforces timeouts, start `obra run` in a separate terminal or background (tmux/screen/nohup) and monitor with `obra status` while it keeps running.
- **Config warnings**: if `obra config show` warns about auth metadata keys in `~/.obra/config-layers/01-user.yaml`, ignore. Other unknown keys are real issues.

Example:
```
OBRA_PROVIDER=openai \
OBRA_MODEL=gpt-5.1-codex-mini \
OBRA_FAST_MODEL=gpt-5.1-codex-mini \
OBRA_HIGH_MODEL=gpt-5.1-codex-mini \
obra run --dir /mnt/c/Projects/obra-simulations/my-sim --stream -vvv \
"Objective with clear stack, features, and success criteria"
```

## ⚠️ REQUIRED BEFORE SUBMITTING

### Input Quality Gate

❌ **DON'T submit vague input:**
```
obra "build a website"
obra "add authentication"
obra "make it better"
obra "fix the bug"
```

✅ **DO submit specific, complete input:**
```
obra "E-commerce website for handmade crafts: React 18 + TypeScript frontend,
Node.js + Express backend, MongoDB database. Features: product catalog with
search/filter by category and price, shopping cart with session persistence,
Stripe checkout integration, JWT authentication. Docker Compose deployment.
Performance: <500ms response time. Testing: >80% code coverage."
```

---

## Minimum Required Information Checklist

Before running `obra "task"`, you MUST have:

- [ ] **Git repository** (project in a git repo, or use `--auto-init-git`)
- [ ] **Clear objective** (2-4 sentences, not just "build X")
- [ ] **Tech stack identified** (language, framework, database)
- [ ] **Specific features** (not "auth" → "JWT authentication with refresh tokens and RBAC")
- [ ] **Success criteria** (testable outcomes: "all tests pass", "API responds <200ms")

---

## If Input is Vague: Assume and Document

**When user says vague things, make reasonable assumptions and document them:**

| User says... | You assume... |
|--------------|---------------|
| "Build a website" | "ASSUMPTION: Building a SaaS web app based on the existing tech stack (React/Node)" |
| "Add authentication" | "ASSUMPTION: Using JWT with refresh tokens (matches existing patterns in codebase)" |
| "Fix the bug" | "ASSUMPTION: Referring to the most recent error in logs / user-reported issue" |
| "Make it faster" | "ASSUMPTION: Optimizing API response time (most common performance bottleneck)" |

**Do NOT ask clarifying questions.** Make the best assumption from context, document it explicitly, and proceed. If your assumption is wrong, the user can correct you in the next iteration.

---

## Required Information by Category

### 1. Tech Stack (ALWAYS REQUIRED)

**FIRST**: Check project files before asking:
- `package.json` → JavaScript/TypeScript, framework (React/Express/Next.js)
- `requirements.txt` or `pyproject.toml` → Python, framework (FastAPI/Django/Flask)
- `go.mod` → Go, framework (Gin/Echo)
- `Cargo.toml` → Rust
- `pom.xml` or `build.gradle` → Java

**If found**: Confirm with user ("I see Python + FastAPI, continue with that?")
**If not found**: Ask with smart defaults ("REST API → suggest FastAPI or Express. Preference?")

**Minimum to specify:**
- Language (python, javascript, go, rust, java, typescript)
- Framework if applicable (fastapi, express, django, react, nextjs)
- Database if needed (postgresql, mysql, mongodb, redis, sqlite, none)

### 2. Specific Features (ALWAYS REQUIRED)

**Be detailed. Push back on vague descriptions:**

| ❌ Vague | ✅ Specific |
|---------|------------|
| "Authentication" | "JWT authentication with refresh tokens, role-based access control (admin/user roles), password reset via email" |
| "Search" | "Product search by name/description with filters for category, price range ($0-$1000), and star rating (1-5)" |
| "Admin panel" | "Admin dashboard with user management (CRUD), order tracking table with filters, analytics charts (daily revenue, top products)" |

### 3. Success Criteria (ALWAYS REQUIRED)

**Testable outcomes that define "done":**

✅ Good examples:
- "All CRUD endpoints return correct HTTP status codes (201, 200, 204, 404)"
- "Authentication blocks unauthenticated requests with 401"
- "Tests achieve >80% code coverage and all pass"
- "API responds to all endpoints within 200ms (95th percentile)"
- "Docker Compose brings up all services without errors"

❌ Bad examples:
- "It works" (not testable)
- "Good performance" (not specific)
- "No bugs" (impossible to verify)

### 4. Constraints (OPTIONAL BUT VALUABLE)

**Ask if user mentions any of these:**
- **Deployment**: Docker, Kubernetes, AWS, Heroku, cloud-run?
- **Performance**: Response time limits? Concurrent user targets? Memory limits?
- **Integration**: Existing services to connect with? (e.g., "auth-service:8000", "legacy-db:5432")
- **Security**: OWASP compliance? No secrets in code? Specific encryption requirements?
- **Testing**: Coverage targets? Test types needed (unit, integration, E2E)?

### 5. Anti-Patterns (OPTIONAL BUT VALUABLE)

**Ask: "Any frameworks, libraries, or approaches you want to avoid?"**

Good examples:
- "Don't use Flask - team is standardizing on FastAPI"
- "Avoid Redux - prefer React Context for simpler state management"
- "No raw SQL queries - must use SQLAlchemy ORM"

---

## Complete Example: Good Input

```
User: "I need user management for my app"

You (LLM): [Check package.json → see FastAPI + PostgreSQL]

You: "I see you're using FastAPI and PostgreSQL. For user management, I need:
1. What operations? Just CRUD, or also authentication/authorization?
2. What user fields beyond email/password?
3. Any role-based access control (admin vs user)?
4. Performance requirements?"

User: "CRUD plus JWT auth. Fields: name, email, role. Admins can manage users.
Response time under 200ms."

You construct:
"User management API for FastAPI app with PostgreSQL: CRUD operations
(create, read, update, delete users), JWT authentication with refresh tokens,
role-based access control (admin and user roles). User fields: name, email,
password (bcrypt), role. Admin endpoints for user management. Success: All
endpoints respond <200ms, JWT blocks unauthorized access, tests >80% coverage."

You submit: obra "User management API for FastAPI..." --stream
```

---

## Quick Decision Tree

```
1. User request received
   ├─ Is objective clear? (2-4 sentence description)
   │  ├─ YES → Continue
   │  └─ NO → Ask: "Can you describe the goal in more detail?"
   │
   ├─ Tech stack specified OR inferable from files?
   │  ├─ YES → Confirm if inferred
   │  └─ NO → Ask: "Language and framework preference?"
   │
   ├─ Features specific? (not "auth", but "JWT auth with X, Y, Z")
   │  ├─ YES → Continue
   │  └─ NO → Push for details: "What kind of auth exactly?"
   │
   ├─ Success criteria defined?
   │  ├─ YES → Ready to submit
   │  └─ NO → Ask: "How do we know when this is done?"
   │
   └─ Submit to Obra with complete, specific input
```

---

## If You Encounter Issues

🐛 **Report bugs, request features, and provide feedback**:

```bash
obra feedback bug "description"     # Report a bug
obra feedback feature "title"       # Request a feature
obra feedback general "text"        # General feedback
```

**Common scenarios**:
```bash
# Orchestration stuck or looping
obra feedback bug "Orchestration repeating same task" --severity high

# Error during execution
obra feedback bug "Derive failed" --error "EmptyPlanError: No tasks" --severity critical

# Feature request with context
obra feedback feature "Support for X" --use-case "Need this for Y"
```

**For automation/non-interactive use**:
```bash
obra feedback bug "description" --non-interactive --format json
```

**Troubleshooting quick fixes**:
- Credential prompt appearing: use `obra run --mock-credentials` for testing or set the env var.
- Service not starting: ensure Docker is running or start the service manually.
- Story 0 re-running unexpectedly: objective changed; use `obra run --resume <id> --from derivation` to skip setup.
- Upgrading mocked credentials: set the real env var, then `obra run --resume <id>` to upgrade.

**Automatic reporting**: If Obra crashes or fails to complete, it will offer to file a bug report automatically with session logs and context already captured.

**Privacy controls**:
- `--privacy full` - Maximum diagnostic data (recommended for complex bugs)
- `--privacy standard` - Balanced data collection (default)
- `--privacy minimal` - Essential info only

**Your feedback helps improve Obra** - all submissions are automatically triaged and prioritized.

### Session Recovery

**When sessions become stuck**, use these recovery commands:

| Issue | Command | Note |
|-------|---------|------|
| Session stuck with 500 errors | `obra sessions repair <id>` | Auto-fixes common issues (missing item_id, stuck phase) |
| Completed work but session stuck | `obra sessions force-complete <id>` | Preserves all results, marks session done |
| Review keeps failing | `obra sessions reset-review <id>` | Clears review state, retries execution |

All commands are safe and idempotent. They only affect sessions you own.

---

## Autonomous Workplan Execution

🤖 **For multi-story workplans**: Use `obra auto` for hands-off execution

```bash
obra auto --plan <WORK_ID>              # Execute all pending stories
obra auto --plan <WORK_ID> --dry-run    # Preview execution plan
```

**When to use**:
- You have a MACHINE_PLAN.json with multiple stories
- Want sequential story execution without continuous LLM attention
- Solving the completion bias problem (LLMs tend to stop before finishing)

**Features**:
- Automatic retry on transient failures
- Progress logged to obra-auto.log
- Graceful Ctrl+C (completes current story, saves state)
- Breakpoint escalation for manual intervention

---

## Plan Visibility

📋 **Inspect execution plans for running sessions**:

```bash
obra sessions plan <session_id>          # View execution plan tree
obra sessions plan --json                # Machine-readable tree + items
obra sync plan <session_id> --machine-plan  # Export MACHINE_PLAN for upload
```

---

## Skip Tracking Quick Reference

```bash
obra skips list                    # List pending skips
obra skips show <skip_id>           # Inspect a skip record
obra skips resolve <skip_id>        # Mark resolved/deferred/wont_fix
obra skips cleanup --interactive    # Walk skips one by one
obra skips cleanup --export         # Generate cleanup MACHINE_PLAN.json
```

---

## Complexity & Parallel Execution Quick Reference

### Complexity Estimation

Obra automatically estimates task complexity during derivation:

| Score | Meaning | Action |
|-------|---------|--------|
| 0-69 | Normal | Execute as planned |
| 70-84 | High | `obra_suggests_decomposition: true` - consider breaking down |
| 85-100 | Very High | Strongly recommend decomposition before execution |

**Skip complexity check** (faster derivation):
```bash
obra run "objective" --skip-complexity-check
```

### Parallel Execution

Derived items are analyzed for parallelization opportunities:

```bash
obra run "multi-task feature" --parallel  # Execute independent items concurrently
```

**Reading parallel groups** (for LLM operators):
- `parallel_group: 0` - First group (execute first)
- `parallel_group: 1` - Second group (execute after group 0)
- `parallel_group: null` - Sequential execution required
- Items in same group have no interdependencies → run concurrently

### UserPlan Quality Refinement

Run the clarification loop to improve UserPlan quality:

```bash
obra userplan clarify <userplan_id>              # Default: 3 iterations, 80% target
obra userplan clarify <id> --max-iterations 5    # More iterations
obra userplan clarify <id> --target 0.9          # Higher quality target
obra userplan clarify <id> --format json         # Machine-readable output
```

**Termination conditions**: quality reached, max iterations, or diminishing returns (<5% improvement).

---

## Next Steps

📚 **Need more guidance?**

- **Complex projects/integrations**: `obra briefing questions`
  ↳ Detailed question patterns for enterprise scenarios, legacy systems, non-technical users

- **Worked examples**: `obra briefing examples`
  ↳ 10 good/bad input comparisons across different project types

- **Autonomous long-running tasks**: `obra briefing protocol`
  ↳ 11 behaviors for unattended execution (checkpointing, progress reporting, escalation)

- **Complete reference**: `obra briefing full`
  ↳ Full 3,600-line guide (blueprint structure, all sections, advanced patterns)

🐛 **Report issues**: `obra feedback bug "description"` or `obra feedback feature "title"`

---

**Generated by Obra v2.10.0** | For updates: `pipx upgrade obra`
