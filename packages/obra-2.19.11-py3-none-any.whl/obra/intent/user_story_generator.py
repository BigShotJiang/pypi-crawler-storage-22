"""User story generator from intent documents.

This module provides automated user story generation with verification methods
from enriched intent documents. Generated stories include acceptance criteria,
proof commands for automated verification, and manual steps for non-automatable
scenarios.

Related:
    - docs/design/prds/USER_STORY_QA_GATE_PRD.md (FR-1, FR-3, FR-4, FR-5)
    - obra/intent/models.py (UserStory, VerificationMethod, ProofType)
    - obra/prompts/intent/user_stories.py
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Callable

from pydantic import ValidationError

from obra.config.llm import resolve_tier_config
from obra.config.loaders import (
    get_user_story_generation_enabled,
    get_user_story_generation_timeout_s,
    get_user_story_max_stories,
    get_user_story_model_tier,
)
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.intent.models import IntentModel, UserStory
from obra.prompts.intent.user_stories import build_user_story_generation_prompt

logger = logging.getLogger(__name__)


class UserStoryGenerator:
    """Generates user stories with verification methods from intent documents.

    This generator uses LLM-powered template editing to produce concrete,
    testable user stories from abstract intent documents. Stories include
    verification methods (automated/manual/not_verifiable) and domain-specific
    proof commands.

    The generator is non-blocking by design - failures return empty list rather
    than raising exceptions, allowing the intent enrichment pipeline to continue
    even if story generation fails.

    Attributes:
        working_dir: Working directory for template files
        llm_config: Optional LLM configuration override
        on_stream: Optional streaming callback
        on_progress: Optional progress callback
        log_event: Optional event logging callback
        production_logger: Optional production logger instance
    """

    def __init__(
        self,
        working_dir: Path,
        *,
        llm_config: dict[str, Any] | None = None,
        on_stream: Callable | None = None,
        on_progress: Callable | None = None,
        log_event: Callable | None = None,
        production_logger: Any | None = None,
    ):
        """Initialize user story generator.

        Args:
            working_dir: Working directory for template files
            llm_config: Optional LLM configuration override
            on_stream: Optional streaming callback
            on_progress: Optional progress callback
            log_event: Optional event logging callback
            production_logger: Optional production logger instance
        """
        self.working_dir = working_dir
        self.llm_config = llm_config
        self.on_stream = on_stream
        self.on_progress = on_progress
        self.log_event = log_event
        self.production_logger = production_logger

    def generate(
        self,
        intent: IntentModel,
        project_context: str | None = None,
    ) -> list[UserStory]:
        """Generate user stories from intent document.

        Args:
            intent: Enriched intent document
            project_context: Optional project context (JSON-serialized dict)

        Returns:
            List of UserStory objects (empty list on failure or if disabled)

        Note:
            This method is non-blocking - failures return [] rather than raising.
            Check logs for warnings if story generation fails.
        """
        # Check if feature is enabled
        if not get_user_story_generation_enabled():
            logger.debug("User story generation disabled via config")
            return []

        try:
            # Resolve model tier configuration
            model_tier = get_user_story_model_tier()
            resolved = resolve_tier_config(
                model_tier,
                role="orchestrator",
            )

            # Build prompt
            max_stories = get_user_story_max_stories()
            prompt = build_user_story_generation_prompt(
                objective=intent.raw_objective,
                intent=intent,
                project_context=project_context,
                max_stories=max_stories,
            )

            # Create template edit pipeline
            pipeline = TemplateEditPipeline(
                working_dir=self.working_dir,
                action_name="user_story_generation",
                on_stream=self.on_stream,
                log_event=self.log_event,
                max_retries=3,  # Allow retries for validation failures
            )

            # Template schema for user story array
            template_schema = {
                "stories": [],
                "_instructions": (
                    "Generate an array of UserStory objects.\n"
                    "Each story must have: id, role, action, outcome, "
                    "verification_method, proof_type, proof_command, "
                    "proof_expected, preconditions, manual_steps.\n"
                    "Replace this stories array with your generated stories."
                ),
            }

            # Validator: check stories array structure
            def validator(data: dict) -> tuple[bool, str | None]:
                stories = data.get("stories")
                if not isinstance(stories, list):
                    return (False, "stories must be an array")
                return (True, None)

            # Fallback returns empty list
            def fallback() -> dict:
                return {"stories": []}

            # Execute pipeline with timeout
            timeout_s = get_user_story_generation_timeout_s()
            result_data, _metadata = pipeline.execute(
                base_prompt=prompt,
                template_content=template_schema,
                validator=validator,
                fallback_fn=fallback,
                timeout_s=timeout_s,
                llm_config={
                    "provider": resolved["provider"],
                    "model": resolved["model"],
                    "thinking": resolved["thinking_level"],
                    "auth": resolved["auth_method"],
                },
            )

            # Parse stories from result
            stories_data = result_data.get("stories", [])
            if not isinstance(stories_data, list):
                logger.warning("Invalid stories data type: %s", type(stories_data))
                return []

            # Convert to UserStory objects with validation
            stories = []
            for story_dict in stories_data[:max_stories]:  # Enforce max_stories limit
                try:
                    story = UserStory.model_validate(story_dict)
                    stories.append(story)
                except ValidationError as e:
                    # Log validation failures but continue with other stories
                    logger.warning(
                        "Skipping invalid user story (validation failed): %s",
                        e,
                    )
                    continue

            logger.info(
                "Generated %d user stories (max: %d)",
                len(stories),
                max_stories,
            )
            return stories

        except Exception as e:
            # Non-blocking: log warning and return empty list
            logger.warning(
                "User story generation failed (non-blocking): %s",
                e,
                exc_info=True,
            )
            return []
