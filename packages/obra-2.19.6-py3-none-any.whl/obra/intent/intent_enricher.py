"""Intent enrichment orchestrator for pre-planning stages."""

from __future__ import annotations

import json
import logging
import sys
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from obra.config import get_heartbeat_initial_delay, get_heartbeat_interval
from obra.config.llm import DEFAULT_ROLE_MAPPINGS, resolve_tier_config
from obra.constants import LIVENESS_CHECK_INTERVAL_S
from obra.display import console
from obra.display.observability import (
    VerbosityLevel,
    _STAGE_USER_LABELS,
    get_runtime_verbosity,
)
from obra.exceptions import ConfigurationError
from obra.hybrid.json_utils import extract_json_payload, is_garbage_response
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.intent.analogue_cache import (
    append_analogue_cache_entry,
    load_analogue_cache_entries,
    render_analogue_cache,
)
from obra.intent.diff import build_intent_diff, render_intent_diff
from obra.intent.enrichment_config import load_enrichment_config
from obra.intent.models import InputType, IntentModel
from obra.intent.prompts_enrichment import (
    build_assumptions_prompt,
    build_assumptions_template,
    build_brief_prompt,
    build_brief_template,
    build_expert_alignment_prompt,
    build_expert_alignment_template,
)
from obra.intent.retention import cleanup_retention
from obra.intent.storage import IntentStorage
from obra.intent.telemetry import log_enrichment_event
from obra.llm.cli_runner import invoke_llm_via_cli

logger = logging.getLogger(__name__)

PROCEED_COMMANDS = {
    "make reasonable assumptions and proceed",
    "proceed with assumptions",
    "proceed",
    "skip questions",
}


def _unwrap_cli_response(raw_response: str) -> str:
    response = raw_response.strip()
    if not response.startswith("{"):
        return response
    try:
        data = json.loads(response)
    except json.JSONDecodeError:
        return response
    if isinstance(data, dict):
        if data.get("type") == "result" and "result" in data:
            result = data.get("result")
            if isinstance(result, str) and result.strip():
                return result.strip()
        if "response" in data and "stats" in data:
            response_value = data.get("response")
            if isinstance(response_value, str) and response_value.strip():
                return response_value.strip()
    return response


def _parse_json_payload(raw_response: str) -> dict[str, Any]:
    response = _unwrap_cli_response(raw_response)
    if not response:
        return {}
    payload_text = extract_json_payload(response) or response.strip()
    try:
        data = json.loads(payload_text)
    except json.JSONDecodeError:
        return {}
    return data if isinstance(data, dict) else {}


@dataclass
class EnrichmentStageResult:
    name: str
    raw_response: str
    parsed: dict[str, Any]
    duration_s: float


class StageHeartbeatThread(threading.Thread):
    """Background thread that emits stage heartbeat events."""

    def __init__(
        self,
        stage: str,
        interval: int,
        initial_delay: int,
        emit_progress: Callable[[str, dict[str, Any]], None],
        log_event: Callable[..., None] | None = None,
    ) -> None:
        super().__init__(daemon=True)
        self._stage = stage
        self._interval = max(1, int(interval))
        self._initial_delay = max(0, int(initial_delay))
        self._emit_progress = emit_progress
        self._log_event = log_event
        self._stop_event = threading.Event()
        self._start_time = time.time()
        self._alive_count = 0

    def stop(self) -> None:
        self._stop_event.set()

    def run(self) -> None:
        self._stop_event.wait(self._initial_delay)
        last_liveness_check = time.time()

        while not self._stop_event.is_set():
            elapsed = int(time.time() - self._start_time)
            self._emit_progress("stage_heartbeat", {"stage": self._stage, "elapsed_s": elapsed})

            current_time = time.time()
            if (
                self._log_event
                and (current_time - last_liveness_check) >= LIVENESS_CHECK_INTERVAL_S
            ):
                self._alive_count += 1
                self._log_event(
                    "stage_liveness_check",
                    stage=self._stage,
                    status="active",
                    alive_count=self._alive_count,
                    elapsed_seconds=elapsed,
                )
                last_liveness_check = current_time

            self._stop_event.wait(self._interval)


class IntentEnricher:
    """Run intent enrichment stages A-C."""

    def __init__(
        self,
        working_dir: Path,
        *,
        llm_config: dict[str, Any],
        on_stream: Any | None = None,
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        log_event: Any | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._llm_config = llm_config
        self._on_stream = on_stream
        self._on_progress = on_progress
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._last_stage_results: list[EnrichmentStageResult] = []
        try:
            self._config = load_enrichment_config(working_dir)
        except ConfigurationError as exc:
            logger.warning("Intent enrichment disabled due to config error: %s", exc)
            self._config = {"enabled": False}

    def get_last_stage_results(self) -> list[EnrichmentStageResult]:
        return list(self._last_stage_results)

    def is_enabled(self) -> bool:
        return bool(self._config.get("enabled", False))

    def should_run(
        self,
        input_type: InputType,
        *,
        force: bool = False,
        skip: bool = False,
    ) -> bool:
        if skip:
            return False
        if not self.is_enabled():
            return False
        if force:
            return True
        always_on = bool(self._config.get("always_on", True))
        if always_on:
            return True
        return input_type in {InputType.VAGUE_NL, InputType.RICH_NL}

    def get_stage_config(self, stage: str) -> dict[str, Any]:
        """Expose stage configuration for external orchestration."""
        return self._get_stage_config(stage)

    def _emit_progress(self, action: str, payload: dict[str, Any]) -> None:
        if self._on_progress:
            try:
                self._on_progress(action, payload)
            except Exception as exc:
                logger.debug("Enrichment progress callback failed: %s", exc)
        if self._log_event:
            try:
                self._log_event(f"progress_{action}", **payload)
            except Exception as exc:
                logger.debug("Enrichment progress log failed: %s", exc)

    def run(
        self,
        objective: str,
        intent: IntentModel,
        *,
        interactive: bool,
        skip_analogues: bool = False,
        skip_brief: bool = False,
    ) -> tuple[IntentModel, Path | None]:
        if not self.is_enabled():
            return intent, None

        stage_results: list[EnrichmentStageResult] = []
        intent_before = intent.model_copy(deep=True)

        self._run_assumptions_loop(
            objective,
            intent,
            stage_results=stage_results,
            interactive=interactive,
        )

        # Stage B: Expert alignment / analogues
        if skip_analogues:
            logger.info("Skipping analogues stage (complexity routing)")
            stage_b_result = EnrichmentStageResult("analogues", "", {}, 0.0)
            stage_results.append(stage_b_result)
        else:
            stage_b_result = self._run_expert_stage(objective, intent, stage_results)
            self._apply_expert_updates(intent, stage_b_result)
            self._update_analogue_cache(objective, stage_b_result)

        # Stage C: Brief generation
        if skip_brief:
            logger.info("Skipping brief stage (complexity routing)")
            stage_c_result = EnrichmentStageResult("brief", "", {}, 0.0)
            stage_results.append(stage_c_result)
        else:
            stage_c_result = self._run_brief_stage(objective, intent, stage_results)
            self._apply_brief_update(intent, stage_c_result)

        storage = IntentStorage()
        storage.save(intent)

        diff_path = self._write_intent_diff(intent_before, intent, stage_c_result)

        artifact_paths = self._write_stage_artifacts(intent.id, stage_results)
        self._log_telemetry(intent.id, stage_results)
        self._run_retention_cleanup(
            protected_diff_paths={diff_path} if diff_path else None,
            protected_artifact_paths=set(artifact_paths),
        )

        self._last_stage_results = list(stage_results)

        return intent, diff_path

    def _run_assumptions_loop(
        self,
        objective: str,
        intent: IntentModel,
        *,
        stage_results: list[EnrichmentStageResult],
        interactive: bool,
    ) -> list[EnrichmentStageResult]:
        stage_config = self._get_stage_config("assumptions")
        max_passes = int(stage_config.get("max_passes") or 0)
        if max_passes < 1:
            return []

        results: list[EnrichmentStageResult] = []
        prior_questions: set[str] = set()
        prior_non_inferable: set[str] = set()

        for pass_index in range(max_passes):
            proceed_override = bool(intent.metadata.get("assumptions_proceed_override"))
            stage_name = "assumptions" if pass_index == 0 else f"assumptions_pass_{pass_index + 1}"
            unresolved_questions = intent.metadata.get("unresolved_questions", [])
            non_inferable_questions = intent.metadata.get("non_inferable_questions", [])
            stage_result = self._run_assumptions_stage(
                objective,
                intent,
                stage_name=stage_name,
                unresolved_questions=sorted({*prior_questions, *unresolved_questions}),
                non_inferable_questions=sorted({*prior_non_inferable, *non_inferable_questions}),
                proceed_override=proceed_override,
            )
            stage_results.append(stage_result)
            results.append(stage_result)

            self._apply_assumptions(intent, stage_result, interactive=interactive)

            answers_added = 0
            if interactive and sys.stdin.isatty():
                answers_added = self._prompt_non_inferable(
                    intent,
                    stage_result.parsed.get("non_inferable_questions", []) or [],
                )

            new_questions = stage_result.parsed.get("questions") or []
            new_non_inferable = stage_result.parsed.get("non_inferable_questions") or []
            prior_questions.update(q for q in new_questions if isinstance(q, str))
            prior_non_inferable.update(q for q in new_non_inferable if isinstance(q, str))

            ready_to_proceed, missing_sections = _parse_quality_signal(stage_result)
            will_continue = self._should_continue_assumptions_loop(
                stage_result=stage_result,
                pass_index=pass_index,
                max_passes=max_passes,
                interactive=interactive,
                answers_added=answers_added,
                proceed_override=bool(intent.metadata.get("assumptions_proceed_override")),
                ready_to_proceed=ready_to_proceed,
                missing_sections=missing_sections,
            )
            self._log_assumptions_quality_decision(
                stage_name=stage_name,
                ready_to_proceed=ready_to_proceed,
                missing_sections=missing_sections,
                will_continue=will_continue,
                interactive=interactive,
                answers_added=answers_added,
                proceed_override=bool(intent.metadata.get("assumptions_proceed_override")),
            )
            if not will_continue:
                break

        return results

    def _run_assumptions_stage(
        self,
        objective: str,
        intent: IntentModel,
        *,
        stage_name: str,
        unresolved_questions: list[str],
        non_inferable_questions: list[str],
        proceed_override: bool,
    ) -> EnrichmentStageResult:
        stage_config = self._get_stage_config("assumptions")
        prompt = build_assumptions_prompt(
            objective,
            self._format_intent(intent),
            self._config.get("non_inferable_categories", []),
            unresolved_questions=unresolved_questions,
            non_inferable_questions=non_inferable_questions,
            proceed_override=proceed_override,
        )
        return self._invoke_stage(stage_name, prompt, stage_config)

    def _run_expert_stage(
        self,
        objective: str,
        intent: IntentModel,
        stage_results: list[EnrichmentStageResult],
    ) -> EnrichmentStageResult:
        stage_config = self._get_stage_config("analogues")
        cache_entries = self._load_analogue_cache_entries()
        cache_text = render_analogue_cache(cache_entries)
        prompt = build_expert_alignment_prompt(
            objective,
            self._format_intent(intent),
            analogue_cache=cache_text or None,
        )
        result = self._invoke_stage("analogues", prompt, stage_config)
        stage_results.append(result)
        return result

    def _run_brief_stage(
        self,
        objective: str,
        intent: IntentModel,
        stage_results: list[EnrichmentStageResult],
    ) -> EnrichmentStageResult:
        stage_config = self._get_stage_config("brief")
        prompt = build_brief_prompt(objective, self._format_intent(intent))
        result = self._invoke_stage("brief", prompt, stage_config)
        stage_results.append(result)
        return result

    def _invoke_stage(
        self, stage_name: str, prompt: str, stage_config: dict[str, Any]
    ) -> EnrichmentStageResult:
        model_tier = stage_config.get("model_tier")
        if "reasoning_level" not in stage_config:
            msg = f"planning.enrichment.stages.{stage_name}.reasoning_level is required"
            raise ConfigurationError(
                msg,
                "Set the reasoning_level in config/default_config.yaml or "
                "~/.obra/config-layers/01-user.yaml",
            )
        if "max_passes" not in stage_config:
            msg = f"planning.enrichment.stages.{stage_name}.max_passes is required"
            raise ConfigurationError(
                msg,
                "Set max_passes in config/default_config.yaml or "
                "~/.obra/config-layers/01-user.yaml",
            )
        if "timeout_s" not in stage_config:
            msg = f"planning.enrichment.stages.{stage_name}.timeout_s is required"
            raise ConfigurationError(
                msg,
                "Set timeout_s in config/default_config.yaml or ~/.obra/config-layers/01-user.yaml",
            )
        reasoning_level = stage_config.get("reasoning_level")
        max_passes = int(stage_config.get("max_passes") or 0)
        timeout_s = int(stage_config.get("timeout_s") or 0)

        if not model_tier:
            msg = f"planning.enrichment.stages.{stage_name}.model_tier is required"
            raise ConfigurationError(
                msg,
                "Set the model_tier in config/default_config.yaml or "
                "~/.obra/config-layers/01-user.yaml",
            )
        if max_passes < 1:
            return EnrichmentStageResult(stage_name, "", {}, 0.0)

        # Look up role from DEFAULT_ROLE_MAPPINGS (ADR-069 pattern)
        base_stage = stage_name.split("_pass_")[0]
        role_key = f"enrichment_{base_stage}"
        role = DEFAULT_ROLE_MAPPINGS.get(role_key, "orchestrator")

        resolved = resolve_tier_config(
            model_tier,
            role=role,
            override_thinking_level=reasoning_level,
        )

        stage_context = {
            "model_tier": model_tier,
            "reasoning_level": reasoning_level,
            "timeout_s": timeout_s,
        }
        user_label = _STAGE_USER_LABELS.get(base_stage, base_stage.replace("_", " ").title())
        self._emit_progress(
            "planning_stage_started",
            {"stage": base_stage, "user_label": user_label},
        )
        self._emit_progress(
            "stage_started",
            {"stage": stage_name, "context": stage_context},
        )
        heartbeat_thread: StageHeartbeatThread | None = None
        try:
            if self._on_progress or self._log_event:
                interval = get_heartbeat_interval()
                initial_delay = get_heartbeat_initial_delay()
                inline_heartbeat = sys.stdin.isatty() and (
                    get_runtime_verbosity() == VerbosityLevel.PROGRESS
                )
                if inline_heartbeat:
                    interval = 1
                    initial_delay = min(1, initial_delay)
                heartbeat_thread = StageHeartbeatThread(
                    stage=stage_name,
                    interval=interval,
                    initial_delay=initial_delay,
                    emit_progress=self._emit_progress,
                    log_event=self._log_event,
                )
                heartbeat_thread.start()

            start = time.time()

            # Check if this stage uses template edit pipeline
            use_template_pipeline = base_stage in {"assumptions", "brief", "analogues"}

            if use_template_pipeline:
                # Use TemplateEditPipeline for migrated stages
                if base_stage == "assumptions":
                    template_content = build_assumptions_template()
                    validator = self._validate_assumptions
                    def fallback_fn() -> dict[str, Any]:
                        return {
                            "assumptions_add": [],
                            "constraints_add": [],
                            "questions": [],
                            "non_inferable_questions": [],
                            "quality_signal": {"ready_to_proceed": False, "missing_sections": []},
                            "rationale": "Fallback: Failed to generate assumptions"
                        }
                elif base_stage == "brief":
                    template_content = build_brief_template()
                    validator = self._validate_brief
                    def fallback_fn() -> dict[str, Any]:
                        return {
                            "problem_statement": "",
                            "assumptions": [],
                            "requirements": [],
                            "constraints": [],
                            "acceptance_criteria": [],
                            "non_goals": [],
                            "risks": [],
                        }
                elif base_stage == "analogues":
                    template_content = build_expert_alignment_template()
                    validator = self._validate_expert_alignment
                    def fallback_fn() -> dict[str, Any]:
                        return {
                            "domain_inference": [],
                            "expert_approach": [],
                            "intent_gaps": [],
                            "expert_perspective": "",
                            "technical_considerations": [],
                            "patterns": [],
                            "proposed_intent_updates": {
                                "assumptions_add": [],
                                "requirements_add": [],
                                "constraints_add": [],
                                "non_goals_add": [],
                                "risks_add": [],
                                "acceptance_criteria_add": []
                            },
                            "rationale": "Fallback: Failed to generate expert alignment"
                        }
                else:
                    msg = f"Unhandled template pipeline stage: {base_stage}"
                    raise RuntimeError(msg)

                llm_config = {
                    "provider": resolved["provider"],
                    "model": resolved["model"],
                    "thinking_level": resolved["thinking_level"],
                    "auth_method": resolved["auth_method"],
                }

                pipeline = TemplateEditPipeline(
                    working_dir=self._working_dir,
                    action_name=f"enrichment_{base_stage}",
                    output_format="json",
                    on_stream=self._build_stream_handler(stage_name),
                    log_event=self._log_event,
                )

                parsed, metadata = pipeline.execute(
                    base_prompt=prompt,
                    template_content=template_content,
                    validator=validator,
                    fallback_fn=fallback_fn,
                    llm_config=llm_config,
                    timeout_s=timeout_s or None,
                )

                # Create synthetic response_text for observability
                response_text = json.dumps(parsed, indent=2)
            else:
                # Use existing invoke_llm_via_cli for non-migrated stages
                raw_response = invoke_llm_via_cli(
                    prompt=prompt,
                    cwd=self._working_dir,
                    provider=resolved["provider"],
                    model=resolved["model"],
                    thinking_level=resolved["thinking_level"],
                    auth_method=resolved["auth_method"],
                    on_stream=self._build_stream_handler(stage_name),
                    timeout_s=timeout_s or None,
                    log_event=self._log_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    call_site=f"enrichment_{stage_name}",
                    monitoring_context=None,
                    skip_git_check=self._llm_config.get("git", {}).get("skip_check", False),
                )
                response_text = _unwrap_cli_response(raw_response)
                parsed = _parse_json_payload(response_text)
        except Exception as exc:
            duration_ms = int((time.time() - start) * 1000) if "start" in locals() else 0
            self._emit_progress(
                "stage_failed",
                {
                    "stage": stage_name,
                    "error": str(exc),
                    "duration_ms": duration_ms,
                    "timeout_s": timeout_s,
                },
            )
            raise
        finally:
            if heartbeat_thread:
                heartbeat_thread.stop()

        duration = time.time() - start
        if response_text:
            is_garbage = is_garbage_response(response_text)
            if is_garbage:
                logger.warning("Enrichment %s stage returned garbage response", stage_name)
        self._emit_progress(
            "planning_stage_completed",
            {"stage": base_stage, "user_label": user_label, "duration_s": duration},
        )
        self._emit_progress(
            "stage_completed",
            {
                "stage": stage_name,
                "duration_ms": int(duration * 1000),
                "result": {"parsed_keys": sorted(parsed.keys())},
            },
        )
        return EnrichmentStageResult(stage_name, response_text, parsed, duration)

    def _load_analogue_cache_entries(self) -> list[dict[str, Any]]:
        cache_config = self._config.get("analogue_cache", {})
        global_path = cache_config.get("global_path")
        project_path = cache_config.get("project_path")
        resolved_global = Path(global_path).expanduser() if global_path else None
        resolved_project = (self._working_dir / project_path).resolve() if project_path else None
        return load_analogue_cache_entries(
            global_path=resolved_global,
            project_path=resolved_project,
        )

    def _update_analogue_cache(self, objective: str, result: EnrichmentStageResult) -> None:
        if not result.parsed:
            return
        cache_config = self._config.get("analogue_cache", {})
        global_path = cache_config.get("global_path")
        project_path = cache_config.get("project_path")
        if not global_path and not project_path:
            return
        resolved_global = Path(global_path).expanduser() if global_path else None
        resolved_project = (self._working_dir / project_path).resolve() if project_path else None
        domain_inference = result.parsed.get("domain_inference") or []
        domains = [
            entry.get("domain")
            for entry in domain_inference
            if isinstance(entry, dict) and entry.get("domain")
        ]
        expert_roles: list[Any] = []
        for entry in domain_inference:
            if isinstance(entry, dict):
                expert_roles.extend(entry.get("expert_roles") or [])
        entry = {
            "created": datetime.now(UTC).isoformat(),
            "objective_preview": objective,
            "domains": domains,
            "expert_roles": expert_roles,
            "expert_approach": result.parsed.get("expert_approach") or [],
            "intent_gaps": result.parsed.get("intent_gaps") or [],
            "rationale": result.parsed.get("rationale") or "",
        }
        append_analogue_cache_entry(
            entry,
            global_path=resolved_global,
            project_path=resolved_project,
        )

    def _apply_assumptions(
        self, intent: IntentModel, result: EnrichmentStageResult, *, interactive: bool
    ) -> None:
        data = result.parsed
        assumptions_add = data.get("assumptions_add", []) or []
        questions = data.get("questions", []) or []
        non_inferable = data.get("non_inferable_questions", []) or []

        intent.assumptions = _merge_unique(intent.assumptions, assumptions_add)

        if questions:
            intent.metadata.setdefault("unresolved_questions", [])
            intent.metadata["unresolved_questions"] = _merge_unique(
                intent.metadata["unresolved_questions"], questions
            )

        if non_inferable:
            intent.metadata.setdefault("non_inferable_questions", [])
            intent.metadata["non_inferable_questions"] = _merge_unique(
                intent.metadata["non_inferable_questions"], non_inferable
            )

    def _prompt_non_inferable(self, intent: IntentModel, questions: list[str]) -> int:
        assumptions_stage = self._config.get("stages", {}).get("assumptions", {})
        if "max_questions" not in assumptions_stage:
            msg = "planning.enrichment.stages.assumptions.max_questions is required"
            raise ConfigurationError(
                msg,
                "Set max_questions in config/default_config.yaml or "
                "~/.obra/config-layers/01-user.yaml",
            )
        max_questions = int(assumptions_stage.get("max_questions"))
        if max_questions <= 0:
            return 0

        answers: list[str] = []
        for question in questions[:max_questions]:
            try:
                from obra.display.prompting import prompt_input

                answer = prompt_input(f"[Intent enrichment] {question} ")
            except (EOFError, KeyboardInterrupt):
                break
            answer = answer.strip()
            if answer.lower() in PROCEED_COMMANDS:
                intent.metadata["assumptions_proceed_override"] = True
                console.print("[yellow]Proceeding with assumptions.[/yellow]")
                break
            if answer:
                console.print("[green]✓[/green]")
                answers.append(f"{question} -> {answer}")
        if answers:
            console.print("[dim]Processing your answers...[/dim]")
            intent.context_amendments.extend(answers)
            intent.metadata.setdefault("non_inferable_answers", [])
            intent.metadata["non_inferable_answers"] = _merge_unique(
                intent.metadata["non_inferable_answers"], answers
            )
        return len(answers)

    @staticmethod
    def _should_continue_assumptions_loop(
        *,
        stage_result: EnrichmentStageResult,
        pass_index: int,
        max_passes: int,
        interactive: bool,
        answers_added: int,
        proceed_override: bool,
        ready_to_proceed: bool | None,
        missing_sections: list[str],
    ) -> bool:
        """Decide whether another assumptions pass is warranted."""
        if proceed_override:
            return False
        if pass_index >= max_passes - 1:
            return False
        if not interactive or not sys.stdin.isatty():
            return False
        if not stage_result.parsed:
            return False
        if ready_to_proceed is True and not missing_sections:
            return False
        non_inferable = stage_result.parsed.get("non_inferable_questions") or []
        if not non_inferable:
            return False
        return not answers_added <= 0

    @staticmethod
    def _log_assumptions_quality_decision(
        *,
        stage_name: str,
        ready_to_proceed: bool | None,
        missing_sections: list[str],
        will_continue: bool,
        interactive: bool,
        answers_added: int,
        proceed_override: bool,
    ) -> None:
        missing_preview = ", ".join(missing_sections) if missing_sections else ""

        # LLM didn't return a quality signal — no gaps flagged
        if ready_to_proceed is None and not missing_sections:
            console.print("[dim]No additional questions needed[/dim]")
            return

        # Will ask follow-up questions
        if will_continue:
            if missing_preview:
                console.print(
                    f"[dim]Need more context on: {missing_preview}"
                    " — asking follow-up questions[/dim]"
                )
            else:
                console.print("[dim]Asking follow-up questions to enhance context[/dim]")
            return

        # Quality sufficient — ready to plan
        if ready_to_proceed is True and not missing_sections:
            console.print("[dim]Context sufficient — proceeding to planning[/dim]")
            return

        # Quality not sufficient but cannot continue — explain why
        reason = "no further questions available"
        if proceed_override:
            reason = "proceed override requested"
        elif not interactive or not sys.stdin.isatty():
            reason = "non-interactive session"
        elif answers_added <= 0:
            reason = "no new answers provided"
        if missing_preview:
            console.print(
                f"[dim]Some gaps remain ({missing_preview}) but {reason}"
                " — proceeding[/dim]"
            )
        else:
            console.print(f"[dim]Proceeding — {reason}[/dim]")

    def _apply_expert_updates(self, intent: IntentModel, result: EnrichmentStageResult) -> None:
        updates = result.parsed.get("proposed_intent_updates", {}) or {}
        intent.assumptions = _merge_unique(intent.assumptions, updates.get("assumptions_add", []))
        intent.requirements = _merge_unique(
            intent.requirements, updates.get("requirements_add", [])
        )
        intent.constraints = _merge_unique(intent.constraints, updates.get("constraints_add", []))
        intent.non_goals = _merge_unique(intent.non_goals, updates.get("non_goals_add", []))
        intent.risks = _merge_unique(intent.risks, updates.get("risks_add", []))
        intent.acceptance_criteria = _merge_unique(
            intent.acceptance_criteria, updates.get("acceptance_criteria_add", [])
        )

        domain_inference = result.parsed.get("domain_inference")
        if domain_inference:
            intent.metadata["domain_inference"] = domain_inference

        expert_approach = result.parsed.get("expert_approach")
        if expert_approach:
            intent.metadata["expert_approach"] = expert_approach

        intent_gaps = result.parsed.get("intent_gaps")
        if intent_gaps:
            intent.metadata["intent_gaps"] = intent_gaps

    def _apply_brief_update(self, intent: IntentModel, result: EnrichmentStageResult) -> None:
        data = result.parsed
        if not data:
            return
        intent.problem_statement = data.get("problem_statement", intent.problem_statement)
        intent.assumptions = data.get("assumptions", intent.assumptions) or intent.assumptions
        intent.requirements = data.get("requirements", intent.requirements) or intent.requirements
        intent.constraints = data.get("constraints", intent.constraints) or intent.constraints
        intent.acceptance_criteria = (
            data.get("acceptance_criteria", intent.acceptance_criteria)
            or intent.acceptance_criteria
        )
        intent.non_goals = data.get("non_goals", intent.non_goals) or intent.non_goals
        intent.risks = data.get("risks", intent.risks) or intent.risks

    def _write_intent_diff(
        self,
        before: IntentModel,
        after: IntentModel,
        stage_result: EnrichmentStageResult,
    ) -> Path | None:
        diff_config = self._config.get("diff", {})
        path_template = diff_config.get("path_template")
        if not path_template:
            msg = "planning.enrichment.diff.path_template is required"
            raise ConfigurationError(
                msg,
                "Set planning.enrichment.diff.path_template in config.",
            )
        diff_path = Path(path_template.format(intent_id=after.id)).expanduser()
        diff_data = build_intent_diff(
            before,
            after,
            stage="enrichment",
            rationale=stage_result.parsed.get("rationale"),
            metadata={
                "non_inferable_questions": after.metadata.get("non_inferable_questions", []),
                "non_inferable_answers": after.metadata.get("non_inferable_answers", []),
            },
        )
        diff_path.parent.mkdir(parents=True, exist_ok=True)
        diff_path.write_text(render_intent_diff(diff_data), encoding="utf-8")
        return diff_path

    def _write_stage_artifacts(
        self,
        intent_id: str,
        stage_results: list[EnrichmentStageResult],
    ) -> list[Path]:
        artifacts_config = self._config.get("artifacts", {})
        artifacts_dir = artifacts_config.get("dir")
        if not artifacts_dir:
            msg = "planning.enrichment.artifacts.dir is required"
            raise ConfigurationError(
                msg,
                "Set planning.enrichment.artifacts.dir in config.",
            )
        root = Path(artifacts_dir).expanduser() / intent_id
        root.mkdir(parents=True, exist_ok=True)
        artifacts: list[Path] = []
        for result in stage_results:
            if not result.raw_response:
                continue
            path = root / f"{result.name}.md"
            path.write_text(result.raw_response, encoding="utf-8")
            artifacts.append(path)
        return artifacts

    def _log_telemetry(self, intent_id: str, stage_results: list[EnrichmentStageResult]) -> None:
        telemetry_config = self._config.get("telemetry", {})
        if not telemetry_config.get("enabled", False):
            return
        output_path = telemetry_config.get("output_path")
        if not output_path:
            msg = "planning.enrichment.telemetry.output_path is required"
            raise ConfigurationError(
                msg,
                "Set planning.enrichment.telemetry.output_path in config.",
            )
        include_content = bool(telemetry_config.get("include_content", False))
        stages_payload = []
        for result in stage_results:
            entry = {
                "stage": result.name,
                "duration_s": result.duration_s,
                "parsed_keys": sorted(result.parsed.keys()),
            }
            if include_content:
                entry["raw_response"] = result.raw_response
            stages_payload.append(entry)
        log_enrichment_event(
            Path(output_path),
            {
                "intent_id": intent_id,
                "stages": stages_payload,
            },
        )

    def _run_retention_cleanup(
        self,
        *,
        protected_diff_paths: set[Path] | None = None,
        protected_artifact_paths: set[Path] | None = None,
    ) -> None:
        diff_retention = self._config.get("diff", {}).get("retention", {})
        artifacts_retention = self._config.get("artifacts", {}).get("retention", {})

        diff_path = self._config.get("diff", {}).get("path_template")
        if diff_path:
            if "max_files" not in diff_retention:
                msg = "planning.enrichment.diff.retention.max_files is required"
                raise ConfigurationError(
                    msg,
                    "Set diff retention values in config/default_config.yaml or ~/.obra/config-layers/01-user.yaml",
                )
            diff_root = Path(diff_path.format(intent_id="_placeholder")).expanduser().parent
            cleanup_retention(
                diff_root,
                max_files=int(diff_retention.get("max_files")),
                protected_paths=protected_diff_paths,
            )

        artifacts_dir = self._config.get("artifacts", {}).get("dir")
        if artifacts_dir:
            if "max_files" not in artifacts_retention:
                msg = "planning.enrichment.artifacts.retention.max_files is required"
                raise ConfigurationError(
                    msg,
                    "Set artifacts retention values in config/default_config.yaml or ~/.obra/config-layers/01-user.yaml",
                )
            cleanup_retention(
                Path(artifacts_dir),
                max_files=int(artifacts_retention.get("max_files")),
                protected_paths=protected_artifact_paths,
            )

    def _get_stage_config(self, stage: str) -> dict[str, Any]:
        stages = self._config.get("stages")
        if not isinstance(stages, dict):
            msg = "planning.enrichment.stages must be a mapping"
            raise ConfigurationError(
                msg,
                "Set planning.enrichment.stages in config.",
            )
        stage_config = stages.get(stage)
        if not isinstance(stage_config, dict):
            msg = f"planning.enrichment.stages.{stage} must be a mapping"
            raise ConfigurationError(
                msg,
                f"Set planning.enrichment.stages.{stage} in config.",
            )
        return stage_config

    def _build_stream_handler(self, stage_name: str):
        if not self._on_stream:
            return None
        return lambda chunk: self._on_stream(stage_name, chunk)

    @staticmethod
    def _validate_assumptions(content: dict) -> tuple[bool, str | None]:
        """Validate assumptions template content.

        Checks:
        - assumptions_add and constraints_add keys exist and are lists
        - At least one assumption or constraint is present
        - No '<FILL:>' placeholders in values

        Args:
            content: Parsed template content

        Returns:
            (True, None) if valid, (False, error_message) if invalid
        """
        if "assumptions_add" not in content:
            return (False, "Missing 'assumptions_add' key")
        if "constraints_add" not in content:
            return (False, "Missing 'constraints_add' key")

        assumptions = content["assumptions_add"]
        constraints = content["constraints_add"]

        if not isinstance(assumptions, list):
            return (False, "'assumptions_add' must be a list")
        if not isinstance(constraints, list):
            return (False, "'constraints_add' must be a list")

        if not assumptions and not constraints:
            return (False, "Both assumptions and constraints are empty")

        # Check for unfilled placeholders
        for item in assumptions:
            if isinstance(item, str) and "<FILL:" in item:
                return (False, f"Unfilled assumption placeholder: {item}")
        for item in constraints:
            if isinstance(item, str) and "<FILL:" in item:
                return (False, f"Unfilled constraint placeholder: {item}")

        return (True, None)

    @staticmethod
    def _validate_brief(content: dict) -> tuple[bool, str | None]:
        """Validate brief template content.

        Checks:
        - problem_statement key exists, is string, not empty
        - No '<FILL:>' placeholders in problem_statement

        Args:
            content: Parsed template content

        Returns:
            (True, None) if valid, (False, error_message) if invalid
        """
        if "problem_statement" not in content:
            return (False, "Missing 'problem_statement' key")

        problem_statement = content["problem_statement"]

        if not isinstance(problem_statement, str):
            return (False, "'problem_statement' must be a string")

        if not problem_statement or not problem_statement.strip():
            return (False, "'problem_statement' is empty")

        if "<FILL:" in problem_statement:
            return (False, "Unfilled problem_statement placeholder")

        return (True, None)

    @staticmethod
    def _validate_expert_alignment(content: dict) -> tuple[bool, str | None]:
        """Validate expert alignment template content.

        Checks:
        - expert_perspective key exists (optional check)
        - technical_considerations key exists, is list, not empty
        - No '<FILL:>' placeholders in technical_considerations

        Args:
            content: Parsed template content

        Returns:
            (True, None) if valid, (False, error_message) if invalid
        """
        if "expert_perspective" not in content:
            return (False, "Missing 'expert_perspective' key")

        if "technical_considerations" not in content:
            return (False, "Missing 'technical_considerations' key")

        technical_considerations = content["technical_considerations"]

        if not isinstance(technical_considerations, list):
            return (False, "'technical_considerations' must be a list")

        if not technical_considerations:
            return (False, "'technical_considerations' is empty")

        # Check for unfilled placeholders
        for item in technical_considerations:
            if isinstance(item, str) and "<FILL:" in item:
                return (False, f"Unfilled technical_consideration placeholder: {item}")

        expert_perspective = content["expert_perspective"]
        if isinstance(expert_perspective, str) and "<FILL:" in expert_perspective:
            return (False, "Unfilled expert_perspective placeholder")

        return (True, None)

    @staticmethod
    def _format_intent(intent: IntentModel) -> str:
        sections = [f"# Intent: {intent.problem_statement}", ""]
        sections.extend(_render_section("Assumptions", intent.assumptions))
        sections.extend(_render_section("Requirements", intent.requirements))
        sections.extend(_render_section("Constraints", intent.constraints))
        sections.extend(_render_section("Acceptance Criteria", intent.acceptance_criteria))
        sections.extend(_render_section("Non-Goals", intent.non_goals))
        sections.extend(_render_section("Risks", intent.risks))
        return "\n".join(sections)


def _render_section(title: str, items: list[str]) -> list[str]:
    if not items:
        return [f"## {title}", "", "- _None documented._", ""]
    return [f"## {title}", "", *(f"- {item}" for item in items), ""]


def _parse_quality_signal(
    stage_result: EnrichmentStageResult,
) -> tuple[bool | None, list[str]]:
    quality_signal = stage_result.parsed.get("quality_signal") or {}
    ready_to_proceed = quality_signal.get("ready_to_proceed")
    if not isinstance(ready_to_proceed, bool):
        ready_to_proceed = None
    missing_sections_raw = quality_signal.get("missing_sections") or []
    if not isinstance(missing_sections_raw, list):
        missing_sections_raw = []
    missing_sections = [
        section.strip()
        for section in missing_sections_raw
        if isinstance(section, str) and section.strip()
    ]
    return ready_to_proceed, missing_sections


def _merge_unique(existing: list[str], additions: list[str] | None) -> list[str]:
    merged = list(existing)
    for item in additions or []:
        if item and item not in merged:
            merged.append(item)
    return merged
