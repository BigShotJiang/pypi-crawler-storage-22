"""CLI commands for the Obra hybrid orchestration package.

This module provides all CLI commands for the unified obra package:
- Main workflow: obra run "objective" to start orchestrated tasks
- status: Check session status
- resume: Resume an interrupted session
- login/logout/whoami: Authentication commands
- config: Configuration management
- docs: Access local documentation
- doctor: Run health checks (includes version and server compatibility)
- plans: Manage plan files (upload, list, delete) for SaaS

Usage:
    $ obra --version
    $ obra run "Add user authentication"
    $ obra run --plan-id abc123 "Execute uploaded plan"
    $ obra run --plan-file plan.yaml "Upload and execute plan"
    $ obra status
    $ obra status <session_id>
    $ obra resume <session_id>
    $ obra login
    $ obra logout
    $ obra whoami
    $ obra config
    $ obra docs
    $ obra doctor
    $ obra plans upload path/to/plan.yaml
    $ obra plans list
    $ obra plans delete <plan_id>

Note: For local plan validation, use 'dobra plan validate' instead.

Reference: EPIC-HYBRID-001 Story S10: CLI Commands
          FEAT-PLAN-IMPORT-OBRA-001: Plan File Import
"""

import contextlib
import json
import os

# ISSUE-DOBRA-008: Configure UTF-8 console encoding FIRST, before any imports
# This is the industry-standard solution for Windows console Unicode issues.
import sys
from datetime import UTC, datetime
from http import HTTPStatus

if hasattr(sys.stdout, "reconfigure") and sys.stdout is not None:
    with contextlib.suppress(Exception):
        sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")
if hasattr(sys.stderr, "reconfigure") and sys.stderr is not None:
    with contextlib.suppress(Exception):
        sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
os.environ.setdefault("PYTHONIOENCODING", "utf-8:backslashreplace")

import logging
import platform
import re
import time
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, TypedDict, cast

import click
import typer
import yaml  # type: ignore[import-untyped]
from rich.console import Console
from rich.table import Table

from obra import __version__
from obra.api.protocol import EscalationNotice, UserDecisionChoice

# Bootstrap safety: validate default_config.yaml exists before heavy imports.
# This fails fast with a clear error if installation is corrupted (S1.T2).
from obra.config.loaders import get_cli_retry_config, validate_default_schema

validate_default_schema()

from obra.cli_commands import UploadPlanCommand
from obra.config import (
    DEFAULT_MODEL,
    DEFAULT_PROVIDER,
    DEFAULT_THINKING_LEVEL,
    THINKING_LEVELS,
    get_thinking_level_notes,
    infer_provider_from_model,
    load_config,
)
from obra.constants import KIBIBYTE
from obra.core.interrupts import (
    GracefulInterrupt,
    clear_interrupt_request,
    defer_interrupts,
    request_interrupt,
    should_defer_interrupts,
)
from obra.display import (
    ObservabilityConfig,
    ProgressEmitter,
    console,
    err_console,
    glyphs,
    handle_encoding_errors,
    print_banner,
    print_error,
    print_info,
    print_success,
    print_warning,
    set_runtime_verbosity,
)
from obra.display.closeout import (
    CloseoutContext,
    TerminationState,
    build_closeout_message,
)
from obra.display.errors import display_error, display_obra_error
from obra.exceptions import (
    APIError,
    AuthenticationError,
    ConfigurationError,
    ObraError,
)
from obra.exceptions import (
    ConnectionError as ObraConnectionError,
)
from obra.feedback.session_logger import (
    rename_session_logging,
    start_session_logging,
    stop_session_logging,
)
from obra.messages import get_message
from obra.messages.warnings import build_deprecation_warning
from obra.model_registry import resolve_quality_tier
from obra.review.config import ALLOWED_AGENTS, ReviewConfig, ReviewConfigCLIInputs
from obra.utils.git_utils import is_git_repository
from obra.utils.obra_home import (
    legacy_notice_needed,
    mark_legacy_notice_shown,
    resolve_runtime_dir,
)
from obra.version_check import check_for_updates_async

logger = logging.getLogger(__name__)

MAX_OBJECTIVE_PREVIEW = 160

# ============================================================================
# Interrupt handling state for double Ctrl+C force-quit
# ============================================================================
# Tracks interrupt count and timestamp for graceful vs force quit behavior:
# - First Ctrl+C: Shows message, attempts graceful shutdown
# - Second Ctrl+C within 3s: Force quits immediately
# - Third+ Ctrl+C (anytime): Force quits immediately (bypasses countdown)
_interrupt_state: dict[str, Any] = {
    "last_time": 0.0,  # Timestamp of last interrupt
    "count": 0,  # Number of interrupts within window
    "total": 0,  # Total interrupts this session (never resets)
    "session_id": None,  # Current session ID for resume hints
    "orchestrator": None,  # Orchestrator reference for fallback session_id lookup
    "recovery_hint_printed": False,  # Prevent duplicate interrupt recovery output
    "recovery_hint_session_id": None,  # Session ID used when recovery hint last printed
}
_FORCE_QUIT_WINDOW_SECONDS: float = 3.0  # Time window for double Ctrl+C


# Valid work types for --work-type flag (from work_type_patterns.json)
VALID_WORK_TYPES = (
    "feature_implementation",
    "bug_fix",
    "refactoring",
    "documentation",
    "testing",
    "performance",
    "security",
    "configuration",
    "infrastructure",
    "dependencies",
    "general",
)

if TYPE_CHECKING:
    from obra.feedback import PrivacyLevel, Severity


def _print_bug_hint() -> None:
    """Print a hint to report bugs after errors."""
    console.print("[dim]Report this issue: obra bug 'description'[/dim]")


def _resolve_interrupt_session_id(session_id: str | None = None) -> str | None:
    """Resolve best-available session ID from explicit arg, interrupt state, or orchestrator."""
    sid = session_id or _interrupt_state.get("session_id")
    if not sid or sid == "<pending>":
        orch = _interrupt_state.get("orchestrator")
        if orch and hasattr(orch, "session_id"):
            sid = orch.session_id
    if not sid or sid == "<pending>":
        return None
    return str(sid)


def _print_interrupt_resume_block(
    session_id: str | None = None, *, mark_as_printed: bool = False
) -> None:
    """Print a compact Ctrl+C recovery block with resume/continue commands."""
    from obra.display.recovery_hints import build_interrupt_recovery_hints

    sid = _resolve_interrupt_session_id(session_id)

    console.print(glyphs.divider)
    for line in build_interrupt_recovery_hints(sid).splitlines():
        if line:
            console.print(f"[dim]{line}[/dim]")
        else:
            console.print()
    if mark_as_printed:
        _interrupt_state["recovery_hint_printed"] = True
        _interrupt_state["recovery_hint_session_id"] = sid


def _print_session_resume_hints(session_id: str | None = None) -> None:
    """Print session resume and continue hints after errors.

    This provides a consistent UX for recovering from session crashes/errors.
    Resolves session ID from: explicit arg → _interrupt_state → orchestrator.

    Args:
        session_id: Optional session ID to use. If None, resolves from state.
    """
    sid = _resolve_interrupt_session_id(session_id)
    if not sid:
        return

    short_id = str(sid).split("-")[0]
    console.print(glyphs.divider)
    console.print(
        f"[dim]Resume:   obra run --resume {short_id}  (pick up exactly where you left off)[/dim]"
    )
    console.print(
        f"[dim]Continue: obra run --continue-from {short_id}  "
        "(re-derive, skip completed; uses original objective)[/dim]"
    )


def _print_session_completion_footer(
    session_id: str | None = None,
    was_escalated: bool = False,
    items_completed: int = 0,
) -> None:
    """Print session completion footer with stats and next-step hints.

    Called after successful session completion (not just errors) to provide
    clear guidance on how to continue or review the work.

    Args:
        session_id: Session ID for resume/continue hints
        was_escalated: Whether the session was escalated (affects messaging)
        items_completed: Number of items completed (for context)
    """
    sid = _resolve_interrupt_session_id(session_id)
    if not sid:
        return

    short_id = str(sid).split("-")[0]
    console.print()
    console.print(glyphs.divider)

    if was_escalated:
        console.print("[bold]Session escalated - manual intervention needed[/bold]")
        console.print()
        console.print(f"[dim]Status:   obra sessions show {short_id}[/dim]")
        console.print(f"[dim]Resume:   obra run --resume {short_id}[/dim]")
    elif items_completed == 0:
        console.print("[bold]Session ended with no items completed[/bold]")
        console.print()
        console.print(f"[dim]Status:   obra sessions show {short_id}[/dim]")
        console.print(f"[dim]Retry:    obra run --continue-from {short_id}[/dim]")
    else:
        console.print(f"[bold]Session {short_id} complete[/bold]")
        console.print()
        console.print(f"[dim]Review:   obra sessions show {short_id}[/dim]")
        console.print(f"[dim]Plan:     obra sessions plan {short_id}[/dim]")
        console.print(f"[dim]Continue: obra run --continue-from {short_id}[/dim]")


def _build_escalation_callback() -> Callable[[EscalationNotice], UserDecisionChoice]:
    """Create interactive escalation callback used by run/resume."""

    def on_escalation(notice: EscalationNotice) -> UserDecisionChoice:
        print_warning(f"Escalation: {notice.reason.value}")

        blocking_issues = notice.blocking_issues
        if not isinstance(blocking_issues, list):
            blocking_issues = []
        valid_issues = [issue for issue in blocking_issues if isinstance(issue, dict)]
        if valid_issues:
            console.print(f"  Blocking issues: {len(valid_issues)}")
            for issue in valid_issues[:5]:
                priority = issue.get("priority", "P3")
                description = issue.get("description", "Unknown")
                console.print(f"    - [{priority}] {description}")

        convergence_diagnostic = (
            notice.convergence_diagnostic
            if isinstance(notice.convergence_diagnostic, dict)
            else {}
        )
        if convergence_diagnostic:
            console.print("  Convergence diagnostic:")

            raw_sizes = convergence_diagnostic.get("per_cycle_blocking_sizes", {})
            if isinstance(raw_sizes, dict) and raw_sizes:
                sorted_sizes = sorted(
                    (
                        (str(iteration), int(size))
                        for iteration, size in raw_sizes.items()
                    ),
                    key=lambda item: (
                        int(item[0]) if item[0].isdigit() else 10_000_000,
                        item[0],
                    ),
                )
                size_summary = ", ".join(
                    f"{iteration}:{size}" for iteration, size in sorted_sizes
                )
                console.print(f"    - Blocking sizes by cycle: {size_summary}")

            raw_persisted = convergence_diagnostic.get("persisted_issues", [])
            persisted_issues = (
                [str(issue_id) for issue_id in raw_persisted if str(issue_id).strip()]
                if isinstance(raw_persisted, list)
                else []
            )
            if persisted_issues:
                console.print(
                    "    - Persisted issues: "
                    + ", ".join(persisted_issues[:5])
                    + (" ..." if len(persisted_issues) > 5 else "")
                )

            raw_appeared = convergence_diagnostic.get("appeared_issues", [])
            appeared_issues = (
                [str(issue_id) for issue_id in raw_appeared if str(issue_id).strip()]
                if isinstance(raw_appeared, list)
                else []
            )
            if appeared_issues:
                console.print(
                    "    - Appeared during stale window: "
                    + ", ".join(appeared_issues[:5])
                    + (" ..." if len(appeared_issues) > 5 else "")
                )

        is_interactive = bool(
            getattr(sys.stdin, "isatty", lambda: False)()
            and getattr(sys.stdout, "isatty", lambda: False)()
        )
        if not is_interactive:
            print_warning(
                "Non-interactive session detected; defaulting escalation decision to force_complete."
            )
            return UserDecisionChoice.FORCE_COMPLETE

        while True:
            choice = (
                typer.prompt(
                    "Escalation action: [c]ontinue fixing / [f]orce complete / [a]bandon",
                    default="c",
                )
                .strip()
                .lower()
            )
            if choice in {"c", "continue", "continue_fixing"}:
                return UserDecisionChoice.CONTINUE_FIXING
            if choice in {"f", "force", "force_complete"}:
                return UserDecisionChoice.FORCE_COMPLETE
            if choice in {"a", "abandon"}:
                return UserDecisionChoice.ABANDON
            print_warning("Invalid choice. Enter c, f, or a.")

    return on_escalation


def _maybe_print_legacy_runtime_notice() -> None:
    """Emit a one-time notice when legacy runtime path is active."""
    selection = resolve_runtime_dir()
    if not legacy_notice_needed(selection):
        return

    print_warning(
        "Using legacy runtime directory "
        f"{selection.path}. The canonical runtime path is ~/.obra-runtime. "
        "Set OBRA_RUNTIME_DIR to override."
    )
    mark_legacy_notice_shown(selection)


# Enforce UTF-8 mode for consistent cross-platform behavior
os.environ.setdefault("PYTHONUTF8", "1")


# =============================================================================
# Terms Acceptance Decorator
# =============================================================================


def require_terms_accepted(func):
    """Decorator to ensure terms have been accepted before running a command.

    Checks if the user has accepted the current version of the Beta Software
    Agreement. If not, raises TermsNotAcceptedError with clear instructions
    to run 'obra setup'.

    Raises:
        TermsNotAcceptedError: If terms not accepted or version mismatch

    Example:
        @app.command()
        @require_terms_accepted
        def my_command():
            # This will only run if terms are accepted
            pass
    """
    import functools

    from obra.config import TERMS_VERSION, is_terms_accepted, needs_reacceptance
    from obra.exceptions import TermsNotAcceptedError

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # Check if terms have been accepted
        if not is_terms_accepted():
            raise TermsNotAcceptedError(
                message="Terms not accepted",
                required_version=TERMS_VERSION,
                action=get_message("recovery.auth.terms"),
            )

        # Check if re-acceptance is needed due to version change
        if needs_reacceptance():
            raise TermsNotAcceptedError(
                message=f"Terms have been updated to version {TERMS_VERSION}",
                required_version=TERMS_VERSION,
                action=get_message("recovery.auth.terms"),
            )

        return func(*args, **kwargs)

    return wrapper


# Create Typer app with custom error handling
app = typer.Typer(
    name="obra",
    help="""Obra - AI Orchestration for Autonomous Development

┌─────────────────────────────────────────────────────────────────────────┐
│  🤖 AI ASSISTANTS: Run `obra briefing quick` for input quality guide   │
│     (~2 min read, 1,500 tokens). Full guide: `obra briefing`           │
└─────────────────────────────────────────────────────────────────────────┘
Plan mode note: Atomic ideas can use `plan_mode=one_step` (see docs/development/backlog/ONE_STEP_PLAN.md) and log validations under `docs/quality/MANUAL_TESTING_LOG.json` so the planner keeps acceptance/tests/docs explicit.
""",
    no_args_is_help=True,  # Show help when no command specified
    rich_markup_mode="rich",
    epilog='Run `obra run "<objective>"` or `obra briefing` to get started.\nEncountered a problem? Run `obra bug "<description>"` to report it.',
)


def setup_logging(verbose: int = 0) -> None:
    """Configure logging for CLI commands.

    Args:
        verbose: Verbosity level (0-3); logs shown only when verbose >= 2
    """
    # Verbosity level mapping: 0-1=ERROR, 2=INFO, 3+=DEBUG - CLI design constant
    if verbose <= 1:
        level = logging.ERROR
    elif verbose == 2:
        level = logging.INFO
    else:
        level = logging.DEBUG

    class _QuietInfoFormatter(logging.Formatter):
        """Dim INFO lines and colorize severity tags in TTY."""

        def __init__(self, use_color: bool) -> None:
            super().__init__()
            self._use_color = use_color

        def format(self, record: logging.LogRecord) -> str:
            level = record.levelname
            timestamp = self.formatTime(record, self.datefmt)
            message = record.getMessage()
            base = f"{level} [{timestamp}] {record.name} - {message}"

            if record.exc_info:
                base = f"{base}\n{self.formatException(record.exc_info)}"
            if record.stack_info:
                base = f"{base}\n{self.formatStack(record.stack_info)}"

            if not self._use_color:
                return base

            if record.levelno == logging.INFO:
                return f"\x1b[90m{base}\x1b[0m"
            if record.levelno >= logging.ERROR:
                tag = f"\x1b[31m{level}\x1b[0m"
            elif record.levelno == logging.WARNING:
                tag = f"\x1b[33m{level}\x1b[0m"
            else:
                return base

            return base.replace(level, tag, 1)

    use_color = hasattr(sys.stderr, "isatty") and sys.stderr.isatty()
    from obra.display.spinner import suspend_active_spinner

    class _SpinnerAwareHandler(logging.StreamHandler):
        """Logging handler that suspends the active spinner during emits."""

        def emit(self, record: logging.LogRecord) -> None:
            with suspend_active_spinner():
                super().emit(record)

    handler = _SpinnerAwareHandler()
    handler.setLevel(level)
    handler.setFormatter(_QuietInfoFormatter(use_color=use_color))
    logging.basicConfig(level=level, handlers=[handler])


def _resolve_command_verbosity(ctx: typer.Context, verbose: int) -> int:
    """Prefer global verbosity when the command-level flag is not set."""
    try:
        source = ctx.get_parameter_source("verbose")
    except Exception:
        return verbose
    if source == click.core.ParameterSource.DEFAULT:
        ctx_obj = ctx.obj if isinstance(ctx.obj, dict) else {}
        ctx_verbose = ctx_obj.get("verbose")
        if isinstance(ctx_verbose, int):
            return ctx_verbose
    return verbose


def _extract_completion_context(
    result: Any,
) -> tuple[int, Any, Any, bool, str]:
    items_completed = 0
    total_iterations: Any = "N/A"
    quality_score: Any = "N/A"
    was_escalated = False
    terminal_phase = ""

    if hasattr(result, "session_summary") and isinstance(result.session_summary, dict):
        summary = result.session_summary
        items_completed = int(summary.get("items_completed", 0) or 0)
        total_iterations = summary.get("total_iterations", "N/A")
        quality_score = summary.get("quality_score", "N/A")
        was_escalated = bool(summary.get("was_escalated", False))
        terminal_phase = summary.get("terminal_phase", "")
    elif hasattr(result, "items_completed"):
        items_completed = int(getattr(result, "items_completed", 0) or 0)
        total_iterations = getattr(result, "total_iterations", "N/A")
        quality_score = getattr(result, "quality_score", "N/A")

    result_was_escalated = getattr(result, "was_escalated", None)
    if isinstance(result_was_escalated, bool):
        was_escalated = result_was_escalated

    result_terminal_phase = getattr(result, "terminal_phase", None)
    if isinstance(result_terminal_phase, str) and result_terminal_phase:
        terminal_phase = result_terminal_phase

    return (
        items_completed,
        total_iterations,
        quality_score,
        was_escalated,
        terminal_phase,
    )


def _map_to_termination_state(
    result: Any,
    *,
    was_interrupted: bool = False,
) -> TerminationState:
    """Map result to TerminationState for closeout message.

    Args:
        result: Session completion result object
        was_interrupted: True if session was interrupted by user (Ctrl+C)

    Returns:
        TerminationState enum value
    """
    if was_interrupted:
        return TerminationState.INTERRUPTED

    # Check for escalation flag
    was_escalated = getattr(result, "was_escalated", None)
    if was_escalated is True:
        return TerminationState.ESCALATED

    # Check session_summary dict for escalation
    if hasattr(result, "session_summary") and isinstance(result.session_summary, dict):
        if result.session_summary.get("was_escalated"):
            return TerminationState.ESCALATED

    # Check status attribute (from SessionStatus enum or string)
    status = getattr(result, "status", None)
    if status is not None:
        status_str = str(status).lower()
        if "failed" in status_str:
            return TerminationState.FAILED
        if "expired" in status_str:
            return TerminationState.EXPIRED
        if "abandoned" in status_str:
            return TerminationState.ABANDONED
        if "escalated" in status_str:
            return TerminationState.ESCALATED

    return TerminationState.COMPLETED


def _safe_numeric(value: Any, default: float = 0.0) -> float:
    """Safely extract a numeric value, returning default if not a number.

    Handles cases where value might be a MagicMock or other non-numeric type
    (common in tests with incomplete mocking).
    """
    if isinstance(value, (int, float)):
        return float(value)
    return default


def _safe_int(value: Any, default: int = 0) -> int:
    """Safely extract an integer value, returning default if not a number."""
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return default


def _build_closeout_context(
    result: Any,
    session_id: str | None,
    objective: str = "",
    *,
    was_interrupted: bool = False,
) -> CloseoutContext:
    """Build CloseoutContext from result for closeout message.

    Extracts all available data from session result to populate closeout context.

    Args:
        result: Session completion result (CompletionNotice or similar)
        session_id: Session ID for display
        objective: Original objective (fallback if not in result)
        was_interrupted: True if session was interrupted by user

    Returns:
        CloseoutContext populated with session data
    """
    # Get basic completion context
    (
        items_completed,
        _total_iterations,  # Not used directly; CloseoutContext doesn't track iterations
        quality_score,
        _was_escalated,  # Used via _map_to_termination_state for state determination
        terminal_phase,
    ) = _extract_completion_context(result)

    # Normalize quality score to 0-100 (may come as 0.0-1.0)
    if isinstance(quality_score, (int, float)):
        if quality_score <= 1.0:
            quality_score = quality_score * 100
    else:
        quality_score = 0.0

    # Extract enhanced closeout fields from result
    # Use _safe_numeric/_safe_int for numeric fields to handle MagicMock in tests
    result_objective = getattr(result, "objective", "") or objective
    work_summary = getattr(result, "work_summary", []) or []
    duration_seconds = _safe_numeric(getattr(result, "duration_seconds", 0.0))
    total_duration_seconds = _safe_numeric(getattr(result, "total_duration_seconds", 0.0))
    invocation_count = _safe_int(getattr(result, "invocation_count", 1), default=1)
    files_created = getattr(result, "files_created", []) or []
    files_modified = getattr(result, "files_modified", []) or []
    git_branch = getattr(result, "git_branch", "") or ""
    git_commit_hash = getattr(result, "git_commit_hash", "") or ""
    termination_reason = getattr(result, "termination_reason", "") or ""
    warnings = getattr(result, "warnings", []) or []
    epics_completed = _safe_int(getattr(result, "epics_completed", 0))
    epics_total = _safe_int(getattr(result, "epics_total", 0))
    stories_completed = _safe_int(getattr(result, "stories_completed", 0))
    stories_total = _safe_int(getattr(result, "stories_total", 0))
    tasks_completed = _safe_int(getattr(result, "tasks_completed", 0))
    tasks_total = _safe_int(getattr(result, "tasks_total", 0))

    # Try to get data from session_summary dict if direct attrs not available
    if hasattr(result, "session_summary") and isinstance(result.session_summary, dict):
        summary = result.session_summary
        if not result_objective:
            result_objective = summary.get("objective", objective)
        if not items_completed:
            items_completed = summary.get("items_completed", 0)

    # Determine termination state
    state = _map_to_termination_state(result, was_interrupted=was_interrupted)

    plan_final = getattr(result, "plan_final", []) or []
    if (
        epics_total == 0
        and stories_total == 0
        and tasks_total == 0
        and isinstance(plan_final, list)
    ):
        counts = {"epic": 0, "story": 0, "task": 0}
        for item in plan_final:
            if not isinstance(item, dict):
                continue
            item_type = item.get("item_type")
            if item_type in counts:
                counts[item_type] += 1
        epics_total = counts["epic"]
        stories_total = counts["story"]
        tasks_total = counts["task"]
        if state == TerminationState.COMPLETED:
            epics_completed = epics_total
            stories_completed = stories_total
            tasks_completed = tasks_total
        elif tasks_completed == 0:
            tasks_completed = items_completed

    items_total = tasks_total if tasks_total > 0 else 0

    return CloseoutContext(
        state=state,
        session_id=session_id or "",
        objective=result_objective,
        work_summary=work_summary if work_summary else None,
        items_completed=items_completed,
        items_total=items_total,
        quality_score=quality_score,
        duration_seconds=duration_seconds,
        total_duration_seconds=total_duration_seconds,
        invocation_count=invocation_count,
        files_created=files_created if files_created else None,
        files_modified=files_modified if files_modified else None,
        git_branch=git_branch,
        git_commit_hash=git_commit_hash,
        termination_reason=termination_reason,
        warnings=warnings if warnings else None,
        terminal_phase=terminal_phase,
        epics_completed=epics_completed,
        epics_total=epics_total,
        stories_completed=stories_completed,
        stories_total=stories_total,
        tasks_completed=tasks_completed or items_completed,
        tasks_total=tasks_total,
    )


def _format_completion_message(terminal_phase: str, was_escalated: bool) -> str:
    phase = (terminal_phase or "").lower()
    if was_escalated:
        return {
            "derivation": "Plan creation stopped",
            "refinement": "Plan refinement stopped",
            "execution": "Execution stopped",
            "review": "Review failed",
            "story0": "Environment prep stopped",
            "completed": "Session escalated",
        }.get(phase, "Session escalated")
    return {
        "derivation": "Plan created",
        "refinement": "Plan refined",
        "execution": "Execution complete",
        "review": "Review passed",
        "story0": "Environment prepared",
        "completed": "Session complete",
    }.get(phase, "Session complete")


def _print_git_file_summary(console: Console, work_dir: str) -> None:
    console.print(f"\n[dim]Project: {work_dir}[/dim]")
    try:
        import subprocess

        git_result = subprocess.run(
            ["git", "status", "--porcelain"],
            check=False,
            cwd=work_dir,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if git_result.returncode != 0:
            return
        lines = [line for line in git_result.stdout.splitlines() if line.strip()]
        # Git status format requires at least 2 chars (XY status codes) - protocol constant
        created = sum(
            1
            for line in lines
            if len(line) >= 2 and line[:2] in ("??", "A ", "AM", "R ", "RM", "C ", "CM")
        )
        modified = sum(1 for line in lines if len(line) >= 2 and (line[0] == "M" or line[1] == "M"))
        console.print(f"[dim]Files: {created} created, {modified} modified[/dim]")
    except Exception:
        pass  # Non-git or git unavailable - skip file counts


# =============================================================================
# App Callback (Primary Invocation Pattern)
# =============================================================================


def version_callback(value: bool) -> None:
    """Print version and exit when --version is passed."""
    if value:
        print(f"obra {__version__}")
        raise typer.Exit()


@app.callback()
@handle_encoding_errors
def app_callback(
    ctx: typer.Context,
    _version: bool = typer.Option(
        False,
        "--version",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit",
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Reduce output (quiet mode)",
    ),
    session_config: str | None = typer.Option(
        None,
        "--session-config",
        help="Path to a session config layer file",
    ),
    verbose: int = typer.Option(
        1,
        "--verbose",
        "-v",
        count=True,
        help="Verbosity level (0-3, default=progress; use -v/-vv/-vvv)",
    ),
) -> None:
    """Obra - AI Orchestration for Autonomous Development.

    Run subcommands for specific operations, or use 'obra run' for orchestration.
    """
    ctx.obj = ctx.obj or {}
    if quiet:
        verbose = 0
    ctx.obj["verbose"] = verbose
    if session_config:
        os.environ["OBRA_SESSION_CONFIG"] = session_config
    setup_logging(verbose)

    # Ensure ~/.obra/README.md exists with helpful documentation
    # Only creates if missing, lightweight check
    from obra.utils.obra_home import ensure_obra_home_readme, get_obra_home

    readme_path = get_obra_home() / "README.md"
    if not readme_path.exists():
        try:
            ensure_obra_home_readme()
        except Exception:
            pass  # Non-critical, don't fail CLI startup


# =============================================================================
# Help Command (Industry Standard Pattern)
# =============================================================================


@app.command(rich_help_panel="General")
@handle_encoding_errors
def help(
    ctx: typer.Context,
    command: str | None = typer.Argument(
        None,
        help="Command to get help for (e.g., 'run', 'status', 'briefing')",
    ),
) -> None:
    """Get help for Obra commands.

    Like `git help`, shows help for main app or specific commands.
    Tier 2: Supports keyword search - if command not found, searches all commands.

    Examples:
        obra help           # Main help
        obra help run       # Help for 'run' command
        obra help briefing  # Help for 'briefing' command
        obra help upload    # Search for commands matching 'upload'
    """
    import click

    # Get the underlying Click group from Typer
    click_app = typer.main.get_group(app)

    if command is None:
        # Show main help
        with click.Context(click_app) as click_ctx:
            click.echo(click_app.get_help(click_ctx))
        click.echo(
            "\nNote: default verbosity is PROGRESS (same as -v). Use -q/--quiet for minimal output."
        )
    else:
        # Find and show help for specific command
        cmd = click_app.get_command(ctx, command)
        if cmd is None:
            # Tier 2: Command not found - search for matching commands
            # Search for substring matches in command names and descriptions
            matches = []
            search_term = command.lower()

            for cmd_obj in app.registered_commands:
                if not cmd_obj.name:
                    continue

                # Check if search term is in command name
                if search_term in cmd_obj.name.lower():
                    matches.append((cmd_obj.name, "name match"))
                    continue

                # Check if search term is in command description
                if cmd_obj.help and search_term in cmd_obj.help.lower():
                    matches.append((cmd_obj.name, "description match"))

            if matches:
                console.print()
                console.print(f"[yellow]Commands matching '{command}':[/yellow]")
                console.print()
                for cmd_name, _match_type in matches:
                    # Get command to show its help snippet
                    cmd_match = click_app.get_command(ctx, cmd_name)
                    if cmd_match and cmd_match.help:
                        first_line = cmd_match.help.split("\n")[0]
                        console.print(f"  [cyan]obra {cmd_name}[/cyan]")
                        console.print(f"    {first_line}")
                        console.print()
                console.print("[dim]Run 'obra help <command>' for detailed help.[/dim]")
                return

            # No matches found - show error
            print_error(f"Unknown command: {command}")
            print_info("Run 'obra help' to see available commands.")
            raise typer.Exit(1)
        with click.Context(cmd, info_name=command, parent=ctx) as click_ctx:
            click.echo(cmd.get_help(click_ctx))


# =============================================================================
# Procs Command (Process Management)
# =============================================================================


@app.command(rich_help_panel="General")
@handle_encoding_errors
def procs(
    kill: bool = typer.Option(
        False,
        "--kill",
        "-k",
        help="Kill running processes (not just stale PID files)",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Skip confirmation prompt",
    ),
) -> None:
    """Manage Obra background processes and sessions.

    Lists tracked Obra processes (config explorer, etc.) and running sessions.
    Removes stale PID files and optionally kills running processes.

    Examples:
        obra procs             # List processes and sessions
        obra procs --kill      # Kill running processes too
        obra procs -k -f       # Kill without confirmation
    """
    from obra.hybrid.session_guard import find_running_sessions
    from obra.utils.process_guard import cleanup_stale_processes, find_stale_processes

    processes = find_stale_processes()
    sessions = find_running_sessions()

    if not processes and not sessions:
        console.print("[green]No Obra processes or sessions found.[/green]")
        return

    # Show running sessions
    if sessions:
        console.print("\n[bold]Running sessions:[/bold]\n")
        for hb in sessions:
            runtime_h = hb.runtime_seconds / 3600
            progress = (
                f"{hb.items_completed}/{hb.items_total}"
                if hb.items_total
                else str(hb.items_completed)
            )
            warning = ""
            if runtime_h >= 24:
                warning = " [yellow]LONG[/yellow]"
            console.print(
                f"  [cyan]{hb.short_id}[/cyan]: {runtime_h:.1f}h, "
                f"{progress} items, {hb.current_phase} (PID {hb.pid}){warning}"
            )
        console.print()

    # Show other processes
    if processes:
        console.print("[bold]Background processes:[/bold]\n")
        for name, pid, alive in processes:
            status = "[green]running[/green]" if alive else "[dim]stale[/dim]"
            console.print(f"  {name}: PID {pid} ({status})")

        running = [(name, pid) for name, pid, alive in processes if alive]
        stale = [(name, pid) for name, pid, alive in processes if not alive]

        if stale:
            console.print(f"\n[dim]Stale PID files: {len(stale)}[/dim]")
        if running:
            console.print(f"[yellow]Running processes: {len(running)}[/yellow]")

        # Determine what to clean up
        if running and not kill:
            console.print("\n[dim]Use --kill to terminate running processes.[/dim]")
            # Only clean stale
            if stale:
                for name, _pid in stale:
                    console.print(f"  [dim]Removed stale PID file: {name}[/dim]")
                cleanup_stale_processes(kill=False)
                console.print(f"\n[green]Cleaned {len(stale)} stale PID file(s).[/green]")
            return

        # Confirm before killing
        if running and kill and not force:
            console.print()
            if not typer.confirm(f"Kill {len(running)} running process(es)?"):
                console.print("[dim]Cancelled.[/dim]")
                return

        # Do the cleanup
        def on_cleanup(name: str, pid: int) -> None:
            console.print(f"  [green]Cleaned: {name} (PID {pid})[/green]")

        cleaned = cleanup_stale_processes(kill=kill, on_cleanup=on_cleanup)

        if cleaned:
            console.print(f"\n[green]Cleaned {len(cleaned)} process(es).[/green]")
        else:
            console.print("\n[dim]Nothing to clean.[/dim]")


# =============================================================================
# Models Command (Provider/Model Discovery)
# =============================================================================


@app.command(rich_help_panel="General")
@handle_encoding_errors
def models(
    provider: str | None = typer.Option(
        None,
        "--provider",
        "-p",
        help="Filter to specific provider (anthropic, google, openai, ollama)",
    ),
) -> None:
    """List available LLM providers and models.

    Shows all supported providers with their models, CLI tool names,
    and installation status.

    Examples:
        obra models                    # All providers
        obra models --provider openai  # OpenAI models only
    """
    from obra.model_registry import MODEL_REGISTRY, ModelStatus

    # Filter providers if specified
    providers_to_show = (
        {provider: MODEL_REGISTRY[provider]}
        if provider and provider in MODEL_REGISTRY
        else MODEL_REGISTRY
    )

    if provider and provider not in MODEL_REGISTRY:
        print_error(f"Unknown provider: {provider}")
        print_info(f"Available providers: {', '.join(MODEL_REGISTRY.keys())}")
        raise typer.Exit(1)

    import shutil

    console.print("\n[bold]Available LLM Providers[/bold]\n")

    for _provider_key, config in providers_to_show.items():
        # Check CLI installation status
        cli_installed = shutil.which(config.cli) is not None
        status_icon = (
            f"[green]{glyphs.success}[/green]" if cli_installed else f"[red]{glyphs.failure}[/red]"
        )
        status_text = "installed" if cli_installed else "not installed"

        # Provider header
        console.print(f"[bold cyan]{config.name}[/bold cyan]")
        console.print(f"  CLI: [yellow]{config.cli}[/yellow] {status_icon} {status_text}")
        if config.default_model:
            console.print(f"  Default: [green]{config.default_model}[/green]")
        console.print()

        # Models table
        table = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
        table.add_column("Model", style="cyan")
        table.add_column("Description")
        table.add_column("Status", style="dim")

        for model_id, model_info in config.models.items():
            if model_info.status == ModelStatus.DEPRECATED:
                continue  # Skip deprecated models

            status_str = model_info.status.value
            desc = model_info.description or ""
            if model_info.resolves_to:
                desc = (
                    f"{desc} → {model_info.resolves_to}" if desc else f"→ {model_info.resolves_to}"
                )

            table.add_row(model_id, desc, status_str)

        console.print(table)
        console.print()

    # Usage examples section
    console.print("[bold]Usage Examples[/bold]\n")
    console.print("  [dim]# Single provider run[/dim]")
    console.print('  obra run "Add user authentication" --model opus')
    console.print('  obra run "Fix tests" --impl-provider openai --model gpt-5.2')
    console.print()
    console.print("  [dim]# Parallel execution with multiple providers[/dim]")
    console.print('  obra run "Implement feature X" --model sonnet &')
    console.print('  obra run "Review code quality" --impl-provider openai &')
    console.print("  wait  # Wait for all jobs to complete")
    console.print()


# =============================================================================
# Main Workflow Commands
# =============================================================================


@app.command(name="run", hidden=False)
@handle_encoding_errors
@require_terms_accepted
def run_objective(
    ctx: typer.Context,
    objective: str | None = typer.Argument(None, help="What you want Obra to accomplish"),
    working_dir: str | None = typer.Option(
        None,
        "--dir",
        "-d",
        help="Working directory (defaults to current directory). WSL UNC paths are auto-converted.",
    ),
    project_id: str | None = typer.Option(
        None,
        "--project",
        help="Project ID override (optional)",
    ),
    resume_session: str | None = typer.Option(
        None,
        "--resume",
        "-r",
        help="Resume an existing session by ID",
    ),
    continue_from: str | None = typer.Option(
        None,
        "--continue-from",
        "-c",
        help=(
            "Continue from a failed/escalated session (creates new session, skips completed tasks; "
            "uses original objective unless overridden)"
        ),
    ),
    plan_id: str | None = typer.Option(
        None,
        "--plan-id",
        help=(
            "Use an uploaded plan by ID (from 'obra plans upload'). "
            "Requires local YAML at docs/development/{PLAN_ID}_MACHINE_PLAN.json."
        ),
    ),
    plan_file: Path | None = typer.Option(
        None,
        "--plan-file",
        help="Upload and use a plan file in one step",
    ),
    model: str | None = typer.Option(
        None,
        "--model",
        "-m",
        help="Implementation model (e.g., opus, gpt-5.2, gemini-2.5-flash)",
    ),
    fast_model: str | None = typer.Option(
        None,
        "--fast-model",
        help="Fast tier model override (used for extraction and quick validation)",
    ),
    high_model: str | None = typer.Option(
        None,
        "--high-model",
        help="High tier model override (used for complex reasoning)",
    ),
    impl_provider: str | None = typer.Option(
        None,
        "--impl-provider",
        "-p",
        help="Implementation provider (anthropic, openai, google). Requires provider CLI (claude/codex/gemini).",
    ),
    thinking_level: str | None = typer.Option(
        None,
        "--thinking-level",
        "-t",
        help="Thinking/reasoning level (off, low, medium, high, maximum)",
    ),
    no_extended_thinking: bool = typer.Option(
        False,
        "--no-extended-thinking",
        help="Disable extended thinking for derivation (equivalent to --thinking-level off)",
    ),
    verbose: int = typer.Option(
        0,
        "--verbose",
        "-v",
        count=True,
        max=3,
        help="Verbosity level (0-3, use -v/-vv/-vvv)",
    ),
    progress_json: bool = typer.Option(
        False,
        "--progress-json",
        help="Emit progress events as JSON lines to stdout",
    ),
    stream: bool = typer.Option(
        False,
        "--stream",
        "-s",
        help="Enable real-time LLM output streaming",
    ),
    plan_only: bool = typer.Option(
        False,
        "--plan-only",
        help="Create plan without executing (client-side exit after planning)",
    ),
    permissive: bool = typer.Option(
        False,
        "--permissive",
        help="Bypass P1 planning blockers (proceed with warnings)",
    ),
    defaults_json: bool = typer.Option(
        False,
        "--defaults-json",
        help="Print proposed defaults as JSON and exit when refinement is blocked",
    ),
    no_closeout: bool = typer.Option(
        False,
        "--no-closeout",
        help="Skip close-out story injection",
    ),
    skip_intent: bool = typer.Option(
        False,
        "--skip-intent",
        help="Skip intent generation for vague objectives (S2.T3)",
    ),
    review_intent: bool = typer.Option(
        False,
        "--review-intent",
        help="Display generated intent and prompt for approval before derive (S2.T4)",
    ),
    enrich: bool = typer.Option(
        False,
        "--enrich",
        help="Force intent enrichment (requires planning.enrichment.enabled)",
    ),
    no_enrich: bool = typer.Option(
        False,
        "--no-enrich",
        help="Skip intent enrichment even when enabled",
    ),
    isolated: bool | None = typer.Option(
        None,
        "--isolated",
        help="Run agent in isolated environment (prevents reading host CLI config)",
    ),
    no_isolated: bool | None = typer.Option(
        None,
        "--no-isolated",
        help="Disable isolation (use host CLI config, even in CI)",
    ),
    full_review: bool = typer.Option(
        False,
        "--full-review",
        help="Run all review agents (overrides auto-detection)",
    ),
    skip_review: bool = typer.Option(
        False,
        "--skip-review",
        help="Skip the review phase entirely",
    ),
    review_agents: str | None = typer.Option(
        None,
        "--review-agents",
        help=f"Comma-separated review agents to run ({', '.join(ALLOWED_AGENTS)})",
    ),
    with_security: bool = typer.Option(
        False,
        "--with-security",
        help="Add the security review agent",
    ),
    with_testing: bool = typer.Option(
        False,
        "--with-testing",
        help="Add the testing review agent",
    ),
    with_docs: bool = typer.Option(
        False,
        "--with-docs",
        help="Add the docs review agent",
    ),
    with_code_quality: bool = typer.Option(
        False,
        "--with-code-quality",
        help="Add the code_quality review agent",
    ),
    no_security: bool = typer.Option(
        False,
        "--no-security",
        help="Remove the security review agent",
    ),
    no_testing: bool = typer.Option(
        False,
        "--no-testing",
        help="Remove the testing review agent",
    ),
    no_docs: bool = typer.Option(
        False,
        "--no-docs",
        help="Remove the docs review agent",
    ),
    no_code_quality: bool = typer.Option(
        False,
        "--no-code-quality",
        help="Remove the code_quality review agent",
    ),
    review_format: str | None = typer.Option(
        None,
        "--review-format",
        help="Review output format (text or json)",
        show_choices=True,
    ),
    review_quiet: bool = typer.Option(
        False,
        "--review-quiet",
        help="Suppress review output",
    ),
    review_summary_only: bool = typer.Option(
        False,
        "--review-summary-only",
        help="Show only review summary counts",
    ),
    fail_on_p1: bool = typer.Option(
        False,
        "--fail-on-p1",
        help="Exit with status 1 when P1 findings are present",
    ),
    fail_on_p2: bool = typer.Option(
        False,
        "--fail-on-p2",
        help="Exit with status 1 when P1 or P2 findings are present",
    ),
    review_timeout: int | None = typer.Option(
        None,
        "--review-timeout",
        min=1,
        help="Per-agent review timeout in seconds",
    ),
    auto_report: bool = typer.Option(
        False,
        "--auto-report",
        help="Automatically submit bug reports on failure (no prompt, for CI/CD)",
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Auto-approve all confirmation prompts",
    ),
    mock_credentials: bool = typer.Option(
        False,
        "--mock-credentials",
        help="Automatically mock all required credentials",
    ),
    skip_git_check: bool = typer.Option(
        False,
        "--skip-git-check",
        help="Skip git repository validation (GIT-HARD-001)",
    ),
    auto_init_git: bool = typer.Option(
        False,
        "--auto-init-git",
        help="Auto-initialize git repository if not present (GIT-HARD-001)",
    ),
    skip_quality_check: bool = typer.Option(
        False,
        "--skip-quality-check",
        help="Skip UserPlan quality assessment (for debugging, testing, or high-confidence plans)",
    ),
    skip_complexity_check: bool = typer.Option(
        False,
        "--skip-complexity-check",
        help="Skip complexity estimation for derived plan items (for faster derivation)",
    ),
    parallel: bool = typer.Option(
        False,
        "--parallel",
        help="Enable parallel execution of independent plan items (uses parallel_group assignments)",
    ),
    skip_tier_check: bool = typer.Option(
        False,
        "--skip-tier-check",
        help="Skip server tier mismatch validation (proceed despite client/server tier disagreement)",
    ),
    skip_explore: bool = typer.Option(
        False,
        "--skip-explore",
        help="Skip automatic codebase exploration before derivation (FEAT-AUTO-EXPLORE-001)",
    ),
    force_explore: bool = typer.Option(
        False,
        "--force-explore",
        help="Force codebase exploration even for simple objectives (FEAT-AUTO-EXPLORE-001)",
    ),
    plan_mode: str | None = typer.Option(
        None,
        "--plan-mode",
        help="Planning mode: auto (default), quick, standard, or thorough",
    ),
    local: bool = typer.Option(
        False,
        "--local",
        help="Use local Firebase emulator instead of production (requires emulators running)",
    ),
) -> None:
    """Run AI-orchestrated workflow for an objective.

    Examples:
        obra run "Add user authentication"
        obra run "Fix the failing tests" --dir /my/project
        obra run "Refactor payment module" --stream -vv
        obra run "Implement feature X" --model opus
        obra run "Improve tests" --impl-provider openai --model gpt-5.2
        obra run "Complex refactor" --thinking-level high
        obra run --plan-only "Design API endpoints"
        obra run "Test feature" --isolated  # Isolated session
        obra run --continue-from abc123  # Continue from failed session
        obra run "Quick fix" --no-extended-thinking  # Disable extended thinking
        obra run "Multi-task feature" --parallel  # Enable parallel execution
        obra run "Test feature" --local  # Use local Firebase emulator

    Environment Variables:
        OBRA_MODEL          Default model (e.g., opus, gpt-5.2, gemini-2.5-flash)
        OBRA_FAST_MODEL     Fast tier override (e.g., haiku, gpt-5.1-codex-mini)
        OBRA_HIGH_MODEL     High tier override (e.g., opus, gpt-5.2)
        OBRA_PROVIDER       Default provider (anthropic, openai, google)
        OBRA_THINKING_LEVEL Default thinking level (off, low, medium, high, maximum)
        OBRA_ISOLATED       Enable/disable isolation (true/false)

    Precedence: CLI flags > environment variables > config file
    """
    verbose = _resolve_command_verbosity(ctx, verbose)

    # Display startup banner
    print_banner()
    console.print("📺 Logs: run 'obra logs viewer' for live session logs", style="cyan")
    console.print()

    # Handle --local flag: use local Firebase emulator
    if local:
        from obra.config import enable_local_mode

        enable_local_mode()
        print_info("Local mode: Using Firebase emulator at localhost:5001")

    # Handle --no-extended-thinking flag: override thinking_level to "off"
    effective_thinking_level = thinking_level
    if no_extended_thinking:
        if thinking_level is not None and thinking_level != "off":
            print_warning(f"--no-extended-thinking overrides --thinking-level {thinking_level}")
        effective_thinking_level = "off"

    # FEAT-COMPLEXITY-ROUTING-001 S4.T0: Validate plan_mode
    valid_plan_modes = ["auto", "quick", "standard", "thorough"]
    if plan_mode is not None and plan_mode.lower() not in valid_plan_modes:
        print_error(
            f"Invalid --plan-mode '{plan_mode}'. Must be one of: {', '.join(valid_plan_modes)}"
        )
        raise typer.Exit(1)
    effective_plan_mode = plan_mode.lower() if plan_mode else None

    # Normalize WSL UNC paths before creating Path object
    normalized_working_dir: Path | None = None
    if working_dir is not None:
        normalized_path = _normalize_wsl_unc_path(working_dir)
        normalized_working_dir = Path(normalized_path).expanduser().resolve(strict=False)

    _run_derive(
        objective=objective,
        working_dir=normalized_working_dir,
        project_id=project_id,
        resume_session=resume_session,
        continue_from=continue_from,
        plan_id=plan_id,
        plan_file=plan_file,
        model=model,
        fast_model=fast_model,
        high_model=high_model,
        impl_provider=impl_provider,
        thinking_level=effective_thinking_level,
        verbose=verbose,
        stream=stream,
        plan_only=plan_only,
        permissive=permissive,
        defaults_json=defaults_json,
        no_closeout=no_closeout,
        skip_intent=skip_intent,
        review_intent=review_intent,
        enrich=enrich,
        no_enrich=no_enrich,
        isolated=isolated,
        no_isolated=no_isolated,
        full_review=full_review,
        skip_review=skip_review,
        review_agents=review_agents,
        with_security=with_security,
        with_testing=with_testing,
        with_docs=with_docs,
        with_code_quality=with_code_quality,
        no_security=no_security,
        no_testing=no_testing,
        no_docs=no_docs,
        no_code_quality=no_code_quality,
        review_format=review_format,
        review_quiet=review_quiet,
        review_summary_only=review_summary_only,
        fail_on_p1=fail_on_p1,
        fail_on_p2=fail_on_p2,
        review_timeout=review_timeout,
        auto_report=auto_report,
        yes=yes,
        mock_credentials=mock_credentials,
        skip_git_check=skip_git_check,
        auto_init_git=auto_init_git,
        skip_quality_check=skip_quality_check,
        skip_complexity_check=skip_complexity_check,
        parallel=parallel,
        skip_tier_check=skip_tier_check,
        skip_explore=skip_explore,
        force_explore=force_explore,
        plan_mode=effective_plan_mode,
    )


def _normalize_wsl_unc_path(path_str: str) -> str:
    """Convert Windows UNC path to Linux path if it's a WSL UNC path.

    Handles paths like:
        \\wsl.localhost\\Ubuntu\\home\\user -> /home/user
        \\wsl$\\Ubuntu\\home\\user -> /home/user

    Note: When users type \\\\wsl.localhost\\... in a shell, the shell interprets
    the backslash escapes, so Python receives \\wsl.localhost\\... (single backslashes).

    This is needed because when users copy paths from Windows File Explorer
    for WSL directories, they get UNC paths that Python's Path() treats as
    relative paths on Linux, causing path concatenation bugs.

    Args:
        path_str: Path string that might be a Windows UNC path

    Returns:
        Normalized Linux path string, or original string if not a WSL UNC path
    """
    import re

    # Match \wsl.localhost\<distro>\... or \wsl$\<distro>\...
    # Shell interprets \\wsl as \wsl, so we look for 1-2 backslashes at start
    # Pattern: \{1,2}wsl(.localhost|$)\<distro>\<path>
    match = re.match(r"^\\{1,2}wsl(?:\.localhost|\$)\\([^\\]+)(.*)$", path_str, re.IGNORECASE)
    if match:
        # Group 1 is distro name (e.g., "Ubuntu"), group 2 is the path after distro
        linux_path = match.group(2).replace("\\", "/")
        return linux_path if linux_path else "/"

    return path_str


def _extract_working_dir(value: str | None) -> Path | None:
    """Convert working directory value to Path if valid."""
    if not value:
        return None
    try:
        # Normalize WSL UNC paths before creating Path object
        normalized = _normalize_wsl_unc_path(value)
        candidate = Path(normalized).expanduser()
    except (TypeError, ValueError):
        return None
    if candidate.is_absolute():
        return candidate.resolve(strict=False)
    return candidate.resolve(strict=False)


def _normalize_path_for_compare(path: Path) -> str:
    """Normalize a path string for comparison (case-insensitive where applicable)."""
    return os.path.normcase(os.path.normpath(str(path)))


def _paths_equivalent(left: Path, right: Path) -> bool:
    """Check if two paths are equivalent without requiring they exist."""
    return _normalize_path_for_compare(left) == _normalize_path_for_compare(right)


@dataclass(frozen=True)
class WorkingDirSelection:
    """Resolved working directory selection and metadata."""

    path: Path
    source: str
    stored_path: Path | None
    stored_source: str | None
    conflict: bool
    prompt_used: bool
    project_id: str | None
    stored_missing: bool


def _resolve_project_working_dir(client, project_id: str) -> Path | None:
    """Resolve project working directory from project metadata."""
    try:
        project = client.get_project(project_id)
    except Exception as exc:
        logger.warning("Failed to resolve project %s: %s", project_id, exc)
        return None

    working_dir = project.get("working_directory") or project.get("working_dir")
    return _extract_working_dir(working_dir)


def _resolve_session_working_dir(client, session_id: str) -> Path | None:
    """Resolve working directory from session or project metadata."""
    try:
        session = client.get_session(session_id)
    except Exception as exc:
        logger.warning("Failed to resolve session %s: %s", session_id, exc)
        return None

    working_dir = session.get("working_directory") or session.get("working_dir")
    resolved = _extract_working_dir(working_dir)
    if resolved:
        return resolved

    project_id = session.get("project_id")
    if project_id:
        return _resolve_project_working_dir(client, str(project_id))

    return None


def _resolve_session_working_dir_data(
    client,
    session_id: str,
) -> tuple[Path | None, str | None]:
    """Resolve session working directory and project_id (if present)."""
    try:
        session = client.get_session(session_id)
    except Exception as exc:
        logger.warning("Failed to resolve session %s: %s", session_id, exc)
        return None, None

    working_dir = session.get("working_directory") or session.get("working_dir")
    resolved = _extract_working_dir(working_dir)
    project_id = session.get("project_id")
    return resolved, str(project_id) if project_id else None


def _prompt_working_dir_choice(stored_path: Path, cwd: Path) -> tuple[Path, str]:
    """Prompt the user to select between stored working_dir and current directory."""
    console.print()
    console.print("Working directory mismatch detected.")
    console.print(f"  1) Use stored project dir (default): {stored_path}")
    console.print(f"  2) Use current shell dir:          {cwd}")
    console.print()

    while True:
        choice = typer.prompt("Select working directory [1/2]", default="1")
        choice = str(choice).strip()
        if choice == "1":
            return stored_path, "stored"
        if choice == "2":
            return cwd, "cwd"
        console.print("Invalid choice. Enter 1 or 2.")


def _confirm_use_cwd_for_project(cwd: Path, project_id: str | None) -> None:
    """Confirm using cwd when no project working directory is configured."""
    console.print()
    if project_id:
        console.print(f"No working directory is configured for project {project_id}.")
    else:
        console.print("No working directory is configured for the selected project.")
    console.print(f"Current shell directory: {cwd}")
    console.print()
    proceed = typer.confirm(get_message("prompt.confirm.directory_use"), default=False)
    if not proceed:
        console.print("Aborted. Use --dir or set the project working directory.")
        raise typer.Exit(1)


def _resolve_working_dir_selection(
    client,
    working_dir: Path | None,
    project_id: str | None,
    resume_session: str | None,
    continue_from: str | None,
) -> WorkingDirSelection:
    """Resolve working directory with precedence and conflict handling."""
    if working_dir is not None:
        # Check whether the project already has a stored working directory.
        # Only set stored_missing=True when the project genuinely has none,
        # so that update_project() doesn't overwrite an existing path.
        already_stored = False
        if project_id:
            existing = _resolve_project_working_dir(client, project_id)
            already_stored = existing is not None
        return WorkingDirSelection(
            path=working_dir,
            source="cli",
            stored_path=None,
            stored_source=None,
            conflict=False,
            prompt_used=False,
            project_id=project_id,
            stored_missing=not already_stored,
        )

    cwd = Path.cwd().resolve(strict=False)
    stored_path: Path | None = None
    stored_source: str | None = None
    resolved_project_id = project_id

    session_id = resume_session or continue_from
    if session_id:
        session_working_dir, session_project_id = _resolve_session_working_dir_data(
            client,
            session_id,
        )
        if session_project_id and not resolved_project_id:
            resolved_project_id = session_project_id
        if session_working_dir:
            stored_path = session_working_dir
            stored_source = "session"

    if stored_path is None and resolved_project_id:
        project_working_dir = _resolve_project_working_dir(client, resolved_project_id)
        if project_working_dir:
            stored_path = project_working_dir
            stored_source = "project"

    stored_missing = stored_path is None
    conflict = False
    prompt_used = False
    selected_path = cwd
    source = "cwd"

    if stored_missing and sys.stdin.isatty():
        _confirm_use_cwd_for_project(cwd, resolved_project_id)
        prompt_used = True
    elif stored_missing and not sys.stdin.isatty():
        # Non-interactive mode with no stored working directory - fail fast
        # to prevent accidental execution in wrong directory
        print_error(
            f"No stored working directory for project. In non-interactive mode, "
            f"you must specify --dir explicitly.\n"
            f"Current directory: {cwd}\n"
            f"Use: obra run --dir {cwd} <objective>"
        )
        raise typer.Exit(code=1)

    if stored_path is not None:
        conflict = not _paths_equivalent(stored_path, cwd)
        if conflict and sys.stdin.isatty():
            selected_path, source = _prompt_working_dir_choice(stored_path, cwd)
            prompt_used = True
        else:
            selected_path = stored_path
            source = "stored"

    return WorkingDirSelection(
        path=selected_path,
        source=source,
        stored_path=stored_path,
        stored_source=stored_source,
        conflict=conflict,
        prompt_used=prompt_used,
        project_id=resolved_project_id,
        stored_missing=stored_missing,
    )


def _emit_progress_json(action: str, payload: dict) -> None:
    """Emit a JSON progress event to stdout for machine-readable streaming."""
    try:
        event = {
            "event_type": action,
            "payload": payload,
            "timestamp": datetime.now(UTC).isoformat(),
        }
        print(json.dumps(event, default=str))
    except Exception:
        return


def _route_progress_event(
    progress_emitter: ProgressEmitter,
    console: "Console",
    verbose: int,
    action: str,
    payload: dict,
    *,
    progress_json: bool = False,
) -> None:
    """Route progress events to ProgressEmitter with defensive payload parsing."""
    if progress_json and action != "llm_streaming":
        _emit_progress_json(action, payload)
    if action == "phase_started":
        phase = payload.get("phase", "UNKNOWN")
        progress_emitter.phase_started(phase, payload.get("context"))
        return
    if action == "phase_completed":
        phase = payload.get("phase", "UNKNOWN")
        duration_ms = payload.get("duration_ms", 0)
        result = payload.get("result")
        progress_emitter.phase_completed(phase, result, duration_ms)
        if phase == "DERIVATION" and isinstance(result, dict):
            item_count = result.get("item_count")
            pv = result.get("plan_version")
            if isinstance(item_count, int) and item_count > 0:
                progress_emitter.set_total_tasks(
                    item_count,
                    plan_version=pv if isinstance(pv, int) else None,
                )
            items = result.get("items")
            if isinstance(items, list):
                progress_emitter.set_plan_items(items)
        return
    if action == "plan_total":
        total = payload.get("total") or payload.get("total_tasks")
        plan_version = payload.get("plan_version")
        if isinstance(total, int):
            progress_emitter.set_total_tasks(
                total,
                plan_version=plan_version if isinstance(plan_version, int) else None,
            )
        return
    if action == "llm_started":
        purpose = payload.get("purpose", "LLM invocation")
        progress_emitter.llm_started(purpose)
        return
    if action == "llm_streaming":
        chunk = payload.get("chunk", "")
        progress_emitter.llm_streaming(chunk)
        return
    if action == "llm_completed":
        summary = payload.get("summary", "")
        tokens = payload.get("tokens", 0)
        progress_emitter.llm_completed(summary, tokens)
        return
    if action == "stage_started":
        stage = payload.get("stage", "unknown")
        context = payload.get("context")
        progress_emitter.stage_started(stage, context)
        return
    if action == "planning_started":
        objective = payload.get("objective", "")
        progress_emitter.planning_started(str(objective))
        return
    if action == "planning_stage_started":
        stage = payload.get("stage", "unknown")
        user_label = payload.get("user_label", "")
        progress_emitter.planning_stage_started(str(stage), str(user_label))
        return
    if action == "planning_stage_completed":
        stage = payload.get("stage", "unknown")
        user_label = payload.get("user_label", "")
        duration_s = payload.get("duration_s", 0.0)
        summary = payload.get("summary")
        progress_emitter.planning_stage_completed(
            str(stage),
            str(user_label),
            float(duration_s) if isinstance(duration_s, (int, float)) else 0.0,
            str(summary) if summary else None,
        )
        return
    if action == "stage_completed":
        stage = payload.get("stage", "unknown")
        duration_ms = payload.get("duration_ms", 0)
        result = payload.get("result")
        progress_emitter.stage_completed(stage, result, duration_ms)
        return
    if action == "stage_failed":
        stage = payload.get("stage", "unknown")
        error = payload.get("error", "unknown error")
        duration_ms = payload.get("duration_ms", 0)
        timeout_s = payload.get("timeout_s")
        progress_emitter.stage_failed(stage, str(error), duration_ms, timeout_s)
        return
    if action == "stage_heartbeat":
        stage = payload.get("stage", "unknown")
        elapsed_s = payload.get("elapsed_s", payload.get("elapsed", 0))
        progress_emitter.stage_heartbeat(stage, int(elapsed_s))
        return
    if action == "derivation_step_heartbeat":
        # Silently consumed — the stage-level heartbeat already covers this.
        return
    if action == "derivation_step_started":
        step = payload.get("step", 1)
        step_name = payload.get("step_name", "unknown")
        progress_emitter.derivation_step_started(step, step_name)
        return
    if action == "epic_derivation_started":
        epic_index = payload.get("epic_index", 1)
        epic_count = payload.get("epic_count", 1)
        epic_id = payload.get("epic_id", "E1")
        epic_title = payload.get("epic_title", "Untitled")
        progress_emitter.epic_derivation_started(
            int(epic_index),
            int(epic_count),
            str(epic_id),
            str(epic_title),
        )
        return
    if action == "epic_derivation_completed":
        epic_index = payload.get("epic_index", 1)
        epic_count = payload.get("epic_count", 1)
        epic_id = payload.get("epic_id", "E1")
        epic_title = payload.get("epic_title")
        stories_derived = payload.get("stories_derived", 0)
        tasks_derived = payload.get("tasks_derived", 0)
        progress_emitter.epic_derivation_completed(
            int(epic_index),
            int(epic_count),
            str(epic_id),
            str(epic_title) if epic_title is not None else None,
            int(stories_derived),
            int(tasks_derived),
        )
        return
    if action == "epic_derivation_heartbeat":
        epic_index = payload.get("epic_index", 1)
        epic_count = payload.get("epic_count", 1)
        epic_title = payload.get("epic_title", "Untitled")
        items_so_far = payload.get("items_so_far", 0)
        elapsed_s = payload.get("elapsed_s", payload.get("elapsed", 0))
        progress_emitter.epic_derivation_heartbeat(
            int(epic_index),
            int(epic_count),
            str(epic_title),
            int(items_so_far),
            int(elapsed_s) if isinstance(elapsed_s, (int, float)) else 0,
        )
        return
    if action == "epic_serialization_batch_started":
        epic_count = payload.get("epic_count", 1)
        max_concurrent = payload.get("max_concurrent", 4)
        progress_emitter.epic_serialization_batch_started(
            int(epic_count),
            int(max_concurrent),
        )
        return
    if action == "epic_serialization_completed":
        epic_index = payload.get("epic_index", 1)
        epic_count = payload.get("epic_count", 1)
        epic_id = payload.get("epic_id", "E1")
        epic_title = payload.get("epic_title", "Untitled")
        items_serialized = payload.get("items_serialized", 0)
        progress_emitter.epic_serialization_completed(
            int(epic_index),
            int(epic_count),
            str(epic_id),
            str(epic_title),
            int(items_serialized),
        )
        return
    if action == "derivation_step_completed":
        step = payload.get("step", 1)
        step_name = payload.get("step_name", "unknown")
        duration_ms = payload.get("duration_ms", 0)
        items_produced = payload.get("items_produced", 0)
        prose = payload.get("prose")
        raw_json = payload.get("raw_json")
        progress_emitter.derivation_step_completed(
            step, step_name, duration_ms, items_produced, prose, raw_json
        )
        return
    if action == "derivation_step_failed":
        step = payload.get("step", 1)
        step_name = payload.get("step_name", "unknown")
        error = payload.get("error", "unknown error")
        duration_ms = payload.get("duration_ms", 0)
        progress_emitter.derivation_step_failed(step, step_name, error, duration_ms)
        return
    if action == "derivation_stall_warning":
        step = payload.get("step", 1)
        step_name = payload.get("step_name", "unknown")
        no_output_seconds = payload.get("no_output_seconds", 0)
        progress_emitter.derivation_stall_warning(step, step_name, no_output_seconds)
        return
    if action == "derivation_streaming_heartbeat":
        step = payload.get("step", 1)
        elapsed_seconds = payload.get("elapsed_seconds", 0)
        progress_emitter.derivation_streaming_heartbeat(step, elapsed_seconds)
        return
    if action == "derivation_validation_started":
        pass_num = payload.get("pass", 1)
        max_passes = payload.get("max_passes", 1)
        progress_emitter.derivation_validation_started(pass_num, max_passes)
        return
    if action == "derivation_validation_completed":
        pass_num = payload.get("pass", 1)
        violations = payload.get("violations", 0)
        passed = payload.get("passed", False)
        progress_emitter.derivation_validation_completed(pass_num, violations, passed)
        return
    if action == "stage_summary":
        return
    if action == "item_started":
        item = payload.get("item", {})
        progress_emitter.item_started(item)
        return
    if action == "item_completed":
        item = payload.get("item", {})
        result = payload.get("result")
        progress_emitter.item_completed(item, result)
        return
    if action == "item_skipped":
        item = payload.get("item", {})
        progress_emitter.item_skipped(item)
        return
    if action in ("item_heartbeat", "heartbeat"):
        item_id = payload.get("item_id") or payload.get("item", {}).get("id")
        if not item_id:
            return
        elapsed_s = payload.get("elapsed_s", payload.get("elapsed", 0))
        file_count = payload.get("file_count", payload.get("files_changed", 0))
        liveness = payload.get("liveness_indicators") or payload.get("liveness")
        progress_emitter.item_heartbeat(
            str(item_id),
            int(elapsed_s) if isinstance(elapsed_s, (int, float)) else 0,
            int(file_count) if isinstance(file_count, (int, float)) else 0,
            liveness if isinstance(liveness, dict) else None,
        )
        return
    if action == "review":
        item_id = payload.get("item_id")
        review_cycle_id = payload.get("review_cycle_id")
        progress_emitter.set_review_context(
            item_id=str(item_id) if item_id else None,
            review_cycle_id=str(review_cycle_id) if review_cycle_id else None,
        )
        return
    if action == "file_event":
        filepath = payload.get("filepath") or payload.get("path")
        event_type = payload.get("event_type")
        if filepath and event_type:
            progress_emitter.file_event(filepath, event_type, payload.get("line_count"))
        return
    if action == "review_loop_started":
        attempt = payload.get("attempt", 1)
        max_attempts = payload.get("max_attempts", 0)
        agent_count = payload.get("agent_count")
        parallel = payload.get("parallel")
        item_id = payload.get("item_id")
        review_cycle_id = payload.get("review_cycle_id")
        progress_emitter.review_loop_started(
            int(attempt),
            int(max_attempts),
            agent_count=int(agent_count) if isinstance(agent_count, (int, float)) else None,
            parallel=bool(parallel) if isinstance(parallel, bool) else None,
            item_id=str(item_id) if item_id else None,
            review_cycle_id=str(review_cycle_id) if review_cycle_id else None,
        )
        return
    if action == "review_agent_started":
        agent_name = payload.get("agent_name") or payload.get("agent")
        if agent_name:
            progress_emitter.review_agent_started(str(agent_name))
        return
    if action == "review_agent_completed":
        agent_name = payload.get("agent_name") or payload.get("agent")
        if not agent_name:
            return
        status = str(payload.get("status", "")).lower()
        passed = payload.get("passed")
        if passed is None:
            passed = status in ("complete", "pass", "passed")
        details = payload.get("details") or payload.get("error_message")
        item_id = payload.get("item_id")
        review_cycle_id = payload.get("review_cycle_id")
        progress_emitter.review_agent_completed(
            str(agent_name),
            bool(passed),
            details,
            status=status or None,
            item_id=str(item_id) if item_id else None,
            review_cycle_id=str(review_cycle_id) if review_cycle_id else None,
        )
        return
    if action == "review_no_fixes":
        item_id = payload.get("item_id")
        progress_emitter.review_no_fixes(str(item_id) if item_id else None)
        return
    if action == "fix_started":
        issue_count = payload.get("issue_count")
        if issue_count is not None:
            progress_emitter.fix_started(int(issue_count))
        return
    if action == "fix_completed":
        fixed = payload.get("fixed", 0)
        failed = payload.get("failed", 0)
        skipped = payload.get("skipped", 0)
        progress_emitter.fix_completed(int(fixed), int(failed), int(skipped))
        return
    if action == "scorecard_available":
        component_scores = payload.get("component_scores_normalized")
        issue_counts = payload.get("issue_counts")
        legacy_scores = payload.get("scores") or {}
        score_units = str(payload.get("score_units", "")).strip().lower()
        total = payload.get("total")
        threshold = payload.get("threshold")
        item_id = payload.get("item_id")  # Include item context for display
        review_cycle_id = payload.get("review_cycle_id")
        if total is None and "compiled_score" in payload:
            total = round(float(payload.get("compiled_score", 0)) * 100)
        if threshold is None and "threshold_ratio" in payload:
            threshold = round(float(payload.get("threshold_ratio", 0)) * 100)

        normalized_scores: dict[str, int] = {}
        if isinstance(component_scores, dict):
            for name, value in component_scores.items():
                try:
                    normalized_scores[str(name)] = round(float(value))
                except (TypeError, ValueError):
                    continue

        parsed_issue_counts: dict[str, int] = {}
        if isinstance(issue_counts, dict):
            for name, value in issue_counts.items():
                try:
                    parsed_issue_counts[str(name)] = int(value)
                except (TypeError, ValueError):
                    continue

        if isinstance(legacy_scores, dict):
            if not normalized_scores and score_units in {"normalized_100", "percent_100"}:
                for name, value in legacy_scores.items():
                    try:
                        normalized_scores[str(name)] = round(float(value))
                    except (TypeError, ValueError):
                        continue
            elif not normalized_scores and score_units in {"ratio_0_1", "ratio"}:
                for name, value in legacy_scores.items():
                    try:
                        normalized_scores[str(name)] = round(float(value) * 100)
                    except (TypeError, ValueError):
                        continue
            elif not normalized_scores and not score_units:
                numeric_values: list[float] = []
                for value in legacy_scores.values():
                    try:
                        numeric_values.append(float(value))
                    except (TypeError, ValueError):
                        numeric_values = []
                        break
                if numeric_values and all(0.0 <= val <= 1.0 for val in numeric_values):
                    # Backward-compatible ratio payloads (legacy servers) without explicit units.
                    # Avoid misclassifying pure binary counters like 0/1 as percentages.
                    has_fractional_score = any(val not in (0.0, 1.0) for val in numeric_values)
                    if has_fractional_score:
                        for name, value in legacy_scores.items():
                            try:
                                normalized_scores[str(name)] = round(float(value) * 100)
                            except (TypeError, ValueError):
                                continue
            elif not parsed_issue_counts:
                for name, value in legacy_scores.items():
                    try:
                        parsed_issue_counts[str(name)] = int(value)
                    except (TypeError, ValueError):
                        continue

        if total is not None and threshold is not None:
            progress_emitter.scorecard_available(
                normalized_scores,
                int(total),
                int(threshold),
                item_id=str(item_id) if item_id else None,
                review_cycle_id=str(review_cycle_id) if review_cycle_id else None,
                issue_counts=parsed_issue_counts or None,
            )
        return
    if action == "scorecard_warning":
        message = payload.get("message")
        if message:
            progress_emitter.scorecard_warning(str(message))
        return
    # FIX-COMPLETION-001: Handle session_completed for celebration message
    # FIX-ESCALATION-COMPLETION-001: Skip celebration for escalated sessions
    if action == "session_completed":
        items_completed = payload.get("items_completed", 0)
        quality_score = payload.get("quality_score", 0.0)
        session_summary = payload.get("session_summary", "")
        was_escalated = payload.get("was_escalated", False)
        progress_emitter.session_completed(
            int(items_completed) if isinstance(items_completed, (int, float)) else 0,
            float(quality_score) if isinstance(quality_score, (int, float)) else 0.0,
            str(session_summary) if session_summary else "",
            was_escalated=bool(was_escalated),
        )
        return
    if action == "plan_snapshot":
        plan_items = payload.get("plan_items")
        if isinstance(plan_items, list):
            source = payload.get("source")
            source_value = str(source) if source is not None else None
            progress_emitter.update_plan_snapshot(
                plan_items,
                source=source_value,
                session_id=payload.get("session_id"),
                mode=payload.get("mode"),
            )
        return
    if action == "revision_batch_progress":
        batch_idx = payload.get("batch_index", 0)
        total = payload.get("total_batches", 0)
        items = payload.get("items_revised", 0)
        from obra.display import print_info

        print_info(f"Revision batch {batch_idx}/{total}: {items} items processed")
        return
    if action == "execute":
        plan_items = payload.get("plan_items")
        if isinstance(plan_items, list):
            progress_emitter.update_plan_snapshot(
                plan_items,
                source="execute",
                session_id=payload.get("session_id"),
                mode="tracker_sync",
            )
        return
    if action == "story0_started":
        progress_emitter.story0_started()
        return
    if action == "story0_prerequisite_status":
        category = payload.get("category", "")
        name = payload.get("name", "")
        status = payload.get("status", "")
        reason = payload.get("reason")
        progress_emitter.story0_prerequisite_status(
            str(category),
            str(name),
            str(status),
            str(reason) if reason else None,
        )
        return
    if action == "story0_message":
        message = payload.get("message", "")
        if message:
            progress_emitter.story0_message(str(message))
        return
    if action == "code_verify_started":
        item_id = payload.get("item_id")
        progress_emitter.code_verify_started(
            str(item_id) if item_id else None,
        )
        return
    if action == "code_verify_completed":
        item_id = payload.get("item_id")
        status = payload.get("status", "inconclusive")
        tools_used = payload.get("tools_used", [])
        if not isinstance(tools_used, list):
            tools_used = []
        pass_count = payload.get("pass_count", 0)
        fail_count = payload.get("fail_count", 0)
        inconclusive_count = payload.get("inconclusive_count", 0)
        progress_emitter.code_verify_completed(
            status=str(status),
            tools_used=[str(tool) for tool in tools_used if str(tool).strip()],
            pass_count=int(pass_count) if isinstance(pass_count, (int, float)) else 0,
            fail_count=int(fail_count) if isinstance(fail_count, (int, float)) else 0,
            inconclusive_count=int(inconclusive_count)
            if isinstance(inconclusive_count, (int, float))
            else 0,
            item_id=str(item_id) if item_id else None,
        )
        return
    if action == "verification_preflight_started":
        message = payload.get("message") or "Verification tools missing → running preflight"
        progress_emitter.verification_preflight_started(str(message))
        return
    if action == "verification_preflight_installing":
        message = payload.get("message") or "Installing verification tools"
        progress_emitter.verification_preflight_installing(str(message))
        return
    if action == "verification_preflight_completed":
        message = payload.get("message") or "Verification preflight complete"
        progress_emitter.verification_preflight_completed(str(message))
        return
    if action == "story0_completed":
        blocking_failures = payload.get("blocking_failures", 0)
        non_blocking_warnings = payload.get("non_blocking_warnings", 0)
        progress_emitter.story0_completed(int(blocking_failures), int(non_blocking_warnings))
        return
    if action == "story0_blocked":
        failures_summary = payload.get("failures_summary", "")
        if failures_summary:
            progress_emitter.story0_blocked(str(failures_summary))
        return
    if action == "debug_tokens":
        total = payload.get("total", 0)
        input_tokens = payload.get("input", 0)
        output_tokens = payload.get("output", 0)
        source = payload.get("source")
        progress_emitter.debug_tokens(
            int(total),
            int(input_tokens),
            int(output_tokens),
            str(source) if source else None,
        )
        return
    if action == "debug_quality":
        message = payload.get("message", "")
        if message:
            progress_emitter.debug_quality(str(message))
        return
    if action == "story_review_started":
        story_id = payload.get("story_id", "")
        story_title = payload.get("story_title", "")
        story_index = payload.get("story_index", 0)
        total_stories = payload.get("total_stories", 0)
        task_count = payload.get("task_count", 0)
        progress_emitter.story_review_started(
            story_id, story_title, story_index, total_stories, task_count
        )
        return
    if action == "story_review_batch_started":
        story_count = payload.get("story_count", 0)
        max_concurrent = payload.get("max_concurrent", 4)
        progress_emitter.story_review_batch_started(int(story_count), int(max_concurrent))
        return
    if action == "story_review_completed":
        story_id = payload.get("story_id", "")
        story_title = payload.get("story_title", "")
        story_index = payload.get("story_index", 0)
        total_stories = payload.get("total_stories", 0)
        changes_required = payload.get("changes_required", False)
        issue_count = payload.get("issue_count", 0)
        issues = payload.get("issues", [])
        duration_s = payload.get("duration_s", 0.0)
        progress_emitter.story_review_completed(
            story_id,
            story_title,
            story_index,
            total_stories,
            changes_required,
            issue_count,
            duration_s,
        )
        # Show issues if any were found
        if issues:
            progress_emitter.review_issues_found(story_id, story_title, issues)
        return
    if action == "intent_alignment_started":
        epic_count = payload.get("epic_count", 0)
        story_count = payload.get("story_count", 0)
        progress_emitter.intent_alignment_started(epic_count, story_count)
        return
    if action == "intent_story_batch_started":
        story_count = payload.get("story_count", 0)
        max_concurrent = payload.get("max_concurrent", 4)
        progress_emitter.intent_story_batch_started(int(story_count), int(max_concurrent))
        return
    if action == "intent_story_assessed":
        story_id = payload.get("story_id", "")
        story_title = payload.get("story_title", "")
        story_index = payload.get("story_index", 0)
        total_stories = payload.get("total_stories", 0)
        status = payload.get("status", "ok")
        note = payload.get("note", "")
        progress_emitter.intent_story_assessed(
            story_id, story_title, story_index, total_stories, status, note
        )
        return
    if action == "intent_story_added":
        title = payload.get("title", "")
        parent_id = payload.get("parent_id")
        progress_emitter.intent_story_added(title, parent_id)
        return
    if action == "intent_gap_detection_started":
        story_count = payload.get("story_count", 0)
        progress_emitter.intent_gap_detection_started(story_count)
        return
    if action == "intent_gap_detection_completed":
        gaps_found = payload.get("gaps_found", False)
        missing_count = payload.get("missing_count", 0)
        stories_to_add = payload.get("stories_to_add", 0)
        duration_s = payload.get("duration_s", 0.0)
        progress_emitter.intent_gap_detection_completed(
            gaps_found, missing_count, stories_to_add, duration_s
        )
        return
    if action == "intent_alignment_completed":
        coverage_status = payload.get("coverage_status", "")
        changes_required = payload.get("changes_required", False)
        missing_count = payload.get("missing_count", 0)
        scope_creep_count = payload.get("scope_creep_count", 0)
        stories_added = payload.get("stories_added", 0)
        stories_removed = payload.get("stories_removed", 0)
        duration_s = payload.get("duration_s", 0.0)
        progress_emitter.intent_alignment_completed(
            coverage_status,
            changes_required,
            missing_count,
            scope_creep_count,
            stories_added,
            stories_removed,
            duration_s,
        )
        return
    if action == "intent_alignment_fixes_applied":
        stories_added = payload.get("stories_added", [])
        stories_removed = payload.get("stories_removed", [])
        progress_emitter.intent_alignment_fixes_applied(stories_added, stories_removed)
        return
    if action == "error":
        message = payload.get("message", "Unknown error")
        hint = payload.get("hint")
        phase = payload.get("phase")
        affected_items = payload.get("affected_items")
        stack_trace = payload.get("stack_trace")
        raw_response = payload.get("raw_response")
        progress_emitter.error(message, hint, phase, affected_items, stack_trace, raw_response)
        return
    if action in (
        "interactive_guard_triggered",
        "interactive_guard_rollback",
        "interactive_guard_retry",
    ):
        message = payload.get("message")
        if not message:
            message = "Interactive guard event recorded."
        progress_emitter.interactive_guard_notice(message)
        return
    if verbose > 0:
        console.print(f"[dim]{action}[/dim]")


def _should_isolate(
    isolated: bool | None = None,
    no_isolated: bool | None = None,
) -> bool:
    """Determine whether to run in isolated mode.

    Resolution precedence (highest to lowest):
    1. CLI flags: --isolated (True) or --no-isolated (False)
    2. Environment variable: OBRA_ISOLATED=true/false
    3. CI environment: CI=true enables isolation automatically
    4. Config file: ~/.obra/config-layers/01-user.yaml agent.isolated_mode
    5. Default: True (isolation enabled for reproducibility)

    Args:
        isolated: CLI --isolated flag value (True if flag present)
        no_isolated: CLI --no-isolated flag value (True if flag present)

    Returns:
        True if isolation should be enabled, False otherwise
    """
    # Priority 1: CLI flags (--isolated or --no-isolated)
    if isolated:
        return True
    if no_isolated:
        return False

    # Priority 2: Environment variable OBRA_ISOLATED
    env_isolated = os.environ.get("OBRA_ISOLATED", "").lower()
    if env_isolated in ("true", "1", "yes"):
        return True
    if env_isolated in ("false", "0", "no"):
        return False

    # Priority 3: CI environment auto-enable
    # Common CI environment variables: CI, GITHUB_ACTIONS, GITLAB_CI, CIRCLECI, etc.
    ci_env = os.environ.get("CI", "").lower()
    if ci_env in ("true", "1", "yes"):
        return True

    # Priority 4: Config file (agent.isolated_mode)
    from obra.config import get_isolated_mode

    config_isolated = get_isolated_mode()
    if config_isolated is True:
        return True
    if config_isolated is False:
        return False

    # Priority 5: Default (isolation enabled for reproducibility)
    return True


def _resolve_model(cli_model: str | None) -> str | None:
    """Resolve effective model from CLI flag or environment variable.

    Resolution precedence (highest to lowest):
    1. CLI flag: --model <value>
    2. Environment variable: OBRA_MODEL=<value>
    3. None (caller uses DEFAULT_MODEL)

    Args:
        cli_model: Value from --model CLI flag (None if not specified)

    Returns:
        Effective model string, or None to use default
    """
    # Priority 1: CLI flag
    if cli_model is not None:
        return cli_model

    # Priority 2: Environment variable OBRA_MODEL
    env_model = os.environ.get("OBRA_MODEL", "").strip()
    if env_model:
        return env_model

    # Priority 3: Return None (caller uses DEFAULT_MODEL)
    return None


def _resolve_tier_model(cli_model: str | None, tier: str) -> str | None:
    """Resolve effective tier override from CLI flag or environment variable."""
    if cli_model is not None:
        return cli_model

    env_value = os.environ.get(f"OBRA_{tier.upper()}_MODEL", "").strip()
    if env_value:
        return env_value

    return None


def _resolve_provider(cli_provider: str | None) -> str | None:
    """Resolve effective provider from CLI flag or environment variable.

    Resolution precedence (highest to lowest):
    1. CLI flag: --impl-provider <value>
    2. Environment variable: OBRA_PROVIDER=<value>
    3. None (caller uses DEFAULT_PROVIDER or auto-detection)

    Args:
        cli_provider: Value from --impl-provider CLI flag (None if not specified)

    Returns:
        Effective provider string, or None to use default/auto-detection
    """
    # Priority 1: CLI flag
    if cli_provider is not None:
        return cli_provider

    # Priority 2: Environment variable OBRA_PROVIDER
    env_provider = os.environ.get("OBRA_PROVIDER", "").strip()
    if env_provider:
        return env_provider

    # Priority 3: Return None (caller uses DEFAULT_PROVIDER or auto-detection)
    return None


def _resolve_thinking_level(cli_thinking: str | None) -> str | None:
    """Resolve effective thinking level from CLI flag or environment variable.

    Resolution precedence (highest to lowest):
    1. CLI flag: --thinking-level <value>
    2. Environment variable: OBRA_THINKING_LEVEL=<value>
    3. None (caller uses DEFAULT_THINKING_LEVEL)

    Args:
        cli_thinking: Value from --thinking-level CLI flag (None if not specified)

    Returns:
        Effective thinking level string, or None to use default
    """
    # Priority 1: CLI flag
    if cli_thinking is not None:
        return cli_thinking

    # Priority 2: Environment variable OBRA_THINKING_LEVEL
    env_thinking = os.environ.get("OBRA_THINKING_LEVEL", "").strip()
    if env_thinking:
        return env_thinking

    # Priority 3: Return None (caller uses DEFAULT_THINKING_LEVEL)
    return None


def _update_llm_config_with_notification(
    role: str,
    provider: str,
    auth_method: str,
    model: str = "default",
    thinking_level: str = "medium",
) -> None:
    """Update LLM config and display tier auto-update notification if provider changed.

    This helper demonstrates the proper pattern for calling set_llm_config() and
    displaying the tier auto-update notification (FEAT-LLM-TIERS-SPLIT-001).

    When a role's provider changes, tiers are automatically updated to match the new
    provider's model names. The notification should be displayed to inform the user.

    Args:
        role: "orchestrator" or "implementation"
        provider: LLM provider (anthropic, openai, google, ollama)
        auth_method: Auth method (oauth, api_key)
        model: Model to use (default recommended for oauth)
        thinking_level: Abstract thinking level (off, low, medium, high, maximum)

    Example:
        >>> _update_llm_config_with_notification("orchestrator", "openai", "oauth")
        # If provider changed, displays: "Updated orchestrator tiers to match OpenAI: ..."
    """
    from obra.config import set_llm_config

    notification = set_llm_config(role, provider, auth_method, model, thinking_level)
    if notification:
        console.print()
        console.print(f"[cyan]ℹ[/cyan]  {notification}")
        console.print()


def _parse_review_agents_csv(review_agents: str | None) -> list[str] | None:
    """Parse a comma-separated agent list from CLI input."""
    if review_agents is None:
        return None
    agents = [part.strip() for part in review_agents.split(",") if part.strip()]
    return agents or None


def _load_planning_config(project_path: Path | None) -> dict[str, Any]:
    """Load planning config from project config layer if present.

    Args:
        project_path: Base project path (repo root preferred)

    Returns:
        Dict with planning config values (empty if not set)
    """
    from obra.config.llm import get_project_planning_config

    return cast(dict[str, Any], get_project_planning_config(project_path))


def _normalize_objective_preview(objective: str, max_len: int = MAX_OBJECTIVE_PREVIEW) -> str:
    """Return a single-line objective preview with optional truncation marker."""
    collapsed = re.sub(r"\s+", " ", objective).strip()
    if len(collapsed) <= max_len:
        return collapsed
    trimmed = collapsed[: max_len - 3].rstrip()
    return f"{trimmed}... (truncated)"


def _summarize_config_layers(origins: dict[str, str]) -> str:
    """Summarize active config layers from origin metadata."""
    active_layers = [layer for layer in ("user", "project", "session") if layer in origins.values()]
    if not active_layers:
        return "defaults"
    return f"{'+'.join(active_layers)} (defaults)"


def _format_run_mode(api_base_url: str | None = None, local_mode: bool | None = None) -> str:
    """Format the run mode label with API host context."""
    if api_base_url is None or local_mode is None:
        from urllib.parse import urlparse

        from obra.config.loaders import get_api_base_url, is_local_mode

        if api_base_url is None:
            api_base_url = get_api_base_url()
        if local_mode is None:
            local_mode = is_local_mode()
        host = urlparse(api_base_url).netloc or api_base_url
    else:
        from urllib.parse import urlparse

        host = urlparse(api_base_url).netloc or api_base_url
    label = "Local emulator" if local_mode else "SaaS"
    return f"{label} ({host})" if host else label


def _format_git_status(work_dir: Path) -> str | None:
    """Return a short git status summary for display."""
    if not is_git_repository(work_dir):
        return "not a repo"
    try:
        import subprocess

        branch_result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=work_dir,
            capture_output=True,
            text=True,
            check=True,
        )
        branch = branch_result.stdout.strip() or "detached"
        status_result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=work_dir,
            capture_output=True,
            text=True,
            check=True,
        )
        dirty_lines = [line for line in status_result.stdout.splitlines() if line.strip()]
        if dirty_lines:
            return f"{branch} (+{len(dirty_lines)})"
        return f"{branch} (clean)"
    except Exception:
        # Check if repo exists but has no commits yet
        import subprocess

        try:
            result = subprocess.run(
                ["git", "rev-list", "-n1", "--all"],
                check=False,
                cwd=work_dir,
                capture_output=True,
                text=True,
            )
            if result.returncode == 0 and not result.stdout.strip():
                return "no commits yet"
        except Exception:
            pass
        return "unknown"


def _format_environment_label(system: str | None = None, release: str | None = None) -> str:
    """Return OS and Python version summary."""
    system_label = system or platform.system()
    release_label = release or platform.release()
    py_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    return f"{system_label} {release_label} | Python {py_version}".strip()


def _resolve_project_display(client: Any, project_id: str | None) -> str:
    """Resolve a project display label with optional name lookup.

    When project_id is None, fetches the user's server-selected default project
    to display the actual project that will be used, not just "server default".
    """
    if not project_id:
        # Fetch server's selected default project
        try:
            result = client.list_projects_with_selection()
            default_id = result.get("default_project_id")
            if default_id:
                project_id = str(default_id)
            else:
                return "none (no default selected)"
        except Exception:
            logger.debug("Failed to fetch server default project", exc_info=True)
            return "server default"
    try:
        project = client.get_project(project_id)
        if isinstance(project, dict):
            name = project.get("name") or project.get("project_name")
            if isinstance(name, str) and name.strip():
                return f"{name.strip()} ({project_id})"
    except Exception:
        logger.debug("Failed to resolve project name for %s", project_id, exc_info=True)
    return project_id


def _validate_project_id_against_server(
    client: Any,
    project_id: str,
    source: str,
) -> str:
    """Validate a project_id exists on the server.

    Args:
        client: API client
        project_id: Project ID to validate
        source: Description of where this ID came from (for error messages)

    Returns:
        Validated project_id (normalized by server)

    Raises:
        typer.Exit: If project doesn't exist or is deleted
    """
    from obra.exceptions import APIError

    try:
        project = client.get_project(project_id)
        is_deleted = project.get("is_deleted")
        if isinstance(is_deleted, bool) and is_deleted:
            print_error(f"Project '{project_id}' ({source}) has been deleted")
            console.print("\nUse 'obra projects list' to see available projects.")
            console.print("Use 'obra projects select <id>' to choose a different default.")
            raise typer.Exit(1)
        # Return the server's canonical project_id
        return str(project.get("project_id", project_id))
    except APIError as e:
        if e.status_code == HTTPStatus.NOT_FOUND.value:
            print_error(f"Project '{project_id}' ({source}) not found on server")
            console.print("\nThe project ID does not exist on the server.")
            console.print("Use 'obra projects list' to see available projects.")
            console.print("Use 'obra projects create' to create a new project.")
        else:
            print_error(f"Failed to validate project '{project_id}': {e}")
        raise typer.Exit(1) from e


def _resolve_and_validate_project_id(
    client: Any,
    cli_project_id: str | None,
) -> str:
    """Resolve and validate project_id from CLI flag, local config, or server default.

    This function ensures CLI and server agree on project_id. It validates any
    provided project_id against the server and fails clearly if there's a mismatch.

    Priority:
        1. CLI --project flag (validated against server)
        2. Local config override (validated against server)
        3. Server's selected default project (already validated)

    Args:
        client: API client
        cli_project_id: Project ID from --project flag (or None)

    Returns:
        Validated project_id that exists on server

    Raises:
        typer.Exit: If no valid project is available
    """
    from obra.config import get_default_project_override

    # Source 1: CLI flag takes highest priority
    if cli_project_id:
        return _validate_project_id_against_server(client, cli_project_id, "from --project flag")

    # Source 2: Local config override
    local_override = get_default_project_override()
    if local_override:
        return _validate_project_id_against_server(client, local_override, "from local config")

    # Source 3: Server's selected default (already validated - it comes from server)
    try:
        result = client.list_projects_with_selection()
        default_id = result.get("default_project_id")
        if default_id:
            logger.debug("Using server's selected default project: %s", default_id)
            return str(default_id)
    except Exception:
        logger.debug("Failed to fetch server default project", exc_info=True)

    # No project available - fail with clear guidance
    print_error("No project selected")
    console.print(f"\n{get_message('guidance.requirement.select_project')}")
    console.print("Options:")
    console.print("  1. obra projects select <id>  - Select an existing project as default")
    console.print("  2. obra projects create       - Create a new project")
    console.print("  3. obra run --project <id> - Specify project for this run only")
    console.print("\nUse 'obra projects list' to see available projects.")
    raise typer.Exit(1)


def _format_review_line(review_config: ReviewConfig) -> str:
    """Summarize review configuration for launch banner."""
    if review_config.skip_review:
        return "disabled"
    if review_config.full_review:
        return "full"
    if review_config.explicit_agents:
        return f"custom (agents: {', '.join(review_config.explicit_agents)})"
    resolved = review_config.resolve_agents(detected_agents=None, server_agents=None)
    if resolved:
        return f"auto (agents: {', '.join(resolved)})"
    return "auto (agents: server/detected)"


def _format_llm_banner(
    effective_map: dict[str, dict[str, str]],
    preflight_results: dict[str, dict[str, str | None]],
    server_validation: dict[str, dict[str, Any]],
    verbose: int,
) -> list[str]:
    """Format the LLM Pipeline Models banner for session startup.

    Groups map entries by (provider, model) tuple and formats summary lines
    with preflight and server validation indicators.

    Args:
        effective_map: Per-stage LLM configuration map.
        preflight_results: Provider preflight check results.
        server_validation: Server-side validation results per entry.
        verbose: Verbosity level (0=grouped, 1+=per-stage).

    Returns:
        List of formatted banner lines.
    """
    from collections import defaultdict

    AGENT_NAMES = {"sense_check", "code_quality", "test_execution"}
    ALL_PIPELINE_STAGES = {"derive", "examine", "revise", "execute", "fix", "review"}
    lines: list[str] = []

    # Separate stages and agent overrides
    stage_entries = {k: v for k, v in effective_map.items() if k not in AGENT_NAMES}
    agent_entries = {k: v for k, v in effective_map.items() if k in AGENT_NAMES}

    # Group stage entries by (provider, model)
    groups: dict[tuple[str, str], list[str]] = defaultdict(list)
    for stage, entry in stage_entries.items():
        key = (entry["provider"], entry["model"])
        groups[key].append(stage)

    def _preflight_icon(provider: str) -> str:
        pf = preflight_results.get(provider, {})
        status = pf.get("status", "")
        if status == "ok":
            return "\u2713 preflight"
        if status == "failed":
            return "\u2717 preflight"
        return ""

    def _server_icon_for(stages_to_check: list[str]) -> str:
        if not server_validation:
            return ""
        statuses = [
            server_validation.get(s, {}).get("status", "") for s in stages_to_check
        ]
        if any(s == "tier_mismatch" for s in statuses):
            return "\u26a0 mismatch"
        if all(s == "resolved" for s in statuses):
            return "\u2713 resolved"
        if all(s == "accepted" for s in statuses):
            return "\u2713 accepted"
        return "\u2713 resolved"

    for (provider, model), stages in groups.items():
        tier = stage_entries[stages[0]]["tier"]
        pf_icon = _preflight_icon(provider)
        sv_icon = _server_icon_for(stages)
        pf_result = preflight_results.get(provider, {})

        if verbose >= 1:
            # Per-stage expansion
            for stage in stages:
                entry = stage_entries[stage]
                thinking = entry.get("thinking_level", "medium")
                stage_sv = _server_icon_for([stage])
                indicators = f"  {pf_icon}"
                if stage_sv:
                    indicators += f" {stage_sv}"
                lines.append(
                    f"  {stage}: {provider} ({model}) | tier: {entry['tier']} | "
                    f"thinking: {thinking}{indicators}"
                )
        else:
            # Grouped format — use "all stages" when covering full pipeline
            stage_set = set(stages)
            if stage_set >= ALL_PIPELINE_STAGES:
                stages_label = "all stages"
            else:
                stages_label = ", ".join(stages)
            indicators = f"  {pf_icon}"
            if sv_icon:
                indicators += f" {sv_icon}"
            lines.append(
                f"  {provider} ({model}) \u2192 {stages_label} | "
                f"tier: {tier}{indicators}"
            )

        # Preflight failure detail
        if pf_result.get("status") == "failed":
            error = pf_result.get("error", "unknown error")
            lines.append(f"    \u2514 {provider}: {error}")

        # Server tier mismatch details
        if server_validation:
            for stage in stages:
                sv = server_validation.get(stage, {})
                if sv.get("status") == "tier_mismatch":
                    lines.append(
                        f"    \u2514 Server computed tier "
                        f"{sv.get('server_tier')} for {stage}"
                    )

    # Agent overrides (always expanded with \u2514 prefix)
    for agent, entry in agent_entries.items():
        provider = entry["provider"]
        model = entry["model"]
        tier = entry["tier"]
        thinking = entry.get("thinking_level", "medium")
        pf_icon = _preflight_icon(provider)
        sv_icon = _server_icon_for([agent])
        indicators = f"  {pf_icon}"
        if sv_icon:
            indicators += f" {sv_icon}"
        lines.append(
            f"    \u2514 {agent}: {provider} ({model}) | tier: {tier} | "
            f"thinking: {thinking}{indicators}"
        )

    return lines


def _format_quality_policy_lines(
    impl_tier: str,
    policy_mode: str,
) -> list[str]:
    """Format quality policy lines for the launch banner.

    Args:
        impl_tier: Execute model tier (fast, medium, high).
        policy_mode: Quality policy mode (auto, fast, medium, high).

    Returns:
        List of formatted banner lines for quality policy display.
    """
    lines: list[str] = []
    effective_tier = impl_tier if policy_mode == "auto" else policy_mode

    if policy_mode == "auto":
        lines.append(
            f"Quality policy: {effective_tier} (auto - from model tier)"
        )
    else:
        lines.append(
            f"Quality policy: {effective_tier} (forced via config)"
        )

    # Mismatch note when forced mode differs from model-derived tier
    if policy_mode != "auto" and policy_mode != impl_tier:
        lines.append(
            f"  Note: Model tier is {impl_tier}, but quality gates "
            f"use {policy_mode} policy"
        )

    return lines


def _build_review_config_from_cli(
    *,
    full_review: bool,
    skip_review: bool,
    review_agents: str | None,
    with_security: bool,
    with_testing: bool,
    with_docs: bool,
    with_code_quality: bool,
    no_security: bool,
    no_testing: bool,
    no_docs: bool,
    no_code_quality: bool,
    review_format: str | None,
    review_quiet: bool,
    review_summary_only: bool,
    fail_on_p1: bool,
    fail_on_p2: bool,
    review_timeout: int | None,
    project_path: Path | None = None,
) -> ReviewConfig:
    """Build ReviewConfig from CLI flags and project config defaults."""
    explicit_agents = _parse_review_agents_csv(review_agents)
    add_agents = [
        name
        for name, enabled in (
            ("security", with_security),
            ("testing", with_testing),
            ("docs", with_docs),
            ("code_quality", with_code_quality),
        )
        if enabled
    ]
    remove_agents = [
        name
        for name, enabled in (
            ("security", no_security),
            ("testing", no_testing),
            ("docs", no_docs),
            ("code_quality", no_code_quality),
        )
        if enabled
    ]

    fail_threshold: str | None = None
    if fail_on_p2:
        fail_threshold = "p2"
    elif fail_on_p1:
        fail_threshold = "p1"

    try:
        cli_inputs = ReviewConfigCLIInputs(
            explicit_agents=explicit_agents,
            add_agents=add_agents,
            remove_agents=remove_agents,
            full_review=full_review,
            skip_review=skip_review,
            output_format=review_format,
            quiet=review_quiet,
            summary_only=review_summary_only,
            fail_threshold=fail_threshold,
            timeout_seconds=review_timeout,
        )
        return ReviewConfig.from_cli_and_config(
            project_path=project_path,
            cli_inputs=cli_inputs,
        )
    except ConfigurationError:
        raise
    except ValueError as exc:
        raise ConfigurationError(str(exc), "Update review CLI flags or review config.") from exc


# =============================================================================
# Input Quality Detection (Phase 2: Error-Driven Nudges)
# =============================================================================

# Common tech stack keywords that indicate specificity
_TECH_KEYWORDS = frozenset(
    [
        # Languages
        "python",
        "javascript",
        "typescript",
        "go",
        "rust",
        "java",
        "ruby",
        "php",
        "swift",
        "kotlin",
        "c#",
        "csharp",
        "c++",
        "scala",
        "elixir",
        # Frameworks
        "fastapi",
        "django",
        "flask",
        "express",
        "nextjs",
        "next.js",
        "react",
        "vue",
        "angular",
        "svelte",
        "rails",
        "spring",
        "gin",
        "echo",
        "actix",
        "nestjs",
        "nuxt",
        "remix",
        "astro",
        "laravel",
        "symfony",
        # Databases
        "postgresql",
        "postgres",
        "mysql",
        "mongodb",
        "redis",
        "sqlite",
        "dynamodb",
        "firestore",
        "supabase",
        "prisma",
        "sqlalchemy",
        "typeorm",
        # Infrastructure
        "docker",
        "kubernetes",
        "k8s",
        "aws",
        "gcp",
        "azure",
        "vercel",
        "heroku",
        "terraform",
        "cloudflare",
    ]
)

# Minimum word count for a specific objective
_MIN_WORD_COUNT = 10

# Maximum word count considered "trivial" (too short for complex tasks)
_TRIVIAL_WORD_COUNT = 5


def _detect_input_quality_issues(objective: str) -> list[str]:
    """Detect common input quality problems in user objectives.

    This function checks for signals that the objective may be too vague
    for Obra to produce good results. It's part of the error-driven nudges
    feature (Phase 2 of layered briefing discovery).

    Args:
        objective: The user's objective string

    Returns:
        List of issue descriptions (empty if no issues detected)
    """
    issues = []
    words = objective.split()
    word_count = len(words)
    objective_lower = objective.lower()

    # Check 1: Very short objectives (likely trivial or vague)
    if word_count < _MIN_WORD_COUNT:
        if word_count <= _TRIVIAL_WORD_COUNT:
            issues.append(f"Very short objective ({word_count} words) - may be too vague")
        else:
            issues.append(f"Short objective ({word_count} words) - consider adding more detail")

    # Check 2: No tech stack keywords detected
    has_tech = any(tech in objective_lower for tech in _TECH_KEYWORDS)
    if not has_tech and word_count >= _TRIVIAL_WORD_COUNT:
        # Don't flag trivial tasks (like "fix typo") for missing tech stack
        issues.append("No tech stack detected - specify language/framework/database")

    # Check 3: Common vague patterns
    vague_patterns = [
        ("build a website", "What kind? E-commerce, blog, SaaS? What features?"),
        ("add authentication", "What type? JWT, OAuth2, session-based?"),
        ("add auth", "What type? JWT, OAuth2, session-based?"),
        ("fix the bug", "Which bug? What's the symptom? What file?"),
        ("fix bug", "Which bug? What's the symptom? What file?"),
        ("make it faster", "Which part? API? Page load? Database?"),
        ("improve performance", "Which part? API? Page load? Database?"),
        ("add tests", "What tests? Unit, integration, E2E? For which components?"),
        ("refactor", "What specifically? Which files/modules? What's the goal?"),
    ]

    for pattern, suggestion in vague_patterns:
        if pattern in objective_lower:
            issues.append(f"Vague pattern '{pattern}' - {suggestion}")
            break  # Only report one vague pattern

    return issues


def _show_input_quality_warning(issues: list[str]) -> None:
    """Display input quality warning with actionable guidance.

    Args:
        issues: List of detected input quality issues
    """
    console.print()
    console.print("[yellow]⚠️  Input Quality Check:[/yellow]")
    for issue in issues:
        console.print(f"  [dim]•[/dim] {issue}")
    console.print()
    console.print("[dim]💡 For better results: [/dim][cyan]obra briefing quick[/cyan]")
    console.print()


def _plan_search_paths(plan_id: str, base_dir: Path) -> list[Path]:
    """Build search paths for local plan files (JSON or YAML)."""
    paths: list[Path] = []
    for ext in [".json", ".yaml", ".yml"]:
        paths.extend(
            [
                base_dir / "docs" / "development" / f"{plan_id}_MACHINE_PLAN{ext}",
                base_dir / ".obra" / "plans" / f"{plan_id}{ext}",
                base_dir / f"{plan_id}{ext}",
            ]
        )
    return paths


def _format_plan_search_paths(plan_id: str, base_dir: Path) -> list[str]:
    """Format search paths relative to base directory when possible."""
    formatted_paths = []
    for path in _plan_search_paths(plan_id, base_dir):
        try:
            relative_path = path.relative_to(base_dir)
            relative_str = str(relative_path)
            if relative_path.parent == Path() and not relative_str.startswith("."):
                relative_str = f"./{relative_str}"
            formatted_paths.append(relative_str)
        except ValueError:
            formatted_paths.append(str(path))
    return formatted_paths


def _extract_plan_context(plan_data: Any, source: str) -> dict[str, Any]:
    """Validate and extract plan context from loaded data."""
    if plan_data is None:
        print_error(f"Plan file is empty: {source}")
        raise typer.Exit(1)

    if not isinstance(plan_data, dict):
        print_error(f"Plan file must be a YAML/JSON object: {source}")
        raise typer.Exit(1)

    epics = plan_data.get("epics")
    if not isinstance(epics, list) or not epics:
        print_error(f"Plan file missing 'epics' array: {source}")
        raise typer.Exit(1)

    for epic in epics:
        if not isinstance(epic, dict):
            print_error(f"Plan file contains an invalid epic entry: {source}")
            raise typer.Exit(1)

        stories = epic.get("stories")
        if not isinstance(stories, list) or not stories:
            print_error(f"Epic {epic.get('id', '<unknown>')} missing 'stories' array: {source}")
            raise typer.Exit(1)

        for story in stories:
            if not isinstance(story, dict):
                print_error(f"Plan file contains an invalid story entry: {source}")
                raise typer.Exit(1)

            tasks = story.get("tasks")
            if tasks is None:
                print_error(f"Story {story.get('id', '<unknown>')} missing 'tasks' array: {source}")
                raise typer.Exit(1)
            if not isinstance(tasks, list):
                print_error(
                    f"Story {story.get('id', '<unknown>')} has invalid tasks format (expected list): {source}"
                )
                raise typer.Exit(1)

    return {"epics": epics}


def _load_plan_context_from_file(plan_path: Path) -> dict[str, Any]:
    """Load plan context from a local YAML/JSON file."""
    import json

    try:
        with plan_path.open(encoding="utf-8") as f:
            try:
                plan_data = json.load(f)
            except json.JSONDecodeError:
                f.seek(0)
                plan_data = yaml.safe_load(f)
    except json.JSONDecodeError as e:
        print_error(f"Plan file is not valid JSON: {plan_path} ({e})")
        logger.error("Plan file JSON decode error for %s: %s", plan_path, e, exc_info=True)
        raise typer.Exit(1) from e
    except yaml.YAMLError as e:
        print_error(f"Plan file is not valid YAML: {plan_path} ({e})")
        logger.error("Plan file YAML parse error for %s: %s", plan_path, e, exc_info=True)
        raise typer.Exit(1) from e
    except UnicodeDecodeError as e:
        print_error(f"Plan file encoding error (expected UTF-8): {e}")
        logger.error("Encoding error reading plan file %s: %s", plan_path, e, exc_info=True)
        raise typer.Exit(1) from e
    except OSError as e:
        print_error(f"Failed to read plan file {plan_path}: {e}")
        logger.error("File I/O error reading plan file %s: %s", plan_path, e, exc_info=True)
        raise typer.Exit(1) from e

    return _extract_plan_context(plan_data, str(plan_path))


def _print_plan_lookup_error(plan_id: str, base_dir: Path) -> None:
    """Display a user-friendly error when local plan file is missing."""
    searched_paths = _format_plan_search_paths(plan_id, base_dir)
    print_error(
        "Plan file not found locally. When using --plan-id, keep the original plan file (JSON or YAML)."
    )
    console.print()
    console.print("Searched:")
    for path in searched_paths:
        console.print(f"  - {path}")
    console.print()
    console.print("Suggestion: Re-upload the plan or use --objective without --plan-id.")


def _find_plan_yaml(plan_id: str, base_dir: Path | None = None) -> Path | None:
    """Find a plan YAML/JSON file by ID in standard locations."""
    root = base_dir or Path.cwd()
    for path in _plan_search_paths(plan_id, root):
        if path.exists():
            return path
    return None


def _run_derive(
    objective: str | None,
    working_dir: Path | None = None,
    project_id: str | None = None,
    resume_session: str | None = None,
    continue_from: str | None = None,
    plan_id: str | None = None,
    plan_file: Path | None = None,
    model: str | None = None,
    fast_model: str | None = None,
    high_model: str | None = None,
    impl_provider: str | None = None,
    thinking_level: str | None = None,
    verbose: int = 0,
    stream: bool = False,
    plan_only: bool = False,
    permissive: bool = False,
    defaults_json: bool = False,
    no_closeout: bool = False,
    skip_intent: bool = False,
    review_intent: bool = False,
    enrich: bool = False,
    no_enrich: bool = False,
    isolated: bool | None = None,
    no_isolated: bool | None = None,
    full_review: bool = False,
    skip_review: bool = False,
    review_agents: str | None = None,
    with_security: bool = False,
    with_testing: bool = False,
    with_docs: bool = False,
    with_code_quality: bool = False,
    no_security: bool = False,
    no_testing: bool = False,
    no_docs: bool = False,
    no_code_quality: bool = False,
    review_format: str | None = None,
    review_quiet: bool = False,
    review_summary_only: bool = False,
    fail_on_p1: bool = False,
    fail_on_p2: bool = False,
    review_timeout: int | None = None,
    auto_report: bool = False,
    yes: bool = False,
    mock_credentials: bool = False,
    skip_git_check: bool = False,
    auto_init_git: bool = False,
    skip_quality_check: bool = False,
    skip_complexity_check: bool = False,
    parallel: bool = False,
    skip_tier_check: bool = False,
    from_step: int | None = None,
    cascade: bool = False,
    work_type: str | None = None,
    skip_explore: bool = False,
    force_explore: bool = False,
    plan_mode: str | None = None,
) -> None:
    """Shared implementation for run workflow.

    Tier 1: Interruption handler for clean CTRL+C behavior.

    This function contains the core logic for starting/resuming orchestrated workflows.
    It's called by both the run command and the app callback.

    Args:
        objective: The objective to accomplish
        working_dir: Working directory (defaults to current directory)
        project_id: Optional project ID override
        resume_session: Resume an existing session by ID
        continue_from: Continue from a failed/escalated session (creates new session, skips completed tasks)
        plan_id: Use an uploaded plan by ID
        plan_file: Upload and use a plan file in one step
        model: Implementation model (e.g., opus, gpt-5.2, gemini-2.5-flash)
        fast_model: Fast tier override (used for extraction/quick tasks)
        high_model: High tier override (used for complex reasoning)
        impl_provider: Implementation provider (anthropic, openai, google)
        thinking_level: Thinking/reasoning level (off, low, medium, high, maximum)
        verbose: Verbosity level (0-3)
        stream: Enable real-time LLM output streaming
        plan_only: Create plan without executing (client-side exit after planning)
        no_closeout: Skip close-out story injection
        isolated: Run agent in isolated environment (True = enable)
        no_isolated: Disable isolation (True = disable, overrides auto-detect)
        full_review: Force all review agents to run
        skip_review: Skip the review phase entirely
        review_agents: Comma-separated explicit review agent list
        with_security: Add the security review agent
        with_testing: Add the testing review agent
        with_docs: Add the docs review agent
        with_code_quality: Add the code_quality review agent
        no_security: Remove the security review agent
        no_testing: Remove the testing review agent
        no_docs: Remove the docs review agent
        no_code_quality: Remove the code_quality review agent
        review_format: Preferred review output format (text or json)
        review_quiet: Suppress review output
        review_summary_only: Show only review summary counts
        fail_on_p1: Exit with status 1 when P1 findings are present
        fail_on_p2: Exit with status 1 when P1 or P2 findings are present
        review_timeout: Per-agent review timeout in seconds
        skip_quality_check: Skip UserPlan quality assessment
        skip_complexity_check: Skip complexity estimation for plan items
        parallel: Enable parallel execution of independent plan items
        skip_tier_check: Skip server tier mismatch validation
        from_step: Re-derive from step N onwards (1-indexed), preserving earlier steps
        cascade: Mark sibling steps after the re-derived step as STALE
        work_type: Manual work type override (bypasses auto-detection when provided)
    """
    setup_logging(verbose)

    # Start session console logging early to capture all output
    # Uses a timestamp-based ID initially, renamed when session_id is available
    import atexit

    session_logger = start_session_logging(
        session_id=resume_session or continue_from or datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    )
    # Ensure logging is stopped when program exits (handles all exit paths)
    atexit.register(stop_session_logging)

    # Reset interrupt state for this run (avoid stale session IDs from previous runs)
    _interrupt_state["count"] = 0
    _interrupt_state["total"] = 0
    _interrupt_state["last_time"] = 0.0
    _interrupt_state["session_id"] = None
    _interrupt_state["orchestrator"] = None  # Will be set after orchestrator is created
    _interrupt_state["recovery_hint_printed"] = False
    _interrupt_state["recovery_hint_session_id"] = None

    # Tier 1: Set up interruption handler for clean CTRL+C behavior
    import signal

    def handle_interrupt(_sig, _frame):
        """Handle CTRL+C with graceful shutdown on first press, force quit on second.

        First Ctrl+C: Shows message that interrupt was received, will exit gracefully
        Second Ctrl+C within 3s: Force quits immediately (may lose session state)
        Third+ Ctrl+C (anytime): Force quits immediately (bypasses countdown)
        """
        current_time = time.time()

        # Track total interrupts (never resets - 3rd+ always force quits)
        _interrupt_state["total"] = int(_interrupt_state["total"]) + 1

        # Reset window counter if enough time has passed since last interrupt
        if current_time - float(_interrupt_state["last_time"]) > _FORCE_QUIT_WINDOW_SECONDS:
            _interrupt_state["count"] = 0

        _interrupt_state["count"] = int(_interrupt_state["count"]) + 1
        _interrupt_state["last_time"] = current_time

        # Force quit conditions (thresholds from config):
        # 1. Nth Ctrl+C within window (default: 2nd), OR
        # 2. Mth+ Ctrl+C total (default: 3rd) - bypasses countdown
        from obra.config.loaders import (
            get_cli_force_exit_threshold,
            get_cli_interrupt_threshold,
        )

        interrupt_threshold = get_cli_interrupt_threshold()
        force_exit_threshold = get_cli_force_exit_threshold()
        if (
            int(_interrupt_state["count"]) >= interrupt_threshold
            or int(_interrupt_state["total"]) >= force_exit_threshold
        ):
            # Force quit - use os._exit to bypass cleanup
            console.print()
            print_warning("Force quitting... (session state may be lost)")
            _print_interrupt_resume_block(mark_as_printed=True)
            os._exit(130)
        else:
            # First Ctrl+C - graceful shutdown message
            console.print()
            print_warning("Interrupt received - finishing current operation...")
            console.print("[dim]Press Ctrl+C again to force quit (session state may be lost)[/dim]")
            console.print()
            _print_interrupt_resume_block(mark_as_printed=True)
            request_interrupt("sigint")
            if not should_defer_interrupts():
                raise typer.Exit(130)  # Standard SIGINT exit code
            return

    signal.signal(signal.SIGINT, handle_interrupt)

    # Validate plan-related arguments
    if plan_id and plan_file:
        print_error("Cannot specify both --plan-id and --plan-file")
        console.print("\nUse one or the other:")
        console.print("  --plan-id: Reference an already uploaded plan")
        console.print("  --plan-file: Upload and use a plan in one step")
        raise typer.Exit(2)

    # Validate session-related arguments
    if resume_session and continue_from:
        print_error("Cannot specify both --resume and --continue-from")
        console.print("\nUse one or the other:")
        console.print("  --resume: Resume an active session")
        console.print(
            "  --continue-from: Continue from failed/escalated session (creates new session)"
        )
        raise typer.Exit(2)

    # XOR validation: require objective unless resuming or continuing
    if not objective and not resume_session and not continue_from:
        print_error("Must specify objective, --resume, or --continue-from")
        console.print("\nUsage:")
        console.print('  obra run "Your objective here"')
        console.print("  obra run --resume <session_id>")
        console.print("  obra run --continue-from <session_id>")
        raise typer.Exit(1)

    if objective and resume_session:
        print_error("Cannot specify both objective and --resume")
        console.print("\nUse one or the other:")
        console.print('  obra run "Your objective here"  # Start new session')
        console.print("  obra run --resume <session_id>  # Resume existing session")
        raise typer.Exit(1)

    # Validate --from-step requires a plan_file or plan_id (existing UserPlan)
    if from_step is not None and not plan_file and not plan_id:
        print_error("--from-step requires --plan-file or --plan-id")
        console.print("\n--from-step re-derives from step N onwards in an existing UserPlan.")
        console.print("Provide the plan source:")
        console.print("  --plan-file path/to/plan.yaml")
        console.print("  --plan-id <existing-plan-id>")
        raise typer.Exit(2)

    # Handle --continue-from: fetch session info and extract completed items
    continue_from_objective = None
    continue_from_plan_context: dict[str, Any] | None = None
    continue_from_session: dict[str, Any] | None = None
    skip_completed_items: list[str] = []
    if continue_from:
        try:
            from obra.api import APIClient

            # ISSUE-009: Removed local import of APIError - it shadows the global
            # import at line 88 and causes UnboundLocalError at line 1772
            # Use the global import instead

            client = APIClient.from_config()

            # Fetch the source session
            source_session = client.get_session(continue_from)
            continue_from_session = source_session
            continue_from_objective = source_session.get("objective")

            # Fetch plan items and identify completed ones
            plan_data = client.get_session_plan(continue_from)
            plan_items = plan_data.get("plan_items", [])

            for item in plan_items:
                if item.get("status") == "completed":
                    # Collect task identifiers (title or order)
                    task_id = item.get("title") or f"task_{item.get('order', 0)}"
                    skip_completed_items.append(task_id)

            completed_count = len(skip_completed_items)
            total_count = len(plan_items)

            objective_override = (
                objective.strip() if isinstance(objective, str) and objective.strip() else None
            )
            if not objective_override:
                objective = continue_from_objective or objective
            resolved_objective = objective_override or continue_from_objective or "<unknown>"

            console.print()
            print_info(f"Continuing from session {continue_from[:8]}...")
            console.print(f"  Progress: {completed_count}/{total_count} tasks already completed")
            console.print(f"  Objective: {resolved_objective}")
            console.print()

            plan_context_candidate = plan_data.get("plan_context")
            if isinstance(plan_context_candidate, dict) and plan_context_candidate.get("epics"):
                continue_from_plan_context = _extract_plan_context(
                    plan_context_candidate,
                    f"session {continue_from[:8]} plan context",
                )
                print_info("  Plan context: preserved from source session")

            # Objective is now resolved for continue-from (uses original if blank)

            if not skip_intent:
                skip_intent = True
                try:
                    from obra.intent.storage import IntentStorage

                    storage = IntentStorage()
                    project_id = storage.get_project_id(working_dir or Path.cwd())
                    active_intent = storage.load_active(project_id)
                    if active_intent:
                        print_info(f"  Intent: preserving active intent {active_intent.id}")
                    else:
                        print_warning(
                            "  Intent: no active intent found; continuing without intent context"
                        )
                except Exception:
                    logger.debug(
                        "Continue-from intent check failed; proceeding without intent context",
                        exc_info=True,
                    )

        except APIError as e:
            if e.status_code == HTTPStatus.NOT_FOUND.value:
                print_error(f"Session not found: {continue_from}")
                console.print("\nCheck the session ID with: obra status")
            else:
                print_error(f"Failed to fetch session: {e}")
            raise typer.Exit(1) from e
        except typer.Exit:
            raise
        except Exception as e:
            print_error(f"Failed to prepare continue-from: {e}")
            raise typer.Exit(1) from e

    # S1.T0/S1.T1: Resolve model, provider, thinking from CLI flags or env vars
    # Precedence: CLI flag > OBRA_* env var > default
    effective_model = _resolve_model(model)
    effective_provider = _resolve_provider(impl_provider)
    effective_thinking = _resolve_thinking_level(thinking_level)
    effective_fast_model = _resolve_tier_model(fast_model, "fast")
    effective_high_model = _resolve_tier_model(high_model, "high")

    if effective_fast_model is not None:
        os.environ["OBRA_FAST_MODEL"] = effective_fast_model
    if effective_high_model is not None:
        os.environ["OBRA_HIGH_MODEL"] = effective_high_model

    # S2.T2: Validate thinking level against THINKING_LEVELS constant
    if effective_thinking is not None and effective_thinking not in THINKING_LEVELS:
        print_error(f"Invalid thinking level: '{effective_thinking}'")
        console.print(f"\nValid levels: {', '.join(THINKING_LEVELS)}")
        raise typer.Exit(2)  # Exit code 2 for config errors

    # S2.T3 & S2.T4: Auto-detect provider from model, warn if unknown
    if effective_model and not effective_provider:
        detected = infer_provider_from_model(effective_model)
        if detected:
            effective_provider = detected
            if verbose > 0:
                console.print(f"[dim]Detected provider: {detected}[/dim]")
        else:
            # S2.T4: Unknown model warning with default fallback
            print_warning(
                f"Unknown model '{effective_model}', using default provider: {DEFAULT_PROVIDER}"
            )
            effective_provider = DEFAULT_PROVIDER

    # Phase 2: Error-driven nudges - detect vague input and show warning
    # This is a non-blocking warning, not an error - execution continues
    if objective is not None:
        quality_issues = _detect_input_quality_issues(objective)
        if quality_issues:
            _show_input_quality_warning(quality_issues)

    progress_emitter: ProgressEmitter | None = None
    orchestrator: Any | None = None
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth
        from obra.config import validate_provider_ready
        from obra.hybrid import HybridOrchestrator

        client = APIClient.from_config()

        # FIX-PROJID-002: Validate project_id against server - CLI must agree with server
        # Priority: CLI flag > local config > server's selected default
        # For resume/continue, prefer the session's project_id to avoid mismatched defaults.
        session_id = resume_session or continue_from
        session_project_id: str | None = None
        if session_id:
            session_data = continue_from_session if continue_from else None
            if session_data is None:
                try:
                    session_data = client.get_session(session_id)
                except APIError as e:
                    if e.status_code == HTTPStatus.NOT_FOUND.value:
                        print_error(f"Session not found: {session_id}")
                        console.print("\nCheck the session ID with: obra status")
                    else:
                        print_error(f"Failed to fetch session: {e}")
                    raise typer.Exit(1) from e
            session_project_id = session_data.get("project_id") if session_data else None

        if session_project_id:
            if project_id and str(project_id) != str(session_project_id):
                print_warning(
                    f"Ignoring --project {project_id}; session {session_id[:8]} "
                    f"belongs to project {session_project_id}"
                )
            project_id = _validate_project_id_against_server(
                client, str(session_project_id), f"from session {session_id[:8]}"
            )
        else:
            # Fails clearly if project doesn't exist (no auto-creation from directory names)
            project_id = _resolve_and_validate_project_id(client, project_id)

        selection = _resolve_working_dir_selection(
            client=client,
            working_dir=working_dir,
            project_id=project_id,
            resume_session=resume_session,
            continue_from=continue_from,
        )
        work_dir = selection.path

        if not work_dir.exists():
            print_error(f"Working directory does not exist: {work_dir}")
            raise typer.Exit(1)

        if selection.conflict and selection.prompt_used:
            print_info(f"Working directory selected: {work_dir}")

        if selection.stored_missing and selection.project_id:
            try:
                client.update_project(
                    project_id=selection.project_id,
                    working_dir=str(work_dir),
                )
                print_info(f"Saved working directory to project {selection.project_id}")
            except Exception as exc:
                logger.warning(
                    "Failed to persist working directory for project %s: %s",
                    selection.project_id,
                    exc,
                )

        review_config = _build_review_config_from_cli(
            full_review=full_review,
            skip_review=skip_review,
            review_agents=review_agents,
            with_security=with_security,
            with_testing=with_testing,
            with_docs=with_docs,
            with_code_quality=with_code_quality,
            no_security=no_security,
            no_testing=no_testing,
            no_docs=no_docs,
            no_code_quality=no_code_quality,
            review_format=review_format,
            review_quiet=review_quiet,
            review_summary_only=review_summary_only,
            fail_on_p1=fail_on_p1,
            fail_on_p2=fail_on_p2,
            review_timeout=review_timeout,
            project_path=work_dir,
        )
        # FIX-PROJID-002: project_id is now guaranteed to be validated against server.
        # _resolve_and_validate_project_id() fails if no valid project is available.

        planning_config = _load_planning_config(work_dir)
        # Check both legacy planning_config and new review.permissive_mode path
        config_permissive = bool(planning_config.get("permissive_mode"))
        if not config_permissive:
            # Check review.permissive_mode from layered config (Menu 4 setting)
            from obra.config.loaders import load_layered_config

            layered_cfg, _, _ = load_layered_config(include_defaults=True)
            config_permissive = bool(layered_cfg.get("review", {}).get("permissive_mode"))
        effective_permissive = permissive or config_permissive
        bypass_modes: list[str] = []
        if effective_permissive:
            bypass_modes.append("planning_permissive")
        if no_closeout:
            bypass_modes.append("no_closeout")
        if skip_intent:
            bypass_modes.append("skip_intent")
        if review_intent:
            bypass_modes.append("review_intent")
        if enrich:
            bypass_modes.append("enrich")
        if no_enrich:
            bypass_modes.append("no_enrich")
        if skip_quality_check:
            bypass_modes.append("skip_quality_check")
        if skip_complexity_check:
            bypass_modes.append("skip_complexity_check")
        if parallel:
            bypass_modes.append("parallel")
        if skip_tier_check:
            bypass_modes.append("skip_tier_check")
        if skip_explore:
            bypass_modes.append("skip_explore")
        if force_explore:
            bypass_modes.append("force_explore")

        # Resolve effective config values with defaults
        # Read from user config if CLI flags not provided (FIX-DISPLAY-001)
        from obra.config import get_llm_config

        user_llm_config = get_llm_config()
        impl_config = user_llm_config.get("implementation", {})
        config_provider = impl_config.get("provider", DEFAULT_PROVIDER)
        config_model = impl_config.get("model", DEFAULT_MODEL)
        config_thinking = impl_config.get("thinking_level", DEFAULT_THINKING_LEVEL)

        display_provider = effective_provider or config_provider
        display_model = effective_model or config_model
        display_thinking = effective_thinking or config_thinking

        # S3.T1: Fail-fast provider health check before any session output/auth
        validate_provider_ready(display_provider)

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        # Ensure valid token
        try:
            ensure_valid_token()
        except AuthenticationError as e:
            display_obra_error(e, console)
            raise typer.Exit(1) from e

        plan_context: dict[str, Any] | None = None

        # Handle --plan-file: upload plan before starting session
        effective_plan_id = plan_id
        if plan_file:
            console.print()
            console.print(f"[dim]Uploading plan file: {plan_file}[/dim]")
            try:
                import yaml

                from obra.api import APIClient

                # C15: Comprehensive plan file validation
                # 1. Check file exists
                if not plan_file.exists():
                    print_error(f"Plan file not found: {plan_file}")
                    logger.error(f"Plan file does not exist: {plan_file}")
                    raise typer.Exit(1)

                # 2. Check file is readable
                if not os.access(plan_file, os.R_OK):
                    print_error(f"Plan file is not readable: {plan_file}")
                    logger.error(f"Insufficient permissions to read plan file: {plan_file}")
                    raise typer.Exit(1)

                # 3. Parse YAML file with comprehensive error handling
                try:
                    with plan_file.open(encoding="utf-8") as f:
                        plan_data = yaml.safe_load(f)
                except yaml.YAMLError as e:
                    print_error(f"Invalid YAML syntax in plan file: {e}")
                    logger.error(f"YAML parsing error in {plan_file}: {e}", exc_info=True)
                    raise typer.Exit(1) from e
                except UnicodeDecodeError as e:
                    print_error(f"Plan file encoding error (expected UTF-8): {e}")
                    logger.error(
                        f"Encoding error reading plan file {plan_file}: {e}",
                        exc_info=True,
                    )
                    raise typer.Exit(1) from e

                # 4. Validate plan_data is dict type
                if plan_data is None:
                    print_error(f"Plan file is empty: {plan_file}")
                    logger.error(f"Plan file {plan_file} contains no data")
                    raise typer.Exit(1)

                if not isinstance(plan_data, dict):
                    print_error(
                        f"Plan file must contain a YAML dictionary, got {type(plan_data).__name__}"
                    )
                    logger.error(
                        f"Plan file {plan_file} validation failed: expected dict, got {type(plan_data).__name__}"
                    )
                    raise typer.Exit(1)

                # Extract plan name
                plan_name = plan_data.get("work_id", plan_file.stem)

                # Extract plan context for local execution
                plan_context = _extract_plan_context(plan_data, str(plan_file))

                # Upload to server for full validation and storage
                client = APIClient.from_config()
                upload_response = client.upload_plan(plan_name, plan_data)
                effective_plan_id = upload_response.get("plan_id")

                console.print(f"[dim]Plan uploaded: {effective_plan_id}[/dim]")

            except APIError as e:
                display_obra_error(e, console)
                logger.error(f"API error uploading plan file: {e}", exc_info=True)
                raise typer.Exit(1) from e
            except ConfigurationError as e:
                display_obra_error(e, console)
                logger.error(f"Configuration error uploading plan file: {e}", exc_info=True)
                raise typer.Exit(1) from e
            except ObraError as e:
                display_obra_error(e, console)
                logger.error(f"Obra error uploading plan file: {e}", exc_info=True)
                raise typer.Exit(1) from e
            except OSError as e:
                print_error(f"Failed to read plan file: {e}")
                logger.error(f"File I/O error reading plan file {plan_file}: {e}", exc_info=True)
                raise typer.Exit(1) from e
            except typer.Exit:
                raise
            except Exception as e:
                print_error(f"Unexpected error uploading plan file: {e}")
                logger.exception(f"Unexpected error uploading plan file {plan_file}")
                raise typer.Exit(1) from e

        plan_search_root = work_dir

        if effective_plan_id and not plan_file:
            plan_path = _find_plan_yaml(effective_plan_id, plan_search_root)
            if not plan_path:
                _print_plan_lookup_error(effective_plan_id, plan_search_root)
                raise typer.Exit(1)

            plan_context = _load_plan_context_from_file(plan_path)

        if plan_context is None and continue_from_plan_context is not None:
            plan_context = continue_from_plan_context

        # S2.T3: Create UserPlan from plan file before derivation
        # This ensures plan file imports go through the UserPlan flow
        userplan_id: str | None = None
        if plan_context is not None:
            try:
                from obra.execution.intake import create_userplan_from_plan_file

                # Determine plan file path for metadata
                plan_file_path_str: str | None = None
                if plan_file:
                    plan_file_path_str = str(plan_file)
                elif effective_plan_id:
                    found_path = _find_plan_yaml(effective_plan_id, plan_search_root)
                    if found_path:
                        plan_file_path_str = str(found_path)

                # Create UserPlan from plan context
                userplan = create_userplan_from_plan_file(
                    plan_context=plan_context,
                    project_id=project_id or "default",
                    plan_file_path=plan_file_path_str,
                )
                userplan_id = userplan.id

                from obra.execution.userplan_cache import (
                    get_userplan_cache_dir,
                    write_userplan_cache,
                    write_userplan_mapping,
                )

                source_metadata = {
                    "type": userplan.source.type.value,
                    "path": plan_file_path_str,
                    "plan_context": plan_context,
                }
                cache_ok, cache_error = write_userplan_cache(userplan, userplan.project_id)
                mapping_ok, mapping_error = write_userplan_mapping(
                    userplan, userplan.project_id, source_metadata
                )
                if not cache_ok:
                    logger.warning("UserPlan cache write failed: %s", cache_error)
                if not mapping_ok:
                    logger.warning("UserPlan mapping write failed: %s", mapping_error)
                if cache_ok:
                    cache_path = get_userplan_cache_dir(userplan.project_id) / f"{userplan.id}.yaml"
                    logger.info("UserPlan cached at %s", cache_path)
                    if verbose > 0:
                        print_info(f"UserPlan cached at {cache_path}")

                # Store UserPlan to server via API client
                userplan_source_dict = {
                    "type": userplan.source.type.value,
                    "path": userplan.source.path,
                    "raw_objective": userplan.source.raw_objective,
                    "generated": userplan.source.generated,
                }
                userplan_steps_list = [
                    {
                        "id": step.id,
                        "index": step.index,
                        "title": step.title,
                        "description": step.description,
                        "raw_text": step.raw_text,
                        "derivation_status": step.derivation_status.value,
                        "context": step.context.model_dump() if step.context else None,
                    }
                    for step in userplan.steps
                ]

                from obra.api import APIClient as UserPlanAPIClient

                userplan_client = UserPlanAPIClient.from_config()
                userplan_client.create_userplan(
                    userplan_id=userplan.id,
                    project_id=userplan.project_id,
                    source=userplan_source_dict,
                    steps=userplan_steps_list,
                    status=userplan.status.value,
                    metadata=userplan.metadata,
                )
                console.print(f"[dim]UserPlan created: {userplan_id}[/dim]")
                logger.info(f"Created UserPlan {userplan_id} from plan file")

                # Handle --from-step: validate step index and mark steps as DERIVING
                if from_step is not None:
                    total_steps = len(userplan.steps)
                    if from_step > total_steps:
                        print_error(f"--from-step {from_step} exceeds total steps ({total_steps})")
                        console.print(f"\nUserPlan has {total_steps} step(s).")
                        console.print(f"Valid range: 1 to {total_steps}")
                        raise typer.Exit(2)

                    # Mark steps >= from_step as DERIVING
                    step_indices_to_rederive = list(range(from_step, total_steps + 1))
                    console.print(
                        f"[dim]Re-deriving from step {from_step}: "
                        f"steps {from_step}-{total_steps} will be updated[/dim]"
                    )

                    # Update step statuses via API
                    try:
                        userplan_client.update_userplan_steps_status_batch(
                            userplan_id=userplan_id,
                            step_indices=step_indices_to_rederive,
                            derivation_status="deriving",
                        )
                        logger.info(
                            f"Marked steps {step_indices_to_rederive} as DERIVING "
                            f"for UserPlan {userplan_id}"
                        )
                    except Exception as status_err:
                        logger.warning(
                            f"Failed to update step statuses: {status_err}",
                            exc_info=True,
                        )
                        console.print(f"[dim]Note: Step status update skipped ({status_err})[/dim]")

                    # Handle --cascade: mark sibling steps (after from_step) as STALE
                    if cascade and from_step < total_steps:
                        sibling_step_indices = list(range(from_step + 1, total_steps + 1))
                        try:
                            userplan_client.update_userplan_steps_status_batch(
                                userplan_id=userplan_id,
                                step_indices=sibling_step_indices,
                                derivation_status="stale",
                            )
                            console.print(
                                f"[dim]Cascade: Marked sibling steps {sibling_step_indices} as STALE[/dim]"
                            )
                            logger.info(
                                f"Cascade: Marked steps {sibling_step_indices} as STALE "
                                f"for UserPlan {userplan_id}"
                            )
                        except Exception as cascade_err:
                            logger.warning(
                                f"Failed to cascade staleness: {cascade_err}",
                                exc_info=True,
                            )
                            console.print(
                                f"[dim]Note: Cascade staleness update skipped ({cascade_err})[/dim]"
                            )

            except typer.Exit:
                raise
            except Exception as e:
                # Log warning but don't fail - this is an enhancement
                logger.warning(f"Failed to create UserPlan from plan file: {e}", exc_info=True)
                console.print(f"[dim]Note: UserPlan creation skipped ({e})[/dim]")
        # BUG-002 FIX: Create UserPlan for free-form objectives
        # All derivation flows must go through UserPlan (commit b20df0cf)
        elif objective is not None:
            try:
                from obra.execution.intake import create_userplan_from_objective

                # Create UserPlan from objective
                userplan = create_userplan_from_objective(
                    objective=objective,
                    project_id=project_id or "default",
                )
                userplan_id = userplan.id

                # Store UserPlan to server via API client
                userplan_source_dict = {
                    "type": userplan.source.type.value,
                    "path": userplan.source.path,
                    "raw_objective": userplan.source.raw_objective,
                    "generated": userplan.source.generated,
                }
                userplan_steps_list = [
                    {
                        "id": step.id,
                        "index": step.index,
                        "title": step.title,
                        "description": step.description,
                        "raw_text": step.raw_text,
                        "derivation_status": step.derivation_status.value,
                        "context": step.context.model_dump() if step.context else None,
                    }
                    for step in userplan.steps
                ]

                from obra.api import APIClient as UserPlanAPIClient

                userplan_client = UserPlanAPIClient.from_config()
                userplan_client.create_userplan(
                    userplan_id=userplan.id,
                    project_id=userplan.project_id,
                    source=userplan_source_dict,
                    steps=userplan_steps_list,
                    status=userplan.status.value,
                    metadata=userplan.metadata,
                )
                console.print(f"[dim]UserPlan created: {userplan_id}[/dim]")
                logger.info(f"Created UserPlan {userplan_id} from objective")

            except typer.Exit:
                raise
            except Exception as e:
                # Check if persistence is required via config flag
                # features.userplan.require_persistence: true = fail, false = warn
                require_persistence = False
                try:
                    from obra.config.loaders import load_layered_config

                    cfg, _, _ = load_layered_config(include_defaults=True)
                    require_persistence = (
                        cfg.get("features", {})
                        .get("userplan", {})
                        .get("require_persistence", False)
                    )
                except Exception:
                    pass  # Default to false (allow standalone operation)

                if require_persistence:
                    # SaaS mode: UserPlan persistence is required
                    logger.exception(f"Failed to create UserPlan (persistence required): {e}")
                    console.print(
                        f"[red]Error: UserPlan creation failed ({e})[/red]\n"
                        "[dim]Set features.userplan.require_persistence: false for standalone mode[/dim]"
                    )
                    raise typer.Exit(1) from e
                # Standalone mode: warn but continue
                logger.warning(f"Failed to create UserPlan from objective: {e}", exc_info=True)
                console.print(f"[dim]Note: UserPlan creation skipped ({e})[/dim]")

        console.print()
        project_display = _resolve_project_display(client, project_id)
        objective_preview = _normalize_objective_preview(
            objective or continue_from_objective or "(resuming)"
        )
        try:
            from obra.config.loaders import load_layered_config

            _, origins, _ = load_layered_config(project_id=project_id, include_defaults=True)
            config_summary = _summarize_config_layers(origins)
        except Exception:
            config_summary = "unknown"
        run_mode = _format_run_mode()
        git_status = _format_git_status(work_dir)
        environment_label = _format_environment_label()

        console.print(f"[bold]Obra Run v{__version__}[/bold]", style="cyan")
        console.print(f"Project: {project_display}")
        console.print(f"Directory: {work_dir}")
        console.print(f"Objective: {objective_preview}")
        if resume_session:
            console.print(f"Resume: {resume_session}")
        if effective_plan_id:
            console.print(f"Plan: {effective_plan_id}")
        console.print(f"Run mode: {run_mode}")
        console.print(f"Config: {config_summary}")
        if git_status:
            console.print(f"Git: {git_status}")
        console.print(f"Environment: {environment_label}")

        # Auth/invocation method display
        # Currently: Auth is always OAuth (API-Key auth not built yet)
        # Currently: Invocation is always CLI (direct API calls not built yet)
        auth_method = "OAuth"  # Future: check for API-Key auth when implemented
        invocation_method = "CLI"  # Future: "Direct" when API calls are implemented

        # Format verbosity level for display
        # Default is PROGRESS (1), so: -q=quiet, (default)=progress, -vv=detail, -vvv=debug
        verbosity_labels = {0: "quiet", 1: "progress", 2: "detail", 3: "debug"}
        verbosity_label = verbosity_labels.get(verbose, f"level-{verbose}")
        if verbose == 0:
            verbosity_flag = "(-q)"
        elif verbose == 1:
            verbosity_flag = "(default)"
        else:
            verbosity_flag = f"(-{'v' * verbose})"

        console.print(
            f"Auth: {auth_method} | Invocation: {invocation_method} | "
            f"Verbosity: {verbosity_label} {verbosity_flag}"
        )

        # Compact pre-session LLM preflight summary
        # Full LLM Pipeline Models section renders post-session (in orchestrator)
        # after server validation completes — see orchestrator._emit_llm_pipeline_banner()
        from obra.config.llm import resolve_action_llm_config, resolve_role_llm_config

        effective_map: dict[str, dict[str, str]] = {}
        for stage in ["derive", "examine", "revise", "execute", "fix", "review"]:
            stage_config = resolve_role_llm_config(stage)
            provider = stage_config.get("provider", DEFAULT_PROVIDER)
            model = stage_config.get("model", DEFAULT_MODEL)
            tier = resolve_quality_tier(provider, model)
            thinking = stage_config.get("thinking_level", DEFAULT_THINKING_LEVEL)
            effective_map[stage] = {
                "provider": provider,
                "model": model,
                "tier": tier,
                "thinking_level": thinking,
            }

        # Check agent overrides (included only when they differ from parent review)
        review_entry = effective_map.get("review", {})
        for agent_name in ["sense_check", "code_quality", "test_execution"]:
            try:
                agent_config = resolve_action_llm_config(agent_name)
                agent_provider = agent_config.get("provider", DEFAULT_PROVIDER)
                agent_model = agent_config.get("model", DEFAULT_MODEL)
                if (
                    agent_provider != review_entry.get("provider")
                    or agent_model != review_entry.get("model")
                ):
                    agent_tier = resolve_quality_tier(agent_provider, agent_model)
                    agent_thinking = agent_config.get(
                        "thinking_level", DEFAULT_THINKING_LEVEL
                    )
                    effective_map[agent_name] = {
                        "provider": agent_provider,
                        "model": agent_model,
                        "tier": agent_tier,
                        "thinking_level": agent_thinking,
                    }
            except Exception:
                pass

        # Run preflight checks for all unique providers and provider+model pairs
        providers = sorted({entry["provider"] for entry in effective_map.values()})
        provider_model_pairs = sorted(
            {(entry["provider"], entry.get("model", "")) for entry in effective_map.values()}
        )
        preflight_results: dict[str, dict[str, str | None]] = {}
        preflight_failures: list[str] = []
        for pf_provider in providers:
            try:
                validate_provider_ready(pf_provider)
                preflight_results[pf_provider] = {"status": "ok", "error": None}
            except Exception as e:
                preflight_results[pf_provider] = {"status": "failed", "error": str(e)}
                preflight_failures.append(f"{pf_provider} ({e})")

        from obra.config.providers import validate_provider_model_ready

        for pf_provider, pf_model in provider_model_pairs:
            try:
                validate_provider_model_ready(
                    pf_provider,
                    pf_model,
                    auth_method="oauth",
                    cwd=work_dir,
                )
            except Exception as e:
                preflight_results[pf_provider] = {"status": "failed", "error": str(e)}
                preflight_failures.append(f"{pf_provider}:{pf_model} ({e})")

        # Display compact preflight result
        console.print()
        if not preflight_failures:
            provider_list = ", ".join(providers)
            console.print(f"LLM preflight: {provider_list} \u2713")
        else:
            console.print("[red]LLM preflight failed:[/red]")
            for failure in preflight_failures:
                console.print(f"  \u2717 {failure}")

        console.print()

        config = load_config()
        story0_override_config: dict[str, Any] | None = None
        if yes or mock_credentials:
            from obra.config.loaders import load_layered_config

            story0_override_config, _, _ = load_layered_config(include_defaults=True)
            if yes:
                story0_override_config.setdefault("story0", {})["auto_approve"] = True
            if mock_credentials:
                story0_override_config.setdefault("story0", {})["mock_credentials"] = True
        ux_config = config.get("features", {}).get("user_experience", {})
        parallel_config = config.get("execution", {}).get("parallel", {})
        parallel_enabled = bool(parallel_config.get("enabled", False))
        if parallel and not parallel_enabled:
            print_warning(
                "Parallel execution is disabled by config (execution.parallel.enabled: false)."
            )
            parallel = False
            if "parallel" in bypass_modes:
                bypass_modes.remove("parallel")
        elif parallel and parallel_enabled:
            os.environ["OBRA_PARALLEL_EXECUTION"] = "1"
            os.environ["OBRA_PARALLEL_MAX_WORKERS"] = str(parallel_config.get("max_workers", 4))
        dashboard_config = ux_config.get("dashboard", {})
        ux_enabled = bool(ux_config.get("enabled", True))
        dashboard_enabled = bool(dashboard_config.get("enabled", True)) and ux_enabled
        footer_hint_enabled = bool(dashboard_config.get("footer_hint", True))
        task_tracker_enabled = bool(dashboard_config.get("task_tracker", True))
        task_tracker_max_next = dashboard_config.get("task_tracker_max_next", 3)
        if not isinstance(task_tracker_max_next, int):
            try:
                task_tracker_max_next = int(task_tracker_max_next)
            except (TypeError, ValueError):
                task_tracker_max_next = 3

        # Create observability configuration from CLI flags
        obs_config = ObservabilityConfig(
            verbosity=verbose,
            stream=stream,
            timestamps=True,
            dashboard_enabled=dashboard_enabled,
            footer_hint_enabled=footer_hint_enabled,
            task_tracker_enabled=task_tracker_enabled,
            task_tracker_max_next=task_tracker_max_next,
        )
        set_runtime_verbosity(verbose)

        # Create progress emitter for observability
        progress_emitter = ProgressEmitter(obs_config, console)
        progress_json_value = bool(locals().get("progress_json", False))

        # Create orchestrator with progress callback
        def on_progress(action: str, payload: dict) -> None:
            """Progress callback that routes events to ProgressEmitter.

            Args:
                action: Event type (e.g., 'phase_started', 'llm_streaming')
                payload: Event data dict
            """
            _route_progress_event(
                progress_emitter,
                console,
                verbose,
                action,
                payload,
                progress_json=progress_json_value,
            )

        # ISSUE-STREAM-001: Create on_stream callback for real-time LLM output streaming
        # Handlers call on_stream(event_type, chunk) directly, separate from on_progress
        def on_stream(event_type: str, chunk: str) -> None:
            """Stream callback for real-time LLM output.

            Args:
                event_type: Event type (e.g., 'llm_streaming')
                chunk: Text chunk from streaming LLM response
            """
            if event_type == "llm_streaming":
                progress_emitter.llm_streaming(chunk)
        on_escalation = _build_escalation_callback()

        # S5.T1/T2: Pass LLM overrides to orchestrator
        # S2.T4/S3.T2: Pass observability config for heartbeat and progress visibility
        # GIT-HARD-001: Pass git CLI flags to override config
        # ISSUE-STREAM-001: Pass on_stream callback for real-time LLM output
        # FEAT-COMPLEXITY-ROUTING-001: Pass planning mode for complexity routing
        orchestrator = HybridOrchestrator.from_config(
            working_dir=work_dir,
            on_progress=on_progress,
            on_escalation=on_escalation,
            on_stream=on_stream if stream else None,
            impl_provider=effective_provider,
            impl_model=effective_model,
            thinking_level=effective_thinking,
            review_config=review_config,
            bypass_modes=bypass_modes,
            defaults_json=defaults_json,
            observability_config=obs_config,
            progress_emitter=progress_emitter,
            skip_git_check=skip_git_check if skip_git_check else None,
            auto_init_git=auto_init_git if auto_init_git else None,
            planning_mode=plan_mode,
        )
        if story0_override_config is not None:
            orchestrator._config = story0_override_config

        # Pass pre-session context for post-session LLM Pipeline Models banner
        orchestrator._cli_preflight_results = preflight_results
        orchestrator._cli_effective_map = effective_map
        orchestrator._cli_verbose = verbose

        # Store orchestrator reference so interrupt handler can get session_id
        _interrupt_state["orchestrator"] = orchestrator

        # Run derive workflow
        # Set session_id early so Ctrl+C shows meaningful ID (updated after derive completes)
        _interrupt_state["session_id"] = resume_session or "<pending>"
        try:
            with defer_interrupts():
                if resume_session:
                    result = orchestrator.resume(resume_session)
                else:
                    # At this point, objective must be non-None (validated at line 3024)
                    assert objective is not None, "objective required for derive"
                    result = orchestrator.derive(
                        objective,
                        plan_id=effective_plan_id,
                        plan_only=plan_only,
                        project_id=project_id,
                        bypass_modes=bypass_modes,
                        skip_completed_items=skip_completed_items,
                        userplan_id=userplan_id,
                        from_step=from_step,
                        work_type=work_type,
                    )
                # Get session_id after derive/resume (works for both paths)
                session_id = orchestrator.session_id
                if session_id:
                    progress_emitter.set_session_id(session_id)
                    _interrupt_state["session_id"] = session_id
                    # Rename session log to use actual session_id
                    rename_session_logging(session_id)
        except GracefulInterrupt:
            session_id = orchestrator.session_id
            hint_session_id = _interrupt_state.get("recovery_hint_session_id")
            suppress_interrupt_hint = bool(_interrupt_state.get("recovery_hint_printed")) and bool(
                hint_session_id
            ) and (not session_id or str(hint_session_id) == str(session_id))
            # Build interrupted closeout message
            closeout_ctx = CloseoutContext(
                state=TerminationState.INTERRUPTED,
                session_id=session_id or "",
                objective=objective or continue_from_objective or "",
                suppress_interrupt_hint=suppress_interrupt_hint,
            )
            build_closeout_message(closeout_ctx, console, verbosity=verbose)
            raise typer.Exit(130) from None
        finally:
            clear_interrupt_request()

        # Display result
        console.print()
        action = getattr(result, "action", None)
        # ISSUE-SAAS-050: Track items_completed to validate success and set exit code
        items_completed = 0
        if action == "complete" or action is None:
            (
                items_completed,
                total_iterations,
                quality_score,
                was_escalated,
                terminal_phase,
            ) = _extract_completion_context(result)

            # Terse completion footer for LLM handoff (git file status)
            _print_git_file_summary(console, str(work_dir))

            # Build and display closeout message using the new closeout builder
            closeout_ctx = _build_closeout_context(
                result,
                session_id=session_id,
                objective=objective or continue_from_objective or "",
            )
            build_closeout_message(closeout_ctx, console, verbosity=verbose)

            if was_escalated:
                raise typer.Exit(1)

            # ISSUE-SAAS-050: Exit with error code if no items succeeded
            if items_completed == 0:
                _offer_bug_report(
                    context="orchestration",
                    command_used="obra derive",
                    objective=objective,
                    failure_reason="0 items completed successfully",
                    auto_report=auto_report,
                    orchestrator=orchestrator,
                )
                raise typer.Exit(1)

        elif action == "escalate":
            print_warning("Session requires user decision")
            console.print("\nRun 'obra status' to see details and respond.")
            # Escalation is not a success - exit with error
            raise typer.Exit(1)
        else:
            console.print(f"Session state: {action}")

    # S3.T3: Consistent exit codes - config=2, connection=3, execution=1
    except typer.Exit:
        raise
    except ConfigurationError as e:
        if progress_emitter:
            progress_emitter.halt_spinner()
        display_obra_error(e, console)
        logger.error(f"Configuration error in derive command: {e}", exc_info=True)
        raise typer.Exit(2) from e
    except ObraConnectionError as e:
        if progress_emitter:
            progress_emitter.halt_spinner()
        display_obra_error(e, console)
        _print_session_resume_hints()
        logger.error(f"Connection error in derive command: {e}", exc_info=True)
        raise typer.Exit(3) from e
    except APIError as e:
        if progress_emitter:
            progress_emitter.halt_spinner()
        display_obra_error(e, console)
        _print_session_resume_hints()
        logger.error(f"API error in derive command: {e}", exc_info=True)
        _offer_bug_report(
            e,
            context="orchestration",
            command_used="obra derive",
            objective=objective,
            auto_report=auto_report,
            orchestrator=orchestrator,
        )
        raise typer.Exit(1) from e
    except ObraError as e:
        if progress_emitter:
            progress_emitter.halt_spinner()
        display_obra_error(e, console)
        _print_session_resume_hints()
        logger.error(f"Obra error in derive command: {e}", exc_info=True)
        _offer_bug_report(
            e,
            context="orchestration",
            command_used="obra derive",
            objective=objective,
            auto_report=auto_report,
            orchestrator=orchestrator,
        )
        raise typer.Exit(1) from e
    except Exception as e:
        if progress_emitter:
            progress_emitter.halt_spinner()
        display_error(e, console)
        _print_session_resume_hints()
        logger.exception(f"Unexpected error in derive command: {e}")
        _offer_bug_report(
            e,
            context="orchestration",
            command_used="obra derive",
            objective=objective,
            auto_report=auto_report,
            orchestrator=orchestrator,
        )
        raise typer.Exit(1) from e


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
@require_terms_accepted
def status(
    ctx: typer.Context,
    session_id: str | None = typer.Argument(
        None,
        help="Session ID to check (defaults to most recent)",
    ),
    verbose: int = typer.Option(
        0,
        "--verbose",
        "-v",
        count=True,
        max=3,
        help="Verbosity level (0-3, use -v/-vv/-vvv)",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON (Tier 1: machine-readable format for LLM operators)",
    ),
    show_tasks: bool = typer.Option(
        False,
        "--tasks",
        "-t",
        help="Show inline task progress from the execution plan",
    ),
) -> None:
    """Check the status of a derivation session.

    Shows the current state of the session including:
    - Session phase (derive, examine, revise, execute, review)
    - Iteration count
    - Quality metrics
    - Any pending user decisions

    Examples:
        $ obra status
        $ obra status abc123
        $ obra status -v
        $ obra status -vv  # More detail
        $ obra status --tasks  # Include task progress
    """
    verbose = _resolve_command_verbosity(ctx, verbose)
    setup_logging(verbose)

    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        # Get API client
        client = APIClient.from_config()

        # Get session status
        if session_id:
            session = client.get_session(session_id)
        else:
            # Get most recent session
            sessions = client.list_sessions(limit=1)
            if not sessions:
                print_info("No active sessions found")
                console.print("\nRun 'obra run \"objective\"' to start a new session.")
                return
            session = sessions[0]

        # Extract resume context for can_resume status
        resume_context = session.get("resume_context", {})
        can_resume = resume_context.get("can_resume", False)

        # Extract escalation_reason if present
        escalation_reason = session.get("escalation_reason")

        # Fetch task progress (always, not just with --tasks)
        session_id_for_plan = session.get("session_id", session_id)
        total_tasks = 0
        completed_tasks = 0
        plan_items = []
        tasks_error = None
        if session_id_for_plan:
            try:
                plan_data = client.get_session_plan(session_id_for_plan)
                plan_items = plan_data.get("plan_items", [])
                total_tasks = plan_data.get("total_count", len(plan_items))
                completed_tasks = plan_data.get("completed_count", 0)
            except APIError:
                tasks_error = "Could not fetch task progress"

        # Tier 1: JSON output for machine-readable format
        if json_output:
            import json

            output = {
                "session_id": session.get("session_id"),
                "objective": session.get("objective"),
                "status": session.get("status"),
                "phase": session.get("current_phase"),
                "iteration": session.get("iteration", 0),
                "created_at": session.get("created_at"),
                "updated_at": session.get("updated_at"),
                "project_id": session.get("project_id"),
                "project_name": session.get("project_name"),
                # Session resume/recovery fields
                "can_resume": can_resume,
                "escalation_reason": escalation_reason,
                # Progress fields
                "completed_tasks": completed_tasks,
                "total_tasks": total_tasks,
            }
            # Add optional fields if present
            if "quality_scorecard" in session:
                output["quality_scorecard"] = session["quality_scorecard"]
            if "pending_escalation" in session:
                output["pending_escalation"] = session["pending_escalation"]

            # Add prompt file stats (local filesystem info)
            working_dir = Path.cwd()
            prompts_dir = working_dir / ".obra" / "prompts"
            if prompts_dir.exists():
                prompt_files = list(prompts_dir.rglob(".obra-prompt-*.txt"))
                if prompt_files:
                    prompt_size_bytes = sum(f.stat().st_size for f in prompt_files)
                    output["prompt_files"] = {
                        "count": len(prompt_files),
                        "size_bytes": prompt_size_bytes,
                    }

            # Add plan items detail if --tasks requested
            if show_tasks:
                if tasks_error:
                    output["plan_items"] = None
                    output["tasks_error"] = tasks_error
                else:
                    output["plan_items"] = plan_items

            # Add recovery suggestion for non-resumable sessions
            if not can_resume and session.get("status") in ("escalated", "completed"):
                output["recovery_command"] = (
                    f"obra run --continue-from {session.get('session_id', '')[:8]}"
                )

            print(json.dumps(output, indent=2))
            return

        # Display session status
        console.print()
        console.print("[bold]Session Status[/bold]", style="cyan")
        console.print()

        table = Table(show_header=False, box=None)
        table.add_column("Field", style="dim")
        table.add_column("Value")

        table.add_row("Session ID", session.get("session_id", "N/A"))
        table.add_row("Objective", session.get("objective", "N/A"))

        # Status with visual indicator
        status = session.get("status", "N/A")
        if status == "active":
            status_display = f"[green]{status}[/green]"
        elif status == "completed":
            status_display = f"[blue]{status}[/blue]"
        elif status == "escalated":
            status_display = f"[yellow]{status}[/yellow]"
        else:
            status_display = f"[dim]{status}[/dim]"
        table.add_row("Status", status_display)

        table.add_row("Phase", session.get("current_phase", "N/A"))

        # Progress summary
        if total_tasks > 0:
            progress_display = f"{completed_tasks}/{total_tasks} tasks"
            if completed_tasks == total_tasks:
                progress_display = f"[green]{progress_display}[/green]"
            elif completed_tasks > 0:
                progress_display = f"[yellow]{progress_display}[/yellow]"
            table.add_row("Progress", progress_display)
        elif tasks_error:
            table.add_row("Progress", f"[dim]{tasks_error}[/dim]")

        # Resumable status
        if can_resume:
            table.add_row("Resumable", "[green]Yes[/green]")
        else:
            table.add_row("Resumable", "[red]No[/red]")

        # Escalation reason (if present)
        if escalation_reason:
            table.add_row("Failure Reason", f"[yellow]{escalation_reason}[/yellow]")

        table.add_row("Iteration", str(session.get("iteration", 0)))
        table.add_row("Created", session.get("created_at", "N/A"))
        table.add_row("Updated", session.get("updated_at", "N/A"))

        if verbose > 0:
            table.add_row("Project ID", session.get("project_id", "N/A"))
            if session.get("project_name"):
                table.add_row("Project", session.get("project_name", "N/A"))

        # Prompt file stats (local filesystem info)
        working_dir = Path.cwd()
        prompts_dir = working_dir / ".obra" / "prompts"
        if prompts_dir.exists():
            prompt_files = list(prompts_dir.rglob(".obra-prompt-*.txt"))
            if prompt_files:
                prompt_size_kb = sum(f.stat().st_size for f in prompt_files) / KIBIBYTE
                table.add_row("Prompt files", f"{len(prompt_files)} ({prompt_size_kb:.1f} KB)")

        console.print(table)

        # Show recovery suggestion for non-resumable sessions
        if not can_resume and status in ("escalated", "completed") and total_tasks > 0:
            console.print()
            console.print("[dim]Session cannot be resumed. To continue from checkpoint:[/dim]")
            console.print(f"  obra run --continue-from {session.get('session_id', '')[:8]}")

        # Show task detail table if requested (uses already-fetched plan data)
        if show_tasks:
            if plan_items:
                console.print()
                console.print("[bold]Task Progress[/bold]", style="cyan")
                console.print(f"[dim]{completed_tasks}/{total_tasks} tasks completed[/dim]")
                console.print()

                task_table = Table(show_header=True, header_style="bold")
                task_table.add_column("#", style="dim", width=3)
                task_table.add_column("Status", width=3)
                task_table.add_column("Task")

                for item in plan_items:
                    order = str(item.get("order", ""))
                    task_status = item.get("status", "pending")
                    title = item.get("title", "Untitled task")

                    # Status indicator with color
                    if task_status == "completed":
                        status_indicator = f"[green]{glyphs.success}[/green]"
                    elif task_status == "in_progress":
                        status_indicator = f"[yellow]{glyphs.paused}[/yellow]"
                    elif task_status == "failed":
                        status_indicator = f"[red]{glyphs.failure}[/red]"
                    else:  # pending
                        status_indicator = "[dim]o[/dim]"

                    task_table.add_row(order, status_indicator, title)

                console.print(task_table)
            elif tasks_error:
                console.print()
                console.print(f"[dim]{tasks_error}[/dim]")
            else:
                console.print()
                console.print("[dim]No plan items found for this session[/dim]")

        # Show quality metrics if available
        if verbose > 0 and "quality_scorecard" in session:
            scorecard = session["quality_scorecard"]
            console.print()
            console.print("[bold]Quality Scorecard[/bold]", style="cyan")

            score_table = Table()
            score_table.add_column("Dimension", style="cyan")
            score_table.add_column("Score")

            for dim, score in scorecard.items():
                score_table.add_row(dim, f"{score:.2f}" if isinstance(score, float) else str(score))

            console.print(score_table)

        # Show pending escalation if any
        if session.get("pending_escalation"):
            console.print()
            print_warning("Pending escalation requires your decision")
            escalation = session["pending_escalation"]
            console.print(f"Reason: {escalation.get('reason', 'N/A')}")
            console.print("\nOptions:")
            for opt in escalation.get("options", []):
                console.print(
                    f"  - {opt.get('id')}: {opt.get('label')} - {opt.get('description', '')}"
                )

        # Show state-based next steps
        state = session.get("state", "").lower()
        session_id_value = session.get("session_id", "")

        console.print()
        console.print("[bold]Next Steps[/bold]", style="cyan")

        if state == "completed":
            console.print(f"  {glyphs.success} This session is complete")
            console.print()
            console.print("  To start new work:")
            console.print('    [cyan]obra run "your task description"[/cyan]')
        elif state in {"paused", "waiting"}:
            progress = session.get("progress", "")
            console.print(f"  {glyphs.paused} Session paused ({progress})")
            console.print()
            console.print("  To resume execution:")
            console.print(f"    [cyan]obra run --resume {session_id_value}[/cyan]")
        elif state in {"failed", "error"}:
            console.print(f"  {glyphs.failure} Session encountered an error")
            console.print()
            console.print("  To view error details:")
            console.print(f"    [cyan]obra status {session_id_value} -vv[/cyan]")
            console.print()
            console.print("  To start a new session:")
            console.print('    [cyan]obra run "your task description"[/cyan]')
        elif state in {"running", "active"}:
            console.print("  ⚙️  Session is currently running")
            console.print()
            console.print("  To monitor progress:")
            console.print(f"    [cyan]obra status {session_id_value}[/cyan]")
        else:
            # Unknown or other states
            console.print("  To resume this session:")
            console.print(f"    [cyan]obra run --resume {session_id_value}[/cyan]")
            console.print()
            console.print("  To check detailed status:")
            console.print(f"    [cyan]obra status {session_id_value} -vv[/cyan]")

        # AI assistant nudge
        console.print()
        console.print("[dim]💡 Using an AI assistant? Run: [/dim][cyan]obra briefing[/cyan]")

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in status command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in status command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in status command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in status command: {e}")
        _print_bug_hint()
        raise typer.Exit(1) from e


# =============================================================================
# Sessions Management
# =============================================================================

sessions_app = typer.Typer(help="Manage derivation sessions")
app.add_typer(sessions_app, name="sessions")


@sessions_app.command("list")
@handle_encoding_errors
def sessions_list(
    limit: int = typer.Option(
        10,
        "--limit",
        "-n",
        help="Maximum number of sessions to list",
    ),
    status_filter: str | None = typer.Option(
        None,
        "--status",
        "-s",
        help="Filter by status (active, completed, expired)",
    ),
) -> None:
    """List recent derivation sessions.

    Displays all sessions for the current user, ordered by
    creation time (most recent first).

    Examples:
        $ obra sessions list
        $ obra sessions list --limit 20
        $ obra sessions list --status active
    """
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        # Get sessions from server
        client = APIClient.from_config()
        sessions = client.list_sessions(limit=limit, status=status_filter)

        console.print()
        if not sessions:
            print_info("No sessions found")
            console.print('\nStart a new session with: [cyan]obra run "your objective"[/cyan]')
            return

        console.print(f"[bold]Recent Sessions[/bold] ({len(sessions)} shown)", style="cyan")
        console.print()

        table = Table()
        table.add_column("Session ID", style="cyan")
        table.add_column("Status", style="bold")
        table.add_column("Project")
        table.add_column("Project ID")
        table.add_column("Phase")
        table.add_column("Created", style="dim")

        for session in sessions:
            session_id_short = session.get("session_id", "")[:12] + "..."
            status = session.get("status", "unknown")
            phase = session.get("phase", "N/A")
            created_at = session.get("created_at", "N/A")
            project_name = session.get("project_name", "")
            project_id = str(session.get("project_id", ""))

            # Format timestamp if it's ISO format
            if "T" in str(created_at):
                from datetime import datetime

                try:
                    dt = datetime.fromisoformat(str(created_at).replace("Z", "+00:00"))
                    created_at = dt.strftime("%Y-%m-%d %H:%M")
                except (ValueError, TypeError):
                    pass

            # Color-code status
            if status == "active":
                status = f"[green]{status}[/green]"
            elif status == "completed":
                status = f"[blue]{status}[/blue]"
            elif status == "expired":
                status = f"[dim]{status}[/dim]"

            table.add_row(session_id_short, status, project_name, project_id, phase, created_at)

        console.print(table)
        console.print()
        console.print("[dim]Check details:[/dim] [cyan]obra status <session_id>[/cyan]")
        console.print("[dim]Resume:[/dim] [cyan]obra run --resume <session_id>[/cyan]")

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in sessions list command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in sessions list command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in sessions list command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in sessions list command: {e}")
        _print_bug_hint()
        raise typer.Exit(1) from e


@sessions_app.command("cancel")
@handle_encoding_errors
def sessions_cancel(
    session_id: str = typer.Argument(
        ...,
        help="Session ID to cancel",
    ),
) -> None:
    """Cancel a derivation session.

    Cancels a session by setting its status to 'abandoned'. This is useful for
    cleaning up sessions that are no longer needed or were started in error.

    Cancellation is idempotent - cancelling an already-cancelled session succeeds.

    Examples:
        $ obra sessions cancel abc123...
        $ obra sessions cancel $(obra sessions list --limit 1 | awk 'NR==4 {print $1}')

    Note:
        You can only cancel sessions you own. Attempting to cancel another
        user's session will result in a permission error.
    """
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        # Cancel the session
        client = APIClient.from_config()
        response = client.cancel_session(session_id)

        # Display success message
        if response.get("success"):
            print_success(f"Session cancelled: {session_id}")
            console.print(
                f"\n[dim]{response.get('message', 'Session status set to abandoned')}[/dim]"
            )
        else:
            print_error("Failed to cancel session")
            console.print(f"\n[dim]{response.get('message', 'Unknown error occurred')}[/dim]")
            raise typer.Exit(1)

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in sessions cancel command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in sessions cancel command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in sessions cancel command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in sessions cancel command: {e}")
        _print_bug_hint()
        raise typer.Exit(1) from e


@sessions_app.command("repair")
@handle_encoding_errors
def sessions_repair(
    session_id: str = typer.Argument(
        ...,
        help="Session ID to repair",
    ),
) -> None:
    """Repair a stuck session by auto-detecting and fixing common issues.

    Auto-detects and repairs common session issues without manual intervention.
    Safe to run multiple times - if no issues are found, no changes are made.

    Repairs Supported:
        - missing_item_id: Recovers missing item_id from execution results
        - stuck_wait_state: Advances phase when stuck in WAIT status
        - inconsistent_status: Reconciles status/phase mismatches

    Examples:
        $ obra sessions repair abc123
        $ obra sessions repair $(obra status --format json | jq -r '.session_id')

    Notes:
        - Safe to run multiple times (idempotent)
        - Only repairs sessions you own
        - Use after encountering 500 errors or stuck sessions
    """
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        # Repair the session
        client = APIClient.from_config()
        response = client.repair_session(session_id)

        # Display results
        if response.get("success"):
            repairs_applied = response.get("repairs_applied", [])
            if repairs_applied:
                print_success(f"Session repaired: {session_id}")
                console.print(f"\n[bold]Repairs applied ({len(repairs_applied)}):[/bold]")
                for repair in repairs_applied:
                    field = repair.get("field", "unknown")
                    action = repair.get("action", "unknown")
                    console.print(f"  • {field}: {action}")
            else:
                print_info(f"No issues found in session: {session_id}")
                console.print("\n[dim]Session state is consistent.[/dim]")
        else:
            print_error("Failed to repair session")
            console.print(f"\n[dim]{response.get('message', 'Unknown error occurred')}[/dim]")
            raise typer.Exit(1)

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in sessions repair command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in sessions repair command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in sessions repair command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in sessions repair command: {e}")
        _print_bug_hint()
        raise typer.Exit(1) from e


@sessions_app.command("force-complete")
@handle_encoding_errors
def sessions_force_complete(
    session_id: str = typer.Argument(
        ...,
        help="Session ID to force-complete",
    ),
    reason: str = typer.Option(
        None,
        "--reason",
        "-r",
        help="Reason for force completion (for audit trail)",
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip confirmation prompt",
    ),
) -> None:
    """Force-complete a session regardless of current phase.

    Marks the session as COMPLETED and preserves all execution results.
    Use this for stuck sessions that have completed work but cannot progress.

    This command will prompt for confirmation if the session has incomplete work,
    unless --yes is specified.

    Examples:
        $ obra sessions force-complete abc123
        $ obra sessions force-complete abc123 --reason "LLM timeout, work complete"
        $ obra sessions force-complete abc123 --yes

    Notes:
        - Preserves all execution results
        - Only force-completes sessions you own
        - Use after work is complete but session cannot progress
    """
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        client = APIClient.from_config()

        # Check for confirmation if not --yes
        if not yes:
            # Get session status first to check for incomplete work
            try:
                session_data = client.get_session(session_id)
            except APIError:
                # Session not found or access denied - let the force_complete call handle it
                session_data = None

            if session_data:
                phase = session_data.get("phase", "UNKNOWN")
                status = session_data.get("status", "UNKNOWN")

                # Check for incomplete work indicators
                incomplete_work = False
                if phase not in ["COMPLETED", "FORCE_COMPLETED"]:
                    incomplete_work = True

                if incomplete_work:
                    console.print(
                        f"\n[yellow]Warning:[/yellow] Session is in {phase} phase with status {status}"
                    )
                    console.print("This may indicate incomplete work.\n")

                    if not typer.confirm(
                        get_message("prompt.confirm.force_complete"), default=False
                    ):
                        print_info("Cancelled")
                        raise typer.Exit(0)

        # Force-complete the session
        response = client.force_complete_session(session_id, reason=reason)

        # Display results
        if response.get("success"):
            print_success(f"Session force-completed: {session_id}")

            preserved_results = response.get("preserved_results", 0)
            console.print(f"\n[bold]Preserved results:[/bold] {preserved_results}")

            warnings = response.get("warnings", [])
            if warnings:
                console.print("\n[bold yellow]Warnings:[/bold yellow]")
                for warning in warnings:
                    console.print(f"  • {warning}")

            if reason:
                console.print(f"\n[dim]Reason: {reason}[/dim]")
        else:
            print_error("Failed to force-complete session")
            console.print(f"\n[dim]{response.get('message', 'Unknown error occurred')}[/dim]")
            raise typer.Exit(1)

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in sessions force-complete command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(
            f"Configuration error in sessions force-complete command: {e}",
            exc_info=True,
        )
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in sessions force-complete command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in sessions force-complete command: {e}")
        _print_bug_hint()
        raise typer.Exit(1) from e


@sessions_app.command("reset-review")
@handle_encoding_errors
def sessions_reset_review(
    session_id: str = typer.Argument(
        ...,
        help="Session ID to reset review for",
    ),
) -> None:
    """Reset a session's review state and return to execution phase.

    Clears review results for the current item and resets the session phase
    to EXECUTION, allowing the item to be re-executed. Useful when review
    keeps failing or incorrect review results need to be discarded.

    Examples:
        $ obra sessions reset-review abc123
        $ obra sessions reset-review $(obra status --format json | jq -r '.session_id')

    Notes:
        - Only resets sessions in REVIEW or FIX phase
        - For sessions not in review, this is a no-op
        - Only affects sessions you own
    """
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        # Reset review for the session
        client = APIClient.from_config()
        response = client.reset_review(session_id)

        # Display results
        if response.get("success"):
            item_id = response.get("item_id")
            if item_id:
                # Session was in review phase and was reset
                print_success(f"Review reset for item {item_id}")
                console.print(f"\n[bold]Session:[/bold] {session_id}")
                console.print(
                    f"[bold]Previous phase:[/bold] {response.get('previous_phase', 'UNKNOWN')}"
                )
                console.print("\n[dim]Session is ready to re-execute the item.[/dim]")
            else:
                # Session not in review phase
                print_info(f"Session not in review phase: {session_id}")
                console.print(
                    "\n[dim]No reset needed - session is not in REVIEW or FIX phase.[/dim]"
                )
        else:
            print_error("Failed to reset review")
            console.print(f"\n[dim]{response.get('message', 'Unknown error occurred')}[/dim]")
            raise typer.Exit(1)

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in sessions reset-review command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in sessions reset-review command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in sessions reset-review command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in sessions reset-review command: {e}")
        _print_bug_hint()
        raise typer.Exit(1) from e


@sessions_app.command("plan")
@handle_encoding_errors
def sessions_plan(
    session_id: str | None = typer.Argument(
        None,
        help="Session ID (full UUID or short prefix). Defaults to most recent session.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON (machine-readable format for LLM operators)",
    ),
) -> None:
    """View the DerivedPlan for a session.

    Displays the DerivedPlan items derived by Obra for a session, including
    the completion status of each task. This helps you understand
    what Obra planned to do and track progress.

    Status indicators:
        ✓  completed - Task finished successfully
        ⏳  in_progress - Task currently running
        ○  pending - Task not yet started
        ✗  failed - Task failed

    Examples:
        $ obra sessions plan                    # Show DerivedPlan for most recent session
        $ obra sessions plan abc123             # Use short session ID
        $ obra sessions plan abc123-def456...   # Use full session ID
        $ obra sessions plan --json             # JSON output for scripting
    """
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        client = APIClient.from_config()

        # If no session ID provided, use most recent session
        if session_id is None:
            sessions = client.list_sessions(limit=1)
            if not sessions:
                if json_output:
                    import json

                    print(json.dumps({"error": "No sessions found", "plan_items": []}))
                else:
                    print_info("No sessions found")
                    console.print(
                        '\nStart a new session with: [cyan]obra run "your objective"[/cyan]'
                    )
                return
            session_id = sessions[0].get("session_id", "")
            if not json_output:
                console.print(f"[dim]Using most recent session: {session_id[:12]}...[/dim]")
                console.print()

        # Get plan from server
        plan_data = client.get_session_plan(session_id)

        plan_items = plan_data.get("plan_items", [])
        objective = plan_data.get("objective", "")
        total_count = plan_data.get("total", len(plan_items))
        completed_count = plan_data.get("completed", 0)
        full_session_id = plan_data.get("session_id", session_id)

        # JSON output for LLM operators
        if json_output:
            import json

            plan_tree = _build_plan_tree_snapshot(plan_items, objective)
            output = {
                "session_id": full_session_id,
                "objective": objective,
                "total_count": total_count,
                "completed_count": completed_count,
                "plan_items": plan_items,
                "plan_tree": plan_tree,
            }
            print(json.dumps(output, indent=2))
            return

        console.print()

        if not plan_items:
            print_info("No DerivedPlan items found for this session")
            console.print(
                "\n[dim]The session may not have derived a DerivedPlan yet, or it uses direct execution.[/dim]"
            )
            return

        # Display header
        console.print("[bold cyan]DerivedPlan[/bold cyan]")
        if objective:
            console.print(f"[dim]Objective:[/dim] {objective}")
        console.print(f"[dim]Session:[/dim] {full_session_id[:12]}...")
        console.print(
            f"[dim]Progress:[/dim] {completed_count}/{total_count} DerivedPlan tasks completed"
        )
        console.print()

        _render_plan_tree(console, plan_items, objective)

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in sessions plan command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in sessions plan command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in sessions plan command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in sessions plan command: {e}")
        raise typer.Exit(1) from e


def _build_plan_tree_snapshot(
    plan_items: list[dict[str, Any]],
    objective: str,
) -> dict[str, Any]:
    """Build a hierarchical DerivedPlan tree snapshot from flat plan items."""
    normalized, children_map, status_map, _order_map = _normalize_plan_items(plan_items)
    roots = _get_root_items(normalized, children_map)
    tree_nodes = [
        _build_tree_node(node_id, normalized, children_map, status_map) for node_id in roots
    ]
    return {
        "objective": objective,
        "roots": tree_nodes,
        "count": len(normalized),
    }


def _build_tree_node(
    item_id: str,
    normalized: dict[str, dict[str, Any]],
    children_map: dict[str | None, list[str]],
    status_map: dict[str, str],
) -> dict[str, Any]:
    item = normalized.get(item_id, {})
    children = children_map.get(item_id, [])
    return {
        "id": item_id,
        "title": item.get("title", "Untitled"),
        "item_type": item.get("item_type", "task"),
        "status": _aggregate_status(item_id, children_map, status_map),
        "children": [
            _build_tree_node(child_id, normalized, children_map, status_map)
            for child_id in children
        ],
    }


def _render_plan_tree(
    console: Console,
    plan_items: list[dict[str, Any]],
    objective: str,
) -> None:
    """Render a hierarchical DerivedPlan tree with status indicators."""
    normalized, children_map, status_map, order_map = _normalize_plan_items(plan_items)
    if not normalized:
        print_info("No DerivedPlan items found for this session")
        return

    roots = _get_root_items(normalized, children_map)
    if not roots:
        print_info("No DerivedPlan roots found for this session")
        return

    console.print("[bold]DerivedPlan Tree[/bold]")
    if objective:
        console.print(f"[dim]{objective}[/dim]")
    console.print()

    for root_id in roots:
        _render_plan_node(
            console,
            root_id,
            normalized,
            children_map,
            status_map,
            order_map,
            level=0,
        )
    console.print()


def _render_plan_node(
    console: Console,
    item_id: str,
    normalized: dict[str, dict[str, Any]],
    children_map: dict[str | None, list[str]],
    status_map: dict[str, str],
    order_map: dict[str, int],
    *,
    level: int,
) -> None:
    item = normalized.get(item_id, {})
    title = item.get("title", "Untitled")
    item_type = item.get("item_type", "task").upper()
    status = _aggregate_status(item_id, children_map, status_map)
    status_indicator = _format_status_indicator(status)
    indent = "  " * level
    console.print(f"{indent}{status_indicator} {item_id} {item_type}: {title}", style="dim")

    children = sorted(children_map.get(item_id, []), key=lambda cid: order_map.get(cid, 1_000_000))
    for child_id in children:
        _render_plan_node(
            console,
            child_id,
            normalized,
            children_map,
            status_map,
            order_map,
            level=level + 1,
        )


def _aggregate_status(
    item_id: str,
    children_map: dict[str | None, list[str]],
    status_map: dict[str, str],
) -> str:
    children = children_map.get(item_id, [])
    if not children:
        return status_map.get(item_id, "pending")
    child_statuses = [
        _aggregate_status(child_id, children_map, status_map) for child_id in children
    ]
    if any(status == "failed" for status in child_statuses):
        return "failed"
    if any(status == "in_progress" for status in child_statuses):
        return "in_progress"
    if all(status in {"completed", "skipped"} for status in child_statuses):
        return "completed"
    return "pending"


def _format_status_indicator(status: str) -> str:
    if status == "completed":
        return f"[green]{glyphs.success}[/green]"
    if status == "in_progress":
        return f"[yellow]{glyphs.paused}[/yellow]"
    if status == "failed":
        return f"[red]{glyphs.failure}[/red]"
    if status == "skipped":
        return "[dim]skip[/dim]"
    return "[dim]o[/dim]"


def _normalize_plan_items(
    plan_items: list[dict[str, Any]],
) -> tuple[
    dict[str, dict[str, Any]],
    dict[str | None, list[str]],
    dict[str, str],
    dict[str, int],
]:
    normalized: dict[str, dict[str, Any]] = {}
    children_map: dict[str | None, list[str]] = {}
    status_map: dict[str, str] = {}
    order_map: dict[str, int] = {}

    for item in plan_items:
        item_id = str(item.get("item_id") or item.get("id") or "").strip()
        if not item_id:
            continue
        title = str(item.get("title") or item.get("description") or "Untitled").strip()
        item_type = str(item.get("item_type") or "").strip().lower()
        if not item_type:
            item_type = _infer_item_type(item_id)
        parent_id = item.get("parent_id")
        parent_id = str(parent_id).strip() if parent_id else None
        status = _normalize_status(str(item.get("status", "")).strip())
        order_value = item.get("order")
        try:
            order = int(order_value) if order_value is not None else 1_000_000
        except (TypeError, ValueError):
            order = 1_000_000

        normalized[item_id] = {
            "id": item_id,
            "title": title,
            "item_type": item_type,
            "parent_id": parent_id,
            "status": status,
            "description": item.get("description", ""),
            "acceptance_criteria": item.get("acceptance_criteria", []),
        }
        status_map[item_id] = status
        order_map[item_id] = order

    parent_defaults = _infer_parent_ids(normalized)
    for item_id, parent_id in parent_defaults.items():
        normalized[item_id]["parent_id"] = parent_id

    for item_id, item in normalized.items():
        parent_id = item.get("parent_id") or None
        children_map.setdefault(parent_id, []).append(item_id)

    return normalized, children_map, status_map, order_map


def _infer_item_type(item_id: str) -> str:
    if item_id.startswith("E"):
        return "epic"
    if item_id.startswith("S") and ".T" not in item_id:
        return "story"
    if ".T" in item_id:
        # Subtask has 2+ dots (e.g., S1.T1.1) - hierarchy parsing protocol constant
        if item_id.count(".") >= 2:
            return "subtask"
        return "task"
    return "task"


def _infer_parent_ids(
    normalized: dict[str, dict[str, Any]],
) -> dict[str, str | None]:
    parent_map: dict[str, str | None] = {}
    epic_ids = [item_id for item_id, item in normalized.items() if item.get("item_type") == "epic"]
    default_epic_id = epic_ids[0] if len(epic_ids) == 1 else None

    for item_id, item in normalized.items():
        if item.get("parent_id"):
            continue
        item_type = item.get("item_type")
        parent_id = None

        if item_type == "subtask":
            parts = item_id.split(".")
            # Subtask format: S1.T1.1 (3 parts) - hierarchy parsing protocol constant
            if len(parts) >= 3:
                parent_id = ".".join(parts[:2])
        elif item_type == "task":
            if ".T" in item_id:
                parent_id = item_id.split(".T")[0]
        elif item_type == "story":
            if default_epic_id:
                parent_id = default_epic_id

        if parent_id and parent_id in normalized:
            parent_map[item_id] = parent_id
        else:
            parent_map[item_id] = None

    return parent_map


def _normalize_status(status: str) -> str:
    normalized = status.lower()
    if normalized in {"completed", "complete", "done", "success", "ok"}:
        return "completed"
    if normalized in {"in_progress", "running", "started"}:
        return "in_progress"
    if normalized in {"failed", "error", "failure"}:
        return "failed"
    if normalized in {"skipped", "skip"}:
        return "skipped"
    return "pending"


def _get_root_items(
    normalized: dict[str, dict[str, Any]],
    children_map: dict[str | None, list[str]],
) -> list[str]:
    roots = []
    for item_id, item in normalized.items():
        parent_id = item.get("parent_id")
        if not parent_id or parent_id not in normalized:
            roots.append(item_id)
    return roots


def _build_machine_plan_export(
    *,
    plan_items: list[dict[str, Any]],
    objective: str,
    session_id: str,
    work_id: str | None = None,
) -> dict[str, Any]:
    """Build a MACHINE_PLAN export from session plan items."""
    normalized, children_map, _status_map, _order_map = _normalize_plan_items(plan_items)
    epic_ids = [item_id for item_id, item in normalized.items() if item.get("item_type") == "epic"]
    if not epic_ids:
        epic_id = "E1"
        normalized[epic_id] = {
            "id": epic_id,
            "title": objective or "Execution Plan",
            "item_type": "epic",
            "status": "pending",
            "parent_id": None,
        }
        children_map.setdefault(None, []).append(epic_id)
        epic_ids = [epic_id]

    epics: list[dict[str, Any]] = []
    for epic_id in epic_ids:
        epic = normalized.get(epic_id, {})
        stories = _build_story_exports(epic_id, normalized, children_map)
        if not stories:
            stories = _build_story_exports(None, normalized, children_map)
        if not stories:
            stories = _build_synthetic_story_exports(normalized, children_map)
        epics.append(
            {
                "id": epic_id,
                "title": epic.get("title", objective or "Execution Plan"),
                "status": epic.get("status", "pending"),
                "stories": stories,
            }
        )

    plan_work_id = work_id or "SESSION-PLAN-EXPORT"
    return {
        "work_id": plan_work_id,
        "version": 1,
        "created": datetime.now(UTC).isoformat(),
        "context": {
            "source_session_id": session_id,
            "objective": objective,
        },
        "epics": epics,
        "completion_checklist": [
            "All plan items completed",
            "Quality checks executed as needed",
            "Final output verified against objective",
        ],
    }


def _build_story_exports(
    epic_id: str | None,
    normalized: dict[str, dict[str, Any]],
    children_map: dict[str | None, list[str]],
) -> list[dict[str, Any]]:
    story_ids = [
        child_id
        for child_id in children_map.get(epic_id, [])
        if normalized.get(child_id, {}).get("item_type") == "story"
    ]
    stories: list[dict[str, Any]] = []
    for story_idx, story_id in enumerate(story_ids, start=1):
        story = normalized.get(story_id, {})
        export_story_id = story_id
        if not re.match(r"^S\d+$", export_story_id):
            export_story_id = f"S{story_idx}"
        tasks = _build_task_exports(export_story_id, story_id, normalized, children_map)
        stories.append(
            {
                "id": export_story_id,
                "title": story.get("title", "Story"),
                "status": story.get("status", "pending"),
                "tasks": tasks,
            }
        )
    return stories


def _build_synthetic_story_exports(
    normalized: dict[str, dict[str, Any]],
    children_map: dict[str | None, list[str]],
) -> list[dict[str, Any]]:
    task_ids = [
        item_id
        for item_id, item in normalized.items()
        if item.get("item_type") == "task"
        and (
            item.get("parent_id") is None
            or normalized.get(item.get("parent_id", ""), {}).get("item_type") != "story"
        )
    ]
    if not task_ids:
        return []
    tasks = []
    for idx, task_id in enumerate(task_ids, start=1):
        task = normalized.get(task_id, {})
        acceptance = task.get("acceptance_criteria", [])
        if not isinstance(acceptance, list):
            acceptance = [acceptance]
        verify = acceptance[0] if acceptance else "Verify task completion"
        export_task = {
            "id": f"S1.T{idx}",
            "desc": task.get("description") or task.get("title", "Task"),
            "status": task.get("status", "pending"),
            "verify": verify,
        }
        subtasks = _build_subtask_exports(task_id, export_task["id"], normalized, children_map)
        if subtasks:
            export_task["subtasks"] = subtasks
        tasks.append(export_task)
    return [
        {
            "id": "S1",
            "title": "Execution Plan",
            "status": "pending",
            "tasks": tasks,
        }
    ]


def _build_task_exports(
    export_story_id: str,
    source_story_id: str,
    normalized: dict[str, dict[str, Any]],
    children_map: dict[str | None, list[str]],
) -> list[dict[str, Any]]:
    task_ids = [
        child_id
        for child_id in children_map.get(source_story_id, [])
        if normalized.get(child_id, {}).get("item_type") in {"task", "subtask"}
    ]
    tasks: list[dict[str, Any]] = []
    for idx, task_id in enumerate(task_ids, start=1):
        task = normalized.get(task_id, {})
        acceptance = task.get("acceptance_criteria", [])
        if not isinstance(acceptance, list):
            acceptance = [acceptance]
        verify = acceptance[0] if acceptance else "Verify task completion"
        export_task_id = task_id
        if not re.match(rf"^{re.escape(export_story_id)}\\.T\\d+$", export_task_id):
            export_task_id = f"{export_story_id}.T{idx}"
        export_task = {
            "id": export_task_id,
            "desc": task.get("description") or task.get("title", "Task"),
            "status": task.get("status", "pending"),
            "verify": verify,
        }
        if task.get("item_type") == "task":
            subtasks = _build_subtask_exports(task_id, export_task_id, normalized, children_map)
            if subtasks:
                export_task["subtasks"] = subtasks
        tasks.append(export_task)
    return tasks


def _build_subtask_exports(
    task_id: str,
    export_task_id: str,
    normalized: dict[str, dict[str, Any]],
    children_map: dict[str | None, list[str]],
) -> list[dict[str, Any]]:
    subtask_ids = [
        child_id
        for child_id in children_map.get(task_id, [])
        if normalized.get(child_id, {}).get("item_type") == "subtask"
    ]
    subtasks: list[dict[str, Any]] = []
    for idx, subtask_id in enumerate(subtask_ids, start=1):
        subtask = normalized.get(subtask_id, {})
        acceptance = subtask.get("acceptance_criteria", [])
        if not isinstance(acceptance, list):
            acceptance = [acceptance]
        verify = acceptance[0] if acceptance else "Verify subtask completion"
        subtasks.append(
            {
                "id": f"{export_task_id}.{idx}",
                "desc": subtask.get("description") or subtask.get("title", "Subtask"),
                "status": subtask.get("status", "pending"),
                "verify": verify,
            }
        )
    return subtasks


# =============================================================================
# Projects Management
# =============================================================================

projects_app = typer.Typer(help="Manage projects")
app.add_typer(projects_app, name="projects")
app.add_typer(
    projects_app,
    name="project",
    hidden=True,  # Alias for common typo + backward compatibility
)


@projects_app.command("list")
@handle_encoding_errors
def projects_list(
    include_deleted: bool = typer.Option(
        False,
        "--all",
        help="Include soft-deleted projects",
    ),
) -> None:
    """List projects for the current user."""
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()
        client = APIClient.from_config()
        result = client.list_projects_with_selection(include_deleted=include_deleted)
        projects = result["projects"]
        default_project_id = result.get("default_project_id")

        console.print()
        if not projects:
            print_info("No projects found")
            return

        console.print(f"[bold]Projects[/bold] ({len(projects)} shown)", style="cyan")
        console.print()

        table = Table()
        table.add_column("Project ID", style="cyan")
        table.add_column("Name")
        table.add_column("Working Dir")
        table.add_column("Updated", style="dim")

        for project in projects:
            project_id = str(project.get("project_id", ""))
            name = project.get("project_name", "") or project.get("name", "")
            working_dir = project.get("working_directory") or ""

            updated_at = project.get("updated_at", "N/A")
            if "T" in str(updated_at):
                from datetime import datetime

                try:
                    dt = datetime.fromisoformat(str(updated_at).replace("Z", "+00:00"))
                    updated_at = dt.strftime("%Y-%m-%d %H:%M")
                except (ValueError, TypeError):
                    pass

            # Show indicator for selected default project
            is_selected = default_project_id and str(default_project_id) == project_id
            display_id = (
                f"{project_id} [green]{glyphs.success}[/green]" if is_selected else project_id
            )

            table.add_row(display_id, name, working_dir, str(updated_at))

        console.print(table)

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in projects list command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in projects list command: {e}")
        raise typer.Exit(1) from e


@projects_app.command("create")
@handle_encoding_errors
def projects_create(
    name: str = typer.Argument(..., help="Project name"),
    working_dir: str | None = typer.Option(
        None,
        "--dir",
        "-d",
        help="Working directory (defaults to current directory). WSL UNC paths are auto-converted.",
    ),
    description: str = typer.Option("", "--description", "-s", help="Project description"),
) -> None:
    """Create a project."""
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()
        client = APIClient.from_config()

        # Normalize WSL UNC paths before creating Path object
        # This handles Windows paths like \\wsl.localhost\Ubuntu\home\user
        if working_dir is not None:
            normalized_path = _normalize_wsl_unc_path(working_dir)
            resolved_working_dir = Path(normalized_path).expanduser().resolve(strict=False)
        else:
            resolved_working_dir = Path.cwd().resolve(strict=False)

        # Warn if not in a git repository
        if not is_git_repository(resolved_working_dir):
            console.print(
                "\n[yellow]⚠ Warning: Project directory is not in a git repository[/yellow]\n"
                "Git repositories are required for Obra to track changes and create commits.\n"
                "\nTo initialize git:\n"
                "  [cyan]git init[/cyan]\n"
                "\nOr use auto-init when running Obra:\n"
                '  [cyan]obra run --auto-init-git "your objective"[/cyan]\n'
                "\nOr configure in your project:\n"
                "  [cyan]~/.obra/config-layers/01-user.yaml[/cyan] → [dim]llm.git.auto_init: true[/dim]\n"
            )

        result = client.create_project(
            name=name,
            working_dir=str(resolved_working_dir),
            description=description,
        )

        project_id = result.get("project_id")
        resolved_project_id = str(project_id) if project_id is not None else None
        print_success(f"Project created: {resolved_project_id} (dir: {resolved_working_dir})")
        if resolved_project_id:
            try:
                client.select_project(resolved_project_id)
                print_success(f"Default project set to {resolved_project_id}")
            except APIError as e:
                display_obra_error(e, console)
                print_warning(
                    "Project created, but failed to set it as default. "
                    "Run `obra projects select <id>` to set it manually."
                )
    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in projects create command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in projects create command: {e}")
        raise typer.Exit(1) from e


@projects_app.command("show")
@handle_encoding_errors
def projects_show(
    project_id: str = typer.Argument(..., help="Project ID"),
) -> None:
    """Show project details."""
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()
        client = APIClient.from_config()
        project = client.get_project(project_id)

        console.print()
        console.print("[bold]Project Details[/bold]", style="cyan")
        console.print()

        table = Table(show_header=False, box=None)
        table.add_column("Field", style="dim")
        table.add_column("Value")

        table.add_row("Project ID", str(project.get("project_id", "")))
        table.add_row("Name", project.get("project_name", project.get("name", "")))
        table.add_row("Working Dir", project.get("working_directory", ""))
        table.add_row("Status", project.get("status", ""))
        table.add_row("Updated", str(project.get("updated_at", "")))

        console.print(table)
    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in projects show command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in projects show command: {e}")
        raise typer.Exit(1) from e


@projects_app.command("select")
@handle_encoding_errors
def projects_select(
    project_id: str = typer.Argument(..., help="Project ID"),
) -> None:
    """Set default project."""
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()
        client = APIClient.from_config()
        client.select_project(project_id)
        print_success(f"Default project set to {project_id}")
    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in projects select command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in projects select command: {e}")
        raise typer.Exit(1) from e


@projects_app.command("update")
@handle_encoding_errors
def projects_update(
    project_id: str = typer.Argument(..., help="Project ID"),
    name: str | None = typer.Option(None, "--name", help="New project name"),
    working_dir: str | None = typer.Option(
        None, "--dir", help="New working directory. WSL UNC paths are auto-converted."
    ),
) -> None:
    """Update project name or working directory."""
    try:
        if name is None and working_dir is None:
            print_error("No updates provided (use --name and/or --dir)")
            raise typer.Exit(2)

        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()
        client = APIClient.from_config()

        # Normalize WSL UNC paths before creating Path object
        resolved_working_dir = None
        if working_dir:
            normalized_path = _normalize_wsl_unc_path(working_dir)
            resolved_working_dir = Path(normalized_path).expanduser().resolve(strict=False)
        project = client.update_project(
            project_id=project_id,
            name=name,
            working_dir=str(resolved_working_dir) if resolved_working_dir else None,
        )
        print_success(f"Project updated: {project.get('project_id')}")
    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in projects update command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in projects update command: {e}")
        raise typer.Exit(1) from e


@projects_app.command("delete")
@handle_encoding_errors
def projects_delete(
    project_id: str = typer.Argument(..., help="Project ID"),
    confirm: bool = typer.Option(
        False,
        "--confirm",
        help="Confirm soft delete",
    ),
) -> None:
    """Soft delete a project."""
    try:
        if not confirm:
            print_error("Refusing to delete without --confirm")
            raise typer.Exit(2)

        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()
        client = APIClient.from_config()
        client.delete_project(project_id)
        print_success(f"Project deleted: {project_id}")
    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in projects delete command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in projects delete command: {e}")
        raise typer.Exit(1) from e


# =============================================================================
# Project Context Management (FEAT-PROJECT-CONTEXT-001)
# =============================================================================

context_app = typer.Typer(help="Manage project context notes")
projects_app.add_typer(context_app, name="context")


@context_app.command("show")
@handle_encoding_errors
def context_show() -> None:
    """Display all project context notes."""
    try:
        from obra.project.context import ProjectContextManager

        manager = ProjectContextManager()
        notes = manager.load_notes()
        metadata = manager.get_metadata()

        console.print()
        if not notes:
            print_info("No project context notes found")
            console.print('\nAdd notes with: [cyan]obra project context add "<note>"[/cyan]')
            return

        console.print(f"[bold]Project Context Notes[/bold] ({len(notes)} total)", style="cyan")
        console.print(f"[dim]Last updated: {metadata.updated}[/dim]")
        console.print(f"[dim]Total injections: {metadata.metrics.get('injections_count', 0)}[/dim]")
        console.print()

        table = Table()
        table.add_column("ID", style="cyan", no_wrap=True)
        table.add_column("Note", style="white")
        table.add_column("Added", style="dim")

        for note in notes:
            # Format timestamp for display
            try:
                from datetime import datetime

                dt = datetime.fromisoformat(note.added.replace("Z", "+00:00"))
                added_str = dt.strftime("%Y-%m-%d %H:%M")
            except Exception:
                added_str = note.added

            table.add_row(note.id, note.text, added_str)

        console.print(table)
        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Error displaying context notes: {e}")
        raise typer.Exit(1) from e


@context_app.command("add")
@handle_encoding_errors
def context_add(
    note: str = typer.Argument(..., help="Context amendment to add to active intent"),
) -> None:
    """Add a context amendment to the active intent.

    Appends additional context or clarifications to the active intent's
    Context Amendments section. Use this to provide additional information
    discovered during derivation or implementation.

    Examples:
        obra context add "also need OAuth 2.0 support"
        obra context add "database should be PostgreSQL not MySQL"

    Reference: FEAT-AUTO-INTENT-001 S3.T2
    """
    try:
        from obra.intent import IntentStorage

        # Get the active intent
        working_dir = Path.cwd()
        storage = IntentStorage()
        project_id = storage.get_project_id(working_dir)

        active_intent = storage.load_active(project_id)

        if not active_intent:
            console.print()
            print_error("No active intent found for this project")
            console.print()
            console.print("To create an intent:")
            console.print("  [cyan]obra intent new 'your objective'[/cyan]")
            console.print()
            console.print("Or set an existing intent as active:")
            console.print("  [cyan]obra intent use <intent-id>[/cyan]")
            console.print()
            raise typer.Exit(1)

        # Append the amendment
        active_intent.context_amendments.append(note)

        # Save the updated intent
        storage.save(active_intent)

        console.print()
        print_success(f"Added context amendment to intent: {active_intent.slug}")
        console.print(f"[dim]{note}[/dim]")
        console.print()
        console.print(f"Total amendments: {len(active_intent.context_amendments)}")
        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Error adding context amendment: {e}")
        raise typer.Exit(1) from e


@context_app.command("remove")
@handle_encoding_errors
def context_remove(
    note_id: str = typer.Argument(..., help="Note ID to remove (e.g., note-001)"),
) -> None:
    """Remove a project context note by ID."""
    try:
        from obra.project.context import ProjectContextManager

        manager = ProjectContextManager()

        # Check if note exists
        note = manager.get_note(note_id)
        if not note:
            print_error(f"Note not found: {note_id}")
            console.print("\nRun [cyan]obra project context show[/cyan] to see available notes")
            raise typer.Exit(1)

        # Remove the note
        success = manager.remove_note(note_id)
        if success:
            print_success(f"Removed note {note_id}")
        else:
            print_error(f"Failed to remove note {note_id}")
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Error removing context note: {e}")
        raise typer.Exit(1) from e


@context_app.command("clear")
@handle_encoding_errors
def context_clear(
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip confirmation prompt",
    ),
) -> None:
    """Remove all project context notes."""
    try:
        from obra.project.context import ProjectContextManager

        manager = ProjectContextManager()
        notes = manager.load_notes()

        if not notes:
            print_info("No notes to clear")
            return

        # Confirmation prompt
        if not yes:
            console.print()
            console.print(
                f"[yellow]Warning:[/yellow] This will remove [bold]{len(notes)}[/bold] notes"
            )
            console.print()

            response = typer.confirm(get_message("prompt.confirm.clear_notes"))
            if not response:
                print_info("Cancelled")
                return

        # Clear notes
        count = manager.clear_notes()
        print_success(f"Cleared {count} notes")

    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Error clearing context notes: {e}")
        raise typer.Exit(1) from e


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
@require_terms_accepted
def cleanup(
    session_id: str = typer.Option(
        ...,
        "--session-id",
        help="Session ID to clean up Obra-managed containers for",
    ),
) -> None:
    """Clean up Obra-managed containers for a session."""
    try:
        from obra.hybrid.handlers.story0 import cleanup_containers

        cleaned = cleanup_containers(session_id)
        if cleaned:
            print_success(f"Cleaned up {cleaned} Obra-managed containers for session {session_id}")
        else:
            print_info("No Obra-managed containers found for cleanup")
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception("Error cleaning up Story 0 containers: %s", e)
        raise typer.Exit(1) from e


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
@require_terms_accepted
def resume(
    ctx: typer.Context,
    session_id: str = typer.Option(..., "--session-id", help="Session ID to resume"),
    working_dir: Path | None = typer.Option(
        None,
        "--dir",
        "-d",
        help="Working directory (overrides stored session working directory)",
        exists=True,
        file_okay=False,
        dir_okay=True,
        resolve_path=True,
    ),
    resume_from: str | None = typer.Option(
        None,
        "--from",
        help=(
            "Resume from a specific phase: story-0/environment (rerun setup), "
            "derivation/plan (skip Story 0 validation), execution (resume execution)."
        ),
        show_choices=True,
        click_type=click.Choice(
            ["story-0", "environment", "derivation", "plan", "execution"],
            case_sensitive=False,
        ),
    ),
    rerun_setup: bool = typer.Option(
        False,
        "--rerun-setup",
        help="Re-run Story 0 environment setup (alias for --from story-0)",
    ),
    verbose: int = typer.Option(
        0,
        "--verbose",
        "-v",
        count=True,
        max=3,
        help="Verbosity level (0-3, use -v/-vv/-vvv)",
    ),
    progress_json: bool = typer.Option(
        False,
        "--progress-json",
        help="Emit progress events as JSON lines to stdout",
    ),
    stream: bool = typer.Option(
        False,
        "--stream",
        "-s",
        help="Enable real-time LLM output streaming",
    ),
    auto_report: bool = typer.Option(
        False,
        "--auto-report",
        help="Automatically submit bug reports on failure (no prompt, for CI/CD)",
    ),
    permissive: bool = typer.Option(
        False,
        "--permissive",
        help="Bypass P1 planning blockers (proceed with warnings)",
    ),
    mock_credentials: bool = typer.Option(
        False,
        "--mock-credentials",
        help="Automatically mock all required credentials",
    ),
) -> None:
    """Resume an interrupted session.

    Continues a session from where it left off. Useful after:
    - Network disconnection
    - Client crash
    - Manual interruption

    Examples:
        $ obra resume --session-id abc123
        $ obra resume --session-id abc123 -v
        $ obra resume --session-id abc123 -vv --stream
        $ obra resume --session-id abc123 --dir /path/to/project
    """
    verbose = _resolve_command_verbosity(ctx, verbose)
    setup_logging(verbose)

    # Deprecation warning for obra resume
    import warnings

    warnings.warn(
        "'obra resume' is deprecated. Use 'obra run --resume <id>' instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    console.print(
        f"[yellow]Deprecation:[/yellow] {build_deprecation_warning('obra resume', f'obra run --resume {session_id}')}",
        style="dim",
    )
    console.print()

    # Start session console logging to capture all output
    import atexit

    start_session_logging(session_id=session_id)
    atexit.register(stop_session_logging)

    progress_emitter: ProgressEmitter | None = None
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth
        from obra.hybrid import HybridOrchestrator

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        console.print()
        console.print("[bold]Resuming Session[/bold]", style="cyan")
        console.print(f"Session ID: {session_id}")

        client = APIClient.from_config()

        # Display plan context to orient the user before resuming
        try:
            plan_data = client.get_session_plan(session_id)
            objective = plan_data.get("objective", "")
            plan_items = plan_data.get("plan_items", [])
            completed = plan_data.get("completed_count", 0)
            total = plan_data.get("total_count", 0)

            if objective:
                console.print(f"[dim]Objective: {objective}[/dim]")

            if total > 0:
                # Find next pending item
                next_item = None
                for item in plan_items:
                    if item.get("status") == "pending":
                        next_item = item
                        break

                console.print(f"Progress: {completed}/{total} items completed")
                if next_item:
                    next_title = next_item.get("title", "Unknown")
                    next_id = next_item.get("item_id", "")
                    console.print(f"Next: [cyan]{next_id}[/cyan] {next_title}")

                # Show full plan tree at -v or higher
                if verbose > 0 and plan_items:
                    console.print()
                    _render_plan_tree(console, plan_items, "")
        except Exception as e:
            # Plan display is optional - don't block resume on failure
            logger.debug("Could not fetch plan for resume context: %s", e)

        console.print()
        selection = _resolve_working_dir_selection(
            client=client,
            working_dir=working_dir,
            project_id=None,
            resume_session=session_id,
            continue_from=None,
        )
        work_dir = selection.path
        if not work_dir.exists():
            print_error(f"Working directory does not exist: {work_dir}")
            raise typer.Exit(1)

        if selection.conflict and selection.prompt_used:
            print_info(f"Working directory selected: {work_dir}")

        if selection.stored_missing and selection.project_id:
            try:
                client.update_project(
                    project_id=selection.project_id,
                    working_dir=str(work_dir),
                )
                print_info(f"Saved working directory to project {selection.project_id}")
            except Exception as exc:
                logger.warning(
                    "Failed to persist working directory for project %s: %s",
                    selection.project_id,
                    exc,
                )

        if rerun_setup:
            resume_from = "story-0"
        if resume_from:
            normalized = resume_from.lower()
            if normalized in ("environment", "story-0"):
                resume_from = "story-0"
            elif normalized in ("plan", "derivation"):
                resume_from = "derivation"
            else:
                resume_from = "execution"

            state_path = work_dir / ".obra" / "story0_state.yaml"
            if resume_from in ("story-0", "derivation") and state_path.exists():
                try:
                    state_path.unlink()
                    if resume_from == "story-0":
                        print_info("Removed Story 0 state; re-running environment setup.")
                    else:
                        print_info("Cleared Story 0 state; skipping validation on resume.")
                except OSError as exc:
                    logger.warning("Failed to remove Story 0 state: %s", exc)

        config = load_config()
        ux_config = config.get("features", {}).get("user_experience", {})
        dashboard_config = ux_config.get("dashboard", {})
        ux_enabled = bool(ux_config.get("enabled", True))
        dashboard_enabled = bool(dashboard_config.get("enabled", True)) and ux_enabled
        footer_hint_enabled = bool(dashboard_config.get("footer_hint", True))
        task_tracker_enabled = bool(dashboard_config.get("task_tracker", True))
        task_tracker_max_next = dashboard_config.get("task_tracker_max_next", 3)
        if not isinstance(task_tracker_max_next, int):
            try:
                task_tracker_max_next = int(task_tracker_max_next)
            except (TypeError, ValueError):
                task_tracker_max_next = 3

        # Create observability configuration from CLI flags
        obs_config = ObservabilityConfig(
            verbosity=verbose,
            stream=stream,
            timestamps=True,
            dashboard_enabled=dashboard_enabled,
            footer_hint_enabled=footer_hint_enabled,
            task_tracker_enabled=task_tracker_enabled,
            task_tracker_max_next=task_tracker_max_next,
        )
        set_runtime_verbosity(verbose)

        # Create progress emitter for observability
        progress_emitter = ProgressEmitter(obs_config, console)
        progress_json_value = bool(locals().get("progress_json", False))

        # Create orchestrator and resume with progress callback
        def on_progress(action: str, payload: dict) -> None:
            """Progress callback that routes events to ProgressEmitter."""
            _route_progress_event(
                progress_emitter,
                console,
                verbose,
                action,
                payload,
                progress_json=progress_json_value,
            )

        # ISSUE-STREAM-001: Create on_stream callback for real-time LLM output streaming
        def on_stream(event_type: str, chunk: str) -> None:
            """Stream callback for real-time LLM output."""
            if event_type == "llm_streaming":
                progress_emitter.llm_streaming(chunk)
        on_escalation = _build_escalation_callback()

        # Build bypass_modes from --permissive flag and config
        planning_config = _load_planning_config(work_dir)
        # Check both legacy planning_config and new review.permissive_mode path
        config_permissive = bool(planning_config.get("permissive_mode"))
        if not config_permissive:
            # Check review.permissive_mode from layered config (Menu 4 setting)
            from obra.config.loaders import load_layered_config

            layered_cfg, _, _ = load_layered_config(include_defaults=True)
            config_permissive = bool(layered_cfg.get("review", {}).get("permissive_mode"))
        effective_permissive = permissive or config_permissive
        bypass_modes: list[str] = []
        if effective_permissive:
            bypass_modes.append("planning_permissive")

        orchestrator = HybridOrchestrator.from_config(
            working_dir=work_dir,
            on_progress=on_progress,
            on_escalation=on_escalation,
            on_stream=on_stream if stream else None,
            observability_config=obs_config,
            progress_emitter=progress_emitter,
            bypass_modes=bypass_modes if bypass_modes else None,
        )

        # Apply mock_credentials override if specified
        if mock_credentials:
            from obra.config.loaders import load_layered_config

            story0_override_config, _, _ = load_layered_config(str(work_dir))
            story0_override_config.setdefault("story0", {})["mock_credentials"] = True
            orchestrator._config = story0_override_config

        try:
            with defer_interrupts():
                result = orchestrator.resume(session_id)
        except GracefulInterrupt:
            hint_session_id = _interrupt_state.get("recovery_hint_session_id")
            suppress_interrupt_hint = bool(_interrupt_state.get("recovery_hint_printed")) and bool(
                hint_session_id
            ) and (not session_id or str(hint_session_id) == str(session_id))
            # Build interrupted closeout message
            closeout_ctx = CloseoutContext(
                state=TerminationState.INTERRUPTED,
                session_id=session_id,
                objective="",  # Objective not available in resume context
                suppress_interrupt_hint=suppress_interrupt_hint,
            )
            build_closeout_message(closeout_ctx, console, verbosity=verbose)
            raise typer.Exit(130) from None
        finally:
            clear_interrupt_request()

        # Display result
        console.print()
        action = getattr(result, "action", None)
        # ISSUE-SAAS-050: Track items_completed to validate success and set exit code
        items_completed = 0
        if action == "complete" or action is None:
            (
                items_completed,
                total_iterations,
                quality_score,
                was_escalated,
                terminal_phase,
            ) = _extract_completion_context(result)

            # Terse completion footer for LLM handoff (git file status)
            _print_git_file_summary(console, str(work_dir))

            # Build and display closeout message using the new closeout builder
            closeout_ctx = _build_closeout_context(
                result,
                session_id=session_id,
                objective="",  # Objective extracted from result inside _build_closeout_context
            )
            build_closeout_message(closeout_ctx, console, verbosity=verbose)

            if was_escalated:
                raise typer.Exit(1)

            # ISSUE-SAAS-050: Exit with error code if no items succeeded
            if items_completed == 0:
                _offer_bug_report(
                    context="session resume",
                    command_used="obra resume",
                    session_id=session_id,
                    failure_reason="0 items completed successfully",
                    auto_report=auto_report,
                    orchestrator=orchestrator,
                )
                raise typer.Exit(1)

        elif action == "escalate":
            print_warning("Session requires user decision")
            console.print("\nRun 'obra status' to see details.")
            # Escalation is not a success - exit with error
            raise typer.Exit(1)
        else:
            console.print(f"Session state: {action}")

    except APIError as e:
        if progress_emitter:
            progress_emitter.halt_spinner()
        display_obra_error(e, console)
        _print_session_resume_hints(session_id)
        logger.error(f"API error in resume command: {e}", exc_info=True)
        _offer_bug_report(
            e,
            context="session resume",
            command_used="obra resume",
            session_id=session_id,
            auto_report=auto_report,
            orchestrator=orchestrator,
        )
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        if progress_emitter:
            progress_emitter.halt_spinner()
        display_obra_error(e, console)
        logger.error(f"Configuration error in resume command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        if progress_emitter:
            progress_emitter.halt_spinner()
        display_obra_error(e, console)
        _print_session_resume_hints(session_id)
        logger.error(f"Obra error in resume command: {e}", exc_info=True)
        _offer_bug_report(
            e,
            context="session resume",
            command_used="obra resume",
            session_id=session_id,
            auto_report=auto_report,
            orchestrator=orchestrator,
        )
        raise typer.Exit(1) from e
    except Exception as e:
        if progress_emitter:
            progress_emitter.halt_spinner()
        display_error(e, console)
        _print_session_resume_hints(session_id)
        logger.exception(f"Unexpected error in resume command: {e}")
        _offer_bug_report(
            e,
            context="session resume",
            command_used="obra resume",
            session_id=session_id,
            auto_report=auto_report,
            orchestrator=orchestrator,
        )
        raise typer.Exit(1) from e


# =============================================================================
# Setup Command (First-Time Onboarding)
# =============================================================================


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
def setup(
    check: bool = typer.Option(
        False,
        "--check",
        help="Check setup status without prompting",
    ),
    skip_validation: bool = typer.Option(
        False,
        "--skip-validation",
        help="Skip environment validation after authentication",
    ),
    timeout: int = typer.Option(
        300,
        "--timeout",
        "-t",
        help="Timeout in seconds for browser authentication",
    ),
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Don't open browser, just print URL",
    ),
) -> None:
    """First-time setup with terms acceptance, authentication, and provider selection.

    Complete onboarding flow:
    1. Display and accept Beta Software Agreement
    2. Authenticate via browser OAuth
    3. Register acceptance with server
    4. Validate environment configuration
    5. Select LLM provider (recommended settings auto-applied)

    Examples:
        $ obra setup
        $ obra setup --check
        $ obra setup --no-browser
        $ obra setup --timeout 600

    Exit Codes:
        0: Setup complete (or --check passed)
        1: Setup incomplete or failed
        2: User declined terms
    """
    try:
        from obra.api import APIClient
        from obra.auth import login_with_browser, save_auth
        from obra.config import (
            DEFAULT_AUTH_METHOD,
            DEFAULT_MODEL,
            DEFAULT_PROVIDER,
            PRIVACY_VERSION,
            TERMS_VERSION,
            is_terms_accepted,
            load_config,
            needs_reacceptance,
            save_config,
            save_terms_acceptance,
        )
        from obra.legal import get_terms_summary

        def _tier_defaults_for_provider(provider: str) -> dict[str, str]:
            """Get recommended tier models for a provider."""
            if provider == "openai":
                return {
                    "fast": "gpt-5.3-codex-spark",
                    "medium": "gpt-5.1-codex-max",
                    "high": "gpt-5.1-codex-max",
                }
            if provider == "google":
                return {
                    "fast": "gemini-2.5-flash",
                    "medium": "gemini-2.5-pro",
                    "high": "gemini-3-pro-preview",
                }
            # anthropic (default)
            return {"fast": "haiku", "medium": "sonnet", "high": "opus"}

        # S1.T6: Implement --check flag
        if check:
            console.print()
            console.print("[bold]Setup Status Check[/bold]", style="cyan")
            console.print()

            # Check terms acceptance
            if is_terms_accepted():
                print_success(f"Terms accepted: version {TERMS_VERSION}")
            elif needs_reacceptance():
                from obra.config import get_terms_acceptance

                old_acceptance = get_terms_acceptance()
                old_version = (
                    old_acceptance.get("version", "unknown") if old_acceptance else "unknown"
                )
                print_warning(f"Terms version mismatch: {old_version} → {TERMS_VERSION}")
                console.print(get_message("recovery.auth.terms"))
                raise typer.Exit(1)
            else:
                print_warning("Terms not accepted")
                console.print(get_message("recovery.auth.terms"))
                raise typer.Exit(1)

            # Check authentication
            from obra.auth import get_current_auth

            auth = get_current_auth()
            if auth:
                print_success(f"Authenticated: {auth.email}")
            else:
                print_warning("Not authenticated")
                console.print(get_message("recovery.auth.setup"))
                raise typer.Exit(1)

            # Check environment (provider CLIs)
            console.print()
            console.print("[bold]Environment:[/bold]")

            from obra.config import LLM_PROVIDERS, check_provider_status

            provider_count = 0
            for provider_key in LLM_PROVIDERS:
                status = check_provider_status(provider_key)
                provider_name = LLM_PROVIDERS[provider_key].get("name", provider_key)

                if status.installed:
                    console.print(
                        f"  [green]{glyphs.success}[/green] {provider_name} ({status.cli_command})"
                    )
                    provider_count += 1
                else:
                    console.print(
                        f"  [red]{glyphs.failure}[/red] {provider_name} ({status.cli_command}) - not found"
                    )

            console.print()
            if provider_count > 0:
                print_success("Setup complete - all checks passed")
                raise typer.Exit(0)
            print_warning("No provider CLIs installed")
            console.print("Install at least one: claude, codex, or gemini")
            raise typer.Exit(1)

        # Regular setup flow (not --check mode)
        console.print()
        console.print("[bold]Obra Setup[/bold]", style="cyan")
        console.print()

        # S1.T7: Check if re-acceptance is needed
        if needs_reacceptance():
            from obra.config import get_terms_acceptance

            old_acceptance = get_terms_acceptance()
            old_version = old_acceptance.get("version", "unknown") if old_acceptance else "unknown"
            console.print(
                f"[yellow]Terms have been updated: v{old_version} → v{TERMS_VERSION}[/yellow]"
            )
            console.print()
            console.print("You must review and accept the updated terms to continue.")
            console.print()

        # S1.T1: Display terms summary
        terms_text = get_terms_summary()

        # Display terms in a box
        console.print(
            "[bold cyan]════════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print(terms_text.strip())
        console.print(
            "[bold cyan]════════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print()

        # Prompt for acceptance
        console.print("To accept these terms, type exactly: [bold]I ACCEPT[/bold]")
        console.print("To decline, type anything else or press Ctrl+C")
        console.print()

        # Get user input
        try:
            from obra.display.prompting import prompt_input

            user_input = prompt_input("> ").strip()
        except (KeyboardInterrupt, EOFError):
            console.print()
            console.print("[yellow]Setup cancelled by user[/yellow]")
            raise typer.Exit(2) from None

        # Check acceptance (case-insensitive)
        if user_input.upper() != "I ACCEPT":
            console.print()
            console.print("[yellow]Terms not accepted. Setup cancelled.[/yellow]")
            console.print()
            console.print(get_message("guidance.requirement.accept_terms"))
            raise typer.Exit(2)

        console.print()
        print_success(f"Terms v{TERMS_VERSION} accepted")
        console.print()

        # Save local acceptance
        save_terms_acceptance()

        # S1.T2: Authenticate via OAuth
        console.print("Opening browser for authentication...")
        console.print()

        try:
            auth_result = login_with_browser(timeout=timeout, auto_open=not no_browser)
            save_auth(auth_result)

            console.print()
            print_success(f"Logged in as: {auth_result.email}")
            if auth_result.display_name:
                console.print(f"Name: {auth_result.display_name}")
            console.print()

        except typer.Exit:
            raise
        except Exception as e:
            print_error(f"Authentication failed: {e}")
            logger.error(f"OAuth flow failed during setup: {e}", exc_info=True)
            raise typer.Exit(1) from e

        # S1.T3: Register terms acceptance with server (MANDATORY)
        # Server-side registration is required for legal compliance.
        # Without server confirmation, we cannot prove acceptance in disputes.
        import time

        client = APIClient.from_config()
        # Get CLI retry config (CHORE-CONFIG-DEFAULTS-001-E3 S3)
        retry_config = get_cli_retry_config()
        max_retries = retry_config["max_attempts"]
        retry_delay = retry_config["initial_delay_s"]
        backoff_multiplier = retry_config["backoff_multiplier"]

        for attempt in range(1, max_retries + 1):
            try:
                client.log_terms_acceptance(
                    terms_version=TERMS_VERSION,
                    privacy_version=PRIVACY_VERSION,
                    client_version=__version__,
                )
                print_success("Terms acceptance registered with server")
                console.print()
                break  # Success - exit retry loop
            except typer.Exit:
                raise
            except Exception as e:
                logger.warning(f"Terms registration attempt {attempt}/{max_retries} failed: {e}")
                if attempt < max_retries:
                    console.print(
                        f"[yellow]Server registration failed, retrying ({attempt}/{max_retries})...[/yellow]"
                    )
                    time.sleep(retry_delay)
                    retry_delay *= backoff_multiplier  # Exponential backoff
                else:
                    # All retries exhausted - this is fatal
                    logger.exception(f"Terms registration failed after {max_retries} attempts")
                    print_error("Failed to register terms acceptance with server")
                    console.print()
                    console.print(
                        "[red]Server-side registration is required for legal compliance.[/red]"
                    )
                    console.print("Please check your internet connection and try again.")
                    console.print()
                    console.print(
                        "If the problem persists, please report the issue at: https://github.com/Unpossible-Creations/Obra/issues"
                    )
                    raise typer.Exit(1) from e

        # S1.T4: Run environment validation (unless skipped)
        if not skip_validation:
            console.print("[bold]Validating environment...[/bold]")
            console.print()

            from obra.config import LLM_PROVIDERS, check_provider_status

            provider_count = 0
            for provider_key in LLM_PROVIDERS:
                status = check_provider_status(provider_key)
                provider_name = LLM_PROVIDERS[provider_key].get("name", provider_key)

                if status.installed:
                    console.print(
                        f"  [green]{glyphs.success}[/green] {provider_name} CLI: {status.cli_command}"
                    )
                    provider_count += 1
                else:
                    console.print(f"  [dim]o[/dim] {provider_name} CLI: Not installed")

            console.print()

            # Check working directory
            from pathlib import Path

            obra_projects = Path.home() / "obra-projects"
            if obra_projects.exists():
                console.print(
                    f"  [green]{glyphs.success}[/green] Working directory: {obra_projects}"
                )
            else:
                console.print(
                    f"  [yellow]o[/yellow] Working directory: {obra_projects} (will be created)"
                )

            console.print()

            if provider_count == 0:
                print_warning("No provider CLIs installed")
                console.print()
                console.print("Obra requires at least one LLM provider CLI:")
                console.print("  - Claude Code: https://claude.com/download")
                console.print("  - OpenAI Codex: https://openai.com/codex")
                console.print("  - Gemini CLI: https://ai.google.dev/gemini-api/docs/cli")
                console.print()
                console.print("Install one and run 'obra setup --check' to verify.")
                console.print()

        # S4.T0: Prompt for LLM provider selection (simplified)
        console.print("[bold]Select LLM Provider[/bold]")
        console.print("Choose your preferred provider. Recommended settings will be applied.")
        console.print("(You can customize later with 'obra config')")
        console.print()

        # Show available providers with status
        from obra.config import LLM_PROVIDERS, check_provider_status

        available_providers = []
        for idx, provider_key in enumerate(["anthropic", "openai", "google"], 1):
            if provider_key not in LLM_PROVIDERS:
                continue
            status = check_provider_status(provider_key)
            provider_name = LLM_PROVIDERS[provider_key].get("name", provider_key)
            if status.installed:
                console.print(f"  {idx}. {provider_name} [green](installed)[/green]")
                available_providers.append(provider_key)
            else:
                console.print(f"  {idx}. {provider_name} [dim](not installed)[/dim]")
                available_providers.append(provider_key)

        console.print()

        # Get provider selection
        try:
            from obra.display.prompting import prompt_input

            selection = prompt_input("Enter provider number [1/2/3]: ").strip()
        except (KeyboardInterrupt, EOFError):
            console.print()
            console.print("[yellow]Setup cancelled by user[/yellow]")
            raise typer.Exit(2) from None

        # Parse selection
        provider_map = {"1": "anthropic", "2": "openai", "3": "google"}
        selected_provider = provider_map.get(selection, DEFAULT_PROVIDER)

        # Get recommended defaults for selected provider
        tier_defaults = _tier_defaults_for_provider(selected_provider)

        # Provider-specific model defaults
        provider_model_defaults = {
            "anthropic": {"model": "sonnet", "auth_method": "oauth"},
            "openai": {"model": "gpt-5.1-codex-max", "auth_method": "oauth"},
            "google": {"model": "gemini-2.5-pro", "auth_method": "oauth"},
        }
        model_defaults = provider_model_defaults.get(
            selected_provider,
            {"model": DEFAULT_MODEL, "auth_method": DEFAULT_AUTH_METHOD},
        )

        # Build clean config structure
        config = load_config()
        llm_section = {
            "orchestrator": {
                "provider": selected_provider,
                "model": model_defaults["model"],
                "auth_method": model_defaults["auth_method"],
                "tiers": tier_defaults.copy(),
            },
            "implementation": {
                "provider": selected_provider,
                "model": model_defaults["model"],
                "auth_method": model_defaults["auth_method"],
                "tiers": tier_defaults.copy(),
            },
        }

        config["llm"] = llm_section
        save_config(config)
        console.print()
        provider_display = LLM_PROVIDERS.get(selected_provider, {}).get("name", selected_provider)
        print_success(f"LLM configuration set to {provider_display}")
        console.print()

        # S1.T5: Display setup completion with copy-paste prompt
        console.print(
            "[bold cyan]═══════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print()
        console.print("[bold green]Setup complete![/bold green]")
        console.print()
        console.print(
            "[bold cyan]═══════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print()
        console.print("[bold]  USING OBRA WITH YOUR AI ASSISTANT[/bold]")
        console.print()
        console.print("    Copy this prompt to your AI assistant (Claude Code, Codex, Gemini):")
        console.print()
        console.print(
            "    [cyan]┌─────────────────────────────────────────────────────────────────┐[/cyan]"
        )
        console.print(
            "    [cyan]│[/cyan]                                                                 [cyan]│[/cyan]"
        )
        console.print(
            "    [cyan]│[/cyan]  I want to use Obra. Run `obra` and `obra briefing` to get     [cyan]│[/cyan]"
        )
        console.print(
            "    [cyan]│[/cyan]  oriented. Then help me prepare structured input and invoke    [cyan]│[/cyan]"
        )
        console.print(
            "    [cyan]│[/cyan]  Obra to execute my objective.                                 [cyan]│[/cyan]"
        )
        console.print(
            "    [cyan]│[/cyan]                                                                 [cyan]│[/cyan]"
        )
        console.print(
            "    [cyan]└─────────────────────────────────────────────────────────────────┘[/cyan]"
        )
        console.print()
        console.print("    Your AI will then know exactly how to prepare high-quality input")
        console.print("    for Obra's optimal performance.")
        console.print()
        console.print(
            "[bold cyan]═══════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print()
        console.print("[bold]Next steps:[/bold]")
        console.print()
        console.print("  1. Give your AI the prompt above, then describe what you want to build")
        console.print()
        console.print("  2. Or start directly (if you know what you're doing):")
        console.print('     [cyan]$ obra run "Add user authentication" --stream[/cyan]')
        console.print()
        console.print("  3. Check session status anytime:")
        console.print("     [cyan]$ obra status[/cyan]")
        console.print()
        console.print("  4. Explore configuration:")
        console.print("     [cyan]$ obra config[/cyan]")
        console.print()
        console.print(
            "[bold cyan]═══════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print()

    except typer.Exit:
        # Re-raise typer.Exit without catching it as an error
        raise
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in setup command: {e}", exc_info=True)
        _offer_bug_report(e, context="setup", command_used="obra setup")
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in setup command: {e}", exc_info=True)
        _offer_bug_report(e, context="setup", command_used="obra setup")
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in setup command: {e}")
        _offer_bug_report(e, context="setup", command_used="obra setup")
        raise typer.Exit(1) from e


# =============================================================================
# AI Assistant Onboarding Commands
# =============================================================================

# Create briefing subcommand group
briefing_app = typer.Typer(
    name="briefing",
    help="★ Operating guide, blueprint, and protocol for AI assistants",
    invoke_without_command=True,
    rich_markup_mode="rich",
)
app.add_typer(briefing_app, name="briefing", rich_help_panel="AI Operator Resources")


def _load_onboarding_content() -> tuple[str, str]:
    """Load LLM_ONBOARDING.md content and file path.

    Returns:
        Tuple of (content, file_path)

    Raises:
        typer.Exit: If file cannot be located
    """
    import importlib.resources as pkg_resources
    from pathlib import Path

    try:
        # Python 3.9+ approach
        if hasattr(pkg_resources, "files"):
            obra_package = pkg_resources.files("obra")
            onboarding_file = obra_package / ".obra" / "LLM_ONBOARDING.md"
            file_path = str(onboarding_file)

            # Read the file content
            if hasattr(onboarding_file, "read_text"):
                content = onboarding_file.read_text(encoding="utf-8")
            else:
                # Fallback for older Python versions
                with Path(file_path).open(encoding="utf-8") as f:
                    content = f.read()
        else:
            # Fallback for Python < 3.9
            import pkg_resources as old_pkg

            file_path = old_pkg.resource_filename("obra", ".obra/LLM_ONBOARDING.md")
            with Path(file_path).open(encoding="utf-8") as f:
                content = f.read()
        return content, file_path
    except typer.Exit:
        raise
    except Exception as e:
        # Development mode fallback - look in source tree
        dev_path = Path(__file__).parent / ".obra" / "LLM_ONBOARDING.md"
        if dev_path.exists():
            file_path = str(dev_path)
            content = dev_path.read_text(encoding="utf-8")
            return content, file_path
        print_error(f"Could not locate LLM_ONBOARDING.md: {e}")
        raise typer.Exit(1) from e


def _track_briefing_usage(command: str) -> None:
    """Track briefing command usage for analytics (Phase 2 telemetry).

    Records which briefing subcommand was invoked to validate 80/20 assumptions:
    - >80% should use 'quick' (the recommended option)
    - <10% should use 'full' (validates full guide is rarely needed)

    Data is stored locally in ~/.obra/usage/briefing.jsonl (JSON Lines format).
    Only tracks if advanced.telemetry.enabled is true in config.

    Args:
        command: The briefing subcommand name (quick, full, blueprint, etc.)
    """
    try:
        import json
        from datetime import datetime

        from obra.config import load_config

        # Check if telemetry is enabled
        config = load_config()
        telemetry_enabled = config.get("advanced", {}).get("telemetry", {}).get("enabled", False)
        if not telemetry_enabled:
            return

        # Create usage directory if needed
        usage_dir = Path.home() / ".obra" / "usage"
        usage_dir.mkdir(parents=True, exist_ok=True)

        # Append event to JSON Lines file (one JSON object per line)
        usage_file = usage_dir / "briefing.jsonl"
        event = {
            "timestamp": datetime.now(UTC).isoformat(),
            "command": command,
            "version": __version__,
        }

        with usage_file.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event) + "\n")

    except Exception:
        # Telemetry should never break the command - silently ignore errors
        pass


def _display_default_briefing() -> None:
    """Display the default briefing output (process-first with conversation example)."""
    console.print()
    console.print("[bold]FOR HUMANS: Copy this prompt to your AI assistant:[/bold]")
    console.print()
    console.print(
        "[cyan]┌─────────────────────────────────────────────────────────────────┐[/cyan]"
    )
    console.print(
        "[cyan]│[/cyan]                                                                 [cyan]│[/cyan]"
    )
    console.print(
        "[cyan]│[/cyan]  I want to use Obra. Run `obra` and `obra briefing` to get     [cyan]│[/cyan]"
    )
    console.print(
        "[cyan]│[/cyan]  oriented. Then help me prepare structured input and invoke    [cyan]│[/cyan]"
    )
    console.print(
        "[cyan]│[/cyan]  Obra to execute my objective.                                 [cyan]│[/cyan]"
    )
    console.print(
        "[cyan]│[/cyan]                                                                 [cyan]│[/cyan]"
    )
    console.print(
        "[cyan]└─────────────────────────────────────────────────────────────────┘[/cyan]"
    )
    console.print()
    console.print(
        "[cyan]══════════════════════════════════════════════════════════════════════[/cyan]"
    )
    console.print("[bold cyan]           OBRA OPERATING GUIDE FOR AI ASSISTANTS[/bold cyan]")
    console.print(
        "[cyan]══════════════════════════════════════════════════════════════════════[/cyan]"
    )
    console.print()
    console.print("[bold red]IMPORTANT: DO NOT KILL LONG-RUNNING OBRA COMMANDS[/bold red]")
    console.print("[red]Obra runs can take 15-40 minutes. If your tool enforces timeouts,[/red]")
    console.print("[red]do NOT let it terminate the process. Start `obra run` in a separate[/red]")
    console.print("[red]terminal or background (tmux/screen/nohup) and monitor with[/red]")
    console.print("[red]`obra status` while the run keeps going.[/red]")
    console.print()
    console.print("[bold]LLM Operator Fast Path (deterministic)[/bold]")
    console.print(
        "  1) Models: [cyan]obra models[/cyan] -> pick names. Use "
        "[cyan]obra run --model X --fast-model X --high-model X --impl-provider openai[/cyan]."
    )
    console.print(
        "     Or env vars: [cyan]OBRA_MODEL/OBRA_FAST_MODEL/OBRA_HIGH_MODEL/OBRA_PROVIDER[/cyan]."
    )
    console.print("     Do NOT use [cyan]obra config set llm.*.model[/cyan] (unsupported).")
    console.print(
        "  2) Help: [cyan]obra help run[/cyan] or [cyan]obra projects create --help[/cyan] "
        "(subcommand help uses --help)."
    )
    console.print(
        "  3) [bold yellow][!] WSL paths[/bold yellow]: map [cyan]C:\\path[/cyan] -> [cyan]/mnt/c/path[/cyan] and use "
        "[cyan]obra run --dir /mnt/c/...[/cyan]."
    )
    console.print("     On native Windows, use [cyan]C:\\path[/cyan] directly.")
    console.print(
        "  4) Working dir: Run from inside your project, or use [cyan]--dir /path[/cyan]. "
        "Verbosity: [cyan]-v/-vv/-vvv[/cyan]."
    )
    console.print(
        "  5) Monitoring: capture [bold]session_id[/bold] from run output, then "
        "[cyan]obra status <session_id>[/cyan]."
    )
    console.print(
        "     Config warnings: ignore auth metadata keys in "
        "[cyan]~/.obra/config-layers/01-user.yaml[/cyan]; others are real issues."
    )
    console.print(
        "  6) Logs & paths: See [cyan]~/.obra/README.md[/cyan] for log file locations and "
        "monitoring commands."
    )
    console.print("     Real-time logs: [cyan]tail -f ~/.obra/logs/hybrid.jsonl[/cyan]")
    console.print()
    console.print("Obra executes development tasks autonomously. Your job: gather requirements")
    console.print("through conversation, then invoke Obra with structured input.")
    console.print()
    console.print("Run `obra` to see all commands. Key: run, status, resume, doctor")
    console.print()

    # Check for active intent and display if found (FEAT-AUTO-INTENT-001 S8.T2)
    try:
        from pathlib import Path as PathLib

        from obra.intent import IntentStorage

        working_dir = PathLib.cwd()
        storage = IntentStorage()
        project_id = storage.get_project_id(working_dir)
        active_intent = storage.load_active(project_id)

        if active_intent:
            console.print(
                "[cyan]╔═════════════════════════════════════════════════════════════════╗[/cyan]"
            )
            console.print(
                "[cyan]║[/cyan] [bold yellow]ACTIVE INTENT DETECTED[/bold yellow]                                           [cyan]║[/cyan]"
            )
            console.print(
                "[cyan]╚═════════════════════════════════════════════════════════════════╝[/cyan]"
            )
            console.print("[dim](Session state from previous work - ignore for new projects)[/dim]")
            console.print()
            console.print(f"[bold]Intent:[/bold] {active_intent.slug}")
            console.print(f"[bold]Problem:[/bold] {active_intent.problem_statement}")
            console.print()

            # Show key requirements (first 3 if more than 3)
            if active_intent.requirements:
                console.print("[bold]Key Requirements:[/bold]")
                max_to_show = 3
                for i, req in enumerate(active_intent.requirements[:max_to_show], 1):
                    console.print(f"  {i}. {req}")
                if len(active_intent.requirements) > max_to_show:
                    remaining = len(active_intent.requirements) - max_to_show
                    console.print(f"  [dim]... and {remaining} more[/dim]")
                console.print()

            console.print("[bold]Suggested Commands:[/bold]")
            console.print(
                "  [cyan]obra derive[/cyan]                  Continue derivation with this intent"
            )
            console.print(
                "  [cyan]obra context add 'info'[/cyan]     Amend intent with additional context"
            )
            console.print("  [cyan]obra intent show[/cyan]            Show full intent details")
            console.print(
                "  [cyan]obra verify[/cyan]                 Verify completion against acceptance criteria"
            )
            console.print()
            console.print(
                "[cyan]─────────────────────────────────────────────────────────────────[/cyan]"
            )
            console.print()
    except Exception:
        # Silently ignore errors (don't break briefing if intent loading fails)
        pass

    console.print("[bold]YOUR PROCESS[/bold]")
    console.print("[cyan]────────────[/cyan]")
    console.print("1. Ask what they're building (get specific, not vague)")
    console.print("2. Check project files for tech stack (don't ask what you can infer)")
    console.print("3. Clarify features, constraints, anti-patterns through conversation")
    console.print("4. Summarize into one structured Obra input")
    console.print()
    console.print("[bold]EXAMPLE CONVERSATION[/bold]")
    console.print("[cyan]────────────────────[/cyan]")
    console.print('  User: "Build me an API"')
    console.print('  You:  "What kind? REST, GraphQL? What\'s it for?"')
    console.print('  User: "REST for user management"')
    console.print('  You:  "I see FastAPI in your project. Auth approach?"')
    console.print('  User: "JWT with refresh tokens"')
    console.print('  You:  "Deployment target? Any existing services to integrate?"')
    console.print()
    console.print("  [bold]→ INVOKE:[/bold]")
    console.print('    obra "User management REST API: FastAPI + PostgreSQL.')
    console.print("    JWT auth with refresh tokens, CRUD operations, role-based access.")
    console.print('    Docker Compose deployment. Integrate with auth-service:8000." --stream')
    console.print()
    console.print("[bold]CHECKLIST (what to cover)[/bold]")
    console.print("[cyan]─────────────────────────[/cyan]")
    console.print("Required: Objective, Tech Stack, Features")
    console.print("Optional: Constraints, Integrations, Anti-patterns")
    console.print()
    console.print("Trivial tasks (typos, single-line fixes) → invoke Obra directly")
    console.print()
    console.print("[bold]ADVANCED FLAGS (optional)[/bold]")
    console.print("[cyan]──────────────────────────[/cyan]")
    console.print("Override model/provider for specific tasks:")
    console.print()
    console.print("  --model opus                    Use specific model")
    console.print("  --impl-provider google          Use specific provider")
    console.print("  --thinking-level high           Set reasoning depth")
    console.print()
    console.print("[dim]Run `obra run --help` for complete flag reference[/dim]")
    console.print()
    console.print("[bold]PARALLEL EXECUTION[/bold]")
    console.print("[cyan]──────────────────[/cyan]")
    console.print("Run multiple Obra sessions simultaneously for faster development:")
    console.print()
    console.print("  1. Discover models: [cyan]obra models[/cyan]")
    console.print()
    console.print("  2. Run in separate terminals:")
    console.print('     [dim]Terminal 1:[/dim] obra run "feature A" --model opus')
    console.print('     [dim]Terminal 2:[/dim] obra run "feature B" -p google -m gemini-2.5-flash')
    console.print()
    console.print("  3. Or use environment variables:")
    console.print('     OBRA_MODEL=opus obra run "feature A" &')
    console.print('     OBRA_PROVIDER=google obra run "feature B" &')
    console.print()
    console.print("[dim]Env vars: OBRA_MODEL, OBRA_PROVIDER, OBRA_THINKING_LEVEL[/dim]")
    console.print("[dim]Precedence: CLI flags > env vars > config file[/dim]")
    console.print()
    console.print("[bold]WHILE OBRA RUNS[/bold]")
    console.print("[cyan]───────────────[/cyan]")
    console.print("Monitor progress, validate success, escalate if stuck.")
    console.print("See `obra briefing protocol` for full 11 autonomous behaviors.")
    console.print()
    console.print(
        "[cyan]──────────────────────────────────────────────────────────────────────[/cyan]"
    )
    console.print(
        "[bold]obra briefing quick[/bold]       Essential checklist (~2 min) [green]RECOMMENDED[/green]"
    )
    console.print("obra briefing examples    Good vs bad input examples (10 project types)")
    console.print("obra briefing blueprint   Quick checklist (condensed)")
    console.print("obra briefing questions   Question patterns (detailed)")
    console.print("obra briefing protocol    11 autonomous behaviors")
    console.print("obra briefing full        Complete guide (includes advanced flags reference)")
    console.print(
        "[cyan]══════════════════════════════════════════════════════════════════════[/cyan]"
    )
    console.print()


def _display_blueprint() -> None:
    """Display the condensed blueprint checklist format."""
    console.print()
    console.print("[bold]OBRA INPUT BLUEPRINT (Quick Reference)[/bold]")
    console.print("[cyan]══════════════════════════════════════[/cyan]")
    console.print()
    console.print("First: Run `obra` to see all commands.")
    console.print()
    console.print("[bold]REQUIRED:[/bold]")
    console.print("  □ Objective      What are we building/fixing?")
    console.print("  □ Tech Stack     Languages, frameworks, databases")
    console.print("  □ Features       List of capabilities needed")
    console.print()
    console.print("[bold]RECOMMENDED:[/bold]")
    console.print("  □ Constraints    Performance, security, compliance")
    console.print("  □ Integrations   External services, APIs, existing systems")
    console.print("  □ Anti-patterns  What to avoid")
    console.print()
    console.print("Trivial tasks (typos, single-line fixes) → invoke directly")
    console.print("Design decisions required → gather requirements first")
    console.print()
    console.print("[bold]Example:[/bold]")
    console.print('  obra "E-commerce: React + Node + MongoDB. Features: catalog, cart,')
    console.print('  Stripe. Constraints: <500ms, OWASP. Anti-patterns: no Redux." --stream')
    console.print()


@briefing_app.callback(invoke_without_command=True)
@handle_encoding_errors
def briefing_callback(
    ctx: typer.Context,
    # Hidden aliases for deprecated flags (S2.T3 - backwards compatibility)
    blueprint: bool = typer.Option(
        False,
        "--blueprint",
        hidden=True,
        help="[DEPRECATED] Use 'obra briefing blueprint' instead",
    ),
    protocol: bool = typer.Option(
        False,
        "--protocol",
        hidden=True,
        help="[DEPRECATED] Use 'obra briefing protocol' instead",
    ),
    questions: bool = typer.Option(
        False,
        "--questions",
        hidden=True,
        help="[DEPRECATED] Use 'obra briefing questions' instead",
    ),
    full: bool = typer.Option(
        False,
        "--full",
        hidden=True,
        help="[DEPRECATED] Use 'obra briefing full' instead",
    ),
    path: bool = typer.Option(
        False,
        "--path",
        hidden=True,
        help="[DEPRECATED] Use 'obra briefing path' instead",
    ),
) -> None:
    """Operating guide for AI assistants using Obra.

    Provides blueprint, protocol, and best practices for LLMs (Claude Code,
    Cursor, Gemini) helping users with Obra.

    Default output (no subcommand) includes:
    - Obra description
    - Input blueprint inline
    - 11 autonomous execution behaviors (names)
    - Subcommand reference

    Examples:
        obra briefing              Default: blueprint inline
        obra briefing blueprint    Quick reference checklist
        obra briefing protocol     Full 11 autonomous behaviors
        obra briefing questions    Question patterns by category
        obra briefing full         Complete guide (1700+ lines)
        obra briefing path         Show file location

    Exit Codes:
        0: Always (informational command)
    """
    try:
        # Handle deprecated flag usage with warnings
        if any([blueprint, protocol, questions, full, path]):
            # Map deprecated flags to new subcommands
            if path:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--path', 'obra briefing path')}[/yellow]",
                    style="yellow",
                )
                content, file_path = _load_onboarding_content()
                console.print()
                console.print("[bold]LLM Onboarding Guide Location:[/bold]")
                console.print()
                console.print(f"  {file_path}")
                console.print()
                console.print("Use this path to read the complete guide in your editor or tools.")
                console.print()
                return

            if full:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--full', 'obra briefing full')}[/yellow]",
                    style="yellow",
                )
                content, _ = _load_onboarding_content()
                console.print(content)
                return

            if blueprint:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--blueprint', 'obra briefing blueprint')}[/yellow]",
                    style="yellow",
                )
                _display_blueprint()
                return

            if protocol:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--protocol', 'obra briefing protocol')}[/yellow]",
                    style="yellow",
                )
                content, _ = _load_onboarding_content()
                _display_protocol_full(content)
                return

            if questions:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--questions', 'obra briefing questions')}[/yellow]",
                    style="yellow",
                )
                content, _ = _load_onboarding_content()
                _display_question_patterns(content)
                return

        # If a subcommand is being invoked, let it handle things
        if ctx.invoked_subcommand is not None:
            return

        # Default: show the briefing guide
        _track_briefing_usage("default")
        _display_default_briefing()

    except typer.Exit:
        raise
    except (UnicodeEncodeError, UnicodeDecodeError):
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in briefing command: {e}")
        raise typer.Exit(1) from e


@briefing_app.command(name="quick")
@handle_encoding_errors
def briefing_quick() -> None:
    """Essential input quality checklist (~2 min read, 1,500 tokens).

    Shows a quick reference with minimum required information, quality gates,
    and decision tree for gathering requirements. Recommended starting point
    for AI agents.

    Examples:
        obra briefing quick

    Exit Codes:
        0: Always (informational command)
    """
    try:
        _track_briefing_usage("quick")

        # Load BRIEFING_QUICK.md from package
        try:
            # Try importlib.resources first (Python 3.9+)
            from importlib.resources import files

            quick_content = files("obra").joinpath(".obra/BRIEFING_QUICK.md").read_text()
        except (ImportError, AttributeError):
            # Fallback to pkg_resources for older Python
            import pkg_resources

            quick_content = pkg_resources.resource_string("obra", ".obra/BRIEFING_QUICK.md").decode(
                "utf-8"
            )

        console.print(quick_content)
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in briefing quick: {e}")
        raise typer.Exit(1) from e


@briefing_app.command(name="full")
@handle_encoding_errors
def briefing_full() -> None:
    """Complete LLM onboarding guide (3,600+ lines).

    Outputs the entire LLM_ONBOARDING.md file, which includes:
    - Input blueprint (what to gather from users)
    - Autonomous operation protocol (11 behaviors)
    - Question patterns by category
    - Advanced usage patterns

    Examples:
        obra briefing full
        obra briefing full | head -100

    Exit Codes:
        0: Always (informational command)
    """
    try:
        _track_briefing_usage("full")
        content, _ = _load_onboarding_content()
        console.print(content)
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in briefing full: {e}")
        raise typer.Exit(1) from e


@briefing_app.command(name="blueprint")
@handle_encoding_errors
def briefing_blueprint() -> None:
    """Quick blueprint reference (condensed checklist format).

    Shows a condensed checklist of what to gather from users before
    invoking Obra. Useful as a quick reference during conversations.

    Examples:
        obra briefing blueprint

    Exit Codes:
        0: Always (informational command)
    """
    try:
        _track_briefing_usage("blueprint")
        _display_blueprint()
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in briefing blueprint: {e}")
        raise typer.Exit(1) from e


@briefing_app.command(name="protocol")
@handle_encoding_errors
def briefing_protocol() -> None:
    """Full autonomous execution protocol (11 behaviors detailed).

    Shows the complete autonomous operation protocol that describes
    how LLMs should behave while Obra executes tasks.

    Examples:
        obra briefing protocol

    Exit Codes:
        0: Always (informational command)
    """
    try:
        _track_briefing_usage("protocol")
        content, _ = _load_onboarding_content()
        _display_protocol_full(content)
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in briefing protocol: {e}")
        raise typer.Exit(1) from e


@briefing_app.command(name="questions")
@handle_encoding_errors
def briefing_questions() -> None:
    """Detailed question patterns by category.

    Shows question patterns organized by category to help LLMs
    gather requirements from users effectively.

    Examples:
        obra briefing questions

    Exit Codes:
        0: Always (informational command)
    """
    try:
        _track_briefing_usage("questions")
        content, _ = _load_onboarding_content()
        _display_question_patterns(content)
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in briefing questions: {e}")
        raise typer.Exit(1) from e


@briefing_app.command(name="path")
@handle_encoding_errors
def briefing_path() -> None:
    """Show file path for deep reading.

    Shows the location of the LLM_ONBOARDING.md file so you can
    read it directly in your editor or tools.

    Examples:
        obra briefing path

    Exit Codes:
        0: Always (informational command)
    """
    try:
        _track_briefing_usage("path")
        _, file_path = _load_onboarding_content()
        console.print()
        console.print("[bold]LLM Onboarding Guide Location:[/bold]")
        console.print()
        console.print(f"  {file_path}")
        console.print()
        console.print("Use this path to read the complete guide in your editor or tools.")
        console.print()
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in briefing path: {e}")
        raise typer.Exit(1) from e


@briefing_app.command(name="examples")
@handle_encoding_errors
def briefing_examples() -> None:
    """Good vs bad input examples across project types.

    Shows 20+ worked examples comparing vague (bad) vs specific (good)
    input for common project types: APIs, web apps, CLIs, and more.

    Examples:
        obra briefing examples

    Exit Codes:
        0: Always (informational command)
    """
    try:
        _track_briefing_usage("examples")
        _display_examples()
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in briefing examples: {e}")
        raise typer.Exit(1) from e


def _display_examples() -> None:
    """Display good vs bad input examples for common project types."""
    console.print()
    console.print("[bold]OBRA INPUT EXAMPLES: Good vs Bad[/bold]")
    console.print("[cyan]══════════════════════════════════[/cyan]")
    console.print()
    console.print("Compare [red]BAD[/red] (vague) vs [green]GOOD[/green] (specific) inputs.")
    console.print("Notice: tech stack, features, success criteria, constraints.")
    console.print()

    # Example 1: REST API
    console.print("[bold]1. REST API[/bold]")
    console.print("[cyan]───────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Build me an API"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "User management REST API with FastAPI + PostgreSQL.')
    console.print("         JWT authentication with refresh tokens, CRUD operations")
    console.print("         (create, read, update, delete users), role-based access")
    console.print('         control (admin/user). Docker Compose deployment. Tests >80%."')
    console.print()

    # Example 2: Web Application
    console.print("[bold]2. Web Application[/bold]")
    console.print("[cyan]─────────────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Build a website"')
    console.print()
    console.print(
        '[green]✅ GOOD:[/green] "E-commerce storefront: Next.js 14 + TypeScript frontend,'
    )
    console.print("         Stripe checkout integration, product catalog with search")
    console.print("         and filter by category/price, shopping cart with session")
    console.print("         persistence, responsive design. Vercel deployment.")
    console.print('         Lighthouse score >90."')
    console.print()

    # Example 3: CLI Tool
    console.print("[bold]3. CLI Tool[/bold]")
    console.print("[cyan]───────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Make a CLI"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "Python CLI for log analysis with typer + rich.')
    console.print("         Commands: parse (extract errors/warnings), stats (count by")
    console.print("         level), search (regex filter). Input: file path or stdin.")
    console.print("         Output: colored terminal, optional JSON export.")
    console.print('         --verbose flag for debug info. Tests with pytest."')
    console.print()

    # Example 4: Authentication
    console.print("[bold]4. Authentication Feature[/bold]")
    console.print("[cyan]────────────────────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Add authentication"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "Add JWT authentication to existing Express API:')
    console.print("         Access tokens (15min expiry), refresh tokens (7 day),")
    console.print("         bcrypt password hashing, /register, /login, /refresh,")
    console.print("         /logout endpoints. Auth middleware for protected routes.")
    console.print('         Rate limiting on auth endpoints. Integration tests."')
    console.print()

    # Example 5: Bug Fix
    console.print("[bold]5. Bug Fix[/bold]")
    console.print("[cyan]──────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Fix the bug"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "Fix race condition in src/workers/queue.py:')
    console.print("         Multiple workers calling process_job() simultaneously")
    console.print("         cause duplicate processing. Symptom: same job ID appears")
    console.print("         2-3x in logs. Expected: each job processed exactly once.")
    console.print('         Add Redis SETNX lock or PostgreSQL advisory lock."')
    console.print()

    # Example 6: Database Integration
    console.print("[bold]6. Database Integration[/bold]")
    console.print("[cyan]──────────────────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Add a database"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "Add PostgreSQL to existing FastAPI app:')
    console.print("         SQLAlchemy ORM with async support (asyncpg driver),")
    console.print("         Alembic migrations, connection pooling (5-20 connections),")
    console.print("         models for User, Product, Order with relationships.")
    console.print('         Docker Compose with postgres:15. Seed script for dev data."')
    console.print()

    # Example 7: Testing
    console.print("[bold]7. Testing[/bold]")
    console.print("[cyan]──────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Add tests"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "Add pytest test suite for src/services/payment.py:')
    console.print("         Unit tests for calculate_total(), apply_discount(),")
    console.print("         validate_card(). Integration tests for Stripe API calls")
    console.print("         using VCR cassettes. Edge cases: zero amount, negative,")
    console.print('         expired card, network timeout. Target >90% coverage."')
    console.print()

    # Example 8: Refactoring
    console.print("[bold]8. Refactoring[/bold]")
    console.print("[cyan]─────────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Refactor the code"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "Refactor src/api/handlers.py (800 lines) into modules:')
    console.print("         Split by domain: users.py, products.py, orders.py, auth.py.")
    console.print("         Extract shared validation to validators.py, shared DB")
    console.print("         queries to repositories.py. Keep all existing tests passing.")
    console.print('         No new dependencies. Preserve API contract."')
    console.print()

    # Example 9: Performance
    console.print("[bold]9. Performance Optimization[/bold]")
    console.print("[cyan]──────────────────────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Make it faster"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "Optimize /api/products endpoint (currently 2.5s):')
    console.print("         Add Redis caching (5min TTL) for product listings,")
    console.print("         database query optimization (add indexes on category_id,")
    console.print("         price), pagination (limit 50 per page). Target: <200ms")
    console.print('         p95 response time. Add APM instrumentation."')
    console.print()

    # Example 10: Documentation
    console.print("[bold]10. Documentation[/bold]")
    console.print("[cyan]─────────────────[/cyan]")
    console.print()
    console.print('[red]❌ BAD:[/red]  "Add docs"')
    console.print()
    console.print('[green]✅ GOOD:[/green] "Add OpenAPI documentation to FastAPI endpoints:')
    console.print("         Response schemas for all endpoints, example request/response")
    console.print("         bodies, authentication requirements documented, error")
    console.print("         response codes (400, 401, 403, 404, 500) with descriptions.")
    console.print('         Generate and host Swagger UI at /docs."')
    console.print()

    console.print(
        "[cyan]══════════════════════════════════════════════════════════════════════[/cyan]"
    )
    console.print()
    console.print("[bold]Key Pattern:[/bold] Good input includes:")
    console.print("  • [cyan]Tech stack[/cyan] (language, framework, database)")
    console.print("  • [cyan]Specific features[/cyan] (not 'auth' but 'JWT with refresh tokens')")
    console.print("  • [cyan]Success criteria[/cyan] (testable: '>80% coverage', '<200ms')")
    console.print("  • [cyan]Constraints[/cyan] (deployment target, existing code to preserve)")
    console.print()
    console.print(
        "[dim]💡 Run [/dim][cyan]obra briefing quick[/cyan][dim] for the full checklist[/dim]"
    )
    console.print()


def _display_protocol_full(content: str) -> None:
    """Display the full autonomous execution protocol with all 11 behaviors.

    Args:
        content: Full content of LLM_ONBOARDING.md
    """
    # Extract the Autonomous Operation Protocol section
    lines = content.split("\n")
    in_protocol_section = False
    protocol_lines = []

    for _i, line in enumerate(lines):
        if line.strip() == "## Autonomous Operation Protocol":
            in_protocol_section = True
            continue

        if in_protocol_section:
            # Stop at the next ## heading
            if line.startswith("## ") and not line.startswith("### "):
                break
            protocol_lines.append(line)

    # Display the extracted section
    console.print()
    console.print("[bold cyan]AUTONOMOUS OPERATION PROTOCOL[/bold cyan]")
    console.print()
    console.print("\n".join(protocol_lines))
    console.print()


def _display_question_patterns(content: str) -> None:
    """Display question patterns by category.

    Args:
        content: Full content of LLM_ONBOARDING.md
    """
    # Extract the Question Patterns section
    lines = content.split("\n")
    in_patterns_section = False
    patterns_lines = []

    for line in lines:
        if "## Question Patterns" in line or "## The Questions to Ask" in line:
            in_patterns_section = True
            continue

        if in_patterns_section:
            # Stop at the next ## heading
            if line.startswith("## ") and not line.startswith("### "):
                break
            patterns_lines.append(line)

    # Display the extracted section
    console.print()
    console.print("[bold cyan]QUESTION PATTERNS FOR GATHERING REQUIREMENTS[/bold cyan]")
    console.print()
    console.print("\n".join(patterns_lines))
    console.print()


# =============================================================================
# Authentication Commands
# =============================================================================


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
def login(
    timeout: int = typer.Option(
        300,
        "--timeout",
        "-t",
        help="Timeout in seconds for browser authentication",
    ),
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Don't open browser, just print URL",
    ),
) -> None:
    """Authenticate with Obra.

    Opens your browser to sign in with Google or GitHub.
    After successful authentication, your session is saved locally.

    Examples:
        $ obra login
        $ obra login --no-browser
        $ obra login --timeout 600
    """
    try:
        from obra.auth import login_with_browser, save_auth

        console.print()
        console.print("[bold]Obra Login[/bold]", style="cyan")
        console.print()

        if no_browser:
            console.print("Opening authentication URL...")
            console.print("Copy the URL below and open it in your browser:")
        else:
            console.print("Opening browser for authentication...")

        result = login_with_browser(timeout=timeout, auto_open=not no_browser)

        # Save the authentication
        save_auth(result)

        console.print()
        print_success(f"Logged in as: {result.email}")
        if result.display_name:
            console.print(f"Name: {result.display_name}")

        # Display next steps
        console.print()
        console.print("[bold]Next Steps[/bold]", style="cyan")
        console.print()
        console.print("1. [cyan]Validate your environment[/cyan]")
        console.print("   $ obra config --validate")
        console.print()
        console.print("2. [cyan]Explore documentation[/cyan]")
        console.print("   $ obra docs")
        console.print()
        console.print("3. [cyan]Start your first task[/cyan]")
        console.print('   $ obra run "Add user authentication"')
        console.print()
        console.print("4. [cyan]Check session status[/cyan]")
        console.print("   $ obra status")
        console.print()

    except AuthenticationError as e:
        display_obra_error(e, console)
        logger.error(f"Authentication error in login command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in login command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in login command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in login command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in login command: {e}")
        _print_bug_hint()
        raise typer.Exit(1) from e


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
def logout() -> None:
    """Log out and clear stored credentials.

    Removes your authentication token from the local config.
    You'll need to run 'obra login' again to use Obra.

    Example:
        $ obra logout
    """
    try:
        from obra.auth import clear_auth, get_current_auth

        auth = get_current_auth()
        if not auth:
            print_info("Not currently logged in")
            return

        email = auth.email
        clear_auth()

        console.print()
        print_success(f"Logged out: {email}")
        console.print(f"\n{get_message('recovery.auth.login')}")

    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in logout command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in logout command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except OSError as e:
        print_error(f"Failed to clear authentication: {e}")
        logger.error(f"File I/O error in logout command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in logout command: {e}")
        _print_bug_hint()
        raise typer.Exit(1) from e


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
def whoami() -> None:
    """Show current authentication status.

    Displays the currently authenticated user and token status.

    Example:
        $ obra whoami
    """
    try:
        from obra.auth import get_current_auth
        from obra.config import load_config

        auth = get_current_auth()

        console.print()
        if not auth:
            print_info("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            return

        console.print("[bold]Current User[/bold]", style="cyan")
        console.print()

        table = Table(show_header=False, box=None)
        table.add_column("Field", style="dim")
        table.add_column("Value")

        table.add_row("Email", auth.email)
        if auth.display_name:
            table.add_row("Name", auth.display_name)
        table.add_row("Provider", auth.auth_provider)
        table.add_row("User ID", auth.firebase_uid[:16] + "...")

        console.print(table)

        # Check token status
        from obra.config.loaders import load_auth_state

        auth_state = load_auth_state()
        token_expires = auth_state.get("token_expires_at")
        if token_expires:
            from datetime import datetime

            try:
                expires_dt = datetime.fromisoformat(token_expires.replace("Z", "+00:00"))
                now = datetime.now(UTC)
                if expires_dt > now:
                    remaining = expires_dt - now
                    minutes = int(remaining.total_seconds() / 60)
                    console.print(f"\n[dim]Token expires in {minutes} minutes[/dim]")
                else:
                    console.print(
                        "\n[yellow]Token expired - will auto-refresh on next request[/yellow]"
                    )
            except ValueError:
                pass

    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in whoami command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in whoami command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in whoami command: {e}")
        _print_bug_hint()
        raise typer.Exit(1) from e


# =============================================================================
# Configuration Commands
# =============================================================================


def _run_config_validation(json_output: bool = False, include_schema: bool = False) -> None:
    """Run configuration validation and display results.

    S4.T2: Validates provider CLIs and configuration settings.

    Args:
        json_output: If True, output JSON instead of human-readable format
        include_schema: If True, include schema validation results
    """
    import json

    from obra.config import CONFIG_PATH, LLM_PROVIDERS, check_provider_status
    from obra.config.loaders import load_config_with_warnings

    # Check all providers
    provider_results = {}
    for provider_key in LLM_PROVIDERS:
        status = check_provider_status(provider_key)
        provider_results[provider_key] = {
            "name": LLM_PROVIDERS[provider_key].get("name", provider_key),
            "installed": status.installed,
            "cli_command": status.cli_command,
            "install_hint": status.install_hint,
            "docs_url": status.docs_url,
        }

    # Load configuration
    config_data, warnings, config_exists = load_config_with_warnings()
    config_exists = config_exists or bool(config_data)
    schema = _config_schema()
    schema_warnings = _config_schema_version_warnings(config_data, schema)
    if schema and config_data:
        unknown_keys = _config_unknown_keys(config_data, schema)
        if unknown_keys:
            from obra.config.loaders import get_display_limit

            list_max = get_display_limit("list_preview_max_items")
            preview = ", ".join(sorted(unknown_keys)[:list_max])
            suffix = "..." if len(unknown_keys) > list_max else ""
            warnings.append(
                "Unknown config keys in "
                f"{CONFIG_PATH}: {preview}{suffix}. "
                "Hint: remove or check spelling; see `obra config show --json` for valid keys."
            )

    warnings.extend(schema_warnings)

    schema_issues: ConfigSchemaIssues = {}
    if include_schema and schema:
        schema_issues = {
            "unknown_keys": _config_unknown_keys(config_data, schema),
            "missing_sections": (
                _config_schema_missing_sections(config_data, schema) if config_data else []
            ),
            "type_mismatches": [
                {"path": path, "expected": expected, "actual": actual}
                for path, expected, actual in _config_schema_type_mismatches(config_data, schema)
            ],
        }

    # Overall status
    all_installed = all(p["installed"] for p in provider_results.values())

    if json_output:
        # S4.T4: JSON output structure
        output = {
            "status": "valid" if (all_installed and config_exists) else "issues_found",
            "providers": provider_results,
            "configuration": {
                "path": str(CONFIG_PATH),
                "exists": config_exists,
                "keys_present": list(config_data.keys()) if config_data else [],
            },
            "warnings": warnings,
            "schema": {
                "version": str(schema.get("config_version")) if schema else None,
                "config_version": (config_data.get("config_version") if config_data else None),
                "issues": schema_issues if include_schema else {},
            },
        }
        # Use print() for JSON to avoid Rich console word-wrapping
        print(json.dumps(output, indent=2))
    else:
        # S4.T3: Human-readable output with colors and icons
        _display_validation_human(
            provider_results,
            config_exists,
            str(CONFIG_PATH),
            warnings,
            schema_issues if include_schema else None,
        )


class ConfigSchemaIssues(TypedDict, total=False):
    """Schema validation issues used for CLI output."""

    unknown_keys: list[str]
    missing_sections: list[str]
    type_mismatches: list[dict[str, str]]


def _display_validation_human(
    provider_results: dict,
    config_exists: bool,
    config_path: str,
    warnings: list[str],
    schema_issues: ConfigSchemaIssues | None,
) -> None:
    """Display validation results in human-readable format with colors and icons.

    S4.T3: Display validation with ✓/✗ icons and colored output.

    Args:
        provider_results: Provider validation results
        config_exists: Whether config file exists
        config_path: Path to config file
    """
    console.print()
    console.print("[bold]Configuration Validation[/bold]", style="cyan")
    console.print()

    # Provider CLI checks
    console.print("[bold]Provider CLIs:[/bold]")
    for _provider_key, result in provider_results.items():
        if result["installed"]:
            icon = f"[green]{glyphs.success}[/green]"
            status_text = f"[green]{result['cli_command']} installed[/green]"
        else:
            icon = f"[red]{glyphs.failure}[/red]"
            status_text = f"[red]{result['cli_command']} not found[/red]"
            if result["install_hint"]:
                status_text += f"\n    [dim]{result['install_hint']}[/dim]"

        console.print(f"  {icon} {result['name']}: {status_text}")

    console.print()

    # Configuration file check
    console.print("[bold]Configuration:[/bold]")
    if config_exists:
        icon = f"[green]{glyphs.success}[/green]"
        status_text = f"[green]Config found at {config_path}[/green]"
    else:
        icon = f"[yellow]{glyphs.warning}[/yellow]"
        status_text = "[yellow]No config file (using defaults)[/yellow]"

    console.print(f"  {icon} {status_text}")
    console.print()

    if warnings:
        console.print("[bold]Schema Warnings:[/bold]")
        for warning in warnings:
            console.print(f"  [yellow]{glyphs.warning}[/yellow] {warning}")
        console.print()

    if schema_issues is not None:
        console.print("[bold]Schema Validation:[/bold]")
        unknown: list[str] = schema_issues.get("unknown_keys") or []
        missing: list[str] = schema_issues.get("missing_sections") or []
        mismatches: list[dict[str, str]] = schema_issues.get("type_mismatches") or []

        if not unknown and not missing and not mismatches:
            console.print(f"  [green]{glyphs.success}[/green] No schema issues found")
        else:
            if unknown:
                preview = ", ".join(unknown[:10])
                suffix = "..." if len(unknown) > 10 else ""
                console.print(
                    f"  [yellow]{glyphs.warning}[/yellow] Unknown keys: {preview}{suffix}"
                )
            if missing:
                preview = ", ".join(missing[:10])
                suffix = "..." if len(missing) > 10 else ""
                console.print(
                    f"  [yellow]{glyphs.warning}[/yellow] Missing sections: {preview}{suffix}"
                )
            if mismatches:
                preview = ", ".join(
                    f"{item['path']} ({item['expected']} -> {item['actual']})"
                    for item in mismatches[:5]
                )
                suffix = "..." if len(mismatches) > 5 else ""
                console.print(
                    f"  [yellow]{glyphs.warning}[/yellow] Type mismatches: {preview}{suffix}"
                )
        console.print()

    # Overall status
    all_installed = all(p["installed"] for p in provider_results.values())
    if all_installed and config_exists:
        print_success("All checks passed!")
    elif all_installed:
        print_warning("Providers installed but no config file found (using defaults)")
    else:
        print_warning("Some provider CLIs are not installed")
        console.print(
            "\n[dim]Tip: Install the providers you plan to use with obra run --impl-provider[/dim]"
        )


# Create config subcommand group (S3.T0)
config_app = typer.Typer(
    name="config",
    help="Manage Obra configuration (TUI, show, get, set, reset, validate)",
    invoke_without_command=True,
    rich_markup_mode="rich",
)
app.add_typer(config_app, name="config", rich_help_panel="User Commands")


# Config helper functions (shared by callback and subcommands)
@lru_cache(maxsize=1)
def _config_schema() -> dict[str, object]:
    """Load the packaged default config schema."""
    try:
        from obra.config.explorer.utils import load_default_config_schema

        schema = load_default_config_schema()
        if isinstance(schema, dict):
            return schema
    except Exception:
        return {}
    return {}


@lru_cache(maxsize=1)
def _config_schema_paths() -> set[str]:
    """Cache all schema dot-paths for fast lookup."""
    schema = _config_schema()
    if not schema:
        return set()

    from obra.config.explorer.utils import iter_schema_paths

    return {path for path, _ in iter_schema_paths(schema)}


@lru_cache(maxsize=1)
def _config_deprecated_paths() -> set[str]:
    """Return deprecated config paths that map to new hierarchy."""
    from obra.config.loaders import CONFIG_PATH_ALIASES

    return set(CONFIG_PATH_ALIASES.keys())


def _config_normalize_path(path: str) -> tuple[str, str | None]:
    """Normalize config paths, handling both deprecated and semantic aliases.

    Deprecated aliases generate a warning.
    Semantic aliases (shortcuts) generate an informational message.
    """
    from obra.config.loaders import CONFIG_PATH_ALIASES, SEMANTIC_CONFIG_ALIASES

    # Check deprecated aliases first (these generate warnings)
    if path in CONFIG_PATH_ALIASES:
        canonical = CONFIG_PATH_ALIASES[path]
        return canonical, get_message("warning.deprecation.config_key", old=path, new=canonical)

    # Check semantic aliases (these are shortcuts, no warning)
    if path in SEMANTIC_CONFIG_ALIASES:
        canonical = SEMANTIC_CONFIG_ALIASES[path]
        # Return None for warning - semantic aliases are valid shortcuts
        return canonical, None

    return path, None


def _config_is_known_path(path: str) -> bool:
    """Check if a path exists in the schema (fallback to descriptions)."""
    normalized, _ = _config_normalize_path(path)
    schema_paths = _config_schema_paths()
    if schema_paths:
        return normalized in schema_paths

    from obra.config.explorer.descriptions import get_description

    return get_description(normalized) is not None


def _config_suggest_paths(invalid_path: str) -> str:
    """Suggest valid config paths when an invalid path is provided.

    Returns a hint string like:
    "Valid paths under 'llm': model, type, cli_command, timeout, ..."

    Also detects keywords and suggests semantic aliases when appropriate.
    """
    from obra.config.loaders import SEMANTIC_CONFIG_ALIASES

    normalized, _ = _config_normalize_path(invalid_path)
    schema_paths = _config_schema_paths()

    suggestions: list[str] = []

    # Check if the path matches a semantic alias exactly
    if invalid_path in SEMANTIC_CONFIG_ALIASES:
        canonical = SEMANTIC_CONFIG_ALIASES[invalid_path]
        suggestions.append(f"Did you mean: obra config set {canonical} <value>")
        suggestions.append(f"('{invalid_path}' is a shortcut for '{canonical}')")
        return "\n".join(suggestions)

    # Keyword detection for common use cases (UX-CONFIG-001)
    keywords_to_paths: dict[str, list[tuple[str, str]]] = {
        "security": [
            (
                "features.quality_automation.agents.security_audit.enabled",
                "Enable/disable security audits",
            ),
            ("agents.security", "Shortcut for security_audit agent"),
        ],
        "doc": [
            (
                "features.quality_automation.agents.doc_audit.enabled",
                "Enable/disable documentation audits",
            ),
            ("agents.doc_audit", "Shortcut for doc_audit agent"),
        ],
        "documentation": [
            (
                "features.quality_automation.agents.doc_audit.enabled",
                "Enable/disable documentation audits",
            ),
            ("agents.documentation", "Shortcut for doc_audit agent"),
        ],
        "review": [
            (
                "features.quality_automation.agents.code_review.enabled",
                "Enable/disable code review",
            ),
            (
                "features.quality_automation.agents.security_audit.enabled",
                "Security reviews",
            ),
            (
                "features.quality_automation.agents.doc_audit.enabled",
                "Documentation reviews",
            ),
        ],
        "agent": [
            ("features.quality_automation.agents", "All agent settings"),
            ("agent.timeout", "Implementation execution timeout"),
        ],
        "model": [
            ("llm.model", "LLM model selection (sonnet, opus, haiku)"),
        ],
        "orchestrator": [
            ("llm.model", "Orchestrator uses the same LLM as configured in llm.model"),
        ],
        "timeout": [
            ("orchestration.timeouts.agent_execution_s", "Agent execution timeout"),
            ("orchestration.timeouts.cli_runner_s", "CLI runner timeout"),
            ("llm.timeout", "LLM timeout"),
        ],
        "budget": [
            ("orchestration.budgets.enabled", "Enable/disable budget framework"),
            ("workflow.budgets.tokens", "Token budget settings"),
        ],
    }

    # Check for keyword matches in the invalid path
    path_lower = invalid_path.lower()
    for keyword, paths in keywords_to_paths.items():
        if keyword in path_lower:
            suggestions.append(f"Related settings for '{keyword}':")
            for path, desc in paths:
                suggestions.append(f"  • {path} - {desc}")
            suggestions.append("")  # blank line
            break

    if not schema_paths:
        return "\n".join(suggestions) if suggestions else ""

    # Extract the prefix (e.g., "llm" from "llm.orchestrator_model")
    parts = normalized.split(".")
    if not parts:
        return "\n".join(suggestions) if suggestions else ""

    # Try progressively shorter prefixes to find valid siblings
    for i in range(len(parts) - 1, 0, -1):
        prefix = ".".join(parts[:i])
        prefix_dot = f"{prefix}."

        # Find all paths that start with this prefix
        matching = sorted(p for p in schema_paths if p.startswith(prefix_dot) and p != normalized)

        if matching:
            # Extract immediate children (next segment after prefix)
            children = set()
            for p in matching:
                remainder = p[len(prefix_dot) :]
                child = remainder.split(".")[0]
                children.add(child)

            # Format the hint
            sorted_children = sorted(children)
            if len(sorted_children) > 6:
                display = ", ".join(sorted_children[:6]) + ", ..."
            else:
                display = ", ".join(sorted_children)

            suggestions.append(f"Valid paths under '{prefix}': {display}")
            break

    # If no prefix matched, show top-level keys
    if not any("Valid paths" in s for s in suggestions):
        top_level = sorted({p.split(".")[0] for p in schema_paths})
        if top_level:
            if len(top_level) > 6:
                display = ", ".join(top_level[:6]) + ", ..."
            else:
                display = ", ".join(top_level)
            suggestions.append(f"Top-level config keys: {display}")

    # Add hint about search command
    if suggestions:
        suggestions.append("")
        suggestions.append("Tip: Use 'obra config search <keyword>' to find related settings.")

    return "\n".join(suggestions)


def _config_get_schema_value(path: str) -> object | None:
    """Get a schema value by dotted path."""
    current: object = _config_schema()
    for part in path.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def _config_schema_has_children(path: str) -> bool:
    """Check if a schema path has children."""
    normalized, _ = _config_normalize_path(path)
    schema_paths = _config_schema_paths()
    if schema_paths:
        prefix = f"{normalized}."
        return any(other.startswith(prefix) for other in schema_paths)

    from obra.config.explorer.descriptions import get_all_paths

    prefix = f"{normalized}."
    return any(other.startswith(prefix) for other in get_all_paths())


def _config_unknown_keys(
    config: dict[str, object],
    schema: dict[str, object],
    prefix: str = "",
) -> list[str]:
    """Return config keys not present in the schema."""
    unknown: list[str] = []
    for key, value in config.items():
        path = f"{prefix}.{key}" if prefix else key
        if key not in schema:
            if path in _config_deprecated_paths():
                continue
            unknown.append(path)
            continue
        schema_value = schema.get(key)
        if isinstance(value, dict) and isinstance(schema_value, dict):
            unknown.extend(_config_unknown_keys(value, schema_value, path))
    return unknown


def _config_schema_type_mismatches(
    config: dict[str, object],
    schema: dict[str, object],
    prefix: str = "",
) -> list[tuple[str, str, str]]:
    """Return (path, expected_type, actual_type) for schema mismatches."""
    mismatches: list[tuple[str, str, str]] = []
    for key, value in config.items():
        if key not in schema:
            continue
        path = f"{prefix}.{key}" if prefix else key
        schema_value = schema.get(key)

        if isinstance(schema_value, dict):
            if isinstance(value, dict):
                mismatches.extend(_config_schema_type_mismatches(value, schema_value, path))
            else:
                mismatches.append((path, "object", type(value).__name__))
            continue

        if schema_value is None:
            continue

        if isinstance(schema_value, list):
            if not isinstance(value, list):
                mismatches.append((path, "list", type(value).__name__))
            continue

        if isinstance(schema_value, bool):
            if not isinstance(value, bool):
                mismatches.append((path, "bool", type(value).__name__))
            continue

        if isinstance(schema_value, int):
            if not isinstance(value, int) or isinstance(value, bool):
                mismatches.append((path, "int", type(value).__name__))
            continue

        if isinstance(schema_value, float):
            if not isinstance(value, (int, float)) or isinstance(value, bool):
                mismatches.append((path, "float", type(value).__name__))
            continue

        if isinstance(schema_value, str):
            if not isinstance(value, str):
                mismatches.append((path, "str", type(value).__name__))
            continue

        if not isinstance(value, type(schema_value)):
            mismatches.append((path, type(schema_value).__name__, type(value).__name__))

    return mismatches


def _config_schema_missing_sections(
    config: dict[str, object],
    schema: dict[str, object],
) -> list[str]:
    """Return top-level schema sections missing from config."""
    missing: list[str] = []
    for key, value in schema.items():
        if isinstance(value, dict) and key not in config:
            missing.append(key)
    return missing


def _config_schema_version_warnings(
    config: dict[str, object],
    schema: dict[str, object],
) -> list[str]:
    """Return schema version warnings based on config_version."""
    warnings: list[str] = []
    schema_version = schema.get("config_version")
    if schema_version is None:
        return warnings

    expected = str(schema_version)
    current = config.get("config_version")
    if current is None:
        if config:
            warnings.append(
                f"Config schema version missing. Add config_version: {expected} to your config."
            )
        return warnings

    if str(current) != expected:
        warnings.append(
            f"Config schema version mismatch (config={current}, expected={expected}). "
            "Update your config to the latest schema."
        )

    return warnings


def _config_emit_warnings(warnings: list[str]) -> None:
    """Emit warnings for config load or schema issues."""
    for warning in warnings:
        err_console.print(f"[yellow]Warning:[/yellow] {warning}", style="yellow")


def _config_emit_error(message: str, detail: str = "") -> None:
    """Emit config error to stderr."""
    prefix = "Error: "
    print(f"{prefix}{message}", file=sys.stderr)
    if detail:
        print(detail, file=sys.stderr)


def _config_get_nested_value(config: dict[str, object], path: str) -> object | None:
    """Get nested value from config dict by dotted path."""
    parts = path.split(".")
    current: object = config
    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def _config_set_nested_value(config: dict[str, object], path: str, value: object) -> None:
    """Set nested value in config dict by dotted path."""
    parts = path.split(".")
    current: dict[str, object] = config
    for part in parts[:-1]:
        if part not in current or not isinstance(current[part], dict):
            current[part] = {}
        current = current[part]  # type: ignore[assignment]
    current[parts[-1]] = value


def _ensure_dict_section(config: dict[str, object], key: str) -> dict[str, object]:
    """Ensure a nested config section is a dict, replacing invalid values."""
    existing = config.get(key)
    if isinstance(existing, dict):
        return existing
    new_section: dict[str, object] = {}
    config[key] = new_section
    return new_section


def _config_flatten(data: dict[str, object], prefix: str = "") -> dict[str, object]:
    """Flatten nested config dict to dotted paths."""
    flat: dict[str, object] = {}
    for key, value in data.items():
        path = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            flat.update(_config_flatten(value, path))
        else:
            flat[path] = value
    return flat


def _config_apply_defaults(config_data: dict[str, object]) -> dict[str, object]:
    """Apply default values to config dict."""
    import copy

    from obra.config.explorer.descriptions import CONFIG_DEFAULTS

    schema = _config_schema()
    if schema:
        try:
            from obra.config.explorer.utils import merge_with_default_schema

            merged_with_defaults = merge_with_default_schema(cast(dict[str, object], config_data))
            return cast(dict[str, object], merged_with_defaults)
        except Exception:
            pass

    merged = copy.deepcopy(config_data)
    for path, default_value in CONFIG_DEFAULTS.items():
        if _config_get_nested_value(merged, path) is None:
            _config_set_nested_value(merged, path, default_value)
    return merged


def _config_format_human_value(value: object) -> str:
    """Format value for human-readable output."""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _config_redact_value(path: str, value: object) -> object:
    """Redact sensitive values."""
    from obra.config.explorer.descriptions import is_sensitive

    if is_sensitive(path):
        return "***"
    return value


def _config_redact(data: dict[str, object]) -> dict[str, object]:
    """Redact all sensitive values in config dict."""
    redacted: dict[str, object] = {}
    for path, value in _config_flatten(data).items():
        _config_set_nested_value(redacted, path, _config_redact_value(path, value))
    return redacted


def _config_prune_deprecated_paths(config_data: dict[str, object]) -> dict[str, object]:
    """Remove deprecated top-level paths from config display."""
    pruned = dict(config_data)
    for path in _config_deprecated_paths():
        pruned.pop(path, None)
    return pruned


def _config_parse_value(raw: str) -> object:
    """Parse string value to appropriate type."""
    stripped = raw.strip()
    if len(stripped) >= 2 and stripped[0] == stripped[-1] and stripped[0] in ("'", '"'):
        return stripped[1:-1]
    lower = stripped.lower()
    if lower == "true":
        return True
    if lower == "false":
        return False
    if re.fullmatch(r"-?\d+", stripped):
        return int(stripped)
    if re.fullmatch(r"-?\d+\.\d+", stripped):
        return float(stripped)
    return stripped


def _config_infer_expected_type(path: str, current_config: dict[str, object]) -> type | None:
    """Infer expected type for a config path."""
    schema_value = _config_get_schema_value(path)
    if isinstance(schema_value, (bool, int, float, list, dict, str)):
        return type(schema_value)

    existing = _config_get_nested_value(current_config, path)
    if isinstance(existing, (bool, int, float, list, dict, str)):
        return type(existing)
    return None


def _config_path_has_children(path: str) -> bool:
    """Check if a config path has child paths."""
    return _config_schema_has_children(path)


def _resolve_project_id_for_layers() -> tuple[str | None, list[str]]:
    """Resolve a project identifier for config layers using the current working dir."""
    try:
        from obra.intent.storage import IntentStorage

        return IntentStorage().get_project_id(Path.cwd()), []
    except Exception as exc:
        return None, [f"Unable to resolve project ID for config layers: {exc}"]


def _config_load_scope(
    scope: str,
    warn_unknown_keys: bool = False,
) -> tuple[dict[str, object], bool, dict[str, object], list[str], dict[str, str]]:
    """Load config for the given scope (local, project, or server)."""
    from obra.config import CONFIG_PATH
    from obra.config.loaders import (
        get_project_layer_path,
        load_config,
        load_layered_config,
        load_project_layer,
    )

    if scope == "server":
        from obra.api import APIClient

        api_client = APIClient.from_config()
        server_config = api_client.get_user_config()
        return (
            server_config.get("resolved", {}),
            True,
            server_config.get("resolved", {}),
            [],
            {},
        )

    warnings: list[str] = []
    origins: dict[str, str] = {}

    if scope == "project":
        project_id, id_warnings = _resolve_project_id_for_layers()
        warnings.extend(id_warnings)
        if not project_id:
            return {}, False, {}, warnings, origins
        project_config, layer_warnings, config_exists = load_project_layer(project_id)
        warnings.extend(layer_warnings)
        if warn_unknown_keys:
            schema = _config_schema()
            if schema and project_config:
                unknown_keys = _config_unknown_keys(project_config, schema)
                if unknown_keys:
                    preview = ", ".join(sorted(unknown_keys)[:10])
                    suffix = "..." if len(unknown_keys) > 10 else ""
                    warnings.append(
                        "Unknown config keys in "
                        f"{get_project_layer_path(project_id)}: {preview}{suffix}. "
                        "Hint: remove or check spelling; see `obra config show --json` for valid keys."
                    )
        for path in _config_flatten(project_config):
            origins[path] = "project"
        return project_config, config_exists, project_config, warnings, origins

    config_data, origins, warnings = load_layered_config(include_defaults=True)
    raw_config = load_config()
    config_exists = CONFIG_PATH.exists()
    if warn_unknown_keys:
        schema = _config_schema()
        if schema and raw_config:
            unknown_keys = _config_unknown_keys(raw_config, schema)
            if unknown_keys:
                preview = ", ".join(sorted(unknown_keys)[:10])
                suffix = "..." if len(unknown_keys) > 10 else ""
                warnings.append(
                    "Unknown config keys in "
                    f"{CONFIG_PATH}: {preview}{suffix}. "
                    "Hint: remove or check spelling; see `obra config show --json` for valid keys."
                )
    return config_data, config_exists, raw_config, warnings, origins


def _config_print_show(
    config_data: dict[str, object],
    scope: str,
    json_output: bool,
    origins: dict[str, str] | None = None,
    verbose: bool = False,
) -> None:
    """Print config in show format."""
    import json

    redacted = _config_redact(_config_prune_deprecated_paths(config_data))
    if json_output:
        payload: dict[str, object] = {"scope": scope, "data": redacted}
        if verbose and origins is not None:
            payload["origins"] = origins
        print(json.dumps(payload, ensure_ascii=True))
        return

    for path, value in sorted(_config_flatten(redacted).items()):
        if verbose and origins is not None:
            layer = origins.get(path, "unknown")
            print(f"{path}: {_config_format_human_value(value)}  [{layer}]")
        else:
            print(f"{path}: {_config_format_human_value(value)}")


def _maybe_emit_ollama_fast_tip(config_data: dict[str, object] | None = None) -> None:
    """Emit a hint about the ollama-fast profile for local performance tuning."""
    active_profile = os.environ.get("OBRA_PROFILE", "").strip()
    config_profile = None
    if isinstance(config_data, dict):
        config_profile = config_data.get("profile_name") or config_data.get("profile")
        if config_profile is None:
            profiles_section = config_data.get("profiles")
            if isinstance(profiles_section, dict):
                config_profile = profiles_section.get("default_profile")
    if active_profile == "ollama-fast" or config_profile == "ollama-fast":
        return
    console.print(
        "[dim]Tip: Local Ollama can be slow. Try `obra --profile ollama-fast` "
        "or copy settings from config/profiles/ollama-fast.yaml for faster runs.[/dim]"
    )


def _config_launch_tui(debug: bool = False) -> None:
    """Launch the interactive config TUI.

    Args:
        debug: Enable debug logging for diagnosing config change issues.
    """
    from obra.config.loaders import load_layered_config

    try:
        from obra.config.explorer import run_explorer

        # Load local config and apply defaults so all settings are visible
        # (matches VS Code, Firefox, Docker pattern - show all settings with defaults)
        local_config, origins, warnings = load_layered_config(include_defaults=True)
        if warnings:
            for warning in warnings:
                logger.warning("Config layer warning: %s", warning)
        try:
            from obra.config.loaders import CONFIG_PATH_ALIASES

            for legacy_path in CONFIG_PATH_ALIASES:
                local_config.pop(legacy_path, None)
        except Exception:
            pass

        # Try to get server config if authenticated
        server_config: dict = {}
        api_client = None
        try:
            from obra.api import APIClient

            api_client = APIClient.from_config(pool_retries=False)
            config_data = api_client.get_user_config(retry=False, timeout=5)
            server_config = config_data.get("resolved", {})
            server_config["_preset"] = config_data.get("preset", "unknown")
        except (APIError, ConfigurationError, ObraConnectionError):
            # Server unavailable or not authenticated - offline mode
            logger.debug("Server config unavailable, using offline mode")
        except typer.Exit:
            raise
        except Exception as e:
            # Log unexpected errors but continue in offline mode
            logger.warning(f"Unexpected error fetching server config: {e}")

        run_explorer(
            local_config=local_config,
            server_config=server_config,
            api_client=api_client,
            origins=origins,
            debug=debug,
        )
    except ImportError:
        print_error("Config explorer not available")
        console.print("\nUse 'obra config show' to view current configuration.")
        console.print("Edit ~/.obra/config-layers/01-user.yaml directly to make changes.")
        raise typer.Exit(1) from None


@config_app.callback(invoke_without_command=True)
@handle_encoding_errors
def config_callback(
    ctx: typer.Context,
    # Debug flag for diagnosing config change issues
    debug: bool = typer.Option(
        False,
        "--debug",
        "-d",
        help="Enable debug logging to ~/.obra/logs/config-explorer.log",
    ),
    # Hidden aliases for deprecated flags (S3.T2 - backwards compatibility)
    show: bool = typer.Option(
        False,
        "--show",
        "-s",
        hidden=True,
        help="[DEPRECATED] Use 'obra config show' instead",
    ),
    get_path: str | None = typer.Option(
        None,
        "--get",
        hidden=True,
        help="[DEPRECATED] Use 'obra config get <path>' instead",
    ),
    set_path: str | None = typer.Option(
        None,
        "--set",
        hidden=True,
        help="[DEPRECATED] Use 'obra config set <path> <value>' instead",
    ),
    set_value: str | None = typer.Option(
        None,
        "--value",
        hidden=True,
        help="[DEPRECATED] Value for --set (use 'obra config set <path> <value>' instead)",
    ),
    reset: bool = typer.Option(
        False,
        "--reset",
        hidden=True,
        help="[DEPRECATED] Use 'obra config reset' instead",
    ),
    validate: bool = typer.Option(
        False,
        "--validate",
        hidden=True,
        help="[DEPRECATED] Use 'obra config validate' instead",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        hidden=True,
        help="[DEPRECATED] Use subcommands with --json instead",
    ),
    confirm: bool = typer.Option(False, "--confirm", hidden=True),
    scope: str = typer.Option("local", "--scope", hidden=True),
    verbose: bool = typer.Option(False, "--verbose", "-v", hidden=True),
) -> None:
    """Manage Obra configuration.

    Without subcommands, launches the interactive configuration TUI.

    Subcommands:
        show      - Display current configuration
        get       - Get value for a specific config path
        set       - Set a config value
        reset     - Reset configuration to defaults
        validate  - Validate provider CLIs and configuration

    Examples:
        obra config                              # Launch TUI
        obra config show                         # Show all config
        obra config show --json                  # Show as JSON
        obra config get llm.orchestrator.provider
        obra config set llm.orchestrator.provider openai
        obra config reset
        obra config validate
    """
    try:
        import json

        from obra.config import save_config
        from obra.config.explorer.descriptions import get_choices

        # Handle deprecated flag usage with warnings (S3.T2)
        deprecated_flags = [validate, reset, show, bool(get_path), bool(set_path)]
        if any(deprecated_flags):
            # Validate flag combinations
            if sum(1 for flag in deprecated_flags if flag) > 1:
                _config_emit_error(
                    "Only one of --show, --get, --set, --reset, or --validate may be used at a time"
                )
                raise typer.Exit(2)

            if confirm and not set_path:
                _config_emit_error("--confirm is only valid with --set")
                raise typer.Exit(2)

            if set_path and json_output and not confirm:
                _config_emit_error("--set --json requires --confirm")
                raise typer.Exit(2)

            if json_output and not (validate or show or get_path or (set_path and confirm)):
                _config_emit_error(
                    "--json is only valid with --show, --get, --validate, or --set --confirm"
                )
                raise typer.Exit(2)

            if scope not in ("local", "project", "server"):
                _config_emit_error("Invalid scope. Use --scope local, project, or server")
                raise typer.Exit(2)

            if set_path:
                _config_emit_error(
                    f"{build_deprecation_warning('--set', 'obra config set <path> <value>')}"
                )
                raise typer.Exit(2)

            # Handle --validate (deprecated)
            if validate:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--validate', 'obra config validate')}[/yellow]",
                    style="yellow",
                )
                _run_config_validation(json_output=json_output)
                return

            # Handle --reset (deprecated)
            if reset:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--reset', 'obra config reset')}[/yellow]",
                    style="yellow",
                )
                # C14: Check for non-interactive mode before prompting
                if not sys.stdin.isatty():
                    console.print(
                        "Non-interactive mode: skipping reset confirmation (defaulting to cancel)"
                    )
                    return

                do_reset = typer.confirm(get_message("prompt.confirm.reset_config"))
                if not do_reset:
                    console.print("Cancelled")
                    return

                save_config({})
                print_success("Configuration reset to defaults")
                return

            # Handle --show (deprecated)
            if show:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--show', 'obra config show')}[/yellow]",
                    style="yellow",
                )
                config_data, _, _, warnings, origins = _config_load_scope(
                    scope, warn_unknown_keys=True
                )
                _config_emit_warnings(warnings)
                _config_print_show(
                    config_data, scope, json_output, origins=origins, verbose=verbose
                )
                return

            # Handle --get (deprecated)
            if get_path:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--get', f'obra config get {get_path}')}[/yellow]",
                    style="yellow",
                )
                normalized_path, warning = _config_normalize_path(get_path)
                if warning:
                    _config_emit_warnings([warning])
                if not _config_is_known_path(normalized_path):
                    _config_emit_error(
                        f"Unknown config path '{get_path}'",
                        _config_suggest_paths(get_path),
                    )
                    raise typer.Exit(1)

                config_data, _, _, warnings, _ = _config_load_scope(scope)
                _config_emit_warnings(warnings)
                value = _config_get_nested_value(config_data, normalized_path)
                value = _config_redact_value(normalized_path, value)

                if json_output:
                    payload = {"scope": scope, "data": {normalized_path: value}}
                    print(json.dumps(payload, ensure_ascii=True))
                else:
                    print(_config_format_human_value(value))
                return

            # Handle --set (deprecated)
            if set_path:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--set', f'obra config set {set_path} <value>')}[/yellow]",
                    style="yellow",
                )
                normalized_path, warning = _config_normalize_path(set_path)
                if warning:
                    _config_emit_warnings([warning])
                if not _config_is_known_path(normalized_path):
                    _config_emit_error(
                        f"Unknown config path '{set_path}'",
                        _config_suggest_paths(set_path),
                    )
                    raise typer.Exit(1)

                if _config_path_has_children(normalized_path):
                    _config_emit_error(f"Cannot set non-leaf config path '{set_path}'")
                    raise typer.Exit(1)

                config_data, _, _, warnings, _ = _config_load_scope(scope)
                _config_emit_warnings(warnings)
                raw_value = set_value or ""
                choices = get_choices(normalized_path, config_data)
                if choices and raw_value not in choices:
                    _config_emit_error(
                        f"Invalid value '{raw_value}' for {normalized_path}",
                        f"Valid choices: {', '.join(choices)}",
                    )
                    raise typer.Exit(1)

                parsed_value = _config_parse_value(raw_value)
                expected_type = _config_infer_expected_type(normalized_path, config_data)
                if expected_type is bool and not isinstance(parsed_value, bool):
                    _config_emit_error(f"Expected boolean for {normalized_path}, got '{raw_value}'")
                    raise typer.Exit(1)
                if expected_type is int and not isinstance(parsed_value, int):
                    _config_emit_error(f"Expected integer for {normalized_path}, got '{raw_value}'")
                    raise typer.Exit(1)
                if expected_type is float and not isinstance(parsed_value, (int, float)):
                    _config_emit_error(f"Expected number for {normalized_path}, got '{raw_value}'")
                    raise typer.Exit(1)

                if scope == "server":
                    from obra.api import APIClient

                    api_client = APIClient.from_config()
                    server_config = api_client.update_user_config(
                        overrides={normalized_path: parsed_value}
                    )
                    config_data = server_config.get("resolved", {})
                elif scope == "project":
                    from obra.config.loaders import get_project_layer_path

                    project_id, id_warnings = _resolve_project_id_for_layers()
                    _config_emit_warnings(id_warnings)
                    if not project_id:
                        _config_emit_error("Unable to resolve project ID for project scope.")
                        raise typer.Exit(1)
                    local_config = {}
                    _config_set_nested_value(local_config, normalized_path, parsed_value)
                    project_path = get_project_layer_path(project_id)
                    project_path.parent.mkdir(parents=True, exist_ok=True)
                    project_path.write_text(
                        yaml.safe_dump(local_config, default_flow_style=False, sort_keys=False),
                        encoding="utf-8",
                    )
                    config_data = local_config
                else:
                    local_config = load_config()
                    _config_set_nested_value(local_config, normalized_path, parsed_value)
                    save_config(local_config)
                    config_data = _config_apply_defaults(local_config)

                if not json_output:
                    print_success(f"Set {normalized_path} = {raw_value}")
                if confirm:
                    _config_print_show(config_data, scope, json_output)
                return

        # If no subcommand was invoked, launch TUI (default behavior)
        if ctx.invoked_subcommand is None:
            _config_launch_tui(debug=debug)

    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in config command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in config command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except OSError as e:
        print_error(f"Failed to access configuration file: {e}")
        logger.error(f"File I/O error in config command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in config command: {e}")
        raise typer.Exit(1) from e


# Config subcommands (S3.T1)
@config_app.command(name="show")
@handle_encoding_errors
def config_show(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    scope: str = typer.Option("local", "--scope", help="Config scope: local, project, or server"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show where each value comes from"),
) -> None:
    """Display current configuration.

    Shows all configuration values with their current settings.
    Use --json for machine-readable output.
    Use --scope server to show server-side configuration.
    Use --scope project to show project-layer overrides.

    Examples:
        obra config show
        obra config show --json
        obra config show --scope server
        obra config show --scope project
        obra config show --verbose

    Exit Codes:
        0: Success
        1: Configuration error
    """
    try:
        if scope not in ("local", "project", "server"):
            _config_emit_error("Invalid scope. Use --scope local, project, or server")
            raise typer.Exit(2)

        config_data, _, _, warnings, origins = _config_load_scope(scope, warn_unknown_keys=True)
        _config_emit_warnings(warnings)
        _config_print_show(config_data, scope, json_output, origins=origins, verbose=verbose)

    except ConfigurationError as e:
        display_obra_error(e, console)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in config show: {e}")
        raise typer.Exit(1) from e


@config_app.command(name="list")
@handle_encoding_errors
def config_list(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    scope: str = typer.Option("local", "--scope", help="Config scope: local, project, or server"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show where each value comes from"),
) -> None:
    """List all configuration values (alias for 'show').

    This is an alias for 'obra config show' to match common CLI patterns.

    Examples:
        obra config list
        obra config list --json
        obra config list --scope server

    Exit Codes:
        0: Success
        1: Configuration error
    """
    # Delegate to config_show
    config_show(json_output=json_output, scope=scope, verbose=verbose)


@config_app.command(name="get")
@handle_encoding_errors
def config_get(
    path: str = typer.Argument(..., help="Configuration path (e.g., llm.orchestrator.provider)"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    scope: str = typer.Option("local", "--scope", help="Config scope: local, project, or server"),
) -> None:
    """Get value for a specific configuration path.

    Retrieves the value of a single configuration key.
    Use dotted paths to access nested values.

    Examples:
        obra config get llm.orchestrator.provider
        obra config get llm.orchestrator.model --json
        obra config get api.timeout --scope server
        obra config get api.timeout --scope project

    Exit Codes:
        0: Success
        1: Unknown path or error
    """
    try:
        import json

        if scope not in ("local", "project", "server"):
            _config_emit_error("Invalid scope. Use --scope local, project, or server")
            raise typer.Exit(2)

        normalized_path, warning = _config_normalize_path(path)
        if warning:
            _config_emit_warnings([warning])
        if not _config_is_known_path(normalized_path):
            _config_emit_error(
                f"Unknown config path '{path}'",
                _config_suggest_paths(path),
            )
            raise typer.Exit(1)

        config_data, _, _, warnings, _ = _config_load_scope(scope)
        _config_emit_warnings(warnings)
        value = _config_get_nested_value(config_data, normalized_path)
        value = _config_redact_value(normalized_path, value)

        if json_output:
            payload = {"scope": scope, "data": {normalized_path: value}}
            print(json.dumps(payload, ensure_ascii=True))
        else:
            print(_config_format_human_value(value))

    except ConfigurationError as e:
        display_obra_error(e, console)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in config get: {e}")
        raise typer.Exit(1) from e


@config_app.command(name="set")
@handle_encoding_errors
def config_set(
    path: str = typer.Argument(..., help="Configuration path to set"),
    value: str = typer.Argument(..., help="Value to set"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON after setting"),
    scope: str = typer.Option("local", "--scope", help="Config scope: local, project, or server"),
    confirm: bool = typer.Option(False, "--confirm", help="Show config after changes"),
) -> None:
    """Set a configuration value.

    Sets a single configuration key to the specified value.
    Values are automatically parsed (true/false become booleans, numbers stay numbers).

    Examples:
        obra config set llm.orchestrator.provider openai
        obra config set api.timeout 30
        obra config set api.timeout 30 --scope project
        obra config set debug true --confirm

    Exit Codes:
        0: Success
        1: Invalid path, value, or error
    """
    try:
        from obra.config import save_config
        from obra.config.explorer.descriptions import (
            get_choices,
            get_lock_reason,
            is_locked,
        )

        if scope not in ("local", "project", "server"):
            _config_emit_error("Invalid scope. Use --scope local, project, or server")
            raise typer.Exit(2)

        normalized_path, warning = _config_normalize_path(path)
        if warning:
            _config_emit_warnings([warning])
        if not _config_is_known_path(normalized_path):
            _config_emit_error(
                f"Unknown config path '{path}'",
                _config_suggest_paths(path),
            )
            raise typer.Exit(1)

        if _config_path_has_children(normalized_path):
            _config_emit_error(f"Cannot set non-leaf config path '{path}'")
            raise typer.Exit(1)

        config_data, _, raw_config, warnings, _ = _config_load_scope(scope)
        _config_emit_warnings(warnings)
        if is_locked(normalized_path):
            reason = get_lock_reason(normalized_path) or "This setting is locked."
            _config_emit_error(reason)
            raise typer.Exit(1)
        raw_value = value
        choices = get_choices(normalized_path, config_data)
        if choices and raw_value not in choices:
            _config_emit_error(
                f"Invalid value '{raw_value}' for {normalized_path}",
                f"Valid choices: {', '.join(choices)}",
            )
            raise typer.Exit(1)

        parsed_value = _config_parse_value(raw_value)
        expected_type = _config_infer_expected_type(normalized_path, config_data)
        if expected_type is bool and not isinstance(parsed_value, bool):
            _config_emit_error(f"Expected boolean for {normalized_path}, got '{raw_value}'")
            raise typer.Exit(1)
        if expected_type is int and not isinstance(parsed_value, int):
            _config_emit_error(f"Expected integer for {normalized_path}, got '{raw_value}'")
            raise typer.Exit(1)
        if expected_type is float and not isinstance(parsed_value, (int, float)):
            _config_emit_error(f"Expected number for {normalized_path}, got '{raw_value}'")
            raise typer.Exit(1)

        # ISSUE-SAAS-052: Auto-set provider when setting a model that implies a different provider
        # This ensures `obra config set llm.model gpt-5.2-codex` correctly switches to openai
        model_paths = {
            "llm.model",
            "llm.orchestrator.model",
            "llm.implementation.model",
        }
        auto_set_provider_path: str | None = None
        inferred_provider: str | None = None
        if normalized_path in model_paths and isinstance(parsed_value, str):
            from obra.config.llm import infer_provider_from_model

            inferred_provider = infer_provider_from_model(parsed_value)
            if inferred_provider:
                # Determine which provider to check against
                if normalized_path == "llm.orchestrator.model":
                    provider_path = "llm.orchestrator.provider"
                elif normalized_path == "llm.implementation.model":
                    provider_path = "llm.implementation.provider"
                else:
                    provider_path = "llm.provider"

                current_provider = _config_get_nested_value(config_data, provider_path)
                if current_provider != inferred_provider:
                    # Auto-set the provider to match the model
                    auto_set_provider_path = provider_path
                    _config_set_nested_value(raw_config, provider_path, inferred_provider)
                    console.print(
                        f"[cyan]Auto-detected:[/cyan] Setting {provider_path} = {inferred_provider} "
                        f"(inferred from model '{parsed_value}')"
                    )

        if scope == "server":
            from obra.api import APIClient

            api_client = APIClient.from_config()
            overrides: dict[str, object] = {normalized_path: parsed_value}
            # Include auto-detected provider in server update
            if auto_set_provider_path and inferred_provider:
                overrides[auto_set_provider_path] = inferred_provider
            server_config = api_client.update_user_config(overrides=overrides)
            config_data = server_config.get("resolved", {})
        else:
            _config_set_nested_value(raw_config, normalized_path, parsed_value)
            # Apply OpenAI-specific git config when provider is set (directly or auto-detected)
            provider_set_to_openai = (
                normalized_path
                in (
                    "llm.orchestrator.provider",
                    "llm.implementation.provider",
                    "llm.provider",
                )
                and parsed_value == "openai"
            ) or (auto_set_provider_path and inferred_provider == "openai")
            if provider_set_to_openai:
                llm_section = _ensure_dict_section(raw_config, "llm")
                git_section = _ensure_dict_section(llm_section, "git")
                git_section["skip_check"] = True
            if scope == "project":
                from obra.config.loaders import get_project_layer_path

                project_id, id_warnings = _resolve_project_id_for_layers()
                _config_emit_warnings(id_warnings)
                if not project_id:
                    _config_emit_error("Unable to resolve project ID for project scope.")
                    raise typer.Exit(1)
                project_path = get_project_layer_path(project_id)
                project_path.parent.mkdir(parents=True, exist_ok=True)
                project_path.write_text(
                    yaml.safe_dump(raw_config, default_flow_style=False, sort_keys=False),
                    encoding="utf-8",
                )
            else:
                save_config(raw_config)
            config_data, _, _, warnings, _origins = _config_load_scope(scope)
            _config_emit_warnings(warnings)

        if not json_output:
            print_success(f"Set {normalized_path} = {raw_value}")
            provider_paths = {
                "llm.provider",
                "llm.orchestrator.provider",
                "llm.implementation.provider",
            }
            ollama_selected = (
                (normalized_path in provider_paths and parsed_value == "ollama")
                or (auto_set_provider_path and inferred_provider == "ollama")
                or (normalized_path in model_paths and inferred_provider == "ollama")
            )
            if ollama_selected:
                _maybe_emit_ollama_fast_tip(config_data)
        if confirm or json_output:
            _config_print_show(config_data, scope, json_output)

    except ConfigurationError as e:
        display_obra_error(e, console)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in config set: {e}")
        raise typer.Exit(1) from e


@config_app.command(name="provider")
@handle_encoding_errors
def config_provider(
    provider: str = typer.Argument(..., help="Provider name: anthropic, openai, google, ollama"),
    model: str = typer.Option(
        None, "--model", "-m", help="Override default model for this provider"
    ),
    role: str = typer.Option(
        "both",
        "--role",
        "-r",
        help="Which role to configure: orchestrator, implementation, or both",
    ),
    auth_method: str = typer.Option(
        None,
        "--auth",
        "-a",
        help="Auth method: oauth or api_key (defaults to provider's recommended)",
    ),
    fast: bool = typer.Option(
        False,
        "--fast",
        help="Apply fast local settings when using Ollama (disables heavy planning/review)",
    ),
    scope: str = typer.Option("local", "--scope", help="Config scope: local, project, or server"),
    confirm: bool = typer.Option(False, "--confirm", help="Show config after changes"),
) -> None:
    """Switch LLM provider with automatic tier configuration.

    This is the recommended way to change LLM providers. It sets the provider,
    model, and automatically updates tier defaults (fast/medium/high models).

    Examples:
        obra config provider anthropic              # Switch to Anthropic Claude
        obra config provider openai --model gpt-5.2 # OpenAI with specific model
        obra config provider google --role implementation  # Only change implementation
        obra config provider anthropic --auth api_key      # Use API key auth
        obra config provider ollama --fast          # Apply fast local settings

    Exit Codes:
        0: Success
        1: Invalid provider, role, or error
    """
    try:
        from obra.config import save_config
        from obra.config.llm import (
            PROVIDER_TIER_DEFAULTS,
            infer_provider_from_model,
            update_role_tiers_for_provider,
        )
        from obra.config.loaders import get_project_layer_path
        from obra.config.providers import LLM_AUTH_METHODS, LLM_PROVIDERS

        # Validate provider
        valid_providers = list(LLM_PROVIDERS.keys())
        if provider not in valid_providers:
            _config_emit_error(
                f"Unknown provider '{provider}'",
                f"Valid providers: {', '.join(valid_providers)}",
            )
            raise typer.Exit(1)

        # Validate role
        valid_roles = ["orchestrator", "implementation", "both"]
        if role not in valid_roles:
            _config_emit_error(
                f"Invalid role '{role}'",
                f"Valid roles: {', '.join(valid_roles)}",
            )
            raise typer.Exit(1)

        # Validate auth method if provided
        if auth_method and auth_method not in LLM_AUTH_METHODS:
            _config_emit_error(
                f"Invalid auth method '{auth_method}'",
                f"Valid methods: {', '.join(LLM_AUTH_METHODS.keys())}",
            )
            raise typer.Exit(1)

        # Validate scope
        if scope not in ("local", "project", "server"):
            _config_emit_error("Invalid scope. Use --scope local, project, or server")
            raise typer.Exit(2)

        # Validate model matches provider if specified
        if model:
            inferred = infer_provider_from_model(model)
            if inferred and inferred != provider:
                _config_emit_error(
                    f"Model '{model}' is associated with provider '{inferred}', not '{provider}'",
                    f"Either change provider to '{inferred}' or use a {provider} model",
                )
                raise typer.Exit(1)

        # Load current config
        config_data, _, raw_config, warnings, _ = _config_load_scope(scope)
        _config_emit_warnings(warnings)

        # Determine roles to update
        roles_to_update = ["orchestrator", "implementation"] if role == "both" else [role]

        # Default auth method if not specified
        effective_auth = auth_method or "oauth"

        # Update each role
        notifications = []
        for r in roles_to_update:
            # Set provider
            _config_set_nested_value(raw_config, f"llm.{r}.provider", provider)
            # Set auth method
            _config_set_nested_value(raw_config, f"llm.{r}.auth_method", effective_auth)
            # Set model if specified, otherwise use "default"
            _config_set_nested_value(raw_config, f"llm.{r}.model", model if model else "default")
            # Update tier defaults
            raw_config, tier_msg = update_role_tiers_for_provider(r, provider, raw_config)
            if tier_msg:
                notifications.append(tier_msg)

        # Set git.skip_check for OpenAI
        if provider == "openai":
            llm_section = _ensure_dict_section(raw_config, "llm")
            git_section = _ensure_dict_section(llm_section, "git")
            git_section["skip_check"] = True

        # Apply fast local settings for Ollama if requested
        if provider == "ollama" and fast:
            _config_set_nested_value(raw_config, "planning.enrichment.enabled", False)
            _config_set_nested_value(raw_config, "planning.enrichment.always_on", False)
            _config_set_nested_value(raw_config, "planning.intent_alignment.model_tier", "fast")
            _config_set_nested_value(raw_config, "planning.intent_alignment.reasoning_level", "off")
            _config_set_nested_value(raw_config, "planning.intent_alignment.max_passes", 1)
            _config_set_nested_value(raw_config, "planning.intent_alignment.block_on_fail", False)
            _config_set_nested_value(raw_config, "planning.intent_gap_check.story_enabled", False)
            _config_set_nested_value(raw_config, "planning.intent_gap_check.epic_enabled", False)
            _config_set_nested_value(raw_config, "refinement.planning.enabled", False)
            _config_set_nested_value(raw_config, "agents.code_review", False)
            _config_set_nested_value(raw_config, "agents.test_gen", False)
            _config_set_nested_value(raw_config, "agents.test_exec", False)
            _config_set_nested_value(raw_config, "agents.rca", False)
            for r in roles_to_update:
                _config_set_nested_value(raw_config, f"llm.{r}.thinking_level", "off")
                _config_set_nested_value(raw_config, f"llm.{r}.tiers.fast", "qwen2.5-coder:3b")
                _config_set_nested_value(raw_config, f"llm.{r}.tiers.medium", "qwen2.5-coder:7b")
                _config_set_nested_value(raw_config, f"llm.{r}.tiers.high", "qwen2.5-coder:14b")
            _config_set_nested_value(raw_config, "llm.thinking_level", "off")
            _config_set_nested_value(raw_config, "llm.reasoning.force_level", "off")

        # Save config
        if scope == "server":
            from obra.api import APIClient

            # Build updates for server
            updates = {}
            for r in roles_to_update:
                updates[f"llm.{r}.provider"] = provider
                updates[f"llm.{r}.auth_method"] = effective_auth
                updates[f"llm.{r}.model"] = model if model else "default"
                tier_defaults = PROVIDER_TIER_DEFAULTS.get(provider, {})
                for tier_name, tier_model in tier_defaults.items():
                    updates[f"llm.{r}.tiers.{tier_name}"] = tier_model

            api_client = APIClient.from_config()
            api_client.update_user_config(overrides=updates)
        elif scope == "project":
            project_id, id_warnings = _resolve_project_id_for_layers()
            _config_emit_warnings(id_warnings)
            if not project_id:
                _config_emit_error("Unable to resolve project ID for project scope.")
                raise typer.Exit(1)
            project_path = get_project_layer_path(project_id)
            project_path.parent.mkdir(parents=True, exist_ok=True)
            project_path.write_text(
                yaml.safe_dump(raw_config, default_flow_style=False, sort_keys=False),
                encoding="utf-8",
            )
        else:
            save_config(raw_config)

        # Print success
        roles_str = " and ".join(roles_to_update)
        model_str = f" with model '{model}'" if model else ""
        print_success(f"Switched {roles_str} to {provider}{model_str}")
        if provider == "ollama" and fast:
            console.print(
                f"  [green]{glyphs.success}[/green] Applied fast local settings for Ollama"
            )
            console.print(
                "  [dim]Disabled intent enrichment, refinement, review agents,"
                "and reasoning; adjusted tiers to 3b/7b/14b.[/dim]"
            )
        if provider == "ollama":
            _maybe_emit_ollama_fast_tip(raw_config)

        # Print tier notifications
        for notif in notifications:
            console.print(f"  {notif}")

        if confirm:
            config_data, _, _, warnings, _ = _config_load_scope(scope)
            _config_emit_warnings(warnings)
            _config_print_show(config_data, scope, json_output=False)

    except ConfigurationError as e:
        display_obra_error(e, console)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in config provider: {e}")
        raise typer.Exit(1) from e


# Fields to preserve during soft reset (terms acceptance only;
# auth credentials live in ~/.obra/auth.yaml and are unaffected by config reset)
_CONFIG_PRESERVE_FIELDS = {
    "terms_accepted",
}


@config_app.command(name="reset")
@handle_encoding_errors
def config_reset(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
    factory: bool = typer.Option(
        False,
        "--factory",
        help="Full factory reset: delete ALL config including auth (requires re-login)",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Force file operations (use when config is corrupted)",
    ),
) -> None:
    """Reset configuration to defaults.

    Two reset modes available:

    SOFT RESET (default):
        Resets all settings to defaults from the bundled default_config.yaml,
        but PRESERVES your authentication and terms acceptance. You won't need
        to log in again or re-accept the terms of service.

    FACTORY RESET (--factory):
        Complete factory reset. Deletes ALL configuration including auth tokens
        and terms acceptance. You will need to log in again and re-accept the
        terms of service. Use this for a completely fresh start.

    Examples:
        obra config reset              # Soft reset (preserves auth)
        obra config reset --yes        # Soft reset without confirmation
        obra config reset --factory    # Full factory reset (requires re-login)
        obra config reset --force      # Force reset if config is corrupted

    Exit Codes:
        0: Success or cancelled
        1: Error
    """
    try:
        from obra.config import load_config, save_config
        from obra.config.explorer.utils import load_default_config_schema
        from obra.config.loaders import CONFIG_LAYER_DIR, CONFIG_PATH

        if not yes:
            # C14: Check for non-interactive mode before prompting
            if not sys.stdin.isatty():
                console.print(
                    "Non-interactive mode: skipping reset confirmation (defaulting to cancel)"
                )
                console.print("Use --yes flag to skip confirmation.")
                return

            if factory:
                console.print(
                    "[bold red]WARNING: Factory reset will delete ALL configuration "
                    "including authentication.[/bold red]"
                )
                console.print("You will need to log in again and re-accept the terms of service.")
                do_reset = typer.confirm(get_message("prompt.confirm.factory_reset"))
            else:
                console.print("[bold]Soft reset[/bold]: All settings will be reset to defaults.")
                console.print("Your authentication and terms acceptance will be preserved.")
                do_reset = typer.confirm(get_message("prompt.confirm.soft_reset"))

            if not do_reset:
                console.print("Cancelled")
                return

        # Load bundled defaults
        defaults = load_default_config_schema()
        if not defaults:
            console.print("[yellow]Warning: Could not load bundled defaults[/yellow]")
            defaults = {}

        if factory:
            # FACTORY RESET: Delete everything, restore from defaults
            from obra.config.loaders import AUTH_STATE_PATH

            if AUTH_STATE_PATH.exists():
                AUTH_STATE_PATH.unlink()
                console.print(f"[dim]Deleted: {AUTH_STATE_PATH}[/dim]")

            if CONFIG_LAYER_DIR.exists():
                for path in CONFIG_LAYER_DIR.glob("*.yaml"):
                    path.unlink()
                    console.print(f"[dim]Deleted: {path}[/dim]")

            CONFIG_LAYER_DIR.mkdir(parents=True, exist_ok=True)

            # Write defaults (or empty if no defaults available)
            import yaml

            config_content = yaml.safe_dump(defaults, default_flow_style=False, sort_keys=False)
            CONFIG_PATH.write_text(
                f"# Obra user configuration (factory reset)\n"
                f"# Use 'obra config' to configure settings\n\n"
                f"{config_content}",
                encoding="utf-8",
            )
            console.print(f"Regenerated: {CONFIG_PATH}")
            print_success("Factory reset complete - please run 'obra login' to authenticate")

        elif force:
            # FORCE RESET: Delete and regenerate (for corrupted configs)
            # Still preserves auth by extracting from raw file if possible
            preserved = {}

            # Try to extract auth fields from potentially corrupted config
            if CONFIG_PATH.exists():
                try:
                    import yaml

                    raw_content = CONFIG_PATH.read_text(encoding="utf-8")
                    raw_config = yaml.safe_load(raw_content) or {}
                    for field in _CONFIG_PRESERVE_FIELDS:
                        if field in raw_config:
                            preserved[field] = raw_config[field]
                except Exception:
                    console.print("[yellow]Could not extract auth from corrupted config[/yellow]")

            # Delete all config files
            if CONFIG_LAYER_DIR.exists():
                for path in CONFIG_LAYER_DIR.glob("*.yaml"):
                    path.unlink()
                    console.print(f"[dim]Deleted: {path}[/dim]")

            CONFIG_LAYER_DIR.mkdir(parents=True, exist_ok=True)

            # Merge preserved auth into defaults
            new_config = {**defaults, **preserved}

            import yaml

            config_content = yaml.safe_dump(new_config, default_flow_style=False, sort_keys=False)
            CONFIG_PATH.write_text(
                f"# Obra user configuration (force reset)\n"
                f"# Use 'obra config' to configure settings\n\n"
                f"{config_content}",
                encoding="utf-8",
            )
            console.print(f"Regenerated: {CONFIG_PATH}")

            if preserved:
                console.print(f"[green]Preserved {len(preserved)} auth/account fields[/green]")
            print_success("Force reset complete (auth preserved)")

        else:
            # SOFT RESET: Preserve auth, reset everything else
            # Load current config to extract auth fields
            try:
                current_config = load_config()
            except Exception:
                current_config = {}

            # Extract auth fields to preserve
            preserved = {}
            for field in _CONFIG_PRESERVE_FIELDS:
                if field in current_config:
                    preserved[field] = current_config[field]

            # Delete extra layer files (keep main user config)
            if CONFIG_LAYER_DIR.exists():
                for path in CONFIG_LAYER_DIR.glob("*.yaml"):
                    if path != CONFIG_PATH:
                        path.unlink()
                        console.print(f"[dim]Deleted: {path}[/dim]")

            # Merge preserved auth into defaults
            new_config = {**defaults, **preserved}

            # Save the new config
            save_config(new_config)

            console.print(f"[green]Preserved {len(preserved)} auth/account fields[/green]")
            print_success("Soft reset complete (auth preserved)")

    except ConfigurationError as e:
        display_obra_error(e, console)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in config reset: {e}")
        raise typer.Exit(1) from e


@config_app.command(name="validate")
@handle_encoding_errors
def config_validate(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    schema: bool = typer.Option(
        False, "--schema", help="Validate config keys and types against schema"
    ),
) -> None:
    """Validate provider CLIs and configuration.

    Checks that provider CLIs are installed and configuration is valid.
    Reports status for each provider and overall configuration health.

    Examples:
        obra config validate
        obra config validate --json
        obra config validate --schema

    Exit Codes:
        0: All checks passed
        1: Issues found or error
    """
    try:
        _run_config_validation(json_output=json_output, include_schema=schema)
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in config validate: {e}")
        raise typer.Exit(1) from e


@config_app.command(name="search")
@handle_encoding_errors
def config_search(
    keyword: str = typer.Argument(
        ..., help="Keyword to search for in config paths and descriptions"
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Search configuration paths by keyword.

    Searches config paths and descriptions for the given keyword.
    Useful for finding settings when you don't know the exact path.

    Examples:
        obra config search security
        obra config search timeout
        obra config search agent
        obra config search model

    Exit Codes:
        0: Found matching settings
        1: No matches found
    """
    import json as json_module

    from obra.config.loaders import SEMANTIC_CONFIG_ALIASES

    schema_paths = _config_schema_paths()
    keyword_lower = keyword.lower()

    # Find matching paths in schema
    matches: list[dict[str, str]] = []

    # Check schema paths
    for path in sorted(schema_paths):
        if keyword_lower in path.lower():
            matches.append({"path": path, "type": "config", "description": ""})

    # Check semantic aliases
    alias_matches: list[dict[str, str]] = []
    for alias, canonical in SEMANTIC_CONFIG_ALIASES.items():
        if keyword_lower in alias.lower():
            alias_matches.append(
                {
                    "alias": alias,
                    "canonical": canonical,
                    "type": "alias",
                }
            )

    # Get descriptions for matches (if available)
    try:
        from obra.config.explorer.descriptions import get_description

        for match in matches:
            desc = get_description(match["path"])
            if desc:
                match["description"] = desc
    except ImportError:
        pass

    if not matches and not alias_matches:
        if json_output:
            print(
                json_module.dumps(
                    {"keyword": keyword, "matches": [], "aliases": []},
                    ensure_ascii=True,
                )
            )
        else:
            console.print(f"[yellow]No settings found matching '{keyword}'[/yellow]")
            console.print()
            console.print("[dim]Try searching for:[/dim]")
            console.print("  • security, doc, review - agent settings")
            console.print("  • timeout - timeout settings")
            console.print("  • model, llm - LLM settings")
            console.print("  • budget - budget framework settings")
        raise typer.Exit(1)

    if json_output:
        output = {
            "keyword": keyword,
            "matches": matches,
            "aliases": alias_matches,
        }
        print(json_module.dumps(output, ensure_ascii=True))
    else:
        console.print(f"[bold]Config settings matching '{keyword}':[/bold]")
        console.print()

        if alias_matches:
            console.print("[bold cyan]Shortcuts (semantic aliases):[/bold cyan]")
            for alias_match in alias_matches:
                console.print(
                    f"  • [green]{alias_match['alias']}[/green] → {alias_match['canonical']}"
                )
            console.print()

        if matches:
            console.print("[bold cyan]Config paths:[/bold cyan]")
            for match in matches[:20]:  # Limit to 20 results
                path = match["path"]
                desc = match.get("description", "")
                if desc:
                    console.print(f"  • [green]{path}[/green] - {desc}")
                else:
                    console.print(f"  • [green]{path}[/green]")
            if len(matches) > 20:
                console.print(f"  ... and {len(matches) - 20} more")
            console.print()

        console.print("[dim]Use 'obra config get <path>' to view a value[/dim]")
        console.print("[dim]Use 'obra config set <path> <value>' to change a value[/dim]")


@config_app.command(name="recipes")
@handle_encoding_errors
def config_recipes() -> None:
    """Show common configuration recipes.

    Displays common configuration patterns for typical use cases
    like disabling agents, changing models, and adjusting timeouts.

    Examples:
        obra config recipes

    Exit Codes:
        0: Always (informational command)
    """
    console.print()
    console.print("[bold cyan]Common Configuration Recipes[/bold cyan]")
    console.print()

    console.print("[bold]1. Disable Security Audits[/bold]")
    console.print("   obra config set agents.security false")
    console.print(
        "   [dim]Or: obra config set features.quality_automation.agents.security_audit.enabled false[/dim]"
    )
    console.print()

    console.print("[bold]2. Disable Documentation Audits[/bold]")
    console.print("   obra config set agents.doc_audit false")
    console.print(
        "   [dim]Or: obra config set features.quality_automation.agents.doc_audit.enabled false[/dim]"
    )
    console.print()

    console.print("[bold]3. Change LLM Model[/bold]")
    console.print("   obra config set llm.model sonnet")
    console.print("   obra config set llm.model opus")
    console.print("   obra config set llm.model haiku")
    console.print()

    console.print("[bold]4. Adjust Timeouts[/bold]")
    console.print("   obra config set llm.timeout 3600                    # 1 hour")
    console.print("   obra config set orchestration.timeouts.agent_execution_s 7200  # 2 hours")
    console.print()

    console.print("[bold]5. Disable All Quality Automation Agents[/bold]")
    console.print("   obra config set features.quality_automation.enabled false")
    console.print()

    console.print("[bold]6. Enable Budget Framework[/bold]")
    console.print("   obra config set orchestration.budgets.enabled true")
    console.print()

    console.print("[bold]7. Pre-flight Setup (Disable Audits, Set Model)[/bold]")
    console.print("   obra config set llm.model sonnet")
    console.print("   obra config set agents.security false")
    console.print("   obra config set agents.doc_audit false")
    console.print()

    console.print("[dim]Use 'obra config search <keyword>' to find more settings[/dim]")
    console.print("[dim]Use 'obra config show' to view all current settings[/dim]")


# =============================================================================
# Documentation Commands
# =============================================================================

# Create docs subcommand group (S3.T3)
docs_app = typer.Typer(
    name="docs",
    help="Access local Obra documentation",
    invoke_without_command=True,
    rich_markup_mode="rich",
)
app.add_typer(docs_app, name="docs", rich_help_panel="User Commands")


def _docs_show_default() -> None:
    """Show default docs output with paths to documentation files."""
    package_root = Path(__file__).parent
    readme_path = package_root / "README.md"
    llm_onboarding_path = package_root / ".obra" / "LLM_ONBOARDING.md"

    console.print()
    console.print("[bold]Obra Documentation (Local)[/bold]", style="cyan")
    console.print()
    console.print("[bold]Package Documentation:[/bold]")
    console.print(f"  README:           {readme_path}")
    console.print()
    console.print("[bold]LLM Operator Guide:[/bold]")
    console.print(f"  LLM_ONBOARDING:   {llm_onboarding_path}")
    console.print("  Quick access:     [cyan]obra docs llm[/cyan]")
    console.print()
    console.print("[dim]Use 'cat <path>' or your text editor to read these files.[/dim]")


def _docs_show_llm() -> None:
    """Show path to LLM_ONBOARDING.md for LLM operators."""
    package_root = Path(__file__).parent
    llm_onboarding_path = package_root / ".obra" / "LLM_ONBOARDING.md"

    console.print()
    console.print("[bold]LLM Operator Guide[/bold]", style="cyan")
    console.print()
    console.print(f"Path: {llm_onboarding_path}")
    console.print()
    console.print("[dim]Use 'cat' or your text editor to read this file.[/dim]")


@docs_app.callback(invoke_without_command=True)
@handle_encoding_errors
def docs_callback(
    ctx: typer.Context,
    # Hidden alias for deprecated flag (S3.T3 - backwards compatibility)
    llm: bool = typer.Option(
        False,
        "--llm",
        hidden=True,
        help="[DEPRECATED] Use 'obra docs llm' instead",
    ),
) -> None:
    """Access local Obra documentation.

    Displays paths to documentation files shipped with the package.

    Subcommands:
        llm  - Show path to LLM operator guide

    Examples:
        obra docs           # Show all doc paths
        obra docs llm       # Show LLM operator guide path
    """
    # Handle deprecated --llm flag
    if llm:
        err_console.print(
            f"[yellow]{build_deprecation_warning('--llm', 'obra docs llm')}[/yellow]",
            style="yellow",
        )
        _docs_show_llm()
        return

    # If no subcommand was invoked, show default docs output
    if ctx.invoked_subcommand is None:
        _docs_show_default()


# =============================================================================
# Log Viewer Commands
# =============================================================================

logs_app = typer.Typer(
    name="logs",
    help="Log tooling and local observability utilities",
    rich_markup_mode="rich",
)
app.add_typer(logs_app, name="logs", rich_help_panel="User Commands")


@logs_app.command("viewer")
@handle_encoding_errors
def logs_viewer(
    host: str = typer.Option(
        "127.0.0.1",
        "--host",
        help="Host to bind for the log viewer",
    ),
    port: int = typer.Option(
        8844,
        "--port",
        help="Port to bind for the log viewer",
    ),
    log_path: Path | None = typer.Option(
        None,
        "--log-path",
        help="Override hybrid.jsonl log path",
    ),
    production_log_path: Path | None = typer.Option(
        None,
        "--production-log-path",
        help="Override production.jsonl log path",
    ),
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Do not auto-open the browser",
    ),
    stay_open: bool = typer.Option(
        False,
        "--stay-open",
        help="Keep the server running after the browser closes",
    ),
) -> None:
    """Launch the local log viewer (aggregates hybrid + production logs)."""
    from obra.observability.log_viewer.server import (
        default_hybrid_log_path,
        default_production_log_path,
        run_log_viewer,
    )

    run_log_viewer(
        host=host,
        port=port,
        hybrid_log_path=log_path or default_hybrid_log_path(),
        production_log_path=production_log_path or default_production_log_path(),
        open_browser=not no_browser,
        stay_open=stay_open,
    )


@docs_app.command(name="llm")
@handle_encoding_errors
def docs_llm() -> None:
    """Show path to LLM operator guide.

    Displays the path to LLM_ONBOARDING.md, which contains guidance
    for AI assistants using Obra.

    Examples:
        obra docs llm

    Exit Codes:
        0: Always (informational command)
    """
    _docs_show_llm()


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
def doctor(
    report: bool = typer.Option(
        False,
        "--report",
        help="Submit diagnostic report if checks fail (for troubleshooting)",
    ),
) -> None:
    """Run health checks on your Obra environment.

    Validates:
    - Python version compatibility
    - Authentication status
    - Provider CLI availability (claude, codex, gemini, ollama)
    - API connectivity and server compatibility
    - Working directory write permissions
    - Provider-specific configuration (git for Codex, etc.)

    Run this before 'obra run' to catch configuration issues early.

    Examples:
        $ obra doctor
        $ obra doctor --report   # Auto-submit if issues found
    """
    import platform

    console.print()
    console.print("[bold]Obra Health Check[/bold]", style="cyan")
    console.print()

    # Show client info first (not a check, just informational)
    console.print("[bold]Client Info:[/bold]")
    console.print(f"  Obra: v{__version__}")
    console.print(f"  Platform: {platform.system()} {platform.release()}")
    console.print()

    checks_passed = 0
    total_checks = 6  # Python, Auth, Provider CLIs, API, Working Dir, Provider Config

    # Check 1: Python version
    console.print("[bold]Python Version:[/bold]")
    python_version = sys.version_info
    version_str = f"{python_version.major}.{python_version.minor}.{python_version.micro}"

    if python_version >= (3, 12):
        console.print(f"  [green]{glyphs.success}[/green] Python {version_str} (recommended)")
        checks_passed += 1
    else:
        console.print(
            f"  [yellow]{glyphs.warning}[/yellow] Python {version_str} (Python 3.12+ recommended)"
        )
        console.print(
            "    [dim]Obra works with Python 3.10+, but 3.12+ is recommended for best performance[/dim]"
        )
        if python_version >= (3, 10):
            checks_passed += 1  # Still passes, just with warning

    console.print()

    # Check 2: Authentication status
    console.print("[bold]Authentication:[/bold]")
    try:
        from obra.auth import get_current_auth

        auth = get_current_auth()

        if auth:
            console.print(f"  [green]{glyphs.success}[/green] Logged in as {auth.email}")
            checks_passed += 1
        else:
            console.print(f"  [yellow]{glyphs.warning}[/yellow] Not logged in")
            console.print(f"    [dim]{get_message('recovery.auth.login')}[/dim]")
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"  [red]{glyphs.failure}[/red] Authentication check failed: {e}")
        logger.debug(f"Auth check error: {e}", exc_info=True)

    console.print()

    # Check 3: Provider CLIs
    console.print("[bold]Provider CLIs:[/bold]")
    try:
        from obra.config import LLM_PROVIDERS, check_provider_status

        provider_count = 0
        for provider_key in LLM_PROVIDERS:
            status = check_provider_status(provider_key)
            provider_name = LLM_PROVIDERS[provider_key].get("name", provider_key)

            if status.installed:
                console.print(
                    f"  [green]{glyphs.success}[/green] {provider_name} ({status.cli_command})"
                )
                provider_count += 1
            else:
                console.print(
                    f"  [red]{glyphs.failure}[/red] {provider_name} ({status.cli_command}) - not found"
                )

        # At least one provider installed counts as passing
        if provider_count > 0:
            checks_passed += 1
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"  [red]{glyphs.failure}[/red] Provider check failed: {e}")
        logger.debug(f"Provider check error: {e}", exc_info=True)

    console.print()

    # Check 4: API Connectivity and Server Compatibility
    console.print("[bold]API Connectivity:[/bold]")
    try:
        from obra.api import APIClient
        from obra.config import get_api_base_url

        # Create unauthenticated client for version check
        client = APIClient(base_url=get_api_base_url())

        try:
            server_info = client.get_version()
            server_version = server_info.get("version", "N/A")
            api_version = server_info.get("api_version", "N/A")
            compatible = server_info.get("compatible", True)
            min_client = server_info.get("min_client_version", "0.0.0")

            console.print(f"  [green]{glyphs.success}[/green] Obra API reachable")
            console.print(f"    [dim]Server: v{server_version} (API {api_version})[/dim]")

            if compatible:
                console.print("    [dim]Client compatible with server[/dim]")
                checks_passed += 1
            else:
                console.print(
                    f"    [yellow]{glyphs.warning} Client update required (minimum: {min_client})[/yellow]"
                )
                console.print("    [dim]Run: pip install --upgrade obra[/dim]")
                # Still count as passed since API is reachable
                checks_passed += 1

        except APIError as e:
            if e.status_code == 0:
                console.print(f"  [red]{glyphs.failure}[/red] Cannot reach Obra API")
                console.print("    [dim]Check your network connection[/dim]")
            else:
                console.print(f"  [yellow]{glyphs.warning}[/yellow] API returned error: {e}")
            logger.debug(f"API error in doctor: {e}", exc_info=True)
        except typer.Exit:
            raise
        except Exception as e:
            console.print(f"  [red]{glyphs.failure}[/red] Cannot reach Obra API")
            console.print(f"    [dim]Error: {e}[/dim]")
            logger.debug(f"Connection error in doctor: {e}", exc_info=True)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"  [red]{glyphs.failure}[/red] API check failed: {e}")
        logger.debug(f"API check error: {e}", exc_info=True)

    console.print()

    # Check 5: Working Directory
    console.print("[bold]Working Directory:[/bold]")
    try:
        cwd = Path.cwd()
        console.print(f"  Path: {cwd}")

        # Test if we can write to the directory
        test_file = cwd / ".obra_doctor_test"
        try:
            test_file.write_text("test")
            test_file.unlink()
            console.print(f"  [green]{glyphs.success}[/green] Directory is writable")
            checks_passed += 1
        except PermissionError:
            console.print(f"  [red]{glyphs.failure}[/red] Directory is not writable")
            console.print("    [dim]Obra needs write access to create files[/dim]")
        except OSError as e:
            console.print(f"  [yellow]{glyphs.warning}[/yellow] Write test failed: {e}")
            # Still pass if it's not a permission issue (e.g., disk full is recoverable)
            checks_passed += 1

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"  [red]{glyphs.failure}[/red] Working directory check failed: {e}")
        logger.debug(f"Working directory check error: {e}", exc_info=True)

    console.print()

    # Check 6: Provider Configuration
    # Validates provider-specific requirements before execution
    console.print("[bold]Provider Configuration:[/bold]")
    try:
        from obra.config.llm import resolve_llm_config
        from obra.config.loaders import load_config_with_warnings

        config, warnings, _ = load_config_with_warnings()
        llm_config = config.get("llm", {})

        # Use resolve_llm_config to properly handle "per-role" delegation
        # This ensures we get the actual provider, not the delegation placeholder
        resolved_config = resolve_llm_config("implementation")
        selected_provider = os.environ.get("OBRA_PROVIDER") or resolved_config.get(
            "provider", DEFAULT_PROVIDER
        )

        schema = _config_schema()
        schema_warnings = _config_schema_version_warnings(config, schema)
        if warnings or schema_warnings:
            console.print(f"  [yellow]{glyphs.warning}[/yellow] Config warnings detected")
            for warning in warnings + schema_warnings:
                console.print(f"    [dim]{warning}[/dim]")

        provider_issues = []
        provider_warnings = []

        # Codex-specific checks
        if selected_provider == "openai":
            # Check 6a: Git repository status for Codex
            cwd = Path.cwd()
            is_git_repo = (cwd / ".git").exists() or any(
                (parent / ".git").exists() for parent in cwd.parents
            )

            # Check config for auto_init_git and skip_git_check
            codex_config = llm_config.get("codex", {})
            auto_init_git = codex_config.get("auto_init_git", False)
            skip_git_check = codex_config.get("skip_git_check", False)

            if is_git_repo:
                console.print(
                    f"  [green]{glyphs.success}[/green] Git repository detected (Codex requirement)"
                )
            elif auto_init_git:
                console.print(
                    f"  [green]{glyphs.success}[/green] Git auto-init enabled (llm.codex.auto_init_git: true)"
                )
            elif skip_git_check:
                console.print(
                    f"  [yellow]{glyphs.warning}[/yellow] Git check disabled (llm.codex.skip_git_check: true)"
                )
                provider_warnings.append("Git safety features bypassed")
            else:
                console.print(f"  [red]{glyphs.failure}[/red] Not in a git repository")
                console.print("    [dim]Codex requires git. Options:[/dim]")
                console.print("    [dim]  1. Run 'git init' in your project[/dim]")
                console.print("    [dim]  2. Set llm.codex.auto_init_git: true in config[/dim]")
                console.print("    [dim]  3. Set llm.codex.skip_git_check: true to bypass[/dim]")
                provider_issues.append("Git repository required for Codex")

        # Gemini-specific checks
        elif selected_provider == "google":
            console.print(f"  [green]{glyphs.success}[/green] Gemini provider configured")
            console.print("    [dim]Sandbox mode: permissive (for execution)[/dim]")

        # Anthropic/Claude-specific checks
        elif selected_provider == "anthropic":
            console.print(f"  [green]{glyphs.success}[/green] Claude provider configured")

        # Ollama-specific checks
        elif selected_provider == "ollama":
            console.print(f"  [green]{glyphs.success}[/green] Ollama provider configured")
            console.print("    [dim]Ensure Ollama server is running locally[/dim]")
            _maybe_emit_ollama_fast_tip(config)
            reasoning_level = resolved_config.get("thinking_level", "medium")
            enrichment = config.get("planning", {}).get("enrichment", {}).get("enabled", True)
            refinement_planning = (
                config.get("refinement", {}).get("planning", {}).get("enabled", True)
            )
            if reasoning_level not in ("off", "low"):
                console.print(
                    f"    [yellow]{glyphs.warning}[/yellow] Ollama runs faster with thinking_level=off "
                    "(or use --profile ollama-fast)"
                )
            if enrichment or refinement_planning:
                console.print(
                    f"    [yellow]{glyphs.warning}[/yellow] Enrichment/refinement planning can be slow on local models; "
                    "consider --profile ollama-fast"
                )

        else:
            console.print(
                f"  [yellow]{glyphs.warning}[/yellow] Unknown provider: {selected_provider}"
            )
            provider_warnings.append(f"Unrecognized provider: {selected_provider}")

        # Determine pass/fail for this check
        if not provider_issues:
            if provider_warnings:
                console.print(
                    f"  [yellow]{glyphs.warning}[/yellow] {len(provider_warnings)} warning(s) - check config"
                )
            checks_passed += 1
        else:
            console.print(
                f"  [red]{glyphs.failure}[/red] {len(provider_issues)} issue(s) need resolution"
            )

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"  [red]{glyphs.failure}[/red] Provider config check failed: {e}")
        logger.debug(f"Provider config check error: {e}", exc_info=True)

    console.print()

    # FEAT-MODEL-QUALITY-001 S3.T1: Show LLM Config with quality tier
    console.print("[bold]LLM Config:[/bold]")
    try:
        llm_provider = os.environ.get("OBRA_PROVIDER", DEFAULT_PROVIDER)
        llm_model = os.environ.get("OBRA_MODEL", DEFAULT_MODEL)
        quality_tier = resolve_quality_tier(llm_provider, llm_model)
        tier_suffix = " (auto-permissive)" if quality_tier == "fast" else ""
        console.print(f"  Provider: {llm_provider}")
        console.print(f"  Model: {llm_model}")
        console.print(f"  Quality tier: {quality_tier}{tier_suffix}")
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"  [yellow]{glyphs.warning}[/yellow] Could not resolve LLM config: {e}")
        logger.debug(f"LLM config resolution error: {e}", exc_info=True)

    console.print()

    # Summary - Report Card Style
    console.print("[bold]Overall Health:[/bold]")
    percentage = int((checks_passed / total_checks) * 100)

    if percentage == 100:
        status_icon = f"[green]{glyphs.success}[/green]"
        status_text = "[green]Excellent - All checks passed![/green]"
    elif percentage >= 80:
        status_icon = f"[green]{glyphs.success}[/green]"
        status_text = "[green]Good - System is functional[/green]"
    elif percentage >= 60:
        status_icon = f"[yellow]{glyphs.warning}[/yellow]"
        status_text = "[yellow]Fair - Some issues detected[/yellow]"
    else:
        status_icon = f"[red]{glyphs.failure}[/red]"
        status_text = "[red]Poor - Multiple issues need attention[/red]"

    console.print(f"  {status_icon} {checks_passed}/{total_checks} checks passed ({percentage}%)")
    console.print(f"  {status_text}")
    console.print()

    # Offer to report issues if checks failed
    if percentage < 100:
        failed_checks = total_checks - checks_passed
        if report:
            # Auto-submit diagnostic report
            _offer_bug_report(
                context="doctor diagnostics",
                command_used="obra doctor --report",
                failure_reason=f"{failed_checks} health check(s) failed ({percentage}%)",
                auto_report=True,
            )
        else:
            console.print(
                "[dim]Having trouble? Run 'obra doctor --report' to submit diagnostics[/dim]"
            )
            console.print()

    # Show log paths hint
    console.print("[dim]Logs & monitoring: See ~/.obra/README.md for log paths and commands[/dim]")
    console.print()


# =============================================================================
# Plan Management Commands
# =============================================================================


# Create plans subcommand group
plans_app = typer.Typer(
    name="plans",
    help="Manage uploaded DerivedPlan files. DerivedPlan only. Use `obra userplan` for UserPlans.",
    no_args_is_help=True,
)
app.add_typer(plans_app, name="plans")


@plans_app.command("list")
@handle_encoding_errors
def plans_list(
    limit: int = typer.Option(
        50,
        "--limit",
        "-n",
        help="Maximum number of DerivedPlans to list (max: 100)",
    ),
) -> None:
    """List uploaded DerivedPlan files.

    Displays all DerivedPlans uploaded by the current user, ordered by
    creation time (most recent first).

    Examples:
        $ obra plans list
        $ obra plans list --limit 10
    """
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        # Get plans from server
        client = APIClient.from_config()
        plans = client.list_plans(limit=limit)

        console.print()
        if not plans:
            print_info("No DerivedPlans uploaded")
            console.print(
                "\nUpload a DerivedPlan with: [cyan]obra plans upload path/to/plan.yaml[/cyan]"
            )
            return

        console.print(f"[bold]Uploaded DerivedPlans[/bold] ({len(plans)} total)", style="cyan")
        console.print()

        table = Table()
        table.add_column("DerivedPlan ID", style="cyan")
        table.add_column("Name", style="bold")
        table.add_column("Stories", justify="right")
        table.add_column("Uploaded", style="dim")

        for plan in plans:
            plan_id_short = plan.get("plan_id", "")[:8] + "..."
            name = plan.get("name", "N/A")
            story_count = str(plan.get("story_count", 0))
            created_at = plan.get("created_at", "N/A")

            # Format timestamp if it's ISO format
            if "T" in created_at:
                from datetime import datetime

                try:
                    dt = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
                    created_at = dt.strftime("%Y-%m-%d %H:%M")
                except (ValueError, TypeError):
                    # Invalid timestamp format, use as-is
                    pass

            table.add_row(plan_id_short, name, story_count, created_at)

        console.print(table)
        console.print()
        console.print('[dim]Use with:[/dim] [cyan]obra run --plan-id <plan_id> "objective"[/cyan]')

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in plans list command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in plans list command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in plans list command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in plans list command: {e}")
        raise typer.Exit(1) from e


@plans_app.command("show")
@handle_encoding_errors
def plans_show(
    plan_id: str = typer.Argument(..., help="DerivedPlan ID to display"),
) -> None:
    """Display details of an uploaded DerivedPlan file.

    Shows complete information about a DerivedPlan including:
    - DerivedPlan metadata (name, work_id, description)
    - Story list with titles and status
    - Task count per story

    Examples:
        $ obra plans show abc123
        $ obra plans show abc12345-6789-...
    """
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        # Get plan details from server
        client = APIClient.from_config()
        plan = client.get_plan(plan_id)

        if not plan:
            print_error(f"DerivedPlan not found: {plan_id}")
            raise typer.Exit(1)

        console.print()
        console.print("[bold cyan]DerivedPlan Details[/bold cyan]")
        console.print("=" * 60)
        console.print()

        # Basic info
        console.print(f"[bold]DerivedPlan ID:[/bold]   {plan.get('plan_id', 'N/A')}")
        console.print(f"[bold]Name:[/bold]      {plan.get('name', 'N/A')}")
        console.print(f"[bold]Work ID:[/bold]   {plan.get('work_id', 'N/A')}")

        # Format and display creation time
        created_at = plan.get("created_at", "N/A")
        if "T" in str(created_at):
            from datetime import datetime

            try:
                dt = datetime.fromisoformat(str(created_at).replace("Z", "+00:00"))
                created_at = dt.strftime("%Y-%m-%d %H:%M:%S UTC")
            except (ValueError, TypeError):
                pass
        console.print(f"[bold]Uploaded:[/bold]  {created_at}")

        # Description if present
        if plan.get("description"):
            console.print("[bold]Description:[/bold]")
            console.print(f"  {plan.get('description')}")

        # Epics and stories
        epics = plan.get("epics", [])
        if epics:
            console.print()
            console.print(f"[bold]Epics[/bold] ({len(epics)} total)")
            console.print("-" * 40)

            story_table = Table(show_header=True, header_style="bold")
            story_table.add_column("Epic", style="cyan")
            story_table.add_column("Story")
            story_table.add_column("Status", style="dim")
            story_table.add_column("Tasks", justify="right")

            for epic in epics:
                epic_id = epic.get("id", "?")
                epic_stories = epic.get("stories", [])
                if not isinstance(epic_stories, list):
                    continue
                for story in epic_stories:
                    story_id = story.get("id", "?")
                    title = story.get("title", "Untitled")
                    status = story.get("status", "pending")
                    task_count = len(story.get("tasks", []))
                    story_table.add_row(epic_id, f"{story_id}: {title}", status, str(task_count))

            console.print(story_table)

        console.print()
        console.print(
            f'[dim]Use with:[/dim] [cyan]obra --plan-id {plan_id[:8]}... "your objective"[/cyan]'
        )

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in plans show command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in plans show command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in plans show command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in plans show command: {e}")
        raise typer.Exit(1) from e


@plans_app.command("delete")
@handle_encoding_errors
def plans_delete(
    plan_id: str = typer.Argument(..., help="DerivedPlan ID to delete"),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Skip confirmation prompt",
    ),
) -> None:
    """Delete an uploaded DerivedPlan file.

    Permanently removes the DerivedPlan from the server. This cannot be undone.
    Existing sessions using this DerivedPlan are not affected.

    Examples:
        $ obra plans delete abc123-uuid
        $ obra plans delete abc123-uuid --force
    """
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        # Get plan details first
        client = APIClient.from_config()

        console.print()
        console.print("[dim]Fetching DerivedPlan details...[/dim]")

        try:
            plan = client.get_plan(plan_id)
            plan_name = plan.get("name", "Unknown")
            story_count = plan.get("story_count", 0)

            console.print()
            console.print("[bold]DerivedPlan Details[/bold]", style="yellow")
            console.print(f"ID: {plan_id}")
            console.print(f"Name: {plan_name}")
            console.print(f"Stories: {story_count}")
            console.print()

        except (APIError, ObraError) as e:
            # Plan not found or error fetching - proceed with deletion anyway
            logger.warning(f"Could not fetch plan details: {e}")
            plan_name = "Unknown"

        # Confirm deletion
        if not force:
            # C14: Check for non-interactive mode before prompting
            if not sys.stdin.isatty():
                # Non-interactive mode: default to not deleting (safe default)
                console.print(
                    "Non-interactive mode: skipping deletion confirmation (defaulting to cancel)"
                )
                console.print("Use --force to delete without confirmation")
                return

            confirm = typer.confirm(
                f"Are you sure you want to delete DerivedPlan '{plan_name}'?",
                default=False,
            )
            if not confirm:
                console.print("Cancelled")
                return

        # Delete plan
        console.print("[dim]Deleting DerivedPlan...[/dim]")
        result = client.delete_plan(plan_id)

        if result.get("success"):
            console.print()
            print_success(f"DerivedPlan deleted: {plan_name}")
        else:
            print_error("Failed to delete DerivedPlan")
            raise typer.Exit(1)

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in plans delete command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in plans delete command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in plans delete command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in plans delete command: {e}")
        raise typer.Exit(1) from e


@plans_app.command("upload")
@handle_encoding_errors
def plans_upload(
    file_path: Path = typer.Argument(
        ..., help="Path to DerivedPlan MACHINE_PLAN file (JSON or YAML) to upload"
    ),
    validate_only: bool = typer.Option(
        False,
        "--validate-only",
        help="Only validate the plan file without uploading",
    ),
) -> None:
    """Upload a DerivedPlan MACHINE_PLAN file (JSON or YAML) to Obra SaaS.

    Validates and uploads a DerivedPlan file to Firestore for later use.
    After upload, use the returned plan_id with 'obra run --plan-id'.

    Examples:
        $ obra plans upload docs/development/MY_PLAN.yaml
        $ obra plans upload --validate-only plan.yaml

    Exit Codes:
        0: Upload successful or validation passed
        1: Upload failed or validation failed
    """
    try:
        command = UploadPlanCommand()
        exit_code = command.execute(str(file_path), validate_only)

        if exit_code != 0:
            raise typer.Exit(exit_code)

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in plans upload command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in plans upload command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in plans upload command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except OSError as e:
        print_error(f"Failed to read plan file: {e}")
        logger.error(f"File I/O error in plans upload command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in plans upload command: {e}")
        raise typer.Exit(1) from e


# NOTE: 'plans validate' command removed - use 'dobra plan validate' instead
# Plan validation is a local operation, not a SaaS operation.
# See CHORE-DOBRA-CLI-001 for migration details.


# =============================================================================
# Sync Commands (Local Observability)
# =============================================================================

sync_app = typer.Typer(
    name="sync",
    help="Sync session data to local files for observability",
    no_args_is_help=True,
)
app.add_typer(sync_app, name="sync", rich_help_panel="User Commands")


@sync_app.command("plan")
@handle_encoding_errors
@require_terms_accepted
def sync_plan(
    ctx: typer.Context,
    session_id: str | None = typer.Argument(
        None,
        help="Session ID to sync (defaults to most recent)",
    ),
    output_dir: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output directory (defaults to .obra/)",
    ),
    export_format: str = typer.Option(
        "yaml",
        "--format",
        help="Export format: yaml or json",
    ),
    machine_plan: bool = typer.Option(
        False,
        "--machine-plan",
        help="Export as MACHINE_PLAN schema for upload/import workflows",
    ),
    work_id: str | None = typer.Option(
        None,
        "--work-id",
        help="Work ID to use when exporting MACHINE_PLAN",
    ),
    verbose: int = typer.Option(
        0,
        "--verbose",
        "-v",
        count=True,
        max=3,
        help="Verbosity level (0-3, use -v/-vv/-vvv)",
    ),
) -> None:
    """Sync session plan to local YAML file.

    Downloads the execution plan for a session and saves it to
    .obra/plan.yaml for local observability. The YAML file includes:
    - Session metadata (objective, status, progress)
    - Plan items with status (pending, in_progress, completed, failed)
    - Acceptance criteria for each item

    Examples:
        $ obra sync plan
        $ obra sync plan abc123
        $ obra sync plan --output ./my-project/.obra/
    """
    from datetime import datetime

    verbose = _resolve_command_verbosity(ctx, verbose)
    setup_logging(verbose)

    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        # Get API client
        client = APIClient.from_config()

        # Resolve session ID
        if session_id:
            target_session_id = session_id
        else:
            # Get most recent session
            sessions = client.list_sessions(limit=1)
            if not sessions:
                print_info("No sessions found")
                console.print("\nRun 'obra run \"objective\"' to start a new session.")
                return
            target_session_id = sessions[0].get("session_id", "")

        console.print()
        console.print("[dim]Fetching plan data...[/dim]")

        # Get session info and plan
        session = client.get_session(target_session_id)
        plan_data = client.get_session_plan(target_session_id)

        # Prepare output structure
        plan_items = plan_data.get("plan_items", [])
        total_count = plan_data.get("total_count", len(plan_items))
        completed_count = plan_data.get("completed_count", 0)

        meta: dict[str, Any] = {
            "synced_at": datetime.now(UTC).isoformat(),
            "session_id": session.get("session_id", target_session_id),
            "objective": session.get("objective", "N/A"),
            "status": session.get("status", "N/A"),
            "phase": session.get("current_phase", "N/A"),
            "iteration": session.get("iteration", 0),
        }
        progress: dict[str, Any] = {
            "total": total_count,
            "completed": completed_count,
            "percentage": (round(completed_count / total_count * 100) if total_count > 0 else 0),
        }
        items: list[dict[str, Any]] = []

        # Format plan items
        for item in plan_items:
            formatted_item = {
                "id": item.get("item_id", item.get("id", "")),
                "order": item.get("order", 0),
                "title": item.get("title", "Untitled"),
                "status": item.get("status", "pending"),
            }

            # Add optional fields if present
            if item.get("acceptance_criteria"):
                formatted_item["acceptance_criteria"] = item["acceptance_criteria"]
            if item.get("started_at"):
                formatted_item["started_at"] = item["started_at"]
            if item.get("completed_at"):
                formatted_item["completed_at"] = item["completed_at"]

            items.append(formatted_item)

        export_format = export_format.lower().strip()
        if export_format not in {"yaml", "json"}:
            print_error(f"Unsupported format: {export_format}. Use yaml or json.")
            raise typer.Exit(1)

        if machine_plan:
            plan_export = _build_machine_plan_export(
                plan_items=plan_items,
                objective=meta["objective"],
                work_id=work_id,
                session_id=meta["session_id"],
            )
        else:
            plan_export = {
                "_meta": meta,
                "progress": progress,
                "items": items,
            }

        # Determine output path
        obra_dir = output_dir or Path.cwd() / ".obra"

        obra_dir.mkdir(parents=True, exist_ok=True)
        output_filename = "plan.yaml"
        if machine_plan:
            output_filename = "MACHINE_PLAN.yaml"
        if export_format == "json":
            output_filename = output_filename.replace(".yaml", ".json")
        output_path = obra_dir / output_filename

        # Write export file
        with output_path.open("w", encoding="utf-8") as f:
            if export_format == "yaml":
                f.write("# Obra Session Plan\n")
                f.write(f"# Synced: {meta['synced_at']}\n")
                f.write(f"# Session: {meta['session_id'][:8]}...\n")
                f.write("#\n")
                if machine_plan:
                    f.write("# Exported as MACHINE_PLAN\n")
                else:
                    f.write("# Status indicators:\n")
                    f.write("#   pending     - Not yet started\n")
                    f.write("#   in_progress - Currently executing\n")
                    f.write("#   completed   - Successfully finished\n")
                    f.write("#   failed      - Execution failed\n")
                f.write("\n")

                yaml.safe_dump(
                    plan_export,
                    f,
                    default_flow_style=False,
                    sort_keys=False,
                    allow_unicode=True,
                    width=100,
                )
            else:
                import json

                json.dump(plan_export, f, indent=2)

        console.print()
        print_success(f"Plan synced to {output_path}")
        console.print()
        console.print(f"[bold]Session[/bold]: {meta['session_id'][:8]}...")
        console.print(f"[bold]Objective[/bold]: {meta['objective']}")
        console.print(
            f"[bold]Progress[/bold]: {completed_count}/{total_count} items "
            f"({progress['percentage']}%)"
        )

        if verbose > 0:
            console.print()
            console.print("[bold]Items[/bold]:")
            for item in items:
                status = item["status"]
                if status == "completed":
                    status_icon = f"[green]{glyphs.success}[/green]"
                elif status == "in_progress":
                    status_icon = f"[yellow]{glyphs.paused}[/yellow]"
                elif status == "failed":
                    status_icon = f"[red]{glyphs.failure}[/red]"
                else:
                    status_icon = "[dim]o[/dim]"
                console.print(f"  {status_icon} {item['title']}")

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in sync plan command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in sync plan command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in sync plan command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except OSError as e:
        print_error(f"Failed to write plan file: {e}")
        logger.error(f"File I/O error in sync plan command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in sync plan command: {e}")
        raise typer.Exit(1) from e


# =============================================================================
# Feedback Commands (Beta Tester Feedback System)
# =============================================================================

feedback_app = typer.Typer(
    name="feedback",
    help="Submit bug reports, feature requests, and feedback",
    invoke_without_command=True,
    rich_markup_mode="rich",
)
app.add_typer(feedback_app, name="feedback", rich_help_panel="Feedback & Bug Reporting")


# =============================================================================
# Bug Shortcut Command (Top-level for discoverability)
# =============================================================================


@app.command(rich_help_panel="Feedback & Bug Reporting")
@handle_encoding_errors
def bug(
    summary: str = typer.Argument(..., help="One-line bug description"),
    non_interactive: bool = typer.Option(
        False,
        "--non-interactive",
        help="Non-interactive mode (no prompts, for orchestrator use)",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
    severity: str = typer.Option(
        "medium",
        "--severity",
        "-s",
        help="Bug severity: critical, high, medium, low",
    ),
    error: str = typer.Option(
        "",
        "--error",
        "-e",
        help="Error message if any",
    ),
    privacy: str = typer.Option(
        "standard",
        "--privacy",
        "-p",
        help="Privacy level: full, standard, minimal",
    ),
) -> None:
    """Quick bug report shortcut.

    Shortcut for `obra feedback bug`. For more options, use the full command.

    Examples:
        obra bug "App crashes on startup"
        obra bug "Orchestrator hangs" --severity high
        obra bug "Error in derive" --error "ValueError: invalid"

    For more options (attachments, session ID, etc.):
        obra feedback bug --help
    """
    from obra.feedback import FeedbackCollector

    try:
        privacy_level = _get_privacy_level(privacy)
        collector = FeedbackCollector(privacy_level=privacy_level)

        # Auto-detect recent session
        session_id = _get_recent_session_id()
        if session_id and not non_interactive:
            console.print(f"[dim]Auto-detected session: {session_id}[/dim]")

        report = collector.create_bug_report(
            summary=summary,
            severity=_get_severity(severity),
            error_message=error,
            session_id=session_id,
        )

        # Check telemetry consent before submission (S4.T2)
        _check_telemetry_consent(non_interactive=non_interactive)

        result = collector.submit(report)

        if format_output == "json":
            import json

            print(json.dumps(result, indent=2, default=str))
            raise typer.Exit(0 if result.get("success") else 1)
        _display_submission_result(result, console)
        raise typer.Exit(0 if result.get("success") else 1)

    except typer.Exit:
        raise
    except Exception as e:
        if format_output == "json":
            import json

            print(json.dumps({"success": False, "error": str(e)}, indent=2))
        else:
            print_error(f"Failed to submit bug report: {e}")
            logger.exception("Bug report submission failed")
        raise typer.Exit(1) from e


def _get_privacy_level(privacy: str) -> "PrivacyLevel":
    """Convert string privacy level to enum."""
    from obra.feedback import PrivacyLevel

    mapping = {
        "full": PrivacyLevel.FULL,
        "standard": PrivacyLevel.STANDARD,
        "minimal": PrivacyLevel.MINIMAL,
    }
    return mapping.get(privacy.lower(), PrivacyLevel.STANDARD)


def _get_severity(severity: str) -> "Severity":
    """Convert string severity to enum."""
    from obra.feedback import Severity

    mapping = {
        "critical": Severity.CRITICAL,
        "high": Severity.HIGH,
        "medium": Severity.MEDIUM,
        "low": Severity.LOW,
    }
    return mapping.get(severity.lower(), Severity.MEDIUM)


def _get_recent_session_id() -> str | None:
    """Get the most recent session ID from session logs.

    Returns:
        Session ID string or None if no recent session found.
    """
    try:
        from obra.feedback.session_logger import SessionConsoleLogger

        session_id, _ = SessionConsoleLogger.get_recent_session_log()
        return cast(str | None, session_id)
    except Exception:
        return None


def _offer_bug_report(
    error: Exception | None = None,
    context: str = "operation",
    session_id: str | None = None,
    command_used: str | None = None,
    objective: str | None = None,
    auto_report: bool = False,
    failure_reason: str | None = None,
    orchestrator: Any | None = None,
) -> None:
    """Offer to file a bug report after a failure.

    Prompts user to submit feedback with pre-filled error context.
    Supports both hard failures (exceptions) and soft failures (e.g., 0 items completed).

    Args:
        error: The exception that occurred (optional for soft failures)
        context: Description of what was happening (e.g., "orchestration", "derive")
        session_id: Session ID if known
        command_used: The command that was run
        objective: The user's objective (what they were trying to accomplish)
        auto_report: If True, skip prompt and submit automatically (for CI/CD)
        failure_reason: Human-readable failure reason (for soft failures without exception)
        orchestrator: HybridOrchestrator instance (if available) for crash state snapshot
    """
    import traceback

    # Determine summary and error details based on failure type
    if error:
        error_type = type(error).__name__
        error_message = str(error)
        error_tb = "".join(traceback.format_exception(type(error), error, error.__traceback__))
        summary = f"{context.title()} failed: {error_type}"
        error_display = f"{error_type}: {error_message[:80]}..."
    else:
        error_type = "SoftFailure"
        error_message = failure_reason or "Operation did not complete successfully"
        error_tb = ""
        summary = f"{context.title()} failed: {failure_reason or 'no items completed'}"
        error_display = failure_reason or "No items completed"

    # Build description with objective if available
    description_parts = [f"Automatic bug report from {context} failure."]
    if objective:
        # Truncate very long objectives for the description
        from obra.config.loaders import get_display_limit

        obj_limit = get_display_limit("objective_preview_max_chars")
        obj_preview = objective[:obj_limit] + "..." if len(objective) > obj_limit else objective
        description_parts.append(f"Objective: {obj_preview}")
    description = "\n\n".join(description_parts)

    session_id = session_id or _get_recent_session_id()

    # Collect orchestrator crash state if available
    session_snapshot: dict[str, Any] = {}
    last_server_action: dict[str, Any] = {}
    if orchestrator is not None:
        try:
            session_snapshot = orchestrator.get_crash_snapshot()
            last_server_action = orchestrator.get_last_server_action_redacted()
            # Use orchestrator's session_id if caller didn't provide one
            if not session_id:
                session_id = session_snapshot.get("session_id")
        except Exception as snap_err:
            logger.debug(f"Failed to collect crash snapshot: {snap_err}")

    # Auto-report mode: skip prompts entirely
    if auto_report:
        try:
            from obra.feedback import FeedbackCollector, PrivacyLevel, Severity

            collector = FeedbackCollector(privacy_level=PrivacyLevel.FULL)
            report = collector.create_bug_report(
                summary=summary,
                severity=Severity.HIGH,
                description=description,
                error_message=error_message,
                error_traceback=error_tb,
                command_used=command_used or "",
                objective=objective or "",
                session_id=session_id,
                session_snapshot=session_snapshot,
                last_server_action=last_server_action,
            )
            result = collector.submit(report)
            console.print()

            # Build captured data summary
            captured_parts = []
            if report.session_snapshot:
                captured_parts.append("session state")
            if report.observability_events:
                captured_parts.append(f"{len(report.observability_events)} events")
            if report.console_log:
                captured_parts.append(f"{len(report.console_log.split(chr(10)))} lines log")
            if objective:
                captured_parts.append("objective")
            captured_str = f" ({', '.join(captured_parts)})" if captured_parts else ""

            if result.get("success"):
                console.print(
                    f"[dim]Bug report auto-submitted: {result.get('report_id', 'N/A')}{captured_str}[/dim]"
                )
            else:
                console.print(
                    f"[dim]Bug report saved locally{captured_str} (will sync later)[/dim]"
                )
        except typer.Exit:
            raise
        except Exception as e:
            console.print(f"[dim]Auto-report failed: {e}[/dim]")
        return

    # Interactive mode: prompt user
    console.print()
    console.print("[bold yellow]Would you like to report this issue?[/bold yellow]")
    console.print("[dim]Your report helps us fix bugs faster.[/dim]")
    console.print()

    console.print("[dim]The report will include:[/dim]")
    console.print(f"  [dim]• Error: {error_display}[/dim]")
    if objective:
        from obra.config.loaders import get_display_limit

        desc_limit = get_display_limit("description_max_chars")
        obj_short = objective[:desc_limit] + "..." if len(objective) > desc_limit else objective
        console.print(f"  [dim]• Objective: {obj_short}[/dim]")
    if session_id:
        console.print("  [dim]• Session logs and events[/dim]")
    console.print("  [dim]• System info (OS, Obra version)[/dim]")
    console.print()

    try:
        from obra.display.prompting import prompt_input

        response = (
            prompt_input("(R)eport (s)kip (p)review > ", console=console, markup=False)
            .strip()
            .lower()
        )
    except (EOFError, KeyboardInterrupt):
        console.print("\n[dim]Skipped.[/dim]")
        return

    if response in ("", "r", "report", "y", "yes"):
        # Submit the bug report
        try:
            from obra.feedback import FeedbackCollector, PrivacyLevel, Severity

            collector = FeedbackCollector(privacy_level=PrivacyLevel.FULL)
            report = collector.create_bug_report(
                summary=summary,
                severity=Severity.HIGH,
                description=description,
                error_message=error_message,
                error_traceback=error_tb,
                command_used=command_used or "",
                objective=objective or "",
                session_id=session_id,
                session_snapshot=session_snapshot,
                last_server_action=last_server_action,
            )

            result = collector.submit(report)
            _display_submission_result(
                result,
                console,
                events_count=len(report.observability_events),
                console_lines=(len(report.console_log.split("\n")) if report.console_log else 0),
                has_objective=bool(objective),
            )

        except Exception as submit_error:
            print_error(f"Failed to submit report: {submit_error}")
            console.print("[dim]You can manually report at: obra feedback bug 'description'[/dim]")

    elif response in ("s", "skip", "n", "no"):
        console.print("[dim]Skipped. You can report later with: obra feedback bug[/dim]")
        return

    elif response in ("p", "preview"):
        # Show preview then ask again
        try:
            import json

            from obra.feedback import FeedbackCollector, PrivacyLevel, Severity

            collector = FeedbackCollector(privacy_level=PrivacyLevel.FULL)
            report = collector.create_bug_report(
                summary=summary,
                severity=Severity.HIGH,
                description=description,
                error_message=error_message,
                error_traceback=error_tb,
                command_used=command_used or "",
                objective=objective or "",
                session_id=session_id,
                session_snapshot=session_snapshot,
                last_server_action=last_server_action,
            )

            preview_data = collector.preview_submission(report)
            console.print()
            console.print("[bold cyan]Preview - Data that will be submitted:[/bold cyan]")
            console.print(json.dumps(preview_data, indent=2, default=str))
            console.print()

            try:
                from obra.display.prompting import prompt_input

                confirm = (
                    prompt_input("(S)ubmit (c)ancel > ", console=console, markup=False)
                    .strip()
                    .lower()
                )
            except (EOFError, KeyboardInterrupt):
                console.print("\n[dim]Cancelled.[/dim]")
                return

            if confirm in ("", "s", "submit", "y", "yes"):
                result = collector.submit(report)
                _display_submission_result(
                    result,
                    console,
                    events_count=len(report.observability_events),
                    console_lines=(
                        len(report.console_log.split("\n")) if report.console_log else 0
                    ),
                    has_objective=bool(objective),
                )
            else:
                console.print(
                    "[dim]Report saved as draft. Submit later with: obra feedback drafts[/dim]"
                )

        except Exception as preview_error:
            print_error(f"Failed to generate preview: {preview_error}")
    else:
        console.print("[dim]Skipped. Report later with: obra feedback bug 'description'[/dim]")


def _display_submission_result(
    result: dict,
    console,
    events_count: int = 0,
    console_lines: int = 0,
    has_system_info: bool = True,
    has_objective: bool = False,
) -> None:
    """Display feedback submission result with details of captured data.

    Args:
        result: Submission result dict from collector.submit()
        console: Rich console for output
        events_count: Number of observability events included
        console_lines: Number of console log lines included
        has_system_info: Whether system info was included
        has_objective: Whether objective was included
    """
    if result.get("success"):
        console.print()
        # Differentiate between submitted and stored locally
        if result.get("stored_locally"):
            print_success("Feedback stored locally")
            console.print("[dim]Will sync when online[/dim]")
        else:
            print_success("Feedback submitted successfully!")
        console.print(f"[dim]Report ID: {result.get('report_id', 'N/A')}[/dim]")

        # Show what was captured for confidence
        captured_parts = []
        if events_count > 0:
            captured_parts.append(f"{events_count} events")
        if console_lines > 0:
            captured_parts.append(f"{console_lines} lines console log")
        if has_objective:
            captured_parts.append("objective")
        if has_system_info:
            captured_parts.append("system info")

        if captured_parts:
            console.print(f"[dim]Included: {', '.join(captured_parts)}[/dim]")
    else:
        print_error(f"Submission failed: {result.get('message', 'Unknown error')}")


@feedback_app.callback(invoke_without_command=True)
@handle_encoding_errors
def feedback_callback(
    ctx: typer.Context,
) -> None:
    """Submit bug reports, feature requests, and feedback.

    Subcommands:
        bug      - Submit a bug report
        feature  - Request a new feature
        comment  - Submit general feedback
        drafts   - Manage saved drafts

    Privacy Levels:
        full     - Maximum data for debugging (prompts, logs, system info)
        standard - Balanced data (truncated prompts, errors, basic system info)
        minimal  - Essential data only (summary, category, Obra version)

    Examples:
        obra feedback bug "App crashes on startup"
        obra feedback feature "Add dark mode"
        obra feedback comment "Great documentation!"
    """
    # If no subcommand was invoked, show help
    if ctx.invoked_subcommand is None:
        console.print()
        console.print("[bold cyan]Obra Feedback System[/bold cyan]")
        console.print()
        console.print("Submit bug reports, feature requests, and feedback to help improve Obra.")
        console.print()
        console.print("[bold]Commands:[/bold]")
        console.print("  obra feedback bug 'App crashes'     # Bug report")
        console.print("  obra feedback feature 'Add X'       # Feature request")
        console.print("  obra feedback comment 'Nice work!'  # General comment")
        console.print()
        console.print("[dim]Run 'obra feedback --help' for more options.[/dim]")


@feedback_app.command("bug")
@handle_encoding_errors
def feedback_bug(
    summary: str = typer.Argument(..., help="One-line bug summary"),
    non_interactive: bool = typer.Option(
        False,
        "--non-interactive",
        help="Non-interactive mode (no prompts, for orchestrator use)",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
    severity: str = typer.Option(
        "medium",
        "--severity",
        "-s",
        help="Bug severity: critical, high, medium, low",
    ),
    description: str = typer.Option(
        "",
        "--description",
        "-d",
        help="Detailed description",
    ),
    steps: str = typer.Option(
        "",
        "--steps",
        help="Steps to reproduce (use \\n for newlines)",
    ),
    expected: str = typer.Option(
        "",
        "--expected",
        help="Expected behavior",
    ),
    actual: str = typer.Option(
        "",
        "--actual",
        help="Actual behavior",
    ),
    error: str = typer.Option(
        "",
        "--error",
        "-e",
        help="Error message if any",
    ),
    command: str = typer.Option(
        "",
        "--command",
        help="The obra command that triggered the bug",
    ),
    session_id: str = typer.Option(
        None,
        "--session",
        help="Session ID for context (auto-detected if recent)",
    ),
    workaround: str = typer.Option(
        "",
        "--workaround",
        "-w",
        help="Known workaround if any",
    ),
    attach: list[Path] = typer.Option(
        None,
        "--attach",
        "-a",
        help="Attach files (logs, screenshots)",
    ),
    privacy: str = typer.Option(
        "standard",
        "--privacy",
        "-p",
        help="Privacy level: full, standard, minimal",
    ),
    preview: bool = typer.Option(
        False,
        "--preview",
        help="Preview what will be sent without submitting",
    ),
) -> None:
    """Submit a bug report.

    Include as much detail as possible to help diagnose the issue.
    System information and recent logs are automatically collected
    based on your chosen privacy level.

    Examples:
        obra feedback bug "App crashes on startup"
        obra feedback bug "Orchestrator hangs" --severity high
        obra feedback bug "Error in derive" --error "ValueError: invalid input"
        obra feedback bug "Crash with spaces" --session abc-123 --attach session.log

    Privacy Levels:
        full     - Include full prompts, logs, and system details
        standard - Include truncated prompts, errors, basic info (default)
        minimal  - Summary, severity, and Obra version only
    """
    from obra.feedback import FeedbackCollector

    try:
        privacy_level = _get_privacy_level(privacy)
        collector = FeedbackCollector(privacy_level=privacy_level)

        # Convert attachment paths to strings
        attachment_paths = [str(p) for p in attach] if attach else []

        # Auto-detect recent session if not provided
        effective_session_id = session_id or _get_recent_session_id()
        if effective_session_id and not session_id and not non_interactive:
            console.print(f"[dim]Auto-detected session: {effective_session_id}[/dim]")

        report = collector.create_bug_report(
            summary=summary,
            severity=_get_severity(severity),
            description=description,
            steps_to_reproduce=steps.replace("\\n", "\n") if steps else "",
            expected_behavior=expected,
            actual_behavior=actual,
            error_message=error,
            command_used=command,
            session_id=effective_session_id,
            workaround=workaround,
            attachment_paths=attachment_paths,
        )

        if preview:
            import json

            if format_output == "json":
                preview_data = collector.preview_submission(report)
                print(json.dumps(preview_data, indent=2, default=str))
            else:
                console.print()
                console.print("[bold cyan]Preview - Data that will be submitted:[/bold cyan]")
                console.print()
                preview_data = collector.preview_submission(report)
                console.print(json.dumps(preview_data, indent=2, default=str))
                console.print()
                console.print("[dim]Run without --preview to submit.[/dim]")
            return

        # Check telemetry consent before submission (S4.T2)
        _check_telemetry_consent(non_interactive=non_interactive)

        result = collector.submit(report)

        if format_output == "json":
            import json

            print(json.dumps(result, indent=2, default=str))
            # Exit with appropriate code
            raise typer.Exit(0 if result.get("success") else 1)
        _display_submission_result(result, console)
        # Exit with appropriate code
        raise typer.Exit(0 if result.get("success") else 1)

    except typer.Exit:
        raise
    except Exception as e:
        if format_output == "json":
            import json

            print(json.dumps({"success": False, "error": str(e)}, indent=2))
        else:
            print_error(f"Failed to submit bug report: {e}")
            logger.exception("Bug report submission failed")
        raise typer.Exit(1) from e


@feedback_app.command("feature")
@handle_encoding_errors
def feedback_feature(
    title: str = typer.Argument(..., help="Feature title"),
    non_interactive: bool = typer.Option(
        False,
        "--non-interactive",
        help="Non-interactive mode (no prompts, for orchestrator use)",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        help="Output format: text, json",
    ),
    use_case: str = typer.Option(
        "",
        "--use-case",
        "-u",
        help="Why do you need this feature?",
    ),
    description: str = typer.Option(
        "",
        "--description",
        "-d",
        help="Detailed description of the feature",
    ),
    workaround: str = typer.Option(
        "",
        "--workaround",
        "-w",
        help="How do you handle this currently?",
    ),
    impact: str = typer.Option(
        "",
        "--impact",
        "-i",
        help="How would this help your work?",
    ),
    frequency: str = typer.Option(
        "",
        "--frequency",
        "-f",
        help="How often would you use this? (daily, weekly, monthly)",
    ),
    similar: str = typer.Option(
        "",
        "--similar",
        help="Have you seen this in other tools?",
    ),
    privacy: str = typer.Option(
        "standard",
        "--privacy",
        "-p",
        help="Privacy level: full, standard, minimal",
    ),
    preview: bool = typer.Option(
        False,
        "--preview",
        help="Preview what will be sent without submitting",
    ),
) -> None:
    """Request a new feature.

    Describe the feature you'd like to see in Obra. Include your use case
    and how it would help your workflow.

    Examples:
        obra feedback feature "Add dark mode"
        obra feedback feature "Export to PDF" --use-case "Share reports with team"
        obra feedback feature "Git integration" --frequency daily --impact "Save 10 min/day"

    Tips:
        - Be specific about the problem you're trying to solve
        - Include frequency of need to help prioritize
        - Mention similar features in other tools if applicable
    """
    from obra.feedback import FeedbackCollector

    try:
        privacy_level = _get_privacy_level(privacy)
        collector = FeedbackCollector(privacy_level=privacy_level)

        report = collector.create_feature_request(
            feature_title=title,
            use_case=use_case,
            description=description,
            current_workaround=workaround,
            business_impact=impact,
            frequency_of_need=frequency,
            similar_tools=similar,
        )

        if preview:
            import json

            if format_output == "json":
                preview_data = collector.preview_submission(report)
                print(json.dumps(preview_data, indent=2, default=str))
            else:
                console.print()
                console.print("[bold cyan]Preview - Data that will be submitted:[/bold cyan]")
                console.print()
                preview_data = collector.preview_submission(report)
                console.print(json.dumps(preview_data, indent=2, default=str))
                console.print()
                console.print("[dim]Run without --preview to submit.[/dim]")
            return

        # Check telemetry consent before submission (S4.T2)
        _check_telemetry_consent(non_interactive=non_interactive)

        result = collector.submit(report)

        if format_output == "json":
            import json

            print(json.dumps(result, indent=2, default=str))
            raise typer.Exit(0 if result.get("success") else 1)
        _display_submission_result(result, console)
        raise typer.Exit(0 if result.get("success") else 1)

    except typer.Exit:
        raise
    except Exception as e:
        if format_output == "json":
            import json

            print(json.dumps({"success": False, "error": str(e)}, indent=2))
        else:
            print_error(f"Failed to submit feature request: {e}")
            logger.exception("Feature request submission failed")
        raise typer.Exit(1) from e


@feedback_app.command("comment")
@handle_encoding_errors
def feedback_comment(
    text: str = typer.Argument(..., help="Your feedback"),
    non_interactive: bool = typer.Option(
        False,
        "--non-interactive",
        help="Non-interactive mode (no prompts, for orchestrator use)",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        help="Output format: text, json",
    ),
    category: str = typer.Option(
        "general",
        "--category",
        "-c",
        help="Category: general, documentation, ux, performance",
    ),
    suggestion: str = typer.Option(
        "",
        "--suggestion",
        "-s",
        help="Improvement suggestion",
    ),
    privacy: str = typer.Option(
        "standard",
        "--privacy",
        "-p",
        help="Privacy level: full, standard, minimal",
    ),
    preview: bool = typer.Option(
        False,
        "--preview",
        help="Preview what will be sent without submitting",
    ),
) -> None:
    """Submit general feedback or a comment.

    Share your thoughts about Obra - what's working well, what could be better,
    or general observations about your experience.

    Examples:
        obra feedback comment "Great documentation!"
        obra feedback comment "Slow on large projects" --category performance
        obra feedback comment "Hard to find settings" --category ux --suggestion "Add search"

    Categories:
        general       - General feedback (default)
        documentation - Feedback about docs
        ux            - User experience feedback
        performance   - Performance observations
    """
    from obra.feedback import FeedbackCollector

    try:
        privacy_level = _get_privacy_level(privacy)
        collector = FeedbackCollector(privacy_level=privacy_level)

        from obra.config.loaders import get_display_limit

        summary_limit = get_display_limit("summary_max_chars")
        report = collector.create_comment(
            summary=text[:summary_limit] + ("..." if len(text) > summary_limit else ""),
            description=text,
            category=category,
            suggestion=suggestion,
        )

        if preview:
            import json

            if format_output == "json":
                preview_data = collector.preview_submission(report)
                print(json.dumps(preview_data, indent=2, default=str))
            else:
                console.print()
                console.print("[bold cyan]Preview - Data that will be submitted:[/bold cyan]")
                console.print()
                preview_data = collector.preview_submission(report)
                console.print(json.dumps(preview_data, indent=2, default=str))
                console.print()
                console.print("[dim]Run without --preview to submit.[/dim]")
            return

        # Check telemetry consent before submission (S4.T2)
        _check_telemetry_consent(non_interactive=non_interactive)

        result = collector.submit(report)

        if format_output == "json":
            import json

            print(json.dumps(result, indent=2, default=str))
            raise typer.Exit(0 if result.get("success") else 1)
        _display_submission_result(result, console)
        raise typer.Exit(0 if result.get("success") else 1)

    except typer.Exit:
        raise
    except Exception as e:
        if format_output == "json":
            import json

            print(json.dumps({"success": False, "error": str(e)}, indent=2))
        else:
            print_error(f"Failed to submit comment: {e}")
            logger.exception("Comment submission failed")
        raise typer.Exit(1) from e


@feedback_app.command("drafts")
@handle_encoding_errors
def feedback_drafts(
    delete: str = typer.Option(
        None,
        "--delete",
        "-d",
        help="Delete a draft by report ID",
    ),
) -> None:
    """List and manage feedback drafts.

    Drafts are automatically saved when creating feedback reports.
    Use this command to view, resume, or delete saved drafts.

    Examples:
        obra feedback drafts                    # List all drafts
        obra feedback drafts --delete abc-123   # Delete a draft
    """
    from obra.feedback import FeedbackCollector

    try:
        collector = FeedbackCollector()

        if delete:
            if collector.delete_draft(delete):
                print_success(f"Draft deleted: {delete}")
            else:
                print_error(f"Draft not found: {delete}")
            return

        drafts = collector.list_drafts()

        console.print()
        if not drafts:
            print_info("No drafts saved")
            return

        console.print(f"[bold cyan]Saved Drafts[/bold cyan] ({len(drafts)} total)")
        console.print()

        table = Table()
        table.add_column("Report ID", style="cyan")
        table.add_column("Type", style="bold")
        table.add_column("Summary")
        table.add_column("Created", style="dim")

        for draft in drafts:
            report_id = draft.get("report_id", "")[:8] + "..."
            feedback_type = draft.get("type", "unknown")
            from obra.config.loaders import get_display_limit

            title_limit = get_display_limit("title_max_chars")
            summary = draft.get("summary", "")[:title_limit] + (
                "..." if len(draft.get("summary", "")) > title_limit else ""
            )
            created = draft.get("created_at", "N/A")

            if "T" in str(created):
                try:
                    from datetime import datetime

                    dt = datetime.fromisoformat(created.replace("Z", "+00:00"))
                    created = dt.strftime("%Y-%m-%d %H:%M")
                except (ValueError, TypeError):
                    pass

            table.add_row(report_id, feedback_type, summary, created)

        console.print(table)
        console.print()
        console.print("[dim]Delete with: obra feedback drafts --delete <report_id>[/dim]")

    except typer.Exit:
        raise
    except Exception as e:
        print_error(f"Failed to list drafts: {e}")
        logger.exception("Draft listing failed")
        raise typer.Exit(1) from e


@feedback_app.command("sync")
@handle_encoding_errors
def feedback_sync() -> None:
    """Sync pending feedback to server.

    Attempts to submit any feedback that was stored locally due to
    network issues. Run this when you regain connectivity.

    Examples:
        obra feedback sync
    """
    from obra.feedback import FeedbackCollector

    try:
        collector = FeedbackCollector()
        result = collector.sync_pending()

        console.print()
        if result["synced"] > 0:
            print_success(f"Synced {result['synced']} pending report(s)")
        if result["failed"] > 0:
            console.print(f"[yellow]Failed to sync {result['failed']} report(s)[/yellow]")
        if result["remaining"] > 0:
            console.print(f"[dim]{result['remaining']} report(s) still pending[/dim]")
        if result["synced"] == 0 and result["failed"] == 0:
            print_info("No pending reports to sync")

    except typer.Exit:
        raise
    except Exception as e:
        print_error(f"Sync failed: {e}")
        logger.exception("Feedback sync failed")
        raise typer.Exit(1) from e


# =============================================================================
# Triage Commands (FEEDBACK-TRIAGE-001: Feedback Triage Orchestration)
# =============================================================================

triage_app = typer.Typer(
    name="triage",
    help="Evaluate and classify feedback submissions",
    rich_markup_mode="rich",
)
app.add_typer(triage_app, name="triage", rich_help_panel="Feedback & Bug Reporting")


@triage_app.command("evaluate")
@handle_encoding_errors
def triage_evaluate(
    feedback_id: str = typer.Option(
        ...,
        "--feedback-id",
        help="Feedback ID to evaluate (e.g., bug-xxx-xxx)",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
) -> None:
    """Evaluate a feedback submission through the triage workflow.

    This command runs the feedback through automated triage stages:
    1. Validation (spam detection, quality scoring)
    2. Classification (bug/enhancement/question)
    3. Severity assignment (for bugs: P0/P1/P2/P3)
    4. Routing decision (accept/reject/escalate)

    Examples:
        obra triage evaluate --feedback-id bug-abc-123
        obra triage evaluate --feedback-id bug-abc-123 --format json
    """
    import json

    from obra.workflow.feedback_triage import FeedbackTriageWorkflow

    try:
        # For now, we'll use a mock feedback submission
        # In a future story, this will fetch from Firestore
        # TODO(FEEDBACK-TRIAGE-001 S3): Integrate with StateManager to fetch real feedback
        feedback = {
            "id": feedback_id,
            "type": "bug",
            "description": "Application crashes when clicking the submit button. "
            "Error message: NullPointerException at line 42.",
            "metadata": {
                "version": "2.0.0",
                "environment": "production",
            },
        }

        # Execute triage workflow
        workflow = FeedbackTriageWorkflow()
        decision = workflow.execute(feedback)

        if format_output == "json":
            # JSON output for machine consumption
            output = {
                "feedback_id": feedback_id,
                "decision": decision.decision,
                "confidence": decision.confidence,
                "reasoning": decision.reasoning,
                "severity": decision.severity,
                "human_review_required": decision.human_review_required,
                "destination": decision.destination,
                "metadata": decision.metadata,
            }
            console.print(json.dumps(output, indent=2))
        else:
            # Human-readable output
            console.print()
            console.print("[bold]Feedback Triage Result[/bold]")
            console.print(f"ID: {feedback_id}")
            console.print()

            # Decision
            decision_color = {
                "accept": "green",
                "reject": "red",
                "escalate": "yellow",
            }.get(decision.decision, "white")
            console.print(
                f"Decision: [{decision_color}]{decision.decision.upper()}[/{decision_color}]"
            )
            console.print(f"Confidence: {decision.confidence:.2f}")

            # Severity (for bugs)
            if decision.severity:
                severity_color = {
                    "P0": "red",
                    "P1": "yellow",
                    "P2": "blue",
                    "P3": "cyan",
                }.get(decision.severity, "white")
                console.print(f"Severity: [{severity_color}]{decision.severity}[/{severity_color}]")

            # Human review flag
            if decision.human_review_required:
                console.print(f"[yellow]{glyphs.warning} Human review required[/yellow]")

            # Reasoning
            console.print()
            console.print("[bold]Reasoning:[/bold]")
            console.print(f"  {decision.reasoning}")

            # Destination
            if decision.destination:
                console.print()
                console.print(f"[dim]Destination: {decision.destination}[/dim]")

            console.print()

    except FileNotFoundError as e:
        print_error(f"Configuration error: {e}")
        raise typer.Exit(1) from e
    except Exception as e:
        print_error(f"Triage evaluation failed: {e}")
        logger.exception("Triage evaluation failed")
        raise typer.Exit(1) from e


# =============================================================================
# Telemetry Commands (FEEDBACK-TRIAGE-001 S4: Privacy Controls)
# =============================================================================


def _load_feedback_config() -> dict[str, Any]:
    """Load feedback config with customer overrides.

    Loads from:
    1. obra/config/defaults/feedback.yaml (default)
    2. .obra/config/feedback.yaml (customer override, if exists)

    Returns:
        Merged configuration dictionary
    """
    # Load default config
    obra_root = Path(__file__).parent
    default_config_path = obra_root / "config" / "defaults" / "feedback.yaml"

    if not default_config_path.exists():
        msg = f"Default feedback config not found: {default_config_path}"
        raise ConfigurationError(msg)

    with default_config_path.open(encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}

    # Check for customer override
    customer_config_path = Path.cwd() / ".obra" / "config" / "feedback.yaml"
    if customer_config_path.exists():
        with customer_config_path.open(encoding="utf-8") as f:
            customer_config = yaml.safe_load(f) or {}
            # Merge customer config (customer values override defaults)
            config.update(customer_config)

    return config


def _save_feedback_consent(consent: bool) -> None:
    """Save telemetry consent to customer config.

    Args:
        consent: True to enable, False to disable
    """
    customer_config_path = Path.cwd() / ".obra" / "config" / "feedback.yaml"
    customer_config_path.parent.mkdir(parents=True, exist_ok=True)

    # Load existing customer config if present
    if customer_config_path.exists():
        with customer_config_path.open(encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}
    else:
        config = {}

    # Update telemetry_consent
    config["telemetry_consent"] = consent

    # Save back to file
    with customer_config_path.open("w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, default_flow_style=False, sort_keys=False)


def _check_telemetry_consent(non_interactive: bool = False) -> bool:
    """Check if user has consented to telemetry.

    Args:
        non_interactive: If True, will not prompt and will raise exception if no consent

    Returns:
        True if consent is granted, False otherwise

    Raises:
        typer.Exit: If non-interactive mode and consent not granted (exit code 1)
    """
    try:
        config = _load_feedback_config()
        consent = config.get("telemetry_consent")

        # If consent is explicitly granted, allow submission
        if consent is True:
            return True

        # If consent is explicitly denied, block submission
        if consent is False:
            if non_interactive:
                print_error("Telemetry disabled. Enable with: obra telemetry enable")
                raise typer.Exit(1)
            console.print()
            console.print(f"[yellow]{glyphs.warning} Telemetry is disabled[/yellow]")
            console.print("Enable with: obra telemetry enable")
            console.print()
            raise typer.Exit(1)

        # If consent not yet given (None), prompt interactively or require action
        if consent is None:
            if non_interactive:
                print_error("Telemetry consent required. Enable with: obra telemetry enable")
                raise typer.Exit(1)
            console.print()
            console.print(f"[yellow]{glyphs.warning} Telemetry consent not configured[/yellow]")
            console.print()
            console.print("Before submitting feedback, you must consent to data collection.")
            console.print("To see what data is collected: obra telemetry explain")
            console.print()

            # Interactive prompt to enable telemetry inline
            allow = typer.confirm("Enable telemetry and submit feedback?", default=False)
            if allow:
                _save_feedback_consent(True)
                console.print("[green]Telemetry enabled. Submitting feedback...[/green]")
                return True

            _save_feedback_consent(False)
            console.print()
            console.print("Telemetry disabled. Enable later with: obra telemetry enable")
            console.print()
            raise typer.Exit(1)

        return False

    except typer.Exit:
        raise
    except Exception as e:
        print_error(f"Failed to check telemetry consent: {e}")
        raise typer.Exit(1) from e


telemetry_app = typer.Typer(
    name="telemetry",
    help="Manage telemetry and feedback data collection",
    rich_markup_mode="rich",
)
app.add_typer(telemetry_app, name="telemetry", rich_help_panel="Feedback & Bug Reporting")


@telemetry_app.command("enable")
@handle_encoding_errors
def telemetry_enable() -> None:
    """Enable telemetry and feedback data collection.

    Grants consent for Obra to collect diagnostic data when you submit
    bug reports or feedback. Data is used to improve Obra and prioritize fixes.

    You can revoke consent at any time with: obra telemetry disable

    Example:
        obra telemetry enable
    """
    try:
        _save_feedback_consent(True)
        print_success(f"{glyphs.success} Telemetry enabled")
        console.print()
        console.print("Thank you for helping improve Obra!")
        console.print(
            "Data will be collected when you submit feedback with: obra feedback bug/feature/comment"
        )
        console.print()
        console.print("To see what data is collected: obra telemetry explain")
        console.print("To disable: obra telemetry disable")
    except typer.Exit:
        raise
    except Exception as e:
        print_error(f"Failed to enable telemetry: {e}")
        raise typer.Exit(1) from e


@telemetry_app.command("disable")
@handle_encoding_errors
def telemetry_disable() -> None:
    """Disable telemetry and feedback data collection.

    Revokes consent for data collection. Bug reports and feedback submissions
    will be blocked until you re-enable telemetry.

    Example:
        obra telemetry disable
    """
    try:
        _save_feedback_consent(False)
        print_success(f"{glyphs.success} Telemetry disabled")
        console.print()
        console.print("Data collection has been disabled.")
        console.print("Note: Feedback submission will be blocked until you re-enable telemetry.")
        console.print()
        console.print("To re-enable: obra telemetry enable")
    except typer.Exit:
        raise
    except Exception as e:
        print_error(f"Failed to disable telemetry: {e}")
        raise typer.Exit(1) from e


@telemetry_app.command("status")
@handle_encoding_errors
def telemetry_status() -> None:
    """Show current telemetry consent status and data collection settings.

    Displays:
    - Whether telemetry is enabled or disabled
    - What data is currently being collected
    - How to change settings

    Example:
        obra telemetry status
    """
    try:
        config = _load_feedback_config()
        consent = config.get("telemetry_consent")
        data_level = config.get("data_level", "minimal")

        console.print()
        console.print("[bold]Telemetry Status[/bold]")
        console.print()

        # Consent status
        if consent is None:
            console.print("Status: [yellow]Not configured[/yellow]")
            console.print("You have not yet been asked for consent.")
            console.print()
            console.print("To enable: obra telemetry enable")
            console.print("To disable: obra telemetry disable")
        elif consent:
            console.print("Status: [green]Enabled[/green]")
            console.print("Data collection is active when you submit feedback.")
        else:
            console.print("Status: [red]Disabled[/red]")
            console.print("Data collection is blocked.")

        console.print()
        console.print(f"Data level: {data_level}")
        console.print()

        # Data fields
        data_fields = config.get("data_fields", {}).get(data_level, [])
        if data_fields:
            console.print("[bold]Data collected:[/bold]")
            for field in data_fields:
                console.print(f"  • {field}")

        console.print()
        console.print("For more details: obra telemetry explain")
        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        print_error(f"Failed to get telemetry status: {e}")
        raise typer.Exit(1) from e


@telemetry_app.command("explain")
@handle_encoding_errors
def telemetry_explain() -> None:
    """Explain what data is collected and why.

    Provides detailed information about:
    - What data Obra collects
    - Why each piece of data is collected
    - How data is protected (redaction, encryption)
    - Your privacy controls

    Example:
        obra telemetry explain
    """
    console.print()
    console.print("[bold cyan]What data does Obra collect?[/bold cyan]")
    console.print()

    console.print("[bold]When you submit feedback (bug/feature/comment):[/bold]")
    console.print()

    console.print("📊 [bold]Minimal data level[/bold] (default):")
    console.print("  • Feedback type (bug, feature request, comment)")
    console.print("  • Your description")
    console.print("  • Obra version")
    console.print("  • Timestamp")
    console.print("  • Platform (Linux, macOS, Windows)")
    console.print("  • Python version")
    console.print()

    console.print("📈 [bold]Detailed data level[/bold] (opt-in):")
    console.print("  • All minimal data, plus:")
    console.print("  • Session ID (for tracking related issues)")
    console.print("  • Stack trace (if error occurred)")
    console.print("  • Environment variables (redacted)")
    console.print("  • Recent logs (last 50 lines)")
    console.print("  • Command history (last 10 commands)")
    console.print("  • Active task ID")
    console.print()

    console.print("[bold cyan]How is your data protected?[/bold cyan]")
    console.print()
    console.print("🔒 [bold]Automatic redaction:[/bold]")
    console.print("  • API keys, tokens, passwords")
    console.print("  • AWS credentials")
    console.print("  • GitHub tokens")
    console.print("  • Home directory paths → replaced with ~")
    console.print("  • Usernames → replaced with [USER]")
    console.print("  • SSH keys, .env files, credentials")
    console.print()

    console.print("[bold cyan]Your privacy controls:[/bold cyan]")
    console.print()
    console.print(f"{glyphs.success} You must explicitly consent before ANY data is sent")
    console.print(f"{glyphs.success} In interactive mode, you can preview data before sending")
    console.print(f"{glyphs.success} You can revoke consent at any time")
    console.print(f"{glyphs.success} Non-interactive submissions are blocked without consent")
    console.print()

    console.print("[bold cyan]Why collect this data?[/bold cyan]")
    console.print()
    console.print("Your feedback helps us:")
    console.print("  • Prioritize bug fixes")
    console.print("  • Understand common issues")
    console.print("  • Improve error messages")
    console.print("  • Build features users actually need")
    console.print()

    console.print("[bold cyan]Commands:[/bold cyan]")
    console.print("  obra telemetry enable     - Grant consent")
    console.print("  obra telemetry disable    - Revoke consent")
    console.print("  obra telemetry status     - Check current settings")
    console.print()


# =============================================================================
# Derive Command (FEAT-AUTO-INTENT-001 S3.T0, S3.T1)
# =============================================================================


@app.command(rich_help_panel="Derivation")
@handle_encoding_errors
@require_terms_accepted
def derive(
    ctx: typer.Context,
    objective: str | None = typer.Argument(
        None,
        help="Objective to derive (uses active intent if not provided)",
    ),
    working_dir: str | None = typer.Option(
        None,
        "--dir",
        "-d",
        help="Working directory (defaults to current directory). WSL UNC paths are auto-converted.",
    ),
    project_id: str | None = typer.Option(
        None,
        "--project",
        help="Project ID override (optional)",
    ),
    continue_intent: bool = typer.Option(
        False,
        "--continue",
        help="Continue with active intent (explicit flag, S3.T1)",
    ),
    resume_session: str | None = typer.Option(
        None,
        "--resume",
        "-r",
        help="Resume an existing session by ID",
    ),
    continue_from: str | None = typer.Option(
        None,
        "--continue-from",
        "-c",
        help="Continue from a failed/escalated session (creates new session, skips completed tasks)",
    ),
    plan_id: str | None = typer.Option(
        None,
        "--plan-id",
        help=(
            "Use an uploaded plan by ID (from 'obra plans upload'). "
            "Requires local YAML at docs/development/{PLAN_ID}_MACHINE_PLAN.json."
        ),
    ),
    plan_file: Path | None = typer.Option(
        None,
        "--plan-file",
        help="Upload and use a plan file in one step",
    ),
    model: str | None = typer.Option(
        None,
        "--model",
        "-m",
        help="Implementation model (e.g., opus, gpt-5.2, gemini-2.5-flash)",
    ),
    fast_model: str | None = typer.Option(
        None,
        "--fast-model",
        help="Fast tier model override (used for extraction and quick validation)",
    ),
    high_model: str | None = typer.Option(
        None,
        "--high-model",
        help="High tier model override (used for complex reasoning)",
    ),
    impl_provider: str | None = typer.Option(
        None,
        "--impl-provider",
        "-p",
        help="Implementation provider (anthropic, openai, google). Requires provider CLI (claude/codex/gemini).",
    ),
    thinking_level: str | None = typer.Option(
        None,
        "--thinking-level",
        "-t",
        help="Thinking/reasoning level (off, low, medium, high, maximum)",
    ),
    no_extended_thinking: bool = typer.Option(
        False,
        "--no-extended-thinking",
        help="Disable extended thinking for derivation (equivalent to --thinking-level off)",
    ),
    verbose: int = typer.Option(
        0,
        "--verbose",
        "-v",
        count=True,
        max=3,
        help="Verbosity level (0-3, use -v/-vv/-vvv)",
    ),
    stream: bool = typer.Option(
        False,
        "--stream",
        "-s",
        help="Enable real-time LLM output streaming",
    ),
    plan_only: bool = typer.Option(
        False,
        "--plan-only",
        help="Create plan without executing (client-side exit after planning)",
    ),
    permissive: bool = typer.Option(
        False,
        "--permissive",
        help="Bypass P1 planning blockers (proceed with warnings)",
    ),
    defaults_json: bool = typer.Option(
        False,
        "--defaults-json",
        help="Print proposed defaults as JSON and exit when refinement is blocked",
    ),
    no_closeout: bool = typer.Option(
        False,
        "--no-closeout",
        help="Skip close-out story injection",
    ),
    skip_intent: bool = typer.Option(
        False,
        "--skip-intent",
        help="Skip intent generation for vague objectives (S2.T3)",
    ),
    review_intent: bool = typer.Option(
        False,
        "--review-intent",
        help="Display generated intent and prompt for approval before derive (S2.T4)",
    ),
    _enrich: bool = typer.Option(
        False,
        "--enrich",
        help="Force intent enrichment (requires planning.enrichment.enabled)",
    ),
    _no_enrich: bool = typer.Option(
        False,
        "--no-enrich",
        help="Skip intent enrichment even when enabled",
    ),
    isolated: bool | None = typer.Option(
        None,
        "--isolated",
        help="Run agent in isolated environment (prevents reading host CLI config)",
    ),
    no_isolated: bool | None = typer.Option(
        None,
        "--no-isolated",
        help="Disable isolation (use host CLI config, even in CI)",
    ),
    full_review: bool = typer.Option(
        False,
        "--full-review",
        help="Run all review agents (overrides auto-detection)",
    ),
    skip_review: bool = typer.Option(
        False,
        "--skip-review",
        help="Skip the review phase entirely",
    ),
    review_agents: str | None = typer.Option(
        None,
        "--review-agents",
        help=f"Comma-separated review agents to run ({', '.join(ALLOWED_AGENTS)})",
    ),
    with_security: bool = typer.Option(
        False,
        "--with-security",
        help="Add the security review agent",
    ),
    with_testing: bool = typer.Option(
        False,
        "--with-testing",
        help="Add the testing review agent",
    ),
    with_docs: bool = typer.Option(
        False,
        "--with-docs",
        help="Add the docs review agent",
    ),
    with_code_quality: bool = typer.Option(
        False,
        "--with-code-quality",
        help="Add the code_quality review agent",
    ),
    no_security: bool = typer.Option(
        False,
        "--no-security",
        help="Remove the security review agent",
    ),
    no_testing: bool = typer.Option(
        False,
        "--no-testing",
        help="Remove the testing review agent",
    ),
    no_docs: bool = typer.Option(
        False,
        "--no-docs",
        help="Remove the docs review agent",
    ),
    no_code_quality: bool = typer.Option(
        False,
        "--no-code-quality",
        help="Remove the code_quality review agent",
    ),
    review_format: str | None = typer.Option(
        None,
        "--review-format",
        help="Review output format (text or json)",
        show_choices=True,
    ),
    review_quiet: bool = typer.Option(
        False,
        "--review-quiet",
        help="Suppress review output",
    ),
    review_summary_only: bool = typer.Option(
        False,
        "--review-summary-only",
        help="Show only review summary counts",
    ),
    fail_on_p1: bool = typer.Option(
        False,
        "--fail-on-p1",
        help="Exit with status 1 when P1 findings are present",
    ),
    fail_on_p2: bool = typer.Option(
        False,
        "--fail-on-p2",
        help="Exit with status 1 when P1 or P2 findings are present",
    ),
    review_timeout: int | None = typer.Option(
        None,
        "--review-timeout",
        min=1,
        help="Per-agent review timeout in seconds",
    ),
    auto_report: bool = typer.Option(
        False,
        "--auto-report",
        help="Automatically submit bug reports on failure (no prompt, for CI/CD)",
    ),
    skip_git_check: bool = typer.Option(
        False,
        "--skip-git-check",
        help="Skip git repository validation (GIT-HARD-001)",
    ),
    auto_init_git: bool = typer.Option(
        False,
        "--auto-init-git",
        help="Auto-initialize git repository if not present (GIT-HARD-001)",
    ),
    skip_quality_check: bool = typer.Option(
        False,
        "--skip-quality-check",
        help="Skip UserPlan quality assessment (for debugging, testing, or high-confidence plans)",
    ),
    skip_complexity_check: bool = typer.Option(
        False,
        "--skip-complexity-check",
        help="Skip complexity estimation for derived plan items (for faster derivation)",
    ),
    force_empty: bool = typer.Option(
        False, "--force-empty", help="Force EMPTY project state (new/minimal project)"
    ),
    force_existing: bool = typer.Option(
        False,
        "--force-existing",
        help="Force EXISTING project state (established codebase)",
    ),
    from_step: int | None = typer.Option(
        None,
        "--from-step",
        "-f",
        min=1,
        help="Re-derive from step N onwards (1-indexed). Steps 1 to N-1 retain existing derivation.",
    ),
    cascade: bool = typer.Option(
        False,
        "--cascade",
        help="Mark sibling steps after the edited/re-derived step as STALE for staleness propagation.",
    ),
    work_type: str | None = typer.Option(
        None,
        "--work-type",
        "-w",
        help=(
            f"Override automatic work type detection. "
            f"Valid types: {', '.join(VALID_WORK_TYPES[:-1])}. "
            f"When provided, bypasses auto-detection and uses the specified work type."
        ),
    ),
    skip_explore: bool = typer.Option(
        False,
        "--skip-explore",
        help="Skip automatic codebase exploration before derivation (FEAT-AUTO-EXPLORE-001)",
    ),
    force_explore: bool = typer.Option(
        False,
        "--force-explore",
        help="Force codebase exploration even for simple objectives (FEAT-AUTO-EXPLORE-001)",
    ),
    local: bool = typer.Option(
        False,
        "--local",
        help="Use local Firebase emulator instead of production (requires emulators running)",
    ),
) -> None:
    """Derive execution plan from objective or active intent.

    Obra's derive command creates an execution plan from your objective.
    If you don't provide an objective, it will use the active intent
    for the current project (created via 'obra intent new').

    Examples:
        obra derive "add user authentication"
        obra derive                              # Uses active intent
        obra derive --continue                   # Explicit continue with active intent
        obra derive "refactor API" --plan-only
        obra derive --stream -vv
        obra derive --from-step 3                # Re-derive from step 3 onwards
        obra derive --no-extended-thinking       # Disable extended thinking
        obra derive "add auth" --local           # Use local Firebase emulator

    With active intent:
        obra intent new "add auth"
        obra derive                              # Uses "add auth" intent
        obra derive --continue                   # Explicit form

    Incremental re-derivation:
        obra derive --from-step N                # Re-derive steps N, N+1, N+2, ...
                                                 # Steps 1 to N-1 retain existing derivation
        obra derive --from-step N --cascade      # Re-derive step N and mark steps after N as STALE

    Environment Variables:
        OBRA_MODEL          Default model (e.g., opus, gpt-5.2, gemini-2.5-flash)
        OBRA_FAST_MODEL     Fast tier override (e.g., haiku, gpt-5.1-codex-mini)
        OBRA_HIGH_MODEL     High tier override (e.g., opus, gpt-5.2)
        OBRA_PROVIDER       Default provider (anthropic, openai, google)
        OBRA_THINKING_LEVEL Default thinking level (off, low, medium, high, maximum)
        OBRA_ISOLATED       Enable/disable isolation (true/false)

    Precedence: CLI flags > environment variables > config file

    Reference: FEAT-AUTO-INTENT-001 S3.T0, S3.T1
    """
    verbose = _resolve_command_verbosity(ctx, verbose)
    # Handle --local flag: use local Firebase emulator
    if local:
        from obra.config import enable_local_mode

        enable_local_mode()
        print_info("Local mode: Using Firebase emulator at localhost:5001")

    from obra.intent import IntentStorage

    # Normalize WSL UNC paths before creating Path object
    if working_dir is not None:
        normalized_path = _normalize_wsl_unc_path(working_dir)
        work_dir = Path(normalized_path).expanduser().resolve(strict=False)
    else:
        work_dir = Path.cwd()
    storage = IntentStorage()
    proj_id = storage.get_project_id(work_dir)

    # Validate force flags are mutually exclusive
    if force_empty and force_existing:
        console.print()
        print_error("Cannot specify both --force-empty and --force-existing")
        console.print()
        raise typer.Exit(1)

    # Validate --work-type if provided
    if work_type is not None and work_type not in VALID_WORK_TYPES:
        console.print()
        print_error(f"Invalid work type: '{work_type}'")
        console.print()
        console.print("Valid work types:")
        for wt in VALID_WORK_TYPES:
            console.print(f"  - {wt}")
        console.print()
        raise typer.Exit(1)

    # Determine objective source
    if objective:
        # Explicit objective provided
        final_objective = objective
        if not continue_intent:
            # S3.T4: Non-blocking notice when creating new intent while active exists
            active_intent = storage.load_active(proj_id)
            if active_intent:
                console.print()
                print_info(
                    f"Note: Active intent '{active_intent.slug}' exists. "
                    "New derivation will create a separate intent."
                )
                console.print(
                    "      To use the active intent, run: [cyan]obra derive[/cyan] (no objective)"
                )
                console.print()
    elif continue_intent or objective is None:
        # No objective: use active intent (S3.T0, S3.T1)
        active_intent = storage.load_active(proj_id)

        if not active_intent:
            # S3.T3: Error handling for missing active intent
            console.print()
            print_error("No active intent found for this project")
            console.print()
            console.print("To create an intent:")
            console.print("  [cyan]obra intent new 'your objective'[/cyan]")
            console.print()
            console.print("Or provide an objective directly:")
            console.print("  [cyan]obra derive 'your objective'[/cyan]")
            console.print()
            raise typer.Exit(1)

        # Use the raw objective from the active intent
        final_objective = active_intent.raw_objective or active_intent.problem_statement
        console.print()
        print_info(f"Using active intent: {active_intent.slug}")
        console.print(f"  [dim]Problem: {active_intent.problem_statement[:60]}...[/dim]")
        console.print()
    else:
        # Should not reach here, but handle gracefully
        console.print()
        print_error("No objective provided and no active intent found")
        console.print()
        console.print("Usage:")
        console.print("  [cyan]obra derive 'objective'[/cyan]")
        console.print("  [cyan]obra derive[/cyan] (uses active intent)")
        console.print()
        raise typer.Exit(1)

    # Handle --no-extended-thinking flag: override thinking_level to "off"
    effective_thinking_level = thinking_level
    if no_extended_thinking:
        if thinking_level is not None and thinking_level != "off":
            print_warning(f"--no-extended-thinking overrides --thinking-level {thinking_level}")
        effective_thinking_level = "off"

    # Call _run_derive with the resolved objective
    _run_derive(
        objective=final_objective,
        working_dir=work_dir,
        project_id=project_id,
        resume_session=resume_session,
        continue_from=continue_from,
        plan_id=plan_id,
        plan_file=plan_file,
        model=model,
        fast_model=fast_model,
        high_model=high_model,
        impl_provider=impl_provider,
        thinking_level=effective_thinking_level,
        verbose=verbose,
        stream=stream,
        plan_only=plan_only,
        permissive=permissive,
        defaults_json=defaults_json,
        no_closeout=no_closeout,
        skip_intent=skip_intent,
        review_intent=review_intent,
        isolated=isolated,
        no_isolated=no_isolated,
        full_review=full_review,
        skip_review=skip_review,
        review_agents=review_agents,
        with_security=with_security,
        with_testing=with_testing,
        with_docs=with_docs,
        with_code_quality=with_code_quality,
        no_security=no_security,
        no_testing=no_testing,
        no_docs=no_docs,
        no_code_quality=no_code_quality,
        review_format=review_format,
        review_quiet=review_quiet,
        review_summary_only=review_summary_only,
        fail_on_p1=fail_on_p1,
        fail_on_p2=fail_on_p2,
        review_timeout=review_timeout,
        auto_report=auto_report,
        skip_git_check=skip_git_check,
        auto_init_git=auto_init_git,
        skip_quality_check=skip_quality_check,
        skip_complexity_check=skip_complexity_check,
        from_step=from_step,
        cascade=cascade,
        work_type=work_type,
        skip_explore=skip_explore,
        force_explore=force_explore,
    )


# =============================================================================
# Intent Commands (FEAT-AUTO-INTENT-001)
# =============================================================================

intent_app = typer.Typer(
    name="intent",
    help="Manage intent capture for derivation workflows",
    rich_markup_mode="rich",
)
app.add_typer(intent_app, name="intent", rich_help_panel="Derivation")


@intent_app.command("new")
@handle_encoding_errors
def intent_new(
    objective: str = typer.Argument(
        None, help="User objective (natural language). Omit if using --prd or --plan."
    ),
    prd: Path | None = typer.Option(None, "--prd", help="Path to PRD file to extract intent from"),
    plan: Path | None = typer.Option(
        None,
        "--plan",
        help="Path to plan file (structured or prose) to extract intent from",
    ),
    force_empty: bool = typer.Option(
        False, "--force-empty", help="Force EMPTY project state (new/minimal project)"
    ),
    force_existing: bool = typer.Option(
        False,
        "--force-existing",
        help="Force EXISTING project state (established codebase)",
    ),
    detect_project_state: bool = typer.Option(
        False,
        "--detect-project-state",
        help="Enable project state detection for PRD/plan inputs (skipped by default)",
    ),
) -> None:
    """Create a new intent from an objective or file.

    Generates a structured intent with problem statement, assumptions,
    requirements, acceptance criteria, and non-goals using LLM.

    The intent is saved to ~/.obra/intents/{project}/ and set as the
    active intent for the project.

    Examples:
        obra intent new "add user authentication"
        obra intent new --prd docs/AUTH_PRD.md
        obra intent new --plan docs/IMPLEMENTATION_PLAN.md
        obra intent new --plan docs/MACHINE_PLAN.json

    The intent can then be used with 'obra derive' or 'obra derive --continue'.
    """
    from obra.config.llm import get_project_planning_config
    from obra.hybrid.handlers.intent import IntentHandler
    from obra.intent import IntentStorage
    from obra.intent.detection import is_structured_plan_file
    from obra.intent.models import InputType

    try:
        working_dir = Path.cwd()
        storage = IntentStorage()
        project_id = storage.get_project_id(working_dir)

        # Validate inputs
        input_count = sum([bool(objective), bool(prd), bool(plan)])
        if input_count > 1:
            console.print()
            print_error("Cannot specify multiple input types")
            console.print("  Use one of:")
            console.print("    • obra intent new 'objective'")
            console.print("    • obra intent new --prd <file>")
            console.print("    • obra intent new --plan <file>")
            console.print()
            raise typer.Exit(1)

        if input_count == 0:
            console.print()
            print_error("Must specify an input")
            console.print("  Use one of:")
            console.print("    • obra intent new 'objective'")
            console.print("    • obra intent new --prd <file>")
            console.print("    • obra intent new --plan <file>")
            console.print()
            raise typer.Exit(1)

        # Validate force flags are mutually exclusive
        if force_empty and force_existing:
            console.print()
            print_error("Cannot specify both --force-empty and --force-existing")
            console.print()
            raise typer.Exit(1)

        # Determine input type and source
        if prd:
            if not prd.exists():
                console.print()
                print_error(f"PRD file not found: {prd}")
                console.print()
                raise typer.Exit(1)

            input_source = str(prd)
            input_type = InputType.PRD
            console.print()
            print_info(f"Extracting intent from PRD: {prd.name}")
            console.print()
        elif plan:
            if not plan.exists():
                console.print()
                print_error(f"Plan file not found: {plan}")
                console.print()
                raise typer.Exit(1)

            input_source = str(plan)
            # Auto-detect structured vs prose plan
            if is_structured_plan_file(plan):
                input_type = InputType.STRUCTURED_PLAN
                console.print()
                print_info(f"Mechanically extracting intent from structured plan: {plan.name}")
                console.print()
            else:
                input_type = InputType.PROSE_PLAN
                console.print()
                print_info(f"Extracting intent from prose plan: {plan.name}")
                console.print()
        else:
            input_source = objective
            input_type = None  # Auto-detect
            console.print()
            print_info(f"Generating intent from: {objective[:60]}...")
            console.print()

        # Get LLM config
        planning_config = get_project_planning_config(working_dir)
        llm_config = {
            "provider": planning_config.get("provider", DEFAULT_PROVIDER),
            "model": planning_config.get("model", DEFAULT_MODEL),
            "thinking_level": planning_config.get("thinking_level", DEFAULT_THINKING_LEVEL),
        }

        # Generate intent
        handler = IntentHandler(
            working_dir=working_dir,
            project=project_id,
            llm_config=llm_config,
        )
        intent = handler.generate(
            input_source,
            input_type=input_type,
            force_empty=force_empty,
            force_existing=force_existing,
            detect_project_state_flag=detect_project_state,
        )

        # Save intent
        file_path = storage.save(intent)

        # Write project-local pointer for LLM discoverability
        pointer_path = storage.write_project_pointer(working_dir, intent)

        console.print()
        print_success(f"Created intent: {intent.id}")
        console.print()
        console.print(f"  [cyan]Problem:[/cyan] {intent.problem_statement}")
        console.print(f"  [cyan]Requirements:[/cyan] {len(intent.requirements)} items")
        console.print(f"  [cyan]Acceptance:[/cyan] {len(intent.acceptance_criteria)} criteria")
        console.print()
        console.print(f"  [dim]Saved to: {file_path}[/dim]")
        console.print()

        # Machine-parseable output for LLM agents
        console.print("[dim]── LLM-parseable output ──[/dim]")
        console.print("INTENT_ACTIVE=true")
        console.print(f"INTENT_ID={intent.id}")
        console.print(f"INTENT_FILE={pointer_path}")
        console.print(f"INTENT_SUMMARY={intent.problem_statement[:100]}...")
        console.print()

        console.print("Next steps:")
        console.print("  • [cyan]obra derive[/cyan] - Derive plan using this intent")
        console.print("  • [cyan]obra intent show[/cyan] - View intent details")
        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        console.print()
        display_error(e, console)
        logger.exception("Intent generation failed")
        raise typer.Exit(1) from e


@intent_app.command("list")
@handle_encoding_errors
def intent_list(
    here: bool = typer.Option(False, "--here", help="Show only intents for current project"),
) -> None:
    """List all intents.

    Shows PROJECT, CREATED, SLUG, and STATUS columns for all intents.
    Use --here to filter to the current project only.

    Examples:
        obra intent list
        obra intent list --here
    """
    from obra.intent import IntentStorage

    try:
        working_dir = Path.cwd()
        storage = IntentStorage()
        project_id = storage.get_project_id(working_dir) if here else None

        intents = storage.list_intents(project=project_id)

        if not intents:
            console.print()
            if here:
                print_info("No intents found for this project")
                console.print()
                console.print("Create an intent with:")
                console.print("  [cyan]obra intent new 'your objective'[/cyan]")
            else:
                print_info("No intents found")
            console.print()
            return

        # Build table
        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("PROJECT", style="dim")
        table.add_column("CREATED", style="yellow")
        table.add_column("SLUG", style="green")
        table.add_column("STATUS", justify="center")

        for intent in intents:
            status = f"{glyphs.success} Active" if intent.get("is_active") else ""
            table.add_row(
                intent.get("project", ""),
                intent.get("created", ""),
                intent.get("slug", ""),
                status,
            )

        console.print()
        console.print(table)
        console.print()
        console.print(f"  Total: {len(intents)} intent(s)")
        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        console.print()
        display_error(e, console)
        logger.exception("Intent list failed")
        raise typer.Exit(1) from e


@intent_app.command("show")
@handle_encoding_errors
def intent_show(
    intent_id: str | None = typer.Argument(
        None,
        help="Intent ID to show (full, timestamp, or slug). Omit to show active intent.",
    ),
    machine: bool = typer.Option(
        False,
        "--machine",
        help="Output in machine-parseable key=value format for LLM agents",
    ),
) -> None:
    """Show details of an intent.

    If no ID is provided, shows the active intent for the current project.
    Otherwise, resolves the ID (supports full ID, timestamp, or slug) and
    displays the specified intent.

    Use --machine for LLM-parseable output format.

    Examples:
        obra intent show                           # Show active intent
        obra intent show 20260110T1200-add-auth    # Full ID
        obra intent show 20260110T1200             # Timestamp only
        obra intent show add-auth                  # Slug only
        obra intent show --machine                 # Machine-parseable output
    """
    from obra.intent import IntentStorage

    try:
        working_dir = Path.cwd()
        storage = IntentStorage()
        project_id = storage.get_project_id(working_dir)

        # Load intent
        if intent_id:
            # Resolve partial ID to full ID
            resolved_id = storage.resolve_id(intent_id, project_id)
            if not resolved_id:
                if machine:
                    console.print("INTENT_ACTIVE=false")
                    console.print(f"INTENT_ERROR=Intent not found: {intent_id}")
                    console.print(
                        "INTENT_HINT=Run 'obra intent list --here' to see available intents"
                    )
                else:
                    console.print()
                    print_error(f"Intent not found: {intent_id}")
                    console.print()
                    console.print("Available intents:")
                    console.print("  [cyan]obra intent list --here[/cyan]")
                    console.print()
                raise typer.Exit(1)

            intent = storage.load(resolved_id, project_id)
            if not intent:
                if machine:
                    console.print("INTENT_ACTIVE=false")
                    console.print(f"INTENT_ERROR=Failed to load intent: {resolved_id}")
                else:
                    console.print()
                    print_error(f"Failed to load intent: {resolved_id}")
                    console.print()
                raise typer.Exit(1)
        else:
            # Load active intent
            intent = storage.load_active(project_id)
            if not intent:
                if machine:
                    console.print("INTENT_ACTIVE=false")
                    console.print(
                        "INTENT_HINT=Run 'obra intent new \"<objective>\"' to create an intent"
                    )
                else:
                    console.print()
                    print_info("No active intent for this project")
                    console.print()
                    console.print("Create an intent with:")
                    console.print("  [cyan]obra intent new 'your objective'[/cyan]")
                    console.print()
                raise typer.Exit(0)

        # Get pointer file path
        pointer_path = working_dir / ".obra" / "active_intent.yaml"
        intent_file_path = storage.root / intent.project / f"{intent.id}.md"

        if machine:
            # Machine-parseable output for LLM agents
            console.print("INTENT_ACTIVE=true")
            console.print(f"INTENT_ID={intent.id}")
            console.print(f"INTENT_PROJECT={intent.project}")
            console.print(f"INTENT_STATUS={intent.status.value}")
            console.print(f"INTENT_FILE={pointer_path}")
            console.print(f"INTENT_FULL_PATH={intent_file_path}")
            console.print(f"INTENT_SUMMARY={intent.problem_statement}")
            if intent.requirements:
                console.print(f"INTENT_REQUIREMENTS={'|'.join(intent.requirements)}")
            if intent.acceptance_criteria:
                console.print(f"INTENT_ACCEPTANCE_CRITERIA={'|'.join(intent.acceptance_criteria)}")
            if intent.assumptions:
                console.print(f"INTENT_ASSUMPTIONS={'|'.join(intent.assumptions)}")
            if intent.non_goals:
                console.print(f"INTENT_NON_GOALS={'|'.join(intent.non_goals)}")
        else:
            # Human-readable output
            console.print()
            console.print(f"[bold cyan]Intent: {intent.slug}[/bold cyan]")
            console.print(f"[dim]ID: {intent.id}[/dim]")
            console.print(f"[dim]Project: {intent.project}[/dim]")
            console.print(f"[dim]Status: {intent.status.value}[/dim]")
            console.print()

            console.print("[bold]Problem Statement:[/bold]")
            console.print(f"  {intent.problem_statement}")
            console.print()

            if intent.assumptions:
                console.print("[bold]Assumptions:[/bold]")
                for assumption in intent.assumptions:
                    console.print(f"  • {assumption}")
                console.print()

            if intent.requirements:
                console.print("[bold]Requirements:[/bold]")
                for req in intent.requirements:
                    console.print(f"  • {req}")
                console.print()

            if intent.acceptance_criteria:
                console.print("[bold]Acceptance Criteria:[/bold]")
                for criterion in intent.acceptance_criteria:
                    console.print(f"  • {criterion}")
                console.print()

            if intent.non_goals:
                console.print("[bold]Non-Goals:[/bold]")
                for non_goal in intent.non_goals:
                    console.print(f"  • {non_goal}")
                console.print()

            if intent.context_amendments:
                console.print("[bold]Context Amendments:[/bold]")
                for amendment in intent.context_amendments:
                    console.print(f"  • {amendment}")
                console.print()

            console.print("Next steps:")
            console.print("  • [cyan]obra derive[/cyan] - Derive plan using this intent")
            console.print("  • [cyan]obra context add 'info'[/cyan] - Amend the intent")
            console.print()

    except typer.Exit:
        raise
    except Exception as e:
        if machine:
            console.print("INTENT_ACTIVE=false")
            console.print(f"INTENT_ERROR={e}")
        else:
            console.print()
            display_error(e, console)
        logger.exception("Intent show failed")
        raise typer.Exit(1) from e


@intent_app.command("use")
@handle_encoding_errors
def intent_use(
    intent_id: str = typer.Argument(
        ..., help="Intent ID to set as active (full, timestamp, or slug)"
    ),
) -> None:
    """Set an intent as the active intent for the current project.

    The active intent is used by 'obra derive' (with no objective) and
    'obra context add' commands.

    Examples:
        obra intent use 20260110T1200-add-auth    # Full ID
        obra intent use 20260110T1200             # Timestamp only
        obra intent use add-auth                  # Slug only
    """
    from obra.intent import IntentStorage

    try:
        working_dir = Path.cwd()
        storage = IntentStorage()
        project_id = storage.get_project_id(working_dir)

        # Resolve partial ID to full ID
        resolved_id = storage.resolve_id(intent_id, project_id)
        if not resolved_id:
            console.print()
            print_error(f"Intent not found: {intent_id}")
            console.print()
            console.print("Available intents:")
            console.print("  [cyan]obra intent list --here[/cyan]")
            console.print()
            raise typer.Exit(1)

        # Set as active
        success = storage.set_active(resolved_id, project_id)
        if not success:
            console.print()
            print_error(f"Failed to set active intent: {resolved_id}")
            console.print()
            raise typer.Exit(1)

        # Load intent for pointer file and summary
        intent = storage.load(resolved_id, project_id)
        if intent:
            # Write project-local pointer for LLM discoverability
            pointer_path = storage.write_project_pointer(working_dir, intent)

            console.print()
            print_success(f"Active intent set: {resolved_id}")
            console.print()

            # Machine-parseable output for LLM agents
            console.print("[dim]── LLM-parseable output ──[/dim]")
            console.print("INTENT_ACTIVE=true")
            console.print(f"INTENT_ID={intent.id}")
            console.print(f"INTENT_FILE={pointer_path}")
            console.print(
                f"INTENT_SUMMARY={intent.problem_statement[:100] if intent.problem_statement else ''}..."
            )
            console.print()
        else:
            console.print()
            print_success(f"Active intent set: {resolved_id}")
            console.print()

        console.print("Next steps:")
        console.print("  • [cyan]obra derive[/cyan] - Derive plan using this intent")
        console.print("  • [cyan]obra intent show[/cyan] - View intent details")
        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        console.print()
        display_error(e, console)
        logger.exception("Intent use failed")
        raise typer.Exit(1) from e


@intent_app.command("delete")
@handle_encoding_errors
def intent_delete(
    intent_id: str = typer.Argument(..., help="Intent ID to delete (full, timestamp, or slug)"),
) -> None:
    """Delete an intent from storage.

    If the intent is currently active, it will be removed from active status
    and a warning will be displayed.

    Examples:
        obra intent delete 20260110T1200-add-auth    # Full ID
        obra intent delete 20260110T1200             # Timestamp only
        obra intent delete add-auth                  # Slug only
    """
    from obra.intent import IntentStorage

    try:
        working_dir = Path.cwd()
        storage = IntentStorage()
        project_id = storage.get_project_id(working_dir)

        # Resolve partial ID to full ID
        resolved_id = storage.resolve_id(intent_id, project_id)
        if not resolved_id:
            console.print()
            print_error(f"Intent not found: {intent_id}")
            console.print()
            console.print("Available intents:")
            console.print("  [cyan]obra intent list --here[/cyan]")
            console.print()
            raise typer.Exit(1)

        # Check if this is the active intent
        active_intent = storage.load_active(project_id)
        is_active = active_intent and active_intent.id == resolved_id

        if is_active:
            console.print()
            print_warning(f"Warning: Deleting active intent: {resolved_id}")
            console.print()

        # Delete
        success = storage.delete(resolved_id, project_id)
        if not success:
            console.print()
            print_error(f"Failed to delete intent: {resolved_id}")
            console.print()
            raise typer.Exit(1)

        # Remove project pointer if this was the active intent
        if is_active:
            storage.remove_project_pointer(working_dir)

        console.print()
        print_success(f"Deleted intent: {resolved_id}")
        console.print()

        if is_active:
            console.print("Note: This was the active intent. Set a new active intent with:")
            console.print("  [cyan]obra intent use <id>[/cyan]")
            console.print()

    except typer.Exit:
        raise
    except Exception as e:
        console.print()
        display_error(e, console)
        logger.exception("Intent delete failed")
        raise typer.Exit(1) from e


@intent_app.command("export")
@handle_encoding_errors
def intent_export() -> None:
    """Export the active intent to the project docs/intents/ directory.

    Renders the active intent to markdown and saves to docs/intents/{intent-id}.md
    in the current project directory.

    Example:
        obra intent export
    """
    from obra.intent import IntentStorage

    try:
        working_dir = Path.cwd()
        storage = IntentStorage()
        project_id = storage.get_project_id(working_dir)

        # Load active intent
        intent = storage.load_active(project_id)
        if not intent:
            console.print()
            print_info("No active intent for this project")
            console.print()
            console.print("Create an intent with:")
            console.print("  [cyan]obra intent new 'your objective'[/cyan]")
            console.print()
            raise typer.Exit(0)

        # Create docs/intents/ directory
        export_dir = working_dir / "docs" / "intents"
        export_dir.mkdir(parents=True, exist_ok=True)

        # Render and write intent markdown
        from obra.intent.templates import render_intent_template

        export_file = export_dir / f"{intent.id}.md"
        export_file.write_text(render_intent_template(intent), encoding="utf-8")

        console.print()
        print_success(f"Exported intent: {intent.id}")
        console.print()
        console.print(f"  [dim]Saved to: {export_file}[/dim]")
        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        console.print()
        display_error(e, console)
        logger.exception("Intent export failed")
        raise typer.Exit(1) from e


# =============================================================================
# UserPlan Commands
# =============================================================================

userplan_app = typer.Typer(
    name="userplan",
    help="Manage UserPlans for derivation workflows",
    rich_markup_mode="rich",
)
app.add_typer(userplan_app, name="userplan", rich_help_panel="Derivation")


@userplan_app.command("add")
@handle_encoding_errors
def userplan_add(
    input_source: str = typer.Argument(
        ...,
        help="File path (YAML/JSON) or objective string to create UserPlan from",
    ),
    project_id: str | None = typer.Option(
        None,
        "--project",
        "-p",
        help="Project identifier (defaults to current directory name)",
    ),
    session_id: str | None = typer.Option(
        None,
        "--session",
        "-s",
        help="Session identifier to associate with the UserPlan",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
) -> None:
    """Create a new UserPlan from a file or objective string.

    Accepts either:
    - A file path containing a UserPlan (YAML/JSON with steps array)
    - An objective string to generate a UserPlan from using LLM

    Examples:
        obra userplan add "Add user authentication with JWT tokens"
        obra userplan add path/to/userplan.yaml
        obra userplan add plan.json --project my-project
        obra userplan add "Implement caching layer" --session abc123
    """
    import asyncio

    from obra.api import APIClient
    from obra.config.llm import get_project_planning_config
    from obra.execution.intake import UserPlanIntake
    from obra.llm.invoker import LLMInvoker

    try:
        working_dir = Path.cwd()

        # Determine project_id from directory if not provided
        effective_project_id = project_id or working_dir.name

        # Check if input_source is a file path
        input_path = Path(input_source)
        is_file_input = input_path.exists() and input_path.is_file()

        if is_file_input:
            # Read file content
            console.print()
            print_info(f"Reading UserPlan from file: {input_path.name}")
            console.print()

            try:
                file_content = input_path.read_text(encoding="utf-8")
            except OSError as e:
                console.print()
                print_error(f"Failed to read file: {e}")
                console.print()
                raise typer.Exit(1) from e

            if not file_content.strip():
                console.print()
                print_error("File is empty")
                console.print()
                raise typer.Exit(1)

            input_text = file_content
        else:
            # Treat as objective string
            if not input_source.strip():
                console.print()
                print_error("Objective cannot be empty")
                console.print()
                raise typer.Exit(1)

            console.print()
            print_info(f"Generating UserPlan from objective: {input_source[:60]}...")
            console.print()

            input_text = input_source

        # Get LLM config for generation
        planning_config = get_project_planning_config(working_dir)
        llm_config = {
            "provider": planning_config.get("provider", DEFAULT_PROVIDER),
            "model": planning_config.get("model", DEFAULT_MODEL),
            "thinking_level": planning_config.get("thinking_level", DEFAULT_THINKING_LEVEL),
        }

        # Create LLM invoker for potential generation
        llm_invoker = LLMInvoker(default_provider=llm_config["provider"])

        # Create intake handler
        intake = UserPlanIntake(
            llm_invoker=llm_invoker,
            thinking_enabled=True,
            thinking_level=llm_config["thinking_level"],
            provider=llm_config["provider"],
        )

        # Process input (async)
        result = asyncio.run(
            intake.process(
                input_text=input_text,
                project_id=effective_project_id,
                session_id=session_id,
            )
        )

        userplan = result.userplan

        # Store UserPlan to server via API client
        userplan_source_dict = {
            "type": userplan.source.type.value,
            "path": userplan.source.path or (str(input_path) if is_file_input else None),
            "raw_objective": userplan.source.raw_objective,
            "generated": userplan.source.generated,
        }
        userplan_steps_list = [
            {
                "id": step.id,
                "index": step.index,
                "title": step.title,
                "description": step.description,
                "raw_text": step.raw_text,
                "derivation_status": step.derivation_status.value,
                "context": step.context.model_dump() if step.context else None,
            }
            for step in userplan.steps
        ]

        api_client = APIClient.from_config()
        api_client.create_userplan(
            userplan_id=userplan.id,
            project_id=userplan.project_id,
            source=userplan_source_dict,
            steps=userplan_steps_list,
            session_id=session_id,
            status=userplan.status.value,
            quality_score=userplan.quality_score,
            quality_status=userplan.quality_status.value,
            work_type=userplan.work_type.value if userplan.work_type else None,
            context=userplan.context.model_dump() if userplan.context else None,
            metadata=userplan.metadata,
        )

        # Output results
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_success(
                data={
                    "userplan": {
                        "id": userplan.id,
                        "project_id": userplan.project_id,
                        "status": userplan.status.value,
                        "source": {
                            "type": userplan.source.type.value,
                            "generated": userplan.source.generated,
                        },
                        "quality_score": userplan.quality_score,
                        "quality_status": userplan.quality_status.value,
                        "work_type": (userplan.work_type.value if userplan.work_type else None),
                        "step_count": len(userplan.steps),
                        "steps": [
                            {
                                "id": step.id,
                                "index": step.index,
                                "title": step.title,
                                "description": step.description,
                                "derivation_status": step.derivation_status.value,
                            }
                            for step in userplan.steps
                        ],
                    },
                    "was_generated": result.was_generated,
                },
                ids={
                    "userplan_id": userplan.id,
                    "project_id": userplan.project_id,
                },
            )
            return

        console.print()
        if result.was_generated:
            print_success(f"Generated and stored UserPlan: {userplan.id}")
        else:
            print_success(f"Stored UserPlan: {userplan.id}")
        console.print()

        # Show summary
        console.print(f"  [cyan]ID:[/cyan] {userplan.id}")
        console.print(f"  [cyan]Project:[/cyan] {userplan.project_id}")
        console.print(f"  [cyan]Steps:[/cyan] {len(userplan.steps)}")
        console.print(f"  [cyan]Source:[/cyan] {userplan.source.type.value}")
        if result.was_generated:
            console.print("  [cyan]Generated:[/cyan] Yes")
        console.print()

        # Show steps preview
        console.print("[bold]Steps:[/bold]")
        for step in userplan.steps[:5]:  # Show first 5 steps
            console.print(f"  {step.index}. {step.title}")
        if len(userplan.steps) > 5:
            console.print(f"  [dim]... and {len(userplan.steps) - 5} more[/dim]")
        console.print()

        # Machine-parseable output for LLM agents
        console.print("[dim]-- LLM-parseable output --[/dim]")
        console.print(f"USERPLAN_ID={userplan.id}")
        console.print(f"USERPLAN_PROJECT={userplan.project_id}")
        console.print(f"USERPLAN_STEPS={len(userplan.steps)}")
        console.print(f"USERPLAN_GENERATED={str(result.was_generated).lower()}")
        console.print()

        console.print("Next steps:")
        console.print(
            f"  [cyan]obra derive --userplan {userplan.id}[/cyan] - Derive plan from this UserPlan"
        )
        console.print()

    except typer.Exit:
        raise
    except APIError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="API_ERROR")
            raise typer.Exit(1) from e
        console.print()
        print_error(f"Failed to store UserPlan: {e}")
        console.print()
        logger.exception("UserPlan storage failed")
        raise typer.Exit(1) from e
    except Exception as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="UNKNOWN_ERROR")
            raise typer.Exit(1) from e
        console.print()
        display_error(e, console)
        logger.exception("UserPlan add failed")
        raise typer.Exit(1) from e


@userplan_app.command("list")
@handle_encoding_errors
def userplan_list(
    project: str | None = typer.Option(
        None,
        "--project",
        "-p",
        help="Filter by project identifier",
    ),
    status: str | None = typer.Option(
        None,
        "--status",
        "-s",
        help="Filter by status (draft, active, completed, archived)",
    ),
    limit: int = typer.Option(
        50,
        "--limit",
        "-n",
        help="Maximum number of UserPlans to list (max: 100)",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
) -> None:
    """List UserPlans.

    Displays UserPlans with ID, title (from first step), status, and step count.
    Optionally filter by project or status.

    Examples:
        obra userplan list
        obra userplan list --project my-app
        obra userplan list --status active --limit 10
        obra userplan list --format json
    """
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_error(error="Not logged in", code="AUTH_REQUIRED")
                raise typer.Exit(1)
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        # Get UserPlans from server
        client = APIClient.from_config()
        userplans = client.list_userplans(project_id=project, status=status, limit=limit)

        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_success(
                data={
                    "userplans": [
                        {
                            "id": up.get("id"),
                            "project_id": up.get("project_id"),
                            "status": up.get("status"),
                            "step_count": up.get("step_count", len(up.get("steps", []))),
                            "quality_score": up.get("quality_score"),
                            "quality_status": up.get("quality_status"),
                            "created_at": up.get("created_at"),
                            "updated_at": up.get("updated_at"),
                            "title": (
                                up.get("steps", [{}])[0].get("title", "Untitled")
                                if up.get("steps")
                                else "Untitled"
                            ),
                        }
                        for up in userplans
                    ],
                    "count": len(userplans),
                    "filters": {
                        "project": project,
                        "status": status,
                        "limit": limit,
                    },
                },
                ids={
                    "userplan_ids": ",".join(up.get("id", "") for up in userplans),
                },
            )
            return

        console.print()
        if not userplans:
            print_info("No UserPlans found")
            console.print('\nCreate a UserPlan with: [cyan]obra userplan add "objective"[/cyan]')
            return

        console.print(f"[bold]UserPlans[/bold] ({len(userplans)} total)", style="cyan")
        console.print()

        table = Table()
        table.add_column("ID", style="cyan")
        table.add_column("Title", style="bold")
        table.add_column("Status", style="dim")
        table.add_column("Steps", justify="right")
        table.add_column("Quality", justify="right")
        table.add_column("Created", style="dim")

        for up in userplans:
            userplan_id = up.get("id", "")
            # Get title from steps if available, otherwise use ID
            steps = up.get("steps", [])
            title = steps[0].get("title", "Untitled") if steps else "Untitled"
            # Truncate title for display
            if len(title) > 40:
                title = title[:37] + "..."
            status_val = up.get("status", "unknown")
            step_count = str(up.get("step_count", len(steps)))
            quality_score = up.get("quality_score")
            quality_str = f"{quality_score:.0%}" if quality_score is not None else "-"
            created_at = up.get("created_at", "N/A")

            # Format timestamp if it's ISO format
            if created_at and "T" in str(created_at):
                from datetime import datetime

                try:
                    dt = datetime.fromisoformat(str(created_at).replace("Z", "+00:00"))
                    created_at = dt.strftime("%Y-%m-%d %H:%M")
                except (ValueError, TypeError):
                    pass

            table.add_row(userplan_id, title, status_val, step_count, quality_str, created_at)

        console.print(table)
        console.print()
        console.print("[dim]Use:[/dim] [cyan]obra userplan show <id>[/cyan] to see full details")

    except typer.Exit:
        raise  # Re-raise typer.Exit to preserve exit code
    except APIError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="API_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"API error in userplan list command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="CONFIG_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"Configuration error in userplan list command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="OBRA_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"Obra error in userplan list command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="UNKNOWN_ERROR")
            raise typer.Exit(1) from e
        display_error(e, console)
        logger.exception(f"Unexpected error in userplan list command: {e}")
        raise typer.Exit(1) from e


@userplan_app.command("show")
@handle_encoding_errors
def userplan_show(
    userplan_id: str = typer.Argument(..., help="UserPlan ID to display"),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
) -> None:
    """Display details of a specific UserPlan.

    Shows complete information about a UserPlan including:
    - Metadata (ID, project, status, source)
    - Quality assessment (score, status, hints)
    - All steps with titles and descriptions

    Examples:
        obra userplan show UP-20260115-add-auth
        obra userplan show UP-20260115-add-auth --format json
    """
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_error(error="Not logged in", code="AUTH_REQUIRED")
                raise typer.Exit(1)
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        # Get UserPlan from server
        client = APIClient.from_config()
        userplan = client.get_userplan(userplan_id)

        if not userplan:
            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_error(error=f"UserPlan not found: {userplan_id}", code="NOT_FOUND")
                raise typer.Exit(1)
            print_error(f"UserPlan not found: {userplan_id}")
            raise typer.Exit(1)

        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter, serialize_userplan

            formatter = JsonOutputFormatter()
            formatter.output_success(
                data={"userplan": serialize_userplan(userplan)},
                ids={"userplan_id": userplan.get("id", "")},
            )
            return

        console.print()
        console.print("[bold cyan]UserPlan Details[/bold cyan]")
        console.print("=" * 60)
        console.print()

        # Basic info
        console.print(f"[bold]ID:[/bold]         {userplan.get('id', 'N/A')}")
        console.print(f"[bold]Project:[/bold]    {userplan.get('project_id', 'N/A')}")
        console.print(f"[bold]Status:[/bold]     {userplan.get('status', 'N/A')}")

        # Source info
        source = userplan.get("source", {})
        if source:
            source_type = source.get("type", "unknown")
            generated = source.get("generated", False)
            console.print(
                f"[bold]Source:[/bold]     {source_type}" + (" (generated)" if generated else "")
            )

        # Format and display timestamps
        created_at = userplan.get("created_at", "N/A")
        if created_at and "T" in str(created_at):
            from datetime import datetime

            try:
                dt = datetime.fromisoformat(str(created_at).replace("Z", "+00:00"))
                created_at = dt.strftime("%Y-%m-%d %H:%M:%S UTC")
            except (ValueError, TypeError):
                pass
        console.print(f"[bold]Created:[/bold]    {created_at}")

        updated_at = userplan.get("updated_at", "N/A")
        if updated_at and "T" in str(updated_at):
            from datetime import datetime

            try:
                dt = datetime.fromisoformat(str(updated_at).replace("Z", "+00:00"))
                updated_at = dt.strftime("%Y-%m-%d %H:%M:%S UTC")
            except (ValueError, TypeError):
                pass
        console.print(f"[bold]Updated:[/bold]    {updated_at}")

        # Quality assessment
        quality_score = userplan.get("quality_score")
        quality_status = userplan.get("quality_status", "not_assessed")
        if quality_score is not None or quality_status != "not_assessed":
            console.print()
            console.print("[bold]Quality Assessment:[/bold]")
            if quality_score is not None:
                console.print(f"  Score:  {quality_score:.0%}")
            console.print(f"  Status: {quality_status}")
            quality_hints = userplan.get("quality_hints", [])
            if quality_hints:
                console.print("  Hints:")
                for hint in quality_hints[:5]:  # Show first 5 hints
                    console.print(f"    - {hint}")
                if len(quality_hints) > 5:
                    console.print(f"    [dim]... and {len(quality_hints) - 5} more[/dim]")

        # Work type
        work_type = userplan.get("work_type")
        if work_type:
            console.print(f"[bold]Work Type:[/bold]  {work_type}")

        # Steps
        steps = userplan.get("steps", [])
        if steps:
            console.print()
            console.print(f"[bold]Steps[/bold] ({len(steps)} total)")
            console.print("-" * 40)

            step_table = Table(show_header=True, header_style="bold")
            step_table.add_column("#", style="cyan", justify="right")
            step_table.add_column("Title")
            step_table.add_column("Derivation", style="dim")

            for step in steps:
                step_index = str(step.get("index", "?"))
                step_title = step.get("title", "Untitled")
                # Truncate title for table display
                if len(step_title) > 50:
                    step_title = step_title[:47] + "..."
                derivation_status = step.get("derivation_status", "not_derived")
                step_table.add_row(step_index, step_title, derivation_status)

            console.print(step_table)

            # Show step descriptions in detail
            console.print()
            console.print("[bold]Step Details:[/bold]")
            for step in steps:
                step_index = step.get("index", "?")
                step_title = step.get("title", "Untitled")
                description = step.get("description", "No description")
                console.print()
                console.print(f"  [cyan]{step_index}. {step_title}[/cyan]")
                # Wrap long descriptions
                desc_lines = description.split("\n")
                for line in desc_lines[:5]:  # Show first 5 lines
                    console.print(f"     {line}")
                if len(desc_lines) > 5:
                    console.print(f"     [dim]... {len(desc_lines) - 5} more lines[/dim]")

        console.print()
        console.print(f"[dim]Derive with:[/dim] [cyan]obra derive --userplan {userplan_id}[/cyan]")

    except typer.Exit:
        raise  # Re-raise typer.Exit to preserve exit code
    except APIError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="API_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"API error in userplan show command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="CONFIG_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"Configuration error in userplan show command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="OBRA_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"Obra error in userplan show command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="UNKNOWN_ERROR")
            raise typer.Exit(1) from e
        display_error(e, console)
        logger.exception(f"Unexpected error in userplan show command: {e}")
        raise typer.Exit(1) from e


@userplan_app.command("steps")
@handle_encoding_errors
def userplan_steps(
    userplan_id: str = typer.Argument(..., help="UserPlan ID to display steps for"),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show step descriptions in addition to titles",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
) -> None:
    """Display all steps in a UserPlan with derivation status.

    Shows each step with:
    - Step sequence number and ID
    - Step title and description (with --verbose)
    - Derivation status (not_derived, deriving, derived, stale)
    - Dependencies between steps (index-based)

    Status colors:
    - Green: derived (completed)
    - Yellow: deriving (in progress)
    - Red: stale (needs re-derivation)
    - Dim: not_derived (pending)

    Examples:
        obra userplan steps UP-20260115-add-auth
        obra userplan steps UP-20260115-add-auth --verbose
        obra userplan steps UP-20260115-add-auth --format json
    """
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth
        from obra.schemas.userplan_schema import DerivationStatus

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_error(error="Not logged in", code="AUTH_REQUIRED")
                raise typer.Exit(1)
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        # Get UserPlan from server
        client = APIClient.from_config()
        userplan = client.get_userplan(userplan_id)

        if not userplan:
            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_error(error=f"UserPlan not found: {userplan_id}", code="NOT_FOUND")
                raise typer.Exit(1)
            print_error(f"UserPlan not found: {userplan_id}")
            raise typer.Exit(1)

        steps = userplan.get("steps", [])
        if not steps:
            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_success(
                    data={
                        "steps": [],
                        "summary": {
                            "total": 0,
                            "derived": 0,
                            "deriving": 0,
                            "stale": 0,
                            "pending": 0,
                        },
                    },
                    ids={"userplan_id": userplan_id},
                )
                return
            print_info(f"UserPlan {userplan_id} has no steps")
            raise typer.Exit(0)

        # Summary line
        total_steps = len(steps)
        derived_count = sum(
            1 for s in steps if s.get("derivation_status") == DerivationStatus.DERIVED.value
        )
        deriving_count = sum(
            1 for s in steps if s.get("derivation_status") == DerivationStatus.DERIVING.value
        )
        stale_count = sum(
            1 for s in steps if s.get("derivation_status") == DerivationStatus.STALE.value
        )
        not_derived_count = sum(
            1 for s in steps if s.get("derivation_status") == DerivationStatus.NOT_DERIVED.value
        )

        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter, serialize_step

            formatter = JsonOutputFormatter()
            formatter.output_success(
                data={
                    "steps": [serialize_step(s) for s in steps],
                    "summary": {
                        "total": total_steps,
                        "derived": derived_count,
                        "deriving": deriving_count,
                        "stale": stale_count,
                        "pending": not_derived_count,
                    },
                },
                ids={
                    "userplan_id": userplan_id,
                    "step_ids": ",".join(s.get("id", "") for s in steps),
                },
            )
            return

        console.print()
        console.print(f"[bold cyan]Steps for UserPlan: {userplan_id}[/bold cyan]")
        console.print()

        console.print(
            f"[bold]Total:[/bold] {total_steps} steps | "
            f"[green]Derived: {derived_count}[/green] | "
            f"[yellow]Deriving: {deriving_count}[/yellow] | "
            f"[red]Stale: {stale_count}[/red] | "
            f"[dim]Pending: {not_derived_count}[/dim]"
        )
        console.print()

        # Build steps table
        table = Table(show_header=True, header_style="bold")
        table.add_column("#", style="cyan", justify="right", width=3)
        table.add_column("Step ID", style="dim", width=30)
        table.add_column("Title", width=40)
        table.add_column("Status", width=12)
        table.add_column("Deps", width=10)

        # Map derivation status to styled text
        def status_style(status_value: str) -> str:
            """Return styled status text based on derivation status."""
            if status_value == DerivationStatus.DERIVED.value:
                return "[green]derived[/green]"
            if status_value == DerivationStatus.DERIVING.value:
                return "[yellow]deriving[/yellow]"
            if status_value == DerivationStatus.STALE.value:
                return "[red]stale[/red]"
            # NOT_DERIVED or unknown
            return "[dim]pending[/dim]"

        for step in steps:
            step_index = str(step.get("index", "?"))
            step_id = step.get("id", "N/A")
            step_title = step.get("title", "Untitled")

            # Truncate title for table display
            if len(step_title) > 38:
                step_title = step_title[:35] + "..."

            derivation_status = step.get("derivation_status", DerivationStatus.NOT_DERIVED.value)
            styled_status = status_style(derivation_status)

            # Dependencies: steps are implicitly sequential (step N depends on step N-1)
            # We show this relationship via index
            step_idx = step.get("index", 1)
            deps = f"S{step_idx - 1}" if step_idx > 1 else "-"

            table.add_row(step_index, step_id, step_title, styled_status, deps)

        console.print(table)

        # Verbose mode: show descriptions
        if verbose:
            console.print()
            console.print("[bold]Step Descriptions:[/bold]")
            console.print("-" * 60)

            for step in steps:
                step_index = step.get("index", "?")
                step_title = step.get("title", "Untitled")
                description = step.get("description", "No description")
                derivation_status = step.get(
                    "derivation_status", DerivationStatus.NOT_DERIVED.value
                )
                styled_status = status_style(derivation_status)

                console.print()
                console.print(f"[cyan]{step_index}. {step_title}[/cyan] {styled_status}")

                # Wrap and indent description
                desc_lines = description.split("\n")
                for line in desc_lines[:10]:  # Show first 10 lines
                    console.print(f"   {line}")
                if len(desc_lines) > 10:
                    console.print(f"   [dim]... {len(desc_lines) - 10} more lines[/dim]")

        console.print()

        # Machine-parseable output for LLM agents
        console.print("[dim]-- LLM-parseable output --[/dim]")
        console.print(f"USERPLAN_ID={userplan_id}")
        console.print(f"TOTAL_STEPS={total_steps}")
        console.print(f"DERIVED_STEPS={derived_count}")
        console.print(f"DERIVING_STEPS={deriving_count}")
        console.print(f"STALE_STEPS={stale_count}")
        console.print(f"PENDING_STEPS={not_derived_count}")
        console.print()

        # Suggest next actions based on status
        if stale_count > 0:
            console.print(
                "[yellow]Hint:[/yellow] Some steps are stale. "
                "Re-derive with: [cyan]obra derive --userplan {userplan_id} --from-step N[/cyan]"
            )
        elif not_derived_count > 0 and derived_count == 0:
            console.print(
                f"[dim]Next:[/dim] Derive plan with: [cyan]obra derive --userplan {userplan_id}[/cyan]"
            )
        elif not_derived_count > 0:
            # Find first pending step
            first_pending = next(
                (
                    s
                    for s in steps
                    if s.get("derivation_status") == DerivationStatus.NOT_DERIVED.value
                ),
                None,
            )
            if first_pending:
                console.print(
                    f"[dim]Next:[/dim] Continue derivation from step {first_pending.get('index')}"
                )

    except typer.Exit:
        raise  # Re-raise typer.Exit to preserve exit code
    except APIError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="API_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"API error in userplan steps command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="CONFIG_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"Configuration error in userplan steps command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="OBRA_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"Obra error in userplan steps command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="UNKNOWN_ERROR")
            raise typer.Exit(1) from e
        display_error(e, console)
        logger.exception(f"Unexpected error in userplan steps command: {e}")
        raise typer.Exit(1) from e


# =============================================================================
# UserPlan Step Subcommands
# =============================================================================

step_app = typer.Typer(
    name="step",
    help="Manage individual steps within a UserPlan",
    rich_markup_mode="rich",
)
userplan_app.add_typer(step_app, name="step")


@step_app.command("add")
@handle_encoding_errors
def userplan_step_add(
    userplan_id: str = typer.Argument(..., help="UserPlan ID to add step to"),
    title: str = typer.Option(
        ...,
        "--title",
        "-t",
        help="Step title (required)",
    ),
    description: str = typer.Option(
        ...,
        "--description",
        "-d",
        help="Step description (required)",
    ),
    index: int | None = typer.Option(
        None,
        "--index",
        "-i",
        help="Position to insert step (1-based, default: append to end)",
    ),
    deliverables: str | None = typer.Option(
        None,
        "--deliverables",
        help="Comma-separated list of deliverables",
    ),
    requirements: str | None = typer.Option(
        None,
        "--requirements",
        help="Comma-separated list of requirements",
    ),
    tech_stack: str | None = typer.Option(
        None,
        "--tech-stack",
        help="Comma-separated list of technologies",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
) -> None:
    """Add a new step to a UserPlan.

    Creates a new step with the specified title and description.
    If --index is provided, inserts at that position; otherwise appends to end.

    Examples:
        obra userplan step add UP-20260115-auth -t "Add validation" -d "Implement input validation"
        obra userplan step add UP-20260115-auth -t "Setup DB" -d "Configure database" --index 1
        obra userplan step add UP-20260115-auth -t "Add tests" -d "Write unit tests" --tech-stack "pytest,coverage"
        obra userplan step add UP-20260115-auth -t "Add tests" -d "Write unit tests" --format json
    """
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_error(error="Not logged in", code="AUTH_REQUIRED")
                raise typer.Exit(1)
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        # Validate inputs
        if not title.strip():
            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_error(error="Title cannot be empty", code="VALIDATION_ERROR")
                raise typer.Exit(1)
            print_error("Title cannot be empty")
            raise typer.Exit(1)

        if not description.strip():
            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_error(error="Description cannot be empty", code="VALIDATION_ERROR")
                raise typer.Exit(1)
            print_error("Description cannot be empty")
            raise typer.Exit(1)

        if index is not None and index < 1:
            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_error(
                    error="Index must be >= 1 (1-based indexing)",
                    code="VALIDATION_ERROR",
                )
                raise typer.Exit(1)
            print_error("Index must be >= 1 (1-based indexing)")
            raise typer.Exit(1)

        # Build context if any context options provided
        context: dict[str, Any] | None = None
        if deliverables or requirements or tech_stack:
            context = {}
            if deliverables:
                context["deliverables"] = [d.strip() for d in deliverables.split(",") if d.strip()]
            if requirements:
                context["requirements"] = [r.strip() for r in requirements.split(",") if r.strip()]
            if tech_stack:
                context["tech_stack"] = [t.strip() for t in tech_stack.split(",") if t.strip()]

        # Add step via API
        client = APIClient.from_config()

        if format_output != "json":
            console.print()
            print_info(f"Adding step to UserPlan: {userplan_id}")

        result = client.add_userplan_step(
            userplan_id=userplan_id,
            title=title.strip(),
            description=description.strip(),
            index=index,
            context=context,
        )

        added_step = result.get("added_step", result.get("step", {}))
        step_index = added_step.get("index", index or "?")
        step_id = added_step.get("id", "N/A")

        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_success(
                data={
                    "step": {
                        "id": step_id,
                        "index": step_index,
                        "title": title.strip(),
                        "description": description.strip(),
                        "context": context,
                    },
                },
                ids={
                    "step_id": str(step_id),
                    "userplan_id": userplan_id,
                },
            )
            return

        console.print()
        print_success(f"Added step {step_index}: {title}")
        console.print()
        console.print(f"  [cyan]Step ID:[/cyan] {step_id}")
        console.print(f"  [cyan]Index:[/cyan] {step_index}")
        console.print(f"  [cyan]Title:[/cyan] {title}")
        if context:
            console.print(f"  [cyan]Context:[/cyan] {len(context)} fields set")
        console.print()

        # Machine-parseable output
        console.print("[dim]-- LLM-parseable output --[/dim]")
        console.print(f"STEP_ID={step_id}")
        console.print(f"STEP_INDEX={step_index}")
        console.print(f"USERPLAN_ID={userplan_id}")
        console.print()

    except typer.Exit:
        raise
    except APIError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="API_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"API error in userplan step add command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="CONFIG_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"Configuration error in userplan step add command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="OBRA_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"Obra error in userplan step add command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="UNKNOWN_ERROR")
            raise typer.Exit(1) from e
        display_error(e, console)
        logger.exception(f"Unexpected error in userplan step add command: {e}")
        raise typer.Exit(1) from e


@step_app.command("remove")
@handle_encoding_errors
def userplan_step_remove(
    userplan_id: str = typer.Argument(..., help="UserPlan ID containing the step"),
    step_id: str = typer.Argument(
        ...,
        help="Step index (number) or full step ID to remove",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Skip confirmation prompt",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
) -> None:
    """Remove a step from a UserPlan.

    Removes the specified step and re-indexes remaining steps.
    This operation cannot be undone.

    The step can be specified by:
    - Index number (e.g., "2" for the second step)
    - Full step ID (e.g., "UP-20260115-auth:S2")

    Examples:
        obra userplan step remove UP-20260115-auth 2
        obra userplan step remove UP-20260115-auth UP-20260115-auth:S2
        obra userplan step remove UP-20260115-auth 3 --force
        obra userplan step remove UP-20260115-auth 2 --format json
    """
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        # Parse step_id - could be index or full ID
        step_index: int
        if step_id.isdigit():
            step_index = int(step_id)
        elif ":S" in step_id:
            # Extract index from full step ID (e.g., "UP-xxx:S2" -> 2)
            try:
                step_index = int(step_id.split(":S")[-1])
            except ValueError:
                print_error(f"Invalid step ID format: {step_id}")
                raise typer.Exit(1) from None
        else:
            print_error(f"Invalid step identifier: {step_id}")
            console.print(
                "Provide either a step index (e.g., '2') or full step ID (e.g., 'UP-xxx:S2')"
            )
            raise typer.Exit(1)

        if step_index < 1:
            print_error("Step index must be >= 1")
            raise typer.Exit(1)

        client = APIClient.from_config()

        # Get the step first to show what will be removed
        userplan = client.get_userplan(userplan_id)
        if not userplan:
            print_error(f"UserPlan not found: {userplan_id}")
            raise typer.Exit(1)

        steps = userplan.get("steps", [])
        if step_index > len(steps):
            print_error(f"Step index {step_index} out of range (UserPlan has {len(steps)} steps)")
            raise typer.Exit(1)

        target_step = steps[step_index - 1]  # Convert to 0-based
        step_title = target_step.get("title", "Untitled")

        console.print()
        console.print("[bold]Step to remove:[/bold]")
        console.print(f"  Index: {step_index}")
        console.print(f"  Title: {step_title}")
        console.print()

        # Confirm unless --force
        if not force:
            console.print("[yellow]Warning:[/yellow] This operation cannot be undone.")
            console.print()
            confirm = typer.confirm(get_message("prompt.confirm.remove_step"))
            if not confirm:
                print_info("Operation cancelled")
                raise typer.Exit(0)

        # Remove step via API
        if format_output != "json":
            print_info(f"Removing step {step_index} from UserPlan: {userplan_id}")

        result = client.remove_userplan_step(
            userplan_id=userplan_id,
            step_index=step_index,
        )

        result.get("removed_step", {})
        remaining_steps = len(result.get("steps", []))

        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_success(
                data={
                    "removed_step": {
                        "index": step_index,
                        "title": step_title,
                    },
                    "remaining_steps": remaining_steps,
                },
                ids={
                    "userplan_id": userplan_id,
                },
            )
            return

        console.print()
        print_success(f"Removed step {step_index}: {step_title}")
        console.print(f"  [dim]Remaining steps: {remaining_steps}[/dim]")
        console.print()

        # Machine-parseable output
        console.print("[dim]-- LLM-parseable output --[/dim]")
        console.print(f"REMOVED_STEP_INDEX={step_index}")
        console.print(f"REMOVED_STEP_TITLE={step_title}")
        console.print(f"REMAINING_STEPS={remaining_steps}")
        console.print(f"USERPLAN_ID={userplan_id}")
        console.print()

    except typer.Exit:
        raise
    except APIError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="API_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"API error in userplan step remove command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="CONFIG_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"Configuration error in userplan step remove command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="OBRA_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"Obra error in userplan step remove command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="UNKNOWN_ERROR")
            raise typer.Exit(1) from e
        display_error(e, console)
        logger.exception(f"Unexpected error in userplan step remove command: {e}")
        raise typer.Exit(1) from e


@step_app.command("update")
@handle_encoding_errors
def userplan_step_update(
    userplan_id: str = typer.Argument(..., help="UserPlan ID containing the step"),
    step_id: str = typer.Argument(
        ...,
        help="Step index (number) or full step ID to update",
    ),
    title: str | None = typer.Option(
        None,
        "--title",
        "-t",
        help="New step title",
    ),
    description: str | None = typer.Option(
        None,
        "--description",
        "-d",
        help="New step description",
    ),
    cascade: bool = typer.Option(
        False,
        "--cascade",
        "-c",
        help="Mark subsequent steps as stale (for re-derivation)",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
) -> None:
    """Update a step's title or description.

    Modifies the specified step's content. When content is changed,
    the step's derivation_status is automatically set to STALE.

    Use --cascade to also mark all subsequent steps as stale,
    which is useful when the change affects dependent steps.

    Examples:
        obra userplan step update UP-20260115-auth 1 -t "New title"
        obra userplan step update UP-20260115-auth 2 -d "Updated description"
        obra userplan step update UP-20260115-auth 1 -t "New title" -d "New desc" --cascade
        obra userplan step update UP-20260115-auth 1 -t "New title" --format json
    """
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        # Validate at least one field is being updated
        if title is None and description is None:
            print_error("At least one of --title or --description must be provided")
            raise typer.Exit(1)

        # Parse step_id - could be index or full ID
        step_index: int
        if step_id.isdigit():
            step_index = int(step_id)
        elif ":S" in step_id:
            try:
                step_index = int(step_id.split(":S")[-1])
            except ValueError:
                print_error(f"Invalid step ID format: {step_id}")
                raise typer.Exit(1) from None
        else:
            print_error(f"Invalid step identifier: {step_id}")
            console.print(
                "Provide either a step index (e.g., '2') or full step ID (e.g., 'UP-xxx:S2')"
            )
            raise typer.Exit(1)

        if step_index < 1:
            print_error("Step index must be >= 1")
            raise typer.Exit(1)

        client = APIClient.from_config()

        console.print()
        if format_output != "json":
            print_info(f"Updating step {step_index} in UserPlan: {userplan_id}")

        result = client.update_userplan_step(
            userplan_id=userplan_id,
            step_index=step_index,
            title=title.strip() if title else None,
            description=description.strip() if description else None,
            cascade=cascade,
        )

        updated_step = result.get("updated_step", result.get("step", {}))
        cascaded_steps = result.get("cascaded_steps", [])

        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_success(
                data={
                    "step": {
                        "index": step_index,
                        "title": title.strip() if title else updated_step.get("title"),
                        "description": (
                            description.strip() if description else updated_step.get("description")
                        ),
                        "derivation_status": "stale",
                    },
                    "cascaded_steps": cascaded_steps,
                },
                ids={
                    "userplan_id": userplan_id,
                    "step_index": str(step_index),
                },
            )
            return

        console.print()
        print_success(f"Updated step {step_index}")
        console.print()

        if title:
            console.print(f"  [cyan]Title:[/cyan] {title}")
        if description:
            desc_preview = description[:50] + "..." if len(description) > 50 else description
            console.print(f"  [cyan]Description:[/cyan] {desc_preview}")

        console.print("  [cyan]Derivation status:[/cyan] stale")

        if cascade and cascaded_steps:
            console.print(f"  [cyan]Cascaded steps:[/cyan] {cascaded_steps}")

        console.print()

        # Machine-parseable output
        console.print("[dim]-- LLM-parseable output --[/dim]")
        console.print(f"STEP_INDEX={step_index}")
        console.print(f"USERPLAN_ID={userplan_id}")
        console.print("DERIVATION_STATUS=stale")
        if cascaded_steps:
            console.print(f"CASCADED_STEPS={','.join(map(str, cascaded_steps))}")
        console.print()

    except typer.Exit:
        raise
    except APIError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="API_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"API error in userplan step update command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="CONFIG_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"Configuration error in userplan step update command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="OBRA_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"Obra error in userplan step update command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="UNKNOWN_ERROR")
            raise typer.Exit(1) from e
        display_error(e, console)
        logger.exception(f"Unexpected error in userplan step update command: {e}")
        raise typer.Exit(1) from e


@step_app.command("context")
@handle_encoding_errors
def userplan_step_context(
    userplan_id: str = typer.Argument(..., help="UserPlan ID containing the step"),
    step_id: str = typer.Argument(
        ...,
        help="Step index (number) or full step ID",
    ),
    deliverables: str | None = typer.Option(
        None,
        "--deliverables",
        help="Set deliverables (comma-separated list, use '' to clear)",
    ),
    success_criteria: str | None = typer.Option(
        None,
        "--success-criteria",
        help="Set success criteria",
    ),
    requirements: str | None = typer.Option(
        None,
        "--requirements",
        help="Set requirements (comma-separated list, use '' to clear)",
    ),
    tech_stack: str | None = typer.Option(
        None,
        "--tech-stack",
        help="Set tech stack (comma-separated list, use '' to clear)",
    ),
    constraints: str | None = typer.Option(
        None,
        "--constraints",
        help="Set constraints (comma-separated list, use '' to clear)",
    ),
    assumptions: str | None = typer.Option(
        None,
        "--assumptions",
        help="Set assumptions (comma-separated list, use '' to clear)",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
) -> None:
    """View or update a step's context.

    Without any update options, displays the current context.
    With update options, modifies the specified context fields.

    Context fields provide structured information for quality assessment
    and derivation (deliverables, success_criteria, requirements, etc.).

    Examples:
        obra userplan step context UP-20260115-auth 1
        obra userplan step context UP-20260115-auth 1 --deliverables "JWT tokens,Refresh endpoint"
        obra userplan step context UP-20260115-auth 2 --tech-stack "Python,FastAPI" --requirements "Auth required"
        obra userplan step context UP-20260115-auth 1 --deliverables ''  # Clear deliverables
        obra userplan step context UP-20260115-auth 1 --format json
    """
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token, get_current_auth

        # Ensure authenticated
        auth = get_current_auth()
        if not auth:
            print_error("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            raise typer.Exit(1)

        ensure_valid_token()

        # Parse step_id - could be index or full ID
        step_index: int
        if step_id.isdigit():
            step_index = int(step_id)
        elif ":S" in step_id:
            try:
                step_index = int(step_id.split(":S")[-1])
            except ValueError:
                print_error(f"Invalid step ID format: {step_id}")
                raise typer.Exit(1) from None
        else:
            print_error(f"Invalid step identifier: {step_id}")
            console.print(
                "Provide either a step index (e.g., '2') or full step ID (e.g., 'UP-xxx:S2')"
            )
            raise typer.Exit(1)

        if step_index < 1:
            print_error("Step index must be >= 1")
            raise typer.Exit(1)

        client = APIClient.from_config()

        # Check if any update options provided
        is_update = any(
            [
                deliverables is not None,
                success_criteria is not None,
                requirements is not None,
                tech_stack is not None,
                constraints is not None,
                assumptions is not None,
            ]
        )

        if is_update:
            # Update mode: build context and update
            context: dict[str, Any] = {}

            if deliverables is not None:
                context["deliverables"] = (
                    [d.strip() for d in deliverables.split(",") if d.strip()]
                    if deliverables
                    else []
                )
            if success_criteria is not None:
                context["success_criteria"] = success_criteria if success_criteria else None
            if requirements is not None:
                context["requirements"] = (
                    [r.strip() for r in requirements.split(",") if r.strip()]
                    if requirements
                    else []
                )
            if tech_stack is not None:
                context["tech_stack"] = (
                    [t.strip() for t in tech_stack.split(",") if t.strip()] if tech_stack else []
                )
            if constraints is not None:
                context["constraints"] = (
                    [c.strip() for c in constraints.split(",") if c.strip()] if constraints else []
                )
            if assumptions is not None:
                context["assumptions"] = (
                    [a.strip() for a in assumptions.split(",") if a.strip()] if assumptions else []
                )

            if format_output != "json":
                console.print()
                print_info(f"Updating context for step {step_index} in UserPlan: {userplan_id}")

            client.update_userplan_step_context(
                userplan_id=userplan_id,
                step_index=step_index,
                context=context,
            )

            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_success(
                    data={
                        "context": context,
                        "fields_updated": list(context.keys()),
                    },
                    ids={
                        "step_index": str(step_index),
                        "userplan_id": userplan_id,
                    },
                )
                return

            console.print()
            print_success(f"Updated context for step {step_index}")
            console.print()

            # Show updated context
            _display_step_context(context, "Updated context")

            # Machine-parseable output
            console.print()
            console.print("[dim]-- LLM-parseable output --[/dim]")
            console.print(f"STEP_INDEX={step_index}")
            console.print(f"USERPLAN_ID={userplan_id}")
            console.print("CONTEXT_UPDATED=true")
            console.print(f"FIELDS_UPDATED={','.join(context.keys())}")
            console.print()

        else:
            # View mode: get step and display context
            userplan = client.get_userplan(userplan_id)
            if not userplan:
                if format_output == "json":
                    from obra.utils.json_output import JsonOutputFormatter

                    formatter = JsonOutputFormatter()
                    formatter.output_error(
                        error=f"UserPlan not found: {userplan_id}", code="NOT_FOUND"
                    )
                    raise typer.Exit(1)
                print_error(f"UserPlan not found: {userplan_id}")
                raise typer.Exit(1)

            steps = userplan.get("steps", [])
            if step_index > len(steps):
                if format_output == "json":
                    from obra.utils.json_output import JsonOutputFormatter

                    formatter = JsonOutputFormatter()
                    formatter.output_error(
                        error=f"Step index {step_index} out of range (UserPlan has {len(steps)} steps)",
                        code="OUT_OF_RANGE",
                    )
                    raise typer.Exit(1)
                print_error(
                    f"Step index {step_index} out of range (UserPlan has {len(steps)} steps)"
                )
                raise typer.Exit(1)

            step = steps[step_index - 1]  # Convert to 0-based
            step_title = step.get("title", "Untitled")
            step_context = step.get("context") or {}

            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_success(
                    data={
                        "step_index": step_index,
                        "step_title": step_title,
                        "context": step_context,
                        "has_context": bool(step_context),
                    },
                    ids={
                        "step_index": str(step_index),
                        "userplan_id": userplan_id,
                    },
                )
                return

            console.print()
            console.print(f"[bold cyan]Context for Step {step_index}: {step_title}[/bold cyan]")
            console.print("=" * 60)
            console.print()

            if not step_context:
                console.print("[dim]No context set for this step.[/dim]")
                console.print()
                console.print("Set context with options like:")
                console.print(
                    f'  [cyan]obra userplan step context {userplan_id} {step_index} --deliverables "item1,item2"[/cyan]'
                )
            else:
                _display_step_context(step_context, "Current context")

            # Machine-parseable output
            console.print()
            console.print("[dim]-- LLM-parseable output --[/dim]")
            console.print(f"STEP_INDEX={step_index}")
            console.print(f"STEP_TITLE={step_title}")
            console.print(f"USERPLAN_ID={userplan_id}")
            console.print(f"HAS_CONTEXT={'true' if step_context else 'false'}")
            console.print()

    except typer.Exit:
        raise
    except APIError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="API_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"API error in userplan step context command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="CONFIG_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"Configuration error in userplan step context command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="OBRA_ERROR")
            raise typer.Exit(1) from e
        display_obra_error(e, console)
        logger.error(f"Obra error in userplan step context command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="UNKNOWN_ERROR")
            raise typer.Exit(1) from e
        display_error(e, console)
        logger.exception(f"Unexpected error in userplan step context command: {e}")
        raise typer.Exit(1) from e


@userplan_app.command("rederive")
@handle_encoding_errors
def userplan_rederive(
    ctx: typer.Context,
    userplan_id: str = typer.Argument(
        ...,
        help="UserPlan ID to re-derive",
    ),
    from_step: int | None = typer.Option(
        None,
        "--from-step",
        min=1,
        help="Re-derive from step N onwards (1-indexed). Steps 1 to N-1 retain existing derivation.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Force re-derivation even if quality gate fails",
    ),
    cascade: bool = typer.Option(
        False,
        "--cascade",
        help="Mark sibling steps after the re-derived step as STALE for staleness propagation",
    ),
    verbose: int = typer.Option(
        0,
        "--verbose",
        "-v",
        count=True,
        max=3,
        help="Verbosity level (0-3, use -v/-vv/-vvv)",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
) -> None:
    """Re-derive execution plan for a UserPlan.

    Triggers re-derivation of the execution plan for an existing UserPlan.
    By default, re-derives all steps. Use --from-step to re-derive only
    from a specific step onwards (partial re-derivation).

    When using --from-step N:
    - Steps 1 to N-1 retain their existing derivation (not re-derived)
    - Steps N onwards are marked as DERIVING and then re-derived
    - Use --cascade to also mark sibling steps after N as STALE

    Examples:
        obra userplan rederive UP-20260117-add-auth
        obra userplan rederive UP-20260117-add-auth --from-step 3
        obra userplan rederive UP-20260117-add-auth --from-step 2 --cascade
        obra userplan rederive UP-20260117-add-auth --force
        obra userplan rederive UP-20260117-add-auth --format json
    """
    from obra.api import APIClient
    from obra.schemas.userplan_schema import DerivationStatus

    verbose = _resolve_command_verbosity(ctx, verbose)
    setup_logging(verbose)

    try:
        # Get API client
        client = APIClient.from_config()

        # Fetch the UserPlan
        if format_output != "json":
            console.print()
            print_info(f"Fetching UserPlan: {userplan_id}")

        userplan = client.get_userplan(userplan_id)

        if not userplan:
            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_error(error=f"UserPlan not found: {userplan_id}", code="NOT_FOUND")
                raise typer.Exit(1)
            console.print()
            print_error(f"UserPlan not found: {userplan_id}")
            console.print()
            raise typer.Exit(1)

        steps = userplan.get("steps", [])
        total_steps = len(steps)

        if total_steps == 0:
            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_error(
                    error=f"UserPlan {userplan_id} has no steps to re-derive",
                    code="NO_STEPS",
                )
                raise typer.Exit(1)
            console.print()
            print_error(f"UserPlan {userplan_id} has no steps to re-derive")
            console.print()
            raise typer.Exit(1)

        # Validate from_step if provided
        if from_step is not None and from_step > total_steps:
            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_error(
                    error=f"--from-step {from_step} exceeds total steps ({total_steps})",
                    code="OUT_OF_RANGE",
                )
                raise typer.Exit(1)
            console.print()
            print_error(f"--from-step {from_step} exceeds total steps ({total_steps})")
            console.print()
            raise typer.Exit(1)

        # Determine which steps to re-derive
        start_step = from_step if from_step is not None else 1
        steps_to_rederive = list(range(start_step, total_steps + 1))

        console.print()
        if from_step is not None:
            print_info(
                f"Re-deriving steps {start_step} to {total_steps} ({len(steps_to_rederive)} steps)"
            )
            if start_step > 1:
                console.print(
                    f"  [dim]Steps 1 to {start_step - 1} will retain existing derivation[/dim]"
                )
        else:
            print_info(f"Re-deriving all {total_steps} steps")

        # Mark steps as DERIVING
        console.print()
        print_info("Marking steps as DERIVING...")

        try:
            client.update_userplan_steps_status_batch(
                userplan_id=userplan_id,
                step_indices=steps_to_rederive,
                derivation_status=DerivationStatus.DERIVING.value,
            )
            if verbose >= 1:
                console.print(f"  [dim]Marked steps {steps_to_rederive} as DERIVING[/dim]")
        except APIError as e:
            console.print()
            print_error(f"Failed to mark steps as DERIVING: {e}")
            console.print()
            raise typer.Exit(1) from e

        # If cascade is enabled, mark sibling steps after the last re-derived step as STALE
        cascaded_steps: list[int] = []
        if cascade and from_step is not None and from_step > 1:
            # Mark steps before from_step that might depend on re-derived steps
            # In practice, cascade marks steps AFTER the re-derived range as STALE
            # But for a full re-derive, there's nothing after
            pass

        # JSON output
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_success(
                data={
                    "rederive_status": "queued",
                    "total_steps": total_steps,
                    "steps_to_rederive": len(steps_to_rederive),
                    "step_indices": steps_to_rederive,
                    "from_step": start_step,
                    "preserved_steps": (list(range(1, start_step)) if start_step > 1 else []),
                    "cascaded_steps": cascaded_steps,
                },
                ids={
                    "userplan_id": userplan_id,
                },
            )
            return

        # Show progress summary
        console.print()
        print_success("Re-derivation queued successfully")
        console.print()

        # Display summary
        console.print("[bold]Re-derivation Summary:[/bold]")
        console.print(f"  [cyan]UserPlan:[/cyan] {userplan_id}")
        console.print(f"  [cyan]Total Steps:[/cyan] {total_steps}")
        console.print(f"  [cyan]Steps to Re-derive:[/cyan] {len(steps_to_rederive)}")
        if from_step is not None and from_step > 1:
            console.print(f"  [cyan]Preserved Steps:[/cyan] 1 to {from_step - 1}")
        console.print(f"  [cyan]Re-derive Range:[/cyan] {start_step} to {total_steps}")

        if cascaded_steps:
            console.print(f"  [cyan]Cascaded (STALE):[/cyan] {cascaded_steps}")

        console.print()

        # Show steps being re-derived
        console.print("[bold]Steps queued for re-derivation:[/bold]")
        for step in steps:
            step_index = step.get("index", 0)
            step_title = step.get("title", "Untitled")
            if step_index in steps_to_rederive:
                console.print(f"  [yellow]>[/yellow] {step_index}. {step_title}")
            elif verbose >= 1:
                console.print(f"  [dim]-[/dim] {step_index}. {step_title} [dim](preserved)[/dim]")

        console.print()

        # Machine-parseable output for LLM agents
        console.print("[dim]-- LLM-parseable output --[/dim]")
        console.print(f"USERPLAN_ID={userplan_id}")
        console.print(f"REDERIVE_FROM_STEP={start_step}")
        console.print(f"REDERIVE_STEPS_COUNT={len(steps_to_rederive)}")
        console.print(f"REDERIVE_STEP_INDICES={','.join(map(str, steps_to_rederive))}")
        console.print(f"TOTAL_STEPS={total_steps}")
        console.print("REDERIVE_STATUS=queued")
        console.print()

        # Next steps
        console.print("Next steps:")
        console.print(
            f"  [cyan]obra derive --userplan {userplan_id}[/cyan] - "
            "Run derivation to generate execution plan"
        )
        if from_step is not None:
            console.print(
                f"  [cyan]obra derive --userplan {userplan_id} --from-step {from_step}[/cyan] - "
                "Derive from specified step"
            )
        console.print()

    except typer.Exit:
        raise
    except APIError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="API_ERROR")
            raise typer.Exit(1) from e
        console.print()
        display_error(e, console)
        logger.error(f"API error in userplan rederive command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="CONFIG_ERROR")
            raise typer.Exit(1) from e
        console.print()
        display_error(e, console)
        logger.error(f"Configuration error in userplan rederive command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="OBRA_ERROR")
            raise typer.Exit(1) from e
        console.print()
        display_obra_error(e, console)
        logger.error(f"Obra error in userplan rederive command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="UNKNOWN_ERROR")
            raise typer.Exit(1) from e
        console.print()
        display_error(e, console)
        logger.exception(f"Unexpected error in userplan rederive command: {e}")
        raise typer.Exit(1) from e


@userplan_app.command("clarify")
@handle_encoding_errors
def userplan_clarify(
    ctx: typer.Context,
    userplan_id: str = typer.Argument(..., help="UserPlan ID to clarify"),
    max_iterations: int | None = typer.Option(
        None,
        "--max-iterations",
        "-n",
        help="Maximum clarification iterations (default: from config, usually 3)",
    ),
    target_quality: float | None = typer.Option(
        None,
        "--target",
        "-t",
        help="Target quality score (0.0-1.0, default: 0.8)",
    ),
    verbose: int = typer.Option(
        0,
        "--verbose",
        "-v",
        count=True,
        max=3,
        help="Verbosity level (0-3, use -v/-vv/-vvv)",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
) -> None:
    """Run clarification loop to refine UserPlan quality.

    The clarification loop iteratively improves UserPlan quality by
    analyzing field deficiencies and generating structured feedback.

    Termination conditions:
    - Quality reaches target (--target or config default 0.8)
    - Maximum iterations reached (--max-iterations or config default 3)
    - Quality improvement below threshold (diminishing returns)
    - No improvements identified

    Examples:
        obra userplan clarify UP-20260117-add-auth
        obra userplan clarify UP-20260117-add-auth --max-iterations 5
        obra userplan clarify UP-20260117-add-auth --target 0.9
        obra userplan clarify UP-20260117-add-auth --format json -v
    """
    from obra.api import APIClient
    from obra.hybrid.quality.clarification import ClarificationLoop
    from obra.schemas.userplan_schema import UserPlan

    verbose = _resolve_command_verbosity(ctx, verbose)
    setup_logging(verbose)

    try:
        # Get API client
        client = APIClient.from_config()

        # Fetch the UserPlan
        if format_output != "json":
            console.print()
            print_info(f"Fetching UserPlan: {userplan_id}")

        userplan_data = client.get_userplan(userplan_id)

        if not userplan_data:
            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_error(error=f"UserPlan not found: {userplan_id}", code="NOT_FOUND")
                raise typer.Exit(1)
            console.print()
            print_error(f"UserPlan not found: {userplan_id}")
            raise typer.Exit(1)

        # Parse UserPlan
        try:
            userplan = UserPlan(**userplan_data)
        except typer.Exit:
            raise
        except Exception as e:
            if format_output == "json":
                from obra.utils.json_output import JsonOutputFormatter

                formatter = JsonOutputFormatter()
                formatter.output_error(error=f"Invalid UserPlan data: {e}", code="PARSE_ERROR")
                raise typer.Exit(1) from e
            console.print()
            print_error(f"Failed to parse UserPlan: {e}")
            raise typer.Exit(1) from e

        # Initialize clarification loop with options
        if max_iterations is not None and target_quality is not None:
            clarification_loop = ClarificationLoop(
                max_iterations=max_iterations, target_quality=target_quality
            )
        elif max_iterations is not None:
            clarification_loop = ClarificationLoop(max_iterations=max_iterations)
        elif target_quality is not None:
            clarification_loop = ClarificationLoop(target_quality=target_quality)
        else:
            clarification_loop = ClarificationLoop()

        if format_output != "json":
            console.print()
            print_info("Running clarification loop...")
            console.print()
            console.print(
                f"[dim]Config: max_iterations={clarification_loop.max_iterations}, "
                f"target_quality={clarification_loop.target_quality:.2f}, "
                f"delta_threshold={clarification_loop.quality_delta_threshold}[/dim]"
            )
            console.print()

        # Run the clarification loop
        result = clarification_loop.run(userplan)

        # Output results
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_success(
                data={
                    "clarification_result": {
                        "userplan_id": result.userplan_id,
                        "initial_quality": result.initial_quality,
                        "final_quality": result.final_quality,
                        "total_improvement": result.total_improvement,
                        "iterations_run": result.iterations_run,
                        "terminal_reason": result.final_terminal_reason.value,
                        "fields_improved_count": result.fields_improved_count,
                        "fields_auto_filled": result.fields_auto_filled,
                        "iterations": [
                            {
                                "iteration": fb.iteration,
                                "quality_before": fb.quality_before,
                                "quality_after": fb.quality_after,
                                "quality_delta": fb.quality_delta,
                                "terminal": fb.terminal,
                                "terminal_reason": (
                                    fb.terminal_reason.value if fb.terminal_reason else None
                                ),
                                "fields_improved": [
                                    {
                                        "field": f.field,
                                        "issue": f.issue.value,
                                        "description": f.description,
                                        "suggestion": f.suggestion,
                                        "resolved": f.resolved,
                                        "step_id": f.step_id,
                                    }
                                    for f in fb.fields_improved
                                ],
                            }
                            for fb in result.iterations
                        ],
                    }
                },
                ids={"userplan_id": result.userplan_id},
            )
            return

        # Text output
        console.print("[bold cyan]Clarification Results[/bold cyan]")
        console.print("=" * 60)
        console.print()

        console.print(f"[bold]UserPlan:[/bold]       {result.userplan_id}")
        console.print(f"[bold]Initial Quality:[/bold] {result.initial_quality:.2%}")
        console.print(f"[bold]Final Quality:[/bold]   {result.final_quality:.2%}")
        console.print(f"[bold]Improvement:[/bold]     {result.total_improvement:+.2%}")
        console.print(f"[bold]Iterations:[/bold]      {result.iterations_run}")
        console.print(f"[bold]Termination:[/bold]     {result.final_terminal_reason.value}")
        console.print()

        # Show iteration details if verbose
        if verbose >= 1 and result.iterations:
            console.print("[bold]Iteration Details:[/bold]")
            console.print("-" * 40)

            for iteration in result.iterations:
                console.print(
                    f"  Iteration {iteration.iteration}: "
                    f"{iteration.quality_before:.2%} -> {iteration.quality_after:.2%} "
                    f"(delta: {iteration.quality_delta:+.3f})"
                )

                if verbose >= 2 and iteration.fields_improved:
                    for fb in iteration.fields_improved[:5]:  # Show first 5
                        console.print(f"    [yellow]{fb.field}[/yellow]: {fb.issue.value}")
                        if verbose >= 3:
                            console.print(f"      {fb.description}")
                            console.print(f"      [dim]Suggestion: {fb.suggestion}[/dim]")

                if iteration.terminal:
                    reason = (
                        iteration.terminal_reason.value if iteration.terminal_reason else "unknown"
                    )
                    console.print(f"    [dim]Terminal: {reason}[/dim]")

            console.print()

        # Summary
        if result.total_improvement > 0.01:
            print_success(
                f"Quality improved by {result.total_improvement:.1%} "
                f"in {result.iterations_run} iteration(s)"
            )
        elif result.iterations_run == 0:
            print_info("No clarification needed - quality already at target")
        else:
            print_info(f"Clarification complete ({result.final_terminal_reason.value})")

        console.print()

        # Machine-parseable output
        console.print("[dim]-- LLM-parseable output --[/dim]")
        console.print(f"USERPLAN_ID={result.userplan_id}")
        console.print(f"INITIAL_QUALITY={result.initial_quality:.4f}")
        console.print(f"FINAL_QUALITY={result.final_quality:.4f}")
        console.print(f"IMPROVEMENT={result.total_improvement:.4f}")
        console.print(f"ITERATIONS={result.iterations_run}")
        console.print(f"TERMINAL_REASON={result.final_terminal_reason.value}")
        console.print(f"FIELDS_IMPROVED={result.fields_improved_count}")
        console.print()

    except typer.Exit:
        raise
    except APIError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="API_ERROR")
            raise typer.Exit(1) from e
        console.print()
        display_error(e, console)
        logger.error(f"API error in userplan clarify command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="CONFIG_ERROR")
            raise typer.Exit(1) from e
        console.print()
        display_error(e, console)
        logger.error(f"Configuration error in userplan clarify command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="OBRA_ERROR")
            raise typer.Exit(1) from e
        console.print()
        display_obra_error(e, console)
        logger.error(f"Obra error in userplan clarify command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        if format_output == "json":
            from obra.utils.json_output import JsonOutputFormatter

            formatter = JsonOutputFormatter()
            formatter.output_error(error=str(e), code="UNKNOWN_ERROR")
            raise typer.Exit(1) from e
        console.print()
        display_error(e, console)
        logger.exception(f"Unexpected error in userplan clarify command: {e}")
        raise typer.Exit(1) from e


def _display_step_context(context: dict[str, Any], header: str) -> None:
    """Helper to display step context in a formatted way."""
    console.print(f"[bold]{header}:[/bold]")

    # Deliverables
    deliverables = context.get("deliverables", [])
    if deliverables:
        console.print("  [cyan]Deliverables:[/cyan]")
        for item in deliverables:
            console.print(f"    - {item}")

    # Success criteria
    success_criteria = context.get("success_criteria")
    if success_criteria:
        console.print(f"  [cyan]Success Criteria:[/cyan] {success_criteria}")

    # Requirements
    requirements = context.get("requirements", [])
    if requirements:
        console.print("  [cyan]Requirements:[/cyan]")
        for item in requirements:
            console.print(f"    - {item}")

    # Tech stack
    tech_stack = context.get("tech_stack", [])
    if tech_stack:
        console.print(f"  [cyan]Tech Stack:[/cyan] {', '.join(tech_stack)}")

    # Constraints
    constraints = context.get("constraints", [])
    if constraints:
        console.print("  [cyan]Constraints:[/cyan]")
        for item in constraints:
            console.print(f"    - {item}")

    # Assumptions
    assumptions = context.get("assumptions", [])
    if assumptions:
        console.print("  [cyan]Assumptions:[/cyan]")
        for item in assumptions:
            console.print(f"    - {item}")


# =============================================================================
# Verify Command
# =============================================================================


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
def verify(
    auto: bool = typer.Option(
        False,
        "--auto",
        help="Attempt automatic verification (best-effort file checks)",
    ),
    intent_id: str | None = typer.Option(
        None,
        "--intent",
        help="Verify specific intent ID (default: active intent)",
    ),
) -> None:
    """Verify completion against active intent acceptance criteria.

    Checks the current project state against the acceptance criteria
    defined in the active intent. Generates a verification report
    and optionally archives the intent if all criteria pass.

    Examples:
        obra verify              # Verify active intent (manual review)
        obra verify --auto       # Attempt automatic verification
        obra verify --intent add-auth  # Verify specific intent
    """
    from pathlib import Path

    from obra.intent.storage import IntentStorage
    from obra.intent.verification import (
        archive_intent,
        save_verification_report,
        verify_completion,
    )

    try:
        storage = IntentStorage()
        working_dir = Path.cwd()
        project = storage.get_project_id(working_dir)

        # Load intent to verify
        if intent_id:
            # Resolve partial ID
            resolved_id = storage.resolve_id(intent_id, project)
            if not resolved_id:
                console.print()
                print_error(f"Intent not found: {intent_id}")
                console.print()
                console.print("  [dim]Use 'obra intent list' to see available intents[/dim]")
                console.print()
                raise typer.Exit(1)
            intent = storage.load(resolved_id, project)
            if not intent:
                console.print()
                print_error(f"Failed to load intent: {resolved_id}")
                console.print()
                raise typer.Exit(1)
        else:
            # Use active intent
            intent = storage.load_active(project)
            if not intent:
                console.print()
                print_error("No active intent to verify")
                console.print()
                console.print("  [dim]Use 'obra intent list' to see available intents[/dim]")
                console.print()
                console.print('  [dim]Or create one with: obra derive "objective"[/dim]')
                console.print()
                raise typer.Exit(1)

        console.print()
        console.print(f"[bold]Verifying Intent:[/bold] {intent.id}")
        console.print(f"[dim]Problem: {intent.problem_statement}[/dim]")
        console.print()

        # Run verification
        report = verify_completion(
            intent,
            project_dir=working_dir if auto else None,
            auto_verify=auto,
        )

        # Save verification report
        report_path = save_verification_report(report)

        # Display results
        status_emoji = {
            "passed": glyphs.success,
            "failed": glyphs.failure,
            "partial": glyphs.warning,
            "skipped": "o",
        }
        emoji = status_emoji.get(report.status.value, "?")

        console.print(f"[bold]Verification Status:[/bold] {emoji} {report.status.value.upper()}")
        console.print()
        console.print(f"  {report.summary}")
        console.print()

        if report.results:
            console.print("[bold]Acceptance Criteria:[/bold]")
            console.print()
            for result in report.results:
                check = (
                    f"[green]{glyphs.success}[/green]"
                    if result.passed
                    else f"[red]{glyphs.failure}[/red]"
                )
                console.print(f"  {check} {result.criterion}")
                if result.notes:
                    console.print(f"    [dim]{result.notes}[/dim]")
            console.print()

        console.print("[bold]Statistics:[/bold]")
        console.print(f"  Total: {report.total_criteria}")
        console.print(f"  Passed: {report.passed_criteria}")
        console.print(f"  Failed: {report.failed_criteria}")
        console.print()

        console.print(f"[dim]Report saved: {report_path}[/dim]")
        console.print()

        # If all criteria passed, offer to archive
        if report.passed:
            console.print("[bold green]All acceptance criteria met![/bold green]")
            console.print()

            # Auto-archive the intent
            if archive_intent(intent.id, project, storage):
                console.print("[dim]Intent archived and marked complete[/dim]")
                console.print()
            else:
                console.print("[dim yellow]Warning: Failed to archive intent[/dim]")
                console.print()
        else:
            console.print(
                "[yellow]Some criteria not yet met. Continue working on this intent.[/yellow]"
            )
            console.print()
            console.print("  [dim]Use: obra derive --continue[/dim]")
            console.print()

    except typer.Exit:
        raise
    except Exception as e:
        console.print()
        display_error(e, console)
        logger.exception("Verification failed")
        raise typer.Exit(1) from e


# =============================================================================
# Autonomous Runner
# =============================================================================


@app.command(rich_help_panel="User Commands")
@handle_encoding_errors
def auto(
    plan: str = typer.Option(
        ...,
        "--plan",
        "-p",
        help="WORK_ID for the machine plan (e.g., AUTO-RUN-001)",
    ),
    max_stories: int | None = typer.Option(
        None,
        "--max-stories",
        "-m",
        help="Maximum number of stories to execute (default: all)",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Show execution plan without running stories",
    ),
) -> None:
    """Execute multi-story workplans autonomously.

    The auto-runner executes stories sequentially from MACHINE_PLAN.json
    without continuous LLM attention, solving the completion bias problem.

    Examples:
        obra auto --plan AUTO-RUN-001              # Execute all stories
        obra auto --plan AUTO-RUN-001 --max-stories 2  # Execute 2 stories
        obra auto --plan AUTO-RUN-001 --dry-run    # Show plan only

    Story Execution:
        Each story runs as a separate `obra run` session.
        The runner updates story status in the machine plan after completion.

    Error Handling:
        - Transient errors: Automatic retry (configurable)
        - Breakpoints: Halt execution for human intervention
        - Failed stories: Skip and continue (or escalate based on config)

    Configuration:
        Set in ~/.obra/config-layers/01-user.yaml or config/default_config.yaml:
            auto:
              enabled: true
              retry_count: 3
              retry_delay_seconds: 5
              error_assessor: null  # null=disabled, "fast"=use fast-tier, or model name
              escalate_on_skip: true

    Related Commands:
        - obra run: Execute a single story objective
        - obra derive: Create execution plans from objectives
    """
    import yaml

    from obra.auto.runner import AutoRunner

    # Build plan path
    plan_path = Path.cwd() / "docs" / "development" / f"{plan}_MACHINE_PLAN.json"

    if not plan_path.exists():
        print_error(f"Machine plan not found: {plan_path}")
        print_info("Expected location: docs/development/{WORK_ID}_MACHINE_PLAN.json")
        raise typer.Exit(1)

    if dry_run:
        print_info(f"[DRY-RUN] Autonomous execution plan for {plan}")
        print_info(f"Plan file: {plan_path}")
        print()

    try:
        # Load configuration from default config file
        # Note: obra package uses direct YAML loading, not src.core.config.Config
        config_path = Path(__file__).parent.parent / "config" / "default_config.yaml"
        if not config_path.exists():
            # Fallback for installed package (config not bundled)
            logger.warning(f"Config file not found at {config_path}, using defaults")
            auto_config = {}
        else:
            config = yaml.safe_load(config_path.read_text())
            auto_config = config.get("orchestration", {}).get("auto", {})

        # Extract configuration values
        retry_count = auto_config.get("retry_count", 2)
        retry_delay = auto_config.get("retry_delay_seconds", 30)
        escalate_on_skip = auto_config.get("escalate_on_skip", True)
        error_assessor_config = auto_config.get("error_assessor")

        # Create error assessor if configured
        error_assessor = None
        if error_assessor_config:
            from obra.auto.assessor import ErrorAssessor
            from obra.config import get_llm_config

            # Resolve model name (handle "fast" tier)
            # "fast" maps to haiku for cost-effective error assessment
            model_name = "haiku" if error_assessor_config == "fast" else error_assessor_config

            # Get LLM config from obra.config (client config)
            # This gives us provider, model, auth info for CLI subprocess invocation
            llm_config = get_llm_config()

            # Override model with the assessor-specific model
            if llm_config:
                llm_config = dict(llm_config)  # Make a copy
                llm_config["model"] = model_name
            else:
                # Fallback if no LLM config available
                llm_config = {"provider": "anthropic", "model": model_name}

            error_assessor = ErrorAssessor(enabled=True, llm_config=llm_config)
            logger.info(f"Error assessor enabled with model: {model_name}")

        runner = AutoRunner(
            str(plan_path),
            retry_count=retry_count,
            retry_delay_seconds=retry_delay,
            escalate_on_skip=escalate_on_skip,
            error_assessor=error_assessor,
        )
        exit_code = runner.run(max_stories=max_stories, dry_run=dry_run)

        if exit_code == 0:
            print_success("Autonomous execution completed successfully.")
        else:
            print_error(f"Autonomous execution failed with exit code {exit_code}")
            raise typer.Exit(exit_code)

    except KeyboardInterrupt:
        print_warning("\nAutonomous execution interrupted by user.")
        print_info("Current story state has been saved to plan.")
        raise typer.Exit(0) from None
    except typer.Exit:
        raise
    except Exception as e:
        print_error(f"Autonomous execution error: {e}")
        logger.exception("Auto-runner failed")
        raise typer.Exit(1) from e


# =============================================================================
# Skip Tracking Commands (SKIP-TRACKING-001)
# =============================================================================


skips_app = typer.Typer(
    name="skips",
    help="Manage skip records from execution gaps",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
app.add_typer(skips_app, name="skips", rich_help_panel="User Commands")


def _find_skip_record(skip_id: str):
    from obra.execution.skip_record import list_skip_records

    records = list_skip_records()
    matches = [record for record in records if record.id.startswith(skip_id)]
    if not matches:
        print_error(f"Skip record not found: {skip_id}")
        raise typer.Exit(1)
    if len(matches) > 1:
        print_error(f"Skip ID is ambiguous: {skip_id}")
        raise typer.Exit(1)
    return matches[0]


@skips_app.command("list")
@handle_encoding_errors
def skips_list(
    session_id: str | None = typer.Option(None, "--session-id", help="Filter by session ID"),
    source: str | None = typer.Option(None, "--source", help="Filter by skip source"),
    reason: str | None = typer.Option(None, "--reason", help="Filter by skip reason"),
    status: str | None = typer.Option(
        "pending", "--status", help="Filter by status (default: pending)"
    ),
    as_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List skip records."""
    from obra.execution.skip_record import SkipSource, SkipStatus, list_skip_records

    source_enum = SkipSource(source) if source else None
    status_enum = SkipStatus(status) if status else None

    records = list_skip_records(source=source_enum, status=status_enum)
    if session_id:
        records = [r for r in records if r.session_id == session_id]
    if reason:
        records = [r for r in records if r.reason.value == reason]

    if as_json:
        payload = [record.to_dict() for record in records]
        console.print(json.dumps(payload, indent=2))
        return

    table = Table()
    table.add_column("ID", style="cyan")
    table.add_column("Task")
    table.add_column("Source")
    table.add_column("Reason")
    table.add_column("Created", style="dim")
    table.add_column("Status")

    for record in records:
        created_at = record.created_at
        if "T" in created_at:
            try:
                dt = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
                created_at = dt.strftime("%Y-%m-%d %H:%M")
            except ValueError:
                pass
        table.add_row(
            record.id[:8],
            record.task_id,
            record.source.value,
            record.reason.value,
            created_at,
            record.status.value,
        )

    console.print(table)


@skips_app.command("show")
@handle_encoding_errors
def skips_show(skip_id: str) -> None:
    """Display full details of a skip record."""
    record = _find_skip_record(skip_id)

    console.print(f"[bold]Skip {record.id}[/bold]")
    console.print(f"Session: {record.session_id}")
    console.print(f"Task: {record.task_id}")
    console.print(f"Source: {record.source.value}")
    console.print(f"Reason: {record.reason.value}")
    console.print(f"Status: {record.status.value}")
    console.print(f"Created: {record.created_at}")
    console.print(f"Description: {record.description}")
    if record.required_input:
        console.print(f"Required Input: {json.dumps(record.required_input, indent=2)}")
    if record.attempted_resolution:
        console.print(f"Attempted Resolution: {record.attempted_resolution}")
    if record.file_context:
        console.print(f"File Context: {record.file_context}")
    if record.error_logs:
        console.print("Error Logs:")
        console.print(record.error_logs)
    if record.source_context:
        console.print(f"Source Context: {json.dumps(record.source_context, indent=2)}")
    if record.resolution_notes:
        console.print(f"Resolution Notes: {record.resolution_notes}")
    if record.resolved_at:
        console.print(f"Resolved At: {record.resolved_at}")
    if record.resolved_by:
        console.print(f"Resolved By: {record.resolved_by}")


@skips_app.command("resolve")
@handle_encoding_errors
def skips_resolve(
    skip_id: str,
    status: str = typer.Option(
        "resolved",
        "--status",
        help="Resolution status (resolved, deferred, wont_fix)",
    ),
    notes: str | None = typer.Option(None, "--notes", help="Resolution notes"),
    context_json: str | None = typer.Option(None, "--context", help="Resolution context JSON"),
) -> None:
    """Mark a skip record as resolved."""
    from obra.cleanup.resolver import parse_resolution_context
    from obra.execution.skip_record import SkipStatus, persist_skip_record

    record = _find_skip_record(skip_id)
    record.status = SkipStatus(status)
    if notes:
        record.resolution_notes = notes
    record.resolved_at = datetime.now(UTC).isoformat()
    record.resolved_by = "user"
    context = parse_resolution_context(context_json)
    if context:
        record.source_context = {
            **record.source_context,
            "resolution_context": context,
        }
    persist_skip_record(record)
    print_success(f"Skip {record.id[:8]} marked as {record.status.value}")


@skips_app.command("stats")
@handle_encoding_errors
def skips_stats() -> None:
    """Show skip statistics."""
    from obra.execution.skip_record import get_skip_metrics_summary

    summary = get_skip_metrics_summary()
    console.print(f"[bold]Total skips:[/bold] {summary.get('total', 0)}")

    def _render_breakdown(title: str, data: dict[str, Any]) -> None:
        if not data:
            return
        console.print(f"[bold]{title}[/bold]")
        table = Table()
        table.add_column("Key")
        table.add_column("Count", justify="right")
        for key, value in sorted(data.items()):
            table.add_row(str(key), str(value))
        console.print(table)

    _render_breakdown("By source", summary.get("by_source", {}))
    _render_breakdown("By reason", summary.get("by_reason", {}))
    _render_breakdown("By status", summary.get("by_status", {}))


@skips_app.command("cleanup")
@handle_encoding_errors
def skips_cleanup(
    interactive: bool = typer.Option(
        True,
        "--interactive/--no-interactive",
        help="Interactive resolution mode",
    ),
    export_plan: bool = typer.Option(
        False,
        "--export",
        help="Export cleanup epic as MACHINE_PLAN.json",
    ),
    auto: bool = typer.Option(
        False,
        "--auto",
        help="Auto-retry transient skips",
    ),
) -> None:
    """Generate cleanup epic from pending skips."""
    from obra.cleanup.epic_generator import (
        export_cleanup_as_machine_plan,
        generate_cleanup_epic,
    )
    from obra.cleanup.resolver import auto_retry_skips, resolve_skips_interactively
    from obra.execution.skip_record import SkipStatus, list_skip_records

    pending_skips = list_skip_records(status=SkipStatus.PENDING)
    epic = generate_cleanup_epic(pending_skips)

    if export_plan:
        path = export_cleanup_as_machine_plan(epic)
        print_success(f"Cleanup plan exported to {path}")

    if auto:
        auto_retry_skips(pending_skips)
        print_info("Auto-retry completed for eligible skips.")

    if interactive:
        resolve_skips_interactively(pending_skips)


# =============================================================================
# Prompt File Management Commands (BUG-PROMPT-RACE-001)
# =============================================================================

prompts_app = typer.Typer(
    name="prompts",
    help="Manage prompt files used during LLM orchestration",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
app.add_typer(prompts_app, name="prompts", rich_help_panel="User Commands")


@prompts_app.command("cleanup")
@handle_encoding_errors
def prompts_cleanup(
    age_hours: int | None = typer.Option(
        None,
        "--age-hours",
        "-a",
        help="Only delete prompts older than this many hours (default: from config)",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Delete all prompt files regardless of age (requires confirmation)",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        "-n",
        help="Show what would be deleted without actually deleting",
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip confirmation prompt (use with --force)",
    ),
) -> None:
    """Clean up old prompt files from the .obra/prompts directory.

    By default, only deletes prompt files older than the configured age threshold
    (default: 24 hours). Use --force to delete all files regardless of age.

    This command is safe to run during active orchestration - it respects
    age-based protection to avoid deleting prompts in use.

    Examples:
        obra prompts cleanup                  # Delete prompts older than 24h
        obra prompts cleanup --age-hours 48   # Delete prompts older than 48h
        obra prompts cleanup --dry-run        # Preview what would be deleted
        obra prompts cleanup --force --yes    # Delete all prompts (no confirm)
    """
    import time

    from obra.config import get_prompt_cleanup_age_hours

    working_dir = Path.cwd()
    prompts_dir = working_dir / ".obra" / "prompts"

    if not prompts_dir.exists():
        console.print()
        print_info("No prompt files to clean up")
        console.print(f"  Directory not found: {prompts_dir}")
        console.print()
        return

    # Determine age threshold
    if force:
        threshold_hours = 0  # Delete everything
        threshold_desc = "all files"
    else:
        threshold_hours = age_hours if age_hours is not None else get_prompt_cleanup_age_hours()
        threshold_desc = f"files older than {threshold_hours}h"

    cutoff_time = time.time() - (threshold_hours * 3600)

    # Collect files to delete
    files_to_delete: list[tuple[Path, float]] = []
    files_skipped = 0
    total_size = 0

    for run_dir in prompts_dir.iterdir():
        if not run_dir.is_dir():
            continue
        if run_dir.name.startswith("."):
            continue  # Skip index files

        for prompt_file in run_dir.glob(".obra-prompt-*.txt"):
            try:
                stat = prompt_file.stat()
                age_hours_actual = (time.time() - stat.st_mtime) / 3600
                if force or stat.st_mtime < cutoff_time:
                    files_to_delete.append((prompt_file, age_hours_actual))
                    total_size += stat.st_size
                else:
                    files_skipped += 1
            except OSError:
                pass  # Skip files we can't stat

    if not files_to_delete:
        console.print()
        print_info(f"No prompt files match criteria ({threshold_desc})")
        if files_skipped:
            console.print(f"  Skipped {files_skipped} recent file(s)")
        console.print()
        return

    # Show summary
    console.print()
    if dry_run:
        console.print("[bold yellow]DRY RUN[/bold yellow] - No files will be deleted")
        console.print()

    console.print(f"[bold]Prompt cleanup: {threshold_desc}[/bold]")
    console.print(f"  Files to delete: {len(files_to_delete)}")
    console.print(f"  Total size: {total_size / KIBIBYTE:.1f} KB")
    if files_skipped:
        console.print(f"  Files skipped (recent): {files_skipped}")
    console.print()

    # Show files
    if len(files_to_delete) <= 10:
        console.print("[dim]Files:[/dim]")
        for file_path, age_h in files_to_delete:
            rel_path = file_path.relative_to(prompts_dir)
            console.print(f"  [dim]{rel_path}[/dim] ({age_h:.1f}h old)")
        console.print()

    if dry_run:
        console.print("[yellow]No changes made (dry run)[/yellow]")
        console.print()
        return

    # Confirm if force and not yes
    if force and not yes:
        console.print(
            "[yellow]⚠️  This will delete ALL prompt files, including recent ones.[/yellow]"
        )
        confirm = typer.confirm(get_message("prompt.confirm.continue_action"))
        if not confirm:
            print_info("Cleanup cancelled")
            raise typer.Exit(0)

    # Delete files
    deleted_count = 0
    deleted_size = 0
    empty_dirs: set[Path] = set()

    for file_path, _ in files_to_delete:
        try:
            file_size = file_path.stat().st_size
            file_path.unlink()
            deleted_count += 1
            deleted_size += file_size
            empty_dirs.add(file_path.parent)
        except OSError as e:
            logger.warning(f"Could not delete {file_path}: {e}")

    # Clean up empty run directories
    dirs_removed = 0
    for dir_path in empty_dirs:
        try:
            if dir_path.exists() and not any(dir_path.iterdir()):
                dir_path.rmdir()
                dirs_removed += 1
        except OSError:
            pass

    print_success(f"Deleted {deleted_count} prompt file(s) ({deleted_size / KIBIBYTE:.1f} KB)")
    if dirs_removed:
        console.print(f"  [dim]Removed {dirs_removed} empty directory(s)[/dim]")
    console.print()


@prompts_app.command("list")
@handle_encoding_errors
def prompts_list(
    show_all: bool = typer.Option(
        False,
        "--all",
        "-a",
        help="Show all prompt files (default: show summary only)",
    ),
) -> None:
    """List prompt files in the .obra/prompts directory.

    Shows a summary of prompt files organized by session/run ID.

    Examples:
        obra prompts list          # Show summary
        obra prompts list --all    # Show all files
    """
    import time

    working_dir = Path.cwd()
    prompts_dir = working_dir / ".obra" / "prompts"

    if not prompts_dir.exists():
        console.print()
        print_info("No prompt files found")
        console.print(f"  Directory: {prompts_dir}")
        console.print()
        return

    # Collect stats per run_id
    run_stats: dict[str, dict[str, Any]] = {}
    total_files = 0
    total_size = 0

    for run_dir in prompts_dir.iterdir():
        if not run_dir.is_dir():
            continue
        if run_dir.name.startswith("."):
            continue

        run_id = run_dir.name
        files: list[tuple[Path, float, int]] = []

        for prompt_file in run_dir.glob(".obra-prompt-*.txt"):
            try:
                stat = prompt_file.stat()
                age_hours = (time.time() - stat.st_mtime) / 3600
                files.append((prompt_file, age_hours, stat.st_size))
                total_files += 1
                total_size += stat.st_size
            except OSError:
                pass

        if files:
            files.sort(key=lambda x: x[1])  # Sort by age
            oldest_age = files[-1][1] if files else 0
            newest_age = files[0][1] if files else 0
            run_size = sum(f[2] for f in files)

            run_stats[run_id] = {
                "count": len(files),
                "size": run_size,
                "oldest_age": oldest_age,
                "newest_age": newest_age,
                "files": files,
            }

    if not run_stats:
        console.print()
        print_info("No prompt files found")
        console.print()
        return

    console.print()
    console.print(
        f"[bold]Prompt files: {total_files} total ({total_size / KIBIBYTE:.1f} KB)[/bold]"
    )
    console.print()

    # Sort runs by newest file age (most recent first)
    sorted_runs = sorted(run_stats.items(), key=lambda x: x[1]["newest_age"])

    for run_id, stats in sorted_runs:
        age_range = f"{stats['newest_age']:.1f}h"
        if stats["oldest_age"] != stats["newest_age"]:
            age_range = f"{stats['newest_age']:.1f}-{stats['oldest_age']:.1f}h"

        # Truncate run_id for display
        display_id = run_id[:12] + "..." if len(run_id) > 15 else run_id

        console.print(
            f"  [cyan]{display_id}[/cyan]: "
            f"{stats['count']} file(s), "
            f"{stats['size'] / KIBIBYTE:.1f} KB, "
            f"age: {age_range}"
        )

        if show_all:
            for file_path, age_h, size in stats["files"]:
                console.print(f"    [dim]{file_path.name}[/dim] ({age_h:.1f}h, {size} bytes)")

    console.print()
    console.print("[dim]Use 'obra prompts cleanup' to remove old prompt files[/dim]")
    console.print()


# =============================================================================
# Entry Point
# =============================================================================


def main() -> None:
    """Main entry point for the CLI.

    Tier 2: Includes command typo suggestions for better discoverability.
    """
    # Windows UTF-8 setup BEFORE any output (including --help)
    # This must run before Typer/Rich output anything with Unicode
    if sys.platform == "win32":
        os.environ["PYTHONUTF8"] = "1"
        # Reconfigure stdout/stderr for UTF-8 with fallback for unprintable chars
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        if hasattr(sys.stderr, "reconfigure"):
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")

    _maybe_print_legacy_runtime_notice()

    # FEAT-CLI-VERSION-NOTIFY-001: Check for updates in background (non-blocking)
    check_for_updates_async()

    # Tier 2: Wrap app() to catch unknown commands and suggest alternatives
    try:
        app()
    except SystemExit as e:
        # Check if this is an unknown command error (exit code 2 from Click)
        if e.code == 2 and len(sys.argv) > 1:
            import difflib

            # Get the command that was attempted
            attempted_cmd = sys.argv[1]

            # Skip if it starts with - (it's a flag, not a command)
            if attempted_cmd.startswith("-"):
                raise

            # Get all available command names
            all_commands = [cmd.name for cmd in app.registered_commands if cmd.name]

            # Find close matches
            suggestions = difflib.get_close_matches(attempted_cmd, all_commands, n=3, cutoff=0.6)

            if suggestions:
                console.print()
                console.print("[yellow]💡 Did you mean:[/yellow]")
                for suggestion in suggestions:
                    console.print(f"   • obra {suggestion}")
                console.print()
                console.print("[dim]Run 'obra --help' for full command list.[/dim]")
                raise SystemExit(2) from e
        raise


if __name__ == "__main__":
    main()
