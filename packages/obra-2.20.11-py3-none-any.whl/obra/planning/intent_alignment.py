"""Intent alignment review for derived epics/stories."""

# pylint: disable=too-many-instance-attributes,too-many-arguments,too-many-locals

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from obra.config.llm import resolve_tier_config
from obra.config.loaders import load_layered_config
from obra.exceptions import ConfigurationError
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.prompts.review.alignment import (
    build_gap_detection_prompt,
    build_plan_intent_alignment_prompt,
    build_story_intent_alignment_prompt,
)

logger = logging.getLogger(__name__)


@dataclass
class StoryAssessment:
    """Assessment of a single story's intent coverage."""

    story_id: str
    status: str  # "ok", "scope_creep", "missing_coverage"
    note: str


@dataclass
class IntentAlignmentResult:
    """Parsed intent alignment result with actionable fixes."""

    changes_required: bool
    coverage_status: str
    story_assessments: list[StoryAssessment]
    missing_requirements: list[str]
    stories_to_add: list[dict[str, Any]]
    stories_to_remove: list[str]
    notes: list[str]
    raw_response: str
    duration_s: float


def _normalize_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item) for item in value if item is not None]
    if value is None:
        return []
    return [str(value)]


def _normalize_stories(value: Any) -> list[dict[str, Any]]:
    """Normalize stories_to_add into a list of story dicts."""
    if not isinstance(value, list):
        return []
    result = []
    for item in value:
        if isinstance(item, dict):
            title = str(item.get("title", "")).strip()
            description = str(item.get("description", "")).strip()
            parent_id = item.get("parent_id")
            acceptance = item.get("acceptance_criteria", [])
            if not title or not description or not parent_id:
                continue
            if not isinstance(acceptance, list):
                continue
            result.append(
                {
                    "title": title,
                    "description": description,
                    "parent_id": str(parent_id).strip(),
                    "acceptance_criteria": [str(entry) for entry in acceptance],
                }
            )
    return result


def _normalize_story_assessments(value: Any) -> list[StoryAssessment]:
    """Normalize story_assessments into a list of StoryAssessment objects."""
    if not isinstance(value, list):
        return []
    result = []
    for item in value:
        if isinstance(item, dict) and "id" in item:
            result.append(
                StoryAssessment(
                    story_id=str(item.get("id", "")),
                    status=str(item.get("status", "ok")),
                    note=str(item.get("note", "")),
                )
            )
    return result


def _load_alignment_config() -> dict[str, Any]:
    config, _, _ = load_layered_config(include_defaults=True)
    return config.get("planning", {}).get("intent_alignment", {}) or {}


def run_intent_alignment_review(
    *,
    working_dir: Path,
    objective: str,
    intent_markdown: str,
    epics_json: str,
    stories_json: str,
    llm_config: dict[str, Any],
    on_stream: Any | None = None,
    log_event: Any | None = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
) -> IntentAlignmentResult | None:
    """Run LLM alignment review using template edit pattern.

    Returns None when disabled or parsing fails after retries.
    """
    alignment_config = _load_alignment_config()
    if not alignment_config:
        logger.info("Intent alignment disabled: missing config")
        return None

    model_tier = alignment_config.get("model_tier")
    reasoning_level = alignment_config.get("reasoning_level")
    max_passes = int(alignment_config.get("max_passes", 0))

    if not model_tier or not reasoning_level:
        msg = "planning.intent_alignment.model_tier and reasoning_level are required"
        raise ConfigurationError(
            msg,
            "Set model_tier and reasoning_level for intent alignment in config.",
        )

    if max_passes < 1:
        logger.info("Intent alignment disabled: max_passes < 1")
        return None

    resolved = resolve_tier_config(
        model_tier,
        role="implementation",
        override_thinking_level=reasoning_level,
    )

    prompt = build_plan_intent_alignment_prompt(
        objective,
        intent_markdown,
        epics_json,
        stories_json,
    )

    start = time.time()

    # Create template edit pipeline (FEAT-TEMPLATE-JSON-001)
    # FIX-ALIGNMENT-STALL-001: Disable streaming to avoid 300s idle timeout during file editing.
    # Anthropic CLI in 'execute' mode is silent on stdout, which triggers idle timeouts
    # during long-running alignment review tasks.
    pipeline = TemplateEditPipeline(
        working_dir=working_dir,
        action_name="intent_alignment",
        on_stream=None,
        log_event=log_event,
        max_retries=max_passes,
    )

    # Template schema for intent alignment
    template_schema = {
        "coverage_status": "",
        "story_assessments": [],
        "missing_requirements": [],
        "stories_to_add": [],
        "stories_to_remove": [],
        "notes": [],
        "_instructions": (
            "Analyze the plan against the intent and fill in:\n"
            "- coverage_status: 'ok', 'warn', or 'fail'\n"
            "- story_assessments: List of {id, status, note} for each story\n"
            "- missing_requirements: List of requirements not covered\n"
            "- stories_to_add: List of {title, description, parent_id, acceptance_criteria} for suggested stories\n"
            "- stories_to_remove: List of story IDs that are scope creep\n"
            "- notes: Any additional observations"
        ),
    }

    def validator(data: dict) -> tuple[bool, str | None]:
        status = data.get("coverage_status", "").lower()
        if status and status not in {"ok", "warn", "fail"}:
            return (
                False,
                f"coverage_status must be 'ok', 'warn', or 'fail', got '{status}'",
            )
        assessments = data.get("story_assessments", [])
        if assessments is not None and not isinstance(assessments, list):
            return (False, "story_assessments must be a list")
        for index, assessment in enumerate(assessments or [], start=1):
            if not isinstance(assessment, dict):
                return (False, f"story_assessments[{index}] must be an object")
            if not str(assessment.get("id", "")).strip():
                return (False, f"story_assessments[{index}] missing id")
            status_value = str(assessment.get("status", "")).lower()
            if status_value and status_value not in {
                "ok",
                "scope_creep",
                "missing_coverage",
            }:
                return (
                    False,
                    f"story_assessments[{index}] invalid status: {status_value}",
                )
        stories_to_add = data.get("stories_to_add", [])
        if stories_to_add is not None and not isinstance(stories_to_add, list):
            return (False, "stories_to_add must be a list")
        for index, story in enumerate(stories_to_add or [], start=1):
            if not isinstance(story, dict):
                return (False, f"stories_to_add[{index}] must be an object")
            title = str(story.get("title", "")).strip()
            description = str(story.get("description", "")).strip()
            parent_id = str(story.get("parent_id", "")).strip()
            if not title:
                return (False, f"stories_to_add[{index}] missing title")
            if not description:
                return (False, f"stories_to_add[{index}] missing description")
            if not parent_id:
                return (False, f"stories_to_add[{index}] missing parent_id")
            acceptance = story.get("acceptance_criteria", [])
            if not isinstance(acceptance, list):
                return (
                    False,
                    f"stories_to_add[{index}] acceptance_criteria must be a list",
                )
        return (True, None)

    def fallback() -> dict | None:
        return None

    result_data, _metadata = pipeline.execute(
        base_prompt=prompt,
        template_content=template_schema,
        validator=validator,
        fallback_fn=fallback,
        llm_config={
            "provider": resolved["provider"],
            "model": resolved["model"],
            "thinking": resolved["thinking_level"],
            "auth": resolved["auth_method"],
        },
    )

    if result_data is None:
        logger.warning("Intent alignment parsing failed after %s attempts", max_passes)
        return None

    duration = time.time() - start
    coverage_status = str(result_data.get("coverage_status", ""))
    story_assessments = _normalize_story_assessments(result_data.get("story_assessments"))
    missing_requirements = _normalize_list(result_data.get("missing_requirements"))
    stories_to_add = _normalize_stories(result_data.get("stories_to_add"))
    stories_to_remove = _normalize_list(result_data.get("stories_to_remove"))
    notes = _normalize_list(result_data.get("notes"))
    changes_required = bool(
        coverage_status in {"warn", "fail"}
        or missing_requirements
        or stories_to_add
        or stories_to_remove
    )

    return IntentAlignmentResult(
        changes_required=changes_required,
        coverage_status=coverage_status,
        story_assessments=story_assessments,
        missing_requirements=missing_requirements,
        stories_to_add=stories_to_add,
        stories_to_remove=stories_to_remove,
        notes=notes,
        raw_response=json.dumps(result_data),
        duration_s=duration,
    )


def run_story_intent_review(
    *,
    working_dir: Path,
    objective: str,
    intent_markdown: str,
    story: dict[str, Any],
    epic_title: str | None,
    llm_config: dict[str, Any],
    resolved_config: dict[str, Any],
    timeout_s: int,
    max_passes: int,
    on_stream: Any | None = None,
    log_event: Any | None = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
) -> StoryAssessment:
    """Run LLM alignment review for a single story using template edit pattern.

    Args:
        working_dir: Working directory for LLM invocation
        objective: Original objective string
        intent_markdown: Full intent document for context
        story: Story dict with id, title, description, acceptance_criteria
        epic_title: Parent epic title for context
        llm_config: LLM configuration dict
        resolved_config: Pre-resolved tier config (provider, model, etc.)
        timeout_s: Timeout per LLM call (unused - pipeline manages timeout)
        max_passes: Retry limit on parse failure
        on_stream: Optional streaming callback
        log_event: Optional log event callback
        trace_id: Trace ID for telemetry
        parent_span_id: Parent span ID for telemetry

    Returns:
        StoryAssessment with status and note
    """
    story_id = story.get("id", "unknown")
    story_json = json.dumps(story, indent=2)

    prompt = build_story_intent_alignment_prompt(
        objective,
        intent_markdown,
        story_json,
        epic_title,
    )

    # Create template edit pipeline (FEAT-TEMPLATE-JSON-001)
    # FIX-STORY-REVIEW-STALL-001: Disable streaming to avoid 300s idle timeout during file editing.
    # Anthropic CLI in 'execute' mode is silent on stdout, which triggers idle timeouts
    # during long-running story review tasks.
    pipeline = TemplateEditPipeline(
        working_dir=working_dir,
        action_name=f"story_review_{story_id}",
        on_stream=None,
        log_event=log_event,
        max_retries=max_passes,
    )

    # Template schema for story review
    template_schema = {
        "status": "",
        "note": "",
        "_instructions": (
            "Review the story against the intent and fill in:\n"
            "- status: 'ok', 'scope_creep', or 'missing_coverage'\n"
            "- note: Brief explanation of the assessment"
        ),
    }

    def validator(data: dict) -> tuple[bool, str | None]:
        status = data.get("status", "").lower()
        if status and status not in {"ok", "scope_creep", "missing_coverage"}:
            return (
                False,
                f"status must be 'ok', 'scope_creep', or 'missing_coverage', got '{status}'",
            )
        return (True, None)

    def fallback() -> dict:
        return {"status": "ok", "note": "Review failed to parse; defaulting to ok"}

    result_data, metadata = pipeline.execute(
        base_prompt=prompt,
        template_content=template_schema,
        validator=validator,
        fallback_fn=fallback,
        llm_config={
            "provider": resolved_config["provider"],
            "model": resolved_config["model"],
            "thinking": resolved_config["thinking_level"],
            "auth": resolved_config["auth_method"],
        },
    )

    if metadata.get("status") == "template_fallback":
        logger.warning(
            "Story %s intent review failed parsing after %d attempts",
            story_id,
            max_passes,
        )

    return StoryAssessment(
        story_id=story_id,
        status=str(result_data.get("status", "ok")),
        note=str(result_data.get("note", "")),
    )


@dataclass
class GapDetectionResult:
    """Result of gap detection analysis."""

    gaps_found: bool
    missing_requirements: list[str]
    stories_to_add: list[dict[str, Any]]
    duration_s: float


def run_gap_detection(
    *,
    working_dir: Path,
    objective: str,
    intent_markdown: str,
    stories: list[dict[str, Any]],
    llm_config: dict[str, Any],
    resolved_config: dict[str, Any],
    timeout_s: int,
    max_passes: int,
    on_stream: Any | None = None,
    log_event: Any | None = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
) -> GapDetectionResult:
    """Run gap detection using template edit pattern.

    Args:
        working_dir: Working directory for LLM invocation
        objective: Original objective string
        intent_markdown: Full intent document
        stories: List of story dicts that passed per-story assessment
        llm_config: LLM configuration dict
        resolved_config: Pre-resolved tier config (provider, model, etc.)
        timeout_s: Timeout per LLM call (unused - pipeline manages timeout)
        max_passes: Retry limit on parse failure
        on_stream: Optional streaming callback
        log_event: Optional log event callback
        trace_id: Trace ID for telemetry
        parent_span_id: Parent span ID for telemetry

    Returns:
        GapDetectionResult with any missing requirements and suggested stories
    """
    start = time.time()
    stories_json = json.dumps(stories, indent=2)

    prompt = build_gap_detection_prompt(
        objective,
        intent_markdown,
        stories_json,
    )

    # Create template edit pipeline (FEAT-TEMPLATE-JSON-001)
    # FIX-GAP-DETECTION-STALL-001: Disable streaming to avoid 300s idle timeout during file editing.
    # Anthropic CLI in 'execute' mode is silent on stdout, which triggers idle timeouts
    # during long-running gap detection tasks.
    pipeline = TemplateEditPipeline(
        working_dir=working_dir,
        action_name="gap_detection",
        on_stream=None,
        log_event=log_event,
        max_retries=max_passes,
    )

    # Template schema for gap detection
    template_schema = {
        "gaps_found": False,
        "missing_requirements": [],
        "stories_to_add": [],
        "_instructions": (
            "Analyze the stories against the intent and fill in:\n"
            "- gaps_found: true if any requirements are not covered by existing stories\n"
            "- missing_requirements: List of requirements from intent not covered\n"
            "- stories_to_add: List of {title, description, parent_id, acceptance_criteria} for suggested new stories"
        ),
    }

    def validator(data: dict) -> tuple[bool, str | None]:
        # gaps_found should be boolean
        if "gaps_found" in data and not isinstance(data["gaps_found"], bool):
            # Try to coerce string "true"/"false" to bool
            gf = data.get("gaps_found")
            if isinstance(gf, str):
                data["gaps_found"] = gf.lower() == "true"
            else:
                return (False, "gaps_found must be a boolean")
        stories_to_add = data.get("stories_to_add", [])
        if stories_to_add is not None and not isinstance(stories_to_add, list):
            return (False, "stories_to_add must be a list")
        for index, story in enumerate(stories_to_add or [], start=1):
            if not isinstance(story, dict):
                return (False, f"stories_to_add[{index}] must be an object")
            title = str(story.get("title", "")).strip()
            description = str(story.get("description", "")).strip()
            parent_id = str(story.get("parent_id", "")).strip()
            if not title:
                return (False, f"stories_to_add[{index}] missing title")
            if not description:
                return (False, f"stories_to_add[{index}] missing description")
            if not parent_id:
                return (False, f"stories_to_add[{index}] missing parent_id")
            acceptance = story.get("acceptance_criteria", [])
            if not isinstance(acceptance, list):
                return (
                    False,
                    f"stories_to_add[{index}] acceptance_criteria must be a list",
                )
        return (True, None)

    def fallback() -> dict:
        return {"gaps_found": False, "missing_requirements": [], "stories_to_add": []}

    result_data, metadata = pipeline.execute(
        base_prompt=prompt,
        template_content=template_schema,
        validator=validator,
        fallback_fn=fallback,
        llm_config={
            "provider": resolved_config["provider"],
            "model": resolved_config["model"],
            "thinking": resolved_config["thinking_level"],
            "auth": resolved_config["auth_method"],
        },
    )

    if metadata.get("status") == "template_fallback":
        logger.warning("Gap detection failed parsing after %d attempts", max_passes)

    duration = time.time() - start
    return GapDetectionResult(
        gaps_found=bool(result_data.get("gaps_found", False)),
        missing_requirements=_normalize_list(result_data.get("missing_requirements")),
        stories_to_add=_normalize_stories(result_data.get("stories_to_add")),
        duration_s=duration,
    )


__all__ = [
    "GapDetectionResult",
    "IntentAlignmentResult",
    "StoryAssessment",
    "run_gap_detection",
    "run_intent_alignment_review",
    "run_story_intent_review",
]
