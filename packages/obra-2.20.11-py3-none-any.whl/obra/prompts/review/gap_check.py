"""Prompt builders for post-execution intent gap checks."""


def _build_gap_prompt(
    *,
    objective: str,
    intent_markdown: str,
    delivered_summary_json: str,
    scope_label: str,
    scope_guidance: str,
    user_stories_markdown: str | None = None,
) -> str:
    # Build user stories section if provided
    user_stories_section = ""
    if user_stories_markdown:
        user_stories_section = f"""
User Stories:
{user_stories_markdown}
"""

    return f"""You are reviewing delivered work against intent.

Objective:
"{objective}"

Intent:
{intent_markdown}
{user_stories_section}
Delivered summary (JSON):
{delivered_summary_json}

Scope:
{scope_label}

Task:
1) Compare the delivered summary against intent requirements for this scope.
2) Flag missing intent requirements or scope creep.
3) Propose follow-up stories only when gaps exist.

Rules:
- {scope_guidance}
- Do not propose tasks; propose story-level outcomes only.
- Do not add features beyond intent requirements.
- Flag user stories that have no corresponding delivered work as uncovered.
- Be concise and specific.

Output format (JSON only):
{{
  "coverage_status": "pass|warn|fail",
  "missing_requirements": ["..."],
  "scope_creep": ["..."],
  "uncovered_user_stories": ["US-1", "..."],
  "followup_stories": [
    {{
      "title": "...",
      "description": "...",
      "acceptance_criteria": ["..."]
    }}
  ],
  "notes": ["..."]
}}
"""


def build_story_gap_prompt(
    *,
    objective: str,
    intent_markdown: str,
    delivered_summary_json: str,
    story_id: str,
    story_title: str,
    user_stories_markdown: str | None = None,
) -> str:
    scope_label = f"Story {story_id}: {story_title}"
    scope_guidance = "Limit to the completed story scope only."
    return _build_gap_prompt(
        objective=objective,
        intent_markdown=intent_markdown,
        delivered_summary_json=delivered_summary_json,
        scope_label=scope_label,
        scope_guidance=scope_guidance,
        user_stories_markdown=user_stories_markdown,
    )


def build_epic_gap_prompt(
    *,
    objective: str,
    intent_markdown: str,
    delivered_summary_json: str,
    epic_id: str,
    epic_title: str,
    user_stories_markdown: str | None = None,
) -> str:
    scope_label = f"Epic {epic_id}: {epic_title}"
    scope_guidance = "Evaluate full intent coverage for the epic."
    return _build_gap_prompt(
        objective=objective,
        intent_markdown=intent_markdown,
        delivered_summary_json=delivered_summary_json,
        scope_label=scope_label,
        scope_guidance=scope_guidance,
        user_stories_markdown=user_stories_markdown,
    )


__all__ = ["build_epic_gap_prompt", "build_story_gap_prompt"]
