"""Tests for obsidian-memory."""
