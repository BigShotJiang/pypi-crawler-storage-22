"""Interactive UI components for ObsidianKi CLI"""
