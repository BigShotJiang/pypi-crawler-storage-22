def test_version():
    from obspec_utils import __version__

    assert __version__
