import gitlab


class GitLabClient:
    """
    GitLab API wrapper for oca-port-jarsa using python-gitlab SDK.
    """

    def __init__(self, token: str, base_url: str):
        self.base_url = base_url.rstrip("/")
        self.token = token

        self.gl = gitlab.Gitlab(
            url=self.base_url,
            private_token=self.token,
            per_page=50,
        )

        # Validate connection early
        self.gl.auth()

    # ---------------------------------------------------------
    # Public API
    # ---------------------------------------------------------

    def search_migration_mr(self, project_path, target_branch, addon):
        """
        Search open Merge Requests that match:
        - target branch
        - addon name in title

        Returns:
            python-gitlab MR object or None
        """

        project = self.gl.projects.get(project_path)

        mrs = project.mergerequests.list(
            state="opened",
            target_branch=target_branch,
            search=addon,
            all=True,
        )

        if not mrs:
            return None

        addon_lower = addon.lower()

        for mr in mrs:
            if addon_lower in mr.title.lower():
                return mr

        return None
