"""
Open Context Protocol (OCP) - Python Library

A zero-infrastructure protocol that provides conversational context
and automatic API discovery to enhance AI agent interactions.

Enables persistent context sharing across HTTP API calls using standard headers,
requiring no servers or infrastructure setup.
"""

from .context import AgentContext
from .http_client import OCPHTTPClient
from .headers import OCPHeaders, create_ocp_headers, extract_context_from_response, parse_context, add_context_headers
from .validation import validate_context
from .schema_discovery import OCPSchemaDiscovery, OCPTool, OCPAPISpec
from .registry import OCPRegistry
from .agent import OCPAgent
from .storage import OCPStorage
from .errors import OCPError, RegistryUnavailable, APINotFound, SchemaDiscoveryError, ValidationError
from .parsers import APISpecParser, ParserRegistry, OpenAPIParser

__version__ = "0.1.0"
__all__ = [
    # Core context management
    "AgentContext",
    
    # HTTP client enhancement
    "OCPHTTPClient",
    "OCPHeaders",
    "create_ocp_headers",
    "extract_context_from_response",
    "validate_context",
    
    # Convenience functions
    "parse_context",
    "add_context_headers",
    
    # Schema discovery
    "OCPSchemaDiscovery",
    "OCPTool",
    "OCPAPISpec",
    
    # Parser system
    "APISpecParser",
    "ParserRegistry",
    "OpenAPIParser",
    
    # Registry integration
    "OCPRegistry",
    
    # Local storage
    "OCPStorage",
    
    # Error handling
    "OCPError",
    "RegistryUnavailable", 
    "APINotFound",
    "SchemaDiscoveryError",
    "ValidationError",
    
    # Complete agent functionality
    "OCPAgent"
]