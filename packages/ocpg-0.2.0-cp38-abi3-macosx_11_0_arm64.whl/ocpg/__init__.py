from .ocpg import *

__doc__ = ocpg.__doc__
if hasattr(ocpg, "__all__"):
    __all__ = ocpg.__all__