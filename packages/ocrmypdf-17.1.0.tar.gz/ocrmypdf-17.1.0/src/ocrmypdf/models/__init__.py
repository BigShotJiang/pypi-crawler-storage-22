# SPDX-FileCopyrightText: 2025 James R. Barlow
# SPDX-License-Identifier: MPL-2.0

"""OCRmyPDF models for plugin options and cross-cutting concerns."""

from __future__ import annotations
