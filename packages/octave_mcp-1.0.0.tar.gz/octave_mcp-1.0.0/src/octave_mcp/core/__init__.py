"""Core OCTAVE parsing, validation, and emission."""
