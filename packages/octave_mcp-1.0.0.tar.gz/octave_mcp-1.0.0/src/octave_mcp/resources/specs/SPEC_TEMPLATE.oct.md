===SPEC_NAME===
META:
  TYPE::LLM_PROFILE
  VERSION::"6.0.0"
  STATUS::APPROVED
  TOKENS::"~XXX"
  REQUIRES::[dependencies]
  PURPOSE::"One-line description of spec purpose"
  IMPLEMENTATION_NOTES::"Current implementation status and references"

---

// SPEC_NAME: Brief description and usage context

§1::SECTION_NAME
  // Core definitions and rules

§2::SECTION_NAME
  // Additional specifications

===END===
