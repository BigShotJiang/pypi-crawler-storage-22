"""OCTAVE schema definitions and loading."""
