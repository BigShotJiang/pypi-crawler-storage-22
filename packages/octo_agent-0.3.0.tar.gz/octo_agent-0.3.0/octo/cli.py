"""CLI entry point — Click group + async chat loop."""
from __future__ import annotations

import asyncio
import logging
import uuid

import click
from langchain_core.messages import HumanMessage

from octo.config import DEFAULT_MODEL, TELEGRAM_BOT_TOKEN

logger = logging.getLogger(__name__)


@click.group(invoke_without_command=True)
@click.pass_context
def main(ctx: click.Context) -> None:
    """Octi — LangGraph multi-agent console."""
    if ctx.invoked_subcommand is None:
        ctx.invoke(chat)


@main.command()
@click.option("--model", default="", help="Model override")
@click.option("--verbose", is_flag=True, help="Verbose output")
@click.option("--debug", is_flag=True, help="Debug output (show LLM calls)")
@click.option("--voice", is_flag=True, help="Enable TTS")
@click.option("--thread", default="", help="Resume thread ID")
@click.option("--resume", is_flag=True, help="Resume last session")
@click.option("--no-telegram", is_flag=True, help="Disable Telegram bot")
def chat(model: str, verbose: bool, debug: bool, voice: bool, thread: str, resume: bool, no_telegram: bool) -> None:
    """Start interactive chat session."""
    asyncio.run(_chat_loop(model, verbose, debug, voice, thread, resume, no_telegram))


@main.command(name="init")
@click.option("--quick", is_flag=True, help="QuickStart mode (minimal prompts)")
@click.option("--provider", type=click.Choice(["anthropic", "bedrock", "openai", "azure"]),
              help="Pre-select provider")
@click.option("--no-validate", is_flag=True, help="Skip credential validation")
@click.option("--no-persona", is_flag=True, help="Skip persona file scaffolding")
@click.option("--force", is_flag=True, help="Overwrite existing .env")
def init_cmd(quick: bool, provider: str, no_validate: bool, no_persona: bool, force: bool) -> None:
    """Interactive setup wizard. Creates .env and scaffolds .octo/ structure."""
    from octo.wizard import run_init
    run_init(quick=quick, provider=provider, skip_validation=no_validate,
             skip_persona=no_persona, force=force)


@main.command()
@click.option("--fix", is_flag=True, help="Attempt to fix issues (re-run init)")
@click.option("--json", "json_output", is_flag=True, help="Output as JSON")
def doctor(fix: bool, json_output: bool) -> None:
    """Check Octo configuration health."""
    from octo.wizard import run_doctor
    asyncio.run(run_doctor(fix=fix, json_output=json_output))


@main.command(name="auth")
@click.argument("action", type=click.Choice(["login", "status", "logout"]))
@click.argument("server_name", required=False)
def auth_cmd(action: str, server_name: str | None) -> None:
    """Manage MCP server OAuth authentication."""
    from octo.oauth.cli_commands import handle_auth
    asyncio.run(handle_auth(action, server_name))


# --- Skills marketplace subcommand ---
from octo.skills_cli import skills as skills_group
main.add_command(skills_group)


async def _chat_loop(
    model_override: str,
    verbose: bool,
    debug: bool,
    voice_on: bool,
    thread_id: str,
    resume: bool,
    no_telegram: bool,
) -> None:
    from octo.wizard import check_first_run
    if not check_first_run():
        return

    from octo import ui
    from octo.callbacks import create_cli_callback
    from octo.graph import build_graph, context_info, read_todos, set_session_pool, set_telegram_transport
    from octo.loaders.mcp_loader import MCPSessionPool, create_mcp_client, filter_tools, get_mcp_configs, get_tool_filters, validate_tool_schemas
    from octo.loaders.skill_loader import load_skills
    from octo.models import make_model, resolve_model_name, _detect_provider
    from octo.sessions import save_session, get_last_session
    from octo.telegram import TelegramTransport
    from octo import voice as voice_mod

    # Setup logging
    logging.basicConfig(
        level=logging.DEBUG if debug else logging.WARNING,
        format="%(name)s: %(message)s",
    )
    # Silence noisy loggers (auto-retried, harmless)
    if not debug:
        for noisy in (
            "telegram.ext.Updater",
            "httpx", "httpcore",
            "mcp", "mcp.server", "mcp.server.lowlevel",
            "mcp.client", "mcp.client.session",
        ):
            logging.getLogger(noisy).setLevel(logging.CRITICAL)

    # Always show VP confidence decisions (even without --debug)
    logging.getLogger("octo.virtual_persona").setLevel(logging.INFO)

    # Resolve model info for display
    active_model = resolve_model_name(model_override)
    provider = _detect_provider(active_model)

    # Thread ID — explicit > --resume > new
    if not thread_id and resume:
        last = get_last_session()
        if last:
            thread_id = last["thread_id"]
    if not thread_id:
        thread_id = str(uuid.uuid4())[:8]

    # Persist session immediately
    save_session(thread_id, model=active_model)

    # Persistent session pool for STDIO MCP servers
    session_pool = MCPSessionPool()

    # Load MCP servers + build graph (reloadable via /mcp reload)
    async def _load_mcp_servers():
        """Load MCP servers, return (flat_tools, tools_by_server)."""
        try:
            configs = get_mcp_configs()
            filters = get_tool_filters()
        except Exception as e:
            ui.print_error(
                f"Failed to parse .mcp.json: {e}\n"
                "  Fix the JSON syntax and run /mcp reload"
            )
            return [], {}
        tools_flat = []
        tools_map: dict[str, list] = {}
        for sname, scfg in configs.items():
            try:
                if scfg.get("transport") == "stdio":
                    # Persistent session — subprocess stays alive
                    stools = await session_pool.connect(sname, scfg)
                else:
                    # HTTP/SSE — stateless, ephemeral per-call is fine
                    client = create_mcp_client({sname: scfg})
                    stools = await client.get_tools()
                all_count = len(stools)
                stools = filter_tools(stools, sname, filters)
                stools = validate_tool_schemas(stools, sname)
                tools_map[sname] = stools
                if len(stools) < all_count:
                    ui.print_info(f"MCP '{sname}': {len(stools)}/{all_count} tools (filtered)")
                tools_flat.extend(stools)
            except (KeyboardInterrupt, asyncio.CancelledError):
                raise
            except BaseException as e:
                # Build config context for the error explainer
                cfg_summary = f"server={sname}, transport={scfg.get('transport', 'stdio')}"
                if scfg.get("command"):
                    cfg_summary += f", command={scfg['command']} {' '.join(scfg.get('args', []))}"
                if scfg.get("url"):
                    cfg_summary += f", url={scfg['url']}"
                try:
                    from octo.middleware import explain_error
                    explanation = await explain_error(
                        e,
                        context=f"connecting to MCP server '{sname}'",
                        details=cfg_summary,
                    )
                    ui.print_error(f"MCP server '{sname}': {explanation}")
                except Exception:
                    # If explainer itself fails, fall back to raw error
                    ui.print_error(f"MCP server '{sname}': {e}")
        return tools_flat, tools_map

    mcp_tools, mcp_tools_by_server = await _load_mcp_servers()

    try:
        # Build graph
        app, agent_configs, skills = await build_graph(mcp_tools, mcp_tools_by_server)

        # Register session pool for auto-reconnect on dead STDIO sessions
        set_session_pool(session_pool)

        # Wire live context bar into the toolbar
        ui.set_context_ref(context_info)

        # Print welcome banner
        ui.print_welcome(
            model=active_model,
            provider=provider,
            thread_id=thread_id,
            agent_count=len(agent_configs),
            skill_count=len(skills),
            mcp_tool_count=len(mcp_tools),
            mcp_servers=list(mcp_tools_by_server.keys()) if mcp_tools else None,
        )

        # Voice
        if voice_on:
            voice_mod.toggle_voice(True)
            ui.print_status("Voice enabled", "green")

        # Setup input with slash command completion
        _BASE_SLASH_CMDS = ["/help", "/clear", "/compact", "/context", "/agents", "/skills",
                            "/tools", "/call", "/projects", "/sessions", "/plan", "/profile",
                            "/voice", "/model", "/mcp", "/cron", "/heartbeat", "/vp",
                            "/create-agent", "/state", "/memory", "exit", "quit"]
        slash_cmds = (_BASE_SLASH_CMDS
                      + [f"/{s.name}" for s in skills]
                      + [f"/{a.name}" for a in agent_configs])
        ui.setup_input(slash_cmds)

        # Callback handler — shared between CLI and Telegram so both show tool traces
        cli_callback = create_cli_callback(verbose=verbose or True, debug=debug)

        # Shared lock — prevents concurrent graph invocations from CLI, Telegram, heartbeat, and cron
        graph_lock = asyncio.Lock()

        # Telegram transport
        tg: TelegramTransport | None = None
        if not no_telegram and TELEGRAM_BOT_TOKEN:
            tg = TelegramTransport(
                graph_app=app,
                thread_id=thread_id,
                on_message=lambda text: ui.print_telegram_message(text),
                on_response=lambda text: ui.print_response(text, source="Octi"),
                callbacks=[cli_callback],
                graph_lock=graph_lock,
            )
            await tg.start()
            set_telegram_transport(tg)
            ui.print_status("Telegram bot connected", "green")
        config = {
            "configurable": {"thread_id": thread_id},
            "callbacks": [cli_callback],
        }

        # --- Proactive AI: heartbeat + cron ---
        from octo.config import (
            HEARTBEAT_PATH, HEARTBEAT_INTERVAL_SECONDS,
            HEARTBEAT_ACTIVE_START_TIME, HEARTBEAT_ACTIVE_END_TIME,
            CRON_PATH,
        )
        from octo.heartbeat import HeartbeatRunner, CronScheduler, CronStore, set_cron_store

        async def _deliver_proactive(text: str, source: str = "\U0001f493 Heartbeat") -> None:
            ui.print_response(text, source=f"Octi ({source})")
            if tg:
                await tg.send_proactive(text, source=source)

        async def _deliver_cron(task: str, response: str) -> None:
            msg = f"**Scheduled task**: {task}\n\n{response}"
            await _deliver_proactive(msg, source="\u23f0 Cron")

        heartbeat = HeartbeatRunner(
            graph_app=app,
            get_thread_id=lambda: config["configurable"]["thread_id"],
            interval=HEARTBEAT_INTERVAL_SECONDS,
            active_start=HEARTBEAT_ACTIVE_START_TIME,
            active_end=HEARTBEAT_ACTIVE_END_TIME,
            heartbeat_path=HEARTBEAT_PATH,
            on_message=_deliver_proactive,
            graph_lock=graph_lock,
        )
        heartbeat.start()

        cron_store = CronStore(CRON_PATH)
        set_cron_store(cron_store)

        cron_scheduler = CronScheduler(
            store=cron_store,
            graph_app=app,
            get_thread_id=lambda: config["configurable"]["thread_id"],
            on_message=_deliver_cron,
            graph_lock=graph_lock,
        )
        cron_scheduler.start()

        hb_interval_display = HEARTBEAT_INTERVAL_SECONDS // 60
        ui.print_status(
            f"Heartbeat active (every {hb_interval_display}m, "
            f"{HEARTBEAT_ACTIVE_START_TIME.strftime('%H:%M')}-"
            f"{HEARTBEAT_ACTIVE_END_TIME.strftime('%H:%M')})", "green"
        )
        cron_jobs = cron_store.load()
        if cron_jobs:
            ui.print_status(f"Cron scheduler active ({len(cron_jobs)} jobs)", "green")

        # --- Virtual Persona poller ---
        vp_poller: Any = None
        from octo.config import VP_ENABLED, VP_POLL_INTERVAL_SECONDS, VP_ACTIVE_START_TIME, VP_ACTIVE_END_TIME, VP_SELF_EMAILS
        if VP_ENABLED:
            from octo.virtual_persona.graph import build_vp_graph
            from octo.virtual_persona.poller import VPPoller, set_self_emails
            if VP_SELF_EMAILS:
                set_self_emails(VP_SELF_EMAILS)

            async def _deliver_escalation(
                text: str, teams_chat_id: str = "", teams_message_id: str = "",
            ) -> None:
                ui.print_response(text, source="Octi (VP Escalation)")
                if tg:
                    await tg.send_vp_notification(text, teams_chat_id, teams_message_id)
                elif not tg:
                    # Console-only fallback
                    pass

            vp_graph = build_vp_graph()
            vp_poller = VPPoller(
                vp_graph=vp_graph,
                octo_app=app,
                graph_lock=graph_lock,
                interval=VP_POLL_INTERVAL_SECONDS,
                active_start=VP_ACTIVE_START_TIME,
                active_end=VP_ACTIVE_END_TIME,
                on_escalation=_deliver_escalation,
                octo_config=config,
            )
            vp_poller.start()
            vp_display = f"{VP_POLL_INTERVAL_SECONDS // 60}m" if VP_POLL_INTERVAL_SECONDS >= 60 else f"{VP_POLL_INTERVAL_SECONDS}s"
            ui.print_status(
                f"VP poller active (every {vp_display}, "
                f"{VP_ACTIVE_START_TIME.strftime('%H:%M')}-"
                f"{VP_ACTIVE_END_TIME.strftime('%H:%M')})", "green"
            )

        async def _rebuild_graph():
            nonlocal app, agent_configs, skills, mcp_tools, mcp_tools_by_server
            await session_pool.close_all()  # Close old STDIO sessions before reload
            mcp_tools, mcp_tools_by_server = await _load_mcp_servers()
            app, agent_configs, skills = await build_graph(mcp_tools, mcp_tools_by_server)
            # Update proactive runners with new graph
            heartbeat._app = app
            cron_scheduler._app = app
            if vp_poller is not None:
                vp_poller._octo_app = app
            # Refresh tab-completion with new skill and agent names
            ui.setup_input(
                _BASE_SLASH_CMDS
                + [f"/{s.name}" for s in skills]
                + [f"/{a.name}" for a in agent_configs]
            )

        async def _auto_handoff(app_ref, cfg, model_factory):
            """Save project state on exit using a cheap LLM summarization."""
            from octo.config import STATE_PATH
            from octo.graph import _todos

            try:
                state = await app_ref.aget_state(cfg)
                messages = state.values.get("messages", [])
                if len(messages) < 3:
                    return  # nothing worth saving

                # Gather recent conversation for context
                recent = messages[-20:]
                summary_lines = []
                for m in recent:
                    role = getattr(m, "type", "unknown")
                    content = m.content if isinstance(m.content, str) else str(m.content)
                    if content.strip():
                        summary_lines.append(f"[{role}]: {content[:300]}")

                # Gather active plan if any
                plan_text = ""
                if _todos:
                    completed = sum(1 for t in _todos if t.get("status") == "completed")
                    plan_text = f"\nActive plan: {completed}/{len(_todos)} tasks completed."

                prompt = (
                    "Based on this conversation extract a brief session handoff note. "
                    "Write 3-5 bullet points covering:\n"
                    "1. What was accomplished this session\n"
                    "2. Current position (what's in progress)\n"
                    "3. Next steps / what to do when resuming\n\n"
                    f"{plan_text}\n\n"
                    "Recent conversation:\n"
                    + "\n".join(summary_lines[-30:])
                )

                ui.print_info("Saving session state...")
                summary_model = model_factory(tier="low")
                response = await summary_model.ainvoke(prompt)

                from datetime import datetime, timezone
                now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
                content = (
                    f"# Project State\n\n_Last updated: {now}_\n\n"
                    f"## Session Handoff\n{response.content}\n"
                )
                STATE_PATH.write_text(content, encoding="utf-8")
                ui.print_info("Session state saved to STATE.md")
            except Exception as e:
                logger.debug("Auto-handoff failed: %s", e)

        try:
            while True:
                user_input = await ui.styled_input_async()

                if not user_input:
                    continue

                # --- Slash commands ---
                if user_input.lower() in ("exit", "quit"):
                    # Auto-handoff: save project state before exiting
                    await _auto_handoff(app, config, make_model)
                    break

                if user_input == "/help":
                    ui.print_help()
                    continue

                if user_input == "/clear":
                    thread_id = str(uuid.uuid4())[:8]
                    config["configurable"]["thread_id"] = thread_id
                    cli_callback.reset_step_counter()
                    save_session(thread_id, model=active_model)
                    if tg:
                        tg.thread_id = thread_id
                    ui.print_info(f"Conversation cleared. New thread: {thread_id}")
                    continue

                if user_input == "/agents":
                    ui.print_agents(agent_configs)
                    continue

                if user_input.startswith("/skills"):
                    parts = user_input.split(maxsplit=2)
                    sub = parts[1] if len(parts) > 1 else "list"
                    arg = parts[2].strip() if len(parts) > 2 else ""

                    if sub == "list":
                        ui.print_skills(skills)
                    elif sub == "search":
                        from octo.skills_cli import _fetch_registry
                        query = arg
                        registry = _fetch_registry()
                        results = []
                        for entry in registry:
                            if query:
                                q = query.lower()
                                if not (q in entry["name"].lower()
                                        or q in entry.get("description", "").lower()
                                        or any(q in t.lower() for t in entry.get("tags", []))):
                                    continue
                            results.append(entry)
                        if not results:
                            ui.print_info("No skills found matching your query.")
                        else:
                            for entry in results:
                                tags = ", ".join(entry.get("tags", []))
                                ui.print_info(
                                    f"  {entry['name']:<20} v{entry.get('version', '?'):<8} "
                                    f"{tags[:25]:<26} {entry.get('description', '')[:40]}"
                                )
                            ui.print_info(f"{len(results)} skill(s) found.")
                    elif sub == "install" and arg:
                        from octo.skills_cli import (
                            _download_skill_files, _fetch_registry, _find_in_registry,
                            _install_deps,
                        )
                        skill_name = arg.split()[0]
                        registry = _fetch_registry()
                        entry = _find_in_registry(registry, skill_name)
                        if not entry:
                            ui.print_error(f"Skill '{skill_name}' not found. Try: /skills search")
                        else:
                            from octo.config import SKILLS_DIR
                            import shutil
                            dest = SKILLS_DIR / skill_name
                            if dest.exists():
                                shutil.rmtree(dest)
                            files = entry.get("files", ["SKILL.md"])
                            ui.print_info(f"Installing '{skill_name}' v{entry.get('version', '?')}...")
                            _download_skill_files(skill_name, files)
                            _install_deps(skill_name)
                            ui.print_info(f"Installed '{skill_name}'. Rebuilding graph...")
                            await _rebuild_graph()
                            ui.print_info(
                                f"Done. {len(skills)} skill(s) loaded."
                            )
                    elif sub == "remove" and arg:
                        from octo.config import SKILLS_DIR
                        import shutil
                        skill_name = arg.split()[0]
                        dest = SKILLS_DIR / skill_name
                        if not dest.is_dir():
                            ui.print_error(f"Skill '{skill_name}' is not installed.")
                        else:
                            shutil.rmtree(dest)
                            ui.print_info(f"Removed '{skill_name}'. Rebuilding graph...")
                            await _rebuild_graph()
                            ui.print_info(
                                f"Done. {len(skills)} skill(s) loaded."
                            )
                    elif sub == "import" and arg:
                        # /skills import <owner/repo> [skill-name]
                        # Installs globally via codex agent; CODEX_HOME points
                        # to .octo/ so skills land in .octo/skills/.
                        import asyncio as _aio
                        import shlex
                        from octo.skills_cli import parse_add_output, strip_ansi
                        tokens = shlex.split(arg.strip())
                        source = tokens[0]
                        cmd = ["npx", "skills", "add", source,
                               "-a", "codex", "-g", "-y"]
                        if len(tokens) > 1:
                            cmd.extend(["-s", *tokens[1:]])
                        ui.print_info(f"Importing from skills.sh: {source} ...")
                        proc = await _aio.create_subprocess_exec(
                            *cmd,
                            stdin=_aio.subprocess.DEVNULL,
                            stdout=_aio.subprocess.PIPE,
                            stderr=_aio.subprocess.STDOUT,
                        )
                        stdout, _ = await proc.communicate()
                        raw = stdout.decode(errors="replace").strip()
                        if proc.returncode == 0:
                            installed = parse_add_output(raw)
                            if installed:
                                ui.print_info(
                                    f"Installed {len(installed)} skill(s): "
                                    + ", ".join(installed)
                                )
                            else:
                                ui.print_info(strip_ansi(raw))
                            ui.print_info("Rebuilding graph...")
                            await _rebuild_graph()
                            ui.print_info(
                                f"Done. {len(skills)} skill(s) loaded."
                            )
                        else:
                            ui.print_error(
                                f"Import failed (exit {proc.returncode}). "
                                "Is Node.js installed?"
                            )
                    elif sub == "find":
                        import asyncio as _aio
                        from octo.skills_cli import (
                            parse_find_no_results, parse_find_output,
                        )
                        query = arg.strip()
                        if not query:
                            ui.print_error("Usage: /skills find <query>")
                        else:
                            ui.print_info(f"Searching skills.sh for '{query}'...")
                            proc = await _aio.create_subprocess_exec(
                                "npx", "skills", "find", query,
                                stdin=_aio.subprocess.DEVNULL,
                                stdout=_aio.subprocess.PIPE,
                                stderr=_aio.subprocess.STDOUT,
                            )
                            stdout, _ = await proc.communicate()
                            raw = stdout.decode(errors="replace").strip()
                            no_match = parse_find_no_results(raw)
                            if no_match:
                                ui.print_info(no_match)
                            else:
                                results = parse_find_output(raw)
                                if results:
                                    for r in results:
                                        ui.print_info(f"  {r['handle']}")
                                        if r["url"]:
                                            ui.print_info(f"    {r['url']}")
                                    ui.print_info(
                                        f"\n{len(results)} result(s). "
                                        "Install: /skills import <owner/repo> [skill-name]"
                                    )
                                else:
                                    ui.print_info("No results.")
                    else:
                        ui.print_error(
                            "Usage: /skills [list|search|install|remove|import|find]"
                        )
                    continue

                if user_input == "/tools":
                    ui.print_tools(mcp_tools_by_server)
                    continue

                if user_input.startswith("/mcp"):
                    from octo.mcp_manager import (
                        mcp_add_wizard, mcp_disable, mcp_enable, mcp_get_status,
                        mcp_install_wizard, mcp_registry_search, mcp_remove,
                    )
                    parts = user_input.split(maxsplit=2)
                    sub = parts[1] if len(parts) > 1 else ""
                    arg = parts[2].strip() if len(parts) > 2 else ""

                    if sub == "":
                        ui.print_mcp_status(mcp_get_status(mcp_tools_by_server))
                    elif sub == "reload":
                        ui.print_info("Reloading MCP servers and skills...")
                        await _rebuild_graph()
                        ui.print_info(
                            f"Reloaded: {len(mcp_tools)} tools from "
                            f"{len(mcp_tools_by_server)} server(s), "
                            f"{len(skills)} skills"
                        )
                    elif sub == "find":
                        query = arg.strip()
                        if not query:
                            ui.print_error("Usage: /mcp find <query>")
                        else:
                            try:
                                ui.print_info(f"Searching MCP registry for '{query}'...")
                                results = mcp_registry_search(query)
                                if not results:
                                    ui.print_info(f"No MCP servers found for '{query}'.")
                                else:
                                    ui.print_mcp_search_results(results, query)
                            except Exception as e:
                                ui.print_error(f"Registry search failed: {e}")
                    elif sub == "install":
                        if not arg:
                            ui.print_error("Usage: /mcp install <server-name>")
                            ui.print_info("Tip: use /mcp find <query> to search first.")
                        else:
                            name = mcp_install_wizard(arg.strip())
                            if name:
                                ui.print_info("Reloading MCP servers...")
                                await _rebuild_graph()
                                ui.print_info(
                                    f"Reloaded: {len(mcp_tools)} tools from "
                                    f"{len(mcp_tools_by_server)} server(s)"
                                )
                    elif sub == "add":
                        name = mcp_add_wizard()
                        if name:
                            ui.print_info("Reloading MCP servers...")
                            await _rebuild_graph()
                            ui.print_info(
                                f"Reloaded: {len(mcp_tools)} tools from "
                                f"{len(mcp_tools_by_server)} server(s)"
                            )
                    elif sub == "disable" and arg:
                        if mcp_disable(arg):
                            await _rebuild_graph()
                    elif sub == "enable" and arg:
                        if mcp_enable(arg):
                            await _rebuild_graph()
                    elif sub == "remove" and arg:
                        if mcp_remove(arg):
                            await _rebuild_graph()
                    else:
                        ui.print_error(
                            "Usage: /mcp [find <query>|install <name>|add|remove <name>|"
                            "disable <name>|enable <name>|reload]"
                        )
                    continue

                if user_input.startswith("/call"):
                    # /call server_name tool_name {json_args}
                    # /call server_name tool_name  (no args)
                    # /call tool_name {json_args}  (search all servers)
                    # /call tool_name              (search all servers, no args)
                    import json as _json
                    raw = user_input[len("/call"):].strip()
                    if not raw:
                        ui.print_error("Usage: /call [server] <tool_name> [{\"arg\": \"value\"}]")
                        ui.print_info("Tip: use /tools to see available tool names")
                        continue

                    # Try to extract JSON args from the end
                    call_args: dict = {}
                    json_start = raw.find("{")
                    if json_start >= 0:
                        try:
                            call_args = _json.loads(raw[json_start:])
                            raw = raw[:json_start].strip()
                        except _json.JSONDecodeError as je:
                            ui.print_error(f"Invalid JSON args: {je}")
                            continue

                    tokens = raw.split()
                    tool = None
                    server_label = ""

                    if len(tokens) == 2:
                        # /call server tool
                        srv, tname = tokens
                        srv_tools = mcp_tools_by_server.get(srv, [])
                        tool = next((t for t in srv_tools if t.name == tname), None)
                        if not tool:
                            ui.print_error(f"Tool '{tname}' not found in server '{srv}'")
                            continue
                        server_label = srv
                    elif len(tokens) == 1:
                        # /call tool — search all servers
                        tname = tokens[0]
                        for srv, srv_tools in mcp_tools_by_server.items():
                            tool = next((t for t in srv_tools if t.name == tname), None)
                            if tool:
                                server_label = srv
                                break
                        if not tool:
                            ui.print_error(f"Tool '{tname}' not found in any server")
                            continue
                    else:
                        ui.print_error("Usage: /call [server] <tool_name> [{\"arg\": \"value\"}]")
                        continue

                    ui.print_info(f"Calling {server_label}/{tool.name}...")
                    try:
                        result = await tool.ainvoke(call_args)
                        ui.print_response(str(result), source=f"{server_label}/{tool.name}")
                    except Exception as e:
                        ui.print_error(f"Tool error: {e}")
                    continue

                if user_input == "/projects":
                    ui.print_projects()
                    continue

                if user_input.startswith("/sessions"):
                    parts = user_input.split(maxsplit=1)
                    if len(parts) > 1:
                        thread_id = parts[1].strip()
                        config["configurable"]["thread_id"] = thread_id
                        cli_callback.reset_step_counter()
                        save_session(thread_id, model=active_model)
                        if tg:
                            tg.thread_id = thread_id
                        ui.print_info(f"Switched to session: {thread_id}")
                    else:
                        ui.print_sessions(current_thread=thread_id)
                    continue

                if user_input == "/plan":
                    from octo.graph import _todos
                    ui.print_plan(_todos)
                    continue

                if user_input.startswith("/voice"):
                    arg = user_input.split(maxsplit=1)[1] if " " in user_input else ""
                    if arg == "on":
                        voice_mod.toggle_voice(True)
                    elif arg == "off":
                        voice_mod.toggle_voice(False)
                    else:
                        voice_mod.toggle_voice()
                    ui.print_info(f"Voice: {'on' if voice_mod.is_enabled() else 'off'}")
                    continue

                if user_input.startswith("/model"):
                    parts = user_input.split(maxsplit=1)
                    if len(parts) > 1:
                        ui.print_info(f"Model switching requires restart. Set DEFAULT_MODEL={parts[1]} in .env")
                    else:
                        ui.print_info(f"Current model: {active_model}")
                    continue

                if user_input == "/compact":
                    try:
                        from langchain_core.messages import RemoveMessage, SystemMessage
                        from langchain_core.messages.utils import count_tokens_approximately

                        state = await app.aget_state(config)
                        messages = state.values.get("messages", [])
                        if len(messages) < 6:
                            ui.print_info("Conversation too short to compact.")
                            continue

                        before_tokens = count_tokens_approximately(messages)

                        # Keep last ~33% of messages by count (minimum 4)
                        keep_count = max(4, len(messages) // 3)
                        old_msgs = messages[:-keep_count]
                        recent_msgs = messages[-keep_count:]

                        if not old_msgs:
                            ui.print_info("Nothing to compact.")
                            continue

                        # Count removable messages (those with valid IDs)
                        removable = [m for m in old_msgs if getattr(m, "id", None)]
                        if not removable:
                            ui.print_info("No removable messages found (missing IDs).")
                            continue

                        # Summarize old messages via low-tier LLM
                        summary_model = make_model(tier="low")
                        summary_lines = []
                        for m in old_msgs:
                            role = getattr(m, "type", "unknown")
                            content = m.content if isinstance(m.content, str) else str(m.content)
                            if content.strip():
                                summary_lines.append(f"[{role}]: {content[:300]}")
                        summary_prompt = (
                            "Summarize this conversation concisely in 2-3 paragraphs. "
                            "Focus on: decisions made, tasks completed, and current objectives.\n\n"
                            + "\n".join(summary_lines[-100:])  # cap to avoid huge prompts
                        )
                        ui.print_info("Summarizing conversation...")
                        summary_response = await summary_model.ainvoke(summary_prompt)
                        summary_msg = SystemMessage(
                            content=(
                                "[Conversation summary — earlier messages were compacted]\n\n"
                                + summary_response.content
                            )
                        )

                        # Remove old messages and prepend summary
                        remove_ops = [RemoveMessage(id=m.id) for m in removable]
                        await app.aupdate_state(config, {"messages": remove_ops + [summary_msg]})

                        after_tokens = count_tokens_approximately([summary_msg] + recent_msgs)
                        ui.print_info(
                            f"Compacted: {before_tokens:,} -> {after_tokens:,} tokens "
                            f"({len(messages)} -> {len(recent_msgs) + 1} messages, "
                            f"{len(removable)} removed)"
                        )
                    except Exception as e:
                        ui.print_error(f"Compact failed: {e}")
                        if verbose or debug:
                            logger.exception("Compact error")
                    continue

                if user_input == "/context":
                    from octo.graph import context_info
                    used = context_info.get("used", 0)
                    limit = context_info.get("limit", 200_000)
                    pct = (used / limit * 100) if limit > 0 else 0
                    if pct < 30:
                        color, label = "green", "PEAK"
                    elif pct < 50:
                        color, label = "cyan", "GOOD"
                    elif pct < 70:
                        color, label = "yellow", "DEGRADING"
                    else:
                        color, label = "red", "POOR"
                    bar_len = 30
                    filled = int(bar_len * pct / 100)
                    bar = "\u2588" * filled + "\u2591" * (bar_len - filled)
                    usage = cli_callback.get_context_usage()
                    ui.console.print(
                        f"  Context: [{color}]{bar}[/{color}] {pct:.0f}% "
                        f"({used:,}/{limit:,} tokens) [{color}]{label}[/{color}]"
                    )
                    ui.console.print(
                        f"  Session: {usage['total_input']:,} input + "
                        f"{usage['total_output']:,} output tokens"
                    )
                    continue

                if user_input.startswith("/profile"):
                    from octo.config import get_active_profile, set_active_profile, BUILTIN_PROFILES
                    parts = user_input.split(maxsplit=1)
                    if len(parts) > 1:
                        name = parts[1].strip()
                        if set_active_profile(name):
                            ui.print_info(f"Switched to '{name}' profile. Takes full effect on restart.")
                        else:
                            available = ", ".join(BUILTIN_PROFILES.keys())
                            ui.print_error(f"Unknown profile '{name}'. Available: {available}")
                    else:
                        current = get_active_profile()
                        ui.print_info(f"Active profile: {current}")
                        for name, tiers in BUILTIN_PROFILES.items():
                            marker = " *" if name == current else "  "
                            ui.print_info(
                                f"{marker}{name}: supervisor={tiers['supervisor']}, "
                                f"workers={tiers['worker_default']}, "
                                f"high-tier={tiers['worker_high_keywords']}"
                            )
                    continue

                if user_input == "/state":
                    from octo.config import STATE_PATH
                    if STATE_PATH.is_file():
                        content = STATE_PATH.read_text(encoding="utf-8").strip()
                        if content:
                            ui.print_markdown(content)
                        else:
                            ui.print_info("STATE.md is empty. The agent will update it during work.")
                    else:
                        ui.print_info("No project state saved yet. STATE.md will be created during work.")
                    continue

                if user_input.startswith("/memory"):
                    from octo.config import MEMORY_DIR, PERSONA_DIR
                    parts = user_input.split(maxsplit=1)
                    sub = parts[1].strip() if len(parts) > 1 else ""

                    if sub == "long":
                        # Show long-term curated memory
                        ltm_path = PERSONA_DIR / "MEMORY.md"
                        if ltm_path.is_file():
                            ui.print_markdown(ltm_path.read_text(encoding="utf-8"))
                        else:
                            ui.print_info("No long-term memory yet.")
                    elif sub == "daily":
                        # Show recent daily logs
                        ui.print_daily_memories(MEMORY_DIR, days=7)
                    else:
                        # Default: show both
                        ltm_path = PERSONA_DIR / "MEMORY.md"
                        if ltm_path.is_file():
                            content = ltm_path.read_text(encoding="utf-8").strip()
                            if content:
                                ui.console.print("[bold cyan]Long-term Memory[/bold cyan]")
                                ui.print_markdown(content)
                        ui.print_daily_memories(MEMORY_DIR, days=5)
                    continue

                if user_input.startswith("/heartbeat"):
                    parts = user_input.split(maxsplit=1)
                    sub = parts[1].strip() if len(parts) > 1 else ""
                    if sub == "test":
                        ui.print_info("Forcing heartbeat tick...")
                        await heartbeat.force_tick()
                    else:
                        ui.print_info(
                            f"Heartbeat: every {heartbeat.interval // 60}m, "
                            f"active {heartbeat.active_start.strftime('%H:%M')}-"
                            f"{heartbeat.active_end.strftime('%H:%M')}"
                        )
                        instructions = heartbeat._load_heartbeat_instructions()
                        if instructions:
                            ui.print_info(f"HEARTBEAT.md: {len(instructions.splitlines())} active lines")
                        else:
                            ui.print_info("HEARTBEAT.md: empty (heartbeat will skip)")
                    continue

                if user_input.startswith("/cron"):
                    parts = user_input.split(maxsplit=2)
                    sub = parts[1] if len(parts) > 1 else "list"
                    arg = parts[2].strip() if len(parts) > 2 else ""

                    if sub == "list":
                        jobs = cron_store.load()
                        if not jobs:
                            ui.print_info("No scheduled tasks. Use /cron add or ask me to schedule something.")
                        else:
                            ui.print_cron_jobs(jobs)
                    elif sub == "add":
                        if not arg:
                            ui.print_error("Usage: /cron add <at|every|cron> <spec> <task>")
                            ui.print_info("  /cron add at in_2h Remind me to review the PR")
                            ui.print_info("  /cron add every 30m Check for new emails")
                            ui.print_info("  /cron add cron '0 9 * * MON-FRI' Morning briefing")
                        else:
                            cron_parts = arg.split(maxsplit=2)
                            if len(cron_parts) < 3:
                                ui.print_error("Usage: /cron add <type> <spec> <task>")
                            else:
                                from octo.heartbeat import CronJob, CronJobType, _parse_at_time, _parse_interval_td, _next_cron_run
                                import uuid as _uuid
                                from datetime import datetime as _dt, timezone as _tz
                                cron_type_str, cron_spec, cron_task = cron_parts
                                try:
                                    cron_type = CronJobType(cron_type_str)
                                    now = _dt.now(_tz.utc)
                                    if cron_type == CronJobType.AT:
                                        next_run = _parse_at_time(cron_spec)
                                    elif cron_type == CronJobType.EVERY:
                                        delta = _parse_interval_td(cron_spec)
                                        next_run = now + delta
                                    elif cron_type == CronJobType.CRON:
                                        next_run = _next_cron_run(cron_spec, now)
                                    else:
                                        raise ValueError(f"Unknown type: {cron_type_str}")
                                    job = CronJob(
                                        id=str(_uuid.uuid4())[:8],
                                        task=cron_task,
                                        type=cron_type,
                                        spec=cron_spec,
                                        created_at=now.isoformat(),
                                        next_run=next_run.isoformat(),
                                    )
                                    cron_store.add(job)
                                    ui.print_info(
                                        f"Scheduled [{job.id}]: '{cron_task}' — "
                                        f"next run at {next_run.strftime('%Y-%m-%d %H:%M UTC')}"
                                    )
                                except (ValueError, KeyError) as e:
                                    ui.print_error(f"Invalid cron spec: {e}")
                    elif sub == "remove":
                        if not arg:
                            ui.print_error("Usage: /cron remove <job_id>")
                        elif cron_store.remove(arg):
                            ui.print_info(f"Removed cron job: {arg}")
                        else:
                            ui.print_error(f"Job not found: {arg}")
                    elif sub in ("pause", "resume"):
                        if not arg:
                            ui.print_error(f"Usage: /cron {sub} <job_id>")
                        else:
                            result = cron_store.toggle_pause(arg)
                            if result is None:
                                ui.print_error(f"Job not found: {arg}")
                            else:
                                state_str = "paused" if result else "resumed"
                                ui.print_info(f"Job {arg}: {state_str}")
                    else:
                        ui.print_error("Usage: /cron [list|add|remove|pause|resume]")
                    continue

                if user_input.startswith("/vp"):
                    from octo.virtual_persona.commands import handle_vp_command
                    vp_args = user_input[3:].strip()
                    await handle_vp_command(
                        vp_args,
                        vp_poller=locals().get("vp_poller"),
                        octo_app=app,
                        octo_config=config,
                    )
                    continue

                if user_input == "/create-agent":
                    from octo.agent_wizard import create_agent_wizard
                    result = await create_agent_wizard(mcp_tools_by_server)
                    if result:
                        ui.print_info(f"Agent '{result}' created. Rebuilding graph...")
                        await _rebuild_graph()
                        ui.print_info(f"Done. {len(agent_configs)} agent(s) loaded.")
                    continue

                # Check for skill or agent invocation
                if user_input.startswith("/"):
                    cmd_name = user_input.split()[0][1:]  # strip /
                    skill = next((s for s in skills if s.name == cmd_name), None)
                    if skill:
                        args = user_input[len(cmd_name) + 2:].strip()
                        injected = f"[Skill: {skill.name}]\n\n{skill.body}"
                        if args:
                            injected += f"\n\nUser request: {args}"
                        # Progressive disclosure: list available references and scripts
                        if skill.references or skill.scripts:
                            injected += "\n\n---\n**Bundled resources** (use Read/Bash tools to access on demand):"
                            if skill.references:
                                injected += "\nReference docs:"
                                for ref in skill.references:
                                    injected += f"\n- `{skill.skill_dir}/{ref}`"
                            if skill.scripts:
                                injected += "\nScripts:"
                                for scr in skill.scripts:
                                    injected += f"\n- `{skill.skill_dir}/{scr}`"
                        user_input = injected
                    elif next((a for a in agent_configs if a.name == cmd_name), None):
                        # Direct agent invocation — route to specific agent
                        prompt = user_input[len(cmd_name) + 2:].strip()
                        if not prompt:
                            ui.print_error(f"Usage: /{cmd_name} <your request>")
                            continue
                        user_input = (
                            f"[IMPORTANT: Route this request directly to the "
                            f"'{cmd_name}' agent. Do not delegate to any other "
                            f"agent.]\n\n{prompt}"
                        )
                    else:
                        ui.print_error(f"Unknown command: {user_input}")
                        continue

                # --- Invoke graph ---
                # Merge Ctrl+V pasted attachments with any detected file paths
                from octo.attachments import process_user_input as _process_attachments
                from octo.attachments import process_pasted_attachments
                pasted = ui.get_pending_attachments()
                if pasted:
                    msg_content, uploaded = process_pasted_attachments(user_input, pasted)
                else:
                    msg_content, uploaded = _process_attachments(user_input)
                if uploaded:
                    names = [p.rsplit("/", 1)[-1] for p in uploaded]
                    ui.print_info(f"Attached: {', '.join(names)}")

                # Update session with latest user message preview
                preview_text = user_input if isinstance(msg_content, str) else user_input
                save_session(thread_id, preview=preview_text, model=active_model)

                try:
                    # Start thinking spinner — callback will stop it on first tool call
                    spinner_text = "[yellow]Thinking...[/yellow]"
                    if cli_callback.active_task:
                        spinner_text = f"[yellow]Working on: {cli_callback.active_task}[/yellow]"
                    status = ui.console.status(spinner_text, spinner="dots")
                    status.start()
                    cli_callback.status = status

                    try:
                        from octo.abort import esc_listener
                        from octo.retry import invoke_with_retry

                        async def _on_retry(msg: str, attempt: int) -> None:
                            try:
                                status.update(f"[yellow]{msg}[/yellow]")
                            except Exception:
                                pass

                        abort_event = asyncio.Event()
                        async with graph_lock:
                            invoke_task = asyncio.create_task(
                                invoke_with_retry(
                                    app,
                                    {"messages": [HumanMessage(content=msg_content)]},
                                    config,
                                    on_retry=_on_retry,
                                )
                            )
                            async with esc_listener(abort_event):
                                abort_waiter = asyncio.create_task(abort_event.wait())
                                done, _ = await asyncio.wait(
                                    {invoke_task, abort_waiter},
                                    return_when=asyncio.FIRST_COMPLETED,
                                )

                                if abort_event.is_set():
                                    invoke_task.cancel()
                                    try:
                                        await invoke_task
                                    except asyncio.CancelledError:
                                        pass
                                    result = None
                                else:
                                    abort_waiter.cancel()
                                    result = invoke_task.result()
                    finally:
                        # Ensure spinner is stopped
                        try:
                            status.stop()
                        except Exception:
                            pass

                    if result is None:
                        ui.print_info("Aborted.")
                    else:
                        # Extract last AI response
                        response_text = ""
                        for msg in reversed(result.get("messages", [])):
                            if hasattr(msg, "type") and msg.type == "ai" and msg.content:
                                response_text = msg.content
                                break

                        if response_text:
                            ui.print_response(response_text)

                            if voice_mod.is_enabled():
                                await voice_mod.speak(response_text)

                except KeyboardInterrupt:
                    ui.print_info("\nInterrupted. Type 'exit' to quit.")
                except Exception as e:
                    error_str = str(e).lower()
                    if "timeout" in error_str or "timed out" in error_str:
                        ui.print_error("Request timed out. Try again — it may be a transient issue.")
                    elif "rate limit" in error_str or "throttling" in error_str:
                        ui.print_error("Rate limited. Wait a moment and try again.")
                    elif "too long" in error_str or "context length" in error_str:
                        ui.print_error("Context too long. Use /compact to free space, or /clear to reset.")
                    else:
                        ui.print_error(f"Error: {e}")
                    if verbose or debug:
                        logger.exception("Graph invocation error")

        finally:
            await heartbeat.stop()
            await cron_scheduler.stop()
            if vp_poller is not None:
                vp_poller.stop()
            if tg:
                await tg.stop()
            ui.print_info("Goodbye!")

    finally:
        await session_pool.close_all()
