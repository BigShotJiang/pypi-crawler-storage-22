# octobatch-cli
Batch LLM orchestration tool.

**This is a placeholder package.** The full release is coming soon.

See the [GitHub repository](https://github.com/andrewstellman/octobatch) for the development version.
