"""Octobatch - Batch LLM orchestration tool. Full release coming soon."""
__version__ = "0.0.1"
