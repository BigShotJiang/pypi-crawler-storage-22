# Contributors

## Authors
- Andreas Wurl (Merck Healthcare KGaA, Darmstadt, Germany), [:material-github: Github](https://github.com/anwurl)
- Nils Haase (Merck KGaA, Darmstadt, Germany), [:material-github: Github](https://github.com/nihaase)


## Contributors
- Kathrin Skubch (Merck KGaA, Darmstadt, Germany) [:material-github: Github](https://github.com/kalama-ai)
- Mathias Winkel (Merck KGaA, Darmstadt, Germany) [:material-github: Github](https://github.com/dasmy)
- Alexander V. Hopp (Merck KGaA, Darmstadt, Germany) [:material-github: Github](https://github.com/AVHopp)
- Abhijna Shridhara Hebbar (Merck Healthcare KGaA, Darmstadt, Germany) [:material-github: Github](https://github.com/abhebbar)
