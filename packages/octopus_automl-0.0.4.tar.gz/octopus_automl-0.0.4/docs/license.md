# Octopus License Terms

--8<-- "LICENSE.txt"
