# Command Line Interface

Current functionality:

* `octopus examples --list` lists available examples.
* `octopus examples <number|filename>` opens that example in Jupyter.
* `octopus examples` opens Jupyter on the examples directory.

Falls back to help output for other commands.
