"""Time to event metrics."""

# Time-to-event metric support is currently disabled. This module is kept as a
# placeholder and will be re-enabled with a full implementation in the future.
