"""Time to event models."""

# NOTE: Time-to-event model support is currently disabled.
# This module is kept as a placeholder and will be reimplemented in the future.
