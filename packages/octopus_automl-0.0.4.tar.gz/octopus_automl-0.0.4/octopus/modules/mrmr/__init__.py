"""Init Mrmr."""

from .core import MrmrCore  # type: ignore
from .module import Mrmr

__all__ = ["Mrmr", "MrmrCore"]
