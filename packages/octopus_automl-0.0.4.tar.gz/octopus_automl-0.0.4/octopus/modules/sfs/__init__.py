"""Init."""

from .core import SfsCore  # type: ignore
from .module import Sfs

__all__ = ["Sfs", "SfsCore"]
