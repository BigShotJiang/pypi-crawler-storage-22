"""Task module."""

from .core import Task

__all__ = ["Task"]
