"""Test model inventory."""
