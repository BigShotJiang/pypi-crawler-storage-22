"""Autogluon module tests."""
