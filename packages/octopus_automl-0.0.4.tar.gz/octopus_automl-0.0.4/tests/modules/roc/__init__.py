"""ROC module tests."""
