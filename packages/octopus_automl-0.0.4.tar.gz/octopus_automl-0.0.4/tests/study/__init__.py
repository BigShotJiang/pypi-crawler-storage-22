"""Tests for the study module."""
