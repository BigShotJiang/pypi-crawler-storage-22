"""Octorules — Manage Cloudflare Rules as IaC."""

__version__ = "0.1.0"
