"""Configuration loading and env/ resolution."""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

log = logging.getLogger("octorules")

_ZONE_ID_RE = re.compile(r"^[0-9a-f]{32}$")


class ConfigError(Exception):
    """Raised when configuration is invalid."""


def _make_include_loader(base_path: Path, visited: set[Path]) -> type:
    """Create a YAML loader subclass with !include support.

    Args:
        base_path: Directory to resolve relative include paths against.
        visited: Set of already-visited file paths for circular include detection.
    """

    class IncludeLoader(yaml.SafeLoader):
        pass

    def _include_constructor(loader: yaml.SafeLoader, node: yaml.Node) -> object:
        rel_path = loader.construct_scalar(node)
        include_path = (base_path / rel_path).resolve()
        if include_path in visited:
            raise ConfigError(f"Circular include detected: {include_path}")
        if not include_path.exists():
            raise ConfigError(f"Include file not found: {include_path}")
        return _yaml_load(include_path, visited)

    IncludeLoader.add_constructor("!include", _include_constructor)
    return IncludeLoader


def _yaml_load(path: Path, visited: set[Path] | None = None) -> object:
    """Load a YAML file with !include directive support."""
    path = path.resolve()
    if visited is None:
        visited = set()
    visited = visited | {path}
    loader_cls = _make_include_loader(path.parent, visited)
    try:
        with open(path, encoding="utf-8") as f:
            return yaml.load(f, Loader=loader_cls)
    except yaml.YAMLError as e:
        raise ConfigError(f"Invalid YAML in {path}: {e}") from e


def resolve_value(value: str) -> str:
    """Resolve a value, expanding env/ prefix to environment variable."""
    if isinstance(value, str) and value.startswith("env/"):
        env_var = value[4:]
        result = os.environ.get(env_var)
        if result is None:
            raise ConfigError(f"Environment variable {env_var!r} is not set (from {value!r})")
        return result
    return value


def _validate_safety(
    delete_threshold: float, update_threshold: float, min_existing: int, context: str
) -> None:
    """Validate safety threshold values."""
    if not 0 <= delete_threshold <= 100:
        raise ConfigError(
            f"'{context}.delete_threshold' must be between 0 and 100 (got {delete_threshold})"
        )
    if not 0 <= update_threshold <= 100:
        raise ConfigError(
            f"'{context}.update_threshold' must be between 0 and 100 (got {update_threshold})"
        )
    if min_existing < 0:
        raise ConfigError(f"'{context}.min_existing' must be >= 0 (got {min_existing})")


@dataclass
class ZoneConfig:
    name: str
    zone_id: str
    always_dry_run: bool = False
    allow_unmanaged: bool = False
    delete_threshold: float = 30.0
    update_threshold: float = 30.0
    min_existing: int = 3


def _parse_zone(
    zone_name: str,
    zone_data: object,
    global_delete_threshold: float,
    global_update_threshold: float,
    global_min_existing: int,
) -> ZoneConfig:
    """Parse a single zone entry from the config file."""
    if not isinstance(zone_data, dict):
        raise ConfigError(f"Zone {zone_name!r} must be a mapping")
    raw_zone_id = zone_data.get("zone_id")
    if not raw_zone_id:
        raise ConfigError(f"Zone {zone_name!r} missing 'zone_id'")
    zone_id = resolve_value(raw_zone_id)
    if not _ZONE_ID_RE.match(zone_id):
        raise ConfigError(
            f"Zone {zone_name!r} has invalid zone_id {zone_id!r} (expected 32 hex characters)"
        )
    always_dry_run = bool(zone_data.get("always_dry_run", False))
    allow_unmanaged = bool(zone_data.get("allow_unmanaged", False))

    # Per-zone safety overrides
    zone_safety = zone_data.get("safety", {})
    if zone_safety is None:
        zone_safety = {}
    if not isinstance(zone_safety, dict):
        raise ConfigError(f"'zones.{zone_name}.safety' must be a mapping")
    delete_threshold = float(zone_safety.get("delete_threshold", global_delete_threshold))
    update_threshold = float(zone_safety.get("update_threshold", global_update_threshold))
    min_existing = int(zone_safety.get("min_existing", global_min_existing))
    _validate_safety(delete_threshold, update_threshold, min_existing, f"zones.{zone_name}.safety")

    return ZoneConfig(
        name=zone_name,
        zone_id=zone_id,
        always_dry_run=always_dry_run,
        allow_unmanaged=allow_unmanaged,
        delete_threshold=delete_threshold,
        update_threshold=update_threshold,
        min_existing=min_existing,
    )


@dataclass
class Config:
    token: str
    rules_dir: Path
    zones: dict[str, ZoneConfig] = field(default_factory=dict)
    max_workers: int = 1
    max_retries: int = 2
    timeout: float | None = None

    @classmethod
    def from_file(cls, path: str | Path) -> Config:
        """Load config from a YAML file."""
        path = Path(path)
        if not path.exists():
            raise ConfigError(f"Config file not found: {path}")

        raw = _yaml_load(path)

        if not isinstance(raw, dict):
            raise ConfigError("Config file must be a YAML mapping")

        cf_section = raw.get("cloudflare", {})
        if not isinstance(cf_section, dict):
            raise ConfigError("'cloudflare' must be a mapping")

        raw_token = cf_section.get("token")
        if not raw_token:
            raise ConfigError("'cloudflare.token' is required")
        token = resolve_value(raw_token)

        max_retries = int(cf_section.get("max_retries", 2))
        if max_retries < 0:
            raise ConfigError("'cloudflare.max_retries' must be >= 0")

        raw_timeout = cf_section.get("timeout")
        if raw_timeout is not None:
            timeout = float(raw_timeout)
            if timeout <= 0:
                raise ConfigError("'cloudflare.timeout' must be > 0")
        else:
            timeout = None

        raw_rules_dir = raw.get("rules_dir", "./rules")
        rules_dir = (path.parent / raw_rules_dir).resolve()
        if not rules_dir.is_dir():
            log.warning("rules_dir does not exist: %s", rules_dir)

        # Global safety defaults
        global_safety = raw.get("safety", {})
        if global_safety is None:
            global_safety = {}
        if not isinstance(global_safety, dict):
            raise ConfigError("'safety' must be a mapping")
        global_delete_threshold = float(global_safety.get("delete_threshold", 30.0))
        global_update_threshold = float(global_safety.get("update_threshold", 30.0))
        global_min_existing = int(global_safety.get("min_existing", 3))
        _validate_safety(
            global_delete_threshold, global_update_threshold, global_min_existing, "safety"
        )

        zones: dict[str, ZoneConfig] = {}
        raw_zones = raw.get("zones", {})
        if not isinstance(raw_zones, dict):
            raise ConfigError("'zones' must be a mapping")

        for zone_name, zone_data in raw_zones.items():
            zones[zone_name] = _parse_zone(
                zone_name,
                zone_data,
                global_delete_threshold,
                global_update_threshold,
                global_min_existing,
            )

        # Manager section
        manager_section = raw.get("manager", {})
        if manager_section is None:
            manager_section = {}
        if not isinstance(manager_section, dict):
            raise ConfigError("'manager' must be a mapping")
        max_workers = int(manager_section.get("max_workers", 1))
        if max_workers < 1:
            raise ConfigError("'manager.max_workers' must be >= 1")

        return cls(
            token=token,
            rules_dir=rules_dir,
            zones=zones,
            max_workers=max_workers,
            max_retries=max_retries,
            timeout=timeout,
        )

    def load_zone_rules(self, zone_name: str) -> dict:
        """Load the rules YAML file for a given zone."""
        rules_file = self.rules_dir / f"{zone_name}.yaml"
        if not rules_file.exists():
            log.debug("No rules file for zone %s (expected %s)", zone_name, rules_file)
            return {}
        data = _yaml_load(rules_file)
        if not isinstance(data, dict):
            raise ConfigError(
                f"Rules file {rules_file} is not a YAML mapping (got {type(data).__name__})"
            )
        return data
