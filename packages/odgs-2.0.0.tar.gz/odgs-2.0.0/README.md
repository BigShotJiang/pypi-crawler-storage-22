# ODGS: Open Data Governance Standard
### The Sovereign Engine for Semantic Integrity in High-Risk AI Systems

> **Legal Reference**: Compliant with **Regulation (EU) 2024/1689 (EU AI Act)**, Article 10 (Data Governance) and Article 12 (Record-Keeping).

![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)
![Status](https://img.shields.io/badge/Status-Reference_Implementation-green.svg)
![Compliance](https://img.shields.io/badge/Compliance-EU_AI_Act_High_Risk-yellow.svg)

## 1. Abstract
The Open Data Governance Standard (ODGS) is a vendor-neutral protocol for the **cryptographic enforcement of Semantic Integrity**. 

Unlike traditional catalogs that passively observe data metadata, ODGS functions as a **Runtime Interceptor (Firewall)**. It binds data payloads to their legal definitions at the millisecond of execution, throwing a `ProcessBlockedException` (Hard Stop) if Semantic Integrity is violated.

This repository serves as the **Reference Implementation** for transforming "Paper Governance" into "Code Governance."

## 2. The 3-Plane Architecture Strategy
ODGS enforces the separation of powers required by sovereign data ecosystems:

1.  **🏛️ Legislative Plane (Definitions)**: Standard Metrics and Terms (e.g., "Net Profit Margin"). Defined in `standard_metrics.json`.
2.  **⚖️ Judiciary Plane (Rules)**: Validation Logic and Norms (e.g., "ISO 6346 Container ID"). Defined in `standard_data_rules.json`.
3.  **⚔️ Executive Plane (Enforcement)**: Runtime Blocking of non-compliant processes. Defined in `business_process_maps.json`.

## 3. Reference Artifacts (Strict Liability)
This repository contains critical artifacts for regulatory compliance:

| Artifact | Function | EU AI Act Article |
| :--- | :--- | :--- |
| `odgs/interceptor.py` | **Middleware**. Hashes input data and blocks execution on rule failure. | Art. 10 (Governance) |
| `schemas/audit_log_v1.json` | **Forensics**. JSON Schema for immutable audit trails. | Art. 12 (Logs) |
| `examples/configurations/` | **Context**. Defines "Safety Critical" tolerances vs "Reporting" tolerances. | Annex III (High-Risk) |
| `integrations/` | **LLM Bridge**. LangChain adapter for RAG Agents. | Art. 50 (Transparency) |

## 4. Installation & Usage

ODGS serves two ecosystems: **Python (Data/AI)** and **Node.js (Web/App)**.

### A. The Sovereign Engine (Python)
**Package**: `pip install odgs`
**Role**: The complete enforcement engine. Includes the Interceptor (Logic), CLI, and Agent.

```python
from odgs.interceptor import OdgsInterceptor, ProcessBlockedException

# 1. Initialize the Sovereign Guard
guard = OdgsInterceptor()

# 2. Intercept Data Flow
try:
    guard.intercept(
        process_urn="urn:odgs:process:O2C_S03", 
        data_context={"container_id": "INVALID 123"}
    )
except ProcessBlockedException as e:
    # 3. FAILURE IS MANDATORY
    print("⛔ HARD STOP: Transaction Blocked by Sovereign Law.")
    sys.exit(1)
```

### B. The Universal Engine (NPM)
**Package**: `npm install odgs`
**Role**: The "Law Book" + "Enforcer". Now includes the Runtime Interceptor for Node.js apps.

```javascript
import { OdgsInterceptor, ProcessBlockedException } from 'odgs';

const guard = new OdgsInterceptor();

try {
  guard.intercept(
    "urn:odgs:process:O2C_S03", 
    { container_id: "BAD_ID" }
  );
} catch (e) {
  if (e instanceof ProcessBlockedException) {
    console.error("⛔ JS HARD STOP: Blocked by ODGS.");
  }
}
```

## 5. The Agentic Forge
Includes a `google-genai` powered CLI tool to instantly generate compliance bundles for new industries.

```bash
# Generate a full ISO-compliant protocol for Pharmaceutical Supply Chains
odgs agent generate "Pharmaceutical Logistics" --api-key $GEMINI_API_KEY
```

---
**Standard Body**: Maintained by the **Metric Provenance** 
**Version**: 2.0.0 (Sovereign Release)