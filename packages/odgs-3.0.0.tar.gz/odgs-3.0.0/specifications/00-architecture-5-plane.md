# ODGS Specifications: 00 - The 5-Plane Architecture

**Status:** ISO/IEC 42001 Candidate Standard
**Version:** 3.0.0

## 1. Abstract
The ODGS Standard defines a **Hierarchical Constitutional Stack** for Data Governance. It strictly separates the Definition of Data (Legislative) from the Execution of Data (Physical).

## 2. The Five Planes

### Plane 1: Legislative (The Definition)
*   **Role:** Defines the semantic truth.
*   **Artifact:** `01-metrics-schema.json`
*   **Immutability:** MUST be cryptographically hashed.

### Plane 2: Judiciary (The Enforcer)
*   **Role:** Validates data against the Legislative definition.
*   **Artifact:** `02-rules-schema.json`
*   **Mechanism:** "Hard Stop" (ProcessBlockedException).

### Plane 3: Executive (The Context)
*   **Role:** Maps definitions to business contexts.
*   **Artifact:** `runtime_config.json`

### Plane 4: System (The Interface)
*   **Role:** Manages I/O and user interaction.
*   **Artifact:** CLI / API definitions.

### Plane 5: Audit (The Record)
*   **Role:** Provides forensic evidence of compliance.
*   **Artifact:** `audit_log_schema.json` (Tri-Partite Binding).

## 3. Normative References
*   **EU AI Act**: Article 10 (Governance), Article 12 (Logging).
*   **ISO/IEC 42001**: Control B.7 (Data Management).
