This module simply provides a date range type marked as 'Fiscal month'.
