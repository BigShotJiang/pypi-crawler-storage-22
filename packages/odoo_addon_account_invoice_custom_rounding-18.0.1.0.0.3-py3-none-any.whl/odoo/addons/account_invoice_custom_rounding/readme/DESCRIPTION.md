This module allows to select a custom taxes rounding method in invoices.
