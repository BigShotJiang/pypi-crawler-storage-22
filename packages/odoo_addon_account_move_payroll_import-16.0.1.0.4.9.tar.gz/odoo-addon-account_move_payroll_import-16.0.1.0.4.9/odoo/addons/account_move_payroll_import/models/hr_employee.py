# -*- coding: utf-8 -*-
from odoo import models, fields

class HrEmployee(models.Model):
    _inherit = "hr.employee"

    payroll_external_id = fields.Char(
        string="Payroll External ID",
        index=True,
        help="Identifier of the employee in the external payroll software (e.g. 19)."
    )
