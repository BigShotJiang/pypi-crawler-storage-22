import logging


from odoo import models, fields, api, _, Command
from odoo.exceptions import UserError
from ..utils.parse_utils import abs_float, parse_float

VALUE_ERROR_MSG = "Invalid value '%s' in column %s."

class PayrollImportLine(models.Model):
    _name = "payroll.import.line"
    _description = "Payroll Import Line Configuration"
    _order = "sequence, id"

    payroll_import_setup_id = fields.Many2one(
        comodel_name="payroll.import.setup",
        string="Import Setup",
        ondelete="cascade", 
        required=True
    )
    sequence = fields.Integer(string="Sequence", default=10)
    name = fields.Char(string="Label", required=True)
    code = fields.Char(
        string="Code", 
        help="Technical code used for specific validations (e.g. 'tc1_total', 'ss_company')."
    )
    column_index = fields.Integer(
        string="Column Index", 
        required=True, 
        help="Column number in the file (1-based)."
    )
    account_id = fields.Many2one(
        comodel_name="account.account",
        string="Account",
        help="Account where the amount will be booked."
    )
    tax_id = fields.Many2one(
        comodel_name="account.tax",
        string="Tax"
    )
    sign = fields.Selection(
        selection=[('debit', 'Debit'), ('credit', 'Credit')],
        string="Sign",
        required=True,
        default='debit',
        help="Indicates if the value should be added as Debit or Credit."
    )
    is_validation_only = fields.Boolean(
        string="Validation Only",
        default=False,
        help="If checked, this line will be read but not posted to the account move. "
             "Used for validation fields like TC1 total checks."
    )
    aggregate_lines = fields.Boolean(
        string="Aggregate to Single Line",
        default=False,
        help="If checked, all values for this concept will be aggregated into a single account move line "
             "(useful for summary lines like 'Total Gross Salary')."
    )
    
    
    
    @api.constrains('column_index')
    def _check_column_index(self):
        for record in self:
            if record.column_index < 1:
                raise UserError(_("Column index must be greater than or equal to 1."))


class PayrollImportSetup(models.Model):
    _name = "payroll.import.setup"
    _description = "Payroll Import Setup"
    _check_company_auto = True

    name = fields.Char(
        string="Name",
        default=_("Payroll Import"),
        required=True
    )
    company_id = fields.Many2one(
        string="Company",
        comodel_name="res.company",
        default=lambda self: self.env.company,
    )
    
    # File Configuration
    header_lines = fields.Integer(
        string="Header Lines", default=1, required=True
    )
    header_ref_line = fields.Integer(
        string="Ref. Line", default=1
    )
    encoding = fields.Selection(
        [("utf-8", "UTF-8"), ("latin1", "Latin1"), ("ascii", "ASCII")],
        string="Encoding", default="utf-8"
    )
    delimiter = fields.Selection(
        [(";", "Semicolon"), (",", "Comma"), ("\t", "Tab")],
        string="Delimiter", default=";"
    )
    thousands_delimiter = fields.Selection(
        [(".", "Dot (.)"), (",", "Comma (,)")], 
        string="Thousands Sep.", default=","
    )
    decimal_delimiter = fields.Selection(
        [(".", "Dot (.)"), (",", "Comma (,)")], 
        string="Decimal Sep.", default="."
    )

    # Core Logic Fields
    data_structure = fields.Selection(
        [("rows", "One Employee per Row"), ("columns", "One Employee per Column")],
        string="Data Structure",
        default="rows",
        required=True,
        help="Select the structure of the file.\n"
             "- One Employee per Row: Standard format. Each row is an employee.\n"
             "- One Employee per Column: Transposed format. Each column is an employee."
    )
    
    sheet_name = fields.Char(
        string="Sheet Name",
        help="Name of the Excel sheet to import (e.g., 'Detalle'). "
             "Leave empty to use the first sheet in the workbook."
    )
    
    journal_id = fields.Many2one(
        comodel_name="account.journal",
        string="Journal",
        help="Journal where moves will be posted."
    )
    column_employee_id = fields.Integer(
        string="Employee ID Column", required=True, default=1
    )
    
    # Dynamic Lines
    line_ids = fields.One2many(
        comodel_name="payroll.import.line",
        inverse_name="payroll_import_setup_id",
        string="Import Lines"
    )

    _sql_constraints = [
        ("name_company_uniq", "unique(name, company_id)", "Name must be unique per company.")
    ]

    def get_file_options(self):
        return {
            "encoding": self.encoding,
            "separator": self.delimiter,
            "float_thousand_separator": self.thousands_delimiter,
            "float_decimal_separator": self.decimal_delimiter,
            "header_lines": self.header_lines,
            "headers": False,
            "quoting": '"',
        }

    def _get_partner_id(self, employee_id_val):
        # 1. Search by NIF/Identification ID
        employee = self.env["hr.employee"].search(
            [("identification_id", "=", employee_id_val)], limit=1
        )
        # 2. Search by Payroll External ID
        if not employee:
            employee = self.env["hr.employee"].search(
                [("payroll_external_id", "=", employee_id_val)], limit=1
            )
        # 3. Search by Name (fallback) 
        if not employee:
             employee = self.env['hr.employee'].search([
                ('name', '=', employee_id_val)
            ], limit=1)
            
        if not employee:
            raise UserError(_("Employee with identification %s not found (NIF, Name, or External ID).") % employee_id_val)
        if not employee.address_home_id:
            raise UserError(_("Employee %s has no home address.") % employee.name)
        return employee.address_home_id.id
    
    def _validate_tc1(self, data):
        """
        Validate TC1 = SS Employee + SS Company for all employees.
        TC1 line should be marked as is_validation_only=True.
        """
        tc1_line = self.line_ids.filtered(lambda l: l.code == 'tc1_total')
        ss_emp_line = self.line_ids.filtered(lambda l: l.code == 'ss_employee')
        ss_comp_line = self.line_ids.filtered(lambda l: l.code == 'ss_company')
        ss_bonus_line = self.line_ids.filtered(lambda l: l.code == 'ss_bonus')
        
        if not (tc1_line and ss_emp_line and ss_comp_line):
            return  # Validation not configured
        
        cumulative = 0.0
        
        if self.data_structure == 'rows':
            for row in data:
                try:
                    tc1_val = abs_float(row[tc1_line.column_index - 1], self.thousands_delimiter, self.decimal_delimiter)
                    ss_emp_val = abs_float(row[ss_emp_line.column_index - 1], self.thousands_delimiter, self.decimal_delimiter)
                    ss_comp_val = abs_float(row[ss_comp_line.column_index - 1], self.thousands_delimiter, self.decimal_delimiter)
                    
                    ss_bonus_val = 0.0
                    if ss_bonus_line:
                        ss_bonus_val = abs_float(row[ss_bonus_line.column_index - 1], self.thousands_delimiter, self.decimal_delimiter)
                    
                    # TC1 = SS_Emp + SS_Comp - SS_Bonus
                    # Error = TC1 - (SS_Emp + SS_Comp - SS_Bonus)
                    cumulative += (tc1_val - (ss_emp_val + ss_comp_val - ss_bonus_val))
                except (IndexError, ValueError):
                    continue
        else:
            # Transposed mode
            num_columns = max(len(row) for row in data) if data else 0
            start_col = self.header_lines
            
            # Column Dump for Mapping Debug
            if data and len(data) > 0 and num_columns > start_col:
                debug_col = start_col  # First data column
                import logging
                _logging = logging.getLogger(__name__)
                dump = []
                for r_idx, row in enumerate(data):
                    val = row[debug_col] if len(row) > debug_col else "N/A"
                    dump.append(f"Row {r_idx+1}: {val}")
                _logging.warning("XLS Mapping Debug - Col %s Dump:\n%s", debug_col, "\n".join(dump))

            for col_idx in range(start_col, num_columns):
                try:
                    tc1_val = abs_float(data[tc1_line.column_index - 1][col_idx], self.thousands_delimiter, self.decimal_delimiter)
                    ss_emp_val = abs_float(data[ss_emp_line.column_index - 1][col_idx], self.thousands_delimiter, self.decimal_delimiter)
                    ss_comp_val = abs_float(data[ss_comp_line.column_index - 1][col_idx], self.thousands_delimiter, self.decimal_delimiter)
                    
                    ss_bonus_val = 0.0
                    if ss_bonus_line:
                        ss_bonus_val = abs_float(data[ss_bonus_line.column_index - 1][col_idx], self.thousands_delimiter, self.decimal_delimiter)

                    # TC1 = SS_Emp + SS_Comp - SS_Bonus
                    diff = tc1_val - (ss_emp_val + ss_comp_val - ss_bonus_val)
                    cumulative += diff
                    
                    # Log first few errors for debugging
                    if abs(diff) > 0.01:
                        import logging
                        _logging = logging.getLogger(__name__)
                        _logging.warning(
                            f"TC1 Debug [Col {col_idx}]: TC1={tc1_val}, SS_Emp={ss_emp_val}, SS_Comp={ss_comp_val}, Bonus={ss_bonus_val}. Diff={diff}"
                        )
                except (IndexError, ValueError):
                    continue
        
        if abs(cumulative) > 0.01:
             import logging
             _logging = logging.getLogger(__name__)
             _logging.warning(f"TC1 Validation Details: Total Cumulative Error = {cumulative}")
             raise UserError(_("TC1 validation failed. Error: %.2f€") % cumulative)



    def _process_value(self, raw_val, line_config, partner_id, move_lines):
        val = parse_float(
            raw_val,
            self.thousands_delimiter,
            self.decimal_delimiter
        )
        
        # Skip validation-only lines (used for TC1 checks, not posted)
        if line_config.is_validation_only:
            return


        if val == 0.0:
            return
            
        if not line_config.account_id:
             raise UserError(_("Account is missing for line '%s'. Please configure it in the Setup.") % line_config.name)

        line_vals = {
            'account_id': line_config.account_id.id,
            'partner_id': partner_id,
            'name': line_config.name,
        }

        if line_config.tax_id:
            line_vals['tax_ids'] = [(6, 0, [line_config.tax_id.id])]

        amount = abs(val)
        if line_config.sign == 'debit':
            line_vals['debit'] = amount
            line_vals['credit'] = 0.0
        else:
            line_vals['credit'] = amount
            line_vals['debit'] = 0.0

        move_lines.append((0, 0, line_vals))

    def _process_rows(self, data):
        move_lines = []
        aggregate_dict = {}  # key: (line_config.id), value: aggregated line_vals
        
        for row in data:
            try:
                employee_val = row[self.column_employee_id - 1]
            except IndexError:
                continue

            if not employee_val:
                continue

            partner_id = self._get_partner_id(employee_val)

            for line_config in self.line_ids:
                if line_config.column_index > len(row):
                    continue
                
                raw_val = row[line_config.column_index - 1]
                
                if line_config.is_validation_only:
                    continue
                    
                val = parse_float(raw_val, self.thousands_delimiter, self.decimal_delimiter)
                if val == 0.0:
                    continue
                
                if not line_config.account_id:
                    raise UserError(_("Account missing for line '%s'.") % line_config.name)
                
                # Build line values
                line_vals = {
                    'account_id': line_config.account_id.id,
                    'partner_id': partner_id,
                    'name': line_config.name,
                }
                if line_config.tax_id:
                    line_vals['tax_ids'] = [(6, 0, [line_config.tax_id.id])]
                
                amount = abs(val)
                if line_config.sign == 'debit':
                    line_vals['debit'] = amount
                    line_vals['credit'] = 0.0
                else:
                    line_vals['credit'] = amount
                    line_vals['debit'] = 0.0
                
                # Aggregate or append
                if line_config.aggregate_lines:
                    key = line_config.id
                    if key in aggregate_dict:
                        aggregate_dict[key]['debit'] += line_vals.get('debit', 0.0)
                        aggregate_dict[key]['credit'] += line_vals.get('credit', 0.0)
                    else:
                        # First occurrence, store without partner (aggregated)
                        aggregate_dict[key] = {
                            'account_id': line_config.account_id.id,
                            'name': line_config.name,
                            'debit': line_vals.get('debit', 0.0),
                            'credit': line_vals.get('credit', 0.0),
                        }
                        if line_config.tax_id:
                            aggregate_dict[key]['tax_ids'] = [(6, 0, [line_config.tax_id.id])]
                else:
                    move_lines.append((0, 0, line_vals))
        
        # Append aggregated lines
        for agg_vals in aggregate_dict.values():
            move_lines.append((0, 0, agg_vals))
        
        return move_lines

    def _process_columns(self, data):
        move_lines = []
        aggregate_dict = {}  # Aggregation by line_config.id
        _logger = logging.getLogger(__name__)
        
        if not data:
            _logger.info("Payroll Import: No data found in file.")
            return []
            
        num_columns = max(len(row) for row in data) if data else 0
        start_col = self.header_lines
        
        _logger.info("Payroll Import: Transposed Mode. Start Col: %s. Max Columns: %s", start_col, num_columns)
        
        for col_idx in range(start_col, num_columns):
            try:
                employee_row_idx = self.column_employee_id - 1
                if employee_row_idx >= len(data):
                     _logger.warning("Payroll Import: Employee Row Index %s out of bounds (rows: %s)", employee_row_idx, len(data))
                     continue

                if col_idx >= len(data[employee_row_idx]):
                     continue
                     
                employee_val = data[employee_row_idx][col_idx]
            except IndexError:
                continue
                
            if not employee_val:
                _logger.warning("Payroll Import: Skipping Column %s (Empty Employee Value)", col_idx)
                continue
                
            _logger.warning("Payroll Import: Processing Column %s for Employee: %s", col_idx, employee_val)
            partner_id = self._get_partner_id(employee_val)
            
            for line_config in self.line_ids:
                if line_config.is_validation_only:
                    continue
                    
                row_idx = line_config.column_index - 1
                if row_idx >= len(data):
                    _logger.warning("Payroll Import: Configured Row Index %s out of bounds", row_idx)
                    continue

                try:
                    if col_idx >= len(data[row_idx]):
                        continue
                    raw_val = data[row_idx][col_idx]
                except IndexError:
                    continue
                
                val = parse_float(raw_val, self.thousands_delimiter, self.decimal_delimiter)
                if val == 0.0:
                    continue
                
                if not line_config.account_id:
                    raise UserError(_("Account missing for line '%s'.") % line_config.name)
                
                line_vals = {
                    'account_id': line_config.account_id.id,
                    'partner_id': partner_id,
                    'name': line_config.name,
                }
                if line_config.tax_id:
                    line_vals['tax_ids'] = [(6, 0, [line_config.tax_id.id])]
                
                amount = abs(val)
                if line_config.sign == 'debit':
                    line_vals['debit'] = amount
                    line_vals['credit'] = 0.0
                else:
                    line_vals['credit'] = amount
                    line_vals['debit'] = 0.0
                
                # Aggregate or append
                if line_config.aggregate_lines:
                    key = line_config.id
                    if key in aggregate_dict:
                        aggregate_dict[key]['debit'] += line_vals.get('debit', 0.0)
                        aggregate_dict[key]['credit'] += line_vals.get('credit', 0.0)
                    else:
                        aggregate_dict[key] = {
                            'account_id': line_config.account_id.id,
                            'name': line_config.name,
                            'debit': line_vals.get('debit', 0.0),
                            'credit': line_vals.get('credit', 0.0),
                        }
                        if line_config.tax_id:
                            aggregate_dict[key]['tax_ids'] = [(6, 0, [line_config.tax_id.id])]
                else:
                    move_lines.append((0, 0, line_vals))
        
        # Append aggregated lines
        for agg_vals in aggregate_dict.values():
            move_lines.append((0, 0, agg_vals))
                
        return move_lines


    def process_data(self, data):
        """
        Process parsed data (list of rows) and create Account Move.
        data: list of list of strings
        """
        _logger = logging.getLogger(__name__)
        _logger.warning("Payroll Import: DATA RECEIVED. Rows: %s. Structure: %s", len(data) if data else 0, self.data_structure)
        
        if self.data_structure == 'columns':
             _logger.warning("Payroll Import: Branching to _process_columns")
             move_lines = self._process_columns(data)
        else:
             _logger.warning("Payroll Import: Branching to _process_rows")
             move_lines = self._process_rows(data)
        
        _logger.warning("Payroll Import: Move Lines Generated: %s", len(move_lines))
        
        # Validate TC1 if configured
        try:
            self._validate_tc1(data)
            _logger.warning("Payroll Import: TC1 Validation PASSED")
        except UserError as e:
            _logger.error("Payroll Import: TC1 Validation FAILED: %s", e)
            raise


        # Create Move
        move = self.env['account.move'].create({
            'journal_id': self.journal_id.id,
            'date': fields.Date.today(),
            'line_ids': move_lines
        })
        
        return move
