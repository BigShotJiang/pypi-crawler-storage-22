JWT bearer token authentication.
