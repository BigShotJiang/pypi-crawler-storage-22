########
Channels
########

This is the API documentation for the job channels and the
scheduling mechanisms of the job runner.

These classes are not intended for use by module developers.

.. automodule:: odoo.addons.queue_job.jobrunner.channels
   :members:
   :undoc-members:
   :show-inheritance:
