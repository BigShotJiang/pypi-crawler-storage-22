from . import (
    contract_iban_change,
    contract_one_shot_request,
    contract_tariff_change,
    partner_email_change,
)
