from . import (
    schemas,
    coop_agreement_service,
    crm_lead_service,
    discovery_channel_service,
    product_catalog_service,
    res_partner_process,
    res_partner_service,
    res_partner_public_service,
    subscription_request_service,
)
