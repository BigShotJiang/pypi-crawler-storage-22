This module allows to manage phone calls in order to analyze them.
