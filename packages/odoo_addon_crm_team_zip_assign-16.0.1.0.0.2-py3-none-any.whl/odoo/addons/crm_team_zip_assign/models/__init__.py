# Copyright 2025 Binhex
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import crm_team
from . import crm_team_zip_pattern
from . import res_partner
