## Odoo Export to DATEV

This module contains the basic configuration of the additional DATEV
modules to offer various ways to export data for the usage in DATEV.
