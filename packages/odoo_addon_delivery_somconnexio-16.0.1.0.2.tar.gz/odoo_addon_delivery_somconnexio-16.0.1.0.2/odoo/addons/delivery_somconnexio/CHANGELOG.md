# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [16.0.1.0.2] - 2026-02-04
### Changed
- [#1636](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1636) Do not use mixed_lead_lines filter in view

## [16.0.1.0.1] - 2025-09-16
### Fix
- [#1566](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1566) Refactor listeners

## [16.0.1.0.0] - 2025-05-26
### Added
- Migrate delivery_somconnexio module to ODOO v16
