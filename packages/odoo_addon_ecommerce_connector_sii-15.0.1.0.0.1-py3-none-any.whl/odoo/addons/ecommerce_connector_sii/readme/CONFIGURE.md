To configure this module, you need to:

*  No configuration needed.
