* Automatically unmark invoices as Simplified for B2C customers (typeClient = individual)
  when using the connector to set the VAT number of a contact previously created
  without one.
