With this module installed, HR Officer can keep records on employee
hire, start, and termination dates. This information is also used to
automatically calculate length of employee's service for the company.

*Hire Date* typically is the date when employee has accepted or signed
the offer.

*Start Date* typically is the date of the first official work day since
which employee is entitled to receiving benefits and various accrual
allocations.

*Termination Date* typically is the date of the last official work day
since until which employee is entitled to receiving benefits and various
accrual allocations.
