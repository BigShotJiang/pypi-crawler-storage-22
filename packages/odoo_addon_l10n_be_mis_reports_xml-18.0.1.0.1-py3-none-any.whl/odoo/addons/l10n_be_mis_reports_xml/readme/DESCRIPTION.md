This module allows to export Belgian VAT declaration as an XML file that
follows the official definition and can be submitted to the
administration's online services.

The XML domain definitions (XSD files) can be found on [the
administration
website](https://finances.belgium.be/fr/E-services/Intervat/documentation-technique).
