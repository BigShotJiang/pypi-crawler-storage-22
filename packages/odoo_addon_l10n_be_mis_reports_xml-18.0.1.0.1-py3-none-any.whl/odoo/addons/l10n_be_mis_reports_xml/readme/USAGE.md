To use this module, you need to go to Accounting \> Reporting \> MIS
Reports and use the buttons available on the previously configured
reports such as preview, export, add to dashboard.
