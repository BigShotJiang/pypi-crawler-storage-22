Data module to add swiss compay types.
