# License AGPL-3 - See https://www.gnu.org/licenses/agpl-3.0

from . import test_l10n_es_aeat_mod123
