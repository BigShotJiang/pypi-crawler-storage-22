A dia de hoy, las retenciones en especie se computan como repercutidas
al trabajador.
