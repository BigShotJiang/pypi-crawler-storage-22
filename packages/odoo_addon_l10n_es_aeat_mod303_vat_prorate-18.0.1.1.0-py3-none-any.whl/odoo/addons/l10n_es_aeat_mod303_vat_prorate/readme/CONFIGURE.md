Para entender el funcionamiento de la prorrata, remitirse a la configuración de l10n_es_vat_prorate.
