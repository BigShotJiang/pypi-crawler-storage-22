- La declaración sólo se puede realizar para personas jurídicas.
- No se calculan operaciones intragrupo.
- No se contempla el régimen de criterio de caja.
- No se contempla el régimen especial de bienes usados, objetos de arte,
  antigüedades y objetos de colección.
- No se contempla el régimen especial de agencias de viaje.
- No se contempla el recargo de equivalencia de impuesto al tabaco
  (casillas 41 y 42).
- No se contempla el régimen especial de la agricultura, ganadería y
  pesca.
- No se contempla la prorrata general de IVA.
- No se contempla el régimen simplificado.
- No se contempla el régimen de deducción diferenciado.
- No se contempla la inversión de sujeto pasivo nacional.
- No se tienen en cuenta tributaciones territoriales.
- Obtener las casillas 95, 97 y 98 de las declaraciones del 303.
- Falta añadir la casilla 663 de cuota pendientes de compensación.
