Para crear un modelo, por ejemplo de un trimestre del año:

1.  Ir a *Contabilidad \> Declaraciones AEAT \> Modelo 390*.
2.  Pulsar en el botón "Crear"
3.  Seleccionar el ejercicio fiscal.
4.  Seleccionar el tipo de declaración.
5.  Rellenar el teléfono y teléfono móvil, necesarios para la
    exportacion BOE
6.  Guardar y pulsar en el botón "Calcular"
7.  Rellenar (si es necesario) aquellos campos que Odoo no calcula
    automáticamente.
8.  Cuando los valores sean los correctos, pulsar en el botón
    "Confirmar"
9.  Podemos exportar en formato BOE para presentarlo telemáticamente en
    el portal de la AEAT
