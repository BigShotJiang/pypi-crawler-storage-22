Los códigos de impuestos incluidos en el Libro de IVA pueden verse en:
Contabilidad -\> Configuración -\> AEAT -\> Mapeo AEAT libro de IVA

Los clientes utilizados para ventas por caja deben tener marcado el
campo "AEAT - Cliente anónimo" para que no se muestren advertencias por
no tener NIF informado siguiendo lo especificado en el formato BOE.
