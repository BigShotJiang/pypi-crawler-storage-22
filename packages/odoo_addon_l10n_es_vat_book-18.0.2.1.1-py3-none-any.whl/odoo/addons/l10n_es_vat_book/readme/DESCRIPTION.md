Módulo que calcula los libros de IVA e IRPF español.

Esto módulo introduce el menú "Libros de IVA y del IRPF" en Contabilidad -\> Informe
-\> Declaraciones AEAT.

Es posible visualizar e imprimir por separado:

- Libro Registro de Facturas Emitidas
- Libro Registro de Facturas Recibidas

Es posible exportar los registros a archivo con extensión xlsx.

En el modo de visualización de los informes es posible navegar a los
asientos contables relacionados con la factura.
