Funcionalidades del Libro Registro de IVA no incluídas por el momento:

- Criterio de caja
- Regímenes especiales de seguros, de agencias de viaje o de bienes
  usados.
- Clave de operación.
- Deducible en periodo posterior.
- Actividad
