1.  Ve a *Contabilidad \> Declaraciones AEAT \> Libro de IVA*.
2.  Crea un nuevo registro.
3.  Escoge el periodo de tiempo para el libro.
4.  Pulsa en "Calcular".
5.  Escoge la opción de visualización o impresión preferida.
