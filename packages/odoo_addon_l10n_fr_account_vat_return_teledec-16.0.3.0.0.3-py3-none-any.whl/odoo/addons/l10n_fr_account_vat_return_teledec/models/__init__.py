from . import res_company
from . import l10n_fr_account_vat_return
