On a VAT return in Odoo, when you reach the step *Automatic Lines*, you will see a button *Send via Gateway* and a field *Send Gateway* to select the gateway. Make sure the field *Send Gateway* is set to *Teledec.fr* and then click on the button *Send via Gateway* to teletransmit the VAT return to DGFiP via Teledec.

.. figure:: static/description/transmit_teledec_button.png
   :alt: VAT Return with option to teletransmit via Teledec.fr.

Teledec will send you an email once they have successfully transmitted your VAT return to DGFiP.
