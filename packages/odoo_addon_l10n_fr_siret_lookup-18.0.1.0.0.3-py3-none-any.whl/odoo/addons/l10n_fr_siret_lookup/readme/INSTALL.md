It's recommended to install `python-stdnum>=1.18` for SIRET support.
