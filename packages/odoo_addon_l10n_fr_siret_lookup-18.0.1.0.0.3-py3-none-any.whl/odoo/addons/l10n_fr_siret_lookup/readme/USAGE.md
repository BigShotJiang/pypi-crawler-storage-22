To update an existing partner, go to the partner form view and click on
*Action \> SIREN Lookup*.

By default, the search field is filled with Company name. To get more
accurate results, you may want to add the City name where the company is
registered. Then click on *Lookup*.

A list of companies is displayed. You may want to click on one in order
to see corresponding information or directly select company from list
view. Once a company is selected, the partner information is updated and
a message is logged in the chatter.
