from . import l10n_ro_mixin
from . import account_journal
from . import ir_ui_menu
from . import product_template
from . import res_bank
from . import res_company
from . import res_partner
from . import template_ro
