- [NextERP Romania](https://www.nexterp.ro):
  - Fekete Mihai \<<feketemihai@nexterp.ro>\>
- [Terrabit](https://www.terrabit.ro):
  - Dorin Hongu \<<dhongu@gmail.com>\>
- Adrian Vasile \<<adrian.vasile@gmail.com>\>
- [QDev Web Labs](https://qdev.ro):
  - Anastasescu Răzvan-Ioan \<<razvan@qdev.ro>\>

Do not contact contributors directly about support or help with
technical issues.
