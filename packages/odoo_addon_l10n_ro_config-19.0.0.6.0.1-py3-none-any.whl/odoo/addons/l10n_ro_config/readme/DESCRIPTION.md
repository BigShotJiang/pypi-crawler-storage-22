This module allows you to install and configure all the localization
modules related to Romania. Some of the modules will load data at
install.

For Romanian companies, you will have a dedicated page in Configuration,
from where you cna install rest of the modules, or set up some added
fields for localization.

\* All changes added by the Romanian localization will only apply for
companies that have the "Use Romanian Accounting" checkbox set.

\* All menus and fields are visible in the interface if you are working
on a Romanian company, otherwise the are hidden.
