from . import res_partner
from . import res_partner_anaf_status
from . import res_partner_anaf_scptva
