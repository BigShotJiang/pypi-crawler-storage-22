Put the VAT number in the partner's form and if it's a romanian company,
it will fetch data available on ANAF website.
