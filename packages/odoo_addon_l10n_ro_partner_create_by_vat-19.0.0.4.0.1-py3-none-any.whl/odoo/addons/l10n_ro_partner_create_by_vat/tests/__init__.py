from . import test_create_partner_by_vat
