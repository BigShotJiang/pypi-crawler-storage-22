from . import fifo

from . import account_account
from . import account_move
from . import account_move_line
from . import product_category
from . import product_template
from . import stock_location
from . import stock_move
from . import stock_picking
from . import stock_warehouse
