- [Tecnativa](https://www.tecnativa.com):

  - Jairo Llopis
  - Pedro M. Baeza
  - David Vidal
  - Victor M.M. Torres
  - Víctor Martínez

- [Hibou Corp.](https://hibou.io):

  - Jared Kipe \<<jared@hibou.io>\>

- [Dynapps N.V.](https://www.dynapps.be):

  - Xander De Jaegere

- [Trobz](https://trobz.com):

  > - Nguyễn Minh Chiến \<<chien@trobz.com>\>

- [PeGon GmbH](https://www.pegon.ch):

  - Pedro Evaristo Gonzalez Sanchez

- [Moduon](https://www.moduon.team/):

    - Jairo Llopis
