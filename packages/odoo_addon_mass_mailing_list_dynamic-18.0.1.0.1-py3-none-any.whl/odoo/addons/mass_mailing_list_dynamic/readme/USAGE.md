To use this module, you need to:

1.  Go to *Email Marketing \> Mailings*, and create one.
2.  Select as recipients a mailing list.
3.  On "Select mailing lists:", choose one mailing list with dynamic
    flag checked.
4.  Before sending the mass mailing, the list will be synced for having
    latest changes.

When you hit the *Sync now* button or send a mass mailing to this list,
its contacts will be automatically updated.

Pay attention to the messages shown to you that tell you about some
non-obvious behaviour you could experience if you edit manually contacts
from a dynamic list.
