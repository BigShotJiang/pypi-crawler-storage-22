- [Tecnativa](https://www.tecnativa.com):

  > - Pedro M. Baeza
  > - Rafael Blasco
  > - Antonio Espinosa
  > - Javier Iniesta
  > - Jairo Llopis
  > - David Vidal
  > - Ernesto Tejeda
  > - Victor M.M. Torres
  > - Manuel Calero
  > - Víctor Martínez

- [Hibou Corp.](https://hibou.io)

- [Trobz](https://trobz.com):

  > - Nguyễn Minh Chiến \<<chien@trobz.com>\>

- [360ERP](https://www.360erp.com):
  > - Kevin Khao
