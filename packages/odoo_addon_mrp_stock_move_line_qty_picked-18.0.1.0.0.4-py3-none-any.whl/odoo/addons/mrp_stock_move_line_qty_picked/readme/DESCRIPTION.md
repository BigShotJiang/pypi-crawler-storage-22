This module adapts the functionality of the stock_move_line_qty_picked module
to manufacturing orders. It displays the quantity picked in stock moves when
shown in the context of manufacturing orders.
