from odoo import models

from ..somoffice.user import SomOfficeUser
from odoo.exceptions import ValidationError


class ResPartner(models.Model):
    _inherit = "res.partner"

    def create_user(self, partner):
        self._required_create_user_attrs(partner, "ref", "email", "vat", "lang")
        SomOfficeUser(
            partner.ref,
            partner.email,
            partner.vat,
            partner.lang,
        ).create()

    def _required_create_user_attrs(self, partner, *attrs):
        """
        Raises Exception if an attribute exists but evaluates to False.
        """
        falsey_attrs = [attr for attr in attrs if not getattr(partner, attr)]
        if falsey_attrs:
            raise ValidationError(
                f"Can't create somoffice user from 'res.partner' has falsey attribute(s): {', '.join(falsey_attrs)}"  # noqa
            )
