from . import contract
from . import opencell_configuration
from . import res_partner
