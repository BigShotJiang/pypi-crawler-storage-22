from .opencell_resource import OpenCellResource


class AccessFromContract(OpenCellResource):
    def __init__(self, contract):
        self.contract = contract
        self.white_list = ["code", "subscription"]

    @property
    def code(self):
        if self.contract.service_contract_type in ("switchboard", "filmin"):
            return self.contract.name
        elif self.contract.phone_number:
            return self.contract.phone_number
        return self.contract.name

    @property
    def subscription(self):
        return self.contract.code
