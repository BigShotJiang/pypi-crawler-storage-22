class Description:
    def __init__(self, text):
        self.text = text[:50]
