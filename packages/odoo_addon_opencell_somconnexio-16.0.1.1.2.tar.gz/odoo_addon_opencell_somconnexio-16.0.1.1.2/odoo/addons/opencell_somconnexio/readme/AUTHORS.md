* Som Connexió SCCL <https://somconnexio.coop/>
* Coopdevs Treball SCCL <https://coopdevs.coop/>
