* `Som Connexió SCCL <https://somconnexio.coop/>`__
    * Gerard Funonsas <gerard.funosas@somconnexio.coop>
* `Coopdevs Treball SCCL <https://coopdevs.coop/>`__
    * Daniel Palomar <daniel.palomar@coopdevs.org>
    * Cesar Lopez <cesar.lopez@coopdevs.org>
    * Carla Berenguer <carla.berenguer@coopdevs.org>
