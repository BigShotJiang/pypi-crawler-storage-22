The usage is full integrated with the ORM of Odoo using listeners.

More info about the listeners: https://odoo-connector.com/api/api_components.html#listeners
