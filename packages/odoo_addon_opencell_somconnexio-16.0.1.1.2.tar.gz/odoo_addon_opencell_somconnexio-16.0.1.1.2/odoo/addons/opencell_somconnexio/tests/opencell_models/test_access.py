from odoo.tests.common import TransactionCase
from odoo.addons.somconnexio.tests.factories import ContractFactory

from ...opencell_models.access import AccessFromContract


class AccessFromContractTestCase(TransactionCase):
    def setUp(self):
        super().setUp()
        self.contract = ContractFactory()
        self.contract.code = 1234
        self.contract.phone_number = "666666666"
        self.contract.name = "OC Contract"

    def test_mobile_access_construct_ok(self):
        self.contract.service_contract_type = "mobile"

        access_from_contract = AccessFromContract(self.contract)
        self.assertEqual(access_from_contract.code, self.contract.phone_number)
        self.assertEqual(access_from_contract.subscription, self.contract.code)

    def test_broadband_subscription_construct_ok(self):
        self.contract.service_contract_type = "vodafone"

        access_from_contract = AccessFromContract(self.contract)
        self.assertEqual(access_from_contract.code, self.contract.phone_number)
        self.assertEqual(access_from_contract.subscription, self.contract.code)

    def test_switchboard_subscription_construct_ok(self):
        self.contract.service_contract_type = "switchboard"

        access_from_contract = AccessFromContract(self.contract)
        self.assertEqual(access_from_contract.code, self.contract.name)
        self.assertEqual(access_from_contract.subscription, self.contract.code)

    def test_filmin_subscription_construct_ok(self):
        self.contract.service_contract_type = "filmin"

        access_from_contract = AccessFromContract(self.contract)
        self.assertEqual(access_from_contract.code, self.contract.name)
        self.assertEqual(access_from_contract.subscription, self.contract.code)
