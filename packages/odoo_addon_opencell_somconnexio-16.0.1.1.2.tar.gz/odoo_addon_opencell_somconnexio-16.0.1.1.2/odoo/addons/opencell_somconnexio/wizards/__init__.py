from . import (
    contract_compensation,
    contract_force_oc_integration,
    contract_iban_change_force,
    contract_iban_change,
    partner_email_change,
)
