This modules allows to use CECA payment acquirer.
