To use this module, you need to create an order and pay it using the CECA method. The detailed steps are explained below:

1. Create an order and go to its payment view on the portal or website shop. For example, you can create a Sale Order, and click on Action / Generate a Paymnent link. Select the CECA payment acquirer, and go to the provided link. 
Note: If no payment mode has been selected to be forced, it will be necessary to select which payment mode has to be used for the specific transaction

2. In the payment view, review the corresponding fields and click on the Pay button.

3. You would be redirected to the payment gateway. Fill the fields and confirm the payment. If the CECA acquirer is in test mode, you can use CECA's test credentials; if not, a real credit card needs to be used.

4. Once the payment is confirmed, you would be redirected again to Odoo's payment view. Then, the transaction will be changed to the 'Done' state. If an error occurs, the transaction will be cancelled. 

IMPORTANT: When a previously confirmed transaction is canceled, the payment needs to be canceled too. The payment can be accessed from the transaction form view.
