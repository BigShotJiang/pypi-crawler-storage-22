* Alexandre Díaz
* Pablo Quesada
* Jose Luis Algara
* `Commit [Sun] <https://www.commitsun.com>`:

  * Dario Lodeiros
  * Eric Antones
  * Sara Lago
  * Brais Abeijon
  * Miguel Padin
* Omar Castiñeira <omar@comunitea.com>
