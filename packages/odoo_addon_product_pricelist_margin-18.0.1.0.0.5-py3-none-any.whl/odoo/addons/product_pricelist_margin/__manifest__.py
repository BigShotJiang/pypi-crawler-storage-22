# Copyright 2024 Camptocamp SA
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
{
    "name": "Product Pricelist Margin",
    "summary": "This module shows the product's cost and margin from the pricelists.",
    "version": "18.0.1.0.0",
    "category": "Product",
    "website": "https://github.com/OCA/product-attribute",
    "author": "Camptocamp, Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "depends": ["account"],
    "data": [
        "views/product_pricelist_views.xml",
        "views/product_pricelist_item_views.xml",
    ],
}
