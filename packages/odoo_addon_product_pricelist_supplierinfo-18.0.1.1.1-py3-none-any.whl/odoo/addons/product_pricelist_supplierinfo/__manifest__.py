# Copyright 2018 Tecnativa - Vicent Cubells
# Copyright 2018 Tecnativa - Pedro M. Baeza
# Copyright 2025 Tecnativa - Carlos Dauden
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
{
    "name": "Supplier info prices in sales pricelists",
    "summary": "Allows to create priceslists based on supplier info",
    "version": "18.0.1.1.1",
    "category": "Sales/Sales",
    "website": "https://github.com/OCA/product-attribute",
    "author": "Tecnativa, Odoo Community Association (OCA), Vauxoo",
    "maintainers": ["luisg123v"],
    "license": "AGPL-3",
    "depends": ["product"],
    "data": [
        "security/res_groups.xml",
        "views/product_pricelist_item_views.xml",
        "views/product_supplierinfo_view.xml",
    ],
    "installable": True,
}
