This module allows importing vendor price lists from Excel files, matching products using any product template char field.
