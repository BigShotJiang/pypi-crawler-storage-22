To use this module, you need to:

1. Go to *Purchase > Configuration > Import vendor pricelists*.
2. Upload your vendor pricelists sheet file.
3. Set the vendor partner, the date from which the pricelists are valid and the lead
   days.
4. Click on import and view.

If a template for that file is configured, it will match the headers with the column
values and create or update the vendor pricelists accordingly.
