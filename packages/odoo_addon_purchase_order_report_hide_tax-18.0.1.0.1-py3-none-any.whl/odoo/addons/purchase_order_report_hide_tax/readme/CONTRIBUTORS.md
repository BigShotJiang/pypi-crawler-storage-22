* David Vidal (`Moduon <https://www.moduon.team/>`__)
* [Quartile](https://www.quartile.co):
  * Aung Ko Ko Lin
