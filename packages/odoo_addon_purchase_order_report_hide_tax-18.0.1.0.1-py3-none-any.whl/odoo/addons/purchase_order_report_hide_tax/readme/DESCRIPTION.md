Hide taxes column in the purchase order document that is sent to the vendor.
