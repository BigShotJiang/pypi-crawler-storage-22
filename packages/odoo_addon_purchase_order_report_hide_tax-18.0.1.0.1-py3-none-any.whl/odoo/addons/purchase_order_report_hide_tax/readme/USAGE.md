Whenever the taxes are in the same group for the whole order the column won't be
displayed in the purchase order printed report.
