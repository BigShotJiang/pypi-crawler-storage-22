In order to use this module, you need to have some storable products valued on average
cost (AVCO).

To do so:

- Go to *Inventory > Configuration > Product Categories* and select one.
- In the **Inventory valuation** section, select the **Costing method** as **Average
  Cost (AVCO)**.
- Now all the products in that category will have that valuation rules.
