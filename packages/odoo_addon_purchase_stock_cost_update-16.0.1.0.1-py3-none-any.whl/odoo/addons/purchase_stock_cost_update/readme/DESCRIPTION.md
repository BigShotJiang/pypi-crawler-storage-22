This module allows to adjust the valuation of the incoming goods related to their
purchase order from the purchase line itself.
