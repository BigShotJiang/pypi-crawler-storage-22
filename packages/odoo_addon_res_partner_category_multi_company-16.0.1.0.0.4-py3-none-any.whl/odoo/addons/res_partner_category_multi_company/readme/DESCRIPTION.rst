This module adds company fields on the model "Contact Tags" (``res.partner.category``).
