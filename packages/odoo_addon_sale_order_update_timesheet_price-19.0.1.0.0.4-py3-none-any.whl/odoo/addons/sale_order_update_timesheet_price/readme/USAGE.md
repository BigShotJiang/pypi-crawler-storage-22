There is a button with a banknote icon on the sale order line.
When clicked, it opens a wizard to update the unit price of the sale order line.
