from odoo import api
from odoo.addons.account_payment_return_import.wizard.payment_return_import import (
    PaymentReturnImport,
)
import logging

_logger = logging.getLogger(__name__)


def post_load_hook():
    @api.model
    def _get_journal(self, bank_account_id):
        """Find the journal"""
        # Find the journal from context, wizard or bank account
        journal_id = self.env.context.get("journal_id") or self.journal_id.id
        return journal_id

    if not hasattr(PaymentReturnImport, "_get_journal_original"):
        PaymentReturnImport._get_journal_original = PaymentReturnImport._get_journal
        PaymentReturnImport._get_journal = _get_journal
