from odoo.addons.component.core import Component


class ResPartnerListener(Component):
    _name = "res.partner.listener"
    _description = "Basic SC Res Partner Listener"
    _inherit = "base.event.listener"
    _apply_on = ["res.partner"]

    def on_record_create(self, record, fields=None):
        if record.type == "representative" and not record.parent_id and record.email:
            record.get_or_create_contract_email(record.email)
