# Copyright 2025 Coopdevs Treball SCCL
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).
from openupgradelib import openupgrade


@openupgrade.migrate()
def migrate(env, version):
    activities = env["mail.activity"].search(
        [("active", "=", True), ("done", "=", True)]
    )
    activities.write({"active": False})
