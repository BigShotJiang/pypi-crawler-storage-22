# Copyright 2025 Coopdevs Treball SCCL
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).
from openupgradelib import openupgrade
from odoo.exceptions import ValidationError

import logging

_logger = logging.getLogger(__name__)


@openupgrade.migrate()
def migrate(env, version):
    """
    Substitute representative partners within contracts "email_ids" field
    for their corresponding contact-email partners.
    """
    contracts = env["contract.contract"].search(
        [
            ("email_ids", "!=", False),
            ("email_ids.type", "=", "representative"),
            ("is_terminated", "=", False),
        ]
    )
    for contract in contracts:
        email_representative_ids = contract.email_ids.filtered(
            lambda p: p.type == "representative"
        )
        for repr_email in email_representative_ids:
            try:
                contact_email = repr_email.get_or_create_contract_email(
                    repr_email.email
                )
            except ValidationError as error:
                _logger.warning(
                    "Contract %s: could not create/find contact-email partner for representative email %s.\n Error: %s",  # noqa: E501
                    contract.id,
                    repr_email.email,
                    error.args[0],
                )
                continue

            cmds = [
                (4, contact_email.id),  # Add contract-email contact
                (3, repr_email.id),  # Remove representative email
            ]
            contract.write({"email_ids": cmds})
            _logger.debug(
                "Contract %s: substituted representative partner %s with contact-email partner %s.",  # noqa: E501
                contract.id,
                repr_email.id,
                contact_email.id,
            )
    _logger.info("Migration of contracts with representative email_ids completed.")
