from ..sc_test_case import SCComponentTestCase
from mock import patch


class TestResPartnerListener(SCComponentTestCase):
    def setUp(self, *args, **kwargs):
        super().setUp(*args, **kwargs)
        self.partner_vals = {
            "name": "test",
            "street": "test",
            "street2": "test2",
            "city": "test",
            "state_id": self.ref("base.state_es_b"),
            "country_id": self.ref("base.es"),
            "email": "brand.new.email@test.coop",
            "type": "representative",
        }

    @patch(
        "odoo.addons.somconnexio.models.res_partner.ResPartner.get_or_create_contract_email"  # noqa: E501
    )
    def test_create_representative_creates_contract_email_child(
        self, mock_get_or_create_contract_email
    ):
        self.env["res.partner"].create(self.partner_vals)
        mock_get_or_create_contract_email.assert_called_once_with(
            self.partner_vals["email"]
        )
