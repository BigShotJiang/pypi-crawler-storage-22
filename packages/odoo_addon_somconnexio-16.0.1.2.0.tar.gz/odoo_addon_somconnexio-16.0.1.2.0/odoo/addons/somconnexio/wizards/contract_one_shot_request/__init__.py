from . import contract_one_shot_request
