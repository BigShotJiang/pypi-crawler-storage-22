This module extends the functionality of stock to allow you to prevent to put
items of different products into the same stock location.
