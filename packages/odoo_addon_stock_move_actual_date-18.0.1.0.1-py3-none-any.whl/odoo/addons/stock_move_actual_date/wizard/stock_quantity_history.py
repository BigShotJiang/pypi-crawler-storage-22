# Copyright 2025 Quartile (https://www.quartile.co)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from odoo import models
from odoo.tools.misc import format_datetime
from odoo.tools.safe_eval import safe_eval


class StockQuantityHistory(models.TransientModel):
    _inherit = "stock.quantity.history"

    def open_at_actual_date(self):
        action = self.env["ir.actions.actions"]._for_xml_id(
            "stock_account.stock_valuation_layer_action"
        )
        action["domain"] = [
            ("actual_date", "<=", self.inventory_datetime),
            ("product_id.is_storable", "=", True),
        ]
        action["display_name"] = format_datetime(self.env, self.inventory_datetime)
        return action

    def open_qty_at_actual_date(self):
        action = self.open_at_date()
        ctx = action["context"]
        ctx = safe_eval(ctx) if isinstance(ctx, str) else ctx
        ctx["use_actual_date"] = True
        return action
