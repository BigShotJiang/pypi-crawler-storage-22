from . import helper_service
from .models import (
    test_contract,
    test_crm_lead_line,
    test_switchboard_isp_info,
)
from .wizards import (
    test_create_lead_from_partner_wizard,
    test_crm_lead_add_sb_line,
)
