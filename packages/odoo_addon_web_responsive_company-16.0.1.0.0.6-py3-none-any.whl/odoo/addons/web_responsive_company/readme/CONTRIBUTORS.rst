* Sylvain LE GAL (https://www.twitter.com/legalsylvain)
* Quentin DUPONT (quentin.dupont@grap.coop)

Part of the code comes from ``web_responsive`` module, and has been adapted.
