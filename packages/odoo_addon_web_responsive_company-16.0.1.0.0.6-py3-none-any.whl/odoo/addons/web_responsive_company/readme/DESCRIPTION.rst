This module extends the ``web_responsive`` module to have a better display of the companies menu.

It is usefull only if you have an Odoo Instance, with a lot of companies.
