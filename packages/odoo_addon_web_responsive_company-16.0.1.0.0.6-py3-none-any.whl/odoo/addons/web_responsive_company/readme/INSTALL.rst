If the OCA module ``res_company_code`` (OCA module present in the
multi-company repository) is installed, the search will be done
also on the company codes.

Ref : https://github.com/OCA/multi-company/tree/16.0/res_company_code

