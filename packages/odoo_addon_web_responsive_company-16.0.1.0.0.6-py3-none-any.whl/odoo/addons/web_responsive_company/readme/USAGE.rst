* Click on the current company name

* The list of the companies are now displayed with the logo and the code (if defined), and there are ordered by complete name. (code and name)

.. figure:: ../static/description/company_menu.png

* It is also possible to search by name, with a fuzzy search.

.. figure:: ../static/description/company_menu_fuzzy_search.png

Other features :
- a new access key is available on 'Y' to display company menu.
- navigate with keyboard 'Arrow down', 'Arrow up' and 'Tab'
- toggle company off/on with 'Space' and log in with 'Enter'
- escape fullscreen with 'Escape'
- selected companies have a check mark
- logged in company has a green check mark and a green border 