from . import models
from .post_install import channel_partner_recompute_completion
