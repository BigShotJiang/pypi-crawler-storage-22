After module installation, you will see course's completed time within attendee views.

![Attendees Tree View](../static/description/attendees_tree_view.png)
