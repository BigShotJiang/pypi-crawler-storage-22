# Bemade Odoo Deployment Tools

This repo contains tools for deploying an Odoo-compatible local development
instance. You can use it in two ways:

## Option 1: Standalone Installation (Recommended)

Install the tool globally on your system:

```bash
# Clone the repository
git clone https://github.com/bemade/odoo-deploy.git
cd odoo-deploy

# Install using the installation script
./install.sh
# OR using make
make install
```

This will create a symlink to `odoo-dev.sh` as `odoo-dev` in:
- `/usr/local/bin` (system-wide, requires sudo if not writable)
- `~/.local/bin` (user-only, automatically added to PATH)

After installation, you can use `odoo-dev` from anywhere:
```bash
odoo-dev help
odoo-dev setup
```

**To update the tool:**
```bash
cd /path/to/odoo-deploy
git pull
```

**To uninstall:**
```bash
./uninstall.sh
# OR
make uninstall
```

## Option 2: Git Submodule (Legacy)

Include it as a submodule in your Odoo.sh-compatible repository:

```bash
git submodule add https://github.com/bemade/odoo-deploy.git .odoo-deploy
git submodule update --init --recursive
```

## Development Environment Options

This repository provides two methods for setting up your development environment:

1. **Traditional Setup** - Local Python virtual environment with direct PostgreSQL connection
2. **Docker Setup** - Containerized environment with Odoo and PostgreSQL running in Docker

## Docker-based Development Environment

### Prerequisites

- Docker and Docker Compose installed on your system
- Git
- VSCode with the Docker and Python extensions (recommended)

### Quick Start

1. Clone your Odoo project repository and update submodules:

   ```bash
   git clone <your-repo-url>
   cd <your-repo-directory>
   git submodule update --init --recursive
   ```

2. Make the development script executable:

   ```bash
   chmod +x .odoo-deploy/odoo-dev.sh
   ```

3. Set up the development environment:

   ```bash
   ./.odoo-dev.sh setup
   ```

4. Start the Docker environment:

   ```bash
   ./.odoo-dev.sh start
   ```

5. Access Odoo at http://localhost:8069

### Available Commands

The `odoo-dev.sh` script provides several commands to help manage your development environment:

```bash
# Complete setup: clone Odoo repos, configure VSCode, build image
./.odoo-dev.sh setup [--community]

# Start Odoo and PostgreSQL containers
./.odoo-dev.sh start

# Stop all containers
./.odoo-dev.sh stop

# Restart all containers
./.odoo-dev.sh restart

# Show logs from the Odoo container
./.odoo-dev.sh logs

# Open a shell in the Odoo container
./.odoo-dev.sh shell

# Open a PostgreSQL shell
./.odoo-dev.sh psql

# Show VSCode debugging instructions
./.odoo-dev.sh debug

# Restore database from a backup file
./.odoo-dev.sh db-restore /path/to/backup.zip [new_database_name]

# Drop a database
./.odoo-dev.sh db-drop database_name

# List all databases
./.odoo-dev.sh db-list

# Neutralize a database (disable emails, etc.)
./.odoo-dev.sh db-neutralize database_name

# Rebuild the Odoo container
./.odoo-dev.sh build

# Update specified modules or all modules if none specified
./.odoo-dev.sh update module1,module2

# Run tests for specified modules (comma-separated) or all modules if none specified
# Specify the database name to use (optional) as a second argument
./.odoo-dev.sh test module1,module2 test_module1_module2

# Update Odoo repositories only
./.odoo-dev.sh odoo-update [--community]

# Set up VSCode configuration for debugging
./.odoo-dev.sh vscode

# Show help message
./.odoo-dev.sh help
```

### Project Naming and Multiple Projects

The Docker Compose project name is automatically set to the basename of your project directory. For example, if your project is located at `/Users/username/src/my-odoo-project`, the Docker Compose project name will be `my-odoo-project`. This means your containers will be named like `my-odoo-project-odoo-1` and `my-odoo-project-db-1`.

**Important:** If you work with multiple Odoo projects simultaneously, you'll need to stop any running project before starting another one, as they use the same ports. To stop a specific project:

```bash
docker compose -p project_name stop
```

Alternatively, you can modify the port mappings in the `compose.yaml` file to avoid conflicts. Beware though that the debugging port will also need
changing in your .vscode/launch.json file. Of course, don't commit your changes to this repo if you do this!

### Environment Variables

The script automatically loads environment variables from a `.env` file in your project root if it exists. This allows you to customize settings like:

- `ODOO_VERSION`: The Odoo version to use (default: 18.0)
- `PYTHON_VERSION`: The Python version to use (default: 3.12)

### Debugging with VSCode

Odoo is configured to run with debugpy enabled on port 5678. To debug your Odoo application:

1. Set breakpoints in your code
2. Go to the 'Run and Debug' view in VSCode (Ctrl+Shift+D or Cmd+Shift+D)
3. Select 'Odoo Docker: Debug' from the dropdown menu
4. Click the green play button or press F5

The debugger will attach to the running Odoo process and stop at your breakpoints.

### Database Restoration and Neutralization

When restoring a database from a backup, the script automatically neutralizes it to prevent unwanted emails and external API calls. This ensures that your development environment doesn't interfere with production systems.

**Happy Odooing!**
