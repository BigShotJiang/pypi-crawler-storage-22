#!/bin/bash

# Odoo Deploy Tool Installation Script
# This script installs the odoo-deploy tool by creating a symlink to the shell script

set -e

# Define colors for output
GREEN="\033[0;32m"
YELLOW="\033[1;33m"
RED="\033[0;31m"
NC="\033[0m" # No Color

# Get the directory of this script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
ODOO_DEV_SCRIPT="$SCRIPT_DIR/odoo-dev.sh"

# Determine the appropriate installation directory based on OS
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS - prefer /usr/local/bin, fallback to ~/.local/bin
    if [ -w "/usr/local/bin" ] || [ "$(id -u)" -eq 0 ]; then
        INSTALL_DIR="/usr/local/bin"
    else
        INSTALL_DIR="$HOME/bin"
        # Create ~/bin if it doesn't exist
        mkdir -p "$INSTALL_DIR"
    fi
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux - prefer /usr/local/bin, fallback to ~/bin
    if [ -w "/usr/local/bin" ] || [ "$(id -u)" -eq 0 ]; then
        INSTALL_DIR="/usr/local/bin"
    else
        INSTALL_DIR="$HOME/bin"
        # Create ~/bin if it doesn't exist
        mkdir -p "$INSTALL_DIR"
    fi
else
    echo -e "${RED}Unsupported operating system: $OSTYPE${NC}"
    exit 1
fi

SYMLINK_PATH="$INSTALL_DIR/odoo-dev"

echo -e "${GREEN}Installing Odoo Deploy Tool...${NC}"
echo -e "Source: $ODOO_DEV_SCRIPT"
echo -e "Target: $SYMLINK_PATH"

# Check if the source script exists
if [ ! -f "$ODOO_DEV_SCRIPT" ]; then
    echo -e "${RED}Error: odoo-dev.sh not found at $ODOO_DEV_SCRIPT${NC}"
    exit 1
fi

# Remove existing symlink if it exists
if [ -L "$SYMLINK_PATH" ]; then
    echo -e "${YELLOW}Removing existing symlink...${NC}"
    rm "$SYMLINK_PATH"
elif [ -f "$SYMLINK_PATH" ]; then
    echo -e "${RED}Error: $SYMLINK_PATH exists but is not a symlink${NC}"
    echo "Please remove it manually and run this script again"
    exit 1
fi

# Create the symlink
if [ "$INSTALL_DIR" = "/usr/local/bin" ] && [ "$(id -u)" -ne 0 ] && [ ! -w "/usr/local/bin" ]; then
    echo -e "${YELLOW}Creating symlink (requires sudo)...${NC}"
    sudo ln -sf "$ODOO_DEV_SCRIPT" "$SYMLINK_PATH"
else
    ln -sf "$ODOO_DEV_SCRIPT" "$SYMLINK_PATH"
fi

# Verify installation
if [ -L "$SYMLINK_PATH" ] && [ -x "$SYMLINK_PATH" ]; then
    echo -e "${GREEN}✓ Installation successful!${NC}"
    echo -e "${GREEN}You can now use 'odoo-dev' from anywhere${NC}"
    echo -e "\nTo get started:"
    echo -e "  ${YELLOW}odoo-dev help${NC}     - Show available commands"
    echo -e "  ${YELLOW}odoo-dev setup${NC}    - Set up a new Odoo development environment"
    echo -e "\nTo update the tool in the future:"
    echo -e "  ${YELLOW}cd $SCRIPT_DIR && git pull${NC}"
else
    echo -e "${RED}Installation failed${NC}"
    exit 1
fi
