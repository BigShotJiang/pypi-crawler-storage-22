#!/bin/bash

# Define colors for output
GREEN="\033[0;32m"
YELLOW="\033[1;33m"
RED="\033[0;31m"
NC="\033[0m" # No Color

# Get the directory of this script (resolving symlinks)
SOURCE="${BASH_SOURCE[0]}"
while [ -L "$SOURCE" ]; do
  DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
done
SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

# Find the project root directory
# Start with the current working directory
PROJECT_DIR="$(pwd)"

# Walk up the directory tree to find the git repository root
while [ "$PROJECT_DIR" != "/" ]; do
  if [ -d "$PROJECT_DIR/.git" ]; then
    # Found git repository root
    break
  fi
  PROJECT_DIR="$(dirname "$PROJECT_DIR")"
done

# If we didn't find a git repository, use current directory
if [ "$PROJECT_DIR" = "/" ]; then
  PROJECT_DIR="$(pwd)"
fi

echo -e "${GREEN}Using project directory: $PROJECT_DIR${NC}"

# Return to the script directory
cd "$SCRIPT_DIR"

# Load environment variables from .env file if it exists
if [ -f "$PROJECT_DIR/.env" ]; then
  echo -e "${GREEN}Loading environment variables from .env file...${NC}"
  source "$PROJECT_DIR/.env"
fi

# Set environment variables
# These will act as defaults if not set in .env
export ODOO_VERSION=${ODOO_VERSION:-18.0}
export PYTHON_VERSION=${PYTHON_VERSION:-3.12}
# Export the project directory for Docker Compose
export PROJECT_DIR="$PROJECT_DIR"
# Get the parent repo name to use as project name
export PROJECT_NAME=$(basename "$PROJECT_DIR")

# Set -e to exit on error. Important not to do it before determining project directory
# as we actually rely on exit code of git commands to determine if we're in a Git repository
set -e

# Function to show help message
show_help() {
    echo -e "${GREEN}Odoo Development Environment Helper${NC}"
    echo -e "Usage: ./odoo-dev.sh [command] [options]\n"
    echo -e "Commands:"
    echo -e "  ${YELLOW}setup${NC} [--community] Complete setup: clone Odoo repos, configure VSCode, build image"
    echo -e "  ${YELLOW}setup-venv${NC}        Set up local Python virtual environment for development"
    echo -e "  ${YELLOW}start${NC}             Start Odoo and PostgreSQL containers"
    echo -e "  ${YELLOW}stop${NC}              Stop all containers"
    echo -e "  ${YELLOW}restart${NC}           Restart all containers"
    echo -e "  ${YELLOW}logs${NC}              Show logs from the Odoo container"
    echo -e "  ${YELLOW}shell${NC} db          Open a shell in the Odoo container with database context"
    echo -e "  ${YELLOW}psql${NC}              Open a PostgreSQL shell"
    echo -e "  ${YELLOW}debug${NC}             Show VSCode debugging instructions"
    echo -e "  ${YELLOW}db-restore${NC} file[.zip|.sql] [db_name]  Restore database from a backup file"
    echo -e "  ${YELLOW}db-drop${NC} db      Drop a database"
    echo -e "  ${YELLOW}db-list${NC}           List all databases"
    echo -e "  ${YELLOW}db-neutralize${NC} [db] Neutralize a database (disable emails, etc.)"
    echo -e "  ${YELLOW}build${NC}             Rebuild the Odoo container"
    echo -e "  ${YELLOW}update${NC} [modules] [db] Update specified modules or all modules if none specified"
    echo -e "  ${YELLOW}test${NC} [modules] [db] Run tests for specified modules (comma-separated) or all modules if none specified"
    echo -e "  ${YELLOW}odoo-update${NC} [--community] Update Odoo repositories only"
    echo -e "  ${YELLOW}vscode${NC}            Set up VSCode configuration for debugging"
    echo -e "  ${YELLOW}help${NC}              Show this help message"
}

# Function to automatically check for updates (lightweight)
auto_check_updates() {
    # Skip auto-update check if explicitly disabled
    if [ "$ODOO_DEV_SKIP_UPDATE" = "1" ]; then
        return 0
    fi
    
    # Save current directory
    ORIGINAL_DIR="$(pwd)"
    
    # Change to script directory
    cd "$SCRIPT_DIR"
    
    # Check if we're in a git repository
    if [ ! -d ".git" ]; then
        cd "$ORIGINAL_DIR"
        return 0
    fi
    
    # Check if there are uncommitted changes - skip auto-update if so
    if ! git diff-index --quiet HEAD -- 2>/dev/null; then
        cd "$ORIGINAL_DIR"
        return 0
    fi
    
    # Get current branch
    CURRENT_BRANCH=$(git symbolic-ref --short HEAD 2>/dev/null || echo "detached")
    
    if [ "$CURRENT_BRANCH" = "detached" ]; then
        cd "$ORIGINAL_DIR"
        return 0
    fi
    
    # Fetch latest changes (quietly)
    if ! git fetch origin 2>/dev/null; then
        cd "$ORIGINAL_DIR"
        return 0
    fi
    
    # Check if there are updates available
    LOCAL_COMMIT=$(git rev-parse HEAD 2>/dev/null)
    REMOTE_COMMIT=$(git rev-parse origin/$CURRENT_BRANCH 2>/dev/null)
    
    if [ "$LOCAL_COMMIT" = "$REMOTE_COMMIT" ]; then
        cd "$ORIGINAL_DIR"
        echo -e "${GREEN}odoo-dev tool is already up to date!${NC}"
        return 0
    fi
    
    # Updates available - show notification and update
    echo -e "${YELLOW}🔄 Updates available for odoo-dev tool!${NC}"
    git log --oneline --no-decorate $LOCAL_COMMIT..$REMOTE_COMMIT | head -3
    
    # Perform the update
    echo -e "${GREEN}Auto-updating odoo-dev tool...${NC}"
    if git pull --ff-only origin $CURRENT_BRANCH >/dev/null 2>&1; then
        echo -e "${GREEN}✅ odoo-dev tool updated successfully!${NC}"
        echo -e "${YELLOW}Note: Restart the command to use the latest version.${NC}"
    else
        echo -e "${YELLOW}⚠️  Auto-update failed. Run 'odoo-dev self-update' for details.${NC}"
    fi
    
    cd "$ORIGINAL_DIR"
    return 0
}

# Function to update the odoo-dev tool itself (manual/verbose)
self_update() {
    echo -e "${GREEN}Checking for odoo-dev tool updates...${NC}"
    
    # Save current directory
    ORIGINAL_DIR="$(pwd)"
    
    # Change to script directory
    cd "$SCRIPT_DIR"
    
    # Check if we're in a git repository
    if [ ! -d ".git" ]; then
        echo -e "${RED}Error: odoo-dev tool is not in a git repository. Cannot update.${NC}"
        echo -e "${YELLOW}Please reinstall using the installation instructions.${NC}"
        cd "$ORIGINAL_DIR"
        return 1
    fi
    
    # Check if there are uncommitted changes
    if ! git diff-index --quiet HEAD --; then
        echo -e "${YELLOW}Warning: There are uncommitted changes in the odoo-dev repository.${NC}"
        echo -e "${YELLOW}Stashing changes before update...${NC}"
        git stash push -m "Auto-stash before self-update $(date)"
        STASHED=true
    else
        STASHED=false
    fi
    
    # Fetch latest changes
    echo -e "${GREEN}Fetching latest changes...${NC}"
    if ! git fetch origin; then
        echo -e "${RED}Error: Failed to fetch updates from remote repository.${NC}"
        echo -e "${YELLOW}Please check your internet connection and try again.${NC}"
        cd "$ORIGINAL_DIR"
        return 1
    fi
    
    # Get current branch
    CURRENT_BRANCH=$(git symbolic-ref --short HEAD 2>/dev/null || echo "detached")
    
    if [ "$CURRENT_BRANCH" = "detached" ]; then
        echo -e "${RED}Error: Currently in detached HEAD state. Cannot update.${NC}"
        echo -e "${YELLOW}Please check out a branch first.${NC}"
        cd "$ORIGINAL_DIR"
        return 1
    fi
    
    # Check if there are updates available
    LOCAL_COMMIT=$(git rev-parse HEAD)
    REMOTE_COMMIT=$(git rev-parse origin/$CURRENT_BRANCH)
    
    if [ "$LOCAL_COMMIT" = "$REMOTE_COMMIT" ]; then
        echo -e "${GREEN}odoo-dev tool is already up to date!${NC}"
        if [ "$STASHED" = true ]; then
            echo -e "${GREEN}Restoring stashed changes...${NC}"
            git stash pop
        fi
        cd "$ORIGINAL_DIR"
        return 0
    fi
    
    # Show what will be updated
    echo -e "${YELLOW}Updates available:${NC}"
    git log --oneline $LOCAL_COMMIT..$REMOTE_COMMIT
    
    # Perform the update
    echo -e "${GREEN}Updating odoo-dev tool...${NC}"
    if git pull --ff-only origin $CURRENT_BRANCH; then
        echo -e "${GREEN}odoo-dev tool updated successfully!${NC}"
        
        # Restore stashed changes if any
        if [ "$STASHED" = true ]; then
            echo -e "${GREEN}Restoring stashed changes...${NC}"
            if ! git stash pop; then
                echo -e "${YELLOW}Warning: Failed to restore stashed changes automatically.${NC}"
                echo -e "${YELLOW}You can restore them manually with: git stash pop${NC}"
            fi
        fi
        
        echo -e "${YELLOW}Note: If you installed odoo-dev globally, the updated version is now active.${NC}"
    else
        echo -e "${RED}Error: Failed to update odoo-dev tool.${NC}"
        echo -e "${YELLOW}This might be due to merge conflicts or other git issues.${NC}"
        echo -e "${YELLOW}You may need to resolve conflicts manually or reinstall the tool.${NC}"
        
        # Restore stashed changes if any
        if [ "$STASHED" = true ]; then
            echo -e "${GREEN}Restoring stashed changes...${NC}"
            git stash pop
        fi
        
        cd "$ORIGINAL_DIR"
        return 1
    fi
    
    cd "$ORIGINAL_DIR"
    return 0
}

# Function to set up Odoo configuration files
setup_odoo_config() {
    local community_only=false

    # Parse command line arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            --community)
                community_only=true
                shift
                ;;
            *)
                shift
                ;;
        esac
    done

    local local_target_dir="$PROJECT_DIR/conf"
    local local_config_file="$local_target_dir/odoo.conf"
    
    # Docker container config
    local docker_config_file="$SCRIPT_DIR/odoo.conf"
    local template_file="$SCRIPT_DIR/templates/odoo.conf"
    
    # Create local conf directory if it doesn't exist
    mkdir -p "$local_target_dir"
    
    # Check if local config file already exists
    local overwrite_local=true
    if [ -f "$local_config_file" ]; then
        echo -e "${YELLOW}Local configuration file already exists at $local_config_file${NC}"
        read -p "Do you want to overwrite it? (y/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            overwrite_local=true
        else
            overwrite_local=false
            echo -e "${GREEN}Using existing local configuration file.${NC}"
        fi
    fi

    # Prompt for admin password with default value
    local default_admin_password="abc123"
    read -s -p "Admin password [$default_admin_password]: " admin_password
    echo
    admin_password="${admin_password:-$default_admin_password}"
    
    # Always generate Docker config with static values
    local overwrite_docker=true
    echo -e "${GREEN}Generating Docker configuration with static values...${NC}"
    
    if [ "$overwrite_local" = false ] && [ "$overwrite_docker" = false ]; then
        return 0
    fi
    
    # Prompt for database configuration
    echo -e "${GREEN}Configuring Odoo database settings${NC}"
    
    # Default values for local development
    local local_db_user="odoo"
    local local_db_password="odoo"
    
    if [ "$overwrite_local" = true ]; then 
        
        # Prompt for local development values
        echo -e "${GREEN}Local Development Configuration:${NC}"
        
        read -p "Database user [$local_db_user]: " input_db_user
        local_db_user="${input_db_user:-$local_db_user}"
        
        read -s -p "Database password [$local_db_password]: " input_db_password
        echo
        local_db_password="${input_db_password:-$local_db_password}"

        echo -e "${GREEN}Generating local configuration file at $local_config_file${NC}"
        
        # Define the addons path for local development
        local LOCAL_ADDONS_PATH="$PROJECT_DIR/odoo/addons,$PROJECT_DIR/odoo/odoo/addons,$PROJECT_DIR/enterprise,$PROJECT_DIR/design-themes,$PROJECT_DIR/addons"

        # Ask about creating database user for local development
        read -p "Create local database user '$local_db_user' with 'createdb' privileges? (y/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            echo -e "${GREEN}Creating local database user '$local_db_user'...${NC}"
            if ! psql -d postgres -c "CREATE USER \"$local_db_user\" WITH PASSWORD '$local_db_password' CREATEDB;" 2>/dev/null; then
                echo -e "${YELLOW}User '$local_db_user' might already exist. Continuing...${NC}"
            fi
        fi
        
        # Create the config file with the correct addons path
        sed -e "s|{{ADMIN_PASSWORD}}|$admin_password|g" \
            -e "/^db_host/d" \
            -e "/^db_port/d" \
            -e "/^data_dir/d" \
            -e "s|{{DB_USER}}|$local_db_user|g" \
            -e "s|{{DB_PASSWORD}}|$local_db_password|g" \
            -e "s|{{ADDONS_PATH}}|$LOCAL_ADDONS_PATH|g" \
            "$template_file" > "$local_config_file"
        
        chmod 600 "$local_config_file"
        echo -e "${GREEN}Local configuration file generated successfully!${NC}"
    fi
    
    
    # Generate Docker config file if needed
    if [ "$overwrite_docker" = true ]; then
        # Default values for Docker container
        local docker_db_host="db"
        local docker_db_port="5432"
        local docker_db_user="odoo"
        local docker_db_password="odoo"
        
        # Docker container values are static
        echo -e "\n${GREEN}Docker Container Configuration:${NC}"
        echo "Using static Docker configuration:"
        echo "- Database host: $docker_db_host"
        echo "- Database port: $docker_db_port"
        echo "- Database user: $docker_db_user"
        echo "- Database password: [hidden]"

        echo -e "${GREEN}Generating Docker configuration file at $docker_config_file${NC}"
        
        # Define the addons path for Docker 
        local DOCKER_ADDONS_PATH="/opt/project/odoo/addons,/opt/project/odoo/odoo/addons"
        
        # Add enterprise and design themes if not community only
        if [ "$community_only" = false ]; then
            DOCKER_ADDONS_PATH="$DOCKER_ADDONS_PATH,/opt/project/enterprise,/opt/project/design-themes"
        fi
        
        # Add project addons
        DOCKER_ADDONS_PATH="$DOCKER_ADDONS_PATH,/opt/project/addons"
        
        sed -e "s|{{ADMIN_PASSWORD}}|$admin_password|g" \
            -e "s|{{DB_HOST}}|$docker_db_host|g" \
            -e "s|{{DB_PORT}}|$docker_db_port|g" \
            -e "s|{{DB_USER}}|$docker_db_user|g" \
            -e "s|{{DB_PASSWORD}}|$docker_db_password|g" \
            -e "s|{{ADDONS_PATH}}|$DOCKER_ADDONS_PATH|g" \
            "$template_file" > "$docker_config_file"
        
        chmod 600 "$docker_config_file"
        echo -e "${GREEN}Docker configuration file generated successfully!${NC}"
    fi
    
    echo -e "\n${YELLOW}Admin password: $admin_password${NC}"
    echo -e "${YELLOW}Keep this password safe! It won't be shown again.${NC}"
}

# Function to set environment variables is now defined at the top of the script

# Function to start containers
start_containers() {
    echo -e "${GREEN}Starting Odoo ($ODOO_VERSION) with Python $PYTHON_VERSION...${NC}"
    cd "$SCRIPT_DIR"
    
    # Check if odoo.conf exists, create it if not
    if [ ! -f "odoo.conf" ]; then
        echo -e "${YELLOW}Config file not found. Creating default configuration...${NC}"
        cp templates/odoo.conf .
    fi
    
    # Start the containers
    if ! docker compose --project-name "$PROJECT_NAME" up -d; then
        echo -e "${RED}Failed to start containers. Check the logs for more information.${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}Odoo is starting up...${NC}"
    echo -e "${GREEN}Web interface: http://localhost:8069${NC}"
    echo -e "${GREEN}Debug port: localhost:5678${NC}"
}

# Function to stop containers
stop_containers() {
    echo -e "${GREEN}Stopping containers...${NC}"
    cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" down
}

# Function to restart containers
restart_containers() {
    stop_containers
    start_containers
}

# Function to show logs
show_logs() {
    echo -e "${GREEN}Showing logs from Odoo container...${NC}"
    cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" logs -f odoo
}

# Function to open a shell in the Odoo container
open_shell() {
    if [ -z "$1" ]; then
        echo -e "${RED}Error: No database name specified${NC}"
        echo -e "Usage: ./odoo-dev.sh shell database_name"
        exit 1
    fi

    DB_NAME=$1
    echo -e "${GREEN}Opening shell in Odoo container with database $DB_NAME...${NC}"
    cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" exec odoo python /opt/project/odoo/odoo-bin shell -d "$DB_NAME" -c /etc/odoo/odoo.conf --no-http
}

# Function to open a PostgreSQL shell
open_psql() {
    echo -e "${GREEN}Opening PostgreSQL shell...${NC}"
    cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" exec db psql -U odoo postgres
}

# Function to show debugging instructions
show_debug_info() {
    echo -e "${GREEN}VSCode Debugging Instructions${NC}"
    echo -e "\nOdoo is already running with debugpy enabled on port 5678."
    echo -e "To debug your Odoo application:"
    echo -e "  1. Set breakpoints in your code"
    echo -e "  2. Go to the 'Run and Debug' view in VSCode (Ctrl+Shift+D or Cmd+Shift+D)"
    echo -e "  3. Select 'Odoo Docker: Debug' from the dropdown menu"
    echo -e "  4. Click the green play button or press F5"
    echo -e "\nThe debugger will attach to the running Odoo process and stop at your breakpoints."
}

# Function to restore a database from a backup file
restore_database() {
    if [ -z "$1" ]; then
        echo -e "${RED}Error: No backup file specified${NC}"
        echo -e "Usage: ./odoo-dev.sh db-restore /path/to/backup.[zip|sql] [new_database_name]"
        exit 1
    fi

    # Get absolute path of backup file
    BACKUP_FILE=$(realpath "$1")
    FILE_EXT="${BACKUP_FILE##*.}"
    BACKUP_FILENAME=$(basename "$BACKUP_FILE")

    # Determine database name - use provided name or derive from filename
    if [ -z "$2" ]; then
        # No custom name provided, derive from filename
        if [ "$FILE_EXT" = "zip" ]; then
            DB_NAME=$(basename "$BACKUP_FILE" .zip)
        else
            DB_NAME=$(basename "$BACKUP_FILE" .sql)
        fi
    else
        # Use the provided custom database name
        DB_NAME=$2
    fi

    # Check if database already exists
    echo -e "${YELLOW}Checking if database $DB_NAME already exists...${NC}"
    DB_EXISTS=$(cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" run --rm \
        -e PGPASSWORD="odoo" \
        odoo sh -c "psql -h db -U odoo -lqt | cut -d \| -f 1 | grep -qw '$DB_NAME' && echo 'exists' || echo 'not_exists'")

    if [[ "$DB_EXISTS" == *"exists"* ]]; then
        echo -e "${YELLOW}Warning: Database $DB_NAME already exists.${NC}"
        echo -e "${YELLOW}Do you want to drop the existing database and restore from backup?${NC}"
        read -p "This will permanently delete the existing database. Continue? (y/n) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            echo -e "${GREEN}Database restore cancelled.${NC}"
            return 0
        fi

        # Drop the existing database
        echo -e "${YELLOW}Dropping existing database $DB_NAME...${NC}"
        cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" run --rm \
            -e PGPASSWORD="odoo" \
            odoo sh -c "dropdb -h db -U odoo '$DB_NAME'"
    fi

    # Stop Odoo container to prevent cron jobs from running during restore
    echo -e "${YELLOW}Stopping Odoo container...${NC}"
    cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" stop odoo

    echo -e "${GREEN}Restoring database $DB_NAME from $BACKUP_FILE...${NC}"

    # Handle different file types
    if [ "$FILE_EXT" = "zip" ]; then
        # For .zip files, use Odoo's db load command
        cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" run --rm \
            -v "$BACKUP_FILE:/tmp/backup.$FILE_EXT:ro" \
            odoo python /opt/project/odoo/odoo-bin db \
            -c /etc/odoo/odoo.conf \
            load \
            "$DB_NAME" \
            "/tmp/backup.$FILE_EXT"
    elif [ "$FILE_EXT" = "sql" ]; then
        # For .sql files, use Odoo's db load command
        cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" run --rm \
            -v "$BACKUP_FILE:/tmp/backup.$FILE_EXT:ro" \
            -e PGPASSWORD="odoo" \
            odoo sh -c "createdb -h db -U odoo && psql -h db -U odoo '$DB_NAME' < '/tmp/backup.$FILE_EXT'"
    else
        # For .dump files, use pg_restore
        cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" run --rm \
            -v "$BACKUP_FILE:/tmp/backup.$FILE_EXT:ro" \
            -e PGPASSWORD="odoo" \
            odoo sh -c "createdb -h db -U odoo '$DB_NAME' && pg_restore --no-owner -h db -U odoo -d '$DB_NAME' '/tmp/backup.$FILE_EXT'"
    fi

    # Always neutralize the database after restore
    neutralize_database "$DB_NAME"

    # Restart Odoo container
    echo -e "${GREEN}Restarting Odoo container...${NC}"
    cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" start odoo
}

# Function to drop a database
drop_database() {
    if [ -z "$1" ]; then
        echo -e "${RED}Error: No database name specified${NC}"
        echo -e "Usage: ./odoo-dev.sh db-drop database_name"
        exit 1
    fi

    DB_NAME=$1

    echo -e "${YELLOW}Warning: You are about to drop database $DB_NAME. This action cannot be undone.${NC}"
    read -p "Are you sure you want to continue? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo -e "${GREEN}Dropping database $DB_NAME...${NC}"
        cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" run --rm \
            odoo python /opt/project/odoo/odoo-bin \
            db \
            -c /etc/odoo/odoo.conf \
            drop \
            "$DB_NAME"
        echo -e "${GREEN}Database $DB_NAME has been dropped.${NC}"
    else
        echo -e "${GREEN}Database drop cancelled.${NC}"
    fi
}

# Function to list all databases
list_databases() {
    echo -e "${GREEN}Listing all databases...${NC}"
    cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" run --rm \
        odoo python /opt/project/odoo/odoo-bin \
        db \
        -c /etc/odoo/odoo.conf \
        list
}

# Function to neutralize a database (disable emails, etc.)
neutralize_database() {
    if [ -z "$1" ]; then
        echo -e "${RED}Error: No database name specified${NC}"
        echo -e "Usage: ./odoo-dev.sh db-neutralize database_name"
        exit 1
    fi

    DB_NAME=$1

    echo -e "${GREEN}Neutralizing database $DB_NAME...${NC}"
    cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" run --rm \
        odoo python /opt/project/odoo/odoo-bin \
        neutralize \
        -c /etc/odoo/odoo.conf \
        -d "$DB_NAME"

    echo -e "${GREEN}Database $DB_NAME has been neutralized.${NC}"
}

# Function to build the Docker image
build_image() {
    local community_only=false

    # Parse arguments
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --community)
                community_only=true
                shift
                ;;
            *)
                shift
                ;;
        esac
    done

    echo -e "${GREEN}Preparing isolated build context...${NC}"

    # Create temporary build directory for this project
    BUILD_CONTEXT="$PROJECT_DIR/.odoo-build-$$"
    mkdir -p "$BUILD_CONTEXT"

    # Copy all necessary files to build context
    echo -e "${GREEN}Setting up build context at $BUILD_CONTEXT...${NC}"
    cp "$SCRIPT_DIR/Dockerfile" "$BUILD_CONTEXT/"
    cp "$SCRIPT_DIR/docker-entrypoint.sh" "$BUILD_CONTEXT/"
    cp "$SCRIPT_DIR/odoo.conf" "$BUILD_CONTEXT/odoo.conf"

    # Copy requirements.txt from project root
    echo -e "${GREEN}Copying requirements.txt from project root...${NC}"
    cp "$PROJECT_DIR/requirements.txt" "$BUILD_CONTEXT/" 2>/dev/null || echo -e "${YELLOW}Warning: Could not copy requirements.txt${NC}"
    echo -e "${GREEN}Copying Odoo's requirements.txt from project root...${NC}"
    cp "$PROJECT_DIR/odoo/requirements.txt" "$BUILD_CONTEXT/odoo-requirements.txt" 2>/dev/null || echo -e "${YELLOW}Warning: Could not copy odoo's requirements.txt${NC}"

    # Create docker-compose.yml in build context pointing to the right image
    cat > "$BUILD_CONTEXT/docker-compose.yml" << EOF
name: \${PROJECT_NAME:-odoo}

services:
  odoo:
    image: \${PROJECT_NAME:-odoo-deploy}-odoo:\${ODOO_VERSION:-17.0}
    build:
      context: .
      dockerfile: Dockerfile
      args:
        - ODOO_VERSION=\${ODOO_VERSION:-17.0}
        - PYTHON_VERSION=\${PYTHON_VERSION:-3.12}
      platforms:
        - linux/amd64
EOF

    # Build the Docker image with project name
    echo -e "${GREEN}Rebuilding Odoo image ($PROJECT_NAME-odoo:$ODOO_VERSION)...${NC}"
    cd "$BUILD_CONTEXT" && PROJECT_NAME="$PROJECT_NAME" docker compose build --build-arg ODOO_VERSION=$ODOO_VERSION --build-arg PYTHON_VERSION=$PYTHON_VERSION odoo

    # Clean up temporary build context
    echo -e "${GREEN}Cleaning up build context...${NC}"
    rm -rf "$BUILD_CONTEXT"
}

# Function to update modules
update_modules() {
    MODULES=$1
    if [ -z "$MODULES" ]; then
        MODULES="all"
    fi

    DB_NAME=$2
    if [ -z "$DB_NAME" ]; then
        DB_NAME="odoo"
    fi

    echo -e "${GREEN}Stopping Odoo container...${NC}"
    cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" stop odoo

    echo -e "${GREEN}Updating modules: $MODULES...${NC}"
    cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" run --rm \
        -v "$PROJECT_DIR:/opt/project" \
        odoo python /opt/project/odoo/odoo-bin -c /etc/odoo/odoo.conf -u "$MODULES" -d "$DB_NAME" --stop-after-init

    echo -e "${GREEN}Restarting Odoo container...${NC}"
    cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" start odoo
}

# Function to run tests
run_tests() {
    MODULES=$1
    if [ -n "$MODULES" ]; then
        TAGS="/${MODULES//,/,/}"
    fi
    DB_NAME=$2
    if [ -z "$DB_NAME" ]; then
        DB_NAME="test"
    fi

    echo -e "${GREEN}Running tests for modules: $MODULES...${NC}"
    cd "$SCRIPT_DIR" && docker compose --project-name "$PROJECT_NAME" run --rm odoo python /opt/project/odoo/odoo-bin -c /etc/odoo/odoo.conf -i "$MODULES" -u "$MODULES" --test-tags "$TAGS" --stop-after-init -d "$DB_NAME"
}

# Function to set up VSCode configuration
setup_vscode_config() {
    echo -e "${GREEN}Setting up VSCode configuration...${NC}"

    # Create .vscode directory if it doesn't exist
    mkdir -p "$PROJECT_DIR/.vscode"

    # Copy template files to .vscode directory
    TEMPLATE_DIR="$SCRIPT_DIR/templates/vscode"

    # Copy launch.json
    echo -e "Copying launch.json..."
    cp "$TEMPLATE_DIR/launch.json" "$PROJECT_DIR/.vscode/launch.json"

    # Copy tasks.json
    echo -e "Copying tasks.json..."
    cp "$TEMPLATE_DIR/tasks.json" "$PROJECT_DIR/.vscode/tasks.json"

    # Copy settings.json if it doesn't exist
    if [ ! -f "$PROJECT_DIR/.vscode/settings.json" ]; then
        echo -e "Copying settings.json..."
        cp "$TEMPLATE_DIR/settings.json" "$PROJECT_DIR/.vscode/settings.json"
    else
        echo -e "${YELLOW}settings.json already exists. Skipping...${NC}"
    fi

    echo -e "${GREEN}VSCode configuration has been set up successfully!${NC}"
    echo -e "You can now use the VSCode debugger to debug your Odoo application."
    echo -e "Available configurations:"
    echo -e "  - ${YELLOW}Odoo Docker: Debug${NC} - Attach to the running Odoo instance"
    echo -e "  - ${YELLOW}Odoo Docker: Update Module${NC} - Update a specific module and attach debugger"
    echo -e "  - ${YELLOW}Odoo Docker: Shell${NC} - Start an Odoo shell and attach debugger"
}

# Function to update Python path in virtual environment
update_python_path() {
    local activate_script="$PROJECT_DIR/venv/bin/activate"
    
    if [ -f "$activate_script" ]; then
        # Remove any existing PYTHONPATH modifications
        sed -i.bak '/# Odoo PYTHONPATH setup/,/# End Odoo PYTHONPATH setup/d' "$activate_script"
        
        # Add new PYTHONPATH setup
        cat >> "$activate_script" << 'EOF'

# Odoo PYTHONPATH setup
if [ -z "$_OLD_VIRTUAL_PYTHONPATH" ]; then
    _OLD_VIRTUAL_PYTHONPATH="$PYTHONPATH"
fi

# Build PYTHONPATH with all Odoo directories
ODOO_PYTHONPATH=""
for dir in "odoo" "enterprise" "design-themes" "industry"; do
    if [ -d "$VIRTUAL_ENV/../$dir" ]; then
        if [ -z "$ODOO_PYTHONPATH" ]; then
            ODOO_PYTHONPATH="$VIRTUAL_ENV/../$dir"
        else
            ODOO_PYTHONPATH="$ODOO_PYTHONPATH:$VIRTUAL_ENV/../$dir"
        fi
    fi
done

# Add custom addons if they exist
if [ -d "$VIRTUAL_ENV/../addons" ]; then
    if [ -z "$ODOO_PYTHONPATH" ]; then
        ODOO_PYTHONPATH="$VIRTUAL_ENV/../addons"
    else
        ODOO_PYTHONPATH="$ODOO_PYTHONPATH:$VIRTUAL_ENV/../addons"
    fi
fi

# Set PYTHONPATH
if [ -n "$ODOO_PYTHONPATH" ]; then
    if [ -n "$_OLD_VIRTUAL_PYTHONPATH" ]; then
        PYTHONPATH="$ODOO_PYTHONPATH:$_OLD_VIRTUAL_PYTHONPATH"
    else
        PYTHONPATH="$ODOO_PYTHONPATH"
    fi
    export PYTHONPATH
fi

# Restore original PYTHONPATH on deactivate
if [ -n "$_OLD_VIRTUAL_PYTHONPATH" ]; then
    _OLD_VIRTUAL_DEACTIVATE="$deactivate"
    deactivate() {
        if [ -n "$_OLD_VIRTUAL_PYTHONPATH" ]; then
            PYTHONPATH="$_OLD_VIRTUAL_PYTHONPATH"
            export PYTHONPATH
            unset _OLD_VIRTUAL_PYTHONPATH
        else
            unset PYTHONPATH
        fi
        
        if [ -n "$_OLD_VIRTUAL_DEACTIVATE" ]; then
            eval "$_OLD_VIRTUAL_DEACTIVATE"
            unset _OLD_VIRTUAL_DEACTIVATE
        fi
    }
fi
# End Odoo PYTHONPATH setup
EOF
        echo -e "${GREEN}PYTHONPATH updated in virtual environment activation script.${NC}"
    else
        echo -e "${RED}Virtual environment activation script not found at $activate_script${NC}"
    fi
}

# Function to set up local Python virtual environment
setup_local_venv() {
    # Setup Odoo configuration first
    setup_odoo_config
    echo -e "${GREEN}Setting up local Python virtual environment for Odoo $ODOO_VERSION...${NC}"
    
    # Function to install system dependencies
    install_system_dependencies() {
        echo -e "${GREEN}Installing system dependencies...${NC}"
        
        if [[ "$OSTYPE" == "darwin"* ]]; then
            # macOS
            echo -e "${YELLOW}Installing dependencies for macOS...${NC}"
            
            # Check if Homebrew is installed
            if ! command -v brew &> /dev/null; then
                echo -e "${YELLOW}Homebrew not found. Installing Homebrew...${NC}"
                /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
            fi

            # Install dependencies
            echo -e "${YELLOW}Installing dependencies with Homebrew...${NC}"
            brew install postgresql libpq openssl libxml2 libxslt zlib freetype libpng libjpeg webp openjdk

            # Set up Java environment variables if needed
            if [[ -d "/opt/homebrew/opt/openjdk/bin" ]]; then
                echo -e "${YELLOW}Adding OpenJDK to PATH...${NC}"
                export PATH="/opt/homebrew/opt/openjdk/bin:$PATH"
                export CPPFLAGS="-I/opt/homebrew/opt/openjdk/include"
            fi

            # Install wkhtmltopdf from official release since the cask is discontinued
            if ! command -v wkhtmltopdf &> /dev/null; then
                echo -e "${YELLOW}Installing wkhtmltopdf from official release...${NC}"
                # Create temp directory for download
                TEMP_DIR=$(mktemp -d)
                cd "$TEMP_DIR"

                # Download and install wkhtmltopdf
                curl -L https://github.com/wkhtmltopdf/packaging/releases/download/0.12.6.1-3/wkhtmltox-0.12.6.1-3.macos-cocoa.pkg -o wkhtmltox.pkg
                sudo installer -pkg wkhtmltox.pkg -target /

                # Clean up
                cd - > /dev/null
                rm -rf "$TEMP_DIR"

                # Verify installation
                if command -v wkhtmltopdf &> /dev/null; then
                    echo -e "${GREEN}wkhtmltopdf installed successfully.${NC}"
                else
                    echo -e "${RED}Failed to install wkhtmltopdf. Please install it manually from https://wkhtmltopdf.org/downloads.html${NC}"
                fi
            else
                echo -e "${GREEN}wkhtmltopdf already installed.${NC}"
            fi

            # Node.js and less
            if ! command -v node &> /dev/null; then
                brew install node
            fi
            if ! command -v lessc &> /dev/null; then
                npm install -g less less-plugin-clean-css
            fi

        elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
            # Debian/Ubuntu
            echo -e "${YELLOW}Installing dependencies with apt...${NC}"
            sudo apt-get update
            sudo apt-get install -y --no-install-recommends \
                build-essential \
                libldap2-dev \
                libpq-dev \
                libsasl2-dev \
                libssl-dev \
                libxml2-dev \
                libxslt1-dev \
                node-less \
                npm \
                postgresql-client \
                python3.12-dev \
                python3.12-venv \
                git

            # Install wkhtmltopdf if not present
            if ! command -v wkhtmltopdf &> /dev/null; then
                echo -e "${YELLOW}Installing wkhtmltopdf...${NC}"
                . /etc/os-release
                UBUNTU_CODE="${UBUNTU_CODENAME:-$VERSION_CODENAME}"
                WKHTML_URL=""
                if [[ "$ID" == "ubuntu" || "$ID_LIKE" == *"ubuntu"* ]]; then
                    # Ubuntu or Ubuntu-based (e.g., Pop!_OS). Prefer jammy build which is known to work for Odoo.
                    # Use the same jammy build for both 22.04 (jammy) and 24.04 (noble) for compatibility.
                    if [[ "$UBUNTU_CODE" == "jammy" || "$VERSION_ID" == "22.04" || "$UBUNTU_CODE" == "noble" || "$VERSION_ID" == "24.04" ]]; then
                        WKHTML_URL="https://github.com/wkhtmltopdf/packaging/releases/download/0.12.6.1-2/wkhtmltox_0.12.6.1-2.jammy_amd64.deb"
                    else
                        echo -e "${RED}Unsupported Ubuntu version ($UBUNTU_CODE). Please install wkhtmltopdf manually from https://wkhtmltopdf.org/downloads.html${NC}"
                        return 1
                    fi
                else
                    echo -e "${RED}Non-Ubuntu system detected. This script only supports Ubuntu 22.04/24.04 (and derivatives).${NC}"
                    return 1
                fi

                # Download with retries
                sudo rm -f /tmp/wkhtmltox.deb || true
                if ! sudo curl -fL --retry 3 --retry-connrefused -o /tmp/wkhtmltox.deb "$WKHTML_URL"; then
                    echo -e "${RED}Failed to download wkhtmltopdf package from $WKHTML_URL${NC}"
                fi

                # Validate the downloaded deb and install; if jammy fails on Ubuntu-based, try focal as fallback
                if dpkg-deb -I /tmp/wkhtmltox.deb >/dev/null 2>&1; then
                    sudo dpkg -i /tmp/wkhtmltox.deb || true
                    sudo apt-get -f install -y
                    sudo rm -f /tmp/wkhtmltox.deb
                else
                    if [[ "$UBUNTU_CODE" == "noble" ]]; then
                        echo -e "${YELLOW}Primary package invalid. Retrying with jammy build for Ubuntu 24.04 (noble)...${NC}"
                        sudo curl -fL --retry 3 --retry-connrefused -o /tmp/wkhtmltox.deb "https://github.com/wkhtmltopdf/packaging/releases/download/0.12.6.1-2/wkhtmltox_0.12.6.1-2.jammy_amd64.deb"
                    else
                        echo -e "${YELLOW}Primary package invalid. Retrying with focal build for Ubuntu 22.04 (jammy)...${NC}"
                        sudo curl -fL --retry 3 --retry-connrefused -o /tmp/wkhtmltox.deb "https://github.com/wkhtmltopdf/packaging/releases/download/0.12.6-1/wkhtmltox_0.12.6-1.focal_amd64.deb"
                    fi
                    if dpkg-deb -I /tmp/wkhtmltox.deb >/dev/null 2>&1; then
                        sudo dpkg -i /tmp/wkhtmltox.deb || true
                        sudo apt-get -f install -y
                        sudo rm -f /tmp/wkhtmltox.deb
                    else
                        echo -e "${RED}Failed to validate wkhtmltopdf packages after fallback. Please download and install manually from https://wkhtmltopdf.org/downloads.html${NC}"
                        sudo rm -f /tmp/wkhtmltox.deb || true
                        return 1
                    fi
                fi
            fi
        else
            echo -e "${RED}Unsupported operating system. Please install dependencies manually.${NC}"
            return 1
        fi

        echo -e "${GREEN}System dependencies installed successfully.${NC}"
        return 0
    }

    # Install system dependencies first
    install_system_dependencies

    # Check if Python version is available and install if needed
    if ! command -v python$PYTHON_VERSION &> /dev/null; then
        echo -e "${YELLOW}Python $PYTHON_VERSION not found. Installing...${NC}"
        if [[ "$OSTYPE" == "linux-gnu"* ]]; then
            # Check Ubuntu version
            . /etc/os-release
            UBUNTU_CODE="${UBUNTU_CODENAME:-$VERSION_CODENAME}"
            if [[ "$ID" == "ubuntu" || "$ID_LIKE" == *"ubuntu"* ]]; then
                if [[ "$UBUNTU_CODE" == "jammy" || "$VERSION_ID" == "22.04" ]]; then
                    # Ubuntu 22.04 needs deadsnakes PPA
                    sudo add-apt-repository -y ppa:deadsnakes/ppa
                    sudo apt-get update
                    sudo apt-get install -y python$PYTHON_VERSION python$PYTHON_VERSION-venv python$PYTHON_VERSION-dev
                else
                    # Ubuntu 24.04 (noble) and other newer Ubuntu-based have suitable versions in standard repos
                    sudo apt-get update
                    sudo apt-get install -y python$PYTHON_VERSION python$PYTHON_VERSION-venv python$PYTHON_VERSION-dev
                fi
            else
                # Generic Debian-based approach
                sudo apt-get update
                sudo apt-get install -y python$PYTHON_VERSION python$PYTHON_VERSION-venv python$PYTHON_VERSION-dev
            fi
        elif [[ "$OSTYPE" == "darwin"* ]]; then
            # macOS
            brew install python@$PYTHON_VERSION
        else
            echo -e "${RED}Unsupported operating system. Please install Python $PYTHON_VERSION manually.${NC}"
            exit 1
        fi
        echo -e "${GREEN}Python $PYTHON_VERSION installed successfully.${NC}"
    fi

    if [ ! -d "$PROJECT_DIR/venv" ]; then
        echo -e "${GREEN}Creating new Python virtual environment...${NC}"
        python$PYTHON_VERSION -m venv "$PROJECT_DIR/venv"
    else
        echo -e "${YELLOW}Virtual environment already exists. Skipping creation.${NC}"
    fi

    # Update PYTHONPATH in activate script
    echo -e "${GREEN}Updating PYTHONPATH in virtual environment...${NC}"
    update_python_path

    # Install requirements
    echo -e "${GREEN}Installing requirements...${NC}"
    source "$PROJECT_DIR/venv/bin/activate"
    pip install --upgrade pip

    # Create requirements file from Odoo requirements
    if [ -f "$PROJECT_DIR/odoo/requirements.txt" ]; then
        echo -e "${GREEN}Installing Odoo requirements...${NC}"

        # Make a copy of the requirements file to modify
        cp "$PROJECT_DIR/odoo/requirements.txt" "$PROJECT_DIR/temp_requirements.txt"

        # Platform-specific modifications
        if [[ "$OSTYPE" == "darwin"* || "$OSTYPE" == "linux-gnu"* ]]; then
            echo -e "${GREEN}Modifying requirements for $OSTYPE...${NC}"
            # Replace psycopg2 with psycopg2-binary
            # Use latest urllib3 to avoid SSL issues
            if [[ "$OSTYPE" == "darwin"* ]]; then
                sed -i '' -e 's/^psycopg2==.*/psycopg2-binary/' "$PROJECT_DIR/temp_requirements.txt"
                sed -i '' -e 's/^urllib3==.*/urllib3/' "$PROJECT_DIR/temp_requirements.txt"
            else
                sed -i -e 's/^psycopg2==.*/psycopg2-binary/' "$PROJECT_DIR/temp_requirements.txt"
                sed -i -e 's/^urllib3==.*/urllib3/' "$PROJECT_DIR/temp_requirements.txt"
            fi
        fi

        # Install modified requirements with better error handling
        if pip install -r "$PROJECT_DIR/temp_requirements.txt"; then
            echo -e "${GREEN}Odoo requirements installed successfully${NC}"
        else
            echo -e "${RED}Failed to install Odoo requirements${NC}"
        fi
        rm -f "$PROJECT_DIR/temp_requirements.txt"
    else
        echo -e "${YELLOW}Warning: Odoo requirements.txt not found at $PROJECT_DIR/odoo/requirements.txt${NC}"
        echo -e "${YELLOW}Skipping Odoo requirements installation${NC}"
    fi

    # Install project-specific requirements if they exist
    if [ -f "$PROJECT_DIR/requirements.txt" ]; then
        echo -e "${GREEN}Installing project-specific requirements...${NC}"
        if pip install -r "$PROJECT_DIR/requirements.txt"; then
            echo -e "${GREEN}Project requirements installed successfully${NC}"
        else
            echo -e "${RED}Failed to install project requirements${NC}"
        fi
    else
        echo -e "${YELLOW}No project-specific requirements.txt found${NC}"
    fi

    # Install development tools
    echo -e "${GREEN}Installing development tools...${NC}"
    pip install pytest pytest-odoo debugpy

    # Deactivate virtual environment
    deactivate

    echo -e "${GREEN}Virtual environment setup complete!${NC}"
    echo -e "${YELLOW}To activate the virtual environment, run:${NC}"
    echo -e "source $PROJECT_DIR/venv/bin/activate"
}

# Function to clone or sync Odoo repositories
get_odoo() {
    local community_only=false

    # Parse arguments
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --community)
                community_only=true
                shift
                ;;
            *)
                shift
                ;;
        esac
    done

    echo -e "${GREEN}Setting up Odoo repositories...${NC}"
    if [ "$community_only" = true ]; then
        echo -e "${YELLOW}Community edition mode: Enterprise repositories will be skipped${NC}"
    fi

    # Define repositories to clone
    REPOS=("git@github.com:odoo/odoo.git|odoo|$ODOO_VERSION"
           "git@github.com:odoo/design-themes.git|design-themes|$ODOO_VERSION")
    # Add industry repo for Odoo 18
    if [[ "$ODOO_VERSION" == "18.0" ]]; then
        REPOS+=("git@github.com:odoo/industry.git|industry|$ODOO_VERSION")
    fi

    # Add enterprise repos if not in community mode
    if [ "$community_only" = false ]; then
        REPOS+=("git@github.com:odoo/enterprise.git|enterprise|$ODOO_VERSION")
    fi

    # Create parent directory for repos if it doesn't exist
    cd "$PROJECT_DIR"

    for REPO_INFO in "${REPOS[@]}"; do
        # Parse repo info
        IFS='|' read -r REPO_URL REPO_DIR REPO_BRANCH <<< "$REPO_INFO"

        if [ -d "$REPO_DIR" ]; then
            echo -e "${YELLOW}Updating $REPO_DIR repository...${NC}"
            cd "$REPO_DIR"

            # Check if we're on the right branch
            CURRENT_BRANCH=$(git symbolic-ref --short HEAD 2>/dev/null || echo "detached")

            if [ "$CURRENT_BRANCH" != "$REPO_BRANCH" ]; then
                echo -e "Switching to branch $REPO_BRANCH..."
                # For shallow clones, we need to use --depth when fetching
                git fetch --depth 1 origin $REPO_BRANCH
                git checkout $REPO_BRANCH
            fi

            # Update the repository with --ff-only to avoid merge conflicts in shallow clones
            git pull --ff-only origin $REPO_BRANCH

            # If pull failed (non-zero exit code), try a fresh clone
            if [ $? -ne 0 ]; then
                echo -e "${YELLOW}Pull failed. Repository might be corrupted due to shallow clone limitations.${NC}"
                echo -e "${YELLOW}Removing and re-cloning $REPO_DIR...${NC}"
                cd "$PROJECT_DIR"
                rm -rf "$REPO_DIR"
                git clone --depth 1 --branch $REPO_BRANCH $REPO_URL $REPO_DIR
            else
                cd "$PROJECT_DIR"
            fi
        else
            echo -e "${YELLOW}Cloning $REPO_DIR repository...${NC}"
            git clone --depth 1 --branch $REPO_BRANCH $REPO_URL $REPO_DIR
        fi
    done

    echo -e "${GREEN}Odoo repositories setup complete.${NC}"
}

# Auto-check for updates on every run (except for help and self-update commands)
if [ $# -eq 0 ] || [[ "$1" != "help" && "$1" != "self-update" ]]; then
    auto_check_updates
fi

# Parse command line arguments
if [ $# -eq 0 ]; then
    show_help
    exit 0
fi

COMMAND=$1
shift

case "$COMMAND" in
    setup)
        echo -e "${GREEN}Setting up complete Odoo development environment...${NC}"
        community_flag=""

        # Check if community flag is provided
        if [[ "$1" == "--community" ]]; then
            echo -e "${YELLOW}Setting up Community Edition${NC}"
            community_flag="--community"
            get_odoo --community
            shift
        else
            get_odoo
        fi

        echo -e "\n${GREEN}Setting up VSCode configuration...${NC}"
        setup_vscode_config

        # Set up local virtual environment automatically
        echo -e "\n${GREEN}Setting up local Python virtual environment...${NC}"
        echo -e "${YELLOW}This will install system dependencies and Python $PYTHON_VERSION if needed${NC}"
        # Ensure we're in the project directory for venv setup
        cd "$PROJECT_DIR"
        setup_local_venv

        # Prompt user before setting up Docker environment
        echo -e "\n${YELLOW}Do you want to set up the Docker environment (build image and configure containers)?${NC}"
        echo -e "${YELLOW}This will build the Odoo Docker image and set up the development environment.${NC}"
        read -p "Continue with Docker setup? (y/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            echo -e "\n${GREEN}Building Docker image...${NC}"
            build_image $community_flag
        else
            echo -e "\n${YELLOW}Skipping Docker setup. You can build the image later with: ./odoo-dev.sh build${NC}"
        fi

        echo -e "\n${GREEN}Setup complete! You can now:${NC}"
        echo -e "  - ${YELLOW}Start Odoo with Docker:${NC} ./odoo-dev.sh start"
        echo -e "  - ${YELLOW}Use local Python environment:${NC} source venv/bin/activate"
        echo -e "  - ${YELLOW}Debug with VSCode:${NC} Use the configured launch profiles"
        ;;
    setup-venv)
        echo -e "${GREEN}Setting up local Python virtual environment for Odoo $ODOO_VERSION...${NC}"
        echo -e "${YELLOW}This will install system dependencies and Python $PYTHON_VERSION if needed${NC}"
        setup_local_venv
        echo -e "\n${GREEN}Virtual environment setup complete!${NC}"
        echo -e "${YELLOW}To activate the environment, run:${NC} source venv/bin/activate"
        ;;
    start)
        start_containers
        ;;
    stop)
        stop_containers
        ;;
    restart)
        restart_containers
        ;;
    logs)
        show_logs
        ;;
    shell)
        open_shell "$1"
        ;;
    psql)
        open_psql
        ;;
    debug)
        show_debug_info
        ;;
    db-restore)
        restore_database "$1" "$2"
        ;;
    db-drop)
        drop_database "$1"
        ;;
    db-list)
        list_databases
        ;;
    db-neutralize)
        neutralize_database "$1"
        ;;
    build)
        build_image
        ;;
    update)
        update_modules "$1" "$2"
        ;;
    test)
        run_tests "$1" "$2"
        ;;
    odoo-update)
        # Check if community flag is provided
        if [[ "$1" == "--community" ]]; then
            echo -e "${YELLOW}Updating Odoo Community Edition repositories...${NC}"
            get_odoo --community
        else
            echo -e "${YELLOW}Updating Odoo Enterprise Edition repositories...${NC}"
            get_odoo
        fi
        ;;
    vscode)
        setup_vscode_config
        ;;
    help)
        show_help
        ;;
    *)
        echo -e "${RED}Error: Unknown command $COMMAND${NC}"
        show_help
        exit 1
        ;;
esac
exit 0
