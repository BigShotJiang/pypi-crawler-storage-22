#!/bin/bash

# Odoo Deploy Tool Uninstallation Script

set -e

# Define colors for output
GREEN="\033[0;32m"
YELLOW="\033[1;33m"
RED="\033[0;31m"
NC="\033[0m" # No Color

# Determine possible installation locations
POSSIBLE_PATHS=(
    "/usr/local/bin/odoo-dev"
    "$HOME/bin/odoo-dev"
)

echo -e "${GREEN}Uninstalling Odoo Deploy Tool...${NC}"

FOUND=false

for SYMLINK_PATH in "${POSSIBLE_PATHS[@]}"; do
    if [ -L "$SYMLINK_PATH" ]; then
        echo -e "${YELLOW}Found symlink at: $SYMLINK_PATH${NC}"
        
        # Check if we need sudo
        INSTALL_DIR=$(dirname "$SYMLINK_PATH")
        if [ "$INSTALL_DIR" = "/usr/local/bin" ] && [ "$(id -u)" -ne 0 ] && [ ! -w "/usr/local/bin" ]; then
            echo -e "${YELLOW}Removing symlink (requires sudo)...${NC}"
            sudo rm "$SYMLINK_PATH"
        else
            rm "$SYMLINK_PATH"
        fi
        
        echo -e "${GREEN}✓ Removed symlink from $SYMLINK_PATH${NC}"
        FOUND=true
    elif [ -f "$SYMLINK_PATH" ]; then
        echo -e "${RED}Warning: $SYMLINK_PATH exists but is not a symlink${NC}"
        echo -e "${RED}Please remove it manually if it was installed by this tool${NC}"
        FOUND=true
    fi
done

if [ "$FOUND" = true ]; then
    echo -e "${GREEN}✓ Uninstallation complete!${NC}"
    echo -e "\nNote: This script only removes the symlink."
    echo -e "To completely remove the tool, delete the git repository:"
    echo -e "  ${YELLOW}rm -rf $(dirname "${BASH_SOURCE[0]}")${NC}"
else
    echo -e "${YELLOW}No installation found${NC}"
fi
