find . -type l -exec bash -c '{
    link={}; 
    target=$(readlink "$link"); 
    if [[ $target = /* ]]; then 
        dir=$(dirname "$link"); 
        relative_target=$(realpath --relative-to="$dir" "$target"); 
        rm "$link"; 
        ln -s "$relative_target" "$link"; 
        echo "Converted $link to a relative symlink"; 
    fi 
}' \;

