# Adaptation Odoo 11.0

## account_invoice_reference

Ajoute le champs supplier_invoice_number à account.move.  On devrait valider son utilité en Odoo 15 et si il est utile
le réactiver dans les vues manquantes.

## account_parent

Supprimé, car dans Odoo 15 plus besoin

## baseline_selling_checklist

Ajoute des champs spécifiques à Durpro au niveau de crm.lead et ajout de la table crm.lead.confirmed_problem

## bi_advance_all_in_one_merge_orders

Permet de fusionner des SO, PO et picking

## bi_global_search

Permet d'implémenter une recherche globale dans  le backend de Odoo

## cloud_base

Permet le sotckage dans le nuage (voir google_drive_odoo)

## customer_product_code

Permet d'ajouter un code ou une description particullière pour un client donné

## deltatech_alternative

Permet d'avoir des alternatives au produits

## dev_invoice_multi_payment

!!! A VÉRIFIER si encore utilisé, permet de payer plusieurs facture avec le même chèque

## droggol_mass_mailing_themes

RAPH: Theme pour courriel

## durpro_base

This module is hugly cause there is too much mixted stuff together

## durpro_customer_reference

Déplacement du champs client_order_ref sur la vue ale.view_order_form

## durpro_extended

Permettra d'installer d'un coup et de mettre le bons menus pour Durpro

## durpro_fso

Solution développée pour gérer nos appels de services (un peux comme FSM)

## durpro_report

Les rapport nécessaire à Durpro

## eq_merge_duplicate_data

Module pour fusionner n'importe quoi, nécessaire pour correction et ménge
sans perte d'historique

## google_drive_odoo

Permet le stockage bi-directionnel Odoo/Google Drive

## google_drive_report

!!! Do we need to keep it, I dont thing so with cloud_storage

## le_website_faq_page

RAPH: FAQ pour le website, doit être modifié pour transformer le popup en page complete

## logisitics_extra_info

Sera porté, mais le gros du code est un autre delivery carrier, donc a remplacer par le vrai delivery carrier

## odoo_linkedin

RAPH: plugin linkedin pour publier sur linkedin

## product_configurator

!!! pas utilisé????

## product_landed_cost (devrait s'appeler supplierinfo_cost_discount)

Ajoute la notion de prix de liste et d'escompte pour calculer le coût

## sale_reference (a fusionner dans durpro_customer_reference)

Encore l'ajout de client_order_ref mais sur sale.view_order_tree