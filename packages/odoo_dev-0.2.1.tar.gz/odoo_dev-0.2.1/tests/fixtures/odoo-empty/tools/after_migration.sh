#!/bin/bash
# Script to run some initial cleanup commands after installing a newly migrated Odoo database

psql -d $1 -c "drop table stock_move_invoice_line_rel;"
psql -d $1 -c "delete from durpro_fso_config_partners_rel;"
psql -d $1 -c "delete from mail_template where body_html ilike '%get_portal_confirmation_action%';"
psql -d $1 -c "delete from ir_asset;"
psql -d $1 -c "delete from mail_template;"

odoo/odoo-bin -d $1 -c conf/odoo.conf --update all --stop-after-init
odoo/odoo-bin -d $1 -c conf/odoo.conf --stop-after-init -i modules_cleaner
odoo/odoo-bin -d $1 -c conf/odoo.conf --stop-after-init -i accounting_setup
odoo/odoo-bin -d $1 -c conf/odoo.conf --stop-after-init -i durpro_reports,bi_advance_all_in_one_merge_orders,mrp_production_serial_matrix