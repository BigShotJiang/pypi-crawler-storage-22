-- 2022-10-25 written by Marc Durepos
-- Fixes translations and non-updated email templates carried over from Odoo 11 migration to Odoo 15.
-- These incorrect translations and template body broke the "Send & Print" function in Odoo 15
-- To run in terminal, use psql <dbname> -f <path>/fix_mail_templates.sql

update mail_template set body_html = REPLACE(body_html,'get_mail_url()','access_url') where id=30;

update ir_translation set src = replace(src,'object.get_mail_url()','object.access_url'),
                          value = replace(value, 'object.get_mail_url()', 'object.access_url')
                      where module='account' and src ilike '%object.get_mail_url()%';

update ir_translation set src = replace(src,'object.number','object.name'),
                          value = replace(value, 'object.number', 'object.name')
                      where module='account' and src ilike '%object.number%';

update ir_translation set src = replace(src,'object.origin','object.invoice_origin'),
                          value = replace(value, 'object.origin', 'object.invoice_origin')
                      where module='account' and src ilike '%object.origin%';