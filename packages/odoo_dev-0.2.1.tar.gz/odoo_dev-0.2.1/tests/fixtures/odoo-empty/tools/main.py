import xmlrpc.client
import sqlite3
import pandas as pd
import os

# Informations de connexion à Odoo
url = 'https://odoo17.durpro.com'
db = 'jun5'
username = 'admin'
password = 'hOlw88jYiJBp6F'
db_filename = '/Users/bvezina/sale_data.db'

# Supprimer le fichier de la base de données SQLite s'il existe
if os.path.exists(db_filename):
    os.remove(db_filename)

# Connexion à Odoo via XML-RPC
common = xmlrpc.client.ServerProxy('{}/xmlrpc/2/common'.format(url))
uid = common.authenticate(db, username, password, {})
models = xmlrpc.client.ServerProxy('{}/xmlrpc/2/object'.format(url))

# Vérification de la connexion
if uid:
    print("Connexion réussie à Odoo")
else:
    print("Échec de la connexion à Odoo")
    exit()

# Connexion à la base de données SQLite
sqlite_conn = sqlite3.connect(db_filename)

def get_relation_id(relation):
    if isinstance(relation, list) and len(relation) == 2:
        return relation[0]
    return None

def get_relation_name(relation):
    if isinstance(relation, list) and len(relation) == 2:
        return relation[1]
    return None

# Définition des fonctions de transfert
def transfer_res_partner():
    print("Transfert des partenaires...")

    table_name = 'res_partner'
    fields = [
        'id',
        'display_name',
        'email',
        'phone',
        'customer_rank',
        'country_id',
        'city',
        'zip',
        'company_type',
        'parent_id'
    ]
    domain = [
        ('customer_rank', '>', 1),
        ('active', '=', True)
    ]


    try:
        data = models.execute_kw(db, uid, password, 'res.partner', 'search_read', [domain], {'fields': fields})
    except Exception as e:
        print(f"Erreur lors de la récupération des données: {e}")
        return

    sqlite_cursor = sqlite_conn.cursor()
    sqlite_cursor.execute(f"""
        CREATE TABLE IF NOT EXISTS {table_name} (
            id INTEGER PRIMARY KEY, 
            name TEXT, 
            email TEXT, 
            phone TEXT, 
            customer_rank INTEGER, 
            country TEXT, 
            city TEXT, 
            zip TEXT, 
            company_type TEXT,
            parent_id INTEGER,
            FOREIGN KEY (parent_id) REFERENCES {table_name}(id)
        )
    """)
    sqlite_cursor.execute(f"DELETE FROM {table_name}")


    print(f"Insertion de {len(data)} enregistrements dans {table_name}")
    for record in data:
        record['country_id'] = get_relation_name(record.get('country_id', None))
        record['parent_id'] = get_relation_id(record.get('parent_id', None))
        record['name'] = record.pop('display_name', None)
        placeholders = ', '.join(['?'] * len(record))
        values = tuple(record.get(field, None) for field in ['id', 'name', 'email', 'phone', 'customer_rank', 'country_id', 'city', 'zip', 'company_type', 'parent_id'])
        sqlite_cursor.execute(f"INSERT INTO {table_name} VALUES ({placeholders})", values)

    sqlite_conn.commit()
    sqlite_cursor.close()

def transfer_product_category():
    print("Transfert des catégories de produits...")

    table_name = 'product_category'
    fields = [
        'id',
        'display_name',
        'parent_id'
    ]
    domain = [
        ('parent_id', 'child_of', 1)
    ]

    try:
        data = models.execute_kw(db, uid, password, 'product.category', 'search_read', [domain], {'fields': fields})
    except Exception as e:
        print(f"Erreur lors de la récupération des données: {e}")
        return

    sqlite_cursor = sqlite_conn.cursor()
    sqlite_cursor.execute(f"""
        CREATE TABLE IF NOT EXISTS {table_name} (
            id INTEGER PRIMARY KEY, 
            name TEXT, 
            parent_id INTEGER,
            grouping INTEGER,
            FOREIGN KEY (parent_id) REFERENCES {table_name}(id)
        )
    """)
    sqlite_cursor.execute(f"DELETE FROM {table_name}")

    def get_grouping(record, data):
        if record['parent_id'] in [None, 1]:
            return record['id']
        parent_record = next((item for item in data if item['id'] == record['parent_id']), None)
        while parent_record and parent_record['parent_id'] != 1:
            parent_record = next((item for item in data if item['id'] == parent_record['parent_id']), None)
        return parent_record['id'] if parent_record else record['id']

    print(f"Insertion de {len(data)} enregistrements dans {table_name}")
    for record in data:
        record['parent_id'] = get_relation_id(record.get('parent_id', None))
        record['grouping'] = get_grouping(record, data)
        record['name'] = record.pop('display_name', None)
        placeholders = ', '.join(['?'] * len(record))
        values = tuple(record.get(field, None) for field in ['id', 'name', 'parent_id', 'grouping'])
        sqlite_cursor.execute(f"INSERT INTO {table_name} VALUES ({placeholders})", values)

    sqlite_conn.commit()
    sqlite_cursor.close()

def transfer_product_template():
    print("Transfert des modèles de produits...")

    table_name = 'product_template'
    fields = [
        'id',
        'display_name',
        'list_price',
        'standard_price',
        'categ_id',
        'type',
        'uom_id'
    ]
    domain = [
        ('active', '=', True)
    ]

    try:
        data = models.execute_kw(db, uid, password, 'product.template', 'search_read', [domain], {'fields': fields})
    except Exception as e:
        print(f"Erreur lors de la récupération des données: {e}")
        return

    sqlite_cursor = sqlite_conn.cursor()
    sqlite_cursor.execute(f"""
        CREATE TABLE IF NOT EXISTS {table_name} (
            id INTEGER PRIMARY KEY, 
            name TEXT, 
            list_price REAL, 
            standard_price REAL, 
            categ_id INTEGER, 
            type TEXT, 
            uom TEXT
        )
    """)
    sqlite_cursor.execute(f"DELETE FROM {table_name}")

    print(f"Insertion de {len(data)} enregistrements dans {table_name}")
    for record in data:
        record['categ_id'] = get_relation_id(record.get('categ_id', None))
        record['uom'] = get_relation_name(record.get('uom_id', None))
        record['name'] = record.pop('display_name', None)
        placeholders = ', '.join(['?'] * (len(record)-1))
        values = tuple(record.get(field, None) for field in ['id', 'name', 'list_price', 'standard_price', 'categ_id', 'type', 'uom'])
        sqlite_cursor.execute(f"INSERT INTO {table_name} VALUES ({placeholders})", values)

    sqlite_conn.commit()
    sqlite_cursor.close()

def transfer_product_product():
    print("Transfert des produits...")
    table_name = 'product_product'
    fields = [
        'id',
        'display_name',
        'product_tmpl_id',
        'list_price',
        'standard_price',
        'categ_id',
        'type',
        'uom_id']
    domain = [
        ('active', '=', True)
    ]

    try:
        data = models.execute_kw(db, uid, password, 'product.product', 'search_read', [domain], {'fields': fields})
    except Exception as e:
        print(f"Erreur lors de la récupération des données: {e}")
        return

    sqlite_cursor = sqlite_conn.cursor()
    sqlite_cursor.execute(f"""
        CREATE TABLE IF NOT EXISTS {table_name} (
            id INTEGER PRIMARY KEY, 
            name TEXT, 
            product_tmpl_id INTEGER,
            list_price REAL, 
            standard_price REAL, 
            categ_id INTEGER, 
            type TEXT, 
            uom TEXT,
            FOREIGN KEY (product_tmpl_id) REFERENCES product_template(id)
        )
    """)
    sqlite_cursor.execute(f"DELETE FROM {table_name}")

    print(f"Insertion de {len(data)} enregistrements dans {table_name}")
    for record in data:
        record['categ_id'] = get_relation_id(record.get('categ_id', None))
        record['uom'] = get_relation_name(record.get('uom_id', None))
        record['product_tmpl_id'] = get_relation_id(record.get('product_tmpl_id', None))
        record['name'] = record.pop('display_name', None)
        values = tuple(record.get(field, None) for field in ['id', 'name', 'product_tmpl_id', 'list_price', 'standard_price', 'categ_id', 'type', 'uom'])
        placeholders = ', '.join(['?'] * len(values))
        sqlite_cursor.execute(f"INSERT INTO {table_name} VALUES ({placeholders})", values)

    sqlite_conn.commit()
    sqlite_cursor.close()

def transfer_account_move():
    print("Transfert des factures...")

    table_name = 'account_move'
    fields = [
        'id',
        'display_name',
        'partner_id',
        'date',
        'state',
        'amount_total',
        'amount_tax',
        'amount_untaxed'
    ]
    domain = [
        ('move_type', '=', 'out_invoice')
    ]  # Filtrer uniquement les factures clients

    try:
        data = models.execute_kw(db, uid, password, 'account.move', 'search_read', [domain], {'fields': fields})
    except Exception as e:
        print(f"Erreur lors de la récupération des données: {e}")
        return

    sqlite_cursor = sqlite_conn.cursor()
    sqlite_cursor.execute(f"""
        CREATE TABLE IF NOT EXISTS {table_name} (
            id INTEGER PRIMARY KEY, 
            name TEXT, 
            partner_id INTEGER, 
            date TEXT, 
            state TEXT, 
            amount_total REAL, 
            amount_tax REAL, 
            amount_untaxed REAL
        )
    """)
    sqlite_cursor.execute(f"DELETE FROM {table_name}")

    print(f"Insertion de {len(data)} enregistrements dans {table_name}")
    for record in data:
        record['partner_id'] = get_relation_id(record.get('partner_id', None))
        record['name'] = record.pop('display_name', None)
        placeholders = ', '.join(['?'] * len(record))
        values = tuple(record.get(field, None) for field in ['id', 'name', 'partner_id', 'date', 'state', 'amount_total', 'amount_tax', 'amount_untaxed'])
        sqlite_cursor.execute(f"INSERT INTO {table_name} VALUES ({placeholders})", values)

    sqlite_conn.commit()
    sqlite_cursor.close()

def transfer_account_move_line():
    print("Transfert des lignes de factures...")
    table_name = 'account_move_line'
    fields = [
        'id',
        'move_id',
        'product_id',
        'quantity',
        'price_unit',
        'price_subtotal'
    ]

    # Filtrer uniquement les lignes des factures clients où product_id n'est pas nul
    domain = [
        ('move_id.move_type', '=', 'out_invoice'),
        ('product_id', '!=', False)
    ]

    try:
        data = models.execute_kw(db, uid, password, 'account.move.line', 'search_read', [domain], {'fields': fields})
    except Exception as e:
        print(f"Erreur lors de la récupération des données: {e}")
        return

    sqlite_cursor = sqlite_conn.cursor()
    sqlite_cursor.execute(f"""
        CREATE TABLE IF NOT EXISTS {table_name} (
            id INTEGER PRIMARY KEY, 
            move_id INTEGER, 
            product_id INTEGER, 
            quantity REAL, 
            price_unit REAL, 
            price_subtotal REAL,
            FOREIGN KEY (move_id) REFERENCES account_move(id),
            FOREIGN KEY (product_id) REFERENCES product_product(id)
        )
    """)
    sqlite_cursor.execute(f"DELETE FROM {table_name}")

    print(f"Insertion de {len(data)} enregistrements dans {table_name}")
    for record in data:
        record['move_id'] = get_relation_id(record.get('move_id', None))
        record['product_id'] = get_relation_id(record.get('product_id', None))
        placeholders = ', '.join(['?'] * len(record))
        values = tuple(record.get(field, None) for field in fields)
        sqlite_cursor.execute(f"INSERT INTO {table_name} VALUES ({placeholders})", values)

    sqlite_conn.commit()
    sqlite_cursor.close()

def apply_post_transfer_operations(db_filename):
    print("Opérations post-transfert...")
    # Connexion à la base de données SQLite
    sqlite_conn = sqlite3.connect(db_filename)
    sqlite_cursor = sqlite_conn.cursor()

    # Création d'index pour améliorer les performances des jointures et des filtres
    print("Création d'index...")
    index_queries = [
        "CREATE INDEX IF NOT EXISTS idx_partner_parent_id ON res_partner(parent_id)",
        "CREATE INDEX IF NOT EXISTS idx_partner_country ON res_partner(country)",
        "CREATE INDEX IF NOT EXISTS idx_product_categ_id ON product_product(categ_id)",
        "CREATE INDEX IF NOT EXISTS idx_product_tmpl_id ON product_product(product_tmpl_id)",
        "CREATE INDEX IF NOT EXISTS idx_move_partner_id ON account_move(partner_id)",
        "CREATE INDEX IF NOT EXISTS idx_move_line_move_id ON account_move_line(move_id)",
        "CREATE INDEX IF NOT EXISTS idx_move_line_product_id ON account_move_line(product_id)"
    ]

    for query in index_queries:
        sqlite_cursor.execute(query)

    print("Création de vues matérialisées et tables d'agrégation...")
    # Validation de l'intégrité référentielle (exemple simple, à ajuster selon les besoins)
    validation_queries = [
        """
        SELECT a.id 
        FROM account_move_line a
        LEFT JOIN account_move m ON a.move_id = m.id
        WHERE m.id IS NULL
        """,
        """
        SELECT p.id 
        FROM product_product p
        LEFT JOIN product_template t ON p.product_tmpl_id = t.id
        WHERE t.id IS NULL
        """
    ]

    for query in validation_queries:
        result = sqlite_cursor.execute(query).fetchall()
        if result:
            print("Problèmes d'intégrité référentielle détectés:", result)

    # Création de vues matérialisées ou de tables d'agrégation (exemple simple)
    view_queries = [
        """
        CREATE VIEW IF NOT EXISTS view_sales_summary AS
        SELECT 
            a.id AS move_id,
            a.name AS move_name,
            p.id AS product_id,
            p.name AS product_name,
            pt.id AS template_id,
            pc.id AS category_id,
            pc.name AS category_name,
            pg.name AS category_group,
            rp.id AS partner_id,
            rp.name AS partner_name,
            rp.email AS partner_email,
            rp.phone AS partner_phone,
            a.date,
            l.quantity,
            l.price_unit,
            l.price_subtotal
        FROM 
            account_move a
        JOIN 
            account_move_line l ON a.id = l.move_id
        JOIN 
            product_product p ON l.product_id = p.id
        JOIN 
            product_template pt ON p.product_tmpl_id = pt.id
        JOIN 
            product_category pc ON pt.categ_id = pc.id
        JOIN 
            product_category pg ON pc.grouping = pg.id
        JOIN 
            res_partner rp ON a.partner_id = rp.id;
        """,
        """
        CREATE VIEW view_sales_per_customer_per_month AS
        SELECT 
            strftime('%Y-%m', sm.date) AS year_month,
            sm.partner_name,
            pc.grouping AS category_group,
            SUM(sm.price_subtotal) AS total_sales
        FROM 
            view_sales_summary sm
        JOIN 
            product_category pc ON sm.category_id = pc.id
        GROUP BY 
            year_month, sm.partner_name, pc.grouping
        ORDER BY 
            year_month, sm.partner_name, pc.grouping;
    """
    ]

    for query in view_queries:
        sqlite_cursor.execute(query)

    # Fermer la connexion SQLite
    sqlite_conn.commit()
    sqlite_conn.close()

# Exécuter les fonctions pour transférer les données dans l'ordre spécifié
transfer_res_partner()
transfer_product_category()
transfer_product_template()
transfer_product_product()
transfer_account_move()
transfer_account_move_line()

apply_post_transfer_operations(db_filename)

print("Transfert de données terminé.")