CREATE OR REPLACE FUNCTION delete_table_or_view(objectName varchar) RETURNS integer AS $$
DECLARE
    isTable integer;
    isView integer;
BEGIN
    SELECT INTO isTable count(*) FROM pg_tables where tablename=objectName;
    SELECT INTO isView count(*) FROM pg_views where viewname=objectName;

    IF isTable = 1 THEN
        execute 'DROP TABLE IF EXISTS ' || objectName || ' CASCADE';
        RETURN 1;
    END IF;

    IF isView = 1 THEN
        execute 'DROP VIEW IF EXISTS ' || objectName || ' CASCADE';
        RETURN 2;
    END IF;

    RETURN 0;

END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION drop_tables_to_cleanup() RETURNS integer AS $$
DECLARE
    tableName RECORD;
BEGIN
    FOR tableName IN
        SELECT
            table_name
        FROM
            ir_model_to_remove
    LOOP
        PERFORM delete_table_or_view(tableName.table_name);
    END LOOP;
    RETURN 0;
END;
$$ LANGUAGE plpgsql;

create table ir_model_to_remove (model_id int, model_name char, table_name char);

COPY ir_model_to_remove (model_id, model_name, table_name) FROM '/path/to/csv' DELIMITER ',' CSV;

update ir_model_to_remove SET
    model_id=(select id from ir_model where ir_model.model=ir_model_to_remove.model_name);

delete from ir_model_access where model_id in (select id from ir_model_to_remove);
delete from ir_model_constraint where model in (select id from ir_model_to_remove);
delete from ir_model_data where model in (select model_name from ir_model_to_remove);
delete from ir_model_fields where model in (select model_name from ir_model_to_remove);
delete from ir_model_relation where model in (select id from ir_model_to_remove);
delete from ir_ui_view where model in (select model_name from ir_model_to_remove);

select drop_tables_to_cleanup();

delete from ir_model where id in (select id from ir_model_to_remove);

drop table ir_model_to_remove;