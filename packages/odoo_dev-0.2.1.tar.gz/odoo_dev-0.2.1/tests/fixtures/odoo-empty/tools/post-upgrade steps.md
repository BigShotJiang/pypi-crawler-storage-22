## Operations to run after installing the odoo upgraded database from 2022-11-27.

Run the script tools/after_migration.sh:

    tools/after_migration.sh <database_name>

## Configuration steps
### Sales

1. In Sales > Settings, activate Pricelists and Advanced price rules

### Inventory

Start with some general clean-up: 
1. Remove trailing slashes from all inventory locations that have them (only root locations on my copy).
2. Remove the product category `Saleable` and its children (I needed to delete some demo products in the pos category)
3. In Settings > Technical > Company Properties, set the production location (search for field location) to the real 
   production location id. This was 7 in my copy.
4. In Inventory > Configuration > Locations, archive the location Durpro: Production

### Set up Inventory and Manufacturing settings

In `Inventory > Configuration > Settings`, enable :
1. "Packages"
2. "Quality" and "Quality Worksheet"
3. "Reception Report" and "Show Reception Report at Validation"

In `Manufacturing > Configuration > Settings`, enable :
1. "By-Products"
2. "Subcontracting"
3. "Master Production Schedule" 

#### Set Up 2-Step Manufacturing and Clean Up Routes

1. Go to `Inventory > Configuration > Warehouses` and select "Durpro Ltée".
2. Set "Manufacture" to "Pick components and then manufacture"
3. In `Inventory > Configuration > Rules`, modify the rules :
   1. For the rule `WH1: Candiac Warehouse -> Pre-Production` belonging to `Dur-Pro Ltée: Pick components then 
      manufacture`, set the supply method to `Take from stock, if unavailable, trigger another rule`.
   2. For the rule `WH1: Pre-Production → Automatisation BL / Automatisation BL 9368-7838 Québec Inc`, belonging to
      belonging to `Dur-Pro Ltée: Pick components then manufacture`, set the supply method to `Take from stock, if 
      unavailable, trigger another rule`.
   3. Archive all rules pertaining to `Pival International` and `C.E. Transport` (don't forget to look in location names)
   4. Archive one of the pull rules on the `Durpro Ltée: Deliver in 1 step (ship)` route (it is duplicated)
4. In `Inventory > Configuration > Routes`:
   1. Set `Product Categories` to true on the `Buy` route 
   2. In the `Durpro Ltée: Deliver in 1 step (ship)` route, set the pull rule to 
      `Take from stock, if unavailable, trigger another rule`
   3. Remove the `Buy` rule from the `SDI` route
   4. Archive the `Make to Order` route
   5. Delete the `Rental Inventory` route - it's not used on any products or product categories and makes no sense
   6. Check the `Product Categories` checkbox in the `Buy` and `Manufacture` routes
   7. Add a rule to the `Dur-Pro Ltée: Pick components then manufacture` route:
      1. Action: Pull from
      2. Operation type: Durpro Ltée: Manufacturing
      3. Source Location: Durpro Ltée/Pre-Production
      4. Destination Location: Virtual Locations/Production
      5. Supply Method: Trigger Another Rule
   8. Re-order the routes in the following order:
      1. SDI
      2. Deliver in 1 step
      3. Manufacture
      4. Buy
      5. Receive in 1 step
      6. Archive the `Durpro Ltée: Pick components and then manufacture` route
   9. Set `Cancel Next Move` to true in the propagate section for the following rules:
      1. All rules in the `Durpro Ltée: Pick components and then manufacture` route
      2. The `Manufacture` rule in the `Manufacture` route
   

#### Set up Product Categories With Routes

Generally, any product category we manufacture should have the "Manufacture" route set on the category.

1. Set the `Buy` route on the `Distribution` and `Replacement Parts` categories
2. Set the `Manufacture` route on the `Bed Filters` category (this may need to be more fine-grained)
3. Set the `Manufacture` route on the `Replacement Parts / Amiad / MCFM` category
4. Set the `Manufacture` route on the `Systems` category ... and seriously consider moving all components categories out.