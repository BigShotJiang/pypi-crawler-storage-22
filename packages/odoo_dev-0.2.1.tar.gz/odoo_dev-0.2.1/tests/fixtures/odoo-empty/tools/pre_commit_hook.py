#!/usr/bin/python3
"""
This pre-commit script checks each module in the addons directory for changes. If the module has changed, it verifies
that there is a commit to a newer (higher) version number in the __manifest__.py file for that module. If not, it
exits in error and requests that the version be incremented appropriately. Place in the .git/hooks/ directory with the
filename pre-commit and chmod 755 (if necessary).
"""

import sys
import subprocess
import re


def get_changes() -> (list, dict):
    diff = subprocess.run(["git", "diff", "--cached", "--name-only"], shell=False, capture_output=True)
    args = str(diff.stdout).replace("b'", "").replace("'", "").split('\\n')
    addons_modified = []
    updated_manifests = {}

    for arg in args:
        path_parts = arg.split('/')
        addon_part = path_parts[1] if path_parts[0] == 'addons' else False
        if addon_part:
            if addon_part not in addons_modified:
                addons_modified.append(addon_part)
            if path_parts[-1] == '__manifest__.py':
                updated_manifests.update({addon_part: arg})

    return filter(lambda n: n not in updated_manifests, addons_modified), updated_manifests


def check_version_upgrade(path) -> (bool, str, str):
    done_proc = subprocess.run(["git", "diff", "--cached", path], shell=False, capture_output=True)
    str_out = str(done_proc.stdout)
    lines = str_out.split("\\n")
    new_version_no, old_version_no = None, None
    for line in lines:
        if "version" in line:
            version_no = re.search("(\d+\.*)+", line)
            if line[0] == '-':
                old_version_no = version_no.group(0)
            elif line[0] == "+":
                new_version_no = version_no.group(0)
    return new_version_no and (new_version_no > old_version_no or not old_version_no), old_version_no, new_version_no


error = False
forgotten_addons, updated_manifests = get_changes()

for addon in forgotten_addons:
    print(f"Addon {addon} was modified but its manifest was not. Please increment the version number.")
    error = True

for addon, path in updated_manifests.items():
    ok, old, new = check_version_upgrade(path)
    if not ok and not new:
        error = True
        print(f"Addon {addon} was modified but its version was not incremented. Please increment the version number.")
    elif not ok:
        error = True
        print(f"Addon {addon} changed from version {old} to version {new} ... this is not a version increase. "
              f"Please increment the version number.")

sys.exit(error)
