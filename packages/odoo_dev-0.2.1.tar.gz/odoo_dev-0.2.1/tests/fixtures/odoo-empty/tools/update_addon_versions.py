#!/usr/bin/python3
""" Takes the path to the addons directory as an argument and adds a ".1" to the end of every module's version
in the manifest. """
import sys
from pathlib import Path
import ast

arg = sys.argv[1]
p = Path(arg)
addon_manifests = list(p.glob('**/__manifest__.py'))

for manifest in addon_manifests:
    with manifest.open('r') as f:
        contents = f.read()
        file_dict = ast.literal_eval(contents)
        if 'version' not in file_dict:
            continue
        version = file_dict['version']
        print(f"Module: {file_dict['name']}: {version}")

    with manifest.open('w') as f:
        new_contents = contents.replace(version, version+".1")
        f.write(new_contents)
