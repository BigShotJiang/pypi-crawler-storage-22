"""Odys - Python framework for optimizing multi-energy systems.

This package provides tools for modeling and optimizing energy systems with generators,
batteries, and other energy assets using mathematical optimization techniques.

"""

import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())
