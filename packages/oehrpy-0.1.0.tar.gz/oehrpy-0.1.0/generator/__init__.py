"""
BMM-to-Python code generator.

This package contains tools for parsing openEHR BMM files and generating
Pydantic models for the Reference Model.
"""
