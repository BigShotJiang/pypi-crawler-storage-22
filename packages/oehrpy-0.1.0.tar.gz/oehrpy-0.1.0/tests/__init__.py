"""Tests for openEHR SDK."""
