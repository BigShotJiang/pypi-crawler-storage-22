-- Initialize PostgreSQL database for EHRBase
-- Enable required extensions

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
