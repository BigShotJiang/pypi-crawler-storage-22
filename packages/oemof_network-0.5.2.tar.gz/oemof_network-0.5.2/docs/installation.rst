============
Installation
============

At the command line::

    pip install oemof.network
