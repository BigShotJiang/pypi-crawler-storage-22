GRAPHQL_URLS = {
  'production': 'https://graph.maia.byterat.io/graphql',
  'development': 'https://dev.graph.maia.byterat.io/graphql',
  'local': 'http://localhost:13337/graphql',
}

GET_OHM_CONFIG = """
	query {
		get_ohm_config {
			db {
				host
				port
				user
				database
				password
				sslmode
			}
			tables {
				metadata
				observation
				dataset_cycle
				dataset_cycle_predictions
			}
		}
	}
"""
