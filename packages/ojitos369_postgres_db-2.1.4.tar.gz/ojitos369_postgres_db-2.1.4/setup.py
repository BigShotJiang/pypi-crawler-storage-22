from setuptools import setup

setup()

"""
# pip install --upgrade setuptools twine pip build
py -m build
# py setup.py sdist
twine upload dist/*
"""