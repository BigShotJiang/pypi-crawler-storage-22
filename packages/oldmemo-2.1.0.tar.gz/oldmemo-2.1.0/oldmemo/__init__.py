from .version import __version__ as __version__

from .oldmemo import Oldmemo as Oldmemo
