"""Provides a class to sync data from TheOldReader."""

##############################################################################
# Python imports.
from collections.abc import AsyncIterator, Callable, Iterable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any

##############################################################################
# Humanize imports.
from humanize import intcomma, naturaltime

##############################################################################
# OldAS imports.
from oldas import (
    Article,
    ArticleIDs,
    Articles,
    Folders,
    Session,
    Subscription,
    Subscriptions,
)

##############################################################################
from .data import (
    LocalUnread,
    Log,
    get_local_subscriptions,
    get_local_unread,
    get_unread_article_ids,
    last_grabbed_data_at,
    load_configuration,
    locally_known_article_ids,
    locally_mark_article_ids_read,
    locally_mark_article_ids_unread,
    remember_we_last_grabbed_at,
    remove_subscription_articles,
    save_local_articles,
    save_local_folders,
    save_local_subscriptions,
)
from .data.models import LocalSubscriptionGrabFilter

##############################################################################
type Callback = Callable[[], Any] | None
"""Type of a callback with no arguments."""
type CallbackWith[T] = Callable[[T], Any] | None
"""Type of callback with a single argument."""


##############################################################################
@dataclass
class TheOldReaderSync:
    """Class that handles syncing data from TheOldReader."""

    session: Session
    """The TheOldReader API session object."""
    on_new_step: CallbackWith[str] = None
    """Function to call when a new step starts."""
    on_new_result: CallbackWith[str] = None
    """Function to call when a result should be communicated."""
    on_new_folders: CallbackWith[Folders] = None
    """Function to call when new folders are acquired."""
    on_new_subscriptions: CallbackWith[Subscriptions] = None
    """Function to call when new subscriptions are acquired."""
    on_new_unread: CallbackWith[LocalUnread] = None
    """Function to call when new unread counts are calculated."""
    on_sync_finished: Callback = None
    """Function to call when the sync has finished."""

    def __post_init__(self) -> None:
        """Initialise the sync object."""
        self._batch_size = load_configuration().article_download_batch_size
        """The size of the article batch to download and save."""
        self._last_sync: datetime | None = None
        """The time at which we last did a sync."""
        self._first_sync = True
        """Is this our first ever sync?"""

    def _step(self, step: str, *, log: bool = True) -> None:
        """Mark a new step.

        Args:
            step: The step that is happening.
            log: Should we log the step?
        """
        if log:
            Log().info(step)
        if self.on_new_step:
            self.on_new_step(step)

    def _result(self, result: str) -> None:
        """Show a new result.

        Args:
            result: The result that should be shown.
        """
        Log().info(result)
        if self.on_new_result:
            self.on_new_result(result)

    async def _download(self, stream: AsyncIterator[Article], description: str) -> int:
        """Download and save articles from an article stream.

        Args:
            stream: The stream to download.
            description: The description of the download.

        Returns:
            The number of articles downloaded.
        """
        loaded = 0
        save_batch: list[Article] = []
        async for article in stream:
            # I've encountered articles that don't have an origin stream ID,
            # which means that I can't relate them back to a stream, which
            # means I'll never see them anyway...
            if not article.origin.stream_id:
                continue
            save_batch.append(article)
            loaded += 1
            if (loaded % self._batch_size) == 0:
                self._step(f"{description}: {intcomma(loaded)}", log=False)
                Log().debug(f"Saving batch of articles: {len(save_batch)}")
                await save_local_articles(Articles(save_batch))
                Log().debug(f"Saved batch of articles: {len(save_batch)}")
                save_batch = []
        if save_batch:
            Log().debug(f"Saving final batch of articles: {len(save_batch)}")
            await save_local_articles(Articles(save_batch))
            Log().debug(f"Saved final batch of articles: {len(save_batch)}")
        return loaded

    async def _catchup_read(
        self, remote_unread: set[str], local_unread: set[str]
    ) -> None:
        """Catch up on the read status of articles.

        Args:
            remote_unread: The IDs of articles unread on the server.
            local_unread: The IDs of articles unread locally.
        """
        if mark_as_read := local_unread - remote_unread:
            Log().debug(f"Articles found as marked read elsewhere: {mark_as_read}")
            await locally_mark_article_ids_read(mark_as_read)
            self._result(
                f"Articles found marked read elsewhere on TheOldReader: {intcomma(len(mark_as_read))}"
            )

    async def _catchup_unread(
        self, remote_unread: set[str], local_unread: set[str]
    ) -> None:
        """Catch up on the unread status of articles.

        Args:
            remote_unread: The IDs of articles unread on the server.
            local_unread: The IDs of articles unread locally.
        """
        if mark_as_unread := remote_unread - local_unread:
            Log().debug(f"Articles found as marked unread elsewhere: {mark_as_unread}")
            await locally_mark_article_ids_unread(mark_as_unread)
            self._result(
                f"Articles found marked unread elsewhere on TheOldReader: {intcomma(len(mark_as_unread))}"
            )

    async def _get_updated_read_status(self) -> None:
        """Refresh the (un)read status from the server."""
        if self._first_sync:
            return
        self._step("Syncing read/unread status with TheOldReader")
        remote_unread_articles = await locally_known_article_ids(
            article_id.full_id
            for article_id in await ArticleIDs.load_unread(self.session)
        )
        local_unread_articles = set(await get_unread_article_ids())
        await self._catchup_read(remote_unread_articles, local_unread_articles)
        await self._catchup_unread(remote_unread_articles, local_unread_articles)

    async def _download_backlog(self, subscriptions: Iterable[Subscription]) -> None:
        """Download the backlog of articles for the given subscriptions.

        Args:
            subscriptions: The subscriptions to download the backlog for.
        """
        cutoff = datetime.now(UTC) - timedelta(days=load_configuration().local_history)
        for subscription in subscriptions:
            if loaded := await self._download(
                Articles.stream_new_since(
                    self.session, cutoff, subscription, n=self._batch_size
                ),
                f"Downloading article backlog for {subscription.title}",
            ):
                self._result(
                    f"Downloaded article backlog for {subscription.title}: {intcomma(loaded)}"
                )

    async def _get_folders(self) -> Folders:
        """Get the list of folders from the server.

        Returns:
            The folders.
        """
        self._step("Getting folder list")
        folders = await save_local_folders(await Folders.load(self.session))
        if self.on_new_folders:
            self.on_new_folders(folders)
        return folders

    async def _get_subscriptions(self) -> tuple[Subscriptions, Subscriptions]:
        """Get the list of subscriptions from the server.

        Returns:
            A tuple of the original subscription list before the sync, and
            after.
        """
        self._step("Getting subscriptions list")
        original_subscriptions = await get_local_subscriptions()
        subscriptions = await save_local_subscriptions(
            await Subscriptions.load(self.session)
        )
        if self.on_new_subscriptions:
            self.on_new_subscriptions(subscriptions)
        return original_subscriptions, subscriptions

    async def _get_new_articles(self) -> None:
        """Download any new articles."""
        self._step(
            "Getting available articles"
            if self._last_sync is None
            else f"Getting new articles since {naturaltime(self._last_sync)}"
        )
        new_grab = datetime.now(UTC)
        last_grabbed = self._last_sync or (
            new_grab - timedelta(days=load_configuration().local_history)
        )
        if loaded := await self._download(
            Articles.stream_new_since(self.session, last_grabbed, n=self._batch_size),
            "Downloading articles from TheOldReader",
        ):
            self._result(f"Articles downloaded: {intcomma(loaded)}")
        else:
            self._result("No new articles found on TheOldReader")
        await remember_we_last_grabbed_at(new_grab)

    @staticmethod
    def _set_of_ids(subscriptions: Subscriptions) -> set[str]:
        """Get a set of the IDs of the given subscriptions.

        Args:
            subscriptions: The subscriptions to get the IDs of.

        Returns:
            A [set][`set`] of subscription IDs.
        """
        return {subscription.id for subscription in subscriptions}

    async def _get_historical_articles(
        self,
        original_subscriptions: Subscriptions,
        current_subscriptions: Subscriptions,
    ) -> None:
        """Download article histories for any new subscriptions.

        Args:
            original_subscriptions: The known subscriptions before the sync.
            current_subscriptions: The subscriptions we're now subscribed to.

        It's possible we have subscriptions we didn't know about before, so
        we want to go and backfill their content regardless of read or
        unread status. So, if it looks like we've grabbed data before but
        now we have subscriptions we didn't know about before... let's grab
        their history regardless.
        """
        Log().info("Checking for historical articles")
        if not self._first_sync and (
            new_subscriptions := self._set_of_ids(current_subscriptions)
            - self._set_of_ids(original_subscriptions)
        ):
            Log().info(f"New subscriptions found: {new_subscriptions}")
            await self._download_backlog(
                subscription
                for subscription in current_subscriptions
                if subscription.id in new_subscriptions
            )

    async def _clean_orphaned_articles(
        self,
        original_subscriptions: Subscriptions,
        current_subscriptions: Subscriptions,
    ) -> None:
        """Clean any articles left over from removed subscriptions.

        Args:
            original_subscriptions: The known subscriptions before the sync.
            current_subscriptions: The subscriptions we're now subscribed to.
        """
        Log().info("Checking for orphaned articles")
        if not self._first_sync and (
            removed_subscriptions := self._set_of_ids(original_subscriptions)
            - self._set_of_ids(current_subscriptions)
        ):
            Log().info(f"Found remotely-removed subscriptions: {removed_subscriptions}")
            for subscription in removed_subscriptions:
                await remove_subscription_articles(subscription)

    async def _clean_orphaned_filters(self, subscriptions: Subscriptions) -> None:
        """Clean out any content filters related to subscriptions we no longer have."""
        Log().info("Checking for orphaned content filters")
        await LocalSubscriptionGrabFilter.filter(
            subscription_id__not_in={subscription.id for subscription in subscriptions}
        ).delete()

    async def _get_unread_counts(
        self, folders: Folders, subscriptions: Subscriptions
    ) -> None:
        """Get the updated unread counts.

        Args:
            folders: The folders to get the counts for.
            subscriptions: The subscriptions to get the counts for.
        """
        if self.on_new_unread:
            self.on_new_unread(await get_local_unread(folders, subscriptions))

    async def sync(self) -> None:
        """Sync the data from TheOldReader."""
        Log().info("Starting sync with TheOldReader")
        self._last_sync = await last_grabbed_data_at()
        self._first_sync = self._last_sync is None
        folders = await self._get_folders()
        original_subscriptions, subscriptions = await self._get_subscriptions()
        await self._get_new_articles()
        await self._get_updated_read_status()
        await self._get_historical_articles(original_subscriptions, subscriptions)
        await self._clean_orphaned_articles(original_subscriptions, subscriptions)
        await self._get_unread_counts(folders, subscriptions)
        await self._clean_orphaned_filters(subscriptions)
        if self.on_sync_finished:
            self.on_sync_finished()
        Log().info("Finished sync with TheOldReader")


### sync.py ends here
