from .observation import MeteorObservation

# 定义版本号
__version__ = "0.1.0"
