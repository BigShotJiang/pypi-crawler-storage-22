# Multiple Positions

This example demonstrates how to write multiple 5D images (positions) using `ome_writers`.

```python
--8<-- "examples/multiposition_5d_images.py"
```
