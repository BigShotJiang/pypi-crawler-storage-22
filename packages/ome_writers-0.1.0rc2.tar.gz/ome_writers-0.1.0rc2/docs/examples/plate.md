# Multi-Well Plate (HCS)

This example demonstrates how to write a multi-well plate (HCS) dataset using `ome_writers`.

```python
--8<-- "examples/plate_5d_images.py"
```
