# Single 5D Image

This example demonstrates how to write a single 5D image using `ome_writers`.

```python
--8<-- "examples/single_5d_image.py"
```
