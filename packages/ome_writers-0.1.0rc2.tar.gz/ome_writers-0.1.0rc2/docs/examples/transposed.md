# Transposed Storage Order

This example demonstrates how to write a 5D image with transposed storage order using `ome_writers`.

```python
--8<-- "examples/transposed_5d_image.py"
```
