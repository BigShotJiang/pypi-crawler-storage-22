## installation 

'''bash
pip install omgen
