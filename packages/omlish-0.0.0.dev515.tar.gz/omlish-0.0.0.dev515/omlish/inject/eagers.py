from .. import check
from .. import dataclasses as dc
from .. import lang
from .elements import Element
from .keys import Key


##


@dc.dataclass(frozen=True)
@dc.extra_class_params(cache_hash=True)
class Eager(Element, lang.Final):
    key: Key = dc.xfield(coerce=check.of_isinstance(Key))

    priority: int = dc.xfield(0, kw_only=True)
