class Json5Error(Exception):
    pass
