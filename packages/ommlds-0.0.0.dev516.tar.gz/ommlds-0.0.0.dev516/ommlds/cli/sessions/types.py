import typing as ta


##


SessionProfileName = ta.NewType('SessionProfileName', str)
