"""MCP resources for Omni Cortex."""
