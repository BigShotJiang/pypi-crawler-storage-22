"""Unit tests for dashboard database functions.

Run with: cd dashboard/backend && .venv/Scripts/python -m pytest test_database.py -v
"""

import json
import os
import sqlite3
import tempfile
from pathlib import Path

import pytest

from database import create_memory, get_memories


@pytest.fixture
def test_db():
    """Create a temporary database with the required schema."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name

    # Create the database schema
    conn = sqlite3.connect(db_path)
    conn.execute("""
        CREATE TABLE memories (
            id TEXT PRIMARY KEY,
            content TEXT NOT NULL,
            context TEXT,
            type TEXT DEFAULT 'other',
            status TEXT DEFAULT 'fresh',
            importance_score INTEGER DEFAULT 50,
            access_count INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            last_accessed TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            tags TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE memory_relationships (
            source_memory_id TEXT NOT NULL,
            target_memory_id TEXT NOT NULL,
            relationship_type TEXT NOT NULL,
            strength REAL DEFAULT 0.5,
            PRIMARY KEY (source_memory_id, target_memory_id)
        )
    """)
    conn.commit()
    conn.close()

    yield db_path

    # Cleanup
    os.unlink(db_path)


class TestCreateMemory:
    """Tests for the create_memory function."""

    def test_create_memory_basic(self, test_db):
        """Test basic memory creation with minimal fields."""
        memory_id = create_memory(
            db_path=test_db,
            content="Test memory content",
        )

        assert memory_id is not None
        assert memory_id.startswith("mem_")

    def test_create_memory_with_type(self, test_db):
        """Test memory creation with custom type."""
        memory_id = create_memory(
            db_path=test_db,
            content="A decision was made",
            memory_type="decision",
        )

        # Verify the type was saved
        conn = sqlite3.connect(test_db)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()
        conn.close()

        assert row["type"] == "decision"

    def test_create_memory_with_tags(self, test_db):
        """Test memory creation with tags."""
        tags = ["python", "testing", "database"]
        memory_id = create_memory(
            db_path=test_db,
            content="Tagged memory",
            tags=tags,
        )

        # Verify tags were saved as JSON
        conn = sqlite3.connect(test_db)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()
        conn.close()

        saved_tags = json.loads(row["tags"])
        assert saved_tags == tags

    def test_create_memory_with_importance(self, test_db):
        """Test memory creation with custom importance score."""
        memory_id = create_memory(
            db_path=test_db,
            content="Important memory",
            importance_score=95,
        )

        conn = sqlite3.connect(test_db)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()
        conn.close()

        assert row["importance_score"] == 95

    def test_create_memory_has_updated_at(self, test_db):
        """Test that created memory has updated_at field (regression test for bug)."""
        memory_id = create_memory(
            db_path=test_db,
            content="Memory with updated_at",
        )

        conn = sqlite3.connect(test_db)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()
        conn.close()

        # This was the bug - updated_at was missing from INSERT
        assert row["updated_at"] is not None
        assert len(row["updated_at"]) > 0

    def test_create_memory_with_context(self, test_db):
        """Test memory creation with context."""
        memory_id = create_memory(
            db_path=test_db,
            content="Memory with context",
            context="This is additional context",
        )

        conn = sqlite3.connect(test_db)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()
        conn.close()

        assert row["context"] == "This is additional context"

    def test_create_memory_default_status_is_fresh(self, test_db):
        """Test that new memories have 'fresh' status by default."""
        memory_id = create_memory(
            db_path=test_db,
            content="Fresh memory",
        )

        conn = sqlite3.connect(test_db)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()
        conn.close()

        assert row["status"] == "fresh"

    def test_create_memory_default_access_count_is_zero(self, test_db):
        """Test that new memories have access_count of 0."""
        memory_id = create_memory(
            db_path=test_db,
            content="New memory",
        )

        conn = sqlite3.connect(test_db)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()
        conn.close()

        assert row["access_count"] == 0

    def test_create_memory_all_fields(self, test_db):
        """Test memory creation with all fields populated."""
        memory_id = create_memory(
            db_path=test_db,
            content="Complete memory",
            memory_type="solution",
            context="Full context here",
            tags=["tag1", "tag2"],
            importance_score=80,
        )

        conn = sqlite3.connect(test_db)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()
        conn.close()

        assert row["content"] == "Complete memory"
        assert row["type"] == "solution"
        assert row["context"] == "Full context here"
        assert json.loads(row["tags"]) == ["tag1", "tag2"]
        assert row["importance_score"] == 80
        assert row["status"] == "fresh"
        assert row["access_count"] == 0
        assert row["created_at"] is not None
        assert row["last_accessed"] is not None
        assert row["updated_at"] is not None


class TestCreateMemoryEdgeCases:
    """Edge case tests for create_memory."""

    def test_create_memory_empty_tags_list(self, test_db):
        """Test memory creation with empty tags list.

        Note: Current behavior stores empty list as None (falsy check in code).
        This is intentional - empty tags are treated same as no tags.
        """
        memory_id = create_memory(
            db_path=test_db,
            content="Memory with empty tags",
            tags=[],
        )

        conn = sqlite3.connect(test_db)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()
        conn.close()

        # Empty list is treated as None (falsy) in the code
        assert row["tags"] is None

    def test_create_memory_none_tags(self, test_db):
        """Test memory creation with None tags (default)."""
        memory_id = create_memory(
            db_path=test_db,
            content="Memory with no tags",
            tags=None,
        )

        conn = sqlite3.connect(test_db)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()
        conn.close()

        assert row["tags"] is None

    def test_create_memory_unicode_content(self, test_db):
        """Test memory creation with unicode content."""
        content = "Memory with unicode: 日本語 🚀 émojis"
        memory_id = create_memory(
            db_path=test_db,
            content=content,
        )

        conn = sqlite3.connect(test_db)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()
        conn.close()

        assert row["content"] == content

    def test_create_memory_long_content(self, test_db):
        """Test memory creation with very long content."""
        content = "A" * 100000  # 100KB of content
        memory_id = create_memory(
            db_path=test_db,
            content=content,
        )

        conn = sqlite3.connect(test_db)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()
        conn.close()

        assert len(row["content"]) == 100000


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
