"""Omni Meeting Recorder - CLI tool for recording online meeting audio."""

__version__ = "0.7.2"
