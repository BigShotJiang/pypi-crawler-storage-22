"""Audio capture backends for Omni Meeting Recorder."""
