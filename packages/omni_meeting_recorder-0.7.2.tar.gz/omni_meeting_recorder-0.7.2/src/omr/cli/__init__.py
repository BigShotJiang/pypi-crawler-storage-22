"""CLI module for Omni Meeting Recorder."""
