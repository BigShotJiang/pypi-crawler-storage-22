"""CLI commands for Omni Meeting Recorder."""
