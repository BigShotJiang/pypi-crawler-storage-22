"""Configuration management for Omni Meeting Recorder."""
