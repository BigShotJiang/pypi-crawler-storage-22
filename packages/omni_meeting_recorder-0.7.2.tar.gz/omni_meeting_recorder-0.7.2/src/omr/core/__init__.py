"""Core functionality for Omni Meeting Recorder."""
