"""Tests for Omni Meeting Recorder."""
