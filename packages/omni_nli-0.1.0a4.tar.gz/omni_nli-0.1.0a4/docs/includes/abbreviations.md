*[NLI]: Natural Language Inference
*[REST]: Representational State Transfer
*[MCP]: Model Context Protocol
*[API]: Application Programming Interface
*[LLM]: Large Language Model
*[JSON]: JavaScript Object Notation
*[HTTP]: Hypertext Transfer Protocol
*[SSE]: Server-Sent Events
*[CPU]: Central Processing Unit
*[GPU]: Graphics Processing Unit
*[CUDA]: Compute Unified Device Architecture
