#!/bin/bash
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
# shellcheck disable=SC1090,1091
set -eux

arch=${1:-x86_64}

os=$(uname -s)

case "$os" in
    "Linux" | "Darwin")
        ;;
    *)
        echo "Unknown OS: $os"
        return 1
        ;;
esac

# export UV_VENV_CLEAR=1
export TVM_FFI_DISABLE_TORCH_C_DLPACK=1
export UV_INDEX_URL="https://mirrors.aliyun.com/pypi/simple/"
pkill uv || true

omniback="$PWD"/
torchpipe="$omniback"/plugins/torchpipe
csrc="$omniback"/plugins/torchpipe/torchpipe/csrc

rm -f "$torchpipe"/torchpipe/lib/*.so

#   sed -e 's|^mirrorlist=|#mirrorlist=|g' \
#       -e 's|^# baseurl=https://repo.almalinux.org|baseurl=https://mirrors.aliyun.com|g' \
#       -i.bak \
#       /etc/yum.repos.d/almalinux*.repo
    
# dnf makecache  

# # see https://developer.aliyun.com/mirror/almalinux?spm=a2c6h.13651102.0.0.62181b11JTaroF


ls -la "$omniback"/.git
git config --global --add safe.directory "$omniback"
# git describe --tags


function build_local_libs() {
    local torch_version=$1
    local python_version=$2

    
    source "$omniback"/.venv/py"$python_version"/bin/activate
    # if [[ "$os" == "Linux" ]]; then
    #     uv pip install torch=="$torch_version" --index-url "$(get_torch_url "$torch_version")"
    # else
    #     uv pip install torch=="$torch_version"
    # fi
    uv pip install torch==$torch_version --index-url https://download.pytorch.org/whl/cpu # -i  http://mirrors.aliyun.com/pypi/simple/
    
    abiflag=$(python -c "import torch; print(int(torch.compiled_with_cxx11_abi()))")
    if [[ "$os" == "Linux" ]]; then
        python -m omniback.utils.build_lib --output-dir "$torchpipe"/torchpipe/lib/ --source-dirs "$csrc"/torchplugins/ "$csrc"/helper/ --include-dirs="$csrc"/ --name torchpipe_core
        # python -m omniback.utils.build_lib --output-dir "$torchpipe"/torchpipe/lib/ --source-dirs "$csrc"/core_cuda/ "$csrc"/helper_cuda/ --include-dirs="$csrc"/ --build-with-cuda --name torchpipe_core_cuda

        for abiflag in 1 0; do
            # opencv_install=/opencv_install/abiflag$abiflag/
            opencv_install=~/.cache/omniback/torchpipe/opencv/abiflag${abiflag}
            # cv_lib=/opencv_install/abiflag$abiflag/lib
            echo "opencv installed in ${opencv_install}"

            python -m omniback.utils.build_lib --output-dir "$torchpipe"/torchpipe/lib/ --source-dirs "$csrc"/mat_torch/  \
                --ldflags "-L$opencv_install/lib -Wl,-Bstatic -lopencv_imgproc -lopencv_imgcodecs -lopencv_core -L$opencv_install/lib/opencv4/3rdparty/ \
                 -ltbb -llibjpeg-turbo -llibpng -llibtiff -llibopenjp2 -lzlib -lipphal -lippiw -lippicv -Wl,-Bdynamic -ldl  -lpthread"  \
                --include-dirs="$csrc/ $opencv_install/include/opencv4/" --name torchpipe_opencv --no-torch --abiflag=$abiflag

   
        done
    fi
    ls "$torchpipe"/torchpipe/lib
    deactivate
}

mkdir -p "$torchpipe"/lib


rm -rf build
# rm -rf "$omniback"/.venv/py3.11


if [ ! -d "$omniback"/.venv/py3.11 ]; then
    uv venv "$omniback"/.venv/py3.11 --python 3.11
fi

# echo $UV_AUDIT

source "$omniback"/.venv/py3.11/bin/activate
uv pip install setuptools ninja fire -v
uv pip install omniback --upgrade --pre
deactivate

# https://pytorch.org/get-started/previous-versions/
torch_versions=("1.13" "2.3" "2.4") # => next version
for version in "${torch_versions[@]}"; do
    build_local_libs "$version" 3.11
done

uv cache clean
# 2.8 -> 2.7
torch_versions=("2.5" "2.6" "2.7") # => next version
for version in "${torch_versions[@]}"; do
    build_local_libs "$version" 3.11
done

uv cache clean

torch_versions=("2.8" "2.9" "2.10") # => next version
for version in "${torch_versions[@]}"; do
    build_local_libs "$version" 3.11
done

uv cache clean

# cp "$omniback"/lib/*.so "$torchpipe"/torchpipe
source "$omniback"/.venv/py3.11/bin/activate
uv pip install build wheel scikit_build_core setuptools-scm
cd "$torchpipe"
rm -rf wheelhouse/
mkdir -p wheelhouse/
rm -rf dist/
python -m build -w --no-isolation
ls dist
if [[ "$os" == "Linux" ]]; then
    # python -m wheel tags dist/*.whl --python-tag="$python_version" --abi-tag="$python_version" --remove
    uv pip install auditwheel
    ls dist/*.whl
    # cp dist/*.whl wheelhouse/
    auditwheel repair --exclude libomniback.so --exclude libomniback_cxx03.so --exclude libtvm_ffi.so \
        --exclude libtorch.so --exclude libtorch_cpu.so --exclude libc10.so --exclude libtorch_python.so --exclude libtorch_cuda.so --exclude libc10_cuda.so dist/*.whl -w wheelhouse
else
    # python -m wheel tags dist/*.whl --python-tag="$python_version" --abi-tag="$python_version" --platform-tag=macosx_11_0_arm64 --remove
    uv pip install delocate
    delocate-wheel -v --ignore-missing-dependencies --exclude libtorch.dylib,libtorch_cpu.dylib,libc10.dylib,libtorch_python.dylib dist/*.whl -w wheelhouse
fi
ls wheelhouse