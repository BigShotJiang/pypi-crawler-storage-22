"""Tests for text extraction module."""
