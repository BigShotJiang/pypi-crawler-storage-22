"""Version information for OmniDocs."""

__version__ = "0.2.4"
