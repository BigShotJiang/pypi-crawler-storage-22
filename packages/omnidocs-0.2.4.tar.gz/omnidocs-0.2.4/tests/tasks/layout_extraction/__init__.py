"""Tests for layout extraction module."""
