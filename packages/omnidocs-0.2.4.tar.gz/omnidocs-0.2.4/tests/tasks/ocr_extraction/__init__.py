"""Tests for OCR extraction module."""
