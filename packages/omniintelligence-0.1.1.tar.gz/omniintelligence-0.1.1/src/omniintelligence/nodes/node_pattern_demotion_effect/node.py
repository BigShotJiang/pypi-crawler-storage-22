# SPDX-License-Identifier: MIT
# Copyright (c) 2025 OmniNode Team
"""Node Pattern Demotion Effect - Declarative effect node for pattern demotion.

This node follows the ONEX declarative pattern:
    - DECLARATIVE effect driven by contract.yaml
    - Zero custom routing logic - all behavior from handler_routing
    - Lightweight shell that delegates to handlers via container resolution
    - Used for ONEX-compliant runtime execution via RuntimeHostProcess
    - Pattern: "Contract-driven, handlers wired externally"

Extends NodeEffect from omnibase_core for infrastructure I/O operations.
All handler routing is 100% driven by contract.yaml, not Python code.

Handler Routing Pattern:
    1. Receive demotion check request (input_model in contract)
    2. Route to appropriate handler based on operation (handler_routing)
    3. Execute infrastructure I/O via handler (PostgreSQL queries, Kafka events)
    4. Return structured response (output_model in contract)

Design Decisions:
    - 100% Contract-Driven: All routing logic in YAML, not Python
    - Zero Custom Routing: Base class handles handler dispatch via contract
    - Declarative Handlers: handler_routing section defines dispatch rules
    - Container DI: Handler dependencies resolved via container

Node Responsibilities:
    - Define I/O model contract (ModelDemotionCheckRequest -> ModelDemotionCheckResult)
    - Delegate all execution to handlers via base class
    - NO custom logic - pure declarative shell

The actual handler execution and routing is performed by:
    - Direct handler invocation by callers
    - Or RuntimeHostProcess for workflow coordination

Handlers receive their dependencies directly via parameter injection:
    - check_and_demote_patterns(repository, producer, request, topic_env_prefix)
    - demote_pattern(repository, producer, pattern_id, pattern_data, ...)

Related Modules:
    - contract.yaml: Handler routing and I/O model definitions
    - handlers/handler_demotion.py: Demotion handler functions

Related Tickets:
    - OMN-1681: Auto-demote logic for patterns failing quality thresholds
    - OMN-1757: Refactor to declarative pattern
"""

from __future__ import annotations

from omnibase_core.nodes.node_effect import NodeEffect


class NodePatternDemotionEffect(NodeEffect):
    """Declarative effect node for demoting validated patterns to deprecated status.

    This effect node is a lightweight shell that defines the I/O contract
    for pattern demotion operations. All routing and execution logic is driven
    by contract.yaml - this class contains NO custom routing code.

    Supported Operations (defined in contract.yaml handler_routing):
        - check_and_demote: Check validated patterns and demote those failing gates

    Dependency Injection:
        Handlers are invoked by callers with their dependencies
        (repository, producer, topic_env_prefix). This node contains NO
        instance variables for handlers or registries.

    Example:
        ```python
        from omnibase_core.models.container import ModelONEXContainer
        from omniintelligence.nodes.node_pattern_demotion_effect import (
            NodePatternDemotionEffect,
            check_and_demote_patterns,
        )

        # Create effect node via container (pure declarative shell)
        container = ModelONEXContainer()
        effect = NodePatternDemotionEffect(container)

        # Handlers are invoked directly with their dependencies
        result = await check_and_demote_patterns(
            repository=db_connection,
            producer=kafka_producer,
            request=ModelDemotionCheckRequest(dry_run=False),
            topic_env_prefix="dev",
        )

        # Or use RuntimeHostProcess for event-driven execution
        # which reads handler_routing from contract.yaml
        ```
    """

    # Pure declarative shell - all behavior defined in contract.yaml


__all__ = ["NodePatternDemotionEffect"]
