class CDMValidationError(RuntimeError):
    pass
