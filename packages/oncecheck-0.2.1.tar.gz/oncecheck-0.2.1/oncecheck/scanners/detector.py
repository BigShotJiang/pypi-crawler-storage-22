"""Auto-detect the project type (iOS, Android, Web) for a given directory."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import List


class Platform(str, Enum):
    IOS = "ios"
    ANDROID = "android"
    WEB = "web"


@dataclass
class DetectionResult:
    platform: Platform
    project_root: Path
    project_type: str  # e.g. "SwiftUI", "Gradle/Kotlin", "Next.js"
    confidence: float  # 0.0 – 1.0


# --- iOS detection -----------------------------------------------------------

_IOS_INDICATORS = {
    "*.xcodeproj": ("Xcode", 0.9),
    "*.xcworkspace": ("Xcode Workspace", 0.9),
    "Info.plist": ("iOS Plist", 0.7),
    "Package.swift": ("Swift Package", 0.6),
    "Podfile": ("CocoaPods", 0.7),
}

_IOS_SOURCE_GLOBS = ["**/*.swift", "**/*.m", "**/*.mm"]


def _detect_ios(root: Path) -> List[DetectionResult]:
    results: List[DetectionResult] = []
    best_confidence = 0.0
    best_type = "iOS"

    for pattern, (label, conf) in _IOS_INDICATORS.items():
        if list(root.glob(pattern)):
            if conf > best_confidence:
                best_confidence = conf
                best_type = label

    # Check for Swift / ObjC source files as supporting evidence
    has_swift = bool(list(root.glob("**/*.swift"))[:1])
    has_objc = bool(list(root.glob("**/*.m"))[:1])

    if has_swift:
        best_type = "SwiftUI / UIKit"
        best_confidence = max(best_confidence, 0.8)
    elif has_objc:
        best_type = "Objective-C"
        best_confidence = max(best_confidence, 0.7)

    if best_confidence > 0:
        results.append(
            DetectionResult(Platform.IOS, root, best_type, best_confidence)
        )
    return results


# --- Android detection --------------------------------------------------------

_ANDROID_INDICATORS = {
    "build.gradle": ("Gradle", 0.8),
    "build.gradle.kts": ("Gradle (Kotlin DSL)", 0.8),
    "settings.gradle": ("Gradle", 0.6),
    "settings.gradle.kts": ("Gradle (Kotlin DSL)", 0.6),
    "AndroidManifest.xml": ("Android Manifest", 0.9),
    "**/AndroidManifest.xml": ("Android Manifest", 0.9),
}


def _detect_android(root: Path) -> List[DetectionResult]:
    results: List[DetectionResult] = []
    best_confidence = 0.0
    best_type = "Android"

    for pattern, (label, conf) in _ANDROID_INDICATORS.items():
        if list(root.glob(pattern)):
            if conf > best_confidence:
                best_confidence = conf
                best_type = label

    has_kotlin = bool(list(root.glob("**/*.kt"))[:1])
    has_java = bool(list(root.glob("**/*.java"))[:1])

    if has_kotlin:
        best_type = "Gradle / Kotlin"
        best_confidence = max(best_confidence, 0.8)
    elif has_java:
        best_type = "Gradle / Java"
        best_confidence = max(best_confidence, 0.7)

    if best_confidence > 0:
        results.append(
            DetectionResult(Platform.ANDROID, root, best_type, best_confidence)
        )
    return results


# --- Web detection ------------------------------------------------------------

_WEB_INDICATORS = {
    "package.json": ("Node.js", 0.5),
    "next.config.js": ("Next.js", 0.9),
    "next.config.ts": ("Next.js", 0.9),
    "next.config.mjs": ("Next.js", 0.9),
    "nuxt.config.js": ("Nuxt", 0.9),
    "nuxt.config.ts": ("Nuxt", 0.9),
    "astro.config.mjs": ("Astro", 0.9),
    "astro.config.ts": ("Astro", 0.9),
    "vite.config.js": ("Vite", 0.8),
    "vite.config.ts": ("Vite", 0.8),
    "vue.config.js": ("Vue CLI", 0.8),
    "angular.json": ("Angular", 0.9),
    "svelte.config.js": ("SvelteKit", 0.9),
}


def _detect_web(root: Path) -> List[DetectionResult]:
    results: List[DetectionResult] = []
    best_confidence = 0.0
    best_type = "Web"

    for pattern, (label, conf) in _WEB_INDICATORS.items():
        if (root / pattern).exists():
            if conf > best_confidence:
                best_confidence = conf
                best_type = label

    if best_confidence > 0:
        results.append(
            DetectionResult(Platform.WEB, root, best_type, best_confidence)
        )
    return results


# --- Public API ---------------------------------------------------------------


def detect_platforms(project_path: str | Path) -> List[DetectionResult]:
    """Return all detected platforms for the given project directory, sorted by confidence."""
    root = Path(project_path).resolve()
    if not root.is_dir():
        raise FileNotFoundError(f"Not a directory: {root}")

    detections: List[DetectionResult] = []
    detections.extend(_detect_ios(root))
    detections.extend(_detect_android(root))
    detections.extend(_detect_web(root))

    detections.sort(key=lambda d: d.confidence, reverse=True)
    return detections
