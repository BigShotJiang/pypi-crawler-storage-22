"""iOS compliance scanner — parses Info.plist, entitlements, and Swift/ObjC source."""

from __future__ import annotations

import plistlib
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..engine.runner import Finding


def scan(project_root: Path) -> List[Finding]:
    """Run all iOS compliance checks and return findings."""
    findings: List[Finding] = []
    root = Path(project_root).resolve()

    plist_data = _load_info_plist(root)
    entitlements = _load_entitlements(root)
    source_contents = _collect_source(root)

    findings.extend(_check_privacy_permissions(root, plist_data, source_contents))
    findings.extend(_check_privacy_manifest(root))
    findings.extend(_check_ats(plist_data, source_contents))
    findings.extend(_check_secrets(source_contents))
    findings.extend(_check_ssl_pinning(source_contents))
    findings.extend(_check_metadata(root, plist_data))
    findings.extend(_check_entitlements(entitlements, source_contents))
    findings.extend(_check_keychain_usage(source_contents))
    findings.extend(_check_app_clips(root, plist_data))

    return findings


# ---------------------------------------------------------------------------
# File loaders
# ---------------------------------------------------------------------------

def _load_info_plist(root: Path) -> Dict[str, Any]:
    """Find and parse the first Info.plist in the project."""
    for plist_path in root.rglob("Info.plist"):
        # Skip build artifacts
        if any(part in str(plist_path) for part in ["DerivedData", "build/", ".build/"]):
            continue
        # Prevent symlink escape
        try:
            resolved = plist_path.resolve()
            if not str(resolved).startswith(str(root.resolve())):
                continue
        except OSError:
            continue
        try:
            with open(plist_path, "rb") as f:
                return plistlib.load(f)
        except (plistlib.InvalidFileException, OSError, ValueError):
            continue
    return {}


def _load_entitlements(root: Path) -> Dict[str, Any]:
    """Find and parse the first .entitlements file."""
    for ent_path in root.rglob("*.entitlements"):
        try:
            resolved = ent_path.resolve()
            if not str(resolved).startswith(str(root.resolve())):
                continue
        except OSError:
            continue
        try:
            with open(ent_path, "rb") as f:
                return plistlib.load(f)
        except (plistlib.InvalidFileException, OSError, ValueError):
            continue
    return {}


def _collect_source(root: Path, limit: int = 500) -> str:
    """Concatenate source file contents for pattern matching (capped)."""
    chunks: List[str] = []
    count = 0
    for ext in ("*.swift", "*.m", "*.mm", "*.h"):
        for src in root.rglob(ext):
            if any(p in str(src) for p in ["DerivedData", "build/", "Pods/", ".build/"]):
                continue
            try:
                chunks.append(src.read_text(errors="ignore"))
            except OSError:
                continue
            count += 1
            if count >= limit:
                break
    return "\n".join(chunks)


# ---------------------------------------------------------------------------
# Privacy & Permissions (IOS-PRIV-*)
# ---------------------------------------------------------------------------

_PRIVACY_CHECKS = [
    {
        "id": "IOS-PRIV-001",
        "plist_key": "NSCameraUsageDescription",
        "patterns": [r"AVCaptureSession", r"AVCaptureDevice", r"UIImagePickerController.*camera"],
        "summary": "Missing NSCameraUsageDescription when camera APIs detected",
        "fix": "Add NSCameraUsageDescription key to Info.plist with a user-facing explanation.",
        "reference": "Apple App Store Review Guidelines 5.1.1",
        "severity": "FAIL",
    },
    {
        "id": "IOS-PRIV-002",
        "plist_key": "NSPhotoLibraryUsageDescription",
        "patterns": [r"PHPhotoLibrary", r"UIImagePickerController", r"PHAsset"],
        "summary": "Missing NSPhotoLibraryUsageDescription when photo access detected",
        "fix": "Add NSPhotoLibraryUsageDescription key to Info.plist.",
        "reference": "Apple App Store Review Guidelines 5.1.1",
        "severity": "FAIL",
    },
    {
        "id": "IOS-PRIV-003",
        "plist_key": "NSUserTrackingUsageDescription",
        "patterns": [r"ASIdentifierManager", r"ATTrackingManager", r"advertisingIdentifier"],
        "summary": "Missing NSUserTrackingUsageDescription when IDFA used",
        "fix": "Add NSUserTrackingUsageDescription key to Info.plist and implement ATTrackingManager prompt.",
        "reference": "Apple App Tracking Transparency",
        "severity": "FAIL",
    },
    {
        "id": "IOS-PRIV-004",
        "plist_key": "NSLocationWhenInUseUsageDescription",
        "patterns": [r"CLLocationManager", r"requestWhenInUseAuthorization", r"requestAlwaysAuthorization"],
        "summary": "Location permission requested without justification string",
        "fix": "Add NSLocationWhenInUseUsageDescription to Info.plist.",
        "reference": "Apple App Store Review Guidelines 5.1.1",
        "severity": "WARN",
    },
    {
        "id": "IOS-PRIV-005",
        "plist_key": "NSMicrophoneUsageDescription",
        "patterns": [r"AVAudioSession", r"AVAudioRecorder", r"AVAudioEngine", r"requestRecordPermission"],
        "summary": "Missing NSMicrophoneUsageDescription when microphone APIs detected",
        "fix": "Add NSMicrophoneUsageDescription key to Info.plist.",
        "reference": "Apple App Store Review Guidelines 5.1.1",
        "severity": "FAIL",
    },
    {
        "id": "IOS-PRIV-006",
        "plist_key": "NSContactsUsageDescription",
        "patterns": [r"CNContactStore", r"ABAddressBook"],
        "summary": "Missing NSContactsUsageDescription when contacts APIs detected",
        "fix": "Add NSContactsUsageDescription key to Info.plist.",
        "reference": "Apple App Store Review Guidelines 5.1.1",
        "severity": "FAIL",
    },
    {
        "id": "IOS-PRIV-009",
        "plist_key": "NSHealthShareUsageDescription",
        "patterns": [r"HKHealthStore", r"HKObjectType", r"HKSampleQuery", r"HealthKit"],
        "summary": "Missing NSHealthShareUsageDescription when HealthKit APIs detected",
        "fix": "Add NSHealthShareUsageDescription (and NSHealthUpdateUsageDescription if writing) to Info.plist.",
        "reference": "Apple App Store Review Guidelines 5.1.1 — HealthKit",
        "severity": "FAIL",
    },
    {
        "id": "IOS-PRIV-010",
        "plist_key": "NSHomeKitUsageDescription",
        "patterns": [r"HMHomeManager", r"HMAccessory", r"HomeKit"],
        "summary": "Missing NSHomeKitUsageDescription when HomeKit APIs detected",
        "fix": "Add NSHomeKitUsageDescription key to Info.plist.",
        "reference": "Apple App Store Review Guidelines 5.1.1 — HomeKit",
        "severity": "FAIL",
    },
]


def _check_privacy_permissions(root: Path, plist: dict, source: str) -> List[Finding]:
    findings: List[Finding] = []
    for check in _PRIVACY_CHECKS:
        has_key = check["plist_key"] in plist
        uses_api = any(re.search(p, source) for p in check["patterns"])
        if uses_api and not has_key:
            findings.append(Finding(
                rule_id=check["id"],
                severity=check["severity"],
                message=check["summary"],
                fix=check["fix"],
                reference=check["reference"],
            ))
    return findings


# ---------------------------------------------------------------------------
# Privacy Manifest (IOS-PRIV-007/008) — CRITICAL for App Store 2024+
# ---------------------------------------------------------------------------

_REQUIRED_REASON_APIS = [
    r"NSFileSystemFreeSize",
    r"systemUptime",
    r"mach_absolute_time",
    r"NSProcessInfo.*systemUptime",
    r"UserDefaults",
    r"NSUserDefaults",
    r"activeCalendars",
    r"freeSize",
    r"volumeAvailableCapacity",
]


def _check_privacy_manifest(root: Path) -> List[Finding]:
    """Check for Apple Privacy Manifest (PrivacyInfo.xcprivacy) — required since Spring 2024."""
    findings: List[Finding] = []

    privacy_manifests = list(root.rglob("PrivacyInfo.xcprivacy"))
    privacy_manifests = [p for p in privacy_manifests if "build/" not in str(p) and "DerivedData" not in str(p)]

    if not privacy_manifests:
        findings.append(Finding(
            rule_id="IOS-PRIV-007",
            severity="FAIL",
            message="Missing Privacy Manifest (PrivacyInfo.xcprivacy) — required for App Store submission",
            fix="Create a PrivacyInfo.xcprivacy file declaring privacy nutrition labels and required reason APIs.",
            reference="https://developer.apple.com/documentation/bundleresources/privacy_manifest_files",
        ))

    # Check for Required Reason APIs usage without declaration
    source = _collect_source(root)
    used_apis = []
    for pattern in _REQUIRED_REASON_APIS:
        if re.search(pattern, source):
            used_apis.append(pattern)

    if used_apis and not privacy_manifests:
        findings.append(Finding(
            rule_id="IOS-PRIV-008",
            severity="FAIL",
            message=f"Required Reason APIs used ({len(used_apis)} types) without Privacy Manifest declaration",
            fix="Declare each Required Reason API usage in PrivacyInfo.xcprivacy with the appropriate reason code.",
            reference="https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_use_of_required_reason_api",
        ))

    return findings


# ---------------------------------------------------------------------------
# App Transport Security (IOS-SEC-*)
# ---------------------------------------------------------------------------

def _check_ats(plist: dict, source: str) -> List[Finding]:
    findings: List[Finding] = []

    ats = plist.get("NSAppTransportSecurity", {})
    if isinstance(ats, dict) and ats.get("NSAllowsArbitraryLoads") is True:
        findings.append(Finding(
            rule_id="IOS-SEC-001",
            severity="FAIL",
            message="ATS disabled globally (NSAllowsArbitraryLoads is true)",
            fix="Remove NSAllowsArbitraryLoads or set to false. Use exception domains for specific hosts.",
            reference="Apple App Store Review Guidelines 2.1",
        ))

    http_urls = re.findall(r'http://[^\s"\'>]+', source)
    if http_urls:
        findings.append(Finding(
            rule_id="IOS-SEC-002",
            severity="WARN",
            message=f"Non-HTTPS endpoints detected ({len(http_urls)} occurrence(s))",
            fix="Upgrade all endpoints to HTTPS.",
            reference="Apple ATS documentation",
        ))

    return findings


# ---------------------------------------------------------------------------
# Hardcoded Secrets (IOS-SEC-003)
# ---------------------------------------------------------------------------

_SECRET_PATTERNS = [
    (r'(?i)(?:api[_-]?key|apikey)\s*[:=]\s*["\'][A-Za-z0-9_\-]{16,}["\']', "API key"),
    (r'(?i)(?:secret|token|password|passwd)\s*[:=]\s*["\'][A-Za-z0-9_\-]{8,}["\']', "Secret/token"),
    (r'(?i)sk_(?:live|test)_[A-Za-z0-9]{24,}', "Stripe key"),
    (r'AIza[0-9A-Za-z_\-]{35}', "Google API key"),
    (r'(?i)aws[_-]?(?:access[_-]?key|secret)\s*[:=]\s*["\'][A-Za-z0-9/+=]{16,}["\']', "AWS credential"),
    (r'ghp_[A-Za-z0-9]{36}', "GitHub personal access token"),
]


def _check_secrets(source: str) -> List[Finding]:
    """Detect hardcoded API keys, tokens, and secrets in source code."""
    findings: List[Finding] = []
    found_types: List[str] = []

    for pattern, label in _SECRET_PATTERNS:
        if re.search(pattern, source):
            found_types.append(label)

    if found_types:
        findings.append(Finding(
            rule_id="IOS-SEC-003",
            severity="FAIL",
            message=f"Hardcoded secrets detected in source code: {', '.join(found_types)}",
            fix="Move secrets to environment variables, Keychain, or a secure configuration management system.",
            reference="OWASP Mobile Security — M9 Reverse Engineering",
        ))

    return findings


# ---------------------------------------------------------------------------
# SSL Certificate Pinning (IOS-SEC-004)
# ---------------------------------------------------------------------------

_SSL_PINNING_PATTERNS = [
    r"URLSessionDelegate",
    r"didReceive\s+challenge.*URLAuthenticationChallenge",
    r"TrustKit",
    r"SSLPinningMode",
    r"AlamofireExtended.*ServerTrustManager",
    r"pinnedCertificates",
    r"evaluateServerTrust",
]


def _check_ssl_pinning(source: str) -> List[Finding]:
    """Check if the app implements SSL certificate pinning."""
    findings: List[Finding] = []

    # Only warn if the app makes network calls but doesn't pin
    network_patterns = [r"URLSession", r"Alamofire", r"AF\.", r"URLRequest", r"httpBody"]
    makes_network_calls = any(re.search(p, source) for p in network_patterns)
    has_pinning = any(re.search(p, source) for p in _SSL_PINNING_PATTERNS)

    if makes_network_calls and not has_pinning:
        findings.append(Finding(
            rule_id="IOS-SEC-004",
            severity="WARN",
            message="No SSL certificate pinning detected for network communications",
            fix="Implement SSL pinning using URLSessionDelegate, TrustKit, or Alamofire's ServerTrustManager.",
            reference="OWASP Mobile Security — M3 Insecure Communication",
        ))

    return findings


# ---------------------------------------------------------------------------
# Metadata & Packaging (IOS-META-*)
# ---------------------------------------------------------------------------

def _check_metadata(root: Path, plist: dict) -> List[Finding]:
    findings: List[Finding] = []

    # IOS-META-001 — App icons
    icon_sets = list(root.rglob("AppIcon.appiconset"))
    if not icon_sets:
        findings.append(Finding(
            rule_id="IOS-META-001",
            severity="FAIL",
            message="Missing required app icons (no AppIcon.appiconset found)",
            fix="Add required app icon assets to Assets.xcassets/AppIcon.appiconset.",
            reference="Apple Human Interface Guidelines — App Icons",
        ))

    # IOS-META-002 — Bundle identifier format
    bundle_id = plist.get("CFBundleIdentifier", "")
    if bundle_id and not re.match(r'^[a-zA-Z][a-zA-Z0-9\-\.]*$', bundle_id):
        # Ignore Xcode variables like $(PRODUCT_BUNDLE_IDENTIFIER)
        if "$(" not in bundle_id:
            findings.append(Finding(
                rule_id="IOS-META-002",
                severity="FAIL",
                message=f"Bundle identifier has invalid format: {bundle_id}",
                fix="Ensure CFBundleIdentifier uses reverse domain notation (e.g. com.example.app).",
                reference="Apple Developer Documentation — CFBundleIdentifier",
            ))

    # IOS-META-003 — Launch screen
    has_launch_key = "UILaunchStoryboardName" in plist
    has_launch_file = (
        bool(list(root.rglob("LaunchScreen.storyboard")))
        or bool(list(root.rglob("LaunchScreen.xib")))
    )
    if not has_launch_key and not has_launch_file:
        findings.append(Finding(
            rule_id="IOS-META-003",
            severity="WARN",
            message="Missing launch screen configuration",
            fix="Add a LaunchScreen.storyboard or set UILaunchStoryboardName in Info.plist.",
            reference="Apple Human Interface Guidelines — Launch Screens",
        ))

    # IOS-META-004 — Minimum deployment target
    min_target = plist.get("MinimumOSVersion", "")
    if min_target:
        try:
            major = int(min_target.split(".")[0])
            if major < 16:
                findings.append(Finding(
                    rule_id="IOS-META-004",
                    severity="INFO",
                    message=f"Minimum deployment target is iOS {min_target} — consider raising to iOS 16+",
                    fix="Update MinimumOSVersion to at least 16.0 to access modern APIs.",
                    reference="Apple Developer Documentation — Deployment Target",
                ))
        except (ValueError, IndexError):
            pass

    return findings


# ---------------------------------------------------------------------------
# Entitlements (IOS-ENT-*)
# ---------------------------------------------------------------------------

def _check_entitlements(entitlements: dict, source: str) -> List[Finding]:
    findings: List[Finding] = []

    # IOS-ENT-001 — iCloud enabled but unused
    icloud_ids = entitlements.get("com.apple.developer.icloud-container-identifiers")
    if icloud_ids:
        icloud_patterns = [r"CKContainer", r"NSUbiquitousKeyValueStore", r"CloudKit"]
        uses_icloud = any(re.search(p, source) for p in icloud_patterns)
        if not uses_icloud:
            findings.append(Finding(
                rule_id="IOS-ENT-001",
                severity="WARN",
                message="iCloud entitlement enabled but no iCloud usage detected in source",
                fix="Remove iCloud entitlement if not used, or implement iCloud functionality.",
                reference="Apple Developer Documentation — iCloud",
            ))

    # IOS-ENT-002 — Push notification entitlement missing but APNs used
    has_aps = "aps-environment" in entitlements
    push_patterns = [r"UNUserNotificationCenter", r"registerForRemoteNotifications", r"didRegisterForRemoteNotificationsWithDeviceToken"]
    uses_push = any(re.search(p, source) for p in push_patterns)
    if uses_push and not has_aps:
        findings.append(Finding(
            rule_id="IOS-ENT-002",
            severity="FAIL",
            message="Push notification entitlement missing but APNs APIs used",
            fix="Add aps-environment entitlement to your app's entitlements file.",
            reference="Apple Developer Documentation — Push Notifications",
        ))

    return findings


# ---------------------------------------------------------------------------
# Keychain Usage Audit (IOS-SEC-005)
# ---------------------------------------------------------------------------

_SENSITIVE_USERDEFAULTS_PATTERNS = [
    r'(?i)UserDefaults[^}]*(?:password|token|secret|apiKey|api_key|accessToken|access_token|refreshToken|refresh_token)',
    r'(?i)(?:set|setValue)\s*\([^)]*(?:password|token|secret|apiKey|api_key|accessToken|refreshToken)[^)]*,\s*forKey',
    r'(?i)NSUserDefaults[^}]*(?:password|token|secret|apiKey|api_key|accessToken)',
]


def _check_keychain_usage(source: str) -> List[Finding]:
    """Detect sensitive data stored in UserDefaults instead of Keychain."""
    findings: List[Finding] = []

    for pattern in _SENSITIVE_USERDEFAULTS_PATTERNS:
        if re.search(pattern, source):
            findings.append(Finding(
                rule_id="IOS-SEC-005",
                severity="FAIL",
                message="Sensitive data (passwords/tokens) stored in UserDefaults instead of Keychain",
                fix="Use Keychain Services (SecItemAdd/SecItemCopyMatching) or a wrapper like KeychainAccess for sensitive data.",
                reference="Apple Security — Keychain Services",
            ))
            break

    return findings


# ---------------------------------------------------------------------------
# App Clips (IOS-META-005)
# ---------------------------------------------------------------------------

def _check_app_clips(root: Path, plist: dict) -> List[Finding]:
    """Check App Clip configuration — requires iOS 14+."""
    findings: List[Finding] = []

    # Detect App Clip presence
    app_clip_indicators = list(root.rglob("*.appclip")) + list(root.rglob("AppClip"))
    source = _collect_source(root)
    has_app_clip_code = bool(re.search(r'NSUserActivity|appClip|NSAppClip|app_clip_url', source))

    if app_clip_indicators or has_app_clip_code:
        min_target = plist.get("MinimumOSVersion", "")
        if min_target:
            try:
                major = int(min_target.split(".")[0])
                if major < 14:
                    findings.append(Finding(
                        rule_id="IOS-META-005",
                        severity="FAIL",
                        message=f"App Clips require iOS 14+ but MinimumOSVersion is {min_target}",
                        fix="Set MinimumOSVersion to at least 14.0 for App Clip targets.",
                        reference="Apple Developer Documentation — App Clips",
                    ))
            except (ValueError, IndexError):
                pass

    return findings
