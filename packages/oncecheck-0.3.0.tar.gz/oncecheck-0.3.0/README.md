# Oncecheck CLI

A terminal-first CLI tool that scans iOS, Android, and Web projects for launch-critical compliance risks.

## Features

- **73+ compliance rules** across iOS, Android, Web, and cross-platform categories
- **Auto-detection** — identifies your project type automatically
- **Interactive browser** — arrow-key driven UI to explore findings
- **Multiple export formats** — JSON, SARIF 2.1, plain text
- **CI/CD ready** — exit codes: 0 (pass), 1 (warnings), 2 (failures)
- **Cross-platform checks** — COPPA, HIPAA, PCI-DSS, accessibility, supply chain
- **Rule suppression** — `.oncecheckignore` file and `.oncecheckrc` config
- **Shell completions** — bash, zsh, and fish

## Rule Categories

| Platform | Rules | Covers |
|----------|-------|--------|
| iOS | 20 | Info.plist, ATS, entitlements, privacy manifests, HealthKit, Keychain |
| Android | 18 | AndroidManifest, target SDK, permissions, ProGuard, Play Integrity |
| Web | 27 | CSP, CORS, OWASP Top 10, accessibility, privacy, cookies |
| Common | 8 | COPPA, HIPAA, PCI-DSS, color contrast, data retention, supply chain |

## Installation

```bash
pip install oncecheck
```

### Development

```bash
git clone <repo-url>
cd oncecheck-cli
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

## Usage

### Interactive mode

```bash
oncecheck
```

Launches the full interactive UI with welcome screen, menu navigation, and findings browser.

### Direct scan

```bash
# Auto-detect platform
oncecheck scan ./my-project

# Force a specific platform
oncecheck scan ./my-project --platform ios

# Export as JSON (Team plan)
oncecheck scan ./my-project --format json --output results.json

# Export as SARIF (Team plan — for GitHub/VS Code)
oncecheck scan ./my-project --format sarif --output results.sarif

# Interactive findings browser
oncecheck scan ./my-project --interactive

# Fail CI on warnings or higher
oncecheck scan ./my-project --fail-on WARN
```

### Authentication

```bash
# Sign in (opens browser)
oncecheck login

# Check status
oncecheck status

# Sign out
oncecheck logout
```

### Configuration

```bash
# Generate config files in your project
oncecheck init ./my-project
```

This creates:
- `.oncecheckrc` — YAML config for disabled rules, severity overrides, and fail threshold
- `.oncecheckignore` — one rule ID per line to suppress

Example `.oncecheckrc`:
```yaml
disabled_rules:
  - IOS-SEC-001
  - WEB-OWASP-003

severity_overrides:
  WEB-A11Y-001: INFO

fail_on: FAIL
```

### Shell Completions

```bash
# Bash
oncecheck completions bash >> ~/.bashrc

# Zsh
oncecheck completions zsh >> ~/.zshrc

# Fish
oncecheck completions fish > ~/.config/fish/completions/oncecheck.fish
```

## CI/CD Integration

```yaml
# GitHub Actions example
- name: Compliance scan
  run: |
    pip install oncecheck
    oncecheck login
    oncecheck scan . --fail-on WARN

- name: Upload SARIF (Team plan)
  run: oncecheck scan . --format sarif --output results.sarif
```

### Exit Codes

| Code | Meaning |
|------|---------|
| 0 | No issues (or only INFO) |
| 1 | Warnings found |
| 2 | Failures found |

## Plans

| Feature | Starter (Free) | Team ($19/mo or $190/yr) |
|---------|----------------|--------------------------|
| Compliance rules | 35 | All 73+ |
| Scans per day | 3 | Unlimited |
| Terminal output | Yes | Yes |
| JSON/text export | — | Yes |
| SARIF export | — | Yes |
| File export (`--output`) | — | Yes |
| Priority support | — | Yes |

## Testing

```bash
python -m pytest tests/ -v
```

## License

MIT
