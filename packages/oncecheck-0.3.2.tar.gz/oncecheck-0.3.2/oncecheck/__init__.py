"""Oncecheck — CLI compliance scanner for iOS, Android, and Web projects."""

__version__ = "0.3.2"
