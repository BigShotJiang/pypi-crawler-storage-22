"""Oncecheck — CLI compliance scanner for iOS, Android, and Web projects."""

__version__ = "0.5.3"
