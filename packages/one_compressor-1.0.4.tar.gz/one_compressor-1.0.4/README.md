# Neural-Adaptive One Compressor

An intelligent, **omnivore compression engine** designed to drastically reduce the file size of **Images, Audio, and
Documents** without compromising clarity.

Unlike standard compressors that rasterize entire pages or destroy audio clarity, this engine uses a **"Container-Aware
Extraction"** strategy combined with **Deep Learning** and **Psychoacoustic DSP**.

## 📂 Supported Formats

| Category      | Formats                   | Technology                               |
|:--------------|:--------------------------|:-----------------------------------------|
| **Images**    | JPG, PNG, WebP, TIFF, BMP | Neural Denoising + Adaptive Quantization |
| **Documents** | PDF, DOCX, PPTX, XLSX     | Container Extraction + Structure Rebuild |
| **Audio**     | WAV (Raw PCM)             | Spectral Pruning + $\mu$-law Companding  |

## ⚙️ Technical Methodology

1. **Neural Denoising:** Uses a Variational Autoencoder to remove invisible sensor noise from images before compression.
2. **Reconstruct & Flatten:** A specialized algorithm to fix "Black Box" issues in PDFs by properly compositing
   transparency on white backgrounds.
3. **True Color Preservation:** Reduces PNG/TIFF size using RGB Posterization without converting to 8-bit palette mode.