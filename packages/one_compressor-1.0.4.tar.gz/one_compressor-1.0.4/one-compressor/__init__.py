from .model import OneCompressor

__version__ = "1.0.0"
