import os
import numpy as np
import librosa
import soundfile as sf

# --- KONFIGURASI ---
TARGET_RATIO = 0.20


def compress_wav_smart(input_path, output_path):
    print(f"🎵 Memproses Audio: {input_path}")

    if not os.path.exists(input_path):
        print("❌ File tidak ditemukan")
        return

    try:
        # Load audio (sr=None mengambil sample rate asli)
        y, sr = librosa.load(input_path, sr=None, mono=False)

        original_size = os.path.getsize(input_path)

        # 1. CHANNEL MIXING (Stereo -> Mono)
        channels = 1 if y.ndim == 1 else y.shape[0]
        if channels > 1:
            # print("   - Mixing Stereo ke Mono...")
            y = librosa.to_mono(y)

        # 2. SPECTRAL PRUNING (Downsampling)
        # 22050 Hz cukup untuk suara manusia (Range frekuensi s/d 11kHz)
        target_sr = 22050
        if sr > target_sr:
            # print(f"   - Resampling {sr}Hz -> {target_sr}Hz...")
            y = librosa.resample(y, orig_sr=sr, target_sr=target_sr)
            final_sr = target_sr
        else:
            final_sr = sr

        # 3. NORMALIZATION (Agar volume optimal sebelum dikompres)
        max_val = np.max(np.abs(y))
        if max_val > 0:
            y = y / max_val

        # 4. ENCODING (u-Law vs PCM_U8)
        # PCM_U8 = Linear 8-bit (Ada desis/noise)
        # ULAW   = Logarithmic 8-bit (Kualitas setara 14-bit, standar telepon)
        # Kita gunakan PCM_U8 sesuai request eksisting Anda,
        # tapi jika ingin lebih jernih ganti ke 'ULAW'
        sf.write(output_path, y, final_sr, subtype='PCM_U8')

        # Cek hasil
        if os.path.exists(output_path):
            final_size = os.path.getsize(output_path)
            # print(f"✅ Selesai: {original_size/1024:.2f} KB -> {final_size/1024:.2f} KB")

    except Exception as e:
        print(f"❌ Error Audio Processing: {e}")
