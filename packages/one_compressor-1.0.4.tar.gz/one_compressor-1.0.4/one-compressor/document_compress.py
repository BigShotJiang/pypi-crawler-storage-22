import os
import io
import zipfile
import fitz  # PyMuPDF
import torch
import torch.nn.functional as F
from PIL import Image
from torchvision.transforms import ToTensor, ToPILImage
from compressai.zoo import mbt2018_mean

# --- KONFIGURASI GLOBAL ---
MIN_IMAGE_SIZE_KB = 5
MODEL_FILENAME = "mbt2018_mean_q1.pth.tar"  # Pastikan nama file sesuai dgn yg di folder

# --- GLOBAL VARIABLES (Untuk Dependency Injection) ---
# Kita set None dulu. Nanti diisi oleh model.py atau fungsi ensure_model_loaded
model = None
device = None


def get_device():
    if torch.backends.mps.is_available():
        return 'mps'
    elif torch.cuda.is_available():
        return 'cuda'
    else:
        return 'cpu'


def ensure_model_loaded():
    """
    Fungsi ini memastikan model sudah ada.
    1. Jika dipanggil dari model.py, variabel 'model' sudah diisi, jadi fungsi ini skip.
    2. Jika dijalankan sendirian, fungsi ini akan me-load model dari file lokal.
    """
    global model, device

    # Jika model sudah ada (di-inject), tidak perlu load lagi
    if model is not None:
        if device is None: device = next(model.parameters()).device
        return

    # Fallback: Load sendiri jika belum ada
    device = get_device()
    print(f"⚙️ Document Engine: Loading model independently on {device}...")

    # Setup Arsitektur
    model = mbt2018_mean(quality=1, pretrained=False)

    # Cek File Lokal
    if os.path.exists(MODEL_FILENAME):
        print(f"📂 Load Weights: {MODEL_FILENAME}")
        checkpoint = torch.load(MODEL_FILENAME, map_location=device)

        if "state_dict" in checkpoint:
            state_dict = checkpoint["state_dict"]
        else:
            state_dict = checkpoint

        model.load_state_dict(state_dict)
    else:
        print("⚠️ Local model not found, downloading default...")
        model = mbt2018_mean(quality=1, pretrained=True)

    model = model.eval().to(device)


def pad_divisible_by(x, div=64):
    h, w = x.size(2), x.size(3)
    pad_h = (div - (h % div)) % div
    pad_w = (div - (w % div)) % div
    x_padded = F.pad(x, (0, pad_w, 0, pad_h), mode='replicate')
    return x_padded, (h, w)


def compress_image_buffer(image_bytes):
    # PENTING: Pastikan model siap sebelum inferensi
    ensure_model_loaded()

    try:
        img = Image.open(io.BytesIO(image_bytes))

        if len(image_bytes) / 1024 < MIN_IMAGE_SIZE_KB:
            return image_bytes

        # --- LOGIKA FIX BLACK BOX (Flatten Transparency) ---
        if img.mode in ('RGBA', 'LA') or (img.mode == 'P' and 'transparency' in img.info):
            # Convert ke RGBA untuk handle palette
            img = img.convert('RGBA')
            # Buat background putih
            background = Image.new('RGB', img.size, (255, 255, 255))
            # Tempel gambar di atas putih menggunakan Alpha sebagai mask
            # Ini mencegah area transparan berubah jadi hitam
            background.paste(img, mask=img.split()[3])
            img_rgb = background
        else:
            img_rgb = img.convert('RGB')

        # --- AI INFERENCE ---
        x = ToTensor()(img_rgb).unsqueeze(0).to(device)
        x_padded, (orig_h, orig_w) = pad_divisible_by(x, 64)

        with torch.no_grad():
            out = model.forward(x_padded)

        x_hat = out['x_hat'].clamp(0, 1)
        x_hat = x_hat[:, :, :orig_h, :orig_w]
        cleaned_rgb = ToPILImage()(x_hat[0].cpu())

        # Save result (JPEG optimized for PDF embedding)
        out_buffer = io.BytesIO()
        cleaned_rgb.save(out_buffer, "JPEG", quality=60, optimize=True, subsampling=0)

        # Hanya return hasil jika ukurannya lebih kecil
        if out_buffer.getbuffer().nbytes < len(image_bytes):
            return out_buffer.getvalue()

        return image_bytes

    except Exception as e:
        # print(f"Error processing image buffer: {e}")
        return image_bytes


# --- FUNGSI PDF UTAMA ---
def compress_pdf(input_path, output_path):
    doc = fitz.open(input_path)
    images_compressed = 0
    # processed_xrefs = {} # Opsional: Cache xref jika perlu

    for page in doc:
        image_list = page.get_images(full=True)

        for img_info in image_list:
            xref = img_info[0]
            smask = img_info[1]

            # (Opsional) Cek Cache di sini jika ingin implementasi cache xref

            try:
                # --- REKONSTRUKSI GAMBAR (Fix Black Box & CMYK) ---
                if smask > 0:
                    pix0 = fitz.Pixmap(doc, xref)
                    pix1 = fitz.Pixmap(doc, smask)
                    pix = fitz.Pixmap(pix0)
                    pix.set_alpha(pix1.samples)
                else:
                    pix = fitz.Pixmap(doc, xref)

                # Fix CMYK Inverted Colors
                if pix.n - pix.alpha >= 4:
                    pix = fitz.Pixmap(fitz.csRGB, pix)

                img_bytes = pix.tobytes("png")

                # Kompres dengan AI
                new_bytes = compress_image_buffer(img_bytes)

                # Replace jika lebih kecil
                if len(new_bytes) < len(img_bytes):
                    # update_stream aman karena kita sudah flatten transparansi jadi JPEG solid
                    doc.update_stream(xref, new_bytes)
                    images_compressed += 1

                pix = None

            except Exception as e:
                # print(f"Skip xref {xref}: {e}")
                continue

    # Save dengan Garbage Collection & Clean
    doc.save(output_path, garbage=4, deflate=True, clean=True)
    doc.close()

    print(f"✅ PDF Selesai: {images_compressed} gambar dikompres.")


def compress_office(input_path, output_path):
    with zipfile.ZipFile(input_path, 'r') as zin:
        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                file_data = zin.read(item.filename)
                # Cek apakah file gambar
                if "media/" in item.filename and item.filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                    new_data = compress_image_buffer(file_data)
                    zout.writestr(item.filename, new_data)
                else:
                    zout.writestr(item, file_data)
    print("✅ Office Selesai.")
