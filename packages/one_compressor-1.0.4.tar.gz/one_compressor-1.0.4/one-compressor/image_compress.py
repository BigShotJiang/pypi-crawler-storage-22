import os
import io
import time
import torch
import torch.nn.functional as F
from PIL import Image, ImageOps
from torchvision.transforms import ToTensor, ToPILImage
from compressai.zoo import mbt2018_mean

# --- KONFIGURASI GLOBAL ---
MODEL_FILENAME = "mbt2018_mean_q1.pth.tar"  # Pastikan nama file sesuai dgn yg di folder

# --- GLOBAL VARIABLES (Untuk Dependency Injection) ---
model = None
device = None


def get_device():
    if torch.backends.mps.is_available():
        return 'mps'
    elif torch.cuda.is_available():
        return 'cuda'
    else:
        return 'cpu'


def ensure_model_loaded():
    """
    Fungsi ini memastikan model sudah ada.
    1. Jika dipanggil dari model.py, variabel 'model' sudah diisi, jadi fungsi ini skip.
    2. Jika dijalankan sendirian, fungsi ini akan me-load model dari file lokal.
    """
    global model, device

    # Jika model sudah ada (di-inject), tidak perlu load lagi
    if model is not None:
        if device is None: device = next(model.parameters()).device
        return

    # Fallback: Load sendiri jika belum ada
    device = get_device()
    print(f"⚙️ Image Engine: Loading model independently on {device}...")

    # Setup Arsitektur
    model = mbt2018_mean(quality=1, pretrained=False)

    # Cek File Lokal
    if os.path.exists(MODEL_FILENAME):
        print(f"📂 Load Weights: {MODEL_FILENAME}")
        checkpoint = torch.load(MODEL_FILENAME, map_location=device)

        if "state_dict" in checkpoint:
            state_dict = checkpoint["state_dict"]
        else:
            state_dict = checkpoint

        model.load_state_dict(state_dict)
    else:
        print("⚠️ Local model not found, downloading default...")
        model = mbt2018_mean(quality=1, pretrained=True)

    model = model.eval().to(device)


def pad_divisible_by(x, div=64):
    h, w = x.size(2), x.size(3)
    pad_h = (div - (h % div)) % div
    pad_w = (div - (w % div)) % div
    x_padded = F.pad(x, (0, pad_w, 0, pad_h), mode='replicate')
    return x_padded, (h, w)


def determine_strategy(file_size_bytes):
    file_size_kb = file_size_bytes / 1024

    if file_size_kb < 200:
        return {
            "use_ai": False,
            "target_ratio": 0.85,
            "min_quality_jpg": 85,
            "min_bits_png": 8,
            "png_strategy": "optimize_only"
        }
    elif file_size_kb < 500:
        return {
            "use_ai": True,
            "target_ratio": 0.60,
            "min_quality_jpg": 60,
            "min_bits_png": 6,
            "png_strategy": "posterize"
        }
    else:
        return {
            "use_ai": True,
            "target_ratio": 0.30,
            "min_quality_jpg": 20,
            "min_bits_png": 3,
            "png_strategy": "posterize"
        }


def process_image_universal(input_file):
    # Pastikan model siap sebelum inferensi
    ensure_model_loaded()

    if not os.path.exists(input_file):
        return None, "File not found"

    try:
        original_size = os.path.getsize(input_file)
        strategy = determine_strategy(original_size)
        target_size = original_size * strategy["target_ratio"]

        img = Image.open(input_file)
        original_format = img.format.upper() if img.format else "JPEG"

        has_alpha = False
        if img.mode in ('RGBA', 'LA') or (img.mode == 'P' and 'transparency' in img.info):
            has_alpha = True
            img = img.convert('RGBA')
            r, g, b, alpha = img.split()
            img_rgb = Image.merge('RGB', (r, g, b))
        else:
            img = img.convert('RGB')
            img_rgb = img
            alpha = None

        if strategy["use_ai"]:
            # Gunakan global model & device
            x = ToTensor()(img_rgb).unsqueeze(0).to(device)
            x_padded, (orig_h, orig_w) = pad_divisible_by(x, 64)

            with torch.no_grad():
                out = model.forward(x_padded)

            x_hat = out['x_hat'].clamp(0, 1)
            x_hat = x_hat[:, :, :orig_h, :orig_w]
            cleaned_rgb = ToPILImage()(x_hat[0].cpu())
        else:
            cleaned_rgb = img_rgb

        best_buffer = None

        if original_format in ['JPEG', 'JPG', 'WEBP']:
            current_quality = 95
            min_quality = strategy["min_quality_jpg"]

            while current_quality >= min_quality:
                buffer = io.BytesIO()

                if original_format == 'WEBP' and has_alpha:
                    final_img = cleaned_rgb.convert('RGBA')
                    final_img.putalpha(alpha)
                else:
                    final_img = cleaned_rgb

                if original_format == 'WEBP':
                    final_img.save(buffer, "WEBP", quality=current_quality, method=6)
                else:
                    final_img.save(buffer, "JPEG", quality=current_quality, optimize=True, subsampling=0)

                size = buffer.getbuffer().nbytes
                best_buffer = buffer

                if size <= target_size:
                    break
                current_quality -= 5
        else:
            if strategy["png_strategy"] == "optimize_only":
                buffer = io.BytesIO()
                if has_alpha:
                    final_img = cleaned_rgb.convert('RGBA')
                    final_img.putalpha(alpha)
                else:
                    final_img = cleaned_rgb
                final_img.save(buffer, "PNG", optimize=True, compress_level=9)
                best_buffer = buffer
            else:
                current_bits = 8
                min_bits = strategy["min_bits_png"]

                while current_bits >= min_bits:
                    buffer = io.BytesIO()
                    posterized_rgb = ImageOps.posterize(cleaned_rgb, current_bits)

                    if has_alpha:
                        posterized_rgb = posterized_rgb.convert('RGBA')
                        posterized_rgb.putalpha(alpha)
                        final_img = posterized_rgb
                    else:
                        final_img = posterized_rgb

                    if original_format == 'TIFF':
                        final_img.save(buffer, "TIFF", compression='tiff_lzw')
                    elif original_format == 'BMP':
                        final_img.save(buffer, "BMP")
                    else:
                        final_img.save(buffer, "PNG", optimize=True, compress_level=9)

                    size = buffer.getbuffer().nbytes
                    best_buffer = buffer

                    if size <= target_size:
                        break
                    current_bits -= 1
        if best_buffer:
            best_buffer.seek(0)
            return best_buffer, None
        else:
            return None, "Gagal membuat buffer"

    except Exception as e:
        return None, str(e)
