import os
import torch
from compressai.zoo import mbt2018_mean

# --- PERUBAHAN PENTING: RELATIVE IMPORT ---
# Gunakan titik (.) di depan nama module karena sekarang ada dalam satu package
from . import image_compress
from . import document_compress
from . import audio_compress


class OneCompressor:
    def __init__(self, model_path=None):
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        # print(f"⚡ OneCompressor initialized on {self.device}")

        # 1. SETUP MODEL
        self.net = mbt2018_mean(quality=1, pretrained=False)

        # 2. LOCATE WEIGHTS (BUNDLED)
        # Jika user tidak memberikan path, cari file di sebelah script ini
        if model_path is None:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            weights_path = os.path.join(current_dir, "mbt2018_mean_q1.pth.tar")
        else:
            weights_path = model_path

        # 3. LOAD WEIGHTS
        if os.path.exists(weights_path):
            try:
                checkpoint = torch.load(weights_path, map_location=self.device)
                state_dict = checkpoint["state_dict"] if "state_dict" in checkpoint else checkpoint
                self.net.load_state_dict(state_dict)
            except Exception as e:
                print(f"❌ Gagal memuat model internal: {e}")
                # Fallback download (opsional)
                self.net = mbt2018_mean(quality=1, pretrained=True)
        else:
            print(f"⚠️ Warning: Model lokal tidak ditemukan di {weights_path}")
            self.net = mbt2018_mean(quality=1, pretrained=True)

        self.net = self.net.to(self.device).eval()

        # 4. DEPENDENCY INJECTION
        image_compress.model = self.net
        image_compress.device = self.device

        document_compress.model = self.net
        document_compress.device = self.device

    def compress(self, input_file, output_file=None):
        if not os.path.exists(input_file):
            raise FileNotFoundError(f"File {input_file} tidak ditemukan")

        if not output_file:
            name, ext = os.path.splitext(input_file)
            output_file = f"{name}_compressed{ext}"

        ext = os.path.splitext(input_file)[1].lower()

        try:
            if ext == '.wav':
                audio_compress.compress_wav_smart(input_file, output_file)

            elif ext == '.pdf':
                document_compress.compress_pdf(input_file, output_file)

            elif ext in ['.docx', '.pptx', '.xlsx']:
                document_compress.compress_office(input_file, output_file)

            elif ext in ['.jpg', '.jpeg', '.png', '.webp', '.tiff', '.bmp']:
                compressed_buffer, error = image_compress.process_image_universal(input_file)
                if compressed_buffer:
                    with open(output_file, "wb") as f:
                        f.write(compressed_buffer.read())
                else:
                    raise RuntimeError(f"Image Error: {error}")
            else:
                raise ValueError(f"Format {ext} tidak didukung.")

            return output_file

        except Exception as e:
            print(f"❌ Error processing {input_file}: {e}")
            return None

### Cara Install & Pakai

# 1.  **Install (Developer Mode):**
#     Buka terminal di folder root (`one-compressor-project`), lalu ketik:
#     ```bash
#     pip install -e .
#     ```
#
# 2.  **Cara Pakai (Di Script Python Lain / Jupyter Notebook):**
#     Sekarang Anda bisa menggunakannya di mana saja di laptop Anda:
#
#     ```python
#     from one_compressor import OneCompressor
#
#     # Inisialisasi (Otomatis load model dari dalam folder package)
#     engine = OneCompressor()
#
#     # Pakai
#     engine.compress("Laporan.pdf")
#     ```
#
# 3.  **Build (Untuk Distribusi):**
#     Jika ingin membagikan ke orang lain sebagai file `.whl`:
#     ```bash
#     pip install build
#     python -m build
