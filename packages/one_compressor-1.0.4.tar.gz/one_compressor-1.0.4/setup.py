from setuptools import setup, find_packages
import os

here = os.path.abspath(os.path.dirname(__file__))

# Baca requirements.txt
try:
    with open(os.path.join(here, 'requirements.txt'), encoding='utf-8') as f:
        required = f.read().splitlines()
except FileNotFoundError:
    print("⚠️ Warning: requirements.txt tidak ditemukan, dependencies kosong.")
    required = []

# Baca deskripsi panjang dari README.md
try:
    with open(os.path.join(here, "README.md"), "r", encoding="utf-8") as fh:
        long_description = fh.read()
except FileNotFoundError:
    long_description = "AI-Powered Omnivore Compression Library"

setup(
    name="one-compressor",
    version="1.0.4",
    author="M Ainurrahman",
    author_email="enoraden@gmail.com",
    description="AI-Powered Omnivore Compression Library (Image, Doc, Audio)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="",  # Jika ada github, taruh di sini agar muncul link di PyPI
    packages=find_packages(),
    include_package_data=True,
    install_requires=required,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.10',
)
