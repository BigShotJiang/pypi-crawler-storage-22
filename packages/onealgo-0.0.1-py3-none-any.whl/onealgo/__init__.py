"""
OneAlgo - Full-stack algo trading framework.

This is a placeholder package. The full version is available at:
https://github.com/onealgo-team/onealgo
"""

__version__ = "0.0.1"
