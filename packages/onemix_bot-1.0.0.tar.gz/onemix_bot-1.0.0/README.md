# onemix-bot — Python SDK для ботов ONEMIX

Библиотека для создания ботов на платформе ONEMIX мессенджера.

## Установка

```bash
pip install onemix-bot
```

Или из исходников:

```bash
git clone <repo>
cd onemix-bot-sdk
pip install -e .
```

## Быстрый старт

```python
from onemix_bot import OnemixBot

bot = OnemixBot(
    token="YOUR_BOT_TOKEN",        # Получите у @botfather
    api_url="https://your-server.com"  # URL вашего ONEMIX сервера
)

@bot.command("start")
def on_start(msg):
    bot.reply(msg, "Привет! Я бот ONEMIX")

@bot.on_message()
def echo(msg):
    bot.reply(msg, f"Вы написали: {msg['content']}")

bot.run()
```

## API

### OnemixBot(token, api_url, poll_interval=2.0)

Создаёт экземпляр бота.

### Методы

| Метод | Описание |
|-------|----------|
| `bot.get_me()` | Информация о боте |
| `bot.send_message(chat_id, text)` | Отправить сообщение |
| `bot.reply(msg, text)` | Ответить на сообщение |
| `bot.get_updates(limit=100)` | Получить обновления |
| `bot.set_webhook(url, secret=None)` | Установить вебхук |
| `bot.delete_webhook()` | Удалить вебхук |
| `bot.set_commands(commands)` | Установить команды |
| `bot.run()` | Запустить polling loop |
| `bot.run_threaded()` | Запустить в фоновом потоке |
| `bot.stop()` | Остановить polling |
| `bot.process_update(update)` | Обработать обновление (для вебхуков) |

### Декораторы

```python
@bot.command("start")         # Обработка команды /start
@bot.on_message()             # Обработка всех текстовых сообщений
@bot.on_message(pattern=r"") # Обработка по regex-шаблону
```

## Webhook-режим

```python
from flask import Flask, request
from onemix_bot import OnemixBot

app = Flask(__name__)
bot = OnemixBot(token="TOKEN", api_url="https://server.com")

@bot.command("start")
def start(msg):
    bot.reply(msg, "Привет!")

@app.route("/webhook", methods=["POST"])
def webhook():
    bot.process_update(request.json)
    return "ok"

if __name__ == "__main__":
    bot.set_webhook("https://your-server.com/webhook")
    app.run(port=5000)
```

## Лицензия

MIT
