"""
ONEMIX Bot SDK
Python library for building bots on the ONEMIX messenger platform.

Usage:
    from onemix_bot import OnemixBot

    bot = OnemixBot(token="YOUR_TOKEN", api_url="https://your-server.com")

    @bot.command("start")
    def on_start(msg):
        bot.reply(msg, "Hello!")

    bot.run()
"""

from .bot import OnemixBot

__version__ = "1.0.0"
__all__ = ["OnemixBot"]
