from setuptools import setup, find_packages

setup(
    name="onemix-bot",
    version="1.0.0",
    description="Python SDK for building bots on the ONEMIX messenger platform",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="ONEMIX Team",
    author_email="support@itpaxlive.ru",
    url="https://github.com/onemix/bot-sdk-python",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.25.0",
    ],
    extras_require={
        "webhook": ["flask>=2.0.0"],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Communications :: Chat",
    ],
    keywords="onemix bot messenger api sdk",
)
