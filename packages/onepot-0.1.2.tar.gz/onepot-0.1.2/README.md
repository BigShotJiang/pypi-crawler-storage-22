# onepot-python

Python client for the onepot API.

## Installation

```bash
uv add onepot
# or
pip install onepot
```

## Usage

```python
from onepot import Client

client = Client(api_key="your-api-key")

response = client.search(
    smiles_list=["Cc1c(C(=O)Nc2ccc(N3CC(C)OC(C)C3)nc2)cccc1-c1ccc(OC(F)(F)F)cc1", ...],
    max_results=10,
    include_chemistry_risk_score=True,
)
```

## Pricing

Credits are charged per SMILES in the query:

| Option | Credits per SMILES |
|--------|-------------------|
| Base search | 1 |
| `include_chemistry_risk=True` | 5 |
| `include_chemistry_risk_score=True` | 10 |

## Response Format

```python
{
    "queries": [
        {
            "query_smiles": "Cc1c(C(=O)Nc2ccc(N3CC(C)OC(C)C3)nc2)cccc1-c1ccc(OC(F)(F)F)cc1",
            "query_inchikey": "VZZJRYRQSPEMTK-CALCHBBNSA-N",
            "results": [
                {
                    "chemistry_risk": "medium",     # if include_chemistry_risk=True
                    "chemistry_risk_score": 0.5,    # if include_chemistry_risk_score=True
                    "inchikey": "VZZJRYRQSPEMTK-UHFFFAOYSA-N",
                    "price_usd": 590,
                    "similarity": 1.0,
                    "smiles": "Cc1c(C(=O)Nc2ccc(N3CC(C)OC(C)C3)nc2)cccc1-c1ccc(OC(F)(F)F)cc1",
                    "supplier_risk": "high",
                },
                ...
            ]
        },
        ...
    ],
    "credits_used": 10,
    "credits_remaining": 990
}
```
