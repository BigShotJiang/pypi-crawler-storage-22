"""
Defines the event message objects propagated through the system.
"""

from .base import EventBase

__all__ = ["EventBase"]
