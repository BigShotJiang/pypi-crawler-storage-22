"""
Provides a library of common technical indicators and a base class for creating custom ones.
"""

from .base import IndicatorBase, discover_indicators, get_registered_indicators
from .averages import SimpleMovingAverage
from .market_fields import Open, High, Low, Close, Volume
from .bollinger import BollingerLower, BollingerUpper, BollingerBandwidth
from .wilders import RSI
from .oscillators import ROC, DetrendOscillator
from .period_extreme import PeriodExtreme

__all__ = [
    "IndicatorBase",
    "discover_indicators",
    "get_registered_indicators",
    "SimpleMovingAverage",
    "Open",
    "High",
    "Low",
    "Close",
    "Volume",
    "BollingerLower",
    "BollingerUpper",
    "BollingerBandwidth",
    "RSI",
    "ROC",
    "DetrendOscillator",
    "PeriodExtreme",
]
