"""
Provides a library of common technical indicators and a base class for creating custom ones.
"""

from .base import IndicatorBase
from .averages import SimpleMovingAverage
from .market_fields import Open, High, Low, Close, Volume
from .bollinger import BollingerLower, BollingerUpper, BollingerBandwidth
from .wilders import RSI, ADX, ATR, MinusDI, ParabolicSAR, PlusDI
from .oscillators import ROC, DetrendOscillator
from .misc import PeriodExtreme

__all__ = [
    "IndicatorBase",
    "SimpleMovingAverage",
    "Open",
    "High",
    "Low",
    "Close",
    "Volume",
    "BollingerLower",
    "BollingerUpper",
    "BollingerBandwidth",
    "RSI",
    "ADX",
    "ATR",
    "MinusDI",
    "ParabolicSAR",
    "PlusDI",
    "ROC",
    "DetrendOscillator",
    "PeriodExtreme",
]
