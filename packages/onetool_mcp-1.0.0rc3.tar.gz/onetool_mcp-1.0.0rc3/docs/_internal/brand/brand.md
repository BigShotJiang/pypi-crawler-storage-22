# OneTool Brand

Brand assets, messaging, and reference materials for OneTool.

---

## Documents

| Document | Purpose |
|----------|---------|
| **This file** | Snippets, taglines, quick reference |
| [ref-terminology.md](ref-terminology.md) | Terminology style guide |
| [ref-claims.md](ref-claims.md) | Benchmark evidence for marketing claims |
| [ref-links.md](ref-links.md) | External references and resources |
| [ref-tool-packs.md](ref-tool-packs.md) | Tool pack descriptions |

**Documentation styling:** See [docs](../docs/index.md) for design system and best practices.

---

## Brand Identity

### Internal Brand

```text
One tool to rule them all
```

### External Pitch

```text
One MCP for developers - No tool tax, no context rot. 
100+ tools including Brave, Gemini, Context7, Version Checker, Excel, File Ops, Database, Chrome DevTools.
```

With emoji: `🧿 One MCP for developers - No tool tax, no context rot. 
100+ tools including Brave, Gemini, Context7, Version Checker, Excel, File Ops, Database, Chrome DevTools.`

---

## Taglines

### Short

```text
Don't enumerate tools. Execute code.
```

### Value Proposition

```text
96% fewer tokens. 24x lower cost.
```

See [ref-claims.md](ref-claims.md) for benchmark sources.

---

## Key Claims

| Claim | Summary |
|-------|---------|
| **96% token reduction** | 46K → 2K tokens (one-shot), gap widens with turns |
| **24x cost reduction** | 7.35¢ → 0.30¢ per 3-turn conversation |
| **$30/server/month** | Each MCP server wastes ~$30/month in tokens |

Details and methodology: [ref-claims.md](ref-claims.md)

---

## Short Descriptions

```text
🧿 One MCP for developers - No tool tax, no context rot. 100+ tools including Brave, Gemini, Context7, Version Checker, Excel, File Ops, Database, Chrome DevTools.
```

## GitHub Tags

```text
python, mcp, model-context-protocol, mcp-server, llm, code-execution, mcp-tools, agents, token-efficiency, fastmcp, context-rot
```

---

## Stats

```text
- 15 packs
- 100+ tools
- 2 CLIs (onetool, bench)
- 96% token reduction
- 24x cost reduction
```

---

## Terminology (Quick Reference)

Full guide: [ref-terminology.md](ref-terminology.md)

### Key Rules

| Rule | Example |
|------|---------|
| Use "agent" for tool behavior | "The agent generates code" |
| Use "LLM" for model characteristics | "LLM performance degrades" |
| Use "MCP server" not "MCP tool" | "Connect an MCP server" |
| Use "tool definitions" not "schemas" | "Tool definitions consume tokens" |

### OneTool Terms

| Term | Meaning |
|------|---------|
| **context rot** | Performance degradation from token bloat |
| **pack** | Collection of related tools |
| **explicit calls** | Direct tool invocation via code |
| **snippet** | Reusable code template |
