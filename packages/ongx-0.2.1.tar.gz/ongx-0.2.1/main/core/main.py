import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'

import pygame as pg
from pathlib import Path

# Пути к проекту и иконке
BASE = Path(__file__).resolve().parents[1]
ICON_FILE = BASE / "assets" / "icon.png"

if not ICON_FILE.exists():
    raise FileNotFoundError(f"Иконка не найдена: {ICON_FILE}")

# Инициализация Pygame
pg.init()
screen = pg.display.set_mode((800, 600))
pg.display.set_caption('ONGX')
icon = pg.image.load(ICON_FILE)
pg.display.set_icon(icon)
clock = pg.time.Clock()

# ASCII логотип
print("""
████████╗███╗   ██╗ ██████╗ ██╗   ██╗
██╔═══██║████╗  ██║██╔════╝ ╚██╗██╔╝
██║   ██║██╔██╗ ██║██║  ███╗ ╚███╔╝ 
██║   ██║██║╚██╗██║██║   ██║ ██╔██╗ 
╚██████╔╝██║ ╚████║╚██████╔╝██╔╝ ██╗
╚═════╝  ╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═╝

We appreciate you using our engine.
""")

class APP:
    def __init__(self, platform="pc"):
        self.running = True
        self.start_ticks = pg.time.get_ticks()  # старт таймера

        # Проверка платформы
        if platform in ["pc", "phone"]:
            print(f"-----------start-----------\nrunning engine as {platform}")
        elif platform == "":
            raise RuntimeError("platform is empty")
        else:
            raise RuntimeError(f"Did you mean 'phone' or 'pc'?")

    def run(self):
        while self.running:
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    self.running = False
                    # Считаем прошедшее время
                    elapsed_ms = pg.time.get_ticks() - self.start_ticks
                    minutes = elapsed_ms // 60000
                    seconds = (elapsed_ms % 60000) // 1000
                    milliseconds = elapsed_ms % 1000
                    print(f"""
run time: {int(minutes):02}:{int(seconds):02}:{int(milliseconds):03}
-----------end-----------""")

            clock.tick(60)