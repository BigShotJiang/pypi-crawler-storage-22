"""Core HDF5 Thing subclasses
Generated from HDF5 ontology
"""

from typing import Optional, List, Any
from pydantic import Field, field_validator
from ontolutils import Thing, namespaces, urirefs
from ontolutils.typing import AnyIriOf

# Custom HDF5 path validator
from typing_extensions import Annotated

def _validate_hdf5_path(path: str, handler):
    if isinstance(path, str) and not path.startswith("/"):
        raise ValueError("HDF5 path must start with /")
    return path

HDF5Path = Annotated[str, _validate_hdf5_path]

HDF5_NS = "http://purl.allotrope.org/ontologies/hdf5/1.8#"

@namespaces(hdf5=HDF5_NS)
@urirefs(
    NamedObject="hdf5:NamedObject",
)
class NamedObject(Thing):
    """Base class for named HDF5 objects"""
    pass


@namespaces(hdf5=HDF5_NS)
@urirefs(
    Dataspace="hdf5:Dataspace",
)
class Dataspace(Thing):
    """A dataset dataspace describes the dimensionality of dataset"""
    pass


@namespaces(hdf5=HDF5_NS)
@urirefs(
    StorageLayout="hdf5:StorageLayout",
)
class StorageLayout(Thing):
    """StorageLayout"""
    pass


@namespaces(hdf5=HDF5_NS)
@urirefs(
    Datatype="hdf5:Datatype",
)
class Datatype(Thing):
    """An object that describes the storage format of individual data points in a data set"""
    pass


@namespaces(hdf5=HDF5_NS)
@urirefs(
    Group="hdf5:Group",
    name="hdf5:name",
    member="hdf5:member",
)
class Group(NamedObject):
    """A grouping structure containing instances of zero or more groups or datasets, together with supporting metadata"""
    name: HDF5Path = Field(default=None)
    member: Optional[Any] = Field(default=None)

    @field_validator("name", mode="before")
    @classmethod
    def _validate_name(cls, name):
        if isinstance(name, str) and not name.startswith("/"):
            raise ValueError("HDF5 path must start with /")
        return name


@namespaces(hdf5=HDF5_NS)
@urirefs(
    Dataset="hdf5:Dataset",
    name="hdf5:name",
    dataspace="hdf5:dataspace",
    layout="hdf5:layout",
    rank="hdf5:rank",
)
class Dataset(NamedObject):
    """A multi-dimensional array of data elements, together with supporting metadata"""
    name: HDF5Path = Field(default=None)
    dataspace: Optional[AnyIriOf[Dataspace]] = Field(default=None)
    layout: Optional[AnyIriOf[StorageLayout]] = Field(default=None)
    rank: Optional[int] = Field(default=None)

    @field_validator("name", mode="before")
    @classmethod
    def _validate_name(cls, name):
        if isinstance(name, str) and not name.startswith("/"):
            raise ValueError("HDF5 path must start with /")
        return name


@namespaces(hdf5=HDF5_NS)
@urirefs(
    File="hdf5:File",
    rootGroup="hdf5:rootGroup",
)
class File(Thing):
    """A container for storing grouped collections of multi-dimensional arrays containing scientific data following HDF 5 specification"""
    rootGroup: Optional[AnyIriOf[Group]] = Field(default=None)




# Rebuild models for forward references
NamedObject.model_rebuild()
Dataspace.model_rebuild()
StorageLayout.model_rebuild()
Datatype.model_rebuild()
Group.model_rebuild()
Dataset.model_rebuild()
File.model_rebuild()
