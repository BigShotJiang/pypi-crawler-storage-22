"""Generated Thing subclasses from hdf.ttl

This file was automatically generated
"""

from typing import Optional, List, Any
from pydantic import Field, field_validator
from ontolutils import Thing, namespaces, urirefs
from ontolutils.typing import AnyIriOf

# Custom HDF5 path validator
from typing_extensions import Annotated

def _validate_hdf5_path(path: str, handler):
    if isinstance(path, str) and not path.startswith("/"):
        raise ValueError("HDF5 path must start with /")
    return path

HDF5Path = Annotated[str, _validate_hdf5_path]

@namespaces(hdf5="http://purl.allotrope.org/ontologies/hdf5/1.8#")
@urirefs(
    File="hdf5:File",
    rootGroup="hdf5:rootGroup",
    btreeIStoreSize="hdf5:btreeIStoreSize",
    btreeLeaf="hdf5:btreeLeaf",
    btreeRank="hdf5:btreeRank",
    btreeRatioLeft="hdf5:btreeRatioLeft",
    btreeRatioMiddle="hdf5:btreeRatioMiddle",
    btreeRatioRight="hdf5:btreeRatioRight",
    globalFreelistVersion="hdf5:globalFreelistVersion",
    metaBlockSize="hdf5:metaBlockSize",
    sharedObjectHeaderVersion="hdf5:sharedObjectHeaderVersion",
    sizeOfAddress="hdf5:sizeOfAddress",
    sizeOfSize="hdf5:sizeOfSize",
    smallDataBlockSize="hdf5:smallDataBlockSize",
    symbolTableNodeSize="hdf5:symbolTableNodeSize",
    symbolTableTreeRank="hdf5:symbolTableTreeRank",
    symbolTableVersion="hdf5:symbolTableVersion",
    userBlockSize="hdf5:userBlockSize",
)
class File(ne02f8cd240164f0aac368e74c3fe4748b147):
    """A container for storing grouped collections of multi-dimensional arrays containing scientific data following the HDF 5 specification. [Allotrope]"""
    rootGroup: Optional[AnyIriOf[Group]] = Field(default=None)
    btreeIStoreSize: Optional[str] = Field(default=None)
    btreeLeaf: Optional[str] = Field(default=None)
    btreeRank: Optional[str] = Field(default=None)
    btreeRatioLeft: Optional[float] = Field(default=None)
    btreeRatioMiddle: Optional[float] = Field(default=None)
    btreeRatioRight: Optional[float] = Field(default=None)
    globalFreelistVersion: Optional[int] = Field(default=None)
    metaBlockSize: Optional[int] = Field(default=None)
    sharedObjectHeaderVersion: Optional[int] = Field(default=None)
    sizeOfAddress: Optional[str] = Field(default=None)
    sizeOfSize: Optional[str] = Field(default=None)
    smallDataBlockSize: Optional[int] = Field(default=None)
    symbolTableNodeSize: Optional[str] = Field(default=None)
    symbolTableTreeRank: Optional[str] = Field(default=None)
    symbolTableVersion: Optional[int] = Field(default=None)
    userBlockSize: Optional[int] = Field(default=None)



@namespaces(hdf5="http://purl.allotrope.org/ontologies/hdf5/1.8#")
@urirefs(
    Group="hdf5:Group",
    link="hdf5:link",
)
class Group(NamedObject):
    """A grouping structure containing instances of zero or more groups or datasets, together with supporting metadata. [Allotrope]"""
    link: Optional[AnyIriOf[Link]] = Field(default=None)

    @field_validator("name", mode="before")
    @classmethod
    def _validate_name(cls, name):
        if isinstance(name, str) and not name.startswith("/"):
            raise ValueError("HDF5 path must start with /")
        return name


@namespaces(hdf5="http://purl.allotrope.org/ontologies/hdf5/1.8#")
@urirefs(
    Dataset="hdf5:Dataset",
    allocationTime="hdf5:allocationTime",
    chunk="hdf5:chunk",
    chunkMode="hdf5:chunkMode",
    compositeFillValue="hdf5:compositeFillValue",
    errorDetectionCheck="hdf5:errorDetectionCheck",
    fillTime="hdf5:fillTime",
    fillValueStatus="hdf5:fillValueStatus",
    filter="hdf5:filter",
    layout="hdf5:layout",
    scaleType="hdf5:scaleType",
    transferMode="hdf5:transferMode",
    atomicFillValue="hdf5:atomicFillValue",
    bufferSize="hdf5:bufferSize",
    chunkCachePreemptionPolicy="hdf5:chunkCachePreemptionPolicy",
    chunkCacheSize="hdf5:chunkCacheSize",
    chunkCacheSlots="hdf5:chunkCacheSlots",
    deflateLevel="hdf5:deflateLevel",
    hyperVectorSize="hdf5:hyperVectorSize",
    iStoreK="hdf5:iStoreK",
)
class Dataset(NamedObject):
    """A multi-dimensional array of data elements, together with supporting metadata. [Allotrope]"""
    allocationTime: Optional[AnyIriOf[StorageAllocation]] = Field(default=None)
    chunk: Optional[AnyIriOf[Chunk]] = Field(default=None)
    chunkMode: Optional[AnyIriOf[ChunkMode]] = Field(default=None)
    compositeFillValue: str = Field(default=None)
    errorDetectionCheck: Optional[AnyIriOf[ErrorDetectionCheck]] = Field(default=None)
    fillTime: Optional[AnyIriOf[FillTime]] = Field(default=None)
    fillValueStatus: Optional[AnyIriOf[FillValueStatus]] = Field(default=None)
    filter: Optional[AnyIriOf[Filter]] = Field(default=None)
    layout: Optional[AnyIriOf[StorageLayout]] = Field(default=None)
    scaleType: Optional[AnyIriOf[ScaleType]] = Field(default=None)
    transferMode: Optional[AnyIriOf[TransferMode]] = Field(default=None)
    atomicFillValue: str = Field(default=None)
    bufferSize: Optional[int] = Field(default=None)
    chunkCachePreemptionPolicy: Optional[str] = Field(default=None)
    chunkCacheSize: Optional[int] = Field(default=None)
    chunkCacheSlots: Optional[int] = Field(default=None)
    deflateLevel: Optional[str] = Field(default=None)
    hyperVectorSize: Optional[str] = Field(default=None)
    iStoreK: Optional[str] = Field(default=None)

    @field_validator("name", mode="before")
    @classmethod
    def _validate_name(cls, name):
        if isinstance(name, str) and not name.startswith("/"):
            raise ValueError("HDF5 path must start with /")
        return name


@namespaces(hdf5="http://purl.allotrope.org/ontologies/hdf5/1.8#")
@urirefs(
    NamedObject="hdf5:NamedObject",
    attribute="hdf5:attribute",
)
class NamedObject(ne02f8cd240164f0aac368e74c3fe4748b165):
    """HDF5 NamedObject"""
    attribute: Optional[AnyIriOf[Attribute]] = Field(default=None)



@namespaces(hdf5="http://purl.allotrope.org/ontologies/hdf5/1.8#")
@urirefs(
    Datatype="hdf5:Datatype",
    order="hdf5:order",
)
class Datatype(ne02f8cd240164f0aac368e74c3fe4748b133):
    """An object that describes the storage format of the individual data points in a data set. There are two categories of datatypes: atomic and compound..."""
    order: Optional[AnyIriOf[Order]] = Field(default=None)




# Rebuild all models to resolve forward references
File.model_rebuild()
Group.model_rebuild()
Dataset.model_rebuild()
NamedObject.model_rebuild()
Datatype.model_rebuild()
