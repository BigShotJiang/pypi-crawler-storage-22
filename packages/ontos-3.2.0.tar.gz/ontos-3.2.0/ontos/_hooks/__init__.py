"""Bundled hooks for ontos init."""
