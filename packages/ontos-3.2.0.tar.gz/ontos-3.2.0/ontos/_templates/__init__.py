"""Bundled templates for ontos init."""
