"""OntoSight server routes."""
