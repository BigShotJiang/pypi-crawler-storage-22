#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 15 15:07:41 2024

@author: ollywhaites
"""
from sys import path
path.append('/Users/ollywhaites/Documents/Documents/PhD/Python/Libraries/')

import numpy as np
import NV_Library as nv
import qutip

import matplotlib.pyplot as plt



options = qutip.solver.Options()
options.store_states = True 

"""

"""



class nv_bubble:
    
    
    
    def __init__(self,seed,d = 7e-9,rho = 670,b = 7.7e-9,species = 'H',params = nv.params(),alpha = np.radians(45)):   
        
        np.random.seed(seed)
        
        N = int(4*rho*(b*1e9)**3)
        #N = 1
        
        X = b*(-1 + 2*np.random.random(N))
        Y = b*(-1 + 2*np.random.random(N))
        Z = d + b*np.random.random(N)

     
        A = [nv.hyperfine(nv.y_rotation(np.array([x,y,z]),alpha),params = params,species = species) for x,y,z in zip(X,Y,Z)]
        
        phi = 2*np.pi*np.random.random(N)
        theta = np.arccos(2*np.random.random(N) - 1)
        #theta = 2*np.random.random(N)
        
        self.positions = np.array([Z,Y,Z]).T
        self.coupings = A
        self.states = np.array([theta,phi]).T
        self.spins = N
        
        self.depth = d
        self.ppm = rho
        self.species = species
        self.bubble_radius = b
        self.params = params
        self.nv_angle = alpha
    
        np.random.seed(None)
        
    def find_classical(self):
        
        params = self.params
        species = self.species
        
        x = self.positions.T[0]
        y = self.positions.T[1]
        z = self.positions.T[2]
        
        theta = self.states.T[0]
        
        r = np.sqrt(x**2 + y**2 + z**2)
        
        a0 = 3*params['mu_red']*params['gamma_%s'%species]*params['h']*np.cos(theta)*(3*z*z - r**2)/(4*np.pi*r**5)
        a = abs(3*params['mu_red']*params['gamma_%s'%species]*params['h']*np.sin(theta)*np.sqrt((z*x)**2 + (z*y)**2)/(4*np.pi*r**5))
        phi1 = np.arctan2(y,x)
        
        self.class_field = np.array([a0,a,phi1]).T
        self.find_mag()
        
        
    def find_mag(self):
        
        class_field = self.class_field
        a0 = class_field.T[0]
        a = class_field.T[1]
        phi = class_field.T[2]
        
        mag_theta = np.arctan(a.sum()/a0.sum())
        B = np.sqrt(a.sum()**2 + a0.sum()**2)
        
        self.mag_theta = mag_theta
        self.B = B
        self.mag_phi = phi.sum()
        
        
        
    def plot_xy(self,b,d,params,species,fig,ax):
        
        
        X = np.linspace(-b,b,100)
        Y = np.linspace(-b,b,100)
        Z = d
        
        x,y = np.meshgrid(X,Y)
        AXY = []
        for x1,y1 in zip(x,y):
            AXYtemp = []
            for x2,y2 in zip(x1,y1):
        
                xn,yn,zn = nv.y_rotation(np.array([x2,y2,Z]), self.nv_angle,passive = True)
        
            #xn,yn,zn = np.meshgrid(Xn,Yn,Zn)
                r = np.sqrt(xn**2 + yn**2 + zn**2)
        
        
                aXY =  abs(3*params['mu_red']*params['gamma_%s'%species]*params['h']/(4*np.pi*r**5)*np.sqrt((zn*xn)**2 + (zn*yn)**2))
                AXYtemp.append(aXY)
                
            AXY.append(AXYtemp)
        
        ax.contourf(x*1e9,y*1e9,np.array(AXY))
        
        ax.set_ylabel('y (nm)',fontsize = 12)
        ax.set_xlabel('x (nm)',fontsize = 12)
        
    def plot_xz(self,b,d,params,species,fig,ax):
        
        X = np.linspace(-b,b,100)
        Y = 0
        Z = np.linspace(d,d + b,100)
        
        x,z = np.meshgrid(X,Z)
        AXZ = []
        for x1,z1 in zip(x,z):
            AXZtemp = []
            for x2,z2 in zip(x1,z1):
        
                xn,yn,zn = nv.y_rotation(np.array([x2,Y,z2]), self.nv_angle,passive = True)
        
            #xn,yn,zn = np.meshgrid(Xn,Yn,Zn)
                r = np.sqrt(xn**2 + yn**2 + zn**2)
        
        
                aXZ =  abs(3*params['mu_red']*params['gamma_%s'%species]*params['h']/(4*np.pi*r**5)*np.sqrt((zn*xn)**2 + (zn*yn)**2))
                AXZtemp.append(aXZ)
                
            AXZ.append(AXZtemp)
        
        ax.contourf(x*1e9,z*1e9,np.array(AXZ))
        
        B = self.B
        theta  = self.mag_theta
        
        vec = [np.sin(theta),0,np.cos(theta)]
        vecNew = nv.y_rotation(np.array(vec), -self.nv_angle,passive = True)
        
        #ax.plot([b/2,b*vecNew[0]/4],[d + b/2,d + b/2 +  b*vecNew[2]/4],color = 'k')
        ax.arrow(0, d*1e9 + b*1e9/2, vecNew[0]*(B/(self.spins*1e-10))*(b*1e9/4),vecNew[2]*(B/(self.spins*1e-10))*(b*1e9/4),
                  head_width=b*1e9/70,
                  length_includes_head=True,
                  head_length=b*1e9/70,
                  color = 'w',
                  lw = 3)
        
        ax.text(0, d*1e9 + b*1e9/2,r'$\mathbf{M}$',fontsize = 12,color = 'w',va = 'top')
        
        ax.set_ylabel('z (nm)',fontsize = 12)
        ax.set_xlabel('x (nm)',fontsize = 12)
        
    def plot_bubble(self):
        
        b = self.bubble_radius
        d = self.depth
        
        params = self.params
        species = self.species
        
        fig,axes = plt.subplots(1,2,figsize = [9,4],dpi = 200)
        
        self.plot_xy(b,d,params,species,fig,axes[0])
        self.plot_xz(b,d,params,species,fig,axes[1])
        
        
        
        

def generate_bubble(d = 7e-9,rho = 670,b = 7.7e-9,species = 'H',params = nv.params(),ts = np.linspace(0,5e-6,100)):
    
    
    
    N = 4*rho*(b*1e9)**3
    
    x = -b + 2*b*np.random.random(int(N))
    y = -b + 2*b*np.random.random(int(N))
    z = d + b*np.random.random(int(N))
    

    r = np.sqrt(x**2 + y**2 + z**2)
    
    a = abs(3*params['mu_red']*params['gamma_%s'%species]*params['h']/(4*np.pi*r**5)*np.sqrt((z*x)**2 + (z*y)**2))
    phi1 = np.arctan2(y,x)
    
    phi = 2*np.pi*np.random.random(int(N))
    theta = np.arccos(2*np.random.random(int(N)) - 1)
    
    omegaL = 2*np.pi*params['B0']*params['gamma_%s'%species]
    
    B = 0
    B2 = 0
    for ai,t,p,p1 in zip(a,theta,phi,phi1):
        B += ai*np.sin(t)*np.cos(omegaL*ts + (p - p1))
        B2 += ai*np.sin(t)*np.cos(omegaL*ts - (p + p1))

    return B, B2



def generate_mag_bubble(b_rms = 4e-9,species = 'H',params = nv.params(),seed_b = None,seed_theta = None,seed_phi = None):
    
    np.random.seed(seed_phi)
    phi = 2*np.pi*np.random.random()
    
    np.random.seed(seed_theta)
    theta = np.arccos(2*np.random.random() - 1)
    
    np.random.seed(seed_b)
    #b = np.random.normal(0,b_rms)
    b = 500e-9
    

    return b,theta,phi


def hahn(operators,args,H,t_lim = [0,2e-6],s = 200):
    
    
    t0 = t_lim[0]
    tf = t_lim[1]
    
    UY = (-1j*np.pi*operators['Sy']/2).expm()
    UX = (-1j*np.pi*operators['Sx']/2).expm()
    
    rho = UY*operators['rho']*UY.dag()
    
    
    output = qutip.mesolve(H,rho,np.linspace(t0,(t0 + tf)/2,s),e_ops = [operators['Sx']],args = args,options = options)
    rho = output.states[-1]
    
    rho = (UY*UY)*rho*(UY*UY).dag()
    
    #args['phi'] = phi0 + args['nu']
    output = qutip.mesolve(H,rho,np.linspace((t0 + tf)/2,tf,s),e_ops = [operators['Sx']],args = args,options = options)
    rho = output.states[-1]
    
    #args['phi'] = phi0 + 2*args['nu']*tau

    rho = UX*rho*UX.dag()
    
    coh = (rho*operators['Sz']).tr()
    
    return coh, rho

def hahn_test(operators,args,H0,M,tau,s = 100):
    
    
    dt = tau/s
    
    UY = (-1j*np.pi*operators['Sy']/2).expm()
    UX = (-1j*np.pi*operators['Sx']/2).expm()
    
    rho = UY*operators['rho']*UY.dag()
    
    rho,M = evolve(H0,M,rho,dt,s, args)
    
    rho = (UY*UY)*rho*(UY*UY).dag()
    
    #args['phi'] = phi0 + args['nu']
    rho,M = evolve(H0,M,rho,dt,s, args)
    
    #args['phi'] = phi0 + 2*args['nu']*tau

    rho = UX*rho*UX.dag()
    
    
    return rho, M


def class_field(M,args):

    return M[0]
    
    

def evolve(H0,M,rho,dt,N, args):
    
    #evolve state
    for n in range(N):
        
        U0 = (-1j*class_field(M,args)*H0*dt).expm()
        
        rho = U0*rho*U0.dag()
        
        M = nv.xy_rotation(M,args['Omega']*dt,args['phase'])
        M = nv.z_rotation(M,args['nu']*dt)
        
        
    return rho, M





        
    
    
    