"""OnyxKraken Blender Toolkit — high-level bpy primitives and AI-driven asset pipeline.

Top-level package for ``onyxkraken-blender``.

When running inside Blender's Python, you can import primitives directly::

    from onyx_blender.onyx_bpy import clear_scene, setup_scene, create_wall

For the Smart Asset Creator pipeline::

    from sac.creator import SmartAssetCreator
    from sac.quality import QualityChecker

When used from outside Blender (e.g. OnyxKraken orchestrator), only
non-bpy utilities (texture catalog, SAC memory) are importable.
"""

__version__ = "0.1.0"
