"""
OnyxKraken Blender Toolkit — high-level bpy primitives for architectural modeling.

Usage in blender_python scripts:
    from onyx_bpy import *

    clear_scene()
    setup_scene()
    w1 = create_wall("FrontWall", (0,0), (6,0))
    cut_window(w1, center_x=3, sill_height=0.9)
    mat = make_material("Brick", (0.45, 0.22, 0.1))
    apply_material(w1, mat)
    add_sun()
    add_camera(location=(10, -10, 8), target=(3, 3, 1.5))
    render_preview()
"""

import bpy
import bmesh
import math
import os
import json
from mathutils import Vector, Matrix, Euler

# ---------------------------------------------------------------------------
# Architectural constants
# ---------------------------------------------------------------------------
WALL_HEIGHT = 2.7           # meters (residential)
WALL_HEIGHT_COMMERCIAL = 3.0
WALL_THICKNESS_INT = 0.15   # interior wall
WALL_THICKNESS_EXT = 0.25   # exterior wall
DOOR_WIDTH = 0.9
DOOR_WIDTH_DOUBLE = 1.5
DOOR_HEIGHT = 2.1
WINDOW_WIDTH = 1.2
WINDOW_HEIGHT = 1.2
WINDOW_SILL = 0.9           # sill height from floor
STAIR_RISE = 0.18
STAIR_RUN = 0.28
FLOOR_THICKNESS = 0.15
ROOF_OVERHANG = 0.3

# Default project directory
PROJECT_DIR = os.path.join(os.path.expanduser("~"), "OnyxProjects")
os.makedirs(PROJECT_DIR, exist_ok=True)


# ---------------------------------------------------------------------------
# Scene management
# ---------------------------------------------------------------------------

def clear_scene():
    """Delete every object in the scene."""
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    # Purge orphan data
    for block in bpy.data.meshes:
        if block.users == 0:
            bpy.data.meshes.remove(block)
    for block in bpy.data.materials:
        if block.users == 0:
            bpy.data.materials.remove(block)


def setup_scene(units='METRIC'):
    """Configure scene units and basic settings."""
    scene = bpy.context.scene
    scene.unit_settings.system = units
    scene.unit_settings.length_unit = 'METERS'
    scene.unit_settings.scale_length = 1.0
    # Enable ambient occlusion for better visual quality
    scene.world = bpy.data.worlds.get('World') or bpy.data.worlds.new('World')
    scene.world.use_nodes = True
    bg = scene.world.node_tree.nodes.get('Background')
    if bg:
        bg.inputs['Color'].default_value = (0.8, 0.85, 0.95, 1.0)  # light sky
        bg.inputs['Strength'].default_value = 0.5


def get_object(name):
    """Get an object by name. Returns None if not found."""
    return bpy.data.objects.get(name)


def list_objects():
    """Print all objects in the scene with type, location, and dimensions."""
    for obj in bpy.data.objects:
        loc = tuple(round(v, 3) for v in obj.location)
        dim = tuple(round(v, 3) for v in obj.dimensions)
        print(f"{obj.name}: type={obj.type}, loc={loc}, dim={dim}")


def select_object(obj):
    """Select an object and make it active."""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj


# ---------------------------------------------------------------------------
# Geometry creation — General-purpose primitives
# ---------------------------------------------------------------------------

def create_cube(size=1.0, location=(0, 0, 0), name="Cube", material=None):
    """Create a cube (uniform size or per-axis tuple).

    Args:
        size: Uniform scale float, or (x, y, z) dimensions tuple.
        location: World position.
        name: Object name.
        material: Optional material to apply.

    Returns:
        The cube Blender object.
    """
    if isinstance(size, (list, tuple)):
        bpy.ops.mesh.primitive_cube_add(size=1, location=location)
        obj = bpy.context.active_object
        obj.scale = (size[0] / 2, size[1] / 2, size[2] / 2) if len(size) == 3 else (size[0], size[0], size[0])
        bpy.ops.object.transform_apply(scale=True)
    else:
        bpy.ops.mesh.primitive_cube_add(size=size, location=location)
        obj = bpy.context.active_object
    obj.name = name
    if material:
        apply_material(obj, material)
    return obj


def create_box(name="Box", width=1, depth=1, height=1, location=(0, 0, 0), material=None):
    """Create a box with explicit width/depth/height dimensions.

    Args:
        name: Object name.
        width: X dimension.
        depth: Y dimension.
        height: Z dimension.
        location: World position.
        material: Optional material.

    Returns:
        The box Blender object.
    """
    bpy.ops.mesh.primitive_cube_add(size=1, location=location)
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = (width, depth, height)
    bpy.ops.object.transform_apply(scale=True)
    if material:
        apply_material(obj, material)
    return obj


def create_sphere(radius=1.0, segments=32, rings=16, location=(0, 0, 0),
                  name="Sphere", material=None):
    """Create a UV sphere.

    Args:
        radius: Sphere radius.
        segments: Longitude segments.
        rings: Latitude rings.
        location: World position.
        name: Object name.
        material: Optional material.

    Returns:
        The sphere Blender object.
    """
    bpy.ops.mesh.primitive_uv_sphere_add(
        radius=radius, segments=segments, ring_count=rings, location=location)
    obj = bpy.context.active_object
    obj.name = name
    if material:
        apply_material(obj, material)
    return obj


def create_cylinder(radius=1.0, depth=2.0, vertices=32, location=(0, 0, 0),
                    name="Cylinder", material=None, height=None,
                    smooth=False):
    """Create a cylinder.

    Supports two calling conventions:
      - New: create_cylinder(radius=0.5, height=2, name="Cyl")
      - Legacy: create_cylinder("Cyl", 0.5, 2, location=...)

    Args:
        radius: Cylinder radius (or name string for legacy calls).
        depth: Cylinder height (also accepts 'height' kwarg).
        vertices: Number of side vertices.
        location: World position.
        name: Object name.
        material: Optional material.
        height: Alias for depth.
        smooth: Apply smooth shading.

    Returns:
        The cylinder Blender object.
    """
    # Backwards compat: old code calls create_cylinder("name", radius, height, location=...)
    if isinstance(radius, str):
        _name, _radius, _height = radius, depth, vertices
        name = _name
        radius = _radius
        depth = _height if isinstance(_height, (int, float)) else 2.0
        vertices = 32
    if height is not None:
        depth = height
    bpy.ops.mesh.primitive_cylinder_add(
        radius=radius, depth=depth, vertices=int(vertices), location=location)
    obj = bpy.context.active_object
    obj.name = name
    if material:
        apply_material(obj, material)
    return obj


def create_cone(radius1=1.0, radius2=0.0, depth=2.0, vertices=32,
                location=(0, 0, 0), name="Cone", material=None, height=None):
    """Create a cone.

    Args:
        radius1: Bottom radius.
        radius2: Top radius (0 for a point).
        depth: Cone height (also accepts 'height' kwarg).
        vertices: Number of side vertices.
        location: World position.
        name: Object name.
        material: Optional material.
        height: Alias for depth.

    Returns:
        The cone Blender object.
    """
    if height is not None:
        depth = height
    bpy.ops.mesh.primitive_cone_add(
        radius1=radius1, radius2=radius2, depth=depth,
        vertices=vertices, location=location)
    obj = bpy.context.active_object
    obj.name = name
    if material:
        apply_material(obj, material)
    return obj


def create_plane(size=2.0, location=(0, 0, 0), name="Plane", material=None):
    """Create a plane (flat quad).

    Args:
        size: Plane size.
        location: World position.
        name: Object name.
        material: Optional material.

    Returns:
        The plane Blender object.
    """
    bpy.ops.mesh.primitive_plane_add(size=size, location=location)
    obj = bpy.context.active_object
    obj.name = name
    if material:
        apply_material(obj, material)
    return obj


def create_torus(major_radius=1.0, minor_radius=0.25, major_segments=48,
                 minor_segments=12, location=(0, 0, 0), name="Torus",
                 material=None):
    """Create a torus.

    Args:
        major_radius: Distance from torus center to tube center.
        minor_radius: Tube radius.
        major_segments: Segments around the ring.
        minor_segments: Segments around the tube.
        location: World position.
        name: Object name.
        material: Optional material.

    Returns:
        The torus Blender object.
    """
    bpy.ops.mesh.primitive_torus_add(
        major_radius=major_radius, minor_radius=minor_radius,
        major_segments=major_segments, minor_segments=minor_segments,
        location=location)
    obj = bpy.context.active_object
    obj.name = name
    if material:
        apply_material(obj, material)
    return obj


def create_icosphere(radius=1.0, subdivisions=2, location=(0, 0, 0),
                     name="Icosphere", material=None):
    """Create an icosphere.

    Args:
        radius: Sphere radius.
        subdivisions: Subdivision level (1-6).
        location: World position.
        name: Object name.
        material: Optional material.

    Returns:
        The icosphere Blender object.
    """
    bpy.ops.mesh.primitive_ico_sphere_add(
        radius=radius, subdivisions=subdivisions, location=location)
    obj = bpy.context.active_object
    obj.name = name
    if material:
        apply_material(obj, material)
    return obj


def create_ground_plane(size=10, location=(0, 0, 0), name="Ground", material=None):
    """Create a large ground plane (convenience wrapper).

    Args:
        size: Plane size.
        location: World position.
        name: Object name.
        material: Optional material.

    Returns:
        The ground plane Blender object.
    """
    return create_plane(size=size, location=location, name=name, material=material)


# Aliases that LLMs commonly try
scene_clear = clear_scene


# ---------------------------------------------------------------------------
# Physics helpers
# ---------------------------------------------------------------------------

def add_collision(obj):
    """Add a Collision physics modifier to an object.

    Args:
        obj: The Blender object (or name string).

    Returns:
        The collision modifier.
    """
    if isinstance(obj, str):
        obj = bpy.data.objects[obj]
    select_object(obj)
    bpy.ops.object.modifier_add(type='COLLISION')
    return obj.modifiers.get('Collision')


def add_cloth(obj, quality=5, mass=0.3, stiffness=15.0, damping=5.0):
    """Add a Cloth physics modifier to an object.

    Args:
        obj: The Blender object (or name string).
        quality: Simulation quality steps.
        mass: Cloth mass (kg).
        stiffness: Structural stiffness.
        damping: Damping factor.

    Returns:
        The cloth modifier.
    """
    if isinstance(obj, str):
        obj = bpy.data.objects[obj]
    select_object(obj)
    bpy.ops.object.modifier_add(type='CLOTH')
    cloth_mod = obj.modifiers.get('Cloth')
    if cloth_mod:
        cloth_mod.settings.quality = quality
        cloth_mod.settings.mass = mass
        cloth_mod.settings.tension_stiffness = stiffness
        cloth_mod.settings.tension_damping = damping
    return cloth_mod


def add_rigid_body(obj, body_type='ACTIVE', mass=1.0, friction=0.5,
                   bounciness=0.5):
    """Add a Rigid Body physics to an object.

    Args:
        obj: The Blender object (or name string).
        body_type: 'ACTIVE' or 'PASSIVE'.
        mass: Object mass.
        friction: Surface friction.
        bounciness: Bounce factor.

    Returns:
        The rigid body settings.
    """
    if isinstance(obj, str):
        obj = bpy.data.objects[obj]
    select_object(obj)
    bpy.ops.rigidbody.object_add(type=body_type)
    rb = obj.rigid_body
    if rb:
        rb.mass = mass
        rb.friction = friction
        rb.restitution = bounciness
    return rb


def add_particle_system(obj, count=1000, lifetime=50, emit_from='FACE',
                        particle_type='EMITTER', hair_length=0.1,
                        name="ParticleSystem"):
    """Add a particle system to an object.

    Args:
        obj: The Blender object (or name string).
        count: Number of particles.
        lifetime: Particle lifetime in frames.
        emit_from: Emission source ('FACE', 'VOLUME', 'VERT').
        particle_type: 'EMITTER' or 'HAIR'.
        hair_length: Hair length (for HAIR type).
        name: Particle system name.

    Returns:
        The particle system modifier.
    """
    if isinstance(obj, str):
        obj = bpy.data.objects[obj]
    select_object(obj)
    bpy.ops.object.particle_system_add()
    ps = obj.particle_systems[-1]
    ps.name = name
    settings = ps.settings
    settings.count = count
    settings.frame_end = lifetime
    settings.emit_from = emit_from
    settings.type = particle_type
    if particle_type == 'HAIR':
        settings.hair_length = hair_length
    return ps


def bake_physics(frame_start=1, frame_end=60):
    """Bake all physics simulations in the scene.

    Args:
        frame_start: Start frame.
        frame_end: End frame.
    """
    scene = bpy.context.scene
    scene.frame_start = frame_start
    scene.frame_end = frame_end
    # Set current frame to start
    scene.frame_set(frame_start)
    # Bake all point caches
    for obj in bpy.data.objects:
        for mod in obj.modifiers:
            if hasattr(mod, 'point_cache'):
                mod.point_cache.frame_start = frame_start
                mod.point_cache.frame_end = frame_end
                select_object(obj)
                try:
                    override = bpy.context.copy()
                    override['point_cache'] = mod.point_cache
                    bpy.ops.ptcache.bake(override, bake=True)
                except Exception:
                    # Fallback: step through frames to simulate
                    pass
    # Step through all frames to ensure simulation is computed
    for f in range(frame_start, frame_end + 1):
        scene.frame_set(f)
    scene.frame_set(frame_end)
    print(f"Physics baked: frames {frame_start}-{frame_end}")


# Convenience aliases
set_collision = add_collision
set_collision_object = add_collision


# ---------------------------------------------------------------------------
# Geometry creation — Walls
# ---------------------------------------------------------------------------

def create_wall(name, start, end, height=None, thickness=None, exterior=False):
    """
    Create a wall between two (x, y) points.

    Args:
        name: Object name.
        start: (x, y) start point.
        end: (x, y) end point.
        height: Wall height in meters (default: WALL_HEIGHT).
        thickness: Wall thickness (default: based on exterior flag).
        exterior: If True, uses exterior wall thickness.

    Returns:
        The wall Blender object.
    """
    if height is None:
        height = WALL_HEIGHT
    if thickness is None:
        thickness = WALL_THICKNESS_EXT if exterior else WALL_THICKNESS_INT

    dx = end[0] - start[0]
    dy = end[1] - start[1]
    length = math.sqrt(dx * dx + dy * dy)
    angle = math.atan2(dy, dx)
    cx = (start[0] + end[0]) / 2
    cy = (start[1] + end[1]) / 2

    bpy.ops.mesh.primitive_cube_add(size=1, location=(cx, cy, height / 2))
    wall = bpy.context.active_object
    wall.name = name
    wall.scale = (length, thickness, height)
    wall.rotation_euler.z = angle
    bpy.ops.object.transform_apply(scale=True, rotation=True)
    return wall


def create_wall_loop(name_prefix, points, height=None, thickness=None,
                     exterior=True, close=True):
    """
    Create a series of connected walls from a list of (x, y) points.

    Args:
        name_prefix: Base name (walls will be named prefix_0, prefix_1, ...).
        points: List of (x, y) corner points.
        height: Wall height.
        thickness: Wall thickness.
        exterior: If True, uses exterior thickness.
        close: If True, connect last point back to first.

    Returns:
        List of wall objects.
    """
    walls = []
    n = len(points)
    segments = n if close else n - 1
    for i in range(segments):
        start = points[i]
        end = points[(i + 1) % n]
        wall = create_wall(
            f"{name_prefix}_{i}", start, end,
            height=height, thickness=thickness, exterior=exterior,
        )
        walls.append(wall)
    return walls


# ---------------------------------------------------------------------------
# Boolean operations — Openings
# ---------------------------------------------------------------------------

def _boolean_cut(target_obj, cutter_obj, cleanup=True):
    """Apply a boolean DIFFERENCE and optionally remove the cutter."""
    select_object(target_obj)
    mod = target_obj.modifiers.new(name='Bool_Cut', type='BOOLEAN')
    mod.operation = 'DIFFERENCE'
    mod.object = cutter_obj
    bpy.ops.object.modifier_apply(modifier=mod.name)
    if cleanup:
        bpy.data.objects.remove(cutter_obj, do_unlink=True)


def cut_window(wall_obj, center_x=None, center_y=None,
               sill_height=None, width=None, height=None,
               name=None):
    """
    Cut a window opening in a wall.

    The cutter is positioned in the wall's local space. center_x/center_y
    refer to the WORLD coordinates of the opening center along the wall's
    length axis. For simple axis-aligned walls, just specify center_x or
    center_y (whichever runs along the wall).

    Args:
        wall_obj: The wall to cut.
        center_x: X world coordinate of window center (for X-aligned walls).
        center_y: Y world coordinate of window center (for Y-aligned walls).
        sill_height: Distance from floor to bottom of window.
        width: Window width.
        height: Window height.
        name: Optional name for the opening.

    Returns:
        The modified wall object.
    """
    if sill_height is None:
        sill_height = WINDOW_SILL
    if width is None:
        width = WINDOW_WIDTH
    if height is None:
        height = WINDOW_HEIGHT
    if name is None:
        name = f"{wall_obj.name}_Window"

    # Determine wall orientation and center
    wall_loc = wall_obj.location
    wall_dim = wall_obj.dimensions

    # Calculate cutter position
    cx = center_x if center_x is not None else wall_loc.x
    cy = center_y if center_y is not None else wall_loc.y
    cz = sill_height + height / 2

    # Cutter needs to be thick enough to go through the wall
    cutter_depth = max(wall_dim.x, wall_dim.y, 0.5) + 0.1

    bpy.ops.mesh.primitive_cube_add(size=1, location=(cx, cy, cz))
    cutter = bpy.context.active_object
    cutter.name = name + '_cutter'

    # Determine which axis is the wall's thin dimension
    if wall_dim.x < wall_dim.y:
        # Wall runs along Y, thin on X
        cutter.scale = (cutter_depth, width, height)
    else:
        # Wall runs along X, thin on Y
        cutter.scale = (width, cutter_depth, height)

    bpy.ops.object.transform_apply(scale=True)
    _boolean_cut(wall_obj, cutter, cleanup=True)
    return wall_obj


def cut_door(wall_obj, center_x=None, center_y=None,
             width=None, height=None, name=None):
    """
    Cut a door opening in a wall (from floor level).

    Args:
        wall_obj: The wall to cut.
        center_x: X world coordinate of door center (for X-aligned walls).
        center_y: Y world coordinate of door center (for Y-aligned walls).
        width: Door width.
        height: Door height.
        name: Optional name.

    Returns:
        The modified wall object.
    """
    if width is None:
        width = DOOR_WIDTH
    if height is None:
        height = DOOR_HEIGHT
    if name is None:
        name = f"{wall_obj.name}_Door"

    # Door starts from floor (sill_height = 0)
    return cut_window(
        wall_obj, center_x=center_x, center_y=center_y,
        sill_height=0, width=width, height=height, name=name,
    )


# ---------------------------------------------------------------------------
# Floor
# ---------------------------------------------------------------------------

def create_floor(name="Floor", width=None, depth=None,
                 vertices=None, location=(0, 0, 0), thickness=None,
                 material=None):
    """
    Create a floor slab.

    Either specify width+depth for rectangular, or vertices for arbitrary polygon.

    Args:
        name: Object name.
        width: X dimension (for rectangular floor).
        depth: Y dimension (for rectangular floor).
        vertices: List of (x, y) points for arbitrary polygon floor.
        location: (x, y, z) position.
        thickness: Floor thickness (default: FLOOR_THICKNESS).
        material: Material to apply (optional).

    Returns:
        The floor object.
    """
    if thickness is None:
        thickness = FLOOR_THICKNESS

    if vertices is not None:
        # Arbitrary polygon floor using bmesh
        mesh = bpy.data.meshes.new(name)
        obj = bpy.data.objects.new(name, mesh)
        bpy.context.collection.objects.link(obj)
        bm = bmesh.new()
        bm_verts = [bm.verts.new((v[0], v[1], 0)) for v in vertices]
        bm.faces.new(bm_verts)
        bm.to_mesh(mesh)
        bm.free()
        obj.location = location
        # Add thickness via solidify
        mod = obj.modifiers.new('Solidify', 'SOLIDIFY')
        mod.thickness = thickness
        mod.offset = -1  # extend downward
        select_object(obj)
        bpy.ops.object.modifier_apply(modifier=mod.name)
    else:
        # Simple rectangular floor
        w = width or 10
        d = depth or 10
        bpy.ops.mesh.primitive_cube_add(
            size=1,
            location=(location[0], location[1], location[2] - thickness / 2),
        )
        obj = bpy.context.active_object
        obj.name = name
        obj.scale = (w, d, thickness)
        bpy.ops.object.transform_apply(scale=True)

    if material:
        apply_material(obj, material)
    return obj


# ---------------------------------------------------------------------------
# Roof
# ---------------------------------------------------------------------------

def create_roof_gable(name="Roof", width=10, depth=10,
                      wall_height=None, peak_height=2.0,
                      overhang=None, thickness=0.08,
                      location=(0, 0, 0), material=None):
    """
    Create a gable roof using bmesh (ridge runs along Y axis).

    Args:
        name: Object name.
        width: Roof width (X dimension, including overhang).
        depth: Roof depth (Y dimension, including overhang).
        wall_height: Height of the wall tops (z level of eaves).
        peak_height: Height of peak above wall_height.
        overhang: Eave overhang distance.
        thickness: Roof panel thickness.
        location: Base offset.
        material: Optional material.

    Returns:
        The roof object.
    """
    if wall_height is None:
        wall_height = WALL_HEIGHT
    if overhang is None:
        overhang = ROOF_OVERHANG

    hw = width / 2 + overhang
    hd = depth / 2 + overhang
    base_z = wall_height
    peak_z = wall_height + peak_height

    mesh = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)

    bm = bmesh.new()
    # Eave vertices
    v0 = bm.verts.new((-hw, -hd, base_z))  # front-left
    v1 = bm.verts.new((hw, -hd, base_z))   # front-right
    v2 = bm.verts.new((hw, hd, base_z))    # back-right
    v3 = bm.verts.new((-hw, hd, base_z))   # back-left
    # Ridge vertices
    v4 = bm.verts.new((0, -hd, peak_z))    # front peak
    v5 = bm.verts.new((0, hd, peak_z))     # back peak

    # Faces
    bm.faces.new([v0, v4, v5, v3])          # left slope
    bm.faces.new([v4, v1, v2, v5])          # right slope
    bm.faces.new([v0, v1, v4])              # front gable triangle
    bm.faces.new([v3, v5, v2])              # back gable triangle

    bm.to_mesh(mesh)
    bm.free()

    obj.location = location

    # Add thickness via solidify
    if thickness > 0:
        mod = obj.modifiers.new('Solidify', 'SOLIDIFY')
        mod.thickness = thickness
        mod.offset = -1  # thickness goes inward/downward
        select_object(obj)
        bpy.ops.object.modifier_apply(modifier=mod.name)

    if material:
        apply_material(obj, material)
    return obj


def create_roof_hip(name="HipRoof", width=10, depth=10,
                    wall_height=None, peak_height=2.0,
                    overhang=None, thickness=0.08,
                    location=(0, 0, 0), material=None):
    """
    Create a hip roof (all four sides slope inward).

    Args:
        name: Object name.
        width: Building width (X).
        depth: Building depth (Y).
        wall_height: Eave height.
        peak_height: Ridge height above eaves.
        overhang: Eave overhang.
        thickness: Panel thickness.
        location: Base offset.
        material: Optional material.

    Returns:
        The roof object.
    """
    if wall_height is None:
        wall_height = WALL_HEIGHT
    if overhang is None:
        overhang = ROOF_OVERHANG

    hw = width / 2 + overhang
    hd = depth / 2 + overhang
    base_z = wall_height
    peak_z = wall_height + peak_height

    # Ridge runs along the longer axis
    if depth >= width:
        ridge_half = (depth - width) / 2
        ridge_pts = [(0, -ridge_half, peak_z), (0, ridge_half, peak_z)]
    else:
        ridge_half = (width - depth) / 2
        ridge_pts = [(-ridge_half, 0, peak_z), (ridge_half, 0, peak_z)]

    mesh = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)

    bm = bmesh.new()
    # Eave corners
    v0 = bm.verts.new((-hw, -hd, base_z))
    v1 = bm.verts.new((hw, -hd, base_z))
    v2 = bm.verts.new((hw, hd, base_z))
    v3 = bm.verts.new((-hw, hd, base_z))

    if depth >= width:
        # Ridge along Y
        vr0 = bm.verts.new(ridge_pts[0])
        vr1 = bm.verts.new(ridge_pts[1])
        bm.faces.new([v0, v1, vr0])          # front hip
        bm.faces.new([v2, v3, vr1])          # back hip
        bm.faces.new([v0, vr0, vr1, v3])     # left slope
        bm.faces.new([v1, v2, vr1, vr0])     # right slope
    else:
        # Ridge along X
        vr0 = bm.verts.new(ridge_pts[0])
        vr1 = bm.verts.new(ridge_pts[1])
        bm.faces.new([v3, v0, vr0])          # left hip
        bm.faces.new([v1, v2, vr1])          # right hip
        bm.faces.new([v0, v1, vr1, vr0])     # front slope
        bm.faces.new([v3, vr0, vr1, v2])     # back slope

    bm.to_mesh(mesh)
    bm.free()

    obj.location = location

    if thickness > 0:
        mod = obj.modifiers.new('Solidify', 'SOLIDIFY')
        mod.thickness = thickness
        mod.offset = -1
        select_object(obj)
        bpy.ops.object.modifier_apply(modifier=mod.name)

    if material:
        apply_material(obj, material)
    return obj


# ---------------------------------------------------------------------------
# Materials
# ---------------------------------------------------------------------------

# Pre-defined architectural colors (RGBA, 0-1)
COLORS = {
    'white':        (1.0, 1.0, 1.0, 1.0),
    'off_white':    (0.95, 0.93, 0.88, 1.0),
    'cream':        (0.96, 0.94, 0.82, 1.0),
    'light_gray':   (0.75, 0.75, 0.75, 1.0),
    'concrete':     (0.65, 0.65, 0.65, 1.0),
    'dark_gray':    (0.3, 0.3, 0.3, 1.0),
    'brick_red':    (0.45, 0.22, 0.1, 1.0),
    'brick_brown':  (0.4, 0.25, 0.15, 1.0),
    'terracotta':   (0.72, 0.35, 0.18, 1.0),
    'wood_light':   (0.65, 0.45, 0.25, 1.0),
    'wood_medium':  (0.45, 0.28, 0.14, 1.0),
    'wood_dark':    (0.25, 0.15, 0.08, 1.0),
    'wood_walnut':  (0.3, 0.18, 0.1, 1.0),
    'glass_blue':   (0.6, 0.75, 0.85, 0.3),
    'glass_clear':  (0.9, 0.95, 0.95, 0.15),
    'metal_steel':  (0.7, 0.7, 0.72, 1.0),
    'metal_copper': (0.72, 0.45, 0.2, 1.0),
    'grass_green':  (0.2, 0.5, 0.1, 1.0),
    'roof_tile':    (0.5, 0.2, 0.12, 1.0),
    'roof_slate':   (0.25, 0.25, 0.28, 1.0),
    'asphalt':      (0.15, 0.15, 0.15, 1.0),
    'sand':         (0.82, 0.73, 0.55, 1.0),
    'sky_blue':     (0.53, 0.81, 0.98, 1.0),
}


def make_material(name, color, roughness=0.5, metallic=0.0, alpha=None):
    """
    Create a Principled BSDF material.

    Args:
        name: Material name.
        color: (R, G, B) or (R, G, B, A) tuple (0-1), or a key from COLORS dict.
        roughness: Surface roughness (0=mirror, 1=matte).
        metallic: Metallic factor (0=dielectric, 1=metal).
        alpha: Override alpha/transparency (0=transparent, 1=opaque).

    Returns:
        The Blender material.
    """
    if isinstance(color, str):
        color = COLORS.get(color, COLORS['white'])
    if len(color) == 3:
        color = (*color, 1.0)

    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get('Principled BSDF')
    bsdf.inputs['Base Color'].default_value = color
    bsdf.inputs['Roughness'].default_value = roughness
    bsdf.inputs['Metallic'].default_value = metallic

    # Handle transparency
    a = alpha if alpha is not None else color[3]
    if a < 1.0:
        bsdf.inputs['Alpha'].default_value = a
        mat.blend_method = 'BLEND'  # EEVEE transparency
        mat.shadow_method = 'CLIP'

    return mat


def apply_material(obj, material):
    """Apply a material to an object (replaces first slot or appends)."""
    if isinstance(material, str):
        material = bpy.data.materials.get(material)
        if material is None:
            raise ValueError(f"Material '{material}' not found")
    if obj.data.materials:
        obj.data.materials[0] = material
    else:
        obj.data.materials.append(material)


# Convenience: pre-built material presets
def mat_wall_exterior(name="ExtWall"):
    """Exterior wall with procedural stucco texture — subtle roughness variation."""
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    bsdf = nodes.get('Principled BSDF')
    bsdf.inputs['Base Color'].default_value = (0.92, 0.90, 0.85, 1.0)
    bsdf.inputs['Metallic'].default_value = 0.0

    # Noise texture for stucco bump and roughness variation
    tex_coord = nodes.new('ShaderNodeTexCoord')
    tex_coord.location = (-800, 0)
    mapping = nodes.new('ShaderNodeMapping')
    mapping.location = (-600, 0)
    mapping.inputs['Scale'].default_value = (8.0, 8.0, 8.0)
    links.new(tex_coord.outputs['Object'], mapping.inputs['Vector'])

    noise = nodes.new('ShaderNodeTexNoise')
    noise.location = (-400, 0)
    noise.inputs['Scale'].default_value = 40.0
    noise.inputs['Detail'].default_value = 8.0
    noise.inputs['Roughness'].default_value = 0.7
    links.new(mapping.outputs['Vector'], noise.inputs['Vector'])

    # Map noise to roughness range 0.65-0.95
    map_range = nodes.new('ShaderNodeMapRange')
    map_range.location = (-200, -100)
    map_range.inputs['From Min'].default_value = 0.0
    map_range.inputs['From Max'].default_value = 1.0
    map_range.inputs['To Min'].default_value = 0.65
    map_range.inputs['To Max'].default_value = 0.95
    links.new(noise.outputs['Fac'], map_range.inputs['Value'])
    links.new(map_range.outputs['Result'], bsdf.inputs['Roughness'])

    # Bump map from noise
    bump = nodes.new('ShaderNodeBump')
    bump.location = (-200, -300)
    bump.inputs['Strength'].default_value = 0.15
    links.new(noise.outputs['Fac'], bump.inputs['Height'])
    links.new(bump.outputs['Normal'], bsdf.inputs['Normal'])

    return mat

def mat_wall_interior(name="IntWall"):
    return make_material(name, 'cream', roughness=0.9)

def mat_floor_wood(name="WoodFloor"):
    """Wood floor using PBR texture from catalog if available."""
    try:
        return make_pbr_material(name, texture_id='wood_mosaic_reclaimed_dark',
                                 roughness=0.55, uv_scale=3.0)
    except Exception:
        return make_material(name, 'wood_medium', roughness=0.6)

def mat_floor_tile(name="TileFloor"):
    """Tile floor using PBR texture from catalog if available."""
    try:
        return make_pbr_material(name, texture_id='tile_mosaic_grey_white',
                                 roughness=0.25, uv_scale=4.0)
    except Exception:
        return make_material(name, 'light_gray', roughness=0.3)

def mat_roof_tile(name="RoofTile"):
    """Roof tile using PBR texture from catalog if available."""
    try:
        return make_pbr_material(name, texture_id='tile_hexagon_terracotta',
                                 roughness=0.75, uv_scale=2.0)
    except Exception:
        return make_material(name, 'roof_tile', roughness=0.8)

def mat_roof_slate(name="RoofSlate"):
    return make_material(name, 'roof_slate', roughness=0.7)

def mat_glass(name="Glass"):
    """Create a realistic glass material with Glass BSDF + transparency."""
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    mat.blend_method = 'BLEND'
    mat.shadow_method = 'HASHED'
    mat.use_backface_culling = False

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out = nodes.new('ShaderNodeOutputMaterial')
    out.location = (500, 0)

    # Glass BSDF for reflections and refraction
    glass = nodes.new('ShaderNodeBsdfGlass')
    glass.location = (100, 100)
    glass.inputs['Color'].default_value = (0.85, 0.92, 0.98, 1.0)
    glass.inputs['Roughness'].default_value = 0.02
    glass.inputs['IOR'].default_value = 1.45

    # Transparent BSDF for see-through
    trans = nodes.new('ShaderNodeBsdfTransparent')
    trans.location = (100, -100)
    trans.inputs['Color'].default_value = (0.95, 0.97, 1.0, 1.0)

    # Mix: mostly transparent with some glass reflection
    mix = nodes.new('ShaderNodeMixShader')
    mix.location = (300, 0)
    mix.inputs['Fac'].default_value = 0.15  # 15% glass, 85% transparent

    links.new(trans.outputs['BSDF'], mix.inputs[1])
    links.new(glass.outputs['BSDF'], mix.inputs[2])
    links.new(mix.outputs['Shader'], out.inputs['Surface'])

    return mat

def mat_concrete(name="Concrete"):
    return make_material(name, 'concrete', roughness=0.9)

def mat_wood_trim(name="WoodTrim"):
    return make_material(name, 'wood_light', roughness=0.5)

def mat_metal(name="Metal"):
    return make_material(name, 'metal_steel', roughness=0.3, metallic=0.9)

def mat_grass(name="Grass"):
    return make_material(name, 'grass_green', roughness=0.95)


# ---------------------------------------------------------------------------
# Window/Door frames (visual detail)
# ---------------------------------------------------------------------------

def add_window_frame(location, width=None, height=None,
                     frame_depth=0.06, frame_thickness=0.04,
                     name="WindowFrame", material=None):
    """
    Add a simple window frame (rectangular frame + glass pane).

    Args:
        location: (x, y, z) center of the window opening.
        width: Frame width.
        height: Frame height.
        frame_depth: How far the frame protrudes.
        frame_thickness: Thickness of frame members.
        name: Object name.
        material: Frame material (default: wood_trim).

    Returns:
        Tuple of (frame_obj, glass_obj).
    """
    if width is None:
        width = WINDOW_WIDTH
    if height is None:
        height = WINDOW_HEIGHT
    if material is None:
        material = mat_wood_trim(f"{name}_mat")

    x, y, z = location
    frame_parts = []

    # Four frame members (top, bottom, left, right)
    positions = [
        (x, y, z + height / 2 - frame_thickness / 2),  # top
        (x, y, z - height / 2 + frame_thickness / 2),  # bottom
        (x, y - width / 2 + frame_thickness / 2, z) if False else None,  # placeholder
        (x, y + width / 2 - frame_thickness / 2, z) if False else None,  # placeholder
    ]

    # Simpler approach: create a single box frame using bmesh
    mesh = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)

    bm = bmesh.new()
    hw, hh = width / 2, height / 2
    ft = frame_thickness

    # Outer rectangle vertices (front face)
    outer = [(-hw, 0, -hh), (hw, 0, -hh), (hw, 0, hh), (-hw, 0, hh)]
    # Inner rectangle vertices
    inner = [(-hw + ft, 0, -hh + ft), (hw - ft, 0, -hh + ft),
             (hw - ft, 0, hh - ft), (-hw + ft, 0, hh - ft)]

    # Create front face verts
    ov = [bm.verts.new(v) for v in outer]
    iv = [bm.verts.new(v) for v in inner]

    # Frame faces (4 strips between outer and inner rect)
    bm.faces.new([ov[0], ov[1], iv[1], iv[0]])  # bottom
    bm.faces.new([ov[1], ov[2], iv[2], iv[1]])  # right
    bm.faces.new([ov[2], ov[3], iv[3], iv[2]])  # top
    bm.faces.new([ov[3], ov[0], iv[0], iv[3]])  # left

    bm.to_mesh(mesh)
    bm.free()

    obj.location = (x, y, z)

    # Add depth via solidify
    mod = obj.modifiers.new('Solidify', 'SOLIDIFY')
    mod.thickness = frame_depth
    select_object(obj)
    bpy.ops.object.modifier_apply(modifier=mod.name)

    apply_material(obj, material)

    # Glass pane
    glass_mat = mat_glass(f"{name}_glass")
    bpy.ops.mesh.primitive_plane_add(size=1, location=(x, y, z))
    glass = bpy.context.active_object
    glass.name = f"{name}_Glass"
    glass.scale = (width - ft * 2, 1, height - ft * 2)
    glass.rotation_euler.x = math.radians(90)
    bpy.ops.object.transform_apply(scale=True, rotation=True)
    apply_material(glass, glass_mat)

    return obj, glass


def add_door_frame(location, width=None, height=None,
                   frame_depth=0.08, frame_thickness=0.05,
                   name="DoorFrame", material=None):
    """
    Add a door frame (U-shaped — no bottom member).

    Args:
        location: (x, y, z) center-bottom of the door opening.
        width: Frame width.
        height: Frame height.
        frame_depth: How far frame protrudes.
        frame_thickness: Frame member thickness.
        name: Object name.
        material: Frame material.

    Returns:
        The door frame object.
    """
    if width is None:
        width = DOOR_WIDTH
    if height is None:
        height = DOOR_HEIGHT
    if material is None:
        material = mat_wood_trim(f"{name}_mat")

    x, y, z = location

    mesh = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)

    bm = bmesh.new()
    hw = width / 2
    ft = frame_thickness

    # U-shaped frame (left, top, right — no bottom)
    # Outer: full rectangle
    # Inner: inset rectangle
    # Only create top + two sides

    # Left side
    v = [
        bm.verts.new((-hw, 0, 0)),
        bm.verts.new((-hw + ft, 0, 0)),
        bm.verts.new((-hw + ft, 0, height - ft)),
        bm.verts.new((-hw, 0, height)),
    ]
    bm.faces.new(v)

    # Right side
    v = [
        bm.verts.new((hw - ft, 0, 0)),
        bm.verts.new((hw, 0, 0)),
        bm.verts.new((hw, 0, height)),
        bm.verts.new((hw - ft, 0, height - ft)),
    ]
    bm.faces.new(v)

    # Top header
    v = [
        bm.verts.new((-hw, 0, height - ft)),
        bm.verts.new((hw, 0, height - ft)),
        bm.verts.new((hw, 0, height)),
        bm.verts.new((-hw, 0, height)),
    ]
    bm.faces.new(v)

    bm.to_mesh(mesh)
    bm.free()

    obj.location = (x, y, z)

    # Depth
    mod = obj.modifiers.new('Solidify', 'SOLIDIFY')
    mod.thickness = frame_depth
    select_object(obj)
    bpy.ops.object.modifier_apply(modifier=mod.name)

    apply_material(obj, material)
    return obj


# ---------------------------------------------------------------------------
# Lighting
# ---------------------------------------------------------------------------

def add_sun(energy=3.0, rotation=None, color=(1, 1, 1), name="Sun"):
    """
    Add a Sun light.

    Args:
        energy: Light energy/strength.
        rotation: (x, y, z) Euler rotation in radians. Default: 45° elevation, 45° azimuth.
        color: Light color (R, G, B).
        name: Light name.

    Returns:
        The sun light object.
    """
    if rotation is None:
        rotation = (math.radians(50), math.radians(10), math.radians(45))
    bpy.ops.object.light_add(type='SUN', location=(0, 0, 10))
    sun = bpy.context.active_object
    sun.name = name
    sun.data.energy = energy
    sun.data.color = color
    sun.rotation_euler = rotation
    return sun


def add_point_light(location, energy=200, color=(1, 0.95, 0.8),
                    radius=0.1, name="PointLight"):
    """Add a point light (good for interior lighting)."""
    bpy.ops.object.light_add(type='POINT', location=location)
    light = bpy.context.active_object
    light.name = name
    light.data.energy = energy
    light.data.color = color
    light.data.shadow_soft_size = radius
    return light


def add_area_light(location, energy=300, size=2.0,
                   rotation=(math.radians(90), 0, 0),
                   color=(1, 0.97, 0.9), name="AreaLight"):
    """Add an area light (soft shadows, good for interiors)."""
    bpy.ops.object.light_add(type='AREA', location=location)
    light = bpy.context.active_object
    light.name = name
    light.data.energy = energy
    light.data.size = size
    light.data.color = color
    light.rotation_euler = rotation
    return light


# ---------------------------------------------------------------------------
# Camera
# ---------------------------------------------------------------------------

def add_camera(location=(12, -12, 8), target=(0, 0, 1.5),
               focal_length=35, name="Camera"):
    """
    Add a camera aimed at a target point.

    Args:
        location: Camera position.
        target: Point the camera looks at.
        focal_length: Lens focal length in mm.
        name: Camera name.

    Returns:
        The camera object.
    """
    bpy.ops.object.camera_add(location=location)
    cam = bpy.context.active_object
    cam.name = name
    cam.data.lens = focal_length

    # Point camera at target
    direction = Vector(target) - Vector(location)
    rot_quat = direction.to_track_quat('-Z', 'Y')
    cam.rotation_euler = rot_quat.to_euler()

    bpy.context.scene.camera = cam
    return cam


def orbit_camera(target=(0, 0, 1.5), distance=15,
                 elevation=30, azimuth=45, focal_length=35,
                 name="Camera"):
    """
    Place camera in orbit around a target point (spherical coordinates).

    Args:
        target: Point to orbit around.
        distance: Distance from target.
        elevation: Angle above horizon in degrees.
        azimuth: Horizontal rotation angle in degrees.
        focal_length: Lens focal length.
        name: Camera name.

    Returns:
        The camera object.
    """
    elev_rad = math.radians(elevation)
    azim_rad = math.radians(azimuth)

    x = target[0] + distance * math.cos(elev_rad) * math.cos(azim_rad)
    y = target[1] + distance * math.cos(elev_rad) * math.sin(azim_rad)
    z = target[2] + distance * math.sin(elev_rad)

    return add_camera(
        location=(x, y, z), target=target,
        focal_length=focal_length, name=name,
    )


# ---------------------------------------------------------------------------
# Animation & Keyframes
# ---------------------------------------------------------------------------

def set_frame_range(start=1, end=120, fps=24):
    """Set the scene frame range and FPS.

    Args:
        start: First frame.
        end: Last frame.
        fps: Frames per second.
    """
    scene = bpy.context.scene
    scene.frame_start = start
    scene.frame_end = end
    scene.render.fps = fps
    scene.frame_set(start)
    print(f"Frame range: {start}-{end} @ {fps}fps")


def set_keyframe(obj, frame, data_path='location'):
    """Insert a keyframe on an object at the given frame.

    Args:
        obj: Blender object.
        frame: Frame number.
        data_path: Property to keyframe ('location', 'rotation_euler', 'scale').
    """
    obj.keyframe_insert(data_path=data_path, frame=frame)


def animate_transform(obj, keyframes):
    """Animate an object through a sequence of transforms.

    Args:
        obj: Blender object.
        keyframes: List of dicts, each with:
            - frame (int): Frame number
            - location (tuple, optional): (x, y, z)
            - rotation (tuple, optional): (rx, ry, rz) in degrees
            - scale (tuple, optional): (sx, sy, sz)

    Example:
        animate_transform(cube, [
            {"frame": 1, "location": (0,0,0), "rotation": (0,0,0)},
            {"frame": 60, "location": (5,0,0), "rotation": (0,0,90)},
            {"frame": 120, "location": (5,5,0), "rotation": (0,0,180)},
        ])
    """
    for kf in keyframes:
        frame = kf["frame"]
        if "location" in kf:
            obj.location = kf["location"]
            obj.keyframe_insert(data_path="location", frame=frame)
        if "rotation" in kf:
            rx, ry, rz = kf["rotation"]
            obj.rotation_euler = (
                math.radians(rx), math.radians(ry), math.radians(rz)
            )
            obj.keyframe_insert(data_path="rotation_euler", frame=frame)
        if "scale" in kf:
            obj.scale = kf["scale"]
            obj.keyframe_insert(data_path="scale", frame=frame)
    print(f"Animated '{obj.name}' with {len(keyframes)} keyframes")


def camera_orbit_animation(target=(0, 0, 1.5), radius=12, frames=120,
                           start_angle=0, elevation=30, fps=24,
                           focal_length=35, name="Camera"):
    """Create a camera that orbits smoothly around a target point.

    Args:
        target: Point to orbit around.
        radius: Distance from target.
        frames: Total number of frames for full orbit.
        start_angle: Starting azimuth in degrees.
        elevation: Angle above horizon in degrees.
        fps: Frames per second.
        focal_length: Lens focal length.
        name: Camera name.

    Returns:
        The camera object.
    """
    set_frame_range(1, frames, fps)
    elev_rad = math.radians(elevation)

    # Create camera at start position
    azim_rad = math.radians(start_angle)
    start_loc = (
        target[0] + radius * math.cos(elev_rad) * math.cos(azim_rad),
        target[1] + radius * math.cos(elev_rad) * math.sin(azim_rad),
        target[2] + radius * math.sin(elev_rad),
    )
    cam = add_camera(location=start_loc, target=target,
                     focal_length=focal_length, name=name)

    # Add Track To constraint so camera always looks at target
    empty = bpy.data.objects.new("CameraTarget", None)
    bpy.context.collection.objects.link(empty)
    empty.location = target
    constraint = cam.constraints.new(type='TRACK_TO')
    constraint.target = empty
    constraint.track_axis = 'TRACK_NEGATIVE_Z'
    constraint.up_axis = 'UP_Y'

    # Keyframe the orbit
    num_keyframes = min(frames, 36)  # one keyframe every ~10 degrees
    for i in range(num_keyframes + 1):
        frame = 1 + int(i * (frames - 1) / num_keyframes)
        angle = start_angle + (360 * i / num_keyframes)
        azim = math.radians(angle)
        cam.location = (
            target[0] + radius * math.cos(elev_rad) * math.cos(azim),
            target[1] + radius * math.cos(elev_rad) * math.sin(azim),
            target[2] + radius * math.sin(elev_rad),
        )
        cam.keyframe_insert(data_path="location", frame=frame)

    # Smooth interpolation
    if cam.animation_data and cam.animation_data.action:
        for fc in cam.animation_data.action.fcurves:
            for kp in fc.keyframe_points:
                kp.interpolation = 'BEZIER'

    print(f"Camera orbit: {frames} frames, radius={radius}, "
          f"elevation={elevation}°, target={target}")
    return cam


def camera_dolly(start, end, target, frames=120, fps=24,
                 focal_length=35, name="Camera"):
    """Create a camera dolly shot — straight-line move while looking at target.

    Args:
        start: Start position (x, y, z).
        end: End position (x, y, z).
        target: Point the camera looks at throughout.
        frames: Total frames.
        fps: Frames per second.
        focal_length: Lens focal length.
        name: Camera name.

    Returns:
        The camera object.
    """
    set_frame_range(1, frames, fps)
    cam = add_camera(location=start, target=target,
                     focal_length=focal_length, name=name)

    # Track To constraint
    empty = bpy.data.objects.new("DollyTarget", None)
    bpy.context.collection.objects.link(empty)
    empty.location = target
    constraint = cam.constraints.new(type='TRACK_TO')
    constraint.target = empty
    constraint.track_axis = 'TRACK_NEGATIVE_Z'
    constraint.up_axis = 'UP_Y'

    # Keyframe start and end
    cam.location = start
    cam.keyframe_insert(data_path="location", frame=1)
    cam.location = end
    cam.keyframe_insert(data_path="location", frame=frames)

    # Smooth interpolation
    if cam.animation_data and cam.animation_data.action:
        for fc in cam.animation_data.action.fcurves:
            for kp in fc.keyframe_points:
                kp.interpolation = 'BEZIER'

    print(f"Camera dolly: {start} → {end}, target={target}, {frames} frames")
    return cam


def camera_crane(base, height_start, height_end, target, frames=120,
                 fps=24, focal_length=35, name="Camera"):
    """Create a crane shot — camera moves vertically while looking at target.

    Args:
        base: Base position (x, y) — horizontal position stays fixed.
        height_start: Starting height (z).
        height_end: Ending height (z).
        target: Point the camera looks at throughout.
        frames: Total frames.
        fps: Frames per second.
        focal_length: Lens focal length.
        name: Camera name.

    Returns:
        The camera object.
    """
    start = (base[0], base[1], height_start)
    end = (base[0], base[1], height_end)
    return camera_dolly(start, end, target, frames, fps, focal_length, name)


def render_animation(output_dir=None, format='PNG', engine='BLENDER_EEVEE',
                     resolution=(1280, 720), samples=64):
    """Render the full animation frame range to image sequence.

    Args:
        output_dir: Directory for output frames (default: PROJECT_DIR/animation/).
        format: Image format ('PNG', 'JPEG', 'OPEN_EXR').
        engine: Render engine.
        resolution: (width, height).
        samples: Render samples.

    Returns:
        The output directory path.
    """
    if output_dir is None:
        output_dir = os.path.join(PROJECT_DIR, "animation")
    os.makedirs(output_dir, exist_ok=True)

    scene = bpy.context.scene
    scene.render.engine = engine
    scene.render.resolution_x = resolution[0]
    scene.render.resolution_y = resolution[1]
    scene.render.image_settings.file_format = format
    scene.render.filepath = os.path.join(output_dir, "frame_").replace("\\", "/")

    if engine == 'CYCLES':
        scene.cycles.samples = samples
        scene.cycles.use_denoising = True
    elif engine == 'BLENDER_EEVEE':
        scene.eevee.taa_render_samples = samples

    bpy.ops.render.render(animation=True)
    total = scene.frame_end - scene.frame_start + 1
    print(f"Rendered {total} frames to: {output_dir}")
    return output_dir


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------

def render_preview(filepath=None, engine='BLENDER_EEVEE',
                   resolution=(1280, 720), samples=64):
    """
    Render the current scene to an image file.

    Args:
        filepath: Output path (default: PROJECT_DIR/render_preview.png).
        engine: 'BLENDER_EEVEE' (fast) or 'CYCLES' (realistic).
        resolution: (width, height) in pixels.
        samples: Render samples (higher = better quality, slower).

    Returns:
        The output filepath.
    """
    if filepath is None:
        filepath = os.path.join(PROJECT_DIR, "render_preview.png")
    filepath = filepath.replace("\\", "/")

    scene = bpy.context.scene
    scene.render.engine = engine
    scene.render.resolution_x = resolution[0]
    scene.render.resolution_y = resolution[1]
    scene.render.filepath = filepath

    if engine == 'CYCLES':
        scene.cycles.samples = samples
        scene.cycles.use_denoising = True
    elif engine == 'BLENDER_EEVEE':
        scene.eevee.taa_render_samples = samples
        scene.eevee.use_gtao = True           # ambient occlusion
        scene.eevee.use_bloom = False
        scene.eevee.use_ssr = True             # screen space reflections

    bpy.ops.render.render(write_still=True)
    print(f"Rendered to: {filepath}")
    return filepath


def render_high_quality(filepath=None, resolution=(1920, 1080), samples=256):
    """Render with Cycles at high quality."""
    if filepath is None:
        filepath = os.path.join(PROJECT_DIR, "render_hq.png")
    return render_preview(
        filepath=filepath, engine='CYCLES',
        resolution=resolution, samples=samples,
    )


# ---------------------------------------------------------------------------
# Compound building helpers
# ---------------------------------------------------------------------------

def _add_baseboard(name, start, end, height=0.08, depth=0.015, material=None):
    """Add a baseboard strip along a wall segment at floor level."""
    dx = end[0] - start[0]
    dy = end[1] - start[1]
    length = math.sqrt(dx * dx + dy * dy)
    angle = math.atan2(dy, dx)
    cx = (start[0] + end[0]) / 2
    cy = (start[1] + end[1]) / 2

    bpy.ops.mesh.primitive_cube_add(size=1, location=(cx, cy, height / 2))
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = (length, depth, height)
    obj.rotation_euler.z = angle
    bpy.ops.object.transform_apply(scale=True, rotation=True)
    if material:
        apply_material(obj, material)
    return obj


def build_room(name, origin, width, depth, height=None, thickness=None,
               exterior=True, door_wall=None, door_pos=None,
               windows=None, floor_material=None, wall_material=None,
               add_detail=True, room_light=True):
    """
    Build a rectangular room with door, windows, frames, glass, baseboards, and light.

    Args:
        name: Room name prefix.
        origin: (x, y) bottom-left corner.
        width: Room width (X).
        depth: Room depth (Y).
        height: Wall height.
        thickness: Wall thickness.
        exterior: Exterior wall thickness flag.
        door_wall: Which wall gets a door: 'front', 'back', 'left', 'right'.
        door_pos: Position along door wall (0-1, default 0.5 = center).
        windows: Dict of wall_name -> list of positions (0-1 along wall).
        floor_material: Material for the floor.
        wall_material: Material for walls.
        add_detail: Add window frames, glass panes, door frames, and baseboards.
        room_light: Add a ceiling point light inside the room.

    Returns:
        Dict with keys: 'walls', 'floor', 'frames', 'baseboards', 'light'.
    """
    if height is None:
        height = WALL_HEIGHT
    if door_pos is None:
        door_pos = 0.5
    if windows is None:
        windows = {}

    ox, oy = origin
    # Corner points (CCW from origin)
    corners = [
        (ox, oy),
        (ox + width, oy),
        (ox + width, oy + depth),
        (ox, oy + depth),
    ]
    wall_names = ['front', 'right', 'back', 'left']

    walls = []
    frames = []
    baseboards = []
    trim_mat = mat_wood_trim(f"{name}_Trim") if add_detail else None

    for i, wn in enumerate(wall_names):
        start = corners[i]
        end = corners[(i + 1) % 4]
        wall = create_wall(
            f"{name}_{wn}", start, end,
            height=height, thickness=thickness, exterior=exterior,
        )

        # Cut door and add frame
        if door_wall == wn:
            mid_x = start[0] + (end[0] - start[0]) * door_pos
            mid_y = start[1] + (end[1] - start[1]) * door_pos
            cut_door(wall, center_x=mid_x, center_y=mid_y)
            if add_detail:
                df = add_door_frame(
                    location=(mid_x, mid_y, 0),
                    name=f"{name}_{wn}_DoorFrame", material=trim_mat,
                )
                frames.append(df)

        # Cut windows and add frames + glass
        if wn in windows:
            for wi, wpos in enumerate(windows[wn]):
                wx = start[0] + (end[0] - start[0]) * wpos
                wy = start[1] + (end[1] - start[1]) * wpos
                sill = WINDOW_SILL
                wh = WINDOW_HEIGHT
                cut_window(wall, center_x=wx, center_y=wy, sill_height=sill)
                if add_detail:
                    wf, wg = add_window_frame(
                        location=(wx, wy, sill + wh / 2),
                        name=f"{name}_{wn}_WinFrame{wi}", material=trim_mat,
                    )
                    frames.extend([wf, wg])

        if wall_material:
            apply_material(wall, wall_material)
        walls.append(wall)

        # Baseboards along each wall (interior side)
        if add_detail:
            bb = _add_baseboard(
                f"{name}_{wn}_Baseboard", start, end,
                material=trim_mat,
            )
            baseboards.append(bb)

    # Floor
    floor = create_floor(
        name=f"{name}_Floor",
        width=width, depth=depth,
        location=(ox + width / 2, oy + depth / 2, 0),
        material=floor_material,
    )

    # Ceiling
    ceil_mat = make_material(f"{name}_Ceiling", (0.97, 0.97, 0.97), roughness=0.95)
    ceiling = create_floor(
        name=f"{name}_Ceiling",
        width=width, depth=depth,
        location=(ox + width / 2, oy + depth / 2, height),
        thickness=0.05,
        material=ceil_mat,
    )

    # Room ceiling light
    light = None
    if room_light:
        light = add_point_light(
            name=f"{name}_CeilingLight",
            location=(ox + width / 2, oy + depth / 2, height - 0.15),
            energy=width * depth * 8,  # scale energy by room area
            color=(1.0, 0.95, 0.88),
        )

    return {
        'walls': walls,
        'floor': floor,
        'ceiling': ceiling,
        'frames': frames,
        'baseboards': baseboards,
        'light': light,
    }


def build_simple_house(width=8, depth=10, height=None,
                       roof_style='gable', roof_peak=2.0,
                       name="House"):
    """
    Build a complete simple house with walls, floor, roof, door, windows,
    materials, lighting, and camera.

    Args:
        width: House width (X).
        depth: House depth (Y).
        height: Wall height.
        roof_style: 'gable' or 'hip'.
        roof_peak: Roof peak height above walls.
        name: Base name for all objects.

    Returns:
        Dict with all created objects.
    """
    if height is None:
        height = WALL_HEIGHT

    clear_scene()
    setup_scene()

    # Materials
    ext_mat = mat_wall_exterior(f"{name}_ExtWall")
    floor_mat = mat_floor_wood(f"{name}_Floor")
    roof_mat = mat_roof_tile(f"{name}_Roof")

    # Build the room
    room = build_room(
        name=name,
        origin=(-width / 2, -depth / 2),
        width=width, depth=depth, height=height,
        exterior=True,
        door_wall='front', door_pos=0.5,
        windows={
            'front': [0.2, 0.8],
            'back': [0.3, 0.7],
            'left': [0.5],
            'right': [0.5],
        },
        floor_material=floor_mat,
        wall_material=ext_mat,
    )

    # Roof
    if roof_style == 'hip':
        roof = create_roof_hip(
            name=f"{name}_Roof", width=width, depth=depth,
            wall_height=height, peak_height=roof_peak,
            material=roof_mat,
        )
    else:
        roof = create_roof_gable(
            name=f"{name}_Roof", width=width, depth=depth,
            wall_height=height, peak_height=roof_peak,
            material=roof_mat,
        )

    # Ground plane
    ground = create_floor(
        name="Ground", width=30, depth=30,
        location=(0, 0, -0.01),
        material=mat_grass("GroundGrass"),
    )

    # Lighting
    sun = add_sun(energy=3.0)

    # Camera
    cam = orbit_camera(
        target=(0, 0, height / 2),
        distance=max(width, depth) * 1.8,
        elevation=25, azimuth=-35,
    )

    return {
        'room': room,
        'roof': roof,
        'ground': ground,
        'sun': sun,
        'camera': cam,
    }


# =========================================================================
# PHASE 3 — Texture System, Furniture, Floor Plans, Photorealism
# =========================================================================

# ---------------------------------------------------------------------------
# Texture catalog & PBR material system
# ---------------------------------------------------------------------------

_TOOLKIT_DIR = os.path.dirname(os.path.abspath(__file__))
_TEXTURE_DIR = os.path.join(_TOOLKIT_DIR, "- TEXTURE ASSETS")
_CATALOG_PATH = os.path.join(_TOOLKIT_DIR, "texture_catalog.json")
_TEXTURE_CATALOG = None


def _load_catalog():
    """Load the texture catalog JSON (cached)."""
    global _TEXTURE_CATALOG
    if _TEXTURE_CATALOG is None:
        if os.path.exists(_CATALOG_PATH):
            with open(_CATALOG_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            _TEXTURE_CATALOG = data.get("textures", {})
        else:
            _TEXTURE_CATALOG = {}
    return _TEXTURE_CATALOG


def list_textures(category=None):
    """List available texture IDs, optionally filtered by category.

    Args:
        category: Filter by category (e.g. 'nature', 'metal', 'wood', 'scifi', 'tile').

    Returns:
        List of texture ID strings.
    """
    cat = _load_catalog()
    if category:
        return [k for k, v in cat.items() if v.get("category") == category]
    return list(cat.keys())


def get_texture_info(texture_id):
    """Get full metadata for a texture by its ID.

    Returns:
        dict with file, category, description, use_for, roughness, etc.
    """
    return _load_catalog().get(texture_id, {})


def texture_path(texture_id):
    """Get the absolute file path for a texture by its catalog ID.

    Args:
        texture_id: Catalog ID (e.g. 'nature_grass_seamless').

    Returns:
        Absolute path string, or None if not found.
    """
    info = get_texture_info(texture_id)
    if not info:
        return None
    fpath = os.path.join(_TEXTURE_DIR, info["file"])
    return fpath if os.path.exists(fpath) else None


def load_texture(image_path, name=None):
    """Load an image into Blender's data as a texture.

    Args:
        image_path: Absolute path to the image file, or a texture catalog ID.
        name: Optional name for the image datablock.

    Returns:
        bpy.types.Image datablock.
    """
    # Check if it's a catalog ID first
    cat_path = texture_path(image_path)
    if cat_path:
        image_path = cat_path
        if name is None:
            name = image_path  # use catalog ID as name

    if name is None:
        name = os.path.splitext(os.path.basename(image_path))[0]

    # Reuse existing image if already loaded
    if name in bpy.data.images:
        return bpy.data.images[name]

    img = bpy.data.images.load(image_path)
    img.name = name
    return img


def make_pbr_material(name, base_color=None, texture_id=None,
                      roughness=0.5, metallic=0.0,
                      normal_map=None, emission_strength=0.0,
                      uv_scale=1.0):
    """Create a PBR (Principled BSDF) material with optional image texture.

    Args:
        name: Material name.
        base_color: (R, G, B, A) tuple if no texture. Ignored if texture_id set.
        texture_id: Catalog texture ID (e.g. 'nature_grass_seamless').
        roughness: Surface roughness 0-1.
        metallic: Metallic factor 0-1.
        normal_map: Path or catalog ID for normal map texture.
        emission_strength: Emission glow strength (0 = none).
        uv_scale: UV coordinate scale for tiling.

    Returns:
        bpy.types.Material.
    """
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    # Output
    out = nodes.new('ShaderNodeOutputMaterial')
    out.location = (600, 0)

    # Principled BSDF
    bsdf = nodes.new('ShaderNodeBsdfPrincipled')
    bsdf.location = (300, 0)
    links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])

    # Auto-load catalog metadata
    info = {}
    if texture_id:
        info = get_texture_info(texture_id)
        if roughness == 0.5 and 'roughness' in info:
            roughness = info['roughness']
        if metallic == 0.0 and 'metallic' in info:
            metallic = info['metallic']
        if emission_strength == 0.0 and 'emission_strength' in info:
            emission_strength = info['emission_strength']
        if uv_scale == 1.0 and 'scale' in info:
            uv_scale = info['scale']
        if normal_map is None and 'normal_map' in info:
            normal_map = os.path.join(_TEXTURE_DIR, info['normal_map'])

    bsdf.inputs['Roughness'].default_value = roughness
    bsdf.inputs['Metallic'].default_value = metallic

    # UV scaling node
    tex_coord = None
    mapping = None
    if texture_id or normal_map:
        tex_coord = nodes.new('ShaderNodeTexCoord')
        tex_coord.location = (-600, 0)
        mapping = nodes.new('ShaderNodeMapping')
        mapping.location = (-400, 0)
        mapping.inputs['Scale'].default_value = (uv_scale, uv_scale, uv_scale)
        links.new(tex_coord.outputs['Object'], mapping.inputs['Vector'])

    # Base color: texture or flat color
    if texture_id:
        tpath = texture_path(texture_id)
        if tpath:
            img = load_texture(tpath, texture_id)
            tex_node = nodes.new('ShaderNodeTexImage')
            tex_node.image = img
            tex_node.location = (-200, 100)
            if mapping:
                links.new(mapping.outputs['Vector'], tex_node.inputs['Vector'])
            links.new(tex_node.outputs['Color'], bsdf.inputs['Base Color'])

            # Use texture for emission too
            if emission_strength > 0:
                bsdf.inputs['Emission Strength'].default_value = emission_strength
                links.new(tex_node.outputs['Color'], bsdf.inputs['Emission Color'])
    elif base_color:
        if len(base_color) == 3:
            base_color = (*base_color, 1.0)
        bsdf.inputs['Base Color'].default_value = base_color

    # Normal map
    if normal_map:
        npath = normal_map
        cat_npath = texture_path(normal_map)
        if cat_npath:
            npath = cat_npath
        if os.path.exists(npath):
            nimg = load_texture(npath, os.path.basename(npath))
            nimg.colorspace_settings.name = 'Non-Color'
            ntex = nodes.new('ShaderNodeTexImage')
            ntex.image = nimg
            ntex.location = (-200, -200)
            if mapping:
                links.new(mapping.outputs['Vector'], ntex.inputs['Vector'])
            nmap = nodes.new('ShaderNodeNormalMap')
            nmap.location = (50, -200)
            links.new(ntex.outputs['Color'], nmap.inputs['Color'])
            links.new(nmap.outputs['Normal'], bsdf.inputs['Normal'])

    return mat


def apply_texture(obj, texture_id, uv_scale=None, name=None):
    """Quick helper: create a PBR material from a catalog texture and apply it.

    Args:
        obj: Blender object.
        texture_id: Catalog texture ID.
        uv_scale: UV tiling scale (auto from catalog if None).
        name: Material name (auto-generated if None).

    Returns:
        The created material.
    """
    if name is None:
        name = f"Mat_{texture_id}"
    kwargs = {"name": name, "texture_id": texture_id}
    if uv_scale is not None:
        kwargs["uv_scale"] = uv_scale
    mat = make_pbr_material(**kwargs)
    apply_material(obj, mat)
    return mat


# ---------------------------------------------------------------------------
# Furniture primitives
# ---------------------------------------------------------------------------

def add_table(name="Table", location=(0, 0, 0),
              width=1.2, depth=0.7, height=0.75,
              top_thickness=0.04, leg_radius=0.03,
              top_material=None, leg_material=None):
    """Create a simple 4-legged table.

    Args:
        name: Object name prefix.
        location: (x, y, z) bottom-center position.
        width: Table top X dimension.
        depth: Table top Y dimension.
        height: Total height including top.
        top_thickness: Thickness of tabletop.
        leg_radius: Radius of each leg.
        top_material: Material for tabletop.
        leg_material: Material for legs.

    Returns:
        dict with 'top' and 'legs' objects.
    """
    x, y, z = location
    if top_material is None:
        top_material = make_material(f"{name}_Top", (0.35, 0.22, 0.12))
    if leg_material is None:
        leg_material = make_material(f"{name}_Leg", (0.25, 0.15, 0.08))

    # Tabletop
    top = create_box(f"{name}_Top", width, depth, top_thickness,
                     location=(x, y, z + height - top_thickness), material=top_material)

    # Legs
    leg_h = height - top_thickness
    inset_x = width / 2 - 0.06
    inset_y = depth / 2 - 0.06
    legs = []
    for i, (lx, ly) in enumerate([(-inset_x, -inset_y), (inset_x, -inset_y),
                                   (-inset_x, inset_y), (inset_x, inset_y)]):
        leg = create_cylinder(f"{name}_Leg{i}", leg_radius, leg_h,
                              location=(x + lx, y + ly, z), material=leg_material)
        legs.append(leg)

    return {'top': top, 'legs': legs}


def add_chair(name="Chair", location=(0, 0, 0),
              seat_width=0.45, seat_depth=0.45, seat_height=0.45,
              back_height=0.45, material=None):
    """Create a simple chair with seat and backrest.

    Args:
        name: Object name prefix.
        location: (x, y, z) bottom-center.
        seat_width: Width of seat.
        seat_depth: Depth of seat.
        seat_height: Height of seat from floor.
        back_height: Height of backrest above seat.
        material: Material for all parts.

    Returns:
        dict with 'seat', 'back', 'legs' objects.
    """
    x, y, z = location
    if material is None:
        material = make_material(f"{name}_Mat", (0.3, 0.18, 0.1))

    seat_thick = 0.04
    leg_r = 0.02

    # Seat
    seat = create_box(f"{name}_Seat", seat_width, seat_depth, seat_thick,
                      location=(x, y, z + seat_height), material=material)

    # Backrest
    back = create_box(f"{name}_Back", seat_width, seat_thick, back_height,
                      location=(x, y - seat_depth / 2 + seat_thick / 2,
                                z + seat_height + seat_thick),
                      material=material)

    # Legs
    leg_h = seat_height
    ix = seat_width / 2 - 0.04
    iy = seat_depth / 2 - 0.04
    legs = []
    for i, (lx, ly) in enumerate([(-ix, -iy), (ix, -iy), (-ix, iy), (ix, iy)]):
        leg = create_cylinder(f"{name}_Leg{i}", leg_r, leg_h,
                              location=(x + lx, y + ly, z), material=material)
        legs.append(leg)

    return {'seat': seat, 'back': back, 'legs': legs}


def add_bed(name="Bed", location=(0, 0, 0),
            width=1.4, depth=2.0, height=0.5,
            headboard_height=0.6, material=None,
            sheet_color=(0.9, 0.9, 0.95)):
    """Create a bed with mattress, frame, and headboard.

    Args:
        name: Object name prefix.
        location: (x, y, z) bottom-center.
        width: Bed width (single=0.9, double=1.4, queen=1.5, king=1.8).
        depth: Bed length.
        height: Mattress top height from floor.
        headboard_height: Headboard height above mattress.
        material: Frame material.
        sheet_color: (R, G, B) for bedsheet/mattress.

    Returns:
        dict with 'frame', 'mattress', 'headboard', 'pillow' objects.
    """
    x, y, z = location
    if material is None:
        material = make_material(f"{name}_Frame", (0.3, 0.2, 0.1))
    sheet_mat = make_material(f"{name}_Sheet", sheet_color)
    pillow_mat = make_material(f"{name}_Pillow", (1.0, 1.0, 0.98))

    frame_h = height * 0.6
    matt_h = height - frame_h

    # Frame
    frame = create_box(f"{name}_Frame", width, depth, frame_h,
                       location=(x, y, z), material=material)

    # Mattress
    mattress = create_box(f"{name}_Mattress", width - 0.02, depth - 0.02, matt_h,
                          location=(x, y, z + frame_h), material=sheet_mat)

    # Headboard
    hb = create_box(f"{name}_Headboard", width, 0.06, headboard_height,
                    location=(x, y - depth / 2 + 0.03, z + frame_h),
                    material=material)

    # Pillow(s)
    pw = min(0.5, width * 0.35)
    pillow = create_box(f"{name}_Pillow", pw, 0.35, 0.1,
                        location=(x, y - depth / 2 + 0.3, z + height),
                        material=pillow_mat)

    return {'frame': frame, 'mattress': mattress, 'headboard': hb, 'pillow': pillow}


def add_sofa(name="Sofa", location=(0, 0, 0),
             width=2.0, depth=0.85, seat_height=0.45,
             back_height=0.35, arm_width=0.15,
             material=None):
    """Create a sofa with seat, back, and arms.

    Args:
        name: Object name prefix.
        location: (x, y, z) bottom-center.
        width: Total width including arms.
        depth: Total depth.
        seat_height: Seat height from floor.
        back_height: Backrest height above seat.
        arm_width: Width of each arm.
        material: Upholstery material.

    Returns:
        dict with 'seat', 'back', 'left_arm', 'right_arm' objects.
    """
    x, y, z = location
    if material is None:
        material = make_material(f"{name}_Mat", (0.22, 0.30, 0.42), roughness=0.85)

    inner_w = width - 2 * arm_width

    # Seat cushion — slightly lighter than base
    cushion_mat = make_material(f"{name}_Cushion", (0.25, 0.33, 0.45), roughness=0.9)
    seat = create_box(f"{name}_Seat", inner_w, depth * 0.6, seat_height * 0.3,
                      location=(x, y + depth * 0.1, z + seat_height * 0.7),
                      material=cushion_mat)

    # Base
    base = create_box(f"{name}_Base", width, depth, seat_height * 0.7,
                      location=(x, y, z), material=material)

    # Backrest
    back = create_box(f"{name}_Back", inner_w, 0.15, back_height,
                      location=(x, y - depth / 2 + 0.08, z + seat_height),
                      material=material)

    # Arms
    arm_h = seat_height + back_height * 0.5
    la = create_box(f"{name}_ArmL", arm_width, depth, arm_h,
                    location=(x - width / 2 + arm_width / 2, y, z),
                    material=material)
    ra = create_box(f"{name}_ArmR", arm_width, depth, arm_h,
                    location=(x + width / 2 - arm_width / 2, y, z),
                    material=material)

    return {'seat': seat, 'base': base, 'back': back, 'left_arm': la, 'right_arm': ra}


def add_shelf(name="Shelf", location=(0, 0, 0),
              width=0.8, depth=0.3, height=1.8,
              shelves=5, material=None):
    """Create a bookshelf / shelving unit.

    Args:
        name: Object name prefix.
        location: (x, y, z) bottom-center.
        width: Total width.
        depth: Total depth.
        height: Total height.
        shelves: Number of shelf boards (including top and bottom).
        material: Material for all parts.

    Returns:
        dict with 'sides' and 'shelves' lists.
    """
    x, y, z = location
    if material is None:
        material = make_material(f"{name}_Mat", (0.35, 0.22, 0.12))

    thick = 0.02
    parts_shelves = []

    # Shelves
    spacing = height / (shelves - 1)
    for i in range(shelves):
        sh = create_box(f"{name}_Shelf{i}", width, depth, thick,
                        location=(x, y, z + i * spacing), material=material)
        parts_shelves.append(sh)

    # Side panels
    sides = []
    for i, sx in enumerate([x - width / 2 + thick / 2, x + width / 2 - thick / 2]):
        side = create_box(f"{name}_Side{i}", thick, depth, height,
                          location=(sx, y, z), material=material)
        sides.append(side)

    # Back panel
    back = create_box(f"{name}_Back", width, thick, height,
                      location=(x, y - depth / 2 + thick / 2, z), material=material)

    return {'sides': sides, 'shelves': parts_shelves, 'back': back}


def add_lamp(name="Lamp", location=(0, 0, 0),
             height=1.5, shade_radius=0.2, energy=100,
             color=(1.0, 0.95, 0.85)):
    """Create a floor lamp with pole, shade, and point light.

    Args:
        name: Object name prefix.
        location: (x, y, z) base position.
        height: Total height.
        shade_radius: Lamp shade radius.
        energy: Light energy in watts.
        color: Light color (R, G, B).

    Returns:
        dict with 'pole', 'shade', 'light' objects.
    """
    x, y, z = location
    pole_mat = make_material(f"{name}_Pole", (0.15, 0.15, 0.15), metallic=0.9)
    shade_mat = make_material(f"{name}_Shade", (0.95, 0.9, 0.8))

    # Pole
    pole = create_cylinder(f"{name}_Pole", 0.015, height - shade_radius,
                           location=(x, y, z), material=pole_mat)

    # Shade (cone-ish)
    bpy.ops.mesh.primitive_cone_add(
        radius1=shade_radius, radius2=shade_radius * 0.5,
        depth=shade_radius * 0.8, vertices=32,
        location=(x, y, z + height - shade_radius * 0.4)
    )
    shade = bpy.context.active_object
    shade.name = f"{name}_Shade"
    apply_material(shade, shade_mat)

    # Point light inside shade
    light = add_point_light(
        name=f"{name}_Light", energy=energy, color=color,
        location=(x, y, z + height - shade_radius * 0.3)
    )

    return {'pole': pole, 'shade': shade, 'light': light}


def add_kitchen_counter(name="Counter", location=(0, 0, 0),
                        width=2.5, depth=0.6, height=0.9,
                        has_sink=True, material=None):
    """Create a kitchen counter with optional sink.

    Args:
        name: Object name prefix.
        location: (x, y, z) bottom-center.
        width: Counter width.
        depth: Counter depth.
        height: Counter height.
        has_sink: Whether to include a sink basin.
        material: Counter material.

    Returns:
        dict with 'base', 'top' and optionally 'sink' objects.
    """
    x, y, z = location
    if material is None:
        material = make_material(f"{name}_Top", (0.82, 0.80, 0.78), roughness=0.1, metallic=0.05)
    base_mat = make_material(f"{name}_Base", (0.25, 0.18, 0.10), roughness=0.7)

    # Base cabinet
    base = create_box(f"{name}_Base", width, depth, height - 0.04,
                      location=(x, y, z), material=base_mat)

    # Countertop
    top = create_box(f"{name}_Top", width + 0.02, depth + 0.04, 0.04,
                     location=(x, y + 0.02, z + height - 0.04), material=material)

    result = {'base': base, 'top': top}

    if has_sink:
        sink_mat = make_material(f"{name}_Sink", (0.8, 0.8, 0.82), metallic=0.9, roughness=0.1)
        sink = create_box(f"{name}_Sink", 0.5, 0.4, 0.02,
                          location=(x, y, z + height - 0.02), material=sink_mat)
        result['sink'] = sink

    return result


def add_toilet(name="Toilet", location=(0, 0, 0), material=None):
    """Create a simple toilet (bowl + tank).

    Returns:
        dict with 'bowl', 'tank' objects.
    """
    x, y, z = location
    if material is None:
        material = make_material(f"{name}_Mat", (0.95, 0.95, 0.95), roughness=0.15)

    # Bowl
    bowl = create_cylinder(f"{name}_Bowl", 0.2, 0.4,
                           location=(x, y + 0.1, z), material=material)

    # Tank
    tank = create_box(f"{name}_Tank", 0.38, 0.18, 0.4,
                      location=(x, y - 0.2, z + 0.35), material=material)

    # Seat
    seat = create_cylinder(f"{name}_Seat", 0.19, 0.03,
                           location=(x, y + 0.1, z + 0.4), material=material)

    return {'bowl': bowl, 'tank': tank, 'seat': seat}


def add_bathtub(name="Bathtub", location=(0, 0, 0),
                width=0.7, depth=1.7, height=0.55, material=None):
    """Create a simple bathtub.

    Returns:
        dict with 'tub' object.
    """
    x, y, z = location
    if material is None:
        material = make_material(f"{name}_Mat", (0.95, 0.95, 0.97), roughness=0.1)

    outer = create_box(f"{name}_Outer", width, depth, height,
                       location=(x, y, z), material=material)

    inner_mat = make_material(f"{name}_Inner", (0.92, 0.92, 0.94), roughness=0.05)
    inner = create_box(f"{name}_Inner", width - 0.08, depth - 0.08, height - 0.05,
                       location=(x, y, z + 0.05), material=inner_mat)

    # Boolean subtract inner from outer
    mod = outer.modifiers.new('Carve', 'BOOLEAN')
    mod.operation = 'DIFFERENCE'
    mod.object = inner
    select_object(outer)
    bpy.ops.object.modifier_apply(modifier=mod.name)
    bpy.data.objects.remove(inner, do_unlink=True)

    return {'tub': outer}


# ---------------------------------------------------------------------------
# Multi-room floor plan builder
# ---------------------------------------------------------------------------

def build_house_from_plan(plan, name="House", exterior_material=None,
                          interior_material=None, floor_material=None,
                          roof_style='gable', roof_peak=2.0,
                          roof_material=None, height=None):
    """Build a multi-room house from a floor plan definition.

    Args:
        plan: List of room dicts, each with:
            - name: Room name (e.g. 'LivingRoom')
            - origin: (x, y) bottom-left corner
            - width: Room width (X)
            - depth: Room depth (Y)
            - door_wall: Which wall has a door ('front'/'back'/'left'/'right'/None)
            - door_pos: Fractional position 0-1 along the wall
            - windows: Dict mapping wall to list of fractional positions
            - furniture: List of furniture dicts (optional):
                - type: 'table', 'chair', 'bed', 'sofa', 'shelf', 'lamp',
                        'counter', 'toilet', 'bathtub'
                - offset: (x, y) offset from room origin
                - kwargs: Additional keyword arguments for the furniture function
            - interior: bool (True = interior walls, default from context)
        name: House name prefix.
        exterior_material: Material for exterior walls.
        interior_material: Material for interior walls.
        floor_material: Material for floors.
        roof_style: 'gable', 'hip', or None (no roof).
        roof_peak: Roof peak height above walls.
        roof_material: Roof material.
        height: Wall height (default: WALL_HEIGHT).

    Returns:
        dict with 'rooms', 'roof', 'ground', 'furniture', 'sun', 'camera'.
    """
    if height is None:
        height = WALL_HEIGHT
    if exterior_material is None:
        exterior_material = mat_wall_exterior(f"{name}_ExtWall")
    if interior_material is None:
        interior_material = mat_wall_interior(f"{name}_IntWall")
    if floor_material is None:
        floor_material = mat_floor_wood(f"{name}_Floor")
    if roof_material is None:
        roof_material = mat_roof_tile(f"{name}_Roof")

    rooms = []
    all_furniture = []

    # Calculate bounding box for roof and ground
    min_x, min_y = float('inf'), float('inf')
    max_x, max_y = float('-inf'), float('-inf')

    for rdef in plan:
        ox, oy = rdef['origin']
        rw = rdef['width']
        rd = rdef['depth']
        min_x = min(min_x, ox)
        min_y = min(min_y, oy)
        max_x = max(max_x, ox + rw)
        max_y = max(max_y, oy + rd)

    for rdef in plan:
        rname = rdef.get('name', 'Room')
        is_interior = rdef.get('interior', False)
        wall_mat = interior_material if is_interior else exterior_material

        room = build_room(
            name=f"{name}_{rname}",
            origin=rdef['origin'],
            width=rdef['width'],
            depth=rdef['depth'],
            height=height,
            exterior=not is_interior,
            door_wall=rdef.get('door_wall'),
            door_pos=rdef.get('door_pos', 0.5),
            windows=rdef.get('windows', {}),
            wall_material=wall_mat,
            floor_material=floor_material,
        )
        rooms.append(room)

        # Place furniture
        for fdef in rdef.get('furniture', []):
            ftype = fdef['type']
            ox, oy = rdef['origin']
            fx, fy = fdef.get('offset', (0, 0))
            floc = (ox + fx, oy + fy, 0)
            fkw = fdef.get('kwargs', {})
            fname = f"{name}_{rname}_{ftype}"

            fobj = None
            if ftype == 'table':
                fobj = add_table(name=fname, location=floc, **fkw)
            elif ftype == 'chair':
                fobj = add_chair(name=fname, location=floc, **fkw)
            elif ftype == 'bed':
                fobj = add_bed(name=fname, location=floc, **fkw)
            elif ftype == 'sofa':
                fobj = add_sofa(name=fname, location=floc, **fkw)
            elif ftype == 'shelf':
                fobj = add_shelf(name=fname, location=floc, **fkw)
            elif ftype == 'lamp':
                fobj = add_lamp(name=fname, location=floc, **fkw)
            elif ftype == 'counter':
                fobj = add_kitchen_counter(name=fname, location=floc, **fkw)
            elif ftype == 'toilet':
                fobj = add_toilet(name=fname, location=floc, **fkw)
            elif ftype == 'bathtub':
                fobj = add_bathtub(name=fname, location=floc, **fkw)

            if fobj:
                all_furniture.append(fobj)

    # Roof
    total_w = max_x - min_x
    total_d = max_y - min_y
    center_x = (min_x + max_x) / 2
    center_y = (min_y + max_y) / 2

    roof = None
    if roof_style == 'gable':
        roof = create_roof_gable(
            name=f"{name}_Roof", width=total_w, depth=total_d,
            wall_height=height, peak_height=roof_peak, material=roof_material,
        )
        roof.location.x = center_x
        roof.location.y = center_y
    elif roof_style == 'hip':
        roof = create_roof_hip(
            name=f"{name}_Roof", width=total_w, depth=total_d,
            wall_height=height, peak_height=roof_peak, material=roof_material,
        )
        roof.location.x = center_x
        roof.location.y = center_y

    # Ground
    ground_size = max(total_w, total_d) * 2.5
    ground = create_floor(
        name="Ground", width=ground_size, depth=ground_size,
        location=(center_x, center_y, -0.01),
        material=mat_grass("GroundGrass"),
    )

    # Lighting
    sun = add_sun(energy=3.0)

    # Camera
    cam = orbit_camera(
        target=(center_x, center_y, height / 2),
        distance=max(total_w, total_d) * 2.0,
        elevation=30, azimuth=-35,
    )

    return {
        'rooms': rooms,
        'roof': roof,
        'ground': ground,
        'furniture': all_furniture,
        'sun': sun,
        'camera': cam,
    }


# ---------------------------------------------------------------------------
# Photorealistic rendering setup
# ---------------------------------------------------------------------------

def setup_cycles(samples=128, use_denoising=True, use_gpu=True):
    """Configure Cycles render engine for photorealistic output.

    Args:
        samples: Number of render samples (128 = good quality, 512 = high).
        use_denoising: Enable AI denoiser.
        use_gpu: Try to use GPU compute.
    """
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    scene.cycles.samples = samples
    scene.cycles.use_denoising = use_denoising

    if use_gpu:
        try:
            prefs = bpy.context.preferences.addons['cycles'].preferences
            prefs.compute_device_type = 'CUDA'
            prefs.get_devices()
            for device in prefs.devices:
                device.use = True
            scene.cycles.device = 'GPU'
        except Exception:
            scene.cycles.device = 'CPU'


def setup_hdri_environment(hdri_path=None, strength=1.0, rotation=0.0):
    """Set up an HDRI environment for realistic lighting.

    Args:
        hdri_path: Path to .hdr/.exr file. If None, creates a procedural sky.
        strength: Environment light strength.
        rotation: Z-rotation of environment in degrees.
    """
    world = bpy.context.scene.world
    if world is None:
        world = bpy.data.worlds.new("World")
        bpy.context.scene.world = world
    world.use_nodes = True
    nodes = world.node_tree.nodes
    links = world.node_tree.links
    nodes.clear()

    out = nodes.new('ShaderNodeOutputWorld')
    out.location = (400, 0)
    bg = nodes.new('ShaderNodeBackground')
    bg.location = (200, 0)
    bg.inputs['Strength'].default_value = strength
    links.new(bg.outputs['Background'], out.inputs['Surface'])

    if hdri_path and os.path.exists(hdri_path):
        # HDRI environment
        env_tex = nodes.new('ShaderNodeTexEnvironment')
        env_tex.location = (-200, 0)
        env_tex.image = bpy.data.images.load(hdri_path)
        links.new(env_tex.outputs['Color'], bg.inputs['Color'])

        # Rotation
        if rotation != 0:
            mapping = nodes.new('ShaderNodeMapping')
            mapping.location = (-400, 0)
            mapping.inputs['Rotation'].default_value = (0, 0, math.radians(rotation))
            coord = nodes.new('ShaderNodeTexCoord')
            coord.location = (-600, 0)
            links.new(coord.outputs['Generated'], mapping.inputs['Vector'])
            links.new(mapping.outputs['Vector'], env_tex.inputs['Vector'])
    else:
        # Procedural sky
        sky = nodes.new('ShaderNodeTexSky')
        sky.location = (-200, 0)
        sky.sky_type = 'NISHITA'
        sky.sun_elevation = math.radians(30)
        sky.sun_rotation = math.radians(rotation)
        links.new(sky.outputs['Color'], bg.inputs['Color'])


# Aliases LLMs commonly try for environment setup
setup_sky_nishita = setup_hdri_environment
add_nishita_sky = setup_hdri_environment
add_environment_lighting = setup_hdri_environment
setup_environment = setup_hdri_environment


def setup_camera_dof(camera_obj=None, focus_distance=5.0, f_stop=2.8):
    """Enable depth of field on a camera.

    Args:
        camera_obj: Camera object (uses active camera if None).
        focus_distance: Focus distance in meters.
        f_stop: Aperture f-stop (lower = more blur).
    """
    if camera_obj is None:
        camera_obj = bpy.context.scene.camera
    if camera_obj is None:
        return
    cam_data = camera_obj.data
    cam_data.dof.use_dof = True
    cam_data.dof.focus_distance = focus_distance
    cam_data.dof.aperture_fstop = f_stop


def render_photorealistic(output_path=None, resolution=(1920, 1080),
                          samples=256, setup_env=True):
    """Full photorealistic render: Cycles + denoising + sky environment.

    Args:
        output_path: Output file path (default: PROJECT_DIR/render_photo.png).
        resolution: (width, height) tuple.
        samples: Cycles render samples.
        setup_env: Whether to set up procedural sky environment.

    Returns:
        The output path string.
    """
    if output_path is None:
        output_path = os.path.join(PROJECT_DIR, "render_photo.png")

    setup_cycles(samples=samples)

    if setup_env:
        setup_hdri_environment()

    scene = bpy.context.scene
    scene.render.resolution_x = resolution[0]
    scene.render.resolution_y = resolution[1]
    scene.render.filepath = output_path.replace("\\", "/")
    scene.render.image_settings.file_format = 'PNG'

    bpy.ops.render.render(write_still=True)
    print(f"Photorealistic render saved: {output_path}")
    return output_path


# ---------------------------------------------------------------------------
# Live-mode helpers (for building in open Blender)
# ---------------------------------------------------------------------------

def refresh_viewport():
    """Force a viewport redraw (useful in live mode).

    When running scripts inside an open Blender, call this between
    construction steps to see objects appear in real-time.
    """
    try:
        bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
    except Exception:
        pass


def build_with_steps(steps, delay=0.5):
    """Execute a list of build functions with viewport refresh between each.

    This creates a "watch it build" effect in an open Blender window.

    Args:
        steps: List of callables (functions/lambdas) to execute in order.
        delay: Seconds to pause between steps (for visual effect).

    Example:
        build_with_steps([
            lambda: clear_scene(),
            lambda: setup_scene(),
            lambda: create_wall("W1", (0,0), (6,0)),
            lambda: create_wall("W2", (6,0), (6,4)),
            lambda: add_sun(),
            lambda: orbit_camera(target=(3,2,1.5), distance=12),
        ])
    """
    import time as _time
    results = []
    for i, step in enumerate(steps):
        result = step()
        results.append(result)
        refresh_viewport()
        if delay > 0 and i < len(steps) - 1:
            _time.sleep(delay)
    return results


# ---------------------------------------------------------------------------
# Scene 1: Sci-Fi Environment Builder
# ---------------------------------------------------------------------------

def mat_scifi_wall(name="SciFiWall"):
    """Riveted military panel wall material."""
    try:
        return make_pbr_material(name, texture_id='scifi_panel_military_riveted')
    except Exception:
        return make_material(name, (0.25, 0.27, 0.25), metallic=0.8, roughness=0.5)


def mat_scifi_floor(name="SciFiFloor"):
    """Dark diamond plate industrial floor."""
    try:
        return make_pbr_material(name, texture_id='metal_diamond_plate_dark')
    except Exception:
        return make_material(name, (0.1, 0.1, 0.12), metallic=0.9, roughness=0.35)


def mat_scifi_ceiling(name="SciFiCeiling"):
    """Dark sci-fi ceiling with machinery panels."""
    try:
        return make_pbr_material(name, texture_id='scifi_ceiling_panels_dark')
    except Exception:
        return make_material(name, (0.08, 0.08, 0.1), metallic=0.7, roughness=0.5)


def mat_neon(name="Neon", color=(0.0, 0.8, 1.0), strength=10.0):
    """Create a bright emission material for neon / LED lights.

    Args:
        name: Material name.
        color: (R, G, B) glow color.
        strength: Emission intensity.

    Returns:
        bpy.types.Material.
    """
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out = nodes.new('ShaderNodeOutputMaterial')
    out.location = (400, 0)
    emit = nodes.new('ShaderNodeEmission')
    emit.location = (200, 0)
    emit.inputs['Color'].default_value = (*color, 1.0)
    emit.inputs['Strength'].default_value = strength
    links.new(emit.outputs['Emission'], out.inputs['Surface'])

    return mat


def mat_metal_dark(name="DarkMetal"):
    """Dark brushed metal for structural elements."""
    return make_material(name, (0.12, 0.12, 0.14), metallic=0.9, roughness=0.3)


def _orient_between(obj, start, end):
    """Orient an object to span between two 3D points along its Z axis."""
    s = Vector(start)
    e = Vector(end)
    direction = (e - s).normalized()
    # Default cylinder/cube Z-up, we want it to point along direction
    rot = direction.to_track_quat('Z', 'Y')
    obj.rotation_euler = rot.to_euler()


def add_neon_strip(name="NeonStrip", start=(0, 0, 0), end=(10, 0, 0),
                   width=0.05, color=(0.0, 0.8, 1.0), strength=10.0,
                   add_glow_light=True):
    """Create a glowing neon strip light between two points.

    Args:
        name: Object name.
        start: (x, y, z) start point.
        end: (x, y, z) end point.
        width: Strip cross-section size.
        color: Neon glow color (R, G, B).
        strength: Emission strength.
        add_glow_light: Add a point light for ambient glow.

    Returns:
        dict with 'strip' and optionally 'light'.
    """
    s = Vector(start)
    e = Vector(end)
    length = (e - s).length
    mid = (s + e) / 2

    neon_mat = mat_neon(f"{name}_Mat", color, strength)

    bpy.ops.mesh.primitive_cube_add(size=1, location=mid)
    obj = bpy.context.active_object
    obj.name = name

    # Scale: X=width, Y=width, Z=length (will rotate to align)
    obj.scale = (width, width, length)
    bpy.ops.object.transform_apply(scale=True)

    _orient_between(obj, start, end)
    apply_material(obj, neon_mat)

    result = {'strip': obj}

    if add_glow_light:
        light = add_point_light(
            name=f"{name}_Glow",
            location=tuple(mid),
            energy=strength * length * 2,
            color=color,
        )
        result['light'] = light

    return result


def add_pipe_run(name="Pipe", start=(0, 0, 0), end=(10, 0, 0),
                 radius=0.06, material=None):
    """Create a cylindrical pipe between two points.

    Args:
        name: Object name.
        start: (x, y, z) start point.
        end: (x, y, z) end point.
        radius: Pipe radius.
        material: Optional material.

    Returns:
        The pipe object.
    """
    s = Vector(start)
    e = Vector(end)
    length = (e - s).length
    mid = (s + e) / 2

    if material is None:
        material = mat_metal_dark(f"{name}_Mat")

    bpy.ops.mesh.primitive_cylinder_add(
        radius=radius, depth=length, vertices=16,
        location=mid
    )
    obj = bpy.context.active_object
    obj.name = name
    _orient_between(obj, start, end)
    select_object(obj)
    bpy.ops.object.shade_smooth()
    apply_material(obj, material)
    return obj


def add_support_rib(name="Rib", location=(0, 0, 0), width=4.0, height=3.5,
                    thickness=0.08, depth=0.15, material=None):
    """Create a structural support rib/arch that frames a corridor cross-section.

    Args:
        name: Object name prefix.
        location: (x, y, z) center-bottom of the rib.
        width: Total span width.
        height: Total height.
        thickness: Beam thickness.
        depth: Beam depth (along corridor axis).
        material: Rib material.

    Returns:
        List of rib part objects.
    """
    x, y, z = location
    if material is None:
        material = mat_metal_dark(f"{name}_Mat")

    parts = []
    # Left vertical
    parts.append(create_box(f"{name}_L", thickness, depth, height,
                            location=(x - width / 2 + thickness / 2, y, z),
                            material=material))
    # Right vertical
    parts.append(create_box(f"{name}_R", thickness, depth, height,
                            location=(x + width / 2 - thickness / 2, y, z),
                            material=material))
    # Top horizontal
    parts.append(create_box(f"{name}_T", width, depth, thickness,
                            location=(x, y, z + height - thickness / 2),
                            material=material))
    return parts


def add_bulkhead_door(name="BulkheadDoor", location=(0, 0, 0),
                      width=2.0, height=2.8, depth=0.3,
                      frame_material=None, door_material=None):
    """Create a heavy sci-fi bulkhead door with frame.

    Args:
        name: Object name prefix.
        location: (x, y, z) center-bottom.
        width: Door opening width.
        height: Door height.
        depth: Frame depth.
        frame_material: Heavy frame material.
        door_material: Door panel material.

    Returns:
        List of door part objects.
    """
    x, y, z = location
    if frame_material is None:
        frame_material = make_material(f"{name}_Frame", (0.18, 0.18, 0.2),
                                       metallic=0.9, roughness=0.35)
    if door_material is None:
        try:
            door_material = make_pbr_material(f"{name}_Door",
                                              texture_id='scifi_panel_clean_light')
        except Exception:
            door_material = make_material(f"{name}_Door", (0.6, 0.6, 0.65),
                                          metallic=0.8, roughness=0.3)

    fw = 0.12  # frame width
    parts = []
    # Left frame
    parts.append(create_box(f"{name}_FL", fw, depth, height + fw,
                            location=(x - width / 2 - fw / 2, y, z),
                            material=frame_material))
    # Right frame
    parts.append(create_box(f"{name}_FR", fw, depth, height + fw,
                            location=(x + width / 2 + fw / 2, y, z),
                            material=frame_material))
    # Top frame
    parts.append(create_box(f"{name}_FT", width + fw * 2, depth, fw,
                            location=(x, y, z + height),
                            material=frame_material))
    # Door panels (split left/right with gap)
    gap = 0.02
    pw = width / 2 - gap
    parts.append(create_box(f"{name}_DL", pw, depth * 0.5, height - gap,
                            location=(x - pw / 2 - gap / 2, y, z),
                            material=door_material))
    parts.append(create_box(f"{name}_DR", pw, depth * 0.5, height - gap,
                            location=(x + pw / 2 + gap / 2, y, z),
                            material=door_material))

    # Door warning strip (neon)
    strip_mat = mat_neon(f"{name}_WarnMat", color=(1.0, 0.3, 0.0), strength=5.0)
    parts.append(create_box(f"{name}_Warn", width + fw * 2, depth * 0.3, 0.03,
                            location=(x, y, z + height + fw / 2),
                            material=strip_mat, bevel=False))
    return parts


def add_vent_grate(name="Vent", location=(0, 0, 0),
                   width=0.6, height=0.4, material=None):
    """Create a wall-mounted vent grate.

    Returns:
        The vent object.
    """
    if material is None:
        try:
            material = make_pbr_material(f"{name}_Mat",
                                         texture_id='metal_grill_perforated_dark')
        except Exception:
            material = make_material(f"{name}_Mat", (0.1, 0.1, 0.12),
                                    metallic=0.9, roughness=0.3)

    return create_box(name, width, 0.03, height,
                      location=location, material=material, bevel=False)


def add_control_panel(name="ControlPanel", location=(0, 0, 0),
                      width=0.5, height=0.7, depth=0.08):
    """Create a wall-mounted tech control panel with circuit-board screen.

    Returns:
        List of [frame, screen] objects.
    """
    x, y, z = location
    try:
        screen_mat = make_pbr_material(f"{name}_Screen",
                                       texture_id='pattern_circuit_board_gold_green')
    except Exception:
        screen_mat = mat_neon(f"{name}_Screen", color=(0.0, 0.8, 0.3), strength=1.0)

    frame_mat = mat_metal_dark(f"{name}_Frame")

    frame = create_box(f"{name}_Frame", width + 0.04, depth, height + 0.04,
                       location=(x, y, z), material=frame_mat)
    screen = create_box(f"{name}_Screen", width, depth + 0.005, height,
                        location=(x, y + 0.003, z + 0.02),
                        material=screen_mat, bevel=False)
    return [frame, screen]


def setup_dark_environment(bg_color=(0.003, 0.003, 0.008), bg_strength=0.1,
                           fog_density=0.0, fog_color=(0.5, 0.6, 0.7)):
    """Set up a dark environment with optional volumetric fog.

    Args:
        bg_color: Background color (very dark).
        bg_strength: Background brightness.
        fog_density: Volume scatter density (0 = no fog).
        fog_color: Fog scatter color.
    """
    world = bpy.context.scene.world
    if world is None:
        world = bpy.data.worlds.new("World")
        bpy.context.scene.world = world
    world.use_nodes = True
    nodes = world.node_tree.nodes
    links = world.node_tree.links
    nodes.clear()

    out = nodes.new('ShaderNodeOutputWorld')
    out.location = (400, 0)
    bg = nodes.new('ShaderNodeBackground')
    bg.location = (200, 0)
    bg.inputs['Color'].default_value = (*bg_color, 1.0)
    bg.inputs['Strength'].default_value = bg_strength
    links.new(bg.outputs['Background'], out.inputs['Surface'])

    if fog_density > 0:
        scatter = nodes.new('ShaderNodeVolumeScatter')
        scatter.location = (200, -200)
        scatter.inputs['Color'].default_value = (*fog_color, 1.0)
        scatter.inputs['Density'].default_value = fog_density
        scatter.inputs['Anisotropy'].default_value = 0.3
        links.new(scatter.outputs['Volume'], out.inputs['Volume'])


def build_scifi_corridor(name="Corridor", length=20.0, width=4.0, height=3.5,
                         segments=5, has_fog=True, neon_color=(0.0, 0.8, 1.0),
                         door_positions=None):
    """Build a complete sci-fi corridor scene with all details.

    Creates: textured walls, diamond-plate floor, dark ceiling, structural ribs,
    neon strip lights, ceiling pipes, wall vents, control panels, bulkhead doors,
    accent lighting, volumetric fog, and a cinematic camera.

    Args:
        name: Scene name prefix.
        length: Corridor length (Y axis).
        width: Corridor width (X axis).
        height: Corridor height (Z axis).
        segments: Number of structural rib segments.
        has_fog: Add volumetric fog for atmosphere.
        neon_color: RGB tuple for neon accent lights.
        door_positions: List of Y positions for bulkhead doors (auto if None).

    Returns:
        dict with all scene objects grouped by type.
    """
    clear_scene()
    setup_scene()

    # Materials
    wall_mat = mat_scifi_wall(f"{name}_Wall")
    floor_mat = mat_scifi_floor(f"{name}_Floor")
    ceil_mat = mat_scifi_ceiling(f"{name}_Ceiling")
    hw = width / 2

    # --- Floor ---
    floor = create_floor(f"{name}_Floor", width=width, depth=length,
                         location=(0, length / 2, 0), material=floor_mat)

    # --- Ceiling ---
    ceiling = create_floor(f"{name}_Ceiling", width=width, depth=length,
                           location=(0, length / 2, height), material=ceil_mat)

    # --- Walls (left and right) ---
    left_wall = create_wall(f"{name}_WallL", (-hw, 0), (-hw, length),
                            height=height, thickness=0.15)
    apply_material(left_wall, wall_mat)
    right_wall = create_wall(f"{name}_WallR", (hw, length), (hw, 0),
                             height=height, thickness=0.15)
    apply_material(right_wall, wall_mat)

    # --- End walls ---
    back_wall = create_wall(f"{name}_WallBack", (-hw, length), (hw, length),
                            height=height, thickness=0.15)
    apply_material(back_wall, wall_mat)

    # --- Support ribs ---
    rib_spacing = length / (segments + 1)
    ribs = []
    for i in range(1, segments + 1):
        ry = i * rib_spacing
        rib = add_support_rib(f"{name}_Rib{i}",
                              location=(0, ry, 0),
                              width=width, height=height)
        ribs.extend(rib)

    # --- Neon strip lights along upper wall edges ---
    neon_strips = []
    neon_h = height - 0.25
    neon_strips.append(add_neon_strip(
        f"{name}_NeonL",
        start=(-hw + 0.12, 0.3, neon_h),
        end=(-hw + 0.12, length - 0.3, neon_h),
        color=neon_color, strength=15.0))
    neon_strips.append(add_neon_strip(
        f"{name}_NeonR",
        start=(hw - 0.12, 0.3, neon_h),
        end=(hw - 0.12, length - 0.3, neon_h),
        color=neon_color, strength=15.0))

    # --- Floor center neon guide strip ---
    neon_strips.append(add_neon_strip(
        f"{name}_NeonFloor",
        start=(0, 0.3, 0.005),
        end=(0, length - 0.3, 0.005),
        width=0.06, color=neon_color, strength=6.0,
        add_glow_light=True))

    # --- Ceiling pipes ---
    pipes = []
    pipe_mat = mat_metal_dark(f"{name}_PipeMat")
    for px in [-hw + 0.5, hw - 0.5]:
        pipes.append(add_pipe_run(
            f"{name}_Pipe_{int(px * 10)}",
            start=(px, 0, height - 0.18),
            end=(px, length, height - 0.18),
            radius=0.05, material=pipe_mat))
    # Cross pipes at each rib
    for i in range(1, segments + 1):
        py = i * rib_spacing
        pipes.append(add_pipe_run(
            f"{name}_XPipe{i}",
            start=(-hw + 0.25, py, height - 0.12),
            end=(hw - 0.25, py, height - 0.12),
            radius=0.03, material=pipe_mat))

    # --- Wall vents (alternating sides) ---
    vents = []
    for i in range(1, segments + 1):
        vy = i * rib_spacing + rib_spacing * 0.35
        if vy < length - 1:
            side = -1 if i % 2 == 0 else 1
            vents.append(add_vent_grate(
                f"{name}_Vent{i}",
                location=(side * (hw - 0.02), vy, 0.5)))

    # --- Control panels (every other segment, opposite side from vents) ---
    panels = []
    for i in range(1, segments + 1, 2):
        py = i * rib_spacing + rib_spacing * 0.6
        if py < length - 1:
            panels.extend(add_control_panel(
                f"{name}_Panel{i}",
                location=(-hw + 0.02, py, 1.2)))

    # --- Bulkhead doors ---
    doors = []
    if door_positions is None:
        door_positions = [length * 0.35, length * 0.7]
    for i, dy in enumerate(door_positions):
        doors.extend(add_bulkhead_door(
            f"{name}_Door{i}", location=(0, dy, 0)))

    # --- Accent lights (warm overhead between ribs) ---
    accents = []
    for i in range(1, segments + 1):
        ay = i * rib_spacing + rib_spacing * 0.5
        if ay < length:
            accents.append(add_point_light(
                (0, ay, height - 0.05),
                energy=60, color=(1.0, 0.6, 0.3),
                name=f"{name}_Accent{i}"))

    # --- Environment: dark with fog ---
    fog_density = 0.012 if has_fog else 0.0
    setup_dark_environment(
        bg_color=(0.002, 0.003, 0.006),
        fog_density=fog_density,
        fog_color=(0.3, 0.4, 0.5))

    # --- Camera: cinematic low-angle down the corridor ---
    cam = add_camera(
        location=(0, -1.5, 1.6),
        target=(0, length * 0.65, 1.4),
        focal_length=24,
    )
    setup_camera_dof(cam, focus_distance=10, f_stop=4.0)

    total = len(bpy.data.objects)
    print(f"Sci-fi corridor built: {total} objects, {segments} segments, "
          f"{len(door_positions)} doors")

    return {
        'floor': floor, 'ceiling': ceiling,
        'walls': [left_wall, right_wall, back_wall],
        'ribs': ribs, 'neon': neon_strips,
        'pipes': pipes, 'vents': vents,
        'panels': panels, 'doors': doors,
        'accents': accents, 'camera': cam,
    }


# ---------------------------------------------------------------------------
# Scene 2: Multi-Story Building
# ---------------------------------------------------------------------------

def add_staircase(name="Stairs", base_pos=(0, 0, 0),
                  width=1.0, total_rise=3.0, total_run=3.0,
                  num_steps=15, direction='Y', material=None):
    """Create a straight-run staircase.

    Args:
        name: Object name prefix.
        base_pos: (x, y, z) bottom of first step.
        width: Stair width.
        total_rise: Total vertical rise.
        total_run: Total horizontal run.
        num_steps: Number of steps.
        direction: 'Y' (along Y axis) or 'X' (along X axis).
        material: Step material.

    Returns:
        List of step objects.
    """
    if material is None:
        material = make_material(f"{name}_Mat", (0.6, 0.6, 0.62), roughness=0.7)

    step_h = total_rise / num_steps
    step_d = total_run / num_steps
    bx, by, bz = base_pos
    steps = []

    for i in range(num_steps):
        sz = bz + i * step_h
        if direction == 'Y':
            sy = by + i * step_d
            step = create_box(f"{name}_S{i}", width, step_d + 0.01, step_h,
                              location=(bx, sy + step_d / 2, sz),
                              material=material, bevel=False, smooth=False)
        else:
            sx = bx + i * step_d
            step = create_box(f"{name}_S{i}", step_d + 0.01, width, step_h,
                              location=(sx + step_d / 2, by, sz),
                              material=material, bevel=False, smooth=False)
        steps.append(step)

    # Stringer (side support)
    stringer_mat = make_material(f"{name}_Stringer", (0.3, 0.3, 0.32),
                                 metallic=0.8, roughness=0.4)
    run_len = math.sqrt(total_run ** 2 + total_rise ** 2)
    angle = math.atan2(total_rise, total_run)

    for side in [-1, 1]:
        sx = bx + side * (width / 2 + 0.02)
        if direction == 'Y':
            mid_y = by + total_run / 2
            mid_z = bz + total_rise / 2
            bpy.ops.mesh.primitive_cube_add(size=1,
                location=(sx, mid_y, mid_z))
            obj = bpy.context.active_object
            obj.name = f"{name}_Stringer{'L' if side < 0 else 'R'}"
            obj.scale = (0.03, run_len, 0.12)
            obj.rotation_euler = (-angle, 0, 0)
        else:
            mid_x = bx + total_run / 2
            mid_z = bz + total_rise / 2
            bpy.ops.mesh.primitive_cube_add(size=1,
                location=(mid_x, by + side * (width / 2 + 0.02), mid_z))
            obj = bpy.context.active_object
            obj.name = f"{name}_Stringer{'L' if side < 0 else 'R'}"
            obj.scale = (run_len, 0.03, 0.12)
            obj.rotation_euler = (0, angle, 0)
        bpy.ops.object.transform_apply(scale=True)
        apply_material(obj, stringer_mat)
        steps.append(obj)

    return steps


def add_railing_segment(name="Railing", start=(0, 0, 0), end=(1, 0, 0),
                        height=1.0, post_spacing=0.5,
                        material=None):
    """Create a railing with posts and top rail between two points.

    Args:
        name: Object name prefix.
        start: (x, y, z) start point (base of railing).
        end: (x, y, z) end point (base of railing).
        height: Railing height.
        post_spacing: Distance between posts.
        material: Railing material.

    Returns:
        List of railing parts.
    """
    if material is None:
        material = make_material(f"{name}_Mat", (0.2, 0.2, 0.22),
                                 metallic=0.9, roughness=0.3)

    s = Vector(start)
    e = Vector(end)
    rail_dir = e - s
    length = rail_dir.length
    if length < 0.01:
        return []
    rail_dir_n = rail_dir.normalized()

    parts = []
    post_r = 0.02
    rail_r = 0.025

    # Posts
    num_posts = max(2, int(length / post_spacing) + 1)
    for i in range(num_posts):
        t = i / max(1, num_posts - 1)
        pos = s + rail_dir * t
        post = create_cylinder(f"{name}_Post{i}", post_r, height,
                               location=tuple(pos), material=material)
        parts.append(post)

    # Top rail
    mid = (s + e) / 2 + Vector((0, 0, height))
    top_rail = add_pipe_run(f"{name}_TopRail",
                            start=(s.x, s.y, s.z + height),
                            end=(e.x, e.y, e.z + height),
                            radius=rail_r, material=material)
    parts.append(top_rail)

    # Mid rail
    mid_h = height * 0.5
    mid_rail = add_pipe_run(f"{name}_MidRail",
                            start=(s.x, s.y, s.z + mid_h),
                            end=(e.x, e.y, e.z + mid_h),
                            radius=rail_r * 0.7, material=material)
    parts.append(mid_rail)

    return parts


def add_balcony(name="Balcony", location=(0, 0, 0),
                width=3.0, depth=1.5, slab_thickness=0.15,
                railing_height=1.0, floor_material=None,
                railing_material=None):
    """Create a balcony platform with railings on 3 sides.

    Args:
        name: Object name prefix.
        location: (x, y, z) where the balcony attaches to the building wall.
        width: Balcony width (along wall).
        depth: How far the balcony extends out.
        slab_thickness: Floor slab thickness.
        railing_height: Railing height.
        floor_material: Slab material.
        railing_material: Railing material.

    Returns:
        dict with 'slab' and 'railings' list.
    """
    x, y, z = location
    if floor_material is None:
        floor_material = make_material(f"{name}_Slab", (0.7, 0.7, 0.72),
                                       roughness=0.8)
    if railing_material is None:
        railing_material = make_material(f"{name}_Rail", (0.15, 0.15, 0.17),
                                         metallic=0.9, roughness=0.3)

    # Floor slab
    slab = create_box(f"{name}_Slab", width, depth, slab_thickness,
                      location=(x, y + depth / 2, z - slab_thickness),
                      material=floor_material, bevel=False, smooth=False)

    railings = []
    # Front railing
    railings.extend(add_railing_segment(
        f"{name}_RailF",
        start=(x - width / 2, y + depth, z),
        end=(x + width / 2, y + depth, z),
        height=railing_height, material=railing_material))
    # Left railing
    railings.extend(add_railing_segment(
        f"{name}_RailL",
        start=(x - width / 2, y, z),
        end=(x - width / 2, y + depth, z),
        height=railing_height, material=railing_material))
    # Right railing
    railings.extend(add_railing_segment(
        f"{name}_RailR",
        start=(x + width / 2, y, z),
        end=(x + width / 2, y + depth, z),
        height=railing_height, material=railing_material))

    return {'slab': slab, 'railings': railings}


def build_multi_story_building(name="Building", width=12, depth=8,
                                floors=3, floor_height=3.0,
                                apt_width=5.0, hall_width=2.0):
    """Build a multi-story apartment building with furnished units.

    Creates: exterior walls with windows at each floor level, floor slabs,
    interior partitions, staircases, balconies with railings, furnished
    apartments, flat roof with parapet, and exterior ground.

    Args:
        name: Building name prefix.
        width: Total building width (X).
        depth: Total building depth (Y).
        floors: Number of floors.
        floor_height: Floor-to-floor height.
        apt_width: Width of each apartment.
        hall_width: Central hallway width.

    Returns:
        dict with all building objects.
    """
    clear_scene()
    setup_scene()

    total_h = floors * floor_height
    hw = width / 2

    # --- Materials ---
    ext_mat = mat_wall_exterior(f"{name}_Ext")
    int_mat = mat_wall_interior(f"{name}_Int")
    floor_mat = mat_floor_wood(f"{name}_FloorWood")
    tile_mat = mat_floor_tile(f"{name}_Tile")
    concrete_mat = make_material(f"{name}_Concrete", (0.65, 0.63, 0.60),
                                  roughness=0.85)
    trim_mat = mat_wood_trim(f"{name}_Trim")

    all_objects = []

    # --- Exterior walls (full building height) ---
    # Front wall
    front_wall = create_wall(f"{name}_Front", (0, 0), (width, 0),
                             height=total_h, thickness=WALL_THICKNESS_EXT)
    apply_material(front_wall, ext_mat)
    all_objects.append(front_wall)

    # Back wall
    back_wall = create_wall(f"{name}_Back", (width, depth), (0, depth),
                            height=total_h, thickness=WALL_THICKNESS_EXT)
    apply_material(back_wall, ext_mat)
    all_objects.append(back_wall)

    # Left wall
    left_wall = create_wall(f"{name}_Left", (0, depth), (0, 0),
                            height=total_h, thickness=WALL_THICKNESS_EXT)
    apply_material(left_wall, ext_mat)
    all_objects.append(left_wall)

    # Right wall
    right_wall = create_wall(f"{name}_Right", (width, 0), (width, depth),
                             height=total_h, thickness=WALL_THICKNESS_EXT)
    apply_material(right_wall, ext_mat)
    all_objects.append(right_wall)

    # --- Cut windows at each floor level ---
    # Front wall: 2 windows per apartment per floor + 1 hallway window
    for f in range(floors):
        z_sill = f * floor_height + WINDOW_SILL
        # Apt A windows (left side)
        for wx in [1.5, 3.5]:
            cut_window(front_wall, center_x=wx, center_y=0,
                       sill_height=z_sill)
        # Hallway window
        cut_window(front_wall, center_x=width / 2, center_y=0,
                   sill_height=z_sill, width=0.8, height=1.2)
        # Apt B windows (right side)
        for wx in [width - 3.5, width - 1.5]:
            cut_window(front_wall, center_x=wx, center_y=0,
                       sill_height=z_sill)

    # Side walls: 1 window per floor
    for f in range(floors):
        z_sill = f * floor_height + WINDOW_SILL
        cut_window(left_wall, center_x=0, center_y=depth / 2,
                   sill_height=z_sill)
        cut_window(right_wall, center_x=width, center_y=depth / 2,
                   sill_height=z_sill)

    # Back wall: 2 windows per floor
    for f in range(floors):
        z_sill = f * floor_height + WINDOW_SILL
        cut_window(back_wall, center_x=3, center_y=depth,
                   sill_height=z_sill)
        cut_window(back_wall, center_x=width - 3, center_y=depth,
                   sill_height=z_sill)

    # --- Exterior window frames + sills on front wall ---
    sill_mat = make_material(f"{name}_Sill", (0.50, 0.48, 0.45), roughness=0.75)
    for f in range(floors):
        z_sill = f * floor_height + WINDOW_SILL
        z_center = z_sill + WINDOW_HEIGHT / 2
        # Apt A window frames
        for wx in [1.5, 3.5]:
            wf, wg = add_window_frame(
                location=(wx, -0.02, z_center),
                name=f"{name}_WF_F{f}_{wx}", material=trim_mat)
            all_objects.extend([wf, wg])
            # Window sill ledge
            bpy.ops.mesh.primitive_cube_add(size=1,
                location=(wx, -0.08, z_sill - 0.03))
            sill = bpy.context.active_object
            sill.name = f"{name}_Sill_F{f}_{wx}"
            sill.scale = (WINDOW_WIDTH + 0.1, 0.1, 0.04)
            bpy.ops.object.transform_apply(scale=True)
            apply_material(sill, sill_mat)
            all_objects.append(sill)
        # Hallway window frame
        wf, wg = add_window_frame(
            location=(width / 2, -0.02, z_center),
            width=0.8, height=1.2,
            name=f"{name}_WF_H{f}", material=trim_mat)
        all_objects.extend([wf, wg])
        # Apt B window frames
        for wx in [width - 3.5, width - 1.5]:
            wf, wg = add_window_frame(
                location=(wx, -0.02, z_center),
                name=f"{name}_WF_F{f}_{wx}", material=trim_mat)
            all_objects.extend([wf, wg])
            bpy.ops.mesh.primitive_cube_add(size=1,
                location=(wx, -0.08, z_sill - 0.03))
            sill = bpy.context.active_object
            sill.name = f"{name}_SillB_F{f}_{wx}"
            sill.scale = (WINDOW_WIDTH + 0.1, 0.1, 0.04)
            bpy.ops.object.transform_apply(scale=True)
            apply_material(sill, sill_mat)
            all_objects.append(sill)

    # --- Floor slabs + interior partitions per level ---
    hall_x_start = apt_width
    hall_x_end = apt_width + hall_width
    floor_slabs = []
    partitions = []

    for f in range(floors):
        z = f * floor_height

        # Floor slab (full building footprint, except ground floor at z=0)
        slab_mat = concrete_mat if f > 0 else floor_mat
        slab = create_floor(f"{name}_Slab{f}", width=width, depth=depth,
                            location=(width / 2, depth / 2, z),
                            thickness=0.2 if f > 0 else 0.05,
                            material=slab_mat)
        floor_slabs.append(slab)
        all_objects.append(slab)

        # Ceiling for this floor (= floor of next, or roof underside)
        ceil_z = z + floor_height
        if f == floors - 1:
            # Top floor ceiling
            ceil = create_floor(f"{name}_Ceil{f}", width=width, depth=depth,
                                location=(width / 2, depth / 2, ceil_z),
                                material=concrete_mat)
            all_objects.append(ceil)

        # Interior partition: Apt A | Hallway
        pw1 = create_box(f"{name}_Part{f}L", WALL_THICKNESS_INT, depth,
                          floor_height,
                          location=(hall_x_start, depth / 2, z),
                          material=int_mat, bevel=False)
        partitions.append(pw1)
        all_objects.append(pw1)

        # Interior partition: Hallway | Apt B
        pw2 = create_box(f"{name}_Part{f}R", WALL_THICKNESS_INT, depth,
                          floor_height,
                          location=(hall_x_end, depth / 2, z),
                          material=int_mat, bevel=False)
        partitions.append(pw2)
        all_objects.append(pw2)

    # --- Front door (ground floor) + entrance canopy ---
    cut_door(front_wall, center_x=width / 2, center_y=0)
    # Add door frame
    df = add_door_frame(location=(width / 2, 0, 0),
                        name=f"{name}_DoorFrame", material=trim_mat)
    all_objects.append(df)

    # Entrance canopy
    canopy_mat = make_material(f"{name}_Canopy", (0.35, 0.33, 0.30),
                                metallic=0.5, roughness=0.4)
    bpy.ops.mesh.primitive_cube_add(size=1,
        location=(width / 2, -0.6, DOOR_HEIGHT + 0.1))
    canopy = bpy.context.active_object
    canopy.name = f"{name}_Canopy"
    canopy.scale = (3.0, 1.2, 0.08)
    bpy.ops.object.transform_apply(scale=True)
    apply_material(canopy, canopy_mat)
    all_objects.append(canopy)
    # Canopy supports
    for cx in [width / 2 - 1.2, width / 2 + 1.2]:
        bpy.ops.mesh.primitive_cylinder_add(radius=0.03, depth=0.6,
            location=(cx, -1.1, DOOR_HEIGHT + 0.1 - 0.3))
        sup = bpy.context.active_object
        sup.name = f"{name}_CanopySupport"
        apply_material(sup, canopy_mat)
        all_objects.append(sup)

    # --- Staircase in hallway ---
    stair_parts = []
    stair_x = width / 2
    stair_mat = make_material(f"{name}_StairMat", (0.55, 0.55, 0.57),
                              roughness=0.7)
    for f in range(floors - 1):
        z_base = f * floor_height + 0.05
        stairs = add_staircase(
            f"{name}_Stairs{f}",
            base_pos=(stair_x, 1.0, z_base),
            width=hall_width * 0.8,
            total_rise=floor_height - 0.05,
            total_run=depth - 2.5,
            num_steps=int(floor_height / 0.2),
            direction='Y',
            material=stair_mat,
        )
        stair_parts.extend(stairs)
    all_objects.extend(stair_parts)

    # --- Balconies (floors 2 and 3) ---
    balconies = []
    for f in range(1, floors):
        z = f * floor_height
        # Apt A balcony
        bal_a = add_balcony(f"{name}_BalA{f}",
                            location=(apt_width / 2, -0.01, z),
                            width=apt_width * 0.6, depth=1.3)
        balconies.append(bal_a)
        # Apt B balcony
        bal_b = add_balcony(f"{name}_BalB{f}",
                            location=(hall_x_end + apt_width / 2, -0.01, z),
                            width=apt_width * 0.6, depth=1.3)
        balconies.append(bal_b)

    # --- Roof parapet ---
    parapet_h = 0.6
    parapet_mat = make_material(f"{name}_Parapet", (0.5, 0.48, 0.45),
                                roughness=0.8)
    for start, end in [((0, 0), (width, 0)),
                       ((width, 0), (width, depth)),
                       ((width, depth), (0, depth)),
                       ((0, depth), (0, 0))]:
        par = create_wall(f"{name}_Parapet", start, end,
                          height=parapet_h, thickness=0.12)
        par.location.z = total_h
        apply_material(par, parapet_mat)
        all_objects.append(par)

    # --- Horizontal bands between floors (facade detail) ---
    band_mat = make_material(f"{name}_Band", (0.55, 0.53, 0.50), roughness=0.7)
    for f in range(1, floors):
        z = f * floor_height
        band = create_box(f"{name}_Band{f}", width + 0.08, 0.06, 0.12,
                          location=(width / 2, -0.03, z - 0.06),
                          material=band_mat, bevel=False)
        all_objects.append(band)

    # --- Furniture per floor ---
    furniture = []
    furniture_types_a = [
        [('sofa', 2.5, 3.5), ('table', 2.5, 1.5), ('lamp', 0.5, 4)],
        [('bed', 2.5, 4, {'width': 1.5}), ('shelf', 4.5, 2)],
        [('bed', 2.5, 4, {'width': 1.4}), ('lamp', 0.5, 3)],
    ]
    furniture_types_b = [
        [('counter', 2, 1, {'width': 3.0}), ('table', 2, 4),
         ('chair', 1.3, 4), ('chair', 2.7, 4)],
        [('bed', 2.5, 4, {'width': 1.5}), ('shelf', 0.5, 2)],
        [('bed', 2.5, 4, {'width': 1.4}), ('lamp', 4.5, 3)],
    ]

    furn_funcs = {
        'sofa': add_sofa, 'table': add_table, 'lamp': add_lamp,
        'shelf': add_shelf, 'bed': add_bed, 'counter': add_kitchen_counter,
        'chair': add_chair, 'toilet': add_toilet, 'bathtub': add_bathtub,
    }

    for f in range(floors):
        z = f * floor_height + 0.05
        # Apartment A furniture
        flist_a = furniture_types_a[f % len(furniture_types_a)]
        for fdef in flist_a:
            ftype = fdef[0]
            fx, fy = fdef[1], fdef[2]
            kwargs = fdef[3] if len(fdef) > 3 else {}
            func = furn_funcs.get(ftype)
            if func:
                result = func(name=f"{name}_F{f}A_{ftype}",
                              location=(fx, fy, z), **kwargs)
                furniture.append(result)

        # Apartment B furniture
        flist_b = furniture_types_b[f % len(furniture_types_b)]
        for fdef in flist_b:
            ftype = fdef[0]
            fx, fy = fdef[1], fdef[2]
            kwargs = fdef[3] if len(fdef) > 3 else {}
            func = furn_funcs.get(ftype)
            if func:
                result = func(name=f"{name}_F{f}B_{ftype}",
                              location=(hall_x_end + fx, fy, z), **kwargs)
                furniture.append(result)

    # --- Interior lights per floor ---
    lights = []
    for f in range(floors):
        z_light = (f + 1) * floor_height - 0.15
        # Apt A light
        lights.append(add_point_light(
            (apt_width / 2, depth / 2, z_light),
            energy=apt_width * depth * 4,
            color=(1.0, 0.95, 0.88),
            name=f"{name}_LightA{f}"))
        # Apt B light
        lights.append(add_point_light(
            (hall_x_end + apt_width / 2, depth / 2, z_light),
            energy=apt_width * depth * 4,
            color=(1.0, 0.95, 0.88),
            name=f"{name}_LightB{f}"))
        # Hallway light
        lights.append(add_point_light(
            (width / 2, depth / 2, z_light),
            energy=hall_width * depth * 3,
            color=(1.0, 0.98, 0.92),
            name=f"{name}_LightH{f}"))

    # --- Ground ---
    grass_mat = make_pbr_material(f"{name}_Grass",
                                  texture_id='nature_grass_seamless')
    ground = create_floor("Ground", width=width * 3, depth=depth * 3,
                          location=(width / 2, depth / 2, -0.02),
                          material=grass_mat)
    all_objects.append(ground)

    # --- Sun + Camera ---
    sun = add_sun(energy=3.5)
    cam = orbit_camera(
        target=(width / 2, depth / 2, total_h / 2),
        distance=max(width, depth) * 2.5,
        elevation=25, azimuth=-30,
    )

    total = len(bpy.data.objects)
    print(f"Multi-story building built: {total} objects, {floors} floors, "
          f"{floors * 2} apartments")

    return {
        'walls': all_objects,
        'stairs': stair_parts,
        'balconies': balconies,
        'furniture': furniture,
        'lights': lights,
        'ground': ground,
        'sun': sun, 'camera': cam,
    }


# ---------------------------------------------------------------------------
# Scene 3: Street / Neighborhood
# ---------------------------------------------------------------------------

def add_road_segment(name="Road", origin=(0, 0), length=30, width=6.0):
    """Create a textured road segment along the X axis.

    Args:
        name: Object name.
        origin: (x, y) center-start of road.
        length: Road length along X.
        width: Road width along Y.

    Returns:
        The road object.
    """
    try:
        road_mat = make_pbr_material(f"{name}_Mat",
                                      texture_id='road_asphalt_markings',
                                      uv_scale=0.15)
    except Exception:
        road_mat = make_material(f"{name}_Mat", (0.12, 0.12, 0.13), roughness=0.9)

    road = create_floor(name, width=length, depth=width,
                        location=(origin[0] + length / 2, origin[1], 0.01),
                        thickness=0.08, material=road_mat)
    return road


def add_sidewalk(name="Sidewalk", origin=(0, 0), length=30, width=1.5):
    """Create a concrete sidewalk segment along the X axis.

    Returns:
        The sidewalk object.
    """
    sw_mat = make_material(f"{name}_Mat", (0.72, 0.70, 0.68), roughness=0.85)
    sw = create_floor(name, width=length, depth=width,
                      location=(origin[0] + length / 2, origin[1] + width / 2, 0.03),
                      thickness=0.1, material=sw_mat)
    return sw


def add_curb(name="Curb", origin=(0, 0), length=30, height=0.12, depth=0.15):
    """Create a raised concrete curb strip along the X axis.

    Args:
        name: Object name.
        origin: (x, y) start position.
        length: Curb length.
        height: Curb height above road.
        depth: Curb thickness (Y).

    Returns:
        The curb object.
    """
    curb_mat = make_material(f"{name}_Mat", (0.60, 0.58, 0.55), roughness=0.9)
    bpy.ops.mesh.primitive_cube_add(size=1,
        location=(origin[0] + length / 2, origin[1] + depth / 2, height / 2))
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = (length, depth, height)
    bpy.ops.object.transform_apply(scale=True)
    apply_material(obj, curb_mat)
    return obj


def add_streetlight(name="Streetlight", location=(0, 0, 0),
                    height=4.5, energy=500,
                    color=(1.0, 0.95, 0.85)):
    """Create a streetlight pole with lamp.

    Args:
        name: Object name prefix.
        location: (x, y, z) base position.
        height: Pole height.
        energy: Light energy in watts.
        color: Light color.

    Returns:
        dict with 'pole', 'arm', 'shade', 'light'.
    """
    x, y, z = location
    pole_mat = make_material(f"{name}_Pole", (0.2, 0.2, 0.22),
                             metallic=0.85, roughness=0.4)

    # Pole
    pole = create_cylinder(f"{name}_Pole", 0.06, height,
                           location=(x, y, z), material=pole_mat)

    # Arm extending out
    arm_len = 0.8
    bpy.ops.mesh.primitive_cube_add(size=1,
        location=(x, y + arm_len / 2, z + height))
    arm = bpy.context.active_object
    arm.name = f"{name}_Arm"
    arm.scale = (0.04, arm_len, 0.04)
    bpy.ops.object.transform_apply(scale=True)
    apply_material(arm, pole_mat)

    # Lamp shade
    shade_mat = make_material(f"{name}_Shade", (0.85, 0.85, 0.82),
                              roughness=0.3)
    bpy.ops.mesh.primitive_cube_add(size=1,
        location=(x, y + arm_len, z + height - 0.1))
    shade = bpy.context.active_object
    shade.name = f"{name}_Shade"
    shade.scale = (0.25, 0.15, 0.08)
    bpy.ops.object.transform_apply(scale=True)
    apply_material(shade, shade_mat)

    # Point light
    light = add_point_light(
        (x, y + arm_len, z + height - 0.15),
        energy=energy, color=color,
        name=f"{name}_Light")

    return {'pole': pole, 'arm': arm, 'shade': shade, 'light': light}


def add_fence_segment(name="Fence", start=(0, 0, 0), end=(5, 0, 0),
                      height=1.0, picket_spacing=0.12,
                      material=None, style='picket'):
    """Create a fence segment between two points.

    Args:
        name: Object name prefix.
        start: (x, y, z) start.
        end: (x, y, z) end.
        height: Fence height.
        picket_spacing: Space between pickets.
        material: Fence material.
        style: 'picket' or 'metal'.

    Returns:
        List of fence part objects.
    """
    if material is None:
        if style == 'picket':
            material = make_material(f"{name}_Mat", (0.85, 0.82, 0.75),
                                     roughness=0.8)
        else:
            material = make_material(f"{name}_Mat", (0.15, 0.15, 0.17),
                                     metallic=0.9, roughness=0.3)

    s = Vector(start)
    e = Vector(end)
    fence_dir = e - s
    length = fence_dir.length
    if length < 0.1:
        return []

    parts = []

    # Top rail
    parts.append(add_pipe_run(f"{name}_TopRail",
                              start=(s.x, s.y, s.z + height),
                              end=(e.x, e.y, e.z + height),
                              radius=0.025 if style == 'picket' else 0.02,
                              material=material))
    # Bottom rail
    parts.append(add_pipe_run(f"{name}_BotRail",
                              start=(s.x, s.y, s.z + 0.15),
                              end=(e.x, e.y, e.z + 0.15),
                              radius=0.02, material=material))

    # Pickets/posts
    num = max(2, int(length / picket_spacing))
    for i in range(num + 1):
        t = i / num
        pos = s + fence_dir * t
        if style == 'picket':
            pw, pd = 0.06, 0.015
            p = create_box(f"{name}_P{i}", pw, pd, height + 0.05,
                           location=tuple(pos), material=material,
                           bevel=False, smooth=False)
        else:
            p = create_cylinder(f"{name}_P{i}", 0.01, height,
                                location=tuple(pos), material=material)
        parts.append(p)

    return parts


def add_simple_tree(name="Tree", location=(0, 0, 0),
                    trunk_height=2.0, trunk_radius=0.12,
                    canopy_radius=1.5, canopy_style='sphere'):
    """Create a simple tree with trunk and foliage canopy.

    Args:
        name: Object name prefix.
        location: (x, y, z) base position.
        trunk_height: Trunk height.
        trunk_radius: Trunk radius.
        canopy_radius: Foliage radius.
        canopy_style: 'sphere' or 'cone'.

    Returns:
        dict with 'trunk' and 'canopy'.
    """
    x, y, z = location
    try:
        bark_mat = make_pbr_material(f"{name}_Bark",
                                      texture_id='nature_bark_tree_seamless')
    except Exception:
        bark_mat = make_material(f"{name}_Bark", (0.28, 0.18, 0.08),
                                 roughness=0.95)
    leaf_mat = make_material(f"{name}_Leaf", (0.15, 0.35, 0.1), roughness=0.9)

    # Trunk
    trunk = create_cylinder(f"{name}_Trunk", trunk_radius, trunk_height,
                            location=(x, y, z), material=bark_mat)

    # Canopy
    canopy_z = z + trunk_height + canopy_radius * 0.5
    if canopy_style == 'cone':
        bpy.ops.mesh.primitive_cone_add(
            radius1=canopy_radius, radius2=0.1,
            depth=canopy_radius * 2, vertices=16,
            location=(x, y, canopy_z))
    else:
        bpy.ops.mesh.primitive_ico_sphere_add(
            radius=canopy_radius, subdivisions=2,
            location=(x, y, canopy_z))
    canopy = bpy.context.active_object
    canopy.name = f"{name}_Canopy"
    select_object(canopy)
    bpy.ops.object.shade_smooth()
    apply_material(canopy, leaf_mat)

    return {'trunk': trunk, 'canopy': canopy}


def add_mailbox(name="Mailbox", location=(0, 0, 0)):
    """Create a simple roadside mailbox.

    Returns:
        dict with 'post' and 'box'.
    """
    x, y, z = location
    post_mat = make_material(f"{name}_Post", (0.3, 0.2, 0.1), roughness=0.8)
    box_mat = make_material(f"{name}_Box", (0.1, 0.2, 0.5), roughness=0.6)

    post = create_box(f"{name}_Post", 0.08, 0.08, 1.0,
                      location=(x, y, z), material=post_mat,
                      bevel=False, smooth=False)
    box = create_box(f"{name}_Box", 0.25, 0.18, 0.2,
                     location=(x, y, z + 1.0), material=box_mat)

    return {'post': post, 'box': box}


def _place_house(name, origin, width, depth, roof_style, roof_peak,
                 ext_mat, floor_mat, roof_mat, rooms_plan):
    """Internal: build a house at a given origin without ground/sun/camera."""
    ox, oy = origin
    height = WALL_HEIGHT
    room_results = []

    for rdef in rooms_plan:
        rname = rdef['name']
        rox = ox + rdef.get('ox', 0)
        roy = oy + rdef.get('oy', 0)
        rw = rdef.get('width', width)
        rd = rdef.get('depth', depth)

        room = build_room(
            f"{name}_{rname}",
            origin=(rox, roy), width=rw, depth=rd,
            door_wall=rdef.get('door_wall'),
            door_pos=rdef.get('door_pos', 0.5),
            windows=rdef.get('windows', {}),
            floor_material=floor_mat,
            wall_material=ext_mat,
        )
        room_results.append(room)

        # Furniture
        for fdef in rdef.get('furniture', []):
            ftype = fdef['type']
            fx = rox + fdef['offset'][0]
            fy = roy + fdef['offset'][1]
            func = {
                'sofa': add_sofa, 'table': add_table, 'lamp': add_lamp,
                'shelf': add_shelf, 'bed': add_bed,
                'counter': add_kitchen_counter, 'chair': add_chair,
            }.get(ftype)
            if func:
                func(name=f"{name}_{rname}_{ftype}",
                     location=(fx, fy, 0),
                     **fdef.get('kwargs', {}))

    # Roof
    total_w = max(r.get('ox', 0) + r.get('width', width) for r in rooms_plan)
    total_d = max(r.get('oy', 0) + r.get('depth', depth) for r in rooms_plan)
    cx = ox + total_w / 2
    cy = oy + total_d / 2

    if roof_style == 'hip':
        roof = create_roof_hip(f"{name}_Roof", total_w + 0.4, total_d + 0.4,
                               peak_height=roof_peak, material=roof_mat)
    else:
        roof = create_roof_gable(f"{name}_Roof", total_w + 0.4, total_d + 0.4,
                                 peak_height=roof_peak, material=roof_mat)
    roof.location.x = cx
    roof.location.y = cy

    return room_results


def build_street_scene(name="Street", road_length=40, num_houses=3):
    """Build a neighborhood street scene with houses, road, and props.

    Creates: asphalt road with markings, concrete sidewalks, 2-3 houses
    with varied styles on each side, picket fences, trees, streetlights,
    mailboxes, and grass ground.

    Args:
        name: Scene name prefix.
        road_length: Length of the road (X axis).
        num_houses: Number of houses per side.

    Returns:
        dict with all scene objects.
    """
    clear_scene()
    setup_scene()

    road_y = 0
    road_w = 6.0
    sidewalk_w = 1.5
    yard_depth = 8.0
    house_spacing = road_length / num_houses

    # --- Road ---
    road = add_road_segment(f"{name}_Road",
                            origin=(0, road_y - road_w / 2),
                            length=road_length, width=road_w)

    # --- Sidewalks + Curbs ---
    curb_n = add_curb(f"{name}_CurbN",
                      origin=(0, road_y + road_w / 2),
                      length=road_length)
    curb_s = add_curb(f"{name}_CurbS",
                      origin=(0, road_y - road_w / 2 - 0.15),
                      length=road_length)
    sw_north = add_sidewalk(f"{name}_SWN",
                            origin=(0, road_y + road_w / 2 + 0.15),
                            length=road_length, width=sidewalk_w)
    sw_south = add_sidewalk(f"{name}_SWS",
                            origin=(0, road_y - road_w / 2 - 0.15 - sidewalk_w),
                            length=road_length, width=sidewalk_w)

    # --- Materials for houses ---
    ext_colors = [
        (0.92, 0.88, 0.72),  # warm cream
        (0.65, 0.75, 0.85),  # sky blue
        (0.82, 0.68, 0.58),  # terracotta beige
    ]
    roof_styles = ['gable', 'hip', 'gable']
    roof_peaks = [1.8, 2.0, 1.5]

    # House plan templates
    house_plans = [
        [  # Plan A: Living + Kitchen
            {'name': 'Living', 'ox': 0, 'oy': 0, 'width': 5, 'depth': 4,
             'door_wall': 'front', 'door_pos': 0.5,
             'windows': {'front': [0.2, 0.8], 'left': [0.5]},
             'furniture': [{'type': 'sofa', 'offset': (2.5, 2.5)},
                           {'type': 'lamp', 'offset': (0.5, 3.2)}]},
            {'name': 'Kitchen', 'ox': 5, 'oy': 0, 'width': 3, 'depth': 4,
             'door_wall': 'left', 'door_pos': 0.5,
             'windows': {'front': [0.5], 'right': [0.5]},
             'furniture': [{'type': 'counter', 'offset': (1.5, 0.4),
                            'kwargs': {'width': 2.0}}]},
        ],
        [  # Plan B: Open plan
            {'name': 'Main', 'ox': 0, 'oy': 0, 'width': 6, 'depth': 5,
             'door_wall': 'front', 'door_pos': 0.3,
             'windows': {'front': [0.6, 0.85], 'left': [0.5], 'right': [0.5]},
             'furniture': [{'type': 'table', 'offset': (3, 2.5)},
                           {'type': 'chair', 'offset': (2.3, 2.5)},
                           {'type': 'chair', 'offset': (3.7, 2.5)},
                           {'type': 'shelf', 'offset': (5.5, 1)}]},
        ],
        [  # Plan C: Bedroom + Bath
            {'name': 'Bedroom', 'ox': 0, 'oy': 0, 'width': 4, 'depth': 4,
             'door_wall': 'front', 'door_pos': 0.7,
             'windows': {'front': [0.3], 'left': [0.5]},
             'furniture': [{'type': 'bed', 'offset': (2, 2.5),
                            'kwargs': {'width': 1.4}}]},
            {'name': 'Bath', 'ox': 4, 'oy': 0, 'width': 3, 'depth': 4,
             'door_wall': 'left', 'door_pos': 0.5,
             'windows': {'right': [0.5]},
             'furniture': []},
        ],
    ]

    houses = []
    fences = []
    trees = []
    mailboxes = []

    # --- North side houses ---
    north_yard_y = road_y + road_w / 2 + sidewalk_w + 1.0
    for i in range(num_houses):
        hx = 3 + i * house_spacing
        hy = north_yard_y + 2.0
        plan_idx = i % len(house_plans)

        # House exterior material
        ec = ext_colors[i % len(ext_colors)]
        ext_mat = make_material(f"{name}_H{i}_Ext", ec, roughness=0.8)
        floor_mat = mat_floor_wood(f"{name}_H{i}_Floor")
        roof_mat = mat_roof_tile(f"{name}_H{i}_Roof")

        plan = house_plans[plan_idx]
        _place_house(f"{name}_HN{i}", origin=(hx, hy),
                     width=5, depth=4,
                     roof_style=roof_styles[i % len(roof_styles)],
                     roof_peak=roof_peaks[i % len(roof_peaks)],
                     ext_mat=ext_mat, floor_mat=floor_mat,
                     roof_mat=roof_mat, rooms_plan=plan)
        houses.append(f"HN{i}")

        # Yard fence (front of yard)
        fence_y = north_yard_y
        plan_w = max(r.get('ox', 0) + r.get('width', 5) for r in plan)
        fences.extend(add_fence_segment(
            f"{name}_FenceN{i}",
            start=(hx - 0.5, fence_y, 0),
            end=(hx + plan_w + 0.5, fence_y, 0),
            height=0.9))

        # Tree in yard (organic displaced canopy)
        trees.append(add_organic_tree(
            f"{name}_TreeN{i}",
            location=(hx + plan_w + 1.5, hy + 1, 0),
            trunk_height=1.8 + i * 0.3,
            canopy_radius=1.2 + i * 0.2,
            seed=i * 17))

        # Mailbox
        mailboxes.append(add_mailbox(
            f"{name}_MBN{i}",
            location=(hx + plan_w / 2, fence_y - 0.3, 0)))

    # --- South side houses (mirrored) ---
    south_yard_y = road_y - road_w / 2 - sidewalk_w - 1.0
    for i in range(max(1, num_houses - 1)):
        hx = 5 + i * house_spacing + house_spacing * 0.5
        hy = south_yard_y - 6.0
        plan_idx = (i + 1) % len(house_plans)

        ec = ext_colors[(i + 1) % len(ext_colors)]
        ext_mat = make_material(f"{name}_HS{i}_Ext", ec, roughness=0.8)
        floor_mat = mat_floor_wood(f"{name}_HS{i}_Floor")
        roof_mat = mat_roof_tile(f"{name}_HS{i}_Roof")

        plan = house_plans[plan_idx]
        _place_house(f"{name}_HS{i}", origin=(hx, hy),
                     width=5, depth=4,
                     roof_style=roof_styles[(i + 1) % len(roof_styles)],
                     roof_peak=roof_peaks[(i + 1) % len(roof_peaks)],
                     ext_mat=ext_mat, floor_mat=floor_mat,
                     roof_mat=roof_mat, rooms_plan=plan)
        houses.append(f"HS{i}")

        # Tree (organic displaced canopy)
        trees.append(add_organic_tree(
            f"{name}_TreeS{i}",
            location=(hx - 1.5, hy + 2, 0),
            canopy_style='cone',
            seed=100 + i * 23))

    # --- Streetlights ---
    streetlights = []
    for i in range(0, int(road_length), 12):
        streetlights.append(add_streetlight(
            f"{name}_LightN{i}",
            location=(i + 6, road_y + road_w / 2 + 0.5, 0)))
        if i + 6 < road_length:
            streetlights.append(add_streetlight(
                f"{name}_LightS{i}",
                location=(i + 12, road_y - road_w / 2 - 0.5, 0)))

    # --- Grass ground ---
    grass_mat = make_pbr_material(f"{name}_Grass",
                                  texture_id='nature_grass_seamless')
    ground = create_floor("Ground",
                          width=road_length + 10, depth=40,
                          location=(road_length / 2, 0, -0.01),
                          material=grass_mat)

    # --- Sun + Camera ---
    sun = add_sun(energy=2.5, color=(1.0, 0.97, 0.92))
    cam = orbit_camera(
        target=(road_length / 2, 0, 3),
        distance=road_length * 0.8,
        elevation=30, azimuth=-20,
    )

    total = len(bpy.data.objects)
    print(f"Street scene built: {total} objects, {len(houses)} houses, "
          f"{len(streetlights)} streetlights, {len(trees)} trees")

    return {
        'road': road, 'sidewalks': [sw_north, sw_south],
        'houses': houses, 'fences': fences,
        'trees': trees, 'streetlights': streetlights,
        'mailboxes': mailboxes, 'ground': ground,
        'sun': sun, 'camera': cam,
    }


# ---------------------------------------------------------------------------
# Scene 4: Robot Character with Armature Rig
# ---------------------------------------------------------------------------

def _add_bone(armature_data, name, head, tail, parent_name=None):
    """Add a bone to an armature in edit mode."""
    bone = armature_data.edit_bones.new(name)
    bone.head = head
    bone.tail = tail
    if parent_name:
        parent = armature_data.edit_bones.get(parent_name)
        if parent:
            bone.parent = parent
    return bone


def _parent_to_bone(mesh_obj, armature_obj, bone_name):
    """Parent a mesh object to a specific bone of an armature (keep transform)."""
    # Store world matrix before parenting
    world_mat = mesh_obj.matrix_world.copy()
    mesh_obj.parent = armature_obj
    mesh_obj.parent_type = 'BONE'
    mesh_obj.parent_bone = bone_name
    # Restore world position by computing correct inverse
    mesh_obj.matrix_parent_inverse.identity()
    bpy.context.view_layer.update()
    mesh_obj.matrix_world = world_mat


def build_robot_character(name="Robot", location=(0, 0, 0),
                           pose='guard'):
    """Build a humanoid robot character with full armature rig.

    Creates: armature skeleton with 20+ bones, chrome body panels,
    dark metal joints, LED eyes, chest arc reactor, circuit-board
    forearm panels, studio lighting, and optional dynamic pose.

    Args:
        name: Character name prefix.
        location: (x, y, z) base position.
        pose: 'guard', 'wave', or 'neutral'.

    Returns:
        dict with 'armature', 'body_parts', 'lights', 'camera'.
    """
    clear_scene()
    setup_scene()
    ox, oy, oz = location

    # --- Materials ---
    chrome = make_material(f"{name}_Chrome", (0.75, 0.78, 0.80),
                           metallic=0.95, roughness=0.15)
    dark_metal = make_material(f"{name}_DarkMetal", (0.08, 0.08, 0.10),
                               metallic=0.9, roughness=0.4)
    joint_mat = make_material(f"{name}_Joint", (0.15, 0.15, 0.18),
                              metallic=0.85, roughness=0.5)
    eye_mat = mat_neon(f"{name}_Eye", color=(0.0, 0.85, 1.0), strength=15.0)
    reactor_mat = mat_neon(f"{name}_Reactor", color=(0.0, 0.7, 1.0),
                           strength=8.0)
    accent_mat = mat_neon(f"{name}_Accent", color=(0.0, 0.6, 0.9),
                          strength=3.0)
    try:
        arm_panel = make_pbr_material(f"{name}_ArmPanel",
                                      texture_id='pattern_circuit_board_gold_green')
    except Exception:
        arm_panel = make_material(f"{name}_ArmPanel", (0.05, 0.15, 0.08),
                                  metallic=0.7, roughness=0.3)

    # --- Create Armature ---
    arm_data = bpy.data.armatures.new(f"{name}_Armature")
    arm_data.display_type = 'STICK'
    armature = bpy.data.objects.new(f"{name}_Rig", arm_data)
    armature.location = (ox, oy, oz)
    bpy.context.collection.objects.link(armature)
    bpy.context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode='EDIT')

    # -- Bone hierarchy --
    _add_bone(arm_data, 'Root',       (0, 0, 0.95), (0, 0, 1.0))
    _add_bone(arm_data, 'Hips',       (0, 0, 0.95), (0, 0, 0.90), 'Root')
    _add_bone(arm_data, 'Spine',      (0, 0, 1.0),  (0, 0, 1.2),  'Root')
    _add_bone(arm_data, 'Chest',      (0, 0, 1.2),  (0, 0, 1.5),  'Spine')
    _add_bone(arm_data, 'Neck',       (0, 0, 1.5),  (0, 0, 1.6),  'Chest')
    _add_bone(arm_data, 'Head',       (0, 0, 1.6),  (0, 0, 1.8),  'Neck')
    _add_bone(arm_data, 'L_Shoulder', (0.22, 0, 1.45), (0.35, 0, 1.45), 'Chest')
    _add_bone(arm_data, 'L_UpperArm', (0.35, 0, 1.45), (0.35, 0, 1.15), 'L_Shoulder')
    _add_bone(arm_data, 'L_LowerArm', (0.35, 0, 1.15), (0.35, 0, 0.85), 'L_UpperArm')
    _add_bone(arm_data, 'L_Hand',     (0.35, 0, 0.85), (0.35, 0, 0.75), 'L_LowerArm')
    _add_bone(arm_data, 'R_Shoulder', (-0.22, 0, 1.45), (-0.35, 0, 1.45), 'Chest')
    _add_bone(arm_data, 'R_UpperArm', (-0.35, 0, 1.45), (-0.35, 0, 1.15), 'R_Shoulder')
    _add_bone(arm_data, 'R_LowerArm', (-0.35, 0, 1.15), (-0.35, 0, 0.85), 'R_UpperArm')
    _add_bone(arm_data, 'R_Hand',     (-0.35, 0, 0.85), (-0.35, 0, 0.75), 'R_LowerArm')
    _add_bone(arm_data, 'L_UpperLeg', (0.12, 0, 0.90), (0.12, 0, 0.50), 'Hips')
    _add_bone(arm_data, 'L_LowerLeg', (0.12, 0, 0.50), (0.12, 0, 0.08), 'L_UpperLeg')
    _add_bone(arm_data, 'L_Foot',     (0.12, 0, 0.08), (0.12, -0.12, 0.02), 'L_LowerLeg')
    _add_bone(arm_data, 'R_UpperLeg', (-0.12, 0, 0.90), (-0.12, 0, 0.50), 'Hips')
    _add_bone(arm_data, 'R_LowerLeg', (-0.12, 0, 0.50), (-0.12, 0, 0.08), 'R_UpperLeg')
    _add_bone(arm_data, 'R_Foot',     (-0.12, 0, 0.08), (-0.12, -0.12, 0.02), 'R_LowerLeg')

    bpy.ops.object.mode_set(mode='OBJECT')

    # --- Body Part Meshes ---
    parts = {}

    # Head
    parts['head'] = create_box(f"{name}_Head", 0.22, 0.24, 0.20,
                               location=(ox, oy, oz + 1.68), material=chrome)
    # Visor
    parts['visor'] = create_box(f"{name}_Visor", 0.20, 0.02, 0.08,
                                location=(ox, oy - 0.12, oz + 1.70),
                                material=dark_metal, bevel=False)
    # Eyes
    for side, sx in [('L', 0.05), ('R', -0.05)]:
        parts[f'eye_{side}'] = create_box(
            f"{name}_Eye{side}", 0.04, 0.02, 0.025,
            location=(ox + sx, oy - 0.13, oz + 1.72),
            material=eye_mat, bevel=False)

    # Neck
    parts['neck'] = create_cylinder(f"{name}_Neck", 0.04, 0.1,
                                    location=(ox, oy, oz + 1.55),
                                    material=joint_mat)
    # Chest
    parts['chest'] = create_box(f"{name}_Chest", 0.40, 0.22, 0.30,
                                location=(ox, oy, oz + 1.20), material=chrome)
    # Arc reactor
    bpy.ops.mesh.primitive_cylinder_add(
        radius=0.04, depth=0.02, vertices=16,
        location=(ox, oy - 0.12, oz + 1.35))
    reactor = bpy.context.active_object
    reactor.name = f"{name}_Reactor"
    apply_material(reactor, reactor_mat)
    parts['reactor'] = reactor

    # Abdomen
    parts['abdomen'] = create_box(f"{name}_Abdomen", 0.30, 0.18, 0.12,
                                  location=(ox, oy, oz + 1.02),
                                  material=dark_metal)
    # Hips
    parts['hips'] = create_box(f"{name}_Hips", 0.32, 0.20, 0.10,
                               location=(ox, oy, oz + 0.90),
                               material=chrome)

    # --- Arms ---
    for side, sx in [('L', 1), ('R', -1)]:
        arm_x = sx * 0.35
        bpy.ops.mesh.primitive_uv_sphere_add(
            radius=0.06, segments=12, ring_count=8,
            location=(ox + sx * 0.26, oy, oz + 1.45))
        sj = bpy.context.active_object
        sj.name = f"{name}_ShoulderJoint{side}"
        select_object(sj); bpy.ops.object.shade_smooth()
        apply_material(sj, joint_mat)
        parts[f'shoulder_joint_{side}'] = sj

        parts[f'upper_arm_{side}'] = create_box(
            f"{name}_UpperArm{side}", 0.10, 0.10, 0.28,
            location=(ox + arm_x, oy, oz + 1.18), material=chrome)

        bpy.ops.mesh.primitive_uv_sphere_add(
            radius=0.045, segments=12, ring_count=8,
            location=(ox + arm_x, oy, oz + 1.15))
        ej = bpy.context.active_object
        ej.name = f"{name}_ElbowJoint{side}"
        select_object(ej); bpy.ops.object.shade_smooth()
        apply_material(ej, joint_mat)
        parts[f'elbow_joint_{side}'] = ej

        parts[f'lower_arm_{side}'] = create_box(
            f"{name}_LowerArm{side}", 0.09, 0.09, 0.28,
            location=(ox + arm_x, oy, oz + 0.88), material=chrome)
        parts[f'arm_panel_{side}'] = create_box(
            f"{name}_ArmPanel{side}", 0.08, 0.02, 0.12,
            location=(ox + arm_x, oy - 0.055, oz + 0.92),
            material=arm_panel, bevel=False)
        parts[f'hand_{side}'] = create_box(
            f"{name}_Hand{side}", 0.07, 0.04, 0.10,
            location=(ox + arm_x, oy, oz + 0.72),
            material=dark_metal)

    # --- Legs ---
    for side, sx in [('L', 1), ('R', -1)]:
        leg_x = sx * 0.12
        bpy.ops.mesh.primitive_uv_sphere_add(
            radius=0.055, segments=12, ring_count=8,
            location=(ox + leg_x, oy, oz + 0.88))
        hj = bpy.context.active_object
        hj.name = f"{name}_HipJoint{side}"
        select_object(hj); bpy.ops.object.shade_smooth()
        apply_material(hj, joint_mat)
        parts[f'hip_joint_{side}'] = hj

        parts[f'upper_leg_{side}'] = create_box(
            f"{name}_UpperLeg{side}", 0.12, 0.12, 0.35,
            location=(ox + leg_x, oy, oz + 0.55), material=chrome)

        bpy.ops.mesh.primitive_uv_sphere_add(
            radius=0.05, segments=12, ring_count=8,
            location=(ox + leg_x, oy, oz + 0.50))
        kj = bpy.context.active_object
        kj.name = f"{name}_KneeJoint{side}"
        select_object(kj); bpy.ops.object.shade_smooth()
        apply_material(kj, joint_mat)
        parts[f'knee_joint_{side}'] = kj

        parts[f'lower_leg_{side}'] = create_box(
            f"{name}_LowerLeg{side}", 0.10, 0.10, 0.38,
            location=(ox + leg_x, oy, oz + 0.26), material=chrome)
        parts[f'knee_accent_{side}'] = create_box(
            f"{name}_KneeAccent{side}", 0.11, 0.02, 0.02,
            location=(ox + leg_x, oy - 0.06, oz + 0.50),
            material=accent_mat, bevel=False)
        parts[f'foot_{side}'] = create_box(
            f"{name}_Foot{side}", 0.10, 0.16, 0.06,
            location=(ox + leg_x, oy - 0.03, oz + 0.03),
            material=dark_metal)

    # --- Shoulder armor ---
    for side, sx in [('L', 1), ('R', -1)]:
        parts[f'shoulder_plate_{side}'] = create_box(
            f"{name}_ShoulderPlate{side}", 0.16, 0.14, 0.06,
            location=(ox + sx * 0.30, oy, oz + 1.50),
            material=chrome)

    # --- Chest accent lines ---
    for i, cz in enumerate([1.38, 1.28, 1.18]):
        parts[f'chest_line_{i}'] = create_box(
            f"{name}_ChestLine{i}", 0.36, 0.02, 0.01,
            location=(ox, oy - 0.12, oz + cz),
            material=accent_mat, bevel=False)

    # --- Back panel ---
    try:
        back_mat = make_pbr_material(f"{name}_BackPanel",
                                     texture_id='scifi_panel_mesh_grey')
    except Exception:
        back_mat = dark_metal
    parts['back_panel'] = create_box(f"{name}_BackPanel", 0.30, 0.02, 0.20,
                                     location=(ox, oy + 0.12, oz + 1.25),
                                     material=back_mat, bevel=False)

    # --- Parent all parts to armature bones ---
    bone_map = {
        'head': 'Head', 'visor': 'Head', 'eye_L': 'Head', 'eye_R': 'Head',
        'neck': 'Neck',
        'chest': 'Chest', 'reactor': 'Chest', 'abdomen': 'Spine',
        'back_panel': 'Chest',
        'chest_line_0': 'Chest', 'chest_line_1': 'Chest',
        'chest_line_2': 'Chest',
        'hips': 'Hips',
        'shoulder_joint_L': 'L_Shoulder', 'shoulder_joint_R': 'R_Shoulder',
        'shoulder_plate_L': 'L_Shoulder', 'shoulder_plate_R': 'R_Shoulder',
        'upper_arm_L': 'L_UpperArm', 'upper_arm_R': 'R_UpperArm',
        'elbow_joint_L': 'L_LowerArm', 'elbow_joint_R': 'R_LowerArm',
        'lower_arm_L': 'L_LowerArm', 'lower_arm_R': 'R_LowerArm',
        'arm_panel_L': 'L_LowerArm', 'arm_panel_R': 'R_LowerArm',
        'hand_L': 'L_Hand', 'hand_R': 'R_Hand',
        'hip_joint_L': 'L_UpperLeg', 'hip_joint_R': 'R_UpperLeg',
        'upper_leg_L': 'L_UpperLeg', 'upper_leg_R': 'R_UpperLeg',
        'knee_joint_L': 'L_LowerLeg', 'knee_joint_R': 'R_LowerLeg',
        'knee_accent_L': 'L_LowerLeg', 'knee_accent_R': 'R_LowerLeg',
        'lower_leg_L': 'L_LowerLeg', 'lower_leg_R': 'R_LowerLeg',
        'foot_L': 'L_Foot', 'foot_R': 'R_Foot',
    }
    for part_key, bone_name in bone_map.items():
        if part_key in parts:
            _parent_to_bone(parts[part_key], armature, bone_name)

    # --- Pose ---
    bpy.context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode='POSE')
    if pose == 'guard':
        pb = armature.pose.bones
        if 'L_Shoulder' in pb:
            pb['L_Shoulder'].rotation_euler = (0, 0, math.radians(-15))
        if 'L_UpperArm' in pb:
            pb['L_UpperArm'].rotation_euler = (math.radians(10), 0, 0)
        if 'R_Shoulder' in pb:
            pb['R_Shoulder'].rotation_euler = (0, 0, math.radians(15))
        if 'R_UpperArm' in pb:
            pb['R_UpperArm'].rotation_euler = (math.radians(-30), 0, 0)
        if 'R_LowerArm' in pb:
            pb['R_LowerArm'].rotation_euler = (math.radians(-40), 0, 0)
        if 'Head' in pb:
            pb['Head'].rotation_euler = (0, 0, math.radians(-8))
    elif pose == 'wave':
        pb = armature.pose.bones
        if 'R_Shoulder' in pb:
            pb['R_Shoulder'].rotation_euler = (0, 0, math.radians(10))
        if 'R_UpperArm' in pb:
            pb['R_UpperArm'].rotation_euler = (math.radians(-120), 0, 0)
        if 'R_LowerArm' in pb:
            pb['R_LowerArm'].rotation_euler = (math.radians(-30), 0, 0)
        if 'Head' in pb:
            pb['Head'].rotation_euler = (math.radians(10), 0, math.radians(-5))
    bpy.ops.object.mode_set(mode='OBJECT')

    # --- Studio Lighting ---
    key_light = add_point_light(
        (ox + 2, oy - 2, oz + 3), energy=300,
        color=(1.0, 0.95, 0.90), name=f"{name}_KeyLight")
    fill_light = add_point_light(
        (ox - 1.5, oy - 1, oz + 1.5), energy=100,
        color=(0.7, 0.8, 1.0), name=f"{name}_FillLight")
    rim_light = add_point_light(
        (ox, oy + 2, oz + 2), energy=200,
        color=(0.3, 0.7, 1.0), name=f"{name}_RimLight")

    # --- Studio floor ---
    studio_floor = make_material(f"{name}_StudioFloor", (0.02, 0.02, 0.03),
                                 metallic=0.3, roughness=0.1)
    ground = create_floor(f"{name}_Ground", width=6, depth=6,
                          location=(ox, oy, oz - 0.01),
                          material=studio_floor)

    # --- Dark environment ---
    setup_dark_environment(bg_color=(0.01, 0.012, 0.02), bg_strength=0.05)

    # --- Camera ---
    cam = add_camera(
        location=(ox + 1.2, oy - 2.0, oz + 1.2),
        target=(ox, oy, oz + 1.1),
        focal_length=50,
    )
    setup_camera_dof(cam, focus_distance=2.5, f_stop=4.0)

    total = len(bpy.data.objects)
    bone_count = len(arm_data.bones)
    print(f"Robot character built: {total} objects, {bone_count} bones, "
          f"pose='{pose}'")

    return {
        'armature': armature,
        'body_parts': parts,
        'lights': [key_light, fill_light, rim_light],
        'ground': ground, 'camera': cam,
    }


# ---------------------------------------------------------------------------
# FBX Import (Mixamo support)
# ---------------------------------------------------------------------------

_TOOLKIT_DIR = os.path.dirname(os.path.abspath(__file__))


def import_fbx(filepath, scale=1.0):
    """Import an FBX file into the current scene.

    Args:
        filepath: Absolute path to the .fbx file.
        scale: Import scale factor.

    Returns:
        List of imported objects.
    """
    before = set(bpy.data.objects)
    bpy.ops.import_scene.fbx(filepath=filepath, global_scale=scale)
    after = set(bpy.data.objects)
    imported = list(after - before)
    print(f"Imported FBX: {len(imported)} objects from {os.path.basename(filepath)}")
    return imported


def import_mixamo_character(fbx_path=None):
    """Import a Mixamo character FBX and return armature + meshes.

    The FBX contains its own internal scale (0.01) and axis rotation.
    This function imports, applies transforms, and returns a properly
    scaled ~1.7m tall character standing upright at the origin.

    Args:
        fbx_path: Path to character.fbx. Defaults to toolkit directory.

    Returns:
        dict with 'armature', 'meshes', 'bones'.
    """
    if fbx_path is None:
        fbx_path = os.path.join(_TOOLKIT_DIR, 'character.fbx')

    imported = import_fbx(fbx_path, scale=1.0)

    armature = None
    meshes = []
    remove_list = []
    for obj in imported:
        if obj.type == 'ARMATURE':
            armature = obj
        elif obj.type == 'MESH' and obj.name != 'Cube':
            meshes.append(obj)
        elif obj.type in ('CAMERA', 'LIGHT') or (obj.type == 'MESH' and obj.name == 'Cube'):
            remove_list.append(obj)

    for obj in remove_list:
        bpy.data.objects.remove(obj, do_unlink=True)

    # Apply transforms on ALL imported objects (internal 0.01 scale + 90° X rotation)
    if armature:
        # Select armature and all children, apply transforms together
        bpy.ops.object.select_all(action='DESELECT')
        armature.select_set(True)
        for mesh in meshes:
            mesh.select_set(True)
        bpy.context.view_layer.objects.active = armature
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

    bones = []
    if armature:
        bones = [b.name for b in armature.data.bones]
        # Check character height from foot to head
        hips = armature.data.bones.get('mixamorig:Hips')
        head = armature.data.bones.get('mixamorig:HeadTop_End')
        if hips and head:
            height = head.head_local.z - 0  # from ground
            print(f"Mixamo character: {len(bones)} bones, height≈{height:.2f}m")
        else:
            print(f"Mixamo armature: {len(bones)} bones")

    return {'armature': armature, 'meshes': meshes, 'bones': bones}


def apply_mixamo_animation(armature, anim_fbx_path=None, scale=1.0):
    """Apply a Mixamo animation FBX to an existing armature.

    Args:
        armature: The target armature object (from import_mixamo_character).
        anim_fbx_path: Path to animation .fbx. Defaults to walk.fbx in toolkit dir.
        scale: Scale factor matching the character import.

    Returns:
        The animation Action object.
    """
    if anim_fbx_path is None:
        anim_fbx_path = os.path.join(_TOOLKIT_DIR, 'walk.fbx')

    before_actions = set(bpy.data.actions)
    imported = import_fbx(anim_fbx_path, scale=scale)

    # Find the new action
    after_actions = set(bpy.data.actions)
    new_actions = list(after_actions - before_actions)

    # Find the imported armature and steal its action
    anim_armature = None
    for obj in imported:
        if obj.type == 'ARMATURE':
            anim_armature = obj
            break

    action = None
    if anim_armature and anim_armature.animation_data:
        action = anim_armature.animation_data.action
    elif new_actions:
        action = new_actions[0]

    # Apply action to our character's armature
    if action and armature:
        if not armature.animation_data:
            armature.animation_data_create()
        armature.animation_data.action = action
        print(f"Applied animation: {action.name} ({len(action.fcurves)} channels, "
              f"frames {action.frame_range[0]:.0f}-{action.frame_range[1]:.0f})")

    # Clean up imported objects (collect names first to avoid StructRNA issues)
    keep_names = set()
    if armature:
        keep_names.add(armature.name)
        for child in armature.children:
            keep_names.add(child.name)

    to_remove = []
    for obj in imported:
        try:
            if obj.name not in keep_names:
                to_remove.append(obj)
        except ReferenceError:
            pass

    for obj in to_remove:
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
        except Exception:
            pass

    return action


# ---------------------------------------------------------------------------
# Improved tree with organic canopy
# ---------------------------------------------------------------------------

def add_organic_tree(name="Tree", location=(0, 0, 0),
                     trunk_height=2.5, trunk_radius=0.12,
                     canopy_radius=1.8, canopy_style='sphere',
                     noise_strength=0.4, seed=0):
    """Create a tree with organic-looking displaced canopy.

    Unlike add_simple_tree, this displaces canopy vertices with noise
    for a natural, non-geometric appearance.

    Args:
        name: Object name prefix.
        location: (x, y, z) base position.
        trunk_height: Trunk height.
        trunk_radius: Trunk radius.
        canopy_radius: Base foliage radius.
        canopy_style: 'sphere' or 'cone'.
        noise_strength: How much to displace vertices (0=perfect shape).
        seed: Random seed for reproducible noise.

    Returns:
        dict with 'trunk' and 'canopy'.
    """
    import random
    rng = random.Random(seed)

    x, y, z = location
    try:
        bark_mat = make_pbr_material(f"{name}_Bark",
                                      texture_id='nature_bark_tree_seamless')
    except Exception:
        bark_mat = make_material(f"{name}_Bark", (0.28, 0.18, 0.08),
                                 roughness=0.95)

    # Multi-tone leaf material with subsurface hint
    leaf_mat = bpy.data.materials.new(f"{name}_Leaf")
    leaf_mat.use_nodes = True
    nodes = leaf_mat.node_tree.nodes
    links = leaf_mat.node_tree.links
    bsdf = nodes.get('Principled BSDF')
    bsdf.inputs['Base Color'].default_value = (0.12, 0.32, 0.08, 1.0)
    bsdf.inputs['Roughness'].default_value = 0.85
    bsdf.inputs['Subsurface'].default_value = 0.1
    bsdf.inputs['Subsurface Color'].default_value = (0.2, 0.5, 0.1, 1.0)
    # Add color variation via noise
    noise = nodes.new('ShaderNodeTexNoise')
    noise.location = (-400, 0)
    noise.inputs['Scale'].default_value = 3.0
    noise.inputs['Detail'].default_value = 4.0
    cr = nodes.new('ShaderNodeValToRGB')
    cr.location = (-200, 0)
    cr.color_ramp.elements[0].color = (0.08, 0.25, 0.05, 1.0)
    cr.color_ramp.elements[1].color = (0.18, 0.42, 0.12, 1.0)
    links.new(noise.outputs['Fac'], cr.inputs['Fac'])
    links.new(cr.outputs['Color'], bsdf.inputs['Base Color'])

    # Trunk
    trunk = create_cylinder(f"{name}_Trunk", trunk_radius, trunk_height,
                            location=(x, y, z), material=bark_mat)

    # Canopy — higher subdivision for displacement
    canopy_z = z + trunk_height + canopy_radius * 0.4
    if canopy_style == 'cone':
        bpy.ops.mesh.primitive_cone_add(
            radius1=canopy_radius, radius2=0.15,
            depth=canopy_radius * 2.2, vertices=24,
            location=(x, y, canopy_z))
    else:
        bpy.ops.mesh.primitive_ico_sphere_add(
            radius=canopy_radius, subdivisions=3,
            location=(x, y, canopy_z))

    canopy = bpy.context.active_object
    canopy.name = f"{name}_Canopy"

    # Displace vertices with noise for organic shape
    bm = bmesh.new()
    bm.from_mesh(canopy.data)
    for v in bm.verts:
        # Random displacement along the vertex normal
        offset = rng.gauss(0, noise_strength)
        v.co += v.normal * offset
    bm.to_mesh(canopy.data)
    bm.free()

    select_object(canopy)
    bpy.ops.object.shade_smooth()
    apply_material(canopy, leaf_mat)

    return {'trunk': trunk, 'canopy': canopy}


# ---------------------------------------------------------------------------
# Rigged Robot Scene — custom box robot on Mixamo skeleton
# ---------------------------------------------------------------------------

def _parent_mesh_to_bone(mesh_obj, armature, bone_name):
    """Parent a mesh object to a bone, keeping its current world position.

    Uses matrix_parent_inverse to prevent position jump when parenting.
    """
    bone = armature.data.bones[bone_name]
    mesh_obj.parent = armature
    mesh_obj.parent_type = 'BONE'
    mesh_obj.parent_bone = bone_name
    bone_mat = armature.matrix_world @ bone.matrix_local
    mesh_obj.matrix_parent_inverse = bone_mat.inverted()


def _make_robot_part(name, shape, size, location, material, bevel=True):
    """Create a single robot body part mesh at a world position.

    Args:
        name: Object name.
        shape: 'cube', 'cylinder', or 'sphere'.
        size: (sx, sy, sz) scale for cube, (radius, height) for cylinder.
        location: (x, y, z) world position (center of part).
        material: Blender material to apply.
        bevel: Add bevel modifier for smooth edges.

    Returns:
        The mesh object.
    """
    x, y, z = location
    if shape == 'cube':
        bpy.ops.mesh.primitive_cube_add(size=1, location=(x, y, z))
        obj = bpy.context.active_object
        obj.name = name
        obj.scale = size
    elif shape == 'cylinder':
        radius, height = size[0], size[1]
        bpy.ops.mesh.primitive_cylinder_add(
            radius=radius, depth=height, location=(x, y, z))
        obj = bpy.context.active_object
        obj.name = name
    elif shape == 'sphere':
        bpy.ops.mesh.primitive_uv_sphere_add(
            radius=size[0], location=(x, y, z))
        obj = bpy.context.active_object
        obj.name = name
    else:
        return None

    bpy.ops.object.transform_apply(scale=True)

    if bevel and shape == 'cube':
        bev = obj.modifiers.new('Bevel', 'BEVEL')
        bev.width = 0.008
        bev.segments = 2
        bev.limit_method = 'ANGLE'

    bpy.ops.object.shade_smooth()
    apply_material(obj, material)
    return obj


def build_rigged_robot(name="OnyxBot", walk_fbx=None, apply_walk=True,
                       frame=16):
    """Build a heavy mech robot rigged to Mixamo skeleton with walk animation.

    v6 — single massive torso, gunmetal materials, fewer but larger pieces,
    military mech proportions with thick limbs and overlapping armor.

    Args:
        name: Scene name prefix.
        walk_fbx: Path to walk.fbx animation. Defaults to toolkit dir.
        apply_walk: Whether to apply walk animation.
        frame: Which animation frame to pose at (mid-stride = 16).

    Returns:
        dict with 'armature', 'parts', 'lights', 'camera', 'action'.
    """
    clear_scene()
    setup_scene()

    # --- 1. Import Mixamo skeleton (NO transform_apply) ---
    char_path = os.path.join(_TOOLKIT_DIR, 'character.fbx')
    imported = import_fbx(char_path, scale=1.0)

    armature = None
    for obj in imported:
        if obj.type == 'ARMATURE':
            armature = obj
        else:
            bpy.data.objects.remove(obj, do_unlink=True)

    if not armature:
        print("ERROR: No armature found in character.fbx")
        return {}

    bpy.context.view_layer.update()

    # Bone helpers
    def bw(bn):
        return armature.matrix_world @ armature.data.bones[bn].head_local

    def bt(bn):
        return armature.matrix_world @ armature.data.bones[bn].tail_local

    def bmid(bn):
        return (bw(bn) + bt(bn)) / 2

    def blen(bn):
        return (bt(bn) - bw(bn)).length

    def part(pname, shape, size, loc, mat, bone, bevel=True):
        obj = _make_robot_part(f"{name}_{pname}", shape, size, loc, mat, bevel)
        _parent_mesh_to_bone(obj, armature, bone)
        return obj

    # --- 2. MATERIALS — gunmetal palette, not pure chrome ---
    # Primary: gunmetal grey (less reflective than chrome)
    gunmetal = make_material(f"{name}_Gunmetal", (0.22, 0.24, 0.26),
                              metallic=0.85, roughness=0.28)
    # Secondary: dark charcoal
    charcoal = make_material(f"{name}_Charcoal", (0.06, 0.06, 0.08),
                              metallic=0.8, roughness=0.4)
    # Highlight: lighter steel for accent plates
    steel = make_material(f"{name}_Steel", (0.55, 0.57, 0.60),
                           metallic=0.9, roughness=0.15)
    # Joint rubber: matte black
    rubber = make_material(f"{name}_Rubber", (0.02, 0.02, 0.02),
                            metallic=0.0, roughness=0.85)
    # Neon cyan
    neon = bpy.data.materials.new(f"{name}_Neon")
    neon.use_nodes = True
    nb = neon.node_tree.nodes.get('Principled BSDF')
    nb.inputs['Emission'].default_value = (0.0, 0.7, 1.0, 1.0)
    nb.inputs['Emission Strength'].default_value = 25.0
    nb.inputs['Base Color'].default_value = (0.0, 0.4, 0.9, 1.0)
    # Warn orange
    warn = bpy.data.materials.new(f"{name}_Warn")
    warn.use_nodes = True
    wnb = warn.node_tree.nodes.get('Principled BSDF')
    wnb.inputs['Emission'].default_value = (1.0, 0.5, 0.0, 1.0)
    wnb.inputs['Emission Strength'].default_value = 12.0

    parts = []
    P = parts.append

    # ===================================================================
    # 3. BUILD MECH BODY — fewer, massive pieces
    # ===================================================================

    # Key positions
    hip_z = bw('mixamorig:Hips').z         # ~0.998
    neck_z = bw('mixamorig:Neck').z        # ~1.498
    head_top_z = bt('mixamorig:Head').z    # ~1.797
    s1_mid = bmid('mixamorig:Spine1')

    # ---------- SINGLE MASSIVE TORSO on Spine1 ----------
    # Spans from below hips to above neck — one monolithic piece
    torso_z = (hip_z + neck_z) / 2
    torso_h = (neck_z - hip_z) + 0.10  # extra overlap top and bottom
    P(part('Torso', 'cube', (0.38, 0.20, torso_h),
           (s1_mid.x, s1_mid.y, torso_z),
           gunmetal, 'mixamorig:Spine1'))

    # Chest front plate (lighter steel accent)
    P(part('ChestFront', 'cube', (0.26, 0.015, 0.22),
           (s1_mid.x, s1_mid.y - 0.108, neck_z - 0.16),
           steel, 'mixamorig:Spine1'))

    # Chest reactor
    reactor = _make_robot_part(f"{name}_Reactor", 'cylinder',
                                (0.05, 0.018),
                                (s1_mid.x, s1_mid.y - 0.108, neck_z - 0.18), neon)
    reactor.rotation_euler.x = 1.5708
    _parent_mesh_to_bone(reactor, armature, 'mixamorig:Spine1')
    P(reactor)

    # Horizontal neon line across chest
    P(part('ChestLine', 'cube', (0.22, 0.004, 0.010),
           (s1_mid.x, s1_mid.y - 0.108, neck_z - 0.25),
           neon, 'mixamorig:Spine1', bevel=False))

    # Belly recessed panel
    P(part('BellyPanel', 'cube', (0.18, 0.012, 0.12),
           (s1_mid.x, s1_mid.y - 0.107, (hip_z + neck_z) / 2 - 0.05),
           charcoal, 'mixamorig:Spine1', bevel=False))

    # Back plate (thicker for backpack/exhaust look)
    P(part('BackPack', 'cube', (0.24, 0.08, 0.28),
           (s1_mid.x, s1_mid.y + 0.14, neck_z - 0.18),
           charcoal, 'mixamorig:Spine1'))

    # Hip skirt armor — extends down past hips for overlap with thighs
    for sx, lab in [(0.16, 'L'), (-0.16, 'R')]:
        P(part(f'HipSkirt{lab}', 'cube', (0.10, 0.16, 0.16),
               (s1_mid.x + sx, s1_mid.y, hip_z - 0.04),
               gunmetal, 'mixamorig:Spine1'))

    # ---------- NECK / COLLAR ----------
    n_mid = bmid('mixamorig:Neck')
    # Thick neck cylinder
    P(part('Neck', 'cylinder', (0.08, 0.14),
           n_mid, rubber, 'mixamorig:Neck'))
    # Collar ring overlapping torso top and head bottom
    P(part('Collar', 'cylinder', (0.15, 0.08),
           (n_mid.x, n_mid.y, n_mid.z),
           charcoal, 'mixamorig:Neck'))

    # ---------- HEAD ----------
    h_mid = bmid('mixamorig:Head')
    h_len = blen('mixamorig:Head')
    # Helmet — extends down to overlap collar
    P(part('Head', 'cube', (0.20, 0.22, h_len * 0.90),
           (h_mid.x, h_mid.y, h_mid.z - 0.03), gunmetal, 'mixamorig:Head'))
    # Face plate (darker recessed front)
    P(part('FacePlate', 'cube', (0.16, 0.012, h_len * 0.45),
           (h_mid.x, h_mid.y - 0.111, h_mid.z - 0.01),
           charcoal, 'mixamorig:Head', bevel=False))
    # Visor — wide neon slit
    P(part('Visor', 'cube', (0.15, 0.008, 0.030),
           (h_mid.x, h_mid.y - 0.112, h_mid.z + 0.01),
           neon, 'mixamorig:Head', bevel=False))
    # Antenna
    P(part('Antenna', 'cylinder', (0.007, 0.07),
           (h_mid.x + 0.06, h_mid.y, h_mid.z + h_len * 0.45),
           charcoal, 'mixamorig:Head'))
    P(part('AntTip', 'sphere', (0.01,),
           (h_mid.x + 0.06, h_mid.y, h_mid.z + h_len * 0.45 + 0.04),
           warn, 'mixamorig:Head'))

    # ========== ARMS ==========
    for side, pfx in [('Left', 'L'), ('Right', 'R')]:
        sign = 1 if side == 'Left' else -1

        # Shoulder pauldron — massive, overlaps torso and upper arm
        sh_mid = bmid(f'mixamorig:{side}Shoulder')
        sh_len = blen(f'mixamorig:{side}Shoulder')
        P(part(f'Pauldron{pfx}', 'cube', (sh_len * 1.8, 0.18, 0.14),
               (sh_mid.x + sign * 0.04, sh_mid.y, sh_mid.z + 0.02),
               steel, f'mixamorig:{side}Shoulder'))
        # Pauldron top neon edge
        P(part(f'PauldEdge{pfx}', 'cube', (sh_len * 1.4, 0.14, 0.012),
               (sh_mid.x + sign * 0.04, sh_mid.y, sh_mid.z + 0.09),
               neon, f'mixamorig:{side}Shoulder', bevel=False))

        # Shoulder ball joint
        sj = bw(f'mixamorig:{side}Arm')
        P(part(f'ShJoint{pfx}', 'sphere', (0.075,),
               sj, rubber, f'mixamorig:{side}Arm'))

        # UPPER ARM — full bone length, thick
        ua_mid = bmid(f'mixamorig:{side}Arm')
        ua_len = blen(f'mixamorig:{side}Arm')
        P(part(f'UpperArm{pfx}', 'cube', (ua_len * 1.05, 0.12, 0.13),
               ua_mid, gunmetal, f'mixamorig:{side}Arm'))

        # Elbow ball joint
        elb = bw(f'mixamorig:{side}ForeArm')
        P(part(f'Elbow{pfx}', 'sphere', (0.068,),
               elb, rubber, f'mixamorig:{side}ForeArm'))

        # FOREARM — full bone length, slightly wider (gauntlet)
        fa_mid = bmid(f'mixamorig:{side}ForeArm')
        fa_len = blen(f'mixamorig:{side}ForeArm')
        P(part(f'ForeArm{pfx}', 'cube', (fa_len * 1.05, 0.13, 0.14),
               fa_mid, gunmetal, f'mixamorig:{side}ForeArm'))
        # Forearm neon stripe
        P(part(f'FALine{pfx}', 'cube', (fa_len * 0.6, 0.004, 0.010),
               (fa_mid.x, fa_mid.y - 0.066, fa_mid.z),
               neon, f'mixamorig:{side}ForeArm', bevel=False))

        # HAND — chunky fist
        hd_mid = bmid(f'mixamorig:{side}Hand')
        hd_len = blen(f'mixamorig:{side}Hand')
        P(part(f'Hand{pfx}', 'cube', (hd_len * 1.4, 0.08, 0.10),
               hd_mid, charcoal, f'mixamorig:{side}Hand'))

    # ========== LEGS ==========
    for side, pfx in [('Left', 'L'), ('Right', 'R')]:
        sign = 1 if side == 'Left' else -1

        # Hip ball joint
        hj = bw(f'mixamorig:{side}UpLeg')
        P(part(f'HipJoint{pfx}', 'sphere', (0.08,),
               hj, rubber, f'mixamorig:{side}UpLeg'))

        # THIGH — massive, full bone length
        th_mid = bmid(f'mixamorig:{side}UpLeg')
        th_len = blen(f'mixamorig:{side}UpLeg')
        P(part(f'Thigh{pfx}', 'cube', (0.14, 0.14, th_len * 1.0),
               th_mid, gunmetal, f'mixamorig:{side}UpLeg'))
        # Thigh outer armor plate
        P(part(f'ThighPlate{pfx}', 'cube', (0.04, 0.11, th_len * 0.75),
               (th_mid.x + sign * 0.07, th_mid.y, th_mid.z),
               steel, f'mixamorig:{side}UpLeg'))
        # Thigh neon
        P(part(f'ThighNeon{pfx}', 'cube', (0.008, 0.005, th_len * 0.5),
               (th_mid.x + sign * 0.071, th_mid.y - 0.056, th_mid.z),
               neon, f'mixamorig:{side}UpLeg', bevel=False))

        # Knee ball joint
        kn = bw(f'mixamorig:{side}Leg')
        P(part(f'Knee{pfx}', 'sphere', (0.078,),
               kn, rubber, f'mixamorig:{side}Leg'))
        # Knee guard
        P(part(f'KneeGuard{pfx}', 'cube', (0.11, 0.04, 0.12),
               (kn.x, kn.y - 0.07, kn.z), steel, f'mixamorig:{side}Leg'))

        # SHIN — full bone length
        sn_mid = bmid(f'mixamorig:{side}Leg')
        sn_len = blen(f'mixamorig:{side}Leg')
        P(part(f'Shin{pfx}', 'cube', (0.12, 0.13, sn_len * 1.0),
               sn_mid, gunmetal, f'mixamorig:{side}Leg'))
        # Shin front plate
        P(part(f'ShinPlate{pfx}', 'cube', (0.08, 0.03, sn_len * 0.8),
               (sn_mid.x, sn_mid.y - 0.08, sn_mid.z),
               steel, f'mixamorig:{side}Leg'))
        # Shin neon
        P(part(f'ShinNeon{pfx}', 'cube', (0.008, 0.005, sn_len * 0.5),
               (sn_mid.x, sn_mid.y - 0.096, sn_mid.z),
               neon, f'mixamorig:{side}Leg', bevel=False))

        # Ankle
        ank = bw(f'mixamorig:{side}Foot')
        P(part(f'Ankle{pfx}', 'cylinder', (0.065, 0.08),
               ank, rubber, f'mixamorig:{side}Foot'))

        # FOOT — big armored boot
        ft_mid = bmid(f'mixamorig:{side}Foot')
        ft_len = blen(f'mixamorig:{side}Foot')
        P(part(f'Foot{pfx}', 'cube', (0.13, ft_len * 1.3, 0.07),
               (ft_mid.x, ft_mid.y, ft_mid.z + 0.01),
               gunmetal, f'mixamorig:{side}Foot'))
        # Toe guard
        toe = bw(f'mixamorig:{side}ToeBase')
        P(part(f'Toe{pfx}', 'cube', (0.11, 0.07, 0.06),
               (toe.x, toe.y - 0.01, toe.z + 0.01),
               steel, f'mixamorig:{side}ToeBase'))

    print(f"Mech body: {len(parts)} parts built and rigged to 65-bone skeleton")

    # --- 4. Walk animation ---
    action = None
    if apply_walk:
        if walk_fbx is None:
            walk_fbx = os.path.join(_TOOLKIT_DIR, 'walk.fbx')
        walk_imported = import_fbx(walk_fbx, scale=1.0)
        walk_arm = None
        for obj in walk_imported:
            if obj.type == 'ARMATURE':
                walk_arm = obj
        if walk_arm and walk_arm.animation_data and walk_arm.animation_data.action:
            action = walk_arm.animation_data.action
            if not armature.animation_data:
                armature.animation_data_create()
            armature.animation_data.action = action
            print(f"Walk: {len(action.fcurves)} fcurves, "
                  f"frames {action.frame_range[0]:.0f}-{action.frame_range[1]:.0f}")
        for obj in walk_imported:
            try:
                bpy.data.objects.remove(obj, do_unlink=True)
            except ReferenceError:
                pass
        bpy.context.scene.frame_set(frame)

    # --- 5. Studio Lighting (cinematic) ---
    setup_dark_environment(bg_color=(0.005, 0.007, 0.012), bg_strength=0.03)

    key = add_area_light(
        location=(2.5, -2.5, 3.5), energy=1000,
        color=(1.0, 0.95, 0.88), size=2.5, name=f"{name}_Key")
    key.rotation_euler = (0.7, 0.3, -0.4)
    fill = add_area_light(
        location=(-2.5, -0.5, 1.5), energy=300,
        color=(0.5, 0.6, 0.9), size=2.0, name=f"{name}_Fill")
    fill.rotation_euler = (0.9, -0.4, 0.5)
    rim = add_point_light(
        (0.3, 3.5, 2.5), energy=600,
        color=(0.15, 0.5, 1.0), name=f"{name}_Rim")
    ground_glow = add_point_light(
        (0, -0.3, 0.03), energy=25,
        color=(0.0, 0.6, 1.0), name=f"{name}_GndGlow")

    # Studio floor — dark reflective
    floor_mat = make_material(f"{name}_Floor", (0.01, 0.01, 0.015),
                              metallic=0.5, roughness=0.06)
    ground = create_floor(f"{name}_Ground", width=10, depth=10,
                          location=(0, 0, -0.01), material=floor_mat)

    # Camera — hero angle, full body
    cam = add_camera(
        location=(2.0, -3.5, 0.9),
        target=(0, 0, 0.9),
        focal_length=55)
    setup_camera_dof(cam, focus_distance=4.2, f_stop=5.6)

    total = len(bpy.data.objects)
    print(f"Mech scene: {total} objects, {len(parts)} body parts, "
          f"walk={'frame ' + str(frame) if action else 'none'}")

    return {
        'armature': armature, 'parts': parts, 'action': action,
        'lights': [key, fill, rim, ground_glow],
        'ground': ground, 'camera': cam,
    }


# ---------------------------------------------------------------------------
# SAC Asset Library Loader
# ---------------------------------------------------------------------------

def _load_library_asset(blend_path, collection_name="Asset",
                        location=(0, 0, 0), rotation_z=0.0, scale=1.0):
    """Load an asset from the SAC asset library into the current scene.

    Appends the asset collection from a .blend file and positions it.

    Args:
        blend_path: Path to the asset .blend file.
        collection_name: Name of the collection inside the .blend.
        location: (x, y, z) placement position.
        rotation_z: Z-axis rotation in radians.
        scale: Uniform scale factor (1.0 = original 1:1 size).

    Returns:
        The linked collection, or list of linked objects.
    """
    with bpy.data.libraries.load(blend_path, link=False) as (data_from, data_to):
        if collection_name in data_from.collections:
            data_to.collections = [collection_name]
        else:
            data_to.objects = data_from.objects

    linked = []
    if data_to.collections:
        for coll in data_to.collections:
            if coll is not None:
                bpy.context.scene.collection.children.link(coll)
                for obj in coll.all_objects:
                    obj.location.x += location[0]
                    obj.location.y += location[1]
                    obj.location.z += location[2]
                    obj.rotation_euler.z += rotation_z
                    if scale != 1.0:
                        obj.scale *= scale
                linked.append(coll)
    elif data_to.objects:
        for obj in data_to.objects:
            if obj is not None:
                bpy.context.collection.objects.link(obj)
                obj.location = Vector(location)
                obj.rotation_euler.z = rotation_z
                if scale != 1.0:
                    obj.scale *= scale
                linked.append(obj)

    return linked


def load_library_asset(asset_id, location=(0, 0, 0), rotation_z=0.0, scale=1.0):
    """Load an asset from the SAC library by its ID.

    Searches the library manifest for the asset and appends it.

    Args:
        asset_id: Asset identifier (e.g., 'dining_chair_modern_01').
        location: (x, y, z) placement.
        rotation_z: Z rotation in radians.
        scale: Uniform scale (1.0 = original 1:1).

    Returns:
        The linked collection or objects, or None if not found.
    """
    _sac_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "asset_library")
    manifest_path = os.path.join(_sac_dir, "manifest.json")

    if not os.path.exists(manifest_path):
        print(f"[SAC] No asset library found at {manifest_path}")
        return None

    with open(manifest_path, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    entry = manifest.get("assets", {}).get(asset_id)
    if not entry:
        print(f"[SAC] Asset '{asset_id}' not found in library")
        return None

    blend_path = os.path.join(_sac_dir, "blends", entry["blend_file"])
    if not os.path.exists(blend_path):
        print(f"[SAC] Blend file not found: {blend_path}")
        return None

    coll_name = entry.get("collection_name", "Asset")
    result = _load_library_asset(blend_path, coll_name,
                                 location, rotation_z, scale)
    print(f"[SAC] Loaded: {entry['name']} ({asset_id})")
    return result
