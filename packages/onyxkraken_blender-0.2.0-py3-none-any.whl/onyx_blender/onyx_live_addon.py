"""
OnyxKraken Live Build Addon for Blender.

This addon starts a TCP socket server inside Blender that listens for
Python scripts from OnyxKraken. When a script is received, it executes
inside Blender's main thread so the user can watch objects appear in real-time.

Installation:
    Edit > Preferences > Add-ons > Install > Select this file
    Or: Copy to Blender's addons folder and enable in preferences.

Usage from OnyxKraken:
    The orchestrator sends scripts to localhost:9876 when live_mode=true.
    Each message is: <4-byte length><utf8 script>
    Response is: <4-byte length><utf8 result>
"""

bl_info = {
    "name": "OnyxKraken Live Build",
    "author": "OnyxKraken",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Onyx",
    "description": "Receive and execute build scripts from OnyxKraken in real-time",
    "category": "Development",
}

import bpy
import threading
import socket
import struct
import traceback


_server_thread = None
_server_socket = None
_running = False
_PORT = 9876
_script_queue = []
_result_events = {}


def _server_loop():
    """Background thread: accept connections and queue scripts."""
    global _running, _server_socket
    _server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    _server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    _server_socket.settimeout(1.0)
    try:
        _server_socket.bind(('127.0.0.1', _PORT))
        _server_socket.listen(1)
        print(f"[Onyx Live] Server listening on port {_PORT}")
    except OSError as e:
        print(f"[Onyx Live] Failed to bind port {_PORT}: {e}")
        _running = False
        return

    while _running:
        try:
            conn, addr = _server_socket.accept()
        except socket.timeout:
            continue
        except OSError:
            break

        try:
            # Read 4-byte length header
            header = conn.recv(4)
            if len(header) < 4:
                conn.close()
                continue
            msg_len = struct.unpack('>I', header)[0]

            # Read script body
            data = b''
            while len(data) < msg_len:
                chunk = conn.recv(min(4096, msg_len - len(data)))
                if not chunk:
                    break
                data += chunk
            script = data.decode('utf-8')

            # Queue for main thread execution
            import threading
            event = threading.Event()
            result_holder = [None]
            _script_queue.append((script, event, result_holder))

            # Wait for main thread to execute (up to 120s)
            event.wait(timeout=120)
            result = result_holder[0] or "OK"

            # Send response
            resp = result.encode('utf-8')
            conn.sendall(struct.pack('>I', len(resp)) + resp)
        except Exception as e:
            try:
                err = f"ERROR: {e}".encode('utf-8')
                conn.sendall(struct.pack('>I', len(err)) + err)
            except Exception:
                pass
        finally:
            conn.close()

    if _server_socket:
        _server_socket.close()
    print("[Onyx Live] Server stopped")


def _process_queue():
    """Timer callback: execute queued scripts in Blender's main thread."""
    while _script_queue:
        script, event, result_holder = _script_queue.pop(0)
        try:
            # Execute the script
            exec(compile(script, '<onyx_live>', 'exec'), {'__builtins__': __builtins__})
            result_holder[0] = "OK"
        except Exception:
            result_holder[0] = traceback.format_exc()
        finally:
            event.set()

        # Force viewport redraw so user sees changes
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

    return 0.1  # Check again in 0.1s


class ONYX_OT_start_server(bpy.types.Operator):
    bl_idname = "onyx.start_live_server"
    bl_label = "Start Onyx Live Server"
    bl_description = "Start listening for build scripts from OnyxKraken"

    def execute(self, context):
        global _server_thread, _running
        if _running:
            self.report({'WARNING'}, "Server already running")
            return {'CANCELLED'}

        _running = True
        _server_thread = threading.Thread(target=_server_loop, daemon=True)
        _server_thread.start()
        bpy.app.timers.register(_process_queue)
        self.report({'INFO'}, f"Onyx Live server started on port {_PORT}")
        return {'FINISHED'}


class ONYX_OT_stop_server(bpy.types.Operator):
    bl_idname = "onyx.stop_live_server"
    bl_label = "Stop Onyx Live Server"
    bl_description = "Stop the OnyxKraken live build server"

    def execute(self, context):
        global _running, _server_socket
        _running = False
        if _server_socket:
            try:
                _server_socket.close()
            except Exception:
                pass
        try:
            bpy.app.timers.unregister(_process_queue)
        except Exception:
            pass
        self.report({'INFO'}, "Onyx Live server stopped")
        return {'FINISHED'}


class ONYX_PT_live_panel(bpy.types.Panel):
    bl_label = "OnyxKraken Live"
    bl_idname = "ONYX_PT_live_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Onyx"

    def draw(self, context):
        layout = self.layout
        if _running:
            layout.label(text=f"Listening on port {_PORT}", icon='LINKED')
            layout.operator("onyx.stop_live_server", icon='CANCEL')
        else:
            layout.label(text="Server stopped", icon='UNLINKED')
            layout.operator("onyx.start_live_server", icon='PLAY')


_classes = (
    ONYX_OT_start_server,
    ONYX_OT_stop_server,
    ONYX_PT_live_panel,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    global _running
    _running = False
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
