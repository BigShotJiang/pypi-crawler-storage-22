"""
Smart Asset Creator (SAC) — Photorealistic 1:1 scale asset pipeline for Blender.

Pipeline: create → quality check → iterate → approve → store in library

Modules:
    creator    — Asset creation pipeline (build → check → store)
    quality    — Gordon Ramsay quality checker (5 dimensions, weighted scoring)
    library    — Asset library manager (manifest, .blend storage, search/load)
    techniques — Advanced Blender modeling primitives (lathe, bevel, UV, etc.)
    memory     — Learning & knowledge base (lessons, adjustments, build history)
    builder    — Two build modes: Quick Build (fast draft) and Detailed Build (production)
    robot      — Detailed mechanical robot builder (Mixamo-compatible rig)
    research   — Self-troubleshooting via Edge browser

Build Modes:
    Quick Build (short-term):
        Fast scene assembly using existing assets + primitives.
        No quality gate. For rapid prototyping.

    Detailed Build (long-term):
        Builds each needed asset individually through full pipeline.
        Quality checks every asset. Stores in library for reuse.
        Consults learned lessons before each build.

Learning:
    Onyx learns from every build and every user correction.
    Lessons are stored in asset_library/knowledge/ and automatically
    injected into future builds of the same asset type.
"""
