"""SAC Builder — Two build modes for Onyx.

Quick Build (short-term):
  - Fast scene assembly using existing library assets + simple primitives
  - No quality gate, no library registration
  - For rapid prototyping, concept scenes, draft renders

Detailed Build (long-term):
  - Builds each needed asset individually through full SAC pipeline
  - Quality checks every asset (Gordon Ramsay treatment)
  - Stores approved assets in library for reuse
  - Assembles final scene from library assets
  - Consults learned lessons before each build
  - Records build history for future learning

Usage:
    from builder import quick_build, detailed_build

    # Fast draft
    quick_build("living_room", furniture=["sofa", "table", "lamp"])

    # Production quality
    detailed_build("living_room", assets_needed=[
        {"type": "sofa", "style": "modern", "id": "sofa_modern_01"},
        {"type": "coffee_table", "style": "walnut", "id": "coffee_table_walnut_01"},
    ])
"""

import os
import sys
import json
import time

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_TOOLKIT_DIR = os.path.dirname(_THIS_DIR)

if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)


# ═══════════════════════════════════════════════════════════════════
# QUICK BUILD — Fast scene assembly
# ═══════════════════════════════════════════════════════════════════

def quick_build(scene_name, scene_script, output_dir=None, render=True,
                resolution=1024):
    """Quick Build — assemble a scene fast using primitives and library assets.

    No quality gate. No library registration. Just build and render.

    Args:
        scene_name: Name for the scene (used in filenames).
        scene_script: Blender Python code for the scene. Can use:
            - All onyx_bpy functions (build_room, add_chair, etc.)
            - load_library_asset(asset_id, location, rotation_z)
            - All standard bpy operations
        output_dir: Where to save output (default: ~/OnyxProjects).
        render: Whether to render a preview.
        resolution: Render resolution.

    Returns:
        dict with 'blend_path', 'render_path', 'duration_s'.
    """
    try:
        from creator import run_blender_script, _find_blender
    except ImportError:
        from .creator import run_blender_script, _find_blender

    if output_dir is None:
        output_dir = os.path.join(os.path.expanduser("~"), "OnyxProjects")
    os.makedirs(output_dir, exist_ok=True)

    blend_path = os.path.join(output_dir, f"{scene_name}.blend").replace("\\", "/")
    render_path = os.path.join(output_dir, f"{scene_name}.png").replace("\\", "/")

    # Minimal header — import everything, set up scene
    header = f'''
import bpy
import bmesh
import math
import os
import sys
import json
from mathutils import Vector, Matrix

sys.path.insert(0, r"{_TOOLKIT_DIR}")
from onyx_bpy import *

clear_scene()
setup_scene()

print("[Quick Build] Starting: {scene_name}")
'''

    # Footer — save and optionally render
    footer = f'''

# Save
bpy.ops.wm.save_as_mainfile(filepath="{blend_path}")
print("[Quick Build] Saved: {blend_path}")
'''

    if render:
        footer += f'''
# Quick render setup
setup_cycles(samples=128, use_denoising=True)
setup_hdri_environment(strength=0.8)

# Auto-camera: find scene bounds
all_coords = []
for obj in bpy.data.objects:
    if obj.type == 'MESH':
        for corner in obj.bound_box:
            wc = obj.matrix_world @ Vector(corner)
            all_coords.append(wc)

if all_coords:
    cx = (max(c.x for c in all_coords) + min(c.x for c in all_coords)) / 2
    cy = (max(c.y for c in all_coords) + min(c.y for c in all_coords)) / 2
    max_z = max(c.z for c in all_coords)
    span = max(
        max(c.x for c in all_coords) - min(c.x for c in all_coords),
        max(c.y for c in all_coords) - min(c.y for c in all_coords),
    )
    dist = max(span, max_z) * 1.8
    target = (cx, cy, max_z * 0.4)
else:
    target, dist = (0, 0, 1), 5.0

cam = orbit_camera(target=target, distance=dist, elevation=30, azimuth=-35, focal_length=35)

# Quick lights
add_area_light(location=(dist, -dist, dist*0.8), energy=500, size=3.0, name="Key",
               rotation=(math.radians(55), 0, math.radians(40)))
add_area_light(location=(-dist*0.7, -dist*0.3, dist*0.5), energy=200, size=2.0, name="Fill",
               rotation=(math.radians(45), 0, math.radians(-25)))

scene = bpy.context.scene
scene.render.resolution_x = {resolution}
scene.render.resolution_y = {resolution}
scene.render.filepath = "{render_path}"
scene.render.image_settings.file_format = 'PNG'
bpy.ops.render.render(write_still=True)
print("[Quick Build] Rendered: {render_path}")
'''

    footer += '\nprint("[Quick Build] COMPLETE")\n'

    full_script = header + scene_script + footer

    print(f"\n[Quick Build] Building scene: {scene_name}")
    t0 = time.time()
    retcode, stdout, stderr = run_blender_script(full_script, timeout=300)
    duration = round(time.time() - t0, 1)

    success = retcode == 0 or "[Quick Build] COMPLETE" in stdout

    if not success:
        # Extract error
        for line in (stdout + "\n" + stderr).split("\n"):
            if "Error" in line or "Traceback" in line:
                print(f"  {line.strip()[:120]}")

    print(f"[Quick Build] {'Done' if success else 'FAILED'} in {duration}s")

    # Record in build history
    try:
        from memory import record_build
    except ImportError:
        from .memory import record_build
    record_build(
        asset_id=scene_name,
        name=scene_name,
        category="scene",
        asset_type="quick_build",
        quality_score=0,  # no quality check for quick builds
        passed=success,
        feedback=[],
        build_mode="quick",
        duration_s=duration,
    )

    return {
        "success": success,
        "blend_path": blend_path,
        "render_path": render_path if render else None,
        "duration_s": duration,
    }


# ═══════════════════════════════════════════════════════════════════
# DETAILED BUILD — Production-quality scene assembly
# ═══════════════════════════════════════════════════════════════════

def detailed_build(scene_name, assets_needed, assembly_script,
                   output_dir=None, render=True, resolution=1024,
                   max_retries=2):
    """Detailed Build — build every asset to quality, then assemble.

    Pipeline:
    1. For each asset needed:
       a. Check if it already exists in library (skip if so)
       b. Consult learned lessons for this asset type
       c. Create asset through full SAC pipeline (quality checked)
       d. Retry up to max_retries if quality fails
    2. Assemble scene using library assets
    3. Render final scene

    Args:
        scene_name: Name for the final scene.
        assets_needed: List of dicts, each with:
            - 'id': asset ID for library (e.g., 'dining_chair_modern_01')
            - 'type': asset type (e.g., 'dining_chair')
            - 'name': human name (e.g., 'Modern Dining Chair')
            - 'category': category (e.g., 'furniture')
            - 'subcategory': subcategory (e.g., 'seating')
            - 'tags': list of tags
            - 'build_script': Blender Python code to build this asset
        assembly_script: Blender Python code that assembles the scene.
            Uses load_library_asset(id, location, rotation_z) to place assets.
        output_dir: Output directory.
        render: Whether to render.
        resolution: Render resolution.
        max_retries: Max retries per asset on quality failure.

    Returns:
        dict with per-asset results, scene result, total duration.
    """
    try:
        from creator import create_asset
        from library import find_asset, get_asset_blend_path
        from memory import (get_lessons_for_build, format_lessons_as_comments,
                           record_build, learn_from_quality_feedback)
    except ImportError:
        from .creator import create_asset
        from .library import find_asset, get_asset_blend_path
        from .memory import (get_lessons_for_build, format_lessons_as_comments,
                            record_build, learn_from_quality_feedback)

    if output_dir is None:
        output_dir = os.path.join(os.path.expanduser("~"), "OnyxProjects")
    os.makedirs(output_dir, exist_ok=True)

    print("\n" + "=" * 60)
    print(f"  DETAILED BUILD: {scene_name}")
    print(f"  Assets needed: {len(assets_needed)}")
    print("=" * 60)

    t0 = time.time()
    asset_results = {}

    # ── Phase 1: Build individual assets ──────────────────────────
    for i, asset_spec in enumerate(assets_needed):
        asset_id = asset_spec["id"]
        asset_type = asset_spec.get("type", "")
        category = asset_spec.get("category", "furniture")

        print(f"\n--- Asset {i+1}/{len(assets_needed)}: {asset_id} ---")

        # Check if already in library
        existing = find_asset(asset_id)
        if existing:
            blend_exists = os.path.exists(get_asset_blend_path(asset_id))
            if blend_exists:
                print(f"  Already in library (score: {existing.get('quality_score', '?')})")
                asset_results[asset_id] = {
                    "status": "existing",
                    "quality_score": existing.get("quality_score", 0),
                }
                continue

        # Get learned lessons for this type
        lessons_comment = format_lessons_as_comments(category, asset_type)
        build_script = asset_spec.get("build_script", "")

        if lessons_comment:
            print(f"  Applying {lessons_comment.count('•')} learned rules")
            build_script = lessons_comment + build_script

        # Build with retries
        attempt = 0
        result = None
        while attempt <= max_retries:
            attempt += 1
            if attempt > 1:
                print(f"  Retry {attempt-1}/{max_retries}...")

            result = create_asset(
                asset_id=asset_id,
                name=asset_spec.get("name", asset_id),
                category=category,
                subcategory=asset_spec.get("subcategory", ""),
                tags=asset_spec.get("tags", []),
                build_script=build_script,
                asset_type=asset_type,
            )

            # Record in history
            report = result.get("quality_report", {})
            record_build(
                asset_id=asset_id,
                name=asset_spec.get("name", asset_id),
                category=category,
                asset_type=asset_type,
                quality_score=report.get("score", 0),
                passed=result.get("success", False),
                feedback=report.get("feedback", []),
                build_mode="detailed",
            )

            # Learn from quality feedback
            if report:
                learn_from_quality_feedback(asset_id, asset_type, category, report)

            if result.get("success"):
                break

        asset_results[asset_id] = {
            "status": "built" if result and result.get("success") else "failed",
            "quality_score": result.get("quality_report", {}).get("score", 0) if result else 0,
            "attempts": attempt,
        }

    # ── Phase 2: Assemble scene ──────────────────────────────────
    print(f"\n--- Assembling scene: {scene_name} ---")

    # Check all assets are available
    missing = [aid for aid, r in asset_results.items()
               if r["status"] == "failed"]
    if missing:
        print(f"  WARNING: {len(missing)} assets failed quality: {missing}")
        print(f"  Assembling with available assets only.")

    scene_result = quick_build(
        scene_name=scene_name,
        scene_script=assembly_script,
        output_dir=output_dir,
        render=render,
        resolution=resolution,
    )

    total_duration = round(time.time() - t0, 1)

    # ── Summary ──────────────────────────────────────────────────
    built = sum(1 for r in asset_results.values() if r["status"] == "built")
    existing = sum(1 for r in asset_results.values() if r["status"] == "existing")
    failed = sum(1 for r in asset_results.values() if r["status"] == "failed")

    print(f"\n" + "=" * 60)
    print(f"  DETAILED BUILD COMPLETE: {scene_name}")
    print(f"  Assets: {built} built, {existing} from library, {failed} failed")
    print(f"  Total time: {total_duration}s")
    print("=" * 60 + "\n")

    return {
        "success": scene_result.get("success", False),
        "scene_name": scene_name,
        "asset_results": asset_results,
        "scene_result": scene_result,
        "total_duration_s": total_duration,
        "assets_built": built,
        "assets_from_library": existing,
        "assets_failed": failed,
    }


# ═══════════════════════════════════════════════════════════════════
# ASSET NEEDS ANALYSIS — What does Onyx need to build?
# ═══════════════════════════════════════════════════════════════════

def analyze_scene_needs(asset_list):
    """Analyze which assets need building vs exist in library.

    Args:
        asset_list: List of asset IDs needed for a scene.

    Returns:
        dict with 'in_library', 'need_building', 'total'.
    """
    try:
        from library import find_asset, get_asset_blend_path
    except ImportError:
        from .library import find_asset, get_asset_blend_path

    in_library = []
    need_building = []

    for asset_id in asset_list:
        existing = find_asset(asset_id)
        if existing and os.path.exists(get_asset_blend_path(asset_id)):
            in_library.append(asset_id)
        else:
            need_building.append(asset_id)

    print(f"\n[Scene Analysis] {len(asset_list)} assets needed:")
    print(f"  In library:    {len(in_library)}")
    print(f"  Need building: {len(need_building)}")
    if need_building:
        for aid in need_building:
            print(f"    → {aid}")

    return {
        "in_library": in_library,
        "need_building": need_building,
        "total": len(asset_list),
    }
