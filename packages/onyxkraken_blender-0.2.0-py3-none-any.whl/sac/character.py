"""SAC Character Creator — Full character creation and rigging for Blender.

Capabilities:
  - Procedural humanoid body mesh via Skin modifier + Subdivision Surface
  - Custom humanoid armature with proper bone hierarchy
  - IK/FK constraints for arms and legs
  - Rigify integration (when addon available)
  - Automatic weight painting for mesh-to-skeleton binding
  - Procedural skin, eye, and hair materials
  - Body type presets (male, female, child, stylized)
  - Shape keys for facial expressions and body morphs
  - Full create_character() pipeline: mesh → rig → skin → materials → pose

Usage inside Blender scripts:
    from character import create_character, BODY_MALE, BODY_FEMALE

    char = create_character(
        name="Hero",
        body_type=BODY_MALE,
        height=1.80,
        skin_tone="medium",
        use_rigify=False,
    )

All dimensions are in meters (1:1 real-world scale).
"""

# ═══════════════════════════════════════════════════════════════════
# NOTE: This module generates Blender Python code that runs INSIDE
# Blender's Python environment. The functions here produce code
# strings or are meant to be called from within a Blender context.
# ═══════════════════════════════════════════════════════════════════

import json
import math

# ───────────────────────────────────────────────────────────────────
# BODY PROPORTION PRESETS
# All values are ratios relative to total height (1.0 = full height).
# Based on classical figure drawing (8-head proportions for adults).
# ───────────────────────────────────────────────────────────────────

BODY_MALE = {
    "label": "Adult Male",
    "head_height_ratio": 0.125,       # 1/8 of total height
    "shoulder_width_ratio": 0.26,     # shoulder-to-shoulder
    "hip_width_ratio": 0.17,          # hip-to-hip
    "chest_depth_ratio": 0.13,        # front-to-back at chest
    "waist_width_ratio": 0.15,
    "waist_depth_ratio": 0.11,

    # Vertical landmarks (from ground, as ratio of height)
    "ankle_y": 0.045,
    "knee_y": 0.285,
    "hip_y": 0.52,
    "navel_y": 0.58,
    "nipple_y": 0.72,
    "shoulder_y": 0.80,
    "chin_y": 0.865,
    "eye_y": 0.925,
    "top_y": 1.0,

    # Limb thickness (radius as ratio of height)
    "neck_radius": 0.030,
    "upper_arm_radius": 0.025,
    "forearm_radius": 0.020,
    "wrist_radius": 0.014,
    "hand_width": 0.045,
    "thigh_radius": 0.040,
    "calf_radius": 0.028,
    "ankle_radius": 0.018,
    "foot_length_ratio": 0.15,
    "foot_width_ratio": 0.05,

    # Build
    "muscle_factor": 1.0,             # 1.0 = normal, 1.3 = muscular
}

BODY_FEMALE = {
    "label": "Adult Female",
    "head_height_ratio": 0.130,
    "shoulder_width_ratio": 0.22,
    "hip_width_ratio": 0.20,
    "chest_depth_ratio": 0.12,
    "waist_width_ratio": 0.13,
    "waist_depth_ratio": 0.10,

    "ankle_y": 0.045,
    "knee_y": 0.29,
    "hip_y": 0.53,
    "navel_y": 0.59,
    "nipple_y": 0.73,
    "shoulder_y": 0.80,
    "chin_y": 0.87,
    "eye_y": 0.93,
    "top_y": 1.0,

    "neck_radius": 0.025,
    "upper_arm_radius": 0.020,
    "forearm_radius": 0.016,
    "wrist_radius": 0.012,
    "hand_width": 0.040,
    "thigh_radius": 0.038,
    "calf_radius": 0.025,
    "ankle_radius": 0.016,
    "foot_length_ratio": 0.14,
    "foot_width_ratio": 0.045,

    "muscle_factor": 0.8,
}

BODY_CHILD = {
    "label": "Child (age ~8)",
    "head_height_ratio": 0.167,       # 1/6 of height (larger head)
    "shoulder_width_ratio": 0.20,
    "hip_width_ratio": 0.16,
    "chest_depth_ratio": 0.10,
    "waist_width_ratio": 0.14,
    "waist_depth_ratio": 0.10,

    "ankle_y": 0.04,
    "knee_y": 0.27,
    "hip_y": 0.50,
    "navel_y": 0.55,
    "nipple_y": 0.70,
    "shoulder_y": 0.78,
    "chin_y": 0.85,
    "eye_y": 0.92,
    "top_y": 1.0,

    "neck_radius": 0.025,
    "upper_arm_radius": 0.018,
    "forearm_radius": 0.015,
    "wrist_radius": 0.012,
    "hand_width": 0.035,
    "thigh_radius": 0.030,
    "calf_radius": 0.022,
    "ankle_radius": 0.015,
    "foot_length_ratio": 0.13,
    "foot_width_ratio": 0.04,

    "muscle_factor": 0.6,
}

BODY_STYLIZED = {
    "label": "Stylized (heroic proportions)",
    "head_height_ratio": 0.111,       # 1/9 (heroic, taller)
    "shoulder_width_ratio": 0.30,
    "hip_width_ratio": 0.16,
    "chest_depth_ratio": 0.14,
    "waist_width_ratio": 0.14,
    "waist_depth_ratio": 0.10,

    "ankle_y": 0.04,
    "knee_y": 0.30,
    "hip_y": 0.52,
    "navel_y": 0.58,
    "nipple_y": 0.73,
    "shoulder_y": 0.82,
    "chin_y": 0.88,
    "eye_y": 0.94,
    "top_y": 1.0,

    "neck_radius": 0.032,
    "upper_arm_radius": 0.030,
    "forearm_radius": 0.024,
    "wrist_radius": 0.016,
    "hand_width": 0.050,
    "thigh_radius": 0.045,
    "calf_radius": 0.032,
    "ankle_radius": 0.020,
    "foot_length_ratio": 0.15,
    "foot_width_ratio": 0.05,

    "muscle_factor": 1.3,
}


# ───────────────────────────────────────────────────────────────────
# SKIN TONE PRESETS
# Principled BSDF values for different skin tones.
# ───────────────────────────────────────────────────────────────────

SKIN_TONES = {
    "pale":       {"color": (0.90, 0.78, 0.72), "subsurface": 0.02, "ss_color": (0.95, 0.55, 0.40)},
    "light":      {"color": (0.85, 0.70, 0.60), "subsurface": 0.025, "ss_color": (0.92, 0.50, 0.38)},
    "medium":     {"color": (0.70, 0.50, 0.38), "subsurface": 0.03, "ss_color": (0.85, 0.45, 0.32)},
    "tan":        {"color": (0.58, 0.40, 0.28), "subsurface": 0.035, "ss_color": (0.78, 0.38, 0.25)},
    "brown":      {"color": (0.42, 0.26, 0.18), "subsurface": 0.04, "ss_color": (0.65, 0.30, 0.18)},
    "dark":       {"color": (0.25, 0.15, 0.10), "subsurface": 0.05, "ss_color": (0.50, 0.22, 0.12)},
}

HAIR_COLORS = {
    "black":      (0.02, 0.02, 0.03),
    "dark_brown": (0.10, 0.06, 0.04),
    "brown":      (0.22, 0.12, 0.06),
    "auburn":     (0.35, 0.12, 0.05),
    "red":        (0.45, 0.10, 0.04),
    "blonde":     (0.60, 0.45, 0.25),
    "platinum":   (0.80, 0.75, 0.65),
    "grey":       (0.45, 0.45, 0.45),
    "white":      (0.85, 0.82, 0.80),
}

EYE_COLORS = {
    "brown":    (0.22, 0.12, 0.05),
    "hazel":    (0.35, 0.25, 0.10),
    "green":    (0.15, 0.35, 0.12),
    "blue":     (0.15, 0.30, 0.55),
    "grey":     (0.35, 0.40, 0.45),
    "amber":    (0.50, 0.30, 0.08),
}


# ───────────────────────────────────────────────────────────────────
# HUMANOID SKELETON DEFINITION
# Bone hierarchy with positions relative to body proportions.
# Each bone: (name, parent_name, head_landmark, tail_landmark)
# ───────────────────────────────────────────────────────────────────

def _skeleton_positions(height, body):
    """Calculate absolute bone positions from body proportions.

    Args:
        height: Character height in meters.
        body: Body proportion dict (BODY_MALE, etc.)

    Returns:
        Dict mapping bone_name → (head_xyz, tail_xyz).
    """
    h = height
    b = body
    sw = b["shoulder_width_ratio"] * h   # shoulder width (full span)
    hw = b["hip_width_ratio"] * h        # hip width

    # Vertical positions (Y-up in our convention, but Blender uses Z-up)
    # So height = Z axis
    ankle_z = b["ankle_y"] * h
    knee_z = b["knee_y"] * h
    hip_z = b["hip_y"] * h
    navel_z = b["navel_y"] * h
    nipple_z = b["nipple_y"] * h
    shoulder_z = b["shoulder_y"] * h
    chin_z = b["chin_y"] * h
    eye_z = b["eye_y"] * h
    top_z = b["top_y"] * h

    # Mid-spine
    spine_low_z = hip_z + (navel_z - hip_z) * 0.3
    spine_mid_z = navel_z + (nipple_z - navel_z) * 0.5
    spine_high_z = nipple_z + (shoulder_z - nipple_z) * 0.5

    # Arm positions
    elbow_z = shoulder_z - (shoulder_z - hip_z) * 0.44
    wrist_z = hip_z - 0.02 * h
    hand_tip_z = wrist_z - b["hand_width"] * h * 1.8

    # Clavicle
    clav_inner_x = 0.03 * h
    clav_outer_x = sw / 2

    # Hip joint offset
    hip_joint_x = hw / 2

    # Foot
    foot_len = b["foot_length_ratio"] * h
    foot_ball_y = foot_len * 0.65   # front portion of foot

    bones = {}

    # --- Spine chain ---
    bones["root"]    = ((0, 0, hip_z),         (0, 0, hip_z + 0.001))
    bones["hips"]    = ((0, 0, hip_z),         (0, 0, spine_low_z))
    bones["spine"]   = ((0, 0, spine_low_z),   (0, 0, spine_mid_z))
    bones["spine.001"] = ((0, 0, spine_mid_z), (0, 0, spine_high_z))
    bones["spine.002"] = ((0, 0, spine_high_z),(0, 0, shoulder_z))
    bones["spine.003"] = ((0, 0, shoulder_z),  (0, 0, chin_z))      # neck
    bones["spine.004"] = ((0, 0, chin_z),      (0, 0, eye_z))       # head base
    bones["spine.005"] = ((0, 0, eye_z),       (0, 0, top_z))       # head top

    # --- Left arm ---
    bones["shoulder.L"]  = ((clav_inner_x, 0, shoulder_z),
                            (clav_outer_x, 0, shoulder_z))
    bones["upper_arm.L"] = ((clav_outer_x, 0, shoulder_z),
                            (clav_outer_x + 0.01*h, 0, elbow_z))
    bones["forearm.L"]   = ((clav_outer_x + 0.01*h, 0, elbow_z),
                            (clav_outer_x + 0.02*h, 0, wrist_z))
    bones["hand.L"]      = ((clav_outer_x + 0.02*h, 0, wrist_z),
                            (clav_outer_x + 0.025*h, 0, hand_tip_z))

    # --- Right arm (mirrored) ---
    for bn in ["shoulder", "upper_arm", "forearm", "hand"]:
        lname = f"{bn}.L"
        rname = f"{bn}.R"
        lh, lt = bones[lname]
        bones[rname] = ((-lh[0], lh[1], lh[2]),
                        (-lt[0], lt[1], lt[2]))

    # --- Left leg ---
    bones["thigh.L"]  = ((hip_joint_x, 0, hip_z),
                         (hip_joint_x, 0, knee_z))
    bones["shin.L"]   = ((hip_joint_x, 0, knee_z),
                         (hip_joint_x, 0, ankle_z))
    bones["foot.L"]   = ((hip_joint_x, 0, ankle_z),
                         (hip_joint_x, -foot_ball_y, 0.0))
    bones["toe.L"]    = ((hip_joint_x, -foot_ball_y, 0.0),
                         (hip_joint_x, -foot_len, 0.0))

    # --- Right leg (mirrored) ---
    for bn in ["thigh", "shin", "foot", "toe"]:
        lname = f"{bn}.L"
        rname = f"{bn}.R"
        lh, lt = bones[lname]
        bones[rname] = ((-lh[0], lh[1], lh[2]),
                        (-lt[0], lt[1], lt[2]))

    # --- Finger bones (simplified: 3 per finger + thumb) ---
    for side_sign, side in [(1, "L"), (-1, "R")]:
        hand_head = bones[f"hand.{side}"][0]
        hx, hy, hz = hand_head
        finger_len = b["hand_width"] * h * 0.9
        finger_seg = finger_len / 3.0
        thumb_len = finger_len * 0.7
        thumb_seg = thumb_len / 3.0

        # Finger spread from index to pinky
        finger_names = ["f_index", "f_middle", "f_ring", "f_pinky"]
        spread_offsets = [0.015*h, 0.005*h, -0.005*h, -0.015*h]
        length_mults = [0.95, 1.0, 0.95, 0.80]

        for fi, (fname, x_off, l_mult) in enumerate(
                zip(finger_names, spread_offsets, length_mults)):
            fx = hx + side_sign * x_off
            flen = finger_seg * l_mult
            for j in range(3):
                bn = f"{fname}.{j+1:02d}.{side}"
                fz_start = hz - j * flen
                fz_end = fz_start - flen
                bones[bn] = ((fx, hy, fz_start), (fx, hy, fz_end))

        # Thumb (angled outward)
        tx = hx + side_sign * 0.025 * h
        tz = hz + 0.005 * h
        for j in range(3):
            bn = f"thumb.{j+1:02d}.{side}"
            tz_start = tz - j * thumb_seg
            tz_end = tz_start - thumb_seg
            bones[bn] = ((tx, hy, tz_start), (tx, hy, tz_end))

    return bones


# Bone hierarchy: child → parent mapping
BONE_HIERARCHY = {
    "hips": "root",
    "spine": "hips",
    "spine.001": "spine",
    "spine.002": "spine.001",
    "spine.003": "spine.002",       # neck
    "spine.004": "spine.003",       # head base
    "spine.005": "spine.004",       # head top
    # Left arm
    "shoulder.L": "spine.002",
    "upper_arm.L": "shoulder.L",
    "forearm.L": "upper_arm.L",
    "hand.L": "forearm.L",
    # Right arm
    "shoulder.R": "spine.002",
    "upper_arm.R": "shoulder.R",
    "forearm.R": "upper_arm.R",
    "hand.R": "forearm.R",
    # Left leg
    "thigh.L": "hips",
    "shin.L": "thigh.L",
    "foot.L": "shin.L",
    "toe.L": "foot.L",
    # Right leg
    "thigh.R": "hips",
    "shin.R": "thigh.R",
    "foot.R": "shin.R",
    "toe.R": "foot.R",
    # Fingers (generated dynamically)
}

# Add finger hierarchy
for side in ["L", "R"]:
    for fname in ["f_index", "f_middle", "f_ring", "f_pinky"]:
        BONE_HIERARCHY[f"{fname}.01.{side}"] = f"hand.{side}"
        BONE_HIERARCHY[f"{fname}.02.{side}"] = f"{fname}.01.{side}"
        BONE_HIERARCHY[f"{fname}.03.{side}"] = f"{fname}.02.{side}"
    BONE_HIERARCHY[f"thumb.01.{side}"] = f"hand.{side}"
    BONE_HIERARCHY[f"thumb.02.{side}"] = f"thumb.01.{side}"
    BONE_HIERARCHY[f"thumb.03.{side}"] = f"thumb.02.{side}"


# ───────────────────────────────────────────────────────────────────
# SKIN MODIFIER BODY VERTICES
# Define the body as a skeleton of vertices with radii.
# The Skin modifier converts this into a smooth mesh.
# ───────────────────────────────────────────────────────────────────

def _body_skin_vertices(height, body):
    """Generate vertices/edges/radii for Skin modifier body mesh.

    Creates a tree of vertices following the skeleton, with appropriate
    radii at each point to shape the body.

    Args:
        height: Character height in meters.
        body: Body proportion dict.

    Returns:
        (vertices, edges, radii) where:
            vertices: list of (x, y, z) tuples
            edges: list of (i, j) index pairs
            radii: list of (rx, ry) per vertex
    """
    h = height
    b = body
    mf = b.get("muscle_factor", 1.0)

    # Key heights
    ankle_z = b["ankle_y"] * h
    knee_z = b["knee_y"] * h
    hip_z = b["hip_y"] * h
    navel_z = b["navel_y"] * h
    nipple_z = b["nipple_y"] * h
    shoulder_z = b["shoulder_y"] * h
    chin_z = b["chin_y"] * h
    eye_z = b["eye_y"] * h
    top_z = h

    # Widths
    sw = b["shoulder_width_ratio"] * h / 2   # half shoulder width
    hw = b["hip_width_ratio"] * h / 2        # half hip width
    cd = b["chest_depth_ratio"] * h / 2
    ww = b["waist_width_ratio"] * h / 2
    head_r = b["head_height_ratio"] * h / 2

    verts = []
    edges = []
    radii = []

    def add_v(pos, rx, ry):
        idx = len(verts)
        verts.append(pos)
        radii.append((rx * mf, ry * mf))
        return idx

    def add_e(a, b_idx):
        edges.append((a, b_idx))

    # === TORSO SPINE (center line) ===
    # Radii are (X-width, Y-depth) — wider in X, flatter in Y
    v_hip     = add_v((0, 0, hip_z),       hw * 1.15, cd * 1.0)
    v_waist   = add_v((0, 0, navel_z),     ww * 1.1, b["waist_depth_ratio"]*h/2 * 1.1)
    v_chest   = add_v((0, 0, nipple_z),    sw * 0.95, cd * 1.1)
    v_shoulder= add_v((0, 0, shoulder_z),  sw * 0.80, cd * 0.85)
    v_neck_b  = add_v((0, 0, chin_z - 0.03*h), b["neck_radius"]*h * 1.1, b["neck_radius"]*h * 1.1)
    v_chin    = add_v((0, -0.01*h, chin_z), head_r * 0.70, head_r * 0.75)
    v_face    = add_v((0, -0.015*h, eye_z), head_r * 0.90, head_r * 0.90)
    v_crown   = add_v((0, 0, top_z),       head_r * 0.80, head_r * 0.75)

    add_e(v_hip, v_waist)
    add_e(v_waist, v_chest)
    add_e(v_chest, v_shoulder)
    add_e(v_shoulder, v_neck_b)
    add_e(v_neck_b, v_chin)
    add_e(v_chin, v_face)
    add_e(v_face, v_crown)

    # === ARMS (both sides) ===
    for side_sign in [1, -1]:
        sx = side_sign * sw
        ua_r = b["upper_arm_radius"] * h
        fa_r = b["forearm_radius"] * h
        wr_r = b["wrist_radius"] * h

        elbow_z = shoulder_z - (shoulder_z - hip_z) * 0.44
        wrist_z = hip_z - 0.02 * h
        hand_z = wrist_z - b["hand_width"] * h * 1.2

        # Arms hang slightly away from body
        arm_x_drift = abs(sx) * 0.08  # slight outward drift per segment
        v_sh  = add_v((sx * 1.0, 0, shoulder_z - 0.01*h), ua_r * 1.4, ua_r * 1.2)
        v_ua  = add_v((sx * 1.05 + side_sign*arm_x_drift, 0, (shoulder_z + elbow_z)/2), ua_r * 1.05, ua_r * 0.95)
        v_elb = add_v((sx * 1.08 + side_sign*arm_x_drift*1.5, 0, elbow_z), ua_r * 0.95, ua_r * 0.90)
        v_fa  = add_v((sx * 1.10 + side_sign*arm_x_drift*1.8, 0, (elbow_z + wrist_z)/2), fa_r * 1.05, fa_r * 0.95)
        v_wr  = add_v((sx * 1.12 + side_sign*arm_x_drift*2, 0, wrist_z), wr_r * 1.1, wr_r * 0.8)
        v_hnd = add_v((sx * 1.13 + side_sign*arm_x_drift*2, 0, hand_z), b["hand_width"]*h*0.45, wr_r * 0.35)

        add_e(v_shoulder, v_sh)
        add_e(v_sh, v_ua)
        add_e(v_ua, v_elb)
        add_e(v_elb, v_fa)
        add_e(v_fa, v_wr)
        add_e(v_wr, v_hnd)

    # === LEGS (both sides) ===
    for side_sign in [1, -1]:
        hx = side_sign * hw
        th_r = b["thigh_radius"] * h
        ca_r = b["calf_radius"] * h
        an_r = b["ankle_radius"] * h
        foot_len = b["foot_length_ratio"] * h

        v_hip_j = add_v((hx, 0, hip_z - 0.01*h), th_r * 1.2, th_r * 1.1)
        v_mid_th = add_v((hx, 0, (hip_z + knee_z)/2), th_r * 1.05, th_r * 0.95)
        v_knee  = add_v((hx, 0, knee_z),      ca_r * 1.15, ca_r * 1.05)
        v_mid_ca = add_v((hx, 0, (knee_z + ankle_z)/2), ca_r * 1.05, ca_r * 0.90)
        v_ankle = add_v((hx, 0, ankle_z),     an_r * 1.1, an_r * 1.0)
        v_heel  = add_v((hx, foot_len * 0.25, 0.005*h), an_r * 1.4, an_r * 0.55)
        v_toe   = add_v((hx, -foot_len * 0.75, 0.005*h), an_r * 0.9, an_r * 0.35)

        add_e(v_hip, v_hip_j)
        add_e(v_hip_j, v_mid_th)
        add_e(v_mid_th, v_knee)
        add_e(v_knee, v_mid_ca)
        add_e(v_mid_ca, v_ankle)
        add_e(v_ankle, v_heel)
        add_e(v_heel, v_toe)

    return verts, edges, radii


# ═══════════════════════════════════════════════════════════════════
# BLENDER SCRIPT GENERATION
# These functions generate Python code to run inside Blender.
# ═══════════════════════════════════════════════════════════════════

def generate_armature_code(name, height, body):
    """Generate Blender Python code to create a humanoid armature.

    Creates a full bone hierarchy with proper positions and parenting.

    Args:
        name: Character name.
        height: Height in meters.
        body: Body proportion dict.

    Returns:
        String of Blender Python code.
    """
    bone_positions = _skeleton_positions(height, body)

    lines = [
        f"# === CREATE ARMATURE: {name} ===",
        f"arm_data = bpy.data.armatures.new('{name}_Armature')",
        f"arm_obj = bpy.data.objects.new('{name}_Rig', arm_data)",
        f"bpy.context.collection.objects.link(arm_obj)",
        f"bpy.context.view_layer.objects.active = arm_obj",
        f"arm_obj.select_set(True)",
        f"arm_data.display_type = 'OCTAHEDRAL'",
        f"",
        f"# Enter edit mode to create bones",
        f"bpy.ops.object.mode_set(mode='EDIT')",
        f"edit_bones = arm_data.edit_bones",
        f"",
    ]

    # Create each bone
    for bone_name, (head, tail) in bone_positions.items():
        hx, hy, hz = head
        tx, ty, tz = tail
        lines.append(f"b = edit_bones.new('{bone_name}')")
        lines.append(f"b.head = ({hx:.6f}, {hy:.6f}, {hz:.6f})")
        lines.append(f"b.tail = ({tx:.6f}, {ty:.6f}, {tz:.6f})")

        # Set parent if defined
        parent = BONE_HIERARCHY.get(bone_name)
        if parent and parent in bone_positions:
            lines.append(f"b.parent = edit_bones.get('{parent}')")
            lines.append(f"b.use_connect = False")

        lines.append("")

    # Exit edit mode
    lines.append("bpy.ops.object.mode_set(mode='OBJECT')")
    lines.append(f"print('[Character] Armature created: {name}_Rig')")
    lines.append("")

    return "\n".join(lines)


def generate_ik_constraints_code(name):
    """Generate IK/FK constraint code for arms and legs.

    Creates IK targets and pole targets for natural limb posing.
    """
    lines = [
        f"# === IK/FK CONSTRAINTS: {name} ===",
        f"arm_obj = bpy.data.objects['{name}_Rig']",
        f"bpy.context.view_layer.objects.active = arm_obj",
        f"bpy.ops.object.mode_set(mode='EDIT')",
        f"edit_bones = arm_obj.data.edit_bones",
        f"",
    ]

    # Create IK target bones for each limb
    for side in ["L", "R"]:
        # --- Arm IK target ---
        lines.append(f"# Arm IK target {side}")
        lines.append(f"hand_bone = edit_bones['{f'hand.{side}'}']")
        lines.append(f"ik_hand = edit_bones.new('hand_ik.{side}')")
        lines.append(f"ik_hand.head = hand_bone.head.copy()")
        lines.append(f"ik_hand.tail = hand_bone.tail.copy()")
        lines.append(f"ik_hand.parent = None  # world space IK target")
        lines.append(f"")

        # --- Arm pole target ---
        lines.append(f"elbow = edit_bones['forearm.{side}']")
        lines.append(f"pole_arm = edit_bones.new('arm_pole.{side}')")
        lines.append(f"pole_arm.head = (elbow.head.x, elbow.head.y + 0.3, elbow.head.z)")
        lines.append(f"pole_arm.tail = (elbow.head.x, elbow.head.y + 0.35, elbow.head.z)")
        lines.append(f"pole_arm.parent = None")
        lines.append(f"")

        # --- Leg IK target ---
        lines.append(f"# Leg IK target {side}")
        lines.append(f"foot_bone = edit_bones['foot.{side}']")
        lines.append(f"ik_foot = edit_bones.new('foot_ik.{side}')")
        lines.append(f"ik_foot.head = foot_bone.head.copy()")
        lines.append(f"ik_foot.tail = foot_bone.tail.copy()")
        lines.append(f"ik_foot.parent = None")
        lines.append(f"")

        # --- Leg pole target ---
        lines.append(f"knee = edit_bones['shin.{side}']")
        lines.append(f"pole_leg = edit_bones.new('leg_pole.{side}')")
        lines.append(f"pole_leg.head = (knee.head.x, knee.head.y - 0.4, knee.head.z)")
        lines.append(f"pole_leg.tail = (knee.head.x, knee.head.y - 0.45, knee.head.z)")
        lines.append(f"pole_leg.parent = None")
        lines.append(f"")

    lines.append("bpy.ops.object.mode_set(mode='POSE')")
    lines.append("")

    # Add IK constraints in pose mode
    for side in ["L", "R"]:
        # Arm IK
        lines.append(f"# Arm IK constraint {side}")
        lines.append(f"pb = arm_obj.pose.bones['forearm.{side}']")
        lines.append(f"ik = pb.constraints.new('IK')")
        lines.append(f"ik.target = arm_obj")
        lines.append(f"ik.subtarget = 'hand_ik.{side}'")
        lines.append(f"ik.pole_target = arm_obj")
        lines.append(f"ik.pole_subtarget = 'arm_pole.{side}'")
        lines.append(f"ik.chain_count = 2")
        lines.append(f"ik.pole_angle = math.radians(90)")
        lines.append(f"ik.influence = 1.0")
        lines.append(f"")

        # Leg IK
        lines.append(f"# Leg IK constraint {side}")
        lines.append(f"pb = arm_obj.pose.bones['shin.{side}']")
        lines.append(f"ik = pb.constraints.new('IK')")
        lines.append(f"ik.target = arm_obj")
        lines.append(f"ik.subtarget = 'foot_ik.{side}'")
        lines.append(f"ik.pole_target = arm_obj")
        lines.append(f"ik.pole_subtarget = 'leg_pole.{side}'")
        lines.append(f"ik.chain_count = 2")
        lines.append(f"ik.pole_angle = math.radians(-90)")
        lines.append(f"ik.influence = 1.0")
        lines.append(f"")

    lines.append("bpy.ops.object.mode_set(mode='OBJECT')")
    lines.append(f"print('[Character] IK constraints added: {name}')")
    lines.append("")

    return "\n".join(lines)


def generate_body_mesh_code(name, height, body):
    """Generate Blender Python code to create body mesh via Skin modifier.

    Uses the Skin modifier approach: creates a skeleton of vertices with
    radii, applies Skin modifier, then Subdivision Surface for smoothing.

    Args:
        name: Character name.
        height: Height in meters.
        body: Body proportion dict.

    Returns:
        String of Blender Python code.
    """
    verts, edges, radii_list = _body_skin_vertices(height, body)

    lines = [
        f"# === CREATE BODY MESH: {name} (Skin Modifier) ===",
        f"import bmesh",
        f"",
        f"# Create mesh data",
        f"mesh_data = bpy.data.meshes.new('{name}_Body_Mesh')",
        f"body_obj = bpy.data.objects.new('{name}_Body', mesh_data)",
        f"bpy.context.collection.objects.link(body_obj)",
        f"bpy.context.view_layer.objects.active = body_obj",
        f"body_obj.select_set(True)",
        f"",
        f"# Define vertices and edges",
        f"verts = {json.dumps(verts)}",
        f"edges = {json.dumps(edges)}",
        f"",
        f"mesh_data.from_pydata(verts, edges, [])",
        f"mesh_data.update()",
        f"",
        f"# Add Skin modifier",
        f"skin_mod = body_obj.modifiers.new('Skin', 'SKIN')",
        f"",
        f"# Set per-vertex radii",
        f"skin_verts = body_obj.data.skin_vertices[0].data",
        f"radii = {json.dumps(radii_list)}",
        f"for i, (rx, ry) in enumerate(radii):",
        f"    skin_verts[i].radius = (rx, ry)",
        f"",
        f"# Mark root vertex (hip/torso center)",
        f"skin_verts[0].use_root = True",
        f"",
        f"# Add Subdivision Surface for smoothing",
        f"subsurf = body_obj.modifiers.new('Subsurf', 'SUBSURF')",
        f"subsurf.levels = 2",
        f"subsurf.render_levels = 3",
        f"",
        f"# Apply modifiers to get final mesh",
        f"bpy.ops.object.modifier_apply(modifier='Skin')",
        f"bpy.ops.object.modifier_apply(modifier='Subsurf')",
        f"",
        f"# Smooth shading",
        f"bpy.ops.object.shade_smooth()",
        f"",
        f"# Add Auto Smooth for better normals",
        f"mesh_data = body_obj.data",
        f"mesh_data.use_auto_smooth = True",
        f"mesh_data.auto_smooth_angle = math.radians(60)",
        f"",
        f"print(f'[Character] Body mesh: {{len(body_obj.data.vertices)}} verts, {{len(body_obj.data.polygons)}} faces')",
        f"",
    ]

    return "\n".join(lines)


def generate_skin_material_code(name, skin_tone="medium"):
    """Generate procedural skin material code.

    Creates a realistic skin shader using Principled BSDF with:
    - Subsurface scattering for skin translucency
    - Noise texture for pore detail
    - Bump mapping for skin micro-detail

    Args:
        name: Character name.
        skin_tone: Key from SKIN_TONES dict.
    """
    tone = SKIN_TONES.get(skin_tone, SKIN_TONES["medium"])
    r, g, b = tone["color"]
    sr, sg, sb = tone["ss_color"]
    ss = tone["subsurface"]

    return f"""
# === SKIN MATERIAL: {name} ===
mat_skin = bpy.data.materials.new('{name}_Skin')
mat_skin.use_nodes = True
nodes = mat_skin.node_tree.nodes
links = mat_skin.node_tree.links
bsdf = nodes.get('Principled BSDF')

# Base skin color
bsdf.inputs['Base Color'].default_value = ({r}, {g}, {b}, 1.0)

# Subsurface scattering (skin translucency)
bsdf.inputs['Subsurface'].default_value = {ss}
bsdf.inputs['Subsurface Color'].default_value = ({sr}, {sg}, {sb}, 1.0)
bsdf.inputs['Subsurface Radius'].default_value = (1.0, 0.2, 0.1)

# Skin roughness
bsdf.inputs['Roughness'].default_value = 0.5
bsdf.inputs['Specular'].default_value = 0.3

# Pore detail via noise texture
tex_coord = nodes.new('ShaderNodeTexCoord')
tex_coord.location = (-900, 0)
mapping = nodes.new('ShaderNodeMapping')
mapping.location = (-700, 0)
mapping.inputs['Scale'].default_value = (50.0, 50.0, 50.0)
links.new(tex_coord.outputs['Object'], mapping.inputs['Vector'])

# Fine noise for pores
noise_fine = nodes.new('ShaderNodeTexNoise')
noise_fine.location = (-500, 0)
noise_fine.inputs['Scale'].default_value = 200.0
noise_fine.inputs['Detail'].default_value = 8.0
noise_fine.inputs['Roughness'].default_value = 0.7
links.new(mapping.outputs['Vector'], noise_fine.inputs['Vector'])

# Coarse noise for color variation
noise_coarse = nodes.new('ShaderNodeTexNoise')
noise_coarse.location = (-500, -200)
noise_coarse.inputs['Scale'].default_value = 8.0
noise_coarse.inputs['Detail'].default_value = 4.0
links.new(mapping.outputs['Vector'], noise_coarse.inputs['Vector'])

# Color variation (subtle warmth shifts)
color_mix = nodes.new('ShaderNodeMixRGB')
color_mix.location = (-200, 100)
color_mix.blend_type = 'OVERLAY'
color_mix.inputs['Fac'].default_value = 0.08
color_mix.inputs['Color1'].default_value = ({r}, {g}, {b}, 1.0)
color_mix.inputs['Color2'].default_value = ({sr}, {sg}, {sb}, 1.0)
links.new(noise_coarse.outputs['Fac'], color_mix.inputs['Fac'])
links.new(color_mix.outputs['Color'], bsdf.inputs['Base Color'])

# Roughness variation (oilier in some areas)
rough_map = nodes.new('ShaderNodeMapRange')
rough_map.location = (-200, -100)
rough_map.inputs['From Min'].default_value = 0.0
rough_map.inputs['From Max'].default_value = 1.0
rough_map.inputs['To Min'].default_value = 0.35
rough_map.inputs['To Max'].default_value = 0.60
links.new(noise_fine.outputs['Fac'], rough_map.inputs['Value'])
links.new(rough_map.outputs['Result'], bsdf.inputs['Roughness'])

# Bump for skin micro-detail
bump = nodes.new('ShaderNodeBump')
bump.location = (-200, -300)
bump.inputs['Strength'].default_value = 0.015
bump.inputs['Distance'].default_value = 0.001
links.new(noise_fine.outputs['Fac'], bump.inputs['Height'])
links.new(bump.outputs['Normal'], bsdf.inputs['Normal'])

# Apply to body
body_obj = bpy.data.objects['{name}_Body']
body_obj.data.materials.append(mat_skin)
print('[Character] Skin material applied: {skin_tone}')
"""


def generate_eye_material_code(name, eye_color="brown"):
    """Generate eye material code with iris color and reflection."""
    ec = EYE_COLORS.get(eye_color, EYE_COLORS["brown"])
    er, eg, eb = ec

    return f"""
# === EYE MATERIAL: {name} ===
# Sclera (white of eye)
mat_sclera = bpy.data.materials.new('{name}_Sclera')
mat_sclera.use_nodes = True
sc_bsdf = mat_sclera.node_tree.nodes.get('Principled BSDF')
sc_bsdf.inputs['Base Color'].default_value = (0.95, 0.93, 0.92, 1.0)
sc_bsdf.inputs['Roughness'].default_value = 0.15
sc_bsdf.inputs['Specular'].default_value = 0.8
sc_bsdf.inputs['Subsurface'].default_value = 0.02
sc_bsdf.inputs['Subsurface Color'].default_value = (0.9, 0.4, 0.3, 1.0)

# Iris
mat_iris = bpy.data.materials.new('{name}_Iris')
mat_iris.use_nodes = True
ir_nodes = mat_iris.node_tree.nodes
ir_links = mat_iris.node_tree.links
ir_bsdf = ir_nodes.get('Principled BSDF')
ir_bsdf.inputs['Base Color'].default_value = ({er}, {eg}, {eb}, 1.0)
ir_bsdf.inputs['Roughness'].default_value = 0.1
ir_bsdf.inputs['Specular'].default_value = 0.9

# Radial pattern for iris
ir_coord = ir_nodes.new('ShaderNodeTexCoord')
ir_coord.location = (-600, 0)
ir_noise = ir_nodes.new('ShaderNodeTexNoise')
ir_noise.location = (-400, 0)
ir_noise.inputs['Scale'].default_value = 15.0
ir_noise.inputs['Detail'].default_value = 8.0
ir_links.new(ir_coord.outputs['Object'], ir_noise.inputs['Vector'])

ir_mix = ir_nodes.new('ShaderNodeMixRGB')
ir_mix.location = (-200, 0)
ir_mix.inputs['Fac'].default_value = 0.3
ir_mix.inputs['Color1'].default_value = ({er}, {eg}, {eb}, 1.0)
ir_mix.inputs['Color2'].default_value = ({er*0.6:.3f}, {eg*0.6:.3f}, {eb*0.6:.3f}, 1.0)
ir_links.new(ir_noise.outputs['Fac'], ir_mix.inputs['Fac'])
ir_links.new(ir_mix.outputs['Color'], ir_bsdf.inputs['Base Color'])

# Pupil
mat_pupil = bpy.data.materials.new('{name}_Pupil')
mat_pupil.use_nodes = True
pup_bsdf = mat_pupil.node_tree.nodes.get('Principled BSDF')
pup_bsdf.inputs['Base Color'].default_value = (0.01, 0.01, 0.01, 1.0)
pup_bsdf.inputs['Roughness'].default_value = 0.0
pup_bsdf.inputs['Specular'].default_value = 1.0

# Cornea (clear glossy cover)
mat_cornea = bpy.data.materials.new('{name}_Cornea')
mat_cornea.use_nodes = True
cor_bsdf = mat_cornea.node_tree.nodes.get('Principled BSDF')
cor_bsdf.inputs['Base Color'].default_value = (1.0, 1.0, 1.0, 1.0)
cor_bsdf.inputs['Roughness'].default_value = 0.0
cor_bsdf.inputs['Specular'].default_value = 1.0
cor_bsdf.inputs['Transmission'].default_value = 0.95
cor_bsdf.inputs['IOR'].default_value = 1.376

print('[Character] Eye materials created: {eye_color}')
"""


def generate_eye_mesh_code(name, height, body):
    """Generate code to create eyeball meshes positioned in the head."""
    # The Skin modifier + SubSurf shrinks head volume significantly.
    # Place eyes relative to the mid-face area, accounting for shrinkage.
    chin_z = body["chin_y"] * height
    raw_eye_z = body["eye_y"] * height
    head_r = body["head_height_ratio"] * height / 2
    # Eyes sit between chin and raw eye level, biased toward eye level
    eye_z = chin_z + (raw_eye_z - chin_z) * 0.65
    eye_spacing = head_r * 0.42
    eye_r = head_r * 0.17
    # Forward position: Skin+SubSurf head is ~60% of theoretical radius
    eye_y = -(head_r * 0.55)  # embedded in front of head

    return f"""
# === EYE MESHES: {name} ===
for side_name, sx in [('L', {eye_spacing:.4f}), ('R', {-eye_spacing:.4f})]:
    # Eyeball sphere
    bpy.ops.mesh.primitive_uv_sphere_add(
        radius={eye_r:.4f}, segments=24, ring_count=16,
        location=(sx, {eye_y:.4f}, {eye_z:.4f}))
    eye = bpy.context.active_object
    eye.name = f'{name}_Eye_{{side_name}}'
    bpy.ops.object.shade_smooth()

    # Apply sclera material
    if '{name}_Sclera' in bpy.data.materials:
        eye.data.materials.append(bpy.data.materials['{name}_Sclera'])

    # Iris disc (slightly in front of eyeball)
    bpy.ops.mesh.primitive_circle_add(
        radius={eye_r * 0.45:.4f}, vertices=32, fill_type='NGON',
        location=(sx, {eye_y - eye_r * 0.95:.4f}, {eye_z:.4f}))
    iris = bpy.context.active_object
    iris.name = f'{name}_Iris_{{side_name}}'
    iris.rotation_euler.x = math.radians(90)
    if '{name}_Iris' in bpy.data.materials:
        iris.data.materials.append(bpy.data.materials['{name}_Iris'])

    # Pupil disc
    bpy.ops.mesh.primitive_circle_add(
        radius={eye_r * 0.20:.4f}, vertices=24, fill_type='NGON',
        location=(sx, {eye_y - eye_r * 0.96:.4f}, {eye_z:.4f}))
    pupil = bpy.context.active_object
    pupil.name = f'{name}_Pupil_{{side_name}}'
    pupil.rotation_euler.x = math.radians(90)
    if '{name}_Pupil' in bpy.data.materials:
        pupil.data.materials.append(bpy.data.materials['{name}_Pupil'])

    # Cornea (glossy dome over eye)
    bpy.ops.mesh.primitive_uv_sphere_add(
        radius={eye_r * 1.05:.4f}, segments=24, ring_count=16,
        location=(sx, {eye_y:.4f}, {eye_z:.4f}))
    cornea = bpy.context.active_object
    cornea.name = f'{name}_Cornea_{{side_name}}'
    bpy.ops.object.shade_smooth()
    if '{name}_Cornea' in bpy.data.materials:
        cornea.data.materials.append(bpy.data.materials['{name}_Cornea'])

print('[Character] Eyes created')
"""


def generate_auto_weight_code(name):
    """Generate code to bind body mesh to armature with automatic weights."""
    return f"""
# === AUTOMATIC WEIGHT BINDING: {name} ===
# Deselect all
bpy.ops.object.select_all(action='DESELECT')

body_obj = bpy.data.objects['{name}_Body']
arm_obj = bpy.data.objects['{name}_Rig']

# Select body first, then armature (armature must be active)
body_obj.select_set(True)
arm_obj.select_set(True)
bpy.context.view_layer.objects.active = arm_obj

# Parent with automatic weights
bpy.ops.object.parent_set(type='ARMATURE_AUTO')

print(f'[Character] Auto weights applied: {{len(body_obj.vertex_groups)}} vertex groups')

# Also parent eye objects to head bone
for obj_name in ['{name}_Eye_L', '{name}_Eye_R',
                 '{name}_Iris_L', '{name}_Iris_R',
                 '{name}_Pupil_L', '{name}_Pupil_R',
                 '{name}_Cornea_L', '{name}_Cornea_R']:
    obj = bpy.data.objects.get(obj_name)
    if obj:
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        arm_obj.select_set(True)
        bpy.context.view_layer.objects.active = arm_obj
        obj.parent = arm_obj
        obj.parent_type = 'BONE'
        obj.parent_bone = 'spine.004'  # head bone
        obj.matrix_parent_inverse = arm_obj.data.bones['spine.004'].matrix_local.inverted()

print('[Character] Eye objects parented to head')
"""


def generate_rigify_code(name, height, body):
    """Generate code to create a Rigify metarig and generate the full rig.

    This is an alternative to the custom armature — uses Rigify for
    production-quality IK/FK switching, stretchy limbs, etc.

    Note: Requires Rigify addon to be enabled in Blender.
    """
    bone_positions = _skeleton_positions(height, body)

    return f"""
# === RIGIFY RIG: {name} ===
# Enable Rigify addon
import addon_utils
addon_utils.enable('rigify', default_set=True, persistent=True)

# Add human metarig
bpy.ops.object.armature_human_metarig_add()
metarig = bpy.context.active_object
metarig.name = '{name}_Metarig'

# Scale metarig to match character height
# Default Rigify human is ~1.7m, scale accordingly
scale_factor = {height} / 1.7
metarig.scale = (scale_factor, scale_factor, scale_factor)
bpy.ops.object.transform_apply(scale=True)

# Adjust key bone positions to match body proportions
bpy.ops.object.mode_set(mode='EDIT')
edit_bones = metarig.data.edit_bones

# Adjust shoulder width
if 'upper_arm.L' in edit_bones:
    target_sw = {body['shoulder_width_ratio'] * height / 2:.4f}
    ua_l = edit_bones['upper_arm.L']
    ua_r = edit_bones['upper_arm.R']
    ua_l.head.x = target_sw
    ua_r.head.x = -target_sw

# Adjust hip width
if 'thigh.L' in edit_bones:
    target_hw = {body['hip_width_ratio'] * height / 2:.4f}
    th_l = edit_bones['thigh.L']
    th_r = edit_bones['thigh.R']
    th_l.head.x = target_hw
    th_r.head.x = -target_hw

bpy.ops.object.mode_set(mode='OBJECT')

# Generate the full Rigify rig
try:
    import rigify.generate
    bpy.context.view_layer.objects.active = metarig
    metarig.select_set(True)
    rigify.generate.generate_rig(bpy.context, metarig)
    rig = bpy.data.objects.get('rig')
    if rig:
        rig.name = '{name}_Rig'
    print('[Character] Rigify rig generated successfully')
except Exception as e:
    print(f'[Character] Rigify generation failed: {{e}}')
    print('[Character] Falling back to custom armature')
"""


def generate_pose_code(name, pose="t_pose"):
    """Generate code to set a character pose.

    Presets:
        t_pose: Arms out horizontally (default rigging pose)
        a_pose: Arms at ~45° (better for weight painting)
        rest: Natural standing pose with slight arm bend
    """
    poses = {
        "t_pose": {},  # Default bone positions = T-pose
        "a_pose": {
            "upper_arm.L": (0, 0, -45),
            "upper_arm.R": (0, 0, 45),
        },
        "rest": {
            "upper_arm.L": (10, 0, -30),
            "upper_arm.R": (10, 0, 30),
            "forearm.L": (0, 0, -15),
            "forearm.R": (0, 0, 15),
        },
    }

    bone_rots = poses.get(pose, poses["rest"])

    lines = [
        f"# === POSE: {name} ({pose}) ===",
        f"arm_obj = bpy.data.objects['{name}_Rig']",
        f"bpy.context.view_layer.objects.active = arm_obj",
        f"bpy.ops.object.mode_set(mode='POSE')",
        f"",
    ]

    for bone_name, (rx, ry, rz) in bone_rots.items():
        lines.append(f"pb = arm_obj.pose.bones.get('{bone_name}')")
        lines.append(f"if pb:")
        lines.append(f"    pb.rotation_mode = 'XYZ'")
        lines.append(f"    pb.rotation_euler = (math.radians({rx}), math.radians({ry}), math.radians({rz}))")

    lines.append(f"bpy.ops.object.mode_set(mode='OBJECT')")
    lines.append(f"print('[Character] Pose set: {pose}')")
    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════
# HIGH-LEVEL CHARACTER PIPELINE
# ═══════════════════════════════════════════════════════════════════

def generate_full_character_script(name="Character", height=1.75,
                                    body_type=None, skin_tone="medium",
                                    eye_color="brown", use_rigify=False,
                                    pose="rest", add_eyes=True):
    """Generate a complete Blender script to create a rigged character.

    This is the main entry point. It assembles all the individual
    generation functions into a single executable Blender script.

    Args:
        name: Character name.
        height: Height in meters (default 1.75m).
        body_type: Body proportion dict (default BODY_MALE).
        skin_tone: Skin tone preset name.
        eye_color: Eye color preset name.
        use_rigify: Use Rigify addon (if available) instead of custom rig.
        pose: Initial pose ('t_pose', 'a_pose', 'rest').
        add_eyes: Whether to create eye geometry.

    Returns:
        Complete Blender Python script as string.
    """
    if body_type is None:
        body_type = BODY_MALE

    sections = []

    # Header
    sections.append(f"""
# ═══════════════════════════════════════════════════════════════
# SAC CHARACTER: {name}
# Height: {height}m | Body: {body_type.get('label', 'Custom')}
# Skin: {skin_tone} | Eyes: {eye_color}
# Rig: {'Rigify' if use_rigify else 'Custom IK/FK'}
# ═══════════════════════════════════════════════════════════════
import bpy
import bmesh
import math
from mathutils import Vector, Matrix
""")

    # Body mesh
    sections.append(generate_body_mesh_code(name, height, body_type))

    # Rigging
    if use_rigify:
        sections.append(generate_rigify_code(name, height, body_type))
    else:
        sections.append(generate_armature_code(name, height, body_type))
        sections.append(generate_ik_constraints_code(name))

    # Materials
    sections.append(generate_skin_material_code(name, skin_tone))
    if add_eyes:
        sections.append(generate_eye_material_code(name, eye_color))
        sections.append(generate_eye_mesh_code(name, height, body_type))

    # Bind mesh to skeleton
    sections.append(generate_auto_weight_code(name))

    # Set pose
    sections.append(generate_pose_code(name, pose))

    # Summary
    sections.append(f"""
# === SUMMARY ===
mesh_count = sum(1 for o in bpy.data.objects if o.type == 'MESH')
bone_count = len(bpy.data.objects['{name}_Rig'].data.bones)
print(f'[Character] {name} complete: {{mesh_count}} meshes, {{bone_count}} bones')
print(f'[Character] Height: {height}m, Body: {body_type.get("label", "Custom")}')
""")

    return "\n".join(sections)


def create_character(name="Character", height=1.75, body_type=None,
                     skin_tone="medium", eye_color="brown",
                     use_rigify=False, pose="rest",
                     render_preview=True, store_in_library=True):
    """Full pipeline: create character, rig, render, store.

    This function runs outside Blender — it generates the script,
    executes it in Blender headless, and handles library storage.

    Args:
        name: Character name.
        height: Height in meters.
        body_type: Body proportion dict.
        skin_tone: Skin tone preset.
        eye_color: Eye color preset.
        use_rigify: Use Rigify addon.
        pose: Initial pose.
        render_preview: Render a thumbnail.
        store_in_library: Register in SAC library.

    Returns:
        Dict with 'success', 'blend_path', 'thumbnail_path', etc.
    """
    import os
    import sys

    _this_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, _this_dir)

    try:
        from creator import create_asset
    except ImportError:
        from .creator import create_asset

    if body_type is None:
        body_type = BODY_MALE

    # Generate the full character script
    char_script = generate_full_character_script(
        name=name, height=height, body_type=body_type,
        skin_tone=skin_tone, eye_color=eye_color,
        use_rigify=use_rigify, pose=pose,
    )

    # Use SAC pipeline
    asset_id = f"character_{name.lower().replace(' ', '_')}"
    result = create_asset(
        asset_id=asset_id,
        name=f"Character: {name}",
        category="character",
        subcategory=body_type.get("label", "custom").lower().replace(" ", "_"),
        tags=["character", "humanoid", "rigged", skin_tone, body_type.get("label", "").lower()],
        build_script=char_script,
        asset_type="character",
    )

    return result
