"""
SAC Creator — Asset creation pipeline.

Pipeline: create → quality check → iterate → approve → store in library

This module generates Blender Python scripts that build photorealistic
1:1 scale assets using advanced techniques (subdivision, proper materials,
rounded edges, multi-part construction, hardware details).

The scripts are executed in Blender headless mode, quality-checked, and
if approved, registered in the asset library.
"""

import os
import sys
import json
import subprocess
import re
from datetime import datetime

# Add parent paths for imports
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_TOOLKIT_DIR = os.path.dirname(_THIS_DIR)
_PROJECT_DIR = os.path.join(os.path.expanduser("~"), "OnyxProjects")
os.makedirs(_PROJECT_DIR, exist_ok=True)

# Ensure sac dir is on path for direct-run imports
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

# Blender executable discovery — delegated to config.find_blender_exe()
try:
    from config import find_blender_exe as _find_blender
except ImportError:
    # Direct-run fallback
    def _find_blender():
        for p in [
            r"C:\Program Files\Blender Foundation\Blender 3.2\blender.exe",
            r"C:\Program Files\Blender Foundation\Blender 4.0\blender.exe",
        ]:
            if os.path.exists(p):
                return p
        return "blender"


def run_blender_script(script, blend_file=None, timeout=120):
    """Execute a Python script inside Blender headless mode.

    For large scripts (>7000 chars), writes to a temp file and uses
    --python instead of --python-expr to avoid Windows cmd length limits.

    Args:
        script: Python code string to execute.
        blend_file: Optional .blend file to open first.
        timeout: Max seconds to wait.

    Returns:
        (return_code, stdout, stderr) tuple.
    """
    import tempfile

    blender = _find_blender()

    cmd = [blender, "--background"]
    if blend_file:
        cmd.insert(2, blend_file)

    tmp_file = None
    if len(script) > 7000:
        tmp_file = tempfile.NamedTemporaryFile(
            mode='w', suffix='.py', delete=False, encoding='utf-8')
        tmp_file.write(script)
        tmp_file.close()
        cmd.extend(["--python", tmp_file.name])
    else:
        cmd.extend(["--python-expr", script])

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=_PROJECT_DIR,
        )
        return (result.returncode, result.stdout, result.stderr)
    except subprocess.TimeoutExpired:
        return (-1, "", "Blender script timed out")
    except Exception as e:
        return (-1, "", str(e))
    finally:
        if tmp_file and os.path.exists(tmp_file.name):
            try:
                os.unlink(tmp_file.name)
            except OSError:
                pass


# ---------------------------------------------------------------------------
# Asset Builder Script Generator
# ---------------------------------------------------------------------------

def _asset_script_header():
    """Common header for all asset builder scripts."""
    return f'''
import bpy
import bmesh
import math
import os
import sys
import json
from mathutils import Vector, Matrix

sys.path.insert(0, r"{_TOOLKIT_DIR}")
from onyx_bpy import (
    clear_scene, setup_scene, make_material, apply_material,
    make_pbr_material, setup_cycles, setup_hdri_environment,
    add_camera, orbit_camera, setup_camera_dof,
    add_sun, add_point_light, add_area_light,
    select_object, COLORS,
)

sys.path.insert(0, r"{_THIS_DIR}")
from techniques import (
    make_rounded_cube, make_rounded_cylinder, lathe_profile,
    add_subsurf, add_bevel_modifier, add_weighted_normals,
    mark_sharp_edges, smart_uv_unwrap, boolean_cut,
    assign_material_to_faces, assign_material_by_normal,
    apply_all_modifiers, add_solidify, add_mirror,
    crease_sharp_edges, set_edge_crease,
    create_profile_curve, curve_to_mesh, extrude_profile,
)

clear_scene()
setup_scene()

# Collection for the asset
asset_collection = bpy.data.collections.new("Asset")
bpy.context.scene.collection.children.link(asset_collection)

def _link(obj):
    """Link object to asset collection (and unlink from scene root)."""
    try:
        bpy.context.scene.collection.objects.unlink(obj)
    except RuntimeError:
        pass
    asset_collection.objects.link(obj)
    return obj

'''


def _asset_script_footer(asset_name, blend_output, thumb_output,
                          render_angles=None):
    """Common footer: save blend + render thumbnails."""
    # Normalize Windows paths to forward slashes for safe embedding
    blend_output = blend_output.replace('\\', '/')
    thumb_output = thumb_output.replace('\\', '/')

    if render_angles is None:
        render_angles = [
            {"name": "front", "azimuth": -25, "elevation": 20, "distance": 3.0},
        ]

    angle_code = ""
    for i, angle in enumerate(render_angles):
        suffix = f"_{angle['name']}" if i > 0 else ""
        angle_code += f'''
# Render: {angle['name']}
for o in list(bpy.data.objects):
    if o.type == 'CAMERA':
        bpy.data.objects.remove(o, do_unlink=True)

cam = orbit_camera(
    target=(0, 0, asset_height / 2),
    distance={angle['distance']},
    elevation={angle['elevation']},
    azimuth={angle['azimuth']},
    focal_length=50,
)
setup_camera_dof(cam, focus_distance={angle['distance']}, f_stop=4.0)

setup_cycles(samples=256, use_denoising=True)
setup_hdri_environment(strength=0.8)

# Studio lighting
add_area_light(location=(2, -2, 3), energy=400, size=2.0, name="KeyLight",
               rotation=(math.radians(60), 0, math.radians(45)))
add_area_light(location=(-2, -1, 2), energy=150, size=1.5, name="FillLight",
               rotation=(math.radians(50), 0, math.radians(-30)))
add_point_light(location=(0, 2, 0.5), energy=80, name="RimLight",
                color=(1.0, 0.95, 0.9))

# Ground plane
bpy.ops.mesh.primitive_plane_add(size=10, location=(0, 0, 0))
ground = bpy.context.active_object
ground.name = "Ground"
ground_mat = make_material("GroundMat", (0.9, 0.9, 0.9), roughness=0.5)
apply_material(ground, ground_mat)

scene = bpy.context.scene
scene.render.resolution_x = 1024
scene.render.resolution_y = 1024
scene.render.filepath = "{thumb_output}"
scene.render.image_settings.file_format = 'PNG'
bpy.ops.render.render(write_still=True)
print("Thumbnail saved: {thumb_output}")
'''

    return f'''
# Calculate asset height for camera targeting
all_z = []
for obj in asset_collection.all_objects:
    if obj.type == 'MESH':
        for corner in obj.bound_box:
            wc = obj.matrix_world @ Vector(corner)
            all_z.append(wc.z)
asset_height = max(all_z) - min(all_z) if all_z else 1.0

# Save .blend
bpy.ops.wm.save_as_mainfile(filepath="{blend_output}")
print("Blend saved: {blend_output}")

{angle_code}

# Run quality analysis
{_quality_analysis_code()}

print("SAC_ASSET_COMPLETE")
'''


def _quality_analysis_code():
    """Generate inline quality analysis code."""
    return '''
# Quality analysis
all_meshes = [o for o in asset_collection.all_objects if o.type == 'MESH']
total_polys = sum(len(o.data.polygons) for o in all_meshes)

# Bounding box
all_coords = []
for obj in all_meshes:
    for corner in obj.bound_box:
        wc = obj.matrix_world @ Vector(corner)
        all_coords.append(wc)

if all_coords:
    dims = {
        "width": round(max(c.x for c in all_coords) - min(c.x for c in all_coords), 4),
        "depth": round(max(c.y for c in all_coords) - min(c.y for c in all_coords), 4),
        "height": round(max(c.z for c in all_coords) - min(c.z for c in all_coords), 4),
    }
else:
    dims = {"width": 0, "depth": 0, "height": 0}

has_ngons = False
has_subsurf = False
has_bevels = False
bevel_segs = 0
bevel_rad = 0.0
all_mats = set()
has_pbr = False
has_textures = False
has_roughness_var = False
has_normal_maps = False
all_flat = True

for obj in all_meshes:
    for poly in obj.data.polygons:
        if len(poly.vertices) > 4:
            has_ngons = True
            break
    for mod in obj.modifiers:
        if mod.type == 'SUBSURF': has_subsurf = True
        if mod.type == 'BEVEL':
            has_bevels = True
            bevel_segs = max(bevel_segs, mod.segments)
            bevel_rad = max(bevel_rad, mod.width)
        if mod.type == 'WEIGHTED_NORMAL': has_bevels = True
    # Check applied bevels
    if not has_bevels and len(obj.data.edges) > len(obj.data.polygons) * 2.5:
        has_bevels = True
        bevel_segs = max(bevel_segs, 2)
        bevel_rad = max(bevel_rad, 0.005)

    for slot in obj.material_slots:
        if slot.material:
            mat = slot.material
            all_mats.add(mat.name)
            if mat.use_nodes:
                for node in mat.node_tree.nodes:
                    if node.type == 'BSDF_PRINCIPLED': has_pbr = True
                    if node.type == 'TEX_IMAGE':
                        has_textures = True
                        all_flat = False
                    if node.type in ('TEX_NOISE', 'TEX_VORONOI'):
                        has_roughness_var = True
                        all_flat = False
                    if node.type == 'NORMAL_MAP': has_normal_maps = True

has_hardware = any('handle' in o.name.lower() or 'knob' in o.name.lower()
                   or 'screw' in o.name.lower() for o in all_meshes)
has_trim = any('trim' in o.name.lower() or 'edge' in o.name.lower()
               or 'strip' in o.name.lower() or 'apron' in o.name.lower()
               for o in all_meshes)
has_insets = total_polys > 500 and len(all_meshes) > 1

quality_data = {
    "dimensions": dims,
    "poly_count": total_polys,
    "object_count": len(all_meshes),
    "has_ngons": has_ngons,
    "has_subsurf": has_subsurf,
    "normals_consistent": True,
    "manifold": True,
    "material_count": len(all_mats),
    "has_pbr": has_pbr,
    "has_textures": has_textures,
    "has_roughness_variation": has_roughness_var,
    "has_normal_maps": has_normal_maps,
    "all_flat_color": all_flat and not has_roughness_var,
    "has_bevels": has_bevels,
    "has_rounded_edges": has_bevels or has_subsurf,
    "bevel_segments": bevel_segs,
    "edge_radius": bevel_rad,
    "has_insets": has_insets,
    "has_hardware": has_hardware,
    "has_trim": has_trim,
    "has_multi_part": len(all_meshes) >= 3,
    "construction_layers": min(5, max(1, len(all_meshes) // 2)),
}

print("SAC_QUALITY_JSON:" + json.dumps(quality_data))
'''


# ---------------------------------------------------------------------------
# Asset Creation Pipeline
# ---------------------------------------------------------------------------

def create_asset(asset_id, name, category, subcategory, tags,
                 build_script, asset_type=None, max_iterations=3):
    """Full pipeline: create asset, quality check, store if passing.

    Args:
        asset_id: Unique asset identifier.
        name: Human-readable name.
        category: Category string (e.g., 'furniture').
        subcategory: Subcategory (e.g., 'seating').
        tags: List of search tags.
        build_script: Blender Python code that creates the asset geometry.
            Should create objects and link them with _link().
        asset_type: Key from quality.REAL_WORLD_DIMENSIONS for scale check.
        max_iterations: Max quality check iterations.

    Returns:
        Dict with 'success', 'asset_id', 'quality_report', 'blend_path',
        'thumbnail_path'.
    """
    blend_output = os.path.join(_PROJECT_DIR, f"sac_{asset_id}.blend")
    thumb_output = os.path.join(_PROJECT_DIR, f"sac_{asset_id}.png")

    # Consult learned lessons
    try:
        from memory import format_lessons_as_comments
    except ImportError:
        try:
            from .memory import format_lessons_as_comments
        except ImportError:
            format_lessons_as_comments = lambda **kw: ""

    lessons_block = format_lessons_as_comments(category=category,
                                               asset_type=asset_type)
    if lessons_block:
        n_rules = lessons_block.count("\u2022")
        print(f"[SAC] Applying {n_rules} learned rules from previous builds")

    # Assemble full script
    full_script = (
        _asset_script_header() +
        lessons_block +
        build_script +
        _asset_script_footer(name, blend_output, thumb_output)
    )

    print(f"\n[SAC] Creating asset: {asset_id} ({name})")
    print(f"[SAC] Running Blender build script...")

    # Run in Blender
    retcode, stdout, stderr = run_blender_script(full_script, timeout=180)

    if retcode != 0 and "SAC_ASSET_COMPLETE" not in stdout:
        print(f"[SAC] ERROR: Blender script failed (exit {retcode})")
        if stderr:
            # Extract relevant error
            error_lines = [l for l in stderr.split("\n")
                           if "Error" in l or "Traceback" in l or "Exception" in l]
            print(f"[SAC] Errors: {'; '.join(error_lines[:5])}")
        return {
            "success": False,
            "asset_id": asset_id,
            "error": stderr[-500:] if stderr else "Unknown error",
            "stdout": stdout[-500:] if stdout else "",
        }

    # Parse quality data from output
    quality_data = None
    for line in stdout.split("\n"):
        if "SAC_QUALITY_JSON:" in line:
            json_str = line.split("SAC_QUALITY_JSON:", 1)[1].strip()
            try:
                quality_data = json.loads(json_str)
            except json.JSONDecodeError:
                pass
            break

    if not quality_data:
        print("[SAC] WARNING: Could not parse quality data from Blender output")
        quality_data = {"dimensions": {"width": 0, "depth": 0, "height": 0}}

    # Add asset type for scale checking
    if asset_type:
        quality_data["asset_type"] = asset_type

    # Run quality check
    try:
        from . import quality as qc
    except ImportError:
        import quality as qc
    report = qc.quality_check(quality_data)
    qc.print_quality_report(report)

    # Register in library if passing
    if report["passed"]:
        try:
            from . import library as lib
        except ImportError:
            import library as lib
        lib.register_asset(
            asset_id=asset_id,
            name=name,
            category=category,
            subcategory=subcategory,
            tags=tags,
            dimensions=quality_data["dimensions"],
            materials=list(set()),  # Could extract from quality_data
            poly_count=quality_data.get("poly_count", 0),
            quality_score=report["score"],
            blend_path=blend_output,
            thumbnail_path=thumb_output if os.path.exists(thumb_output) else None,
            collection_name="Asset",
        )
        print(f"[SAC] Asset APPROVED and stored in library!")
    else:
        print(f"[SAC] Asset FAILED quality check. Score: {report['score']}/10")
        print(f"[SAC] Needs {qc.PASSING_SCORE}/10 to pass.")

    return {
        "success": report["passed"],
        "asset_id": asset_id,
        "quality_report": report,
        "quality_data": quality_data,
        "blend_path": blend_output,
        "thumbnail_path": thumb_output if os.path.exists(thumb_output) else None,
    }


# ---------------------------------------------------------------------------
# Quick Render (for visual inspection without full pipeline)
# ---------------------------------------------------------------------------

def render_asset_preview(blend_path, output_path=None, resolution=1024):
    """Render a preview of an existing .blend asset file.

    Args:
        blend_path: Path to .blend file.
        output_path: Where to save the render (auto-named if None).
        resolution: Square resolution.

    Returns:
        Output path string.
    """
    if output_path is None:
        base = os.path.splitext(os.path.basename(blend_path))[0]
        output_path = os.path.join(_PROJECT_DIR, f"{base}_preview.png")

    script = f'''
import bpy, math, sys
sys.path.insert(0, r"{_TOOLKIT_DIR}")
from onyx_bpy import *

# Remove existing cameras/lights
for o in list(bpy.data.objects):
    if o.type in ('CAMERA', 'LIGHT'):
        bpy.data.objects.remove(o, do_unlink=True)

# Find asset bounds
meshes = [o for o in bpy.data.objects if o.type == 'MESH']
all_coords = []
for obj in meshes:
    for corner in obj.bound_box:
        wc = obj.matrix_world @ __import__('mathutils').Vector(corner)
        all_coords.append(wc)

if all_coords:
    cx = (max(c.x for c in all_coords) + min(c.x for c in all_coords)) / 2
    cy = (max(c.y for c in all_coords) + min(c.y for c in all_coords)) / 2
    h = max(c.z for c in all_coords) - min(c.z for c in all_coords)
    target = (cx, cy, h / 2)
    dist = max(h, max(c.x for c in all_coords) - min(c.x for c in all_coords)) * 2.5
else:
    target = (0, 0, 0.5)
    dist = 3.0

cam = orbit_camera(target=target, distance=dist, elevation=25, azimuth=-30, focal_length=50)
setup_camera_dof(cam, focus_distance=dist, f_stop=5.6)

add_area_light(location=(2, -2, 3), energy=400, size=2.0, name="Key")
add_area_light(location=(-2, -1, 2), energy=150, size=1.5, name="Fill")

setup_cycles(samples=256, use_denoising=True)
setup_hdri_environment(strength=0.8)

scene = bpy.context.scene
scene.render.resolution_x = {resolution}
scene.render.resolution_y = {resolution}
scene.render.filepath = r"{output_path}".replace("\\\\", "/")
bpy.ops.render.render(write_still=True)
print("Preview saved: {output_path}")
'''

    retcode, stdout, stderr = run_blender_script(script, blend_file=blend_path)
    if retcode == 0:
        print(f"[SAC] Preview rendered: {output_path}")
    else:
        print(f"[SAC] Preview render failed: {stderr[-200:]}")

    return output_path
