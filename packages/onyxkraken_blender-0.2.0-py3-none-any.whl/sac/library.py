"""
SAC Library — Asset library manager for storing, searching, and loading
photorealistic 1:1 scale Blender assets.

Storage layout:
    asset_library/
    ├── manifest.json        (catalog of all assets)
    ├── blends/              (.blend files, one per asset)
    │   └── {asset_id}.blend
    └── thumbnails/          (rendered preview images)
        └── {asset_id}.png

Manifest entry format:
{
    "id": "dining_chair_modern_01",
    "name": "Modern Dining Chair",
    "category": "furniture",
    "subcategory": "seating",
    "tags": ["chair", "dining", "modern", "wood"],
    "dimensions": {"width": 0.45, "depth": 0.50, "height": 0.85},
    "materials": ["oak_wood", "fabric_cream"],
    "poly_count": 12400,
    "quality_score": 8.5,
    "created": "2026-02-11T11:30:00",
    "blend_file": "dining_chair_modern_01.blend",
    "thumbnail": "dining_chair_modern_01.png",
    "collection_name": "Asset"
}
"""

import json
import os
import re
import shutil
from datetime import datetime

# Library paths
_BLENDER_TOOLKIT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LIBRARY_DIR = os.path.join(_BLENDER_TOOLKIT_DIR, "asset_library")
BLENDS_DIR = os.path.join(LIBRARY_DIR, "blends")
THUMBS_DIR = os.path.join(LIBRARY_DIR, "thumbnails")
MANIFEST_PATH = os.path.join(LIBRARY_DIR, "manifest.json")

# Ensure dirs exist
for d in [LIBRARY_DIR, BLENDS_DIR, THUMBS_DIR]:
    os.makedirs(d, exist_ok=True)


# ---------------------------------------------------------------------------
# Manifest I/O
# ---------------------------------------------------------------------------

def _load_manifest():
    """Load the asset manifest from disk."""
    if os.path.exists(MANIFEST_PATH):
        with open(MANIFEST_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"assets": {}, "version": 1}


def _save_manifest(manifest):
    """Save the asset manifest to disk."""
    with open(MANIFEST_PATH, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)


# ---------------------------------------------------------------------------
# Asset Registration
# ---------------------------------------------------------------------------

def register_asset(asset_id, name, category, subcategory,
                   tags, dimensions, materials, poly_count,
                   quality_score, blend_path, thumbnail_path=None,
                   collection_name="Asset"):
    """Register a new asset in the library.

    Copies the .blend file and optional thumbnail into the library
    directory and adds an entry to the manifest.

    Args:
        asset_id: Unique identifier (e.g., 'dining_chair_modern_01').
        name: Human-readable name.
        category: Top-level category ('furniture', 'prop', 'fixture', etc.).
        subcategory: Sub-category ('seating', 'table', 'lighting', etc.).
        tags: List of searchable tags.
        dimensions: Dict with 'width', 'depth', 'height' in meters.
        materials: List of material description strings.
        poly_count: Total polygon count.
        quality_score: Quality score 0-10 from Ramsay checker.
        blend_path: Path to the source .blend file.
        thumbnail_path: Path to rendered thumbnail (optional).
        collection_name: Name of the collection inside the .blend file.

    Returns:
        The asset entry dict.
    """
    manifest = _load_manifest()

    # Copy .blend file
    blend_dest = os.path.join(BLENDS_DIR, f"{asset_id}.blend")
    if os.path.abspath(blend_path) != os.path.abspath(blend_dest):
        shutil.copy2(blend_path, blend_dest)

    # Copy thumbnail if provided
    thumb_filename = None
    if thumbnail_path and os.path.exists(thumbnail_path):
        thumb_filename = f"{asset_id}.png"
        thumb_dest = os.path.join(THUMBS_DIR, thumb_filename)
        if os.path.abspath(thumbnail_path) != os.path.abspath(thumb_dest):
            shutil.copy2(thumbnail_path, thumb_dest)

    entry = {
        "id": asset_id,
        "name": name,
        "category": category,
        "subcategory": subcategory,
        "tags": tags,
        "dimensions": dimensions,
        "materials": materials,
        "poly_count": poly_count,
        "quality_score": quality_score,
        "created": datetime.now().isoformat(),
        "blend_file": f"{asset_id}.blend",
        "thumbnail": thumb_filename,
        "collection_name": collection_name,
    }

    manifest["assets"][asset_id] = entry
    _save_manifest(manifest)

    print(f"[SAC Library] Registered asset: {asset_id} ({name})")
    return entry


def remove_asset(asset_id):
    """Remove an asset from the library.

    Deletes the .blend file, thumbnail, and manifest entry.

    Args:
        asset_id: Asset to remove.

    Returns:
        True if removed, False if not found.
    """
    manifest = _load_manifest()
    if asset_id not in manifest["assets"]:
        return False

    entry = manifest["assets"][asset_id]

    # Delete files
    blend_path = os.path.join(BLENDS_DIR, entry["blend_file"])
    if os.path.exists(blend_path):
        os.remove(blend_path)

    if entry.get("thumbnail"):
        thumb_path = os.path.join(THUMBS_DIR, entry["thumbnail"])
        if os.path.exists(thumb_path):
            os.remove(thumb_path)

    del manifest["assets"][asset_id]
    _save_manifest(manifest)

    print(f"[SAC Library] Removed asset: {asset_id}")
    return True


# ---------------------------------------------------------------------------
# Asset Search
# ---------------------------------------------------------------------------

def list_assets(category=None, subcategory=None):
    """List all assets, optionally filtered by category.

    Args:
        category: Filter by category (e.g., 'furniture').
        subcategory: Filter by subcategory (e.g., 'seating').

    Returns:
        List of asset entry dicts.
    """
    manifest = _load_manifest()
    results = list(manifest["assets"].values())

    if category:
        results = [a for a in results if a["category"] == category]
    if subcategory:
        results = [a for a in results if a["subcategory"] == subcategory]

    return results


def search_assets(query, category=None, min_quality=0.0):
    """Search assets by keyword matching against name, tags, and category.

    Args:
        query: Search string (matched against name, tags, category, subcategory).
        category: Optional category filter.
        min_quality: Minimum quality score filter.

    Returns:
        List of matching asset entry dicts, sorted by relevance.
    """
    manifest = _load_manifest()
    query_lower = query.lower()
    query_words = query_lower.split()

    scored = []
    for entry in manifest["assets"].values():
        if category and entry["category"] != category:
            continue
        if entry["quality_score"] < min_quality:
            continue

        # Score by keyword matches
        score = 0
        searchable = (
            entry["name"].lower() + " " +
            entry["category"].lower() + " " +
            entry["subcategory"].lower() + " " +
            " ".join(entry["tags"]).lower()
        )

        for word in query_words:
            if word in searchable:
                score += 1
            # Exact tag match bonus
            if word in [t.lower() for t in entry["tags"]]:
                score += 2
            # Name contains bonus
            if word in entry["name"].lower():
                score += 3

        if score > 0:
            scored.append((score, entry))

    scored.sort(key=lambda x: (-x[0], -x[1]["quality_score"]))
    return [entry for _, entry in scored]


def find_asset(asset_id):
    """Get a specific asset by ID.

    Args:
        asset_id: Asset identifier.

    Returns:
        Asset entry dict, or None if not found.
    """
    manifest = _load_manifest()
    return manifest["assets"].get(asset_id)


def get_asset_blend_path(asset_id):
    """Get the .blend file path for an asset.

    Args:
        asset_id: Asset identifier.

    Returns:
        Absolute path to .blend file, or None.
    """
    entry = find_asset(asset_id)
    if entry:
        path = os.path.join(BLENDS_DIR, entry["blend_file"])
        if os.path.exists(path):
            return path
    return None


def get_asset_thumbnail_path(asset_id):
    """Get the thumbnail path for an asset.

    Args:
        asset_id: Asset identifier.

    Returns:
        Absolute path to thumbnail, or None.
    """
    entry = find_asset(asset_id)
    if entry and entry.get("thumbnail"):
        path = os.path.join(THUMBS_DIR, entry["thumbnail"])
        if os.path.exists(path):
            return path
    return None


# ---------------------------------------------------------------------------
# Asset Loading (for use inside Blender scripts)
# ---------------------------------------------------------------------------

def load_asset_script(asset_id, location=(0, 0, 0), rotation=(0, 0, 0),
                      scale=(1, 1, 1)):
    """Generate a Blender Python script to load an asset from the library.

    This returns a string of Python code that can be executed inside Blender
    to append the asset collection and place it at the desired location.

    Args:
        asset_id: Asset to load.
        location: (x, y, z) placement.
        rotation: (rx, ry, rz) Euler rotation in radians.
        scale: (sx, sy, sz) scale factors.

    Returns:
        Python code string, or None if asset not found.
    """
    entry = find_asset(asset_id)
    if not entry:
        return None

    blend_path = os.path.join(BLENDS_DIR, entry["blend_file"])
    collection_name = entry.get("collection_name", "Asset")

    script = f'''
import bpy
from mathutils import Vector, Euler

# Append asset collection from library
blend_path = r"{blend_path}"
collection_name = "{collection_name}"

with bpy.data.libraries.load(blend_path, link=False) as (data_from, data_to):
    if collection_name in data_from.collections:
        data_to.collections = [collection_name]
    else:
        data_to.objects = data_from.objects

# Link to scene
if data_to.collections:
    for coll in data_to.collections:
        if coll is not None:
            bpy.context.scene.collection.children.link(coll)
            # Position all objects in the collection
            for obj in coll.all_objects:
                obj.location += Vector({location})
                obj.rotation_euler.x += {rotation[0]}
                obj.rotation_euler.y += {rotation[1]}
                obj.rotation_euler.z += {rotation[2]}
                obj.scale = ({scale[0]}, {scale[1]}, {scale[2]})
elif data_to.objects:
    for obj in data_to.objects:
        if obj is not None:
            bpy.context.collection.objects.link(obj)
            obj.location = Vector({location})

print("[SAC] Loaded asset: {asset_id}")
'''
    return script


def get_load_code(asset_id, location=(0, 0, 0), rotation_z=0.0):
    """Get compact Python code to load and place an asset.

    For use inside onyx_bpy build scripts.

    Args:
        asset_id: Asset to load.
        location: (x, y, z) placement.
        rotation_z: Z rotation in radians.

    Returns:
        Python code string.
    """
    entry = find_asset(asset_id)
    if not entry:
        raise ValueError(f"Asset '{asset_id}' not found in library")

    blend_path = os.path.join(BLENDS_DIR, entry["blend_file"]).replace("\\", "/")
    coll = entry.get("collection_name", "Asset")

    return (
        f"_load_library_asset(r'{blend_path}', '{coll}', "
        f"location={location}, rotation_z={rotation_z})"
    )


# ---------------------------------------------------------------------------
# Library Stats
# ---------------------------------------------------------------------------

def library_stats():
    """Get statistics about the asset library.

    Returns:
        Dict with counts, categories, total size, etc.
    """
    manifest = _load_manifest()
    assets = manifest["assets"]

    categories = {}
    total_polys = 0
    total_size = 0

    for entry in assets.values():
        cat = entry["category"]
        categories[cat] = categories.get(cat, 0) + 1
        total_polys += entry.get("poly_count", 0)

        blend_path = os.path.join(BLENDS_DIR, entry["blend_file"])
        if os.path.exists(blend_path):
            total_size += os.path.getsize(blend_path)

    return {
        "total_assets": len(assets),
        "categories": categories,
        "total_polys": total_polys,
        "total_size_mb": round(total_size / (1024 * 1024), 2),
        "avg_quality": (
            round(sum(a["quality_score"] for a in assets.values()) / len(assets), 1)
            if assets else 0
        ),
    }


def print_library():
    """Print a formatted summary of the asset library."""
    stats = library_stats()
    manifest = _load_manifest()

    print(f"\n{'='*60}")
    print(f"  SAC Asset Library — {stats['total_assets']} assets")
    print(f"  Size: {stats['total_size_mb']} MB | "
          f"Avg Quality: {stats['avg_quality']}/10")
    print(f"{'='*60}")

    for cat, count in sorted(stats["categories"].items()):
        print(f"\n  [{cat.upper()}] ({count} assets)")
        for entry in sorted(manifest["assets"].values(),
                            key=lambda x: x["name"]):
            if entry["category"] == cat:
                dims = entry["dimensions"]
                print(f"    • {entry['name']:<30s}  "
                      f"{dims['width']:.2f}×{dims['depth']:.2f}×"
                      f"{dims['height']:.2f}m  "
                      f"Q:{entry['quality_score']:.1f}")

    print(f"\n{'='*60}\n")
