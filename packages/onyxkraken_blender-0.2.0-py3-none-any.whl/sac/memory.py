"""SAC Memory — Learning & Knowledge Base.

Onyx learns from every build:
  - Quality scores and feedback per asset type
  - Manual adjustments the user makes (compared via Blender diff)
  - Technique preferences (what works, what doesn't)
  - Build history for trend analysis

Storage: asset_library/knowledge/
  - lessons.json      — accumulated lessons (technique prefs, corrections)
  - build_history.json — every build attempt with scores and feedback
  - adjustments/      — recorded user corrections to assets
"""

import json
import os
import subprocess
import sys
from datetime import datetime

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_TOOLKIT_DIR = os.path.dirname(_THIS_DIR)
_KNOWLEDGE_DIR = os.path.join(_TOOLKIT_DIR, "asset_library", "knowledge")
_ADJUSTMENTS_DIR = os.path.join(_KNOWLEDGE_DIR, "adjustments")
_LESSONS_PATH = os.path.join(_KNOWLEDGE_DIR, "lessons.json")
_HISTORY_PATH = os.path.join(_KNOWLEDGE_DIR, "build_history.json")

for d in [_KNOWLEDGE_DIR, _ADJUSTMENTS_DIR]:
    os.makedirs(d, exist_ok=True)


# ── Blender executable discovery — delegated to config.find_blender_exe()
try:
    from config import find_blender_exe as _find_blender
except ImportError:
    # Direct-run fallback
    def _find_blender():
        for p in [
            r"C:\Program Files\Blender Foundation\Blender 3.2\blender.exe",
            r"C:\Program Files\Blender Foundation\Blender 4.0\blender.exe",
        ]:
            if os.path.exists(p):
                return p
        return "blender"


# ═══════════════════════════════════════════════════════════════════
# LESSONS — What Onyx has learned
# ═══════════════════════════════════════════════════════════════════

def _load_lessons():
    """Load the lessons knowledge base."""
    if os.path.exists(_LESSONS_PATH):
        with open(_LESSONS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "global_rules": [],          # apply to ALL builds
        "category_rules": {},        # apply to builds in a category (e.g., furniture)
        "asset_type_rules": {},      # apply to specific asset types (e.g., dining_chair)
        "technique_notes": [],       # general technique knowledge
        "material_preferences": {},  # learned material settings
        "dimension_overrides": {},   # corrected real-world dimensions
    }


def _save_lessons(lessons):
    """Save lessons to disk."""
    with open(_LESSONS_PATH, "w", encoding="utf-8") as f:
        json.dump(lessons, f, indent=2, default=str)


def add_lesson(lesson_text, scope="global", scope_key=None, source="user"):
    """Add a lesson to the knowledge base.

    Args:
        lesson_text: What was learned (natural language).
        scope: 'global', 'category', 'asset_type', or 'technique'.
        scope_key: For category/asset_type scope, the key (e.g., 'dining_chair').
        source: 'user' (manual), 'adjustment' (from diff), 'quality' (from checks).
    """
    lessons = _load_lessons()
    entry = {
        "text": lesson_text,
        "source": source,
        "timestamp": datetime.now().isoformat(),
    }

    if scope == "global":
        lessons["global_rules"].append(entry)
    elif scope == "category" and scope_key:
        lessons["category_rules"].setdefault(scope_key, []).append(entry)
    elif scope == "asset_type" and scope_key:
        lessons["asset_type_rules"].setdefault(scope_key, []).append(entry)
    elif scope == "technique":
        lessons["technique_notes"].append(entry)

    _save_lessons(lessons)
    print(f"[SAC Memory] Learned: {lesson_text[:80]}...")
    return entry


def add_material_preference(material_name, settings, asset_type=None):
    """Record a preferred material configuration.

    Args:
        material_name: e.g., 'oak_wood', 'fabric_seat'.
        settings: dict of material settings (color, roughness, etc.).
        asset_type: optional — limit to specific asset type.
    """
    lessons = _load_lessons()
    key = f"{asset_type}:{material_name}" if asset_type else material_name
    lessons["material_preferences"][key] = {
        "settings": settings,
        "timestamp": datetime.now().isoformat(),
    }
    _save_lessons(lessons)
    print(f"[SAC Memory] Material preference saved: {key}")


def add_dimension_override(asset_type, dimension, value, unit="m"):
    """Record a corrected real-world dimension.

    Args:
        asset_type: e.g., 'dining_chair'.
        dimension: e.g., 'backrest_height', 'seat_height'.
        value: the corrected value.
        unit: measurement unit (default 'm').
    """
    lessons = _load_lessons()
    lessons["dimension_overrides"].setdefault(asset_type, {})[dimension] = {
        "value": value,
        "unit": unit,
        "timestamp": datetime.now().isoformat(),
    }
    _save_lessons(lessons)
    print(f"[SAC Memory] Dimension override: {asset_type}.{dimension} = {value}{unit}")


def get_lessons_for_build(category=None, asset_type=None):
    """Retrieve all relevant lessons for a build.

    Returns lessons in priority order:
    1. Global rules (always apply)
    2. Category rules (if category matches)
    3. Asset type rules (if asset type matches)
    4. Dimension overrides
    5. Material preferences

    Returns:
        dict with 'rules' (list of text), 'dimensions' (dict), 'materials' (dict).
    """
    lessons = _load_lessons()
    result = {
        "rules": [],
        "dimensions": {},
        "materials": {},
    }

    # Global rules always apply
    for rule in lessons.get("global_rules", []):
        result["rules"].append(rule["text"])

    # Category rules
    if category and category in lessons.get("category_rules", {}):
        for rule in lessons["category_rules"][category]:
            result["rules"].append(rule["text"])

    # Asset type rules
    if asset_type and asset_type in lessons.get("asset_type_rules", {}):
        for rule in lessons["asset_type_rules"][asset_type]:
            result["rules"].append(rule["text"])

    # Dimension overrides
    if asset_type and asset_type in lessons.get("dimension_overrides", {}):
        result["dimensions"] = lessons["dimension_overrides"][asset_type]

    # Material preferences
    for key, pref in lessons.get("material_preferences", {}).items():
        # Match both global materials and asset-specific ones
        if ":" not in key or key.startswith(f"{asset_type}:"):
            mat_name = key.split(":")[-1] if ":" in key else key
            result["materials"][mat_name] = pref["settings"]

    return result


def format_lessons_as_comments(category=None, asset_type=None):
    """Format lessons as Python comments to inject into build scripts.

    Returns a string of comments that can be prepended to a build script.
    """
    data = get_lessons_for_build(category, asset_type)

    if not data["rules"] and not data["dimensions"] and not data["materials"]:
        return ""

    lines = ["# ═══ SAC LEARNED RULES (from previous builds) ═══"]

    if data["rules"]:
        lines.append("# Build Rules:")
        for rule in data["rules"]:
            # Wrap long rules
            for line in rule.split("\n"):
                lines.append(f"#   • {line}")

    if data["dimensions"]:
        lines.append("# Dimension Corrections:")
        for dim, info in data["dimensions"].items():
            lines.append(f"#   • {dim} = {info['value']}{info['unit']}")

    if data["materials"]:
        lines.append("# Material Preferences:")
        for mat, settings in data["materials"].items():
            desc = ", ".join(f"{k}={v}" for k, v in settings.items())
            lines.append(f"#   • {mat}: {desc}")

    lines.append("# ═══════════════════════════════════════════════\n")
    return "\n".join(lines) + "\n"


# ═══════════════════════════════════════════════════════════════════
# BUILD HISTORY — Track every build attempt
# ═══════════════════════════════════════════════════════════════════

def _load_history():
    if os.path.exists(_HISTORY_PATH):
        with open(_HISTORY_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"builds": []}


def _save_history(history):
    with open(_HISTORY_PATH, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2, default=str)


def record_build(asset_id, name, category, asset_type, quality_score,
                 passed, feedback, build_mode="detailed", duration_s=None):
    """Record a build attempt in history.

    Args:
        asset_id: Asset identifier.
        name: Human-readable name.
        category: Asset category.
        asset_type: Specific type (e.g., 'dining_chair').
        quality_score: Score from quality checker.
        passed: Whether it passed quality check.
        feedback: List of quality feedback strings.
        build_mode: 'quick' or 'detailed'.
        duration_s: Build time in seconds.
    """
    history = _load_history()
    entry = {
        "asset_id": asset_id,
        "name": name,
        "category": category,
        "asset_type": asset_type,
        "quality_score": quality_score,
        "passed": passed,
        "feedback": feedback,
        "build_mode": build_mode,
        "duration_s": duration_s,
        "timestamp": datetime.now().isoformat(),
    }
    history["builds"].append(entry)
    _save_history(history)
    return entry


def get_build_stats(category=None, asset_type=None):
    """Get statistics for builds, optionally filtered.

    Returns:
        dict with count, avg_score, pass_rate, common_issues.
    """
    history = _load_history()
    builds = history.get("builds", [])

    if category:
        builds = [b for b in builds if b.get("category") == category]
    if asset_type:
        builds = [b for b in builds if b.get("asset_type") == asset_type]

    if not builds:
        return {"count": 0, "avg_score": 0, "pass_rate": 0, "common_issues": []}

    scores = [b["quality_score"] for b in builds]
    passed = sum(1 for b in builds if b["passed"])

    # Count common issues
    issue_counts = {}
    for b in builds:
        for fb in b.get("feedback", []):
            issue_counts[fb] = issue_counts.get(fb, 0) + 1

    common = sorted(issue_counts.items(), key=lambda x: -x[1])[:5]

    return {
        "count": len(builds),
        "avg_score": round(sum(scores) / len(scores), 1),
        "pass_rate": round(passed / len(builds) * 100, 1),
        "common_issues": [{"issue": k, "count": v} for k, v in common],
        "best_score": max(scores),
        "worst_score": min(scores),
    }


# ═══════════════════════════════════════════════════════════════════
# ADJUSTMENT TRACKING — Learn from user corrections
# ═══════════════════════════════════════════════════════════════════

def _diff_script():
    """Blender Python script that compares two .blend files and outputs diffs."""
    return r'''
import bpy
import json
import sys
import math

# Args: original.blend, adjusted.blend
argv = sys.argv
idx = argv.index("--") + 1
original_path = argv[idx]
adjusted_path = argv[idx + 1]

def snapshot_scene(filepath):
    """Load a .blend and capture object states."""
    bpy.ops.wm.open_mainfile(filepath=filepath)
    data = {}
    for obj in bpy.data.objects:
        if obj.type not in ('MESH', 'CURVE', 'SURFACE'):
            continue
        entry = {
            "type": obj.type,
            "location": list(obj.location),
            "rotation": list(obj.rotation_euler),
            "scale": list(obj.scale),
        }
        if obj.type == 'MESH':
            entry["vertex_count"] = len(obj.data.vertices)
            entry["face_count"] = len(obj.data.polygons)
            # Bounding box dimensions
            bb = obj.bound_box
            xs = [v[0] for v in bb]
            ys = [v[1] for v in bb]
            zs = [v[2] for v in bb]
            entry["bbox_size"] = [
                round(max(xs) - min(xs), 4),
                round(max(ys) - min(ys), 4),
                round(max(zs) - min(zs), 4),
            ]
            # World-space bounding box
            ws = [obj.matrix_world @ Vector(v) for v in bb]
            wxs = [v.x for v in ws]
            wys = [v.y for v in ws]
            wzs = [v.z for v in ws]
            entry["world_bbox"] = {
                "min": [round(min(wxs), 4), round(min(wys), 4), round(min(wzs), 4)],
                "max": [round(max(wxs), 4), round(max(wys), 4), round(max(wzs), 4)],
            }
        # Materials
        entry["materials"] = []
        for slot in obj.material_slots:
            if slot.material:
                mat_data = {"name": slot.material.name}
                bsdf = slot.material.node_tree.nodes.get("Principled BSDF") if slot.material.node_tree else None
                if bsdf:
                    bc = bsdf.inputs.get("Base Color")
                    if bc:
                        mat_data["base_color"] = list(bc.default_value)[:3]
                    mat_data["roughness"] = bsdf.inputs.get("Roughness").default_value if bsdf.inputs.get("Roughness") else None
                    mat_data["metallic"] = bsdf.inputs.get("Metallic").default_value if bsdf.inputs.get("Metallic") else None
                entry["materials"].append(mat_data)
        # Modifiers
        entry["modifiers"] = [
            {"type": m.type, "name": m.name} for m in obj.modifiers
        ]
        data[obj.name] = entry
    return data

from mathutils import Vector

# Snapshot both
original = snapshot_scene(original_path)
adjusted = snapshot_scene(adjusted_path)

# Compare
diffs = []

# Objects in adjusted but not original (added)
for name in adjusted:
    if name not in original:
        diffs.append({
            "type": "added",
            "object": name,
            "details": adjusted[name],
        })

# Objects in original but not adjusted (removed)
for name in original:
    if name not in adjusted:
        diffs.append({
            "type": "removed",
            "object": name,
        })

# Objects in both — check for changes
def approx_eq(a, b, tol=0.001):
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        return all(abs(x - y) < tol for x, y in zip(a, b))
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return abs(a - b) < tol
    return a == b

for name in original:
    if name not in adjusted:
        continue
    orig = original[name]
    adj = adjusted[name]
    changes = {}

    # Location
    if not approx_eq(orig["location"], adj["location"]):
        changes["location"] = {
            "from": [round(v, 4) for v in orig["location"]],
            "to": [round(v, 4) for v in adj["location"]],
        }

    # Rotation
    if not approx_eq(orig["rotation"], adj["rotation"]):
        changes["rotation"] = {
            "from": [round(math.degrees(v), 2) for v in orig["rotation"]],
            "to": [round(math.degrees(v), 2) for v in adj["rotation"]],
        }

    # Scale
    if not approx_eq(orig["scale"], adj["scale"]):
        changes["scale"] = {
            "from": [round(v, 4) for v in orig["scale"]],
            "to": [round(v, 4) for v in adj["scale"]],
        }

    # Bounding box size (mesh edit)
    if "bbox_size" in orig and "bbox_size" in adj:
        if not approx_eq(orig["bbox_size"], adj["bbox_size"]):
            changes["dimensions"] = {
                "from": orig["bbox_size"],
                "to": adj["bbox_size"],
            }

    # Vertex/face count (topology change)
    if orig.get("vertex_count") != adj.get("vertex_count"):
        changes["vertex_count"] = {
            "from": orig.get("vertex_count"),
            "to": adj.get("vertex_count"),
        }
    if orig.get("face_count") != adj.get("face_count"):
        changes["face_count"] = {
            "from": orig.get("face_count"),
            "to": adj.get("face_count"),
        }

    # Materials
    orig_mats = {m["name"]: m for m in orig.get("materials", [])}
    adj_mats = {m["name"]: m for m in adj.get("materials", [])}
    mat_changes = {}
    for mname in set(list(orig_mats.keys()) + list(adj_mats.keys())):
        if mname in orig_mats and mname in adj_mats:
            om = orig_mats[mname]
            am = adj_mats[mname]
            mc = {}
            if not approx_eq(om.get("base_color", []), am.get("base_color", [])):
                mc["base_color"] = {"from": om.get("base_color"), "to": am.get("base_color")}
            if not approx_eq(om.get("roughness", 0), am.get("roughness", 0)):
                mc["roughness"] = {"from": om.get("roughness"), "to": am.get("roughness")}
            if not approx_eq(om.get("metallic", 0), am.get("metallic", 0)):
                mc["metallic"] = {"from": om.get("metallic"), "to": am.get("metallic")}
            if mc:
                mat_changes[mname] = mc
        elif mname in adj_mats and mname not in orig_mats:
            mat_changes[mname] = {"added": adj_mats[mname]}
        elif mname in orig_mats and mname not in adj_mats:
            mat_changes[mname] = {"removed": True}
    if mat_changes:
        changes["materials"] = mat_changes

    if changes:
        diffs.append({
            "type": "modified",
            "object": name,
            "changes": changes,
        })

output = {
    "original": original_path,
    "adjusted": adjusted_path,
    "diff_count": len(diffs),
    "diffs": diffs,
}
print("SAC_DIFF_JSON_START")
print(json.dumps(output, indent=2))
print("SAC_DIFF_JSON_END")
'''


def compare_blend_files(original_path, adjusted_path):
    """Compare two .blend files and return diffs.

    Uses Blender headless to open both files and diff object states.

    Args:
        original_path: Path to the original .blend file.
        adjusted_path: Path to the user-adjusted .blend file.

    Returns:
        dict with diffs, or None on failure.
    """
    blender = _find_blender()
    script = _diff_script()

    # Write temp script
    script_path = os.path.join(_KNOWLEDGE_DIR, "_diff_script.py")
    with open(script_path, "w", encoding="utf-8") as f:
        f.write(script)

    # Normalize paths
    original_path = original_path.replace("\\", "/")
    adjusted_path = adjusted_path.replace("\\", "/")

    cmd = [
        blender, "--background", "--python", script_path,
        "--", original_path, adjusted_path,
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        stdout = result.stdout

        # Parse diff JSON
        if "SAC_DIFF_JSON_START" in stdout and "SAC_DIFF_JSON_END" in stdout:
            json_str = stdout.split("SAC_DIFF_JSON_START")[1].split("SAC_DIFF_JSON_END")[0]
            return json.loads(json_str.strip())
        else:
            print(f"[SAC Memory] Could not parse diff output")
            print(f"  stdout: {stdout[-500:]}")
            print(f"  stderr: {result.stderr[-500:]}")
            return None
    except Exception as e:
        print(f"[SAC Memory] Diff failed: {e}")
        return None
    finally:
        if os.path.exists(script_path):
            os.remove(script_path)


def learn_from_adjustment(asset_id, original_blend, adjusted_blend,
                          category=None, asset_type=None, user_note=None):
    """Compare original and adjusted .blend, extract lessons, store them.

    This is the core learning function. It:
    1. Diffs the two .blend files
    2. Converts diffs into human-readable lessons
    3. Stores lessons in the knowledge base
    4. Saves the raw diff for future reference

    Args:
        asset_id: The asset that was adjusted.
        original_blend: Path to original .blend (before user edit).
        adjusted_blend: Path to adjusted .blend (after user edit).
        category: Asset category (e.g., 'furniture').
        asset_type: Asset type (e.g., 'dining_chair').
        user_note: Optional note from user about what they changed.

    Returns:
        dict with lessons extracted.
    """
    print(f"[SAC Memory] Analyzing adjustment to '{asset_id}'...")

    diff = compare_blend_files(original_blend, adjusted_blend)
    if not diff:
        print("[SAC Memory] Could not compute diff")
        # If user gave a note, still record it
        if user_note:
            add_lesson(
                user_note,
                scope="asset_type" if asset_type else "global",
                scope_key=asset_type,
                source="user",
            )
        return {"lessons": [user_note] if user_note else []}

    # Save raw diff
    diff_path = os.path.join(_ADJUSTMENTS_DIR, f"{asset_id}_diff.json")
    with open(diff_path, "w", encoding="utf-8") as f:
        json.dump(diff, f, indent=2)

    # Extract lessons from diffs
    lessons_extracted = []

    for d in diff.get("diffs", []):
        obj_name = d.get("object", "unknown")
        dtype = d.get("type")

        if dtype == "modified":
            changes = d.get("changes", {})

            # Location changes → positioning lesson
            if "location" in changes:
                loc_from = changes["location"]["from"]
                loc_to = changes["location"]["to"]
                delta = [round(t - f, 4) for f, t in zip(loc_from, loc_to)]
                axis_names = ["X", "Y", "Z"]
                moves = [f"{axis_names[i]}={delta[i]:+.4f}m"
                         for i in range(3) if abs(delta[i]) > 0.001]
                if moves:
                    lesson = (f"'{obj_name}' position adjusted: {', '.join(moves)}. "
                              f"Move {obj_name} by these offsets in future builds.")
                    lessons_extracted.append(lesson)
                    add_lesson(
                        lesson,
                        scope="asset_type" if asset_type else "category",
                        scope_key=asset_type or category,
                        source="adjustment",
                    )

            # Rotation changes → angle lesson
            if "rotation" in changes:
                rot_from = changes["rotation"]["from"]
                rot_to = changes["rotation"]["to"]
                delta = [round(t - f, 2) for f, t in zip(rot_from, rot_to)]
                axis_names = ["X", "Y", "Z"]
                rots = [f"{axis_names[i]}={delta[i]:+.2f}°"
                        for i in range(3) if abs(delta[i]) > 0.1]
                if rots:
                    lesson = (f"'{obj_name}' rotation adjusted: {', '.join(rots)}. "
                              f"Apply this rotation correction in future builds.")
                    lessons_extracted.append(lesson)
                    add_lesson(
                        lesson,
                        scope="asset_type" if asset_type else "category",
                        scope_key=asset_type or category,
                        source="adjustment",
                    )

            # Scale changes → sizing lesson
            if "scale" in changes:
                sc_from = changes["scale"]["from"]
                sc_to = changes["scale"]["to"]
                lesson = (f"'{obj_name}' scale changed from "
                          f"({sc_from[0]:.3f}, {sc_from[1]:.3f}, {sc_from[2]:.3f}) to "
                          f"({sc_to[0]:.3f}, {sc_to[1]:.3f}, {sc_to[2]:.3f}).")
                lessons_extracted.append(lesson)
                add_lesson(
                    lesson,
                    scope="asset_type" if asset_type else "category",
                    scope_key=asset_type or category,
                    source="adjustment",
                )

            # Dimension changes → mesh edit lesson
            if "dimensions" in changes:
                dim_from = changes["dimensions"]["from"]
                dim_to = changes["dimensions"]["to"]
                lesson = (f"'{obj_name}' mesh dimensions changed: "
                          f"W {dim_from[0]:.4f}→{dim_to[0]:.4f}m, "
                          f"D {dim_from[1]:.4f}→{dim_to[1]:.4f}m, "
                          f"H {dim_from[2]:.4f}→{dim_to[2]:.4f}m.")
                lessons_extracted.append(lesson)
                add_lesson(
                    lesson,
                    scope="asset_type" if asset_type else "category",
                    scope_key=asset_type or category,
                    source="adjustment",
                )

            # Material changes
            if "materials" in changes:
                for mat_name, mc in changes["materials"].items():
                    parts = []
                    if "base_color" in mc:
                        parts.append(f"color {mc['base_color']['from']} → {mc['base_color']['to']}")
                    if "roughness" in mc:
                        parts.append(f"roughness {mc['roughness']['from']} → {mc['roughness']['to']}")
                    if "metallic" in mc:
                        parts.append(f"metallic {mc['metallic']['from']} → {mc['metallic']['to']}")
                    if parts:
                        lesson = f"Material '{mat_name}' on '{obj_name}' adjusted: {'; '.join(parts)}."
                        lessons_extracted.append(lesson)
                        add_lesson(
                            lesson,
                            scope="asset_type" if asset_type else "category",
                            scope_key=asset_type or category,
                            source="adjustment",
                        )
                        # Also save as material preference
                        if "base_color" in mc or "roughness" in mc or "metallic" in mc:
                            settings = {}
                            if "base_color" in mc:
                                settings["base_color"] = mc["base_color"]["to"]
                            if "roughness" in mc:
                                settings["roughness"] = mc["roughness"]["to"]
                            if "metallic" in mc:
                                settings["metallic"] = mc["metallic"]["to"]
                            add_material_preference(mat_name, settings, asset_type)

        elif dtype == "added":
            lesson = (f"Object '{obj_name}' was ADDED to the asset. "
                      f"Include this in future builds of {asset_type or 'this type'}.")
            lessons_extracted.append(lesson)
            add_lesson(
                lesson,
                scope="asset_type" if asset_type else "global",
                scope_key=asset_type,
                source="adjustment",
            )

        elif dtype == "removed":
            lesson = (f"Object '{obj_name}' was REMOVED from the asset. "
                      f"Do not include this in future builds of {asset_type or 'this type'}.")
            lessons_extracted.append(lesson)
            add_lesson(
                lesson,
                scope="asset_type" if asset_type else "global",
                scope_key=asset_type,
                source="adjustment",
            )

    # Add user note if provided
    if user_note:
        add_lesson(
            user_note,
            scope="asset_type" if asset_type else "global",
            scope_key=asset_type,
            source="user",
        )
        lessons_extracted.append(user_note)

    print(f"[SAC Memory] Extracted {len(lessons_extracted)} lessons from adjustment")
    for i, l in enumerate(lessons_extracted):
        print(f"  {i+1}. {l[:100]}")

    return {
        "asset_id": asset_id,
        "diff_count": diff.get("diff_count", 0),
        "lessons": lessons_extracted,
        "diff_path": diff_path,
    }


def learn_from_quality_feedback(asset_id, asset_type, category,
                                 quality_report):
    """Extract lessons from a quality check report.

    If an asset fails or has specific feedback, record it so future builds
    avoid the same issues.
    """
    feedback = quality_report.get("feedback", [])
    score = quality_report.get("score", 0)

    # Only learn from failures or notable feedback
    if score >= 9.0 and not feedback:
        return  # Nothing to learn, it was great

    for fb in feedback:
        # Don't record generic success messages
        if "OK" in fb or "Scale OK" in fb:
            continue
        add_lesson(
            f"Quality feedback (score {score}): {fb}",
            scope="asset_type" if asset_type else "category",
            scope_key=asset_type or category,
            source="quality",
        )


# ═══════════════════════════════════════════════════════════════════
# KNOWLEDGE QUERY — What does Onyx know?
# ═══════════════════════════════════════════════════════════════════

def print_knowledge_summary():
    """Print a summary of everything Onyx has learned."""
    lessons = _load_lessons()
    history = _load_history()

    print("\n" + "=" * 60)
    print("  ONYX KNOWLEDGE SUMMARY")
    print("=" * 60)

    # Rules
    total_rules = len(lessons.get("global_rules", []))
    for cat_rules in lessons.get("category_rules", {}).values():
        total_rules += len(cat_rules)
    for type_rules in lessons.get("asset_type_rules", {}).values():
        total_rules += len(type_rules)
    print(f"\n  Rules learned:        {total_rules}")
    print(f"  Technique notes:      {len(lessons.get('technique_notes', []))}")
    print(f"  Material preferences: {len(lessons.get('material_preferences', {}))}")
    print(f"  Dimension overrides:  {sum(len(v) for v in lessons.get('dimension_overrides', {}).values())}")

    # Build history
    builds = history.get("builds", [])
    print(f"\n  Total builds:         {len(builds)}")
    if builds:
        scores = [b["quality_score"] for b in builds]
        passed = sum(1 for b in builds if b["passed"])
        print(f"  Average score:        {sum(scores)/len(scores):.1f}/10")
        print(f"  Pass rate:            {passed}/{len(builds)} ({passed/len(builds)*100:.0f}%)")

    # Category breakdown
    categories = set(b.get("category", "?") for b in builds)
    if categories:
        print(f"\n  Categories built:")
        for cat in sorted(categories):
            cat_builds = [b for b in builds if b.get("category") == cat]
            avg = sum(b["quality_score"] for b in cat_builds) / len(cat_builds)
            print(f"    {cat}: {len(cat_builds)} builds, avg {avg:.1f}/10")

    # Adjustments
    adj_files = [f for f in os.listdir(_ADJUSTMENTS_DIR) if f.endswith("_diff.json")]
    print(f"\n  User adjustments:     {len(adj_files)}")

    # Per-type rules
    if lessons.get("asset_type_rules"):
        print(f"\n  Type-specific rules:")
        for atype, rules in lessons["asset_type_rules"].items():
            print(f"    {atype}: {len(rules)} rules")

    print("=" * 60 + "\n")
