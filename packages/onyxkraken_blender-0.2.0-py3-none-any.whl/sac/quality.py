"""
SAC Quality Checker — The Gordon Ramsay Treatment.

Evaluates assets across multiple dimensions and returns a pass/fail
verdict with detailed feedback. An asset must score >= 7.0/10 to be
approved for the library.

Quality Dimensions:
1. Scale Accuracy   — real-world 1:1 dimensions check
2. Geometry Quality — poly count, no ngons, proper normals, subdivision
3. Material Quality — PBR materials, no flat colors, texture usage
4. Edge Treatment   — bevels/rounded edges (real objects aren't razor-sharp)
5. Visual Quality   — multi-angle render evaluation
6. Detail Level     — hardware, trim, insets, layered construction

Each dimension is scored 0-10 and weighted to produce a final score.
"""

import math
import os
import json

# Dimension reference data — real-world sizes for common objects (meters)
# Used for scale validation
REAL_WORLD_DIMENSIONS = {
    # Seating
    "dining_chair": {"width": (0.40, 0.55), "depth": (0.42, 0.55), "height": (0.78, 0.95)},
    "office_chair": {"width": (0.55, 0.70), "depth": (0.55, 0.70), "height": (0.90, 1.20)},
    "armchair": {"width": (0.70, 0.95), "depth": (0.75, 0.95), "height": (0.80, 1.05)},
    "bar_stool": {"width": (0.35, 0.50), "depth": (0.35, 0.50), "height": (0.65, 0.85)},
    "bench": {"width": (1.00, 1.80), "depth": (0.35, 0.50), "height": (0.42, 0.50)},
    "sofa_2seat": {"width": (1.40, 1.80), "depth": (0.80, 1.00), "height": (0.75, 0.95)},
    "sofa_3seat": {"width": (1.90, 2.40), "depth": (0.80, 1.00), "height": (0.75, 0.95)},

    # Tables
    "dining_table": {"width": (0.80, 1.80), "depth": (0.80, 1.10), "height": (0.72, 0.78)},
    "coffee_table": {"width": (0.80, 1.40), "depth": (0.50, 0.80), "height": (0.38, 0.50)},
    "side_table": {"width": (0.35, 0.60), "depth": (0.35, 0.60), "height": (0.50, 0.65)},
    "desk": {"width": (1.00, 1.80), "depth": (0.50, 0.80), "height": (0.72, 0.78)},
    "nightstand": {"width": (0.40, 0.60), "depth": (0.35, 0.50), "height": (0.55, 0.70)},

    # Beds
    "bed_single": {"width": (0.90, 1.00), "depth": (1.90, 2.10), "height": (0.45, 0.65)},
    "bed_double": {"width": (1.35, 1.55), "depth": (1.90, 2.10), "height": (0.45, 0.65)},
    "bed_queen": {"width": (1.50, 1.65), "depth": (1.95, 2.10), "height": (0.45, 0.65)},
    "bed_king": {"width": (1.80, 2.00), "depth": (1.95, 2.15), "height": (0.45, 0.65)},

    # Storage
    "bookshelf": {"width": (0.60, 1.20), "depth": (0.25, 0.40), "height": (1.50, 2.20)},
    "wardrobe": {"width": (0.80, 2.00), "depth": (0.55, 0.65), "height": (1.80, 2.40)},
    "dresser": {"width": (0.80, 1.60), "depth": (0.45, 0.55), "height": (0.75, 1.00)},
    "tv_stand": {"width": (1.00, 1.80), "depth": (0.35, 0.50), "height": (0.45, 0.65)},

    # Kitchen/Bath
    "kitchen_counter": {"width": (0.60, 3.00), "depth": (0.55, 0.65), "height": (0.85, 0.92)},
    "toilet": {"width": (0.35, 0.45), "depth": (0.65, 0.80), "height": (0.38, 0.42)},
    "bathtub": {"width": (0.65, 0.85), "depth": (1.50, 1.80), "height": (0.50, 0.65)},
    "sink_vanity": {"width": (0.50, 1.20), "depth": (0.40, 0.55), "height": (0.80, 0.90)},

    # Lighting
    "floor_lamp": {"width": (0.25, 0.50), "depth": (0.25, 0.50), "height": (1.20, 1.80)},
    "table_lamp": {"width": (0.15, 0.40), "depth": (0.15, 0.40), "height": (0.35, 0.65)},
    "pendant_light": {"width": (0.20, 0.60), "depth": (0.20, 0.60), "height": (0.15, 0.50)},

    # Props
    "plant_pot": {"width": (0.15, 0.45), "depth": (0.15, 0.45), "height": (0.20, 1.50)},
    "picture_frame": {"width": (0.20, 1.00), "depth": (0.02, 0.05), "height": (0.25, 0.80)},
    "vase": {"width": (0.08, 0.30), "depth": (0.08, 0.30), "height": (0.15, 0.50)},
    "mug": {"width": (0.08, 0.12), "depth": (0.08, 0.12), "height": (0.08, 0.12)},
    "book": {"width": (0.12, 0.22), "depth": (0.02, 0.04), "height": (0.17, 0.30)},

    # Characters
    "character": {"width": (0.30, 0.60), "depth": (0.20, 0.40), "height": (1.50, 2.10)},
    "character_child": {"width": (0.25, 0.45), "depth": (0.15, 0.30), "height": (1.10, 1.45)},
    "character_stylized": {"width": (0.30, 0.70), "depth": (0.20, 0.45), "height": (1.50, 2.30)},
}

# Scoring weights
WEIGHTS = {
    "scale": 0.15,
    "geometry": 0.20,
    "materials": 0.25,
    "edges": 0.15,
    "detail": 0.25,
}

PASSING_SCORE = 7.0


# ---------------------------------------------------------------------------
# Individual Quality Checks
# ---------------------------------------------------------------------------

def check_scale(dimensions, asset_type=None):
    """Check if dimensions are realistic 1:1 scale.

    Args:
        dimensions: Dict with 'width', 'depth', 'height' in meters.
        asset_type: Key from REAL_WORLD_DIMENSIONS for precise validation.

    Returns:
        (score, feedback) tuple. Score 0-10.
    """
    w = dimensions.get("width", 0)
    d = dimensions.get("depth", 0)
    h = dimensions.get("height", 0)

    issues = []
    score = 10.0

    # Basic sanity: nothing should be < 1cm or > 10m for indoor furniture
    for dim_name, val in [("width", w), ("depth", d), ("height", h)]:
        if val < 0.01:
            issues.append(f"{dim_name} too small ({val:.3f}m < 1cm)")
            score -= 3.0
        elif val > 10.0:
            issues.append(f"{dim_name} too large ({val:.2f}m > 10m)")
            score -= 3.0

    # Type-specific validation
    if asset_type and asset_type in REAL_WORLD_DIMENSIONS:
        ref = REAL_WORLD_DIMENSIONS[asset_type]
        for dim_name, val in [("width", w), ("depth", d), ("height", h)]:
            if dim_name in ref:
                lo, hi = ref[dim_name]
                if val < lo * 0.8:
                    issues.append(f"{dim_name} undersized: {val:.3f}m "
                                  f"(expected {lo:.2f}-{hi:.2f}m)")
                    score -= 2.0
                elif val > hi * 1.2:
                    issues.append(f"{dim_name} oversized: {val:.3f}m "
                                  f"(expected {lo:.2f}-{hi:.2f}m)")
                    score -= 2.0

    feedback = "Scale OK" if not issues else "; ".join(issues)
    return (max(0, score), feedback)


def check_geometry(poly_count, has_ngons=False, has_subsurf=False,
                   normals_consistent=True, manifold=True):
    """Check geometry quality.

    Args:
        poly_count: Total polygon count.
        has_ngons: Whether the mesh has n-gons (faces with >4 verts).
        has_subsurf: Whether subdivision surface is used.
        normals_consistent: Whether face normals are all pointing outward.
        manifold: Whether the mesh is watertight/manifold.

    Returns:
        (score, feedback) tuple.
    """
    issues = []
    score = 10.0

    # Poly count expectations
    if poly_count < 100:
        issues.append(f"Too few polygons ({poly_count}) — looks primitive")
        score -= 4.0
    elif poly_count < 500:
        issues.append(f"Low poly ({poly_count}) — may lack detail")
        score -= 2.0
    elif poly_count > 500000:
        issues.append(f"Very high poly ({poly_count}) — may be excessive")
        score -= 1.0

    if has_ngons:
        issues.append("Has n-gons — should use quads for subdivision")
        score -= 2.0

    if not normals_consistent:
        issues.append("Inconsistent normals — will cause shading artifacts")
        score -= 3.0

    if not manifold:
        issues.append("Non-manifold mesh — may cause rendering issues")
        score -= 1.5

    if has_subsurf:
        score = min(score + 1.0, 10.0)  # Bonus for using subsurf

    feedback = "Geometry OK" if not issues else "; ".join(issues)
    return (max(0, score), feedback)


def check_materials(material_count, has_pbr=False, has_textures=False,
                    has_roughness_variation=False, has_normal_maps=False,
                    all_flat_color=False):
    """Check material quality.

    Args:
        material_count: Number of materials on the object.
        has_pbr: Uses Principled BSDF.
        has_textures: Has image textures.
        has_roughness_variation: Roughness isn't uniform flat value.
        has_normal_maps: Has normal map textures.
        all_flat_color: All materials are just flat Base Color.

    Returns:
        (score, feedback) tuple.
    """
    issues = []
    score = 10.0

    if material_count == 0:
        issues.append("No materials assigned")
        score -= 5.0
    elif material_count == 1:
        issues.append("Only 1 material — real objects have multiple materials")
        score -= 1.5

    if all_flat_color:
        issues.append("All flat colors — needs textures or procedural variation")
        score -= 3.0

    if not has_pbr:
        issues.append("Not using Principled BSDF — required for PBR")
        score -= 3.0

    if not has_textures and not has_roughness_variation:
        issues.append("No texture or roughness variation — looks plastic/CG")
        score -= 2.0

    if has_normal_maps:
        score = min(score + 1.0, 10.0)  # Bonus

    if has_textures:
        score = min(score + 0.5, 10.0)  # Bonus

    feedback = "Materials OK" if not issues else "; ".join(issues)
    return (max(0, score), feedback)


def check_edges(has_bevels=False, has_rounded_edges=False,
                bevel_segments=0, edge_radius=0.0):
    """Check edge treatment.

    Real-world objects NEVER have perfectly sharp 90° edges. Every edge
    should have at least a small bevel/chamfer to catch light realistically.

    Args:
        has_bevels: Whether bevel modifier is present.
        has_rounded_edges: Whether edges are visually rounded.
        bevel_segments: Number of bevel segments.
        edge_radius: Bevel radius in meters.

    Returns:
        (score, feedback) tuple.
    """
    issues = []
    score = 10.0

    if not has_bevels and not has_rounded_edges:
        issues.append("No edge bevels — razor-sharp edges look CG, not real")
        score -= 5.0
    elif has_bevels:
        if bevel_segments < 2:
            issues.append(f"Only {bevel_segments} bevel segments — needs 2+ for smooth")
            score -= 1.5
        if edge_radius < 0.001:
            issues.append(f"Bevel radius too small ({edge_radius:.4f}m)")
            score -= 1.0
        if edge_radius > 0.05:
            issues.append(f"Bevel radius too large ({edge_radius:.3f}m) — looks like a pillow")
            score -= 1.0

    feedback = "Edges OK" if not issues else "; ".join(issues)
    return (max(0, score), feedback)


def check_detail(has_insets=False, has_hardware=False,
                 has_trim=False, has_multi_part=False,
                 construction_layers=1):
    """Check detail level — the difference between "CG" and "real".

    Args:
        has_insets: Panel lines, recessed details.
        has_hardware: Screws, handles, knobs, hinges.
        has_trim: Edge trim, molding, decorative strips.
        has_multi_part: Made of visually distinct parts (not one blob).
        construction_layers: Number of distinct construction layers.

    Returns:
        (score, feedback) tuple.
    """
    issues = []
    score = 5.0  # Start at 5, earn points for detail

    if has_insets:
        score += 1.5
    else:
        issues.append("No panel insets or recessed detail")

    if has_hardware:
        score += 2.0
    else:
        issues.append("No hardware (handles, screws, knobs)")

    if has_trim:
        score += 1.0
    else:
        issues.append("No trim or decorative elements")

    if has_multi_part:
        score += 1.0
    else:
        issues.append("Single-piece construction — looks like a 3D print")

    if construction_layers >= 3:
        score += 0.5
    elif construction_layers < 2:
        issues.append("Only 1 construction layer — needs structural depth")

    feedback = "Detail OK" if not issues else "; ".join(issues)
    return (min(10, max(0, score)), feedback)


# ---------------------------------------------------------------------------
# Full Quality Report
# ---------------------------------------------------------------------------

def quality_check(asset_info):
    """Run the full Gordon Ramsay quality check on an asset.

    Args:
        asset_info: Dict with all asset metadata:
            - dimensions: {width, depth, height}
            - asset_type: Key from REAL_WORLD_DIMENSIONS (optional)
            - poly_count: int
            - has_ngons: bool
            - has_subsurf: bool
            - normals_consistent: bool
            - manifold: bool
            - material_count: int
            - has_pbr: bool
            - has_textures: bool
            - has_roughness_variation: bool
            - has_normal_maps: bool
            - all_flat_color: bool
            - has_bevels: bool
            - has_rounded_edges: bool
            - bevel_segments: int
            - edge_radius: float
            - has_insets: bool
            - has_hardware: bool
            - has_trim: bool
            - has_multi_part: bool
            - construction_layers: int

    Returns:
        Dict with:
            - passed: bool
            - score: float (0-10)
            - dimensions: dict of {name: (score, feedback)}
            - summary: str
    """
    results = {}

    # 1. Scale
    results["scale"] = check_scale(
        asset_info.get("dimensions", {}),
        asset_info.get("asset_type"),
    )

    # 2. Geometry
    results["geometry"] = check_geometry(
        asset_info.get("poly_count", 0),
        asset_info.get("has_ngons", False),
        asset_info.get("has_subsurf", False),
        asset_info.get("normals_consistent", True),
        asset_info.get("manifold", True),
    )

    # 3. Materials
    results["materials"] = check_materials(
        asset_info.get("material_count", 0),
        asset_info.get("has_pbr", False),
        asset_info.get("has_textures", False),
        asset_info.get("has_roughness_variation", False),
        asset_info.get("has_normal_maps", False),
        asset_info.get("all_flat_color", False),
    )

    # 4. Edges
    results["edges"] = check_edges(
        asset_info.get("has_bevels", False),
        asset_info.get("has_rounded_edges", False),
        asset_info.get("bevel_segments", 0),
        asset_info.get("edge_radius", 0.0),
    )

    # 5. Detail
    results["detail"] = check_detail(
        asset_info.get("has_insets", False),
        asset_info.get("has_hardware", False),
        asset_info.get("has_trim", False),
        asset_info.get("has_multi_part", False),
        asset_info.get("construction_layers", 1),
    )

    # Weighted final score
    final_score = sum(
        results[dim][0] * WEIGHTS[dim]
        for dim in WEIGHTS
    )

    passed = final_score >= PASSING_SCORE

    # Build summary
    summary_lines = []
    if passed:
        summary_lines.append(f"✓ PASSED — Score: {final_score:.1f}/10")
    else:
        summary_lines.append(f"✗ FAILED — Score: {final_score:.1f}/10 "
                             f"(needs {PASSING_SCORE})")

    summary_lines.append("")
    for dim in WEIGHTS:
        s, fb = results[dim]
        status = "PASS" if s >= 7.0 else "FAIL"
        weight_pct = int(WEIGHTS[dim] * 100)
        summary_lines.append(f"  [{status}] {dim.upper():<12s} "
                             f"{s:4.1f}/10 ({weight_pct}%) — {fb}")

    summary = "\n".join(summary_lines)

    return {
        "passed": passed,
        "score": round(final_score, 1),
        "dimensions": results,
        "summary": summary,
    }


def print_quality_report(report):
    """Pretty-print a quality report."""
    print(f"\n{'='*65}")
    print(f"  GORDON RAMSAY QUALITY REPORT")
    print(f"{'='*65}")
    print(report["summary"])
    print(f"{'='*65}\n")


# ---------------------------------------------------------------------------
# Blender-Side Analysis (runs inside Blender)
# ---------------------------------------------------------------------------

def analyze_blender_object_script(obj_name="Asset"):
    """Generate a Blender Python script that analyzes an object's quality metrics.

    Returns a script string that, when executed in Blender, prints a JSON
    dict of all quality metrics that can be fed into quality_check().

    Args:
        obj_name: Name of the root object or collection to analyze.

    Returns:
        Python code string for execution in Blender.
    """
    return f'''
import bpy
import bmesh
import json
import math

def analyze_asset(name="{obj_name}"):
    """Analyze asset quality metrics."""
    # Gather all mesh objects
    meshes = [o for o in bpy.data.objects if o.type == 'MESH'
              and name.lower() in o.name.lower()]

    if not meshes:
        # Try collection
        for coll in bpy.data.collections:
            if name.lower() in coll.name.lower():
                meshes = [o for o in coll.all_objects if o.type == 'MESH']
                break

    if not meshes:
        meshes = [o for o in bpy.data.objects if o.type == 'MESH']

    # Bounding box
    all_coords = []
    for obj in meshes:
        for corner in obj.bound_box:
            world_co = obj.matrix_world @ __import__('mathutils').Vector(corner)
            all_coords.append(world_co)

    if not all_coords:
        print(json.dumps({{"error": "No mesh objects found"}}))
        return

    min_x = min(c.x for c in all_coords)
    max_x = max(c.x for c in all_coords)
    min_y = min(c.y for c in all_coords)
    max_y = max(c.y for c in all_coords)
    min_z = min(c.z for c in all_coords)
    max_z = max(c.z for c in all_coords)

    dims = {{
        "width": round(max_x - min_x, 4),
        "depth": round(max_y - min_y, 4),
        "height": round(max_z - min_z, 4),
    }}

    # Poly count + mesh analysis
    total_polys = 0
    has_ngons = False
    normals_ok = True
    has_subsurf = False
    has_bevels = False
    bevel_segments = 0
    edge_radius = 0.0

    for obj in meshes:
        mesh = obj.data
        total_polys += len(mesh.polygons)

        for poly in mesh.polygons:
            if len(poly.vertices) > 4:
                has_ngons = True
                break

        for mod in obj.modifiers:
            if mod.type == 'SUBSURF':
                has_subsurf = True
            if mod.type == 'BEVEL':
                has_bevels = True
                bevel_segments = max(bevel_segments, mod.segments)
                edge_radius = max(edge_radius, mod.width)
            if mod.type == 'WEIGHTED_NORMAL':
                has_bevels = True  # implies good edge treatment

    # Check for already-applied bevels via edge count heuristic
    if not has_bevels and total_polys > 200:
        # Check if edges show beveling (more edges than a raw box)
        for obj in meshes:
            if len(obj.data.edges) > len(obj.data.polygons) * 2.5:
                has_bevels = True
                bevel_segments = 2
                edge_radius = 0.005
                break

    # Materials
    all_mats = set()
    has_pbr = False
    has_textures = False
    has_roughness_var = False
    has_normal_maps = False
    all_flat = True

    for obj in meshes:
        for slot in obj.material_slots:
            if slot.material:
                mat = slot.material
                all_mats.add(mat.name)
                if mat.use_nodes:
                    for node in mat.node_tree.nodes:
                        if node.type == 'BSDF_PRINCIPLED':
                            has_pbr = True
                        if node.type == 'TEX_IMAGE':
                            has_textures = True
                            all_flat = False
                        if node.type == 'TEX_NOISE' or node.type == 'TEX_VORONOI':
                            has_roughness_var = True
                            all_flat = False
                        if node.type == 'NORMAL_MAP':
                            has_normal_maps = True

    # Detail analysis
    has_insets = total_polys > 500 and len(meshes) > 1
    has_hardware = any('handle' in o.name.lower() or 'knob' in o.name.lower()
                       or 'screw' in o.name.lower() or 'hinge' in o.name.lower()
                       for o in meshes)
    has_trim = any('trim' in o.name.lower() or 'edge' in o.name.lower()
                   or 'strip' in o.name.lower() for o in meshes)

    result = {{
        "dimensions": dims,
        "poly_count": total_polys,
        "object_count": len(meshes),
        "has_ngons": has_ngons,
        "has_subsurf": has_subsurf,
        "normals_consistent": normals_ok,
        "manifold": True,
        "material_count": len(all_mats),
        "has_pbr": has_pbr,
        "has_textures": has_textures,
        "has_roughness_variation": has_roughness_var,
        "has_normal_maps": has_normal_maps,
        "all_flat_color": all_flat and not has_roughness_var,
        "has_bevels": has_bevels,
        "has_rounded_edges": has_bevels or has_subsurf,
        "bevel_segments": bevel_segments,
        "edge_radius": edge_radius,
        "has_insets": has_insets,
        "has_hardware": has_hardware,
        "has_trim": has_trim,
        "has_multi_part": len(meshes) >= 3,
        "construction_layers": min(5, max(1, len(meshes) // 2)),
    }}

    print("SAC_QUALITY_JSON:" + json.dumps(result))
    return result

analyze_asset()
'''


def parse_quality_json(blender_output):
    """Parse quality JSON from Blender script output.

    Args:
        blender_output: Full stdout from Blender containing SAC_QUALITY_JSON line.

    Returns:
        Parsed dict, or None if not found.
    """
    for line in blender_output.split("\n"):
        if "SAC_QUALITY_JSON:" in line:
            json_str = line.split("SAC_QUALITY_JSON:", 1)[1].strip()
            return json.loads(json_str)
    return None
