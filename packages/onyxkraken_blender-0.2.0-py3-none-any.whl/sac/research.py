"""
SAC Research — Self-troubleshooting via Microsoft Edge browser.

When Onyx encounters an issue building an asset (Blender API error,
technique question, etc.), it can research solutions using Edge.

Uses the OnyxKraken desktop automation agent to control Edge browser.
Falls back to subprocess-based URL opening if the agent isn't available.
"""

import os
import sys
import subprocess
import webbrowser
import json
import re

# Edge executable
EDGE_EXE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
if not os.path.exists(EDGE_EXE):
    EDGE_EXE = r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"

# Search engines
SEARCH_URLS = {
    "blender_docs": "https://docs.blender.org/api/current/search.html?q=",
    "blender_stack": "https://blender.stackexchange.com/search?q=",
    "general": "https://www.bing.com/search?q=",
}

# Common Blender error patterns and their known fixes
KNOWN_FIXES = {
    "RuntimeError: Operator bpy.ops.mesh": {
        "cause": "Mesh operator called outside of correct context",
        "fix": "Ensure object is selected and active, correct mode (EDIT/OBJECT)",
        "code": "bpy.ops.object.select_all(action='DESELECT'); obj.select_set(True); "
                "bpy.context.view_layer.objects.active = obj",
    },
    "context is incorrect": {
        "cause": "Blender operator called in wrong context",
        "fix": "Switch to correct mode before calling operator",
        "code": "bpy.ops.object.mode_set(mode='OBJECT')",
    },
    "not found in object": {
        "cause": "Modifier or property doesn't exist on this object",
        "fix": "Check object type and existing modifiers before applying",
        "code": "if mod.name in [m.name for m in obj.modifiers]: ...",
    },
    "non-default value": {
        "cause": "Blender API version mismatch",
        "fix": "Check Blender version and use compatible API calls",
        "code": "print(bpy.app.version_string)",
    },
    "bmesh": {
        "cause": "BMesh operation error",
        "fix": "Ensure bmesh is valid, verts/faces exist, and free() after use",
        "code": "bm.verts.ensure_lookup_table(); bm.faces.ensure_lookup_table()",
    },
    "BOOLEAN": {
        "cause": "Boolean modifier failed",
        "fix": "Ensure both objects are manifold, non-zero volume, and not coplanar",
        "code": "mod.solver = 'FAST'  # or 'EXACT' for complex cases",
    },
    "material_index": {
        "cause": "Material index out of range",
        "fix": "Ensure material slots exist before assigning indices",
        "code": "if fi < len(obj.data.polygons): obj.data.polygons[fi].material_index = idx",
    },
}


def lookup_known_fix(error_message):
    """Check if an error matches a known fix pattern.

    Args:
        error_message: The error string from Blender.

    Returns:
        Dict with 'cause', 'fix', 'code' if found, else None.
    """
    error_lower = error_message.lower()
    for pattern, fix in KNOWN_FIXES.items():
        if pattern.lower() in error_lower:
            return fix
    return None


def build_search_query(error_message, context=""):
    """Build an optimized search query from an error message.

    Args:
        error_message: The error string.
        context: Additional context (e.g., "building a chair with subdivision").

    Returns:
        Cleaned search query string.
    """
    # Strip file paths and line numbers
    cleaned = re.sub(r'File "[^"]*"', '', error_message)
    cleaned = re.sub(r'line \d+', '', cleaned)
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()

    # Take just the core error message (last meaningful line)
    lines = [l.strip() for l in cleaned.split('\n') if l.strip()]
    core_error = lines[-1] if lines else cleaned

    # Truncate if too long
    if len(core_error) > 100:
        core_error = core_error[:100]

    query = f"Blender Python {core_error}"
    if context:
        query += f" {context}"

    return query


def open_search(query, engine="blender_stack"):
    """Open a search in Microsoft Edge.

    Args:
        query: Search query string.
        engine: Search engine key from SEARCH_URLS.

    Returns:
        The full URL opened.
    """
    base_url = SEARCH_URLS.get(engine, SEARCH_URLS["general"])
    url = base_url + query.replace(" ", "+")

    try:
        subprocess.Popen([EDGE_EXE, url],
                         stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL)
    except FileNotFoundError:
        webbrowser.open(url)

    return url


def research_error(error_message, context="", auto_open=False):
    """Research a Blender error — check known fixes first, then search.

    Args:
        error_message: The error string from Blender output.
        context: What was being attempted (e.g., "adding subdivision surface").
        auto_open: If True, automatically open Edge browser with search.

    Returns:
        Dict with 'known_fix' (if any), 'search_query', 'search_url'.
    """
    result = {
        "known_fix": None,
        "search_query": None,
        "search_url": None,
    }

    # Check known fixes first
    fix = lookup_known_fix(error_message)
    if fix:
        result["known_fix"] = fix
        print(f"[SAC Research] Known fix found:")
        print(f"  Cause: {fix['cause']}")
        print(f"  Fix: {fix['fix']}")
        print(f"  Code: {fix['code']}")
        return result

    # Build search query
    query = build_search_query(error_message, context)
    result["search_query"] = query

    print(f"[SAC Research] No known fix. Searching: {query}")

    if auto_open:
        url = open_search(query, engine="blender_stack")
        result["search_url"] = url
        print(f"[SAC Research] Opened in Edge: {url}")

    return result


def research_technique(technique_name, auto_open=False):
    """Research a Blender technique or workflow.

    Args:
        technique_name: What to learn about (e.g., "cloth simulation cushion").
        auto_open: If True, auto-open Edge.

    Returns:
        Dict with search info.
    """
    query = f"Blender Python scripting {technique_name} tutorial"
    result = {"search_query": query, "search_url": None}

    if auto_open:
        url = open_search(query, engine="general")
        result["search_url"] = url
        print(f"[SAC Research] Opened in Edge: {url}")
    else:
        print(f"[SAC Research] Suggested search: {query}")

    return result
