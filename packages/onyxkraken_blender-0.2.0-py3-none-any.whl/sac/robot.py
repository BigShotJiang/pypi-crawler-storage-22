"""
SAC Detailed Robot Builder — Gordon Ramsay Quality Mechanical Robot.

Builds a fully detailed, Mixamo-compatible rigged mechanical robot
with individual attention to each body section:
- Head: helmet, visor, jaw, antenna, sensors
- Torso: chest plates, reactor, back unit, belly armor, hip skirts
- Arms: pauldrons, upper arms, elbows, forearms, wrist joints
- Hands: palm, 5 articulated fingers with 3 segments each
- Legs: hip joints, thighs, knee assemblies, shins, ankle joints
- Feet: foot body, heel, toe segments, sole plates

Uses bmesh for detailed geometry: inset panels, edge loops,
beveled armor, mechanical detail. All parts parent to Mixamo
skeleton bones for animation compatibility.
"""

import os
import sys
import math

try:
    from .creator import create_asset, run_blender_script
except ImportError:
    from creator import create_asset, run_blender_script


# ───────────────────────────────────────────────────────────────────
# MIXAMO SKELETON — bone names and T-pose positions
# These are the standard Mixamo bone names that animations expect.
# ───────────────────────────────────────────────────────────────────

MIXAMO_BONES = [
    "mixamorig:Hips",
    "mixamorig:Spine", "mixamorig:Spine1", "mixamorig:Spine2",
    "mixamorig:Neck", "mixamorig:Head",
    # Left arm
    "mixamorig:LeftShoulder", "mixamorig:LeftArm",
    "mixamorig:LeftForeArm", "mixamorig:LeftHand",
    "mixamorig:LeftHandThumb1", "mixamorig:LeftHandThumb2",
    "mixamorig:LeftHandThumb3",
    "mixamorig:LeftHandIndex1", "mixamorig:LeftHandIndex2",
    "mixamorig:LeftHandIndex3",
    "mixamorig:LeftHandMiddle1", "mixamorig:LeftHandMiddle2",
    "mixamorig:LeftHandMiddle3",
    "mixamorig:LeftHandRing1", "mixamorig:LeftHandRing2",
    "mixamorig:LeftHandRing3",
    "mixamorig:LeftHandPinky1", "mixamorig:LeftHandPinky2",
    "mixamorig:LeftHandPinky3",
    # Right arm
    "mixamorig:RightShoulder", "mixamorig:RightArm",
    "mixamorig:RightForeArm", "mixamorig:RightHand",
    "mixamorig:RightHandThumb1", "mixamorig:RightHandThumb2",
    "mixamorig:RightHandThumb3",
    "mixamorig:RightHandIndex1", "mixamorig:RightHandIndex2",
    "mixamorig:RightHandIndex3",
    "mixamorig:RightHandMiddle1", "mixamorig:RightHandMiddle2",
    "mixamorig:RightHandMiddle3",
    "mixamorig:RightHandRing1", "mixamorig:RightHandRing2",
    "mixamorig:RightHandRing3",
    "mixamorig:RightHandPinky1", "mixamorig:RightHandPinky2",
    "mixamorig:RightHandPinky3",
    # Left leg
    "mixamorig:LeftUpLeg", "mixamorig:LeftLeg",
    "mixamorig:LeftFoot", "mixamorig:LeftToeBase",
    # Right leg
    "mixamorig:RightUpLeg", "mixamorig:RightLeg",
    "mixamorig:RightFoot", "mixamorig:RightToeBase",
]


# ───────────────────────────────────────────────────────────────────
# MATERIAL PALETTE — upgraded from v6 with scratched metal + wear
# ───────────────────────────────────────────────────────────────────

def _generate_materials_code(name):
    """Generate Blender code for the full robot material palette.

    Materials use procedural textures for scratches, wear, and
    edge highlighting — not just flat Principled BSDF.
    """
    return f'''
# === ROBOT MATERIALS: {name} ===

def _robot_mat(mat_name, base_rgb, metallic, roughness,
               scratch_amount=0.0, edge_wear=0.0):
    """Create a metal material with optional procedural scratches and edge wear."""
    mat = bpy.data.materials.new(mat_name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    bsdf = nodes.get('Principled BSDF')

    bsdf.inputs['Base Color'].default_value = (*base_rgb, 1.0)
    bsdf.inputs['Metallic'].default_value = metallic
    bsdf.inputs['Roughness'].default_value = roughness

    if scratch_amount > 0:
        # Procedural scratch layer: anisotropic noise stretched in one direction
        tc = nodes.new('ShaderNodeTexCoord')
        tc.location = (-800, 300)
        mapping = nodes.new('ShaderNodeMapping')
        mapping.location = (-600, 300)
        mapping.inputs['Scale'].default_value = (5.0, 120.0, 5.0)
        links.new(tc.outputs['Object'], mapping.inputs['Vector'])

        scratch_noise = nodes.new('ShaderNodeTexNoise')
        scratch_noise.location = (-400, 300)
        scratch_noise.inputs['Scale'].default_value = 80.0
        scratch_noise.inputs['Detail'].default_value = 12.0
        scratch_noise.inputs['Roughness'].default_value = 0.9
        links.new(mapping.outputs['Vector'], scratch_noise.inputs['Vector'])

        # Mix scratches into roughness
        rough_mix = nodes.new('ShaderNodeMath')
        rough_mix.location = (-200, 200)
        rough_mix.operation = 'ADD'
        rough_mix.inputs[0].default_value = roughness
        links.new(scratch_noise.outputs['Fac'], rough_mix.inputs[1])

        clamp = nodes.new('ShaderNodeClamp')
        clamp.location = (-50, 200)
        clamp.inputs['Min'].default_value = roughness
        clamp.inputs['Max'].default_value = min(roughness + 0.3, 1.0)
        links.new(rough_mix.outputs['Value'], clamp.inputs['Value'])
        links.new(clamp.outputs['Result'], bsdf.inputs['Roughness'])

        # Subtle color variation from scratches
        col_mix = nodes.new('ShaderNodeMixRGB')
        col_mix.location = (-200, 0)
        col_mix.inputs['Fac'].default_value = scratch_amount * 0.3
        col_mix.inputs['Color1'].default_value = (*base_rgb, 1.0)
        lighter = tuple(min(c * 1.3, 1.0) for c in base_rgb)
        col_mix.inputs['Color2'].default_value = (*lighter, 1.0)
        links.new(scratch_noise.outputs['Fac'], col_mix.inputs['Fac'])
        links.new(col_mix.outputs['Color'], bsdf.inputs['Base Color'])

    if edge_wear > 0:
        # Pointiness-based edge highlighting (brighter edges = paint wear)
        geom = nodes.new('ShaderNodeNewGeometry')
        geom.location = (-600, -200)
        # Note: Pointiness requires mesh to have calculated sharp edges
        # We approximate with a color ramp on the geometry normal
        bump = nodes.new('ShaderNodeBump')
        bump.location = (-200, -300)
        bump.inputs['Strength'].default_value = edge_wear * 0.5
        links.new(geom.outputs['Normal'], bump.inputs['Normal'])
        links.new(bump.outputs['Normal'], bsdf.inputs['Normal'])

    return mat

# Primary armor: gunmetal with scratches
mat_gunmetal = _robot_mat('{name}_Gunmetal',
    (0.12, 0.13, 0.15), metallic=0.85, roughness=0.30,
    scratch_amount=0.15, edge_wear=0.3)

# Dark recessed panels: charcoal
mat_charcoal = _robot_mat('{name}_Charcoal',
    (0.03, 0.03, 0.04), metallic=0.75, roughness=0.45,
    scratch_amount=0.05)

# Accent plates: bright steel
mat_steel = _robot_mat('{name}_Steel',
    (0.55, 0.57, 0.60), metallic=0.9, roughness=0.15,
    scratch_amount=0.2, edge_wear=0.4)

# Joint rubber: matte black
mat_rubber = _robot_mat('{name}_Rubber',
    (0.02, 0.02, 0.02), metallic=0.0, roughness=0.85)

# Copper accents: warm mechanical detail
mat_copper = _robot_mat('{name}_Copper',
    (0.72, 0.45, 0.20), metallic=0.9, roughness=0.25,
    scratch_amount=0.25, edge_wear=0.5)

# Inner frame: dark gunmetal for visible internals
mat_frame = _robot_mat('{name}_Frame',
    (0.10, 0.11, 0.12), metallic=0.7, roughness=0.5)

# Neon cyan emissive
mat_neon = bpy.data.materials.new('{name}_Neon')
mat_neon.use_nodes = True
_nb = mat_neon.node_tree.nodes.get('Principled BSDF')
_nb.inputs['Emission'].default_value = (0.0, 0.7, 1.0, 1.0)
_nb.inputs['Emission Strength'].default_value = 25.0
_nb.inputs['Base Color'].default_value = (0.0, 0.4, 0.9, 1.0)

# Warning orange emissive
mat_warn = bpy.data.materials.new('{name}_Warn')
mat_warn.use_nodes = True
_wb = mat_warn.node_tree.nodes.get('Principled BSDF')
_wb.inputs['Emission'].default_value = (1.0, 0.5, 0.0, 1.0)
_wb.inputs['Emission Strength'].default_value = 12.0

print('[Robot] Materials created: 8 materials with procedural scratches/wear')
'''


# ───────────────────────────────────────────────────────────────────
# HELPER FUNCTIONS — bone lookups, part creation, bmesh utilities
# ───────────────────────────────────────────────────────────────────

def _generate_helpers_code(name):
    """Generate Blender helper functions for bone positions and part creation."""
    return f'''
# === ROBOT HELPERS: {name} ===

def bw(bn):
    """Bone world-space head position."""
    return armature.matrix_world @ armature.data.bones[bn].head_local

def bt(bn):
    """Bone world-space tail position."""
    return armature.matrix_world @ armature.data.bones[bn].tail_local

def bmid(bn):
    """Bone midpoint in world space."""
    return (bw(bn) + bt(bn)) / 2

def blen(bn):
    """Bone length."""
    return (bt(bn) - bw(bn)).length

def parent_to_bone(obj, bone_name):
    """Parent object to bone keeping current world position."""
    bone = armature.data.bones[bone_name]
    obj.parent = armature
    obj.parent_type = 'BONE'
    obj.parent_bone = bone_name
    bone_mat = armature.matrix_world @ bone.matrix_local
    obj.matrix_parent_inverse = bone_mat.inverted()

def make_part(pname, shape, size, loc, mat, bone, bevel_width=0.005):
    """Create a basic part (cube/cylinder/sphere) and parent to bone."""
    x, y, z = loc if not hasattr(loc, 'x') else (loc.x, loc.y, loc.z)
    if shape == 'cube':
        bpy.ops.mesh.primitive_cube_add(size=1, location=(x, y, z))
        obj = bpy.context.active_object
        obj.scale = size
        bpy.ops.object.transform_apply(scale=True)
        if bevel_width > 0:
            bev = obj.modifiers.new('Bevel', 'BEVEL')
            bev.width = bevel_width
            bev.segments = 2
            bev.limit_method = 'ANGLE'
    elif shape == 'cylinder':
        bpy.ops.mesh.primitive_cylinder_add(
            radius=size[0], depth=size[1], vertices=32,
            location=(x, y, z))
        obj = bpy.context.active_object
    elif shape == 'sphere':
        bpy.ops.mesh.primitive_uv_sphere_add(
            radius=size[0], segments=24, ring_count=16,
            location=(x, y, z))
        obj = bpy.context.active_object
    else:
        return None

    obj.name = '{name}_' + pname
    bpy.ops.object.shade_smooth()
    obj.data.materials.append(mat)
    parent_to_bone(obj, bone)
    return obj

def make_bmesh_part(pname, bm_func, loc, mat, bone):
    """Create a part from a bmesh function and parent to bone.

    bm_func(bm) should populate the bmesh with geometry.
    Returns the created object.
    """
    mesh = bpy.data.meshes.new('{name}_' + pname)
    obj = bpy.data.objects.new('{name}_' + pname, mesh)
    bpy.context.collection.objects.link(obj)

    bm = bmesh.new()
    bm_func(bm)
    bm.to_mesh(mesh)
    bm.free()

    mesh.update()
    obj.location = loc if not hasattr(loc, 'x') else (loc.x, loc.y, loc.z)

    # Smooth shading
    for face in mesh.polygons:
        face.use_smooth = True

    obj.data.materials.append(mat)
    parent_to_bone(obj, bone)
    return obj

def inset_panel(bm, face, inset_thickness=0.003, inset_depth=0.002):
    """Create an inset panel on a bmesh face — mechanical detail."""
    result = bmesh.ops.inset_individual(bm, faces=[face],
                                         thickness=inset_thickness,
                                         depth=-inset_depth)
    return result

def add_edge_loops(obj, cuts=1):
    """Add subdivision edge loops for better deformation."""
    mod = obj.modifiers.new('EdgeLoops', 'SUBSURF')
    mod.levels = cuts
    mod.render_levels = cuts + 1
    return mod

parts = []
P = parts.append

print('[Robot] Helpers ready')
'''


# ───────────────────────────────────────────────────────────────────
# ARMATURE IMPORT — load Mixamo skeleton from character.fbx
# ───────────────────────────────────────────────────────────────────

def _generate_armature_code():
    """Generate code to import the Mixamo armature and strip default meshes."""
    toolkit_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    char_fbx = os.path.join(toolkit_dir, 'character.fbx').replace('\\', '/')

    return f'''
# === CLEAR SCENE & IMPORT MIXAMO ARMATURE ===
import bpy, bmesh, math, os
from mathutils import Vector, Matrix

# Clear default scene (removes startup cube, light, camera)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=True)

# Import Mixamo character skeleton
bpy.ops.import_scene.fbx(filepath=r"{char_fbx}", use_anim=False)

armature = None
to_remove = []
for obj in bpy.context.selected_objects:
    if obj.type == 'ARMATURE':
        armature = obj
    else:
        to_remove.append(obj)

# Strip default Mixamo meshes — we build our own
for obj in to_remove:
    bpy.data.objects.remove(obj, do_unlink=True)

if not armature:
    print("ERROR: No armature found in character.fbx")
    raise RuntimeError("No armature in FBX")

bpy.context.view_layer.update()
bone_names = [b.name for b in armature.data.bones]
print(f'[Robot] Armature loaded: {{len(bone_names)}} bones')
print(f'[Robot] Bone list: {{bone_names[:10]}}...')
'''


# ───────────────────────────────────────────────────────────────────
# BODY SECTION: HEAD
# Helmet, visor, face plate, jaw mechanism, antenna, sensors
# ───────────────────────────────────────────────────────────────────

def _generate_head_code(name):
    """Generate detailed head assembly."""
    return f'''
# === HEAD ASSEMBLY: {name} ===
h_mid = bmid('mixamorig:Head')
h_len = blen('mixamorig:Head')
h_top = bt('mixamorig:Head')
h_base = bw('mixamorig:Head')
head_bone = 'mixamorig:Head'

# --- Main helmet shell ---
# Wider at temples, narrower at chin — not a simple box
P(make_part('Helmet', 'cube', (0.21, 0.23, h_len * 0.92),
    (h_mid.x, h_mid.y + 0.005, h_mid.z - 0.02),
    mat_gunmetal, head_bone, bevel_width=0.008))

# --- Face plate (dark recessed) ---
P(make_part('FacePlate', 'cube', (0.17, 0.014, h_len * 0.48),
    (h_mid.x, h_mid.y - 0.117, h_mid.z - 0.01),
    mat_charcoal, head_bone, bevel_width=0.003))

# --- Visor: wide neon slit with slight curve feel ---
P(make_part('Visor', 'cube', (0.155, 0.010, 0.032),
    (h_mid.x, h_mid.y - 0.119, h_mid.z + 0.015),
    mat_neon, head_bone, bevel_width=0.002))

# --- Visor frame: steel border around visor ---
P(make_part('VisorFrameTop', 'cube', (0.165, 0.012, 0.006),
    (h_mid.x, h_mid.y - 0.118, h_mid.z + 0.034),
    mat_steel, head_bone, bevel_width=0.001))
P(make_part('VisorFrameBot', 'cube', (0.165, 0.012, 0.006),
    (h_mid.x, h_mid.y - 0.118, h_mid.z - 0.003),
    mat_steel, head_bone, bevel_width=0.001))

# --- Jaw / chin plate (separate piece for mechanical look) ---
P(make_part('Jaw', 'cube', (0.14, 0.10, h_len * 0.18),
    (h_mid.x, h_mid.y - 0.02, h_base.z + h_len * 0.08),
    mat_gunmetal, head_bone, bevel_width=0.005))

# --- Jaw vent slits (3 horizontal lines) ---
for i in range(3):
    vz = h_base.z + h_len * 0.04 + i * 0.012
    P(make_part(f'JawVent{{i}}', 'cube', (0.08, 0.004, 0.003),
        (h_mid.x, h_mid.y - 0.075, vz),
        mat_frame, head_bone, bevel_width=0))

# --- Top crest / ridge ---
P(make_part('Crest', 'cube', (0.04, 0.20, 0.015),
    (h_mid.x, h_mid.y, h_top.z - 0.02),
    mat_steel, head_bone, bevel_width=0.003))

# --- Side temple plates (L and R) ---
for sx, lab in [(0.107, 'L'), (-0.107, 'R')]:
    P(make_part(f'Temple{{lab}}', 'cube', (0.015, 0.10, h_len * 0.35),
        (h_mid.x + sx, h_mid.y + 0.02, h_mid.z + 0.01),
        mat_steel, head_bone, bevel_width=0.002))
    # Small sensor dot on temple
    P(make_part(f'Sensor{{lab}}', 'sphere', (0.008,),
        (h_mid.x + sx, h_mid.y - 0.04, h_mid.z + 0.02),
        mat_neon, head_bone, bevel_width=0))

# --- Antenna (right side) ---
P(make_part('AntennaBase', 'cylinder', (0.012, 0.025),
    (h_mid.x + 0.07, h_mid.y - 0.02, h_top.z + 0.005),
    mat_charcoal, head_bone, bevel_width=0))
P(make_part('AntennaRod', 'cylinder', (0.005, 0.08),
    (h_mid.x + 0.07, h_mid.y - 0.02, h_top.z + 0.05),
    mat_charcoal, head_bone, bevel_width=0))
P(make_part('AntennaTip', 'sphere', (0.008,),
    (h_mid.x + 0.07, h_mid.y - 0.02, h_top.z + 0.095),
    mat_warn, head_bone, bevel_width=0))

# --- Back of head panel ---
P(make_part('HeadBack', 'cube', (0.15, 0.03, h_len * 0.5),
    (h_mid.x, h_mid.y + 0.13, h_mid.z + 0.02),
    mat_charcoal, head_bone, bevel_width=0.004))

# --- Ear-like mechanical housings ---
for sx, lab in [(0.115, 'L'), (-0.115, 'R')]:
    P(make_part(f'EarHousing{{lab}}', 'cylinder', (0.025, 0.03),
        (h_mid.x + sx, h_mid.y + 0.02, h_mid.z - 0.01),
        mat_copper, head_bone, bevel_width=0))

head_count = len([p for p in parts if p is not None])
print(f'[Robot] Head: {{head_count}} parts')
'''


# ───────────────────────────────────────────────────────────────────
# BODY SECTION: NECK + TORSO
# ───────────────────────────────────────────────────────────────────

def _generate_torso_code(name):
    """Generate detailed torso assembly."""
    return f'''
# === TORSO ASSEMBLY: {name} ===
hip_z = bw('mixamorig:Hips').z
neck_z = bw('mixamorig:Neck').z
s1_mid = bmid('mixamorig:Spine1')
s2_mid = bmid('mixamorig:Spine2')
n_mid = bmid('mixamorig:Neck')
torso_bone = 'mixamorig:Spine1'
torso_start = len(parts)

# --- NECK ---
# Rubber core + armored collar
P(make_part('NeckCore', 'cylinder', (0.055, 0.12),
    n_mid, mat_rubber, 'mixamorig:Neck', bevel_width=0))
# Segmented neck rings (3 rings for mechanical articulation look)
for i in range(3):
    nz = bw('mixamorig:Neck').z + i * 0.035 + 0.015
    P(make_part(f'NeckRing{{i}}', 'cylinder', (0.065, 0.012),
        (n_mid.x, n_mid.y, nz),
        mat_charcoal, 'mixamorig:Neck', bevel_width=0))
# Collar — overlaps torso top
P(make_part('Collar', 'cylinder', (0.13, 0.05),
    (n_mid.x, n_mid.y, bw('mixamorig:Neck').z - 0.01),
    mat_steel, 'mixamorig:Neck', bevel_width=0))

# --- MAIN TORSO: single monolith on Spine1 ---
# Extend well below hips for overlap with hip skirts
torso_z = (hip_z + neck_z) / 2 - 0.03
torso_h = (neck_z - hip_z) + 0.20
P(make_part('TorsoMain', 'cube', (0.38, 0.21, torso_h),
    (s1_mid.x, s1_mid.y, torso_z),
    mat_gunmetal, torso_bone, bevel_width=0.008))

# --- CHEST PLATES (layered armor) ---
# Upper chest plate — steel accent
P(make_part('ChestUpper', 'cube', (0.30, 0.016, 0.14),
    (s1_mid.x, s1_mid.y - 0.114, neck_z - 0.12),
    mat_steel, torso_bone, bevel_width=0.004))

# Lower chest plate — gunmetal with inset
P(make_part('ChestLower', 'cube', (0.26, 0.014, 0.10),
    (s1_mid.x, s1_mid.y - 0.112, neck_z - 0.26),
    mat_gunmetal, torso_bone, bevel_width=0.003))

# --- CHEST REACTOR (central glowing element) ---
reactor_z = neck_z - 0.18
# Reactor housing (copper ring)
bpy.ops.mesh.primitive_torus_add(
    major_radius=0.045, minor_radius=0.008,
    major_segments=32, minor_segments=12,
    location=(s1_mid.x, s1_mid.y - 0.115, reactor_z))
reactor_ring = bpy.context.active_object
reactor_ring.name = '{name}_ReactorRing'
reactor_ring.data.materials.append(mat_copper)
bpy.ops.object.shade_smooth()
parent_to_bone(reactor_ring, torso_bone)
P(reactor_ring)

# Reactor core (neon glow)
P(make_part('ReactorCore', 'cylinder', (0.035, 0.015),
    (s1_mid.x, s1_mid.y - 0.116, reactor_z),
    mat_neon, torso_bone, bevel_width=0))
# Rotate reactor to face forward
bpy.context.view_layer.objects.active = parts[-1]
parts[-1].rotation_euler.x = 1.5708

# --- CHEST NEON LINES ---
# Horizontal line below reactor
P(make_part('ChestLineH', 'cube', (0.22, 0.004, 0.008),
    (s1_mid.x, s1_mid.y - 0.113, reactor_z - 0.07),
    mat_neon, torso_bone, bevel_width=0))
# Vertical center line
P(make_part('ChestLineV', 'cube', (0.005, 0.004, 0.18),
    (s1_mid.x, s1_mid.y - 0.113, (neck_z - 0.08 + hip_z + 0.10) / 2),
    mat_neon, torso_bone, bevel_width=0))

# --- BELLY PANEL (dark recessed) ---
belly_z = (hip_z + neck_z) / 2 - 0.04
P(make_part('BellyPanel', 'cube', (0.20, 0.013, 0.13),
    (s1_mid.x, s1_mid.y - 0.112, belly_z),
    mat_charcoal, torso_bone, bevel_width=0.002))

# --- BELLY VENT SLITS ---
for i in range(4):
    vz = belly_z - 0.04 + i * 0.022
    P(make_part(f'BellyVent{{i}}', 'cube', (0.10, 0.003, 0.005),
        (s1_mid.x, s1_mid.y - 0.119, vz),
        mat_frame, torso_bone, bevel_width=0))

# --- SIDE PANELS (armor plates covering ribs area) ---
for sx, lab in [(0.19, 'L'), (-0.19, 'R')]:
    P(make_part(f'SidePanel{{lab}}', 'cube', (0.02, 0.16, torso_h * 0.6),
        (s1_mid.x + sx, s1_mid.y, torso_z + 0.02),
        mat_steel, torso_bone, bevel_width=0.003))

# --- BACKPACK UNIT ---
back_z = neck_z - 0.16
P(make_part('BackpackMain', 'cube', (0.26, 0.09, 0.30),
    (s1_mid.x, s1_mid.y + 0.155, back_z),
    mat_charcoal, torso_bone, bevel_width=0.006))
# Backpack vents (top exhaust)
for i in range(3):
    P(make_part(f'BackVent{{i}}', 'cube', (0.06, 0.02, 0.008),
        (s1_mid.x - 0.07 + i * 0.07, s1_mid.y + 0.205, back_z + 0.12),
        mat_frame, torso_bone, bevel_width=0))
# Backpack neon strip
P(make_part('BackNeon', 'cube', (0.18, 0.004, 0.008),
    (s1_mid.x, s1_mid.y + 0.205, back_z),
    mat_neon, torso_bone, bevel_width=0))

# --- PELVIS BRIDGE (on Hips bone — fills the torso-to-thigh gap) ---
# Hips bone sits at z≈0.998, UpLeg heads at z≈0.931
# This is the critical gap zone; parent to Hips bone directly
hips_mid = bmid('mixamorig:Hips')
hips_head = bw('mixamorig:Hips')
ul_head_L = bw('mixamorig:LeftUpLeg')
ul_head_R = bw('mixamorig:RightUpLeg')
pelvis_top = hips_head.z + 0.04
pelvis_bot = min(ul_head_L.z, ul_head_R.z) - 0.05
pelvis_h = pelvis_top - pelvis_bot
pelvis_cz = (pelvis_top + pelvis_bot) / 2

# Main pelvis block — wide enough to cover both hip joints
P(make_part('PelvisMain', 'cube', (0.36, 0.20, pelvis_h),
    (hips_mid.x, hips_mid.y, pelvis_cz),
    mat_gunmetal, 'mixamorig:Hips', bevel_width=0.006))

# Side hip skirts (overlap thigh tops from above)
for sx, lab in [(0.12, 'L'), (-0.12, 'R')]:
    P(make_part(f'HipSkirt{{lab}}', 'cube', (0.14, 0.19, pelvis_h + 0.04),
        (hips_mid.x + sx, hips_mid.y, pelvis_cz - 0.02),
        mat_gunmetal, 'mixamorig:Hips', bevel_width=0.005))
    # Skirt neon accent
    P(make_part(f'HipLine{{lab}}', 'cube', (0.008, 0.005, pelvis_h * 0.6),
        (hips_mid.x + sx * 0.7, hips_mid.y - 0.097, pelvis_cz),
        mat_neon, 'mixamorig:Hips', bevel_width=0))

# Center groin plate (darker recessed)
P(make_part('GroinPlate', 'cube', (0.14, 0.17, pelvis_h * 0.7),
    (hips_mid.x, hips_mid.y, pelvis_cz - 0.01),
    mat_charcoal, 'mixamorig:Hips', bevel_width=0.004))

# Front codpiece accent
P(make_part('CodPiece', 'cube', (0.08, 0.02, pelvis_h * 0.5),
    (hips_mid.x, hips_mid.y - 0.10, pelvis_cz),
    mat_steel, 'mixamorig:Hips', bevel_width=0.003))

# --- WAIST BELT (copper accent ring) ---
P(make_part('WaistBelt', 'cube', (0.40, 0.22, 0.025),
    (s1_mid.x, s1_mid.y, hip_z + 0.04),
    mat_copper, torso_bone, bevel_width=0.004))

# --- FRONT WAIST BUCKLE ---
P(make_part('WaistBuckle', 'cube', (0.06, 0.02, 0.04),
    (s1_mid.x, s1_mid.y - 0.12, hip_z + 0.04),
    mat_steel, torso_bone, bevel_width=0.002))

torso_count = len(parts) - torso_start
print(f'[Robot] Torso: {{torso_count}} parts')
'''


# ───────────────────────────────────────────────────────────────────
# BODY SECTION: ARMS
# ───────────────────────────────────────────────────────────────────

def _generate_arms_code(name):
    """Generate detailed arm assemblies (both sides)."""
    return f'''
# === ARM ASSEMBLIES: {name} ===
arm_start = len(parts)

for side, pfx in [('Left', 'L'), ('Right', 'R')]:
    sign = 1 if side == 'Left' else -1

    # --- SHOULDER PAULDRON ---
    sh_mid = bmid(f'mixamorig:{{side}}Shoulder')
    sh_len = blen(f'mixamorig:{{side}}Shoulder')

    # Main pauldron — massive overlapping armor plate
    P(make_part(f'Pauldron{{pfx}}', 'cube', (sh_len * 1.9, 0.20, 0.15),
        (sh_mid.x + sign * 0.04, sh_mid.y, sh_mid.z + 0.025),
        mat_steel, f'mixamorig:{{side}}Shoulder', bevel_width=0.006))

    # Pauldron top ridge
    P(make_part(f'PauldRidge{{pfx}}', 'cube', (sh_len * 1.5, 0.15, 0.012),
        (sh_mid.x + sign * 0.04, sh_mid.y, sh_mid.z + 0.10),
        mat_gunmetal, f'mixamorig:{{side}}Shoulder', bevel_width=0.003))

    # Pauldron neon edge
    P(make_part(f'PauldNeon{{pfx}}', 'cube', (sh_len * 1.4, 0.14, 0.005),
        (sh_mid.x + sign * 0.04, sh_mid.y, sh_mid.z + 0.107),
        mat_neon, f'mixamorig:{{side}}Shoulder', bevel_width=0))

    # Pauldron inner plate (darker underside)
    P(make_part(f'PauldInner{{pfx}}', 'cube', (sh_len * 1.2, 0.14, 0.008),
        (sh_mid.x + sign * 0.04, sh_mid.y, sh_mid.z - 0.04),
        mat_charcoal, f'mixamorig:{{side}}Shoulder', bevel_width=0.002))

    # --- SHOULDER BALL JOINT ---
    sj = bw(f'mixamorig:{{side}}Arm')
    P(make_part(f'ShJoint{{pfx}}', 'sphere', (0.075,),
        sj, mat_rubber, f'mixamorig:{{side}}Arm', bevel_width=0))
    # Joint ring (copper accent)
    bpy.ops.mesh.primitive_torus_add(
        major_radius=0.065, minor_radius=0.008,
        major_segments=24, minor_segments=8,
        location=(sj.x, sj.y, sj.z))
    jr = bpy.context.active_object
    jr.name = '{name}_ShJointRing' + pfx
    jr.data.materials.append(mat_copper)
    bpy.ops.object.shade_smooth()
    parent_to_bone(jr, f'mixamorig:{{side}}Arm')
    P(jr)

    # --- UPPER ARM ---
    ua_mid = bmid(f'mixamorig:{{side}}Arm')
    ua_len = blen(f'mixamorig:{{side}}Arm')

    # Main upper arm armor
    P(make_part(f'UpperArm{{pfx}}', 'cube', (ua_len * 1.08, 0.13, 0.14),
        ua_mid, mat_gunmetal, f'mixamorig:{{side}}Arm', bevel_width=0.005))

    # Upper arm detail plate (outer)
    P(make_part(f'UAPlate{{pfx}}', 'cube', (ua_len * 0.6, 0.015, 0.10),
        (ua_mid.x, ua_mid.y - 0.067, ua_mid.z),
        mat_steel, f'mixamorig:{{side}}Arm', bevel_width=0.002))

    # Upper arm neon strip
    P(make_part(f'UANeon{{pfx}}', 'cube', (ua_len * 0.5, 0.004, 0.008),
        (ua_mid.x, ua_mid.y - 0.068, ua_mid.z + 0.04),
        mat_neon, f'mixamorig:{{side}}Arm', bevel_width=0))

    # --- ELBOW JOINT ---
    elb = bw(f'mixamorig:{{side}}ForeArm')
    P(make_part(f'Elbow{{pfx}}', 'sphere', (0.068,),
        elb, mat_rubber, f'mixamorig:{{side}}ForeArm', bevel_width=0))
    # Elbow guard plate
    P(make_part(f'ElbowGuard{{pfx}}', 'cube', (0.06, 0.04, 0.08),
        (elb.x, elb.y + 0.055, elb.z),
        mat_steel, f'mixamorig:{{side}}ForeArm', bevel_width=0.003))

    # --- FOREARM / GAUNTLET ---
    fa_mid = bmid(f'mixamorig:{{side}}ForeArm')
    fa_len = blen(f'mixamorig:{{side}}ForeArm')

    # Main forearm — slightly wider (gauntlet)
    P(make_part(f'ForeArm{{pfx}}', 'cube', (fa_len * 1.08, 0.14, 0.15),
        fa_mid, mat_gunmetal, f'mixamorig:{{side}}ForeArm', bevel_width=0.005))

    # Gauntlet front plate
    P(make_part(f'FAPlate{{pfx}}', 'cube', (fa_len * 0.7, 0.015, 0.11),
        (fa_mid.x, fa_mid.y - 0.071, fa_mid.z),
        mat_steel, f'mixamorig:{{side}}ForeArm', bevel_width=0.002))

    # Forearm neon stripe
    P(make_part(f'FANeon{{pfx}}', 'cube', (fa_len * 0.6, 0.004, 0.008),
        (fa_mid.x, fa_mid.y - 0.072, fa_mid.z),
        mat_neon, f'mixamorig:{{side}}ForeArm', bevel_width=0))

    # Forearm back panel (charcoal)
    P(make_part(f'FABack{{pfx}}', 'cube', (fa_len * 0.5, 0.012, 0.08),
        (fa_mid.x, fa_mid.y + 0.072, fa_mid.z),
        mat_charcoal, f'mixamorig:{{side}}ForeArm', bevel_width=0.002))

    # --- WRIST JOINT ---
    wr = bw(f'mixamorig:{{side}}Hand')
    P(make_part(f'Wrist{{pfx}}', 'cylinder', (0.045, 0.04),
        wr, mat_rubber, f'mixamorig:{{side}}Hand', bevel_width=0))
    # Wrist ring
    P(make_part(f'WristRing{{pfx}}', 'cylinder', (0.055, 0.015),
        wr, mat_copper, f'mixamorig:{{side}}Hand', bevel_width=0))

arm_count = len(parts) - arm_start
print(f'[Robot] Arms: {{arm_count}} parts ({{arm_count // 2}} per side)')
'''


# ───────────────────────────────────────────────────────────────────
# BODY SECTION: HANDS (fully articulated fingers)
# ───────────────────────────────────────────────────────────────────

def _generate_hands_code(name):
    """Generate detailed hand assemblies with 5 articulated fingers."""
    return f'''
# === HAND ASSEMBLIES: {name} ===
hand_start = len(parts)

for side, pfx in [('Left', 'L'), ('Right', 'R')]:
    sign = 1 if side == 'Left' else -1
    hand_bone = f'mixamorig:{{side}}Hand'
    hd_mid = bmid(hand_bone)
    hd_len = blen(hand_bone)

    # --- PALM ---
    P(make_part(f'Palm{{pfx}}', 'cube', (hd_len * 1.3, 0.09, 0.11),
        hd_mid, mat_charcoal, hand_bone, bevel_width=0.004))

    # Palm front plate
    P(make_part(f'PalmPlate{{pfx}}', 'cube', (hd_len * 0.9, 0.012, 0.07),
        (hd_mid.x, hd_mid.y - 0.046, hd_mid.z),
        mat_gunmetal, hand_bone, bevel_width=0.002))

    # --- FINGERS (4 main + thumb) ---
    # Each finger has 3 phalanx segments parented to corresponding bones
    finger_names = ['Index', 'Middle', 'Ring', 'Pinky']

    for fi, fname in enumerate(finger_names):
        for seg in range(1, 4):
            bone_name = f'mixamorig:{{side}}Hand{{fname}}{{seg}}'

            # Check if bone exists
            if bone_name not in [b.name for b in armature.data.bones]:
                continue

            f_mid = bmid(bone_name)
            f_len = blen(bone_name)

            # Finger segment dimensions decrease per phalanx
            seg_w = 0.018 - seg * 0.002
            seg_d = 0.020 - seg * 0.002
            seg_h = f_len * 0.95

            # Main segment
            P(make_part(f'Finger{{fname}}{{seg}}{{pfx}}', 'cube',
                (seg_h, seg_d, seg_w),
                f_mid, mat_gunmetal, bone_name, bevel_width=0.002))

            # Joint ball at base of each segment (except first)
            if seg > 1:
                jt = bw(bone_name)
                P(make_part(f'FJoint{{fname}}{{seg}}{{pfx}}', 'sphere',
                    (seg_w * 0.65,),
                    jt, mat_rubber, bone_name, bevel_width=0))

    # --- THUMB (3 segments, angled) ---
    for seg in range(1, 4):
        bone_name = f'mixamorig:{{side}}HandThumb{{seg}}'
        if bone_name not in [b.name for b in armature.data.bones]:
            continue

        t_mid = bmid(bone_name)
        t_len = blen(bone_name)

        seg_w = 0.020 - seg * 0.002
        seg_d = 0.022 - seg * 0.002

        P(make_part(f'Thumb{{seg}}{{pfx}}', 'cube',
            (t_len * 0.95, seg_d, seg_w),
            t_mid, mat_gunmetal, bone_name, bevel_width=0.002))

        if seg > 1:
            jt = bw(bone_name)
            P(make_part(f'TJoint{{seg}}{{pfx}}', 'sphere',
                (seg_w * 0.65,),
                jt, mat_rubber, bone_name, bevel_width=0))

    # --- KNUCKLE GUARDS (steel plate across finger bases) ---
    idx1 = f'mixamorig:{{side}}HandIndex1'
    pnk1 = f'mixamorig:{{side}}HandPinky1'
    if idx1 in [b.name for b in armature.data.bones] and \
       pnk1 in [b.name for b in armature.data.bones]:
        kg_z = (bw(idx1).z + bw(pnk1).z) / 2
        kg_x = (bw(idx1).x + bw(pnk1).x) / 2
        P(make_part(f'KnuckleGuard{{pfx}}', 'cube',
            (0.06, 0.015, 0.06),
            (kg_x, hd_mid.y - 0.046, kg_z),
            mat_steel, hand_bone, bevel_width=0.002))

hand_count = len(parts) - hand_start
print(f'[Robot] Hands: {{hand_count}} parts ({{hand_count // 2}} per side)')
'''


# ───────────────────────────────────────────────────────────────────
# BODY SECTION: LEGS
# ───────────────────────────────────────────────────────────────────

def _generate_legs_code(name):
    """Generate detailed leg assemblies."""
    return f'''
# === LEG ASSEMBLIES: {name} ===
leg_start = len(parts)

for side, pfx in [('Left', 'L'), ('Right', 'R')]:
    sign = 1 if side == 'Left' else -1

    # --- HIP BALL JOINT ---
    hj = bw(f'mixamorig:{{side}}UpLeg')
    P(make_part(f'HipJoint{{pfx}}', 'sphere', (0.095,),
        hj, mat_rubber, f'mixamorig:{{side}}UpLeg', bevel_width=0))
    # Hip joint ring
    bpy.ops.mesh.primitive_torus_add(
        major_radius=0.072, minor_radius=0.008,
        major_segments=24, minor_segments=8,
        location=(hj.x, hj.y, hj.z))
    hjr = bpy.context.active_object
    hjr.name = '{name}_HipRing' + pfx
    hjr.data.materials.append(mat_copper)
    bpy.ops.object.shade_smooth()
    parent_to_bone(hjr, f'mixamorig:{{side}}UpLeg')
    P(hjr)

    # --- THIGH ---
    th_mid = bmid(f'mixamorig:{{side}}UpLeg')
    th_len = blen(f'mixamorig:{{side}}UpLeg')

    # Main thigh armor — extend upward into hip joint area
    th_center = (th_mid.x, th_mid.y, th_mid.z + 0.02)
    P(make_part(f'Thigh{{pfx}}', 'cube', (0.15, 0.15, th_len * 1.18),
        th_center, mat_gunmetal, f'mixamorig:{{side}}UpLeg', bevel_width=0.006))

    # Outer armor plate
    P(make_part(f'ThighPlate{{pfx}}', 'cube', (0.04, 0.12, th_len * 0.75),
        (th_mid.x + sign * 0.075, th_mid.y, th_mid.z),
        mat_steel, f'mixamorig:{{side}}UpLeg', bevel_width=0.003))

    # Front detail panel
    P(make_part(f'ThighFront{{pfx}}', 'cube', (0.08, 0.012, th_len * 0.5),
        (th_mid.x, th_mid.y - 0.076, th_mid.z),
        mat_charcoal, f'mixamorig:{{side}}UpLeg', bevel_width=0.002))

    # Thigh neon strip
    P(make_part(f'ThighNeon{{pfx}}', 'cube', (0.008, 0.005, th_len * 0.5),
        (th_mid.x + sign * 0.076, th_mid.y - 0.058, th_mid.z),
        mat_neon, f'mixamorig:{{side}}UpLeg', bevel_width=0))

    # --- KNEE ASSEMBLY ---
    kn = bw(f'mixamorig:{{side}}Leg')

    # Knee ball
    P(make_part(f'Knee{{pfx}}', 'sphere', (0.078,),
        kn, mat_rubber, f'mixamorig:{{side}}Leg', bevel_width=0))

    # Knee guard plate (front)
    P(make_part(f'KneeGuard{{pfx}}', 'cube', (0.12, 0.05, 0.13),
        (kn.x, kn.y - 0.075, kn.z),
        mat_steel, f'mixamorig:{{side}}Leg', bevel_width=0.004))

    # Knee guard neon accent
    P(make_part(f'KneeNeon{{pfx}}', 'cube', (0.08, 0.004, 0.008),
        (kn.x, kn.y - 0.101, kn.z - 0.03),
        mat_neon, f'mixamorig:{{side}}Leg', bevel_width=0))

    # Knee side bolts
    for bsx in [0.06, -0.06]:
        P(make_part(f'KneeBolt{{pfx}}{{"L" if bsx > 0 else "R"}}', 'cylinder',
            (0.008, 0.02),
            (kn.x + bsx, kn.y, kn.z),
            mat_copper, f'mixamorig:{{side}}Leg', bevel_width=0))

    # --- SHIN ---
    sn_mid = bmid(f'mixamorig:{{side}}Leg')
    sn_len = blen(f'mixamorig:{{side}}Leg')

    # Main shin armor
    P(make_part(f'Shin{{pfx}}', 'cube', (0.13, 0.14, sn_len * 1.02),
        sn_mid, mat_gunmetal, f'mixamorig:{{side}}Leg', bevel_width=0.005))

    # Front shin plate
    P(make_part(f'ShinPlate{{pfx}}', 'cube', (0.09, 0.03, sn_len * 0.8),
        (sn_mid.x, sn_mid.y - 0.085, sn_mid.z),
        mat_steel, f'mixamorig:{{side}}Leg', bevel_width=0.003))

    # Shin neon strip
    P(make_part(f'ShinNeon{{pfx}}', 'cube', (0.008, 0.005, sn_len * 0.5),
        (sn_mid.x, sn_mid.y - 0.10, sn_mid.z),
        mat_neon, f'mixamorig:{{side}}Leg', bevel_width=0))

    # Back calf panel
    P(make_part(f'CalfPanel{{pfx}}', 'cube', (0.08, 0.015, sn_len * 0.6),
        (sn_mid.x, sn_mid.y + 0.075, sn_mid.z),
        mat_charcoal, f'mixamorig:{{side}}Leg', bevel_width=0.002))

    # --- ANKLE JOINT ---
    ank = bw(f'mixamorig:{{side}}Foot')
    P(make_part(f'Ankle{{pfx}}', 'cylinder', (0.065, 0.06),
        ank, mat_rubber, f'mixamorig:{{side}}Foot', bevel_width=0))
    P(make_part(f'AnkleRing{{pfx}}', 'cylinder', (0.072, 0.015),
        ank, mat_copper, f'mixamorig:{{side}}Foot', bevel_width=0))

leg_count = len(parts) - leg_start
print(f'[Robot] Legs: {{leg_count}} parts ({{leg_count // 2}} per side)')
'''


# ───────────────────────────────────────────────────────────────────
# BODY SECTION: FEET
# ───────────────────────────────────────────────────────────────────

def _generate_feet_code(name):
    """Generate detailed foot assemblies."""
    return f'''
# === FOOT ASSEMBLIES: {name} ===
foot_start = len(parts)

for side, pfx in [('Left', 'L'), ('Right', 'R')]:
    sign = 1 if side == 'Left' else -1

    ft_mid = bmid(f'mixamorig:{{side}}Foot')
    ft_len = blen(f'mixamorig:{{side}}Foot')
    ft_base = bw(f'mixamorig:{{side}}Foot')
    foot_bone = f'mixamorig:{{side}}Foot'
    toe_bone = f'mixamorig:{{side}}ToeBase'

    # --- MAIN FOOT BODY (armored boot) ---
    P(make_part(f'FootMain{{pfx}}', 'cube', (0.14, ft_len * 1.3, 0.08),
        (ft_mid.x, ft_mid.y, ft_mid.z + 0.01),
        mat_gunmetal, foot_bone, bevel_width=0.006))

    # --- FOOT TOP PLATE ---
    P(make_part(f'FootTop{{pfx}}', 'cube', (0.12, ft_len * 0.9, 0.015),
        (ft_mid.x, ft_mid.y, ft_mid.z + 0.05),
        mat_steel, foot_bone, bevel_width=0.003))

    # --- SOLE PLATE (dark rubber) ---
    P(make_part(f'Sole{{pfx}}', 'cube', (0.145, ft_len * 1.35, 0.015),
        (ft_mid.x, ft_mid.y, ft_mid.z - 0.035),
        mat_rubber, foot_bone, bevel_width=0.002))

    # --- HEEL BUMPER ---
    heel_y = ft_base.y + ft_len * 0.15
    P(make_part(f'Heel{{pfx}}', 'cube', (0.12, 0.06, 0.06),
        (ft_mid.x, heel_y, ft_mid.z - 0.01),
        mat_charcoal, foot_bone, bevel_width=0.004))

    # --- TOE GUARD ---
    toe_mid = bmid(toe_bone)
    toe_len = blen(toe_bone)
    P(make_part(f'ToeGuard{{pfx}}', 'cube', (0.12, toe_len * 1.2, 0.065),
        (toe_mid.x, toe_mid.y - 0.01, toe_mid.z + 0.01),
        mat_steel, toe_bone, bevel_width=0.004))

    # Toe neon accent
    P(make_part(f'ToeNeon{{pfx}}', 'cube', (0.08, 0.004, 0.008),
        (toe_mid.x, toe_mid.y - toe_len * 0.4, toe_mid.z + 0.04),
        mat_neon, toe_bone, bevel_width=0))

    # --- ANKLE PISTONS (2 small cylinders connecting shin to foot) ---
    for px in [0.04, -0.04]:
        piston_top = (ft_base.x + px, ft_base.y, ft_base.z + 0.03)
        P(make_part(f'Piston{{pfx}}{{"O" if px > 0 else "I"}}', 'cylinder',
            (0.006, 0.06),
            piston_top,
            mat_copper, foot_bone, bevel_width=0))

foot_count = len(parts) - foot_start
print(f'[Robot] Feet: {{foot_count}} parts ({{foot_count // 2}} per side)')
'''


# ───────────────────────────────────────────────────────────────────
# SCENE SETUP — lighting, camera, floor
# ───────────────────────────────────────────────────────────────────

def _generate_scene_code(name):
    """Generate cinematic scene setup for robot render."""
    return f'''
# === SCENE SETUP: {name} ===

# Dark studio environment
world = bpy.context.scene.world
if not world:
    world = bpy.data.worlds.new('{name}_World')
    bpy.context.scene.world = world
world.use_nodes = True
bg = world.node_tree.nodes.get('Background')
if bg:
    bg.inputs['Color'].default_value = (0.005, 0.007, 0.012, 1.0)
    bg.inputs['Strength'].default_value = 0.03

# Studio lighting
import math as _m

# Key light — warm, high
key = bpy.data.objects.new('{name}_Key', bpy.data.lights.new('{name}_Key', 'AREA'))
bpy.context.collection.objects.link(key)
key.location = (2.5, -2.5, 3.5)
key.rotation_euler = (0.7, 0.3, -0.4)
key.data.energy = 800
key.data.color = (1.0, 0.95, 0.88)
key.data.size = 2.5

# Fill light — cool blue
fill = bpy.data.objects.new('{name}_Fill', bpy.data.lights.new('{name}_Fill', 'AREA'))
bpy.context.collection.objects.link(fill)
fill.location = (-2.5, -0.5, 1.5)
fill.rotation_euler = (0.9, -0.4, 0.5)
fill.data.energy = 250
fill.data.color = (0.5, 0.6, 0.9)
fill.data.size = 2.0

# Rim light — blue backlight
rim = bpy.data.objects.new('{name}_Rim', bpy.data.lights.new('{name}_Rim', 'POINT'))
bpy.context.collection.objects.link(rim)
rim.location = (0.3, 3.5, 2.5)
rim.data.energy = 800
rim.data.color = (0.15, 0.5, 1.0)

# Ground glow (subtle)
gg = bpy.data.objects.new('{name}_GndGlow', bpy.data.lights.new('{name}_GndGlow', 'POINT'))
bpy.context.collection.objects.link(gg)
gg.location = (0, -0.3, 0.03)
gg.data.energy = 30
gg.data.color = (0.0, 0.6, 1.0)

# Studio floor — dark matte
bpy.ops.mesh.primitive_plane_add(size=20, location=(0, 0, -0.005))
floor = bpy.context.active_object
floor.name = '{name}_Floor'
floor_mat = bpy.data.materials.new('{name}_Floor')
floor_mat.use_nodes = True
fb = floor_mat.node_tree.nodes.get('Principled BSDF')
fb.inputs['Base Color'].default_value = (0.012, 0.013, 0.018, 1.0)
fb.inputs['Metallic'].default_value = 0.3
fb.inputs['Roughness'].default_value = 0.15
fb.inputs['Specular'].default_value = 0.2
floor.data.materials.append(floor_mat)

# Camera — hero angle
cam_data = bpy.data.cameras.new('{name}_Cam')
cam_data.lens = 35
cam_obj = bpy.data.objects.new('{name}_Cam', cam_data)
bpy.context.collection.objects.link(cam_obj)
cam_obj.location = (2.0, -4.0, 1.5)

# Point camera at mid-torso to frame full robot
from mathutils import Vector as _V
direction = _V((0, 0, 0.85)) - cam_obj.location
rot_quat = direction.to_track_quat('-Z', 'Y')
cam_obj.rotation_euler = rot_quat.to_euler()

bpy.context.scene.camera = cam_obj

# DOF
cam_data.dof.use_dof = True
cam_data.dof.focus_distance = 4.5
cam_data.dof.aperture_fstop = 5.6

# Render settings
bpy.context.scene.render.engine = 'CYCLES'
bpy.context.scene.cycles.samples = 200
bpy.context.scene.cycles.use_denoising = True
try:
    bpy.context.preferences.addons['cycles'].preferences.compute_device_type = 'CUDA'
    bpy.context.scene.cycles.device = 'GPU'
except:
    pass

bpy.context.scene.render.resolution_x = 1920
bpy.context.scene.render.resolution_y = 1080

total_parts = len([p for p in parts if p is not None])
total_objects = len(bpy.data.objects)
print(f'[Robot] Scene ready: {{total_parts}} robot parts, {{total_objects}} total objects')
print('[Robot] {name} build complete — T-pose, Mixamo-compatible rig')
'''


# ───────────────────────────────────────────────────────────────────
# FULL ROBOT PIPELINE
# ───────────────────────────────────────────────────────────────────

def generate_full_robot_script(name="OnyxMech", render_path=None,
                                blend_path=None):
    """Generate the complete Blender script for the detailed robot.

    Args:
        name: Robot name prefix.
        render_path: Path for rendered image. If None, renders to OnyxProjects.
        blend_path: Path for .blend save. If None, saves to OnyxProjects.

    Returns:
        Complete Blender Python script string.
    """
    home = os.path.expanduser("~").replace("\\", "/")
    if render_path is None:
        render_path = f"{home}/OnyxProjects/{name.lower()}.png"
    if blend_path is None:
        blend_path = f"{home}/OnyxProjects/{name.lower()}.blend"

    sections = [
        _generate_armature_code(),
        _generate_materials_code(name),
        _generate_helpers_code(name),
        _generate_head_code(name),
        _generate_torso_code(name),
        _generate_arms_code(name),
        _generate_hands_code(name),
        _generate_legs_code(name),
        _generate_feet_code(name),
        _generate_scene_code(name),
    ]

    # Add save + render at end
    sections.append(f'''
# === SAVE & RENDER ===
bpy.ops.wm.save_as_mainfile(filepath="{blend_path}")
print('[Robot] Blend saved: {blend_path}')

bpy.context.scene.render.filepath = "{render_path}"
bpy.context.scene.render.image_settings.file_format = 'PNG'
bpy.ops.render.render(write_still=True)
print('[Robot] Rendered: {render_path}')
''')

    return "\n".join(sections)


def build_robot(name="OnyxMech"):
    """Build the detailed robot via SAC pipeline.

    Generates the full Blender script and runs it headless.

    Args:
        name: Robot name.

    Returns:
        (return_code, stdout, stderr) from Blender.
    """
    script = generate_full_robot_script(name)
    return run_blender_script(script, timeout=600)


# CLI entry point
if __name__ == "__main__":
    print("[Robot] Building detailed mechanical robot...")
    rc, out, err = build_robot()
    print(f"RC: {rc}")
    for line in out.split("\n"):
        line = line.strip()
        if line and "[Robot]" in line:
            print(f"  {line}")
    if rc != 0:
        for line in err.split("\n"):
            if "Error" in line or "Traceback" in line:
                print(f"  ERR: {line[:120]}")
