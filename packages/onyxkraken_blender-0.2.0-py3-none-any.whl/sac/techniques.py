"""
SAC Techniques — Advanced Blender modeling techniques for photorealistic assets.

Provides higher-level modeling primitives beyond simple box/cylinder:
- Subdivision surface modeling with edge creasing
- Proper UV unwrapping
- Curve-based modeling (legs, handles, trim)
- Weighted normals for hard-surface
- Multi-material assignment per face
- Profile extrusion (molding, trim, baseboards)
- Lathe/revolution surfaces (bowls, vases, legs)
- Boolean operations with cleanup
- Cloth-like soft deformations
"""

import bpy
import bmesh
import math
import os
from mathutils import Vector, Matrix


# ---------------------------------------------------------------------------
# Subdivision Surface Modeling
# ---------------------------------------------------------------------------

def add_subsurf(obj, levels=2, render_levels=3, use_creases=True):
    """Add subdivision surface modifier with optional crease support.

    Args:
        obj: Blender object.
        levels: Viewport subdivision levels.
        render_levels: Render subdivision levels.
        use_creases: Enable edge crease weighting.

    Returns:
        The modifier.
    """
    mod = obj.modifiers.new('Subsurf', 'SUBSURF')
    mod.levels = levels
    mod.render_levels = render_levels
    mod.use_creased_normal = use_creases
    return mod


def set_edge_crease(obj, edge_indices=None, crease=1.0, all_edges=False):
    """Set crease weight on specific edges for subdivision control.

    Creased edges stay sharp during subdivision. crease=1.0 means fully sharp.

    Args:
        obj: Blender mesh object.
        edge_indices: List of edge indices to crease (or None if all_edges=True).
        crease: Crease weight 0.0-1.0.
        all_edges: If True, crease all edges.
    """
    mesh = obj.data
    if not mesh.edge_creases:
        mesh.edge_creases.add()
    # Use bmesh for reliable crease assignment
    bm = bmesh.new()
    bm.from_mesh(mesh)
    crease_layer = bm.edges.layers.crease.verify()

    if all_edges:
        for edge in bm.edges:
            edge[crease_layer] = crease
    elif edge_indices:
        bm.edges.ensure_lookup_table()
        for idx in edge_indices:
            if idx < len(bm.edges):
                bm.edges[idx][crease_layer] = crease

    bm.to_mesh(mesh)
    bm.free()
    mesh.update()


def crease_sharp_edges(obj, angle_threshold=30.0, crease=1.0):
    """Auto-crease edges sharper than a threshold angle.

    Args:
        obj: Blender mesh object.
        angle_threshold: Edges sharper than this angle (degrees) get creased.
        crease: Crease weight to apply.
    """
    threshold_rad = math.radians(angle_threshold)
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    crease_layer = bm.edges.layers.crease.verify()

    for edge in bm.edges:
        if len(edge.link_faces) == 2:
            angle = edge.calc_face_angle(0)
            if angle > threshold_rad:
                edge[crease_layer] = crease

    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()


def make_subdiv_box(name, width, depth, height, location=(0, 0, 0),
                    levels=2, crease_all=True, material=None):
    """Create a subdivision-ready box with creased edges for controlled rounding.

    Unlike create_box + bevel, this produces smooth organic curves with
    precise edge control — essential for photorealistic furniture.

    Args:
        name: Object name.
        width, depth, height: Dimensions in meters.
        location: (x, y, z) bottom-center.
        levels: Subdivision levels.
        crease_all: Crease all edges (keeps box shape but rounds corners).
        material: Optional material.

    Returns:
        The subdivided box object.
    """
    bpy.ops.mesh.primitive_cube_add(size=1, location=(
        location[0], location[1], location[2] + height / 2
    ))
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = (width, depth, height)
    bpy.ops.object.transform_apply(scale=True)

    if crease_all:
        set_edge_crease(obj, all_edges=True, crease=0.85)

    add_subsurf(obj, levels=levels, render_levels=levels + 1)

    # Smooth shading
    _select(obj)
    bpy.ops.object.shade_smooth()

    if material:
        _apply_mat(obj, material)

    return obj


# ---------------------------------------------------------------------------
# UV Unwrapping
# ---------------------------------------------------------------------------

def smart_uv_unwrap(obj, angle_limit=66.0, island_margin=0.02):
    """Apply smart UV projection to an object.

    Args:
        obj: Blender mesh object.
        angle_limit: Angle limit for island detection (degrees).
        island_margin: Margin between UV islands.
    """
    _select(obj)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.uv.smart_project(angle_limit=math.radians(angle_limit),
                              island_margin=island_margin)
    bpy.ops.object.mode_set(mode='OBJECT')


def box_uv_project(obj, scale=1.0):
    """Apply box/cube UV projection — good for architectural objects.

    Args:
        obj: Blender mesh object.
        scale: UV scale multiplier.
    """
    _select(obj)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.uv.cube_project(cube_size=scale)
    bpy.ops.object.mode_set(mode='OBJECT')


def cylinder_uv_project(obj):
    """Apply cylindrical UV projection."""
    _select(obj)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.uv.cylinder_project()
    bpy.ops.object.mode_set(mode='OBJECT')


# ---------------------------------------------------------------------------
# Curve-Based Modeling
# ---------------------------------------------------------------------------

def create_profile_curve(name, points, closed=False, bevel_depth=0.0,
                         bevel_resolution=4, fill='FULL'):
    """Create a curve from a list of (x, y, z) points.

    Args:
        name: Object name.
        points: List of (x, y, z) tuples defining the curve path.
        closed: Whether the curve is a closed loop.
        bevel_depth: Extrusion radius around the curve (tube thickness).
        bevel_resolution: Resolution of the bevel cross-section.
        fill: Fill mode — 'FULL', 'HALF', 'BACK', 'FRONT'.

    Returns:
        The curve object.
    """
    curve_data = bpy.data.curves.new(name, type='CURVE')
    curve_data.dimensions = '3D'
    curve_data.fill_mode = fill
    curve_data.bevel_depth = bevel_depth
    curve_data.bevel_resolution = bevel_resolution

    spline = curve_data.splines.new('BEZIER')
    spline.bezier_points.add(len(points) - 1)
    spline.use_cyclic_u = closed

    for i, pt in enumerate(points):
        bp = spline.bezier_points[i]
        bp.co = Vector(pt)
        bp.handle_type_left = 'AUTO'
        bp.handle_type_right = 'AUTO'

    obj = bpy.data.objects.new(name, curve_data)
    bpy.context.collection.objects.link(obj)
    return obj


def curve_to_mesh(curve_obj, keep_curve=False):
    """Convert a curve object to a mesh for further editing.

    Args:
        curve_obj: The curve object to convert.
        keep_curve: If True, keep the original curve (creates a copy).

    Returns:
        The mesh object.
    """
    _select(curve_obj)
    if keep_curve:
        bpy.ops.object.duplicate()
        curve_obj = bpy.context.active_object

    bpy.ops.object.convert(target='MESH')
    mesh_obj = bpy.context.active_object
    return mesh_obj


def lathe_profile(name, profile_points, segments=32, material=None):
    """Create a revolution surface (lathe) from a 2D profile.

    Perfect for vases, bowls, table legs, lamp bases, etc.
    Profile is defined as (radius, z) pairs rotated around the Z axis.

    Args:
        name: Object name.
        profile_points: List of (radius, z) tuples defining the profile.
        segments: Number of rotation segments (higher = smoother).
        material: Optional material.

    Returns:
        The lathed mesh object.
    """
    bm = bmesh.new()

    # Create profile vertices along XZ plane
    profile_verts = []
    for r, z in profile_points:
        v = bm.verts.new((r, 0, z))
        profile_verts.append(v)

    # Create profile edges
    for i in range(len(profile_verts) - 1):
        bm.edges.new((profile_verts[i], profile_verts[i + 1]))

    # Spin (lathe) the profile around Z axis
    geom = bm.verts[:] + bm.edges[:]
    bmesh.ops.spin(
        bm,
        geom=geom,
        cent=(0, 0, 0),
        axis=(0, 0, 1),
        angle=math.radians(360),
        steps=segments,
        use_duplicate=False,
    )

    # Remove doubles at the seam
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.0001)

    # Create mesh
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()

    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)

    _select(obj)
    bpy.ops.object.shade_smooth()

    # Recalculate normals
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.normals_make_consistent(inside=False)
    bpy.ops.object.mode_set(mode='OBJECT')

    if material:
        _apply_mat(obj, material)

    return obj


# ---------------------------------------------------------------------------
# Weighted Normals & Hard Surface
# ---------------------------------------------------------------------------

def add_weighted_normals(obj, keep_sharp=True, face_influence=True):
    """Add weighted normals modifier for better hard-surface shading.

    This prevents shading artifacts on beveled hard-surface models
    by weighting normals based on face area.

    Args:
        obj: Blender mesh object.
        keep_sharp: Respect sharp edges.
        face_influence: Use face area for normal weighting.

    Returns:
        The modifier.
    """
    # Auto smooth is required
    obj.data.use_auto_smooth = True
    obj.data.auto_smooth_angle = math.radians(30)

    mod = obj.modifiers.new('WeightedNormal', 'WEIGHTED_NORMAL')
    mod.mode = 'FACE_AREA'
    mod.keep_sharp = keep_sharp
    mod.face_influence = face_influence
    return mod


def mark_sharp_edges(obj, angle_threshold=30.0):
    """Mark edges as sharp based on angle threshold.

    Args:
        obj: Blender mesh object.
        angle_threshold: Edges sharper than this (degrees) are marked sharp.
    """
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    threshold_rad = math.radians(angle_threshold)

    for edge in bm.edges:
        if len(edge.link_faces) == 2:
            angle = edge.calc_face_angle(0)
            edge.smooth = angle <= threshold_rad
        else:
            edge.smooth = False

    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()


# ---------------------------------------------------------------------------
# Multi-Material Assignment
# ---------------------------------------------------------------------------

def assign_material_to_faces(obj, material, face_indices):
    """Assign a material to specific faces of an object.

    Args:
        obj: Blender mesh object.
        material: Material to assign.
        face_indices: List of face indices to assign the material to.
    """
    # Ensure material is in the object's slots
    mat_idx = None
    for i, slot in enumerate(obj.material_slots):
        if slot.material == material:
            mat_idx = i
            break

    if mat_idx is None:
        obj.data.materials.append(material)
        mat_idx = len(obj.data.materials) - 1

    # Assign material to faces
    for fi in face_indices:
        if fi < len(obj.data.polygons):
            obj.data.polygons[fi].material_index = mat_idx


def assign_material_by_normal(obj, material, direction, threshold=0.7):
    """Assign a material to faces pointing in a given direction.

    Useful for assigning different materials to top/sides/bottom.

    Args:
        obj: Blender mesh object.
        material: Material to assign.
        direction: Normal direction vector (e.g., (0, 0, 1) for upward faces).
        threshold: Dot product threshold (0.7 = ~45° cone).
    """
    direction = Vector(direction).normalized()
    face_indices = []

    for i, poly in enumerate(obj.data.polygons):
        if Vector(poly.normal).dot(direction) > threshold:
            face_indices.append(i)

    if face_indices:
        assign_material_to_faces(obj, material, face_indices)


# ---------------------------------------------------------------------------
# Boolean Operations with Cleanup
# ---------------------------------------------------------------------------

def boolean_cut(target, cutter, operation='DIFFERENCE', cleanup=True):
    """Perform a boolean operation with automatic cleanup.

    Args:
        target: Object to cut into.
        cutter: Object used as the cutter tool.
        operation: 'DIFFERENCE', 'UNION', or 'INTERSECT'.
        cleanup: Remove the cutter object after operation.

    Returns:
        The modified target object.
    """
    mod = target.modifiers.new('Boolean', 'BOOLEAN')
    mod.operation = operation
    mod.object = cutter
    mod.solver = 'FAST'

    _select(target)
    bpy.ops.object.modifier_apply(modifier=mod.name)

    if cleanup:
        bpy.data.objects.remove(cutter, do_unlink=True)

    return target


def boolean_union(target, addition, cleanup=True):
    """Boolean union — merge two objects into one."""
    return boolean_cut(target, addition, operation='UNION', cleanup=cleanup)


# ---------------------------------------------------------------------------
# Profile Extrusion
# ---------------------------------------------------------------------------

def extrude_profile(name, profile_2d, path_points, material=None):
    """Extrude a 2D profile along a path.

    Great for molding, trim, baseboards, custom cross-sections.

    Args:
        name: Object name.
        profile_2d: List of (x, y) points defining the cross-section.
        path_points: List of (x, y, z) points defining the extrusion path.
        material: Optional material.

    Returns:
        The extruded mesh object.
    """
    # Create path curve
    path = create_profile_curve(f"{name}_Path", path_points)

    # Create profile curve (2D cross-section)
    profile_data = bpy.data.curves.new(f"{name}_Profile", type='CURVE')
    profile_data.dimensions = '2D'
    spline = profile_data.splines.new('POLY')
    spline.points.add(len(profile_2d) - 1)
    for i, (px, py) in enumerate(profile_2d):
        spline.points[i].co = (px, py, 0, 1)

    profile_obj = bpy.data.objects.new(f"{name}_Profile", profile_data)
    bpy.context.collection.objects.link(profile_obj)

    # Assign profile as bevel object
    path.data.bevel_object = profile_obj
    path.data.use_fill_caps = True

    # Convert to mesh
    _select(path)
    bpy.ops.object.convert(target='MESH')
    result = bpy.context.active_object
    result.name = name

    # Cleanup profile object
    bpy.data.objects.remove(profile_obj, do_unlink=True)

    _select(result)
    bpy.ops.object.shade_smooth()

    if material:
        _apply_mat(result, material)

    return result


# ---------------------------------------------------------------------------
# Edge Loop Operations
# ---------------------------------------------------------------------------

def add_loop_cuts(obj, edge_index=0, cuts=1, factor=0.0):
    """Add loop cuts to a mesh object.

    Args:
        obj: Blender mesh object.
        edge_index: Edge to cut across.
        cuts: Number of cuts.
        factor: Offset factor (-1.0 to 1.0).
    """
    _select(obj)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.loopcut_slide(
        MESH_OT_loopcut={"number_cuts": cuts, "edge_index": edge_index},
        TRANSFORM_OT_edge_slide={"value": factor}
    )
    bpy.ops.object.mode_set(mode='OBJECT')


def inset_faces(obj, thickness=0.02, depth=0.0, face_indices=None):
    """Inset faces on an object — creates panel line detail.

    Args:
        obj: Blender mesh object.
        thickness: Inset distance.
        depth: How far inset faces are pushed in/out.
        face_indices: Specific faces to inset (None = all selected).
    """
    _select(obj)
    bpy.ops.object.mode_set(mode='EDIT')

    if face_indices is not None:
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')
        for fi in face_indices:
            if fi < len(obj.data.polygons):
                obj.data.polygons[fi].select = True
        bpy.ops.object.mode_set(mode='EDIT')
    else:
        bpy.ops.mesh.select_all(action='SELECT')

    bpy.ops.mesh.inset(thickness=thickness, depth=depth)
    bpy.ops.object.mode_set(mode='OBJECT')


# ---------------------------------------------------------------------------
# Modifiers
# ---------------------------------------------------------------------------

def add_solidify(obj, thickness=0.02, offset=-1.0, even_thickness=True):
    """Add solidify modifier — gives thickness to flat surfaces.

    Args:
        obj: Blender object.
        thickness: Shell thickness.
        offset: -1 = inward, 0 = centered, 1 = outward.
        even_thickness: Maintain even thickness on angled surfaces.

    Returns:
        The modifier.
    """
    mod = obj.modifiers.new('Solidify', 'SOLIDIFY')
    mod.thickness = thickness
    mod.offset = offset
    mod.use_even_offset = even_thickness
    return mod


def add_mirror(obj, axis='X', merge_threshold=0.001):
    """Add mirror modifier — build half, mirror the rest.

    Args:
        obj: Blender object.
        axis: 'X', 'Y', or 'Z' axis to mirror across.
        merge_threshold: Distance to merge mirrored vertices.

    Returns:
        The modifier.
    """
    mod = obj.modifiers.new('Mirror', 'MIRROR')
    mod.use_axis[0] = 'X' in axis
    mod.use_axis[1] = 'Y' in axis
    mod.use_axis[2] = 'Z' in axis
    mod.merge_threshold = merge_threshold
    return mod


def add_array(obj, count=3, offset=(1.0, 0, 0), relative=True):
    """Add array modifier — repeat geometry in a pattern.

    Args:
        obj: Blender object.
        count: Number of copies.
        offset: Offset per copy.
        relative: If True, offset is relative to object size.

    Returns:
        The modifier.
    """
    mod = obj.modifiers.new('Array', 'ARRAY')
    mod.count = count
    mod.use_relative_offset = relative
    mod.use_constant_offset = not relative
    if relative:
        mod.relative_offset_displace = offset
    else:
        mod.constant_offset_displace = offset
    return mod


def add_bevel_modifier(obj, width=0.005, segments=3, angle_limit=30.0,
                       clamp_overlap=True):
    """Add bevel modifier with angle-based limiting.

    Args:
        obj: Blender object.
        width: Bevel width.
        segments: Number of bevel segments (more = smoother).
        angle_limit: Only bevel edges sharper than this angle (degrees).
        clamp_overlap: Prevent bevels from overlapping.

    Returns:
        The modifier.
    """
    mod = obj.modifiers.new('Bevel', 'BEVEL')
    mod.width = width
    mod.segments = segments
    mod.limit_method = 'ANGLE'
    mod.angle_limit = math.radians(angle_limit)
    mod.use_clamp_overlap = clamp_overlap
    return mod


def apply_all_modifiers(obj):
    """Apply all modifiers on an object in order.

    Args:
        obj: Blender object.
    """
    _select(obj)
    for mod in list(obj.modifiers):
        try:
            bpy.ops.object.modifier_apply(modifier=mod.name)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# BMesh Utilities
# ---------------------------------------------------------------------------

def bmesh_from_object(obj):
    """Get a BMesh from a mesh object for editing.

    Remember to call bmesh_to_object() when done!

    Args:
        obj: Blender mesh object.

    Returns:
        BMesh instance.
    """
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    return bm


def bmesh_to_object(bm, obj, free=True):
    """Write BMesh back to an object and optionally free it.

    Args:
        bm: BMesh instance.
        obj: Target mesh object.
        free: Free the BMesh after writing.
    """
    bm.to_mesh(obj.data)
    if free:
        bm.free()
    obj.data.update()


def bmesh_extrude_face(bm, face, offset=0.1):
    """Extrude a single face outward by an offset.

    Args:
        bm: BMesh instance.
        face: BMFace to extrude.
        offset: Distance to extrude along face normal.

    Returns:
        The new extruded face.
    """
    result = bmesh.ops.extrude_discrete_faces(bm, faces=[face])
    new_face = result['faces'][0]
    normal = new_face.normal
    bmesh.ops.translate(bm, verts=new_face.verts,
                        vec=normal * offset)
    return new_face


# ---------------------------------------------------------------------------
# Convenience Shapes
# ---------------------------------------------------------------------------

def make_rounded_cube(name, width, depth, height, radius=0.02,
                      resolution=4, location=(0, 0, 0), material=None):
    """Create a cube with truly rounded edges using bevel + subsurf.

    This is the photorealistic equivalent of create_box — every real object
    has slightly rounded edges that catch light.

    Args:
        name: Object name.
        width, depth, height: Dimensions.
        radius: Edge rounding radius.
        resolution: Bevel segments (higher = smoother).
        location: (x, y, z) bottom-center.
        material: Optional material.

    Returns:
        The rounded cube object.
    """
    bpy.ops.mesh.primitive_cube_add(size=1, location=(
        location[0], location[1], location[2] + height / 2
    ))
    obj = bpy.context.active_object
    obj.name = name
    obj.scale = (width, depth, height)
    bpy.ops.object.transform_apply(scale=True)

    # Bevel all edges
    add_bevel_modifier(obj, width=radius, segments=resolution,
                       angle_limit=89.0)

    # Weighted normals for clean shading
    obj.data.use_auto_smooth = True
    obj.data.auto_smooth_angle = math.radians(30)

    _select(obj)
    bpy.ops.object.shade_smooth()

    if material:
        _apply_mat(obj, material)

    return obj


def make_rounded_cylinder(name, radius, height, edge_radius=0.01,
                          resolution=4, vertices=32,
                          location=(0, 0, 0), material=None):
    """Create a cylinder with rounded top/bottom edges.

    Args:
        name: Object name.
        radius: Cylinder radius.
        height: Cylinder height.
        edge_radius: Edge rounding radius.
        resolution: Bevel segments.
        vertices: Circle resolution.
        location: (x, y, z) bottom-center.
        material: Optional material.

    Returns:
        The rounded cylinder object.
    """
    bpy.ops.mesh.primitive_cylinder_add(
        radius=radius, depth=height, vertices=vertices,
        location=(location[0], location[1], location[2] + height / 2)
    )
    obj = bpy.context.active_object
    obj.name = name

    # Bevel the top and bottom edges
    add_bevel_modifier(obj, width=edge_radius, segments=resolution,
                       angle_limit=60.0)

    obj.data.use_auto_smooth = True
    obj.data.auto_smooth_angle = math.radians(30)

    _select(obj)
    bpy.ops.object.shade_smooth()

    if material:
        _apply_mat(obj, material)

    return obj


# ---------------------------------------------------------------------------
# Internal Helpers
# ---------------------------------------------------------------------------

def _select(obj):
    """Select an object and make it active."""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj


def _apply_mat(obj, material):
    """Apply a material to an object."""
    if obj.data.materials:
        obj.data.materials[0] = material
    else:
        obj.data.materials.append(material)
