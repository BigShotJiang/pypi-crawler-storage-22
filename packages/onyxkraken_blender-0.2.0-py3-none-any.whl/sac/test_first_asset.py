"""Test: Create first SAC asset — Modern Dining Chair."""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from creator import create_asset

CHAIR_SCRIPT = r'''
import math

# === MATERIALS ===
mat_oak = make_material('Oak', (0.45, 0.28, 0.14), roughness=0.55, metallic=0.0)
oak_nodes = mat_oak.node_tree.nodes
oak_links = mat_oak.node_tree.links
bsdf = oak_nodes.get('Principled BSDF')

tex_coord = oak_nodes.new('ShaderNodeTexCoord')
tex_coord.location = (-800, 0)
mapping = oak_nodes.new('ShaderNodeMapping')
mapping.location = (-600, 0)
mapping.inputs['Scale'].default_value = (2.0, 15.0, 2.0)
oak_links.new(tex_coord.outputs['Object'], mapping.inputs['Vector'])

noise = oak_nodes.new('ShaderNodeTexNoise')
noise.location = (-400, 0)
noise.inputs['Scale'].default_value = 12.0
noise.inputs['Detail'].default_value = 6.0
noise.inputs['Roughness'].default_value = 0.8
oak_links.new(mapping.outputs['Vector'], noise.inputs['Vector'])

ramp = oak_nodes.new('ShaderNodeValToRGB')
ramp.location = (-200, 0)
ramp.color_ramp.elements[0].position = 0.3
ramp.color_ramp.elements[0].color = (0.35, 0.20, 0.10, 1.0)
ramp.color_ramp.elements[1].position = 0.7
ramp.color_ramp.elements[1].color = (0.55, 0.35, 0.18, 1.0)
oak_links.new(noise.outputs['Fac'], ramp.inputs['Fac'])
oak_links.new(ramp.outputs['Color'], bsdf.inputs['Base Color'])

rough_ramp = oak_nodes.new('ShaderNodeMapRange')
rough_ramp.location = (-200, -200)
rough_ramp.inputs['From Min'].default_value = 0.0
rough_ramp.inputs['From Max'].default_value = 1.0
rough_ramp.inputs['To Min'].default_value = 0.45
rough_ramp.inputs['To Max'].default_value = 0.65
oak_links.new(noise.outputs['Fac'], rough_ramp.inputs['Value'])
oak_links.new(rough_ramp.outputs['Result'], bsdf.inputs['Roughness'])

mat_fabric = make_material('Fabric', (0.85, 0.82, 0.75), roughness=0.92, metallic=0.0)
fab_nodes = mat_fabric.node_tree.nodes
fab_links = mat_fabric.node_tree.links
fab_bsdf = fab_nodes.get('Principled BSDF')
fab_noise = fab_nodes.new('ShaderNodeTexNoise')
fab_noise.location = (-300, 0)
fab_noise.inputs['Scale'].default_value = 80.0
fab_noise.inputs['Detail'].default_value = 4.0
fab_bump = fab_nodes.new('ShaderNodeBump')
fab_bump.location = (-100, -200)
fab_bump.inputs['Strength'].default_value = 0.08
fab_links.new(fab_noise.outputs['Fac'], fab_bump.inputs['Height'])
fab_links.new(fab_bump.outputs['Normal'], fab_bsdf.inputs['Normal'])

mat_metal = make_material('DarkMetal', (0.05, 0.05, 0.06), roughness=0.25, metallic=0.95)

# === CHAIR DIMENSIONS (real-world 1:1) ===
seat_w = 0.44
seat_d = 0.42
seat_h = 0.46
seat_t = 0.025
back_h = 0.42
back_t = 0.018
leg_r = 0.018
leg_r_top = 0.014
apron_h = 0.06
apron_t = 0.018

# === SEAT ===
seat = make_rounded_cube('Seat', seat_w, seat_d, seat_t,
                         location=(0, 0, seat_h - seat_t),
                         radius=0.004, resolution=3, material=mat_fabric)
_link(seat)

# === BACKREST ===
back = make_rounded_cube('Backrest', seat_w - 0.02, back_t, back_h,
                         location=(0, -seat_d/2 + back_t/2, seat_h),
                         radius=0.003, resolution=3, material=mat_oak)
back.rotation_euler.x = math.radians(-5)
_link(back)

slat = make_rounded_cube('BackSlat', seat_w - 0.06, back_t * 0.8, 0.025,
                         location=(0, -seat_d/2 + back_t/2, seat_h + back_h * 0.45),
                         radius=0.002, resolution=2, material=mat_oak)
slat.rotation_euler.x = math.radians(-5)
_link(slat)

# === LEGS (tapered via lathe) ===
leg_positions = [
    (-seat_w/2 + 0.04, -seat_d/2 + 0.04),
    ( seat_w/2 - 0.04, -seat_d/2 + 0.04),
    (-seat_w/2 + 0.04,  seat_d/2 - 0.04),
    ( seat_w/2 - 0.04,  seat_d/2 - 0.04),
]

for i, (lx, ly) in enumerate(leg_positions):
    is_back = i < 2
    leg_height = seat_h - seat_t

    if is_back:
        ext_h = seat_h + back_h
        taper_ext = [
            (leg_r, 0),
            (leg_r, leg_height * 0.1),
            (leg_r * 0.95, leg_height * 0.5),
            (leg_r_top, leg_height),
            (leg_r_top * 0.85, ext_h * 0.95),
            (leg_r_top * 0.8, ext_h),
        ]
        leg = lathe_profile(f'Leg{i}', taper_ext, segments=16, material=mat_oak)
        leg.location = (lx, ly, 0)
        leg.rotation_euler.x = math.radians(-3)
    else:
        taper = [
            (leg_r, 0),
            (leg_r, leg_height * 0.1),
            (leg_r * 0.95, leg_height * 0.5),
            (leg_r_top, leg_height * 0.95),
            (leg_r_top, leg_height),
        ]
        leg = lathe_profile(f'Leg{i}', taper, segments=16, material=mat_oak)
        leg.location = (lx, ly, 0)

    _link(leg)

# === APRONS (structural rails under seat) ===
apron_f = make_rounded_cube('ApronFront', seat_w - 0.08, apron_t, apron_h,
                            location=(0, seat_d/2 - 0.04, seat_h - seat_t - apron_h),
                            radius=0.002, resolution=2, material=mat_oak)
_link(apron_f)

apron_b = make_rounded_cube('ApronBack', seat_w - 0.08, apron_t, apron_h,
                            location=(0, -seat_d/2 + 0.04, seat_h - seat_t - apron_h),
                            radius=0.002, resolution=2, material=mat_oak)
_link(apron_b)

for side, sx in [('L', -seat_w/2 + 0.04), ('R', seat_w/2 - 0.04)]:
    apron_s = make_rounded_cube(f'Apron{side}', apron_t, seat_d - 0.08, apron_h,
                                location=(sx, 0, seat_h - seat_t - apron_h),
                                radius=0.002, resolution=2, material=mat_oak)
    _link(apron_s)

# === CORNER BLOCKS (joinery detail) ===
for i, (cx, cy) in enumerate(leg_positions):
    block = make_rounded_cube(f'CornerBlock{i}', 0.04, 0.04, 0.03,
                              location=(cx, cy, seat_h - seat_t - 0.03),
                              radius=0.001, resolution=1, material=mat_oak)
    _link(block)

# === SCREW DETAILS ===
for i, (cx, cy) in enumerate(leg_positions):
    bpy.ops.mesh.primitive_cylinder_add(radius=0.004, depth=0.003, vertices=16,
                                        location=(cx, cy, seat_h - seat_t - 0.001))
    screw = bpy.context.active_object
    screw.name = f'Screw{i}'
    select_object(screw)
    bpy.ops.object.shade_smooth()
    apply_material(screw, mat_metal)
    _link(screw)

# === FOOT PADS (rubber) ===
mat_rubber = make_material('Rubber', (0.02, 0.02, 0.02), roughness=0.9, metallic=0.0)
for i, (fx, fy) in enumerate(leg_positions):
    bpy.ops.mesh.primitive_cylinder_add(radius=leg_r + 0.002, depth=0.005,
                                        vertices=16, location=(fx, fy, 0.0025))
    pad = bpy.context.active_object
    pad.name = f'FootPad{i}'
    select_object(pad)
    bpy.ops.object.shade_smooth()
    apply_material(pad, mat_rubber)
    _link(pad)

print(f'Chair built: {len(asset_collection.all_objects)} objects')
'''


if __name__ == "__main__":
    result = create_asset(
        asset_id='dining_chair_modern_01',
        name='Modern Dining Chair',
        category='furniture',
        subcategory='seating',
        tags=['chair', 'dining', 'modern', 'wood', 'oak', 'fabric'],
        build_script=CHAIR_SCRIPT,
        asset_type='dining_chair',
    )

    print(f"\nResult: success={result['success']}")
    if result.get('quality_report'):
        print(f"Score: {result['quality_report']['score']}/10")
    if result.get('thumbnail_path') and os.path.exists(result['thumbnail_path']):
        print(f"Thumbnail: {result['thumbnail_path']}")
    if result.get('blend_path') and os.path.exists(result['blend_path']):
        print(f"Blend: {result['blend_path']}")
