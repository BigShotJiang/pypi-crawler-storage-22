from .version import __version__, check_version, auto_update
from .colors import color, apply_colors
from .io_helpers import (
    typingprint, typingprint_nl, colourprint, colourprint_nl,
    typinginput, colourinput, typingintructions, error, spinner, progress_bar
)
from .timing import wait
from .screens import clear, countdown, loading_screen

# DON'T automatically call check_version() here — user can call it explicitly

__all__ = [
    "__version__", "check_version", "auto_update",
    "color", "apply_colors",
    "typingprint", "typingprint_nl", "colourprint", "colourprint_nl",
    "typinginput", "colourinput", "typingintructions", "error", "spinner", "progress_bar",
    "wait",
    "clear", "countdown", "loading_screen"
]
