class color:
    # Standard colours
    BLUE = '\033[94m'        
    CYAN = '\033[96m'        
    GREEN = '\033[92m'       
    PURPLE = '\033[95m'      
    RED = '\033[91m'        
    YELLOW = '\033[93m'     

    # Dark colours
    DARKBLUE = "\033[38;5;27m"  
    DARKCYAN = '\033[36m'        
    DARKPURPLE = "\033[38;5;54m" 

    # Accents
    BOLD = '\033[1m'            
    UNDERLINE = '\033[4m'        
    END = '\033[0m'             

_color_dict = {
    'BLUE': color.BLUE,
    'CYAN': color.CYAN,
    'GREEN': color.GREEN,
    'PURPLE': color.PURPLE,
    'RED': color.RED,
    'YELLOW': color.YELLOW,
    'DARKBLUE': color.DARKBLUE,
    'DARKCYAN': color.DARKCYAN,
    'DARKPURPLE': color.DARKPURPLE,
    'BOLD': color.BOLD,          
    'UNDERLINE': color.UNDERLINE, 
    'END': color.END,
}

# Apply color codes to text
def apply_colors(text: str) -> str:
    for name, code in _color_dict.items():
        text = text.replace(f'{{{name}}}', code)
    return text + color.END
