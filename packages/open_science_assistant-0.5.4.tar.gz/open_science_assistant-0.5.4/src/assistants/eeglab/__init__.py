"""EEGLAB community assistant."""

__all__ = []  # No specialized tools in Phase 1
