"""CLI interface for Open Science Assistant."""
