"""Domain models for Open Science Assistant."""
