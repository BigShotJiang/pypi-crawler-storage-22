"""Shared utilities for Open Science Assistant."""
