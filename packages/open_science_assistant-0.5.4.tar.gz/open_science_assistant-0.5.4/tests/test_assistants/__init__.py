"""Tests for OSA assistants package."""
