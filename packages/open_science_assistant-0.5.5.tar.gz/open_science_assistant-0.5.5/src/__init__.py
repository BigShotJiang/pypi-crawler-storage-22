"""Open Science Assistant (OSA) - An extensible AI assistant platform for open science projects."""

from src.version import __version__, __version_info__

__all__ = ["__version__", "__version_info__"]
