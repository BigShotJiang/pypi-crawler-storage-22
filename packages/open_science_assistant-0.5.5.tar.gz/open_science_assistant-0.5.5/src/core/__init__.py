"""Core business logic for Open Science Assistant."""
