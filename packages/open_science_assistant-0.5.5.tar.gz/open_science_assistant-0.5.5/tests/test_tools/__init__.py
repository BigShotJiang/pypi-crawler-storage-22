"""Tests for OSA tools."""
