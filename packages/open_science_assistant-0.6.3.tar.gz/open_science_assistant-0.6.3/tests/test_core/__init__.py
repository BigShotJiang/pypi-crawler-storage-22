"""Core business logic tests."""
