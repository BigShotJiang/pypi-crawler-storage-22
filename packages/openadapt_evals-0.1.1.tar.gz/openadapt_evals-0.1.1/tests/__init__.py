"""Test suite for openadapt-evals package."""
