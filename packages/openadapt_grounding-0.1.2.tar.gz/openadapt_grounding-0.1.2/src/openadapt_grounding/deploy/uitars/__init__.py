"""UI-TARS deployment module."""

from .deploy import Deploy

__all__ = ["Deploy"]
