"""Tests for openadapt-retrieval package."""
