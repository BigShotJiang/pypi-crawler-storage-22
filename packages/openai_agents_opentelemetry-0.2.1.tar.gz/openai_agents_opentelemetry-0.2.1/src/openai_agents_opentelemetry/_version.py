"""Version information for openai-agents-opentelemetry."""

__version__ = "0.2.1"
