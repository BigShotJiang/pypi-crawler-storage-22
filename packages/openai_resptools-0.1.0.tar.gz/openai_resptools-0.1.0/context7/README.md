# context7 docs

This folder contains a compact documentation bundle for `openai-resptools` intended to be:
- Easy to skim for humans
- Easy to ingest for tooling/LLMs
- Grounded in the current source code and examples

## Contents

- [Overview](overview.md)
- [API](api.md)
- [Architecture](architecture.md)
- [Schema & strictness](schema-and-strictness.md)
- [Examples](examples.md)
- [Errors](errors.md)

