"""
openai-resptools

Ergonomic tool-calling wrapper for the OpenAI Responses API.
"""

from .errors import (
    RunnerError,
    RunnerMaxIterationsError,
    ToolArgumentsError,
    ToolExecutionError,
    ToolNotFoundError,
)
from .registry import ToolRegistry
from .runner import ToolRunner, run
from .tool import ToolDef
from .types import RunnerResult

__all__ = [
    "RunnerError",
    "RunnerMaxIterationsError",
    "ToolArgumentsError",
    "ToolExecutionError",
    "ToolNotFoundError",
    "ToolRegistry",
    "ToolRunner",
    "ToolDef",
    "RunnerResult",
    "run",
]
