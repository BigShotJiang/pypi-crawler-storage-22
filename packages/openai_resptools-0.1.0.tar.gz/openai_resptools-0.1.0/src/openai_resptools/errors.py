from __future__ import annotations


class RespToolsError(Exception):
    """Base exception for this package."""


class ToolNotFoundError(RespToolsError, KeyError):
    """Raised when a tool name is missing from the registry."""


class ToolArgumentsError(RespToolsError, ValueError):
    """Raised when tool arguments cannot be parsed/validated."""


class ToolExecutionError(RespToolsError, RuntimeError):
    """Raised when the tool callable itself fails."""

    def __init__(
        self, tool_name: str, message: str, *, cause: Exception | None = None
    ) -> None:
        super().__init__(f"Tool '{tool_name}' failed: {message}")
        self.tool_name = tool_name
        self.__cause__ = cause


class RunnerError(RespToolsError):
    """Raised for runner-level errors."""


class RunnerMaxIterationsError(RunnerError):
    """Raised when the runner hits max tool-call iterations."""
