from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Protocol, Sequence, TypedDict, Union

JSON = Union[None, bool, int, float, str, List["JSON"], Dict[str, "JSON"]]


class FunctionCallItem(TypedDict, total=False):
    type: str
    id: str
    call_id: str
    name: str
    arguments: str


class FunctionCallOutputItem(TypedDict, total=False):
    type: str
    call_id: str
    output: str


InputItem = Dict[str, Any]
InputList = List[InputItem]
ToolsPayload = List[Dict[str, Any]]


class ResponsesClient(Protocol):
    """Minimal protocol for OpenAI client compatibility."""

    class responses(Protocol):
        @staticmethod
        def create(**kwargs: Any) -> Any: ...


@dataclass(frozen=True)
class RunnerResult:
    """Result of a single `run()` call."""

    text: str
    input_items: Sequence[InputItem]
    last_response: Any
