import os
import sys

# Ensure src is in path
sys.path.insert(0, os.path.abspath("src"))

from openai_resptools import ToolRegistry


class MyTools(ToolRegistry):
    def tool_one(self, x: int) -> int:
        """Tool one description."""
        return x + 1

    def tool_two(self, name: str) -> str:
        """Tool two description."""
        return f"Hello {name}"


def test_subclass_registration():
    reg = MyTools()

    print("Tools registered:", reg.names())

    assert "tool_one" in reg.names()
    assert "tool_two" in reg.names()
    assert "add" not in reg.names()  # Should not register base methods

    tool1 = reg.get("tool_one")
    assert tool1.description == "Tool one description."

    print("Subclass registration test passed!")


def test_object_registration():
    class SeparateTools:
        def external_tool(self):
            """External tool."""
            pass

    reg = ToolRegistry()
    tools_obj = SeparateTools()
    reg.register_object(tools_obj)

    print("External tools registered:", reg.names())
    assert "external_tool" in reg.names()

    print("Object registration test passed!")


if __name__ == "__main__":
    test_subclass_registration()
    test_object_registration()
