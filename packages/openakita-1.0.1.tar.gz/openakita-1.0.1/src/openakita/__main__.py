"""
OpenAkita 模块入口

允许通过 python -m openakita 运行
"""

from .main import app

if __name__ == "__main__":
    app()
