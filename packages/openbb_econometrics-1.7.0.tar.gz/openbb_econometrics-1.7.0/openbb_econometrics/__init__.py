"""OpenBB Econometrics Extension."""
