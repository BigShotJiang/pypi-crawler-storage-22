"""Fundamentals."""
