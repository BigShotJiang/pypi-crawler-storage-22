#!/usr/bin/env python3
"""한국투자증권(KIS) 범용 MCP 서버 (로컬 — 사용자 컨테이너)

PDR v5 정의: KIS MCP Docker 컨테이너 SSE 브릿지 + DB 자동저장
포트: 8202
모의/실전: KIS_ENV=mock or KIS_ENV=live

도구 3개:
  - kis_call_tool     : KIS MCP 컨테이너의 모든 도구 범용 호출 + DB 자동저장
  - kis_list_tools    : KIS MCP 컨테이너의 사용 가능한 도구 목록
  - kis_get_env_info  : 현재 환경 정보 (env, kis_mcp_url)

DB 저장 흐름:
  1) hub_api_responses — 모든 API 응답 무조건 JSONB 저장 (kis:도구명)
  2) kis_api_responses — KIS 전용 로그 테이블
  3) 정규화 테이블 — tool_name 라우팅
     price/inquire → kis_prices    (시세 조회)
     balance       → kis_balances  (잔고)
     order         → kis_orders    (주문)

사용 예시:
    KIS_ENV=live KIS_MCP_URL=http://127.0.0.1:3001 python kis_mcp_server.py
"""

import os
import sys
import json
import hashlib
import asyncio
import threading
from pathlib import Path
from typing import Any, Dict

try:
    import psycopg2
    import psycopg2.extras
    _HAS_PG = True
except ImportError:
    _HAS_PG = False
    print("[DB] psycopg2 not installed - DB save disabled")

from fastmcp import FastMCP, Client

# ─── 환경 설정 ────────────────────────────────────────────
KIS_MCP_URL = os.getenv("KIS_MCP_URL", "http://127.0.0.1:3001")
KIS_ENV = os.getenv("KIS_ENV", "live")  # live or mock

# ─── PostgreSQL 자동저장 ─────────────────────────────────────
_pg_conn = None
_pg_getter = None  # Gateway에서 주입, 없으면 로컬 _get_pg 사용


def _get_pg():
    """PostgreSQL 연결 (재사용, 실패 시 None)"""
    global _pg_conn
    if not _HAS_PG:
        return None
    try:
        if _pg_conn is None or _pg_conn.closed:
            _pg_conn = psycopg2.connect(
                host=os.getenv("PG_HOST", "localhost"),
                port=int(os.getenv("PG_PORT", "5432")),
                dbname=os.getenv("PG_DB", "shared_data_lake"),
                user=os.getenv("PG_USER", "hub"),
                password=os.getenv("PG_PASSWORD", ""),
                connect_timeout=5,
            )
            _pg_conn.autocommit = True
            print("[DB] PostgreSQL 연결 성공 (kis)")
        return _pg_conn
    except Exception as e:
        print(f"[DB] PostgreSQL 연결 실패: {e}")
        return None


def _kis_db_save(tool_name: str, params: dict, result: dict):
    """KIS 도구 응답 DB 저장

    1) hub_api_responses: 통합 로그 (kis:도구명)
    2) kis_api_responses: KIS 전용 로그
    3) 정규화 테이블: tool_name 라우팅 (kis_prices, kis_balances, kis_orders)

    autocommit=True이므로 각 INSERT는 즉시 커밋.
    """
    conn = (_pg_getter or _get_pg)()
    if not conn:
        return
    try:
        r_json = json.dumps(result, ensure_ascii=False, default=str)
        p_json = json.dumps(params, ensure_ascii=False, default=str)
        p_hash = hashlib.md5(p_json.encode()).hexdigest()
        env = os.getenv("KIS_ENV", "live")

        with conn.cursor() as cur:
            # 1) hub_api_responses 통합 로그
            cur.execute(
                """INSERT INTO hub_api_responses (tool_name, params_hash, params, response)
                   VALUES (%s, %s, %s::jsonb, %s::jsonb)""",
                (f"kis:{tool_name}", p_hash, p_json, r_json),
            )
            # 2) kis_api_responses 전용 로그
            cur.execute(
                """INSERT INTO kis_api_responses (api_path, method, params, response, env)
                   VALUES (%s, %s, %s::jsonb, %s::jsonb, %s)""",
                (tool_name, "MCP", p_json, r_json, env),
            )
            # 3) 정규화 테이블
            _kis_save_normalized(cur, tool_name, params, result, env)
    except Exception as e:
        print(f"[DB] KIS 저장 실패 ({tool_name}): {e}")


def _kis_save_normalized(cur, tool_name: str, params: dict, result: dict, env: str):
    """KIS 도구별 정규화 테이블 라우팅 저장

    tool_name 기반 라우팅:
      - "price" or "inquire" 포함 → kis_prices
      - "balance" 포함 → kis_balances
      - "order" 포함 → kis_orders

    실패 응답(success=False)은 정규화하지 않음.
    """
    if not result.get("success"):
        return

    data = result.get("data", {})
    r_json = json.dumps(data, ensure_ascii=False, default=str)
    tool_lower = tool_name.lower()

    # 시세 조회 (price, inquire)
    if "price" in tool_lower or "inquire" in tool_lower:
        ticker = params.get("ticker", params.get("FID_INPUT_ISCD", ""))
        if ticker:
            cur.execute(
                """INSERT INTO kis_prices (ticker, env, price_data)
                   VALUES (%s, %s, %s::jsonb)""",
                (ticker, env, r_json),
            )

    # 잔고
    elif "balance" in tool_lower:
        cur.execute(
            """INSERT INTO kis_balances (env, balance_data)
               VALUES (%s, %s::jsonb)""",
            (env, r_json),
        )

    # 주문
    elif "order" in tool_lower:
        ticker = params.get("ticker", params.get("PDNO", ""))
        side = params.get("side", "unknown")
        qty = int(params.get("qty", params.get("ORD_QTY", 0)))
        price = int(params.get("price", params.get("ORD_UNPR", 0)))
        cur.execute(
            """INSERT INTO kis_orders (ticker, side, qty, price, env, order_data)
               VALUES (%s, %s, %s, %s, %s, %s::jsonb)""",
            (ticker, side, qty, price, env, r_json),
        )


# ─── KIS MCP 호출 헬퍼 (SSE Client) ───────────────────────

def _kis_call_tool_impl(tool_name: str, arguments: dict = None) -> dict:
    """KIS MCP 컨테이너에 도구 호출 (SSE Client) + DB 저장

    별도 스레드에서 asyncio 이벤트 루프 실행 (fastmcp Client는 async이지만 MCP 도구는 sync)
    30초 타임아웃.
    """
    result = {}

    async def _call():
        async with Client(KIS_MCP_URL + "/sse") as client:
            raw = await client.call_tool(tool_name, arguments or {})
            # fastmcp Client 응답 파싱
            if isinstance(raw, list):
                texts = []
                for item in raw:
                    if hasattr(item, 'text'):
                        try:
                            texts.append(json.loads(item.text))
                        except (json.JSONDecodeError, TypeError):
                            texts.append(item.text)
                return {"success": True, "data": texts[0] if len(texts) == 1 else texts}
            elif isinstance(raw, dict):
                return {"success": True, "data": raw}
            else:
                return {"success": True, "data": str(raw)}

    def _run():
        nonlocal result
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            r = loop.run_until_complete(_call())
            result.update(r)
        except Exception as e:
            result.update({"success": False, "error": str(e), "error_type": "KIS_MCP_ERROR"})
        finally:
            loop.close()

    t = threading.Thread(target=_run, daemon=True)
    t.start()
    t.join(timeout=30)
    if not result:
        result = {"success": False, "error": "KIS MCP 호출 타임아웃 (30초)"}

    # DB 저장
    try:
        _kis_db_save(tool_name, arguments or {}, result)
    except Exception as e:
        print(f"[KIS DB] {tool_name} 저장 실패: {e}")
    return result


# ─── MCP 도구 3개 ──────────────────────────────────────────

def register_tools(mcp, get_pg=None):
    """FastMCP 인스턴스에 KIS 도구 3개 등록"""
    global _pg_getter
    if get_pg is not None:
        _pg_getter = get_pg

    @mcp.tool()
    def kis_call_tool(tool_name: str, args_json: str = "{}") -> dict:
        """한국투자증권(KIS) 실시간 시세 + 매매 — KIS Docker 컨테이너 프록시 (KIS 계좌 필요)

        USE THIS WHEN: KIS 계좌로 실시간 시세 조회, 주문, 잔고 확인
        DO NOT USE: 과거 주가/차트 → datakit_call, 뉴스 → news_search_stock

        Args:
            tool_name: KIS MCP 도구 이름 (예: 'get_stock_price', 'get_balance', 'order_stock')
            args_json: JSON 문자열 인자 (예: '{"ticker":"005930"}', '{"side":"buy","qty":10}')

        Returns:
            {
                "success": true,
                "data": { ... KIS MCP 응답 ... }
            }

        DB 자동저장:
            - hub_api_responses: 모든 도구 무조건 저장 (kis:도구명)
            - kis_api_responses: KIS 전용 로그
            - kis_prices: price/inquire 관련 도구
            - kis_balances: balance 관련 도구
            - kis_orders: order 관련 도구

        Note:
            kis_list_tools()로 KIS MCP 컨테이너의 도구 목록 확인 가능.
        """
        try:
            arguments = json.loads(args_json) if args_json else {}
        except json.JSONDecodeError:
            return {"success": False, "error": "args_json 파싱 실패", "tool_name": tool_name}

        return _kis_call_tool_impl(tool_name, arguments)

    @mcp.tool()
    def kis_list_tools() -> dict:
        """한국투자증권(KIS) MCP 컨테이너의 사용 가능한 도구 목록 조회

        Returns:
            {
                "success": true,
                "count": 12,
                "tools": [
                    {"name": "get_stock_price", "description": "..."},
                    {"name": "get_balance", "description": "..."},
                    ...
                ]
            }
        """
        result = {}

        async def _list():
            async with Client(KIS_MCP_URL + "/sse") as client:
                tools = await client.list_tools()
                return [{"name": t.name, "description": t.description} for t in tools]

        def _run():
            nonlocal result
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                tools = loop.run_until_complete(_list())
                result.update({"success": True, "count": len(tools), "tools": tools})
            except Exception as e:
                result.update({"success": False, "error": str(e), "error_type": "KIS_MCP_ERROR"})
            finally:
                loop.close()

        t = threading.Thread(target=_run, daemon=True)
        t.start()
        t.join(timeout=15)
        if not result:
            return {"success": False, "error": "KIS MCP 목록 조회 타임아웃 (15초)"}
        return result

    @mcp.tool()
    def kis_get_env_info() -> dict:
        """현재 KIS MCP 서버 환경 정보 조회

        Returns:
            {
                "success": true,
                "data": {
                    "env": "live" or "mock",
                    "kis_mcp_url": "http://127.0.0.1:3001",
                    "pg_db": "shared_data_lake",
                    "pg_enabled": true
                }
            }
        """
        try:
            data = {
                "env": KIS_ENV,
                "kis_mcp_url": KIS_MCP_URL,
                "pg_host": os.getenv("PG_HOST", "localhost"),
                "pg_port": int(os.getenv("PG_PORT", "5432")),
                "pg_db": os.getenv("PG_DB", "shared_data_lake"),
                "pg_user": os.getenv("PG_USER", "hub"),
                "pg_enabled": _HAS_PG,
            }
            return {"success": True, "data": data}
        except Exception as e:
            return {"success": False, "error": str(e), "error_type": type(e).__name__}


if __name__ == "__main__":
    from fastmcp import FastMCP
    mcp = FastMCP("KIS Data MCP")
    register_tools(mcp)

    print(f"KIS Data MCP Server starting...")
    print(f"   Environment: {KIS_ENV}")
    print(f"   KIS MCP URL: {KIS_MCP_URL}")
    print(f"   Tools: kis_call_tool, kis_list_tools, kis_get_env_info")
    print(f"   Port: 8202")
    print(f"   Transport: SSE")
    print(f"   PostgreSQL: {'Enabled' if _HAS_PG else 'Disabled'}")
    print()

    mcp.run(transport="sse", host="0.0.0.0", port=8202)
