"""
数据持久化和日志模块
将内存快照写入 JSONL 文件，告警写入独立日志
"""
import json
import os
import time
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Optional, IO

from .collector import MemSnapshot
from .leak_detector import LeakAlert
from .reclaimer import ReclaimResult


class DataStore:
    """数据持久化管理"""

    def __init__(self, data_dir: str = "data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)

        # 按日期分文件
        self._current_date = ""
        self._snapshot_file: Optional[IO[str]] = None
        self._alert_file: Optional[IO[str]] = None
        self._last_alert_emit = {}
        self._alert_dedupe_window_sec = 30.0

        # 设置日志
        self._setup_logging()

    def _setup_logging(self):
        """配置日志系统"""
        log_dir = self.data_dir / "logs"
        log_dir.mkdir(exist_ok=True)

        self.logger = logging.getLogger("mem_monitor")
        self.logger.setLevel(logging.DEBUG)

        # 文件handler
        fh = logging.FileHandler(
            log_dir / "monitor.log", encoding="utf-8"
        )
        fh.setLevel(logging.DEBUG)

        # 控制台handler
        ch = logging.StreamHandler()
        ch.setLevel(logging.WARNING)

        fmt = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        fh.setFormatter(fmt)
        ch.setFormatter(fmt)

        self.logger.addHandler(fh)
        self.logger.addHandler(ch)

    def _get_date_str(self) -> str:
        return datetime.now().strftime("%Y-%m-%d")

    def _rotate_files(self):
        """按日期轮转文件"""
        today = self._get_date_str()
        if today != self._current_date:
            self._current_date = today
            if self._snapshot_file:
                self._snapshot_file.close()
            if self._alert_file:
                self._alert_file.close()

            snap_path = self.data_dir / f"snapshots_{today}.jsonl"
            alert_path = self.data_dir / f"alerts_{today}.jsonl"

            self._snapshot_file = open(snap_path, "a", encoding="utf-8")
            self._alert_file = open(alert_path, "a", encoding="utf-8")
            self.logger.info(f"日志轮转: {today}")

    def save_snapshot(self, snap: MemSnapshot):
        """保存一个快照到 JSONL"""
        self._rotate_files()
        try:
            # 精简存储：不存每个进程的详细信息，只存汇总
            record = {
                "ts": snap.timestamp,
                "t": datetime.fromtimestamp(snap.timestamp).strftime("%H:%M:%S"),
                "sys": None,
                "node": {
                    "count": snap.node_process_count,
                    "ram_mb": snap.node_total_ram_mb,
                    "virt_gb": snap.node_total_virtual_gb,
                    "handles": snap.node_total_handles,
                    "threads": snap.node_total_threads,
                },
                "all": {
                    "count": snap.all_process_count,
                    "high_mem_count": len(snap.high_mem_processes),
                    "high_mem_total_mb": snap.high_mem_total_mb,
                },
                "err": snap.error or None,
            }
            if snap.system:
                record["sys"] = {
                    "total_gb": snap.system.total_ram_gb,
                    "free_gb": snap.system.free_ram_gb,
                    "used_pct": snap.system.usage_pct,
                    "commit_pct": snap.system.commit_pct,
                }

            line = json.dumps(record, ensure_ascii=False)
            if self._snapshot_file:
                self._snapshot_file.write(line + "\n")
                self._snapshot_file.flush()
        except Exception as e:
            self.logger.error(f"保存快照失败: {e}")

    def save_alerts(self, alerts: List[LeakAlert]):
        """保存告警到 JSONL"""
        if not alerts:
            return
        self._rotate_files()
        try:
            for alert in alerts:
                dedupe_key = (alert.level, alert.metric)
                last_ts = self._last_alert_emit.get(dedupe_key, 0.0)
                if (alert.timestamp - last_ts) < self._alert_dedupe_window_sec:
                    continue

                record = {
                    "ts": alert.timestamp,
                    "t": datetime.fromtimestamp(alert.timestamp).strftime("%H:%M:%S"),
                    "level": alert.level,
                    "metric": alert.metric,
                    "msg": alert.message,
                    "value": alert.current_value,
                    "rate": alert.growth_rate_per_min,
                    "exhaust_min": alert.predicted_exhaust_min,
                }
                line = json.dumps(record, ensure_ascii=False)
                if self._alert_file:
                    self._alert_file.write(line + "\n")
                    self._alert_file.flush()
                self._last_alert_emit[dedupe_key] = alert.timestamp

                # 同时写入日志
                log_fn = {
                    "warning": self.logger.warning,
                    "critical": self.logger.critical,
                    "emergency": self.logger.critical,
                }.get(alert.level, self.logger.warning)
                log_fn(f"[{alert.level.upper()}] {alert.message}")
        except Exception as e:
            self.logger.error(f"保存告警失败: {e}")

    def save_reclaim(self, result: ReclaimResult):
        """保存回收操作记录到 JSONL"""
        if not result.actions:
            return
        self._rotate_files()
        try:
            dry_run_count = 0
            reclaim_count = 0
            fail_count = 0
            for action in result.actions:
                if action.reason.startswith("[SKIP]"):
                    continue

                record = {
                    "ts": action.timestamp,
                    "t": datetime.fromtimestamp(action.timestamp).strftime("%H:%M:%S"),
                    "type": "reclaim",
                    "pid": action.pid,
                    "name": action.name,
                    "ram_mb": action.ram_mb,
                    "age_min": action.age_minutes,
                    "reason": action.reason,
                    "success": action.success,
                    "decision_state": action.decision_state,
                    "protection_tier": action.protection_tier,
                    "simulated": action.simulated,
                    "error": action.error or None,
                }
                line = json.dumps(record, ensure_ascii=False)
                if self._alert_file:
                    self._alert_file.write(line + "\n")

                if action.simulated and action.reason.startswith("[DRY RUN]"):
                    dry_run_count += 1
                elif action.success:
                    reclaim_count += 1
                else:
                    fail_count += 1

            if self._alert_file:
                self._alert_file.flush()

            if dry_run_count:
                self.logger.info(f"[DRY RUN] 本轮候选 {dry_run_count} 个")
            if reclaim_count:
                self.logger.info(f"[RECLAIM] 本轮成功 {reclaim_count} 个")
            if fail_count:
                fail_details = []
                for action in actions:
                    if not action.simulated and not action.success:
                        err = action.error or "未知原因"
                        fail_details.append(
                            f"  PID={action.pid} {action.name} "
                            f"RAM={action.ram_mb:.0f}MB | {err}"
                        )
                detail_str = "\n".join(fail_details)
                self.logger.warning(
                    f"[RECLAIM FAIL] 本轮失败 {fail_count} 个:\n{detail_str}"
                )
        except Exception as e:
            self.logger.error(f"保存回收记录失败: {e}")

    def close(self):
        """关闭文件句柄"""
        if self._snapshot_file:
            self._snapshot_file.close()
            self._snapshot_file = None
        if self._alert_file:
            self._alert_file.close()
            self._alert_file = None
