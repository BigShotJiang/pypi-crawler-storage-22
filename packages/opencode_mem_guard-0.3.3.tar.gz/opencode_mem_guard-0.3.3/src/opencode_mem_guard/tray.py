"""
系统托盘图标模块
使用 pystray + Pillow 实现动态颜色托盘图标
"""
import os
import subprocess
import threading
from pathlib import Path
from typing import Callable, Optional, List, Dict

from PIL import Image, ImageDraw

from .state_labels import decision_state_label
import pystray


# 状态颜色映射
STATUS_COLORS = {
    "normal": (63, 185, 80),      # #3fb950 绿色
    "warning": (210, 153, 34),     # #d29922 黄色
    "critical": (248, 81, 73),     # #f85149 红色
}


def create_icon_image(color: tuple = (63, 185, 80), size: int = 64) -> Image.Image:
    """
    动态生成托盘图标 — 纯色圆形
    
    Args:
        color: RGB 颜色元组
        size: 图标尺寸
    
    Returns:
        PIL Image 对象
    """
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # 外圈（稍暗的边框）
    border_color = tuple(max(0, c - 40) for c in color) + (255,)
    draw.ellipse([2, 2, size - 3, size - 3], fill=border_color)
    
    # 内圈（主色）
    draw.ellipse([4, 4, size - 5, size - 5], fill=color + (255,))
    
    # 高光点
    highlight = tuple(min(255, c + 80) for c in color) + (180,)
    draw.ellipse([size // 4, size // 6, size // 2, size // 3], fill=highlight)
    
    return img


class TrayManager:
    """
    系统托盘管理器
    
    职责：
    - 显示/更新托盘图标（颜色随状态变化）
    - 右键菜单：显示/隐藏浮球、自动回收开关、立即回收、开机自启、退出
    - 左键点击切换浮球显示
    """
    
    def __init__(
        self,
        on_toggle_ball: Optional[Callable] = None,
        on_toggle_reclaim: Optional[Callable] = None,
        on_force_reclaim: Optional[Callable] = None,
        on_cycle_decision_state: Optional[Callable] = None,
        on_set_decision_state: Optional[Callable] = None,
        on_toggle_app_policy: Optional[Callable] = None,
        on_open_policy_panel: Optional[Callable] = None,
        on_toggle_autostart: Optional[Callable] = None,
        on_quit: Optional[Callable] = None,
        get_reclaim_state: Optional[Callable] = None,
        get_decision_state: Optional[Callable] = None,
        get_app_policy_entries: Optional[Callable] = None,
        get_autostart_state: Optional[Callable] = None,
        get_ball_visible: Optional[Callable] = None,
        data_dir: str = "",
    ):
        self._on_toggle_ball = on_toggle_ball or (lambda: None)
        self._on_toggle_reclaim = on_toggle_reclaim or (lambda: None)
        self._on_force_reclaim = on_force_reclaim or (lambda: None)
        self._on_cycle_decision_state = on_cycle_decision_state or (lambda: None)
        self._on_set_decision_state = on_set_decision_state or (lambda mode: None)
        self._on_toggle_app_policy = on_toggle_app_policy or (lambda app_name: None)
        self._on_open_policy_panel = on_open_policy_panel or (lambda: None)
        self._on_toggle_autostart = on_toggle_autostart or (lambda: None)
        self._on_quit = on_quit or (lambda: None)
        self._get_reclaim_state = get_reclaim_state or (lambda: True)
        self._get_decision_state = get_decision_state or (lambda: "warn")
        self._get_app_policy_entries = get_app_policy_entries or (lambda: [])
        self._get_autostart_state = get_autostart_state or (lambda: False)
        self._get_ball_visible = get_ball_visible or (lambda: True)
        self._data_dir = data_dir or str(Path.home() / ".opencode-mem-guard" / "data")
        
        self._current_status = "normal"
        self._tooltip = "OpenCode MemGuard"
        self._icon = None
        self._lock = threading.Lock()
    
    def _build_menu(self):
        """构建右键菜单（紧凑布局）"""
        mode_menu = pystray.Menu(
            pystray.MenuItem(
                "循环切换",
                self._handle_cycle_decision_state,
            ),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem(
                f"{decision_state_label('observe')}",
                lambda icon, item: self._handle_set_decision_state(icon, "observe"),
                checked=lambda item: self._get_decision_state() == "observe",
            ),
            pystray.MenuItem(
                f"{decision_state_label('warn')}",
                lambda icon, item: self._handle_set_decision_state(icon, "warn"),
                checked=lambda item: self._get_decision_state() == "warn",
            ),
            pystray.MenuItem(
                f"{decision_state_label('enforce')}",
                lambda icon, item: self._handle_set_decision_state(icon, "enforce"),
                checked=lambda item: self._get_decision_state() == "enforce",
            ),
        )

        return pystray.Menu(
            pystray.MenuItem(
                "浮球显示",
                self._handle_toggle_ball,
                checked=lambda item: self._get_ball_visible(),
            ),
            pystray.MenuItem(
                "自动回收",
                self._handle_toggle_reclaim,
                checked=lambda item: self._get_reclaim_state(),
            ),
            pystray.MenuItem(
                "治理模式",
                mode_menu,
            ),
            pystray.MenuItem(
                "应用策略",
                self._build_app_policy_menu(),
            ),
            pystray.MenuItem(
                "开机自启",
                self._handle_toggle_autostart,
                checked=lambda item: self._get_autostart_state(),
            ),
            pystray.MenuItem(
                "立即回收",
                self._handle_force_reclaim,
            ),
            pystray.MenuItem(
                "查看日志",
                self._handle_open_log,
            ),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem(
                "退出",
                self._handle_quit,
            ),
        )

    def _build_app_policy_menu(self):
        entries: List[Dict] = self._get_app_policy_entries()
        items = []

        if not entries:
            items.append(pystray.MenuItem("暂无监测应用", lambda icon, item: None, enabled=False))
        else:
            for entry in entries:
                name = entry.get("name", "")
                ram = entry.get("ram_mb", 0.0)
                label = f"{name} ({ram:.0f}MB)"
                if len(label) > 34:
                    label = label[:34] + "..."
                items.append(
                    pystray.MenuItem(
                        label,
                        self._make_toggle_app_action(name),
                        checked=self._make_toggle_app_checked(name),
                    )
                )

        items.append(pystray.Menu.SEPARATOR)
        items.append(pystray.MenuItem("打开策略面板", self._handle_open_policy_panel))
        return pystray.Menu(*items)

    def _make_toggle_app_action(self, app_name: str):
        def _action(icon, item):
            self._handle_toggle_app_policy(icon, app_name)
        return _action

    def _make_toggle_app_checked(self, app_name: str):
        def _checked(item):
            return self._is_app_auto_cleanup_enabled(app_name)
        return _checked

    def _is_app_auto_cleanup_enabled(self, app_name: str) -> bool:
        for entry in self._get_app_policy_entries():
            if entry.get("name") == app_name:
                return bool(entry.get("auto_cleanup"))
        return False
    
    def _handle_toggle_ball(self, icon, item):
        threading.Thread(target=self._on_toggle_ball, daemon=True).start()
    
    def _handle_toggle_reclaim(self, icon, item):
        self._on_toggle_reclaim()
        # 刷新菜单勾选状态
        try:
            icon.menu = self._build_menu()
            icon.update_menu()
        except Exception:
            pass
    
    def _handle_force_reclaim(self, icon, item):
        threading.Thread(target=self._on_force_reclaim, daemon=True).start()

    def _handle_cycle_decision_state(self, icon, item):
        self._on_cycle_decision_state()
        try:
            icon.menu = self._build_menu()
            icon.update_menu()
        except Exception:
            pass

    def _handle_set_decision_state(self, icon, mode: str):
        self._on_set_decision_state(mode)
        try:
            icon.menu = self._build_menu()
            icon.update_menu()
        except Exception:
            pass

    def _handle_toggle_app_policy(self, icon, app_name: str):
        self._on_toggle_app_policy(app_name)
        try:
            icon.menu = self._build_menu()
            icon.update_menu()
        except Exception:
            pass

    def _handle_open_policy_panel(self, icon, item):
        self._on_open_policy_panel()
    
    def _handle_toggle_autostart(self, icon, item):
        self._on_toggle_autostart()
        # 强制刷新菜单，确保勾选标记立即更新
        try:
            icon.menu = self._build_menu()
            icon.update_menu()
        except Exception:
            pass
    
    def _handle_open_log(self, icon, item):
        """启动独立进程的日志查看器"""
        try:
            import sys
            log_path = str(Path(self._data_dir) / "logs" / "monitor.log")
            python = sys.executable
            subprocess.Popen(
                [python, "-m", "opencode_mem_guard.log_viewer", log_path],
                creationflags=0x00000008,  # DETACHED_PROCESS
            )
        except Exception:
            # 回退：打开目录
            try:
                os.makedirs(self._data_dir, exist_ok=True)
                subprocess.Popen(["explorer", self._data_dir])
            except Exception:
                pass

    def _handle_quit(self, icon, item):
        self._on_quit()
        if self._icon:
            self._icon.stop()
    
    def update_status(self, status: str, tooltip: str = ""):
        """
        更新托盘图标状态
        
        Args:
            status: "normal" | "warning" | "critical"
            tooltip: 悬浮提示文字
        """
        with self._lock:
            if status != self._current_status or tooltip != self._tooltip:
                self._current_status = status
                if tooltip:
                    self._tooltip = tooltip
                
                if self._icon:
                    color = STATUS_COLORS.get(status, STATUS_COLORS["normal"])
                    self._icon.icon = create_icon_image(color)
                    if tooltip:
                        self._icon.title = tooltip
    
    def run(self):
        """
        启动托盘图标（阻塞调用，应在主线程运行）
        """
        color = STATUS_COLORS.get(self._current_status, STATUS_COLORS["normal"])
        
        self._icon = pystray.Icon(
            name="opencode-mem-guard",
            icon=create_icon_image(color),
            title=self._tooltip,
            menu=self._build_menu(),
        )
        
        icon = self._icon
        if icon is not None:
            icon.run()
    
    def stop(self):
        """停止托盘图标"""
        if self._icon:
            self._icon.stop()

    def notify(self, title: str, message: str):
        """托盘气泡通知。"""
        try:
            if self._icon:
                self._icon.notify(message, title)
        except Exception:
            pass
