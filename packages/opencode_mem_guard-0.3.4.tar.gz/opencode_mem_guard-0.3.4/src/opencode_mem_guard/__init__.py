"""OpenCode Memory Guard - 内存泄漏监控与僵尸进程回收"""

__version__ = "0.3.4"
