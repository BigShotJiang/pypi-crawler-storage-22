"""全进程回收模块（分级决策 + 安全策略）。"""

import logging
import os
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List, Optional, Set, Tuple

import psutil

from .collector import _get_global_memory_status
from .state_labels import decision_state_label

DECISION_OBSERVE = "observe"
DECISION_WARN = "warn"
DECISION_DRY_RUN = "dry-run"
DECISION_ENFORCE = "enforce"

TIER_CRITICAL = "critical"
TIER_PROTECTED = "protected"
TIER_RECLAIMABLE = "reclaimable"


@dataclass
class ZombieCandidate:
    pid: int
    name: str
    exe_path: str
    create_time: float
    ram_mb: float
    cpu_pct_sample1: float
    cpu_pct_sample2: float
    age_minutes: float
    handle_count: int
    has_children: bool
    parent_pid: Optional[int]
    cmdline: str


@dataclass
class ReclaimAction:
    timestamp: float
    pid: int
    name: str
    ram_mb: float
    age_minutes: float
    reason: str
    success: bool
    decision_state: str
    protection_tier: str
    simulated: bool = False
    error: str = ""


@dataclass
class ReclaimResult:
    timestamp: float
    scanned: int
    zombies_found: int
    killed: int
    freed_mb: float
    decision_state: str
    actions: List[ReclaimAction] = field(default_factory=list)
    protected_pids: Set[int] = field(default_factory=set)
    skipped: int = 0


class ProcessReclaimer:
    def __init__(
        self,
        min_age_minutes: float = 30.0,
        cpu_sample_interval: float = 2.0,
        idle_cpu_threshold_pct: float = 0.0,
        min_reclaim_ram_mb: float = 200.0,
        decision_state: str = DECISION_ENFORCE,
        cooldown_minutes: float = 5.0,
        per_pid_cooldown_minutes: float = 30.0,
        max_kills_per_cycle: int = 3,
        max_kills_per_minute: int = 6,
        emergency_pause_ram_pct: float = 95.0,
        enforce_require_double_confirm: bool = True,
        enforce_confirm_window_seconds: int = 15,
        enforce_whitelist_names: Optional[List[str]] = None,
        protected_names: Optional[List[str]] = None,
        protected_path_keywords: Optional[List[str]] = None,
        critical_process_names: Optional[List[str]] = None,
        logger: Optional[logging.Logger] = None,
    ):
        self.min_age_minutes = min_age_minutes
        self.cpu_sample_interval = cpu_sample_interval
        self.idle_cpu_threshold_pct = idle_cpu_threshold_pct
        self.min_reclaim_ram_mb = min_reclaim_ram_mb
        self.decision_state = DECISION_WARN
        self.cooldown_minutes = cooldown_minutes
        self.per_pid_cooldown_minutes = per_pid_cooldown_minutes
        self.max_kills_per_cycle = max_kills_per_cycle
        self.max_kills_per_minute = max_kills_per_minute
        self.emergency_pause_ram_pct = emergency_pause_ram_pct
        self.enforce_require_double_confirm = enforce_require_double_confirm
        self.enforce_confirm_window_seconds = enforce_confirm_window_seconds
        self.enforce_whitelist_names = {
            x.lower() for x in (enforce_whitelist_names or [])
        }
        self.protected_names = {x.lower() for x in (protected_names or [])}
        self.protected_path_keywords = {x.lower() for x in (protected_path_keywords or [])}
        self.critical_process_names = {x.lower() for x in (critical_process_names or [])}
        self.logger = logger or logging.getLogger("reclaimer")

        # 启动后先冷却一个周期，避免一开机立即触发高负载扫描
        self._last_reclaim_time = time.time()
        self._kill_history: List[ReclaimAction] = []
        self._recent_kill_timestamps: Deque[float] = deque()
        self._pid_cooldown: Dict[str, float] = {}
        self._enforce_armed_until = 0.0
        self._recent_skip_reasons: Deque[str] = deque(maxlen=20)

        # 初始化阶段也必须经过 enforce 安全闸门
        self.set_decision_state(decision_state)

    def set_decision_state(self, decision_state: str) -> None:
        state = (decision_state or DECISION_ENFORCE).lower()
        if state == DECISION_DRY_RUN:
            state = DECISION_ENFORCE
        if state not in {DECISION_OBSERVE, DECISION_WARN, DECISION_ENFORCE}:
            return
        if state == DECISION_ENFORCE and not self._can_enter_enforce():
            self.decision_state = DECISION_WARN
            return
        self.decision_state = state

    def arm_enforce(self) -> float:
        self._enforce_armed_until = time.time() + self.enforce_confirm_window_seconds
        return self._enforce_armed_until

    def _can_enter_enforce(self, log: bool = True) -> bool:
        if not self.enforce_whitelist_names:
            if log:
                self.logger.warning("enforce 被拒绝：未配置 enforce_whitelist_names")
            return False
        if not self.enforce_require_double_confirm:
            return True
        if time.time() <= self._enforce_armed_until:
            return True
        if log:
            self.logger.warning("enforce 被拒绝：需要在确认窗口内二次确认")
        return False

    def can_enter_enforce(self) -> bool:
        return self._can_enter_enforce()

    def can_enter_enforce_silent(self) -> bool:
        return self._can_enter_enforce(log=False)

    def set_policy_lists(
        self,
        enforce_whitelist_names: Optional[List[str]] = None,
        protected_names: Optional[List[str]] = None,
    ) -> None:
        """运行时更新白名单/黑名单策略。"""
        if enforce_whitelist_names is not None:
            self.enforce_whitelist_names = {x.lower() for x in enforce_whitelist_names}
        if protected_names is not None:
            self.protected_names = {x.lower() for x in protected_names}

    def should_run(self) -> bool:
        if self._last_reclaim_time == 0:
            return True
        elapsed = (time.time() - self._last_reclaim_time) / 60.0
        return elapsed >= self.cooldown_minutes

    def _append_history(self, action: ReclaimAction) -> None:
        self._kill_history.append(action)
        if len(self._kill_history) > 200:
            self._kill_history = self._kill_history[-200:]

    def _remember_skip(self, action: ReclaimAction) -> None:
        msg = f"PID={action.pid} {action.name} {action.reason}"
        self._recent_skip_reasons.append(msg)

    def _cooldown_key(self, pid: int, create_time: float) -> str:
        return f"{pid}:{int(create_time)}"

    def _is_in_pid_cooldown(self, pid: int, create_time: float) -> bool:
        ts = self._pid_cooldown.get(self._cooldown_key(pid, create_time))
        if ts is None:
            return False
        return (time.time() - ts) / 60.0 < self.per_pid_cooldown_minutes

    def _mark_pid_cooldown(self, pid: int, create_time: float) -> None:
        self._pid_cooldown[self._cooldown_key(pid, create_time)] = time.time()

    def _cleanup_rate_window(self) -> None:
        now = time.time()
        while self._recent_kill_timestamps and now - self._recent_kill_timestamps[0] > 60:
            self._recent_kill_timestamps.popleft()

    def _allow_global_kill(self) -> bool:
        self._cleanup_rate_window()
        return len(self._recent_kill_timestamps) < self.max_kills_per_minute

    def _record_global_kill(self) -> None:
        self._recent_kill_timestamps.append(time.time())

    def _classify_tier(self, pid: int, name: str, exe_path: str, protected_pids: Set[int]) -> str:
        lname = (name or "").lower()
        lexep = (exe_path or "").lower()
        if lname in self.critical_process_names:
            return TIER_CRITICAL
        if pid in protected_pids:
            return TIER_PROTECTED
        if lname in self.protected_names:
            return TIER_PROTECTED
        for keyword in self.protected_path_keywords:
            if keyword and keyword in lexep:
                return TIER_PROTECTED
        return TIER_RECLAIMABLE

    def _is_system_under_pressure(self) -> bool:
        try:
            return psutil.virtual_memory().percent >= self.emergency_pause_ram_pct
        except Exception:
            return False

    def _get_commit_pct(self) -> float:
        """获取真实 commit 使用率 (0~100)，用于回收决策。"""
        stat = _get_global_memory_status()
        if stat is not None and stat.ullTotalPageFile > 0:
            charge = stat.ullTotalPageFile - stat.ullAvailPageFile
            return charge / stat.ullTotalPageFile * 100.0
        return 0.0

    def _is_commit_under_pressure(self, threshold_pct: float = 85.0) -> bool:
        """commit 使用率是否超过阈值。"""
        return self._get_commit_pct() >= threshold_pct

    def find_protected_pids(self) -> Set[int]:
        protected = {os.getpid()}
        try:
            for proc in psutil.process_iter(["pid", "name"]):
                try:
                    name = (proc.info["name"] or "").lower()
                    if name in {"opencode.exe", "opencode-cli.exe"}:
                        protected.add(proc.info["pid"])
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except Exception as e:
            self.logger.error(f"查找受保护进程失败: {e}")
        return protected

    def scan_zombies(self, protected_pids: Set[int]) -> Tuple[List[ZombieCandidate], int, List[ReclaimAction]]:
        candidates: Dict[int, dict] = {}
        skipped_actions: List[ReclaimAction] = []
        now = time.time()
        scanned = 0
        commit_pressure = self._is_commit_under_pressure(85.0)
        for proc in psutil.process_iter(["pid", "name", "create_time"]):
            try:
                scanned += 1
                pid = proc.info["pid"]
                name = proc.info["name"] or ""
                create_time = proc.info.get("create_time") or 0.0
                age_min = (now - create_time) / 60.0 if create_time > 0 else 0.0
                if age_min < self.min_age_minutes:
                    continue
                mem = proc.memory_info()
                ram_mb = mem.rss / 1048576
                # commit 高压时用 VMS (虚拟内存) 作为筛选指标，
                # 因为 VMS 大的进程是 commit 大户，即使 RSS 不高
                effective_mb = mem.vms / 1048576 if commit_pressure else ram_mb
                if effective_mb < self.min_reclaim_ram_mb:
                    continue
                try:
                    exe_path = proc.exe()
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    exe_path = ""
                tier = self._classify_tier(pid, name, exe_path, protected_pids)
                if tier != TIER_RECLAIMABLE:
                    skipped_actions.append(
                        ReclaimAction(
                            timestamp=time.time(),
                            pid=pid,
                            name=name,
                            ram_mb=ram_mb,
                            age_minutes=age_min,
                            reason=f"[SKIP] 受保护规则命中: tier={tier}",
                            success=False,
                            decision_state=self.decision_state,
                            protection_tier=tier,
                            simulated=True,
                        )
                    )
                    continue
                if self._is_in_pid_cooldown(pid, create_time):
                    skipped_actions.append(
                        ReclaimAction(
                            timestamp=time.time(),
                            pid=pid,
                            name=name,
                            ram_mb=ram_mb,
                            age_minutes=age_min,
                            reason="[SKIP] 命中每PID冷却窗口",
                            success=False,
                            decision_state=self.decision_state,
                            protection_tier=TIER_RECLAIMABLE,
                            simulated=True,
                        )
                    )
                    continue
                proc.cpu_percent(interval=None)
                children = proc.children(recursive=False)
                try:
                    cmdline_items = proc.cmdline()
                    cmdline = " ".join(cmdline_items[:4]) if cmdline_items else ""
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    cmdline = ""
                candidates[pid] = {
                    "proc": proc,
                    "name": name,
                    "exe_path": exe_path,
                    "create_time": create_time,
                    "ram_mb": ram_mb,
                    "age_min": age_min,
                    "handle_count": proc.num_handles() if hasattr(proc, "num_handles") else 0,
                    "has_children": len(children) > 0,
                    "parent_pid": proc.ppid(),
                    "cmdline": cmdline,
                }
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

        if not candidates:
            return [], scanned, skipped_actions
        time.sleep(self.cpu_sample_interval)

        zombies: List[ZombieCandidate] = []
        for pid, info in candidates.items():
            try:
                proc = info["proc"]
                cpu_pct = proc.cpu_percent(interval=None)
                if cpu_pct <= self.idle_cpu_threshold_pct and not info["has_children"]:
                    if self.decision_state == DECISION_ENFORCE:
                        lname = (info["name"] or "").lower()
                        if lname not in self.enforce_whitelist_names:
                            skipped_actions.append(
                                ReclaimAction(
                                    timestamp=time.time(),
                                    pid=pid,
                                    name=info["name"],
                                    ram_mb=info["ram_mb"],
                                    age_minutes=info["age_min"],
                                    reason="[SKIP] enforce 白名单未命中",
                                    success=False,
                                    decision_state=self.decision_state,
                                    protection_tier=TIER_RECLAIMABLE,
                                    simulated=True,
                                )
                            )
                            continue
                    zombies.append(
                        ZombieCandidate(
                            pid=pid,
                            name=info["name"],
                            exe_path=info["exe_path"],
                            create_time=info["create_time"],
                            ram_mb=info["ram_mb"],
                            cpu_pct_sample1=0.0,
                            cpu_pct_sample2=cpu_pct,
                            age_minutes=info["age_min"],
                            handle_count=info["handle_count"],
                            has_children=info["has_children"],
                            parent_pid=info["parent_pid"],
                            cmdline=info["cmdline"],
                        )
                    )
                else:
                    reason = "[SKIP] 进程仍活跃"
                    if info["has_children"]:
                        reason = "[SKIP] 进程有子进程"
                    skipped_actions.append(
                        ReclaimAction(
                            timestamp=time.time(),
                            pid=pid,
                            name=info["name"],
                            ram_mb=info["ram_mb"],
                            age_minutes=info["age_min"],
                            reason=reason,
                            success=False,
                            decision_state=self.decision_state,
                            protection_tier=TIER_RECLAIMABLE,
                            simulated=True,
                        )
                    )
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
        return zombies, scanned, skipped_actions

    def kill_zombie(self, zombie: ZombieCandidate) -> ReclaimAction:
        action = ReclaimAction(
            timestamp=time.time(),
            pid=zombie.pid,
            name=zombie.name,
            ram_mb=zombie.ram_mb,
            age_minutes=zombie.age_minutes,
            reason=(
                f"空闲高内存进程: CPU={zombie.cpu_pct_sample2:.1f}%, "
                f"年龄={zombie.age_minutes:.0f}min, RAM={zombie.ram_mb:.1f}MB"
            ),
            success=False,
            decision_state=self.decision_state,
            protection_tier=TIER_RECLAIMABLE,
        )

        if self.decision_state in {DECISION_OBSERVE, DECISION_WARN}:
            action.simulated = True
            action.reason = f"[{decision_state_label(self.decision_state)}] 仅观察，不执行终止"
            return action
        if self.decision_state == DECISION_DRY_RUN:
            action.success = True
            action.simulated = True
            action.reason = "[DRY RUN] " + action.reason
            self._mark_pid_cooldown(zombie.pid, zombie.create_time)
            return action

        try:
            proc = psutil.Process(zombie.pid)
            current_name = (proc.name() or "").lower()
            if current_name != (zombie.name or "").lower():
                action.error = f"PID {zombie.pid} 名称变化: {zombie.name} -> {current_name}，跳过"
                self.logger.warning(f"[SKIP] {action.error}")
                self._mark_pid_cooldown(zombie.pid, zombie.create_time)
                return action
            proc.terminate()
            try:
                proc.wait(timeout=3)
                action.success = True
                self.logger.info(f"[RECLAIM] PID={zombie.pid} {zombie.name} freed={zombie.ram_mb:.1f}MB")
            except psutil.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=2)
                action.success = True
                self.logger.info(f"[RECLAIM] PID={zombie.pid} {zombie.name} forced freed={zombie.ram_mb:.1f}MB")
        except psutil.NoSuchProcess:
            action.success = True
            action.reason += " (进程已自行退出)"
        except psutil.AccessDenied:
            action.error = f"PID {zombie.pid} 权限不足，无法终止"
            self.logger.warning(f"[SKIP] {action.error}")
        except Exception as e:
            action.error = f"终止 PID {zombie.pid} 异常: {e}"
            self.logger.error(action.error)

        self._mark_pid_cooldown(zombie.pid, zombie.create_time)
        if action.success and not action.simulated:
            self._record_global_kill()
        return action

    def reclaim_manual_process(self, pid: int, name_hint: str = "") -> ReclaimAction:
        """手动确认后回收指定进程（受保护规则仍生效）。"""
        action = ReclaimAction(
            timestamp=time.time(),
            pid=pid,
            name=name_hint,
            ram_mb=0.0,
            age_minutes=0.0,
            reason="[MANUAL] 用户确认回收",
            success=False,
            decision_state=self.decision_state,
            protection_tier=TIER_RECLAIMABLE,
        )

        try:
            proc = psutil.Process(pid)
            name = (proc.name() or "").lower()
            if name_hint and name != name_hint.lower():
                action.error = f"目标进程已变化: {name_hint} -> {name}"
                return action

            mem = proc.memory_info()
            ram_mb = mem.rss / 1048576
            create_time = proc.create_time()
            age_min = max(0.0, (time.time() - create_time) / 60.0)
            exe_path = ""
            try:
                exe_path = proc.exe()
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                exe_path = ""

            protected = self.find_protected_pids()
            tier = self._classify_tier(pid, name, exe_path, protected)
            if tier != TIER_RECLAIMABLE:
                action.name = name
                action.ram_mb = ram_mb
                action.age_minutes = age_min
                action.protection_tier = tier
                action.reason = f"[SKIP] 手动回收被保护规则阻止: tier={tier}"
                action.simulated = True
                self._remember_skip(action)
                return action

            action.name = name
            action.ram_mb = ram_mb
            action.age_minutes = age_min

            proc.terminate()
            try:
                proc.wait(timeout=3)
                action.success = True
            except psutil.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=2)
                action.success = True

            self._mark_pid_cooldown(pid, create_time)
            if action.success:
                self._record_global_kill()
                self._append_history(action)
            else:
                self._remember_skip(action)
            return action

        except psutil.NoSuchProcess:
            action.success = True
            action.reason += " (进程已退出)"
            self._append_history(action)
            return action
        except psutil.AccessDenied:
            action.error = "权限不足，无法回收该进程"
            self._remember_skip(action)
            return action
        except Exception as e:
            action.error = f"手动回收异常: {e}"
            self._remember_skip(action)
            return action

    def reclaim(self) -> Optional[ReclaimResult]:
        if not self.should_run():
            return None
        self._last_reclaim_time = time.time()
        result = ReclaimResult(
            timestamp=time.time(),
            scanned=0,
            zombies_found=0,
            killed=0,
            freed_mb=0.0,
            decision_state=self.decision_state,
        )
        if self._is_system_under_pressure() and not self._is_commit_under_pressure(85.0):
            self.logger.warning(f"[SKIP] 系统内存压力过高(>={self.emergency_pause_ram_pct}%)，本轮暂停自动回收")
            return result
        if self._is_commit_under_pressure(85.0):
            self.logger.info("[COMMIT] 已提交内存压力高，本轮使用 VMS 筛选加速回收")
        try:
            protected = self.find_protected_pids()
            result.protected_pids = protected
            zombies, scanned, skipped_actions = self.scan_zombies(protected)
            result.scanned = scanned
            result.zombies_found = len(zombies)
            result.skipped = len(skipped_actions)
            if skipped_actions:
                for skip_action in skipped_actions[-5:]:
                    self._remember_skip(skip_action)
            if not zombies:
                return result

            cycle_kills = 0
            for zombie in zombies:
                if cycle_kills >= self.max_kills_per_cycle:
                    break
                if self.decision_state == DECISION_ENFORCE and not self._allow_global_kill():
                    self.logger.warning("[SKIP] 达到每分钟回收上限，暂停本轮后续终止")
                    break
                action = self.kill_zombie(zombie)
                result.actions.append(action)
                self._append_history(action)
                if action.success and not action.simulated:
                    cycle_kills += 1
                    result.killed += 1
                    result.freed_mb += zombie.ram_mb
        except Exception as e:
            self.logger.error(f"回收周期异常: {e}")
        return result

    @property
    def total_freed_mb(self) -> float:
        return sum(a.ram_mb for a in self._kill_history if a.success and not a.simulated)

    @property
    def total_killed(self) -> int:
        return sum(1 for a in self._kill_history if a.success and not a.simulated)

    @property
    def recent_actions(self) -> List[ReclaimAction]:
        return self._kill_history[-20:]

    @property
    def recent_skip_reasons(self) -> List[str]:
        return list(self._recent_skip_reasons)
