# OpenCode MemGuard

🛡️ OpenCode 内存泄漏监控与僵尸进程回收工具。

360 风格桌面悬浮球 + 系统托盘，实时监控 Node.js 进程内存，自动回收僵尸进程。

## 功能

- **360 式悬浮球**：实时显示 RAM 使用率，拖拽、边缘吸附、悬停展开详情
- **系统托盘**：右键菜单控制自动回收、开机自启、查看日志
- **内存泄漏检测**：滑动窗口线性回归，自动识别内存增长趋势
- **僵尸进程回收**：自动检测并终止空闲 node.exe，释放内存
- **实时日志查看器**：深色主题窗口，实时滚动显示监控日志
- **开机自启**：Windows 注册表自启动管理

## 系统要求

- Windows 10/11
- Python >= 3.10

## 安装

```bash
pip install opencode-mem-guard
```

## 使用

```bash
# 标准模式：悬浮球 + 托盘
opencode-mem-guard

# 后台运行（无控制台窗口，关终端不退出）
pythonw -m opencode_mem_guard

# 仅托盘模式
opencode-mem-guard --no-ball

# 试运行（不杀进程）
opencode-mem-guard --dry-run
```

## 参数

| 参数 | 说明 |
|------|------|
| `--no-ball` | 不显示悬浮球 |
| `--no-tray` | 不显示托盘图标 |
| `--no-reclaim` | 禁用自动回收 |
| `--dry-run` | 试运行模式 |
| `-i, --interval` | 采集间隔秒数，默认 5 |
| `--data-dir` | 数据目录，默认 `~/.opencode-mem-guard/data/` |

## License

MIT
