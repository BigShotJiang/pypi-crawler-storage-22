# Memory Watchdog Research: 12 Mature Cross-Platform Projects

## Executive Summary

**12 Projects Identified** across 4 tiers with concrete GitHub permalinks and reusable patterns for Windows Python app integration.

**Key Finding**: Combine PSUTIL (metrics) + SUPERVISOR (restart logic) + WATCHDOG (event pattern) for optimal Windows compatibility.

---

## TIER 1: DIRECT PYTHON INTEGRATION (Use These)

### 1. PSUTIL - Foundation Layer
- **GitHub**: https://github.com/giampaolo/psutil
- **Stars**: 11,078 | **License**: BSD-3-Clause
- **Windows**: ✓ Full Support
- **Key Code**: https://github.com/giampaolo/psutil/blob/master/psutil/_pswindows.py
- **Pattern**: `process.memory_info().rss`, `virtual_memory().percent`
- **Maturity**: Production-ready (12+ years)

### 2. SUPERVISOR - Restart Policy Framework
- **GitHub**: https://github.com/Supervisor/supervisor
- **Stars**: 8,997 | **License**: Other
- **Windows**: ✓ Full Support
- **Key Code**: https://github.com/Supervisor/supervisor/blob/master/supervisor/options.py
- **Pattern**: RestartPolicy state machine, INI config parsing
- **Maturity**: Production-ready (15+ years)

### 3. PEBBLE - Process Pool Management
- **GitHub**: https://github.com/noxdafox/pebble
- **Stars**: 643 | **License**: LGPLv3
- **Windows**: ✓ Full Support
- **Key Code**: https://github.com/noxdafox/pebble/blob/master/pebble/pool/process_pool.py
- **Pattern**: Worker lifecycle, timeout-based termination
- **Maturity**: Stable (8+ years)

### 4. WATCHDOG - Event-Driven Architecture
- **GitHub**: https://github.com/gorakhargosh/watchdog
- **Stars**: 7,250 | **License**: Apache-2.0
- **Windows**: ✓ Full Support
- **Key Code**: https://github.com/gorakhargosh/watchdog/blob/master/src/watchdog/observers/api.py
- **Pattern**: Observer/Handler pattern, event callbacks
- **Maturity**: Production-ready (15+ years)

