"""允许 python -m opencode_mem_guard 启动"""
from opencode_mem_guard.app import main

if __name__ == "__main__":
    main()
