"""
OpenCode MemGuard 主应用编排器

职责：
- 启动监控线程（collector + leak_detector + reclaimer 循环）
- 启动 360 式悬浮球（主线程 Win32 Layered Window）
- 启动系统托盘（后台线程 pystray）
- 线程安全的共享状态
"""
import argparse
import sys
import time
import threading
import logging
import subprocess
from pathlib import Path
from typing import Callable, Optional, List, Dict

from .collector import collect_snapshot, MemSnapshot
from .leak_detector import LeakDetector, LeakAlert
from .reclaimer import ProcessReclaimer, ReclaimResult
from .datastore import DataStore
from .autostart import is_autostart_enabled, enable_autostart, disable_autostart
from .config import (
    GovernanceConfig,
    load_governance_config,
    save_default_config_if_missing,
    save_governance_config,
)
from .state_labels import decision_state_label


# ─── 共享状态 ───────────────────────────────────────────────

class SharedState:
    """线程安全的共享监控状态"""

    def __init__(self):
        self._lock = threading.Lock()
        self._data = {
            "ram_pct": 0.0,
            "ram_used_gb": 0.0,
            "ram_total_gb": 0.0,
            "commit_pct": 0.0,
            "commit_used_gb": 0.0,
            "commit_total_gb": 0.0,
            "node_count": 0,
            "node_ram_mb": 0.0,
            "node_handles": 0,
            "all_process_count": 0,
            "high_mem_count": 0,
            "high_mem_processes": [],
            "high_mem_apps": [],
            "total_killed": 0,
            "total_freed_mb": 0.0,
            "auto_reclaim": True,
            "status": "normal",
            "decision_state": "enforce",
            "enforce_armed": False,
            "uptime_min": 0.0,
            "alerts": [],
            "recent_skips": [],
            # opencode-cli.exe 监控
            "oc_found": False,
            "oc_pid": 0,
            "oc_ram_gb": 0.0,
            "oc_child_count": 0,
            "oc_node_children": 0,
            "oc_uptime_min": 0.0,
        }
        self._start_time = time.time()

    def update_from_snapshot(self, snap: MemSnapshot):
        with self._lock:
            if snap.system:
                self._data["ram_pct"] = snap.system.usage_pct
                self._data["ram_used_gb"] = snap.system.used_ram_gb
                self._data["ram_total_gb"] = snap.system.total_ram_gb
                self._data["commit_pct"] = snap.system.commit_pct
                self._data["commit_used_gb"] = snap.system.commit_used_gb
                self._data["commit_total_gb"] = snap.system.commit_total_gb
            self._data["node_count"] = snap.node_process_count
            self._data["node_ram_mb"] = snap.node_total_ram_mb
            self._data["node_handles"] = snap.node_total_handles
            self._data["all_process_count"] = snap.all_process_count
            self._data["high_mem_count"] = len(snap.high_mem_processes)
            self._data["high_mem_processes"] = [
                {
                    "pid": p.pid,
                    "name": p.name,
                    "ram_mb": round(p.ram_mb, 1),
                    "private_mb": round(getattr(p, "private_mb", p.ram_mb), 1),
                }
                for p in snap.high_mem_processes[:8]
            ]
            app_groups: Dict[str, dict] = {}
            for p in snap.high_mem_processes:
                key = (p.name or "").strip().lower()
                if not key:
                    key = f"pid-{p.pid}"
                private_mb = round(getattr(p, "private_mb", p.ram_mb), 1)
                group = app_groups.get(key)
                if group is None:
                    group = {
                        "name": p.name or key,
                        "instances": 0,
                        "private_mb": 0.0,
                        "ram_mb": 0.0,
                        "pid": p.pid,
                        "max_private_mb": private_mb,
                    }
                    app_groups[key] = group

                group["instances"] += 1
                group["private_mb"] += private_mb
                group["ram_mb"] += p.ram_mb
                if private_mb >= group["max_private_mb"]:
                    group["max_private_mb"] = private_mb
                    group["pid"] = p.pid

            apps = []
            for group in app_groups.values():
                display_name = group["name"]
                if group["instances"] > 1:
                    display_name = f"{display_name} ({group['instances']})"
                apps.append(
                    {
                        "name": group["name"],
                        "display_name": display_name,
                        "instances": int(group["instances"]),
                        "private_mb": round(group["private_mb"], 1),
                        "ram_mb": round(group["ram_mb"], 1),
                        "pid": int(group["pid"]),
                    }
                )

            apps.sort(key=lambda x: (-x["private_mb"], -x["ram_mb"], x["display_name"].lower()))
            self._data["high_mem_apps"] = apps[:8]
            self._data["uptime_min"] = round((time.time() - self._start_time) / 60, 1)
            # opencode-cli.exe 信息
            if snap.opencode and snap.opencode.found:
                oc = snap.opencode
                self._data["oc_found"] = True
                self._data["oc_pid"] = oc.pid
                self._data["oc_ram_gb"] = oc.ram_gb
                self._data["oc_child_count"] = oc.child_count
                self._data["oc_node_children"] = oc.node_child_count
                self._data["oc_uptime_min"] = oc.uptime_minutes
            else:
                self._data["oc_found"] = False

    def update_alerts(self, alerts: list):
        with self._lock:
            # 确定状态等级
            status = "normal"
            for a in alerts:
                if a.level in ("critical", "emergency"):
                    status = "critical"
                    break
                elif a.level == "warning":
                    status = "warning"
            self._data["status"] = status
            self._data["alerts"] = [
                {"level": a.level, "metric": a.metric, "msg": a.message}
                for a in alerts[-5:]  # 只保留最近5条
            ]

    def update_reclaim(self, reclaimer: ProcessReclaimer):
        with self._lock:
            self._data["total_killed"] = reclaimer.total_killed
            self._data["total_freed_mb"] = round(reclaimer.total_freed_mb, 1)
            self._data["recent_skips"] = reclaimer.recent_skip_reasons[-3:]

    def set_auto_reclaim(self, enabled: bool):
        with self._lock:
            self._data["auto_reclaim"] = enabled

    def set_decision_state(self, state: str):
        with self._lock:
            self._data["decision_state"] = state

    def set_enforce_armed(self, armed: bool):
        with self._lock:
            self._data["enforce_armed"] = armed

    def get_decision_state(self) -> str:
        with self._lock:
            return str(self._data["decision_state"])

    def get_auto_reclaim(self) -> bool:
        with self._lock:
            return self._data["auto_reclaim"]

    def get_status_dict(self) -> dict:
        with self._lock:
            return dict(self._data)

    def get_tray_status(self) -> str:
        with self._lock:
            return self._data["status"]

    def get_tray_tooltip(self) -> str:
        with self._lock:
            d = self._data
            return (
                f"MemGuard - RAM: {d['ram_pct']}% | "
                f"全进程: {d['all_process_count']} | "
                f"高内存: {d['high_mem_count']} | "
                f"模式: {decision_state_label(d['decision_state'])}"
                + (" (待确认)" if d.get("enforce_armed") else "")
            )


# ─── 监控线程 ───────────────────────────────────────────────

class MonitorThread(threading.Thread):
    """后台监控线程"""

    def __init__(
        self,
        state: SharedState,
        governance: GovernanceConfig,
        policy_file: str = "",
        interval: float = 5.0,
        no_reclaim: bool = False,
        data_dir: str = "",
        on_reclaim_done: Optional[Callable] = None,
        on_alert_notify: Optional[Callable[[str, str], None]] = None,
    ):
        super().__init__(daemon=True, name="monitor-loop")
        self.state = state
        self.governance = governance
        self.policy_file = policy_file
        self.interval = interval
        self.no_reclaim = no_reclaim
        self._stop_event = threading.Event()
        self._on_reclaim_done = on_reclaim_done
        self._on_alert_notify = on_alert_notify
        self._reclaim_running = False
        self._reclaim_lock = threading.Lock()
        self._last_full_scan_ts = 0.0
        self._full_scan_interval_sec = max(45.0, interval * 6)
        self._cached_all_process_count = 0
        self._cached_high_mem = []
        self._cached_high_mem_total_mb = 0.0
        self._cached_node_handles = 0
        self._cached_node_threads = 0
        self._observed_apps: Dict[str, float] = {}
        self._policy_path = Path(self.policy_file) if self.policy_file else Path.home() / ".opencode-mem-guard" / "policy.json"
        self._policy_mtime = self._get_policy_mtime()
        self._last_alert_notify_ts = 0.0
        self._last_alert_signature = ""

        # 数据目录
        if not data_dir:
            data_dir = str(Path.home() / ".opencode-mem-guard" / "data")
        self.store = DataStore(data_dir=data_dir)
        self.detector = LeakDetector()
        self.reclaimer = ProcessReclaimer(
            min_age_minutes=governance.min_age_minutes,
            cpu_sample_interval=governance.cpu_sample_interval,
            idle_cpu_threshold_pct=governance.idle_cpu_threshold_pct,
            min_reclaim_ram_mb=governance.min_reclaim_ram_mb,
            decision_state=governance.decision_state,
            cooldown_minutes=governance.cycle_cooldown_minutes,
            per_pid_cooldown_minutes=governance.per_pid_cooldown_minutes,
            max_kills_per_cycle=governance.max_kills_per_cycle,
            max_kills_per_minute=governance.max_kills_per_minute,
            emergency_pause_ram_pct=governance.emergency_pause_ram_pct,
            enforce_require_double_confirm=governance.enforce_require_double_confirm,
            enforce_confirm_window_seconds=governance.enforce_confirm_window_seconds,
            enforce_whitelist_names=governance.enforce_whitelist_names,
            protected_names=governance.protected_names,
            protected_path_keywords=governance.protected_path_keywords,
            critical_process_names=governance.critical_process_names,
            logger=self.store.logger,
        )
        self.state.set_decision_state(self.reclaimer.decision_state)
        self.store.logger.info("监控线程初始化完成")

    def run(self):
        self.store.logger.info(
            f"监控启动 interval={self.interval}s "
            f"reclaim={'off' if self.no_reclaim else 'on'}"
        )
        while not self._stop_event.is_set():
            try:
                self._tick()
            except Exception as e:
                self.store.logger.error(f"监控循环异常: {e}")
            self._stop_event.wait(self.interval)

        self.store.close()
        self.store.logger.info("监控线程已停止")

    def _tick(self):
        self._reload_policy_if_needed()

        # 1. 采集
        now = time.time()
        run_full_scan = (now - self._last_full_scan_ts) >= self._full_scan_interval_sec
        snap = collect_snapshot(
            high_mem_threshold_mb=self.governance.high_mem_threshold_mb,
            scan_all_processes=run_full_scan,
        )
        if run_full_scan:
            self._last_full_scan_ts = now
            self._cached_all_process_count = snap.all_process_count
            self._cached_high_mem = list(snap.high_mem_processes)
            self._cached_high_mem_total_mb = snap.high_mem_total_mb
            self._cached_node_handles = snap.node_total_handles
            self._cached_node_threads = snap.node_total_threads
        else:
            snap.all_process_count = self._cached_all_process_count
            snap.high_mem_processes = list(self._cached_high_mem)
            snap.high_mem_total_mb = self._cached_high_mem_total_mb
            snap.node_total_handles = self._cached_node_handles
            snap.node_total_threads = self._cached_node_threads

        self.state.update_from_snapshot(snap)
        self._update_observed_apps(snap)
        self.store.save_snapshot(snap)

        # 2. 泄漏检测
        alerts = self.detector.feed(snap)
        self.state.update_alerts(alerts)
        self.state.set_decision_state(self.reclaimer.decision_state)
        if alerts:
            self.store.save_alerts(alerts)
            self._notify_alert_if_needed(alerts)

        # 3. 回收
        if not self.no_reclaim and self.state.get_auto_reclaim():
            if self.reclaimer.should_run() and not self._reclaim_running:
                self._start_reclaim_worker(force=False)
        else:
            # 即使不回收也更新统计
            self.state.update_reclaim(self.reclaimer)

    def force_reclaim(self) -> Optional[ReclaimResult]:
        """手动触发一次回收（忽略冷却期）"""
        self._start_reclaim_worker(force=True)
        return None

    def reclaim_manual_process(self, pid: int, name_hint: str = "") -> bool:
        """按 PID 手动回收（异步执行，避免阻塞 UI 线程）。"""
        if pid <= 0:
            return False

        with self._reclaim_lock:
            if self._reclaim_running:
                return False
            self._reclaim_running = True

        def _worker():
            try:
                action = self.reclaimer.reclaim_manual_process(pid, name_hint)
                if action.success or action.error or action.simulated:
                    result = ReclaimResult(
                        timestamp=time.time(),
                        scanned=1,
                        zombies_found=1 if not action.simulated else 0,
                        killed=1 if action.success and not action.simulated else 0,
                        freed_mb=action.ram_mb if action.success and not action.simulated else 0.0,
                        decision_state=self.reclaimer.decision_state,
                        actions=[action],
                        skipped=0 if action.success else 1,
                    )
                    self.store.save_reclaim(result)

                self.state.update_reclaim(self.reclaimer)

                if action.success and not action.simulated and self._on_reclaim_done:
                    self._on_reclaim_done(action.ram_mb, 1)
                elif not action.success:
                    detail = action.error or action.reason
                    self.store.logger.warning(
                        f"手动回收未执行 PID={pid} name={name_hint or action.name}: {detail}"
                    )
            except Exception as e:
                self.store.logger.error(f"手动回收线程异常: {e}")
            finally:
                with self._reclaim_lock:
                    self._reclaim_running = False

        threading.Thread(
            target=_worker,
            daemon=True,
            name=f"manual-reclaim-{pid}",
        ).start()
        return True

    def _start_reclaim_worker(self, force: bool) -> None:
        with self._reclaim_lock:
            if self._reclaim_running:
                return
            self._reclaim_running = True

        def _worker():
            try:
                if force:
                    self.reclaimer._last_reclaim_time = 0
                result = self.reclaimer.reclaim()
                if result and result.actions:
                    self.store.save_reclaim(result)
                    self.state.update_reclaim(self.reclaimer)
                    if self._on_reclaim_done:
                        self._on_reclaim_done(result.freed_mb, result.killed)
            except Exception as e:
                self.store.logger.error(f"回收线程异常: {e}")
            finally:
                with self._reclaim_lock:
                    self._reclaim_running = False

        threading.Thread(
            target=_worker,
            daemon=True,
            name="reclaim-worker",
        ).start()

    def _update_observed_apps(self, snap: MemSnapshot) -> None:
        candidates = []
        for p in snap.high_mem_processes:
            candidates.append((p.name.lower(), max(p.ram_mb, getattr(p, "private_mb", 0.0))))
        for p in snap.node_processes:
            candidates.append((p.name.lower(), max(p.ram_mb, getattr(p, "private_mb", 0.0))))
        if snap.opencode and snap.opencode.found:
            candidates.append(("opencode-cli.exe", snap.opencode.ram_mb))

        for name, ram_mb in candidates:
            if not name:
                continue
            prev = self._observed_apps.get(name, 0.0)
            if ram_mb > prev:
                self._observed_apps[name] = ram_mb

        # 控制列表规模，保留前50个
        if len(self._observed_apps) > 50:
            top = sorted(self._observed_apps.items(), key=lambda x: x[1], reverse=True)[:50]
            self._observed_apps = dict(top)

    def _notify_alert_if_needed(self, alerts: List[LeakAlert]) -> None:
        if not self._on_alert_notify or not alerts:
            return

        level_rank = {"warning": 1, "critical": 2, "emergency": 3}
        top = max(alerts, key=lambda a: level_rank.get(a.level, 0))

        now = time.time()
        cooldown = 120.0 if top.level == "warning" else 45.0
        signature = f"{top.level}:{top.metric}:{top.message}"
        if signature == self._last_alert_signature and (now - self._last_alert_notify_ts) < cooldown:
            return
        if (now - self._last_alert_notify_ts) < cooldown:
            return

        title = {
            "warning": "MemGuard 预警",
            "critical": "MemGuard 严重预警",
            "emergency": "MemGuard 紧急预警",
        }.get(top.level, "MemGuard 预警")

        try:
            self._on_alert_notify(title, top.message)
            self._last_alert_signature = signature
            self._last_alert_notify_ts = now
        except Exception as e:
            self.store.logger.warning(f"弹出预警失败: {e}")

    def _get_policy_mtime(self) -> float:
        try:
            return self._policy_path.stat().st_mtime
        except Exception:
            return 0.0

    def _reload_policy_if_needed(self) -> None:
        cur_mtime = self._get_policy_mtime()
        if cur_mtime <= 0 or cur_mtime == self._policy_mtime:
            return

        self._policy_mtime = cur_mtime
        try:
            cfg = load_governance_config(str(self._policy_path))
            self.governance.enforce_whitelist_names = list(cfg.enforce_whitelist_names)
            self.governance.protected_names = list(cfg.protected_names)
            self.governance.normalize()
            self.reclaimer.set_policy_lists(
                enforce_whitelist_names=self.governance.enforce_whitelist_names,
                protected_names=self.governance.protected_names,
            )
            self.store.logger.info("策略文件变更已加载")
        except Exception as e:
            self.store.logger.warning(f"策略文件热加载失败: {e}")

    def get_app_policy_entries(self) -> List[dict]:
        names = set(self._observed_apps.keys())
        names.update(self.governance.enforce_whitelist_names)
        names.update(self.governance.protected_names)
        entries = []
        for name in names:
            in_white = name in self.governance.enforce_whitelist_names
            in_black = name in self.governance.protected_names
            auto_cleanup = in_white and not in_black
            entries.append(
                {
                    "name": name,
                    "ram_mb": round(self._observed_apps.get(name, 0.0), 1),
                    "auto_cleanup": auto_cleanup,
                    "in_whitelist": in_white,
                    "in_blacklist": in_black,
                }
            )
        entries.sort(key=lambda x: (-x["ram_mb"], x["name"]))
        return entries[:18]

    def toggle_app_auto_cleanup(self, app_name: str) -> bool:
        name = (app_name or "").lower().strip()
        if not name:
            return False

        in_white = name in self.governance.enforce_whitelist_names
        in_black = name in self.governance.protected_names
        enabled = in_white and not in_black

        if enabled:
            self.governance.enforce_whitelist_names = [x for x in self.governance.enforce_whitelist_names if x != name]
            if name not in self.governance.protected_names:
                self.governance.protected_names.append(name)
            new_enabled = False
        else:
            if name not in self.governance.enforce_whitelist_names:
                self.governance.enforce_whitelist_names.append(name)
            self.governance.protected_names = [x for x in self.governance.protected_names if x != name]
            new_enabled = True

        self.governance.normalize()
        self.reclaimer.set_policy_lists(
            enforce_whitelist_names=self.governance.enforce_whitelist_names,
            protected_names=self.governance.protected_names,
        )
        save_governance_config(self.governance, self.policy_file)
        self._policy_mtime = self._get_policy_mtime()

        status_text = "启用自动清理" if new_enabled else "禁用自动清理"
        self.store.logger.info(f"应用策略更新: {name} -> {status_text}")
        return new_enabled

    def open_policy_file(self) -> None:
        target = save_governance_config(self.governance, self.policy_file)
        self._policy_mtime = self._get_policy_mtime()
        try:
            subprocess.Popen(["notepad", str(target)])
        except Exception as e:
            self.store.logger.warning(f"打开策略文件失败: {e}")

    def open_policy_panel(self) -> None:
        target = save_governance_config(self.governance, self.policy_file)
        self._policy_mtime = self._get_policy_mtime()
        try:
            subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "opencode_mem_guard.policy_panel",
                    "--policy-file",
                    str(target),
                ],
                creationflags=0x00000008,
            )
        except Exception as e:
            self.store.logger.warning(f"打开策略面板失败，回退到策略文件: {e}")
            self.open_policy_file()

    def set_decision_state(self, state: str):
        state = (state or "").lower()
        prev = self.reclaimer.decision_state
        if state == "enforce":
            if not self.reclaimer.can_enter_enforce():
                self.state.set_enforce_armed(False)
                self.state.set_decision_state(self.reclaimer.decision_state)
                self.store.logger.warning(
                    "治理模式切换失败: 自动回收未满足安全闸门（白名单/二次确认）"
                )
                return
        self.reclaimer.set_decision_state(state)
        self.state.set_decision_state(self.reclaimer.decision_state)
        if self.reclaimer.decision_state != prev:
            self.store.logger.info(
                f"治理模式切换: {decision_state_label(prev)} -> "
                f"{decision_state_label(self.reclaimer.decision_state)}"
            )
        if self.reclaimer.decision_state == "enforce":
            self.state.set_enforce_armed(False)
        else:
            self.state.set_enforce_armed(False)

    def cycle_decision_state(self) -> str:
        order = ["observe", "warn", "enforce"]
        current = self.reclaimer.decision_state
        try:
            idx = order.index(current)
        except ValueError:
            idx = 1

        # 循环切换时如果自动回收被安全闸门拦截，自动跳过，避免“点了没反应”
        for step in range(1, len(order) + 1):
            next_state = order[(idx + step) % len(order)]
            if next_state == "enforce" and not self.reclaimer.can_enter_enforce_silent():
                continue
            self.set_decision_state(next_state)
            return next_state

        # 理论兜底：保持当前状态
        return current

    def confirm_enforce(self) -> bool:
        self.reclaimer.arm_enforce()
        self.reclaimer.set_decision_state("enforce")
        ok = self.reclaimer.decision_state == "enforce"
        self.state.set_decision_state(self.reclaimer.decision_state)
        self.state.set_enforce_armed(not ok)
        if ok:
            self.store.logger.warning("[GUARD] 自动回收已生效（通过二次确认 + 白名单限制）")
        else:
            self.store.logger.warning("[GUARD] 自动回收未生效，请检查白名单或确认窗口")
        return ok

    def stop(self):
        self._stop_event.set()


# ─── 主入口 ─────────────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser(
        prog="opencode-mem-guard",
        description="OpenCode 内存泄漏监控与僵尸进程回收",
    )
    parser.add_argument(
        "--no-reclaim", action="store_true",
        help="禁用自动回收",
    )
    parser.add_argument(
        "--no-tray", action="store_true",
        help="不显示托盘图标（headless 模式）",
    )
    parser.add_argument(
        "--no-ball", action="store_true",
        help="不显示悬浮球（仅托盘模式）",
    )
    parser.add_argument(
        "-i", "--interval", type=float, default=8.0,
        help="采集间隔（秒），默认 8",
    )
    parser.add_argument(
        "--data-dir", type=str, default="",
        help="数据存储目录，默认 ~/.opencode-mem-guard/data/",
    )
    parser.add_argument(
        "--policy-file", type=str, default="",
        help="治理策略文件（JSON），默认 ~/.opencode-mem-guard/policy.json",
    )
    parser.add_argument(
        "--decision-state",
        choices=["observe", "warn", "enforce"],
        default="",
        help="运行态决策模式覆盖策略文件",
    )
    args = parser.parse_args()

    save_default_config_if_missing(args.policy_file)
    governance = load_governance_config(args.policy_file)
    if args.decision_state:
        governance.decision_state = args.decision_state
        governance.normalize()

    # 共享状态
    state = SharedState()
    state.set_auto_reclaim(not args.no_reclaim)

    # ── 回调函数（需要在 monitor 之前定义） ──

    ball = None  # 浮球引用，后面赋值
    tray = None

    def on_reclaim_done(freed_mb, killed):
        """回收完成回调 → 触发悬浮球动画"""
        if ball:
            ball.trigger_reclaim_animation(freed_mb, killed)

    def on_alert_notify(title: str, message: str):
        if tray:
            tray.notify(title, message)

    # 启动监控线程
    monitor = MonitorThread(
        state=state,
        governance=governance,
        policy_file=args.policy_file,
        interval=args.interval,
        no_reclaim=args.no_reclaim,
        data_dir=args.data_dir,
        on_reclaim_done=on_reclaim_done,
        on_alert_notify=on_alert_notify,
    )
    monitor.start()

    if args.no_tray and args.no_ball:
        # headless 模式：直接等待
        print("OpenCode MemGuard 已启动（headless 模式）")
        print(f"数据目录: {monitor.store.data_dir}")
        print("按 Ctrl+C 退出")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n正在停止...")
            monitor.stop()
            monitor.join(timeout=5)
        return

    # ── 回调函数 ──

    def on_quit():
        monitor.stop()
        if ball:
            ball.stop()

    def on_toggle_reclaim():
        state.set_auto_reclaim(not state.get_auto_reclaim())

    def on_cycle_decision_state():
        monitor.cycle_decision_state()

    def on_set_decision_state(mode: str):
        if mode == "enforce":
            monitor.confirm_enforce()
        else:
            monitor.set_decision_state(mode)

    def on_toggle_app_policy(app_name: str):
        monitor.toggle_app_auto_cleanup(app_name)

    def on_open_policy_panel():
        monitor.open_policy_panel()

    def on_force_reclaim():
        def _run_force_reclaim():
            try:
                monitor.force_reclaim()
            except Exception as e:
                monitor.store.logger.error(f"手动回收执行失败: {e}")

        threading.Thread(
            target=_run_force_reclaim,
            daemon=True,
            name="manual-reclaim",
        ).start()

    def on_manual_reclaim_process(pid: int, name: str) -> bool:
        ok = monitor.reclaim_manual_process(pid, name)
        if not ok:
            monitor.store.logger.warning("手动回收已在执行中，忽略重复请求")
        return ok

    def on_toggle_autostart():
        if is_autostart_enabled():
            disable_autostart()
        else:
            enable_autostart()

    # ── 启动托盘（后台线程） ──

    if not args.no_tray:
        from .tray import TrayManager

        def on_toggle_ball():
            if ball:
                ball.toggle_visibility()

        tray = TrayManager(
            on_toggle_ball=on_toggle_ball,
            on_toggle_reclaim=on_toggle_reclaim,
            on_force_reclaim=on_force_reclaim,
            on_cycle_decision_state=on_cycle_decision_state,
            on_set_decision_state=on_set_decision_state,
            on_toggle_app_policy=on_toggle_app_policy,
            on_open_policy_panel=on_open_policy_panel,
            on_toggle_autostart=on_toggle_autostart,
            on_quit=on_quit,
            get_reclaim_state=lambda: state.get_auto_reclaim(),
            get_decision_state=lambda: state.get_decision_state(),
            get_app_policy_entries=lambda: monitor.get_app_policy_entries(),
            get_autostart_state=is_autostart_enabled,
            get_ball_visible=lambda: ball._visible if ball else True,
            data_dir=str(monitor.store.data_dir),
        )

        # 托盘状态更新线程
        def _update_tray():
            while monitor.is_alive():
                try:
                    tray.update_status(
                        state.get_tray_status(),
                        state.get_tray_tooltip(),
                    )
                except Exception:
                    pass
                time.sleep(3)

        tray_thread = threading.Thread(
            target=tray.run, daemon=True, name="pystray"
        )
        tray_thread.start()

        updater = threading.Thread(
            target=_update_tray, daemon=True, name="tray-updater"
        )
        updater.start()

    # ── 启动悬浮球（主线程 Win32） ──

    if not args.no_ball:
        from .floating_ball import FloatingBall

        ball = FloatingBall(
            get_data=lambda: state.get_status_dict(),
            on_force_reclaim=on_force_reclaim,
            on_toggle_reclaim=on_toggle_reclaim,
            on_cycle_decision_state=on_cycle_decision_state,
            on_manual_reclaim_process=on_manual_reclaim_process,
            on_open_policy_panel=on_open_policy_panel,
            on_quit=on_quit,
            get_reclaim_state=lambda: state.get_auto_reclaim(),
        )

        try:
            ball.run()  # 阻塞：tkinter mainloop
        except KeyboardInterrupt:
            pass
        finally:
            monitor.stop()
            monitor.join(timeout=5)
            if tray is not None:
                tray.stop()
    else:
        # 仅托盘模式，主线程等待
        print("OpenCode MemGuard 已启动（仅托盘模式）")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
        finally:
            monitor.stop()
            monitor.join(timeout=5)


if __name__ == "__main__":
    main()
