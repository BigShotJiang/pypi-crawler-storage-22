"""
Windows 开机自启动管理模块
使用注册表实现开机自启动
"""
import sys
import winreg
from pathlib import Path
from typing import Optional


REG_PATH = r"Software\Microsoft\Windows\CurrentVersion\Run"
APP_NAME = "OpenCodeMemGuard"


def get_executable_path() -> str:
    """获取当前可执行文件路径"""
    if getattr(sys, 'frozen', False):
        # 打包后的 exe
        return sys.executable
    else:
        # 开发模式：使用 pythonw -m opencode_mem_guard
        python_exe = sys.executable.replace("python.exe", "pythonw.exe")
        if not Path(python_exe).exists():
            python_exe = sys.executable
        return f'"{python_exe}" -m opencode_mem_guard'


def enable_autostart() -> bool:
    """
    启用开机自启动
    
    Returns:
        bool: 成功返回 True，失败返回 False
    """
    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            REG_PATH,
            0,
            winreg.KEY_SET_VALUE
        )
        
        exe_path = get_executable_path()
        winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, exe_path)
        winreg.CloseKey(key)
        return True
    except Exception as e:
        print(f"启用自启动失败: {e}")
        return False


def disable_autostart() -> bool:
    """
    禁用开机自启动
    
    Returns:
        bool: 成功返回 True，失败返回 False
    """
    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            REG_PATH,
            0,
            winreg.KEY_SET_VALUE
        )
        
        try:
            winreg.DeleteValue(key, APP_NAME)
        except FileNotFoundError:
            # 键不存在，视为成功
            pass
        
        winreg.CloseKey(key)
        return True
    except Exception as e:
        print(f"禁用自启动失败: {e}")
        return False


def is_autostart_enabled() -> bool:
    """
    检查是否已启用开机自启动
    
    Returns:
        bool: 已启用返回 True，未启用返回 False
    """
    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            REG_PATH,
            0,
            winreg.KEY_READ
        )
        
        try:
            value, _ = winreg.QueryValueEx(key, APP_NAME)
            winreg.CloseKey(key)
            return bool(value)
        except FileNotFoundError:
            winreg.CloseKey(key)
            return False
    except Exception:
        return False


def get_autostart_path() -> Optional[str]:
    """
    获取注册表中的自启动路径
    
    Returns:
        Optional[str]: 自启动路径，如果未设置则返回 None
    """
    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            REG_PATH,
            0,
            winreg.KEY_READ
        )
        
        try:
            value, _ = winreg.QueryValueEx(key, APP_NAME)
            winreg.CloseKey(key)
            return value
        except FileNotFoundError:
            winreg.CloseKey(key)
            return None
    except Exception:
        return None
