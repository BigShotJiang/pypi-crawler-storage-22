"""
内存数据采集模块
使用 psutil 采集 node.exe 进程内存、系统内存、句柄数等关键指标
比 PowerShell 快 100x+，不会在系统高负载时超时
"""
import ctypes
import ctypes.wintypes
import time
import psutil
from dataclasses import dataclass, field, asdict
from typing import List, Optional


# ── Windows GlobalMemoryStatusEx (真实 commit 数据) ──

class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.wintypes.DWORD),
        ("dwMemoryLoad", ctypes.wintypes.DWORD),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),   # = commit limit
        ("ullAvailPageFile", ctypes.c_ulonglong),   # = commit limit - commit charge
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


def _get_global_memory_status() -> Optional[MEMORYSTATUSEX]:
    """调用 Win32 GlobalMemoryStatusEx 获取真实 commit limit / charge。"""
    try:
        stat = MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
            return stat
    except Exception:
        pass
    return None


@dataclass
class ProcessMemInfo:
    """单个进程的内存信息"""
    pid: int
    name: str
    ram_mb: float  # WorkingSet (物理内存)
    private_mb: float  # 私有内存（尽量贴近任务管理器进程页口径）
    virtual_mb: float  # 虚拟内存
    paged_mb: float  # 分页内存
    peak_ram_mb: float  # 峰值物理内存
    handle_count: int
    thread_count: int
    cpu_seconds: float = 0.0
    cmdline: str = ""
    exe_path: str = ""
    username: str = ""
    age_minutes: float = 0.0
    cpu_percent: float = 0.0
    is_zombie: bool = False


@dataclass
class SystemMemInfo:
    """系统级内存信息"""
    total_ram_gb: float
    free_ram_gb: float
    used_ram_gb: float
    usage_pct: float
    commit_total_gb: float  # 提交总量(虚拟内存)
    commit_used_gb: float
    commit_pct: float


@dataclass
class OpenCodeInfo:
    """opencode-cli.exe 进程信息"""
    pid: int = 0
    ram_gb: float = 0.0
    ram_mb: float = 0.0
    virtual_gb: float = 0.0
    child_count: int = 0
    node_child_count: int = 0
    uptime_minutes: float = 0.0
    cpu_percent: float = 0.0
    handle_count: int = 0
    found: bool = False


@dataclass
class MemSnapshot:
    """一次完整的内存快照"""
    timestamp: float
    system: Optional[SystemMemInfo] = None
    node_processes: List[ProcessMemInfo] = field(default_factory=list)
    node_total_ram_mb: float = 0.0
    node_total_virtual_gb: float = 0.0
    node_process_count: int = 0
    node_total_handles: int = 0
    node_total_threads: int = 0
    all_process_count: int = 0
    high_mem_processes: List[ProcessMemInfo] = field(default_factory=list)
    high_mem_total_mb: float = 0.0
    opencode: Optional[OpenCodeInfo] = None
    error: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def collect_snapshot(
    high_mem_threshold_mb: float = 500.0,
    include_process_limit: int = 120,
    scan_all_processes: bool = True,
) -> MemSnapshot:
    """使用 psutil 执行一次完整的内存快照采集"""
    snap = MemSnapshot(timestamp=time.time())
    node_ram_sum_mb = 0.0
    node_virtual_sum_mb = 0.0
    node_count_fast = 0

    try:
        # ── 系统内存 ──
        vm = psutil.virtual_memory()
        swap = psutil.swap_memory()

        total_gb = vm.total / (1024 ** 3)
        free_gb = vm.available / (1024 ** 3)
        used_gb = (vm.total - vm.available) / (1024 ** 3)

        # commit: 优先用 Win32 GlobalMemoryStatusEx 获取真实值
        mem_stat = _get_global_memory_status()
        if mem_stat is not None:
            commit_limit = mem_stat.ullTotalPageFile      # commit limit (bytes)
            commit_charge = commit_limit - mem_stat.ullAvailPageFile  # commit charge
            commit_total_gb = commit_limit / (1024 ** 3)
            commit_used_gb = commit_charge / (1024 ** 3)
        else:
            # fallback: psutil 估算
            commit_total_gb = (vm.total + swap.total) / (1024 ** 3)
            commit_used_gb = (vm.total - vm.available + swap.used) / (1024 ** 3)
        commit_pct = (commit_used_gb / commit_total_gb * 100) if commit_total_gb > 0 else 0

        snap.system = SystemMemInfo(
            total_ram_gb=round(total_gb, 2),
            free_ram_gb=round(free_gb, 2),
            used_ram_gb=round(used_gb, 2),
            usage_pct=round(vm.percent, 1),
            commit_total_gb=round(commit_total_gb, 2),
            commit_used_gb=round(commit_used_gb, 2),
            commit_pct=round(commit_pct, 1),
        )
    except Exception as e:
        snap.error = f"系统内存采集失败: {e}"

    # ── 进程采集（全量 + Node + OpenCode + 高内存） ──
    try:
        now = time.time()
        proc_fields = ['pid', 'name', 'create_time', 'username']
        if scan_all_processes:
            proc_fields.append('memory_info')

        for proc in psutil.process_iter(proc_fields):
            try:
                snap.all_process_count += 1
                pid = proc.info['pid']
                name_raw = proc.info['name'] or ''
                name = name_raw.lower()
                is_node = name == 'node.exe'
                is_opencode = name == 'opencode-cli.exe'

                # 轻量模式下只关注 node/opencode；全量模式才做全进程高内存判定
                if not scan_all_processes and not is_node and not is_opencode:
                    continue

                mem = proc.info.get('memory_info') if scan_all_processes else None
                if mem is None:
                    mem = proc.memory_info()

                private_bytes = getattr(mem, 'private', 0) or getattr(mem, 'private_usage', 0)
                if private_bytes <= 0:
                    try:
                        full_mem = proc.memory_full_info()
                        private_bytes = (
                            getattr(full_mem, 'uss', 0)
                            or getattr(full_mem, 'private', 0)
                            or getattr(full_mem, 'private_usage', 0)
                        )
                    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                        private_bytes = 0
                    except Exception:
                        private_bytes = 0
                if private_bytes <= 0:
                    private_bytes = mem.rss
                age_minutes = 0.0
                create_time = proc.info.get('create_time')
                if create_time:
                    age_minutes = max(0.0, round((now - create_time) / 60.0, 1))

                ram_mb = round(mem.rss / 1048576, 1)
                is_high_mem = scan_all_processes and (ram_mb >= high_mem_threshold_mb)

                if is_node and not scan_all_processes:
                    node_count_fast += 1
                    node_ram_sum_mb += ram_mb
                    node_virtual_sum_mb += mem.vms / 1048576

                # 仅在全量扫描时采集 node/high-mem 详情；轻量扫描只保留 opencode 详情
                need_detail = is_opencode or (scan_all_processes and (is_node or is_high_mem))

                cmdline_text = ''
                exe_path = ''
                status = ''
                cpu_seconds = 0.0
                handle_count = 0
                thread_count = 0
                if need_detail:
                    try:
                        with proc.oneshot():
                            try:
                                cmdline_items = proc.cmdline()
                                cmdline_text = ' '.join(cmdline_items[:4]) if cmdline_items else ''
                            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                                cmdline_text = ''

                            try:
                                exe_path = proc.exe() if hasattr(proc, 'exe') else ''
                            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                                exe_path = ''

                            try:
                                status = proc.status()
                            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                                status = ''

                            try:
                                cpu_times = proc.cpu_times()
                                cpu_seconds = round(cpu_times.user + cpu_times.system, 2)
                            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                                cpu_seconds = 0.0

                            try:
                                handle_count = proc.num_handles() if hasattr(proc, 'num_handles') else 0
                            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                                handle_count = 0

                            try:
                                thread_count = proc.num_threads()
                            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                                thread_count = 0
                    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                        continue

                proc_info = None
                if scan_all_processes or is_opencode:
                    proc_info = ProcessMemInfo(
                        pid=pid,
                        name=name_raw,
                        ram_mb=ram_mb,
                        private_mb=round(private_bytes / 1048576, 1),
                        virtual_mb=round(mem.vms / 1048576, 1),
                        paged_mb=round(getattr(mem, 'paged_pool', 0) / 1048576, 1),
                        peak_ram_mb=round(getattr(mem, 'peak_wset', mem.rss) / 1048576, 1),
                        handle_count=handle_count,
                        thread_count=thread_count,
                        cpu_seconds=cpu_seconds,
                        cmdline=cmdline_text,
                        exe_path=exe_path,
                        username=proc.info.get('username') or '',
                        age_minutes=age_minutes,
                        cpu_percent=0.0,
                        is_zombie=(status == psutil.STATUS_ZOMBIE),
                    )

                if is_node and scan_all_processes and proc_info is not None:
                    snap.node_processes.append(proc_info)

                if is_high_mem and proc_info is not None:
                    snap.high_mem_processes.append(proc_info)

                if is_opencode and (not snap.opencode or not snap.opencode.found):
                    children = proc.children(recursive=True)
                    node_children = sum(
                        1 for c in children
                        if (c.name() or '').lower() == 'node.exe'
                    )
                    snap.opencode = OpenCodeInfo(
                        pid=pid,
                        ram_gb=round(mem.rss / (1024 ** 3), 2),
                        ram_mb=round(mem.rss / 1048576, 1),
                        virtual_gb=round(mem.vms / (1024 ** 3), 2),
                        child_count=len(children),
                        node_child_count=node_children,
                        uptime_minutes=age_minutes,
                        cpu_percent=proc.cpu_percent(interval=None),
                        handle_count=handle_count,
                        found=True,
                    )
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
    except Exception as e:
        if not snap.error:
            snap.error = f"进程采集失败: {e}"

    # 汇总
    if scan_all_processes:
        snap.node_process_count = len(snap.node_processes)
        snap.node_total_ram_mb = round(sum(p.ram_mb for p in snap.node_processes), 1)
        snap.node_total_virtual_gb = round(sum(p.virtual_mb for p in snap.node_processes) / 1024, 2)
        snap.node_total_handles = sum(p.handle_count for p in snap.node_processes)
        snap.node_total_threads = sum(p.thread_count for p in snap.node_processes)
    else:
        snap.node_process_count = node_count_fast
        snap.node_total_ram_mb = round(node_ram_sum_mb, 1)
        snap.node_total_virtual_gb = round(node_virtual_sum_mb / 1024, 2)

    # 高内存进程按内存降序，限制存储大小
    snap.high_mem_processes.sort(key=lambda p: p.ram_mb, reverse=True)
    if include_process_limit > 0:
        snap.high_mem_processes = snap.high_mem_processes[:include_process_limit]
    snap.high_mem_total_mb = round(sum(p.ram_mb for p in snap.high_mem_processes), 1)

    return snap
