"""
策略配置模块
加载全进程内存治理策略（JSON）
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import List


DEFAULT_CRITICAL_PROCESS_NAMES = [
    "system",
    "registry",
    "smss.exe",
    "csrss.exe",
    "wininit.exe",
    "winlogon.exe",
    "services.exe",
    "lsass.exe",
    "svchost.exe",
    "dwm.exe",
    "fontdrvhost.exe",
]


@dataclass
class GovernanceConfig:
    decision_state: str = "enforce"  # observe | warn | enforce
    high_mem_threshold_mb: float = 500.0
    min_age_minutes: float = 30.0
    cpu_sample_interval: float = 2.0
    idle_cpu_threshold_pct: float = 0.0
    min_reclaim_ram_mb: float = 200.0
    cycle_cooldown_minutes: float = 5.0
    per_pid_cooldown_minutes: float = 30.0
    max_kills_per_cycle: int = 3
    max_kills_per_minute: int = 6
    emergency_pause_ram_pct: float = 95.0
    enforce_require_double_confirm: bool = True
    enforce_confirm_window_seconds: int = 15
    enforce_whitelist_names: List[str] = field(default_factory=list)
    protected_names: List[str] = field(default_factory=list)
    protected_path_keywords: List[str] = field(default_factory=list)
    critical_process_names: List[str] = field(
        default_factory=lambda: list(DEFAULT_CRITICAL_PROCESS_NAMES)
    )

    def normalize(self) -> None:
        state = (self.decision_state or "enforce").lower()
        if state == "dry-run":
            state = "enforce"
        allowed = {"observe", "warn", "enforce"}
        self.decision_state = state if state in allowed else "enforce"
        self.protected_names = [x.lower() for x in self.protected_names]
        self.enforce_whitelist_names = [x.lower() for x in self.enforce_whitelist_names]
        self.protected_path_keywords = [x.lower() for x in self.protected_path_keywords]
        self.critical_process_names = [x.lower() for x in self.critical_process_names]


def default_config_path() -> Path:
    return Path.home() / ".opencode-mem-guard" / "policy.json"


def load_governance_config(path: str = "") -> GovernanceConfig:
    cfg = GovernanceConfig()
    target = Path(path) if path else default_config_path()
    if not target.exists():
        cfg.normalize()
        return cfg

    try:
        with open(target, "r", encoding="utf-8") as f:
            raw = json.load(f)
        if not isinstance(raw, dict):
            cfg.normalize()
            return cfg

        known_keys = {
            "decision_state",
            "high_mem_threshold_mb",
            "min_age_minutes",
            "cpu_sample_interval",
            "idle_cpu_threshold_pct",
            "min_reclaim_ram_mb",
            "cycle_cooldown_minutes",
            "per_pid_cooldown_minutes",
            "max_kills_per_cycle",
            "max_kills_per_minute",
            "emergency_pause_ram_pct",
            "enforce_require_double_confirm",
            "enforce_confirm_window_seconds",
            "enforce_whitelist_names",
            "protected_names",
            "protected_path_keywords",
            "critical_process_names",
        }
        for k, v in raw.items():
            if k in known_keys:
                setattr(cfg, k, v)
    except Exception:
        pass

    cfg.normalize()
    return cfg


def save_default_config_if_missing(path: str = "") -> Path:
    target = Path(path) if path else default_config_path()
    if target.exists():
        return target
    target.parent.mkdir(parents=True, exist_ok=True)
    cfg = GovernanceConfig()
    cfg.normalize()
    payload = {
        "decision_state": cfg.decision_state,
        "high_mem_threshold_mb": cfg.high_mem_threshold_mb,
        "min_age_minutes": cfg.min_age_minutes,
        "cpu_sample_interval": cfg.cpu_sample_interval,
        "idle_cpu_threshold_pct": cfg.idle_cpu_threshold_pct,
        "min_reclaim_ram_mb": cfg.min_reclaim_ram_mb,
        "cycle_cooldown_minutes": cfg.cycle_cooldown_minutes,
        "per_pid_cooldown_minutes": cfg.per_pid_cooldown_minutes,
        "max_kills_per_cycle": cfg.max_kills_per_cycle,
        "max_kills_per_minute": cfg.max_kills_per_minute,
        "emergency_pause_ram_pct": cfg.emergency_pause_ram_pct,
        "enforce_require_double_confirm": cfg.enforce_require_double_confirm,
        "enforce_confirm_window_seconds": cfg.enforce_confirm_window_seconds,
        "enforce_whitelist_names": cfg.enforce_whitelist_names,
        "protected_names": cfg.protected_names,
        "protected_path_keywords": cfg.protected_path_keywords,
        "critical_process_names": cfg.critical_process_names,
    }
    with open(target, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    return target


def save_governance_config(cfg: GovernanceConfig, path: str = "") -> Path:
    """保存当前治理配置到策略文件。"""
    target = Path(path) if path else default_config_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    cfg.normalize()
    payload = {
        "decision_state": cfg.decision_state,
        "high_mem_threshold_mb": cfg.high_mem_threshold_mb,
        "min_age_minutes": cfg.min_age_minutes,
        "cpu_sample_interval": cfg.cpu_sample_interval,
        "idle_cpu_threshold_pct": cfg.idle_cpu_threshold_pct,
        "min_reclaim_ram_mb": cfg.min_reclaim_ram_mb,
        "cycle_cooldown_minutes": cfg.cycle_cooldown_minutes,
        "per_pid_cooldown_minutes": cfg.per_pid_cooldown_minutes,
        "max_kills_per_cycle": cfg.max_kills_per_cycle,
        "max_kills_per_minute": cfg.max_kills_per_minute,
        "emergency_pause_ram_pct": cfg.emergency_pause_ram_pct,
        "enforce_require_double_confirm": cfg.enforce_require_double_confirm,
        "enforce_confirm_window_seconds": cfg.enforce_confirm_window_seconds,
        "enforce_whitelist_names": cfg.enforce_whitelist_names,
        "protected_names": cfg.protected_names,
        "protected_path_keywords": cfg.protected_path_keywords,
        "critical_process_names": cfg.critical_process_names,
    }
    with open(target, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    return target
