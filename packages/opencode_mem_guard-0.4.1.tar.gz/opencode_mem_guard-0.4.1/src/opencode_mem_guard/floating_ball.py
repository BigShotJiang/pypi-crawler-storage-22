"""
360式桌面悬浮球 v8 - Win32 Layered Window
使用 Win32 UpdateLayeredWindow + per-pixel alpha 实现真正的透明
解决 200% DPI 下 tkinter -transparentcolor 的黑边问题
"""
import ctypes
import ctypes.wintypes as wt
import math
import time
import threading
from typing import Callable, Optional, Dict, Any

from PIL import Image, ImageDraw, ImageFont

from .state_labels import decision_state_label

# ── DPI Awareness ──
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

# ── Win32 Constants ──
WS_POPUP = 0x80000000
WS_EX_LAYERED = 0x00080000
WS_EX_TOPMOST = 0x00000008
WS_EX_TOOLWINDOW = 0x00000080
ULW_ALPHA = 0x02
AC_SRC_OVER = 0x00
AC_SRC_ALPHA = 0x01
WM_DESTROY = 0x0002
WM_CLOSE = 0x0010
WM_TIMER = 0x0113
WM_LBUTTONDOWN = 0x0201
WM_LBUTTONUP = 0x0202
WM_RBUTTONUP = 0x0204
WM_MOUSEMOVE = 0x0200
WM_MOUSELEAVE = 0x02A3
CS_HREDRAW = 0x0002
CS_VREDRAW = 0x0001
IDC_ARROW = 32512
DIB_RGB_COLORS = 0
BI_RGB = 0
SW_SHOW = 5
SW_HIDE = 0
TME_LEAVE = 0x00000002
SWP_NOSIZE = 0x0001
SWP_NOZORDER = 0x0004
MF_STRING = 0x0000
MF_SEPARATOR = 0x0800
TPM_LEFTALIGN = 0x0000
TPM_RETURNCMD = 0x0100
MB_YESNO = 0x00000004
MB_ICONQUESTION = 0x00000020
MB_ICONWARNING = 0x00000030
IDYES = 6

user32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32
kernel32 = ctypes.windll.kernel32

WNDPROC = ctypes.WINFUNCTYPE(
    ctypes.c_ssize_t, wt.HWND, ctypes.c_uint, wt.WPARAM, wt.LPARAM
)

# ── Win32 Structures ──
class WNDCLASSEX(ctypes.Structure):
    _fields_ = [
        ("cbSize", ctypes.c_uint),
        ("style", ctypes.c_uint),
        ("lpfnWndProc", WNDPROC),
        ("cbClsExtra", ctypes.c_int),
        ("cbWndExtra", ctypes.c_int),
        ("hInstance", wt.HINSTANCE),
        ("hIcon", wt.HICON),
        ("hCursor", wt.HANDLE),
        ("hbrBackground", wt.HBRUSH),
        ("lpszMenuName", wt.LPCWSTR),
        ("lpszClassName", wt.LPCWSTR),
        ("hIconSm", wt.HICON),
    ]

class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize", ctypes.c_uint),
        ("biWidth", ctypes.c_int),
        ("biHeight", ctypes.c_int),
        ("biPlanes", ctypes.c_ushort),
        ("biBitCount", ctypes.c_ushort),
        ("biCompression", ctypes.c_uint),
        ("biSizeImage", ctypes.c_uint),
        ("biXPelsPerMeter", ctypes.c_int),
        ("biYPelsPerMeter", ctypes.c_int),
        ("biClrUsed", ctypes.c_uint),
        ("biClrImportant", ctypes.c_uint),
    ]

class BLENDFUNCTION(ctypes.Structure):
    _fields_ = [
        ("BlendOp", ctypes.c_byte),
        ("BlendFlags", ctypes.c_byte),
        ("SourceConstantAlpha", ctypes.c_byte),
        ("AlphaFormat", ctypes.c_byte),
    ]

class TRACKMOUSEEVENT(ctypes.Structure):
    _fields_ = [
        ("cbSize", ctypes.c_uint),
        ("dwFlags", ctypes.c_uint),
        ("hwndTrack", wt.HWND),
        ("dwHoverTime", ctypes.c_uint),
    ]

# ── Constants ──
BALL = 144
EXP_W = 480
EXP_H = 200
RS = 2  # Supersample ratio (进一步降载)

DOCK_TH = 50
DOCK_SHOW = BALL // 2

GLOW_MAX = 80
GLOW_STEP = 14
GLOW_MS = 30

TIMER_REFRESH = 1
TIMER_GLOW = 2
TIMER_EXPAND = 3
TIMER_REDOCK = 4
TIMER_SAFETY = 5
TIMER_SLIDE = 6
TIMER_RECLAIM_ANIM = 7
DRAG_THRESHOLD = 5

# 回收动画参数
ANIM_FPS = 45          # ms per frame (~22fps)
ANIM_TOTAL = 16        # 总帧数 (~0.72秒)
ANIM_PHASE1 = 4        # 漩涡启动
ANIM_PHASE2 = 11       # 吸收中
# phase3 = 22..29       # 完成闪光

# 自定义 Windows 消息
WM_APP = 0x8000
WM_RECLAIM_ANIM = WM_APP + 1

C = {
    "ok":  (72, 199, 142),  "ok2":  (56, 152, 236),
    "warn": (245, 166, 35), "warn2": (235, 87, 87),
    "crit": (235, 87, 87),  "crit2": (180, 40, 40),
    "bg":  (22, 27, 44),
    "glass": (32, 40, 64),
    "txt": (240, 245, 250), "dim": (140, 155, 170),
    "bar": (50, 58, 75),
    # 回收动画颜色
    "vortex": (120, 60, 200),   # 漩涡臂 - 深紫
    "vortex2": (80, 30, 160),   # 漩涡臂暗色
    "particle": (100, 220, 255),  # 粒子 - 青色
    "core": (200, 160, 255),    # 核心光芒
    "flash": (255, 255, 255),   # 完成闪光
    "success": (72, 230, 150),  # 成功绿
}

_STATUS_MAP = {"normal": "ok", "warning": "warn", "critical": "crit"}


# ── Helper Functions ──
def _font(sz, bold=False):
    """加载中文字体"""
    for p in [
        "C:/Windows/Fonts/msyhbd.ttc" if bold else "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/simhei.ttf",
        "C:/Windows/Fonts/segoeui.ttf",
    ]:
        try:
            return ImageFont.truetype(p, sz)
        except Exception:
            pass
    return ImageFont.load_default()

def _lerp(c1, c2, t):
    """线性插值"""
    return tuple(int(a + (b - a) * t) for a, b in zip(c1, c2))

def _ctxt(draw, cx, cy, text, font, fill):
    """居中绘制文字"""
    bb = draw.textbbox((0, 0), text, font=font)
    x = cx - (bb[2] - bb[0]) // 2 - bb[0]
    y = cy - (bb[3] - bb[1]) // 2 - bb[1]
    draw.text((x, y), text, fill=fill, font=font)

def _circle_mask(size):
    """创建圆形遮罩（超采样）"""
    big = size * RS
    m = Image.new("L", (big, big), 0)
    ImageDraw.Draw(m).ellipse([0, 0, big - 1, big - 1], fill=255)
    return m.resize((size, size), Image.Resampling.LANCZOS)

def pil_to_hbitmap(img):
    """将 RGBA PIL Image 转为 Win32 HBITMAP (premultiplied alpha)"""
    w, h = img.size
    src = img.tobytes("raw", "RGBA")
    out = bytearray(w * h * 4)

    # Premultiply + RGBA→BGRA + 垂直翻转（bottom-up DIB）
    stride = w * 4
    for y in range(h):
        si = y * stride
        di = (h - 1 - y) * stride
        for x in range(w):
            so = si + x * 4
            do = di + x * 4
            a = src[so + 3]
            if a == 0:
                pass  # out 已全零
            elif a == 255:
                out[do] = src[so + 2]      # B
                out[do + 1] = src[so + 1]  # G
                out[do + 2] = src[so]      # R
                out[do + 3] = 255
            else:
                out[do] = src[so + 2] * a // 255
                out[do + 1] = src[so + 1] * a // 255
                out[do + 2] = src[so] * a // 255
                out[do + 3] = a

    bmi = BITMAPINFOHEADER()
    bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    bmi.biWidth = w
    bmi.biHeight = h
    bmi.biPlanes = 1
    bmi.biBitCount = 32
    bmi.biCompression = BI_RGB

    bits = ctypes.c_void_p()
    hdc = user32.GetDC(0)
    hbm = gdi32.CreateDIBSection(
        hdc, ctypes.byref(bmi), DIB_RGB_COLORS,
        ctypes.byref(bits), None, 0
    )
    user32.ReleaseDC(0, hdc)

    if not hbm:
        raise RuntimeError("CreateDIBSection failed")

    ctypes.memmove(bits, bytes(out), len(out))
    return hbm

def update_layered_window(hwnd, hbm, w, h):
    """用 UpdateLayeredWindow 设置窗口内容"""
    hdc_screen = user32.GetDC(0)
    hdc_mem = gdi32.CreateCompatibleDC(hdc_screen)
    old_bm = gdi32.SelectObject(hdc_mem, hbm)

    pt_src = wt.POINT(0, 0)
    sz = wt.SIZE(w, h)
    blend = BLENDFUNCTION()
    blend.BlendOp = AC_SRC_OVER
    blend.BlendFlags = 0
    blend.SourceConstantAlpha = 255
    blend.AlphaFormat = AC_SRC_ALPHA

    user32.UpdateLayeredWindow(
        hwnd, hdc_screen, None, ctypes.byref(sz),
        hdc_mem, ctypes.byref(pt_src), 0,
        ctypes.byref(blend), ULW_ALPHA
    )

    gdi32.SelectObject(hdc_mem, old_bm)
    gdi32.DeleteDC(hdc_mem)
    user32.ReleaseDC(0, hdc_screen)


class FloatingBall:
    """360式悬浮球 - Win32 Layered Window 实现"""
    
    def __init__(
        self,
        get_data: Optional[Callable] = None,
        on_force_reclaim: Optional[Callable] = None,
        on_toggle_reclaim: Optional[Callable] = None,
        on_cycle_decision_state: Optional[Callable] = None,
        on_manual_reclaim_process: Optional[Callable[[int, str], bool]] = None,
        on_open_policy_panel: Optional[Callable] = None,
        on_quit: Optional[Callable] = None,
        get_reclaim_state: Optional[Callable] = None,
    ):
        self._get_data = get_data or (lambda: {})
        self._on_force_reclaim = on_force_reclaim or (lambda: None)
        self._on_toggle_reclaim = on_toggle_reclaim or (lambda: None)
        self._on_cycle_decision_state = on_cycle_decision_state or (lambda: None)
        self._on_manual_reclaim_process = on_manual_reclaim_process or (lambda pid, name: False)
        self._on_open_policy_panel = on_open_policy_panel or (lambda: None)
        self._on_quit = on_quit or (lambda: None)
        self._get_reclaim_state = get_reclaim_state or (lambda: True)

        self._hwnd = None
        self._hinstance = None
        self._wnd_proc_cb = None
        self._data: Dict[str, Any] = {}
        self._lock = threading.Lock()
        self._ball_mask: Optional[Image.Image] = None
        self._current_hbm = None

        self._expanded = False
        self._visible = True
        self._dragging = False
        self._drag_ox = 0
        self._drag_oy = 0
        self._drag_start_x = 0
        self._drag_start_y = 0
        self._did_drag = False

        self._glow = 0
        self._glow_target = 0

        self._docked = False
        self._dock_side = ""
        self._pre_dock_x = 0
        self._pre_dock_y = 0
        self._was_docked = False
        self._last_dock_side = ""

        self._mouse_inside = False
        self._running = False
        self._expand_right = True
        self._ignore_leave_until = 0.0  # 展开/收起后短暂忽略 mouse leave

        # 滑动动画状态
        self._slide_tx = 0
        self._slide_ty = 0
        self._slide_step = 0
        self._slide_steps = 6
        self._slide_callback = None  # 滑动完成后的回调

        # 回收动画状态
        self._anim_active = False
        self._anim_frame = 0
        self._anim_freed_mb = 0.0
        self._anim_killed = 0
        self._anim_particles = []  # [(base_angle, speed, radius_offset), ...]
        self._last_render_signature = None
        self._clickable_apps = []

    # ── Color Helpers ──
    def _colors(self):
        """根据状态返回颜色（opencode-cli 内存告警优先）"""
        # opencode-cli.exe 内存告警优先级最高
        oc_gb = self._data.get("oc_ram_gb", 0)
        if self._data.get("oc_found") and oc_gb >= 6.0:
            return C["crit"], C["crit2"]
        elif self._data.get("oc_found") and oc_gb >= 4.0:
            return C["warn"], C["warn2"]
        k = _STATUS_MAP.get(self._data.get("status", "normal"), "ok")
        return C[k], C[k + "2"]

    # ── Rendering: Ball ──
    def _render_ball(self, glow=0):
        """渲染圆球（超采样 + RGBA）"""
        S = RS
        sz = BALL * S
        img = Image.new("RGBA", (sz, sz), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        c1, c2 = self._colors()
        pct = self._data.get("ram_pct", 0)
        cx, cy = sz // 2, sz // 2

        # 背景圆
        draw.ellipse([0, 0, sz - 1, sz - 1], fill=C["bg"] + (240,))

        # 渐变圆环
        rw = 3 * S
        r = sz // 2 - rw // 2 - 1
        for i in range(120):
            a = 2 * math.pi * i / 120
            a2 = a + 2 * math.pi / 120
            c = _lerp(c1, c2, i / 120)
            draw.line([
                (cx + r * math.cos(a), cy + r * math.sin(a)),
                (cx + r * math.cos(a2), cy + r * math.sin(a2)),
            ], fill=c + (255,), width=rw)

        # 进度弧
        if pct > 0:
            ap = 8 * S
            draw.arc([ap, ap, sz - ap, sz - ap],
                     start=90 - pct * 3.6, end=90,
                     fill=c1 + (255,), width=5 * S)

        # 文字
        _ctxt(draw, cx, cy - 10 * S, f"{pct:.0f}%",
              _font(30 * S, True), c1 + (255,))
        _ctxt(draw, cx, cy + 22 * S, "RAM",
              _font(13 * S), C["dim"] + (255,))

        # 缩小到目标尺寸
        small = img.resize((BALL, BALL), Image.Resampling.LANCZOS)

        # 应用圆形遮罩
        if self._ball_mask is None:
            self._ball_mask = _circle_mask(BALL)
        
        result = Image.new("RGBA", (BALL, BALL), (0, 0, 0, 0))
        result.paste(small, (0, 0), self._ball_mask)

        # 发光效果
        if glow > 0:
            self._apply_glow(result, glow, c1, c2)

        return result

    def _apply_glow(self, img, glow, c1, c2):
        """轻量发光效果（避免逐像素循环）"""
        intensity = min(glow, GLOW_MAX) / GLOW_MAX
        if intensity <= 0:
            return

        gc = _lerp(c1, c2, 0.5)
        draw = ImageDraw.Draw(img)
        cx = BALL // 2
        cy = BALL // 2
        base_r = BALL // 2

        for i in range(3):
            r = base_r + 4 + i * 4
            alpha = int((60 - i * 14) * intensity)
            if alpha <= 0:
                continue
            draw.ellipse(
                [cx - r, cy - r, cx + r, cy + r],
                outline=gc + (alpha,),
                width=2,
            )

    # ── Rendering: Reclaim Animation ──
    def _init_particles(self, count=10):
        """初始化粒子参数（随机角度、速度、半径偏移）"""
        import random
        self._anim_particles = []
        for _ in range(count):
            base_angle = random.uniform(0, 2 * math.pi)
            speed = random.uniform(0.15, 0.35)  # 旋转速度
            r_off = random.uniform(-0.1, 0.1)   # 半径随机偏移
            size = random.uniform(0.6, 1.0)      # 粒子大小系数
            self._anim_particles.append((base_angle, speed, r_off, size))

    def _render_reclaim_frame(self, frame):
        """渲染回收动画单帧（黑洞漩涡效果）"""
        S = RS
        sz = BALL * S
        img = Image.new("RGBA", (sz, sz), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        cx, cy = sz // 2, sz // 2
        t = frame / ANIM_TOTAL  # 0..1 归一化进度

        # ── 背景圆（比正常稍暗） ──
        bg_alpha = 240 if frame < ANIM_PHASE2 else int(240 - (frame - ANIM_PHASE2) * 8)
        bg_alpha = max(180, min(240, bg_alpha))
        draw.ellipse([0, 0, sz - 1, sz - 1], fill=C["bg"] + (bg_alpha,))

        # ── Phase 1 & 2: 漩涡臂 ──
        if frame < ANIM_PHASE2 + 4:
            self._draw_vortex_arms(draw, cx, cy, sz, frame)

        # ── Phase 1 & 2: 粒子 ──
        if frame < ANIM_PHASE2 + 2:
            self._draw_particles(draw, cx, cy, sz, frame)

        # ── Phase 2: 核心光芒 ──
        if ANIM_PHASE1 <= frame < ANIM_TOTAL - 2:
            self._draw_core_glow(draw, cx, cy, sz, frame)

        # ── Phase 2: 释放文字 ──
        if ANIM_PHASE1 + 2 <= frame < ANIM_TOTAL - 4:
            self._draw_freed_text(draw, cx, cy, sz, frame)

        # ── Phase 3: 完成闪光脉冲 ──
        if frame >= ANIM_PHASE2:
            self._draw_completion_flash(draw, cx, cy, sz, frame)

        # ── 缩小 + 圆形遮罩 ──
        small = img.resize((BALL, BALL), Image.Resampling.LANCZOS)
        if self._ball_mask is None:
            self._ball_mask = _circle_mask(BALL)
        result = Image.new("RGBA", (BALL, BALL), (0, 0, 0, 0))
        result.paste(small, (0, 0), self._ball_mask)
        return result

    def _draw_vortex_arms(self, draw, cx, cy, sz, frame):
        """绘制漩涡臂（3条对数螺旋线）"""
        S = RS
        # 漩涡强度：phase1 渐入，phase2 满强度
        if frame < ANIM_PHASE1:
            intensity = frame / ANIM_PHASE1
        elif frame < ANIM_PHASE2:
            intensity = 1.0
        else:
            intensity = max(0, 1.0 - (frame - ANIM_PHASE2) / 6)

        rotation = frame * 0.25  # 整体旋转角度
        max_r = sz * 0.38
        arm_count = 3

        for arm in range(arm_count):
            arm_offset = arm * (2 * math.pi / arm_count)
            points = []
            for step in range(40):
                st = step / 40  # 0..1 沿螺旋线
                r = max_r * st
                angle = arm_offset + rotation + st * 3.5  # 对数螺旋
                x = cx + r * math.cos(angle)
                y = cy + r * math.sin(angle)
                points.append((x, y))

            # 绘制螺旋线段
            alpha = int(160 * intensity)
            width = max(1, int(3 * S * intensity))
            vc = C["vortex"]
            for i in range(len(points) - 1):
                seg_t = i / len(points)
                seg_alpha = int(alpha * (1 - seg_t * 0.6))
                if seg_alpha < 10:
                    continue
                c = _lerp(C["vortex2"], vc, seg_t)
                draw.line(
                    [points[i], points[i + 1]],
                    fill=c + (seg_alpha,),
                    width=width,
                )

    def _draw_particles(self, draw, cx, cy, sz, frame):
        """绘制被吸入的粒子"""
        S = RS
        max_r = sz * 0.4

        for base_angle, speed, r_off, p_size in self._anim_particles:
            # 粒子从外向内螺旋
            progress = min(1.0, frame / ANIM_PHASE2)
            r = max_r * (1 - progress * 0.9) * (1 + r_off)
            angle = base_angle + frame * speed
            x = cx + r * math.cos(angle)
            y = cy + r * math.sin(angle)

            # 粒子大小和透明度
            dot_r = int(3.5 * S * p_size * (1 - progress * 0.5))
            alpha = int(220 * (1 - progress * 0.3))
            if dot_r < 1 or alpha < 20:
                continue

            # 外层光晕（大、半透明）
            halo_r = dot_r * 2
            halo_alpha = alpha // 3
            draw.ellipse(
                [x - halo_r, y - halo_r, x + halo_r, y + halo_r],
                fill=C["particle"] + (halo_alpha,),
            )
            # 核心亮点
            draw.ellipse(
                [x - dot_r, y - dot_r, x + dot_r, y + dot_r],
                fill=C["particle"] + (alpha,),
            )

    def _draw_core_glow(self, draw, cx, cy, sz, frame):
        """绘制中心核心光芒"""
        S = RS
        # 核心强度脉动
        phase2_t = (frame - ANIM_PHASE1) / (ANIM_TOTAL - ANIM_PHASE1)
        pulse = 0.7 + 0.3 * math.sin(frame * 0.8)
        intensity = min(1.0, phase2_t * 2) * pulse

        # 多层光晕
        for layer in range(3):
            r = int(sz * (0.06 + layer * 0.04) * (1 + intensity * 0.3))
            alpha = int((180 - layer * 50) * intensity)
            alpha = max(0, min(255, alpha))
            c = _lerp(C["core"], C["flash"], layer * 0.3)
            draw.ellipse(
                [cx - r, cy - r, cx + r, cy + r],
                fill=c + (alpha,),
            )

    def _draw_freed_text(self, draw, cx, cy, sz, frame):
        """绘制释放内存文字"""
        S = RS
        # 文字淡入
        text_t = (frame - ANIM_PHASE1 - 2) / 6
        text_alpha = int(min(1.0, text_t) * 240)
        if text_alpha < 20:
            return

        freed = self._anim_freed_mb
        killed = self._anim_killed
        if freed >= 1024:
            text = f"-{freed / 1024:.1f}GB"
        elif freed > 0:
            text = f"-{freed:.0f}MB"
        else:
            text = f"×{killed}"

        font = _font(18 * S, bold=True)
        _ctxt(draw, cx, cy - 4 * S, text, font, C["success"] + (text_alpha,))

        # 副标题
        sub = f"回收 {killed} 进程" if killed > 0 else "扫描完成"
        sub_font = _font(10 * S)
        sub_alpha = int(text_alpha * 0.7)
        _ctxt(draw, cx, cy + 18 * S, sub, sub_font, C["dim"] + (sub_alpha,))

    def _draw_completion_flash(self, draw, cx, cy, sz, frame):
        """绘制完成闪光脉冲（扩散环）"""
        S = RS
        flash_t = (frame - ANIM_PHASE2) / (ANIM_TOTAL - ANIM_PHASE2)
        if flash_t < 0 or flash_t > 1:
            return

        # 扩散环
        ring_r = int(sz * 0.1 + sz * 0.35 * flash_t)
        ring_w = max(1, int(4 * S * (1 - flash_t)))
        ring_alpha = int(200 * (1 - flash_t))
        if ring_alpha < 10:
            return

        c = _lerp(C["success"], C["flash"], flash_t)
        draw.ellipse(
            [cx - ring_r, cy - ring_r, cx + ring_r, cy + ring_r],
            outline=c + (ring_alpha,),
            width=ring_w,
        )

    # ── Rendering: Expanded ──
    def _render_expanded(self, ball_on_right=True):
        """渲染展开面板（超采样 + RGBA）"""
        S = RS
        ew, eh = EXP_W * S, EXP_H * S
        bs = BALL * S
        c1, c2 = self._colors()
        d = self._data
        pct = d.get("ram_pct", 0)

        total_w = ew + bs
        total_h = eh
        img = Image.new("RGBA", (total_w, total_h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # 面板/球偏移
        px_off = 0 if ball_on_right else bs
        bx_off = ew if ball_on_right else 0
        # 球垂直居中
        by_off = (eh - bs) // 2

        # 面板背景（圆角矩形）
        pad = 4 * S
        r = 16 * S
        draw.rounded_rectangle(
            [px_off + pad, pad, px_off + ew - pad, eh - pad],
            radius=r, fill=C["glass"] + (235,),
        )

        # ── 双栏布局：左栏摘要 / 右栏高占用应用 ──
        left_x = px_off + 20 * S
        right_x = px_off + int(ew * 0.62)
        divider_x = px_off + int(ew * 0.58)
        top_y = 16 * S

        self._clickable_apps = []

        # 左栏标题
        status = d.get("status", "normal")
        dot_color = c1 + (255,)
        dot_r = 5 * S
        draw.ellipse(
            [left_x, top_y + 2 * S, left_x + dot_r * 2, top_y + 2 * S + dot_r * 2],
            fill=dot_color,
        )
        status_text = {"normal": "正常", "warning": "警告", "critical": "危险"}.get(status, "正常")
        draw.text(
            (left_x + dot_r * 2 + 8 * S, top_y),
            f"运行摘要 · {status_text}",
            fill=C["txt"] + (255,),
            font=_font(13 * S, bold=True),
        )

        # 分栏线
        draw.line(
            [divider_x, 14 * S, divider_x, eh - 14 * S],
            fill=C["bar"] + (135,),
            width=1 * S,
        )

        row_y = top_y + 22 * S
        row_h = 19 * S
        font_label = _font(10 * S)
        font_val = _font(11 * S, bold=True)

        rows = [
            ("系统内存", f"{d.get('ram_used_gb', 0):.1f}/{d.get('ram_total_gb', 0):.1f} GB", C["txt"]),
        ]
        # 已提交行 — 根据压力着色
        commit_pct = d.get("commit_pct", 0)
        commit_used = d.get("commit_used_gb", 0)
        commit_total = d.get("commit_total_gb", 0)
        if commit_pct >= 95:
            commit_color = C["crit"]
        elif commit_pct >= 80:
            commit_color = C["warn"]
        else:
            commit_color = C["txt"]
        rows.append(("已提交", f"{commit_used:.1f}/{commit_total:.1f} GB", commit_color))

        rows += [
            ("治理模式", decision_state_label(d.get("decision_state", "enforce")), C["txt"]),
            ("高内存", f"{d.get('high_mem_count', 0)} / {d.get('all_process_count', 0)}", C["txt"]),
            ("Node", f"{d.get('node_count', 0)} 个 · {d.get('node_ram_mb', 0):.0f}MB", C["txt"]),
            ("已回收", f"{d.get('total_killed', 0)} 个 · {d.get('total_freed_mb', 0):.0f}MB", C["dim"]),
        ]
        if d.get("oc_found"):
            oc_gb = d.get("oc_ram_gb", 0)
            oc_color = C["crit"] if oc_gb >= 6.0 else (C["warn"] if oc_gb >= 4.0 else C["txt"])
            rows.insert(2, ("OpenCode", f"{oc_gb:.1f} GB", oc_color))

        left_val_x = divider_x - 10 * S
        for i, (label, value, color) in enumerate(rows[:7]):
            y = row_y + i * row_h
            draw.text((left_x, y), label, fill=C["dim"] + (220,), font=font_label)
            vbb = draw.textbbox((0, 0), value, font=font_val)
            draw.text((left_val_x - (vbb[2] - vbb[0]), y), value, fill=color + (255,), font=font_val)

        # 左栏进度条
        bar_x = left_x
        bar_y = eh - 24 * S
        bar_w = divider_x - left_x - 16 * S
        bar_h = 7 * S
        draw.rounded_rectangle(
            [bar_x, bar_y, bar_x + bar_w, bar_y + bar_h],
            radius=bar_h // 2,
            fill=C["bar"] + (200,),
        )
        if pct > 0:
            fill_w = int(bar_w * min(pct, 100) / 100)
            if fill_w > bar_h:
                draw.rounded_rectangle(
                    [bar_x, bar_y, bar_x + fill_w, bar_y + bar_h],
                    radius=bar_h // 2,
                    fill=c1 + (255,),
                )
        draw.text(
            (bar_x + bar_w + 5 * S, bar_y - 2 * S),
            f"{pct:.0f}%",
            fill=c1 + (255,),
            font=_font(10 * S),
        )

        # 右栏背景板（提高对比度，避免桌面内容穿透）
        right_panel_x = divider_x + 8 * S
        right_panel_y = 10 * S
        right_panel_w = px_off + ew - right_panel_x - 10 * S
        right_panel_h = eh - 20 * S
        draw.rounded_rectangle(
            [
                right_panel_x,
                right_panel_y,
                right_panel_x + right_panel_w,
                right_panel_y + right_panel_h,
            ],
            radius=9 * S,
            fill=(22, 34, 58, 220),
            outline=(88, 110, 148, 220),
            width=max(1, S),
        )

        right_x = right_panel_x + 10 * S

        # 右栏标题
        draw.text(
            (right_x, top_y),
            "高占用应用",
            fill=C["txt"] + (255,),
            font=_font(13 * S, bold=True),
        )
        draw.text(
            (right_x, top_y + 14 * S),
            "点击可手动回收",
            fill=(190, 210, 232, 245),
            font=_font(10 * S),
        )

        app_items = d.get("high_mem_apps", []) or d.get("high_mem_processes", []) or []
        app_top = top_y + 30 * S
        app_row_h = 22 * S
        app_w = right_panel_w - 20 * S
        max_rows = 6

        for i, item in enumerate(app_items[:max_rows]):
            pid = int(item.get("pid", 0))
            base_name = str(item.get("name", ""))
            display_name = str(item.get("display_name", base_name))
            private_mb = float(item.get("private_mb", item.get("ram_mb", 0.0)))
            ram_mb = float(item.get("ram_mb", private_mb))
            y1 = app_top + i * app_row_h
            y2 = y1 + app_row_h - 3 * S
            bg_color = (48, 66, 98, 228) if i % 2 == 0 else (42, 58, 88, 228)

            draw.rounded_rectangle(
                [right_x, y1, right_x + app_w, y2],
                radius=5 * S,
                fill=bg_color,
                outline=(118, 142, 182, 230),
                width=max(1, S),
            )

            name_text = display_name
            if len(name_text) > 12:
                name_text = name_text[:12] + "..."
            draw.text(
                (right_x + 7 * S, y1 + 3 * S),
                name_text,
                fill=(246, 251, 255, 255),
                font=_font(10 * S, bold=True),
            )
            val_text = f"{private_mb:.0f}MB"
            vbb = draw.textbbox((0, 0), val_text, font=_font(10 * S))
            if private_mb >= 1200:
                val_color = C["crit"] + (255,)
            elif private_mb >= 700:
                val_color = C["warn"] + (255,)
            else:
                val_color = (170, 224, 255, 255)
            draw.text(
                (right_x + app_w - (vbb[2] - vbb[0]) - 7 * S, y1 + 3 * S),
                val_text,
                fill=val_color,
                font=_font(10 * S),
            )

            self._clickable_apps.append(
                {
                    "pid": pid,
                    "name": base_name,
                    "ram_mb": ram_mb,
                    "private_mb": private_mb,
                    "rect": (
                        int(right_x / S),
                        int(y1 / S),
                        int((right_x + app_w) / S),
                        int(y2 / S),
                    ),
                }
            )

        if not app_items:
            draw.text(
                (right_x, app_top + 4 * S),
                "暂无高占用应用",
                fill=C["dim"] + (210,),
                font=_font(11 * S),
            )

        # ── 粘贴球 ──
        ball_img = self._render_ball()
        ball_big = ball_img.resize((bs, bs), Image.Resampling.LANCZOS)
        img.paste(ball_big, (bx_off, by_off), ball_big)

        # ── 遮罩 ──
        mask = Image.new("L", (total_w, total_h), 0)
        md = ImageDraw.Draw(mask)
        md.rounded_rectangle([px_off, 0, px_off + ew, eh], radius=r, fill=255)
        circle_mask = _circle_mask(BALL)
        circle_big = circle_mask.resize((bs, bs), Image.Resampling.LANCZOS)
        mask.paste(circle_big, (bx_off, by_off))

        result = Image.new("RGBA", (total_w, total_h), (0, 0, 0, 0))
        result.paste(img, (0, 0), mask)

        final_w = EXP_W + BALL
        return result.resize((final_w, EXP_H), Image.Resampling.LANCZOS)

    # ── Update Window ──
    def _update_window(self, img):
        """更新窗口显示"""
        if not self._hwnd:
            return
        
        # 删除旧的 HBITMAP
        if self._current_hbm:
            gdi32.DeleteObject(self._current_hbm)
        
        # 创建新的 HBITMAP
        self._current_hbm = pil_to_hbitmap(img)
        w, h = img.size
        update_layered_window(self._hwnd, self._current_hbm, w, h)

    def _draw_ball(self):
        """绘制球"""
        self._clickable_apps = []
        img = self._render_ball(glow=self._glow)
        self._update_window(img)

    def _draw_expanded(self):
        """绘制展开面板"""
        ball_on_right = not self._expand_right  # expand_right=面板在右, 所以球在左
        img = self._render_expanded(ball_on_right=ball_on_right)
        self._update_window(img)

    def _draw_reclaim_frame(self):
        """绘制回收动画当前帧"""
        self._clickable_apps = []
        img = self._render_reclaim_frame(self._anim_frame)
        self._update_window(img)

    # ── Reclaim Animation Control ──
    def trigger_reclaim_animation(self, freed_mb: float, killed: int):
        """触发回收动画（线程安全，通过 PostMessage 转发到主线程）"""
        self._anim_freed_mb = freed_mb
        self._anim_killed = killed
        if self._hwnd:
            user32.PostMessageW(self._hwnd, WM_RECLAIM_ANIM, 0, 0)

    def _start_reclaim_anim(self):
        """在主线程启动回收动画"""
        if self._anim_active:
            return
        # 如果展开中，先收起
        if self._expanded:
            self._collapse()
        self._anim_active = True
        self._anim_frame = 0
        self._init_particles(4)
        user32.SetTimer(self._hwnd, TIMER_RECLAIM_ANIM, ANIM_FPS, None)
        self._draw_reclaim_frame()

    def _animate_reclaim(self):
        """回收动画步进（由定时器驱动）"""
        self._anim_frame += 1
        if self._anim_frame >= ANIM_TOTAL:
            # 动画结束
            user32.KillTimer(self._hwnd, TIMER_RECLAIM_ANIM)
            self._anim_active = False
            self._anim_frame = 0
            self._draw_ball()
            return
        self._draw_reclaim_frame()

    def _is_ball_on_right(self):
        """球在屏幕右半边"""
        if not self._hwnd:
            return True
        sw = user32.GetSystemMetrics(0)
        rect = wt.RECT()
        user32.GetWindowRect(self._hwnd, ctypes.byref(rect))
        return rect.left > sw // 2

    # ── Expand / Collapse ──
    def _expand(self):
        """展开信息面板"""
        if self._expanded or self._docked or not self._hwnd:
            return
        self._expanded = True

        rect = wt.RECT()
        user32.GetWindowRect(self._hwnd, ctypes.byref(rect))
        bx, by = rect.left, rect.top

        # 锁定方向
        sw = user32.GetSystemMetrics(0)
        ball_on_right = bx > sw // 2
        self._expand_right = not ball_on_right

        w = EXP_W + BALL
        if ball_on_right:
            x = bx - EXP_W
            if x < 0:
                x = 0
        else:
            x = bx

        y_offset = (EXP_H - BALL) // 2
        wy = by - y_offset

        # 先渲染好图像，再一次性更新窗口（位置+尺寸+内容同步）
        img = self._render_expanded(ball_on_right=ball_on_right)
        if self._current_hbm:
            gdi32.DeleteObject(self._current_hbm)
        self._current_hbm = pil_to_hbitmap(img)

        # 同时设置位置、尺寸
        user32.SetWindowPos(self._hwnd, None, x, wy, w, EXP_H, SWP_NOZORDER)
        # 立即刷新内容
        update_layered_window(self._hwnd, self._current_hbm, img.size[0], img.size[1])
        self._ignore_leave_until = time.monotonic() + 0.3

    def _collapse(self):
        """收起信息面板"""
        if not self._expanded or not self._hwnd:
            return
        self._expanded = False

        rect = wt.RECT()
        user32.GetWindowRect(self._hwnd, ctypes.byref(rect))

        # 用锁定的方向计算球的回归位置
        if not self._expand_right:
            # 面板在左，球在右 → 球x = 窗口左 + EXP_W
            x = rect.left + EXP_W
        else:
            # 面板在右，球在左 → 球x = 窗口左
            x = rect.left

        # 恢复球的y坐标（展开时上移了y_offset）
        y_offset = (EXP_H - BALL) // 2
        y = rect.top + y_offset
        user32.SetWindowPos(self._hwnd, None, x, y, BALL, BALL, SWP_NOZORDER)
        self._ignore_leave_until = time.monotonic() + 0.3
        self._draw_ball()

    # ── Glow Animation ──
    def _start_glow(self):
        """开始发光动画"""
        self._glow_target = GLOW_MAX
        if self._glow != self._glow_target:
            user32.SetTimer(self._hwnd, TIMER_GLOW, GLOW_MS, None)

    def _stop_glow(self):
        """停止发光动画"""
        self._glow_target = 0
        if self._glow != self._glow_target:
            user32.SetTimer(self._hwnd, TIMER_GLOW, GLOW_MS, None)

    def _animate_glow(self):
        """发光动画步进"""
        if self._glow < self._glow_target:
            self._glow = min(self._glow + GLOW_STEP, self._glow_target)
        elif self._glow > self._glow_target:
            self._glow = max(self._glow - GLOW_STEP, self._glow_target)
        
        if not self._expanded and not self._docked:
            self._draw_ball()
        
        if self._glow == self._glow_target:
            user32.KillTimer(self._hwnd, TIMER_GLOW)

    # ── Docking ──
    def _check_dock(self):
        """检查是否需要吸附"""
        if self._docked or not self._hwnd:
            return
        
        rect = wt.RECT()
        user32.GetWindowRect(self._hwnd, ctypes.byref(rect))
        x = rect.left
        sw = user32.GetSystemMetrics(0)
        
        if x <= DOCK_TH:
            self._dock("left")
        elif x + BALL >= sw - DOCK_TH:
            self._dock("right")

    def _dock(self, side: str):
        """吸附到屏幕边缘"""
        if not self._hwnd:
            return
        
        if self._expanded:
            self._collapse()
        
        rect = wt.RECT()
        user32.GetWindowRect(self._hwnd, ctypes.byref(rect))
        self._pre_dock_x = rect.left
        self._pre_dock_y = rect.top
        self._docked = True
        self._dock_side = side
        
        sw = user32.GetSystemMetrics(0)
        y = self._pre_dock_y
        
        if side == "left":
            tx = -(BALL - DOCK_SHOW)
        else:
            tx = sw - DOCK_SHOW
        
        self._slide_to(tx, y)

    def _slide_to(self, tx, ty, steps=6, callback=None):
        """启动滑动动画"""
        if not self._hwnd:
            return
        self._slide_tx = tx
        self._slide_ty = ty
        self._slide_step = 0
        self._slide_steps = steps
        self._slide_callback = callback
        user32.SetTimer(self._hwnd, TIMER_SLIDE, 16, None)

    def _slide_tick(self):
        """滑动动画单步"""
        if not self._hwnd:
            return
        self._slide_step += 1
        if self._slide_step >= self._slide_steps:
            user32.KillTimer(self._hwnd, TIMER_SLIDE)
            user32.SetWindowPos(
                self._hwnd, None,
                self._slide_tx, self._slide_ty,
                BALL, BALL, SWP_NOZORDER,
            )
            if self._slide_callback:
                cb = self._slide_callback
                self._slide_callback = None
                cb()
            return

        rect = wt.RECT()
        user32.GetWindowRect(self._hwnd, ctypes.byref(rect))
        cx, cy = rect.left, rect.top
        t = self._slide_step / self._slide_steps
        t = 1 - (1 - t) ** 2  # ease-out

        nx = int(cx + (self._slide_tx - cx) * t)
        ny = int(cy + (self._slide_ty - cy) * t)
        user32.SetWindowPos(
            self._hwnd, None, nx, ny, BALL, BALL, SWP_NOZORDER,
        )

    def _undock(self):
        """取消吸附"""
        if not self._docked or not self._hwnd:
            return
        
        self._was_docked = True
        self._last_dock_side = self._dock_side
        self._docked = False
        side = self._dock_side
        self._dock_side = ""
        
        rect = wt.RECT()
        user32.GetWindowRect(self._hwnd, ctypes.byref(rect))
        y = rect.top
        sw = user32.GetSystemMetrics(0)
        
        if side == "left":
            tx = 0
        else:
            tx = sw - BALL
        
        self._slide_to(tx, y, callback=self._expand)

    # ── Window Procedure ──
    def _wnd_proc(self, hwnd, msg, wparam, lparam):
        """Win32 窗口过程"""
        try:
            if msg == WM_TIMER:
                if wparam == TIMER_REFRESH:
                    self._refresh()
                elif wparam == TIMER_GLOW:
                    self._animate_glow()
                elif wparam == TIMER_EXPAND:
                    user32.KillTimer(hwnd, TIMER_EXPAND)
                    if not self._dragging and not self._docked and not self._expanded:
                        self._expand()
                elif wparam == TIMER_REDOCK:
                    user32.KillTimer(hwnd, TIMER_REDOCK)
                    self._maybe_redock()
                elif wparam == TIMER_SAFETY:
                    self._safety_check()
                elif wparam == TIMER_SLIDE:
                    self._slide_tick()
                elif wparam == TIMER_RECLAIM_ANIM:
                    self._animate_reclaim()
                return 0
            
            elif msg == WM_RECLAIM_ANIM:
                self._start_reclaim_anim()
                return 0
            
            elif msg == WM_LBUTTONDOWN:
                self._dragging = True
                self._did_drag = False
                user32.SetCapture(hwnd)
                x = ctypes.c_short(lparam & 0xFFFF).value
                y = ctypes.c_short((lparam >> 16) & 0xFFFF).value
                self._drag_ox = x
                self._drag_oy = y
                pt = wt.POINT()
                user32.GetCursorPos(ctypes.byref(pt))
                self._drag_start_x = pt.x
                self._drag_start_y = pt.y
                return 0
            
            elif msg == WM_MOUSEMOVE:
                if not self._mouse_inside:
                    self._mouse_inside = True
                    self._on_mouse_enter()
                    # Track mouse leave
                    tme = TRACKMOUSEEVENT()
                    tme.cbSize = ctypes.sizeof(TRACKMOUSEEVENT)
                    tme.dwFlags = TME_LEAVE
                    tme.hwndTrack = hwnd
                    user32.TrackMouseEvent(ctypes.byref(tme))
                
                if self._dragging:
                    pt = wt.POINT()
                    user32.GetCursorPos(ctypes.byref(pt))

                    if not self._did_drag:
                        dx = abs(pt.x - self._drag_start_x)
                        dy = abs(pt.y - self._drag_start_y)
                        if dx < DRAG_THRESHOLD and dy < DRAG_THRESHOLD:
                            return 0
                        self._did_drag = True
                    
                    if self._expanded:
                        rect = wt.RECT()
                        user32.GetWindowRect(hwnd, ctypes.byref(rect))
                        if self._is_ball_on_right():
                            ball_x = rect.left + EXP_W
                        else:
                            ball_x = rect.left
                        ball_y = rect.top
                        self._expanded = False
                        user32.SetWindowPos(hwnd, None, ball_x, ball_y, BALL, BALL, SWP_NOZORDER)
                        self._draw_ball()
                        self._drag_ox = pt.x - ball_x
                        self._drag_oy = pt.y - ball_y
                    else:
                        x = pt.x - self._drag_ox
                        y = pt.y - self._drag_oy
                        user32.SetWindowPos(hwnd, None, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER)
                return 0
            
            elif msg == WM_LBUTTONUP:
                if self._dragging:
                    was_dragged = self._did_drag
                    self._dragging = False
                    user32.ReleaseCapture()
                    if was_dragged:
                        self._check_dock()
                        if not self._docked:
                            self._was_docked = False
                    elif self._expanded:
                        x = ctypes.c_short(lparam & 0xFFFF).value
                        y = ctypes.c_short((lparam >> 16) & 0xFFFF).value
                        self._handle_expanded_click(x, y)
                    self._did_drag = False
                elif self._expanded:
                    x = ctypes.c_short(lparam & 0xFFFF).value
                    y = ctypes.c_short((lparam >> 16) & 0xFFFF).value
                    self._handle_expanded_click(x, y)
                return 0
            
            elif msg == WM_MOUSELEAVE:
                self._mouse_inside = False
                # 展开/收起后短暂忽略，防止窗口移动触发的假 leave
                if time.monotonic() < self._ignore_leave_until:
                    return 0
                self._on_mouse_leave()
                return 0
            
            elif msg == WM_RBUTTONUP:
                self._show_context_menu()
                return 0
            
            elif msg == WM_CLOSE:
                self._running = False
                user32.DestroyWindow(hwnd)
                return 0
            
            elif msg == WM_DESTROY:
                user32.PostQuitMessage(0)
                return 0
        
        except Exception:
            pass
        
        return user32.DefWindowProcW(hwnd, msg, wt.WPARAM(wparam), wt.LPARAM(lparam))

    def _handle_expanded_click(self, x: int, y: int) -> bool:
        """处理展开面板内的点击命中（高占用应用列表）。"""
        if not self._expanded:
            return False

        for item in self._clickable_apps:
            left, top, right, bottom = item.get("rect", (0, 0, 0, 0))
            if left <= x <= right and top <= y <= bottom:
                return self._confirm_manual_reclaim(item)
        return False

    def _confirm_manual_reclaim(self, item: Dict[str, Any]) -> bool:
        """弹窗确认后触发手动回收。"""
        pid = int(item.get("pid", 0))
        name = str(item.get("name", ""))
        ram_mb = float(item.get("ram_mb", 0.0))
        private_mb = float(item.get("private_mb", ram_mb))
        if pid <= 0:
            return False

        msg = (
            f"确认回收进程？\n\n"
            f"应用: {name}\n"
            f"PID: {pid}\n"
            f"专用内存: {private_mb:.0f} MB\n"
            f"工作集: {ram_mb:.0f} MB\n\n"
            "该操作会终止进程。"
        )
        ret = user32.MessageBoxW(
            self._hwnd,
            msg,
            "MemGuard 手动回收",
            MB_YESNO | MB_ICONQUESTION,
        )
        if ret != IDYES:
            return False

        accepted = bool(self._on_manual_reclaim_process(pid, name))
        if not accepted:
            user32.MessageBoxW(
                self._hwnd,
                "当前已有回收任务在执行，请稍后再试。",
                "MemGuard",
                MB_ICONWARNING,
            )
        return accepted

    # ── Event Handlers ──
    def _on_mouse_enter(self):
        """鼠标进入"""
        self._start_glow()
        if self._docked:
            self._undock()
        elif not self._dragging and not self._expanded:
            user32.SetTimer(self._hwnd, TIMER_EXPAND, 350, None)

    def _on_mouse_leave(self):
        """鼠标离开"""
        self._stop_glow()
        user32.KillTimer(self._hwnd, TIMER_EXPAND)
        
        if self._expanded and not self._dragging:
            self._collapse()
        
        if self._was_docked and not self._dragging and not self._docked:
            user32.SetTimer(self._hwnd, TIMER_REDOCK, 400, None)

    def _maybe_redock(self):
        """鼠标离开后检查是否需要重新吸附"""
        if self._docked or self._dragging or not self._was_docked or not self._hwnd:
            return
        
        pt = wt.POINT()
        user32.GetCursorPos(ctypes.byref(pt))
        rect = wt.RECT()
        user32.GetWindowRect(self._hwnd, ctypes.byref(rect))
        
        # 鼠标仍在窗口内，不吸附
        if rect.left <= pt.x <= rect.right and rect.top <= pt.y <= rect.bottom:
            return
        
        # 鼠标已离开，重新吸附
        self._dock(self._last_dock_side)

    def _show_context_menu(self):
        """显示右键菜单"""
        if not self._hwnd:
            return
        
        hmenu = user32.CreatePopupMenu()
        user32.AppendMenuW(hmenu, MF_STRING, 1, "立即回收")

        auto_label = "自动回收: 开" if self._get_reclaim_state() else "自动回收: 关"
        user32.AppendMenuW(hmenu, MF_STRING, 2, auto_label)
        user32.AppendMenuW(hmenu, MF_STRING, 4, "切换治理模式")
        user32.AppendMenuW(hmenu, MF_STRING, 5, "应用策略")
        user32.AppendMenuW(hmenu, MF_SEPARATOR, 0, None)
        user32.AppendMenuW(hmenu, MF_STRING, 3, "退出")
        
        pt = wt.POINT()
        user32.GetCursorPos(ctypes.byref(pt))
        
        cmd = user32.TrackPopupMenu(
            hmenu, TPM_LEFTALIGN | TPM_RETURNCMD,
            pt.x, pt.y, 0, self._hwnd, None
        )
        
        user32.DestroyMenu(hmenu)
        
        if cmd == 1:
            self._on_force_reclaim()
        elif cmd == 2:
            self._on_toggle_reclaim()
        elif cmd == 4:
            self._on_cycle_decision_state()
        elif cmd == 5:
            self._on_open_policy_panel()
        elif cmd == 3:
            self._on_quit()
            user32.PostMessageW(self._hwnd, WM_CLOSE, 0, 0)

    # ── Data & Refresh ──
    def update_data(self, data: dict):
        """线程安全的数据更新"""
        with self._lock:
            self._data = data

    def _refresh(self):
        """定时刷新数据和显示"""
        if not self._hwnd or not self._visible:
            return
        if self._anim_active:
            # 动画期间只更新数据，不重绘（由动画定时器驱动）
            new_data = self._get_data()
            with self._lock:
                self._data = new_data
            return
        try:
            new_data = self._get_data()
            with self._lock:
                self._data = new_data

            sig = (
                new_data.get("ram_pct"),
                new_data.get("status"),
                new_data.get("decision_state"),
                new_data.get("high_mem_count"),
                new_data.get("node_count"),
                new_data.get("node_ram_mb"),
                new_data.get("total_killed"),
                new_data.get("total_freed_mb"),
                tuple(new_data.get("recent_skips", [])[-1:]),
                self._expanded,
                self._docked,
            )

            if sig == self._last_render_signature and not self._expanded:
                return

            if self._expanded:
                self._draw_expanded()
            else:
                # 吸附和非吸附状态都重绘球
                self._draw_ball()

            self._last_render_signature = sig
        except Exception as e:
            import traceback
            traceback.print_exc()

    def _safety_check(self):
        """安全检查：防止球完全消失在屏幕外"""
        if not self._hwnd or not self._visible:
            return
        try:
            rect = wt.RECT()
            user32.GetWindowRect(self._hwnd, ctypes.byref(rect))
            x, y = rect.left, rect.top
            sw = user32.GetSystemMetrics(0)
            sh = user32.GetSystemMetrics(1)
            
            # 球完全在屏幕外
            if x + BALL < -10 or x > sw + 10 or y + BALL < -10 or y > sh + 10:
                nx = sw - BALL - 60
                ny = (sh - BALL) // 2
                self._docked = False
                self._was_docked = False
                self._dock_side = ""
                user32.SetWindowPos(self._hwnd, None, nx, ny, BALL, BALL, SWP_NOZORDER)
                self._draw_ball()
        except Exception:
            pass

    # ── Visibility ──
    def show(self):
        """显示窗口"""
        if self._hwnd and not self._visible:
            self._visible = True
            user32.ShowWindow(self._hwnd, SW_SHOW)

    def hide(self):
        """隐藏窗口"""
        if self._hwnd and self._visible:
            self._visible = False
            user32.ShowWindow(self._hwnd, SW_HIDE)

    def toggle_visibility(self):
        """切换显示/隐藏"""
        if self._visible:
            self.hide()
        else:
            self.show()

    # ── Lifecycle ──
    def run(self):
        """创建窗口并进入消息循环（阻塞）"""
        self._hinstance = kernel32.GetModuleHandleW(None)
        self._wnd_proc_cb = WNDPROC(self._wnd_proc)
        
        # 注册窗口类
        wc = WNDCLASSEX()
        wc.cbSize = ctypes.sizeof(WNDCLASSEX)
        wc.style = CS_HREDRAW | CS_VREDRAW
        wc.lpfnWndProc = self._wnd_proc_cb
        wc.hInstance = self._hinstance
        wc.hCursor = user32.LoadCursorW(None, IDC_ARROW)
        wc.lpszClassName = "MemGuardFloatingBall"
        
        if not user32.RegisterClassExW(ctypes.byref(wc)):
            raise RuntimeError(f"RegisterClassEx failed: {kernel32.GetLastError()}")
        
        # 获取屏幕尺寸
        sw = user32.GetSystemMetrics(0)
        sh = user32.GetSystemMetrics(1)
        x = sw - BALL - 60
        y = (sh - BALL) // 2
        
        # 创建窗口
        self._hwnd = user32.CreateWindowExW(
            WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
            "MemGuardFloatingBall", "MemGuard",
            WS_POPUP,
            x, y, BALL, BALL,
            None, None, self._hinstance, None
        )
        
        if not self._hwnd:
            raise RuntimeError(f"CreateWindowEx failed: {kernel32.GetLastError()}")
        
        # 初始化数据和渲染
        self._data = self._get_data()
        self._draw_ball()
        
        # 显示窗口
        user32.ShowWindow(self._hwnd, SW_SHOW)
        user32.UpdateWindow(self._hwnd)
        
        # 启动定时器
        user32.SetTimer(self._hwnd, TIMER_REFRESH, 3000, None)  # 数据刷新
        user32.SetTimer(self._hwnd, TIMER_SAFETY, 5000, None)   # 安全检查
        
        self._running = True
        
        # 消息循环
        msg = wt.MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))
        
        # 清理
        if self._current_hbm:
            gdi32.DeleteObject(self._current_hbm)
            self._current_hbm = None

    def stop(self):
        """停止窗口（从其他线程调用）"""
        if self._hwnd:
            user32.PostMessageW(self._hwnd, WM_CLOSE, 0, 0)
