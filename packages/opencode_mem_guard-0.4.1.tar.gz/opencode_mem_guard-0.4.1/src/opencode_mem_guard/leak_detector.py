"""
内存泄漏检测算法模块
基于滑动窗口线性回归检测内存增长趋势，识别泄漏模式
"""
import time
import math
from collections import deque
from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Deque

from .collector import MemSnapshot


@dataclass
class LeakAlert:
    """泄漏告警"""
    timestamp: float
    level: str  # "warning", "critical", "emergency"
    metric: str  # 哪个指标
    message: str
    current_value: float
    growth_rate_per_min: float  # MB/min 或 %/min
    predicted_exhaust_min: float  # 预计多少分钟后耗尽
    window_minutes: float  # 分析窗口长度


@dataclass
class GovernanceDecision:
    """治理动作建议"""

    state: str  # observe | warn | dry-run | enforce
    reason: str
    severity: str  # normal | warning | critical


@dataclass
class TrendResult:
    """趋势分析结果"""
    slope: float  # 每秒变化量
    r_squared: float  # 拟合度 (0~1, 越高越线性)
    slope_per_min: float  # 每分钟变化量
    is_growing: bool
    confidence: str  # "high", "medium", "low"


def linear_regression(xs: List[float], ys: List[float]) -> Tuple[float, float, float]:
    """
    简单线性回归，返回 (slope, intercept, r_squared)
    纯 Python 实现，不依赖 numpy
    """
    n = len(xs)
    if n < 2:
        return 0.0, 0.0, 0.0

    sum_x = sum(xs)
    sum_y = sum(ys)
    sum_xy = sum(x * y for x, y in zip(xs, ys))
    sum_x2 = sum(x * x for x in xs)
    sum_y2 = sum(y * y for y in ys)

    denom = n * sum_x2 - sum_x * sum_x
    if abs(denom) < 1e-12:
        return 0.0, sum_y / n, 0.0

    slope = (n * sum_xy - sum_x * sum_y) / denom
    intercept = (sum_y - slope * sum_x) / n

    # R² 计算
    ss_res = sum((y - (slope * x + intercept)) ** 2 for x, y in zip(xs, ys))
    mean_y = sum_y / n
    ss_tot = sum((y - mean_y) ** 2 for y in ys)

    r_squared = 1.0 - (ss_res / ss_tot) if ss_tot > 1e-12 else 0.0
    r_squared = max(0.0, min(1.0, r_squared))

    return slope, intercept, r_squared


class LeakDetector:
    """
    内存泄漏检测器
    
    核心策略：
    1. 滑动窗口线性回归 - 检测持续增长趋势
    2. 绝对阈值告警 - 内存使用超过危险线
    3. 进程数异常检测 - node进程数持续增长(僵尸进程)
    4. 句柄泄漏检测 - 句柄数持续增长
    """

    def __init__(
        self,
        window_size: int = 60,          # 保留最近60个采样点
        min_samples: int = 5,            # 至少5个点才做趋势分析
        ram_warn_pct: float = 80.0,      # 系统内存使用 >80% 警告
        ram_critical_pct: float = 90.0,  # >90% 严重
        ram_emergency_pct: float = 95.0, # >95% 紧急
        node_ram_warn_mb: float = 4096,  # node总内存 >4GB 警告
        node_ram_critical_mb: float = 8192,
        growth_warn_mb_per_min: float = 10.0,   # 增长 >10MB/min 警告
        growth_critical_mb_per_min: float = 50.0,
        handle_growth_warn_per_min: float = 50.0,
        # opencode-cli.exe 内存阈值
        oc_ram_warn_gb: float = 4.0,     # opencode-cli >4GB 警告
        oc_ram_critical_gb: float = 6.0, # >6GB 危险
        # 提交内存阈值
        commit_warn_pct: float = 80.0,       # commit >= 80% 警告
        commit_critical_pct: float = 90.0,   # commit >= 90% 严重
        commit_emergency_pct: float = 95.0,  # commit >= 95% 紧急
    ):
        self.window_size = window_size
        self.min_samples = min_samples
        self.ram_warn_pct = ram_warn_pct
        self.ram_critical_pct = ram_critical_pct
        self.ram_emergency_pct = ram_emergency_pct
        self.node_ram_warn_mb = node_ram_warn_mb
        self.node_ram_critical_mb = node_ram_critical_mb
        self.growth_warn_mb_per_min = growth_warn_mb_per_min
        self.growth_critical_mb_per_min = growth_critical_mb_per_min
        self.handle_growth_warn_per_min = handle_growth_warn_per_min
        self.oc_ram_warn_gb = oc_ram_warn_gb
        self.oc_ram_critical_gb = oc_ram_critical_gb
        self.commit_warn_pct = commit_warn_pct
        self.commit_critical_pct = commit_critical_pct
        self.commit_emergency_pct = commit_emergency_pct

        # 滑动窗口数据
        self._timestamps: Deque[float] = deque(maxlen=window_size)
        self._sys_usage_pct: Deque[float] = deque(maxlen=window_size)
        self._node_ram_mb: Deque[float] = deque(maxlen=window_size)
        self._node_virtual_gb: Deque[float] = deque(maxlen=window_size)
        self._node_handles: Deque[int] = deque(maxlen=window_size)
        self._node_proc_count: Deque[int] = deque(maxlen=window_size)
        self._commit_pct: Deque[float] = deque(maxlen=window_size)
        self._high_mem_count: Deque[int] = deque(maxlen=window_size)
        self._latest_decision = GovernanceDecision(
            state="observe",
            reason="无告警",
            severity="normal",
        )

    def feed(self, snap: MemSnapshot) -> List[LeakAlert]:
        """喂入一个快照，返回告警列表"""
        if snap.error:
            return []

        self._timestamps.append(snap.timestamp)
        self._node_ram_mb.append(snap.node_total_ram_mb)
        self._node_virtual_gb.append(snap.node_total_virtual_gb)
        self._node_handles.append(snap.node_total_handles)
        self._node_proc_count.append(snap.node_process_count)

        if snap.system:
            self._sys_usage_pct.append(snap.system.usage_pct)
            self._commit_pct.append(snap.system.commit_pct)
        self._high_mem_count.append(len(snap.high_mem_processes))

        alerts: List[LeakAlert] = []

        # 1. 绝对阈值检查
        alerts.extend(self._check_thresholds(snap))

        # 2. 趋势分析（需要足够样本）
        if len(self._timestamps) >= self.min_samples:
            alerts.extend(self._check_trends(snap))

        self._latest_decision = self._derive_decision(alerts)

        return alerts

    @property
    def latest_decision(self) -> GovernanceDecision:
        return self._latest_decision

    def _derive_decision(self, alerts: List[LeakAlert]) -> GovernanceDecision:
        if not alerts:
            return GovernanceDecision(state="observe", reason="无告警", severity="normal")
        has_critical = any(a.level in ("critical", "emergency") for a in alerts)
        if has_critical:
            return GovernanceDecision(
                state="dry-run",
                reason="存在严重告警，建议进入 dry-run 观察回收候选",
                severity="critical",
            )
        return GovernanceDecision(
            state="warn",
            reason="存在告警，建议先告警并观察",
            severity="warning",
        )

    def _check_thresholds(self, snap: MemSnapshot) -> List[LeakAlert]:
        """绝对阈值检查"""
        alerts = []
        now = snap.timestamp

        # 系统内存使用率
        if snap.system:
            pct = snap.system.usage_pct
            if pct >= self.ram_emergency_pct:
                alerts.append(LeakAlert(
                    timestamp=now, level="emergency", metric="system_ram_pct",
                    message=f"系统内存使用 {pct}% >= {self.ram_emergency_pct}%，即将耗尽！",
                    current_value=pct, growth_rate_per_min=0,
                    predicted_exhaust_min=0, window_minutes=0,
                ))
            elif pct >= self.ram_critical_pct:
                alerts.append(LeakAlert(
                    timestamp=now, level="critical", metric="system_ram_pct",
                    message=f"系统内存使用 {pct}% >= {self.ram_critical_pct}%",
                    current_value=pct, growth_rate_per_min=0,
                    predicted_exhaust_min=0, window_minutes=0,
                ))
            elif pct >= self.ram_warn_pct:
                alerts.append(LeakAlert(
                    timestamp=now, level="warning", metric="system_ram_pct",
                    message=f"系统内存使用 {pct}% >= {self.ram_warn_pct}%",
                    current_value=pct, growth_rate_per_min=0,
                    predicted_exhaust_min=0, window_minutes=0,
                ))

            # 提交内存(虚拟内存) — 三级告警
            cpct = snap.system.commit_pct
            if cpct >= self.commit_emergency_pct:
                alerts.append(LeakAlert(
                    timestamp=now, level="emergency", metric="commit_pct",
                    message=f"已提交 {cpct:.1f}% >= {self.commit_emergency_pct}%，即将触及限额！",
                    current_value=cpct, growth_rate_per_min=0,
                    predicted_exhaust_min=0, window_minutes=0,
                ))
            elif cpct >= self.commit_critical_pct:
                alerts.append(LeakAlert(
                    timestamp=now, level="critical", metric="commit_pct",
                    message=f"已提交 {cpct:.1f}% >= {self.commit_critical_pct}%，页面文件压力大",
                    current_value=cpct, growth_rate_per_min=0,
                    predicted_exhaust_min=0, window_minutes=0,
                ))
            elif cpct >= self.commit_warn_pct:
                alerts.append(LeakAlert(
                    timestamp=now, level="warning", metric="commit_pct",
                    message=f"已提交 {cpct:.1f}% >= {self.commit_warn_pct}%，建议关注",
                    current_value=cpct, growth_rate_per_min=0,
                    predicted_exhaust_min=0, window_minutes=0,
                ))

        # Node 总内存
        if snap.node_total_ram_mb >= self.node_ram_critical_mb:
            alerts.append(LeakAlert(
                timestamp=now, level="critical", metric="node_total_ram",
                message=f"Node总内存 {snap.node_total_ram_mb:.0f}MB >= {self.node_ram_critical_mb}MB",
                current_value=snap.node_total_ram_mb, growth_rate_per_min=0,
                predicted_exhaust_min=0, window_minutes=0,
            ))
        elif snap.node_total_ram_mb >= self.node_ram_warn_mb:
            alerts.append(LeakAlert(
                timestamp=now, level="warning", metric="node_total_ram",
                message=f"Node总内存 {snap.node_total_ram_mb:.0f}MB >= {self.node_ram_warn_mb}MB",
                current_value=snap.node_total_ram_mb, growth_rate_per_min=0,
                predicted_exhaust_min=0, window_minutes=0,
            ))

        # OpenCode 主进程内存 (opencode-cli.exe = bun binary)
        if snap.opencode and snap.opencode.found:
            oc_gb = snap.opencode.ram_gb
            if oc_gb >= self.oc_ram_critical_gb:
                alerts.append(LeakAlert(
                    timestamp=now, level="critical", metric="opencode_ram",
                    message=f"OpenCode进程内存 {oc_gb:.1f}GB >= {self.oc_ram_critical_gb}GB，建议重启",
                    current_value=oc_gb, growth_rate_per_min=0,
                    predicted_exhaust_min=0, window_minutes=0,
                ))
            elif oc_gb >= self.oc_ram_warn_gb:
                alerts.append(LeakAlert(
                    timestamp=now, level="warning", metric="opencode_ram",
                    message=f"OpenCode进程内存 {oc_gb:.1f}GB >= {self.oc_ram_warn_gb}GB",
                    current_value=oc_gb, growth_rate_per_min=0,
                    predicted_exhaust_min=0, window_minutes=0,
                ))

        # 全进程高内存进程数量
        high_mem_count = len(snap.high_mem_processes)
        if high_mem_count >= 10:
            alerts.append(LeakAlert(
                timestamp=now,
                level="warning",
                metric="high_mem_process_count",
                message=f"高内存进程数 {high_mem_count} 个 (阈值: 10)",
                current_value=float(high_mem_count),
                growth_rate_per_min=0,
                predicted_exhaust_min=0,
                window_minutes=0,
            ))

        return alerts

    def _analyze_trend(self, timestamps: list, values: list) -> Optional[TrendResult]:
        """对一组时间序列做趋势分析"""
        if len(timestamps) < self.min_samples:
            return None

        ts = list(timestamps)
        vs = list(values)
        t0 = ts[0]
        xs = [t - t0 for t in ts]

        slope, intercept, r_sq = linear_regression(xs, vs)
        slope_per_min = slope * 60.0

        if r_sq >= 0.8:
            confidence = "high"
        elif r_sq >= 0.5:
            confidence = "medium"
        else:
            confidence = "low"

        return TrendResult(
            slope=slope, r_squared=r_sq,
            slope_per_min=slope_per_min,
            is_growing=slope > 0, confidence=confidence,
        )

    def _check_trends(self, snap: MemSnapshot) -> List[LeakAlert]:
        """趋势分析检查"""
        alerts = []
        now = snap.timestamp
        ts = list(self._timestamps)
        window_min = (ts[-1] - ts[0]) / 60.0 if len(ts) >= 2 else 0

        # ── Node 总 RAM 增长趋势 ──
        trend = self._analyze_trend(ts, list(self._node_ram_mb))
        if trend and trend.is_growing and trend.confidence in ("high", "medium"):
            rate = trend.slope_per_min
            if snap.system and snap.system.total_ram_gb > 0:
                remaining_mb = snap.system.free_ram_gb * 1024
                exhaust_min = remaining_mb / rate if rate > 0.01 else float('inf')
            else:
                exhaust_min = float('inf')

            if rate >= self.growth_critical_mb_per_min:
                alerts.append(LeakAlert(
                    timestamp=now, level="critical",
                    metric="node_ram_growth",
                    message=f"Node内存快速增长 {rate:.1f}MB/min (R²={trend.r_squared:.2f})，"
                            f"预计 {exhaust_min:.0f}min 后耗尽系统内存",
                    current_value=snap.node_total_ram_mb,
                    growth_rate_per_min=rate,
                    predicted_exhaust_min=exhaust_min,
                    window_minutes=window_min,
                ))
            elif rate >= self.growth_warn_mb_per_min:
                alerts.append(LeakAlert(
                    timestamp=now, level="warning",
                    metric="node_ram_growth",
                    message=f"Node内存持续增长 {rate:.1f}MB/min (R²={trend.r_squared:.2f})",
                    current_value=snap.node_total_ram_mb,
                    growth_rate_per_min=rate,
                    predicted_exhaust_min=exhaust_min,
                    window_minutes=window_min,
                ))

        # ── 句柄泄漏检测 ──
        handle_trend = self._analyze_trend(ts, list(self._node_handles))
        if handle_trend and handle_trend.is_growing and handle_trend.confidence in ("high", "medium"):
            h_rate = handle_trend.slope_per_min
            if h_rate >= self.handle_growth_warn_per_min:
                alerts.append(LeakAlert(
                    timestamp=now, level="warning",
                    metric="handle_growth",
                    message=f"句柄数持续增长 {h_rate:.0f}/min (R²={handle_trend.r_squared:.2f})，"
                            f"当前总句柄 {snap.node_total_handles}",
                    current_value=float(snap.node_total_handles),
                    growth_rate_per_min=h_rate,
                    predicted_exhaust_min=0,
                    window_minutes=window_min,
                ))

        # ── 进程数异常增长(僵尸进程) ──
        if len(self._node_proc_count) >= self.min_samples:
            first_count = list(self._node_proc_count)[0]
            current_count = snap.node_process_count
            if current_count > first_count + 5:
                alerts.append(LeakAlert(
                    timestamp=now, level="warning",
                    metric="process_count_growth",
                    message=f"Node进程数从 {first_count} 增长到 {current_count}，"
                            f"可能存在僵尸进程",
                    current_value=float(current_count),
                    growth_rate_per_min=0,
                    predicted_exhaust_min=0,
                    window_minutes=window_min,
                ))

        # ── 系统内存使用率趋势 ──
        if len(self._sys_usage_pct) >= self.min_samples:
            sys_trend = self._analyze_trend(
                ts[-len(self._sys_usage_pct):],
                list(self._sys_usage_pct))
            if (sys_trend and sys_trend.is_growing
                    and sys_trend.confidence == "high"
                    and sys_trend.slope_per_min > 0.5):
                remaining_pct = 100.0 - (snap.system.usage_pct if snap.system else 0)
                exhaust = (remaining_pct / sys_trend.slope_per_min
                           if sys_trend.slope_per_min > 0.01 else float('inf'))
                alerts.append(LeakAlert(
                    timestamp=now, level="warning",
                    metric="sys_ram_trend",
                    message=f"系统内存使用率持续上升 "
                            f"{sys_trend.slope_per_min:.2f}%/min，"
                            f"预计 {exhaust:.0f}min 后达到100%",
                    current_value=snap.system.usage_pct if snap.system else 0,
                    growth_rate_per_min=sys_trend.slope_per_min,
                    predicted_exhaust_min=exhaust,
                    window_minutes=window_min,
                ))

        # ── 已提交内存趋势 ──
        if len(self._commit_pct) >= self.min_samples:
            commit_trend = self._analyze_trend(
                ts[-len(self._commit_pct):],
                list(self._commit_pct))
            if (commit_trend and commit_trend.is_growing
                    and commit_trend.confidence in ("high", "medium")
                    and commit_trend.slope_per_min > 0.3):
                remaining_pct = 100.0 - (snap.system.commit_pct if snap.system else 0)
                exhaust = (remaining_pct / commit_trend.slope_per_min
                           if commit_trend.slope_per_min > 0.01 else float('inf'))
                level = "critical" if commit_trend.slope_per_min > 1.0 else "warning"
                alerts.append(LeakAlert(
                    timestamp=now, level=level,
                    metric="commit_pct_trend",
                    message=f"已提交持续上升 "
                            f"{commit_trend.slope_per_min:.2f}%/min "
                            f"(R²={commit_trend.r_squared:.2f})，"
                            f"预计 {exhaust:.0f}min 后触及限额",
                    current_value=snap.system.commit_pct if snap.system else 0,
                    growth_rate_per_min=commit_trend.slope_per_min,
                    predicted_exhaust_min=exhaust,
                    window_minutes=window_min,
                ))

        return alerts
