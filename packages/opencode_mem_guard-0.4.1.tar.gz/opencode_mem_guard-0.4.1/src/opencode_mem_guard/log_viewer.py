"""
实时日志查看器 — 深色主题 tkinter 窗口
独立进程运行，避免与 Win32 悬浮球冲突
"""
import tkinter as tk
from tkinter import ttk
import os
import time
import threading
from pathlib import Path


# ── 深色主题配色 ──
COLORS = {
    "bg": "#1a1b26",
    "fg": "#a9b1d6",
    "accent": "#7aa2f7",
    "dim": "#565f89",
    "border": "#24283b",
    "entry_bg": "#24283b",
    "scrollbar": "#414868",
    "tag_info": "#9ece6a",
    "tag_warn": "#e0af68",
    "tag_crit": "#f7768e",
    "tag_reclaim": "#7dcfff",
    "tag_skip": "#ff9e64",
    "tag_guard": "#bb9af7",
    "tag_time": "#565f89",
    "title_bg": "#1f2335",
}

FONT_MONO = ("Consolas", 10)
FONT_TITLE = ("Microsoft YaHei UI", 11, "bold")
FONT_STATUS = ("Microsoft YaHei UI", 9)


class LogViewer:
    """实时日志查看器窗口"""

    def __init__(self, log_path: str, title: str = "MemGuard 日志"):
        self._log_path = log_path
        self._title = title
        self._running = False
        self._root = None
        self._text = None
        self._auto_scroll = True
        self._file_pos = 0
        self._status_var = None

    def run(self):
        """启动窗口（阻塞）"""
        self._root = tk.Tk()
        self._root.title(self._title)
        self._root.geometry("720x480")
        self._root.minsize(500, 300)
        self._root.configure(bg=COLORS["bg"])

        # 窗口图标（可选）
        try:
            self._root.iconbitmap(default="")
        except Exception:
            pass

        self._build_ui()
        self._apply_theme()

        self._running = True
        # 从文件末尾开始读
        self._init_file_pos()
        # 先加载最近 50 行
        self._load_tail(50)
        # 启动定时刷新
        self._schedule_refresh()

        self._root.protocol("WM_DELETE_WINDOW", self._on_close)
        self._root.mainloop()

    def _build_ui(self):
        """构建界面"""
        root = self._root

        # ── 顶部标题栏 ──
        top = tk.Frame(root, bg=COLORS["title_bg"], height=36)
        top.pack(fill=tk.X)
        top.pack_propagate(False)

        tk.Label(
            top, text="📋 " + self._title,
            font=FONT_TITLE, fg=COLORS["accent"],
            bg=COLORS["title_bg"],
        ).pack(side=tk.LEFT, padx=12, pady=6)

        self._status_var = tk.StringVar(value="实时监控中...")
        tk.Label(
            top, textvariable=self._status_var,
            font=FONT_STATUS, fg=COLORS["dim"],
            bg=COLORS["title_bg"],
        ).pack(side=tk.RIGHT, padx=12, pady=6)

        # ── 日志文本区 ──
        text_frame = tk.Frame(root, bg=COLORS["bg"])
        text_frame.pack(fill=tk.BOTH, expand=True, padx=8, pady=(4, 0))

        self._text = tk.Text(
            text_frame,
            wrap=tk.WORD,
            font=FONT_MONO,
            bg=COLORS["bg"],
            fg=COLORS["fg"],
            insertbackground=COLORS["accent"],
            selectbackground=COLORS["accent"],
            selectforeground="#ffffff",
            borderwidth=0,
            highlightthickness=0,
            padx=8, pady=6,
            state=tk.DISABLED,
        )

        scrollbar = ttk.Scrollbar(
            text_frame, orient=tk.VERTICAL,
            command=self._text.yview,
        )
        self._text.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self._text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # ── 底部控制栏 ──
        bottom = tk.Frame(root, bg=COLORS["border"], height=32)
        bottom.pack(fill=tk.X, padx=8, pady=(4, 8))
        bottom.pack_propagate(False)

        self._auto_var = tk.BooleanVar(value=True)
        cb = tk.Checkbutton(
            bottom, text="自动滚动",
            variable=self._auto_var,
            font=FONT_STATUS,
            fg=COLORS["fg"], bg=COLORS["border"],
            selectcolor=COLORS["entry_bg"],
            activebackground=COLORS["border"],
            activeforeground=COLORS["fg"],
            command=self._toggle_auto_scroll,
        )
        cb.pack(side=tk.LEFT, padx=8, pady=4)

        btn_clear = tk.Button(
            bottom, text="清屏",
            font=FONT_STATUS,
            fg=COLORS["fg"], bg=COLORS["entry_bg"],
            activebackground=COLORS["scrollbar"],
            activeforeground="#ffffff",
            borderwidth=0, padx=12, pady=2,
            command=self._clear,
        )
        btn_clear.pack(side=tk.RIGHT, padx=8, pady=4)

        btn_open = tk.Button(
            bottom, text="打开目录",
            font=FONT_STATUS,
            fg=COLORS["fg"], bg=COLORS["entry_bg"],
            activebackground=COLORS["scrollbar"],
            activeforeground="#ffffff",
            borderwidth=0, padx=12, pady=2,
            command=self._open_dir,
        )
        btn_open.pack(side=tk.RIGHT, padx=4, pady=4)

        # ── 文本标签（颜色高亮）──
        self._setup_tags()

    def _setup_tags(self):
        """配置文本颜色标签"""
        t = self._text
        t.tag_configure("time", foreground=COLORS["tag_time"])
        t.tag_configure("info", foreground=COLORS["tag_info"])
        t.tag_configure("warning", foreground=COLORS["tag_warn"])
        t.tag_configure("critical", foreground=COLORS["tag_crit"])
        t.tag_configure("reclaim", foreground=COLORS["tag_reclaim"])
        t.tag_configure("skip", foreground=COLORS["tag_skip"])
        t.tag_configure("guard", foreground=COLORS["tag_guard"])
        t.tag_configure("dim", foreground=COLORS["dim"])

    def _apply_theme(self):
        """应用深色主题到 ttk 组件"""
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(
            "Vertical.TScrollbar",
            background=COLORS["scrollbar"],
            troughcolor=COLORS["bg"],
            borderwidth=0,
            arrowsize=0,
        )

    def _init_file_pos(self):
        """初始化文件读取位置"""
        try:
            if os.path.exists(self._log_path):
                self._file_pos = os.path.getsize(self._log_path)
        except Exception:
            self._file_pos = 0

    def _load_tail(self, n=50):
        """加载文件末尾 n 行"""
        try:
            if not os.path.exists(self._log_path):
                self._append_line("等待日志生成...\n", "dim")
                return

            with open(self._log_path, "r", encoding="utf-8") as f:
                lines = f.readlines()

            tail = lines[-n:] if len(lines) > n else lines
            if tail:
                self._append_line(
                    f"── 最近 {len(tail)} 条日志 ──\n", "dim"
                )
                for line in tail:
                    self._append_colored(line)

            # 更新文件位置到末尾
            self._file_pos = os.path.getsize(self._log_path)
        except Exception as e:
            self._append_line(f"读取日志失败: {e}\n", "critical")

    def _schedule_refresh(self):
        """定时检查新日志"""
        if not self._running:
            return
        self._check_new_lines()
        self._root.after(1000, self._schedule_refresh)

    def _check_new_lines(self):
        """读取新增的日志行"""
        try:
            if not os.path.exists(self._log_path):
                return

            size = os.path.getsize(self._log_path)
            if size <= self._file_pos:
                if size < self._file_pos:
                    # 文件被截断（轮转），重置
                    self._file_pos = 0
                return

            with open(self._log_path, "r", encoding="utf-8") as f:
                f.seek(self._file_pos)
                new_lines = f.readlines()
                self._file_pos = f.tell()

            count = 0
            for line in new_lines:
                if line.strip():
                    self._append_colored(line)
                    count += 1

            if count > 0 and self._status_var:
                now = time.strftime("%H:%M:%S")
                self._status_var.set(f"最后更新: {now}")

        except Exception:
            pass

    def _append_colored(self, line: str):
        """根据内容添加带颜色的日志行"""
        line = line.rstrip("\n") + "\n"

        # 判断标签
        tag = "info"
        upper = line.upper()
        if "[CRITICAL]" in upper or "[EMERGENCY]" in upper:
            tag = "critical"
        elif "[WARNING]" in upper:
            tag = "warning"
        elif "[RECLAIM" in upper:
            tag = "reclaim"
        elif "[SKIP]" in upper:
            tag = "skip"
        elif "[GUARD]" in upper:
            tag = "guard"
        elif "[INFO]" in upper:
            tag = "info"
        elif "[DEBUG]" in upper:
            tag = "dim"

        self._append_line(line, tag)

    def _append_line(self, text: str, tag: str = "info"):
        """追加一行文本"""
        t = self._text
        t.configure(state=tk.NORMAL)
        t.insert(tk.END, text, tag)

        # 限制最大行数（防止内存膨胀）
        line_count = int(t.index("end-1c").split(".")[0])
        if line_count > 2000:
            t.delete("1.0", f"{line_count - 1500}.0")

        t.configure(state=tk.DISABLED)

        if self._auto_scroll:
            t.see(tk.END)

    def _toggle_auto_scroll(self):
        self._auto_scroll = self._auto_var.get()
        if self._auto_scroll:
            self._text.see(tk.END)

    def _clear(self):
        self._text.configure(state=tk.NORMAL)
        self._text.delete("1.0", tk.END)
        self._text.configure(state=tk.DISABLED)

    def _open_dir(self):
        """打开日志所在目录"""
        import subprocess
        d = str(Path(self._log_path).parent)
        try:
            subprocess.Popen(["explorer", d])
        except Exception:
            pass

    def _on_close(self):
        self._running = False
        self._root.destroy()


def main():
    """独立进程入口"""
    import sys
    if len(sys.argv) < 2:
        log_path = str(
            Path.home() / ".opencode-mem-guard" / "data" / "logs" / "monitor.log"
        )
    else:
        log_path = sys.argv[1]

    viewer = LogViewer(log_path)
    viewer.run()


if __name__ == "__main__":
    main()
