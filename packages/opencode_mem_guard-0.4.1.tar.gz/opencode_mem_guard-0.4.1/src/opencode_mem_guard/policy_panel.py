"""应用自动清理策略面板。"""

from __future__ import annotations

import argparse
import tkinter as tk
from pathlib import Path
from tkinter import ttk

import psutil

from .config import GovernanceConfig, load_governance_config, save_governance_config


class PolicyPanel:
    def __init__(self, policy_file: str):
        self.policy_file = str(Path(policy_file).expanduser())
        self.cfg: GovernanceConfig = load_governance_config(self.policy_file)
        self.apps = []

        self.root = tk.Tk()
        self.root.title("应用自动清理策略")
        self.root.geometry("700x640")
        self.root.minsize(620, 520)

        self._build_ui()
        self.refresh_apps()

    def _build_ui(self) -> None:
        header = ttk.Frame(self.root)
        header.pack(fill="x", padx=12, pady=(10, 6))

        ttk.Label(header, text="已监测应用（点击右侧按钮切换自动清理）").pack(side="left")

        self.summary_var = tk.StringVar(value="")
        ttk.Label(header, textvariable=self.summary_var).pack(side="right")

        btn_row = ttk.Frame(self.root)
        btn_row.pack(fill="x", padx=12, pady=(0, 8))
        ttk.Button(btn_row, text="刷新列表", command=self.refresh_apps).pack(side="left")
        ttk.Button(btn_row, text="关闭", command=self.root.destroy).pack(side="right")

        container = ttk.Frame(self.root)
        container.pack(fill="both", expand=True, padx=12, pady=8)

        self.canvas = tk.Canvas(container, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(container, orient="vertical", command=self.canvas.yview)
        self.list_frame = ttk.Frame(self.canvas)

        self.list_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")),
        )
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        self.canvas.create_window((0, 0), window=self.list_frame, anchor="nw")

        tip = "说明: 点击按钮可切换该应用是否允许自动清理。关键系统进程不会出现在列表中。"
        ttk.Label(self.root, text=tip, foreground="#666666").pack(fill="x", padx=12, pady=(0, 10))

    def _collect_runtime_apps(self):
        critical = set(self.cfg.critical_process_names)
        memory_map = {}

        for proc in psutil.process_iter(["name", "memory_info"]):
            try:
                name = (proc.info.get("name") or "").lower()
                if not name or name in critical:
                    continue

                mem = proc.info.get("memory_info")
                if mem is None:
                    continue
                ram_mb = round(mem.rss / 1048576, 1)

                prev = memory_map.get(name, 0.0)
                if ram_mb > prev:
                    memory_map[name] = ram_mb
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

        for name in self.cfg.enforce_whitelist_names:
            memory_map.setdefault(name, 0.0)
        for name in self.cfg.protected_names:
            memory_map.setdefault(name, 0.0)

        rows = sorted(memory_map.items(), key=lambda x: (-x[1], x[0]))
        return rows[:40]

    def _is_enabled(self, app_name: str) -> bool:
        in_white = app_name in self.cfg.enforce_whitelist_names
        in_black = app_name in self.cfg.protected_names
        return in_white and not in_black

    def _toggle_app(self, app_name: str) -> None:
        enabled = self._is_enabled(app_name)

        if enabled:
            self.cfg.enforce_whitelist_names = [
                x for x in self.cfg.enforce_whitelist_names if x != app_name
            ]
            if app_name not in self.cfg.protected_names:
                self.cfg.protected_names.append(app_name)
        else:
            if app_name not in self.cfg.enforce_whitelist_names:
                self.cfg.enforce_whitelist_names.append(app_name)
            self.cfg.protected_names = [x for x in self.cfg.protected_names if x != app_name]

        self.cfg.normalize()
        save_governance_config(self.cfg, self.policy_file)
        self.refresh_apps()

    def _render_rows(self) -> None:
        for child in self.list_frame.winfo_children():
            child.destroy()

        header = ttk.Frame(self.list_frame)
        header.pack(fill="x", pady=(0, 6))
        ttk.Label(header, text="应用", width=34).pack(side="left", padx=(6, 0))
        ttk.Label(header, text="内存(MB)", width=10).pack(side="left")
        ttk.Label(header, text="自动清理", width=14).pack(side="left")

        for name, ram_mb in self.apps:
            row = ttk.Frame(self.list_frame)
            row.pack(fill="x", pady=2)

            show_name = name if len(name) <= 36 else f"{name[:33]}..."
            ttk.Label(row, text=show_name, width=34).pack(side="left", padx=(6, 0), anchor="w")
            ttk.Label(row, text=f"{ram_mb:.1f}", width=10).pack(side="left")

            enabled = self._is_enabled(name)
            btn_text = "允许" if enabled else "不允许"
            ttk.Button(
                row,
                text=btn_text,
                command=lambda app=name: self._toggle_app(app),
                width=10,
            ).pack(side="left", padx=6)

    def refresh_apps(self) -> None:
        self.cfg = load_governance_config(self.policy_file)
        self.apps = self._collect_runtime_apps()
        allowed_count = len(self.cfg.enforce_whitelist_names)
        denied_count = len(self.cfg.protected_names)
        self.summary_var.set(f"允许自动清理 {allowed_count} | 不允许自动清理 {denied_count}")
        self._render_rows()

    def run(self) -> None:
        self.root.mainloop()


def main() -> None:
    parser = argparse.ArgumentParser(description="OpenCode MemGuard 策略面板")
    parser.add_argument("--policy-file", type=str, default="", help="策略文件路径")
    args = parser.parse_args()

    panel = PolicyPanel(args.policy_file)
    panel.run()


if __name__ == "__main__":
    main()
