"""治理模式文案映射。"""

DECISION_STATE_LABELS = {
    "observe": "只监不清",
    "warn": "预警观察",
    "enforce": "自动回收",
}


def decision_state_label(state: str) -> str:
    return DECISION_STATE_LABELS.get((state or "").lower(), "未知模式")
