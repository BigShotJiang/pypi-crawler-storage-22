'''Various checks for making sure a user can or can't run docker

Uses:
from opencos.utils.docker_checks import docker_ok

if docker_ok():
  # do docker stuff
else
  # print messages saying can't do docker stuff, fail
'''

from importlib import import_module
import os
from pathlib import Path
import shutil
import subprocess
import sys

from opencos import __version__ as opencos_version
from opencos.util import debug, warning
from opencos.utils.str_helpers import strip_outer_quotes
from opencos.utils.subprocess_helpers import IS_LINUX, IS_MACOS, IS_WINDOWS

DOCKER_EXE = shutil.which('docker')
DOCKER_GROUP = 'docker'

_DOCKER_VERSION = ''
_DOCKER_OK = None
_CAN_RUN_DOCKER_WITHOUT_SUDO = None


grp = None # pylint: disable=invalid-name
if IS_LINUX:
    grp = import_module('grp') # pylint: disable=invalid-name


def get_error_str_cant_run_docker() -> str:
    '''Returns a somewhat O/S specific messsage about you couldn't run docker'''

    is_installed = bool(DOCKER_EXE)
    if not is_installed:
        return (
            'Current user cannot run docker, it does not appear to be installed or is not in PATH'
        )
    if not not_in_docker_already():
        return (
            'Current user cannot run docker, it appears we are already in a docker ENV'
            ' (./dockerenv exists). Docker-in-docker is not yet supported within opencos-eda.'
        )
    if IS_LINUX:
        return (
            'Current user cannot run docker! (user is not a member of',
            ' docker group, or requires sudo to run docker).'
        )
    if IS_MACOS:
        return (
            'Current macos user cannot run docker! (user may not have Docker Desktop'
            ' running, it needs to be. Also check if user can run docker without sudo.)'
        )
    if IS_WINDOWS:
        return (
            'Current windows user cannot run docker! (This may not be correctly implemented'
            f' for windows in opencos-eda version: {opencos_version})'
        )
    return (
        'Current user cannot run docker! (unknown operating system, not supported in'
        f' opencos-eda version: {opencos_version} -- platform: {sys.platform})'
    )


def is_docker_installed() -> bool:
    '''Checks if DOCKER_EXE is non-blank'''
    return bool(DOCKER_EXE)

def not_in_docker_already() -> bool:
    '''Returns True if we're not in docker (False if we are in docker).

    We do not yet support DinD situations, so if we are already in docker,
    make sure docker_ok() returns overall False.
    '''
    return not Path('/.dockerenv').exists()


def get_docker_version() -> str:
    '''Returns docker version (or blank str if not installed) and sets global _DOCKER_VERSION'''
    global _DOCKER_VERSION # pylint: disable=global-statement
    if _DOCKER_VERSION:
        return _DOCKER_VERSION
    if not is_docker_installed():
        return ''

    version_ret = subprocess.run(
        [DOCKER_EXE, '--version'],
        capture_output=True,
        check=False
    )
    # Docker version 29.2.0, build 0b9d198
    stdout = version_ret.stdout.decode('utf-8', errors='replace')
    debug(f'{DOCKER_EXE=} {version_ret=}')
    words = stdout.split()
    if len(words) < 1:
        warning(
            f'{DOCKER_EXE} --version: returned unexpected string {version_ret=}'
        )
    _DOCKER_VERSION = words[2].rstrip(',')
    return _DOCKER_VERSION


def can_run_docker_without_sudo() -> bool:
    '''Checks if the user can run 'docker' with sudo

    Note this command is slow until it has been run and cached.
    '''
    global _CAN_RUN_DOCKER_WITHOUT_SUDO # pylint: disable=global-statement
    if _CAN_RUN_DOCKER_WITHOUT_SUDO is not None:
        return _CAN_RUN_DOCKER_WITHOUT_SUDO
    if not is_docker_installed():
        _CAN_RUN_DOCKER_WITHOUT_SUDO = False

    else:
        try:
            # 'docker info' requires connection to the daemon
            # Using check_call ensures we catch non-zero exit codes
            subprocess.check_call([DOCKER_EXE, 'info'],
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
            _CAN_RUN_DOCKER_WITHOUT_SUDO = True
        except (subprocess.CalledProcessError, FileNotFoundError):
            _CAN_RUN_DOCKER_WITHOUT_SUDO = False

    return _CAN_RUN_DOCKER_WITHOUT_SUDO


def is_in_docker_group_or_non_linux() -> bool:
    '''Checks if the user is in a group named 'docker'.

    Note this applies to Linux-only. Macos supports groups but they don't need
    docker group for Docker Desktop'''
    if not IS_LINUX:
        return True
    if not grp:
        return False
    try:
        docker_gid = grp.getgrnam(DOCKER_GROUP).gr_gid
        return docker_gid in os.getgroups()
    except KeyError:
        # Group 'docker' doesn't even exist on this system
        return False


def is_docker_ok_windows() -> bool:
    '''Checks for docker support in Windows'''
    if not IS_WINDOWS:
        return True

    return False


def docker_ok() -> bool:
    '''Sets DOCKER_OK to True/False if unset, returns _DOCKER_OK'''
    global _DOCKER_OK # pylint: disable=global-statement
    if _DOCKER_OK is None:
        _DOCKER_OK = all(
            (
                is_docker_installed(),
                not_in_docker_already(),
                get_docker_version(),
                can_run_docker_without_sudo(),
                is_in_docker_group_or_non_linux(),
                is_docker_ok_windows(),
            )
        )
    return _DOCKER_OK


def get_docker_run_command( # pylint: disable=dangerous-default-value
        image: str,
        docker_command: str = 'run', # or 'exec'
        user: str = '$(id -u):$(id -g)',
        env_dict: dict = {},
        ro_volumes: list = [],
        rw_volumes: list = [],
        entrypoint: str = '/bin/bash',
        commands: list = []
) -> list:
    '''Returns list (suitable for subprocess) of: docker run ... or docker exec ...'''

    # TODO(drew): this likely needs tweaks to 'user' str for Windows
    ret = [
        'docker', docker_command, '--rm'
    ]
    if user:
        ret.extend([
            '--user', user
        ])
    for k,v in env_dict.items():
        ret.extend(['-e', f'"{strip_outer_quotes(k)}={strip_outer_quotes(v)}"'])
    for v in ro_volumes:
        assert isinstance(v, (str, Path, tuple)), f'{type(v)=} {v=} must be Path|str|tuple'
        if isinstance(v, tuple):
            assert len(v) == 2, f'Need src, dst in ro_volumes entry {v}'
            ret.extend(['-v', f'{v[0]}:{v[1]}:ro'])
        else:
            ret.extend(['-v', f'{v}:{v}:ro'])
    for v in rw_volumes:
        assert isinstance(v, (str, Path, tuple)), f'{type(v)=} {v=} must be Path|str|tuple'
        if isinstance(v, tuple):
            assert len(v) == 2, f'Need src, dst in rw_volumes entry {v}'
            ret.extend(['-v', f'{v[0]}:{v[1]}:rw'])
        else:
            ret.extend(['-v', f'{v}:{v}:rw'])

    if entrypoint:
        ret.extend([
            '--entrypoint', entrypoint
        ])

    assert image, f'docker {image=} is missing, must set'
    ret.append(image)

    if commands:
        ret.extend(commands)

    return ret
