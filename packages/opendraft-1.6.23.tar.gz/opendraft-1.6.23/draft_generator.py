#!/usr/bin/env python3
"""
ABOUTME: Orchestrator for the draft generation pipeline
ABOUTME: Coordinates phase modules under engine/phases/ for production use

This module provides the public generate_draft() function that orchestrates
the full pipeline: Research -> Structure -> Citations -> Compose -> Validate -> Compile.

Output Structure:
    draft_output/
    ├── research/           # All research materials
    │   ├── papers/         # Individual paper summaries
    │   ├── combined_research.md
    │   ├── research_gaps.md
    │   └── bibliography.json
    ├── drafts/             # Section drafts
    ├── tools/              # Refinement prompts for Cursor
    └── exports/            # Final outputs (PDF, DOCX, MD)
"""

import sys
import warnings

# Suppress deprecation warnings from dependencies before any imports
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)

import time
import shutil
import json
from pathlib import Path
import re
import logging
import traceback
import psutil
import os
from typing import Tuple, Optional, List, Dict
from datetime import datetime

# Suppress WeasyPrint stderr warnings
os.environ['WEASYPRINT_QUIET'] = '1'

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

import google.generativeai as genai
from config import get_config
from utils.structured_logger import StructuredLogger
from utils.agent_runner import setup_model

# Phase imports
from phases import (
    DraftContext,
    run_research_phase,
    run_structure_phase,
    run_citation_management,
    run_compose_phase,
    run_validate_phase,
    run_compile_and_export,
    run_expose_export,
)
from phases.context import PhaseValidationError, validate_phase_output

# Configure comprehensive logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(name)-30s | %(levelname)-8s | %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)


# =============================================================================
# GENERAL UTILITIES (stay in orchestrator)
# =============================================================================

def log_memory_usage(context=""):
    """Log current memory usage"""
    process = psutil.Process(os.getpid())
    mem_info = process.memory_info()
    mem_mb = mem_info.rss / 1024 / 1024
    logger.info(f"[MEMORY] {context}: {mem_mb:.1f} MB RSS")
    return mem_mb


def log_timing(func):
    """Decorator to log function execution time"""
    def wrapper(*args, **kwargs):
        start_time = time.time()
        func_name = func.__name__
        logger.info(f"[START] {func_name}")
        log_memory_usage(f"Before {func_name}")
        try:
            result = func(*args, **kwargs)
            elapsed = time.time() - start_time
            logger.info(f"[COMPLETE] {func_name} in {elapsed:.1f}s")
            log_memory_usage(f"After {func_name}")
            return result
        except Exception as e:
            elapsed = time.time() - start_time
            logger.error(f"[FAILED] {func_name} after {elapsed:.1f}s: {e}")
            logger.error(f"[TRACEBACK] {traceback.format_exc()}")
            raise
    return wrapper


def slugify(text: str, max_length: int = 30) -> str:
    """Convert text to a safe filename slug."""
    slug = re.sub(r'[^\w\s-]', '', text.lower())
    slug = re.sub(r'[\s_]+', '_', slug).strip('_')
    return slug[:max_length]


# =============================================================================
# LOCALIZATION: Chapter and section names in different languages
# =============================================================================
CHAPTER_NAMES = {
    'en': {
        'introduction': 'Introduction',
        'literature_review': 'Literature Review',
        'methodology': 'Methodology',
        'results': 'Results and Analysis',
        'discussion': 'Discussion',
        'conclusion': 'Conclusion',
        'references': 'References',
        'appendix': 'Appendix',
    },
    'de': {
        'introduction': 'Einleitung',
        'literature_review': 'Literaturübersicht',
        'methodology': 'Methodik',
        'results': 'Ergebnisse und Analyse',
        'discussion': 'Diskussion',
        'conclusion': 'Fazit',
        'references': 'Literaturverzeichnis',
        'appendix': 'Anhang',
    },
    'es': {
        'introduction': 'Introducción',
        'literature_review': 'Revisión de la Literatura',
        'methodology': 'Metodología',
        'results': 'Resultados y Análisis',
        'discussion': 'Discusión',
        'conclusion': 'Conclusión',
        'references': 'Referencias',
        'appendix': 'Apéndice',
    },
    'fr': {
        'introduction': 'Introduction',
        'literature_review': 'Revue de la Littérature',
        'methodology': 'Méthodologie',
        'results': 'Résultats et Analyse',
        'discussion': 'Discussion',
        'conclusion': 'Conclusion',
        'references': 'Références',
        'appendix': 'Annexe',
    },
    'it': {
        'introduction': 'Introduzione',
        'literature_review': 'Revisione della Letteratura',
        'methodology': 'Metodologia',
        'results': 'Risultati e Analisi',
        'discussion': 'Discussione',
        'conclusion': 'Conclusione',
        'references': 'Riferimenti',
        'appendix': 'Appendice',
    },
    'pt': {
        'introduction': 'Introdução',
        'literature_review': 'Revisão da Literatura',
        'methodology': 'Metodologia',
        'results': 'Resultados e Análise',
        'discussion': 'Discussão',
        'conclusion': 'Conclusão',
        'references': 'Referências',
        'appendix': 'Apêndice',
    },
}


def get_chapter_name(chapter_key: str, language: str = 'en') -> str:
    """
    Get localized chapter name.

    Args:
        chapter_key: Key like 'introduction', 'conclusion', etc.
        language: Language code ('en', 'de', 'es', 'fr', 'it', 'pt')

    Returns:
        Localized chapter name, or English fallback if not found
    """
    lang = language.split('-')[0].lower() if language else 'en'
    lang_dict = CHAPTER_NAMES.get(lang, CHAPTER_NAMES['en'])
    return lang_dict.get(chapter_key, CHAPTER_NAMES['en'].get(chapter_key, chapter_key.replace('_', ' ').title()))


def setup_output_folders(output_dir: Path) -> Dict[str, Path]:
    """
    Create the organized folder structure for draft output.

    Returns dict with paths to all subdirectories.
    """
    folders = {
        'root': output_dir,
        'research': output_dir / 'research',
        'papers': output_dir / 'research' / 'papers',
        'drafts': output_dir / 'drafts',
        'tools': output_dir / 'tools',
        'exports': output_dir / 'exports',
    }

    for folder in folders.values():
        folder.mkdir(parents=True, exist_ok=True)

    return folders


def get_language_name(language_code: str) -> str:
    """
    Convert language code to full language name for prompts and formatting.

    Args:
        language_code: ISO 639-1 language code (e.g., 'en-US', 'en-GB', 'es', 'fr')

    Returns:
        Full language name (e.g., 'American English', 'British English', 'Spanish', 'French')
    """
    language_map = {
        'en': 'English', 'en-US': 'American English', 'en-GB': 'British English',
        'en-AU': 'Australian English', 'en-CA': 'Canadian English',
        'en-NZ': 'New Zealand English', 'en-IE': 'Irish English',
        'en-ZA': 'South African English',
        'de': 'German', 'de-DE': 'German (Germany)', 'de-AT': 'German (Austria)',
        'de-CH': 'German (Switzerland)',
        'es': 'Spanish', 'es-ES': 'Spanish (Spain)', 'es-MX': 'Spanish (Mexico)',
        'es-AR': 'Spanish (Argentina)',
        'fr': 'French', 'fr-FR': 'French (France)', 'fr-CA': 'French (Canada)',
        'fr-BE': 'French (Belgium)',
        'it': 'Italian',
        'pt': 'Portuguese', 'pt-BR': 'Portuguese (Brazil)', 'pt-PT': 'Portuguese (Portugal)',
        'nl': 'Dutch', 'nl-NL': 'Dutch (Netherlands)', 'nl-BE': 'Dutch (Belgium)',
        'ru': 'Russian',
        'zh': 'Chinese', 'zh-CN': 'Chinese (Simplified)', 'zh-TW': 'Chinese (Traditional)',
        'ja': 'Japanese', 'ko': 'Korean', 'ar': 'Arabic', 'hi': 'Hindi',
        'sv': 'Swedish', 'no': 'Norwegian', 'da': 'Danish', 'fi': 'Finnish',
        'pl': 'Polish', 'cs': 'Czech', 'tr': 'Turkish', 'he': 'Hebrew',
        'th': 'Thai', 'vi': 'Vietnamese', 'id': 'Indonesian', 'ms': 'Malay',
        'uk': 'Ukrainian', 'ro': 'Romanian', 'hu': 'Hungarian', 'el': 'Greek',
        'bg': 'Bulgarian', 'hr': 'Croatian', 'sk': 'Slovak', 'sl': 'Slovenian',
        'et': 'Estonian', 'lv': 'Latvian', 'lt': 'Lithuanian',
    }
    return language_map.get(language_code, language_code.upper())


def get_word_count_targets(academic_level: str) -> dict:
    """
    Get word count targets for each section based on academic level.

    Args:
        academic_level: 'bachelor', 'master', 'phd', or 'research_paper'

    Returns:
        Dictionary with word count targets for each section, plus citation/time estimates
    """
    targets = {
        'research_paper': {
            'total': '3,000-5,000',
            'introduction': '600-800',
            'literature_review': '800-1,200',
            'methodology': '600-800',
            'results': '800-1,200',
            'discussion': '600-800',
            'conclusion': '400-600',
            'appendices': '0',
            'chapters': '3-4',
            'min_citations': 10,
            'deep_research_min_sources': 20,
            'estimated_time_minutes': '5-10',
        },
        'bachelor': {
            'total': '10,000-15,000',
            'introduction': '1,500-2,000',
            'literature_review': '3,000-4,000',
            'methodology': '1,500-2,000',
            'results': '2,500-3,500',
            'discussion': '1,500-2,000',
            'conclusion': '800-1,200',
            'appendices': '500-1,000',
            'chapters': '5-7',
            'min_citations': 15,
            'deep_research_min_sources': 40,
            'estimated_time_minutes': '8-15',
        },
        'master': {
            'total': '25,000-30,000',
            'introduction': '2,500-3,000',
            'literature_review': '6,000-7,000',
            'methodology': '3,000-3,500',
            'results': '6,000-7,000',
            'discussion': '3,000-3,500',
            'conclusion': '1,500-2,000',
            'appendices': '2,000-3,000',
            'chapters': '7-10',
            'min_citations': 25,
            'deep_research_min_sources': 50,
            'estimated_time_minutes': '10-25',
        },
        'phd': {
            'total': '50,000-80,000',
            'introduction': '4,000-5,000',
            'literature_review': '12,000-15,000',
            'methodology': '6,000-8,000',
            'results': '12,000-15,000',
            'discussion': '8,000-10,000',
            'conclusion': '3,000-4,000',
            'appendices': '5,000-8,000',
            'chapters': '10-15',
            'min_citations': 50,
            'deep_research_min_sources': 100,
            'estimated_time_minutes': '20-40',
        },
    }
    return targets.get(academic_level, targets['master'])


def copy_tools_to_output(tools_dir: Path, topic: str, academic_level: str, verbose: bool = True):
    """Copy refinement prompts and create .cursorrules for the output folder."""
    project_root = Path(__file__).parent.parent

    voice_src = project_root / 'prompts' / '05_refine' / 'voice.md'
    if voice_src.exists():
        shutil.copy(voice_src, tools_dir / 'humanizer_prompt.md')

    entropy_src = project_root / 'prompts' / '05_refine' / 'entropy.md'
    if entropy_src.exists():
        shutil.copy(entropy_src, tools_dir / 'entropy_prompt.md')

    style_src = project_root / 'templates' / 'style_guide.md'
    if style_src.exists():
        shutil.copy(style_src, tools_dir / 'style_guide.md')

    cursorrules_template = project_root / 'templates' / 'cursorrules.md'
    if cursorrules_template.exists():
        content = cursorrules_template.read_text(encoding='utf-8')
        content = content.replace('{topic}', topic)
        content = content.replace('{academic_level}', academic_level)
        (tools_dir / '.cursorrules').write_text(content, encoding='utf-8')

    if verbose:
        print("   \u2705 Copied refinement tools to output")


def create_output_readme(output_dir: Path, topic: str, verbose: bool = True):
    """Create README.md and CLAUDE.md for the output folder."""
    project_root = Path(__file__).parent.parent
    readme_template = project_root / 'templates' / 'draft_readme.md'
    claude_template = project_root / 'templates' / 'claude.md'

    if readme_template.exists():
        shutil.copy(readme_template, output_dir / 'README.md')
        if verbose:
            print("   \u2705 Created README.md")

    if claude_template.exists():
        shutil.copy(claude_template, output_dir / 'CLAUDE.md')
        if verbose:
            print("   \u2705 Created CLAUDE.md")


# =============================================================================
# MAIN ORCHESTRATOR
# =============================================================================

def generate_draft(
    topic: str,
    language: str = "en",
    academic_level: str = "master",
    output_dir: Optional[Path] = None,
    skip_validation: bool = True,
    verbose: bool = True,
    tracker=None,
    streamer=None,
    blurb: Optional[str] = None,
    output_type: str = "full",
    author_name: Optional[str] = None,
    institution: Optional[str] = None,
    department: Optional[str] = None,
    faculty: Optional[str] = None,
    advisor: Optional[str] = None,
    second_examiner: Optional[str] = None,
    location: Optional[str] = None,
    student_id: Optional[str] = None,
    citation_style: str = "apa",
) -> Tuple[Path, Path]:
    """
    Generate a complete academic draft using specialized AI agents.

    This is a simplified, production-ready version of the test workflow,
    optimized for automated processing on Modal.com or similar platforms.

    Args:
        topic: Draft topic (e.g., "Machine Learning for Climate Prediction")
        language: Draft language code (e.g., 'en-US', 'en-GB', 'de', 'es', 'fr', etc.)
        academic_level: 'bachelor', 'master', or 'phd'
        output_dir: Custom output directory (default: config.paths.output_dir / "generated_draft")
        skip_validation: Skip strict quality gates (recommended for automated runs)
        verbose: Print progress messages
        output_type: 'full' for complete draft, 'expose' for research overview only
        author_name: Student's full name (for cover page)
        institution: University/institution name
        department: Department name
        faculty: Faculty name
        advisor: First examiner/advisor name
        second_examiner: Second examiner name
        location: City/location for date line
        student_id: Student matriculation number
        citation_style: Citation format - 'apa' or 'ieee' (default: 'apa')

    Returns:
        Tuple[Path, Path]: (pdf_path, docx_path) - Paths to generated draft files

    Raises:
        ValueError: If insufficient citations found or generation fails
        Exception: If any critical step fails
    """
    # ====================================================================
    # STARTUP AND INITIALIZATION
    # ====================================================================
    draft_start_time = time.time()
    logger.info("=" * 80)
    logger.info("DRAFT GENERATION STARTED")
    logger.info("=" * 80)
    logger.info(f"Topic: {topic}")
    logger.info(f"Language: {language}")
    logger.info(f"Academic Level: {academic_level}")
    logger.info(f"Output Type: {output_type}")
    logger.info(f"Validation: {'Skipped' if skip_validation else 'Enabled'}")
    logger.info(f"Tracker: {'Enabled' if tracker else 'Disabled'}")
    logger.info(f"Streamer: {'Enabled' if streamer else 'Disabled'}")
    if author_name:
        logger.info(f"Author: {author_name}")
    if institution:
        logger.info(f"Institution: {institution}")
    logger.info(f"Process PID: {os.getpid()}")
    logger.info(f"Python: {sys.version}")
    log_memory_usage("Initial")
    logger.info("=" * 80)

    # Immediate progress update
    if tracker:
        tracker.log_activity("🚀 Generation started", event_type="milestone", phase="research")
        tracker.update_phase("research", progress_percent=1, details={"stage": "initializing"})

    try:
        config = get_config()

        # Check CLI quiet mode
        from utils.api_citations.orchestrator import _verbose_research
        cli_quiet_mode = not _verbose_research

        if verbose and not cli_quiet_mode:
            print("=" * 70)
            print("DRAFT GENERATION - AUTOMATED WORKFLOW")
            print("=" * 70)
            print(f"Topic: {topic}")
            print(f"Language: {language}")
            print(f"Level: {academic_level}")
            print(f"Validation: {'Skipped' if skip_validation else 'Enabled'}")
            print("=" * 70)

        # Setup model
        logger.info("[SETUP] Initializing Gemini model...")
        if tracker:
            tracker.log_activity("🤖 Loading AI model...", event_type="info", phase="research")

        model = setup_model()
        logger.info("[SETUP] Model initialized successfully")

        if tracker:
            tracker.log_activity("\u2705 AI model ready", event_type="found", phase="research")
            tracker.update_phase("research", progress_percent=3, details={"stage": "model_loaded"})

        if output_dir is None:
            output_dir = config.paths.output_dir / "generated_draft"

        logger.info(f"[SETUP] Output directory: {output_dir}")

        folders = setup_output_folders(output_dir)
        logger.info(f"[SETUP] Created folders: {', '.join(folders.keys())}")

        if verbose and not cli_quiet_mode:
            print(f"📁 Output folder: {output_dir}")

        # Prepare word targets and language
        word_targets = get_word_count_targets(academic_level)
        language_name = get_language_name(language)
        language_instruction = f"\n\n**LANGUAGE REQUIREMENT:** Write the ENTIRE output in {language_name}. All text, headings, and content must be in {language_name}."

        # ====================================================================
        # Initialize DraftContext
        # ====================================================================
        ctx = DraftContext(
            topic=topic,
            language=language,
            academic_level=academic_level,
            output_type=output_type,
            citation_style=citation_style,
            skip_validation=skip_validation,
            verbose=verbose,
            blurb=blurb,
            author_name=author_name,
            institution=institution,
            department=department,
            faculty=faculty,
            advisor=advisor,
            second_examiner=second_examiner,
            location=location,
            student_id=student_id,
            config=config,
            model=model,
            folders=folders,
            word_targets=word_targets,
            language_name=language_name,
            language_instruction=language_instruction,
            tracker=tracker,
            streamer=streamer,
        )

        # Optional token tracker
        try:
            from utils.token_tracker import TokenTracker
            model_name = config.model.model_name
            ctx.token_tracker = TokenTracker(model_name=model_name)
            logger.info(f"[SETUP] TokenTracker initialized for {model_name}")
        except Exception as e:
            logger.debug(f"[SETUP] TokenTracker not available: {e}")
            ctx.token_tracker = None

        # ====================================================================
        # Execute pipeline phases
        # ====================================================================
        run_research_phase(ctx)

        # Validate research phase outputs before structure
        validate_phase_output(
            ctx,
            phase_name="research",
            required_fields=["scout_result", "scout_output", "scribe_output"],
            min_chars={"scout_output": 100, "scribe_output": 100},
        )
        logger.info("[VALIDATION] Research phase outputs validated")

        run_structure_phase(ctx)

        # Validate structure phase outputs before citations
        validate_phase_output(
            ctx,
            phase_name="structure",
            required_fields=["architect_output", "formatter_output"],
            min_chars={"formatter_output": 50},
        )
        logger.info("[VALIDATION] Structure phase outputs validated")

        run_citation_management(ctx)

        # Validate citation management outputs
        validate_phase_output(
            ctx,
            phase_name="citation_management",
            required_fields=["citation_database"],
        )
        if ctx.citation_database and len(ctx.citation_database.citations) == 0:
            raise PhaseValidationError(
                phase="citation_management",
                message="No citations in database after citation management",
            )
        logger.info(f"[VALIDATION] Citation management validated: {len(ctx.citation_database.citations)} citations")

        if ctx.output_type == 'expose':
            pdf_path, docx_path = run_expose_export(ctx)
            _finalize(ctx, pdf_path, docx_path, draft_start_time)
            return pdf_path, docx_path

        run_compose_phase(ctx)

        # Validate compose phase outputs before validation
        validate_phase_output(
            ctx,
            phase_name="compose",
            required_fields=["intro_output", "body_output", "conclusion_output"],
            min_chars={"intro_output": 200, "body_output": 500, "conclusion_output": 100},
        )
        logger.info("[VALIDATION] Compose phase outputs validated")
        run_validate_phase(ctx)

        # Copy tools and README
        copy_tools_to_output(folders['tools'], topic, academic_level, verbose)
        create_output_readme(output_dir, topic, verbose)

        pdf_path, docx_path = run_compile_and_export(ctx)

        _finalize(ctx, pdf_path, docx_path, draft_start_time)
        return pdf_path, docx_path

    except Exception as e:
        draft_total_time = time.time() - draft_start_time
        logger.error("=" * 80)
        logger.error("DRAFT GENERATION FAILED!")
        logger.error("=" * 80)
        logger.error(f"Failed after {draft_total_time:.1f}s ({draft_total_time/60:.1f} minutes)")
        logger.error(f"Error: {e}")
        logger.error(f"Error type: {type(e).__name__}")
        logger.error("=" * 80)
        logger.error("FULL TRACEBACK:")
        logger.error(traceback.format_exc())
        logger.error("=" * 80)
        log_memory_usage("At failure")

        if tracker:
            try:
                tracker.mark_failed(f"{type(e).__name__}: {str(e)[:200]}")
            except Exception as tracker_error:
                logger.error(f"Failed to update tracker: {tracker_error}")

        raise


def _finalize(ctx: DraftContext, pdf_path: Path, docx_path: Path, draft_start_time: float) -> None:
    """Print final report, save token usage, mark tracker complete."""
    # Token usage report
    if ctx.token_tracker:
        ctx.token_tracker.print_report()
        try:
            token_json_path = ctx.folders['root'] / "token_usage.json"
            token_json_path.write_text(ctx.token_tracker.to_json(), encoding='utf-8')
            logger.info(f"Token usage saved to {token_json_path}")
        except Exception as e:
            logger.warning(f"Failed to save token usage: {e}")

    if ctx.tracker:
        ctx.tracker.mark_completed()

    if ctx.verbose:
        print("=" * 70)
        print("\u2705 DRAFT GENERATION COMPLETE")
        print("=" * 70)
        print(f"\u2705 Exported PDF: {pdf_path}")
        print(f"\u2705 Exported DOCX: {docx_path}")
        print(f"📂 Output folder: {ctx.folders['root']}")
        print("\n💡 Open the folder in Cursor to refine your draft!")
        print(f"   cursor {ctx.folders['root']}")

    draft_total_time = time.time() - draft_start_time
    logger.info("=" * 80)
    logger.info("DRAFT GENERATION COMPLETE!")
    logger.info("=" * 80)
    logger.info(f"Total time: {draft_total_time:.1f}s ({draft_total_time/60:.1f} minutes)")
    logger.info(f"PDF: {pdf_path}")
    logger.info(f"DOCX: {docx_path}")
    if pdf_path.exists():
        logger.info(f"PDF size: {pdf_path.stat().st_size:,} bytes ({pdf_path.stat().st_size/1024/1024:.1f} MB)")
    if docx_path.exists():
        logger.info(f"DOCX size: {docx_path.stat().st_size:,} bytes ({docx_path.stat().st_size/1024/1024:.1f} MB)")
    log_memory_usage("Final")
    logger.info("=" * 80)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Generate academic draft")

    # Required arguments
    parser.add_argument("--topic", required=True, help="Draft topic")
    parser.add_argument("--language", default="en", help="Language code (e.g., en-US, en-GB, de, es, fr, etc.)")
    parser.add_argument("--academic-level", default="master", choices=["research_paper", "bachelor", "master", "phd"], help="Academic level")

    # Database integration (optional)
    parser.add_argument("--draft-id", help="Database draft ID for progress tracking")
    parser.add_argument("--supabase-url", help="Supabase URL")
    parser.add_argument("--supabase-key", help="Supabase service role key")
    parser.add_argument("--gemini-key", help="Gemini API key (overrides env var)")

    # Metadata (optional)
    parser.add_argument("--author", help="Author name")
    parser.add_argument("--institution", help="Institution name")
    parser.add_argument("--department", help="Department name")
    parser.add_argument("--faculty", help="Faculty name")
    parser.add_argument("--advisor", help="Advisor name")
    parser.add_argument("--second-examiner", help="Second examiner name")
    parser.add_argument("--location", help="Location")
    parser.add_argument("--student-id", help="Student ID")

    # Other options
    parser.add_argument("--validate", action="store_true", help="Enable strict validation")

    args = parser.parse_args()

    # Set environment variables if provided
    if args.gemini_key:
        os.environ['GEMINI_API_KEY'] = args.gemini_key
    if args.supabase_url:
        os.environ['SUPABASE_URL'] = args.supabase_url
    if args.supabase_key:
        os.environ['SUPABASE_SERVICE_KEY'] = args.supabase_key

    # Initialize database tracker if draft_id provided
    progress_tracker = None
    if args.draft_id:
        from utils.progress_tracker import ProgressTracker
        progress_tracker = ProgressTracker(draft_id=args.draft_id)
        print(f"\u2705 Database tracking enabled for draft: {args.draft_id}")

    try:
        pdf, docx = generate_draft(
            topic=args.topic,
            language=args.language,
            academic_level=args.academic_level,
            skip_validation=not args.validate,
            tracker=progress_tracker,
            author_name=args.author,
            institution=args.institution,
            department=args.department,
            faculty=args.faculty,
            advisor=args.advisor,
            second_examiner=args.second_examiner,
            location=args.location,
            student_id=args.student_id,
        )

        print(f"\n\u2705 Generated:")
        print(f"   PDF: {pdf}")
        print(f"   DOCX: {docx}")

        sys.exit(0)

    except Exception as e:
        print(f"\n\u274c Generation failed: {e}", file=sys.stderr)
        traceback.print_exc()
        sys.exit(1)
