"""Engram Python SDK client."""

from __future__ import annotations

import os
from typing import Any, Optional

import httpx

from .exceptions import (
    AuthenticationError,
    EngramError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from .models import (
    BatchResult,
    ContextResult,
    ImportanceHint,
    Memory,
    MemoryLayer,
    MemorySource,
    QueryResult,
    SubjectType,
)

DEFAULT_BASE_URL = "https://api.openengram.ai"
DEFAULT_TIMEOUT = 30.0


class Engram:
    """Client for the Engram memory API.

    Args:
        api_key: API key for authentication. Falls back to ``ENGRAM_API_KEY`` env var.
        user_id: Default user ID. Falls back to ``ENGRAM_USER_ID`` env var.
        base_url: API base URL. Falls back to ``ENGRAM_BASE_URL`` env var or default.
        timeout: Request timeout in seconds.
        httpx_client: Optional pre-configured ``httpx.Client`` instance.
    """

    def __init__(
        self,
        api_key: str | None = None,
        user_id: str | None = None,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        httpx_client: httpx.Client | None = None,
    ) -> None:
        self.api_key = api_key or os.environ.get("ENGRAM_API_KEY", "")
        self.user_id = user_id or os.environ.get("ENGRAM_USER_ID", "")
        self.base_url = (base_url or os.environ.get("ENGRAM_BASE_URL", DEFAULT_BASE_URL)).rstrip("/")
        self.timeout = timeout

        if httpx_client:
            self._client = httpx_client
            self._owns_client = False
        else:
            self._client = httpx.Client(timeout=timeout)
            self._owns_client = True

    def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> Engram:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ── Internal ────────────────────────────────────────────────────────

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {}
        if self.api_key:
            headers["X-AM-API-Key"] = self.api_key
        if self.user_id:
            headers["X-AM-User-ID"] = self.user_id
        return headers

    def _url(self, path: str) -> str:
        return f"{self.base_url}/v1/{path.lstrip('/')}"

    def _handle_response(self, resp: httpx.Response) -> Any:
        if resp.status_code == 204:
            return None
        if resp.is_success:
            return resp.json()

        body = None
        try:
            body = resp.json()
        except Exception:
            pass
        msg = (body or {}).get("message", resp.text or f"HTTP {resp.status_code}")

        error_map: dict[int, type[EngramError]] = {
            400: ValidationError,
            401: AuthenticationError,
            403: AuthenticationError,
            404: NotFoundError,
            429: RateLimitError,
        }
        exc_cls = error_map.get(resp.status_code, ServerError if resp.status_code >= 500 else EngramError)
        raise exc_cls(msg, status_code=resp.status_code, response=body)

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        resp = self._client.request(method, self._url(path), headers=self._headers(), **kwargs)
        return self._handle_response(resp)

    # ── CRUD ────────────────────────────────────────────────────────────

    def remember(
        self,
        content: str,
        *,
        layer: MemoryLayer | str | None = None,
        importance_hint: ImportanceHint | str | None = None,
        context: dict[str, str] | None = None,
        source: MemorySource | str | None = None,
        subject_type: SubjectType | str | None = None,
        subject_id: str | None = None,
        agent_id: str | None = None,
        agent_session_key: str | None = None,
        pool_id: str | None = None,
    ) -> Memory:
        """Store a new memory.

        Args:
            content: The memory text to store.
            layer: Memory layer (SESSION, PROJECT, IDENTITY, TASK).
            importance_hint: Importance hint (LOW, MEDIUM, HIGH, CRITICAL).
            context: Optional dict with ``projectId`` and/or ``sessionId``.
            source: Memory source type.
            subject_type: Subject type (USER, AGENT).
            subject_id: Subject identifier.
            agent_id: Agent identifier.
            agent_session_key: Agent session key.
            pool_id: Pool ID for scoped writes.

        Returns:
            The created Memory object.
        """
        body: dict[str, Any] = {"raw": content}
        if layer:
            body["layer"] = str(layer)
        if importance_hint:
            body["importanceHint"] = str(importance_hint)
        if context:
            body["context"] = context
        if source:
            body["source"] = str(source)
        if subject_type:
            body["subjectType"] = str(subject_type)
        if subject_id:
            body["subjectId"] = subject_id
        if agent_id:
            body["agentId"] = agent_id
        if agent_session_key:
            body["agentSessionKey"] = agent_session_key
        if pool_id:
            body["poolId"] = pool_id
        return Memory.from_dict(self._request("POST", "memories", json=body))

    def remember_batch(
        self,
        memories: list[dict[str, Any]],
        *,
        context: dict[str, str] | None = None,
    ) -> BatchResult:
        """Store multiple memories at once.

        Args:
            memories: List of dicts with at least ``raw`` key. Optional: ``layer``, ``importanceHint``, ``ts``.
            context: Optional dict with ``projectId`` and/or ``sessionId``.

        Returns:
            BatchResult with created/failed counts.
        """
        body: dict[str, Any] = {"memories": memories}
        if context:
            body["context"] = context
        return BatchResult.from_dict(self._request("POST", "memories/batch", json=body))

    def get(self, memory_id: str) -> Memory:
        """Get a memory by ID.

        Args:
            memory_id: The memory ID.

        Returns:
            The Memory object.

        Raises:
            NotFoundError: If the memory doesn't exist.
        """
        data = self._request("GET", f"memories/{memory_id}")
        return Memory.from_dict(data)

    def update(
        self,
        memory_id: str,
        *,
        raw: str | None = None,
        layer: MemoryLayer | str | None = None,
        importance_hint: ImportanceHint | str | None = None,
        importance_score: float | None = None,
        extraction: dict[str, Any] | None = None,
    ) -> Memory:
        """Update an existing memory.

        Args:
            memory_id: The memory ID.
            raw: Updated content (triggers re-embedding).
            layer: New layer classification.
            importance_hint: New importance hint.
            importance_score: Direct importance score (0.0-1.0).
            extraction: Updated 5W1H extraction fields.

        Returns:
            The updated Memory object.
        """
        body: dict[str, Any] = {}
        if raw is not None:
            body["raw"] = raw
        if layer is not None:
            body["layer"] = str(layer)
        if importance_hint is not None:
            body["importanceHint"] = str(importance_hint)
        if importance_score is not None:
            body["importanceScore"] = importance_score
        if extraction is not None:
            body["extraction"] = extraction
        return Memory.from_dict(self._request("PATCH", f"memories/{memory_id}", json=body))

    def forget(self, memory_id: str) -> None:
        """Delete a memory (soft delete).

        Args:
            memory_id: The memory ID to delete.
        """
        self._request("DELETE", f"memories/{memory_id}")

    # ── Search ──────────────────────────────────────────────────────────

    def search(
        self,
        query: str,
        *,
        layers: list[MemoryLayer | str] | None = None,
        limit: int = 10,
        include_chains: bool = False,
        project_id: str | None = None,
        agent_id: str | None = None,
        agent_session_key: str | None = None,
        pool_ids: list[str] | None = None,
    ) -> QueryResult:
        """Search memories using semantic similarity.

        Args:
            query: Natural language search query.
            layers: Filter by memory layers.
            limit: Maximum number of results.
            include_chains: Include memory chains.
            project_id: Filter by project.
            agent_id: Filter by agent.
            agent_session_key: Agent session key.
            pool_ids: Filter by pool IDs.

        Returns:
            QueryResult with matching memories.
        """
        body: dict[str, Any] = {"query": query, "limit": limit}
        if layers:
            body["layers"] = [str(l) for l in layers]
        if include_chains:
            body["includeChains"] = True
        if project_id:
            body["projectId"] = project_id
        if agent_id:
            body["agentId"] = agent_id
        if agent_session_key:
            body["agentSessionKey"] = agent_session_key
        if pool_ids:
            body["poolIds"] = pool_ids
        return QueryResult.from_dict(self._request("POST", "memories/search", json=body))

    # ── Context ─────────────────────────────────────────────────────────

    def context(
        self,
        *,
        max_tokens: int = 4000,
        project_id: str | None = None,
        session_id: str | None = None,
        agent_id: str | None = None,
    ) -> ContextResult:
        """Load context for an agent session.

        Args:
            max_tokens: Maximum tokens for context.
            project_id: Optional project filter.
            session_id: Optional session filter.
            agent_id: Optional agent filter.

        Returns:
            ContextResult with formatted context and memories.
        """
        body: dict[str, Any] = {"maxTokens": max_tokens}
        if project_id:
            body["projectId"] = project_id
        if session_id:
            body["sessionId"] = session_id
        if agent_id:
            body["agentId"] = agent_id
        return ContextResult.from_dict(self._request("POST", "context", json=body))

    # ── Feedback ────────────────────────────────────────────────────────

    def mark_used(self, memory_id: str) -> None:
        """Mark a memory as used (implicit feedback).

        Args:
            memory_id: The memory ID.
        """
        self._request("POST", f"memories/{memory_id}/used")

    def mark_helpful(self, memory_id: str) -> None:
        """Mark a memory as helpful (explicit feedback).

        Args:
            memory_id: The memory ID.
        """
        self._request("POST", f"memories/{memory_id}/helpful")

    # ── Graph ───────────────────────────────────────────────────────────

    def graph(
        self,
        *,
        limit: int = 500,
        include_agent: bool = False,
    ) -> dict[str, Any]:
        """Get memory graph data for visualization.

        Args:
            limit: Maximum number of nodes.
            include_agent: Include agent memories.

        Returns:
            Dict with nodes, edges, entities, and optional stats.
        """
        params: dict[str, Any] = {"limit": str(limit)}
        if include_agent:
            params["includeAgent"] = "true"
        return self._request("GET", "memories/graph", params=params)


class AsyncEngram:
    """Async client for the Engram memory API.

    Same interface as :class:`Engram` but uses ``httpx.AsyncClient``.
    """

    def __init__(
        self,
        api_key: str | None = None,
        user_id: str | None = None,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        httpx_client: httpx.AsyncClient | None = None,
    ) -> None:
        self.api_key = api_key or os.environ.get("ENGRAM_API_KEY", "")
        self.user_id = user_id or os.environ.get("ENGRAM_USER_ID", "")
        self.base_url = (base_url or os.environ.get("ENGRAM_BASE_URL", DEFAULT_BASE_URL)).rstrip("/")
        self.timeout = timeout

        if httpx_client:
            self._client = httpx_client
            self._owns_client = False
        else:
            self._client = httpx.AsyncClient(timeout=timeout)
            self._owns_client = True

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def __aenter__(self) -> AsyncEngram:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {}
        if self.api_key:
            headers["X-AM-API-Key"] = self.api_key
        if self.user_id:
            headers["X-AM-User-ID"] = self.user_id
        return headers

    def _url(self, path: str) -> str:
        return f"{self.base_url}/v1/{path.lstrip('/')}"

    def _handle_response(self, resp: httpx.Response) -> Any:
        if resp.status_code == 204:
            return None
        if resp.is_success:
            return resp.json()
        body = None
        try:
            body = resp.json()
        except Exception:
            pass
        msg = (body or {}).get("message", resp.text or f"HTTP {resp.status_code}")
        error_map: dict[int, type[EngramError]] = {
            400: ValidationError,
            401: AuthenticationError,
            403: AuthenticationError,
            404: NotFoundError,
            429: RateLimitError,
        }
        exc_cls = error_map.get(resp.status_code, ServerError if resp.status_code >= 500 else EngramError)
        raise exc_cls(msg, status_code=resp.status_code, response=body)

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        resp = await self._client.request(method, self._url(path), headers=self._headers(), **kwargs)
        return self._handle_response(resp)

    async def remember(self, content: str, **kwargs: Any) -> Memory:
        """Store a new memory. See :meth:`Engram.remember` for args."""
        body: dict[str, Any] = {"raw": content}
        for k, v in kwargs.items():
            if v is not None:
                body[k] = v
        return Memory.from_dict(await self._request("POST", "memories", json=body))

    async def get(self, memory_id: str) -> Memory:
        return Memory.from_dict(await self._request("GET", f"memories/{memory_id}"))

    async def search(self, query: str, *, limit: int = 10, **kwargs: Any) -> QueryResult:
        body: dict[str, Any] = {"query": query, "limit": limit, **kwargs}
        return QueryResult.from_dict(await self._request("POST", "memories/search", json=body))

    async def context(self, *, max_tokens: int = 4000, **kwargs: Any) -> ContextResult:
        body: dict[str, Any] = {"maxTokens": max_tokens, **kwargs}
        return ContextResult.from_dict(await self._request("POST", "context", json=body))

    async def update(self, memory_id: str, **kwargs: Any) -> Memory:
        return Memory.from_dict(await self._request("PATCH", f"memories/{memory_id}", json=kwargs))

    async def forget(self, memory_id: str) -> None:
        await self._request("DELETE", f"memories/{memory_id}")

    async def mark_used(self, memory_id: str) -> None:
        await self._request("POST", f"memories/{memory_id}/used")

    async def mark_helpful(self, memory_id: str) -> None:
        await self._request("POST", f"memories/{memory_id}/helpful")

    async def graph(self, *, limit: int = 500, include_agent: bool = False) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": str(limit)}
        if include_agent:
            params["includeAgent"] = "true"
        return await self._request("GET", "memories/graph", params=params)
