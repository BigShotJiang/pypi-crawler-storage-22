"""Exceptions for the Engram SDK."""

from __future__ import annotations


class EngramError(Exception):
    """Base exception for Engram SDK errors."""

    def __init__(self, message: str, status_code: int | None = None, response: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class AuthenticationError(EngramError):
    """Raised when authentication fails (401)."""


class NotFoundError(EngramError):
    """Raised when a resource is not found (404)."""


class RateLimitError(EngramError):
    """Raised when rate limited (429)."""


class ValidationError(EngramError):
    """Raised when request validation fails (400)."""


class ServerError(EngramError):
    """Raised on server errors (5xx)."""
