"""Data models for the Engram SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional


class MemoryLayer(str, Enum):
    SESSION = "SESSION"
    PROJECT = "PROJECT"
    IDENTITY = "IDENTITY"
    TASK = "TASK"


class ImportanceHint(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class SubjectType(str, Enum):
    USER = "USER"
    AGENT = "AGENT"


class MemorySource(str, Enum):
    EXPLICIT_STATEMENT = "EXPLICIT_STATEMENT"
    INFERRED = "INFERRED"
    OBSERVED = "OBSERVED"


@dataclass
class Extraction:
    who: Optional[str] = None
    what: Optional[str] = None
    when: Optional[str] = None
    where: Optional[str] = None
    why: Optional[str] = None
    how: Optional[str] = None
    topics: list[str] = field(default_factory=list)


@dataclass
class Memory:
    id: str
    raw: str
    layer: Optional[str] = None
    importance: Optional[float] = None
    extraction: Optional[Extraction] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Memory:
        extraction = None
        if data.get("extraction"):
            ext = data["extraction"]
            if isinstance(ext, dict):
                extraction = Extraction(
                    who=ext.get("who"),
                    what=ext.get("what"),
                    when=ext.get("when"),
                    where=ext.get("where"),
                    why=ext.get("why"),
                    how=ext.get("how"),
                    topics=ext.get("topics", []),
                )
        return cls(
            id=data.get("id", ""),
            raw=data.get("raw", ""),
            layer=data.get("layer"),
            importance=data.get("importance") or data.get("importanceScore"),
            extraction=extraction,
            created_at=data.get("createdAt"),
            updated_at=data.get("updatedAt"),
        )


@dataclass
class QueryResult:
    memories: list[Memory]
    total: Optional[int] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> QueryResult:
        memories = [Memory.from_dict(m) for m in data.get("memories", [])]
        return cls(memories=memories, total=data.get("total"))


@dataclass
class ContextResult:
    context: str
    memories: list[Memory] = field(default_factory=list)
    token_count: Optional[int] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ContextResult:
        memories = [Memory.from_dict(m) for m in data.get("memories", [])]
        return cls(
            context=data.get("context", ""),
            memories=memories,
            token_count=data.get("tokenCount"),
        )


@dataclass
class BatchResult:
    created: int
    failed: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BatchResult:
        return cls(created=data.get("created", 0), failed=data.get("failed", 0))
