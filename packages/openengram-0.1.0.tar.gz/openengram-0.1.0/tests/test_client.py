"""Tests for the Engram SDK client."""

import json
from unittest.mock import MagicMock

import httpx
import pytest

from openengram import (
    AsyncEngram,
    AuthenticationError,
    Engram,
    Memory,
    MemoryLayer,
    NotFoundError,
    QueryResult,
    RateLimitError,
)


def make_response(status_code: int = 200, json_data: dict | None = None) -> httpx.Response:
    resp = httpx.Response(
        status_code=status_code,
        json=json_data,
        request=httpx.Request("GET", "https://test.com"),
    )
    return resp


class TestMemoryModel:
    def test_from_dict_minimal(self):
        m = Memory.from_dict({"id": "abc", "raw": "hello"})
        assert m.id == "abc"
        assert m.raw == "hello"
        assert m.extraction is None

    def test_from_dict_with_extraction(self):
        m = Memory.from_dict({
            "id": "abc",
            "raw": "hello",
            "extraction": {"who": "user", "topics": ["greetings"]},
        })
        assert m.extraction is not None
        assert m.extraction.who == "user"
        assert m.extraction.topics == ["greetings"]


class TestEngram:
    def setup_method(self):
        self.mock_client = MagicMock(spec=httpx.Client)
        self.engram = Engram(
            api_key="ek_test",
            user_id="user_test",
            base_url="https://test.api.com",
            httpx_client=self.mock_client,
        )

    def test_headers(self):
        headers = self.engram._headers()
        assert headers["X-AM-API-Key"] == "ek_test"
        assert headers["X-AM-User-ID"] == "user_test"

    def test_url(self):
        assert self.engram._url("memories") == "https://test.api.com/v1/memories"
        assert self.engram._url("/memories") == "https://test.api.com/v1/memories"

    def test_remember(self):
        self.mock_client.request.return_value = make_response(201, {
            "id": "mem_123",
            "raw": "test memory",
            "layer": "SESSION",
        })
        memory = self.engram.remember("test memory")
        assert memory.id == "mem_123"
        assert memory.raw == "test memory"

        call_args = self.mock_client.request.call_args
        assert call_args[0][0] == "POST"
        assert "memories" in call_args[0][1]

    def test_get(self):
        self.mock_client.request.return_value = make_response(200, {
            "id": "mem_123",
            "raw": "test memory",
        })
        memory = self.engram.get("mem_123")
        assert memory.id == "mem_123"

    def test_search(self):
        self.mock_client.request.return_value = make_response(200, {
            "memories": [
                {"id": "mem_1", "raw": "result 1"},
                {"id": "mem_2", "raw": "result 2"},
            ],
        })
        result = self.engram.search("test query")
        assert len(result.memories) == 2
        assert result.memories[0].id == "mem_1"

    def test_forget(self):
        self.mock_client.request.return_value = make_response(204)
        self.engram.forget("mem_123")  # should not raise

    def test_404_raises_not_found(self):
        self.mock_client.request.return_value = make_response(404, {"message": "Not found"})
        with pytest.raises(NotFoundError):
            self.engram.get("nonexistent")

    def test_401_raises_auth_error(self):
        self.mock_client.request.return_value = make_response(401, {"message": "Unauthorized"})
        with pytest.raises(AuthenticationError):
            self.engram.get("mem_123")

    def test_429_raises_rate_limit(self):
        self.mock_client.request.return_value = make_response(429, {"message": "Too many requests"})
        with pytest.raises(RateLimitError):
            self.engram.search("test")

    def test_context_manager(self):
        client = MagicMock(spec=httpx.Client)
        with Engram(api_key="ek_test", httpx_client=client) as e:
            assert e.api_key == "ek_test"

    def test_remember_with_layer(self):
        self.mock_client.request.return_value = make_response(201, {
            "id": "mem_123",
            "raw": "identity fact",
            "layer": "IDENTITY",
        })
        memory = self.engram.remember("identity fact", layer=MemoryLayer.IDENTITY)
        assert memory.layer == "IDENTITY"
