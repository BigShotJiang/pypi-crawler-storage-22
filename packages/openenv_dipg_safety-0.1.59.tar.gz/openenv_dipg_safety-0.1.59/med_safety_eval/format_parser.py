"""
Format parser for handling various structured response formats from models.
"""
import re
import json
import yaml
from typing import Dict, Optional, Any, Tuple

from .models import ParsedResponse, ResponseFormat

class FormatParser:
    """
    Parses a model's raw string response into a structured `ParsedResponse` object.
    
    It can handle different formats, like custom XML-like tags, JSON, and YAML,
    and is designed to be extensible.
    """

    def __init__(self):
        # Define tag aliases centrally for easier maintenance.
        self.tag_aliases = {
            "analysis": ["think", "analysis", "reasoning", "thought"],
            "proof": ["proof", "trace", "evidence", "quote"],
            "final": ["answer", "final", "conclusion", "result", "final_answer"],
        }
        
        # Shared template for XML-like tag extraction
        # V4.6: Support both <tag> and [tag].
        self.tag_pattern_template = r"(?:<|\[)(?:{tags})(?:\s+[^\]>]*?)?(?:>|\])(.*?)(?:<|\[)/(?:{tags})(?:>|\])"
        
        # Pre-compile regex for efficiency, supporting multiple tag names for flexibility.
        self.tag_patterns = {
            key: re.compile(
                self.tag_pattern_template.format(tags='|'.join(re.escape(a) for a in aliases)),
                re.DOTALL | re.IGNORECASE
            )
            for key, aliases in self.tag_aliases.items()
        }
        
        # Unclosed tag fallbacks (Additive V4.7)
        # Support both <tag> and [tag] stop at the next tag or end of string.
        all_aliases = [a for aliases in self.tag_aliases.values() for a in aliases]
        self.unclosed_patterns = {
            key: re.compile(
                r"(?:<|\[)(?:{tags})(?:\s+[^\]>]*?)?(?:>|\])(.*?)(?=(?:<|\[)(?:{all_tags})|$)".format(
                    tags='|'.join(re.escape(a) for a in aliases),
                    all_tags='|'.join(re.escape(a) for a in all_aliases)
                ),
                re.DOTALL | re.IGNORECASE
            )
            for key, aliases in self.tag_aliases.items()
        }
        
        # Regex pattern for custom tag format (backward compatibility)
        # Regex pattern for custom tag format (backward compatibility)
        self.custom_tag_pattern = re.compile(
            r'<\|channel\|>(\w+)<\|message\|>(.*?)<\|end\|>',
            re.DOTALL
        )

    def _rescue_answer(self, text: str) -> Tuple[Optional[str], bool]:
        """
        Attempts to rescue an answer from the text.
        Returns (rescued_text, is_strong_match).
        """
        if not text:
            return None, False

        # 1. Strong Match: \boxed{...}
        boxed_match = re.search(r'\\boxed\{(.*?)\}', text, re.DOTALL)
        if boxed_match:
            return boxed_match.group(1).strip(), True
            
        # 2. Strong Match: Markdown Header **Answer:** or similar
        # Look for **Answer:** followed by text, until the next double newline or end of string
        header_match = re.search(r'(?:\*\*|###)\s*(?:Final\s+)?Answer:?\s*(?:\*\*|:)?\s*(.*?)(?:\n\n|$)', text, re.IGNORECASE | re.DOTALL)
        if header_match:
            return header_match.group(1).strip(), True
            
        # 3. Weak Match: Keywords (Existing logic)
        # Find the LAST occurrence of a keyword
        marker = re.search(r".*(\b(?:conclusion|answer|therefore|thus|so|consequently|final answer|result|summary)\b[\W\s]+.*?)$", text, re.IGNORECASE | re.DOTALL)
        if marker:
            candidate = marker.group(1).strip()
            # Cleanup: Stop at "Hmm", "Wait", "Let me", "I need to" if they appear at start of a new sentence
            # This helps with the format_again.md case where the model continues thinking
            cleanup_pattern = re.compile(r'(\n\s*(?:Hmm|Wait|Let me|I need to)\b.*)', re.IGNORECASE | re.DOTALL)
            cleaned = cleanup_pattern.sub('', candidate)
            return cleaned.strip(), False
            
        return None, False

    def parse(
        self,
        response_text: str,
        format_type: ResponseFormat = ResponseFormat.AUTO
    ) -> ParsedResponse:
        """
        Public method to parse a response.
        """
        if not response_text or not response_text.strip():
            return ParsedResponse(
                final="FORMAT_ERROR: Empty response",
                original_response=response_text,
                format_error=True
            )

        if format_type == ResponseFormat.AUTO:
            format_type = self._detect_format(response_text)

        parser_map = {
            ResponseFormat.CUSTOM_TAGS: self._parse_custom_tags,
            ResponseFormat.XML: self._parse_xml,
            ResponseFormat.JSON: self._parse_json,
            ResponseFormat.YAML: self._parse_yaml,
        }
        
        parser_func = parser_map.get(format_type, self._parse_xml)
        return parser_func(response_text, original_response=response_text)

    def _detect_format(self, response: str) -> ResponseFormat:
        """Auto-detect the format of the response"""
        response_stripped = response.strip()
        
        if '<|channel|>' in response_stripped:
            return ResponseFormat.CUSTOM_TAGS

        if response_stripped.startswith('{') or '```json' in response_stripped.lower():
            return ResponseFormat.JSON
        
        if '<' in response_stripped and '>' in response_stripped:
             return ResponseFormat.XML

        if all(field in response_stripped for field in ['analysis:', 'proof:', 'final:']) or '```yaml' in response_stripped.lower():
            return ResponseFormat.YAML
        
        return ResponseFormat.XML

    def _parse_xml(self, response_text: str, original_response: str = "") -> ParsedResponse:
        """
        Parses a response expected to contain XML-like tags with V4.5 robustness.
        """
        extracted: Dict[str, Optional[str]] = {}
        
        # 1. Extract analysis (thought) block (first match)
        analysis_pattern = self.tag_patterns["analysis"]
        analysis_match = analysis_pattern.search(response_text)
        
        extracted["analysis"] = analysis_match.group(1).strip() if analysis_match else None
        if not analysis_match:
            # Additive fallback for unclosed analysis
            unclosed_match = self.unclosed_patterns["analysis"].search(response_text)
            if unclosed_match:
                extracted["analysis"] = unclosed_match.group(1).strip()
                
        # 2. Sanitized text = original minus recognized thought blocks
        if analysis_match:
            start, end = analysis_match.span()
            sanitized_text = response_text[:start] + response_text[end:]
        elif extracted.get("analysis"):
            # Sanitize using the unclosed pattern for subsequent extraction
            sanitized_text = self.unclosed_patterns["analysis"].sub("", response_text, count=1)
        else:
            sanitized_text = response_text
            
        # 3. Extract proof and final answer from the sanitized text
        for key in ["proof", "final"]:
            pattern = self.tag_patterns[key]
            if key == "proof":
                # Aggregate multiple closed proof tags
                matches = [m.group(1).strip() for m in pattern.finditer(sanitized_text) if m.group(1).strip()]
                
                # Additive: if no closed proof tags, try unclosed fallback (typically for truncated responses)
                if not matches:
                    unclosed_m = self.unclosed_patterns["proof"].search(sanitized_text)
                    if unclosed_m:
                        matches = [unclosed_m.group(1).strip()]
                
                extracted[key] = "\n".join(matches) if matches else None
            else:
                # Take the last closed final answer
                last_match = None
                for m in pattern.finditer(sanitized_text):
                    last_match = m
                
                if last_match:
                    extracted[key] = last_match.group(1).strip()
                else:
                    # Additive: fallback to unclosed final tag
                    unclosed_m = self.unclosed_patterns["final"].search(sanitized_text)
                    if unclosed_m:
                        extracted[key] = unclosed_m.group(1).strip()
                    else:
                        extracted[key] = None

        # 4. Fallback Handling if <final> is missing
        is_format_error = False
        if extracted.get("final") is None:
            # ROBUSTNESS FALLBACK A: "Dangling" Answer - look for substantial text outside of tags
            text_without_blocks = sanitized_text
            # Remove all well-formed tag blocks that we recognize (both <tag> and [tag])
            for key_alias, aliases in self.tag_aliases.items():
                p = re.compile(
                    r"(?:<|\[)(?:{tags})(?:\s+[^\]>]*?)?(?:>|\])(.*?)(?:<|\[)/(?:{tags})(?:>|\])".format(tags='|'.join(re.escape(a) for a in aliases)),
                    re.DOTALL | re.IGNORECASE
                )
                text_without_blocks = p.sub("", text_without_blocks)
            
            # Remove any stray unclosed tags or top-level wrappers
            dangling_candidate = re.sub(r'<[^>]+>|\[[^\]]+\]', '', text_without_blocks).strip()
            
            if len(dangling_candidate) > 5:
                # Clean up common Markdown headers or markers from the dangling answer
                cleaned_candidate = dangling_candidate
                markers = [
                    r"^(?:###?\s+)?(?:Final\s+)?Answer:?[\s\n]*",
                    r"^(?:###?\s+)?Conclusion:?[\s\n]*",
                    r"^(?:###?\s+)?Result:?[\s\n]*",
                    r"^\*\*Answer:\*\*[\s\n]*",
                    r"^Answer:?[\s\n]*"
                ]
                for m in markers:
                    match = re.search(m, cleaned_candidate, flags=re.IGNORECASE)
                    if match:
                        # Only strip if there's substantial text after the marker
                        potential_new = cleaned_candidate[match.end():].strip()
                        if len(potential_new) > 3:
                            cleaned_candidate = potential_new
                            break
                
                extracted["final"] = cleaned_candidate
                is_format_error = False # Dangling text is accepted as clear intent
            else:
                # ROBUSTNESS FALLBACK B: "Rescued" Answer - look inside the thinking block
                if extracted.get("analysis"):
                    thoughts = extracted["analysis"]
                    rescued_text, is_strong = self._rescue_answer(thoughts)
                    if rescued_text:
                        if is_strong:
                            extracted["final"] = rescued_text
                            is_format_error = False # Strong match is accepted
                        else:
                            extracted["final"] = f"Rescued: {rescued_text}"
                            is_format_error = True # Weak match still flagged
                    elif len(thoughts) > 50:
                        # Fallback to last sentence
                        sentences = [s.strip() for s in re.split(r'[\.\?\!\n]', thoughts) if s.strip()]
                        if sentences:
                            extracted["final"] = f"Rescued: {sentences[-1]}"
                            is_format_error = True

        if extracted.get("final") is None:
            return ParsedResponse(
                analysis=extracted.get("analysis"),
                proof=extracted.get("proof"),
                final=f"FORMAT_ERROR: Missing <answer> tag. Original response: {original_response or response_text}",
                original_response=original_response or response_text,
                format_error=True,
            )

        return ParsedResponse(
            analysis=extracted.get("analysis"),
            proof=extracted.get("proof"),
            final=extracted["final"],
            original_response=original_response or response_text,
            format_error=is_format_error,
        )

    def _parse_custom_tags(self, response_text: str, original_response: str = "") -> ParsedResponse:
        """Parses legacy <|channel|> format."""
        channels = {
            match.group(1): match.group(2).strip()
            for match in self.custom_tag_pattern.finditer(response_text)
        }
        
        analysis = channels.get("analysis")
        proof = channels.get("proof")
        final = channels.get("final")

        if final is None:
            return ParsedResponse(
                analysis=analysis,
                proof=proof,
                final=f"FORMAT_ERROR: Missing final channel. Original: {original_response or response_text}",
                original_response=original_response or response_text,
                format_error=True
            )

        return ParsedResponse(
            analysis=analysis,
            proof=proof,
            final=final,
            original_response=original_response or response_text,
            format_error=False
        )

    def _parse_json(self, response_text: str, original_response: str = "") -> ParsedResponse:
        """Parses JSON responses."""
        cleaned = response_text.strip()
        if '```' in cleaned:
            blocks = re.findall(r'```(?:json)?(.*?)```', cleaned, re.DOTALL | re.IGNORECASE)
            if blocks: cleaned = blocks[0].strip()
            
        try:
            data = json.loads(cleaned)
            aliases = {
                'analysis': ['reasoning', 'thought', 'explanation', 'analysis', 'think'],
                'proof': ['evidence', 'quote', 'reference', 'proof', 'trace', 'source'],
                'final': ['answer', 'conclusion', 'result', 'final', 'final_answer']
            }
            normalized = {}
            for target, sources in aliases.items():
                for s in sources:
                    if s in data:
                        normalized[target] = data[s]
                        break
            
            if not normalized.get('final'):
                return ParsedResponse(
                    analysis=normalized.get('analysis'),
                    proof=normalized.get('proof'),
                    final=f"FORMAT_ERROR: Missing final answer in JSON.",
                    original_response=original_response or response_text,
                    format_error=True
                )
            return ParsedResponse(
                analysis=normalized.get('analysis'),
                proof=normalized.get('proof'),
                final=normalized['final'],
                original_response=original_response or response_text,
                format_error=False
            )
        except:
            return ParsedResponse(final="FORMAT_ERROR: Invalid JSON", original_response=response_text, format_error=True)

    def _parse_yaml(self, response_text: str, original_response: str = "") -> ParsedResponse:
        """Parses YAML responses."""
        cleaned = response_text.strip()
        if '```' in cleaned:
            blocks = re.findall(r'```(?:yaml)?(.*?)```', cleaned, re.DOTALL | re.IGNORECASE)
            if blocks: cleaned = blocks[0].strip()
        try:
            data = yaml.safe_load(cleaned)
            if not isinstance(data, dict): raise ValueError()
            return ParsedResponse(
                analysis=data.get('analysis'),
                proof=data.get('proof'),
                final=data.get('final') or "FORMAT_ERROR: Missing final in YAML",
                original_response=original_response or response_text,
                format_error=not bool(data.get('final'))
            )
        except:
            return ParsedResponse(final="FORMAT_ERROR: Invalid YAML", original_response=response_text, format_error=True)