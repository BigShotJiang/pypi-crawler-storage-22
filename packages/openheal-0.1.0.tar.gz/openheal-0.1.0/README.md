# openheal

Plataforma Open Source para Saúde — módulos reutilizáveis para análise de dados clínicos.

## Instalação

```bash
pip install openheal
```

## Módulos disponíveis

### `openheal.endocrinology.abbott_system`

Análise de dados de glicemia hospitalar a partir de planilhas exportadas pelo sistema Abbott.

```python
from openheal.endocrinology.abbott_system.spreadsheet_reader import SpreadsheetReader
from openheal.endocrinology.abbott_system.stats import StatisticsEngine

# Ler planilha Abbott
reader = SpreadsheetReader(path="glicemias.xlsx")
df = reader.read()

# Calcular todos os indicadores
engine = StatisticsEngine()
resultados = engine.run_all(df)
```

## Publicar no PyPI

```bash
# Instalar ferramentas de build
pip install build twine

# Construir pacote
python -m build

# Enviar para PyPI
twine upload dist/*
```

## Licença

MIT
