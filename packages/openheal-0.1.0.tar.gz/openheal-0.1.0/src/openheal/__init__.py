"""OpenHeal — Plataforma Open Source para Saúde."""

__version__ = "0.1.0"
