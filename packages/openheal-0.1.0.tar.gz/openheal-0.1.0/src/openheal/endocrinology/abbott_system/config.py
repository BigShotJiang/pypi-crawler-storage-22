"""Configurações públicas do sistema Abbott."""

from pathlib import Path

# ---------------------------------------------------------------------------
# Diretório das planilhas de glicemias (padrão relativo ao pacote instalado)
# ---------------------------------------------------------------------------
SPREADSHEET_DIR: Path = Path(__file__).parent / "sheets"

# ---------------------------------------------------------------------------
# Schema de colunas esperadas nas planilhas
# ---------------------------------------------------------------------------
SPREADSHEET_COLUMNS: list[str | list[str]] = [
    "Inst. Transfer Date/Time",
    "Test Date/Time",
    "Facility",
    "Department",
    "Location",
    "Instrument Type",
    "Instrument Name",
    "Instrument Serial",
    "Reagent Product",
    "Reagent Lot",
    "Result Type",
    "Operator ID",
    "Operator Name",
    "Inst. Comment",
    "Patient ID",
    "Patient Name",
    "Patient Gender",
    "Patient DOB",
    "ADT Source",
    "Sample Source",
    "Sample Lot",
    "Lot Level",
    "LIS Receive Date/Time",
    "LIS Accession",
    "LIS Transfer",
    "LIS Message",
    "Reviewed",
    "Review Date/Time",
    "Reviewed By",
    "Review Comment",
    "Excluded",
    ["GLU", "Glicemia", "Glicose"],
    "GLU Unit",
    "BatteryVoltage",
    "Temperature",
]

# ---------------------------------------------------------------------------
# Cutoffs glicêmicos (mg/dL)
# ---------------------------------------------------------------------------
CRITICAL_HYPO: int = 40
HYPO: int = 70
HYPER: int = 180
CRITICAL_HYPER: int = 400

# ---------------------------------------------------------------------------
# Limiares de exclusão (Step B — Value-Based Exclusion)
# ---------------------------------------------------------------------------
GLU_MIN_THRESHOLD: int = 20
GLU_MAX_THRESHOLD: int = 500

# ---------------------------------------------------------------------------
# Intervalo mínimo entre testes do mesmo paciente (minutos)
# (Step C — Time-Interval Exclusion)
# ---------------------------------------------------------------------------
MIN_TIME_INTERVAL: int = 10

# ---------------------------------------------------------------------------
# Range válido para Patient ID (Step A — ID Validation)
# ---------------------------------------------------------------------------
PATIENT_ID_MIN: int = 1
PATIENT_ID_MAX: int = 99_999_999
