"""Módulo de limpeza de dados (Steps B e C)."""

import pandas as pd
import numpy as np
from openheal.endocrinology.abbott_system.config import (
    GLU_MIN_THRESHOLD,
    GLU_MAX_THRESHOLD,
    MIN_TIME_INTERVAL,
)


class DataCleaner:
    @staticmethod
    def clean(df: pd.DataFrame) -> pd.DataFrame:
        """
        Executa o pipeline de exclusão:
        Step B: Value-Based Exclusion
        Step C: Time-Interval Exclusion

        Marca a coluna 'Excluded' como True/False.
        """
        df = df.copy()

        if 'Excluded' not in df.columns:
            df['Excluded'] = False
        else:
            df['Excluded'] = df['Excluded'].astype(bool)

        df['GLU'] = pd.to_numeric(df['GLU'], errors='coerce')

        df['Test Date/Time'] = pd.to_datetime(df['Test Date/Time'], errors='coerce')

        # Step B: Value-Based Exclusion
        value_exclusion_mask = (
            (df['GLU'] < GLU_MIN_THRESHOLD) |
            (df['GLU'] > GLU_MAX_THRESHOLD) |
            (df['GLU'].isna())
        )
        df.loc[value_exclusion_mask, 'Excluded'] = True

        # Step C: Time-Interval Exclusion
        df.sort_values(by=['Patient ID', 'Test Date/Time'], inplace=True)

        patient_mask = (df['Result Type'].astype(str).str.lower() == 'patient') & (~df['Excluded'])

        candidates = df[patient_mask].copy()

        if candidates.empty:
            return df

        exclude_indices_step_c = []

        for patient_id, group in candidates.groupby('Patient ID'):
            if len(group) < 2:
                continue

            last_valid_time = None

            for idx, row in group.iterrows():
                current_time = row['Test Date/Time']
                if pd.isna(current_time):
                    continue

                if last_valid_time is None:
                    last_valid_time = current_time
                else:
                    diff = (current_time - last_valid_time).total_seconds() / 60.0
                    if diff < MIN_TIME_INTERVAL:
                        exclude_indices_step_c.append(idx)
                    else:
                        last_valid_time = current_time

        if exclude_indices_step_c:
            df.loc[exclude_indices_step_c, 'Excluded'] = True

        return df

    @staticmethod
    def exclude_indices(df: pd.DataFrame, indices: list) -> pd.DataFrame:
        """Marca índices específicos como Excluded."""
        df = df.copy()
        valid_indices = [i for i in indices if i in df.index]
        if valid_indices:
            df.loc[valid_indices, 'Excluded'] = True
        return df
