"""Módulo de ingestão de dados.
Responsável por ler arquivos (Excel/CSV) e normalizar colunas.
"""

import pandas as pd
from pathlib import Path
from typing import Optional, List, Union
import io

from openheal.endocrinology.abbott_system.config import SPREADSHEET_COLUMNS


class DataIngestor:
    @staticmethod
    def read_file(content: bytes, filename: str) -> pd.DataFrame:
        """Lê o arquivo e retorna um DataFrame com as colunas normalizadas."""
        if filename.endswith(('.xls', '.xlsx')):
            try:
                df = pd.read_excel(io.BytesIO(content))
            except Exception as e:
                raise ValueError(f"Erro ao ler arquivo Excel: {e}")
        elif filename.endswith('.csv'):
            try:
                df = pd.read_csv(io.BytesIO(content))
            except Exception as e:
                raise ValueError(f"Erro ao ler arquivo CSV: {e}")
        else:
            raise ValueError("Formato de arquivo não suportado. Use .xls, .xlsx ou .csv")

        df = DataIngestor._normalize_columns(df)
        DataIngestor._validate_columns(df)

        return df

    @staticmethod
    def _normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
        rename_map = {}
        for col_def in SPREADSHEET_COLUMNS:
            if isinstance(col_def, list):
                canonical = col_def[0]
                for alt in col_def[1:]:
                    rename_map[alt] = canonical

        df = df.rename(columns=rename_map)
        return df

    @staticmethod
    def _validate_columns(df: pd.DataFrame):
        missing_cols = []
        for col_def in SPREADSHEET_COLUMNS:
            canonical = col_def[0] if isinstance(col_def, list) else col_def
            if canonical not in df.columns:
                missing_cols.append(canonical)

        if missing_cols:
            raise ValueError(f"Colunas obrigatórias ausentes: {', '.join(missing_cols)}")
