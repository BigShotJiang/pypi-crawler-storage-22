"""Módulo de validação de IDs (Step A)."""

import pandas as pd
import re
from typing import List, Dict


class IdValidator:
    @staticmethod
    def validate(df: pd.DataFrame) -> pd.DataFrame:
        """
        Executa validações de ID no DataFrame.
        Adiciona uma coluna 'Validation_Error' com a descrição do erro, se houver.
        Retorna o DataFrame modificado.
        """
        df = df.copy()
        df['Validation_Error'] = None

        # 1. Checagem de Conflito: Operator ID == Patient ID
        conflict_mask = (df['Operator ID'].astype(str) == df['Patient ID'].astype(str))
        df.loc[conflict_mask, 'Validation_Error'] = 'Conflito: Operator ID igual ao Patient ID'

        return df

    @staticmethod
    def get_errors_only(df: pd.DataFrame) -> pd.DataFrame:
        """Retorna apenas as linhas com erros de validação."""
        if 'Validation_Error' not in df.columns:
            return pd.DataFrame()
        return df[df['Validation_Error'].notna()]
