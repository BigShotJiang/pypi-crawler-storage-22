"""Serviço principal do Sistema Abbott — orquestra upload, validação e limpeza de dados."""

from typing import Dict, Any, List, Optional
import uuid
import pandas as pd
from datetime import datetime

from openheal.endocrinology.abbott_system.data_ingestor import DataIngestor
from openheal.endocrinology.abbott_system.data_validator import IdValidator
from openheal.endocrinology.abbott_system.data_cleaner import DataCleaner


class AbbottService:
    # In-memory session store
    _sessions: Dict[str, Dict[str, Any]] = {}

    @classmethod
    def create_session(cls, file_content: bytes, filename: str) -> Dict[str, Any]:
        """Endpoint 1 logic: Upload and Validate file structure."""
        try:
            df = DataIngestor.read_file(file_content, filename)
        except ValueError as e:
            raise ValueError(str(e))

        session_id = str(uuid.uuid4())

        cls._sessions[session_id] = {
            "df": df,
            "filename": filename,
            "created_at": datetime.now(),
            "status": "uploaded"
        }

        return {
            "session_id": session_id,
            "message": "Arquivo recebido e validado com sucesso.",
            "total_rows": len(df),
            "columns": list(df.columns)
        }

    @classmethod
    def validate_ids(cls, session_id: str) -> str:
        """Endpoint 2 logic: Run ID Validation and return dataframe (as JSON)."""
        session = cls._sessions.get(session_id)
        if not session:
            raise KeyError("Sessão não encontrada.")

        df = session["df"]

        df_validated = IdValidator.validate(df)

        session["df_validated"] = df_validated
        session["status"] = "validated"

        return df_validated.to_json(orient='records', date_format='iso')

    @classmethod
    def apply_exclusion_and_clean(cls, session_id: str, exclude_indices: List[int]) -> str:
        """Endpoint 3 logic: Receive excluded indexes, Apply B & C, return filtered dataframe."""
        session = cls._sessions.get(session_id)
        if not session:
            raise KeyError("Sessão não encontrada.")

        df = session.get("df_validated", session["df"])

        df_manual = DataCleaner.exclude_indices(df, exclude_indices)
        df_cleaned = DataCleaner.clean(df_manual)

        session["df_cleaned"] = df_cleaned
        session["status"] = "cleaned"

        return df_cleaned.to_json(orient='records', date_format='iso')
