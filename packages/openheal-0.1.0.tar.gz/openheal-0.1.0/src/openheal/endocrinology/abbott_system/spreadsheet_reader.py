"""Módulo responsável por ler e validar planilhas com base em um schema de colunas."""

from __future__ import annotations

import io
from pathlib import Path

import pandas as pd

from openheal.endocrinology.abbott_system.config import SPREADSHEET_COLUMNS, SPREADSHEET_DIR

# ---------------------------------------------------------------------------
# Tipos auxiliares
# ---------------------------------------------------------------------------
ColumnSchema = list[str | list[str]]


class SpreadsheetReader:
    """Lê uma planilha a partir de um *path* ou de *content* (bytes) e retorna um ``DataFrame`` validado.

    A validação das colunas é feita com base na constante
    ``SPREADSHEET_COLUMNS`` definida em ``config.py``, no formato::

        ["ColA", "ColB", ["ColC", "AlternativaC"], "ColD"]

    * Elementos ``str`` de primeiro nível são nomes **obrigatórios** das
      colunas, na ordem em que devem aparecer.
    * Elementos ``list[str]`` representam **nomes alternativos** para aquela
      posição.  Se a coluna encontrada corresponder a um nome alternativo,
      ela é renomeada para o **primeiro** nome da lista (nome canônico).

    Pode ser instanciado com:
    - ``path``: caminho do arquivo no disco (comportamento original).
    - ``content`` + ``filename``: bytes do arquivo e nome para validar extensão (não grava em disco).
    """

    SUPPORTED_EXTENSIONS: tuple[str, ...] = (".xlsx", ".xls", ".ods")

    def __init__(
        self,
        path: str | Path | None = None,
        content: bytes | None = None,
        filename: str = "",
        schema: ColumnSchema | None = None,
    ) -> None:
        self._schema: ColumnSchema = schema if schema is not None else SPREADSHEET_COLUMNS
        self._validate_schema(self._schema)

        if content is not None:
            self._from_bytes = True
            self._content = content
            self._filename = filename or "upload.xlsx"
            self._path = None
        else:
            self._from_bytes = False
            self._content = None
            self._filename = ""
            if path is None:
                raise ValueError("Deve ser fornecido path ou content.")
            self._path = Path(path)

    # ------------------------------------------------------------------
    # API pública
    # ------------------------------------------------------------------
    def read(self) -> pd.DataFrame:
        """Orquestra leitura e validação, retornando o DataFrame final."""
        self._validate_path()
        df = self._load_dataframe()
        df = self._validate_and_normalize_columns(df)
        df = self._parse_dates(df)
        df = self._coerce_glu(df)
        df = self._coerce_ids(df)
        return df

    # ------------------------------------------------------------------
    # Métodos internos
    # ------------------------------------------------------------------
    def _validate_path(self) -> None:
        if self._from_bytes:
            suffix = Path(self._filename).suffix.lower()
            if suffix not in self.SUPPORTED_EXTENSIONS:
                raise ValueError(
                    f"Extensão '{suffix}' não é suportada. "
                    f"Extensões válidas: {', '.join(self.SUPPORTED_EXTENSIONS)}"
                )
            return

        if not self._path.exists():
            potential_path = SPREADSHEET_DIR / self._path.name
            if potential_path.exists():
                self._path = potential_path
            else:
                raise FileNotFoundError(
                    f"Arquivo não encontrado: {self._path}"
                )

        if self._path.suffix.lower() not in self.SUPPORTED_EXTENSIONS:
            raise ValueError(
                f"Extensão '{self._path.suffix}' não é suportada. "
                f"Extensões válidas: {', '.join(self.SUPPORTED_EXTENSIONS)}"
            )

    def _load_dataframe(self) -> pd.DataFrame:
        if self._from_bytes:
            return pd.read_excel(io.BytesIO(self._content))
        return pd.read_excel(self._path)

    @staticmethod
    def _validate_schema(schema: ColumnSchema) -> None:
        if not isinstance(schema, list) or len(schema) == 0:
            raise ValueError(
                "SPREADSHEET_COLUMNS deve ser uma lista não-vazia."
            )

        for i, item in enumerate(schema):
            if isinstance(item, str):
                continue
            if isinstance(item, list):
                if len(item) == 0:
                    raise ValueError(
                        f"Elemento na posição {i} é uma lista vazia. "
                        "Listas internas devem conter ao menos um nome."
                    )
                if not all(isinstance(s, str) for s in item):
                    raise ValueError(
                        f"Elemento na posição {i} contém valores não-string. "
                        "Listas internas só podem conter strings."
                    )
            else:
                raise ValueError(
                    f"Elemento na posição {i} tem tipo inválido "
                    f"({type(item).__name__}). Esperado: str ou list[str]."
                )

    def _validate_and_normalize_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        actual_columns = list(df.columns)

        if len(actual_columns) < len(self._schema):
            raise ValueError(
                f"A planilha possui {len(actual_columns)} coluna(s), "
                f"mas o schema exige pelo menos {len(self._schema)}."
            )

        rename_map: dict[str, str] = {}

        for i, expected in enumerate(self._schema):
            actual = actual_columns[i]

            if isinstance(expected, str):
                if actual != expected:
                    raise ValueError(
                        f"Coluna na posição {i}: esperado '{expected}', "
                        f"encontrado '{actual}'."
                    )
            else:
                canonical = expected[0]
                if actual not in expected:
                    raise ValueError(
                        f"Coluna na posição {i}: esperado um de "
                        f"{expected}, encontrado '{actual}'."
                    )
                if actual != canonical:
                    rename_map[actual] = canonical

        if rename_map:
            df = df.rename(columns=rename_map)

        return df

    def _parse_dates(self, df: pd.DataFrame) -> pd.DataFrame:
        if "Test Date/Time" in df.columns:
            df["Test Date/Time"] = pd.to_datetime(df["Test Date/Time"], errors="coerce")
        return df

    def _coerce_glu(self, df: pd.DataFrame) -> pd.DataFrame:
        if "GLU" in df.columns:
            df["GLU"] = pd.to_numeric(df["GLU"], errors="coerce").astype("Int64")
        return df

    def _coerce_ids(self, df: pd.DataFrame) -> pd.DataFrame:
        for col in ("Patient ID", "Operator ID"):
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").astype("Int64")
        return df
