"""Agregações estatísticas sobre indicadores."""

from __future__ import annotations

from typing import Any

import pandas as pd

from openheal.endocrinology.abbott_system.stats.base_indicator import BaseIndicator


class Aggregator(BaseIndicator):
    """Calcula agregações sobre os resultados dos indicadores."""

    def calculate(self, df: pd.DataFrame, **kwargs: Any) -> pd.DataFrame | pd.Series:
        return self.mean_and_std(df, **kwargs)

    @staticmethod
    def mean_and_std(
        df: pd.DataFrame,
        value_col: str = "GLU",
        group_by: str | list[str] | None = None,
    ) -> pd.DataFrame:
        if group_by is None:
            return pd.DataFrame(
                [{"mean": df[value_col].mean(), "std": df[value_col].std()}]
            )

        groups = [group_by] if isinstance(group_by, str) else list(group_by)
        return (
            df.groupby(groups, as_index=False)[value_col]
            .agg(["mean", "std"])
            .reset_index()
        )

    @staticmethod
    def mean_of_daily_means(
        df: pd.DataFrame,
        value_col: str = "GLU",
        entity_col: str = "Patient ID",
        date_col: str = "Test Date/Time",
    ) -> pd.DataFrame:
        work = df.copy()
        work["_date"] = pd.to_datetime(work[date_col]).dt.date

        daily_means = (
            work.groupby([entity_col, "_date"], as_index=False)[value_col]
            .mean()
            .rename(columns={value_col: "_daily_mean"})
        )

        result = (
            daily_means.groupby(entity_col, as_index=False)["_daily_mean"]
            .mean()
            .rename(columns={"_daily_mean": "daily_mean_of_means"})
        )

        return result

    @staticmethod
    def event_day_rate(
        events_df: pd.DataFrame,
        patient_day_df: pd.DataFrame,
    ) -> pd.DataFrame:
        total_patient_days = int(patient_day_df["unique_patients"].sum())

        if events_df.empty or total_patient_days == 0:
            return pd.DataFrame(
                [
                    {
                        "total_patient_days": total_patient_days,
                        "days_with_event": 0,
                        "event_day_rate": 0.0,
                    }
                ]
            )

        days_with_event = events_df.groupby("date")["Patient ID"].nunique().sum()

        rate = days_with_event / total_patient_days if total_patient_days > 0 else 0.0

        return pd.DataFrame(
            [
                {
                    "total_patient_days": total_patient_days,
                    "days_with_event": int(days_with_event),
                    "event_day_rate": rate,
                }
            ]
        )
