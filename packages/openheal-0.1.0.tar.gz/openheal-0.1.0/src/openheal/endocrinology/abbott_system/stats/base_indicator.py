"""Classe base abstrata para todos os indicadores estatísticos."""

from __future__ import annotations

import calendar
from abc import ABC, abstractmethod
from typing import Any

import pandas as pd

# Portuguese month abbreviations (1-indexed)
_MONTH_ABBR: dict[int, str] = {
    1: "Jan", 2: "Fev", 3: "Mar", 4: "Abr",
    5: "Mai", 6: "Jun", 7: "Jul", 8: "Ago",
    9: "Set", 10: "Out", 11: "Nov", 12: "Dez",
}


class BaseIndicator(ABC):
    """Fornece interface comum e utilitários compartilhados entre indicadores."""

    @staticmethod
    def add_month_labels(
        df: pd.DataFrame,
        date_col: str = "Test Date/Time",
    ) -> pd.DataFrame:
        result = df.copy()
        dt = pd.to_datetime(result[date_col])
        result["_period"] = dt.dt.to_period("M")
        result["_day"] = dt.dt.date

        days_per_month = (
            result.groupby("_period")["_day"].nunique().to_dict()
        )

        labels: dict = {}
        for period, n_days in days_per_month.items():
            total_days = calendar.monthrange(period.year, period.month)[1]
            label = f"{_MONTH_ABBR[period.month]}/{period.year}"
            if n_days < total_days:
                label += f" ({n_days}d)"
            labels[period] = label

        result["month_label"] = result["_period"].map(labels)
        result.drop(columns=["_period", "_day"], inplace=True)
        return result

    @staticmethod
    def _filter_valid(df: pd.DataFrame) -> pd.DataFrame:
        result = df.copy()

        if "Excluded" in result.columns:
            result = result[result["Excluded"] != True]  # noqa: E712

        if "Result Type" in result.columns:
            result = result[result["Result Type"] == "Patient"]

        return result.reset_index(drop=True)

    @staticmethod
    def _extract_date(df: pd.DataFrame, col: str = "Test Date/Time") -> pd.Series:
        return pd.to_datetime(df[col]).dt.date

    @abstractmethod
    def calculate(self, df: pd.DataFrame, **kwargs: Any) -> pd.DataFrame | pd.Series:
        ...
