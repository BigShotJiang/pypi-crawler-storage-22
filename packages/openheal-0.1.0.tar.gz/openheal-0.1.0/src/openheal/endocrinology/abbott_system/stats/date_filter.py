"""Filtro de DataFrame por intervalo de datas."""

from __future__ import annotations

from datetime import date, datetime
from typing import Union

import pandas as pd


class DateFilter:
    """Extrai o range de datas e filtra o DataFrame por período."""

    DATE_COL = "Test Date/Time"

    def get_date_range(self, df: pd.DataFrame) -> dict[str, str]:
        self._validate_date_column(df)

        dates = pd.to_datetime(df[self.DATE_COL], errors="coerce").dropna()

        if dates.empty:
            raise ValueError(
                f"Nenhuma data válida encontrada na coluna '{self.DATE_COL}'."
            )

        return {
            "min_date": str(dates.min().date()),
            "max_date": str(dates.max().date()),
        }

    def filter_by_date(
        self,
        df: pd.DataFrame,
        start_date: Union[str, date, datetime, None] = None,
        end_date: Union[str, date, datetime, None] = None,
    ) -> pd.DataFrame:
        if start_date is None and end_date is None:
            return df.copy()

        self._validate_date_column(df)

        ts_start = (
            pd.Timestamp(start_date).normalize() if start_date is not None else None
        )
        ts_end = (
            pd.Timestamp(end_date).normalize() if end_date is not None else None
        )

        if ts_start is not None and ts_end is not None and ts_start > ts_end:
            raise ValueError(
                f"start_date ({ts_start.date()}) não pode ser posterior "
                f"a end_date ({ts_end.date()})."
            )

        dates = pd.to_datetime(df[self.DATE_COL], errors="coerce").dt.normalize()
        df_min = dates.min()
        df_max = dates.max()

        if ts_start is not None and ts_start > df_max:
            raise ValueError(
                f"start_date ({ts_start.date()}) é posterior à última data "
                f"do DataFrame ({df_max.date()})."
            )
        if ts_end is not None and ts_end < df_min:
            raise ValueError(
                f"end_date ({ts_end.date()}) é anterior à primeira data "
                f"do DataFrame ({df_min.date()})."
            )

        mask = pd.Series(True, index=df.index)

        if ts_start is not None:
            mask = mask & (dates >= ts_start)
        if ts_end is not None:
            mask = mask & (dates <= ts_end)

        return df[mask].copy().reset_index(drop=True)

    def _validate_date_column(self, df: pd.DataFrame) -> None:
        if df.empty:
            raise ValueError("O DataFrame está vazio.")
        if self.DATE_COL not in df.columns:
            raise ValueError(
                f"Coluna '{self.DATE_COL}' não encontrada no DataFrame."
            )
