"""Estatísticas agregadas sobre erros de validação de ID."""

from __future__ import annotations

from datetime import date, datetime
from typing import Union

import pandas as pd


class ErrorStatistics:
    """Recebe o DataFrame de erros de ``IdValidator.validate`` e retorna
    contagens agrupadas por **Facility**, **Location** e **tipo de erro**.
    """

    _GROUP_COLS = ["Facility", "Location", "validation_error"]
    _DATE_COL = "Test Date/Time"

    def __init__(
        self,
        start_date: Union[str, datetime, date, None] = None,
        end_date: Union[str, datetime, date, None] = None,
    ) -> None:
        self._start_date = pd.Timestamp(start_date).normalize() if start_date else None
        self._end_date = pd.Timestamp(end_date).normalize() if end_date else None

    def calculate(self, errors_df: pd.DataFrame) -> pd.DataFrame:
        if errors_df.empty:
            return pd.DataFrame(columns=[*self._GROUP_COLS, "count"])

        filtered = self._filter_by_date(errors_df)

        if filtered.empty:
            return pd.DataFrame(columns=[*self._GROUP_COLS, "count"])

        result = (
            filtered
            .groupby(self._GROUP_COLS, dropna=False)
            .size()
            .reset_index(name="count")
        )

        return result

    def _filter_by_date(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._start_date is None and self._end_date is None:
            return df

        if self._DATE_COL not in df.columns:
            return df

        dates = pd.to_datetime(df[self._DATE_COL], errors="coerce").dt.normalize()
        mask = pd.Series(True, index=df.index)

        if self._start_date is not None:
            mask = mask & (dates >= self._start_date)
        if self._end_date is not None:
            mask = mask & (dates <= self._end_date)

        return df[mask]
