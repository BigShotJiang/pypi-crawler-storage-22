"""Contador de eventos glicêmicos com regra de reset."""

from __future__ import annotations

from typing import Any

import pandas as pd

from openheal.endocrinology.abbott_system.config import HYPO
from openheal.endocrinology.abbott_system.stats.base_indicator import BaseIndicator


class EventCounter(BaseIndicator):
    """Identifica e conta eventos glicêmicos usando a regra de reset."""

    DIRECTION_BELOW = "below"
    DIRECTION_ABOVE = "above"

    def __init__(
        self,
        cutoff: int | None = None,
        direction: str = DIRECTION_BELOW,
    ) -> None:
        self._cutoff = cutoff if cutoff is not None else HYPO
        if direction not in (self.DIRECTION_BELOW, self.DIRECTION_ABOVE):
            raise ValueError(
                f"direction deve ser '{self.DIRECTION_BELOW}' ou "
                f"'{self.DIRECTION_ABOVE}', recebeu '{direction}'."
            )
        self._direction = direction

    @property
    def cutoff(self) -> int:
        return self._cutoff

    @property
    def direction(self) -> str:
        return self._direction

    _EXTRA_COLS = ("Facility", "Location", "month_label")

    def calculate(self, df: pd.DataFrame, **kwargs: Any) -> pd.DataFrame:
        work = df.copy()
        work["_date"] = pd.to_datetime(work["Test Date/Time"]).dt.date
        work = work.sort_values(["Patient ID", "Test Date/Time"]).reset_index(drop=True)

        events: list[dict[str, Any]] = []

        for (patient_id, date), group in work.groupby(["Patient ID", "_date"]):
            first = group.iloc[0]
            extras = {c: first.get(c) for c in self._EXTRA_COLS if c in group.columns}
            events.extend(self._detect_events_in_group(patient_id, date, group, extras))

        base_cols = [
            "Patient ID", "Facility", "Location", "date",
            "event_number", "event_start_time", "event_start_glu",
        ]
        if not events:
            return pd.DataFrame(columns=base_cols)

        return pd.DataFrame(events)

    def _is_beyond_cutoff(self, glu: float) -> bool:
        if self._direction == self.DIRECTION_BELOW:
            return glu <= self._cutoff
        return glu >= self._cutoff

    def _detect_events_in_group(
        self,
        patient_id: Any,
        date: Any,
        group: pd.DataFrame,
        extras: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        events: list[dict[str, Any]] = []
        in_event = False
        event_num = 0
        extra_fields = extras or {}

        for _, row in group.iterrows():
            glu = row["GLU"]
            test_time = row["Test Date/Time"]

            if pd.isna(glu):
                continue

            if not in_event and self._is_beyond_cutoff(glu):
                event_num += 1
                in_event = True
                events.append(
                    {
                        "Patient ID": patient_id,
                        **extra_fields,
                        "date": date,
                        "event_number": event_num,
                        "event_start_time": test_time,
                        "event_start_glu": glu,
                    }
                )
            elif in_event and not self._is_beyond_cutoff(glu):
                in_event = False

        return events
