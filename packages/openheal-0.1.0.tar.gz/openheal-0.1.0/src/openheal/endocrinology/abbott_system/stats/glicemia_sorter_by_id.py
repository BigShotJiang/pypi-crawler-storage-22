import pandas as pd


class GlicemiaSorterByID:
    """Classe responsável por ordenar os dados de glicemia."""

    def sort(self, df: pd.DataFrame) -> pd.DataFrame:
        """Retorna um novo DataFrame ordenado por 'Patient ID' e 'Test Date/Time'."""
        df_sorted = df.sort_values(by=["Patient ID", "Test Date/Time"], ascending=[True, True])

        cols = list(df_sorted.columns)
        if "Patient ID" in cols:
            cols.remove("Patient ID")
            cols.insert(0, "Patient ID")

        return df_sorted[cols]
