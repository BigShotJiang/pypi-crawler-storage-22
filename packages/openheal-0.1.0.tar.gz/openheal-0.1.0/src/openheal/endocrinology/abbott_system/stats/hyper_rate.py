"""Indicador de taxa de hiperglicemia."""

from __future__ import annotations

from typing import Any

import pandas as pd

from openheal.endocrinology.abbott_system.config import HYPER
from openheal.endocrinology.abbott_system.stats.base_indicator import BaseIndicator


class HyperRate(BaseIndicator):
    """Calcula a taxa de hiperglicemia: (testes ≥ cutoff) / total de testes."""

    def __init__(self, cutoff: int | None = None) -> None:
        self._cutoff = cutoff if cutoff is not None else HYPER

    @property
    def cutoff(self) -> int:
        return self._cutoff

    def calculate(
        self,
        df: pd.DataFrame,
        group_by: str | list[str] | None = None,
        **kwargs: Any,
    ) -> pd.DataFrame:
        if group_by is None:
            total = len(df)
            hyper_count = int((df["GLU"] >= self._cutoff).sum())
            rate = hyper_count / total if total > 0 else 0.0
            return pd.DataFrame(
                [{"total_tests": total, "hyper_count": hyper_count, "hyper_rate": rate}]
            )

        groups = [group_by] if isinstance(group_by, str) else list(group_by)
        result = (
            df.groupby(groups, as_index=False)
            .agg(
                total_tests=("GLU", "size"),
                hyper_count=("GLU", lambda s: (s >= self._cutoff).sum()),
            )
        )
        result["hyper_rate"] = result["hyper_count"] / result["total_tests"]
        return result
