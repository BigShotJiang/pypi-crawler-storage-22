"""Validador de IDs de paciente e operador (Step A do pipeline)."""

from __future__ import annotations

import pandas as pd

from openheal.endocrinology.abbott_system.config import PATIENT_ID_MIN, PATIENT_ID_MAX


class IdValidator:
    """Identifica registros com erros de validação em IDs."""

    def __init__(
        self,
        id_min: int | None = None,
        id_max: int | None = None,
    ) -> None:
        self._id_min = id_min if id_min is not None else PATIENT_ID_MIN
        self._id_max = id_max if id_max is not None else PATIENT_ID_MAX

    @property
    def id_min(self) -> int:
        return self._id_min

    @property
    def id_max(self) -> int:
        return self._id_max

    def validate(self, df: pd.DataFrame) -> pd.DataFrame:
        error_frames: list[pd.DataFrame] = []

        error_frames.append(self._check_not_numeric(df))
        error_frames.append(self._check_conflict(df))
        error_frames.append(self._check_out_of_range(df))

        result = pd.concat(error_frames)
        return result

    @staticmethod
    def exclude(df: pd.DataFrame, indices: list[int]) -> pd.DataFrame:
        return df.drop(index=indices)

    def _check_conflict(self, df: pd.DataFrame) -> pd.DataFrame:
        valid_mask = df["Patient ID"].notna() & df["Operator ID"].notna()
        conflict_mask = valid_mask & (df["Patient ID"] == df["Operator ID"])
        matched = df[conflict_mask].copy()
        matched["validation_error"] = "operator_equals_patient"
        return matched

    def _check_out_of_range(self, df: pd.DataFrame) -> pd.DataFrame:
        numeric_mask = df["Patient ID"].notna()
        out_mask = numeric_mask & (
            (df["Patient ID"] < self._id_min)
            | (df["Patient ID"] > self._id_max)
        )
        matched = df[out_mask].copy()
        matched["validation_error"] = "patient_id_out_of_range"
        return matched

    def _check_not_numeric(self, df: pd.DataFrame) -> pd.DataFrame:
        na_mask = df["Patient ID"].isna()
        matched = df[na_mask].copy()
        matched["validation_error"] = "patient_id_not_numeric"
        return matched
