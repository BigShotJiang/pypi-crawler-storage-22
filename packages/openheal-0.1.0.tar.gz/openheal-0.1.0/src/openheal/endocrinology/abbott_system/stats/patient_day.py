"""Indicador Paciente-Dia."""

from __future__ import annotations

from enum import Enum
from typing import Any

import pandas as pd

from openheal.endocrinology.abbott_system.config import CRITICAL_HYPER, CRITICAL_HYPO, HYPER, HYPO
from openheal.endocrinology.abbott_system.stats.base_indicator import BaseIndicator


class GlycemicCategory(Enum):
    """Categorias suportadas para o cálculo de paciente-dia."""

    ALL_HYPO = (HYPO, "below")
    ALL_HYPER = (HYPER, "above")
    ONLY_CRITICAL_HYPO = (CRITICAL_HYPO, "below")
    ONLY_CRITICAL_HYPER = (CRITICAL_HYPER, "above")

    @property
    def cutoff(self) -> int:
        return self.value[0]

    @property
    def direction(self) -> str:
        return self.value[1]


class PatientDay(BaseIndicator):
    """Calcula métricas usando a metodologia paciente-dia."""

    def __init__(self, category: GlycemicCategory) -> None:
        self._category = category
        self._cutoff = category.cutoff
        self._direction = category.direction

    @property
    def category(self) -> GlycemicCategory:
        return self._category

    @property
    def cutoff(self) -> int:
        return self._cutoff

    @property
    def direction(self) -> str:
        return self._direction

    def calculate(
        self,
        df: pd.DataFrame,
        group_by: str | list[str] | None = None,
        **kwargs: Any,
    ) -> pd.DataFrame:
        work = df.copy()
        work["_date"] = pd.to_datetime(work["Test Date/Time"]).dt.date

        if self._direction == "below":
            work["_is_event"] = work["GLU"] <= self._cutoff
        else:
            work["_is_event"] = work["GLU"] >= self._cutoff

        if group_by is None:
            group_keys = ["_date"]
        else:
            extra = [group_by] if isinstance(group_by, str) else list(group_by)
            group_keys = ["_date"] + extra

        denominator = (
            work.groupby(group_keys, as_index=False)["Patient ID"]
            .nunique()
            .rename(columns={"Patient ID": "unique_patients"})
        )

        events = work[work["_is_event"].fillna(False)]
        numerator = (
            events.groupby(group_keys, as_index=False)["Patient ID"]
            .nunique()
            .rename(columns={"Patient ID": "patients_with_event"})
        )

        result = denominator.merge(numerator, on=group_keys, how="left")
        result["patients_with_event"] = result["patients_with_event"].fillna(0).astype(int)
        result["patient_day_rate"] = (
            result["patients_with_event"] / result["unique_patients"]
        )

        result = result.rename(columns={"_date": "date"})
        return result
