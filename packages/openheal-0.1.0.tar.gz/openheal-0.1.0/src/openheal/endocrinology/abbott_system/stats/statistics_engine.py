"""Orquestrador de todos os indicadores estatísticos."""

from __future__ import annotations

from typing import Any

import pandas as pd

from openheal.endocrinology.abbott_system.config import CRITICAL_HYPO, CRITICAL_HYPER, HYPO, HYPER
from openheal.endocrinology.abbott_system.stats.base_indicator import BaseIndicator
from openheal.endocrinology.abbott_system.stats.hypo_rate import HypoRate
from openheal.endocrinology.abbott_system.stats.hyper_rate import HyperRate
from openheal.endocrinology.abbott_system.stats.patient_day import GlycemicCategory, PatientDay
from openheal.endocrinology.abbott_system.stats.event_counter import EventCounter
from openheal.endocrinology.abbott_system.stats.time_to_correction import TimeToCorrection
from openheal.endocrinology.abbott_system.stats.aggregator import Aggregator


class StatisticsEngine:
    """Instancia e executa todos os indicadores em sequência."""

    def __init__(self) -> None:
        # Taxas
        self.hypo_rate = HypoRate(cutoff=HYPO)
        self.critical_hypo_rate = HypoRate(cutoff=CRITICAL_HYPO)
        self.hyper_rate = HyperRate(cutoff=HYPER)
        self.critical_hyper_rate = HyperRate(cutoff=CRITICAL_HYPER)

        # Paciente-dia
        self.patient_day_hypo = PatientDay(GlycemicCategory.ALL_HYPO)
        self.patient_day_critical_hypo = PatientDay(GlycemicCategory.ONLY_CRITICAL_HYPO)
        self.patient_day_hyper = PatientDay(GlycemicCategory.ALL_HYPER)
        self.patient_day_critical_hyper = PatientDay(GlycemicCategory.ONLY_CRITICAL_HYPER)

        # Eventos
        self.event_counter_hypo = EventCounter(cutoff=HYPO, direction="below")
        self.event_counter_critical_hypo = EventCounter(cutoff=CRITICAL_HYPO, direction="below")
        self.event_counter_hyper = EventCounter(cutoff=HYPER, direction="above")
        self.event_counter_critical_hyper = EventCounter(cutoff=CRITICAL_HYPER, direction="above")

        # Tempo até correção
        self.ttc_hypo = TimeToCorrection(cutoff=HYPO, direction="below")
        self.ttc_critical_hypo = TimeToCorrection(cutoff=CRITICAL_HYPO, direction="below")
        self.ttc_hyper = TimeToCorrection(cutoff=HYPER, direction="above")
        self.ttc_critical_hyper = TimeToCorrection(cutoff=CRITICAL_HYPER, direction="above")

        # Agregador
        self.aggregator = Aggregator()

    def run_all(
        self,
        df: pd.DataFrame,
        group_by: str | list[str] | None = None,
        group_by_month: bool = False,
    ) -> dict[str, Any]:
        """Executa todos os indicadores e retorna dict consolidado."""
        valid = BaseIndicator._filter_valid(df)

        if group_by_month:
            valid = BaseIndicator.add_month_labels(valid)
            if group_by is None:
                group_by = "month_label"
            elif isinstance(group_by, str):
                group_by = [group_by, "month_label"]
            else:
                group_by = list(group_by) + ["month_label"]

        rates = {
            "hypo_rate": self.hypo_rate.calculate(valid, group_by=group_by),
            "critical_hypo_rate": self.critical_hypo_rate.calculate(valid, group_by=group_by),
            "hyper_rate": self.hyper_rate.calculate(valid, group_by=group_by),
            "critical_hyper_rate": self.critical_hyper_rate.calculate(valid, group_by=group_by),
        }

        patient_days = {
            "patient_day_hypo": self.patient_day_hypo.calculate(valid, group_by=group_by),
            "patient_day_critical_hypo": self.patient_day_critical_hypo.calculate(valid, group_by=group_by),
            "patient_day_hyper": self.patient_day_hyper.calculate(valid, group_by=group_by),
            "patient_day_critical_hyper": self.patient_day_critical_hyper.calculate(valid, group_by=group_by),
        }

        events = {
            "events_hypo": self.event_counter_hypo.calculate(valid),
            "events_critical_hypo": self.event_counter_critical_hypo.calculate(valid),
            "events_hyper": self.event_counter_hyper.calculate(valid),
            "events_critical_hyper": self.event_counter_critical_hyper.calculate(valid),
        }

        ttc = {
            "ttc_hypo": self.ttc_hypo.calculate(valid, events["events_hypo"]),
            "ttc_critical_hypo": self.ttc_critical_hypo.calculate(valid, events["events_critical_hypo"]),
            "ttc_hyper": self.ttc_hyper.calculate(valid, events["events_hyper"]),
            "ttc_critical_hyper": self.ttc_critical_hyper.calculate(valid, events["events_critical_hyper"]),
        }

        aggregations = {
            "mean_std": self.aggregator.mean_and_std(valid, group_by=group_by),
            "mean_of_daily_means": self.aggregator.mean_of_daily_means(valid),
            "event_day_hypo": self.aggregator.event_day_rate(
                events["events_hypo"],
                patient_days["patient_day_hypo"],
            ),
            "event_day_hyper": self.aggregator.event_day_rate(
                events["events_hyper"],
                patient_days["patient_day_hyper"],
            ),
        }

        return {
            "rates": rates,
            "patient_days": patient_days,
            "events": events,
            "time_to_correction": ttc,
            "aggregations": aggregations,
        }
