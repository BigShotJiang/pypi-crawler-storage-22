"""Indicador de tempo até correção de evento glicêmico."""

from __future__ import annotations

from typing import Any

import pandas as pd

from openheal.endocrinology.abbott_system.config import HYPO
from openheal.endocrinology.abbott_system.stats.base_indicator import BaseIndicator


class TimeToCorrection(BaseIndicator):
    """Calcula o tempo entre o início de um evento e o retorno à zona segura."""

    DIRECTION_BELOW = "below"
    DIRECTION_ABOVE = "above"

    def __init__(
        self,
        cutoff: int | None = None,
        direction: str = DIRECTION_BELOW,
    ) -> None:
        self._cutoff = cutoff if cutoff is not None else HYPO
        if direction not in (self.DIRECTION_BELOW, self.DIRECTION_ABOVE):
            raise ValueError(
                f"direction deve ser '{self.DIRECTION_BELOW}' ou "
                f"'{self.DIRECTION_ABOVE}', recebeu '{direction}'."
            )
        self._direction = direction

    @property
    def cutoff(self) -> int:
        return self._cutoff

    _EXTRA_COLS = ("Facility", "Location", "month_label")

    def calculate(
        self,
        df: pd.DataFrame,
        events_df: pd.DataFrame,
        **kwargs: Any,
    ) -> pd.DataFrame:
        base_cols = [
            "Patient ID", "Facility", "Location", "date",
            "event_number", "event_start_time",
            "correction_time", "correction_time_minutes",
        ]

        if events_df.empty:
            return pd.DataFrame(columns=base_cols)

        work = df.copy()
        work["Test Date/Time"] = pd.to_datetime(work["Test Date/Time"])
        work["_date"] = work["Test Date/Time"].dt.date
        work = work.sort_values(["Patient ID", "Test Date/Time"]).reset_index(drop=True)

        results: list[dict[str, Any]] = []

        for _, event in events_df.iterrows():
            patient_id = event["Patient ID"]
            date = event["date"]
            event_start = pd.to_datetime(event["event_start_time"])

            extras = {c: event.get(c) for c in self._EXTRA_COLS if c in events_df.columns}

            correction = self._find_correction(work, patient_id, date, event_start)
            results.append(
                {
                    "Patient ID": patient_id,
                    **extras,
                    "date": date,
                    "event_number": event["event_number"],
                    "event_start_time": event_start,
                    **correction,
                }
            )

        return pd.DataFrame(results)

    def _is_in_safe_zone(self, glu: float) -> bool:
        if self._direction == self.DIRECTION_BELOW:
            return glu > self._cutoff
        return glu < self._cutoff

    def _find_correction(
        self,
        work: pd.DataFrame,
        patient_id: Any,
        date: Any,
        event_start: pd.Timestamp,
    ) -> dict[str, Any]:
        mask = (
            (work["Patient ID"] == patient_id)
            & (work["_date"] == date)
            & (work["Test Date/Time"] > event_start)
        )
        subsequent = work[mask]

        for _, row in subsequent.iterrows():
            if self._is_in_safe_zone(row["GLU"]):
                correction_time = row["Test Date/Time"] - event_start
                return {
                    "correction_time": correction_time,
                    "correction_time_minutes": correction_time.total_seconds() / 60,
                }

        return {"correction_time": None, "correction_time_minutes": None}
