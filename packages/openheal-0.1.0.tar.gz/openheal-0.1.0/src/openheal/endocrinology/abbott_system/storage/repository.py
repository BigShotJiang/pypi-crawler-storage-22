"""Repositório abstrato e implementação em memória para dados de planilha por sessão."""

from __future__ import annotations

from abc import ABC, abstractmethod

import pandas as pd


class SessionNotFoundError(LookupError):
    """Sessão não encontrada no repositório."""

    def __init__(self, session_id: str) -> None:
        self.session_id = session_id
        super().__init__(f"Sessão não encontrada: {session_id}")


class AbstractSpreadsheetRepository(ABC):
    """Contrato para armazenamento de DataFrames de planilha por session_id."""

    @abstractmethod
    def save(self, session_id: str, df: pd.DataFrame) -> None:
        ...

    @abstractmethod
    def get(self, session_id: str) -> pd.DataFrame:
        ...

    @abstractmethod
    def exists(self, session_id: str) -> bool:
        ...

    @abstractmethod
    def delete(self, session_id: str) -> None:
        ...


class InMemorySpreadsheetRepository(AbstractSpreadsheetRepository):
    """Implementação em memória: armazena DataFrames em um dicionário por session_id."""

    def __init__(self) -> None:
        self._store: dict[str, pd.DataFrame] = {}

    def save(self, session_id: str, df: pd.DataFrame) -> None:
        self._store[session_id] = df.copy()

    def get(self, session_id: str) -> pd.DataFrame:
        if session_id not in self._store:
            raise SessionNotFoundError(session_id)
        return self._store[session_id].copy()

    def exists(self, session_id: str) -> bool:
        return session_id in self._store

    def delete(self, session_id: str) -> None:
        self._store.pop(session_id, None)
