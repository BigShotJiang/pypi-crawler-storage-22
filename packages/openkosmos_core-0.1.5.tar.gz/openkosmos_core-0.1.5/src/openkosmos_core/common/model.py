from pydantic import BaseModel


class BaseConfig(BaseModel):
    pass
