"""
<description not available>
"""

# this file was auto-generated!

from openminds.base import IRI

from openminds.base import LinkedMetadata
from openminds.properties import Property


class Terminology(LinkedMetadata):
    """
    <description not available>
    """

    type_ = "https://openminds.om-i.org/types/Terminology"
    context = {"@vocab": "https://openminds.om-i.org/props/"}
    schema_version = "latest"

    properties = [
        Property(
            "definition",
            str,
            "definition",
            formatting="text/markdown",
            multiline=True,
            description="Short, but precise statement of the meaning of a word, word group, sign or a symbol.",
            instructions="Enter one sentence for defining this term.",
        ),
        Property(
            "description",
            str,
            "description",
            formatting="text/markdown",
            multiline=True,
            description="Longer statement or account giving the characteristics of the terminology.",
            instructions="Enter a short text describing this term.",
        ),
        Property(
            "interlex_identifier",
            IRI,
            "interlexIdentifier",
            description="Persistent identifier for a term registered in the InterLex project.",
            instructions="Enter the internationalized resource identifier (IRI) pointing to the integrated ontology entry in the InterLex project.",
        ),
        Property(
            "knowledge_space_link",
            IRI,
            "knowledgeSpaceLink",
            description="Persistent link to an encyclopedia entry in the Knowledge Space project.",
            instructions="Enter the internationalized resource identifier (IRI) pointing to the wiki page of the corresponding term in the KnowledgeSpace.",
        ),
        Property(
            "name",
            str,
            "name",
            formatting="text/plain",
            required=True,
            description="Word or phrase that constitutes the distinctive designation of the terminology.",
            instructions="Controlled term originating from a defined terminology.",
        ),
        Property(
            "preferred_ontology_identifier",
            IRI,
            "preferredOntologyIdentifier",
            description="Persistent identifier of a preferred ontological term.",
            instructions="Enter the internationalized resource identifier (IRI) pointing to the preferred ontological term.",
        ),
        Property(
            "synonyms",
            str,
            "synonym",
            multiple=True,
            unique_items=True,
            min_items=1,
            formatting="text/plain",
            description="Words or expressions used in the same language that have the same or nearly the same meaning in some or all senses.",
            instructions="Enter one or several synonyms (including abbreviations) for this controlled term.",
        ),
    ]

    def __init__(
        self,
        id=None,
        definition=None,
        description=None,
        interlex_identifier=None,
        knowledge_space_link=None,
        name=None,
        preferred_ontology_identifier=None,
        synonyms=None,
    ):
        return super().__init__(
            id=id,
            definition=definition,
            description=description,
            interlex_identifier=interlex_identifier,
            knowledge_space_link=knowledge_space_link,
            name=name,
            preferred_ontology_identifier=preferred_ontology_identifier,
            synonyms=synonyms,
        )

    @classmethod
    def instances(cls):
        return [value for value in cls.__dict__.values() if isinstance(value, cls)]

    @classmethod
    def by_name(
        cls,
        name: str,
        match: str = "equals",
        all: bool = False,
    ):
        """
        Search for instances in the openMINDS instance library based on their name.

        This includes properties "name", "lookup_label", "family_name", "full_name", "short_name", "abbreviation", and "synonyms".

        Note that not all metadata classes have a name.

        Args:
            name (str): a string to search for.
            match (str, optional): either "equals" (exact match - default) or "contains".
            all (bool, optional): Whether to return all objects that match the name, or only the first. Defaults to False.
        """
        namelike_properties = ("name", "lookup_label", "family_name", "full_name", "short_name", "abbreviation")
        if cls._instance_lookup is None:
            cls._instance_lookup = {}
            for instance in cls.instances():
                keys = []
                for prop_name in namelike_properties:
                    if hasattr(instance, prop_name):
                        keys.append(getattr(instance, prop_name))
                if hasattr(instance, "synonyms"):
                    for synonym in instance.synonyms or []:
                        keys.append(synonym)
                for key in keys:
                    if key in cls._instance_lookup:
                        cls._instance_lookup[key].append(instance)
                    else:
                        cls._instance_lookup[key] = [instance]
        if match == "equals":
            matches = cls._instance_lookup.get(name, [])
        elif match == "contains":
            matches = []
            for key, instances in cls._instance_lookup.items():
                if name in key:
                    matches.extend(instances)
        else:
            raise ValueError("'match' must be either 'equals' or 'contains'")
        if not matches:
            return None
        elif all:
            return matches
        else:
            return matches[0]


Terminology.access_channel = Terminology(
    id="https://openminds.om-i.org/instances/terminology/accessChannel",
    definition="Terminology defining the location or medium through which a resource can be accessed.",
    description="The terminology defining access channel specifies whether a resource is accessible remotely through digital means (virtual), requires physical presence at a specific location (on-site), or is available through both means (hybrid).",
    name="access channel",
)
Terminology.access_eligibility_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/accessEligibilityType",
    definition="The terminology defining access eligibility type specifies whether a resource is openly available to anyone, requires authentication, or authorization.",
    name="access eligibility type",
)
Terminology.access_form = Terminology(
    id="https://openminds.om-i.org/instances/terminology/accessForm",
    definition="Terminology defining the manner in which access to a resource is facilitated.",
    description="The terminology defining access form specifies whether users obtain access directly without intermediaries or through mediation by a third party.",
    name="access form",
)
Terminology.access_process_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/accessProcessType",
    definition="Terminology defining the workflow or mechanism through which access to a resource is granted.",
    name="access process type",
)
Terminology.action_status_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/actionStatusType",
    name="action status type",
)
Terminology.age_category = Terminology(
    id="https://openminds.om-i.org/instances/terminology/ageCategory",
    definition="The age category describes a specific spatiotemporal part of the life cycle of an organism.",
    name="age category",
    preferred_ontology_identifier=IRI("http://purl.obolibrary.org/obo/UBERON_0000105"),
)
Terminology.analysis_technique = Terminology(
    id="https://openminds.om-i.org/instances/terminology/analysisTechnique",
    name="analysis technique",
)
Terminology.anatomical_axes_orientation = Terminology(
    id="https://openminds.om-i.org/instances/terminology/anatomicalAxesOrientation",
    name="anatomical axes orientation",
)
Terminology.anatomical_identification_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/anatomicalIdentificationType",
    definition="The type of identiciation that was used to determine an anatomical location.",
    name="anatomical identification type",
)
Terminology.anatomical_plane = Terminology(
    id="https://openminds.om-i.org/instances/terminology/anatomicalPlane",
    definition="A flat anatomical 2D surface that bisects an anatomical structure or an anatomical space.",
    interlex_identifier=IRI("http://uri.interlex.org/ilx_0725051"),
    name="anatomical plane",
    preferred_ontology_identifier=IRI("http://purl.obolibrary.org/obo/UBERON_0035085"),
    synonyms=["fiat anatomical surface"],
)
Terminology.annotation_criteria_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/annotationCriteriaType",
    definition="General classification of how data were annotated.",
    name="annotation criteria type",
)
Terminology.annotation_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/annotationType",
    definition="Geometrical classification of annotations into types.",
    name="annotation type",
)
Terminology.atlas_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/atlasType",
    name="atlas type",
)
Terminology.auditory_stimulus_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/auditoryStimulusType",
    definition="An 'auditory stimulus type' groups similar auditory stimuli used across auditory stimulation techniques.",
    name="auditory stimulus type",
)
Terminology.biological_order = Terminology(
    id="https://openminds.om-i.org/instances/terminology/biologicalOrder",
    name="biological order",
)
Terminology.biological_sex = Terminology(
    id="https://openminds.om-i.org/instances/terminology/biologicalSex",
    name="biological sex",
)
Terminology.breeding_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/breedingType",
    definition="The breeding type describes how plants or animals have been sexually propagated.",
    name="breeding type",
)
Terminology.cell_culture_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/cellCultureType",
    definition="The type of a cell culture (e.g. primary, secondary)",
    name="cell culture type",
)
Terminology.cell_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/cellType",
    name="cell type",
)
Terminology.chemical_mixture_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/chemicalMixtureType",
    definition="A 'chemical mixture type' groups all mixtures with the same chemical and physical characteristics under a general term.",
    name="chemicalMixtureType",
)
Terminology.colormap = Terminology(
    id="https://openminds.om-i.org/instances/terminology/colormap",
    definition="A colormap is a lookup table specifying the colors to be used in rendering a palettized image, [adapted from [Wiktionary](https://en.wiktionary.org/wiki/colormap)].",
    name="colormap",
)
Terminology.contribution_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/contributionType",
    name="contribution type",
)
Terminology.cranial_window_construction_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/cranialWindowConstructionType",
    definition="The construction type of a cranial window.",
    name="cranial window construction type",
)
Terminology.cranial_window_reinforcement_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/cranialWindowReinforcementType",
    definition="The reinforcement type of a cranial window.",
    name="cranial window reinforcement type",
)
Terminology.criteria_quality_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/criteriaQualityType",
    name="criteria quality type",
)
Terminology.data_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/dataType",
    name="data type",
)
Terminology.device_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/deviceType",
    name="device type",
)
Terminology.difference_measure = Terminology(
    id="https://openminds.om-i.org/instances/terminology/differenceMeasure",
    definition="A measure of the difference between two things",
    description="This may be a numerical or physical quantity, a set of categories, etc. Examples include 'mean squared error', 't-statistic', 'p-value'.",
    name="difference measure",
)
Terminology.disease = Terminology(
    id="https://openminds.om-i.org/instances/terminology/disease",
    name="disease",
)
Terminology.disease_model = Terminology(
    id="https://openminds.om-i.org/instances/terminology/diseaseModel",
    name="disease model",
)
Terminology.educational_level = Terminology(
    id="https://openminds.om-i.org/instances/terminology/educationalLevel",
    definition="An 'educational level' defines the developmental stage of a student and how learning environments are structured. ",
    name="educational level",
)
Terminology.electrical_stimulus_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/electricalStimulusType",
    definition="An 'electrical stimulus type' groups similar electrical stimuli used across electrical stimulation techniques.",
    name="electrical stimulus type",
)
Terminology.experimental_approach = Terminology(
    id="https://openminds.om-i.org/instances/terminology/experimentalApproach",
    name="experimental approach",
)
Terminology.file_bundle_grouping = Terminology(
    id="https://openminds.om-i.org/instances/terminology/fileBundleGrouping",
    name="file bundle grouping",
)
Terminology.file_repository_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/fileRepositoryType",
    name="file repository type",
)
Terminology.file_usage_role = Terminology(
    id="https://openminds.om-i.org/instances/terminology/fileUsageRole",
    name="file usage role",
)
Terminology.genetic_strain_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/geneticStrainType",
    definition="The genetic strain type describes the genetic background type of a strain.",
    name="genetic strain type",
)
Terminology.gustatory_stimulus_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/gustatoryStimulusType",
    definition="A 'gustatory stimulus type' groups similar gustatory stimuli used across gustatory stimulation techniques.",
    name="gustatory stimulus type",
)
Terminology.handedness = Terminology(
    id="https://openminds.om-i.org/instances/terminology/handedness",
    name="handedness",
)
Terminology.language = Terminology(
    id="https://openminds.om-i.org/instances/terminology/language",
    name="language",
)
Terminology.laterality = Terminology(
    id="https://openminds.om-i.org/instances/terminology/laterality",
    name="laterality",
)
Terminology.learning_resource_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/learningResourceType",
    definition="A 'learning resource type' groups persistent resources that explicitly entail learning activities or learning experiences in a certain format (e.g., in a physical or digital presentation).",
    name="learning resource type",
)
Terminology.measured_quantity = Terminology(
    id="https://openminds.om-i.org/instances/terminology/measuredQuantity",
    definition="A qualified physical quantity that was measured/recorded",
    name="measured quantity",
)
Terminology.measured_signal_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/measuredSignalType",
    definition="The types of biological electrical and non-electrical signals that vary in time and/or space and can be measured.",
    name="measured signal type",
)
Terminology.meta_data_model_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/metaDataModelType",
    name="(meta)data model type",
)
Terminology.model_abstraction_level = Terminology(
    id="https://openminds.om-i.org/instances/terminology/modelAbstractionLevel",
    name="model abstraction level",
)
Terminology.model_scope = Terminology(
    id="https://openminds.om-i.org/instances/terminology/modelScope",
    name="model scope",
)
Terminology.modification_consent_requirement = Terminology(
    id="https://openminds.om-i.org/instances/terminology/modificationConsentRequirement",
    definition="Terminology for specifying whose agreement is required for a contract modification to be legally valid.",
    name="modification consent requirement",
)
Terminology.modification_constraint = Terminology(
    id="https://openminds.om-i.org/instances/terminology/modificationConstraint",
    definition="Terminology for specifying procedural conditions or prohibitions that limit how modifications may be made.",
    name="modification constraint",
)
Terminology.modification_form = Terminology(
    id="https://openminds.om-i.org/instances/terminology/modificationForm",
    definition="Terminology for specifying the formal method by which consent to a modification must be expressed.",
    name="modification form",
)
Terminology.modification_scope = Terminology(
    id="https://openminds.om-i.org/instances/terminology/modificationScope",
    definition="Terminology for specifying which parts or aspects of an agreement may be modified.",
    name="modification scope",
)
Terminology.molecular_entity = Terminology(
    id="https://openminds.om-i.org/instances/terminology/molecularEntity",
    definition="Any constitutionally or isotopically distinct atom, molecule, ion, ion pair, radical, radical ion, complex, conformer etc., identifiable as a separately distinguishable entity.",
    interlex_identifier=IRI("http://uri.interlex.org/base/ilx_0107064"),
    knowledge_space_link=IRI("https://knowledge-space.org/wiki/CHEBI:23367#molecular-entity"),
    name="molecular entity",
    preferred_ontology_identifier=IRI("http://purl.obolibrary.org/obo/CHEBI_23367"),
)
Terminology.mr_spatial_encoding = Terminology(
    id="https://openminds.om-i.org/instances/terminology/MRSpatialEncoding",
    definition="MR spatial encoding type defines the method by which imaging data is collected, determining the spatial encoding strategy and affecting resolution, scan time, and overall image quality.",
    description="MR spatial encoding dictates how spatial and temporal information is encoded during image acquisition. It is classified based on the number of encoded dimensions: 2D acquisition captures individual slices sequentially using frequency * phase encoding, while 3D acquisition collects an entire volume in a single scan with frequency * phase * phase encoding, offering higher resolution and isotropic reconstruction. In rare cases, 1D acquisition is used for specialized applications like MR spectroscopy, encoding data along a single frequency dimension. The choice of acquisition type depends on clinical and research needs, balancing factors such as scan efficiency, spatial resolution, and signal-to-noise ratio.",
    name="MR spatial encoding",
    synonyms=["MRI acquisition type"],
)
Terminology.mri_pulse_sequence = Terminology(
    id="https://openminds.om-i.org/instances/terminology/MRIPulseSequence",
    definition="An 'MRI pulse sequence' is a particular setting of pulse sequences and pulsed field gradients, resulting in a particular image appearance [adapted from [Wikipedia](https://en.wikipedia.org/wiki/MRI_pulse_sequence)].",
    name="MRI pulse sequence",
)
Terminology.mri_weighting = Terminology(
    id="https://openminds.om-i.org/instances/terminology/MRIWeighting",
    definition="Class of imaging techniques where the image contrast is generated from a specific intrinsic tissue parameter (T1, T2, etc.).",
    name="MRI weighting",
)
Terminology.olfactory_stimulus_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/olfactoryStimulusType",
    definition="An 'olfactory stimulus type' groups similar olfactory stimuli used across olfactory stimulation techniques.",
    name="olfactory stimulus type",
)
Terminology.operating_device = Terminology(
    id="https://openminds.om-i.org/instances/terminology/operatingDevice",
    name="operating device",
)
Terminology.operating_system = Terminology(
    id="https://openminds.om-i.org/instances/terminology/operatingSystem",
    name="operating system",
)
Terminology.optical_stimulus_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/opticalStimulusType",
    definition="An 'optical stimulus type' groups similar optical stimuli used across optical stimulation techniques.",
    name="optical stimulus type",
)
Terminology.organ = Terminology(
    id="https://openminds.om-i.org/instances/terminology/organ",
    definition="Anatomical structure that performs a specific function or group of functions.",
    description="The preferred ontology for 'organ' is UBERON.",
    name="organ",
    preferred_ontology_identifier=IRI("http://purl.obolibrary.org/obo/UBERON_0000062"),
)
Terminology.organism_substance = Terminology(
    id="https://openminds.om-i.org/instances/terminology/organismSubstance",
    definition="Any material anatomical entity in a gaseous, liquid, semisolid or solid state produced by or derived from an organism or parts of an organism.",
    description="The preferred ontology for 'organism substance' is UBERON.",
    name="organism substance",
)
Terminology.organism_system = Terminology(
    id="https://openminds.om-i.org/instances/terminology/organismSystem",
    definition="Any anatomical or functional system in an organism, regardless of scale.",
    name="organism system",
)
Terminology.organization_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/organizationType",
    definition="Terminology for classifying an organization based on its legal status or position within a larger entity.",
    name="organization type",
    preferred_ontology_identifier=IRI("https://www.wikidata.org/entity/Q17197366"),
)
Terminology.patch_clamp_variation = Terminology(
    id="https://openminds.om-i.org/instances/terminology/patchClampVariation",
    definition="A variation of the patch clamp technique",
    name="patch clamp variation",
)
Terminology.payment_model_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/paymentModelType",
    definition="Terminology defining the pricing structure or financial model associated with accessing a resource.",
    name="payment model type",
)
Terminology.preparation_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/preparationType",
    name="preparation type",
)
Terminology.product_accessibility = Terminology(
    id="https://openminds.om-i.org/instances/terminology/productAccessibility",
    name="product accessibility",
)
Terminology.programming_language = Terminology(
    id="https://openminds.om-i.org/instances/terminology/programmingLanguage",
    name="programming language",
)
Terminology.publication_status = Terminology(
    id="https://openminds.om-i.org/instances/terminology/publicationStatus",
    definition="Terminology defining the status of a resource in the publication lifecycle.",
    name="publication status",
)
Terminology.qualitative_overlap = Terminology(
    id="https://openminds.om-i.org/instances/terminology/qualitativeOverlap",
    name="qualitative overlap",
)
Terminology.semantic_data_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/semanticDataType",
    name="semantic data type",
)
Terminology.service = Terminology(
    id="https://openminds.om-i.org/instances/terminology/service",
    name="service",
)
Terminology.setup_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/setupType",
    definition="The setup type describes the overall purpose of arranging equipment in a certain way (setup).",
    name="setup type",
)
Terminology.software_application_category = Terminology(
    id="https://openminds.om-i.org/instances/terminology/softwareApplicationCategory",
    name="software application category",
)
Terminology.software_feature = Terminology(
    id="https://openminds.om-i.org/instances/terminology/softwareFeature",
    name="software feature",
)
Terminology.species = Terminology(
    id="https://openminds.om-i.org/instances/terminology/species",
    name="species",
)
Terminology.stimulation_approach = Terminology(
    id="https://openminds.om-i.org/instances/terminology/stimulationApproach",
    name="stimulation approach",
)
Terminology.stimulation_technique = Terminology(
    id="https://openminds.om-i.org/instances/terminology/stimulationTechnique",
    name="stimulation technique",
)
Terminology.subcellular_entity = Terminology(
    id="https://openminds.om-i.org/instances/terminology/subcellularEntity",
    definition="Entity derived from a cell or cells. The anatomical scale of these objects roughly corresponds to that which would be visible in high resolution light microscopy or conventional electron microscopy, e.g., nanometers to microns",
    interlex_identifier=IRI("http://uri.interlex.org/base/ilx_0111157"),
    knowledge_space_link=IRI("https://knowledge-space.org/wiki/GO:0005575#iJ6UjX8BxpaxvvQA_2ri"),
    name="subcellular entity",
    preferred_ontology_identifier=IRI("http://purl.obolibrary.org/obo/GO_0005575"),
    synonyms=["cellular component"],
)
Terminology.subject_attribute = Terminology(
    id="https://openminds.om-i.org/instances/terminology/subjectAttribute",
    name="subject attribute",
)
Terminology.tactile_stimulus_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/tactileStimulusType",
    definition="A 'tactile stimulus type' groups similar tactile stimuli used across tactile stimulation techniques.",
    name="tactile stimulus type",
)
Terminology.technique = Terminology(
    id="https://openminds.om-i.org/instances/terminology/technique",
    name="technique",
)
Terminology.tissue_sample_attribute = Terminology(
    id="https://openminds.om-i.org/instances/terminology/tissueSampleAttribute",
    name="tissue sample attribute",
)
Terminology.tissue_sample_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/tissueSampleType",
    name="tissue sample type",
)
Terminology.type_of_uncertainty = Terminology(
    id="https://openminds.om-i.org/instances/terminology/typeOfUncertainty",
    name="type of uncertainty",
)
Terminology.uberon_parcellation = Terminology(
    id="https://openminds.om-i.org/instances/terminology/UBERONParcellation",
    name="UBERON parcellation",
)
Terminology.unit_of_measurement = Terminology(
    id="https://openminds.om-i.org/instances/terminology/unitOfMeasurement",
    name="unit of measurement",
)
Terminology.visual_stimulus_type = Terminology(
    id="https://openminds.om-i.org/instances/terminology/visualStimulusType",
    definition="A 'visual stimulus type' groups similar visual stimuli used across visual stimulation techniques.",
    name="visual stimulus type",
)
