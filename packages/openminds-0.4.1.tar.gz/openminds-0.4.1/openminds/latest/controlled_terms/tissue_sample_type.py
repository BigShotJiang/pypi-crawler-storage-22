"""
Structured information on the general type of the tissue sample.
"""

# this file was auto-generated!

from openminds.base import IRI

from openminds.base import LinkedMetadata
from openminds.properties import Property


class TissueSampleType(LinkedMetadata):
    """
    Structured information on the general type of the tissue sample.
    """

    type_ = "https://openminds.om-i.org/types/TissueSampleType"
    context = {"@vocab": "https://openminds.om-i.org/props/"}
    schema_version = "latest"

    properties = [
        Property(
            "definition",
            str,
            "definition",
            formatting="text/markdown",
            multiline=True,
            description="Short, but precise statement of the meaning of a word, word group, sign or a symbol.",
            instructions="Enter one sentence for defining this term.",
        ),
        Property(
            "description",
            str,
            "description",
            formatting="text/markdown",
            multiline=True,
            description="Longer statement or account giving the characteristics of the tissue sample type.",
            instructions="Enter a short text describing this term.",
        ),
        Property(
            "interlex_identifier",
            IRI,
            "interlexIdentifier",
            description="Persistent identifier for a term registered in the InterLex project.",
            instructions="Enter the internationalized resource identifier (IRI) pointing to the integrated ontology entry in the InterLex project.",
        ),
        Property(
            "knowledge_space_link",
            IRI,
            "knowledgeSpaceLink",
            description="Persistent link to an encyclopedia entry in the Knowledge Space project.",
            instructions="Enter the internationalized resource identifier (IRI) pointing to the wiki page of the corresponding term in the KnowledgeSpace.",
        ),
        Property(
            "name",
            str,
            "name",
            formatting="text/plain",
            required=True,
            description="Word or phrase that constitutes the distinctive designation of the tissue sample type.",
            instructions="Controlled term originating from a defined terminology.",
        ),
        Property(
            "preferred_ontology_identifier",
            IRI,
            "preferredOntologyIdentifier",
            description="Persistent identifier of a preferred ontological term.",
            instructions="Enter the internationalized resource identifier (IRI) pointing to the preferred ontological term.",
        ),
        Property(
            "synonyms",
            str,
            "synonym",
            multiple=True,
            unique_items=True,
            min_items=1,
            formatting="text/plain",
            description="Words or expressions used in the same language that have the same or nearly the same meaning in some or all senses.",
            instructions="Enter one or several synonyms (including abbreviations) for this controlled term.",
        ),
    ]

    def __init__(
        self,
        id=None,
        definition=None,
        description=None,
        interlex_identifier=None,
        knowledge_space_link=None,
        name=None,
        preferred_ontology_identifier=None,
        synonyms=None,
    ):
        return super().__init__(
            id=id,
            definition=definition,
            description=description,
            interlex_identifier=interlex_identifier,
            knowledge_space_link=knowledge_space_link,
            name=name,
            preferred_ontology_identifier=preferred_ontology_identifier,
            synonyms=synonyms,
        )

    @classmethod
    def instances(cls):
        return [value for value in cls.__dict__.values() if isinstance(value, cls)]

    @classmethod
    def by_name(
        cls,
        name: str,
        match: str = "equals",
        all: bool = False,
    ):
        """
        Search for instances in the openMINDS instance library based on their name.

        This includes properties "name", "lookup_label", "family_name", "full_name", "short_name", "abbreviation", and "synonyms".

        Note that not all metadata classes have a name.

        Args:
            name (str): a string to search for.
            match (str, optional): either "equals" (exact match - default) or "contains".
            all (bool, optional): Whether to return all objects that match the name, or only the first. Defaults to False.
        """
        namelike_properties = ("name", "lookup_label", "family_name", "full_name", "short_name", "abbreviation")
        if cls._instance_lookup is None:
            cls._instance_lookup = {}
            for instance in cls.instances():
                keys = []
                for prop_name in namelike_properties:
                    if hasattr(instance, prop_name):
                        keys.append(getattr(instance, prop_name))
                if hasattr(instance, "synonyms"):
                    for synonym in instance.synonyms or []:
                        keys.append(synonym)
                for key in keys:
                    if key in cls._instance_lookup:
                        cls._instance_lookup[key].append(instance)
                    else:
                        cls._instance_lookup[key] = [instance]
        if match == "equals":
            matches = cls._instance_lookup.get(name, [])
        elif match == "contains":
            matches = []
            for key, instances in cls._instance_lookup.items():
                if name in key:
                    matches.extend(instances)
        else:
            raise ValueError("'match' must be either 'equals' or 'contains'")
        if not matches:
            return None
        elif all:
            return matches
        else:
            return matches[0]


TissueSampleType.biopsy_sample = TissueSampleType(
    id="https://openminds.om-i.org/instances/tissueSampleType/biopsySample",
    definition="Typically very small sample of tissue that was excised from a living or deceased multicellular organism body.",
    interlex_identifier=IRI("http://uri.interlex.org/ilx_0782394"),
    name="biopsy sample",
    preferred_ontology_identifier=IRI("http://purl.obolibrary.org/obo/OBI_0002650"),
)
TissueSampleType.fluid_specimen = TissueSampleType(
    id="https://openminds.om-i.org/instances/tissueSampleType/fluidSpecimen",
    definition="A fluid sample either taken directly from a living or deceased multicellular organism body (i.e. body fluids) or produced in a laboratory.",
    name="fluid specimen",
)
TissueSampleType.hemisphere = TissueSampleType(
    id="https://openminds.om-i.org/instances/tissueSampleType/hemisphere",
    definition="One of the symmetric halves excised from a bilateral organ tissue sample (e.g., a brain) from a living or deceased multicellular organism body.",
    name="hemisphere",
)
TissueSampleType.heterogeneous_cell_population = TissueSampleType(
    id="https://openminds.om-i.org/instances/tissueSampleType/heterogeneousCellPopulation",
    definition="A sample of multiple cells/a population of cells that are of two or more different cell types.",
    name="heterogeneous cell population",
)
TissueSampleType.homogeneous_cell_population = TissueSampleType(
    id="https://openminds.om-i.org/instances/tissueSampleType/homogeneousCellPopulation",
    definition="A sample of multiple cells/a population of cells that are of the same cell type.",
    name="homogeneous cell population",
)
TissueSampleType.nerve = TissueSampleType(
    id="https://openminds.om-i.org/instances/tissueSampleType/nerve",
    definition="A nerve sample (i.e. a whole nerve or a part of a nerve) from a living or deceased multicellular organism body.",
    name="nerve",
)
TissueSampleType.single_cell = TissueSampleType(
    id="https://openminds.om-i.org/instances/tissueSampleType/singleCell",
    definition="A single cell sample from a living or deceased multicellular organism body.",
    name="single cell",
)
TissueSampleType.tissue_block = TissueSampleType(
    id="https://openminds.om-i.org/instances/tissueSampleType/tissueBlock",
    definition="A cube-like sample of tissue that was excised from a larger tissue sample (e.g., a whole organ) from a living or deceased multicellular organism body.",
    name="tissue block",
)
TissueSampleType.tissue_slice = TissueSampleType(
    id="https://openminds.om-i.org/instances/tissueSampleType/tissueSlice",
    definition="A thin and often flat sample of tissue that was excised from a larger tissue sample (e.g., a tissue block or a whole organ) from a living or deceased multicellular organism body.",
    name="tissue slice",
)
TissueSampleType.whole_organ = TissueSampleType(
    id="https://openminds.om-i.org/instances/tissueSampleType/wholeOrgan",
    definition="A whole organ sample from a living or deceased multicellular organism body.",
    name="whole organ",
)
