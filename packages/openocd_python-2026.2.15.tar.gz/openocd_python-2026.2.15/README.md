# openocd-python

Typed, async-first Python bindings for the full OpenOCD command surface.

## Install

```bash
pip install openocd-python
```

## Quick Start

```python
from openocd import Session

# Connect to a running OpenOCD instance
async with Session.connect() as ocd:
    state = await ocd.target.halt()
    pc = await ocd.registers.pc()
    mem = await ocd.memory.read_u32(0x08000000, 4)
    print(f"PC: {pc:#x}")

# Or spawn OpenOCD and connect
async with Session.start("interface/cmsis-dap.cfg -f target/stm32f1x.cfg") as ocd:
    await ocd.target.halt()
    regs = await ocd.registers.read_all()

# Synchronous API available too
with Session.start_sync("interface/cmsis-dap.cfg") as ocd:
    ocd.target.halt()
    print(f"PC: {ocd.registers.pc():#x}")
```

## Features

- **Async-first** with sync wrappers for every method
- **Typed returns** — dataclasses, not raw strings
- **Full OpenOCD surface**: target control, memory, registers, flash, JTAG, breakpoints, RTT
- **SVD decoding** — read a peripheral register and get named bitfields
- **Process management** — spawn and manage OpenOCD subprocesses
- **Dual transport** — TCL RPC (primary) and telnet (fallback)

## Requirements

- Python 3.11+
- OpenOCD installed and on PATH (or pass `openocd_bin=`)
