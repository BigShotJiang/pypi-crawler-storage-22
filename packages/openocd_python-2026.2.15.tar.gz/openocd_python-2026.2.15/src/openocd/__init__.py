"""openocd-python — typed, async-first Python bindings for OpenOCD."""

from openocd.errors import (
    ConnectionError,
    FlashError,
    JTAGError,
    OpenOCDError,
    ProcessError,
    SVDError,
    SWDError,
    TargetError,
    TargetNotHaltedError,
    TimeoutError,
)
from openocd.session import Session, SyncSession
from openocd.types import (
    APInfo,
    BitField,
    Breakpoint,
    DAPInfo,
    DecodedRegister,
    FlashBank,
    FlashSector,
    JTAGState,
    MemoryRegion,
    Register,
    RTTChannel,
    TAPInfo,
    TargetState,
    Watchpoint,
)

__all__ = [
    # Session
    "Session",
    "SyncSession",
    # Types
    "APInfo",
    "BitField",
    "Breakpoint",
    "DAPInfo",
    "DecodedRegister",
    "FlashBank",
    "FlashSector",
    "JTAGState",
    "MemoryRegion",
    "RTTChannel",
    "Register",
    "TAPInfo",
    "TargetState",
    "Watchpoint",
    # Errors
    "ConnectionError",
    "FlashError",
    "JTAGError",
    "OpenOCDError",
    "ProcessError",
    "SVDError",
    "SWDError",
    "TargetError",
    "TargetNotHaltedError",
    "TimeoutError",
]

try:
    from importlib.metadata import version

    __version__ = version("openocd-python")
except Exception:
    __version__ = "0.0.0"
