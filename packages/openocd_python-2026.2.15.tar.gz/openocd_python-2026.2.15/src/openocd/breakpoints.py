"""Breakpoint and watchpoint management.

Wraps OpenOCD's ``bp``, ``rbp``, ``wp``, and ``rwp`` commands for
setting, removing, and listing hardware/software breakpoints and
data watchpoints.
"""

from __future__ import annotations

import asyncio
import logging
import re
from typing import Literal

from openocd.connection.base import Connection
from openocd.errors import OpenOCDError
from openocd.types import Breakpoint, Watchpoint

log = logging.getLogger(__name__)


class BreakpointError(OpenOCDError):
    """A breakpoint or watchpoint operation failed."""


# ---------------------------------------------------------------------------
# Parsers
# ---------------------------------------------------------------------------

# Breakpoint(IVA): 0x08001234, 0x2, 1   (hw=1) or 0 (sw)
_BP_RE = re.compile(
    r"Breakpoint\([^)]*\):\s*(?P<addr>0x[0-9a-fA-F]+),\s*"
    r"(?P<len>0x[0-9a-fA-F]+),\s*(?P<hw>\d+)"
)

# Watchpoint output varies across OpenOCD versions. Common formats:
#   address: 0x20000000, len: 0x4, r/w/a: 2 (access), value: ...
#   Watchpoint(DWT): 0x20000000, 0x4, 2
_WP_RE = re.compile(
    r"(?:address:\s*(?P<addr1>0x[0-9a-fA-F]+).*?len:\s*(?P<len1>0x[0-9a-fA-F]+).*?r/w/a:\s*(?P<rwa1>\d+))"
    r"|"
    r"(?:Watchpoint\([^)]*\):\s*(?P<addr2>0x[0-9a-fA-F]+),\s*(?P<len2>0x[0-9a-fA-F]+),\s*(?P<rwa2>\d+))"
)

# OpenOCD watchpoint access type encoding
_WP_ACCESS_MAP = {0: "r", 1: "w", 2: "rw"}
_WP_ACCESS_CMD = {"r": "r", "w": "w", "rw": "a"}


def _check_error(response: str, context: str) -> None:
    """Raise BreakpointError if the response indicates failure."""
    if "error" in response.lower():
        raise BreakpointError(f"{context}: {response.strip()}")


def _parse_breakpoint_list(text: str) -> list[Breakpoint]:
    """Parse the output of ``bp`` (no arguments) into Breakpoint objects."""
    breakpoints: list[Breakpoint] = []
    for idx, m in enumerate(_BP_RE.finditer(text)):
        hw_flag = int(m.group("hw"))
        breakpoints.append(
            Breakpoint(
                number=idx,
                type="hw" if hw_flag else "sw",
                address=int(m.group("addr"), 16),
                length=int(m.group("len"), 16),
                enabled=True,
            )
        )
    return breakpoints


def _parse_watchpoint_list(text: str) -> list[Watchpoint]:
    """Parse watchpoint listing output."""
    watchpoints: list[Watchpoint] = []
    for idx, m in enumerate(_WP_RE.finditer(text)):
        # Match could come from either alternative in the regex
        if m.group("addr1") is not None:
            addr = int(m.group("addr1"), 16)
            length = int(m.group("len1"), 16)
            rwa = int(m.group("rwa1"))
        else:
            addr = int(m.group("addr2"), 16)
            length = int(m.group("len2"), 16)
            rwa = int(m.group("rwa2"))

        watchpoints.append(
            Watchpoint(
                number=idx,
                address=addr,
                length=length,
                access=_WP_ACCESS_MAP.get(rwa, "rw"),
            )
        )
    return watchpoints


class BreakpointManager:
    """Manage breakpoints and watchpoints via OpenOCD.

    Breakpoints can be either software (patching the instruction) or
    hardware (using on-chip comparators). Watchpoints trigger on data
    access to a given address range.
    """

    def __init__(self, conn: Connection) -> None:
        self._conn = conn

    # ------------------------------------------------------------------
    # Breakpoints
    # ------------------------------------------------------------------

    async def add(self, address: int, length: int = 2, hw: bool = False) -> None:
        """Set a breakpoint at the given address.

        Args:
            address: Instruction address for the breakpoint.
            length: Breakpoint length in bytes (2 for Thumb, 4 for ARM).
            hw: Request a hardware breakpoint. If False, OpenOCD uses a
                software breakpoint when possible.
        """
        cmd = f"bp 0x{address:08X} {length}"
        if hw:
            cmd += " hw"
        resp = await self._conn.send(cmd)
        _check_error(resp, f"bp 0x{address:08X}")
        log.info("Breakpoint set at 0x%08X (len=%d, hw=%s)", address, length, hw)

    async def remove(self, address: int) -> None:
        """Remove a breakpoint at the given address.

        Args:
            address: Address of the breakpoint to remove.
        """
        cmd = f"rbp 0x{address:08X}"
        resp = await self._conn.send(cmd)
        _check_error(resp, f"rbp 0x{address:08X}")
        log.info("Breakpoint removed at 0x%08X", address)

    async def list(self) -> list[Breakpoint]:
        """List all active breakpoints.

        Returns:
            A list of Breakpoint objects describing each active breakpoint.
        """
        resp = await self._conn.send("bp")
        # An empty response or no matches means no breakpoints set
        if not resp.strip():
            return []
        return _parse_breakpoint_list(resp)

    # ------------------------------------------------------------------
    # Watchpoints
    # ------------------------------------------------------------------

    async def add_watchpoint(
        self,
        address: int,
        length: int,
        access: Literal["r", "w", "rw"] = "rw",
    ) -> None:
        """Set a data watchpoint.

        Args:
            address: Memory address to watch.
            length: Number of bytes to watch (must be power of 2 on most targets).
            access: Access type -- ``"r"`` for read, ``"w"`` for write,
                    ``"rw"`` for read/write (access).
        """
        access_flag = _WP_ACCESS_CMD.get(access, "a")
        cmd = f"wp 0x{address:08X} {length} {access_flag}"
        resp = await self._conn.send(cmd)
        _check_error(resp, f"wp 0x{address:08X}")
        log.info("Watchpoint set at 0x%08X (len=%d, access=%s)", address, length, access)

    async def remove_watchpoint(self, address: int) -> None:
        """Remove a watchpoint at the given address.

        Args:
            address: Address of the watchpoint to remove.
        """
        cmd = f"rwp 0x{address:08X}"
        resp = await self._conn.send(cmd)
        _check_error(resp, f"rwp 0x{address:08X}")
        log.info("Watchpoint removed at 0x%08X", address)

    async def list_watchpoints(self) -> list[Watchpoint]:
        """List all active watchpoints.

        Returns:
            A list of Watchpoint objects describing each active watchpoint.
        """
        # OpenOCD doesn't have a dedicated "list watchpoints" command
        # but 'wp' with no arguments on some builds returns the list.
        # The more reliable approach is using the TCL command.
        resp = await self._conn.send("wp")
        if not resp.strip():
            return []
        return _parse_watchpoint_list(resp)


# ======================================================================
# Sync wrapper
# ======================================================================


class SyncBreakpointManager:
    """Synchronous wrapper around BreakpointManager."""

    def __init__(self, bp_manager: BreakpointManager, loop: asyncio.AbstractEventLoop) -> None:
        self._bp = bp_manager
        self._loop = loop

    def add(self, address: int, length: int = 2, hw: bool = False) -> None:
        self._loop.run_until_complete(self._bp.add(address, length=length, hw=hw))

    def remove(self, address: int) -> None:
        self._loop.run_until_complete(self._bp.remove(address))

    def list(self) -> list[Breakpoint]:
        return self._loop.run_until_complete(self._bp.list())

    def add_watchpoint(
        self,
        address: int,
        length: int,
        access: Literal["r", "w", "rw"] = "rw",
    ) -> None:
        self._loop.run_until_complete(self._bp.add_watchpoint(address, length, access=access))

    def remove_watchpoint(self, address: int) -> None:
        self._loop.run_until_complete(self._bp.remove_watchpoint(address))

    def list_watchpoints(self) -> list[Watchpoint]:
        return self._loop.run_until_complete(self._bp.list_watchpoints())
