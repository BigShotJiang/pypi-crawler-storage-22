"""CLI entry point for openocd-python.

Provides quick diagnostics and a REPL for interactive use:

    $ openocd-python --help
    $ openocd-python info               # probe detection + target info
    $ openocd-python repl               # interactive command REPL
    $ openocd-python read 0x08000000 16 # quick memory read
"""

from __future__ import annotations

import argparse
import asyncio
import sys


def main() -> None:
    try:
        from importlib.metadata import version

        pkg_version = version("openocd-python")
    except Exception:
        pkg_version = "dev"

    parser = argparse.ArgumentParser(
        prog="openocd-python",
        description=f"OpenOCD Python bindings v{pkg_version}",
    )
    parser.add_argument("--version", action="version", version=f"openocd-python {pkg_version}")
    parser.add_argument("--host", default="localhost", help="OpenOCD host (default: localhost)")
    parser.add_argument(
        "--port", type=int, default=6666, help="OpenOCD TCL RPC port (default: 6666)"
    )

    sub = parser.add_subparsers(dest="command")

    sub.add_parser("info", help="Show target and adapter information")

    repl_parser = sub.add_parser("repl", help="Interactive OpenOCD command REPL")
    repl_parser.add_argument(
        "--timeout", type=float, default=10.0, help="Command timeout in seconds"
    )

    read_parser = sub.add_parser("read", help="Read memory and display as hexdump")
    read_parser.add_argument("address", help="Start address (hex, e.g. 0x08000000)")
    read_parser.add_argument(
        "size", type=int, nargs="?", default=64, help="Bytes to read (default: 64)"
    )

    sub.add_parser("scan", help="Scan the JTAG chain")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    asyncio.run(_dispatch(args))


async def _dispatch(args: argparse.Namespace) -> None:
    from openocd.session import Session

    async with Session.connect(host=args.host, port=args.port) as ocd:
        if args.command == "info":
            await _cmd_info(ocd)
        elif args.command == "repl":
            await _cmd_repl(ocd, timeout=args.timeout)
        elif args.command == "read":
            await _cmd_read(ocd, args.address, args.size)
        elif args.command == "scan":
            await _cmd_scan(ocd)


async def _cmd_info(ocd) -> None:
    """Display target state and adapter information."""
    from openocd.errors import OpenOCDError

    print("=== OpenOCD Target Info ===\n")

    try:
        state = await ocd.target.state()
        print(f"  Target:  {state.name}")
        print(f"  State:   {state.state}")
        if state.current_pc is not None:
            print(f"  PC:      0x{state.current_pc:08X}")
    except OpenOCDError as e:
        print(f"  Target:  (error: {e})")

    print()

    try:
        transport_name = await ocd.transport.select()
        print(f"  Transport: {transport_name}")
    except OpenOCDError:
        pass

    try:
        adapter = await ocd.transport.adapter_info()
        print(f"  Adapter:   {adapter}")
    except OpenOCDError:
        pass

    try:
        speed = await ocd.transport.adapter_speed()
        print(f"  Speed:     {speed} kHz")
    except OpenOCDError:
        pass


async def _cmd_repl(ocd, timeout: float = 10.0) -> None:
    """Interactive command REPL."""
    print("OpenOCD REPL (type 'quit' or Ctrl-D to exit)\n")
    while True:
        try:
            cmd = input("ocd> ")
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if cmd.strip().lower() in ("quit", "exit", "q"):
            break
        if not cmd.strip():
            continue
        try:
            result = await ocd.command(cmd)
            if result.strip():
                print(result)
        except Exception as e:
            print(f"Error: {e}")


async def _cmd_read(ocd, address_str: str, size: int) -> None:
    """Read memory and display as hexdump."""
    addr = int(address_str, 0)
    dump = await ocd.memory.hexdump(addr, size)
    print(dump)


async def _cmd_scan(ocd) -> None:
    """Scan the JTAG chain."""
    taps = await ocd.jtag.scan_chain()
    if not taps:
        print("No TAPs found on the JTAG chain.")
        return

    print(f"{'TAP Name':<25s} {'IDCODE':>10s}  IR  Enabled")
    print("-" * 50)
    for tap in taps:
        print(
            f"{tap.name:<25s} 0x{tap.idcode:08X}  {tap.ir_length:>2d}  "
            f"{'yes' if tap.enabled else 'no'}"
        )


if __name__ == "__main__":
    main()
