"""Connection backends for communicating with OpenOCD."""

from openocd.connection.base import Connection
from openocd.connection.tcl_rpc import TclRpcConnection
from openocd.connection.telnet import TelnetConnection

__all__ = ["Connection", "TclRpcConnection", "TelnetConnection"]
