"""Abstract base class for OpenOCD connection backends."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable


class Connection(ABC):
    """Protocol-agnostic interface to an OpenOCD instance."""

    @abstractmethod
    async def connect(self, host: str, port: int) -> None:
        """Open a connection to the given host and port."""

    @abstractmethod
    async def send(self, command: str) -> str:
        """Send a command string and return the response."""

    @abstractmethod
    async def close(self) -> None:
        """Close the connection."""

    @abstractmethod
    async def enable_notifications(self) -> None:
        """Enable asynchronous event notifications from OpenOCD."""

    @abstractmethod
    def on_notification(self, callback: Callable[[str], None]) -> None:
        """Register a callback for incoming notifications."""
