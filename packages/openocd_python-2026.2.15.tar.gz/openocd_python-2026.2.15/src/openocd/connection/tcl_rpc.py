"""TCL RPC client for OpenOCD (port 6666).

OpenOCD's TCL RPC uses a simple framing protocol:
  - Client sends: command_string + \\x1a
  - Server replies: response_string + \\x1a
The \\x1a (ASCII SUB / Ctrl-Z) byte acts as an unambiguous delimiter.

Notifications use a **separate connection** to avoid dual-reader race
conditions on the command stream.  When ``enable_notifications()`` is
called, a second TCP connection is opened to the same host:port.  That
connection sends ``tcl_notifications on`` and then exclusively reads
unsolicited events, leaving the primary connection free for
request/response commands.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
from collections.abc import Callable

from openocd.connection.base import Connection
from openocd.errors import ConnectionError
from openocd.errors import TimeoutError as OcdTimeoutError

log = logging.getLogger(__name__)

SEPARATOR = b"\x1a"
DEFAULT_TIMEOUT = 10.0
MAX_RESPONSE_SIZE = 10 * 1024 * 1024  # 10 MB — guard against runaway reads


class TclRpcConnection(Connection):
    """Async TCP client speaking OpenOCD's TCL RPC protocol.

    The command connection and the notification connection are kept on
    **separate sockets** so that unsolicited events never corrupt
    the request/response stream.
    """

    def __init__(self, timeout: float = DEFAULT_TIMEOUT) -> None:
        # Primary command connection
        self._reader: asyncio.StreamReader | None = None
        self._writer: asyncio.StreamWriter | None = None
        self._timeout = timeout
        self._lock = asyncio.Lock()
        self._remainder = bytearray()  # leftover bytes after separator
        self._host: str = ""
        self._port: int = 0

        # Notification connection (separate socket)
        self._notif_reader: asyncio.StreamReader | None = None
        self._notif_writer: asyncio.StreamWriter | None = None
        self._notification_callbacks: list[Callable[[str], None]] = []
        self._notification_task: asyncio.Task[None] | None = None
        self._notification_failed: bool = False

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    async def connect(self, host: str = "localhost", port: int = 6666) -> None:
        self._host = host
        self._port = port
        try:
            self._reader, self._writer = await asyncio.wait_for(
                asyncio.open_connection(host, port),
                timeout=self._timeout,
            )
        except OSError as exc:
            raise ConnectionError(
                f"Cannot connect to OpenOCD TCL RPC at {host}:{port}: {exc}"
            ) from exc
        except TimeoutError as exc:
            raise OcdTimeoutError(
                f"Timed out connecting to OpenOCD TCL RPC at {host}:{port}"
            ) from exc
        log.debug("Connected to OpenOCD TCL RPC at %s:%d", host, port)

    async def close(self) -> None:
        # Tear down notification connection first
        if self._notification_task and not self._notification_task.done():
            self._notification_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._notification_task
            self._notification_task = None

        if self._notif_writer:
            self._notif_writer.close()
            with contextlib.suppress(OSError):
                await self._notif_writer.wait_closed()
            self._notif_writer = None
            self._notif_reader = None

        # Tear down primary command connection
        if self._writer:
            self._writer.close()
            with contextlib.suppress(OSError):
                await self._writer.wait_closed()
            self._writer = None
            self._reader = None
        self._remainder.clear()
        log.debug("TCL RPC connection closed")

    # ------------------------------------------------------------------
    # Command send/receive
    # ------------------------------------------------------------------

    async def send(self, command: str) -> str:
        """Send a command and return the response string.

        The protocol appends \\x1a after the command and reads until
        \\x1a appears in the response stream.
        """
        if not self._writer or not self._reader:
            raise ConnectionError("Not connected — call connect() first")

        if self._notification_failed:
            log.warning("Notification listener has stopped — events may be missed")

        async with self._lock:
            payload = command.encode("utf-8") + SEPARATOR
            self._writer.write(payload)
            await self._writer.drain()
            log.debug("TX: %s", command)

            try:
                raw = await asyncio.wait_for(
                    self._read_until_separator(),
                    timeout=self._timeout,
                )
            except TimeoutError as exc:
                raise OcdTimeoutError(f"Timed out waiting for response to: {command}") from exc

            response = raw.decode("utf-8", errors="replace")
            log.debug("RX: %s", response[:200])
            return response

    async def _read_until_separator(self) -> bytes:
        """Read from the command stream until the \\x1a separator is found.

        Preserves any bytes received after the separator for the next call.
        Raises ``ConnectionError`` if the response exceeds ``MAX_RESPONSE_SIZE``.
        """
        assert self._reader is not None
        buf = self._remainder
        self._remainder = bytearray()

        # Check if remainder already contains a complete response
        idx = buf.find(SEPARATOR)
        if idx != -1:
            result = bytes(buf[:idx])
            self._remainder = bytearray(buf[idx + 1 :])
            return result

        while True:
            chunk = await self._reader.read(4096)
            if not chunk:
                raise ConnectionError("OpenOCD closed the connection")
            buf.extend(chunk)
            if len(buf) > MAX_RESPONSE_SIZE:
                raise ConnectionError(
                    f"Response exceeded {MAX_RESPONSE_SIZE} bytes without separator — "
                    "is this an OpenOCD TCL RPC port?"
                )
            idx = buf.find(SEPARATOR)
            if idx != -1:
                result = bytes(buf[:idx])
                self._remainder = bytearray(buf[idx + 1 :])
                return result

    # ------------------------------------------------------------------
    # Notifications (separate connection)
    # ------------------------------------------------------------------

    async def enable_notifications(self) -> None:
        """Open a dedicated notification connection and start the listener.

        A **separate TCP connection** to the same OpenOCD instance is
        used for notifications.  This avoids the dual-reader race
        condition that would occur if notifications and command
        responses shared the same stream.
        """
        if not self._host:
            raise ConnectionError("Not connected — call connect() first")

        try:
            self._notif_reader, self._notif_writer = await asyncio.wait_for(
                asyncio.open_connection(self._host, self._port),
                timeout=self._timeout,
            )
        except OSError as exc:
            raise ConnectionError(
                f"Cannot open notification connection to {self._host}:{self._port}: {exc}"
            ) from exc
        except TimeoutError as exc:
            raise OcdTimeoutError(
                f"Timed out opening notification connection to {self._host}:{self._port}"
            ) from exc

        # Enable notifications on the dedicated connection
        enable_cmd = b"tcl_notifications on" + SEPARATOR
        self._notif_writer.write(enable_cmd)
        await self._notif_writer.drain()

        # Read and discard the acknowledgement
        ack_buf = bytearray()
        while True:
            chunk = await asyncio.wait_for(self._notif_reader.read(4096), timeout=self._timeout)
            if not chunk:
                raise ConnectionError("Notification connection closed during setup")
            ack_buf.extend(chunk)
            if ack_buf.find(SEPARATOR) != -1:
                break

        log.debug("Notification connection established to %s:%d", self._host, self._port)
        self._notification_failed = False
        self._notification_task = asyncio.create_task(self._notification_loop())

    async def _notification_loop(self) -> None:
        """Background task that reads unsolicited notifications from
        the dedicated notification connection."""
        assert self._notif_reader is not None
        buf = bytearray()
        try:
            while True:
                chunk = await self._notif_reader.read(4096)
                if not chunk:
                    log.warning("Notification connection closed by OpenOCD")
                    break
                buf.extend(chunk)
                while True:
                    idx = buf.find(SEPARATOR)
                    if idx == -1:
                        break
                    msg = buf[:idx].decode("utf-8", errors="replace")
                    buf = buf[idx + 1 :]
                    log.debug("Notification: %s", msg)
                    for cb in self._notification_callbacks:
                        try:
                            cb(msg)
                        except Exception:
                            log.exception("Notification callback error")
        except asyncio.CancelledError:
            return
        except Exception:
            log.exception("Notification loop crashed")
        finally:
            self._notification_failed = True

    def on_notification(self, callback: Callable[[str], None]) -> None:
        self._notification_callbacks.append(callback)
