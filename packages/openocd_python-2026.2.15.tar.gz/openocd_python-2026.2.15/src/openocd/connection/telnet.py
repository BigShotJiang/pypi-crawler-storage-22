"""Telnet connection to OpenOCD (port 4444) — fallback transport.

The telnet interface is human-oriented and its output formatting varies
between OpenOCD versions. Prefer TclRpcConnection where possible.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
from collections.abc import Callable

from openocd.connection.base import Connection
from openocd.errors import ConnectionError
from openocd.errors import TimeoutError as OcdTimeoutError

log = logging.getLogger(__name__)

PROMPT = b"> "
DEFAULT_TIMEOUT = 10.0
MAX_RESPONSE_SIZE = 10 * 1024 * 1024  # 10 MB


class TelnetConnection(Connection):
    """Async telnet client for OpenOCD port 4444."""

    def __init__(self, timeout: float = DEFAULT_TIMEOUT) -> None:
        self._reader: asyncio.StreamReader | None = None
        self._writer: asyncio.StreamWriter | None = None
        self._timeout = timeout
        self._lock = asyncio.Lock()

    async def connect(self, host: str = "localhost", port: int = 4444) -> None:
        try:
            self._reader, self._writer = await asyncio.wait_for(
                asyncio.open_connection(host, port),
                timeout=self._timeout,
            )
        except OSError as exc:
            raise ConnectionError(
                f"Cannot connect to OpenOCD telnet at {host}:{port}: {exc}"
            ) from exc
        except TimeoutError as exc:
            raise OcdTimeoutError(
                f"Timed out connecting to OpenOCD telnet at {host}:{port}"
            ) from exc

        # Consume the initial banner / prompt
        with contextlib.suppress(TimeoutError):
            await asyncio.wait_for(self._read_until_prompt(), timeout=self._timeout)
        log.debug("Connected to OpenOCD telnet at %s:%d", host, port)

    async def close(self) -> None:
        if self._writer:
            self._writer.close()
            with contextlib.suppress(OSError):
                await self._writer.wait_closed()
            self._writer = None
            self._reader = None

    async def send(self, command: str) -> str:
        if not self._writer or not self._reader:
            raise ConnectionError("Not connected")

        async with self._lock:
            self._writer.write((command + "\n").encode("utf-8"))
            await self._writer.drain()

            try:
                raw = await asyncio.wait_for(
                    self._read_until_prompt(),
                    timeout=self._timeout,
                )
            except TimeoutError as exc:
                raise OcdTimeoutError(f"Timed out waiting for: {command}") from exc

            # Strip the echoed command and trailing prompt
            text = raw.decode("utf-8", errors="replace")
            lines = text.splitlines()
            # First line is often the echoed command, last line is the prompt
            if lines and lines[0].strip() == command.strip():
                lines = lines[1:]
            return "\n".join(lines).strip()

    async def _read_until_prompt(self) -> bytes:
        assert self._reader is not None
        buf = bytearray()
        while True:
            chunk = await self._reader.read(4096)
            if not chunk:
                raise ConnectionError("OpenOCD closed the connection")
            buf.extend(chunk)
            if len(buf) > MAX_RESPONSE_SIZE:
                raise ConnectionError(f"Response exceeded {MAX_RESPONSE_SIZE} bytes without prompt")
            if buf.endswith(PROMPT):
                return bytes(buf[: -len(PROMPT)])

    async def enable_notifications(self) -> None:
        log.warning("Telnet transport does not support async notifications")

    def on_notification(self, callback: Callable[[str], None]) -> None:
        log.warning("Telnet transport does not support notifications")
