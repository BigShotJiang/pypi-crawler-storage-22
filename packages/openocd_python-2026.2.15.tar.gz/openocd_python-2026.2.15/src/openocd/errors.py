"""Exception hierarchy for openocd-python.

All exceptions inherit from OpenOCDError so callers can catch broadly
or narrowly as needed.
"""

from __future__ import annotations


class OpenOCDError(Exception):
    """Base exception for all openocd-python errors."""


class ConnectionError(OpenOCDError):
    """Cannot connect to the OpenOCD TCL RPC or telnet interface."""


class TimeoutError(OpenOCDError):
    """A command or wait operation exceeded its deadline."""


class TargetError(OpenOCDError):
    """The target is not responding or returned an error."""


class TargetNotHaltedError(TargetError):
    """Operation requires a halted target but it is currently running."""


class FlashError(OpenOCDError):
    """A flash read/write/erase/verify operation failed."""


class JTAGError(OpenOCDError):
    """JTAG communication or chain error."""


class SVDError(OpenOCDError):
    """SVD file not found, failed to parse, or lookup error."""


class SWDError(OpenOCDError):
    """Raised when an SWD/DAP operation fails."""


class ProcessError(OpenOCDError):
    """OpenOCD subprocess failed to start or exited unexpectedly."""
