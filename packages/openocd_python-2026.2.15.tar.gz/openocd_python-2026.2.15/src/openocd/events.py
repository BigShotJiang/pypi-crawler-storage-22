"""Async event system for OpenOCD target state changes.

OpenOCD can push TCL notifications when target state changes occur
(halt, resume, reset, etc.). This module provides a typed callback
interface on top of the raw notification stream.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from openocd.connection.base import Connection

log = logging.getLogger(__name__)

# Known event types emitted by OpenOCD's TCL notification system
EVENT_HALTED = "halted"
EVENT_RESUMED = "resumed"
EVENT_RESET = "reset"
EVENT_GDB_ATTACHED = "gdb-attached"
EVENT_GDB_DETACHED = "gdb-detached"


class EventManager:
    """Manages callbacks for target state change events.

    Usage::

        events = EventManager(conn)
        await events.enable()

        events.on("halted", lambda msg: print(f"Target halted: {msg}"))
        events.on("reset", handle_reset)

        # Later...
        events.off("halted", that_callback)
    """

    def __init__(self, conn: Connection) -> None:
        self._conn = conn
        self._callbacks: dict[str, list[Callable[[str], None]]] = {}
        self._enabled = False

    @property
    def enabled(self) -> bool:
        """Whether TCL notifications have been turned on."""
        return self._enabled

    async def enable(self) -> None:
        """Enable TCL notifications and start event dispatch.

        Sends ``tcl_notifications on`` to OpenOCD and registers an
        internal handler that routes incoming messages to typed callbacks.

        Raises:
            ConnectionError: If the connection is not open.
        """
        if self._enabled:
            return

        await self._conn.enable_notifications()
        self._conn.on_notification(self._dispatch)
        self._enabled = True
        log.info("Event notifications enabled")

    def on(self, event_type: str, callback: Callable[[str], None]) -> None:
        """Register a callback for a specific event type.

        Args:
            event_type: Event name to match (e.g. "halted", "reset", "resumed").
                        Matching is case-insensitive substring — a notification
                        containing "halted" anywhere triggers "halted" callbacks.
            callback: Function to call with the full notification message.
        """
        key = event_type.lower()
        if key not in self._callbacks:
            self._callbacks[key] = []
        if callback not in self._callbacks[key]:
            self._callbacks[key].append(callback)
            log.debug("Registered callback for event '%s'", key)

    def off(self, event_type: str, callback: Callable[[str], None]) -> None:
        """Unregister a callback.

        Args:
            event_type: The event type the callback was registered under.
            callback: The callback to remove.
        """
        key = event_type.lower()
        handlers = self._callbacks.get(key, [])
        try:
            handlers.remove(callback)
            log.debug("Unregistered callback for event '%s'", key)
        except ValueError:
            pass

    def _dispatch(self, message: str) -> None:
        """Route an incoming notification to matching callbacks."""
        msg_lower = message.lower()
        for event_type, handlers in self._callbacks.items():
            if event_type in msg_lower:
                for handler in handlers:
                    try:
                        handler(message)
                    except Exception:
                        log.exception(
                            "Error in event callback for '%s'",
                            event_type,
                        )
