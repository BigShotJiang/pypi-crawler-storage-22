"""Flash memory programming operations.

Wraps OpenOCD's ``flash`` command family for reading, writing, erasing,
and verifying on-chip flash memory banks.
"""

from __future__ import annotations

import asyncio
import logging
import re
import tempfile
from pathlib import Path

from openocd.connection.base import Connection
from openocd.errors import FlashError
from openocd.types import FlashBank, FlashSector

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Regex patterns for parsing OpenOCD flash output
# ---------------------------------------------------------------------------

# flash banks: #0 : stm32f1x.flash (stm32f1x) at 0x08000000, size 0x00020000, ...
_BANK_LIST_RE = re.compile(
    r"#(?P<idx>\d+)\s*:\s*(?P<name>\S+)\s+\((?P<driver>\S+)\)\s+"
    r"at\s+(?P<base>0x[0-9a-fA-F]+),\s*size\s+(?P<size>0x[0-9a-fA-F]+),\s*"
    r"buswidth\s+(?P<bw>\d+),\s*chipwidth\s+(?P<cw>\d+)"
)

# flash info header: #0 : stm32f1x at 0x08000000, size 0x00020000, ...
_INFO_HEADER_RE = re.compile(
    r"#(?P<idx>\d+)\s*:\s*(?P<name>\S+)\s+at\s+(?P<base>0x[0-9a-fA-F]+),\s*"
    r"size\s+(?P<size>0x[0-9a-fA-F]+),\s*"
    r"buswidth\s+(?P<bw>\d+),\s*chipwidth\s+(?P<cw>\d+)"
)

# flash info sector: #  0: 0x00000000 (0x400 1kB) not protected
_SECTOR_RE = re.compile(
    r"#\s*(?P<idx>\d+):\s*(?P<offset>0x[0-9a-fA-F]+)\s+"
    r"\((?P<size>0x[0-9a-fA-F]+)\s+[^)]*\)\s+"
    r"(?P<prot>protected|not protected)"
)


def _check_error(response: str, context: str) -> None:
    """Raise FlashError if the response indicates failure."""
    if "error" in response.lower():
        raise FlashError(f"{context}: {response.strip()}")


def _parse_bank_list(text: str) -> list[FlashBank]:
    """Parse the output of ``flash banks``."""
    banks: list[FlashBank] = []
    for m in _BANK_LIST_RE.finditer(text):
        banks.append(
            FlashBank(
                index=int(m.group("idx")),
                name=m.group("name"),
                base=int(m.group("base"), 16),
                size=int(m.group("size"), 16),
                bus_width=int(m.group("bw")),
                chip_width=int(m.group("cw")),
                target=m.group("driver"),
            )
        )
    return banks


def _parse_bank_info(text: str) -> FlashBank:
    """Parse the output of ``flash info <bank>`` into a FlashBank with sectors."""
    header = _INFO_HEADER_RE.search(text)
    if not header:
        raise FlashError(f"Cannot parse flash info output: {text[:200]}")

    sectors: list[FlashSector] = []
    for m in _SECTOR_RE.finditer(text):
        sectors.append(
            FlashSector(
                index=int(m.group("idx")),
                offset=int(m.group("offset"), 16),
                size=int(m.group("size"), 16),
                protected=m.group("prot") == "protected",
            )
        )

    return FlashBank(
        index=int(header.group("idx")),
        name=header.group("name"),
        base=int(header.group("base"), 16),
        size=int(header.group("size"), 16),
        bus_width=int(header.group("bw")),
        chip_width=int(header.group("cw")),
        target=(
            header.group("name").split(".")[0]
            if "." in header.group("name")
            else header.group("name")
        ),
        sectors=sectors,
    )


class Flash:
    """Flash memory programming via OpenOCD.

    All methods are async and use the underlying TCL RPC connection to
    issue ``flash`` commands.
    """

    def __init__(self, conn: Connection) -> None:
        self._conn = conn

    # ------------------------------------------------------------------
    # Bank enumeration
    # ------------------------------------------------------------------

    async def banks(self) -> list[FlashBank]:
        """List all configured flash banks.

        Returns:
            A list of FlashBank descriptors (without detailed sector info).
        """
        resp = await self._conn.send("flash banks")
        _check_error(resp, "flash banks")
        return _parse_bank_list(resp)

    async def info(self, bank: int = 0) -> FlashBank:
        """Get detailed information about a flash bank, including sectors.

        Args:
            bank: Flash bank number (default 0).

        Returns:
            A FlashBank with populated ``sectors`` list.
        """
        resp = await self._conn.send(f"flash info {bank}")
        _check_error(resp, f"flash info {bank}")
        return _parse_bank_info(resp)

    # ------------------------------------------------------------------
    # Read operations
    # ------------------------------------------------------------------

    async def read(self, bank: int, offset: int, size: int) -> bytes:
        """Read raw bytes from a flash bank.

        Uses a temporary file as an intermediary since OpenOCD's
        ``flash read_bank`` writes to a file, then reads the file content
        back via TCL.

        Args:
            bank: Flash bank number.
            offset: Byte offset within the bank.
            size: Number of bytes to read.

        Returns:
            The raw flash contents as bytes.
        """
        with tempfile.NamedTemporaryFile(suffix=".bin", delete=False) as tmp:
            tmp_path = tmp.name

        try:
            cmd = f"flash read_bank {bank} {tmp_path} {offset} {size}"
            resp = await self._conn.send(cmd)
            _check_error(resp, f"flash read_bank {bank}")

            # Read the file back through TCL to handle remote OpenOCD instances.
            # Use ocd_find + binary read if available, otherwise fall back to
            # reading the local file.
            tcl_read = f"set fp [open {tmp_path} rb]; set data [read $fp]; close $fp; set data"
            try:
                raw = await self._conn.send(tcl_read)
                # TCL returns binary as string; try base64 approach if garbled
                return raw.encode("latin-1")
            except Exception:
                # Fallback: read the local file directly
                return Path(tmp_path).read_bytes()
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    async def read_to_file(self, bank: int, path: Path) -> None:
        """Read an entire flash bank to a local file.

        Args:
            bank: Flash bank number.
            path: Destination file path.
        """
        cmd = f"flash read_bank {bank} {path}"
        resp = await self._conn.send(cmd)
        _check_error(resp, f"flash read_bank {bank} to {path}")
        log.info("Flash bank %d read to %s", bank, path)

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    async def write(self, bank: int, offset: int, data: bytes) -> None:
        """Write raw bytes to a flash bank at the given offset.

        Writes data through a temporary file since OpenOCD's
        ``flash write_bank`` reads from a file.

        Args:
            bank: Flash bank number.
            offset: Byte offset within the bank.
            data: Bytes to write.
        """
        with tempfile.NamedTemporaryFile(suffix=".bin", delete=False) as tmp:
            tmp.write(data)
            tmp_path = tmp.name

        try:
            cmd = f"flash write_bank {bank} {tmp_path} {offset}"
            resp = await self._conn.send(cmd)
            _check_error(resp, f"flash write_bank {bank}")
            log.info("Wrote %d bytes to flash bank %d at offset 0x%X", len(data), bank, offset)
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    async def write_image(
        self,
        path: Path,
        erase: bool = True,
        verify: bool = True,
    ) -> None:
        """Program a firmware image into flash.

        This is the high-level "flash and go" command that handles erase,
        write, and optional verification in a single operation.

        Args:
            path: Path to the firmware image (.bin, .hex, .elf, etc.).
            erase: Erase affected sectors before writing (default True).
            verify: Verify flash contents after writing (default True).
        """
        parts = ["flash", "write_image"]
        if erase:
            parts.append("erase")
        parts.append(str(path))

        cmd = " ".join(parts)
        resp = await self._conn.send(cmd)
        _check_error(resp, f"flash write_image {path}")
        log.info("Flash image written: %s (erase=%s)", path, erase)

        if verify:
            verify_cmd = f"verify_image {path}"
            vresp = await self._conn.send(verify_cmd)
            if "error" in vresp.lower() or "mismatch" in vresp.lower():
                raise FlashError(f"Post-write verification failed: {vresp.strip()}")
            log.info("Flash verification passed for %s", path)

    # ------------------------------------------------------------------
    # Erase operations
    # ------------------------------------------------------------------

    async def erase_sector(self, bank: int, first: int, last: int) -> None:
        """Erase a range of sectors within a flash bank.

        Args:
            bank: Flash bank number.
            first: First sector number to erase (inclusive).
            last: Last sector number to erase (inclusive).
        """
        if first > last:
            raise FlashError(f"Invalid sector range: first ({first}) > last ({last})")

        cmd = f"flash erase_sector {bank} {first} {last}"
        resp = await self._conn.send(cmd)
        _check_error(resp, f"flash erase_sector {bank} {first}-{last}")
        log.info("Erased sectors %d-%d in flash bank %d", first, last, bank)

    async def erase_all(self, bank: int = 0) -> None:
        """Erase all sectors in a flash bank.

        Queries the bank info to determine the last sector, then erases
        the full range.

        Args:
            bank: Flash bank number (default 0).
        """
        bank_info = await self.info(bank)
        if not bank_info.sectors:
            # Fall back to erasing sector 0 through "last" using the count
            # OpenOCD also accepts "last" as a keyword
            cmd = f"flash erase_sector {bank} 0 last"
            resp = await self._conn.send(cmd)
            _check_error(resp, f"flash erase_all bank {bank}")
        else:
            last_sector = bank_info.sectors[-1].index
            await self.erase_sector(bank, 0, last_sector)
        log.info("Erased all sectors in flash bank %d", bank)

    # ------------------------------------------------------------------
    # Protection
    # ------------------------------------------------------------------

    async def protect(self, bank: int, first: int, last: int, on: bool) -> None:
        """Set or clear write protection on a range of sectors.

        Args:
            bank: Flash bank number.
            first: First sector number (inclusive).
            last: Last sector number (inclusive).
            on: True to enable protection, False to disable.
        """
        flag = "on" if on else "off"
        cmd = f"flash protect {bank} {first} {last} {flag}"
        resp = await self._conn.send(cmd)
        _check_error(resp, f"flash protect {bank} {first}-{last} {flag}")
        log.info("Flash bank %d sectors %d-%d protection: %s", bank, first, last, flag)

    # ------------------------------------------------------------------
    # Verify
    # ------------------------------------------------------------------

    async def verify(self, bank: int, path: Path) -> bool:
        """Verify flash bank contents against a file.

        Args:
            bank: Flash bank number.
            path: Path to the reference binary file.

        Returns:
            True if the flash contents match the file, False otherwise.
        """
        cmd = f"flash verify_bank {bank} {path}"
        resp = await self._conn.send(cmd)
        if "error" in resp.lower() or "mismatch" in resp.lower():
            log.warning("Flash verify failed for bank %d against %s: %s", bank, path, resp.strip())
            return False
        log.info("Flash bank %d verified against %s", bank, path)
        return True


# ======================================================================
# Sync wrapper
# ======================================================================


class SyncFlash:
    """Synchronous wrapper around Flash for use outside async contexts."""

    def __init__(self, flash: Flash, loop: asyncio.AbstractEventLoop) -> None:
        self._flash = flash
        self._loop = loop

    def banks(self) -> list[FlashBank]:
        return self._loop.run_until_complete(self._flash.banks())

    def info(self, bank: int = 0) -> FlashBank:
        return self._loop.run_until_complete(self._flash.info(bank))

    def read(self, bank: int, offset: int, size: int) -> bytes:
        return self._loop.run_until_complete(self._flash.read(bank, offset, size))

    def read_to_file(self, bank: int, path: Path) -> None:
        self._loop.run_until_complete(self._flash.read_to_file(bank, path))

    def write(self, bank: int, offset: int, data: bytes) -> None:
        self._loop.run_until_complete(self._flash.write(bank, offset, data))

    def write_image(self, path: Path, erase: bool = True, verify: bool = True) -> None:
        self._loop.run_until_complete(self._flash.write_image(path, erase=erase, verify=verify))

    def erase_sector(self, bank: int, first: int, last: int) -> None:
        self._loop.run_until_complete(self._flash.erase_sector(bank, first, last))

    def erase_all(self, bank: int = 0) -> None:
        self._loop.run_until_complete(self._flash.erase_all(bank))

    def protect(self, bank: int, first: int, last: int, on: bool) -> None:
        self._loop.run_until_complete(self._flash.protect(bank, first, last, on=on))

    def verify(self, bank: int, path: Path) -> bool:
        return self._loop.run_until_complete(self._flash.verify(bank, path))
