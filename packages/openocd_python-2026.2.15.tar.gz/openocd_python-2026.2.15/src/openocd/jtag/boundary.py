"""SVF and XSVF boundary-scan file execution."""

from __future__ import annotations

from pathlib import Path

from openocd.connection.base import Connection
from openocd.errors import JTAGError


async def svf(
    conn: Connection,
    path: Path,
    *,
    tap: str | None = None,
    quiet: bool = False,
    progress: bool = True,
) -> None:
    """Execute an SVF (Serial Vector Format) file.

    Args:
        path: Path to the ``.svf`` file.
        tap: Restrict operations to this TAP. When ``None``, OpenOCD
             applies vectors to whatever TAP is appropriate.
        quiet: Suppress per-statement logging inside OpenOCD.
        progress: Show a progress indicator (default on).
    """
    parts = ["svf", str(path)]
    if tap is not None:
        parts.extend(["-tap", tap])
    if quiet:
        parts.append("quiet")
    if progress:
        parts.append("progress")
    resp = await conn.send(" ".join(parts))
    _check_error(resp, "svf")


async def xsvf(conn: Connection, tap: str, path: Path) -> None:
    """Execute an XSVF file against the given TAP.

    Args:
        tap: TAP to target (e.g. ``stm32f1x.cpu``).
        path: Path to the ``.xsvf`` file.
    """
    resp = await conn.send(f"xsvf {tap} {path}")
    _check_error(resp, "xsvf")


def _check_error(response: str, command: str) -> None:
    if "error" in response.lower():
        raise JTAGError(f"{command} failed: {response.strip()}")
