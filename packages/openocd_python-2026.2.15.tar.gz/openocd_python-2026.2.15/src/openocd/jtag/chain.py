"""JTAG chain enumeration and the main JTAGController facade."""

from __future__ import annotations

import asyncio
import logging
import re
from pathlib import Path

from openocd.connection.base import Connection
from openocd.errors import JTAGError
from openocd.jtag import boundary as _boundary
from openocd.jtag import scan as _scan
from openocd.jtag import state as _state
from openocd.types import JTAGState, TAPInfo

log = logging.getLogger(__name__)

# Regex for one row of ``scan_chain`` output.
# Example line:
#  0 stm32f1x.cpu        Y        0x3ba00477 0x3ba00477     4 0x01  0x0f
_CHAIN_ROW_RE = re.compile(
    r"^\s*\d+\s+"  # index
    r"(\S+)\s+"  # tap name  (chip.tap)
    r"([YN])\s+"  # enabled
    r"(0x[0-9a-fA-F]+)\s+"  # idcode
    r"(0x[0-9a-fA-F]+)\s+"  # expected
    r"(\d+)",  # ir_length
)


async def scan_chain(conn: Connection) -> list[TAPInfo]:
    """Query the JTAG scan chain and return a list of discovered TAPs."""
    resp = await conn.send("scan_chain")
    if "error" in resp.lower():
        raise JTAGError(f"scan_chain failed: {resp.strip()}")
    return _parse_scan_chain(resp)


async def new_tap(
    conn: Connection,
    chip: str,
    tap: str,
    ir_len: int,
    expected_id: int | None = None,
) -> None:
    """Declare a new TAP on the JTAG chain.

    Args:
        chip: Chip name (first part of the dotted TAP name).
        tap: TAP name (second part, e.g. ``cpu``, ``bs``).
        ir_len: Instruction register length in bits.
        expected_id: Expected IDCODE. When ``None``, OpenOCD skips
                     the IDCODE verification.
    """
    parts = ["jtag", "newtap", chip, tap, "-irlen", str(ir_len)]
    if expected_id is not None:
        parts.extend(["-expected-id", f"0x{expected_id:08x}"])
    resp = await conn.send(" ".join(parts))
    if "error" in resp.lower():
        raise JTAGError(f"newtap failed: {resp.strip()}")


def _parse_scan_chain(raw: str) -> list[TAPInfo]:
    """Parse the tabular output of ``scan_chain``."""
    taps: list[TAPInfo] = []
    for line in raw.splitlines():
        m = _CHAIN_ROW_RE.match(line)
        if not m:
            continue
        full_name = m.group(1)
        # Split "chip.tap" into components
        dot = full_name.find(".")
        if dot == -1:
            chip_part, tap_part = full_name, ""
        else:
            chip_part, tap_part = full_name[:dot], full_name[dot + 1 :]

        taps.append(
            TAPInfo(
                name=full_name,
                chip=chip_part,
                tap_name=tap_part,
                idcode=int(m.group(3), 16),
                ir_length=int(m.group(5)),
                enabled=m.group(2) == "Y",
            )
        )
    return taps


# ======================================================================
# JTAGController — unified facade
# ======================================================================


class JTAGController:
    """High-level async interface to all JTAG operations.

    Delegates to helper functions in the ``scan``, ``state``, and
    ``boundary`` sub-modules so each method stays concise.
    """

    def __init__(self, conn: Connection) -> None:
        self._conn = conn

    # -- Chain enumeration -------------------------------------------------

    async def scan_chain(self) -> list[TAPInfo]:
        """Return every TAP discovered on the JTAG chain."""
        return await scan_chain(self._conn)

    async def new_tap(
        self,
        chip: str,
        tap: str,
        ir_len: int,
        expected_id: int | None = None,
    ) -> None:
        """Declare a new TAP on the chain."""
        await new_tap(self._conn, chip, tap, ir_len, expected_id)

    # -- Scan operations ---------------------------------------------------

    async def irscan(self, tap: str, instruction: int) -> int:
        """Shift *instruction* into the TAP instruction register."""
        return await _scan.irscan(self._conn, tap, instruction)

    async def drscan(self, tap: str, bits: int, value: int) -> int:
        """Shift *value* (of width *bits*) through the data register."""
        return await _scan.drscan(self._conn, tap, bits, value)

    async def runtest(self, cycles: int) -> None:
        """Clock *cycles* TCK pulses in the Run-Test/Idle state."""
        await _scan.runtest(self._conn, cycles)

    # -- TAP state machine -------------------------------------------------

    async def pathmove(self, states: list[JTAGState]) -> None:
        """Walk the TAP controller through an explicit state sequence."""
        await _state.pathmove(self._conn, states)

    # -- Boundary scan (SVF / XSVF) ----------------------------------------

    async def svf(
        self,
        path: Path,
        tap: str | None = None,
        *,
        quiet: bool = False,
        progress: bool = True,
    ) -> None:
        """Execute an SVF boundary-scan file."""
        await _boundary.svf(self._conn, path, tap=tap, quiet=quiet, progress=progress)

    async def xsvf(self, tap: str, path: Path) -> None:
        """Execute an XSVF boundary-scan file against *tap*."""
        await _boundary.xsvf(self._conn, tap, path)


# ======================================================================
# SyncJTAGController — blocking wrappers
# ======================================================================


class SyncJTAGController:
    """Synchronous wrapper around :class:`JTAGController`.

    Every async method is exposed with the same signature but runs
    through ``loop.run_until_complete``.
    """

    def __init__(self, ctrl: JTAGController, loop: asyncio.AbstractEventLoop) -> None:
        self._ctrl = ctrl
        self._loop = loop

    # -- Chain -------------------------------------------------------------

    def scan_chain(self) -> list[TAPInfo]:
        return self._loop.run_until_complete(self._ctrl.scan_chain())

    def new_tap(
        self,
        chip: str,
        tap: str,
        ir_len: int,
        expected_id: int | None = None,
    ) -> None:
        self._loop.run_until_complete(self._ctrl.new_tap(chip, tap, ir_len, expected_id))

    # -- Scan --------------------------------------------------------------

    def irscan(self, tap: str, instruction: int) -> int:
        return self._loop.run_until_complete(self._ctrl.irscan(tap, instruction))

    def drscan(self, tap: str, bits: int, value: int) -> int:
        return self._loop.run_until_complete(self._ctrl.drscan(tap, bits, value))

    def runtest(self, cycles: int) -> None:
        self._loop.run_until_complete(self._ctrl.runtest(cycles))

    # -- State -------------------------------------------------------------

    def pathmove(self, states: list[JTAGState]) -> None:
        self._loop.run_until_complete(self._ctrl.pathmove(states))

    # -- Boundary ----------------------------------------------------------

    def svf(
        self,
        path: Path,
        tap: str | None = None,
        *,
        quiet: bool = False,
        progress: bool = True,
    ) -> None:
        self._loop.run_until_complete(self._ctrl.svf(path, tap, quiet=quiet, progress=progress))

    def xsvf(self, tap: str, path: Path) -> None:
        self._loop.run_until_complete(self._ctrl.xsvf(tap, path))
