"""IR/DR scan and TCK run-test operations."""

from __future__ import annotations

from openocd.connection.base import Connection
from openocd.errors import JTAGError


async def irscan(conn: Connection, tap: str, instruction: int) -> int:
    """Shift an instruction into the TAP instruction register.

    Returns the value shifted out of the IR during the operation.
    """
    resp = await conn.send(f"irscan {tap} 0x{instruction:x}")
    _check_error(resp, "irscan")
    # OpenOCD returns the shifted-out value as a hex string
    cleaned = resp.strip()
    if not cleaned:
        return 0
    try:
        return int(cleaned, 16)
    except ValueError:
        return 0


async def drscan(conn: Connection, tap: str, bits: int, value: int) -> int:
    """Shift data through the TAP data register.

    Args:
        tap: TAP name (e.g. ``stm32f1x.cpu``).
        bits: Number of bits to shift.
        value: Value to shift in.

    Returns the value shifted out of the DR.
    """
    resp = await conn.send(f"drscan {tap} {bits} 0x{value:x}")
    _check_error(resp, "drscan")
    cleaned = resp.strip()
    if not cleaned:
        return 0
    try:
        return int(cleaned, 16)
    except ValueError:
        return 0


async def runtest(conn: Connection, cycles: int) -> None:
    """Execute *cycles* TCK clocks in the Run-Test/Idle state."""
    if cycles < 0:
        raise JTAGError(f"runtest cycles must be non-negative, got {cycles}")
    resp = await conn.send(f"runtest {cycles}")
    _check_error(resp, "runtest")


def _check_error(response: str, command: str) -> None:
    """Raise JTAGError if OpenOCD reported an error."""
    if "error" in response.lower():
        raise JTAGError(f"{command} failed: {response.strip()}")
