"""TAP state-machine path movement."""

from __future__ import annotations

from openocd.connection.base import Connection
from openocd.errors import JTAGError
from openocd.types import JTAGState


async def pathmove(conn: Connection, states: list[JTAGState]) -> None:
    """Move the TAP controller through a sequence of states.

    Each state must be a legal single-step transition from the previous one
    in the IEEE 1149.1 state machine. OpenOCD validates the path and will
    report an error for illegal transitions.
    """
    if not states:
        raise JTAGError("pathmove requires at least one target state")
    state_names = " ".join(s.value for s in states)
    resp = await conn.send(f"pathmove {state_names}")
    _check_error(resp, "pathmove")


def _check_error(response: str, command: str) -> None:
    if "error" in response.lower():
        raise JTAGError(f"{command} failed: {response.strip()}")
