"""OpenOCD subprocess management.

Spawns an OpenOCD process, waits for the TCL RPC port to become
available, and provides clean shutdown.
"""

from __future__ import annotations

import asyncio
import logging
import shutil

from openocd.errors import ProcessError
from openocd.errors import TimeoutError as OpenOCDTimeoutError

log = logging.getLogger(__name__)

DEFAULT_TCL_PORT = 6666
READY_POLL_INTERVAL = 0.25


class OpenOCDProcess:
    """Spawn and manage an OpenOCD subprocess."""

    def __init__(self) -> None:
        self._proc: asyncio.subprocess.Process | None = None
        self._tcl_port: int = DEFAULT_TCL_PORT

    @property
    def pid(self) -> int | None:
        return self._proc.pid if self._proc else None

    @property
    def running(self) -> bool:
        return self._proc is not None and self._proc.returncode is None

    @property
    def tcl_port(self) -> int:
        return self._tcl_port

    async def start(
        self,
        config: str | list[str],
        extra_args: list[str] | None = None,
        tcl_port: int = DEFAULT_TCL_PORT,
        openocd_bin: str | None = None,
    ) -> None:
        """Start OpenOCD with the given configuration.

        Args:
            config: Config file path, inline ``-f`` / ``-c`` arguments string,
                    or a list of arguments (preferred for paths with spaces).
                    String form: ``"interface/cmsis-dap.cfg -f target/stm32f1x.cfg"``
                    List form: ``["-f", "my config/board.cfg", "-f", "target/stm32f1x.cfg"]``
            extra_args: Additional CLI arguments.
            tcl_port: TCL RPC port (default 6666).
            openocd_bin: Path to OpenOCD binary (auto-detected if None).
        """
        self._tcl_port = tcl_port
        binary = openocd_bin or shutil.which("openocd")
        if not binary:
            raise ProcessError("OpenOCD binary not found. Install it or pass openocd_bin=")

        args = [binary]

        # Accept either a pre-split list or a string to parse
        if isinstance(config, list):
            args.extend(config)
        else:
            config_parts = config.split()
            if not config_parts:
                raise ProcessError("Empty config string")
            i = 0
            while i < len(config_parts):
                part = config_parts[i]
                if part in ("-f", "-c"):
                    if i + 1 >= len(config_parts):
                        raise ProcessError(f"Config flag '{part}' requires an argument")
                    args.extend([part, config_parts[i + 1]])
                    i += 2
                else:
                    args.extend(["-f", part])
                    i += 1

        args.extend(["-c", f"tcl_port {tcl_port}"])

        if extra_args:
            args.extend(extra_args)

        log.info("Starting OpenOCD: %s", " ".join(args))
        try:
            self._proc = await asyncio.create_subprocess_exec(
                *args,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
            )
        except FileNotFoundError as exc:
            raise ProcessError(f"OpenOCD binary not found at {binary}") from exc
        except OSError as exc:
            raise ProcessError(f"Failed to start OpenOCD: {exc}") from exc

    async def wait_ready(self, timeout: float = 10.0) -> None:
        """Poll until the TCL RPC port is accepting connections."""
        deadline = asyncio.get_event_loop().time() + timeout
        while asyncio.get_event_loop().time() < deadline:
            # Check if the process died
            if self._proc and self._proc.returncode is not None:
                stderr = ""
                if self._proc.stderr:
                    raw = await self._proc.stderr.read()
                    stderr = raw.decode("utf-8", errors="replace")
                raise ProcessError(
                    f"OpenOCD exited with code {self._proc.returncode}: {stderr[-500:]}"
                )

            try:
                _, writer = await asyncio.wait_for(
                    asyncio.open_connection("localhost", self._tcl_port),
                    timeout=1.0,
                )
                writer.close()
                await writer.wait_closed()
                log.info("OpenOCD ready on TCL port %d", self._tcl_port)
                return
            except (OSError, TimeoutError):
                await asyncio.sleep(READY_POLL_INTERVAL)

        raise OpenOCDTimeoutError(f"OpenOCD did not become ready within {timeout}s")

    async def stop(self) -> None:
        """Terminate the OpenOCD process."""
        if not self._proc:
            return
        if self._proc.returncode is None:
            self._proc.terminate()
            try:
                await asyncio.wait_for(self._proc.wait(), timeout=5.0)
            except TimeoutError:
                self._proc.kill()
                await self._proc.wait()
            log.info("OpenOCD process stopped (pid=%d)", self._proc.pid)
        self._proc = None
