"""CPU register access via OpenOCD.

Wraps the ``reg`` command family to read and write individual registers,
list all registers, and provide ARM Cortex-M convenience accessors.
"""

from __future__ import annotations

import asyncio
import logging
import re

from openocd.connection.tcl_rpc import TclRpcConnection
from openocd.errors import TargetError, TargetNotHaltedError
from openocd.types import Register

log = logging.getLogger(__name__)

# Matches "reg <name>" output: "pc (/32): 0x08001234"
_REG_VALUE_RE = re.compile(r"(\S+)\s+\(/(\d+)\):\s*(0x[0-9a-fA-F]+)")

# Matches a row in "reg" (list all) output.
# Typical formats:
#   "(0) r0 (/32): 0x00000000"
#   "(123) xPSR (/32): 0x61000000 (dirty)"
_REG_LIST_RE = re.compile(
    r"\((\d+)\)\s+"  # register number
    r"(\S+)\s+"  # register name
    r"\(/(\d+)\):\s*"  # bit width
    r"(0x[0-9a-fA-F]+)"  # value
    r"(?:\s+\(dirty\))?"  # optional dirty flag
)


class Registers:
    """Read and write CPU registers."""

    def __init__(self, conn: TclRpcConnection) -> None:
        self._conn = conn

    async def read(self, name: str) -> int:
        """Read a single register by name and return its value.

        Args:
            name: Register name, e.g. ``"pc"``, ``"r0"``, ``"xPSR"``.

        Returns:
            The register value as an integer.

        Raises:
            TargetNotHaltedError: Target must be halted for register access.
            TargetError: Register not found or command failed.
        """
        resp = await self._conn.send(f"reg {name}")
        self._check_halted(resp)

        m = _REG_VALUE_RE.search(resp)
        if not m:
            raise TargetError(f"Cannot parse register '{name}' from: {resp}")

        return int(m.group(3), 16)

    async def write(self, name: str, value: int) -> None:
        """Write a value to a register.

        Args:
            name: Register name.
            value: Value to write.
        """
        resp = await self._conn.send(f"reg {name} 0x{value:x}")
        self._check_halted(resp)

        if "error" in resp.lower() and "not halted" not in resp.lower():
            raise TargetError(f"reg write failed: {resp}")

    async def read_all(self) -> dict[str, Register]:
        """Read all registers and return them as a dict keyed by name.

        Returns:
            Mapping of register name to Register dataclass.
        """
        resp = await self._conn.send("reg")
        self._check_halted(resp)

        registers: dict[str, Register] = {}
        for line in resp.splitlines():
            m = _REG_LIST_RE.search(line)
            if m:
                number = int(m.group(1))
                name = m.group(2)
                size = int(m.group(3))
                value = int(m.group(4), 16)
                dirty = "(dirty)" in line

                registers[name] = Register(
                    name=name,
                    number=number,
                    value=value,
                    size=size,
                    dirty=dirty,
                )

        return registers

    async def read_many(self, names: list[str]) -> dict[str, int]:
        """Read several registers by name.

        Args:
            names: List of register names.

        Returns:
            Mapping of register name to value.
        """
        results: dict[str, int] = {}
        for name in names:
            results[name] = await self.read(name)
        return results

    # ------------------------------------------------------------------
    # ARM Cortex-M convenience accessors
    # ------------------------------------------------------------------

    async def pc(self) -> int:
        """Read the program counter."""
        return await self.read("pc")

    async def sp(self) -> int:
        """Read the stack pointer."""
        return await self.read("sp")

    async def lr(self) -> int:
        """Read the link register."""
        return await self.read("lr")

    async def xpsr(self) -> int:
        """Read the xPSR (combined program status register)."""
        return await self.read("xPSR")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _check_halted(resp: str) -> None:
        """Raise TargetNotHaltedError if the response indicates the target
        is not halted (register access requires a halted target).
        """
        lower = resp.lower()
        if "not halted" in lower or "target not halted" in lower:
            raise TargetNotHaltedError("Target must be halted to access registers")


class SyncRegisters:
    """Synchronous wrapper around Registers."""

    def __init__(self, registers: Registers, loop: asyncio.AbstractEventLoop) -> None:
        self._registers = registers
        self._loop = loop

    def read(self, name: str) -> int:
        return self._loop.run_until_complete(self._registers.read(name))

    def write(self, name: str, value: int) -> None:
        self._loop.run_until_complete(self._registers.write(name, value))

    def read_all(self) -> dict[str, Register]:
        return self._loop.run_until_complete(self._registers.read_all())

    def read_many(self, names: list[str]) -> dict[str, int]:
        return self._loop.run_until_complete(self._registers.read_many(names))

    def pc(self) -> int:
        return self._loop.run_until_complete(self._registers.pc())

    def sp(self) -> int:
        return self._loop.run_until_complete(self._registers.sp())

    def lr(self) -> int:
        return self._loop.run_until_complete(self._registers.lr())

    def xpsr(self) -> int:
        return self._loop.run_until_complete(self._registers.xpsr())
