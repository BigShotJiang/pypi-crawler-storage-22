"""Real-Time Transfer (RTT) support via OpenOCD.

SEGGER RTT provides high-speed bidirectional communication between
a debug host and an embedded target using shared memory in RAM.
OpenOCD exposes RTT through its ``rtt`` command family.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
from typing import TYPE_CHECKING

from openocd.errors import OpenOCDError
from openocd.types import RTTChannel

if TYPE_CHECKING:
    from openocd.connection.base import Connection

log = logging.getLogger(__name__)


class RTTManager:
    """Control and use SEGGER RTT channels via OpenOCD.

    Typical flow::

        rtt = RTTManager(conn)
        await rtt.setup(address=0x20000000, size=0x1000)
        await rtt.start()
        channels = await rtt.channels()
        data = await rtt.read(0)
        await rtt.write(0, "hello\\n")
        await rtt.stop()
    """

    def __init__(self, conn: Connection) -> None:
        self._conn = conn

    async def setup(
        self,
        address: int,
        size: int,
        id_string: str = "SEGGER RTT",
    ) -> None:
        """Configure RTT control block search parameters.

        Args:
            address: Start address of the RAM region to search.
            size: Size of the search region in bytes.
            id_string: RTT control block identifier (default "SEGGER RTT").

        Raises:
            OpenOCDError: If the setup command fails.
        """
        cmd = f'rtt setup 0x{address:X} 0x{size:X} "{id_string}"'
        response = await self._conn.send(cmd)
        _check_rtt_response(response, cmd)
        log.info(
            "RTT setup: search 0x%08X +0x%X id=%r",
            address,
            size,
            id_string,
        )

    async def start(self) -> None:
        """Start RTT — searches for the control block and activates channels.

        Raises:
            OpenOCDError: If the control block is not found or start fails.
        """
        response = await self._conn.send("rtt start")
        _check_rtt_response(response, "rtt start")
        log.info("RTT started")

    async def stop(self) -> None:
        """Stop RTT communication.

        Raises:
            OpenOCDError: If the stop command fails.
        """
        response = await self._conn.send("rtt stop")
        _check_rtt_response(response, "rtt stop")
        log.info("RTT stopped")

    async def channels(self) -> list[RTTChannel]:
        """List available RTT channels.

        Returns:
            List of RTTChannel descriptors (index, name, size, direction).

        Raises:
            OpenOCDError: If the channels command fails.
        """
        response = await self._conn.send("rtt channels")
        _check_rtt_response(response, "rtt channels")
        return _parse_channels(response)

    async def read(self, channel: int) -> str:
        """Read pending data from an RTT up-channel.

        Args:
            channel: Channel index (typically 0 for Terminal).

        Returns:
            The data read as a string (may be empty if nothing pending).

        Raises:
            OpenOCDError: If the read command fails.
        """
        cmd = f"rtt channelread {channel}"
        response = await self._conn.send(cmd)
        _check_rtt_response(response, cmd)
        return response

    async def write(self, channel: int, data: str) -> None:
        """Write data to an RTT down-channel.

        Args:
            channel: Channel index (typically 0 for Terminal).
            data: String data to send to the target.

        Raises:
            OpenOCDError: If the write command fails.
        """
        # Escape TCL special characters to prevent injection
        escaped = (
            data.replace("\\", "\\\\").replace('"', '\\"').replace("[", "\\[").replace("$", "\\$")
        )
        cmd = f'rtt channelwrite {channel} "{escaped}"'
        response = await self._conn.send(cmd)
        _check_rtt_response(response, cmd)


class SyncRTTManager:
    """Synchronous wrapper around RTTManager."""

    def __init__(self, manager: RTTManager, loop: asyncio.AbstractEventLoop) -> None:
        self._manager = manager
        self._loop = loop

    def setup(
        self,
        address: int,
        size: int,
        id_string: str = "SEGGER RTT",
    ) -> None:
        self._loop.run_until_complete(self._manager.setup(address, size, id_string))

    def start(self) -> None:
        self._loop.run_until_complete(self._manager.start())

    def stop(self) -> None:
        self._loop.run_until_complete(self._manager.stop())

    def channels(self) -> list[RTTChannel]:
        return self._loop.run_until_complete(self._manager.channels())

    def read(self, channel: int) -> str:
        return self._loop.run_until_complete(self._manager.read(channel))

    def write(self, channel: int, data: str) -> None:
        self._loop.run_until_complete(self._manager.write(channel, data))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _check_rtt_response(response: str, command: str) -> None:
    """Raise on error responses from RTT commands."""
    if response and "error" in response.lower():
        raise OpenOCDError(f"RTT command failed ({command}): {response}")


def _parse_channels(response: str) -> list[RTTChannel]:
    """Parse the output of ``rtt channels`` into RTTChannel objects.

    OpenOCD typically outputs lines like::

        Up-channels:
          0: Terminal 1024
        Down-channels:
          0: Terminal 16

    The exact format may vary by OpenOCD version; this parser is
    intentionally lenient.
    """
    channels: list[RTTChannel] = []
    direction = "up"

    for line in response.splitlines():
        stripped = line.strip()
        lower = stripped.lower()

        if "up-channel" in lower or lower.startswith("up"):
            direction = "up"
            continue
        if "down-channel" in lower or lower.startswith("down"):
            direction = "down"
            continue

        # Try to parse lines like "0: Terminal 1024"
        if ":" in stripped and stripped[0].isdigit():
            parts = stripped.split(":", 1)
            try:
                index = int(parts[0].strip())
            except ValueError:
                continue

            rest = parts[1].strip().split()
            name = rest[0] if rest else f"channel_{index}"
            size = 0
            if len(rest) >= 2:
                with contextlib.suppress(ValueError):
                    size = int(rest[-1])

            channels.append(
                RTTChannel(
                    index=index,
                    name=name,
                    size=size,
                    direction=direction,
                )
            )

    return channels
