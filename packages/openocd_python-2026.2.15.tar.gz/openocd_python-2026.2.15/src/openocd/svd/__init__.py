"""SVD (System View Description) integration for peripheral/register decoding."""

from openocd.svd.peripheral import SVDManager, SyncSVDManager

__all__ = ["SVDManager", "SyncSVDManager"]
