"""Register value decoding using SVD metadata.

Takes a raw integer read from hardware and splits it into named bitfields
using the field definitions from a parsed SVD file.
"""

from __future__ import annotations

from typing import Any

from openocd.types import BitField, DecodedRegister


def decode_register(
    peripheral_obj: Any,
    register_obj: Any,
    raw_value: int,
) -> DecodedRegister:
    """Decode a raw register value into named bitfields using SVD metadata.

    Args:
        peripheral_obj: cmsis_svd peripheral (used for base_address and name).
        register_obj: cmsis_svd register (used for fields, address_offset, name).
        raw_value: The 32-bit value read from hardware.

    Returns:
        A DecodedRegister with all fields extracted and annotated.
    """
    address = peripheral_obj.base_address + register_obj.address_offset
    fields: list[BitField] = []

    for svd_field in register_obj.fields or []:
        mask = ((1 << svd_field.bit_width) - 1) << svd_field.bit_offset
        value = (raw_value & mask) >> svd_field.bit_offset
        fields.append(
            BitField(
                name=svd_field.name,
                offset=svd_field.bit_offset,
                width=svd_field.bit_width,
                value=value,
                description=svd_field.description or "",
            )
        )

    # Sort fields by bit offset (low to high) for consistent display
    fields.sort(key=lambda f: f.offset)

    return DecodedRegister(
        peripheral=peripheral_obj.name,
        register=register_obj.name,
        address=address,
        raw_value=raw_value,
        fields=fields,
    )
