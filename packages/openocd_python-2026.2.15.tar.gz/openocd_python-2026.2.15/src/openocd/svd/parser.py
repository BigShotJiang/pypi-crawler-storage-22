"""SVD file loading and peripheral/register lookup.

Wraps cmsis_svd to parse CMSIS-SVD XML files and provide indexed access
to peripherals and their registers.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from cmsis_svd import SVDParser

from openocd.errors import SVDError

log = logging.getLogger(__name__)


class SVDParserWrapper:
    """Load and cache parsed SVD device data."""

    def __init__(self) -> None:
        self._device: Any = None
        self._peripherals: dict[str, Any] = {}

    @property
    def loaded(self) -> bool:
        """Whether an SVD file has been parsed."""
        return self._device is not None

    def load(self, svd_path: Path) -> None:
        """Parse an SVD file and index peripherals/registers.

        Args:
            svd_path: Path to the .svd file on disk.

        Raises:
            SVDError: If the file cannot be found or parsed.
        """
        path = Path(svd_path)
        if not path.exists():
            raise SVDError(f"SVD file not found: {path}")

        try:
            parser = SVDParser.for_xml_file(str(path))
            self._device = parser.get_device()
        except Exception as exc:
            raise SVDError(f"Failed to parse SVD file {path}: {exc}") from exc

        self._peripherals = {p.name: p for p in self._device.get_peripherals()}
        log.info(
            "Loaded SVD for %s — %d peripherals",
            getattr(self._device, "name", "unknown"),
            len(self._peripherals),
        )

    def _require_loaded(self) -> None:
        if not self.loaded:
            raise SVDError("No SVD file loaded — call load() first")

    def get_peripheral(self, name: str) -> Any:
        """Look up a peripheral by name.

        Args:
            name: Peripheral name (case-sensitive, e.g. "GPIOA", "USART1").

        Returns:
            The cmsis_svd peripheral object.

        Raises:
            SVDError: If no SVD is loaded or the peripheral is not found.
        """
        self._require_loaded()
        periph = self._peripherals.get(name)
        if periph is None:
            raise SVDError(
                f"Peripheral '{name}' not found. Available: {', '.join(sorted(self._peripherals))}"
            )
        return periph

    def get_register(self, peripheral: str, register: str) -> Any:
        """Look up a register within a peripheral.

        Args:
            peripheral: Peripheral name.
            register: Register name (e.g. "CR1", "SR").

        Returns:
            The cmsis_svd register object.

        Raises:
            SVDError: If the peripheral or register is not found.
        """
        periph = self.get_peripheral(peripheral)
        registers = periph.registers or []
        for reg in registers:
            if reg.name == register:
                return reg

        available = [r.name for r in registers]
        raise SVDError(
            f"Register '{register}' not found in {peripheral}. "
            f"Available: {', '.join(sorted(available))}"
        )

    def list_peripherals(self) -> list[str]:
        """Return sorted names of all peripherals in the SVD.

        Raises:
            SVDError: If no SVD is loaded.
        """
        self._require_loaded()
        return sorted(self._peripherals.keys())

    def list_registers(self, peripheral: str) -> list[str]:
        """Return sorted register names for a peripheral.

        Args:
            peripheral: Peripheral name.

        Raises:
            SVDError: If the peripheral is not found.
        """
        periph = self.get_peripheral(peripheral)
        registers = periph.registers or []
        return sorted(r.name for r in registers)
