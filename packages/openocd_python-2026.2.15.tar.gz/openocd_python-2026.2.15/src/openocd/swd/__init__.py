"""SWD/DAP operations: DP/AP register access and DAP discovery."""

from openocd.swd.controller import SWDController, SyncSWDController

__all__ = ["SWDController", "SyncSWDController"]
