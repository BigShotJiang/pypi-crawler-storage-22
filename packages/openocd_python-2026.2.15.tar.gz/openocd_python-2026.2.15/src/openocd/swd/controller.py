"""SWDController — unified facade for SWD/DAP operations."""

from __future__ import annotations

import asyncio
import logging

from openocd.connection.base import Connection
from openocd.errors import SWDError
from openocd.swd import dap as _dap
from openocd.types import APInfo, DAPInfo

log = logging.getLogger(__name__)


class SWDController:
    """High-level async interface to SWD/DAP operations.

    Most boards have a single DAP.  When *dap* is ``None``, the controller
    auto-discovers via ``dap names`` and uses the first (or only) DAP.
    Multi-DAP boards (e.g. STM32H7 dual-core) pass the DAP name explicitly.
    """

    def __init__(self, conn: Connection) -> None:
        self._conn = conn
        self._cached_dap: str | None = None

    # -- DAP name resolution -----------------------------------------------

    async def _resolve_dap(self, dap: str | None) -> str:
        """Return the DAP name to use: explicit or auto-discovered.

        When *dap* is ``None``, uses the auto-discovered DAP (first result
        from ``dap names``). Once resolved, the name is cached for the
        lifetime of this controller unless :meth:`invalidate_cache` is called.
        """
        if dap is not None:
            return dap
        if self._cached_dap is not None:
            return self._cached_dap

        names = await _dap.dap_names(self._conn)
        if not names:
            raise SWDError("No DAP instances found (is the transport set to SWD?)")
        self._cached_dap = names[0]
        log.debug("Auto-resolved DAP: %s", self._cached_dap)
        return self._cached_dap

    def invalidate_cache(self) -> None:
        """Clear the cached DAP name.

        Call after transport changes, probe reconnection, or target
        reconfiguration that may change which DAPs are available.
        """
        self._cached_dap = None
        log.debug("DAP cache invalidated")

    # -- DAP discovery -----------------------------------------------------

    async def info(self, dap: str | None = None) -> DAPInfo:
        """Query DAP information."""
        name = await self._resolve_dap(dap)
        return await _dap.dap_info(self._conn, name)

    async def list_aps(self, dap: str | None = None) -> list[APInfo]:
        """Enumerate Access Ports on the DAP."""
        name = await self._resolve_dap(dap)
        return await _dap.enumerate_aps(self._conn, name)

    # -- DP register access ------------------------------------------------

    async def dpreg(self, address: int, value: int | None = None, *, dap: str | None = None) -> int:
        """Read or write a DP register.

        When *value* is ``None``, performs a read and returns the value.
        When *value* is provided, performs a write and returns the written value.
        """
        name = await self._resolve_dap(dap)
        if value is None:
            return await _dap.dpreg_read(self._conn, name, address)
        await _dap.dpreg_write(self._conn, name, address, value)
        return value

    # -- AP register access ------------------------------------------------

    async def apreg(
        self, ap: int, address: int, value: int | None = None, *, dap: str | None = None
    ) -> int:
        """Read or write an AP register.

        When *value* is ``None``, performs a read and returns the value.
        When *value* is provided, performs a write and returns the written value.
        """
        name = await self._resolve_dap(dap)
        if value is None:
            return await _dap.apreg_read(self._conn, name, ap, address)
        await _dap.apreg_write(self._conn, name, ap, address, value)
        return value

    # -- Convenience: well-known DP registers ------------------------------

    async def dpidr(self, dap: str | None = None) -> int:
        """Read the DP IDR (address 0x0) — identifies the debug port."""
        return await self.dpreg(0x0, dap=dap)

    async def target_id(self, dap: str | None = None) -> int:
        """Read the TARGETID register (DP address 0x24, DPv2+)."""
        return await self.dpreg(0x24, dap=dap)


# ======================================================================
# SyncSWDController — blocking wrappers
# ======================================================================


class SyncSWDController:
    """Synchronous wrapper around :class:`SWDController`.

    Every async method is exposed with the same signature but runs
    through ``loop.run_until_complete``.
    """

    def __init__(self, ctrl: SWDController, loop: asyncio.AbstractEventLoop) -> None:
        self._ctrl = ctrl
        self._loop = loop

    def info(self, dap: str | None = None) -> DAPInfo:
        return self._loop.run_until_complete(self._ctrl.info(dap))

    def list_aps(self, dap: str | None = None) -> list[APInfo]:
        return self._loop.run_until_complete(self._ctrl.list_aps(dap))

    def dpreg(self, address: int, value: int | None = None, *, dap: str | None = None) -> int:
        return self._loop.run_until_complete(self._ctrl.dpreg(address, value, dap=dap))

    def apreg(
        self, ap: int, address: int, value: int | None = None, *, dap: str | None = None
    ) -> int:
        return self._loop.run_until_complete(self._ctrl.apreg(ap, address, value, dap=dap))

    def dpidr(self, dap: str | None = None) -> int:
        return self._loop.run_until_complete(self._ctrl.dpidr(dap))

    def target_id(self, dap: str | None = None) -> int:
        return self._loop.run_until_complete(self._ctrl.target_id(dap))

    def invalidate_cache(self) -> None:
        self._ctrl.invalidate_cache()
