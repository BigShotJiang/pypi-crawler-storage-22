"""Low-level DAP functions for SWD/DAP register access.

All functions take a connection and a DAP name, then issue the
corresponding OpenOCD ``<dap>`` sub-commands.  Parsing is defensive
because OpenOCD output varies between versions.
"""

from __future__ import annotations

import logging
import re

from openocd.connection.base import Connection
from openocd.errors import SWDError
from openocd.types import APInfo, DAPInfo

log = logging.getLogger(__name__)

# Match a hex value anywhere in the response (OpenOCD returns "0x2ba01477\n")
_HEX_RE = re.compile(r"0x([0-9a-fA-F]+)")

# Count APs in dap info output — looks for "AP # <n>" lines
_AP_NUM_RE = re.compile(r"AP\s*#?\s*(\d+)")

# DPIDR line in dap info output
_DPIDR_RE = re.compile(r"DPIDR\s*[:=]?\s*(0x[0-9a-fA-F]+)", re.IGNORECASE)

# OpenOCD error patterns: match the structure of actual error responses,
# not arbitrary English words. Avoids false positives on output like
# "error detection enabled" or register descriptions containing "invalid".
_ERROR_RE = re.compile(
    r"^Error:|^invalid command|^invalid|command not found",
    re.IGNORECASE | re.MULTILINE,
)

_U32_MAX = 0xFFFFFFFF
_AP_MAX = 255


def _validate_u32(value: int, name: str) -> None:
    """Ensure value is a valid unsigned 32-bit integer."""
    if not isinstance(value, int) or value < 0 or value > _U32_MAX:
        raise SWDError(f"{name} must be 0..0xFFFFFFFF, got {value!r}")


def _validate_ap_num(ap_num: int) -> None:
    """Ensure AP number is in the valid range (0-255 per ARM ADI spec)."""
    if not isinstance(ap_num, int) or ap_num < 0 or ap_num > _AP_MAX:
        raise SWDError(f"AP number must be 0..255, got {ap_num!r}")


def _parse_hex(resp: str, context: str) -> int:
    """Extract the first hex value from an OpenOCD response string."""
    m = _HEX_RE.search(resp)
    if m is None:
        raise SWDError(f"{context}: no hex value in response: {resp.strip()!r}")
    return int(m.group(1), 16)


def _check_error(resp: str, context: str) -> None:
    """Raise SWDError if the response indicates a failure.

    Matches OpenOCD's actual error response patterns (``Error:``,
    ``invalid command``) rather than naive substring matching, to avoid
    false positives on legitimate output containing words like "error".
    """
    if _ERROR_RE.search(resp):
        raise SWDError(f"{context}: {resp.strip()}")


async def dap_names(conn: Connection) -> list[str]:
    """Return the list of DAP instance names known to OpenOCD."""
    resp = await conn.send("dap names")
    _check_error(resp, "dap names")
    names = [n.strip() for n in resp.strip().splitlines() if n.strip()]
    return names


async def dap_info(conn: Connection, dap_name: str) -> DAPInfo:
    """Query full DAP info and return a structured DAPInfo."""
    resp = await conn.send(f"{dap_name} info")
    _check_error(resp, f"{dap_name} info")

    # Extract DPIDR
    dpidr = 0
    m = _DPIDR_RE.search(resp)
    if m:
        dpidr = int(m.group(1), 16)
    else:
        log.warning(
            "Could not parse DPIDR from '%s info' output — "
            "OpenOCD format may have changed. Raw: %.200s",
            dap_name,
            resp,
        )

    # Count APs mentioned
    ap_indices = set(_AP_NUM_RE.findall(resp))
    ap_count = len(ap_indices)

    return DAPInfo(
        name=dap_name,
        dpidr=dpidr,
        ap_count=ap_count,
        raw_info=resp.strip(),
    )


async def dpreg_read(conn: Connection, dap_name: str, address: int) -> int:
    """Read a DP register at *address* via ``<dap> dpreg <addr>``."""
    _validate_u32(address, "DP register address")
    cmd = f"{dap_name} dpreg {address:#x}"
    resp = await conn.send(cmd)
    _check_error(resp, cmd)
    return _parse_hex(resp, cmd)


async def dpreg_write(conn: Connection, dap_name: str, address: int, value: int) -> None:
    """Write *value* to DP register at *address*."""
    _validate_u32(address, "DP register address")
    _validate_u32(value, "DP register value")
    cmd = f"{dap_name} dpreg {address:#x} {value:#x}"
    resp = await conn.send(cmd)
    _check_error(resp, cmd)


async def apreg_read(conn: Connection, dap_name: str, ap_num: int, address: int) -> int:
    """Read an AP register: ``<dap> apreg <ap> <addr>``."""
    _validate_ap_num(ap_num)
    _validate_u32(address, "AP register address")
    cmd = f"{dap_name} apreg {ap_num} {address:#x}"
    resp = await conn.send(cmd)
    _check_error(resp, cmd)
    return _parse_hex(resp, cmd)


async def apreg_write(
    conn: Connection, dap_name: str, ap_num: int, address: int, value: int
) -> None:
    """Write *value* to AP register: ``<dap> apreg <ap> <addr> <val>``."""
    _validate_ap_num(ap_num)
    _validate_u32(address, "AP register address")
    _validate_u32(value, "AP register value")
    cmd = f"{dap_name} apreg {ap_num} {address:#x} {value:#x}"
    resp = await conn.send(cmd)
    _check_error(resp, cmd)


def _classify_ap(idr: int) -> str:
    """Classify an AP by its IDR value.

    The AP IDR Class field (bits 16:13) indicates the AP type per ARM ADI:
      0x0 = no AP / reserved
      0x1 = COM-AP (deprecated MEM-AP variant, ADIv5)
      0x8 = MEM-AP (ADIv5)
      0x9 = MEM-AP (ADIv6)
    The Type field (bits 3:0) further distinguishes variants.
    """
    if idr == 0:
        return "unknown"
    class_field = (idr >> 13) & 0xF
    if class_field in (0x1, 0x8, 0x9):
        return "MEM-AP"
    type_field = idr & 0xF
    if type_field == 0x0:
        return "JTAG-AP"
    return "unknown"


async def enumerate_aps(conn: Connection, dap_name: str, max_aps: int = 256) -> list[APInfo]:
    """Probe APs by reading IDR (offset 0xFC) until we get 0 or hit *max_aps*.

    Each AP with a non-zero IDR is included. We also read the BASE register
    (offset 0xF8) to capture the ROM table address.
    """
    aps: list[APInfo] = []
    for idx in range(max_aps):
        try:
            idr = await apreg_read(conn, dap_name, idx, 0xFC)
        except SWDError as exc:
            log.warning("AP enumeration stopped at index %d due to error: %s", idx, exc)
            break
        if idr == 0:
            break

        try:
            base = await apreg_read(conn, dap_name, idx, 0xF8)
        except SWDError:
            base = 0

        aps.append(
            APInfo(
                index=idx,
                idr=idr,
                base=base,
                ap_type=_classify_ap(idr),
            )
        )
    return aps
