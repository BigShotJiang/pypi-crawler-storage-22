"""Target state control — halt, resume, step, reset, and state queries.

Wraps the OpenOCD target commands: halt, resume, step, reset,
wait_halt, and targets (for state inspection).
"""

from __future__ import annotations

import asyncio
import logging
import re
from typing import Literal

from openocd.connection.tcl_rpc import TclRpcConnection
from openocd.errors import TargetError, TimeoutError
from openocd.types import TargetState

log = logging.getLogger(__name__)

# Matches a target row from "targets" output, e.g.:
#   " 0* stm32f1x.cpu       cortex_m   little stm32f1x.cpu       halted"
_TARGET_ROW_RE = re.compile(
    r"^\s*\d+\*?\s+"  # index, optional current marker
    r"(\S+)\s+"  # target name
    r"\S+\s+"  # type
    r"\S+\s+"  # endian
    r"\S+\s+"  # tap name
    r"(\S+)"  # state
)


class Target:
    """Target execution control — halt, resume, step, reset."""

    def __init__(self, conn: TclRpcConnection) -> None:
        self._conn = conn

    async def halt(self) -> TargetState:
        """Halt the target and return the resulting state."""
        resp = await self._conn.send("halt")
        if "error" in resp.lower() and "already" not in resp.lower():
            raise TargetError(f"halt failed: {resp}")
        return await self._parse_state()

    async def resume(self, address: int | None = None) -> None:
        """Resume execution, optionally from a specific address."""
        cmd = "resume"
        if address is not None:
            cmd = f"resume 0x{address:x}"
        resp = await self._conn.send(cmd)
        if "error" in resp.lower():
            raise TargetError(f"resume failed: {resp}")

    async def step(self, address: int | None = None) -> TargetState:
        """Single-step and return the resulting state."""
        cmd = "step"
        if address is not None:
            cmd = f"step 0x{address:x}"
        resp = await self._conn.send(cmd)
        if "error" in resp.lower():
            raise TargetError(f"step failed: {resp}")
        return await self._parse_state()

    async def reset(self, mode: Literal["run", "halt", "init"] = "halt") -> None:
        """Reset the target.

        Args:
            mode: Reset mode — "run" resumes after reset, "halt" stops at
                  the reset vector, "init" runs init scripts after reset.
        """
        resp = await self._conn.send(f"reset {mode}")
        if "error" in resp.lower():
            raise TargetError(f"reset failed: {resp}")

    async def wait_halt(self, timeout_ms: int = 5000) -> TargetState:
        """Block until the target halts or the timeout expires.

        Args:
            timeout_ms: Maximum wait time in milliseconds.

        Raises:
            TimeoutError: Target did not halt within the deadline.
        """
        resp = await self._conn.send(f"wait_halt {timeout_ms}")
        if "timed out" in resp.lower() or "time out" in resp.lower():
            raise TimeoutError(f"Target did not halt within {timeout_ms}ms")
        if "error" in resp.lower():
            raise TargetError(f"wait_halt failed: {resp}")
        return await self._parse_state()

    async def state(self) -> TargetState:
        """Query and return the current target state."""
        return await self._parse_state()

    async def _parse_state(self) -> TargetState:
        """Parse the ``targets`` command output into a TargetState.

        The output looks like::

            TargetName         Type       Endian TapName            State
          --  ------------------ ---------- ------ ------------------ ------------
           0* stm32f1x.cpu       cortex_m   little stm32f1x.cpu       halted

        If the target is halted, also reads the program counter via ``reg pc``.
        """
        resp = await self._conn.send("targets")

        name = "unknown"
        raw_state = "unknown"

        for line in resp.splitlines():
            m = _TARGET_ROW_RE.match(line)
            if m:
                name = m.group(1)
                raw_state = m.group(2).lower()
                break

        # Normalize to our known state literals
        if raw_state not in ("running", "halted", "reset", "debug-running"):
            raw_state = "unknown"

        pc: int | None = None
        if raw_state == "halted":
            try:
                pc = await self._read_pc()
            except Exception:
                log.debug("Could not read PC while halted", exc_info=True)

        return TargetState(name=name, state=raw_state, current_pc=pc)

    async def _read_pc(self) -> int:
        """Read the program counter from the halted target."""
        resp = await self._conn.send("reg pc")
        # Output: "pc (/32): 0x08001234"
        m = re.search(r":\s*(0x[0-9a-fA-F]+)", resp)
        if not m:
            raise TargetError(f"Cannot parse PC from: {resp}")
        return int(m.group(1), 16)


class SyncTarget:
    """Synchronous wrapper around Target."""

    def __init__(self, target: Target, loop: asyncio.AbstractEventLoop) -> None:
        self._target = target
        self._loop = loop

    def halt(self) -> TargetState:
        return self._loop.run_until_complete(self._target.halt())

    def resume(self, address: int | None = None) -> None:
        self._loop.run_until_complete(self._target.resume(address))

    def step(self, address: int | None = None) -> TargetState:
        return self._loop.run_until_complete(self._target.step(address))

    def reset(self, mode: Literal["run", "halt", "init"] = "halt") -> None:
        self._loop.run_until_complete(self._target.reset(mode))

    def wait_halt(self, timeout_ms: int = 5000) -> TargetState:
        return self._loop.run_until_complete(self._target.wait_halt(timeout_ms))

    def state(self) -> TargetState:
        return self._loop.run_until_complete(self._target.state())
