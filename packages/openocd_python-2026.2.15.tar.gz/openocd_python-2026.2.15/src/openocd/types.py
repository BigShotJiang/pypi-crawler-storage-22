"""Shared dataclasses and enums used across the openocd-python package."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Literal

# ---------------------------------------------------------------------------
# Target
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TargetState:
    """Snapshot of target execution state."""

    name: str
    state: Literal["running", "halted", "reset", "debug-running", "unknown"]
    current_pc: int | None = None


# ---------------------------------------------------------------------------
# Registers
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Register:
    """A single CPU register."""

    name: str
    number: int
    value: int
    size: int  # bits
    dirty: bool = False


# ---------------------------------------------------------------------------
# Flash
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FlashSector:
    """One sector inside a flash bank."""

    index: int
    offset: int
    size: int
    protected: bool


@dataclass(frozen=True)
class FlashBank:
    """A flash bank reported by OpenOCD."""

    index: int
    name: str
    base: int
    size: int
    bus_width: int
    chip_width: int
    target: str
    sectors: list[FlashSector] = field(default_factory=list)


# ---------------------------------------------------------------------------
# JTAG
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TAPInfo:
    """One TAP discovered on the JTAG chain."""

    name: str
    chip: str
    tap_name: str
    idcode: int
    ir_length: int
    enabled: bool


class JTAGState(str, Enum):
    """IEEE 1149.1 TAP controller states."""

    RESET = "RESET"
    IDLE = "IDLE"
    DRSELECT = "DRSELECT"
    DRCAPTURE = "DRCAPTURE"
    DRSHIFT = "DRSHIFT"
    DREXIT1 = "DREXIT1"
    DRPAUSE = "DRPAUSE"
    DREXIT2 = "DREXIT2"
    DRUPDATE = "DRUPDATE"
    IRSELECT = "IRSELECT"
    IRCAPTURE = "IRCAPTURE"
    IRSHIFT = "IRSHIFT"
    IREXIT1 = "IREXIT1"
    IRPAUSE = "IRPAUSE"
    IREXIT2 = "IREXIT2"
    IRUPDATE = "IRUPDATE"


# ---------------------------------------------------------------------------
# Memory
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MemoryRegion:
    """A chunk of memory read from the target."""

    address: int
    size: int
    data: bytes


# ---------------------------------------------------------------------------
# SVD
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BitField:
    """One decoded bitfield inside a register."""

    name: str
    offset: int
    width: int
    value: int
    description: str


@dataclass(frozen=True)
class DecodedRegister:
    """A register value decoded into named bitfields via SVD."""

    peripheral: str
    register: str
    address: int
    raw_value: int
    fields: list[BitField] = field(default_factory=list)

    def __str__(self) -> str:
        header = f"{self.peripheral}.{self.register}"
        lines = [f"{header} @ 0x{self.address:08X} = 0x{self.raw_value:08X}"]
        for f in self.fields:
            bits = f"{f.offset + f.width - 1}:{f.offset}" if f.width > 1 else str(f.offset)
            lines.append(f"  [{bits:>5s}] {f.name:<20s} = 0x{f.value:X}  {f.description}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Breakpoints
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Breakpoint:
    """An active breakpoint."""

    number: int
    type: Literal["hw", "sw"]
    address: int
    length: int
    enabled: bool


@dataclass(frozen=True)
class Watchpoint:
    """An active watchpoint."""

    number: int
    address: int
    length: int
    access: Literal["r", "w", "rw"]


# ---------------------------------------------------------------------------
# RTT
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RTTChannel:
    """An RTT channel descriptor."""

    index: int
    name: str
    size: int
    direction: Literal["up", "down"]


# ---------------------------------------------------------------------------
# SWD / DAP
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DAPInfo:
    """Debug Access Port information returned by ``dap info``."""

    name: str  # DAP instance name (e.g. "stm32f1x.dap")
    dpidr: int  # DP ID Register value
    ap_count: int  # Number of access ports discovered
    raw_info: str  # Full ``dap info`` output for detailed parsing


@dataclass(frozen=True)
class APInfo:
    """Access Port descriptor discovered during AP enumeration."""

    index: int  # AP number (0, 1, 2...)
    idr: int  # AP ID Register (from apreg <n> 0xfc)
    base: int  # ROM table base address (from apreg <n> 0xf8)
    ap_type: str  # "MEM-AP", "JTAG-AP", "CTRL-AP", or "unknown"
