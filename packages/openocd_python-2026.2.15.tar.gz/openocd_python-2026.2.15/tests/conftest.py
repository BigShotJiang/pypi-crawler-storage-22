"""Shared pytest fixtures for openocd-python tests."""

from __future__ import annotations

import pytest

from openocd.connection.tcl_rpc import TclRpcConnection
from openocd.session import Session
from tests.mock_server import MockOpenOCDServer


@pytest.fixture
async def mock_ocd():
    """Start a MockOpenOCDServer, yield (host, port), stop on teardown."""
    server = MockOpenOCDServer()
    await server.start()
    host, port = server.address
    yield host, port, server
    await server.stop()


@pytest.fixture
async def connection(mock_ocd):
    """A TclRpcConnection connected to the mock server."""
    host, port, _server = mock_ocd
    conn = TclRpcConnection(timeout=5.0)
    await conn.connect(host, port)
    yield conn
    await conn.close()


@pytest.fixture
async def session(mock_ocd):
    """A Session connected to the mock server via Session.connect()."""
    host, port, _server = mock_ocd
    sess = await Session.connect(host, port, timeout=5.0)
    yield sess
    await sess.close()
