"""Tests for the JTAG subsystem."""

from __future__ import annotations

import pytest

from openocd.types import TAPInfo


async def test_scan_chain(session):
    """scan_chain() should return a list of TAPInfo objects."""
    taps = await session.jtag.scan_chain()
    assert isinstance(taps, list)
    assert len(taps) == 1


async def test_scan_chain_tap_fields(session):
    """The returned TAPInfo should have all fields populated correctly."""
    taps = await session.jtag.scan_chain()
    tap = taps[0]
    assert isinstance(tap, TAPInfo)
    assert tap.name == "stm32f1x.cpu"
    assert tap.chip == "stm32f1x"
    assert tap.tap_name == "cpu"
    assert tap.idcode == 0x3BA00477
    assert tap.ir_length == 4
    assert tap.enabled is True


async def test_scan_chain_frozen(session):
    """TAPInfo should be immutable (frozen dataclass)."""
    taps = await session.jtag.scan_chain()
    tap = taps[0]
    with pytest.raises(AttributeError):
        tap.name = "something_else"  # type: ignore[misc]


async def test_irscan(session):
    """irscan should return the shifted-out value as an int."""
    result = await session.jtag.irscan("stm32f1x.cpu", 0x0E)
    assert isinstance(result, int)
    assert result == 0x01


async def test_drscan(session):
    """drscan should return the shifted-out value as an int."""
    result = await session.jtag.drscan("stm32f1x.cpu", 32, 0x00000000)
    assert isinstance(result, int)
    assert result == 0xDEADBEEF


async def test_runtest(session):
    """runtest should complete without error."""
    await session.jtag.runtest(100)


async def test_scan_chain_parsing_multiple_taps(mock_ocd):
    """Verify the parser handles multiple TAPs in scan_chain output."""
    from openocd.jtag.chain import _parse_scan_chain

    raw = """\
   TapName             Enabled  IdCode     Expected   IrLen IrCap IrMask
-- ------------------- -------- ---------- ---------- ----- ----- ------
 0 stm32f1x.cpu        Y        0x3ba00477 0x3ba00477     4 0x01  0x0f
 1 stm32f1x.bs         N        0x06433041 0x06433041     5 0x01  0x1f"""

    taps = _parse_scan_chain(raw)
    assert len(taps) == 2

    assert taps[0].name == "stm32f1x.cpu"
    assert taps[0].enabled is True
    assert taps[0].idcode == 0x3BA00477
    assert taps[0].ir_length == 4

    assert taps[1].name == "stm32f1x.bs"
    assert taps[1].chip == "stm32f1x"
    assert taps[1].tap_name == "bs"
    assert taps[1].enabled is False
    assert taps[1].idcode == 0x06433041
    assert taps[1].ir_length == 5


def test_parse_scan_chain_empty():
    """An empty scan_chain output should return an empty list."""
    from openocd.jtag.chain import _parse_scan_chain

    result = _parse_scan_chain("")
    assert result == []

    result = _parse_scan_chain(
        "   TapName             Enabled  IdCode     Expected   IrLen IrCap IrMask\n"
        "-- ------------------- -------- ---------- ---------- ----- ----- ------\n"
    )
    assert result == []
