"""Tests for the Memory subsystem."""

from __future__ import annotations


async def test_read_u32(session):
    """read_u32 should return a list[int] with correctly parsed hex values."""
    values = await session.memory.read_u32(0x8000000, 4)
    assert isinstance(values, list)
    assert len(values) == 4
    assert values[0] == 0x20005000
    assert values[1] == 0x080001A1
    assert values[2] == 0x080001AB
    assert values[3] == 0x080001AD


async def test_read_u32_single(session):
    """read_u32 with count=1 should return a single-element list."""
    values = await session.memory.read_u32(0x20000000, 1)
    assert isinstance(values, list)
    assert len(values) == 1


async def test_read_u8(session):
    """read_u8 should return a list of 8-bit values."""
    values = await session.memory.read_u8(0x20000000, 4)
    assert isinstance(values, list)
    assert len(values) == 4
    # Generic mock returns zeros for unregistered addresses
    assert all(isinstance(v, int) for v in values)


async def test_read_u16(session):
    """read_u16 should return a list of 16-bit values."""
    values = await session.memory.read_u16(0x20000000, 2)
    assert isinstance(values, list)
    assert len(values) == 2


async def test_read_bytes(session):
    """read_bytes should return a bytes object of the requested size."""
    data = await session.memory.read_bytes(0x20000000, 8)
    assert isinstance(data, bytes)
    assert len(data) == 8


async def test_write_u32(session):
    """write_u32 should complete without error."""
    await session.memory.write_u32(0x20000000, [0xDEADBEEF, 0xCAFEBABE])


async def test_write_u32_single_value(session):
    """write_u32 with a single int should complete without error."""
    await session.memory.write_u32(0x20000000, 0x12345678)


async def test_write_bytes(session):
    """write_bytes should complete without error."""
    await session.memory.write_bytes(0x20000000, b"\x00\x01\x02\x03")


async def test_hexdump_format(session):
    """hexdump should return a properly formatted hex+ASCII dump."""
    dump = await session.memory.hexdump(0x20000000, 32)
    assert isinstance(dump, str)
    lines = dump.strip().splitlines()
    assert len(lines) == 2  # 32 bytes / 16 bytes per line = 2 lines

    # Each line should start with an address
    assert lines[0].startswith("20000000:")
    assert lines[1].startswith("20000010:")

    # Each line should contain the ASCII column delimited by pipes
    for line in lines:
        assert "|" in line


async def test_hexdump_ascii_column(session):
    """Hexdump ASCII column should use dots for non-printable bytes."""
    dump = await session.memory.hexdump(0x20000000, 16)
    # The mock returns all zeros, which are non-printable
    assert "|" in dump
    # Extract the ASCII portion between the pipes
    ascii_part = dump.split("|")[1]
    # All-zero bytes map to dots
    assert all(c == "." for c in ascii_part)


async def test_read_u32_returns_ints(session):
    """All values from read_u32 should be Python ints."""
    values = await session.memory.read_u32(0x8000000, 4)
    for v in values:
        assert isinstance(v, int)
        assert v >= 0
