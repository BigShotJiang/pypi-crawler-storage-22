"""Tests for the Registers subsystem."""

from __future__ import annotations

from openocd.types import Register


async def test_read_pc(session):
    """read('pc') should return the correct value from the mock."""
    val = await session.registers.read("pc")
    assert val == 0x08001234


async def test_read_sp(session):
    """read('sp') should return the correct value."""
    val = await session.registers.read("sp")
    assert val == 0x20005000


async def test_read_lr(session):
    """read('lr') should return the correct value."""
    val = await session.registers.read("lr")
    assert val == 0x08000100


async def test_read_xpsr(session):
    """read('xPSR') should return the correct value."""
    val = await session.registers.read("xPSR")
    assert val == 0x61000000


async def test_read_all(session):
    """read_all() should return a dict of Register objects keyed by name."""
    regs = await session.registers.read_all()
    assert isinstance(regs, dict)
    assert len(regs) > 0

    # Spot-check a few registers
    assert "pc" in regs
    assert "sp" in regs
    assert "r0" in regs
    assert "xPSR" in regs


async def test_read_all_register_type(session):
    """Each value in read_all() should be a Register dataclass."""
    regs = await session.registers.read_all()
    for name, reg in regs.items():
        assert isinstance(reg, Register)
        assert reg.name == name
        assert isinstance(reg.number, int)
        assert isinstance(reg.value, int)
        assert isinstance(reg.size, int)
        assert isinstance(reg.dirty, bool)


async def test_read_all_pc_value(session):
    """The pc register from read_all() should have the correct value."""
    regs = await session.registers.read_all()
    pc = regs["pc"]
    assert pc.value == 0x08001234
    assert pc.size == 32
    assert pc.number == 15


async def test_read_all_dirty_flag(session):
    """The control register should have dirty=True in our mock data."""
    regs = await session.registers.read_all()
    control = regs["control"]
    assert control.dirty is True


async def test_convenience_pc(session):
    """The pc() convenience method should match read('pc')."""
    val = await session.registers.pc()
    assert val == 0x08001234


async def test_convenience_sp(session):
    """The sp() convenience method should match read('sp')."""
    val = await session.registers.sp()
    assert val == 0x20005000


async def test_convenience_lr(session):
    """The lr() convenience method should match read('lr')."""
    val = await session.registers.lr()
    assert val == 0x08000100


async def test_convenience_xpsr(session):
    """The xpsr() convenience method should match read('xPSR')."""
    val = await session.registers.xpsr()
    assert val == 0x61000000


async def test_write(session):
    """write() should complete without error."""
    await session.registers.write("r0", 0xDEADBEEF)


async def test_read_many(session):
    """read_many() should return values for all requested registers."""
    results = await session.registers.read_many(["pc", "sp", "lr"])
    assert len(results) == 3
    assert results["pc"] == 0x08001234
    assert results["sp"] == 0x20005000
    assert results["lr"] == 0x08000100
