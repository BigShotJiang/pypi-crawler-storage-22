"""Tests for the Target subsystem."""

from __future__ import annotations

import pytest

from openocd.types import TargetState


async def test_state_returns_target_state(session):
    """target.state() should return a TargetState with correct fields."""
    state = await session.target.state()
    assert isinstance(state, TargetState)
    assert state.name == "stm32f1x.cpu"
    assert state.state == "halted"
    # When halted, the mock returns pc = 0x08001234
    assert state.current_pc == 0x08001234


async def test_halt(session):
    """target.halt() should return a TargetState."""
    state = await session.target.halt()
    assert isinstance(state, TargetState)
    assert state.state == "halted"


async def test_resume(session):
    """target.resume() should complete without error."""
    await session.target.resume()


async def test_resume_with_address(session):
    """target.resume(address=...) should complete without error."""
    await session.target.resume(address=0x08000000)


async def test_step(session):
    """target.step() should return a TargetState."""
    state = await session.target.step()
    assert isinstance(state, TargetState)


async def test_step_with_address(session):
    """target.step(address=...) should complete without error."""
    state = await session.target.step(address=0x08001234)
    assert isinstance(state, TargetState)


async def test_reset_halt(session):
    """target.reset('halt') should complete without error."""
    await session.target.reset("halt")


async def test_reset_run(session):
    """target.reset('run') should complete without error."""
    await session.target.reset("run")


async def test_reset_init(session):
    """target.reset('init') should complete without error."""
    await session.target.reset("init")


async def test_state_pc_field(session):
    """When halted, current_pc should be populated from reg pc."""
    state = await session.target.state()
    assert state.current_pc is not None
    assert state.current_pc == 0x08001234


async def test_state_frozen_dataclass(session):
    """TargetState should be immutable (frozen dataclass)."""
    state = await session.target.state()
    with pytest.raises(AttributeError):
        state.name = "something_else"  # type: ignore[misc]
