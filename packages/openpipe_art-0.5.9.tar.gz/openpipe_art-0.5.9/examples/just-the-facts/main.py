def main():
    print("Hello from just-the-facts!")


if __name__ == "__main__":
    main()
