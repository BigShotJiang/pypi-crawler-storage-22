"""Integration tests for ART multi-checkpoint inference."""
