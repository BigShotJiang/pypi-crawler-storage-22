"""OpenProficiency - Library to manage proficiency scores using topics and topic lists."""

from .Topic import Topic
from .TopicList import TopicList