# OpenProficiency Python SDK

A lightweight Python library for managing proficiency topics and topic lists. This library provides simple class objects for working with proficiency domains, making it easy to build applications that track and manage knowledge areas.

## Features

- **Topic Class**: Represents a defined unique area of knowledge with support for subtopics and prerequisites
- **TopicList Class**: Manages collections of topics organized by an issuer
- **Serialization**: JSON serialization and deserialization for both `Topic` and `TopicList`
- **Flexible Design**: Support for nested topics, external dependencies, and custom metadata

## Installation

### From Source (Development)

```bash
git clone https://github.com/openproficiency/openproficiency.git
cd openproficiency/python-sdk
pip install -e .
```

### With Development Dependencies

```bash
pip install -e ".[dev]"
```

## Quick Start

### Creating Topics

```python
from openproficiency import Topic

# Create a simple topic
topic = Topic(
    id="git-basics",
    description="Git version control fundamentals"
)

# Create a topic with subtopics
advanced_git = Topic(
    id="git-advanced",
    description="Advanced Git techniques",
    subtopics=["branching", "merging", "rebasing"],
    pretopics=["git-basics"]
)
```

### Creating Topic Lists

```python
from openproficiency import Topic, TopicList

# Create a topic list
topic_list = TopicList(
    issuer="github",
    name="github/git-fundamentals",
    description="A comprehensive guide to Git fundamentals",
    version="1.0.0"
)

# Add topics to the list
git_basics = Topic(id="git-basics", description="Git basics")
topic_list.add_topic(git_basics)

# Retrieve a topic
retrieved = topic_list.get_topic("git-basics")
```

### Serialization

```python
from openproficiency import Topic, TopicList

# Create a topic
topic = Topic(id="git", description="Git version control")
topic_list = TopicList(
    issuer="github",
    name="github/git",
    topics={"git": topic}
)

# Serialize to JSON
json_string = topic_list.to_json()
print(json_string)

# Deserialize from JSON
restored = TopicList.from_json(json_string)
```

## API Documentation

### Topic

#### Methods

- `to_dict() -> Dict[str, Any]`: Convert to dictionary representation
- `to_json() -> str`: Convert to JSON string
- `from_dict(data: Dict[str, Any]) -> Topic`: Create from dictionary
- `from_json(json_string: str) -> Topic`: Create from JSON string

#### Attributes

- `id` (str): Unique identifier (pattern: `^[a-z0-9-]+$`)
- `description` (str): Brief description of the knowledge area
- `subtopics` (List[Union[str, Topic]]): Subtopics or references to subtopic IDs
- `pretopics` (List[str]): Prerequisite topic identifiers

### TopicList

#### Methods

- `add_topic(topic: Topic) -> None`: Add a topic to the list
- `get_topic(topic_id: str) -> Optional[Topic]`: Retrieve a topic by ID
- `to_dict() -> Dict[str, Any]`: Convert to dictionary representation
- `to_json() -> str`: Convert to JSON string
- `from_dict(data: Dict[str, Any]) -> TopicList`: Create from dictionary
- `from_json(json_string: str) -> TopicList`: Create from JSON string

#### Attributes

- `issuer` (str): Entity that declares and maintains this topic list
- `name` (str): Name to define scope (format: `namespace/subject-area`)
- `description` (str): Brief description of the knowledge domain
- `version` (str): Version of the topic list
- `topics` (Dict[str, Topic]): Map of topic IDs to Topic objects
- `timestamp` (str): ISO 8601 timestamp of creation
- `dependencies` (Dict[str, Union[str, TopicList]]): External topic list references

## Testing

Run the test suite:

```bash
pytest
```

With coverage report:

```bash
pytest --cov=openproficiency --cov-report=html
```


## How to Develop

This project is very open to pull requests.

Please see the [contribution guide](CONTRIBUTE.md) to get started.