"""OpenProficiency Library - A library for managing proficiency topics and topic lists."""

from .Topic import Topic
from .TopicList import TopicList

__version__ = "0.1.0"
__author__ = "OpenProficiency Contributors"
__all__ = ["Topic", "TopicList"]
