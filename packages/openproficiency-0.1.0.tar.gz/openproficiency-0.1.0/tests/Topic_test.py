import json
import pytest
from openproficiency import Topic

class TestTopic:

    # Initializers
    def test_init_required_params(self):
        """Create a topic with requied fields only"""

        # Arrange
        id = "git-commit"

        # Act
        topic = Topic(id=id)
        
        # Assert
        assert topic.id == id

        # Assert - default values
        assert topic.description == ""
        assert topic.subtopics == []
        assert topic.pretopics == []

    def test_init_optional_params(self):
        """Test creating a topic with subtopics."""

        # Arrange
        id = "git-commit"
        description = "Saving changes to the Git history"
        
        # Act
        topic = Topic(
            id=id,
            description=description
        )

        # Assert
        assert topic.description == description

    # Methods
    def test_add_subtopic_string(self):
        """Test adding a subtopic as a string."""

        # Arrange
        topic = Topic(id="git")
        subtopic_id = "git-commit"

        # Act
        topic.add_subtopic(subtopic_id)

        # Assert
        assert subtopic_id in topic.subtopics

    def test_add_subtopic_topic(self):
        """Test adding a subtopic as a Topic instance."""

        # Arrange
        topic = Topic(id="git")
        subtopic = Topic(
            id="git-commit",
            description="Saving changes to the Git history"
        )

        # Act
        topic.add_subtopic(subtopic)

        # Assert
        assert subtopic.id in topic.subtopics

    def test_add_pretopic_string(self):
        """Test adding a pretopic as a string."""

        # Arrange
        topic = Topic(id="git")
        pretopic_id = "version-control"

        # Act
        topic.add_pretopic(pretopic_id)

        # Assert
        assert pretopic_id in topic.pretopics

    def test_add_pretopic_topic(self):
        """Test adding a pretopic as a Topic instance."""

        # Arrange
        topic = Topic(id="git")
        pretopic = Topic(
            id="version-control",
            description="Managing changes to code over time"
        )

        # Act
        topic.add_pretopic(pretopic)

        # Assert
        assert pretopic.id in topic.pretopics

    # Debugging
    def test_topic_repr(self):
        """Test __repr__ method."""

        topic = Topic(id="git", description="Git version control")
        repr_str = repr(topic)
        
        assert "git" in repr_str
        assert "Git version control" in repr_str
        assert "Topic" in repr_str
