"""Entry point for python -m rewrite.rpc.server"""
from .server import main

if __name__ == '__main__':
    main()
