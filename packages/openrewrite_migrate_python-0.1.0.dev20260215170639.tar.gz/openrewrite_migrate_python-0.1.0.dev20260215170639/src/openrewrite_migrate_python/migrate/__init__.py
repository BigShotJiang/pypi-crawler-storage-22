"""Python version and library migration recipes."""

# LangChain migration recipes
from .langchain_classic_imports import (
    FindDeprecatedLangchainAgents,
    ReplaceLangchainClassicImports,
    FindLangchainCreateReactAgent,
)
from .langchain_community_imports import ReplaceLangchainCommunityImports
from .langchain_provider_imports import ReplaceLangchainProviderImports
from .upgrade_to_langchain02 import UpgradeToLangChain02
from .upgrade_to_langchain1 import UpgradeToLangChain1

# PEP 594 dead batteries - additional modules
from .aifc_migrations import (
    FindAifcModule,
    FindAudioopModule,
    FindChunkModule,
    FindImghdrModule,
    FindSndhdrModule,
    FindSunauModule,
)
from .array_deprecations import ReplaceArrayFromstring, ReplaceArrayTostring
from .ast_deprecations import (
    ReplaceAstBytes,
    ReplaceAstEllipsis,
    ReplaceAstNameConstant,
    ReplaceAstNum,
    ReplaceAstStr,
)
from .asyncio_coroutine_to_async import MigrateAsyncioCoroutine
from .asyncio_deprecations import FindAsyncioCoroutineDecorator
from .base64_deprecations import ReplaceBase64Decodestring, ReplaceBase64Encodestring
from .calendar_deprecations import ReplaceCalendarConstants
from .cgi_migrations import FindCgiModule, FindCgitbModule, ReplaceCgiEscape
from .cgi_parse_deprecations import FindCgiParseQs, FindCgiParseQsl
from .collections_abc_migrations import ReplaceCollectionsAbcImports
from .configparser_deprecations import (
    ReplaceConfigparserReadfp,
    ReplaceConfigparserSafeConfigParser,
)
from .datetime_utc import ReplaceDatetimeUtcFromTimestamp, ReplaceDatetimeUtcNow
from .distutils_deprecations import FindDistutilsUsage
from .distutils_migrations import ReplaceDistutilsVersion
from .fractions_deprecations import ReplaceFractionsGcd
from .functools_deprecations import FindFunctoolsCmpToKey
from .gettext_deprecations import ReplaceGettextDeprecations
from .html_parser_deprecations import FindHtmlParserUnescape
from .imp_migrations import FindImpUsage, ReplaceImpImport, ReplaceImpReload
from .inspect_deprecations import ReplaceInspectGetargspec
from .locale_deprecations import ReplaceLocaleResetlocale
from .locale_getdefaultlocale_deprecation import FindLocaleGetdefaultlocale
from .logging_deprecations import ReplaceLoggingWarn
from .macpath_deprecations import FindMacpathModule
from .mailcap_migrations import FindMailcapModule
from .nntplib_migrations import FindNntplibModule
from .os_deprecations import FindOsPopen, FindOsSpawn
from .pathlib_deprecations import FindPathlibLinkTo
from .platform_deprecations import FindPlatformPopen
from .pep594_system_migrations import (
    FindCryptModule,
    FindMsilibModule,
    FindNisModule,
    FindOssaudiodevModule,
    FindSpwdModule,
)
from .pipes_migrations import FindPipesModule
from .pkgutil_deprecations import ReplacePkgutilFindLoader, ReplacePkgutilGetLoader
from .re_deprecations import FindReTemplate
from .removed_modules_312 import FindRemovedModules312
from .shutil_deprecations import FindShutilRmtreeOnerror
from .socket_deprecations import FindSocketGetFQDN
from .ssl_deprecations import FindSslMatchHostname
from .string_formatting import ReplacePercentFormatWithFString, ReplaceStrFormatWithFString
from .sys_check_interval_deprecations import ReplaceSysGetCheckInterval, ReplaceSysSetCheckInterval
from .sys_deprecations import FindSysCoroutineWrapper
from .sys_last_deprecations import FindSysLastExcInfo
from .tarfile_deprecations import FindTarfileFilemode
from .telnetlib_migrations import FindTelnetlibModule
from .tempfile_deprecations import FindTempfileMktemp
from .threading_is_alive_deprecation import ReplaceThreadIsAlive
from .time_deprecations import ReplaceTimeClock
from .threading_deprecations import (
    ReplaceConditionNotifyAll,
    ReplaceEventIsSet,
    ReplaceThreadGetName,
    ReplaceThreadIsDaemon,
    ReplaceThreadSetDaemon,
    ReplaceThreadSetName,
    ReplaceThreadingActiveCount,
    ReplaceThreadingCurrentThread,
)
from .typing_builtins import (
    ReplaceTypingDictWithBuiltin,
    ReplaceTypingFrozenSetWithBuiltin,
    ReplaceTypingListWithBuiltin,
    ReplaceTypingSetWithBuiltin,
    ReplaceTypingTupleWithBuiltin,
    ReplaceTypingTypeWithBuiltin,
)
from .typing_callable import ReplaceTypingCallableWithCollectionsAbcCallable
from .typing_pep585_extended import (
    ReplaceTypingAbstractSetWithCollectionsAbcSet,
    ReplaceTypingAsyncContextManagerWithContextlib,
    ReplaceTypingAsyncGeneratorWithCollectionsAbcAsyncGenerator,
    ReplaceTypingAsyncIterableWithCollectionsAbcAsyncIterable,
    ReplaceTypingAsyncIteratorWithCollectionsAbcAsyncIterator,
    ReplaceTypingAwaitableWithCollectionsAbcAwaitable,
    ReplaceTypingChainMapWithCollectionsChainMap,
    ReplaceTypingCollectionWithCollectionsAbcCollection,
    ReplaceTypingContainerWithCollectionsAbcContainer,
    ReplaceTypingContextManagerWithContextlib,
    ReplaceTypingCoroutineWithCollectionsAbcCoroutine,
    ReplaceTypingCounterWithCollectionsCounter,
    ReplaceTypingDefaultDictWithCollectionsDefaultdict,
    ReplaceTypingDequeWithCollectionsDeque,
    ReplaceTypingGeneratorWithCollectionsAbcGenerator,
    ReplaceTypingItemsViewWithCollectionsAbcItemsView,
    ReplaceTypingIterableWithCollectionsAbcIterable,
    ReplaceTypingIteratorWithCollectionsAbcIterator,
    ReplaceTypingKeysViewWithCollectionsAbcKeysView,
    ReplaceTypingMappingViewWithCollectionsAbcMappingView,
    ReplaceTypingMappingWithCollectionsAbcMapping,
    ReplaceTypingMatchWithReMatch,
    ReplaceTypingMutableMappingWithCollectionsAbcMutableMapping,
    ReplaceTypingMutableSequenceWithCollectionsAbcMutableSequence,
    ReplaceTypingMutableSetWithCollectionsAbcMutableSet,
    ReplaceTypingOrderedDictWithCollectionsOrderedDict,
    ReplaceTypingPatternWithRePattern,
    ReplaceTypingReversibleWithCollectionsAbcReversible,
    ReplaceTypingSequenceWithCollectionsAbcSequence,
    ReplaceTypingValuesViewWithCollectionsAbcValuesView,
)
from .typing_union_to_pipe import (
    ReplaceTypingOptionalWithUnion,
    ReplaceTypingUnionWithPipe,
)
from .unittest_deprecations import ReplaceUnittestDeprecatedAliases
from .upgrade_to_python38 import UpgradeToPython38
from .upgrade_to_python39 import UpgradeToPython39
from .upgrade_to_python310 import UpgradeToPython310
from .upgrade_to_python311 import UpgradeToPython311
from .upgrade_to_python312 import UpgradeToPython312
from .upgrade_to_python313 import UpgradeToPython313
from .upgrade_to_python314 import UpgradeToPython314
from .urllib_deprecations import FindUrllibParseSplitFunctions, FindUrllibParseToBytes
from .uu_migrations import FindUuModule
from .xdrlib_migrations import FindXdrlibModule
from .xml_deprecations import FindElementGetchildren, ReplaceElementGetiterator

__all__ = [
    # String formatting auto-fix recipes
    "ReplacePercentFormatWithFString",
    "ReplaceStrFormatWithFString",
    "FindAifcModule",
    "FindAsyncioCoroutineDecorator",
    "FindAudioopModule",
    "FindCgiModule",
    "FindCgiParseQs",
    "FindCgiParseQsl",
    "FindCgitbModule",
    "FindChunkModule",
    "FindCryptModule",
    "FindDistutilsUsage",
    "FindElementGetchildren",
    "FindFunctoolsCmpToKey",
    "FindHtmlParserUnescape",
    "FindImghdrModule",
    "FindImpUsage",
    "FindMacpathModule",
    "FindMailcapModule",
    "FindMsilibModule",
    "FindNisModule",
    "FindNntplibModule",
    "FindLocaleGetdefaultlocale",
    "FindOsPopen",
    "FindOsSpawn",
    "FindOssaudiodevModule",
    "FindPathlibLinkTo",
    "FindPipesModule",
    "FindPlatformPopen",
    "FindReTemplate",
    "FindRemovedModules312",
    "FindShutilRmtreeOnerror",
    "FindSndhdrModule",
    "FindSocketGetFQDN",
    "FindSpwdModule",
    "FindSslMatchHostname",
    "FindSysLastExcInfo",
    "FindSunauModule",
    "FindSysCoroutineWrapper",
    "FindTarfileFilemode",
    "FindTelnetlibModule",
    "FindTempfileMktemp",
    "ReplaceThreadGetName",
    "ReplaceThreadIsDaemon",
    "ReplaceThreadSetDaemon",
    "ReplaceThreadSetName",
    "FindUrllibParseSplitFunctions",
    "FindUrllibParseToBytes",
    "FindUuModule",
    "FindXdrlibModule",
    # Auto-fix: Time
    "ReplaceTimeClock",
    # Auto-fix: Array
    "ReplaceArrayFromstring",
    "ReplaceArrayTostring",
    # Auto-fix: AST
    "ReplaceAstBytes",
    "ReplaceAstEllipsis",
    "ReplaceAstNameConstant",
    "ReplaceAstNum",
    "ReplaceAstStr",
    # Auto-fix: Asyncio
    "MigrateAsyncioCoroutine",
    # Auto-fix: Base64
    "ReplaceBase64Decodestring",
    "ReplaceBase64Encodestring",
    # Auto-fix: Calendar
    "ReplaceCalendarConstants",
    # Auto-fix: CGI
    "ReplaceCgiEscape",
    # Auto-fix: Collections
    "ReplaceCollectionsAbcImports",
    # Auto-fix: Configparser
    "ReplaceConfigparserReadfp",
    "ReplaceConfigparserSafeConfigParser",
    # Auto-fix: Datetime
    "ReplaceDatetimeUtcFromTimestamp",
    "ReplaceDatetimeUtcNow",
    # Auto-fix: Distutils
    "ReplaceDistutilsVersion",
    # Auto-fix: Gettext
    "ReplaceGettextDeprecations",
    # Auto-fix: Imp -> Importlib
    "ReplaceImpImport",
    "ReplaceImpReload",
    # Auto-fix: Inspect
    "ReplaceInspectGetargspec",
    # Auto-fix: Locale
    "ReplaceLocaleResetlocale",
    # Auto-fix: Fractions
    "ReplaceFractionsGcd",
    # Auto-fix: Logging
    "ReplaceLoggingWarn",
    # Auto-fix: Sys check interval
    "ReplaceSysGetCheckInterval",
    "ReplaceSysSetCheckInterval",
    # Auto-fix: Pkgutil
    "ReplacePkgutilFindLoader",
    "ReplacePkgutilGetLoader",
    # Auto-fix: Threading
    "ReplaceThreadIsAlive",
    "ReplaceConditionNotifyAll",
    "ReplaceEventIsSet",
    "ReplaceThreadingActiveCount",
    "ReplaceThreadingCurrentThread",
    # Auto-fix: Typing -> Builtins (PEP 585)
    "ReplaceTypingDictWithBuiltin",
    "ReplaceTypingFrozenSetWithBuiltin",
    "ReplaceTypingListWithBuiltin",
    "ReplaceTypingSetWithBuiltin",
    "ReplaceTypingTupleWithBuiltin",
    "ReplaceTypingTypeWithBuiltin",
    # Auto-fix: Typing -> collections (PEP 585)
    "ReplaceTypingDequeWithCollectionsDeque",
    "ReplaceTypingDefaultDictWithCollectionsDefaultdict",
    "ReplaceTypingOrderedDictWithCollectionsOrderedDict",
    "ReplaceTypingCounterWithCollectionsCounter",
    "ReplaceTypingChainMapWithCollectionsChainMap",
    # Auto-fix: Typing -> re (PEP 585)
    "ReplaceTypingPatternWithRePattern",
    "ReplaceTypingMatchWithReMatch",
    # Auto-fix: Typing -> contextlib (PEP 585)
    "ReplaceTypingContextManagerWithContextlib",
    "ReplaceTypingAsyncContextManagerWithContextlib",
    # Auto-fix: Typing -> collections.abc (PEP 585)
    "ReplaceTypingIterableWithCollectionsAbcIterable",
    "ReplaceTypingIteratorWithCollectionsAbcIterator",
    "ReplaceTypingGeneratorWithCollectionsAbcGenerator",
    "ReplaceTypingSequenceWithCollectionsAbcSequence",
    "ReplaceTypingMutableSequenceWithCollectionsAbcMutableSequence",
    "ReplaceTypingMappingWithCollectionsAbcMapping",
    "ReplaceTypingMutableMappingWithCollectionsAbcMutableMapping",
    "ReplaceTypingAbstractSetWithCollectionsAbcSet",
    "ReplaceTypingMutableSetWithCollectionsAbcMutableSet",
    "ReplaceTypingAwaitableWithCollectionsAbcAwaitable",
    "ReplaceTypingCoroutineWithCollectionsAbcCoroutine",
    "ReplaceTypingAsyncIterableWithCollectionsAbcAsyncIterable",
    "ReplaceTypingAsyncIteratorWithCollectionsAbcAsyncIterator",
    "ReplaceTypingAsyncGeneratorWithCollectionsAbcAsyncGenerator",
    "ReplaceTypingReversibleWithCollectionsAbcReversible",
    "ReplaceTypingContainerWithCollectionsAbcContainer",
    "ReplaceTypingCollectionWithCollectionsAbcCollection",
    "ReplaceTypingMappingViewWithCollectionsAbcMappingView",
    "ReplaceTypingKeysViewWithCollectionsAbcKeysView",
    "ReplaceTypingItemsViewWithCollectionsAbcItemsView",
    "ReplaceTypingValuesViewWithCollectionsAbcValuesView",
    # Auto-fix: Typing
    "ReplaceTypingCallableWithCollectionsAbcCallable",
    "ReplaceTypingOptionalWithUnion",
    "ReplaceTypingUnionWithPipe",
    # Auto-fix: Unittest
    "ReplaceUnittestDeprecatedAliases",
    # Auto-fix: XML
    "ReplaceElementGetiterator",
    # Auto-fix: LangChain
    "ReplaceLangchainCommunityImports",
    "ReplaceLangchainProviderImports",
    "ReplaceLangchainClassicImports",
    "FindLangchainCreateReactAgent",
    # Detection: LangChain
    "FindDeprecatedLangchainAgents",
    # Composite upgrade recipes: LangChain
    "UpgradeToLangChain02",
    "UpgradeToLangChain1",
    # Composite upgrade recipes: Python
    "UpgradeToPython38",
    "UpgradeToPython39",
    "UpgradeToPython310",
    "UpgradeToPython311",
    "UpgradeToPython312",
    "UpgradeToPython313",
    "UpgradeToPython314",
]
