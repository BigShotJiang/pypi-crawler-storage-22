"""
Recipes for migrating deprecated base64 module methods.

The following methods were deprecated in Python 3.1 and removed in Python 3.9:
- base64.encodestring() -> base64.encodebytes()
- base64.decodestring() -> base64.decodebytes()

See: https://docs.python.org/3/library/base64.html
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.9
_Python39 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.9"),
]


@categorize(_Python39)
class ReplaceBase64Encodestring(Recipe):
    """
    Replace `base64.encodestring()` with `base64.encodebytes()`.

    The `encodestring()` method was deprecated in Python 3.1 and removed
    in Python 3.9. Use `encodebytes()` instead.

    Example:
        Before:
            import base64
            encoded = base64.encodestring(data)

        After:
            import base64
            encoded = base64.encodebytes(data)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceBase64Encodestring"

    @property
    def display_name(self) -> str:
        return "Replace `base64.encodestring()` with `base64.encodebytes()`"

    @property
    def description(self) -> str:
        return (
            "Replace `base64.encodestring()` with `base64.encodebytes()`. "
            "The encodestring() method was deprecated in Python 3.1 and removed in 3.9."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.9", "base64"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "encodestring":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "base64":
                    return method

                # Replace encodestring with encodebytes
                new_name = method.name.replace(_simple_name="encodebytes")
                return method.replace(_name=new_name)

        return Visitor()


@categorize(_Python39)
class ReplaceBase64Decodestring(Recipe):
    """
    Replace `base64.decodestring()` with `base64.decodebytes()`.

    The `decodestring()` method was deprecated in Python 3.1 and removed
    in Python 3.9. Use `decodebytes()` instead.

    Example:
        Before:
            import base64
            decoded = base64.decodestring(data)

        After:
            import base64
            decoded = base64.decodebytes(data)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceBase64Decodestring"

    @property
    def display_name(self) -> str:
        return "Replace `base64.decodestring()` with `base64.decodebytes()`"

    @property
    def description(self) -> str:
        return (
            "Replace `base64.decodestring()` with `base64.decodebytes()`. "
            "The decodestring() method was deprecated in Python 3.1 and removed in 3.9."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.9", "base64"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "decodestring":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "base64":
                    return method

                # Replace decodestring with decodebytes
                new_name = method.name.replace(_simple_name="decodebytes")
                return method.replace(_name=new_name)

        return Visitor()
