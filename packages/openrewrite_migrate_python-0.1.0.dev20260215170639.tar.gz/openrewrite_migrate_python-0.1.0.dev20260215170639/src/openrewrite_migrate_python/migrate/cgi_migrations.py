"""
Recipes for migrating from deprecated cgi and cgitb modules.

The cgi and cgitb modules were deprecated in Python 3.11 (PEP 594) and
removed in Python 3.13.

Replacements:
- cgi.parse() -> urllib.parse.parse_qs()
- cgi.parse_qs() -> urllib.parse.parse_qs()
- cgi.parse_qsl() -> urllib.parse.parse_qsl()
- cgi.FieldStorage -> Use web frameworks or email.message
- cgitb -> Use standard logging and traceback modules

See: https://peps.python.org/pep-0594/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport, Import
from rewrite.java.tree import Identifier, FieldAccess, MethodInvocation

# Define category path: Python > Migrate > Python 3.13
_Python313 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.13"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


def _get_import_name(import_node: Any) -> Optional[str]:
    """Extract the module name from an import node's qualid."""
    qualid = import_node.qualid
    if isinstance(qualid, FieldAccess):
        return qualid.name.simple_name
    if isinstance(qualid, Identifier):
        return qualid.simple_name
    return None


@categorize(_Python313)
class FindCgiModule(Recipe):
    """
    Find imports of the deprecated `cgi` module.

    The `cgi` module was deprecated in Python 3.11 and removed in Python 3.13.

    Replacements:
    - `cgi.parse_qs()` -> `urllib.parse.parse_qs()`
    - `cgi.parse_qsl()` -> `urllib.parse.parse_qsl()`
    - `cgi.FieldStorage` -> Use web frameworks (Flask, Django) or `email.message`
    - `cgi.escape()` -> `html.escape()` (deprecated since 3.2)

    See: https://peps.python.org/pep-0594/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindCgiModule"

    @property
    def display_name(self) -> str:
        return "Find deprecated `cgi` module usage"

    @property
    def description(self) -> str:
        return (
            "The `cgi` module was deprecated in Python 3.11 and removed in Python 3.13. "
            "Use `urllib.parse` for query string parsing, `html.escape()` for escaping, "
            "and web frameworks or `email.message` for form handling."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.13", "PEP 594"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    # Handle 'from cgi import ...' pattern
                    if isinstance(from_part, Identifier) and from_part.simple_name == "cgi":
                        return _mark_deprecated(
                            multi,
                            "The `cgi` module was removed in Python 3.13. "
                            "Use urllib.parse for query parsing, html.escape() for escaping."
                        )
                else:
                    # Handle 'import cgi' pattern
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == "cgi":
                            return _mark_deprecated(
                                multi,
                                "The `cgi` module was removed in Python 3.13. "
                                "Use urllib.parse for query parsing, html.escape() for escaping."
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == "cgi":
                    return _mark_deprecated(
                        import_stmt,
                        "The `cgi` module was removed in Python 3.13. "
                        "Use urllib.parse for query parsing, html.escape() for escaping."
                    )
                return import_stmt

        return Visitor()


@categorize(_Python313)
class FindCgitbModule(Recipe):
    """
    Find imports of the deprecated `cgitb` module.

    The `cgitb` module was deprecated in Python 3.11 and removed in Python 3.13.

    Use the standard `logging` and `traceback` modules instead for error handling
    and debugging.

    See: https://peps.python.org/pep-0594/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindCgitbModule"

    @property
    def display_name(self) -> str:
        return "Find deprecated `cgitb` module usage"

    @property
    def description(self) -> str:
        return (
            "The `cgitb` module was deprecated in Python 3.11 and removed in Python 3.13. "
            "Use the standard `logging` and `traceback` modules for error handling."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.13", "PEP 594"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == "cgitb":
                        return _mark_deprecated(
                            multi,
                            "The `cgitb` module was removed in Python 3.13. "
                            "Use logging and traceback modules instead."
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == "cgitb":
                            return _mark_deprecated(
                                multi,
                                "The `cgitb` module was removed in Python 3.13. "
                                "Use logging and traceback modules instead."
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == "cgitb":
                    return _mark_deprecated(
                        import_stmt,
                        "The `cgitb` module was removed in Python 3.13. "
                        "Use logging and traceback modules instead."
                    )
                return import_stmt

        return Visitor()


# Define category for Python 3.2 deprecations (cgi.escape was deprecated then)
_Python32 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.2"),
]


@categorize(_Python32)
class ReplaceCgiEscape(Recipe):
    """
    Replace `cgi.escape()` with `html.escape()`.

    `cgi.escape()` was deprecated in Python 3.2 and removed in Python 3.8.
    `html.escape()` is the direct replacement with identical behavior.

    Example:
        Before:
            import cgi
            safe = cgi.escape(user_input)
            safe_quoted = cgi.escape(user_input, quote=True)

        After:
            import html
            safe = html.escape(user_input)
            safe_quoted = html.escape(user_input, quote=True)

    Note: This recipe replaces the method call. You may need to also update
    your imports from `import cgi` to `import html`.
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceCgiEscape"

    @property
    def display_name(self) -> str:
        return "Replace `cgi.escape()` with `html.escape()`"

    @property
    def description(self) -> str:
        return (
            "Replace `cgi.escape()` with `html.escape()`. "
            "cgi.escape() was deprecated in Python 3.2 and removed in Python 3.8."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.2", "3.8"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                # Check if this is cgi.escape()
                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "escape":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "cgi":
                    return method

                # Replace cgi with html
                new_select = select.replace(_simple_name="html")
                old_padded_select = method.padding.select
                new_padded_select = old_padded_select.replace(_element=new_select)
                return method.padding.replace(_select=new_padded_select)

        return Visitor()
