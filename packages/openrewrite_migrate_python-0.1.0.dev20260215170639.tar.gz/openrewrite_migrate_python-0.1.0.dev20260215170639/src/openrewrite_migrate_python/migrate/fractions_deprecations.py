"""
Recipes for migrating deprecated fractions module functions.

The following function was deprecated in Python 3.5 and removed in Python 3.9:
- fractions.gcd() -> math.gcd()

See: https://docs.python.org/3/whatsnew/3.9.html#removed
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.9
_Python39 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.9"),
]


@categorize(_Python39)
class ReplaceFractionsGcd(Recipe):
    """
    Replace `fractions.gcd()` with `math.gcd()`.

    `fractions.gcd()` was deprecated in Python 3.5 and removed in Python 3.9.
    Use `math.gcd()` instead.

    Example:
        Before:
            import fractions
            result = fractions.gcd(12, 8)

        After:
            import math
            result = math.gcd(12, 8)

    Note: This recipe replaces the method call only. You may also need
    to update your imports.
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceFractionsGcd"

    @property
    def display_name(self) -> str:
        return "Replace `fractions.gcd()` with `math.gcd()`"

    @property
    def description(self) -> str:
        return (
            "Replace `fractions.gcd()` with `math.gcd()`. "
            "fractions.gcd() was deprecated in Python 3.5 and removed in 3.9."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.9", "fractions"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "gcd":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "fractions":
                    return method

                # Replace fractions with math
                new_select = select.replace(_simple_name="math")
                old_padded_select = method.padding.select
                new_padded_select = old_padded_select.replace(_element=new_select)
                return method.padding.replace(_select=new_padded_select)

        return Visitor()
