"""
Recipe for migrating deprecated HTMLParser.unescape() method.

HTMLParser.unescape() was deprecated in Python 3.4 and removed in Python 3.9.
Use html.unescape() instead.

See: https://docs.python.org/3/whatsnew/3.9.html#removed
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.9
_Python39 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.9"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_Python39)
class FindHtmlParserUnescape(Recipe):
    """
    Find usages of removed `HTMLParser.unescape()`.

    `HTMLParser.unescape()` was deprecated in Python 3.4 and removed in Python 3.9.
    Use `html.unescape()` instead.

    Example:
        Before:
            from html.parser import HTMLParser
            parser = HTMLParser()
            text = parser.unescape(html_text)

        After:
            import html
            text = html.unescape(html_text)

    Note: This is a search recipe because the transformation requires
    changing from an instance method to a module function.
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindHtmlParserUnescape"

    @property
    def display_name(self) -> str:
        return "Find removed `HTMLParser.unescape()` usage"

    @property
    def description(self) -> str:
        return (
            "`HTMLParser.unescape()` was removed in Python 3.9. "
            "Use `html.unescape()` instead."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.9", "html"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "unescape":
                    return method

                # We can't easily distinguish HTMLParser.unescape from other
                # .unescape() calls without type information, so we mark all
                # .unescape() calls on non-module selects as potential matches
                # when the select is not a known module name like "html"
                select = method.select
                if isinstance(select, Identifier) and select.simple_name == "html":
                    # Already using html.unescape(), no change needed
                    return method

                # Skip if no select (bare function call)
                if method.select is None:
                    return method

                return _mark_deprecated(
                    method,
                    "HTMLParser.unescape() was removed in Python 3.9. "
                    "Use html.unescape() instead."
                )

        return Visitor()
