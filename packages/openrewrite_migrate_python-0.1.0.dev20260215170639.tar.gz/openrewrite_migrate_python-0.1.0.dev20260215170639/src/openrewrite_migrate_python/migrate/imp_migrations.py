"""
Recipes for migrating deprecated imp module usage.

The imp module was deprecated in Python 3.4 and removed in Python 3.12.
Users should migrate to importlib.

Common migrations:
- imp.reload() -> importlib.reload()
- imp.find_module() -> importlib.util.find_spec()
- imp.load_module() -> importlib.util.module_from_spec() + loader.exec_module()
- imp.NullImporter -> use importlib.abc.MetaPathFinder
- imp.acquire_lock() / imp.release_lock() -> importlib._bootstrap._lock_unlock_module()

See: https://docs.python.org/3/library/imp.html
See: https://peps.python.org/pep-3121/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport, Import
from rewrite.java.tree import FieldAccess, Identifier, MethodInvocation
from rewrite.utils import random_id

# Define category path: Python > Migrate > Python 3.12
_Python312 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.12"),
]


def _mark_deprecated(tree: Any, message: str, detail: Optional[str] = None) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    full_message = f"{message}: {detail}" if detail else message
    search_marker = SearchResult(random_id(), full_message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


def _get_import_name(import_node: Any) -> Optional[str]:
    """Extract the module name from an import node's qualid."""
    qualid = import_node.qualid
    if isinstance(qualid, FieldAccess):
        return qualid.name.simple_name
    if isinstance(qualid, Identifier):
        return qualid.simple_name
    return None


@categorize(_Python312)
class FindImpUsage(Recipe):
    """
    Find imports of the deprecated imp module.

    The imp module was deprecated in Python 3.4 (PEP 3121) and removed
    in Python 3.12. Projects should migrate to importlib.

    Common migrations:
    - imp.reload() -> importlib.reload()
    - imp.find_module() -> importlib.util.find_spec()
    - imp.load_module() -> Use importlib.util.module_from_spec() with loader.exec_module()

    Note: For simple imp.reload() calls, use ReplaceImpReload for auto-fix.
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindImpUsage"

    @property
    def display_name(self) -> str:
        return "Find deprecated imp module usage"

    @property
    def description(self) -> str:
        return (
            "Find imports of the deprecated `imp` module which was removed "
            "in Python 3.12. Migrate to `importlib`."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.12"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == 'imp':
                        return _mark_deprecated(
                            multi,
                            "imp module is deprecated",
                            "Migrate to importlib (removed in Python 3.12)"
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == 'imp':
                            return _mark_deprecated(
                                multi,
                                "imp module is deprecated",
                                "Migrate to importlib (removed in Python 3.12)"
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == 'imp':
                    return _mark_deprecated(
                        import_stmt,
                        "imp module is deprecated",
                        "Migrate to importlib (removed in Python 3.12)"
                    )
                return import_stmt

        return Visitor()


@categorize(_Python312)
class ReplaceImpReload(Recipe):
    """
    Replace `imp.reload()` with `importlib.reload()`.

    This is a direct 1:1 replacement that can be auto-fixed. The function
    signature and behavior are identical.

    Example:
        Before:
            import imp
            imp.reload(my_module)

        After:
            import importlib
            importlib.reload(my_module)

    Note: This recipe only replaces the method call. You may need to also
    update your imports from `import imp` to `import importlib`.
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceImpReload"

    @property
    def display_name(self) -> str:
        return "Replace `imp.reload()` with `importlib.reload()`"

    @property
    def description(self) -> str:
        return (
            "Replace `imp.reload()` with `importlib.reload()`. "
            "This is a direct 1:1 replacement with identical behavior."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.12"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                # Check if this is imp.reload()
                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "reload":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "imp":
                    return method

                # Replace imp with importlib
                new_select = select.replace(_simple_name="importlib")
                old_padded_select = method.padding.select
                new_padded_select = old_padded_select.replace(_element=new_select)
                return method.padding.replace(_select=new_padded_select)

        return Visitor()


@categorize(_Python312)
class ReplaceImpImport(Recipe):
    """
    Replace `import imp` with `import importlib` and `from imp import reload`
    with `from importlib import reload`.

    This auto-fixes import statements for the simple reload() use case.

    Example:
        Before:
            import imp

        After:
            import importlib

        Before:
            from imp import reload

        After:
            from importlib import reload
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceImpImport"

    @property
    def display_name(self) -> str:
        return "Replace `import imp` with `import importlib`"

    @property
    def description(self) -> str:
        return (
            "Replace `import imp` with `import importlib` for code that only "
            "uses imp.reload(). Also replaces `from imp import reload`."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.12"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    # Handle 'from imp import reload' -> 'from importlib import reload'
                    if isinstance(from_part, Identifier) and from_part.simple_name == 'imp':
                        # Check if only importing reload
                        import_names = []
                        for import_node in multi.names:
                            name = _get_import_name(import_node)
                            if name:
                                import_names.append(name)

                        # Only auto-fix if importing just 'reload'
                        if import_names == ['reload']:
                            new_from = from_part.replace(_simple_name='importlib')
                            return multi.replace(_from=new_from)
                else:
                    # Handle 'import imp' -> 'import importlib'
                    for i, import_node in enumerate(multi.names):
                        name = _get_import_name(import_node)
                        if name == 'imp':
                            # Replace imp with importlib in the qualid
                            qualid = import_node.qualid
                            if isinstance(qualid, Identifier):
                                new_qualid = qualid.replace(_simple_name='importlib')
                                new_import_node = import_node.replace(_qualid=new_qualid)
                                new_names = list(multi.names)
                                new_names[i] = new_import_node
                                return multi.replace(_names=new_names)

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                qualid = import_stmt.qualid
                if isinstance(qualid, Identifier) and qualid.simple_name == 'imp':
                    new_qualid = qualid.replace(_simple_name='importlib')
                    return import_stmt.replace(_qualid=new_qualid)
                return import_stmt

        return Visitor()
