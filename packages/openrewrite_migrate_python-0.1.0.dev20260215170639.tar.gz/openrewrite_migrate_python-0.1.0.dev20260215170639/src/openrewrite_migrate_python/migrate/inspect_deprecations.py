"""
Recipes for migrating deprecated inspect module functions.

inspect.getargspec() was deprecated in Python 3.0 and removed in Python 3.11.
The replacement is inspect.getfullargspec().

See: https://docs.python.org/3/library/inspect.html
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.11
_Python311 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.11"),
]


def _is_inspect_method(method: MethodInvocation, method_name: str) -> bool:
    """
    Check if this is an inspect.method_name() call.

    Uses multiple strategies to identify the method:
    1. Check method name matches
    2. Check type attribution if available (FQN contains 'inspect')
    3. Check simple name on select is 'inspect'
    """
    # Check method name first
    if not isinstance(method.name, Identifier):
        return False
    if method.name.simple_name != method_name:
        return False

    # Check if type info confirms this is an inspect method
    if method.method_type and method.method_type.declaring_type:
        dt = method.method_type.declaring_type
        if hasattr(dt, '_fully_qualified_name'):
            fqn = str(dt._fully_qualified_name)
            if 'inspect' in fqn:
                return True

    # Fallback: Check simple name on select
    select = method.select
    if select is None:
        return False
    if isinstance(select, Identifier) and select.simple_name == "inspect":
        return True

    return False


def _rename_method(method: MethodInvocation, new_name: str) -> MethodInvocation:
    """Rename a method invocation."""
    old_name = method.name
    if not isinstance(old_name, Identifier):
        return method

    new_identifier = old_name.replace(_simple_name=new_name)
    return method.replace(_name=new_identifier)


@categorize(_Python311)
class ReplaceInspectGetargspec(Recipe):
    """
    Replace `inspect.getargspec()` calls with `inspect.getfullargspec()`.

    The `inspect.getargspec()` function was deprecated in Python 3.0 and
    removed in Python 3.11. The replacement `inspect.getfullargspec()`
    provides the same information plus support for keyword-only arguments
    and annotations.

    Note: The return type changes from `ArgSpec` to `FullArgSpec`, which has
    additional fields. Code that accesses results by index will continue to
    work for the first 4 fields (args, varargs, varkw, defaults), but code
    that uses the `keywords` field name must change to `varkw`.

    Example:
        Before:
            import inspect
            spec = inspect.getargspec(my_func)

        After:
            import inspect
            spec = inspect.getfullargspec(my_func)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceInspectGetargspec"

    @property
    def display_name(self) -> str:
        return "Replace `inspect.getargspec()` with `inspect.getfullargspec()`"

    @property
    def description(self) -> str:
        return (
            "The `inspect.getargspec()` function was deprecated in Python 3.0 and "
            "removed in Python 3.11. Replace with `inspect.getfullargspec()`. "
            "Note that code accessing the `keywords` field must be updated to use `varkw`."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if _is_inspect_method(method, "getargspec"):
                    method = _rename_method(method, "getfullargspec")
                    return method

                return method

        return Visitor()
