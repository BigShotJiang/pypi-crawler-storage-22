"""
Recipes for migrating deprecated logging module methods.

The logging.warn() method was deprecated since Python 3.3 and should be
replaced with logging.warning(). While not yet removed, it's considered
best practice to use the recommended method.

See: https://docs.python.org/3/library/logging.html
"""

from typing import Any, List, Optional, cast

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.3
_Python33 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.3"),
]


@categorize(_Python33)
class ReplaceLoggingWarn(Recipe):
    """
    Replace `logging.warn()` with `logging.warning()`.

    The `warn()` method has been deprecated since Python 3.3. While it
    still works, `warning()` is the recommended method to use.

    Example:
        Before:
            import logging
            logging.warn("Something happened")
            logger.warn("Something happened")

        After:
            import logging
            logging.warning("Something happened")
            logger.warning("Something happened")
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceLoggingWarn"

    @property
    def display_name(self) -> str:
        return "Replace `logging.warn()` with `logging.warning()`"

    @property
    def description(self) -> str:
        return (
            "Replace `warn()` calls with `warning()`. "
            "The warn() method was deprecated in Python 3.3."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.3", "logging"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = cast(MethodInvocation, super().visit_method_invocation(method, p))

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "warn":
                    return method

                # Only match calls on the logging module itself
                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "logging":
                    return method

                # Replace warn with warning
                new_name = method.name.replace(_simple_name="warning")
                return method.replace(_name=new_name)

        return Visitor()
