"""
Recipes for migrating deprecated sys check interval functions.

The following functions were deprecated in Python 3.2 and removed in Python 3.9:
- sys.getcheckinterval() -> sys.getswitchinterval()
- sys.setcheckinterval() -> sys.setswitchinterval()

See: https://docs.python.org/3/whatsnew/3.9.html#removed
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.9
_Python39 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.9"),
]


@categorize(_Python39)
class ReplaceSysGetCheckInterval(Recipe):
    """
    Replace `sys.getcheckinterval()` with `sys.getswitchinterval()`.

    `sys.getcheckinterval()` was deprecated in Python 3.2 and removed in Python 3.9.

    Example:
        Before:
            import sys
            interval = sys.getcheckinterval()

        After:
            import sys
            interval = sys.getswitchinterval()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceSysGetCheckInterval"

    @property
    def display_name(self) -> str:
        return "Replace `sys.getcheckinterval()` with `sys.getswitchinterval()`"

    @property
    def description(self) -> str:
        return (
            "Replace `sys.getcheckinterval()` with `sys.getswitchinterval()`. "
            "Deprecated in Python 3.2 and removed in 3.9."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.9", "sys"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "getcheckinterval":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "sys":
                    return method

                new_name = method.name.replace(_simple_name="getswitchinterval")
                return method.replace(_name=new_name)

        return Visitor()


@categorize(_Python39)
class ReplaceSysSetCheckInterval(Recipe):
    """
    Replace `sys.setcheckinterval()` with `sys.setswitchinterval()`.

    `sys.setcheckinterval()` was deprecated in Python 3.2 and removed in Python 3.9.

    Note: The semantics differ slightly — the check interval was measured in
    bytecode instructions while the switch interval is measured in seconds.

    Example:
        Before:
            import sys
            sys.setcheckinterval(100)

        After:
            import sys
            sys.setswitchinterval(0.005)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceSysSetCheckInterval"

    @property
    def display_name(self) -> str:
        return "Replace `sys.setcheckinterval()` with `sys.setswitchinterval()`"

    @property
    def description(self) -> str:
        return (
            "Replace `sys.setcheckinterval()` with `sys.setswitchinterval()`. "
            "Deprecated in Python 3.2 and removed in 3.9. "
            "Note: The semantics differ — check interval was in bytecode instructions, "
            "switch interval is in seconds."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.9", "sys"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "setcheckinterval":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "sys":
                    return method

                new_name = method.name.replace(_simple_name="setswitchinterval")
                return method.replace(_name=new_name)

        return Visitor()
