"""
Recipes for migrating deprecated time module functions.

The following function was deprecated in Python 3.3 and removed in Python 3.8:
- time.clock() -> time.perf_counter() or time.process_time()

See: https://docs.python.org/3/whatsnew/3.8.html#api-and-feature-removals
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.8
_Python38 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.8"),
]


@categorize(_Python38)
class ReplaceTimeClock(Recipe):
    """
    Replace `time.clock()` with `time.perf_counter()`.

    `time.clock()` was deprecated in Python 3.3 and removed in Python 3.8.
    `time.perf_counter()` is the recommended replacement for measuring elapsed
    time. Use `time.process_time()` if you specifically need CPU time.

    Example:
        Before:
            import time
            start = time.clock()

        After:
            import time
            start = time.perf_counter()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceTimeClock"

    @property
    def display_name(self) -> str:
        return "Replace `time.clock()` with `time.perf_counter()`"

    @property
    def description(self) -> str:
        return (
            "Replace `time.clock()` with `time.perf_counter()`. "
            "time.clock() was deprecated in Python 3.3 and removed in 3.8."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.8", "time"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "clock":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "time":
                    return method

                # Replace clock with perf_counter
                new_name = method.name.replace(_simple_name="perf_counter")
                return method.replace(_name=new_name)

        return Visitor()
