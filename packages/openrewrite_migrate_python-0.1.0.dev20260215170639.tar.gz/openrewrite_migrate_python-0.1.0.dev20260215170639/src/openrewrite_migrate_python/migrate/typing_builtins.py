"""
Recipes for replacing typing module generics with built-in types.

Starting in Python 3.9, you can use built-in types directly as generics
instead of importing from typing:

- typing.List[X] -> list[X]
- typing.Dict[K, V] -> dict[K, V]
- typing.Set[X] -> set[X]
- typing.FrozenSet[X] -> frozenset[X]
- typing.Tuple[X, ...] -> tuple[X, ...]
- typing.Type[X] -> type[X]

See: https://peps.python.org/pep-0585/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.9
_Python39 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.9"),
]


def _create_typing_builtin_recipe(
    typing_name: str,
    builtin_name: str,
    recipe_name_suffix: str,
) -> type:
    """Factory to create recipes that replace typing.X with builtin x."""

    @categorize(_Python39)
    class ReplaceTypingWithBuiltin(Recipe):
        __doc__ = f"""
        Replace `typing.{typing_name}` with `{builtin_name}`.

        Starting in Python 3.9 (PEP 585), built-in types can be used directly
        as generic types instead of importing from the typing module.

        Example:
            Before:
                from typing import {typing_name}
                def process(items: {typing_name}[str]) -> None: ...

            After:
                def process(items: {builtin_name}[str]) -> None: ...
        """

        @property
        def name(self) -> str:
            return f"org.openrewrite.python.migrate.ReplaceTyping{recipe_name_suffix}WithBuiltin"

        @property
        def display_name(self) -> str:
            return f"Replace `typing.{typing_name}` with `{builtin_name}`"

        @property
        def description(self) -> str:
            return (
                f"Replace `typing.{typing_name}` with the built-in `{builtin_name}` type. "
                f"Available in Python 3.9+ (PEP 585)."
            )

        @property
        def tags(self) -> List[str]:
            return ["python", "migration", "3.9", "PEP 585", "typing"]

        def editor(self) -> TreeVisitor[Any, ExecutionContext]:
            outer_typing_name = typing_name
            outer_builtin_name = builtin_name

            class Visitor(PythonVisitor[ExecutionContext]):
                def visit_method_invocation(
                    self, method: MethodInvocation, p: ExecutionContext
                ) -> Optional[MethodInvocation]:
                    method = super().visit_method_invocation(method, p)

                    # Check if this is typing.List[], typing.Dict[], etc.
                    if not isinstance(method.name, Identifier):
                        return method
                    if method.name.simple_name != outer_typing_name:
                        return method

                    select = method.select
                    if not isinstance(select, Identifier):
                        return method
                    if select.simple_name != "typing":
                        return method

                    # Replace typing.List with list, etc.
                    # We need to replace the entire select.name with just the builtin name
                    new_name = method.name.replace(_simple_name=outer_builtin_name)
                    return method.replace(_select=None, _name=new_name)

            return Visitor()

    return ReplaceTypingWithBuiltin


# Create individual recipe classes
ReplaceTypingListWithBuiltin = _create_typing_builtin_recipe("List", "list", "List")
ReplaceTypingDictWithBuiltin = _create_typing_builtin_recipe("Dict", "dict", "Dict")
ReplaceTypingSetWithBuiltin = _create_typing_builtin_recipe("Set", "set", "Set")
ReplaceTypingFrozenSetWithBuiltin = _create_typing_builtin_recipe(
    "FrozenSet", "frozenset", "FrozenSet"
)
ReplaceTypingTupleWithBuiltin = _create_typing_builtin_recipe("Tuple", "tuple", "Tuple")
ReplaceTypingTypeWithBuiltin = _create_typing_builtin_recipe("Type", "type", "Type")
