"""
Recipes for replacing typing module aliases with their PEP 585 equivalents.

PEP 585 (Python 3.9+) deprecated many typing module aliases in favor of
the actual types in collections, collections.abc, re, and contextlib:

Collections module:
- typing.Deque -> collections.deque
- typing.DefaultDict -> collections.defaultdict
- typing.OrderedDict -> collections.OrderedDict
- typing.Counter -> collections.Counter
- typing.ChainMap -> collections.ChainMap

re module:
- typing.Pattern -> re.Pattern
- typing.Match -> re.Match

contextlib module:
- typing.ContextManager -> contextlib.AbstractContextManager
- typing.AsyncContextManager -> contextlib.AbstractAsyncContextManager

collections.abc module:
- typing.Iterable -> collections.abc.Iterable
- typing.Iterator -> collections.abc.Iterator
- typing.Generator -> collections.abc.Generator
- typing.Sequence -> collections.abc.Sequence
- typing.MutableSequence -> collections.abc.MutableSequence
- typing.Mapping -> collections.abc.Mapping
- typing.MutableMapping -> collections.abc.MutableMapping
- typing.AbstractSet -> collections.abc.Set
- typing.MutableSet -> collections.abc.MutableSet
- typing.Awaitable -> collections.abc.Awaitable
- typing.Coroutine -> collections.abc.Coroutine
- typing.AsyncIterable -> collections.abc.AsyncIterable
- typing.AsyncIterator -> collections.abc.AsyncIterator
- typing.AsyncGenerator -> collections.abc.AsyncGenerator
- typing.Reversible -> collections.abc.Reversible
- typing.Container -> collections.abc.Container
- typing.Collection -> collections.abc.Collection
- typing.MappingView -> collections.abc.MappingView
- typing.KeysView -> collections.abc.KeysView
- typing.ItemsView -> collections.abc.ItemsView
- typing.ValuesView -> collections.abc.ValuesView

See: https://peps.python.org/pep-0585/
"""

from typing import Any, List

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers
from rewrite.python.visitor import PythonVisitor
from rewrite.java.support_types import JLeftPadded, Space
from rewrite.java.tree import FieldAccess, Identifier, MethodInvocation
from rewrite.utils import random_id

# Define category path: Python > Migrate > Python 3.9
_Python39 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.9"),
]


def _create_typing_module_recipe(
    typing_name: str,
    new_module: str,
    new_name: str,
    recipe_class_name: str,
) -> type:
    """Factory to create recipes replacing typing.X with module.Y.

    Handles simple two-part replacements like typing.Deque -> collections.deque.
    """

    @categorize(_Python39)
    class _ReplaceTypingWithModule(Recipe):
        __doc__ = f"""
        Replace `typing.{typing_name}` with `{new_module}.{new_name}`.

        Starting in Python 3.9 (PEP 585), `typing.{typing_name}` is deprecated.
        Use `{new_module}.{new_name}` instead.

        Example:
            Before:
                x: typing.{typing_name}[int] = typing.{typing_name}()

            After:
                x: {new_module}.{new_name}[int] = {new_module}.{new_name}()
        """

        @property
        def name(self) -> str:
            return f"org.openrewrite.python.migrate.{recipe_class_name}"

        @property
        def display_name(self) -> str:
            return f"Replace `typing.{typing_name}` with `{new_module}.{new_name}`"

        @property
        def description(self) -> str:
            return (
                f"Replace `typing.{typing_name}` with `{new_module}.{new_name}`. "
                f"Available in Python 3.9+ (PEP 585)."
            )

        @property
        def tags(self) -> List[str]:
            return ["python", "migration", "3.9", "PEP 585", "typing"]

        def editor(self) -> TreeVisitor[Any, ExecutionContext]:
            outer_typing_name = typing_name
            outer_new_module = new_module
            outer_new_name = new_name

            class Visitor(PythonVisitor[ExecutionContext]):
                def visit_method_invocation(
                    self, method: MethodInvocation, p: ExecutionContext
                ):
                    method = super().visit_method_invocation(method, p)

                    if not isinstance(method.name, Identifier):
                        return method
                    if method.name.simple_name != outer_typing_name:
                        return method

                    select = method.select
                    if not isinstance(select, Identifier):
                        return method
                    if select.simple_name != "typing":
                        return method

                    # Replace select through the padding layer
                    new_select = select.replace(_simple_name=outer_new_module)
                    old_padded_select = method.padding.select
                    new_padded_select = old_padded_select.replace(_element=new_select)
                    new_method_name = method.name.replace(_simple_name=outer_new_name)
                    result = method.padding.replace(_select=new_padded_select)
                    return result.replace(_name=new_method_name)

                def visit_field_access(
                    self, field_access: FieldAccess, p: ExecutionContext
                ):
                    field_access = super().visit_field_access(field_access, p)

                    name = field_access.name
                    if not isinstance(name, Identifier):
                        return field_access
                    if name.simple_name != outer_typing_name:
                        return field_access

                    target = field_access.target
                    if not isinstance(target, Identifier):
                        return field_access
                    if target.simple_name != "typing":
                        return field_access

                    # Replace typing.X with module.Y
                    new_target = target.replace(_simple_name=outer_new_module)
                    new_name_id = name.replace(_simple_name=outer_new_name)
                    result = field_access.padding.replace(
                        name=field_access.padding.name.replace(element=new_name_id)
                    )
                    return result.replace(_target=new_target)

            return Visitor()

    _ReplaceTypingWithModule.__name__ = recipe_class_name
    _ReplaceTypingWithModule.__qualname__ = recipe_class_name
    return _ReplaceTypingWithModule


def _create_typing_abc_recipe(
    typing_name: str,
    abc_name: str,
    recipe_class_name: str,
) -> type:
    """Factory to create recipes replacing typing.X with collections.abc.Y.

    Handles three-part replacements like typing.Iterable -> collections.abc.Iterable.
    Constructs a FieldAccess node for collections.abc as the select expression.
    """

    @categorize(_Python39)
    class _ReplaceTypingWithAbc(Recipe):
        __doc__ = f"""
        Replace `typing.{typing_name}` with `collections.abc.{abc_name}`.

        Starting in Python 3.9 (PEP 585), `typing.{typing_name}` is deprecated.
        Use `collections.abc.{abc_name}` instead.

        Example:
            Before:
                x: typing.{typing_name}[int] = typing.{typing_name}()

            After:
                x: collections.abc.{abc_name}[int] = collections.abc.{abc_name}()
        """

        @property
        def name(self) -> str:
            return f"org.openrewrite.python.migrate.{recipe_class_name}"

        @property
        def display_name(self) -> str:
            return f"Replace `typing.{typing_name}` with `collections.abc.{abc_name}`"

        @property
        def description(self) -> str:
            return (
                f"Replace `typing.{typing_name}` with `collections.abc.{abc_name}`. "
                f"Available in Python 3.9+ (PEP 585)."
            )

        @property
        def tags(self) -> List[str]:
            return ["python", "migration", "3.9", "PEP 585", "typing"]

        def editor(self) -> TreeVisitor[Any, ExecutionContext]:
            outer_typing_name = typing_name
            outer_abc_name = abc_name

            def _build_collections_abc(typing_id: Identifier) -> FieldAccess:
                """Build a collections.abc FieldAccess, preserving prefix from the original typing identifier."""
                abc_identifier = Identifier(
                    _id=random_id(),
                    _prefix=Space.EMPTY,
                    _markers=Markers.EMPTY,
                    _annotations=[],
                    _simple_name="abc",
                    _type=None,
                    _field_type=None,
                )
                padded_abc = JLeftPadded(
                    _before=Space.EMPTY,
                    _element=abc_identifier,
                    _markers=Markers.EMPTY,
                )
                collections_id = typing_id.replace(
                    _simple_name="collections",
                    _prefix=Space.EMPTY,
                )
                return FieldAccess(
                    _id=random_id(),
                    _prefix=typing_id.prefix,
                    _markers=Markers.EMPTY,
                    _target=collections_id,
                    _name=padded_abc,
                    _type=None,
                )

            class Visitor(PythonVisitor[ExecutionContext]):
                def visit_method_invocation(
                    self, method: MethodInvocation, p: ExecutionContext
                ):
                    method = super().visit_method_invocation(method, p)

                    if not isinstance(method.name, Identifier):
                        return method
                    if method.name.simple_name != outer_typing_name:
                        return method

                    select = method.select
                    if not isinstance(select, Identifier):
                        return method
                    if select.simple_name != "typing":
                        return method

                    new_select = _build_collections_abc(select)
                    old_padded_select = method.padding.select
                    new_padded_select = old_padded_select.replace(_element=new_select)
                    new_method_name = method.name.replace(_simple_name=outer_abc_name)
                    result = method.padding.replace(_select=new_padded_select)
                    return result.replace(_name=new_method_name)

                def visit_field_access(
                    self, field_access: FieldAccess, p: ExecutionContext
                ):
                    field_access = super().visit_field_access(field_access, p)

                    name = field_access.name
                    if not isinstance(name, Identifier):
                        return field_access
                    if name.simple_name != outer_typing_name:
                        return field_access

                    target = field_access.target
                    if not isinstance(target, Identifier):
                        return field_access
                    if target.simple_name != "typing":
                        return field_access

                    # Replace typing.X with collections.abc.Y
                    new_target = _build_collections_abc(target)
                    new_name_id = name.replace(_simple_name=outer_abc_name)
                    result = field_access.padding.replace(
                        name=field_access.padding.name.replace(element=new_name_id)
                    )
                    return result.replace(_target=new_target)

            return Visitor()

    _ReplaceTypingWithAbc.__name__ = recipe_class_name
    _ReplaceTypingWithAbc.__qualname__ = recipe_class_name
    return _ReplaceTypingWithAbc


# --- collections module replacements ---

ReplaceTypingDequeWithCollectionsDeque = _create_typing_module_recipe(
    "Deque", "collections", "deque",
    "ReplaceTypingDequeWithCollectionsDeque",
)
ReplaceTypingDefaultDictWithCollectionsDefaultdict = _create_typing_module_recipe(
    "DefaultDict", "collections", "defaultdict",
    "ReplaceTypingDefaultDictWithCollectionsDefaultdict",
)
ReplaceTypingOrderedDictWithCollectionsOrderedDict = _create_typing_module_recipe(
    "OrderedDict", "collections", "OrderedDict",
    "ReplaceTypingOrderedDictWithCollectionsOrderedDict",
)
ReplaceTypingCounterWithCollectionsCounter = _create_typing_module_recipe(
    "Counter", "collections", "Counter",
    "ReplaceTypingCounterWithCollectionsCounter",
)
ReplaceTypingChainMapWithCollectionsChainMap = _create_typing_module_recipe(
    "ChainMap", "collections", "ChainMap",
    "ReplaceTypingChainMapWithCollectionsChainMap",
)

# --- re module replacements ---

ReplaceTypingPatternWithRePattern = _create_typing_module_recipe(
    "Pattern", "re", "Pattern",
    "ReplaceTypingPatternWithRePattern",
)
ReplaceTypingMatchWithReMatch = _create_typing_module_recipe(
    "Match", "re", "Match",
    "ReplaceTypingMatchWithReMatch",
)

# --- contextlib module replacements ---

ReplaceTypingContextManagerWithContextlib = _create_typing_module_recipe(
    "ContextManager", "contextlib", "AbstractContextManager",
    "ReplaceTypingContextManagerWithContextlib",
)
ReplaceTypingAsyncContextManagerWithContextlib = _create_typing_module_recipe(
    "AsyncContextManager", "contextlib", "AbstractAsyncContextManager",
    "ReplaceTypingAsyncContextManagerWithContextlib",
)

# --- collections.abc replacements ---

ReplaceTypingIterableWithCollectionsAbcIterable = _create_typing_abc_recipe(
    "Iterable", "Iterable",
    "ReplaceTypingIterableWithCollectionsAbcIterable",
)
ReplaceTypingIteratorWithCollectionsAbcIterator = _create_typing_abc_recipe(
    "Iterator", "Iterator",
    "ReplaceTypingIteratorWithCollectionsAbcIterator",
)
ReplaceTypingGeneratorWithCollectionsAbcGenerator = _create_typing_abc_recipe(
    "Generator", "Generator",
    "ReplaceTypingGeneratorWithCollectionsAbcGenerator",
)
ReplaceTypingSequenceWithCollectionsAbcSequence = _create_typing_abc_recipe(
    "Sequence", "Sequence",
    "ReplaceTypingSequenceWithCollectionsAbcSequence",
)
ReplaceTypingMutableSequenceWithCollectionsAbcMutableSequence = _create_typing_abc_recipe(
    "MutableSequence", "MutableSequence",
    "ReplaceTypingMutableSequenceWithCollectionsAbcMutableSequence",
)
ReplaceTypingMappingWithCollectionsAbcMapping = _create_typing_abc_recipe(
    "Mapping", "Mapping",
    "ReplaceTypingMappingWithCollectionsAbcMapping",
)
ReplaceTypingMutableMappingWithCollectionsAbcMutableMapping = _create_typing_abc_recipe(
    "MutableMapping", "MutableMapping",
    "ReplaceTypingMutableMappingWithCollectionsAbcMutableMapping",
)
ReplaceTypingAbstractSetWithCollectionsAbcSet = _create_typing_abc_recipe(
    "AbstractSet", "Set",
    "ReplaceTypingAbstractSetWithCollectionsAbcSet",
)
ReplaceTypingMutableSetWithCollectionsAbcMutableSet = _create_typing_abc_recipe(
    "MutableSet", "MutableSet",
    "ReplaceTypingMutableSetWithCollectionsAbcMutableSet",
)
ReplaceTypingAwaitableWithCollectionsAbcAwaitable = _create_typing_abc_recipe(
    "Awaitable", "Awaitable",
    "ReplaceTypingAwaitableWithCollectionsAbcAwaitable",
)
ReplaceTypingCoroutineWithCollectionsAbcCoroutine = _create_typing_abc_recipe(
    "Coroutine", "Coroutine",
    "ReplaceTypingCoroutineWithCollectionsAbcCoroutine",
)
ReplaceTypingAsyncIterableWithCollectionsAbcAsyncIterable = _create_typing_abc_recipe(
    "AsyncIterable", "AsyncIterable",
    "ReplaceTypingAsyncIterableWithCollectionsAbcAsyncIterable",
)
ReplaceTypingAsyncIteratorWithCollectionsAbcAsyncIterator = _create_typing_abc_recipe(
    "AsyncIterator", "AsyncIterator",
    "ReplaceTypingAsyncIteratorWithCollectionsAbcAsyncIterator",
)
ReplaceTypingAsyncGeneratorWithCollectionsAbcAsyncGenerator = _create_typing_abc_recipe(
    "AsyncGenerator", "AsyncGenerator",
    "ReplaceTypingAsyncGeneratorWithCollectionsAbcAsyncGenerator",
)
ReplaceTypingReversibleWithCollectionsAbcReversible = _create_typing_abc_recipe(
    "Reversible", "Reversible",
    "ReplaceTypingReversibleWithCollectionsAbcReversible",
)
ReplaceTypingContainerWithCollectionsAbcContainer = _create_typing_abc_recipe(
    "Container", "Container",
    "ReplaceTypingContainerWithCollectionsAbcContainer",
)
ReplaceTypingCollectionWithCollectionsAbcCollection = _create_typing_abc_recipe(
    "Collection", "Collection",
    "ReplaceTypingCollectionWithCollectionsAbcCollection",
)
ReplaceTypingMappingViewWithCollectionsAbcMappingView = _create_typing_abc_recipe(
    "MappingView", "MappingView",
    "ReplaceTypingMappingViewWithCollectionsAbcMappingView",
)
ReplaceTypingKeysViewWithCollectionsAbcKeysView = _create_typing_abc_recipe(
    "KeysView", "KeysView",
    "ReplaceTypingKeysViewWithCollectionsAbcKeysView",
)
ReplaceTypingItemsViewWithCollectionsAbcItemsView = _create_typing_abc_recipe(
    "ItemsView", "ItemsView",
    "ReplaceTypingItemsViewWithCollectionsAbcItemsView",
)
ReplaceTypingValuesViewWithCollectionsAbcValuesView = _create_typing_abc_recipe(
    "ValuesView", "ValuesView",
    "ReplaceTypingValuesViewWithCollectionsAbcValuesView",
)
