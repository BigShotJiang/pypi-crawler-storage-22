"""Composite recipe for upgrading from Python 3.8 to Python 3.9."""

from typing import List

from rewrite import Recipe
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python

# Define category path: Python > Migrate
_Migrate = [*Python, CategoryDescriptor(display_name="Migrate")]


@categorize(_Migrate)
class UpgradeToPython39(Recipe):
    """
    Migrate deprecated APIs for Python 3.9 compatibility.

    This composite recipe applies all necessary migrations for code
    running on Python 3.8 to be compatible with Python 3.9.

    Key changes in Python 3.9:
    - PEP 585: Built-in generics (`list[int]` instead of `typing.List[int]`)
    - `base64.encodestring()` / `decodestring()` removed
    - `Element.getiterator()` deprecated (use `iter()`)
    - `Element.getchildren()` deprecated (use `list(element)`)
    - `typing.Callable` deprecated in favor of `collections.abc.Callable`

    See: https://docs.python.org/3/whatsnew/3.9.html
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.UpgradeToPython39"

    @property
    def display_name(self) -> str:
        return "Upgrade to Python 3.9"

    @property
    def description(self) -> str:
        return (
            "Migrate deprecated APIs for Python 3.9 compatibility. "
            "This includes PEP 585 built-in generics, removed base64 functions, "
            "and deprecated XML Element methods."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.9"]

    def recipe_list(self) -> List[Recipe]:
        """Return the list of recipes to apply for Python 3.9 upgrade."""
        from .base64_deprecations import (
            ReplaceBase64Decodestring,
            ReplaceBase64Encodestring,
        )
        from .fractions_deprecations import ReplaceFractionsGcd
        from .html_parser_deprecations import FindHtmlParserUnescape
        from .sys_check_interval_deprecations import (
            ReplaceSysGetCheckInterval,
            ReplaceSysSetCheckInterval,
        )
        from .threading_is_alive_deprecation import ReplaceThreadIsAlive
        from .typing_builtins import (
            ReplaceTypingDictWithBuiltin,
            ReplaceTypingFrozenSetWithBuiltin,
            ReplaceTypingListWithBuiltin,
            ReplaceTypingSetWithBuiltin,
            ReplaceTypingTupleWithBuiltin,
            ReplaceTypingTypeWithBuiltin,
        )
        from .typing_callable import ReplaceTypingCallableWithCollectionsAbcCallable
        from .typing_pep585_extended import (
            ReplaceTypingDequeWithCollectionsDeque,
            ReplaceTypingDefaultDictWithCollectionsDefaultdict,
            ReplaceTypingOrderedDictWithCollectionsOrderedDict,
            ReplaceTypingCounterWithCollectionsCounter,
            ReplaceTypingChainMapWithCollectionsChainMap,
            ReplaceTypingPatternWithRePattern,
            ReplaceTypingMatchWithReMatch,
            ReplaceTypingContextManagerWithContextlib,
            ReplaceTypingAsyncContextManagerWithContextlib,
            ReplaceTypingIterableWithCollectionsAbcIterable,
            ReplaceTypingIteratorWithCollectionsAbcIterator,
            ReplaceTypingGeneratorWithCollectionsAbcGenerator,
            ReplaceTypingSequenceWithCollectionsAbcSequence,
            ReplaceTypingMutableSequenceWithCollectionsAbcMutableSequence,
            ReplaceTypingMappingWithCollectionsAbcMapping,
            ReplaceTypingMutableMappingWithCollectionsAbcMutableMapping,
            ReplaceTypingAbstractSetWithCollectionsAbcSet,
            ReplaceTypingMutableSetWithCollectionsAbcMutableSet,
            ReplaceTypingAwaitableWithCollectionsAbcAwaitable,
            ReplaceTypingCoroutineWithCollectionsAbcCoroutine,
            ReplaceTypingAsyncIterableWithCollectionsAbcAsyncIterable,
            ReplaceTypingAsyncIteratorWithCollectionsAbcAsyncIterator,
            ReplaceTypingAsyncGeneratorWithCollectionsAbcAsyncGenerator,
            ReplaceTypingReversibleWithCollectionsAbcReversible,
            ReplaceTypingContainerWithCollectionsAbcContainer,
            ReplaceTypingCollectionWithCollectionsAbcCollection,
            ReplaceTypingMappingViewWithCollectionsAbcMappingView,
            ReplaceTypingKeysViewWithCollectionsAbcKeysView,
            ReplaceTypingItemsViewWithCollectionsAbcItemsView,
            ReplaceTypingValuesViewWithCollectionsAbcValuesView,
        )
        from .upgrade_to_python38 import UpgradeToPython38
        from .xml_deprecations import FindElementGetchildren, ReplaceElementGetiterator

        return [
            # First apply all Python 3.8 upgrades
            UpgradeToPython38(),
            # base64 encodestring/decodestring removed in Python 3.9
            ReplaceBase64Encodestring(),
            ReplaceBase64Decodestring(),
            # PEP 585: Replace typing.List[X] with list[X], etc. (Python 3.9+)
            ReplaceTypingListWithBuiltin(),
            ReplaceTypingDictWithBuiltin(),
            ReplaceTypingSetWithBuiltin(),
            ReplaceTypingFrozenSetWithBuiltin(),
            ReplaceTypingTupleWithBuiltin(),
            ReplaceTypingTypeWithBuiltin(),
            # typing.Callable -> collections.abc.Callable (PEP 585)
            ReplaceTypingCallableWithCollectionsAbcCallable(),
            # PEP 585: typing -> collections replacements
            ReplaceTypingDequeWithCollectionsDeque(),
            ReplaceTypingDefaultDictWithCollectionsDefaultdict(),
            ReplaceTypingOrderedDictWithCollectionsOrderedDict(),
            ReplaceTypingCounterWithCollectionsCounter(),
            ReplaceTypingChainMapWithCollectionsChainMap(),
            # PEP 585: typing -> re replacements
            ReplaceTypingPatternWithRePattern(),
            ReplaceTypingMatchWithReMatch(),
            # PEP 585: typing -> contextlib replacements
            ReplaceTypingContextManagerWithContextlib(),
            ReplaceTypingAsyncContextManagerWithContextlib(),
            # PEP 585: typing -> collections.abc replacements
            ReplaceTypingIterableWithCollectionsAbcIterable(),
            ReplaceTypingIteratorWithCollectionsAbcIterator(),
            ReplaceTypingGeneratorWithCollectionsAbcGenerator(),
            ReplaceTypingSequenceWithCollectionsAbcSequence(),
            ReplaceTypingMutableSequenceWithCollectionsAbcMutableSequence(),
            ReplaceTypingMappingWithCollectionsAbcMapping(),
            ReplaceTypingMutableMappingWithCollectionsAbcMutableMapping(),
            ReplaceTypingAbstractSetWithCollectionsAbcSet(),
            ReplaceTypingMutableSetWithCollectionsAbcMutableSet(),
            ReplaceTypingAwaitableWithCollectionsAbcAwaitable(),
            ReplaceTypingCoroutineWithCollectionsAbcCoroutine(),
            ReplaceTypingAsyncIterableWithCollectionsAbcAsyncIterable(),
            ReplaceTypingAsyncIteratorWithCollectionsAbcAsyncIterator(),
            ReplaceTypingAsyncGeneratorWithCollectionsAbcAsyncGenerator(),
            ReplaceTypingReversibleWithCollectionsAbcReversible(),
            ReplaceTypingContainerWithCollectionsAbcContainer(),
            ReplaceTypingCollectionWithCollectionsAbcCollection(),
            ReplaceTypingMappingViewWithCollectionsAbcMappingView(),
            ReplaceTypingKeysViewWithCollectionsAbcKeysView(),
            ReplaceTypingItemsViewWithCollectionsAbcItemsView(),
            ReplaceTypingValuesViewWithCollectionsAbcValuesView(),
            # XML Element.getiterator() deprecated in 3.9, use iter()
            ReplaceElementGetiterator(),
            # XML Element.getchildren() deprecated in 3.9 (detection only)
            FindElementGetchildren(),
            # fractions.gcd() removed in 3.9, use math.gcd()
            ReplaceFractionsGcd(),
            # sys.getcheckinterval/setcheckinterval removed in 3.9
            ReplaceSysGetCheckInterval(),
            ReplaceSysSetCheckInterval(),
            # Thread.isAlive() removed in 3.9
            ReplaceThreadIsAlive(),
            # HTMLParser.unescape() removed in 3.9
            FindHtmlParserUnescape(),
        ]
