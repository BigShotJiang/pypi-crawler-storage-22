"""Tests for base64 deprecation migration recipes."""

import pytest

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.base64_deprecations import (
    ReplaceBase64Decodestring,
    ReplaceBase64Encodestring,
)


class TestReplaceBase64Encodestring:
    """Tests for ReplaceBase64Encodestring recipe."""

    def test_replaces_encodestring(self):
        spec = RecipeSpec(recipe=ReplaceBase64Encodestring())
        spec.rewrite_run(
            python(
                "encoded = base64.encodestring(data)",
                "encoded = base64.encodebytes(data)",
            )
        )

    def test_no_change_when_already_encodebytes(self):
        spec = RecipeSpec(recipe=ReplaceBase64Encodestring())
        spec.rewrite_run(
            python("encoded = base64.encodebytes(data)")
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=ReplaceBase64Encodestring())
        spec.rewrite_run(
            python("encoded = other.encodestring(data)")
        )


class TestReplaceBase64Decodestring:
    """Tests for ReplaceBase64Decodestring recipe."""

    def test_replaces_decodestring(self):
        spec = RecipeSpec(recipe=ReplaceBase64Decodestring())
        spec.rewrite_run(
            python(
                "decoded = base64.decodestring(data)",
                "decoded = base64.decodebytes(data)",
            )
        )

    def test_no_change_when_already_decodebytes(self):
        spec = RecipeSpec(recipe=ReplaceBase64Decodestring())
        spec.rewrite_run(
            python("decoded = base64.decodebytes(data)")
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=ReplaceBase64Decodestring())
        spec.rewrite_run(
            python("decoded = other.decodestring(data)")
        )
