"""Tests for fractions module deprecation migration recipes."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.fractions_deprecations import ReplaceFractionsGcd


class TestReplaceFractionsGcd:
    """Tests for ReplaceFractionsGcd recipe."""

    def test_replaces_fractions_gcd(self):
        spec = RecipeSpec(recipe=ReplaceFractionsGcd())
        spec.rewrite_run(
            python(
                """
                import fractions
                result = fractions.gcd(12, 8)
                """,
                # TODO Change import to math as well, but for now just verify the method call is replaced
                """
                import fractions
                result = math.gcd(12, 8)
                """,
            )
        )

    def test_no_change_when_already_math_gcd(self):
        spec = RecipeSpec(recipe=ReplaceFractionsGcd())
        spec.rewrite_run(
            python("result = math.gcd(12, 8)")
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=ReplaceFractionsGcd())
        spec.rewrite_run(
            python("result = other.gcd(12, 8)")
        )

    def test_no_change_when_different_method(self):
        spec = RecipeSpec(recipe=ReplaceFractionsGcd())
        spec.rewrite_run(
            python("result = fractions.Fraction(1, 3)")
        )
