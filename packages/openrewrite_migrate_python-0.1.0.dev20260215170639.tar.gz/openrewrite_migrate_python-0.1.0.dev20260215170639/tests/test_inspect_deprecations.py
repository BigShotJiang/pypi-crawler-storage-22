"""Tests for inspect deprecation migration recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.inspect_deprecations import (
    ReplaceInspectGetargspec,
)


class TestReplaceInspectGetargspec:
    """Tests for the ReplaceInspectGetargspec recipe."""

    def test_replaces_inspect_getargspec(self):
        """Test that inspect.getargspec() is replaced with getfullargspec."""
        spec = RecipeSpec(recipe=ReplaceInspectGetargspec())
        spec.rewrite_run(
            python(
                """
                import inspect
                spec = inspect.getargspec(my_func)
                """,
                """
                import inspect
                spec = inspect.getfullargspec(my_func)
                """,
            )
        )

    def test_replaces_with_variable_argument(self):
        """Test replacement when function is passed as a variable."""
        spec = RecipeSpec(recipe=ReplaceInspectGetargspec())
        spec.rewrite_run(
            python(
                """
                import inspect

                def analyze(func):
                    return inspect.getargspec(func)
                """,
                """
                import inspect

                def analyze(func):
                    return inspect.getfullargspec(func)
                """,
            )
        )

    def test_no_change_when_getfullargspec(self):
        """Test that inspect.getfullargspec() is not modified."""
        spec = RecipeSpec(recipe=ReplaceInspectGetargspec())
        spec.rewrite_run(
            python(
                """
                import inspect
                spec = inspect.getfullargspec(my_func)
                """
            )
        )

    def test_no_change_when_different_module(self):
        """Test that getargspec on a different object is not modified."""
        spec = RecipeSpec(recipe=ReplaceInspectGetargspec())
        spec.rewrite_run(
            python(
                """
                class MyInspect:
                    def getargspec(self, func):
                        pass

                obj = MyInspect()
                obj.getargspec(some_func)
                """
            )
        )

    def test_replaces_in_conditional(self):
        """Test replacement works inside conditional expressions."""
        spec = RecipeSpec(recipe=ReplaceInspectGetargspec())
        spec.rewrite_run(
            python(
                """
                import inspect

                args = inspect.getargspec(func).args if func else []
                """,
                """
                import inspect

                args = inspect.getfullargspec(func).args if func else []
                """,
            )
        )
