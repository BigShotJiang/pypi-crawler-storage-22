"""Tests for logging deprecation migration recipes."""

import pytest

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.logging_deprecations import ReplaceLoggingWarn


class TestReplaceLoggingWarn:
    """Tests for ReplaceLoggingWarn recipe."""

    def test_replaces_logging_warn(self):
        spec = RecipeSpec(recipe=ReplaceLoggingWarn())
        spec.rewrite_run(
            python(
                'logging.warn("message")',
                'logging.warning("message")',
            )
        )

    def test_no_change_for_logger_warn_without_type_info(self):
        spec = RecipeSpec(recipe=ReplaceLoggingWarn())
        spec.rewrite_run(
            python('logger.warn("message")')
        )

    def test_no_change_when_already_warning(self):
        spec = RecipeSpec(recipe=ReplaceLoggingWarn())
        spec.rewrite_run(
            python('logging.warning("message")')
        )

    def test_no_change_when_no_select(self):
        spec = RecipeSpec(recipe=ReplaceLoggingWarn())
        spec.rewrite_run(
            python('warn("message")')
        )

    def test_no_change_for_warnings_warn(self):
        spec = RecipeSpec(recipe=ReplaceLoggingWarn())
        spec.rewrite_run(
            python('warnings.warn("deprecated", DeprecationWarning)')
        )
