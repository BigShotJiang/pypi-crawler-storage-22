"""Tests for sys check interval deprecation migration recipes."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.sys_check_interval_deprecations import (
    ReplaceSysGetCheckInterval,
    ReplaceSysSetCheckInterval,
)


class TestReplaceSysGetCheckInterval:
    """Tests for ReplaceSysGetCheckInterval recipe."""

    def test_replaces_getcheckinterval(self):
        spec = RecipeSpec(recipe=ReplaceSysGetCheckInterval())
        spec.rewrite_run(
            python(
                "interval = sys.getcheckinterval()",
                "interval = sys.getswitchinterval()",
            )
        )

    def test_no_change_when_already_getswitchinterval(self):
        spec = RecipeSpec(recipe=ReplaceSysGetCheckInterval())
        spec.rewrite_run(
            python("interval = sys.getswitchinterval()")
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=ReplaceSysGetCheckInterval())
        spec.rewrite_run(
            python("interval = other.getcheckinterval()")
        )


class TestReplaceSysSetCheckInterval:
    """Tests for ReplaceSysSetCheckInterval recipe."""

    def test_replaces_setcheckinterval(self):
        spec = RecipeSpec(recipe=ReplaceSysSetCheckInterval())
        spec.rewrite_run(
            python(
                "sys.setcheckinterval(100)",
                "sys.setswitchinterval(100)",
            )
        )

    def test_no_change_when_already_setswitchinterval(self):
        spec = RecipeSpec(recipe=ReplaceSysSetCheckInterval())
        spec.rewrite_run(
            python("sys.setswitchinterval(0.005)")
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=ReplaceSysSetCheckInterval())
        spec.rewrite_run(
            python("other.setcheckinterval(100)")
        )
