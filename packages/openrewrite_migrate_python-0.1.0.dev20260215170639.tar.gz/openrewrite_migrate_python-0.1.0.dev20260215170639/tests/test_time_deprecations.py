"""Tests for time module deprecation migration recipes."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.time_deprecations import ReplaceTimeClock


class TestReplaceTimeClock:
    """Tests for ReplaceTimeClock recipe."""

    def test_replaces_time_clock(self):
        spec = RecipeSpec(recipe=ReplaceTimeClock())
        spec.rewrite_run(
            python(
                "start = time.clock()",
                "start = time.perf_counter()",
            )
        )

    def test_no_change_when_already_perf_counter(self):
        spec = RecipeSpec(recipe=ReplaceTimeClock())
        spec.rewrite_run(
            python("start = time.perf_counter()")
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=ReplaceTimeClock())
        spec.rewrite_run(
            python("start = other.clock()")
        )

    def test_no_change_when_different_method(self):
        spec = RecipeSpec(recipe=ReplaceTimeClock())
        spec.rewrite_run(
            python("start = time.sleep(1)")
        )
