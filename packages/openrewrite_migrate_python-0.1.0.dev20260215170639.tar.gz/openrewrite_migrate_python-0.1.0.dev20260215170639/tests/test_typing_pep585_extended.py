"""Tests for PEP 585 extended typing replacement recipes."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.typing_pep585_extended import (
    ReplaceTypingDequeWithCollectionsDeque,
    ReplaceTypingDefaultDictWithCollectionsDefaultdict,
    ReplaceTypingOrderedDictWithCollectionsOrderedDict,
    ReplaceTypingCounterWithCollectionsCounter,
    ReplaceTypingChainMapWithCollectionsChainMap,
    ReplaceTypingPatternWithRePattern,
    ReplaceTypingMatchWithReMatch,
    ReplaceTypingContextManagerWithContextlib,
    ReplaceTypingAsyncContextManagerWithContextlib,
    ReplaceTypingIterableWithCollectionsAbcIterable,
    ReplaceTypingIteratorWithCollectionsAbcIterator,
    ReplaceTypingGeneratorWithCollectionsAbcGenerator,
    ReplaceTypingSequenceWithCollectionsAbcSequence,
    ReplaceTypingMutableSequenceWithCollectionsAbcMutableSequence,
    ReplaceTypingMappingWithCollectionsAbcMapping,
    ReplaceTypingMutableMappingWithCollectionsAbcMutableMapping,
    ReplaceTypingAbstractSetWithCollectionsAbcSet,
    ReplaceTypingMutableSetWithCollectionsAbcMutableSet,
    ReplaceTypingAwaitableWithCollectionsAbcAwaitable,
    ReplaceTypingCoroutineWithCollectionsAbcCoroutine,
    ReplaceTypingAsyncIterableWithCollectionsAbcAsyncIterable,
    ReplaceTypingAsyncIteratorWithCollectionsAbcAsyncIterator,
    ReplaceTypingAsyncGeneratorWithCollectionsAbcAsyncGenerator,
    ReplaceTypingReversibleWithCollectionsAbcReversible,
    ReplaceTypingContainerWithCollectionsAbcContainer,
    ReplaceTypingCollectionWithCollectionsAbcCollection,
    ReplaceTypingMappingViewWithCollectionsAbcMappingView,
    ReplaceTypingKeysViewWithCollectionsAbcKeysView,
    ReplaceTypingItemsViewWithCollectionsAbcItemsView,
    ReplaceTypingValuesViewWithCollectionsAbcValuesView,
)


# --- collections module replacements ---

class TestReplaceTypingDeque:
    def test_replaces_typing_deque(self):
        spec = RecipeSpec(recipe=ReplaceTypingDequeWithCollectionsDeque())
        spec.rewrite_run(
            python(
                "x = typing.Deque()",
                "x = collections.deque()",
            )
        )

    def test_replaces_typing_deque_subscript(self):
        spec = RecipeSpec(recipe=ReplaceTypingDequeWithCollectionsDeque())
        spec.rewrite_run(
            python(
                "x: typing.Deque[int] = typing.Deque()",
                "x: collections.deque[int] = collections.deque()",
            )
        )

    def test_no_change_when_not_typing(self):
        spec = RecipeSpec(recipe=ReplaceTypingDequeWithCollectionsDeque())
        spec.rewrite_run(
            python("x = collections.deque()")
        )


class TestReplaceTypingDefaultDict:
    def test_replaces_typing_defaultdict(self):
        spec = RecipeSpec(recipe=ReplaceTypingDefaultDictWithCollectionsDefaultdict())
        spec.rewrite_run(
            python(
                "x = typing.DefaultDict(int)",
                "x = collections.defaultdict(int)",
            )
        )

    def test_no_change_when_not_typing(self):
        spec = RecipeSpec(recipe=ReplaceTypingDefaultDictWithCollectionsDefaultdict())
        spec.rewrite_run(
            python("x = collections.defaultdict(int)")
        )


class TestReplaceTypingOrderedDict:
    def test_replaces_typing_ordered_dict(self):
        spec = RecipeSpec(recipe=ReplaceTypingOrderedDictWithCollectionsOrderedDict())
        spec.rewrite_run(
            python(
                "x = typing.OrderedDict()",
                "x = collections.OrderedDict()",
            )
        )


class TestReplaceTypingCounter:
    def test_replaces_typing_counter(self):
        spec = RecipeSpec(recipe=ReplaceTypingCounterWithCollectionsCounter())
        spec.rewrite_run(
            python(
                "x = typing.Counter()",
                "x = collections.Counter()",
            )
        )


class TestReplaceTypingChainMap:
    def test_replaces_typing_chainmap(self):
        spec = RecipeSpec(recipe=ReplaceTypingChainMapWithCollectionsChainMap())
        spec.rewrite_run(
            python(
                "x = typing.ChainMap()",
                "x = collections.ChainMap()",
            )
        )


# --- re module replacements ---

class TestReplaceTypingPattern:
    def test_replaces_typing_pattern(self):
        spec = RecipeSpec(recipe=ReplaceTypingPatternWithRePattern())
        spec.rewrite_run(
            python(
                "x = typing.Pattern()",
                "x = re.Pattern()",
            )
        )

    def test_replaces_typing_pattern_subscript(self):
        spec = RecipeSpec(recipe=ReplaceTypingPatternWithRePattern())
        spec.rewrite_run(
            python(
                "x: typing.Pattern[str] = re.compile('foo')",
                "x: re.Pattern[str] = re.compile('foo')",
            )
        )

    def test_no_change_when_not_typing(self):
        spec = RecipeSpec(recipe=ReplaceTypingPatternWithRePattern())
        spec.rewrite_run(
            python("x = re.compile('foo')")
        )


class TestReplaceTypingMatch:
    def test_replaces_typing_match(self):
        spec = RecipeSpec(recipe=ReplaceTypingMatchWithReMatch())
        spec.rewrite_run(
            python(
                "x = typing.Match()",
                "x = re.Match()",
            )
        )


# --- contextlib replacements ---

class TestReplaceTypingContextManager:
    def test_replaces_typing_context_manager(self):
        spec = RecipeSpec(recipe=ReplaceTypingContextManagerWithContextlib())
        spec.rewrite_run(
            python(
                "x = typing.ContextManager()",
                "x = contextlib.AbstractContextManager()",
            )
        )


class TestReplaceTypingAsyncContextManager:
    def test_replaces_typing_async_context_manager(self):
        spec = RecipeSpec(recipe=ReplaceTypingAsyncContextManagerWithContextlib())
        spec.rewrite_run(
            python(
                "x = typing.AsyncContextManager()",
                "x = contextlib.AbstractAsyncContextManager()",
            )
        )


# --- collections.abc replacements ---

class TestReplaceTypingIterable:
    def test_replaces_typing_iterable(self):
        spec = RecipeSpec(recipe=ReplaceTypingIterableWithCollectionsAbcIterable())
        spec.rewrite_run(
            python(
                "x = typing.Iterable()",
                "x = collections.abc.Iterable()",
            )
        )

    def test_replaces_typing_iterable_subscript(self):
        spec = RecipeSpec(recipe=ReplaceTypingIterableWithCollectionsAbcIterable())
        spec.rewrite_run(
            python(
                "x: typing.Iterable[int] = []",
                "x: collections.abc.Iterable[int] = []",
            )
        )

    def test_no_change_when_not_typing(self):
        spec = RecipeSpec(recipe=ReplaceTypingIterableWithCollectionsAbcIterable())
        spec.rewrite_run(
            python("x = list()")
        )


class TestReplaceTypingIterator:
    def test_replaces_typing_iterator(self):
        spec = RecipeSpec(recipe=ReplaceTypingIteratorWithCollectionsAbcIterator())
        spec.rewrite_run(
            python(
                "x = typing.Iterator()",
                "x = collections.abc.Iterator()",
            )
        )


class TestReplaceTypingSequence:
    def test_replaces_typing_sequence(self):
        spec = RecipeSpec(recipe=ReplaceTypingSequenceWithCollectionsAbcSequence())
        spec.rewrite_run(
            python(
                "x = typing.Sequence()",
                "x = collections.abc.Sequence()",
            )
        )


class TestReplaceTypingMapping:
    def test_replaces_typing_mapping(self):
        spec = RecipeSpec(recipe=ReplaceTypingMappingWithCollectionsAbcMapping())
        spec.rewrite_run(
            python(
                "x = typing.Mapping()",
                "x = collections.abc.Mapping()",
            )
        )


class TestReplaceTypingGenerator:
    def test_replaces_typing_generator(self):
        spec = RecipeSpec(recipe=ReplaceTypingGeneratorWithCollectionsAbcGenerator())
        spec.rewrite_run(
            python(
                "x = typing.Generator()",
                "x = collections.abc.Generator()",
            )
        )


class TestReplaceTypingMutableSequence:
    def test_replaces(self):
        spec = RecipeSpec(recipe=ReplaceTypingMutableSequenceWithCollectionsAbcMutableSequence())
        spec.rewrite_run(
            python(
                "x = typing.MutableSequence()",
                "x = collections.abc.MutableSequence()",
            )
        )


class TestReplaceTypingMutableMapping:
    def test_replaces(self):
        spec = RecipeSpec(recipe=ReplaceTypingMutableMappingWithCollectionsAbcMutableMapping())
        spec.rewrite_run(
            python(
                "x = typing.MutableMapping()",
                "x = collections.abc.MutableMapping()",
            )
        )


class TestReplaceTypingAbstractSet:
    def test_replaces(self):
        spec = RecipeSpec(recipe=ReplaceTypingAbstractSetWithCollectionsAbcSet())
        spec.rewrite_run(
            python(
                "x = typing.AbstractSet()",
                "x = collections.abc.Set()",
            )
        )


class TestReplaceTypingMutableSet:
    def test_replaces(self):
        spec = RecipeSpec(recipe=ReplaceTypingMutableSetWithCollectionsAbcMutableSet())
        spec.rewrite_run(
            python(
                "x = typing.MutableSet()",
                "x = collections.abc.MutableSet()",
            )
        )


class TestReplaceTypingAwaitable:
    def test_replaces(self):
        spec = RecipeSpec(recipe=ReplaceTypingAwaitableWithCollectionsAbcAwaitable())
        spec.rewrite_run(
            python(
                "x = typing.Awaitable()",
                "x = collections.abc.Awaitable()",
            )
        )


class TestReplaceTypingCoroutine:
    def test_replaces(self):
        spec = RecipeSpec(recipe=ReplaceTypingCoroutineWithCollectionsAbcCoroutine())
        spec.rewrite_run(
            python(
                "x = typing.Coroutine()",
                "x = collections.abc.Coroutine()",
            )
        )


class TestReplaceTypingAsyncIterable:
    def test_replaces(self):
        spec = RecipeSpec(recipe=ReplaceTypingAsyncIterableWithCollectionsAbcAsyncIterable())
        spec.rewrite_run(
            python(
                "x = typing.AsyncIterable()",
                "x = collections.abc.AsyncIterable()",
            )
        )


class TestReplaceTypingAsyncIterator:
    def test_replaces(self):
        spec = RecipeSpec(recipe=ReplaceTypingAsyncIteratorWithCollectionsAbcAsyncIterator())
        spec.rewrite_run(
            python(
                "x = typing.AsyncIterator()",
                "x = collections.abc.AsyncIterator()",
            )
        )


class TestReplaceTypingAsyncGenerator:
    def test_replaces(self):
        spec = RecipeSpec(recipe=ReplaceTypingAsyncGeneratorWithCollectionsAbcAsyncGenerator())
        spec.rewrite_run(
            python(
                "x = typing.AsyncGenerator()",
                "x = collections.abc.AsyncGenerator()",
            )
        )


class TestReplaceTypingReversible:
    def test_replaces(self):
        spec = RecipeSpec(recipe=ReplaceTypingReversibleWithCollectionsAbcReversible())
        spec.rewrite_run(
            python(
                "x = typing.Reversible()",
                "x = collections.abc.Reversible()",
            )
        )


class TestReplaceTypingContainer:
    def test_replaces(self):
        spec = RecipeSpec(recipe=ReplaceTypingContainerWithCollectionsAbcContainer())
        spec.rewrite_run(
            python(
                "x = typing.Container()",
                "x = collections.abc.Container()",
            )
        )


class TestReplaceTypingCollection:
    def test_replaces(self):
        spec = RecipeSpec(recipe=ReplaceTypingCollectionWithCollectionsAbcCollection())
        spec.rewrite_run(
            python(
                "x = typing.Collection()",
                "x = collections.abc.Collection()",
            )
        )


class TestReplaceTypingMappingView:
    def test_replaces(self):
        spec = RecipeSpec(recipe=ReplaceTypingMappingViewWithCollectionsAbcMappingView())
        spec.rewrite_run(
            python(
                "x = typing.MappingView()",
                "x = collections.abc.MappingView()",
            )
        )


class TestReplaceTypingKeysView:
    def test_replaces(self):
        spec = RecipeSpec(recipe=ReplaceTypingKeysViewWithCollectionsAbcKeysView())
        spec.rewrite_run(
            python(
                "x = typing.KeysView()",
                "x = collections.abc.KeysView()",
            )
        )


class TestReplaceTypingItemsView:
    def test_replaces(self):
        spec = RecipeSpec(recipe=ReplaceTypingItemsViewWithCollectionsAbcItemsView())
        spec.rewrite_run(
            python(
                "x = typing.ItemsView()",
                "x = collections.abc.ItemsView()",
            )
        )


class TestReplaceTypingValuesView:
    def test_replaces(self):
        spec = RecipeSpec(recipe=ReplaceTypingValuesViewWithCollectionsAbcValuesView())
        spec.rewrite_run(
            python(
                "x = typing.ValuesView()",
                "x = collections.abc.ValuesView()",
            )
        )
