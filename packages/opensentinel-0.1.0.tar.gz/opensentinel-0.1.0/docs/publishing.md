# Publishing to PyPI

This guide details how to build and publish `opensentinel` to the Python Package Index (PyPI).

## Prerequisites

1.  **PyPI Account**: You need an account on [PyPI](https://pypi.org/).
2.  **TestPyPI Account** (Optional but recommended): You should also have an account on [TestPyPI](https://test.pypi.org/) to test releases before the real thing.
3.  **API Token**: Create an API token in your PyPI account settings (Account Settings -> API tokens). Scope it to "Entire account" (for new projects) or strictly to "open-sentinel" if it already exists.

## One-time Setup

Ensure you have the build tools installed. If you haven't already:

```bash
pip install build twine
```

Or use the provided Makefile target (requires dev dependencies):

```bash
make install-dev
```

## Build the Package

To build the source distribution and wheel:

```bash
make build
```

This will run `clean-build` first, then generate artifacts in `dist/`.

## Publish to TestPyPI

It is highly recommended to upload to TestPyPI first to ensure everything looks correct (README rendering, metadata, etc.).

1.  Run the publish command:

    ```bash
    make publish-test
    ```

2.  You will be prompted for your username and password.
    *   **Username**: `__token__`
    *   **Password**: Your TestPyPI API token (starting with `pypi-`).

3.  Verify the package on [TestPyPI](https://test.pypi.org/project/open-sentinel/).

## Publish to PyPI

Once you are confident, publish to the real PyPI:

1.  **Check Version**: Ensure `version` in `pyproject.toml` is correct and hasn't been used before. PyPI does not allow overwriting versions.

2.  Run the publish command:

    ```bash
    make publish
    ```

3.  Enter your credentials:
    *   **Username**: `__token__`
    *   **Password**: Your generic PyPI API token (starting with `pypi-`).

## Automating with `.pypirc`

To avoid entering credentials every time, you can create a `~/.pypirc` file:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
  username = __token__
  password = pypi-xxxxxxxxxxxxxxxx

[testpypi]
  repository = https://test.pypi.org/legacy/
  username = __token__
  password = pypi-xxxxxxxxxxxxxxxx
```

**Security Warning**: Protect this file! On Unix-like rulesystems, run `chmod 600 ~/.pypirc`.
