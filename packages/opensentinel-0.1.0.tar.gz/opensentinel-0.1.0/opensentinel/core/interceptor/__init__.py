"""
Interceptor module for Open Sentinel.

Provides a clean abstraction for running checkers at different phases
of the LLM request lifecycle.
"""

from .adapters import PolicyEngineChecker
from .checker import Checker
from .interceptor import Interceptor
from .types import (
    CheckDecision,
    CheckerContext,
    CheckerMode,
    CheckPhase,
    CheckResult,
    InterceptionResult,
    PolicyViolation,
)

__all__ = [
    # Types
    "CheckPhase",
    "CheckerMode",
    "CheckDecision",
    "CheckResult",
    "CheckerContext",
    "InterceptionResult",
    "PolicyViolation",
    # Classes
    "Checker",
    "Interceptor",
    "PolicyEngineChecker",
]
