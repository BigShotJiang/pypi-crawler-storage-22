"""NTRS public curated data pack for OpenSolids."""

__all__ = ["__version__"]
__version__ = "0.2.1"
