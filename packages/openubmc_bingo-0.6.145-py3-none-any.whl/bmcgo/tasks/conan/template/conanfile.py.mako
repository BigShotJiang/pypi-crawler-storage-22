#!/usr/bin/env python
# coding=utf-8
# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# openUBMC is licensed under Mulan PSL v2.
# You can obtain a copy of Mulan PSL v2 at:
#         http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.

"""
MDS/MDB Conan制品conanfile模板
通过mako模板引擎动态生成，支持Conan v2
"""

from conan import ConanFile
from conan.tools.files import copy


class BoardMetadataConan(ConanFile):
    name = "${package_name}"
    version = "${version}"
    license = "Mulan PSL v2"
    # 使用exports_sources将文件导出到recipe中，不使用package()方法
    exports_sources = "${"\", \"".join(exports_sources)}"
    # build_policy=never表示不从源码构建，仅使用export-pkg
    build_policy = "never"
