# OpenVideo

Open-source AI video generation library without API keys. Generate videos from text prompts or images using open-source models.

## Features

- **Text-to-Video**: Generate videos from text descriptions
- **Image-to-Video**: Animate static images into videos
- **Multiple Models**: Support for various open-source models (Zeroscope, ModelScope, AnimateDiff)
- **No API Keys Required**: Fully local generation using open-source models
- **CLI Interface**: Easy command-line usage
- **Python API**: Programmatic access for developers

## Installation

```bash
pip install openvideo
```

For development installation:

```bash
pip install openvideo[dev]
```

## Requirements

- Python 3.9+
- CUDA-capable GPU (recommended for performance)
- 8GB+ VRAM for video generation

## Quick Start

### CLI Usage

```bash
# Text to Video
openvideo text2video -p "a cat walking in the snow" -o output.mp4

# Image to Video
openvideo image2video -i input.png -o output.mp4 -p "camera panning"
```

### Python API

```python
from openvideo import VideoGenerator

# Initialize generator
generator = VideoGenerator(model_name="zeroscope")

# Generate from text
frames = generator.generate(
    prompt="a beautiful sunset over the ocean",
    num_frames=24,
    width=512,
    height=512,
)

# Save video
generator.save_video(frames, "output.mp4", fps=24)
```

```python
# Generate from image
from PIL import Image

img = Image.open("input.png")
frames = generator.generate_from_image(
    image=img,
    prompt="gentle camera pan",
    num_frames=24,
)
generator.save_video(frames, "output.mp4")
```

## Supported Models

| Model | Description | VRAM |
|-------|-------------|------|
| zeroscope | High-quality text-to-video | 8GB |
| modelscope | Fast text-to-video | 6GB |
| animatediff | Animation from SD models | 6GB |

## Configuration

### GPU Settings

```python
# Use specific device
generator = VideoGenerator(device="cuda")

# Use float16 for less VRAM
generator = VideoGenerator(dtype="float16")
```

### Generation Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| num_frames | 24 | Number of frames |
| width | 512 | Frame width |
| height | 512 | Frame height |
| num_inference_steps | 25 | Denoising steps |
| guidance_scale | 7.5 | CFG scale |
| seed | None | Random seed |

## Advanced Usage

### Custom Model Loading

```python
from openvideo.models.text2video import TextToVideoModel

model = TextToVideoModel(model_name="zeroscope")
model.load()
frames = model.generate(prompt="your prompt")
```

### Batch Generation

```python
prompts = [
    "a dog running in park",
    "a bird flying in sky",
    "rain falling on window",
]

for i, prompt in enumerate(prompts):
    frames = generator.generate(prompt=prompt)
    generator.save_video(frames, f"video_{i}.mp4")
```

## Troubleshooting

### Out of Memory

- Reduce resolution (width/height)
- Use float16 dtype
- Reduce num_frames
- Enable attention slicing

### Slow Generation

- Use GPU instead of CPU
- Reduce num_inference_steps
- Use smaller models

## License

MIT License

## Credits

- Uses Hugging Face Diffusers
- Model weights from various open-source projects
