import pytest
import numpy as np
from pathlib import Path


class TestVideoGenerator:
    def test_init_default(self):
        from openvideo import VideoGenerator
        gen = VideoGenerator()
        assert gen.model_name == "zeroscope"
        
    def test_init_custom_model(self):
        from openvideo import VideoGenerator
        gen = VideoGenerator(model_name="modelscope")
        assert gen.model_name == "modelscope"
        
    def test_save_video_frames_shape(self):
        from openvideo import VideoGenerator
        gen = VideoGenerator()
        frames = np.random.randint(0, 255, (24, 512, 512, 3), dtype=np.uint8)
        assert frames.shape == (24, 512, 512, 3)


class TestTextToVideoModel:
    def test_supported_models(self):
        from openvideo.models.text2video import TextToVideoModel
        model = TextToVideoModel()
        assert "zeroscope" in model.SUPPORTED_MODELS
        assert "modelscope" in model.SUPPORTED_MODELS


class TestImageToVideoModel:
    def test_supported_models(self):
        from openvideo.models.image2video import ImageToVideoModel
        model = ImageToVideoModel()
        assert "zeroscope_v2" in model.SUPPORTED_MODELS


def test_version():
    import openvideo
    assert openvideo.__version__ == "0.1.0"
