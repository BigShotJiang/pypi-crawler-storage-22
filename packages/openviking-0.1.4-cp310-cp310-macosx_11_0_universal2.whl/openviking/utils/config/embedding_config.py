# Copyright (c) 2026 Beijing Volcano Engine Technology Co., Ltd.
# SPDX-License-Identifier: Apache-2.0
import os
from typing import List, Optional, Union, Dict, Any
import openai
import volcenginesdkarkruntime
from pydantic import BaseModel, Field, model_validator

class EmbeddingModelConfig(BaseModel):
    """Configuration for a specific embedding model"""
    model: Optional[str] = Field(default=None, description="Model name")
    api_key: Optional[str] = Field(default=None, description="API key")
    api_base: Optional[str] = Field(default=None, description="API base URL")
    dimension: Optional[int] = Field(default=None, description="Embedding dimension")
    batch_size: int = Field(default=32, description="Batch size for embedding generation")
    input: str = Field(default="multimodal", description="Input type: 'text' or 'multimodal'")
    backend: Optional[str] = Field(default="volcengine", description="Backend type: 'openai', 'volcengine', 'vikingdb'")
    version: Optional[str] = Field(default=None, description="Model version")
    ak: Optional[str] = Field(default=None, description="Access Key ID for VikingDB API")
    sk: Optional[str] = Field(default=None, description="Access Key Secretfor VikingDB API")
    region: Optional[str] = Field(default=None, description="Region for VikingDB API")
    host: Optional[str] = Field(default=None, description="Host for VikingDB API")

    @model_validator(mode='after')
    def validate_config(self):
        """Validate configuration completeness and consistency"""
        if not self.model:
            raise ValueError("Embedding model name is required")

        if not self.backend:
            raise ValueError("Embedding backend is required")

        if self.backend not in ["openai", "volcengine", "vikingdb"]:
            raise ValueError(
                f"Invalid embedding backend: '{self.backend}'. Must be one of: 'openai', 'volcengine', 'vikingdb'"
            )

        # Backend-specific validation
        if self.backend == "openai":
            if not self.api_key:
                raise ValueError("OpenAI backend requires 'api_key' to be set")

        elif self.backend == "volcengine":
            if not self.api_key:
                raise ValueError("Volcengine backend requires 'api_key' to be set")

        elif self.backend == "vikingdb":
            missing = []
            if not self.ak:
                missing.append("ak")
            if not self.sk:
                missing.append("sk")
            if not self.region:
                missing.append("region")

            if missing:
                raise ValueError(
                    f"VikingDB backend requires the following fields: {', '.join(missing)}"
                )

        return self


class EmbeddingConfig(BaseModel):
    """
    Embedding configuration, supports OpenAI or VolcEngine compatible APIs.

    Structure:
    - dense: Configuration for dense embedder
    - sparse: Configuration for sparse embedder
    - hybrid: Configuration for hybrid embedder (single model returning both)

    Environment variables are mapped to these configurations.
    """

    dense: Optional[EmbeddingModelConfig] = Field(default=None)
    sparse: Optional[EmbeddingModelConfig] = Field(default=None)
    hybrid: Optional[EmbeddingModelConfig] = Field(default=None)

    @model_validator(mode="before")
    @classmethod
    def apply_env_defaults(cls, data):
        if not isinstance(data, dict):
            return data

        config_sections = [
            ("dense", "OPENVIKING_EMBEDDING_DENSE_"),
            ("sparse", "OPENVIKING_EMBEDDING_SPARSE_"),
            ("hybrid", "OPENVIKING_EMBEDDING_HYBRID_")
        ]

        env_fields = {
            "model": str, "api_key": str, "api_base": str,
            "dimension": int, "batch_size": int,
            "input": str, "backend": str, "version": str,
            "ak": str, "sk": str, "region": str, "host": str
        }

        for section, prefix in config_sections:
            section_env_data = {}
            for field, field_type in env_fields.items():
                env_key = f"{prefix}{field.upper()}"
                val = os.getenv(env_key)
                if val is not None:
                    try:
                        section_env_data[field] = field_type(val)
                    except ValueError:
                        continue

            if section_env_data:
                if data.get(section) is None:
                    data[section] = {}

                if isinstance(data[section], dict):
                    for k, v in section_env_data.items():
                        if data[section].get(k) is None:
                            data[section][k] = v

        return data

    @model_validator(mode='after')
    def validate_config(self):
        """Validate configuration completeness and consistency"""
        if not self.dense and not self.sparse and not self.hybrid:
            raise ValueError(
                "At least one embedding configuration (dense, sparse, or hybrid) is required"
            )
        return self

    def _create_embedder(self, backend: str, embedder_type: str, config: EmbeddingModelConfig):
        """Factory method to create embedder instance based on backend and type.

        Args:
            backend: Backend type ('openai', 'volcengine', 'vikingdb')
            embedder_type: Embedder type ('dense', 'sparse', 'hybrid')
            config: EmbeddingModelConfig instance

        Returns:
            Embedder instance

        Raises:
            ValueError: If backend/type combination is not supported
        """
        from openviking.models.embedder import (
            OpenAIDenseEmbedder,
            VolcengineDenseEmbedder,
            VolcengineSparseEmbedder,
            VolcengineHybridEmbedder,
            VikingDBDenseEmbedder,
            VikingDBSparseEmbedder,
            VikingDBHybridEmbedder
        )

        # Factory registry: (backend, type) -> (embedder_class, param_builder)
        factory_registry = {
            ('openai', 'dense'): (
                OpenAIDenseEmbedder,
                lambda cfg: {
                    'model_name': cfg.model,
                    'api_key': cfg.api_key,
                    'api_base': cfg.api_base,
                    'dimension': cfg.dimension
                }
            ),
            ('volcengine', 'dense'): (
                VolcengineDenseEmbedder,
                lambda cfg: {
                    'model_name': cfg.model,
                    'api_key': cfg.api_key,
                    'api_base': cfg.api_base,
                    'dimension': cfg.dimension,
                    'input_type': cfg.input
                }
            ),
            ('volcengine', 'sparse'): (
                VolcengineSparseEmbedder,
                lambda cfg: {
                    'model_name': cfg.model,
                    'api_key': cfg.api_key,
                    'api_base': cfg.api_base
                }
            ),
            ('volcengine', 'hybrid'): (
                VolcengineHybridEmbedder,
                lambda cfg: {
                    'model_name': cfg.model,
                    'api_key': cfg.api_key,
                    'api_base': cfg.api_base,
                    'dimension': cfg.dimension,
                    'input_type': cfg.input
                }
            ),
            ('vikingdb', 'dense'): (
                VikingDBDenseEmbedder,
                lambda cfg: {
                    'model_name': cfg.model,
                    'model_version': cfg.version,
                    'ak': cfg.ak,
                    'sk': cfg.sk,
                    'region': cfg.region,
                    'host': cfg.host,
                    'dimension': cfg.dimension,
                    'input_type': cfg.input
                }
            ),
            ('vikingdb', 'sparse'): (
                VikingDBSparseEmbedder,
                lambda cfg: {
                    'model_name': cfg.model,
                    'model_version': cfg.version,
                    'ak': cfg.ak,
                    'sk': cfg.sk,
                    'region': cfg.region,
                    'host': cfg.host
                }
            ),
            ('vikingdb', 'hybrid'): (
                VikingDBHybridEmbedder,
                lambda cfg: {
                    'model_name': cfg.model,
                    'model_version': cfg.version,
                    'ak': cfg.ak,
                    'sk': cfg.sk,
                    'region': cfg.region,
                    'host': cfg.host,
                    'dimension': cfg.dimension,
                    'input_type': cfg.input
                }
            ),
        }

        key = (backend, embedder_type)
        if key not in factory_registry:
            raise ValueError(
                f"Unsupported combination: backend='{backend}', type='{embedder_type}'. "
                f"Supported combinations: {list(factory_registry.keys())}"
            )

        embedder_class, param_builder = factory_registry[key]
        params = param_builder(config)
        return embedder_class(**params)

    def get_embedder(self):
        """Get embedder instance based on configuration.

        Returns:
            Embedder instance (Dense, Sparse, Hybrid, or Composite)

        Raises:
            ValueError: If configuration is invalid or unsupported
        """
        from openviking.models.embedder import CompositeHybridEmbedder

        if self.hybrid:
            return self._create_embedder(self.hybrid.backend.lower(), 'hybrid', self.hybrid)

        if self.dense and self.sparse:
            dense_embedder = self._create_embedder(self.dense.backend.lower(), 'dense', self.dense)
            sparse_embedder = self._create_embedder(self.sparse.backend.lower(), 'sparse', self.sparse)
            return CompositeHybridEmbedder(dense_embedder, sparse_embedder)

        if self.dense:
            return self._create_embedder(self.dense.backend.lower(), 'dense', self.dense)

        raise ValueError("No embedding configuration found (dense, sparse, or hybrid)")

    @property
    def dimension(self) -> int:
        """Get dimension from active config."""
        return self.get_dimension()

    def get_dimension(self) -> int:
        """Helper to get dimension from active config"""
        if self.hybrid:
            return self.hybrid.dimension or 2048
        if self.dense:
            return self.dense.dimension or 2048
        return 2048

