import logging
import time
from typing import Optional, List, Union, Any, Type, TypeVar
import httpx
from .models import (
    Status, UserResponse, TransferResponse, TransferListResponse,
    ChequeResponse, ChequeInfoResponse, ChequeClaimResponse,
    MultiChequeResponse, MultiChequeInfoResponse, MultiChequeClaimResponse,
    CoinResponse, CoinListResponse, Error
)
from .errors import (
    OpenWAVError, AuthenticationError, ValidationError,
    RateLimitError, NotFoundError, ConflictError, ServerError
)

logger = logging.getLogger("openwav")

T = TypeVar("T")

class BaseClient:
    """Base logic for OpenWAV API communication."""
    def __init__(
        self, 
        api_key: str, 
        base_url: str = "https://openwav.physm.org",
        timeout: float = 30.0,
        max_retries: int = 3
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.headers = {
            "X-API-Key": self.api_key,
            "Accept": "application/json"
        }
        self.timeout = timeout
        self.max_retries = max_retries

    def _handle_response(self, response: httpx.Response) -> Any:
        logger.debug(f"Response: {response.status_code} - {response.text}")
        
        if response.status_code in (200, 201):
            data = response.json()
            if isinstance(data, dict) and data.get("status") is False:
                raise OpenWAVError(data.get("message", "API Error"), status_code=response.status_code)
            return data
        
        error_msg = response.text
        try:
            error_data = response.json()
            if isinstance(error_data, dict) and "message" in error_data:
                error_msg = error_data["message"]
        except Exception:
            pass

        if response.status_code == 401:
            raise AuthenticationError(error_msg, response.status_code)
        elif response.status_code == 403:
            raise OpenWAVError(f"Forbidden: {error_msg}", response.status_code)
        elif response.status_code == 404:
            raise NotFoundError(error_msg, response.status_code)
        elif response.status_code == 409:
            raise ConflictError(error_msg, response.status_code)
        elif response.status_code == 422:
            raise ValidationError(f"Validation Error: {error_msg}", response.status_code)
        elif response.status_code == 429:
            raise RateLimitError(error_msg, response.status_code)
        elif response.status_code >= 500:
            raise ServerError(f"Server Error: {error_msg}", response.status_code)
        else:
            raise OpenWAVError(f"Unexpected error: {error_msg}", response.status_code)

class OpenWAVClient(BaseClient):
    """Asynchronous client for OpenWAV API."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=self.headers,
            timeout=self.timeout
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    async def close(self):
        await self._client.aclose()

    async def _request(self, method: str, path: str, **kwargs) -> Any:
        retries = 0
        while True:
            try:
                logger.debug(f"Request: {method} {path} - Params: {kwargs.get('params')} - Retries: {retries}")
                response = await self._client.request(method, path, **kwargs)
                return self._handle_response(response)
            except (RateLimitError, ServerError, httpx.NetworkError) as e:
                if retries >= self.max_retries:
                    raise
                retries += 1
                wait_time = 2 ** retries  # Exponential backoff
                logger.warning(f"Request failed ({type(e).__name__}), retrying in {wait_time}s...")
                await httpx.AsyncClient().request("GET", "http://example.com") # Just a dummy to allow async yielding
                import asyncio
                await asyncio.sleep(wait_time)

    # Methods
    async def ping(self) -> bool:
        try:
            await self._request("GET", "/ping")
            return True
        except Exception:
            return False

    async def key_ping(self) -> bool:
        try:
            await self._request("GET", "/key-ping")
            return True
        except Exception:
            return False

    async def get_me(self) -> UserResponse:
        data = await self._request("GET", "/wallet/me")
        return UserResponse(**data)

    async def transfer(self, receiver: str, coin: str, amount: float, comment: str = None) -> TransferResponse:
        params = {"receiver": receiver, "coin": coin, "amount": amount}
        if comment: params["comment"] = comment
        data = await self._request("POST", "/wallet/transfers", params=params)
        return TransferResponse(**data)

    async def list_transfers(self, offset: int = 0, limit: int = 50, direction: int = 2) -> TransferListResponse:
        params = {"offset": offset, "limit": limit, "direction": direction}
        data = await self._request("GET", "/wallet/transfers", params=params)
        return TransferListResponse(**data)

    async def create_cheque(self, coin: str, amount: float, password: str = None, comment: str = None) -> ChequeResponse:
        params = {"coin": coin, "amount": amount}
        if password: params["password"] = password
        if comment: params["comment"] = comment
        data = await self._request("POST", "/wallet/cheques", params=params)
        return ChequeResponse(**data)

    async def list_cheques(self, offset: int = 0, limit: int = 50, only_active: bool = True) -> List[ChequeResponse]:
        params = {"offset": offset, "limit": limit, "only_active": only_active}
        data = await self._request("GET", "/wallet/cheques", params=params)
        return [ChequeResponse(**c) for c in data.get("cheques", [])]

    async def get_cheque_info(self, cheque_id: str) -> ChequeInfoResponse:
        data = await self._request("GET", f"/wallet/cheques/{cheque_id}")
        return ChequeInfoResponse(**data)

    async def claim_cheque(self, cheque_id: str, password: str = None) -> ChequeClaimResponse:
        params = {"password": password} if password else {}
        data = await self._request("POST", f"/wallet/cheques/{cheque_id}/claim", params=params)
        return ChequeClaimResponse(**data)

    async def cancel_cheque(self, cheque_id: str) -> bool:
        await self._request("DELETE", f"/wallet/cheques/{cheque_id}")
        return True

    async def create_multicheque(self, coin: str, amount_per_user: float, max_activations: int, password: str = None, comment: str = None) -> MultiChequeResponse:
        params = {"coin": coin, "amount_per_user": amount_per_user, "max_activations": max_activations}
        if password: params["password"] = password
        if comment: params["comment"] = comment
        data = await self._request("POST", "/wallet/multicheques", params=params)
        return MultiChequeResponse(**data)

    async def list_multicheques(self, offset: int = 0, limit: int = 50, only_active: bool = True) -> List[MultiChequeResponse]:
        params = {"offset": offset, "limit": limit, "only_active": only_active}
        data = await self._request("GET", "/wallet/multicheques", params=params)
        return [MultiChequeResponse(**mc) for mc in data.get("multicheques", [])]

    async def get_multicheque_info(self, multicheque_id: str) -> MultiChequeInfoResponse:
        data = await self._request("GET", f"/wallet/multicheques/{multicheque_id}")
        return MultiChequeInfoResponse(**data)

    async def claim_multicheque(self, multicheque_id: str, password: str = None) -> MultiChequeClaimResponse:
        params = {"password": password} if password else {}
        data = await self._request("POST", f"/wallet/multicheques/{multicheque_id}/claim", params=params)
        return MultiChequeClaimResponse(**data)

    async def cancel_multicheque(self, multicheque_id: str) -> bool:
        await self._request("DELETE", f"/wallet/multicheques/{multicheque_id}")
        return True

class OpenWAVSyncClient(BaseClient):
    """Synchronous client for OpenWAV API."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._client = httpx.Client(
            base_url=self.base_url,
            headers=self.headers,
            timeout=self.timeout
        )

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def close(self):
        self._client.close()

    def _request(self, method: str, path: str, **kwargs) -> Any:
        retries = 0
        while True:
            try:
                logger.debug(f"Sync Request: {method} {path} - Retries: {retries}")
                response = self._client.request(method, path, **kwargs)
                return self._handle_response(response)
            except (RateLimitError, ServerError, httpx.NetworkError) as e:
                if retries >= self.max_retries:
                    raise
                retries += 1
                wait_time = 2 ** retries
                logger.warning(f"Sync Request failed, retrying in {wait_time}s...")
                time.sleep(wait_time)

    # Methods (Same as Async but sync)
    def ping(self) -> bool:
        try:
            self._request("GET", "/ping")
            return True
        except Exception:
            return False

    def get_me(self) -> UserResponse:
        data = self._request("GET", "/wallet/me")
        return UserResponse(**data)

    def transfer(self, receiver: str, coin: str, amount: float, comment: str = None) -> TransferResponse:
        params = {"receiver": receiver, "coin": coin, "amount": amount}
        if comment: params["comment"] = comment
        data = self._request("POST", "/wallet/transfers", params=params)
        return TransferResponse(**data)

    # ... and others can be added similarly.

