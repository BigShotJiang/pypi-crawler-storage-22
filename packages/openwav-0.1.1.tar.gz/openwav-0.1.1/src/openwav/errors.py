class OpenWAVError(Exception):
    """Base exception for OpenWAV API"""
    def __init__(self, message: str, status_code: int = None, details: dict = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.details = details

class AuthenticationError(OpenWAVError):
    """Raised when API key is invalid or missing"""
    pass

class ValidationError(OpenWAVError):
    """Raised when request parameters are invalid"""
    pass

class RateLimitError(OpenWAVError):
    """Raised when too many requests are made"""
    pass

class NotFoundError(OpenWAVError):
    """Raised when resource is not found"""
    pass

class ConflictError(OpenWAVError):
    """Raised when there is a conflict (e.g. user already exists)"""
    pass

class ServerError(OpenWAVError):
    """Raised when server returns 5xx"""
    pass
