from datetime import datetime
from typing import List, Optional, Union
from pydantic import BaseModel, Field

class Status(BaseModel):
    status: bool = True

class Error(BaseModel):
    status: bool = False
    message: str = "Some error occurred."

class BalanceInUserResponse(BaseModel):
    coin_id: int
    coin_symbol: str
    coin_decimals: int
    amount_raw: int
    amount: float

class UserResponse(BaseModel):
    id: int
    nickname: str
    mention: Optional[str] = None
    full_name: str
    is_active: bool
    is_premium: bool
    admin_lvl: int = Field(ge=0, le=2)
    has_access: bool
    api_key: str
    balances: List[BalanceInUserResponse] = []

class TransferResponse(BaseModel):
    unique_id: str
    sender_id: int
    sender_nickname: str
    receiver_id: int
    receiver_nickname: str
    coin_id: int
    coin_symbol: str
    amount_raw: int
    amount: float
    comment: Optional[str] = Field(None, max_length=256)
    created_at: datetime

class TransferListResponse(BaseModel):
    transfers: List[TransferResponse]
    total: int
    offset: int
    limit: int

class ChequeResponse(BaseModel):
    unique_id: str
    creator_id: int
    creator_nickname: str
    coin_id: int
    coin_symbol: str
    amount_raw: int
    amount: float
    has_password: bool
    comment: Optional[str] = Field(None, max_length=256)
    is_activated: bool
    activator_id: Optional[int] = None
    activator_nickname: Optional[str] = None
    created_at: datetime
    activated_at: Optional[datetime] = None

class ChequeInfoResponse(BaseModel):
    unique_id: str
    coin_id: int
    coin_symbol: str
    amount_raw: int
    amount: float
    has_password: bool
    comment: Optional[str] = Field(None, max_length=256)
    is_activated: bool

class ChequeClaimResponse(BaseModel):
    unique_id: str
    coin_id: int
    coin_symbol: str
    amount_raw: int
    amount: float
    comment: Optional[str] = Field(None, max_length=256)
    claimed_at: datetime

class MultiChequeResponse(BaseModel):
    unique_id: str
    creator_id: int
    creator_nickname: str
    coin_id: int
    coin_symbol: str
    amount_per_user_raw: int
    amount_per_user: float
    total_amount_raw: int
    total_amount: float
    max_activations: int = Field(ge=1, le=1000)
    current_activations: int
    remaining_activations: int
    has_password: bool
    comment: Optional[str] = Field(None, max_length=256)
    is_fully_activated: bool
    is_cancelled: bool
    created_at: datetime

class MultiChequeInfoResponse(BaseModel):
    unique_id: str
    coin_id: int
    coin_symbol: str
    amount_per_user_raw: int
    amount_per_user: float
    max_activations: int = Field(ge=1, le=1000)
    current_activations: int
    remaining_activations: int
    has_password: bool
    comment: Optional[str] = Field(None, max_length=256)
    is_fully_activated: bool

class MultiChequeClaimResponse(BaseModel):
    unique_id: str
    coin_id: int
    coin_symbol: str
    amount_raw: int
    amount: float
    comment: Optional[str] = Field(None, max_length=250)
    remaining_activations: int

class CoinResponse(BaseModel):
    id: int
    name: str = Field(min_length=1, max_length=32)
    symbol: str = Field(min_length=1, max_length=8)
    description: Optional[str] = Field(None, max_length=256)
    url: Optional[str] = Field(None, max_length=128)
    decimals: int = Field(ge=0, le=8)
    total_supply_raw: int
    is_active: bool
    created_at: datetime
    total_supply: float

class CoinListResponse(BaseModel):
    coins: List[CoinResponse]
    total: int
    offset: int
    limit: int

