from .dashboard import (  # noqa
    register_dashboard_chart,
    register_dashboard_template,
    unregister_dashboard_chart,
    unregister_dashboard_template,
)
