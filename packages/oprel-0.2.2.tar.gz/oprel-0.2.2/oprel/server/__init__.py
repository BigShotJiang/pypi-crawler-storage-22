# Server mode for persistent model caching
from oprel.server.daemon import app

__all__ = ["app"]
