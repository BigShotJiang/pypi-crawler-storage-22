"""Unit tests for OpsPilot."""
