# Opteryx

Opteryx-Core is fork of [Opteryx](https://github.com/mabel-dev/opteryx) with a reduced API and configuration surface. It is the engine used by the cloud version of [Opteryx](https://opteryx.app).

Install:
```bash
pip install opteryx-core
```

Docs: https://docs.opteryx.app/  •  Source: https://github.com/mabel-dev/opteryx-core  •  License: Apache-2.0
