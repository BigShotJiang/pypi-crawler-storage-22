"""OptGate — QAOA shot optimization via temporal scheduling. Part of the QubitBoost platform."""
__version__ = "0.0.1"
