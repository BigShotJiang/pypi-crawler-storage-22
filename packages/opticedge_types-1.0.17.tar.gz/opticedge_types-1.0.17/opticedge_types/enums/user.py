from enum import IntEnum

class CollectorType(IntEnum):
    NON_MEMBER = -1
    ELITE = 0
    ROOKIE = 1
    FREE = 2
