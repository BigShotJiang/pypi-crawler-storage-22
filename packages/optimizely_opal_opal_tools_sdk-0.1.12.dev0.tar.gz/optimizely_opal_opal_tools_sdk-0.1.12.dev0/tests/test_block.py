#!/usr/bin/env python3
"""Tests for Block components."""

from opal_tools_sdk import Block, BlockResponse


def test_block_heading():
    """Test creating a Block.Heading with children"""
    heading = Block.Heading(children="Test Heading")
    assert heading.field_type == "Block.Heading"

    response = BlockResponse(content=Block.Document(children=heading))
    data = response.to_dict()
    assert data == {
        "content": {
            "$type": "Block.Document",
            "children": {"$type": "Block.Heading", "children": "Test Heading"},
        }
    }


def test_block_text():
    """Test creating a Block.Text with children"""
    text = Block.Text(children="Test text content")
    assert text.field_type == "Block.Text"

    response = BlockResponse(content=Block.Document(children=text))
    data = response.to_dict()
    assert data == {
        "content": {
            "$type": "Block.Document",
            "children": {"$type": "Block.Text", "children": "Test text content"},
        }
    }


def test_block_heading_with_props():
    """Test Block.Heading with additional properties"""
    heading = Block.Heading(children="Styled Heading", level="2", fontSize="md", fontWeight="600")

    response = BlockResponse(content=Block.Document(children=heading))
    data = response.to_dict()
    assert data == {
        "content": {
            "$type": "Block.Document",
            "children": {
                "$type": "Block.Heading",
                "children": "Styled Heading",
                "level": "2",
                "fontSize": "md",
                "fontWeight": "600",
            },
        }
    }


def test_block_group():
    """Test creating a Block.Group with children array"""
    group = Block.Group(
        flexDirection="column",
        gap="16",
        children=[
            Block.Text(children="First item"),
            Block.Text(children="Second item"),
        ],
    )

    response = BlockResponse(content=Block.Document(children=group))
    data = response.to_dict()
    assert data == {
        "content": {
            "$type": "Block.Document",
            "children": {
                "$type": "Block.Group",
                "flexDirection": "column",
                "gap": "16",
                "children": [
                    {"$type": "Block.Text", "children": "First item"},
                    {"$type": "Block.Text", "children": "Second item"},
                ],
            },
        }
    }


def test_block_document():
    """Test creating a Block.Document"""
    doc = Block.Document(
        children=[
            Block.Heading(children="Title", level="2"),
            Block.Text(children="Description"),
        ]
    )

    response = BlockResponse(content=doc)
    data = response.to_dict()
    assert data == {
        "content": {
            "$type": "Block.Document",
            "children": [
                {"$type": "Block.Heading", "children": "Title", "level": "2"},
                {"$type": "Block.Text", "children": "Description"},
            ],
        }
    }
