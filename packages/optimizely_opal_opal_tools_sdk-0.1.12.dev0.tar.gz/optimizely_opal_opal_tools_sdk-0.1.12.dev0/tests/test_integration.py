#!/usr/bin/env python3
"""Tests for FastAPI integration with the @tool decorator."""

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from opal_tools_sdk import Block, BlockResponse, ToolsService, _registry, tool
from pydantic import BaseModel, Field


class SimpleParams(BaseModel):
    """Simple tool parameters."""

    name: str = Field(description="The name to greet")


class BlockParams(BaseModel):
    """Block tool parameters."""

    message: str = Field(description="Message to display")


@pytest.fixture(autouse=True)
def clear_registry():
    """Clear the global registry before each test."""
    _registry.services.clear()
    yield
    _registry.services.clear()


def test_simple_tool_endpoint():
    """Test that a simple tool creates a working endpoint"""
    app = FastAPI()
    _ = ToolsService(app)  # noqa: F841

    @tool(name="greet", description="Greet a user")
    async def greet_tool(params: SimpleParams, environment: dict) -> str:
        """Greet tool."""
        return f"Hello, {params.name}!"

    client = TestClient(app)

    # Call the endpoint (returns result directly, not wrapped in response envelope)
    response = client.post("/tools/greet", json={"name": "Alice"})

    assert response.status_code == 200
    # Verify correct content-type header for regular tools (application/json)
    assert response.headers["content-type"] == "application/json"
    assert response.json() == "Hello, Alice!"


def test_block_tool_endpoint():
    """Test that a block tool endpoint correctly serializes all fields"""
    app = FastAPI()
    _ = ToolsService(app)  # noqa: F841

    @tool(name="create_task", description="Create a task", type="block")
    async def create_task(params: SimpleParams, environment: dict) -> BlockResponse:
        """Create task tool."""
        return BlockResponse(
            content=Block.Document(children=Block.Text(children=f"Created task: {params.name}")),
            data={"created_at": "2024-01-01T00:00:00Z"},
            artifact={"type": "task", "id": "task-123", "data": {"name": params.name}},
            rollback={
                "type": "endpoint",
                "config": {"endpoint": "/api/tasks/task-123", "method": "DELETE"},
                "label": "Delete Task",
            },
            error=None,
        )

    client = TestClient(app)

    # Call the endpoint
    response = client.post("/tools/create_task", json={"name": "My Task"})

    assert response.status_code == 200
    assert response.headers["content-type"] == "application/vnd.opal.block+json"
    assert response.json() == {
        "content": {
            "$type": "Block.Document",
            "children": {"$type": "Block.Text", "children": "Created task: My Task"},
        },
        "data": {"created_at": "2024-01-01T00:00:00Z"},
        "artifact": {"type": "task", "id": "task-123", "data": {"name": "My Task"}},
        "rollback": {
            "type": "endpoint",
            "config": {"endpoint": "/api/tasks/task-123", "method": "DELETE"},
            "label": "Delete Task",
        },
    }


def test_environment_parameter_passed():
    """Test that environment parameter is correctly passed to the tool"""
    app = FastAPI()
    _ = ToolsService(app)  # noqa: F841

    @tool(name="check_env", description="Check environment")
    async def check_env(params: SimpleParams, environment: dict) -> dict:
        """Check environment tool."""
        return {
            "has_environment": environment is not None,
            "param_name": params.name,
        }

    client = TestClient(app)

    # Call the endpoint
    response = client.post("/tools/check_env", json={"name": "Test"})

    assert response.status_code == 200
    assert response.json() == {
        "has_environment": True,
        "param_name": "Test",
    }


def test_invalid_parameters():
    """Test that invalid parameters return proper error"""
    app = FastAPI()
    _ = ToolsService(app)  # noqa: F841

    @tool(name="validate_params", description="Validate parameters")
    async def validate_params(params: SimpleParams, environment: dict) -> str:
        """Validate params tool."""
        return f"Valid: {params.name}"

    client = TestClient(app)

    # Call with missing required parameter
    response = client.post("/tools/validate_params", json={})

    assert response.status_code == 400  # Validation error (Pydantic ValidationError)


def test_multiple_tools_same_service():
    """Test that multiple tools can be registered on the same service"""
    app = FastAPI()
    _ = ToolsService(app)  # noqa: F841

    @tool(name="tool_one", description="First tool")
    async def tool_one(params: SimpleParams, environment: dict) -> str:
        """Tool one."""
        return "Tool 1"

    @tool(name="tool_two", description="Second tool")
    async def tool_two(params: SimpleParams, environment: dict) -> str:
        """Tool two."""
        return "Tool 2"

    client = TestClient(app)

    # Call both endpoints
    response1 = client.post("/tools/tool_one", json={"name": "Test"})
    response2 = client.post("/tools/tool_two", json={"name": "Test"})

    assert response1.status_code == 200
    assert response2.status_code == 200
    assert response1.json() == "Tool 1"
    assert response2.json() == "Tool 2"


def test_block_tool_without_block_response_throws_error():
    """Test that a block tool that doesn't return BlockResponse throws an error"""
    app = FastAPI()
    _ = ToolsService(app)  # noqa: F841

    @tool(name="invalid_block", description="Block tool that returns wrong type", type="block")
    async def invalid_block(params: SimpleParams, environment: dict) -> str:
        """Invalid block tool that returns string instead of BlockResponse."""
        return f"This should fail: {params.name}"

    client = TestClient(app)

    # Call the endpoint - should fail because it doesn't return BlockResponse
    response = client.post("/tools/invalid_block", json={"name": "Test"})

    # Should return 500 error because block tools must return BlockResponse
    assert response.status_code == 500
    assert "must return a BlockResponse object" in response.json()["detail"]
