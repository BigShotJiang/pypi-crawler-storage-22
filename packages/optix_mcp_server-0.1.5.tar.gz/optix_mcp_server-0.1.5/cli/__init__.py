"""Optix CLI module."""

__version__ = "0.1.5"
