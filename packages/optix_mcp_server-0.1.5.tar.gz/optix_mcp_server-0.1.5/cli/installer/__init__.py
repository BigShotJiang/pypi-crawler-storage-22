"""Optix installation wizard module."""

from cli.installer.wizard import InstallationWizard

__all__ = ["InstallationWizard"]
