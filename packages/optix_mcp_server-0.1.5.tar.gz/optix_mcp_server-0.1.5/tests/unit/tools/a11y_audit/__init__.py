"""Unit tests for accessibility audit tool."""
