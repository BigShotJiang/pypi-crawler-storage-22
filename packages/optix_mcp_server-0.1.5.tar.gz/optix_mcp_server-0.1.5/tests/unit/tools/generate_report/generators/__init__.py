"""Test package for report generators."""
