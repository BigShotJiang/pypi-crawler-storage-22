"""Unit tests for view_history tool."""
