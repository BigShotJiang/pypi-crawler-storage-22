"""DevOps Audit Tool - Multi-step infrastructure analysis workflow.

Provides guided analysis of:
- Dockerfile security and best practices
- GitHub Actions CI/CD configuration
- Node.js dependency management

Follows the WorkflowTool pattern with 4-step progressive analysis:
1. Docker Infrastructure Audit
2. CI/CD Pipeline Audit
3. Dependency Security Audit
4. Cross-Domain Analysis & Report Generation

Supports specialized lens variations:
- security: Focus on secrets, supply chain, CVEs, OWASP
- performance: Focus on build times, caching, runner costs
- compliance: Focus on SOC2, PCI-DSS, audit trails
- multicloud: Focus on AWS/Azure/GCP patterns, IaC
- startup: Focus on quick wins, pragmatic defaults
- comprehensive: All checks (default)
"""

from tools.devops_audit.domains import (
    DevOpsCategory,
    DevOpsLens,
    DevOpsStepDomain,
    DiscoveredArtifacts,
)
from tools.devops_audit.finding import ConsolidatedDevOpsFindings, DevOpsFinding
from tools.devops_audit.guidance import TOTAL_STEPS, DevOpsStepGuidance, get_step_guidance
from tools.devops_audit.lenses import (
    BaseLens,
    LensConfig,
    LensRule,
    get_lens,
    get_lens_config,
    list_available_lenses,
)
from tools.devops_audit.report import DevOpsAuditReportGenerator
from tools.devops_audit.severity import Severity
from tools.devops_audit.tool import DevOpsAuditTool

__all__ = [
    "DevOpsAuditTool",
    "DevOpsCategory",
    "DevOpsLens",
    "DevOpsStepDomain",
    "DevOpsFinding",
    "ConsolidatedDevOpsFindings",
    "DiscoveredArtifacts",
    "Severity",
    "DevOpsStepGuidance",
    "DevOpsAuditReportGenerator",
    "get_step_guidance",
    "TOTAL_STEPS",
    "BaseLens",
    "LensConfig",
    "LensRule",
    "get_lens",
    "get_lens_config",
    "list_available_lenses",
]
