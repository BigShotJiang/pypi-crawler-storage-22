"""View History tool for generating static HTML audit history viewer.

This module provides the view_history MCP tool that generates a
self-contained HTML file and opens it in the browser.

Public Exports:
    ViewHistoryTool: MCP tool for viewing audit history in browser
"""

from tools.view_history.tool import ViewHistoryTool

__all__ = ["ViewHistoryTool"]
