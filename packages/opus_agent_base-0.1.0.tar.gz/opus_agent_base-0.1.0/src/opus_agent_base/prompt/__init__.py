"""Prompt and instructions management."""
