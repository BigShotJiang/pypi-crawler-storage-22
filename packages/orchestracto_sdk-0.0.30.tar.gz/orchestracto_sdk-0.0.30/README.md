If you introduce some incompatible changes to the SDK, you need to update the base runtime image.
1. `docker build . -f simple_runtime.Dockerfile --platform linux/amd64 -t cr.eu-north1.nebius.cloud/e00faee7vas5hpsh3s/orchestracto/sdk-simple-runtime:<NEW_VERSION> --push`
2. Update it in `orc_sdk/constants.py` file (`BASE_IMAGE`)


### Building new version
- update version in https://github.com/tractoai/farm/blob/main/orchestracto/sdk/orc_sdk/__init__.py#L1
- commit and push
- run action https://github.com/tractoai/farm/actions/workflows/orc-sdk-pypi.yaml

You will find the new version on PyPi: https://pypi.org/project/orchestracto-sdk/
