"""
Orchestrador v3 - Pipeline de Jobs com SQLite e Auto-Recovery

Um orquestrador de tarefas para CLIs de código (Claude Code, Codex CLI).
"""

__version__ = "3.0.0"
__author__ = "Rafael Oliveira"

from .executor import (
    create_pipeline,
    execute_job,
    retry_job,
    resume_job,
    recover_interrupted_jobs,
    list_jobs,
    list_pipelines,
)
from .database import init_database

__all__ = [
    "create_pipeline",
    "execute_job", 
    "retry_job",
    "resume_job",
    "recover_interrupted_jobs",
    "list_jobs",
    "list_pipelines",
    "init_database",
    "__version__",
]
