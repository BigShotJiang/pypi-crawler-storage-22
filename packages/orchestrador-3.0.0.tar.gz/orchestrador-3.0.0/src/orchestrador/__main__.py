"""
Permite executar o módulo diretamente:
    python -m orchestrador        # CLI
    python -m orchestrador.server # Servidor direto
"""
from .cli import main

if __name__ == "__main__":
    main()
