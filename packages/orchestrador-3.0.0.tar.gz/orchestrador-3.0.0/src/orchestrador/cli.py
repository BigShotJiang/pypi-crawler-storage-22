#!/usr/bin/env python3
"""
Orchestrador CLI - Gerencia o servidor e jobs
"""

import argparse
import sys
import os
import signal
import subprocess
import time
from pathlib import Path

def get_pid_file():
    return Path(os.getenv("ORCHESTRADOR_PID_FILE", "/tmp/orchestrador.pid"))

def get_log_file():
    return Path(os.getenv("ORCHESTRADOR_LOG_FILE", "/tmp/orchestrador.log"))

def is_running():
    """Verifica se o orchestrador está rodando"""
    pid_file = get_pid_file()
    if not pid_file.exists():
        return False, None
    
    try:
        pid = int(pid_file.read_text().strip())
        # Verifica se processo existe
        os.kill(pid, 0)
        return True, pid
    except (ValueError, ProcessLookupError, PermissionError):
        pid_file.unlink(missing_ok=True)
        return False, None

def cmd_start(args):
    """Inicia o servidor"""
    running, pid = is_running()
    if running:
        print(f"Orchestrador já está rodando (PID {pid})")
        return 1
    
    # Importa e inicia o servidor
    print("Iniciando Orchestrador...")
    
    # Executa em background
    log_file = get_log_file()
    pid_file = get_pid_file()
    
    # Usa subprocess para rodar em background
    cmd = [sys.executable, "-m", "orchestrador.server"]
    
    with open(log_file, "w") as log:
        proc = subprocess.Popen(
            cmd,
            stdout=log,
            stderr=log,
            start_new_session=True,
        )
    
    # Salva PID
    pid_file.write_text(str(proc.pid))
    
    # Aguarda um pouco e verifica se iniciou
    time.sleep(2)
    
    running, _ = is_running()
    if running:
        port = os.getenv("ORCHESTRADOR_PORT", "8765")
        print(f"✅ Orchestrador iniciado!")
        print(f"   PID: {proc.pid}")
        print(f"   URL: http://127.0.0.1:{port}")
        print(f"   Log: {log_file}")
        return 0
    else:
        print("❌ Falha ao iniciar. Verifique o log:")
        print(f"   cat {log_file}")
        return 1

def cmd_stop(args):
    """Para o servidor"""
    running, pid = is_running()
    if not running:
        print("Orchestrador não está rodando")
        return 0
    
    print(f"Parando Orchestrador (PID {pid})...")
    try:
        os.kill(pid, signal.SIGTERM)
        time.sleep(1)
        
        # Verifica se parou
        try:
            os.kill(pid, 0)
            # Ainda rodando, força
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        
        get_pid_file().unlink(missing_ok=True)
        print("✅ Orchestrador parado")
        return 0
    except Exception as e:
        print(f"❌ Erro ao parar: {e}")
        return 1

def cmd_restart(args):
    """Reinicia o servidor"""
    cmd_stop(args)
    time.sleep(1)
    return cmd_start(args)

def cmd_status(args):
    """Mostra status do servidor"""
    import requests
    
    running, pid = is_running()
    if not running:
        print("❌ Orchestrador não está rodando")
        return 1
    
    port = os.getenv("ORCHESTRADOR_PORT", "8765")
    url = f"http://127.0.0.1:{port}"
    
    print(f"✅ Orchestrador rodando (PID {pid})")
    print(f"   URL: {url}")
    
    try:
        # Busca pipelines ativos
        resp = requests.get(f"{url}/pipelines", timeout=5)
        pipelines = resp.json()
        
        running_pipelines = [p for p in pipelines if p["status"] == "running"]
        completed = [p for p in pipelines if p["status"] == "completed"]
        failed = [p for p in pipelines if p["status"] == "failed"]
        
        print(f"\n📊 Pipelines:")
        print(f"   Rodando:    {len(running_pipelines)}")
        print(f"   Completos:  {len(completed)}")
        print(f"   Falhos:     {len(failed)}")
        
        if running_pipelines:
            print(f"\n🔄 Em execução:")
            for p in running_pipelines[:5]:
                print(f"   - {p['id']}: job {p['current_job_index']+1}/{len(p['jobs'])}")
        
    except Exception as e:
        print(f"\n⚠️  Não foi possível conectar à API: {e}")
    
    return 0

def cmd_logs(args):
    """Mostra logs do servidor"""
    log_file = get_log_file()
    
    if not log_file.exists():
        print("Nenhum log encontrado")
        return 1
    
    lines = args.lines or 50
    
    if args.follow:
        os.system(f"tail -f {log_file}")
    else:
        os.system(f"tail -n {lines} {log_file}")
    
    return 0

def cmd_recover(args):
    """Recupera jobs interrompidos"""
    import requests
    
    port = os.getenv("ORCHESTRADOR_PORT", "8765")
    url = f"http://127.0.0.1:{port}/recover"
    
    try:
        params = {"auto_retry": "true" if args.auto_retry else "false"}
        resp = requests.post(url, params=params, timeout=30)
        data = resp.json()
        
        print(f"🔧 Recovery executado:")
        print(f"   Jobs encontrados: {data.get('found', 0)}")
        print(f"   Retentados:       {data.get('retried', 0)}")
        print(f"   Marcados falho:   {data.get('marked_failed', 0)}")
        
        if data.get("jobs"):
            print(f"\n📋 Jobs processados:")
            for job in data["jobs"]:
                print(f"   - {job['id']}: {job['action']}")
        
        return 0
    except Exception as e:
        print(f"❌ Erro: {e}")
        return 1

def cmd_install_skill(args):
    """Instala a skill do orchestrador no OpenClaw"""
    import shutil
    import json
    
    # Diretório de destino
    openclaw_dir = Path.home() / ".openclaw"
    skills_dir = openclaw_dir / "skills" / "orchestrator-client"
    
    # Diretório fonte (dentro do pacote)
    import orchestrador
    pkg_dir = Path(orchestrador.__file__).parent
    skill_src = pkg_dir / "openclaw-skill" / "SKILL.md"
    
    if not skill_src.exists():
        print(f"❌ Skill não encontrada no pacote: {skill_src}")
        return 1
    
    # Cria diretório se não existe
    skills_dir.mkdir(parents=True, exist_ok=True)
    
    # Copia skill
    dest = skills_dir / "SKILL.md"
    shutil.copy2(skill_src, dest)
    
    print(f"✅ Skill copiada para: {dest}")
    
    # Atualiza openclaw.json automaticamente
    openclaw_config = openclaw_dir / "openclaw.json"
    config_updated = False
    
    if openclaw_config.exists():
        try:
            config = json.loads(openclaw_config.read_text())
            
            # Garante que skills.allowBundled existe
            if "skills" not in config:
                config["skills"] = {}
            if "allowBundled" not in config["skills"]:
                config["skills"]["allowBundled"] = []
            
            # Adiciona orchestrator-client se não tiver
            if "orchestrator-client" not in config["skills"]["allowBundled"]:
                config["skills"]["allowBundled"].append("orchestrator-client")
                openclaw_config.write_text(json.dumps(config, indent=2))
                config_updated = True
                print(f"✅ Skill ativada no openclaw.json")
            else:
                print(f"ℹ️  Skill já estava ativada no openclaw.json")
                
        except Exception as e:
            print(f"⚠️  Não foi possível atualizar openclaw.json: {e}")
            print(f"   Adicione manualmente: \"skills\": {{\"allowBundled\": [\"orchestrator-client\"]}}")
    else:
        print(f"⚠️  openclaw.json não encontrado em {openclaw_dir}")
        print(f"   Execute 'openclaw onboard' primeiro ou crie o arquivo manualmente")
    
    print(f"\n🎉 Instalação concluída!")
    print(f"   Reinicie o OpenClaw para carregar a skill")
    
    return 0

def main():
    parser = argparse.ArgumentParser(
        prog="orchestrador",
        description="Orchestrador v3 - Gerenciador de Pipelines de Jobs"
    )
    parser.add_argument("--version", action="version", version="%(prog)s 3.0.0")
    
    subparsers = parser.add_subparsers(dest="command", help="Comandos disponíveis")
    
    # start
    p_start = subparsers.add_parser("start", help="Inicia o servidor")
    p_start.set_defaults(func=cmd_start)
    
    # stop
    p_stop = subparsers.add_parser("stop", help="Para o servidor")
    p_stop.set_defaults(func=cmd_stop)
    
    # restart
    p_restart = subparsers.add_parser("restart", help="Reinicia o servidor")
    p_restart.set_defaults(func=cmd_restart)
    
    # status
    p_status = subparsers.add_parser("status", help="Mostra status do servidor")
    p_status.set_defaults(func=cmd_status)
    
    # logs
    p_logs = subparsers.add_parser("logs", help="Mostra logs do servidor")
    p_logs.add_argument("-f", "--follow", action="store_true", help="Segue o log em tempo real")
    p_logs.add_argument("-n", "--lines", type=int, default=50, help="Número de linhas")
    p_logs.set_defaults(func=cmd_logs)
    
    # recover
    p_recover = subparsers.add_parser("recover", help="Recupera jobs interrompidos")
    p_recover.add_argument("--auto-retry", action="store_true", help="Reexecuta jobs automaticamente")
    p_recover.set_defaults(func=cmd_recover)
    
    # install-skill
    p_skill = subparsers.add_parser("install-skill", help="Instala a skill do orchestrador no OpenClaw")
    p_skill.set_defaults(func=cmd_install_skill)
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    return args.func(args)

if __name__ == "__main__":
    sys.exit(main())
