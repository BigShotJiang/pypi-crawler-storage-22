"""
Orchestrador v3 - Configuracoes

Skills locais (pasta skills/ do orchestrador)
Não depende mais do OpenClaw para skills.

CLIs Configuradas:
- Claude Code: Backend, Frontend, Fullstack, Database, API, Architecture, DevOps, UI/Design
- Codex CLI: Review, Security, Bugfix, Refactor, Docs, E2E Tests
"""
import os
from pathlib import Path

# Diretorio base do orchestrador
BASE_DIR = Path(__file__).parent

# Skills - LOCAL (dentro do orchestrador)
SKILLS_DIR = BASE_DIR / "skills"

# Projetos
PROJECTS_DIR = Path(os.getenv("PROJECTS_DIR", "/home/clawd/workspaces/projects"))

# Jobs
JOBS_DIR = Path(os.getenv("JOBS_DIR", Path.home() / ".openclaw" / "orchestrador" / "jobs"))

# Servidor
HOST = os.getenv("ORCHESTRADOR_HOST", "127.0.0.1")
PORT = int(os.getenv("ORCHESTRADOR_PORT", "8765"))

# Gateway OpenClaw (para callbacks via HTTP hooks)
GATEWAY_URL = os.getenv("GATEWAY_URL", "http://127.0.0.1:18789")
GATEWAY_HOOK_TOKEN = os.getenv("GATEWAY_HOOK_TOKEN", "orchestrador-hook-token")

# Versao
VERSION = "3.0.0"

# ============================================================
# CLI CONFIG - Mapeamento tipo → CLI + skills
# ============================================================
# Claude Code: Criação de código (backend, frontend, arquitetura)
# Codex CLI: Review, correção, análise
# ============================================================

CLI_CONFIG = {
    # ==================== CLAUDE CODE ====================
    
    # Backend (API, services, repositories, lógica de negócio)
    "backend": {
        "cli": "claude",
        "args": ["-p", "--permission-mode", "bypassPermissions"],
        "user": "clawd",
        "skills": ["backend-patterns", "tdd-guide", "security-review", "web-development-workflow"]
    },
    
    # Database (schema, migrations, queries)
    "database": {
        "cli": "claude",
        "args": ["-p", "--permission-mode", "bypassPermissions"],
        "user": "clawd",
        "skills": ["database-reviewer", "postgres-patterns", "security-review"]
    },
    
    # API Routes (endpoints REST/GraphQL)
    "api": {
        "cli": "claude",
        "args": ["-p", "--permission-mode", "bypassPermissions"],
        "user": "clawd",
        "skills": ["backend-patterns", "tdd-guide", "web-architecture"]
    },
    
    # Architecture (estrutura, patterns, setup inicial)
    "architecture": {
        "cli": "claude",
        "args": ["-p", "--permission-mode", "bypassPermissions"],
        "user": "clawd",
        "skills": ["web-architecture", "architecture-decision", "backend-patterns", "project-analyzer"]
    },

    # Frontend (React, componentes, UI, styling)
    "frontend": {
        "cli": "claude",
        "args": ["-p", "--permission-mode", "bypassPermissions"],
        "user": "clawd",
        "skills": ["frontend-patterns", "tdd-guide", "interface-design", "web-tdd-workflow"]
    },
    
    # Landing Pages (sites estáticos, marketing)
    "landing": {
        "cli": "claude",
        "args": ["-p", "--permission-mode", "bypassPermissions"],
        "user": "clawd",
        "skills": ["frontend-patterns", "interface-design"]
    },
    
    # UI Components (apenas UI/styling)
    "ui": {
        "cli": "claude",
        "args": ["-p", "--permission-mode", "bypassPermissions"],
        "user": "clawd",
        "skills": ["frontend-patterns", "interface-design"]
    },

    # DevOps (Docker, CI/CD, deploy, infra)
    "devops": {
        "cli": "claude",
        "args": ["-p", "--permission-mode", "bypassPermissions"],
        "user": "clawd",
        "skills": ["devops-patterns", "security-review"]
    },

    # Fullstack (backend + frontend) - usa Opus
    "fullstack": {
        "cli": "claude",
        "args": ["-p", "--permission-mode", "bypassPermissions", "--model", "opus"],
        "user": "clawd",
        "skills": [
            "backend-patterns", 
            "frontend-patterns", 
            "tdd-guide", 
            "web-architecture",
            "web-development-workflow",
            "interface-design"
        ]
    },

    # ==================== CODEX CLI ====================
    
    # Code Review (qualidade, best practices)
    "review": {
        "cli": "codex",
        "args": ["exec", "--full-auto", "--skip-git-repo-check"],
        "skills": ["code-reviewer", "security-review", "web-tdd-workflow"]
    },
    
    # Security Review (auditoria de segurança)
    "security": {
        "cli": "codex",
        "args": ["exec", "--full-auto", "--skip-git-repo-check"],
        "skills": ["security-review", "code-reviewer"]
    },
    
    # Bugfix (correção de bugs, erros de build)
    "bugfix": {
        "cli": "codex",
        "args": ["exec", "--full-auto", "--skip-git-repo-check"],
        "skills": ["build-error-resolver", "code-reviewer"]
    },
    
    # Refactor (refatoração, limpeza de código)
    "refactor": {
        "cli": "codex",
        "args": ["exec", "--full-auto", "--skip-git-repo-check"],
        "skills": ["refactor-cleaner", "code-reviewer"]
    },

    # Documentation (docs, codemaps, READMEs)
    "docs": {
        "cli": "codex",
        "args": ["exec", "--full-auto", "--skip-git-repo-check"],
        "skills": ["doc-updater", "project-analyzer"]
    },

    # E2E Tests (testes end-to-end com Playwright)
    "e2e": {
        "cli": "codex",
        "args": ["exec", "--full-auto", "--skip-git-repo-check"],
        "skills": ["e2e-runner", "web-tdd-workflow"]
    },

    # Analysis (análise de projeto, greenfield/brownfield)
    "analysis": {
        "cli": "codex",
        "args": ["exec", "--full-auto", "--skip-git-repo-check"],
        "skills": ["project-analyzer", "code-reviewer", "architecture-decision"]
    }
}

# Lista de tipos válidos (para validação)
VALID_TYPES = list(CLI_CONFIG.keys())
