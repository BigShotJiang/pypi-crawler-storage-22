"""
Orchestrador - Database Layer (SQLite WAL)

Persistência eficiente de jobs e pipelines usando SQLite com Write-Ahead Logging.
"""
import sqlite3
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any
from contextlib import contextmanager

# Database path
DB_DIR = Path("/root/.openclaw/orchestrador")
DB_PATH = DB_DIR / "orchestrador.db"


def get_connection() -> sqlite3.Connection:
    """Cria conexão com configurações otimizadas"""
    DB_DIR.mkdir(parents=True, exist_ok=True)
    
    conn = sqlite3.connect(str(DB_PATH), timeout=30.0)
    conn.row_factory = sqlite3.Row  # Acesso por nome de coluna
    
    # Configurações WAL para performance
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA cache_size=10000")  # ~40MB cache
    conn.execute("PRAGMA temp_store=MEMORY")
    conn.execute("PRAGMA mmap_size=268435456")  # 256MB mmap
    
    return conn


@contextmanager
def db_transaction():
    """Context manager para transações"""
    conn = get_connection()
    try:
        yield conn
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        conn.close()


def init_database():
    """Inicializa schema do banco"""
    with db_transaction() as conn:
        # Tabela de Jobs
        conn.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY,
                tipo TEXT NOT NULL,
                projeto TEXT NOT NULL,
                descricao TEXT,
                status TEXT DEFAULT 'pending',
                cli TEXT DEFAULT '',
                started_at TEXT,
                finished_at TEXT,
                exit_code INTEGER,
                output TEXT DEFAULT '',
                error TEXT DEFAULT '',
                callback_session TEXT,
                current_task_index INTEGER DEFAULT 0,
                depends_on TEXT,
                pipeline_id TEXT,
                auto_review INTEGER DEFAULT 1,
                max_review_iterations INTEGER DEFAULT 5,
                codex_timeout INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Tabela de Tasks
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id TEXT PRIMARY KEY,
                job_id TEXT NOT NULL,
                name TEXT NOT NULL,
                description TEXT,
                status TEXT DEFAULT 'pending',
                started_at TEXT,
                finished_at TEXT,
                exit_code INTEGER,
                output TEXT DEFAULT '',
                error TEXT DEFAULT '',
                tests_passed INTEGER DEFAULT 0,
                build_passed INTEGER DEFAULT 0,
                review_passed INTEGER DEFAULT 0,
                task_order INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
            )
        """)
        
        # Tabela de Pipelines
        conn.execute("""
            CREATE TABLE IF NOT EXISTS pipelines (
                id TEXT PRIMARY KEY,
                status TEXT DEFAULT 'pending',
                current_job_index INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                finished_at TEXT
            )
        """)
        
        # Índices para queries frequentes
        conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_projeto ON jobs(projeto)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_pipeline ON jobs(pipeline_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_created ON jobs(created_at)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_job ON tasks(job_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status)")
        
        print("[database] Schema inicializado com sucesso")


# ============ JOB OPERATIONS ============

def save_job(job_data: Dict[str, Any]) -> None:
    """Salva ou atualiza um job"""
    with db_transaction() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO jobs (
                id, tipo, projeto, descricao, status, cli,
                started_at, finished_at, exit_code, output, error,
                callback_session, current_task_index, depends_on,
                pipeline_id, auto_review, max_review_iterations,
                codex_timeout, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            job_data["id"],
            job_data["tipo"],
            job_data["projeto"],
            job_data.get("descricao", ""),
            job_data.get("status", "pending"),
            job_data.get("cli", ""),
            job_data.get("started_at"),
            job_data.get("finished_at"),
            job_data.get("exit_code"),
            job_data.get("output", "")[-10000:],  # Limita output
            job_data.get("error", ""),
            job_data.get("callback_session"),
            job_data.get("current_task_index", 0),
            job_data.get("depends_on"),
            job_data.get("pipeline_id"),
            1 if job_data.get("auto_review", True) else 0,
            job_data.get("max_review_iterations", 5),
            job_data.get("codex_timeout"),
            datetime.now().isoformat()
        ))


def load_job(job_id: str) -> Optional[Dict[str, Any]]:
    """Carrega um job pelo ID"""
    with db_transaction() as conn:
        row = conn.execute(
            "SELECT * FROM jobs WHERE id = ?", (job_id,)
        ).fetchone()
        
        if not row:
            return None
        
        job = dict(row)
        job["auto_review"] = bool(job["auto_review"])
        
        # Carrega tasks
        tasks = conn.execute(
            "SELECT * FROM tasks WHERE job_id = ? ORDER BY task_order",
            (job_id,)
        ).fetchall()
        
        job["tasks"] = [_task_row_to_dict(t) for t in tasks]
        
        return job


def _task_row_to_dict(row: sqlite3.Row) -> Dict[str, Any]:
    """Converte row de task para dict"""
    return {
        "id": row["id"],
        "name": row["name"],
        "description": row["description"],
        "status": row["status"],
        "started_at": row["started_at"],
        "finished_at": row["finished_at"],
        "exit_code": row["exit_code"],
        "output": row["output"],
        "error": row["error"],
        "tests_passed": bool(row["tests_passed"]),
        "build_passed": bool(row["build_passed"]),
        "review_passed": bool(row["review_passed"])
    }


def list_all_jobs(limit: int = 100, status: str = None) -> List[Dict[str, Any]]:
    """Lista jobs com filtros opcionais"""
    with db_transaction() as conn:
        if status:
            rows = conn.execute(
                "SELECT * FROM jobs WHERE status = ? ORDER BY created_at DESC LIMIT ?",
                (status, limit)
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM jobs ORDER BY created_at DESC LIMIT ?",
                (limit,)
            ).fetchall()
        
        jobs = []
        for row in rows:
            job = dict(row)
            job["auto_review"] = bool(job["auto_review"])
            
            # Carrega tasks
            tasks = conn.execute(
                "SELECT * FROM tasks WHERE job_id = ? ORDER BY task_order",
                (job["id"],)
            ).fetchall()
            job["tasks"] = [_task_row_to_dict(t) for t in tasks]
            
            jobs.append(job)
        
        return jobs


def find_jobs_by_status(status: str) -> List[Dict[str, Any]]:
    """Encontra jobs por status"""
    return list_all_jobs(limit=1000, status=status)


def delete_job(job_id: str) -> bool:
    """Remove um job e suas tasks"""
    with db_transaction() as conn:
        conn.execute("DELETE FROM tasks WHERE job_id = ?", (job_id,))
        result = conn.execute("DELETE FROM jobs WHERE id = ?", (job_id,))
        return result.rowcount > 0


# ============ TASK OPERATIONS ============

def save_task(job_id: str, task_data: Dict[str, Any], task_order: int = 0) -> None:
    """Salva ou atualiza uma task"""
    with db_transaction() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO tasks (
                id, job_id, name, description, status,
                started_at, finished_at, exit_code, output, error,
                tests_passed, build_passed, review_passed, task_order
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            task_data["id"],
            job_id,
            task_data.get("name", "Task"),
            task_data.get("description", ""),
            task_data.get("status", "pending"),
            task_data.get("started_at"),
            task_data.get("finished_at"),
            task_data.get("exit_code"),
            task_data.get("output", "")[-10000:],
            task_data.get("error", ""),
            1 if task_data.get("tests_passed") else 0,
            1 if task_data.get("build_passed") else 0,
            1 if task_data.get("review_passed") else 0,
            task_order
        ))


def load_task(task_id: str) -> Optional[Dict[str, Any]]:
    """Carrega uma task pelo ID"""
    with db_transaction() as conn:
        row = conn.execute(
            "SELECT * FROM tasks WHERE id = ?", (task_id,)
        ).fetchone()
        
        if not row:
            return None
        
        return _task_row_to_dict(row)


# ============ PIPELINE OPERATIONS ============

def save_pipeline(pipeline_data: Dict[str, Any]) -> None:
    """Salva ou atualiza um pipeline"""
    with db_transaction() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO pipelines (
                id, status, current_job_index, created_at, finished_at
            ) VALUES (?, ?, ?, ?, ?)
        """, (
            pipeline_data["id"],
            pipeline_data.get("status", "pending"),
            pipeline_data.get("current_job_index", 0),
            pipeline_data.get("created_at", datetime.now().isoformat()),
            pipeline_data.get("finished_at")
        ))


def load_pipeline(pipeline_id: str) -> Optional[Dict[str, Any]]:
    """Carrega um pipeline com seus jobs"""
    with db_transaction() as conn:
        row = conn.execute(
            "SELECT * FROM pipelines WHERE id = ?", (pipeline_id,)
        ).fetchone()
        
        if not row:
            return None
        
        pipeline = dict(row)
        
        # Carrega jobs do pipeline
        jobs = conn.execute(
            "SELECT id FROM jobs WHERE pipeline_id = ? ORDER BY id",
            (pipeline_id,)
        ).fetchall()
        
        pipeline["jobs"] = [j["id"] for j in jobs]
        
        return pipeline


def list_all_pipelines(limit: int = 50) -> List[Dict[str, Any]]:
    """Lista pipelines"""
    with db_transaction() as conn:
        rows = conn.execute(
            "SELECT * FROM pipelines ORDER BY created_at DESC LIMIT ?",
            (limit,)
        ).fetchall()
        
        pipelines = []
        for row in rows:
            pipeline = dict(row)
            
            # Carrega jobs do pipeline
            jobs = conn.execute(
                "SELECT id FROM jobs WHERE pipeline_id = ? ORDER BY id",
                (pipeline["id"],)
            ).fetchall()
            pipeline["jobs"] = [j["id"] for j in jobs]
            
            pipelines.append(pipeline)
        
        return pipelines


# ============ MIGRATION ============

def migrate_from_json(json_dir: Path) -> Dict[str, int]:
    """Migra dados de JSON para SQLite"""
    stats = {"jobs": 0, "tasks": 0, "errors": 0}
    
    if not json_dir.exists():
        return stats
    
    init_database()
    
    for json_file in json_dir.glob("*.json"):
        try:
            data = json.loads(json_file.read_text(encoding="utf-8"))
            
            # Salva job
            save_job(data)
            stats["jobs"] += 1
            
            # Salva tasks
            for i, task in enumerate(data.get("tasks", [])):
                save_task(data["id"], task, task_order=i)
                stats["tasks"] += 1
                
        except Exception as e:
            print(f"[database] Erro migrando {json_file}: {e}")
            stats["errors"] += 1
    
    print(f"[database] Migração concluída: {stats}")
    return stats


# ============ STATS ============

def get_stats() -> Dict[str, Any]:
    """Retorna estatísticas do banco"""
    with db_transaction() as conn:
        total_jobs = conn.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]
        
        by_status = {}
        for row in conn.execute("SELECT status, COUNT(*) as cnt FROM jobs GROUP BY status"):
            by_status[row["status"]] = row["cnt"]
        
        total_tasks = conn.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
        total_pipelines = conn.execute("SELECT COUNT(*) FROM pipelines").fetchone()[0]
        
        # Tamanho do banco
        db_size = DB_PATH.stat().st_size if DB_PATH.exists() else 0
        
        return {
            "total_jobs": total_jobs,
            "jobs_by_status": by_status,
            "total_tasks": total_tasks,
            "total_pipelines": total_pipelines,
            "database_size_mb": round(db_size / (1024 * 1024), 2)
        }


# ============ CLEANUP ============

def cleanup_old_jobs(days: int = 30) -> int:
    """Remove jobs antigos (completados/falhos)"""
    with db_transaction() as conn:
        cutoff = datetime.now().isoformat()[:10]  # Simplificado
        
        # Remove tasks de jobs antigos
        conn.execute("""
            DELETE FROM tasks WHERE job_id IN (
                SELECT id FROM jobs 
                WHERE status IN ('completed', 'failed')
                AND date(created_at) < date(?, '-' || ? || ' days')
            )
        """, (cutoff, days))
        
        # Remove jobs antigos
        result = conn.execute("""
            DELETE FROM jobs 
            WHERE status IN ('completed', 'failed')
            AND date(created_at) < date(?, '-' || ? || ' days')
        """, (cutoff, days))
        
        return result.rowcount


# Inicializa banco ao importar
init_database()
