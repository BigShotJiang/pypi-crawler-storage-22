"""
Orchestrador - Executor de CLIs (v2)

Novidades:
- Sistema de Tasks: cada job = task testável individualmente
- Pipeline: jobs em sequência com dependências
- Code Review + Build-Fix em loop até passar
- Sem timeout fixo (apenas detecção de falha real)
"""
import os
import subprocess
import json
import uuid
import urllib.request
import urllib.error
import time
import re
import shutil
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field, asdict
from enum import Enum

from .config import CLI_CONFIG, PROJECTS_DIR, JOBS_DIR, GATEWAY_URL, GATEWAY_HOOK_TOKEN
from .skills import load_skills
from . import database as db


class JobStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    WAITING = "waiting"  # Aguardando dependência
    COMPLETED = "completed"
    FAILED = "failed"


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class Task:
    """Uma tarefa dentro de um job"""
    id: str
    name: str
    description: str
    status: TaskStatus = TaskStatus.PENDING
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    exit_code: Optional[int] = None
    output: str = ""
    error: str = ""
    tests_passed: bool = False
    build_passed: bool = False
    review_passed: bool = False

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "status": self.status.value if isinstance(self.status, TaskStatus) else self.status,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "exit_code": self.exit_code,
            "output": self.output[-3000:] if self.output else "",
            "error": self.error,
            "tests_passed": self.tests_passed,
            "build_passed": self.build_passed,
            "review_passed": self.review_passed
        }
    
    def save(self, job_id: str = None):
        """Salva task via job pai"""
        if job_id:
            job = Job.load(job_id)
            if job:
                for i, t in enumerate(job.tasks):
                    if t.id == self.id:
                        job.tasks[i] = self
                        job.save()
                        break


@dataclass
class Job:
    """Job contendo múltiplas tasks"""
    id: str
    tipo: str
    projeto: str
    descricao: str
    status: JobStatus = JobStatus.PENDING
    cli: str = ""
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    exit_code: Optional[int] = None
    output: str = ""
    error: str = ""
    callback_session: Optional[str] = None
    tasks: List[Task] = field(default_factory=list)
    current_task_index: int = 0
    depends_on: Optional[str] = None  # ID do job que deve completar antes
    pipeline_id: Optional[str] = None  # ID do pipeline (grupo de jobs)
    auto_review: bool = True
    max_review_iterations: int = 5  # Máximo de tentativas de review/fix
    codex_timeout: Optional[int] = None  # Timeout customizado em segundos (None = adaptável)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "tipo": self.tipo,
            "projeto": self.projeto,
            "descricao": self.descricao,
            "status": self.status.value,
            "cli": self.cli,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "exit_code": self.exit_code,
            "output": self.output[-5000:] if self.output else "",
            "error": self.error,
            "callback_session": self.callback_session,
            "tasks": [t.to_dict() for t in self.tasks],
            "current_task_index": self.current_task_index,
            "depends_on": self.depends_on,
            "pipeline_id": self.pipeline_id,
            "auto_review": self.auto_review,
            "max_review_iterations": self.max_review_iterations,
            "codex_timeout": self.codex_timeout,
            "progress": f"{self.current_task_index}/{len(self.tasks)}"
        }

    def save(self):
        """Salva job no SQLite"""
        # Salva job
        db.save_job(self.to_dict())
        
        # Salva tasks
        for i, task in enumerate(self.tasks):
            db.save_task(self.id, task.to_dict(), task_order=i)

    @classmethod
    def load(cls, job_id: str) -> Optional["Job"]:
        """Carrega job do SQLite"""
        data = db.load_job(job_id)
        if not data:
            return None
        
        # Reconstrói tasks
        tasks = []
        for t in data.get("tasks", []):
            task = Task(
                id=t["id"],
                name=t["name"],
                description=t.get("description", ""),
                status=TaskStatus(t["status"]) if t.get("status") else TaskStatus.PENDING,
                started_at=t.get("started_at"),
                finished_at=t.get("finished_at"),
                exit_code=t.get("exit_code"),
                output=t.get("output", ""),
                error=t.get("error", ""),
                tests_passed=t.get("tests_passed", False),
                build_passed=t.get("build_passed", False),
                review_passed=t.get("review_passed", False)
            )
            tasks.append(task)
        
        return cls(
            id=data["id"],
            tipo=data["tipo"],
            projeto=data["projeto"],
            descricao=data.get("descricao", ""),
            status=JobStatus(data["status"]) if data.get("status") else JobStatus.PENDING,
            cli=data.get("cli", ""),
            started_at=data.get("started_at"),
            finished_at=data.get("finished_at"),
            exit_code=data.get("exit_code"),
            output=data.get("output", ""),
            error=data.get("error", ""),
            callback_session=data.get("callback_session"),
            tasks=tasks,
            current_task_index=data.get("current_task_index", 0),
            depends_on=data.get("depends_on"),
            pipeline_id=data.get("pipeline_id"),
            auto_review=data.get("auto_review", True),
            max_review_iterations=data.get("max_review_iterations", 5),
            codex_timeout=data.get("codex_timeout")
        )


class Pipeline:
    """Gerencia um pipeline de jobs sequenciais"""
    
    def __init__(self, pipeline_id: str, jobs: List[Job]):
        self.id = pipeline_id
        self.jobs = jobs
        self.status = JobStatus.PENDING
        self.current_job_index = 0
        self.created_at = datetime.now().isoformat()
        self.finished_at = None
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "status": self.status.value if isinstance(self.status, JobStatus) else self.status,
            "current_job_index": self.current_job_index,
            "total_jobs": len(self.jobs),
            "created_at": self.created_at,
            "finished_at": self.finished_at,
            "jobs": [j.id for j in self.jobs]
        }
    
    def save(self):
        """Salva pipeline no SQLite"""
        db.save_pipeline(self.to_dict())
    
    @classmethod
    def load(cls, pipeline_id: str) -> Optional["Pipeline"]:
        """Carrega pipeline do SQLite"""
        data = db.load_pipeline(pipeline_id)
        if not data:
            return None
        
        # Carrega jobs do pipeline
        jobs = []
        for job_id in data.get("jobs", []):
            job = Job.load(job_id)
            if job:
                jobs.append(job)
        
        pipeline = cls(pipeline_id, jobs)
        pipeline.status = data.get("status", JobStatus.PENDING)
        pipeline.current_job_index = data.get("current_job_index", 0)
        pipeline.created_at = data.get("created_at")
        pipeline.finished_at = data.get("finished_at")
        return pipeline
    
    def get_current_job(self) -> Optional[Job]:
        """Retorna o job atual do pipeline"""
        if self.current_job_index < len(self.jobs):
            return self.jobs[self.current_job_index]
        return None
    
    def mark_job_completed(self, job_id: str):
        """Marca um job como completado e avança para o próximo"""
        if self.current_job_index < len(self.jobs):
            current_job = self.jobs[self.current_job_index]
            if current_job.id == job_id:
                self.current_job_index += 1
                
                # Verifica se pipeline terminou
                if self.current_job_index >= len(self.jobs):
                    self.status = JobStatus.COMPLETED
                    self.finished_at = datetime.now().isoformat()
                else:
                    # Inicia próximo job
                    next_job = self.jobs[self.current_job_index]
                    next_job.status = JobStatus.RUNNING
                    next_job.save()
                    self.status = JobStatus.RUNNING
                
                self.save()
    
    def mark_job_failed(self, job_id: str):
        """Marca um job como falho (para o pipeline)"""
        self.status = JobStatus.FAILED
        self.finished_at = datetime.now().isoformat()
        self.save()


def notify_callback(session_key: str, job: "Job", pipeline: Pipeline = None) -> bool:
    """Notifica o clawdbot via HTTP hooks quando job termina"""
    if not session_key:
        return False

    # Calcula duracao
    duration = ""
    if job.started_at and job.finished_at:
        try:
            start = datetime.fromisoformat(job.started_at)
            end = datetime.fromisoformat(job.finished_at)
            delta = end - start
            mins, secs = divmod(int(delta.total_seconds()), 60)
            duration = f"{mins}m {secs}s" if mins > 0 else f"{secs}s"
        except:
            pass

    # Monta mensagem
    if pipeline:
        progress = f"({pipeline.current_job_index + 1}/{len(pipeline.jobs)})"
    else:
        progress = f"({job.current_task_index}/{len(job.tasks)})" if job.tasks else ""

    if job.status == JobStatus.COMPLETED:
        message = f"✅ Job {job.id} {progress} completo ({job.projeto})"
        if duration:
            message += f" em {duration}"
        if job.tasks:
            all_passed = all(t.tests_passed and t.build_passed for t in job.tasks)
            if all_passed:
                message += " - Todos os checks passaram!"
            else:
                message += " - Alguns checks falharam"
    elif job.status == JobStatus.FAILED:
        message = f"❌ Job {job.id} {progress} falhou ({job.projeto})"
        if job.error:
            message += f": {job.error[:100]}"
    else:
        message = f"⏳ Job {job.id} {progress} em andamento ({job.projeto})"

    # Envia pro gateway (para sessão atual, não só telegram)
    try:
        url = f"{GATEWAY_URL}/hooks/agent"
        data = json.dumps({
            "message": message,
            "name": "Orchestrador",
            "deliver": True,
            "wakeMode": "now"
        }).encode("utf-8")

        req = urllib.request.Request(
            url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "x-openclaw-token": GATEWAY_HOOK_TOKEN
            },
            method="POST"
        )

        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status in [200, 202]
    except Exception as e:
        print(f"[orchestrador] Erro ao notificar: {e}")
        return False


def get_project_state(projeto_dir: Path) -> dict:
    """Analisa estado atual do projeto (para brownfield ou tasks subsequentes)"""
    state = {
        "exists": projeto_dir.exists(),
        "files": [],
        "has_package_json": False,
        "has_src": False,
        "has_tests": False,
        "type": "greenfield"
    }
    
    if not projeto_dir.exists():
        return state
    
    # Lista arquivos existentes (ignora node_modules, .git, dist)
    ignore_dirs = {'node_modules', '.git', 'dist', '.next', '__pycache__', 'venv'}
    for root, dirs, files in os.walk(projeto_dir):
        dirs[:] = [d for d in dirs if d not in ignore_dirs]
        for f in files:
            rel_path = os.path.relpath(os.path.join(root, f), projeto_dir)
            state["files"].append(rel_path)
    
    state["has_package_json"] = "package.json" in state["files"]
    state["has_src"] = any(f.startswith("src/") for f in state["files"])
    state["has_tests"] = any("test" in f.lower() for f in state["files"])
    
    if state["has_package_json"] or len(state["files"]) > 2:
        state["type"] = "brownfield"
    
    return state


def get_completed_tasks_summary(job: Job) -> str:
    """Gera resumo das tasks já completadas"""
    completed = []
    for i, t in enumerate(job.tasks):
        if i < job.current_task_index:
            status = "✓" if t.build_passed else "✗"
            completed.append(f"  {status} Task {i+1}: {t.name}")
    
    if not completed:
        return ""
    
    return "## TASKS JÁ COMPLETADAS\n" + "\n".join(completed)


def get_pending_tasks_summary(job: Job) -> str:
    """Gera resumo das tasks pendentes (para contexto)"""
    pending = []
    for i, t in enumerate(job.tasks):
        if i > job.current_task_index:
            pending.append(f"  - Task {i+1}: {t.name}")
    
    if not pending:
        return ""
    
    return "## TASKS FUTURAS (apenas para contexto, NAO implemente)\n" + "\n".join(pending)


def build_task_prompt(task: Task, job: Job, skills: list, contexto: str = None, regras: list = None) -> str:
    """Monta prompt para uma task específica"""
    skills_content = load_skills(skills)
    
    # Analisa estado do projeto
    projeto_dir = PROJECTS_DIR / job.projeto
    project_state = get_project_state(projeto_dir)
    
    # Regras base
    regras_default = [
        "Siga os patterns das skills",
        "Escreva testes ANTES do codigo (TDD)",
        "Arquivos pequenos (max 400 linhas)",
        "Nomes descritivos",
        "Trate erros",
        "Valide inputs",
        "NAO use emojis no codigo",
        "VERIFIQUE build antes de finalizar"
    ]
    
    if regras:
        regras_list = regras
    else:
        regras_list = regras_default
    
    regras_str = "\n".join(f"- {r}" for r in regras_list)
    
    # Contexto do projeto
    contexto_str = f"\n\n## CONTEXTO DO PROJETO\n{contexto}" if contexto else ""
    
    # Estado atual (para brownfield ou tasks subsequentes)
    estado_str = ""
    if project_state["type"] == "brownfield" or job.current_task_index > 0:
        files_list = "\n".join(f"  - {f}" for f in project_state["files"][:30])
        if len(project_state["files"]) > 30:
            files_list += f"\n  ... e mais {len(project_state['files']) - 30} arquivos"
        estado_str = f"""

## ESTADO ATUAL DO PROJETO ({project_state['type'].upper()})
Arquivos existentes:
{files_list}"""
    
    # Tasks completadas e pendentes
    completed_str = get_completed_tasks_summary(job)
    pending_str = get_pending_tasks_summary(job)
    
    # Número da task atual
    task_num = job.current_task_index + 1
    total_tasks = len(job.tasks)

    return f"""## TASK {task_num}/{total_tasks}: {task.name}

### OBJETIVO DESTA TASK
{task.description}

### IMPORTANTE - FOCO
- Implemente APENAS o que esta task pede
- NAO implemente funcionalidades de tasks futuras
- Se precisar de algo de uma task futura, use stubs/mocks
- Garanta que o build passa ao final desta task
{contexto_str}{estado_str}

{completed_str}

{pending_str}

## SKILLS E PATTERNS
{skills_content}

## REGRAS
{regras_str}

## CHECKLIST DE CONCLUSAO
Ao finalizar ESTA TASK, certifique-se:
- [ ] Implementou APENAS o que foi pedido nesta task
- [ ] Testes passam (`npm test` ou equivalente)
- [ ] Build passa (`npm run build` ou equivalente)
- [ ] TypeScript sem erros
- [ ] Codigo limpo e bem estruturado

Finalize APENAS quando todos os checks passarem."""


def run_cli_command(cmd: list, cwd: str, prompt: str = None, env: dict = None, timeout: int = None) -> tuple:
    """Executa comando CLI e retorna (stdout, stderr, exit_code)
    
    Args:
        cmd: Comando a executar
        cwd: Diretório de trabalho
        prompt: Input para stdin (opcional)
        env: Variáveis de ambiente (opcional)
        timeout: Timeout em segundos (opcional, None = sem timeout)
    
    Returns:
        (stdout, stderr, exit_code)
        exit_code = -1 indica timeout
    """
    try:
        process = subprocess.Popen(
            cmd,
            cwd=cwd,
            stdin=subprocess.PIPE if prompt else None,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            shell=False,
            encoding="utf-8",
            errors="replace",
            env=env
        )
        
        try:
            if prompt:
                stdout, stderr = process.communicate(input=prompt, timeout=timeout)
            else:
                stdout, stderr = process.communicate(timeout=timeout)
            
            return stdout, stderr, process.returncode
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            return "", f"TIMEOUT: Processo excedeu {timeout}s", -1
    except Exception as e:
        return "", str(e), 1


def check_tests_pass(output: str) -> bool:
    """Verifica se os testes passaram baseado no output"""
    patterns = [
        r'(\d+)\s+passing',  # Mocha/Jest
        r'Tests?:\s+(\d+)\s+passed',  # Vitest
        r'✓\s+\d+',  # Checkmarks
        r'PASS',  # Jest pass
        r'Test Suites?:\s+(\d+)\s+passed',  # Jest suites
    ]
    for pattern in patterns:
        if re.search(pattern, output, re.IGNORECASE):
            # Verifica se não há falhas
            if not re.search(r'(\d+)\s+failing|FAIL|failed', output, re.IGNORECASE):
                return True
    return False


def check_build_pass(output: str) -> bool:
    """Verifica se o build passou"""
    success_patterns = [
        r'Build\s+completed\s+successfully',
        r'Compiled\s+successfully',
        r'✓\s+Built',
        r'Done\s+in\s+[\d.]+s',  # Next.js build
        r'successfully\s+built',
    ]
    fail_patterns = [
        r'Build\s+error',
        r'Compilation\s+error',
        r'Failed\s+to\s+compile',
        r'error\s+during\s+build',
    ]
    
    has_success = any(re.search(p, output, re.IGNORECASE) for p in success_patterns)
    has_fail = any(re.search(p, output, re.IGNORECASE) for p in fail_patterns)
    
    return has_success and not has_fail


def detect_project_type(projeto_dir: str) -> dict:
    """
    Detecta o tipo de projeto baseado nos arquivos presentes.
    Retorna dict com tipo, comandos de build/test e se tem estrutura válida.
    """
    projeto_path = Path(projeto_dir)
    
    # Node.js / TypeScript
    if (projeto_path / "package.json").exists():
        pkg = {}
        try:
            pkg = json.loads((projeto_path / "package.json").read_text())
        except:
            pass
        
        scripts = pkg.get("scripts", {})
        return {
            "type": "nodejs",
            "build_cmd": ["npm", "run", "build"] if "build" in scripts else None,
            "test_cmd": ["npm", "test"] if "test" in scripts else None,
            "lint_cmd": ["npm", "run", "lint"] if "lint" in scripts else None,
            "typecheck_cmd": ["npx", "tsc", "--noEmit"] if (projeto_path / "tsconfig.json").exists() else None,
            "has_structure": True
        }
    
    # Python
    if (projeto_path / "requirements.txt").exists() or \
       (projeto_path / "setup.py").exists() or \
       (projeto_path / "pyproject.toml").exists() or \
       any(projeto_path.glob("*.py")):
        # Só roda mypy se tiver config (mypy.ini, pyproject.toml com [tool.mypy], ou setup.cfg)
        has_mypy_config = (projeto_path / "mypy.ini").exists() or \
                          (projeto_path / ".mypy.ini").exists() or \
                          (projeto_path / "setup.cfg").exists()
        if (projeto_path / "pyproject.toml").exists():
            try:
                pyproject = (projeto_path / "pyproject.toml").read_text()
                has_mypy_config = has_mypy_config or "[tool.mypy]" in pyproject
            except:
                pass
        
        return {
            "type": "python",
            "build_cmd": None,  # Python não tem build tradicional
            "test_cmd": ["python", "-m", "pytest"] if (projeto_path / "tests").exists() or any(projeto_path.glob("test_*.py")) else None,
            "lint_cmd": None,  # Desabilitado por padrão - muitos false positives
            "typecheck_cmd": ["python", "-m", "mypy", "."] if has_mypy_config and shutil.which("mypy") else None,
            "has_structure": True
        }
    
    # Go
    if (projeto_path / "go.mod").exists():
        return {
            "type": "go",
            "build_cmd": ["go", "build", "./..."],
            "test_cmd": ["go", "test", "./..."],
            "lint_cmd": None,
            "typecheck_cmd": None,
            "has_structure": True
        }
    
    # Projeto sem estrutura reconhecida
    return {
        "type": "unknown",
        "build_cmd": None,
        "test_cmd": None,
        "lint_cmd": None,
        "typecheck_cmd": None,
        "has_structure": False
    }


def calculate_adaptive_timeout(projeto_dir: str, operation: str = "review") -> int:
    """
    Calcula timeout adaptável baseado no tamanho do projeto e tipo de operação.
    
    Args:
        projeto_dir: Diretório do projeto
        operation: Tipo de operação (quick_fix, review, deep_review, bug_hunt, refactor)
    
    Returns:
        Timeout em segundos
    """
    # Limites
    MIN_TIMEOUT = 60    # 1 minuto mínimo
    MAX_TIMEOUT = 900   # 15 minutos máximo
    
    # Base por tipo de operação
    OPERATION_BASE = {
        "quick_fix": 60,      # Fix simples
        "review": 120,        # Review básico
        "deep_review": 180,   # Review profundo
        "bug_hunt": 300,      # Busca de bugs
        "refactor": 300,      # Refatoração
    }
    
    base = OPERATION_BASE.get(operation, 120)
    
    # Conta linhas de código (ignora node_modules, .git, dist, etc)
    loc = 0
    ignore_dirs = {'node_modules', '.git', 'dist', '.next', '__pycache__', 'venv', 'build', 'coverage'}
    code_extensions = {'.ts', '.tsx', '.js', '.jsx', '.py', '.go', '.rs', '.java', '.kt', '.swift', '.c', '.cpp', '.h'}
    
    try:
        for root, dirs, files in os.walk(projeto_dir):
            dirs[:] = [d for d in dirs if d not in ignore_dirs]
            for f in files:
                ext = os.path.splitext(f)[1].lower()
                if ext in code_extensions:
                    try:
                        filepath = os.path.join(root, f)
                        with open(filepath, 'r', encoding='utf-8', errors='ignore') as file:
                            loc += sum(1 for line in file if line.strip())
                    except:
                        pass
    except:
        pass
    
    # Calcula timeout: base + 30s por cada 1000 linhas
    timeout = base + (loc // 1000) * 30
    
    # Aplica limites
    timeout = max(MIN_TIMEOUT, min(timeout, MAX_TIMEOUT))
    
    print(f"[orchestrador] Timeout adaptável: {timeout}s (LOC: {loc}, operação: {operation})")
    return timeout


def run_codex_review(projeto_dir: str, prompt: str, timeout: int = None, max_retries: int = 2, operation: str = "review") -> tuple:
    """
    Executa Codex CLI para code review/fix com timeout adaptável e retry.
    
    Args:
        projeto_dir: Diretório do projeto
        prompt: Prompt para o Codex
        timeout: Timeout em segundos (None = calcula automaticamente)
        max_retries: Máximo de retries em caso de timeout (default: 2)
        operation: Tipo de operação para cálculo de timeout (quick_fix, review, deep_review, bug_hunt, refactor)
    
    Returns:
        (output, stderr, exit_code)
        exit_code = -1 indica timeout após todos os retries
    """
    # Calcula timeout adaptável se não foi especificado
    if timeout is None:
        timeout = calculate_adaptive_timeout(projeto_dir, operation)
    for attempt in range(max_retries + 1):
        if attempt > 0:
            print(f"[orchestrador] Codex retry {attempt}/{max_retries}...")
        
        stdout, stderr, exit_code = run_cli_command(
            ["codex", "exec", "--full-auto", "--skip-git-repo-check"],
            str(projeto_dir),
            prompt=prompt,
            timeout=timeout
        )
        
        # Se não foi timeout, retorna resultado
        if exit_code != -1:
            return stdout, stderr, exit_code
        
        print(f"[orchestrador] Codex timeout após {timeout}s (tentativa {attempt + 1}/{max_retries + 1})")
    
    # Todos os retries falharam por timeout
    print(f"[orchestrador] Codex falhou após {max_retries + 1} tentativas por timeout")
    return "", f"TIMEOUT: Codex excedeu {timeout}s em todas as {max_retries + 1} tentativas", -1


def run_code_review_and_fix(projeto_dir: str, max_iterations: int = 5, codex_timeout: int = None) -> dict:
    """
    Roda code review e build-fix em loop até passar ou atingir max iterações.
    Usa Codex CLI para review e correções.
    
    Args:
        projeto_dir: Diretório do projeto
        max_iterations: Máximo de iterações do loop
        codex_timeout: Timeout customizado para Codex (None = adaptável automático)
    
    Retorna dict com status final e logs.
    """
    iteration = 0
    all_checks_passed = False
    logs = []
    
    # Detecta tipo de projeto
    project_info = detect_project_type(projeto_dir)
    project_type = project_info["type"]
    
    # Usa timeout customizado ou calcula adaptável
    effective_timeout = codex_timeout if codex_timeout else calculate_adaptive_timeout(projeto_dir, "review")
    
    print(f"[orchestrador] Projeto detectado: {project_type}")
    print(f"[orchestrador] Timeout Codex: {effective_timeout}s {'(customizado)' if codex_timeout else '(adaptável)'}")
    print(f"[orchestrador] Iniciando loop de review + build-fix (max {max_iterations} iterações)")
    
    # Se não tem estrutura reconhecida, pula verificações de build/test
    if not project_info["has_structure"]:
        print(f"[orchestrador] Projeto sem estrutura reconhecida, pulando build/test checks")
        # Apenas faz code review
        review_output, review_stderr, review_exit = run_codex_review(
            projeto_dir,
            prompt="""Analise o código para:
1. Vulnerabilidades de segurança
2. Problemas de qualidade de código
3. Anti-patterns e code smells

Se encontrar problemas CRÍTICOS ou ALTOS, corrija-os.
Se não houver problemas graves, retorne "CODE_REVIEW_PASSED".

Use as skills: code-reviewer, security-review""",
            timeout=effective_timeout
        )
        logs.append({"step": "code-review-only", "output": review_output, "error": review_stderr})
        
        return {
            "success": True,  # Considera sucesso se não tem build/test
            "iterations": 1,
            "logs": logs,
            "tests_passed": True,
            "build_passed": True,
            "review_passed": "CODE_REVIEW_PASSED" in review_output or review_exit == 0
        }
    
    while iteration < max_iterations and not all_checks_passed:
        iteration += 1
        print(f"[orchestrador] Iteração {iteration}/{max_iterations}")
        
        # === STEP 1: Build Check (se aplicável) ===
        build_passed = True
        if project_info["build_cmd"]:
            print(f"[orchestrador] Verificando build ({' '.join(project_info['build_cmd'])})...")
            build_output, build_stderr, build_exit = run_cli_command(
                project_info["build_cmd"],
                str(projeto_dir)
            )
            build_passed = build_exit == 0
            
            if not build_passed:
                print(f"[orchestrador] Build falhou, Codex CLI tentando corrigir...")
                fix_output, fix_stderr, fix_exit = run_codex_review(
                    projeto_dir,
                    prompt=f"""Corrija os erros de build do projeto {project_type}.

Output do build:
{build_output}
{build_stderr}

Use a skill build-error-resolver para:
1. Identificar os erros
2. Aplicar correções mínimas
3. Garantir que o build passe

Regras:
- Faça apenas alterações necessárias para o build passar
- Não mude a arquitetura
- Mantenha a compatibilidade""",
                    timeout=effective_timeout,
                    operation="quick_fix"
                )
                logs.append({"step": f"build-fix-{iteration}", "output": fix_output, "error": fix_stderr})
                continue
        
        # === STEP 2: TypeCheck (se aplicável) ===
        typecheck_passed = True
        if project_info["typecheck_cmd"]:
            print(f"[orchestrador] Verificando tipos...")
            tc_output, tc_stderr, tc_exit = run_cli_command(
                project_info["typecheck_cmd"],
                str(projeto_dir)
            )
            typecheck_passed = tc_exit == 0
            
            if not typecheck_passed:
                print(f"[orchestrador] TypeCheck falhou, Codex CLI tentando corrigir...")
                fix_output, fix_stderr, fix_exit = run_codex_review(
                    projeto_dir,
                    prompt=f"""Corrija os erros de tipo do projeto {project_type}.

Output do typecheck:
{tc_output}
{tc_stderr}

Use a skill build-error-resolver para corrigir erros de tipo.
Faça apenas alterações mínimas necessárias.""",
                    timeout=effective_timeout,
                    operation="quick_fix"
                )
                logs.append({"step": f"typecheck-fix-{iteration}", "output": fix_output, "error": fix_stderr})
                continue
        
        # === STEP 3: Code Review ===
        print(f"[orchestrador] Codex CLI rodando code review...")
        review_output, review_stderr, review_exit = run_codex_review(
            projeto_dir,
            prompt=f"""Analise o código {project_type} para:
1. Vulnerabilidades de segurança (OWASP Top 10)
2. Problemas de qualidade de código
3. Anti-patterns e code smells
4. Boas práticas de {project_type}

Para cada problema encontrado:
- Descreva o problema
- Aplique a correção
- Indique a severidade (Crítica/Alta/Média/Baixa)

Se não houver problemas CRÍTICOS ou ALTOS, retorne "CODE_REVIEW_PASSED".

Use as skills: code-reviewer, security-review""",
            timeout=effective_timeout,
            operation="review"
        )
        
        # Verifica se Codex falhou por timeout
        codex_timeout = review_exit == -1
        review_passed = "CODE_REVIEW_PASSED" in review_output or review_exit == 0
        logs.append({"step": f"code-review-{iteration}", "output": review_output, "error": review_stderr})
        
        # Se Codex deu timeout, verifica se build/tests passam para decidir se continua
        if codex_timeout:
            print(f"[orchestrador] Codex timeout - verificando se build/tests passam para fallback...")
            
            # Verifica build
            fallback_build_passed = True
            if project_info["build_cmd"]:
                fb_out, fb_err, fb_exit = run_cli_command(project_info["build_cmd"], str(projeto_dir), timeout=60)
                fallback_build_passed = fb_exit == 0 or check_build_pass(fb_out + fb_err)
            
            # Verifica tests
            fallback_tests_passed = True
            if project_info["test_cmd"]:
                ft_out, ft_err, ft_exit = run_cli_command(project_info["test_cmd"], str(projeto_dir), timeout=120)
                fallback_tests_passed = ft_exit == 0 or check_tests_pass(ft_out + ft_err)
            
            if fallback_build_passed and fallback_tests_passed:
                print(f"[orchestrador] Build e testes passam - continuando sem code review (fallback)")
                review_passed = True  # Considera review passado por fallback
            else:
                print(f"[orchestrador] Build/testes não passam - não pode usar fallback")
        
        if not review_passed:
            print(f"[orchestrador] Code review encontrou problemas, Codex aplicou correções...")
            time.sleep(1)
            continue
        
        # === STEP 4: Test Check (se aplicável) ===
        tests_passed = True
        if project_info["test_cmd"]:
            print(f"[orchestrador] Verificando testes ({' '.join(project_info['test_cmd'])})...")
            test_output, test_stderr, test_exit = run_cli_command(
                project_info["test_cmd"],
                str(projeto_dir)
            )
            tests_passed = test_exit == 0 or check_tests_pass(test_output + test_stderr)
            
            if not tests_passed:
                print(f"[orchestrador] Testes falharam, Codex CLI tentando corrigir...")
                fix_output, fix_stderr, fix_exit = run_codex_review(
                    projeto_dir,
                    prompt=f"""Corrija os testes que estão falhando no projeto {project_type}.

Output dos testes:
{test_output}
{test_stderr}

Use a skill tdd-guide para:
1. Identificar testes falhando
2. Corrigir o código ou os testes conforme necessário
3. Garantir que todos os testes passem

Regras:
- Mantenha a cobertura de testes
- Não remova testes sem motivo
- Siga o padrão TDD""",
                    timeout=effective_timeout,
                    operation="quick_fix"
                )
                logs.append({"step": f"test-fix-{iteration}", "output": fix_output, "error": fix_stderr})
                continue
        
        # Tudo passou!
        all_checks_passed = True
        print(f"[orchestrador] Todos os checks passaram na iteração {iteration}!")
    
    return {
        "success": all_checks_passed,
        "iterations": iteration,
        "logs": logs,
        "tests_passed": all_checks_passed,
        "build_passed": all_checks_passed,
        "review_passed": all_checks_passed
    }


def execute_task(task: Task, job: Job, skills: list, contexto: str = None, regras: list = None) -> bool:
    """Executa uma task individual"""
    print(f"[orchestrador] Executando task {task.id}: {task.name}")
    
    task.status = TaskStatus.RUNNING
    task.started_at = datetime.now().isoformat()
    task.save(job.id)
    job.save()
    
    # Pega config do CLI
    config = CLI_CONFIG.get(job.tipo, CLI_CONFIG["backend"])
    cli = config["cli"]
    args = config["args"]
    
    # Pega user da config (se tiver) - ANTES de usar
    run_as_user = config.get("user")
    
    # Prepara diretório
    projeto_dir = PROJECTS_DIR / job.projeto
    projeto_dir.mkdir(parents=True, exist_ok=True)
    
    # Ajusta permissões do diretório se rodar como outro usuário
    if run_as_user:
        import shutil
        shutil.chown(projeto_dir, user=run_as_user, group=run_as_user)
        # Ajusta permissões para permitir escrita
        os.chmod(projeto_dir, 0o755)
    
    # Monta prompt
    prompt = build_task_prompt(task, job, skills, contexto, regras)
    
    # Executa CLI
    env = os.environ.copy()
    
    # Salva prompt em arquivo temporário
    prompt_file = Path(f"/tmp/orchestrador-prompt-{task.id}.md")
    # Remove arquivo existente para evitar PermissionError no restart
    if prompt_file.exists():
        try:
            prompt_file.unlink()
        except Exception:
            pass  # Ignora erro se não conseguir deletar
    prompt_file.write_text(prompt, encoding="utf-8")
    # Ajusta permissões para o usuário clawd poder ler
    if run_as_user:
        import shutil
        shutil.chown(prompt_file, user=run_as_user, group=run_as_user)
        os.chmod(prompt_file, 0o644)
    
    try:
        if cli == "claude":
            # Claude Code: usa su - para rodar como usuario clawd sem contexto sudo
            # O -p mode espera prompt via stdin
            if run_as_user:
                # Cria diretório como clawd primeiro
                os.system(f"su - {run_as_user} -c \"mkdir -p '{projeto_dir}'\"")
                os.system(f"su - {run_as_user} -c \"chmod 755 '{projeto_dir}'\"")
                
                # Executa claude via su - (limpa contexto sudo)
                # Passa o prompt via stdin com cat
                cmd = f"su - {run_as_user} -c \"cd '{projeto_dir}' && cat '{prompt_file}' | {cli} {' '.join(args)}\""
            else:
                cmd = f"cd '{projeto_dir}' && cat '{prompt_file}' | {cli} {' '.join(args)}"
            
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                shell=True,
                encoding="utf-8",
                errors="replace",
                env=env
            )
            stdout, stderr = process.communicate()
            exit_code = process.returncode
        else:
            # Outros CLIs (codex): passa via stdin
            cmd = [cli] + args
            stdout, stderr, exit_code = run_cli_command(cmd, str(projeto_dir), prompt, env)
    except Exception as e:
        stdout, stderr, exit_code = "", str(e), 1
    finally:
        # Limpa arquivo de prompt
        try:
            prompt_file.unlink()
        except:
            pass
    
    task.output = stdout
    task.error = stderr
    task.exit_code = exit_code
    
    # Verifica se CLI terminou com sucesso
    if exit_code != 0:
        print(f"[orchestrador] Task {task.id} falhou com exit_code {exit_code}")
        task.status = TaskStatus.FAILED
        task.finished_at = datetime.now().isoformat()
        task.save(job.id)
        return False
    
    # === AUTO REVIEW + BUILD FIX ===
    if job.auto_review:
        print(f"[orchestrador] Iniciando auto review para task {task.id}")
        review_result = run_code_review_and_fix(
            str(projeto_dir), 
            job.max_review_iterations,
            codex_timeout=job.codex_timeout  # None = adaptável automático
        )
        
        task.tests_passed = review_result["tests_passed"]
        task.build_passed = review_result["build_passed"]
        task.review_passed = review_result["review_passed"]
        
        # Adiciona logs do review ao output
        task.output += f"\n\n=== AUTO REVIEW ===\n"
        task.output += f"Iterações: {review_result['iterations']}\n"
        task.output += f"Sucesso: {review_result['success']}\n"
        
        if not review_result["success"]:
            print(f"[orchestrador] Auto review não conseguiu corrigir todos os problemas")
            task.status = TaskStatus.FAILED
            task.finished_at = datetime.now().isoformat()
            task.save(job.id)
            return False
        
        print(f"[orchestrador] Auto review concluído com sucesso")
    
    task.status = TaskStatus.COMPLETED
    task.finished_at = datetime.now().isoformat()
    task.save(job.id)
    return True


# ============ RECUPERAÇÃO DE JOBS ============

def find_interrupted_jobs() -> List[Job]:
    """
    Encontra jobs que estavam rodando quando o orchestrador parou.
    Retorna lista de jobs com status 'running'.
    """
    interrupted = []
    
    # Busca jobs com status 'running' no SQLite
    running_jobs = db.find_jobs_by_status("running")
    
    for data in running_jobs:
        try:
            job = Job.load(data["id"])
            if job:
                interrupted.append(job)
        except Exception as e:
            print(f"[orchestrador] Erro ao carregar job {data['id']}: {e}")
    
    return interrupted


def mark_job_interrupted(job: Job, error_msg: str = None):
    """
    Marca um job como interrompido (failed com flag especial).
    """
    job.status = JobStatus.FAILED
    job.error = error_msg or "Job interrompido por reinício do orchestrador"
    job.finished_at = datetime.now().isoformat()
    
    # Marca task atual como interrompida também
    if job.tasks and job.current_task_index < len(job.tasks):
        current_task = job.tasks[job.current_task_index]
        if current_task.status == TaskStatus.RUNNING:
            current_task.status = TaskStatus.FAILED
            current_task.error = "Task interrompida por reinício"
            current_task.finished_at = datetime.now().isoformat()
    
    job.save()
    print(f"[orchestrador] Job {job.id} marcado como interrompido")


def recover_interrupted_jobs(auto_retry: bool = False) -> dict:
    """
    Recupera jobs interrompidos.
    
    Args:
        auto_retry: Se True, tenta re-executar automaticamente
    
    Returns:
        Dict com estatísticas da recuperação
    """
    interrupted = find_interrupted_jobs()
    
    result = {
        "found": len(interrupted),
        "marked_failed": 0,
        "retried": 0,
        "jobs": []
    }
    
    for job in interrupted:
        job_info = {
            "id": job.id,
            "projeto": job.projeto,
            "task_index": job.current_task_index,
            "total_tasks": len(job.tasks)
        }
        
        if auto_retry:
            # Tenta continuar de onde parou
            print(f"[orchestrador] Retomando job {job.id} da task {job.current_task_index + 1}")
            try:
                resume_job(job)
                job_info["action"] = "retried"
                result["retried"] += 1
            except Exception as e:
                mark_job_interrupted(job, str(e))
                job_info["action"] = "failed"
                job_info["error"] = str(e)
                result["marked_failed"] += 1
        else:
            # Apenas marca como falho
            mark_job_interrupted(job)
            job_info["action"] = "marked_failed"
            result["marked_failed"] += 1
        
        result["jobs"].append(job_info)
    
    return result


def resume_job(job: Job):
    """
    Retoma um job interrompido da task atual.
    """
    from threading import Thread
    
    def _resume():
        job.status = JobStatus.RUNNING
        job.save()
        
        # Continua da task atual
        for i in range(job.current_task_index, len(job.tasks)):
            job.current_task_index = i
            task = job.tasks[i]
            
            # Pula tasks já completadas
            if task.status == TaskStatus.COMPLETED:
                continue
            
            print(f"[orchestrador] Retomando task {task.id}: {task.name}")
            # Carrega skills do tipo do job
            skills = CLI_CONFIG.get(job.tipo, {}).get("skills", [])
            success = execute_task(task, job, skills)
            
            if not success:
                job.status = JobStatus.FAILED
                job.error = f"Task {task.id} falhou"
                job.finished_at = datetime.now().isoformat()
                job.save()
                
                # Se faz parte de pipeline, marca como falho
                if job.pipeline_id:
                    pipeline = Pipeline.load(job.pipeline_id)
                    if pipeline:
                        pipeline.mark_job_failed(job.id)
                
                # Notifica callback
                if job.callback_session:
                    notify_callback(job.callback_session, job)
                return
        
        # Todas as tasks completaram
        job.status = JobStatus.COMPLETED
        job.finished_at = datetime.now().isoformat()
        job.save()
        
        # Se faz parte de um pipeline, avança para o próximo job
        pipeline = None
        if job.pipeline_id:
            pipeline = Pipeline.load(job.pipeline_id)
            if pipeline:
                pipeline.mark_job_completed(job.id)
                print(f"[orchestrador] Pipeline {job.pipeline_id} avançado para próximo job")
                
                # Executa próximo job se houver
                next_job = pipeline.get_current_job()
                if next_job and next_job.status == JobStatus.RUNNING:
                    print(f"[orchestrador] Iniciando próximo job: {next_job.id}")
                    resume_job(next_job)
        
        if job.callback_session:
            notify_callback(job.callback_session, job, pipeline)
        
        print(f"[orchestrador] Job {job.id} retomado e completado com sucesso!")
    
    # Executa em thread separada
    thread = Thread(target=_resume, daemon=True)
    thread.start()


def retry_job(job_id: str, from_beginning: bool = False) -> Job:
    """
    Re-executa um job falho.
    
    Args:
        job_id: ID do job a re-executar
        from_beginning: Se True, recomeça do zero. Se False, continua de onde parou.
    
    Returns:
        Job re-executado
    """
    job = Job.load(job_id)
    if not job:
        raise ValueError(f"Job {job_id} não encontrado")
    
    if job.status not in [JobStatus.FAILED, JobStatus.COMPLETED]:
        raise ValueError(f"Job {job_id} não pode ser re-executado (status: {job.status})")
    
    if from_beginning:
        # Reset completo
        job.current_task_index = 0
        job.error = ""
        job.output = ""
        for task in job.tasks:
            task.status = TaskStatus.PENDING
            task.started_at = None
            task.finished_at = None
            task.output = ""
            task.error = ""
            task.tests_passed = False
            task.build_passed = False
            task.review_passed = False
    else:
        # Continua de onde parou - reset apenas a task atual e seguintes
        for i in range(job.current_task_index, len(job.tasks)):
            task = job.tasks[i]
            if task.status == TaskStatus.FAILED:
                task.status = TaskStatus.PENDING
                task.error = ""
    
    job.status = JobStatus.PENDING
    job.started_at = datetime.now().isoformat()
    job.finished_at = None
    job.save()
    
    # Executa
    resume_job(job)
    
    return job


def execute_job(
    tipo: str,
    projeto: str,
    descricao: str,
    skills: list = None,
    tarefas: list = None,
    contexto: str = None,
    regras: list = None,
    entregaveis: list = None,
    callback_session: str = None,
    job_id: str = None,
    auto_review: bool = True,
    depends_on: str = None,
    pipeline_id: str = None,
    max_review_iterations: int = 5,
    codex_timeout: int = None
) -> Job:
    """
    Executa um job completo (com múltiplas tasks).
    Se depends_on for especificado, aguarda o job anterior completar.
    """
    
    # Cria job
    job = Job(
        id=job_id or str(uuid.uuid4())[:8],
        tipo=tipo,
        projeto=projeto,
        descricao=descricao,
        callback_session=callback_session,
        auto_review=auto_review,
        depends_on=depends_on,
        pipeline_id=pipeline_id,
        max_review_iterations=max_review_iterations,
        codex_timeout=codex_timeout
    )
    
    # Cria tasks a partir das tarefas
    if tarefas:
        for i, tarefa_desc in enumerate(tarefas):
            task = Task(
                id=f"{job.id}-t{i+1}",
                name=f"Task {i+1}",
                description=tarefa_desc
            )
            job.tasks.append(task)
    elif entregaveis:
        # Usa entregáveis como tasks
        for i, entregavel in enumerate(entregaveis):
            task = Task(
                id=f"{job.id}-t{i+1}",
                name=f"Entregável {i+1}",
                description=entregavel
            )
            job.tasks.append(task)
    else:
        # Uma única task com a descrição do job
        task = Task(
            id=f"{job.id}-t1",
            name="Implementação",
            description=descricao
        )
        job.tasks.append(task)
    
    # Verifica dependência
    if depends_on:
        parent_job = Job.load(depends_on)
        if parent_job and parent_job.status != JobStatus.COMPLETED:
            print(f"[orchestrador] Job {job.id} aguardando job {depends_on}")
            job.status = JobStatus.WAITING
            job.save()
            
            # Notifica que está aguardando
            if callback_session:
                notify_callback(callback_session, job)
            
            # Poll até o job pai completar (ou falhar)
            while True:
                time.sleep(5)
                parent_job = Job.load(depends_on)
                if not parent_job:
                    job.status = JobStatus.FAILED
                    job.error = f"Job pai {depends_on} não encontrado"
                    job.save()
                    return job
                
                if parent_job.status == JobStatus.COMPLETED:
                    print(f"[orchestrador] Job {depends_on} completado, iniciando {job.id}")
                    break
                elif parent_job.status == JobStatus.FAILED:
                    job.status = JobStatus.FAILED
                    job.error = f"Job pai {depends_on} falhou"
                    job.save()
                    return job
    
    # Inicia execução
    job.status = JobStatus.RUNNING
    job.started_at = datetime.now().isoformat()
    job.save()
    
    config = CLI_CONFIG.get(tipo, CLI_CONFIG["backend"])
    job.cli = config["cli"]
    
    if not skills:
        skills = config["skills"]
    
    print(f"[orchestrador] Job {job.id} iniciado com {len(job.tasks)} tasks")
    
    # Executa cada task sequencialmente
    all_tasks_passed = True
    for i, task in enumerate(job.tasks):
        job.current_task_index = i
        job.save()
        
        success = execute_task(task, job, skills, contexto, regras)
        
        if not success:
            all_tasks_passed = False
            job.status = JobStatus.FAILED
            job.error = f"Task {task.id} falhou: {task.error[:200]}"
            break
    
    # Finaliza job
    job.finished_at = datetime.now().isoformat()
    if all_tasks_passed:
        job.status = JobStatus.COMPLETED
        job.exit_code = 0
    
    job.save()
    
    # Atualiza pipeline se existir
    pipeline = None
    if pipeline_id:
        pipeline = Pipeline.load(pipeline_id)
        if pipeline:
            if job.status == JobStatus.COMPLETED:
                pipeline.mark_job_completed(job.id)
                
                # Inicia próximo job automaticamente
                next_job = pipeline.get_current_job()
                if next_job and next_job.status == JobStatus.RUNNING:
                    print(f"[orchestrador] Pipeline {pipeline_id}: iniciando próximo job {next_job.id}")
                    # Executa em thread separada para não bloquear
                    import threading
                    def run_next():
                        execute_job(
                            tipo=next_job.tipo,
                            projeto=next_job.projeto,
                            descricao=next_job.descricao,
                            callback_session=next_job.callback_session,
                            job_id=next_job.id,
                            auto_review=next_job.auto_review,
                            depends_on=None,  # Já completou, não precisa esperar
                            pipeline_id=next_job.pipeline_id,
                            max_review_iterations=next_job.max_review_iterations
                        )
                    thread = threading.Thread(target=run_next)
                    thread.daemon = True
                    thread.start()
            else:
                pipeline.mark_job_failed(job.id)
    
    # Notifica callback
    if callback_session:
        notify_callback(callback_session, job, pipeline)
    
    return job


def create_pipeline(jobs_data: list, callback_session: str = None) -> str:
    """
    Cria um pipeline de jobs sequenciais.
    jobs_data: lista de dicts com dados de cada job
    Retorna o ID do pipeline.
    """
    pipeline_id = str(uuid.uuid4())[:8]
    
    jobs = []
    prev_job_id = None
    
    for i, job_data in enumerate(jobs_data):
        job_id = f"{pipeline_id}-{i+1}"
        
        job = Job(
            id=job_id,
            tipo=job_data["tipo"],
            projeto=job_data["projeto"],
            descricao=job_data["descricao"],
            callback_session=callback_session,
            depends_on=prev_job_id,
            pipeline_id=pipeline_id,
            auto_review=job_data.get("auto_review", True),
            max_review_iterations=job_data.get("max_review_iterations", 5),
            codex_timeout=job_data.get("codex_timeout")
        )
        
        # Cria tasks
        tarefas = job_data.get("tarefas", job_data.get("entregaveis", []))
        if tarefas:
            for j, tarefa in enumerate(tarefas):
                task = Task(
                    id=f"{job_id}-t{j+1}",
                    name=f"Task {j+1}",
                    description=tarefa
                )
                job.tasks.append(task)
        else:
            task = Task(
                id=f"{job_id}-t1",
                name="Implementação",
                description=job_data["descricao"]
            )
            job.tasks.append(task)
        
        job.save()
        jobs.append(job)
        prev_job_id = job_id
    
    # Cria o pipeline
    pipeline = Pipeline(pipeline_id, jobs)
    pipeline.save()
    
    print(f"[orchestrador] Pipeline {pipeline_id} criado com {len(jobs)} jobs")
    
    # Inicia APENAS o primeiro job em background
    # Os próximos jobs serão iniciados automaticamente quando cada um completar
    import threading
    first_job = jobs[0]
    first_job.status = JobStatus.RUNNING
    first_job.save()
    
    def start_first_job():
        execute_job(
            tipo=first_job.tipo,
            projeto=first_job.projeto,
            descricao=first_job.descricao,
            callback_session=first_job.callback_session,
            job_id=first_job.id,
            auto_review=first_job.auto_review,
            depends_on=None,  # Primeiro job não tem dependência
            pipeline_id=first_job.pipeline_id,
            max_review_iterations=first_job.max_review_iterations
        )
    
    thread = threading.Thread(target=start_first_job)
    thread.daemon = True
    thread.start()
    
    return pipeline_id


def list_jobs() -> list:
    """Lista todos os jobs do SQLite"""
    jobs = db.list_all_jobs(limit=200)
    
    # Adiciona progress para cada job
    for job in jobs:
        tasks = job.get("tasks", [])
        current = job.get("current_task_index", 0)
        job["progress"] = f"{current}/{len(tasks)}"
    
    return jobs


def list_pipelines() -> list:
    """Lista todos os pipelines do SQLite"""
    return db.list_all_pipelines(limit=100)
