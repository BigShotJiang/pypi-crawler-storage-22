"""
Orchestrador - API HTTP (v3)

Novidades v3:
- Skills locais (não depende mais do OpenClaw)
- Endpoint /skills para listar skills disponíveis
- Pronto para empacotamento

Novidades v2:
- Endpoints para Tasks individuais
- Endpoints para Pipeline (jobs sequenciais)
- Sem timeout fixo
"""
import sys
from pathlib import Path
from typing import List, Optional
from contextlib import asynccontextmanager
import asyncio
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, str(Path(__file__).parent))

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from .config import HOST, PORT, CLI_CONFIG, VERSION
from .executor import (
    execute_job, create_pipeline, Job, Task, Pipeline,
    list_jobs, list_pipelines, JobStatus,
    find_interrupted_jobs, recover_interrupted_jobs, retry_job
)
from .skills import list_skills, get_skills_info


executor_pool = ThreadPoolExecutor(max_workers=5)


# ============ MODELS ============

class TaskRequest(BaseModel):
    name: str
    description: str


class ExecuteRequest(BaseModel):
    tipo: str
    projeto: str
    descricao: str
    skills: Optional[List[str]] = None
    tarefas: Optional[List[str]] = None  # Lista de descrições de tasks
    tasks: Optional[List[TaskRequest]] = None  # Tasks estruturadas
    contexto: Optional[str] = None
    regras: Optional[List[str]] = None
    entregaveis: Optional[List[str]] = None
    callback_session: Optional[str] = None
    auto_review: Optional[bool] = True
    max_review_iterations: Optional[int] = 5
    codex_timeout: Optional[int] = None  # Timeout em segundos (None = adaptável automático)


class PipelineJobRequest(BaseModel):
    tipo: str
    projeto: str
    descricao: str
    tarefas: Optional[List[str]] = None
    tasks: Optional[List[TaskRequest]] = None
    entregaveis: Optional[List[str]] = None
    auto_review: Optional[bool] = True
    max_review_iterations: Optional[int] = 5
    codex_timeout: Optional[int] = None  # Timeout em segundos (None = adaptável automático)


class PipelineRequest(BaseModel):
    jobs: List[PipelineJobRequest]
    callback_session: Optional[str] = None


class ExecuteResponse(BaseModel):
    job_id: str
    status: str
    message: str
    tasks_count: int = 1


class PipelineResponse(BaseModel):
    pipeline_id: str
    status: str
    message: str
    jobs_count: int


class TaskResponse(BaseModel):
    id: str
    name: str
    description: str
    status: str
    started_at: Optional[str]
    finished_at: Optional[str]
    tests_passed: bool
    build_passed: bool
    review_passed: bool


class JobResponse(BaseModel):
    id: str
    tipo: str
    projeto: str
    descricao: str
    status: str
    cli: str
    started_at: Optional[str]
    finished_at: Optional[str]
    exit_code: Optional[int]
    output: str
    error: str
    progress: str
    tasks: List[TaskResponse]
    current_task_index: int
    depends_on: Optional[str]
    pipeline_id: Optional[str]


class PipelineStatusResponse(BaseModel):
    id: str
    status: str
    current_job_index: int
    total_jobs: int
    created_at: Optional[str]
    finished_at: Optional[str]
    jobs: List[str]


# ============ LIFESPAN ============

@asynccontextmanager
async def lifespan(app: FastAPI):
    print(f"🚀 Orchestrador v2 iniciado em http://{HOST}:{PORT}")
    print(f"📦 Skills disponiveis: {len(list_skills())}")
    print(f"🔧 CLIs configurados: {list(CLI_CONFIG.keys())}")
    print(f"⚡ Features: Tasks + Pipeline + Auto Review Loop")
    yield
    executor_pool.shutdown(wait=False)
    print("👋 Orchestrador encerrado")


app = FastAPI(
    title="Orchestrador v2",
    description="API para orquestrar CLIs com Tasks, Pipeline e Auto Review Loop",
    version="2.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============ HELPERS ============

def run_job_sync(request: ExecuteRequest) -> Job:
    """Executa job de forma sincrona"""
    # Converte tasks para tarefas
    tarefas = request.tarefas or []
    if request.tasks:
        tarefas = [t.description for t in request.tasks]
    
    return execute_job(
        tipo=request.tipo,
        projeto=request.projeto,
        descricao=request.descricao,
        skills=request.skills,
        tarefas=tarefas,
        contexto=request.contexto,
        regras=request.regras,
        entregaveis=request.entregaveis,
        callback_session=request.callback_session,
        auto_review=request.auto_review,
        max_review_iterations=request.max_review_iterations,
        codex_timeout=request.codex_timeout
    )


def run_pipeline_sync(request: PipelineRequest) -> str:
    """Cria e executa pipeline de jobs"""
    jobs_data = []
    for job in request.jobs:
        tarefas = job.tarefas or []
        if job.tasks:
            tarefas = [t.description for t in job.tasks]
        
        jobs_data.append({
            "tipo": job.tipo,
            "projeto": job.projeto,
            "descricao": job.descricao,
            "tarefas": tarefas,
            "entregaveis": job.entregaveis,
            "auto_review": job.auto_review,
            "max_review_iterations": job.max_review_iterations,
            "codex_timeout": job.codex_timeout
        })
    
    return create_pipeline(jobs_data, request.callback_session)


# ============ ENDPOINTS ============

@app.post("/execute", response_model=ExecuteResponse)
async def execute(request: ExecuteRequest, background_tasks: BackgroundTasks):
    """
    Inicia execucao de um job com múltiplas tasks.
    
    Cada task é executada sequencialmente e testada automaticamente.
    O job só avança quando a task anterior passa nos checks.
    """
    if request.tipo not in CLI_CONFIG:
        raise HTTPException(
            status_code=400,
            detail=f"Tipo invalido: {request.tipo}. Validos: {list(CLI_CONFIG.keys())}"
        )

    # Conta tasks
    tasks_count = len(request.tarefas or request.tasks or request.entregaveis or [])
    
    # Executa em background
    background_tasks.add_task(run_job_sync, request)

    return ExecuteResponse(
        job_id="pending",  # Será gerado no background
        status="running",
        message=f"Job iniciado com {tasks_count} tasks. CLI: {CLI_CONFIG[request.tipo]['cli']}",
        tasks_count=tasks_count or 1
    )


@app.post("/execute/sync", response_model=JobResponse)
async def execute_sync(request: ExecuteRequest):
    """
    Executa job de forma sincrona (aguarda conclusao).
    Cuidado: pode demorar bastante (sem timeout fixo).
    """
    if request.tipo not in CLI_CONFIG:
        raise HTTPException(
            status_code=400,
            detail=f"Tipo invalido: {request.tipo}"
        )

    loop = asyncio.get_event_loop()
    job = await loop.run_in_executor(executor_pool, run_job_sync, request)

    return JobResponse(**job.to_dict())


@app.post("/pipeline", response_model=PipelineResponse)
async def create_pipeline_endpoint(request: PipelineRequest):
    """
    Cria um pipeline de jobs sequenciais.
    
    Cada job só inicia quando o anterior completar com sucesso.
    Todos os jobs passam por review + build-fix automático.
    """
    # Valida tipos
    for job in request.jobs:
        if job.tipo not in CLI_CONFIG:
            raise HTTPException(
                status_code=400,
                detail=f"Tipo invalido: {job.tipo}"
            )

    # Cria pipeline em background
    pipeline_id = run_pipeline_sync(request)

    return PipelineResponse(
        pipeline_id=pipeline_id,
        status="running",
        message=f"Pipeline iniciado com {len(request.jobs)} jobs",
        jobs_count=len(request.jobs)
    )


@app.get("/jobs", response_model=List[dict])
async def get_jobs():
    """Lista todos os jobs com suas tasks"""
    return list_jobs()


@app.get("/jobs/interrupted")
async def get_interrupted_jobs():
    """Lista jobs que foram interrompidos por reinício do orchestrador"""
    interrupted = find_interrupted_jobs()
    return {
        "count": len(interrupted),
        "jobs": [
            {
                "id": job.id,
                "projeto": job.projeto,
                "current_task": job.current_task_index + 1,
                "total_tasks": len(job.tasks),
                "started_at": job.started_at
            }
            for job in interrupted
        ]
    }


@app.get("/jobs/{job_id}", response_model=JobResponse)
async def get_job(job_id: str):
    """Retorna status detalhado de um job com suas tasks"""
    job = Job.load(job_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"Job {job_id} nao encontrado")
    return JobResponse(**job.to_dict())


@app.get("/pipelines", response_model=List[dict])
async def get_pipelines():
    """Lista todos os pipelines"""
    return list_pipelines()


@app.get("/pipelines/{pipeline_id}", response_model=PipelineStatusResponse)
async def get_pipeline(pipeline_id: str):
    """Retorna status de um pipeline"""
    pipeline = Pipeline.load(pipeline_id)
    if not pipeline:
        raise HTTPException(status_code=404, detail=f"Pipeline {pipeline_id} nao encontrado")
    return PipelineStatusResponse(**pipeline.to_dict())


@app.get("/skills")
async def get_skills(detailed: bool = False):
    """Lista skills disponiveis (local)"""
    if detailed:
        return get_skills_info()
    return list_skills()


@app.get("/types", response_model=dict)
async def get_types():
    """Lista tipos de job disponiveis"""
    return {
        tipo: {"cli": cfg["cli"], "skills": cfg["skills"]}
        for tipo, cfg in CLI_CONFIG.items()
    }


@app.get("/health")
async def health():
    """Health check"""
    return {
        "status": "ok",
        "service": "orchestrador",
        "version": VERSION,
        "features": ["tasks", "pipeline", "auto_review_loop", "local_skills"]
    }


@app.post("/jobs/{job_id}/retry")
async def retry_job_endpoint(job_id: str, from_beginning: bool = False):
    """
    Re-executa um job que falhou.
    
    Args:
        job_id: ID do job
        from_beginning: Se True, recomeça do zero. Se False, continua de onde parou.
    """
    try:
        job = retry_job(job_id, from_beginning=from_beginning)
        return {
            "message": f"Job {job_id} {'reiniciado' if from_beginning else 'retomado'}",
            "status": "running",
            "current_task": job.current_task_index + 1,
            "total_tasks": len(job.tasks)
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/recover")
async def recover_jobs(auto_retry: bool = False):
    """
    Recupera jobs interrompidos.
    
    Args:
        auto_retry: Se True, tenta re-executar automaticamente. Se False, apenas marca como falho.
    """
    result = recover_interrupted_jobs(auto_retry=auto_retry)
    return result


# ============ DATABASE ============

@app.get("/stats")
async def get_stats():
    """Retorna estatísticas do banco de dados"""
    import database as db_module
    return db_module.get_stats()


@app.post("/migrate")
async def migrate_from_json():
    """Migra dados de JSON para SQLite"""
    import database as db_module
    from .config import JOBS_DIR
    
    result = db_module.migrate_from_json(JOBS_DIR)
    return {
        "message": "Migração concluída",
        **result
    }


@app.post("/cleanup")
async def cleanup_old_jobs(days: int = 30):
    """Remove jobs antigos (completados/falhos)"""
    import database as db_module
    
    deleted = db_module.cleanup_old_jobs(days=days)
    return {
        "message": f"Removidos {deleted} jobs antigos (>{days} dias)",
        "deleted": deleted
    }


# ============ STARTUP ============

@app.on_event("startup")
async def startup_event():
    """Executa ao iniciar o orchestrador"""
    # Verifica jobs interrompidos
    interrupted = find_interrupted_jobs()
    if interrupted:
        print(f"[orchestrador] ⚠️ Encontrados {len(interrupted)} jobs interrompidos")
        for job in interrupted:
            print(f"  - {job.id}: {job.projeto} (task {job.current_task_index + 1}/{len(job.tasks)})")
        print(f"[orchestrador] Use POST /recover para recuperá-los")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=HOST, port=PORT)
