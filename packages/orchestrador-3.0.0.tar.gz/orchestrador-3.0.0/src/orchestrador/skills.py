"""
Orchestrador v3 - Carregador de Skills (LOCAL)

Skills agora são arquivos .md diretamente na pasta skills/
Não depende mais do OpenClaw.
"""
from pathlib import Path
from typing import List
from .config import SKILLS_DIR


def load_skill(name: str) -> str:
    """Carrega conteudo de uma skill local"""
    # Tenta nome.md diretamente
    skill_file = SKILLS_DIR / f"{name}.md"
    if skill_file.exists():
        return skill_file.read_text(encoding="utf-8")
    
    # Fallback: tenta sem extensão (compatibilidade)
    skill_file_alt = SKILLS_DIR / name
    if skill_file_alt.exists():
        return skill_file_alt.read_text(encoding="utf-8")
    
    return f"[Skill '{name}' nao encontrada em {SKILLS_DIR}]"


def load_skills(names: List[str]) -> str:
    """Carrega e formata multiplas skills"""
    content = []
    for name in names:
        skill_content = load_skill(name)
        if not skill_content.startswith("[Skill"):
            content.append(f"## SKILL: {name}\n{skill_content}")
    return "\n\n".join(content)


def list_skills() -> List[str]:
    """Lista skills disponiveis"""
    if not SKILLS_DIR.exists():
        return []
    return [
        f.stem for f in SKILLS_DIR.glob("*.md")
        if f.is_file()
    ]


def get_skills_info() -> dict:
    """Retorna info sobre skills disponiveis"""
    skills = list_skills()
    return {
        "directory": str(SKILLS_DIR),
        "count": len(skills),
        "available": skills
    }
