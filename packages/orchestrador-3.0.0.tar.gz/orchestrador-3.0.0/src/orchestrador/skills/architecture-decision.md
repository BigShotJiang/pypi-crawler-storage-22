---
name: architecture-decision
description: Help choose the right architecture pattern for a project - DDD, Clean Architecture, Hexagonal, Layered, or Microservices. Analyzes requirements and recommends the best approach with trade-offs.
triggers:
  - "which architecture"
  - "ddd vs clean architecture"
  - "hexagonal architecture"
  - "choose architecture"
  - "what pattern to use"
  - "architectural pattern"
---

# Architecture Decision Skill

Choose the right architectural pattern for your project.

## Architecture Patterns

### 1. Clean Architecture (Recommended for most web apps)

**Structure:**
```
src/
├── domains/          # Entities, business rules (framework-agnostic)
├── features/         # Use cases, features
├── shared/           # Interfaces, utilities
└── infrastructure/   # DB, HTTP, external services
```

**Best for:**
- Web applications (Next.js, React, Node.js)
- APIs RESTful
- Projects that may change frameworks
- Team sizes: 2-20 developers

**Pros:**
- ✅ Framework independence (domains are pure)
- ✅ Testability (business logic without React/Express)
- ✅ Clear separation of concerns
- ✅ Easy to understand and maintain
- ✅ Good for rapid development

**Cons:**
- ❌ Can be overkill for simple CRUD apps
- ❌ More boilerplate than simple MVC

**When to use:**
- Most web applications
- When you want testable business logic
- When framework might change

---

### 2. Domain-Driven Design (DDD)

**Structure:**
```
src/
├── bounded-contexts/
│   ├── order/
│   │   ├── domain/       # Aggregates, entities, value objects
│   │   ├── application/  # Services, DTOs
│   │   ├── infrastructure/
│   │   └── interfaces/   # Controllers, presenters
│   └── inventory/
├── shared-kernel/
└── anti-corruption-layers/
```

**Best for:**
- Complex business domains
- Enterprise applications
- Systems with multiple bounded contexts
- Team sizes: 10+ developers

**Pros:**
- ✅ Handles complex business logic
- ✅ Ubiquitous language with domain experts
- ✅ Clear boundaries between contexts
- ✅ Long-term maintainability for complex systems

**Cons:**
- ❌ Steep learning curve
- ❌ Overkill for simple applications
- ❌ Requires deep domain understanding
- ❌ More ceremony and boilerplate

**When to use:**
- Complex business rules (finance, healthcare, logistics)
- Multiple teams working on different contexts
- Long-lived enterprise systems

---

### 3. Hexagonal Architecture (Ports & Adapters)

**Structure:**
```
src/
├── domain/           # Business logic (inner hexagon)
├── application/      # Use cases
├── ports/            # Interfaces (driving + driven)
└── adapters/         # Implementations
    ├── inbound/      # HTTP, CLI, Events
    └── outbound/     # DB, Email, External APIs
```

**Best for:**
- Systems with multiple interfaces (HTTP, CLI, Events)
- When testing without infrastructure is critical
- Microservices
- Team sizes: 3-15 developers

**Pros:**
- ✅ Excellent testability (swap adapters easily)
- ✅ Multiple interfaces to same domain
- ✅ Clear dependency direction (inward)
- ✅ Infrastructure can be swapped

**Cons:**
- ❌ More complex than Clean Arch
- ❌ Learning curve for "ports/adapters" terminology
- ❌ Can be verbose

**When to use:**
- Multiple input sources (HTTP + CLI + Queue)
- Heavy testing requirements
- Microservices architecture

---

### 4. Layered Architecture (Traditional)

**Structure:**
```
src/
├── presentation/     # Controllers, Views
├── application/      # Services, DTOs
├── domain/           # Business logic
└── infrastructure/   # DB, External services
```

**Best for:**
- Simple CRUD applications
- Rapid prototyping
- Small teams (1-5 developers)
- Short-lived projects

**Pros:**
- ✅ Simple to understand
- ✅ Quick to implement
- ✅ Well-known pattern

**Cons:**
- ❌ Business logic coupled to framework
- ❌ Harder to test
- ❌ Can become "big ball of mud"

**When to use:**
- Simple applications
- MVPs and prototypes
- Short deadlines

---

### 5. Microservices Architecture

**Structure:**
```
services/
├── api-gateway/
├── user-service/
├── order-service/
├── inventory-service/
└── notification-service/
```

**Best for:**
- Large-scale systems
- Multiple teams (20+ developers)
- Independent deployment requirements
- Different scaling needs per service

**Pros:**
- ✅ Independent deployment
- ✅ Technology diversity per service
- ✅ Fault isolation
- ✅ Scalability per service

**Cons:**
- ❌ Distributed system complexity
- ❌ Network latency
- ❌ Data consistency challenges
- ❌ Operational overhead

**When to use:**
- Large organizations
- Different scaling requirements
- Multiple autonomous teams
- NOT for: small teams, simple applications

---

## Decision Matrix

| Factor | Clean Arch | DDD | Hexagonal | Layered | Microservices |
|--------|-----------|-----|-----------|---------|---------------|
| **Complexity** | Medium | High | Medium-High | Low | High |
| **Team Size** | 2-20 | 10+ | 3-15 | 1-5 | 20+ |
| **Testability** | High | High | Very High | Medium | Medium |
| **Learning Curve** | Low-Med | High | Medium | Low | High |
| **Framework Coupling** | Low | Low | Very Low | High | Low |
| **Best For** | Web Apps | Complex Domain | Multi-Interface | Simple CRUD | Large Scale |

---

## Decision Flowchart

```
Start
  │
  ├─ Simple CRUD? ──YES──► Layered Architecture
  │
  ├─ Large team (20+) with complex domain? ──YES──► DDD or Microservices
  │
  ├─ Multiple interfaces (HTTP + CLI + Events)? ──YES──► Hexagonal
  │
  ├─ Web app, API, need testability? ──YES──► Clean Architecture
  │
  └─ Default ──► Clean Architecture
```

---

## Application Examples

### E-commerce Platform

**Small-Medium (1-10 devs):**
→ **Clean Architecture**
- Domains: Product, Order, User, Cart
- Features: Checkout, Search, Auth
- Easy to test, framework-agnostic

**Large (20+ devs, complex inventory):**
→ **DDD with Bounded Contexts**
- Contexts: Catalog, Order, Inventory, Payment, Shipping
- Complex business rules
- Multiple teams

### Task Management App (like password-generator)

→ **Clean Architecture**
- Domains: Task, User, Project
- Simple business logic
- Easy to understand and maintain

### Banking System

→ **DDD**
- Complex business rules
- Regulatory compliance
- Multiple bounded contexts
- Long-term maintenance

### CLI + Web + API Tool

→ **Hexagonal Architecture**
- Same domain logic
- Multiple interfaces
- Highly testable

---

## Implementation Guide

### Clean Architecture (Recommended Default)

```typescript
// 1. Define Repository Interface (Domain)
// domains/user/repository.ts
export interface UserRepository {
  findById(id: string): Promise<User | null>
  create(data: CreateUserDto): Promise<User>
}

// 2. Implement Business Logic (Domain)
// domains/user/service.ts
export class UserService {
  constructor(private repo: UserRepository) {}
  
  async register(dto: CreateUserDto) {
    // Business logic here - framework agnostic!
    const existing = await this.repo.findByEmail(dto.email)
    if (existing) throw new Error('Email exists')
    
    return this.repo.create({
      ...dto,
      password: await hash(dto.password),
    })
  }
}

// 3. Implement Repository (Infrastructure)
// infrastructure/database/prisma-user-repo.ts
export class PrismaUserRepository implements UserRepository {
  constructor(private prisma: PrismaClient) {}
  
  async findById(id: string) {
    return this.prisma.user.findUnique({ where: { id } })
  }
}

// 4. Use in Application (Feature)
// features/auth/api/register/route.ts
const userService = new UserService(new PrismaUserRepository(prisma))

export async function POST(req: Request) {
  const user = await userService.register(await req.json())
  return Response.json(user)
}
```

### Testing Clean Architecture

```typescript
// domains/user/service.test.ts
// NO React, NO Next.js, NO Database needed!

describe('UserService', () => {
  it('registers user with hashed password', async () => {
    const mockRepo = new MockUserRepository() // In-memory
    const service = new UserService(mockRepo)
    
    const user = await service.register({
      email: 'test@example.com',
      password: 'plain',
    })
    
    expect(user.password).not.toBe('plain')
    expect(await mockRepo.findByEmail('test@example.com')).toBeDefined()
  })
})
```

---

## Output Format

When asked, provide:

```
## Architecture Recommendation

**Recommended Pattern:** [Pattern Name]

**Rationale:**
- [Why this pattern fits]
- [Key benefits for your use case]

**Alternative Considered:**
- [Other pattern]: [Why rejected]

**Project Structure:**
```
[Directory structure]
```

**Key Principles:**
1. [Principle 1]
2. [Principle 2]

**Next Steps:**
- Use [skill-name] to implement
```

---

## Common Mistakes to Avoid

❌ **Over-engineering:** Using DDD for a simple TODO app  
❌ **Under-engineering:** Using Layered for complex financial system  
❌ **Mixing patterns:** Clean Arch structure with DDD terminology (confusing)  
❌ **Framework coupling:** Business logic depending on React/Express  
❌ **No tests:** Architecture is useless without tests  

✅ **Right-sizing:** Match complexity to project needs  
✅ **Consistency:** Stick to one pattern per project  
✅ **Testability:** Always verify business logic without framework  
✅ **Evolution:** Start simple, evolve to complex if needed
