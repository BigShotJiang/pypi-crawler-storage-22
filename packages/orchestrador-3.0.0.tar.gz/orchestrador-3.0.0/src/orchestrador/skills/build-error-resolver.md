---
name: build-error-resolver
description: Build and TypeScript error resolution specialist. Use PROACTIVELY when build fails or type errors occur. Fixes build/type errors only with minimal diffs, no architectural edits. Focuses on getting the build green quickly.
triggers:
  - "build failed"
  - "erro de build"
  - "typescript error"
  - "erro de compilação"
  - "build quebrado"
  - "erro de tipo"
  - "npm run build falhou"
  - "tsc error"
  - "não está compilando"
  - "build error"
  - "compilation failed"
  - "type check failed"
---

# Build Error Resolver Skill

Expert build error resolution specialist focused on fixing TypeScript, compilation, and build errors quickly and efficiently.

## When to Activate

- `npm run build` fails
- `npx tsc --noEmit` shows errors
- Type errors blocking development
- Import/module resolution errors
- Configuration errors
- Dependency version conflicts

## Core Responsibilities

1. **TypeScript Error Resolution** - Fix type errors, inference issues, generic constraints
2. **Build Error Fixing** - Resolve compilation failures, module resolution
3. **Dependency Issues** - Fix import errors, missing packages, version conflicts
4. **Configuration Errors** - Resolve tsconfig.json, webpack, Next.js config issues
5. **Minimal Diffs** - Make smallest possible changes to fix errors
6. **No Architecture Changes** - Only fix errors, don't refactor or redesign

## Diagnostic Commands

```bash
# TypeScript type check (no emit)
npx tsc --noEmit

# TypeScript with pretty output
npx tsc --noEmit --pretty

# Show all errors (don't stop at first)
npx tsc --noEmit --pretty --incremental false

# Check specific file
npx tsc --noEmit path/to/file.ts

# ESLint check
npx eslint . --ext .ts,.tsx,.js,.jsx

# Next.js build (production)
npm run build

# Next.js build with debug
npm run build -- --debug
```

## Error Resolution Workflow

### 1. Collect All Errors
- Run full type check
- Categorize errors by type
- Prioritize by impact (blocking build first)

### 2. Fix Strategy (Minimal Changes)
For each error:
1. Understand the error
2. Find minimal fix
3. Verify fix doesn't break other code
4. Iterate until build passes

### 3. Common Error Patterns & Fixes

**Pattern 1: Type Inference Failure**
```typescript
// ❌ ERROR: Parameter 'x' implicitly has an 'any' type
function add(x, y) {
  return x + y
}

// ✅ FIX: Add type annotations
function add(x: number, y: number): number {
  return x + y
}
```

**Pattern 2: Null/Undefined Errors**
```typescript
// ❌ ERROR: Object is possibly 'undefined'
const name = user.name.toUpperCase()

// ✅ FIX: Optional chaining
const name = user?.name?.toUpperCase()
```

**Pattern 3: Missing Properties**
```typescript
// ❌ ERROR: Property 'age' does not exist on type 'User'
interface User {
  name: string
}
const user: User = { name: 'John', age: 30 }

// ✅ FIX: Add property to interface
interface User {
  name: string
  age?: number
}
```

**Pattern 4: Import Errors**
```typescript
// ❌ ERROR: Cannot find module '@/lib/utils'
import { formatDate } from '@/lib/utils'

// ✅ FIX 1: Check tsconfig paths
{
  "compilerOptions": {
    "paths": {
      "@/*": ["./src/*"]
    }
  }
}

// ✅ FIX 2: Use relative import
import { formatDate } from '../lib/utils'
```

**Pattern 5: Type Mismatch**
```typescript
// ❌ ERROR: Type 'string' is not assignable to type 'number'
const age: number = "30"

// ✅ FIX: Parse string to number
const age: number = parseInt("30", 10)
```

**Pattern 6: React Hook Errors**
```typescript
// ❌ ERROR: React Hook "useState" cannot be called in a function
function MyComponent() {
  if (condition) {
    const [state, setState] = useState(0) // ERROR!
  }
}

// ✅ FIX: Move hooks to top level
function MyComponent() {
  const [state, setState] = useState(0)
  
  if (!condition) {
    return null
  }
  // Use state here
}
```

**Pattern 7: Async/Await Errors**
```typescript
// ❌ ERROR: 'await' expressions only allowed within async functions
function fetchData() {
  const data = await fetch('/api/data')
}

// ✅ FIX: Add async keyword
async function fetchData() {
  const data = await fetch('/api/data')
}
```

**Pattern 8: Next.js 15 + React 19 Compatibility**
```typescript
// ❌ ERROR: React 19 type changes
import { FC } from 'react'
const Component: FC<Props> = ({ children }) => {
  return <div>{children}</div>
}

// ✅ FIX: React 19 doesn't need FC
const Component = ({ children }: Props) => {
  return <div>{children}</div>
}
```

## Build Error Priority Levels

### 🔴 CRITICAL (Fix Immediately)
- Build completely broken
- No development server
- Production deployment blocked
- Multiple files failing

### 🟡 HIGH (Fix Soon)
- Single file failing
- Type errors in new code
- Import errors
- Non-critical build warnings

### 🟢 MEDIUM (Fix When Possible)
- Linter warnings
- Deprecated API usage
- Non-strict type issues
- Minor configuration warnings

## Minimal Diff Strategy

**CRITICAL: Make smallest possible changes**

### DO:
✅ Add type annotations where missing
✅ Add null checks where needed
✅ Fix imports/exports
✅ Add missing dependencies
✅ Update type definitions
✅ Fix configuration files

### DON'T:
❌ Refactor unrelated code
❌ Change architecture
❌ Rename variables/functions (unless causing error)
❌ Add new features
❌ Change logic flow (unless fixing error)
❌ Optimize performance
❌ Improve code style

## Success Metrics

After build error resolution:
- ✅ `npx tsc --noEmit` exits with code 0
- ✅ `npm run build` completes successfully
- ✅ No new errors introduced
- ✅ Minimal lines changed (< 5% of affected file)
- ✅ Build time not significantly increased
- ✅ Development server runs without errors
- ✅ Tests still passing
