---
name: database-reviewer
description: PostgreSQL database specialist for query optimization, schema design, security, and performance. Use PROACTIVELY when writing SQL, creating migrations, designing schemas, or troubleshooting database performance. Incorporates Supabase best practices.
triggers:
  - "revisar query"
  - "otimizar banco de dados"
  - "criar migration"
  - "schema design"
  - "revisar SQL"
  - "database review"
  - "query optimization"
  - "criar índice"
  - "database schema"
  - "row level security"
  - "supabase database"
  - "postgresql review"
---

# Database Reviewer Skill

Expert PostgreSQL database specialist focused on query optimization, schema design, security, and performance.

## When to Activate

- Writing SQL queries or migrations
- Designing database schemas
- Troubleshooting slow queries
- Implementing Row Level Security
- Setting up connection pooling
- Optimizing database performance

## Core Responsibilities

1. **Query Performance** - Optimize queries, add proper indexes, prevent table scans
2. **Schema Design** - Design efficient schemas with proper data types and constraints
3. **Security & RLS** - Implement Row Level Security, least privilege access
4. **Connection Management** - Configure pooling, timeouts, limits
5. **Concurrency** - Prevent deadlocks, optimize locking strategies
6. **Monitoring** - Set up query analysis and performance tracking

## Index Patterns

### 1. Add Indexes on WHERE and JOIN Columns
```sql
-- ❌ BAD: No index on foreign key
CREATE TABLE orders (
  id bigint PRIMARY KEY,
  customer_id bigint REFERENCES customers(id)
);

-- ✅ GOOD: Index on foreign key
CREATE TABLE orders (
  id bigint PRIMARY KEY,
  customer_id bigint REFERENCES customers(id)
);
CREATE INDEX orders_customer_id_idx ON orders (customer_id);
```

### 2. Choose the Right Index Type

| Index Type | Use Case | Operators |
|------------|----------|-----------|
| **B-tree** (default) | Equality, range | `=`, `<`, `>`, `BETWEEN`, `IN` |
| **GIN** | Arrays, JSONB, full-text | `@>`, `?`, `?&`, `?\|`, `@@` |
| **BRIN** | Large time-series tables | Range queries on sorted data |

### 3. Composite Indexes for Multi-Column Queries
```sql
-- ❌ BAD: Separate indexes
CREATE INDEX orders_status_idx ON orders (status);
CREATE INDEX orders_created_idx ON orders (created_at);

-- ✅ GOOD: Composite index (equality columns first, then range)
CREATE INDEX orders_status_created_idx ON orders (status, created_at);
```

### 4. Covering Indexes (Index-Only Scans)
```sql
-- ❌ BAD: Must fetch name from table
CREATE INDEX users_email_idx ON users (email);
SELECT email, name FROM users WHERE email = 'user@example.com';

-- ✅ GOOD: All columns in index
CREATE INDEX users_email_idx ON users (email) INCLUDE (name, created_at);
```

### 5. Partial Indexes for Filtered Queries
```sql
-- ❌ BAD: Full index includes deleted rows
CREATE INDEX users_email_idx ON users (email);

-- ✅ GOOD: Partial index excludes deleted rows
CREATE INDEX users_active_email_idx ON users (email) WHERE deleted_at IS NULL;
```

## Schema Design Patterns

### Data Type Selection
```sql
-- ❌ BAD: Poor type choices
CREATE TABLE users (
  id int,                           -- Overflows at 2.1B
  email varchar(255),               -- Artificial limit
  created_at timestamp,             -- No timezone
  is_active varchar(5),             -- Should be boolean
  balance float                     -- Precision loss
);

-- ✅ GOOD: Proper types
CREATE TABLE users (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  email text NOT NULL,
  created_at timestamptz DEFAULT now(),
  is_active boolean DEFAULT true,
  balance numeric(10,2)
);
```

### Primary Key Strategy
```sql
-- ✅ Single database: IDENTITY (default, recommended)
CREATE TABLE users (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY
);

-- ✅ Distributed systems: UUIDv7 (time-ordered)
CREATE EXTENSION IF NOT EXISTS pg_uuidv7;
CREATE TABLE orders (
  id uuid DEFAULT uuid_generate_v7() PRIMARY KEY
);

-- ❌ AVOID: Random UUIDs cause index fragmentation
CREATE TABLE events (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY
);
```

## Security & Row Level Security (RLS)

### Enable RLS for Multi-Tenant Data
```sql
-- ❌ BAD: Application-only filtering
SELECT * FROM orders WHERE user_id = $current_user_id;
-- Bug means all orders exposed!

-- ✅ GOOD: Database-enforced RLS
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders FORCE ROW LEVEL SECURITY;

CREATE POLICY orders_user_policy ON orders
  FOR ALL
  TO authenticated
  USING (user_id = auth.uid());
```

### Optimize RLS Policies
```sql
-- ❌ BAD: Function called per row
CREATE POLICY orders_policy ON orders
  USING (auth.uid() = user_id);  -- Called 1M times for 1M rows!

-- ✅ GOOD: Wrap in SELECT (cached, called once)
CREATE POLICY orders_policy ON orders
  USING ((SELECT auth.uid()) = user_id);  -- 100x faster

-- Always index RLS policy columns
CREATE INDEX orders_user_id_idx ON orders (user_id);
```

## Data Access Patterns

### Batch Inserts
```sql
-- ❌ BAD: Individual inserts
INSERT INTO events (user_id, action) VALUES (1, 'click');
INSERT INTO events (user_id, action) VALUES (2, 'view');

-- ✅ GOOD: Batch insert
INSERT INTO events (user_id, action) VALUES
  (1, 'click'),
  (2, 'view'),
  (3, 'click');

-- ✅ BEST: COPY for large datasets
COPY events (user_id, action) FROM '/path/to/data.csv' WITH (FORMAT csv);
```

### Cursor-Based Pagination
```sql
-- ❌ BAD: OFFSET gets slower with depth
SELECT * FROM products ORDER BY id LIMIT 20 OFFSET 199980;

-- ✅ GOOD: Cursor-based (always fast)
SELECT * FROM products WHERE id > 199980 ORDER BY id LIMIT 20;
```

### UPSERT for Insert-or-Update
```sql
-- ❌ BAD: Race condition
SELECT * FROM settings WHERE user_id = 123 AND key = 'theme';
-- Both threads find nothing, both insert, one fails

-- ✅ GOOD: Atomic UPSERT
INSERT INTO settings (user_id, key, value)
VALUES (123, 'theme', 'dark')
ON CONFLICT (user_id, key)
DO UPDATE SET value = EXCLUDED.value, updated_at = now()
RETURNING *;
```

## Review Checklist

### Before Approving Database Changes:
- [ ] All WHERE/JOIN columns indexed
- [ ] Composite indexes in correct column order
- [ ] Proper data types (bigint, text, timestamptz, numeric)
- [ ] RLS enabled on multi-tenant tables
- [ ] RLS policies use `(SELECT auth.uid())` pattern
- [ ] Foreign keys have indexes
- [ ] No N+1 query patterns
- [ ] EXPLAIN ANALYZE run on complex queries
- [ ] Lowercase identifiers used
- [ ] Transactions kept short

---

**Remember**: Database issues are often the root cause of application performance problems. Optimize queries and schema design early.
