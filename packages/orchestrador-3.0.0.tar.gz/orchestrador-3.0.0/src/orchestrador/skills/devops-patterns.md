---
name: devops-patterns
description: DevOps patterns for Docker, CI/CD, deployment, and infrastructure best practices for Node.js/Next.js applications.
triggers:
  - "devops patterns"
  - "docker setup"
  - "ci/cd pipeline"
  - "deployment patterns"
  - "kubernetes"
  - "dockerfile"
  - "github actions"
  - "vercel deploy"
  - "infraestrutura"
  - "deploy automation"
  - "container patterns"
  - "pipeline config"
---

# DevOps Patterns Skill

DevOps patterns for Docker, CI/CD, deployment, and infrastructure best practices.

## When to Activate

- Setting up Docker containers
- Creating CI/CD pipelines
- Configuring deployments
- Setting up infrastructure
- Automating workflows
- Managing environments

## Docker Patterns

### Multi-Stage Dockerfile for Next.js
```dockerfile
# Stage 1: Dependencies
FROM node:20-alpine AS deps
RUN apk add --no-cache libc6-compat
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

# Stage 2: Builder
FROM node:20-alpine AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm run build

# Stage 3: Runner
FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production

# Copy only necessary files
COPY --from=builder /app/public ./public
COPY --from=builder /app/.next/standalone ./
COPY --from=builder /app/.next/static ./.next/static

EXPOSE 3000
ENV PORT=3000
ENV HOSTNAME="0.0.0.0"

CMD ["node", "server.js"]
```

### Docker Compose for Development
```yaml
version: '3.8'

services:
  app:
    build:
      context: .
      dockerfile: Dockerfile.dev
    ports:
      - "3000:3000"
    volumes:
      - .:/app
      - /app/node_modules
    environment:
      - NODE_ENV=development
      - DATABASE_URL=postgresql://user:pass@db:5432/dbname
    depends_on:
      - db
      - redis

  db:
    image: postgres:15-alpine
    environment:
      POSTGRES_USER: user
      POSTGRES_PASSWORD: pass
      POSTGRES_DB: dbname
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data

volumes:
  postgres_data:
  redis_data:
```

## CI/CD Patterns

### GitHub Actions - Next.js CI/CD
```yaml
name: CI/CD Pipeline

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Run linter
        run: npm run lint
      
      - name: Run type check
        run: npx tsc --noEmit
      
      - name: Run tests
        run: npm test -- --coverage
      
      - name: Upload coverage
        uses: codecov/codecov-action@v3

  build:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Build application
        run: npm run build
        env:
          DATABASE_URL: ${{ secrets.DATABASE_URL }}

  deploy:
    needs: [test, build]
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - name: Deploy to Vercel
        uses: vercel/action-deploy@v1
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
          vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
```

### Environment-Based Deployment
```yaml
# Production deployment
- name: Deploy Production
  if: github.ref == 'refs/heads/main'
  run: vercel --prod --token=${{ secrets.VERCEL_TOKEN }}

# Staging deployment
- name: Deploy Staging
  if: github.ref == 'refs/heads/develop'
  run: vercel --token=${{ secrets.VERCEL_TOKEN }}
```

## Environment Configuration

### Environment Variables Strategy
```
.env.local          # Local development (never committed)
.env.development    # Development environment
.env.staging        # Staging environment
.env.production     # Production environment
```

### Environment Validation
```typescript
// lib/env.ts
import { z } from 'zod'

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']),
  DATABASE_URL: z.string().url(),
  NEXTAUTH_SECRET: z.string().min(32),
  NEXTAUTH_URL: z.string().url(),
})

export const env = envSchema.parse(process.env)
```

## Health Checks

### Health Check Endpoint
```typescript
// app/api/health/route.ts
import { NextResponse } from 'next/server'

export async function GET() {
  const checks = {
    database: await checkDatabase(),
    redis: await checkRedis(),
    timestamp: new Date().toISOString()
  }
  
  const allHealthy = Object.values(checks).every(c => c.status === 'ok')
  
  return NextResponse.json(
    checks,
    { status: allHealthy ? 200 : 503 }
  )
}

async function checkDatabase() {
  try {
    await prisma.$queryRaw`SELECT 1`
    return { status: 'ok' }
  } catch (error) {
    return { status: 'error', message: (error as Error).message }
  }
}
```

## Monitoring & Logging

### Structured Logging
```typescript
import winston from 'winston'

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' })
  ]
})

export default logger
```

### Application Metrics
```typescript
// lib/metrics.ts
import { Counter, Histogram, register } from 'prom-client'

export const httpRequestDuration = new Histogram({
  name: 'http_request_duration_seconds',
  help: 'Duration of HTTP requests in seconds',
  labelNames: ['method', 'route', 'status_code'],
  buckets: [0.1, 0.5, 1, 2, 5]
})

export const httpRequestsTotal = new Counter({
  name: 'http_requests_total',
  help: 'Total number of HTTP requests',
  labelNames: ['method', 'route', 'status_code']
})

// Metrics endpoint
export async function GET() {
  return new Response(await register.metrics(), {
    headers: { 'Content-Type': register.contentType }
  })
}
```

## Security in CI/CD

### Secrets Management
```yaml
# .github/workflows/deploy.yml
- name: Deploy
  env:
    DATABASE_URL: ${{ secrets.DATABASE_URL }}
    API_KEY: ${{ secrets.API_KEY }}
  run: |
    echo "Deploying with secure secrets..."
```

### Dependency Scanning
```yaml
- name: Run security audit
  run: npm audit --audit-level=moderate

- name: Check for outdated dependencies
  run: npm outdated

- name: Run Snyk security scan
  uses: snyk/actions/node@master
  env:
    SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
```

## Deployment Strategies

### Blue-Green Deployment
```bash
# Deploy to green environment
vercel --target=production --meta version=green

# Switch traffic after health check
# If health check fails, rollback to blue
```

### Feature Flags
```typescript
// lib/feature-flags.ts
export function isFeatureEnabled(feature: string): boolean {
  const flags = process.env.FEATURE_FLAGS?.split(',') || []
  return flags.includes(feature)
}

// Usage
if (isFeatureEnabled('new-dashboard')) {
  return <NewDashboard />
}
return <OldDashboard />
```

## Backup & Recovery

### Database Backup Script
```bash
#!/bin/bash
# backup.sh

BACKUP_DIR="/backups"
DATE=$(date +%Y%m%d_%H%M%S)
FILENAME="backup_${DATE}.sql"

# Create backup
pg_dump $DATABASE_URL > "$BACKUP_DIR/$FILENAME"

# Compress
gzip "$BACKUP_DIR/$FILENAME"

# Upload to S3
aws s3 cp "$BACKUP_DIR/$FILENAME.gz" s3://my-backups/

# Clean old backups (keep last 7 days)
find $BACKUP_DIR -name "backup_*.sql.gz" -mtime +7 -delete
```

## Best Practices

1. **Immutable Infrastructure**: Treat infrastructure as code
2. **Automated Testing**: Run tests on every commit
3. **Secret Management**: Never commit secrets, use vaults
4. **Monitoring**: Track metrics and set up alerts
5. **Rollback Strategy**: Always have a rollback plan
6. **Environment Parity**: Keep dev/staging/prod as similar as possible
