---
name: doc-updater
description: Documentation and codemap specialist. Use PROACTIVELY for updating codemaps and documentation. Generates docs/CODEMAPS/*, updates READMEs and guides.
triggers:
  - "atualizar documentação"
  - "update docs"
  - "gerar codemap"
  - "atualizar README"
  - "documentar código"
  - "docs:"
  - "criar documentação"
  - "update codemaps"
  - "document architecture"
  - "atualizar CLAUDE.md"
  - "sync documentation"
  - "update guides"
---

# Documentation & Codemap Specialist Skill

Documentation specialist focused on keeping codemaps and documentation current with the codebase.

## When to Activate

- After completing major features
- When architecture changes
- To create project documentation
- To update outdated docs
- When onboarding new developers
- Before releases

## Core Responsibilities

1. **Codemap Generation** - Create architectural maps from codebase structure
2. **Documentation Updates** - Refresh READMEs and guides from code
3. **AST Analysis** - Use TypeScript compiler API to understand structure
4. **Dependency Mapping** - Track imports/exports across modules
5. **Documentation Quality** - Ensure docs match reality

## Codemap Generation Workflow

### 1. Repository Structure Analysis
- Identify all workspaces/packages
- Map directory structure
- Find entry points (apps/*, packages/*, services/*)
- Detect framework patterns (Next.js, Node.js, etc.)

### 2. Generate Codemaps
```
docs/CODEMAPS/
├── INDEX.md              # Overview of all areas
├── frontend.md           # Frontend structure
├── backend.md            # Backend/API structure
├── database.md           # Database schema
├── integrations.md       # External services
└── workers.md            # Background jobs
```

### 3. Codemap Format
```markdown
# [Area] Codemap

**Last Updated:** YYYY-MM-DD
**Entry Points:** list of main files

## Architecture
[ASCII diagram of component relationships]

## Key Modules
| Module | Purpose | Exports | Dependencies |
|--------|---------|---------|--------------|
| ... | ... | ... | ... |

## Data Flow
[Description of how data flows through this area]

## External Dependencies
- package-name - Purpose, Version

## Related Areas
Links to other codemaps
```

## Documentation Update Workflow

### Files to Update:
- README.md - Project overview, setup instructions
- docs/GUIDES/*.md - Feature guides, tutorials
- package.json - Descriptions, scripts docs
- API documentation - Endpoint specs

### Validation
- Verify all mentioned files exist
- Check all links work
- Ensure examples are runnable
- Validate code snippets compile

## Example Codemaps

### Frontend Codemap
```markdown
# Frontend Architecture

**Last Updated:** YYYY-MM-DD
**Framework:** Next.js 15 (App Router)
**Entry Point:** src/app/layout.tsx

## Structure
src/
├── app/                # Next.js App Router
│   ├── api/           # API routes
│   └── (routes)/      # Pages
├── components/        # React components
├── hooks/             # Custom hooks
└── lib/               # Utilities

## Key Components
| Component | Purpose | Location |
|-----------|---------|----------|
| ... | ... | ... |

## Data Flow
User → Page → API Route → Database → Response
```

### Backend Codemap
```markdown
# Backend Architecture

**Last Updated:** YYYY-MM-DD
**Runtime:** Next.js API Routes

## API Routes
| Route | Method | Purpose |
|-------|--------|---------|
| /api/users | GET | List users |
| /api/users | POST | Create user |

## Data Flow
API Route → Database → Cache → Response
```

## README Update Template

```markdown
# Project Name

Brief description

## Setup
\`\`\`bash
# Installation
npm install

# Environment variables
cp .env.example .env.local

# Development
npm run dev

# Build
npm run build
\`\`\`

## Architecture
See [docs/CODEMAPS/INDEX.md](docs/CODEMAPS/INDEX.md)

## Documentation
- [Setup Guide](docs/GUIDES/setup.md)
- [API Reference](docs/GUIDES/api.md)
```

## Maintenance Schedule

**Weekly:**
- Check for new files not in codemaps
- Verify README.md instructions work

**After Major Features:**
- Regenerate all codemaps
- Update architecture documentation
- Refresh API reference

**Before Releases:**
- Comprehensive documentation audit
- Verify all examples work
- Check all external links

## Quality Checklist

Before committing documentation:
- [ ] Codemaps generated from actual code
- [ ] All file paths verified to exist
- [ ] Code examples compile/run
- [ ] Links tested (internal and external)
- [ ] Freshness timestamps updated
- [ ] No obsolete references
