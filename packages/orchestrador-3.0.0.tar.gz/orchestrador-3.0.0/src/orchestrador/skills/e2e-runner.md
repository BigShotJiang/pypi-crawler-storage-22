---
name: e2e-runner
description: End-to-end testing specialist using Playwright. Use PROACTIVELY for generating, maintaining, and running E2E tests. Manages test journeys and ensures critical user flows work.
triggers:
  - "e2e test"
  - "playwright test"
  - "end-to-end"
  - "teste de integração"
  - "browser automation"
  - "teste automatizado"
  - "user journey"
  - "critical flow"
  - "regression test"
  - "teste e2e"
  - "playwright"
  - "browser test"
---

# E2E Test Runner Skill

End-to-end testing specialist ensuring critical user journeys work correctly.

## When to Activate

- Creating E2E tests for new features
- Maintaining existing test suites
- Testing critical user flows
- Debugging flaky tests
- Setting up Playwright configuration

## Core Responsibilities

1. **Test Journey Creation** - Write tests for user flows
2. **Test Maintenance** - Keep tests up to date with UI changes
3. **Flaky Test Management** - Identify and quarantine unstable tests
4. **Artifact Management** - Capture screenshots, videos, traces
5. **CI/CD Integration** - Ensure tests run reliably in pipelines

## Test Commands

```bash
# Run all E2E tests
npx playwright test

# Run specific test file
npx playwright test tests/markets.spec.ts

# Run tests in headed mode (see browser)
npx playwright test --headed

# Debug test with inspector
npx playwright test --debug

# Generate test code from actions
npx playwright codegen http://localhost:3000

# Run tests with trace
npx playwright test --trace on

# Show HTML report
npx playwright show-report

# Update snapshots
npx playwright test --update-snapshots
```

## Test Structure

### Page Object Model Pattern
```typescript
// pages/MarketsPage.ts
import { Page, Locator } from '@playwright/test'

export class MarketsPage {
  readonly searchInput: Locator
  readonly marketCards: Locator

  constructor(page: Page) {
    this.searchInput = page.locator('[data-testid="search-input"]')
    this.marketCards = page.locator('[data-testid="market-card"]')
  }

  async goto() {
    await this.page.goto('/markets')
    await this.page.waitForLoadState('networkidle')
  }

  async searchMarkets(query: string) {
    await this.searchInput.fill(query)
    await this.page.waitForLoadState('networkidle')
  }
}
```

### Example Test
```typescript
import { test, expect } from '@playwright/test'
import { MarketsPage } from '../pages/MarketsPage'

test.describe('Market Search', () => {
  let marketsPage: MarketsPage

  test.beforeEach(async ({ page }) => {
    marketsPage = new MarketsPage(page)
    await marketsPage.goto()
  })

  test('should search markets by keyword', async ({ page }) => {
    await marketsPage.searchMarkets('election')
    
    const marketCount = await marketsPage.getMarketCount()
    expect(marketCount).toBeGreaterThan(0)
    
    await page.screenshot({ path: 'artifacts/search-results.png' })
  })
})
```

## Critical User Journeys to Test

1. **Authentication Flows**
   - Login/Logout
   - Registration
   - Password reset

2. **Core Features**
   - Search functionality
   - Data creation/editing
   - File uploads

3. **Payment Flows** (if applicable)
   - Checkout process
   - Payment confirmation

4. **Data Integrity**
   - CRUD operations
   - Form validations

## Playwright Configuration

```typescript
// playwright.config.ts
import { defineConfig, devices } from '@playwright/test'

export default defineConfig({
  testDir: './tests/e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [
    ['html', { outputFolder: 'playwright-report' }],
    ['junit', { outputFile: 'playwright-results.xml' }]
  ],
  use: {
    baseURL: process.env.BASE_URL || 'http://localhost:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure'
  },
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
    { name: 'firefox', use: { ...devices['Desktop Firefox'] } },
    { name: 'webkit', use: { ...devices['Desktop Safari'] } }
  ]
})
```

## Flaky Test Management

### Identifying Flaky Tests
```bash
# Run test multiple times to check stability
npx playwright test tests/markets/search.spec.ts --repeat-each=10
```

### Quarantine Pattern
```typescript
test('flaky: complex search', async ({ page }) => {
  test.fixme(true, 'Test is flaky - Issue #123')
  // Test code...
})
```

### Common Flakiness Causes
```typescript
// ❌ FLAKY: Don't assume element is ready
await page.click('[data-testid="button"]')

// ✅ STABLE: Wait for element
await page.locator('[data-testid="button"]').click()
```

## CI/CD Integration

```yaml
# .github/workflows/e2e.yml
name: E2E Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: npm ci
      - run: npx playwright install --with-deps
      - run: npx playwright test
      - uses: actions/upload-artifact@v3
        if: always()
        with:
          name: playwright-report
          path: playwright-report/
```

## Best Practices

1. **Use semantic selectors**: `data-testid` over CSS classes
2. **Wait for network idle**: Ensure page is fully loaded
3. **Take screenshots**: Capture state on failure
4. **Keep tests independent**: No shared state between tests
5. **Mock external APIs**: Control test environment
