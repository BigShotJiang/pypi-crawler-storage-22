---
name: project-analyzer
description: Analyze a codebase to determine if it's GREENFIELD (new project) or BROWNFIELD (existing project) and provide tailored recommendations for next steps.
triggers:
  - "analyze this project"
  - "check if this is greenfield or brownfield"
  - "start new project"
  - "analyze codebase"
---

# Project Analyzer Skill

Analyze any codebase to determine its maturity level and provide context-aware recommendations.

## Project Classification

### GREENFIELD Project
**Indicators:**
- Empty or minimal directory structure
- No `package.json`, `Cargo.toml`, `pom.xml`, `requirements.txt`
- No existing source code files
- Fresh git repository (no commits or initial commit only)
- No configuration files (eslint, prettier, tsconfig, etc.)

**Characteristics:**
- Complete freedom in architecture decisions
- Opportunity to implement best practices from scratch
- No technical debt to consider
- Can choose latest technologies

### BROWNFIELD Project
**Indicators:**
- Existing `package.json` or equivalent dependency files
- Source code present (`src/`, `app/`, `lib/` directories)
- Existing configuration files
- Git history with multiple commits
- Existing tests, CI/CD configs
- Documentation present

**Characteristics:**
- Must respect existing patterns and conventions
- Technical debt may exist
- Migration strategies needed for major changes
- Consistency with existing code is critical

## Analysis Steps

### Step 1: Detect Project Type

```bash
# Check for existing project files
if exist package.json → Node.js project
if exist next.config.* → Next.js project
if exist src/ or app/ → Has source code
if exist .git with commits → Brownfield
```

### Step 2: Gather Context

**For GREENFIELD:**
- What is the project goal?
- What technologies are preferred?
- Team size and experience?
- Performance/scalability requirements?

**For BROWNFIELD:**
- What is the current architecture?
- What patterns are used?
- What is the tech stack?
- Where is the technical debt?
- What are the coding standards?

### Step 3: Provide Recommendations

**GREENFIELD Recommendations:**
1. Set up project structure with best practices
2. Configure tooling (linting, formatting, testing)
3. Implement foundational architecture
4. Set up CI/CD from day one
5. Create initial documentation

**BROWNFIELD Recommendations:**
1. Analyze existing codebase for patterns
2. Document current architecture
3. Identify technical debt
4. Plan incremental improvements
5. Respect existing conventions
6. Propose refactoring where needed

## Usage

### Example 1: New Project
```
User: "Create a new Next.js project for an e-commerce app"
Analyzer: Detects GREENFIELD
→ Recommends: Use web-architecture skill to set up Clean Architecture
```

### Example 2: Existing Project
```
User: "Help me add authentication to this project"
Analyzer: Detects BROWNFIELD with Express.js
→ Recommends: Respect existing patterns, use web-architecture for auth patterns
```

## Output Format

```
## Project Analysis

**Type:** GREENFIELD | BROWNFIELD
**Stack Detected:** [Next.js | React | Express | etc.]
**Maturity:** [Early | Mid | Legacy]

### Key Findings
- [List of findings]

### Recommendations
1. [Specific action]
2. [Specific action]

### Next Steps
- Use [skill-name] for [purpose]
```
