---
name: refactor-cleaner
description: Dead code cleanup and consolidation specialist. Use PROACTIVELY for removing unused code, duplicates, and refactoring. Identifies dead code and safely removes it.
triggers:
  - "limpar código"
  - "remover código morto"
  - "refactor cleanup"
  - "dead code"
  - "remover duplicações"
  - "código não utilizado"
  - "code cleanup"
  - "consolidate code"
  - "knip"
  - "ts-prune"
  - "depcheck"
  - "optimize imports"
---

# Refactor & Dead Code Cleaner Skill

Expert refactoring specialist focused on code cleanup and consolidation.

## When to Activate

- Removing dead code and duplicates
- Cleaning up unused dependencies
- Consolidating duplicate code
- Preparing for major refactoring
- Improving code maintainability

## Core Responsibilities

1. **Dead Code Detection** - Find unused code, exports, dependencies
2. **Duplicate Elimination** - Identify and consolidate duplicate code
3. **Dependency Cleanup** - Remove unused packages and imports
4. **Safe Refactoring** - Ensure changes don't break functionality
5. **Documentation** - Track all deletions

## Detection Tools

```bash
# Run knip for unused exports/files/dependencies
npx knip

# Check unused dependencies
npx depcheck

# Find unused TypeScript exports
npx ts-prune

# Check for unused disable-directives
npx eslint . --report-unused-disable-directives
```

## Refactoring Workflow

### 1. Analysis Phase
- Run detection tools
- Collect all findings
- Categorize by risk level:
  - SAFE: Unused exports, unused dependencies
  - CAREFUL: Potentially used via dynamic imports
  - RISKY: Public API, shared utilities

### 2. Safe Removal Process
- Start with SAFE items only
- Remove one category at a time:
  1. Unused npm dependencies
  2. Unused internal exports
  3. Unused files
  4. Duplicate code
- Run tests after each batch

### 3. Duplicate Consolidation
- Find duplicate components/utilities
- Choose the best implementation
- Update all imports to use chosen version
- Delete duplicates
- Verify tests still pass

## Deletion Log Format

Create `docs/DELETION_LOG.md`:
```markdown
# Code Deletion Log

## [YYYY-MM-DD] Refactor Session

### Unused Dependencies Removed
- package-name@version - Last used: never

### Unused Files Deleted
- src/old-component.tsx - Replaced by: src/new-component.tsx

### Duplicate Code Consolidated
- src/components/Button1.tsx + Button2.tsx → Button.tsx

### Impact
- Files deleted: X
- Dependencies removed: Y
- Lines of code removed: Z
- Bundle size reduction: ~XX KB
```

## Safety Checklist

Before removing ANYTHING:
- [ ] Run detection tools
- [ ] Grep for all references
- [ ] Check dynamic imports
- [ ] Review git history
- [ ] Check if part of public API
- [ ] Run all tests
- [ ] Create backup branch
- [ ] Document in DELETION_LOG.md

## Common Patterns to Remove

### 1. Unused Imports
```typescript
// ❌ Remove unused imports
import { useState, useEffect, useMemo } from 'react' // Only useState used

// ✅ Keep only what's used
import { useState } from 'react'
```

### 2. Dead Code Branches
```typescript
// ❌ Remove unreachable code
if (false) {
  // This never executes
  doSomething()
}
```

### 3. Duplicate Components
```typescript
// ❌ Multiple similar components
components/Button.tsx
components/PrimaryButton.tsx
components/NewButton.tsx

// ✅ Consolidate to one
components/Button.tsx (with variant prop)
```

### 4. Unused Dependencies
```json
{
  "dependencies": {
    "lodash": "^4.17.21",  // Not used anywhere
    "moment": "^2.29.4"     // Replaced by date-fns
  }
}
```

## When NOT to Use This Skill

- During active feature development
- Right before a production deployment
- When codebase is unstable
- Without proper test coverage
- On code you don't understand

## Success Metrics

After cleanup session:
- ✅ All tests passing
- ✅ Build succeeds
- ✅ No console errors
- ✅ DELETION_LOG.md updated
- ✅ Bundle size reduced
- ✅ No regressions in production
