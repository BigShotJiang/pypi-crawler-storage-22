---
name: tdd-guide
description: Test-Driven Development specialist enforcing write-tests-first methodology. Use PROACTIVELY when writing new features, fixing bugs, or refactoring code. Ensures 80%+ test coverage.
triggers:
  - "tdd"
  - "test driven"
  - "escrever testes"
  - "test coverage"
  - "write tests first"
  - "red green refactor"
  - "test first"
  - "testes unitários"
  - "coverage 80%"
  - "jest test"
  - "vitest"
  - "test patterns"
---

# TDD Guide Skill

Test-Driven Development specialist enforcing write-tests-first methodology.

## When to Activate

- Writing new features or functionality
- Fixing bugs or issues
- Refactoring existing code
- Adding API endpoints
- Creating new components
- Setting up testing infrastructure

## TDD Workflow

### Step 1: Write Test First (RED)
```typescript
// ALWAYS start with a failing test
describe('searchMarkets', () => {
  it('returns semantically similar markets', async () => {
    const results = await searchMarkets('election')
    
    expect(results).toHaveLength(5)
    expect(results[0].name).toContain('Trump')
  })
})
```

### Step 2: Run Test (Verify it FAILS)
```bash
npm test
# Test should fail - we haven't implemented yet
```

### Step 3: Write Minimal Implementation (GREEN)
```typescript
export async function searchMarkets(query: string) {
  const embedding = await generateEmbedding(query)
  const results = await vectorSearch(embedding)
  return results
}
```

### Step 4: Run Test (Verify it PASSES)
```bash
npm test
# Test should now pass
```

### Step 5: Refactor (IMPROVE)
- Remove duplication
- Improve names
- Optimize performance
- Enhance readability

### Step 6: Verify Coverage
```bash
npm run test:coverage
# Verify 80%+ coverage
```

## Test Types You Must Write

### 1. Unit Tests (Mandatory)
```typescript
import { calculateSimilarity } from './utils'

describe('calculateSimilarity', () => {
  it('returns 1.0 for identical embeddings', () => {
    const embedding = [0.1, 0.2, 0.3]
    expect(calculateSimilarity(embedding, embedding)).toBe(1.0)
  })

  it('returns 0.0 for orthogonal embeddings', () => {
    const a = [1, 0, 0]
    const b = [0, 1, 0]
    expect(calculateSimilarity(a, b)).toBe(0.0)
  })

  it('handles null gracefully', () => {
    expect(() => calculateSimilarity(null as any, [])).toThrow()
  })
})
```

### 2. Integration Tests (Mandatory)
```typescript
import { NextRequest } from 'next/server'
import { GET } from './route'

describe('GET /api/markets/search', () => {
  it('returns 200 with valid results', async () => {
    const request = new NextRequest('http://localhost/api/markets/search?q=trump')
    const response = await GET(request)
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(data.success).toBe(true)
  })

  it('returns 400 for missing query', async () => {
    const request = new NextRequest('http://localhost/api/markets/search')
    const response = await GET(request)

    expect(response.status).toBe(400)
  })
})
```

### 3. E2E Tests (Critical Flows)
```typescript
import { test, expect } from '@playwright/test'

test('user can search and view market', async ({ page }) => {
  await page.goto('/')
  
  await page.fill('input[placeholder="Search"]', 'election')
  await page.waitForTimeout(600)
  
  const results = page.locator('[data-testid="market-card"]')
  await expect(results).toHaveCount(5, { timeout: 5000 })
  
  await results.first().click()
  await expect(page).toHaveURL(/\/markets\//)
})
```

## Mocking External Dependencies

### Supabase Mock
```typescript
jest.mock('@/lib/supabase', () => ({
  supabase: {
    from: jest.fn(() => ({
      select: jest.fn(() => ({
        eq: jest.fn(() => Promise.resolve({
          data: [{ id: 1, name: 'Test' }],
          error: null
        }))
      }))
    }))
  }
}))
```

### Fetch Mock
```typescript
global.fetch = jest.fn(() =>
  Promise.resolve({
    json: () => Promise.resolve({ data: [] }),
    ok: true
  } as Response)
)
```

## Edge Cases You MUST Test

1. **Null/Undefined**: What if input is null?
2. **Empty**: What if array/string is empty?
3. **Invalid Types**: What if wrong type passed?
4. **Boundaries**: Min/max values
5. **Errors**: Network failures, database errors
6. **Race Conditions**: Concurrent operations
7. **Large Data**: Performance with 10k+ items
8. **Special Characters**: Unicode, emojis, SQL characters

## Test Quality Checklist

Before marking tests complete:
- [ ] All public functions have unit tests
- [ ] All API endpoints have integration tests
- [ ] Critical user flows have E2E tests
- [ ] Edge cases covered (null, empty, invalid)
- [ ] Error paths tested (not just happy path)
- [ ] Mocks used for external dependencies
- [ ] Tests are independent (no shared state)
- [ ] Test names describe what's being tested
- [ ] Assertions are specific and meaningful
- [ ] Coverage is 80%+ (verify with coverage report)

## Test Smells (Anti-Patterns)

### ❌ Testing Implementation Details
```typescript
// DON'T test internal state
expect(component.state.count).toBe(5)

// DO test what users see
expect(screen.getByText('Count: 5')).toBeInTheDocument()
```

### ❌ Tests Depend on Each Other
```typescript
// DON'T rely on previous test
test('creates user', () => { /* ... */ })
test('updates same user', () => { /* needs previous test */ })

// DO setup data in each test
test('updates user', () => {
  const user = createTestUser()
  // Test logic
})
```

## Coverage Requirements

```json
{
  "jest": {
    "coverageThresholds": {
      "global": {
        "branches": 80,
        "functions": 80,
        "lines": 80,
        "statements": 80
      }
    }
  }
}
```

**Remember**: No code without tests. Tests are not optional. They are the safety net that enables confident refactoring, rapid development, and production reliability.
