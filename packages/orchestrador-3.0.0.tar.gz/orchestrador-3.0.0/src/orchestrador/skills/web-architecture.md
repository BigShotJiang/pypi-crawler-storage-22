---
name: web-architecture
description: Architecture patterns and best practices for Node.js, Next.js, React, and TypeScript projects. Covers Clean Architecture, API design, state management, and performance optimization.
triggers:
  - "how to structure this"
  - "architecture for"
  - "best practices for node"
  - "next.js patterns"
  - "react architecture"
  - "how to organize code"
  - "clean architecture"
  - "api design"
---

# Web Architecture Skill

Architecture patterns for Node.js, Next.js, React, and TypeScript projects.

## Project Structure

### Next.js App Router (Recommended)

```
my-app/
├── src/
│   ├── app/                    # Next.js App Router
│   │   ├── api/               # API routes
│   │   ├── layout.tsx         # Root layout
│   │   ├── page.tsx           # Homepage
│   │   └── globals.css        # Global styles
│   ├── domains/               # Business logic (framework-agnostic)
│   │   ├── user/
│   │   │   ├── types.ts       # Domain types
│   │   │   ├── repository.ts  # Data access interface
│   │   │   └── service.ts     # Business logic
│   │   └── order/
│   ├── features/              # Feature modules
│   │   ├── auth/
│   │   │   ├── components/    # Feature components
│   │   │   ├── hooks/         # Feature hooks
│   │   │   └── api.ts         # Feature API calls
│   │   └── dashboard/
│   ├── shared/                # Shared code
│   │   ├── ui/                # UI components
│   │   ├── lib/               # Utilities
│   │   └── hooks/             # Shared hooks
│   └── infrastructure/        # External services
│       ├── database/
│       └── http/
├── tests/
│   ├── unit/
│   ├── integration/
│   └── e2e/
└── docs/
    └── architecture/
```

### Key Principles

**1. Domain-First Organization**
- Business logic in `domains/` is framework-agnostic
- Can be tested without React/Next.js
- Easy to migrate between frameworks

**2. Feature-Based Modules**
- Each feature owns its components, hooks, and API
- Cohesive and encapsulated
- Easy to understand and maintain

**3. Shared Resources**
- `shared/ui` - Reusable UI components (Button, Card, etc.)
- `shared/lib` - Utility functions
- `shared/hooks` - Custom hooks used across features

## Backend Patterns

### Repository Pattern

Abstract data access logic for testability and flexibility:

```typescript
// domains/user/repository.ts
export interface UserRepository {
  findAll(filters?: UserFilters): Promise<User[]>
  findById(id: string): Promise<User | null>
  create(data: CreateUserDto): Promise<User>
  update(id: string, data: UpdateUserDto): Promise<User>
  delete(id: string): Promise<void>
}

// Infrastructure implementation
export class PrismaUserRepository implements UserRepository {
  constructor(private prisma: PrismaClient) {}

  async findById(id: string): Promise<User | null> {
    return this.prisma.user.findUnique({ where: { id } })
  }

  // Other methods...
}

// Mock for testing
export class MockUserRepository implements UserRepository {
  private users: User[] = []

  async findById(id: string): Promise<User | null> {
    return this.users.find(u => u.id === id) || null
  }

  // Other methods...
}
```

### Service Layer Pattern

Business logic separated from data access:

```typescript
// domains/user/service.ts
export class UserService {
  constructor(private userRepo: UserRepository) {}

  async registerUser(data: CreateUserDto): Promise<User> {
    // Business logic
    const existing = await this.userRepo.findByEmail(data.email)
    if (existing) {
      throw new Error('Email already registered')
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(data.password, 10)

    // Create user
    return this.userRepo.create({
      ...data,
      password: hashedPassword,
    })
  }

  async authenticate(email: string, password: string): Promise<User | null> {
    const user = await this.userRepo.findByEmail(email)
    if (!user) return null

    const valid = await bcrypt.compare(password, user.password)
    return valid ? user : null
  }
}
```

### API Route Handler Pattern

```typescript
// app/api/users/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { userService } from '@/domains/user/service'
import { createUserSchema } from '@/domains/user/types'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const filters = {
      role: searchParams.get('role') || undefined,
      limit: parseInt(searchParams.get('limit') || '10'),
    }

    const users = await userService.findAll(filters)

    return NextResponse.json({ success: true, data: users })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch users' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Validate input
    const validated = createUserSchema.parse(body)

    const user = await userService.registerUser(validated)

    return NextResponse.json(
      { success: true, data: user },
      { status: 201 }
    )
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: error.errors },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { success: false, error: 'Failed to create user' },
      { status: 500 }
    )
  }
}
```

## Frontend Patterns

### Component Patterns

**Composition over Inheritance:**

```typescript
// ✅ GOOD: Component composition
interface CardProps {
  children: React.ReactNode
  variant?: 'default' | 'outlined'
}

export function Card({ children, variant = 'default' }: CardProps) {
  return <div className={`card card-${variant}`}>{children}</div>
}

export function CardHeader({ children }: { children: React.ReactNode }) {
  return <div className="card-header">{children}</div>
}

export function CardBody({ children }: { children: React.ReactNode }) {
  return <div className="card-body">{children}</div>
}

// Usage
<Card>
  <CardHeader>Title</CardHeader>
  <CardBody>Content</CardBody>
</Card>
```

**Compound Components:**

```typescript
const TabsContext = createContext<{
  activeTab: string
  setActiveTab: (tab: string) => void
} | undefined>(undefined)

export function Tabs({ children, defaultTab }: {
  children: React.ReactNode
  defaultTab: string
}) {
  const [activeTab, setActiveTab] = useState(defaultTab)

  return (
    <TabsContext.Provider value={{ activeTab, setActiveTab }}>
      {children}
    </TabsContext.Provider>
  )
}

export function TabList({ children }: { children: React.ReactNode }) {
  return <div className="tab-list">{children}</div>
}

export function Tab({ id, children }: { id: string, children: React.ReactNode }) {
  const context = useContext(TabsContext)
  if (!context) throw new Error('Tab must be used within Tabs')

  return (
    <button
      className={context.activeTab === id ? 'active' : ''}
      onClick={() => context.setActiveTab(id)}
    >
      {children}
    </button>
  )
}
```

### State Management

**Server State (React Query/TanStack Query):**

```typescript
// features/users/hooks/use-users.ts
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'

export function useUsers(filters?: UserFilters) {
  return useQuery({
    queryKey: ['users', filters],
    queryFn: () => fetchUsers(filters),
  })
}

export function useCreateUser() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: createUser,
    onSuccess: () => {
      // Invalidate and refetch
      queryClient.invalidateQueries({ queryKey: ['users'] })
    },
  })
}
```

**Client State (Zustand):**

```typescript
// shared/stores/auth-store.ts
import { create } from 'zustand'

interface AuthState {
  user: User | null
  isAuthenticated: boolean
  login: (user: User) => void
  logout: () => void
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: false,
  login: (user) => set({ user, isAuthenticated: true }),
  logout: () => set({ user: null, isAuthenticated: false }),
}))
```

### Custom Hooks

```typescript
// shared/hooks/use-debounce.ts
export function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value)

  useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delay)
    return () => clearTimeout(handler)
  }, [value, delay])

  return debouncedValue
}

// shared/hooks/use-local-storage.ts
export function useLocalStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(() => {
    if (typeof window === 'undefined') return initialValue
    try {
      const item = window.localStorage.getItem(key)
      return item ? JSON.parse(item) : initialValue
    } catch (error) {
      return initialValue
    }
  })

  const setValue = (value: T | ((val: T) => T)) => {
    const valueToStore = value instanceof Function ? value(storedValue) : value
    setStoredValue(valueToStore)
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(key, JSON.stringify(valueToStore))
    }
  }

  return [storedValue, setValue] as const
}
```

## Error Handling

### API Error Pattern

```typescript
// shared/lib/errors.ts
export class AppError extends Error {
  constructor(
    message: string,
    public code: string,
    public statusCode: number = 500
  ) {
    super(message)
    this.name = 'AppError'
  }
}

export class ValidationError extends AppError {
  constructor(message: string) {
    super(message, 'VALIDATION_ERROR', 400)
  }
}

export class NotFoundError extends AppError {
  constructor(resource: string) {
    super(`${resource} not found`, 'NOT_FOUND', 404)
  }
}

// Middleware
export function errorHandler(error: unknown) {
  if (error instanceof AppError) {
    return NextResponse.json(
      { success: false, error: error.message, code: error.code },
      { status: error.statusCode }
    )
  }

  console.error('Unexpected error:', error)
  return NextResponse.json(
    { success: false, error: 'Internal server error' },
    { status: 500 }
  )
}
```

## Performance Optimization

### React Optimization

```typescript
// Memoize expensive computations
const sortedData = useMemo(() => {
  return data.sort((a, b) => b.score - a.score)
}, [data])

// Memoize callbacks
const handleSubmit = useCallback((values: FormValues) => {
  mutate(values)
}, [mutate])

// Memoize components
const MemoizedListItem = memo(ListItem)

// Lazy load routes
const Dashboard = dynamic(() => import('./dashboard'), {
  loading: () => <Skeleton />,
})
```

### API Optimization

```typescript
// Pagination
interface PaginatedResponse<T> {
  data: T[]
  meta: {
    total: number
    page: number
    limit: number
    totalPages: number
  }
}

// Caching with React Query
const { data } = useQuery({
  queryKey: ['users', page],
  queryFn: () => fetchUsers({ page }),
  staleTime: 5 * 60 * 1000, // 5 minutes
  cacheTime: 10 * 60 * 1000, // 10 minutes
})
```

## Decision Tree

### When to use what?

**State Management:**
- Server state → React Query
- Global client state → Zustand
- Form state → React Hook Form
- URL state → Next.js router

**Data Fetching:**
- Server Components → Direct fetch
- Client Components → React Query
- Real-time → WebSockets + React Query

**Styling:**
- New project → Tailwind CSS
- Design system → CSS Modules + CSS Variables
- Rapid prototyping → Tailwind + shadcn/ui
