---
name: web-development-workflow
description: Complete PREVC workflow for web projects - Planning, Review, Execution, Validation, Commit. Enforces decoupled architecture, TDD, and validated patterns.
triggers:
  - "start project"
  - "new feature"
  - "implement"
  - "create"
  - "build"
  - "refactor"
  - "add feature"
---

# Web Development Workflow (PREVC)

**P**lanning → **R**eview → **E**xecution → **V**alidation → **C**ommit

Complete workflow emphasizing:
- ✅ Decoupled architecture (framework-independent domains)
- ✅ Test-Driven Development (tests before code)
- ✅ Architecture validated per application type
- ✅ Clean Architecture / DDD / Hexagonal as appropriate

---

## Fase 1: PLANNING (Planejamento)

**Objetivo:** Entender completamente ANTES de codificar

### 1.1 Análise do Projeto
**Skill:** `project-analyzer`

**Checklist:**
- [ ] Detectar GREENFIELD vs BROWNFIELD
- [ ] Identificar stack tecnológica
- [ ] Mapear requisitos funcionais
- [ ] Mapear requisitos não-funcionais (performance, escala, segurança)
- [ ] Entregar estimativa de complexidade

**Output:**
```
## Project Analysis

**Type:** GREENFIELD | BROWNFIELD
**Stack:** [Next.js | React | Node | etc.]
**Complexity:** [Low | Medium | High]
**Team Size:** [1-5 | 5-10 | 10+]

### Requirements
**Functional:**
- [List of features]

**Non-Functional:**
- Performance: [requirements]
- Security: [requirements]
- Scalability: [requirements]
```

### 1.2 Escolha de Arquitetura
**Skill:** `architecture-decision`

**Checklist:**
- [ ] Analisar complexidade do domínio
- [ ] Definir tamanho da equipe
- [ ] Escolher padrão: Clean Arch | DDD | Hexagonal | Layered
- [ ] Documentar decisão (ADR)

**Critérios de Decisão:**

| Situação | Arquitetura |
|----------|-------------|
| Simple CRUD, 1-5 devs | Layered |
| Web app/API, testabilidade importante | **Clean Architecture** |
| Complex business rules, 10+ devs | DDD |
| Multiple interfaces (HTTP + CLI + Events) | Hexagonal |
| Large scale, independent teams | Microservices |

**Output:**
```
## Architecture Decision (ADR-001)

**Decision:** Use Clean Architecture

**Context:**
- Web application with moderate complexity
- Team of 3-5 developers
- Need for testable business logic

**Consequences:**
- ✅ Domains are framework-agnostic
- ✅ Easy to test business logic
- ⚠️ More boilerplate than simple MVC
```

### 1.3 Design da Solução
**Skill:** `web-architecture`

**Checklist:**
- [ ] Definir estrutura de diretórios
- [ ] Identificar domínios/bounded contexts
- [ ] Definir contratos de API
- [ ] Mapear repositories e services
- [ ] Definir estratégia de testes

**Para Clean Architecture:**
```
src/
├── domains/              # Framework-agnostic business logic
│   ├── [domain]/
│   │   ├── types.ts      # Entities, DTOs
│   │   ├── repository.ts # Interface (port)
│   │   └── service.ts    # Business logic
│   └── ...
├── features/             # Use cases, UI
│   ├── [feature]/
│   │   ├── components/
│   │   ├── hooks/
│   │   └── api/
├── shared/               # Utilities, UI components
└── infrastructure/       # Implementations (adapters)
    └── database/
```

**Princípios de Decoupling:**
1. **Domain layer** NUNCA depende de framework (React, Express, etc.)
2. **Repositories** são interfaces, implementações em infrastructure
3. **Services** contêm business logic, puras funções
4. **Features** orquestram domains + UI

**Output:**
```
## Design Document

### Domains
- User (auth, profile)
- Task (CRUD, assignments)
- Project (organization)

### APIs
POST   /api/auth/register
POST   /api/auth/login
GET    /api/tasks
POST   /api/tasks
PUT    /api/tasks/:id
DELETE /api/tasks/:id

### Repositories
- UserRepository (Prisma)
- TaskRepository (Prisma)

### Test Strategy
- Unit: domains (80%+ coverage)
- Integration: API routes
- E2E: Critical user flows
```

---

## Fase 2: REVIEW (Revisão do Planejamento)

**Objetivo:** Validar o plano ANTES de executar

### 2.1 Review Checklist

**Arquitetura:**
- [ ] Separation of concerns está claro?
- [ ] Domains são realmente framework-agnostic?
- [ ] Dependências apontam para o domínio (inward)?
- [ ] Não há acoplamento entre features?

**Testabilidade:**
- [ ] Business logic pode ser testada sem React/Express?
- [ ] Repositories têm mocks?
- [ ] Estratégia de testes cobre unit + integration + E2E?

**Escopo:**
- [ ] Design é viável no tempo estimado?
- [ ] Complexidade é apropriada?
- [ ] Riscos foram identificados?

### 2.2 Architecture Validation

**Validação de Decoupling:**
```typescript
// ❌ WRONG: Domain depends on framework
// domains/user/service.ts
import { prisma } from '@prisma/client' // ❌ Coupling!

// ✅ CORRECT: Pure domain
// domains/user/service.ts
export class UserService {
  constructor(private repo: UserRepository) {} // ✅ Interface
  // Business logic only
}
```

**Dependency Rule:**
```
Infrastructure ──depends on──► Domain
Features ──depends on──► Domain
Domain ──depends on──► Nothing (pure)
```

### 2.3 Output da Revisão

```
## Planning Review

**Status:** ✅ Approved | ⚠️ Needs Changes | ❌ Rejected

**Findings:**
- [List of issues or confirmations]

**Changes Required:**
- [If any]

**Approved Architecture:**
- Pattern: [Clean Arch | DDD | Hexagonal]
- Structure: [Summary]

**Next:** Proceed to Execution
```

---

## Fase 3: EXECUTION (Execução)

**Objetivo:** Implementar seguindo TDD e arquitetura aprovada

### 3.0 Delegando para CLIs Especialistas

Para tarefas complexas, delegue para CLIs externos usando `exec` com `pty:true`:

#### Claude Code (Criacao/Arquitetura)
```bash
exec pty:true workdir:"<projeto>" background:true command:"claude '<tarefa>'"
```
Usar para: criar projetos, implementar features, arquitetura, backend, banco

#### Codex CLI (Review/Correcao)
```bash
exec pty:true workdir:"<projeto>" background:true command:"codex exec '<tarefa>'"
```
Usar para: code review, bug fixes, refatoracao, analise de seguranca

#### Flags Codex
- `--full-auto`: sandbox com auto-aprovacao
- `--yolo`: sem sandbox, sem aprovacao (rapido)

#### Monitorar Tarefas Background
```bash
process action:list              # listar sessoes
process action:log sessionId:X   # ver output
process action:poll sessionId:X  # verificar status
process action:kill sessionId:X  # matar se necessario
```

### 3.1 TDD Cycle (RED → GREEN → REFACTOR)

**Skill:** `web-tdd-workflow`

**Regra de Ouro:** TESTES ANTES DO CÓDIGO

#### Step 1: RED (Write failing test)

```typescript
// domains/user/service.test.ts
// Write this FIRST, before any implementation

describe('UserService', () => {
  describe('register', () => {
    it('should create user with hashed password', async () => {
      // Arrange
      const mockRepo = new MockUserRepository()
      const service = new UserService(mockRepo)
      
      // Act
      const result = await service.register({
        email: 'test@example.com',
        password: 'plain123',
      })
      
      // Assert
      expect(result.email).toBe('test@example.com')
      expect(result.password).not.toBe('plain123') // Must be hashed
      expect(result.id).toBeDefined()
    })
    
    it('should throw error for duplicate email', async () => {
      const mockRepo = new MockUserRepository()
      await mockRepo.create({ email: 'exists@example.com', password: 'hash' })
      
      const service = new UserService(mockRepo)
      
      await expect(
        service.register({ email: 'exists@example.com', password: 'pass' })
      ).rejects.toThrow('Email already registered')
    })
  })
})
```

#### Step 2: GREEN (Minimal implementation)

```typescript
// domains/user/service.ts
// MINIMUM code to pass tests

export class UserService {
  constructor(private userRepo: UserRepository) {}
  
  async register(dto: CreateUserDto): Promise<User> {
    // Check duplicate
    const existing = await this.userRepo.findByEmail(dto.email)
    if (existing) {
      throw new Error('Email already registered')
    }
    
    // Hash password
    const hashedPassword = await bcrypt.hash(dto.password, 10)
    
    // Create user
    return this.userRepo.create({
      ...dto,
      password: hashedPassword,
    })
  }
}
```

#### Step 3: REFACTOR (Improve while keeping tests green)

```typescript
// Extract validation
// Extract hashing logic
// Improve naming
// But ALL tests must still pass!
```

### 3.2 Implementation Order

**Always implement:**
1. **Domain types** (entities, DTOs) + validation schemas
2. **Repository interface** (port)
3. **Domain service** + unit tests (TDD)
4. **Repository implementation** + integration tests
5. **API routes** + integration tests
6. **UI components** + component tests
7. **E2E tests** for critical flows

### 3.3 Decoupling Enforcement

**Domain Layer (Pure):**
```typescript
// domains/task/service.ts
// NO imports from React, Next.js, Express, Prisma!

export class TaskService {
  constructor(
    private taskRepo: TaskRepository,
    private userRepo: UserRepository
  ) {}
  
  async createTask(dto: CreateTaskDto, userId: string) {
    // Pure business logic
    const user = await this.userRepo.findById(userId)
    if (!user) throw new NotFoundError('User')
    
    if (dto.dueDate && new Date(dto.dueDate) < new Date()) {
      throw new ValidationError('Due date cannot be in the past')
    }
    
    return this.taskRepo.create({
      ...dto,
      userId,
      status: 'pending',
    })
  }
}
```

**Infrastructure Layer (Adapters):**
```typescript
// infrastructure/database/prisma-task-repo.ts
// Implements repository interface

export class PrismaTaskRepository implements TaskRepository {
  constructor(private prisma: PrismaClient) {}
  
  async findById(id: string) {
    return this.prisma.task.findUnique({ where: { id } })
  }
  
  async create(data: CreateTaskDto) {
    return this.prisma.task.create({ data })
  }
}
```

**Feature Layer (Orchestration):**
```typescript
// features/tasks/api/route.ts
// Orchestrates domain + HTTP

const taskService = new TaskService(
  new PrismaTaskRepository(prisma),
  new PrismaUserRepository(prisma)
)

export async function POST(req: Request) {
  const session = await getSession()
  const dto = createTaskSchema.parse(await req.json())
  
  const task = await taskService.createTask(dto, session.userId)
  
  return Response.json(task, { status: 201 })
}
```

### 3.4 Code Quality Standards

**File Organization:**
```
MANY SMALL FILES > FEW LARGE FILES
- 200-400 lines typical
- Maximum 800 lines
- High cohesion, low coupling
```

**Immutability (CRITICAL):**
```typescript
// ✅ ALWAYS create new objects
function updateTask(task: Task, updates: Partial<Task>): Task {
  return { ...task, ...updates, updatedAt: new Date() }
}

// ❌ NEVER mutate
function updateTaskBad(task: Task, title: string) {
  task.title = title // MUTATION!
  return task
}
```

**Error Handling:**
```typescript
// ✅ Always handle errors
try {
  const result = await riskyOperation()
  return result
} catch (error) {
  console.error('Operation failed:', error)
  throw new AppError('User-friendly message', 'OPERATION_FAILED', 500)
}
```

**Input Validation:**
```typescript
// ✅ Always validate with Zod
const schema = z.object({
  email: z.string().email(),
  age: z.number().int().min(0).max(150),
})

const validated = schema.parse(input) // Throws on invalid
```

---

## Fase 4: VALIDATION (Validação)

**Objetivo:** Garantir qualidade antes de finalizar

### 4.1 Test Validation

**Coverage Requirements:**
- [ ] Unit tests: 80%+ coverage
- [ ] Integration tests: All API endpoints
- [ ] Component tests: User interactions
- [ ] E2E tests: Critical flows
- [ ] All tests passing

**Decoupling Validation:**
```bash
# Can you run domain tests without React?
npm test -- domains/user/service.test.ts
# Should work with just Node.js, no browser

# Can you run domain tests without database?
# Yes, using MockRepository
```

### 4.2 Code Quality Validation

**Static Analysis:**
- [ ] TypeScript strict mode: zero errors
- [ ] ESLint: zero errors
- [ ] Prettier: formatted
- [ ] SonarLint: no issues

**Architecture Validation:**
- [ ] No domain imports from React/Express
- [ ] Repositories are interfaces
- [ ] Services are pure business logic
- [ ] Features orchestrate, don't implement logic

### 4.3 Build Validation

- [ ] Production build succeeds
- [ ] Type checking passes
- [ ] Bundle size acceptable
- [ ] No console errors

### 4.4 Validation Report

```
## Validation Report

**Tests:**
- Unit Coverage: 85% ✅
- Integration: 12/12 passing ✅
- E2E: 5/5 passing ✅

**Quality:**
- TypeScript: 0 errors ✅
- ESLint: 0 errors ✅
- Build: Success ✅

**Architecture:**
- Domain decoupling: Validated ✅
- Repository pattern: Correct ✅
- Service purity: Validated ✅

**Status:** ✅ Ready for Commit
```

---

## Fase 5: COMMIT (Commit)

**Objetivo:** Entregar código com documentação

### 5.1 Commit Checklist

**Code:**
- [ ] All tests passing
- [ ] No console.log statements
- [ ] No hardcoded secrets
- [ ] Error handling complete

**Documentation:**
- [ ] CLAUDE.md updated (if exists)
- [ ] ADR created (if architecture decision)
- [ ] README.md updated (if needed)
- [ ] JSDoc on public APIs

**Git:**
- [ ] Commits atomic and well-described
- [ ] Branch ready for PR
- [ ] No merge conflicts

### 5.2 Documentation Updates

**ADR Template:**
```markdown
# ADR-003: User Authentication Implementation

**Status:** Accepted

**Context:**
Need to implement user authentication for the task manager.

**Decision:**
Use JWT tokens with bcrypt password hashing.

**Consequences:**
- ✅ Stateless authentication
- ✅ Easy to scale
- ⚠️ Token revocation complexity
```

**CLAUDE.md Update:**
```markdown
## User Domain

### Service
- `register(dto): User` - Creates user with hashed password
- `authenticate(email, password): User | null`

### Repository
- Interface: `UserRepository`
- Implementation: `PrismaUserRepository`

### Tests
- Unit: `domains/user/service.test.ts`
- Integration: `app/api/auth/route.test.ts`
```

### 5.3 Commit Message

```
feat(auth): implement user registration and login

- Add User domain with repository pattern
- Implement UserService with password hashing
- Add /api/auth/register and /api/auth/login endpoints
- Include unit and integration tests (87% coverage)

Architecture:
- Follows Clean Architecture
- Domain layer is framework-agnostic
- Repository pattern for data access

Closes #123
```

---

## Workflow Summary

```
┌─────────────────────────────────────────────────────────────┐
│                    PREVC WORKFLOW                           │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. PLANNING                                                │
│     ├─ Analyze project (GREENFIELD/BROWNFIELD)              │
│     ├─ Choose architecture (Clean/DDD/Hexagonal)            │
│     └─ Design solution (domains, APIs, tests)               │
│                          ↓                                  │
│  2. REVIEW                                                  │
│     ├─ Validate architecture decisions                      │
│     ├─ Verify decoupling                                    │
│     └─ Confirm test strategy                                │
│                          ↓                                  │
│  3. EXECUTION                                               │
│     ├─ TDD: RED → GREEN → REFACTOR                          │
│     ├─ Implement: Domain → Repository → API → UI            │
│     └─ Enforce: Immutability, error handling, validation    │
│                          ↓                                  │
│  4. VALIDATION                                              │
│     ├─ Tests: 80%+ coverage, all passing                    │
│     ├─ Quality: TS, ESLint, Build                           │
│     └─ Architecture: Decoupling validated                   │
│                          ↓                                  │
│  5. COMMIT                                                  │
│     ├─ Code: Clean, no debug statements                     │
│     ├─ Docs: CLAUDE.md, ADRs updated                        │
│     └─ Git: Atomic commits, ready for PR                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Usage Examples

### Example 1: New Feature with PREVC

```
User: "Implement user authentication"

Lex (following PREVC):

[PLANNING]
1. Analyze: BROWNFIELD project (password-generator)
2. Architecture: Clean Architecture (appropriate for size)
3. Design: User domain, JWT auth, protected routes

[REVIEW]
4. Validate: Architecture approved, decoupling OK

[EXECUTION]
5. TDD: Write UserService tests → Implement → Refactor
6. TDD: Write auth API tests → Implement endpoints
7. TDD: Write LoginForm tests → Implement component

[VALIDATION]
8. Tests: 85% coverage, all passing
9. Quality: 0 TS errors, 0 lint errors
10. Build: Production build OK

[COMMIT]
11. Docs: Update CLAUDE.md with auth domain
12. ADR: Document JWT decision
13. Git: Commit with descriptive message
```

### Example 2: Architecture Decision

```
User: "Should I use DDD or Clean Architecture for this e-commerce?"

Lex:
- Team size: 5 developers
- Complexity: Medium (products, orders, payments)
- Recommendation: Clean Architecture

Rationale:
- DDD would be overkill for this complexity
- Clean Arch provides testability without ceremony
- Can evolve to DDD later if needed
```

---

## Success Criteria

Projeto seguindo PREVC deve ter:

- ✅ **Arquitetura validada:** Pattern adequado à complexidade
- ✅ **Decoupling:** Domains sem dependência de framework
- ✅ **TDD:** Testes antes do código, 80%+ coverage
- ✅ **Qualidade:** TS strict, ESLint, build OK
- ✅ **Documentação:** ADRs, CLAUDE.md atualizados
- ✅ **Commits:** Atômicos, descritivos, prontos para PR
