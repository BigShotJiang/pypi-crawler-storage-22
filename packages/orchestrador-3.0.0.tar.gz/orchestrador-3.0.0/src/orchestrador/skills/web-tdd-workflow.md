---
name: web-tdd-workflow
description: Test-Driven Development workflow for web projects. Enforces tests before code, 80%+ coverage, and comprehensive test strategies including unit, integration, and E2E tests.
triggers:
  - "write tests"
  - "tdd"
  - "test coverage"
  - "how to test"
  - "unit test"
  - "integration test"
  - "e2e test"
  - "testing strategy"
---

# Web TDD Workflow Skill

Test-Driven Development for Node.js, Next.js, and React projects.

## Core Principles

### 1. Tests BEFORE Code
**ALWAYS** write tests first, then implement code to make tests pass.

### 2. Coverage Requirements
- Minimum 80% coverage (unit + integration + E2E)
- All edge cases covered
- Error scenarios tested
- Boundary conditions verified

### 3. Test Types

| Type | Scope | Tools | When to Use |
|------|-------|-------|-------------|
| Unit | Functions, utilities | Vitest, Jest | Pure logic, helpers |
| Integration | API endpoints, DB | Vitest + supertest | Server-side logic |
| Component | React components | Testing Library | UI behavior |
| E2E | Critical user flows | Playwright | Full workflows |

## TDD Cycle

```
RED → GREEN → REFACTOR

1. RED: Write failing test
2. GREEN: Write minimal code to pass
3. REFACTOR: Improve code quality
4. REPEAT
```

## Setting Up Testing

### Vitest Configuration

```typescript
// vitest.config.ts
import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./tests/setup.ts'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'html', 'json'],
      thresholds: {
        lines: 80,
        functions: 80,
        branches: 80,
        statements: 80,
      },
      exclude: [
        'node_modules/',
        'tests/',
        '**/*.d.ts',
        '**/*.config.*',
      ],
    },
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
})
```

### Test Setup

```typescript
// tests/setup.ts
import '@testing-library/jest-dom'
import { cleanup } from '@testing-library/react'

// Clean up after each test
afterEach(() => {
  cleanup()
})

// Mock environment variables
process.env.NEXT_PUBLIC_API_URL = 'http://localhost:3000'
```

## Unit Testing

### Pure Functions

```typescript
// domains/user/utils.ts
export function validateEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

export function calculateAge(birthDate: Date): number {
  const today = new Date()
  let age = today.getFullYear() - birthDate.getFullYear()
  const monthDiff = today.getMonth() - birthDate.getMonth()

  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--
  }

  return age
}

// domains/user/utils.test.ts
import { describe, it, expect } from 'vitest'
import { validateEmail, calculateAge } from './utils'

describe('validateEmail', () => {
  it('returns true for valid email', () => {
    expect(validateEmail('user@example.com')).toBe(true)
    expect(validateEmail('test.user@domain.co.uk')).toBe(true)
  })

  it('returns false for invalid email', () => {
    expect(validateEmail('')).toBe(false)
    expect(validateEmail('invalid')).toBe(false)
    expect(validateEmail('@example.com')).toBe(false)
    expect(validateEmail('user@')).toBe(false)
  })
})

describe('calculateAge', () => {
  it('calculates age correctly', () => {
    const birthDate = new Date('1990-01-01')
    const age = calculateAge(birthDate)
    expect(age).toBeGreaterThan(30)
  })

  it('handles edge case of birthday not yet occurred this year', () => {
    const today = new Date()
    const birthDate = new Date(today.getFullYear() - 25, today.getMonth() + 1, 1)
    expect(calculateAge(birthDate)).toBe(24)
  })
})
```

### Repository Pattern Testing

```typescript
// domains/user/repository.test.ts
import { describe, it, expect, beforeEach } from 'vitest'
import { MockUserRepository } from './repository'
import type { CreateUserDto } from './types'

describe('UserRepository', () => {
  let repository: MockUserRepository

  beforeEach(() => {
    repository = new MockUserRepository()
  })

  describe('create', () => {
    it('creates a user with generated ID', async () => {
      const data: CreateUserDto = {
        email: 'test@example.com',
        name: 'Test User',
      }

      const user = await repository.create(data)

      expect(user.id).toBeDefined()
      expect(user.email).toBe(data.email)
      expect(user.name).toBe(data.name)
      expect(user.createdAt).toBeInstanceOf(Date)
    })
  })

  describe('findById', () => {
    it('returns user when found', async () => {
      const created = await repository.create({
        email: 'test@example.com',
        name: 'Test',
      })

      const found = await repository.findById(created.id)

      expect(found).toEqual(created)
    })

    it('returns null when not found', async () => {
      const found = await repository.findById('non-existent')
      expect(found).toBeNull()
    })
  })

  describe('findAll', () => {
    it('returns all users', async () => {
      await repository.create({ email: 'user1@test.com', name: 'User 1' })
      await repository.create({ email: 'user2@test.com', name: 'User 2' })

      const users = await repository.findAll()

      expect(users).toHaveLength(2)
    })

    it('filters by criteria', async () => {
      await repository.create({ email: 'admin@test.com', name: 'Admin', role: 'admin' })
      await repository.create({ email: 'user@test.com', name: 'User', role: 'user' })

      const admins = await repository.findAll({ role: 'admin' })

      expect(admins).toHaveLength(1)
      expect(admins[0].role).toBe('admin')
    })
  })
})
```

## Integration Testing

### API Route Testing

```typescript
// app/api/users/route.test.ts
import { describe, it, expect, beforeAll, afterAll } from 'vitest'
import { createTestServer } from '@/tests/utils/server'

describe('Users API', () => {
  const server = createTestServer()

  describe('GET /api/users', () => {
    it('returns list of users', async () => {
      const response = await server.get('/api/users')

      expect(response.status).toBe(200)
      expect(response.body.success).toBe(true)
      expect(Array.isArray(response.body.data)).toBe(true)
    })

    it('supports pagination', async () => {
      const response = await server
        .get('/api/users')
        .query({ limit: 5, offset: 0 })

      expect(response.body.data).toHaveLength(5)
      expect(response.body.meta).toMatchObject({
        total: expect.any(Number),
        limit: 5,
        offset: 0,
      })
    })
  })

  describe('POST /api/users', () => {
    it('creates a new user', async () => {
      const newUser = {
        email: 'newuser@test.com',
        name: 'New User',
      }

      const response = await server
        .post('/api/users')
        .send(newUser)

      expect(response.status).toBe(201)
      expect(response.body.data.email).toBe(newUser.email)
    })

    it('validates required fields', async () => {
      const response = await server
        .post('/api/users')
        .send({ name: 'No Email' })

      expect(response.status).toBe(400)
      expect(response.body.success).toBe(false)
    })

    it('prevents duplicate emails', async () => {
      const user = { email: 'duplicate@test.com', name: 'User' }

      await server.post('/api/users').send(user)
      const response = await server.post('/api/users').send(user)

      expect(response.status).toBe(409)
    })
  })
})
```

## Component Testing

### React Component Testing

```typescript
// features/auth/components/login-form.test.tsx
import { describe, it, expect, vi } from 'vitest'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { LoginForm } from './login-form'

describe('LoginForm', () => {
  it('renders email and password inputs', () => {
    render(<LoginForm onSubmit={vi.fn()} />)

    expect(screen.getByLabelText(/email/i)).toBeInTheDocument()
    expect(screen.getByLabelText(/password/i)).toBeInTheDocument()
    expect(screen.getByRole('button', { name: /sign in/i })).toBeInTheDocument()
  })

  it('shows validation errors for empty fields', async () => {
    render(<LoginForm onSubmit={vi.fn()} />)

    fireEvent.click(screen.getByRole('button', { name: /sign in/i }))

    await waitFor(() => {
      expect(screen.getByText(/email is required/i)).toBeInTheDocument()
      expect(screen.getByText(/password is required/i)).toBeInTheDocument()
    })
  })

  it('calls onSubmit with form data', async () => {
    const onSubmit = vi.fn()
    render(<LoginForm onSubmit={onSubmit} />)

    fireEvent.change(screen.getByLabelText(/email/i), {
      target: { value: 'user@test.com' },
    })
    fireEvent.change(screen.getByLabelText(/password/i), {
      target: { value: 'password123' },
    })
    fireEvent.click(screen.getByRole('button', { name: /sign in/i }))

    await waitFor(() => {
      expect(onSubmit).toHaveBeenCalledWith({
        email: 'user@test.com',
        password: 'password123',
      })
    })
  })

  it('shows loading state during submission', async () => {
    const onSubmit = vi.fn(() => new Promise(() => {})) // Never resolves
    render(<LoginForm onSubmit={onSubmit} />)

    fireEvent.change(screen.getByLabelText(/email/i), {
      target: { value: 'user@test.com' },
    })
    fireEvent.change(screen.getByLabelText(/password/i), {
      target: { value: 'password123' },
    })
    fireEvent.click(screen.getByRole('button', { name: /sign in/i }))

    await waitFor(() => {
      expect(screen.getByText(/signing in/i)).toBeInTheDocument()
      expect(screen.getByRole('button')).toBeDisabled()
    })
  })

  it('displays error message on failed login', async () => {
    const onSubmit = vi.fn().mockRejectedValue(new Error('Invalid credentials'))
    render(<LoginForm onSubmit={onSubmit} />)

    fireEvent.change(screen.getByLabelText(/email/i), {
      target: { value: 'user@test.com' },
    })
    fireEvent.change(screen.getByLabelText(/password/i), {
      target: { value: 'wrongpassword' },
    })
    fireEvent.click(screen.getByRole('button', { name: /sign in/i }))

    await waitFor(() => {
      expect(screen.getByText(/invalid credentials/i)).toBeInTheDocument()
    })
  })
})
```

### Hook Testing

```typescript
// shared/hooks/use-local-storage.test.ts
import { describe, it, expect } from 'vitest'
import { renderHook, act } from '@testing-library/react'
import { useLocalStorage } from './use-local-storage'

describe('useLocalStorage', () => {
  beforeEach(() => {
    localStorage.clear()
  })

  it('returns initial value when no stored value', () => {
    const { result } = renderHook(() => useLocalStorage('key', 'default'))
    expect(result.current[0]).toBe('default')
  })

  it('returns stored value when available', () => {
    localStorage.setItem('key', JSON.stringify('stored'))
    const { result } = renderHook(() => useLocalStorage('key', 'default'))
    expect(result.current[0]).toBe('stored')
  })

  it('updates localStorage when value changes', () => {
    const { result } = renderHook(() => useLocalStorage('key', 'initial'))

    act(() => {
      result.current[1]('updated')
    })

    expect(result.current[0]).toBe('updated')
    expect(JSON.parse(localStorage.getItem('key')!)).toBe('updated')
  })

  it('supports functional updates', () => {
    const { result } = renderHook(() => useLocalStorage('count', 0))

    act(() => {
      result.current[1]((prev) => prev + 1)
    })

    expect(result.current[0]).toBe(1)
  })
})
```

## E2E Testing with Playwright

```typescript
// e2e/auth.spec.ts
import { test, expect } from '@playwright/test'

test.describe('Authentication', () => {
  test('user can sign up', async ({ page }) => {
    await page.goto('/signup')

    await page.fill('[name="email"]', 'newuser@test.com')
    await page.fill('[name="password"]', 'SecurePass123!')
    await page.fill('[name="confirmPassword"]', 'SecurePass123!')
    await page.click('button[type="submit"]')

    await expect(page).toHaveURL('/dashboard')
    await expect(page.locator('[data-testid="user-menu"]')).toBeVisible()
  })

  test('user can log in', async ({ page }) => {
    await page.goto('/login')

    await page.fill('[name="email"]', 'user@test.com')
    await page.fill('[name="password"]', 'password123')
    await page.click('button[type="submit"]')

    await expect(page).toHaveURL('/dashboard')
  })

  test('shows error for invalid credentials', async ({ page }) => {
    await page.goto('/login')

    await page.fill('[name="email"]', 'user@test.com')
    await page.fill('[name="password"]', 'wrongpassword')
    await page.click('button[type="submit"]')

    await expect(page.locator('[role="alert"]')).toHaveText(/invalid credentials/i)
    await expect(page).toHaveURL('/login')
  })

  test('protected routes redirect to login', async ({ page }) => {
    await page.goto('/dashboard')
    await expect(page).toHaveURL('/login?redirect=/dashboard')
  })
})

// e2e/tasks.spec.ts
import { test, expect } from '@playwright/test'

test.describe('Task Management', () => {
  test.beforeEach(async ({ page }) => {
    // Login before each test
    await page.goto('/login')
    await page.fill('[name="email"]', 'user@test.com')
    await page.fill('[name="password"]', 'password123')
    await page.click('button[type="submit"]')
    await page.waitForURL('/dashboard')
  })

  test('user can create a task', async ({ page }) => {
    await page.click('[data-testid="new-task-button"]')
    await page.fill('[name="title"]', 'New Task')
    await page.fill('[name="description"]', 'Task description')
    await page.click('button[type="submit"]')

    await expect(page.locator('text=New Task')).toBeVisible()
  })

  test('user can mark task as complete', async ({ page }) => {
    await page.click('[data-testid="task-checkbox"]:first-child')

    await expect(page.locator('[data-testid="task-checkbox"]:first-child')).toBeChecked()
  })
})
```

## Test Utilities

```typescript
// tests/utils/server.ts
import { createServer } from 'http'
import { NextApiHandler } from 'next'
import { apiResolver } from 'next/dist/server/api-utils/node'
import supertest from 'supertest'

export function createTestServer() {
  const server = createServer(async (req, res) => {
    const handler: NextApiHandler = (await import('@/app/api/users/route')).default
    return apiResolver(req, res, undefined, handler, {}, false)
  })

  return supertest(server)
}

// tests/utils/factories.ts
import { faker } from '@faker-js/faker'
import type { User, CreateUserDto } from '@/domains/user/types'

export function createUserFactory(overrides?: Partial<CreateUserDto>): CreateUserDto {
  return {
    email: faker.internet.email(),
    name: faker.person.fullName(),
    ...overrides,
  }
}

export function createMockUser(overrides?: Partial<User>): User {
  return {
    id: faker.string.uuid(),
    email: faker.internet.email(),
    name: faker.person.fullName(),
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  }
}

// tests/utils/render.tsx
import { render as rtlRender } from '@testing-library/react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { ReactNode } from 'react'

function createTestQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        gcTime: Infinity,
      },
    },
  })
}

export function render(ui: ReactNode) {
  const queryClient = createTestQueryClient()

  return rtlRender(
    <QueryClientProvider client={queryClient}>
      {ui}
    </QueryClientProvider>
  )
}
```

## Running Tests

```bash
# Run all tests
npm test

# Run with coverage
npm run test:coverage

# Run specific test file
npm test -- domains/user/utils.test.ts

# Run in watch mode
npm test -- --watch

# Run E2E tests
npx playwright test

# Run E2E with UI
npx playwright test --ui
```

## Coverage Checklist

Before marking work complete:

- [ ] Unit tests for all pure functions
- [ ] Unit tests for all repository methods
- [ ] Integration tests for all API endpoints
- [ ] Component tests for user interactions
- [ ] Hook tests for custom hooks
- [ ] E2E tests for critical user flows
- [ ] Error scenarios tested
- [ ] Edge cases covered
- [ ] 80%+ overall coverage
- [ ] All tests passing
