//
//  cOrderedStructs.h
//  skiplist
//
//  Created by Paul Ross on 01/10/2016.
//  Copyright (c) 2016 Paul Ross. All rights reserved.
//

#ifndef skiplist_cOrderedStructs_h
#define skiplist_cOrderedStructs_h

/// CPython package name.
#define ORDERED_STRUCTS_MODULE_NAME "orderedstructs"


#endif
