import OrecchietTetris

OrecchietTetris.main()
