# Organization Main Local Python Package

TODO Please update the README of the package

# TODOs

TODO Bring the logo of the organization/company from finhub/clearbit/IEX Cloud/Poligon.io/Yahoo Finance (via RapidAPI or yfinance) using API Management Virtual API (alternative APIs) and store it in the storage. Note that IEX Cloud announced the shutdown of certain services.<br>

TODO Move all files from organizations-local to organization_local in the repo directory.<br>

TODO organization is_no_active_group_member_in_groups( groups).<br>
TODO organizations organizatiobs_with_no_active_member_is_groups( Filter, Groups).<br>

TODO When sending a message, we get the organization as part of a template, and the organization includes more than one company. Shall we add the two Organizations, Companies? Generate a warning?<br>

TODO When searching for an organization (company) in a certain language, search for the organization in all languages. Shall we have this logic in Criteria or in Organization? - We prefer to have this logic in the Organization class.<br>

TODO Add reputation float 0.0-1.0 to each organization (same in url_table).<br>

TODO Get all aliases and values in all languages of the Organization.<br>

TODO If the Organization's original name includes parentheses (), create an alias name for the organization with the name in the parentheses.<br>

TOOD organization name included in other organization name group included in another group name (let's make it generic) creates Recommendation Action Item.<br>

TODO Organizations without any URL (nor email) - Create Action Items. [Data Analyst]<br>

TODO Organizations, Groups ... which are not commonly used, maybe they are spelling mistakes or aliases. [Data Analysis].<br>
