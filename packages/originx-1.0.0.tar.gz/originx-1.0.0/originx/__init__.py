"""
OriginX - WAF Origin IP Discovery Tool
Author: LAKSHMIKANTHAN K (letchupkt)
License: MIT
Purpose: Bug bounty & defensive security research
"""

__version__ = "1.0.0"
__author__ = "LAKSHMIKANTHAN K (letchupkt)"
__license__ = "MIT"