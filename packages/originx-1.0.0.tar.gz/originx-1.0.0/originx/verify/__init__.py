"""
Verification modules for OriginX
"""