"""Setup commands for devbox configuration."""

from pathlib import Path

import questionary
import typer
from orpheus.client import APIError, OrpheusClient
from orpheus.config import get_config
from orpheus.display import console, print_error, print_success, print_warning
from orpheus.git import get_repo_from_cwd


setup = typer.Typer(help="Manage devbox setup.", no_args_is_help=True)


def get_keys_dir() -> Path:
    """Get the directory for SSH keys."""
    keys_dir = Path.home() / ".orpheus" / "keys"
    keys_dir.mkdir(parents=True, exist_ok=True)
    return keys_dir


@setup.command()
def start():
    """Start devbox setup by selecting a repository."""
    config = get_config()

    if not config.user_access_token:
        print_error("Not authenticated. Run 'orpheus auth login' first.")
        raise typer.Exit(1)

    client = OrpheusClient(config)

    console.print("Fetching your repositories...")
    try:
        repos = client.list_repos()
    except APIError as e:
        print_error(f"Failed to fetch repos: {e}")
        raise typer.Exit(1)

    if not repos:
        print_error("No repositories found.")
        raise typer.Exit(1)

    # Try to auto-detect repo from cwd
    detected_repo = get_repo_from_cwd()
    selected = None

    if detected_repo:
        selected = next((r for r in repos if r["full_name"] == detected_repo), None)
        if selected:
            console.print(f"Detected repository: [bold]{detected_repo}[/bold]")
        else:
            print_error(f"Detected repo '{detected_repo}' not in your accessible repos.")
            raise typer.Exit(1)

    if not selected:
        choices = [questionary.Choice(title=r["full_name"], value=r) for r in repos]
        selected = questionary.select(
            "Select a repository:",
            choices=choices,
            use_shortcuts=False,
            use_arrow_keys=True,
            use_jk_keys=False,
            use_search_filter=True,
        ).ask()

    if selected is None:
        raise typer.Exit(1)

    repo_full_name = selected["full_name"]
    is_private = selected["private"]

    console.print()
    console.print(f"Provisioning devbox for [bold]{repo_full_name}[/bold]...")

    try:
        data = client.start_setup(repo_full_name, is_private)
    except APIError as e:
        print_error(f"Failed to start setup: {e}")
        raise typer.Exit(1)

    # Save SSH key
    keys_dir = get_keys_dir()
    key_path = keys_dir / data["instance_id"]
    key_path.write_text(data["ssh_private_key"])
    key_path.chmod(0o600)

    # Display SSH info
    console.print()
    print_success("Your devbox is ready!")
    console.print()
    console.print("[bold]SSH command:[/bold]")
    console.print(f"  ssh -i {key_path} {data['ssh_user']}@{data['ssh_host']}")
    console.print()
    console.print("[bold]Or use password:[/bold]")
    console.print(f"  {data['ssh_password']}")
    console.print()
    print_warning("When you're done configuring, run:")
    console.print("  [bold]orpheus setup save[/bold]")


@setup.command()
def save():
    """Save devbox state by creating a snapshot."""
    config = get_config()

    if not config.user_access_token:
        print_error("Not authenticated. Run 'orpheus auth login' first.")
        raise typer.Exit(1)

    # Detect repo from cwd
    repo_full_name = get_repo_from_cwd()
    if not repo_full_name:
        print_error("Not in a git repository with a GitHub remote.")
        print_error("Run this command from within your cloned repo directory.")
        raise typer.Exit(1)

    client = OrpheusClient(config)

    console.print(f"Saving devbox snapshot for [bold]{repo_full_name}[/bold]...")

    try:
        data = client.save_setup(repo_full_name)
    except APIError as e:
        print_error(f"Failed to save devbox: {e}")
        raise typer.Exit(1)

    print_success(f"Snapshot saved: {data['snapshot_id']}")
    console.print()
    console.print("You can now run tasks with:")
    console.print("  [bold]orpheus exec spec.txt[/bold]")
