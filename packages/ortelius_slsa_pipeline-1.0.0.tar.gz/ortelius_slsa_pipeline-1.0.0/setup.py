from setuptools import setup, find_packages
from pathlib import Path

# Read the README file for long description
this_directory = Path(__file__).parent
long_description = ""
readme_file = this_directory / "README.md"
if readme_file.exists():
    long_description = readme_file.read_text(encoding="utf-8")

setup(
    name="ortelius-slsa-pipeline",
    version="1.0.0",
    description="Temporal-based SLSA Level 3 CI/CD orchestration with AI-powered auto-fix",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Ortelius",
    author_email="steve@deployhub.com",
    url="https://github.com/ortelius/slsa-pipeline",
    project_urls={
        "Bug Tracker": "https://github.com/ortelius/slsa-pipeline/issues",
        "Documentation": "https://github.com/ortelius/slsa-pipeline#readme",
        "Source Code": "https://github.com/ortelius/slsa-pipeline",
    },
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.10",
    install_requires=[
        "temporalio>=1.5.0",
        "httpx>=0.25.0",
        "click>=8.1.0",
        "pyyaml>=6.0",
        "mcp>=0.9.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
            "ruff>=0.1.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "slsa-pipeline=slsa_pipeline.cli:cli",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Build Tools",
        "Topic :: Software Development :: Quality Assurance",
        "Topic :: Security",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
        "Framework :: AsyncIO",
        "Typing :: Typed",
    ],
    keywords=[
        "slsa",
        "supply-chain-security",
        "ci-cd",
        "temporal",
        "sbom",
        "container-security",
        "code-signing",
        "vulnerability-scanning",
        "devops",
        "github-actions",
        "ai-automation",
        "claude-ai",
    ],
    include_package_data=True,
    package_data={
        "slsa_pipeline": ["py.typed"],  # For type checking support
    },
    zip_safe=False,
)