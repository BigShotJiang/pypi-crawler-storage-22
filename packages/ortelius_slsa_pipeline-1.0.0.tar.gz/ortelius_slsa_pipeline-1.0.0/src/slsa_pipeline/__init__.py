"""
SLSA Pipeline - Temporal-based SLSA Level 3 CI/CD Orchestration.

This package provides a complete implementation of SLSA Level 3 build pipeline
using Temporal workflows and GitHub Actions.
"""
