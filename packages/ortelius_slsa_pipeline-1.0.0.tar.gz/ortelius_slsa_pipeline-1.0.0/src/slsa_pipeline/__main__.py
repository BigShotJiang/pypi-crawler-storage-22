"""
Entry point for running slsa_pipeline as a module.

This module allows the package to be executed directly using:
    python -m slsa_pipeline

It delegates to the CLI interface defined in cli.py.
"""

from .cli import cli

if __name__ == '__main__':
    cli()
