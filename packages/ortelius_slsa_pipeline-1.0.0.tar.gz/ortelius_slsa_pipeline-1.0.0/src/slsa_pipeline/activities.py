"""
Temporal Activities for SLSA Pipeline.

This module contains all Temporal activities that execute GitHub workflows,
interact with the GitHub API, manage MCP sessions, and integrate with Claude AI
for automated code fixes.

Activities are the building blocks of Temporal workflows - they represent
individual tasks that can be retried, monitored, and composed into complex
orchestrations.

Uses a dependency-driven architecture where activities extract
their own inputs from a centralized 'statedata' dictionary, improving
testability and separation of concerns.
"""

import os
import json
import asyncio
import io
import zipfile
import httpx
import re
from typing import Dict, List, Optional
from pprint import pprint
from contextlib import AsyncExitStack
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from temporalio import activity


# --- MCP Manager (unchanged) ---

class GitHubMCPManager:
    """
    Singleton manager for GitHub MCP (Model Context Protocol) sessions.
    
    This class manages a persistent connection to the GitHub MCP server,
    which provides tool-based access to GitHub operations like creating
    branches, pushing files, and managing issues/PRs.
    
    Attributes:
        _session: The active MCP ClientSession
        _exit_stack: AsyncExitStack for managing cleanup
        _lock: Asyncio lock for thread-safe session initialization
    """
    
    _session: Optional[ClientSession] = None
    _exit_stack: Optional[AsyncExitStack] = None
    _lock = asyncio.Lock()

    @classmethod
    async def get_session(cls) -> ClientSession:
        """
        Get or create the MCP session.
        
        This method ensures only one MCP session is created and reused
        across all activity executions, improving performance and
        preventing resource exhaustion.
        
        Returns:
            ClientSession: Active MCP session for GitHub operations
        """
        async with cls._lock:
            if cls._session is None:
                cls._exit_stack = AsyncExitStack()
                server_params = StdioServerParameters(
                    command="npx",
                    args=["-y", "@modelcontextprotocol/server-github"],
                    env={
                        **os.environ, 
                        "GITHUB_PERSONAL_ACCESS_TOKEN": os.getenv("GITHUB_TOKEN", ""),
                        "LOG_LEVEL": "warn"  
                    }
                )
                read, write = await cls._exit_stack.enter_async_context(stdio_client(server_params))
                cls._session = await cls._exit_stack.enter_async_context(ClientSession(read, write))
                await cls._session.initialize()
            return cls._session

    @classmethod
    async def shutdown(cls):
        """
        Shutdown the MCP session and cleanup resources.
        
        Should be called when the worker is shutting down to ensure
        proper cleanup of the MCP connection.
        """
        if cls._exit_stack:
            await cls._exit_stack.aclose()
            cls._session = None
            cls._exit_stack = None


# --- Helper (unchanged) ---

async def fetch_workflow_artifact_json(
    client: httpx.AsyncClient, 
    repo_owner: str, 
    repo_name: str, 
    run_id: int, 
    artifact_name: str, 
    headers: dict
) -> dict:
    """
    Fetch and parse a JSON artifact from a GitHub Actions workflow run.
    
    This helper function:
    1. Lists artifacts for the specified run
    2. Finds the target artifact by name
    3. Downloads the artifact (ZIP file)
    4. Extracts and parses the first JSON file found
    
    Args:
        client: Async HTTP client for making requests
        repo_owner: GitHub repository owner
        repo_name: Repository name
        run_id: GitHub Actions workflow run ID
        artifact_name: Name of the artifact to fetch
        headers: HTTP headers including authentication
    
    Returns:
        dict: Parsed JSON content from the artifact, or empty dict on error
    """
    try:
        url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/actions/runs/{run_id}/artifacts"
        res = await client.get(url, headers=headers)
        res.raise_for_status()
        
        artifacts = res.json().get("artifacts", [])
        target = next((a for a in artifacts if a["name"] == artifact_name), None)
        
        if not target:
            activity.logger.warning(f"Artifact {artifact_name} not found for run {run_id}")
            return {}

        download_url = target["archive_download_url"]
        art_res = await client.get(download_url, headers=headers, follow_redirects=True)
        art_res.raise_for_status()

        with zipfile.ZipFile(io.BytesIO(art_res.content)) as z:
            for file_info in z.infolist():
                if file_info.filename.endswith(".json"):
                    with z.open(file_info) as f:
                        return json.load(f)
    except Exception as e:
        activity.logger.warning(f"Error fetching artifact {artifact_name}: {str(e)}")
    return {}


# --- MCP Activities (now extract from statedata) ---

@activity.defn
async def mcp_create_branch(branch_name: str, statedata: Dict) -> Dict:
    """
    Create a new Git branch using MCP.
    
    Extracts repository information from statedata['config'].
    
    Args:
        branch_name: Name for the new branch
        statedata: Centralized data dict containing config and upstream results
    
    Returns:
        dict: Result containing branch name and method used
    """
    config = statedata['config']
    
    activity.logger.info("mcp_create_branch - Input:")
    pprint({"branch_name": branch_name, "repo": f"{config['repo_owner']}/{config['repo_name']}"})
    
    client = await GitHubMCPManager.get_session()
    await client.call_tool(
        "create_branch", 
        {
            "owner": config["repo_owner"], 
            "repo": config["repo_name"], 
            "branch": branch_name, 
            "from_branch": config.get("git_ref", "main")
        }
    )
    result = {"branch": branch_name, "method": "mcp"}
    
    activity.logger.info("mcp_create_branch - Output:")
    pprint(result)
    
    return result


@activity.defn
async def mcp_push_files(branch: str, files: List[Dict], statedata: Dict) -> Dict:
    """
    Push multiple files to a Git branch using MCP.
    
    Extracts repository information from statedata['config'].
    
    Args:
        branch: Target branch name
        files: List of file dicts with 'path' and 'content' keys
        statedata: Centralized data dict containing config
    
    Returns:
        dict: Result containing number of files pushed and method used
    """
    config = statedata['config']
    
    activity.logger.info("mcp_push_files - Input:")
    pprint({"branch": branch, "file_count": len(files), "repo": f"{config['repo_owner']}/{config['repo_name']}"})
    
    client = await GitHubMCPManager.get_session()
    formatted = [
        {
            "path": f.get("path") or f.get("file"), 
            "content": f.get("content") or f.get("fixed")
        } 
        for f in files
    ]
    await client.call_tool(
        "push_files", 
        {
            "owner": config["repo_owner"], 
            "repo": config["repo_name"], 
            "branch": branch, 
            "files": formatted, 
            "message": "fix: Auto-fix lint errors"
        }
    )
    result = {"files_pushed": len(formatted), "method": "mcp"}
    
    activity.logger.info("mcp_push_files - Output:")
    pprint(result)
    
    return result


@activity.defn
async def get_files_with_lint_errors(lint_errs: List[Dict], statedata: Dict) -> List[Dict[str, str]]:
    """
    Identify and fetch files with linting errors from GitHub.
    
    Extracts file paths from MegaLinter error reports and retrieves
    their current content from the repository.
    
    Extracts repository info and git ref from statedata['config'].
    
    Args:
        lint_errs: List of linter result dicts from MegaLinter
        statedata: Centralized data dict containing config
    
    Returns:
        list: List of dicts with 'path' and 'content' keys for each file
    """
    config = statedata['config']
    
    activity.logger.info("get_files_with_lint_errors - Input:")
    pprint({"linter_count": len(lint_errs), "repo": f"{config['repo_owner']}/{config['repo_name']}"})
    
    client = await GitHubMCPManager.get_session()
    files_to_fetch = set()
    
    for linter in lint_errs:
        if linter.get("status") == "error":
            for file_path in linter.get("files", []):
                if file_path:
                    files_to_fetch.add(file_path)
    
    result = []
    for path in files_to_fetch:
        try:
            response = await client.call_tool(
                "get_file_contents", 
                {
                    "owner": config["repo_owner"], 
                    "repo": config["repo_name"], 
                    "path": path, 
                    "ref": config.get("git_ref", "main")
                }
            )
            content = ""
            if hasattr(response, 'content') and response.content:
                first_block = response.content[0]
                content = getattr(first_block, 'text', "")
            result.append({"path": path, "content": content})
        except Exception as e:
            activity.logger.warning(f"Could not fetch file {path}: {str(e)}")
    
    activity.logger.info("get_files_with_lint_errors - Output:")
    pprint({"files_fetched": len(result)})
    
    return result


@activity.defn
async def create_pull_request_with_fixes(
    fix_branch: str, 
    fix_result: Dict, 
    statedata: Dict
) -> Dict:
    """
    Create a pull request with AI-generated fixes and add labels.
    
    Uses MCP for PR creation and GitHub API for labels.
    Extracts repository info from statedata['config'].
    
    Args:
        fix_branch: Source branch with changes
        fix_result: Fix analysis result containing summary
        statedata: Centralized data dict containing config
    
    Returns:
        dict: PR details including number, URL, labels, and method used
    """
    config = statedata['config']
    
    activity.logger.info("create_pull_request_with_fixes - Input:")
    pprint({"fix_branch": fix_branch, "repo": f"{config['repo_owner']}/{config['repo_name']}"})
    
    client = await GitHubMCPManager.get_session()
    pr_response = await client.call_tool(
        "create_pull_request", 
        {
            "owner": config["repo_owner"], 
            "repo": config["repo_name"], 
            "title": "🤖 Auto-fix: Lint errors", 
            "body": fix_result.get('summary', ''), 
            "head": fix_branch, 
            "base": config.get("git_ref", "main")
        }
    )
    
    pr_data = {}
    if hasattr(pr_response, 'content') and pr_response.content:
        first_content = pr_response.content[0]
        text_content = getattr(first_content, 'text', '{}')
        pr_data = json.loads(text_content)
    
    pr_number = pr_data.get("number")
    pr_url = pr_data.get("html_url")
    github_token = os.getenv("GITHUB_TOKEN")
    labels = ["automated-fix", "ai-generated", "needs-review"]
    
    async with httpx.AsyncClient() as api_client:
        try:
            await api_client.post(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/issues/{pr_number}/labels", 
                headers={
                    "Authorization": f"Bearer {github_token}", 
                    "Accept": "application/vnd.github.v3+json"
                }, 
                json={"labels": labels}
            )
        except Exception as e:
            activity.logger.warning(f"Could not add labels: {str(e)}")
    
    result = {"number": pr_number, "url": pr_url, "labels": labels, "method": "mcp+api"}
    
    activity.logger.info("create_pull_request_with_fixes - Output:")
    pprint(result)
    
    return result


@activity.defn
async def create_vulnerability_issue(
    scan_res: Dict, 
    critical: int, 
    high: int, 
    statedata: Dict
) -> Dict:
    """
    Create a GitHub issue documenting security vulnerabilities found during SBOM scanning.
    
    Extracts repository info from statedata['config'] and SBOM run_id from
    statedata['generate_sbom'].
    
    Args:
        scan_res: Scan results dictionary with run_id
        critical: Number of critical vulnerabilities
        high: Number of high severity vulnerabilities
        statedata: Centralized data dict containing config and upstream results
    
    Returns:
        dict: Issue details including number, labels, and method used
    """
    config = statedata['config']
    sbom_run_id = statedata['generate_sbom'].get("run_id")
    
    activity.logger.info("create_vulnerability_issue - Input:")
    pprint({"critical": critical, "high": high, "scan_run_id": scan_res.get("run_id")})
    
    title = f"🛡️ Security: Critical/High Vulnerabilities in {config['image_name']}:{config['image_tag']}"
    body = (
        f"## Vulnerability Scan Failure\n\n"
        f"**Image**: `{config['image_name']}:{config['image_tag']}`\n"
        f"**SBOM Artifact**: `sbom-{sbom_run_id}`\n"
        f"**Scan Workflow**: [View Results](https://github.com/{config['repo_owner']}/{config['repo_name']}/actions/runs/{scan_res.get('run_id')})\n\n"
        f"### Summary\n"
        f"Critical or high severity vulnerabilities detected.\n\n"
        f"**Findings:**\n"
        f"- Critical: {critical}\n"
        f"- High: {high}\n\n"
        f"---\n*Auto-created by SLSA Pipeline*"
    )
    labels = ["security", "vulnerability", "high-priority", "automated"]
    
    client = await GitHubMCPManager.get_session()
    issue_response = await client.call_tool(
        "create_issue", 
        {
            "owner": config["repo_owner"], 
            "repo": config["repo_name"], 
            "title": title, 
            "body": body
        }
    )
    
    issue_data = {}
    if hasattr(issue_response, 'content') and issue_response.content:
        first_content = issue_response.content[0]
        text_content = getattr(first_content, 'text', '{}')
        issue_data = json.loads(text_content)
    
    issue_number = issue_data.get("number")
    github_token = os.getenv("GITHUB_TOKEN")
    
    async with httpx.AsyncClient() as api_client:
        try:
            await api_client.post(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/issues/{issue_number}/labels", 
                headers={
                    "Authorization": f"Bearer {github_token}", 
                    "Accept": "application/vnd.github.v3+json"
                }, 
                json={"labels": labels}
            )
        except Exception as e:
            activity.logger.warning(f"Could not add labels: {str(e)}")
    
    result = {"number": issue_number, "labels": labels, "method": "mcp+api"}
    
    activity.logger.info("create_vulnerability_issue - Output:")
    pprint(result)
    
    return result


@activity.defn
async def create_failure_issue(statedata: Dict) -> Dict:
    """
    Create a GitHub issue documenting a pipeline failure.
    
    Extracts repository info from statedata['config'] and error message
    from statedata['error_message'].
    
    Args:
        statedata: Centralized data dict containing config and error info
    
    Returns:
        dict: Issue details including number, labels, and method used
    """
    config = statedata['config']
    error_msg = statedata.get("error_message", "Unknown error")
    
    activity.logger.info("create_failure_issue - Input:")
    pprint({"image_tag": config.get('image_tag', 'unknown'), "error": error_msg[:100]})
    
    title = f"🔴 Build Failed: {config.get('image_tag', 'unknown')}"
    body = (
        f"## Build Failure Report\n\n"
        f"**Image**: `{config.get('registry', 'ghcr.io')}/{config['image_name']}:{config.get('image_tag', 'unknown')}`\n"
        f"### Failed Steps\n{error_msg}\n\n"
        f"---\n*Auto-created by SLSA Pipeline*"
    )
    labels = ["ci-failure", "automated", "security"]
    
    client = await GitHubMCPManager.get_session()
    issue_response = await client.call_tool(
        "create_issue", 
        {
            "owner": config["repo_owner"], 
            "repo": config["repo_name"], 
            "title": title, 
            "body": body
        }
    )
    
    issue_data = {}
    if hasattr(issue_response, 'content') and issue_response.content:
        first_content = issue_response.content[0]
        text_content = getattr(first_content, 'text', '{}')
        issue_data = json.loads(text_content)
    
    issue_number = issue_data.get("number")
    github_token = os.getenv("GITHUB_TOKEN")
    
    async with httpx.AsyncClient() as api_client:
        try:
            await api_client.post(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/issues/{issue_number}/labels", 
                headers={
                    "Authorization": f"Bearer {github_token}", 
                    "Accept": "application/vnd.github.v3+json"
                }, 
                json={"labels": labels}
            )
        except Exception as e:
            activity.logger.warning(f"Could not add labels: {str(e)}")
    
    result = {"number": issue_number, "labels": labels, "method": "mcp+api"}
    
    activity.logger.info("create_failure_issue - Output:")
    pprint(result)
    
    return result


@activity.defn
async def analyze_lint_failures_with_claude(
    lint_report: List[Dict], 
    source_files: List[Dict], 
    statedata: Dict
) -> Dict:
    """
    Analyze linting failures and generate fixes using Claude AI.
    
    This activity sends linting errors and source code to Claude (Anthropic API)
    for analysis. Claude examines the errors and generates corrected versions
    of the affected files.
    
    Extracts repository info from statedata['config'].
    
    Args:
        lint_report: List of linter result dicts from MegaLinter containing
                     error details, file paths, and violation descriptions
        source_files: List of dicts with 'path' and 'content' keys for files
                      that have linting errors
        statedata: Centralized data dict containing config
    
    Returns:
        dict: Analysis result containing:
            - can_fix: Boolean indicating if fixes are available
            - fixes: List of dicts with 'path' and 'content' for fixed files
            - summary: Human-readable explanation of changes made
            - error: Error message if analysis failed (optional)
    
    Note:
        Requires ANTHROPIC_API_KEY environment variable to be set.
        Uses Claude Sonnet 4 model for code analysis and generation.
    """
    config = statedata['config']
    api_key = os.getenv("ANTHROPIC_API_KEY")
    
    activity.logger.info("analyze_lint_failures_with_claude - Input:")
    pprint({"linter_count": len(lint_report), "file_count": len(source_files), "repo": f"{config['repo_owner']}/{config['repo_name']}"})
    
    if not api_key:
        return {
            "can_fix": False, 
            "fixes": [], 
            "summary": "ANTHROPIC_API_KEY not set"
        }

    error_context = ""
    for linter in lint_report:
        if linter.get("status") == "error":
            name = linter.get("name", linter.get("linter_name", "Linter"))
            clean_stdout = linter.get("stdout", "")
            error_context += f"### Linter: {name}\n{clean_stdout}\n"

    prompt = (
        f"Analyze and fix lint errors for {config['repo_owner']}/{config['repo_name']}.\n\n"
        f"ERROR LOGS:\n{error_context}\n\n"
        f"SOURCE CODE:\n{json.dumps(source_files, indent=2)}\n\n"
        "Respond with JSON:\n"
        "{\n"
        "  \"can_fix\": true,\n"
        "  \"summary\": \"Brief explanation\",\n"
        "  \"fixes\": [\n"
        "    {\"path\": \"file_path\", \"content\": \"corrected_content\"}\n"
        "  ]\n"
        "}"
    )

    async with httpx.AsyncClient(timeout=120.0) as client:
        try:
            response = await client.post(
                "https://api.anthropic.com/v1/messages", 
                headers={
                    "x-api-key": api_key, 
                    "anthropic-version": "2023-06-01", 
                    "content-type": "application/json"
                }, 
                json={
                    "model": "claude-sonnet-4-20250514", 
                    "max_tokens": 8000, 
                    "messages": [{"role": "user", "content": prompt}]
                }
            )
            response.raise_for_status()
            data = response.json()

            if not data.get("content"):
                return {"can_fix": False, "fixes": [], "summary": "No response"}

            text_content = "".join([
                block.get("text", "") 
                for block in data["content"] if block.get("type") == "text"
            ])

            json_match = re.search(r'```json\s*(\{.*?\})\s*```', text_content, re.DOTALL)
            if json_match:
                result = json.loads(json_match.group(1))
            else:
                result = json.loads(text_content)

            result.setdefault("fixes", [])
            result.setdefault("can_fix", len(result["fixes"]) > 0)
            
            activity.logger.info("analyze_lint_failures_with_claude - Output:")
            pprint({"can_fix": result.get("can_fix"), "fix_count": len(result.get("fixes", []))})
            
            return result

        except Exception as e:
            result = {"can_fix": False, "fixes": [], "summary": f"Error: {str(e)}"}
            activity.logger.info("analyze_lint_failures_with_claude - Output:")
            pprint(result)
            return result


# --- Workflow Activities (now extract from statedata) ---

@activity.defn
async def run_megalinter(statedata: Dict) -> Dict:
    """
    Execute MegaLinter workflow and wait for completion.
    
    Triggers the MegaLinter GitHub Actions workflow, polls for completion,
    and retrieves lint results including error details and summaries.
    
    Extracts repository info and git ref from statedata['config'].
    
    Args:
        statedata: Centralized data dict containing config
    
    Returns:
        dict: Lint results including status, conclusion, run_id, 
              lint summary, and detailed linter errors
    """
    config = statedata['config']
    WORKFLOW_FILE = "00-megalinter.yml"
    
    github_token = os.getenv("GITHUB_TOKEN")
    headers = {
        "Authorization": f"Bearer {github_token}", 
        "Accept": "application/vnd.github.v3+json"
    }
    
    inputs = config.get("inputs", {})
    
    activity.logger.info("run_megalinter - Input:")
    pprint({"workflow": WORKFLOW_FILE, "inputs": inputs})
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/workflows/{WORKFLOW_FILE}/dispatches",
                headers=headers,
                json={
                    "ref": config.get("git_ref", "main"), 
                    "inputs": inputs
                }
            )
            response.raise_for_status()
        except Exception as e:
            return {"workflow": "megalinter", "status": "failure", "error": str(e)}
    
        run_id = None
        for _ in range(10):
            res = await client.get(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/workflows/{WORKFLOW_FILE}/runs", 
                headers=headers, 
                params={"per_page": 1}
            )
            if res.status_code == 200:
                runs = res.json().get("workflow_runs", [])
                if runs:
                    run_id = runs[0]["id"]
                    break
            await asyncio.sleep(2)
        
        if not run_id:
            return {"workflow": "megalinter", "status": "failure", "error": "Run not found"}
        
        while True:
            res = await client.get(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/runs/{run_id}", 
                headers=headers
            )
            res.raise_for_status()
            data = res.json()
            
            if data.get("status") == "completed":
                conclusion = data.get("conclusion")
                result = {
                    "workflow": "megalinter",
                    "status": conclusion,
                    "conclusion": conclusion,
                    "run_id": run_id
                }
                
                artifact_data = await fetch_workflow_artifact_json(
                    client, config['repo_owner'], config['repo_name'], 
                    run_id, f"lint-summary-{run_id}", headers
                )
                result.update(artifact_data)

                lint_data = await fetch_workflow_artifact_json(
                    client, config['repo_owner'], config['repo_name'], 
                    run_id, f"megalinter-reports-{run_id}", headers
                )
                lint_errs = lint_data.get("linters", {})

                try:
                    json_str = json.dumps(lint_errs)
                    ansi_escape = re.compile(r'(\\u001b|\x1b)\[[0-9;]*m') 
                    clean_json_str = ansi_escape.sub('', json_str)
                    lint_errs = json.loads(clean_json_str)
                except Exception as e:
                    activity.logger.warning(f"Failed to sanitize lint report: {str(e)}")

                result.update({"lint_errs": lint_errs})
                
                activity.logger.info("run_megalinter - Output:")
                pprint({"workflow": WORKFLOW_FILE, "result": result})
                
                return result
            
            activity.heartbeat()
            await asyncio.sleep(5)


@activity.defn
async def run_build_image(statedata: Dict) -> Dict:
    """
    Execute container image build workflow and wait for completion.
    
    Triggers the build-image GitHub Actions workflow, monitors progress,
    and retrieves the image digest and build artifacts.
    
    Extracts image details and repository info from statedata['config'].
    
    Args:
        statedata: Centralized data dict containing config
    
    Returns:
        dict: Build results including status, conclusion, run_id, 
              image digest, and artifact data
    """
    config = statedata['config']
    WORKFLOW_FILE = "01-build-image.yml"
    
    github_token = os.getenv("GITHUB_TOKEN")
    headers = {"Authorization": f"Bearer {github_token}", "Accept": "application/vnd.github.v3+json"}
    
    inputs = {
        "image_name": config["image_name"],
        "image_tag": config["image_tag"],
        "registry": config.get("registry", "ghcr.io"),
        "dockerfile_path": config.get("dockerfile_path", "./Dockerfile"),
        "build_context": config.get("build_context", "."),
        "ref": config.get("git_ref", "main")
    }
    
    activity.logger.info("run_build_image - Input:")
    pprint({"workflow": WORKFLOW_FILE, "inputs": inputs})
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/workflows/{WORKFLOW_FILE}/dispatches",
                headers=headers,
                json={"ref": config.get("git_ref", "main"), "inputs": inputs}
            )
            response.raise_for_status()
        except Exception as e:
            return {"workflow": "build_image", "status": "failure", "error": str(e)}

        run_id = None
        for _ in range(10):
            res = await client.get(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/workflows/{WORKFLOW_FILE}/runs", 
                headers=headers, params={"per_page": 1}
            )
            if res.status_code == 200:
                runs = res.json().get("workflow_runs", [])
                if runs:
                    run_id = runs[0]["id"]
                    break
            await asyncio.sleep(2)
        
        if not run_id:
            return {"workflow": "build_image", "status": "failure", "error": "Run not found"}
        
        while True:
            res = await client.get(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/runs/{run_id}", 
                headers=headers
            )
            res.raise_for_status()
            data = res.json()
            
            if data.get("status") == "completed":
                conclusion = data.get("conclusion")
                result = {
                    "workflow": "build_image",
                    "status": conclusion,
                    "conclusion": conclusion,
                    "run_id": run_id,
                    "digest": data.get("digest")
                }
                artifact_data = await fetch_workflow_artifact_json(
                    client, config['repo_owner'], config['repo_name'], 
                    run_id, f"build-image-{run_id}", headers
                )
                result.update(artifact_data)
                
                activity.logger.info("run_build_image - Output:")
                pprint({"workflow": WORKFLOW_FILE, "result": result})
                
                return result
            
            activity.heartbeat()
            await asyncio.sleep(5)


@activity.defn
async def run_generate_sbom(statedata: Dict) -> Dict:
    """
    Execute SBOM (Software Bill of Materials) generation workflow.
    
    Part of Phase 2 parallel block. Generates an SBOM for the built
    container image using Trivy.
    
    Extracts image details from statedata['config'] and digest from
    statedata['build'].
    
    Args:
        statedata: Centralized data dict containing config and build results
    
    Returns:
        dict: SBOM generation results including status, conclusion, and run_id
    """
    config = statedata['config']
    build_res = statedata['build']
    
    WORKFLOW_FILE = "02-a-generate-sbom.yml"
    
    github_token = os.getenv("GITHUB_TOKEN")
    headers = {"Authorization": f"Bearer {github_token}", "Accept": "application/vnd.github.v3+json"}
    
    inputs = {
        "image_name": config["image_name"],
        "image_digest": build_res.get("digest"),
        "registry": config.get("registry", "ghcr.io")
    }
    
    activity.logger.info("run_generate_sbom - Input:")
    pprint({"workflow": WORKFLOW_FILE, "inputs": inputs})
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/workflows/{WORKFLOW_FILE}/dispatches",
                headers=headers,
                json={"ref": config.get("git_ref", "main"), "inputs": inputs}
            )
            response.raise_for_status()
        except Exception as e:
            return {"workflow": "generate_sbom", "status": "failure", "error": str(e)}

        run_id = None
        for _ in range(10):
            res = await client.get(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/workflows/{WORKFLOW_FILE}/runs", 
                headers=headers, params={"per_page": 1}
            )
            if res.status_code == 200:
                runs = res.json().get("workflow_runs", [])
                if runs:
                    run_id = runs[0]["id"]
                    break
            await asyncio.sleep(2)
        
        if not run_id:
            return {"workflow": "generate_sbom", "status": "failure", "error": "Run not found"}
        
        while True:
            res = await client.get(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/runs/{run_id}", 
                headers=headers
            )
            res.raise_for_status()
            data = res.json()
            
            if data.get("status") == "completed":
                conclusion = data.get("conclusion")
                result = {
                    "workflow": "generate_sbom",
                    "status": conclusion,
                    "conclusion": conclusion,
                    "run_id": run_id
                }
                
                activity.logger.info("run_generate_sbom - Output:")
                pprint({"workflow": WORKFLOW_FILE, "result": result})
                
                return result
            
            activity.heartbeat()
            await asyncio.sleep(5)


@activity.defn
async def run_scan_sbom(statedata: Dict) -> Dict:
    """
    Execute SBOM vulnerability scanning workflow using Grype.
    
    Security gate following SBOM generation. Scans the SBOM artifact
    for known vulnerabilities and reports critical/high findings.
    
    Extracts repository info from statedata['config'] and SBOM run_id
    from statedata['generate_sbom'].
    
    Args:
        statedata: Centralized data dict containing config and SBOM results
    
    Returns:
        dict: Scan results including status, conclusion, run_id,
              critical_count, high_count, and detailed findings
    """
    config = statedata['config']
    sbom_res = statedata['generate_sbom']
    
    WORKFLOW_FILE = "02-c-scan-sbom.yml"
    
    github_token = os.getenv("GITHUB_TOKEN")
    headers = {"Authorization": f"Bearer {github_token}", "Accept": "application/vnd.github.v3+json"}
    
    inputs = {
        "sbom_artifact_name": f"generate-sbom-{sbom_res['run_id']}",
        "sbom_workflow_run_id": str(sbom_res['run_id'])
    }
    
    activity.logger.info("run_scan_sbom - Input:")
    pprint({"workflow": WORKFLOW_FILE, "inputs": inputs})
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/workflows/{WORKFLOW_FILE}/dispatches",
                headers=headers,
                json={"ref": config.get("git_ref", "main"), "inputs": inputs}
            )
            response.raise_for_status()
        except Exception as e:
            return {"workflow": "scan_sbom", "status": "failure", "error": str(e)}

        run_id = None
        for _ in range(10):
            res = await client.get(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/workflows/{WORKFLOW_FILE}/runs", 
                headers=headers, params={"per_page": 1}
            )
            if res.status_code == 200:
                runs = res.json().get("workflow_runs", [])
                if runs:
                    run_id = runs[0]["id"]
                    break
            await asyncio.sleep(2)
        
        if not run_id:
            return {"workflow": "scan_sbom", "status": "failure", "error": "Run not found"}
        
        while True:
            res = await client.get(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/runs/{run_id}", 
                headers=headers
            )
            res.raise_for_status()
            data = res.json()
            
            if data.get("status") == "completed":
                conclusion = data.get("conclusion")
                result = {
                    "workflow": "scan_sbom",
                    "status": conclusion,
                    "conclusion": conclusion,
                    "run_id": run_id,
                    "critical_count": data.get("critical_count", 0),
                    "high_count": data.get("high_count", 0)
                }
                artifact_data = await fetch_workflow_artifact_json(
                    client, config['repo_owner'], config['repo_name'], 
                    run_id, f"scan-sbom-{run_id}", headers
                )
                result.update(artifact_data)
                
                activity.logger.info("run_scan_sbom - Output:")
                pprint({"workflow": WORKFLOW_FILE, "result": result})
                
                return result
            
            activity.heartbeat()
            await asyncio.sleep(5)


@activity.defn
async def run_sign_image(statedata: Dict) -> Dict:
    """
    Execute container image signing workflow using Cosign.
    
    Part of Phase 2 parallel block. Signs the container image with
    keyless signing using Sigstore/Cosign.
    
    Extracts image details from statedata['config'] and digest from
    statedata['build'].
    
    Args:
        statedata: Centralized data dict containing config and build results
    
    Returns:
        dict: Signing results including status, conclusion, run_id,
              and signature artifact data
    """
    config = statedata['config']
    build_res = statedata['build']
    
    WORKFLOW_FILE = "02-b-sign-image.yml"
    
    github_token = os.getenv("GITHUB_TOKEN")
    headers = {"Authorization": f"Bearer {github_token}", "Accept": "application/vnd.github.v3+json"}
    
    inputs = {
        "image_name": config["image_name"],
        "image_digest": build_res.get("digest"),
        "registry": config.get("registry", "ghcr.io")
    }
    
    activity.logger.info("run_sign_image - Input:")
    pprint({"workflow": WORKFLOW_FILE, "inputs": inputs})
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/workflows/{WORKFLOW_FILE}/dispatches",
                headers=headers,
                json={"ref": config.get("git_ref", "main"), "inputs": inputs}
            )
            response.raise_for_status()
        except Exception as e:
            return {"workflow": "sign_image", "status": "failure", "error": str(e)}

        run_id = None
        for _ in range(10):
            res = await client.get(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/workflows/{WORKFLOW_FILE}/runs", 
                headers=headers, params={"per_page": 1}
            )
            if res.status_code == 200:
                runs = res.json().get("workflow_runs", [])
                if runs:
                    run_id = runs[0]["id"]
                    break
            await asyncio.sleep(2)
        
        if not run_id:
            return {"workflow": "sign_image", "status": "failure", "error": "Run not found"}
        
        while True:
            res = await client.get(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/runs/{run_id}", 
                headers=headers
            )
            res.raise_for_status()
            data = res.json()
            
            if data.get("status") == "completed":
                conclusion = data.get("conclusion")
                result = {
                    "workflow": "sign_image",
                    "status": conclusion,
                    "conclusion": conclusion,
                    "run_id": run_id
                }
                artifact_data = await fetch_workflow_artifact_json(
                    client, config['repo_owner'], config['repo_name'], 
                    run_id, f"sign-image-{run_id}", headers
                )
                result.update(artifact_data)
                
                activity.logger.info("run_sign_image - Output:")
                pprint({"workflow": WORKFLOW_FILE, "result": result})
                
                return result
            
            activity.heartbeat()
            await asyncio.sleep(5)


@activity.defn
async def run_attest_sbom(statedata: Dict) -> Dict:
    """
    Execute SBOM attestation workflow.
    
    Phase 2.5 sequential step. Attaches the SBOM as an attestation
    to the container image using GitHub's attestation API.
    
    Extracts image details from statedata['config'], digest from
    statedata['build'], and SBOM run_id from statedata['generate_sbom'].
    
    Args:
        statedata: Centralized data dict containing config and upstream results
    
    Returns:
        dict: Attestation results including status, conclusion, 
              run_id, and attestation data
    """
    config = statedata['config']
    build_res = statedata['build']
    sbom_res = statedata['generate_sbom']
    
    WORKFLOW_FILE = "03-attest-sbom.yml"
    
    github_token = os.getenv("GITHUB_TOKEN")
    headers = {"Authorization": f"Bearer {github_token}", "Accept": "application/vnd.github.v3+json"}
    
    inputs = {
        "image_name": config["image_name"],
        "image_digest": build_res.get("digest"),
        "registry": config.get("registry", "ghcr.io"),
        "sbom_artifact_name": f"generate-sbom-{sbom_res['run_id']}",
        "sbom_workflow_run_id": str(sbom_res['run_id'])
    }
    
    activity.logger.info("run_attest_sbom - Input:")
    pprint({"workflow": WORKFLOW_FILE, "inputs": inputs})
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/workflows/{WORKFLOW_FILE}/dispatches",
                headers=headers,
                json={"ref": config.get("git_ref", "main"), "inputs": inputs}
            )
            response.raise_for_status()
        except Exception as e:
            return {"workflow": "attest_sbom", "status": "failure", "error": str(e)}

        run_id = None
        for _ in range(10):
            res = await client.get(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/workflows/{WORKFLOW_FILE}/runs", 
                headers=headers, params={"per_page": 1}
            )
            if res.status_code == 200:
                runs = res.json().get("workflow_runs", [])
                if runs:
                    run_id = runs[0]["id"]
                    break
            await asyncio.sleep(2)
        
        if not run_id:
            return {"workflow": "attest_sbom", "status": "failure", "error": "Run not found"}
        
        while True:
            res = await client.get(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/runs/{run_id}", 
                headers=headers
            )
            res.raise_for_status()
            data = res.json()
            
            if data.get("status") == "completed":
                conclusion = data.get("conclusion")
                result = {
                    "workflow": "attest_sbom",
                    "status": conclusion,
                    "conclusion": conclusion,
                    "run_id": run_id
                }
                artifact_data = await fetch_workflow_artifact_json(
                    client, config['repo_owner'], config['repo_name'], 
                    run_id, f"attest-sbom-{run_id}", headers
                )
                result.update(artifact_data)
                
                activity.logger.info("run_attest_sbom - Output:")
                pprint({"workflow": WORKFLOW_FILE, "result": result})
                
                return result
            
            activity.heartbeat()
            await asyncio.sleep(5)


@activity.defn
async def run_verify_signatures(statedata: Dict) -> Dict:
    """
    Execute signature and attestation verification workflow.
    
    Phase 3 final verification. Validates all signatures and attestations
    attached to the container image to ensure SLSA Level 3 compliance.
    
    Extracts image details and preset from statedata['config'], and digest
    from statedata['build'].
    
    Args:
        statedata: Centralized data dict containing config and build results
    
    Returns:
        dict: Verification results including status, conclusion, 
              run_id, and verification details
    """
    config = statedata['config']
    build_res = statedata['build']
    preset_name = config.get("preset", "standard")
    
    WORKFLOW_FILE = "04-verify-signatures.yml"
    
    github_token = os.getenv("GITHUB_TOKEN")
    headers = {"Authorization": f"Bearer {github_token}", "Accept": "application/vnd.github.v3+json"}
    
    inputs = {
        "image_name": config["image_name"],
        "image_digest": build_res.get("digest"),
        "registry": config.get("registry", "ghcr.io"),
        "verify_signature": "true",
        "verify_sbom_attestation": "true",
        "verify_provenance": "true" if preset_name == "standard" else "false"
    }
    
    activity.logger.info("run_verify_signatures - Input:")
    pprint({"workflow": WORKFLOW_FILE, "inputs": inputs})
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/workflows/{WORKFLOW_FILE}/dispatches",
                headers=headers,
                json={"ref": config.get("git_ref", "main"), "inputs": inputs}
            )
            response.raise_for_status()
        except Exception as e:
            return {"workflow": "verify_signatures", "status": "failure", "error": str(e)}

        run_id = None
        for _ in range(10):
            res = await client.get(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/workflows/{WORKFLOW_FILE}/runs", 
                headers=headers, params={"per_page": 1}
            )
            if res.status_code == 200:
                runs = res.json().get("workflow_runs", [])
                if runs:
                    run_id = runs[0]["id"]
                    break
            await asyncio.sleep(2)
        
        if not run_id:
            return {"workflow": "verify_signatures", "status": "failure", "error": "Run not found"}
        
        while True:
            res = await client.get(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/actions/runs/{run_id}", 
                headers=headers
            )
            res.raise_for_status()
            data = res.json()
            
            if data.get("status") == "completed":
                conclusion = data.get("conclusion")
                result = {
                    "workflow": "verify_signatures",
                    "status": conclusion,
                    "conclusion": conclusion,
                    "run_id": run_id
                }
                artifact_data = await fetch_workflow_artifact_json(
                    client, config['repo_owner'], config['repo_name'], 
                    run_id, f"verify-signatures-{run_id}", headers
                )
                result.update(artifact_data)
                
                activity.logger.info("run_verify_signatures - Output:")
                pprint({"workflow": WORKFLOW_FILE, "result": result})
                
                return result
            
            activity.heartbeat()
            await asyncio.sleep(5)


@activity.defn
async def update_commit_status(statedata: Dict) -> Dict:
    """
    Update a GitHub commit status.
    
    Creates or updates a commit status check for tracking pipeline progress.
    
    Extracts repository info, git_sha, and preset from statedata['config'].
    
    Args:
        statedata: Centralized data dict containing config
    
    Returns:
        dict: Update result with status state and method used
    """
    config = statedata['config']
    preset_name = config.get("preset", "standard")
    
    activity.logger.info("update_commit_status - Input:")
    pprint({"git_sha": config.get("git_sha", "")[:8], "preset": preset_name})
    
    github_token = os.getenv("GITHUB_TOKEN")
    
    payload = {
        "state": "success", 
        "context": "SLSA Pipeline", 
        "description": f"SLSA Level 3 completed ({preset_name})"
    }
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                f"https://api.github.com/repos/{config['repo_owner']}/{config['repo_name']}/statuses/{config['git_sha']}", 
                headers={
                    "Authorization": f"Bearer {github_token}", 
                    "Accept": "application/vnd.github.v3+json"
                }, 
                json=payload
            )
            response.raise_for_status()
            result = {"status": "updated", "state": "success"}
            
            activity.logger.info("update_commit_status - Output:")
            pprint(result)
            
            return result
        except Exception as e:
            result = {"status": "failure", "error": str(e)}
            activity.logger.info("update_commit_status - Output:")
            pprint(result)
            return result