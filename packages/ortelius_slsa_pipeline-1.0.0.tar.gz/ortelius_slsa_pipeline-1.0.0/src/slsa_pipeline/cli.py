"""
Command-Line Interface for SLSA Pipeline.

This module provides the Click-based CLI for managing and executing the
SLSA Level 3 build pipeline, including commands for setup, running workers,
and executing pipeline workflows with various presets.
"""

import click
import asyncio
import os
import sys
import shutil
from pathlib import Path

# Add parent directory to path for direct script execution
if __name__ == '__main__':
    sys.path.insert(0, str(Path(__file__).parent.parent))

# Always use absolute imports for type checking
# Imports must be AFTER the sys.path hack above for direct execution to work
from slsa_pipeline.presets import list_presets, get_preset  # type: ignore[assignment]
from slsa_pipeline.orchestrator import SLSABuildPipeline # type: ignore
from slsa_pipeline.temporal import connect_temporal  # <--- Imported here, after sys.path fix


@click.group()
@click.version_option(version='1.0.0')
def cli():
    """SLSA Pipeline - Temporal-based SLSA Level 3 CI/CD orchestration."""
    pass


@cli.command()
def setup():
    """
    Copy GitHub Actions workflows to the local repository.
    
    This command copies all required workflow YAML files from the package
    installation to the current repository's .github/workflows directory.
    Must be run from the repository root.
    """
    click.echo("📋 Setting up GitHub Actions workflows...")
    
    # Logic to locate workflows directory (assuming it's relative to the package)
    src_workflows = Path(__file__).parent.parent.parent / ".github" / "workflows"
    dest_workflows = Path.cwd() / ".github" / "workflows"
    
    if not src_workflows.exists():
        click.echo("❌ Source workflows not found. Ensure you are running from the project root.", err=True)
        click.get_current_context().exit(1)

    dest_workflows.mkdir(parents=True, exist_ok=True)
    for wf_file in src_workflows.glob("*.yml"):
        shutil.copy(wf_file, dest_workflows)
        click.echo(f"  ✓ Copied {wf_file.name}")
    
    click.echo(f"\n✅ Workflows copied to {dest_workflows}")


@cli.command()
def worker():
    """
    Start the Temporal worker to poll for tasks.
    
    The worker connects to the Temporal server and begins polling for
    workflow and activity tasks. It must be running for pipelines to execute.
       
    Environment Variables Required:
        GITHUB_TOKEN: GitHub Personal Access Token with repo permissions
        ANTHROPIC_API_KEY: (Optional) For auto-fix functionality
        TEMPORAL_URL: (Optional) Cloud Enpoint
        TEMPORAL_NAMESPACE: (Optional) Cloud Namespace
        TEMPORAL_API_KEY: (Optional) Cloud API Key
    """
    from slsa_pipeline.temporal import start_worker
    
    click.echo("🔧 Starting SLSA Pipeline Worker...")
    
    # Validate environment variables before starting
    if not os.getenv("GITHUB_TOKEN"):
        click.echo("❌ GITHUB_TOKEN environment variable not set", err=True)
        click.get_current_context().exit(1)

    try:
        asyncio.run(start_worker())
    except KeyboardInterrupt:
        click.echo("\n🛑 Worker shut down by user")
        click.get_current_context().exit(0)
    except Exception as e:
        click.echo(f"\n❌ Worker failed: {str(e)}", err=True)
        click.get_current_context().exit(1)


async def monitor_progress(handle):
    """
    Monitor workflow execution progress via Temporal queries.
    
    Continuously polls the workflow for status updates and displays
    them to the user. Exits when the workflow completes or fails.
    
    Args:
        handle: Temporal workflow handle for querying status
    """
    last_status = ""
    while True:
        try:
            # Query the orchestrator progress via Temporal Query
            progress = await handle.query(SLSABuildPipeline.get_progress)
            if progress != last_status:
                click.echo(f"  [Status]: {progress}")
                last_status = progress
            
            # Check if workflow is finished
            desc = await handle.describe()
            if desc.status.name != "RUNNING":
                break
            await asyncio.sleep(2)
        except Exception as e:
            # Handle cases where query is not yet registered or connection issues
            if "query task not found" in str(e).lower():
                await asyncio.sleep(2)
                continue
            break


@cli.command()
@click.option('--preset', required=True, type=click.Choice(['minimal', 'standard', 'skip_linting']), help='Preset to use')
@click.option('--repo-owner', required=True, help='GitHub repository owner')
@click.option('--repo-name', required=True, help='Repository name')
@click.option('--image-name', required=True, help='Container image name')
@click.option('--image-tag', required=True, help='Image tag')
@click.option('--registry', default='ghcr.io', help='Container registry')
@click.option('--git-ref', default='main', help='Git reference')
@click.option('--git-sha', help='Git commit SHA (for status updates)')
@click.option('--dockerfile-path', default='./Dockerfile', help='Dockerfile path')
@click.option('--build-context', default='.', help='Build context')
@click.option('--severity', help='Vulnerability severity threshold')
@click.option('--max-findings', type=int, help='Maximum allowed findings')
@click.option('--update-commit-status', is_flag=True, help='Update GitHub commit status')
@click.option('--auto-fix-lint', is_flag=True, help='Auto-fix lint errors with Claude AI')
def run(**kwargs):
    """
    Run SLSA pipeline with specified preset and real-time feedback.
    
    Executes a complete SLSA Level 3 build pipeline using the specified preset.
    The pipeline includes linting, building, SBOM generation, vulnerability scanning,
    signing, attestation, and verification depending on the preset selected.
    
    Presets:
        minimal: Fast feedback for development - basic security checks only
        standard: Production-ready SLSA Level 3 with full verification
        skip_linting: Production pipeline without linting phase
    
    Environment Variables Required:
        GITHUB_TOKEN: GitHub Personal Access Token
        ANTHROPIC_API_KEY: (Optional) For --auto-fix-lint feature
    
    Examples:
        # Run standard pipeline
        slsa-pipeline run --preset standard --repo-owner myorg --repo-name myrepo \\
            --image-name myapp --image-tag v1.0.0
        
        # Run with auto-fix enabled
        slsa-pipeline run --preset standard --repo-owner myorg --repo-name myrepo \\
            --image-name myapp --image-tag v1.0.0 --auto-fix-lint
    """
    
    async def execute():
        """
        Internal async function to execute the pipeline workflow.
        
        Connects to Temporal, starts the workflow, monitors progress,
        and returns the final result.
        """
        # Connect to Temporal Client
        try:
            client = await connect_temporal()
        except Exception as e:
            raise click.ClickException(f"Failed to connect to Temporal: {e}")

        click.echo(f"🚀 Starting {kwargs['preset']} pipeline for {kwargs['image_name']}:{kwargs['image_tag']}...")
        click.echo(f"   Repository: {kwargs['repo_owner']}/{kwargs['repo_name']}")
        click.echo()
        
        # Validate environment variables
        if not os.getenv("GITHUB_TOKEN"):
            raise click.ClickException("GITHUB_TOKEN environment variable not set")
        
        if kwargs.get('auto_fix_lint') and not os.getenv("ANTHROPIC_API_KEY"):
            click.echo("⚠️  Warning: --auto-fix-lint enabled but ANTHROPIC_API_KEY not set", err=True)
            click.echo("   Auto-fix will be skipped if lint errors occur", err=True)
            click.echo()

        # Generate deterministic Workflow ID
        workflow_id = f"slsa-{kwargs['image_name'].replace('/', '-')}-{kwargs['image_tag']}"
        
        try:
            # Start workflow asynchronously
            handle = await client.start_workflow(
                SLSABuildPipeline.run,
                kwargs,
                id=workflow_id,
                task_queue="slsa-pipeline-tasks"
            )
            
            click.echo(f"📊 Workflow ID: {workflow_id}")
            
            # Start monitoring the progress query
            await monitor_progress(handle)
            
            # Wait for final result
            result = await handle.result()
            click.echo()
            click.echo(f"✅ Pipeline Status: {result.get('status')}")
            click.echo(f"🛡️ Compliance: {result.get('compliance', 'N/A')}")
            
        except KeyboardInterrupt:
            click.echo("\n⚠️  Pipeline interrupted by user. Workflow continues on server.", err=True)
            click.echo(f"   Workflow ID: {workflow_id}", err=True)
            click.echo("   Check status: http://localhost:8233", err=True)
            raise click.Abort()
        except Exception as e:
            click.echo(f"\n❌ Pipeline failed: {str(e)}", err=True)
            
            if "refused" in str(e).lower():
                click.echo("\n💡 Hint: Is Temporal server running?", err=True)
                click.echo("   Start with: docker-compose up -d", err=True)
            elif "unauthorized" in str(e).lower() or "403" in str(e):
                click.echo("\n💡 Hint: Check your GITHUB_TOKEN permissions", err=True)
            
            raise click.ClickException("Pipeline execution failed")

    # Run the async execution logic
    asyncio.run(execute())


@cli.command(name='list-presets')
def list_presets_cmd():
    """
    List all available pipeline presets.
    
    Displays the name, description, and included workflows for each
    available preset configuration.
    """
    presets = list_presets()
    click.echo("\n📋 Available Presets:\n")
    for name, preset in presets.items():
        click.echo(f"  {name}")
        click.echo(f"    Description: {preset.description}")
        click.echo(f"    Workflows: {', '.join(preset.workflows)}")
        click.echo()


@cli.command()
@click.argument('type', type=click.Choice(['preset']))
@click.argument('name')
def inspect(type, name):
    """
    Inspect a preset configuration in detail.
    
    Shows the complete configuration for a preset including all workflows,
    failure behaviors, and security settings.
    
    Args:
        type: Object type to inspect (currently only 'preset' supported)
        name: Name of the preset to inspect
    
    Example:
        slsa-pipeline inspect preset standard
    """
    try:
        obj = get_preset(name)
        click.echo(f"\nPreset: {name}\n")
        click.echo(f"  Display Name: {obj.display_name}")
        click.echo(f"  Description: {obj.description}")
        click.echo("  Workflows:")
        for wf in obj.workflows:
            click.echo(f"    - {wf}")
        click.echo(f"  Fail on Lint Errors: {obj.fail_on_lint_errors}")
        click.echo(f"  Fail on Vulnerabilities: {obj.fail_on_vulnerabilities}")
        click.echo(f"  Vulnerability Severity: {obj.vulnerability_severity}")
        click.echo()
    except ValueError as e:
        click.echo(f"❌ {str(e)}", err=True)
        click.get_current_context().exit(1)


if __name__ == "__main__":
    cli()