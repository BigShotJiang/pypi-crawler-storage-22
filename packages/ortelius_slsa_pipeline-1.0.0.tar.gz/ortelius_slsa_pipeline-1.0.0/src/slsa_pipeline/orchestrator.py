"""
Temporal Workflow Orchestrator for SLSA Pipeline.

This module implements the main workflow orchestration logic using a state machine
pattern. It coordinates all phases of the SLSA Level 3 build pipeline including
linting, building, security scanning, signing, attestation, and verification.

Uses a dependency-driven state transitions where each state
declares prerequisites instead of knowing downstream states. All data
flows through a centralized 'statedata' dictionary.

The orchestrator uses Temporal's workflow capabilities to provide:
- Durable execution with automatic retries
- Progress tracking via queries
- Parallel execution of independent tasks
- State management across long-running processes
"""

from datetime import timedelta
import asyncio
from typing import Dict, Any, List
from enum import Enum
from temporalio import workflow
from temporalio.exceptions import ApplicationError

from .presets import get_preset


class PipelineState(Enum):
    """
    Explicit workflow states for state machine dispatch.
    
    Each state represents a phase in the SLSA pipeline execution.
    States now declare their dependencies rather than knowing next states,
    enabling a more flexible and testable architecture.
    
    States:
        INIT: Initialize workflow context and determine starting point
        LINT: Execute code quality and linting checks
        AUTO_FIX: Auto-fix lint errors using Claude AI
        BUILD: Build container image
        BUILD_FAILURE: Handle build failures and create issues
        PARALLEL_SBOM_SIGN: Parallel execution of SBOM generation and image signing
        VULNERABILITY_REMEDIATION: Handle critical/high vulnerabilities
        ATTEST: Attach SBOM as attestation to image
        VERIFY: Verify all signatures and attestations
        VERIFY_FAILURE: Handle verification failures and create issues
        UPDATE_STATUS: Update GitHub commit status (if configured)
        DONE: Successfully completed
        FAILED: Pipeline failed at some stage
    """
    INIT = "init"
    LINT = "lint"
    AUTO_FIX = "auto_fix"
    BUILD = "build"
    BUILD_FAILURE = "build_failure"
    PARALLEL_SBOM_SIGN = "parallel_sbom_sign"
    VULNERABILITY_REMEDIATION = "vulnerability_remediation"
    ATTEST = "attest"
    VERIFY = "verify"
    VERIFY_FAILURE = "verify_failure"
    UPDATE_STATUS = "update_status"
    DONE = "done"
    FAILED = "failed"


def get_state_dependencies(preset) -> Dict[PipelineState, List[PipelineState]]:
    """
    Get state dependencies dynamically based on preset configuration.
    
    This function builds the dependency graph based on which workflows
    are enabled in the preset, allowing states to be optional/skipped.
    
    Args:
        preset: PresetDefinition with workflow configuration
    
    Returns:
        dict: Mapping of states to their prerequisite states
    
    Examples:
        With linting enabled:
            LINT -> [INIT]
            BUILD -> [LINT]
        
        Without linting:
            BUILD -> [INIT]  # LINT is skipped
            
        With linting and auto-fix:
            LINT -> [INIT]
            AUTO_FIX -> [LINT]  # Only if lint errors found
            BUILD -> [AUTO_FIX or LINT]
    """
    deps = {
        PipelineState.INIT: [],
        PipelineState.DONE: [],
        PipelineState.FAILED: []
    }
    
    # Determine LINT dependencies
    if "megalinter" in preset.workflows:
        deps[PipelineState.LINT] = [PipelineState.INIT]
        # AUTO_FIX is conditionally added during execution
        # BUILD will depend on LINT (or AUTO_FIX if it runs)
        deps[PipelineState.BUILD] = [PipelineState.LINT]
    else:
        deps[PipelineState.BUILD] = [PipelineState.INIT]
    
    # PARALLEL_SBOM_SIGN always depends on BUILD
    deps[PipelineState.PARALLEL_SBOM_SIGN] = [PipelineState.BUILD]
    
    # Determine ATTEST dependencies
    if "attest_sbom" in preset.workflows:
        deps[PipelineState.ATTEST] = [PipelineState.PARALLEL_SBOM_SIGN]
        
        # VERIFY depends on ATTEST if both are enabled
        if "verify_signatures" in preset.workflows:
            deps[PipelineState.VERIFY] = [PipelineState.ATTEST]
            deps[PipelineState.UPDATE_STATUS] = [PipelineState.VERIFY]
        else:
            deps[PipelineState.UPDATE_STATUS] = [PipelineState.ATTEST]
    else:
        # No attestation, check if verification is standalone
        if "verify_signatures" in preset.workflows:
            deps[PipelineState.VERIFY] = [PipelineState.PARALLEL_SBOM_SIGN]
            deps[PipelineState.UPDATE_STATUS] = [PipelineState.VERIFY]
        else:
            deps[PipelineState.UPDATE_STATUS] = [PipelineState.PARALLEL_SBOM_SIGN]
    
    return deps


@workflow.defn(name="SLSABuildPipeline")
class SLSABuildPipeline:
    """
    Main Temporal workflow for SLSA Level 3 build pipeline orchestration.
    
    This workflow implements a dependency-driven state machine that coordinates 
    all phases of the SLSA build process. It manages state transitions, handles
    failures, creates issues for problems, and provides progress tracking.
    
    All workflow state and results flow through a centralized 'statedata' 
    dictionary, allowing activities to extract their own inputs and enabling
    better testability and separation of concerns.
    
    Attributes:
        _current_step: Human-readable description of current activity
        state: Current state in the pipeline state machine
        statedata: Dictionary holding all workflow state and results
        completed_states: Set of states that have successfully completed
        state_dependencies: Dynamic dependency graph based on preset config
    """
    
    def __init__(self) -> None:
        """Initialize workflow with default state."""
        self._current_step: str = "Initializing"
        self.state: PipelineState = PipelineState.INIT
        self.statedata: Dict[str, Any] = {}  # Centralized data store
        self.completed_states: set = set()
        self.state_dependencies: Dict[PipelineState, List[PipelineState]] = {}

    @workflow.query
    def get_progress(self) -> str:
        """
        Query handler to return the current step to CLI clients.
        
        This query can be called by external clients (like the CLI)
        to check the current status of the workflow execution without
        blocking or affecting the workflow's progress.
        
        Returns:
            str: Human-readable description of current step
        """
        return self._current_step

    @workflow.run
    async def run(self, config: Dict) -> Dict:
        """
        Main workflow entry point implementing state machine orchestration.
        
        This is the workflow's run method that gets invoked when the
        workflow is started. It implements a state machine loop that
        continues until reaching DONE or FAILED states.
        
        All configuration and results are stored in the centralized 'statedata'
        dictionary, which is passed to activities for input extraction.
        
        Args:
            config: Pipeline configuration dictionary containing:
                - preset: Name of preset to use
                - repo_owner: GitHub repository owner
                - repo_name: Repository name
                - image_name: Container image name
                - image_tag: Image tag
                - git_ref: Git reference (branch/tag/SHA)
                - auto_fix_lint: Enable Claude AI auto-fix
                - update_commit_status: Update GitHub commit status
                - And other preset-specific parameters
        
        Returns:
            dict: Final pipeline result with status and compliance level
        
        Raises:
            ApplicationError: If pipeline fails at any stage
        """
        try:
            # Initialize statedata with config
            self.statedata['config'] = config
            self.statedata['preset'] = get_preset(config.get("preset", "standard"))
            
            # Build dynamic state dependencies based on preset
            self.state_dependencies = get_state_dependencies(self.statedata['preset'])
            
            # State machine loop
            while self.state not in (PipelineState.DONE, PipelineState.FAILED):
                await self._dispatch_state()
            
            if self.state == PipelineState.FAILED:
                error_msg = self.statedata.get("error_message", "Unknown error")
                raise ApplicationError(error_msg, non_retryable=True)
            
            return {"status": "success", "compliance": "SLSA Level 3"}
            
        except Exception as e:
            self.state = PipelineState.FAILED
            self.statedata["error_message"] = str(e)
            self._current_step = f"Failed: {str(e)}"
            workflow.logger.error(f"❌ Pipeline failed: {str(e)}")
            
            if "404" not in str(e):
                try:
                    await self._create_failure_issue()
                except Exception as issue_err:
                    workflow.logger.error(f"Failed to create failure issue: {str(issue_err)}")
            
            if isinstance(e, ApplicationError):
                raise e
            raise ApplicationError(str(e), non_retryable=True) from e

    async def _dispatch_state(self) -> None:
        """
        Route to appropriate step handler based on current state.
        
        This dispatcher method is the core of the state machine. It examines
        the current state and delegates to the appropriate step handler method.
        Each handler is responsible for executing its phase, storing results
        in statedata, and transitioning to the next state.
        
        Raises:
            ApplicationError: If an unknown state is encountered
        """
        match self.state:
            case PipelineState.INIT:
                await self._step_initialize()
            case PipelineState.LINT:
                await self._step_lint()
            case PipelineState.AUTO_FIX:
                await self._step_auto_fix()
            case PipelineState.BUILD:
                await self._step_build()
            case PipelineState.BUILD_FAILURE:
                await self._step_build_failure()
            case PipelineState.PARALLEL_SBOM_SIGN:
                await self._step_parallel_sbom_sign()
            case PipelineState.VULNERABILITY_REMEDIATION:
                await self._step_vulnerability_remediation()
            case PipelineState.ATTEST:
                await self._step_attest()
            case PipelineState.VERIFY:
                await self._step_verify()
            case PipelineState.VERIFY_FAILURE:
                await self._step_verify_failure()
            case PipelineState.UPDATE_STATUS:
                await self._step_update_status()
            case _:
                raise ApplicationError(f"Unknown state: {self.state}", non_retryable=True)

    def _get_next_state(self) -> PipelineState:
        """
        Determine next state based on preset configuration and completed states.
        
        This method implements the state transition logic by examining:
        - Current state
        - Dynamic state dependencies built from preset
        - Set of completed states
        
        States are only transitioned to if they are in the dependency graph
        (meaning they're enabled in the preset). This allows states to be
        completely skipped if not needed.
        
        Returns:
            PipelineState: The next state to transition to
        
        Examples:
            With linting enabled:
                INIT -> LINT -> BUILD -> ...
            
            Without linting:
                INIT -> BUILD -> ...  (LINT is completely skipped)
                
            With linting and auto-fix enabled (and errors found):
                INIT -> LINT -> AUTO_FIX -> BUILD -> ...
        """
        # Define potential state transitions in order
        state_order = [
            PipelineState.INIT,
            PipelineState.LINT,
            PipelineState.AUTO_FIX,
            PipelineState.BUILD,
            PipelineState.PARALLEL_SBOM_SIGN,
            PipelineState.VULNERABILITY_REMEDIATION,
            PipelineState.ATTEST,
            PipelineState.VERIFY,
            PipelineState.UPDATE_STATUS,
            PipelineState.DONE
        ]
        
        # Find current position
        try:
            current_idx = state_order.index(self.state)
        except ValueError:
            return PipelineState.DONE
        
        # Look for next enabled state
        for next_state in state_order[current_idx + 1:]:
            # Check if this state is in the dependency graph (meaning it's enabled)
            if next_state in self.state_dependencies:
                # Check if all dependencies are satisfied
                deps = self.state_dependencies[next_state]
                if all(dep in self.completed_states for dep in deps):
                    return next_state
        
        # No more states to execute
        return PipelineState.DONE

    # ============================================================
    # STEP FUNCTIONS (store results in statedata, determine next state)
    # ============================================================

    async def _step_initialize(self) -> None:
        """
        Initialize workflow and determine next state.
        
        Sets up the workflow context, logs initialization, stores initial
        results in statedata, and determines the first execution phase 
        based on the selected preset configuration.
        
        Stores:
            statedata['init']: Init results with preset_name
        
        State Transitions:
            - To LINT if preset includes megalinter
            - To BUILD otherwise
        """
        config = self.statedata['config']
        preset_name = config.get("preset", "standard")
        
        self._current_step = f"Started: Using preset '{preset_name}'"
        workflow.logger.info(f"🚀 Starting SLSA Pipeline (Preset: {preset_name})")
        
        # Store init results
        self.statedata[PipelineState.INIT.value] = {"preset_name": preset_name}
        self.completed_states.add(PipelineState.INIT)
        
        # Transition
        self.state = self._get_next_state()

    async def _step_lint(self) -> None:
        """
        Orchestrate linting phase.
        
        Executes MegaLinter to check code quality and stores results.
        Instead of handling auto-fix inline, it dynamically adds AUTO_FIX
        to the dependency graph if errors are found and auto-fix is enabled.
        
        Stores:
            statedata['lint']: Lint results including errors and linter details
        
        State Transitions:
            - Adds AUTO_FIX to dependencies if errors found and auto_fix_lint enabled
            - To AUTO_FIX if added to dependency graph
            - To BUILD if no errors or auto-fix not enabled
            - Raises ApplicationError if preset.fail_on_lint_errors and errors found
        
        Raises:
            ApplicationError: If linting fails and preset.fail_on_lint_errors is True
        """
        self._current_step = "Step 0: Running MegaLinter"
        workflow.logger.info("Step 0: Starting MegaLinter...")
        
        # Activity extracts its own inputs from statedata
        lint_result = await workflow.execute_activity(
            "run_megalinter",
            args=[self.statedata],
            start_to_close_timeout=timedelta(minutes=20)
        )
        
        # Store in statedata
        self.statedata[PipelineState.LINT.value] = lint_result
        self.completed_states.add(PipelineState.LINT)
        
        # Handle errors
        preset = self.statedata['preset']
        config = self.statedata['config']
        linters_failed = int(lint_result.get("linters_failed", 0))
        lint_errs_list = lint_result.get("lint_errs", [])
        conclusion = lint_result.get("conclusion")
        
        # Calculate stats
        total_errors = sum(int(linter.get("total_number_errors", 0)) for linter in lint_errs_list)
        linters_run_count = len(lint_errs_list)
        
        # Check if we have errors that need handling
        has_errors = linters_failed > 0 or total_errors > 0 or conclusion == "failure"
        
        if has_errors:
            workflow.logger.warning(f"⚠️ Linting issues found: {linters_run_count} linters run, {total_errors} errors.")
            
            # Dynamically add AUTO_FIX state to dependency graph if enabled
            if config.get("auto_fix_lint", False):
                workflow.logger.info("Auto-fix enabled, adding AUTO_FIX state to pipeline")
                
                # Dynamic Derivation: Identify any state that currently depends on LINT
                downstream_states = [
                    state for state, deps in self.state_dependencies.items()
                    if PipelineState.LINT in deps
                ]
                
                # Cut the cord: Remove those states from the execution graph
                for state in downstream_states:
                    del self.state_dependencies[state]

                # Insert AUTO_FIX: Add the new path that ends after this step
                self.state_dependencies[PipelineState.AUTO_FIX] = [PipelineState.LINT]
                
            elif preset.fail_on_lint_errors:
                # No auto-fix and strict mode - fail immediately
                raise ApplicationError(
                    f"Linting failed: {linters_run_count} linters run, {total_errors} errors",
                    non_retryable=True
                )
            # else: errors exist but not in strict mode and no auto-fix, continue to BUILD
        
        # Transition to next state (either AUTO_FIX or BUILD depending on above logic)
        self.state = self._get_next_state()

    async def _step_auto_fix(self) -> None:
        """
        Orchestrate auto-fix workflow for lint errors using Claude AI.
        
        This is a full state handler that coordinates the process of:
        1. Identifying files with errors (via activity)
        2. Analyzing errors with Claude AI (via activity)
        3. Creating a fix branch (via activity)
        4. Pushing corrected files (via activity)
        5. Creating a pull request with fixes (via activity)
        
        All activities extract their inputs from statedata.
        
        Stores:
            statedata['auto_fix']: Auto-fix results including PR details
        
        State Transitions:
            - To BUILD after attempting fixes (success or failure)
            - Raises ApplicationError if preset.fail_on_lint_errors and fixes fail
        
        Note:
            This is a best-effort process - failures in auto-fix do not
            necessarily fail the pipeline unless fail_on_lint_errors is True.
        """
        self._current_step = "Step 0: Auto-Fix - Identifying files"
        workflow.logger.info("Step 0: Starting Auto-Fix workflow")
        
        lint_result = self.statedata[PipelineState.LINT.value]
        lint_errs_list = lint_result.get("lint_errs", [])
        preset = self.statedata['preset']
        
        auto_fix_result: Dict[str, Any] = {"attempted": True, "success": False}
        
        try:
            # Get files with errors
            lint_files = await workflow.execute_activity(
                "get_files_with_lint_errors",
                args=[lint_errs_list, self.statedata],
                start_to_close_timeout=timedelta(minutes=5)
            )
            
            if not lint_files:
                workflow.logger.info("Step 0: Auto-Fix - No source files identified to fix.")
                auto_fix_result["reason"] = "no_files_found"
                self.statedata[PipelineState.AUTO_FIX.value] = auto_fix_result
                self.completed_states.add(PipelineState.AUTO_FIX)
                
                # Still fail if strict mode
                if preset.fail_on_lint_errors:
                    raise ApplicationError("Linting failed and auto-fix found no files", non_retryable=True)
                
                self.state = self._get_next_state()
                return
            
            # Analyze with Claude
            self._current_step = f"Step 0: Auto-Fix - Analyzing {len(lint_files)} files with Claude"
            fix_result = await workflow.execute_activity(
                "analyze_lint_failures_with_claude",
                args=[lint_errs_list, lint_files, self.statedata],
                start_to_close_timeout=timedelta(minutes=3)
            )
            
            if not (fix_result.get("can_fix") and fix_result.get("fixes")):
                workflow.logger.info("Step 0: Auto-Fix - Claude could not determine fixes.")
                auto_fix_result["reason"] = "claude_no_fix"
                auto_fix_result["claude_response"] = fix_result
                self.statedata[PipelineState.AUTO_FIX.value] = auto_fix_result
                self.completed_states.add(PipelineState.AUTO_FIX)
                
                # Still fail if strict mode
                if preset.fail_on_lint_errors:
                    raise ApplicationError("Linting failed and Claude could not fix", non_retryable=True)
                
                self.state = self._get_next_state()
                return
            
            # Create fix branch and PR
            workflow.logger.info("🤖 Claude AI generated fixes. Creating pull request...")
            self._current_step = "Step 0: Auto-Fix - Applying fixes"
            
            now_ts = int(workflow.now().timestamp())
            fix_branch = f"fix/lint-errors-{now_ts}"
            
            await workflow.execute_activity(
                "mcp_create_branch",
                args=[fix_branch, self.statedata],
                start_to_close_timeout=timedelta(minutes=2)
            )
            
            await workflow.execute_activity(
                "mcp_push_files",
                args=[fix_branch, fix_result["fixes"], self.statedata],
                start_to_close_timeout=timedelta(minutes=3)
            )
            
            self._current_step = "Step 0: Auto-Fix - Creating PR"
            pr_result = await workflow.execute_activity(
                "create_pull_request_with_fixes",
                args=[fix_branch, fix_result, self.statedata],
                start_to_close_timeout=timedelta(minutes=2)
            )
            
            self._current_step = "Step 0: Auto-fix PR created"
            workflow.logger.info(f"✅ Auto-fix PR created successfully: {pr_result.get('url')}")
            
            auto_fix_result["success"] = True
            auto_fix_result["pr_number"] = pr_result.get("number")
            auto_fix_result["pr_url"] = pr_result.get("url")
            auto_fix_result["fixes_count"] = len(fix_result.get("fixes", []))
            
        except Exception as e:
            workflow.logger.error(f"❌ Auto-fix attempt failed: {str(e)}")
            auto_fix_result["error"] = str(e)
            
            # Only re-raise if strict mode
            if preset.fail_on_lint_errors:
                raise ApplicationError(f"Auto-fix failed: {str(e)}", non_retryable=True)
        
        # Store results and mark complete
        self.statedata[PipelineState.AUTO_FIX.value] = auto_fix_result
        self.completed_states.add(PipelineState.AUTO_FIX)
        
        # Transition to BUILD
        self.state = self._get_next_state()

    async def _step_build(self) -> None:
        """
        Orchestrate container image build phase.
        
        Triggers the build workflow (activity extracts inputs from statedata),
        waits for completion, and stores the image digest for use in downstream 
        steps.
        
        Stores:
            statedata['build']: Build results including digest
        
        State Transitions:
            - To PARALLEL_SBOM_SIGN on successful build
            - To BUILD_FAILURE if build fails
        """
        self._current_step = "Step 1: Building image"
        
        build_res = await workflow.execute_activity(
            "run_build_image",
            args=[self.statedata],
            start_to_close_timeout=timedelta(minutes=30)
        )
        
        self.statedata[PipelineState.BUILD.value] = build_res
        self.completed_states.add(PipelineState.BUILD)
        
        # Check for build failure and transition to failure state
        if build_res.get("conclusion") == "failure" or build_res.get("status") == "failure":
            workflow.logger.error("❌ Build failed")
            # Add BUILD_FAILURE to dependency graph
            self.state_dependencies[PipelineState.BUILD_FAILURE] = [PipelineState.BUILD]
            self.state = PipelineState.BUILD_FAILURE
            return
        
        workflow.logger.info(f"✅ Build successful: {build_res.get('digest')}")
        self.state = self._get_next_state()

    async def _step_build_failure(self) -> None:
        """
        Handle build failure by creating a specific GitHub issue.
        
        This state is reached when the container build fails. It creates
        a detailed GitHub issue with build logs and diagnostic information,
        then fails the pipeline.
        
        Stores:
            statedata['build_failure']: Failure handling results
        
        Raises:
            ApplicationError: Always - build failures are terminal
        """
        self._current_step = "Step 1: Handling build failure"
        workflow.logger.info("Step 1: Creating build failure issue")
        
        config = self.statedata['config']
        build_res = self.statedata.get(PipelineState.BUILD.value, {})
        error_msg = build_res.get("error", "Build failed")
        run_id = build_res.get("run_id", "unknown")
        
        failure_result: Dict[str, Any] = {
            "build_run_id": run_id,
            "error": error_msg,
            "issue_created": False
        }
        
        # Create specific build failure issue
        try:
            workflow_url = f"https://github.com/{config['repo_owner']}/{config['repo_name']}/actions/runs/{run_id}"
            
            issue_result = await workflow.execute_activity(
                "create_failure_issue",
                args=[{
                    **self.statedata,
                    "error_message": f"Build failed for {config['image_name']}:{config['image_tag']}\n\n**Error:** {error_msg}\n\n**Build Run:** {workflow_url}",
                    "config": config
                }],
                start_to_close_timeout=timedelta(minutes=2)
            )
            
            failure_result["issue_created"] = True
            failure_result["issue_number"] = issue_result.get("number")
            workflow.logger.info(f"📋 Build failure issue created: #{issue_result.get('number')}")
        except Exception as e:
            workflow.logger.warning(f"Could not create build failure issue: {str(e)}")
            failure_result["issue_error"] = str(e)
        
        # Store results
        self.statedata[PipelineState.BUILD_FAILURE.value] = failure_result
        self.completed_states.add(PipelineState.BUILD_FAILURE)
        
        # Always fail on build errors
        raise ApplicationError(f"Build failed: {error_msg}", non_retryable=True)

    async def _step_parallel_sbom_sign(self) -> None:
        """
        Orchestrate parallel SBOM generation and image signing.
        
        Executes two independent branches in parallel:
        - SBOM Branch: Generate SBOM and scan for vulnerabilities
        - Sign Branch: Sign the container image
        
        Both branches must complete successfully before proceeding.
        Activities in each branch extract their inputs from statedata.
        
        State Transitions:
            - To ATTEST if preset includes attest_sbom
            - To VERIFY if preset includes verify_signatures (but not attest)
            - To UPDATE_STATUS otherwise
        
        Raises:
            ApplicationError: If either branch fails
        """
        self._current_step = "Step 2: Parallel SBOM & Sign"
        
        results = await asyncio.gather(
            self._orchestrate_sbom_branch(),
            self._orchestrate_sign_branch(),
            return_exceptions=True
        )
        
        for result in results:
            if isinstance(result, Exception):
                raise result
        
        self.completed_states.add(PipelineState.PARALLEL_SBOM_SIGN)
        self.state = self._get_next_state()

    async def _orchestrate_sbom_branch(self) -> None:
        """
        Orchestrate SBOM generation and vulnerability scanning branch.
        
        This sub-workflow:
        1. Generates an SBOM for the built image (activity extracts digest from statedata)
        2. Scans the SBOM for security vulnerabilities (activity extracts SBOM run_id)
        3. Dynamically adds VULNERABILITY_REMEDIATION state if critical/high vulns found
        
        Stores:
            statedata['generate_sbom']: SBOM generation results with run_id
            statedata['scan_sbom']: Scan results with vulnerability counts
        
        Note:
            Does NOT raise ApplicationError here - vulnerability handling is
            delegated to VULNERABILITY_REMEDIATION state if needed.
        """
        sbom_res = await workflow.execute_activity(
            "run_generate_sbom",
            args=[self.statedata],
            start_to_close_timeout=timedelta(minutes=15)
        )
        self.statedata['generate_sbom'] = sbom_res
        
        scan_res = await workflow.execute_activity(
            "run_scan_sbom",
            args=[self.statedata],
            start_to_close_timeout=timedelta(minutes=15)
        )
        self.statedata['scan_sbom'] = scan_res
        
        critical = int(scan_res.get("critical_count", 0))
        high = int(scan_res.get("high_count", 0))
        
        # Check if we have vulnerabilities that need handling
        if critical > 0 or high > 0:
            workflow.logger.warning(f"⚠️ Vulnerabilities found: {critical} Critical, {high} High")
            
            # Dynamically add VULNERABILITY_REMEDIATION state to handle this
            workflow.logger.info("Adding VULNERABILITY_REMEDIATION state to pipeline")
            self.state_dependencies[PipelineState.VULNERABILITY_REMEDIATION] = [PipelineState.PARALLEL_SBOM_SIGN]
            
            # Update downstream dependencies
            preset = self.statedata['preset']
            if "attest_sbom" in preset.workflows:
                self.state_dependencies[PipelineState.ATTEST] = [PipelineState.VULNERABILITY_REMEDIATION]
            elif "verify_signatures" in preset.workflows:
                self.state_dependencies[PipelineState.VERIFY] = [PipelineState.VULNERABILITY_REMEDIATION]
            else:
                self.state_dependencies[PipelineState.UPDATE_STATUS] = [PipelineState.VULNERABILITY_REMEDIATION]
        else:
            workflow.logger.info(f"✅ SBOM scan clean: {critical} Critical, {high} High")

    async def _orchestrate_sign_branch(self) -> None:
        """
        Orchestrate image signing branch.
        
        Signs the container image using Cosign with keyless signing.
        Activity extracts image details from statedata.
        
        Stores:
            statedata['sign_image']: Signing results
        
        Raises:
            ApplicationError: If signing fails
        """
        sign_res = await workflow.execute_activity(
            "run_sign_image",
            args=[self.statedata],
            start_to_close_timeout=timedelta(minutes=15)
        )
        self.statedata['sign_image'] = sign_res

    async def _step_vulnerability_remediation(self) -> None:
        """
        Handle vulnerability remediation workflow.
        
        This state is dynamically added when critical/high vulnerabilities are found.
        It creates a GitHub issue and decides whether to fail the pipeline based on
        preset configuration.
        
        Stores:
            statedata['vulnerability_remediation']: Remediation results including issue details
        
        State Transitions:
            - To ATTEST/VERIFY/UPDATE_STATUS (depending on what's next in preset)
            - Raises ApplicationError if preset.fail_on_vulnerabilities is True
        
        Raises:
            ApplicationError: If vulnerabilities exceed threshold and 
                            preset.fail_on_vulnerabilities is True
        """
        self._current_step = "Step 2.5: Handling vulnerabilities"
        workflow.logger.info("Step 2.5: Processing vulnerability scan results")
        
        scan_res = self.statedata['scan_sbom']
        critical = int(scan_res.get("critical_count", 0))
        high = int(scan_res.get("high_count", 0))
        preset = self.statedata['preset']
        
        remediation_result: Dict[str, Any] = {
            "critical_count": critical,
            "high_count": high,
            "issue_created": False
        }
        
        # Create GitHub issue to track vulnerabilities
        try:
            issue_result = await workflow.execute_activity(
                "create_vulnerability_issue",
                args=[scan_res, critical, high, self.statedata],
                start_to_close_timeout=timedelta(minutes=2)
            )
            remediation_result["issue_created"] = True
            remediation_result["issue_number"] = issue_result.get("number")
            remediation_result["issue_url"] = issue_result.get("url", "")
            workflow.logger.info(f"📋 Vulnerability issue created: #{issue_result.get('number')}")
        except Exception as e:
            workflow.logger.warning(f"Could not create vulnerability issue: {str(e)}")
            remediation_result["issue_error"] = str(e)
        
        # Store results
        self.statedata[PipelineState.VULNERABILITY_REMEDIATION.value] = remediation_result
        self.completed_states.add(PipelineState.VULNERABILITY_REMEDIATION)
        
        # Decide whether to fail pipeline
        if preset.fail_on_vulnerabilities:
            workflow.logger.error(f"❌ Security gate failed: {critical} Critical, {high} High vulnerabilities")
            raise ApplicationError(
                f"Security gate failed: {critical} Critical, {high} High vulnerabilities",
                non_retryable=True
            )
        else:
            workflow.logger.warning(f"⚠️ Continuing despite {critical} Critical, {high} High vulnerabilities (fail_on_vulnerabilities=False)")
        
        # Transition to next state
        self.state = self._get_next_state()

    async def _step_attest(self) -> None:
        """
        Orchestrate SBOM attestation phase.
        
        Attaches the generated SBOM as an attestation to the container image.
        This creates a cryptographically verifiable link between the image
        and its software bill of materials.
        
        Activity extracts image digest and SBOM run_id from statedata.
        
        Stores:
            statedata['attest']: Attestation results
        
        State Transitions:
            - To VERIFY if preset includes verify_signatures
            - To UPDATE_STATUS otherwise
        
        Raises:
            ApplicationError: If attestation fails
        """
        self._current_step = "Step 3: Attesting SBOM"
        
        attest_res = await workflow.execute_activity(
            "run_attest_sbom",
            args=[self.statedata],
            start_to_close_timeout=timedelta(minutes=15)
        )
        
        self.statedata[PipelineState.ATTEST.value] = attest_res
        self.completed_states.add(PipelineState.ATTEST)
        self.state = self._get_next_state()

    async def _step_verify(self) -> None:
        """
        Orchestrate signature and attestation verification phase.
        
        Final security check that validates:
        - Image signature is valid
        - SBOM attestation is valid and matches image
        - Provenance attestation (if applicable)
        
        This ensures SLSA Level 3 compliance requirements are met.
        Activity extracts image digest and preset from statedata.
        
        Stores:
            statedata['verify']: Verification results
        
        State Transitions:
            - To UPDATE_STATUS on successful verification
        
        Raises:
            ApplicationError: If verification fails
        """
        self._current_step = "Step 4: Verifying signatures"
        
        verify_result = await workflow.execute_activity(
            "run_verify_signatures",
            args=[self.statedata],
            start_to_close_timeout=timedelta(minutes=10)
        )
        
        self.statedata[PipelineState.VERIFY.value] = verify_result
        self.completed_states.add(PipelineState.VERIFY)
        
        # Check for verification failure and transition to failure state
        if verify_result.get("conclusion") != "success" and verify_result.get("status") != "success":
            workflow.logger.error("❌ Verification failed")
            # Add VERIFY_FAILURE to dependency graph
            self.state_dependencies[PipelineState.VERIFY_FAILURE] = [PipelineState.VERIFY]
            self.state = PipelineState.VERIFY_FAILURE
            return
        
        workflow.logger.info("✅ Signature verification successful")
        self.state = self._get_next_state()

    async def _step_verify_failure(self) -> None:
        """
        Handle verification failure by creating a specific GitHub issue.
        
        This state is reached when signature/attestation verification fails.
        It creates a detailed GitHub issue with verification logs and
        diagnostic information, then fails the pipeline.
        
        Stores:
            statedata['verify_failure']: Failure handling results
        
        Raises:
            ApplicationError: Always - verification failures are terminal for SLSA compliance
        """
        self._current_step = "Step 4: Handling verification failure"
        workflow.logger.info("Step 4: Creating verification failure issue")
        
        config = self.statedata['config']
        verify_res = self.statedata.get(PipelineState.VERIFY.value, {})
        error_msg = verify_res.get("error", "Signature verification failed")
        run_id = verify_res.get("run_id", "unknown")
        
        failure_result: Dict[str, Any] = {
            "verify_run_id": run_id,
            "error": error_msg,
            "issue_created": False
        }
        
        # Create specific verification failure issue
        try:
            workflow_url = f"https://github.com/{config['repo_owner']}/{config['repo_name']}/actions/runs/{run_id}"
            
            issue_result = await workflow.execute_activity(
                "create_failure_issue",
                args=[{
                    **self.statedata,
                    "error_message": f"SLSA verification failed for {config['image_name']}:{config['image_tag']}\n\n**Error:** {error_msg}\n\n**Verification Run:** {workflow_url}\n\n**Impact:** This image does not meet SLSA Level 3 compliance requirements.",
                    "config": config
                }],
                start_to_close_timeout=timedelta(minutes=2)
            )
            
            failure_result["issue_created"] = True
            failure_result["issue_number"] = issue_result.get("number")
            workflow.logger.info(f"📋 Verification failure issue created: #{issue_result.get('number')}")
        except Exception as e:
            workflow.logger.warning(f"Could not create verification failure issue: {str(e)}")
            failure_result["issue_error"] = str(e)
        
        # Store results
        self.statedata[PipelineState.VERIFY_FAILURE.value] = failure_result
        self.completed_states.add(PipelineState.VERIFY_FAILURE)
        
        # Always fail on verification errors (SLSA compliance requirement)
        raise ApplicationError(f"Signature verification failed: {error_msg}", non_retryable=True)

    async def _step_update_status(self) -> None:
        """
        Update GitHub commit status if configured.
        
        If the pipeline was triggered with --update-commit-status flag,
        updates the commit status to reflect successful pipeline completion.
        Activity extracts git_sha and preset from statedata.
        
        State Transitions:
            - To DONE (pipeline completion)
        """
        config = self.statedata['config']
        
        if config.get("update_commit_status", False) and config.get("git_sha"):
            self._current_step = "Finalizing: Updating status"
            await workflow.execute_activity(
                "update_commit_status",
                args=[self.statedata],
                start_to_close_timeout=timedelta(minutes=2)
            )
        
        self._current_step = "Completed Successfully"
        self.state = PipelineState.DONE

    async def _create_failure_issue(self) -> None:
        """
        Create failure issue on GitHub.
        
        Called when the pipeline fails to document the failure
        in a GitHub issue for visibility and tracking.
        
        Activity extracts repo info and error message from statedata.
        """
        await workflow.execute_activity(
            "create_failure_issue",
            args=[self.statedata],
            start_to_close_timeout=timedelta(minutes=2)
        )