"""
Preset Definitions for Pipeline Configurations.

This module defines preset configurations that control which phases
of the SLSA pipeline are executed and how failures are handled.

Presets provide convenient, named configurations for different use cases
like development (fast feedback), production (full compliance), or
custom scenarios.
"""

from dataclasses import dataclass
from typing import List


@dataclass
class PresetDefinition:
    """
    Definition of a pipeline preset configuration.
    
    Presets bundle together workflow selections, failure policies,
    and security settings into named configurations that can be
    selected via the CLI.
    
    Attributes:
        name: Internal preset identifier (used in code)
        display_name: Human-readable preset name
        description: Explanation of preset purpose and use cases
        workflows: List of workflow identifiers to execute
        fail_on_lint_errors: Whether to fail pipeline on linting errors
        fail_on_vulnerabilities: Whether to fail pipeline on security findings
        vulnerability_severity: Comma-separated list of severities that trigger failures
    
    Example:
        preset = PresetDefinition(
            name="minimal",
            display_name="Minimal Pipeline",
            description="Fast feedback for development",
            workflows=["megalinter", "build_image"],
            fail_on_lint_errors=False,
            fail_on_vulnerabilities=True,
            vulnerability_severity="CRITICAL"
        )
    """
    name: str
    display_name: str
    description: str
    workflows: List[str]
    fail_on_lint_errors: bool = True
    fail_on_vulnerabilities: bool = True
    vulnerability_severity: str = "HIGH,CRITICAL"


# All available presets
PRESETS = {
    "minimal": PresetDefinition(
        name="minimal",
        display_name="Minimal Pipeline",
        description="Fast feedback for development - basic security checks only",
        workflows=["megalinter", "build_image", "generate_sbom", "scan_sbom"],
        fail_on_lint_errors=False,
        fail_on_vulnerabilities=True,
        vulnerability_severity="CRITICAL"
    ),
    
    "standard": PresetDefinition(
        name="standard",
        display_name="Standard Pipeline",
        description="Production-ready SLSA Level 3 pipeline with full verification",
        workflows=["megalinter", "build_image", "generate_sbom", "scan_sbom", "sign_image", "attest_sbom", "verify_signatures"],
        fail_on_lint_errors=True,
        fail_on_vulnerabilities=True,
        vulnerability_severity="HIGH,CRITICAL"
    ),
    
    "skip_linting": PresetDefinition(
        name="skip_linting",
        display_name="Skip Linting Pipeline",
        description="Production-ready SLSA Level 3 pipeline skipping the linting phase",
        workflows=["build_image", "generate_sbom", "scan_sbom", "sign_image", "attest_sbom", "verify_signatures"],
        fail_on_lint_errors=False,
        fail_on_vulnerabilities=True,
        vulnerability_severity="HIGH,CRITICAL"
    ),
}


def get_preset(name: str) -> PresetDefinition:
    """
    Get a preset definition by name.
    
    Args:
        name: Preset identifier (e.g., "minimal", "standard", "skip_linting")
    
    Returns:
        PresetDefinition: The requested preset configuration
    
    Raises:
        ValueError: If the preset name is not recognized
    
    Example:
        preset = get_preset("standard")
        print(preset.workflows)  # List of workflows to execute
    """
    if name not in PRESETS:
        raise ValueError(f"Unknown preset: {name}")
    return PRESETS[name]


def list_presets() -> dict:
    """
    List all available preset configurations.
    
    Returns:
        dict: Dictionary mapping preset names to PresetDefinition objects
    
    Example:
        presets = list_presets()
        for name, preset in presets.items():
            print(f"{name}: {preset.description}")
    """
    return PRESETS
