"""
Temporal Utilities for Client and Worker Management.

This module provides helper functions for connecting to Temporal,
starting workflows, and running workers. It simplifies the setup
and execution of the SLSA pipeline with Temporal.
"""

import os
from temporalio.client import Client
from temporalio.worker import Worker
from .orchestrator import SLSABuildPipeline
from . import activities


async def connect_temporal() -> Client:
    """
    Connect to Temporal.
    
    Logic:
    1. If TEMPORAL_URL is defined then use Temporal Cloud, use TLS/API Key.
    2. Otherwise, default to plaintext (local dev).
    """

    if os.getenv("TEMPORAL_URL", None) is not None:
        print("Using Cloud\n")
        return await Client.connect(
            os.getenv("TEMPORAL_URL", ""),
            namespace=os.getenv("TEMPORAL_NAMESPACE", ""),
            api_key=os.getenv("TEMPORAL_API_KEY", ""),
            tls=True, 
        )

    return await Client.connect("localhost:7233")


async def run_pipeline_and_wait(config: dict) -> dict:
    """
    Connect to Temporal, start the SLSA pipeline workflow, and wait for completion.
    
    This is a convenience function that combines workflow starting and waiting
    into a single operation. Useful for programmatic execution and testing.
    
    Args:
        config: Pipeline configuration dictionary containing all parameters
                (preset, repo info, image details, etc.)
    
    Returns:
        dict: Pipeline result containing:
            - status: Success or failure status
            - compliance: SLSA compliance level achieved
            - workflow_id: Temporal workflow ID for tracking
            - Additional result fields from workflow execution
    """
    client = await connect_temporal()
    workflow_id = f"slsa-{config['image_name'].replace('/', '-')}-{config['image_tag']}"
    handle = await client.start_workflow(
        SLSABuildPipeline.run, 
        config, 
        id=workflow_id, 
        task_queue="slsa-pipeline-tasks"
    )
    result = await handle.result()
    result['workflow_id'] = workflow_id
    return result


async def start_worker():
    """
    Start the Temporal worker to process SLSA pipeline tasks.
    
    The worker connects to Temporal and begins polling for workflow
    and activity tasks. It must be running for any pipelines to execute.
    The worker uses sandboxed execution for security.
    
    Environment Variables Required:
        GITHUB_TOKEN: GitHub Personal Access Token with repo permissions
        ANTHROPIC_API_KEY: (Optional) For Claude AI auto-fix functionality
        TEMPORAL_NAMESPACE: (Required if using Cloud)
        TEMPORAL_API_KEY: (Required if using Cloud)
    """
    client = await connect_temporal()
    
    # Only register activities that are actually used by the orchestrator
    activities_list = [
        # MCP Activities
        activities.mcp_create_branch,
        activities.mcp_push_files,
        activities.get_files_with_lint_errors,
        activities.create_pull_request_with_fixes,
        
        # Issue Management
        activities.create_vulnerability_issue,
        activities.create_failure_issue,
        
        # AI Integration
        activities.analyze_lint_failures_with_claude,
        
        # Workflow Execution
        activities.run_megalinter,
        activities.run_build_image,
        activities.run_generate_sbom,
        activities.run_scan_sbom,
        activities.run_sign_image,
        activities.run_attest_sbom,
        activities.run_verify_signatures,
        
        # Status Management
        activities.update_commit_status,
    ]
    
    worker = Worker(
        client, 
        task_queue="slsa-pipeline-tasks", 
        workflows=[SLSABuildPipeline], 
        activities=activities_list
    )
    
    print("🚀 SLSA Pipeline Worker started (Sandboxed)")
    try: 
        await worker.run()
    finally: 
        await activities.GitHubMCPManager.shutdown()