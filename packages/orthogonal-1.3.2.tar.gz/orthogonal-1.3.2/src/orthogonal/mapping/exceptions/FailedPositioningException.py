
class FailedPositioningException(Exception):
    pass
