
class UnSupportedOperationException(Exception):
    pass
