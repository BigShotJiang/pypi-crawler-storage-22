

class OrthogonalException(Exception):
    pass
