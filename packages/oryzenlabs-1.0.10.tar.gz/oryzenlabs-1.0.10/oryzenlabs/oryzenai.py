import requests

class OryzenAI:
    def __init__(self):
        self.base_url = "https://oryzenlabs.net/v1"
        self.api_key = None
        self.api_secret = None

    def getapi(self, api_key, api_secret):
        self.api_key = api_key
        self.api_secret = api_secret

    @property
    def send(self):
        return self

    def response(self, model="OryzenV1", send=""):
        if not self.api_key or not self.api_secret:
            return "Hata: API Key veya Secret Key tanımlanmamış. client.getapi() kullanın."

        headers = {
            "X-API-KEY": self.api_key,
            "X-API-SECRET": self.api_secret,
            "Content-Type": "application/json"
        }

        payload = {
            "model": model,
            "send": send
        }

        try:
            r = requests.post(
                f"{self.base_url}/chat/completions",
                json=payload,
                headers=headers,
                timeout=30
            )
            if r.status_code == 200:
                return r.json().get("response")
            elif r.status_code == 401:
                return "Hata: Yetkisiz Erişim (API Key veya Secret hatalı)."
            else:
                return f"Hata: Sunucu hatası ({r.status_code})"
        except Exception as e:
            return f"OryzenAPI_Bağlantı_Hatası: {str(e)}"
