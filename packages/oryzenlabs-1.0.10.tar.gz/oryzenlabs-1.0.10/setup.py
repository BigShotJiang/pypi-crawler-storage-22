from setuptools import setup, find_packages

setup(
    name="oryzenlabs",
    version="1.0.10",
    packages=find_packages(),
    install_requires=["requests"],
    author="Can Yıldırım",
    description="OryzenAI Resmi Python SDK",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    python_requires=">=3.6",
)
