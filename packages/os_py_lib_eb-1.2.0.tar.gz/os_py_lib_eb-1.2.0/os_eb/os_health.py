from __future__ import annotations

import asyncio
import json
import threading
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from ipaddress import ip_address, ip_network
from typing import Any, Awaitable, Callable, Iterable


def parse_cidrs(raw: str | Iterable[str] | None) -> list:
    if raw is None:
        return []
    if isinstance(raw, str):
        parts = [x.strip() for x in raw.split(",") if x.strip()]
    else:
        parts = [str(x).strip() for x in raw if str(x).strip()]
    return [ip_network(x, strict=False) for x in parts]


def is_ip_allowed(ip_raw: str | None, allowed_networks: list) -> bool:
    if not ip_raw:
        return False
    try:
        client_ip = ip_address(ip_raw)
    except ValueError:
        return False
    return any(client_ip in network for network in allowed_networks)


def json_body(payload: dict[str, Any]) -> str:
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


@dataclass
class AsyncHealthServer:
    bind_host: str
    port: int
    allowed_networks: list
    dbhealth_provider: Callable[[], Awaitable[dict[str, Any]]]
    health_path: str = "/alive"
    dbhealth_path: str = "/dlive"

    _server: asyncio.base_events.Server | None = None

    def __post_init__(self) -> None:
        if not self.health_path.startswith("/"):
            raise ValueError("health_path must start with '/'")
        if not self.dbhealth_path.startswith("/"):
            raise ValueError("dbhealth_path must start with '/'")

    async def _http_response(
        self,
        status_code: int,
        body: str,
        writer: asyncio.StreamWriter,
        content_type: str = "text/plain; charset=utf-8",
    ) -> None:
        data = body.encode("utf-8")
        headers = [
            f"HTTP/1.1 {status_code} OK",
            f"Content-Type: {content_type}",
            f"Content-Length: {len(data)}",
            "Connection: close",
            "",
            "",
        ]
        writer.write("\r\n".join(headers).encode("utf-8") + data)
        await writer.drain()
        writer.close()
        await writer.wait_closed()

    async def _handle(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peer = writer.get_extra_info("peername")
        ip_raw = peer[0] if isinstance(peer, tuple) and peer else None

        try:
            line = await asyncio.wait_for(reader.readline(), timeout=2.0)
        except Exception:
            await self._http_response(400, "Bad Request", writer)
            return

        request_line = line.decode("utf-8", "ignore").strip()
        if not request_line:
            await self._http_response(400, "Bad Request", writer)
            return

        parts = request_line.split(" ")
        if len(parts) < 2:
            await self._http_response(400, "Bad Request", writer)
            return

        method, path = parts[0], parts[1]
        if method != "GET":
            await self._http_response(405, "Method Not Allowed", writer)
            return
        if path not in {self.health_path, self.dbhealth_path}:
            await self._http_response(404, "Not Found", writer)
            return
        if not is_ip_allowed(ip_raw, self.allowed_networks):
            await self._http_response(403, "Forbidden", writer)
            return
        if path == self.health_path:
            await self._http_response(200, json_body({"ok": True}), writer, "application/json; charset=utf-8")
            return

        payload = await self.dbhealth_provider()
        await self._http_response(200, json_body(payload), writer, "application/json; charset=utf-8")

    async def start(self) -> None:
        self._server = await asyncio.start_server(self._handle, host=self.bind_host, port=self.port)

    async def stop(self) -> None:
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()


@dataclass
class ThreadedHealthServer:
    bind_host: str
    port: int
    allowed_networks: list
    dbhealth_provider: Callable[[], dict[str, Any]]
    health_path: str = "/alive"
    dbhealth_path: str = "/dlive"

    _server: ThreadingHTTPServer | None = None
    _thread: threading.Thread | None = None

    def __post_init__(self) -> None:
        if not self.health_path.startswith("/"):
            raise ValueError("health_path must start with '/'")
        if not self.dbhealth_path.startswith("/"):
            raise ValueError("dbhealth_path must start with '/'")

    def start(self) -> None:
        parent = self

        class Handler(BaseHTTPRequestHandler):
            def _json(self, status_code: int, payload: dict[str, Any]) -> None:
                body = json_body(payload).encode("utf-8")
                self.send_response(status_code)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, format: str, *args: Any) -> None:  # noqa: A003
                return

            def do_GET(self) -> None:  # noqa: N802
                if self.path not in {parent.health_path, parent.dbhealth_path}:
                    self.send_error(404)
                    return

                peer_ip = self.client_address[0] if self.client_address else None
                if not is_ip_allowed(peer_ip, parent.allowed_networks):
                    self.send_error(403)
                    return

                if self.path == parent.health_path:
                    self._json(200, {"ok": True})
                    return

                try:
                    payload = parent.dbhealth_provider()
                except Exception as exc:
                    payload = {"ok": False, "error": str(exc)}
                self._json(200, payload)

        self._server = ThreadingHTTPServer((self.bind_host, self.port), Handler)
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
            self._server = None
        if self._thread is not None:
            self._thread.join(timeout=1.0)
            self._thread = None
