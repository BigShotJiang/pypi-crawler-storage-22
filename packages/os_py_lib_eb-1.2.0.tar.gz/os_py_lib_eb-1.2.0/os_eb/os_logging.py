"""Shared console logging setup for EB services."""

from __future__ import annotations

import logging
import socket
from typing import Final


_HOSTNAME: Final[str] = socket.gethostname().strip() or "unknown-host"


class HostnameFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if not hasattr(record, "hostname"):
            record.hostname = _HOSTNAME
        return True


def configure_console_logging(level: str | int = "INFO", *, force: bool = True) -> None:
    """Configure root logger for consistent console output across services.

    Format:
      YYYY-MM-DD HH:MM:SS.mmm - LEVEL - HOSTNAME - message
    """

    if isinstance(level, str):
        resolved_level = logging.getLevelName(level.upper())
        if isinstance(resolved_level, str):
            resolved_level = logging.INFO
    else:
        resolved_level = int(level)

    handler = logging.StreamHandler()
    handler.addFilter(HostnameFilter())
    handler.setFormatter(
        logging.Formatter(
            fmt="%(asctime)s.%(msecs)03d - %(levelname)s - %(hostname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )

    root = logging.getLogger()
    if force:
        for existing in list(root.handlers):
            root.removeHandler(existing)
    root.setLevel(resolved_level)
    root.addHandler(handler)
