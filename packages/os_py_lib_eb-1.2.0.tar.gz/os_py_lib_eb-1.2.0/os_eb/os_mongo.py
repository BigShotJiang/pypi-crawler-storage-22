from __future__ import annotations

from typing import Any

from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import MongoClient
from pymongo.errors import AutoReconnect, ConnectionFailure, NetworkTimeout, ServerSelectionTimeoutError


def is_mongo_connection_error(exc: Exception) -> bool:
    return isinstance(exc, (AutoReconnect, ConnectionFailure, NetworkTimeout, ServerSelectionTimeoutError, OSError))


def build_async_mongo_client(mongodb_uri: str, **kwargs: Any) -> AsyncIOMotorClient:
    return AsyncIOMotorClient(mongodb_uri, **kwargs)


async def reconnect_async_mongo(
    current_client: AsyncIOMotorClient,
    mongodb_uri: str,
    **kwargs: Any,
) -> AsyncIOMotorClient:
    try:
        current_client.close()
    except Exception:
        pass
    return build_async_mongo_client(mongodb_uri, **kwargs)


def build_sync_mongo_client(mongodb_uri: str, **kwargs: Any) -> MongoClient:
    return MongoClient(mongodb_uri, **kwargs)


def reconnect_sync_mongo(current_client: MongoClient, mongodb_uri: str, **kwargs: Any) -> MongoClient:
    try:
        current_client.close()
    except Exception:
        pass
    return build_sync_mongo_client(mongodb_uri, **kwargs)
