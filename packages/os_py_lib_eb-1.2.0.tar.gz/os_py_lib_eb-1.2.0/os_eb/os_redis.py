from __future__ import annotations

import inspect
from typing import Any, Awaitable, Callable
from urllib.parse import urlparse

from redis.asyncio import Redis
from redis.exceptions import RedisError


def validate_redis_url(redis_url: str) -> None:
    parsed = urlparse(redis_url)
    host = (parsed.hostname or "").lower()
    scheme = (parsed.scheme or "").lower()
    if host.endswith("upstash.io") and scheme != "rediss":
        raise ValueError("Upstash Redis requires TLS. Use redis URL with rediss://")


def build_async_redis(
    redis_url: str,
    *,
    decode_responses: bool = True,
    socket_keepalive: bool = True,
    health_check_interval: int = 30,
    retry_on_timeout: bool = True,
) -> Redis:
    return Redis.from_url(
        redis_url,
        decode_responses=decode_responses,
        socket_keepalive=socket_keepalive,
        health_check_interval=health_check_interval,
        retry_on_timeout=retry_on_timeout,
    )


async def reconnect_async_redis(
    current_client: Redis,
    redis_url: str,
    *,
    decode_responses: bool = True,
    socket_keepalive: bool = True,
    health_check_interval: int = 30,
    retry_on_timeout: bool = True,
) -> Redis:
    try:
        await current_client.aclose()
    except Exception:
        pass
    return build_async_redis(
        redis_url,
        decode_responses=decode_responses,
        socket_keepalive=socket_keepalive,
        health_check_interval=health_check_interval,
        retry_on_timeout=retry_on_timeout,
    )


async def call_with_reconnect(
    *,
    get_client: Callable[[], Awaitable[Redis]] | Callable[[], Redis],
    set_client: Callable[[Redis], Awaitable[None]] | Callable[[Redis], None],
    redis_url: str,
    op_name: str,
    op_args: tuple[Any, ...] = (),
    op_kwargs: dict[str, Any] | None = None,
    decode_responses: bool = True,
    socket_keepalive: bool = True,
    health_check_interval: int = 30,
    retry_on_timeout: bool = True,
) -> Any:
    if op_kwargs is None:
        op_kwargs = {}

    client = get_client()
    if inspect.isawaitable(client):
        client = await client

    op = getattr(client, op_name)
    try:
        return await op(*op_args, **op_kwargs)
    except RedisError:
        new_client = await reconnect_async_redis(
            client,
            redis_url,
            decode_responses=decode_responses,
            socket_keepalive=socket_keepalive,
            health_check_interval=health_check_interval,
            retry_on_timeout=retry_on_timeout,
        )
        maybe_awaitable = set_client(new_client)
        if inspect.isawaitable(maybe_awaitable):
            await maybe_awaitable

        op = getattr(new_client, op_name)
        return await op(*op_args, **op_kwargs)
