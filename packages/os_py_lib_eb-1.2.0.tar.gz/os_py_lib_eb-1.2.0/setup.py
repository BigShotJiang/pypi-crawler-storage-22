"""
Setup configuration for os-py-lib-eb.
This file provides backward compatibility for older pip versions.
Actual configuration is in pyproject.toml.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
