"""Binary file analysis framework.

Provides comprehensive analysis of binary files including:
- Multi-stage dtype detection with validation
- Pattern mining for repeating sequences
- Message and field structure inference
- Semantic field classification
- Protocol identification
- Visualization and dissector generation
"""

from __future__ import annotations

from oscura.analyzers.binary.core.pipeline import BinaryAnalyzer
from oscura.analyzers.binary.core.results import (
    BinaryAnalysisResult,
    EncodingResult,
    Field,
    FieldType,
    Message,
    Pattern,
    PatternRole,
    StructureResult,
)

__all__ = [
    "BinaryAnalysisResult",
    "BinaryAnalyzer",
    "EncodingResult",
    "Field",
    "FieldType",
    "Message",
    "Pattern",
    "PatternRole",
    "StructureResult",
]
