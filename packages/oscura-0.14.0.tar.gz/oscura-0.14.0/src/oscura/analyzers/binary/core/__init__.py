"""Core binary analysis components."""

from __future__ import annotations

from oscura.analyzers.binary.core.file_access import BinaryFile
from oscura.analyzers.binary.core.pipeline import BinaryAnalyzer
from oscura.analyzers.binary.core.results import (
    BinaryAnalysisResult,
    EncodingResult,
    Field,
    FieldType,
    Message,
    Pattern,
    PatternRole,
    StructureResult,
)

__all__ = [
    "BinaryAnalysisResult",
    "BinaryAnalyzer",
    "BinaryFile",
    "EncodingResult",
    "Field",
    "FieldType",
    "Message",
    "Pattern",
    "PatternRole",
    "StructureResult",
]
