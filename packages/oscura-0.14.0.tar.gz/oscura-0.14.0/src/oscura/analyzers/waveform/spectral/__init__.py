"""Spectral analysis functions for waveform data.

This package provides FFT, PSD, and spectral quality metrics
per IEEE 1241-2010 for ADC characterization.

The package is organized into focused submodules:
    - fft: FFT core functions with caching
    - psd: Power Spectral Density estimation (Welch, periodogram, Bartlett)
    - quality_metrics: IEEE 1241-2010 metrics (THD, SNR, SINAD, ENOB, SFDR)
    - wavelets: Wavelet transforms (Hilbert, CWT, DWT, MFCC)
    - chunked: Memory-bounded processing for large signals
    - peaks: Peak finding and harmonic extraction
    - phase: Phase spectrum and group delay
    - measure: Unified measurement function
    - analyzer: SpectralAnalyzer class (OOP wrapper)

Example:
    >>> from oscura.analyzers.waveform.spectral import fft, thd, snr
    >>> freq, magnitude = fft(trace)
    >>> thd_db = thd(trace)
    >>> snr_db = snr(trace)

References:
    IEEE 1241-2010: Standard for Terminology and Test Methods for
    Analog-to-Digital Converters
"""

# FFT core
# SpectralAnalyzer class
from oscura.analyzers.waveform.spectral.analyzer import SpectralAnalyzer

# Chunked processing for large signals
from oscura.analyzers.waveform.spectral.chunked import (
    fft_chunked,
    psd_chunked,
    spectrogram_chunked,
)
from oscura.analyzers.waveform.spectral.fft import (
    clear_fft_cache,
    configure_fft_cache,
    fft,
    get_fft_cache_stats,
)

# Unified measurement function
from oscura.analyzers.waveform.spectral.measure import measure

# Peak finding and harmonic extraction
from oscura.analyzers.waveform.spectral.peaks import (
    extract_harmonics,
    find_peaks,
)

# Phase spectrum and group delay
from oscura.analyzers.waveform.spectral.phase import (
    group_delay,
    phase_spectrum,
)

# PSD functions
from oscura.analyzers.waveform.spectral.psd import (
    bartlett_psd,
    periodogram,
    psd,
    spectrogram,
)

# IEEE 1241-2010 quality metrics
from oscura.analyzers.waveform.spectral.quality_metrics import (
    enob,
    sfdr,
    sinad,
    snr,
    thd,
)

# Wavelet and transform functions
from oscura.analyzers.waveform.spectral.wavelets import (
    cwt,
    dwt,
    hilbert_transform,
    idwt,
    mfcc,
)

__all__ = [
    "SpectralAnalyzer",
    "bartlett_psd",
    "clear_fft_cache",
    "configure_fft_cache",
    "cwt",
    "dwt",
    "enob",
    "extract_harmonics",
    "fft",
    "fft_chunked",
    "find_peaks",
    "get_fft_cache_stats",
    "group_delay",
    "hilbert_transform",
    "idwt",
    "measure",
    "mfcc",
    "periodogram",
    "phase_spectrum",
    "psd",
    "psd_chunked",
    "sfdr",
    "sinad",
    "snr",
    "spectrogram",
    "spectrogram_chunked",
    "thd",
]
