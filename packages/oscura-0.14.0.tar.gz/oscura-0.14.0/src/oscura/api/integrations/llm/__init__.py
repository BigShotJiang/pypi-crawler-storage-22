"""LLM Integration for Oscura.

Provides hooks for Large Language Model integration to enable natural language
analysis and assistance.

This package was refactored from a single ``llm.py`` module.
All public symbols are re-exported here so existing imports such as::

    from oscura.api.integrations.llm import get_client

continue to work unchanged.

Submodules:
    types              -- Enums, dataclasses, LLMClient Protocol, LLMError
    cost               -- CostTracker, ResponseCache, RateLimiter
    integration        -- LLMIntegration manager class
    openai_provider    -- OpenAI client implementation
    anthropic_provider -- Anthropic client implementation
    local_provider     -- Local/mock client implementation
    factory            -- Client factory functions and FailoverLLMClient

Examples:
    Basic usage with auto-selection:

    >>> from oscura.api.integrations import llm
    >>> client = llm.get_client()  # Auto-selects available provider
    >>> response = client.chat_completion("What is signal rise time?")

    Provider-specific usage:

    >>> client = llm.get_client("openai", model="gpt-4")
    >>> analysis = client.analyze_trace({"sample_rate": 1e9, "mean": 0.5})

    With failover:

    >>> client = llm.get_client_with_failover(
    ...     providers=["openai", "anthropic", "local"]
    ... )
"""

from oscura.api.integrations.llm.cost import (
    CostTracker,
    ResponseCache,
    get_cost_tracker,
    get_response_cache,
)
from oscura.api.integrations.llm.factory import (
    FailoverLLMClient,
    analyze,
    configure,
    explain,
    get_client,
    get_client_auto,
    get_client_with_failover,
    get_llm,
    get_provider,
    is_provider_available,
    list_available_providers,
)
from oscura.api.integrations.llm.integration import LLMIntegration
from oscura.api.integrations.llm.types import (
    AnalysisHook,
    LLMConfig,
    LLMError,
    LLMProvider,
    LLMResponse,
    estimate_tokens,
)

__all__ = [
    # Core classes
    "AnalysisHook",
    "CostTracker",
    "FailoverLLMClient",
    "LLMConfig",
    "LLMError",
    "LLMIntegration",
    "LLMProvider",
    "LLMResponse",
    "ResponseCache",
    # High-level functions
    "analyze",
    "configure",
    # Cost and caching utilities (API-020)
    "estimate_tokens",
    "explain",
    # Client factory functions (API-020)
    "get_client",
    "get_client_auto",
    "get_client_with_failover",
    "get_cost_tracker",
    "get_llm",
    "get_provider",
    "get_response_cache",
    # Provider discovery (API-020)
    "is_provider_available",
    "list_available_providers",
]
