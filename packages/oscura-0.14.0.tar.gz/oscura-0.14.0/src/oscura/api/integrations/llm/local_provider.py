"""Local/mock LLM provider implementation.

Provides ``LocalLLMClient`` as a stub for local operation when
no cloud API keys are configured.
"""

from __future__ import annotations

from typing import Any

from oscura.api.integrations.llm.types import LLMConfig, LLMResponse


class LocalLLMClient:
    """Local LLM client (mock implementation)."""

    def __init__(self, config: LLMConfig) -> None:
        """Initialize local client.

        Args:
            config: LLM configuration
        """
        self.config = config

    def query(self, prompt: str, context: dict[str, Any]) -> LLMResponse:
        """Mock query implementation.

        Args:
            prompt: User prompt
            context: Analysis context

        Returns:
            Mock LLM response
        """
        return LLMResponse(
            answer="Local LLM not configured. This is a mock response.",
            confidence=0.0,
            suggested_commands=[],
            metadata={"mock": True},
        )

    def analyze(self, trace: Any, question: str) -> LLMResponse:
        """Mock analysis implementation.

        Args:
            trace: Trace object
            question: Natural language question

        Returns:
            Mock LLM response
        """
        question_lower = question.lower()

        if "protocol" in question_lower:
            return LLMResponse(
                answer="Unable to determine protocol without LLM. Try manual inspection.",
                confidence=0.0,
                suggested_commands=[
                    "measure frequency",
                    "plot $trace",
                ],
            )

        return LLMResponse(
            answer=f"Local LLM analysis not available. Question was: {question}",
            confidence=0.0,
            suggested_commands=["measure all"],
        )

    def explain(self, measurement: Any) -> str:
        """Mock explanation implementation.

        Args:
            measurement: Measurement result

        Returns:
            Mock explanation text
        """
        return f"Measurement result: {measurement}. Local LLM explanation not available."
