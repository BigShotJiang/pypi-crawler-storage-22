"""Legacy export functions for backward compatibility.

This module provides backward-compatible export functions that wrap
the modern pipeline handler implementations.
"""

from __future__ import annotations

from oscura.export.legacy.wav import export_wav

__all__ = ["export_wav"]
