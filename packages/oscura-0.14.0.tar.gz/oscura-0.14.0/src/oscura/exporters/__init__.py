"""Export utilities for Oscura analysis results.

This module provides exporters for various external tools and formats:

- Wireshark Lua dissector generation
- PCAP/PCAPNG export (future)
- Third-party tool integration (future)

Example:
    >>> from oscura.exporters.wireshark import generate_dissector
    >>> from oscura.inference.message_format import infer_format
    >>> messages = [b'\\xAA\\x01DATA', b'\\xAA\\x02DATA']
    >>> schema = infer_format(messages)
    >>> lua_code = generate_dissector(schema, protocol_name="custom")
"""

from __future__ import annotations

__all__ = ["wireshark"]
