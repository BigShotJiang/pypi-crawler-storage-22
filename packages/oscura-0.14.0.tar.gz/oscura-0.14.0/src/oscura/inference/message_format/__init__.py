"""Message format inference package.

Provides statistical analysis for inferring message field structure from
collections of similar messages used in protocol reverse engineering.

This package was refactored from a single ``message_format.py`` module.
All public symbols are re-exported here so existing imports such as::

    from oscura.inference.message_format import MessageFormatInferrer

continue to work unchanged.

Submodules:
    types              -- Core dataclasses (InferredField, MessageSchema, ...)
    entropy            -- Shannon entropy utilities
    boundaries         -- Field boundary detection algorithms
    field_classification -- Field type classification & voting
    advanced_detectors -- Timestamp, float, length, enum, reserved detectors
    inferrer           -- MessageFormatInferrer class & convenience functions
"""

from oscura.inference.message_format.inferrer import (
    MessageFormatInferrer,
    infer_format,
)
from oscura.inference.message_format.inferrer import (
    detect_field_types_standalone as detect_field_types,
)
from oscura.inference.message_format.inferrer import (
    find_dependencies_standalone as find_dependencies,
)
from oscura.inference.message_format.types import (
    FieldDetectionResult,
    InferredField,
    MessageSchema,
)

__all__ = [
    "FieldDetectionResult",
    "InferredField",
    "MessageFormatInferrer",
    "MessageSchema",
    "detect_field_types",
    "find_dependencies",
    "infer_format",
]
