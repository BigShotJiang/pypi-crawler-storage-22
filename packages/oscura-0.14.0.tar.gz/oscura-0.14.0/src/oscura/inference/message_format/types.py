"""Data types for message format inference.

Provides the core dataclasses used throughout the message format inference
package: ``FieldDetectionResult``, ``InferredField``, and ``MessageSchema``.

Requirements addressed: PSI-001
"""

from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field as dataclass_field
from typing import Any, Literal


@dataclass
class FieldDetectionResult:
    """Result from a field type detector.

    Attributes:
        confidence: Detection confidence score (0.0-1.0)
        field_offset: Field offset in bytes
        field_length: Field length in bytes
        evidence: Supporting data for detection
    """

    confidence: float
    field_offset: int
    field_length: int
    evidence: dict[str, Any]


@dataclass
class InferredField:
    """An inferred message field.

    : Field classification and type inference.

    Attributes:
        name: Auto-generated field name
        offset: Byte offset from message start
        size: Field size in bytes
        field_type: Inferred field type classification
        entropy: Shannon entropy of field values
        variance: Statistical variance of field values
        confidence: Confidence score (0-1) for type inference
        values_seen: Sample values for validation
        evidence: Evidence from each expert (for ensemble methods)
    """

    name: str
    offset: int
    size: int
    field_type: Literal[
        "constant",
        "counter",
        "timestamp",
        "length",
        "checksum",
        "data",
        "float",
        "enum",
        "reserved",
        "unknown",
    ]
    entropy: float
    variance: float
    confidence: float
    values_seen: list[Any] = dataclass_field(default_factory=list)  # Sample values
    evidence: dict[str, bool] = dataclass_field(default_factory=dict)  # Expert evidence


@dataclass
class MessageSchema:
    """Inferred message format schema.

    : Complete message format specification.

    Attributes:
        total_size: Total message size in bytes
        fields: List of inferred fields
        field_boundaries: Byte offsets of field starts
        header_size: Detected header size
        payload_offset: Start of payload region
        checksum_field: Detected checksum field if any
        length_field: Detected length field if any
    """

    total_size: int
    fields: list[InferredField]
    field_boundaries: list[int]  # Byte offsets of field starts
    header_size: int  # Detected header size
    payload_offset: int
    checksum_field: InferredField | None
    length_field: InferredField | None
