"""YAML-based pipeline system for Oscura.

This package provides a complete pipeline execution framework with:
- YAML configuration for declarative workflows
- 60+ built-in handlers for common operations
- Transaction semantics with automatic rollback
- Conditional logic and parallel execution
- Template variables and composition

Quick Start:
    >>> from oscura.pipeline import Pipeline, register_all_handlers
    >>>
    >>> # Load and execute a pipeline
    >>> pipeline = Pipeline.load("analysis.yaml")
    >>> register_all_handlers(pipeline)
    >>> results = pipeline.execute()
    >>>
    >>> # Access results
    >>> trace = results.outputs["load_trace"]["trace"]
    >>> frames = results.outputs["decode_uart"]["frames"]

Example YAML:
    ```yaml
    pipeline:
      name: uart_analysis
      version: 1.0.0
      steps:
        - name: load_trace
          type: input.file
          params:
            path: ${input_file}
          outputs:
            trace: waveform

        - name: decode_uart
          type: decoder.uart
          inputs:
            trace: load_trace.waveform
          params:
            baud_rate: 115200
          outputs:
            frames: decoded_frames
    ```
"""

from oscura.core.config.pipeline import (
    Pipeline,
    PipelineDefinition,
    PipelineExecutionError,
    PipelineResult,
    PipelineStep,
    PipelineValidationError,
)
from oscura.pipeline.handlers import (
    get_all_handlers,
    get_handler,
    list_handler_types,
    register_all_handlers,
    register_handler,
)

__all__ = [
    # Core classes
    "Pipeline",
    "PipelineDefinition",
    "PipelineExecutionError",
    "PipelineResult",
    "PipelineStep",
    "PipelineValidationError",
    "get_all_handlers",
    "get_handler",
    "list_handler_types",
    "register_all_handlers",
    # Registry functions
    "register_handler",
]
