# osho

Python package and CLI for osho quotes.

> [!IMPORTANT]
> Its a fun project. Please share interesting ideas in Discussion Tab.
