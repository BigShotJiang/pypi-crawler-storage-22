import click

from osho.__about__ import __version__, LOGO


@click.command()
@click.version_option(__version__, "-V", "--version")
@click.help_option("-h", "--help")
def cli():
    """Osho CLI Tool"""
    click.echo(LOGO)


if __name__ == "__main__":
    cli()
