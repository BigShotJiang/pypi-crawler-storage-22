#!/usr/bin/env python
"""Test finite element solution for basic nonlinear equations.

Test consistency using MMS.
"""
import numpy as np
import pygimli as pg
from oskar import (div, grad, func,
                   derive, solve, normL2,
                   ScalarSpace, FEASolution)

from oskar.tests.utils import (parseTestArgs)
from oskar.tests import TestCollection, testCount

_show_ = False


class TestFEANonlinear(TestCollection):
    """MMS for nonlinear problem."""

    def test_PicardStationary(self):
        """MMS for nonlinear stationary problem using Picard iteration."""
        u = func(u='(1 + x*5)²')
        alpha = func('(1 + u)²')

        x = np.linspace(0, 1, 11)
        mesh = pg.createGrid(x)
        bc = {'Dirichlet': {'*': u}}

        ### order > 2 to converge against exact solution
        ## else saturation of error due to approximation error for alpha(u)
        s = ScalarSpace(mesh, p=2, order=3)
        uh = FEASolution(s, values=1)

        L = lambda u, a: -div(a*grad(u))
        pde = L(s, alpha(u=uh)) == L(u, alpha(u=u))

        bc = {'Dirichlet': {'*': u}}
        ws = {}
        def checkL2(uh, **kwargs):
            kwargs['ws'].setdefault('l2', []).append(normL2(uh - u))

        uh = solve(pde, bc=bc, solver='scipy',
                   nonlinear='picard', maxIter=1000, atol=1e-5,
                   postIter=checkL2,
                   ws=ws)

        if _show_ is True:
            fig, axs = pg.plt.subplots(1, 2)
            uh.show(ref=u, animate=False, ax=axs[0], xl='x', yl='u',)
            axs[1].semilogy(ws['res'], marker='o', lw=0.4, ms=1,
                            label='Picard residual')
            axs[1].set(xlabel='Iteration', ylabel='Residual',
                       title='Convergence history')
            axs[1].grid(True)
            axs[1].legend()

            aTwin = axs[1].twinx()
            aTwin.semilogy(ws['l2'], color='C1', marker='o', lw=0.4, ms=1,
                           label='$||u_h-u||_{L^2}$')
            aTwin.set_ylabel('$||u_h-u||_{L^2}$', color='C1')
            h1, l1 = axs[1].get_legend_handles_labels()
            h2, l2 = aTwin.get_legend_handles_labels()
            axs[1].legend(h1 + h2, l1 + l2, loc='best')
            fig.tight_layout()

        self.assertEqual(normL2(uh - u), 0.0, tol=3.1e-6)


    def test_PicardNonStationary(self):
        """MMS for nonlinear non-stationary problem."""
        times = np.linspace(0, 1, 11)
        x = np.linspace(0, 1, 11)
        mesh = pg.createGrid(x)

        ## quadratic to get exact solution for p2
        u = func('(1 + 5*x)²')
        #u *= '(1.0 + 0.5*sin(2*pi*t))'

        ## linear to get exact solution for implicit time stepping
        u *= '(1.0 + 4*t)'
        alpha = func("(1 + u)²") ## needs higher integration order

        L = lambda u, a: derive(u, 't') - div(a*grad(u))
        f = L(u, alpha(u=u))

        atol = 1e-6
        maxIter = 100
        omega = 0.55 ## relaxation factor .. larger results in higher oscillations

        bc = {'Dirichlet':{'1':u},
              'Neumann':{'2':alpha(u=u)*grad(u)}}

        ### order > 3 to converge against exact solution with linear time term
        ## else saturation of error due to approximation error for alpha(u)
        s = ScalarSpace(mesh, p=2, order=4)
        uh = FEASolution(s, values=u(t=0))  # initial guess

        def checkL2(uh, **kwargs):
            kwargs['ws'].setdefault('l2', []).append(normL2(uh - u(t=kwargs['time'])))

        ws = {}
        uh = solve(L(s, alpha(u=uh)) == f,
                   ic=uh, times=times, bc=bc, solver='scipy',
                   nonlinear='picard', atol=atol, maxIter=maxIter, omega=omega,
                   progress=True, ws=ws, postIter=checkL2)

        if _show_ is True:
            fig, axs = pg.plt.subplots(1, 2)
            uh.show(ref=u, ax=axs[0], xl='x', yl='u',)
            axs[1].semilogy(ws['ws'][-1]['res'], marker='o', lw=0.4, ms=1,
                            label='Picard residual (last time step)')
            axs[1].set(xlabel='Iteration', ylabel='Residual',
                       title='Convergence history (last time step)')
            axs[1].grid(True)
            aTwin = axs[1].twinx()
            aTwin.semilogy(ws['ws'][-1]['l2'], color='C1', marker='o',
                           lw=0.4, ms=1, label='$||u_h-u||_{L^2}$')
            aTwin.set_ylabel('$||u_h-u||_{L^2}$', color='C1')
            h1, l1 = axs[1].get_legend_handles_labels()
            h2, l2 = aTwin.get_legend_handles_labels()
            axs[1].legend(h1 + h2, l1 + l2, loc='best')

            fig.tight_layout()

        self.assertEqual(normL2(uh - u), 0.0, tol=3.2e-8)


if __name__ == '__main__':
    _show_ = parseTestArgs()

    import unittest
    pg.tic()
    unittest.main(exit=False)

    print()
    pg.info(f'Absolute tests: {testCount()}, took {pg.dur()} s')
