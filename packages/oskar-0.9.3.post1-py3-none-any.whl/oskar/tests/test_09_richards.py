#!/usr/bin/env python
"""Test finite element solution for Richards equation.

Test consistency using MMS.
"""
import numpy as np
import warnings
from oskar.utils import hydraulicConductivityModel
import pygimli as pg
from oskar import (div, grad, OP, func, Z, derive,
                   solve, normL2,
                   ScalarSpace, FEASolution,
                   solveRichards,
                   RichardsSolver)

from oskar.tests.utils import (parseTestArgs)
from oskar.tests import TestCollection, assertEqual, testCount

_show_ = False

class TestRichards(TestCollection):
    """MMS for Richards equation."""

    def test_Models(self):
        """Test hydraulic conductivity models."""
        x = np.geomspace(1e-2, 1e1, 100)
        xall = np.array([*-x[::-1], 0, *x])

        kwB = {'K_s':9.44e-5, 'theta_r':0.075, 'theta_s':0.287, 'h' :'x'}
        kwM = {'alpha':13.8, 'm':'1 - 1/n', 'n':1.6, 'lam':0.5, 'l':'1/2'}
        kwHav = {'alpha':1.611e2, 'beta':3.96,'gamma':4.74, 'A':1.175e2}

        # textbook form for van Genuchten-Mualem looks different and can't
        # be compared directly. WHY? Ideas?
        theta, K = hydraulicConductivityModel(model='vanGenuchten-Mualem')
        kw = kwB | kwM

        K2 = func('K_s*(1 - (alpha*h)^(m*n)*(1 + (alpha*h)^n)^(-m))^2'
                '/(1 + (alpha*h)^n)^(m/2)')(m='1 - 1/n')

        if _show_ is True:
            ax = K(**kw).show(mesh=pg.createGrid(np.geomspace(1e-4, 1e1, 100)))[0]
            ax.set_yscale('log')
            ax.set_xscale('log')
            ax = K2(**kw).show(mesh=pg.createGrid(np.geomspace(1e-4, 1e1, 100)), ax=ax)[0]
            pg._g()
            print((K-K2).simplify)
            (K-K2).simplify(**kw).show()
        self.assertEqual((K-K2)(**kw)(x), x*0, tol=3e-18)

        #### test all model boundaries

        if _show_ is True:
            fig, axs = pg.plt.subplots(2,3, figsize=(12,8))

        with warnings.catch_warnings():
            ## note runtime warnings are from np.select that does not work
            # with np.where, but obviously calc for all and then replace
            # afterwards still to correct values
            warnings.filterwarnings('ignore', 'invalid value encountered')
            warnings.filterwarnings('ignore', 'divide by zero encountered')
            for i, model in enumerate(['Brooks-Corey',
                                    'vanGenuchten-Mualem',
                                    'Haverkamp'
                                    ]):

                if i < 2:
                    kw = kwB | kwM
                else:
                    kw = kwB | kwHav

                # default defined for h >= 0
                theta, K = hydraulicConductivityModel(model=model)
                ## note runtime warnings are from np.select that does not work
                # with np.where, but obviously calc for all and then replace
                # afterwards still to correct values

                ## note Brooks-Corey in normal form is not defined for h < 1/alpha
                if _show_ is True:
                    theta(**kw).show(mesh=pg.createGrid(x),
                                    label=f'$\\theta(h)$ ({model})',
                                    ax=axs[0, 0], xl='h')
                    axs[0, 0].set_xscale('log')

                    K(**kw).show(mesh=pg.createGrid(x),
                                label=f'$K(h)$ ({model})',
                                ax=axs[1, 0], xl='h')
                    axs[1, 0].set_yscale('log')
                    axs[1, 0].set_xscale('log')
                    axs[0, 0].set_title('default $h$ needs to be positive')
                    axs[1, 0].set_title('default $h$ needs to be positive')

                if i == 0:
                    self.assertEqual(theta(**kw)(1/kwM['alpha']), kw['theta_s'], tol=1e-15)
                    self.assertEqual(K(**kw)(1/kwM['alpha']), kw['K_s'], tol=1e-19)
                else:
                    self.assertEqual(theta(**kw)(0), kw['theta_s'])
                    self.assertEqual(K(**kw)(0), kw['K_s'], tol=1e-19)

                ## defined for h >= 0 but fallback for h < 0
                theta, K = hydraulicConductivityModel(model=model, hIsNegative=False)
                self.assertEqual(theta(**kw)(0), kw['theta_s'])
                self.assertEqual(K(**kw)(0), kw['K_s'])
                self.assertEqual(theta(**kw)(-1), kw['theta_s'])
                self.assertEqual(K(**kw)(-1), kw['K_s'])

                if _show_ is True:
                    theta(**kw).show(mesh=pg.createGrid(xall),
                                    label=f'$\\theta(h)$ ({model})',
                                    ax=axs[0, 1], xl='h')

                    K(**kw).show(mesh=pg.createGrid(xall),
                                label=f'$K(h)$ ({model})',
                                ax=axs[1, 1], xl='h')
                    axs[1, 1].set_yscale('log')
                    axs[1, 1].set_title('valid $h$ are positive')
                    axs[0, 1].set_title('valid $h$ are positive')

                ## defined for h <= 0 but fallback for h > 0
                theta, K = hydraulicConductivityModel(model=model, hIsNegative=True)
                self.assertEqual(theta(**kw)(0), kw['theta_s'])
                self.assertEqual(K(**kw)(0), kw['K_s'])
                self.assertEqual(theta(**kw)(1), kw['theta_s'])
                self.assertEqual(K(**kw)(1), kw['K_s'])

                if _show_ is True:
                    theta(**kw).show(mesh=pg.createGrid(xall),
                                    label=f'$\\theta(h)$ ({model})',
                                    ax=axs[0, 2], xl='h')
                    K(**kw).show(mesh=pg.createGrid(xall),
                                label=f'$K(h)$ ({model})',
                                ax=axs[1, 2], xl='h')
                    axs[1, 2].set_yscale('log')
                    axs[1, 2].set_title('valid $h$ are negative')
                    axs[0, 2].set_title('valid $h$ are negative')


    def test_Stationary(self):
        """MMS for stationary Richards equation."""
        # manufactured solution like :cite:`Cockett2017`
        h = func('-20 * atan(20*(x-0.5)) -50')  # neg. pressure head h in cm
        richardsEQ = lambda h, K: -div(K*(grad(h + Z)))

        kw = {'K_s':1e-5, 'alpha':13.8, 'n':1.6, 'lam':0.5,
              'gamma':4.74, 'A':1.175e6}

        for i, model in enumerate(['Brooks-Corey',
                                   'vanGenuchten-Mualem',
                                   'Haverkamp'
                                    ]):
            theta, K = hydraulicConductivityModel(model=model,
                                                  hIsNegative=True,
                                                  **kw)

            f = pg.cache(richardsEQ)(h, K(h=h))
            dz = 0.04
            z = np.arange(0, 1 + dz, dz) # in m
            mesh = pg.createGrid(z)

            s = ScalarSpace(mesh, p=2, order=3)
            hh = FEASolution(s, values=h(0))

            bc = {'Dirichlet':{'1':h},
                  'Neumann':{'2':K(h=h)*grad(h)}}

            EQ = richardsEQ(s, K(h=hh)) == f

            ws = {}
            maxIter = 1000                        # maximum number of iterations
            atol = 1e-4                           # absolute tolerance
            omega = 0.8                           # under-relaxation factor

            def checkL2(uh, **kwargs):
                kwargs['ws'].setdefault('l2', []).append(normL2(hh - h))

            hh = solve(EQ, bc=bc, solver='scipy',
                    nonlinear='Picard', atol=atol, maxIter=maxIter, omega=omega,
                    ws=ws, postIter=checkL2)

            ht = solveRichards(mesh, K=K, f=f, h0=h(0), bc=bc,
                               omega=omega, atol=atol, maxIter=maxIter)

            assertEqual(hh, ht, atol=1e-18)

            if _show_ is True:
                fig, axs = pg.plt.subplots(1, 2)
                hh.show(ref=h, animate=False, ax=axs[0], xl='x', yl='h',)
                axs[1].semilogy(ws['res'], marker='o', lw=0.4, ms=1,
                                label='Picard residual')
                axs[1].set(xlabel='Iteration', ylabel='Residual',
                        title='Convergence history (' + K.extraName + ')')
                axs[1].grid(True)
                axs[1].legend()

                aTwin = axs[1].twinx()
                aTwin.semilogy(ws['l2'], color='C1', marker='o', lw=0.4, ms=1,
                            label='$||u_h-u||_{L^2}$')
                aTwin.set_ylabel('$||u_h-u||_{L^2}$', color='C1')
                h1, l1 = axs[1].get_legend_handles_labels()
                h2, l2 = aTwin.get_legend_handles_labels()
                axs[1].legend(h1 + h2, l1 + l2, loc='best')
                fig.tight_layout()

            self.assertEqual(normL2(hh - h), 0.0, tol=0.14)


    def test_Transient(self):
        """MMS for transient Richards equation."""
        h = func('-20 * atan(20*((x - 0.25) -t)) -40')

        kwB = {'K_s':1e-5, 'theta_r':0.02, 'theta_s':0.4}
        kwM = {'alpha':13.8, 'n':1.6, 'lam':0.5}
        kwHav = {'alpha':1.611e6, 'beta':3.96,'gamma':4.74, 'A':1.175e6}

        dz = 0.1
        dt = 0.0025
        z = np.arange(0, 1 + dz, dz) # in cm
        times = np.arange(0, 0.5, dt)[0:10] # in s

        for i, model in enumerate(['Brooks-Corey',
                                   'vanGenuchten-Mualem',
                                   'Haverkamp'
                                    ]):

            if i < 2:
                kw = kwB | kwM
            else:
                kw = kwB | kwHav

            theta, K = hydraulicConductivityModel(model=model, hIsNegative=True,
                                                  **kw)

            f = pg.cache(lambda h, theta, K:
                   derive(theta, 'h')(h=h)*derive(h, 't')(h=h) \
                    - div(K(h=h)*(grad(h + Z))))(h, theta, K)

            hh = solveRichards(pg.createGrid(z),
                               K=K, theta=theta, times=times,
                               f=f, h0=h(t=0),
                               bc={'Dirichlet':{'*':h}},
                            #    bc={'Dirichlet':{'1':h},
                            #        'Neumann':{'2':K(h=h)*grad(h)}},
                               omega=0.8, atol=1e-4, var='head')

            if _show_ is True:
                print(normL2(hh - h))
                hh.show(ref=h,
                        xl='x', yl='h',
                        title=f'Head-based transient Richards solution '
                              f'({K.extraName})')

            self.assertEqual(normL2(hh - h), 0.0, tol=0.333)

            hh = solveRichards(pg.createGrid(z),
                               K=K, theta=theta, times=times,
                               f=f, h0=h(t=0),
                               bc={'Dirichlet':{'1':h},
                                   'Neumann':{'2':K(h=h)*grad(h)}},
                               omega=0.8, atol=1e-4, var='mixed')

            if _show_ is True:
                print(normL2(hh - h))
                hh.show(ref=h,
                        xl='x', yl='h',
                        title=f'Mixed transient Richards solution '
                              f'({K.extraName})')

            self.assertEqual(normL2(hh - h), 0.0, tol=0.333)


if __name__ == '__main__':
    _show_ = parseTestArgs()

    import unittest
    pg.tic()
    unittest.main(exit=False)

    print()
    pg.info(f'Absolute tests: {testCount()}, took {pg.dur()} s')
