# Data writers

::: osmium.SimpleWriter
::: osmium.WriteHandler
::: osmium.BackReferenceWriter
::: osmium.ForwardReferenceWriter

