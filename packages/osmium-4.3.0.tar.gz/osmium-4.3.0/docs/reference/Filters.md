# Filters

::: osmium.filter.EmptyTagFilter
::: osmium.filter.EntityFilter
::: osmium.filter.GeoInterfaceFilter
::: osmium.filter.IdFilter
::: osmium.filter.KeyFilter
::: osmium.filter.TagFilter

