# IO classes

::: osmium.io.File
::: osmium.io.FileBuffer
::: osmium.io.Header
::: osmium.io.Reader
::: osmium.io.Writer
::: osmium.io.ThreadPool
