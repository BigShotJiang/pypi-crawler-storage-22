# Indexes

::: osmium.IdTracker
::: osmium.index.IdSet
::: osmium.index.LocationTable

## Index creation functions

::: osmium.index.map_types
    options:
        heading_level: 3

::: osmium.index.create_map
    options:
        heading_level: 3

