## Engineering Heuristics (99 Bottles + Grug)

### Core principle
- Prefer understandable code over speculative flexibility.
- Complexity is a cost; introduce it only with a concrete, current need.

### Default decision rules
- Start with the simplest working design ("shameless green").
- Do not add abstractions "for later" without a real change request.
- If unsure between clever and boring, choose boring.
- Prefer 80/20 solutions that deliver most value with less moving parts.
- Optimize for local clarity and operability, not architectural novelty.

### Abstraction policy
- Add an abstraction only when duplication or variation is proven in real code.
- Require at least one concrete caller/use case before introducing generic APIs.
- Keep interfaces narrow; hide complexity behind small boundaries.
- Delay factoring until stable cut points emerge.

### Refactoring policy
- Keep refactors small, reversible, and behavior-preserving.
- Preserve system behavior at every step; avoid "big bang" rewrites.
- Apply Chesterton's Fence: understand why existing code exists before replacing it.
- Prefer incremental improvements over broad redesign.

### Testing policy
- Prefer integration tests at stable boundaries.
- Keep a small, high-signal end-to-end suite.
- Use unit tests where they add speed and focus, not by dogma.
- For bugs: write a failing regression test first, then fix.

### Comments and docstrings
- Comments explain why a choice exists, not what the code syntax does.
- Document tradeoffs, invariants, failure modes, and operational constraints.
- If code is self-evident, remove noise comments.

### Dependency and tooling policy
- No new libraries by default.
- Add dependencies only for clear, repeated pain with measurable gain.
- Prefer standard library and existing project components first.
- Invest in debugging/logging quality before adding framework complexity.

### PR acceptance checklist
- Is this simpler than the previous version?
- Does this reduce or cap complexity?
- Are tests aligned with stable behavior?
- Are operational failure modes visible in logs/metrics?
- Could this be done with fewer abstractions?

### Commit message convention (semantic + readable)
- Use: `<type>(<scope>): <subject>`
- `scope` is optional.
- Apply the 7 cbeams rules:
  - Separate subject from body with a blank line.
  - Limit the subject line to about 50 characters.
  - Capitalize the subject line.
  - Do not end the subject line with a period.
  - Use the imperative mood in the subject line.
  - Wrap the body at about 72 characters.
  - Use the body to explain what and why vs. how.
- Commit body is the default, not optional in normal work.
- Omit body only for truly trivial commits (e.g., typo-only, comment typo, formatting-only with zero behavior impact).
- Reference issues/PRs at the end when relevant (`Refs: #123`, `Fixes: #123`).

Examples:
- `fix(outbox): Prefer task_id over legacy body id`
- `refactor(workers): Simplify notify drain loop`
- `test(updates): Add provider idempotency regression`

Allowed `type` values:
- `feat`: user-visible feature
- `fix`: bug fix
- `docs`: documentation only
- `refactor`: code restructuring, no behavior change
- `test`: test-only changes
- `chore`: maintenance/build/tooling
- `style`: formatting/no semantic change

Commit template:

`<type>(<scope>): <subject>`

`<blank line>`

`Why this change is needed now.`
`What changed at a high level and key tradeoffs.`
`Operational/testing notes if important.`

`Refs: #issue`
