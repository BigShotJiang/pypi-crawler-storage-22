# Changelog

## 0.2.0 - 2026-02-12

- Removed ambiguous `ProviderResult.state`; providers now return result payload via `data`.
- Kept `external_id` as the canonical top-level identifier field on `ProviderResult`.
- Hardened idempotency hashing input encoding to avoid delimiter-collision ambiguity.
- Removed unused `osp_provider_contracts.testing.fixtures` helpers.
- Reduced repository `.gitignore` to a focused package-level set.

## 0.1.0 - 2026-02-12

- Initial alpha release.
- Added provider protocol, shared types, and canonical errors.
- Added capabilities validation and idempotency key helper.
- Added lightweight conformance assertions for provider tests.
