# Release Guide

## Automated on tag

On tag `vX.Y.Z`, CI:
- runs lint, type-check, and tests
- builds `sdist` and wheel
- runs `twine check dist/*`
- uploads artifacts to the GitHub Release

## Manual/gated publish

Publishing to PyPI (or internal index) is intentionally manual/gated.

```bash
env -u VIRTUAL_ENV uv sync --extra dev
hatch shell
hatch run check
hatch run build
hatch run verify
hatch run publish
```

If using a custom repository:

```bash
hatch publish -r <repo-name>
```

Credentials should be stored in `~/.pypirc` (or keyring), not committed.

TestPyPI dry run publish:

```bash
hatch run publish-test
```
