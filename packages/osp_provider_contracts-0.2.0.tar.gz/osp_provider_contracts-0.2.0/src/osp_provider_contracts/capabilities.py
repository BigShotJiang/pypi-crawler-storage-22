from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any


def validate_capabilities(capabilities: Mapping[str, Any]) -> None:
    required = ("provider", "version", "resources")
    missing = [name for name in required if name not in capabilities]
    if missing:
        raise ValueError(f"capabilities missing required keys: {missing}")

    if not isinstance(capabilities["provider"], str) or not capabilities["provider"]:
        raise ValueError("capabilities.provider must be a non-empty string")
    if not isinstance(capabilities["version"], str) or not capabilities["version"]:
        raise ValueError("capabilities.version must be a non-empty string")

    resources = capabilities["resources"]
    if not isinstance(resources, Sequence):
        raise ValueError("capabilities.resources must be a sequence")

    for index, resource in enumerate(resources):
        if not isinstance(resource, Mapping):
            raise ValueError(f"resources[{index}] must be a mapping")
        if "kind" not in resource or "actions" not in resource:
            raise ValueError(f"resources[{index}] must include 'kind' and 'actions'")
        if not isinstance(resource["kind"], str) or not resource["kind"]:
            raise ValueError(f"resources[{index}].kind must be a non-empty string")
        if not isinstance(resource["actions"], Sequence) or any(
            not isinstance(action, str) for action in resource["actions"]
        ):
            raise ValueError(f"resources[{index}].actions must be a sequence of strings")
