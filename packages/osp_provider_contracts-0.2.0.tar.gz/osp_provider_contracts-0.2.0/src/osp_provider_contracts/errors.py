from __future__ import annotations

from collections.abc import Mapping
from typing import Any


class ProviderError(Exception):
    def __init__(
        self,
        message: str,
        *,
        code: str = "provider_error",
        retryable: bool = False,
        detail: str | None = None,
        extra: Mapping[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code = code
        self.retryable = retryable
        self.detail = detail
        self.extra = dict(extra or {})

    def as_dict(self) -> dict[str, Any]:
        return {
            "message": self.message,
            "code": self.code,
            "retryable": self.retryable,
            "detail": self.detail,
            "extra": self.extra,
        }


class AuthError(ProviderError):
    def __init__(self, message: str, **kwargs: Any) -> None:
        super().__init__(message, code="auth_error", retryable=False, **kwargs)


class NotFoundError(ProviderError):
    def __init__(self, message: str, **kwargs: Any) -> None:
        super().__init__(message, code="not_found", retryable=False, **kwargs)


class ConflictError(ProviderError):
    def __init__(self, message: str, **kwargs: Any) -> None:
        super().__init__(message, code="conflict", retryable=False, **kwargs)


class ValidationError(ProviderError):
    def __init__(self, message: str, **kwargs: Any) -> None:
        super().__init__(message, code="validation_error", retryable=False, **kwargs)


class RateLimitError(ProviderError):
    def __init__(self, message: str, **kwargs: Any) -> None:
        super().__init__(message, code="rate_limited", retryable=True, **kwargs)


class DependencyError(ProviderError):
    def __init__(self, message: str, **kwargs: Any) -> None:
        super().__init__(message, code="dependency_error", retryable=True, **kwargs)


class TransientError(ProviderError):
    def __init__(self, message: str, **kwargs: Any) -> None:
        super().__init__(message, code="transient_error", retryable=True, **kwargs)
