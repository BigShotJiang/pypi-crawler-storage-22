from __future__ import annotations

import hashlib
import json

from .types import RequestContext


def build_idempotency_key(
    *,
    context: RequestContext,
    action: str,
    resource_key: str,
) -> str:
    # Use a structured encoding to avoid delimiter-collision ambiguities.
    base = json.dumps(
        [context.task_id, context.request_id, action, resource_key],
        separators=(",", ":"),
        ensure_ascii=True,
    )
    return hashlib.sha256(base.encode("utf-8")).hexdigest()
