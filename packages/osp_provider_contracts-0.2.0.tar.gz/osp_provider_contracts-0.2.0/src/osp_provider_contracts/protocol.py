from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Protocol, runtime_checkable

from .types import ProviderRequest, ProviderResult, RequestContext


@runtime_checkable
class Provider(Protocol):
    def capabilities(self) -> Mapping[str, Any]:
        ...

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        ...
