from __future__ import annotations

import inspect
from typing import Any

from osp_provider_contracts.capabilities import validate_capabilities


def _assert_method_arity(method: Any, expected: int, name: str) -> None:
    params = list(inspect.signature(method).parameters.values())
    required = [
        p
        for p in params
        if p.default is inspect.Signature.empty
        and p.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
    ]
    if len(required) < expected:
        message = f"{name} requires at least {expected} parameters, found {len(required)}"
        raise AssertionError(message)


def assert_provider_conforms(provider: Any) -> None:
    if not hasattr(provider, "capabilities") or not callable(provider.capabilities):
        raise AssertionError("provider must define callable capabilities()")
    if not hasattr(provider, "execute") or not callable(provider.execute):
        raise AssertionError("provider must define callable execute(action, request, context)")

    _assert_method_arity(provider.capabilities, expected=0, name="capabilities")
    _assert_method_arity(provider.execute, expected=3, name="execute")

    capabilities = provider.capabilities()
    if not isinstance(capabilities, dict):
        raise AssertionError("capabilities() must return a mapping")
    validate_capabilities(capabilities)
