from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class RequestContext:
    task_id: str
    request_id: str
    actor: str | None = None
    idempotency_key: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ProviderRequest:
    action: str
    resource_kind: str
    payload: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class ProviderResult:
    success: bool
    external_id: str | None = None
    message: str | None = None
    data: Mapping[str, Any] = field(default_factory=dict)
