from osp_provider_contracts.errors import (
    AuthError,
    ConflictError,
    DependencyError,
    NotFoundError,
    ProviderError,
    RateLimitError,
    TransientError,
    ValidationError,
)


def test_provider_error_shape() -> None:
    err = ProviderError(
        "boom",
        code="example",
        retryable=True,
        detail="details",
        extra={"x": 1},
    )
    assert err.code == "example"
    assert err.retryable is True
    assert err.as_dict()["extra"] == {"x": 1}


def test_subclass_defaults() -> None:
    assert AuthError("x").retryable is False
    assert NotFoundError("x").code == "not_found"
    assert ConflictError("x").code == "conflict"
    assert ValidationError("x").code == "validation_error"
    assert RateLimitError("x").retryable is True
    assert DependencyError("x").retryable is True
    assert TransientError("x").retryable is True
