from osp_provider_contracts.idempotency import build_idempotency_key
from osp_provider_contracts.types import RequestContext


def test_idempotency_key_is_deterministic() -> None:
    ctx = RequestContext(task_id="task-1", request_id="req-1")
    first = build_idempotency_key(context=ctx, action="provision", resource_key="bucket:demo")
    second = build_idempotency_key(context=ctx, action="provision", resource_key="bucket:demo")
    assert first == second


def test_idempotency_key_avoids_delimiter_collisions() -> None:
    a = RequestContext(task_id="a|b", request_id="c")
    b = RequestContext(task_id="a", request_id="b|c")

    key_a = build_idempotency_key(context=a, action="x", resource_key="y")
    key_b = build_idempotency_key(context=b, action="x", resource_key="y")

    assert key_a != key_b
