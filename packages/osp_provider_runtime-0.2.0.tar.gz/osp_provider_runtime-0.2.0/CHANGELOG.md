# Changelog

## 0.2.0 - 2026-02-12

- Removed dead `RuntimeConfig.from_env()` path and `run_provider()` helper.
- Added explicit RabbitMQ connection close on runtime shutdown.
- Added `RabbitMQRunner` tests for topology declaration and ack/nack/publish behavior.
- Added legacy status/severity `IntEnum` values instead of inline magic numbers.
- Removed `DeliveryHandler` protocol indirection in favor of typed callables.
- Normalized legacy payload parsing to exclude envelope metadata from provider payload.
- Updated response serialization to match `ProviderResult` contract (no `state` field).

## 0.1.0 - 2026-02-12

- Initial alpha runtime package.
- Added thin provider execution runtime and RabbitMQ runner.
- Added envelope parsing/serialization and explicit ack decision model.
- Added tests for envelope validation and retry/ack semantics.
