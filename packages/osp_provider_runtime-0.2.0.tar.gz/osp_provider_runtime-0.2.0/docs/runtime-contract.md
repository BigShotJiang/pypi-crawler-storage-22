# Runtime Messaging Contract (v0.1)

Request envelope required fields:
- `envelope_version` (string)
- `contract_version` (string)
- `message_id` (string)
- `correlation_id` (string)
- `task_id` (string)
- `action` (string)
- `resource_kind` (string)
- `payload` (object)

Optional fields:
- `attempt` (int, defaults to 1)
- `idempotency_key` (string)
- `provider` (string)

Response envelope:
- `envelope_version`
- `contract_version`
- `message_id`
- `correlation_id`
- `task_id`
- `ok` (bool)
- `provider` (string)
- `action` (string)
- `result` (object, only when `ok=true`)
- `error` (object, only when `ok=false`)

Error object shape:
- `code` (string)
- `detail` (string | null)
- `retryable` (bool)
- `extra` (object)

Ack policy:
- Success: `ack`.
- `ProviderError(retryable=false)`: `ack`.
- `ProviderError(retryable=true)`: `requeue` until max attempts; then dead-letter.
- Unknown exception: treat as retryable transient error with same attempt policy.

Legacy compatibility:
- Runtime also accepts legacy orchestrator outbox payloads:
  - `{"id": <int>, "action": <str>, ...}`
- For legacy input, runtime can emit provider update events to `osp.to_orch`
  using `status_code=200` on success and `status_code=580` on terminal errors.

Runtime topology behavior:
- Runtime declares and binds its request queue on startup.
- Default request exchange: `osp.from_orch` (topic).
- Default request binding: `<provider_name>.#`.
- Default updates exchange: `osp.to_orch` (topic).
