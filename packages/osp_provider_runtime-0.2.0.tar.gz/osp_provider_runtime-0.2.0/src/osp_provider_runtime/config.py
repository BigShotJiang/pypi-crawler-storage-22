from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class RuntimeConfig:
    rabbitmq_url: str
    request_queue: str
    request_exchange: str = "osp.from_orch"
    request_binding: str | None = None
    prefetch_count: int = 1
    concurrency: int = 1
    max_attempts: int = 5
    handler_timeout_seconds: float | None = None
    dead_letter_exchange: str | None = None
    dead_letter_routing_key: str | None = None
    heartbeat_seconds: int = 60
    blocked_connection_timeout_seconds: int = 30
    provider_name: str = "unknown-provider"
    updates_exchange: str = "osp.to_orch"
    updates_routing_key: str = "unknown-provider"
    emit_legacy_updates: bool = True
