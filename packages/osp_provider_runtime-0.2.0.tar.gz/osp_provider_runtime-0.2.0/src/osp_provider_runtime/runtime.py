from __future__ import annotations

import concurrent.futures
import json
from enum import IntEnum
from typing import Any

from loguru import logger
from osp_provider_contracts import (
    Provider,
    ProviderError,
    ProviderRequest,
    ProviderResult,
    RequestContext,
)
from osp_provider_contracts.errors import TransientError

from .config import RuntimeConfig
from .envelope import (
    RequestEnvelope,
    ResponseEnvelope,
    dump_response_envelope,
    parse_request_envelope,
)
from .transport import AckAction, Delivery, DeliveryResult


class LegacyStatusCode(IntEnum):
    COMPLETED = 200
    PROVIDER_ERROR = 580


class LegacySeverity(IntEnum):
    INFO = 20
    ERROR = 40


class ProviderRuntime:
    def __init__(self, provider: Provider, config: RuntimeConfig) -> None:
        self.provider = provider
        self.config = config

    def handle_delivery(self, delivery: Delivery) -> DeliveryResult:
        try:
            request_env = parse_request_envelope(delivery.body)
        except Exception:
            logger.exception("Malformed request envelope")
            return DeliveryResult(ack_action=AckAction.DEAD_LETTER)

        try:
            result = self._execute_provider(request_env)
            response_env = self._build_success_response(request_env, result)
            response = dump_response_envelope(response_env)
            update_body = self._build_legacy_update_success(request_env, result)
            logger.info(
                "Processed message",
                message_id=request_env.message_id,
                task_id=request_env.task_id,
                attempt=request_env.attempt,
                decision="ack",
            )
            return DeliveryResult(
                ack_action=AckAction.ACK,
                response_body=response,
                response_routing_key=delivery.reply_to,
                response_correlation_id=request_env.correlation_id,
                update_body=update_body,
                update_exchange=self.config.updates_exchange if update_body else None,
                update_routing_key=self.config.updates_routing_key if update_body else None,
            )
        except ProviderError as exc:
            return self._handle_provider_error(request_env, delivery, exc)
        except Exception as exc:  # noqa: BLE001
            transient = TransientError(str(exc), detail="Unhandled runtime exception")
            return self._handle_provider_error(request_env, delivery, transient)

    def _execute_provider(self, request_env: RequestEnvelope) -> ProviderResult:
        context = RequestContext(
            task_id=request_env.task_id,
            request_id=request_env.correlation_id,
            idempotency_key=request_env.idempotency_key,
        )
        request = ProviderRequest(
            action=request_env.action,
            resource_kind=request_env.resource_kind,
            payload=request_env.payload,
        )
        timeout = self.config.handler_timeout_seconds
        if timeout is None:
            return self.provider.execute(request_env.action, request, context)

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(self.provider.execute, request_env.action, request, context)
            try:
                return future.result(timeout=timeout)
            except concurrent.futures.TimeoutError as exc:
                raise TransientError(
                    f"Provider execution timed out after {timeout} seconds",
                    detail="handler_timeout",
                    extra={"timeout_seconds": timeout},
                ) from exc

    def _handle_provider_error(
        self,
        request_env: RequestEnvelope,
        delivery: Delivery,
        exc: ProviderError,
    ) -> DeliveryResult:
        attempts_left = request_env.attempt < self.config.max_attempts
        if exc.retryable and attempts_left:
            logger.warning(
                "Retryable provider error; requeueing",
                message_id=request_env.message_id,
                task_id=request_env.task_id,
                attempt=request_env.attempt,
                decision="requeue",
                error_code=exc.code,
            )
            return DeliveryResult(ack_action=AckAction.REQUEUE)

        ack_action = AckAction.DEAD_LETTER if exc.retryable else AckAction.ACK
        decision = "dead_letter" if ack_action == AckAction.DEAD_LETTER else "ack"
        response_env = self._build_error_response(request_env, exc)
        response = dump_response_envelope(response_env)
        logger.error(
            "Provider error",
            message_id=request_env.message_id,
            task_id=request_env.task_id,
            attempt=request_env.attempt,
            decision=decision,
            error_code=exc.code,
            retryable=exc.retryable,
        )
        return DeliveryResult(
            ack_action=ack_action,
            response_body=response,
            response_routing_key=delivery.reply_to,
            response_correlation_id=request_env.correlation_id,
            update_body=self._build_legacy_update_error(request_env, exc),
            update_exchange=self.config.updates_exchange,
            update_routing_key=self.config.updates_routing_key,
        )

    def _build_success_response(
        self,
        request_env: RequestEnvelope,
        result: ProviderResult,
    ) -> ResponseEnvelope:
        payload: dict[str, Any] = {
            "success": result.success,
            "external_id": result.external_id,
            "message": result.message,
            "data": dict(result.data),
        }
        return ResponseEnvelope(
            envelope_version=request_env.envelope_version,
            contract_version=request_env.contract_version,
            message_id=request_env.message_id,
            correlation_id=request_env.correlation_id,
            task_id=request_env.task_id,
            ok=True,
            provider=self.config.provider_name,
            action=request_env.action,
            result=payload,
            error=None,
        )

    def _build_error_response(
        self,
        request_env: RequestEnvelope,
        exc: ProviderError,
    ) -> ResponseEnvelope:
        error = {
            "code": exc.code,
            "detail": exc.detail,
            "retryable": exc.retryable,
            "extra": exc.extra,
        }
        return ResponseEnvelope(
            envelope_version=request_env.envelope_version,
            contract_version=request_env.contract_version,
            message_id=request_env.message_id,
            correlation_id=request_env.correlation_id,
            task_id=request_env.task_id,
            ok=False,
            provider=self.config.provider_name,
            action=request_env.action,
            result=None,
            error=error,
        )

    def _build_legacy_update_success(
        self,
        request_env: RequestEnvelope,
        result: ProviderResult,
    ) -> bytes | None:
        is_legacy = request_env.source_format == "legacy_orchestrator"
        if not self.config.emit_legacy_updates or not is_legacy:
            return None
        if request_env.legacy_task_id is None:
            return None
        payload = {
            "requested": dict(request_env.payload),
            "resolved": dict(result.data or {}),
            "provenance": {},
            "dry_run": bool(request_env.payload.get("dry_run") or request_env.payload.get("check")),
        }
        body = {
            "id": request_env.legacy_task_id,
            "status_code": int(LegacyStatusCode.COMPLETED),
            "severity": int(LegacySeverity.INFO),
            "message": result.message or "Completed",
            "payload": payload,
        }
        return json.dumps(body, separators=(",", ":")).encode("utf-8")

    def _build_legacy_update_error(
        self,
        request_env: RequestEnvelope,
        exc: ProviderError,
    ) -> bytes | None:
        is_legacy = request_env.source_format == "legacy_orchestrator"
        if not self.config.emit_legacy_updates or not is_legacy:
            return None
        if request_env.legacy_task_id is None:
            return None
        body = {
            "id": request_env.legacy_task_id,
            "status_code": int(LegacyStatusCode.PROVIDER_ERROR),
            "severity": int(LegacySeverity.ERROR),
            "message": exc.message,
            "payload": {
                "error": {
                    "code": exc.code,
                    "detail": exc.detail,
                    "retryable": exc.retryable,
                    "extra": exc.extra,
                }
            },
        }
        return json.dumps(body, separators=(",", ":")).encode("utf-8")
