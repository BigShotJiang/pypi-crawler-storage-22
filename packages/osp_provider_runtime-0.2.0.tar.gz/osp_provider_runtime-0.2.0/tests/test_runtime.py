import json
import time
from typing import Any

from osp_provider_contracts import ProviderError, ProviderRequest, ProviderResult, RequestContext

from osp_provider_runtime.config import RuntimeConfig
from osp_provider_runtime.runtime import ProviderRuntime
from osp_provider_runtime.transport import AckAction, Delivery


def _envelope(attempt: int = 1) -> bytes:
    return json.dumps(
        {
            "envelope_version": "1",
            "contract_version": "0.1",
            "message_id": "m1",
            "correlation_id": "c1",
            "task_id": "t1",
            "action": "create",
            "resource_kind": "bucket",
            "payload": {"name": "x"},
            "attempt": attempt,
        }
    ).encode()


class OkProvider:
    def capabilities(self) -> dict[str, Any]:
        return {"provider": "ok", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        return ProviderResult(success=True, message="done")


class FailingProvider:
    def __init__(self, exc: ProviderError):
        self.exc = exc

    def capabilities(self) -> dict[str, Any]:
        return {"provider": "fail", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        raise self.exc


class SlowProvider:
    def capabilities(self) -> dict[str, Any]:
        return {"provider": "slow", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        time.sleep(0.05)
        return ProviderResult(success=True, message="done")


def test_success_ack_and_response() -> None:
    runtime = ProviderRuntime(
        provider=OkProvider(),
        config=RuntimeConfig("amqp://guest:guest@localhost:5672/", "q", provider_name="p"),
    )

    result = runtime.handle_delivery(Delivery(body=_envelope(), reply_to="reply.q"))

    assert result.ack_action == AckAction.ACK
    assert result.response_body is not None
    assert result.response_routing_key == "reply.q"
    assert result.update_body is None


def test_retryable_error_requeues_before_limit() -> None:
    runtime = ProviderRuntime(
        provider=FailingProvider(ProviderError("nope", retryable=True, code="x")),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            max_attempts=3,
            provider_name="p",
        ),
    )

    result = runtime.handle_delivery(Delivery(body=_envelope(attempt=1), reply_to="reply.q"))

    assert result.ack_action == AckAction.REQUEUE
    assert result.response_body is None


def test_retryable_error_dead_letters_on_limit() -> None:
    runtime = ProviderRuntime(
        provider=FailingProvider(ProviderError("nope", retryable=True, code="x")),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            max_attempts=3,
            provider_name="p",
        ),
    )

    result = runtime.handle_delivery(Delivery(body=_envelope(attempt=3), reply_to="reply.q"))

    assert result.ack_action == AckAction.DEAD_LETTER
    assert result.response_body is not None


def test_non_retryable_error_acks() -> None:
    runtime = ProviderRuntime(
        provider=FailingProvider(ProviderError("bad", retryable=False, code="bad")),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            max_attempts=3,
            provider_name="p",
        ),
    )

    result = runtime.handle_delivery(Delivery(body=_envelope(attempt=1), reply_to="reply.q"))

    assert result.ack_action == AckAction.ACK
    assert result.response_body is not None


def test_malformed_envelope_dead_letters() -> None:
    runtime = ProviderRuntime(
        provider=OkProvider(),
        config=RuntimeConfig("amqp://guest:guest@localhost:5672/", "q", provider_name="p"),
    )

    result = runtime.handle_delivery(Delivery(body=b"not-json", reply_to="reply.q"))

    assert result.ack_action == AckAction.DEAD_LETTER
    assert result.response_body is None


def test_handler_timeout_requeues_before_limit() -> None:
    runtime = ProviderRuntime(
        provider=SlowProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="p",
            handler_timeout_seconds=0.001,
            max_attempts=3,
        ),
    )
    result = runtime.handle_delivery(Delivery(body=_envelope(attempt=1), reply_to="reply.q"))
    assert result.ack_action == AckAction.REQUEUE
    assert result.response_body is None


def test_legacy_message_emits_update_on_success() -> None:
    runtime = ProviderRuntime(
        provider=OkProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="nrec",
            updates_exchange="osp.to_orch",
            updates_routing_key="nrec",
            emit_legacy_updates=True,
        ),
    )
    legacy = json.dumps({"id": 7, "action": "create", "name": "x"}).encode()
    result = runtime.handle_delivery(Delivery(body=legacy, reply_to=None))
    assert result.ack_action == AckAction.ACK
    assert result.update_body is not None
    assert result.update_exchange == "osp.to_orch"
    assert result.update_routing_key == "nrec"
