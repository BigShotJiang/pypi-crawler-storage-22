# Changelog

## 0.2.2 - 2026-02-13

- Switched approval update payload to canonical `payload.approval` block as
  the primary contract shape.
- Updated orchestrator update consumer to read approval fields from
  `payload.approval` (with fallback), reducing compatibility shim complexity.
- Added tests for reserved approval payload block handling and stale-update
  behavior.
- Added runtime observability assertions for `task_id`, `correlation_id`,
  and emitted `event_id` fields in processed message logs.
- Added release notes document for TaskReporter migration and rollout.

## 0.2.1 - 2026-02-13

- Added canonical update model and thin `TaskReporter` API for provider update emission.
- Standardized helper fast paths (`accepted`, `running`, `progress`, `require_approval`,
  `deny`, `completed`, `failed`) with one low-level `update` escape hatch.
- Added reserved payload blocks (`approval`, `progress`) and explicit update metadata
  (`event_id`, `correlation_id`, `task_id`) in emitted payloads.
- Hardened update serialization with JSON-safe coercion.
- Enabled provider update emission for contract envelopes when task id is resolvable.
- Added deterministic mapping for approval-required errors to `WAITING_APPROVAL` updates.
- Added tests for contract/update mapping and `TaskReporter` behavior.
- Added provider migration and runtime upgrade docs.
- Removed runtime internal legacy naming in update emission path.

## 0.2.0 - 2026-02-12

- Removed dead `RuntimeConfig.from_env()` path and `run_provider()` helper.
- Added explicit RabbitMQ connection close on runtime shutdown.
- Added `RabbitMQRunner` tests for topology declaration and ack/nack/publish behavior.
- Added legacy status/severity `IntEnum` values instead of inline magic numbers.
- Removed `DeliveryHandler` protocol indirection in favor of typed callables.
- Normalized legacy payload parsing to exclude envelope metadata from provider payload.
- Updated response serialization to match `ProviderResult` contract (no `state` field).

## 0.1.0 - 2026-02-12

- Initial alpha runtime package.
- Added thin provider execution runtime and RabbitMQ runner.
- Added envelope parsing/serialization and explicit ack decision model.
- Added tests for envelope validation and retry/ack semantics.
