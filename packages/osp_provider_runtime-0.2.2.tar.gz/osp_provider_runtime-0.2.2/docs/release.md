# Release Guide

Automated on tag `vX.Y.Z`:
- run lint, type-check, tests
- build sdist + wheel
- run `twine check dist/*`
- attach artifacts to GitHub Release

Manual/gated publish:

```bash
env -u VIRTUAL_ENV uv sync --extra dev
hatch shell
hatch run check
hatch run build
hatch run verify
hatch run publish
```

Pre-publish note:
- `osp-provider-runtime` depends on `osp-provider-contracts`.
- Publish contracts first (or use local `uv` checks in monorepo before publish).

For internal index or other repository:

```bash
hatch publish -r <repo-name>
```

Credentials should be stored in `~/.pypirc` (or keyring), not committed.

TestPyPI dry run publish:

```bash
hatch run publish-test
```
