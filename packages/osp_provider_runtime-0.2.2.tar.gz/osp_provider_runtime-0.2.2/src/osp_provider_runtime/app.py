from __future__ import annotations

from osp_provider_contracts import Provider

from .config import RuntimeConfig
from .rabbitmq import RabbitMQRunner
from .runtime import ProviderRuntime


def run_provider_with_config(provider: Provider, config: RuntimeConfig) -> None:
    runtime = ProviderRuntime(provider=provider, config=config)
    runner = RabbitMQRunner(config)
    runner.run(runtime.handle_delivery)
