from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class RequestEnvelope:
    envelope_version: str
    contract_version: str
    message_id: str
    correlation_id: str
    task_id: str
    action: str
    resource_kind: str
    payload: dict[str, Any]
    attempt: int = 1
    idempotency_key: str | None = None
    provider: str | None = None
    source_format: str = "contract_v1"
    legacy_task_id: int | None = None


@dataclass(frozen=True, slots=True)
class ResponseEnvelope:
    envelope_version: str
    contract_version: str
    message_id: str
    correlation_id: str
    task_id: str
    ok: bool
    provider: str
    action: str
    result: dict[str, Any] | None = None
    error: dict[str, Any] | None = None


REQUIRED_REQUEST_FIELDS = {
    "envelope_version",
    "contract_version",
    "message_id",
    "correlation_id",
    "task_id",
    "action",
    "resource_kind",
    "payload",
}

LEGACY_ENVELOPE_KEYS = {
    "id",
    "action",
    "provider",
    "attempt",
    "message_id",
    "correlation_id",
    "resource_kind",
    "idempotency_key",
}


def parse_request_envelope(raw_body: bytes) -> RequestEnvelope:
    data = json.loads(raw_body.decode("utf-8"))

    if not isinstance(data, dict):
        raise ValueError("request envelope must be a JSON object")

    missing = sorted(REQUIRED_REQUEST_FIELDS - set(data.keys()))
    if not missing:
        payload = data["payload"]
        if not isinstance(payload, dict):
            raise ValueError("payload must be a JSON object")

        attempt = data.get("attempt", 1)
        if not isinstance(attempt, int) or attempt < 1:
            raise ValueError("attempt must be an integer >= 1")

        return RequestEnvelope(
            envelope_version=str(data["envelope_version"]),
            contract_version=str(data["contract_version"]),
            message_id=str(data["message_id"]),
            correlation_id=str(data["correlation_id"]),
            task_id=str(data["task_id"]),
            action=str(data["action"]),
            resource_kind=str(data["resource_kind"]),
            payload=payload,
            attempt=attempt,
            idempotency_key=(str(data["idempotency_key"]) if "idempotency_key" in data else None),
            provider=(str(data["provider"]) if "provider" in data else None),
            source_format="contract_v1",
            legacy_task_id=None,
        )

    # Legacy orchestrator outbox payload:
    # {"id": int, "action": str, ...} with provider-specific fields at top level.
    if "id" not in data or "action" not in data:
        raise ValueError(f"missing required envelope fields: {missing}")
    task_id = data.get("id")
    action = data.get("action")
    if not isinstance(task_id, int) or not isinstance(action, str) or not action.strip():
        raise ValueError("legacy message requires id:int and action:str")
    attempt = data.get("attempt", 1)
    if not isinstance(attempt, int) or attempt < 1:
        raise ValueError("attempt must be an integer >= 1")
    provider = data.get("provider")
    message_id = str(data.get("message_id") or f"legacy-task-{task_id}")
    correlation_id = str(data.get("correlation_id") or message_id)
    payload = {k: v for k, v in data.items() if k not in LEGACY_ENVELOPE_KEYS}
    return RequestEnvelope(
        envelope_version="legacy_v1",
        contract_version="legacy_v1",
        message_id=message_id,
        correlation_id=correlation_id,
        task_id=str(task_id),
        action=action.strip(),
        resource_kind=str(data.get("resource_kind") or "task"),
        payload=payload,
        attempt=attempt,
        idempotency_key=(str(data["idempotency_key"]) if "idempotency_key" in data else None),
        provider=(str(provider) if provider is not None else None),
        source_format="legacy_orchestrator",
        legacy_task_id=task_id,
    )


def dump_response_envelope(envelope: ResponseEnvelope) -> bytes:
    return json.dumps(asdict(envelope), separators=(",", ":")).encode("utf-8")
