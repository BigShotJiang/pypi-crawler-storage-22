from __future__ import annotations

import concurrent.futures
from collections.abc import Callable
from typing import Any

import pika  # type: ignore[import-untyped]
from loguru import logger

from .config import RuntimeConfig
from .transport import AckAction, Delivery, DeliveryResult


class RabbitMQRunner:
    def __init__(self, config: RuntimeConfig) -> None:
        self.config = config

    def run(self, handler: Callable[[Delivery], DeliveryResult]) -> None:
        if self.config.concurrency < 1:
            raise ValueError("RuntimeConfig.concurrency must be >= 1")
        params = pika.URLParameters(self.config.rabbitmq_url)
        params.heartbeat = self.config.heartbeat_seconds
        params.blocked_connection_timeout = self.config.blocked_connection_timeout_seconds
        connection = pika.BlockingConnection(params)
        channel = connection.channel()
        prefetch = max(self.config.prefetch_count, self.config.concurrency)
        channel.basic_qos(prefetch_count=prefetch)
        channel.exchange_declare(
            exchange=self.config.request_exchange,
            exchange_type="topic",
            durable=True,
        )
        channel.exchange_declare(
            exchange=self.config.updates_exchange,
            exchange_type="topic",
            durable=True,
        )
        queue_arguments: dict[str, Any] = {}
        if self.config.dead_letter_exchange:
            queue_arguments["x-dead-letter-exchange"] = self.config.dead_letter_exchange
        if self.config.dead_letter_routing_key:
            queue_arguments["x-dead-letter-routing-key"] = self.config.dead_letter_routing_key
        channel.queue_declare(
            queue=self.config.request_queue,
            durable=True,
            arguments=queue_arguments or None,
        )
        if self.config.request_binding:
            bindings = [
                item.strip()
                for item in self.config.request_binding.split(",")
                if item.strip()
            ]
            for binding in bindings:
                channel.queue_bind(
                    queue=self.config.request_queue,
                    exchange=self.config.request_exchange,
                    routing_key=binding,
                )

        executor = concurrent.futures.ThreadPoolExecutor(max_workers=self.config.concurrency)

        def _publish_result(ch: Any, method: Any, result: DeliveryResult) -> None:
            if result.response_body and result.response_routing_key:
                channel.basic_publish(
                    exchange="",
                    routing_key=result.response_routing_key,
                    body=result.response_body,
                    properties=pika.BasicProperties(
                        content_type="application/json",
                        correlation_id=result.response_correlation_id,
                    ),
                )
            if result.update_body and result.update_exchange and result.update_routing_key:
                channel.basic_publish(
                    exchange=result.update_exchange,
                    routing_key=result.update_routing_key,
                    body=result.update_body,
                    properties=pika.BasicProperties(
                        content_type="application/json",
                    ),
                )

        def _on_message(ch: Any, method: Any, properties: Any, body: bytes) -> None:
            delivery = Delivery(
                body=body,
                reply_to=properties.reply_to,
                routing_key=getattr(method, "routing_key", None),
            )

            def _finalize(future: concurrent.futures.Future[DeliveryResult]) -> None:
                try:
                    result = future.result()
                except Exception:
                    logger.exception(
                        "Unhandled exception in delivery handler",
                        routing_key=delivery.routing_key,
                    )
                    result = DeliveryResult(ack_action=AckAction.DEAD_LETTER)

                def _on_connection_thread() -> None:
                    # Pika channels are not thread-safe; publish and ack/nack on
                    # the connection thread.
                    _publish_result(ch, method, result)
                    if result.ack_action == AckAction.ACK:
                        ch.basic_ack(delivery_tag=method.delivery_tag)
                    elif result.ack_action == AckAction.REQUEUE:
                        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)
                    else:
                        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
                    logger.info(
                        "Delivery finalized",
                        routing_key=delivery.routing_key,
                        ack_action=result.ack_action.value,
                    )

                connection.add_callback_threadsafe(_on_connection_thread)

            future = executor.submit(handler, delivery)
            future.add_done_callback(_finalize)

        channel.basic_consume(queue=self.config.request_queue, on_message_callback=_on_message)
        logger.info(
            "Starting runtime consumer",
            queue=self.config.request_queue,
            exchange=self.config.request_exchange,
            binding=self.config.request_binding,
            updates_exchange=self.config.updates_exchange,
            updates_routing_key=self.config.updates_routing_key,
            prefetch=prefetch,
            concurrency=self.config.concurrency,
            handler_timeout_seconds=self.config.handler_timeout_seconds,
            dead_letter_exchange=self.config.dead_letter_exchange,
            dead_letter_routing_key=self.config.dead_letter_routing_key,
        )
        try:
            channel.start_consuming()
        finally:
            executor.shutdown(wait=True)
            try:
                if connection.is_open:
                    connection.close()
            except Exception:
                logger.exception("Failed to close RabbitMQ connection cleanly")
