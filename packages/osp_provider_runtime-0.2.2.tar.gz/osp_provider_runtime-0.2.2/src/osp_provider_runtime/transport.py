from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class AckAction(StrEnum):
    ACK = "ack"
    REQUEUE = "requeue"
    DEAD_LETTER = "dead_letter"


@dataclass(frozen=True, slots=True)
class Delivery:
    body: bytes
    reply_to: str | None
    routing_key: str | None = None


@dataclass(frozen=True, slots=True)
class DeliveryResult:
    ack_action: AckAction
    response_body: bytes | None = None
    response_routing_key: str | None = None
    response_correlation_id: str | None = None
    update_body: bytes | None = None
    update_exchange: str | None = None
    update_routing_key: str | None = None
