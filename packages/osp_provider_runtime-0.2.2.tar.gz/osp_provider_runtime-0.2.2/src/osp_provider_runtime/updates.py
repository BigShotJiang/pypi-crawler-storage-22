from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4


def _json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_json_safe(v) for v in value]
    if isinstance(value, tuple):
        return [_json_safe(v) for v in value]
    if hasattr(value, "isoformat"):
        try:
            return value.isoformat()
        except Exception:  # noqa: BLE001
            pass
    if hasattr(value, "value") and hasattr(value, "source"):
        return {
            "value": _json_safe(getattr(value, "value", None)),
            "source": str(getattr(value, "source", "")),
            "context_id": _json_safe(getattr(value, "context_id", None)),
        }
    return str(value)


@dataclass(frozen=True, slots=True)
class ProviderUpdate:
    event_id: str
    task_id: int
    correlation_id: str
    status_code: int
    severity: int
    message: str
    payload: dict[str, Any] | None = None

    def to_transport_body(self) -> dict[str, Any]:
        payload = dict(self.payload or {})
        # Compatibility for orchestrator consumer idempotency extraction.
        payload["event_id"] = self.event_id
        payload["correlation_id"] = self.correlation_id
        payload["task_id"] = self.task_id
        body = {
            "id": self.task_id,
            "status_code": int(self.status_code),
            "severity": int(self.severity),
            "message": self.message,
        }
        if payload:
            body["payload"] = payload
        return body

    def to_transport_bytes(self) -> bytes:
        body = self.to_transport_body()
        try:
            return json.dumps(body, separators=(",", ":")).encode("utf-8")
        except TypeError:
            return json.dumps(_json_safe(body), separators=(",", ":")).encode("utf-8")


class TaskReporter:
    # Runtime-local defaults matching current orchestrator semantics.
    STATUS_ACCEPTED = 105
    STATUS_RUNNING = 160
    STATUS_COMPLETED = 200
    STATUS_WAITING_APPROVAL = 301
    STATUS_PROVIDER_ERROR = 580
    STATUS_REJECTED = 900

    SEVERITY_INFO = 20
    SEVERITY_WARNING = 30
    SEVERITY_ERROR = 40

    def __init__(self, *, task_id: int, correlation_id: str) -> None:
        self.task_id = int(task_id)
        self.correlation_id = correlation_id

    def update(
        self,
        *,
        status_code: int,
        severity: int,
        message: str,
        payload: dict[str, Any] | None = None,
        event_id: str | None = None,
    ) -> ProviderUpdate:
        resolved_event_id = event_id or str(uuid4())
        return ProviderUpdate(
            event_id=resolved_event_id,
            task_id=self.task_id,
            correlation_id=self.correlation_id,
            status_code=int(status_code),
            severity=int(severity),
            message=message,
            payload=payload,
        )

    def accepted(self, *, message: str, payload: dict[str, Any] | None = None) -> ProviderUpdate:
        return self.update(
            status_code=self.STATUS_ACCEPTED,
            severity=self.SEVERITY_INFO,
            message=message,
            payload=payload,
        )

    def running(self, *, message: str, payload: dict[str, Any] | None = None) -> ProviderUpdate:
        return self.update(
            status_code=self.STATUS_RUNNING,
            severity=self.SEVERITY_INFO,
            message=message,
            payload=payload,
        )

    def progress(
        self,
        *,
        message: str,
        current: int,
        total: int,
        payload: dict[str, Any] | None = None,
    ) -> ProviderUpdate:
        data = dict(payload or {})
        data["progress"] = {"current": int(current), "total": int(total)}
        return self.update(
            status_code=self.STATUS_RUNNING,
            severity=self.SEVERITY_INFO,
            message=message,
            payload=data,
        )

    def require_approval(
        self,
        *,
        gate_code: int,
        importance: int,
        reason: str,
        details: dict[str, Any] | None = None,
        message: str = "Provider requires approval",
    ) -> ProviderUpdate:
        approval = {
            "gate_code": int(gate_code),
            "importance": int(importance),
            "reason": reason,
            "gated_at": datetime.now(UTC).isoformat(),
        }
        if details:
            approval["details"] = details
        payload: dict[str, Any] = {"approval": approval}
        return self.update(
            status_code=self.STATUS_WAITING_APPROVAL,
            severity=self.SEVERITY_WARNING,
            message=message,
            payload=payload,
        )

    def deny(
        self,
        *,
        message: str,
        reason_code: str,
        details: dict[str, Any] | None = None,
    ) -> ProviderUpdate:
        payload: dict[str, Any] = {"reason_code": reason_code}
        if details:
            payload["details"] = details
        return self.update(
            status_code=self.STATUS_REJECTED,
            severity=self.SEVERITY_ERROR,
            message=message,
            payload=payload,
        )

    def completed(self, *, message: str, payload: dict[str, Any] | None = None) -> ProviderUpdate:
        return self.update(
            status_code=self.STATUS_COMPLETED,
            severity=self.SEVERITY_INFO,
            message=message,
            payload=payload,
        )

    def failed(
        self,
        *,
        message: str,
        code: str,
        detail: str | None = None,
        retryable: bool = False,
        extra: dict[str, Any] | None = None,
        payload: dict[str, Any] | None = None,
    ) -> ProviderUpdate:
        data = dict(payload or {})
        data["error"] = {
            "code": code,
            "detail": detail,
            "retryable": retryable,
            "extra": dict(extra or {}),
        }
        return self.update(
            status_code=self.STATUS_PROVIDER_ERROR,
            severity=self.SEVERITY_ERROR,
            message=message,
            payload=data,
        )
