import json

import pytest

from osp_provider_runtime.envelope import parse_request_envelope


def test_parse_valid_request_envelope() -> None:
    body = json.dumps(
        {
            "envelope_version": "1",
            "contract_version": "0.1",
            "message_id": "m1",
            "correlation_id": "c1",
            "task_id": "t1",
            "action": "create",
            "resource_kind": "bucket",
            "payload": {"name": "x"},
        }
    ).encode()

    env = parse_request_envelope(body)
    assert env.message_id == "m1"
    assert env.attempt == 1
    assert env.source_format == "contract_v1"


def test_parse_missing_field_raises() -> None:
    body = json.dumps({"envelope_version": "1"}).encode()
    with pytest.raises(ValueError):
        parse_request_envelope(body)


def test_parse_invalid_attempt_raises() -> None:
    body = json.dumps(
        {
            "envelope_version": "1",
            "contract_version": "0.1",
            "message_id": "m1",
            "correlation_id": "c1",
            "task_id": "t1",
            "action": "create",
            "resource_kind": "bucket",
            "payload": {"name": "x"},
            "attempt": 0,
        }
    ).encode()
    with pytest.raises(ValueError):
        parse_request_envelope(body)


def test_parse_legacy_orchestrator_message() -> None:
    body = json.dumps(
        {
            "id": 123,
            "action": "provision",
            "provider": "nrec",
            "name": "host01",
        }
    ).encode()
    env = parse_request_envelope(body)
    assert env.source_format == "legacy_orchestrator"
    assert env.legacy_task_id == 123
    assert env.action == "provision"
    assert env.payload == {"name": "host01"}
