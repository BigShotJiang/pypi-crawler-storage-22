import json
import time
from typing import Any

from loguru import logger
from osp_provider_contracts import ProviderError, ProviderRequest, ProviderResult, RequestContext
from osp_provider_contracts.errors import ValidationError

from osp_provider_runtime.config import RuntimeConfig
from osp_provider_runtime.runtime import ProviderRuntime
from osp_provider_runtime.transport import AckAction, Delivery


def _envelope(attempt: int = 1) -> bytes:
    return json.dumps(
        {
            "envelope_version": "1",
            "contract_version": "0.1",
            "message_id": "m1",
            "correlation_id": "c1",
            "task_id": "t1",
            "action": "create",
            "resource_kind": "bucket",
            "payload": {"name": "x"},
            "attempt": attempt,
        }
    ).encode()


def _envelope_with_task_id(task_id: str) -> bytes:
    return json.dumps(
        {
            "envelope_version": "1",
            "contract_version": "0.1",
            "message_id": "m1",
            "correlation_id": "c1",
            "task_id": task_id,
            "action": "create",
            "resource_kind": "bucket",
            "payload": {"name": "x"},
            "attempt": 1,
        }
    ).encode()


class OkProvider:
    def capabilities(self) -> dict[str, Any]:
        return {"provider": "ok", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        return ProviderResult(success=True, message="done")


class FailingProvider:
    def __init__(self, exc: ProviderError):
        self.exc = exc

    def capabilities(self) -> dict[str, Any]:
        return {"provider": "fail", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        raise self.exc


class SlowProvider:
    def capabilities(self) -> dict[str, Any]:
        return {"provider": "slow", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        time.sleep(0.05)
        return ProviderResult(success=True, message="done")


class ApprovalProvider:
    def capabilities(self) -> dict[str, Any]:
        return {"provider": "approval", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        raise ValidationError(
            "Manual approval required",
            detail="approval_required",
            extra={
                "gate_code": 403,
                "importance": 2,
                "reason": "policy_violation",
                "details": {"scope": "network"},
            },
        )


class JsonUnsafeProvider:
    def capabilities(self) -> dict[str, Any]:
        return {"provider": "unsafe", "version": "0.1", "resources": []}

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        class _ResolvedItem:
            def __init__(self) -> None:
                self.value = {"cpu_cores": 4}
                self.source = "policy_default"
                self.context_id = None

        return ProviderResult(
            success=True,
            message="done",
            data={"provenance": {"cpu_cores": _ResolvedItem()}},
        )


def test_success_ack_and_response() -> None:
    runtime = ProviderRuntime(
        provider=OkProvider(),
        config=RuntimeConfig("amqp://guest:guest@localhost:5672/", "q", provider_name="p"),
    )

    result = runtime.handle_delivery(Delivery(body=_envelope(), reply_to="reply.q"))

    assert result.ack_action == AckAction.ACK
    assert result.response_body is not None
    assert result.response_routing_key == "reply.q"
    assert result.update_body is None


def test_contract_message_emits_update_when_task_id_is_numeric() -> None:
    runtime = ProviderRuntime(
        provider=OkProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="p",
            updates_exchange="osp.to_orch",
            updates_routing_key="p",
            emit_legacy_updates=True,
            emit_legacy_updates_for_contract_requests=True,
        ),
    )
    result = runtime.handle_delivery(
        Delivery(body=_envelope_with_task_id("7"), reply_to="reply.q")
    )
    assert result.ack_action == AckAction.ACK
    assert result.update_body is not None
    decoded = json.loads(result.update_body)
    assert decoded["id"] == 7
    assert decoded["status_code"] == 200
    assert result.update_exchange == "osp.to_orch"
    assert result.update_routing_key == "p"


def test_contract_message_can_disable_legacy_update_emission() -> None:
    runtime = ProviderRuntime(
        provider=OkProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="p",
            emit_legacy_updates=True,
            emit_legacy_updates_for_contract_requests=False,
        ),
    )
    result = runtime.handle_delivery(
        Delivery(body=_envelope_with_task_id("7"), reply_to="reply.q")
    )
    assert result.ack_action == AckAction.ACK
    assert result.update_body is None


def test_approval_required_maps_to_waiting_approval_update() -> None:
    runtime = ProviderRuntime(
        provider=ApprovalProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="p",
            emit_legacy_updates=True,
            emit_legacy_updates_for_contract_requests=True,
        ),
    )
    result = runtime.handle_delivery(
        Delivery(body=_envelope_with_task_id("9"), reply_to="reply.q")
    )
    assert result.ack_action == AckAction.ACK
    assert result.update_body is not None
    decoded = json.loads(result.update_body)
    assert decoded["id"] == 9
    assert decoded["status_code"] == 301
    assert decoded["severity"] == 30
    assert decoded["payload"]["approval"]["gate_code"] == 403
    assert decoded["payload"]["approval"]["importance"] == 2


def test_update_payload_is_json_safe() -> None:
    runtime = ProviderRuntime(
        provider=JsonUnsafeProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="p",
            emit_legacy_updates=True,
            emit_legacy_updates_for_contract_requests=True,
        ),
    )
    result = runtime.handle_delivery(
        Delivery(body=_envelope_with_task_id("11"), reply_to="reply.q")
    )
    assert result.ack_action == AckAction.ACK
    assert result.update_body is not None
    decoded = json.loads(result.update_body)
    assert decoded["id"] == 11
    assert decoded["payload"]["resolved"]["provenance"]["cpu_cores"]["value"]["cpu_cores"] == 4
    assert decoded["payload"]["resolved"]["provenance"]["cpu_cores"]["source"] == "policy_default"


def test_retryable_error_requeues_before_limit() -> None:
    runtime = ProviderRuntime(
        provider=FailingProvider(ProviderError("nope", retryable=True, code="x")),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            max_attempts=3,
            provider_name="p",
        ),
    )

    result = runtime.handle_delivery(Delivery(body=_envelope(attempt=1), reply_to="reply.q"))

    assert result.ack_action == AckAction.REQUEUE
    assert result.response_body is None


def test_retryable_error_dead_letters_on_limit() -> None:
    runtime = ProviderRuntime(
        provider=FailingProvider(ProviderError("nope", retryable=True, code="x")),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            max_attempts=3,
            provider_name="p",
        ),
    )

    result = runtime.handle_delivery(Delivery(body=_envelope(attempt=3), reply_to="reply.q"))

    assert result.ack_action == AckAction.DEAD_LETTER
    assert result.response_body is not None


def test_non_retryable_error_acks() -> None:
    runtime = ProviderRuntime(
        provider=FailingProvider(ProviderError("bad", retryable=False, code="bad")),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            max_attempts=3,
            provider_name="p",
        ),
    )

    result = runtime.handle_delivery(Delivery(body=_envelope(attempt=1), reply_to="reply.q"))

    assert result.ack_action == AckAction.ACK
    assert result.response_body is not None


def test_malformed_envelope_dead_letters() -> None:
    runtime = ProviderRuntime(
        provider=OkProvider(),
        config=RuntimeConfig("amqp://guest:guest@localhost:5672/", "q", provider_name="p"),
    )

    result = runtime.handle_delivery(Delivery(body=b"not-json", reply_to="reply.q"))

    assert result.ack_action == AckAction.DEAD_LETTER
    assert result.response_body is None


def test_handler_timeout_requeues_before_limit() -> None:
    runtime = ProviderRuntime(
        provider=SlowProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="p",
            handler_timeout_seconds=0.001,
            max_attempts=3,
        ),
    )
    result = runtime.handle_delivery(Delivery(body=_envelope(attempt=1), reply_to="reply.q"))
    assert result.ack_action == AckAction.REQUEUE
    assert result.response_body is None


def test_legacy_message_emits_update_on_success() -> None:
    runtime = ProviderRuntime(
        provider=OkProvider(),
        config=RuntimeConfig(
            "amqp://guest:guest@localhost:5672/",
            "q",
            provider_name="nrec",
            updates_exchange="osp.to_orch",
            updates_routing_key="nrec",
            emit_legacy_updates=True,
        ),
    )
    legacy = json.dumps({"id": 7, "action": "create", "name": "x"}).encode()
    result = runtime.handle_delivery(Delivery(body=legacy, reply_to=None))
    assert result.ack_action == AckAction.ACK
    assert result.update_body is not None
    assert result.update_exchange == "osp.to_orch"
    assert result.update_routing_key == "nrec"


def test_processed_message_log_includes_correlation_and_event_id() -> None:
    records: list[dict[str, Any]] = []

    def _sink(message: Any) -> None:
        records.append(message.record)

    sink_id = logger.add(_sink, level="INFO")
    try:
        runtime = ProviderRuntime(
            provider=OkProvider(),
            config=RuntimeConfig(
                "amqp://guest:guest@localhost:5672/",
                "q",
                provider_name="p",
                updates_exchange="osp.to_orch",
                updates_routing_key="p",
                emit_legacy_updates=True,
                emit_legacy_updates_for_contract_requests=True,
            ),
        )
        _ = runtime.handle_delivery(Delivery(body=_envelope_with_task_id("7"), reply_to="reply.q"))
    finally:
        logger.remove(sink_id)

    processed = [r for r in records if r.get("message") == "Processed message"]
    assert processed, "Expected runtime to emit 'Processed message' log"
    extra = processed[-1]["extra"]
    assert extra.get("task_id") == "7"
    assert extra.get("correlation_id") == "c1"
    assert isinstance(extra.get("update_event_id"), str) and extra["update_event_id"]
