from __future__ import annotations

import json

from osp_provider_runtime.updates import TaskReporter


def test_update_includes_contract_metadata_in_payload() -> None:
    reporter = TaskReporter(task_id=42, correlation_id="corr-42")
    update = reporter.update(
        status_code=160,
        severity=20,
        message="Running",
        payload={"step": "clone"},
        event_id="evt-1",
    )
    body = update.to_transport_body()
    assert body["id"] == 42
    assert body["status_code"] == 160
    assert body["severity"] == 20
    assert body["message"] == "Running"
    assert body["payload"]["step"] == "clone"
    assert body["payload"]["event_id"] == "evt-1"
    assert body["payload"]["correlation_id"] == "corr-42"
    assert body["payload"]["task_id"] == 42


def test_require_approval_uses_reserved_approval_block() -> None:
    reporter = TaskReporter(task_id=7, correlation_id="corr-7")
    update = reporter.require_approval(
        gate_code=403,
        importance=2,
        reason="policy_violation",
        details={"scope": "network"},
        message="Need approval",
    )
    body = update.to_transport_body()
    assert body["status_code"] == 301
    assert body["severity"] == 30
    approval = body["payload"]["approval"]
    assert approval["gate_code"] == 403
    assert approval["importance"] == 2
    assert approval["reason"] == "policy_violation"


def test_progress_uses_standard_payload_shape() -> None:
    reporter = TaskReporter(task_id=5, correlation_id="corr-5")
    body = reporter.progress(message="Halfway", current=5, total=10).to_transport_body()
    assert body["status_code"] == 160
    assert body["severity"] == 20
    assert body["payload"]["progress"] == {"current": 5, "total": 10}


def test_transport_bytes_is_json_safe() -> None:
    reporter = TaskReporter(task_id=8, correlation_id="corr-8")

    class _ResolvedItem:
        def __init__(self) -> None:
            self.value = {"cpu_cores": 4}
            self.source = "policy_default"
            self.context_id = None

    raw = reporter.completed(
        message="Done",
        payload={"resolved": {"cpu_cores": _ResolvedItem()}},
    ).to_transport_bytes()
    decoded = json.loads(raw.decode("utf-8"))
    assert decoded["payload"]["resolved"]["cpu_cores"]["value"]["cpu_cores"] == 4
    assert decoded["payload"]["resolved"]["cpu_cores"]["source"] == "policy_default"
