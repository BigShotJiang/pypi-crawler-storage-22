from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class RuntimeConfig:
    rabbitmq_url: str
    request_queue: str
    request_exchange: str = "osp.from_orch"
    request_binding: str | None = None
    prefetch_count: int = 1
    concurrency: int = 1
    max_attempts: int = 5
    handler_timeout_seconds: float | None = None
    dead_letter_exchange: str | None = None
    dead_letter_routing_key: str | None = None
    heartbeat_seconds: int = 60
    blocked_connection_timeout_seconds: int = 30
    connect_max_attempts: int = 0
    connect_backoff_base_seconds: float = 1.0
    connect_backoff_max_seconds: float = 30.0
    connect_backoff_jitter_factor: float = 0.2
    retry_backoff_base_seconds: float = 1.0
    retry_backoff_max_seconds: float = 30.0
    retry_backoff_jitter_factor: float = 0.2
    provider_name: str = "unknown-provider"
    updates_exchange: str = "osp.to_orch"
    updates_routing_key: str = "unknown-provider"
    emit_legacy_updates: bool = True
    emit_legacy_updates_for_contract_requests: bool = True
