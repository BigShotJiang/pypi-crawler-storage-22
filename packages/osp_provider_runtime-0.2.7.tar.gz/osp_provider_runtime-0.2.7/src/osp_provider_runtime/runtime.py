from __future__ import annotations

import concurrent.futures
import json
from typing import Any

from loguru import logger
from osp_provider_contracts import (
    Provider,
    ProviderError,
    ProviderRequest,
    ProviderResult,
    RequestContext,
)
from osp_provider_contracts.errors import TransientError

from .config import RuntimeConfig
from .envelope import (
    RequestEnvelope,
    ResponseEnvelope,
    dump_response_envelope,
    parse_request_envelope,
)
from .transport import AckAction, Delivery, DeliveryResult
from .updates import TaskReporter


class ProviderRuntime:
    def __init__(self, provider: Provider, config: RuntimeConfig) -> None:
        self.provider = provider
        self.config = config

    def handle_delivery(self, delivery: Delivery) -> DeliveryResult:
        legacy_caps = self._handle_legacy_capabilities_request(delivery)
        if legacy_caps is not None:
            return legacy_caps

        try:
            request_env = parse_request_envelope(delivery.body)
        except Exception:
            logger.exception("Malformed request envelope")
            return DeliveryResult(ack_action=AckAction.DEAD_LETTER)

        if request_env.action == "capabilities":
            return self._handle_contract_capabilities_request(request_env, delivery)

        try:
            result = self._execute_provider(request_env)
            response_env = self._build_success_response(request_env, result)
            response = dump_response_envelope(response_env)
            update_body = self._build_provider_update_success(request_env, result)
            update_event_id = self._extract_update_event_id(update_body)
            logger.info(
                "Processed message",
                message_id=request_env.message_id,
                task_id=request_env.task_id,
                correlation_id=request_env.correlation_id,
                update_event_id=update_event_id,
                attempt=request_env.attempt,
                decision="ack",
            )
            return DeliveryResult(
                ack_action=AckAction.ACK,
                response_body=response,
                response_routing_key=delivery.reply_to,
                response_correlation_id=request_env.correlation_id,
                update_body=update_body,
                update_exchange=self.config.updates_exchange if update_body else None,
                update_routing_key=self.config.updates_routing_key if update_body else None,
            )
        except ProviderError as exc:
            return self._handle_provider_error(request_env, delivery, exc)
        except Exception as exc:  # noqa: BLE001
            transient = TransientError(str(exc), detail="Unhandled runtime exception")
            return self._handle_provider_error(request_env, delivery, transient)

    def _handle_legacy_capabilities_request(self, delivery: Delivery) -> DeliveryResult | None:
        try:
            parsed = json.loads(delivery.body.decode("utf-8"))
        except Exception:
            return None
        if not isinstance(parsed, dict) or parsed.get("op") != "capabilities":
            return None

        payload = self._json_safe(self.provider.capabilities())
        response = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        logger.info(
            "Processed legacy capabilities RPC",
            routing_key=delivery.routing_key,
            decision="ack",
        )
        return DeliveryResult(
            ack_action=AckAction.ACK,
            response_body=response if delivery.reply_to else None,
            response_routing_key=delivery.reply_to,
            response_correlation_id=delivery.correlation_id,
        )

    def _handle_contract_capabilities_request(
        self,
        request_env: RequestEnvelope,
        delivery: Delivery,
    ) -> DeliveryResult:
        payload = self._json_safe(self.provider.capabilities())
        response = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        logger.info(
            "Processed capabilities RPC",
            message_id=request_env.message_id,
            correlation_id=request_env.correlation_id,
            decision="ack",
        )
        return DeliveryResult(
            ack_action=AckAction.ACK,
            response_body=response if delivery.reply_to else None,
            response_routing_key=delivery.reply_to,
            response_correlation_id=delivery.correlation_id or request_env.correlation_id,
        )

    def _execute_provider(self, request_env: RequestEnvelope) -> ProviderResult:
        context = RequestContext(
            task_id=request_env.task_id,
            request_id=request_env.correlation_id,
            idempotency_key=request_env.idempotency_key,
        )
        request = ProviderRequest(
            action=request_env.action,
            resource_kind=request_env.resource_kind,
            payload=request_env.payload,
        )
        timeout = self.config.handler_timeout_seconds
        if timeout is None:
            return self.provider.execute(request_env.action, request, context)

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(self.provider.execute, request_env.action, request, context)
            try:
                return future.result(timeout=timeout)
            except concurrent.futures.TimeoutError as exc:
                raise TransientError(
                    f"Provider execution timed out after {timeout} seconds",
                    detail="handler_timeout",
                    extra={"timeout_seconds": timeout},
                ) from exc

    def _handle_provider_error(
        self,
        request_env: RequestEnvelope,
        delivery: Delivery,
        exc: ProviderError,
    ) -> DeliveryResult:
        attempts_left = request_env.attempt < self.config.max_attempts
        if exc.retryable and attempts_left:
            logger.warning(
                "Retryable provider error; requeueing",
                message_id=request_env.message_id,
                task_id=request_env.task_id,
                attempt=request_env.attempt,
                decision="requeue",
                error_code=exc.code,
            )
            return DeliveryResult(ack_action=AckAction.REQUEUE)

        ack_action = AckAction.DEAD_LETTER if exc.retryable else AckAction.ACK
        decision = "dead_letter" if ack_action == AckAction.DEAD_LETTER else "ack"
        response_env = self._build_error_response(request_env, exc)
        response = dump_response_envelope(response_env)
        update_body = self._build_provider_update_error(request_env, exc)
        update_event_id = self._extract_update_event_id(update_body)
        logger.error(
            "Provider error",
            message_id=request_env.message_id,
            task_id=request_env.task_id,
            correlation_id=request_env.correlation_id,
            update_event_id=update_event_id,
            attempt=request_env.attempt,
            decision=decision,
            error_code=exc.code,
            retryable=exc.retryable,
        )
        return DeliveryResult(
            ack_action=ack_action,
            response_body=response,
            response_routing_key=delivery.reply_to,
            response_correlation_id=request_env.correlation_id,
            update_body=update_body,
            update_exchange=self.config.updates_exchange,
            update_routing_key=self.config.updates_routing_key,
        )

    def _build_success_response(
        self,
        request_env: RequestEnvelope,
        result: ProviderResult,
    ) -> ResponseEnvelope:
        payload: dict[str, Any] = {
            "success": result.success,
            "external_id": result.external_id,
            "message": result.message,
            "data": self._json_safe(dict(result.data)),
        }
        return ResponseEnvelope(
            envelope_version=request_env.envelope_version,
            contract_version=request_env.contract_version,
            message_id=request_env.message_id,
            correlation_id=request_env.correlation_id,
            task_id=request_env.task_id,
            ok=True,
            provider=self.config.provider_name,
            action=request_env.action,
            result=payload,
            error=None,
        )

    def _build_error_response(
        self,
        request_env: RequestEnvelope,
        exc: ProviderError,
    ) -> ResponseEnvelope:
        error = {
            "code": exc.code,
            "detail": exc.detail,
            "retryable": exc.retryable,
            "extra": self._json_safe(exc.extra),
        }
        return ResponseEnvelope(
            envelope_version=request_env.envelope_version,
            contract_version=request_env.contract_version,
            message_id=request_env.message_id,
            correlation_id=request_env.correlation_id,
            task_id=request_env.task_id,
            ok=False,
            provider=self.config.provider_name,
            action=request_env.action,
            result=None,
            error=error,
        )

    def _build_provider_update_success(
        self,
        request_env: RequestEnvelope,
        result: ProviderResult,
    ) -> bytes | None:
        if not self._should_emit_provider_update(request_env):
            return None
        task_id = self._resolve_legacy_update_task_id(request_env)
        if task_id is None:
            return None
        reporter = TaskReporter(task_id=task_id, correlation_id=request_env.correlation_id)
        result_data = self._json_safe(dict(result.data or {}))
        progress_events = None
        if isinstance(result_data, dict):
            maybe_progress = result_data.get("progress_events")
            if isinstance(maybe_progress, list):
                progress_events = maybe_progress
                # Avoid duplicating the same data in both resolved payload and
                # expanded TaskEvent rows.
                result_data = dict(result_data)
                result_data.pop("progress_events", None)
        payload = {
            "requested": self._json_safe(dict(request_env.payload)),
            "resolved": result_data,
            "provenance": {},
            "dry_run": bool(request_env.payload.get("dry_run") or request_env.payload.get("check")),
        }
        if progress_events is not None:
            payload["progress_events"] = progress_events
        return reporter.completed(
            message=result.message or "Completed",
            payload=payload,
        ).to_transport_bytes()

    def _build_provider_update_error(
        self,
        request_env: RequestEnvelope,
        exc: ProviderError,
    ) -> bytes | None:
        if not self._should_emit_provider_update(request_env):
            return None
        task_id = self._resolve_legacy_update_task_id(request_env)
        if task_id is None:
            return None
        reporter = TaskReporter(task_id=task_id, correlation_id=request_env.correlation_id)
        if self._is_approval_required(exc):
            return reporter.require_approval(
                gate_code=int(exc.extra.get("gate_code", 0)),
                importance=int(exc.extra.get("importance", 3)),
                reason=str(exc.extra.get("reason") or "approval_required"),
                details=exc.extra.get("details")
                if isinstance(exc.extra.get("details"), dict)
                else None,
                message=exc.message or "Provider requires approval",
            ).to_transport_bytes()
        return reporter.failed(
            message=exc.message,
            code=exc.code,
            detail=exc.detail,
            retryable=exc.retryable,
            extra=self._json_safe(exc.extra),
        ).to_transport_bytes()

    def _should_emit_provider_update(self, request_env: RequestEnvelope) -> bool:
        if not self.config.emit_legacy_updates:
            return False
        if request_env.source_format == "legacy_orchestrator":
            return True
        return bool(self.config.emit_legacy_updates_for_contract_requests)

    def _resolve_legacy_update_task_id(self, request_env: RequestEnvelope) -> int | None:
        if request_env.legacy_task_id is not None:
            return int(request_env.legacy_task_id)
        try:
            return int(str(request_env.task_id))
        except (TypeError, ValueError):
            pass
        payload_id = request_env.payload.get("id")
        if isinstance(payload_id, int):
            return payload_id
        if isinstance(payload_id, str) and payload_id.isdigit():
            return int(payload_id)
        return None

    def _is_approval_required(self, exc: ProviderError) -> bool:
        if exc.detail != "approval_required":
            return False
        gate_code = exc.extra.get("gate_code")
        return isinstance(gate_code, int) and 400 <= gate_code <= 499

    def _json_safe(self, value: Any) -> Any:
        if value is None or isinstance(value, (str, int, float, bool)):
            return value
        if isinstance(value, dict):
            return {str(k): self._json_safe(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self._json_safe(v) for v in value]
        if isinstance(value, tuple):
            return [self._json_safe(v) for v in value]
        if hasattr(value, "isoformat"):
            try:
                return value.isoformat()
            except Exception:  # noqa: BLE001
                pass
        if hasattr(value, "value") and hasattr(value, "source"):
            return {
                "value": self._json_safe(getattr(value, "value", None)),
                "source": str(getattr(value, "source", "")),
                "context_id": self._json_safe(getattr(value, "context_id", None)),
            }
        return str(value)

    def _extract_update_event_id(self, update_body: bytes | None) -> str | None:
        if update_body is None:
            return None
        try:
            parsed = json.loads(update_body.decode("utf-8"))
        except Exception:  # noqa: BLE001
            return None
        payload = parsed.get("payload")
        if not isinstance(payload, dict):
            return None
        raw = payload.get("event_id")
        if raw is None:
            return None
        value = str(raw).strip()
        return value or None
