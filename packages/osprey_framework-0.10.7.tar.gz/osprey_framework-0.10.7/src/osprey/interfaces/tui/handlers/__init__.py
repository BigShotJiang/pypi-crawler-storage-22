"""TUI Handlers."""

from osprey.interfaces.tui.handlers.log_handler import QueueLogHandler

__all__ = ["QueueLogHandler"]
