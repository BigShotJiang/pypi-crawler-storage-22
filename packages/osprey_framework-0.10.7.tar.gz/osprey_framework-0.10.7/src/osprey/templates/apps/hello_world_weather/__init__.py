"""{{ app_display_name }} Application Package."""
