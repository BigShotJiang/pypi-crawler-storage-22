# otp-toolkit

A lightweight Python utility for generating and verifying OTPs (One-Time Passwords).

## Features
- Secure OTP generation
- Expiry handling
- SHA256 hashing
- Framework independent (works with Django, Flask, FastAPI)

## Installation
```bash
pip install otp-toolkit

## Example

from otp_toolkit import generate_otp, hash_otp, verify_otp

# Step 1: Generate OTP
otp, expires_at = generate_otp(length=6, expires_in=300)
hashed_otp = hash_otp(otp)

# Send `otp` to user via email/SMS (not shown here)

# Step 2: Verify OTP entered by user
user_input = "123456"

if verify_otp(user_input, hashed_otp, expires_at):
    print("Login successful")
else:
    print("Invalid or expired OTP")
