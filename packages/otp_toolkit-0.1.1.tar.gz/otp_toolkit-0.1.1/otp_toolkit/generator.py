import secrets
import string
from datetime import datetime, timedelta

def generate_otp(length: int = 6, expires_in: int = 300):
    """
    Generate a numeric OTP and expiry time.
    """
    otp = ''.join(secrets.choice(string.digits) for _ in range(length))
    expires_at = datetime.utcnow() + timedelta(seconds=expires_in)
    return otp, expires_at
