import hashlib

def hash_otp(otp: str) -> str:
    """
    Hash OTP using SHA256.
    """
    return hashlib.sha256(otp.encode()).hexdigest()
