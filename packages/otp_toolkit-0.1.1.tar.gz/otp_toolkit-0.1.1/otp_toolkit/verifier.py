from datetime import datetime
from .hashing import hash_otp

def verify_otp(user_input: str, hashed_otp: str, expires_at) -> bool:
    """
    Verify OTP against hash and expiry.
    """
    if datetime.utcnow() > expires_at:
        return False

    return hash_otp(user_input) == hashed_otp
