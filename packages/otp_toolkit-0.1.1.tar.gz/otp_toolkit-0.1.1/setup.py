from setuptools import setup, find_packages

classifiers = [
    "Development Status :: 5 - Production/Stable",
    "Intended Audience :: Education",
    "Operating System :: OS Independent",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3",
]

setup(
    name="otp-toolkit",
    version="0.1.1",
    description="Simple OTP generation and verification toolkit",
    long_description=open("README.txt").read() + "\n\n" + open("CHANGELOG.txt").read(),
    long_description_content_type="text/plain",
    url="",
    author="Yawar Hussain",
    author_email="hussainyawar140504@gmail.com",
    license="MIT",
    classifiers=classifiers,
    keywords="otp security authentication python",
    packages=find_packages(),
    install_requires=[],
)
