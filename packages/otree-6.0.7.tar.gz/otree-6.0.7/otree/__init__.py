__version__ = '6.0.7'
# don't import anything else here because setup.py imports this.
