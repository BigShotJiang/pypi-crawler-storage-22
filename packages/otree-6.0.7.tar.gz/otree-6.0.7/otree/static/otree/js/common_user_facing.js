function makeReconnectingWebSocket(path) {
    // https://github.com/pladaria/reconnecting-websocket/issues/91#issuecomment-431244323
    var ws_scheme = window.location.protocol === "https:" ? "wss" : "ws";
    var ws_path = ws_scheme + '://' + window.location.host + path;
    return new ReconnectingWebSocket(ws_path);
}

document.addEventListener('DOMContentLoaded', function () {
    let tabDebugMetaEle = document.querySelector('meta[name="tab-title-debug-info"]');
    let bodyTitle = document.getElementById('_otree-title');
    let bodyTitleText = bodyTitle ? bodyTitle.textContent : '';
    let tabTitle = document.querySelector('title');    

    if (tabDebugMetaEle) {
        tabTitle.textContent += `[${tabDebugMetaEle.content}] ${bodyTitleText} [debug]`;
    } else if (!tabTitle.textContent.trim()) {
        tabTitle.textContent = bodyTitleText;
    }
 
    // block the user from spamming the next button which can make congestion
    // problems worse.
    // i can't use addEventListener on the button itself
    // because disabling the button inside the handler interferes with form
    // submission.
    var form = document.getElementById('form');
    if (form) {
        form.addEventListener('submit', function () {
            document.querySelectorAll('.otree-btn-next').forEach(function (nextButton) {
                var originalState = nextButton.disabled;
                nextButton.disabled = true;
                setTimeout(function () {
                    // restore original state.
                    // it's possible the button was disabled in the first place?
                    nextButton.disabled = originalState;
                }, 5000);
            });
        });
    }
});
