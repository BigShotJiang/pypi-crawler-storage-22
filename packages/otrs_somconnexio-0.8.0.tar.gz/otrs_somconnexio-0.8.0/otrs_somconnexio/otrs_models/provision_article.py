# coding: utf-8
from otrs_somconnexio.otrs_models.abstract_article import AbstractArticle


class ProvisionArticle(AbstractArticle):
    def __init__(self, subject, notes=""):
        self.subject = subject
        self.isVisibleForCustomer = "0" if notes else "1"
        self.body = notes
