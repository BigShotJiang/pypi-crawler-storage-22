class SwitchboardHeaderData:
    service_type = "header_switchboard"

    def __init__(
        self,
        order_id,
        email,
        contact_phone,
        sales_team,
        technology,
        lead_line_data,
        agent_data,
        notes="",
    ):
        self.order_id = order_id
        self.email = email
        self.contact_phone = contact_phone
        self.sales_team = sales_team
        self.technology = technology
        self.lead_line_data = lead_line_data
        self.agent_data = agent_data
        self.notes = notes
