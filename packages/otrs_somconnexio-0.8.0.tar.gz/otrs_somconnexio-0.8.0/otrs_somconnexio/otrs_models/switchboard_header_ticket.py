# coding: utf-8
from tabulate import tabulate
from itertools import groupby
from otrs_somconnexio.otrs_models.provision_ticket import ProvisionTicket
from otrs_somconnexio.otrs_models.switchboard_header_dynamic_fields import (
    SwitchboardHeaderDynamicFields,
)
from otrs_somconnexio.otrs_models.configurations.provision.switchboard_ticket import (
    SwitchboardTicketConfiguration,
)


class SwitchboardHeaderTicket(ProvisionTicket):
    def __init__(self, service_data, customer_data, responsible_data):
        super(SwitchboardHeaderTicket, self).__init__(responsible_data)
        self.service_data = service_data
        self.customer_data = customer_data
        self.otrs_configuration = SwitchboardTicketConfiguration()

    def service_type(self):
        return "switchboard_header"

    def _build_dynamic_fields(self):
        return SwitchboardHeaderDynamicFields(
            self.service_data,
            self.customer_data,
            self._ticket_process_id(),
            self._ticket_activity_id(),
        ).all()

    def _ticket_title(self):
        return "Provisió centraleta virtual (CV) → Capçalera"

    def _files_to_attach(self):
        formatted_agent_data = self._format_agent_data()

        attachments = []

        if formatted_agent_data:
            attachments.append(
                {
                    "Filename": "importació_agents_operator_{}.txt".format(
                        self.service_data.order_id
                    ),
                    "Content": formatted_agent_data,
                }
            )

        return attachments

    def _get_article_notes(self):
        return self._format_lead_line_data()

    def _format_lead_line_data(self):
        """Format lead line data for tsv table attachment."""
        lead_line_data = self.service_data.lead_line_data
        if not lead_line_data:
            return ""

        lead_table_data = list(zip(*lead_line_data.values()))
        headers = lead_line_data.keys()
        lead_lines_table = tabulate(lead_table_data, headers, tablefmt="csv")

        return lead_lines_table

    def _format_agent_data(self):
        """Format agent data for operator import attachment.
        Sorted by product, grouped by product.
        """
        agent_data = self.service_data.agent_data
        if not agent_data:
            return ""

        sorted_agents = sorted(agent_data, key=lambda d: d["product"])

        pin = "2424"
        agents_info = []
        for product, agents in groupby(sorted_agents, key=lambda ag: ag["product"]):
            agents_info.append(f"{product}:")

            for agent in agents:
                agents_info.append(
                    f"{agent['extension']}\t{agent['agent_name']}\t{pin}\t{agent['agent_name']}\t{agent['agent_email']}"  # noqa E501
                )

            agents_info.append("")

        return "\n".join(agents_info)
