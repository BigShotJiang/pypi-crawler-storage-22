# coding: utf-8
import unittest
from mock import patch

from otrs_somconnexio.otrs_models.provision_article import ProvisionArticle


class ProvisionArticleTestCase(unittest.TestCase):
    @patch("otrs_somconnexio.otrs_models.abstract_article.Article")
    def test_call_with_notes(self, MockArticle):
        subject = "test subject"
        notes = "test notes"
        expected_article_arguments = {
            "Subject": subject,
            "Body": notes,
            "ContentType": "text/plain; charset=utf8",
            "IsVisibleForCustomer": "0",
        }
        ProvisionArticle(subject=subject, notes=notes).call()
        MockArticle.assert_called_once_with(expected_article_arguments)

    @patch("otrs_somconnexio.otrs_models.abstract_article.Article")
    def test_call_without_notes(self, MockArticle):
        subject = "test subject"
        expected_article_arguments = {
            "Subject": subject,
            "Body": "",
            "ContentType": "text/plain; charset=utf8",
            "IsVisibleForCustomer": "1",
        }
        ProvisionArticle(subject=subject, notes="").call()
        MockArticle.assert_called_once_with(expected_article_arguments)
