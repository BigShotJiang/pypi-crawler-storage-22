# coding: utf-8
import unittest
from mock import Mock, patch

from otrs_somconnexio.otrs_models.switchboard_header_ticket import (
    SwitchboardHeaderTicket,
)
from otrs_somconnexio.otrs_models.configurations.provision.switchboard_ticket import (
    SwitchboardTicketConfiguration,
)


class SwitchboardHeaderTicketTestCase(unittest.TestCase):
    def setUp(self):
        self.responsible_data = Mock(spec=["email"])

    @patch("otrs_somconnexio.otrs_models.provision_ticket.Ticket")
    def test_build_ticket(self, MockTicket):
        service_data = Mock(spec=["order_id", "notes", "technology"])
        service_data.order_id = 123
        customer_data = Mock(spec=["id"])

        expected_ticket_arguments = {
            "Title": "Provisió centraleta virtual (CV) → Capçalera",
            "Type": SwitchboardTicketConfiguration.type,
            "QueueID": SwitchboardTicketConfiguration.queue_id,
            "State": SwitchboardTicketConfiguration.state,
            "SLA": "No pendent resposta",
            "Service": "Centraleta Virtual",
            "Priority": SwitchboardTicketConfiguration.priority,
            "CustomerUser": customer_data.id,
            "CustomerID": customer_data.id,
            "Responsible": self.responsible_data.email,
        }

        SwitchboardHeaderTicket(
            service_data, customer_data, self.responsible_data
        )._build_ticket()
        MockTicket.assert_called_with(expected_ticket_arguments)

    @patch("otrs_somconnexio.otrs_models.provision_ticket.ProvisionArticle")
    def test_build_article(self, MockProvisionArticle):
        service_data = Mock(spec=["order_id", "technology", "lead_line_data"])
        service_data.order_id = 123
        service_data.lead_line_data = {}
        customer_data = Mock(spec=["order_id"])

        mock_article = MockProvisionArticle.return_value

        ticket = SwitchboardHeaderTicket(
            service_data, customer_data, self.responsible_data
        )
        ticket._build_article()

        MockProvisionArticle.assert_called_with(
            ticket._ticket_title(),
            ticket._format_lead_line_data(),
        )
        mock_article.call.assert_called_once()

    @patch(
        "otrs_somconnexio.otrs_models.switchboard_header_ticket.SwitchboardHeaderDynamicFields"
    )
    def test_build_dynamic_fields(self, MockSwitchboardHeaderDynamicFields):
        service_data = Mock()
        customer_data = Mock()
        mock_dyn_fields = MockSwitchboardHeaderDynamicFields.return_value

        SwitchboardHeaderTicket(
            service_data, customer_data, self.responsible_data
        )._build_dynamic_fields()
        MockSwitchboardHeaderDynamicFields.assert_called_with(
            service_data,
            customer_data,
            SwitchboardTicketConfiguration.process_id,
            SwitchboardTicketConfiguration.activity_id,
        )
        mock_dyn_fields.all.assert_called_once()

    @patch("otrs_somconnexio.otrs_models.provision_ticket.OTRSClient")
    def test_create(self, MockOTRSClient):
        service_data = Mock(
            spec=[
                "order_id",
                "iban",
                "email",
                "contact_phone",
                "product",
                "technology",
                "previous_owner_vat",
                "previous_owner_name",
                "previous_owner_surname",
                "sales_team",
                "agent_data",
                "lead_line_data",
                "type",
                "notes",
            ]
        )
        customer_data = Mock(
            spec=[
                "id",
                "first_name",
                "name",
                "vat_number",
                "street",
                "city",
                "zip",
                "subdivision",
                "has_active_contracts",
                "language",
            ]
        )
        service_data.agent_data = []
        service_data.lead_line_data = {}

        mock_otrs_client = Mock(spec=["create_otrs_process_ticket"])
        mock_otrs_client.create_otrs_process_ticket.return_value = Mock(
            SwitchboardHeaderTicket, autospec=True
        )
        mock_otrs_client.create_otrs_process_ticket.return_value.id = 123
        mock_otrs_client.create_otrs_process_ticket.return_value.number = "#123"
        MockOTRSClient.return_value = mock_otrs_client

        ticket = SwitchboardHeaderTicket(
            service_data, customer_data, self.responsible_data
        )
        ticket.create()

        mock_otrs_client.create_otrs_process_ticket.assert_called_once()
        self.assertEqual(ticket.id, 123)
        self.assertEqual(ticket.number, "#123")

    def test_files_to_attach(self):
        service_data = Mock(spec=["order_id", "agent_data"])
        customer_data = Mock()
        service_data.order_id = 123
        service_data.agent_data = [
            {
                "product": "product1",
                "extension": "ext1",
                "agent_name": "agent1",
                "agent_email": "agent1@test.com",
            },
            {
                "product": "product2",
                "extension": "ext2",
                "agent_name": "agent2",
                "agent_email": "agent2@test.com",
            },
            {
                "product": "product3",
                "extension": "ext3",
                "agent_name": "agent3",
                "agent_email": "agent3@test.com",
            },
        ]

        sb_header_ticket = SwitchboardHeaderTicket(
            service_data, customer_data, self.responsible_data
        )
        files = sb_header_ticket._files_to_attach()

        self.assertEqual(len(files), 1)
        agent_data_file = files[0]
        self.assertEqual(
            agent_data_file["Filename"],
            "importació_agents_operator_{}.txt".format(service_data.order_id),
        )
        self.assertIn("product1:\n", agent_data_file["Content"])
        self.assertIn(
            "ext1\tagent1\t2424\tagent1\tagent1@test.com\n", agent_data_file["Content"]
        )
        self.assertIn("product2:\n", agent_data_file["Content"])
        self.assertIn(
            "ext2\tagent2\t2424\tagent2\tagent2@test.com\n", agent_data_file["Content"]
        )
        self.assertIn("product3:\n", agent_data_file["Content"])
        self.assertIn(
            "ext3\tagent3\t2424\tagent3\tagent3@test.com\n", agent_data_file["Content"]
        )

    def test_format_lead_line_data(self):
        service_data = Mock(spec=["order_id", "lead_line_data"])
        customer_data = Mock()
        service_data.order_id = 123
        service_data.lead_line_data = {
            "Prod": ["product1", "product2", "product3"],
            "Ext": ["ext1", "ext2", "ext3"],
            "Nom": ["agent1", "agent2", "agent3"],
            "Telf": ["111", "222", "333"],
            "Tipus": ["tipus1", "tipus2", "tipus3"],
        }

        sb_header_ticket = SwitchboardHeaderTicket(
            service_data, customer_data, self.responsible_data
        )
        lead_line_table = sb_header_ticket._format_lead_line_data()

        for header in service_data.lead_line_data.keys():
            self.assertIn(header, lead_line_table)
        self.assertEqual(
            lead_line_table.count("\n"),
            len(service_data.lead_line_data["Prod"]) + 1,
        )  # headers + number of rows
