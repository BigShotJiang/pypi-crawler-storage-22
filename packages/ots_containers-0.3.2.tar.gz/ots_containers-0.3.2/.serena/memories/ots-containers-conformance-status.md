# ots-containers Conformance Status

**Reviewed**: 2025-12-15 (Updated)

## Current State

FHS-compliant architecture. SQLite deployment tracking. Production-ready quadlet template.

### Compliant

| Area | Status | Implementation |
|------|--------|----------------|
| Quadlet location | ✓ | `/etc/containers/systemd/onetime@.container` |
| Template pattern | ✓ | Port-parametrized `onetime@{port}` |
| Unit dependencies | ✓ | `After=local-fs.target network-online.target` |
| FHS paths | ✓ | `config_dir=/etc/onetimesecret/`, `var_dir=/var/lib/onetimesecret/` |
| Config separation | ✓ | config.yaml + .env template in /etc, runtime .env-{port} in /var/lib |
| Deployment tracking | ✓ | SQLite database at `/var/lib/onetimesecret/deployments.db` |
| Image aliases | ✓ | CURRENT/ROLLBACK resolved from database, not env vars |
| Idempotent setup | ✓ | `ots-containers init` command |
| Restart policy | ✓ | `Restart=on-failure`, `RestartSec=5` in [Service] |
| Health check | ✓ | `HealthCmd`, `HealthInterval=30s`, `HealthRetries=3` |
| Container naming | ✓ | Uses `systemd-onetime_{port}` (underscore, not @) |

### Non-Compliant (Lower Priority)

| Priority | Gap | Current | Required |
|----------|-----|---------|----------|
| MEDIUM | Resource limits | None | `PodmanArgs=--memory=1g --cpus=2` |
| LOW | Secrets | In .env files | Consider `podman secret` for sensitive values |

### Acceptable (Documented Decisions)

- **Host networking**: Performance trade-off, appropriate for dedicated instances
- **Port-based identification**: Each instance on specific port (e.g., 7043, 7044)

## Architecture

```
/etc/onetimesecret/           # System configuration (read-only at runtime)
├── config.yaml               # Application config
├── .env                      # Environment template
└── Caddyfile.template        # Proxy config template

/var/lib/onetimesecret/       # Variable runtime data
├── .env-7043                 # Instance-specific env (port 7043)
├── .env-7044                 # Instance-specific env (port 7044)
└── deployments.db            # SQLite audit trail + image aliases

/etc/containers/systemd/      # Quadlet units
└── onetime@.container        # Parametrized template

/etc/caddy/                   # Caddy config (rendered)
└── Caddyfile
```

## Naming Convention

- **Systemd unit**: `onetime@7043.service`
- **Podman container**: `systemd-onetime_7043` (underscore replaces @)

## Commands

- `ots-containers init` - Idempotent directory/database setup
- `ots-containers image pull/list/set-current/rollback/history/aliases`
- `ots-containers instance deploy/start/stop/restart/status/logs/exec`
- `ots-containers proxy render/reload` - Caddy config management
