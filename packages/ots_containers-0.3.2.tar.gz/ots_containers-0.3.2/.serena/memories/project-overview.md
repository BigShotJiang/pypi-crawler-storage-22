# ots-containers Project Overview

Dual-purpose CLI for OneTimeSecret infrastructure: manages containerized OTS via Podman Quadlets (systemd) and native systemd services for deps (Valkey, Redis).

## Tech Stack
- Python 3.11+, cyclopts (CLI), podman bindings, pyyaml
- Build: Hatchling (PEP 517). Entry point: `ots-containers` → `ots_containers.cli:app`
- Dev: ruff, pyright, pre-commit. Test: pytest (70% coverage minimum)

## Package Layout (`src/ots_containers/`)

| Module | Role |
|--------|------|
| `cli.py` | Entry point, subcommand registration, `version` command |
| `config.py` | `Config` dataclass, env var resolution, image references |
| `quadlet.py` | Systemd Quadlet template generation |
| `systemd.py` | systemctl wrappers, instance auto-discovery |
| `podman.py` | Chainable podman CLI interface |
| `db.py` | SQLite deployment timeline, image aliases (CURRENT/ROLLBACK) |
| `environment_file.py` | `/etc/default/onetimesecret` processing, Podman secrets |
| `assets.py` | Static asset extraction from container images |

## Command Groups
- `instance` - Container lifecycle (deploy/redeploy/undeploy/start/stop/restart/status/logs)
- `image` - Image pull/push/build/rollback/list/prune
- `service` - Native systemd services (init/start/stop/restart/status)
- `proxy` - Caddy reverse proxy config
- `cloudinit` - Cloud-init generation with apt repo templates
- `env` - Environment file and secrets processing
- `init` - Setup wizard

## Key Patterns
- **Port-based instances**: `onetime-web@7043.service`, `onetime-worker@billing`
- **FHS paths**: `/etc/onetimesecret/`, `/var/lib/onetimesecret/`, `/etc/containers/systemd/`
- **Copy-on-write config**: Package defaults → instance configs
- **SQLite tracking**: Deployment audit trail, image alias resolution
- **Auto-discovery**: `systemd.discover_{web,worker,scheduler}_instances()` via systemctl

## Version Management
Single source of truth in `pyproject.toml` (`version = "0.3.1"`).
Runtime: `importlib.metadata.version("ots-containers")` → `__init__.__version__` → cyclopts App.
No duplication. Version command and `--version` flag both read from this chain.

Note: `commands/image/app.py` reads the *target project's* `package.json` version for container builds — separate from this package's version.
