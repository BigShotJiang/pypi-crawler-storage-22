"""
Otto - Agent abstraction and orchestration layer.

Provides backend abstraction for multiple agent CLIs (Claude, Codex)
and sub-agent orchestration for parallel task execution.

Usage:
    from otto import get_backend, get_orchestrator, SpawnRequest

    # Use a backend directly
    backend = get_backend()  # Gets active backend from config
    result = await backend.run_async(prompt, system_prompt, cwd)

    # Spawn sub-agents
    orchestrator = get_orchestrator()
    agent_id = await orchestrator.spawn(SpawnRequest(
        prompt="...",
        system_prompt="...",
        task_description="Process data"
    ))
    result = await orchestrator.wait_for(agent_id)
"""

from .backends import (
    DEFAULT_PERMISSION_MODE,
    AgentBackend,
    AgentConfig,
    AgentResult,
    ClaudeBackend,
    CodexBackend,
    OutputFormat,
    PermissionMode,
    get_active_backend_name,
    get_backend,
    get_orchestration_config,
    list_backends,
    reload_config,
    set_active_backend,
)
from .memory import (
    clear_index as memory_clear,
)
from .memory import (
    get_stats as memory_stats,
)
from .memory import (
    index_all as index_memory,
)
from .memory import (
    index_file,
)
from .memory import (
    search as memory_search,
)
from .memory import (
    search_formatted as memory_search_formatted,
)
from .orchestrator import (
    Orchestrator,
    SpawnRequest,
    SubAgent,
    get_orchestrator,
)
from .sessions import (
    add_message,
    archive_session,
    delete_session,
    get_current_session,
    get_messages,
    get_session_for_prompt,
    list_sessions,
    load_session,
    maybe_auto_title,
    migrate_from_conversation_json,
    new_session,
    update_session_topic,
)

__all__ = [
    # Backend classes
    "AgentBackend",
    "AgentConfig",
    "AgentResult",
    "ClaudeBackend",
    "CodexBackend",
    # Backend types
    "PermissionMode",
    "OutputFormat",
    "DEFAULT_PERMISSION_MODE",
    # Backend functions
    "get_backend",
    "list_backends",
    "reload_config",
    "get_active_backend_name",
    "set_active_backend",
    "get_orchestration_config",
    # Orchestrator
    "Orchestrator",
    "SpawnRequest",
    "SubAgent",
    "get_orchestrator",
    # Sessions
    "get_current_session",
    "new_session",
    "add_message",
    "get_messages",
    "archive_session",
    "delete_session",
    "list_sessions",
    "load_session",
    "get_session_for_prompt",
    "migrate_from_conversation_json",
    "update_session_topic",
    "maybe_auto_title",
    # Memory
    "index_file",
    "index_memory",
    "memory_search",
    "memory_search_formatted",
    "memory_stats",
    "memory_clear",
]
