#!/usr/bin/env python3
"""
Otto Audit Logging System

Comprehensive logging with configurable privacy levels:
- off: No audit logging (not recommended)
- on: Basic logging - events only, no message content (default)
- verbose: Full logging including truncated message content
- debug: Full logging with extended content + timing data

Logs are stored in JSONL format for easy querying and future analysis.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

from otto.paths import CONFIG_DIR, DATA_DIR, LOGS_DIR, ensure_dirs

# Log levels (ascending verbosity)
LogLevel = Literal["off", "on", "verbose", "debug"]
LOG_LEVELS = {"off": 0, "on": 1, "verbose": 2, "debug": 3}

# Audit log types
AuditType = Literal[
    "message",  # User/assistant messages
    "action",  # Commands, backend switches, etc.
    "security",  # Auth events, access control
    "agent",  # Sub-agent operations
    "error",  # Errors and exceptions
    "system",  # System events (startup, shutdown, etc.)
]

# Lock for thread-safe writes
_write_lock = threading.Lock()

# Cache for log level to avoid repeated file reads
_log_level_cache: dict[str, tuple[float, LogLevel]] = {}
_CACHE_TTL = 30  # seconds

# ---------------------------------------------------------------------------
# SQLite audit database (queryable, alongside JSONL)
# ---------------------------------------------------------------------------

_AUDIT_DB_PATH: Path | None = None
_db_conn: sqlite3.Connection | None = None
_db_lock = threading.Lock()

_CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS audit_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp   TEXT    NOT NULL,
    type        TEXT    NOT NULL,
    event       TEXT    NOT NULL,
    success     INTEGER NOT NULL DEFAULT 1,
    user_id     TEXT,
    username    TEXT,
    backend     TEXT,
    session_id  TEXT,
    server      TEXT,
    tool        TEXT,
    verdict     TEXT,
    error       TEXT,
    data_json   TEXT,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_type ON audit_log(type);
CREATE INDEX IF NOT EXISTS idx_audit_server_tool ON audit_log(server, tool);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_verdict ON audit_log(verdict);
"""


def _get_db() -> sqlite3.Connection:
    """Get or create the audit SQLite database connection."""
    global _db_conn, _AUDIT_DB_PATH

    if _db_conn is not None:
        return _db_conn

    ensure_dirs()
    _AUDIT_DB_PATH = DATA_DIR / "audit.db"
    _db_conn = sqlite3.connect(str(_AUDIT_DB_PATH), check_same_thread=False)
    _db_conn.execute("PRAGMA journal_mode=WAL")
    _db_conn.execute("PRAGMA busy_timeout=5000")
    _db_conn.executescript(_CREATE_TABLE_SQL)
    _db_conn.row_factory = sqlite3.Row
    return _db_conn


def _write_db(entry: dict) -> None:
    """Write an audit entry to the SQLite database."""
    try:
        with _db_lock:
            db = _get_db()
            db.execute(
                """INSERT INTO audit_log
                   (timestamp, type, event, success, user_id, username,
                    backend, session_id, server, tool, verdict, error, data_json)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    entry.get("timestamp", datetime.now().isoformat()),
                    entry.get("type", ""),
                    entry.get("event", ""),
                    1 if entry.get("success", True) else 0,
                    str(entry["user_id"]) if entry.get("user_id") is not None else None,
                    entry.get("username"),
                    entry.get("backend"),
                    entry.get("session_id"),
                    entry.get("server"),
                    entry.get("tool"),
                    entry.get("verdict"),
                    entry.get("error"),
                    json.dumps(entry.get("data"), default=str) if entry.get("data") else None,
                ),
            )
            db.commit()
    except Exception:
        pass  # Never let audit DB errors break the app


def close_db() -> None:
    """Close the audit database (call on shutdown)."""
    global _db_conn
    with _db_lock:
        if _db_conn is not None:
            _db_conn.close()
            _db_conn = None


def _get_log_level() -> LogLevel:
    """Get the current log level from config (with caching)."""
    import yaml

    cache_key = "log_level"
    now = time.time()

    if cache_key in _log_level_cache:
        cached_time, cached_level = _log_level_cache[cache_key]
        if now - cached_time < _CACHE_TTL:
            return cached_level

    settings_file = CONFIG_DIR / "settings.yaml"
    level: LogLevel = "on"  # default

    if settings_file.exists():
        try:
            with open(settings_file) as f:
                settings = yaml.safe_load(f) or {}
            level = settings.get("logging", {}).get("level", "on")
            if level not in LOG_LEVELS:
                level = "on"
        except Exception:
            level = "on"

    _log_level_cache[cache_key] = (now, level)
    return level


def _should_log(required_level: LogLevel) -> bool:
    """Check if we should log at the given level."""
    current = _get_log_level()
    return LOG_LEVELS[current] >= LOG_LEVELS[required_level]


def _get_audit_file() -> Path:
    """Get the current audit log file (daily rotation)."""
    ensure_dirs()
    date_str = datetime.now().strftime("%Y-%m-%d")
    return LOGS_DIR / f"audit-{date_str}.jsonl"


def _write_entry(entry: dict) -> None:
    """Write an entry to JSONL audit log AND SQLite database (thread-safe)."""
    if _get_log_level() == "off":
        return

    with _write_lock:
        audit_file = _get_audit_file()
        with open(audit_file, "a") as f:
            f.write(json.dumps(entry, default=str) + "\n")

    # Also write to SQLite for queryable access
    _write_db(entry)


def log(
    audit_type: AuditType,
    event: str,
    *,
    user_id: int | str | None = None,
    username: str | None = None,
    backend: str | None = None,
    session_id: str | None = None,
    data: dict[str, Any] | None = None,
    success: bool = True,
    error: str | None = None,
    level: LogLevel = "on",
) -> None:
    """
    Write an audit log entry.

    Args:
        audit_type: Category of the event
        event: Short description of what happened
        user_id: Telegram user ID (if applicable)
        username: Telegram username (if applicable)
        backend: Backend used (claude, codex)
        session_id: Session ID (if applicable)
        data: Additional structured data
        success: Whether the operation succeeded
        error: Error message (if failed)
        level: Minimum log level required to write this entry
    """
    if not _should_log(level):
        return

    entry = {
        "timestamp": datetime.now().isoformat(),
        "type": audit_type,
        "event": event,
        "success": success,
    }

    if user_id is not None:
        entry["user_id"] = user_id
    if username:
        entry["username"] = username
    if backend:
        entry["backend"] = backend
    if session_id:
        entry["session_id"] = session_id
    if data:
        entry["data"] = data
    if error:
        entry["error"] = error

    _write_entry(entry)


# Convenience functions for common audit events


def log_message(
    role: Literal["user", "assistant", "system"],
    content: str,
    *,
    user_id: int | str | None = None,
    username: str | None = None,
    backend: str | None = None,
    session_id: str | None = None,
) -> None:
    """
    Log a message (user input or assistant response).

    Privacy levels:
    - on: logs event with content_length only (no content)
    - verbose: includes truncated content (500 chars)
    - debug: includes extended content (2000 chars)
    """
    current_level = _get_log_level()
    if current_level == "off":
        return

    data: dict[str, Any] = {
        "role": role,
        "content_length": len(content),
    }

    # Only include content at verbose or higher
    if current_level == "verbose":
        truncate_at = 500
        data["content"] = content[:truncate_at] + ("..." if len(content) > truncate_at else "")
    elif current_level == "debug":
        truncate_at = 2000
        data["content"] = content[:truncate_at] + ("..." if len(content) > truncate_at else "")

    log(
        "message",
        f"{role}_message",
        user_id=user_id,
        username=username,
        backend=backend,
        session_id=session_id,
        data=data,
        level="on",
    )


def log_action(
    action: str,
    *,
    user_id: int | str | None = None,
    username: str | None = None,
    data: dict[str, Any] | None = None,
    success: bool = True,
    error: str | None = None,
) -> None:
    """Log a user action (command, button press, etc.)."""
    log(
        "action",
        action,
        user_id=user_id,
        username=username,
        data=data,
        success=success,
        error=error,
        level="on",
    )


def log_backend_switch(
    old_backend: str | None,
    new_backend: str,
    *,
    user_id: int | str | None = None,
    username: str | None = None,
) -> None:
    """Log a backend switch event."""
    log(
        "action",
        "backend_switch",
        user_id=user_id,
        username=username,
        backend=new_backend,
        data={"old_backend": old_backend, "new_backend": new_backend},
        level="on",
    )


def log_security(
    event: str,
    *,
    user_id: int | str | None = None,
    username: str | None = None,
    success: bool = True,
    data: dict[str, Any] | None = None,
) -> None:
    """Log a security event (auth attempt, access control). Always logged at 'on' level."""
    log(
        "security",
        event,
        user_id=user_id,
        username=username,
        success=success,
        data=data,
        level="on",
    )


def log_agent(
    event: str,
    agent_id: str,
    *,
    backend: str | None = None,
    task: str | None = None,
    success: bool = True,
    error: str | None = None,
    data: dict[str, Any] | None = None,
) -> None:
    """Log an agent operation (spawn, complete, error)."""
    current_level = _get_log_level()
    agent_data = {"agent_id": agent_id}

    # Only include task content at verbose+
    if task and current_level in ("verbose", "debug"):
        truncate_at = 200 if current_level == "verbose" else 500
        agent_data["task"] = task[:truncate_at] + ("..." if len(task) > truncate_at else "")
    elif task:
        agent_data["task_length"] = len(task)

    if data:
        agent_data.update(data)

    log(
        "agent",
        event,
        backend=backend,
        data=agent_data,
        success=success,
        error=error,
        level="on",
    )


def log_error(
    event: str,
    error: str,
    *,
    data: dict[str, Any] | None = None,
) -> None:
    """Log an error event. Always logged at 'on' level."""
    log(
        "error",
        event,
        error=error,
        success=False,
        data=data,
        level="on",
    )


def log_system(
    event: str,
    *,
    data: dict[str, Any] | None = None,
) -> None:
    """Log a system event (startup, shutdown, etc.)."""
    log(
        "system",
        event,
        data=data,
        level="on",
    )


def log_backend_execution(
    backend: str,
    *,
    user_id: int | str | None = None,
    username: str | None = None,
    session_id: str | None = None,
    prompt_length: int | None = None,
    response_length: int | None = None,
    duration_ms: int | None = None,
    success: bool = True,
    error: str | None = None,
) -> None:
    """Log backend execution (which backend actually processed the request)."""
    data: dict[str, Any] = {}
    if prompt_length is not None:
        data["prompt_length"] = prompt_length
    if response_length is not None:
        data["response_length"] = response_length
    if duration_ms is not None:
        data["duration_ms"] = duration_ms

    log(
        "action",
        "backend_execution",
        user_id=user_id,
        username=username,
        backend=backend,
        session_id=session_id,
        data=data if data else None,
        success=success,
        error=error,
        level="on",
    )


def log_media(
    media_type: Literal["photo", "voice", "document", "video"],
    *,
    user_id: int | str | None = None,
    username: str | None = None,
    file_path: str | None = None,
    file_size: int | None = None,
    duration: int | None = None,
) -> None:
    """Log media handling (photo, voice, document uploads)."""
    current_level = _get_log_level()
    data: dict[str, Any] = {"media_type": media_type}

    if file_size is not None:
        data["file_size"] = file_size
    if duration is not None:
        data["duration"] = duration

    # Only include file path at verbose+
    if file_path and current_level in ("verbose", "debug"):
        data["file_path"] = file_path

    log(
        "action",
        f"media_{media_type}",
        user_id=user_id,
        username=username,
        data=data,
        level="on",
    )


def log_session(
    event: Literal["new", "switch", "list"],
    session_id: str | None = None,
    *,
    user_id: int | str | None = None,
    username: str | None = None,
    data: dict[str, Any] | None = None,
) -> None:
    """Log session operations."""
    log(
        "action",
        f"session_{event}",
        user_id=user_id,
        username=username,
        session_id=session_id,
        data=data,
        level="on",
    )


def log_command(
    command: str,
    *,
    user_id: int | str | None = None,
    username: str | None = None,
    args: str | None = None,
) -> None:
    """Log command usage."""
    current_level = _get_log_level()
    data: dict[str, Any] = {"command": command}

    # Only include args at verbose+
    if args and current_level in ("verbose", "debug"):
        data["args"] = args[:200] if len(args) > 200 else args
    elif args:
        data["args_length"] = len(args)

    log(
        "action",
        "command",
        user_id=user_id,
        username=username,
        data=data,
        level="on",
    )


def log_debug(
    event: str,
    *,
    data: dict[str, Any] | None = None,
) -> None:
    """Log debug information (only at debug level)."""
    log(
        "system",
        event,
        data=data,
        level="debug",
    )


def log_tool_call(
    server: str,
    tool: str,
    verdict: str,
    *,
    backend: str | None = None,
    success: bool = True,
    error: str | None = None,
    arguments: dict[str, Any] | None = None,
    dry_run: bool = False,
) -> None:
    """
    Log a gateway tool call with full server/tool/verdict info.

    This writes to the SQLite audit DB with dedicated columns for
    efficient querying (server, tool, verdict).
    """
    current_level = _get_log_level()
    if current_level == "off":
        return

    data: dict[str, Any] = {}
    if dry_run:
        data["dry_run"] = True

    # Only include arguments at verbose+ (may contain secrets)
    if arguments and current_level in ("verbose", "debug"):
        truncated = json.dumps(arguments, default=str)
        max_len = 500 if current_level == "verbose" else 2000
        data["arguments"] = truncated[:max_len]

    entry = {
        "timestamp": datetime.now().isoformat(),
        "type": "security",
        "event": "tool_call",
        "success": success,
        "backend": backend,
        "server": server,
        "tool": tool,
        "verdict": verdict,
        "data": data if data else None,
    }
    if error:
        entry["error"] = error

    _write_entry(entry)

    # Hook: anomaly detection (non-blocking, never fails the audit)
    try:
        from otto.observability import on_tool_call as _obs_hook

        _obs_hook(server, tool, verdict, success)
    except Exception:
        pass  # Observability must never break auditing


# Query functions


def get_recent_logs(
    audit_type: AuditType | None = None,
    limit: int = 50,
    since: datetime | None = None,
) -> list[dict]:
    """
    Get recent audit log entries.

    Args:
        audit_type: Filter by type (optional)
        limit: Maximum entries to return
        since: Only entries after this time (optional)

    Returns:
        List of log entries (newest first)
    """
    ensure_dirs()

    entries = []

    # Get all audit files, sorted newest first
    audit_files = sorted(LOGS_DIR.glob("audit-*.jsonl"), reverse=True)

    for audit_file in audit_files:
        try:
            with open(audit_file) as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())

                        # Filter by type
                        if audit_type and entry.get("type") != audit_type:
                            continue

                        # Filter by time
                        if since:
                            entry_time = datetime.fromisoformat(entry["timestamp"])
                            if entry_time < since:
                                continue

                        entries.append(entry)
                    except json.JSONDecodeError:
                        continue
        except Exception:
            continue

        # Check if we have enough
        if len(entries) >= limit * 2:  # Get extra for sorting
            break

    # Sort by timestamp (newest first) and limit
    entries.sort(key=lambda e: e.get("timestamp", ""), reverse=True)
    return entries[:limit]


def get_message_history(
    user_id: int | str | None = None,
    limit: int = 20,
) -> list[dict]:
    """Get message history for a user."""
    entries = get_recent_logs(audit_type="message", limit=limit * 2)

    if user_id:
        entries = [e for e in entries if e.get("user_id") == user_id]

    return entries[:limit]


def get_security_events(
    limit: int = 50,
    failed_only: bool = False,
) -> list[dict]:
    """Get security events."""
    entries = get_recent_logs(audit_type="security", limit=limit * 2)

    if failed_only:
        entries = [e for e in entries if not e.get("success", True)]

    return entries[:limit]


def get_log_level() -> LogLevel:
    """Public accessor for current log level."""
    return _get_log_level()


# ---------------------------------------------------------------------------
# SQLite query functions  (``otto audit list`` / ``otto audit search``)
# ---------------------------------------------------------------------------


def query_audit(
    *,
    audit_type: str | None = None,
    server: str | None = None,
    tool: str | None = None,
    verdict: str | None = None,
    success: bool | None = None,
    user_id: str | None = None,
    since: str | None = None,
    until: str | None = None,
    search: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[dict]:
    """
    Query the SQLite audit log with flexible filters.

    Args:
        audit_type: Filter by type (message, action, security, agent, error, system)
        server: Filter by MCP server name
        tool: Filter by tool name
        verdict: Filter by verdict (allow, deny, prompt)
        success: Filter by success/failure
        user_id: Filter by user ID
        since: ISO timestamp lower bound
        until: ISO timestamp upper bound
        search: Full-text search across event, error, data_json
        limit: Max results (default 50)
        offset: Skip first N results

    Returns:
        List of audit entries as dicts (newest first)
    """
    try:
        with _db_lock:
            db = _get_db()
            conditions: list[str] = []
            params: list[Any] = []

            if audit_type:
                conditions.append("type = ?")
                params.append(audit_type)
            if server:
                conditions.append("server = ?")
                params.append(server)
            if tool:
                conditions.append("tool = ?")
                params.append(tool)
            if verdict:
                conditions.append("verdict = ?")
                params.append(verdict)
            if success is not None:
                conditions.append("success = ?")
                params.append(1 if success else 0)
            if user_id:
                conditions.append("user_id = ?")
                params.append(str(user_id))
            if since:
                conditions.append("timestamp >= ?")
                params.append(since)
            if until:
                conditions.append("timestamp <= ?")
                params.append(until)
            if search:
                conditions.append(
                    "(event LIKE ? OR error LIKE ? OR data_json LIKE ? OR server LIKE ? OR tool LIKE ?)"
                )
                pattern = f"%{search}%"
                params.extend([pattern, pattern, pattern, pattern, pattern])

            where = (" WHERE " + " AND ".join(conditions)) if conditions else ""
            sql = f"SELECT * FROM audit_log{where} ORDER BY id DESC LIMIT ? OFFSET ?"
            params.extend([limit, offset])

            cursor = db.execute(sql, params)
            return [dict(row) for row in cursor.fetchall()]
    except Exception:
        return []


def count_audit(
    *,
    audit_type: str | None = None,
    server: str | None = None,
    verdict: str | None = None,
    since: str | None = None,
) -> int:
    """Count audit entries matching filters."""
    try:
        with _db_lock:
            db = _get_db()
            conditions: list[str] = []
            params: list[Any] = []

            if audit_type:
                conditions.append("type = ?")
                params.append(audit_type)
            if server:
                conditions.append("server = ?")
                params.append(server)
            if verdict:
                conditions.append("verdict = ?")
                params.append(verdict)
            if since:
                conditions.append("timestamp >= ?")
                params.append(since)

            where = (" WHERE " + " AND ".join(conditions)) if conditions else ""
            sql = f"SELECT COUNT(*) FROM audit_log{where}"

            cursor = db.execute(sql, params)
            return cursor.fetchone()[0]
    except Exception:
        return 0


def audit_stats(since: str | None = None) -> dict[str, Any]:
    """
    Get audit statistics summary.

    Returns:
        Dict with total_calls, by_verdict, by_server, by_type counts.
    """
    try:
        with _db_lock:
            db = _get_db()
            time_filter = ""
            params: list[Any] = []
            if since:
                time_filter = " WHERE timestamp >= ?"
                params = [since]

            total = db.execute(f"SELECT COUNT(*) FROM audit_log{time_filter}", params).fetchone()[0]

            by_verdict = {}
            for row in db.execute(
                f"SELECT verdict, COUNT(*) as cnt FROM audit_log{time_filter} GROUP BY verdict",
                params,
            ):
                by_verdict[row[0] or "none"] = row[1]

            by_server = {}
            for row in db.execute(
                f"SELECT server, COUNT(*) as cnt FROM audit_log"
                f"{time_filter}{' AND' if time_filter else ' WHERE'} server IS NOT NULL "
                f"GROUP BY server ORDER BY cnt DESC LIMIT 10",
                params,
            ):
                by_server[row[0]] = row[1]

            by_type = {}
            for row in db.execute(
                f"SELECT type, COUNT(*) as cnt FROM audit_log{time_filter} GROUP BY type",
                params,
            ):
                by_type[row[0]] = row[1]

            denials = db.execute(
                f"SELECT COUNT(*) FROM audit_log{time_filter}"
                f"{' AND' if time_filter else ' WHERE'} verdict = 'deny'",
                params,
            ).fetchone()[0]

            return {
                "total": total,
                "denials": denials,
                "by_verdict": by_verdict,
                "by_server": by_server,
                "by_type": by_type,
            }
    except Exception:
        return {"total": 0, "denials": 0, "by_verdict": {}, "by_server": {}, "by_type": {}}


# CLI-friendly output


def format_entry(entry: dict) -> str:
    """Format a single entry for display."""
    ts = entry.get("timestamp", "")[:19]  # Trim microseconds
    audit_type = entry.get("type", "?")
    event = entry.get("event", "?")

    # Handle both bool and int (SQLite returns 0/1)
    success_val = entry.get("success", True)
    if isinstance(success_val, int):
        success_val = bool(success_val)
    success = "✓" if success_val else "✗"

    user = entry.get("username") or entry.get("user_id") or ""
    if user:
        user = f" [{user}]"

    backend = entry.get("backend") or ""
    if backend:
        backend = f" ({backend})"

    # Include server.tool info for gateway entries
    server = entry.get("server") or ""
    tool = entry.get("tool") or ""
    tool_info = ""
    if server and tool:
        verdict = entry.get("verdict") or ""
        verdict_icon = {"allow": "✅", "deny": "🚫", "prompt": "❓"}.get(verdict, "")
        tool_info = f" {verdict_icon}{server}.{tool}"
    elif server:
        tool_info = f" {server}"

    error = entry.get("error") or ""
    if error:
        error = f" err={error[:60]}"

    return f"{ts} {success} {audit_type}/{event}{tool_info}{user}{backend}{error}"


def format_logs(entries: list[dict]) -> str:
    """Format multiple entries for display."""
    return "\n".join(format_entry(e) for e in entries)
