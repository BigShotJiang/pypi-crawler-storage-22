"""
Backend registry and configuration loader.

Provides get_backend() to obtain a configured backend instance,
list_backends() to see available backends, set_active_backend() to
switch backends, and reload_config() to refresh from settings.

All configuration is read/written via otto.config (settings.yaml).
"""

from pathlib import Path

from .base import AgentBackend, AgentConfig, AgentResult
from .claude_sdk import ClaudeSDKBackend as ClaudeBackend
from .codex import CodexBackend
from .generic import GenericBackend
from .types import DEFAULT_PERMISSION_MODE, OutputFormat, PermissionMode

# Backend implementations registry
_BACKEND_CLASSES = {
    "claude": ClaudeBackend,
    "codex": CodexBackend,
    "generic": GenericBackend,
}

# Known models per backend (static list, user can override with any value)
# These are shown in UI for convenience, but any model string is accepted
BACKEND_MODELS = {
    "claude": [
        "claude-sonnet-4-5",
        "claude-opus-4-5",
        "claude-haiku-4-5",
        "sonnet",
        "opus",
        "haiku",
    ],
    "codex": [
        "gpt-5.2-codex",
        "gpt-5.1-codex-max",
        "gpt-5.1-codex",
        "o3",
    ],
    "generic": [
        # OpenRouter
        "openrouter/meta-llama/llama-3.3-70b-instruct",
        "openrouter/anthropic/claude-sonnet-4",
        "openrouter/google/gemini-2.0-flash",
        # Ollama
        "ollama/qwen2.5-coder",
        "ollama/llama3.2",
        # Gemini
        "gemini/gemini-2.0-flash",
        # OpenAI
        "gpt-4o",
        "gpt-4o-mini",
    ],
}

# Cached backend instances
_backends_cache: dict[str, AgentBackend] = {}


def _get_default_config() -> dict:
    """Return default agent configuration."""
    return {
        "active": "claude",
        "backends": {
            "claude": {
                "enabled": True,
                "model": None,
                "sdk_options": {
                    "permission_mode": "bypassPermissions",
                    "max_turns": None,
                    "allowed_tools": None,
                },
            },
            "codex": {
                "enabled": False,
                "path": "~/.nvm/versions/node/v22.22.0/bin/codex",
                "model": "gpt-5.1-codex",
                "sdk_options": {
                    "reuse_session": True,
                    "connection_timeout": 120,
                    "approval_policy": "never",
                    "sandbox_policy": "danger-full-access",
                },
            },
            "generic": {
                "enabled": False,
                "model": "openrouter/meta-llama/llama-3.3-70b-instruct",
                "sdk_options": {
                    "max_turns": 50,
                    "timeout": 300,
                    "api_base": None,
                    "api_key_env": "OPENROUTER_API_KEY",
                    "include_mcp_tools": True,
                    "safeguards": {
                        "enabled": True,
                        "protected_paths": [],
                        "blocked_patterns": [],
                    },
                },
            },
        },
        "orchestration": {
            "max_parallel": 5,
            "worker_concurrency": 4,
            "default_timeout": 3600,
            "pipeline_notify_grace_seconds": 8,
        },
    }


def reload_config() -> None:
    """Reload configuration from settings.yaml and clear caches."""
    global _backends_cache
    from .. import config as otto_config

    otto_config.reload()
    _backends_cache = {}  # Clear cached backend instances


def _get_agent_config() -> dict:
    """Get the agent configuration section from settings.yaml."""
    from .. import config as otto_config

    defaults = _get_default_config()
    agent_config = otto_config.get_setting("agent", {})

    # Deep merge with defaults
    if not agent_config:
        return defaults

    # Ensure backends exist and merge with defaults
    # This ensures new backends are available even if
    # the user's settings.yaml was created before they were added
    if "backends" not in agent_config:
        agent_config["backends"] = defaults["backends"]
    else:
        # Merge: user config takes precedence, but include new default backends
        merged_backends = dict(defaults["backends"])
        merged_backends.update(agent_config["backends"])
        agent_config["backends"] = merged_backends

    return agent_config


def get_backend(name: str | None = None) -> AgentBackend:
    """
    Get a backend instance by name.

    Args:
        name: Backend name. If None, uses the active backend from config.

    Returns:
        AgentBackend instance.

    Raises:
        ValueError: If backend is not found or not supported.
    """
    agent_config = _get_agent_config()
    defaults = _get_default_config()

    # Determine which backend to use
    if name is None:
        name = agent_config.get("active", defaults["active"])

    # Check cache first
    if name in _backends_cache:
        return _backends_cache[name]

    # Get backend configuration
    backends_config = agent_config.get("backends", defaults["backends"])
    backend_cfg = backends_config.get(name)

    if backend_cfg is None:
        # Fall back to defaults for known backends
        backend_cfg = defaults["backends"].get(name)
        if backend_cfg is None:
            raise ValueError(f"Unknown backend: {name}")

    # Get the backend class
    backend_class = _BACKEND_CLASSES.get(name)
    if backend_class is None:
        raise ValueError(f"Backend not implemented: {name}")

    # Build AgentConfig
    config = AgentConfig(
        name=name,
        path=Path(backend_cfg.get("path", f"~/.local/bin/{name}")).expanduser(),
        enabled=backend_cfg.get("enabled", True),
        model=backend_cfg.get("model"),
        flags=backend_cfg.get("flags", []),
    )

    # Attach SDK-specific options if present (for claude backend)
    if "sdk_options" in backend_cfg:
        config.sdk_options = backend_cfg["sdk_options"]

    # Create and cache the backend instance
    backend = backend_class(config)
    _backends_cache[name] = backend
    return backend


def list_backends() -> dict[str, dict]:
    """
    List all configured backends with their info.

    Returns:
        Dict mapping backend name to its configuration.
        Example: {"claude": {"enabled": True, "path": "...", ...}, ...}
    """
    agent_config = _get_agent_config()
    defaults = _get_default_config()
    backends_config = agent_config.get("backends", defaults["backends"])
    return backends_config


def get_active_backend_name() -> str:
    """Get the name of the currently active backend."""
    agent_config = _get_agent_config()
    defaults = _get_default_config()
    return agent_config.get("active", defaults["active"])


def set_active_backend(name: str) -> None:
    """
    Set the active backend in settings.yaml.

    Args:
        name: Backend name (claude, codex)

    Raises:
        ValueError: If backend is unknown or not available
    """
    from .. import config as otto_config

    backends = list_backends()
    if name not in backends:
        raise ValueError(f"Unknown backend: {name}")

    # Update settings.yaml
    otto_config.set_setting("agent.active", name)

    # Clear backend cache so next get_backend() uses new active
    global _backends_cache
    _backends_cache = {}


def get_orchestration_config() -> dict:
    """Get orchestration configuration."""
    agent_config = _get_agent_config()
    defaults = _get_default_config()
    return agent_config.get("orchestration", defaults["orchestration"])


def get_backend_model(name: str | None = None) -> str | None:
    """
    Get the model configured for a backend.

    Args:
        name: Backend name. If None, uses active backend.

    Returns:
        Model name or None if using backend default.
    """
    if name is None:
        name = get_active_backend_name()

    backends = list_backends()
    backend_cfg = backends.get(name, {})
    return backend_cfg.get("model")


def set_backend_model(model: str | None, name: str | None = None) -> None:
    """
    Set the model for a backend in settings.yaml.

    Args:
        model: Model name (e.g., "sonnet", "opus"). None to clear/use default.
        name: Backend name. If None, uses active backend.

    Note:
        Any model string is accepted. If invalid, the CLI will return an error
        which gets passed through to the user.
    """
    from .. import config as otto_config

    if name is None:
        name = get_active_backend_name()

    backends = list_backends()
    if name not in backends:
        raise ValueError(f"Unknown backend: {name}")

    # Update settings.yaml
    otto_config.set_setting(f"agent.backends.{name}.model", model)

    # Clear backend cache so next get_backend() uses new model
    global _backends_cache
    _backends_cache = {}


def get_known_models(name: str | None = None) -> list[str]:
    """
    Get known models for a backend.

    Args:
        name: Backend name. If None, uses active backend.

    Returns:
        List of known model names for this backend.
    """
    if name is None:
        name = get_active_backend_name()
    return BACKEND_MODELS.get(name, [])


# Re-export base classes and types
__all__ = [
    # Base classes
    "AgentBackend",
    "AgentConfig",
    "AgentResult",
    # Type definitions
    "PermissionMode",
    "OutputFormat",
    "DEFAULT_PERMISSION_MODE",
    # Backend implementations
    "ClaudeBackend",
    "CodexBackend",
    "GenericBackend",
    "BACKEND_MODELS",
    # Registry functions
    "get_backend",
    "list_backends",
    "reload_config",
    "get_active_backend_name",
    "set_active_backend",
    "get_orchestration_config",
    "get_backend_model",
    "set_backend_model",
    "get_known_models",
]
