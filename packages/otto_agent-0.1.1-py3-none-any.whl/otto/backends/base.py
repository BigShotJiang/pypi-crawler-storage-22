"""
Base classes for agent backend abstraction.

Provides AgentBackend ABC and related dataclasses for implementing
different agent CLI backends (Claude, Codex, etc.).
"""

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from otto.streaming import StreamEvent


@dataclass
class AgentResult:
    """Result from running an agent backend."""

    success: bool
    output: str
    error: str | None = None
    backend: str = ""
    duration_seconds: float = 0.0

    # SDK-specific fields (optional, for backwards compatibility)
    cost_usd: float | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None
    session_id: str | None = None
    num_turns: int | None = None

    # Structured error context for sub-agent orchestration.
    # Populated by the orchestrator to give parent agents richer failure info.
    error_context: dict | None = None  # e.g. {"attempt": 3, "max_attempts": 4, "last_error": "..."}

    @property
    def is_retryable(self) -> bool:
        """Whether this failure looks transient and worth retrying."""
        if self.success or not self.error:
            return False
        transient_patterns = ["timed out", "rate limit", "connection", "503", "429"]
        error_lower = self.error.lower()
        return any(p in error_lower for p in transient_patterns)


@dataclass
class AgentConfig:
    """Configuration for an agent backend."""

    name: str
    path: Path
    enabled: bool = True
    model: str | None = None
    flags: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)

    def __post_init__(self):
        if isinstance(self.path, str):
            self.path = Path(self.path).expanduser()
        if self.flags is None:
            self.flags = []
        if self.env is None:
            self.env = {}


class AgentBackend(ABC):
    """Abstract base class for agent backends."""

    def __init__(self, config: AgentConfig):
        self.config = config
        self.name = config.name

    @abstractmethod
    async def run_async(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
    ) -> AgentResult:
        """Run the agent asynchronously."""
        pass

    @abstractmethod
    def run_sync(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
    ) -> AgentResult:
        """Run the agent synchronously."""
        pass

    def is_available(self) -> bool:
        """Check if the backend is available and enabled."""
        return self.config.enabled and self.config.path.exists()

    def get_capabilities(self) -> dict:
        """Return backend capabilities for introspection."""
        return {
            "name": self.name,
            "supports_system_prompt": False,  # Override in subclasses
            "supports_json_output": False,
            "supports_sandbox": False,
            "supports_mcp": False,
            "supports_streaming": False,
        }

    async def run_async_streaming(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
    ) -> AsyncIterator["StreamEvent"]:
        """
        Run the agent with streaming output.

        Yields StreamEvent objects as the response is generated.
        Default implementation falls back to non-streaming.

        Subclasses that support streaming should override this method.
        """
        from otto.streaming import StreamEvent

        # Default: run non-streaming and yield complete result
        result = await self.run_async(prompt, system_prompt, cwd, timeout, model)

        if result.success:
            yield StreamEvent.text_complete(result.output)
        else:
            yield StreamEvent.error(result.error or "Unknown error")

        yield StreamEvent.done()

    def supports_streaming(self) -> bool:
        """Check if this backend supports streaming."""
        return self.get_capabilities().get("supports_streaming", False)
