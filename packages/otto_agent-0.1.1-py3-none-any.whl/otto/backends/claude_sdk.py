"""
Claude SDK backend implementation.

Uses the official claude-agent-sdk Python SDK instead of CLI subprocess.
This addresses:
- Privacy: Prompts never visible in `ps aux`
- Typed API: Structured messages instead of raw text parsing
- Cost tracking: Built-in usage and cost metrics
- Hooks: Intercept and audit tool calls
- Better control: Fine-grained permission callbacks
- MCP isolation: Only Otto's tools are available, user MCP servers are not loaded
- Ephemeral sessions: Session files are deleted after successful completion,
  keeping the user's Claude Code session list clean (failed sessions are kept for debugging)
- Dynamic routing: Switch between providers on-the-fly via model spec:
    - "claude-sonnet-4-5" → Anthropic API (default)
    - "ollama/qwen3-coder" → Ollama local (Anthropic-compatible API)
    - "litellm/gpt-4o" → LiteLLM proxy (any model)
    - "openrouter/anthropic/claude-sonnet-4" → OpenRouter (failover, budget controls)
    - "http://custom:8080/v1:model" → Custom endpoint

    Model spec uses slash format consistently across all backends (same as LiteLLM).
    Legacy colon format (e.g., "openrouter:model") is accepted for backwards compatibility.

OpenRouter setup:
    1. Set OPENROUTER_API_KEY in your environment
    2. Use: /backend claude openrouter/anthropic/claude-sonnet-4
    OpenRouter provides provider failover, budget controls, and usage analytics.
    See: https://openrouter.ai/docs/guides/claude-code-integration
"""

import asyncio
import json
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from otto.streaming import StreamEvent

from .base import AgentBackend, AgentConfig, AgentResult


@dataclass
class ModelSpec:
    """Parsed model specification for routing requests."""

    provider: str  # "anthropic", "ollama", "litellm", "openrouter"
    model: str  # Model name
    base_url: str | None = None  # Override URL
    api_key: str | None = None  # Override API key (ANTHROPIC_API_KEY)
    auth_token_env: str | None = None  # Env var to read for ANTHROPIC_AUTH_TOKEN

    # Well-known provider configurations
    PROVIDERS = {
        "anthropic": {
            "base_url": None,  # Use default
            "api_key": None,  # Use default from env
            "disable_thinking": False,
            "auth_token_env": None,  # Uses ANTHROPIC_API_KEY
        },
        "ollama": {
            "base_url": "http://localhost:11434",
            "api_key": "",  # Empty string as per Ollama docs
            "disable_thinking": True,  # Ollama doesn't support thinking/beta features
            "auth_token_env": None,
        },
        "litellm": {
            "base_url": "http://localhost:4000",
            "api_key": None,  # Uses LITELLM_MASTER_KEY
            "disable_thinking": False,
            "auth_token_env": None,
        },
        "openrouter": {
            "base_url": "https://openrouter.ai/api",
            "api_key": "",  # Must be explicitly empty
            "disable_thinking": False,  # OpenRouter supports Claude natively
            "auth_token_env": "OPENROUTER_API_KEY",  # Read from env, set as AUTH_TOKEN
            # Note: Claude Code's background tasks (title gen, summarization) may still
            # go directly to Anthropic. Set CLAUDE_CODE_DISABLE_BACKGROUND_TASKS=1 to reduce.
        },
    }
    disable_thinking: bool = False  # Disable extended thinking for compatibility

    @classmethod
    def parse(cls, spec: str) -> "ModelSpec":
        """
        Parse a model specification string.

        Command format: /backend claude <model_spec>

        Model spec formats (slash format — standard):
            "claude-sonnet-4-5"                      → Anthropic API
            "ollama/qwen3-coder"                     → Ollama local
            "ollama/glm-4.7-flash:latest"            → Ollama with version tag
            "ollama/qwen3-coder:8b"                  → Ollama with size tag
            "litellm/gpt-4o"                         → LiteLLM proxy
            "litellm/gemini-2.0-flash"               → LiteLLM → Gemini
            "openrouter/anthropic/claude-sonnet-4"   → OpenRouter
            "openrouter/google/gemini-2.0-flash"     → OpenRouter → Gemini
            "http://custom:8080/v1:model"            → Custom endpoint

        Legacy colon format is also accepted for backwards compatibility:
            "openrouter:anthropic/claude-sonnet-4"   → same as slash format

        Returns:
            ModelSpec with provider, model, and optional overrides
        """
        if not spec:
            return cls(provider="anthropic", model="claude-sonnet-4-5-20250514")

        # Check if it's a custom URL (starts with http) — handle before slash parsing
        if spec.startswith("http://") or spec.startswith("https://"):
            # Format: http://host:port/v1:model
            url_parts = spec.rsplit(":", 1)
            if len(url_parts) == 2 and not url_parts[1].startswith("/"):
                return cls(
                    provider="custom",
                    model=url_parts[1],
                    base_url=url_parts[0],
                )
            return cls(provider="custom", model="default", base_url=spec)

        # Primary: slash format (e.g., "openrouter/anthropic/claude-sonnet-4")
        # Check if the first path segment is a known provider
        slash_parts = spec.split("/", 1)
        if slash_parts[0].lower() in cls.PROVIDERS:
            provider = slash_parts[0].lower()
            model_part = slash_parts[1] if len(slash_parts) > 1 else "claude-sonnet-4-5-20250514"

            config = cls.PROVIDERS[provider]
            return cls(
                provider=provider,
                model=model_part,
                base_url=config["base_url"],
                api_key=config["api_key"],
                disable_thinking=config.get("disable_thinking", False),
                auth_token_env=config.get("auth_token_env"),
            )

        # Legacy: colon format (e.g., "openrouter:anthropic/claude-sonnet-4")
        # Kept for backwards compatibility
        colon_parts = spec.split(":", 1)
        if colon_parts[0].lower() in cls.PROVIDERS:
            provider = colon_parts[0].lower()
            model_part = colon_parts[1] if len(colon_parts) > 1 else "claude-sonnet-4-5-20250514"

            config = cls.PROVIDERS[provider]
            return cls(
                provider=provider,
                model=model_part,
                base_url=config["base_url"],
                api_key=config["api_key"],
                disable_thinking=config.get("disable_thinking", False),
                auth_token_env=config.get("auth_token_env"),
            )

        # Default: treat as Anthropic model name
        return cls(provider="anthropic", model=spec)

    def get_env(self) -> dict[str, str]:
        """Get environment variables for this model spec."""
        import os

        env = {}
        if self.base_url:
            env["ANTHROPIC_BASE_URL"] = self.base_url
        if self.api_key is not None:  # Include even if empty string
            env["ANTHROPIC_API_KEY"] = self.api_key

        # Handle auth token from environment variable (e.g., OpenRouter)
        # This reads OPENROUTER_API_KEY and sets it as ANTHROPIC_AUTH_TOKEN
        if self.auth_token_env:
            auth_token = os.environ.get(self.auth_token_env)
            if auth_token:
                env["ANTHROPIC_AUTH_TOKEN"] = auth_token
                # For OpenRouter: disable background tasks to prevent extra Haiku calls
                env["CLAUDE_CODE_DISABLE_BACKGROUND_TASKS"] = "1"
                # Override the "small fast model" used for tool summarization
                # Default is Haiku which costs money - use same model as main conversation
                # This makes ALL requests go through the specified model
                env["ANTHROPIC_SMALL_FAST_MODEL"] = self.model
            else:
                # Warn but don't fail - let Claude SDK handle the error
                import logging

                logging.getLogger(__name__).warning(
                    f"Environment variable {self.auth_token_env} not set for {self.provider} provider"
                )

        # Disable beta/thinking features for non-Anthropic providers
        # This prevents compatibility issues with Ollama/LiteLLM
        if self.disable_thinking:
            env["ANTHROPIC_AUTH_TOKEN"] = "ollama"  # Required for Ollama
            env["DISABLE_INTERLEAVED_THINKING"] = "1"
            env["CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS"] = "1"
            env["CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC"] = "1"
        return env


def _get_session_cache_path(cwd: Path) -> Path:
    """Get the path to store Claude session ID for this project."""
    otto_dir = cwd / ".otto"
    otto_dir.mkdir(exist_ok=True)
    return otto_dir / "claude_session.json"


def _load_cached_session(cwd: Path) -> str | None:
    """Load cached Claude session ID for this project."""
    cache_path = _get_session_cache_path(cwd)
    if cache_path.exists():
        try:
            data = json.loads(cache_path.read_text())
            return data.get("session_id")
        except (json.JSONDecodeError, OSError):
            pass
    return None


def _save_cached_session(cwd: Path, session_id: str) -> None:
    """Save Claude session ID for this project."""
    cache_path = _get_session_cache_path(cwd)
    try:
        cache_path.write_text(json.dumps({"session_id": session_id}))
    except OSError:
        pass  # Best effort


def _get_claude_session_path(cwd: Path, session_id: str) -> Path:
    """Get the path to Claude Code's session file for cleanup."""
    # Claude stores sessions in ~/.claude/projects/{escaped-path}/{session_id}.jsonl
    # Path escaping: /home/user/project → -home-user-project
    escaped_path = str(cwd.resolve()).replace("/", "-")
    if escaped_path.startswith("-"):
        escaped_path = escaped_path[1:]  # Remove leading dash
    escaped_path = "-" + escaped_path  # Add it back (Claude's format)

    claude_dir = Path.home() / ".claude" / "projects" / escaped_path
    return claude_dir / f"{session_id}.jsonl"


def _delete_claude_session(cwd: Path, session_id: str) -> bool:
    """
    Delete a Claude Code session file to keep the session list clean.

    This removes the session from the user's Claude Code session list,
    preventing pollution from Otto's ephemeral sessions.

    Args:
        cwd: Project working directory
        session_id: The session UUID to delete

    Returns:
        True if deleted, False if not found or error
    """
    session_path = _get_claude_session_path(cwd, session_id)
    try:
        if session_path.exists():
            session_path.unlink()
            return True
    except OSError:
        pass  # Best effort
    return False


def _get_default_otto_mcp_config() -> dict[str, Any]:
    """
    Get the default MCP server configuration for Otto's tools.

    Uses Otto's built-in MCP server (otto.mcp_server) via stdio transport.
    This provides:
    - Memory tools: memory_recall, memory_remember, memory_list, memory_forget, memory_search_fts
    - Agent tools: agent_spawn, agent_list, agent_output
    - Pipeline tools: pipeline_run, pipeline_status, pipeline_cancel, pipeline_list
    - Platform tools: notify_send, send_buttons, send_file, edit_message, send_progress

    Returns:
        MCP server config dict for use with mcp_servers option
    """
    import sys

    return {
        "type": "stdio",
        "command": sys.executable,
        "args": ["-m", "otto.mcp_server"],
    }


# Note: In-process SDK MCP servers are disabled due to a bug in claude-agent-sdk
# where the subprocess transport fails with "ProcessTransport is not ready for writing"
# when handling MCP control requests. Using stdio transport with otto.mcp_server instead.


# Import SafeguardConfig from shared module
from otto.safeguards import SafeguardConfig


class ClaudeSDKBackend(AgentBackend):
    """
    Backend using claude-agent-sdk Python SDK.

    Key differences from CLI backend:
    - Prompts are passed via Python API, never visible in `ps aux`
    - Typed message streaming with AssistantMessage, ToolUseBlock, etc.
    - Built-in cost tracking via ResultMessage
    - Permission callbacks for fine-grained control
    """

    def __init__(self, config: AgentConfig):
        super().__init__(config)

        # Extract SDK-specific config from the sdk_options field
        sdk_config = getattr(config, "sdk_options", {}) or {}
        safeguard_config = sdk_config.get("safeguards", {})

        self.safeguards = SafeguardConfig(
            enabled=safeguard_config.get("enabled", True),
            protected_paths=safeguard_config.get("protected_paths", []),
            blocked_patterns=safeguard_config.get("blocked_patterns", []),
        )

        self.permission_mode = sdk_config.get("permission_mode", "bypassPermissions")
        self.max_turns = sdk_config.get("max_turns")
        self.allowed_tools = sdk_config.get("allowed_tools")
        # MCP isolation: only use Otto's tools, don't load user's MCP servers
        self.use_otto_mcp = sdk_config.get("use_otto_mcp", True)
        self.isolate_mcp = sdk_config.get("isolate_mcp", True)  # Don't load user settings

        # Session reuse: when False (default), each Otto call creates a fresh session
        # This is better for debugging (one exchange per session) and avoids
        # redundant context accumulation since Otto provides context via <recent_conversation>
        # Set to True if you want all Otto operations to appear as ONE session per project
        self.reuse_session = sdk_config.get("reuse_session", False)

        # Ephemeral sessions: delete session files after successful completion
        # This keeps the user's Claude Code session list clean
        # Sessions are deleted from ~/.claude/projects/{project}/{session_id}.jsonl
        self.ephemeral_sessions = sdk_config.get("ephemeral_sessions", True)

    def _build_mcp_servers(self) -> dict[str, Any]:
        """
        Build MCP server configurations routed through the gateway proxy.

        Instead of passing raw transport configs (which lets Claude SDK
        connect to MCP servers directly, bypassing policy enforcement),
        we use a single gateway proxy server that routes ALL tool calls
        through gateway.request_tool() for the full 7-step policy pipeline:

            allowlist → filtering → safeguards → permissions → prompt → execute → audit

        The proxy also includes Otto's built-in tools (memory, agents, etc.),
        so only one MCP server config is needed.
        """
        from otto.mcp_gateway_proxy import get_gateway_proxy_config

        try:
            # Single proxy server replaces both:
            # 1. Raw external MCP server configs (now policy-enforced)
            # 2. Otto's built-in MCP server (otto, agents, pipelines, etc.)
            return {"otto-gateway": get_gateway_proxy_config()}
        except Exception as e:
            import logging

            logging.getLogger(__name__).warning(
                "Failed to build gateway proxy config: %s, falling back to direct configs", e
            )
            # Fallback: direct configs (no policy enforcement) + otto tools
            from otto.gateway import get_gateway

            try:
                configs = get_gateway().get_mcp_server_configs()
            except Exception:
                configs = {}
            configs["otto"] = _get_default_otto_mcp_config()
            return configs

    def _build_options(
        self,
        system_prompt: str,
        cwd: Path,
        resume_session: str | None = None,
        model_spec: ModelSpec | None = None,
    ) -> "ClaudeAgentOptions":
        """Build SDK options with Otto's MCP tools."""
        from claude_agent_sdk import ClaudeAgentOptions

        # Build MCP servers — gateway proxy handles everything (external + Otto tools)
        mcp_servers = self._build_mcp_servers()

        # Determine model - use spec if provided, otherwise config default
        model = model_spec.model if model_spec else self.config.model

        options_kwargs = {
            "system_prompt": system_prompt,
            "model": model,
            "cwd": str(cwd),
            "permission_mode": self.permission_mode,
            # Note: can_use_tool callback disabled due to SDK streaming protocol issue
            # Safeguards still available via SafeguardConfig for validation/logging
            "allowed_tools": self.allowed_tools,
            "max_turns": self.max_turns,
            "mcp_servers": mcp_servers if mcp_servers else None,
            # Isolate from user's Claude Code settings (prevents loading their MCP servers)
            "setting_sources": [] if self.isolate_mcp else None,
        }

        # Add environment overrides for custom providers (Ollama, LiteLLM, etc.)
        if model_spec:
            env = model_spec.get_env()
            if env:
                options_kwargs["env"] = env
                # Debug: log the env vars being set
                import logging

                logging.getLogger(__name__).info(f"SDK env overrides: {env}")

        # Only pass resume if we have a session ID to resume
        # Passing None might have different behavior than omitting it
        if resume_session:
            options_kwargs["resume"] = resume_session

        return ClaudeAgentOptions(**options_kwargs)

    async def _permission_callback(
        self,
        tool_name: str,
        input_data: dict[str, Any],
        context: Any,
    ) -> Any:
        """
        Permission callback with sane safeguards.

        Philosophy: Allow everything by default, prevent catastrophic mistakes.
        """
        from claude_agent_sdk.types import PermissionResultAllow, PermissionResultDeny

        # If safeguards disabled, allow everything
        if not self.safeguards.enabled:
            return PermissionResultAllow()

        # File write operations: check protected paths
        if tool_name in ("Write", "Edit", "MultiEdit"):
            file_path = input_data.get("file_path", "")
            if self.safeguards.is_path_protected(file_path):
                return PermissionResultDeny(
                    message=f"Protected path: {file_path}. "
                    "Set safeguards.enabled=false to override.",
                    interrupt=False,  # Don't halt, just skip this action
                )

        # Bash: check dangerous command patterns
        if tool_name == "Bash":
            command = input_data.get("command", "")
            blocked, pattern = self.safeguards.is_command_blocked(command)
            if blocked:
                return PermissionResultDeny(
                    message=f"Blocked dangerous command pattern: {pattern}",
                    interrupt=False,
                )

        # Read operations: always allowed
        if tool_name in ("Read", "Glob", "Grep", "LS", "WebFetch", "WebSearch"):
            return PermissionResultAllow()

        # Default: allow
        return PermissionResultAllow()

    def get_capabilities(self) -> dict:
        """Return SDK backend capabilities."""
        return {
            "name": self.name,
            "supports_system_prompt": True,
            "supports_json_output": True,
            "supports_sandbox": True,
            "supports_mcp": True,
            "supports_hooks": True,
            "supports_cost_tracking": True,
            "supports_streaming": True,
            "models": ["claude-sonnet-4-5", "claude-opus-4-5", "claude-haiku-4-5"],
        }

    async def run_async(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
    ) -> AgentResult:
        """
        Run Claude via SDK - prompts never visible in ps aux.

        Args:
            prompt: The user prompt
            system_prompt: System prompt for the model
            cwd: Working directory
            timeout: Request timeout in seconds
            model: Optional model specification for dynamic routing.
                Command: /backend claude <model_spec>
                Examples:
                - None or "claude-sonnet-4-5" → Anthropic API (default)
                - "ollama/qwen3-coder" → Ollama local
                - "ollama/glm-4.7-flash:latest" → Ollama with version
                - "litellm/gpt-4o" → LiteLLM → OpenAI
                - "litellm/gemini-2.0-flash" → LiteLLM → Gemini
                - "openrouter/anthropic/claude-sonnet-4" → OpenRouter
                - "openrouter/google/gemini-2.0-flash" → OpenRouter → Gemini

        Returns:
            AgentResult with output, cost tracking, etc.
        """
        if not self.config.enabled:
            return AgentResult(
                success=False,
                output="",
                error=f"Backend {self.name} is not enabled",
                backend=self.name,
            )

        # Import SDK here to allow graceful handling if not installed
        try:
            from claude_agent_sdk import (
                AssistantMessage,
                ResultMessage,
                SystemMessage,
                TextBlock,
                query,
            )
        except ImportError as e:
            return AgentResult(
                success=False,
                output="",
                error=f"claude-agent-sdk not installed: {e}. "
                "Install with: pip install claude-agent-sdk",
                backend=self.name,
            )

        # Parse model specification for dynamic routing
        model_spec = ModelSpec.parse(model) if model else None

        # Debug logging for model routing
        import logging

        log = logging.getLogger(__name__)
        if model_spec:
            log.info(f"Model routing: provider={model_spec.provider}, model={model_spec.model}")
            log.info(f"Model routing env: {model_spec.get_env()}")

        # Try to reuse existing session to avoid polluting user's Claude Code session list
        # All Otto operations for this project will appear as ONE session
        cached_session = _load_cached_session(cwd) if self.reuse_session else None
        options = self._build_options(
            system_prompt, cwd, resume_session=cached_session, model_spec=model_spec
        )

        start_time = time.time()
        output_parts: list[str] = []
        cost_usd: float | None = None
        input_tokens: int | None = None
        output_tokens: int | None = None
        session_id: str | None = None
        num_turns: int | None = None

        try:
            async for message in query(prompt=prompt, options=options):
                # Capture session ID from init message and cache it for reuse
                if isinstance(message, SystemMessage):
                    if message.subtype == "init" and message.data:
                        new_session_id = message.data.get("session_id")
                        if new_session_id:
                            session_id = new_session_id
                            if self.reuse_session and new_session_id != cached_session:
                                _save_cached_session(cwd, new_session_id)

                elif isinstance(message, AssistantMessage):
                    for block in message.content:
                        if isinstance(block, TextBlock):
                            output_parts.append(block.text)

                elif isinstance(message, ResultMessage):
                    cost_usd = message.total_cost_usd
                    # Prefer session_id from ResultMessage if available
                    session_id = message.session_id or session_id
                    num_turns = message.num_turns
                    if message.usage:
                        input_tokens = message.usage.get("input_tokens")
                        output_tokens = message.usage.get("output_tokens")

                    # Cache the session ID for future runs
                    if self.reuse_session and session_id and session_id != cached_session:
                        _save_cached_session(cwd, session_id)

                    if message.is_error:
                        return AgentResult(
                            success=False,
                            output="\n".join(output_parts),
                            error=message.result or "Unknown error",
                            backend=self.name,
                            duration_seconds=(
                                message.duration_ms / 1000 if message.duration_ms else 0
                            ),
                            cost_usd=cost_usd,
                            input_tokens=input_tokens,
                            output_tokens=output_tokens,
                            session_id=session_id,
                            num_turns=num_turns,
                        )

            return AgentResult(
                success=True,
                output="\n".join(output_parts),
                backend=self.name,
                duration_seconds=time.time() - start_time,
                cost_usd=cost_usd,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                session_id=session_id,
                num_turns=num_turns,
            )

        except asyncio.CancelledError:
            return AgentResult(
                success=False,
                output="\n".join(output_parts),
                error="Cancelled by user",
                backend=self.name,
                duration_seconds=time.time() - start_time,
            )
        except asyncio.TimeoutError:
            return AgentResult(
                success=False,
                output="\n".join(output_parts),
                error=f"Request timed out after {timeout}s",
                backend=self.name,
                duration_seconds=timeout,
            )
        except Exception as e:
            return AgentResult(
                success=False,
                output="\n".join(output_parts),
                error=str(e),
                backend=self.name,
                duration_seconds=time.time() - start_time,
            )
        finally:
            # Clean up ephemeral session on ALL exit paths (success, error, timeout)
            # to keep the user's Claude Code session list clean
            if self.ephemeral_sessions and session_id:
                _delete_claude_session(cwd, session_id)

    def run_sync(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
    ) -> AgentResult:
        """Run synchronously by wrapping async."""
        return asyncio.run(self.run_async(prompt, system_prompt, cwd, timeout, model))

    async def run_async_streaming(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
    ) -> AsyncIterator["StreamEvent"]:
        """
        Run Claude via SDK with streaming output.

        Yields StreamEvent objects as the response is generated.
        This enables real-time UI updates during long responses.

        Args:
            prompt: The user prompt
            system_prompt: System prompt for the model
            cwd: Working directory
            timeout: Request timeout in seconds
            model: Optional model specification for dynamic routing

        Yields:
            StreamEvent objects (THINKING, TOOL_USE, TEXT_DELTA, etc.)
        """
        from otto.streaming import StreamEvent

        if not self.config.enabled:
            yield StreamEvent.error(f"Backend {self.name} is not enabled")
            yield StreamEvent.done()
            return

        # Import SDK
        try:
            from claude_agent_sdk import (
                AssistantMessage,
                ResultMessage,
                SystemMessage,
                TextBlock,
                ThinkingBlock,
                ToolResultBlock,
                ToolUseBlock,
                query,
            )
        except ImportError as e:
            yield StreamEvent.error(
                f"claude-agent-sdk not installed: {e}. Install with: pip install claude-agent-sdk"
            )
            yield StreamEvent.done()
            return

        # Parse model specification
        model_spec = ModelSpec.parse(model) if model else None

        # Build options
        cached_session = _load_cached_session(cwd) if self.reuse_session else None
        options = self._build_options(
            system_prompt, cwd, resume_session=cached_session, model_spec=model_spec
        )

        import logging

        log = logging.getLogger(__name__)

        # Track session_id at method scope for cleanup on all exit paths
        session_id: str | None = None

        # Emit initial THINKING event so the UI shows "Thinking..." immediately
        yield StreamEvent.thinking()

        try:
            async for message in query(prompt=prompt, options=options):
                # System messages (init, etc.)
                if isinstance(message, SystemMessage):
                    if message.subtype == "init" and message.data:
                        session_id = message.data.get("session_id")
                        if session_id and self.reuse_session:
                            _save_cached_session(cwd, session_id)
                    continue

                # Assistant messages with content blocks
                elif isinstance(message, AssistantMessage):
                    for block in message.content:
                        # Handle thinking blocks
                        if isinstance(block, ThinkingBlock):
                            yield StreamEvent.thinking(block.thinking or "")

                        # Handle text blocks (the actual response)
                        elif isinstance(block, TextBlock):
                            # Yield as delta for streaming
                            yield StreamEvent.text_delta(block.text)

                        # Handle tool use blocks
                        elif isinstance(block, ToolUseBlock):
                            yield StreamEvent.tool_use(
                                tool_name=block.name,
                                tool_input=block.input if hasattr(block, "input") else None,
                            )

                        # Handle tool result blocks (tool completed)
                        elif isinstance(block, ToolResultBlock):
                            tool_name = getattr(block, "tool_use_id", "unknown")
                            tool_output = getattr(block, "content", "")
                            if isinstance(tool_output, list):
                                # Extract text from content blocks
                                tool_output = " ".join(
                                    str(c.text) if hasattr(c, "text") else str(c)
                                    for c in tool_output
                                )
                            yield StreamEvent.tool_result(str(tool_name), str(tool_output)[:500])

                # Final result
                elif isinstance(message, ResultMessage):
                    if message.is_error:
                        yield StreamEvent.error(message.result or "Unknown error")

                    # Prefer session_id from ResultMessage if available
                    session_id = message.session_id or session_id

        except asyncio.TimeoutError:
            yield StreamEvent.error(f"Request timed out after {timeout}s")
        except Exception as e:
            log.exception("Streaming error")
            yield StreamEvent.error(str(e))
        finally:
            # Clean up ephemeral session on ALL exit paths (success, error, timeout)
            if self.ephemeral_sessions and session_id:
                _delete_claude_session(cwd, session_id)

        yield StreamEvent.done()

    def is_available(self) -> bool:
        """SDK backend is available if enabled (no binary check needed)."""
        return self.config.enabled

    # Session Management API
    @staticmethod
    def clear_cached_session(cwd: Path) -> bool:
        """
        Clear the cached Claude session for a project.

        Use this to force Otto to create a new Claude Code session
        instead of reusing the existing one.

        Args:
            cwd: Project directory

        Returns:
            True if cache was cleared, False if no cache existed
        """
        cache_path = _get_session_cache_path(cwd)
        if cache_path.exists():
            cache_path.unlink()
            return True
        return False

    @staticmethod
    def get_cached_session(cwd: Path) -> str | None:
        """
        Get the cached Claude session ID for a project.

        Args:
            cwd: Project directory

        Returns:
            Session ID if cached, None otherwise
        """
        return _load_cached_session(cwd)

    @staticmethod
    def delete_session(cwd: Path, session_id: str) -> bool:
        """
        Delete a Claude Code session file.

        Use this to manually clean up sessions from the user's
        Claude Code session list.

        Args:
            cwd: Project directory
            session_id: Session UUID to delete

        Returns:
            True if deleted, False if not found
        """
        return _delete_claude_session(cwd, session_id)

    @staticmethod
    def get_supported_providers() -> dict[str, dict]:
        """
        Get information about supported model providers.

        Returns:
            Dict of provider name → config info

        Example:
            >>> ClaudeSDKBackend.get_supported_providers()
            {
                "anthropic": {"base_url": None, "api_key": None},
                "ollama": {"base_url": "http://localhost:11434", "api_key": "ollama"},
                "litellm": {"base_url": "http://localhost:4000", "api_key": None},
            }
        """
        return ModelSpec.PROVIDERS.copy()

    @staticmethod
    def parse_model_spec(spec: str) -> dict:
        """
        Parse a model specification string.

        Args:
            spec: Model spec like "ollama/glm-4.7-flash:latest"

        Returns:
            Dict with provider, model, base_url, api_key, auth_token_env

        Examples:
            >>> ClaudeSDKBackend.parse_model_spec("ollama/glm-4.7-flash:latest")
            {"provider": "ollama", "model": "glm-4.7-flash:latest",
             "base_url": "http://localhost:11434", "api_key": ""}

            >>> ClaudeSDKBackend.parse_model_spec("litellm/gpt-4o")
            {"provider": "litellm", "model": "gpt-4o",
             "base_url": "http://localhost:4000", "api_key": None}

            >>> ClaudeSDKBackend.parse_model_spec("openrouter/anthropic/claude-sonnet-4")
            {"provider": "openrouter", "model": "anthropic/claude-sonnet-4",
             "base_url": "https://openrouter.ai/api", "api_key": "",
             "auth_token_env": "OPENROUTER_API_KEY"}
        """
        parsed = ModelSpec.parse(spec)
        return {
            "provider": parsed.provider,
            "model": parsed.model,
            "base_url": parsed.base_url,
            "api_key": parsed.api_key,
            "auth_token_env": parsed.auth_token_env,
        }
