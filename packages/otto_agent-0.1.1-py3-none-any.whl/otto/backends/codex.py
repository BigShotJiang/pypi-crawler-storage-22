"""
Codex App-Server backend implementation.

Uses Codex's JSON-RPC 2.0 app-server protocol for:
- True incremental text streaming (item/agentMessage/delta events)
- Session persistence with thread resume/fork
- Graceful cancellation via turn/interrupt
- Connection reuse instead of spawning process each time

Protocol overview:
    Client → Server: {"method": "thread/start", "id": 1, "params": {...}}
    Server → Client (response): {"id": 1, "result": {"thread": {"id": "thr_123"}}}
    Server → Client (notification): {"type": "item/agentMessage/delta", "delta": "Hello"}
"""

import asyncio
import json
import logging
import os
import re
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from pathlib import Path

from .base import AgentBackend, AgentConfig, AgentResult

log = logging.getLogger(__name__)


# Codex-specific behavior instructions to maintain Otto persona
OTTO_INSTRUCTIONS = """
CRITICAL BEHAVIOR RULES:
1. Be DIRECT. Never narrate what you're about to do - just do it.
2. Never say "I'll analyze...", "Let me check...", "I'm going to..." - just give results.
3. Never mention internal tools, delegating to investigators, or your process.
4. If you use tools, report RESULTS only, not the fact that you used them.
5. Keep responses concise. No preamble, no meta-commentary.
6. You ARE Otto - respond as Otto would, not as a verbose assistant.

BAD: "Right, let me analyze the codebase. I'll use my investigator tool to examine..."
GOOD: "Here's the system architecture: [direct answer]"
""".strip()


def _extract_cli_error_message(raw: object) -> str:
    """Extract a readable error message from Codex CLI error payloads."""
    if raw is None:
        return "Unknown error"

    # Many Codex CLI errors are JSON encoded as strings
    if isinstance(raw, str):
        text = raw.strip()
        if text.startswith("{") and text.endswith("}"):
            try:
                data = json.loads(text)
                if isinstance(data, dict):
                    if "detail" in data and isinstance(data["detail"], str):
                        return data["detail"].strip()
                    err = data.get("error")
                    if isinstance(err, dict) and isinstance(err.get("message"), str):
                        return err["message"].strip()
            except json.JSONDecodeError:
                pass
        return text

    if isinstance(raw, dict):
        message = raw.get("message")
        if isinstance(message, str) and message.strip():
            return message.strip()
    return str(raw).strip() or "Unknown error"


def _extract_shell_command(command: str) -> str:
    """Try to extract the user-relevant shell snippet from Codex's command wrapper."""
    if not command:
        return ""
    # Examples:
    #   /usr/bin/zsh -lc ls
    #   /usr/bin/zsh -lc 'ls -a'
    #   /usr/bin/zsh -lc "printf 'hi' > file"
    m = re.search(r"\s-lc\s+(?P<cmd>.+)$", command)
    extracted = (m.group("cmd") if m else command).strip()
    if (extracted.startswith("'") and extracted.endswith("'")) or (
        extracted.startswith('"') and extracted.endswith('"')
    ):
        extracted = extracted[1:-1].strip()
    return extracted


class JsonRpcConnection:
    """Bidirectional JSON-RPC 2.0 over stdio."""

    def __init__(self, proc: asyncio.subprocess.Process):
        self._proc = proc
        self._request_id = 0
        self._pending: dict[int, asyncio.Future] = {}
        self._notification_queue: asyncio.Queue = asyncio.Queue()
        self._reader_task: asyncio.Task | None = None
        self._closed = False

    async def start(self) -> None:
        """Start background reader task."""
        self._reader_task = asyncio.create_task(self._read_loop())

    async def _read_loop(self) -> None:
        """Route responses to pending futures, notifications to queue."""
        assert self._proc.stdout is not None

        while not self._closed:
            try:
                line = await self._proc.stdout.readline()
                if not line:
                    log.debug("EOF from codex server stdout")
                    break

                line_str = line.decode(errors="replace").strip()
                if not line_str:
                    continue

                if not line_str.startswith("{"):
                    log.debug("Non-JSON from codex: %s", line_str[:200])
                    continue

                try:
                    msg = json.loads(line_str)
                except json.JSONDecodeError:
                    log.warning("Invalid JSON from codex server: %s", line_str[:100])
                    continue

                if not isinstance(msg, dict):
                    continue

                if "id" in msg:
                    # Response to a request
                    request_id = msg["id"]
                    log.debug("Received response for request %d", request_id)
                    future = self._pending.pop(request_id, None)
                    if future and not future.done():
                        if "error" in msg:
                            log.warning("Request %d returned error: %s", request_id, msg["error"])
                            future.set_exception(
                                RuntimeError(msg["error"].get("message", str(msg["error"])))
                            )
                        else:
                            future.set_result(msg.get("result", {}))
                else:
                    # Notification (has "type" instead of "id")
                    log.debug(
                        "Queuing notification: %s", msg.get("method", msg.get("type", "unknown"))
                    )
                    await self._notification_queue.put(msg)

            except asyncio.CancelledError:
                break
            except Exception as e:
                log.debug("Error reading from codex server: %s", e)
                break

        # Signal end to any waiting readers
        await self._notification_queue.put(None)

    async def send_request(self, method: str, params: dict) -> dict:
        """Send request and await response."""
        if self._closed or self._proc.returncode is not None:
            raise RuntimeError("Connection closed")

        self._request_id += 1
        request_id = self._request_id
        request = {"method": method, "id": request_id, "params": params}

        loop = asyncio.get_event_loop()
        future: asyncio.Future = loop.create_future()
        self._pending[request_id] = future

        assert self._proc.stdin is not None
        try:
            log.debug("Sending request %d: %s", request_id, method)
            self._proc.stdin.write(json.dumps(request).encode() + b"\n")
            await self._proc.stdin.drain()
        except Exception as e:
            self._pending.pop(request_id, None)
            raise RuntimeError(f"Failed to send request: {e}") from e

        log.debug("Waiting for response to request %d...", request_id)
        return await future

    async def send_notification(self, method: str, params: dict) -> None:
        """Send notification (no response expected)."""
        if self._closed or self._proc.returncode is not None:
            raise RuntimeError("Connection closed")

        msg = {"method": method, "params": params}

        assert self._proc.stdin is not None
        self._proc.stdin.write(json.dumps(msg).encode() + b"\n")
        await self._proc.stdin.drain()

    async def read_notification(self, timeout: float | None = None) -> dict:
        """Read next notification from queue."""
        try:
            msg = await asyncio.wait_for(self._notification_queue.get(), timeout=timeout)
            if msg is None:
                raise RuntimeError("Connection closed")
            return msg
        except asyncio.TimeoutError:
            raise

    async def close(self) -> None:
        """Clean shutdown."""
        self._closed = True

        if self._reader_task:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass

        # Cancel pending requests
        for future in self._pending.values():
            if not future.done():
                future.cancel()
        self._pending.clear()

        if self._proc.returncode is None:
            self._proc.terminate()
            try:
                await asyncio.wait_for(self._proc.wait(), timeout=5)
            except asyncio.TimeoutError:
                self._proc.kill()
                await self._proc.wait()


@dataclass
class CodexServerSession:
    """Active session with the Codex app-server."""

    thread_id: str
    process: asyncio.subprocess.Process
    connection: JsonRpcConnection
    current_turn_id: str | None = None


def _get_session_cache_path(cwd: Path) -> Path:
    """Get the path to store Codex session ID for this project."""
    otto_dir = cwd / ".otto"
    otto_dir.mkdir(exist_ok=True)
    return otto_dir / "codex_session.json"


def _load_cached_session(cwd: Path) -> dict | None:
    """Load cached Codex session data for this project."""
    cache_path = _get_session_cache_path(cwd)
    if cache_path.exists():
        try:
            data = json.loads(cache_path.read_text())
            # Sessions expire after 24 hours
            if time.time() - data.get("created_at", 0) < 86400:
                return data
        except (json.JSONDecodeError, OSError):
            pass
    return None


def _save_cached_session(cwd: Path, thread_id: str) -> None:
    """Save Codex session ID for this project."""
    cache_path = _get_session_cache_path(cwd)
    try:
        cache_path.write_text(
            json.dumps(
                {
                    "thread_id": thread_id,
                    "created_at": time.time(),
                }
            )
        )
    except OSError:
        pass  # Best effort


class CodexBackend(AgentBackend):
    """
    Backend using Codex app-server JSON-RPC protocol.

    Key benefits over codex exec:
    - True incremental text streaming (item/agentMessage/delta)
    - Session persistence with thread resume
    - Graceful cancellation via turn/interrupt
    - Connection reuse
    """

    def __init__(self, config: AgentConfig):
        super().__init__(config)
        self._sessions: dict[Path, CodexServerSession] = {}
        self._lock = asyncio.Lock()

        # Derive node bin path from the codex binary location
        self._node_path = self.config.path.parent if self.config.path else None

        # SDK-style options
        sdk_config = getattr(config, "sdk_options", {}) or {}
        self.reuse_session = sdk_config.get("reuse_session", True)
        self.connection_timeout = sdk_config.get("connection_timeout", 120)
        self.approval_policy = sdk_config.get("approval_policy", "never")
        self.sandbox_policy = sdk_config.get("sandbox_policy", "danger-full-access")

    def get_capabilities(self) -> dict:
        """Return backend capabilities."""
        return {
            "name": self.name,
            "supports_system_prompt": False,  # Prepended to prompt
            "supports_json_output": True,
            "supports_sandbox": True,
            "supports_mcp": True,
            "supports_streaming": True,  # TRUE incremental streaming!
            "supports_session_reuse": True,
            "sandbox_modes": ["read-only", "workspace-write", "danger-full-access"],
            "approval_modes": ["never", "unlessTrusted", "always"],
        }

    def is_available(self) -> bool:
        """Check if backend is available and enabled."""
        return self.config.enabled and self.config.path.exists()

    def _get_env(self) -> dict:
        """Get environment variables for subprocess."""
        env = {**os.environ}

        # Ensure correct node version is used (same dir as codex binary)
        if self._node_path:
            node_bin = str(self._node_path)
            current_path = env.get("PATH", "")
            if node_bin not in current_path:
                env["PATH"] = f"{node_bin}:{current_path}"

        # Disable color codes for clean output
        env["NO_COLOR"] = "1"
        env["FORCE_COLOR"] = "0"

        return env

    def _prepare_stdin(self, system_prompt: str, user_prompt: str) -> str:
        """Prepare combined prompt for input."""
        parts = []
        if system_prompt:
            parts.append(system_prompt)

        parts.append(OTTO_INSTRUCTIONS)

        if user_prompt:
            parts.append(f"USER QUERY: {user_prompt}")

        return "\n\n".join(parts)

    async def _ensure_connection(self, cwd: Path) -> CodexServerSession:
        """Get or create session with automatic reconnection."""
        async with self._lock:
            session = self._sessions.get(cwd)

            # Check if process died
            if session and session.process.returncode is not None:
                log.info("Codex server process died, reconnecting...")
                await session.connection.close()
                del self._sessions[cwd]
                session = None

            if not session:
                session = await asyncio.wait_for(
                    self._start_server(cwd), timeout=self.connection_timeout
                )
                self._sessions[cwd] = session

            return session

    async def _start_server(self, cwd: Path) -> CodexServerSession:
        """Spawn app-server and perform handshake."""
        log.info("Starting codex app-server for %s", cwd)

        proc = await asyncio.create_subprocess_exec(
            str(self.config.path),
            "app-server",
            cwd=str(cwd),
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=self._get_env(),
        )

        conn = JsonRpcConnection(proc)
        await conn.start()

        # Handshake (required before any other calls)
        try:
            await conn.send_request(
                "initialize",
                {
                    "clientInfo": {
                        "name": "otto_codex_backend",
                        "title": "Otto Codex Backend",
                        "version": "1.0.0",
                    }
                },
            )
            await conn.send_notification("initialized", {})
        except Exception as e:
            await conn.close()
            raise RuntimeError(f"Handshake failed: {e}") from e

        log.info("Codex app-server handshake complete")

        return CodexServerSession(
            thread_id="",
            process=proc,
            connection=conn,
        )

    async def _get_or_create_thread(
        self,
        session: CodexServerSession,
        cwd: Path,
        model: str | None = None,
    ) -> str:
        """Get existing thread or create new one."""

        # Try resume cached session
        if self.reuse_session:
            cached = _load_cached_session(cwd)
            if cached and cached.get("thread_id"):
                try:
                    result = await session.connection.send_request(
                        "thread/resume", {"threadId": cached["thread_id"]}
                    )
                    thread = result.get("thread", {})
                    session.thread_id = thread.get("id", cached["thread_id"])
                    log.info("Resumed thread %s", session.thread_id)
                    return session.thread_id
                except Exception as e:
                    log.debug("Failed to resume thread: %s", e)
                    # Fall through to create new

        # Create new thread
        effective_model = model or self.config.model or "gpt-5.1-codex"
        result = await session.connection.send_request(
            "thread/start",
            {
                "model": effective_model,
                "cwd": str(cwd),
                "approvalPolicy": self.approval_policy,
                "sandbox": self.sandbox_policy,
            },
        )

        thread = result.get("thread", {})
        session.thread_id = thread.get("id", "")

        if self.reuse_session and session.thread_id:
            _save_cached_session(cwd, session.thread_id)

        log.info("Created new thread %s", session.thread_id)
        return session.thread_id

    async def _interrupt_turn(
        self,
        session: CodexServerSession,
        thread_id: str,
        turn_id: str,
    ) -> None:
        """Interrupt turn gracefully instead of killing process."""
        try:
            await session.connection.send_request(
                "turn/interrupt",
                {
                    "threadId": thread_id,
                    "turnId": turn_id,
                },
            )

            # Wait for turn/completed with status="interrupted"
            for _ in range(10):  # Max 10 notifications
                try:
                    notification = await session.connection.read_notification(timeout=5)
                    if notification.get("type") == "turn/completed":
                        break
                except asyncio.TimeoutError:
                    break
        except Exception as e:
            log.warning("Failed to interrupt turn: %s", e)

    @staticmethod
    def _extract_tool_start(item: dict) -> tuple[str | None, dict | None]:
        """Extract tool name and input from item/started."""
        item_type = item.get("type")

        if item_type == "commandExecution":
            command = _extract_shell_command(item.get("command", ""))
            return "Bash", {"command": command} if command else None

        if item_type == "fileChange":
            return "Apply patch", None

        if item_type == "mcpToolCall":
            tool = item.get("tool") or item.get("name")
            return str(tool) if tool else "MCP", item.get("input")

        if item_type == "webSearch":
            return "WebSearch", {"query": item.get("query")}

        return None, None

    @staticmethod
    def _extract_tool_output(item: dict) -> str:
        """Extract tool output from item/completed."""
        item_type = item.get("type")

        if item_type == "commandExecution":
            output = item.get("aggregatedOutput", "")
            exit_code = item.get("exitCode")
            if output:
                return str(output)[:200]
            return f"(exit {exit_code})" if exit_code is not None else "done"

        if item_type == "fileChange":
            changes = item.get("changes", [])
            paths = [
                Path(c.get("path", "")).name
                for c in changes[:5]
                if isinstance(c, dict) and c.get("path")
            ]
            return ", ".join(paths) if paths else "files modified"

        if item_type == "mcpToolCall":
            return str(item.get("output", ""))[:100]

        return "done"

    @staticmethod
    def _extract_error(error: dict | str | None) -> str:
        """Extract error message from turn.failed error payload."""
        if error is None:
            return "Unknown error"

        if isinstance(error, str):
            return _extract_cli_error_message(error)

        if isinstance(error, dict):
            message = error.get("message")
            if message:
                return _extract_cli_error_message(message)
            return str(error)

        return str(error)

    async def run_async_streaming(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
    ) -> AsyncIterator:
        """
        Run Codex with true incremental streaming via app-server.

        Yields StreamEvent objects as the response is generated.
        """
        from otto.streaming import StreamEvent

        if not self.is_available():
            yield StreamEvent.error(f"Backend {self.name} is not available")
            yield StreamEvent.done()
            return

        # Establish connection
        try:
            session = await self._ensure_connection(cwd)
            thread_id = await self._get_or_create_thread(session, cwd, model)
        except asyncio.TimeoutError:
            yield StreamEvent.error(f"Connection timeout after {self.connection_timeout}s")
            yield StreamEvent.done()
            return
        except Exception as e:
            yield StreamEvent.error(f"Connection failed: {e}")
            yield StreamEvent.done()
            return

        # Build prompt with system context
        full_prompt = self._prepare_stdin(system_prompt, prompt)

        # Start turn
        try:
            result = await session.connection.send_request(
                "turn/start",
                {
                    "threadId": thread_id,
                    "input": [{"type": "text", "text": full_prompt}],
                },
            )
            turn = result.get("turn", {})
            turn_id = turn.get("id", "")
            session.current_turn_id = turn_id
        except Exception as e:
            log.exception("Failed to start turn")
            yield StreamEvent.error(f"Failed to start turn: {e}")
            yield StreamEvent.done()
            return

        yield StreamEvent.thinking()

        # State tracking
        accumulated_text = ""
        active_tools: dict[str, dict] = {}  # itemId -> {name, input}

        try:
            deadline = time.time() + timeout

            while True:
                remaining = deadline - time.time()
                if remaining <= 0:
                    raise asyncio.TimeoutError()

                try:
                    log.debug("Waiting for notification (remaining: %.1fs)...", remaining)
                    notification = await session.connection.read_notification(timeout=remaining)
                except asyncio.TimeoutError:
                    raise

                # JSON-RPC notifications use "method" not "type"
                etype = notification.get("method") or notification.get("type", "")
                params = notification.get("params", {})
                log.debug("Received: %s", etype)

                # --- Turn lifecycle ---
                if etype == "turn/started":
                    yield StreamEvent.thinking()
                    continue

                if etype == "turn/completed":
                    turn = params.get("turn", {})
                    status = turn.get("status", "")
                    if status == "failed":
                        error = turn.get("error", {})
                        yield StreamEvent.error(self._extract_error(error))
                    elif accumulated_text.strip():
                        yield StreamEvent.text_complete(accumulated_text.strip())
                    break

                # --- Reasoning deltas ---
                if etype == "item/reasoning/summaryTextDelta":
                    delta = params.get("summaryTextDelta", "")
                    if delta:
                        yield StreamEvent.thinking(delta)
                    continue

                # --- Agent message deltas (TRUE STREAMING!) ---
                if etype == "item/agentMessage/delta":
                    delta = params.get("delta", "")
                    if delta:
                        accumulated_text += delta
                        yield StreamEvent.text_delta(delta)
                    continue

                # --- Item started (tools) ---
                if etype == "item/started":
                    item = params.get("item", {})
                    item_id = params.get("itemId", "")
                    tool_name, tool_input = self._extract_tool_start(item)
                    if tool_name:
                        active_tools[item_id] = {"name": tool_name, "input": tool_input}
                        yield StreamEvent.tool_use(tool_name, tool_input)
                    continue

                # --- Item completed ---
                if etype == "item/completed":
                    item = params.get("item", {})
                    item_id = params.get("itemId", "")

                    # Complete tool if we tracked it
                    tool_info = active_tools.pop(item_id, None)
                    if tool_info:
                        output = self._extract_tool_output(item)
                        yield StreamEvent.tool_result(tool_info["name"], output)

                    # Fallback: agent_message in completed (if no deltas received)
                    if item.get("type") == "agentMessage" and not accumulated_text:
                        text = item.get("text", "")
                        if text:
                            accumulated_text = text
                    continue

        except asyncio.TimeoutError:
            # Graceful interruption instead of kill
            if session.current_turn_id:
                await self._interrupt_turn(session, thread_id, session.current_turn_id)
            yield StreamEvent.error(f"Request timed out after {timeout}s")

        except Exception as e:
            log.exception("Codex server streaming error")
            yield StreamEvent.error(str(e))

        finally:
            session.current_turn_id = None
            yield StreamEvent.done()

    async def run_async(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
    ) -> AgentResult:
        """Non-streaming execution - collect streaming results."""
        output_parts = []
        error = None
        start_time = time.time()

        async for event in self.run_async_streaming(prompt, system_prompt, cwd, timeout, model):
            from otto.streaming import StreamEventType

            if event.type == StreamEventType.TEXT_DELTA:
                output_parts.append(event.content)
            elif event.type == StreamEventType.TEXT_COMPLETE:
                output_parts = [event.content]  # Replace with final
            elif event.type == StreamEventType.ERROR:
                error = event.error

        return AgentResult(
            success=error is None,
            output="".join(output_parts),
            error=error,
            backend=self.name,
            duration_seconds=time.time() - start_time,
        )

    def run_sync(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
    ) -> AgentResult:
        """Run synchronously by wrapping async."""
        return asyncio.run(self.run_async(prompt, system_prompt, cwd, timeout, model))

    async def close_all_sessions(self) -> None:
        """Close all active sessions."""
        async with self._lock:
            for session in self._sessions.values():
                await session.connection.close()
            self._sessions.clear()

    async def close_session(self, cwd: Path) -> bool:
        """Close session for a specific working directory."""
        async with self._lock:
            session = self._sessions.pop(cwd, None)
            if session:
                await session.connection.close()
                return True
            return False
