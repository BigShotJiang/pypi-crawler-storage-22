"""
Type definitions for backend abstraction.

Provides enums and type aliases used across all backends.
"""

from enum import Enum


class PermissionMode(Enum):
    """
    Unified permission modes across backends.

    Default is BYPASS for maximum automation. Users can dial down as needed.

    Mapping (most permissive to least):
    ┌───────────┬─────────────────────┬──────────────────────────┬─────────────┐
    │ Unified   │ Claude              │ Codex                    │ Gemini      │
    ├───────────┼─────────────────────┼──────────────────────────┼─────────────┤
    │ BYPASS    │ --dangerously-skip  │ --yolo                   │ --yolo      │
    │ FULL_AUTO │ --permission-mode   │ --full-auto              │ -y          │
    │           │   dontAsk           │                          │             │
    │ AUTO_EDIT │ --permission-mode   │ --ask-for-approval       │ --approval  │
    │           │   acceptEdits       │   on-failure             │   auto_edit │
    │ ASK       │ (default)           │ --ask-for-approval       │ (default)   │
    │           │                     │   untrusted              │             │
    │ READONLY  │ --permission-mode   │ --sandbox read-only      │ --approval  │
    │           │   plan              │                          │   plan      │
    └───────────┴─────────────────────┴──────────────────────────┴─────────────┘

    Note: Otto manages sessions, not the CLIs. Each backend invocation is stateless.
    Context is passed via system_prompt, not session resume.
    """

    BYPASS = "bypass"  # Skip all permissions (default)
    FULL_AUTO = "full_auto"  # Auto-approve within workspace
    AUTO_EDIT = "auto_edit"  # Auto-approve file edits only
    ASK = "ask"  # Prompt for approval
    READONLY = "readonly"  # Read-only, no writes


class OutputFormat(Enum):
    """Output format for backend responses."""

    TEXT = "text"  # Plain text (default for Claude --print)
    JSON = "json"  # JSON object
    STREAM_JSON = "stream_json"  # Streaming JSON events


# Default permission mode for all backends
DEFAULT_PERMISSION_MODE = PermissionMode.BYPASS
