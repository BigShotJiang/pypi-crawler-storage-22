"""
MCP Server Catalog — curated, vetted servers shipped with Otto.

The catalog is a static YAML file (otto/data/mcp_catalog.yaml) listing
recommended MCP servers with their default transport configs, required
environment variables, risk levels, and install hints.

Users reference catalog entries in settings.yaml via ``from_catalog``:

    gateway:
      servers:
        filesystem:
          from_catalog: filesystem
          enabled: true
          transport:
            args: ["/home/user/projects"]

This module provides:
- ``load_catalog()``: Load and cache the catalog
- ``get_catalog_entry()``: Look up a single server
- ``list_catalog()``: List all catalog entries
- ``resolve_from_catalog()``: Merge catalog defaults with user overrides
- ``validate_server_config()``: Validate a server config entry
- ``install_server()``: Add a catalog server to settings.yaml
- ``remove_server()``: Remove a server from settings.yaml
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

log = logging.getLogger(__name__)

# Catalog file path (shipped with Otto)
_CATALOG_PATH = Path(__file__).parent / "data" / "mcp_catalog.yaml"

# In-memory cache
_catalog_cache: dict[str, dict[str, Any]] | None = None


@dataclass
class CatalogEntry:
    """A single MCP server from the catalog."""

    name: str
    description: str = ""
    category: str = ""
    transport: dict[str, Any] = field(default_factory=dict)
    default_allowed_tools: list[str] | None = None
    default_blocked_tools: list[str] = field(default_factory=list)
    requires_env: list[str] = field(default_factory=list)
    install_hint: str = ""
    homepage: str = ""
    risk_level: str = "medium"  # low / medium / high
    recommended_policy: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, name: str, data: dict[str, Any]) -> CatalogEntry:
        return cls(
            name=name,
            description=data.get("description", ""),
            category=data.get("category", ""),
            transport=data.get("transport", {}),
            default_allowed_tools=data.get("default_allowed_tools"),
            default_blocked_tools=data.get("default_blocked_tools", []),
            requires_env=data.get("requires_env", []),
            install_hint=data.get("install_hint", ""),
            homepage=data.get("homepage", ""),
            risk_level=data.get("risk_level", "medium"),
            recommended_policy=data.get("recommended_policy", {}),
        )

    def check_env(self) -> list[str]:
        """Return list of missing required environment variables."""
        missing = []
        for var in self.requires_env:
            if not os.environ.get(var):
                # Also check .env file
                from otto.config import get_secret

                if not get_secret(var):
                    missing.append(var)
        return missing

    @property
    def risk_icon(self) -> str:
        return {"low": "🟢", "medium": "🟡", "high": "🔴"}.get(self.risk_level, "⚪")

    @property
    def category_icon(self) -> str:
        return {
            "filesystem": "📁",
            "search": "🔍",
            "dev": "🛠",
            "data": "🗄",
            "productivity": "📋",
        }.get(self.category, "📦")


def load_catalog() -> dict[str, dict[str, Any]]:
    """
    Load the MCP server catalog from the shipped YAML file.

    Returns a dict mapping server name -> raw catalog dict.
    Results are cached in memory.
    """
    global _catalog_cache
    if _catalog_cache is not None:
        return _catalog_cache

    if not _CATALOG_PATH.exists():
        log.warning("MCP catalog not found: %s", _CATALOG_PATH)
        _catalog_cache = {}
        return _catalog_cache

    try:
        raw = yaml.safe_load(_CATALOG_PATH.read_text()) or {}
    except Exception:
        log.error("Failed to parse MCP catalog", exc_info=True)
        _catalog_cache = {}
        return _catalog_cache

    # Filter out non-dict entries (YAML frontmatter artifacts, etc.)
    _catalog_cache = {k: v for k, v in raw.items() if isinstance(v, dict)}
    return _catalog_cache


def reload_catalog() -> dict[str, dict[str, Any]]:
    """Force-reload the catalog (clears cache)."""
    global _catalog_cache
    _catalog_cache = None
    return load_catalog()


def get_catalog_entry(name: str) -> CatalogEntry | None:
    """Look up a single server in the catalog by name."""
    catalog = load_catalog()
    data = catalog.get(name)
    if data is None:
        return None
    return CatalogEntry.from_dict(name, data)


def list_catalog(
    category: str | None = None,
) -> list[CatalogEntry]:
    """
    List all catalog entries, optionally filtered by category.

    Args:
        category: Filter by category (filesystem, search, dev, data, productivity)

    Returns:
        List of CatalogEntry objects, sorted by category then name.
    """
    catalog = load_catalog()
    entries = []
    for name, data in catalog.items():
        entry = CatalogEntry.from_dict(name, data)
        if category and entry.category != category:
            continue
        entries.append(entry)

    entries.sort(key=lambda e: (e.category, e.name))
    return entries


def list_categories() -> list[str]:
    """Return sorted list of unique categories in the catalog."""
    catalog = load_catalog()
    categories = set()
    for data in catalog.values():
        cat = data.get("category", "")
        if cat:
            categories.add(cat)
    return sorted(categories)


# ---------------------------------------------------------------------------
# Config resolution: merge catalog defaults with user overrides
# ---------------------------------------------------------------------------


def resolve_from_catalog(
    server_name: str,
    user_config: dict[str, Any],
) -> dict[str, Any]:
    """
    Merge catalog defaults with user overrides for a server config.

    If ``user_config`` has ``from_catalog: <name>``, loads the catalog
    entry and merges user overrides on top. User values always win.

    Args:
        server_name: The server name in settings.yaml
        user_config: The user's config dict for this server

    Returns:
        Fully resolved config dict ready for ServerPolicy construction.
    """
    catalog_ref = user_config.get("from_catalog")
    if not catalog_ref:
        return user_config

    entry = get_catalog_entry(str(catalog_ref))
    if entry is None:
        log.warning(
            "Server '%s' references unknown catalog entry '%s'",
            server_name,
            catalog_ref,
        )
        return user_config

    # Start with catalog defaults
    resolved: dict[str, Any] = {
        "enabled": user_config.get("enabled", True),
        "transport": dict(entry.transport),
        "builtin": False,
    }

    if entry.default_allowed_tools is not None:
        resolved["allowed_tools"] = list(entry.default_allowed_tools)
    if entry.default_blocked_tools:
        resolved["blocked_tools"] = list(entry.default_blocked_tools)

    # Inherit recommended_policy from catalog (used by PolicyEngine)
    if entry.recommended_policy:
        resolved["recommended_policy"] = dict(entry.recommended_policy)

    # User overrides — deep merge transport, shallow merge everything else
    for key, value in user_config.items():
        if key == "from_catalog":
            continue
        if key == "transport" and isinstance(value, dict):
            resolved["transport"].update(value)
        else:
            resolved[key] = value

    return resolved


# ---------------------------------------------------------------------------
# Config validation
# ---------------------------------------------------------------------------


@dataclass
class ValidationResult:
    """Result of validating a server config."""

    valid: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def validate_server_config(
    name: str,
    config: dict[str, Any],
) -> ValidationResult:
    """
    Validate a single server configuration entry.

    Checks:
    - Transport type is known (stdio, http, sse) or builtin flag
    - Stdio transport has a command
    - HTTP transport has a url
    - Required env vars are set (for catalog entries)
    - Tool lists are valid types

    Args:
        name: Server name
        config: Server config dict (after catalog resolution)

    Returns:
        ValidationResult with errors and warnings.
    """
    errors: list[str] = []
    warnings: list[str] = []

    if not isinstance(config, dict):
        return ValidationResult(valid=False, errors=[f"'{name}': config must be a dict"])

    # Builtin servers don't need transport
    if config.get("builtin"):
        return ValidationResult(valid=True, warnings=warnings)

    transport = config.get("transport", {})
    if not transport:
        errors.append(f"'{name}': missing transport config (or set builtin: true)")
        return ValidationResult(valid=False, errors=errors, warnings=warnings)

    transport_type = transport.get("type", "").lower()
    if transport_type not in ("stdio", "http", "sse"):
        errors.append(
            f"'{name}': unknown transport type '{transport_type}' (expected: stdio, http, sse)"
        )

    if transport_type == "stdio":
        if not transport.get("command"):
            errors.append(f"'{name}': stdio transport requires 'command'")

    if transport_type in ("http", "sse"):
        if not transport.get("url"):
            errors.append(f"'{name}': {transport_type} transport requires 'url'")

    # Validate tool lists
    allowed = config.get("allowed_tools")
    if allowed is not None and not isinstance(allowed, list):
        errors.append(f"'{name}': allowed_tools must be a list or null")

    blocked = config.get("blocked_tools")
    if blocked is not None and not isinstance(blocked, list):
        errors.append(f"'{name}': blocked_tools must be a list")

    # Check env vars if from catalog
    catalog_ref = config.get("from_catalog")
    if catalog_ref:
        entry = get_catalog_entry(str(catalog_ref))
        if entry:
            missing = entry.check_env()
            if missing:
                warnings.append(f"'{name}': missing env vars: {', '.join(missing)}")

    return ValidationResult(
        valid=len(errors) == 0,
        errors=errors,
        warnings=warnings,
    )


def validate_all_servers(
    servers_config: dict[str, Any],
) -> ValidationResult:
    """
    Validate all server configs in the gateway.servers section.

    Args:
        servers_config: The gateway.servers dict from settings.yaml

    Returns:
        Aggregate ValidationResult.
    """
    all_errors: list[str] = []
    all_warnings: list[str] = []

    for name, config in (servers_config or {}).items():
        if not isinstance(config, dict):
            all_errors.append(f"'{name}': config must be a dict, got {type(config).__name__}")
            continue

        # Resolve catalog references first
        resolved = resolve_from_catalog(name, config)
        result = validate_server_config(name, resolved)
        all_errors.extend(result.errors)
        all_warnings.extend(result.warnings)

    return ValidationResult(
        valid=len(all_errors) == 0,
        errors=all_errors,
        warnings=all_warnings,
    )


# ---------------------------------------------------------------------------
# Install / Remove servers in settings.yaml
# ---------------------------------------------------------------------------


def install_server(
    name: str,
    *,
    transport_overrides: dict[str, Any] | None = None,
    enabled: bool = True,
) -> tuple[bool, str]:
    """
    Add a catalog server to settings.yaml gateway.servers.

    Args:
        name: Catalog server name to install
        transport_overrides: Override transport args (e.g., different paths)
        enabled: Whether to enable the server immediately

    Returns:
        (success, message) tuple.
    """
    from otto.config import get_setting, set_setting

    entry = get_catalog_entry(name)
    if entry is None:
        return False, f"'{name}' not found in catalog"

    # Check if already configured
    existing = get_setting(f"gateway.servers.{name}")
    if existing:
        return False, f"'{name}' already configured in gateway.servers"

    # Build config
    server_config: dict[str, Any] = {
        "from_catalog": name,
        "enabled": enabled,
    }

    if transport_overrides:
        server_config["transport"] = transport_overrides

    set_setting(f"gateway.servers.{name}", server_config)

    # Check for missing env vars
    missing = entry.check_env()
    if missing:
        return True, (
            f"'{name}' installed but missing env vars: {', '.join(missing)}. "
            f"Set them in ~/.otto/config/.env"
        )

    return True, f"'{name}' installed and {'enabled' if enabled else 'disabled'}"


def remove_server(name: str) -> tuple[bool, str]:
    """
    Remove a server from settings.yaml gateway.servers.

    Args:
        name: Server name to remove

    Returns:
        (success, message) tuple.
    """
    from otto.config import load_settings, save_settings

    settings = load_settings()
    servers = settings.get("gateway", {}).get("servers", {})

    if name not in servers:
        return False, f"'{name}' not found in gateway.servers"

    del servers[name]

    # Also remove any per-server policy
    policy_servers = settings.get("gateway", {}).get("policy", {}).get("servers", {})
    policy_servers.pop(name, None)

    save_settings(settings)

    # Reload gateway so the server is immediately unavailable
    try:
        from otto.gateway import reload_gateway

        reload_gateway()
    except Exception as exc:
        log.warning("Gateway reload after remove failed: %s", exc)

    return True, f"'{name}' removed from gateway config"


# ---------------------------------------------------------------------------
# Test server connection
# ---------------------------------------------------------------------------


@dataclass
class TestResult:
    """Result of testing an MCP server connection."""

    server: str
    success: bool
    tools: list[str] = field(default_factory=list)
    error: str = ""
    latency_ms: float = 0.0

    @property
    def status_icon(self) -> str:
        return "✅" if self.success else "❌"


async def _test_server_async(name: str) -> TestResult:
    """
    Test connectivity to a configured MCP server.

    Spawns a temporary stdio connection, performs the MCP handshake,
    and fetches tools/list. Cleans up the connection afterwards.

    The server must already be configured in gateway.servers.
    """
    import asyncio
    import time

    from otto.gateway import StdioConnection, get_gateway

    gateway = get_gateway()
    servers = gateway.list_servers()
    policy = servers.get(name)

    if policy is None:
        return TestResult(server=name, success=False, error="Not configured in gateway.servers")
    if not policy.enabled:
        return TestResult(server=name, success=False, error="Server is disabled")
    if policy.builtin:
        # Builtin servers are always available
        return TestResult(server=name, success=True, tools=["(builtin)"])

    transport = policy.transport or {}
    transport_type = transport.get("type", "").lower()

    if transport_type != "stdio":
        return TestResult(
            server=name,
            success=False,
            error=f"Test only supports stdio transport, got '{transport_type}'",
        )

    command = transport.get("command")
    if not command:
        return TestResult(server=name, success=False, error="No command configured")

    args = transport.get("args", [])
    env = transport.get("env")

    conn: StdioConnection | None = None
    start = time.monotonic()
    try:
        conn = await asyncio.wait_for(
            StdioConnection.connect(name, command, args, env),
            timeout=30.0,
        )
        result = await asyncio.wait_for(
            conn.send_request("tools/list", {}),
            timeout=10.0,
        )
        elapsed = (time.monotonic() - start) * 1000
        tools = [t.get("name", "?") for t in result.get("tools", [])]
        return TestResult(
            server=name,
            success=True,
            tools=tools,
            latency_ms=round(elapsed, 1),
        )
    except asyncio.TimeoutError:
        elapsed = (time.monotonic() - start) * 1000
        return TestResult(
            server=name,
            success=False,
            error="Connection timed out (30s)",
            latency_ms=round(elapsed, 1),
        )
    except Exception as exc:
        elapsed = (time.monotonic() - start) * 1000
        return TestResult(
            server=name,
            success=False,
            error=str(exc),
            latency_ms=round(elapsed, 1),
        )
    finally:
        if conn is not None:
            try:
                await conn.close()
            except Exception:
                pass


def test_server(name: str) -> TestResult:
    """
    Synchronous wrapper for testing an MCP server connection.

    Spawns a fresh connection (not from the gateway pool), performs
    the MCP initialize handshake and tools/list, then tears it down.
    """
    import asyncio

    return asyncio.run(_test_server_async(name))


async def test_all_servers() -> list[TestResult]:
    """Test all enabled, non-builtin servers."""
    import asyncio

    from otto.gateway import get_gateway

    gateway = get_gateway()
    servers = gateway.list_servers()

    tasks = []
    for name, policy in servers.items():
        if policy.enabled and not policy.builtin:
            tasks.append(_test_server_async(name))

    if not tasks:
        return []

    return list(await asyncio.gather(*tasks, return_exceptions=False))


__all__ = [
    "CatalogEntry",
    "ValidationResult",
    "TestResult",
    "load_catalog",
    "reload_catalog",
    "get_catalog_entry",
    "list_catalog",
    "list_categories",
    "resolve_from_catalog",
    "validate_server_config",
    "validate_all_servers",
    "install_server",
    "remove_server",
    "test_server",
    "test_all_servers",
]
