"""
Chat platform abstraction for Otto.

Provides a unified interface for different chat platforms (Telegram, Signal, etc.)
while sharing core logic like agent execution, sessions, and memory.

Platform implementations:
- TelegramPlatform: Rich UI with inline keyboards, buttons, HTML formatting
- SignalPlatform: Plain text with numbered menus and text-based confirmations

Adapters provide composable capabilities and security:
- CapabilitiesAdapter: Check platform features before using them
- SecurityAdapter: Authorization, permissions, and security context
"""

from .adapters import (
    CapabilitiesAdapter,
    Capability,
    Permission,
    SecurityAdapter,
    SecurityContext,
    SecurityLevel,
)
from .base import ChatContext, ChatMessage, ChatPlatform, PlatformCapabilities
from .commands import CommandHandler, CommandResult, CommandRouter, get_command_router
from .core import ChatCore

__all__ = [
    # Base classes
    "ChatPlatform",
    "PlatformCapabilities",
    "ChatContext",
    "ChatMessage",
    # Core logic
    "ChatCore",
    # Commands
    "CommandRouter",
    "CommandHandler",
    "CommandResult",
    "get_command_router",
    # Adapters
    "CapabilitiesAdapter",
    "Capability",
    "SecurityAdapter",
    "SecurityContext",
    "Permission",
    "SecurityLevel",
]
