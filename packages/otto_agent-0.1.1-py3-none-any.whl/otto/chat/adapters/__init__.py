"""
Chat platform adapters for capabilities and security.

Inspired by OpenClaw's composable adapter pattern - allows platforms to
declare capabilities and enforce security independently.
"""

from .capabilities import CapabilitiesAdapter, Capability
from .security import Permission, SecurityAdapter, SecurityContext, SecurityLevel

__all__ = [
    "CapabilitiesAdapter",
    "Capability",
    "SecurityAdapter",
    "SecurityContext",
    "Permission",
    "SecurityLevel",
]
