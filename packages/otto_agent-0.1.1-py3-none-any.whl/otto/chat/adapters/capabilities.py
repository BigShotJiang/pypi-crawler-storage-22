"""
Capabilities adapter for chat platforms.

Provides a composable way to check and enforce platform capabilities
before executing actions. This prevents runtime errors from calling
unsupported features on platforms that don't have them.

Usage:
    adapter = CapabilitiesAdapter(platform)

    if adapter.can(Capability.INLINE_KEYBOARDS):
        await platform.send_message(..., reply_markup=keyboard)
    else:
        await platform.send_message(..., text=text_fallback)
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum, auto
from typing import TYPE_CHECKING, Any, TypeVar

if TYPE_CHECKING:
    from ..base import ChatPlatform


class Capability(Enum):
    """Enumeration of all possible platform capabilities."""

    # Rich UI
    INLINE_KEYBOARDS = auto()
    BUTTONS = auto()
    RICH_FORMATTING = auto()

    # Media
    VOICE_MESSAGES = auto()
    FILE_ATTACHMENTS = auto()
    PHOTOS = auto()

    # Interaction
    EDIT_MESSAGES = auto()
    REACTIONS = auto()
    TYPING_INDICATOR = auto()

    # Threading (future)
    THREADS = auto()
    REPLIES = auto()

    # Groups (future)
    GROUP_CHATS = auto()
    CHANNEL_POSTS = auto()


# Mapping from Capability enum to PlatformCapabilities attribute
_CAPABILITY_MAP: dict[Capability, str] = {
    Capability.INLINE_KEYBOARDS: "inline_keyboards",
    Capability.BUTTONS: "buttons",
    Capability.RICH_FORMATTING: "rich_formatting",
    Capability.VOICE_MESSAGES: "voice_messages",
    Capability.FILE_ATTACHMENTS: "file_attachments",
    Capability.PHOTOS: "photos",
    Capability.EDIT_MESSAGES: "edit_messages",
    Capability.REACTIONS: "reactions",
    Capability.TYPING_INDICATOR: "typing_indicator",
}


@dataclass
class CapabilityCheck:
    """Result of a capability check with optional fallback."""

    supported: bool
    capability: Capability
    fallback: Any = None

    def __bool__(self) -> bool:
        return self.supported


class CapabilitiesAdapter:
    """
    Adapter for checking and enforcing platform capabilities.

    Provides a clean interface for checking what a platform supports
    before attempting to use features. Supports fallback patterns.
    """

    def __init__(self, platform: ChatPlatform):
        self.platform = platform
        self._capabilities = platform.capabilities

    def can(self, capability: Capability) -> bool:
        """Check if the platform supports a capability."""
        attr_name = _CAPABILITY_MAP.get(capability)
        if attr_name is None:
            # Unknown capability, assume not supported
            return False
        return getattr(self._capabilities, attr_name, False)

    def check(self, capability: Capability, fallback: Any = None) -> CapabilityCheck:
        """
        Check a capability with an optional fallback value.

        Usage:
            check = adapter.check(Capability.INLINE_KEYBOARDS, fallback=None)
            if check:
                # Use inline keyboards
            else:
                # Use check.fallback
        """
        return CapabilityCheck(
            supported=self.can(capability),
            capability=capability,
            fallback=fallback,
        )

    def require(self, capability: Capability) -> None:
        """
        Require a capability, raising if not supported.

        Raises:
            CapabilityNotSupportedError: If the capability is not available.
        """
        if not self.can(capability):
            raise CapabilityNotSupportedError(
                f"Platform '{self.platform.name}' does not support {capability.name}"
            )

    def all_of(self, *capabilities: Capability) -> bool:
        """Check if ALL of the given capabilities are supported."""
        return all(self.can(cap) for cap in capabilities)

    def any_of(self, *capabilities: Capability) -> bool:
        """Check if ANY of the given capabilities are supported."""
        return any(self.can(cap) for cap in capabilities)

    @property
    def max_message_length(self) -> int:
        """Get the maximum message length for this platform."""
        return self._capabilities.max_message_length

    def list_supported(self) -> list[Capability]:
        """List all supported capabilities."""
        return [cap for cap in Capability if self.can(cap)]

    def list_unsupported(self) -> list[Capability]:
        """List all unsupported capabilities."""
        return [cap for cap in Capability if not self.can(cap)]

    def to_dict(self) -> dict[str, bool]:
        """Export capabilities as a dictionary."""
        return {cap.name.lower(): self.can(cap) for cap in Capability}


class CapabilityNotSupportedError(Exception):
    """Raised when a required capability is not supported by the platform."""

    pass


# Decorator for requiring capabilities
F = TypeVar("F", bound=Callable[..., Any])


def requires_capability(*capabilities: Capability) -> Callable[[F], F]:
    """
    Decorator to mark a function as requiring certain capabilities.

    Usage:
        @requires_capability(Capability.INLINE_KEYBOARDS)
        async def send_keyboard_menu(ctx, ...):
            ...

    Note: The decorated function must receive a context with a
    CapabilitiesAdapter accessible.
    """

    def decorator(func: F) -> F:
        func._required_capabilities = capabilities  # type: ignore
        return func

    return decorator
