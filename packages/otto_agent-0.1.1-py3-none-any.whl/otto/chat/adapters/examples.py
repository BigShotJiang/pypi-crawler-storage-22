"""
Example usage of capabilities and security adapters.

This file demonstrates how to integrate the adapters with a ChatPlatform
implementation. Not used in production - just documentation.
"""

# Example: Using CapabilitiesAdapter with a platform
"""
from otto.chat import ChatPlatform, CapabilitiesAdapter, Capability

class TelegramPlatform(ChatPlatform):
    def __init__(self):
        self.capabilities_adapter = CapabilitiesAdapter(self)

    async def send_menu(self, chat_id: str, options: list[str]):
        # Check if we can use inline keyboards
        if self.capabilities_adapter.can(Capability.INLINE_KEYBOARDS):
            keyboard = self._build_inline_keyboard(options)
            await self.send_message(chat_id, "Choose:", reply_markup=keyboard)
        else:
            # Fallback to numbered text list
            text = "Choose:\n" + "\n".join(f"{i+1}. {opt}" for i, opt in enumerate(options))
            await self.send_message(chat_id, text)
"""

# Example: Using SecurityAdapter with config
"""
from otto import config as otto_config
from otto.chat import SecurityAdapter, Permission

# Create adapter with config module
security = SecurityAdapter(config_module=otto_config)

async def handle_message(ctx: ChatContext):
    # Create security context for this request
    sec_ctx = security.create_context(
        user_id=ctx.message.user_id,
        platform=ctx.platform.name,
    )
    ctx.security = sec_ctx

    # Now permission checks work
    if ctx.has_permission(Permission.USE_AGENT):
        await process_with_agent(ctx)
    else:
        await ctx.reply("You don't have permission to use the agent.")
"""

# Example: Protecting commands with permissions
"""
from otto.chat.commands import router, CommandResult
from otto.chat import Permission

@router.register("/admin", permission=Permission.EXECUTE_ADMIN_COMMANDS)
async def admin_command(ctx: ChatContext, args: str) -> CommandResult:
    # Only runs if user has EXECUTE_ADMIN_COMMANDS
    return CommandResult(success=True, message="Admin action completed")
"""

# Example: Checking multiple capabilities
"""
async def send_rich_response(ctx: ChatContext, text: str, file_path: Path):
    caps = CapabilitiesAdapter(ctx.platform)

    # Send file if supported
    if caps.can(Capability.FILE_ATTACHMENTS):
        await ctx.platform.send_file(ctx.message.chat_id, file_path, caption=text)
    else:
        # Just send text
        await ctx.reply(f"{text}\n\n(File: {file_path.name})")

    # Add reaction if supported
    if caps.can(Capability.REACTIONS):
        await ctx.platform.add_reaction(ctx.message.message_id, "✅")
"""
