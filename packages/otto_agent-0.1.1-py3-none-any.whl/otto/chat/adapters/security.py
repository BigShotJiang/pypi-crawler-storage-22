"""
Security adapter for chat platforms.

Provides authorization, permission checking, and security context
for all chat operations. Designed to be composable and extensible.

Security Model:
- SecurityLevel: Hierarchical access levels (owner > admin > user > guest)
- Permission: Granular permissions for specific actions
- SecurityContext: Per-request security state attached to ChatContext

Usage:
    adapter = SecurityAdapter(config_module=otto_config)

    # Check authorization
    if adapter.is_authorized(user_id):
        ctx = adapter.create_context(user_id, platform="telegram")

        # Check specific permissions
        if ctx.has_permission(Permission.EXECUTE_COMMANDS):
            await handle_command(ctx, ...)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from types import ModuleType


class SecurityLevel(Enum):
    """Hierarchical security levels."""

    OWNER = 100  # Full access, can manage users
    ADMIN = 80  # Most access, can't manage owner settings
    USER = 50  # Standard access, allowed in allowlist
    GUEST = 20  # Limited access, rate-limited
    BLOCKED = 0  # No access


class Permission(Enum):
    """Granular permissions for specific actions."""

    # Message handling
    SEND_MESSAGES = auto()
    READ_MESSAGES = auto()

    # Commands
    EXECUTE_COMMANDS = auto()
    EXECUTE_ADMIN_COMMANDS = auto()

    # Agent interaction
    USE_AGENT = auto()
    SWITCH_BACKEND = auto()

    # File operations
    SEND_FILES = auto()
    DOWNLOAD_FILES = auto()

    # Memory
    ACCESS_MEMORY = auto()
    WRITE_MEMORY = auto()

    # Session management
    MANAGE_SESSIONS = auto()
    CLEAR_HISTORY = auto()

    # Admin actions
    MANAGE_USERS = auto()
    VIEW_LOGS = auto()
    RESTART_SERVICES = auto()

    # Jobs and agents
    CREATE_JOBS = auto()
    VIEW_JOBS = auto()
    CANCEL_JOBS = auto()

    # MCP tools
    USE_MCP_TOOLS = auto()
    MANAGE_MCP_SERVERS = auto()


# Default permission sets for each security level
DEFAULT_PERMISSIONS: dict[SecurityLevel, set[Permission]] = {
    SecurityLevel.OWNER: set(Permission),  # All permissions
    SecurityLevel.ADMIN: {
        Permission.SEND_MESSAGES,
        Permission.READ_MESSAGES,
        Permission.EXECUTE_COMMANDS,
        Permission.EXECUTE_ADMIN_COMMANDS,
        Permission.USE_AGENT,
        Permission.SWITCH_BACKEND,
        Permission.SEND_FILES,
        Permission.DOWNLOAD_FILES,
        Permission.ACCESS_MEMORY,
        Permission.WRITE_MEMORY,
        Permission.MANAGE_SESSIONS,
        Permission.CLEAR_HISTORY,
        Permission.VIEW_LOGS,
        Permission.CREATE_JOBS,
        Permission.VIEW_JOBS,
        Permission.CANCEL_JOBS,
        Permission.USE_MCP_TOOLS,
    },
    SecurityLevel.USER: {
        Permission.SEND_MESSAGES,
        Permission.READ_MESSAGES,
        Permission.EXECUTE_COMMANDS,
        Permission.USE_AGENT,
        Permission.SEND_FILES,
        Permission.DOWNLOAD_FILES,
        Permission.ACCESS_MEMORY,
        Permission.MANAGE_SESSIONS,
        Permission.CLEAR_HISTORY,
        Permission.VIEW_JOBS,
        Permission.USE_MCP_TOOLS,
    },
    SecurityLevel.GUEST: {
        Permission.SEND_MESSAGES,
        Permission.READ_MESSAGES,
    },
    SecurityLevel.BLOCKED: set(),
}


@dataclass
class SecurityContext:
    """
    Security context for a single request/message.

    Attached to ChatContext to provide authorization info throughout
    the request lifecycle.
    """

    user_id: str
    platform: str
    level: SecurityLevel
    permissions: set[Permission] = field(default_factory=set)

    # Metadata
    created_at: datetime = field(default_factory=datetime.now)
    session_id: str | None = None

    # True when this request claimed ownership during initial bootstrap.
    bootstrapped_owner: bool = False

    # Restrictions (for rate limiting, feature flags, etc.)
    restrictions: dict[str, Any] = field(default_factory=dict)

    def has_permission(self, permission: Permission) -> bool:
        """Check if this context has a specific permission."""
        return permission in self.permissions

    def has_all_permissions(self, *permissions: Permission) -> bool:
        """Check if this context has ALL of the given permissions."""
        return all(p in self.permissions for p in permissions)

    def has_any_permission(self, *permissions: Permission) -> bool:
        """Check if this context has ANY of the given permissions."""
        return any(p in self.permissions for p in permissions)

    def require_permission(self, permission: Permission) -> None:
        """Require a permission, raising if not present."""
        if not self.has_permission(permission):
            raise PermissionDeniedError(
                f"Permission {permission.name} required (user: {self.user_id}, level: {self.level.name})"
            )

    def require_level(self, minimum_level: SecurityLevel) -> None:
        """Require at least a certain security level."""
        if self.level.value < minimum_level.value:
            raise PermissionDeniedError(
                f"Security level {minimum_level.name} required, user has {self.level.name}"
            )

    @property
    def is_owner(self) -> bool:
        """Check if this is the owner."""
        return self.level == SecurityLevel.OWNER

    @property
    def is_admin(self) -> bool:
        """Check if this is an admin or higher."""
        return self.level.value >= SecurityLevel.ADMIN.value

    @property
    def is_authorized(self) -> bool:
        """Check if this user is authorized (not blocked/guest)."""
        return self.level.value >= SecurityLevel.USER.value


class SecurityAdapter:
    """
    Adapter for authorization and permission management.

    Uses the central config module for user data but provides
    a clean, testable interface for security operations.
    """

    def __init__(
        self,
        config_module: ModuleType | None = None,
        owner_id: str | None = None,
        admin_ids: set[str] | None = None,
    ):
        """
        Initialize the security adapter.

        Args:
            config_module: The otto.config module (or compatible mock)
            owner_id: Override owner ID (useful for testing)
            admin_ids: Set of admin user IDs
        """
        self._config = config_module
        self._owner_id = owner_id
        self._admin_ids = admin_ids or set()

        # Custom permission overrides per user
        self._permission_overrides: dict[str, set[Permission]] = {}

        # Blocked users (in addition to config)
        self._blocked_users: set[str] = set()

    def _get_owner_id(self) -> str | None:
        """Get the owner user ID from config or override."""
        if self._owner_id:
            return self._owner_id
        if self._config:
            owner = self._config.get_setting("access.owner_id")
            return str(owner) if owner else None
        return None

    def _maybe_bootstrap_owner(self, user_id: str, platform: str, user_name: str | None) -> bool:
        """
        Bootstrap ownership when no allowlist exists yet.

        For now this is only supported for Telegram, since otto.config stores
        Telegram user IDs under `access.*`.
        """
        if not self._config:
            return False

        if platform.lower() != "telegram":
            return False

        owner_id = self._config.get_setting("access.owner_id")
        allowed_users = self._config.get_setting("access.allowed_users", [])
        if owner_id or allowed_users:
            return False

        try:
            telegram_user_id = int(user_id)
        except ValueError:
            return False

        return bool(self._config.bootstrap_owner_if_needed(telegram_user_id, user_name or ""))

    def _get_allowed_user_ids(self) -> set[str]:
        """Get allowed user IDs from config."""
        if self._config:
            return {str(uid) for uid in self._config.get_allowed_user_ids()}
        return set()

    def get_security_level(self, user_id: str) -> SecurityLevel:
        """Determine the security level for a user."""
        user_id = str(user_id)

        # Check blocked first
        if user_id in self._blocked_users:
            return SecurityLevel.BLOCKED

        # Check owner
        owner_id = self._get_owner_id()
        if owner_id and user_id == owner_id:
            return SecurityLevel.OWNER

        # Check admin
        if user_id in self._admin_ids:
            return SecurityLevel.ADMIN

        # Check allowed users
        if user_id in self._get_allowed_user_ids():
            return SecurityLevel.USER

        # Default to guest
        return SecurityLevel.GUEST

    def is_authorized(self, user_id: str) -> bool:
        """Check if a user is authorized (user level or higher)."""
        level = self.get_security_level(str(user_id))
        return level.value >= SecurityLevel.USER.value

    def get_permissions(self, user_id: str) -> set[Permission]:
        """Get all permissions for a user."""
        user_id = str(user_id)
        level = self.get_security_level(user_id)

        # Start with default permissions for this level
        permissions = DEFAULT_PERMISSIONS.get(level, set()).copy()

        # Apply any overrides
        if user_id in self._permission_overrides:
            permissions.update(self._permission_overrides[user_id])

        return permissions

    def create_context(
        self,
        user_id: str,
        platform: str,
        *,
        user_name: str | None = None,
        session_id: str | None = None,
        restrictions: dict[str, Any] | None = None,
    ) -> SecurityContext:
        """Create a security context for a request."""
        user_id = str(user_id)

        bootstrapped_owner = self._maybe_bootstrap_owner(user_id, platform, user_name)

        level = self.get_security_level(user_id)
        permissions = self.get_permissions(user_id)

        return SecurityContext(
            user_id=user_id,
            platform=platform,
            level=level,
            permissions=permissions,
            session_id=session_id,
            bootstrapped_owner=bootstrapped_owner,
            restrictions=restrictions or {},
        )

    # User management (for owner/admin use)
    def block_user(self, user_id: str) -> None:
        """Block a user."""
        self._blocked_users.add(str(user_id))

    def unblock_user(self, user_id: str) -> None:
        """Unblock a user."""
        self._blocked_users.discard(str(user_id))

    def add_admin(self, user_id: str) -> None:
        """Add an admin."""
        self._admin_ids.add(str(user_id))

    def remove_admin(self, user_id: str) -> None:
        """Remove admin status."""
        self._admin_ids.discard(str(user_id))

    def grant_permission(self, user_id: str, permission: Permission) -> None:
        """Grant a specific permission to a user."""
        user_id = str(user_id)
        if user_id not in self._permission_overrides:
            self._permission_overrides[user_id] = set()
        self._permission_overrides[user_id].add(permission)

    def revoke_permission(self, user_id: str, permission: Permission) -> None:
        """Revoke a specific permission from a user."""
        user_id = str(user_id)
        if user_id in self._permission_overrides:
            self._permission_overrides[user_id].discard(permission)


class PermissionDeniedError(Exception):
    """Raised when a required permission is not present."""

    pass
