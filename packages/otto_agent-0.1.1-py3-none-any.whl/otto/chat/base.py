"""
Base classes and interfaces for chat platform abstraction.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any


@dataclass
class PlatformCapabilities:
    """Describes what a chat platform can do."""

    # Rich UI features
    inline_keyboards: bool = False
    buttons: bool = False
    rich_formatting: bool = False  # HTML/markdown support

    # Media handling
    voice_messages: bool = True
    file_attachments: bool = True
    photos: bool = True

    # Interaction patterns
    edit_messages: bool = False
    reactions: bool = False
    typing_indicator: bool = False

    # Message limits
    max_message_length: int = 4000


@dataclass
class ChatMessage:
    """Represents a message in the chat."""

    text: str
    user_id: str
    user_name: str
    chat_id: str
    platform: str

    # Optional attachments
    photo_path: Path | None = None
    voice_path: Path | None = None
    file_path: Path | None = None

    # Platform-specific metadata
    raw_message: Any = None
    message_id: str | None = None


@dataclass
class ChatContext:
    """Context passed to handlers and core logic."""

    message: ChatMessage
    platform: ChatPlatform

    # For stateful flows
    user_data: dict = field(default_factory=dict)

    # Security context (optional, set by platform if using SecurityAdapter)
    security: SecurityContext | None = None

    async def reply(self, text: str, **kwargs) -> Any:
        """Reply to the message."""
        return await self.platform.send_message(self.message.chat_id, text, **kwargs)

    async def send_file(self, file_path: Path, caption: str | None = None, **kwargs) -> Any:
        """Send a file attachment to this chat."""
        return await self.platform.send_file(
            self.message.chat_id, file_path, caption=caption, **kwargs
        )

    async def send_typing(self):
        """Send typing indicator if supported."""
        if self.platform.capabilities.typing_indicator:
            await self.platform.send_typing(self.message.chat_id)

    def has_permission(self, permission: Permission) -> bool:
        """Check if the current user has a permission."""
        if self.security is None:
            # No security context = allow everything (legacy mode)
            return True
        return self.security.has_permission(permission)

    def require_permission(self, permission: Permission) -> None:
        """Require a permission, raising PermissionDeniedError if not present."""
        if self.security is None:
            return  # Legacy mode, allow
        self.security.require_permission(permission)

    @property
    def is_owner(self) -> bool:
        """Check if the current user is the owner."""
        if self.security is None:
            return True  # Legacy mode
        return self.security.is_owner

    @property
    def is_admin(self) -> bool:
        """Check if the current user is an admin or higher."""
        if self.security is None:
            return True  # Legacy mode
        return self.security.is_admin


# Forward reference imports for type hints
if TYPE_CHECKING:
    from .adapters.security import Permission, SecurityContext


class ChatPlatform(ABC):
    """
    Abstract base class for chat platforms.

    Each platform (Telegram, Signal, Discord, etc.) implements this interface.
    The ChatCore handles shared logic (agent execution, sessions, memory).
    """

    name: str  # Platform identifier ("telegram", "signal", etc.)
    capabilities: PlatformCapabilities

    @abstractmethod
    async def send_message(
        self,
        chat_id: str,
        text: str,
        parse_mode: str | None = None,
        reply_markup: Any = None,
        **kwargs,
    ) -> Any:
        """Send a text message."""
        pass

    @abstractmethod
    async def send_typing(self, chat_id: str) -> None:
        """Send typing indicator."""
        pass

    @abstractmethod
    async def edit_message(self, chat_id: str, message_id: str, text: str, **kwargs) -> Any:
        """Edit an existing message. Raise if not supported."""
        pass

    async def delete_message(self, chat_id: str, message_id: str) -> bool:
        """Delete a message. Returns True if successful, False otherwise.

        Default implementation does nothing (not all platforms support deletion).
        """
        return False

    @abstractmethod
    async def send_file(
        self, chat_id: str, file_path: Path, caption: str | None = None, **kwargs
    ) -> Any:
        """Send a file attachment."""
        pass

    @abstractmethod
    async def download_file(self, file_id: str, destination: Path) -> Path:
        """Download a file from the platform."""
        pass

    def format_text(
        self, text: str, bold: bool = False, code: bool = False, pre: bool = False
    ) -> str:
        """
        Format text for this platform.

        Default: no formatting (plain text).
        Override in platform-specific implementations for rich text.
        """
        if pre:
            return f"```\n{text}\n```"
        if code:
            return f"`{text}`"
        if bold:
            return f"*{text}*"
        return text

    def strip_formatting(self, text: str) -> str:
        """Strip platform-specific formatting from text."""
        return text

    @abstractmethod
    async def start(self) -> None:
        """Start the platform (connect, register handlers, etc.)."""
        pass

    @abstractmethod
    async def stop(self) -> None:
        """Stop the platform gracefully."""
        pass
