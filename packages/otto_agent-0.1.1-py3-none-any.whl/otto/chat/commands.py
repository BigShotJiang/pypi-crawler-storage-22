"""
Command router for handling slash commands across platforms.

Commands are text-based responses that don't require LLM processing.
Works for both rich platforms (Telegram) and simple ones (Signal).
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

from .base import ChatContext


@dataclass
class CommandResult:
    """Result of a command execution.

    Commands return structured data that platforms render appropriately:
    - Telegram: Inline keyboards, buttons, interactive menus
    - Signal: Text-based menus, numbered options, plain text
    """

    text: str
    success: bool = True

    # Structured data for rich rendering
    data: Any = None  # Arbitrary structured data
    options: list[dict[str, Any]] | None = None  # [{id, label, description?}]
    action: str | None = None  # "confirm", "select", "input"

    # For stateful flows (callbacks)
    next_handler: str | None = None  # Callback to invoke on response

    # Legacy button support (deprecated, use options instead)
    buttons: list[dict[str, str]] | None = None  # [{label, callback_data}]

    # Platform-specific passthrough (e.g., Telegram InlineKeyboardMarkup)
    reply_markup: Any | None = None

    @classmethod
    def ok(cls, text: str, **kwargs) -> CommandResult:
        return cls(text=text, success=True, **kwargs)

    @classmethod
    def error(cls, text: str) -> CommandResult:
        return cls(text=text, success=False)

    @classmethod
    def confirm(cls, text: str, handler: str, **kwargs) -> CommandResult:
        """Create a confirmation prompt."""
        return cls(text=text, success=True, action="confirm", next_handler=handler, **kwargs)

    @classmethod
    def select(
        cls, text: str, options: list[dict[str, Any]], handler: str, **kwargs
    ) -> CommandResult:
        """Create a selection prompt."""
        return cls(
            text=text,
            success=True,
            action="select",
            options=options,
            next_handler=handler,
            **kwargs,
        )


# Type alias for command handlers
CommandHandler = Callable[[ChatContext, list[str]], Awaitable[CommandResult]]


# Type alias for callback handlers
CallbackHandler = Callable[[ChatContext, str], Awaitable[CommandResult]]


class CommandRouter:
    """
    Routes slash commands to handlers.

    Usage:
        router = CommandRouter()

        @router.command("help")
        async def cmd_help(ctx, args):
            return CommandResult.ok("Help text here...")

        @router.callback("backend")
        async def cb_backend(ctx, value):
            # value is the selected option (e.g., "claude")
            return CommandResult.ok(f"Switched to {value}")

        # In message handler:
        result = await router.handle(ctx, "/help")

        # In callback handler:
        result = await router.handle_callback(ctx, "backend", "claude")
    """

    def __init__(self):
        self._handlers: dict[str, CommandHandler] = {}
        self._callbacks: dict[str, CallbackHandler] = {}
        self._aliases: dict[str, str] = {}

    def command(self, name: str, aliases: list[str] | None = None):
        """Decorator to register a command handler."""

        def decorator(func: CommandHandler) -> CommandHandler:
            self._handlers[name.lower()] = func
            if aliases:
                for alias in aliases:
                    self._aliases[alias.lower()] = name.lower()
            return func

        return decorator

    def callback(self, action: str):
        """Decorator to register a callback handler.

        Callbacks are invoked when a user responds to an interactive element
        (button press, selection, etc.)

        Args:
            action: The callback action name (e.g., "backend", "restart")

        Example:
            @router.callback("backend")
            async def cb_backend(ctx, value):
                # value is the selection (e.g., "claude")
                set_active_backend(value)
                return CommandResult.ok(f"Switched to {value}")
        """

        def decorator(func: CallbackHandler) -> CallbackHandler:
            self._callbacks[action.lower()] = func
            return func

        return decorator

    def register_callback(self, action: str, handler: CallbackHandler) -> None:
        """Register a callback handler programmatically."""
        self._callbacks[action.lower()] = handler

    def register(
        self, name: str, handler: CommandHandler, aliases: list[str] | None = None
    ) -> None:
        """Register a command handler programmatically."""
        self._handlers[name.lower()] = handler
        if aliases:
            for alias in aliases:
                self._aliases[alias.lower()] = name.lower()

    def is_command(self, text: str) -> bool:
        """Check if text is a command."""
        return text.strip().startswith("/")

    def parse_command(self, text: str) -> tuple[str, list[str]]:
        """Parse command name and arguments from text."""
        text = text.strip()
        if not text.startswith("/"):
            return "", []

        parts = text.split()
        cmd = parts[0][1:].lower()  # Remove leading /
        args = parts[1:] if len(parts) > 1 else []

        return cmd, args

    async def handle(self, ctx: ChatContext, text: str) -> CommandResult | None:
        """
        Handle a command if text is a valid command.

        Returns None if not a command or command not found.
        """
        if not self.is_command(text):
            return None

        cmd, args = self.parse_command(text)

        # Resolve aliases
        if cmd in self._aliases:
            cmd = self._aliases[cmd]

        # Find handler
        handler = self._handlers.get(cmd)
        if not handler:
            return CommandResult.error(
                f"Unknown command: /{cmd}\n\nUse /help for available commands."
            )

        try:
            return await handler(ctx, args)
        except Exception as e:
            return CommandResult.error(f"Command error: {e}")

    async def handle_callback(
        self, ctx: ChatContext, action: str, value: str | None = None
    ) -> CommandResult:
        """
        Handle a callback (button press, selection) for a command.

        Args:
            ctx: Chat context
            action: The callback action name (e.g., "backend")
            value: The selected value (e.g., "claude")

        Returns:
            CommandResult with the response
        """
        handler = self._callbacks.get(action.lower())
        if not handler:
            return CommandResult.error(f"Unknown callback: {action}")

        try:
            return await handler(ctx, value or "")
        except Exception as e:
            return CommandResult.error(f"Callback error: {e}")

    def list_commands(self) -> list[str]:
        """Get list of registered commands."""
        return list(self._handlers.keys())

    def list_callbacks(self) -> list[str]:
        """Get list of registered callback handlers."""
        return list(self._callbacks.keys())


# Global command router instance
_router: CommandRouter | None = None


def get_command_router() -> CommandRouter:
    """Get the global command router."""
    global _router
    if _router is None:
        _router = CommandRouter()
        _register_core_commands(_router)
    return _router


def _register_core_commands(router: CommandRouter) -> None:
    """Register core commands that work across all platforms."""
    from otto import (
        delete_session,
        get_current_session,
        list_sessions,
        memory_search_formatted,
        memory_stats,
        new_session,
    )
    from otto.backends import get_active_backend_name, list_backends

    def _relative_time(iso_str: str | None) -> str:
        """Convert an ISO timestamp to a human-readable relative time."""
        if not iso_str:
            return ""
        try:
            from datetime import datetime, timezone

            dt = datetime.fromisoformat(iso_str)
            if dt.tzinfo is None:
                # Timestamps are stored as naive local time, compare with local now
                now = datetime.now()
            else:
                now = datetime.now(timezone.utc)
            diff = now - dt
            secs = int(diff.total_seconds())
            if secs < 0:
                return "just now"
            if secs < 60:
                return "just now"
            if secs < 3600:
                return f"{secs // 60}m ago"
            if secs < 86400:
                return f"{secs // 3600}h ago"
            d = secs // 86400
            if d == 1:
                return "yesterday"
            if d < 30:
                return f"{d}d ago"
            return f"{d // 30}mo ago"
        except Exception:
            return ""

    @router.command("help")
    async def cmd_help(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Show interactive help menu with categories."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        text = (
            "<b>Otto Commands</b>\n\n"
            "<b>Conversations</b> — Sessions, new, stop\n"
            "<b>AI &amp; Agents</b> — Backend, thinking, agents\n"
            "<b>Memory &amp; Tasks</b> — Memory, tasks, polls, jobs\n"
            "<b>MCP &amp; Tools</b> — MCP, activity, audit, pause\n"
            "<b>System</b> — Status, VTT, reindex, restart\n\n"
            "<i>Tap a category or quick-launch below.</i>"
        )

        buttons = [
            [
                InlineKeyboardButton("Conversations", callback_data="help_cat:conv"),
                InlineKeyboardButton("AI & Agents", callback_data="help_cat:ai"),
            ],
            [
                InlineKeyboardButton("Memory & Tasks", callback_data="help_cat:mem"),
                InlineKeyboardButton("MCP & Tools", callback_data="help_cat:tools"),
                InlineKeyboardButton("System", callback_data="help_cat:sys"),
            ],
            [
                InlineKeyboardButton("/new", callback_data="help_run:new"),
                InlineKeyboardButton("/status", callback_data="help_run:status"),
                InlineKeyboardButton("/agents", callback_data="help_run:agents"),
            ],
        ]

        return CommandResult.ok(text, reply_markup=InlineKeyboardMarkup(buttons))

    @router.command("stop", aliases=["cancel"])
    async def cmd_stop(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Cancel in-progress response or manage tool access.

        Usage:
            /stop              — Cancel current response
            /stop tools        — Kill switch: revoke ALL MCP tool access
            /stop tools off    — Restore tool access (deactivate kill switch)
        """
        if args and args[0].lower() == "tools":
            from otto.gateway import (
                activate_kill_switch,
                deactivate_kill_switch,
                is_kill_switch_active,
            )

            if len(args) > 1 and args[1].lower() in ("off", "resume", "restore"):
                deactivate_kill_switch()
                return CommandResult.ok("✅ MCP tool access restored.")

            if is_kill_switch_active():
                return CommandResult.ok(
                    "🔴 Kill switch is already active.\n\n"
                    "Use <code>/stop tools off</code> to restore access."
                )

            activate_kill_switch()
            return CommandResult.ok(
                "🔴 <b>MCP Kill Switch Activated</b>\n\n"
                "All tool access is now revoked.\n"
                "Use <code>/stop tools off</code> to restore."
            )

        core = ctx.platform.core if hasattr(ctx.platform, "core") else None
        if core and core.cancel_request(ctx.message.chat_id):
            return CommandResult.ok("Stopped.")
        return CommandResult.ok("Nothing running.")

    @router.command("pause")
    async def cmd_pause(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Pause or resume a specific MCP server at runtime.

        Usage:
            /pause <server>        — Pause server (deny all tool calls)
            /pause <server> off    — Resume server
            /pause list            — Show paused servers
        """
        from otto.gateway import get_gateway

        if not args:
            return CommandResult.error(
                "<b>Usage:</b>\n"
                "  /pause &lt;server&gt; — Pause a server\n"
                "  /pause &lt;server&gt; off — Resume a server\n"
                "  /pause list — Show paused servers"
            )

        sub = args[0].lower()

        if sub == "list":
            gw = get_gateway()
            paused = gw.paused_servers
            if not paused:
                return CommandResult.ok("No servers are currently paused.")
            lines = ["<b>Paused Servers</b>\n"]
            for name in sorted(paused.keys()):
                lines.append(f"  ⏸ {name}")
            lines.append("\nResume with: <code>/pause &lt;name&gt; off</code>")
            return CommandResult.ok("\n".join(lines))

        server_name = sub
        gw = get_gateway()

        # Resume?
        if len(args) > 1 and args[1].lower() in ("off", "resume", "restore"):
            if gw.resume_server(server_name):
                return CommandResult.ok(f"▶️ Server <b>{server_name}</b> resumed.")
            return CommandResult.error(f"Server '{server_name}' is not paused.")

        # Pause
        if gw.pause_server(server_name):
            return CommandResult.ok(
                f"⏸ Server <b>{server_name}</b> paused.\n\n"
                f"All tool calls to this server will be denied.\n"
                f"Resume with: <code>/pause {server_name} off</code>"
            )
        return CommandResult.error(
            f"Server '{server_name}' not found in gateway.\n"
            f"Available: {', '.join(sorted(gw.list_servers().keys())) or 'none'}"
        )

    @router.command("status")
    async def cmd_status(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Show system status with live data and quick actions."""
        import platform as _platform

        from otto.backends import get_backend_model
        from otto.config import get_setting
        from otto.daemon import format_uptime
        from otto.daemon import status as service_status

        session = get_current_session(chat_id=ctx.message.chat_id)
        session_id = session.get("id", "none")[:20]
        session_topic = session.get("topic", "")
        msg_count = len(session.get("messages", []))
        active_backend = get_active_backend_name()
        current_model = get_backend_model(active_backend)
        mem = memory_stats()
        thinking_on = get_setting("agent.thinking.enabled", True)

        # Uptime
        info = service_status("telegram-bot")
        uptime_str = format_uptime(info.uptime_seconds)

        # Agent counts
        agent_active = 0
        agent_pending = 0
        try:
            from otto.jobs.queue import JobQueue

            q = JobQueue()
            jobs = q.list(job_type="agent", limit=100)
            for j in jobs:
                st = j.get("status")
                if st == "running":
                    agent_active += 1
                elif st == "pending":
                    agent_pending += 1
        except Exception:
            pass

        # Build status text
        lines = ["<b>Otto Status</b>\n"]

        # System
        lines.append("<b>System</b>")
        lines.append(f"  Uptime: {uptime_str}")
        lines.append(f"  Platform: {_platform.system()} {_platform.release()}")

        # Backend
        backend_str = active_backend
        if current_model:
            backend_str = f"{active_backend} ({current_model})"
        lines.append("\n<b>Backend</b>")
        lines.append(f"  {backend_str}")
        lines.append(f"  Thinking: {'ON' if thinking_on else 'OFF'}")

        # Session
        lines.append("\n<b>Session</b>")
        lines.append(f"  ID: <code>{session_id}</code>")
        if session_topic:
            lines.append(f"  Topic: {session_topic}")
        lines.append(f"  Messages: {msg_count}")

        # Agents (only if any exist)
        if agent_active or agent_pending:
            lines.append("\n<b>Agents</b>")
            parts = []
            if agent_active:
                parts.append(f"{agent_active} running")
            if agent_pending:
                parts.append(f"{agent_pending} pending")
            lines.append(f"  {', '.join(parts)}")

        # Memory
        lines.append("\n<b>Memory</b>")
        lines.append(f"  {mem.get('total_chunks', 0)} chunks indexed")

        text = "\n".join(lines)

        # Quick action buttons
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        buttons = [
            [
                InlineKeyboardButton("Switch Backend", callback_data="status_action:backend"),
                InlineKeyboardButton("New Session", callback_data="status_action:new"),
            ],
            [
                InlineKeyboardButton("Refresh", callback_data="status_action:refresh"),
            ],
        ]
        # Add Agents button only if agents exist
        if agent_active or agent_pending:
            buttons[1].append(InlineKeyboardButton("Agents", callback_data="status_action:agents"))

        return CommandResult.ok(text, reply_markup=InlineKeyboardMarkup(buttons))

    @router.command("new", aliases=["clear"])
    async def cmd_new(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Start a fresh session."""
        from otto.sessions import maybe_auto_title

        # Auto-title the outgoing session before archiving (fire-and-forget)
        try:
            await maybe_auto_title(chat_id=ctx.message.chat_id, force=True)
        except Exception:
            pass

        topic = " ".join(args) if args else None
        new_session(topic=topic, archive_current=True, chat_id=ctx.message.chat_id)
        if topic:
            return CommandResult.ok(f"Fresh session started: {topic}")
        return CommandResult.ok("Fresh session started.")

    @router.command("sessions")
    async def cmd_sessions(ctx: ChatContext, args: list[str]) -> CommandResult:
        """List sessions with topic, message count, relative age, and pagination."""

        # Parse page number from args
        page = 0
        if args:
            try:
                page = max(0, int(args[0]) - 1)
            except ValueError:
                pass

        return _render_sessions_page(page, chat_id=ctx.message.chat_id)

    def _render_sessions_page(page: int = 0, chat_id: str | None = None) -> CommandResult:
        """Render a page of sessions with inline keyboard."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        PAGE_SIZE = 5
        all_sessions = list_sessions(chat_id=chat_id) or []

        if not all_sessions:
            return CommandResult.ok(
                "<b>Sessions</b>\n\n"
                "No sessions yet.\n\n"
                "Use /new to start a fresh session — your current chat will be saved."
            )

        current_session = get_current_session(chat_id=chat_id)
        current_id = current_session.get("id", "")

        total = len(all_sessions)
        total_pages = (total + PAGE_SIZE - 1) // PAGE_SIZE
        page = min(page, total_pages - 1)
        start = page * PAGE_SIZE
        page_sessions = all_sessions[start : start + PAGE_SIZE]

        lines = [f"<b>Sessions</b> ({total} total)\n"]

        buttons: list[list[InlineKeyboardButton]] = []
        for s in page_sessions:
            sid = s.get("id") or "?"
            topic = (s.get("topic") or "")[:25] or "(no topic)"
            msg_count = s.get("message_count", 0)
            age = _relative_time(s.get("last_activity") or s.get("created"))
            is_current = s.get("is_current", False) or sid == current_id

            marker = " ← current" if is_current else ""
            lines.append(
                f"{'▸' if is_current else '•'} <b>{topic}</b>{marker}\n  {msg_count} msgs · {age}"
            )

            # Per-session action buttons
            row = []
            if not is_current:
                # callback_data max 64 bytes: "sess_sw:{id}" must fit
                sw_data = f"sess_sw:{sid[:50]}"
                row.append(InlineKeyboardButton("Switch", callback_data=sw_data))
            del_data = f"sess_del:{sid[:50]}"
            row.append(InlineKeyboardButton("Delete", callback_data=del_data))
            if row:
                buttons.append(row)

        # Pagination buttons
        nav_row: list[InlineKeyboardButton] = []
        if page > 0:
            nav_row.append(InlineKeyboardButton("« Prev", callback_data=f"sess_pg:{page - 1}"))
        if page < total_pages - 1:
            nav_row.append(InlineKeyboardButton("Next »", callback_data=f"sess_pg:{page + 1}"))
        if nav_row:
            buttons.append(nav_row)

        return CommandResult.ok(
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup(buttons) if buttons else None,
        )

    @router.command("backend")
    async def cmd_backend(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Show or switch backend/model.

        Usage:
            /backend              - Show current backend and model
            /backend <name>       - Switch to backend
            /backend <name> <model> - Switch to backend with specific model
            /backend . <model>    - Change model for current backend
        """
        from otto.backends import (
            get_backend_model,
            get_known_models,
            set_active_backend,
            set_backend_model,
        )

        active = get_active_backend_name()
        backends = list_backends()
        current_model = get_backend_model(active)

        if not args:
            # Show status with options for UI
            model_str = current_model or "(default)"
            known = get_known_models(active)
            lines = [f"Backend: {active}", f"Model: {model_str}\n"]
            lines.append("Backends:")

            # Build options for all backends (show disabled ones too)
            backend_options = []
            for name, info in backends.items():
                enabled = info.get("enabled", False)
                status = "✓" if enabled else "○"
                marker = " ←" if name == active else ""

                # Add description for backends
                desc = ""
                if name == "claude":
                    desc = " (Claude SDK)"
                elif name == "codex":
                    desc = " (OpenAI Codex)"
                elif name == "generic":
                    desc = " (LiteLLM multi-provider)"

                lines.append(f"  {status} {name}{desc}{marker}")

                # Show all backends as options, mark current with ✓
                if name == active:
                    label = f"✓ {name}"
                elif not enabled:
                    label = f"○ {name}"
                else:
                    label = name
                backend_options.append({"id": name, "label": label})

            if known:
                lines.append(f"\nKnown models for {active}:")
                # Format model list nicely
                if active == "generic":
                    # Group by provider for generic backend
                    lines.append("  OpenRouter: openrouter/<model>")
                    lines.append("  Ollama: ollama/<model>")
                    lines.append("  Gemini: gemini/<model>")
                    lines.append("  OpenAI: gpt-4o, gpt-4o-mini")
                else:
                    lines.append(f"  {', '.join(known)}")

            # Add API key hint for generic backend
            if active == "generic":
                lines.append("\nAPI keys via env vars:")
                lines.append("  OPENROUTER_API_KEY, OPENAI_API_KEY, etc.")

            # Return with options for Telegram inline keyboard
            return CommandResult(
                text="\n".join(lines),
                success=True,
                options=backend_options,
                action="select",
                next_handler="backend",
            )

        target_backend = args[0].lower()
        target_model = args[1] if len(args) > 1 else None

        # Handle "." meaning current backend
        if target_backend == ".":
            target_backend = active
        elif target_backend not in backends:
            return CommandResult.error(f"Unknown backend: {target_backend}")

        # Switch backend if different
        if target_backend != active:
            set_active_backend(target_backend)

        # Set model if specified
        if target_model:
            set_backend_model(target_model, target_backend)
            return CommandResult.ok(f"Switched to {target_backend} ({target_model}).")
        elif target_backend != active:
            return CommandResult.ok(f"Switched to {target_backend}.")
        else:
            return CommandResult.ok(f"Already on {target_backend}.")

    @router.command("memory")
    async def cmd_memory(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Search memory or show stats."""
        if not args:
            stats = memory_stats()
            chunks = stats.get("total_chunks", 0)
            if chunks == 0:
                return CommandResult.ok(
                    "Memory index is empty.\n\n"
                    "Use /reindex to build the index from your knowledge files and sessions."
                )
            return CommandResult.ok(
                f"Memory: {chunks} chunks indexed\nUse /memory <query> to search."
            )

        query = " ".join(args)
        results = memory_search_formatted(query, limit=3)
        if not results:
            return CommandResult.ok(
                f"Nothing found for: {query}\n\n"
                "Try broader terms, or /reindex to rebuild the index."
            )
        return CommandResult.ok(results)

    @router.command("agents")
    async def cmd_agents(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Show active sub-agents with inline actions."""
        from otto.jobs.queue import JobQueue

        # Handle cancel subcommand for text-only platforms: /agents cancel <id|all>
        if args and args[0].lower() == "cancel":
            queue = JobQueue()
            target = args[1] if len(args) > 1 else None
            if not target:
                return CommandResult.error("Usage: /agents cancel <id|all>")

            if target.lower() == "all":
                count = queue.force_cancel_all_running(job_type="agent")
                if count:
                    return CommandResult.ok(f"Cancelled {count} agent(s).")
                return CommandResult.ok("No active agents to cancel.")

            job = queue.get_by_external_id(target, job_type="agent")
            if not job:
                return CommandResult.error(f"Agent {target} not found.")
            if queue.force_cancel(int(job["id"])):
                return CommandResult.ok(f"Cancelled agent {target}.")
            return CommandResult.error(f"Agent {target} is already finished.")

        return _build_agents_view(show_history=False)

    def _build_agents_view(show_history: bool = False) -> CommandResult:
        """Build the agents view (active or history)."""
        from otto.jobs.queue import JobQueue

        queue = JobQueue()
        jobs = queue.list(job_type="agent", limit=50)

        agents: list[dict] = []
        for job in jobs:
            payload = job.get("payload") or {}
            agent_id = job.get("external_id") or payload.get("agent_id") or str(job.get("id", "?"))
            agents.append(
                {
                    "id": agent_id,
                    "job_id": job.get("id"),
                    "task": payload.get("task") or payload.get("task_description") or "",
                    "backend": payload.get("backend") or "",
                    "status": job.get("status") or "unknown",
                    "created_at": job.get("created_at") or "",
                    "updated_at": job.get("updated_at") or "",
                    "output_file": payload.get("output_file") or "",
                }
            )

        active = [a for a in agents if a.get("status") in ("pending", "running")]
        finished = [a for a in agents if a.get("status") in ("completed", "failed", "cancelled")]

        if show_history:
            return _render_agents_history(finished)
        return _render_agents_active(active, finished)

    def _agent_duration(created_at: str) -> str:
        """Format duration from created_at to now."""
        from datetime import datetime

        if not created_at:
            return ""
        try:
            start = datetime.fromisoformat(created_at)
            total_secs = int((datetime.now() - start).total_seconds())
            if total_secs < 0:
                return ""
            if total_secs < 60:
                return f"{total_secs}s"
            mins, secs = divmod(total_secs, 60)
            if mins < 60:
                return f"{mins}m {secs}s"
            hours, mins = divmod(mins, 60)
            return f"{hours}h {mins}m"
        except (ValueError, TypeError):
            return ""

    def _render_agents_active(active: list[dict], finished: list[dict]) -> CommandResult:
        """Render the active agents view with per-agent action buttons."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        if not active:
            text = (
                "<b>Agents</b>\n\nNo agents running. I'll spawn agents automatically when needed."
            )
            rows = []
            if finished:
                rows.append([InlineKeyboardButton("Show History", callback_data="ag_hist:1")])
            markup = InlineKeyboardMarkup(rows) if rows else None
            return CommandResult.ok(text, reply_markup=markup)

        # Summary line
        running = sum(1 for a in active if a["status"] == "running")
        pending = sum(1 for a in active if a["status"] == "pending")
        parts = []
        if running:
            parts.append(f"{running} running")
        if pending:
            parts.append(f"{pending} pending")

        lines = [f"<b>Agents</b> — {', '.join(parts)}\n"]
        keyboard_rows: list[list] = []

        for agent in active:
            status = agent["status"]
            aid = agent["id"]
            task = (agent.get("task") or "")[:40]
            duration = _agent_duration(agent.get("created_at", ""))
            short_id = aid[:20]

            if status == "running":
                dur_str = f" ({duration})" if duration else ""
                lines.append(f"⏳ <code>{aid[:12]}</code>{dur_str}\n   {task}")
                keyboard_rows.append(
                    [
                        InlineKeyboardButton("Stop", callback_data=f"ag_stop:{short_id}"),
                        InlineKeyboardButton("Details", callback_data=f"ag_dtl:{short_id}"),
                    ]
                )
            elif status == "pending":
                lines.append(f"⏸ <code>{aid[:12]}</code>\n   {task}")
                keyboard_rows.append(
                    [
                        InlineKeyboardButton("Cancel", callback_data=f"ag_cancel:{short_id}"),
                        InlineKeyboardButton("Details", callback_data=f"ag_dtl:{short_id}"),
                    ]
                )

        # Footer
        footer = []
        if finished:
            footer.append(InlineKeyboardButton("Show History", callback_data="ag_hist:1"))
        footer.append(InlineKeyboardButton("Refresh", callback_data="ag_ref:1"))
        keyboard_rows.append(footer)

        markup = InlineKeyboardMarkup(keyboard_rows)
        return CommandResult.ok("\n".join(lines), reply_markup=markup)

    def _render_agents_history(finished: list[dict]) -> CommandResult:
        """Render history view of completed/failed agents."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        if not finished:
            text = "<b>Agent History</b>\n\nNo completed agents yet."
            markup = InlineKeyboardMarkup(
                [[InlineKeyboardButton("Back to Active", callback_data="ag_ref:1")]]
            )
            return CommandResult.ok(text, reply_markup=markup)

        recent = finished[:8]
        lines = ["<b>Agent History</b>\n"]
        keyboard_rows: list[list] = []

        for agent in recent:
            status = agent["status"]
            aid = agent["id"]
            task = (agent.get("task") or "")[:40]
            short_id = aid[:20]

            icon = {"completed": "✓", "failed": "✗", "cancelled": "○"}.get(status, "?")
            lines.append(f"{icon} <code>{aid[:12]}</code>\n   {task}")

            row = []
            if status == "completed" and agent.get("output_file"):
                row.append(InlineKeyboardButton("Output", callback_data=f"ag_out:{short_id}"))
            row.append(InlineKeyboardButton("Details", callback_data=f"ag_dtl:{short_id}"))
            keyboard_rows.append(row)

        if len(finished) > 8:
            lines.append(f"\n<i>({len(finished) - 8} older agents not shown)</i>")

        keyboard_rows.append(
            [
                InlineKeyboardButton("Back to Active", callback_data="ag_ref:1"),
            ]
        )

        markup = InlineKeyboardMarkup(keyboard_rows)
        return CommandResult.ok("\n".join(lines), reply_markup=markup)

    # --- Agent callback handlers ---

    @router.callback("ag_stop")
    async def cb_agents_stop(ctx: ChatContext, value: str) -> CommandResult:
        """Stop a running agent."""
        from otto.jobs.queue import JobQueue

        if not value:
            return CommandResult.error("Missing agent ID.")
        queue = JobQueue()
        job = queue.get_by_external_id(value, job_type="agent")
        if not job:
            return CommandResult.error(f"Agent not found: {value[:12]}")
        if queue.force_cancel(int(job["id"])):
            return _build_agents_view(show_history=False)
        return CommandResult.error(f"Agent {value[:12]} already finished.")

    @router.callback("ag_cancel")
    async def cb_agents_cancel(ctx: ChatContext, value: str) -> CommandResult:
        """Cancel a pending agent."""
        from otto.jobs.queue import JobQueue

        if not value:
            return CommandResult.error("Missing agent ID.")
        queue = JobQueue()
        job = queue.get_by_external_id(value, job_type="agent")
        if not job:
            return CommandResult.error(f"Agent not found: {value[:12]}")
        if queue.force_cancel(int(job["id"])):
            return _build_agents_view(show_history=False)
        return CommandResult.error(f"Agent {value[:12]} already finished.")

    @router.callback("ag_out")
    async def cb_agents_output(ctx: ChatContext, value: str) -> CommandResult:
        """Show agent output file contents."""
        from pathlib import Path

        from otto.jobs.queue import JobQueue

        if not value:
            return CommandResult.error("Missing agent ID.")

        queue = JobQueue()
        job = queue.get_by_external_id(value, job_type="agent")
        if not job:
            return CommandResult.error(f"Agent not found: {value[:12]}")

        payload = job.get("payload") or {}
        output_file = payload.get("output_file") or ""

        if not output_file or not Path(output_file).exists():
            return CommandResult.ok(f"No output file for agent {value[:12]}.")

        try:
            content = Path(output_file).read_text()[:2000]
            if not content.strip():
                return CommandResult.ok(f"Output file is empty for agent {value[:12]}.")
            return CommandResult.ok(
                f"<b>Output</b> — <code>{value[:12]}</code>\n\n<pre>{content}</pre>"
            )
        except Exception as e:
            return CommandResult.error(f"Error reading output: {e}")

    @router.callback("ag_dtl")
    async def cb_agents_detail(ctx: ChatContext, value: str) -> CommandResult:
        """Show full agent details."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        from otto.jobs.queue import JobQueue

        if not value:
            return CommandResult.error("Missing agent ID.")

        queue = JobQueue()
        job = queue.get_by_external_id(value, job_type="agent")
        if not job:
            return CommandResult.error(f"Agent not found: {value[:12]}")

        payload = job.get("payload") or {}
        status = job.get("status") or "unknown"
        task = payload.get("task") or payload.get("task_description") or "(no task)"
        backend = payload.get("backend") or "?"
        created = job.get("created_at") or "?"
        attempts = job.get("attempts") or 0
        last_error = job.get("last_error") or ""
        duration = _agent_duration(job.get("created_at", ""))

        icon = {
            "pending": "⏸",
            "running": "⏳",
            "completed": "✓",
            "failed": "✗",
            "cancelled": "○",
        }.get(status, "?")

        lines = [
            "<b>Agent Details</b>\n",
            f"{icon} Status: {status}",
            f"ID: <code>{value}</code>",
            f"Backend: {backend}",
            f"Created: {created[:19]}",
        ]
        if duration:
            lines.append(f"Duration: {duration}")
        if attempts > 1:
            lines.append(f"Attempts: {attempts}")
        if last_error:
            lines.append(f"Error: {last_error[:200]}")
        lines.append(f"\nTask: {task[:200]}")

        short_id = value[:20]
        rows: list[list] = []
        if status == "running":
            rows.append([InlineKeyboardButton("Stop", callback_data=f"ag_stop:{short_id}")])
        elif status == "pending":
            rows.append([InlineKeyboardButton("Cancel", callback_data=f"ag_cancel:{short_id}")])
        elif status == "completed" and payload.get("output_file"):
            rows.append([InlineKeyboardButton("Output", callback_data=f"ag_out:{short_id}")])
        rows.append([InlineKeyboardButton("Back to Active", callback_data="ag_ref:1")])

        markup = InlineKeyboardMarkup(rows)
        return CommandResult.ok("\n".join(lines), reply_markup=markup)

    @router.callback("ag_hist")
    async def cb_agents_history(ctx: ChatContext, value: str) -> CommandResult:
        """Show agent history."""
        return _build_agents_view(show_history=True)

    @router.callback("ag_ref")
    async def cb_agents_refresh(ctx: ChatContext, value: str) -> CommandResult:
        """Refresh the active agents view."""
        return _build_agents_view(show_history=False)

    @router.command("restart")
    async def cmd_restart(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Request bot restart (confirmation needed on rich platforms)."""
        return CommandResult.confirm(
            "Restart Otto?\n\nThis will respawn the bot process. Back in a few seconds.",
            handler="restart",
        )

    @router.command("switch")
    async def cmd_switch(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Switch to a different session."""
        from otto import load_session
        from otto.sessions import maybe_auto_title

        if not args:
            return CommandResult.error("Usage: /switch <session_id>")

        # Auto-title the outgoing session before switching (fire-and-forget)
        try:
            await maybe_auto_title(chat_id=ctx.message.chat_id, force=True)
        except Exception:
            pass

        session_id = args[0]
        session = load_session(session_id, chat_id=ctx.message.chat_id)
        if session:
            topic = session.get("topic") or session_id[:15]
            return CommandResult.ok(f"Resumed session: {topic}")
        return CommandResult.error(f"Session not found: {session_id}")

    @router.command("vtt")
    async def cmd_vtt(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Toggle voice-to-text transcription."""
        try:
            from otto_tools.vtt import is_model_ready
            from otto_tools.vtt import load_config as vtt_load_config

            vtt_config = vtt_load_config()
            vtt_enabled = vtt_config.get("enabled", False)
            model = vtt_config.get("model", "base")
            model_ready = is_model_ready()
        except ImportError:
            return CommandResult.error("VTT not available\n\nModule otto_tools.vtt not found.")

        status = "enabled" if vtt_enabled else "disabled"
        model_status = "ready" if model_ready else "not downloaded"

        text = f"Voice-to-Text: {status.upper()}\nModel: {model} ({model_status})"
        if vtt_enabled:
            text += "\n\nVoice messages will be transcribed."
        else:
            text += "\n\nEnable to transcribe voice messages."

        # Build options based on current state
        if vtt_enabled:
            options = [{"id": "disable", "label": "Disable VTT"}]
        else:
            options = [{"id": "enable", "label": "Enable VTT"}]
            if not model_ready:
                options.append({"id": "download", "label": "Download Model"})

        return CommandResult(
            text=text,
            options=options,
            action="select",
            next_handler="vtt_toggle",
            data={"enabled": vtt_enabled, "model": model, "model_ready": model_ready},
        )

    @router.command("thinking")
    async def cmd_thinking(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Configure extended thinking for AI models."""
        from otto.config import get_setting

        thinking_enabled = get_setting("agent.thinking.enabled", True)
        show_in_chat = get_setting("agent.thinking.show_in_chat", True)

        # Build status text
        status_icon = "✓" if thinking_enabled else "○"
        display_icon = "✓" if show_in_chat else "○"

        text = "<b>Thinking Configuration</b>\n\n"
        text += f"{status_icon} Extended thinking: {'ON' if thinking_enabled else 'OFF'}\n"
        text += f"{display_icon} Show in chat: {'ON' if show_in_chat else 'OFF'}\n\n"

        if thinking_enabled:
            text += "The model will use extended reasoning for complex tasks."
            if show_in_chat:
                text += " Thinking content will be visible."
            else:
                text += " Thinking will be hidden."
        else:
            text += "Extended thinking is disabled. Faster but less thorough."

        # Build options
        options = []
        if thinking_enabled:
            options.append({"id": "disable_thinking", "label": "Disable Thinking"})
            if show_in_chat:
                options.append({"id": "hide_thinking", "label": "Hide in Chat"})
            else:
                options.append({"id": "show_thinking", "label": "Show in Chat"})
        else:
            options.append({"id": "enable_thinking", "label": "Enable Thinking"})

        return CommandResult(
            text=text,
            options=options,
            action="select",
            next_handler="thinking",
            data={"enabled": thinking_enabled, "show_in_chat": show_in_chat},
        )

    @router.command("mcp")
    async def cmd_mcp(ctx: ChatContext, args: list[str]) -> CommandResult:
        """MCP server management with inline keyboards."""
        if not args:
            return _render_mcp_list()

        subcmd = args[0].lower()
        rest = args[1:] if len(args) > 1 else []

        if subcmd == "list":
            return _render_mcp_list()
        if subcmd == "info" and rest:
            return _render_mcp_info(rest[0])
        if subcmd == "enable" and rest:
            return _mcp_toggle(rest[0], enable=True)
        if subcmd == "disable" and rest:
            return _mcp_toggle(rest[0], enable=False)
        if subcmd == "search" and rest:
            return _mcp_search(" ".join(rest))
        if subcmd == "gateway":
            if rest and rest[0].lower() == "validate":
                return _gateway_validate()
            if rest and rest[0].lower() == "test-policy":
                return _gateway_test_policy(rest[1:])
            if rest and rest[0].lower() == "export-policy":
                return _gateway_export_policy(rest[1:])
            if rest and rest[0].lower() == "import-policy":
                return _gateway_import_policy(rest[1:])
            if rest and rest[0].lower() == "packs":
                return _gateway_list_packs()
            return _render_mcp_gateway()
        if subcmd == "catalog":
            category = rest[0] if rest else None
            return _render_mcp_catalog(category)
        if subcmd == "install" and rest:
            return _mcp_install(rest[0])
        if subcmd == "remove" and rest:
            return _mcp_remove(rest[0])
        if subcmd == "test":
            server_name = rest[0] if rest else None
            return await _mcp_test(server_name)
        if subcmd == "add" and rest:
            return _mcp_install(rest[0])

        return CommandResult.error(
            "Usage:\n"
            "  /mcp — Server list\n"
            "  /mcp catalog — Browse available servers\n"
            "  /mcp install &lt;name&gt; — Install from catalog\n"
            "  /mcp remove &lt;name&gt; — Remove server\n"
            "  /mcp test [name] — Test server connection\n"
            "  /mcp gateway — Gateway status\n"
            "  /mcp gateway validate — Validate policy config\n"
            "  /mcp gateway test-policy &lt;server&gt; &lt;tool&gt; [arg=val ...] — Test policy\n"
            "  /mcp gateway export-policy [name] — Export policy as pack\n"
            "  /mcp gateway import-policy &lt;path&gt; — Import policy pack\n"
            "  /mcp gateway packs — List installed packs\n"
            "  /mcp info &lt;name&gt;\n"
            "  /mcp search &lt;query&gt;"
        )

    def _mcp_server_status() -> tuple[dict[str, Any], dict[str, dict]]:
        """Return (gateway_servers, empty_catalog) for building the MCP views.

        gateway_servers: {name: ServerPolicy} from otto.gateway
        catalog: empty dict (Docker catalog removed, all servers in gateway)
        """
        try:
            from otto.gateway import get_gateway

            servers = get_gateway().list_servers()
        except Exception:
            servers = {}

        return servers, {}

    def _render_mcp_list() -> CommandResult:
        """Render the MCP server list with inline keyboard."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        servers, catalog = _mcp_server_status()
        all_names = sorted(set(servers.keys()) | set(catalog.keys()))

        if not all_names:
            return CommandResult.ok(
                "<b>MCP Servers</b>\n\n"
                "No servers configured.\n\n"
                "Add servers in <code>~/.otto/settings.yaml</code> under "
                "<code>gateway.servers</code>"
            )

        enabled_names = []
        available_names = []

        for name in all_names:
            sp = servers.get(name)
            if sp and sp.enabled:
                enabled_names.append(name)
            else:
                available_names.append(name)

        lines = ["<b>MCP Servers</b>\n"]

        if enabled_names:
            lines.append("<b>Enabled:</b>")
            for name in enabled_names:
                desc = _mcp_short_desc(name, servers, catalog)
                lines.append(f"✓ {name} — {desc}" if desc else f"✓ {name}")

        if available_names:
            lines.append("\n<b>Available:</b>")
            for name in available_names:
                desc = _mcp_short_desc(name, servers, catalog)
                lines.append(f"○ {name} — {desc}" if desc else f"○ {name}")

        n = len(enabled_names)
        lines.append(f"\n<i>{n} active server{'s' if n != 1 else ''}</i>")

        # Build keyboard: per-server info buttons, 2 per row
        rows: list[list[InlineKeyboardButton]] = []
        btn_row: list[InlineKeyboardButton] = []

        for name in enabled_names:
            btn_row.append(InlineKeyboardButton(f"{name} ✓", callback_data=f"mcp:info_{name[:50]}"))
            if len(btn_row) == 2:
                rows.append(btn_row)
                btn_row = []

        for name in available_names:
            btn_row.append(InlineKeyboardButton(name, callback_data=f"mcp:info_{name[:50]}"))
            if len(btn_row) == 2:
                rows.append(btn_row)
                btn_row = []
        if btn_row:
            rows.append(btn_row)

        rows.append(
            [
                InlineKeyboardButton("📦 Catalog", callback_data="mcp:catalog"),
                InlineKeyboardButton("Gateway", callback_data="mcp:gateway"),
                InlineKeyboardButton("🧪 Test", callback_data="mcp:test"),
                InlineKeyboardButton("↻", callback_data="mcp:refresh"),
            ]
        )

        return CommandResult.ok(
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup(rows),
        )

    def _mcp_short_desc(name: str, servers: dict, catalog: dict) -> str:
        """Get a short description for a server."""
        sp = servers.get(name)
        if sp:
            t = sp.transport.get("type", "builtin" if sp.builtin else "")
            tools = ""
            if sp.allowed_tools is not None:
                tools = f", {len(sp.allowed_tools)} tools"
            return f"{t}{tools}" if t else ""
        cat = catalog.get(name, {})
        desc = cat.get("desc", "")
        # Take the part after " - " if present for brevity
        if " - " in desc:
            return desc.split(" - ", 1)[1][:40]
        return desc[:40]

    def _render_mcp_info(name: str) -> CommandResult:
        """Render detail view for a single MCP server."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        servers, catalog = _mcp_server_status()
        name_lower = name.lower()

        sp = servers.get(name_lower)
        cat = catalog.get(name_lower, {})
        is_enabled = sp.enabled if sp else False

        lines = [f"<b>{name_lower}</b>\n"]

        if cat:
            lines.append(cat.get("desc", ""))
            lines.append(f"\nStatus: {'enabled' if is_enabled else 'disabled'}")
            if "url" in cat:
                lines.append("Type: URL endpoint")
                lines.append(f"URL: {cat['url']}")
            elif "image" in cat:
                lines.append("Type: Docker container")
                lines.append(f"Image: {cat['image']}")
        elif sp:
            t = sp.transport.get("type", "builtin" if sp.builtin else "unknown")
            lines.append(f"Status: {'enabled' if is_enabled else 'disabled'}")
            lines.append(f"Type: {t}")
            if sp.allowed_tools is not None:
                lines.append(f"Allowed tools: {len(sp.allowed_tools)}")
            if sp.blocked_tools:
                lines.append(f"Blocked tools: {len(sp.blocked_tools)}")
        else:
            lines.append("Server not found in gateway or catalog.")

        # Action buttons
        rows: list[list[InlineKeyboardButton]] = []
        if is_enabled:
            rows.append(
                [InlineKeyboardButton("Disable", callback_data=f"mcp:disable_{name_lower[:50]}")]
            )
        else:
            rows.append(
                [InlineKeyboardButton("Enable", callback_data=f"mcp:enable_{name_lower[:50]}")]
            )
        rows.append([InlineKeyboardButton("« Back to Servers", callback_data="mcp:back")])

        return CommandResult.ok(
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup(rows),
        )

    def _mcp_toggle(name: str, *, enable: bool) -> CommandResult:
        """Toggle server enabled/disabled in gateway policy.

        Note: Runtime toggle changes the in-memory gateway policy.
        For persistent changes, edit settings.yaml gateway.servers.
        """
        action = "enable" if enable else "disable"
        return CommandResult.error(
            f"Cannot {action} '{name}' at runtime.\n\n"
            f"Edit <code>settings.yaml</code> → <code>gateway.servers.{name}.enabled</code> "
            f"and reload the gateway."
        )

    def _mcp_search(query: str) -> CommandResult:
        """Search configured MCP servers by name/keyword."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        from otto.gateway import get_gateway

        q = query.lower()
        gateway = get_gateway()
        results: list[tuple[str, str]] = []

        for name, policy in gateway.list_servers().items():
            if q in name.lower():
                transport_type = "builtin" if policy.builtin else policy.transport.get("type", "?")
                status = "enabled" if policy.enabled else "disabled"
                results.append((name, f"{transport_type} ({status})"))

        if not results:
            rows = [[InlineKeyboardButton("« Back to Servers", callback_data="mcp:back")]]
            return CommandResult.ok(
                f"No servers matching: {query}\n\nCheck gateway.servers in settings.yaml.",
                reply_markup=InlineKeyboardMarkup(rows),
            )

        lines = [f"<b>MCP Search:</b> <i>{query}</i>\n"]
        rows: list[list[InlineKeyboardButton]] = []

        for name, desc in results[:10]:
            lines.append(f"• <b>{name}</b> - {desc}")
            rows.append([InlineKeyboardButton(name, callback_data=f"mcp:info_{name[:50]}")])

        rows.append([InlineKeyboardButton("« Back to Servers", callback_data="mcp:back")])

        return CommandResult.ok(
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup(rows),
        )

    def _render_mcp_gateway() -> CommandResult:
        """Render native gateway status inline."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        from otto.gateway import get_gateway

        lines = ["<b>MCP Gateway</b> (native)\n"]

        try:
            gateway = get_gateway()
            servers = gateway.list_servers()
            enabled = sum(1 for p in servers.values() if p.enabled)
            builtin = sum(1 for p in servers.values() if p.builtin)
            external = enabled - builtin

            # Kill switch status
            ks_status = "🔴 ACTIVE" if gateway.policy.kill_switch else "🟢 Off"
            lines.append(f"Kill Switch: {ks_status}")

            lines.append(f"Servers: {len(servers)} total, {enabled} enabled")
            lines.append(f"Built-in: {builtin}")
            lines.append(f"External: {external}")
            lines.append(f"Audit: {'on' if gateway.policy.audit_enabled else 'off'}")

            if gateway.policy.allowed_paths:
                lines.append(f"\n<b>Allowed paths:</b> {', '.join(gateway.policy.allowed_paths)}")

            if gateway.policy.permissions:
                lines.append("\n<b>Permissions:</b>")
                for op, verdict in gateway.policy.permissions.items():
                    lines.append(f"  {op}: {verdict.value}")
        except Exception as e:
            lines.append("Status: <b>error</b>")
            lines.append(f"\n<i>{e}</i>")

        rows = []
        try:
            if gateway.policy.kill_switch:
                rows.append(
                    [InlineKeyboardButton("🟢 Deactivate Kill Switch", callback_data="mcp:ks_off")]
                )
            else:
                rows.append(
                    [InlineKeyboardButton("🔴 Activate Kill Switch", callback_data="mcp:ks_on")]
                )
        except Exception:
            pass
        rows.append([InlineKeyboardButton("« Back to Servers", callback_data="mcp:back")])
        return CommandResult.ok(
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup(rows),
        )

    def _gateway_validate() -> CommandResult:
        """Validate the gateway policy configuration and show effective policies."""
        from otto.config import get_setting
        from otto.policy import (
            PolicyConfig,
            PolicyEngine,
            validate_policy_config,
        )

        lines = ["<b>Gateway Policy Validation</b>\n"]

        policy_raw = get_setting("gateway.policy") or {}

        # 1. Validate config structure
        errors = validate_policy_config(policy_raw)
        if errors:
            lines.append("❌ <b>Config errors:</b>")
            for err in errors:
                lines.append(f"  • {err}")
        else:
            lines.append("✅ Config syntax is valid")

        # 2. Show active preset and defaults
        policy_config = PolicyConfig.from_config(policy_raw)
        engine = PolicyEngine(policy_config)

        lines.append(f"\n<b>Preset:</b> {policy_config.preset}")
        lines.append(f"<b>Default verdict:</b> {policy_config.defaults.verdict.value}")
        if policy_config.defaults.rate_limit:
            lines.append(f"<b>Default rate limit:</b> {policy_config.defaults.rate_limit}/min")

        # 3. Show global tool verdicts (from preset)
        if policy_config.tool_verdicts:
            lines.append("\n<b>Global tool verdicts:</b>")
            for tool, verdict in sorted(policy_config.tool_verdicts.items()):
                lines.append(f"  {tool}: {verdict.value}")

        # 4. Show per-server effective policies
        if policy_config.servers:
            lines.append("\n<b>Server policies:</b>")
            for srv_name, srv_pol in sorted(policy_config.servers.items()):
                lines.append(f"\n  <b>{srv_name}</b>: {srv_pol.verdict.value}")
                if srv_pol.rate_limit:
                    lines.append(f"    rate_limit: {srv_pol.rate_limit}/min")
                if srv_pol.args:
                    lines.append(f"    arg_rules: {', '.join(srv_pol.args.keys())}")
                for tool_name, tool_pol in sorted(srv_pol.tools.items()):
                    lines.append(f"    {tool_name}: {tool_pol.verdict.value}")
                    if tool_pol.rate_limit:
                        lines.append(f"      rate_limit: {tool_pol.rate_limit}/min")
                    if tool_pol.args:
                        for arg_name, rule in tool_pol.args.items():
                            parts = []
                            if rule.required:
                                parts.append("required")
                            if rule.must_match:
                                parts.append(f"match: {rule.must_match}")
                            if rule.must_not_match:
                                parts.append(f"block: {rule.must_not_match}")
                            if rule.blocked_values:
                                parts.append(f"blocked: {rule.blocked_values}")
                            if rule.max_length:
                                parts.append(f"max_len: {rule.max_length}")
                            lines.append(f"      {arg_name}: {', '.join(parts)}")

        # 5. Show argument templates
        if policy_config.arg_templates:
            lines.append("\n<b>Argument templates:</b>")
            for tmpl_name, tmpl in sorted(policy_config.arg_templates.items()):
                lines.append(f"  {tmpl_name}: {', '.join(tmpl.args.keys())}")

        # 6. Check catalog inheritance
        try:
            from otto.gateway import get_gateway

            gw = get_gateway()
            catalog_count = 0
            gw_policy_raw = policy_raw.get("servers") or {}
            for srv_name in gw.policy_engine.config.servers:
                if srv_name not in gw_policy_raw:
                    catalog_count += 1
            if catalog_count:
                lines.append(f"\n<i>{catalog_count} server(s) inherited policy from catalog</i>")
        except Exception:
            pass

        return CommandResult.ok("\n".join(lines))

    def _gateway_test_policy(args: list[str]) -> CommandResult:
        """Test a policy against a mock request."""
        from otto.policy_ext import MockToolRequest, evaluate_mock_request

        if len(args) < 2:
            return CommandResult.error(
                "Usage: /mcp gateway test-policy &lt;server&gt; &lt;tool&gt; [arg=val ...]\n\n"
                "Example:\n"
                "  /mcp gateway test-policy filesystem write_file path=/tmp/test.txt\n"
                "  /mcp gateway test-policy bash exec command='rm -rf /'"
            )

        server = args[0]
        tool = args[1]

        # Parse key=value arguments
        arguments: dict[str, Any] = {}
        for arg in args[2:]:
            if "=" in arg:
                key, value = arg.split("=", 1)
                arguments[key.strip()] = value.strip()
            else:
                arguments[arg] = ""

        request = MockToolRequest(server=server, tool=tool, arguments=arguments)
        result = evaluate_mock_request(request)

        verdict_icon = {"allow": "✅", "deny": "❌", "ask": "❓"}.get(result.verdict, "❓")

        lines = [
            "<b>Policy Test Result</b>\n",
            f"{verdict_icon} <b>Verdict:</b> {result.verdict.upper()}",
            f"<b>Source:</b> {result.source}",
            f"<b>Reason:</b> {result.reason}",
        ]

        if result.arg_errors:
            lines.append("\n<b>Argument errors:</b>")
            for err in result.arg_errors:
                lines.append(f"  • {err}")

        if result.expression_matched:
            lines.append(f"\n<i>Expression: {result.expression_matched}</i>")
        if result.plugin_matched:
            lines.append(f"\n<i>Plugin: {result.plugin_matched}</i>")

        lines.append(f"\n<b>Request:</b> {server}.{tool}")
        if arguments:
            lines.append("<b>Args:</b> " + ", ".join(f"{k}={v}" for k, v in arguments.items()))

        return CommandResult.ok("\n".join(lines))

    def _gateway_export_policy(args: list[str]) -> CommandResult:
        """Export current policy as a shareable pack."""
        from otto.policy_ext import PACKS_DIR, ensure_policy_dirs, export_current_policy

        name = args[0] if args else "exported"
        description = " ".join(args[1:]) if len(args) > 1 else ""

        try:
            pack = export_current_policy(name, description)
            ensure_policy_dirs()
            dest = PACKS_DIR / f"{name}.yaml"
            pack.export(dest)
            return CommandResult.ok(
                f"✅ Policy exported as pack <b>{name}</b>\n"
                f"📁 {dest}\n\n"
                f"Share this file or import with:\n"
                f"<code>/mcp gateway import-policy {dest}</code>"
            )
        except Exception as e:
            return CommandResult.error(f"Failed to export: {e}")

    def _gateway_import_policy(args: list[str]) -> CommandResult:
        """Import a policy pack file."""
        from pathlib import Path

        from otto.policy_ext import install_pack

        if not args:
            return CommandResult.error(
                "Usage: /mcp gateway import-policy &lt;path&gt;\n\n"
                "Path to a .yaml policy pack file."
            )

        pack_path = Path(args[0]).expanduser()
        success, message = install_pack(pack_path)

        if success:
            return CommandResult.ok(f"✅ {message}")
        return CommandResult.error(f"❌ {message}")

    def _gateway_list_packs() -> CommandResult:
        """List installed policy packs."""
        from otto.policy_ext import PACKS_DIR, list_packs

        packs = list_packs()

        if not packs:
            return CommandResult.ok(
                "<b>Policy Packs</b>\n\n"
                "No packs installed.\n\n"
                f"Add packs to <code>{PACKS_DIR}</code> or export current policy with:\n"
                "<code>/mcp gateway export-policy my-pack</code>"
            )

        lines = ["<b>Policy Packs</b>\n"]
        for pack in packs:
            lines.append(f"📦 <b>{pack.name}</b> v{pack.version}")
            if pack.description:
                lines.append(f"   {pack.description}")
            if pack.author:
                lines.append(f"   by {pack.author}")
            if pack.source_path:
                lines.append(f"   📁 {pack.source_path}")

            # Validate
            errors = pack.validate()
            if errors:
                lines.append(f"   ⚠️ {len(errors)} validation issue(s)")

        return CommandResult.ok("\n".join(lines))

    def _render_mcp_catalog(category: str | None = None) -> CommandResult:
        """Render the curated MCP server catalog for browsing."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        from otto.catalog import list_catalog, list_categories

        entries = list_catalog(category=category)
        categories = list_categories()

        if not entries:
            if category:
                text = f"<b>MCP Catalog</b>\n\nNo servers in category: {category}"
            else:
                text = "<b>MCP Catalog</b>\n\nCatalog is empty."
            rows = [[InlineKeyboardButton("« Back to Servers", callback_data="mcp:back")]]
            return CommandResult.ok(text, reply_markup=InlineKeyboardMarkup(rows))

        # Check which are already installed
        try:
            from otto.gateway import get_gateway

            installed = set(get_gateway().list_servers().keys())
        except Exception:
            installed = set()

        if category:
            title = f"<b>MCP Catalog</b> — {category}\n"
        else:
            title = f"<b>MCP Catalog</b> ({len(entries)} servers)\n"

        lines = [title]

        # Group by category if showing all
        if not category:
            by_cat: dict[str, list] = {}
            for e in entries:
                by_cat.setdefault(e.category, []).append(e)

            for cat_name in sorted(by_cat.keys()):
                cat_entries = by_cat[cat_name]
                icon = cat_entries[0].category_icon if cat_entries else "📦"
                lines.append(f"\n<b>{icon} {cat_name}</b>")
                for e in cat_entries:
                    status = "✓" if e.name in installed else "○"
                    lines.append(f"  {status} <b>{e.name}</b> — {e.description[:45]}")
        else:
            for e in entries:
                status = "✓" if e.name in installed else "○"
                risk = e.risk_icon
                lines.append(f"{status} {risk} <b>{e.name}</b>\n   {e.description[:60]}")

        lines.append("\n<i>✓ = installed, ○ = available</i>")

        # Build keyboard
        rows: list[list[InlineKeyboardButton]] = []

        # Category filter buttons (if showing all)
        if not category and len(categories) > 1:
            cat_row: list[InlineKeyboardButton] = []
            for cat in categories[:4]:
                cat_row.append(
                    InlineKeyboardButton(cat.title(), callback_data=f"mcp:cat_{cat[:20]}")
                )
            rows.append(cat_row)

        # Per-server install/info buttons
        btn_row: list[InlineKeyboardButton] = []
        for e in entries[:12]:  # Limit buttons
            if e.name in installed:
                btn_row.append(
                    InlineKeyboardButton(f"{e.name} ✓", callback_data=f"mcp:info_{e.name[:50]}")
                )
            else:
                btn_row.append(
                    InlineKeyboardButton(f"+ {e.name}", callback_data=f"mcp:inst_{e.name[:50]}")
                )
            if len(btn_row) == 2:
                rows.append(btn_row)
                btn_row = []
        if btn_row:
            rows.append(btn_row)

        rows.append(
            [
                InlineKeyboardButton("« Back to Servers", callback_data="mcp:back"),
            ]
        )

        return CommandResult.ok(
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup(rows),
        )

    def _render_mcp_catalog_detail(name: str) -> CommandResult:
        """Render detail view for a catalog entry (pre-install)."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        from otto.catalog import get_catalog_entry

        entry = get_catalog_entry(name)
        if entry is None:
            return CommandResult.error(f"'{name}' not found in catalog")

        # Check if already installed
        try:
            from otto.gateway import get_gateway

            installed = name in get_gateway().list_servers()
        except Exception:
            installed = False

        lines = [
            f"<b>{entry.name}</b> {entry.risk_icon}\n",
            entry.description,
            f"\nCategory: {entry.category_icon} {entry.category}",
            f"Risk: {entry.risk_icon} {entry.risk_level}",
            f"Transport: {entry.transport.get('type', '?')}",
        ]

        if entry.requires_env:
            missing = entry.check_env()
            if missing:
                lines.append(f"\n⚠️ Missing env: {', '.join(missing)}")
            else:
                lines.append("\n✓ Required env vars set")

        if entry.install_hint:
            lines.append(f"\nInstall: {entry.install_hint}")

        if entry.homepage:
            lines.append(f"Homepage: {entry.homepage}")

        rows: list[list[InlineKeyboardButton]] = []
        if installed:
            rows.append(
                [
                    InlineKeyboardButton("Remove", callback_data=f"mcp:rm_{name[:50]}"),
                    InlineKeyboardButton("Info", callback_data=f"mcp:info_{name[:50]}"),
                ]
            )
        else:
            rows.append(
                [
                    InlineKeyboardButton("Install", callback_data=f"mcp:inst_{name[:50]}"),
                ]
            )
        rows.append(
            [
                InlineKeyboardButton("« Back to Catalog", callback_data="mcp:catalog"),
            ]
        )

        return CommandResult.ok(
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup(rows),
        )

    def _mcp_install(name: str) -> CommandResult:
        """Install a server from the catalog into settings.yaml."""
        from otto.catalog import install_server
        from otto.gateway import reload_gateway

        ok, msg = install_server(name)
        if ok:
            # Reload gateway to pick up new server
            reload_gateway()
        return CommandResult.ok(f"{'✓' if ok else '✗'} {msg}")

    def _mcp_remove(name: str) -> CommandResult:
        """Remove a server from settings.yaml."""
        from otto.catalog import remove_server
        from otto.gateway import reload_gateway

        ok, msg = remove_server(name)
        if ok:
            reload_gateway()
        return CommandResult.ok(f"{'✓' if ok else '✗'} {msg}")

    async def _mcp_test(name: str | None = None) -> CommandResult:
        """Test MCP server connection(s)."""
        from otto.catalog import _test_server_async, test_all_servers
        from otto.gateway import get_gateway

        if name:
            result = await _test_server_async(name)
            results = [result]
        else:
            gateway = get_gateway()
            servers = gateway.list_servers()
            external = [n for n, p in servers.items() if p.enabled and not p.builtin]

            if not external:
                return CommandResult.ok(
                    "<b>MCP Test</b>\n\nNo external servers configured.\n"
                    "Install one with /mcp install &lt;name&gt;"
                )

            results = await test_all_servers()

        lines = ["<b>MCP Connection Test</b>\n"]
        for r in results:
            if r.success:
                lines.append(
                    f"{r.status_icon} <b>{r.server}</b> — "
                    f"{len(r.tools)} tools ({r.latency_ms:.0f}ms)"
                )
            else:
                lines.append(f"{r.status_icon} <b>{r.server}</b> — {r.error}")

        passed = sum(1 for r in results if r.success)
        failed = len(results) - passed
        lines.append(f"\n<i>{passed} passed, {failed} failed</i>")

        return CommandResult.ok("\n".join(lines))

    # -----------------------------------------------------------------
    # /audit — Queryable audit log
    # -----------------------------------------------------------------

    @router.command("audit")
    async def cmd_audit(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Query the gateway audit log.

        Usage:
            /audit                — Show audit stats summary
            /audit list [N]       — Show last N entries (default 20)
            /audit search <term>  — Search audit entries
            /audit denials [N]    — Show recent denials
            /audit server <name>  — Show entries for a server
            /audit tool <name>    — Show entries for a tool
        """
        from otto.audit import audit_stats, format_logs, query_audit

        if not args:
            # Show summary stats
            stats = audit_stats()
            lines = [
                "<b>📊 Audit Summary</b>\n",
                f"Total entries: <b>{stats['total']}</b>",
                f"Denials: <b>{stats['denials']}</b>",
            ]

            if stats["by_verdict"]:
                lines.append("\n<b>By verdict:</b>")
                for verdict, count in sorted(stats["by_verdict"].items()):
                    icon = {"allow": "✅", "deny": "🚫", "prompt": "❓"}.get(verdict, "•")
                    lines.append(f"  {icon} {verdict}: {count}")

            if stats["by_server"]:
                lines.append("\n<b>Top servers:</b>")
                for srv, count in list(stats["by_server"].items())[:5]:
                    lines.append(f"  • {srv}: {count}")

            if stats["by_type"]:
                lines.append("\n<b>By type:</b>")
                for t, count in sorted(stats["by_type"].items()):
                    lines.append(f"  • {t}: {count}")

            lines.append("\n<i>Use /audit list, /audit search, /audit denials</i>")
            return CommandResult.ok("\n".join(lines))

        sub = args[0].lower()
        rest = args[1:]

        if sub == "list":
            limit = int(rest[0]) if rest and rest[0].isdigit() else 20
            entries = query_audit(limit=limit)
            if not entries:
                return CommandResult.ok("No audit entries found.")
            header = f"<b>📋 Last {len(entries)} audit entries</b>\n\n"
            return CommandResult.ok(header + f"<pre>{format_logs(entries)}</pre>")

        elif sub == "search":
            if not rest:
                return CommandResult.error("Usage: /audit search &lt;term&gt;")
            term = " ".join(rest)
            entries = query_audit(search=term, limit=30)
            if not entries:
                return CommandResult.ok(f"No entries matching '{term}'.")
            header = f"<b>🔍 Audit search: '{term}' ({len(entries)} results)</b>\n\n"
            return CommandResult.ok(header + f"<pre>{format_logs(entries)}</pre>")

        elif sub == "denials":
            limit = int(rest[0]) if rest and rest[0].isdigit() else 20
            entries = query_audit(verdict="deny", limit=limit)
            if not entries:
                return CommandResult.ok("No denials found. 🎉")
            header = f"<b>🚫 Recent denials ({len(entries)})</b>\n\n"
            return CommandResult.ok(header + f"<pre>{format_logs(entries)}</pre>")

        elif sub == "server":
            if not rest:
                return CommandResult.error("Usage: /audit server &lt;name&gt;")
            entries = query_audit(server=rest[0], limit=30)
            if not entries:
                return CommandResult.ok(f"No entries for server '{rest[0]}'.")
            header = f"<b>📋 Audit for server '{rest[0]}' ({len(entries)} entries)</b>\n\n"
            return CommandResult.ok(header + f"<pre>{format_logs(entries)}</pre>")

        elif sub == "tool":
            if not rest:
                return CommandResult.error("Usage: /audit tool &lt;name&gt;")
            entries = query_audit(tool=rest[0], limit=30)
            if not entries:
                return CommandResult.ok(f"No entries for tool '{rest[0]}'.")
            header = f"<b>📋 Audit for tool '{rest[0]}' ({len(entries)} entries)</b>\n\n"
            return CommandResult.ok(header + f"<pre>{format_logs(entries)}</pre>")

        else:
            return CommandResult.error(
                "<b>Usage:</b>\n"
                "  /audit — Summary stats\n"
                "  /audit list [N] — Last N entries\n"
                "  /audit search &lt;term&gt;\n"
                "  /audit denials [N]\n"
                "  /audit server &lt;name&gt;\n"
                "  /audit tool &lt;name&gt;"
            )

    @router.command("activity", aliases=["tools"])
    async def cmd_activity(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Live MCP tool activity dashboard.

        Usage:
            /activity              — 24h activity dashboard
            /activity [N]h         — Last N hours (e.g., /activity 6h)
            /activity anomalies    — Recent anomaly alerts
            /activity replay [N]   — Last N tool calls (session replay)
            /activity summary      — Generate daily summary
            /activity boundaries   — Show agent boundary status
        """
        from otto.observability import (
            format_activity_dashboard,
            format_anomalies,
            generate_daily_summary,
            get_activity_summary,
            get_detector,
            get_session_replay,
        )

        if not args:
            summary = get_activity_summary(hours=24)
            text = format_activity_dashboard(summary)

            # Append live status section
            try:
                from otto.gateway import get_gateway

                gw = get_gateway()
                status_parts = []

                # Kill switch
                if gw.policy.kill_switch:
                    status_parts.append("🔴 Kill switch: <b>ACTIVE</b>")

                # Paused servers
                paused = gw.paused_servers
                if paused:
                    names = ", ".join(sorted(paused.keys()))
                    status_parts.append(f"⏸ Paused: {names}")

                # Turn tracker
                turn_count = gw.turn_tracker.turn_count
                max_turn = gw.policy.boundaries.max_calls_per_turn
                if max_turn > 0:
                    status_parts.append(f"Turn: {turn_count}/{max_turn}")

                # Quota
                if gw._quota.max_calls > 0:
                    status_parts.append(f"Quota: {gw._quota.count}/{gw._quota.max_calls}")

                if status_parts:
                    text += "\n\n<b>Live Status:</b>\n" + "\n".join(f"  {p}" for p in status_parts)
            except Exception:
                pass

            return CommandResult.ok(text)

        sub = args[0].lower()

        # /activity 6h — custom time window
        if sub.endswith("h") and sub[:-1].isdigit():
            hours = int(sub[:-1])
            hours = max(1, min(hours, 720))  # 1h to 30 days
            summary = get_activity_summary(hours=hours)
            return CommandResult.ok(format_activity_dashboard(summary))

        if sub == "anomalies":
            detector = get_detector()
            anomalies = detector.anomalies
            return CommandResult.ok(format_anomalies(anomalies))

        if sub == "replay":
            limit = int(args[1]) if len(args) > 1 and args[1].isdigit() else 20
            entries = get_session_replay(limit=limit)
            if not entries:
                return CommandResult.ok("No tool call history found.")
            from otto.audit import format_logs

            header = f"<b>🔄 Session Replay ({len(entries)} entries)</b>\n\n"
            return CommandResult.ok(header + f"<pre>{format_logs(entries)}</pre>")

        if sub == "summary":
            text = generate_daily_summary()
            return CommandResult.ok(text)

        if sub == "boundaries":
            return _render_boundaries()

        return CommandResult.error(
            "<b>Usage:</b>\n"
            "  /activity — 24h dashboard\n"
            "  /activity [N]h — Last N hours\n"
            "  /activity anomalies — Anomaly alerts\n"
            "  /activity replay [N] — Tool call history\n"
            "  /activity summary — Daily summary\n"
            "  /activity boundaries — Agent boundary status"
        )

    def _render_boundaries() -> CommandResult:
        """Render the agent boundary configuration and live status."""
        from otto.gateway import get_gateway

        try:
            gw = get_gateway()
            b = gw.policy.boundaries

            lines = ["<b>🔒 Agent Boundaries</b>\n"]

            # Config
            lines.append("<b>Configuration:</b>")
            max_turn = b.max_calls_per_turn
            lines.append(f"  Max calls/turn: {max_turn if max_turn > 0 else 'unlimited'}")
            turn_timeout = b.turn_timeout
            lines.append(f"  Turn timeout: {f'{turn_timeout}s' if turn_timeout > 0 else 'none'}")
            cd = b.cooldown_seconds
            lines.append(f"  Global cooldown: {f'{cd}s' if cd > 0 else 'none'}")

            if b.server_cooldowns:
                lines.append("\n  <b>Server cooldowns:</b>")
                for srv, secs in sorted(b.server_cooldowns.items()):
                    lines.append(f"    • {srv}: {secs}s")

            # Session quota
            quota = gw._quota
            if quota.max_calls > 0:
                lines.append(f"\n  Session quota: {quota.count}/{quota.max_calls}")
            else:
                lines.append(f"\n  Session quota: unlimited ({quota.count} used)")

            # Live status
            lines.append("\n<b>Live Status:</b>")

            # Kill switch
            if gw.policy.kill_switch:
                lines.append("  🔴 Kill switch: <b>ACTIVE</b>")
            else:
                lines.append("  🟢 Kill switch: Off")

            # Paused servers
            paused = gw.paused_servers
            if paused:
                lines.append(f"  ⏸ Paused servers: {', '.join(sorted(paused.keys()))}")
            else:
                lines.append("  ▶️ All servers active")

            # Current turn
            turn_count = gw.turn_tracker.turn_count
            if max_turn > 0:
                pct = (turn_count / max_turn * 100) if max_turn else 0
                lines.append(f"  Turn progress: {turn_count}/{max_turn} ({pct:.0f}%)")
            elif turn_count > 0:
                lines.append(f"  Calls this turn: {turn_count}")

            return CommandResult.ok("\n".join(lines))
        except Exception as exc:
            return CommandResult.error(f"Could not load boundaries: {exc}")

    @router.command("tasks")
    async def cmd_tasks(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Manage task checklists."""
        import re

        from otto.services.tasks import (
            create_checklist,
            get_checklist,
            get_task_manager,
            render_checklist,
        )

        raw = (ctx.message.text or "").strip()
        rest = raw[len("/tasks") :].strip() if raw.lower().startswith("/tasks") else " ".join(args)

        if rest.lower().startswith("new"):
            spec = rest[3:].strip()
            if not spec:
                return CommandResult.error("Usage: /tasks new <title> | <task1>; <task2>; ...")

            if "|" in spec:
                title, tasks_part = spec.split("|", 1)
                title = title.strip()
                tasks = [t.strip() for t in re.split(r"[;\n]", tasks_part) if t.strip()]
            else:
                title = spec.strip()
                tasks = []

            if not title:
                return CommandResult.error("Checklist title required.")

            checklist = create_checklist(title, int(ctx.message.chat_id), tasks, created_by="otto")
            text, keyboard = render_checklist(checklist)
            return CommandResult.ok(
                text,
                reply_markup=keyboard,
                data={"task_checklist_id": checklist.id},
            )

        if rest.lower().startswith("show"):
            parts = rest.split(maxsplit=2)
            if len(parts) < 2:
                return CommandResult.error("Usage: /tasks show <checklist_id>")
            checklist_id = parts[1]
            checklist = get_checklist(checklist_id)
            if not checklist:
                return CommandResult.error("Checklist not found.")
            text, keyboard = render_checklist(checklist)
            return CommandResult.ok(
                text, reply_markup=keyboard, data={"task_checklist_id": checklist.id}
            )

        if rest.lower().startswith("add"):
            parts = rest.split(maxsplit=2)
            if len(parts) < 3:
                return CommandResult.error("Usage: /tasks add <checklist_id> <task>")
            checklist_id = parts[1]
            content = parts[2].strip()
            if not content:
                return CommandResult.error("Task content required.")
            mgr = get_task_manager()
            task = mgr.add_task_to_checklist(checklist_id, content, created_by="user")
            if not task:
                return CommandResult.error("Checklist not found.")
            checklist = get_checklist(checklist_id)
            if not checklist:
                return CommandResult.error("Checklist not found.")
            text, keyboard = render_checklist(checklist)
            return CommandResult.ok(
                text, reply_markup=keyboard, data={"task_checklist_id": checklist.id}
            )

        # Default: list active checklists with buttons.
        mgr = get_task_manager()
        checklists = mgr.get_active_checklists(int(ctx.message.chat_id), limit=10)
        if not checklists:
            return CommandResult.ok(
                "No active task lists.\n\n"
                "Create one: <code>/tasks new Title | task 1; task 2</code>\n"
                "Or just ask me to make a checklist for you."
            )

        options = [{"id": cl.id, "label": cl.title[:40]} for cl in checklists]
        lines = ["<b>Tasks</b>\n", "Select a checklist:"]
        for cl in checklists:
            lines.append(f"• <code>{cl.id}</code> — {cl.title[:60]}")

        return CommandResult.select("\n".join(lines), options=options, handler="tasks")

    @router.command("poll")
    async def cmd_poll(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Create or view polls.

        Usage:
            /poll                              - Show active polls
            /poll "Question?" opt1; opt2; opt3 - Create new poll
        """
        import re

        from otto.services.tasks import get_poll_manager, render_poll

        raw = (ctx.message.text or "").strip()
        rest = raw[len("/poll") :].strip() if raw.lower().startswith("/poll") else " ".join(args)

        if not rest:
            # List active (open) polls for this chat
            mgr = get_poll_manager()
            import sqlite3

            with sqlite3.connect(mgr.db_path) as conn:
                conn.row_factory = sqlite3.Row
                rows = conn.execute(
                    """SELECT id, question FROM polls
                       WHERE chat_id = ? AND closed = 0
                       ORDER BY created_at DESC LIMIT 10""",
                    (int(ctx.message.chat_id),),
                ).fetchall()

            if not rows:
                return CommandResult.ok(
                    "No active polls.\n\n"
                    'Create one: <code>/poll "Question?" opt1; opt2; opt3</code>'
                )

            lines = ["<b>Active Polls</b>\n"]
            options = []
            for row in rows:
                lines.append(f"• {row['question'][:50]}")
                options.append({"id": row["id"], "label": row["question"][:30]})

            return CommandResult.select("\n".join(lines), options=options, handler="poll_show")

        # Parse: "Question?" option1; option2; option3
        # The question can be quoted or unquoted (ends at ? or first ;)
        match = re.match(r'^"([^"]+)"\s*(.*)', rest)
        if match:
            question = match.group(1).strip()
            opts_str = match.group(2).strip()
        else:
            # Try splitting on ? as question delimiter
            if "?" in rest and ";" in rest:
                q_end = rest.index("?")
                question = rest[: q_end + 1].strip()
                opts_str = rest[q_end + 1 :].strip()
            else:
                return CommandResult.error('Usage: <code>/poll "Question?" opt1; opt2; opt3</code>')

        # Parse options
        opt_list = [o.strip() for o in opts_str.split(";") if o.strip()]
        if len(opt_list) < 2:
            return CommandResult.error("Polls need at least 2 options (separated by ;)")

        # Build options dict {key: label}
        options_dict = {}
        for i, opt in enumerate(opt_list):
            options_dict[str(i)] = opt

        mgr = get_poll_manager()
        poll = mgr.create_poll(
            chat_id=int(ctx.message.chat_id),
            question=question,
            options=options_dict,
            created_by="user",
        )

        user_id = ctx.message.user_id or "0"
        text, keyboard = render_poll(poll, user_id)
        return CommandResult.ok(text, reply_markup=keyboard, data={"poll_id": poll.id})

    def _cron_to_human(expr: str) -> str:
        """Convert a cron expression to a human-readable description."""
        parts = expr.strip().split()
        if len(parts) != 5:
            return expr
        mn, hr, dom, mon, dow = parts
        # Common patterns
        if expr == "* * * * *":
            return "Every minute"
        if mn != "*" and hr != "*" and dom == "*" and mon == "*" and dow == "*":
            return f"Daily at {hr.zfill(2)}:{mn.zfill(2)}"
        if mn != "*" and hr != "*" and dom == "*" and mon == "*" and dow != "*":
            day_names = {
                "0": "Sun",
                "1": "Mon",
                "2": "Tue",
                "3": "Wed",
                "4": "Thu",
                "5": "Fri",
                "6": "Sat",
                "7": "Sun",
            }
            days = ",".join(day_names.get(d.strip(), d.strip()) for d in dow.split(","))
            return f"{days} at {hr.zfill(2)}:{mn.zfill(2)}"
        if mn.startswith("*/"):
            return f"Every {mn[2:]} min"
        if mn != "*" and hr == "*":
            return f"Hourly at :{mn.zfill(2)}"
        return expr

    def _next_cron_run(expr: str) -> str:
        """Calculate next run time from a cron expression."""
        try:
            from datetime import datetime

            from croniter import croniter

            now = datetime.now()
            cron = croniter(expr, now)
            nxt = cron.get_next(datetime)
            diff = nxt - now
            secs = int(diff.total_seconds())
            if secs < 60:
                return "in <1m"
            if secs < 3600:
                return f"in {secs // 60}m"
            if secs < 86400:
                h = secs // 3600
                m = (secs % 3600) // 60
                return f"in {h}h{m}m" if m else f"in {h}h"
            return f"in {secs // 86400}d"
        except Exception:
            return ""

    @router.command("schedules")
    async def cmd_schedules(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Show dynamic schedules created by agents."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        from otto import schedule_state, schedule_store

        try:
            schedules = schedule_store.list_schedules(include_disabled=False)
        except Exception as e:
            return CommandResult.error(f"Error loading schedules: {e}")

        if not schedules:
            return CommandResult.ok(
                "<b>Schedules</b>\n\n"
                "No active schedules.\n\n"
                "Ask me to schedule something:\n"
                '<i>"Remind me to check email in 2 minutes"</i>\n'
                '<i>"Search HN for AI news every day at 9am"</i>'
            )

        lines = [f"<b>Schedules</b> ({len(schedules)} active)\n"]
        buttons: list[list[InlineKeyboardButton]] = []

        for sched in schedules:
            sid = sched["id"]
            name = (sched.get("name") or "")[:40]
            stype = sched.get("schedule_type", "once")

            if stype == "recurring" and sched.get("cron_expr"):
                human = _cron_to_human(sched["cron_expr"])
                nxt = _next_cron_run(sched["cron_expr"])
                type_str = f"🔄 {human} ({nxt})"
            elif sched.get("run_at"):
                try:
                    from datetime import datetime as dt

                    target = dt.fromisoformat(sched["run_at"])
                    diff = target - dt.now()
                    secs = int(diff.total_seconds())
                    if secs <= 0:
                        nxt = "due now"
                    elif secs < 60:
                        nxt = f"in {secs}s"
                    elif secs < 3600:
                        nxt = f"in {secs // 60}m"
                    elif secs < 86400:
                        h = secs // 3600
                        m = (secs % 3600) // 60
                        nxt = f"in {h}h{m}m" if m else f"in {h}h"
                    else:
                        nxt = f"in {secs // 86400}d"
                except Exception:
                    nxt = ""
                type_str = f"⏱ One-shot ({nxt})" if nxt else "⏱ One-shot"
            else:
                type_str = "⏱ One-shot"

            # Load run state
            state = schedule_state.load(sid)
            run_count = state.get("run_count", 0)
            last_status = state.get("last_status", "")
            status_str = ""
            if run_count:
                icon = (
                    "✓" if last_status == "completed" else "✗" if last_status == "failed" else "?"
                )
                status_str = f" | {icon} {run_count} runs"

            lines.append(f"<b>{name}</b>")
            lines.append(f"  {type_str}{status_str}")
            lines.append(f"  <code>{sid}</code>")
            lines.append("")

            short_id = sid[:20]
            row = [
                InlineKeyboardButton("Cancel", callback_data=f"sched_cancel:{short_id}"),
                InlineKeyboardButton("Run Now", callback_data=f"sched_run:{short_id}"),
            ]
            buttons.append(row)

        buttons.append([InlineKeyboardButton("Refresh", callback_data="sched_ref:1")])

        return CommandResult.ok(
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup(buttons),
        )

    @router.callback("sched_cancel")
    async def cb_sched_cancel(ctx: ChatContext, value: str) -> CommandResult:
        """Cancel a dynamic schedule."""
        from otto import schedule_state, schedule_store

        if not value:
            return CommandResult.error("Missing schedule ID.")

        sched = schedule_store.get_schedule(value)
        if not sched:
            return CommandResult.error(f"Schedule not found: {value}")

        schedule_store.disable_schedule(value)
        state = schedule_state.load(value)
        state["disabled"] = True
        schedule_state.save(value, state)

        return await cmd_schedules(ctx, [])

    @router.callback("sched_run")
    async def cb_sched_run(ctx: ChatContext, value: str) -> CommandResult:
        """Trigger immediate execution of a dynamic schedule."""
        from otto import schedule_store

        if not value:
            return CommandResult.error("Missing schedule ID.")

        sched = schedule_store.get_schedule(value)
        if not sched:
            return CommandResult.error(f"Schedule not found: {value}")

        prompt = sched.get("prompt", "")
        if not prompt:
            return CommandResult.error("Schedule has no prompt.")

        return CommandResult.ok(
            f"Running schedule <b>{sched.get('name', value)[:40]}</b>...\n\n<i>{prompt[:100]}</i>",
            data={"run_job": value, "prompt": prompt},
        )

    @router.callback("sched_ref")
    async def cb_sched_refresh(ctx: ChatContext, value: str) -> CommandResult:
        """Refresh schedules view."""
        return await cmd_schedules(ctx, [])

    @router.command("jobs")
    async def cmd_jobs(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Show scheduled jobs with human-readable schedules and actions."""
        import yaml
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        from otto.paths import BRAINFILE

        no_jobs_msg = (
            "<b>Scheduled Jobs</b>\n\n"
            "No jobs configured.\n\n"
            "Add jobs to <code>~/.otto/brainfile.md</code>:\n"
            "<code>---\njobs:\n"
            "  - id: backup\n"
            '    schedule: "0 2 * * *"\n'
            "    task: run backup\n"
            "---</code>"
        )

        if not BRAINFILE.exists():
            return CommandResult.ok(no_jobs_msg)

        try:
            content = BRAINFILE.read_text()
            if not content.startswith("---"):
                return CommandResult.ok(no_jobs_msg)

            end = content.find("\n---", 3)
            if end == -1:
                return CommandResult.ok(no_jobs_msg)

            data = yaml.safe_load(content[4:end]) or {}
            jobs = data.get("jobs", [])
        except Exception as e:
            return CommandResult.error(f"Error reading jobs: {e}")

        if not jobs:
            return CommandResult.ok(no_jobs_msg)

        enabled_count = sum(1 for j in jobs if j.get("enabled", True))
        lines = [f"<b>Scheduled Jobs</b>  ({len(jobs)} jobs, {enabled_count} enabled)\n"]

        buttons = []
        for j in jobs:
            enabled = j.get("enabled", True)
            job_id = j.get("id", "?")
            schedule = j.get("schedule", "?")
            task = j.get("task", "")

            icon = "ON" if enabled else "OFF"
            human = _cron_to_human(schedule)
            nxt = _next_cron_run(schedule) if enabled else "paused"

            lines.append(f"{'>' if enabled else '  '} <b>{job_id}</b>  [{icon}]")
            lines.append(f"    {human}  ({nxt})")
            if task:
                lines.append(f"    <i>{task[:60]}</i>")
            lines.append("")

            # Per-job action buttons
            toggle_label = "Disable" if enabled else "Enable"
            toggle_icon = "OFF" if enabled else "ON"
            row = [
                InlineKeyboardButton(
                    f"{toggle_icon} {toggle_label}", callback_data=f"job_tgl:{job_id}"
                ),
                InlineKeyboardButton("Run Now", callback_data=f"job_run:{job_id}"),
            ]
            buttons.append(row)

        keyboard = InlineKeyboardMarkup(buttons)
        return CommandResult.ok("\n".join(lines), reply_markup=keyboard)

    @router.command("reindex")
    async def cmd_reindex(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Re-index memory."""
        stats = memory_stats()
        return CommandResult.confirm(
            f"Re-index Memory?\n\nCurrent: {stats.get('total_chunks', 0)} chunks\n\n"
            "This will rebuild the search index from:\n"
            "• Knowledge files\n"
            "• Project notes\n"
            "• Session history",
            handler="reindex",
            data=stats,
        )

    # -------------------------------------------------------------------------
    # Callback handlers
    # -------------------------------------------------------------------------

    @router.callback("restart")
    async def cb_restart(ctx: ChatContext, value: str) -> CommandResult:
        """Handle restart confirmation."""
        if value == "yes":
            # Platform will handle the actual restart
            return CommandResult.ok(
                "Restarting...",
                data={"action": "do_restart"},
            )
        return CommandResult.ok("Restart cancelled.")

    @router.callback("status_action")
    async def cb_status_action(ctx: ChatContext, value: str) -> CommandResult:
        """Route status quick actions to appropriate commands."""
        if value == "refresh":
            return await cmd_status(ctx, [])
        elif value == "backend":
            return await cmd_backend(ctx, [])
        elif value == "new":
            return await cmd_new(ctx, [])
        elif value == "agents":
            return await cmd_agents(ctx, [])
        return CommandResult.error(f"Unknown status action: {value}")

    @router.callback("help_cat")
    async def cb_help_cat(ctx: ChatContext, value: str) -> CommandResult:
        """Show commands in a help category."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        categories = {
            "conv": (
                "<b>Conversations</b>\n\n"
                "/new [topic] — Start fresh session\n"
                "/sessions — List/switch sessions\n"
                "/stop — Cancel current response"
            ),
            "ai": (
                "<b>AI &amp; Agents</b>\n\n"
                "/backend [name] — Show/switch backend\n"
                "/thinking — Toggle extended thinking\n"
                "/agents [limit] — List sub-agents\n"
                "/agents cancel &lt;id|all&gt; — Cancel agents"
            ),
            "mem": (
                "<b>Memory &amp; Tasks</b>\n\n"
                "/memory [query] — Search memory\n"
                "/tasks — Task checklists\n"
                "/poll — Create or view polls\n"
                "/jobs — Brainfile scheduled jobs"
            ),
            "tools": (
                "<b>MCP &amp; Tools</b>\n\n"
                "/mcp [subcmd] — Manage MCP servers\n"
                "/activity — Tool activity dashboard\n"
                "/audit [subcmd] — Query audit log\n"
                "/pause &lt;server&gt; — Pause/resume MCP server"
            ),
            "sys": (
                "<b>System</b>\n\n"
                "/status — Live system status\n"
                "/vtt — Toggle voice-to-text\n"
                "/reindex — Rebuild memory index\n"
                "/restart — Restart Otto safely\n"
                "/schedules — Dynamic agent schedules"
            ),
        }

        text = categories.get(value)
        if not text:
            return CommandResult.error(f"Unknown category: {value}")

        back_btn = InlineKeyboardButton("« Back", callback_data="help_back:main")
        buttons = [[back_btn]]

        return CommandResult.ok(text, reply_markup=InlineKeyboardMarkup(buttons))

    @router.callback("help_back")
    async def cb_help_back(ctx: ChatContext, value: str) -> CommandResult:
        """Return to main help menu."""
        return await cmd_help(ctx, [])

    @router.callback("help_run")
    async def cb_help_run(ctx: ChatContext, value: str) -> CommandResult:
        """Execute a command directly from help menu."""
        cmd_map = {
            "new": cmd_new,
            "status": cmd_status,
            "agents": cmd_agents,
        }
        handler = cmd_map.get(value)
        if handler:
            return await handler(ctx, [])
        return CommandResult.error(f"Unknown command: {value}")

    @router.callback("backend")
    async def cb_backend(ctx: ChatContext, value: str) -> CommandResult:
        """Handle backend selection."""
        import os

        from otto.backends import get_backend, set_active_backend

        from .. import config as otto_config

        if value == "cancel":
            return CommandResult.ok("Backend unchanged.")

        active = get_active_backend_name()
        if value == active:
            return CommandResult.ok(f"Already using {value}")

        backends = list_backends()
        if value not in backends:
            return CommandResult.error(f"Unknown backend: {value}")

        # Check if backend is enabled, enable it if not
        backend_cfg = backends.get(value, {})
        if not backend_cfg.get("enabled", False):
            # Auto-enable the backend when selected
            otto_config.set_setting(f"agent.backends.{value}.enabled", True)

        try:
            backend = get_backend(value)
            if not backend.is_available():
                # Provide helpful error messages based on backend
                if value == "generic":
                    return CommandResult.error(
                        f"Backend {value} requires litellm.\n\n"
                        "Install with:\n"
                        "<code>pip install litellm</code>"
                    )
                return CommandResult.error(f"Backend {value} is not available (check path/config)")

            set_active_backend(value)

            # Provide helpful hints for generic backend
            if value == "generic":
                model = backend_cfg.get("model", "openrouter/meta-llama/llama-3.3-70b-instruct")
                api_key_env = backend_cfg.get("sdk_options", {}).get(
                    "api_key_env", "OPENROUTER_API_KEY"
                )
                has_key = bool(os.environ.get(api_key_env))

                lines = [f"Switched to {value}"]
                lines.append(f"Model: {model}")

                if not has_key:
                    lines.append(f"\n⚠️ Set {api_key_env} for API access")
                    lines.append("\nChange model with:")
                    lines.append("<code>/backend . openrouter/provider/model-name</code>")

                return CommandResult.ok("\n".join(lines))

            return CommandResult.ok(f"Switched to {value}")
        except Exception as e:
            return CommandResult.error(f"Failed: {e}")

    @router.callback("vtt_toggle")
    async def cb_vtt_toggle(ctx: ChatContext, value: str) -> CommandResult:
        """Handle VTT toggle."""
        if value in ("no", "cancel"):
            return CommandResult.ok("VTT unchanged.")

        try:
            from otto_tools.vtt import download_model, load_config, save_config

            if value == "download":
                # Download the model
                try:
                    download_model()
                    return CommandResult.ok("Model downloaded. Enable VTT to use.")
                except Exception as e:
                    return CommandResult.error(f"Download failed: {e}")

            config = load_config()

            if value == "enable":
                config["enabled"] = True
            elif value == "disable":
                config["enabled"] = False
            else:
                # Legacy toggle behavior
                config["enabled"] = not config.get("enabled", False)

            save_config(config)
            new_state = "enabled" if config["enabled"] else "disabled"
            return CommandResult.ok(f"Voice-to-Text {new_state}")
        except ImportError:
            return CommandResult.error("VTT module not available")
        except Exception as e:
            return CommandResult.error(f"Error: {e}")

    @router.callback("thinking")
    async def cb_thinking(ctx: ChatContext, value: str) -> CommandResult:
        """Handle thinking configuration toggle."""
        from otto.config import set_setting

        if value == "cancel":
            return CommandResult.ok("Thinking config unchanged.")

        if value == "enable_thinking":
            set_setting("agent.thinking.enabled", True)
            return CommandResult.ok("✓ Extended thinking enabled")

        if value == "disable_thinking":
            set_setting("agent.thinking.enabled", False)
            return CommandResult.ok("○ Extended thinking disabled")

        if value == "show_thinking":
            set_setting("agent.thinking.show_in_chat", True)
            return CommandResult.ok("✓ Thinking will be shown in chat")

        if value == "hide_thinking":
            set_setting("agent.thinking.show_in_chat", False)
            return CommandResult.ok("○ Thinking will be hidden in chat")

        return CommandResult.error(f"Unknown action: {value}")

    @router.callback("reindex")
    async def cb_reindex(ctx: ChatContext, value: str) -> CommandResult:
        """Handle reindex confirmation."""
        if value != "yes":
            return CommandResult.ok("Reindex cancelled.")

        from otto import index_memory

        try:
            counts = index_memory(force=True)
            return CommandResult.ok(
                f"Indexed: {counts.get('total', 0)} chunks\n"
                f"Knowledge: {counts.get('knowledge', 0)}\n"
                f"Projects: {counts.get('projects', 0)}\n"
                f"Sessions: {counts.get('sessions', 0)}"
            )
        except Exception as e:
            return CommandResult.error(f"Indexing failed: {e}")

    @router.callback("mcp")
    async def cb_mcp(ctx: ChatContext, value: str) -> CommandResult:
        """Route MCP callbacks: info_*, enable_*, disable_*, gateway, refresh, back."""
        if not value:
            return _render_mcp_list()

        if value == "refresh" or value == "back":
            return _render_mcp_list()

        if value == "gateway":
            return _render_mcp_gateway()

        if value.startswith("info_"):
            return _render_mcp_info(value[5:])

        if value.startswith("enable_"):
            return _mcp_toggle(value[7:], enable=True)

        if value.startswith("disable_"):
            return _mcp_toggle(value[8:], enable=False)

        if value == "ks_on":
            from otto.gateway import activate_kill_switch

            activate_kill_switch()
            return _render_mcp_gateway()

        if value == "ks_off":
            from otto.gateway import deactivate_kill_switch

            deactivate_kill_switch()
            return _render_mcp_gateway()

        # Catalog callbacks
        if value == "catalog":
            return _render_mcp_catalog()

        if value.startswith("cat_"):
            return _render_mcp_catalog(value[4:])

        if value.startswith("catinfo_"):
            return _render_mcp_catalog_detail(value[8:])

        if value.startswith("inst_"):
            return _mcp_install(value[5:])

        if value.startswith("rm_"):
            return _mcp_remove(value[3:])

        if value == "test":
            return await _mcp_test()

        if value.startswith("test_"):
            return await _mcp_test(value[5:])

        return CommandResult.error(f"Unknown MCP action: {value}")

    @router.callback("job_tgl")
    async def cb_job_toggle(ctx: ChatContext, value: str) -> CommandResult:
        """Toggle a job's enabled state."""
        import yaml

        from otto.paths import BRAINFILE

        job_id = value

        try:
            content = BRAINFILE.read_text()
            if not content.startswith("---"):
                return CommandResult.error("No jobs in brainfile.")

            end = content.find("\n---", 3)
            if end == -1:
                return CommandResult.error("Invalid brainfile format.")

            data = yaml.safe_load(content[4:end]) or {}
            markdown = content[end + 4 :].strip()
            jobs = data.get("jobs", [])

            found = False
            new_state = False
            for j in jobs:
                if j.get("id") == job_id:
                    current = j.get("enabled", True)
                    new_state = not current
                    j["enabled"] = new_state
                    found = True
                    break

            if not found:
                return CommandResult.error(f"Job not found: {job_id}")

            new_content = "---\n"
            new_content += yaml.dump(
                data, default_flow_style=False, allow_unicode=True, sort_keys=False
            )
            new_content += "---\n\n"
            new_content += markdown
            BRAINFILE.write_text(new_content)

            status = "enabled" if new_state else "disabled"
            return CommandResult.ok(f"Job <b>{job_id}</b> {status}.")
        except Exception as e:
            return CommandResult.error(f"Failed: {e}")

    @router.callback("job_run")
    async def cb_job_run(ctx: ChatContext, value: str) -> CommandResult:
        """Trigger immediate execution of a job."""
        import yaml

        from otto.paths import BRAINFILE

        job_id = value

        try:
            content = BRAINFILE.read_text()
            if not content.startswith("---"):
                return CommandResult.error("No jobs in brainfile.")

            end = content.find("\n---", 3)
            if end == -1:
                return CommandResult.error("Invalid brainfile format.")

            data = yaml.safe_load(content[4:end]) or {}
            jobs = data.get("jobs", [])

            target = None
            for j in jobs:
                if j.get("id") == job_id:
                    target = j
                    break

            if not target:
                return CommandResult.error(f"Job not found: {job_id}")

            task_prompt = target.get("task", "")
            if not task_prompt:
                return CommandResult.error(f"Job {job_id} has no task defined.")

            # Queue the job as a message for the pipeline to process
            return CommandResult.ok(
                f"Running job <b>{job_id}</b>...\n\n<i>{task_prompt[:100]}</i>",
                data={"run_job": job_id, "prompt": task_prompt},
            )
        except Exception as e:
            return CommandResult.error(f"Failed: {e}")

    @router.callback("session")
    async def cb_session(ctx: ChatContext, value: str) -> CommandResult:
        """Handle session switch (legacy)."""
        from otto import load_session

        if value == "cancel":
            return CommandResult.ok("Session unchanged.")

        session = load_session(value, chat_id=ctx.message.chat_id)
        if session:
            topic = session.get("topic") or value[:15]
            return CommandResult.ok(f"Resumed session: {topic}")
        return CommandResult.error(f"Session not found: {value}")

    @router.callback("sess_pg")
    async def cb_session_page(ctx: ChatContext, value: str) -> CommandResult:
        """Navigate session pages."""
        try:
            page = int(value)
        except ValueError:
            page = 0
        return _render_sessions_page(page, chat_id=ctx.message.chat_id)

    @router.callback("sess_sw")
    async def cb_session_switch(ctx: ChatContext, value: str) -> CommandResult:
        """Switch to a session."""
        from otto import load_session

        if not value:
            return CommandResult.error("Missing session ID.")

        session = load_session(value, chat_id=ctx.message.chat_id)
        if session:
            topic = session.get("topic") or value[:15]
            return CommandResult.ok(f"Switched to: {topic}")
        return CommandResult.error(f"Session not found: {value}")

    @router.callback("sess_del")
    async def cb_session_delete_confirm(ctx: ChatContext, value: str) -> CommandResult:
        """Ask for delete confirmation."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        if not value:
            return CommandResult.error("Missing session ID.")

        buttons = InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("Yes, delete", callback_data=f"sess_rm:{value[:52]}"),
                    InlineKeyboardButton("Cancel", callback_data="sess_pg:0"),
                ]
            ]
        )

        return CommandResult.ok(
            f"Delete session <code>{value[:20]}</code>?\n\nThis cannot be undone.",
            reply_markup=buttons,
        )

    @router.callback("sess_rm")
    async def cb_session_delete(ctx: ChatContext, value: str) -> CommandResult:
        """Actually delete a session and return to list."""
        if not value:
            return CommandResult.error("Missing session ID.")

        if delete_session(value):
            return _render_sessions_page(0)
        return CommandResult.error(f"Session not found: {value}")

    @router.callback("tasks")
    async def cb_tasks(ctx: ChatContext, value: str) -> CommandResult:
        """Open a checklist from /tasks selection."""
        from otto.services.tasks import get_checklist, get_task_manager, render_checklist

        if value == "cancel":
            return CommandResult.ok("Cancelled.")

        checklist = get_checklist(value)
        if not checklist:
            return CommandResult.error("Checklist not found.")

        # Track the Telegram message_id that now represents this checklist.
        if ctx.message.message_id:
            try:
                get_task_manager().update_checklist_message_id(value, int(ctx.message.message_id))
                checklist.message_id = int(ctx.message.message_id)
            except Exception:
                pass

        text, keyboard = render_checklist(checklist)
        return CommandResult.ok(
            text, reply_markup=keyboard, data={"task_checklist_id": checklist.id}
        )

    @router.callback("task_toggle")
    async def cb_task_toggle(ctx: ChatContext, value: str) -> CommandResult:
        """Toggle a task and refresh the checklist UI."""
        from otto.services.tasks import (
            get_checklist,
            get_task_manager,
            render_checklist,
            toggle_task,
        )

        if not value:
            return CommandResult.error("Missing task ID.")

        task = toggle_task(value, toggled_by="user")
        if not task or not task.checklist_id:
            return CommandResult.error("Task not found.")

        checklist_id = str(task.checklist_id)
        checklist = get_checklist(checklist_id)
        if not checklist:
            return CommandResult.error("Checklist not found.")

        if ctx.message.message_id:
            try:
                get_task_manager().update_checklist_message_id(
                    checklist_id, int(ctx.message.message_id)
                )
                checklist.message_id = int(ctx.message.message_id)
            except Exception:
                pass

        text, keyboard = render_checklist(checklist)
        return CommandResult.ok(
            text, reply_markup=keyboard, data={"task_checklist_id": checklist.id}
        )

    @router.callback("task_done")
    async def cb_task_done(ctx: ChatContext, value: str) -> CommandResult:
        """Close a checklist UI (hide the keyboard)."""
        from otto.services.tasks import get_checklist, render_checklist

        if not value:
            return CommandResult.error("Missing checklist ID.")

        checklist = get_checklist(value)
        if not checklist:
            return CommandResult.error("Checklist not found.")

        text, _keyboard = render_checklist(checklist)
        return CommandResult.ok(f"{text}\n\n<i>(Checklist closed)</i>")

    @router.callback("poll_show")
    async def cb_poll_show(ctx: ChatContext, value: str) -> CommandResult:
        """Show a poll from the poll list selection."""
        from otto.services.tasks import get_poll_manager, render_poll

        if value == "cancel":
            return CommandResult.ok("Cancelled.")

        mgr = get_poll_manager()
        poll = mgr.get_poll(value)
        if not poll:
            return CommandResult.error("Poll not found.")

        user_id = ctx.message.user_id or "0"
        text, keyboard = render_poll(poll, user_id)
        return CommandResult.ok(text, reply_markup=keyboard, data={"poll_id": poll.id})

    @router.callback("poll_vote")
    async def cb_poll_vote(ctx: ChatContext, value: str) -> CommandResult:
        """Toggle vote on a poll option. Value format: {poll_id}:{option_key}"""
        from otto.services.tasks import get_poll_manager, render_poll

        if not value or ":" not in value:
            return CommandResult.error("Invalid vote data.")

        poll_id, option_key = value.split(":", 1)
        user_id = ctx.message.user_id or "0"

        mgr = get_poll_manager()
        poll = mgr.get_poll(poll_id)
        if not poll:
            return CommandResult.error("Poll not found.")

        if poll.closed:
            text = mgr.render_poll_text(poll)
            return CommandResult.ok(text)

        mgr.toggle_vote(poll_id, user_id, option_key)

        # Re-fetch poll with updated votes
        poll = mgr.get_poll(poll_id)
        text, keyboard = render_poll(poll, user_id)
        return CommandResult.ok(text, reply_markup=keyboard, data={"poll_id": poll.id})

    @router.callback("poll_results")
    async def cb_poll_results(ctx: ChatContext, value: str) -> CommandResult:
        """Show poll results view."""
        from otto.services.tasks import get_poll_manager

        mgr = get_poll_manager()
        poll = mgr.get_poll(value)
        if not poll:
            return CommandResult.error("Poll not found.")

        text = mgr.render_poll_text(poll)
        return CommandResult.ok(text)

    @router.callback("poll_close")
    async def cb_poll_close(ctx: ChatContext, value: str) -> CommandResult:
        """Close a poll to voting."""
        from otto.services.tasks import get_poll_manager

        mgr = get_poll_manager()
        poll = mgr.get_poll(value)
        if not poll:
            return CommandResult.error("Poll not found.")

        mgr.close_poll(value)

        # Re-fetch with closed state
        poll = mgr.get_poll(value)
        text = mgr.render_poll_text(poll)
        return CommandResult.ok(text)
