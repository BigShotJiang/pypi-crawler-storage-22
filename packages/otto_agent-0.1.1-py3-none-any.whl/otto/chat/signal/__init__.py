"""
Signal chat platform for Otto.

Uses signal-cli-rest-api Docker container for Signal integration.
"""

from .client import SignalClient
from .platform import SignalPlatform
from .renderer import SignalRenderer, render_result

__all__ = ["SignalPlatform", "SignalClient", "SignalRenderer", "render_result"]
