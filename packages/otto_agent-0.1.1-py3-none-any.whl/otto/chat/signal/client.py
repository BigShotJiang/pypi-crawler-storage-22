"""
Signal CLI REST API client.

Communicates with signal-cli-rest-api Docker container.
https://github.com/bbernhard/signal-cli-rest-api
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from pathlib import Path

import aiohttp

log = logging.getLogger(__name__)


@dataclass
class SignalMessage:
    """Represents an incoming Signal message."""

    envelope: dict
    source: str  # Phone number of sender
    source_name: str | None
    timestamp: int
    text: str | None
    attachments: list[dict]
    group_id: str | None
    is_group: bool

    @classmethod
    def from_envelope(cls, envelope: dict) -> SignalMessage | None:
        """Parse a message from signal-cli envelope."""
        data_message = envelope.get("dataMessage")
        if not data_message:
            return None

        source = envelope.get("source", "")
        source_name = envelope.get("sourceName")
        timestamp = data_message.get("timestamp", 0)
        text = data_message.get("message")
        attachments = data_message.get("attachments", [])

        # Group handling
        group_info = data_message.get("groupInfo")
        group_id = group_info.get("groupId") if group_info else None
        is_group = group_id is not None

        return cls(
            envelope=envelope,
            source=source,
            source_name=source_name,
            timestamp=timestamp,
            text=text,
            attachments=attachments,
            group_id=group_id,
            is_group=is_group,
        )

    @property
    def chat_id(self) -> str:
        """Get chat identifier (group_id or source number)."""
        return self.group_id or self.source

    @property
    def sender_display(self) -> str:
        """Get sender display name."""
        return self.source_name or self.source


class SignalClient:
    """
    Async client for signal-cli-rest-api.

    Usage:
        async with SignalClient("http://localhost:8080", "+1234567890") as client:
            # Send message
            await client.send_message("+0987654321", "Hello!")

            # Receive messages (polling)
            async for msg in client.receive_messages():
                print(msg.text)
    """

    def __init__(
        self,
        api_url: str = "http://localhost:8080",
        phone_number: str = "",
        poll_interval: float = 1.0,
    ):
        self.api_url = api_url.rstrip("/")
        self.phone_number = phone_number
        self.poll_interval = poll_interval
        self._session: aiohttp.ClientSession | None = None
        self._running = False

    async def __aenter__(self) -> SignalClient:
        self._session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, *args):
        if self._session:
            await self._session.close()
            self._session = None

    async def _ensure_session(self):
        if self._session is None:
            self._session = aiohttp.ClientSession()

    async def close(self):
        """Close the client session."""
        self._running = False
        if self._session:
            await self._session.close()
            self._session = None

    # -------------------------------------------------------------------------
    # API Methods
    # -------------------------------------------------------------------------

    async def about(self) -> dict:
        """Get API info."""
        await self._ensure_session()
        async with self._session.get(f"{self.api_url}/v1/about") as resp:
            return await resp.json()

    async def health(self) -> bool:
        """Check API health."""
        try:
            await self._ensure_session()
            async with self._session.get(f"{self.api_url}/v1/health") as resp:
                return resp.status == 200
        except Exception:
            return False

    async def register(self, captcha: str | None = None, voice: bool = False) -> dict:
        """Register a new Signal account."""
        await self._ensure_session()
        data = {"use_voice": voice}
        if captcha:
            data["captcha"] = captcha

        async with self._session.post(
            f"{self.api_url}/v1/register/{self.phone_number}",
            json=data,
        ) as resp:
            return await resp.json()

    async def verify(self, code: str) -> dict:
        """Verify registration with SMS code."""
        await self._ensure_session()
        async with self._session.post(
            f"{self.api_url}/v1/register/{self.phone_number}/verify/{code}"
        ) as resp:
            return await resp.json()

    async def link(self, device_name: str = "Otto Bot") -> str:
        """
        Link as a secondary device. Returns the QR code URI.

        The user scans this QR code in their Signal app to link.
        """
        await self._ensure_session()
        async with self._session.get(
            f"{self.api_url}/v1/qrcodelink",
            params={"device_name": device_name},
        ) as resp:
            if resp.status == 200:
                # Returns the QR code as PNG image
                return f"{self.api_url}/v1/qrcodelink?device_name={device_name}"
            data = await resp.json()
            raise Exception(f"Link failed: {data}")

    async def get_linked_devices(self) -> list[dict]:
        """Get list of linked devices."""
        await self._ensure_session()
        async with self._session.get(f"{self.api_url}/v1/devices/{self.phone_number}") as resp:
            return await resp.json()

    async def send_message(
        self,
        recipient: str,
        message: str,
        attachments: list[str] | None = None,
    ) -> dict:
        """
        Send a message to a recipient.

        Args:
            recipient: Phone number or group ID
            message: Text message
            attachments: List of base64-encoded attachments
        """
        await self._ensure_session()

        data = {
            "message": message,
            "number": self.phone_number,
            "recipients": [recipient],
        }

        if attachments:
            data["base64_attachments"] = attachments

        async with self._session.post(
            f"{self.api_url}/v2/send",
            json=data,
        ) as resp:
            result = await resp.json()
            if resp.status not in (200, 201):
                log.error(f"Send failed: {result}")
            return result

    async def send_group_message(
        self,
        group_id: str,
        message: str,
        attachments: list[str] | None = None,
    ) -> dict:
        """Send a message to a group."""
        await self._ensure_session()

        data = {
            "message": message,
            "number": self.phone_number,
            "recipients": [group_id],
        }

        if attachments:
            data["base64_attachments"] = attachments

        async with self._session.post(
            f"{self.api_url}/v2/send",
            json=data,
        ) as resp:
            return await resp.json()

    async def receive(self) -> list[SignalMessage]:
        """
        Receive pending messages.

        This is a polling endpoint - call periodically to get new messages.
        """
        await self._ensure_session()

        try:
            async with self._session.get(
                f"{self.api_url}/v1/receive/{self.phone_number}",
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                if resp.status != 200:
                    return []

                data = await resp.json()
                messages = []

                for item in data:
                    envelope = item.get("envelope", {})
                    msg = SignalMessage.from_envelope(envelope)
                    if msg:
                        messages.append(msg)

                return messages

        except asyncio.TimeoutError:
            return []
        except Exception as e:
            log.error(f"Receive error: {e}")
            return []

    async def receive_messages(self):
        """
        Async generator that yields messages as they arrive.

        Usage:
            async for msg in client.receive_messages():
                print(msg.text)
        """
        self._running = True

        while self._running:
            messages = await self.receive()

            for msg in messages:
                yield msg

            await asyncio.sleep(self.poll_interval)

    async def send_typing(self, recipient: str) -> None:
        """Send typing indicator."""
        # signal-cli-rest-api doesn't expose typing indicators directly
        # This is a no-op for now
        pass

    async def send_reaction(self, recipient: str, emoji: str, target_timestamp: int) -> dict:
        """React to a message."""
        await self._ensure_session()

        data = {
            "recipient": recipient,
            "reaction": emoji,
            "target_author": recipient,
            "target_timestamp": target_timestamp,
        }

        async with self._session.post(
            f"{self.api_url}/v1/reactions/{self.phone_number}",
            json=data,
        ) as resp:
            return await resp.json()

    async def get_groups(self) -> list[dict]:
        """Get list of groups."""
        await self._ensure_session()
        async with self._session.get(f"{self.api_url}/v1/groups/{self.phone_number}") as resp:
            return await resp.json()

    async def get_contacts(self) -> list[dict]:
        """Get list of contacts."""
        await self._ensure_session()
        async with self._session.get(f"{self.api_url}/v1/contacts/{self.phone_number}") as resp:
            return await resp.json()

    async def download_attachment(self, attachment_id: str, destination: Path) -> Path:
        """Download an attachment to a file."""
        await self._ensure_session()

        async with self._session.get(f"{self.api_url}/v1/attachments/{attachment_id}") as resp:
            if resp.status == 200:
                destination.parent.mkdir(parents=True, exist_ok=True)
                content = await resp.read()
                destination.write_bytes(content)
                return destination
            else:
                raise Exception(f"Download failed: {resp.status}")

    async def upload_attachment(self, file_path: Path) -> str:
        """
        Upload a file and return base64-encoded content for sending.

        Note: signal-cli-rest-api expects base64 attachments inline.
        """
        import base64

        content = file_path.read_bytes()
        return base64.b64encode(content).decode("utf-8")

    def stop(self):
        """Stop receiving messages."""
        self._running = False
