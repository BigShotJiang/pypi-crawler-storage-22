"""
Signal platform implementation for Otto chat abstraction.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

from ..adapters.security import SecurityAdapter
from ..base import ChatContext, ChatMessage, ChatPlatform, PlatformCapabilities
from ..commands import CommandResult
from ..core import ChatCore
from .client import SignalClient, SignalMessage
from .renderer import SignalRenderer

log = logging.getLogger(__name__)


class SignalPlatform(ChatPlatform):
    """
    Signal platform using signal-cli-rest-api.

    Features:
    - Plain text messaging (no rich formatting)
    - Voice message transcription (VTT)
    - Photo analysis
    - File attachments
    - Slash commands (/help, /status, etc.)
    - Security context and audit logging
    - Background agent notification delivery
    - No inline keyboards or buttons (text-based menus instead)
    """

    name = "Signal"

    capabilities = PlatformCapabilities(
        inline_keyboards=False,
        buttons=False,
        rich_formatting=False,  # Plain text only
        voice_messages=True,
        file_attachments=True,
        photos=True,
        edit_messages=False,
        reactions=True,
        typing_indicator=False,  # Not exposed by API
        max_message_length=8000,  # Signal allows longer messages
    )

    def __init__(
        self,
        api_url: str = "http://localhost:8080",
        phone_number: str = "",
        allowed_numbers: set[str] | None = None,
    ):
        self.api_url = api_url
        self.phone_number = phone_number
        self.allowed_numbers = allowed_numbers or set()

        from otto import config as otto_config

        self.security = SecurityAdapter(config_module=otto_config)

        self.client: SignalClient | None = None
        self.core: ChatCore | None = None
        self.renderer = SignalRenderer()
        self._running = False
        self._pending_selections: dict[str, dict] = {}  # user_id -> {options, handler}

        # Per-user locks for LLM requests - prevents concurrent LLM calls per user
        self._user_locks: dict[str, asyncio.Lock] = {}

    async def start(self) -> None:
        """Start the Signal platform."""
        log.info("Starting Signal platform for %s", self.phone_number)

        self.client = SignalClient(
            api_url=self.api_url,
            phone_number=self.phone_number,
        )
        await self.client._ensure_session()

        self.core = ChatCore(self)
        self._running = True

        # Start message loop and internal message processor
        asyncio.create_task(self._message_loop())
        asyncio.create_task(self._internal_message_loop())

        log.info("Signal platform started")

    async def stop(self) -> None:
        """Stop the Signal platform."""
        log.info("Stopping Signal platform")
        self._running = False

        if self.client:
            self.client.stop()
            await self.client.close()
            self.client = None

    # -------------------------------------------------------------------------
    # Authorization
    # -------------------------------------------------------------------------

    def _is_authorized(self, ctx: ChatContext) -> bool:
        """Check if this request is authorized (and emit audit logs)."""
        from otto import audit

        if ctx.security is None:
            return True

        if ctx.security.is_authorized:
            if ctx.security.bootstrapped_owner:
                audit.log_security(
                    "owner_bootstrapped",
                    user_id=ctx.message.user_id,
                    username=ctx.message.user_name,
                    data={"platform": ctx.message.platform},
                )
            return True

        audit.log_security(
            "auth_denied",
            user_id=ctx.message.user_id,
            username=ctx.message.user_name,
            success=False,
            data={"reason": "not_in_allowed_users"},
        )
        return False

    # -------------------------------------------------------------------------
    # Per-user concurrency
    # -------------------------------------------------------------------------

    def _get_user_lock(self, user_id: str) -> asyncio.Lock:
        """Get or create a lock for a specific user."""
        if user_id not in self._user_locks:
            self._user_locks[user_id] = asyncio.Lock()
        return self._user_locks[user_id]

    # -------------------------------------------------------------------------
    # Message loop
    # -------------------------------------------------------------------------

    async def _message_loop(self):
        """Main message receiving loop."""
        log.info("Starting Signal message loop")

        while self._running:
            try:
                messages = await self.client.receive()

                for msg in messages:
                    if msg.attachments:
                        await self._handle_attachments(msg)
                    elif msg.text:
                        await self._handle_message(msg)

            except asyncio.CancelledError:
                break
            except Exception as e:
                log.exception("Message loop error: %s", e)
                await asyncio.sleep(5)  # Back off on error

            await asyncio.sleep(1.0)  # Poll interval

    async def _handle_message(self, msg: SignalMessage):
        """Handle an incoming Signal text message."""
        ctx = self._create_context(msg)

        if not self._is_authorized(ctx):
            log.warning("Unauthorized message from %s", msg.source)
            await self.send_message(msg.source, "Access denied. This bot is private.")
            return

        log.info("Message from %s: %s", msg.sender_display, (msg.text or "")[:80])

        # Intercept /stop and /cancel BEFORE the per-user lock so they
        # execute immediately even while an LLM request is in progress.
        text = (msg.text or "").strip()
        if text.lower() in ("/stop", "/cancel"):
            from ..commands import get_command_router

            router = get_command_router()
            result = await router.handle(ctx, text)
            if result:
                await self._send_command_result(ctx, result)
            return

        # Audit log
        from otto import audit, get_current_session

        session = get_current_session(chat_id=ctx.message.chat_id)
        audit.log_message(
            "user",
            msg.text or "",
            user_id=msg.source,
            username=msg.sender_display,
            session_id=session.get("id"),
        )

        # Check for pending selection/confirmation
        user_id = msg.source
        if user_id in self._pending_selections:
            await self._handle_pending_response(ctx, msg.text)
            return

        # Get per-user lock to prevent concurrent LLM requests
        lock = self._get_user_lock(user_id)

        if lock.locked():
            await self.send_message(
                msg.chat_id,
                "Still working on your previous message... Use /stop to cancel or /agents while you wait.",
            )
            return

        async with lock:
            # Process through core
            try:
                result = await self.core.handle_message(ctx)

                # Handle CommandResult responses
                if isinstance(result, CommandResult):
                    await self._send_command_result(ctx, result)

            except Exception as e:
                log.exception("Error handling message: %s", e)
                await self.send_message(msg.chat_id, f"Error: {e}")

    # -------------------------------------------------------------------------
    # Attachment handling (voice + photo)
    # -------------------------------------------------------------------------

    async def _handle_attachments(self, msg: SignalMessage):
        """Handle incoming attachments (voice, photos, files)."""
        ctx = self._create_context(msg)

        if not self._is_authorized(ctx):
            log.warning("Unauthorized attachment from %s", msg.source)
            return

        from otto import audit

        for attachment in msg.attachments:
            content_type = attachment.get("contentType", "")
            attachment_id = attachment.get("id", "")

            if content_type.startswith("audio/") or content_type == "application/ogg":
                await self._handle_voice(ctx, msg, attachment)
            elif content_type.startswith("image/"):
                await self._handle_photo(ctx, msg, attachment)
            else:
                # Log other attachments but don't process
                audit.log_media(
                    "file",
                    user_id=msg.source,
                    username=msg.sender_display,
                    file_path=attachment_id,
                    file_size=attachment.get("size"),
                )
                if msg.text:
                    # If there's text with the attachment, process it as text
                    await self._handle_message(msg)

    async def _handle_voice(self, ctx: ChatContext, msg: SignalMessage, attachment: dict):
        """Handle voice message attachment."""
        from otto import audit
        from otto.paths import DATA_DIR

        user_id = msg.source
        attachment_id = attachment.get("id", "")
        content_type = attachment.get("contentType", "audio/ogg")

        # Determine extension
        ext = "ogg"
        if "mp3" in content_type:
            ext = "mp3"
        elif "mp4" in content_type or "m4a" in content_type:
            ext = "m4a"

        # Download audio
        audio_dir = DATA_DIR / "audio"
        audio_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        audio_path = audio_dir / f"voice_{timestamp}.{ext}"

        try:
            await self.client.download_attachment(attachment_id, audio_path)
            audit.log_media(
                "voice",
                user_id=user_id,
                username=msg.sender_display,
                file_path=str(audio_path),
                file_size=attachment.get("size"),
            )
        except Exception as e:
            log.error("Failed to download voice: %s", e)
            await self.send_message(msg.chat_id, f"Couldn't download voice message: {e}")
            return

        # Get per-user lock
        lock = self._get_user_lock(user_id)
        if lock.locked():
            await self.send_message(msg.chat_id, "Still working on your previous message...")
            return

        async with lock:
            result = await self.core.process_with_voice(ctx, audio_path)
            if isinstance(result, CommandResult):
                await self._send_command_result(ctx, result)

    async def _handle_photo(self, ctx: ChatContext, msg: SignalMessage, attachment: dict):
        """Handle photo attachment."""
        from otto import audit
        from otto.paths import PHOTOS_DIR

        user_id = msg.source
        attachment_id = attachment.get("id", "")
        caption = msg.text or "What's in this image?"

        # Download photo
        PHOTOS_DIR.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        photo_path = PHOTOS_DIR / f"photo_{timestamp}.jpg"

        try:
            await self.client.download_attachment(attachment_id, photo_path)
            audit.log_media(
                "photo",
                user_id=user_id,
                username=msg.sender_display,
                file_path=str(photo_path),
                file_size=attachment.get("size"),
            )
        except Exception as e:
            log.error("Failed to download photo: %s", e)
            await self.send_message(msg.chat_id, f"Couldn't download photo: {e}")
            return

        # Get per-user lock
        lock = self._get_user_lock(user_id)
        if lock.locked():
            await self.send_message(msg.chat_id, "Still working on your previous message...")
            return

        async with lock:
            await self.core.process_with_image(ctx, photo_path, caption)

    # -------------------------------------------------------------------------
    # Internal message processing (agent notifications, job events)
    # -------------------------------------------------------------------------

    async def _internal_message_loop(self):
        """Periodically deliver background agent/job notifications."""
        log.info("Starting Signal internal message processor")

        # Wait a bit before first check to let things initialize
        await asyncio.sleep(10)

        while self._running:
            try:
                await self._process_internal_messages()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.exception("Internal message processing error: %s", e)

            await asyncio.sleep(10)  # Check every 10 seconds

    async def _process_internal_messages(self) -> None:
        """Process pending internal messages from background agents."""
        from otto.internal_messages import (
            claim_pending_messages,
            format_agent_completion,
            format_pipeline_completed,
            format_scheduled_job_event,
            format_system_event,
            mark_failed,
            mark_processed,
        )

        # Determine the chat_id to deliver to.
        # For Signal, we use the phone number of the owner / first allowed number.
        chat_id = self._get_notification_chat_id()
        if not chat_id:
            return

        # Process high/normal priority events
        messages = claim_pending_messages(
            worker_id="signal-bot",
            limit=10,
            types=["agent_completed", "scheduled_job", "system_event", "pipeline_completed"],
            min_priority=0,
        )

        for msg in messages:
            try:
                if msg.type == "agent_completed":
                    prompt = format_agent_completion(msg.payload)
                elif msg.type == "pipeline_completed":
                    prompt = format_pipeline_completed(msg.payload)
                elif msg.type == "scheduled_job":
                    prompt = format_scheduled_job_event(msg.payload)
                elif msg.type == "system_event":
                    prompt = format_system_event(msg.payload)
                else:
                    prompt = (
                        f"[SYSTEM: Internal event]\nType: {msg.type}\n"
                        f"Payload: {msg.payload}\n\n[Summarize this briefly.]"
                    )

                await self._deliver_internal_event(chat_id, prompt)
                mark_processed(msg.id, status="processed")

            except Exception as e:
                log.error("Failed to process internal message %s: %s", msg.id, e)
                mark_failed(msg.id, str(e))

    def _get_notification_chat_id(self) -> str | None:
        """Get the chat_id to deliver internal notifications to."""
        # Use the first allowed number (typically the owner)
        if self.allowed_numbers:
            return next(iter(self.allowed_numbers))
        # Fallback: no configured recipient
        return None

    async def _deliver_internal_event(self, chat_id: str, prompt: str) -> None:
        """Run an internal event through ChatCore and deliver notification."""
        if not self.core:
            raise RuntimeError("ChatCore not initialized")
        await self.core.process_internal_event(chat_id, prompt)

    # -------------------------------------------------------------------------
    # Helpers
    # -------------------------------------------------------------------------

    def _create_context(self, msg: SignalMessage) -> ChatContext:
        """Create a ChatContext from a SignalMessage."""
        chat_message = ChatMessage(
            text=msg.text or "",
            user_id=msg.source,
            user_name=msg.sender_display,
            chat_id=msg.chat_id,
            platform="signal",
            raw_message=msg,
            message_id=str(msg.timestamp),
        )

        ctx = ChatContext(message=chat_message, platform=self)
        ctx.security = self.security.create_context(
            user_id=chat_message.user_id,
            user_name=chat_message.user_name,
            platform=chat_message.platform,
        )
        return ctx

    async def _handle_pending_response(self, ctx: ChatContext, text: str) -> None:
        """Handle a response to a pending selection/confirmation."""
        from ..commands import get_command_router

        user_id = ctx.message.user_id
        pending = self._pending_selections.pop(user_id, None)
        if not pending:
            return

        handler = pending.get("handler")
        options = pending.get("options")
        action = pending.get("action")

        if action == "confirm":
            # Parse confirmation
            confirmed = self.renderer.parse_confirmation(text)
            if confirmed is None:
                await ctx.reply("Please reply 'yes' or 'no'.")
                self._pending_selections[user_id] = pending  # Re-add
                return
            value = "yes" if confirmed else "no"
        elif options:
            # Parse selection
            value = self.renderer.parse_selection(text, options)
            if not value:
                await ctx.reply("Invalid selection. Please reply with a number.")
                self._pending_selections[user_id] = pending  # Re-add
                return
        else:
            value = text

        # Execute callback
        router = get_command_router()
        result = await router.handle_callback(ctx, handler, value)
        await self._send_command_result(ctx, result)

    async def _send_command_result(self, ctx: ChatContext, result: CommandResult) -> None:
        """Send a CommandResult, storing pending state for interactive commands."""
        user_id = ctx.message.user_id

        # Render for Signal
        text = self.renderer.render(result)

        # Store pending state if this is an interactive command
        if result.options or result.action == "confirm":
            self._pending_selections[user_id] = {
                "options": result.options,
                "handler": result.next_handler,
                "action": result.action,
            }

        await ctx.reply(text)

    # -------------------------------------------------------------------------
    # ChatPlatform interface
    # -------------------------------------------------------------------------

    async def send_message(
        self,
        chat_id: str,
        text: str,
        parse_mode: str | None = None,
        reply_markup: Any = None,
        **kwargs,
    ) -> Any:
        """Send a text message."""
        if not self.client:
            raise RuntimeError("Signal client not initialized")

        # Strip any HTML formatting for Signal
        clean_text = self._strip_html(text)

        # Check if it's a group
        if chat_id.startswith("group."):
            return await self.client.send_group_message(chat_id, clean_text)
        else:
            return await self.client.send_message(chat_id, clean_text)

    async def send_typing(self, chat_id: str) -> None:
        """Send typing indicator (not supported on Signal API)."""
        pass  # No-op

    async def edit_message(self, chat_id: str, message_id: str, text: str, **kwargs) -> Any:
        """Edit an existing message (not supported on Signal)."""
        raise NotImplementedError("Signal doesn't support message editing")

    async def send_file(
        self, chat_id: str, file_path: Path, caption: str | None = None, **kwargs
    ) -> Any:
        """Send a file attachment."""
        if not self.client:
            raise RuntimeError("Signal client not initialized")

        # Upload file as base64
        attachment = await self.client.upload_attachment(file_path)

        message = caption or file_path.name
        return await self.client.send_message(chat_id, message, attachments=[attachment])

    async def download_file(self, file_id: str, destination: Path) -> Path:
        """Download a file from Signal."""
        if not self.client:
            raise RuntimeError("Signal client not initialized")

        return await self.client.download_attachment(file_id, destination)

    def format_text(
        self, text: str, bold: bool = False, code: bool = False, pre: bool = False
    ) -> str:
        """Format text - Signal uses plain text, so minimal formatting."""
        if pre:
            return f"```\n{text}\n```"
        if code:
            return f"`{text}`"
        if bold:
            return f"*{text}*"
        return text

    def strip_formatting(self, text: str) -> str:
        """Strip formatting from text."""
        return self._strip_html(text)

    def _strip_html(self, text: str) -> str:
        """Remove HTML tags from text."""
        import re

        # Replace common HTML tags with plain text equivalents
        text = re.sub(r"<b>(.*?)</b>", r"*\1*", text)
        text = re.sub(r"<i>(.*?)</i>", r"_\1_", text)
        text = re.sub(r"<code>(.*?)</code>", r"`\1`", text)
        text = re.sub(r"<pre>(.*?)</pre>", r"```\n\1\n```", text, flags=re.DOTALL)

        # Remove any remaining HTML tags
        text = re.sub(r"<[^>]+>", "", text)

        return text


def run_signal_bot(
    api_url: str,
    phone_number: str,
    allowed_numbers: set[str] | None = None,
):
    """
    Run the Signal bot.

    Usage:
        run_signal_bot(
            api_url="http://localhost:8080",
            phone_number="+1234567890",
            allowed_numbers={"+0987654321"},
        )
    """
    import asyncio

    async def main():
        platform = SignalPlatform(
            api_url=api_url,
            phone_number=phone_number,
            allowed_numbers=allowed_numbers,
        )

        await platform.start()

        # Keep running until interrupted
        try:
            while True:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            pass
        finally:
            await platform.stop()

    asyncio.run(main())
