"""
Signal-specific rendering of CommandResult.

Converts structured CommandResult data into text-based UI for Signal:
- Numbered option lists
- Plain text confirmations
- Text-only menus
"""

from __future__ import annotations

from typing import Any

from ..commands import CommandResult


class SignalRenderer:
    """Renders CommandResult as plain text for Signal."""

    def render(self, result: CommandResult) -> str:
        """
        Convert CommandResult to plain text.

        Args:
            result: The command result to render

        Returns:
            Formatted plain text string
        """
        text = result.text

        # Handle selection with options
        if result.options:
            text += "\n\n"
            for i, opt in enumerate(result.options, 1):
                label = opt.get("label", opt.get("id", f"Option {i}"))
                desc = opt.get("description", "")
                if desc:
                    text += f"{i}. {label} - {desc}\n"
                else:
                    text += f"{i}. {label}\n"
            text += "\nReply with number to select."

        # Handle confirmation
        if result.action == "confirm":
            text += "\n\nReply 'yes' to confirm or 'no' to cancel."

        return text

    def strip_html(self, text: str) -> str:
        """
        Strip HTML formatting from text.

        Converts common HTML tags to plain text equivalents.
        """
        import re

        # Convert HTML tags to plain text
        text = re.sub(r"<b>(.*?)</b>", r"*\1*", text)
        text = re.sub(r"<strong>(.*?)</strong>", r"*\1*", text)
        text = re.sub(r"<i>(.*?)</i>", r"_\1_", text)
        text = re.sub(r"<em>(.*?)</em>", r"_\1_", text)
        text = re.sub(r"<code>(.*?)</code>", r"`\1`", text)
        text = re.sub(r"<pre>(.*?)</pre>", r"```\n\1\n```", text, flags=re.DOTALL)

        # Remove any remaining HTML tags
        text = re.sub(r"<[^>]+>", "", text)

        return text

    def parse_selection(self, text: str, options: list[dict[str, Any]]) -> str | None:
        """
        Parse a user's selection response.

        Args:
            text: User's response text
            options: The options that were presented

        Returns:
            The selected option ID, or None if invalid
        """
        text = text.strip().lower()

        # Try to parse as number
        try:
            num = int(text)
            if 1 <= num <= len(options):
                return options[num - 1].get("id", options[num - 1].get("label"))
        except ValueError:
            pass

        # Try to match by label
        for opt in options:
            label = opt.get("label", "").lower()
            opt_id = opt.get("id", "").lower()
            if text == label or text == opt_id:
                return opt.get("id", opt.get("label"))

        return None

    def parse_confirmation(self, text: str) -> bool | None:
        """
        Parse a confirmation response.

        Args:
            text: User's response text

        Returns:
            True for yes, False for no, None if unclear
        """
        text = text.strip().lower()

        if text in ("yes", "y", "yeah", "yep", "ok", "okay", "confirm", "1"):
            return True
        if text in ("no", "n", "nope", "cancel", "nevermind", "0"):
            return False

        return None


def render_result(result: CommandResult) -> str:
    """Render a CommandResult for Signal."""
    renderer = SignalRenderer()
    return renderer.render(result)
