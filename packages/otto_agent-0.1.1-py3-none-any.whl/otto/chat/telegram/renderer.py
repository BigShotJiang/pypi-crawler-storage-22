"""
Telegram-specific rendering of CommandResult.

Converts structured CommandResult data into Telegram's rich UI elements:
- Inline keyboards for options
- Confirmation dialogs
- Selection menus
"""

from __future__ import annotations

from typing import Any

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from ..commands import CommandResult


class TelegramRenderer:
    """Renders CommandResult for Telegram's rich UI."""

    def render(self, result: CommandResult) -> tuple[str, InlineKeyboardMarkup | None]:
        """
        Convert CommandResult to (text, reply_markup).

        Args:
            result: The command result to render

        Returns:
            Tuple of (formatted text, optional keyboard markup)
        """
        text = result.text

        # Platform passthrough markup (e.g., task checklists).
        if result.reply_markup is not None:
            return text, result.reply_markup

        # Handle confirmation actions
        if result.action == "confirm":
            keyboard = self._confirm_keyboard(result.next_handler)
            return text, keyboard

        # Handle selection with options
        if result.options and result.action == "select":
            keyboard = self._options_keyboard(result.options, result.next_handler)
            return text, keyboard

        # Handle legacy buttons
        if result.buttons:
            keyboard = self._legacy_buttons(result.buttons)
            return text, keyboard

        return text, None

    def _confirm_keyboard(
        self, handler: str | None, yes_label: str = "Yes", no_label: str = "Cancel"
    ) -> InlineKeyboardMarkup:
        """Create a Yes/No confirmation keyboard."""
        prefix = handler or "confirm"
        return InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(f"✓ {yes_label}", callback_data=f"{prefix}:yes"),
                    InlineKeyboardButton(f"✗ {no_label}", callback_data=f"{prefix}:no"),
                ]
            ]
        )

    def _options_keyboard(
        self,
        options: list[dict[str, Any]],
        handler: str | None,
        columns: int = 2,
        include_cancel: bool = True,
    ) -> InlineKeyboardMarkup:
        """
        Create a keyboard from options list.

        Args:
            options: List of {"id": str, "label": str, "description"?: str}
            handler: Callback handler prefix
            columns: Number of buttons per row
            include_cancel: Whether to include a cancel button

        Returns:
            InlineKeyboardMarkup with the options
        """
        prefix = handler or "select"
        buttons = []

        for opt in options:
            opt_id = opt.get("id", opt.get("label", ""))
            label = opt.get("label", opt_id)
            callback_data = f"{prefix}:{opt_id}"

            # Telegram callback_data has a 64-byte limit
            if len(callback_data) > 64:
                callback_data = callback_data[:64]

            buttons.append(InlineKeyboardButton(label, callback_data=callback_data))

        # Arrange into rows
        rows = []
        for i in range(0, len(buttons), columns):
            rows.append(buttons[i : i + columns])

        # Add cancel button
        if include_cancel:
            rows.append([InlineKeyboardButton("Cancel", callback_data=f"{prefix}:cancel")])

        return InlineKeyboardMarkup(rows)

    def _legacy_buttons(self, buttons: list[dict[str, str]]) -> InlineKeyboardMarkup:
        """Convert legacy button format to keyboard."""
        keyboard_buttons = [
            InlineKeyboardButton(
                btn.get("label", "Button"), callback_data=btn.get("callback_data", "unknown")
            )
            for btn in buttons
        ]

        # Put all in a single row for legacy compatibility
        return InlineKeyboardMarkup([keyboard_buttons])

    def format_html(self, text: str) -> str:
        """
        Ensure text is properly formatted for Telegram HTML.

        Escapes special characters that could break HTML parsing.
        """
        # Only escape if it doesn't already contain HTML tags
        if "<" in text and ">" in text:
            # Assume it's already HTML formatted
            return text

        import html

        return html.escape(text)


# Convenience function for quick rendering
def render_result(result: CommandResult) -> tuple[str, InlineKeyboardMarkup | None]:
    """Render a CommandResult for Telegram."""
    renderer = TelegramRenderer()
    return renderer.render(result)
