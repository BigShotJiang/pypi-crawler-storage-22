"""
`otto` - primary CLI for Otto.

Design goals:
- One entrypoint with subcommands (`otto …`).
- No reliance on a repo checkout path like ~/agent.
- Runtime state and user extensions live under OTTO_HOME (default ~/.otto).
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

import typer

from otto.paths import BRAINFILE, ENV_FILE, LOGS_DIR, build_agent_system_prompt, ensure_dirs

app = typer.Typer(
    name="otto",
    help="Otto - agent services and utility tools.",
    no_args_is_help=True,
    add_completion=False,
)


def _write_file_if_missing(path: Path, content: str) -> bool:
    if path.exists():
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    return True


def _mask_secret(value: str) -> str:
    """Mask a secret value for display, showing first 4 and last 4 chars."""
    if not value or len(value) <= 10:
        return "****"
    return value[:4] + "..." + value[-4:]


def _read_env_values() -> dict[str, str]:
    """Read current key=value pairs from the .env file."""
    env = {}
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                value = value.strip().strip('"').strip("'")
                if value:
                    env[key.strip()] = value
    return env


def _save_env_values(env: dict[str, str]) -> None:
    """Write the .env file preserving comments and updating/adding keys."""
    lines: list[str] = []
    written_keys: set[str] = set()

    # Preserve existing file structure (comments, ordering)
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text().splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith("#") and "=" in stripped:
                key = stripped.split("=", 1)[0].strip()
                if key in env:
                    lines.append(f"{key}={env[key]}")
                    written_keys.add(key)
                else:
                    lines.append(line)
            else:
                lines.append(line)

    # Append any new keys not already in the file
    for key, value in env.items():
        if key not in written_keys:
            lines.append(f"{key}={value}")

    ENV_FILE.parent.mkdir(parents=True, exist_ok=True)
    ENV_FILE.write_text("\n".join(lines) + "\n")
    ENV_FILE.chmod(0o600)


def _validate_telegram_token(token: str) -> tuple[bool, str]:
    """Validate a Telegram bot token by calling getMe. Returns (ok, message)."""
    import json
    import urllib.request
    import urllib.error

    url = f"https://api.telegram.org/bot{token}/getMe"
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            if data.get("ok"):
                bot_info = data.get("result", {})
                bot_name = bot_info.get("first_name", "")
                bot_user = bot_info.get("username", "")
                return True, f"Bot: {bot_name} (@{bot_user})"
            return False, "API returned ok=false"
    except urllib.error.HTTPError as e:
        return False, f"HTTP {e.code} - token may be invalid"
    except urllib.error.URLError as e:
        return False, f"Network error: {e.reason}"
    except Exception as e:
        return False, f"Validation error: {e}"


def _detect_binary(name: str, config_path: str | None = None) -> tuple[bool, str]:
    """Check if a CLI binary is available. Returns (found, path_or_message)."""
    # Check configured path first
    if config_path:
        p = Path(config_path).expanduser()
        if p.exists():
            return True, str(p)
    # Fall back to $PATH
    found = shutil.which(name)
    if found:
        return True, found
    return False, "not found"


def _detect_claude_sdk() -> tuple[bool, str]:
    """Check if claude-agent-sdk is installed."""
    try:
        import claude_agent_sdk  # noqa: F401
        return True, "claude-agent-sdk installed"
    except ImportError:
        return False, "claude-agent-sdk not installed"


# LiteLLM docs URL for supported providers
_LITELLM_PROVIDERS_URL = "https://docs.litellm.ai/docs/providers"


@app.command()
def init(
    force: bool = typer.Option(False, "--force", help="Overwrite existing files and skip update prompts"),
    reconfigure: bool = typer.Option(False, "--reconfigure", help="Re-run wizard on existing config"),
    token: str = typer.Option(None, "--token", help="Telegram bot token (non-interactive)"),
    backend: str = typer.Option(None, "--backend", help="Backend choice: claude, codex, api"),
):
    """Bootstrap ~/.otto with an interactive setup wizard."""
    from rich.console import Console
    from rich.panel import Panel

    console = Console()

    # ---- Phase 1: Directory and file creation (same as before) ----
    ensure_dirs()

    env_content = "# Otto secrets - this file has 0600 permissions\n# Telegram Bot Token from BotFather\nTELEGRAM_BOT_TOKEN=\n"
    if force:
        ENV_FILE.write_text(env_content)
        ENV_FILE.chmod(0o600)
    else:
        if _write_file_if_missing(ENV_FILE, env_content):
            ENV_FILE.chmod(0o600)

    brainfile_template = """---
persona:
  name: Otto
  identity: "You are Otto."
  role: personal assistant
  style: brief, natural
  values: []

context:
  user: {}
  preferences: []

rules:
  governance: ""
  output_handling: ""
  capabilities: ""

agent:
  active: claude
  backends:
    claude:
      enabled: true
      path: "~/.local/bin/claude"
      flags: ["--dangerously-skip-permissions"]
    codex:
      enabled: false
      path: "~/.nvm/versions/node/v22.22.0/bin/codex"
      flags: ["--dangerously-bypass-approvals-and-sandbox"]

orchestration:
  max_parallel: 5
  default_timeout: 3600

jobs: []
---

# Otto Brainfile

This file is Otto's configuration and long-term guidance.

## Tools

Otto can use the `otto` CLI for built-in tools and services:
- `otto mcp ...` (MCP gateway management)
- `otto memory ...` (long-term memory)
- `otto notify send ...` (Telegram notifications)
- `otto skills ...` (custom extensions under ~/.otto/skills)
"""

    if force:
        BRAINFILE.write_text(brainfile_template)
    else:
        _write_file_if_missing(BRAINFILE, brainfile_template)

    console.print()
    console.print(Panel("[bold]Welcome to Otto setup![/bold]", expand=False))
    console.print()

    # Load existing config to detect reconfiguration
    existing_env = _read_env_values()

    from otto import config as otto_config

    settings = otto_config.load_settings()
    is_reconfig = reconfigure or bool(existing_env)

    # Determine if we are fully non-interactive (CLI flags provided)
    non_interactive = token is not None and backend is not None

    # ---- Step 1/4: Telegram Bot Token ----
    console.print("[bold cyan]Step 1/4: Telegram Bot[/bold cyan]")

    current_token = existing_env.get("TELEGRAM_BOT_TOKEN", "")
    step1_skip = False

    if token is not None:
        # Non-interactive: use provided token
        tg_token = token
    elif current_token and is_reconfig and not force:
        console.print(f"  Current token: {_mask_secret(current_token)}")
        if typer.confirm("  Update Telegram token?", default=False):
            tg_token = typer.prompt("  Paste your Telegram bot token (from @BotFather)")
        else:
            tg_token = current_token
            step1_skip = True
    else:
        tg_token = typer.prompt("  Paste your Telegram bot token (from @BotFather)")

    if tg_token and not step1_skip:
        ok, msg = _validate_telegram_token(tg_token)
        if ok:
            console.print(f"  [green]Token validated - {msg}[/green]")
        else:
            console.print(f"  [yellow]Warning: {msg}[/yellow]")
            console.print("  [dim]Token saved anyway (network may be unavailable)[/dim]")

    if tg_token:
        existing_env["TELEGRAM_BOT_TOKEN"] = tg_token
        _save_env_values(existing_env)
        if not step1_skip:
            console.print("  [green]Token saved[/green]")
    else:
        console.print("  [yellow]No token provided - you can set it later in ~/.otto/config/.env[/yellow]")

    console.print()

    # ---- Step 2/4: AI Backend ----
    console.print("[bold cyan]Step 2/4: AI Backend[/bold cyan]")

    current_backend = settings.get("agent", {}).get("active", "claude")

    # Auto-detect available backends
    claude_sdk_ok, claude_sdk_msg = _detect_claude_sdk()
    claude_bin_ok, claude_bin_path = _detect_binary("claude")
    codex_path_cfg = (
        settings.get("agent", {})
        .get("backends", {})
        .get("codex", {})
        .get("path", "")
    )
    codex_ok, codex_path = _detect_binary("codex", codex_path_cfg)

    if backend is not None:
        # Non-interactive: map name to choice
        choice = {"claude": "1", "codex": "2", "api": "3", "generic": "3"}.get(
            backend.lower(), "1"
        )
    else:
        from rich.table import Table

        console.print(f"  Current backend: [bold]{current_backend}[/bold]")
        console.print()

        claude_check = "[green]\u2713[/green]" if claude_sdk_ok else "[dim]\u2717[/dim]"
        codex_check = "[green]\u2713[/green]" if codex_ok else "[dim]\u2717[/dim]"

        table = Table(show_header=True, show_edge=False, pad_edge=False, padding=(0, 2))
        table.add_column("#", style="bold", width=3)
        table.add_column("Backend")
        table.add_column("Detected", justify="center")
        table.add_column("Notes", style="dim")
        table.add_row("1", "Claude Code", claude_check, "claude-agent-sdk")
        table.add_row("2", "Codex CLI", codex_check, "OpenAI Codex")
        table.add_row("3", "API Keys", "\u2014", "any provider via LiteLLM")

        console.print(table)
        console.print()

        choice = typer.prompt("  Select backend", default="1")
        if choice not in ("1", "2", "3"):
            console.print(f"  [yellow]Invalid choice '{choice}', defaulting to Claude Code[/yellow]")
            choice = "1"

    # Configure based on choice
    if choice == "1":
        # Claude Code backend
        otto_config.set_setting("agent.active", "claude")
        otto_config.set_setting("agent.backends.claude.enabled", True)
        if claude_sdk_ok and claude_bin_ok:
            console.print(f"  [green]Backend configured: Claude Code ({claude_bin_path})[/green]")
        elif claude_sdk_ok:
            console.print("  [green]Backend configured: Claude Code[/green]")
        else:
            console.print("  [yellow]Backend set to Claude Code but SDK not found[/yellow]")
            console.print("  [dim]Install: pip install claude-agent-sdk[/dim]")

    elif choice == "2":
        # Codex CLI backend
        otto_config.set_setting("agent.active", "codex")
        otto_config.set_setting("agent.backends.codex.enabled", True)
        if codex_ok:
            otto_config.set_setting("agent.backends.codex.path", codex_path)
            console.print(f"  [green]Backend configured: Codex CLI ({codex_path})[/green]")
        else:
            console.print("  [yellow]Backend set to Codex but binary not found[/yellow]")
            console.print("  [dim]Install: npm install -g @openai/codex[/dim]")

    elif choice == "3":
        # API Keys / LiteLLM generic backend
        otto_config.set_setting("agent.active", "generic")
        otto_config.set_setting("agent.backends.generic.enabled", True)
        console.print()
        console.print("  Set your provider's API key as an environment variable:")
        console.print()
        console.print("    [bold]export OPENROUTER_API_KEY[/bold]=sk-or-...")
        console.print("    [bold]export ANTHROPIC_API_KEY[/bold]=sk-ant-...")
        console.print("    [bold]export OPENAI_API_KEY[/bold]=sk-...")
        console.print()
        console.print(f"  Supported providers: [link={_LITELLM_PROVIDERS_URL}]{_LITELLM_PROVIDERS_URL}[/link]")
        console.print()
        console.print("  [green]Backend configured: generic (LiteLLM)[/green]")
        console.print("  [dim]After setting your key, run: otto service restart all[/dim]")

    console.print()

    # ---- Step 3/4: Features ----
    console.print("[bold cyan]Step 3/4: Features[/bold cyan]")

    current_vtt = otto_config.get_setting("vtt.enabled", False)
    current_gateway = not otto_config.get_setting("gateway.kill_switch", False)

    if non_interactive:
        # Keep defaults in non-interactive mode
        vtt_enabled = current_vtt
        mcp_enabled = current_gateway
    else:
        vtt_enabled = typer.confirm("  Enable voice-to-text (Whisper)?", default=current_vtt)
        mcp_enabled = typer.confirm("  Enable MCP gateway?", default=True if not is_reconfig else current_gateway)

    otto_config.set_setting("vtt.enabled", vtt_enabled)
    otto_config.set_setting("gateway.kill_switch", not mcp_enabled)

    console.print(f"  Voice-to-text: {'enabled' if vtt_enabled else 'disabled'}")
    console.print(f"  MCP gateway:   {'enabled' if mcp_enabled else 'disabled'}")
    console.print("  [green]Features configured[/green]")
    console.print()

    # ---- Step 4/4: Verify ----
    console.print("[bold cyan]Step 4/4: Verify[/bold cyan]")
    console.print("  Running diagnostics...")

    issues: list[str] = []

    # Re-read env after saves
    final_env = _read_env_values()

    # Check Telegram token
    final_token = final_env.get("TELEGRAM_BOT_TOKEN", "")
    if final_token:
        ok, msg = _validate_telegram_token(final_token)
        if ok:
            console.print(f"  [green]Telegram token valid - {msg}[/green]")
        else:
            console.print(f"  [yellow]Telegram token issue: {msg}[/yellow]")
            issues.append(f"Telegram: {msg}")
    else:
        console.print("  [yellow]Telegram token not set[/yellow]")
        issues.append("Telegram token missing")

    # Check backend availability
    reloaded_settings = otto_config.load_settings()
    active = reloaded_settings.get("agent", {}).get("active", "claude")

    if active == "claude":
        sdk_ok, sdk_msg = _detect_claude_sdk()
        bin_ok, bin_path = _detect_binary("claude")
        if sdk_ok and bin_ok:
            console.print(f"  [green]Claude Code ready ({bin_path})[/green]")
        elif sdk_ok:
            console.print("  [green]claude-agent-sdk installed[/green]")
            console.print("  [dim]Claude CLI not in PATH (optional)[/dim]")
        else:
            console.print("  [yellow]claude-agent-sdk not installed[/yellow]")
            issues.append("Claude Code: pip install claude-agent-sdk")
    elif active == "codex":
        codex_cfg_path = (
            reloaded_settings.get("agent", {})
            .get("backends", {})
            .get("codex", {})
            .get("path", "")
        )
        ok, path = _detect_binary("codex", codex_cfg_path)
        if ok:
            console.print(f"  [green]Codex CLI ready ({path})[/green]")
        else:
            console.print("  [yellow]Codex CLI not found[/yellow]")
            issues.append("Codex CLI: npm install -g @openai/codex")
    elif active == "generic":
        # Check if any known API key env var is set
        known_keys = [
            "OPENROUTER_API_KEY", "ANTHROPIC_API_KEY", "OPENAI_API_KEY",
            "GEMINI_API_KEY", "GROQ_API_KEY", "TOGETHER_API_KEY",
        ]
        found_keys = [k for k in known_keys if final_env.get(k) or os.environ.get(k)]
        if found_keys:
            console.print(f"  [green]API keys found: {', '.join(found_keys)}[/green]")
        else:
            console.print("  [yellow]No API keys detected in env or .env file[/yellow]")
            issues.append(f"Set a provider API key (see {_LITELLM_PROVIDERS_URL})")

    # Summary
    console.print()
    if issues:
        console.print(Panel(
            "[yellow]Setup complete with warnings[/yellow]\n\n"
            + "\n".join(f"  - {i}" for i in issues)
            + "\n\n[dim]Run [bold]otto doctor[/bold] to recheck later[/dim]",
            title="Summary",
            expand=False,
        ))
    else:
        console.print(Panel(
            "[green]Configuration complete![/green]\n\n"
            f"  Brainfile:  {BRAINFILE}\n"
            f"  Config:     {ENV_FILE}\n"
            f"  Logs:       {LOGS_DIR}\n\n"
            "  Run: [bold]otto service start all[/bold]",
            title="Summary",
            expand=False,
        ))
    console.print()


@app.command()
def doctor():
    """Check system prerequisites and configuration."""
    ensure_dirs()

    issues: list[str] = []

    token = os.environ.get("TELEGRAM_BOT_TOKEN") or os.environ.get("OTTO_TELEGRAM_BOT_TOKEN")
    if not token and ENV_FILE.exists():
        for line in ENV_FILE.read_text().splitlines():
            if line.strip().startswith(
                ("TELEGRAM_BOT_TOKEN=", "OTTO_TELEGRAM_BOT_TOKEN=")
            ) and line.strip() not in {
                "TELEGRAM_BOT_TOKEN=",
                "OTTO_TELEGRAM_BOT_TOKEN=",
            }:
                token = line.split("=", 1)[1].strip().strip('"').strip("'")
                break

    if not token:
        issues.append(
            f"Missing TELEGRAM_BOT_TOKEN/OTTO_TELEGRAM_BOT_TOKEN (set env var or edit {ENV_FILE})"
        )

    if not BRAINFILE.exists():
        issues.append(f"Missing brainfile: {BRAINFILE} (run: otto init)")

    # Check native gateway configuration
    from otto.gateway import load_gateway_policy

    try:
        policy = load_gateway_policy()
        if not policy.servers:
            issues.append(
                "No MCP servers configured in gateway (see settings.yaml gateway.servers)"
            )
    except Exception as e:
        issues.append(f"Gateway policy load error: {e}")

    if issues:
        typer.echo("Issues found:")
        for i in issues:
            typer.echo(f"- {i}")
        raise typer.Exit(1)

    typer.echo("OK")


@app.command("mcp-server")
def mcp_server():
    """Run the Otto memory MCP server on stdio."""
    from otto.mcp_server import run

    run()


# ---- Subcommands (mounted from other modules) ----

# ---- Chat (unified chat platforms) ----

chat_app = typer.Typer(no_args_is_help=True, help="Chat platform management.")
chat_telegram_app = typer.Typer(no_args_is_help=True, help="Telegram chat platform.")
chat_signal_app = typer.Typer(no_args_is_help=True, help="Signal chat platform.")


@chat_app.command("list")
def chat_list():
    """List available chat platforms and their status."""
    from otto.daemon import ServiceStatus, format_uptime, status

    platforms = [
        ("telegram", "telegram-bot"),
        ("signal", "signal-bot"),
    ]

    typer.echo("Available chat platforms:\n")
    for name, service in platforms:
        info = status(service)
        if info.status == ServiceStatus.RUNNING:
            uptime = format_uptime(info.uptime_seconds)
            typer.echo(f"  {name:<12} running (PID {info.pid}, uptime {uptime})")
        elif info.status == ServiceStatus.DEAD:
            typer.echo(f"  {name:<12} dead (stale PID {info.pid})")
        else:
            typer.echo(f"  {name:<12} stopped")


# Telegram commands under chat
_TELEGRAM_SERVICE = "telegram-bot"


def _telegram_command() -> list[str]:
    """Get telegram bot command with correct Python path."""
    return [sys.executable, "-m", "otto.services.telegram"]


@chat_telegram_app.command("start")
def chat_telegram_start(
    foreground: bool = typer.Option(
        False, "--foreground", "-f", help="Run in foreground (don't daemonize)"
    ),
):
    """Start the Telegram bot."""
    from otto.daemon import ServiceStatus, status

    # Check for already running instance (both foreground and background modes)
    info = status(_TELEGRAM_SERVICE)
    if info.status == ServiceStatus.RUNNING:
        typer.echo(f"Telegram bot is already running (PID {info.pid})")
        raise typer.Exit(1)

    if foreground:
        from otto.services.telegram import main as bot_main

        # The service handles its own PID file management
        bot_main()
    else:
        from otto.daemon import start

        ok, msg = start(_TELEGRAM_SERVICE, _telegram_command())
        typer.echo(msg)
        raise typer.Exit(0 if ok else 1)


@chat_telegram_app.command("stop")
def chat_telegram_stop():
    """Stop the Telegram bot."""
    from otto.daemon import stop

    ok, msg = stop(_TELEGRAM_SERVICE)
    typer.echo(msg)
    raise typer.Exit(0 if ok else 1)


@chat_telegram_app.command("restart")
def chat_telegram_restart(
    graceful: bool = typer.Option(
        True, "--graceful/--force", help="Use graceful restart with health checks"
    ),
):
    """Restart the Telegram bot."""
    from otto.daemon import graceful_restart, restart

    if graceful:
        ok, msg = graceful_restart(_TELEGRAM_SERVICE, _telegram_command(), ready_timeout=30.0)
    else:
        ok, msg = restart(_TELEGRAM_SERVICE, _telegram_command())
    typer.echo(msg)
    raise typer.Exit(0 if ok else 1)


@chat_telegram_app.command("reload")
def chat_telegram_reload():
    """Reload Telegram bot configuration (send SIGHUP)."""
    from otto.daemon import reload_config

    ok, msg = reload_config(_TELEGRAM_SERVICE)
    typer.echo(msg)
    raise typer.Exit(0 if ok else 1)


@chat_telegram_app.command("status")
def chat_telegram_status():
    """Show Telegram bot status."""
    from otto.daemon import ServiceStatus, format_uptime, is_ready, status

    info = status(_TELEGRAM_SERVICE)

    if info.status == ServiceStatus.RUNNING:
        uptime = format_uptime(info.uptime_seconds)
        ready = is_ready(_TELEGRAM_SERVICE)
        ready_str = "ready" if ready else "starting"
        typer.echo(f"Telegram bot is running (PID {info.pid}, uptime {uptime}, {ready_str})")
    elif info.status == ServiceStatus.DEAD:
        typer.echo(f"Telegram bot is dead (stale PID {info.pid})")
        raise typer.Exit(1)
    else:
        typer.echo("Telegram bot is stopped")
        raise typer.Exit(1)


@chat_telegram_app.command("logs")
def chat_telegram_logs(
    follow: bool = typer.Option(False, "--follow", "-f", help="Follow log output"),
    lines: int = typer.Option(50, "--lines", "-n", help="Number of lines to show"),
):
    """Show Telegram bot logs."""
    from otto.paths import LOGS_DIR

    log_file = LOGS_DIR / f"{_TELEGRAM_SERVICE}.log"
    if not log_file.exists():
        typer.echo("No log file found")
        raise typer.Exit(1)

    if follow:
        subprocess.run(["tail", "-f", "-n", str(lines), str(log_file)])
    else:
        subprocess.run(["tail", "-n", str(lines), str(log_file)])


# Mount telegram under chat
chat_app.add_typer(chat_telegram_app, name="telegram")
chat_app.add_typer(chat_signal_app, name="signal")


# ---- Service management (unified) ----

service_app = typer.Typer(no_args_is_help=True, help="Unified service management.")

# Service registry: name -> (service_id, command_func)
_SERVICES = {
    "telegram": ("telegram-bot", lambda: [sys.executable, "-m", "otto.services.telegram"]),
    "worker": ("job-worker", lambda: [sys.executable, "-m", "otto.services.worker", "--daemon"]),
}


@service_app.command("list")
def service_list():
    """List all available services and their status."""
    from otto.daemon import ServiceStatus, format_uptime, status

    typer.echo("Available services:\n")
    for name, (service_id, _) in _SERVICES.items():
        info = status(service_id)
        if info.status == ServiceStatus.RUNNING:
            uptime = format_uptime(info.uptime_seconds)
            typer.echo(f"  {name:<12} running (PID {info.pid}, uptime {uptime})")
        elif info.status == ServiceStatus.DEAD:
            typer.echo(f"  {name:<12} dead (stale PID {info.pid})")
        else:
            typer.echo(f"  {name:<12} stopped")


@service_app.command("status")
def service_status(
    name: str = typer.Argument(None, help="Service name (telegram, worker) or 'all'"),
):
    """Show status of a service or all services."""
    from otto.daemon import ServiceStatus, format_uptime, is_ready, status

    if name is None or name == "all":
        service_list()
        return

    if name not in _SERVICES:
        typer.echo(f"Unknown service: {name}")
        typer.echo(f"Available: {', '.join(_SERVICES.keys())}")
        raise typer.Exit(1)

    service_id, _ = _SERVICES[name]
    info = status(service_id)

    if info.status == ServiceStatus.RUNNING:
        uptime = format_uptime(info.uptime_seconds)
        ready = is_ready(service_id)
        ready_str = "ready" if ready else "starting"
        typer.echo(f"{name} is running (PID {info.pid}, uptime {uptime}, {ready_str})")
    elif info.status == ServiceStatus.DEAD:
        typer.echo(f"{name} is dead (stale PID {info.pid})")
        raise typer.Exit(1)
    else:
        typer.echo(f"{name} is stopped")
        raise typer.Exit(1)


@service_app.command("start")
def service_start(
    name: str = typer.Argument(..., help="Service name (telegram, worker) or 'all'"),
):
    """Start a service or all services."""

    if name == "all":
        for svc_name in _SERVICES:
            _start_service(svc_name)
        return

    if name not in _SERVICES:
        typer.echo(f"Unknown service: {name}")
        typer.echo(f"Available: {', '.join(_SERVICES.keys())}, all")
        raise typer.Exit(1)

    _start_service(name)


def _start_service(name: str) -> None:
    from otto.daemon import ServiceStatus, start, status

    service_id, cmd_func = _SERVICES[name]
    info = status(service_id)
    if info.status == ServiceStatus.RUNNING:
        typer.echo(f"{name}: already running (PID {info.pid})")
        return

    ok, msg = start(service_id, cmd_func())
    typer.echo(f"{name}: {msg}")


@service_app.command("stop")
def service_stop(
    name: str = typer.Argument(..., help="Service name (telegram, worker) or 'all'"),
):
    """Stop a service or all services."""
    from otto.daemon import stop

    if name == "all":
        for svc_name in _SERVICES:
            service_id, _ = _SERVICES[svc_name]
            ok, msg = stop(service_id)
            typer.echo(f"{svc_name}: {msg}")
        return

    if name not in _SERVICES:
        typer.echo(f"Unknown service: {name}")
        typer.echo(f"Available: {', '.join(_SERVICES.keys())}, all")
        raise typer.Exit(1)

    service_id, _ = _SERVICES[name]
    ok, msg = stop(service_id)
    typer.echo(f"{name}: {msg}")


@service_app.command("restart")
def service_restart(
    name: str = typer.Argument(..., help="Service name (telegram, worker) or 'all'"),
    graceful: bool = typer.Option(True, "--graceful/--force", help="Use graceful restart"),
):
    """Restart a service or all services."""

    if name == "all":
        for svc_name in _SERVICES:
            _restart_service(svc_name, graceful)
        return

    if name not in _SERVICES:
        typer.echo(f"Unknown service: {name}")
        typer.echo(f"Available: {', '.join(_SERVICES.keys())}, all")
        raise typer.Exit(1)

    _restart_service(name, graceful)


def _restart_service(name: str, graceful: bool) -> None:
    from otto.daemon import graceful_restart, restart

    service_id, cmd_func = _SERVICES[name]
    if graceful:
        ok, msg = graceful_restart(service_id, cmd_func(), ready_timeout=30.0)
    else:
        ok, msg = restart(service_id, cmd_func())
    typer.echo(f"{name}: {msg}")


@service_app.command("logs")
def service_logs(
    name: str = typer.Argument(..., help="Service name (telegram, worker)"),
    follow: bool = typer.Option(False, "--follow", "-f", help="Follow log output"),
    lines: int = typer.Option(50, "--lines", "-n", help="Number of lines to show"),
):
    """Show logs for a service."""
    from otto.paths import LOGS_DIR

    if name not in _SERVICES:
        typer.echo(f"Unknown service: {name}")
        typer.echo(f"Available: {', '.join(_SERVICES.keys())}")
        raise typer.Exit(1)

    service_id, _ = _SERVICES[name]
    log_file = LOGS_DIR / f"{service_id}.log"

    if not log_file.exists():
        typer.echo(f"No log file found for {name}")
        raise typer.Exit(1)

    if follow:
        subprocess.run(["tail", "-f", "-n", str(lines), str(log_file)])
    else:
        subprocess.run(["tail", "-n", str(lines), str(log_file)])


# ---- Job management (unified worker + schedule) ----

job_app = typer.Typer(no_args_is_help=True, help="Job queue management.")
job_schedule_app = typer.Typer(no_args_is_help=True, help="Scheduled job operations.")


@job_app.command("list")
def job_list(
    status_filter: str = typer.Option(None, "--status", "-s", help="Filter by status"),
    limit: int = typer.Option(20, "--limit", "-n", help="Number of jobs to show"),
):
    """List jobs in the queue."""
    from otto.jobs.queue import JobQueue

    q = JobQueue()
    jobs = q.list(status=status_filter, limit=limit)

    if not jobs:
        typer.echo("No jobs found.")
        return

    typer.echo(f"{'ID':<6} {'Type':<10} {'Status':<12} {'External ID':<12} {'Created'}")
    typer.echo("-" * 70)
    for job in jobs:
        job_id = job.get("id", "?")
        job_type = job.get("type", "?")[:10]
        status = job.get("status", "?")[:12]
        ext_id = (job.get("external_id") or "-")[:12]
        created = (job.get("created_at") or "?")[:19]
        typer.echo(f"{job_id:<6} {job_type:<10} {status:<12} {ext_id:<12} {created}")


@job_app.command("stats")
def job_stats():
    """Show job queue statistics."""
    from otto.jobs.queue import JobQueue

    q = JobQueue()
    stats = q.stats()

    typer.echo("Job Queue Statistics:\n")
    typer.echo(f"  Pending:    {stats.get('pending', 0)}")
    typer.echo(f"  Running:    {stats.get('running', 0)}")
    typer.echo(f"  Completed:  {stats.get('completed', 0)}")
    typer.echo(f"  Failed:     {stats.get('failed', 0)}")
    typer.echo(f"  Cancelled:  {stats.get('cancelled', 0)}")
    typer.echo(f"  Ready now:  {stats.get('ready_now', 0)}")


@job_app.command("process")
def job_process():
    """Process one job from the queue and exit."""
    from otto.services.worker import Worker

    worker = Worker()
    if worker.process_one():
        typer.echo("Processed one job.")
    else:
        typer.echo("No jobs to process.")


@job_app.command("cleanup")
def job_cleanup(
    days: int = typer.Option(7, "--days", "-d", help="Remove jobs older than N days"),
):
    """Remove old completed/cancelled jobs."""
    from otto.jobs.queue import JobQueue

    q = JobQueue()
    count = q.cleanup(days=days)
    typer.echo(f"Removed {count} old job(s).")


# Schedule subcommands under job
@job_schedule_app.command("tick")
def job_schedule_tick():
    """Evaluate schedules and enqueue due jobs."""
    from otto.schedule import tick

    result = tick()
    enqueued = result.get("enqueued", [])
    if enqueued:
        names = [e.get("job_id", "?") for e in enqueued]
        typer.echo(f"Enqueued {len(enqueued)} job(s): {', '.join(names)}")
    else:
        typer.echo("No jobs due.")


@job_schedule_app.command("install")
def job_schedule_install(
    method: str = typer.Argument("systemd", help="Installation method: systemd or cron"),
):
    """Install scheduler (systemd timer or cron)."""
    otto_bin = shutil.which("otto") or "otto"

    if method == "systemd":
        service_content = f"""[Unit]
Description=Otto Schedule Tick
After=network.target

[Service]
Type=oneshot
ExecStart={otto_bin} job schedule tick
"""
        timer_content = """[Unit]
Description=Otto Schedule Timer (every minute)

[Timer]
OnCalendar=*:*:00
Persistent=true

[Install]
WantedBy=timers.target
"""
        service_dir = Path.home() / ".config" / "systemd" / "user"
        service_dir.mkdir(parents=True, exist_ok=True)

        (service_dir / "otto-schedule.service").write_text(service_content)
        (service_dir / "otto-schedule.timer").write_text(timer_content)

        typer.echo("Installed systemd user timer.")
        typer.echo("Enable with: systemctl --user enable --now otto-schedule.timer")

    elif method == "cron":
        cron_line = f"* * * * * {otto_bin} job schedule tick >> ~/.otto/logs/schedule.log 2>&1"
        typer.echo("Add this line to your crontab (crontab -e):\n")
        typer.echo(cron_line)

    else:
        typer.echo(f"Unknown method: {method}. Use 'systemd' or 'cron'.")
        raise typer.Exit(1)


# Mount schedule under job
job_app.add_typer(job_schedule_app, name="schedule")


# Worker service ID constant (used by agent_spawn for status check)
_WORKER_SERVICE = "job-worker"


# (Deprecated top-level 'otto schedule' app removed; use 'otto job schedule')

mcp_app = typer.Typer(no_args_is_help=True, help="Native MCP gateway management.")


@mcp_app.command("list")
def mcp_list(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    """List configured MCP servers from the native gateway."""
    import json as json_mod

    from otto.gateway import get_gateway

    gateway = get_gateway()
    servers = gateway.list_servers()

    if json_output:
        output = {}
        for name, policy in servers.items():
            output[name] = {
                "enabled": policy.enabled,
                "builtin": policy.builtin,
                "transport": policy.transport.get("type", "none") if policy.transport else "none",
                "allowed_tools": policy.allowed_tools,
                "blocked_tools": policy.blocked_tools,
            }
        print(json_mod.dumps(output, indent=2))
    else:
        if not servers:
            typer.echo("No MCP servers configured.")
            typer.echo("Add servers in settings.yaml under gateway.servers")
            return

        typer.echo("MCP Servers (native gateway):\n")
        for name, policy in servers.items():
            status_str = "enabled" if policy.enabled else "disabled"
            type_str = "builtin" if policy.builtin else policy.transport.get("type", "?")
            typer.echo(f"  {name:<20} {status_str:<10} [{type_str}]")
            if policy.allowed_tools:
                typer.echo(f"    allowed: {', '.join(policy.allowed_tools)}")
            if policy.blocked_tools:
                typer.echo(f"    blocked: {', '.join(policy.blocked_tools)}")


@mcp_app.command("status")
def mcp_status():
    """Show native gateway status."""
    from otto.gateway import get_gateway

    gateway = get_gateway()
    servers = gateway.list_servers()
    enabled = sum(1 for p in servers.values() if p.enabled)
    builtin = sum(1 for p in servers.values() if p.builtin)
    external = sum(1 for p in servers.values() if p.enabled and not p.builtin)

    typer.echo("Native MCP Gateway Status\n")
    typer.echo(f"  Total servers:    {len(servers)}")
    typer.echo(f"  Enabled:          {enabled}")
    typer.echo(f"  Built-in:         {builtin}")
    typer.echo(f"  External:         {external}")
    typer.echo(f"  Audit logging:    {'on' if gateway.policy.audit_enabled else 'off'}")

    if gateway.policy.permissions:
        typer.echo("\n  Permission policy:")
        for op, verdict in gateway.policy.permissions.items():
            typer.echo(f"    {op}: {verdict.value}")


@mcp_app.command("configs")
def mcp_configs():
    """Show MCP server transport configs (as passed to backends)."""
    import json as json_mod

    from otto.gateway import get_gateway

    configs = get_gateway().get_mcp_server_configs()
    if not configs:
        typer.echo("No external MCP server configs to export.")
        return

    print(json_mod.dumps(configs, indent=2))


@mcp_app.command("catalog")
def mcp_catalog(
    category: str = typer.Argument(
        None, help="Filter by category (filesystem, search, dev, data, productivity)"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    """Browse the curated MCP server catalog."""
    import json as json_mod

    from otto.catalog import list_catalog, list_categories

    entries = list_catalog(category=category)

    if json_output:
        output = [
            {
                "name": e.name,
                "description": e.description,
                "category": e.category,
                "risk_level": e.risk_level,
                "requires_env": e.requires_env,
                "transport": e.transport.get("type", "?"),
            }
            for e in entries
        ]
        print(json_mod.dumps(output, indent=2))
        return

    if not entries:
        typer.echo("No catalog entries found." + (f" (category: {category})" if category else ""))
        return

    # Check installed
    try:
        from otto.gateway import get_gateway

        installed = set(get_gateway().list_servers().keys())
    except Exception:
        installed = set()

    categories = list_categories()

    if not category:
        typer.echo(f"MCP Server Catalog ({len(entries)} servers)\n")
        typer.echo(f"Categories: {', '.join(categories)}\n")

        by_cat: dict[str, list] = {}
        for e in entries:
            by_cat.setdefault(e.category, []).append(e)

        for cat_name in sorted(by_cat.keys()):
            cat_entries = by_cat[cat_name]
            icon = cat_entries[0].category_icon
            typer.echo(f"\n  {icon} {cat_name}")
            for e in cat_entries:
                status = "✓" if e.name in installed else " "
                typer.echo(f"    [{status}] {e.name:<22} {e.risk_icon} {e.description[:50]}")
    else:
        typer.echo(f"MCP Catalog — {category} ({len(entries)} servers)\n")
        for e in entries:
            status = "✓" if e.name in installed else " "
            typer.echo(f"  [{status}] {e.name:<22} {e.risk_icon} {e.description}")
            if e.requires_env:
                missing = e.check_env()
                if missing:
                    typer.echo(f"       ⚠️  Missing: {', '.join(missing)}")

    typer.echo("\n  ✓ = installed")
    typer.echo("\nInstall: otto mcp add <name>")


@mcp_app.command("add")
def mcp_add(
    name: str = typer.Argument(..., help="Catalog server name to install"),
    enable: bool = typer.Option(True, "--enable/--no-enable", help="Enable the server"),
):
    """Install a server from the curated catalog into settings.yaml."""
    from otto.catalog import get_catalog_entry, install_server
    from otto.gateway import reload_gateway

    entry = get_catalog_entry(name)
    if entry is None:
        typer.echo(f"'{name}' not found in catalog.", err=True)
        typer.echo("\nBrowse available servers: otto mcp catalog")
        raise typer.Exit(1)

    # Show what will be installed
    typer.echo(f"Installing: {entry.name}")
    typer.echo(f"  {entry.description}")
    typer.echo(f"  Risk: {entry.risk_icon} {entry.risk_level}")
    typer.echo(f"  Transport: {entry.transport.get('type', '?')}")

    if entry.requires_env:
        missing = entry.check_env()
        if missing:
            typer.echo(f"\n  ⚠️  Missing env vars: {', '.join(missing)}")
            typer.echo("  Set them in ~/.otto/config/.env before using this server.")

    ok, msg = install_server(name, enabled=enable)
    if ok:
        reload_gateway()
        typer.echo(f"\n✓ {msg}")
    else:
        typer.echo(f"\n✗ {msg}", err=True)
        raise typer.Exit(1)


@mcp_app.command("remove")
def mcp_remove(
    name: str = typer.Argument(..., help="Server name to remove"),
):
    """Remove a server from settings.yaml."""
    from otto.catalog import remove_server
    from otto.gateway import reload_gateway

    ok, msg = remove_server(name)
    if ok:
        reload_gateway()
    typer.echo(f"{'✓' if ok else '✗'} {msg}")
    if not ok:
        raise typer.Exit(1)


@mcp_app.command("test")
def mcp_test(
    name: str = typer.Argument(None, help="Server name to test (default: all enabled)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    """Test MCP server connections (handshake + tools/list)."""
    import asyncio
    import json as json_mod

    from otto.catalog import _test_server_async, test_all_servers
    from otto.gateway import get_gateway

    if name:
        result = asyncio.run(_test_server_async(name))
        results = [result]
    else:
        gateway = get_gateway()
        servers = gateway.list_servers()
        external = [n for n, p in servers.items() if p.enabled and not p.builtin]

        if not external:
            typer.echo("No external MCP servers configured.")
            typer.echo("Install one: otto mcp add <name>")
            return

        typer.echo(f"Testing {len(external)} server(s)...\n")
        results = asyncio.run(test_all_servers())

    if json_output:
        output = [
            {
                "server": r.server,
                "success": r.success,
                "tools": r.tools,
                "error": r.error,
                "latency_ms": r.latency_ms,
            }
            for r in results
        ]
        print(json_mod.dumps(output, indent=2))
        return

    for r in results:
        if r.success:
            typer.echo(
                f"  {r.status_icon} {r.server:<20} {len(r.tools)} tools ({r.latency_ms:.0f}ms)"
            )
        else:
            typer.echo(f"  {r.status_icon} {r.server:<20} {r.error}")

    passed = sum(1 for r in results if r.success)
    failed = len(results) - passed
    typer.echo(f"\n{passed} passed, {failed} failed")

    if failed:
        raise typer.Exit(1)


config_app = typer.Typer(no_args_is_help=True, help="Configuration management.")


@config_app.command("show")
def config_show(
    path: str = typer.Argument(None, help="Dot-separated config path (e.g., vtt.enabled)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    """Show configuration values."""
    import json as json_mod

    from otto import config as otto_config

    if path:
        value = otto_config.get_setting(path)
        if json_output:
            print(json_mod.dumps({"path": path, "value": value}, indent=2))
        else:
            typer.echo(f"{path} = {value}")
    else:
        settings = otto_config.load_settings()
        if json_output:
            print(json_mod.dumps(settings, indent=2))
        else:
            import yaml

            typer.echo(yaml.dump(settings, default_flow_style=False))


@config_app.command("set")
def config_set(
    path: str = typer.Argument(..., help="Dot-separated config path"),
    value: str = typer.Argument(..., help="Value to set (JSON for complex types)"),
):
    """Set a configuration value."""
    import json as json_mod

    from otto import config as otto_config

    # Try to parse as JSON, fall back to string
    try:
        parsed = json_mod.loads(value)
    except json_mod.JSONDecodeError:
        # Handle booleans and numbers
        if value.lower() == "true":
            parsed = True
        elif value.lower() == "false":
            parsed = False
        elif value.isdigit():
            parsed = int(value)
        else:
            parsed = value

    otto_config.set_setting(path, parsed)
    typer.echo(f"Set {path} = {parsed}")


@config_app.command("users")
def config_users(
    action: str = typer.Argument(None, help="Action: add, remove, list"),
    user_id: int = typer.Argument(None, help="Telegram user ID"),
    name: str = typer.Option("", "--name", "-n", help="User name/handle"),
):
    """Manage authorized users."""
    from otto import config as otto_config

    if not action or action == "list":
        settings = otto_config.load_settings()
        access = settings.get("access", {})
        owner = access.get("owner_id")
        users = access.get("allowed_users", [])

        typer.echo("Authorized Users:")
        typer.echo(f"  Owner: {owner}")
        for user in users:
            if isinstance(user, dict):
                uid = user.get("id")
                uname = user.get("name", "")
                added = user.get("added", "")[:10]
                owner_mark = " (owner)" if uid == owner else ""
                typer.echo(f"  {uid} {uname}{owner_mark} - added {added}")
            else:
                typer.echo(f"  {user}")
        return

    if action == "add":
        if not user_id:
            typer.echo("Error: user_id required", err=True)
            raise typer.Exit(1)
        if otto_config.add_user(user_id, name):
            typer.echo(f"Added user {user_id} ({name})")
        else:
            typer.echo(f"User {user_id} already exists")

    elif action == "remove":
        if not user_id:
            typer.echo("Error: user_id required", err=True)
            raise typer.Exit(1)
        if otto_config.remove_user(user_id):
            typer.echo(f"Removed user {user_id}")
        else:
            typer.echo(f"User {user_id} not found")

    elif action == "owner":
        if not user_id:
            typer.echo("Error: user_id required", err=True)
            raise typer.Exit(1)
        otto_config.set_owner(user_id, name)
        typer.echo(f"Set owner to {user_id} ({name})")

    else:
        typer.echo(f"Unknown action: {action}", err=True)
        raise typer.Exit(1)


@config_app.command("migrate")
def config_migrate():
    """Migrate existing config files to new unified format."""
    from otto import config as otto_config

    results = otto_config.migrate_existing_configs()
    typer.echo("Migration results:")
    if results["migrated"]:
        typer.echo("  Migrated:")
        for item in results["migrated"]:
            typer.echo(f"    - {item}")
    if results["skipped"]:
        typer.echo("  Skipped:")
        for item in results["skipped"]:
            typer.echo(f"    - {item}")
    if results["errors"]:
        typer.echo("  Errors:")
        for item in results["errors"]:
            typer.echo(f"    - {item}")


@config_app.command("path")
def config_path():
    """Show config file paths."""
    from otto import config as otto_config

    typer.echo(f"Settings: {otto_config.SETTINGS_FILE}")
    typer.echo(f"State:    {otto_config.STATE_FILE}")
    typer.echo(f"Secrets:  {otto_config.ENV_FILE}")


# ---- Backend management (canonical path: 'otto config backend') ----
# Deprecated top-level 'otto backend' alias removed.
backend_app = typer.Typer(no_args_is_help=True, help="Manage agent backends.")


@backend_app.command("list")
def backend_list(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    """List available backends."""
    import json as json_mod

    from otto.backends import get_active_backend_name, get_backend, list_backends

    active = get_active_backend_name()
    backends = list_backends()

    if json_output:
        output = {"active": active, "backends": {}}
        for name, info in backends.items():
            try:
                backend = get_backend(name)
                available = backend.is_available()
            except Exception:
                available = False
            output["backends"][name] = {
                **info,
                "available": available,
                "active": name == active,
            }
        print(json_mod.dumps(output, indent=2))
    else:
        typer.echo(f"Active backend: {active}\n")
        typer.echo("Available backends:")
        for name, info in backends.items():
            try:
                backend = get_backend(name)
                available = backend.is_available()
            except Exception:
                available = False

            status = "available" if available else "unavailable"
            enabled = "enabled" if info.get("enabled") else "disabled"
            marker = " (active)" if name == active else ""
            typer.echo(f"  {name}: {status}, {enabled}{marker}")


@backend_app.command("show")
def backend_show(
    name: str = typer.Argument(None, help="Backend name (default: active)"),
):
    """Show backend configuration."""
    from otto.backends import get_active_backend_name, get_backend, list_backends

    if not name:
        name = get_active_backend_name()

    backends = list_backends()
    if name not in backends:
        typer.echo(f"Unknown backend: {name}", err=True)
        raise typer.Exit(1)

    info = backends[name]
    typer.echo(f"Backend: {name}")
    typer.echo(f"  Path: {info.get('path')}")
    typer.echo(f"  Model: {info.get('model') or 'default'}")
    typer.echo(f"  Enabled: {info.get('enabled', False)}")
    typer.echo(f"  Flags: {' '.join(info.get('flags', []))}")

    try:
        backend = get_backend(name)
        typer.echo(f"  Available: {backend.is_available()}")
    except Exception as e:
        typer.echo(f"  Available: False ({e})")


@backend_app.command("set")
def backend_set(
    name: str = typer.Argument(..., help="Backend name to switch to"),
):
    """Set the active backend."""
    from otto.backends import get_backend, list_backends, set_active_backend

    backends = list_backends()
    if name not in backends:
        typer.echo(f"Unknown backend: {name}", err=True)
        typer.echo(f"Available: {', '.join(backends.keys())}")
        raise typer.Exit(1)

    try:
        backend = get_backend(name)
        if not backend.is_available():
            typer.echo(
                f"Warning: Backend {name} is not available (binary missing or disabled)", err=True
            )
    except Exception as e:
        typer.echo(f"Warning: Could not verify backend: {e}", err=True)

    try:
        set_active_backend(name)
        typer.echo(f"Switched to {name}")
    except Exception as e:
        typer.echo(f"Failed to switch backend: {e}", err=True)
        raise typer.Exit(1)


skills_app = typer.Typer(no_args_is_help=True, help="Manage ~/.otto/skills.")

# ---- Agent orchestration ----

agent_app = typer.Typer(no_args_is_help=True, help="Sub-agent orchestration.")


@agent_app.command("spawn")
def agent_spawn(
    prompt: str = typer.Option(..., "-p", "--prompt", help="Task prompt for the agent"),
    task: str = typer.Option(..., "-t", "--task", help="Short task description"),
    backend: str = typer.Option("claude", "-b", "--backend", help="Backend: claude, codex"),
    model: str = typer.Option(
        None, "-m", "--model", help="Model spec (e.g., openrouter/provider/model)"
    ),
    notify: bool = typer.Option(False, "--notify", help="Send Telegram notification when done"),
    timeout: int = typer.Option(
        None, "--timeout", help="Timeout in seconds (default: from config, 1h)"
    ),
    priority: str = typer.Option(
        "normal", "--priority", "-P", help="Priority: high, normal, low (high=immediate notify)"
    ),
    after_success: str | None = typer.Option(
        None, "--after-success", help="Run only if specified agent succeeds"
    ),
    after_failure: str | None = typer.Option(
        None, "--after-failure", help="Run only if specified agent fails"
    ),
    force: bool = typer.Option(
        False, "--force", "-f", help="Bypass duplicate detection and force spawn"
    ),
):
    """Spawn a background sub-agent."""
    import hashlib
    import uuid

    from otto.backends import get_orchestration_config
    from otto.daemon import ServiceStatus, status
    from otto.jobs.queue import JobQueue
    from otto.paths import OUTPUTS_DIR

    queue = JobQueue()

    if after_success and after_failure:
        typer.echo("Cannot use both --after-success and --after-failure", err=True)
        raise typer.Exit(1)

    depends_on_id: str | None = None
    depends_on_status: str | None = None
    if after_success is not None:
        depends_on_id = str(after_success).strip()
        if not depends_on_id:
            typer.echo("--after-success requires a non-empty agent id", err=True)
            raise typer.Exit(1)
        depends_on_status = "success"
    elif after_failure is not None:
        depends_on_id = str(after_failure).strip()
        if not depends_on_id:
            typer.echo("--after-failure requires a non-empty agent id", err=True)
            raise typer.Exit(1)
        depends_on_status = "failure"

    if depends_on_id:
        dependency = queue.get_by_external_id(depends_on_id, job_type="agent")
        if not dependency:
            typer.echo(f"Agent {depends_on_id} not found", err=True)
            raise typer.Exit(1)

    # Duplicate detection: check for similar pending/running agents
    if not force:
        # Create a fingerprint from task description (normalized)
        task_fingerprint = hashlib.sha256(task.strip().lower().encode()).hexdigest()[:16]

        # Check for existing pending/running agents with same task
        existing = queue.find_duplicate_agent(task_fingerprint)
        if existing:
            existing_id = existing.get("external_id") or existing.get("payload", {}).get(
                "agent_id", "?"
            )
            existing_status = existing.get("status", "unknown")
            typer.echo(
                f"⚠️  Duplicate detected: agent {existing_id} ({existing_status}) has the same task.\n"
                f"   Use --force to spawn anyway, or wait for the existing agent to complete.",
                err=True,
            )
            raise typer.Exit(1)

    # Get timeout from config if not specified
    if timeout is None:
        orch_config = get_orchestration_config()
        timeout = orch_config.get("default_timeout", 3600)

    agent_id = uuid.uuid4().hex[:8]
    output_file = OUTPUTS_DIR / f"{agent_id}.txt"

    # Create task fingerprint for future duplicate detection
    task_fingerprint = hashlib.sha256(task.strip().lower().encode()).hexdigest()[:16]

    # Build clean, model-agnostic system prompt
    system_prompt = build_agent_system_prompt()

    # Validate priority
    priority = priority.lower()
    if priority not in ("high", "normal", "low"):
        typer.echo(f"Invalid priority: {priority}. Use high, normal, or low.", err=True)
        raise typer.Exit(1)

    queue_priority = {"high": 10, "normal": 0, "low": -10}[priority]
    payload = {
        "agent_id": agent_id,
        "prompt": prompt,
        "system": system_prompt,
        "task": task,
        "backend": backend,
        "model": model,  # For dynamic routing (e.g., "openrouter/provider/model")
        "timeout": timeout,
        "notify": notify,
        "priority": priority,
        "output_file": str(output_file),
        "task_fingerprint": task_fingerprint,
    }
    retry_cfg = get_orchestration_config().get("retry", {}) or {}
    max_retries = int(retry_cfg.get("max_retries", 3))
    if max_retries < 0:
        max_retries = 0
    max_attempts = 1 + max_retries
    job_id = queue.add(
        "agent",
        payload,
        priority=queue_priority,
        max_attempts=max_attempts,
        external_id=agent_id,
        depends_on_id=depends_on_id,
        depends_on_status=depends_on_status,
    )

    if depends_on_id:
        dep_latest = queue.get_by_external_id(depends_on_id, job_type="agent")
        dep_status = dep_latest.get("status") if dep_latest else None
        if dep_status in ("completed", "failed", "cancelled"):
            queue.activate_dependents(depends_on_id, dep_status)

    info = status(_WORKER_SERVICE)
    if info.status != ServiceStatus.RUNNING:
        typer.echo(
            "Warning: worker is not running. Start it with: otto service start worker", err=True
        )

    typer.echo(f"Queued agent: {agent_id} (job {job_id})")
    if depends_on_id and depends_on_status:
        relation = "succeeds" if depends_on_status == "success" else "fails"
        job = queue.get(job_id)
        job_status = job.get("status") if job else "unknown"
        if job_status == "waiting":
            typer.echo(f"  → Will run after {depends_on_id} {relation}")
        elif job_status == "pending":
            typer.echo(f"  → Ready (dependency {depends_on_id} {relation})")
        elif job_status == "cancelled":
            typer.echo(f"  → Cancelled (dependency {depends_on_id} {relation} not met)")
        else:
            typer.echo(f"  → Depends on {depends_on_id} {relation}")
    typer.echo(f"Task: {task}")
    typer.echo(f"Backend: {backend}")
    if model:
        typer.echo(f"Model: {model}")
    typer.echo(f"Output will be at: {output_file}")


@agent_app.command("list")
def agent_list(
    all_agents: bool = typer.Option(
        False, "-a", "--all", help="Show all agents (including completed)"
    ),
):
    """List sub-agents."""
    import json

    from otto.jobs.queue import JobQueue
    from otto.paths import OTTO_HOME

    queue = JobQueue()
    jobs = queue.list(job_type="agent", limit=50)

    agents: list[dict] = []
    for job in jobs:
        payload = job.get("payload") or {}
        agents.append(
            {
                "id": job.get("external_id") or payload.get("agent_id") or str(job.get("id", "?")),
                "job_id": job.get("id"),
                "task": payload.get("task") or payload.get("task_description") or "",
                "backend": payload.get("backend") or "default",
                "status": job.get("status") or "unknown",
                "depends_on_id": job.get("depends_on_id"),
                "depends_on_status": job.get("depends_on_status"),
            }
        )

    # Fallback to legacy state.json if jobs table is empty
    if not agents:
        state_file = OTTO_HOME / "state.json"
        if state_file.exists():
            try:
                state = json.loads(state_file.read_text())
                legacy = state.get("agents", [])
                if isinstance(legacy, list):
                    agents = [
                        {
                            "id": a.get("id", "?"),
                            "job_id": None,
                            "task": a.get("task", ""),
                            "backend": a.get("backend", "unknown"),
                            "status": a.get("status", "unknown"),
                        }
                        for a in legacy
                        if isinstance(a, dict)
                    ]
            except (json.JSONDecodeError, OSError):
                pass

    if not all_agents:
        agents = [a for a in agents if a.get("status") in ("pending", "running", "waiting")]

    if not agents:
        typer.echo("No sub-agents." if not all_agents else "No sub-agents found.")
        return

    for agent in agents:
        task = (agent.get("task") or "")[:60]
        backend = agent.get("backend") or "default"
        status = agent.get("status") or "unknown"
        status_icon = {
            "pending": "⏸",
            "waiting": "⏳",
            "running": "🔄",
            "completed": "✅",
            "failed": "❌",
            "cancelled": "⏹️",
        }.get(status, "?")

        job_info = f" (job {agent['job_id']})" if agent.get("job_id") else ""
        dep_note = ""
        dep_id = agent.get("depends_on_id")
        dep_status = agent.get("depends_on_status")
        if dep_id and dep_status == "success":
            dep_note = f" (after {dep_id} succeeds)"
        elif dep_id and dep_status == "failure":
            dep_note = f" (after {dep_id} fails)"
        elif dep_id:
            dep_note = f" (after {dep_id})"

        typer.echo(
            f"{status_icon} {agent['id']}{job_info}: {task} ({backend}) [{status}]{dep_note}"
        )


@agent_app.command("output")
def agent_output(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    tail: int = typer.Option(0, "-n", "--tail", help="Show last N lines (0 = all)"),
):
    """Read output from a completed agent."""
    from otto.paths import OUTPUTS_DIR

    output_file = OUTPUTS_DIR / f"{agent_id}.txt"
    if not output_file.exists():
        typer.echo(f"No output file for agent {agent_id}", err=True)
        raise typer.Exit(1)

    content = output_file.read_text()
    if tail > 0:
        lines = content.splitlines()
        content = "\n".join(lines[-tail:])

    typer.echo(content)


@agent_app.command("cancel")
def agent_cancel(
    agent_id: str = typer.Argument(..., help="Agent ID to cancel, or 'all'"),
    all_agents: bool = typer.Option(False, "--all", "-a", help="Cancel all active agents"),
):
    """Cancel an agent (pending, waiting, or running)."""
    from otto.jobs.queue import JobQueue

    queue = JobQueue()

    if all_agents or agent_id.lower() == "all":
        count = queue.force_cancel_all_running(job_type="agent")
        typer.echo(f"Cancelled {count} agent(s).")
        return

    job = queue.get_by_external_id(agent_id, job_type="agent")
    if not job:
        typer.echo(f"Agent {agent_id} not found", err=True)
        raise typer.Exit(1)

    if queue.force_cancel(int(job["id"])):
        typer.echo(f"Cancelled agent {agent_id}")
    else:
        status = job.get("status")
        typer.echo(f"Agent {agent_id} is already {status}", err=True)
        raise typer.Exit(1)


@agent_app.command("remove")
def agent_remove(agent_id: str = typer.Argument(..., help="Agent ID to remove")):
    """Remove an agent record from state."""
    import asyncio

    from otto.orchestrator import get_orchestrator

    async def _remove():
        orchestrator = get_orchestrator()
        success = await orchestrator.remove(agent_id)
        if success:
            typer.echo(f"Removed agent {agent_id}")
        else:
            typer.echo(f"Agent {agent_id} not found", err=True)
            raise typer.Exit(1)

    asyncio.run(_remove())


@agent_app.command("clear")
def agent_clear():
    """Clear all completed/failed/cancelled agents from state."""
    import asyncio

    from otto.orchestrator import get_orchestrator

    async def _clear():
        orchestrator = get_orchestrator()
        removed = await orchestrator.clear_completed()
        typer.echo(f"Cleared {removed} agent(s)")

    asyncio.run(_clear())


@agent_app.command("queue")
def agent_queue(
    clear: bool = typer.Option(False, "--clear", "-c", help="Clear processed messages from the queue"),
):
    """Show pending internal messages (agent completions waiting to be processed).

    Use --clear to remove already-processed messages.
    """
    if clear:
        from otto.internal_messages import clear_processed

        removed = clear_processed()
        typer.echo(f"Cleared {removed} processed message(s)")
        return

    from otto.internal_messages import get_pending_messages

    messages = get_pending_messages()
    if not messages:
        typer.echo("No pending messages.")
        return

    for msg in messages:
        payload = msg.payload
        typer.echo(f"📬 {msg.id} [{msg.type}]")
        if msg.type == "agent_completed":
            status = "✅" if payload.get("success") else "❌"
            typer.echo(f"   {status} Agent: {payload.get('agent_id')} - {payload.get('task')}")
        typer.echo(f"   Time: {msg.timestamp}")
        typer.echo()


@agent_app.command("batch")
def agent_batch(
    flush: bool = typer.Option(
        False, "--flush", "-f", help="Force flush pending low-priority messages now"
    ),
    status: bool = typer.Option(False, "--status", "-s", help="Show batch queue status"),
):
    """Manage low-priority agent batch queue.

    Low-priority agents are batched together and delivered as a single summary
    when either the threshold count or max wait time is reached.

    Use --status to see pending batched messages.
    Use --flush to force immediate delivery of all pending messages.
    """
    from datetime import datetime

    from otto import config as otto_config
    from otto.internal_messages import get_pending_messages

    if status or (not flush):
        # Show batch status
        messages = get_pending_messages()
        low_priority = [m for m in messages if m.payload.get("priority") == "low"]

        batch_config = otto_config.get_setting("agent.orchestration.batch", {})
        threshold = batch_config.get("low_priority_threshold", 3)
        max_wait = batch_config.get("low_priority_max_wait_minutes", 5)

        typer.echo("📦 Batch Queue Status\n")
        typer.echo("Config:")
        typer.echo(f"  Threshold: {threshold} messages")
        typer.echo(f"  Max wait: {max_wait} minutes")
        typer.echo(f"  AI summary: {batch_config.get('batch_with_ai_summary', True)}")
        typer.echo()

        if not low_priority:
            typer.echo("Queue: empty (0 pending)")
            return

        typer.echo(f"Queue: {len(low_priority)} pending")
        oldest = min(low_priority, key=lambda m: m.timestamp)
        try:
            oldest_time = datetime.fromisoformat(oldest.timestamp)
            age_minutes = (datetime.now() - oldest_time).total_seconds() / 60
            typer.echo(f"Oldest: {age_minutes:.1f} min ago")
        except Exception:
            pass

        typer.echo()
        for msg in low_priority:
            payload = msg.payload
            status_icon = "✅" if payload.get("success") else "❌"
            typer.echo(
                f"  {status_icon} {payload.get('agent_id', '?')[:8]} - {payload.get('task', '?')[:40]}"
            )

        # Show when batch will trigger
        if len(low_priority) >= threshold:
            typer.echo("\n⚡ Threshold reached! Will batch on next poll.")
        elif age_minutes and age_minutes >= max_wait:
            typer.echo("\n⏰ Max wait reached! Will batch on next poll.")
        else:
            remaining = threshold - len(low_priority)
            typer.echo(f"\n⏳ Need {remaining} more or wait until max age")

    if flush:
        # Force flush by marking messages for immediate processing
        from otto.internal_messages import force_batch_flush, get_pending_messages

        messages = get_pending_messages()
        low_priority = [m for m in messages if m.payload.get("priority") == "low"]

        if not low_priority:
            typer.echo("No low-priority messages to flush.")
            return

        # Change priority to "normal" to force immediate processing
        count = force_batch_flush()
        typer.echo(f"Flushed {count} message(s) - will process on next poll (within 10s)")


@skills_app.command("list")
def skills_list():
    """List available skills."""
    from otto_tools.skills.loader import SkillLoader

    loader = SkillLoader()
    skills = loader.discover()
    if not skills:
        typer.echo("No skills found.")
        return
    for s in skills:
        typer.echo(f"{s.name} - {s.description}")


@skills_app.command("show")
def skills_show(name: str = typer.Argument(..., help="Skill name")):
    """Show a skill's SKILL.md (without frontmatter)."""
    from otto_tools.skills.loader import SkillLoader

    loader = SkillLoader()
    loader.discover()
    skill = loader.get(name)
    if not skill:
        raise typer.Exit(1)
    loader.activate(skill)
    typer.echo(skill.content or "")


@skills_app.command("prompt")
def skills_prompt():
    """Generate <available_skills> XML for prompt injection."""
    from otto_tools.skills.loader import SkillLoader

    loader = SkillLoader()
    loader.discover()
    typer.echo(loader.generate_prompt_xml())


# ---- Signal commands under chat ----


@chat_signal_app.command("start")
def chat_signal_start(
    api_url: str = typer.Option("http://localhost:8080", "--api", help="signal-cli-rest-api URL"),
    phone: str = typer.Option(None, "--phone", "-p", help="Signal phone number (or from config)"),
):
    """Start the Signal bot (runs in foreground)."""
    import asyncio

    from otto import config as otto_config
    from otto.chat.signal import SignalPlatform

    if not phone:
        phone = otto_config.get_setting("signal.phone_number")
        if not phone:
            typer.echo("Error: No phone number. Use --phone or set signal.phone_number in config.")
            raise typer.Exit(1)

    allowed = otto_config.get_setting("signal.allowed_numbers") or []
    allowed_set = set(allowed) if allowed else None

    async def main():
        platform = SignalPlatform(
            api_url=api_url,
            phone_number=phone,
            allowed_numbers=allowed_set,
        )
        await platform.start()
        typer.echo(f"Signal bot running for {phone}...")
        try:
            while True:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            pass
        finally:
            await platform.stop()

    asyncio.run(main())


@chat_signal_app.command("setup")
def chat_signal_setup():
    """Interactive Signal setup - start Docker, link device."""
    import time

    compose_path = Path(__file__).parent / "chat" / "signal" / "docker-compose.yml"

    typer.echo("Signal Setup\n")

    if subprocess.run(["docker", "info"], capture_output=True).returncode != 0:
        typer.echo("Error: Docker not running. Start Docker first.")
        raise typer.Exit(1)

    typer.echo("1. Starting signal-cli-rest-api container...")
    result = subprocess.run(
        ["docker", "compose", "-f", str(compose_path), "up", "-d"],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        typer.echo(f"Error: {result.stderr}")
        raise typer.Exit(1)

    typer.echo("   Container started.")
    typer.echo("   Waiting for API to be ready...")

    import requests

    for i in range(30):
        try:
            resp = requests.get("http://localhost:8080/v1/about", timeout=2)
            if resp.status_code == 200:
                break
        except Exception:
            pass
        time.sleep(1)
    else:
        typer.echo("   Warning: API not responding yet, continuing anyway...\n")

    typer.echo("\n2. Link your Signal number:")
    typer.echo("   a) Open Signal on your phone")
    typer.echo("   b) Settings → Linked Devices → Link New Device")
    typer.echo("   c) Follow the QR code instructions from the signal-cli-rest-api logs")
    typer.echo("\n   Run: docker logs -f signal-cli-rest-api")


@chat_signal_app.command("status")
def chat_signal_status(
    api_url: str = typer.Option("http://localhost:8080", "--api", help="signal-cli-rest-api URL"),
):
    """Check Signal API status."""
    import requests

    try:
        resp = requests.get(f"{api_url}/v1/about", timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            typer.echo("Signal API: running")
            typer.echo(f"  Version: {data.get('version', 'unknown')}")
            typer.echo(f"  Build: {data.get('build', 'unknown')}")
        else:
            typer.echo(f"Signal API: error (status {resp.status_code})")
            raise typer.Exit(1)
    except requests.exceptions.ConnectionError:
        typer.echo("Signal API: not running")
        typer.echo("  Start with: otto chat signal setup")
        raise typer.Exit(1)
    except Exception as e:
        typer.echo(f"Signal API: error ({e})")
        raise typer.Exit(1)


@chat_signal_app.command("send")
def chat_signal_send(
    recipient: str = typer.Argument(..., help="Phone number to send to"),
    message: str = typer.Argument(..., help="Message to send"),
    api_url: str = typer.Option("http://localhost:8080", "--api", help="signal-cli-rest-api URL"),
    phone: str = typer.Option(None, "--phone", "-p", help="Signal phone number (or from config)"),
):
    """Send a Signal message."""
    import asyncio

    from otto import config as otto_config
    from otto.chat.signal.client import SignalClient

    if not phone:
        phone = otto_config.get_setting("signal.phone_number")
        if not phone:
            typer.echo("Error: No phone number. Use --phone or set signal.phone_number in config.")
            raise typer.Exit(1)

    async def send():
        client = SignalClient(api_url=api_url, phone_number=phone)
        await client.send_message(recipient, message)
        typer.echo(f"Sent to {recipient}")

    asyncio.run(send())


# New consolidated commands
# (Deprecated top-level 'otto signal' app removed; use 'otto chat signal')
app.add_typer(chat_app, name="chat")
app.add_typer(service_app, name="service")
app.add_typer(job_app, name="job")
app.add_typer(mcp_app, name="mcp")
app.add_typer(skills_app, name="skills")
app.add_typer(config_app, name="config")
app.add_typer(agent_app, name="agent")

# Nest backend under config
# (Deprecated top-level 'otto backend' alias removed; use 'otto config backend')
config_app.add_typer(backend_app, name="backend")


# ---- Audit logging ----

audit_app = typer.Typer(no_args_is_help=True, help="Query audit logs.")


@audit_app.command("tail")
def audit_tail(
    limit: int = typer.Option(20, "-n", "--limit", help="Number of entries"),
    audit_type: str = typer.Option(
        None,
        "-t",
        "--type",
        help="Filter by type (message, action, security, agent, error, system)",
    ),
    json_output: bool = typer.Option(False, "-j", "--json", help="Output as JSON"),
):
    """Show recent audit log entries."""
    import json as json_mod

    from otto import audit

    entries = audit.get_recent_logs(
        audit_type=audit_type if audit_type else None,
        limit=limit,
    )

    if json_output:
        typer.echo(json_mod.dumps(entries, indent=2, default=str))
    else:
        if not entries:
            typer.echo("No audit entries found.")
            return
        typer.echo(audit.format_logs(entries))


@audit_app.command("messages")
def audit_messages(
    limit: int = typer.Option(20, "-n", "--limit", help="Number of entries"),
    json_output: bool = typer.Option(False, "-j", "--json", help="Output as JSON"),
):
    """Show recent message history."""
    import json as json_mod

    from otto import audit

    entries = audit.get_message_history(limit=limit)

    if json_output:
        typer.echo(json_mod.dumps(entries, indent=2, default=str))
    else:
        if not entries:
            typer.echo("No messages found.")
            return
        for e in entries:
            ts = e.get("timestamp", "")[:19]
            data = e.get("data", {})
            role = data.get("role", "?")
            content = data.get("content", "")[:100]
            backend = e.get("backend") or ""
            if backend:
                backend = f" ({backend})"
            typer.echo(f"{ts} [{role}]{backend}: {content}")


@audit_app.command("security")
def audit_security(
    limit: int = typer.Option(50, "-n", "--limit", help="Number of entries"),
    failed_only: bool = typer.Option(False, "-f", "--failed", help="Show only failed events"),
    json_output: bool = typer.Option(False, "-j", "--json", help="Output as JSON"),
):
    """Show security events."""
    import json as json_mod

    from otto import audit

    entries = audit.get_security_events(limit=limit, failed_only=failed_only)

    if json_output:
        typer.echo(json_mod.dumps(entries, indent=2, default=str))
    else:
        if not entries:
            typer.echo("No security events found.")
            return
        typer.echo(audit.format_logs(entries))


@audit_app.command("stats")
def audit_stats():
    """Show audit log statistics."""
    from otto import audit
    from otto.paths import LOGS_DIR

    audit_files = list(LOGS_DIR.glob("audit-*.jsonl"))

    if not audit_files:
        typer.echo("No audit logs found.")
        return

    total_size = sum(f.stat().st_size for f in audit_files)
    total_files = len(audit_files)

    # Count by type from recent entries
    recent = audit.get_recent_logs(limit=1000)
    by_type = {}
    for e in recent:
        t = e.get("type", "unknown")
        by_type[t] = by_type.get(t, 0) + 1

    typer.echo("Audit Log Stats")
    typer.echo(f"  Files: {total_files}")
    typer.echo(f"  Size: {total_size / 1024:.1f} KB")
    typer.echo("  Recent entries by type:")
    for t, count in sorted(by_type.items(), key=lambda x: -x[1]):
        typer.echo(f"    {t}: {count}")


app.add_typer(audit_app, name="audit")


# ---- Pipeline orchestration ----

pipeline_app = typer.Typer(no_args_is_help=True, help="Multi-step pipeline orchestration.")


@pipeline_app.command("list")
def pipeline_list():
    """List available pipelines (skills with pipeline.yaml)."""
    from otto.pipeline import discover_pipelines

    pipelines = discover_pipelines()
    if not pipelines:
        typer.echo("No pipelines found.")
        typer.echo("Create a skill with pipeline.yaml in ~/.otto/skills/")
        return

    typer.echo("Available Pipelines:")
    for p in pipelines:
        step_count = len(p.steps)
        typer.echo(f"  {p.name} - {p.description} ({step_count} steps)")


@pipeline_app.command("show")
def pipeline_show(name: str = typer.Argument(..., help="Pipeline name")):
    """Show pipeline details."""
    from otto.pipeline import get_pipeline

    pipeline = get_pipeline(name)
    if not pipeline:
        typer.echo(f"Pipeline not found: {name}", err=True)
        raise typer.Exit(1)

    errors = pipeline.validate()
    if errors:
        typer.echo("Pipeline has validation errors:", err=True)
        for e in errors:
            typer.echo(f"  - {e}", err=True)
        raise typer.Exit(1)

    typer.echo(f"Pipeline: {pipeline.name}")
    typer.echo(f"Description: {pipeline.description}")
    typer.echo(f"Default backend: {pipeline.default_backend}")
    typer.echo(f"Default timeout: {pipeline.default_timeout}s")
    typer.echo(f"\nSteps ({len(pipeline.steps)}):")

    for i, step in enumerate(pipeline.steps, 1):
        dep = f" (after {step.depends_on})" if step.depends_on else ""
        typer.echo(f"  {i}. {step.id} [{step.backend}]{dep}")
        prompt_preview = step.prompt[:60] + "..." if len(step.prompt) > 60 else step.prompt
        typer.echo(f"     Prompt: {prompt_preview}")


@pipeline_app.command("run")
def pipeline_run(
    name: str = typer.Argument(..., help="Pipeline name"),
    task: str = typer.Option(None, "-t", "--task", help="Task variable to substitute"),
    notify: bool = typer.Option(True, "--notify/--no-notify", help="Notify on completion"),
    priority: str = typer.Option("normal", "-P", "--priority", help="Priority: high/normal/low"),
    var: list[str] = typer.Option([], "-v", "--var", help="Variable in key=value format"),
):
    """Run a pipeline."""
    from otto.daemon import ServiceStatus, status
    from otto.pipeline import get_pipeline, run_pipeline

    pipeline = get_pipeline(name)
    if not pipeline:
        typer.echo(f"Pipeline not found: {name}", err=True)
        raise typer.Exit(1)

    errors = pipeline.validate()
    if errors:
        typer.echo("Pipeline has validation errors:", err=True)
        for e in errors:
            typer.echo(f"  - {e}", err=True)
        raise typer.Exit(1)

    # Build variables dict
    variables = {}
    if task:
        variables["task"] = task

    for v in var:
        if "=" in v:
            key, value = v.split("=", 1)
            variables[key] = value
        else:
            typer.echo(f"Invalid variable format: {v} (use key=value)", err=True)
            raise typer.Exit(1)

    # Check worker status
    info = status("job-worker")
    if info.status != ServiceStatus.RUNNING:
        typer.echo(
            "Warning: worker is not running. Start it with: otto service start worker", err=True
        )

    # Run the pipeline
    run_result = run_pipeline(
        pipeline,
        variables=variables,
        notify_on_complete=notify,
        priority=priority,
    )

    typer.echo(f"Pipeline started: {run_result.pipeline_id}")
    typer.echo(f"  Name: {pipeline.name}")
    typer.echo(f"  Steps: {len(pipeline.steps)}")
    typer.echo("\nStep agents:")
    for step_id, agent_id in run_result.step_agents.items():
        typer.echo(f"  {step_id}: {agent_id}")

    typer.echo(f"\nTrack with: otto agent pipeline status {run_result.pipeline_id}")


@pipeline_app.command("status")
def pipeline_status(
    pipeline_id: str = typer.Argument(..., help="Pipeline run ID"),
    json_output: bool = typer.Option(False, "-j", "--json", help="Output as JSON"),
):
    """Check pipeline status."""
    import json as json_mod

    from otto.pipeline import get_pipeline_status

    status = get_pipeline_status(pipeline_id)
    if not status:
        typer.echo(f"Pipeline not found: {pipeline_id}", err=True)
        raise typer.Exit(1)

    if json_output:
        typer.echo(json_mod.dumps(status, indent=2))
        return

    status_icons = {
        "completed": "✅",
        "failed": "❌",
        "running": "🔄",
        "pending": "⏸",
        "waiting": "⏳",
        "cancelled": "⏹️",
    }

    overall_icon = status_icons.get(status["status"], "?")
    typer.echo(f"Pipeline: {pipeline_id}")
    typer.echo(f"Status: {overall_icon} {status['status']}")
    typer.echo("\nSteps:")

    for step in status["steps"]:
        icon = status_icons.get(step["status"], "?")
        typer.echo(f"  {icon} {step['step_id']} [{step['backend']}] - {step['status']}")
        if step.get("output_file"):
            typer.echo(f"     Output: {step['output_file']}")


@pipeline_app.command("cancel")
def pipeline_cancel(pipeline_id: str = typer.Argument(..., help="Pipeline run ID")):
    """Cancel a running pipeline."""
    from otto.pipeline import cancel_pipeline

    cancelled = cancel_pipeline(pipeline_id)
    if cancelled > 0:
        typer.echo(f"Cancelled {cancelled} step(s) in pipeline {pipeline_id}")
    else:
        typer.echo(f"No cancellable steps found for pipeline {pipeline_id}")


# Nest pipeline under agent
# (Deprecated top-level 'otto pipeline' alias removed; use 'otto agent pipeline')
agent_app.add_typer(pipeline_app, name="pipeline")


try:
    # Existing tooling apps (we'll progressively migrate these into otto/)
    from otto_tools.memory import app as memory_app
    from otto_tools.notify import app as notify_app
    from otto_tools.system import app as system_app

    # Keep standalone commands that make sense at top level
    app.add_typer(memory_app, name="memory", help="Memory operations")
    app.add_typer(system_app, name="system", help="System info and monitoring")

    # Notify stays top-level (was previously also under 'otto tool notify')
    # Deprecated 'otto tool' namespace removed; 'otto notify' is the canonical path.
    app.add_typer(notify_app, name="notify", help="Send notifications")
except Exception:
    # Keep CLI importable even if optional subcommands fail to import.
    pass


def run() -> None:
    app()


if __name__ == "__main__":
    run()
