"""
Daemon process management for Otto services.

Provides start/stop/restart/reload/status for long-running services
like the Telegram bot and job worker.

PID files are stored in ~/.otto/pids/
Ready markers and restart notifications are in ~/.otto/run/
"""

from __future__ import annotations

import json
import logging
import os
import re
import signal
import subprocess
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

from .paths import LOGS_DIR, PIDS_DIR, RUN_DIR, ensure_dirs

log = logging.getLogger(__name__)

# Valid service name pattern (alphanumeric, hyphens, underscores only)
_SERVICE_NAME_PATTERN = re.compile(r"^[a-zA-Z][a-zA-Z0-9_-]*$")


class ServiceStatus(Enum):
    """Service status."""

    RUNNING = "running"
    STOPPED = "stopped"
    DEAD = "dead"  # PID file exists but process is gone


@dataclass
class ServiceInfo:
    """Information about a service."""

    name: str
    status: ServiceStatus
    pid: int | None = None
    uptime_seconds: float | None = None


def _validate_service_name(service: str) -> None:
    """
    Validate service name to prevent path traversal attacks.

    Raises:
        ValueError: If service name is invalid
    """
    if not service or not _SERVICE_NAME_PATTERN.match(service):
        raise ValueError(
            f"Invalid service name: {service!r}. "
            "Must start with a letter and contain only alphanumeric, hyphens, underscores."
        )
    if len(service) > 64:
        raise ValueError(f"Service name too long: {len(service)} > 64 chars")


def _pid_file(service: str) -> Path:
    """Get PID file path for a service."""
    _validate_service_name(service)
    return PIDS_DIR / f"{service}.pid"


def _log_file(service: str) -> Path:
    """Get log file path for a service."""
    _validate_service_name(service)
    return LOGS_DIR / f"{service}.log"


def _read_pid(service: str) -> int | None:
    """Read PID from file, return None if not exists or invalid."""
    pid_file = _pid_file(service)
    if not pid_file.exists():
        return None
    try:
        content = pid_file.read_text().strip()
        pid = int(content)
        # Sanity check: PIDs are positive integers
        if pid <= 0:
            return None
        return pid
    except (ValueError, OSError):
        return None


def _write_pid(service: str, pid: int) -> None:
    """Write PID to file atomically."""
    ensure_dirs()
    pid_file = _pid_file(service)
    # Write to temp file first, then rename for atomicity
    tmp_file = pid_file.with_suffix(".tmp")
    tmp_file.write_text(str(pid))
    tmp_file.rename(pid_file)


def _remove_pid(service: str) -> None:
    """Remove PID file."""
    pid_file = _pid_file(service)
    try:
        pid_file.unlink(missing_ok=True)
    except OSError as e:
        log.warning("Failed to remove PID file %s: %s", pid_file, e)


def _is_running(pid: int) -> bool:
    """Check if a process is running."""
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)  # Signal 0 = check if process exists
        return True
    except (OSError, ProcessLookupError):
        return False


def _get_process_start_time(pid: int) -> float | None:
    """
    Get process start time (Unix timestamp).

    Parses /proc/{pid}/stat carefully to handle command names with spaces/parens.
    """
    try:
        stat_file = Path(f"/proc/{pid}/stat")
        if not stat_file.exists():
            return None

        content = stat_file.read_text()

        # Field 2 (comm) is enclosed in parentheses and can contain spaces/parens
        # Find the last ')' to reliably split the fields after it
        last_paren = content.rfind(")")
        if last_paren == -1:
            return None

        # Fields after the command name (starting from field 3)
        fields_after_comm = content[last_paren + 2 :].split()

        # Field 22 (starttime) is at index 19 in fields_after_comm (field 3 is index 0)
        # Actually: field 22 is starttime, field 3 is state
        # So starttime is at index 22 - 3 = 19
        if len(fields_after_comm) < 20:
            return None

        starttime_ticks = int(fields_after_comm[19])

        # Get system boot time
        with open("/proc/stat") as f:
            for line in f:
                if line.startswith("btime "):
                    boot_time = int(line.split()[1])
                    break
            else:
                return None

        # Convert ticks to seconds
        ticks_per_sec = os.sysconf(os.sysconf_names["SC_CLK_TCK"])
        start_time = boot_time + (starttime_ticks / ticks_per_sec)
        return start_time

    except (OSError, IndexError, ValueError, KeyError) as e:
        log.debug("Failed to get process start time for PID %d: %s", pid, e)
        return None


def status(service: str) -> ServiceInfo:
    """Get status of a service."""
    pid = _read_pid(service)

    if pid is None:
        return ServiceInfo(name=service, status=ServiceStatus.STOPPED)

    if not _is_running(pid):
        # Stale PID file
        return ServiceInfo(name=service, status=ServiceStatus.DEAD, pid=pid)

    # Calculate uptime
    uptime = None
    start_time = _get_process_start_time(pid)
    if start_time:
        uptime = time.time() - start_time

    return ServiceInfo(
        name=service,
        status=ServiceStatus.RUNNING,
        pid=pid,
        uptime_seconds=uptime,
    )


def start(
    service: str,
    command: list[str],
    *,
    check_running: bool = True,
    env: dict | None = None,
) -> tuple[bool, str]:
    """
    Start a service as a background daemon.

    Args:
        service: Service name (for PID file). Must be alphanumeric with hyphens/underscores.
        command: Command to run (first element should be absolute path or found in PATH)
        check_running: If True, fail if already running
        env: Additional environment variables

    Returns:
        (success, message) tuple
    """
    ensure_dirs()

    # Validate inputs
    _validate_service_name(service)
    if not command:
        return False, "Empty command"

    # Check if already running
    if check_running:
        info = status(service)
        if info.status == ServiceStatus.RUNNING:
            return False, f"{service} is already running (PID {info.pid})"
        elif info.status == ServiceStatus.DEAD:
            # Clean up stale PID file
            _remove_pid(service)

    # Prepare environment
    proc_env = os.environ.copy()
    if env:
        proc_env.update(env)

    # Open log file for output
    log_file = _log_file(service)

    try:
        with open(log_file, "a") as log_fd:
            # Start the process
            proc = subprocess.Popen(
                command,
                stdout=log_fd,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                env=proc_env,
                start_new_session=True,  # Detach from terminal
            )

        # Write PID file
        _write_pid(service, proc.pid)

        # Brief wait to check if it started successfully
        time.sleep(0.5)
        if not _is_running(proc.pid):
            _remove_pid(service)
            return False, f"{service} failed to start (check {log_file})"

        return True, f"{service} started (PID {proc.pid})"

    except FileNotFoundError:
        return False, f"Command not found: {command[0]}"
    except PermissionError:
        return False, f"Permission denied: {command[0]}"
    except Exception as e:
        log.exception("Failed to start %s", service)
        return False, f"Failed to start {service}: {e}"


def default_service_commands() -> dict[str, list[str]]:
    """Known Otto-managed services and their start commands."""
    return {
        "telegram-bot": [sys.executable, "-m", "otto.services.telegram"],
        "job-worker": [sys.executable, "-m", "otto.services.worker", "--daemon"],
    }


def check_mcp_health(*, timeout: float = 10.0) -> tuple[bool, str]:
    """Check native gateway health by verifying policy loads."""
    try:
        from otto.gateway import get_gateway

        gateway = get_gateway()
        servers = gateway.list_servers()
        enabled = sum(1 for p in servers.values() if p.enabled)
        return True, f"ok ({enabled} server(s) enabled)"
    except Exception as e:
        return False, str(e)


def stop(service: str, *, timeout: float = 10.0) -> tuple[bool, str]:
    """
    Stop a service gracefully (SIGTERM, then SIGKILL).

    Args:
        service: Service name
        timeout: Seconds to wait for graceful shutdown (default: 10)

    Returns:
        (success, message) tuple
    """
    info = status(service)

    if info.status == ServiceStatus.STOPPED:
        return True, f"{service} is not running"

    if info.status == ServiceStatus.DEAD:
        _remove_pid(service)
        return True, f"{service} was not running (cleaned up stale PID)"

    pid = info.pid

    try:
        # Send SIGTERM for graceful shutdown
        os.kill(pid, signal.SIGTERM)

        # Wait for process to exit
        deadline = time.time() + timeout
        while time.time() < deadline:
            if not _is_running(pid):
                _remove_pid(service)
                return True, f"{service} stopped"
            time.sleep(0.2)

        # Force kill if still running
        os.kill(pid, signal.SIGKILL)
        time.sleep(0.5)
        _remove_pid(service)
        return True, f"{service} killed (did not respond to SIGTERM)"

    except ProcessLookupError:
        _remove_pid(service)
        return True, f"{service} stopped"
    except Exception as e:
        log.exception("Failed to stop %s", service)
        return False, f"Failed to stop {service}: {e}"


def restart(
    service: str,
    command: list[str],
    *,
    env: dict | None = None,
) -> tuple[bool, str]:
    """Stop and start a service."""
    stop_ok, stop_msg = stop(service)
    if not stop_ok:
        return False, f"Failed to stop: {stop_msg}"

    # Brief pause between stop and start
    time.sleep(0.5)

    return start(service, command, check_running=False, env=env)


def reload_config(service: str) -> tuple[bool, str]:
    """
    Send SIGHUP to reload configuration.

    The service must handle SIGHUP appropriately.

    Returns:
        (success, message) tuple
    """
    info = status(service)

    if info.status != ServiceStatus.RUNNING:
        return False, f"{service} is not running"

    try:
        os.kill(info.pid, signal.SIGHUP)
        return True, f"Reload signal sent to {service} (PID {info.pid})"
    except ProcessLookupError:
        return False, f"{service} is no longer running"
    except Exception as e:
        return False, f"Failed to reload {service}: {e}"


def format_uptime(seconds: float | None) -> str:
    """Format uptime as human-readable string."""
    if seconds is None:
        return "unknown"

    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds}s"
    elif seconds < 3600:
        return f"{seconds // 60}m {seconds % 60}s"
    elif seconds < 86400:
        hours = seconds // 3600
        mins = (seconds % 3600) // 60
        return f"{hours}h {mins}m"
    else:
        days = seconds // 86400
        hours = (seconds % 86400) // 3600
        return f"{days}d {hours}h"


# Signal handler state
_sighup_handler_installed = False
_reload_callbacks: list[Callable[[], None]] = []


def _handle_sighup(signum, frame):
    """Internal SIGHUP handler that calls all registered callbacks."""
    for cb in _reload_callbacks:
        try:
            cb()
        except Exception as e:
            print(f"Reload callback error: {e}", file=sys.stderr)


def register_reload_handler(callback: Callable[[], None]) -> None:
    """
    Register a callback to be called on SIGHUP.

    Services should call this to enable reload support. The signal
    handler is installed only once, on first registration.
    """
    global _sighup_handler_installed

    _reload_callbacks.append(callback)

    if not _sighup_handler_installed:
        signal.signal(signal.SIGHUP, _handle_sighup)
        _sighup_handler_installed = True


def write_own_pid(service: str) -> None:
    """
    Write current process PID to file.

    Call this at service startup when running in foreground mode.
    """
    ensure_dirs()
    _write_pid(service, os.getpid())


def cleanup_own_pid(service: str) -> None:
    """
    Remove PID file for current service.

    Call this at service shutdown.
    """
    _remove_pid(service)


# ---------------------------------------------------------------------------
# Ready markers - for health checks during restart
# ---------------------------------------------------------------------------


def _ready_file(service: str) -> Path:
    """Get ready marker file path for a service."""
    _validate_service_name(service)
    return RUN_DIR / f"{service}.ready"


def write_ready_marker(service: str) -> None:
    """
    Write a ready marker indicating the service is fully initialized.

    Call this after the service has started and is ready to handle requests.
    """
    ensure_dirs()
    ready_file = _ready_file(service)
    ready_file.write_text(
        json.dumps(
            {
                "pid": os.getpid(),
                "timestamp": datetime.now().isoformat(),
            }
        )
    )


def clear_ready_marker(service: str, *, only_own: bool = True) -> None:
    """
    Remove the ready marker for a service.

    Args:
        service: Service name
        only_own: If True, only clear if the marker belongs to current process
    """
    ready_file = _ready_file(service)
    if not ready_file.exists():
        return

    if only_own:
        try:
            data = json.loads(ready_file.read_text())
            marker_pid = data.get("pid")
            if marker_pid != os.getpid():
                # Marker belongs to a different process - don't clear it
                return
        except (json.JSONDecodeError, OSError):
            pass

    try:
        ready_file.unlink(missing_ok=True)
    except OSError:
        pass


def is_ready(service: str, max_age_seconds: float = 30.0) -> bool:
    """
    Check if a service has a recent ready marker.

    Args:
        service: Service name
        max_age_seconds: Maximum age of ready marker to consider valid

    Returns:
        True if service has a recent ready marker
    """
    ready_file = _ready_file(service)
    if not ready_file.exists():
        return False

    try:
        data = json.loads(ready_file.read_text())
        timestamp = datetime.fromisoformat(data.get("timestamp", ""))
        age = (datetime.now() - timestamp).total_seconds()
        return age <= max_age_seconds
    except (json.JSONDecodeError, ValueError, OSError):
        return False


def wait_for_ready(service: str, timeout: float = 30.0, poll_interval: float = 0.5) -> bool:
    """
    Wait for a service to become ready.

    Args:
        service: Service name
        timeout: Maximum time to wait in seconds
        poll_interval: Time between checks

    Returns:
        True if service became ready, False if timed out
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        if is_ready(service):
            return True
        time.sleep(poll_interval)
    return False


# ---------------------------------------------------------------------------
# Restart notifications - notify user when bot comes back online
# ---------------------------------------------------------------------------


def _restart_notify_file(service: str) -> Path:
    """Get restart notification file path for a service."""
    _validate_service_name(service)
    return RUN_DIR / f"{service}.restart-notify.json"


def schedule_restart_notification(
    service: str,
    chat_id: str | int,
    user_id: str | int | None = None,
    user_name: str | None = None,
    reason: str = "restart",
    platform: str = "telegram",
) -> None:
    """
    Schedule a notification to be sent when the service restarts.

    Args:
        service: Service name (e.g., "telegram-bot")
        chat_id: Chat ID to send notification to
        user_id: User ID who triggered the restart
        user_name: Username who triggered the restart
        reason: Reason for restart
        platform: Platform to notify on
    """
    ensure_dirs()
    notify_file = _restart_notify_file(service)
    notify_file.write_text(
        json.dumps(
            {
                "chat_id": str(chat_id),
                "user_id": str(user_id) if user_id else None,
                "user_name": user_name,
                "reason": reason,
                "platform": platform,
                "timestamp": datetime.now().isoformat(),
            }
        )
    )


def get_pending_restart_notification(service: str) -> dict[str, Any] | None:
    """
    Get and clear any pending restart notification.

    Returns:
        Notification data dict or None if no pending notification
    """
    notify_file = _restart_notify_file(service)
    if not notify_file.exists():
        return None

    try:
        data = json.loads(notify_file.read_text())
        notify_file.unlink(missing_ok=True)
        return data
    except (json.JSONDecodeError, OSError):
        notify_file.unlink(missing_ok=True)
        return None


def clear_restart_notification(service: str) -> None:
    """Clear any pending restart notification."""
    notify_file = _restart_notify_file(service)
    try:
        notify_file.unlink(missing_ok=True)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Graceful restart via signal
# ---------------------------------------------------------------------------

# State for signal-based restart
_restart_requested = False
_restart_callback: Callable[[], None] | None = None


def _handle_sigusr1(signum, frame):
    """Handle SIGUSR1 for graceful restart."""
    global _restart_requested
    _restart_requested = True
    log.info("Received SIGUSR1, initiating graceful restart...")

    if _restart_callback:
        try:
            _restart_callback()
        except Exception as e:
            log.error("Restart callback error: %s", e)


def register_restart_handler(callback: Callable[[], None]) -> None:
    """
    Register a callback to be called on SIGUSR1 (restart signal).

    The callback should initiate a graceful shutdown of the service.
    """
    global _restart_callback
    _restart_callback = callback
    signal.signal(signal.SIGUSR1, _handle_sigusr1)


def request_restart(service: str) -> tuple[bool, str]:
    """
    Request a graceful restart of a running service by sending SIGUSR1.

    Args:
        service: Service name

    Returns:
        (success, message) tuple
    """
    info = status(service)
    if info.status != ServiceStatus.RUNNING:
        return False, f"{service} is not running"

    try:
        os.kill(info.pid, signal.SIGUSR1)
        return True, f"Restart signal sent to {service} (PID {info.pid})"
    except ProcessLookupError:
        return False, f"{service} is no longer running"
    except Exception as e:
        return False, f"Failed to send restart signal: {e}"


def graceful_restart(
    service: str,
    command: list[str],
    *,
    notify_chat_id: str | int | None = None,
    notify_user_id: str | int | None = None,
    notify_user_name: str | None = None,
    env: dict | None = None,
    ready_timeout: float = 30.0,
) -> tuple[bool, str]:
    """
    Perform a graceful restart with health checks and optional notification.

    This spawns a new process, waits for it to become ready, then stops the old one.

    Args:
        service: Service name
        command: Command to start the service
        notify_chat_id: Chat ID to notify when restart completes
        notify_user_id: User ID who triggered restart
        notify_user_name: Username who triggered restart
        env: Additional environment variables
        ready_timeout: Max seconds to wait for new process to be ready

    Returns:
        (success, message) tuple
    """
    ensure_dirs()

    # Schedule restart notification if requested
    if notify_chat_id:
        schedule_restart_notification(
            service,
            chat_id=notify_chat_id,
            user_id=notify_user_id,
            user_name=notify_user_name,
            reason="graceful_restart",
        )

    # Clear old ready marker
    clear_ready_marker(service)

    # Get current process info
    old_info = status(service)
    old_pid = old_info.pid if old_info.status == ServiceStatus.RUNNING else None

    # Start new process
    ok, msg = start(service, command, check_running=False, env=env)
    if not ok:
        clear_restart_notification(service)
        return False, f"Failed to start new process: {msg}"

    # Wait for new process to be ready
    if not wait_for_ready(service, timeout=ready_timeout):
        # New process didn't become ready, but it might still be running
        new_info = status(service)
        if new_info.status != ServiceStatus.RUNNING:
            clear_restart_notification(service)
            return False, "New process failed to start or become ready"
        # Process is running but not ready - might just be slow
        log.warning("New process running but not ready after %ss", ready_timeout)

    # Stop old process if it was running
    if old_pid and _is_running(old_pid):
        try:
            os.kill(old_pid, signal.SIGTERM)
            # Wait briefly for old process to exit
            deadline = time.time() + 10.0
            while time.time() < deadline and _is_running(old_pid):
                time.sleep(0.2)
            if _is_running(old_pid):
                os.kill(old_pid, signal.SIGKILL)
        except ProcessLookupError:
            pass  # Already exited
        except Exception as e:
            log.warning("Error stopping old process: %s", e)

    return True, f"{service} restarted successfully"


# Public API
__all__ = [
    # Service status
    "ServiceStatus",
    "ServiceInfo",
    "status",
    # Lifecycle
    "start",
    "stop",
    "restart",
    "reload_config",
    "graceful_restart",
    "request_restart",
    # Ready markers
    "write_ready_marker",
    "clear_ready_marker",
    "is_ready",
    "wait_for_ready",
    # Restart notifications
    "schedule_restart_notification",
    "get_pending_restart_notification",
    "clear_restart_notification",
    # Signal handlers
    "register_reload_handler",
    "register_restart_handler",
    # Helpers
    "default_service_commands",
    "check_mcp_health",
    "format_uptime",
    "write_own_pid",
    "cleanup_own_pid",
]
