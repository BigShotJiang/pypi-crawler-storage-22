# Data files shipped with Otto (catalogs, schemas, etc.)
