"""
External event bus + webhooks for Otto.

This module provides a tiny, dependency-free webhook server (stdlib http.server)
that can enqueue internal events or background agent jobs.
"""

from __future__ import annotations

import json
import os
import threading
import uuid
from dataclasses import dataclass
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

from otto.internal_messages import InternalMessage, queue_message
from otto.jobs.queue import JobQueue


@dataclass(frozen=True)
class WebhookConfig:
    host: str = "127.0.0.1"
    port: int = 8787
    token: str | None = None  # Bearer token
    max_body_bytes: int = 256 * 1024


def _require_token(headers: dict[str, str], token: str | None) -> bool:
    if not token:
        return True
    auth = headers.get("authorization") or headers.get("Authorization") or ""
    return auth.strip() == f"Bearer {token}"


def enqueue_system_event(
    *,
    event: str,
    details: Any | None = None,
    title: str | None = None,
    priority: str = "normal",
) -> str:
    """Queue a system_event internal message for the bot to deliver."""
    msg = InternalMessage.create(
        "system_event",
        {
            "event": event,
            "title": title or "External event",
            "details": details,
            "priority": priority,
        },
    )
    queue_message(msg)
    return msg.id


def enqueue_agent_job(
    *,
    prompt: str,
    task: str | None = None,
    backend: str | None = None,
    notify: bool = True,
    priority: str = "normal",
    queue: JobQueue | None = None,
) -> int:
    """Enqueue a background agent job via the job queue."""
    q = queue or JobQueue()
    agent_id = uuid.uuid4().hex[:12]
    payload = {
        "agent_id": agent_id,
        "task": task or "External agent trigger",
        "prompt": prompt,
        "backend": backend,
        "notify": bool(notify),
        "priority": priority,
    }
    return q.add("agent", payload, priority=0, external_id=f"webhook:{agent_id}")


class _WebhookHandler(BaseHTTPRequestHandler):
    server_version = "OttoWebhook/1.0"

    def _send(self, status: int, body: dict[str, Any]) -> None:
        data = json.dumps(body).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:  # noqa: N802
        if self.path.rstrip("/") in ("", "/health"):
            self._send(200, {"ok": True, "ts": datetime.now().isoformat()})
            return
        self._send(404, {"ok": False, "error": "not found"})

    def do_POST(self) -> None:  # noqa: N802
        cfg: WebhookConfig = self.server.webhook_config  # type: ignore[attr-defined]

        if not _require_token(dict(self.headers), cfg.token):
            self._send(401, {"ok": False, "error": "unauthorized"})
            return

        length = int(self.headers.get("Content-Length", "0") or "0")
        if length <= 0 or length > cfg.max_body_bytes:
            self._send(413, {"ok": False, "error": "invalid body length"})
            return

        try:
            raw = self.rfile.read(length)
            data = json.loads(raw.decode("utf-8"))
        except Exception:
            self._send(400, {"ok": False, "error": "invalid json"})
            return

        if self.path.rstrip("/") == "/event":
            event = str(data.get("event") or data.get("type") or "event")
            details = data.get("details", data.get("payload"))
            title = data.get("title")
            priority = str(data.get("priority") or "normal")
            msg_id = enqueue_system_event(
                event=event, details=details, title=title, priority=priority
            )
            self._send(200, {"ok": True, "id": msg_id})
            return

        if self.path.rstrip("/") == "/agent":
            prompt = str(data.get("prompt") or "").strip()
            if not prompt:
                self._send(400, {"ok": False, "error": "missing prompt"})
                return
            job_id = enqueue_agent_job(
                prompt=prompt,
                task=data.get("task"),
                backend=data.get("backend"),
                notify=bool(data.get("notify", True)),
                priority=str(data.get("priority") or "normal"),
            )
            self._send(200, {"ok": True, "job_id": job_id})
            return

        self._send(404, {"ok": False, "error": "not found"})


def run_webhook_server(cfg: WebhookConfig | None = None) -> ThreadingHTTPServer:
    """Start the webhook server in the foreground (blocking)."""
    cfg = cfg or WebhookConfig(
        host=os.environ.get("OTTO_WEBHOOK_HOST", "127.0.0.1"),
        port=int(os.environ.get("OTTO_WEBHOOK_PORT", "8787")),
        token=os.environ.get("OTTO_WEBHOOK_TOKEN") or None,
    )

    server = ThreadingHTTPServer((cfg.host, int(cfg.port)), _WebhookHandler)
    server.webhook_config = cfg  # type: ignore[attr-defined]
    server.serve_forever(poll_interval=0.5)
    return server


def start_webhook_server(cfg: WebhookConfig | None = None) -> ThreadingHTTPServer:
    """Start the webhook server on a background thread and return the server."""
    cfg = cfg or WebhookConfig()
    server = ThreadingHTTPServer((cfg.host, int(cfg.port)), _WebhookHandler)
    server.webhook_config = cfg  # type: ignore[attr-defined]

    t = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.5}, daemon=True)
    t.start()
    return server
