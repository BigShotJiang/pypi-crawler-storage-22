"""
Otto Security & Control Gateway (Pillar 3).

This module defines the native MCP bridge interface contract -- the single
trust boundary through which ALL backend tool access is mediated.

Architecture:
    Backends (Claude SDK, Codex, Generic) never access tools directly.
    Every tool invocation flows through the Gateway:

        Backend  -->  Gateway.request_tool()  -->  Policy check  -->  Executor
                                                       |
                                                  DENY / ALLOW
                                                       |
                                              PermissionCallback
                                              (if sensitive op)

    For Claude SDK specifically, a Gateway Proxy MCP Server
    (otto.mcp_gateway_proxy) acts as the intermediary:

        Claude SDK --> stdio --> GatewayProxyServer --> gateway.request_tool()
                                                             |
                                                     Policy enforcement
                                                     Safeguard checks
                                                     Audit logging

    This ensures Claude SDK's native MCP connections are policy-enforced
    instead of connecting to MCP servers directly.

Security Invariants:
    1. SINGLE ENFORCEMENT POINT: All tool access goes through Gateway.
       Backends MUST NOT bypass the gateway to invoke tools directly.
    2. POLICY-FIRST: The gateway loads policy once from config. Every
       request is checked against the active policy before execution.
    3. DENY-BY-DEFAULT for unrecognized servers/tools (unless policy
       explicitly allows via allowlist or wildcard).
    4. SAFEGUARDS ARE NON-NEGOTIABLE: Default protected paths and blocked
       command patterns are always enforced, even when a tool is allowed
       by policy. Users can extend protections but cannot disable the
       catastrophic-prevention defaults without explicit opt-out.
    5. GATEWAY-LEVEL, NOT PER-CLIENT: Users define policy once in
       settings.yaml; all backends respect the same rules.

Config schema (settings.yaml):
    gateway:
      # Which MCP servers are available to agents
      servers:
        filesystem:
          enabled: true
          transport:
            type: stdio
            command: npx
            args: ["@modelcontextprotocol/server-filesystem", "/home/user"]
          # Tool filtering: which tools from this server are exposed
          # Omit or set to null for "all tools allowed"
          allowed_tools: [read_file, list_directory]
          blocked_tools: [write_file, delete_file]

        exa:
          enabled: true
          transport:
            type: http
            url: https://mcp.exa.ai/mcp

        otto:
          enabled: true
          # No transport needed -- built-in Otto tools
          builtin: true

      # Global path protections (merged with SafeguardConfig defaults)
      blocked_paths:
        - ~/.ssh
        - ~/.gnupg
        - /etc

      # Global blocked command patterns (merged with SafeguardConfig defaults)
      blocked_commands:
        - 'rm\\s+(-[rf]+\\s+)*(/\\s*$|/\\*)'

      # Permission callback behavior for sensitive operations
      permissions:
        # "auto" = allow with audit log
        # "prompt" = ask user via chat interface before allowing
        # "deny" = always deny
        file_write: auto
        file_delete: prompt
        shell_exec: auto
        network_access: auto

      # Audit logging
      audit:
        enabled: true
        log_allowed: true    # Log allowed operations (not just denials)
        log_tool_args: false # Don't log tool arguments (may contain secrets)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from abc import ABC, abstractmethod
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Protocol, runtime_checkable

from otto.policy import PolicyConfig, PolicyEngine, ToolVerdict
from otto.policy_ext import ExtendedPolicyEngine
from otto.safeguards import SafeguardConfig

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Core data types
# ---------------------------------------------------------------------------


class PolicyVerdict(Enum):
    """Result of a gateway policy check."""

    ALLOW = "allow"
    DENY = "deny"
    PROMPT = "prompt"  # Ask user before proceeding


# ---------------------------------------------------------------------------
# Agent behavior boundaries (Phase 4)
# ---------------------------------------------------------------------------


@dataclass
class AgentBoundaries:
    """
    Configurable boundaries for agent tool usage.

    Controls how many tool calls an agent can make per turn, per session,
    and enforces cooldown periods between calls to prevent runaway behavior.

    Config schema (settings.yaml):
        gateway:
          boundaries:
            max_calls_per_turn: 50       # Max tool calls in a single agent turn
            turn_timeout: 300            # Seconds before a turn is auto-expired
            cooldown_seconds: 0          # Min seconds between calls to same tool
            server_cooldowns:            # Per-server cooldown overrides
              filesystem: 0.5
              exa: 2.0
    """

    # Max tool calls per agent turn (0 = unlimited)
    max_calls_per_turn: int = 0
    # Seconds before a turn is considered expired (0 = no timeout)
    turn_timeout: int = 0
    # Global cooldown between calls to the same server.tool (seconds, 0 = none)
    cooldown_seconds: float = 0.0
    # Per-server cooldown overrides (server_name -> seconds)
    server_cooldowns: dict[str, float] = field(default_factory=dict)

    @classmethod
    def from_config(cls, config: dict[str, Any] | None) -> AgentBoundaries:
        """Load from settings.yaml gateway.boundaries section."""
        if not config:
            return cls()
        return cls(
            max_calls_per_turn=int(config.get("max_calls_per_turn", 0)),
            turn_timeout=int(config.get("turn_timeout", 0)),
            cooldown_seconds=float(config.get("cooldown_seconds", 0)),
            server_cooldowns={
                str(k): float(v) for k, v in (config.get("server_cooldowns") or {}).items()
            },
        )


class TurnTracker:
    """
    Track tool calls within agent turns for boundary enforcement.

    A "turn" is a burst of tool calls from a single agent invocation.
    The turn auto-resets after ``turn_timeout`` seconds of inactivity.
    """

    def __init__(self, boundaries: AgentBoundaries):
        self._boundaries = boundaries
        self._turn_count: int = 0
        self._turn_start: float = 0.0
        self._last_call: float = 0.0

    @property
    def turn_count(self) -> int:
        """Number of calls in the current turn."""
        self._maybe_reset_turn()
        return self._turn_count

    def check(self) -> bool:
        """Check if another call is allowed in this turn."""
        self._maybe_reset_turn()
        max_per_turn = self._boundaries.max_calls_per_turn
        if max_per_turn <= 0:
            return True
        return self._turn_count < max_per_turn

    def record(self) -> None:
        """Record a tool call in the current turn."""
        now = time.monotonic()
        if self._turn_count == 0:
            self._turn_start = now
        self._turn_count += 1
        self._last_call = now

    def reset(self) -> None:
        """Manually reset the turn counter."""
        self._turn_count = 0
        self._turn_start = 0.0
        self._last_call = 0.0

    def _maybe_reset_turn(self) -> None:
        """Auto-reset turn if timeout has elapsed since last call."""
        timeout = self._boundaries.turn_timeout
        if timeout <= 0 or self._turn_count == 0:
            return
        now = time.monotonic()
        if now - self._last_call > timeout:
            self.reset()


class CooldownTracker:
    """
    Enforce minimum time between tool calls to the same server/tool.

    Prevents rapid-fire repeated calls that could indicate runaway behavior.
    """

    def __init__(self, boundaries: AgentBoundaries):
        self._boundaries = boundaries
        # key -> last call timestamp (monotonic)
        self._last_calls: dict[str, float] = {}

    def check(self, server: str, tool: str) -> tuple[bool, float]:
        """
        Check if a call is allowed given cooldown constraints.

        Returns:
            (allowed, wait_seconds) — if not allowed, wait_seconds > 0
        """
        cooldown = self._boundaries.server_cooldowns.get(server, self._boundaries.cooldown_seconds)
        if cooldown <= 0:
            return True, 0.0

        key = f"{server}.{tool}"
        last = self._last_calls.get(key)
        if last is None:
            return True, 0.0

        elapsed = time.monotonic() - last
        if elapsed >= cooldown:
            return True, 0.0

        return False, cooldown - elapsed

    def record(self, server: str, tool: str) -> None:
        """Record a tool call timestamp."""
        key = f"{server}.{tool}"
        self._last_calls[key] = time.monotonic()

    def reset(self) -> None:
        """Clear all cooldown state."""
        self._last_calls.clear()


@dataclass(frozen=True)
class ToolRequest:
    """
    A request from a backend to invoke a tool through the gateway.

    This is the canonical input to the gateway's policy engine.

    Attributes:
        server: MCP server name (e.g., "filesystem", "exa", "otto")
        tool: Tool name within the server (e.g., "read_file", "write_file")
        arguments: Tool-specific arguments
        backend: Name of the requesting backend (e.g., "claude", "codex")
        context: Optional opaque context from the backend (session IDs, etc.)
    """

    server: str
    tool: str
    arguments: dict[str, Any] = field(default_factory=dict)
    backend: str = ""
    context: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ToolResponse:
    """
    Result returned by the gateway after tool execution.

    Attributes:
        success: Whether the tool executed successfully
        output: Tool output (text content)
        error: Error message if success is False
        verdict: The policy verdict that was applied
        audit_id: Unique ID for this operation in the audit log
    """

    success: bool
    output: str
    error: str | None = None
    verdict: PolicyVerdict = PolicyVerdict.ALLOW
    audit_id: str | None = None


@dataclass
class ServerPolicy:
    """
    Policy for a single MCP server.

    Defines which tools are accessible and how the server connects.

    Attributes:
        name: Server identifier
        enabled: Whether this server is active
        transport: Connection config (type, command/url, args, env, headers)
        builtin: True for Otto's built-in tools (no external transport)
        allowed_tools: Whitelist of tool names. None = all tools allowed.
        blocked_tools: Blacklist of tool names. Applied after allowed_tools.
    """

    name: str
    enabled: bool = True
    transport: dict[str, Any] = field(default_factory=dict)
    builtin: bool = False
    allowed_tools: list[str] | None = None
    blocked_tools: list[str] = field(default_factory=list)

    def is_tool_allowed(self, tool_name: str) -> bool:
        """
        Check if a specific tool is allowed by this server's policy.

        Rules applied in order:
        1. If server is disabled, nothing is allowed.
        2. If blocked_tools contains the tool, deny.
        3. If allowed_tools is set and tool is not in it, deny.
        4. Otherwise, allow.
        """
        if not self.enabled:
            return False
        if tool_name in self.blocked_tools:
            return False
        if self.allowed_tools is not None and tool_name not in self.allowed_tools:
            return False
        return True


@dataclass
class GatewayPolicy:
    """
    Complete gateway policy loaded from user configuration.

    This is the single source of truth for what agents can and cannot do.

    Attributes:
        servers: Map of server name -> ServerPolicy
        safeguards: SafeguardConfig for path/command protection
        permissions: Map of operation category -> PolicyVerdict
        audit_enabled: Whether to log operations
        audit_log_allowed: Whether to log allowed operations (not just denials)
        audit_log_tool_args: Whether to include tool arguments in audit log
        kill_switch: When True, ALL MCP access is instantly revoked
        allowed_paths: List of directory prefixes agents may access.
            If non-empty, file operations outside these directories are denied.
            Works as a complement to blocked_paths (safeguards): blocked_paths
            always deny, allowed_paths constrains what's reachable.
    """

    servers: dict[str, ServerPolicy] = field(default_factory=dict)
    safeguards: SafeguardConfig = field(default_factory=SafeguardConfig)
    permissions: dict[str, PolicyVerdict] = field(default_factory=dict)
    audit_enabled: bool = True
    audit_log_allowed: bool = True
    audit_log_tool_args: bool = False
    kill_switch: bool = False
    allowed_paths: list[str] = field(default_factory=list)
    # Rate limiting: max calls per minute per server (0 = unlimited)
    rate_limits: dict[str, int] = field(default_factory=dict)
    # Rate limiting per tool: "server.tool" -> max per minute (0 = unlimited)
    tool_rate_limits: dict[str, int] = field(default_factory=dict)
    # Budget/quota: max total tool calls per session (0 = unlimited)
    max_calls_per_session: int = 0
    # Dry-run: log tool calls but don't execute
    dry_run: bool = False
    # Granular tool policy configuration (Phase 3)
    policy_config: PolicyConfig = field(default_factory=PolicyConfig)
    # Agent behavior boundaries (Phase 4)
    boundaries: AgentBoundaries = field(default_factory=lambda: AgentBoundaries())

    @classmethod
    def from_config(cls, config: dict[str, Any] | None) -> GatewayPolicy:
        """
        Load gateway policy from settings.yaml gateway section.

        Args:
            config: The 'gateway' dict from settings.yaml, or None for defaults.

        Returns:
            Fully resolved GatewayPolicy with defaults applied.
        """
        if not config:
            return cls()

        # Parse servers (with catalog resolution)
        servers: dict[str, ServerPolicy] = {}
        for name, srv_conf in (config.get("servers") or {}).items():
            if not isinstance(srv_conf, dict):
                continue

            # Resolve from_catalog references
            if "from_catalog" in srv_conf:
                from otto.catalog import resolve_from_catalog

                srv_conf = resolve_from_catalog(name, srv_conf)

            servers[name] = ServerPolicy(
                name=name,
                enabled=srv_conf.get("enabled", True),
                transport=srv_conf.get("transport", {}),
                builtin=srv_conf.get("builtin", False),
                allowed_tools=srv_conf.get("allowed_tools"),
                blocked_tools=srv_conf.get("blocked_tools", []),
            )

        # Build safeguards from gateway config + defaults
        extra_paths = config.get("blocked_paths", [])
        extra_patterns = config.get("blocked_commands", [])
        safeguards = SafeguardConfig(
            enabled=True,
            protected_paths=extra_paths,  # SafeguardConfig merges with defaults
            blocked_patterns=extra_patterns,
        )

        # Parse permissions
        permission_map = {
            "auto": PolicyVerdict.ALLOW,
            "allow": PolicyVerdict.ALLOW,
            "prompt": PolicyVerdict.PROMPT,
            "deny": PolicyVerdict.DENY,
        }
        permissions: dict[str, PolicyVerdict] = {}
        for op, verdict_str in (config.get("permissions") or {}).items():
            verdict = permission_map.get(str(verdict_str).lower(), PolicyVerdict.ALLOW)
            permissions[op] = verdict

        # Audit config
        audit_conf = config.get("audit", {})

        # Kill switch — instant MCP revocation
        kill_switch = bool(config.get("kill_switch", False))

        # Allowed paths — constrain file access to these directories
        allowed_paths = config.get("allowed_paths", [])

        # Rate limits per server: {server_name: max_calls_per_minute}
        rate_limits: dict[str, int] = {}
        for name, srv_conf in (config.get("servers") or {}).items():
            if isinstance(srv_conf, dict):
                limit = srv_conf.get("max_calls_per_minute", 0)
                if limit and int(limit) > 0:
                    rate_limits[name] = int(limit)

        # Rate limits per tool: {"server.tool": max_calls_per_minute}
        tool_rate_limits: dict[str, int] = {}
        for name, srv_conf in (config.get("servers") or {}).items():
            if isinstance(srv_conf, dict):
                tool_limits = srv_conf.get("tool_rate_limits", {})
                for tool_name, limit in tool_limits.items():
                    if limit and int(limit) > 0:
                        tool_rate_limits[f"{name}.{tool_name}"] = int(limit)

        # Budget/quota: max total calls per session
        max_calls_per_session = int(config.get("max_calls_per_session", 0))

        # Dry-run mode
        dry_run = bool(config.get("dry_run", False))

        # Granular tool policy (Phase 3)
        policy_config = PolicyConfig.from_config(config.get("policy"))

        # Inherit recommended_policy from catalog entries (Phase 3, subtask 4)
        # Catalog policies act as defaults — user-defined server policies take precedence.
        from otto.policy import ServerToolPolicy as _STP

        for name, srv_conf in (config.get("servers") or {}).items():
            if not isinstance(srv_conf, dict):
                continue
            # Resolve catalog first so recommended_policy is available
            resolved = srv_conf
            if "from_catalog" in srv_conf:
                from otto.catalog import resolve_from_catalog

                resolved = resolve_from_catalog(name, srv_conf)
            rec = resolved.get("recommended_policy")
            if rec and isinstance(rec, dict) and name not in policy_config.servers:
                policy_config.servers[name] = _STP.from_config(rec)

        # Agent behavior boundaries (Phase 4)
        boundaries = AgentBoundaries.from_config(config.get("boundaries"))

        return cls(
            servers=servers,
            safeguards=safeguards,
            permissions=permissions,
            audit_enabled=audit_conf.get("enabled", True),
            audit_log_allowed=audit_conf.get("log_allowed", True),
            audit_log_tool_args=audit_conf.get("log_tool_args", False),
            kill_switch=kill_switch,
            allowed_paths=allowed_paths,
            rate_limits=rate_limits,
            tool_rate_limits=tool_rate_limits,
            max_calls_per_session=max_calls_per_session,
            dry_run=dry_run,
            policy_config=policy_config,
            boundaries=boundaries,
        )


# ---------------------------------------------------------------------------
# Callback protocols
# ---------------------------------------------------------------------------


@runtime_checkable
class PermissionCallback(Protocol):
    """
    Callback for prompting the user on sensitive operations.

    Implementations should present the operation to the user and return
    True (allow) or False (deny). This is used when a policy verdict
    is PROMPT.

    The gateway calls this when:
    - A tool invocation hits a permission rule set to "prompt"
    - A safeguard detects a potentially dangerous operation that the
      user may want to allow on a case-by-case basis
    """

    async def __call__(
        self,
        request: ToolRequest,
        reason: str,
    ) -> bool:
        """
        Ask the user whether to allow a tool invocation.

        Args:
            request: The tool request being evaluated
            reason: Human-readable explanation of why permission is needed

        Returns:
            True to allow, False to deny
        """
        ...


@runtime_checkable
class AuditCallback(Protocol):
    """
    Callback for audit logging of gateway operations.

    Implementations can log to file, database, or external service.
    The gateway calls this for every tool invocation (if audit is enabled).
    """

    async def __call__(
        self,
        request: ToolRequest,
        response: ToolResponse,
    ) -> None:
        """
        Record a tool invocation in the audit log.

        Args:
            request: The original tool request
            response: The gateway's response (includes verdict)
        """
        ...


# ---------------------------------------------------------------------------
# Gateway interface
# ---------------------------------------------------------------------------


class RateLimiter:
    """
    Sliding-window rate limiter for tool calls.

    Tracks timestamps of recent calls per key (server or server.tool)
    and enforces max-calls-per-minute limits.
    """

    def __init__(self) -> None:
        # key -> deque of timestamps (monotonic seconds)
        self._windows: dict[str, deque[float]] = defaultdict(deque)

    def check(self, key: str, max_per_minute: int) -> bool:
        """
        Check if a call is allowed under the rate limit.

        Returns True if allowed, False if rate-limited.
        Does NOT record the call — call ``record()`` after successful execution.
        """
        if max_per_minute <= 0:
            return True

        now = time.monotonic()
        window = self._windows[key]
        cutoff = now - 60.0

        # Purge old entries
        while window and window[0] < cutoff:
            window.popleft()

        return len(window) < max_per_minute

    def record(self, key: str) -> None:
        """Record a call for rate-limiting purposes."""
        self._windows[key].append(time.monotonic())

    def remaining(self, key: str, max_per_minute: int) -> int:
        """Return how many calls remain in the current window."""
        if max_per_minute <= 0:
            return -1  # unlimited

        now = time.monotonic()
        window = self._windows[key]
        cutoff = now - 60.0
        while window and window[0] < cutoff:
            window.popleft()

        return max(0, max_per_minute - len(window))


class QuotaTracker:
    """
    Session-level quota tracker.

    Enforces a hard cap on total tool calls per gateway lifetime (session).
    """

    def __init__(self, max_calls: int = 0) -> None:
        self._max = max_calls  # 0 = unlimited
        self._count = 0

    @property
    def count(self) -> int:
        return self._count

    @property
    def max_calls(self) -> int:
        return self._max

    @property
    def remaining(self) -> int:
        if self._max <= 0:
            return -1  # unlimited
        return max(0, self._max - self._count)

    def check(self) -> bool:
        """Return True if a call is allowed."""
        if self._max <= 0:
            return True
        return self._count < self._max

    def record(self) -> None:
        """Record a successful tool call."""
        self._count += 1


class Gateway(ABC):
    """
    The Security & Control Gateway -- Otto's trust boundary.

    This is the abstract interface that all gateway implementations must
    satisfy. It mediates ALL tool access from backends to external services.

    Backends interact with the gateway through two methods:
    - request_tool(): Submit a tool invocation for policy evaluation + execution
    - check_tool(): Pre-flight check whether a tool would be allowed (no execution)

    The gateway is initialized with a GatewayPolicy and optional callbacks.
    Policy is immutable after initialization -- to change policy, create a
    new gateway instance (this prevents mid-session policy drift).

    Subclasses:
    - LocalGateway: In-process gateway for direct tool execution
    - (Future) RemoteGateway: HTTP gateway for distributed setups
    """

    def __init__(
        self,
        policy: GatewayPolicy,
        permission_callback: PermissionCallback | None = None,
        audit_callback: AuditCallback | None = None,
    ):
        self._policy = policy
        self._permission_callback = permission_callback
        self._audit_callback = audit_callback
        self._rate_limiter = RateLimiter()
        self._quota = QuotaTracker(max_calls=policy.max_calls_per_session)
        self._policy_engine = PolicyEngine(policy.policy_config)
        # Extended policy engine with expression rules + plugins (Phase 5)
        self._extended_engine: ExtendedPolicyEngine | None = None
        # Agent boundaries (Phase 4)
        self._turn_tracker = TurnTracker(policy.boundaries)
        self._cooldown_tracker = CooldownTracker(policy.boundaries)
        # Runtime-paused servers (name -> True); not persisted to config
        self._paused_servers: dict[str, bool] = {}

    @property
    def policy(self) -> GatewayPolicy:
        """The active gateway policy. Read-only after initialization."""
        return self._policy

    @property
    def policy_engine(self) -> PolicyEngine:
        """The active policy engine. Read-only after initialization."""
        return self._policy_engine

    @property
    def extended_engine(self) -> ExtendedPolicyEngine | None:
        """The extended policy engine (expressions + plugins). None if not configured."""
        return self._extended_engine

    def enable_extended_policy(self, raw_config: dict[str, Any] | None = None) -> None:
        """
        Enable the extended policy engine with expression rules and plugins.

        Called during gateway setup when the policy config contains
        'rules', 'plugins', or 'packs' sections.
        """
        if raw_config is None:
            from otto.config import get_setting

            raw_config = get_setting("gateway.policy") or {}

        self._extended_engine = ExtendedPolicyEngine(raw_config)

    @property
    def turn_tracker(self) -> TurnTracker:
        """The agent turn tracker."""
        return self._turn_tracker

    @property
    def cooldown_tracker(self) -> CooldownTracker:
        """The tool cooldown tracker."""
        return self._cooldown_tracker

    @property
    def paused_servers(self) -> dict[str, bool]:
        """Map of runtime-paused server names."""
        return dict(self._paused_servers)

    def pause_server(self, server_name: str) -> bool:
        """
        Temporarily pause a server at runtime (no config change).

        Returns True if the server was found and paused.
        """
        if server_name in self._policy.servers:
            self._paused_servers[server_name] = True
            log.info("Server '%s' paused at runtime", server_name)
            return True
        return False

    def resume_server(self, server_name: str) -> bool:
        """
        Resume a runtime-paused server.

        Returns True if the server was paused and is now resumed.
        """
        if self._paused_servers.pop(server_name, None):
            log.info("Server '%s' resumed", server_name)
            return True
        return False

    def is_server_paused(self, server_name: str) -> bool:
        """Check if a server is currently paused."""
        return self._paused_servers.get(server_name, False)

    async def request_tool(self, request: ToolRequest) -> ToolResponse:
        """
        Submit a tool invocation through the gateway.

        This is the ONLY way backends should invoke tools. The method:
        1. Checks server allowlist (is this server known and enabled?)
        2. Checks tool filtering (is this tool allowed on this server?)
        3. Checks safeguards (path protection, command blocking)
        4. Checks permission policy (auto/prompt/deny for this operation category)
        5. If PROMPT, calls the permission callback
        6. If ALLOW, delegates to the executor
        7. Logs the operation via audit callback

        Args:
            request: The tool request to evaluate and potentially execute

        Returns:
            ToolResponse with the result or denial reason

        Security note:
            This method NEVER raises exceptions for policy denials.
            Denials are returned as ToolResponse(success=False, verdict=DENY).
            Only unexpected executor errors may raise.
        """
        # Step 0: Kill switch — instantly revoke ALL MCP access
        if self._policy.kill_switch:
            response = ToolResponse(
                success=False,
                output="",
                error="MCP access revoked: kill switch is active",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 0b: Runtime-paused server check
        if self.is_server_paused(request.server):
            response = ToolResponse(
                success=False,
                output="",
                error=f"Server '{request.server}' is temporarily paused",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 0c: Agent turn boundary check
        if not self._turn_tracker.check():
            max_per_turn = self._policy.boundaries.max_calls_per_turn
            response = ToolResponse(
                success=False,
                output="",
                error=f"Turn boundary exceeded: {self._turn_tracker.turn_count}/{max_per_turn} calls this turn",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 0d: Cooldown check
        cd_allowed, cd_wait = self._cooldown_tracker.check(request.server, request.tool)
        if not cd_allowed:
            response = ToolResponse(
                success=False,
                output="",
                error=f"Cooldown active for {request.server}.{request.tool}: wait {cd_wait:.1f}s",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 1: Server allowlist
        server_policy = self._policy.servers.get(request.server)
        if server_policy is None:
            response = ToolResponse(
                success=False,
                output="",
                error=f"Server '{request.server}' is not in the allowlist",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        if not server_policy.enabled:
            response = ToolResponse(
                success=False,
                output="",
                error=f"Server '{request.server}' is disabled",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 2: Tool filtering
        if not server_policy.is_tool_allowed(request.tool):
            response = ToolResponse(
                success=False,
                output="",
                error=f"Tool '{request.tool}' is not allowed on server '{request.server}'",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 2.5: Granular tool policy evaluation (Phase 3 + Phase 5)
        # Use extended engine (expressions + plugins) if available,
        # otherwise fall back to standard engine.
        if self._extended_engine is not None:
            policy_result = self._extended_engine.evaluate(
                request.server, request.tool, request.arguments
            )
        else:
            policy_result = self._policy_engine.evaluate(
                request.server, request.tool, request.arguments
            )

        # Argument validation errors are always a hard deny
        if policy_result.arg_errors:
            response = ToolResponse(
                success=False,
                output="",
                error=f"Policy argument validation failed: {'; '.join(policy_result.arg_errors)}",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Policy engine deny verdict
        if policy_result.verdict == ToolVerdict.DENY:
            response = ToolResponse(
                success=False,
                output="",
                error=f"Denied by tool policy: {policy_result.reason}",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Policy engine rate limit (applies alongside legacy rate limits)
        if policy_result.rate_limit > 0:
            rl_key = f"policy.{request.server}.{request.tool}"
            if not self._rate_limiter.check(rl_key, policy_result.rate_limit):
                response = ToolResponse(
                    success=False,
                    output="",
                    error=f"Rate limited by tool policy: {request.server}.{request.tool} "
                    f"({policy_result.rate_limit}/min)",
                    verdict=PolicyVerdict.DENY,
                )
                await self._audit(request, response)
                return response

        # Step 3: Safeguard checks
        denial = self._check_safeguards(request)
        if denial is not None:
            await self._audit(request, denial)
            return denial

        # Step 4: Permission policy
        # Policy engine ASK verdict upgrades to PROMPT
        if policy_result.verdict == ToolVerdict.ASK:
            verdict = PolicyVerdict.PROMPT
        else:
            op_category = self._classify_operation(request)
            verdict = self._policy.permissions.get(op_category, PolicyVerdict.ALLOW)

        if verdict == PolicyVerdict.DENY:
            response = ToolResponse(
                success=False,
                output="",
                error=f"Operation category '{self._classify_operation(request)}' is denied by policy",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 5: Prompt user if needed
        if verdict == PolicyVerdict.PROMPT:
            if self._permission_callback is not None:
                reason = (
                    policy_result.reason
                    if policy_result.verdict == ToolVerdict.ASK
                    else (
                        f"Tool '{request.tool}' on '{request.server}' requires permission "
                        f"(category: {self._classify_operation(request)})"
                    )
                )
                allowed = await self._permission_callback(
                    request,
                    reason=reason,
                )
                if not allowed:
                    response = ToolResponse(
                        success=False,
                        output="",
                        error="User denied permission",
                        verdict=PolicyVerdict.DENY,
                    )
                    await self._audit(request, response)
                    return response
            else:
                # No callback available -- deny for safety
                response = ToolResponse(
                    success=False,
                    output="",
                    error="Operation requires permission but no callback is registered",
                    verdict=PolicyVerdict.DENY,
                )
                await self._audit(request, response)
                return response

        # Step 5b: Rate limiting per server
        server_limit = self._policy.rate_limits.get(request.server, 0)
        if server_limit > 0 and not self._rate_limiter.check(request.server, server_limit):
            response = ToolResponse(
                success=False,
                output="",
                error=f"Rate limited: server '{request.server}' exceeds {server_limit} calls/min",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 5c: Rate limiting per tool
        tool_key = f"{request.server}.{request.tool}"
        tool_limit = self._policy.tool_rate_limits.get(tool_key, 0)
        if tool_limit > 0 and not self._rate_limiter.check(tool_key, tool_limit):
            response = ToolResponse(
                success=False,
                output="",
                error=f"Rate limited: tool '{tool_key}' exceeds {tool_limit} calls/min",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 5d: Session quota check
        if not self._quota.check():
            response = ToolResponse(
                success=False,
                output="",
                error=f"Session quota exhausted: {self._quota.count}/{self._quota.max_calls} calls used",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 6: Dry-run mode — log but don't execute
        if self._policy.dry_run:
            response = ToolResponse(
                success=True,
                output=f"[DRY RUN] Would execute {request.server}.{request.tool}",
                verdict=PolicyVerdict.ALLOW,
            )
            await self._audit(request, response)
            return response

        # Step 7: Execute
        response = await self._execute(request, server_policy)

        # Record rate limit + quota + boundaries after successful execution
        if server_limit > 0:
            self._rate_limiter.record(request.server)
        if tool_limit > 0:
            self._rate_limiter.record(tool_key)
        if policy_result.rate_limit > 0:
            rl_key = f"policy.{request.server}.{request.tool}"
            self._rate_limiter.record(rl_key)
        self._quota.record()
        self._turn_tracker.record()
        self._cooldown_tracker.record(request.server, request.tool)

        # Step 8: Audit
        await self._audit(request, response)

        return response

    async def check_tool(self, request: ToolRequest) -> PolicyVerdict:
        """
        Pre-flight check: would this tool request be allowed?

        Does NOT execute the tool. Useful for backends that want to
        know ahead of time whether a tool call would succeed before
        committing to it (e.g., for SDK permission callbacks).

        Args:
            request: The tool request to evaluate

        Returns:
            PolicyVerdict indicating whether the request would be allowed
        """
        if self._policy.kill_switch:
            return PolicyVerdict.DENY

        server_policy = self._policy.servers.get(request.server)
        if server_policy is None or not server_policy.enabled:
            return PolicyVerdict.DENY

        if not server_policy.is_tool_allowed(request.tool):
            return PolicyVerdict.DENY

        # Granular tool policy (Phase 3 + Phase 5)
        if self._extended_engine is not None:
            policy_result = self._extended_engine.evaluate(
                request.server, request.tool, request.arguments
            )
        else:
            policy_result = self._policy_engine.evaluate(
                request.server, request.tool, request.arguments
            )
        if policy_result.denied:
            return PolicyVerdict.DENY
        if policy_result.needs_prompt:
            return PolicyVerdict.PROMPT

        denial = self._check_safeguards(request)
        if denial is not None:
            return PolicyVerdict.DENY

        op_category = self._classify_operation(request)
        return self._policy.permissions.get(op_category, PolicyVerdict.ALLOW)

    def get_server_tools(self, server_name: str) -> list[str] | None:
        """
        Get the list of allowed tools for a server.

        Returns None if the server allows all tools (no whitelist).
        Returns empty list if server is disabled or not found.

        Args:
            server_name: The MCP server name

        Returns:
            List of allowed tool names, None for "all", or [] for "none"
        """
        policy = self._policy.servers.get(server_name)
        if policy is None or not policy.enabled:
            return []
        return policy.allowed_tools  # None means all tools

    def list_servers(self) -> dict[str, ServerPolicy]:
        """Return all configured server policies."""
        return dict(self._policy.servers)

    def get_mcp_server_configs(self) -> dict[str, dict[str, Any]]:
        """
        Export MCP server transport configs for backend consumption.

        Returns a dict suitable for passing to Claude SDK's mcp_servers
        option or Codex's MCP config. Only includes enabled, non-builtin
        servers with transport configuration.

        Returns:
            Dict mapping server name -> transport config dict
        """
        configs: dict[str, dict[str, Any]] = {}
        for name, policy in self._policy.servers.items():
            if not policy.enabled:
                continue
            if policy.builtin:
                continue
            if not policy.transport:
                continue
            configs[name] = dict(policy.transport)
        return configs

    # -----------------------------------------------------------------------
    # Internal methods
    # -----------------------------------------------------------------------

    def _check_safeguards(self, request: ToolRequest) -> ToolResponse | None:
        """
        Check safeguards (path protection, command blocking, allowed paths).

        Returns a DENY ToolResponse if safeguards block the request,
        or None if the request passes all checks.
        """
        safeguards = self._policy.safeguards

        # Check path protection for file operations
        file_path = (
            request.arguments.get("file_path")
            or request.arguments.get("path")
            or request.arguments.get("file")
        )
        if file_path:
            # Blocked paths always deny (standard safeguards)
            if safeguards.is_path_protected(str(file_path)):
                return ToolResponse(
                    success=False,
                    output="",
                    error=f"Protected path: {file_path}",
                    verdict=PolicyVerdict.DENY,
                )

            # Allowed paths — if configured, restrict to these directories
            if self._policy.allowed_paths:
                if not self._is_path_within_allowed(str(file_path)):
                    return ToolResponse(
                        success=False,
                        output="",
                        error=f"Path outside allowed directories: {file_path}",
                        verdict=PolicyVerdict.DENY,
                    )

        # Check command blocking for shell operations
        command = request.arguments.get("command") or request.arguments.get("cmd")
        if command:
            blocked, pattern = safeguards.is_command_blocked(str(command))
            if blocked:
                return ToolResponse(
                    success=False,
                    output="",
                    error=f"Blocked command pattern: {pattern}",
                    verdict=PolicyVerdict.DENY,
                )

        return None

    def _is_path_within_allowed(self, file_path: str) -> bool:
        """
        Check if a path falls within one of the allowed directories.

        Returns True if allowed_paths is empty (no restriction) or
        if the path is under at least one allowed directory.
        """
        from pathlib import Path as _Path

        if not self._policy.allowed_paths:
            return True

        try:
            target = _Path(file_path).expanduser().resolve()
        except (ValueError, OSError):
            return False

        for allowed in self._policy.allowed_paths:
            try:
                allowed_path = _Path(allowed).expanduser().resolve()
                if target == allowed_path or allowed_path in target.parents:
                    return True
            except (ValueError, OSError):
                continue

        return False

    @staticmethod
    def _classify_operation(request: ToolRequest) -> str:
        """
        Classify a tool request into an operation category for permission lookup.

        Categories:
        - file_write: Tools that modify the filesystem
        - file_delete: Tools that remove files
        - shell_exec: Shell/command execution
        - network_access: HTTP requests, web searches, API calls

        Returns:
            Operation category string matching permissions config keys
        """
        tool = request.tool.lower()

        # File write operations
        if tool in ("write_file", "edit_file", "write", "edit", "multiedit", "patch"):
            return "file_write"

        # File delete operations
        if tool in ("delete_file", "remove", "unlink"):
            return "file_delete"

        # Shell execution
        if tool in ("bash", "shell", "exec", "commandexecution", "run_command"):
            return "shell_exec"

        # Network access
        if tool in ("web_search", "fetch", "http_request", "websearch", "webfetch"):
            return "network_access"

        # Default: no special permission needed
        return "general"

    @abstractmethod
    async def _execute(self, request: ToolRequest, server_policy: ServerPolicy) -> ToolResponse:
        """
        Execute a tool request that has passed all policy checks.

        Subclasses implement the actual MCP server communication here.

        Args:
            request: The validated tool request
            server_policy: The server's policy (includes transport config)

        Returns:
            ToolResponse with execution result
        """
        ...

    async def _audit(self, request: ToolRequest, response: ToolResponse) -> None:
        """Log the operation via the audit callback and SQLite audit DB."""
        if not self._policy.audit_enabled:
            return

        # Skip logging allowed operations if configured
        if response.verdict == PolicyVerdict.ALLOW and not self._policy.audit_log_allowed:
            return

        # Always write to structured SQLite audit log
        from otto.audit import log_tool_call

        log_tool_call(
            server=request.server,
            tool=request.tool,
            verdict=response.verdict.value,
            backend=request.backend or None,
            success=response.success,
            error=response.error,
            arguments=request.arguments if self._policy.audit_log_tool_args else None,
            dry_run=self._policy.dry_run,
        )

        if self._audit_callback is not None:
            try:
                await self._audit_callback(request, response)
            except Exception:
                log.warning("Audit callback failed", exc_info=True)
        else:
            # Default: log to Python logger
            level = logging.INFO if response.verdict == PolicyVerdict.ALLOW else logging.WARNING
            args_str = ""
            if self._policy.audit_log_tool_args:
                args_str = f" args={request.arguments}"
            log.log(
                level,
                "gateway: %s %s.%s [%s] backend=%s%s%s",
                response.verdict.value.upper(),
                request.server,
                request.tool,
                response.error or "ok",
                request.backend,
                args_str,
                f" audit_id={response.audit_id}" if response.audit_id else "",
            )


# ---------------------------------------------------------------------------
# Convenience: load gateway from Otto's config
# ---------------------------------------------------------------------------


def load_gateway_policy() -> GatewayPolicy:
    """
    Load the gateway policy from Otto's settings.yaml.

    Reads the 'gateway' section from settings and constructs a
    GatewayPolicy. If no gateway config exists, returns defaults
    (all safeguards active, no servers configured).

    Returns:
        GatewayPolicy ready for Gateway initialization
    """
    from otto.config import get_setting

    gateway_config = get_setting("gateway")
    return GatewayPolicy.from_config(gateway_config)


# ---------------------------------------------------------------------------
# Stdio transport: JSON-RPC 2.0 over subprocess
# ---------------------------------------------------------------------------

_MCP_PROTOCOL_VERSION = "2024-11-05"
_MCP_CLIENT_INFO = {"name": "otto", "version": "1.0"}
_DEFAULT_TOOL_TIMEOUT = 30.0  # seconds
_PROCESS_SHUTDOWN_TIMEOUT = 5.0  # seconds


class StdioConnection:
    """
    JSON-RPC 2.0 connection to an MCP server over stdio.

    Spawns the server as a subprocess and communicates via stdin/stdout.
    Handles the MCP initialize handshake and provides ``call_tool()`` for
    tool invocations.

    Adapted from ``otto.backends.codex.JsonRpcConnection`` with MCP-specific
    protocol additions (initialize handshake, tools/call method, content
    array response format).
    """

    def __init__(self, proc: asyncio.subprocess.Process, server_name: str):
        self._proc = proc
        self._server_name = server_name
        self._request_id = 0
        self._pending: dict[int, asyncio.Future[dict[str, Any]]] = {}
        self._reader_task: asyncio.Task[None] | None = None
        self._closed = False
        self._initialized = False

    @classmethod
    async def connect(
        cls,
        server_name: str,
        command: str,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
    ) -> StdioConnection:
        """
        Spawn an MCP server subprocess and perform the initialize handshake.

        Args:
            server_name: Identifier for logging/pooling
            command: Executable to run
            args: Command-line arguments
            env: Extra environment variables (merged with current env)

        Returns:
            Ready-to-use StdioConnection

        Raises:
            RuntimeError: If the subprocess fails to start or handshake fails
        """
        full_env = dict(os.environ)
        if env:
            full_env.update(env)

        try:
            proc = await asyncio.create_subprocess_exec(
                command,
                *(args or []),
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=full_env,
            )
        except (FileNotFoundError, PermissionError, OSError) as exc:
            raise RuntimeError(f"Failed to start MCP server '{server_name}': {exc}") from exc

        conn = cls(proc, server_name)
        conn._reader_task = asyncio.create_task(conn._read_loop())
        await conn._initialize()
        return conn

    @property
    def alive(self) -> bool:
        """Whether the subprocess is still running."""
        return not self._closed and self._proc.returncode is None

    async def _read_loop(self) -> None:
        """Route JSON-RPC responses to pending futures."""
        assert self._proc.stdout is not None

        while not self._closed:
            try:
                line = await self._proc.stdout.readline()
                if not line:
                    log.debug("EOF from MCP server '%s'", self._server_name)
                    break

                line_str = line.decode(errors="replace").strip()
                if not line_str:
                    continue

                if not line_str.startswith("{"):
                    log.debug(
                        "Non-JSON from MCP server '%s': %s",
                        self._server_name,
                        line_str[:200],
                    )
                    continue

                try:
                    msg = json.loads(line_str)
                except json.JSONDecodeError:
                    log.warning(
                        "Invalid JSON from MCP server '%s': %s",
                        self._server_name,
                        line_str[:100],
                    )
                    continue

                if not isinstance(msg, dict):
                    continue

                if "id" in msg:
                    request_id = msg["id"]
                    future = self._pending.pop(request_id, None)
                    if future and not future.done():
                        if "error" in msg:
                            future.set_exception(
                                RuntimeError(msg["error"].get("message", str(msg["error"])))
                            )
                        else:
                            future.set_result(msg.get("result", {}))
                # Notifications from the server are logged but not queued
                # (we don't need them for tool calls)

            except asyncio.CancelledError:
                break
            except Exception:
                log.debug(
                    "Error reading from MCP server '%s'",
                    self._server_name,
                    exc_info=True,
                )
                break

    async def send_request(
        self, method: str, params: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Send a JSON-RPC request and await the response."""
        if self._closed or self._proc.returncode is not None:
            raise RuntimeError(f"Connection to '{self._server_name}' is closed")

        self._request_id += 1
        request_id = self._request_id
        request = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
            "params": params or {},
        }

        loop = asyncio.get_running_loop()
        future: asyncio.Future[dict[str, Any]] = loop.create_future()
        self._pending[request_id] = future

        assert self._proc.stdin is not None
        try:
            self._proc.stdin.write(json.dumps(request).encode() + b"\n")
            await self._proc.stdin.drain()
        except Exception as exc:
            self._pending.pop(request_id, None)
            raise RuntimeError(f"Failed to send to '{self._server_name}': {exc}") from exc

        return await future

    async def send_notification(self, method: str, params: dict[str, Any] | None = None) -> None:
        """Send a JSON-RPC notification (no response expected)."""
        if self._closed or self._proc.returncode is not None:
            raise RuntimeError(f"Connection to '{self._server_name}' is closed")

        msg = {"jsonrpc": "2.0", "method": method, "params": params or {}}

        assert self._proc.stdin is not None
        self._proc.stdin.write(json.dumps(msg).encode() + b"\n")
        await self._proc.stdin.drain()

    async def _initialize(self) -> None:
        """Perform the MCP initialize handshake."""
        result = await self.send_request(
            "initialize",
            {
                "protocolVersion": _MCP_PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": _MCP_CLIENT_INFO,
            },
        )
        log.debug(
            "MCP server '%s' initialized: %s",
            self._server_name,
            result.get("serverInfo", {}),
        )
        await self.send_notification("notifications/initialized")
        self._initialized = True

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any],
        timeout: float = _DEFAULT_TOOL_TIMEOUT,
    ) -> dict[str, Any]:
        """
        Invoke a tool on the MCP server.

        Args:
            name: Tool name
            arguments: Tool arguments
            timeout: Seconds to wait for response

        Returns:
            MCP result dict (typically has "content" array)

        Raises:
            RuntimeError: On communication failure
            asyncio.TimeoutError: If tool doesn't respond in time
        """
        return await asyncio.wait_for(
            self.send_request("tools/call", {"name": name, "arguments": arguments}),
            timeout=timeout,
        )

    async def close(self) -> None:
        """Gracefully shut down the connection and subprocess."""
        self._closed = True

        if self._reader_task:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass

        for future in self._pending.values():
            if not future.done():
                future.cancel()
        self._pending.clear()

        if self._proc.returncode is None:
            self._proc.terminate()
            try:
                await asyncio.wait_for(self._proc.wait(), timeout=_PROCESS_SHUTDOWN_TIMEOUT)
            except asyncio.TimeoutError:
                self._proc.kill()
                await self._proc.wait()


# ---------------------------------------------------------------------------
# LocalGateway: concrete in-process gateway
# ---------------------------------------------------------------------------


def _extract_mcp_text(result: dict[str, Any]) -> str:
    """
    Extract text output from an MCP tools/call result.

    MCP results have a ``content`` array of typed blocks. This extracts
    and concatenates all text blocks.
    """
    content = result.get("content")
    if content is None or not isinstance(content, list):
        # Some servers return a plain string or dict
        if isinstance(result, str):
            return result
        return json.dumps(result) if result else ""
    if not content:
        return ""

    parts: list[str] = []
    for block in content:
        if isinstance(block, dict) and block.get("type") == "text":
            parts.append(block.get("text", ""))
        elif isinstance(block, str):
            parts.append(block)
    return "\n".join(parts) if parts else json.dumps(content)


class LocalGateway(Gateway):
    """
    In-process gateway that communicates with MCP servers directly.

    Handles three transport types:
    - **stdio**: Launches MCP server as subprocess, communicates via JSON-RPC
    - **http/sse**: Connects to remote MCP server via HTTP (stub, not yet needed)
    - **builtin**: Routes to Otto's built-in tools (no subprocess)

    Maintains a connection pool for stdio servers to reuse processes across
    tool calls. Dead connections are detected and replaced automatically.

    Usage::

        policy = load_gateway_policy()
        gw = LocalGateway(policy, permission_callback=my_cb)
        response = await gw.request_tool(ToolRequest(
            server="filesystem", tool="read_file",
            arguments={"path": "/tmp/test.txt"},
        ))
        await gw.close()  # cleanup when done
    """

    def __init__(
        self,
        policy: GatewayPolicy,
        permission_callback: PermissionCallback | None = None,
        audit_callback: AuditCallback | None = None,
    ):
        super().__init__(policy, permission_callback, audit_callback)
        self._connections: dict[str, StdioConnection] = {}
        self._builtin_executors: dict[str, Any] | None = None
        self._tool_cache: dict[str, list[dict[str, Any]]] = {}

    async def _execute(self, request: ToolRequest, server_policy: ServerPolicy) -> ToolResponse:
        """
        Execute a tool request by routing to the appropriate transport.

        This method only runs AFTER all policy checks have passed.
        """
        try:
            if server_policy.builtin:
                return await self._execute_builtin(request)

            transport_type = server_policy.transport.get("type", "").lower()

            if transport_type == "stdio":
                return await self._execute_stdio(request, server_policy)
            elif transport_type in ("http", "sse"):
                return await self._execute_http(request, server_policy)
            else:
                return ToolResponse(
                    success=False,
                    output="",
                    error=f"Unknown transport type: '{transport_type}' "
                    f"for server '{server_policy.name}'",
                    verdict=PolicyVerdict.ALLOW,
                )
        except Exception as exc:
            log.error(
                "Gateway execute error for %s.%s: %s",
                request.server,
                request.tool,
                exc,
                exc_info=True,
            )
            return ToolResponse(
                success=False,
                output="",
                error=str(exc),
                verdict=PolicyVerdict.ALLOW,
            )

    async def _execute_builtin(self, request: ToolRequest) -> ToolResponse:
        """Route to Otto's built-in MCP tools."""
        if self._builtin_executors is None:
            from otto.tools.schemas import get_mcp_tool_executors

            self._builtin_executors = get_mcp_tool_executors()

        executor = self._builtin_executors.get(request.tool)
        if executor is None:
            return ToolResponse(
                success=False,
                output="",
                error=f"Unknown builtin tool: '{request.tool}'",
                verdict=PolicyVerdict.ALLOW,
            )

        result = await executor(**request.arguments)

        if isinstance(result, dict):
            success = result.get("success", True)
            if success:
                data = result.get("data")
                output = json.dumps(data) if data is not None else ""
            else:
                output = ""
            return ToolResponse(
                success=success,
                output=output,
                error=result.get("error") if not success else None,
                verdict=PolicyVerdict.ALLOW,
            )

        return ToolResponse(
            success=True,
            output=str(result) if result else "",
            verdict=PolicyVerdict.ALLOW,
        )

    async def _execute_stdio(
        self, request: ToolRequest, server_policy: ServerPolicy
    ) -> ToolResponse:
        """Execute via stdio MCP server with connection pooling."""
        conn = await self._get_connection(server_policy)

        timeout = float(server_policy.transport.get("timeout", _DEFAULT_TOOL_TIMEOUT))

        try:
            result = await conn.call_tool(request.tool, request.arguments, timeout)
        except (RuntimeError, asyncio.TimeoutError) as exc:
            # Connection may be dead -- try once with a fresh connection
            if not conn.alive:
                log.warning("MCP server '%s' died, reconnecting...", server_policy.name)
                await self._close_connection(server_policy.name)
                conn = await self._get_connection(server_policy)
                try:
                    result = await conn.call_tool(request.tool, request.arguments, timeout)
                except Exception as retry_exc:
                    return ToolResponse(
                        success=False,
                        output="",
                        error=f"MCP server '{server_policy.name}' retry failed: {retry_exc}",
                        verdict=PolicyVerdict.ALLOW,
                    )
            else:
                return ToolResponse(
                    success=False,
                    output="",
                    error=f"MCP server '{server_policy.name}' error: {exc}",
                    verdict=PolicyVerdict.ALLOW,
                )

        # Check for MCP-level isError flag
        is_error = result.get("isError", False)
        text = _extract_mcp_text(result)

        return ToolResponse(
            success=not is_error,
            output=text if not is_error else "",
            error=text if is_error else None,
            verdict=PolicyVerdict.ALLOW,
        )

    async def _execute_http(
        self, request: ToolRequest, server_policy: ServerPolicy
    ) -> ToolResponse:
        """HTTP/SSE transport stub."""
        return ToolResponse(
            success=False,
            output="",
            error=f"HTTP/SSE transport not yet implemented for server '{server_policy.name}'",
            verdict=PolicyVerdict.ALLOW,
        )

    async def _get_connection(self, server_policy: ServerPolicy) -> StdioConnection:
        """
        Get or create a stdio connection for a server.

        Reuses existing connections. If the existing connection is dead,
        closes it and creates a fresh one.
        """
        name = server_policy.name
        conn = self._connections.get(name)

        if conn is not None and conn.alive:
            return conn

        # Close dead connection if present
        if conn is not None:
            await self._close_connection(name)

        transport = server_policy.transport
        command = transport.get("command")
        if not command:
            raise RuntimeError(f"No command configured for stdio server '{name}'")

        args = transport.get("args", [])
        env = transport.get("env")

        conn = await StdioConnection.connect(name, command, args, env)
        self._connections[name] = conn
        return conn

    async def _close_connection(self, server_name: str) -> None:
        """Close and remove a single connection from the pool."""
        conn = self._connections.pop(server_name, None)
        if conn is not None:
            try:
                await conn.close()
            except Exception:
                log.debug("Error closing connection to '%s'", server_name, exc_info=True)

    async def list_tools(self, server_name: str) -> list[dict[str, Any]]:
        """
        Fetch the tools/list from an MCP server.

        Returns the raw MCP tool list (array of tool descriptors).
        Results are cached per server for the lifetime of this gateway.

        Args:
            server_name: Name of the MCP server

        Returns:
            List of MCP tool descriptors (name, description, inputSchema)

        Raises:
            RuntimeError: If the server is unknown, disabled, or has no transport
        """
        if server_name in self._tool_cache:
            return self._tool_cache[server_name]

        server_policy = self._policy.servers.get(server_name)
        if server_policy is None:
            raise RuntimeError(f"Unknown server: '{server_name}'")
        if not server_policy.enabled:
            raise RuntimeError(f"Server '{server_name}' is disabled")
        if server_policy.builtin:
            # Builtin tools are handled via Otto's tool registry, not MCP
            raise RuntimeError(f"Server '{server_name}' is builtin (use tool registry)")
        if not server_policy.transport:
            raise RuntimeError(f"Server '{server_name}' has no transport config")

        transport_type = server_policy.transport.get("type", "").lower()
        if transport_type != "stdio":
            raise RuntimeError(f"list_tools only supports stdio transport, got '{transport_type}'")

        conn = await self._get_connection(server_policy)
        result = await conn.send_request("tools/list", {})
        tools = result.get("tools", [])

        # Filter through server policy
        filtered = []
        for tool in tools:
            tool_name = tool.get("name", "")
            if server_policy.is_tool_allowed(tool_name):
                filtered.append(tool)

        self._tool_cache[server_name] = filtered
        return filtered

    async def get_server_tool_schemas(self, server_name: str) -> list[dict[str, Any]]:
        """
        Get OpenAI-format tool schemas for an MCP server's tools.

        Fetches tools/list from the server, filters through policy, and
        converts to OpenAI function-calling format. Cached per server.

        Args:
            server_name: Name of the MCP server

        Returns:
            List of OpenAI-format tool schemas ready for LLM consumption
        """
        mcp_tools = await self.list_tools(server_name)

        schemas: list[dict[str, Any]] = []
        for tool in mcp_tools:
            schema = {
                "type": "function",
                "function": {
                    "name": f"{server_name}__{tool['name']}",
                    "description": tool.get("description", ""),
                    "parameters": tool.get("inputSchema", {"type": "object", "properties": {}}),
                },
            }
            schemas.append(schema)

        return schemas

    async def close(self) -> None:
        """Close all MCP server connections. Call on shutdown."""
        names = list(self._connections.keys())
        for name in names:
            await self._close_connection(name)


# ---------------------------------------------------------------------------
# Gateway singleton
# ---------------------------------------------------------------------------

_gateway: LocalGateway | None = None


def _maybe_enable_extended_policy(gw: LocalGateway) -> None:
    """Enable extended policy engine if rules/plugins/packs are configured."""
    from otto.config import get_setting

    policy_raw = get_setting("gateway.policy") or {}
    has_rules = bool(policy_raw.get("rules"))
    has_plugins = bool(policy_raw.get("plugins", {}).get("enabled", False))
    has_packs = bool(policy_raw.get("packs"))

    if has_rules or has_plugins or has_packs:
        gw.enable_extended_policy(policy_raw)
        log.info(
            "Extended policy engine enabled: rules=%s, plugins=%s, packs=%s",
            has_rules,
            has_plugins,
            has_packs,
        )


_gateway_lock = asyncio.Lock()


def get_gateway() -> LocalGateway:
    """
    Get the module-level gateway singleton.

    Lazily initializes from settings.yaml on first call. Thread-safe
    (though typically called from a single async event loop).

    The gateway is initialized with a TelegramPermissionCallback so that
    PROMPT verdicts send approval buttons to Telegram.

    Returns:
        The shared LocalGateway instance.
    """
    global _gateway
    if _gateway is None:
        policy = load_gateway_policy()
        _gateway = LocalGateway(
            policy,
            permission_callback=MultiPlatformPermissionCallback(),
        )
        # Enable extended policy engine if rules/plugins/packs are configured
        _maybe_enable_extended_policy(_gateway)
        log.info(
            "Gateway initialized: %d server(s), kill_switch=%s, dry_run=%s, quota=%s",
            len(policy.servers),
            policy.kill_switch,
            policy.dry_run,
            policy.max_calls_per_session or "unlimited",
        )
    return _gateway


async def close_gateway() -> None:
    """Close the gateway singleton and release all connections."""
    global _gateway
    if _gateway is not None:
        await _gateway.close()
        _gateway = None
        log.info("Gateway closed")


def reload_gateway() -> LocalGateway:
    """
    Reload gateway policy from settings.yaml and create a new instance.

    Useful for SIGHUP config reload. The old gateway is NOT closed here --
    callers should ``await close_gateway()`` first if the old instance
    has active connections.

    Returns:
        The new LocalGateway instance (also stored as singleton).
    """
    global _gateway
    policy = load_gateway_policy()
    _gateway = LocalGateway(
        policy,
        permission_callback=MultiPlatformPermissionCallback(),
    )
    # Enable extended policy engine if rules/plugins/packs are configured
    _maybe_enable_extended_policy(_gateway)
    log.info(
        "Gateway reloaded: %d server(s), kill_switch=%s, dry_run=%s, quota=%s",
        len(policy.servers),
        policy.kill_switch,
        policy.dry_run,
        policy.max_calls_per_session or "unlimited",
    )
    return _gateway


def activate_kill_switch() -> None:
    """
    Activate the MCP kill switch — instantly revoke ALL tool access.

    This persists to settings.yaml AND takes effect immediately on the
    in-memory gateway singleton. All subsequent tool requests are denied.
    """
    from otto.config import set_setting

    set_setting("gateway.kill_switch", True)
    gw = get_gateway()
    gw._policy.kill_switch = True
    log.warning("MCP KILL SWITCH ACTIVATED — all tool access revoked")


def deactivate_kill_switch() -> None:
    """
    Deactivate the MCP kill switch — restore normal tool access.

    Clears the kill_switch flag in settings.yaml and on the
    in-memory gateway singleton.
    """
    from otto.config import set_setting

    set_setting("gateway.kill_switch", False)
    gw = get_gateway()
    gw._policy.kill_switch = False
    log.info("MCP kill switch deactivated — tool access restored")


def is_kill_switch_active() -> bool:
    """Check if the MCP kill switch is currently active."""
    return get_gateway()._policy.kill_switch


# ---------------------------------------------------------------------------
# Telegram permission callback — wires PROMPT verdicts to Telegram buttons
# ---------------------------------------------------------------------------


class TelegramPermissionCallback:
    """
    Permission callback that sends Telegram inline-keyboard buttons
    and waits for the user to approve or deny.

    Uses Otto's send_buttons MCP tool to render the approval UI and
    polls for the callback response.
    """

    _pending: dict[str, asyncio.Future[bool]] = {}

    def __init__(self, timeout: float = 120.0):
        self._timeout = timeout

    async def __call__(self, request: ToolRequest, reason: str) -> bool:
        """Send approval buttons to Telegram and wait for user response."""
        import uuid

        from otto.mcp_tools.platform import send_buttons

        request_id = uuid.uuid4().hex[:12]
        loop = asyncio.get_running_loop()
        future: asyncio.Future[bool] = loop.create_future()
        TelegramPermissionCallback._pending[request_id] = future

        text = (
            f"🔐 <b>Permission Required</b>\n\n"
            f"<b>Tool:</b> <code>{request.server}.{request.tool}</code>\n"
            f"<b>Reason:</b> {reason}\n"
            f"<b>Backend:</b> {request.backend or 'unknown'}"
        )

        buttons = [
            {"label": "✅ Allow", "callback_data": f"gw_permit:{request_id}:allow"},
            {"label": "❌ Deny", "callback_data": f"gw_permit:{request_id}:deny"},
        ]

        result = await send_buttons(text=text, buttons=buttons, columns=2)

        if not result.get("success"):
            log.warning("Failed to send permission prompt: %s", result.get("error"))
            # Fall back to deny when we can't reach the user
            TelegramPermissionCallback._pending.pop(request_id, None)
            return False

        try:
            return await asyncio.wait_for(future, timeout=self._timeout)
        except asyncio.TimeoutError:
            log.warning(
                "Permission request timed out for %s.%s (request_id=%s)",
                request.server,
                request.tool,
                request_id,
            )
            return False
        finally:
            TelegramPermissionCallback._pending.pop(request_id, None)

    @classmethod
    def resolve(cls, request_id: str, allowed: bool) -> bool:
        """
        Resolve a pending permission request (called from callback handler).

        Args:
            request_id: The request ID from the callback_data
            allowed: True to allow, False to deny

        Returns:
            True if the request was found and resolved, False if not found
        """
        future = cls._pending.get(request_id)
        if future is not None and not future.done():
            future.set_result(allowed)
            return True
        return False


class SignalPermissionCallback:
    """
    Permission callback for Signal (text-based, no inline keyboards).

    Sends a text prompt to Signal and waits for "yes"/"no" reply.
    Uses Otto's notify tool to send the prompt and resolves via the
    Signal message handler.
    """

    _pending: dict[str, asyncio.Future[bool]] = {}

    def __init__(self, timeout: float = 120.0):
        self._timeout = timeout

    async def __call__(self, request: ToolRequest, reason: str) -> bool:
        """Send a text permission prompt to Signal and wait for reply."""
        import uuid

        from otto.mcp_tools.notify import notify_send

        request_id = uuid.uuid4().hex[:12]
        loop = asyncio.get_running_loop()
        future: asyncio.Future[bool] = loop.create_future()
        SignalPermissionCallback._pending[request_id] = future

        text = (
            f"🔐 Permission Required\n\n"
            f"Tool: {request.server}.{request.tool}\n"
            f"Reason: {reason}\n"
            f"Backend: {request.backend or 'unknown'}\n\n"
            f"Reply 'allow {request_id}' or 'deny {request_id}'"
        )

        result = await notify_send(message=text, platform="signal")

        if not result.get("success"):
            log.warning("Failed to send Signal permission prompt: %s", result.get("error"))
            SignalPermissionCallback._pending.pop(request_id, None)
            return False

        try:
            return await asyncio.wait_for(future, timeout=self._timeout)
        except asyncio.TimeoutError:
            log.warning(
                "Signal permission request timed out for %s.%s (request_id=%s)",
                request.server,
                request.tool,
                request_id,
            )
            return False
        finally:
            SignalPermissionCallback._pending.pop(request_id, None)

    @classmethod
    def resolve(cls, request_id: str, allowed: bool) -> bool:
        """Resolve a pending Signal permission request."""
        future = cls._pending.get(request_id)
        if future is not None and not future.done():
            future.set_result(allowed)
            return True
        return False


class MultiPlatformPermissionCallback:
    """
    Dispatches permission prompts to all active platforms.

    Tries Telegram first (rich inline buttons), then Signal (text-based).
    First platform to respond wins.
    """

    def __init__(self, timeout: float = 120.0):
        self._telegram = TelegramPermissionCallback(timeout=timeout)
        self._signal = SignalPermissionCallback(timeout=timeout)
        self._timeout = timeout

    async def __call__(self, request: ToolRequest, reason: str) -> bool:
        """Send permission prompt to Telegram (primary) with Signal fallback."""
        # Try Telegram first — it's the rich platform with inline buttons
        try:
            return await self._telegram(request, reason)
        except Exception as exc:
            log.debug("Telegram permission callback failed: %s", exc)

        # Fallback to Signal
        try:
            return await self._signal(request, reason)
        except Exception as exc:
            log.debug("Signal permission callback also failed: %s", exc)

        # Both failed — deny for safety
        log.warning("All permission callbacks failed for %s.%s", request.server, request.tool)
        return False


__all__ = [
    # Core types
    "PolicyVerdict",
    "ToolRequest",
    "ToolResponse",
    "ServerPolicy",
    "GatewayPolicy",
    # Protocols
    "PermissionCallback",
    "AuditCallback",
    # Gateway
    "Gateway",
    "LocalGateway",
    # Rate limiting & quota
    "RateLimiter",
    "QuotaTracker",
    # Agent boundaries (Phase 4)
    "AgentBoundaries",
    "TurnTracker",
    "CooldownTracker",
    # Singleton
    "get_gateway",
    "close_gateway",
    "reload_gateway",
    # Kill switch
    "activate_kill_switch",
    "deactivate_kill_switch",
    "is_kill_switch_active",
    # Permission callbacks
    "TelegramPermissionCallback",
    "SignalPermissionCallback",
    "MultiPlatformPermissionCallback",
    # Internal (for testing)
    "StdioConnection",
    # Helpers
    "load_gateway_policy",
]
