"""
Internal message queue for async agent → Otto communication.

When a background agent completes, it writes a message here.
The Telegram bot polls this queue and processes messages through Otto,
allowing natural conversational responses to async events.
"""

from __future__ import annotations

import json
import random
import sqlite3
import time
import uuid
from collections.abc import Sequence
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Literal

from otto.jobs.queue import DEFAULT_DB
from otto.paths import OTTO_HOME

LEGACY_QUEUE_FILE = OTTO_HOME / "internal_messages.jsonl"
DB_PATH = DEFAULT_DB

_MAX_DELIVERY_ATTEMPTS = 10
_BASE_BACKOFF_SECONDS = 5
_MAX_BACKOFF_SECONDS = 300  # 5 minutes


@dataclass
class InternalMessage:
    """A message from an async process to Otto."""

    id: str
    type: Literal[
        "agent_completed", "scheduled_job", "system_event", "task_update", "pipeline_completed"
    ]
    payload: dict
    timestamp: str
    processed: bool = False

    @classmethod
    def create(cls, msg_type: str, payload: dict) -> InternalMessage:
        return cls(
            id=uuid.uuid4().hex[:12],
            type=msg_type,
            payload=payload,
            timestamp=datetime.now().isoformat(),
            processed=False,
        )

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> InternalMessage:
        return cls(**d)


def _connect(db_path: Path = DB_PATH) -> sqlite3.Connection:
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(
        db_path,
        timeout=30.0,
        isolation_level="IMMEDIATE",
    )
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA busy_timeout=30000;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    return conn


def _init_db(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS internal_events (
            id TEXT PRIMARY KEY,
            type TEXT NOT NULL,
            payload TEXT DEFAULT '{}',
            status TEXT DEFAULT 'pending',
            priority INTEGER DEFAULT 0,
            attempts INTEGER DEFAULT 0,
            max_attempts INTEGER DEFAULT 10,
            run_at TEXT,
            last_error TEXT,
            locked_at TEXT,
            locked_by TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            processed_at TEXT
        )
        """
    )

    # Backwards-compatible migrations for existing DBs.
    cols = {row["name"] for row in conn.execute("PRAGMA table_info(internal_events)")}
    if "priority" not in cols:
        conn.execute("ALTER TABLE internal_events ADD COLUMN priority INTEGER DEFAULT 0")
    if "attempts" not in cols:
        conn.execute("ALTER TABLE internal_events ADD COLUMN attempts INTEGER DEFAULT 0")
    if "max_attempts" not in cols:
        conn.execute("ALTER TABLE internal_events ADD COLUMN max_attempts INTEGER DEFAULT 10")
    if "run_at" not in cols:
        conn.execute("ALTER TABLE internal_events ADD COLUMN run_at TEXT")
    if "last_error" not in cols:
        conn.execute("ALTER TABLE internal_events ADD COLUMN last_error TEXT")
    if "locked_at" not in cols:
        conn.execute("ALTER TABLE internal_events ADD COLUMN locked_at TEXT")
    if "locked_by" not in cols:
        conn.execute("ALTER TABLE internal_events ADD COLUMN locked_by TEXT")
    if "updated_at" not in cols:
        conn.execute(
            "ALTER TABLE internal_events ADD COLUMN updated_at TEXT DEFAULT CURRENT_TIMESTAMP"
        )
    if "processed_at" not in cols:
        conn.execute("ALTER TABLE internal_events ADD COLUMN processed_at TEXT")

    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_internal_events_pending
        ON internal_events(status, run_at, priority)
        """
    )
    conn.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_internal_events_type
        ON internal_events(type, status)
        """
    )


def _with_retry(fn, *, max_attempts: int = 6):
    """Retry transient SQLite errors with exponential backoff + jitter."""
    last_exc: Exception | None = None
    for attempt in range(max_attempts):
        try:
            return fn()
        except sqlite3.OperationalError as e:
            last_exc = e
            msg = str(e).lower()
            if "locked" not in msg and "busy" not in msg:
                raise
            delay = min(2.0, 0.05 * (2**attempt)) + random.random() * 0.05
            time.sleep(delay)
    if last_exc:
        raise last_exc
    raise RuntimeError("Unreachable")


def _migrate_legacy_jsonl(conn: sqlite3.Connection) -> int:
    """
    Best-effort one-time migration from legacy JSONL queue into SQLite.

    Returns number of messages imported.
    """
    if not LEGACY_QUEUE_FILE.exists():
        return 0

    imported = 0
    try:
        lines = LEGACY_QUEUE_FILE.read_text().splitlines()
    except OSError:
        return 0

    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue

        processed = data.get("processed")
        if processed is True or processed == "processing":
            continue

        msg_id = data.get("id")
        msg_type = data.get("type")
        payload = data.get("payload") or {}
        timestamp = data.get("timestamp")
        if not msg_id or not msg_type or not timestamp:
            continue

        priority = 0
        p = (payload.get("priority") or "").lower()
        if p == "high":
            priority = 10
        elif p == "low":
            priority = -10

        conn.execute(
            """
            INSERT OR IGNORE INTO internal_events (id, type, payload, status, priority, created_at)
            VALUES (?, ?, ?, 'pending', ?, ?)
            """,
            (msg_id, msg_type, json.dumps(payload), priority, timestamp),
        )
        imported += 1

    # Avoid re-importing on every poll.
    try:
        LEGACY_QUEUE_FILE.rename(LEGACY_QUEUE_FILE.with_suffix(".jsonl.migrated"))
    except OSError:
        pass

    return imported


def queue_message(
    msg: InternalMessage,
    *,
    run_at: datetime | None = None,
    delay_seconds: float | None = None,
) -> None:
    """Persist a message for the bot to deliver."""

    def _op():
        conn = _connect()
        try:
            _init_db(conn)
            _migrate_legacy_jsonl(conn)

            local_run_at = run_at
            if delay_seconds is not None and delay_seconds > 0:
                local_run_at = datetime.now() + timedelta(seconds=float(delay_seconds))
            run_at_value = local_run_at.isoformat() if local_run_at else None

            payload = msg.payload or {}
            priority = 0
            p = (payload.get("priority") or "").lower()
            if p == "high":
                priority = 10
            elif p == "low":
                priority = -10

            conn.execute(
                """
                INSERT OR REPLACE INTO internal_events (
                    id, type, payload, status, priority, attempts, max_attempts, run_at, created_at, updated_at
                ) VALUES (?, ?, ?, 'pending', ?, 0, ?, ?, ?, CURRENT_TIMESTAMP)
                """,
                (
                    msg.id,
                    msg.type,
                    json.dumps(payload),
                    priority,
                    _MAX_DELIVERY_ATTEMPTS,
                    run_at_value,
                    msg.timestamp,
                ),
            )
            conn.commit()
        finally:
            conn.close()

    _with_retry(_op)


def get_pending_messages() -> list[InternalMessage]:
    """Get all unprocessed messages (does not claim/lock)."""

    def _op() -> list[InternalMessage]:
        conn = _connect()
        try:
            _init_db(conn)
            _migrate_legacy_jsonl(conn)

            now = datetime.now().isoformat()
            cursor = conn.execute(
                """
                SELECT * FROM internal_events
                WHERE status = 'pending'
                AND (run_at IS NULL OR run_at <= ?)
                ORDER BY priority DESC, created_at ASC, id ASC
                """,
                (now,),
            )
            rows = cursor.fetchall()
            out: list[InternalMessage] = []
            for row in rows:
                payload = json.loads(row["payload"] or "{}")
                out.append(
                    InternalMessage(
                        id=row["id"],
                        type=row["type"],
                        payload=payload,
                        timestamp=row["created_at"],
                        processed=False,
                    )
                )
            return out
        finally:
            conn.close()

    return _with_retry(_op)


def claim_pending_messages(
    worker_id: str = "telegram",
    limit: int = 25,
    *,
    types: Sequence[str] | None = None,
    min_priority: int | None = None,
    max_priority: int | None = None,
) -> list[InternalMessage]:
    """Atomically claim messages for processing and return them.

    Args:
        worker_id: Locker identity.
        limit: Max number of messages to claim.
        types: Optional list of internal event types to claim.
        min_priority: Optional minimum DB priority (inclusive).
        max_priority: Optional maximum DB priority (inclusive).
    """

    def _op() -> list[InternalMessage]:
        conn = _connect()
        try:
            _init_db(conn)
            _migrate_legacy_jsonl(conn)

            now = datetime.now().isoformat()
            lock_timeout = (datetime.now() - timedelta(minutes=30)).isoformat()

            where = ["status = 'pending'", "(run_at IS NULL OR run_at <= ?)"]
            params: list[object] = [now]

            if types:
                where.append(f"type IN ({','.join(['?'] * len(types))})")
                params.extend([str(t) for t in types])

            if min_priority is not None:
                where.append("priority >= ?")
                params.append(int(min_priority))
            if max_priority is not None:
                where.append("priority <= ?")
                params.append(int(max_priority))

            where_sql = " AND ".join(where)

            cursor = conn.execute(
                f"""
                WITH to_claim AS (
                    SELECT id FROM internal_events
                    WHERE {where_sql}
                    ORDER BY priority DESC, run_at ASC, created_at ASC, id ASC
                    LIMIT ?
                )
                UPDATE internal_events SET
                    status = 'processing',
                    locked_at = ?,
                    locked_by = ?,
                    attempts = attempts + 1,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id IN (SELECT id FROM to_claim)
                RETURNING *
                """,
                (*params, limit, now, worker_id),
            )
            rows = cursor.fetchall()

            # Reclaim stale processing events (crashed bot) when no fresh work was found.
            if not rows:
                stale_where = [
                    "status = 'processing'",
                    "locked_at < ?",
                    "attempts < max_attempts",
                ]
                stale_params: list[object] = [lock_timeout]

                if types:
                    stale_where.append(f"type IN ({','.join(['?'] * len(types))})")
                    stale_params.extend([str(t) for t in types])

                if min_priority is not None:
                    stale_where.append("priority >= ?")
                    stale_params.append(int(min_priority))
                if max_priority is not None:
                    stale_where.append("priority <= ?")
                    stale_params.append(int(max_priority))

                stale_where_sql = " AND ".join(stale_where)
                cursor = conn.execute(
                    f"""
                    WITH stale AS (
                        SELECT id FROM internal_events
                        WHERE {stale_where_sql}
                        ORDER BY priority DESC, created_at ASC, id ASC
                        LIMIT ?
                    )
                    UPDATE internal_events SET
                        status = 'processing',
                        locked_at = ?,
                        locked_by = ?,
                        attempts = attempts + 1,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id IN (SELECT id FROM stale)
                    RETURNING *
                    """,
                    (*stale_params, limit, now, worker_id),
                )
                rows = cursor.fetchall()

            conn.commit()

            out: list[InternalMessage] = []
            for row in rows:
                out.append(
                    InternalMessage(
                        id=row["id"],
                        type=row["type"],
                        payload=json.loads(row["payload"] or "{}"),
                        timestamp=row["created_at"],
                        processed=False,
                    )
                )
            return out
        finally:
            conn.close()

    from datetime import timedelta

    return _with_retry(_op)


def mark_processed(msg_id: str, status: str = "processed") -> None:
    """Update an event's delivery state (legacy API)."""

    def _op():
        conn = _connect()
        try:
            _init_db(conn)
            _migrate_legacy_jsonl(conn)

            now = datetime.now().isoformat()
            if status == "processing":
                conn.execute(
                    """
                    UPDATE internal_events SET
                        status = 'processing',
                        locked_at = ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """,
                    (now, msg_id),
                )
            else:
                conn.execute(
                    """
                    UPDATE internal_events SET
                        status = 'processed',
                        processed_at = ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """,
                    (now, msg_id),
                )
            conn.commit()
        finally:
            conn.close()

    _with_retry(_op)


def mark_failed(msg_id: str, error: str) -> None:
    """Record a delivery failure and reschedule with exponential backoff."""

    def _op():
        conn = _connect()
        try:
            _init_db(conn)
            _migrate_legacy_jsonl(conn)

            cursor = conn.execute(
                "SELECT attempts, max_attempts FROM internal_events WHERE id = ?",
                (msg_id,),
            )
            row = cursor.fetchone()
            if not row:
                return

            attempts = int(row["attempts"] or 0)
            max_attempts = int(row["max_attempts"] or _MAX_DELIVERY_ATTEMPTS)

            if attempts < max_attempts:
                delay = min(_MAX_BACKOFF_SECONDS, _BASE_BACKOFF_SECONDS * (2**attempts))
                run_at = (datetime.now() + timedelta(seconds=delay)).isoformat()
                conn.execute(
                    """
                    UPDATE internal_events SET
                        status = 'pending',
                        last_error = ?,
                        run_at = ?,
                        locked_at = NULL,
                        locked_by = NULL,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """,
                    (error[:500], run_at, msg_id),
                )
            else:
                conn.execute(
                    """
                    UPDATE internal_events SET
                        status = 'failed',
                        last_error = ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """,
                    (error[:500], msg_id),
                )

            conn.commit()
        finally:
            conn.close()

    from datetime import timedelta

    _with_retry(_op)


def clear_processed() -> int:
    """Remove all processed messages. Returns count removed."""
    removed: int = 0

    def _op() -> int:
        conn = _connect()
        try:
            _init_db(conn)
            _migrate_legacy_jsonl(conn)

            cur = conn.execute(
                "DELETE FROM internal_events WHERE status = 'processed'",
            )
            conn.commit()
            return int(cur.rowcount)
        finally:
            conn.close()

    removed = _with_retry(_op)
    return removed


def format_agent_completion(payload: dict) -> str:
    """Format an agent completion message for Otto's context."""
    agent_id = payload.get("agent_id", "unknown")
    task = payload.get("task", "unknown task")
    backend = payload.get("backend", "unknown")
    success = payload.get("success", False)
    duration = payload.get("duration", payload.get("duration_seconds", 0))
    output_file = payload.get("output_file", "")
    output_summary = payload.get("output_summary", "")

    status = "completed successfully" if success else "failed"
    try:
        duration_s = float(duration or 0)
    except Exception:
        duration_s = 0.0

    msg = f"""[SYSTEM: Background agent {agent_id} has {status}]
Task: {task}
Backend: {backend}
Duration: {duration_s:.1f}s
Output file: {output_file}
"""
    if output_summary:
        msg += f"\nOutput summary:\n{output_summary}\n"

    msg += "\n[Please summarize this result naturally to the user based on our conversation context. Be concise unless they asked for detail.]"

    return msg


def format_scheduled_job_event(payload: dict) -> str:
    """Format a scheduled job completion event for Otto's context."""
    job_id = payload.get("job_id", "unknown")
    scheduled_for = payload.get("scheduled_for")
    success = bool(payload.get("success", False))
    duration = payload.get("duration_seconds", payload.get("duration"))
    output_file = payload.get("output_file")
    output_summary = payload.get("output_summary") or ""
    error = payload.get("error") or ""

    status = "completed successfully" if success else "failed"
    lines = [f"[SYSTEM: Scheduled job {job_id} {status}]"]
    if scheduled_for:
        lines.append(f"Scheduled for: {scheduled_for}")
    if duration is not None:
        try:
            lines.append(f"Duration: {float(duration):.1f}s")
        except Exception:
            pass
    if output_file:
        lines.append(f"Output file: {output_file}")
    if output_summary:
        lines.append(f"\nOutput summary:\n{output_summary[:800]}")
    if error and not success:
        lines.append(f"\nError:\n{str(error)[:800]}")
    lines.append(
        "\n[Please summarize this to the user based on our conversation context. "
        "Be concise unless they asked for detail.]"
    )
    return "\n".join(lines)


def format_system_event(payload: dict) -> str:
    """Format a system event for Otto's context."""
    event = payload.get("event", payload.get("type", "system_event"))
    title = payload.get("title") or "System event"
    details = payload.get("details") or payload.get("message") or ""

    lines = [f"[SYSTEM: {title}]", f"Event: {event}"]
    if details:
        lines.append(f"\nDetails:\n{str(details)[:1200]}")
    lines.append("\n[Summarize this briefly for the user and suggest next steps if needed.]")
    return "\n".join(lines)


def format_event_batch(messages: Sequence[InternalMessage]) -> str:
    """Format a mixed set of internal events for Otto to summarize as a batch."""
    if not messages:
        return ""

    lines: list[str] = [
        "[SYSTEM: Multiple low-priority internal events are ready to report.]",
        "",
    ]

    for i, msg in enumerate(messages, 1):
        payload = msg.payload or {}
        lines.append(f"### Event {i}: {msg.type}")
        if msg.timestamp:
            lines.append(f"Time: {msg.timestamp}")

        if msg.type == "agent_completed":
            agent_id = payload.get("agent_id", "unknown")
            task = payload.get("task", "unknown task")
            backend = payload.get("backend", "unknown")
            success = bool(payload.get("success", False))
            duration = payload.get("duration", payload.get("duration_seconds"))
            output_file = payload.get("output_file")
            output_summary = (payload.get("output_summary") or "")[:400]
            error = (payload.get("error") or "")[:400]

            lines.extend(
                [
                    f"Agent: {agent_id}",
                    f"Task: {task}",
                    f"Backend: {backend}",
                    f"Success: {success}",
                ]
            )
            if duration is not None:
                try:
                    lines.append(f"Duration: {float(duration):.1f}s")
                except Exception:
                    pass
            if output_file:
                lines.append(f"Output file: {output_file}")
            if output_summary:
                lines.append(f"Output summary: {output_summary}")
            if error and not success:
                lines.append(f"Error: {error}")

        elif msg.type == "scheduled_job":
            job_id = payload.get("job_id", "unknown")
            scheduled_for = payload.get("scheduled_for")
            backend = payload.get("backend", "unknown")
            success = bool(payload.get("success", False))
            duration = payload.get("duration_seconds", payload.get("duration"))
            output_file = payload.get("output_file")
            output_summary = (payload.get("output_summary") or "")[:400]
            error = (payload.get("error") or "")[:400]

            lines.extend(
                [
                    f"Job: {job_id}",
                    f"Backend: {backend}",
                    f"Success: {success}",
                ]
            )
            if scheduled_for:
                lines.append(f"Scheduled for: {scheduled_for}")
            if duration is not None:
                try:
                    lines.append(f"Duration: {float(duration):.1f}s")
                except Exception:
                    pass
            if output_file:
                lines.append(f"Output file: {output_file}")
            if output_summary:
                lines.append(f"Output summary: {output_summary}")
            if error and not success:
                lines.append(f"Error: {error}")

        elif msg.type == "system_event":
            event = payload.get("event", payload.get("type", "system_event"))
            title = payload.get("title") or "System event"
            details = payload.get("details") or payload.get("message") or ""
            details_str = str(details)[:800] if details else ""

            lines.extend([f"Title: {title}", f"Event: {event}"])
            if details_str:
                lines.append(f"Details: {details_str}")

        elif msg.type == "task_update":
            checklist_id = payload.get("checklist_id")
            action = payload.get("action")
            task_id = payload.get("task_id")
            task_content = payload.get("task_content")

            if checklist_id:
                lines.append(f"Checklist: {checklist_id}")
            if action:
                lines.append(f"Action: {action}")
            if task_id:
                lines.append(f"Task ID: {task_id}")
            if task_content:
                lines.append(f"Task content: {str(task_content)[:200]}")

        else:
            try:
                lines.append(f"Payload: {json.dumps(payload)[:1200]}")
            except Exception:
                lines.append(f"Payload: {str(payload)[:1200]}")

        lines.append("")

    lines.append(
        "[Write a single, concise update for the user. Group related items. "
        "Clearly call out any failures or needed follow-ups. "
        "Do not paste long outputs; reference output file paths instead.]"
    )
    return "\n".join(lines)


def format_pipeline_completed(payload: dict) -> str:
    """Format a pipeline completion message for Otto's context."""
    root_agent_id = payload.get("root_agent_id", "unknown")
    final_agent_id = payload.get("final_agent_id", "unknown")
    members = payload.get("members", [])
    all_success = payload.get("all_success", False)

    status = "completed successfully" if all_success else "completed with failures"

    lines = [
        f"[SYSTEM: Pipeline {root_agent_id} has {status}]",
        f"Pipeline has {len(members)} stages:",
        "",
    ]

    for i, m in enumerate(members, 1):
        agent_id = m.get("agent_id", "unknown")
        task = m.get("task", "unknown task")
        member_status = m.get("status", "unknown")
        output_file = m.get("output_file", "")

        status_icon = (
            "✅" if member_status == "completed" else "❌" if member_status == "failed" else "⏳"
        )
        lines.append(f"{i}. {status_icon} {task[:60]}")
        lines.append(f"   Agent: {agent_id} | Status: {member_status}")
        if output_file:
            lines.append(f"   Output: {output_file}")
        lines.append("")

    lines.append(
        "[INSTRUCTIONS: Read the output files to understand what happened, then send ONE concise message "
        "summarizing the pipeline results. Do NOT send the files separately - just synthesize the key outcomes. "
        "Keep it brief (2-4 sentences). Be conversational, mention if all stages succeeded or which failed.]"
    )

    return "\n".join(lines)


def format_batch_completion(payloads: list[dict]) -> str:
    """Format multiple agent completions for Otto to summarize as a batch."""
    if not payloads:
        return ""

    lines = [
        "[SYSTEM: Multiple background agents have completed. Please summarize these results as a batch.]",
        "",
    ]

    for i, p in enumerate(payloads, 1):
        agent_id = p.get("agent_id", "unknown")
        task = p.get("task", "unknown task")
        success = p.get("success", False)
        duration = p.get("duration", 0)
        output_summary = p.get("output_summary", "")[:200]
        status = "✅ Success" if success else "❌ Failed"

        lines.append(f"### Agent {i}: {agent_id}")
        lines.append(f"Task: {task}")
        lines.append(f"Status: {status} ({duration:.1f}s)")
        if output_summary:
            lines.append(f"Summary: {output_summary}")
        lines.append("")

    lines.append(
        "[Provide a brief, unified summary of all these results. Group by success/failure if useful. Be concise - user can ask for details.]"
    )

    return "\n".join(lines)


def get_batch_status() -> dict:
    """Get status of the low-priority batch queue."""
    from datetime import datetime

    messages = get_pending_messages()
    low_priority = [m for m in messages if (m.payload.get("priority") or "").lower() == "low"]

    if not low_priority:
        return {
            "count": 0,
            "oldest_age_minutes": 0,
            "messages": [],
        }

    oldest = min(low_priority, key=lambda m: m.timestamp)
    try:
        oldest_time = datetime.fromisoformat(oldest.timestamp)
        age_minutes = (datetime.now() - oldest_time).total_seconds() / 60
    except Exception:
        age_minutes = 0

    return {
        "count": len(low_priority),
        "oldest_age_minutes": age_minutes,
        "messages": [
            {
                "id": m.id,
                "type": m.type,
                "agent_id": m.payload.get("agent_id"),
                "task": m.payload.get("task"),
                "success": m.payload.get("success"),
                "timestamp": m.timestamp,
            }
            for m in low_priority
        ],
    }


def queue_task_update(
    checklist_id: str,
    task_id: str | None = None,
    action: str = "toggle",  # "toggle", "complete", "add"
    task_content: str | None = None,
) -> None:
    """Queue a task update for the Telegram bot to process.

    This allows Otto to update task checklists asynchronously (e.g., when
    completing work in the background).

    Args:
        checklist_id: The checklist to update
        task_id: Specific task to modify (for toggle/complete)
        action: "toggle", "complete", or "add"
        task_content: Content for new task (when action="add")
    """
    msg = InternalMessage.create(
        "task_update",
        {
            "checklist_id": checklist_id,
            "task_id": task_id,
            "action": action,
            "task_content": task_content,
        },
    )
    queue_message(msg)


def force_batch_flush() -> int:
    """Force immediate processing of low-priority messages by changing their priority to normal.

    Returns the number of messages updated.
    """

    def _op() -> int:
        conn = _connect()
        try:
            _init_db(conn)
            _migrate_legacy_jsonl(conn)

            cursor = conn.execute(
                """
                SELECT id, payload FROM internal_events
                WHERE status = 'pending' AND type = 'agent_completed'
                """,
            )
            rows = cursor.fetchall()

            updated = 0
            for row in rows:
                payload = json.loads(row["payload"] or "{}")
                if (payload.get("priority") or "").lower() != "low":
                    continue
                payload["priority"] = "normal"
                payload["flushed"] = True
                conn.execute(
                    """
                    UPDATE internal_events SET
                        payload = ?,
                        priority = 0,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """,
                    (json.dumps(payload), row["id"]),
                )
                updated += 1

            conn.commit()
            return updated
        finally:
            conn.close()

    return _with_retry(_op)
