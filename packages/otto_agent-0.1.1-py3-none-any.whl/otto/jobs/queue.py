#!/usr/bin/env python3
"""
SQLite Job Queue - minimal, reliable job processing.

The queue is intentionally a transient execution buffer. Authoritative schedule
state lives in files under ~/.otto/ (see `otto.schedule`), not in this DB.
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path

from otto.paths import DATA_DIR

DEFAULT_DB = DATA_DIR / "jobs.sqlite"


class JobQueue:
    def __init__(self, db_path: Path = DEFAULT_DB):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    @contextmanager
    def _conn(self):
        """Thread-safe connection context manager."""
        conn = sqlite3.connect(
            self.db_path,
            timeout=30.0,
            isolation_level="IMMEDIATE",
        )
        conn.row_factory = sqlite3.Row

        # Basic reliability defaults; WAL keeps writers from blocking readers.
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA busy_timeout=30000;")
        conn.execute("PRAGMA synchronous=NORMAL;")

        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_db(self):
        """Create tables if they don't exist."""
        with self._conn() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS jobs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    type TEXT NOT NULL,
                    payload TEXT DEFAULT '{}',
                    external_id TEXT,
                    pipeline_id TEXT,
                    step_id TEXT,
                    depends_on_id TEXT,
                    depends_on_status TEXT,
                    status TEXT DEFAULT 'pending',
                    priority INTEGER DEFAULT 0,
                    run_at TEXT,
                    attempts INTEGER DEFAULT 0,
                    max_attempts INTEGER DEFAULT 3,
                    last_error TEXT,
                    pid INTEGER,
                    locked_at TEXT,
                    locked_by TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
                """
            )

            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS job_dependencies (
                    job_id INTEGER NOT NULL,
                    depends_on_id TEXT NOT NULL
                )
                """
            )

            # Backwards-compatible migrations for existing DBs.
            cols = {row["name"] for row in conn.execute("PRAGMA table_info(jobs)")}
            if "external_id" not in cols:
                conn.execute("ALTER TABLE jobs ADD COLUMN external_id TEXT")
            if "pid" not in cols:
                conn.execute("ALTER TABLE jobs ADD COLUMN pid INTEGER")
            if "depends_on_id" not in cols:
                conn.execute("ALTER TABLE jobs ADD COLUMN depends_on_id TEXT")
            if "depends_on_status" not in cols:
                conn.execute("ALTER TABLE jobs ADD COLUMN depends_on_status TEXT")
            if "pipeline_id" not in cols:
                conn.execute("ALTER TABLE jobs ADD COLUMN pipeline_id TEXT")
            if "step_id" not in cols:
                conn.execute("ALTER TABLE jobs ADD COLUMN step_id TEXT")

            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_jobs_pending
                ON jobs(status, run_at, priority)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_jobs_type
                ON jobs(type, status)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_jobs_external_id
                ON jobs(external_id)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_jobs_depends_on
                ON jobs(depends_on_id, depends_on_status, status)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_jobs_pipeline
                ON jobs(pipeline_id, status)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_job_dependencies_dep
                ON job_dependencies(depends_on_id)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_job_dependencies_job
                ON job_dependencies(job_id)
                """
            )
            # Enforce deduplication for scheduled jobs: external_id encodes (job_id, scheduled_for).
            conn.execute(
                """
                CREATE UNIQUE INDEX IF NOT EXISTS idx_jobs_scheduled_unique
                ON jobs(external_id)
                WHERE type = 'scheduled' AND external_id IS NOT NULL
                """
            )

            # Internal events table (agent -> bot delivery). Stored in the same DB for atomicity.
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS internal_events (
                    id TEXT PRIMARY KEY,
                    type TEXT NOT NULL,
                    payload TEXT DEFAULT '{}',
                    status TEXT DEFAULT 'pending',
                    priority INTEGER DEFAULT 0,
                    attempts INTEGER DEFAULT 0,
                    max_attempts INTEGER DEFAULT 10,
                    run_at TEXT,
                    last_error TEXT,
                    locked_at TEXT,
                    locked_by TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    processed_at TEXT
                )
                """
            )

            # Backwards-compatible migrations for existing DBs.
            ev_cols = {row["name"] for row in conn.execute("PRAGMA table_info(internal_events)")}
            if "priority" not in ev_cols:
                conn.execute("ALTER TABLE internal_events ADD COLUMN priority INTEGER DEFAULT 0")
            if "attempts" not in ev_cols:
                conn.execute("ALTER TABLE internal_events ADD COLUMN attempts INTEGER DEFAULT 0")
            if "max_attempts" not in ev_cols:
                conn.execute(
                    "ALTER TABLE internal_events ADD COLUMN max_attempts INTEGER DEFAULT 10"
                )
            if "run_at" not in ev_cols:
                conn.execute("ALTER TABLE internal_events ADD COLUMN run_at TEXT")
            if "last_error" not in ev_cols:
                conn.execute("ALTER TABLE internal_events ADD COLUMN last_error TEXT")
            if "locked_at" not in ev_cols:
                conn.execute("ALTER TABLE internal_events ADD COLUMN locked_at TEXT")
            if "locked_by" not in ev_cols:
                conn.execute("ALTER TABLE internal_events ADD COLUMN locked_by TEXT")
            if "updated_at" not in ev_cols:
                conn.execute(
                    "ALTER TABLE internal_events ADD COLUMN updated_at TEXT DEFAULT CURRENT_TIMESTAMP"
                )
            if "processed_at" not in ev_cols:
                conn.execute("ALTER TABLE internal_events ADD COLUMN processed_at TEXT")

            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_internal_events_pending
                ON internal_events(status, run_at, priority)
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_internal_events_type
                ON internal_events(type, status)
                """
            )

            # Agent failure tracking (used for retries + observability).
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS agent_failures (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    agent_id TEXT NOT NULL,
                    job_id INTEGER,
                    attempt INTEGER,
                    error TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_agent_failures_agent
                ON agent_failures(agent_id, created_at)
                """
            )

    def add(
        self,
        job_type: str,
        payload: dict | None = None,
        delay_seconds: int = 0,
        priority: int = 0,
        max_attempts: int = 3,
        external_id: str | None = None,
        pipeline_id: str | None = None,
        step_id: str | None = None,
        depends_on_id: str | None = None,
        depends_on_status: str | None = None,
    ) -> int:
        """Add a job to the queue. Returns job ID."""
        run_at = None
        if delay_seconds > 0:
            run_at = (datetime.now() + timedelta(seconds=delay_seconds)).isoformat()

        status = "pending"
        if depends_on_id is not None or depends_on_status is not None:
            if not depends_on_id or not depends_on_status:
                raise ValueError("depends_on_id and depends_on_status must be provided together")
            depends_on_status = str(depends_on_status).strip().lower()
            if depends_on_status not in ("success", "failure"):
                raise ValueError("depends_on_status must be 'success' or 'failure'")
            status = "waiting"

        with self._conn() as conn:
            cursor = conn.execute(
                """
                INSERT INTO jobs (
                    type,
                    payload,
                    status,
                    priority,
                    run_at,
                    max_attempts,
                    external_id,
                    pipeline_id,
                    step_id,
                    depends_on_id,
                    depends_on_status
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    job_type,
                    json.dumps(payload or {}),
                    status,
                    priority,
                    run_at,
                    max_attempts,
                    external_id,
                    pipeline_id,
                    step_id,
                    depends_on_id,
                    depends_on_status,
                ),
            )
            job_id = int(cursor.lastrowid)

            deps: list[str] = []
            if depends_on_id:
                deps.append(str(depends_on_id))
            if isinstance(payload, dict):
                payload_deps = payload.get("_depends_on_all")
                if isinstance(payload_deps, list):
                    for dep in payload_deps:
                        dep_str = str(dep).strip()
                        if dep_str and dep_str not in deps:
                            deps.append(dep_str)

            if deps:
                conn.executemany(
                    """
                    INSERT INTO job_dependencies (job_id, depends_on_id)
                    VALUES (?, ?)
                    """,
                    [(job_id, dep) for dep in deps],
                )

            return job_id

    def next(self, worker_id: str = "default") -> dict | None:
        """Get and lock the next available job. Returns None if no jobs ready."""
        now = datetime.now().isoformat()
        lock_timeout = (datetime.now() - timedelta(minutes=30)).isoformat()

        with self._conn() as conn:
            cursor = conn.execute(
                """
                UPDATE jobs SET
                    status = 'running',
                    locked_at = ?,
                    locked_by = ?,
                    attempts = attempts + 1,
                    updated_at = ?
                WHERE id = (
                    SELECT id FROM jobs
                    WHERE status = 'pending'
                    AND (run_at IS NULL OR run_at <= ?)
                    ORDER BY priority DESC, run_at ASC, id ASC
                    LIMIT 1
                )
                RETURNING *
                """,
                (now, worker_id, now, now),
            )

            row = cursor.fetchone()
            if row:
                return self._row_to_dict(row)

            # Check for stale locked jobs (crashed workers)
            cursor = conn.execute(
                """
                UPDATE jobs SET
                    status = 'running',
                    locked_at = ?,
                    locked_by = ?,
                    attempts = attempts + 1,
                    updated_at = ?
                WHERE id = (
                    SELECT id FROM jobs
                    WHERE status = 'running'
                    AND locked_at < ?
                    AND attempts < max_attempts
                    ORDER BY priority DESC, id ASC
                    LIMIT 1
                )
                RETURNING *
                """,
                (now, worker_id, now, lock_timeout),
            )

            row = cursor.fetchone()
            return self._row_to_dict(row) if row else None

    def complete(self, job_id: int) -> None:
        """Mark job as completed."""
        with self._conn() as conn:
            conn.execute(
                """
                UPDATE jobs SET
                    status = 'completed',
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                """,
                (job_id,),
            )

    def has_waiting_children(self, agent_id: str) -> bool:
        """Check if this agent has any jobs waiting on its completion."""
        if not agent_id:
            return False
        with self._conn() as conn:
            cursor = conn.execute(
                """
                SELECT COUNT(*) as count FROM jobs
                WHERE depends_on_id = ? AND status = 'waiting'
                """,
                (agent_id,),
            )
            return cursor.fetchone()["count"] > 0

    def get_pipeline_root(self, agent_id: str) -> str | None:
        """Find the root agent of a pipeline by walking up dependency chain."""
        if not agent_id:
            return None
        with self._conn() as conn:
            current_id = agent_id
            visited = set()
            while current_id and current_id not in visited:
                visited.add(current_id)
                cursor = conn.execute(
                    """
                    SELECT depends_on_id FROM jobs
                    WHERE external_id = ? AND depends_on_id IS NOT NULL
                    LIMIT 1
                    """,
                    (current_id,),
                )
                row = cursor.fetchone()
                if not row or not row["depends_on_id"]:
                    return current_id
                current_id = row["depends_on_id"]
            return current_id

    def get_pipeline_members(self, root_agent_id: str) -> list[dict]:
        """Get all agents in a pipeline starting from the root."""
        if not root_agent_id:
            return []

        members = []
        with self._conn() as conn:
            # Get the root job
            cursor = conn.execute(
                """
                SELECT * FROM jobs WHERE external_id = ? AND type = 'agent'
                ORDER BY id DESC LIMIT 1
                """,
                (root_agent_id,),
            )
            root = cursor.fetchone()
            if root:
                members.append(self._row_to_dict(root))

            # BFS to find all descendants
            queue = [root_agent_id]
            visited = {root_agent_id}
            while queue:
                parent_id = queue.pop(0)
                cursor = conn.execute(
                    """
                    SELECT * FROM jobs
                    WHERE depends_on_id = ? AND type = 'agent'
                    ORDER BY id ASC
                    """,
                    (parent_id,),
                )
                for row in cursor.fetchall():
                    job = self._row_to_dict(row)
                    if job and job.get("external_id") not in visited:
                        members.append(job)
                        visited.add(job.get("external_id"))
                        queue.append(job.get("external_id"))

        return members

    def is_pipeline_complete(self, agent_id: str) -> tuple[bool, list[dict]]:
        """
        Check if the pipeline containing this agent is complete.

        Returns:
            (is_complete, pipeline_members) - is_complete is True if all members
            are in a terminal state (completed, failed, cancelled)
        """
        root = self.get_pipeline_root(agent_id)
        if not root:
            return True, []

        members = self.get_pipeline_members(root)
        if not members:
            return True, []

        # Single agent, no pipeline
        if len(members) == 1:
            return True, members

        # Check if all are terminal
        terminal_states = {"completed", "failed", "cancelled"}
        all_terminal = all(m.get("status") in terminal_states for m in members)
        return all_terminal, members

    def activate_dependents(self, agent_id: str, final_status: str) -> dict[str, int]:
        """Activate or cancel jobs waiting on another agent's outcome."""
        if not agent_id:
            return {"activated": 0, "cancelled": 0}

        final_status = str(final_status or "").strip().lower()
        activated = 0
        cancelled = 0

        with self._conn() as conn:

            def _dep_status(dep_id: str | None) -> str | None:
                if not dep_id:
                    return None
                row = conn.execute(
                    "SELECT status FROM jobs WHERE external_id = ? ORDER BY id DESC LIMIT 1",
                    (dep_id,),
                ).fetchone()
                return row["status"] if row else None

            def _matches_required(required: str, status: str) -> bool:
                if required == "success":
                    return status == "completed"
                if required == "failure":
                    return status == "failed"
                return False

            def _job_dependencies(job_id: int, fallback: str | None) -> list[str]:
                deps: list[str] = []
                rows = conn.execute(
                    "SELECT depends_on_id FROM job_dependencies WHERE job_id = ?",
                    (job_id,),
                ).fetchall()
                deps.extend([row["depends_on_id"] for row in rows if row["depends_on_id"]])
                if not deps and fallback:
                    deps.append(str(fallback))
                return [str(dep).strip() for dep in deps if str(dep).strip()]

            rows = conn.execute(
                """
                SELECT j.* FROM jobs j
                JOIN job_dependencies d ON j.id = d.job_id
                WHERE j.status = 'waiting'
                AND d.depends_on_id = ?
                """,
                (agent_id,),
            ).fetchall()

            legacy_rows = conn.execute(
                """
                SELECT * FROM jobs
                WHERE status = 'waiting'
                AND depends_on_id = ?
                """,
                (agent_id,),
            ).fetchall()

            jobs: dict[int, dict] = {}
            for row in rows + legacy_rows:
                job = self._row_to_dict(row)
                if job:
                    jobs[int(job["id"])] = job

            for job in jobs.values():
                depends_on_status = (job.get("depends_on_status") or "success").lower()
                deps = _job_dependencies(int(job["id"]), job.get("depends_on_id"))
                if not deps:
                    conn.execute(
                        """
                        UPDATE jobs SET
                            status = 'pending',
                            locked_at = NULL,
                            locked_by = NULL,
                            pid = NULL,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                        """,
                        (job["id"],),
                    )
                    activated += 1
                    continue

                statuses = {dep: _dep_status(str(dep)) for dep in deps}

                if depends_on_status == "success":
                    if any(status in ("failed", "cancelled") for status in statuses.values()):
                        conn.execute(
                            """
                            UPDATE jobs SET
                                status = 'cancelled',
                                locked_at = NULL,
                                locked_by = NULL,
                                pid = NULL,
                                updated_at = CURRENT_TIMESTAMP
                            WHERE id = ?
                            """,
                            (job["id"],),
                        )
                        cancelled += 1
                        continue
                    if all(status == "completed" for status in statuses.values()):
                        conn.execute(
                            """
                            UPDATE jobs SET
                                status = 'pending',
                                depends_on_id = ?,
                                locked_at = NULL,
                                locked_by = NULL,
                                pid = NULL,
                                updated_at = CURRENT_TIMESTAMP
                            WHERE id = ?
                            """,
                            (agent_id, job["id"]),
                        )
                        activated += 1
                        continue
                    continue

                if depends_on_status == "failure":
                    if any(status in ("completed", "cancelled") for status in statuses.values()):
                        conn.execute(
                            """
                            UPDATE jobs SET
                                status = 'cancelled',
                                locked_at = NULL,
                                locked_by = NULL,
                                pid = NULL,
                                updated_at = CURRENT_TIMESTAMP
                            WHERE id = ?
                            """,
                            (job["id"],),
                        )
                        cancelled += 1
                        continue
                    if all(status == "failed" for status in statuses.values()):
                        conn.execute(
                            """
                            UPDATE jobs SET
                                status = 'pending',
                                depends_on_id = ?,
                                locked_at = NULL,
                                locked_by = NULL,
                                pid = NULL,
                                updated_at = CURRENT_TIMESTAMP
                            WHERE id = ?
                            """,
                            (agent_id, job["id"]),
                        )
                        activated += 1
                        continue
                    continue

                conn.execute(
                    """
                    UPDATE jobs SET
                        status = 'cancelled',
                        locked_at = NULL,
                        locked_by = NULL,
                        pid = NULL,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """,
                    (job["id"],),
                )
                cancelled += 1

        return {"activated": activated, "cancelled": cancelled}

    def record_agent_failure(
        self,
        agent_id: str,
        *,
        job_id: int | None = None,
        attempt: int | None = None,
        error: str | None = None,
    ) -> None:
        """Record an agent failure for observability and retry tracking."""
        if not agent_id:
            return
        with self._conn() as conn:
            conn.execute(
                """
                INSERT INTO agent_failures (agent_id, job_id, attempt, error)
                VALUES (?, ?, ?, ?)
                """,
                (str(agent_id), int(job_id) if job_id is not None else None, attempt, error),
            )

    def fail(self, job_id: int, error: str | None = None) -> None:
        """Mark job as failed. If under max_attempts, it will be retried."""
        with self._conn() as conn:
            cursor = conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,))
            row = cursor.fetchone()
            if not row:
                return

            job_type = row["type"]
            attempts = int(row["attempts"] or 0)
            max_attempts = int(row["max_attempts"] or 0)
            external_id = row["external_id"]
            payload = json.loads(row["payload"]) if row["payload"] else {}

            agent_id = None
            if job_type == "agent":
                agent_id = external_id or payload.get("agent_id") or payload.get("id")
                if agent_id:
                    conn.execute(
                        """
                        INSERT INTO agent_failures (agent_id, job_id, attempt, error)
                        VALUES (?, ?, ?, ?)
                        """,
                        (str(agent_id), int(job_id), attempts, error),
                    )

            if attempts < max_attempts:
                delay = self._retry_delay_seconds(job_type=job_type, attempts=attempts)
                run_at = (datetime.now() + timedelta(seconds=delay)).isoformat()
                conn.execute(
                    """
                    UPDATE jobs SET
                        status = 'pending',
                        last_error = ?,
                        run_at = ?,
                        locked_at = NULL,
                        locked_by = NULL,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """,
                    (error, run_at, job_id),
                )
                return

            conn.execute(
                """
                UPDATE jobs SET
                    status = 'failed',
                    last_error = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                """,
                (error, job_id),
            )

    def _retry_delay_seconds(self, *, job_type: str, attempts: int) -> int:
        """Compute retry delay for a job attempt."""
        base_delay = 30
        backoff_factor = 2.0
        max_delay = 300

        if job_type == "agent":
            try:
                from otto import config as otto_config

                retry_cfg = otto_config.get_setting("agent.orchestration.retry", {}) or {}
                base_delay = int(retry_cfg.get("base_delay_seconds", base_delay))
                backoff_factor = float(retry_cfg.get("backoff_factor", backoff_factor))
                max_delay = int(retry_cfg.get("max_delay_seconds", max_delay))
            except Exception:
                pass

        if attempts < 0:
            attempts = 0
        delay = int(base_delay * (backoff_factor**attempts))
        if delay < 0:
            delay = 0
        return min(max_delay, delay)

    def cancel(self, job_id: int) -> None:
        """Cancel a pending or waiting job."""
        job = self.get(job_id)
        if not job:
            return

        with self._conn() as conn:
            cursor = conn.execute(
                """
                UPDATE jobs SET
                    status = 'cancelled',
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ? AND status IN ('pending', 'waiting')
                """,
                (job_id,),
            )
            cancelled = int(cursor.rowcount) > 0

        if not cancelled:
            return

        if job.get("type") != "agent":
            return

        payload = job.get("payload") if isinstance(job.get("payload"), dict) else {}
        agent_id = job.get("external_id") or payload.get("agent_id") or payload.get("id")
        if agent_id:
            self.activate_dependents(str(agent_id), "cancelled")

    def force_cancel(self, job_id: int) -> bool:
        """Cancel a job regardless of current status (including running).

        Returns True if the job was cancelled, False if already terminal.
        """
        with self._conn() as conn:
            cursor = conn.execute(
                """
                UPDATE jobs SET
                    status = 'cancelled',
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ? AND status NOT IN ('completed', 'failed', 'cancelled')
                """,
                (job_id,),
            )
            cancelled = int(cursor.rowcount) > 0

        if not cancelled:
            return False

        # Activate dependents (they'll see "cancelled" and cascade-cancel)
        job = self.get(job_id)
        if job and job.get("type") == "agent":
            payload = job.get("payload") if isinstance(job.get("payload"), dict) else {}
            agent_id = job.get("external_id") or payload.get("agent_id") or payload.get("id")
            if agent_id:
                self.activate_dependents(str(agent_id), "cancelled")

        return True

    def force_cancel_all_running(self, job_type: str = "agent") -> int:
        """Cancel all pending/running/waiting jobs of a given type.

        Returns the number of jobs cancelled.
        """
        with self._conn() as conn:
            cursor = conn.execute(
                """
                UPDATE jobs SET
                    status = 'cancelled',
                    updated_at = CURRENT_TIMESTAMP
                WHERE type = ? AND status NOT IN ('completed', 'failed', 'cancelled')
                """,
                (job_type,),
            )
            count = int(cursor.rowcount)

        return count

    def get(self, job_id: int) -> dict | None:
        """Get a job by ID."""
        with self._conn() as conn:
            cursor = conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,))
            row = cursor.fetchone()
            return self._row_to_dict(row) if row else None

    def get_by_external_id(self, external_id: str, job_type: str | None = None) -> dict | None:
        """Get the most recent job for a given external_id."""
        query = "SELECT * FROM jobs WHERE external_id = ?"
        params: list[object] = [external_id]
        if job_type:
            query += " AND type = ?"
            params.append(job_type)
        query += " ORDER BY id DESC LIMIT 1"

        with self._conn() as conn:
            cursor = conn.execute(query, params)
            row = cursor.fetchone()
            return self._row_to_dict(row) if row else None

    def find_duplicate_agent(self, task_fingerprint: str, max_age_minutes: int = 60) -> dict | None:
        """
        Find a pending/running agent job with the same task fingerprint.

        Args:
            task_fingerprint: Hash of the normalized task description.
            max_age_minutes: Only consider jobs created within this window.

        Returns:
            The duplicate job dict if found, None otherwise.
        """
        with self._conn() as conn:
            # Search for agent jobs that are pending or running with matching fingerprint
            # Use SQLite datetime() for consistent timestamp comparison
            cursor = conn.execute(
                """
                SELECT * FROM jobs
                WHERE type = 'agent'
                AND status IN ('pending', 'running', 'waiting')
                AND datetime(created_at) > datetime('now', ?)
                ORDER BY created_at DESC
                """,
                (f"-{max_age_minutes} minutes",),
            )

            for row in cursor.fetchall():
                job = self._row_to_dict(row)
                if job:
                    payload = job.get("payload", {})
                    existing_fingerprint = payload.get("task_fingerprint")
                    if existing_fingerprint == task_fingerprint:
                        return job

            return None

    def set_pid(self, job_id: int, pid: int | None) -> None:
        """Set the OS pid for a running job (best-effort metadata)."""
        with self._conn() as conn:
            conn.execute(
                """
                UPDATE jobs SET
                    pid = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                """,
                (pid, job_id),
            )

    def heartbeat(self, job_id: int) -> bool:
        """Update locked_at timestamp to indicate job is still being processed.

        Should be called periodically by workers during long-running jobs
        to prevent stale lock recovery from re-grabbing the job.

        Returns True if heartbeat was recorded, False if job not found/not running.
        """
        now = datetime.now().isoformat()
        with self._conn() as conn:
            cursor = conn.execute(
                """
                UPDATE jobs SET
                    locked_at = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ? AND status = 'running'
                """,
                (now, job_id),
            )
            return cursor.rowcount > 0

    def list(
        self, status: str | None = None, job_type: str | None = None, limit: int = 50
    ) -> list[dict]:
        """List jobs with optional filters."""
        query = "SELECT * FROM jobs WHERE 1=1"
        params: list[object] = []

        if status:
            query += " AND status = ?"
            params.append(status)
        if job_type:
            query += " AND type = ?"
            params.append(job_type)

        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)

        with self._conn() as conn:
            cursor = conn.execute(query, params)
            return [self._row_to_dict(row) for row in cursor.fetchall()]

    def list_pipeline(self, pipeline_id: str) -> list[dict]:
        """List jobs for a pipeline, ordered by creation."""
        if not pipeline_id:
            return []
        with self._conn() as conn:
            cursor = conn.execute(
                """
                SELECT * FROM jobs
                WHERE pipeline_id = ?
                ORDER BY id ASC
                """,
                (pipeline_id,),
            )
            return [self._row_to_dict(row) for row in cursor.fetchall()]

    def list_pipelines(self, limit: int = 20) -> list[dict]:
        """List recent pipelines with status."""
        if limit <= 0:
            return []
        with self._conn() as conn:
            cursor = conn.execute(
                """
                SELECT pipeline_id, MAX(id) as last_id
                FROM jobs
                WHERE pipeline_id IS NOT NULL AND pipeline_id != ''
                GROUP BY pipeline_id
                ORDER BY last_id DESC
                LIMIT ?
                """,
                (limit,),
            )
            pipeline_ids = [row["pipeline_id"] for row in cursor.fetchall()]

        pipelines: list[dict] = []
        for pipeline_id in pipeline_ids:
            jobs = self.list_pipeline(pipeline_id)
            if not jobs:
                continue
            statuses = [job.get("status") or "unknown" for job in jobs]
            if any(status in ("failed", "cancelled") for status in statuses):
                overall = "failed"
            elif statuses and all(status == "completed" for status in statuses):
                overall = "completed"
            else:
                overall = "running"
            last_updated = max((job.get("updated_at") or "" for job in jobs), default="")
            pipelines.append(
                {
                    "pipeline_id": pipeline_id,
                    "status": overall,
                    "steps": len(jobs),
                    "last_updated": last_updated,
                }
            )
        return pipelines

    def cancel_pipeline(self, pipeline_id: str) -> int:
        """Cancel pending/waiting jobs for a pipeline."""
        if not pipeline_id:
            return 0
        with self._conn() as conn:
            cursor = conn.execute(
                """
                UPDATE jobs SET
                    status = 'cancelled',
                    locked_at = NULL,
                    locked_by = NULL,
                    pid = NULL,
                    updated_at = CURRENT_TIMESTAMP
                WHERE pipeline_id = ?
                AND status IN ('pending', 'waiting')
                """,
                (pipeline_id,),
            )
            return int(cursor.rowcount)

    def stats(self) -> dict:
        """Get queue statistics."""
        with self._conn() as conn:
            cursor = conn.execute(
                """
                SELECT status, COUNT(*) as count
                FROM jobs
                GROUP BY status
                """
            )
            counts = {row["status"]: row["count"] for row in cursor.fetchall()}

            cursor = conn.execute(
                """
                SELECT COUNT(*) as count FROM jobs
                WHERE status = 'pending'
                AND (run_at IS NULL OR run_at <= ?)
                """,
                (datetime.now().isoformat(),),
            )
            ready = cursor.fetchone()["count"]

            return {
                "pending": counts.get("pending", 0),
                "running": counts.get("running", 0),
                "completed": counts.get("completed", 0),
                "failed": counts.get("failed", 0),
                "cancelled": counts.get("cancelled", 0),
                "ready_now": ready,
            }

    def cleanup(self, days: int = 7) -> int:
        """Remove old completed/cancelled jobs."""
        cutoff = (datetime.now() - timedelta(days=days)).isoformat()
        with self._conn() as conn:
            cursor = conn.execute(
                """
                DELETE FROM jobs
                WHERE status IN ('completed', 'cancelled')
                AND updated_at < ?
                """,
                (cutoff,),
            )
            return int(cursor.rowcount)

    def _row_to_dict(self, row: sqlite3.Row | None) -> dict | None:
        if row is None:
            return None
        d = dict(row)
        d["payload"] = json.loads(d["payload"])
        d["job_type"] = d.get("type")
        return d


if __name__ == "__main__":
    # Simple debug CLI: python -m otto.jobs.queue stats
    import sys

    q = JobQueue()
    cmd = sys.argv[1] if len(sys.argv) > 1 else "stats"
    if cmd == "stats":
        print(json.dumps(q.stats(), indent=2))
    else:
        print("Supported: stats")
