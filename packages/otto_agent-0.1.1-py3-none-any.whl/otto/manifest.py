"""
CLI manifest generator for Otto.

Introspects the CLI to generate a structured representation of all available
commands. Used to keep documentation (brainfile, system prompts) in sync
with actual CLI capabilities.

Usage:
    otto tool manifest              # Text format
    otto tool manifest --json       # JSON format
    otto tool manifest --markdown   # Markdown format
    otto tool manifest --brainfile  # Brainfile CLI section format
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

import click
import typer


@dataclass
class CommandInfo:
    """Information about a CLI command."""

    name: str
    help: str
    parent: str = ""
    subcommands: list[CommandInfo] = field(default_factory=list)
    options: list[dict[str, str]] = field(default_factory=list)
    arguments: list[dict[str, str]] = field(default_factory=list)

    @property
    def full_name(self) -> str:
        """Get the full command path (e.g., 'agent spawn')."""
        if self.parent:
            # Remove "otto " prefix from parent if present
            parent = self.parent
            if parent.startswith("otto "):
                parent = parent[4:]
            if parent and parent != "otto":
                return f"{parent} {self.name}"
        return self.name

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary, recursively."""
        d = {
            "name": self.name,
            "full_name": self.full_name,
            "help": self.help,
        }
        if self.subcommands:
            d["subcommands"] = [sub.to_dict() for sub in self.subcommands]
        if self.options:
            d["options"] = self.options
        if self.arguments:
            d["arguments"] = self.arguments
        return d


def _extract_command_info(
    cmd: click.Command | click.Group,
    name: str,
    parent: str = "",
) -> CommandInfo:
    """Extract command information from a Click command."""
    help_text = cmd.help or cmd.short_help or ""
    # Clean up help text
    help_text = help_text.split("\n")[0].strip()

    info = CommandInfo(
        name=name,
        help=help_text,
        parent=parent,
    )

    # Extract options
    for param in cmd.params:
        if isinstance(param, click.Option):
            opt_names = "/".join(param.opts)
            opt_help = param.help or ""
            info.options.append({"name": opt_names, "help": opt_help})
        elif isinstance(param, click.Argument):
            info.arguments.append(
                {
                    "name": param.name or "",
                    "required": param.required,
                }
            )

    # Extract subcommands for groups
    if isinstance(cmd, click.Group):
        for sub_name, sub_cmd in sorted(cmd.commands.items()):
            # Skip hidden commands
            if getattr(sub_cmd, "hidden", False):
                continue
            sub_info = _extract_command_info(
                sub_cmd,
                sub_name,
                parent=info.full_name,
            )
            info.subcommands.append(sub_info)

    return info


def get_cli_manifest() -> CommandInfo:
    """Get the full CLI manifest by introspecting the otto CLI."""
    from otto.cli import app

    # Get the underlying Click command
    click_app = typer.main.get_command(app)

    return _extract_command_info(click_app, "otto")


def format_text(manifest: CommandInfo, indent: int = 0) -> str:
    """Format manifest as plain text tree."""
    lines = []
    prefix = "  " * indent

    if indent == 0:
        lines.append("Otto CLI Commands")
        lines.append("=" * 40)
        lines.append("")

    # Show this command
    if manifest.name != "otto" or indent > 0:
        help_text = f" - {manifest.help}" if manifest.help else ""
        lines.append(f"{prefix}otto {manifest.full_name}{help_text}")

    # Show subcommands
    for sub in manifest.subcommands:
        lines.extend(format_text(sub, indent + 1).split("\n"))

    return "\n".join(lines)


def format_json(manifest: CommandInfo) -> str:
    """Format manifest as JSON."""
    return json.dumps(manifest.to_dict(), indent=2)


def format_markdown(manifest: CommandInfo) -> str:
    """Format manifest as Markdown documentation."""
    lines = ["# Otto CLI Reference", ""]

    def _format_group(cmd: CommandInfo, level: int = 2) -> None:
        if cmd.subcommands:
            # This is a command group
            heading = "#" * level
            lines.append(
                f"{heading} otto {cmd.full_name}" if cmd.name != "otto" else f"{heading} Commands"
            )
            if cmd.help:
                lines.append(f"\n{cmd.help}\n")

            # List subcommands
            lines.append("| Command | Description |")
            lines.append("|---------|-------------|")
            for sub in cmd.subcommands:
                full = f"otto {sub.full_name}"
                lines.append(f"| `{full}` | {sub.help} |")
            lines.append("")

            # Recurse into subgroups
            for sub in cmd.subcommands:
                if sub.subcommands:
                    _format_group(sub, level + 1)

    _format_group(manifest)
    return "\n".join(lines)


def format_brainfile(manifest: CommandInfo) -> str:
    """Format manifest as brainfile CLI section."""
    lines = [
        "## CLI Reference",
        "",
        "Otto has a unified CLI: `otto`. Run `otto --help` or `otto <command> --help` for details.",
        "",
    ]

    # Group commands by category
    categories = {
        "service": ("Service Management", []),
        "agent": ("Sub-Agent Orchestration", []),
        "memory": ("Memory", []),
        "mcp": ("MCP Server Management", []),
        "skills": ("Skills", []),
        "config": ("Configuration", []),
        "job": ("Jobs", []),
        "tool": ("Utilities", []),
        "chat": ("Chat Platforms", []),
        "system": ("System", []),
        "vtt": ("Voice-to-Text", []),
    }

    # Find top-level groups
    for sub in manifest.subcommands:
        if sub.name in categories:
            categories[sub.name] = (categories[sub.name][0], sub.subcommands)

    for key, (title, cmds) in categories.items():
        if not cmds:
            continue

        lines.append(f"### {title}")
        lines.append("")
        lines.append("```bash")

        for cmd in cmds[:6]:  # Limit to 6 most important
            full_cmd = f"otto {cmd.full_name}"
            # Pad for alignment
            padded = full_cmd.ljust(35)
            lines.append(f"{padded} # {cmd.help}")

        lines.append("```")
        lines.append("")

    return "\n".join(lines)


def format_subagent_prompt(manifest: CommandInfo) -> str:
    """Format manifest as a system prompt section for sub-agents."""
    lines = [
        "<otto_cli_tools>",
        "You have access to the Otto CLI. Key commands:",
        "",
    ]

    # Most important commands for sub-agents
    important = [
        ("otto memory recall <query>", "Search Otto's memory"),
        ("otto memory remember <path> <text>", "Store information"),
        ("otto tool notify send <msg>", "Send notification to user"),
        ("otto tool research search <query>", "Web search"),
        ("otto mcp list", "List available MCP servers"),
        ("otto agent spawn -p <prompt>", "Spawn sub-agent"),
    ]

    for cmd, desc in important:
        lines.append(f"  {cmd} - {desc}")

    lines.append("")
    lines.append("Run `otto --help` for full command list.")
    lines.append("</otto_cli_tools>")

    return "\n".join(lines)


def generate_manifest(
    format: str = "text",
) -> str:
    """
    Generate CLI manifest in the specified format.

    Args:
        format: Output format - "text", "json", "markdown", "brainfile", or "prompt"

    Returns:
        Formatted manifest string
    """
    manifest = get_cli_manifest()

    formatters = {
        "text": format_text,
        "json": format_json,
        "markdown": format_markdown,
        "brainfile": format_brainfile,
        "prompt": format_subagent_prompt,
    }

    formatter = formatters.get(format, format_text)
    return formatter(manifest)
