"""
MCP server for Otto memory tools.

Exposes memory tools over MCP (stdio transport) with JSON responses.
"""

from __future__ import annotations

import asyncio
from datetime import datetime
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

from otto import memory as memory_index
from otto.mcp_tools import register_tools
from otto.paths import MEMORY_DIR
from otto_tools.memory import CATEGORIES, sanitize_topic, search_memory


def _ok(data: dict[str, Any]) -> dict[str, Any]:
    """Return a success response."""
    return {"success": True, "data": data, "error": None}


def _error(message: str) -> dict[str, Any]:
    """Return an error response."""
    return {"success": False, "data": None, "error": message}


def _ensure_memory_dir() -> Path:
    """Ensure memory directory exists and return it."""
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    return MEMORY_DIR


server = FastMCP("otto")
register_tools(server)


@server.tool()
async def memory_recall(query: str, limit: int = 10) -> dict[str, Any]:
    """
    Search file-based memory for matching content.

    Args:
        query: Search query string
        limit: Maximum results to return
    """
    try:
        if not query.strip():
            return _error("query is required")
        results = await asyncio.to_thread(search_memory, query, limit)
        return _ok({"query": query, "results": results})
    except Exception as exc:
        return _error(str(exc))


@server.tool()
async def memory_remember(category: str, topic: str, content: str) -> dict[str, Any]:
    """
    Store information in memory files.

    Args:
        category: Memory category (projects, facts, contexts)
        topic: Topic name
        content: Content to store
    """
    try:
        if category not in CATEGORIES:
            return _error(f"invalid category '{category}' (valid: {', '.join(CATEGORIES)})")
        if not content.strip():
            return _error("content is required")

        def _remember() -> dict[str, Any]:
            memory_dir = _ensure_memory_dir()
            cat_dir = memory_dir / category
            cat_dir.mkdir(parents=True, exist_ok=True)

            safe_topic = sanitize_topic(topic)
            file_path = cat_dir / f"{safe_topic}.md"
            timestamp = datetime.now().isoformat()

            if file_path.exists():
                file_path.write_text(
                    file_path.read_text() + f"\n\n---\n_Updated: {timestamp}_\n\n{content}"
                )
                action = "updated"
            else:
                file_path.write_text(f"# {topic}\n\n_Created: {timestamp}_\n\n{content}\n")
                action = "created"

            return {"action": action, "file": str(file_path)}

        result = await asyncio.to_thread(_remember)
        return _ok(result)
    except Exception as exc:
        return _error(str(exc))


@server.tool()
async def memory_list(category: str | None = None) -> dict[str, Any]:
    """
    List stored memory files.

    Args:
        category: Optional category filter
    """
    try:
        if category and category not in CATEGORIES:
            return _error(f"invalid category '{category}' (valid: {', '.join(CATEGORIES)})")

        def _list() -> dict[str, list[dict[str, Any]]]:
            memory_dir = _ensure_memory_dir()
            categories = [category] if category else CATEGORIES
            result: dict[str, list[dict[str, Any]]] = {}

            for cat in categories:
                cat_dir = memory_dir / cat
                if not cat_dir.exists():
                    continue

                files = []
                for file in sorted(cat_dir.glob("*.md")):
                    stat = file.stat()
                    files.append(
                        {
                            "name": file.stem,
                            "size": stat.st_size,
                            "modified": int(stat.st_mtime),
                        }
                    )
                if files:
                    result[cat] = files

            return result

        result = await asyncio.to_thread(_list)
        return _ok(result)
    except Exception as exc:
        return _error(str(exc))


@server.tool()
async def memory_forget(category: str, topic: str) -> dict[str, Any]:
    """
    Delete a memory file.

    Args:
        category: Memory category
        topic: Topic name
    """
    try:
        if category not in CATEGORIES:
            return _error(f"invalid category '{category}' (valid: {', '.join(CATEGORIES)})")

        def _forget() -> dict[str, Any] | None:
            memory_dir = _ensure_memory_dir()
            safe_topic = sanitize_topic(topic)
            file_path = memory_dir / category / f"{safe_topic}.md"

            if not file_path.exists():
                return None

            file_path.unlink()
            return {"deleted": str(file_path)}

        result = await asyncio.to_thread(_forget)
        if result is None:
            return _error(f"not_found: {MEMORY_DIR / category / f'{sanitize_topic(topic)}.md'}")
        return _ok(result)
    except Exception as exc:
        return _error(str(exc))


@server.tool()
async def memory_search_fts(
    query: str, limit: int = 5, source_types: list[str] | None = None
) -> dict[str, Any]:
    """
    Search indexed memory using FTS5.

    Args:
        query: Search query
        limit: Max results
        source_types: Optional filter (knowledge, project, session)
    """
    try:
        if not query.strip():
            return _error("query is required")
        results = await asyncio.to_thread(
            memory_index.search, query, limit=limit, source_types=source_types
        )
        return _ok({"query": query, "results": results})
    except Exception as exc:
        return _error(str(exc))


def run() -> None:
    """Run the MCP server on stdio."""
    server.run(transport="stdio")


if __name__ == "__main__":
    run()
