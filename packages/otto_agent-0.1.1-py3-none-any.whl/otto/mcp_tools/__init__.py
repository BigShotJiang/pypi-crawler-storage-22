"""MCP tool exports for Otto."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from .agent import (
    agent_list,
    agent_output,
    agent_spawn,
    pipeline_cancel,
    pipeline_list,
    pipeline_run,
    pipeline_status,
)
from .audit import audit_list, audit_search, audit_stats_tool
from .notify import notify_send
from .platform import edit_message, send_buttons, send_file, send_progress
from .registry import (
    registry_disable,
    registry_enable,
    registry_info,
    registry_install,
    registry_remove,
    registry_search,
)
from .schedule import schedule_cancel, schedule_list, schedule_task
from .session import session_list, session_new, session_switch

ToolFn = Callable[..., Awaitable[dict[str, Any]]]

ALL_TOOLS: tuple[ToolFn, ...] = (
    agent_spawn,
    agent_list,
    agent_output,
    pipeline_run,
    pipeline_status,
    pipeline_cancel,
    pipeline_list,
    notify_send,
    send_buttons,
    send_file,
    edit_message,
    send_progress,
    schedule_task,
    schedule_list,
    schedule_cancel,
    audit_list,
    audit_search,
    audit_stats_tool,
    registry_search,
    registry_install,
    registry_info,
    registry_remove,
    registry_disable,
    registry_enable,
    session_list,
    session_switch,
    session_new,
)


def register_tools(server: Any) -> None:
    """Register all MCP tools with a FastMCP server instance."""
    for tool in ALL_TOOLS:
        server.tool()(tool)


__all__ = [
    "agent_spawn",
    "agent_list",
    "agent_output",
    "pipeline_run",
    "pipeline_status",
    "pipeline_cancel",
    "pipeline_list",
    "notify_send",
    "send_buttons",
    "send_file",
    "edit_message",
    "send_progress",
    "schedule_task",
    "schedule_list",
    "schedule_cancel",
    "audit_list",
    "audit_search",
    "audit_stats_tool",
    "registry_search",
    "registry_install",
    "registry_info",
    "registry_remove",
    "registry_disable",
    "registry_enable",
    "session_list",
    "session_switch",
    "session_new",
    "register_tools",
    "ALL_TOOLS",
]
