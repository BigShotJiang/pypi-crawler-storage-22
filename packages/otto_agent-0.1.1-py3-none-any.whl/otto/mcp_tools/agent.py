"""MCP tools for agent orchestration."""

from __future__ import annotations

import asyncio
import hashlib
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from otto.backends import get_orchestration_config
from otto.jobs.queue import JobQueue
from otto.paths import OTTO_HOME, OUTPUTS_DIR, build_agent_system_prompt


def _ok(data: dict[str, Any]) -> dict[str, Any]:
    """Return a success response."""
    return {"success": True, "data": data, "error": None}


def _error(message: str) -> dict[str, Any]:
    """Return an error response."""
    return {"success": False, "data": None, "error": message}


def _display_path(path: Path) -> str:
    """Display path with home shortened to ~."""
    try:
        home = str(Path.home())
        text = str(path)
        if text.startswith(home):
            return text.replace(home, "~", 1)
        return text
    except Exception:
        return str(path)


def _to_iso(value: str | None) -> str | None:
    """Normalize timestamps to ISO-8601 with Z suffix when possible."""
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value)
    except ValueError:
        return value
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc).isoformat().replace("+00:00", "Z")
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _derive_task_name(prompt: str) -> str:
    """Derive a short task name from the prompt."""
    cleaned = " ".join(line.strip() for line in prompt.splitlines() if line.strip())
    if not cleaned:
        return "Untitled task"
    return cleaned[:120]


def _enqueue_agent_job(
    *,
    agent_id: str,
    prompt: str,
    task_name: str,
    backend: str,
    notify: bool,
    output_file: Path,
    system_prompt: str,
    priority: int,
    max_attempts: int,
    timeout: int | None,
    model: str | None = None,
    task_fingerprint: str | None = None,
    pipeline_id: str | None = None,
    step_id: str | None = None,
    depends_on_id: str | None = None,
    depends_on_status: str | None = None,
    extra_payload: dict[str, Any] | None = None,
) -> tuple[int, str]:
    queue = JobQueue()
    payload = {
        "agent_id": agent_id,
        "prompt": prompt,
        "system": system_prompt,
        "task": task_name,
        "backend": backend,
        "model": model,  # For dynamic routing (e.g., "openrouter/provider/model")
        "timeout": timeout,
        "notify": notify,
        "priority": "normal",
        "output_file": str(output_file),
    }
    if task_fingerprint:
        payload["task_fingerprint"] = task_fingerprint
    if extra_payload:
        payload.update(extra_payload)
    job_id = queue.add(
        "agent",
        payload,
        priority=priority,
        max_attempts=max_attempts,
        external_id=agent_id,
        pipeline_id=pipeline_id,
        step_id=step_id,
        depends_on_id=depends_on_id,
        depends_on_status=depends_on_status,
    )
    job = queue.get(job_id)
    status = job.get("status") if job else "pending"
    return job_id, status


def _get_job(job_id: int) -> dict[str, Any] | None:
    queue = JobQueue()
    return queue.get(job_id)


def _get_job_by_external_id(agent_id: str) -> dict[str, Any] | None:
    queue = JobQueue()
    return queue.get_by_external_id(agent_id, "agent")


def _list_agent_jobs(limit: int) -> list[dict[str, Any]]:
    queue = JobQueue()
    return queue.list(job_type="agent", limit=limit)


async def agent_spawn(
    prompt: str,
    backend: str = "claude",
    model: str | None = None,
    task_name: str | None = None,
    notify: bool = True,
    background: bool = True,
    session_id: str | None = None,
    chat_id: str | None = None,
) -> dict[str, Any]:
    """Spawn a background agent to handle a task.

    Args:
        prompt: The task prompt for the agent
        backend: Backend name ("claude", "codex")
        model: Optional model spec for dynamic routing (e.g., "openrouter/provider/model")
        task_name: Human-readable task description
        notify: Whether to notify on completion
        background: Run in background (True) or wait for completion (False)
    """
    try:
        if not prompt.strip():
            return _error("prompt is required")

        if task_name and task_name.strip():
            resolved_task = task_name.strip()
        else:
            resolved_task = _derive_task_name(prompt)

        # Auto-detect session_id and chat_id if not provided
        if not session_id or not chat_id:
            try:
                from otto import config as otto_config
                from otto.sessions import get_current_session

                if not chat_id:
                    state = otto_config.get_telegram_state()
                    chat_id = str(state.get("chat_id") or "")
                if chat_id and not session_id:
                    session = get_current_session(chat_id=chat_id)
                    session_id = session.get("id")
            except Exception:
                pass

        # Duplicate detection: match CLI behavior
        task_fingerprint = hashlib.sha256(prompt.strip().lower().encode()).hexdigest()[:16]
        queue = JobQueue()
        existing = await asyncio.to_thread(queue.find_duplicate_agent, task_fingerprint)
        if existing:
            existing_id = existing.get("external_id") or existing.get("payload", {}).get(
                "agent_id", "?"
            )
            existing_status = existing.get("status", "unknown")
            output_path = _resolve_output_path(existing_id, existing.get("payload"))
            return _ok(
                {
                    "agent_id": existing_id,
                    "backend": backend,
                    "model": model,
                    "task_name": resolved_task,
                    "status": existing_status,
                    "output_file": _display_path(output_path),
                    "duplicate": True,
                }
            )

        agent_id = uuid.uuid4().hex[:8]
        output_file = OUTPUTS_DIR / f"{agent_id}.txt"

        await asyncio.to_thread(output_file.parent.mkdir, parents=True, exist_ok=True)

        system_prompt = await asyncio.to_thread(build_agent_system_prompt)

        orch_config = await asyncio.to_thread(get_orchestration_config)
        timeout = orch_config.get("default_timeout", 3600)
        retry_cfg = orch_config.get("retry", {}) or {}
        max_retries = int(retry_cfg.get("max_retries", 3))
        if max_retries < 0:
            max_retries = 0
        max_attempts = 1 + max_retries

        # Include session context so completion events route back to the right session
        extra_session_payload: dict[str, Any] = {}
        if session_id:
            extra_session_payload["session_id"] = session_id
        if chat_id:
            extra_session_payload["chat_id"] = chat_id

        priority = 10 if not background else 0
        job_id, status = await asyncio.to_thread(
            _enqueue_agent_job,
            agent_id=agent_id,
            prompt=prompt,
            task_name=resolved_task,
            backend=backend,
            model=model,
            notify=notify,
            output_file=output_file,
            system_prompt=system_prompt,
            priority=priority,
            max_attempts=max_attempts,
            timeout=timeout,
            task_fingerprint=task_fingerprint,
            extra_payload=extra_session_payload if extra_session_payload else None,
        )

        if not background:
            proc = await asyncio.create_subprocess_exec(
                sys.executable,
                "-m",
                "otto.services.worker",
                "--once",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await proc.communicate()
            if proc.returncode != 0:
                detail = (stderr.decode() or stdout.decode()).strip()
                return _error(f"worker failed: {detail or 'unknown error'}")
            refreshed = await asyncio.to_thread(_get_job, job_id)
            if refreshed:
                status = refreshed.get("status") or status

        return _ok(
            {
                "agent_id": agent_id,
                "backend": backend,
                "model": model,
                "task_name": resolved_task,
                "status": status,
                "output_file": _display_path(output_file),
            }
        )
    except Exception as exc:
        return _error(str(exc))


def _load_legacy_agents() -> list[dict[str, Any]]:
    state_file = OTTO_HOME / "state.json"
    if not state_file.exists():
        return []
    try:
        import json

        state = json.loads(state_file.read_text())
        legacy = state.get("agents", [])
        if not isinstance(legacy, list):
            return []
        return [a for a in legacy if isinstance(a, dict)]
    except Exception:
        return []


async def agent_list(status: str | None = None, limit: int = 20) -> dict[str, Any]:
    """List agents with optional status filter."""
    try:
        normalized = status.lower() if status else None
        if normalized not in (None, "all", "running", "completed", "failed"):
            return _error("status must be running, completed, failed, or all")

        jobs = await asyncio.to_thread(_list_agent_jobs, max(limit, 1))

        agents: list[dict[str, Any]] = []
        if jobs:
            for job in jobs:
                payload = job.get("payload") or {}
                job_status = job.get("status") or "unknown"
                if normalized == "running" and job_status not in ("pending", "waiting", "running"):
                    continue
                if normalized == "completed" and job_status != "completed":
                    continue
                if normalized == "failed" and job_status != "failed":
                    continue

                output_path = payload.get("output_file") or str(
                    OUTPUTS_DIR / f"{job.get('external_id')}.txt"
                )
                agents.append(
                    {
                        "id": job.get("external_id")
                        or payload.get("agent_id")
                        or payload.get("id")
                        or str(job.get("id", "?")),
                        "backend": payload.get("backend") or "default",
                        "task_name": payload.get("task") or payload.get("task_description") or "",
                        "status": job_status,
                        "started_at": _to_iso(job.get("created_at")),
                        "completed_at": _to_iso(job.get("updated_at"))
                        if job_status in ("completed", "failed", "cancelled")
                        else None,
                        "output_file": _display_path(Path(output_path)),
                    }
                )
        else:
            legacy = await asyncio.to_thread(_load_legacy_agents)
            for agent in legacy:
                job_status = agent.get("status") or "unknown"
                if normalized == "running" and job_status not in ("pending", "waiting", "running"):
                    continue
                if normalized == "completed" and job_status != "completed":
                    continue
                if normalized == "failed" and job_status != "failed":
                    continue
                output_path = agent.get("output_file") or str(
                    OUTPUTS_DIR / f"{agent.get('id', '')}.txt"
                )
                agents.append(
                    {
                        "id": agent.get("id", "?"),
                        "backend": agent.get("backend", "unknown"),
                        "task_name": agent.get("task", ""),
                        "status": job_status,
                        "started_at": _to_iso(agent.get("started_at")),
                        "completed_at": _to_iso(agent.get("updated_at"))
                        if job_status in ("completed", "failed", "cancelled")
                        else None,
                        "output_file": _display_path(Path(output_path)),
                    }
                )

        if normalized in ("running", "completed", "failed"):
            agents = agents[:limit]

        return _ok({"agents": agents, "total": len(agents)})
    except Exception as exc:
        return _error(str(exc))


def _resolve_output_path(agent_id: str, payload: dict[str, Any] | None) -> Path:
    if payload:
        output = payload.get("output_file")
        if output:
            return Path(str(output)).expanduser()
    return OUTPUTS_DIR / f"{agent_id}.txt"


async def agent_output(agent_id: str, tail: int | None = None) -> dict[str, Any]:
    """Get output from an agent (running or completed)."""
    try:
        if not agent_id.strip():
            return _error("agent_id is required")

        job = await asyncio.to_thread(_get_job_by_external_id, agent_id)
        payload = job.get("payload") if job else None
        status = job.get("status") if job else "unknown"

        output_path = _resolve_output_path(agent_id, payload)
        exists = await asyncio.to_thread(output_path.exists)
        if not exists:
            return _error(f"output not found for agent {agent_id}")

        content = await asyncio.to_thread(output_path.read_text, encoding="utf-8")
        truncated = False
        if tail and tail > 0:
            lines = content.splitlines()
            if len(lines) > tail:
                truncated = True
            content = "\n".join(lines[-tail:])

        if status == "unknown" and content:
            status = "completed"

        return _ok(
            {
                "agent_id": agent_id,
                "status": status,
                "output": content,
                "output_file": _display_path(output_path),
                "truncated": truncated,
            }
        )
    except Exception as exc:
        return _error(str(exc))


async def pipeline_run(
    steps: list[dict], name: str | None = None, notify: bool = True
) -> dict[str, Any]:
    """
    Run a multi-step pipeline.

    Args:
        steps: List of step definitions with id, prompt, backend, depends_on
        name: Optional pipeline name
        notify: Whether to notify on completion (per-step)
    """
    try:
        if not isinstance(steps, list) or not steps:
            return _error("steps must be a non-empty list")

        normalized_steps: list[dict[str, Any]] = []
        seen_ids: set[str] = set()

        for raw in steps:
            if not isinstance(raw, dict):
                return _error("each step must be a dict")
            step_id = str(raw.get("id") or "").strip()
            if not step_id:
                return _error("step id is required")
            if step_id in seen_ids:
                return _error(f"duplicate step id '{step_id}'")
            prompt = str(raw.get("prompt") or "").strip()
            if not prompt:
                return _error(f"step '{step_id}' requires a prompt")
            backend = str(raw.get("backend") or "claude").strip() or "claude"
            depends_on = raw.get("depends_on") or []
            if isinstance(depends_on, str):
                depends_on = [depends_on]
            if not isinstance(depends_on, list):
                return _error(f"step '{step_id}' depends_on must be a list")
            depends_on = [str(d).strip() for d in depends_on if str(d).strip()]
            normalized_steps.append(
                {
                    "id": step_id,
                    "prompt": prompt,
                    "backend": backend,
                    "depends_on": depends_on,
                }
            )
            seen_ids.add(step_id)

        all_ids = {step["id"] for step in normalized_steps}
        for step in normalized_steps:
            for dep in step["depends_on"]:
                if dep not in all_ids:
                    return _error(f"step '{step['id']}' depends on unknown step '{dep}'")

        pipeline_id = uuid.uuid4().hex[:8]

        system_prompt = await asyncio.to_thread(build_agent_system_prompt)

        orch_config = await asyncio.to_thread(get_orchestration_config)
        timeout = orch_config.get("default_timeout", 3600)
        retry_cfg = orch_config.get("retry", {}) or {}
        max_retries = int(retry_cfg.get("max_retries", 3))
        if max_retries < 0:
            max_retries = 0
        max_attempts = 1 + max_retries

        await asyncio.to_thread(OUTPUTS_DIR.mkdir, parents=True, exist_ok=True)

        agent_ids = {step["id"]: uuid.uuid4().hex[:8] for step in normalized_steps}
        results: list[dict[str, str]] = []

        for idx, step in enumerate(normalized_steps):
            step_id = step["id"]
            agent_id = agent_ids[step_id]
            output_file = OUTPUTS_DIR / f"{agent_id}.txt"
            depends_on_ids = [agent_ids[dep] for dep in step["depends_on"]]
            depends_on_id = depends_on_ids[0] if depends_on_ids else None
            depends_on_status = "success" if depends_on_ids else None
            extra_payload: dict[str, Any] = {
                "pipeline_id": pipeline_id,
                "step_id": step_id,
            }
            if name:
                extra_payload["pipeline_name"] = name
            if len(depends_on_ids) > 1:
                extra_payload["_depends_on_all"] = depends_on_ids

            # Only notify on the last step to avoid duplicate notifications
            is_last_step = idx == len(normalized_steps) - 1
            step_notify = notify and is_last_step

            job_id, _status = await asyncio.to_thread(
                _enqueue_agent_job,
                agent_id=agent_id,
                prompt=step["prompt"],
                task_name=_derive_task_name(step["prompt"]),
                backend=step["backend"],
                notify=step_notify,
                output_file=output_file,
                system_prompt=system_prompt,
                priority=0,
                max_attempts=max_attempts,
                timeout=timeout,
                pipeline_id=pipeline_id,
                step_id=step_id,
                depends_on_id=depends_on_id,
                depends_on_status=depends_on_status,
                extra_payload=extra_payload,
            )

            results.append({"id": step_id, "job_id": str(job_id)})

        return _ok({"pipeline_id": pipeline_id, "steps": results})
    except Exception as exc:
        return _error(str(exc))


async def pipeline_status(pipeline_id: str) -> dict[str, Any]:
    """
    Get status of all steps in a pipeline.
    """
    try:
        if not pipeline_id or not pipeline_id.strip():
            return _error("pipeline_id is required")

        queue = JobQueue()
        jobs = await asyncio.to_thread(queue.list_pipeline, pipeline_id.strip())
        if not jobs:
            return _error(f"pipeline not found: {pipeline_id}")

        steps = []
        statuses = []
        for job in jobs:
            payload = job.get("payload") if isinstance(job.get("payload"), dict) else {}
            step_id = job.get("step_id") or payload.get("step_id") or ""
            agent_id = job.get("external_id") or payload.get("agent_id") or ""
            output_path = _resolve_output_path(agent_id, payload)
            job_status = job.get("status") or "unknown"
            statuses.append(job_status)
            steps.append(
                {
                    "id": step_id,
                    "job_id": str(job.get("id")),
                    "status": job_status,
                    "output_file": _display_path(output_path),
                }
            )

        if any(status in ("failed", "cancelled") for status in statuses):
            overall = "failed"
        elif statuses and all(status == "completed" for status in statuses):
            overall = "completed"
        else:
            overall = "running"

        return _ok({"pipeline_id": pipeline_id, "status": overall, "steps": steps})
    except Exception as exc:
        return _error(str(exc))


async def pipeline_list(limit: int = 20) -> dict[str, Any]:
    """List recent pipelines with status."""
    try:
        if limit is None:
            limit = 20
        limit = int(limit)
        if limit <= 0:
            return _ok({"pipelines": []})

        queue = JobQueue()
        pipelines = await asyncio.to_thread(queue.list_pipelines, limit)
        for pipe in pipelines:
            pipe["last_updated"] = _to_iso(pipe.get("last_updated"))
        return _ok({"pipelines": pipelines})
    except Exception as exc:
        return _error(str(exc))


async def pipeline_cancel(pipeline_id: str) -> dict[str, Any]:
    """Cancel all pending/waiting steps in a pipeline."""
    try:
        if not pipeline_id or not pipeline_id.strip():
            return _error("pipeline_id is required")

        queue = JobQueue()
        cancelled = await asyncio.to_thread(queue.cancel_pipeline, pipeline_id.strip())
        return _ok({"pipeline_id": pipeline_id, "cancelled": cancelled})
    except Exception as exc:
        return _error(str(exc))
