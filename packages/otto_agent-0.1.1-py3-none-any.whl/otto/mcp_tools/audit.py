"""MCP tools for querying the audit log."""

from __future__ import annotations

from typing import Any


async def audit_list(
    limit: int = 20,
    audit_type: str | None = None,
    server: str | None = None,
    tool: str | None = None,
    verdict: str | None = None,
) -> dict[str, Any]:
    """
    List recent audit log entries with optional filters.

    Args:
        limit: Maximum entries to return (default 20, max 100)
        audit_type: Filter by type (message, action, security, agent, error, system)
        server: Filter by MCP server name
        tool: Filter by tool name
        verdict: Filter by verdict (allow, deny, prompt)

    Returns:
        List of audit entries (newest first)
    """
    from otto.audit import query_audit

    try:
        limit = min(max(1, limit), 100)
        entries = query_audit(
            audit_type=audit_type,
            server=server,
            tool=tool,
            verdict=verdict,
            limit=limit,
        )
        return {
            "success": True,
            "data": {"entries": entries, "count": len(entries)},
            "error": None,
        }
    except Exception as exc:
        return {"success": False, "data": None, "error": str(exc)}


async def audit_search(
    query: str,
    limit: int = 30,
) -> dict[str, Any]:
    """
    Search audit log entries by keyword.

    Args:
        query: Search term to match against events, errors, servers, tools
        limit: Maximum entries to return (default 30, max 100)

    Returns:
        Matching audit entries
    """
    from otto.audit import query_audit

    try:
        if not query or not query.strip():
            return {"success": False, "data": None, "error": "query is required"}
        limit = min(max(1, limit), 100)
        entries = query_audit(search=query.strip(), limit=limit)
        return {
            "success": True,
            "data": {"entries": entries, "count": len(entries), "query": query.strip()},
            "error": None,
        }
    except Exception as exc:
        return {"success": False, "data": None, "error": str(exc)}


async def audit_stats_tool() -> dict[str, Any]:
    """
    Get audit log statistics summary.

    Returns:
        Statistics including total entries, denials, breakdowns by verdict/server/type
    """
    from otto.audit import audit_stats

    try:
        stats = audit_stats()
        return {"success": True, "data": stats, "error": None}
    except Exception as exc:
        return {"success": False, "data": None, "error": str(exc)}
