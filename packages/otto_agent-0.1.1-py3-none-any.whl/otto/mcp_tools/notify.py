"""MCP tools for notifications."""

from __future__ import annotations

from typing import Any

from otto_tools.config import get_chat_id, get_telegram_token
from otto_tools.notify import chunk_message


def _ok(data: dict[str, Any]) -> dict[str, Any]:
    """Return a success response."""
    return {"success": True, "data": data, "error": None}


def _error(message: str) -> dict[str, Any]:
    """Return an error response."""
    return {"success": False, "data": None, "error": message}


async def notify_send(
    message: str,
    chat_id: str | None = None,
    platform: str = "telegram",
) -> dict[str, Any]:
    """Send a notification message to the user."""
    try:
        if not message or not message.strip():
            return _error("message is required")

        if platform.lower() != "telegram":
            return _error(f"unsupported platform: {platform}")

        try:
            from telegram import Bot
            from telegram.constants import ParseMode
        except ImportError:
            return _error("python-telegram-bot not installed. Run: pip install python-telegram-bot")

        token = get_telegram_token()
        if not token:
            return _error("TELEGRAM_BOT_TOKEN not found in environment or ~/.otto/config/.env")

        resolved_chat_id: int | None
        if chat_id is not None:
            try:
                resolved_chat_id = int(str(chat_id).strip())
            except ValueError:
                return _error("chat_id must be an integer")
        else:
            resolved_chat_id = get_chat_id()

        if not resolved_chat_id:
            return _error("No chat_id registered. Message the bot with /start first.")

        bot = Bot(token=token)
        chunks = chunk_message(message)
        message_id: int | None = None

        for chunk in chunks:
            sent = await bot.send_message(
                chat_id=resolved_chat_id,
                text=chunk,
                parse_mode=ParseMode.HTML,
            )
            message_id = sent.message_id

        return _ok({"sent": True, "message_id": message_id, "platform": "telegram"})
    except Exception as exc:
        return _error(str(exc))
