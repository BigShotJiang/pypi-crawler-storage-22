"""MCP tools for chat platform actions."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from otto.chat.base import ChatPlatform, PlatformCapabilities
from otto_tools.config import get_chat_id, get_telegram_token


class _TelegramBotPlatform(ChatPlatform):
    """Lightweight Telegram platform adapter for MCP tools."""

    name = "telegram"
    capabilities = PlatformCapabilities(
        inline_keyboards=True,
        buttons=True,
        rich_formatting=True,
        voice_messages=True,
        file_attachments=True,
        photos=True,
        edit_messages=True,
        reactions=False,
        typing_indicator=True,
        max_message_length=4096,
    )

    def __init__(self) -> None:
        try:
            from telegram import Bot
        except ImportError as exc:  # pragma: no cover - handled by caller
            raise RuntimeError(
                "python-telegram-bot not installed. Run: pip install python-telegram-bot"
            ) from exc

        token = get_telegram_token()
        if not token:
            raise RuntimeError("TELEGRAM_BOT_TOKEN not found in environment or ~/.otto/config/.env")

        self._bot = Bot(token=token)

    async def send_message(
        self,
        chat_id: str,
        text: str,
        parse_mode: str | None = None,
        reply_markup: Any = None,
        **kwargs,
    ) -> Any:
        return await self._bot.send_message(
            chat_id=int(chat_id),
            text=text,
            parse_mode=parse_mode,
            reply_markup=reply_markup,
            **kwargs,
        )

    async def send_typing(self, chat_id: str) -> None:
        from telegram.constants import ChatAction

        await self._bot.send_chat_action(chat_id=int(chat_id), action=ChatAction.TYPING)

    async def edit_message(self, chat_id: str, message_id: str, text: str, **kwargs) -> Any:
        return await self._bot.edit_message_text(
            chat_id=int(chat_id),
            message_id=int(message_id),
            text=text,
            parse_mode=kwargs.get("parse_mode"),
            **{k: v for k, v in kwargs.items() if k != "parse_mode"},
        )

    async def send_file(
        self, chat_id: str, file_path: Path, caption: str | None = None, **kwargs
    ) -> Any:
        with open(file_path, "rb") as f:
            return await self._bot.send_document(
                chat_id=int(chat_id),
                document=f,
                caption=caption,
                **kwargs,
            )

    async def download_file(self, file_id: str, destination: Path) -> Path:
        file = await self._bot.get_file(file_id)
        await file.download_to_drive(destination)
        return destination

    async def start(self) -> None:  # pragma: no cover - not used in MCP
        return None

    async def stop(self) -> None:  # pragma: no cover - not used in MCP
        return None


def _ok(data: dict[str, Any]) -> dict[str, Any]:
    """Return a success response."""
    return {"success": True, "data": data, "error": None}


def _error(message: str) -> dict[str, Any]:
    """Return an error response."""
    return {"success": False, "data": None, "error": message}


def _resolve_chat_id(chat_id: str | None) -> str | None:
    if chat_id is not None:
        cleaned = str(chat_id).strip()
        return cleaned or None
    resolved = get_chat_id()
    if resolved is None:
        return None
    return str(resolved)


async def _get_platform(name: str) -> ChatPlatform:
    normalized = (name or "telegram").strip().lower()
    if normalized == "telegram":
        return _TelegramBotPlatform()
    raise RuntimeError(f"unsupported platform: {name}")


async def send_buttons(
    text: str,
    buttons: list[dict[str, str]],
    chat_id: str | None = None,
    platform: str = "telegram",
    columns: int = 2,
) -> dict[str, Any]:
    """Send a message with interactive buttons to the current chat."""
    try:
        if not text or not text.strip():
            return _error("text is required")
        if not buttons:
            return _error("buttons are required")
        if columns < 1:
            return _error("columns must be >= 1")

        resolved_chat_id = _resolve_chat_id(chat_id)
        if not resolved_chat_id:
            return _error("No chat_id registered. Message the bot with /start first.")

        try:
            from telegram import InlineKeyboardButton, InlineKeyboardMarkup
            from telegram.constants import ParseMode
        except ImportError:
            return _error("python-telegram-bot not installed. Run: pip install python-telegram-bot")

        platform_impl = await _get_platform(platform)
        if not platform_impl.capabilities.buttons:
            return _error(f"platform '{platform}' does not support buttons")
        if not platform_impl.capabilities.inline_keyboards:
            return _error(f"platform '{platform}' does not support inline keyboards")

        keyboard_buttons: list[InlineKeyboardButton] = []
        for btn in buttons:
            label = (btn or {}).get("label")
            callback_data = (btn or {}).get("callback_data")
            if not label or not callback_data:
                return _error("each button requires 'label' and 'callback_data'")
            keyboard_buttons.append(
                InlineKeyboardButton(str(label), callback_data=str(callback_data))
            )

        rows = [keyboard_buttons[i : i + columns] for i in range(0, len(keyboard_buttons), columns)]
        markup = InlineKeyboardMarkup(rows)

        sent = await platform_impl.send_message(
            resolved_chat_id,
            text.strip(),
            parse_mode=ParseMode.HTML,
            reply_markup=markup,
        )
        message_id = getattr(sent, "message_id", None)
        return _ok({"sent": True, "message_id": message_id, "platform": platform_impl.name})
    except Exception as exc:
        return _error(str(exc))


async def send_file(
    file_path: str,
    caption: str | None = None,
    chat_id: str | None = None,
    platform: str = "telegram",
) -> dict[str, Any]:
    """Send a file to the current chat."""
    try:
        if not file_path or not str(file_path).strip():
            return _error("file_path is required")

        resolved_chat_id = _resolve_chat_id(chat_id)
        if not resolved_chat_id:
            return _error("No chat_id registered. Message the bot with /start first.")

        platform_impl = await _get_platform(platform)
        if not platform_impl.capabilities.file_attachments:
            return _error(f"platform '{platform}' does not support file attachments")

        path = Path(file_path).expanduser()
        if not path.exists():
            return _error(f"file not found: {path}")
        if not path.is_file():
            return _error(f"not a file: {path}")

        sent = await platform_impl.send_file(resolved_chat_id, path, caption=caption)
        message_id = getattr(sent, "message_id", None)
        return _ok({"sent": True, "message_id": message_id, "platform": platform_impl.name})
    except Exception as exc:
        return _error(str(exc))


async def edit_message(
    message_id: str,
    text: str,
    chat_id: str | None = None,
    platform: str = "telegram",
) -> dict[str, Any]:
    """Edit a previously sent message."""
    try:
        if not message_id or not str(message_id).strip():
            return _error("message_id is required")
        if not text or not text.strip():
            return _error("text is required")

        resolved_chat_id = _resolve_chat_id(chat_id)
        if not resolved_chat_id:
            return _error("No chat_id registered. Message the bot with /start first.")

        platform_impl = await _get_platform(platform)
        if not platform_impl.capabilities.edit_messages:
            return _error(f"platform '{platform}' does not support message editing")

        await platform_impl.edit_message(resolved_chat_id, str(message_id).strip(), text.strip())
        return _ok({"edited": True, "message_id": message_id, "platform": platform_impl.name})
    except Exception as exc:
        return _error(str(exc))


async def send_progress(
    text: str,
    message_id: str | None = None,
    chat_id: str | None = None,
    platform: str = "telegram",
) -> dict[str, Any]:
    """Send or update a progress indicator."""
    try:
        if not text or not text.strip():
            return _error("text is required")

        resolved_chat_id = _resolve_chat_id(chat_id)
        if not resolved_chat_id:
            return _error("No chat_id registered. Message the bot with /start first.")

        platform_impl = await _get_platform(platform)

        if message_id and platform_impl.capabilities.edit_messages:
            await platform_impl.edit_message(
                resolved_chat_id, str(message_id).strip(), text.strip()
            )
            return _ok(
                {
                    "updated": True,
                    "message_id": message_id,
                    "platform": platform_impl.name,
                }
            )

        sent = await platform_impl.send_message(resolved_chat_id, text.strip())
        new_message_id = getattr(sent, "message_id", None)
        return _ok({"sent": True, "message_id": new_message_id, "platform": platform_impl.name})
    except Exception as exc:
        return _error(str(exc))
