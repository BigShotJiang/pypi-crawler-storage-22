"""MCP tools for searching and installing from the MCP server registry."""

from __future__ import annotations

from typing import Any


async def registry_search(
    query: str,
    limit: int = 10,
) -> dict[str, Any]:
    """
    Search the MCP server registry for servers matching a query.

    Searches the official modelcontextprotocol.io registry. This is optional —
    Otto works fully without registry access using local catalog and manual config.

    Args:
        query: Search term (matches against server names)
        limit: Maximum results to return (default 10, max 50)

    Returns:
        List of matching servers with trust scores and install info
    """
    try:
        from otto.registry import (
            RegistryClient,
            RegistryUnavailableError,
            format_search_results,
        )

        if not query or not query.strip():
            return {"success": False, "data": None, "error": "query is required"}

        limit = min(max(1, limit), 50)
        client = RegistryClient()

        try:
            servers = await client.search(query.strip(), limit=limit)
        except RegistryUnavailableError as exc:
            return {
                "success": False,
                "data": None,
                "error": f"Registry unavailable: {exc}. Use local catalog instead.",
            }

        # Convert to serializable format
        results = []
        for s in servers:
            entry: dict[str, Any] = {
                "name": s.name,
                "display_name": s.display_name,
                "description": s.description,
                "version": s.version,
                "repository_url": s.repository_url,
            }
            if s.trust:
                entry["trust"] = {
                    "score": s.trust.score,
                    "level": s.trust.level.value,
                    "icon": s.trust.icon,
                    "reasons": list(s.trust.reasons),
                    "in_catalog": s.trust.in_catalog,
                }

            pkg = s.stdio_package
            if pkg:
                entry["package"] = {
                    "registry": pkg.get("registryType", ""),
                    "identifier": pkg.get("identifier", ""),
                }

            results.append(entry)

        return {
            "success": True,
            "data": {
                "servers": results,
                "count": len(results),
                "query": query.strip(),
                "formatted": format_search_results(servers, max_display=limit),
            },
            "error": None,
        }
    except Exception as exc:
        return {"success": False, "data": None, "error": str(exc)}


async def registry_install(
    server_name: str,
    local_name: str | None = None,
    enabled: bool = True,
    apply_policy: bool = True,
) -> dict[str, Any]:
    """
    Install a server from the MCP registry into Otto's gateway config.

    Fetches the server from the registry, converts it to Otto config format,
    and saves to settings.yaml. Optionally applies trust-based gateway policies.

    Args:
        server_name: Full registry server name (e.g., io.github.org/server-name)
        local_name: Override the local config name (default: derived from server name)
        enabled: Whether to enable the server immediately (default: true)
        apply_policy: Whether to auto-apply trust-based policy (default: true)

    Returns:
        Installation result with details
    """
    try:
        from otto.registry import (
            RegistryClient,
            RegistryUnavailableError,
            install_from_registry,
        )

        if not server_name or not server_name.strip():
            return {"success": False, "data": None, "error": "server_name is required"}

        client = RegistryClient()

        try:
            server = await client.get_server(server_name.strip())
        except RegistryUnavailableError as exc:
            return {
                "success": False,
                "data": None,
                "error": f"Registry unavailable: {exc}",
            }

        if server is None:
            return {
                "success": False,
                "data": None,
                "error": f"Server '{server_name}' not found in registry",
            }

        ok, msg = install_from_registry(
            server,
            server_name=local_name,
            enabled=enabled,
            apply_policy=apply_policy,
        )

        return {
            "success": ok,
            "data": {
                "server_name": server_name,
                "local_name": local_name or server.short_name,
                "message": msg,
                "trust": {
                    "score": server.trust.score,
                    "level": server.trust.level.value,
                    "icon": server.trust.icon,
                }
                if server.trust
                else None,
            }
            if ok
            else {"message": msg},
            "error": None if ok else msg,
        }
    except Exception as exc:
        return {"success": False, "data": None, "error": str(exc)}


async def registry_info(
    server_name: str,
) -> dict[str, Any]:
    """
    Get detailed info about a specific server from the MCP registry.

    Args:
        server_name: Full registry server name to look up

    Returns:
        Detailed server information including trust score, packages, and policy suggestion
    """
    try:
        from otto.registry import (
            RegistryClient,
            RegistryUnavailableError,
            suggest_policy_for_server,
        )

        if not server_name or not server_name.strip():
            return {"success": False, "data": None, "error": "server_name is required"}

        client = RegistryClient()

        try:
            server = await client.get_server(server_name.strip())
        except RegistryUnavailableError as exc:
            return {
                "success": False,
                "data": None,
                "error": f"Registry unavailable: {exc}",
            }

        if server is None:
            return {
                "success": False,
                "data": None,
                "error": f"Server '{server_name}' not found in registry",
            }

        # Build detailed response
        info: dict[str, Any] = {
            "name": server.name,
            "display_name": server.display_name,
            "description": server.description,
            "version": server.version,
            "repository_url": server.repository_url,
            "website_url": server.website_url,
            "published_at": server.published_at,
            "updated_at": server.updated_at,
            "packages": [],
        }

        for pkg in server.packages:
            info["packages"].append(
                {
                    "registry": pkg.get("registryType", ""),
                    "identifier": pkg.get("identifier", ""),
                    "version": pkg.get("version", ""),
                    "transport": pkg.get("transport", {}),
                    "env_vars": [
                        {"name": v.get("name", ""), "required": v.get("isRequired", False)}
                        for v in pkg.get("environmentVariables", [])
                        if isinstance(v, dict)
                    ],
                }
            )

        if server.trust:
            info["trust"] = {
                "score": server.trust.score,
                "level": server.trust.level.value,
                "icon": server.trust.icon,
                "reasons": list(server.trust.reasons),
                "in_catalog": server.trust.in_catalog,
                "namespace_verified": server.trust.namespace_verified,
            }

        info["suggested_policy"] = suggest_policy_for_server(server)

        return {"success": True, "data": info, "error": None}
    except Exception as exc:
        return {"success": False, "data": None, "error": str(exc)}


async def registry_remove(
    server_name: str,
) -> dict[str, Any]:
    """
    Remove an MCP server from Otto's gateway config.

    Completely removes the server and its policy. The server's tools become
    immediately unavailable — no restart needed.

    Args:
        server_name: Local server name as it appears in gateway.servers
                     (e.g., "exa", "filesystem", "github")

    Returns:
        Removal result with details
    """
    try:
        from otto.catalog import remove_server

        if not server_name or not server_name.strip():
            return {"success": False, "data": None, "error": "server_name is required"}

        ok, msg = remove_server(server_name.strip())
        return {
            "success": ok,
            "data": {"server_name": server_name, "message": msg} if ok else None,
            "error": None if ok else msg,
        }
    except Exception as exc:
        return {"success": False, "data": None, "error": str(exc)}


async def registry_disable(
    server_name: str,
) -> dict[str, Any]:
    """
    Disable an MCP server without removing it from config.

    The server remains in settings.yaml but its tools become immediately
    unavailable. Use registry_install with the same name to re-enable.

    Args:
        server_name: Local server name to disable

    Returns:
        Result with details
    """
    try:
        from otto.config import get_setting, set_setting
        from otto.gateway import reload_gateway

        if not server_name or not server_name.strip():
            return {"success": False, "data": None, "error": "server_name is required"}

        name = server_name.strip()
        existing = get_setting(f"gateway.servers.{name}")
        if not existing:
            return {
                "success": False,
                "data": None,
                "error": f"'{name}' not found in gateway.servers",
            }

        set_setting(f"gateway.servers.{name}.enabled", False)

        try:
            reload_gateway()
        except Exception:
            pass  # Best effort — config is already saved

        return {
            "success": True,
            "data": {"server_name": name, "message": f"'{name}' disabled"},
            "error": None,
        }
    except Exception as exc:
        return {"success": False, "data": None, "error": str(exc)}


async def registry_enable(
    server_name: str,
) -> dict[str, Any]:
    """
    Re-enable a previously disabled MCP server.

    The server's tools become immediately available — no restart needed.

    Args:
        server_name: Local server name to enable

    Returns:
        Result with details
    """
    try:
        from otto.config import get_setting, set_setting
        from otto.gateway import reload_gateway

        if not server_name or not server_name.strip():
            return {"success": False, "data": None, "error": "server_name is required"}

        name = server_name.strip()
        existing = get_setting(f"gateway.servers.{name}")
        if not existing:
            return {
                "success": False,
                "data": None,
                "error": f"'{name}' not found in gateway.servers",
            }

        set_setting(f"gateway.servers.{name}.enabled", True)

        try:
            reload_gateway()
        except Exception:
            pass  # Best effort

        return {
            "success": True,
            "data": {"server_name": name, "message": f"'{name}' enabled"},
            "error": None,
        }
    except Exception as exc:
        return {"success": False, "data": None, "error": str(exc)}
