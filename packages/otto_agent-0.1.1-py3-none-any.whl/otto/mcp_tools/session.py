"""MCP tools for session management."""

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import Any

from otto import sessions


def _ok(data: dict[str, Any]) -> dict[str, Any]:
    return {"success": True, "data": data, "error": None}


def _error(message: str) -> dict[str, Any]:
    return {"success": False, "data": None, "error": message}


def _resolve_chat_id(chat_id: str | None) -> str | None:
    """Resolve chat_id, falling back to current Telegram state."""
    if chat_id:
        return chat_id
    try:
        from otto import config as otto_config

        state = otto_config.get_telegram_state()
        return str(state.get("chat_id") or "") or None
    except Exception:
        return None


def _humanize_age(iso_ts: str | None) -> str:
    """Convert an ISO timestamp to a human-readable age string."""
    if not iso_ts:
        return "unknown"
    try:
        created = datetime.fromisoformat(iso_ts)
        delta = datetime.now() - created
        seconds = int(delta.total_seconds())
        if seconds < 60:
            return "just now"
        if seconds < 3600:
            mins = seconds // 60
            return f"{mins}m ago"
        if seconds < 86400:
            hours = seconds // 3600
            return f"{hours}h ago"
        days = seconds // 86400
        return f"{days}d ago"
    except (ValueError, TypeError):
        return "unknown"


def _session_summary(session: dict[str, Any]) -> dict[str, Any]:
    """Build a compact session summary for tool responses."""
    # Use last_activity (last message time) for age, fall back to created
    activity_ts = session.get("last_activity") or session.get("created")
    return {
        "id": session.get("id"),
        "topic": session.get("topic") or "(untitled)",
        "created": session.get("created"),
        "last_activity": activity_ts,
        "age": _humanize_age(activity_ts),
        "message_count": session.get("message_count", 0),
        "is_current": session.get("is_current", False),
        "archived": session.get("archived"),
    }


async def session_list(
    limit: int = 10,
    chat_id: str | None = None,
) -> dict[str, Any]:
    """List recent sessions with topic, age, and message count.

    Args:
        limit: Maximum number of sessions to return
        chat_id: Chat ID to scope to (auto-detected if omitted)
    """
    try:
        if limit is None:
            limit = 10
        limit = int(limit)
        if limit <= 0:
            return _ok({"sessions": [], "total": 0})

        resolved_chat_id = _resolve_chat_id(chat_id)

        all_sessions = await asyncio.to_thread(
            sessions.list_sessions, include_current=True, chat_id=resolved_chat_id
        )

        # Apply limit
        trimmed = all_sessions[:limit]

        items = [_session_summary(s) for s in trimmed]

        return _ok({"sessions": items, "total": len(all_sessions)})
    except Exception as exc:
        return _error(str(exc))


async def session_switch(
    session_id: str | None = None,
    query: str | None = None,
    chat_id: str | None = None,
) -> dict[str, Any]:
    """Switch to a different session by ID or fuzzy search.

    If session_id is provided, switches directly.
    If query is provided, searches session topics and content:
      - 1 match: auto-switches
      - Multiple matches: returns candidates for the LLM to pick

    Args:
        session_id: Exact session ID to switch to
        query: Fuzzy search term to find a session by topic/content
        chat_id: Chat ID to scope to (auto-detected if omitted)
    """
    try:
        if not session_id and not query:
            return _error("either session_id or query is required")

        resolved_chat_id = _resolve_chat_id(chat_id)

        # Direct switch by ID
        if session_id:
            session_id = session_id.strip()
            if not session_id:
                return _error("session_id must not be empty")

            loaded = await asyncio.to_thread(
                sessions.load_session, session_id, chat_id=resolved_chat_id
            )
            if loaded is None:
                return _error(f"session not found: {session_id}")

            return _ok(
                {
                    "switched": True,
                    "session": {
                        "id": loaded.get("id"),
                        "topic": loaded.get("topic") or "(untitled)",
                        "created": loaded.get("created"),
                        "message_count": loaded.get("metadata", {}).get(
                            "message_count", len(loaded.get("messages", []))
                        ),
                    },
                }
            )

        # Fuzzy search by query
        query_lower = query.strip().lower()
        if not query_lower:
            return _error("query must not be empty")

        all_sessions = await asyncio.to_thread(
            sessions.list_sessions, include_current=True, chat_id=resolved_chat_id
        )

        # Score matches: check topic and session ID
        matches: list[dict[str, Any]] = []
        for s in all_sessions:
            topic = (s.get("topic") or "").lower()
            sid = (s.get("id") or "").lower()

            # Skip current session — no point switching to it
            if s.get("is_current"):
                continue

            # Check if query appears in topic or ID
            if query_lower in topic or query_lower in sid:
                matches.append(s)

        if not matches:
            return _ok(
                {
                    "switched": False,
                    "reason": "no_matches",
                    "query": query,
                    "message": f"No sessions found matching '{query}'",
                }
            )

        if len(matches) == 1:
            # Single match — auto-switch
            target = matches[0]
            loaded = await asyncio.to_thread(
                sessions.load_session, target["id"], chat_id=resolved_chat_id
            )
            if loaded is None:
                return _error(f"session not found: {target['id']}")

            return _ok(
                {
                    "switched": True,
                    "session": {
                        "id": loaded.get("id"),
                        "topic": loaded.get("topic") or "(untitled)",
                        "created": loaded.get("created"),
                        "message_count": loaded.get("metadata", {}).get(
                            "message_count", len(loaded.get("messages", []))
                        ),
                    },
                }
            )

        # Multiple matches — return candidates
        candidates = [_session_summary(s) for s in matches[:10]]
        return _ok(
            {
                "switched": False,
                "reason": "multiple_matches",
                "query": query,
                "message": f"Found {len(matches)} sessions matching '{query}'. Pick one by session_id.",
                "candidates": candidates,
            }
        )
    except Exception as exc:
        return _error(str(exc))


async def session_new(
    mode: str = "fresh",
    topic: str | None = None,
    starter_prompt: str | None = None,
    chat_id: str | None = None,
) -> dict[str, Any]:
    """Create a new session, either fresh or forked from the current one.

    Args:
        mode: "fresh" (default), "fork", or "ask" (send Telegram choice buttons)
        topic: Optional topic/name for the new session
        starter_prompt: Initial user message to seed a fresh session
        chat_id: Chat ID to scope to (auto-detected if omitted)
    """
    try:
        resolved_chat_id = _resolve_chat_id(chat_id)
        normalized_mode = str(mode or "fresh").strip().lower()
        clean_topic = topic.strip() if isinstance(topic, str) else topic
        clean_topic = clean_topic or None

        if normalized_mode not in {"fresh", "fork", "ask"}:
            return _error("mode must be one of: fresh, fork, ask")

        if normalized_mode == "ask":
            from otto.mcp_tools.platform import send_buttons as _send_buttons

            callback_topic = clean_topic[:45] if clean_topic else None
            if callback_topic:
                buttons = [
                    {
                        "label": "Fork (keep context)",
                        "callback_data": f"sess_new:fork:{callback_topic}",
                    },
                    {
                        "label": "Fresh (blank)",
                        "callback_data": f"sess_new:fresh:{callback_topic}",
                    },
                ]
            else:
                buttons = [
                    {"label": "Fork (keep context)", "callback_data": "sess_new:fork"},
                    {"label": "Fresh (blank)", "callback_data": "sess_new:fresh"},
                ]

            message = "<b>New session</b>"
            if clean_topic:
                message = f"{message}: {clean_topic}"
            message += "\n\nKeep current conversation context or start blank?"

            result = await _send_buttons(
                text=message,
                buttons=buttons,
                chat_id=resolved_chat_id,
            )
            if not result.get("success"):
                return _error(result.get("error", "Failed to send session choice buttons"))

            return _ok(
                {
                    "awaiting_choice": True,
                    "message": "Asked the user to choose fork or fresh.",
                }
            )

        # Auto-title outgoing session before creating/replacing it.
        try:
            await sessions.maybe_auto_title(chat_id=resolved_chat_id, force=True)
        except Exception:
            pass

        if normalized_mode == "fork":
            session = await asyncio.to_thread(
                sessions.fork_session,
                topic=clean_topic,
                chat_id=resolved_chat_id,
            )
            return _ok(
                {
                    "created": True,
                    "mode": "fork",
                    "session": {
                        "id": session.get("id"),
                        "topic": session.get("topic") or "(untitled)",
                        "message_count": session.get("metadata", {}).get(
                            "message_count", len(session.get("messages", []))
                        ),
                        "forked_from": session.get("metadata", {}).get("forked_from"),
                    },
                }
            )

        session = await asyncio.to_thread(
            sessions.new_session,
            topic=clean_topic,
            archive_current=True,
            chat_id=resolved_chat_id,
        )

        clean_starter = starter_prompt.strip() if isinstance(starter_prompt, str) else ""
        if clean_starter:
            session = await asyncio.to_thread(
                sessions.add_message,
                role="user",
                content=clean_starter,
                chat_id=resolved_chat_id,
            )

        return _ok(
            {
                "created": True,
                "mode": "fresh",
                "session": {
                    "id": session.get("id"),
                    "topic": session.get("topic") or "(untitled)",
                    "message_count": session.get("metadata", {}).get(
                        "message_count", len(session.get("messages", []))
                    ),
                },
                "starter_prompt": clean_starter or None,
            }
        )
    except Exception as exc:
        return _error(str(exc))
