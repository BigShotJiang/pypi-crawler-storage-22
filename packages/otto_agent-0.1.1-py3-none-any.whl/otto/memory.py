"""
Memory system for Otto.

Uses SQLite FTS5 for full-text search across:
- memory/knowledge.md (core facts)
- memory/projects/*.md (project context)
- sessions/archive/*.json (past conversations)

The memory is one continuous brain - sessions are bookmarks, not walls.
"""

import hashlib
import json
import re
import sqlite3
from datetime import datetime
from pathlib import Path

from .paths import OTTO_HOME

OTTO_DIR = OTTO_HOME
MEMORY_DIR = OTTO_DIR / "memory"
SESSIONS_DIR = OTTO_DIR / "sessions"
ARCHIVE_DIR = SESSIONS_DIR / "archive"
DB_PATH = OTTO_DIR / "memory.sqlite"

# Chunk size for indexing (in characters)
CHUNK_SIZE = 1500
CHUNK_OVERLAP = 200


def _get_db() -> sqlite3.Connection:
    """Get database connection, creating schema if needed."""
    OTTO_DIR.mkdir(parents=True, exist_ok=True)

    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row

    # Create FTS5 virtual table if not exists
    db.executescript("""
        CREATE TABLE IF NOT EXISTS memory_chunks (
            id INTEGER PRIMARY KEY,
            source_type TEXT NOT NULL,  -- 'knowledge', 'project', 'session'
            source_path TEXT NOT NULL,  -- file path
            source_id TEXT,             -- session id or project name
            chunk_index INTEGER,        -- position in source
            content TEXT NOT NULL,
            content_hash TEXT NOT NULL,
            indexed_at TEXT NOT NULL,
            metadata TEXT               -- JSON metadata
        );

        CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
            content,
            source_type,
            source_id,
            content='memory_chunks',
            content_rowid='id'
        );

        -- Triggers to keep FTS in sync
        CREATE TRIGGER IF NOT EXISTS memory_ai AFTER INSERT ON memory_chunks BEGIN
            INSERT INTO memory_fts(rowid, content, source_type, source_id)
            VALUES (new.id, new.content, new.source_type, new.source_id);
        END;

        CREATE TRIGGER IF NOT EXISTS memory_ad AFTER DELETE ON memory_chunks BEGIN
            INSERT INTO memory_fts(memory_fts, rowid, content, source_type, source_id)
            VALUES ('delete', old.id, old.content, old.source_type, old.source_id);
        END;

        CREATE TRIGGER IF NOT EXISTS memory_au AFTER UPDATE ON memory_chunks BEGIN
            INSERT INTO memory_fts(memory_fts, rowid, content, source_type, source_id)
            VALUES ('delete', old.id, old.content, old.source_type, old.source_id);
            INSERT INTO memory_fts(rowid, content, source_type, source_id)
            VALUES (new.id, new.content, new.source_type, new.source_id);
        END;

        -- Index for efficient lookups
        CREATE INDEX IF NOT EXISTS idx_chunks_source ON memory_chunks(source_path);
        CREATE INDEX IF NOT EXISTS idx_chunks_hash ON memory_chunks(content_hash);
    """)

    return db


def _chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """Split text into overlapping chunks."""
    if len(text) <= chunk_size:
        return [text]

    chunks = []
    start = 0

    while start < len(text):
        end = start + chunk_size

        # Try to break at paragraph or sentence boundary
        if end < len(text):
            # Look for paragraph break
            para_break = text.rfind("\n\n", start, end)
            if para_break > start + chunk_size // 2:
                end = para_break + 2
            else:
                # Look for sentence break
                sentence_break = max(
                    text.rfind(". ", start, end),
                    text.rfind(".\n", start, end),
                    text.rfind("? ", start, end),
                    text.rfind("! ", start, end),
                )
                if sentence_break > start + chunk_size // 2:
                    end = sentence_break + 2

        chunks.append(text[start:end].strip())
        start = end - overlap

    return [c for c in chunks if c]  # Filter empty chunks


def _content_hash(content: str) -> str:
    """Generate hash of content for change detection."""
    return hashlib.md5(content.encode()).hexdigest()


def index_file(
    path: Path, source_type: str, source_id: str | None = None, force: bool = False
) -> int:
    """
    Index a file into the memory database.

    Args:
        path: Path to file
        source_type: 'knowledge', 'project', or 'session'
        source_id: Identifier (project name, session id)
        force: Re-index even if unchanged

    Returns:
        Number of chunks indexed
    """
    if not path.exists():
        return 0

    source_path = str(path)

    # Read content
    if path.suffix == ".json":
        # Session file - extract conversation
        try:
            data = json.loads(path.read_text())
            messages = data.get("messages", [])
            topic = data.get("topic", "")

            # Format conversation for indexing
            lines = [f"Session: {topic}"] if topic else []
            for msg in messages:
                role = msg.get("role", "")
                content = msg.get("content", "")
                lines.append(f"{role}: {content}")

            content = "\n".join(lines)
            source_id = source_id or data.get("id", path.stem)
        except json.JSONDecodeError:
            return 0
    else:
        content = path.read_text()
        source_id = source_id or path.stem

    if not content.strip():
        return 0

    db = _get_db()
    try:
        content_hash = _content_hash(content)

        # Check if already indexed with same hash
        if not force:
            existing = db.execute(
                "SELECT content_hash FROM memory_chunks WHERE source_path = ? LIMIT 1",
                (source_path,),
            ).fetchone()

            if existing and existing["content_hash"] == content_hash:
                return 0  # Already up to date

        # Remove old chunks for this file
        db.execute("DELETE FROM memory_chunks WHERE source_path = ?", (source_path,))

        # Chunk and index
        chunks = _chunk_text(content)
        now = datetime.now().isoformat()

        for i, chunk in enumerate(chunks):
            db.execute(
                """
                INSERT INTO memory_chunks
                (source_type, source_path, source_id, chunk_index, content, content_hash, indexed_at, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    source_type,
                    source_path,
                    source_id,
                    i,
                    chunk,
                    content_hash,
                    now,
                    json.dumps({"total_chunks": len(chunks)}),
                ),
            )

        db.commit()
    finally:
        db.close()

    return len(chunks)


def index_all(force: bool = False) -> dict:
    """
    Index all memory sources.

    Returns:
        Dict with counts: {knowledge, projects, sessions, total}
    """
    counts = {"knowledge": 0, "projects": 0, "sessions": 0, "total": 0}

    # Index knowledge.md
    knowledge_file = MEMORY_DIR / "knowledge.md"
    if knowledge_file.exists():
        counts["knowledge"] = index_file(knowledge_file, "knowledge", "core", force=force)

    # Index project files
    projects_dir = MEMORY_DIR / "projects"
    if projects_dir.exists():
        for project_file in projects_dir.glob("*.md"):
            n = index_file(project_file, "project", project_file.stem, force=force)
            counts["projects"] += n

    # Index archived sessions
    if ARCHIVE_DIR.exists():
        for session_file in ARCHIVE_DIR.glob("*.json"):
            n = index_file(session_file, "session", force=force)
            counts["sessions"] += n

    counts["total"] = counts["knowledge"] + counts["projects"] + counts["sessions"]
    return counts


def search(query: str, limit: int = 5, source_types: list[str] | None = None) -> list[dict]:
    """
    Search memory for relevant content.

    Args:
        query: Search query
        limit: Max results
        source_types: Filter by type ('knowledge', 'project', 'session')

    Returns:
        List of results with content, source info, and relevance score
    """
    db = _get_db()

    # Build FTS query
    # Escape special characters and add prefix matching
    safe_query = re.sub(r"[^\w\s]", " ", query)
    terms = safe_query.split()
    fts_query = " OR ".join(f'"{term}"*' for term in terms if term)

    if not fts_query:
        db.close()
        return []

    # Build SQL
    sql = """
        SELECT
            c.id,
            c.source_type,
            c.source_path,
            c.source_id,
            c.content,
            c.chunk_index,
            c.metadata,
            bm25(memory_fts) as score
        FROM memory_fts f
        JOIN memory_chunks c ON f.rowid = c.id
        WHERE memory_fts MATCH ?
    """

    params = [fts_query]

    if source_types:
        placeholders = ",".join("?" * len(source_types))
        sql += f" AND c.source_type IN ({placeholders})"
        params.extend(source_types)

    sql += " ORDER BY score LIMIT ?"
    params.append(limit)

    try:
        rows = db.execute(sql, params).fetchall()
    except sqlite3.OperationalError:
        # FTS query syntax error - try simpler query
        simple_query = " ".join(f'"{term}"' for term in terms if term)
        try:
            params[0] = simple_query
            rows = db.execute(sql, params).fetchall()
        except sqlite3.OperationalError:
            db.close()
            return []

    results = []
    for row in rows:
        results.append(
            {
                "content": row["content"],
                "source_type": row["source_type"],
                "source_id": row["source_id"],
                "source_path": row["source_path"],
                "chunk_index": row["chunk_index"],
                "score": row["score"],
                "metadata": json.loads(row["metadata"]) if row["metadata"] else {},
            }
        )

    db.close()
    return results


def search_formatted(query: str, limit: int = 5) -> str:
    """
    Search memory and return formatted results for prompt injection.

    Args:
        query: Search query
        limit: Max results

    Returns:
        Formatted string with tagged results
    """
    results = search(query, limit)

    if not results:
        return ""

    lines = ["Recalled from memory:"]

    for r in results:
        source_label = f"{r['source_type']}/{r['source_id']}"
        content = r["content"][:800]  # Truncate for prompt

        lines.append(f"\n[from: {source_label}]")
        lines.append(content)

    return "\n".join(lines)


def get_stats() -> dict:
    """Get memory index statistics."""
    db = _get_db()

    stats = {"total_chunks": 0, "by_type": {}, "sources": []}

    # Total chunks
    row = db.execute("SELECT COUNT(*) as count FROM memory_chunks").fetchone()
    stats["total_chunks"] = row["count"]

    # By type
    for row in db.execute(
        "SELECT source_type, COUNT(*) as count FROM memory_chunks GROUP BY source_type"
    ):
        stats["by_type"][row["source_type"]] = row["count"]

    # Unique sources
    for row in db.execute(
        "SELECT DISTINCT source_path, source_type, source_id FROM memory_chunks ORDER BY source_type"
    ):
        stats["sources"].append(
            {"path": row["source_path"], "type": row["source_type"], "id": row["source_id"]}
        )

    db.close()
    return stats


def clear_index():
    """Clear all indexed content."""
    db = _get_db()
    db.execute("DELETE FROM memory_chunks")
    db.commit()
    db.close()
