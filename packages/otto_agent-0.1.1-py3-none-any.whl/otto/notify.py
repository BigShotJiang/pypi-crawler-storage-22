"""Telegram notifications (shared by services and CLI)."""

from __future__ import annotations

import asyncio

from otto_tools.notify import send_telegram


def send(message: str) -> str:
    """Send a Telegram message. Raises on failure."""
    success, result = asyncio.run(send_telegram(message))
    if not success:
        raise RuntimeError(result)
    return result
