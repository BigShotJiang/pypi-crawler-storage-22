"""
Runtime Observability & Anomaly Detection (Phase 4, Pillar 3).

Provides real-time visibility and anomaly detection over MCP gateway activity:

1. **Activity Dashboard** — Live tool-call statistics, top servers/tools,
   recent verdicts, rate-limit status. Powers the /activity Telegram command.

2. **Anomaly Detection** — Flags unusual patterns:
   - Burst detection: sudden spike in calls per minute
   - New-tool detection: first-time use of a server or tool
   - Denial spike: unusual number of denials in a window
   - After-hours activity: tool calls outside normal hours

3. **Summary Reports** — Daily/weekly digests of gateway activity
   suitable for Telegram notification.

All queries hit the existing SQLite audit DB (otto.audit) — no new storage.
Anomaly state is kept in-memory with optional persistence to a small JSON file.

Architecture:
    The observability module is a *read-only consumer* of the audit log.
    It never blocks the gateway pipeline; anomaly checks run asynchronously
    after audit entries are written.

    Gateway.request_tool()  -->  audit.log_tool_call()  -->  _write_entry()
                                                                  |
                                                          observability.check_anomalies()
                                                                  |
                                                          (async notification if flagged)
"""

from __future__ import annotations

import logging
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Literal

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Activity Dashboard queries (hit SQLite audit DB)
# ---------------------------------------------------------------------------


def get_activity_summary(
    hours: int = 24,
    limit_entries: int = 15,
) -> dict[str, Any]:
    """
    Get a summary of recent MCP gateway activity.

    Returns a dict with:
      - total_calls: int
      - allowed / denied / prompted counts
      - top_servers: [(name, count), ...]
      - top_tools: [(server.tool, count), ...]
      - recent_denials: [entry, ...]
      - calls_per_hour: [(hour_label, count), ...]  (last N hours)

    Args:
        hours: Look-back window in hours (default 24)
        limit_entries: Max items in top-N lists
    """
    from otto.audit import _db_lock, _get_db

    since = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()

    try:
        with _db_lock:
            db = _get_db()

            # Total tool calls in window
            total = db.execute(
                "SELECT COUNT(*) FROM audit_log WHERE timestamp >= ? AND event = 'tool_call'",
                (since,),
            ).fetchone()[0]

            # Verdict breakdown
            verdicts: dict[str, int] = {}
            for row in db.execute(
                "SELECT verdict, COUNT(*) FROM audit_log "
                "WHERE timestamp >= ? AND event = 'tool_call' "
                "GROUP BY verdict",
                (since,),
            ):
                verdicts[row[0] or "none"] = row[1]

            # Top servers
            top_servers: list[tuple[str, int]] = []
            for row in db.execute(
                "SELECT server, COUNT(*) as cnt FROM audit_log "
                "WHERE timestamp >= ? AND event = 'tool_call' AND server IS NOT NULL "
                "GROUP BY server ORDER BY cnt DESC LIMIT ?",
                (since, limit_entries),
            ):
                top_servers.append((row[0], row[1]))

            # Top tools (server.tool)
            top_tools: list[tuple[str, int]] = []
            for row in db.execute(
                "SELECT server || '.' || tool, COUNT(*) as cnt FROM audit_log "
                "WHERE timestamp >= ? AND event = 'tool_call' "
                "AND server IS NOT NULL AND tool IS NOT NULL "
                "GROUP BY server, tool ORDER BY cnt DESC LIMIT ?",
                (since, limit_entries),
            ):
                top_tools.append((row[0], row[1]))

            # Recent denials
            denial_rows = db.execute(
                "SELECT timestamp, server, tool, error FROM audit_log "
                "WHERE timestamp >= ? AND verdict = 'deny' "
                "ORDER BY id DESC LIMIT ?",
                (since, 10),
            ).fetchall()
            recent_denials = [
                {
                    "timestamp": r[0],
                    "server": r[1],
                    "tool": r[2],
                    "error": r[3],
                }
                for r in denial_rows
            ]

            # Calls per hour (last N hours)
            calls_per_hour: list[tuple[str, int]] = []
            for i in range(min(hours, 24), 0, -1):
                h_start = (datetime.now(timezone.utc) - timedelta(hours=i)).isoformat()
                h_end = (datetime.now(timezone.utc) - timedelta(hours=i - 1)).isoformat()
                cnt = db.execute(
                    "SELECT COUNT(*) FROM audit_log "
                    "WHERE timestamp >= ? AND timestamp < ? AND event = 'tool_call'",
                    (h_start, h_end),
                ).fetchone()[0]
                label = (datetime.now(timezone.utc) - timedelta(hours=i)).strftime("%H:%M")
                calls_per_hour.append((label, cnt))

            return {
                "total_calls": total,
                "verdicts": verdicts,
                "top_servers": top_servers,
                "top_tools": top_tools,
                "recent_denials": recent_denials,
                "calls_per_hour": calls_per_hour,
                "window_hours": hours,
            }
    except Exception as exc:
        log.warning("Failed to get activity summary: %s", exc)
        return {
            "total_calls": 0,
            "verdicts": {},
            "top_servers": [],
            "top_tools": [],
            "recent_denials": [],
            "calls_per_hour": [],
            "window_hours": hours,
        }


def get_session_replay(
    session_id: str | None = None,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """
    Get complete tool-call history for a session (or recent history).

    Returns list of entries with full detail for session replay.
    """
    from otto.audit import query_audit

    kwargs: dict[str, Any] = {"audit_type": "security", "limit": limit}
    if session_id:
        kwargs["search"] = session_id
    return query_audit(**kwargs)


# ---------------------------------------------------------------------------
# Anomaly Detection Engine
# ---------------------------------------------------------------------------

AnomalyType = Literal[
    "burst",  # Sudden spike in calls per minute
    "new_tool",  # First-time use of a tool
    "new_server",  # First-time use of a server
    "denial_spike",  # Unusual number of denials
    "after_hours",  # Activity outside configured hours
    "high_error_rate",  # High proportion of errors
]


@dataclass
class Anomaly:
    """A detected anomaly in MCP gateway activity."""

    anomaly_type: AnomalyType
    severity: Literal["info", "warning", "critical"]
    message: str
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    data: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": self.anomaly_type,
            "severity": self.severity,
            "message": self.message,
            "timestamp": self.timestamp,
            "data": self.data,
        }


@dataclass
class AnomalyConfig:
    """Configuration for anomaly detection thresholds."""

    # Burst detection: flag if calls/min exceeds this
    burst_threshold: int = 60
    # Burst window in seconds
    burst_window: int = 60

    # Denial spike: flag if denials in window exceed this
    denial_spike_threshold: int = 10
    denial_spike_window: int = 300  # 5 minutes

    # After-hours: flag activity outside these hours (24h format, UTC)
    after_hours_start: int = 23  # 11 PM
    after_hours_end: int = 6  # 6 AM

    # Enable/disable individual detectors
    detect_bursts: bool = True
    detect_new_tools: bool = True
    detect_denial_spikes: bool = True
    detect_after_hours: bool = False  # off by default
    detect_high_error_rate: bool = True

    # High error rate: flag if error% exceeds this in window
    error_rate_threshold: float = 0.5  # 50%
    error_rate_min_calls: int = 10  # min calls before checking rate

    @classmethod
    def from_config(cls, config: dict[str, Any] | None) -> AnomalyConfig:
        """Load from settings.yaml gateway.observability section."""
        if not config:
            return cls()
        return cls(
            burst_threshold=int(config.get("burst_threshold", 60)),
            burst_window=int(config.get("burst_window", 60)),
            denial_spike_threshold=int(config.get("denial_spike_threshold", 10)),
            denial_spike_window=int(config.get("denial_spike_window", 300)),
            after_hours_start=int(config.get("after_hours_start", 23)),
            after_hours_end=int(config.get("after_hours_end", 6)),
            detect_bursts=bool(config.get("detect_bursts", True)),
            detect_new_tools=bool(config.get("detect_new_tools", True)),
            detect_denial_spikes=bool(config.get("detect_denial_spikes", True)),
            detect_after_hours=bool(config.get("detect_after_hours", False)),
            detect_high_error_rate=bool(config.get("detect_high_error_rate", True)),
            error_rate_threshold=float(config.get("error_rate_threshold", 0.5)),
            error_rate_min_calls=int(config.get("error_rate_min_calls", 10)),
        )


class AnomalyDetector:
    """
    In-memory anomaly detector for MCP gateway activity.

    Maintains sliding windows and known-tool sets to detect anomalies
    in real-time as tool calls flow through the gateway.

    Thread-safe: all state updates are protected by a lock.
    """

    def __init__(self, config: AnomalyConfig | None = None):
        self._config = config or AnomalyConfig()
        self._lock = threading.Lock()

        # Sliding window of recent call timestamps (monotonic)
        self._call_times: deque[float] = deque()
        # Sliding window of recent denial timestamps
        self._denial_times: deque[float] = deque()
        # Sliding window for error rate tracking
        self._recent_calls: deque[tuple[float, bool]] = deque()  # (time, success)

        # Known servers and tools (first-seen tracking)
        self._known_servers: set[str] = set()
        self._known_tools: set[str] = set()  # "server.tool" format

        # Recent anomalies (bounded buffer)
        self._anomalies: deque[Anomaly] = deque(maxlen=200)

        # Notification callback (set externally)
        self._notify_callback: Any = None

    @property
    def config(self) -> AnomalyConfig:
        return self._config

    @property
    def anomalies(self) -> list[Anomaly]:
        """Get recent anomalies (newest first)."""
        with self._lock:
            return list(reversed(self._anomalies))

    def seed_known_tools(self, servers: set[str], tools: set[str]) -> None:
        """
        Pre-populate known servers/tools to avoid false positives on startup.

        Call this after loading historical data from the audit DB.
        """
        with self._lock:
            self._known_servers.update(servers)
            self._known_tools.update(tools)

    def seed_from_audit_db(self) -> None:
        """Load known servers/tools from the audit database."""
        try:
            from otto.audit import _db_lock, _get_db

            with _db_lock:
                db = _get_db()
                servers = set()
                tools = set()

                for row in db.execute(
                    "SELECT DISTINCT server FROM audit_log WHERE server IS NOT NULL"
                ):
                    servers.add(row[0])

                for row in db.execute(
                    "SELECT DISTINCT server || '.' || tool FROM audit_log "
                    "WHERE server IS NOT NULL AND tool IS NOT NULL"
                ):
                    tools.add(row[0])

            self.seed_known_tools(servers, tools)
            log.debug(
                "Seeded anomaly detector: %d servers, %d tools",
                len(servers),
                len(tools),
            )
        except Exception as exc:
            log.debug("Could not seed anomaly detector from DB: %s", exc)

    def check(
        self,
        server: str,
        tool: str,
        verdict: str,
        success: bool = True,
    ) -> list[Anomaly]:
        """
        Check a tool call for anomalies.

        Called after each tool call is logged. Returns any detected anomalies.

        Args:
            server: MCP server name
            tool: Tool name
            verdict: Policy verdict (allow, deny, prompt)
            success: Whether the call succeeded

        Returns:
            List of detected anomalies (may be empty)
        """
        now = time.monotonic()
        detected: list[Anomaly] = []

        with self._lock:
            # Record timestamps
            self._call_times.append(now)
            self._recent_calls.append((now, success))

            if verdict == "deny":
                self._denial_times.append(now)

            # 1. Burst detection
            if self._config.detect_bursts:
                anomaly = self._check_burst(now)
                if anomaly:
                    detected.append(anomaly)

            # 2. New tool/server detection
            if self._config.detect_new_tools:
                tool_key = f"{server}.{tool}"

                if server not in self._known_servers:
                    self._known_servers.add(server)
                    anomaly = Anomaly(
                        anomaly_type="new_server",
                        severity="info",
                        message=f"First-time MCP server used: {server}",
                        data={"server": server, "tool": tool},
                    )
                    self._anomalies.append(anomaly)
                    detected.append(anomaly)

                if tool_key not in self._known_tools:
                    self._known_tools.add(tool_key)
                    anomaly = Anomaly(
                        anomaly_type="new_tool",
                        severity="info",
                        message=f"First-time tool used: {tool_key}",
                        data={"server": server, "tool": tool},
                    )
                    self._anomalies.append(anomaly)
                    detected.append(anomaly)

            # 3. Denial spike
            if self._config.detect_denial_spikes:
                anomaly = self._check_denial_spike(now)
                if anomaly:
                    detected.append(anomaly)

            # 4. After-hours activity
            if self._config.detect_after_hours:
                anomaly = self._check_after_hours()
                if anomaly:
                    detected.append(anomaly)

            # 5. High error rate
            if self._config.detect_high_error_rate:
                anomaly = self._check_error_rate(now)
                if anomaly:
                    detected.append(anomaly)

        return detected

    def _check_burst(self, now: float) -> Anomaly | None:
        """Check for burst activity (calls per minute exceeding threshold)."""
        cutoff = now - self._config.burst_window
        while self._call_times and self._call_times[0] < cutoff:
            self._call_times.popleft()

        count = len(self._call_times)
        if count >= self._config.burst_threshold:
            anomaly = Anomaly(
                anomaly_type="burst",
                severity="warning",
                message=f"Burst detected: {count} calls in {self._config.burst_window}s "
                f"(threshold: {self._config.burst_threshold})",
                data={"count": count, "window": self._config.burst_window},
            )
            self._anomalies.append(anomaly)
            return anomaly
        return None

    def _check_denial_spike(self, now: float) -> Anomaly | None:
        """Check for denial spike (many denials in a window)."""
        cutoff = now - self._config.denial_spike_window
        while self._denial_times and self._denial_times[0] < cutoff:
            self._denial_times.popleft()

        count = len(self._denial_times)
        if count >= self._config.denial_spike_threshold:
            anomaly = Anomaly(
                anomaly_type="denial_spike",
                severity="warning",
                message=f"Denial spike: {count} denials in {self._config.denial_spike_window}s "
                f"(threshold: {self._config.denial_spike_threshold})",
                data={"count": count, "window": self._config.denial_spike_window},
            )
            self._anomalies.append(anomaly)
            return anomaly
        return None

    def _check_after_hours(self) -> Anomaly | None:
        """Check if current time is outside configured active hours."""
        hour = datetime.now(timezone.utc).hour
        start = self._config.after_hours_start
        end = self._config.after_hours_end

        is_after_hours = False
        if start > end:
            # Wraps midnight: e.g., 23-6 means 23:00 to 06:00
            is_after_hours = hour >= start or hour < end
        else:
            is_after_hours = start <= hour < end

        if is_after_hours:
            anomaly = Anomaly(
                anomaly_type="after_hours",
                severity="info",
                message=f"After-hours tool activity at {hour:02d}:00 UTC",
                data={"hour": hour},
            )
            self._anomalies.append(anomaly)
            return anomaly
        return None

    def _check_error_rate(self, now: float) -> Anomaly | None:
        """Check for high error rate in recent calls."""
        # Use a 5-minute window
        cutoff = now - 300
        while self._recent_calls and self._recent_calls[0][0] < cutoff:
            self._recent_calls.popleft()

        total = len(self._recent_calls)
        if total < self._config.error_rate_min_calls:
            return None

        errors = sum(1 for _, success in self._recent_calls if not success)
        rate = errors / total

        if rate >= self._config.error_rate_threshold:
            anomaly = Anomaly(
                anomaly_type="high_error_rate",
                severity="warning",
                message=f"High error rate: {errors}/{total} ({rate:.0%}) in last 5 minutes",
                data={"errors": errors, "total": total, "rate": rate},
            )
            self._anomalies.append(anomaly)
            return anomaly
        return None

    def clear(self) -> None:
        """Clear all state (for testing)."""
        with self._lock:
            self._call_times.clear()
            self._denial_times.clear()
            self._recent_calls.clear()
            self._known_servers.clear()
            self._known_tools.clear()
            self._anomalies.clear()


# ---------------------------------------------------------------------------
# Summary Reports (for daily/weekly notifications)
# ---------------------------------------------------------------------------


def generate_daily_summary() -> str:
    """
    Generate a daily summary of MCP gateway activity for notification.

    Returns formatted text suitable for Telegram (HTML).
    """
    summary = get_activity_summary(hours=24)

    total = summary["total_calls"]
    verdicts = summary["verdicts"]
    allowed = verdicts.get("allow", 0)
    denied = verdicts.get("deny", 0)
    prompted = verdicts.get("prompt", 0)

    lines = ["<b>📊 Daily MCP Activity Summary</b>\n"]
    lines.append(f"Total tool calls: <b>{total}</b>")

    if total > 0:
        lines.append(f"  ✅ Allowed: {allowed}")
        if denied:
            lines.append(f"  🚫 Denied: {denied}")
        if prompted:
            lines.append(f"  ❓ Prompted: {prompted}")

    # Top servers
    if summary["top_servers"]:
        lines.append("\n<b>Top servers:</b>")
        for srv, cnt in summary["top_servers"][:5]:
            lines.append(f"  • {srv}: {cnt}")

    # Top tools
    if summary["top_tools"]:
        lines.append("\n<b>Top tools:</b>")
        for tool, cnt in summary["top_tools"][:5]:
            lines.append(f"  • <code>{tool}</code>: {cnt}")

    # Denials
    if summary["recent_denials"]:
        lines.append(f"\n<b>Recent denials ({len(summary['recent_denials'])}):</b>")
        for d in summary["recent_denials"][:3]:
            ts = d["timestamp"][:16] if d.get("timestamp") else "?"
            err = (d.get("error") or "")[:60]
            lines.append(f"  • {d.get('server', '?')}.{d.get('tool', '?')} — {err}")

    # Activity chart (simple ASCII sparkline)
    if summary["calls_per_hour"]:
        lines.append("\n<b>Hourly activity:</b>")
        max_val = max((c for _, c in summary["calls_per_hour"]), default=1) or 1
        bars = []
        for label, cnt in summary["calls_per_hour"]:
            bar_len = int((cnt / max_val) * 8) if max_val > 0 else 0
            bars.append("▇" * bar_len if bar_len > 0 else "·")
        lines.append(f"  <code>{''.join(bars)}</code>")

    if total == 0:
        lines.append("\n<i>No MCP tool activity in the last 24 hours.</i>")

    return "\n".join(lines)


def generate_weekly_summary() -> str:
    """Generate a weekly summary of MCP gateway activity."""
    summary = get_activity_summary(hours=168)  # 7 days

    total = summary["total_calls"]
    verdicts = summary["verdicts"]
    allowed = verdicts.get("allow", 0)
    denied = verdicts.get("deny", 0)

    lines = ["<b>📊 Weekly MCP Activity Summary</b>\n"]
    lines.append(f"Total tool calls (7 days): <b>{total}</b>")

    if total > 0:
        lines.append(f"  ✅ Allowed: {allowed}")
        if denied:
            lines.append(f"  🚫 Denied: {denied}")

    if summary["top_servers"]:
        lines.append("\n<b>Top servers:</b>")
        for srv, cnt in summary["top_servers"][:5]:
            lines.append(f"  • {srv}: {cnt}")

    if summary["top_tools"]:
        lines.append("\n<b>Top tools:</b>")
        for tool, cnt in summary["top_tools"][:5]:
            lines.append(f"  • <code>{tool}</code>: {cnt}")

    if denied:
        denial_pct = (denied / total * 100) if total > 0 else 0
        lines.append(f"\n<b>Denial rate:</b> {denial_pct:.1f}%")

    return "\n".join(lines)


async def send_daily_summary() -> dict[str, Any]:
    """
    Generate and send the daily summary via Telegram notification.

    Returns result dict with success status.
    """
    try:
        text = generate_daily_summary()
        from otto.mcp_tools.notify import notify_send

        result = await notify_send(message=text, platform="telegram")
        return result
    except Exception as exc:
        log.warning("Failed to send daily summary: %s", exc)
        return {"success": False, "error": str(exc)}


async def send_weekly_summary() -> dict[str, Any]:
    """Generate and send the weekly summary via Telegram notification."""
    try:
        text = generate_weekly_summary()
        from otto.mcp_tools.notify import notify_send

        result = await notify_send(message=text, platform="telegram")
        return result
    except Exception as exc:
        log.warning("Failed to send weekly summary: %s", exc)
        return {"success": False, "error": str(exc)}


# ---------------------------------------------------------------------------
# Singleton anomaly detector
# ---------------------------------------------------------------------------

_detector: AnomalyDetector | None = None
_detector_lock = threading.Lock()


def get_detector() -> AnomalyDetector:
    """Get or create the global anomaly detector."""
    global _detector
    if _detector is None:
        with _detector_lock:
            if _detector is None:
                config = _load_anomaly_config()
                _detector = AnomalyDetector(config)
                _detector.seed_from_audit_db()
    return _detector


def reset_detector() -> None:
    """Reset the global detector (for testing)."""
    global _detector
    _detector = None


def _load_anomaly_config() -> AnomalyConfig:
    """Load anomaly config from settings.yaml."""
    try:
        from otto.config import get_setting

        obs_config = get_setting("gateway.observability")
        return AnomalyConfig.from_config(obs_config)
    except Exception:
        return AnomalyConfig()


# ---------------------------------------------------------------------------
# Integration hook: call from audit.log_tool_call()
# ---------------------------------------------------------------------------


def on_tool_call(
    server: str,
    tool: str,
    verdict: str,
    success: bool = True,
) -> list[Anomaly]:
    """
    Hook called after each tool call is logged.

    Runs anomaly detection and returns any flagged anomalies.
    Notifications are sent asynchronously if anomalies are detected.
    """
    try:
        detector = get_detector()
        anomalies = detector.check(server, tool, verdict, success)

        if anomalies:
            # Log anomalies
            for a in anomalies:
                log.info(
                    "Anomaly detected: [%s] %s (severity=%s)",
                    a.anomaly_type,
                    a.message,
                    a.severity,
                )

            # Fire-and-forget async notification for warning+ severity
            warnings = [a for a in anomalies if a.severity in ("warning", "critical")]
            if warnings:
                _notify_anomalies_async(warnings)

        return anomalies
    except Exception as exc:
        log.debug("Anomaly detection error: %s", exc)
        return []


def _notify_anomalies_async(anomalies: list[Anomaly]) -> None:
    """Send anomaly notifications asynchronously (fire-and-forget)."""
    import asyncio

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return  # No event loop — skip notification

    async def _send():
        try:
            from otto.mcp_tools.notify import notify_send

            lines = ["<b>⚠️ MCP Anomaly Alert</b>\n"]
            for a in anomalies:
                icon = {"info": "ℹ️", "warning": "⚠️", "critical": "🚨"}.get(a.severity, "•")
                lines.append(f"{icon} <b>{a.anomaly_type}</b>: {a.message}")

            await notify_send(message="\n".join(lines), platform="telegram")
        except Exception as exc:
            log.debug("Failed to send anomaly notification: %s", exc)

    loop.create_task(_send())


# ---------------------------------------------------------------------------
# Format helpers
# ---------------------------------------------------------------------------


def format_activity_dashboard(summary: dict[str, Any]) -> str:
    """
    Format the activity summary for Telegram display.

    Returns HTML-formatted text.
    """
    total = summary.get("total_calls", 0)
    verdicts = summary.get("verdicts", {})
    hours = summary.get("window_hours", 24)

    lines = [f"<b>📊 MCP Activity Dashboard</b> ({hours}h)\n"]
    lines.append(f"Total calls: <b>{total}</b>")

    if total > 0:
        allowed = verdicts.get("allow", 0)
        denied = verdicts.get("deny", 0)
        prompted = verdicts.get("prompt", 0)
        lines.append(f"  ✅ {allowed}  🚫 {denied}  ❓ {prompted}")

    # Top servers
    top_servers = summary.get("top_servers", [])
    if top_servers:
        lines.append("\n<b>Servers:</b>")
        for srv, cnt in top_servers[:5]:
            pct = f" ({cnt / total * 100:.0f}%)" if total > 0 else ""
            lines.append(f"  • {srv}: {cnt}{pct}")

    # Top tools
    top_tools = summary.get("top_tools", [])
    if top_tools:
        lines.append("\n<b>Tools:</b>")
        for tool, cnt in top_tools[:5]:
            lines.append(f"  • <code>{tool}</code>: {cnt}")

    # Denials
    denials = summary.get("recent_denials", [])
    if denials:
        lines.append("\n<b>Recent denials:</b>")
        for d in denials[:3]:
            srv = d.get("server", "?")
            tool = d.get("tool", "?")
            err = (d.get("error") or "")[:50]
            lines.append(f"  🚫 {srv}.{tool}: {err}")

    # Hourly sparkline
    calls_per_hour = summary.get("calls_per_hour", [])
    if calls_per_hour:
        max_val = max((c for _, c in calls_per_hour), default=1) or 1
        bars = []
        for _, cnt in calls_per_hour:
            bar_len = int((cnt / max_val) * 8) if max_val > 0 else 0
            bars.append("▇" * bar_len if bar_len > 0 else "·")
        lines.append(f"\n<b>Hourly:</b> <code>{''.join(bars)}</code>")

    if total == 0:
        lines.append("\n<i>No activity in this window.</i>")

    return "\n".join(lines)


def format_anomalies(anomalies: list[Anomaly], limit: int = 10) -> str:
    """Format recent anomalies for display."""
    if not anomalies:
        return "No anomalies detected."

    lines = [f"<b>⚠️ Recent Anomalies ({len(anomalies)})</b>\n"]
    for a in anomalies[:limit]:
        icon = {"info": "ℹ️", "warning": "⚠️", "critical": "🚨"}.get(a.severity, "•")
        ts = a.timestamp[:16] if a.timestamp else "?"
        lines.append(f"{icon} [{ts}] <b>{a.anomaly_type}</b>: {a.message}")

    return "\n".join(lines)


__all__ = [
    # Dashboard
    "get_activity_summary",
    "get_session_replay",
    "format_activity_dashboard",
    # Anomaly detection
    "AnomalyConfig",
    "AnomalyDetector",
    "Anomaly",
    "AnomalyType",
    "get_detector",
    "reset_detector",
    "on_tool_call",
    # Reports
    "generate_daily_summary",
    "generate_weekly_summary",
    "send_daily_summary",
    "send_weekly_summary",
    "format_anomalies",
]
