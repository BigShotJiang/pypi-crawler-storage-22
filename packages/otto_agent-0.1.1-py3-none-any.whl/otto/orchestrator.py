"""
Sub-agent orchestrator for spawning and managing parallel agent tasks.

Provides Orchestrator class for spawning sub-agents, tracking their status,
and collecting results. State is persisted to .otto/state.json.
"""

import asyncio
import json
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime

from . import audit
from .backends import AgentResult, get_backend, get_orchestration_config
from .jobs.queue import JobQueue
from .paths import OTTO_HOME, get_workdir
from .paths import OUTPUTS_DIR as OTTO_OUTPUTS_DIR

# Paths
OTTO_DIR = OTTO_HOME
STATE_FILE = OTTO_DIR / "state.json"
OUTPUTS_DIR = OTTO_OUTPUTS_DIR


@dataclass
class SpawnRequest:
    """Request to spawn a sub-agent."""

    prompt: str
    system_prompt: str
    task_description: str
    backend: str | None = None
    timeout: int | None = None  # None means use config default


@dataclass
class SubAgent:
    """A running sub-agent instance."""

    id: str
    task: str
    backend: str
    started_at: str  # ISO format
    status: str = "running"  # running, completed, failed, cancelled
    # Optional fields for backwards compatibility with legacy state
    prompt: str | None = None
    output_file: str | None = None
    pid: int | None = None
    updated_at: str | None = None

    def to_dict(self) -> dict:
        """Convert to dict, excluding None values for cleaner output."""
        d = asdict(self)
        return {k: v for k, v in d.items() if v is not None}

    @classmethod
    def from_dict(cls, data: dict) -> "SubAgent":
        """Create from dict, ignoring unknown fields."""
        valid_fields = {
            "id",
            "task",
            "backend",
            "started_at",
            "status",
            "prompt",
            "output_file",
            "pid",
            "updated_at",
        }
        filtered = {k: v for k, v in data.items() if k in valid_fields}
        return cls(**filtered)


class Orchestrator:
    """
    Manages spawning and tracking of sub-agents.

    Usage:
        orchestrator = get_orchestrator()
        agent_id = await orchestrator.spawn(request)
        result = await orchestrator.wait_for(agent_id)
    """

    # Maximum cached results to prevent unbounded memory growth.
    # Once exceeded, oldest completed results are evicted.
    MAX_CACHED_RESULTS = 100

    def __init__(self):
        self._tasks: dict[str, asyncio.Task] = {}
        self._results: dict[str, AgentResult] = {}
        self._agents: dict[str, SubAgent] = {}
        self._lock = asyncio.Lock()

        # Ensure directories exist
        OTTO_DIR.mkdir(parents=True, exist_ok=True)
        OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)

        # Load persisted state
        self._load_state()

    def _load_state(self) -> None:
        """Load state from disk and cleanup stale agents."""
        if STATE_FILE.exists():
            try:
                data = json.loads(STATE_FILE.read_text())
                # Restore agent metadata (tasks won't survive restart)
                for agent_data in data.get("agents", []):
                    try:
                        agent = SubAgent.from_dict(agent_data)
                        # Mark as failed if was running (process didn't survive restart)
                        if agent.status == "running":
                            # Check if process is actually still running
                            if agent.pid is None:
                                # Legacy runner didn't record PIDs; keep as running (best-effort).
                                pass
                            elif self._is_process_running(agent.pid):
                                pass  # Keep as running
                            else:
                                agent.status = "failed"
                        self._agents[agent.id] = agent
                    except (TypeError, KeyError):
                        # Skip malformed agent entries
                        continue
                # Auto-save to persist any status changes
                self._save_state()
            except (json.JSONDecodeError, KeyError):
                pass

    def _is_process_running(self, pid: int) -> bool:
        """Check if a process is still running."""
        import os

        try:
            os.kill(pid, 0)
            return True
        except (OSError, ProcessLookupError):
            return False

    def _save_state(self) -> None:
        """Persist state to disk."""
        data = {
            "agents": [a.to_dict() for a in self._agents.values()],
            "last_updated": datetime.now().isoformat(),
        }
        STATE_FILE.write_text(json.dumps(data, indent=2))

    def _prune_completed_tasks(self) -> None:
        """Remove done asyncio.Tasks and evict oldest results if over cap."""
        # Clean up finished tasks
        done_ids = [aid for aid, t in self._tasks.items() if t.done()]
        for aid in done_ids:
            del self._tasks[aid]

        # Evict oldest results if over cap
        if len(self._results) > self.MAX_CACHED_RESULTS:
            # Keep the most recent MAX_CACHED_RESULTS entries
            # (dict preserves insertion order in Python 3.7+)
            excess = len(self._results) - self.MAX_CACHED_RESULTS
            for aid in list(self._results.keys())[:excess]:
                del self._results[aid]

    @staticmethod
    async def _cleanup_backend_session(backend) -> None:
        """Clean up backend-specific resources after agent completion.

        For Codex backend, this closes the server session to prevent
        leaked subprocesses. Other backends are no-ops.
        """
        try:
            # Codex: close session for the working directory
            if hasattr(backend, "close_session"):
                await backend.close_session(get_workdir())
        except Exception:
            pass  # Best-effort cleanup

    def _generate_id(self) -> str:
        """Generate an 8-character agent ID."""
        return uuid.uuid4().hex[:8]

    async def spawn(self, request: SpawnRequest) -> str:
        """
        Spawn a new sub-agent.

        Args:
            request: SpawnRequest with prompt, system_prompt, and task description.

        Returns:
            Agent ID string.
        """
        config = get_orchestration_config()
        max_parallel = config.get("max_parallel", 5)

        async with self._lock:
            # Prune finished tasks and evict old results to bound memory
            self._prune_completed_tasks()

            # Check if we're at capacity
            running = sum(1 for a in self._agents.values() if a.status == "running")
            if running >= max_parallel:
                raise RuntimeError(
                    f"Max parallel agents ({max_parallel}) reached. "
                    f"Wait for existing agents to complete."
                )

            # Create agent record
            agent_id = self._generate_id()
            backend_name = request.backend or "claude"

            agent = SubAgent(
                id=agent_id,
                task=request.task_description,
                backend=backend_name,
                started_at=datetime.now().isoformat(),
                status="running",
            )
            self._agents[agent_id] = agent
            self._save_state()

        # Start the task
        task = asyncio.create_task(self._run_agent(agent_id, request))
        self._tasks[agent_id] = task

        # Log agent spawn
        audit.log_agent(
            "spawn",
            agent_id,
            backend=backend_name,
            task=request.task_description,
        )

        return agent_id

    async def _run_agent(self, agent_id: str, request: SpawnRequest) -> AgentResult:
        """Run the agent and handle completion.

        Ensures resource cleanup on all exit paths (success, failure, exception).
        For Codex backend, closes the session to prevent leaked subprocesses.
        """
        backend = get_backend(request.backend)

        try:
            # Get timeout and retry config (single call, not duplicated)
            config = get_orchestration_config()
            timeout = request.timeout or config.get("default_timeout", 3600)
            retry_cfg = config.get("retry", {}) or {}
            max_retries = max(int(retry_cfg.get("max_retries", 3)), 0)
            total_attempts = 1 + max_retries

            queue = JobQueue()
            last_result: AgentResult | None = None
            errors_by_attempt: list[str] = []

            for attempt in range(1, total_attempts + 1):
                result = await backend.run_async(
                    prompt=request.prompt,
                    system_prompt=request.system_prompt,
                    cwd=get_workdir(),
                    timeout=timeout,
                )
                last_result = result

                if result.success:
                    break

                last_error = result.error or "unknown error"
                errors_by_attempt.append(last_error)
                queue.record_agent_failure(agent_id, attempt=attempt, error=last_error)

                if attempt < total_attempts:
                    delay = int(
                        int(retry_cfg.get("base_delay_seconds", 30))
                        * (float(retry_cfg.get("backoff_factor", 2)) ** attempt)
                    )
                    max_delay = int(retry_cfg.get("max_delay_seconds", 300))
                    if delay < 0:
                        delay = 0
                    if max_delay > 0:
                        delay = min(delay, max_delay)
                    await asyncio.sleep(delay)

            if last_result is None:
                raise RuntimeError("Agent did not produce a result")
            result = last_result

            # Attach structured error context for failed results so parent
            # agents get richer information about what went wrong
            if not result.success and errors_by_attempt:
                result.error_context = {
                    "attempts": len(errors_by_attempt),
                    "max_attempts": total_attempts,
                    "errors": errors_by_attempt,
                    "retryable": result.is_retryable,
                }

            # Save output to file
            output_file = OUTPUTS_DIR / f"{agent_id}.txt"
            output_content = f"Task: {request.task_description}\n"
            output_content += f"Backend: {request.backend or 'claude'}\n"
            output_content += f"Success: {result.success}\n"
            output_content += f"Duration: {result.duration_seconds:.2f}s\n"
            output_content += f"\n{'=' * 50}\n\n"
            output_content += result.output
            if result.error:
                output_content += f"\n\nError: {result.error}"
            output_file.write_text(output_content)

            # Update status
            async with self._lock:
                if agent_id in self._agents:
                    self._agents[agent_id].status = "completed" if result.success else "failed"
                    self._save_state()

            # Log agent completion
            audit.log_agent(
                "complete",
                agent_id,
                backend=request.backend or "claude",
                task=request.task_description,
                success=result.success,
                error=result.error,
                data={
                    "duration_seconds": result.duration_seconds,
                    "output_length": len(result.output) if result.output else 0,
                },
            )

            self._results[agent_id] = result
            return result

        except Exception as e:
            result = AgentResult(
                success=False, output="", error=str(e), backend=request.backend or "claude"
            )
            try:
                JobQueue().record_agent_failure(agent_id, attempt=1, error=str(e))
            except Exception:
                pass
            async with self._lock:
                if agent_id in self._agents:
                    self._agents[agent_id].status = "failed"
                    self._save_state()

            # Log agent failure
            audit.log_agent(
                "failed",
                agent_id,
                backend=request.backend or "claude",
                task=request.task_description,
                success=False,
                error=str(e),
            )

            self._results[agent_id] = result
            return result

        finally:
            # Clean up backend resources to prevent leaked sessions/subprocesses.
            # Codex backend holds long-lived server processes per working directory.
            await self._cleanup_backend_session(backend)

    async def spawn_parallel(self, requests: list[SpawnRequest]) -> dict[str, AgentResult]:
        """
        Spawn multiple sub-agents in parallel and wait for all to complete.

        Args:
            requests: List of SpawnRequests.

        Returns:
            Dict mapping agent_id to AgentResult.
        """
        # Spawn all agents
        agent_ids = []
        for request in requests:
            agent_id = await self.spawn(request)
            agent_ids.append(agent_id)

        # Wait for all to complete
        results = {}
        for agent_id in agent_ids:
            results[agent_id] = await self.wait_for(agent_id)

        return results

    async def wait_for(self, agent_id: str, timeout: int | None = None) -> AgentResult:
        """
        Wait for a sub-agent to complete.

        Args:
            agent_id: The agent ID to wait for.
            timeout: Optional timeout in seconds.

        Returns:
            AgentResult from the agent.

        Raises:
            KeyError: If agent_id not found.
            asyncio.TimeoutError: If timeout exceeded.
        """
        if agent_id not in self._tasks:
            # Check if we have a cached result
            if agent_id in self._results:
                return self._results[agent_id]
            raise KeyError(f"Agent {agent_id} not found")

        task = self._tasks[agent_id]

        if timeout:
            return await asyncio.wait_for(task, timeout=timeout)
        return await task

    async def list_running(self) -> list[dict]:
        """
        List all running sub-agents.

        Returns:
            List of agent info dicts.
        """
        async with self._lock:
            return [a.to_dict() for a in self._agents.values() if a.status == "running"]

    async def list_all(self) -> list[dict]:
        """
        List all sub-agents (including completed).

        Returns:
            List of agent info dicts.
        """
        async with self._lock:
            return [a.to_dict() for a in self._agents.values()]

    async def cancel(self, agent_id: str) -> bool:
        """
        Cancel a running sub-agent.

        Args:
            agent_id: The agent ID to cancel.

        Returns:
            True if cancelled, False if not found or already completed.
        """
        if agent_id not in self._tasks:
            return False

        task = self._tasks[agent_id]
        if task.done():
            return False

        task.cancel()

        async with self._lock:
            if agent_id in self._agents:
                self._agents[agent_id].status = "cancelled"
                self._save_state()

        return True

    async def cleanup_old(self, max_age_hours: int = 24) -> int:
        """
        Remove old agent records from state.

        Args:
            max_age_hours: Remove agents older than this.

        Returns:
            Number of agents removed.
        """
        from datetime import timedelta

        cutoff = datetime.now() - timedelta(hours=max_age_hours)
        removed = 0

        async with self._lock:
            to_remove = []
            for agent_id, agent in self._agents.items():
                started = datetime.fromisoformat(agent.started_at)
                if started < cutoff and agent.status != "running":
                    to_remove.append(agent_id)

            for agent_id in to_remove:
                del self._agents[agent_id]
                self._results.pop(agent_id, None)
                self._tasks.pop(agent_id, None)
                removed += 1

            if removed > 0:
                self._save_state()

        return removed

    async def remove(self, agent_id: str) -> bool:
        """
        Remove an agent record from state (regardless of status).

        Args:
            agent_id: The agent ID to remove.

        Returns:
            True if removed, False if not found.
        """
        async with self._lock:
            if agent_id not in self._agents:
                return False

            # Cancel task if still running
            if agent_id in self._tasks:
                task = self._tasks[agent_id]
                if not task.done():
                    task.cancel()
                del self._tasks[agent_id]

            del self._agents[agent_id]
            self._results.pop(agent_id, None)
            self._save_state()
            return True

    async def clear_completed(self) -> int:
        """
        Remove all completed/failed/cancelled agents from state.

        Returns:
            Number of agents removed.
        """
        removed = 0
        async with self._lock:
            to_remove = [
                agent_id
                for agent_id, agent in self._agents.items()
                if agent.status in ("completed", "failed", "cancelled")
            ]
            for agent_id in to_remove:
                del self._agents[agent_id]
                self._results.pop(agent_id, None)
                self._tasks.pop(agent_id, None)
                removed += 1

            if removed > 0:
                self._save_state()

        return removed


# Global singleton
_orchestrator: Orchestrator | None = None


def get_orchestrator() -> Orchestrator:
    """Get the global Orchestrator instance."""
    global _orchestrator
    if _orchestrator is None:
        _orchestrator = Orchestrator()
    return _orchestrator
