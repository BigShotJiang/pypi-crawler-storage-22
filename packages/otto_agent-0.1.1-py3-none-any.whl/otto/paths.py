# Codex was here
"""
Filesystem layout and path helpers for the Otto application.

This module centralizes the canonical locations of Otto's configuration, runtime
state, and user-installed extensions. It exposes `pathlib.Path` constants for
directories and files under `OTTO_HOME` (default: `~/.otto`, override via the
`OTTO_HOME` environment variable) and includes small helpers such as
`ensure_dirs()` to create the expected directory structure.

Contract:
- Everything under OTTO_HOME (default ~/.otto) is runtime state, config, and extensions.
- The codebase itself must not assume a checkout path like ~/agent.
"""

from __future__ import annotations

import os
from pathlib import Path


def _expand_dir(value: str | None, default: Path) -> Path:
    if not value:
        return default
    return Path(value).expanduser()


def _resolve_home() -> Path:
    explicit_otto = os.environ.get("OTTO_HOME")
    if explicit_otto:
        return Path(explicit_otto).expanduser()

    return Path.home() / ".otto"


# Root runtime directory
OTTO_HOME: Path = _resolve_home()

# Core config/state
CONFIG_DIR: Path = OTTO_HOME / "config"
ENV_FILE: Path = CONFIG_DIR / ".env"
BOT_STATE_FILE: Path = CONFIG_DIR / "bot_state.json"
BRAINFILE: Path = OTTO_HOME / "brainfile.md"

# Runtime data
LOGS_DIR: Path = OTTO_HOME / "logs"
DATA_DIR: Path = OTTO_HOME / "data"
PHOTOS_DIR: Path = OTTO_HOME / "photos"
OUTPUTS_DIR: Path = OTTO_HOME / "outputs"
PIDS_DIR: Path = OTTO_HOME / "pids"
RUN_DIR: Path = OTTO_HOME / "run"  # Transient runtime files (ready markers, restart notifications)

# Feature directories
MEMORY_DIR: Path = OTTO_HOME / "memory"
SESSIONS_DIR: Path = OTTO_HOME / "sessions"
SCHEDULES_DIR: Path = OTTO_HOME / "schedules"
SKILLS_DIR: Path = OTTO_HOME / "skills"
POLICIES_DIR: Path = OTTO_HOME / "policies"


def ensure_dirs() -> None:
    """Create Otto runtime directories if missing."""
    for d in (
        OTTO_HOME,
        CONFIG_DIR,
        LOGS_DIR,
        DATA_DIR,
        PHOTOS_DIR,
        OUTPUTS_DIR,
        PIDS_DIR,
        RUN_DIR,
        MEMORY_DIR,
        SESSIONS_DIR,
        SCHEDULES_DIR,
        SKILLS_DIR,
        POLICIES_DIR,
    ):
        d.mkdir(parents=True, exist_ok=True)


def get_workdir() -> Path:
    """Get the working directory for backend execution."""
    value = os.environ.get("OTTO_WORKDIR")
    if value:
        return Path(value).expanduser()
    return Path.cwd()


_DEFAULT_AGENT_PROMPT = "You are a helpful assistant completing a task."


def build_agent_system_prompt() -> str:
    """
    Build a clean, model-agnostic system prompt for agents.

    Extracts only persona/context/rules from brainfile, excluding:
    - Internal backend configurations
    - Orchestration settings
    - Job queue state
    - Any mention of specific AI systems (Claude, etc.)

    This ensures the prompt works correctly when routing to
    non-Anthropic models via Ollama, OpenRouter, etc.
    """
    import yaml

    if not BRAINFILE.exists():
        return _DEFAULT_AGENT_PROMPT

    content = BRAINFILE.read_text()

    # Parse YAML frontmatter if present
    if not content.startswith("---"):
        # No frontmatter, use content directly
        return content

    end = content.find("\n---", 3)
    if end == -1:
        return _DEFAULT_AGENT_PROMPT

    try:
        data = yaml.safe_load(content[4:end]) or {}
    except yaml.YAMLError:
        return _DEFAULT_AGENT_PROMPT

    # Extract only relevant sections
    persona = data.get("persona", {})
    context = data.get("context", {})
    rules = data.get("rules", {})

    # Build clean prompt
    parts = []

    # Identity (without mentioning specific AI systems)
    identity = persona.get("identity", "")
    if identity:
        parts.append(identity)
    elif persona.get("name"):
        parts.append(f"You are {persona['name']}.")

    # Role and style
    if persona.get("role"):
        parts.append(f"Role: {persona['role']}")
    if persona.get("style"):
        parts.append(f"Style: {persona['style']}")

    # Values
    values = persona.get("values", [])
    if values:
        parts.append(f"Values: {', '.join(values)}")

    # User context (if any)
    user_ctx = context.get("user", {})
    if user_ctx and isinstance(user_ctx, dict):
        user_lines = [f"  {k}: {v}" for k, v in user_ctx.items() if v]
        if user_lines:
            parts.append("User context:")
            parts.extend(user_lines)

    # Preferences
    prefs = context.get("preferences", [])
    if prefs:
        parts.append("Preferences:")
        for p in prefs:
            parts.append(f"  - {p}")

    # Rules/governance
    if rules.get("governance"):
        parts.append(f"Rules: {rules['governance']}")
    if rules.get("output_handling"):
        parts.append(f"Output: {rules['output_handling']}")
    if rules.get("capabilities"):
        parts.append(f"Capabilities: {rules['capabilities']}")

    # Get markdown content after frontmatter (skip internal tool docs)
    markdown_content = content[end + 4 :].strip()
    # Only include markdown if it's not just default tool documentation
    if markdown_content and "# Otto Brainfile" not in markdown_content:
        parts.append("")
        parts.append(markdown_content)

    if not parts:
        return _DEFAULT_AGENT_PROMPT

    return "\n".join(parts)
