"""
Granular Tool Policy Engine (Phase 3, Pillar 3).

Content-aware policy enforcement with cascading rules, argument validation,
rate limiting, and policy presets.

Architecture:
    Policies cascade from broad to specific:

        Global defaults  ->  Server-level  ->  Tool-level
        (lowest priority)                      (highest priority)

    Each level can set:
    - verdict: allow / deny / ask
    - rate_limit: max calls per minute
    - argument rules: path_must_match, path_must_not_match, required, blocked_values

    Tool-level overrides server-level which overrides global defaults.

Config schema (settings.yaml):
    gateway:
      policy:
        preset: moderate  # strict | moderate | permissive | custom

        # Global defaults (lowest priority)
        defaults:
          verdict: allow
          rate_limit: 60

        # Per-server overrides
        servers:
          filesystem:
            verdict: allow
            rate_limit: 30
            tools:
              write_file:
                verdict: ask
                rate_limit: 10
                args:
                  path:
                    must_match: ["^/home/", "^/tmp/"]
                    must_not_match: ["\\.\\."]
              delete_file:
                verdict: deny
              read_file:
                verdict: allow

          exa:
            verdict: allow
            rate_limit: 20

        # Argument validation templates for dangerous tool patterns
        arg_templates:
          file_operations:
            path:
              must_not_match: ["\\.\\.", "~/.ssh", "~/.gnupg"]
              required: true
          shell_operations:
            command:
              must_not_match: ["rm\\s+-rf", "dd\\s+.*of=/dev"]
              required: true
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Core types
# ---------------------------------------------------------------------------


class ToolVerdict(Enum):
    """Verdict for a specific tool invocation."""

    ALLOW = "allow"
    DENY = "deny"
    ASK = "ask"  # Prompt user (maps to PolicyVerdict.PROMPT)


@dataclass
class ArgRule:
    """
    Validation rule for a single tool argument.

    Attributes:
        must_match: Regexes the value MUST match at least one of (if set).
        must_not_match: Regexes the value MUST NOT match any of.
        required: Whether the argument must be present.
        blocked_values: Exact values that are always denied.
        max_length: Maximum string length (0 = unlimited).
    """

    must_match: list[str] = field(default_factory=list)
    must_not_match: list[str] = field(default_factory=list)
    required: bool = False
    blocked_values: list[str] = field(default_factory=list)
    max_length: int = 0

    # Compiled patterns (built lazily)
    _compiled_match: list[re.Pattern] | None = field(default=None, repr=False)
    _compiled_not_match: list[re.Pattern] | None = field(default=None, repr=False)

    def _compile(self) -> None:
        if self._compiled_match is None:
            self._compiled_match = [re.compile(p, re.IGNORECASE) for p in self.must_match]
        if self._compiled_not_match is None:
            self._compiled_not_match = [re.compile(p, re.IGNORECASE) for p in self.must_not_match]

    def validate(self, arg_name: str, value: Any) -> str | None:
        """
        Validate an argument value against this rule.

        Returns None if valid, or an error message if invalid.
        """
        self._compile()

        str_value = str(value) if value is not None else ""

        # Required check
        if self.required and (value is None or str_value == ""):
            return f"Argument '{arg_name}' is required"

        # Skip further checks if value is empty and not required
        if value is None or str_value == "":
            return None

        # Blocked values (exact match)
        if str_value in self.blocked_values:
            return f"Argument '{arg_name}' has a blocked value"

        # Max length
        if self.max_length > 0 and len(str_value) > self.max_length:
            return (
                f"Argument '{arg_name}' exceeds max length ({len(str_value)} > {self.max_length})"
            )

        # Must match at least one pattern
        if self._compiled_match:
            if not any(p.search(str_value) for p in self._compiled_match):
                return (
                    f"Argument '{arg_name}' does not match required pattern "
                    f"(value: {str_value[:80]})"
                )

        # Must not match any pattern
        if self._compiled_not_match:
            for p in self._compiled_not_match:
                if p.search(str_value):
                    return f"Argument '{arg_name}' matches blocked pattern '{p.pattern}'"

        return None

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> ArgRule:
        """Parse an ArgRule from a config dict."""
        return cls(
            must_match=config.get("must_match", []),
            must_not_match=config.get("must_not_match", []),
            required=bool(config.get("required", False)),
            blocked_values=config.get("blocked_values", []),
            max_length=int(config.get("max_length", 0)),
        )


@dataclass
class ToolPolicy:
    """
    Policy for a specific tool on a specific server.

    Attributes:
        verdict: What to do when this tool is called.
        rate_limit: Max calls per minute (0 = inherit from parent / unlimited).
        args: Validation rules per argument name.
    """

    verdict: ToolVerdict = ToolVerdict.ALLOW
    rate_limit: int = 0
    args: dict[str, ArgRule] = field(default_factory=dict)

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> ToolPolicy:
        """Parse a ToolPolicy from config dict."""
        verdict_str = str(config.get("verdict", "allow")).lower()
        verdict_map = {
            "allow": ToolVerdict.ALLOW,
            "deny": ToolVerdict.DENY,
            "ask": ToolVerdict.ASK,
            "prompt": ToolVerdict.ASK,
            "auto": ToolVerdict.ALLOW,
        }
        verdict = verdict_map.get(verdict_str, ToolVerdict.ALLOW)

        args: dict[str, ArgRule] = {}
        for arg_name, arg_conf in (config.get("args") or {}).items():
            if isinstance(arg_conf, dict):
                args[arg_name] = ArgRule.from_config(arg_conf)

        return cls(
            verdict=verdict,
            rate_limit=int(config.get("rate_limit", 0)),
            args=args,
        )


@dataclass
class ServerToolPolicy:
    """
    Policy for a server with optional per-tool overrides.

    Attributes:
        verdict: Default verdict for all tools on this server.
        rate_limit: Default rate limit for tools on this server.
        tools: Per-tool policy overrides.
        args: Default argument rules for all tools on this server.
    """

    verdict: ToolVerdict = ToolVerdict.ALLOW
    rate_limit: int = 0
    tools: dict[str, ToolPolicy] = field(default_factory=dict)
    args: dict[str, ArgRule] = field(default_factory=dict)

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> ServerToolPolicy:
        """Parse a ServerToolPolicy from config dict."""
        verdict_str = str(config.get("verdict", "allow")).lower()
        verdict_map = {
            "allow": ToolVerdict.ALLOW,
            "deny": ToolVerdict.DENY,
            "ask": ToolVerdict.ASK,
            "prompt": ToolVerdict.ASK,
            "auto": ToolVerdict.ALLOW,
        }
        verdict = verdict_map.get(verdict_str, ToolVerdict.ALLOW)

        tools: dict[str, ToolPolicy] = {}
        for tool_name, tool_conf in (config.get("tools") or {}).items():
            if isinstance(tool_conf, dict):
                tools[tool_name] = ToolPolicy.from_config(tool_conf)

        args: dict[str, ArgRule] = {}
        for arg_name, arg_conf in (config.get("args") or {}).items():
            if isinstance(arg_conf, dict):
                args[arg_name] = ArgRule.from_config(arg_conf)

        return cls(
            verdict=verdict,
            rate_limit=int(config.get("rate_limit", 0)),
            tools=tools,
            args=args,
        )


# ---------------------------------------------------------------------------
# Argument templates
# ---------------------------------------------------------------------------


@dataclass
class ArgTemplate:
    """
    Reusable argument validation template.

    Templates define common validation patterns (e.g., file_operations,
    shell_operations) that can be applied to tools matching certain categories.
    """

    args: dict[str, ArgRule] = field(default_factory=dict)

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> ArgTemplate:
        args: dict[str, ArgRule] = {}
        for arg_name, arg_conf in config.items():
            if isinstance(arg_conf, dict):
                args[arg_name] = ArgRule.from_config(arg_conf)
        return cls(args=args)


# ---------------------------------------------------------------------------
# Policy presets
# ---------------------------------------------------------------------------

# Tool categories for presets
_FILE_WRITE_TOOLS = {"write_file", "edit_file", "write", "edit", "multiedit", "patch"}
_FILE_DELETE_TOOLS = {"delete_file", "remove", "unlink"}
_SHELL_TOOLS = {"bash", "shell", "exec", "commandexecution", "run_command"}
_NETWORK_TOOLS = {"web_search", "fetch", "http_request", "websearch", "webfetch"}

PRESETS: dict[str, dict[str, Any]] = {
    "permissive": {
        "description": "Minimal restrictions. Allow most operations, deny only catastrophic ones.",
        "defaults": {
            "verdict": "allow",
            "rate_limit": 0,
        },
        "arg_templates": {
            "file_operations": {
                "path": {
                    "must_not_match": [
                        r"(^|/)\.\.(/|$)",  # path traversal
                    ],
                },
            },
            "shell_operations": {
                "command": {
                    "must_not_match": [
                        r"rm\s+(-[rf]+\s+)*(/\s*$|/\*)",
                        r":\(\)\{\s*:\|:&\s*\};:",
                        r"dd\s+.*of=/dev/sd",
                        r"mkfs\.",
                    ],
                },
            },
        },
    },
    "moderate": {
        "description": "Balanced. Allow reads freely, ask for writes/deletes, enforce rate limits.",
        "defaults": {
            "verdict": "allow",
            "rate_limit": 60,
        },
        "tool_verdicts": {
            "write_file": "ask",
            "edit_file": "ask",
            "write": "ask",
            "edit": "ask",
            "multiedit": "ask",
            "patch": "ask",
            "delete_file": "deny",
            "remove": "deny",
            "unlink": "deny",
            "bash": "ask",
            "shell": "ask",
            "exec": "ask",
            "run_command": "ask",
        },
        "arg_templates": {
            "file_operations": {
                "path": {
                    "must_not_match": [
                        r"(^|/)\.\.(/|$)",
                        r"~/.ssh",
                        r"~/.gnupg",
                        r"~/.aws",
                    ],
                },
            },
            "shell_operations": {
                "command": {
                    "must_not_match": [
                        r"rm\s+(-[rf]+\s+)*(/\s*$|/\*)",
                        r":\(\)\{\s*:\|:&\s*\};:",
                        r"dd\s+.*of=/dev/sd",
                        r"mkfs\.",
                        r"curl\s+.*\|\s*(bash|sh)",
                    ],
                    "required": True,
                },
            },
        },
    },
    "strict": {
        "description": "Maximum control. Ask for everything, deny deletes and shell, tight rate limits.",
        "defaults": {
            "verdict": "ask",
            "rate_limit": 20,
        },
        "tool_verdicts": {
            "delete_file": "deny",
            "remove": "deny",
            "unlink": "deny",
            "bash": "deny",
            "shell": "deny",
            "exec": "deny",
            "run_command": "deny",
        },
        "arg_templates": {
            "file_operations": {
                "path": {
                    "must_not_match": [
                        r"(^|/)\.\.(/|$)",
                        r"~/\.",  # all dotfiles
                        r"/etc",
                        r"/usr",
                        r"/var",
                    ],
                    "required": True,
                },
            },
            "shell_operations": {
                "command": {
                    "must_not_match": [r".*"],  # block everything
                    "required": True,
                },
            },
        },
    },
}


def get_preset_names() -> list[str]:
    """Return available preset names."""
    return list(PRESETS.keys())


def get_preset(name: str) -> dict[str, Any] | None:
    """Get a preset config by name."""
    return PRESETS.get(name)


# ---------------------------------------------------------------------------
# Policy Engine
# ---------------------------------------------------------------------------

# Map tool names to argument template categories
_TOOL_TO_TEMPLATE: dict[str, str] = {}
for _t in _FILE_WRITE_TOOLS | _FILE_DELETE_TOOLS | {"read_file", "list_directory", "read_dir"}:
    _TOOL_TO_TEMPLATE[_t] = "file_operations"
for _t in _SHELL_TOOLS:
    _TOOL_TO_TEMPLATE[_t] = "shell_operations"


@dataclass
class PolicyConfig:
    """
    Complete policy configuration with cascading resolution.

    Attributes:
        preset: Active preset name (or "custom").
        defaults: Global default policy.
        servers: Per-server policy overrides.
        arg_templates: Reusable argument validation templates.
        tool_verdicts: Global per-tool verdict overrides (from presets).
    """

    preset: str = "permissive"
    defaults: ToolPolicy = field(default_factory=ToolPolicy)
    servers: dict[str, ServerToolPolicy] = field(default_factory=dict)
    arg_templates: dict[str, ArgTemplate] = field(default_factory=dict)
    tool_verdicts: dict[str, ToolVerdict] = field(default_factory=dict)

    @classmethod
    def from_config(cls, config: dict[str, Any] | None) -> PolicyConfig:
        """
        Parse PolicyConfig from the gateway.policy section of settings.yaml.

        If a preset is specified, its defaults are loaded first, then user
        overrides are applied on top.
        """
        if not config:
            return cls()

        preset_name = str(config.get("preset", "permissive")).lower()

        # Start from preset defaults
        preset = PRESETS.get(preset_name, PRESETS["permissive"])

        # Parse global defaults (preset defaults + user overrides)
        defaults_conf = {**preset.get("defaults", {})}
        if "defaults" in config and isinstance(config["defaults"], dict):
            defaults_conf.update(config["defaults"])
        defaults = ToolPolicy.from_config(defaults_conf)

        # Parse tool verdicts from preset
        tool_verdicts: dict[str, ToolVerdict] = {}
        verdict_map = {
            "allow": ToolVerdict.ALLOW,
            "deny": ToolVerdict.DENY,
            "ask": ToolVerdict.ASK,
        }
        for tool_name, v_str in preset.get("tool_verdicts", {}).items():
            tool_verdicts[tool_name] = verdict_map.get(str(v_str).lower(), ToolVerdict.ALLOW)

        # Parse arg templates (preset + user overrides)
        arg_templates: dict[str, ArgTemplate] = {}
        for tmpl_name, tmpl_conf in preset.get("arg_templates", {}).items():
            if isinstance(tmpl_conf, dict):
                arg_templates[tmpl_name] = ArgTemplate.from_config(tmpl_conf)
        for tmpl_name, tmpl_conf in (config.get("arg_templates") or {}).items():
            if isinstance(tmpl_conf, dict):
                arg_templates[tmpl_name] = ArgTemplate.from_config(tmpl_conf)

        # Parse per-server policies
        servers: dict[str, ServerToolPolicy] = {}
        for srv_name, srv_conf in (config.get("servers") or {}).items():
            if isinstance(srv_conf, dict):
                servers[srv_name] = ServerToolPolicy.from_config(srv_conf)

        return cls(
            preset=preset_name,
            defaults=defaults,
            servers=servers,
            arg_templates=arg_templates,
            tool_verdicts=tool_verdicts,
        )


@dataclass
class PolicyResult:
    """
    Result of evaluating a tool request against the policy engine.

    Attributes:
        verdict: The resolved verdict (allow/deny/ask).
        rate_limit: The resolved rate limit (calls per minute, 0 = unlimited).
        arg_errors: List of argument validation error messages.
        reason: Human-readable explanation of the verdict.
    """

    verdict: ToolVerdict = ToolVerdict.ALLOW
    rate_limit: int = 0
    arg_errors: list[str] = field(default_factory=list)
    reason: str = ""

    @property
    def allowed(self) -> bool:
        return self.verdict == ToolVerdict.ALLOW and not self.arg_errors

    @property
    def denied(self) -> bool:
        return self.verdict == ToolVerdict.DENY or bool(self.arg_errors)

    @property
    def needs_prompt(self) -> bool:
        return self.verdict == ToolVerdict.ASK and not self.arg_errors


class PolicyEngine:
    """
    Evaluates tool requests against cascading policy rules.

    Resolution order (highest priority first):
    1. Tool-level policy (server.tools.tool_name)
    2. Server-level policy (server defaults)
    3. Global tool verdicts (preset-based per-tool rules)
    4. Global defaults

    Argument validation is cumulative: templates + server args + tool args
    are all checked.
    """

    def __init__(self, config: PolicyConfig):
        self._config = config

    @property
    def config(self) -> PolicyConfig:
        return self._config

    def evaluate(
        self,
        server_name: str,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
    ) -> PolicyResult:
        """
        Evaluate a tool request against the full policy cascade.

        Args:
            server_name: MCP server name
            tool_name: Tool name within the server
            arguments: Tool arguments to validate

        Returns:
            PolicyResult with verdict, rate limit, and any arg errors
        """
        arguments = arguments or {}

        # --- Resolve verdict (cascading) ---
        verdict, rate_limit, reason = self._resolve_verdict_and_rate(server_name, tool_name)

        # --- Argument validation ---
        arg_errors = self._validate_arguments(server_name, tool_name, arguments)

        if arg_errors:
            reason = f"Argument validation failed: {'; '.join(arg_errors)}"

        return PolicyResult(
            verdict=verdict,
            rate_limit=rate_limit,
            arg_errors=arg_errors,
            reason=reason,
        )

    def _resolve_verdict_and_rate(
        self, server_name: str, tool_name: str
    ) -> tuple[ToolVerdict, int, str]:
        """
        Resolve verdict and rate limit through the cascade.

        Returns (verdict, rate_limit, reason).
        """
        # Start with global defaults
        verdict = self._config.defaults.verdict
        rate_limit = self._config.defaults.rate_limit
        reason = f"Global default: {verdict.value}"

        # Check global tool verdicts (preset-level per-tool rules)
        tool_lower = tool_name.lower()
        if tool_lower in self._config.tool_verdicts:
            verdict = self._config.tool_verdicts[tool_lower]
            reason = f"Global tool rule for '{tool_name}': {verdict.value}"

        # Check server-level
        server_policy = self._config.servers.get(server_name)
        if server_policy is not None:
            # Server default verdict overrides global
            verdict = server_policy.verdict
            reason = f"Server '{server_name}' default: {verdict.value}"

            if server_policy.rate_limit > 0:
                rate_limit = server_policy.rate_limit

            # Check tool-level within server
            tool_policy = server_policy.tools.get(tool_name)
            if tool_policy is not None:
                verdict = tool_policy.verdict
                reason = f"Tool '{server_name}.{tool_name}': {verdict.value}"

                if tool_policy.rate_limit > 0:
                    rate_limit = tool_policy.rate_limit

        return verdict, rate_limit, reason

    def _validate_arguments(
        self,
        server_name: str,
        tool_name: str,
        arguments: dict[str, Any],
    ) -> list[str]:
        """
        Validate tool arguments against all applicable rules.

        Checks (in order, cumulative):
        1. Argument templates (based on tool category)
        2. Server-level argument rules
        3. Tool-level argument rules
        """
        errors: list[str] = []

        # 1. Argument templates
        tool_lower = tool_name.lower()
        template_name = _TOOL_TO_TEMPLATE.get(tool_lower)
        if template_name and template_name in self._config.arg_templates:
            template = self._config.arg_templates[template_name]
            errors.extend(self._check_arg_rules(template.args, arguments))

        # 2. Server-level args
        server_policy = self._config.servers.get(server_name)
        if server_policy is not None:
            errors.extend(self._check_arg_rules(server_policy.args, arguments))

            # 3. Tool-level args
            tool_policy = server_policy.tools.get(tool_name)
            if tool_policy is not None:
                errors.extend(self._check_arg_rules(tool_policy.args, arguments))

        return errors

    @staticmethod
    def _check_arg_rules(rules: dict[str, ArgRule], arguments: dict[str, Any]) -> list[str]:
        """Check argument values against a set of ArgRules."""
        errors: list[str] = []
        for arg_name, rule in rules.items():
            value = arguments.get(arg_name)
            error = rule.validate(arg_name, value)
            if error:
                errors.append(error)
        return errors

    def get_effective_policy(self, server_name: str, tool_name: str) -> dict[str, Any]:
        """
        Return the effective (resolved) policy for a server.tool combination.

        Useful for debugging and the 'otto gateway validate' command.
        """
        verdict, rate_limit, reason = self._resolve_verdict_and_rate(server_name, tool_name)
        return {
            "server": server_name,
            "tool": tool_name,
            "verdict": verdict.value,
            "rate_limit": rate_limit,
            "reason": reason,
            "preset": self._config.preset,
        }


# ---------------------------------------------------------------------------
# Convenience: load policy engine from Otto's config
# ---------------------------------------------------------------------------


def load_policy_engine() -> PolicyEngine:
    """
    Load the policy engine from Otto's settings.yaml.

    Reads the 'gateway.policy' section and constructs a PolicyEngine.
    Falls back to permissive preset if no policy config exists.
    """
    from otto.config import get_setting

    policy_config = get_setting("gateway.policy")
    config = PolicyConfig.from_config(policy_config)
    return PolicyEngine(config)


# ---------------------------------------------------------------------------
# Policy validation helper
# ---------------------------------------------------------------------------


def validate_policy_config(config: dict[str, Any]) -> list[str]:
    """
    Validate a policy configuration dict and return a list of warnings/errors.

    Returns empty list if valid.
    """
    errors: list[str] = []

    preset = config.get("preset", "permissive")
    if preset not in PRESETS and preset != "custom":
        errors.append(f"Unknown preset: '{preset}'. Valid: {', '.join(PRESETS.keys())}, custom")

    # Validate server configs
    for srv_name, srv_conf in (config.get("servers") or {}).items():
        if not isinstance(srv_conf, dict):
            errors.append(f"Server '{srv_name}': expected dict, got {type(srv_conf).__name__}")
            continue

        verdict = srv_conf.get("verdict", "allow")
        if str(verdict).lower() not in {"allow", "deny", "ask", "prompt", "auto"}:
            errors.append(f"Server '{srv_name}': unknown verdict '{verdict}'")

        for tool_name, tool_conf in (srv_conf.get("tools") or {}).items():
            if not isinstance(tool_conf, dict):
                errors.append(f"Server '{srv_name}', tool '{tool_name}': expected dict")
                continue

            tv = tool_conf.get("verdict", "allow")
            if str(tv).lower() not in {"allow", "deny", "ask", "prompt", "auto"}:
                errors.append(f"Server '{srv_name}', tool '{tool_name}': unknown verdict '{tv}'")

            # Validate regex patterns
            for arg_name, arg_conf in (tool_conf.get("args") or {}).items():
                if not isinstance(arg_conf, dict):
                    continue
                for pattern_key in ("must_match", "must_not_match"):
                    for pattern in arg_conf.get(pattern_key, []):
                        try:
                            re.compile(pattern)
                        except re.error as e:
                            errors.append(
                                f"Server '{srv_name}', tool '{tool_name}', "
                                f"arg '{arg_name}', {pattern_key}: "
                                f"invalid regex '{pattern}': {e}"
                            )

    return errors


__all__ = [
    # Core types
    "ToolVerdict",
    "ArgRule",
    "ToolPolicy",
    "ServerToolPolicy",
    "ArgTemplate",
    "PolicyConfig",
    "PolicyResult",
    # Engine
    "PolicyEngine",
    # Presets
    "PRESETS",
    "get_preset_names",
    "get_preset",
    # Helpers
    "load_policy_engine",
    "validate_policy_config",
]
