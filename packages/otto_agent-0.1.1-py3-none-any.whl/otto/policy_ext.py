"""
User-Defined Policies as Code (Phase 5, Pillar 3).

Extends the Phase 3 policy engine with:
1. Policy expressions — Python expressions in YAML rules evaluated safely
2. Policy plugins — drop-in Python files in ~/.otto/policies/
3. Policy packs — shareable, exportable/importable policy bundles
4. Test harness — test policies against mock requests

Architecture:
    The expression engine provides a restricted evaluation sandbox.
    Only whitelisted builtins and a controlled namespace are available:

        when: "args.get('path', '').startswith('/tmp')"
        when: "tool == 'bash' and 'rm' in args.get('command', '')"
        when: "server == 'filesystem' and not path_ok(args.get('path', ''))"

    Plugins are Python files in ~/.otto/policies/ that define hook functions:
        def policy_hook(server, tool, args) -> str | None:
            '''Return 'deny', 'ask', 'allow', or None to skip.'''

    Policy packs are YAML files that bundle policy configs for sharing:
        # my-security-pack.yaml
        name: strict-filesystem
        version: 1
        description: Strict file access controls
        policy:
          servers:
            filesystem:
              verdict: ask
              tools:
                write_file:
                  verdict: deny

Config schema (settings.yaml):
    gateway:
      policy:
        # Expression rules evaluated in order; first match wins
        rules:
          - when: "tool == 'bash' and 'sudo' in args.get('command', '')"
            action: deny
            reason: "sudo commands are blocked"
          - when: "server == 'filesystem' and args.get('path', '').startswith('/tmp')"
            action: allow
            reason: "/tmp is always allowed"

        # Plugin directory (default: ~/.otto/policies/)
        plugins:
          enabled: true
          directory: ~/.otto/policies/

        # Installed policy packs
        packs:
          - path: ~/.otto/policies/packs/strict-fs.yaml
"""

from __future__ import annotations

import ast
import importlib.util
import logging
import re
import signal
import sys
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from otto.paths import OTTO_HOME

log = logging.getLogger(__name__)

_EXPRESSION_TIMEOUT_SECONDS = 2.0


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

POLICIES_DIR: Path = OTTO_HOME / "policies"
PACKS_DIR: Path = POLICIES_DIR / "packs"


def ensure_policy_dirs() -> None:
    """Create policy directories if missing."""
    POLICIES_DIR.mkdir(parents=True, exist_ok=True)
    PACKS_DIR.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# 1. Policy Expressions Engine
# ---------------------------------------------------------------------------

# Safe builtins for expression evaluation
_SAFE_BUILTINS: dict[str, Any] = {
    "True": True,
    "False": False,
    "None": None,
    "len": len,
    "str": str,
    "int": int,
    "float": float,
    "bool": bool,
    "list": list,
    "dict": dict,
    "set": set,
    "tuple": tuple,
    "any": any,
    "all": all,
    "min": min,
    "max": max,
    "abs": abs,
    "sorted": sorted,
    "isinstance": isinstance,
    "hasattr": hasattr,
    "getattr": getattr,
}


class ExpressionError(Exception):
    """Raised when a policy expression is invalid or unsafe."""


def _validate_expression_ast(expr: str) -> None:
    """
    Validate that an expression AST contains only safe operations.

    Blocks:
    - Import statements
    - Function/class definitions
    - Attribute access to dunder methods
    - exec/eval/compile calls
    - __builtins__ access
    """
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as e:
        raise ExpressionError(f"Syntax error in expression: {e}") from e

    _BLOCKED_NAMES = {
        "exec",
        "eval",
        "compile",
        "__import__",
        "open",
        "getattr",
        "setattr",
        "delattr",
        "globals",
        "locals",
        "vars",
        "__builtins__",
        "breakpoint",
        "exit",
        "quit",
        "input",
        "print",
    }
    # Note: getattr is in _SAFE_BUILTINS for controlled use, but we block
    # raw access to the name in expressions as a precaution. The safe version
    # is available via the namespace.

    for node in ast.walk(tree):
        # Block imports
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            raise ExpressionError("Import statements not allowed in expressions")

        # Block function/class definitions
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            raise ExpressionError("Definitions not allowed in expressions")

        # Block dunder attribute access
        if isinstance(node, ast.Attribute):
            if node.attr.startswith("__") and node.attr.endswith("__"):
                raise ExpressionError(f"Dunder attribute access not allowed: {node.attr}")

        # Block dangerous name references
        if isinstance(node, ast.Name):
            if node.id in _BLOCKED_NAMES:
                raise ExpressionError(f"Name '{node.id}' not allowed in expressions")

        # Block starred expressions (prevent unpacking attacks)
        if isinstance(node, ast.Starred):
            raise ExpressionError("Starred expressions not allowed")


def validate_expression(expr: str) -> list[str]:
    """
    Validate a policy expression and return list of errors (empty if valid).

    This is the public validation API — does NOT execute the expression.
    """
    errors: list[str] = []
    try:
        _validate_expression_ast(expr)
    except ExpressionError as e:
        errors.append(str(e))
    except Exception as e:
        errors.append(f"Unexpected error validating expression: {e}")
    return errors


def evaluate_expression(
    expr: str,
    server: str,
    tool: str,
    args: dict[str, Any],
) -> bool:
    """
    Safely evaluate a policy expression in a restricted namespace.

    The expression has access to:
    - server: str — MCP server name
    - tool: str — tool name
    - args: dict — tool arguments
    - re: re module (for pattern matching)
    - path_ok(p): helper that checks path doesn't contain traversal

    Returns the boolean result of the expression.
    Raises ExpressionError on invalid expressions.
    """
    _validate_expression_ast(expr)

    def _path_ok(path: str) -> bool:
        """Check that a path doesn't contain traversal or access sensitive dirs."""
        if not path:
            return False
        blocked = ["..", "~/.ssh", "~/.gnupg", "~/.aws", "/etc/shadow", "/etc/passwd"]
        return not any(b in path for b in blocked)

    namespace: dict[str, Any] = {
        "__builtins__": {},  # Block all builtins
        # Safe builtins
        **_SAFE_BUILTINS,
        # Request context
        "server": server,
        "tool": tool,
        "args": dict(args),  # defensive copy
        # Utility functions
        "re": re,
        "path_ok": _path_ok,
        "match": lambda pattern, string: bool(re.search(pattern, str(string))),
    }

    def _evaluate() -> Any:
        return eval(expr, namespace)  # noqa: S307

    def _run_with_signal_timeout(timeout_seconds: float) -> Any:
        def _timeout_handler(signum: int, frame: Any) -> None:
            raise TimeoutError("expression evaluation timed out")

        old_handler = signal.getsignal(signal.SIGALRM)
        old_timer = signal.setitimer(signal.ITIMER_REAL, 0.0)
        try:
            signal.signal(signal.SIGALRM, _timeout_handler)
            signal.setitimer(signal.ITIMER_REAL, timeout_seconds)
            return _evaluate()
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0.0)
            signal.signal(signal.SIGALRM, old_handler)
            if old_timer != (0.0, 0.0):
                signal.setitimer(signal.ITIMER_REAL, old_timer[0], old_timer[1])

    def _run_with_thread_timeout(timeout_seconds: float) -> Any:
        result: dict[str, Any] = {}
        error: dict[str, BaseException] = {}
        done = threading.Event()

        def _target() -> None:
            try:
                result["value"] = _evaluate()
            except BaseException as e:  # pragma: no cover - best-effort fallback
                error["exc"] = e
            finally:
                done.set()

        worker = threading.Thread(target=_target, daemon=True)
        worker.start()
        if not done.wait(timeout_seconds):
            raise ExpressionError(f"Expression evaluation timed out after {timeout_seconds:.1f}s")
        if "exc" in error:
            raise error["exc"]
        return result.get("value")

    try:
        can_use_signal_timeout = (
            hasattr(signal, "setitimer") and threading.current_thread() is threading.main_thread()
        )
        if can_use_signal_timeout:
            result = _run_with_signal_timeout(_EXPRESSION_TIMEOUT_SECONDS)
        else:
            result = _run_with_thread_timeout(_EXPRESSION_TIMEOUT_SECONDS)
        return bool(result)
    except TimeoutError as e:
        raise ExpressionError(
            f"Expression evaluation timed out after {_EXPRESSION_TIMEOUT_SECONDS:.1f}s"
        ) from e
    except ExpressionError:
        raise
    except Exception as e:
        raise ExpressionError(f"Error evaluating expression '{expr}': {e}") from e


@dataclass
class ExpressionRule:
    """
    A policy rule with a Python expression condition.

    Attributes:
        when: Python expression that evaluates to bool
        action: Verdict to apply when expression is true (allow/deny/ask)
        reason: Human-readable reason for the rule
        priority: Lower number = higher priority (default 100)
    """

    when: str
    action: str  # "allow", "deny", "ask"
    reason: str = ""
    priority: int = 100

    def __post_init__(self) -> None:
        if self.action not in {"allow", "deny", "ask"}:
            raise ValueError(f"Invalid action '{self.action}', must be allow/deny/ask")

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> ExpressionRule:
        """Parse from YAML config."""
        return cls(
            when=str(config.get("when", "False")),
            action=str(config.get("action", "deny")).lower(),
            reason=str(config.get("reason", "")),
            priority=int(config.get("priority", 100)),
        )

    def matches(self, server: str, tool: str, args: dict[str, Any]) -> bool:
        """Evaluate the expression against a request. Returns True if rule matches."""
        try:
            return evaluate_expression(self.when, server, tool, args)
        except ExpressionError as e:
            log.warning("Expression rule error: %s — skipping rule", e)
            return False


@dataclass
class ExpressionEngine:
    """
    Evaluates a list of expression rules against tool requests.

    Rules are evaluated in priority order (lower = higher priority).
    First matching rule wins. If no rule matches, returns None
    (fallback to standard policy engine).
    """

    rules: list[ExpressionRule] = field(default_factory=list)

    @classmethod
    def from_config(cls, config: list[dict[str, Any]] | None) -> ExpressionEngine:
        """Parse from the gateway.policy.rules section of settings.yaml."""
        if not config:
            return cls()
        rules = []
        for rule_conf in config:
            if isinstance(rule_conf, dict):
                try:
                    rules.append(ExpressionRule.from_config(rule_conf))
                except (ValueError, ExpressionError) as e:
                    log.warning("Skipping invalid expression rule: %s", e)
        # Sort by priority (lower = higher priority)
        rules.sort(key=lambda r: r.priority)
        return cls(rules=rules)

    def evaluate(self, server: str, tool: str, args: dict[str, Any]) -> tuple[str, str] | None:
        """
        Evaluate rules against a request.

        Returns (action, reason) for the first matching rule, or None if
        no rule matches.
        """
        for rule in self.rules:
            if rule.matches(server, tool, args):
                return rule.action, rule.reason or f"Matched rule: {rule.when}"
        return None


# ---------------------------------------------------------------------------
# 2. Policy Plugins
# ---------------------------------------------------------------------------


@dataclass
class PolicyPlugin:
    """
    A loaded policy plugin from ~/.otto/policies/.

    Plugins are Python files that define hook functions:
        def policy_hook(server: str, tool: str, args: dict) -> str | None:
            '''Return 'deny', 'ask', 'allow', or None to skip.'''
    """

    name: str
    path: Path
    hook: Any  # Callable[[str, str, dict], str | None]
    description: str = ""

    def evaluate(self, server: str, tool: str, args: dict[str, Any]) -> tuple[str, str] | None:
        """
        Call the plugin hook.

        Returns (action, reason) or None if the plugin doesn't match.
        """
        try:
            result = self.hook(server, tool, args)
            if result and isinstance(result, str) and result.lower() in {"allow", "deny", "ask"}:
                return result.lower(), f"Plugin '{self.name}'"
            return None
        except Exception as e:
            log.warning("Plugin '%s' error: %s", self.name, e)
            return None


class PluginLoader:
    """
    Discovers and loads policy plugins from a directory.

    Plugins are .py files that must define a `policy_hook` function.
    Optional: `PLUGIN_DESCRIPTION` string for documentation.
    """

    def __init__(self, directory: Path | None = None):
        self.directory = directory or POLICIES_DIR
        self._plugins: list[PolicyPlugin] = []
        self._loaded = False

    def load(self) -> list[PolicyPlugin]:
        """Load all plugins from the directory. Caches results."""
        if self._loaded:
            return self._plugins

        self._plugins = []
        if not self.directory.is_dir():
            self._loaded = True
            return self._plugins

        for py_file in sorted(self.directory.glob("*.py")):
            if py_file.name.startswith("_"):
                continue
            try:
                plugin = self._load_plugin(py_file)
                if plugin:
                    self._plugins.append(plugin)
                    log.info("Loaded policy plugin: %s", plugin.name)
            except Exception as e:
                log.warning("Failed to load plugin %s: %s", py_file.name, e)

        self._loaded = True
        return self._plugins

    def reload(self) -> list[PolicyPlugin]:
        """Force-reload all plugins."""
        self._loaded = False
        self._plugins = []
        return self.load()

    @staticmethod
    def _load_plugin(path: Path) -> PolicyPlugin | None:
        """Load a single plugin file."""
        module_name = f"otto_policy_plugin_{path.stem}"

        spec = importlib.util.spec_from_file_location(module_name, path)
        if not spec or not spec.loader:
            return None

        module = importlib.util.module_from_spec(spec)
        # Don't pollute sys.modules permanently
        old_module = sys.modules.get(module_name)
        try:
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
        except Exception as e:
            log.warning("Error loading plugin %s: %s", path.name, e)
            return None
        finally:
            if old_module is not None:
                sys.modules[module_name] = old_module
            else:
                sys.modules.pop(module_name, None)

        hook = getattr(module, "policy_hook", None)
        if not callable(hook):
            log.debug("Skipping %s: no policy_hook function", path.name)
            return None

        description = getattr(module, "PLUGIN_DESCRIPTION", "")
        return PolicyPlugin(
            name=path.stem,
            path=path,
            hook=hook,
            description=str(description),
        )


# ---------------------------------------------------------------------------
# 3. Policy Packs (shareable policy bundles)
# ---------------------------------------------------------------------------


@dataclass
class PolicyPack:
    """
    A shareable policy configuration bundle.

    Packs are YAML files containing:
    - name: Pack identifier
    - version: Pack version (int)
    - description: Human-readable description
    - author: Pack author (optional)
    - policy: Policy config dict (same schema as gateway.policy)
    - rules: Expression rules (optional)
    """

    name: str
    version: int = 1
    description: str = ""
    author: str = ""
    policy: dict[str, Any] = field(default_factory=dict)
    rules: list[dict[str, Any]] = field(default_factory=list)
    source_path: Path | None = None

    @classmethod
    def from_file(cls, path: Path) -> PolicyPack:
        """Load a policy pack from a YAML file."""
        import yaml

        if not path.exists():
            raise FileNotFoundError(f"Policy pack not found: {path}")

        data = yaml.safe_load(path.read_text()) or {}
        return cls(
            name=str(data.get("name", path.stem)),
            version=int(data.get("version", 1)),
            description=str(data.get("description", "")),
            author=str(data.get("author", "")),
            policy=data.get("policy", {}),
            rules=data.get("rules", []),
            source_path=path,
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PolicyPack:
        """Load from a dict."""
        return cls(
            name=str(data.get("name", "unnamed")),
            version=int(data.get("version", 1)),
            description=str(data.get("description", "")),
            author=str(data.get("author", "")),
            policy=data.get("policy", {}),
            rules=data.get("rules", []),
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a dict for YAML export."""
        result: dict[str, Any] = {
            "name": self.name,
            "version": self.version,
        }
        if self.description:
            result["description"] = self.description
        if self.author:
            result["author"] = self.author
        if self.policy:
            result["policy"] = self.policy
        if self.rules:
            result["rules"] = self.rules
        return result

    def export(self, path: Path) -> None:
        """Export the pack to a YAML file."""
        import yaml

        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(yaml.dump(self.to_dict(), default_flow_style=False, sort_keys=False))

    def validate(self) -> list[str]:
        """Validate the pack and return errors."""
        from otto.policy import validate_policy_config

        errors: list[str] = []

        if not self.name:
            errors.append("Pack name is required")

        if self.policy:
            policy_errors = validate_policy_config(self.policy)
            errors.extend(f"Policy: {e}" for e in policy_errors)

        for i, rule in enumerate(self.rules):
            if not isinstance(rule, dict):
                errors.append(f"Rule {i}: expected dict")
                continue
            when = rule.get("when", "")
            if when:
                expr_errors = validate_expression(when)
                errors.extend(f"Rule {i} expression: {e}" for e in expr_errors)
            action = rule.get("action", "")
            if action and str(action).lower() not in {"allow", "deny", "ask"}:
                errors.append(f"Rule {i}: invalid action '{action}'")

        return errors


def list_packs(directory: Path | None = None) -> list[PolicyPack]:
    """List all policy packs in the packs directory."""
    packs_dir = directory or PACKS_DIR
    if not packs_dir.is_dir():
        return []
    packs = []
    for yaml_file in sorted(packs_dir.glob("*.yaml")) + sorted(packs_dir.glob("*.yml")):
        try:
            packs.append(PolicyPack.from_file(yaml_file))
        except Exception as e:
            log.warning("Failed to load pack %s: %s", yaml_file.name, e)
    return packs


def install_pack(pack_path: Path) -> tuple[bool, str]:
    """
    Install a policy pack into ~/.otto/policies/packs/.

    Returns (success, message).
    """
    try:
        pack = PolicyPack.from_file(pack_path)
    except Exception as e:
        return False, f"Failed to load pack: {e}"

    errors = pack.validate()
    if errors:
        return False, "Pack validation failed:\n" + "\n".join(f"  - {e}" for e in errors)

    ensure_policy_dirs()
    dest = PACKS_DIR / f"{pack.name}.yaml"
    pack.export(dest)
    return True, f"Installed pack '{pack.name}' to {dest}"


def export_current_policy(name: str = "exported", description: str = "") -> PolicyPack:
    """
    Export the current gateway policy as a shareable pack.

    Reads from settings.yaml and creates a PolicyPack.
    """
    from otto.config import get_setting

    policy_raw = get_setting("gateway.policy") or {}
    policy_dict = dict(policy_raw) if isinstance(policy_raw, dict) else {}

    # Extract expression rules if present (without mutating config cache)
    rules = policy_dict.get("rules", [])
    policy_without_rules = {k: v for k, v in policy_dict.items() if k != "rules"}

    pack = PolicyPack(
        name=name,
        description=description or "Exported from Otto gateway policy",
        policy=policy_without_rules,
        rules=rules if isinstance(rules, list) else [],
    )
    return pack


def merge_pack_into_config(pack: PolicyPack, config: dict[str, Any]) -> dict[str, Any]:
    """
    Merge a policy pack into an existing policy config.

    Pack values serve as defaults; existing config takes precedence.
    """
    from otto.config import _deep_merge

    merged = _deep_merge(pack.policy, config)

    # Merge expression rules: pack rules first, then existing
    existing_rules = config.get("rules", [])
    pack_rules = pack.rules or []
    if pack_rules or existing_rules:
        merged["rules"] = pack_rules + existing_rules

    return merged


# ---------------------------------------------------------------------------
# 4. Test Policy Harness
# ---------------------------------------------------------------------------


@dataclass
class MockToolRequest:
    """A mock tool request for testing policies."""

    server: str
    tool: str
    arguments: dict[str, Any] = field(default_factory=dict)
    backend: str = "test"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MockToolRequest:
        return cls(
            server=str(data.get("server", "")),
            tool=str(data.get("tool", "")),
            arguments=data.get("arguments", data.get("args", {})),
            backend=str(data.get("backend", "test")),
        )


@dataclass
class PolicyTestResult:
    """Result of testing a policy against a mock request."""

    request: MockToolRequest
    verdict: str  # "allow", "deny", "ask"
    reason: str
    source: str  # "expression", "plugin", "engine", "pack"
    arg_errors: list[str] = field(default_factory=list)
    expression_matched: str | None = None
    plugin_matched: str | None = None

    @property
    def passed(self) -> bool:
        """Whether the request would be allowed."""
        return self.verdict == "allow" and not self.arg_errors


def evaluate_mock_request(
    request: MockToolRequest,
    policy_config: dict[str, Any] | None = None,
    extra_rules: list[dict[str, Any]] | None = None,
    plugin_dir: Path | None = None,
) -> PolicyTestResult:
    """
    Test a mock request against the full policy pipeline.

    Evaluation order:
    1. Expression rules (first match wins)
    2. Plugin hooks (first match wins)
    3. Standard policy engine

    Args:
        request: Mock tool request to test
        policy_config: Policy config dict (defaults to current settings)
        extra_rules: Additional expression rules to test
        plugin_dir: Plugin directory (defaults to ~/.otto/policies/)

    Returns:
        PolicyTestResult with verdict and reasoning
    """
    from otto.policy import PolicyConfig, PolicyEngine

    if policy_config is None:
        from otto.config import get_setting

        policy_config = get_setting("gateway.policy") or {}

    # 1. Expression rules
    rules_config = list(policy_config.get("rules", []) or [])
    if extra_rules:
        rules_config.extend(extra_rules)

    expr_engine = ExpressionEngine.from_config(rules_config)
    expr_result = expr_engine.evaluate(request.server, request.tool, request.arguments)
    if expr_result:
        action, reason = expr_result
        return PolicyTestResult(
            request=request,
            verdict=action,
            reason=reason,
            source="expression",
            expression_matched=reason,
        )

    # 2. Plugin hooks
    loader = PluginLoader(plugin_dir)
    plugins = loader.load()
    for plugin in plugins:
        plugin_result = plugin.evaluate(request.server, request.tool, request.arguments)
        if plugin_result:
            action, reason = plugin_result
            return PolicyTestResult(
                request=request,
                verdict=action,
                reason=reason,
                source="plugin",
                plugin_matched=plugin.name,
            )

    # 3. Standard policy engine
    # Remove 'rules' key before passing to PolicyConfig (it doesn't understand it)
    engine_config = {k: v for k, v in policy_config.items() if k != "rules"}
    config = PolicyConfig.from_config(engine_config)
    engine = PolicyEngine(config)
    result = engine.evaluate(request.server, request.tool, request.arguments)

    return PolicyTestResult(
        request=request,
        verdict=result.verdict.value,
        reason=result.reason,
        source="engine",
        arg_errors=result.arg_errors,
    )


# Public alias (avoids pytest collection since it's not at module level with test_ prefix)
check_policy = evaluate_mock_request


def evaluate_mock_requests(
    requests: list[MockToolRequest],
    policy_config: dict[str, Any] | None = None,
    extra_rules: list[dict[str, Any]] | None = None,
    plugin_dir: Path | None = None,
) -> list[PolicyTestResult]:
    """Test multiple mock requests against the policy pipeline."""
    return [evaluate_mock_request(req, policy_config, extra_rules, plugin_dir) for req in requests]


# ---------------------------------------------------------------------------
# Integration: Extended PolicyEngine that includes expressions + plugins
# ---------------------------------------------------------------------------


class ExtendedPolicyEngine:
    """
    Full policy evaluation pipeline combining:
    1. Expression rules
    2. Plugin hooks
    3. Standard PolicyEngine cascade

    This is the recommended entry point for runtime policy evaluation
    when Phase 5 features are enabled.
    """

    def __init__(
        self,
        policy_config: dict[str, Any] | None = None,
        plugin_dir: Path | None = None,
    ):
        from otto.policy import PolicyConfig, PolicyEngine

        self._raw_config = policy_config or {}

        # Expression engine from 'rules' section
        self._expr_engine = ExpressionEngine.from_config(self._raw_config.get("rules"))

        # Plugin loader
        plugins_conf = self._raw_config.get("plugins", {})
        plugins_enabled = (
            bool(plugins_conf.get("enabled", True)) if isinstance(plugins_conf, dict) else True
        )
        if plugins_enabled:
            custom_dir = None
            if isinstance(plugins_conf, dict) and plugins_conf.get("directory"):
                custom_dir = Path(str(plugins_conf["directory"])).expanduser()
            self._plugin_loader = PluginLoader(plugin_dir or custom_dir)
        else:
            self._plugin_loader = None

        # Standard engine (strip 'rules' and 'plugins' and 'packs' keys)
        engine_config = {
            k: v for k, v in self._raw_config.items() if k not in {"rules", "plugins", "packs"}
        }
        self._policy_config = PolicyConfig.from_config(engine_config)
        self._engine = PolicyEngine(self._policy_config)

    @property
    def expression_engine(self) -> ExpressionEngine:
        return self._expr_engine

    @property
    def policy_engine(self):  # -> PolicyEngine
        return self._engine

    @property
    def plugins(self) -> list[PolicyPlugin]:
        if self._plugin_loader:
            return self._plugin_loader.load()
        return []

    def evaluate(
        self,
        server: str,
        tool: str,
        arguments: dict[str, Any] | None = None,
    ):
        """
        Full evaluation pipeline.

        Returns a PolicyResult (from otto.policy).
        Expression/plugin overrides are converted to PolicyResult.
        """
        from otto.policy import PolicyResult, ToolVerdict

        arguments = arguments or {}
        verdict_map = {
            "allow": ToolVerdict.ALLOW,
            "deny": ToolVerdict.DENY,
            "ask": ToolVerdict.ASK,
        }

        # 1. Expression rules (first match wins)
        expr_result = self._expr_engine.evaluate(server, tool, arguments)
        if expr_result:
            action, reason = expr_result
            return PolicyResult(
                verdict=verdict_map.get(action, ToolVerdict.DENY),
                reason=f"[expression] {reason}",
            )

        # 2. Plugin hooks (first match wins)
        if self._plugin_loader:
            for plugin in self._plugin_loader.load():
                plugin_result = plugin.evaluate(server, tool, arguments)
                if plugin_result:
                    action, reason = plugin_result
                    return PolicyResult(
                        verdict=verdict_map.get(action, ToolVerdict.DENY),
                        reason=f"[plugin:{plugin.name}] {reason}",
                    )

        # 3. Standard policy engine
        return self._engine.evaluate(server, tool, arguments)


# ---------------------------------------------------------------------------
# Convenience: load extended engine from settings
# ---------------------------------------------------------------------------


def load_extended_policy_engine(
    plugin_dir: Path | None = None,
) -> ExtendedPolicyEngine:
    """
    Load the extended policy engine from Otto's settings.yaml.

    This includes expression rules, plugins, and the standard policy engine.
    """
    from otto.config import get_setting

    policy_config = get_setting("gateway.policy") or {}
    return ExtendedPolicyEngine(policy_config, plugin_dir)


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------


def validate_rules_config(rules: list[dict[str, Any]]) -> list[str]:
    """Validate a list of expression rule configs."""
    errors: list[str] = []
    for i, rule in enumerate(rules):
        if not isinstance(rule, dict):
            errors.append(f"Rule {i}: expected dict, got {type(rule).__name__}")
            continue

        when = rule.get("when")
        if not when:
            errors.append(f"Rule {i}: 'when' expression is required")
        else:
            expr_errors = validate_expression(str(when))
            for e in expr_errors:
                errors.append(f"Rule {i}: {e}")

        action = rule.get("action", "")
        if not action:
            errors.append(f"Rule {i}: 'action' is required")
        elif str(action).lower() not in {"allow", "deny", "ask"}:
            errors.append(f"Rule {i}: invalid action '{action}'")

    return errors


def validate_extended_config(config: dict[str, Any]) -> list[str]:
    """Validate an extended policy config (with rules, plugins, packs)."""
    from otto.policy import validate_policy_config

    errors: list[str] = []

    # Validate standard policy config (strip extension keys)
    standard_config = {k: v for k, v in config.items() if k not in {"rules", "plugins", "packs"}}
    errors.extend(validate_policy_config(standard_config))

    # Validate expression rules
    rules = config.get("rules")
    if rules:
        if not isinstance(rules, list):
            errors.append("'rules' must be a list")
        else:
            errors.extend(validate_rules_config(rules))

    # Validate plugin config
    plugins = config.get("plugins")
    if plugins and isinstance(plugins, dict):
        plugin_dir = plugins.get("directory")
        if plugin_dir:
            p = Path(str(plugin_dir)).expanduser()
            if not p.is_dir():
                errors.append(f"Plugin directory does not exist: {p}")

    # Validate packs
    packs = config.get("packs")
    if packs:
        if not isinstance(packs, list):
            errors.append("'packs' must be a list")
        else:
            for i, pack_ref in enumerate(packs):
                if isinstance(pack_ref, dict):
                    pack_path = pack_ref.get("path")
                    if pack_path:
                        p = Path(str(pack_path)).expanduser()
                        if not p.exists():
                            errors.append(f"Pack {i}: file not found: {p}")
                elif isinstance(pack_ref, str):
                    p = Path(pack_ref).expanduser()
                    if not p.exists():
                        errors.append(f"Pack {i}: file not found: {p}")

    return errors


# ---------------------------------------------------------------------------
# Exports
# ---------------------------------------------------------------------------

__all__ = [
    # Paths
    "POLICIES_DIR",
    "PACKS_DIR",
    "ensure_policy_dirs",
    # Expressions
    "ExpressionError",
    "ExpressionRule",
    "ExpressionEngine",
    "evaluate_expression",
    "validate_expression",
    # Plugins
    "PolicyPlugin",
    "PluginLoader",
    # Packs
    "PolicyPack",
    "list_packs",
    "install_pack",
    "export_current_policy",
    "merge_pack_into_config",
    # Testing
    "MockToolRequest",
    "PolicyTestResult",
    "evaluate_mock_request",
    "check_policy",
    "evaluate_mock_requests",
    # Extended engine
    "ExtendedPolicyEngine",
    "load_extended_policy_engine",
    # Validation
    "validate_rules_config",
    "validate_extended_config",
]
