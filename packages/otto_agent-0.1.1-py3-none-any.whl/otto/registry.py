"""
MCP Registry Bridge — optional connection to modelcontextprotocol.io registry.

This module provides a bridge to the official MCP server registry at
registry.modelcontextprotocol.io, enabling:
- Searching for MCP servers by name or keyword
- Fetching server metadata and transport configs
- Trust scoring for unverified/new servers
- Auto-applying gateway policies when installing from registry

IMPORTANT: The registry is NEVER required. Otto works fully offline
with local catalog (otto/data/mcp_catalog.yaml) and manual config.
This is an optional discovery tool for power users.

Architecture (Pillar 3):
    The registry bridge is a read-only client. It:
    1. Searches the registry API (no auth required for reads)
    2. Converts registry entries to Otto's CatalogEntry format
    3. Assigns trust scores based on metadata signals
    4. Suggests gateway policies based on server capabilities
    5. Never auto-enables — always requires user confirmation

    Local catalog  ──┐
                      ├──>  Gateway Policy  ──>  Tool Access
    Registry bridge ──┘     (user confirms)
         (optional)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any

try:
    import aiohttp
except ImportError:
    aiohttp = None  # type: ignore[assignment]

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

REGISTRY_BASE_URL = "https://registry.modelcontextprotocol.io"
REGISTRY_API_VERSION = "v0.1"
DEFAULT_TIMEOUT = 10.0  # seconds
DEFAULT_SEARCH_LIMIT = 20

# Trust score thresholds
TRUST_HIGH = 80
TRUST_MEDIUM = 50
TRUST_LOW = 25


# ---------------------------------------------------------------------------
# Trust scoring
# ---------------------------------------------------------------------------


class TrustLevel(Enum):
    """Trust level for a registry server."""

    HIGH = "high"  # Well-known, verified, long-lived
    MEDIUM = "medium"  # Verified namespace, some history
    LOW = "low"  # New or unverified
    UNKNOWN = "unknown"  # Cannot determine


@dataclass(frozen=True)
class TrustScore:
    """
    Trust assessment for a registry server.

    The score (0-100) is computed from multiple signals:
    - Namespace verification (GitHub org, verified domain)
    - Age since first published
    - Repository source (GitHub, etc.)
    - Whether it appears in Otto's curated catalog
    - Package registry presence (npm, pypi)

    Attributes:
        score: Numeric trust score (0-100).
        level: Categorical trust level.
        reasons: Human-readable explanations for the score.
        in_catalog: Whether the server matches an Otto catalog entry.
        namespace_verified: Whether the namespace is verified.
    """

    score: int = 0
    level: TrustLevel = TrustLevel.UNKNOWN
    reasons: tuple[str, ...] = ()
    in_catalog: bool = False
    namespace_verified: bool = False

    @property
    def icon(self) -> str:
        return {
            TrustLevel.HIGH: "🟢",
            TrustLevel.MEDIUM: "🟡",
            TrustLevel.LOW: "🔴",
            TrustLevel.UNKNOWN: "⚪",
        }[self.level]


def compute_trust_score(
    server: RegistryServer,
    catalog_names: set[str] | None = None,
) -> TrustScore:
    """
    Compute a trust score for a registry server based on available signals.

    Scoring breakdown (max 100):
    - Namespace verified (GitHub namespace): +25
    - Repository on GitHub: +10
    - Has package on npm/pypi: +10
    - Published > 30 days ago: +15
    - Published > 90 days ago: +10 (additional)
    - Matches Otto curated catalog: +30

    Args:
        server: The registry server to score.
        catalog_names: Set of server names from Otto's curated catalog.

    Returns:
        TrustScore with computed score, level, and reasons.
    """
    score = 0
    reasons: list[str] = []
    namespace_verified = False
    in_catalog = False

    # Check namespace verification (io.github.* = GitHub-verified)
    if server.name.startswith("io.github."):
        score += 25
        namespace_verified = True
        reasons.append("GitHub-verified namespace (+25)")
    elif "." in server.name and not server.name.startswith("io.github."):
        # Domain-based namespace — some verification
        score += 15
        namespace_verified = True
        reasons.append("Domain-verified namespace (+15)")

    # Repository on GitHub
    if server.repository_url and "github.com" in server.repository_url:
        score += 10
        reasons.append("GitHub repository (+10)")

    # Has published packages
    if server.packages:
        has_npm = any(p.get("registryType") == "npm" for p in server.packages)
        has_pypi = any(p.get("registryType") == "pypi" for p in server.packages)
        if has_npm or has_pypi:
            score += 10
            registries = []
            if has_npm:
                registries.append("npm")
            if has_pypi:
                registries.append("pypi")
            reasons.append(f"Published on {', '.join(registries)} (+10)")

    # Age-based scoring
    if server.published_at:
        try:
            pub_date = datetime.fromisoformat(server.published_at.replace("Z", "+00:00"))
            age_days = (datetime.now(timezone.utc) - pub_date).days

            if age_days > 90:
                score += 25
                reasons.append(f"Published {age_days} days ago (+25)")
            elif age_days > 30:
                score += 15
                reasons.append(f"Published {age_days} days ago (+15)")
            else:
                reasons.append(f"Recently published ({age_days} days ago)")
        except (ValueError, TypeError):
            pass

    # Check if in Otto's curated catalog
    if catalog_names:
        # Match by short name (last segment) or full name
        short_name = server.name.rsplit("/", 1)[-1] if "/" in server.name else server.name
        # Also try removing common prefixes
        clean_name = short_name.replace("mcp-server-", "").replace("mcp-", "")
        if (
            server.name in catalog_names
            or short_name in catalog_names
            or clean_name in catalog_names
        ):
            score += 30
            in_catalog = True
            reasons.append("In Otto curated catalog (+30)")

    # Determine level
    score = min(score, 100)
    if score >= TRUST_HIGH:
        level = TrustLevel.HIGH
    elif score >= TRUST_MEDIUM:
        level = TrustLevel.MEDIUM
    elif score >= TRUST_LOW:
        level = TrustLevel.LOW
    else:
        level = TrustLevel.UNKNOWN

    return TrustScore(
        score=score,
        level=level,
        reasons=tuple(reasons),
        in_catalog=in_catalog,
        namespace_verified=namespace_verified,
    )


# ---------------------------------------------------------------------------
# Registry data types
# ---------------------------------------------------------------------------


@dataclass
class RegistryServer:
    """
    A server entry from the MCP registry.

    This is the normalized representation of a registry API response.
    Intentionally kept as a data container — the registry module
    converts these to Otto's CatalogEntry format for installation.
    """

    name: str
    description: str = ""
    version: str = ""
    repository_url: str = ""
    repository_source: str = ""
    website_url: str = ""
    packages: list[dict[str, Any]] = field(default_factory=list)
    published_at: str = ""
    updated_at: str = ""
    is_latest: bool = False
    title: str = ""
    # Computed after fetch
    trust: TrustScore | None = None

    @classmethod
    def from_api_response(cls, entry: dict[str, Any]) -> RegistryServer:
        """
        Parse a single server entry from the registry API response.

        Handles the nested structure:
        {
            "server": { name, description, packages, ... },
            "_meta": { "io.modelcontextprotocol.registry/official": { status, publishedAt, ... } }
        }
        """
        server_data = entry.get("server", {})
        meta = entry.get("_meta", {})
        official_meta = meta.get("io.modelcontextprotocol.registry/official", {})

        repo = server_data.get("repository", {})

        return cls(
            name=server_data.get("name", ""),
            description=server_data.get("description", ""),
            version=server_data.get("version", ""),
            repository_url=repo.get("url", ""),
            repository_source=repo.get("source", ""),
            website_url=server_data.get("websiteUrl", ""),
            packages=server_data.get("packages", []),
            published_at=official_meta.get("publishedAt", ""),
            updated_at=official_meta.get("updatedAt", ""),
            is_latest=official_meta.get("isLatest", False),
            title=server_data.get("title", ""),
        )

    @property
    def short_name(self) -> str:
        """Extract a short display name from the full registry name."""
        if "/" in self.name:
            return self.name.rsplit("/", 1)[-1]
        return self.name

    @property
    def display_name(self) -> str:
        """Human-readable name: title if available, else short_name."""
        return self.title or self.short_name

    @property
    def stdio_package(self) -> dict[str, Any] | None:
        """
        Find the first stdio-transport package.

        Otto prefers stdio transport for MCP servers. Returns the
        package dict or None if no stdio package is available.
        """
        for pkg in self.packages:
            transport = pkg.get("transport", {})
            if transport.get("type") == "stdio":
                return pkg
        return None

    def to_catalog_entry_dict(self) -> dict[str, Any]:
        """
        Convert to an Otto CatalogEntry-compatible dict.

        This produces a dict suitable for use as a catalog entry,
        including transport config derived from the registry package.
        """
        entry: dict[str, Any] = {
            "description": self.description,
            "category": "",  # Registry doesn't provide categories
            "transport": {},
            "default_allowed_tools": None,
            "default_blocked_tools": [],
            "requires_env": [],
            "install_hint": "",
            "homepage": self.website_url or self.repository_url,
            "risk_level": "medium",  # Default for unknown servers
        }

        # Try to build transport from the stdio package
        pkg = self.stdio_package
        if pkg:
            registry_type = pkg.get("registryType", "")
            identifier = pkg.get("identifier", "")
            version = pkg.get("version", "")

            if registry_type == "npm":
                pkg_spec = (
                    f"{identifier}@{version}" if version and version != "latest" else identifier
                )
                entry["transport"] = {
                    "type": "stdio",
                    "command": "npx",
                    "args": ["-y", pkg_spec],
                }
                entry["install_hint"] = "npx (included with Node.js)"
            elif registry_type == "pypi":
                entry["transport"] = {
                    "type": "stdio",
                    "command": "uvx",
                    "args": [identifier],
                }
                entry["install_hint"] = "uvx (included with uv)"

            # Extract environment variables
            env_vars = pkg.get("environmentVariables", [])
            required_env = [
                v["name"] for v in env_vars if isinstance(v, dict) and v.get("isRequired")
            ]
            entry["requires_env"] = required_env

            # Extract package arguments and append to transport args
            pkg_args = pkg.get("packageArguments", [])
            if pkg_args:
                arg_hints = []
                for arg in pkg_args:
                    if isinstance(arg, dict):
                        name = arg.get("name", "")
                        desc = arg.get("description", "")
                        default = arg.get("default", "")
                        required = arg.get("isRequired", False)
                        hint = f"--{name}"
                        if default:
                            hint += f" (default: {default})"
                        if required:
                            hint += " [required]"
                        if desc:
                            hint += f" — {desc}"
                        arg_hints.append(hint)
                if arg_hints:
                    entry["install_hint"] += "\nArguments: " + "; ".join(arg_hints)

        # Adjust risk level based on trust score
        if self.trust:
            if self.trust.level == TrustLevel.HIGH:
                entry["risk_level"] = "low"
            elif self.trust.level == TrustLevel.LOW:
                entry["risk_level"] = "high"

        return entry


# ---------------------------------------------------------------------------
# Policy suggestions
# ---------------------------------------------------------------------------


def suggest_policy_for_server(server: RegistryServer) -> dict[str, Any]:
    """
    Suggest gateway policy rules for a registry server based on trust score.

    Higher-trust servers get more permissive policies. Lower-trust servers
    get stricter defaults. Users can always override.

    Returns a dict suitable for inclusion in settings.yaml gateway.policy.servers.
    """
    trust = server.trust or TrustScore()
    policy: dict[str, Any] = {}

    if trust.level == TrustLevel.HIGH or trust.in_catalog:
        # Trusted server — allow most operations
        policy = {
            "verdict": "allow",
            "rate_limit": 60,
        }
    elif trust.level == TrustLevel.MEDIUM:
        # Moderate trust — allow with rate limits
        policy = {
            "verdict": "allow",
            "rate_limit": 30,
        }
    elif trust.level == TrustLevel.LOW:
        # Low trust — ask for everything
        policy = {
            "verdict": "ask",
            "rate_limit": 10,
        }
    else:
        # Unknown — deny by default, user must explicitly allow
        policy = {
            "verdict": "ask",
            "rate_limit": 5,
        }

    return policy


# ---------------------------------------------------------------------------
# Registry client
# ---------------------------------------------------------------------------


class RegistryClient:
    """
    HTTP client for the MCP server registry API.

    Read-only client — only performs GET requests. No authentication
    required for search/list operations.

    Usage::

        client = RegistryClient()
        results = await client.search("filesystem")
        for server in results:
            print(server.name, server.trust.icon)

        # Or check if registry is available
        if await client.is_available():
            ...
    """

    def __init__(
        self,
        base_url: str = REGISTRY_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._catalog_names: set[str] | None = None

    def _get_catalog_names(self) -> set[str]:
        """Lazy-load Otto's catalog server names for trust scoring."""
        if self._catalog_names is None:
            try:
                from otto.catalog import load_catalog

                catalog = load_catalog()
                self._catalog_names = set(catalog.keys())
            except Exception:
                self._catalog_names = set()
        return self._catalog_names

    async def is_available(self) -> bool:
        """
        Check if the registry API is reachable.

        Returns True if the health endpoint responds, False otherwise.
        Never raises.
        """
        try:
            if aiohttp is None:
                return False

            url = f"{self._base_url}/{REGISTRY_API_VERSION}/health"
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    return resp.status == 200
        except Exception:
            return False

    async def search(
        self,
        query: str,
        *,
        limit: int = DEFAULT_SEARCH_LIMIT,
        latest_only: bool = True,
    ) -> list[RegistryServer]:
        """
        Search the registry for MCP servers matching a query.

        Args:
            query: Search term (case-insensitive substring match on names).
            limit: Maximum results to return.
            latest_only: Only return latest versions.

        Returns:
            List of RegistryServer objects with trust scores computed.

        Raises:
            RegistryUnavailableError: If the registry cannot be reached.
        """
        params: dict[str, str] = {"search": query}
        if latest_only:
            params["version"] = "latest"

        entries = await self._fetch_servers(params)

        # Limit results
        entries = entries[:limit]

        # Compute trust scores
        catalog_names = self._get_catalog_names()
        for entry in entries:
            entry.trust = compute_trust_score(entry, catalog_names)

        return entries

    async def list_servers(
        self,
        *,
        limit: int = DEFAULT_SEARCH_LIMIT,
        latest_only: bool = True,
        updated_since: str | None = None,
    ) -> list[RegistryServer]:
        """
        List servers from the registry.

        Args:
            limit: Maximum results to return.
            latest_only: Only return latest versions.
            updated_since: RFC3339 timestamp to filter by.

        Returns:
            List of RegistryServer objects with trust scores.

        Raises:
            RegistryUnavailableError: If the registry cannot be reached.
        """
        params: dict[str, str] = {}
        if latest_only:
            params["version"] = "latest"
        if updated_since:
            params["updated_since"] = updated_since

        entries = await self._fetch_servers(params)
        entries = entries[:limit]

        catalog_names = self._get_catalog_names()
        for entry in entries:
            entry.trust = compute_trust_score(entry, catalog_names)

        return entries

    async def get_server(self, name: str) -> RegistryServer | None:
        """
        Fetch a specific server by name.

        Args:
            name: Full registry server name (e.g., "io.github.org/server").

        Returns:
            RegistryServer if found, None otherwise.
        """
        results = await self.search(name, limit=50, latest_only=True)
        for server in results:
            if server.name == name:
                return server
        return None

    async def _fetch_servers(self, params: dict[str, str]) -> list[RegistryServer]:
        """
        Fetch servers from the registry API.

        Handles HTTP errors and converts to RegistryServer objects.
        """
        if aiohttp is None:
            raise RegistryUnavailableError(
                "aiohttp is required for registry access. Install it with: pip install aiohttp"
            )

        url = f"{self._base_url}/{REGISTRY_API_VERSION}/servers"

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=self._timeout),
                ) as resp:
                    if resp.status != 200:
                        text = await resp.text()
                        raise RegistryUnavailableError(
                            f"Registry API returned {resp.status}: {text[:200]}"
                        )
                    data = await resp.json()
        except RegistryUnavailableError:
            raise
        except Exception as exc:
            raise RegistryUnavailableError(f"Failed to reach registry: {exc}") from exc

        servers: list[RegistryServer] = []
        for entry in data.get("servers", []):
            try:
                servers.append(RegistryServer.from_api_response(entry))
            except Exception:
                log.debug("Failed to parse registry entry", exc_info=True)
                continue

        return servers


# ---------------------------------------------------------------------------
# Install from registry
# ---------------------------------------------------------------------------


def install_from_registry(
    server: RegistryServer,
    *,
    server_name: str | None = None,
    enabled: bool = True,
    apply_policy: bool = True,
) -> tuple[bool, str]:
    """
    Install a registry server into Otto's settings.yaml.

    Converts the registry server to Otto's config format and adds it
    to gateway.servers. Optionally applies a suggested policy based
    on the server's trust score.

    Args:
        server: The registry server to install.
        server_name: Override the server name in config (default: short_name).
        enabled: Whether to enable the server immediately.
        apply_policy: Whether to auto-apply trust-based policy.

    Returns:
        (success, message) tuple.
    """
    from otto.config import get_setting, load_settings, save_settings

    name = server_name or server.short_name
    name = _sanitize_server_name(name)

    # Check if already configured
    existing = get_setting(f"gateway.servers.{name}")
    if existing:
        return False, f"'{name}' already configured in gateway.servers"

    # Build the catalog-like entry for the server config
    entry_dict = server.to_catalog_entry_dict()

    # Build settings config
    server_config: dict[str, Any] = {
        "enabled": enabled,
        "transport": entry_dict.get("transport", {}),
        # Record where this came from
        "from_registry": server.name,
    }

    if entry_dict.get("default_blocked_tools"):
        server_config["blocked_tools"] = entry_dict["default_blocked_tools"]

    # Save to settings
    settings = load_settings()
    if "gateway" not in settings:
        settings["gateway"] = {}
    if "servers" not in settings["gateway"]:
        settings["gateway"]["servers"] = {}

    settings["gateway"]["servers"][name] = server_config

    # Apply trust-based policy
    policy_msg = ""
    if apply_policy and server.trust:
        policy = suggest_policy_for_server(server)
        if policy:
            if "policy" not in settings["gateway"]:
                settings["gateway"]["policy"] = {}
            if "servers" not in settings["gateway"]["policy"]:
                settings["gateway"]["policy"]["servers"] = {}
            settings["gateway"]["policy"]["servers"][name] = policy
            policy_msg = (
                f" Policy applied: verdict={policy.get('verdict', 'allow')}, "
                f"rate_limit={policy.get('rate_limit', 0)}/min"
            )

    save_settings(settings)

    # Reload gateway so new server is immediately available for tool calls
    try:
        from otto.gateway import reload_gateway

        reload_gateway()
    except Exception as exc:
        log.warning("Gateway reload after install failed: %s", exc)

    # Build message
    trust_msg = ""
    if server.trust:
        trust_msg = (
            f" Trust: {server.trust.icon} {server.trust.level.value} ({server.trust.score}/100)"
        )

    env_vars = entry_dict.get("requires_env", [])
    env_msg = ""
    if env_vars:
        env_msg = f" Missing env vars: {', '.join(env_vars)}."

    status = "enabled" if enabled else "disabled"
    return True, (f"'{name}' installed from registry ({status}).{trust_msg}{policy_msg}{env_msg}")


def _sanitize_server_name(name: str) -> str:
    """
    Sanitize a server name for use as a YAML key.

    Removes problematic characters, keeps alphanumeric, hyphens, underscores.
    """
    import re

    # Replace slashes and dots with hyphens
    name = name.replace("/", "-").replace(".", "-")
    # Remove anything that's not alphanumeric, hyphen, or underscore
    name = re.sub(r"[^a-zA-Z0-9_-]", "", name)
    # Remove leading hyphens/underscores
    name = name.lstrip("-_")
    # Collapse multiple hyphens
    name = re.sub(r"-+", "-", name)
    return name or "unknown-server"


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class RegistryUnavailableError(Exception):
    """
    Raised when the MCP registry cannot be reached.

    This is a non-fatal error — Otto continues to work with local config.
    Callers should catch this and fall back gracefully.
    """

    pass


# ---------------------------------------------------------------------------
# Convenience: format search results for chat display
# ---------------------------------------------------------------------------


def format_search_results(
    servers: list[RegistryServer],
    *,
    max_display: int = 10,
) -> str:
    """
    Format registry search results for display in chat.

    Returns a human-readable string with server names, descriptions,
    trust scores, and install hints.
    """
    if not servers:
        return "No servers found in the registry."

    lines: list[str] = []
    lines.append(f"Found {len(servers)} server(s):\n")

    for i, server in enumerate(servers[:max_display]):
        trust_icon = server.trust.icon if server.trust else "⚪"
        trust_label = (
            f"{server.trust.level.value} ({server.trust.score})" if server.trust else "unknown"
        )

        lines.append(f"{i + 1}. {trust_icon} <b>{server.display_name}</b>")
        lines.append(f"   Name: <code>{server.name}</code>")
        if server.description:
            desc = server.description[:120]
            if len(server.description) > 120:
                desc += "…"
            lines.append(f"   {desc}")
        lines.append(f"   Trust: {trust_label} | v{server.version}")

        pkg = server.stdio_package
        if pkg:
            reg = pkg.get("registryType", "?")
            ident = pkg.get("identifier", "?")
            lines.append(f"   Package: {reg}:{ident}")

        lines.append("")

    if len(servers) > max_display:
        lines.append(f"... and {len(servers) - max_display} more")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Exports
# ---------------------------------------------------------------------------

__all__ = [
    # Types
    "TrustLevel",
    "TrustScore",
    "RegistryServer",
    # Core functions
    "compute_trust_score",
    "suggest_policy_for_server",
    "install_from_registry",
    "format_search_results",
    # Client
    "RegistryClient",
    # Errors
    "RegistryUnavailableError",
]
