"""
Safeguard configuration for permission controls.

Shared by Claude SDK backend and GenericBackend for consistent
protection against dangerous operations.

Philosophy: Autonomy by default, safeguards against catastrophic mistakes.
- Open permissions as default
- Sane safeguards that prevent system destruction (even in bypass mode)
- User-configurable protection levels
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

# Sensible defaults - prevent system destruction
DEFAULT_PROTECTED_PATHS = [
    # System directories
    "/etc",
    "/usr",
    "/bin",
    "/sbin",
    "/boot",
    "/sys",
    "/proc",
    "/dev",
    "/lib",
    "/lib64",
    "/var/log",
    "/var/run",
    # Sensitive home dotfiles
    "~/.ssh",
    "~/.gnupg",
    "~/.aws",
    "~/.config/gcloud",
    "~/.kube",
    "~/.docker",
    # Shell configs (accidental corruption = locked out)
    "~/.bashrc",
    "~/.zshrc",
    "~/.profile",
    "~/.bash_profile",
]

DEFAULT_BLOCKED_PATTERNS = [
    r"rm\s+(-[rf]+\s+)*(/\s*$|/\*|~\s*$|\$HOME\s*$)",  # rm -rf / (but not /home/user/...)
    r":\(\)\{\s*:\|:&\s*\};:",  # Fork bomb
    r"dd\s+.*of=/dev/sd",  # Disk wipe
    r"mkfs\.",  # Format filesystem
    r"chmod\s+(-R\s+)?777\s+/",  # Dangerous permissions
    r">\s*/dev/sd",  # Overwrite disk
]


@dataclass
class SafeguardConfig:
    """
    Configuration for permission safeguards.

    Philosophy: Autonomy by default, safeguards against catastrophic mistakes.
    - Open permissions as default (bypassPermissions)
    - Sane safeguards that prevent system destruction (even in bypass mode)
    - User-configurable protection levels
    """

    enabled: bool = True
    protected_paths: list[str] = field(default_factory=list)
    blocked_patterns: list[str] = field(default_factory=list)

    # Internal compiled state
    _compiled_patterns: list[re.Pattern] = field(default_factory=list, repr=False)
    _resolved_paths: list[Path] = field(default_factory=list, repr=False)

    def __post_init__(self):
        if not self.protected_paths:
            self.protected_paths = DEFAULT_PROTECTED_PATHS.copy()
        if not self.blocked_patterns:
            self.blocked_patterns = DEFAULT_BLOCKED_PATTERNS.copy()

        # Compile patterns
        self._compiled_patterns = [re.compile(p, re.IGNORECASE) for p in self.blocked_patterns]

        # Expand and resolve paths
        self._resolved_paths = []
        for p in self.protected_paths:
            try:
                self._resolved_paths.append(Path(p).expanduser().resolve())
            except (ValueError, OSError):
                pass

    def is_path_protected(self, file_path: str) -> bool:
        """Check if path is in a protected directory."""
        if not self.enabled:
            return False
        try:
            target = Path(file_path).expanduser().resolve()
            for protected in self._resolved_paths:
                if target == protected or protected in target.parents:
                    return True
        except (ValueError, OSError):
            pass
        return False

    def is_command_blocked(self, command: str) -> tuple[bool, str | None]:
        """
        Check if command matches blocked patterns.

        Returns:
            (blocked, pattern): blocked is True if command should be blocked,
                               pattern is the matching pattern string or None
        """
        if not self.enabled:
            return False, None
        for pattern in self._compiled_patterns:
            if pattern.search(command):
                return True, pattern.pattern
        return False, None

    @classmethod
    def from_config(cls, config: dict | None) -> SafeguardConfig:
        """
        Create SafeguardConfig from a configuration dict.

        Args:
            config: Dict with optional keys: enabled, protected_paths, blocked_patterns

        Returns:
            SafeguardConfig instance
        """
        if not config:
            return cls()

        return cls(
            enabled=config.get("enabled", True),
            protected_paths=config.get("protected_paths", []),
            blocked_patterns=config.get("blocked_patterns", []),
        )


__all__ = [
    "SafeguardConfig",
    "DEFAULT_PROTECTED_PATHS",
    "DEFAULT_BLOCKED_PATTERNS",
]
