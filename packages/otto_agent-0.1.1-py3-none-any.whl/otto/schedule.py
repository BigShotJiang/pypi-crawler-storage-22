"""
Scheduler tick for Otto.

Scheduling model:
- Job definitions live in ~/.otto/brainfile.md (config source of truth)
- Durable schedule metadata lives in ~/.otto/schedules/<job_id>.json
- Runnable work is enqueued to SQLite (see `otto.jobs.queue`)

Run:
  otto job schedule tick
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

import yaml

from otto import schedule_store
from otto.jobs.queue import JobQueue
from otto.notify import send as send_notification
from otto.paths import BRAINFILE, OUTPUTS_DIR, SCHEDULES_DIR, build_agent_system_prompt, ensure_dirs
from otto.schedule_state import load as load_state
from otto.schedule_state import mark_enqueued
from otto.schedule_state import save as save_state

_SUPERVISOR_JOB_ID = "__service_supervisor__"

_NOTIFY_MODES = {"always", "on_error", "on_action", "never"}


def _normalize_notify_mode(value: object) -> str:
    """Normalize job notify config to a supported mode."""
    if value is None:
        return "on_error"
    if isinstance(value, bool):
        return "always" if value else "never"
    mode = str(value).strip().lower()
    if mode in ("true", "yes", "1"):
        return "always"
    if mode in ("false", "no", "0"):
        return "never"
    return mode if mode in _NOTIFY_MODES else "on_error"


def _supervisor_config() -> dict:
    from otto import config as otto_config

    return {
        "enabled": bool(otto_config.get_setting("supervisor.enabled", True)),
        "alert_after_failures": int(
            otto_config.get_setting("supervisor.alert_after_failures", 3) or 3
        ),
        "check_mcp": bool(otto_config.get_setting("supervisor.check_mcp", True)),
    }


def _get_supervisor_state() -> dict:
    state = load_state(_SUPERVISOR_JOB_ID)
    if not isinstance(state.get("services"), dict):
        state["services"] = {}
    return state


def _update_service_state(
    state: dict, *, key: str, healthy: bool, threshold: int, details: str
) -> None:
    services = state.setdefault("services", {})
    svc = services.setdefault(key, {"consecutive_failures": 0, "alerted": False})
    if not isinstance(svc, dict):
        svc = {"consecutive_failures": 0, "alerted": False}
        services[key] = svc

    if healthy:
        svc["consecutive_failures"] = 0
        svc["alerted"] = False
        svc["last_ok"] = datetime.now().isoformat()
        svc.pop("last_error", None)
        return

    svc["consecutive_failures"] = int(svc.get("consecutive_failures", 0) or 0) + 1
    svc["last_error"] = details[:500] if details else "unhealthy"
    svc["last_failed_at"] = datetime.now().isoformat()

    if threshold <= 0:
        return
    if svc.get("alerted"):
        return
    if int(svc["consecutive_failures"]) < threshold:
        return

    svc["alerted"] = True
    try:
        send_notification(
            "\n".join(
                [
                    "<b>Supervisor</b>: service unhealthy",
                    f"- <code>{key}</code>",
                    f"- failures: {svc['consecutive_failures']}",
                    f"- last_error: {svc.get('last_error', '')}",
                ]
            )
        )
    except Exception:
        # Best-effort: never break scheduling.
        pass


def supervise(*, dry_run: bool = False) -> dict:
    """Check critical service health and self-heal when possible."""
    from otto.daemon import ServiceStatus, check_mcp_health, default_service_commands, start, status

    cfg = _supervisor_config()
    if not cfg["enabled"]:
        return {"enabled": False}

    threshold = int(cfg["alert_after_failures"])
    alert_threshold = 0 if dry_run else threshold
    state = _get_supervisor_state()
    state["last_checked_at"] = datetime.now().isoformat()

    results: dict[str, dict] = {}

    for service, cmd in default_service_commands().items():
        info = status(service)
        action = None
        healthy = info.status == ServiceStatus.RUNNING

        if not healthy and not dry_run:
            ok, msg = start(service, cmd)
            action = msg
            info = status(service)
            healthy = info.status == ServiceStatus.RUNNING
            if not healthy and ok:
                # Start said ok but status disagrees; treat as unhealthy.
                pass

        details = action or info.status.value
        results[service] = {
            "status": info.status.value,
            "pid": info.pid,
            "healthy": healthy,
            "action": action,
        }
        _update_service_state(
            state,
            key=service,
            healthy=healthy,
            threshold=alert_threshold,
            details=details,
        )

    if cfg["check_mcp"]:
        mcp_ok, mcp_msg = (True, "dry-run") if dry_run else check_mcp_health()
        results["mcp"] = {"healthy": bool(mcp_ok), "details": mcp_msg}
        _update_service_state(
            state,
            key="mcp",
            healthy=bool(mcp_ok),
            threshold=alert_threshold,
            details=mcp_msg,
        )

    if not dry_run:
        save_state(_SUPERVISOR_JOB_ID, state)

    return {"enabled": True, "results": results}


def _acquire_lock(lock_path: Path):
    """Cross-process lock to keep `tick` single-instance."""
    import fcntl

    lock_path.parent.mkdir(parents=True, exist_ok=True)
    fd = open(lock_path, "w")
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        fd.close()
        return None
    return fd


def _parse_brainfile_jobs() -> list[dict]:
    if not BRAINFILE.exists():
        return []

    content = BRAINFILE.read_text()
    if not content.startswith("---"):
        return []

    end = content.find("\n---", 3)
    if end == -1:
        return []

    data = yaml.safe_load(content[4:end]) or {}
    jobs = data.get("jobs", [])
    return jobs if isinstance(jobs, list) else []


_DAILY_SUMMARY_ID = "__observability_daily__"
_WEEKLY_SUMMARY_ID = "__observability_weekly__"


def _check_observability_summaries(now: datetime, *, dry_run: bool = False) -> dict:
    """
    Check and send daily/weekly MCP activity summaries.

    Uses schedule_state to track when last summary was sent.
    Configurable in settings.yaml:
        gateway:
          observability:
            daily_summary: true
            daily_summary_hour: 9
            weekly_summary: true
            weekly_summary_day: 1  # Monday
            weekly_summary_hour: 9
    """
    results: dict = {"daily": None, "weekly": None}

    try:
        from otto.config import get_setting

        obs_config = get_setting("gateway.observability") or {}

        # Daily summary
        if obs_config.get("daily_summary", False):
            target_hour = int(obs_config.get("daily_summary_hour", 9))
            state = load_state(_DAILY_SUMMARY_ID)
            last_sent = state.get("last_sent_date")
            today = now.strftime("%Y-%m-%d")

            if last_sent != today and now.hour >= target_hour:
                if dry_run:
                    results["daily"] = {"would_send": True, "date": today}
                else:
                    try:
                        from otto.observability import generate_daily_summary

                        text = generate_daily_summary()
                        send_notification(text)
                        state["last_sent_date"] = today
                        state["last_sent_at"] = now.isoformat()
                        save_state(_DAILY_SUMMARY_ID, state)
                        results["daily"] = {"sent": True, "date": today}
                    except Exception as e:
                        results["daily"] = {"error": str(e)[:200]}

        # Weekly summary
        if obs_config.get("weekly_summary", False):
            target_day = int(obs_config.get("weekly_summary_day", 1))  # 0=Mon in ISO
            target_hour = int(obs_config.get("weekly_summary_hour", 9))
            state = load_state(_WEEKLY_SUMMARY_ID)
            last_sent_week = state.get("last_sent_week")
            current_week = now.strftime("%Y-W%W")

            # Check if it's the right day (isoweekday: 1=Mon, 7=Sun)
            if (
                last_sent_week != current_week
                and now.isoweekday() == target_day
                and now.hour >= target_hour
            ):
                if dry_run:
                    results["weekly"] = {"would_send": True, "week": current_week}
                else:
                    try:
                        from otto.observability import generate_weekly_summary

                        text = generate_weekly_summary()
                        send_notification(text)
                        state["last_sent_week"] = current_week
                        state["last_sent_at"] = now.isoformat()
                        save_state(_WEEKLY_SUMMARY_ID, state)
                        results["weekly"] = {"sent": True, "week": current_week}
                    except Exception as e:
                        results["weekly"] = {"error": str(e)[:200]}

    except Exception as e:
        results["error"] = str(e)[:200]

    return results


def tick(*, dry_run: bool = False) -> dict:
    """
    Evaluate schedules and enqueue due jobs.

    Returns stats dict for logging/testing.
    """
    ensure_dirs()

    lock_fd = _acquire_lock(SCHEDULES_DIR / ".tick.lock")
    if lock_fd is None:
        return {"skipped": True, "reason": "locked"}

    try:
        jobs = _parse_brainfile_jobs()
        now = datetime.now().replace(second=0, microsecond=0)

        try:
            from croniter import croniter
        except ImportError as e:  # pragma: no cover
            raise RuntimeError("Missing dependency: croniter (add it to your environment)") from e

        queue = JobQueue()
        enqueued: list[dict] = []

        # Get default timeout from config
        from otto.backends import get_orchestration_config

        orch_config = get_orchestration_config()
        default_timeout = orch_config.get("default_timeout", 3600)

        for job in jobs:
            if not isinstance(job, dict):
                continue

            if not job.get("enabled", True):
                continue

            job_id = job.get("id")
            schedule = job.get("schedule")
            prompt = job.get("prompt")

            if not job_id or not schedule or not prompt:
                continue

            try:
                state = load_state(job_id)
                if state.get("disabled"):
                    continue

                # Start from last enqueued minute if present; else only consider "now".
                last_enq_str = state.get("last_enqueued_for")
                base = now - timedelta(minutes=1)
                if isinstance(last_enq_str, str):
                    try:
                        base = datetime.fromisoformat(last_enq_str).replace(second=0, microsecond=0)
                    except ValueError:
                        base = now - timedelta(minutes=1)

                it = croniter(schedule, base)

                # Catch up bounded to avoid surprise floods (configurable per job).
                catch_up_limit = int(job.get("catch_up_limit", 5))
                emitted = 0

                while True:
                    next_run = it.get_next(datetime).replace(second=0, microsecond=0)
                    if next_run > now:
                        break
                    emitted += 1
                    if emitted > catch_up_limit:
                        break

                    payload = {
                        "job_id": job_id,
                        "prompt": prompt,
                        "notify": _normalize_notify_mode(job.get("notify", "on_error")),
                        "one_shot": bool(job.get("one_shot", False)),
                        "backend": job.get("backend"),
                        "timeout": int(job.get("timeout", default_timeout)),
                        "scheduled_for": next_run.isoformat(),
                    }

                    if dry_run:
                        enqueued.append(
                            {
                                "job_id": job_id,
                                "scheduled_for": next_run.isoformat(),
                                "dry_run": True,
                            }
                        )
                        continue

                    external_id = f"scheduled:{job_id}:{payload['scheduled_for']}"
                    try:
                        queue.add(
                            "scheduled",
                            payload,
                            priority=int(job.get("priority", 0)),
                            external_id=external_id,
                        )
                    except sqlite3.IntegrityError:
                        # Already enqueued (dedupe on (job_id, scheduled_for)).
                        enqueued.append(
                            {
                                "job_id": job_id,
                                "scheduled_for": next_run.isoformat(),
                                "deduped": True,
                            }
                        )
                        mark_enqueued(job_id, next_run)
                        continue
                    mark_enqueued(job_id, next_run)
                    enqueued.append({"job_id": job_id, "scheduled_for": next_run.isoformat()})
            except Exception as e:
                # Per-job fault isolation: a broken job must not break the scheduler.
                err = str(e)[:500]
                enqueued.append({"job_id": job_id, "error": err})
                if not dry_run:
                    try:
                        state = load_state(job_id)
                        state["last_error"] = err
                        state["last_failed_at"] = datetime.now().isoformat()
                        save_state(job_id, state)
                    except Exception:
                        pass
                continue

        # --- Dynamic schedules: enqueue as agent jobs for reliable notification ---
        try:
            system_prompt = build_agent_system_prompt()
        except Exception:
            system_prompt = "You are Otto, a helpful assistant running a scheduled task."

        try:
            OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

        def _build_dynamic_agent_payload(sched: dict, scheduled_for: str) -> dict:
            sid = sched["id"]
            task_name = (sched.get("name") or "")[:120] or "Scheduled task"
            output_file = OUTPUTS_DIR / f"{sid}.txt"
            return {
                "agent_id": sid,
                "prompt": sched["prompt"],
                "system": system_prompt,
                "task": task_name,
                "backend": sched.get("backend"),
                "model": sched.get("model"),
                "timeout": default_timeout,
                "notify": sched.get("notify", "always"),
                "priority": "normal",
                "output_file": str(output_file),
            }

        # --- Dynamic one-shot schedules ---
        try:
            due_oneshots = schedule_store.get_enabled_oneshot(now)
        except Exception:
            due_oneshots = []

        for sched in due_oneshots:
            try:
                sid = sched["id"]
                if dry_run:
                    enqueued.append(
                        {
                            "job_id": sid,
                            "scheduled_for": sched.get("run_at"),
                            "dry_run": True,
                            "source": "dynamic",
                        }
                    )
                    continue

                payload = _build_dynamic_agent_payload(sched, sched.get("run_at", ""))
                try:
                    queue.add("agent", payload, external_id=sid)
                except sqlite3.IntegrityError:
                    enqueued.append(
                        {
                            "job_id": sid,
                            "scheduled_for": sched.get("run_at"),
                            "deduped": True,
                            "source": "dynamic",
                        }
                    )
                    mark_enqueued(sid, now)
                    schedule_store.disable_schedule(sid)
                    continue

                mark_enqueued(sid, now)
                schedule_store.disable_schedule(sid)
                enqueued.append(
                    {"job_id": sid, "scheduled_for": sched.get("run_at"), "source": "dynamic"}
                )
            except Exception as e:
                err = str(e)[:500]
                enqueued.append({"job_id": sched.get("id", "?"), "error": err, "source": "dynamic"})

        # --- Dynamic recurring schedules ---
        try:
            recurring = schedule_store.get_enabled_recurring()
        except Exception:
            recurring = []

        for sched in recurring:
            try:
                sid = sched["id"]
                cron_expr = sched.get("cron_expr")
                if not cron_expr:
                    continue

                state = load_state(sid)
                if state.get("disabled"):
                    continue

                last_enq_str = state.get("last_enqueued_for")
                base = now - timedelta(minutes=1)
                if isinstance(last_enq_str, str):
                    try:
                        base = datetime.fromisoformat(last_enq_str).replace(second=0, microsecond=0)
                    except ValueError:
                        base = now - timedelta(minutes=1)

                it = croniter(cron_expr, base)
                catch_up_limit = 5
                emitted = 0

                while True:
                    next_run = it.get_next(datetime).replace(second=0, microsecond=0)
                    if next_run > now:
                        break
                    emitted += 1
                    if emitted > catch_up_limit:
                        break

                    if dry_run:
                        enqueued.append(
                            {
                                "job_id": sid,
                                "scheduled_for": next_run.isoformat(),
                                "dry_run": True,
                                "source": "dynamic",
                            }
                        )
                        continue

                    payload = _build_dynamic_agent_payload(sched, next_run.isoformat())
                    # Unique external_id per recurring instance to allow dedup
                    ext_id = f"{sid}:{next_run.isoformat()}"
                    try:
                        queue.add("agent", payload, external_id=ext_id)
                    except sqlite3.IntegrityError:
                        enqueued.append(
                            {
                                "job_id": sid,
                                "scheduled_for": next_run.isoformat(),
                                "deduped": True,
                                "source": "dynamic",
                            }
                        )
                        mark_enqueued(sid, next_run)
                        continue

                    mark_enqueued(sid, next_run)
                    enqueued.append(
                        {"job_id": sid, "scheduled_for": next_run.isoformat(), "source": "dynamic"}
                    )
            except Exception as e:
                err = str(e)[:500]
                enqueued.append({"job_id": sched.get("id", "?"), "error": err, "source": "dynamic"})

        # --- Built-in observability summaries ---
        summary_results = _check_observability_summaries(now, dry_run=dry_run)

        supervisor = supervise(dry_run=dry_run)
        return {
            "skipped": False,
            "enqueued": enqueued,
            "now": now.isoformat(),
            "supervisor": supervisor,
            "observability": summary_results,
        }
    finally:
        try:
            import fcntl

            fcntl.flock(lock_fd, fcntl.LOCK_UN)
        finally:
            lock_fd.close()


if __name__ == "__main__":
    print(json.dumps(tick(dry_run=True), indent=2))
