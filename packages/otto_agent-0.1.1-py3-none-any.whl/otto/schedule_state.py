"""Durable schedule metadata stored as JSON per job under ~/.otto/schedules/."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from otto.paths import SCHEDULES_DIR


def _state_path(job_id: str) -> Path:
    return SCHEDULES_DIR / f"{job_id}.json"


def load(job_id: str) -> dict[str, Any]:
    path = _state_path(job_id)
    if not path.exists():
        return {
            "job_id": job_id,
            "disabled": False,
            "run_count": 0,
        }
    try:
        return json.loads(path.read_text())
    except json.JSONDecodeError:
        # Corrupt state shouldn't break the system; start fresh but keep a hint.
        return {
            "job_id": job_id,
            "disabled": False,
            "run_count": 0,
            "last_error": "schedule state JSON was unreadable; state was reset",
        }


def save(job_id: str, state: dict[str, Any]) -> None:
    SCHEDULES_DIR.mkdir(parents=True, exist_ok=True)
    path = _state_path(job_id)

    state = dict(state)
    state["job_id"] = job_id
    state["updated_at"] = datetime.now().isoformat()

    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(state, indent=2, sort_keys=True))
    tmp.replace(path)


def mark_enqueued(job_id: str, scheduled_for: datetime) -> None:
    state = load(job_id)
    state["last_enqueued_for"] = scheduled_for.replace(second=0, microsecond=0).isoformat()
    save(job_id, state)


def mark_run(job_id: str, *, status: str, error: str | None = None, one_shot: bool = False) -> None:
    state = load(job_id)
    state["last_run_at"] = datetime.now().isoformat()
    state["last_status"] = status
    if error:
        state["last_error"] = error
    state["run_count"] = int(state.get("run_count", 0) or 0) + 1
    if one_shot and status == "completed":
        state["disabled"] = True
    save(job_id, state)
