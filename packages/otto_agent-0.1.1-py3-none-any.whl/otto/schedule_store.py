"""Dynamic schedule CRUD stored in SQLite (same DB as JobQueue).

Provides persistence for agent-created schedules (one-shot and recurring).
Static brainfile jobs remain separate — this module only handles dynamic schedules
created via MCP tools at runtime.
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

from otto.jobs.queue import DEFAULT_DB


def _connect(db_path: Path | None = None) -> sqlite3.Connection:
    path = db_path or DEFAULT_DB
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA busy_timeout=30000;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    return conn


def _init_db(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS dynamic_schedules (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            prompt TEXT NOT NULL,
            schedule_type TEXT NOT NULL DEFAULT 'once',
            cron_expr TEXT,
            run_at TEXT,
            backend TEXT DEFAULT 'claude',
            model TEXT,
            notify TEXT DEFAULT 'always',
            enabled INTEGER DEFAULT 1,
            chat_id TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            metadata TEXT DEFAULT '{}'
        )
        """
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_ds_enabled ON dynamic_schedules(enabled)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_ds_type ON dynamic_schedules(schedule_type)")
    conn.commit()


def _row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    d = dict(row)
    d["enabled"] = bool(d.get("enabled"))
    if d.get("metadata"):
        try:
            d["metadata"] = json.loads(d["metadata"])
        except (json.JSONDecodeError, TypeError):
            d["metadata"] = {}
    return d


def create_schedule(
    id: str,
    name: str,
    prompt: str,
    schedule_type: str = "once",
    cron_expr: str | None = None,
    run_at: str | None = None,
    backend: str = "claude",
    model: str | None = None,
    notify: str = "always",
    chat_id: str | None = None,
    metadata: dict | None = None,
    *,
    db_path: Path | None = None,
) -> dict[str, Any]:
    now = datetime.now().isoformat()
    meta_json = json.dumps(metadata or {})
    conn = _connect(db_path)
    try:
        _init_db(conn)
        conn.execute(
            """
            INSERT INTO dynamic_schedules
                (id, name, prompt, schedule_type, cron_expr, run_at,
                 backend, model, notify, enabled, chat_id,
                 created_at, updated_at, metadata)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?)
            """,
            (
                id,
                name,
                prompt,
                schedule_type,
                cron_expr,
                run_at,
                backend,
                model,
                notify,
                chat_id,
                now,
                now,
                meta_json,
            ),
        )
        conn.commit()
        row = conn.execute("SELECT * FROM dynamic_schedules WHERE id = ?", (id,)).fetchone()
        return _row_to_dict(row)
    finally:
        conn.close()


def list_schedules(
    include_disabled: bool = False,
    *,
    db_path: Path | None = None,
) -> list[dict[str, Any]]:
    conn = _connect(db_path)
    try:
        _init_db(conn)
        if include_disabled:
            rows = conn.execute(
                "SELECT * FROM dynamic_schedules ORDER BY created_at DESC"
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM dynamic_schedules WHERE enabled = 1 ORDER BY created_at DESC"
            ).fetchall()
        return [_row_to_dict(r) for r in rows]
    finally:
        conn.close()


def get_schedule(
    schedule_id: str,
    *,
    db_path: Path | None = None,
) -> dict[str, Any] | None:
    conn = _connect(db_path)
    try:
        _init_db(conn)
        row = conn.execute(
            "SELECT * FROM dynamic_schedules WHERE id = ?", (schedule_id,)
        ).fetchone()
        return _row_to_dict(row) if row else None
    finally:
        conn.close()


def disable_schedule(
    schedule_id: str,
    *,
    db_path: Path | None = None,
) -> bool:
    conn = _connect(db_path)
    try:
        _init_db(conn)
        cur = conn.execute(
            "UPDATE dynamic_schedules SET enabled = 0, updated_at = ? WHERE id = ?",
            (datetime.now().isoformat(), schedule_id),
        )
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


def delete_schedule(
    schedule_id: str,
    *,
    db_path: Path | None = None,
) -> bool:
    conn = _connect(db_path)
    try:
        _init_db(conn)
        cur = conn.execute("DELETE FROM dynamic_schedules WHERE id = ?", (schedule_id,))
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


def get_enabled_oneshot(
    now: datetime,
    *,
    db_path: Path | None = None,
) -> list[dict[str, Any]]:
    conn = _connect(db_path)
    try:
        _init_db(conn)
        rows = conn.execute(
            """
            SELECT * FROM dynamic_schedules
            WHERE enabled = 1
              AND schedule_type = 'once'
              AND run_at IS NOT NULL
              AND run_at <= ?
            ORDER BY run_at ASC
            """,
            (now.isoformat(),),
        ).fetchall()
        return [_row_to_dict(r) for r in rows]
    finally:
        conn.close()


def get_enabled_recurring(
    *,
    db_path: Path | None = None,
) -> list[dict[str, Any]]:
    conn = _connect(db_path)
    try:
        _init_db(conn)
        rows = conn.execute(
            """
            SELECT * FROM dynamic_schedules
            WHERE enabled = 1
              AND schedule_type = 'recurring'
              AND cron_expr IS NOT NULL
            ORDER BY created_at ASC
            """
        ).fetchall()
        return [_row_to_dict(r) for r in rows]
    finally:
        conn.close()
