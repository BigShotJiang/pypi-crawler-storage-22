"""Long-running services (Telegram bot, worker, scheduler integration)."""
