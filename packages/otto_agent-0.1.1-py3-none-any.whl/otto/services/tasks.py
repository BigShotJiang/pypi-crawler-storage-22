"""
Otto Task Manager - Bidirectional task tracking via Telegram checklists.

Both user and Otto can create, update, and complete tasks. Tasks appear as
interactive checklists in Telegram that can be toggled by either party.

Storage: SQLite for persistence, with message_id tracking for live updates.
"""

from __future__ import annotations

import sqlite3
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path

from otto.paths import OTTO_HOME

DB_PATH = OTTO_HOME / "data" / "tasks.sqlite"


class TaskStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


# Emoji name to unicode mapping for reactions
REACTION_EMOJIS = {
    "thumbsup": "👍",
    "thumbsdown": "👎",
    "party": "🎉",
    "heart": "❤️",
    "thinking": "🤔",
}


@dataclass
class Task:
    """A single task item."""

    id: str
    content: str
    status: TaskStatus = TaskStatus.PENDING
    created_at: str = ""
    updated_at: str = ""
    completed_at: str | None = None
    created_by: str = "user"  # "user" or "otto"
    checklist_id: str | None = None  # Parent checklist
    order: int = 0

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat()
        if not self.updated_at:
            self.updated_at = self.created_at


@dataclass
class Checklist:
    """A group of tasks displayed as a single Telegram message."""

    id: str
    title: str
    chat_id: int
    message_id: int | None = None  # Telegram message ID for live updates
    created_at: str = ""
    updated_at: str = ""
    created_by: str = "otto"
    tasks: list[Task] = field(default_factory=list)

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat()
        if not self.updated_at:
            self.updated_at = self.created_at


class TaskManager:
    """Manages tasks and checklists with SQLite persistence."""

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self._ensure_db()

    def _ensure_db(self):
        """Create database and tables if they don't exist."""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        with sqlite3.connect(self.db_path) as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS checklists (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    chat_id INTEGER NOT NULL,
                    message_id INTEGER,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    created_by TEXT NOT NULL DEFAULT 'otto'
                );

                CREATE TABLE IF NOT EXISTS tasks (
                    id TEXT PRIMARY KEY,
                    content TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    completed_at TEXT,
                    created_by TEXT NOT NULL DEFAULT 'user',
                    checklist_id TEXT,
                    task_order INTEGER DEFAULT 0,
                    FOREIGN KEY (checklist_id) REFERENCES checklists(id)
                );

                CREATE INDEX IF NOT EXISTS idx_tasks_checklist
                    ON tasks(checklist_id);
                CREATE INDEX IF NOT EXISTS idx_tasks_status
                    ON tasks(status);
                CREATE INDEX IF NOT EXISTS idx_checklists_chat
                    ON checklists(chat_id);

                -- Reactions table for tasks/checklists
                CREATE TABLE IF NOT EXISTS reactions (
                    id TEXT PRIMARY KEY,
                    target_type TEXT NOT NULL,  -- 'task' or 'checklist'
                    target_id TEXT NOT NULL,
                    emoji TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(target_type, target_id, emoji, user_id)
                );

                CREATE INDEX IF NOT EXISTS idx_reactions_target
                    ON reactions(target_type, target_id);

                -- Multi-choice poll table
                CREATE TABLE IF NOT EXISTS polls (
                    id TEXT PRIMARY KEY,
                    chat_id INTEGER NOT NULL,
                    message_id INTEGER,
                    question TEXT NOT NULL,
                    options TEXT NOT NULL,  -- JSON array
                    multi_select INTEGER DEFAULT 1,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    created_by TEXT NOT NULL DEFAULT 'otto',
                    closed INTEGER DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS poll_votes (
                    id TEXT PRIMARY KEY,
                    poll_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    option_key TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (poll_id) REFERENCES polls(id),
                    UNIQUE(poll_id, user_id, option_key)
                );

                CREATE INDEX IF NOT EXISTS idx_poll_votes
                    ON poll_votes(poll_id);
            """)

    # ─────────────────────────────────────────────────────────────
    # Checklist Operations
    # ─────────────────────────────────────────────────────────────

    def create_checklist(
        self,
        title: str,
        chat_id: int,
        tasks: list[str],
        created_by: str = "otto",
    ) -> Checklist:
        """Create a new checklist with initial tasks."""
        checklist_id = uuid.uuid4().hex[:12]
        now = datetime.now().isoformat()

        checklist = Checklist(
            id=checklist_id,
            title=title,
            chat_id=chat_id,
            created_at=now,
            updated_at=now,
            created_by=created_by,
        )

        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT INTO checklists
                   (id, title, chat_id, message_id, created_at, updated_at, created_by)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    checklist.id,
                    checklist.title,
                    checklist.chat_id,
                    checklist.message_id,
                    checklist.created_at,
                    checklist.updated_at,
                    checklist.created_by,
                ),
            )

            # Add tasks
            for i, content in enumerate(tasks):
                task = Task(
                    id=uuid.uuid4().hex[:12],
                    content=content,
                    checklist_id=checklist_id,
                    order=i,
                    created_by=created_by,
                )
                conn.execute(
                    """INSERT INTO tasks
                       (id, content, status, created_at, updated_at,
                        completed_at, created_by, checklist_id, task_order)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        task.id,
                        task.content,
                        task.status.value,
                        task.created_at,
                        task.updated_at,
                        task.completed_at,
                        task.created_by,
                        task.checklist_id,
                        task.order,
                    ),
                )
                checklist.tasks.append(task)

        return checklist

    def get_checklist(self, checklist_id: str) -> Checklist | None:
        """Get a checklist by ID with all its tasks."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row

            row = conn.execute("SELECT * FROM checklists WHERE id = ?", (checklist_id,)).fetchone()

            if not row:
                return None

            checklist = Checklist(
                id=row["id"],
                title=row["title"],
                chat_id=row["chat_id"],
                message_id=row["message_id"],
                created_at=row["created_at"],
                updated_at=row["updated_at"],
                created_by=row["created_by"],
            )

            task_rows = conn.execute(
                """SELECT * FROM tasks
                   WHERE checklist_id = ?
                   ORDER BY task_order""",
                (checklist_id,),
            ).fetchall()

            for tr in task_rows:
                checklist.tasks.append(
                    Task(
                        id=tr["id"],
                        content=tr["content"],
                        status=TaskStatus(tr["status"]),
                        created_at=tr["created_at"],
                        updated_at=tr["updated_at"],
                        completed_at=tr["completed_at"],
                        created_by=tr["created_by"],
                        checklist_id=tr["checklist_id"],
                        order=tr["task_order"],
                    )
                )

            return checklist

    def update_checklist_message_id(self, checklist_id: str, message_id: int) -> bool:
        """Store the Telegram message_id for a checklist (for live updates)."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                """UPDATE checklists
                   SET message_id = ?, updated_at = ?
                   WHERE id = ?""",
                (message_id, datetime.now().isoformat(), checklist_id),
            )
            return cursor.rowcount > 0

    def get_active_checklists(self, chat_id: int, limit: int = 10) -> list[Checklist]:
        """Get recent checklists for a chat that have incomplete tasks."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row

            rows = conn.execute(
                """SELECT DISTINCT c.* FROM checklists c
                   JOIN tasks t ON t.checklist_id = c.id
                   WHERE c.chat_id = ?
                     AND t.status NOT IN ('completed', 'cancelled')
                   ORDER BY c.updated_at DESC
                   LIMIT ?""",
                (chat_id, limit),
            ).fetchall()

            checklists = []
            for row in rows:
                cl = self.get_checklist(row["id"])
                if cl:
                    checklists.append(cl)

            return checklists

    # ─────────────────────────────────────────────────────────────
    # Task Operations
    # ─────────────────────────────────────────────────────────────

    def toggle_task(self, task_id: str, toggled_by: str = "user") -> Task | None:
        """Toggle a task's completion status. Returns updated task."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row

            row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()

            if not row:
                return None

            current_status = TaskStatus(row["status"])
            now = datetime.now().isoformat()

            # Toggle: completed <-> pending
            if current_status == TaskStatus.COMPLETED:
                new_status = TaskStatus.PENDING
                completed_at = None
            else:
                new_status = TaskStatus.COMPLETED
                completed_at = now

            conn.execute(
                """UPDATE tasks
                   SET status = ?, updated_at = ?, completed_at = ?
                   WHERE id = ?""",
                (new_status.value, now, completed_at, task_id),
            )

            # Update checklist timestamp
            if row["checklist_id"]:
                conn.execute(
                    "UPDATE checklists SET updated_at = ? WHERE id = ?", (now, row["checklist_id"])
                )

            return Task(
                id=row["id"],
                content=row["content"],
                status=new_status,
                created_at=row["created_at"],
                updated_at=now,
                completed_at=completed_at,
                created_by=row["created_by"],
                checklist_id=row["checklist_id"],
                order=row["task_order"],
            )

    def set_task_status(
        self, task_id: str, status: TaskStatus, updated_by: str = "otto"
    ) -> Task | None:
        """Set a specific task status."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row

            row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()

            if not row:
                return None

            now = datetime.now().isoformat()
            completed_at = now if status == TaskStatus.COMPLETED else None

            conn.execute(
                """UPDATE tasks
                   SET status = ?, updated_at = ?, completed_at = ?
                   WHERE id = ?""",
                (status.value, now, completed_at, task_id),
            )

            if row["checklist_id"]:
                conn.execute(
                    "UPDATE checklists SET updated_at = ? WHERE id = ?", (now, row["checklist_id"])
                )

            return Task(
                id=row["id"],
                content=row["content"],
                status=status,
                created_at=row["created_at"],
                updated_at=now,
                completed_at=completed_at,
                created_by=row["created_by"],
                checklist_id=row["checklist_id"],
                order=row["task_order"],
            )

    def add_task_to_checklist(
        self, checklist_id: str, content: str, created_by: str = "otto"
    ) -> Task | None:
        """Add a new task to an existing checklist."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row

            # Get max order
            row = conn.execute(
                "SELECT MAX(task_order) as max_order FROM tasks WHERE checklist_id = ?",
                (checklist_id,),
            ).fetchone()

            next_order = (row["max_order"] or 0) + 1
            now = datetime.now().isoformat()

            task = Task(
                id=uuid.uuid4().hex[:12],
                content=content,
                checklist_id=checklist_id,
                order=next_order,
                created_by=created_by,
                created_at=now,
                updated_at=now,
            )

            conn.execute(
                """INSERT INTO tasks
                   (id, content, status, created_at, updated_at,
                    completed_at, created_by, checklist_id, task_order)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    task.id,
                    task.content,
                    task.status.value,
                    task.created_at,
                    task.updated_at,
                    task.completed_at,
                    task.created_by,
                    task.checklist_id,
                    task.order,
                ),
            )

            conn.execute("UPDATE checklists SET updated_at = ? WHERE id = ?", (now, checklist_id))

            return task

    def get_task(self, task_id: str) -> Task | None:
        """Get a single task by ID."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row

            row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()

            if not row:
                return None

            return Task(
                id=row["id"],
                content=row["content"],
                status=TaskStatus(row["status"]),
                created_at=row["created_at"],
                updated_at=row["updated_at"],
                completed_at=row["completed_at"],
                created_by=row["created_by"],
                checklist_id=row["checklist_id"],
                order=row["task_order"],
            )

    # ─────────────────────────────────────────────────────────────
    # Rendering
    # ─────────────────────────────────────────────────────────────

    def render_checklist_text(self, checklist: Checklist) -> str:
        """Render checklist as Telegram HTML text."""
        lines = [f"<b>{checklist.title}</b>\n"]

        for task in checklist.tasks:
            if task.status == TaskStatus.COMPLETED:
                checkbox = "☑️"
                text = f"<s>{task.content}</s>"
            elif task.status == TaskStatus.IN_PROGRESS:
                checkbox = "🔄"
                text = task.content
            elif task.status == TaskStatus.CANCELLED:
                checkbox = "⊘"
                text = f"<s>{task.content}</s>"
            else:
                checkbox = "☐"
                text = task.content

            lines.append(f"{checkbox} {text}")

        # Progress summary
        total = len(checklist.tasks)
        completed = sum(1 for t in checklist.tasks if t.status == TaskStatus.COMPLETED)

        if total > 0:
            pct = int(completed / total * 100)
            lines.append(f"\n<i>{completed}/{total} complete ({pct}%)</i>")

        return "\n".join(lines)

    def build_checklist_keyboard(self, checklist: Checklist):
        """Build inline keyboard for task toggles."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        keyboard = []

        for task in checklist.tasks:
            if task.status == TaskStatus.COMPLETED:
                label = f"☑️ {task.content[:30]}"
            elif task.status == TaskStatus.CANCELLED:
                continue  # Don't show cancelled tasks as buttons
            else:
                label = f"☐ {task.content[:30]}"

            keyboard.append([InlineKeyboardButton(label, callback_data=f"task_toggle:{task.id}")])

        # Add action row
        keyboard.append(
            [
                InlineKeyboardButton("➕ Add task", callback_data=f"task_add:{checklist.id}"),
                InlineKeyboardButton("✓ Done", callback_data=f"task_done:{checklist.id}"),
            ]
        )

        return InlineKeyboardMarkup(keyboard)


# ─────────────────────────────────────────────────────────────────
# Module-level convenience functions
# ─────────────────────────────────────────────────────────────────

_manager: TaskManager | None = None


def get_task_manager() -> TaskManager:
    """Get singleton TaskManager instance."""
    global _manager
    if _manager is None:
        _manager = TaskManager()
    return _manager


def create_checklist(
    title: str, chat_id: int, tasks: list[str], created_by: str = "otto"
) -> Checklist:
    """Create a new checklist."""
    return get_task_manager().create_checklist(title, chat_id, tasks, created_by)


def get_checklist(checklist_id: str) -> Checklist | None:
    """Get a checklist by ID."""
    return get_task_manager().get_checklist(checklist_id)


def toggle_task(task_id: str, toggled_by: str = "user") -> Task | None:
    """Toggle task completion status."""
    return get_task_manager().toggle_task(task_id, toggled_by)


def render_checklist(checklist: Checklist) -> tuple[str, any]:
    """Render checklist text and keyboard."""
    mgr = get_task_manager()
    text = mgr.render_checklist_text(checklist)
    keyboard = mgr.build_checklist_keyboard(checklist)
    return text, keyboard


# ─────────────────────────────────────────────────────────────────
# Reaction Support
# ─────────────────────────────────────────────────────────────────


@dataclass
class Poll:
    """A multi-choice poll/question."""

    id: str
    chat_id: int
    question: str
    options: dict[str, str]  # {key: label}
    multi_select: bool = True
    message_id: int | None = None
    created_at: str = ""
    updated_at: str = ""
    created_by: str = "otto"
    closed: bool = False
    votes: dict[str, set[str]] = field(default_factory=dict)  # {option_key: {user_ids}}

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat()
        if not self.updated_at:
            self.updated_at = self.created_at


class ReactionManager:
    """Manages reactions on tasks and checklists."""

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path

    def add_reaction(
        self,
        target_type: str,  # 'task', 'checklist', 'message'
        target_id: str,
        emoji: str,
        user_id: str,
    ) -> bool:
        """Add a reaction. Returns True if added, False if already exists."""
        with sqlite3.connect(self.db_path) as conn:
            try:
                conn.execute(
                    """INSERT INTO reactions (id, target_type, target_id, emoji, user_id, created_at)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (
                        uuid.uuid4().hex[:12],
                        target_type,
                        target_id,
                        emoji,
                        user_id,
                        datetime.now().isoformat(),
                    ),
                )
                return True
            except sqlite3.IntegrityError:
                return False

    def remove_reaction(
        self,
        target_type: str,
        target_id: str,
        emoji: str,
        user_id: str,
    ) -> bool:
        """Remove a reaction. Returns True if removed."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                """DELETE FROM reactions
                   WHERE target_type = ? AND target_id = ? AND emoji = ? AND user_id = ?""",
                (target_type, target_id, emoji, user_id),
            )
            return cursor.rowcount > 0

    def toggle_reaction(
        self,
        target_type: str,
        target_id: str,
        emoji: str,
        user_id: str,
    ) -> bool:
        """Toggle a reaction. Returns True if now reacted, False if removed."""
        with sqlite3.connect(self.db_path) as conn:
            # Check if exists
            row = conn.execute(
                """SELECT id FROM reactions
                   WHERE target_type = ? AND target_id = ? AND emoji = ? AND user_id = ?""",
                (target_type, target_id, emoji, user_id),
            ).fetchone()

            if row:
                conn.execute("DELETE FROM reactions WHERE id = ?", (row[0],))
                return False
            else:
                conn.execute(
                    """INSERT INTO reactions (id, target_type, target_id, emoji, user_id, created_at)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (
                        uuid.uuid4().hex[:12],
                        target_type,
                        target_id,
                        emoji,
                        user_id,
                        datetime.now().isoformat(),
                    ),
                )
                return True

    def get_reactions(
        self,
        target_type: str,
        target_id: str,
    ) -> dict[str, int]:
        """Get reaction counts for a target."""
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                """SELECT emoji, COUNT(*) as count FROM reactions
                   WHERE target_type = ? AND target_id = ?
                   GROUP BY emoji""",
                (target_type, target_id),
            ).fetchall()
            return {row[0]: row[1] for row in rows}

    def get_user_reactions(
        self,
        target_type: str,
        target_id: str,
        user_id: str,
    ) -> set[str]:
        """Get emojis a user has reacted with."""
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                """SELECT emoji FROM reactions
                   WHERE target_type = ? AND target_id = ? AND user_id = ?""",
                (target_type, target_id, user_id),
            ).fetchall()
            return {row[0] for row in rows}


class PollManager:
    """Manages multi-choice polls."""

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path

    def create_poll(
        self,
        chat_id: int,
        question: str,
        options: dict[str, str],
        multi_select: bool = True,
        created_by: str = "otto",
    ) -> Poll:
        """Create a new poll."""
        import json

        poll_id = uuid.uuid4().hex[:12]
        now = datetime.now().isoformat()

        poll = Poll(
            id=poll_id,
            chat_id=chat_id,
            question=question,
            options=options,
            multi_select=multi_select,
            created_at=now,
            updated_at=now,
            created_by=created_by,
        )

        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """INSERT INTO polls
                   (id, chat_id, message_id, question, options, multi_select,
                    created_at, updated_at, created_by, closed)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    poll.id,
                    poll.chat_id,
                    poll.message_id,
                    poll.question,
                    json.dumps(options),
                    1 if multi_select else 0,
                    poll.created_at,
                    poll.updated_at,
                    poll.created_by,
                    0,
                ),
            )

        return poll

    def get_poll(self, poll_id: str) -> Poll | None:
        """Get a poll by ID with vote counts."""
        import json

        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row

            row = conn.execute("SELECT * FROM polls WHERE id = ?", (poll_id,)).fetchone()

            if not row:
                return None

            poll = Poll(
                id=row["id"],
                chat_id=row["chat_id"],
                question=row["question"],
                options=json.loads(row["options"]),
                multi_select=bool(row["multi_select"]),
                message_id=row["message_id"],
                created_at=row["created_at"],
                updated_at=row["updated_at"],
                created_by=row["created_by"],
                closed=bool(row["closed"]),
            )

            # Load votes
            vote_rows = conn.execute(
                "SELECT option_key, user_id FROM poll_votes WHERE poll_id = ?", (poll_id,)
            ).fetchall()

            for vr in vote_rows:
                opt_key = vr["option_key"]
                if opt_key not in poll.votes:
                    poll.votes[opt_key] = set()
                poll.votes[opt_key].add(vr["user_id"])

            return poll

    def toggle_vote(
        self,
        poll_id: str,
        user_id: str,
        option_key: str,
    ) -> bool:
        """Toggle a vote. Returns True if now voted, False if removed."""
        with sqlite3.connect(self.db_path) as conn:
            # Check if poll allows multi-select
            poll_row = conn.execute(
                "SELECT multi_select FROM polls WHERE id = ?", (poll_id,)
            ).fetchone()

            if not poll_row:
                return False

            multi_select = bool(poll_row[0])

            # Check if already voted for this option
            existing = conn.execute(
                """SELECT id FROM poll_votes
                   WHERE poll_id = ? AND user_id = ? AND option_key = ?""",
                (poll_id, user_id, option_key),
            ).fetchone()

            if existing:
                # Remove vote
                conn.execute("DELETE FROM poll_votes WHERE id = ?", (existing[0],))
                return False
            else:
                # If single-select, remove other votes first
                if not multi_select:
                    conn.execute(
                        "DELETE FROM poll_votes WHERE poll_id = ? AND user_id = ?",
                        (poll_id, user_id),
                    )

                # Add vote
                conn.execute(
                    """INSERT INTO poll_votes (id, poll_id, user_id, option_key, created_at)
                       VALUES (?, ?, ?, ?, ?)""",
                    (
                        uuid.uuid4().hex[:12],
                        poll_id,
                        user_id,
                        option_key,
                        datetime.now().isoformat(),
                    ),
                )
                return True

    def get_user_votes(self, poll_id: str, user_id: str) -> set[str]:
        """Get options a user has voted for."""
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT option_key FROM poll_votes WHERE poll_id = ? AND user_id = ?",
                (poll_id, user_id),
            ).fetchall()
            return {row[0] for row in rows}

    def update_poll_message_id(self, poll_id: str, message_id: int) -> bool:
        """Store the Telegram message_id for a poll."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "UPDATE polls SET message_id = ?, updated_at = ? WHERE id = ?",
                (message_id, datetime.now().isoformat(), poll_id),
            )
            return cursor.rowcount > 0

    def close_poll(self, poll_id: str) -> bool:
        """Close a poll to further voting."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "UPDATE polls SET closed = 1, updated_at = ? WHERE id = ?",
                (datetime.now().isoformat(), poll_id),
            )
            return cursor.rowcount > 0

    def render_poll_text(self, poll: Poll) -> str:
        """Render poll as Telegram HTML text."""
        lines = [f"<b>{poll.question}</b>\n"]

        total_votes = sum(len(users) for users in poll.votes.values())

        for key, label in poll.options.items():
            vote_count = len(poll.votes.get(key, set()))
            pct = int(vote_count / total_votes * 100) if total_votes > 0 else 0

            # Progress bar
            filled = int(pct / 10)
            bar = "█" * filled + "░" * (10 - filled)

            lines.append(f"{label}")
            lines.append(f"<code>{bar}</code> {vote_count} ({pct}%)")

        if poll.closed:
            lines.append("\n<i>Poll closed</i>")
        else:
            mode = "Multi-select" if poll.multi_select else "Single choice"
            lines.append(f"\n<i>{mode} • {total_votes} votes</i>")

        return "\n".join(lines)

    def build_poll_keyboard(self, poll: Poll, user_id: str):
        """Build inline keyboard for poll voting."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        if poll.closed:
            return None

        user_votes = self.get_user_votes(poll.id, user_id)
        keyboard = []

        for key, label in poll.options.items():
            checkbox = "☑️" if key in user_votes else "☐"
            keyboard.append(
                [
                    InlineKeyboardButton(
                        f"{checkbox} {label}", callback_data=f"poll_vote:{poll.id}:{key}"
                    )
                ]
            )

        # Close button (for poll creator)
        keyboard.append(
            [
                InlineKeyboardButton("📊 Results", callback_data=f"poll_results:{poll.id}"),
                InlineKeyboardButton("🔒 Close", callback_data=f"poll_close:{poll.id}"),
            ]
        )

        return InlineKeyboardMarkup(keyboard)


# Singleton instances
_reaction_manager: ReactionManager | None = None
_poll_manager: PollManager | None = None


def get_reaction_manager() -> ReactionManager:
    """Get singleton ReactionManager instance."""
    global _reaction_manager
    if _reaction_manager is None:
        _reaction_manager = ReactionManager()
    return _reaction_manager


def get_poll_manager() -> PollManager:
    """Get singleton PollManager instance."""
    global _poll_manager
    if _poll_manager is None:
        _poll_manager = PollManager()
    return _poll_manager


def render_poll(poll: Poll, user_id: str) -> tuple[str, any]:
    """Render poll text and keyboard."""
    mgr = get_poll_manager()
    text = mgr.render_poll_text(poll)
    keyboard = mgr.build_poll_keyboard(poll, user_id)
    return text, keyboard
