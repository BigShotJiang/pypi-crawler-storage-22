#!/usr/bin/env python3
"""
Telegram bot service - thin runner.

This module provides the entry point for the Telegram bot using the
ChatPlatform abstraction. Run via:

    otto service start telegram
    otto service start telegram -f  # foreground

Or directly:

    python -m otto.services.telegram
"""

from __future__ import annotations

import logging
import os
import re
from logging.handlers import RotatingFileHandler

from otto import index_memory
from otto.paths import CONFIG_DIR, LOGS_DIR, ensure_dirs


class _RedactBotToken(logging.Filter):
    """Redact Telegram bot tokens from logs (best-effort)."""

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:
            return True

        if "api.telegram.org/bot" in msg:
            record.msg = re.sub(
                r"(api\.telegram\.org/bot)[^/]+",
                r"\1<redacted>",
                msg,
            )
            record.args = ()
        return True


def _setup_logging() -> logging.Logger:
    """Set up logging for the bot."""
    ensure_dirs()
    LOGS_DIR.mkdir(parents=True, exist_ok=True)

    handlers = [
        RotatingFileHandler(
            LOGS_DIR / "telegram.log",
            maxBytes=5 * 1024 * 1024,
            backupCount=5,
            encoding="utf-8",
        ),
        logging.StreamHandler(),
    ]
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(message)s",
        level=logging.INFO,
        handlers=handlers,
    )

    # Silence library noise
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("telegram").setLevel(logging.INFO)
    logging.getLogger("telegram.ext").setLevel(logging.INFO)

    root = logging.getLogger()
    root.addFilter(_RedactBotToken())

    return logging.getLogger(__name__)


def _load_token() -> str | None:
    """Load Telegram bot token from environment or config file."""
    token = os.environ.get("TELEGRAM_BOT_TOKEN") or os.environ.get("OTTO_TELEGRAM_BOT_TOKEN")
    if token:
        return token

    env_file = CONFIG_DIR / ".env"
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if line.startswith(
                ("TELEGRAM_BOT_TOKEN=", "OTTO_TELEGRAM_BOT_TOKEN=")
            ) and not line.endswith("="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    return None


SERVICE_NAME = "telegram-bot"


def main() -> None:
    """Main entry point for the Telegram bot."""
    from otto import audit
    from otto import config as otto_config
    from otto.backends import get_active_backend_name
    from otto.chat.telegram import TelegramPlatform
    from otto.daemon import ServiceStatus, cleanup_own_pid, status, write_own_pid

    log = _setup_logging()

    # Check for already running instance (skip if the PID is ourself - happens when
    # started via daemon.start() which writes our PID before we run)
    info = status(SERVICE_NAME)
    if info.status == ServiceStatus.RUNNING and info.pid != os.getpid():
        log.error(
            "Telegram bot is already running (PID %s). "
            "Stop it first with: otto service stop telegram",
            info.pid,
        )
        return

    # Write our PID file (may already exist if started via daemon.start())
    write_own_pid(SERVICE_NAME)

    try:
        # Load token
        token = _load_token()
        if not token:
            log.error(
                "No TELEGRAM_BOT_TOKEN/OTTO_TELEGRAM_BOT_TOKEN. Set env var or edit %s/.env",
                CONFIG_DIR,
            )
            return

        ensure_dirs()

        bootstrap_mode = (
            str(otto_config.get_setting("access.bootstrap.mode", "first_user") or "")
            .strip()
            .lower()
        )
        allowed_ids = otto_config.get_allowed_user_ids()
        owner_id = otto_config.get_setting("access.owner_id")

        if not owner_id and not allowed_ids and bootstrap_mode == "first_user":
            log.info("No owner configured. First Telegram user to /start will become owner.")
        else:
            log.info(
                "Allowed Telegram user IDs: %s", sorted(allowed_ids) if allowed_ids else "(none)"
            )

        # Log startup
        audit.log_system("bot_startup", data={"backend": get_active_backend_name()})

        # Index memory on startup
        try:
            counts = index_memory()
            log.info("Memory indexed: %s chunks", counts.get("total", 0))
        except Exception as e:
            log.warning("Memory indexing failed: %s", e)

        # Create and run platform
        platform = TelegramPlatform(token=token)

        # Use blocking run() which manages its own event loop
        platform.run()
    finally:
        # Clean up PID file
        cleanup_own_pid(SERVICE_NAME)


if __name__ == "__main__":
    main()
