#!/usr/bin/env python3
"""
Job Worker - processes jobs from the SQLite queue.

This module is the installable entrypoint used by `otto service start worker`.
"""

from __future__ import annotations

import logging
import os
import signal
import subprocess
import time
from collections.abc import Callable
from logging.handlers import RotatingFileHandler
from pathlib import Path

from otto import get_backend
from otto.jobs.queue import JobQueue
from otto.notify import send as send_notification
from otto.paths import BRAINFILE, LOGS_DIR, ensure_dirs, get_workdir
from otto.schedule_state import mark_run

ensure_dirs()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        RotatingFileHandler(
            LOGS_DIR / "worker.log",
            maxBytes=5 * 1024 * 1024,
            backupCount=5,
            encoding="utf-8",
        ),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger(__name__)


HANDLERS: dict[str, Callable[[dict], str]] = {}

_NOTIFY_MODES = {"always", "on_error", "on_action", "never"}


def _normalize_notify_mode(value: object, *, default: str = "never") -> str:
    """Normalize notify config to a supported mode."""
    if value is None:
        return default
    if isinstance(value, bool):
        return "always" if value else "never"
    mode = str(value).strip().lower()
    if mode in ("true", "yes", "1"):
        return "always"
    if mode in ("false", "no", "0"):
        return "never"
    return mode if mode in _NOTIFY_MODES else default


def handler(job_type: str):
    """Decorator to register a job handler."""

    def decorator(func):
        HANDLERS[job_type] = func
        return func

    return decorator


@handler("notify")
def handle_notify(payload: dict) -> str:
    message = payload.get("message", "")
    if not message:
        raise ValueError("No message in payload")
    send_notification(message)
    return "Notification sent"


@handler("claude")
@handler("agent")
def handle_agent(payload: dict) -> str:
    from otto.backends import get_orchestration_config
    from otto.paths import OUTPUTS_DIR

    prompt = payload.get("prompt", "")
    if not prompt:
        raise ValueError("No prompt in payload")

    # Inject upstream context for pipeline jobs
    upstream = payload.get("_upstream_context")
    if upstream and upstream.get("parent_output"):
        context_block = [
            "<upstream_pipeline_context>",
            f"Previous stage: {upstream.get('parent_task', 'unknown')}",
            f"Status: {upstream.get('parent_status', 'unknown')}",
            "",
            "Output from previous stage:",
            upstream.get("parent_output", ""),
            "</upstream_pipeline_context>",
            "",
            "Your task (continue the pipeline):",
        ]
        prompt = "\n".join(context_block) + "\n" + prompt

    system = (
        payload.get("system")
        or payload.get("system_prompt")
        or "You are Otto, a helpful assistant."
    )
    # Get default timeout from config
    orch_config = get_orchestration_config()
    default_timeout = orch_config.get("default_timeout", 3600)
    timeout = int(payload.get("timeout", default_timeout))
    backend_name = payload.get("backend")  # None uses active backend
    model = payload.get("model")  # For dynamic routing (e.g., "openrouter/provider/model")
    notify_mode = _normalize_notify_mode(payload.get("notify"), default="never")
    pipeline_grace = int(orch_config.get("pipeline_notify_grace_seconds", 8) or 0)
    if pipeline_grace < 0:
        pipeline_grace = 0

    backend = get_backend(backend_name)
    result = backend.run_sync(prompt, system, get_workdir(), timeout, model=model)

    agent_id = str(payload.get("agent_id") or payload.get("id") or "")[:32]
    task_desc = str(payload.get("task") or payload.get("task_description") or "").strip()
    priority = str(payload.get("priority") or "normal")

    output_file = payload.get("output_file")
    if output_file:
        output_path = Path(str(output_file)).expanduser()
    elif agent_id:
        output_path = OUTPUTS_DIR / f"{agent_id}.txt"
    else:
        output_path = None

    if output_path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        content = [
            f"Task: {task_desc}" if task_desc else "Task: (unspecified)",
            f"Backend: {backend_name or backend.name}",
            f"Success: {result.success}",
            f"Duration: {result.duration_seconds:.2f}s",
            "",
            "=" * 50,
            "",
            result.output or "",
        ]
        if result.error:
            content.extend(["", f"Error: {result.error}"])
        output_path.write_text("\n".join(content))

    job_meta = payload.get("_job") if isinstance(payload.get("_job"), dict) else {}
    attempt = int(job_meta.get("attempt", 0) or 0)
    max_attempts = int(job_meta.get("max_attempts", 0) or 0)
    is_final_attempt = max_attempts > 0 and attempt >= max_attempts

    output_text = (result.output or "").strip()
    should_notify = False
    if notify_mode == "always":
        should_notify = result.success or is_final_attempt
    elif notify_mode == "on_error":
        should_notify = (not result.success) and is_final_attempt
    elif notify_mode == "on_action":
        should_notify = (bool(output_text) and result.success) or (
            (not result.success) and is_final_attempt
        )

    # Store notification metadata for the worker to handle AFTER job is marked complete.
    # This ensures pipeline completion checks see accurate job statuses.
    if should_notify:
        payload["_notify_meta"] = {
            "agent_id": agent_id or None,
            "task": task_desc or None,
            "backend": backend_name or backend.name,
            "success": result.success,
            "attempt": attempt or None,
            "max_attempts": max_attempts or None,
            "duration": result.duration_seconds,
            "output_file": str(output_path) if output_path else None,
            "output_summary": output_text[:2000] or None,
            "error": (result.error[:200] if result.error else None),
            "priority": priority,
            "pipeline_grace": pipeline_grace,
            "session_id": payload.get("session_id"),
            "chat_id": payload.get("chat_id"),
        }
        if not job_meta.get("id"):
            from otto.internal_messages import InternalMessage, queue_message

            msg = InternalMessage.create(
                "agent_completed",
                {
                    "agent_id": agent_id or None,
                    "task": task_desc or None,
                    "backend": backend_name or backend.name,
                    "success": result.success,
                    "attempt": attempt or None,
                    "max_attempts": max_attempts or None,
                    "duration": result.duration_seconds,
                    "output_file": str(output_path) if output_path else None,
                    "output_summary": output_text[:2000] or None,
                    "error": (result.error[:200] if result.error else None),
                    "priority": priority,
                    "session_id": payload.get("session_id"),
                    "chat_id": payload.get("chat_id"),
                },
            )
            queue_message(msg)

    if not result.success:
        raise RuntimeError(f"Agent failed: {result.error}")
    return result.output


@handler("shell")
def handle_shell(payload: dict) -> str:
    command = payload.get("command", "")
    if not command:
        raise ValueError("No command in payload")

    timeout = int(payload.get("timeout", 60))
    cwd = payload.get("cwd") or str(get_workdir())

    result = subprocess.run(
        command,
        shell=True,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )

    output = result.stdout + result.stderr
    if result.returncode != 0:
        raise RuntimeError(f"Command failed (exit {result.returncode}): {output}")

    return output.strip()


@handler("http")
def handle_http(payload: dict) -> str:
    import urllib.error
    import urllib.request

    url = payload.get("url", "")
    if not url:
        raise ValueError("No URL in payload")

    method = payload.get("method", "GET")
    headers = payload.get("headers", {})
    data = payload.get("data")
    timeout = int(payload.get("timeout", 30))

    req = urllib.request.Request(
        url,
        method=method,
        headers=headers,
        data=data.encode() if data else None,
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return f"{resp.status}: {resp.read().decode()[:1000]}"
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HTTP {e.code}: {e.reason}")


def _substitute_result(obj, result: str):
    if isinstance(obj, str):
        return obj.replace("{{result}}", result)
    if isinstance(obj, dict):
        return {k: _substitute_result(v, result) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_substitute_result(item, result) for item in obj]
    return obj


@handler("chain")
def handle_chain(payload: dict) -> str:
    jobs = payload.get("jobs", [])
    if not jobs:
        return "No jobs to chain"

    last_result = ""
    results = []

    for i, job_spec in enumerate(jobs):
        job_type = job_spec.get("type")
        job_payload = _substitute_result(job_spec.get("payload", {}), last_result)

        handler_func = HANDLERS.get(job_type)
        if not handler_func:
            raise RuntimeError(f"Step {i + 1}: No handler for {job_type}")

        log.info("Chain step %s/%s: %s", i + 1, len(jobs), job_type)
        last_result = handler_func(job_payload)
        results.append(f"Step {i + 1} ({job_type}): {str(last_result)[:50]}")

    return "\n".join(results)


@handler("scheduled")
def handle_scheduled(payload: dict) -> str:
    from datetime import datetime

    import yaml

    from otto.backends import get_orchestration_config
    from otto.internal_messages import InternalMessage, queue_message
    from otto.paths import OUTPUTS_DIR

    job_id = payload.get("job_id", "")
    prompt = payload.get("prompt", "")
    notify_mode = str(payload.get("notify", "on_error") or "on_error").strip().lower()
    backend_name = payload.get("backend")  # None uses active
    model = payload.get("model")  # For dynamic routing
    one_shot = bool(payload.get("one_shot", False))
    scheduled_for = payload.get("scheduled_for")
    # Get default timeout from config
    orch_config = get_orchestration_config()
    default_timeout = orch_config.get("default_timeout", 3600)
    timeout = int(payload.get("timeout", default_timeout))

    if not job_id:
        raise ValueError("No job_id in scheduled job payload")
    if not prompt:
        raise ValueError("No prompt in scheduled job payload")

    # Parse brainfile for context
    data = None
    if BRAINFILE.exists():
        content = BRAINFILE.read_text()
        if content.startswith("---"):
            end = content.find("\n---", 3)
            if end != -1:
                data = yaml.safe_load(content[4:end])

    if data:
        persona = data.get("persona", {})
        identity = persona.get("identity", "You are Otto.")
        context = data.get("context", {})
        rules = data.get("rules", {})

        system_parts = [
            identity,
            "You are running a scheduled job autonomously.",
            f"Context: {context}",
            f"Rules: {rules}",
            "Respond briefly. Take action if needed. Format for Telegram (HTML tags only).",
        ]
        system_prompt = "\n".join(str(p) for p in system_parts)
    else:
        system_prompt = "You are Otto, a helpful assistant running a scheduled job."

    backend = get_backend(backend_name)
    result = backend.run_sync(prompt, system_prompt, get_workdir(), timeout, model=model)

    success = result.success
    output = result.output if success else (result.error or "")

    # Normalize notify semantics.
    if notify_mode in ("true", "yes", "1"):
        notify_mode = "always"
    if notify_mode in ("false", "no", "0"):
        notify_mode = "never"
    if notify_mode not in ("always", "on_error", "on_action", "never"):
        notify_mode = "on_error"

    # Update schedule state (durable JSON; brainfile stays config-only).
    mark_run(
        job_id,
        status="completed" if success else "failed",
        error=None if success else output[:500],
        one_shot=one_shot,
    )

    # Persist output for later review (avoid chat spam).
    output_path = None
    try:
        OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
        stamp = (
            str(scheduled_for).replace(":", "").replace("-", "").replace("T", "-")[:15]
            if scheduled_for
            else datetime.now().strftime("%Y%m%d-%H%M%S")
        )
        output_path = OUTPUTS_DIR / f"job-{job_id}-{stamp}.txt"
        content = [
            f"Job: {job_id}",
            f"Scheduled for: {scheduled_for}" if scheduled_for else "Scheduled for: (unknown)",
            f"Backend: {backend_name or backend.name}",
            f"Success: {success}",
            f"Duration: {result.duration_seconds:.2f}s",
            "",
            "=" * 50,
            "",
            result.output or "",
        ]
        if result.error:
            content.extend(["", f"Error: {result.error}"])
        output_path.write_text("\n".join(content), encoding="utf-8")
    except Exception:
        output_path = None

    # Notifications (via internal event queue, delivered conversationally by the bot).
    output_text = (result.output or "").strip()
    should_notify = False
    if notify_mode == "always":
        should_notify = True
    elif notify_mode == "on_error":
        should_notify = not success
    elif notify_mode == "on_action":
        should_notify = bool(output_text) or (not success)
    elif notify_mode == "never":
        should_notify = False

    if should_notify:
        output_summary = output_text[:800]
        if len(output_text) > 800:
            output_summary += "..."

        msg = InternalMessage.create(
            "scheduled_job",
            {
                "job_id": job_id,
                "scheduled_for": scheduled_for,
                "backend": backend_name or backend.name,
                "success": success,
                "duration_seconds": result.duration_seconds,
                "output_file": str(output_path) if output_path else None,
                "output_summary": output_summary or None,
                "error": (result.error[:800] if result.error else None),
                "chat_id": payload.get("chat_id"),
            },
        )
        queue_message(msg)

    if not success:
        raise RuntimeError(f"Scheduled job failed: {output[:500]}")

    return f"Scheduled job {job_id} completed: {output[:200]}"


class Worker:
    # Heartbeat interval (minutes) - should be well under stale lock timeout (30 min)
    HEARTBEAT_INTERVAL_MINUTES: float = 5.0  # Can override via env WORKER_HEARTBEAT_MIN

    def __init__(self, worker_id: str | None = None, concurrency: int = 1):
        self.queue = JobQueue()
        self.worker_id = worker_id or f"worker-{os.getpid()}"
        self.running = True
        self.poll_interval = 5
        self.concurrency = max(1, concurrency)
        self._last_tick_at: float = time.monotonic()
        self._tick_interval: float = 60.0

        # Allow env var override for testing
        env_hb = os.environ.get("WORKER_HEARTBEAT_MIN")
        if env_hb:
            try:
                self.HEARTBEAT_INTERVAL_MINUTES = float(env_hb)
            except ValueError:
                pass

        signal.signal(signal.SIGTERM, self._shutdown)
        signal.signal(signal.SIGINT, self._shutdown)

    def _shutdown(self, signum, frame):
        log.info("Received signal %s, shutting down...", signum)
        self.running = False

    def _maybe_tick(self) -> None:
        """Run scheduler tick if enough time has elapsed since the last one."""
        now = time.monotonic()
        if now - self._last_tick_at < self._tick_interval:
            return
        self._last_tick_at = now
        try:
            from otto.schedule import tick

            result = tick(dry_run=False)
            if result.get("skipped"):
                return
            enqueued = result.get("enqueued", [])
            if enqueued:
                log.info("Scheduler tick enqueued %d job(s)", len(enqueued))
        except Exception:
            log.exception("Scheduler tick failed")

    def _run_with_heartbeat(self, job_id: int, job_type: str, handler_func, payload: dict) -> str:
        """Run a handler with periodic heartbeat updates.

        Creates a per-job heartbeat thread that runs independently.
        Used by both single-threaded and concurrent modes.
        """
        import threading

        stop_event = threading.Event()

        def _heartbeat():
            interval_seconds = self.HEARTBEAT_INTERVAL_MINUTES * 60
            while not stop_event.is_set():
                time.sleep(interval_seconds)
                if stop_event.is_set():
                    break
                try:
                    self.queue.heartbeat(job_id)
                except Exception:
                    log.exception("Heartbeat failed for job #%s", job_id)

        # Start heartbeat thread
        thread = threading.Thread(target=_heartbeat, daemon=True)
        thread.start()
        log.debug(
            "Started heartbeat for job #%s (interval=%.1f min)",
            job_id,
            self.HEARTBEAT_INTERVAL_MINUTES,
        )

        try:
            return handler_func(payload)
        finally:
            stop_event.set()
            # Give thread a moment to exit cleanly
            thread.join(timeout=1.0)

    def process_one(self) -> bool:
        job = self.queue.next(self.worker_id)
        if not job:
            return False

        job_id = job["id"]
        job_type = job["type"]
        payload = job["payload"]

        log.info("Processing job #%s [%s]", job_id, job_type)
        self.queue.set_pid(job_id, os.getpid())

        # Best-effort metadata for handlers (helps with retries/notifications).
        if isinstance(payload, dict):
            payload["_job"] = {
                "id": job_id,
                "type": job_type,
                "external_id": job.get("external_id"),
                "attempt": job.get("attempts"),
                "max_attempts": job.get("max_attempts"),
                "depends_on_id": job.get("depends_on_id"),
            }

            # Inject upstream context for pipeline jobs
            depends_on_id = job.get("depends_on_id")
            if depends_on_id and job_type == "agent":
                upstream_context = self._get_upstream_context(depends_on_id)
                if upstream_context:
                    payload["_upstream_context"] = upstream_context

        handler_func = HANDLERS.get(job_type)
        if not handler_func:
            error = f"No handler for job type: {job_type}"
            log.error(error)
            self.queue.fail(job_id, error)
            return True

        try:
            # Run with heartbeat for long-running job types
            if job_type in ("agent", "scheduled", "claude"):
                result = self._run_with_heartbeat(job_id, job_type, handler_func, payload)
            else:
                result = handler_func(payload)

            # Check if job was cancelled while running (force_cancel from CLI/chat)
            job_now = self.queue.get(job_id)
            if job_now and job_now.get("status") == "cancelled":
                log.info("Job #%s was cancelled while running, discarding result", job_id)
                return True

            self.queue.complete(job_id)

            if job_type == "agent":
                agent_id = job.get("external_id") or payload.get("agent_id") or payload.get("id")
                if agent_id:
                    self.queue.activate_dependents(str(agent_id), "completed")

                # Handle notifications AFTER job is marked complete so pipeline checks are accurate
                notify_meta = payload.get("_notify_meta")
                if notify_meta:
                    self._handle_agent_notification(notify_meta, success=True)

            if "on_success" in payload:
                self._handle_callback(payload["on_success"], str(result))
        except Exception as e:
            error = str(e)
            log.error("Job #%s failed: %s", job_id, error)

            # Check if job was cancelled while running
            job_now = self.queue.get(job_id)
            if job_now and job_now.get("status") == "cancelled":
                log.info("Job #%s was cancelled while running, not marking as failed", job_id)
                return True

            self.queue.fail(job_id, error)

            if job_type == "agent":
                agent_id = job.get("external_id") or payload.get("agent_id") or payload.get("id")
                job_after = self.queue.get(job_id)
                if agent_id and job_after and job_after.get("status") == "failed":
                    self.queue.activate_dependents(str(agent_id), "failed")

                # Handle notifications AFTER job is marked failed so pipeline checks are accurate
                notify_meta = payload.get("_notify_meta")
                if notify_meta:
                    # Update meta with failure info
                    notify_meta["success"] = False
                    notify_meta["error"] = error[:200] if error else None
                    self._handle_agent_notification(notify_meta, success=False)

            if "on_failure" in payload:
                self._handle_callback(payload["on_failure"], error)

        return True

    def _handle_callback(self, callback: dict, data: str) -> None:
        callback_type = callback.get("type", "notify")
        callback_payload = callback.get("payload", {})
        callback_payload["_data"] = data
        self.queue.add(callback_type, callback_payload)

    def _get_upstream_context(self, parent_agent_id: str) -> dict | None:
        """Get output from upstream pipeline stage to inject into downstream prompt."""
        from otto.paths import OUTPUTS_DIR

        if not parent_agent_id:
            return None

        # Get parent job info
        parent_job = self.queue.get_by_external_id(parent_agent_id, job_type="agent")
        if not parent_job:
            return None

        parent_payload = parent_job.get("payload", {})
        parent_task = parent_payload.get("task") or parent_payload.get("task_description") or ""
        parent_status = parent_job.get("status", "unknown")

        # Try to read parent's output file
        output_file = OUTPUTS_DIR / f"{parent_agent_id}.txt"
        output_content = None
        if output_file.exists():
            try:
                raw = output_file.read_text(encoding="utf-8")
                # Extract just the output portion (after the separator line)
                if "=" * 50 in raw:
                    output_content = raw.split("=" * 50, 1)[-1].strip()
                else:
                    output_content = raw.strip()
                # Limit size to avoid prompt bloat
                if len(output_content) > 4000:
                    output_content = output_content[:4000] + "\n... (truncated)"
            except Exception:
                pass

        return {
            "parent_agent_id": parent_agent_id,
            "parent_task": parent_task,
            "parent_status": parent_status,
            "parent_output": output_content,
        }

    def _handle_agent_notification(self, meta: dict, *, success: bool) -> None:
        """Handle agent completion notification after job is marked complete."""
        from otto.internal_messages import InternalMessage, queue_message
        from otto.paths import OUTPUTS_DIR

        agent_id = meta.get("agent_id")
        priority = meta.get("priority", "normal")
        pipeline_grace = meta.get("pipeline_grace", 0)

        if agent_id:
            # Check pipeline completion now that job status is accurate in DB
            is_complete, pipeline_members = self.queue.is_pipeline_complete(agent_id)

            if not is_complete:
                log.info(
                    "Agent %s is part of an incomplete pipeline, deferring notification",
                    agent_id,
                )
                return

            if len(pipeline_members) > 1:
                # Pipeline completed! Send a single event with all members.
                root_id = self.queue.get_pipeline_root(agent_id)
                log.info("Pipeline completed for root agent %s.", root_id)
                msg = InternalMessage.create(
                    "pipeline_completed",
                    {
                        "root_agent_id": root_id,
                        "final_agent_id": agent_id,
                        "members": [
                            {
                                "agent_id": m.get("external_id"),
                                "task": (m.get("payload") or {}).get("task")
                                or (m.get("payload") or {}).get("task_description"),
                                "status": m.get("status"),
                                "output_file": str(OUTPUTS_DIR / f"{m.get('external_id')}.txt")
                                if m.get("external_id")
                                else None,
                            }
                            for m in pipeline_members
                        ],
                        "all_success": all(
                            m.get("status") == "completed" for m in pipeline_members
                        ),
                        "priority": priority,
                        "session_id": meta.get("session_id"),
                        "chat_id": meta.get("chat_id"),
                    },
                )
                queue_message(msg)
            else:
                # Single agent completed - send normal notification.
                msg = InternalMessage.create(
                    "agent_completed",
                    {
                        "agent_id": agent_id,
                        "task": meta.get("task"),
                        "backend": meta.get("backend"),
                        "success": meta.get("success"),
                        "attempt": meta.get("attempt"),
                        "max_attempts": meta.get("max_attempts"),
                        "duration": meta.get("duration"),
                        "output_file": meta.get("output_file"),
                        "output_summary": meta.get("output_summary"),
                        "error": meta.get("error"),
                        "priority": priority,
                        "session_id": meta.get("session_id"),
                        "chat_id": meta.get("chat_id"),
                    },
                )
                queue_message(msg, delay_seconds=pipeline_grace if pipeline_grace else None)
        else:
            # No agent_id - send basic notification without pipeline logic
            msg = InternalMessage.create(
                "agent_completed",
                {
                    "agent_id": None,
                    "task": meta.get("task"),
                    "backend": meta.get("backend"),
                    "success": meta.get("success"),
                    "attempt": meta.get("attempt"),
                    "max_attempts": meta.get("max_attempts"),
                    "duration": meta.get("duration"),
                    "output_file": meta.get("output_file"),
                    "output_summary": meta.get("output_summary"),
                    "error": meta.get("error"),
                    "priority": priority,
                    "session_id": meta.get("session_id"),
                    "chat_id": meta.get("chat_id"),
                },
            )
            queue_message(msg)

    def run_all(self) -> int:
        count = 0
        while self.running and self.process_one():
            count += 1
        log.info("Processed %s jobs", count)
        return count

    def run_daemon(self) -> None:
        if self.concurrency > 1:
            self.run_daemon_concurrent()
            return
        log.info("Worker %s starting daemon mode (single-threaded)", self.worker_id)
        # Run first tick shortly after startup
        self._last_tick_at = time.monotonic() - self._tick_interval + 5.0
        while self.running:
            self._maybe_tick()
            if not self.process_one():
                time.sleep(self.poll_interval)
        log.info("Worker stopped")

    def run_daemon_concurrent(self) -> None:
        from concurrent.futures import Future, ThreadPoolExecutor

        log.info(
            "Worker %s starting daemon mode (concurrency=%d)",
            self.worker_id,
            self.concurrency,
        )
        futures: list[Future] = []
        pool = ThreadPoolExecutor(max_workers=self.concurrency)
        # Run first tick shortly after startup
        self._last_tick_at = time.monotonic() - self._tick_interval + 5.0
        try:
            while self.running:
                self._maybe_tick()

                # Collect completed futures
                done = [f for f in futures if f.done()]
                for f in done:
                    futures.remove(f)
                    try:
                        f.result()
                    except Exception:
                        log.exception("Worker thread error")

                # Submit new jobs if free slots available
                submitted = False
                while self.running and len(futures) < self.concurrency:
                    job = self.queue.next(self.worker_id)
                    if not job:
                        break
                    futures.append(pool.submit(self._process_job, job))
                    submitted = True

                if not submitted and not done:
                    time.sleep(self.poll_interval)
        finally:
            # Wait for in-flight jobs to finish
            log.info("Waiting for %d in-flight job(s) to complete...", len(futures))
            for f in futures:
                try:
                    f.result(timeout=60)
                except Exception:
                    log.exception("Error in in-flight job during shutdown")
            pool.shutdown(wait=False)
            log.info("Worker stopped")

    def _process_job(self, job: dict) -> None:
        """Process a single job (used by concurrent mode)."""
        job_id = job["id"]
        job_type = job["type"]
        payload = job["payload"]

        log.info("Processing job #%s [%s]", job_id, job_type)
        self.queue.set_pid(job_id, os.getpid())

        if isinstance(payload, dict):
            payload["_job"] = {
                "id": job_id,
                "type": job_type,
                "external_id": job.get("external_id"),
                "attempt": job.get("attempts"),
                "max_attempts": job.get("max_attempts"),
                "depends_on_id": job.get("depends_on_id"),
            }
            depends_on_id = job.get("depends_on_id")
            if depends_on_id and job_type == "agent":
                upstream_context = self._get_upstream_context(depends_on_id)
                if upstream_context:
                    payload["_upstream_context"] = upstream_context

        handler_func = HANDLERS.get(job_type)
        if not handler_func:
            error = f"No handler for job type: {job_type}"
            log.error(error)
            self.queue.fail(job_id, error)
            return

        try:
            # Run with heartbeat for long-running job types
            if job_type in ("agent", "scheduled", "claude"):
                result = self._run_with_heartbeat(job_id, job_type, handler_func, payload)
            else:
                result = handler_func(payload)

            # Check if job was cancelled while running (force_cancel from CLI/chat)
            job_now = self.queue.get(job_id)
            if job_now and job_now.get("status") == "cancelled":
                log.info("Job #%s was cancelled while running, discarding result", job_id)
                return

            self.queue.complete(job_id)

            if job_type == "agent":
                agent_id = job.get("external_id") or payload.get("agent_id") or payload.get("id")
                if agent_id:
                    self.queue.activate_dependents(str(agent_id), "completed")
                notify_meta = payload.get("_notify_meta")
                if notify_meta:
                    self._handle_agent_notification(notify_meta, success=True)

            if "on_success" in payload:
                self._handle_callback(payload["on_success"], str(result))
        except Exception as e:
            error = str(e)
            log.error("Job #%s failed: %s", job_id, error)

            # Check if job was cancelled while running
            job_now = self.queue.get(job_id)
            if job_now and job_now.get("status") == "cancelled":
                log.info("Job #%s was cancelled while running, not marking as failed", job_id)
                return

            self.queue.fail(job_id, error)

            if job_type == "agent":
                agent_id = job.get("external_id") or payload.get("agent_id") or payload.get("id")
                job_after = self.queue.get(job_id)
                if agent_id and job_after and job_after.get("status") == "failed":
                    self.queue.activate_dependents(str(agent_id), "failed")
                notify_meta = payload.get("_notify_meta")
                if notify_meta:
                    notify_meta["success"] = False
                    notify_meta["error"] = error[:200] if error else None
                    self._handle_agent_notification(notify_meta, success=False)

            if "on_failure" in payload:
                self._handle_callback(payload["on_failure"], error)


SERVICE_NAME = "job-worker"


def main(*, daemon: bool = False, once: bool = False, worker_id: str | None = None) -> None:
    import signal

    from otto.backends import reload_config
    from otto.daemon import ServiceStatus, cleanup_own_pid, status, write_own_pid

    (LOGS_DIR).mkdir(parents=True, exist_ok=True)

    # For daemon mode, check for already running instance (skip if the PID is
    # ourself - happens when started via daemon.start() which writes our PID first)
    if daemon:
        info = status(SERVICE_NAME)
        if info.status == ServiceStatus.RUNNING and info.pid != os.getpid():
            log.error(
                "Worker is already running (PID %s). Stop it first with: otto service stop worker",
                info.pid,
            )
            return

        # Write our PID file (may already exist if started via daemon.start())
        write_own_pid(SERVICE_NAME)

    # Set up SIGHUP handler for config reload
    def _handle_sighup(signum, frame):
        log.info("Received SIGHUP, reloading configuration...")
        try:
            reload_config()
            log.info("Configuration reloaded successfully")
        except Exception as e:
            log.error("Config reload failed: %s", e)

    signal.signal(signal.SIGHUP, _handle_sighup)

    try:
        from otto.backends import get_orchestration_config

        orch_config = get_orchestration_config()
        concurrency = int(orch_config.get("worker_concurrency", 1))
        worker = Worker(worker_id=worker_id, concurrency=concurrency)
        if daemon:
            worker.run_daemon()
            return
        if once:
            worker.process_one()
            return
        worker.run_all()
    finally:
        # Clean up PID file if we wrote one
        if daemon:
            cleanup_own_pid(SERVICE_NAME)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Job queue worker")
    parser.add_argument("--daemon", action="store_true", help="Run forever")
    parser.add_argument("--once", action="store_true", help="Process one job only")
    parser.add_argument("--id", default=None, help="Worker ID")
    args = parser.parse_args()

    main(daemon=args.daemon, once=args.once, worker_id=args.id)
