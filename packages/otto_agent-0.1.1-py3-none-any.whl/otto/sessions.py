"""
Session management for Otto.

Sessions are organizational chapters, not isolation walls.
The agent can search across all sessions via the memory index.

Structure:
    ~/.otto/sessions/
    ├── active/           # Per-chat active sessions
    │   └── {chat_id}.json
    ├── archive/          # Past sessions (indexed for search)
    │   └── {id}.json
    └── current.json      # Legacy fallback (migrated on first access)
"""

import json
import logging
import re
import shutil
from datetime import datetime
from pathlib import Path

from filelock import FileLock

from .paths import OTTO_HOME

log = logging.getLogger(__name__)

OTTO_DIR = OTTO_HOME
SESSIONS_DIR = OTTO_DIR / "sessions"
ACTIVE_DIR = SESSIONS_DIR / "active"
ARCHIVE_DIR = SESSIONS_DIR / "archive"
CURRENT_FILE = SESSIONS_DIR / "current.json"  # Legacy fallback

# Default rolling window size
DEFAULT_MAX_MESSAGES = 50

# Default chat_id when none is provided (backward compat)
_DEFAULT_CHAT_ID = "_default"

# Auto-titling configuration
AUTO_TITLE_COUNT_THRESHOLD = 5  # Title after this many messages
AUTO_TITLE_GAP_THRESHOLD = 3  # Title after this many msgs if there's a time gap
AUTO_TITLE_GAP_SECONDS = 3600  # 1 hour gap = "return visit"
AUTO_TITLE_WINDOW = 15  # Use last N messages for title generation
AUTO_TITLE_REFRESH_START = 20  # First refresh point, then doubling (40, 80, 160...)


def _ensure_dirs():
    """Ensure session directories exist."""
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    ACTIVE_DIR.mkdir(exist_ok=True)
    ARCHIVE_DIR.mkdir(exist_ok=True)


def _chat_file(chat_id: str | None) -> Path:
    """Get the active session file for a chat_id."""
    cid = chat_id or _DEFAULT_CHAT_ID
    # Sanitize chat_id for use as filename
    safe = re.sub(r"[^\w\-.]", "_", str(cid))
    return ACTIVE_DIR / f"{safe}.json"


def _lock_for(path: Path) -> FileLock:
    """Get a file lock for a session file."""
    return FileLock(str(path) + ".lock", timeout=5)


def _slugify(text: str) -> str:
    """Convert text to a valid filename slug."""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[-\s]+", "-", text)
    return text[:50]  # Limit length


def _generate_session_id(topic: str | None = None) -> str:
    """Generate a unique session ID."""
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    if topic:
        return f"{timestamp}-{_slugify(topic)}"
    return timestamp


def _migrate_legacy(chat_id: str | None) -> dict | None:
    """Migrate legacy current.json to per-chat active file (one-time)."""
    if not CURRENT_FILE.exists():
        return None

    try:
        data = json.loads(CURRENT_FILE.read_text())
    except json.JSONDecodeError:
        log.warning("Corrupt legacy current.json, removing")
        CURRENT_FILE.unlink(missing_ok=True)
        return None

    if not data.get("messages"):
        CURRENT_FILE.unlink(missing_ok=True)
        return None

    # Save to active dir for this chat
    target = _chat_file(chat_id)
    lock = _lock_for(target)
    with lock:
        target.write_text(json.dumps(data, indent=2))

    # Remove legacy file
    CURRENT_FILE.unlink(missing_ok=True)
    log.info("Migrated legacy current.json -> %s", target.name)
    return data


def get_current_session(chat_id: str | None = None) -> dict:
    """
    Get the current session for a chat, creating one if needed.

    Args:
        chat_id: Chat/conversation ID (e.g. Telegram chat_id).
                 None falls back to a global default.

    Returns:
        Session dict with id, created, topic, messages, metadata
    """
    _ensure_dirs()

    target = _chat_file(chat_id)
    lock = _lock_for(target)

    with lock:
        if target.exists():
            try:
                return json.loads(target.read_text())
            except json.JSONDecodeError:
                log.warning("Corrupt session file %s, creating new session", target.name)

    # Try legacy migration (only if active file doesn't exist)
    migrated = _migrate_legacy(chat_id)
    if migrated:
        return migrated

    # Create new session
    return new_session(chat_id=chat_id, archive_current=False)


def new_session(
    topic: str | None = None,
    archive_current: bool = True,
    chat_id: str | None = None,
) -> dict:
    """
    Start a new session, optionally archiving the current one.

    Args:
        topic: Optional topic/name for the session
        archive_current: Whether to archive the current session first
        chat_id: Chat ID to scope this session to

    Returns:
        The new session dict
    """
    _ensure_dirs()

    target = _chat_file(chat_id)
    lock = _lock_for(target)

    with lock:
        # Archive current session if it exists and has messages
        if archive_current and target.exists():
            try:
                current = json.loads(target.read_text())
                if current.get("messages"):
                    archive_session(current)
            except (json.JSONDecodeError, KeyError):
                pass

        # Create new session
        session_id = _generate_session_id(topic)
        session = {
            "id": session_id,
            "created": datetime.now().isoformat(),
            "topic": topic,
            "messages": [],
            "metadata": {
                "last_backend": None,
                "message_count": 0,
                "chat_id": chat_id,
            },
        }

        target.write_text(json.dumps(session, indent=2))

    return session


def fork_session(
    topic: str | None = None,
    chat_id: str | None = None,
) -> dict:
    """
    Fork the current session into a new active session with copied messages.

    Args:
        topic: Optional topic/name for the new forked session
        chat_id: Chat ID to scope this session to

    Returns:
        The new (forked) session dict
    """
    _ensure_dirs()

    target = _chat_file(chat_id)
    lock = _lock_for(target)

    with lock:
        current = None
        if target.exists():
            try:
                current = json.loads(target.read_text())
            except json.JSONDecodeError:
                pass

        if current and current.get("messages"):
            archive_session(current)

            fork_topic = topic if topic is not None else current.get("topic")
            copied_messages = list(current.get("messages", []))
            session_id = _generate_session_id(fork_topic)
            session = {
                "id": session_id,
                "created": datetime.now().isoformat(),
                "topic": fork_topic,
                "messages": copied_messages,
                "metadata": {
                    "last_backend": current.get("metadata", {}).get("last_backend"),
                    "message_count": current.get("metadata", {}).get(
                        "message_count", len(copied_messages)
                    ),
                    "chat_id": chat_id,
                    "forked_from": current.get("id"),
                },
            }

            target.write_text(json.dumps(session, indent=2))
            return session

    return new_session(topic=topic, archive_current=True, chat_id=chat_id)


def _save_current(session: dict, chat_id: str | None = None):
    """Save session to the active file for this chat."""
    _ensure_dirs()
    target = _chat_file(chat_id)
    lock = _lock_for(target)
    with lock:
        target.write_text(json.dumps(session, indent=2))


def add_message(
    role: str,
    content: str,
    backend: str | None = None,
    max_messages: int = DEFAULT_MAX_MESSAGES,
    chat_id: str | None = None,
    ephemeral: bool = False,
) -> dict:
    """
    Add a message to the current session.

    Args:
        role: 'user' or 'assistant'
        content: Message content
        backend: Which backend generated this (for assistant messages)
        max_messages: Rolling window size
        chat_id: Chat ID to scope to
        ephemeral: If True, message is excluded from LLM context (e.g. cross-session notifications)

    Returns:
        Updated session dict
    """
    _ensure_dirs()
    target = _chat_file(chat_id)
    lock = _lock_for(target)

    with lock:
        # Read current session under lock
        session = None
        if target.exists():
            try:
                session = json.loads(target.read_text())
            except json.JSONDecodeError:
                log.warning("Corrupt session %s during add_message, creating new", target.name)

        if session is None:
            session = {
                "id": _generate_session_id(),
                "created": datetime.now().isoformat(),
                "topic": None,
                "messages": [],
                "metadata": {"last_backend": None, "message_count": 0, "chat_id": chat_id},
            }
            log.info("Created new session for chat %s (was missing/corrupt)", chat_id)

        message = {
            "role": role,
            "content": content,
            "ts": datetime.now().isoformat(),
        }
        if backend:
            message["backend"] = backend
        if ephemeral:
            message["ephemeral"] = True

        session["messages"].append(message)
        # Track total messages ever sent (not just what's in the window)
        session["metadata"]["message_count"] = session["metadata"].get("message_count", 0) + 1
        session["metadata"]["last_backend"] = backend or session["metadata"].get("last_backend")

        # Apply rolling window
        if len(session["messages"]) > max_messages:
            session["messages"] = session["messages"][-max_messages:]

        target.write_text(json.dumps(session, indent=2))

    return session


def get_messages(
    limit: int | None = None,
    chat_id: str | None = None,
    include_ephemeral: bool = True,
) -> list[dict]:
    """
    Get messages from current session.

    Args:
        limit: Max messages to return (most recent)
        chat_id: Chat ID to scope to
        include_ephemeral: If False, exclude ephemeral messages (cross-session notifications)

    Returns:
        List of message dicts
    """
    session = get_current_session(chat_id=chat_id)
    messages = session.get("messages", [])

    if not include_ephemeral:
        messages = [m for m in messages if not m.get("ephemeral")]

    if limit and len(messages) > limit:
        return messages[-limit:]
    return messages


def archive_session(session: dict | None = None, chat_id: str | None = None) -> str | None:
    """
    Archive a session.

    Args:
        session: Session to archive (defaults to current for chat_id)
        chat_id: Chat ID to scope to (only used when session is None)

    Returns:
        Archive filename or None if nothing to archive
    """
    _ensure_dirs()

    if session is None:
        target = _chat_file(chat_id)
        if not target.exists():
            return None
        lock = _lock_for(target)
        with lock:
            try:
                session = json.loads(target.read_text())
            except json.JSONDecodeError:
                return None

    if not session.get("messages"):
        return None

    # Add archive metadata
    session["archived"] = datetime.now().isoformat()

    # Save to archive
    archive_file = ARCHIVE_DIR / f"{session['id']}.json"
    archive_file.write_text(json.dumps(session, indent=2))

    return archive_file.name


def _last_activity(session: dict) -> str | None:
    """Get the timestamp of the most recent message, or fall back to created."""
    messages = session.get("messages", [])
    if messages:
        # Walk backwards to find the last message with a timestamp
        for msg in reversed(messages):
            ts = msg.get("ts")
            if ts:
                return ts
    return session.get("created")


def list_sessions(include_current: bool = True, chat_id: str | None = None) -> list[dict]:
    """
    List all sessions (current + archived) for a chat.

    Args:
        include_current: Whether to include the active session
        chat_id: Chat ID to scope to

    Returns:
        List of session summaries sorted by last activity (most recent first)
    """
    _ensure_dirs()
    sessions = []

    # Current session for this chat
    if include_current:
        target = _chat_file(chat_id)
        if target.exists():
            lock = _lock_for(target)
            with lock:
                try:
                    current = json.loads(target.read_text())
                    sessions.append(
                        {
                            "id": current.get("id", "current"),
                            "topic": current.get("topic"),
                            "created": current.get("created"),
                            "last_activity": _last_activity(current),
                            "message_count": current.get("metadata", {}).get(
                                "message_count", len(current.get("messages", []))
                            ),
                            "is_current": True,
                        }
                    )
                except json.JSONDecodeError:
                    pass

    # Archived sessions (shared across all chats)
    for archive_file in ARCHIVE_DIR.glob("*.json"):
        try:
            session = json.loads(archive_file.read_text())
            sessions.append(
                {
                    "id": session.get("id", archive_file.stem),
                    "topic": session.get("topic"),
                    "created": session.get("created"),
                    "last_activity": _last_activity(session),
                    "archived": session.get("archived"),
                    "message_count": session.get("metadata", {}).get(
                        "message_count", len(session.get("messages", []))
                    ),
                    "is_current": False,
                }
            )
        except json.JSONDecodeError:
            continue

    # Sort by last activity (most recent first), current session always on top
    sessions.sort(
        key=lambda s: (
            not s.get("is_current"),
            -(
                datetime.fromisoformat(s["last_activity"]).timestamp()
                if s.get("last_activity")
                else 0
            ),
        ),
    )

    return sessions


def delete_session(session_id: str) -> bool:
    """
    Delete an archived session.

    Args:
        session_id: Session ID to delete

    Returns:
        True if deleted, False if not found
    """
    _ensure_dirs()
    archive_file = ARCHIVE_DIR / f"{session_id}.json"
    if archive_file.exists():
        archive_file.unlink()
        return True
    return False


def load_session(session_id: str, chat_id: str | None = None) -> dict | None:
    """
    Load a session by ID (makes it current for this chat).

    Args:
        session_id: Session ID to load
        chat_id: Chat ID to scope to

    Returns:
        Session dict or None if not found
    """
    _ensure_dirs()

    # Check archive
    archive_file = ARCHIVE_DIR / f"{session_id}.json"
    if archive_file.exists():
        session = json.loads(archive_file.read_text())

        # Archive current first
        target = _chat_file(chat_id)
        lock = _lock_for(target)
        with lock:
            if target.exists():
                try:
                    current = json.loads(target.read_text())
                    if current.get("messages") and current.get("id") != session_id:
                        archive_session(current)
                except json.JSONDecodeError:
                    pass

            # Remove archived timestamp (it's active again)
            session.pop("archived", None)

            # Save as current
            target.write_text(json.dumps(session, indent=2))

        # Remove from archive
        archive_file.unlink()

        return session

    return None


def update_session_topic(topic: str, chat_id: str | None = None) -> dict:
    """
    Update the topic of the current session.

    Args:
        topic: New topic for the session
        chat_id: Chat ID to scope to

    Returns:
        Updated session dict
    """
    session = get_current_session(chat_id=chat_id)
    session["topic"] = topic
    _save_current(session, chat_id=chat_id)
    return session


def get_session_for_prompt(max_messages: int = 20, chat_id: str | None = None) -> str:
    """
    Get session context formatted for inclusion in prompts.

    Excludes ephemeral messages (cross-session notifications) from LLM context.

    Args:
        max_messages: Max recent messages to include
        chat_id: Chat ID to scope to

    Returns:
        Formatted conversation history
    """
    messages = get_messages(limit=max_messages, chat_id=chat_id, include_ephemeral=False)
    if not messages:
        return ""

    lines = ["Recent conversation:"]
    for msg in messages:
        role = msg.get("role", "unknown")
        content = msg.get("content", "")[:2000]  # Truncate long messages
        backend = msg.get("backend", "")

        prefix = "User" if role == "user" else "Otto"
        if backend and role == "assistant":
            prefix = f"Otto ({backend})"

        lines.append(f"{prefix}: {content}")

    return "\n".join(lines)


def _has_time_gap(messages: list[dict], gap_seconds: int = AUTO_TITLE_GAP_SECONDS) -> bool:
    """Check if there's a significant time gap between any two consecutive messages.

    This detects "return visits" — user left and came back.
    """
    if len(messages) < 2:
        return False

    for i in range(1, len(messages)):
        prev_ts = messages[i - 1].get("ts")
        curr_ts = messages[i].get("ts")
        if not prev_ts or not curr_ts:
            continue
        try:
            prev_dt = datetime.fromisoformat(prev_ts)
            curr_dt = datetime.fromisoformat(curr_ts)
            if (curr_dt - prev_dt).total_seconds() >= gap_seconds:
                return True
        except (ValueError, TypeError):
            continue
    return False


def _should_auto_title(
    message_count: int, messages: list[dict] | None = None, has_title: bool = False
) -> bool:
    """Check if we should generate/update the title at this message count.

    Triggers:
    1. 5+ messages (enough context for a meaningful title)
    2. 3+ messages AND time gap > 1hr (return visit = intent to continue)
    3. Refresh at 20, 40, 80, 160... (doubling intervals for long sessions)
    """
    # Already titled — only refresh at doubling schedule
    if has_title:
        threshold = AUTO_TITLE_REFRESH_START
        while threshold <= message_count:
            if message_count == threshold:
                return True
            threshold *= 2
        return False

    # Not yet titled — check initial triggers
    if message_count >= AUTO_TITLE_COUNT_THRESHOLD:
        return True

    if message_count >= AUTO_TITLE_GAP_THRESHOLD and messages and _has_time_gap(messages):
        return True

    return False


async def _generate_title(messages: list[dict]) -> str | None:
    """Generate a short title from recent messages using the LLM backend.

    Returns a short title string or None on failure.
    """
    # Build a compact summary of recent messages for the LLM
    lines = []
    for m in messages[-AUTO_TITLE_WINDOW:]:
        role = "User" if m["role"] == "user" else "Otto"
        # Keep messages short for the title prompt
        content = m.get("content", "")[:200]
        lines.append(f"{role}: {content}")

    conversation_snippet = "\n".join(lines)

    prompt = (
        "Generate a very short title (3-6 words, no quotes) summarizing this conversation. "
        "Focus on the main topic or activity. Examples: 'PDF Skill Testing', "
        "'MCP Gateway Setup', 'Session Isolation Testing'.\n\n"
        f"Conversation:\n{conversation_snippet}\n\nTitle:"
    )

    try:
        from otto import get_backend
        from otto.backends import get_backend_model
        from otto.paths import get_workdir

        backend = get_backend()
        model = get_backend_model(backend.config.name)
        result = await backend.run_async(
            prompt,
            "You generate ultra-short conversation titles. Reply with ONLY the title, nothing else.",
            get_workdir(),
            timeout=30,
            model=model,
        )
        if result.success and result.output:
            # Clean up: strip quotes, whitespace, limit length
            title = result.output.strip().strip("\"'").strip()
            # Take first line only (in case LLM is chatty)
            title = title.split("\n")[0].strip()
            if len(title) > 60:
                title = title[:57] + "..."
            return title if title else None
        return None
    except Exception as e:
        log.warning("Auto-title generation failed: %s", e)
        return None


async def maybe_auto_title(chat_id: str | None = None, force: bool = False) -> str | None:
    """Check if the current session needs a title update and generate one.

    Called after add_message or before session exit. Returns the new title or None.

    Args:
        chat_id: Chat ID to scope to
        force: If True, skip schedule check and generate title if untitled and has messages
    """
    target = _chat_file(chat_id)
    if not target.exists():
        return None

    lock = _lock_for(target)
    with lock:
        try:
            session = json.loads(target.read_text())
        except (json.JSONDecodeError, FileNotFoundError):
            return None

    count = session.get("metadata", {}).get("message_count", 0)
    messages = session.get("messages", [])
    has_title = bool(session.get("topic"))

    if not messages:
        return None

    # Force mode: title untitled sessions on exit (need at least 2 messages)
    if force:
        if has_title or count < 2:
            return None
    elif not _should_auto_title(count, messages=messages, has_title=has_title):
        return None

    title = await _generate_title(messages)
    if not title:
        return None

    # Update the session topic
    with lock:
        try:
            session = json.loads(target.read_text())
            session["topic"] = title
            target.write_text(json.dumps(session, indent=2))
            log.info("Auto-titled session (count=%d, force=%s): %s", count, force, title)
            return title
        except Exception as e:
            log.warning("Failed to save auto-title: %s", e)
            return None


def migrate_from_conversation_json(old_path: Path) -> bool:
    """
    Migrate from old conversation.json format to new session format.

    Args:
        old_path: Path to old conversation.json

    Returns:
        True if migration succeeded
    """
    if not old_path.exists():
        return False

    try:
        old_data = json.loads(old_path.read_text())
        messages = old_data if isinstance(old_data, list) else old_data.get("messages", [])

        if not messages:
            return False

        # Create session from old messages
        session = {
            "id": _generate_session_id("migrated"),
            "created": datetime.now().isoformat(),
            "topic": "Migrated from conversation.json",
            "messages": [],
            "metadata": {"migrated_from": str(old_path), "message_count": 0},
        }

        # Convert messages
        for msg in messages:
            session["messages"].append(
                {
                    "role": msg.get("role", "user"),
                    "content": msg.get("content", ""),
                    "ts": msg.get("ts", msg.get("timestamp", datetime.now().isoformat())),
                }
            )

        session["metadata"]["message_count"] = len(session["messages"])

        _save_current(session)

        # Backup old file
        backup_path = old_path.with_suffix(".json.bak")
        shutil.move(old_path, backup_path)

        return True

    except (json.JSONDecodeError, KeyError):
        return False
