"""
Streaming infrastructure for progressive message updates.

This module provides real-time streaming of AI responses with platform-specific
rendering. For Telegram, we edit messages in-place with rate-limit aware debouncing.

Usage:
    handler = TelegramStreamHandler(platform, chat_id)

    async for event in stream_events():
        await handler.handle(event)

    await handler.finalize()

StreamEvent Types:
    - THINKING: Model is reasoning (buffered, not displayed)
    - TOOL_USE: Tool invocation started (triggers tool message)
    - TOOL_RESULT: Tool completed (updates tool message)
    - TEXT_DELTA: Incremental text chunk
    - TEXT_COMPLETE: Final text ready
    - DONE: Stream finished

Telegram Display Flow:
    1. Events buffered silently until first TOOL_USE
    2. On first tool: send message with optional intent header + tool list
    3. On subsequent tools: update message to show all tools
    4. On finalize:
       - If no tools: just send response (no intermediate message)
       - If tools: update to "{N} tool calls completed", send response as new message
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Protocol, runtime_checkable

log = logging.getLogger(__name__)


_ALLOWED_TELEGRAM_HTML_TAG_RE = re.compile(
    r"<\s*(/?)\s*(b|i|code|pre)\s*>",
    flags=re.IGNORECASE,
)
_AMPERSAND_NOT_ENTITY_RE = re.compile(r"&(?!(#\d+|#x[0-9A-Fa-f]+|[A-Za-z][A-Za-z0-9]+);)")


def sanitize_telegram_html(text: str) -> str:
    """Escape unsupported Telegram HTML while preserving a small allowlist of tags.

    Telegram rejects messages that contain unknown/unsupported tags such as HTML comments
    (e.g. <!-- ... -->) or prompt markers (e.g. <recent_conversation>).

    We preserve only: <b>, <i>, <code>, <pre> (and their closing tags). Everything else is escaped.
    """
    if not text:
        return text

    preserved: list[str] = []

    def _preserve_tag(match: re.Match) -> str:
        token = f"[[OTTO_TG_TAG_{len(preserved)}]]"
        closing = match.group(1) or ""
        tag = (match.group(2) or "").lower()
        preserved.append(f"<{closing}{tag}>")
        return token

    # Temporarily remove allowed tags so we can safely escape everything else.
    interim = _ALLOWED_TELEGRAM_HTML_TAG_RE.sub(_preserve_tag, text)

    # Escape &, <, > in the remaining text. Keep existing entities like &lt; intact.
    interim = _AMPERSAND_NOT_ENTITY_RE.sub("&amp;", interim)
    interim = interim.replace("<", "&lt;").replace(">", "&gt;")

    # Restore allowed tags.
    for i, tag in enumerate(preserved):
        interim = interim.replace(f"[[OTTO_TG_TAG_{i}]]", tag)

    # Close any unclosed allowed tags (prevents Telegram parse errors).
    open_stack: list[str] = []
    for m in re.finditer(r"<(/?)([a-z]+)>", interim):
        closing, tag = m.group(1), m.group(2)
        if tag not in ("b", "i", "code", "pre"):
            continue
        if closing:
            # Pop matching open tag (if any)
            for j in range(len(open_stack) - 1, -1, -1):
                if open_stack[j] == tag:
                    open_stack.pop(j)
                    break
        else:
            open_stack.append(tag)

    # Close remaining open tags in reverse order
    for tag in reversed(open_stack):
        interim += f"</{tag}>"

    return interim


# Pattern: mcp__server__tool or server__tool (gateway proxy format)
_MCP_TOOL_NAME_RE = re.compile(r"^(?:mcp__)?([^_](?:[^_]|_(?!_))*)__(.+)$")


def format_tool_name(raw_name: str) -> str:
    """Format a raw tool name for clean display.

    Transforms MCP-namespaced names into readable form:
      - ``mcp__otto-gateway__context7__query-docs`` -> ``context7: query-docs``
      - ``mcp__otto-gateway__memory_recall`` -> ``memory_recall``
      - ``otto-gateway__notify_send`` -> ``notify_send``
      - ``Read`` / ``Bash`` -> unchanged

    For gateway-proxied tools (server name is ``otto-gateway``), we strip the
    gateway prefix and show just the underlying server:tool.  If the remaining
    part itself contains ``__`` (a sub-server), we split once more so the
    deepest server becomes the display prefix.
    """
    m = _MCP_TOOL_NAME_RE.match(raw_name)
    if not m:
        return raw_name  # native tool like Read, Bash, etc.

    server, tool = m.group(1), m.group(2)

    # Strip gateway prefix: mcp__otto-gateway__<rest> -> <rest>
    if server == "otto-gateway":
        # rest may be "context7__query-docs" or just "notify_send"
        inner = _MCP_TOOL_NAME_RE.match(tool)
        if inner:
            return f"{inner.group(1)}: {inner.group(2)}"
        return tool

    return f"{server}: {tool}"


class StreamEventType(Enum):
    """Types of streaming events."""

    THINKING = auto()  # Model is reasoning
    TOOL_USE = auto()  # Tool invocation started
    TOOL_RESULT = auto()  # Tool completed
    TEXT_DELTA = auto()  # Incremental text chunk
    TEXT_COMPLETE = auto()  # Final text ready
    DONE = auto()  # Stream finished
    ERROR = auto()  # Error occurred


@dataclass
class StreamEvent:
    """
    A streaming event from the AI backend.

    Attributes:
        type: Event type (THINKING, TEXT_DELTA, etc.)
        content: Text content (for TEXT_DELTA, TEXT_COMPLETE)
        tool_name: Tool being used (for TOOL_USE, TOOL_RESULT)
        tool_input: Tool input data (for TOOL_USE)
        tool_output: Tool result (for TOOL_RESULT)
        error: Error message (for ERROR type)
        metadata: Additional event-specific data
    """

    type: StreamEventType
    content: str = ""
    tool_name: str | None = None
    tool_input: dict[str, Any] | None = None
    tool_output: str | None = None
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)

    @classmethod
    def thinking(cls, content: str = "") -> StreamEvent:
        """Create a THINKING event."""
        return cls(type=StreamEventType.THINKING, content=content)

    @classmethod
    def tool_use(cls, tool_name: str, tool_input: dict[str, Any] | None = None) -> StreamEvent:
        """Create a TOOL_USE event."""
        return cls(type=StreamEventType.TOOL_USE, tool_name=tool_name, tool_input=tool_input)

    @classmethod
    def tool_result(cls, tool_name: str, tool_output: str) -> StreamEvent:
        """Create a TOOL_RESULT event."""
        return cls(type=StreamEventType.TOOL_RESULT, tool_name=tool_name, tool_output=tool_output)

    @classmethod
    def text_delta(cls, content: str) -> StreamEvent:
        """Create a TEXT_DELTA event."""
        return cls(type=StreamEventType.TEXT_DELTA, content=content)

    @classmethod
    def text_complete(cls, content: str) -> StreamEvent:
        """Create a TEXT_COMPLETE event."""
        return cls(type=StreamEventType.TEXT_COMPLETE, content=content)

    @classmethod
    def done(cls) -> StreamEvent:
        """Create a DONE event."""
        return cls(type=StreamEventType.DONE)

    @classmethod
    def error(cls, message: str) -> StreamEvent:
        """Create an ERROR event."""
        return cls(type=StreamEventType.ERROR, error=message)


@dataclass
class StreamBuffer:
    """
    Accumulates streaming content with change detection.

    Tracks text content and tool invocations, providing methods to detect
    when content has meaningfully changed (for debounced UI updates).

    Attributes:
        text: Accumulated text content (all text concatenated)
        text_blocks: Separate text blocks (for extracting final answer)
        tools: List of tool invocations (name, status)
        is_thinking: Whether model is in thinking phase
        is_complete: Whether stream has finished
        initial_text: Text captured before first tool use (for tools_only mode)
    """

    text: str = ""
    text_blocks: list[str] = field(default_factory=list)  # Separate text blocks
    tools: list[dict[str, Any]] = field(default_factory=list)
    is_thinking: bool = False
    is_complete: bool = False
    error: str | None = None
    initial_text: str = ""  # Text before first tool use
    _tools_started: bool = False  # Track if tools have started
    _start_new_block: bool = True  # Next text starts a new block

    _last_rendered: str = ""
    _last_render_time: float = 0.0

    def append_text(self, content: str) -> None:
        """Append text content."""
        self.text += content

        # Track text blocks separately
        if self._start_new_block or not self.text_blocks:
            self.text_blocks.append(content)
            self._start_new_block = False
        else:
            # Append to current block
            self.text_blocks[-1] += content

    def set_text(self, content: str) -> None:
        """Set the complete text content (e.g., from TEXT_COMPLETE event).

        When this replaces the entire buffer, treat as single final block.
        """
        self.text = content
        self.is_complete = True
        # TEXT_COMPLETE replaces everything - this IS the final answer
        self.text_blocks = [content]

    def add_tool_use(self, tool_name: str, tool_input: dict[str, Any] | None = None) -> None:
        """Record a tool invocation."""
        # Capture text before first tool as initial_text
        if not self._tools_started and self.text.strip():
            self.initial_text = self.text.strip()
        self._tools_started = True

        # Next text after this tool starts a new block
        self._start_new_block = True

        self.tools.append(
            {
                "name": tool_name,
                "input": tool_input,
                "status": "running",
                "started_at": time.time(),
            }
        )

    def complete_tool(self, tool_name: str, output: str | None = None) -> None:
        """Mark a tool as completed."""
        for tool in reversed(self.tools):
            if tool["name"] == tool_name and tool["status"] == "running":
                tool["status"] = "completed"
                tool["output"] = output
                tool["completed_at"] = time.time()
                # Next text after tool completion starts a new block
                self._start_new_block = True
                break

    def get_final_text(self) -> str:
        """Get the final text block (the actual answer after tools).

        Returns the last text block, which should be the final response
        after all tool usage is complete.
        """
        if self.text_blocks:
            return self.text_blocks[-1].strip()
        return self.text.strip()

    def has_meaningful_change(self, min_chars: int = 50, min_interval: float = 0.5) -> bool:
        """
        Check if buffer has changed enough to warrant a UI update.

        Args:
            min_chars: Minimum new characters before update
            min_interval: Minimum seconds between updates

        Returns:
            True if content should be re-rendered
        """
        now = time.time()

        # Always update if complete or error
        if self.is_complete or self.error:
            return True

        # Respect minimum interval
        if now - self._last_render_time < min_interval:
            return False

        # Check for meaningful text change
        new_chars = len(self.text) - len(self._last_rendered)
        if new_chars >= min_chars:
            return True

        # Check for new tool activity
        running_tools = sum(1 for t in self.tools if t["status"] == "running")
        if running_tools > 0:
            return True

        return False

    def mark_rendered(self) -> None:
        """Mark current state as rendered."""
        self._last_rendered = self.text
        self._last_render_time = time.time()

    def render(self, include_status: bool = True, tools_only: bool = False) -> str:
        """
        Render buffer content for display.

        Args:
            include_status: Whether to include thinking/tool status indicators
            tools_only: If True, only show tool names during processing (no narration text)

        Returns:
            Formatted string for display
        """
        parts = []

        # Status indicator with emojis for visual feedback
        # In tools_only mode, skip status line - we show tool list below instead
        if include_status and not tools_only:
            if self.is_thinking:
                parts.append("\U0001f914 <i>Thinking...</i>\n\n")
            elif self.tools and any(t["status"] == "running" for t in self.tools):
                running = [
                    format_tool_name(t["name"]) for t in self.tools if t["status"] == "running"
                ]
                parts.append(f"\U0001f527 <i>Using: {', '.join(running)}...</i>\n\n")

        # In tools_only mode during processing, show tool list + initial text
        if tools_only and not self.is_complete and self.tools:
            # Show compact tool list: 🔧 Tool1, Tool2, Tool3...
            tool_names = [format_tool_name(t["name"]) for t in self.tools]
            # Dedupe consecutive same tools
            deduped = []
            for name in tool_names:
                if not deduped or deduped[-1] != name:
                    deduped.append(name)
            if deduped:
                parts.append(f"🔧 <i>{', '.join(deduped)}...</i>")
            # Show initial text below tools (the "Got it, I'll..." intro)
            if self.initial_text:
                parts.append(f"\n\n{self.initial_text}")
        elif self.text:
            # Main text content (always show when complete or not in tools_only mode)
            parts.append(self.text)

        # Error
        if self.error:
            parts.append(f"\n\n<b>Error:</b> {self.error}")

        # Incomplete indicator (only if we have text and not in tools_only mode)
        if not self.is_complete and self.text and not tools_only:
            parts.append("...")

        return "".join(parts)


@runtime_checkable
class StreamHandlerProtocol(Protocol):
    """Protocol for stream handlers."""

    async def handle(self, event: StreamEvent) -> None:
        """Handle a streaming event."""
        ...

    async def finalize(self) -> None:
        """Finalize the stream (send final message, cleanup)."""
        ...


class BaseStreamHandler(ABC):
    """
    Abstract base class for platform-specific stream handlers.

    Subclasses implement platform-specific rendering and rate limiting.
    """

    def __init__(self):
        self.buffer = StreamBuffer()
        self._started = False
        self._finalized = False

    @abstractmethod
    async def handle(self, event: StreamEvent) -> None:
        """Handle a streaming event."""
        pass

    @abstractmethod
    async def finalize(self) -> None:
        """Finalize the stream."""
        pass

    async def _handle_event(self, event: StreamEvent) -> None:
        """Process event and update buffer."""
        match event.type:
            case StreamEventType.THINKING:
                self.buffer.is_thinking = True
                if event.content:
                    self.buffer.append_text(event.content)

            case StreamEventType.TOOL_USE:
                self.buffer.is_thinking = False
                if event.tool_name:
                    self.buffer.add_tool_use(event.tool_name, event.tool_input)

            case StreamEventType.TOOL_RESULT:
                if event.tool_name:
                    self.buffer.complete_tool(event.tool_name, event.tool_output)

            case StreamEventType.TEXT_DELTA:
                self.buffer.is_thinking = False
                self.buffer.append_text(event.content)

            case StreamEventType.TEXT_COMPLETE:
                self.buffer.is_thinking = False
                self.buffer.set_text(event.content)

            case StreamEventType.DONE:
                self.buffer.is_complete = True

            case StreamEventType.ERROR:
                self.buffer.error = event.error
                self.buffer.is_complete = True


class TelegramStreamHandler(BaseStreamHandler):
    """
    Stream handler for Telegram with edit-in-place support.

    Features:
    - Waits silently until first tool use (no awkward "Thinking..." message)
    - Shows intent message (text before tools) as header if present
    - Shows tools accumulating below the intent
    - Edits message in-place as tools progress
    - Sends final response as a new message
    - Updates tool message to "{N} tool calls completed" summary

    Attributes:
        platform: TelegramPlatform instance
        chat_id: Target chat ID
        message_id: ID of the message being edited
        min_update_interval: Minimum seconds between edits (default: 1.0)
        min_chars_delta: Minimum new chars before update (default: 100)
        keep_thinking_message: Whether to keep the tool message after completion
    """

    # Telegram rate limit: ~30 messages per second to same chat
    # But for edits to same message, be more conservative
    DEFAULT_MIN_INTERVAL = 1.0
    DEFAULT_MIN_CHARS = 100

    def __init__(
        self,
        platform: Any,  # TelegramPlatform
        chat_id: str,
        min_update_interval: float = DEFAULT_MIN_INTERVAL,
        min_chars_delta: int = DEFAULT_MIN_CHARS,
        keep_thinking_message: bool = True,
        show_thinking: bool = True,
        tools_only: bool = False,
    ):
        super().__init__()
        self.platform = platform
        self.chat_id = chat_id
        self.message_id: str | None = None
        self.min_update_interval = min_update_interval
        self.min_chars_delta = min_chars_delta
        self.keep_thinking_message = keep_thinking_message
        self.show_thinking = show_thinking
        self.tools_only = tools_only

        self._update_task: asyncio.Task | None = None
        self._pending_update = False
        self._lock = asyncio.Lock()
        self._final_message_id: str | None = None
        self._intent_text: str = ""  # Text captured before first tool

    async def handle(self, event: StreamEvent) -> None:
        """Handle a streaming event with debounced updates.

        Flow:
        - Accumulate events silently until first TOOL_USE
        - On first tool: send message with optional intent header + tool list
        - On subsequent tools: update the message
        - If no tools ever used: skip intermediate message entirely
        """
        await self._handle_event(event)

        # Skip ALL intermediate messages if show_thinking is False
        # We'll just send one final message in finalize()
        if not self.show_thinking:
            return

        # Only react to TOOL_USE events for sending/updating the tool message
        if event.type == StreamEventType.TOOL_USE:
            if not self._started:
                # First tool! Capture any text before this as intent
                self._intent_text = self.buffer.initial_text
                await self._send_tool_message()
                self._started = True
            else:
                # Additional tool, schedule update
                await self._schedule_update()
        elif event.type == StreamEventType.TOOL_RESULT and self._started:
            # Tool completed, update to show status
            await self._schedule_update()

    TELEGRAM_MAX_MESSAGE_LENGTH = 4096

    @staticmethod
    def _chunk_text(text: str, max_len: int = 4096) -> list[str]:
        """Split text into chunks at natural boundaries."""
        if len(text) <= max_len:
            return [text]

        chunks: list[str] = []
        while text:
            if len(text) <= max_len:
                chunks.append(text)
                break

            chunk = text[:max_len]

            # Try to break at newline
            last_newline = chunk.rfind("\n")
            if last_newline > max_len / 2:
                chunk = text[:last_newline]
                text = text[last_newline + 1 :]
            else:
                # Break at space
                last_space = chunk.rfind(" ")
                if last_space > max_len / 2:
                    chunk = text[:last_space]
                    text = text[last_space + 1 :]
                else:
                    text = text[max_len:]

            chunks.append(chunk.strip())

        return chunks

    async def _send_safe(self, text: str) -> str | None:
        """Send text to Telegram with chunking and HTML fallback.

        Returns message_id of the last sent message, or None on total failure.
        """
        chunks = self._chunk_text(text, self.TELEGRAM_MAX_MESSAGE_LENGTH)
        last_msg_id: str | None = None

        for chunk in chunks:
            if not chunk.strip():
                continue
            try:
                msg = await self.platform.send_message(self.chat_id, chunk)
                last_msg_id = str(msg.message_id)
            except Exception as e:
                if "can't parse entities" in str(e).lower():
                    # Strip HTML and retry as plain text
                    plain = re.sub(r"<[^>]+>", "", chunk)
                    try:
                        msg = await self.platform.send_message(self.chat_id, plain)
                        last_msg_id = str(msg.message_id)
                    except Exception as e2:
                        log.error("Failed to send chunk even as plain text: %s", e2)
                else:
                    log.error("Failed to send chunk: %s", e)

        return last_msg_id

    async def finalize(self) -> None:
        """Send final response as a NEW message, update tool message to summary."""
        if self._finalized:
            return

        self._finalized = True

        # Cancel any pending update
        if self._update_task and not self._update_task.done():
            self._update_task.cancel()
            try:
                await self._update_task
            except asyncio.CancelledError:
                pass

        self.buffer.is_complete = True

        # Get final content (without status indicators)
        # In tools_only mode, only show the last text block (the actual answer)
        log.debug(
            "finalize: tools_only=%s, num_tools=%d, num_text_blocks=%d, text_len=%d",
            self.tools_only,
            len(self.buffer.tools),
            len(self.buffer.text_blocks),
            len(self.buffer.text),
        )
        if self.tools_only and self.buffer.tools:
            content = self.buffer.get_final_text()
            log.debug("Using get_final_text(), got %d chars", len(content))
        else:
            content = self.buffer.render(include_status=False)
            log.debug("Using render(), got %d chars", len(content))
        if not content.strip():
            return
        content = sanitize_telegram_html(content)

        # If thinking display is off OR no tools were used, just send the final message
        # (no tool message was created, so nothing to update)
        if not self.show_thinking or not self._started:
            self._final_message_id = await self._send_safe(content)
            if self._final_message_id:
                log.debug("Sent final message (no tool message): %s", self._final_message_id)
            return

        # Send final response as a NEW message
        self._final_message_id = await self._send_safe(content)
        if not self._final_message_id:
            log.error("Failed to send final streaming message via _send_safe")
            return

        # Update the tool message to show completion summary
        if self.message_id:
            try:
                if self.keep_thinking_message:
                    # Build summary: keep intent (if any) + tool count
                    num_tools = len(self.buffer.tools)
                    tool_word = "tool call" if num_tools == 1 else "tool calls"
                    summary_parts = []

                    # Keep the intent message if we had one
                    if self._intent_text:
                        summary_parts.append(self._intent_text)
                        summary_parts.append("")  # blank line

                    summary_parts.append(f"<i>{num_tools} {tool_word} completed</i>")

                    await self.platform.edit_message(
                        self.chat_id,
                        self.message_id,
                        sanitize_telegram_html("\n".join(summary_parts)),
                    )
                else:
                    # Delete the tool message
                    await self.platform.delete_message(self.chat_id, self.message_id)
            except Exception as e:
                # Non-fatal - the final message was sent successfully
                log.debug("Could not update/delete tool message: %s", e)

    async def _send_tool_message(self) -> None:
        """Send the tool progress message.

        Format:
            [Intent text if present]

            🔧 tool_name
            🔧 another_tool (running...)
        """
        content = self._render_tool_progress()
        content = sanitize_telegram_html(content)

        try:
            msg = await self.platform.send_message(self.chat_id, content)
            self.message_id = str(msg.message_id)
            self.buffer.mark_rendered()
            log.debug("Sent tool progress message: %s", self.message_id)
        except Exception as e:
            log.error("Failed to send tool progress message: %s", e)
            self.buffer.error = f"Failed to send tool message: {e}"

    def _render_tool_progress(self) -> str:
        """Render the tool progress message.

        Shows:
        - Intent text (if any) as header
        - Only the currently running tool (not the full history)
        """
        parts = []

        # Intent header (text that came before first tool)
        if self._intent_text:
            parts.append(self._intent_text)
            parts.append("")  # blank line

        # Show only the currently running tool
        running_tools = [t for t in self.buffer.tools if t["status"] == "running"]
        if running_tools:
            # Show the most recent running tool
            current = running_tools[-1]
            parts.append(f"🔧 <i>{format_tool_name(current['name'])}...</i>")
        elif self.buffer.tools:
            # All tools completed, show the last one without ellipsis
            last = self.buffer.tools[-1]
            parts.append(f"🔧 <i>{format_tool_name(last['name'])}</i>")

        return "\n".join(parts)

    async def _schedule_update(self) -> None:
        """Schedule a debounced update."""
        async with self._lock:
            self._pending_update = True

            # If no update task running, start one
            if self._update_task is None or self._update_task.done():
                self._update_task = asyncio.create_task(self._update_loop())

    async def _update_loop(self) -> None:
        """Background loop for debounced updates."""
        while self._pending_update and not self._finalized:
            self._pending_update = False

            # Check if update is warranted
            if self.buffer.has_meaningful_change(
                min_chars=self.min_chars_delta,
                min_interval=self.min_update_interval,
            ):
                await self._do_update()

            # Wait before checking again
            await asyncio.sleep(self.min_update_interval)

    async def _do_update(self, final: bool = False) -> None:
        """Perform the actual message edit."""
        if not self.message_id:
            return

        # Use our tool progress renderer for intermediate updates
        if final:
            content = self.buffer.render(include_status=False)
        else:
            content = self._render_tool_progress()

        if not content.strip():
            return
        content = sanitize_telegram_html(content)

        try:
            await self.platform.edit_message(
                self.chat_id,
                self.message_id,
                content,
            )
            self.buffer.mark_rendered()
        except Exception as e:
            # Telegram may reject edits if content unchanged
            if "message is not modified" not in str(e).lower():
                log.warning("Failed to edit streaming message: %s", e)


class SimpleStreamHandler(BaseStreamHandler):
    """
    Simple stream handler that just collects content.

    Useful for platforms without edit support or for testing.
    Sends one message at the end.
    """

    def __init__(self, send_callback):
        """
        Args:
            send_callback: async callable(text) to send final message
        """
        super().__init__()
        self.send_callback = send_callback

    async def handle(self, event: StreamEvent) -> None:
        """Collect events without sending."""
        await self._handle_event(event)

    async def finalize(self) -> None:
        """Send the final collected content."""
        if self._finalized:
            return

        self._finalized = True
        content = self.buffer.render(include_status=False)

        if content.strip():
            await self.send_callback(content)


def create_stream_handler(platform: Any, chat_id: str) -> BaseStreamHandler:
    """
    Factory function to create appropriate stream handler for platform.

    Args:
        platform: Chat platform instance
        chat_id: Target chat ID

    Returns:
        Appropriate stream handler for the platform

    Config options (in otto config):
        streaming.keep_thinking_message: bool (default: True)
            Whether to keep the tool message after the final response is sent.
            If True, collapses it to "{N} tool calls completed". If False, deletes it.
        agent.thinking.show_in_chat: bool (default: True)
            Whether to show tool progress at all. If False, only final response is sent.
        agent.thinking.tools_only: bool (default: False)
            If True, only show tool names during processing instead of narration text.
            The final response still shows the full text.
    """
    # Check if platform supports message editing
    if hasattr(platform, "capabilities") and platform.capabilities.edit_messages:
        # Get config options
        keep_thinking = True  # Default
        show_thinking = True  # Default
        tools_only = False  # Default
        try:
            from otto.config import get_setting

            keep_thinking = get_setting("streaming.keep_thinking_message", True)
            show_thinking = get_setting("agent.thinking.show_in_chat", True)
            tools_only = get_setting("agent.thinking.tools_only", False)
        except Exception:
            pass

        return TelegramStreamHandler(
            platform,
            chat_id,
            keep_thinking_message=keep_thinking,
            show_thinking=show_thinking,
            tools_only=tools_only,
        )

    # Fall back to simple handler
    async def send(text: str) -> None:
        await platform.send_message(chat_id, text)

    return SimpleStreamHandler(send)
