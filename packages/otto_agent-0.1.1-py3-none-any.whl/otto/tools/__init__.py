"""
Tool framework for Otto's GenericBackend.

This package provides:
- BaseTool: Abstract base class for tool implementations
- ToolSchema: OpenAI-format tool schema definition
- ToolResult: Standardized tool execution result
- ToolRegistry: Registry for managing available tools

Core tools (read_file, write_file, edit_file, bash, glob, grep) are
implemented in executors.py and respect SafeguardConfig protections.

MCP tool integration is provided via schemas.py, which converts Otto's
MCP tools to OpenAI format for use with LiteLLM.
"""

from .base import BaseTool, ToolRegistry, ToolResult, ToolSchema
from .exa import (
    CodeSearchTool,
    ExaClientError,
    ExaMCPClient,
    WebSearchTool,
    create_exa_tools,
)
from .executors import create_core_tools
from .schemas import (
    function_to_openai_schema,
    get_mcp_tool_executors,
    get_mcp_tool_schemas,
)

__all__ = [
    # Base classes
    "BaseTool",
    "ToolSchema",
    "ToolResult",
    "ToolRegistry",
    # Factory
    "create_core_tools",
    # MCP integration
    "function_to_openai_schema",
    "get_mcp_tool_schemas",
    "get_mcp_tool_executors",
    # Exa tools
    "ExaClientError",
    "ExaMCPClient",
    "WebSearchTool",
    "CodeSearchTool",
    "create_exa_tools",
]
