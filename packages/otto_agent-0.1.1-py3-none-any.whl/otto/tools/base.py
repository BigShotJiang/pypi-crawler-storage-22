"""
Base classes for the tool framework.

Provides abstractions for defining and executing tools in the GenericBackend,
with OpenAI-compatible schema generation for LiteLLM tool calling.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ToolSchema:
    """
    Tool schema definition compatible with OpenAI function calling.

    Attributes:
        name: Unique tool identifier
        description: Human-readable description of what the tool does
        parameters: JSON Schema for tool parameters
    """

    name: str
    description: str
    parameters: dict[str, Any] = field(default_factory=dict)

    def to_openai_format(self) -> dict[str, Any]:
        """
        Convert to OpenAI function calling format.

        Returns:
            Dict in the format expected by OpenAI/LiteLLM tool calling:
            {
                "type": "function",
                "function": {
                    "name": "...",
                    "description": "...",
                    "parameters": {...}
                }
            }
        """
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


@dataclass
class ToolResult:
    """
    Result from executing a tool.

    Attributes:
        success: Whether the tool executed successfully
        output: The tool's output (text content)
        error: Error message if success is False
    """

    success: bool
    output: str
    error: str | None = None

    def to_message_content(self) -> str:
        """Format result for inclusion in a message to the LLM."""
        if self.success:
            return self.output
        return f"Error: {self.error}"


class BaseTool(ABC):
    """
    Abstract base class for tool implementations.

    Subclasses must implement:
    - schema: Property returning a ToolSchema
    - execute: Async method that runs the tool
    """

    @property
    @abstractmethod
    def schema(self) -> ToolSchema:
        """Return the tool's schema definition."""
        pass

    @abstractmethod
    async def execute(self, **kwargs: Any) -> ToolResult:
        """
        Execute the tool with the given arguments.

        Args:
            **kwargs: Tool-specific arguments matching the schema

        Returns:
            ToolResult with success status and output
        """
        pass

    @property
    def name(self) -> str:
        """Convenience accessor for the tool name."""
        return self.schema.name


class ToolRegistry:
    """
    Registry for managing available tools.

    Provides registration, lookup, and schema export for tools.
    """

    def __init__(self):
        self._tools: dict[str, BaseTool] = {}

    def register(self, tool: BaseTool) -> None:
        """
        Register a tool in the registry.

        Args:
            tool: Tool instance to register

        Raises:
            ValueError: If a tool with the same name is already registered
        """
        name = tool.name
        if name in self._tools:
            raise ValueError(f"Tool already registered: {name}")
        self._tools[name] = tool

    def register_all(self, tools: list[BaseTool]) -> None:
        """Register multiple tools at once."""
        for tool in tools:
            self.register(tool)

    def get(self, name: str) -> BaseTool | None:
        """
        Get a tool by name.

        Args:
            name: Tool name

        Returns:
            Tool instance or None if not found
        """
        return self._tools.get(name)

    def has(self, name: str) -> bool:
        """Check if a tool is registered."""
        return name in self._tools

    def list_names(self) -> list[str]:
        """Get list of all registered tool names."""
        return list(self._tools.keys())

    def list_schemas(self) -> list[dict[str, Any]]:
        """
        Get all tool schemas in OpenAI format.

        Returns:
            List of tool schemas ready for LiteLLM
        """
        return [tool.schema.to_openai_format() for tool in self._tools.values()]

    def __len__(self) -> int:
        return len(self._tools)

    def __contains__(self, name: str) -> bool:
        return name in self._tools

    def __iter__(self):
        return iter(self._tools.values())


__all__ = [
    "ToolSchema",
    "ToolResult",
    "BaseTool",
    "ToolRegistry",
]
