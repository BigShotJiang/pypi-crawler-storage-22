"""
Exa-powered web search and code search tools for GenericBackend.

Implements a lightweight JSON-RPC 2.0 / SSE HTTP client that calls the
Exa MCP endpoint (https://mcp.exa.ai/mcp) directly.

Free tier: 3 QPS, 150 calls/day. No API key required.
Set EXA_API_KEY env var (or in ~/.otto/config/.env) for higher limits.

Tools:
- web_search: Search the web using Exa
- code_search: Search code repositories using Exa
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

import aiohttp

from .base import BaseTool, ToolResult, ToolSchema

log = logging.getLogger(__name__)

EXA_MCP_ENDPOINT = "https://mcp.exa.ai/mcp"
REQUEST_TIMEOUT = 30
MAX_OUTPUT_CHARS = 15000
RATE_LIMIT_RETRY_DELAY = 3  # seconds to wait on 429 before retrying
RATE_LIMIT_MAX_RETRIES = 2  # retry up to 2 times (3 total attempts)


class ExaClientError(Exception):
    """Error communicating with the Exa MCP endpoint."""


class ExaMCPClient:
    """
    Lightweight JSON-RPC 2.0 / SSE HTTP client for the Exa MCP endpoint.

    Lazily creates an aiohttp session (must be done inside async context).
    The Exa endpoint is stateless — no MCP initialize handshake is needed.

    If an API key is provided (or found in EXA_API_KEY), it's sent as a
    Bearer token for authenticated access with higher rate limits.
    """

    _BASE_HEADERS = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/event-stream",
    }

    def __init__(self, endpoint: str = EXA_MCP_ENDPOINT, api_key: str | None = None):
        self._endpoint = endpoint
        self._api_key = api_key
        self._session: aiohttp.ClientSession | None = None
        self._request_id = 0

    @property
    def _headers(self) -> dict[str, str]:
        headers = dict(self._BASE_HEADERS)
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        return headers

    def _next_id(self) -> int:
        self._request_id += 1
        return self._request_id

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=REQUEST_TIMEOUT)
            )
        return self._session

    async def _send_jsonrpc(self, method: str, params: dict | None = None) -> Any:
        """Send a JSON-RPC 2.0 request and parse the SSE response.

        Retries on 429 (rate limit) with a fixed delay. The free tier allows
        3 QPS / 150 calls per day — parallel sub-agents can easily hit this,
        so we absorb the burst transparently rather than failing immediately.
        """
        session = await self._ensure_session()

        payload = {
            "jsonrpc": "2.0",
            "id": self._next_id(),
            "method": method,
        }
        if params is not None:
            payload["params"] = params

        last_error: Exception | None = None
        for attempt in range(1 + RATE_LIMIT_MAX_RETRIES):
            try:
                async with session.post(
                    self._endpoint,
                    json=payload,
                    headers=self._headers,
                ) as resp:
                    if resp.status == 429:
                        last_error = ExaClientError("Rate limited by Exa (429)")
                        if attempt < RATE_LIMIT_MAX_RETRIES:
                            log.info(
                                "Exa rate limited (429), waiting %ds before retry %d/%d",
                                RATE_LIMIT_RETRY_DELAY,
                                attempt + 1,
                                RATE_LIMIT_MAX_RETRIES,
                            )
                            await asyncio.sleep(RATE_LIMIT_RETRY_DELAY)
                            continue
                        raise last_error

                    if resp.status != 200:
                        text = await resp.text()
                        raise ExaClientError(f"Exa returned HTTP {resp.status}: {text[:200]}")
                    raw = await resp.text()
                    return self._parse_sse_response(raw)
            except aiohttp.ClientError as e:
                raise ExaClientError(f"Network error: {e}") from e
            except ExaClientError:
                raise
            except Exception as e:
                raise ExaClientError(f"Unexpected error: {e}") from e

        raise last_error or ExaClientError("Rate limit retries exhausted")

    @staticmethod
    def _parse_sse_response(raw_text: str) -> Any:
        """
        Extract the JSON-RPC result from an SSE response.

        SSE format:
            event: message
            data: {"jsonrpc":"2.0","id":2,"result":{...}}
        """
        # Try each data: line for valid JSON-RPC response
        for line in raw_text.splitlines():
            line = line.strip()
            if line.startswith("data:"):
                json_str = line[len("data:") :].strip()
                if not json_str:
                    continue
                try:
                    parsed = json.loads(json_str)
                    if "result" in parsed:
                        return parsed["result"]
                    if "error" in parsed:
                        err = parsed["error"]
                        msg = err.get("message", str(err)) if isinstance(err, dict) else str(err)
                        raise ExaClientError(f"JSON-RPC error: {msg}")
                except json.JSONDecodeError:
                    continue

        # Fallback: try parsing the entire response as JSON
        try:
            parsed = json.loads(raw_text)
            if "result" in parsed:
                return parsed["result"]
            if "error" in parsed:
                err = parsed["error"]
                msg = err.get("message", str(err)) if isinstance(err, dict) else str(err)
                raise ExaClientError(f"JSON-RPC error: {msg}")
        except json.JSONDecodeError:
            pass

        raise ExaClientError(f"Could not parse SSE response: {raw_text[:200]}")

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> str:
        """
        Call a tool on the Exa MCP endpoint.

        The Exa endpoint is stateless — each request is independent,
        no MCP initialize handshake required.

        Args:
            name: Tool name (e.g. "web_search_exa")
            arguments: Tool arguments

        Returns:
            Text content from the tool result
        """
        result = await self._send_jsonrpc(
            "tools/call",
            {
                "name": name,
                "arguments": arguments,
            },
        )

        # Extract text from content array
        if isinstance(result, dict):
            content = result.get("content", [])
            if isinstance(content, list):
                texts = []
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        texts.append(item.get("text", ""))
                if texts:
                    return "\n".join(texts)

            # Check for error flag
            if result.get("isError"):
                raise ExaClientError(f"Tool error: {result}")

        return str(result) if result else ""

    async def close(self) -> None:
        """Close the HTTP session."""
        if self._session and not self._session.closed:
            await self._session.close()
        self._session = None


class WebSearchTool(BaseTool):
    """Search the web using Exa."""

    def __init__(self, client: ExaMCPClient):
        self._client = client

    @property
    def schema(self) -> ToolSchema:
        return ToolSchema(
            name="web_search",
            description="Search the web for current information on any topic. Returns relevant web page titles, URLs, and snippets.",
            parameters={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "The search query",
                    },
                    "num_results": {
                        "type": "integer",
                        "description": "Number of results to return (1-20, default 5)",
                    },
                },
                "required": ["query"],
            },
        )

    async def execute(self, **kwargs: Any) -> ToolResult:
        query = kwargs.get("query", "")
        if not query:
            return ToolResult(success=False, output="", error="query is required")

        num_results = kwargs.get("num_results", 5)
        num_results = max(1, min(20, int(num_results)))

        try:
            text = await self._client.call_tool(
                "web_search_exa",
                {
                    "query": query,
                    "numResults": num_results,
                },
            )

            output = f"## Web Search Results for: {query}\n\n{text}"
            if len(output) > MAX_OUTPUT_CHARS:
                output = output[:MAX_OUTPUT_CHARS] + "\n\n[Results truncated]"

            return ToolResult(success=True, output=output)
        except ExaClientError as e:
            log.warning("Exa web_search failed: %s", e)
            return ToolResult(success=False, output="", error=str(e))


class CodeSearchTool(BaseTool):
    """Search code repositories using Exa."""

    def __init__(self, client: ExaMCPClient):
        self._client = client

    @property
    def schema(self) -> ToolSchema:
        return ToolSchema(
            name="code_search",
            description="Search code repositories for implementations, examples, and documentation. Returns relevant code snippets and context.",
            parameters={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "The code search query (e.g. 'Python async HTTP client example')",
                    },
                    "max_tokens": {
                        "type": "integer",
                        "description": "Maximum tokens in response (1000-50000, default 5000)",
                    },
                },
                "required": ["query"],
            },
        )

    async def execute(self, **kwargs: Any) -> ToolResult:
        query = kwargs.get("query", "")
        if not query:
            return ToolResult(success=False, output="", error="query is required")

        max_tokens = kwargs.get("max_tokens", 5000)
        max_tokens = max(1000, min(50000, int(max_tokens)))

        try:
            text = await self._client.call_tool(
                "get_code_context_exa",
                {
                    "query": query,
                    "tokensNum": max_tokens,
                },
            )

            output = f"## Code Search Results for: {query}\n\n{text}"
            if len(output) > MAX_OUTPUT_CHARS:
                output = output[:MAX_OUTPUT_CHARS] + "\n\n[Results truncated]"

            return ToolResult(success=True, output=output)
        except ExaClientError as e:
            log.warning("Exa code_search failed: %s", e)
            return ToolResult(success=False, output="", error=str(e))


def create_exa_tools() -> tuple[list[BaseTool], ExaMCPClient]:
    """
    Create Exa-powered search tools with a shared client.

    Checks EXA_API_KEY env var (or ~/.otto/config/.env) for authenticated
    access with higher rate limits. Falls back to free tier if unset.

    Returns:
        (tools, client): List of tool instances and the shared client for cleanup.
    """
    from otto.config import get_secret

    api_key = get_secret("EXA_API_KEY")
    if api_key:
        log.info("Using authenticated Exa access (EXA_API_KEY set)")

    client = ExaMCPClient(api_key=api_key)
    tools: list[BaseTool] = [WebSearchTool(client), CodeSearchTool(client)]
    return tools, client


__all__ = [
    "ExaClientError",
    "ExaMCPClient",
    "WebSearchTool",
    "CodeSearchTool",
    "create_exa_tools",
]
