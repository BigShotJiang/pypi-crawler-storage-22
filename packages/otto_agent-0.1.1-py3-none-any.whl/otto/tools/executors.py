"""
Core tool implementations for GenericBackend.

Provides file and shell operations with safeguard checks:
- read_file: Read file contents
- write_file: Write content to file (safeguard: protected paths)
- edit_file: Replace text in file (safeguard: protected paths)
- bash: Execute shell commands (safeguard: blocked patterns)
- glob: Find files by pattern
- grep: Search file contents

All tools respect SafeguardConfig for path protection and command filtering.
"""

from __future__ import annotations

import asyncio
import re
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .base import BaseTool, ToolResult, ToolSchema

if TYPE_CHECKING:
    from otto.safeguards import SafeguardConfig


class ReadFileTool(BaseTool):
    """Read contents of a file."""

    def __init__(self, cwd: Path):
        self.cwd = cwd

    @property
    def schema(self) -> ToolSchema:
        return ToolSchema(
            name="read_file",
            description="Read the contents of a file. Returns the file content as text.",
            parameters={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file to read (absolute or relative to cwd)",
                    },
                    "offset": {
                        "type": "integer",
                        "description": "Line number to start reading from (1-indexed)",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of lines to read",
                    },
                },
                "required": ["path"],
            },
        )

    async def execute(
        self,
        path: str,
        offset: int | None = None,
        limit: int | None = None,
        **kwargs: Any,
    ) -> ToolResult:
        try:
            file_path = Path(path)
            if not file_path.is_absolute():
                file_path = self.cwd / file_path

            if not file_path.exists():
                return ToolResult(success=False, output="", error=f"File not found: {path}")

            if not file_path.is_file():
                return ToolResult(success=False, output="", error=f"Not a file: {path}")

            content = await asyncio.to_thread(file_path.read_text, encoding="utf-8")

            # Apply offset and limit
            if offset or limit:
                lines = content.splitlines(keepends=True)
                start = (offset - 1) if offset and offset > 0 else 0
                end = (start + limit) if limit else None
                content = "".join(lines[start:end])

            return ToolResult(success=True, output=content)

        except PermissionError:
            return ToolResult(success=False, output="", error=f"Permission denied: {path}")
        except UnicodeDecodeError:
            return ToolResult(success=False, output="", error=f"Cannot read binary file: {path}")
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class WriteFileTool(BaseTool):
    """Write content to a file."""

    def __init__(self, cwd: Path, safeguards: SafeguardConfig):
        self.cwd = cwd
        self.safeguards = safeguards

    @property
    def schema(self) -> ToolSchema:
        return ToolSchema(
            name="write_file",
            description="Write content to a file. Creates the file if it doesn't exist, overwrites if it does.",
            parameters={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file to write (absolute or relative to cwd)",
                    },
                    "content": {
                        "type": "string",
                        "description": "Content to write to the file",
                    },
                },
                "required": ["path", "content"],
            },
        )

    async def execute(
        self,
        path: str,
        content: str,
        **kwargs: Any,
    ) -> ToolResult:
        try:
            file_path = Path(path)
            if not file_path.is_absolute():
                file_path = self.cwd / file_path

            # Check safeguards
            if self.safeguards.is_path_protected(str(file_path)):
                return ToolResult(
                    success=False,
                    output="",
                    error=f"Protected path: {path}. Cannot write to this location.",
                )

            # Create parent directories if needed
            await asyncio.to_thread(file_path.parent.mkdir, parents=True, exist_ok=True)

            # Write file
            await asyncio.to_thread(file_path.write_text, content, encoding="utf-8")

            return ToolResult(
                success=True, output=f"Successfully wrote {len(content)} bytes to {path}"
            )

        except PermissionError:
            return ToolResult(success=False, output="", error=f"Permission denied: {path}")
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class EditFileTool(BaseTool):
    """Edit a file by replacing text."""

    def __init__(self, cwd: Path, safeguards: SafeguardConfig):
        self.cwd = cwd
        self.safeguards = safeguards

    @property
    def schema(self) -> ToolSchema:
        return ToolSchema(
            name="edit_file",
            description="Edit a file by replacing exact text. The old_text must match exactly in the file.",
            parameters={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the file to edit (absolute or relative to cwd)",
                    },
                    "old_text": {
                        "type": "string",
                        "description": "Exact text to find and replace",
                    },
                    "new_text": {
                        "type": "string",
                        "description": "Text to replace old_text with",
                    },
                    "replace_all": {
                        "type": "boolean",
                        "description": "Replace all occurrences (default: false, replace first only)",
                    },
                },
                "required": ["path", "old_text", "new_text"],
            },
        )

    async def execute(
        self,
        path: str,
        old_text: str,
        new_text: str,
        replace_all: bool = False,
        **kwargs: Any,
    ) -> ToolResult:
        try:
            file_path = Path(path)
            if not file_path.is_absolute():
                file_path = self.cwd / file_path

            # Check safeguards
            if self.safeguards.is_path_protected(str(file_path)):
                return ToolResult(
                    success=False,
                    output="",
                    error=f"Protected path: {path}. Cannot edit this file.",
                )

            if not file_path.exists():
                return ToolResult(success=False, output="", error=f"File not found: {path}")

            content = await asyncio.to_thread(file_path.read_text, encoding="utf-8")

            if old_text not in content:
                return ToolResult(
                    success=False,
                    output="",
                    error="Text not found in file. The old_text must match exactly.",
                )

            # Check for uniqueness if not replacing all
            if not replace_all and content.count(old_text) > 1:
                return ToolResult(
                    success=False,
                    output="",
                    error=f"old_text appears {content.count(old_text)} times. "
                    "Use replace_all=true or provide more context to make it unique.",
                )

            # Perform replacement
            if replace_all:
                new_content = content.replace(old_text, new_text)
                count = content.count(old_text)
            else:
                new_content = content.replace(old_text, new_text, 1)
                count = 1

            await asyncio.to_thread(file_path.write_text, new_content, encoding="utf-8")

            return ToolResult(
                success=True,
                output=f"Replaced {count} occurrence(s) in {path}",
            )

        except PermissionError:
            return ToolResult(success=False, output="", error=f"Permission denied: {path}")
        except UnicodeDecodeError:
            return ToolResult(success=False, output="", error=f"Cannot edit binary file: {path}")
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class BashTool(BaseTool):
    """Execute bash commands."""

    def __init__(self, cwd: Path, safeguards: SafeguardConfig):
        self.cwd = cwd
        self.safeguards = safeguards

    @property
    def schema(self) -> ToolSchema:
        return ToolSchema(
            name="bash",
            description="Execute a bash command. Returns stdout and stderr.",
            parameters={
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "The bash command to execute",
                    },
                    "cwd": {
                        "type": "string",
                        "description": "Working directory for the command (optional, defaults to project root)",
                    },
                    "timeout": {
                        "type": "integer",
                        "description": "Timeout in seconds (default: 120)",
                    },
                },
                "required": ["command"],
            },
        )

    async def execute(
        self,
        command: str,
        cwd: str | None = None,
        timeout: int = 120,
        **kwargs: Any,
    ) -> ToolResult:
        try:
            # Check safeguards
            blocked, pattern = self.safeguards.is_command_blocked(command)
            if blocked:
                return ToolResult(
                    success=False,
                    output="",
                    error=f"Blocked dangerous command pattern: {pattern}",
                )

            # Determine working directory
            work_dir = Path(cwd) if cwd else self.cwd
            if not work_dir.is_absolute():
                work_dir = self.cwd / work_dir

            # Execute command
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(work_dir),
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(),
                    timeout=timeout,
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                return ToolResult(
                    success=False,
                    output="",
                    error=f"Command timed out after {timeout} seconds",
                )

            output_parts = []
            if stdout:
                output_parts.append(stdout.decode("utf-8", errors="replace"))
            if stderr:
                output_parts.append(f"STDERR:\n{stderr.decode('utf-8', errors='replace')}")

            output = "\n".join(output_parts)

            # Truncate very long outputs
            if len(output) > 30000:
                output = output[:30000] + "\n... (truncated)"

            if proc.returncode != 0:
                return ToolResult(
                    success=False,
                    output=output,
                    error=f"Command exited with code {proc.returncode}",
                )

            return ToolResult(success=True, output=output or "(no output)")

        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class GlobTool(BaseTool):
    """Find files matching a glob pattern."""

    def __init__(self, cwd: Path):
        self.cwd = cwd

    @property
    def schema(self) -> ToolSchema:
        return ToolSchema(
            name="glob",
            description="Find files matching a glob pattern (e.g., '**/*.py', 'src/**/*.ts').",
            parameters={
                "type": "object",
                "properties": {
                    "pattern": {
                        "type": "string",
                        "description": "Glob pattern to match files",
                    },
                    "path": {
                        "type": "string",
                        "description": "Directory to search in (default: cwd)",
                    },
                },
                "required": ["pattern"],
            },
        )

    async def execute(
        self,
        pattern: str,
        path: str | None = None,
        **kwargs: Any,
    ) -> ToolResult:
        try:
            search_dir = Path(path) if path else self.cwd
            if not search_dir.is_absolute():
                search_dir = self.cwd / search_dir

            if not search_dir.exists():
                return ToolResult(
                    success=False, output="", error=f"Directory not found: {search_dir}"
                )

            # Use pathlib glob
            matches = await asyncio.to_thread(
                lambda: sorted(str(p.relative_to(search_dir)) for p in search_dir.glob(pattern))
            )

            if not matches:
                return ToolResult(success=True, output="No files matched the pattern")

            # Limit output
            total = len(matches)
            if total > 500:
                matches = matches[:500]
                output = "\n".join(matches) + f"\n... and {total - 500} more files"
            else:
                output = "\n".join(matches)

            return ToolResult(success=True, output=output)

        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class GrepTool(BaseTool):
    """Search for patterns in file contents."""

    def __init__(self, cwd: Path):
        self.cwd = cwd

    @property
    def schema(self) -> ToolSchema:
        return ToolSchema(
            name="grep",
            description="Search for a regex pattern in files. Returns matching files and lines.",
            parameters={
                "type": "object",
                "properties": {
                    "pattern": {
                        "type": "string",
                        "description": "Regex pattern to search for",
                    },
                    "path": {
                        "type": "string",
                        "description": "File or directory to search in (default: cwd)",
                    },
                    "include": {
                        "type": "string",
                        "description": "Glob pattern to filter files (e.g., '*.py')",
                    },
                },
                "required": ["pattern"],
            },
        )

    async def execute(
        self,
        pattern: str,
        path: str | None = None,
        include: str | None = None,
        **kwargs: Any,
    ) -> ToolResult:
        try:
            search_path = Path(path) if path else self.cwd
            if not search_path.is_absolute():
                search_path = self.cwd / search_path

            if not search_path.exists():
                return ToolResult(success=False, output="", error=f"Path not found: {search_path}")

            # Compile regex
            try:
                regex = re.compile(pattern)
            except re.error as e:
                return ToolResult(success=False, output="", error=f"Invalid regex: {e}")

            results = []
            files_searched = 0
            max_results = 100

            def search_file(file_path: Path) -> list[str]:
                nonlocal files_searched
                files_searched += 1
                matches = []
                try:
                    content = file_path.read_text(encoding="utf-8", errors="ignore")
                    for i, line in enumerate(content.splitlines(), 1):
                        if regex.search(line):
                            rel_path = str(file_path.relative_to(self.cwd))
                            matches.append(f"{rel_path}:{i}: {line[:200]}")
                except Exception:
                    pass
                return matches

            # Get files to search
            if search_path.is_file():
                files = [search_path]
            else:
                glob_pattern = include or "**/*"
                files = [
                    f
                    for f in search_path.glob(glob_pattern)
                    if f.is_file() and not any(part.startswith(".") for part in f.parts)
                ]

            # Search files (in thread to avoid blocking)
            for file_path in files:
                if len(results) >= max_results:
                    break
                file_results = await asyncio.to_thread(search_file, file_path)
                results.extend(file_results[: max_results - len(results)])

            if not results:
                return ToolResult(
                    success=True,
                    output=f"No matches found in {files_searched} files",
                )

            output = "\n".join(results)
            if len(results) >= max_results:
                output += f"\n... (limited to {max_results} results)"

            return ToolResult(success=True, output=output)

        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


def create_core_tools(cwd: Path, safeguards: SafeguardConfig) -> list[BaseTool]:
    """
    Create all core tools with the given configuration.

    Args:
        cwd: Working directory for file operations
        safeguards: SafeguardConfig for path/command protection

    Returns:
        List of tool instances ready for registration
    """
    return [
        ReadFileTool(cwd),
        WriteFileTool(cwd, safeguards),
        EditFileTool(cwd, safeguards),
        BashTool(cwd, safeguards),
        GlobTool(cwd),
        GrepTool(cwd),
    ]


__all__ = [
    "ReadFileTool",
    "WriteFileTool",
    "EditFileTool",
    "BashTool",
    "GlobTool",
    "GrepTool",
    "create_core_tools",
]
