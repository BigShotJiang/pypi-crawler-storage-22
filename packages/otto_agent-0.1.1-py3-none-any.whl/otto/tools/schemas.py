"""
MCP tool schema conversion for GenericBackend.

Converts Otto's MCP tools (async Python functions) to OpenAI-format tool schemas
for use with LiteLLM. Also provides executors for direct tool calls.

The conversion introspects function signatures and docstrings to build
JSON Schema parameter definitions.
"""

from __future__ import annotations

import inspect
from collections.abc import Callable
from typing import Any, Union, get_args, get_origin, get_type_hints


def _python_type_to_json_schema(py_type: type | None) -> dict[str, Any]:
    """
    Convert a Python type annotation to JSON Schema.

    Args:
        py_type: Python type annotation

    Returns:
        JSON Schema type definition
    """
    if py_type is None:
        return {"type": "string"}

    # Handle Optional[X] (Union[X, None])
    origin = get_origin(py_type)
    if origin is Union:
        args = get_args(py_type)
        # Filter out NoneType
        non_none_args = [a for a in args if a is not type(None)]
        if len(non_none_args) == 1:
            # Optional[X] -> just use X's schema
            return _python_type_to_json_schema(non_none_args[0])
        # Union of multiple types - use anyOf
        return {"anyOf": [_python_type_to_json_schema(a) for a in non_none_args]}

    # Handle list[X]
    if origin is list:
        args = get_args(py_type)
        item_type = args[0] if args else str
        return {
            "type": "array",
            "items": _python_type_to_json_schema(item_type),
        }

    # Handle dict[K, V]
    if origin is dict:
        return {"type": "object"}

    # Basic types
    type_map = {
        str: {"type": "string"},
        int: {"type": "integer"},
        float: {"type": "number"},
        bool: {"type": "boolean"},
        type(None): {"type": "null"},
    }

    return type_map.get(py_type, {"type": "string"})


def function_to_openai_schema(func: Callable[..., Any]) -> dict[str, Any]:
    """
    Convert an async function to OpenAI tool schema format.

    Extracts:
    - Function name
    - Docstring as description
    - Parameter types from annotations
    - Required parameters (those without defaults)

    Args:
        func: Async function to convert

    Returns:
        OpenAI tool schema dict:
        {
            "type": "function",
            "function": {
                "name": "...",
                "description": "...",
                "parameters": {
                    "type": "object",
                    "properties": {...},
                    "required": [...]
                }
            }
        }
    """
    sig = inspect.signature(func)

    try:
        hints = get_type_hints(func)
    except Exception:
        hints = {}

    # Get docstring for description
    doc = inspect.getdoc(func) or ""
    # Use first paragraph as description
    description = doc.split("\n\n")[0].strip() if doc else f"Call the {func.__name__} function"

    # Build parameter schema
    properties: dict[str, Any] = {}
    required: list[str] = []

    for name, param in sig.parameters.items():
        # Skip 'self' and return annotation
        if name in ("self", "cls"):
            continue

        # Get type hint
        py_type = hints.get(name)
        schema = _python_type_to_json_schema(py_type)

        # Try to extract parameter description from docstring
        param_desc = _extract_param_description(doc, name)
        if param_desc:
            schema["description"] = param_desc

        properties[name] = schema

        # Determine if required (no default value)
        if param.default is inspect.Parameter.empty:
            required.append(name)

    return {
        "type": "function",
        "function": {
            "name": func.__name__,
            "description": description,
            "parameters": {
                "type": "object",
                "properties": properties,
                "required": required,
            },
        },
    }


def _extract_param_description(docstring: str, param_name: str) -> str | None:
    """
    Extract parameter description from docstring.

    Supports Google-style and Sphinx-style docstrings:
    - Args:
        param_name: Description here
    - :param param_name: Description here

    Args:
        docstring: Full docstring text
        param_name: Parameter name to find

    Returns:
        Parameter description or None
    """
    if not docstring:
        return None

    lines = docstring.split("\n")

    # Google-style: look for "param_name: description" after "Args:"
    in_args_section = False
    for line in lines:
        stripped = line.strip()

        if stripped.lower().startswith("args:"):
            in_args_section = True
            continue

        if in_args_section:
            # End of Args section
            if stripped and not stripped.startswith(" ") and ":" not in stripped[:20]:
                if stripped.lower().startswith(("returns:", "raises:", "yields:", "examples:")):
                    in_args_section = False
                    continue

            # Match "param_name: description" or "param_name (type): description"
            if stripped.startswith(f"{param_name}:"):
                return stripped.split(":", 1)[1].strip()
            if stripped.startswith(f"{param_name} ("):
                # Handle "param_name (type): description"
                if "):" in stripped:
                    return stripped.split("):", 1)[1].strip()

    # Sphinx-style: look for ":param param_name: description"
    for line in lines:
        stripped = line.strip()
        if stripped.startswith(f":param {param_name}:"):
            return stripped.split(":", 2)[2].strip()

    return None


def get_mcp_tool_schemas() -> list[dict[str, Any]]:
    """
    Get OpenAI-format schemas for all Otto MCP tools.

    Returns:
        List of tool schemas ready for LiteLLM
    """
    from otto.mcp_tools import ALL_TOOLS

    return [function_to_openai_schema(tool) for tool in ALL_TOOLS]


def get_mcp_tool_executors() -> dict[str, Callable[..., Any]]:
    """
    Get a mapping of tool names to their executor functions.

    Returns:
        Dict mapping tool name to async function
    """
    from otto.mcp_tools import ALL_TOOLS

    return {tool.__name__: tool for tool in ALL_TOOLS}


__all__ = [
    "function_to_openai_schema",
    "get_mcp_tool_schemas",
    "get_mcp_tool_executors",
]
