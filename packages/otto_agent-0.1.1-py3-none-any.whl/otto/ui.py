"""
Otto Telegram UI Helpers

Simplifies building interactive button dialogs for common patterns:
- Confirmations (Yes/No)
- Multi-choice selections
- Multi-step flows with state

Usage:
    from otto.ui import confirm, choice, menu

    # Simple confirmation
    markup = confirm("delete_item_123", yes="Delete", no="Keep")

    # Choice list
    markup = choice("backend", ["claude", "codex", "generic"], cancel=True)

    # Menu with descriptions
    markup = menu("action", {
        "run": "Execute now",
        "schedule": "Schedule for later",
        "cancel": "Nevermind",
    })

Callback data format:
    {prefix}:{action}  e.g. "delete_item_123:yes", "backend:claude"

Legacy callback data format (still parsed for backwards compatibility):
    {prefix}_{action}
"""

from __future__ import annotations

from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def confirm(
    prefix: str,
    yes: str = "Yes",
    no: str = "No",
    yes_data: str = "yes",
    no_data: str = "no",
) -> InlineKeyboardMarkup:
    """
    Create a Yes/No confirmation dialog.

    Args:
        prefix: Callback data prefix (e.g. "delete_file")
        yes: Label for confirm button
        no: Label for cancel button
        yes_data: Suffix for confirm callback (default: "yes")
        no_data: Suffix for cancel callback (default: "no")

    Returns:
        InlineKeyboardMarkup with two buttons in a row

    Example callback_data: "delete_file_yes", "delete_file_no"
    """
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(yes, callback_data=f"{prefix}:{yes_data}"),
                InlineKeyboardButton(no, callback_data=f"{prefix}:{no_data}"),
            ]
        ]
    )


def choice(
    prefix: str,
    options: list[str],
    cancel: bool = True,
    cancel_label: str = "Cancel",
    per_row: int = 1,
) -> InlineKeyboardMarkup:
    """
    Create a single-select choice list.

    Args:
        prefix: Callback data prefix
        options: List of option labels (also used as callback suffixes)
        cancel: Whether to add a cancel button
        cancel_label: Label for cancel button
        per_row: Buttons per row (default: 1)

    Returns:
        InlineKeyboardMarkup with options

    Example callback_data: "backend_claude", "backend_cancel"
    """
    keyboard = []
    row = []

    for opt in options:
        # Sanitize option for callback_data (max 64 bytes, no special chars)
        safe_opt = opt.lower().replace(" ", "_")[:30]
        row.append(InlineKeyboardButton(opt, callback_data=f"{prefix}:{safe_opt}"))

        if len(row) >= per_row:
            keyboard.append(row)
            row = []

    if row:
        keyboard.append(row)

    if cancel:
        keyboard.append([InlineKeyboardButton(cancel_label, callback_data=f"{prefix}:cancel")])

    return keyboard_markup(keyboard)


def menu(
    prefix: str,
    items: dict[str, str],
    cancel: bool = False,
    cancel_label: str = "Cancel",
) -> InlineKeyboardMarkup:
    """
    Create a menu with labeled actions.

    Args:
        prefix: Callback data prefix
        items: Dict of {action_key: display_label}
        cancel: Whether to add a cancel button
        cancel_label: Label for cancel button

    Returns:
        InlineKeyboardMarkup with menu items

    Example:
        menu("file", {"open": "Open File", "delete": "Delete"})
        # callback_data: "file_open", "file_delete"
    """
    keyboard = []

    for key, label in items.items():
        keyboard.append([InlineKeyboardButton(label, callback_data=f"{prefix}:{key}")])

    if cancel:
        keyboard.append([InlineKeyboardButton(cancel_label, callback_data=f"{prefix}:cancel")])

    return keyboard_markup(keyboard)


def grid(
    prefix: str,
    items: list[str] | dict[str, str],
    columns: int = 2,
    cancel: bool = False,
) -> InlineKeyboardMarkup:
    """
    Create a grid layout of buttons.

    Args:
        prefix: Callback data prefix
        items: List of labels or dict of {key: label}
        columns: Number of columns
        cancel: Whether to add a cancel button

    Returns:
        InlineKeyboardMarkup with grid layout
    """
    keyboard = []
    row = []

    if isinstance(items, dict):
        item_list = [(k, v) for k, v in items.items()]
    else:
        item_list = [(item.lower().replace(" ", "_")[:30], item) for item in items]

    for key, label in item_list:
        row.append(InlineKeyboardButton(label, callback_data=f"{prefix}:{key}"))
        if len(row) >= columns:
            keyboard.append(row)
            row = []

    if row:
        keyboard.append(row)

    if cancel:
        keyboard.append([InlineKeyboardButton("Cancel", callback_data=f"{prefix}:cancel")])

    return keyboard_markup(keyboard)


def error_recovery(
    prefix: str = "error",
    retry: bool = True,
    skip: bool = True,
    cancel: bool = True,
) -> InlineKeyboardMarkup:
    """
    Create error recovery buttons (Retry/Skip/Cancel).

    Args:
        prefix: Callback data prefix
        retry: Include retry button
        skip: Include skip button
        cancel: Include cancel button

    Returns:
        InlineKeyboardMarkup with recovery options
    """
    buttons = []
    if retry:
        buttons.append(InlineKeyboardButton("🔄 Retry", callback_data=f"{prefix}:retry"))
    if skip:
        buttons.append(InlineKeyboardButton("⏭ Skip", callback_data=f"{prefix}:skip"))
    if cancel:
        buttons.append(InlineKeyboardButton("✕ Cancel", callback_data=f"{prefix}:cancel"))

    return InlineKeyboardMarkup([buttons]) if buttons else InlineKeyboardMarkup([])


def link_button(text: str, url: str) -> InlineKeyboardMarkup:
    """Create a single URL button."""
    return InlineKeyboardMarkup([[InlineKeyboardButton(text, url=url)]])


def link_row(*buttons: tuple[str, str]) -> InlineKeyboardMarkup:
    """
    Create a row of URL buttons.

    Args:
        buttons: Tuples of (label, url)

    Example:
        link_row(("Docs", "https://..."), ("GitHub", "https://..."))
    """
    return InlineKeyboardMarkup([[InlineKeyboardButton(label, url=url) for label, url in buttons]])


def keyboard_markup(keyboard: list[list[InlineKeyboardButton]]) -> InlineKeyboardMarkup:
    """Wrap a keyboard in InlineKeyboardMarkup."""
    return InlineKeyboardMarkup(keyboard)


def parse_callback(data: str, expected_prefix: str) -> str | None:
    """
    Parse callback data and extract action if prefix matches.

    Args:
        data: Raw callback_data string
        expected_prefix: Prefix to match

    Returns:
        Action string if prefix matches, None otherwise

    Example:
        parse_callback("vtt_enable", "vtt") -> "enable"
        parse_callback("backend_claude", "vtt") -> None
    """
    if data.startswith(f"{expected_prefix}:"):
        return data[len(expected_prefix) + 1 :]
    if data.startswith(f"{expected_prefix}_"):
        return data[len(expected_prefix) + 1 :]
    return None


# ─────────────────────────────────────────────────────────────
# Task List (Resend Pattern)
# ─────────────────────────────────────────────────────────────


def format_task_list(
    tasks: list[dict],
    title: str | None = None,
    max_display: int = 6,
) -> str:
    """
    Format a task list for display in chat.

    Uses resend pattern: send NEW message with updated state
    instead of editing inline. Max 5-6 tasks shown.

    Args:
        tasks: List of {"content": str, "done": bool}
        title: Optional title for the list
        max_display: Max tasks to show (rest are "... +N more")

    Returns:
        Formatted HTML string

    Example output:
        <b>Setup Tasks</b>

        ☑️ <s>Install dependencies</s>
        ☑️ <s>Configure database</s>
        ☐ Write tests
        ☐ Deploy to staging

        2/4 complete
    """
    lines = []

    if title:
        lines.append(f"<b>{title}</b>\n")

    displayed = tasks[:max_display]
    remaining = len(tasks) - max_display

    for t in displayed:
        content = t.get("content", "Task")
        done = t.get("done", False)

        if done:
            lines.append(f"☑️ <s>{content}</s>")
        else:
            lines.append(f"☐ {content}")

    if remaining > 0:
        lines.append(f"<i>... +{remaining} more</i>")

    # Progress summary
    total = len(tasks)
    completed = sum(1 for t in tasks if t.get("done"))
    if total > 0:
        lines.append(f"\n<i>{completed}/{total} complete</i>")

    return "\n".join(lines)
