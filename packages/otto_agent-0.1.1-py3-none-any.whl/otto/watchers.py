"""
Filesystem watchers for Otto.

This module provides a polling-based directory watcher (no external deps) that can
trigger background agent jobs when files change.
"""

from __future__ import annotations

import fnmatch
import time
import uuid
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

from otto.jobs.queue import JobQueue


@dataclass(frozen=True)
class FileInfo:
    mtime_ns: int
    size: int


@dataclass(frozen=True)
class ChangeSet:
    created: tuple[str, ...]
    modified: tuple[str, ...]
    deleted: tuple[str, ...]

    @property
    def is_empty(self) -> bool:
        return not (self.created or self.modified or self.deleted)


def _matches_any(path: str, globs: Iterable[str]) -> bool:
    return any(fnmatch.fnmatch(path, g) for g in globs)


def snapshot(
    roots: Iterable[Path],
    *,
    ignore_globs: Iterable[str] = (),
    include_hidden: bool = False,
) -> dict[str, FileInfo]:
    """Create a snapshot of file mtimes/sizes under the given roots."""
    ignore = tuple(ignore_globs)
    out: dict[str, FileInfo] = {}

    for root in roots:
        root = Path(root).expanduser()
        if not root.exists():
            continue

        paths = [root] if root.is_file() else list(root.rglob("*"))
        for p in paths:
            try:
                if p.is_dir():
                    continue
                rel = str(p)
                if not include_hidden and any(part.startswith(".") for part in p.parts):
                    continue
                if ignore and _matches_any(rel, ignore):
                    continue
                st = p.stat()
                out[rel] = FileInfo(mtime_ns=int(st.st_mtime_ns), size=int(st.st_size))
            except OSError:
                continue

    return out


def diff(old: dict[str, FileInfo], new: dict[str, FileInfo]) -> ChangeSet:
    """Compute created/modified/deleted files between two snapshots."""
    old_keys = set(old)
    new_keys = set(new)

    created = sorted(new_keys - old_keys)
    deleted = sorted(old_keys - new_keys)

    modified: list[str] = []
    for k in sorted(old_keys & new_keys):
        if old[k] != new[k]:
            modified.append(k)

    return ChangeSet(created=tuple(created), modified=tuple(modified), deleted=tuple(deleted))


def format_changes(changes: ChangeSet, *, max_paths: int = 50) -> str:
    """Format a ChangeSet as a short, human-readable block."""
    lines: list[str] = []

    def _add(label: str, paths: tuple[str, ...]) -> None:
        if not paths:
            return
        shown = paths[:max_paths]
        lines.append(f"{label} ({len(paths)}):")
        lines.extend(f"- {p}" for p in shown)
        if len(paths) > len(shown):
            lines.append(f"- ... +{len(paths) - len(shown)} more")
        lines.append("")

    _add("Created", changes.created)
    _add("Modified", changes.modified)
    _add("Deleted", changes.deleted)

    return "\n".join(lines).strip()


def enqueue_agent_for_changes(
    *,
    changes: ChangeSet,
    watch_name: str,
    roots: Iterable[Path],
    prompt: str | None = None,
    backend: str | None = None,
    notify: bool = True,
    priority: str = "low",
    queue: JobQueue | None = None,
) -> int:
    """Enqueue a background agent job describing the detected changes."""
    if changes.is_empty:
        raise ValueError("No changes to enqueue")

    q = queue or JobQueue()
    agent_id = uuid.uuid4().hex[:12]

    roots_str = ", ".join(str(Path(r).expanduser()) for r in roots)
    changes_block = format_changes(changes, max_paths=80)

    user_prompt = prompt or (
        "A filesystem watcher detected changes.\n\n"
        f"Watcher: {watch_name}\n"
        f"Roots: {roots_str}\n\n"
        f"{changes_block}\n\n"
        "Please summarize what changed and what actions (if any) I should take. "
        "Be brief unless detail is required."
    )

    payload = {
        "agent_id": agent_id,
        "task": f"Filesystem watcher: {watch_name}",
        "prompt": user_prompt,
        "backend": backend,
        "notify": bool(notify),
        "priority": priority,
    }
    return q.add("agent", payload, priority=0, external_id=f"watch:{watch_name}:{agent_id}")


class DirectoryWatcher:
    """Polling-based directory watcher with simple debouncing."""

    def __init__(
        self,
        *,
        roots: Iterable[Path],
        name: str = "watch",
        poll_seconds: float = 2.0,
        debounce_seconds: float = 5.0,
        ignore_globs: Iterable[str] = (),
        include_hidden: bool = False,
    ):
        self.roots = tuple(Path(r).expanduser() for r in roots)
        self.name = name
        self.poll_seconds = float(poll_seconds)
        self.debounce_seconds = float(debounce_seconds)
        self.ignore_globs = tuple(ignore_globs)
        self.include_hidden = bool(include_hidden)

        self._running = False
        self._last_snapshot: dict[str, FileInfo] = {}
        self._last_trigger_at: float = 0.0

    def stop(self) -> None:
        self._running = False

    def run(
        self,
        *,
        trigger_agents: bool = True,
        prompt: str | None = None,
        backend: str | None = None,
        notify: bool = True,
        priority: str = "low",
    ) -> None:
        """Run the watcher loop forever (until stop())."""
        self._running = True
        self._last_snapshot = snapshot(
            self.roots,
            ignore_globs=self.ignore_globs,
            include_hidden=self.include_hidden,
        )

        while self._running:
            time.sleep(self.poll_seconds)
            current = snapshot(
                self.roots,
                ignore_globs=self.ignore_globs,
                include_hidden=self.include_hidden,
            )
            changes = diff(self._last_snapshot, current)
            self._last_snapshot = current

            if changes.is_empty:
                continue

            now = time.time()
            if self.debounce_seconds > 0 and (now - self._last_trigger_at) < self.debounce_seconds:
                continue
            self._last_trigger_at = now

            if trigger_agents:
                enqueue_agent_for_changes(
                    changes=changes,
                    watch_name=self.name,
                    roots=self.roots,
                    prompt=prompt,
                    backend=backend,
                    notify=notify,
                    priority=priority,
                )
