"""
otto-tools - Unified CLI for Otto's utility tools.

Provides a single command-line interface for all Otto operations:
- memory: Store and retrieve information
- system: System information and monitoring
- dev: Development utilities (test, lint, git)
- research: Web search and information gathering
- notify: Send notifications via Telegram
"""

__version__ = "0.1.0"
