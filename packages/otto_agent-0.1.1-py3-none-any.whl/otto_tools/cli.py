"""
Main CLI entry point for otto-tools.

Uses Typer for a modern, type-hinted CLI experience.
"""

import typer

from . import __version__
from .dev import app as dev_app
from .memory import app as memory_app
from .notify import app as notify_app
from .research import app as research_app
from .system import app as system_app

app = typer.Typer(
    name="otto-tools",
    help="Unified CLI for Otto's utility tools.",
    no_args_is_help=True,
    add_completion=False,
)

# Add subcommands
app.add_typer(memory_app, name="memory", help="Memory operations (recall, remember, list, forget)")
app.add_typer(system_app, name="system", help="System information and monitoring")
app.add_typer(dev_app, name="dev", help="Development utilities (test, lint, git)")
app.add_typer(research_app, name="research", help="Web search and information")
app.add_typer(notify_app, name="notify", help="Send notifications")


def version_callback(value: bool):
    if value:
        print(f"otto-tools version {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        None,
        "--version",
        "-V",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit",
    ),
):
    """
    Otto Tools - Unified CLI for all Otto utility operations.

    Use 'otto-tools <command> --help' for detailed help on each command.
    """
    pass


def run():
    """Entry point for the CLI."""
    app()


if __name__ == "__main__":
    run()
