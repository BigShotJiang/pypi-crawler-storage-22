"""
Shared configuration for otto-tools.

Uses the same configuration paths as otto core for consistency.
"""

import os
from pathlib import Path

from otto.paths import ENV_FILE, MEMORY_DIR


def get_memory_dir() -> Path:
    """Get the memory directory, creating if needed."""
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    return MEMORY_DIR


def get_env_value(key: str) -> str | None:
    """Get an environment value from env or .env file."""
    # Check environment first
    value = os.environ.get(key)
    if value:
        return value

    # Check .env file
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text().split("\n"):
            line = line.strip()
            if line.startswith(f"{key}="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")

    return None


def get_telegram_token() -> str | None:
    """Get Telegram bot token."""
    return get_env_value("TELEGRAM_BOT_TOKEN")


def get_chat_id() -> int | None:
    """Get registered Telegram chat ID from state.yaml or owner_id from settings."""
    from otto.config import get_setting, get_telegram_state

    # First check state.yaml (telegram.chat_id)
    tg_state = get_telegram_state()
    if tg_state and tg_state.get("chat_id"):
        return int(tg_state["chat_id"])

    # Fallback to owner_id from settings (access.owner_id)
    owner_id = get_setting("access.owner_id")
    if owner_id:
        return int(owner_id)

    return None
