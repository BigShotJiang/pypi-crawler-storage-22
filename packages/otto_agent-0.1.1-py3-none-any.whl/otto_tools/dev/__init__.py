"""
Development tools.

Commands:
- test: Auto-detect and run tests
- lint: Auto-detect and run linter
- git-summary: Show git status and recent activity
"""

import json
import shutil
import subprocess
import time
from pathlib import Path

import typer
from rich.console import Console

app = typer.Typer(
    name="dev",
    help="Development utilities (test, lint, git).",
    no_args_is_help=True,
)

console = Console()
err_console = Console(stderr=True)


def detect_project_type(path: Path) -> str | None:
    """Detect the project type based on files present."""
    if (path / "pyproject.toml").exists() or (path / "setup.py").exists():
        return "python"
    if (path / "package.json").exists():
        return "node"
    if (path / "Cargo.toml").exists():
        return "rust"
    if (path / "go.mod").exists():
        return "go"
    if (path / "Makefile").exists():
        return "makefile"
    # Check for python files
    if list(path.glob("*.py")) or (path / "tests").exists():
        return "python"
    return None


def run_command(cmd: list[str], cwd: Path, timeout: int = 300) -> tuple[int, str]:
    """Run a command and return exit code and output."""
    try:
        result = subprocess.run(
            cmd,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        output = result.stdout + result.stderr
        return result.returncode, output
    except subprocess.TimeoutExpired:
        return 1, "Command timed out"
    except FileNotFoundError as e:
        return 1, f"Command not found: {e}"


@app.command()
def test(
    path: Path = typer.Argument(
        ".",
        help="Project path to test",
        exists=True,
        file_okay=False,
        resolve_path=True,
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    Auto-detect test framework and run tests.

    Supports:
    - Python: pytest, unittest
    - Node.js: npm test
    - Rust: cargo test
    - Go: go test
    - Makefile: make test
    """
    project_type = detect_project_type(path)

    start_time = time.time()
    exit_code = 1
    output = ""
    framework = "unknown"

    if project_type == "python":
        if shutil.which("pytest"):
            framework = "pytest"
            exit_code, output = run_command(["pytest", "-v"], path)
        elif shutil.which("python3"):
            framework = "unittest"
            exit_code, output = run_command(["python3", "-m", "unittest", "discover"], path)
        else:
            output = "No Python test runner found"

    elif project_type == "node":
        package_json = path / "package.json"
        if package_json.exists():
            try:
                pkg = json.loads(package_json.read_text())
                if "test" in pkg.get("scripts", {}):
                    framework = "npm test"
                    exit_code, output = run_command(["npm", "test"], path)
                else:
                    output = "No test script in package.json"
            except json.JSONDecodeError:
                output = "Invalid package.json"

    elif project_type == "rust":
        framework = "cargo test"
        exit_code, output = run_command(["cargo", "test"], path)

    elif project_type == "go":
        framework = "go test"
        exit_code, output = run_command(["go", "test", "./..."], path)

    elif project_type == "makefile":
        makefile = path / "Makefile"
        if "test:" in makefile.read_text():
            framework = "make test"
            exit_code, output = run_command(["make", "test"], path)
        else:
            output = "No 'test' target in Makefile"

    else:
        output = "Could not detect test framework"

    duration = time.time() - start_time
    status = "passed" if exit_code == 0 else "failed"

    if json_output:
        result = {
            "status": status,
            "exit_code": exit_code,
            "duration_seconds": round(duration, 2),
            "framework": framework,
            "output": output[-5000:] if len(output) > 5000 else output,
        }
        print(json.dumps(result, indent=2))
    else:
        if framework != "unknown":
            console.print(f"[dim]Detected: {project_type} ({framework})[/dim]")
        console.print(output)
        console.print()
        if exit_code == 0:
            console.print(f"[green]✓ Tests passed ({duration:.1f}s)[/green]")
        else:
            console.print(f"[red]✗ Tests failed ({duration:.1f}s)[/red]")

    raise typer.Exit(exit_code)


@app.command()
def lint(
    path: Path = typer.Argument(
        ".",
        help="Project path to lint",
        exists=True,
        file_okay=False,
        resolve_path=True,
    ),
    fix: bool = typer.Option(False, "--fix", help="Auto-fix issues where possible"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    Auto-detect linter and check code.

    Supports:
    - Python: ruff, flake8
    - Node.js: eslint
    - Rust: cargo clippy
    - Go: golangci-lint
    """
    project_type = detect_project_type(path)

    exit_code = 1
    output = ""
    linter = "unknown"

    if project_type == "python":
        if shutil.which("ruff"):
            linter = "ruff"
            cmd = ["ruff", "check"]
            if fix:
                cmd.append("--fix")
            cmd.append(".")
            exit_code, output = run_command(cmd, path)
        elif shutil.which("flake8"):
            linter = "flake8"
            exit_code, output = run_command(["flake8", "."], path)
        else:
            output = "No Python linter found (install ruff or flake8)"

    elif project_type == "node":
        if shutil.which("npx"):
            linter = "eslint"
            cmd = ["npx", "eslint"]
            if fix:
                cmd.append("--fix")
            cmd.append(".")
            exit_code, output = run_command(cmd, path)
        else:
            output = "npx not found"

    elif project_type == "rust":
        linter = "clippy"
        cmd = ["cargo", "clippy"]
        if fix:
            cmd.extend(["--fix", "--allow-dirty"])
        exit_code, output = run_command(cmd, path)

    elif project_type == "go":
        if shutil.which("golangci-lint"):
            linter = "golangci-lint"
            cmd = ["golangci-lint", "run"]
            if fix:
                cmd.append("--fix")
            cmd.append("./...")
            exit_code, output = run_command(cmd, path)
        else:
            output = "golangci-lint not found"

    else:
        output = "Could not detect linter"

    status = "clean" if exit_code == 0 else "issues"

    if json_output:
        result = {
            "status": status,
            "exit_code": exit_code,
            "linter": linter,
            "output": output[-5000:] if len(output) > 5000 else output,
        }
        print(json.dumps(result, indent=2))
    else:
        if linter != "unknown":
            console.print(f"[dim]Detected: {project_type} ({linter})[/dim]")
        console.print(output)

    raise typer.Exit(exit_code)


@app.command("git-summary")
def git_summary(
    path: Path = typer.Argument(
        ".",
        help="Git repository path",
        exists=True,
        file_okay=False,
        resolve_path=True,
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    Show git status and recent activity.

    Displays branch, remote, last commit, and pending changes.
    """
    if not (path / ".git").exists():
        err_console.print("[red]Error: Not a git repository[/red]")
        raise typer.Exit(1)

    def git_cmd(args: list[str]) -> str:
        try:
            result = subprocess.run(
                ["git"] + args,
                cwd=path,
                capture_output=True,
                text=True,
                timeout=10,
            )
            return result.stdout.strip() if result.returncode == 0 else ""
        except Exception:
            return ""

    branch = git_cmd(["branch", "--show-current"]) or "detached"
    remote = git_cmd(["remote", "get-url", "origin"]) or "none"
    last_commit = git_cmd(["log", "-1", "--format=%h %s"]) or "none"
    last_commit_date = git_cmd(["log", "-1", "--format=%cr"]) or "unknown"

    # Count changes
    staged = (
        len(git_cmd(["diff", "--cached", "--numstat"]).split("\n"))
        if git_cmd(["diff", "--cached", "--numstat"])
        else 0
    )
    unstaged = (
        len(git_cmd(["diff", "--numstat"]).split("\n")) if git_cmd(["diff", "--numstat"]) else 0
    )
    untracked = (
        len(git_cmd(["ls-files", "--others", "--exclude-standard"]).split("\n"))
        if git_cmd(["ls-files", "--others", "--exclude-standard"])
        else 0
    )

    # Ahead/behind
    ahead = 0
    behind = 0
    try:
        ahead_str = git_cmd(["rev-list", "--count", "@{upstream}..HEAD"])
        behind_str = git_cmd(["rev-list", "--count", "HEAD..@{upstream}"])
        ahead = int(ahead_str) if ahead_str else 0
        behind = int(behind_str) if behind_str else 0
    except ValueError:
        pass

    if json_output:
        result = {
            "branch": branch,
            "remote": remote,
            "last_commit": last_commit,
            "last_commit_date": last_commit_date,
            "staged": staged,
            "unstaged": unstaged,
            "untracked": untracked,
            "ahead": ahead,
            "behind": behind,
        }
        print(json.dumps(result, indent=2))
    else:
        console.print(f"[bold]Branch:[/bold] {branch}")
        console.print(f"[bold]Remote:[/bold] {remote}")
        console.print()
        console.print(f"[bold]Last commit:[/bold] {last_commit}")
        console.print(f"             ({last_commit_date})")
        console.print()
        console.print("[bold]Changes:[/bold]")
        console.print(f"  Staged:    {staged} files")
        console.print(f"  Unstaged:  {unstaged} files")
        console.print(f"  Untracked: {untracked} files")

        if ahead > 0 or behind > 0:
            console.print()
            console.print(f"[bold]Sync:[/bold] ↑{ahead} ↓{behind}")
