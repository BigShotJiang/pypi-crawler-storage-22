"""
Notification tools.

Commands:
- send: Send a notification via Telegram
"""

import asyncio
import json
import sys

import typer
from rich.console import Console

from ..config import get_chat_id, get_telegram_token

app = typer.Typer(
    name="notify",
    help="Send notifications via Telegram.",
    no_args_is_help=True,
)

console = Console()
err_console = Console(stderr=True)

MAX_MSG_LENGTH = 4000


def chunk_message(message: str, max_len: int = MAX_MSG_LENGTH) -> list[str]:
    """Split message into Telegram-safe chunks."""
    if len(message) <= max_len:
        return [message]

    chunks = []
    remaining = message

    while len(remaining) > max_len:
        # Try to split at newline
        cut = remaining.rfind("\n", 0, max_len)
        if cut == -1 or cut < max_len * 0.5:
            cut = max_len
        chunks.append(remaining[:cut])
        remaining = remaining[cut:].lstrip("\n")

    if remaining:
        chunks.append(remaining)

    return chunks


async def send_telegram(message: str) -> tuple[bool, str]:
    """Send a message via Telegram."""
    try:
        from telegram import Bot
        from telegram.constants import ParseMode
    except ImportError:
        return False, "python-telegram-bot not installed. Run: pip install python-telegram-bot"

    token = get_telegram_token()
    chat_id = get_chat_id()

    if not token:
        return False, "TELEGRAM_BOT_TOKEN not found in environment or ~/.otto/config/.env"

    if not chat_id:
        return False, "No chat_id registered. Message the bot with /start first."

    try:
        bot = Bot(token=token)
        chunks = chunk_message(message)

        for chunk in chunks:
            await bot.send_message(
                chat_id=chat_id,
                text=chunk,
                parse_mode=ParseMode.HTML,
            )

        return True, f"Sent {len(chunks)} message(s) to chat {chat_id}"

    except Exception as e:
        return False, f"Telegram error: {e}"


@app.command()
def send(
    message: list[str] | None = typer.Argument(None, help="Message to send"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    Send a notification via Telegram.

    Message can be provided as arguments or piped via stdin.
    Supports HTML formatting: <b>bold</b>, <i>italic</i>, <code>code</code>

    Examples:
        otto notify send "Task complete"
        echo "Build failed" | otto notify send
    """
    # Get message from args or stdin
    if message:
        message_str = " ".join(message)
    elif not sys.stdin.isatty():
        message_str = sys.stdin.read().strip()
    else:
        err_console.print("[red]Error: No message provided[/red]")
        err_console.print("Usage: otto notify send <message>")
        err_console.print("       echo 'message' | otto notify send")
        raise typer.Exit(1)

    if not message_str:
        err_console.print("[red]Error: Empty message[/red]")
        raise typer.Exit(1)

    # Send the notification
    success, result = asyncio.run(send_telegram(message_str))

    if json_output:
        output = {
            "success": success,
            "message": result,
        }
        print(json.dumps(output, indent=2))
    else:
        if success:
            console.print(f"[green]✓ {result}[/green]")
        else:
            err_console.print(f"[red]✗ {result}[/red]")
            raise typer.Exit(1)


# Alias for convenience - allows `otto notify "message"` without 'send'
@app.callback(invoke_without_command=True)
def notify_callback(
    ctx: typer.Context,
    message: list[str] | None = typer.Argument(None, help="Message to send (shortcut)"),
):
    """
    Send notifications via Telegram.

    You can use 'otto notify send <message>' or just 'otto notify <message>'.
    """
    if ctx.invoked_subcommand is None and message:
        # Directly invoked with a message - call send
        ctx.invoke(send, message=message)
