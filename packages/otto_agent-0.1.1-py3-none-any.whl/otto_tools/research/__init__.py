"""
Research tools for web search and information gathering.

Commands:
- search: Web search using DuckDuckGo
- summarize: Summarize text or URL (placeholder)
"""

import json
import urllib.parse
import urllib.request

import typer
from rich.console import Console

app = typer.Typer(
    name="research",
    help="Web search and information gathering.",
    no_args_is_help=True,
)

console = Console()
err_console = Console(stderr=True)


def search_duckduckgo(query: str, limit: int = 5) -> dict:
    """Search using DuckDuckGo instant answers API."""
    try:
        encoded = urllib.parse.quote(query)
        url = f"https://api.duckduckgo.com/?q={encoded}&format=json&no_html=1"

        req = urllib.request.Request(url, headers={"User-Agent": "Otto/1.0"})
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode())

        results = []

        # Abstract (main answer)
        if data.get("Abstract"):
            results.append(
                {
                    "title": data.get("Heading", "Answer"),
                    "snippet": data["Abstract"],
                    "url": data.get("AbstractURL", ""),
                }
            )

        # Related topics
        for topic in data.get("RelatedTopics", []):
            if len(results) >= limit:
                break
            if isinstance(topic, dict) and topic.get("Text"):
                url = topic.get("FirstURL", "")
                title = url.split("/")[-1].replace("_", " ") if url else "Related"
                results.append({"title": title, "snippet": topic["Text"], "url": url})

        return {"results": results[:limit], "source": "duckduckgo"}

    except urllib.error.URLError as e:
        return {"error": f"Network error: {e.reason}", "source": "duckduckgo"}
    except json.JSONDecodeError:
        return {"error": "Invalid response from DuckDuckGo", "source": "duckduckgo"}
    except Exception as e:
        return {"error": str(e), "source": "duckduckgo"}


@app.command()
def search(
    query: list[str] = typer.Argument(..., help="Search query"),
    limit: int = typer.Option(5, "--limit", "-n", help="Maximum results"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    Search the web using DuckDuckGo.

    Returns instant answers and related topics.
    """
    query_str = " ".join(query)

    if not query_str.strip():
        err_console.print("[red]Error: No query provided[/red]")
        raise typer.Exit(1)

    result = search_duckduckgo(query_str, limit)

    if json_output:
        result["query"] = query_str
        print(json.dumps(result, indent=2))
    else:
        if "error" in result:
            err_console.print(f"[red]Search error: {result['error']}[/red]")
            raise typer.Exit(1)

        results = result.get("results", [])
        if not results:
            console.print(f"No results for: {query_str}")
            return

        console.print(f"[bold]Results for:[/bold] {query_str}")
        console.print(f"[dim]Source: {result.get('source', 'unknown')}[/dim]")
        console.print()

        for i, r in enumerate(results, 1):
            title = r.get("title", "No title")
            console.print(f"[cyan]{i}. {title}[/cyan]")

            snippet = r.get("snippet", "")
            if snippet:
                # Truncate long snippets
                if len(snippet) > 200:
                    snippet = snippet[:200] + "..."
                console.print(f"   {snippet}")

            url = r.get("url", "")
            if url:
                console.print(f"   [dim]→ {url}[/dim]")

            console.print()


@app.command()
def summarize(
    source: str = typer.Argument(..., help="Text or URL to summarize"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    Summarize text or a URL.

    Note: This is a placeholder - full summarization requires an LLM backend.
    """
    # Check if it's a URL
    is_url = source.startswith("http://") or source.startswith("https://")

    if is_url:
        # Fetch URL content
        try:
            req = urllib.request.Request(source, headers={"User-Agent": "Otto/1.0"})
            with urllib.request.urlopen(req, timeout=10) as response:
                content = response.read().decode("utf-8", errors="ignore")

            # Very basic text extraction (remove HTML tags)
            import re

            text = re.sub(r"<[^>]+>", " ", content)
            text = re.sub(r"\s+", " ", text).strip()
            text = text[:2000]  # Limit length

        except Exception as e:
            if json_output:
                print(json.dumps({"error": str(e)}))
            else:
                err_console.print(f"[red]Error fetching URL: {e}[/red]")
            raise typer.Exit(1)
    else:
        text = source

    # Simple "summary" - just show first portion
    # Real summarization would require an LLM
    summary = text[:500] + "..." if len(text) > 500 else text
    word_count = len(text.split())

    if json_output:
        output = {
            "source": source if is_url else "text",
            "word_count": word_count,
            "summary": summary,
            "note": "Basic truncation - full summarization requires LLM",
        }
        print(json.dumps(output, indent=2))
    else:
        console.print("[bold]Summary:[/bold]")
        console.print(summary)
        console.print()
        console.print(
            f"[dim]Words: {word_count} | Note: Basic truncation, full summarization requires LLM[/dim]"
        )
