"""
Otto Skills System

Implements the Agent Skills specification (agentskills.io) for Otto.
Skills are directories containing SKILL.md files with metadata and instructions.
"""

from .executor import SkillExecutor
from .loader import Skill, SkillLoader

__all__ = ["SkillLoader", "Skill", "SkillExecutor"]
