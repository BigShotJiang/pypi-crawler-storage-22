"""
Skill Executor - Runs skill scripts and manages skill execution.

Handles:
- Script execution in sandboxed environments
- Resource access and loading
- Execution logging and auditing
"""

import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from otto.paths import OTTO_HOME

from .loader import Skill


@dataclass
class ExecutionResult:
    """Result of a script execution."""

    success: bool
    output: str
    error: str
    exit_code: int


class SkillExecutor:
    """
    Executes skill scripts and manages resources.

    Provides sandboxed execution of skill scripts with proper
    environment setup and security considerations.
    """

    def __init__(self, work_dir: Path | None = None):
        """
        Initialize the executor.

        Args:
            work_dir: Working directory for script execution.
                     Defaults to ~/.otto/skill-work/
        """
        if work_dir is None:
            work_dir = OTTO_HOME / "skill-work"

        self.work_dir = Path(work_dir)
        self.work_dir.mkdir(parents=True, exist_ok=True)

    def run_script(
        self,
        skill: Skill,
        script_name: str,
        args: list[str] = None,
        stdin: str = None,
        timeout: int = 300,
        env: dict = None,
    ) -> ExecutionResult:
        """
        Execute a skill script.

        Args:
            skill: The skill containing the script
            script_name: Name of the script in scripts/ directory
            args: Command line arguments
            stdin: Input to pass to script
            timeout: Execution timeout in seconds
            env: Additional environment variables

        Returns:
            ExecutionResult with output and status
        """
        script_path = skill.get_script(script_name)
        if not script_path:
            return ExecutionResult(
                success=False, output="", error=f"Script not found: {script_name}", exit_code=1
            )

        # Prepare environment
        exec_env = os.environ.copy()
        exec_env.update(
            {
                "SKILL_NAME": skill.name,
                "SKILL_PATH": str(skill.path),
                "SKILL_WORK_DIR": str(self.work_dir),
            }
        )
        if env:
            exec_env.update(env)

        # Prepare command
        cmd = [str(script_path)]
        if args:
            cmd.extend(args)

        # Determine interpreter
        suffix = script_path.suffix.lower()
        if suffix == ".py":
            # Use the current interpreter so this works with pipx/uv tools installs.
            cmd = [sys.executable] + cmd
        elif suffix == ".sh":
            cmd = ["bash"] + cmd
        elif suffix == ".js":
            cmd = ["node"] + cmd

        try:
            result = subprocess.run(
                cmd,
                cwd=str(self.work_dir),
                env=exec_env,
                input=stdin,
                capture_output=True,
                text=True,
                timeout=timeout,
            )

            return ExecutionResult(
                success=result.returncode == 0,
                output=result.stdout,
                error=result.stderr,
                exit_code=result.returncode,
            )

        except subprocess.TimeoutExpired:
            return ExecutionResult(
                success=False, output="", error=f"Script timed out after {timeout}s", exit_code=-1
            )
        except Exception as e:
            return ExecutionResult(success=False, output="", error=str(e), exit_code=-1)

    def read_reference(self, skill: Skill, ref_name: str) -> str | None:
        """
        Read a reference document from a skill.

        Args:
            skill: The skill containing the reference
            ref_name: Name of the reference file

        Returns:
            Content of the reference file, or None if not found
        """
        ref_path = skill.get_reference(ref_name)
        if ref_path and ref_path.exists():
            return ref_path.read_text()
        return None

    def get_asset_path(self, skill: Skill, asset_name: str) -> Path | None:
        """
        Get the path to a skill asset.

        Args:
            skill: The skill containing the asset
            asset_name: Name of the asset file

        Returns:
            Path to the asset, or None if not found
        """
        asset_path = skill.path / "assets" / asset_name
        if asset_path.exists():
            return asset_path
        return None

    def list_available_scripts(self, skill: Skill) -> list[dict]:
        """
        List all available scripts in a skill with metadata.

        Returns:
            List of dicts with script info
        """
        scripts_dir = skill.path / "scripts"
        if not scripts_dir.exists():
            return []

        result = []
        for script in scripts_dir.iterdir():
            if script.is_file():
                result.append(
                    {
                        "name": script.name,
                        "path": str(script),
                        "executable": os.access(script, os.X_OK),
                        "size": script.stat().st_size,
                    }
                )
        return result
