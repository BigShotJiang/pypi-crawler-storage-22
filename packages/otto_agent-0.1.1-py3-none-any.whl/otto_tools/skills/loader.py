"""
Skill Loader - Discovers and loads Agent Skills from configured directories.

Implements the Agent Skills specification:
- Scans directories for SKILL.md files
- Parses YAML frontmatter for metadata
- Supports progressive disclosure (metadata -> full content -> resources)
"""

import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from otto.paths import SKILLS_DIR


@dataclass
class SkillMetadata:
    """Skill metadata from YAML frontmatter."""

    name: str
    description: str
    license: str | None = None
    compatibility: str | None = None
    metadata: dict = field(default_factory=dict)
    allowed_tools: list = field(default_factory=list)


@dataclass
class Skill:
    """
    Represents an Agent Skill.

    Attributes:
        path: Absolute path to skill directory
        meta: Parsed metadata from frontmatter
        content: Full SKILL.md content (loaded on activation)
        scripts: Available scripts in scripts/ directory
        references: Available reference docs
        assets: Available asset files
    """

    path: Path
    meta: SkillMetadata
    content: str | None = None
    scripts: list = field(default_factory=list)
    references: list = field(default_factory=list)
    assets: list = field(default_factory=list)

    @property
    def name(self) -> str:
        return self.meta.name

    @property
    def description(self) -> str:
        return self.meta.description

    @property
    def skill_md_path(self) -> Path:
        return self.path / "SKILL.md"

    def is_loaded(self) -> bool:
        """Check if full content has been loaded."""
        return self.content is not None

    def get_script(self, name: str) -> Path | None:
        """Get path to a script by name."""
        script_path = self.path / "scripts" / name
        if script_path.exists():
            return script_path
        return None

    def get_reference(self, name: str) -> Path | None:
        """Get path to a reference doc by name."""
        ref_path = self.path / "references" / name
        if ref_path.exists():
            return ref_path
        return None

    def to_prompt_xml(self) -> str:
        """Generate XML for inclusion in agent prompts."""
        return f"""<skill>
  <name>{self.meta.name}</name>
  <description>{self.meta.description}</description>
  <location>{self.skill_md_path}</location>
</skill>"""


class SkillLoader:
    """
    Discovers and loads skills from configured directories.

    Usage:
        loader = SkillLoader(["/path/to/skills"])
        skills = loader.discover()

        # Get metadata for all skills (lightweight)
        for skill in skills:
            print(f"{skill.name}: {skill.description}")

        # Activate a skill (load full content)
        loader.activate(skill)
        print(skill.content)
    """

    # Regex to extract YAML frontmatter
    FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)

    # Name validation pattern (per spec)
    NAME_RE = re.compile(r"^[a-z][a-z0-9-]*[a-z0-9]$|^[a-z]$")

    def __init__(self, skill_dirs: list[str | Path] = None):
        """
        Initialize the skill loader.

        Args:
            skill_dirs: List of directories to scan for skills.
                       Defaults to ~/.otto/skills/
        """
        if skill_dirs is None:
            skill_dirs = [SKILLS_DIR]

        self.skill_dirs = [Path(d).expanduser() for d in skill_dirs]
        self._skills: dict[str, Skill] = {}

    def discover(self) -> list[Skill]:
        """
        Discover all valid skills in configured directories.

        Returns:
            List of Skill objects with metadata loaded.
        """
        self._skills.clear()

        for skill_dir in self.skill_dirs:
            if not skill_dir.exists():
                continue

            for entry in skill_dir.iterdir():
                if not entry.is_dir():
                    continue

                skill_md = entry / "SKILL.md"
                if not skill_md.exists():
                    continue

                try:
                    skill = self._load_skill_metadata(entry)
                    if skill:
                        self._skills[skill.name] = skill
                except Exception as e:
                    print(f"Warning: Failed to load skill from {entry}: {e}")

        return list(self._skills.values())

    def _load_skill_metadata(self, skill_path: Path) -> Skill | None:
        """Load just the metadata from a skill's SKILL.md."""
        skill_md = skill_path / "SKILL.md"
        content = skill_md.read_text()

        # Extract frontmatter
        match = self.FRONTMATTER_RE.match(content)
        if not match:
            raise ValueError(f"No valid frontmatter found in {skill_md}")

        frontmatter = yaml.safe_load(match.group(1))

        # Validate required fields
        if "name" not in frontmatter:
            raise ValueError("Missing required 'name' field")
        if "description" not in frontmatter:
            raise ValueError("Missing required 'description' field")

        name = frontmatter["name"]

        # Validate name format
        if not self._validate_name(name):
            raise ValueError(f"Invalid skill name: {name}")

        # Name must match directory
        if name != skill_path.name:
            raise ValueError(f"Skill name '{name}' doesn't match directory '{skill_path.name}'")

        # Parse allowed-tools
        allowed_tools = []
        if "allowed-tools" in frontmatter:
            allowed_tools = frontmatter["allowed-tools"].split()

        meta = SkillMetadata(
            name=name,
            description=frontmatter["description"],
            license=frontmatter.get("license"),
            compatibility=frontmatter.get("compatibility"),
            metadata=frontmatter.get("metadata", {}),
            allowed_tools=allowed_tools,
        )

        # Discover optional directories
        scripts = self._list_dir(skill_path / "scripts")
        references = self._list_dir(skill_path / "references")
        assets = self._list_dir(skill_path / "assets")

        return Skill(
            path=skill_path, meta=meta, scripts=scripts, references=references, assets=assets
        )

    def _validate_name(self, name: str) -> bool:
        """Validate skill name per specification."""
        if not name or len(name) > 64:
            return False
        if "--" in name:
            return False
        if name.startswith("-") or name.endswith("-"):
            return False
        return bool(self.NAME_RE.match(name))

    def _list_dir(self, path: Path) -> list[str]:
        """List files in a directory, returning empty list if doesn't exist."""
        if not path.exists():
            return []
        return [f.name for f in path.iterdir() if f.is_file()]

    def get(self, name: str) -> Skill | None:
        """Get a skill by name."""
        return self._skills.get(name)

    def activate(self, skill: Skill) -> None:
        """
        Activate a skill by loading its full content.

        This loads the complete SKILL.md content for injection into context.
        """
        if skill.is_loaded():
            return

        content = skill.skill_md_path.read_text()

        # Remove frontmatter for the content
        match = self.FRONTMATTER_RE.match(content)
        if match:
            skill.content = content[match.end() :]
        else:
            skill.content = content

    def generate_prompt_xml(self) -> str:
        """
        Generate <available_skills> XML for all discovered skills.

        This should be injected into the agent's system prompt.
        """
        if not self._skills:
            self.discover()

        skills_xml = "\n".join(s.to_prompt_xml() for s in self._skills.values())
        return f"<available_skills>\n{skills_xml}\n</available_skills>"


def main():
    """CLI entry point for skill operations."""
    import sys

    loader = SkillLoader()
    skills = loader.discover()

    if len(sys.argv) < 2:
        print("Otto Skills")
        print("=" * 40)
        for skill in skills:
            print(f"\n{skill.name}")
            print(f"  {skill.description}")
            if skill.scripts:
                print(f"  Scripts: {', '.join(skill.scripts)}")
        return

    cmd = sys.argv[1]

    if cmd == "list":
        for skill in skills:
            print(f"{skill.name}: {skill.description}")

    elif cmd == "show" and len(sys.argv) > 2:
        name = sys.argv[2]
        skill = loader.get(name)
        if skill:
            loader.activate(skill)
            print(f"# {skill.name}\n")
            print(skill.content)
        else:
            print(f"Skill not found: {name}")
            sys.exit(1)

    elif cmd == "prompt":
        print(loader.generate_prompt_xml())

    elif cmd == "validate" and len(sys.argv) > 2:
        path = Path(sys.argv[2])
        try:
            skill = loader._load_skill_metadata(path)
            print(f"Valid skill: {skill.name}")
            print(f"Description: {skill.description}")
        except Exception as e:
            print(f"Invalid: {e}")
            sys.exit(1)

    else:
        print("Usage: otto-skills [list|show <name>|prompt|validate <path>]")


if __name__ == "__main__":
    main()
