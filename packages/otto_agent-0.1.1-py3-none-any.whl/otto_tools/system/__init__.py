"""
System information and monitoring tools.

Commands:
- info: System information summary
- ports: List listening ports
- check-service: Check if a service is running
"""

import json
import os
import platform
import re
import shutil
import signal
import subprocess
import time

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(
    name="system",
    help="System information and monitoring tools.",
    no_args_is_help=True,
)

console = Console()
err_console = Console(stderr=True)


def get_uptime() -> str:
    """Get system uptime."""
    try:
        result = subprocess.run(["uptime", "-p"], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass

    # Fallback
    try:
        result = subprocess.run(["uptime"], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            # Parse traditional uptime output
            output = result.stdout.strip()
            match = re.search(r"up\s+(.+?),\s+\d+\s+user", output)
            if match:
                return match.group(1)
    except Exception:
        pass

    return "unknown"


def get_load_average() -> str:
    """Get system load average."""
    try:
        with open("/proc/loadavg") as f:
            parts = f.read().split()[:3]
            return " ".join(parts)
    except Exception:
        pass

    try:
        result = subprocess.run(["uptime"], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            match = re.search(r"load average:\s*(.+)$", result.stdout)
            if match:
                return match.group(1).strip()
    except Exception:
        pass

    return "N/A"


def get_memory_info() -> tuple[str, str]:
    """Get memory total and used."""
    try:
        result = subprocess.run(["free", "-h"], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            for line in result.stdout.split("\n"):
                if line.startswith("Mem:"):
                    parts = line.split()
                    return parts[1], parts[2]
    except Exception:
        pass
    return "N/A", "N/A"


def get_disk_usage() -> str:
    """Get root disk usage percentage."""
    try:
        result = subprocess.run(["df", "-h", "/"], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            lines = result.stdout.strip().split("\n")
            if len(lines) >= 2:
                parts = lines[1].split()
                return parts[4] if len(parts) >= 5 else "N/A"
    except Exception:
        pass
    return "N/A"


def _read_meminfo_kb() -> dict[str, int]:
    info: dict[str, int] = {}
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 2 and parts[1].isdigit():
                    key = parts[0].rstrip(":")
                    info[key] = int(parts[1])
    except Exception:
        return {}
    return info


def get_memory_usage_percent() -> float | None:
    """Return system memory used percent (Linux) or None if unavailable."""
    info = _read_meminfo_kb()
    total = info.get("MemTotal")
    avail = info.get("MemAvailable")
    if not total or not avail:
        return None
    used = total - avail
    if total <= 0:
        return None
    return (used / total) * 100.0


def _list_process_usage() -> list[dict]:
    """Return per-process CPU/mem usage using `ps` (best-effort)."""
    if not shutil.which("ps"):
        return []
    try:
        r = subprocess.run(
            ["ps", "-eo", "pid,pcpu,pmem,comm,args", "--no-headers"],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except Exception:
        return []
    if r.returncode != 0:
        return []

    procs: list[dict] = []
    for line in r.stdout.splitlines():
        parts = line.strip().split(None, 4)
        if len(parts) < 4:
            continue
        try:
            pid = int(parts[0])
            pcpu = float(parts[1])
            pmem = float(parts[2])
        except ValueError:
            continue
        comm = parts[3]
        args = parts[4] if len(parts) >= 5 else comm
        procs.append({"pid": pid, "cpu": pcpu, "mem": pmem, "comm": comm, "args": args})
    return procs


def _is_pid_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def _terminate_pid(
    pid: int, *, force: bool = False, grace_seconds: float = 3.0
) -> tuple[bool, str]:
    try:
        os.kill(pid, signal.SIGTERM)
    except PermissionError:
        return False, "permission denied"
    except ProcessLookupError:
        return True, "already exited"
    except Exception as e:
        return False, str(e)

    if not force:
        return True, "sigterm sent"

    # Wait briefly, then SIGKILL if still alive.
    deadline = time.time() + max(0.0, float(grace_seconds))
    while time.time() < deadline:
        if not _is_pid_running(pid):
            return True, "terminated"
        time.sleep(0.1)

    try:
        os.kill(pid, signal.SIGKILL)
        return True, "sigkill sent"
    except ProcessLookupError:
        return True, "terminated"
    except PermissionError:
        return False, "permission denied (sigkill)"
    except Exception as e:
        return False, str(e)


def get_docker_container_count() -> int:
    """Get number of running Docker containers."""
    try:
        result = subprocess.run(["docker", "ps", "-q"], capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            return len(result.stdout.strip().split("\n")) if result.stdout.strip() else 0
    except Exception:
        pass
    return 0


@app.command()
def info(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    Display system information summary.

    Shows hostname, OS, kernel, uptime, load, memory, disk, and Docker stats.
    """
    hostname = platform.node()
    os_name = platform.system()
    arch = platform.machine()
    kernel = platform.release()
    uptime = get_uptime()
    load = get_load_average()
    mem_total, mem_used = get_memory_info()
    disk_usage = get_disk_usage()
    docker_containers = get_docker_container_count()

    if json_output:
        output = {
            "hostname": hostname,
            "os": os_name,
            "arch": arch,
            "kernel": kernel,
            "uptime": uptime,
            "load": load,
            "memory_total": mem_total,
            "memory_used": mem_used,
            "disk_usage": disk_usage,
            "docker_containers": docker_containers,
        }
        print(json.dumps(output, indent=2))
    else:
        console.print(f"[bold]System:[/bold] {hostname} ({os_name} {arch})")
        console.print(f"[bold]Kernel:[/bold] {kernel}")
        console.print(f"[bold]Uptime:[/bold] {uptime}")
        console.print(f"[bold]Load:[/bold]   {load}")
        console.print(f"[bold]Memory:[/bold] {mem_used} / {mem_total}")
        console.print(f"[bold]Disk:[/bold]   {disk_usage} used")
        console.print(f"[bold]Docker:[/bold] {docker_containers} containers running")


@app.command()
def monitor(
    cpu_load_threshold: float = typer.Option(
        1.5, "--cpu-load", help="Alert when 1m load / CPU count exceeds this"
    ),
    mem_used_threshold: float = typer.Option(
        90.0, "--mem-used", help="Alert when system memory used percent exceeds this"
    ),
    proc_cpu_threshold: float = typer.Option(
        200.0, "--proc-cpu", help="Flag processes using >= this CPU percent"
    ),
    proc_mem_threshold: float = typer.Option(
        50.0, "--proc-mem", help="Flag processes using >= this memory percent"
    ),
    kill: bool = typer.Option(False, "--kill", help="Terminate flagged processes"),
    force: bool = typer.Option(
        False, "--force", help="After SIGTERM, send SIGKILL if still running"
    ),
    grace_seconds: float = typer.Option(
        3.0, "--grace", help="Seconds to wait before SIGKILL when using --force"
    ),
    limit: int = typer.Option(10, "--limit", help="Max processes to display/kill"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    Resource monitoring with optional runaway process termination.

    Reports load, memory usage, and top per-process CPU/memory usage. When --kill is set,
    terminates processes exceeding thresholds (best-effort).
    """
    cpu_count = os.cpu_count() or 1
    load1, load5, load15 = (0.0, 0.0, 0.0)
    try:
        load1, load5, load15 = os.getloadavg()
    except Exception:
        pass
    load_per_cpu = load1 / cpu_count if cpu_count > 0 else load1

    mem_used_pct = get_memory_usage_percent()
    procs = _list_process_usage()

    offenders = [
        p
        for p in procs
        if (float(p.get("cpu", 0.0)) >= float(proc_cpu_threshold))
        or (float(p.get("mem", 0.0)) >= float(proc_mem_threshold))
    ]
    offenders.sort(key=lambda p: (float(p.get("cpu", 0.0)), float(p.get("mem", 0.0))), reverse=True)
    offenders = offenders[: max(0, int(limit))]

    alerts: list[str] = []
    if cpu_load_threshold > 0 and load_per_cpu >= cpu_load_threshold:
        alerts.append(f"High CPU load: {load1:.2f} (per-cpu {load_per_cpu:.2f})")
    if mem_used_threshold > 0 and mem_used_pct is not None and mem_used_pct >= mem_used_threshold:
        alerts.append(f"High memory use: {mem_used_pct:.1f}%")
    if offenders:
        alerts.append(f"Runaway candidates: {len(offenders)}")

    killed: list[dict] = []
    if kill and offenders:
        self_pid = os.getpid()
        for proc in offenders:
            pid = int(proc.get("pid", 0) or 0)
            if pid in {0, 1, self_pid}:
                continue
            ok, msg = _terminate_pid(pid, force=force, grace_seconds=grace_seconds)
            killed.append({"pid": pid, "ok": ok, "message": msg, "comm": proc.get("comm")})

    output = {
        "cpu_count": cpu_count,
        "load": {"1m": load1, "5m": load5, "15m": load15, "per_cpu_1m": load_per_cpu},
        "memory_used_percent": mem_used_pct,
        "thresholds": {
            "cpu_load": cpu_load_threshold,
            "mem_used": mem_used_threshold,
            "proc_cpu": proc_cpu_threshold,
            "proc_mem": proc_mem_threshold,
        },
        "alerts": alerts,
        "offenders": offenders,
        "killed": killed,
    }

    if json_output:
        print(json.dumps(output, indent=2))
        if alerts:
            raise typer.Exit(1)
        return

    console.print(
        f"[bold]Load:[/bold] {load1:.2f} {load5:.2f} {load15:.2f} (per-cpu {load_per_cpu:.2f})"
    )
    if mem_used_pct is not None:
        console.print(f"[bold]Memory used:[/bold] {mem_used_pct:.1f}%")
    else:
        console.print("[bold]Memory used:[/bold] N/A")

    if alerts:
        err_console.print("[red]Alerts:[/red]")
        for a in alerts:
            err_console.print(f"  - {a}")

    if offenders:
        table = Table(title="Runaway Candidates")
        table.add_column("PID", style="cyan")
        table.add_column("CPU%", style="yellow", justify="right")
        table.add_column("MEM%", style="magenta", justify="right")
        table.add_column("CMD", style="green")
        for p in offenders:
            table.add_row(
                str(p["pid"]),
                f"{float(p['cpu']):.1f}",
                f"{float(p['mem']):.1f}",
                str(p.get("comm") or "")[:30],
            )
        console.print(table)

    if killed:
        table = Table(title="Terminations")
        table.add_column("PID", style="cyan")
        table.add_column("OK", style="green")
        table.add_column("Message", style="white")
        for k in killed:
            table.add_row(str(k["pid"]), "yes" if k["ok"] else "no", str(k["message"]))
        console.print(table)

    if alerts:
        raise typer.Exit(1)


@app.command()
def ports(
    port_filter: int | None = typer.Argument(None, help="Filter by specific port"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    List listening ports and their processes.

    Optionally filter by a specific port number.
    """
    if not shutil.which("ss"):
        err_console.print("[red]Error: 'ss' command not found[/red]")
        raise typer.Exit(1)

    try:
        result = subprocess.run(["ss", "-tlnp"], capture_output=True, text=True, timeout=10)
        if result.returncode != 0:
            err_console.print("[red]Error running ss command[/red]")
            raise typer.Exit(1)
    except subprocess.TimeoutExpired:
        err_console.print("[red]Error: ss command timed out[/red]")
        raise typer.Exit(1)

    lines = result.stdout.strip().split("\n")[1:]  # Skip header
    ports_data = []

    for line in lines:
        parts = line.split()
        if len(parts) < 5:
            continue

        local_addr = parts[3]
        # Parse address:port
        if "]:" in local_addr:  # IPv6
            addr, port = local_addr.rsplit(":", 1)
        else:
            addr, port = local_addr.rsplit(":", 1)

        try:
            port_num = int(port)
        except ValueError:
            continue

        if port_filter is not None and port_num != port_filter:
            continue

        # Parse process info
        process_info = parts[-1] if len(parts) >= 6 else ""
        proc_match = re.search(r'users:\(\("([^"]+)"', process_info)
        pid_match = re.search(r"pid=(\d+)", process_info)

        proc_name = proc_match.group(1) if proc_match else "unknown"
        pid = int(pid_match.group(1)) if pid_match else 0

        ports_data.append(
            {
                "port": port_num,
                "address": addr,
                "process": proc_name,
                "pid": pid,
            }
        )

    if json_output:
        print(json.dumps(ports_data, indent=2))
    else:
        if not ports_data:
            console.print("No listening ports found.")
            return

        table = Table(title="Listening Ports")
        table.add_column("Port", style="cyan")
        table.add_column("Address", style="green")
        table.add_column("Process", style="yellow")
        table.add_column("PID", style="dim")

        for p in ports_data:
            table.add_row(
                str(p["port"]), p["address"], p["process"], str(p["pid"]) if p["pid"] else "-"
            )

        console.print(table)


@app.command("check-service")
def check_service(
    name: str = typer.Argument(..., help="Service or process name to check"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    Check if a service or process is running.

    Checks systemd (system and user), then falls back to process search.
    """
    result = {
        "name": name,
        "running": False,
        "systemd": "unknown",
        "user_systemd": "unknown",
        "process_count": 0,
    }

    # Check system systemd
    if shutil.which("systemctl"):
        try:
            r = subprocess.run(
                ["systemctl", "is-active", "--quiet", name], capture_output=True, timeout=5
            )
            if r.returncode == 0:
                result["systemd"] = "active"
                result["running"] = True
            else:
                # Check if unit exists
                r2 = subprocess.run(
                    ["systemctl", "list-unit-files", name],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if name in r2.stdout:
                    result["systemd"] = "inactive"
                else:
                    result["systemd"] = "not-found"
        except Exception:
            pass

        # Check user systemd
        try:
            r = subprocess.run(
                ["systemctl", "--user", "is-active", "--quiet", name],
                capture_output=True,
                timeout=5,
            )
            if r.returncode == 0:
                result["user_systemd"] = "active"
                result["running"] = True
            else:
                r2 = subprocess.run(
                    ["systemctl", "--user", "list-unit-files"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if name in r2.stdout:
                    result["user_systemd"] = "inactive"
                else:
                    result["user_systemd"] = "not-found"
        except Exception:
            pass

    # Check processes
    if shutil.which("pgrep"):
        try:
            r = subprocess.run(["pgrep", "-fc", name], capture_output=True, text=True, timeout=5)
            if r.returncode == 0:
                count = int(r.stdout.strip())
                result["process_count"] = count
                if count > 0:
                    result["running"] = True
        except Exception:
            pass

    if json_output:
        print(json.dumps(result, indent=2))
    else:
        if result["running"]:
            console.print(f"[green]✓[/green] {name} is running")
            if result["systemd"] == "active":
                console.print("  - systemd: active")
            if result["user_systemd"] == "active":
                console.print("  - user systemd: active")
            if result["process_count"] > 0:
                console.print(f"  - processes: {result['process_count']}")
        else:
            console.print(f"[red]✗[/red] {name} is not running")
            raise typer.Exit(1)
