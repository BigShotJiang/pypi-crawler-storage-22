<p align="center">
  <img src="docs/assets/otto-logo.png" alt="Otto" width="200" />
</p>

<h1 align="center">Otto</h1>

<p align="center">
  <strong>Your personal AI agent that actually gets things done.</strong>
</p>

<p align="center">
  <a href="#"><img src="https://img.shields.io/badge/build-passing-brightgreen" alt="Build Status" /></a>
  <a href="#"><img src="https://img.shields.io/badge/version-0.1.0-blue" alt="Version" /></a>
  <a href="LICENSE"><img src="https://img.shields.io/badge/license-MIT-green" alt="License" /></a>
  <a href="#"><img src="https://img.shields.io/badge/python-3.10+-yellow" alt="Python" /></a>
</p>

<p align="center">
  <a href="#quick-install">Install</a> •
  <a href="#features">Features</a> •
  <a href="#quick-start">Quick Start</a> •
  <a href="docs/guide/01-architecture.md">Docs</a> •
  <a href="#contributing">Contributing</a>
</p>

---

Otto is a self-hosted AI assistant that lives on your infrastructure and talks to you through Telegram. She can spawn background agents, run scheduled tasks, manage your tools through an MCP gateway, and actually remember what you talked about last week.

No cloud platform. No vendor lock-in. Just your own AI agent that works for you.

## Quick Install

**One-liner:**

```bash
curl -fsSL https://raw.githubusercontent.com/1broseidon/otto/main/install.sh | bash
```

**Or clone and install:**

```bash
git clone https://github.com/1broseidon/otto.git ~/agent
cd ~/agent && ./install.sh
```

The installer sets up everything: Python environment, dependencies, and prompts for your Telegram bot token.

## Features

### 🌐 MCP Gateway with Tool Routing
Unified tool access through the Model Context Protocol. Connect filesystem, browser, search, and custom tools—configured once, available to all backends. Policy-based access control keeps things safe.

### 🤖 Multi-Backend Support
Swap between Claude SDK, Codex, and other backends based on the task. Use Claude for complex reasoning, Codex for code generation—Otto routes automatically or lets you choose.

### 💬 Telegram Integration
Chat with Otto like a friend. Send text, voice messages, or files. Get notifications when background tasks complete. Configure settings through conversation.

### ⏰ Scheduled Tasks & Pipelines
Schedule one-off tasks or recurring jobs with cron expressions. Chain multiple steps into pipelines with dependencies. Otto runs them in the background and pings you when done.

### 🧠 Session Management
Conversations are persistent. Fork a session to explore a tangent. Switch between contexts. Pick up where you left off.

### 💾 Memory & Context Persistence
Otto remembers. Store facts, project context, and preferences in memory. Search and recall across sessions. She gets smarter the more you use her.

## Quick Start

After installing, start Otto:

```bash
source ~/agent/.venv/bin/activate
otto service start telegram -f
```

Open Telegram and message your bot. Otto will help you finish configuring.

**Basic commands:**

```bash
otto doctor           # Health check
otto service status   # Show running services
otto config get       # View configuration
otto mcp start        # Start MCP Gateway
```

**Chat-first configuration** — many settings can be changed through conversation:

> "Enable voice transcription"
> "Switch to Pi backend"
> "Set my timezone to EST"

⚠️ **API keys & secrets** — set these in `~/.otto/config/.env`:

```bash
OPENROUTER_API_KEY=YOUR_API_KEY
ANTHROPIC_API_KEY=YOUR_API_KEY
```

## Architecture Overview

```
┌──────────────────┐
│   You (Telegram) │
└────────┬─────────┘
         ▼
┌──────────────────┐     ┌─────────────────┐
│  Telegram Bot    │────▶│   Orchestrator  │
└──────────────────┘     └────────┬────────┘
                                  │
                 ┌──────────────┴──────────────┐
                 ▼                             ▼
        ┌─────────────────┐          ┌─────────────────┐
        │       Pi        │          │     LiteLLM     │
        └────────┬────────┘          └────────┬────────┘
                 │                             │
                 └──────────────┬──────────────┘
                                ▼
                    ┌───────────────────────┐
                    │      MCP Gateway      │
                    │  (Tools & Policies)   │
                    └───────────────────────┘
```

- **Telegram Bot** — Your interface. Handles messages, voice, files, notifications.
- **Orchestrator** — Routes requests, spawns agents, loads context.
- **Backends** — Pluggable LLM wrappers (Pi and LiteLLM).
- **MCP Gateway** — Unified tool access with policy-based control.
- **Memory** — Persistent storage for facts, projects, and conversation context.

## Configuration

Otto stores runtime data in `~/.otto/`:

```
~/.otto/
├── brainfile.md      # Identity & personality
├── config/           # Settings & secrets
├── memory/           # Knowledge base
├── sessions/         # Conversation history
├── skills/           # Custom skills
└── outputs/          # Background task results
```

For detailed configuration options, see the [Installation Guide](docs/guide/02-installation.md) and [User Guide](docs/guide/03-user-guide.md).

## Documentation

| Guide | Description |
|-------|-------------|
| [Architecture](docs/guide/01-architecture.md) | System overview and components |
| [Installation](docs/guide/02-installation.md) | Setup instructions |
| [User Guide](docs/guide/03-user-guide.md) | How to interact with Otto |
| [Developer Guide](docs/guide/04-developer-guide.md) | Extending Otto |
| [Operations](docs/guide/05-operations-guide.md) | Running in production |

## Requirements

- Python 3.10+
- Git
- Telegram bot token (from [@BotFather](https://t.me/botfather))

**Optional:**
- Docker (for some MCP servers)
- Node.js (for agent backend CLIs)
- ffmpeg (for voice transcription)

## Contributing

Contributions welcome! Whether it's bug fixes, new features, or documentation improvements.

1. Fork the repo
2. Create a feature branch (`git checkout -b feature/cool-thing`)
3. Make your changes
4. Run tests (`make test`)
5. Submit a PR

Please keep PRs focused and include tests for new functionality.

## License

MIT — do whatever you want with it.

---

<p align="center">
  Built with ☕ and questionable life choices.<br>
  <sub>Otto is a personal project. Use at your own risk, but she's been pretty reliable so far.</sub>
</p>
