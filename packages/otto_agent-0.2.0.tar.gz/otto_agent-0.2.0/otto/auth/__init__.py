"""Otto authentication and credential storage.

Manages OAuth tokens and API keys for multiple providers.
Credentials are persisted to ``~/.otto/config/auth.json`` (chmod 600).

Usage::

    from otto.auth import AuthStorage

    storage = AuthStorage()
    key = await storage.get_api_key("anthropic")  # auto-refreshes if expired
"""

from __future__ import annotations

import json
import logging
import os
import stat
import time
from pathlib import Path
from typing import Any

from filelock import FileLock

from otto.paths import CONFIG_DIR

log = logging.getLogger(__name__)

AUTH_FILE: Path = CONFIG_DIR / "auth.json"
_LOCK_TIMEOUT = 10


def _mask(value: str) -> str:
    """Mask a token for safe debug output."""
    if len(value) <= 8:
        return "***"
    return f"{value[:4]}…{value[-4:]}"


class AuthStorage:
    """Thread/process-safe credential storage backed by ``auth.json``."""

    def __init__(self, path: Path | None = None) -> None:
        self._path = path or AUTH_FILE
        self._lock = FileLock(str(self._path) + ".lock", timeout=_LOCK_TIMEOUT)

    # ------------------------------------------------------------------
    # Low-level I/O
    # ------------------------------------------------------------------

    def _read(self) -> dict[str, Any]:
        if not self._path.exists():
            return {"credentials": {}}
        try:
            data = json.loads(self._path.read_text())
            if "credentials" not in data:
                data["credentials"] = {}
            return data
        except (json.JSONDecodeError, OSError):
            log.warning("Corrupt auth.json — starting fresh")
            return {"credentials": {}}

    def _write(self, data: dict[str, Any]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(json.dumps(data, indent=2))
        os.chmod(self._path, stat.S_IRUSR | stat.S_IWUSR)  # 600

    # ------------------------------------------------------------------
    # Credential CRUD
    # ------------------------------------------------------------------

    def list_providers(self) -> list[str]:
        """Return provider names that have stored credentials."""
        with self._lock:
            return list(self._read()["credentials"].keys())

    def get_credentials(self, provider: str) -> dict | None:
        """Return raw credential dict for *provider*, or ``None``."""
        with self._lock:
            return self._read()["credentials"].get(provider)

    def save_credentials(self, provider: str, creds: dict) -> None:
        """Persist credentials for *provider* (token values are never logged)."""
        with self._lock:
            data = self._read()
            data["credentials"][provider] = creds
            self._write(data)
        log.debug("Saved credentials for %s (tokens masked)", provider)

    def delete_credentials(self, provider: str) -> bool:
        """Remove credentials for *provider*. Returns ``True`` if they existed."""
        with self._lock:
            data = self._read()
            existed = provider in data["credentials"]
            data["credentials"].pop(provider, None)
            self._write(data)
        return existed

    # ------------------------------------------------------------------
    # High-level: get a usable API key (with auto-refresh)
    # ------------------------------------------------------------------

    async def get_api_key(self, provider: str) -> str | None:
        """Return a usable API key / access token for *provider*.

        * For ``type: api_key`` credentials the stored key is returned directly.
        * For ``type: oauth`` credentials the access token is returned, refreshing
          it first (under file-lock) if it has expired.
        * Returns ``None`` when no credentials are stored for *provider*.
        """
        creds = self.get_credentials(provider)
        if creds is None:
            return None

        cred_type = creds.get("type", "api_key")

        if cred_type == "api_key":
            return creds.get("key") or creds.get("access")

        # OAuth — check expiry
        if cred_type == "oauth":
            if time.time() < creds.get("expires", 0):
                return self._provider_api_key(provider, creds)
            # Needs refresh
            return await self._refresh_and_return(provider, creds)

        log.warning("Unknown credential type %r for %s", cred_type, provider)
        return None

    async def _refresh_and_return(self, provider: str, creds: dict) -> str | None:
        """Refresh under lock and return the new API key."""
        with self._lock:
            # Re-read — another process may have refreshed already
            fresh = self._read()["credentials"].get(provider)
            if fresh and time.time() < fresh.get("expires", 0):
                return self._provider_api_key(provider, fresh)

            try:
                updated = await self._do_refresh(provider, creds)
            except Exception:
                log.exception("Failed to refresh token for %s", provider)
                return None

            data = self._read()
            data["credentials"][provider] = updated
            self._write(data)

        return self._provider_api_key(provider, updated)

    async def _do_refresh(self, provider: str, creds: dict) -> dict:
        """Dispatch to the correct provider refresh function."""
        if provider == "anthropic":
            from otto.auth.anthropic import refresh_token

            return await refresh_token(creds["refresh"])
        if provider == "google":
            from otto.auth.google import refresh_token

            return await refresh_token(creds["refresh"], creds.get("projectId", ""))
        if provider == "openai":
            from otto.auth.openai import refresh_token

            return await refresh_token(creds["refresh"])
        if provider == "copilot":
            from otto.auth.copilot import refresh_token

            return await refresh_token(creds["refresh"], creds.get("enterpriseUrl"))
        raise ValueError(f"No refresh handler for provider: {provider}")

    @staticmethod
    def _provider_api_key(provider: str, creds: dict) -> str:
        """Extract the API key string appropriate for *provider*."""
        if provider == "google":
            from otto.auth.google import get_api_key

            return get_api_key(creds)
        return creds.get("access", creds.get("key", ""))

    # ------------------------------------------------------------------
    # Convenience: store a plain API key
    # ------------------------------------------------------------------

    def set_api_key(self, provider: str, key: str) -> None:
        """Store a plain API key (non-OAuth) for *provider*."""
        self.save_credentials(
            provider,
            {
                "provider": provider,
                "type": "api_key",
                "key": key,
            },
        )
