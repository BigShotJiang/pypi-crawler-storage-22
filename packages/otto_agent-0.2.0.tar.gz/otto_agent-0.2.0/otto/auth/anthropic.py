"""Anthropic OAuth flow (Claude Pro/Max)."""

from __future__ import annotations

import base64
import logging
import time
from collections.abc import Callable
from typing import Any
from urllib.parse import urlencode

import aiohttp

from .pkce import generate_pkce

log = logging.getLogger(__name__)

_CLIENT_ID = base64.b64decode("OWQxYzI1MGEtZTYxYi00NGQ5LTg4ZWQtNTk0NGQxOTYyZjVl").decode()
_AUTHORIZE_URL = "https://claude.ai/oauth/authorize"
_TOKEN_URL = "https://console.anthropic.com/v1/oauth/token"
_REDIRECT_URI = "https://console.anthropic.com/oauth/code/callback"
_SCOPES = "org:create_api_key user:profile user:inference"


async def login(
    on_auth_url: Callable[[str], None],
    on_prompt_code: Callable[[], Any],
) -> dict:
    """Run the Anthropic OAuth authorization-code flow.

    Returns credential dict with keys: refresh, access, expires, provider.
    """
    verifier, challenge = generate_pkce()

    params = urlencode(
        {
            "code": "true",
            "client_id": _CLIENT_ID,
            "response_type": "code",
            "redirect_uri": _REDIRECT_URI,
            "scope": _SCOPES,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
            "state": verifier,
        }
    )
    auth_url = f"{_AUTHORIZE_URL}?{params}"
    on_auth_url(auth_url)

    raw = await on_prompt_code()
    parts = str(raw).split("#")
    code = parts[0]
    state = parts[1] if len(parts) > 1 else ""

    async with aiohttp.ClientSession() as session:
        async with session.post(
            _TOKEN_URL,
            json={
                "grant_type": "authorization_code",
                "client_id": _CLIENT_ID,
                "code": code,
                "state": state,
                "redirect_uri": _REDIRECT_URI,
                "code_verifier": verifier,
            },
            headers={"Content-Type": "application/json"},
        ) as resp:
            if resp.status != 200:
                text = await resp.text()
                raise RuntimeError(f"Anthropic token exchange failed ({resp.status}): {text}")
            data = await resp.json()

    expires_at = time.time() + data["expires_in"] - 300
    log.debug("Anthropic OAuth login succeeded (token masked)")
    return {
        "provider": "anthropic",
        "type": "oauth",
        "refresh": data["refresh_token"],
        "access": data["access_token"],
        "expires": expires_at,
    }


async def refresh_token(refresh: str) -> dict:
    """Refresh an Anthropic OAuth token. Returns updated credential dict."""
    async with aiohttp.ClientSession() as session:
        async with session.post(
            _TOKEN_URL,
            json={
                "grant_type": "refresh_token",
                "client_id": _CLIENT_ID,
                "refresh_token": refresh,
            },
            headers={"Content-Type": "application/json"},
        ) as resp:
            if resp.status != 200:
                text = await resp.text()
                raise RuntimeError(f"Anthropic token refresh failed ({resp.status}): {text}")
            data = await resp.json()

    expires_at = time.time() + data["expires_in"] - 300
    log.debug("Anthropic token refreshed (token masked)")
    return {
        "provider": "anthropic",
        "type": "oauth",
        "refresh": data.get("refresh_token", refresh),
        "access": data["access_token"],
        "expires": expires_at,
    }


def get_api_key(credentials: dict) -> str:
    """Extract the usable API key from Anthropic OAuth credentials."""
    return credentials["access"]
