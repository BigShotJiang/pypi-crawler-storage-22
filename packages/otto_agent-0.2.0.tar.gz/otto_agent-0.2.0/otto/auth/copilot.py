"""GitHub Copilot OAuth flow (device code)."""

from __future__ import annotations

import base64
import logging
import time
from collections.abc import Callable
from urllib.parse import urlparse

import aiohttp

log = logging.getLogger(__name__)

_CLIENT_ID = base64.b64decode("SXYxLmI1MDdhMDhjODdlY2ZlOTg=").decode()

_COPILOT_HEADERS = {
    "User-Agent": "GitHubCopilotChat/0.35.0",
    "Editor-Version": "vscode/1.107.0",
    "Editor-Plugin-Version": "copilot-chat/0.35.0",
    "Copilot-Integration-Id": "vscode-chat",
}


def normalize_domain(raw: str) -> str | None:
    trimmed = raw.strip()
    if not trimmed:
        return None
    try:
        url = trimmed if "://" in trimmed else f"https://{trimmed}"
        return urlparse(url).hostname
    except Exception:
        return None


def _urls(domain: str) -> dict:
    return {
        "device_code": f"https://{domain}/login/device/code",
        "access_token": f"https://{domain}/login/oauth/access_token",
        "copilot_token": f"https://api.{domain}/copilot_internal/v2/token",
    }


def _base_url_from_token(token: str, enterprise: str | None = None) -> str:
    import re

    m = re.search(r"proxy-ep=([^;]+)", token)
    if m:
        return f"https://{m.group(1).replace('proxy.', 'api.', 1)}"
    if enterprise:
        return f"https://copilot-api.{enterprise}"
    return "https://api.individual.githubcopilot.com"


# ---------------------------------------------------------------------------
# Login
# ---------------------------------------------------------------------------


async def login(
    on_auth_url: Callable[[str, str], None],
    on_prompt: Callable[[dict], object],
    on_progress: Callable[[str], None] | None = None,
    signal_cancelled: Callable[[], bool] | None = None,
) -> dict:
    """Run the GitHub Copilot device-code OAuth flow.

    ``on_auth_url(url, instructions)`` — called with verification URI and user code.
    ``on_prompt({"message": ..., "allowEmpty": bool})`` — prompt user for input.
    """
    # Ask for enterprise domain
    raw = await on_prompt(
        {
            "message": "GitHub Enterprise URL/domain (blank for github.com)",
            "allowEmpty": True,
        }
    )
    trimmed = str(raw).strip()
    enterprise = normalize_domain(raw) if trimmed else None
    if trimmed and not enterprise:
        raise RuntimeError("Invalid GitHub Enterprise URL/domain")
    domain = enterprise or "github.com"
    urls = _urls(domain)

    # Start device flow
    async with aiohttp.ClientSession() as session:
        async with session.post(
            urls["device_code"],
            json={"client_id": _CLIENT_ID, "scope": "read:user"},
            headers={"Accept": "application/json", "User-Agent": "GitHubCopilotChat/0.35.0"},
        ) as resp:
            if resp.status != 200:
                raise RuntimeError(f"Device code request failed ({resp.status})")
            device = await resp.json()

    device_code = device["device_code"]
    user_code = device["user_code"]
    verification_uri = device["verification_uri"]
    interval = max(1, device.get("interval", 5))
    expires_in = device.get("expires_in", 900)

    on_auth_url(verification_uri, f"Enter code: {user_code}")

    # Poll for access token
    import asyncio

    deadline = time.time() + expires_in
    interval_s = float(interval)

    async with aiohttp.ClientSession() as session:
        while time.time() < deadline:
            if signal_cancelled and signal_cancelled():
                raise RuntimeError("Login cancelled")

            async with session.post(
                urls["access_token"],
                json={
                    "client_id": _CLIENT_ID,
                    "device_code": device_code,
                    "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                },
                headers={
                    "Accept": "application/json",
                    "User-Agent": "GitHubCopilotChat/0.35.0",
                },
            ) as resp:
                data = await resp.json()

            if "access_token" in data:
                github_token = data["access_token"]
                break

            error = data.get("error", "")
            if error == "authorization_pending":
                await asyncio.sleep(interval_s)
                continue
            if error == "slow_down":
                interval_s += 5
                await asyncio.sleep(interval_s)
                continue
            raise RuntimeError(f"Device flow failed: {error}")
        else:
            raise RuntimeError("Device flow timed out")

    # Exchange GitHub token for Copilot token
    creds = await _exchange_copilot_token(github_token, enterprise, urls)

    log.debug("GitHub Copilot login succeeded (token masked)")
    return creds


async def _exchange_copilot_token(
    github_token: str,
    enterprise: str | None,
    urls: dict,
) -> dict:
    async with aiohttp.ClientSession() as session:
        async with session.get(
            urls["copilot_token"],
            headers={
                "Accept": "application/json",
                "Authorization": f"Bearer {github_token}",
                **_COPILOT_HEADERS,
            },
        ) as resp:
            if resp.status != 200:
                raise RuntimeError(
                    f"Copilot token exchange failed ({resp.status}): {await resp.text()}"
                )
            data = await resp.json()

    token = data["token"]
    expires_at = data["expires_at"]

    return {
        "provider": "copilot",
        "type": "oauth",
        "refresh": github_token,
        "access": token,
        "expires": expires_at - 300,
        "enterpriseUrl": enterprise,
    }


async def refresh_token(refresh: str, enterprise: str | None = None) -> dict:
    """Refresh a GitHub Copilot token using the stored GitHub access token."""
    domain = enterprise or "github.com"
    urls = _urls(domain)

    async with aiohttp.ClientSession() as session:
        async with session.get(
            urls["copilot_token"],
            headers={
                "Accept": "application/json",
                "Authorization": f"Bearer {refresh}",
                **_COPILOT_HEADERS,
            },
        ) as resp:
            if resp.status != 200:
                raise RuntimeError(
                    f"Copilot token refresh failed ({resp.status}): {await resp.text()}"
                )
            data = await resp.json()

    token = data["token"]
    expires_at = data["expires_at"]

    log.debug("GitHub Copilot token refreshed (token masked)")
    return {
        "provider": "copilot",
        "type": "oauth",
        "refresh": refresh,
        "access": token,
        "expires": expires_at - 300,
        "enterpriseUrl": enterprise,
    }


def get_api_key(credentials: dict) -> str:
    """Extract the usable API key from Copilot credentials."""
    return credentials["access"]
