"""Google Cloud Code Assist (Gemini CLI) OAuth flow."""

from __future__ import annotations

import base64
import json
import logging
import os
import time
from collections.abc import Callable
from typing import Any
from urllib.parse import urlencode

import aiohttp

from .pkce import generate_pkce

log = logging.getLogger(__name__)

_CLIENT_ID = base64.b64decode(
    "NjgxMjU1ODA5Mzk1LW9vOGZ0Mm9wcmRybnA5ZTNhcWY2YXYzaG1kaWIxMzVqLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29t"
).decode()
_CLIENT_SECRET = base64.b64decode("R09DU1BYLTR1SGdNUG0tMW83U2stZ2VWNkN1NWNsWEZzeGw=").decode()
_REDIRECT_URI = "http://localhost:8085/oauth2callback"
_SCOPES = [
    "https://www.googleapis.com/auth/cloud-platform",
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/userinfo.profile",
]
_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
_TOKEN_URL = "https://oauth2.googleapis.com/token"
_CODE_ASSIST_ENDPOINT = "https://cloudcode-pa.googleapis.com"
_CALLBACK_PORT = 8085

_TIER_FREE = "free-tier"
_TIER_LEGACY = "legacy-tier"

# ---------------------------------------------------------------------------
# Local callback server
# ---------------------------------------------------------------------------


async def _run_callback_server() -> tuple[Any, Any]:
    """Start a local HTTP server on port 8085 and return (runner, future).

    The future resolves with ``{"code": ..., "state": ...}`` or ``None``.
    """
    import asyncio

    from aiohttp import web

    result_future: asyncio.Future[dict | None] = asyncio.get_event_loop().create_future()

    async def _handle(request: web.Request) -> web.Response:
        error = request.query.get("error")
        if error:
            if not result_future.done():
                result_future.set_result(None)
            return web.Response(
                text=f"<h1>Authentication Failed</h1><p>{error}</p>",
                content_type="text/html",
            )
        code = request.query.get("code")
        state = request.query.get("state")
        if code and state:
            if not result_future.done():
                result_future.set_result({"code": code, "state": state})
            return web.Response(
                text="<h1>Authentication Successful</h1><p>You can close this window.</p>",
                content_type="text/html",
            )
        return web.Response(status=400, text="Missing code or state")

    app = web.Application()
    app.router.add_get("/oauth2callback", _handle)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", _CALLBACK_PORT)
    await site.start()
    return runner, result_future


# ---------------------------------------------------------------------------
# Project discovery / provisioning
# ---------------------------------------------------------------------------


async def _discover_project(
    access_token: str,
    on_progress: Callable[[str], None] | None = None,
) -> str:
    env_project = os.environ.get("GOOGLE_CLOUD_PROJECT") or os.environ.get(
        "GOOGLE_CLOUD_PROJECT_ID"
    )
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
        "User-Agent": "google-api-nodejs-client/9.15.1",
        "X-Goog-Api-Client": "gl-node/22.17.0",
    }

    if on_progress:
        on_progress("Checking for existing Cloud Code Assist project...")

    async with aiohttp.ClientSession() as session:
        async with session.post(
            f"{_CODE_ASSIST_ENDPOINT}/v1internal:loadCodeAssist",
            headers=headers,
            json={
                "cloudaicompanionProject": env_project,
                "metadata": {
                    "ideType": "IDE_UNSPECIFIED",
                    "platform": "PLATFORM_UNSPECIFIED",
                    "pluginType": "GEMINI",
                    "duetProject": env_project,
                },
            },
        ) as resp:
            if resp.status != 200:
                error_text = await resp.text()
                # Check for VPC-SC
                try:
                    err_json = json.loads(error_text)
                    details = err_json.get("error", {}).get("details", [])
                    if any(d.get("reason") == "SECURITY_POLICY_VIOLATED" for d in details):
                        data: dict = {"currentTier": {"id": "standard-tier"}}
                    else:
                        raise RuntimeError(f"loadCodeAssist failed ({resp.status}): {error_text}")
                except (json.JSONDecodeError, RuntimeError):
                    raise RuntimeError(f"loadCodeAssist failed ({resp.status}): {error_text}")
            else:
                data = await resp.json()

        # Already has tier + project
        if data.get("currentTier"):
            if data.get("cloudaicompanionProject"):
                return data["cloudaicompanionProject"]
            if env_project:
                return env_project
            raise RuntimeError(
                "This account requires GOOGLE_CLOUD_PROJECT or GOOGLE_CLOUD_PROJECT_ID env var."
            )

        # Onboard
        allowed = data.get("allowedTiers", [])
        default_tier = next((t for t in allowed if t.get("isDefault")), None)
        tier_id = (default_tier or {}).get("id", _TIER_FREE)

        if tier_id != _TIER_FREE and not env_project:
            raise RuntimeError(
                "This account requires GOOGLE_CLOUD_PROJECT or GOOGLE_CLOUD_PROJECT_ID env var."
            )

        if on_progress:
            on_progress("Provisioning Cloud Code Assist project...")

        onboard_body: dict[str, Any] = {
            "tierId": tier_id,
            "metadata": {
                "ideType": "IDE_UNSPECIFIED",
                "platform": "PLATFORM_UNSPECIFIED",
                "pluginType": "GEMINI",
            },
        }
        if tier_id != _TIER_FREE and env_project:
            onboard_body["cloudaicompanionProject"] = env_project
            onboard_body["metadata"]["duetProject"] = env_project

        async with session.post(
            f"{_CODE_ASSIST_ENDPOINT}/v1internal:onboardUser",
            headers=headers,
            json=onboard_body,
        ) as resp:
            if resp.status != 200:
                raise RuntimeError(f"onboardUser failed ({resp.status}): {await resp.text()}")
            lro = await resp.json()

        # Poll LRO if needed
        if not lro.get("done") and lro.get("name"):
            import asyncio

            for attempt in range(60):
                if on_progress:
                    on_progress(f"Waiting for provisioning (attempt {attempt + 1})...")
                await asyncio.sleep(5)
                async with session.get(
                    f"{_CODE_ASSIST_ENDPOINT}/v1internal/{lro['name']}",
                    headers=headers,
                ) as resp:
                    if resp.status != 200:
                        raise RuntimeError(f"Poll failed ({resp.status})")
                    lro = await resp.json()
                    if lro.get("done"):
                        break

        project_id = lro.get("response", {}).get("cloudaicompanionProject", {}).get("id")
        if project_id:
            return project_id
        if env_project:
            return env_project
        raise RuntimeError("Could not discover or provision a Google Cloud project.")


# ---------------------------------------------------------------------------
# Login / refresh
# ---------------------------------------------------------------------------


async def login(
    on_auth_url: Callable[[str], None],
    on_progress: Callable[[str], None] | None = None,
) -> dict:
    """Run the Google Cloud Code Assist OAuth flow with local callback server.

    Returns credential dict with keys: provider, type, refresh, access, expires, projectId.
    """
    import asyncio

    verifier, challenge = generate_pkce()

    runner, code_future = await _run_callback_server()

    try:
        params = urlencode(
            {
                "client_id": _CLIENT_ID,
                "response_type": "code",
                "redirect_uri": _REDIRECT_URI,
                "scope": " ".join(_SCOPES),
                "code_challenge": challenge,
                "code_challenge_method": "S256",
                "state": verifier,
                "access_type": "offline",
                "prompt": "consent",
            }
        )
        on_auth_url(f"{_AUTH_URL}?{params}")

        if on_progress:
            on_progress("Waiting for OAuth callback...")

        result = await asyncio.wait_for(code_future, timeout=300)
        if not result or not result.get("code"):
            raise RuntimeError("No authorization code received")
        if result.get("state") != verifier:
            raise RuntimeError("OAuth state mismatch")

        code = result["code"]

        # Exchange code for tokens
        if on_progress:
            on_progress("Exchanging authorization code...")

        async with aiohttp.ClientSession() as session:
            async with session.post(
                _TOKEN_URL,
                data={
                    "client_id": _CLIENT_ID,
                    "client_secret": _CLIENT_SECRET,
                    "code": code,
                    "grant_type": "authorization_code",
                    "redirect_uri": _REDIRECT_URI,
                    "code_verifier": verifier,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            ) as resp:
                if resp.status != 200:
                    raise RuntimeError(
                        f"Token exchange failed ({resp.status}): {await resp.text()}"
                    )
                token_data = await resp.json()

        if not token_data.get("refresh_token"):
            raise RuntimeError("No refresh token received")

        access = token_data["access_token"]
        project_id = await _discover_project(access, on_progress)
        expires_at = time.time() + token_data["expires_in"] - 300

        log.debug("Google OAuth login succeeded (token masked)")
        return {
            "provider": "google",
            "type": "oauth",
            "refresh": token_data["refresh_token"],
            "access": access,
            "expires": expires_at,
            "projectId": project_id,
        }
    finally:
        await runner.cleanup()


async def refresh_token(refresh: str, project_id: str) -> dict:
    """Refresh a Google Cloud OAuth token."""
    async with aiohttp.ClientSession() as session:
        async with session.post(
            _TOKEN_URL,
            data={
                "client_id": _CLIENT_ID,
                "client_secret": _CLIENT_SECRET,
                "refresh_token": refresh,
                "grant_type": "refresh_token",
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        ) as resp:
            if resp.status != 200:
                raise RuntimeError(
                    f"Google token refresh failed ({resp.status}): {await resp.text()}"
                )
            data = await resp.json()

    expires_at = time.time() + data["expires_in"] - 300
    log.debug("Google token refreshed (token masked)")
    return {
        "provider": "google",
        "type": "oauth",
        "refresh": data.get("refresh_token", refresh),
        "access": data["access_token"],
        "expires": expires_at,
        "projectId": project_id,
    }


def get_api_key(credentials: dict) -> str:
    """Return JSON-encoded ``{token, projectId}`` for Google provider."""
    return json.dumps(
        {
            "token": credentials["access"],
            "projectId": credentials.get("projectId", ""),
        }
    )
