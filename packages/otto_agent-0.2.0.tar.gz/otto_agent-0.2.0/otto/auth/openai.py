"""OpenAI / Codex OAuth flow."""

from __future__ import annotations

import base64
import json
import logging
import os
import time
from collections.abc import Callable
from typing import Any
from urllib.parse import urlencode

import aiohttp

from .pkce import generate_pkce

log = logging.getLogger(__name__)

_CLIENT_ID = "app_EMoamEEZ73f0CkXaXp7hrann"
_AUTHORIZE_URL = "https://auth.openai.com/oauth/authorize"
_TOKEN_URL = "https://auth.openai.com/oauth/token"
_REDIRECT_URI = "http://localhost:1455/auth/callback"
_SCOPE = "openid profile email offline_access"
_JWT_CLAIM_PATH = "https://api.openai.com/auth"
_CALLBACK_PORT = 1455


def _random_state() -> str:
    return os.urandom(16).hex()


def _decode_jwt_payload(token: str) -> dict | None:
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        payload = parts[1]
        # Add padding
        payload += "=" * (-len(payload) % 4)
        decoded = base64.urlsafe_b64decode(payload)
        return json.loads(decoded)
    except Exception:
        return None


def _extract_account_id(access_token: str) -> str | None:
    payload = _decode_jwt_payload(access_token)
    if not payload:
        return None
    auth = payload.get(_JWT_CLAIM_PATH, {})
    aid = auth.get("chatgpt_account_id")
    return aid if isinstance(aid, str) and aid else None


def _parse_auth_input(raw: str) -> dict:
    value = raw.strip()
    if not value:
        return {}
    try:
        from urllib.parse import parse_qs, urlparse

        parsed = urlparse(value)
        if parsed.query:
            qs = parse_qs(parsed.query)
            return {
                "code": qs.get("code", [None])[0],
                "state": qs.get("state", [None])[0],
            }
    except Exception:
        pass
    if "#" in value:
        code, state = value.split("#", 1)
        return {"code": code, "state": state}
    return {"code": value}


# ---------------------------------------------------------------------------
# Local callback server
# ---------------------------------------------------------------------------


async def _run_callback_server(expected_state: str) -> tuple[Any, Any]:
    import asyncio

    from aiohttp import web

    result_future: asyncio.Future[dict | None] = asyncio.get_event_loop().create_future()

    async def _handle(request: web.Request) -> web.Response:
        if request.path != "/auth/callback":
            return web.Response(status=404, text="Not found")
        state = request.query.get("state")
        if state != expected_state:
            return web.Response(status=400, text="State mismatch")
        code = request.query.get("code")
        if not code:
            return web.Response(status=400, text="Missing authorization code")
        if not result_future.done():
            result_future.set_result({"code": code})
        return web.Response(
            text="<p>Authentication successful. Return to your terminal.</p>",
            content_type="text/html",
        )

    app = web.Application()
    app.router.add_get("/auth/callback", _handle)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", _CALLBACK_PORT)
    await site.start()
    return runner, result_future


# ---------------------------------------------------------------------------
# Login / refresh
# ---------------------------------------------------------------------------


async def login(
    on_auth_url: Callable[[str], None],
    on_prompt_code: Callable[[], Any],
    on_progress: Callable[[str], None] | None = None,
) -> dict:
    """Run the OpenAI/Codex OAuth flow. Returns credential dict."""
    import asyncio

    verifier, challenge = generate_pkce()
    state = _random_state()

    try:
        runner, code_future = await _run_callback_server(state)
        server_ok = True
    except OSError:
        log.debug("Could not bind port %d, falling back to manual paste", _CALLBACK_PORT)
        runner = None
        code_future = None
        server_ok = False

    try:
        params = urlencode(
            {
                "response_type": "code",
                "client_id": _CLIENT_ID,
                "redirect_uri": _REDIRECT_URI,
                "scope": _SCOPE,
                "code_challenge": challenge,
                "code_challenge_method": "S256",
                "state": state,
                "id_token_add_organizations": "true",
                "codex_cli_simplified_flow": "true",
                "originator": "otto",
            }
        )
        on_auth_url(f"{_AUTHORIZE_URL}?{params}")

        code = None
        if server_ok and code_future is not None:
            try:
                result = await asyncio.wait_for(code_future, timeout=60)
                if result:
                    code = result.get("code")
            except asyncio.TimeoutError:
                pass

        if not code:
            raw = await on_prompt_code()
            parsed = _parse_auth_input(str(raw))
            if parsed.get("state") and parsed["state"] != state:
                raise RuntimeError("State mismatch")
            code = parsed.get("code")

        if not code:
            raise RuntimeError("Missing authorization code")

        async with aiohttp.ClientSession() as session:
            async with session.post(
                _TOKEN_URL,
                data={
                    "grant_type": "authorization_code",
                    "client_id": _CLIENT_ID,
                    "code": code,
                    "code_verifier": verifier,
                    "redirect_uri": _REDIRECT_URI,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            ) as resp:
                if resp.status != 200:
                    raise RuntimeError(
                        f"OpenAI token exchange failed ({resp.status}): {await resp.text()}"
                    )
                data = await resp.json()

        access = data.get("access_token")
        refresh = data.get("refresh_token")
        expires_in = data.get("expires_in")
        if not access or not refresh or not isinstance(expires_in, (int, float)):
            raise RuntimeError("Token response missing required fields")

        account_id = _extract_account_id(access)
        if not account_id:
            raise RuntimeError("Failed to extract accountId from token")

        log.debug("OpenAI OAuth login succeeded (token masked)")
        return {
            "provider": "openai",
            "type": "oauth",
            "refresh": refresh,
            "access": access,
            "expires": time.time() + expires_in,
            "accountId": account_id,
        }
    finally:
        if runner:
            await runner.cleanup()


async def refresh_token(refresh: str) -> dict:
    """Refresh an OpenAI/Codex OAuth token."""
    async with aiohttp.ClientSession() as session:
        async with session.post(
            _TOKEN_URL,
            data={
                "grant_type": "refresh_token",
                "refresh_token": refresh,
                "client_id": _CLIENT_ID,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        ) as resp:
            if resp.status != 200:
                raise RuntimeError(
                    f"OpenAI token refresh failed ({resp.status}): {await resp.text()}"
                )
            data = await resp.json()

    access = data.get("access_token")
    new_refresh = data.get("refresh_token")
    expires_in = data.get("expires_in")
    if not access or not new_refresh or not isinstance(expires_in, (int, float)):
        raise RuntimeError("Token refresh response missing fields")

    account_id = _extract_account_id(access)
    if not account_id:
        raise RuntimeError("Failed to extract accountId from refreshed token")

    log.debug("OpenAI token refreshed (token masked)")
    return {
        "provider": "openai",
        "type": "oauth",
        "refresh": new_refresh,
        "access": access,
        "expires": time.time() + expires_in,
        "accountId": account_id,
    }


def get_api_key(credentials: dict) -> str:
    """Extract the usable API key from OpenAI OAuth credentials."""
    return credentials["access"]
