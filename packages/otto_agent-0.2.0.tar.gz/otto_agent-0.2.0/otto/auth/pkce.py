"""PKCE (Proof Key for Code Exchange) utilities."""

from __future__ import annotations

import base64
import hashlib
import os


def _base64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def generate_pkce() -> tuple[str, str]:
    """Return ``(verifier, challenge)`` for an S256 PKCE flow."""
    verifier = _base64url(os.urandom(32))
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = _base64url(digest)
    return verifier, challenge
