"""
Backend registry and configuration loader.

Provides get_backend() to obtain a configured backend instance,
list_backends() to see available backends, set_active_backend() to
switch backends, and reload_config() to refresh from settings.

All configuration is read/written via otto.config (settings.yaml).
"""

from pathlib import Path

from .base import AgentBackend, AgentConfig, AgentResult
from .generic import GenericBackend
from .pi import PiBackend
from .types import DEFAULT_PERMISSION_MODE, OutputFormat, PermissionMode

# Lazy import for optional cecli dependency
try:
    from .cecli import CecliBackend
except ImportError:
    CecliBackend = None

# Backend implementations registry
_BACKEND_CLASSES: dict[str, type[AgentBackend]] = {
    "pi": PiBackend,
    "litellm": GenericBackend,
}
if CecliBackend is not None:
    _BACKEND_CLASSES["cecli"] = CecliBackend

# Known models per backend (static list, user can override with any value)
# These are shown in UI for convenience, but any model string is accepted
BACKEND_MODELS = {
    "litellm": [
        # OpenRouter
        "openrouter/meta-llama/llama-3.3-70b-instruct",
        "openrouter/anthropic/claude-sonnet-4",
        "openrouter/google/gemini-2.0-flash",
        # Ollama
        "ollama/qwen2.5-coder",
        "ollama/llama3.2",
        # Gemini
        "gemini/gemini-2.0-flash",
        # OpenAI
        "gpt-4o",
        "gpt-4o-mini",
    ],
    "pi": [
        "claude-sonnet-4-5",
        "claude-sonnet-4-5-thinking",
        "claude-opus-4-5-thinking",
        "gemini-3-flash",
        "gemini-3-pro-high",
        "gemini-3-pro-low",
        "gpt-oss-120b-medium",
    ],
    "cecli": [
        "anthropic/claude-sonnet-4-5",
        "anthropic/claude-opus-4-5",
        "openrouter/anthropic/claude-sonnet-4",
        "openai/gpt-4o",
        "ollama/qwen2.5-coder",
    ],
}

# Cached backend instances
_backends_cache: dict[str, AgentBackend] = {}


def _get_default_config() -> dict:
    """Return default agent configuration."""
    return {
        "active": "pi",
        "backends": {
            "pi": {
                "enabled": True,
                "path": "~/.local/bin/pi",
                "model": "anthropic/claude-sonnet-4-5-thinking",
                "options": {
                    "reuse_session": True,
                    "connection_timeout": 60,
                    "thinking_level": "medium",
                    "auto_compaction": True,
                },
            },
            "litellm": {
                "enabled": False,
                "model": "openrouter/meta-llama/llama-3.3-70b-instruct",
                "options": {
                    "max_turns": 50,
                    "timeout": 300,
                    "api_base": None,
                    "api_key_env": "OPENROUTER_API_KEY",
                    "include_mcp_tools": True,
                    "safeguards": {
                        "enabled": True,
                        "protected_paths": [],
                        "blocked_patterns": [],
                    },
                },
            },
            "cecli": {
                "enabled": False,
                "model": "anthropic/claude-sonnet-4-5",
                "options": {
                    "edit_format": "agent",
                    "auto_commits": False,
                    "use_git": False,
                    "auto_lint": False,
                    "auto_test": False,
                    "timeout": 300,
                },
            },
        },
        "orchestration": {
            "max_parallel": 5,
            "worker_concurrency": 4,
            "default_timeout": 3600,
            "pipeline_notify_grace_seconds": 8,
            "heartbeat": {
                "enabled": True,
                "auto_retry": True,
                "max_retries": 3,
                "poll_interval": 30,
                "timeout_seconds": 3600,
                "escalate_to_llm": True,
                "notify_on": ["agent_failed", "schedule_missed", "critical_error"],
            },
        },
    }


def reload_config() -> None:
    """Reload configuration from settings.yaml and clear caches."""
    global _backends_cache
    from .. import config as otto_config

    otto_config.reload()
    _backends_cache = {}  # Clear cached backend instances


def _get_agent_config() -> dict:
    """Get the agent configuration section from settings.yaml."""
    from .. import config as otto_config

    defaults = _get_default_config()
    agent_config = otto_config.get_setting("agent", {})

    # Deep merge with defaults
    if not agent_config:
        return defaults

    # --- Migration: map removed backend names to their replacements ---
    active = agent_config.get("active", defaults["active"])
    if active in ("claude", "codex"):
        agent_config["active"] = "pi"
    elif active == "generic":
        agent_config["active"] = "litellm"
    elif active == "aider":
        agent_config["active"] = "cecli"

    # Ensure backends exist and merge with defaults
    # This ensures new backends are available even if
    # the user's settings.yaml was created before they were added
    if "backends" not in agent_config:
        agent_config["backends"] = defaults["backends"]
    else:
        # Migrate "generic" key to "litellm" if present
        backends = agent_config["backends"]
        if "generic" in backends and "litellm" not in backends:
            backends["litellm"] = backends.pop("generic")

        # Migrate "aider" key to "cecli" if present
        if "aider" in backends and "cecli" not in backends:
            backends["cecli"] = backends.pop("aider")

        # Strip removed backends that may linger in user config
        for removed in ("claude", "codex", "generic", "aider"):
            backends.pop(removed, None)

        # Merge: user config takes precedence, but include new default backends
        merged_backends = dict(defaults["backends"])
        merged_backends.update(backends)
        agent_config["backends"] = merged_backends

    return agent_config


def get_backend(name: str | None = None) -> AgentBackend:
    """
    Get a backend instance by name.

    Args:
        name: Backend name. If None, uses the active backend from config.

    Returns:
        AgentBackend instance.

    Raises:
        ValueError: If backend is not found or not supported.
    """
    agent_config = _get_agent_config()
    defaults = _get_default_config()

    # Determine which backend to use
    if name is None:
        name = agent_config.get("active", defaults["active"])

    # Migration: silently map removed backend names
    if name in ("claude", "codex"):
        name = "pi"
    elif name == "generic":
        name = "litellm"
    elif name == "aider":
        name = "cecli"

    # Check cache first
    if name in _backends_cache:
        return _backends_cache[name]

    # Get backend configuration
    backends_config = agent_config.get("backends", defaults["backends"])
    backend_cfg = backends_config.get(name)

    if backend_cfg is None:
        # Fall back to defaults for known backends
        backend_cfg = defaults["backends"].get(name)
        if backend_cfg is None:
            raise ValueError(f"Unknown backend: {name}")

    # Get the backend class
    backend_class = _BACKEND_CLASSES.get(name)
    if backend_class is None:
        raise ValueError(f"Backend not implemented: {name}")

    # Build AgentConfig
    config = AgentConfig(
        name=name,
        path=Path(backend_cfg.get("path", f"~/.local/bin/{name}")).expanduser(),
        enabled=backend_cfg.get("enabled", True),
        model=backend_cfg.get("model"),
        flags=backend_cfg.get("flags", []),
    )

    # Attach options (with sdk_options fallback for migration)
    options = backend_cfg.get("options", backend_cfg.get("sdk_options", {}))
    if options:
        config.options = options

    # Create and cache the backend instance
    backend = backend_class(config)
    _backends_cache[name] = backend
    return backend


def list_backends() -> dict[str, dict]:
    """
    List all configured backends with their info.

    Returns:
        Dict mapping backend name to its configuration.
        Example: {"pi": {"enabled": True, "path": "...", ...}, ...}
    """
    agent_config = _get_agent_config()
    defaults = _get_default_config()
    backends_config = agent_config.get("backends", defaults["backends"])
    return backends_config


def get_active_backend_name() -> str:
    """Get the name of the currently active backend."""
    agent_config = _get_agent_config()
    defaults = _get_default_config()
    return agent_config.get("active", defaults["active"])


def set_active_backend(name: str) -> None:
    """
    Set the active backend in settings.yaml.

    Args:
        name: Backend name (pi, litellm)

    Raises:
        ValueError: If backend is unknown or not available
    """
    from .. import config as otto_config

    backends = list_backends()
    if name not in backends:
        raise ValueError(f"Unknown backend: {name}")

    # Update settings.yaml
    otto_config.set_setting("agent.active", name)

    # Clear backend cache so next get_backend() uses new active
    global _backends_cache
    _backends_cache = {}


def get_orchestration_config() -> dict:
    """Get orchestration configuration."""
    agent_config = _get_agent_config()
    defaults = _get_default_config()
    return agent_config.get("orchestration", defaults["orchestration"])


def get_backend_model(name: str | None = None) -> str | None:
    """
    Get the model configured for a backend.

    Args:
        name: Backend name. If None, uses active backend.

    Returns:
        Model name or None if using backend default.
    """
    if name is None:
        name = get_active_backend_name()

    backends = list_backends()
    backend_cfg = backends.get(name, {})
    return backend_cfg.get("model")


def set_backend_model(model: str | None, name: str | None = None) -> None:
    """
    Set the model for a backend in settings.yaml.

    Args:
        model: Model name (e.g., "sonnet", "opus"). None to clear/use default.
        name: Backend name. If None, uses active backend.

    Note:
        Any model string is accepted. If invalid, the CLI will return an error
        which gets passed through to the user.
    """
    from .. import config as otto_config

    if name is None:
        name = get_active_backend_name()

    backends = list_backends()
    if name not in backends:
        raise ValueError(f"Unknown backend: {name}")

    # Update settings.yaml
    otto_config.set_setting(f"agent.backends.{name}.model", model)

    # Clear backend cache so next get_backend() uses new model
    global _backends_cache
    _backends_cache = {}


def get_known_models(name: str | None = None) -> list[str]:
    """
    Get known models for a backend.

    Args:
        name: Backend name. If None, uses active backend.

    Returns:
        List of known model names for this backend.
    """
    if name is None:
        name = get_active_backend_name()
    return BACKEND_MODELS.get(name, [])


def get_available_models(name: str | None = None) -> list[dict]:
    """Get available models for a backend.

    For Pi: runs live discovery via ``pi --list-models``.
    For others: returns the static ``BACKEND_MODELS`` list wrapped in dicts.

    Returns:
        List of ``{"id": str, "label": str, "provider"?: str, "thinking"?: bool}``
    """
    if name is None:
        name = get_active_backend_name()

    # Pi: prefer live discovery
    if name == "pi":
        try:
            backend = get_backend(name)
            if hasattr(backend, "get_available_models"):
                discovered = backend.get_available_models()
                if discovered:
                    results = []
                    for m in discovered:
                        provider = m.get("provider", "")
                        model = m["model"]
                        # Use provider/model format for id so selections
                        # store the new config format
                        model_id = f"{provider}/{model}" if provider else model
                        results.append(
                            {
                                "id": model_id,
                                "label": model_id,
                                "provider": provider,
                                "thinking": m.get("thinking", False),
                            }
                        )
                    return results
        except Exception:
            pass  # Fall through to static list

    # Static fallback for all backends (including pi if discovery failed)
    static = BACKEND_MODELS.get(name, [])
    return [{"id": m, "label": m} for m in static]


# Re-export base classes and types
__all__ = [
    # Base classes
    "AgentBackend",
    "AgentConfig",
    "AgentResult",
    # Type definitions
    "PermissionMode",
    "OutputFormat",
    "DEFAULT_PERMISSION_MODE",
    # Backend implementations
    "CecliBackend",
    "GenericBackend",
    "PiBackend",
    "BACKEND_MODELS",
    # Registry functions
    "get_backend",
    "list_backends",
    "reload_config",
    "get_active_backend_name",
    "set_active_backend",
    "get_orchestration_config",
    "get_backend_model",
    "set_backend_model",
    "get_known_models",
    "get_available_models",
]
