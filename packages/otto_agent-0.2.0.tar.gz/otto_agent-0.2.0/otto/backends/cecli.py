"""
Cecli backend using cecli's Python API.

Provides AI coding agent powered by cecli (fork of aider).
Wraps cecli's Coder API with Otto's backend interface.

cecli is an optional dependency. Install with: pip install cecli-dev
"""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
import os
import time
from collections.abc import AsyncIterator
from pathlib import Path
from typing import TYPE_CHECKING

from otto.auth import AuthStorage

from .base import AgentBackend, AgentConfig, AgentResult

if TYPE_CHECKING:
    from otto.streaming import StreamEvent

log = logging.getLogger(__name__)

_GOOGLE_CODE_ASSIST_API_BASE = "https://cloudcode-pa.googleapis.com"
_COPILOT_DEFAULT_API_BASE = "https://api.individual.githubcopilot.com"

# Lazy import cecli - optional dependency
try:
    from cecli.coders import Coder
    from cecli.io import InputOutput
    from cecli.mcp import McpServerManager
    from cecli.models import Model

    CECLI_AVAILABLE = True
except ImportError:
    CECLI_AVAILABLE = False
    Coder = None
    InputOutput = None
    McpServerManager = None
    Model = None


if CECLI_AVAILABLE and InputOutput is not None:
    _CecliInputOutputBase = InputOutput
else:
    _CecliInputOutputBase = object


class OttoInputOutput(_CecliInputOutputBase):
    """
    InputOutput adapter for cecli that captures output for Otto.

    Subclasses cecli.io.InputOutput with auto-confirm and output capture.
    """

    def __init__(self):
        if not CECLI_AVAILABLE or InputOutput is None:
            raise ImportError("cecli not installed. Install with: pip install cecli-dev")

        # Initialize base with auto-confirm, no pretty printing
        super().__init__(yes=True, pretty=False)

        # Output capture
        self._output_buffer: list[str] = []
        self._event_queue: asyncio.Queue[StreamEvent] | None = None

    def stream_output(self, text: str, final: bool = False) -> None:
        """Capture text chunks from cecli's streaming output."""
        self._output_buffer.append(text)

        # If we have a queue for streaming, emit text delta event
        if self._event_queue is not None:
            from otto.streaming import StreamEvent

            try:
                self._event_queue.put_nowait(StreamEvent.text_delta(text))
            except asyncio.QueueFull:
                log.warning("Stream event queue full, dropping text delta")

    def tool_output(self, *messages, log_only: bool = False, bold: bool = False, type=None) -> None:
        """Capture tool output messages from cecli."""
        text = " ".join(str(m) for m in messages)
        if text:
            self._output_buffer.append(text + "\n")

    def tool_error(self, message: str = "", strip: bool = True) -> None:
        """Capture tool error messages from cecli."""
        if message:
            self._output_buffer.append(f"Error: {message}\n")

    def tool_warning(self, message: str = "", strip: bool = True) -> None:
        """Capture tool warning messages from cecli."""
        if message:
            self._output_buffer.append(f"Warning: {message}\n")

    def tool_success(self, message: str = "", strip: bool = True) -> None:
        """Capture tool success messages from cecli."""
        if message:
            self._output_buffer.append(message + "\n")

    def get_collected_output(self) -> str:
        """Get all collected output as a single string."""
        return "".join(self._output_buffer)

    def _emit_event(self, event: StreamEvent) -> None:
        """Emit an event to the streaming queue if available."""
        if self._event_queue is not None:
            try:
                self._event_queue.put_nowait(event)
            except asyncio.QueueFull:
                log.warning("Stream event queue full, dropping event")

    async def stream_events(self) -> AsyncIterator[StreamEvent]:
        """Bridge cecli output to Otto's StreamEvent types."""
        from otto.streaming import StreamEvent

        if self._event_queue is None:
            # Not in streaming mode
            return

        while True:
            try:
                event = await asyncio.wait_for(self._event_queue.get(), timeout=0.1)
                yield event

                # Check for done event
                from otto.streaming import StreamEventType

                if event.type == StreamEventType.DONE:
                    break
            except asyncio.TimeoutError:
                # No events in queue, keep waiting
                continue
            except Exception as e:
                log.exception("Error streaming events")
                yield StreamEvent.error(str(e))
                break


class CecliBackend(AgentBackend):
    """
    Backend using cecli's Python API.

    cecli is a fork of aider focused on AI coding agents.
    This backend wraps cecli's Coder API with Otto's interface.
    """

    def __init__(self, config: AgentConfig):
        super().__init__(config)

        if not CECLI_AVAILABLE:
            log.warning("cecli not installed - CecliBackend will not be available")

        # Backend registry monkey-patches options onto AgentConfig instances.
        self._options = getattr(config, "options", None) or {}

    async def _run_coder(self, coder, message: str, timeout: int) -> None:
        """
        Execute coder.run() with timeout support for both async and sync implementations.
        """
        run_fn = coder.run
        if inspect.iscoroutinefunction(run_fn):
            await asyncio.wait_for(run_fn(message), timeout=timeout)
            return

        def _run_sync() -> None:
            result = run_fn(message)
            # Defensive: some wrappers return awaitables from non-async callables.
            if inspect.isawaitable(result):
                asyncio.run(result)

        await asyncio.wait_for(asyncio.to_thread(_run_sync), timeout=timeout)

    def _wrap_tool_events(self, coder, io: OttoInputOutput) -> None:
        """Wrap coder's process_tool_calls to emit structured tool events.

        Monkey-patches the coder instance so that each tool invocation emits
        StreamEvent.tool_use (before execution) and StreamEvent.tool_result
        (after execution). This gives the Telegram renderer real-time
        visibility into which tools are running, matching the Pi backend UX.
        """
        from otto.streaming import StreamEvent

        original = coder.process_tool_calls

        async def wrapped(tool_call_response):
            # Extract tool names and args from the LLM response
            tools: list[tuple[str, dict]] = []
            if tool_call_response is not None:
                try:
                    message = tool_call_response.choices[0].message
                    if hasattr(message, "tool_calls") and message.tool_calls:
                        for tc in message.tool_calls:
                            name = tc.function.name
                            try:
                                raw = tc.function.arguments
                                args = json.loads(raw) if raw and raw.strip() else {}
                            except (ValueError, AttributeError):
                                args = {}
                            tools.append((name, args))
                            io._emit_event(StreamEvent.tool_use(name, args))
                except (AttributeError, IndexError):
                    pass

            # Delegate to the real (AgentCoder) implementation
            result = await original(tool_call_response)

            # Emit completion events only when tools actually ran
            if result and tools:
                for name, _ in tools:
                    io._emit_event(StreamEvent.tool_result(name, "completed"))

            return result

        coder.process_tool_calls = wrapped

    @staticmethod
    def _get_provider_env_vars(provider: str) -> tuple[str, ...]:
        provider_env_vars = {
            "anthropic": ("ANTHROPIC_API_KEY",),
            "openai": ("OPENAI_API_KEY",),
            "google": ("GEMINI_API_KEY", "GOOGLE_API_KEY"),
            "gemini": ("GEMINI_API_KEY", "GOOGLE_API_KEY"),
            "copilot": ("OPENAI_API_KEY",),
            "github_copilot": ("OPENAI_API_KEY",),
            "openrouter": ("OPENROUTER_API_KEY",),
        }
        return provider_env_vars.get(provider, ())

    @staticmethod
    def _resolve_copilot_api_base(api_key: str, creds: dict | None) -> str:
        marker = "proxy-ep="
        if marker in api_key:
            endpoint = api_key.split(marker, 1)[1].split(";", 1)[0].strip()
            if endpoint:
                return f"https://{endpoint.replace('proxy.', 'api.', 1)}"

        enterprise_host = ""
        if isinstance(creds, dict):
            enterprise = str(creds.get("enterpriseUrl") or "").strip()
            if enterprise:
                # Normalize values like "https://ghe.example.com/path" to host only.
                enterprise_host = enterprise.replace("https://", "", 1).replace("http://", "", 1)
                enterprise_host = enterprise_host.split("/", 1)[0].strip()
        if enterprise_host:
            if enterprise_host.startswith("copilot-api."):
                return f"https://{enterprise_host}"
            return f"https://copilot-api.{enterprise_host}"

        return _COPILOT_DEFAULT_API_BASE

    @staticmethod
    def _is_copilot_api_base(api_base: str) -> bool:
        normalized = api_base.strip().lower().rstrip("/")
        return (
            normalized == _COPILOT_DEFAULT_API_BASE
            or normalized.startswith("https://copilot-api.")
        )

    @staticmethod
    def _seed_litellm_copilot_tokens(creds: dict | None) -> None:
        """Write Otto's copilot credentials into litellm's token cache.

        litellm's ``Authenticator`` reads from
        ``~/.config/litellm/github_copilot/{access-token,api-key.json}``.
        By pre-seeding these files we skip the interactive device-code flow.
        """
        if not isinstance(creds, dict):
            return
        token_dir = os.environ.get(
            "GITHUB_COPILOT_TOKEN_DIR",
            os.path.expanduser("~/.config/litellm/github_copilot"),
        )
        os.makedirs(token_dir, exist_ok=True)

        # access-token  — the long-lived GitHub OAuth token (our "refresh")
        github_token = creds.get("refresh", "")
        if github_token:
            access_file = os.path.join(token_dir, "access-token")
            try:
                with open(access_file, "w") as f:
                    f.write(github_token)
            except OSError:
                log.debug("Could not write litellm copilot access-token")

        # api-key.json — the short-lived Copilot token
        copilot_token = creds.get("access", "")
        expires = creds.get("expires", 0)
        if copilot_token:
            import json as _json

            api_key_file = os.path.join(token_dir, "api-key.json")
            api_key_data: dict = {
                "token": copilot_token,
                "expires_at": int(expires) + 300,  # undo the 300s safety margin
            }
            # Include endpoints if we can derive api_base
            enterprise = creds.get("enterpriseUrl")
            if enterprise:
                api_key_data["endpoints"] = {
                    "api": f"https://copilot-api.{enterprise}",
                }
            try:
                with open(api_key_file, "w") as f:
                    _json.dump(api_key_data, f)
            except OSError:
                log.debug("Could not write litellm copilot api-key.json")

    # Map litellm provider prefixes to AuthStorage provider names.
    _AUTH_PROVIDER_ALIASES: dict[str, str] = {
        "github_copilot": "copilot",
        "gemini": "google",
    }

    async def _apply_auth_storage_env(self, model: str) -> None:
        provider = model.split("/")[0].strip().lower()
        if not provider:
            return

        # Resolve litellm provider prefix to AuthStorage credential name.
        auth_provider = self._AUTH_PROVIDER_ALIASES.get(provider, provider)

        # Avoid cross-provider contamination if a previous Copilot run
        # left OPENAI_API_BASE set to a Copilot endpoint.
        if provider not in {"copilot", "github_copilot"}:
            openai_api_base = os.environ.get("OPENAI_API_BASE", "")
            if openai_api_base and self._is_copilot_api_base(openai_api_base):
                os.environ.pop("OPENAI_API_BASE", None)

        try:
            storage = AuthStorage()
            api_key = await storage.get_api_key(auth_provider)
            if not api_key:
                return

            for env_var in self._get_provider_env_vars(provider):
                os.environ[env_var] = api_key

            if provider in {"google", "gemini"}:
                os.environ["GEMINI_API_BASE"] = _GOOGLE_CODE_ASSIST_API_BASE
                return

            if provider in {"copilot", "github_copilot"}:
                creds = storage.get_credentials(auth_provider)
                os.environ["OPENAI_API_BASE"] = self._resolve_copilot_api_base(api_key, creds)
                # Seed litellm's Authenticator file cache so it skips device-code login.
                self._seed_litellm_copilot_tokens(creds)
        except Exception as e:
            # Auth integration is best-effort; fallback to existing env vars.
            log.debug("AuthStorage lookup failed for provider %s: %s", provider, e)

    @staticmethod
    async def _create_gateway_proxy_server(io: OttoInputOutput):
        """Create a cecli McpServer backed by the Otto gateway proxy.

        The gateway proxy exposes all external MCP tools and Otto's built-in
        tools through a single stdio MCP server.  Every tool call routes
        through ``gateway.request_tool()`` for policy enforcement (Pillar 3).

        Returns None if the proxy config is unavailable so the coder can
        still function without MCP tools.
        """
        try:
            from otto.mcp_gateway_proxy import get_gateway_proxy_config

            proxy_cfg = get_gateway_proxy_config()
            # cecli McpServer expects a dict with at least "command" and optional
            # "args", "env", "name".
            server_config = {
                "name": "otto-gateway",
                "command": proxy_cfg["command"],
                "args": proxy_cfg.get("args", []),
            }
            from cecli.mcp import McpServer as CecliMcpServer

            server = CecliMcpServer(server_config, io=io)
            return server
        except Exception as exc:
            log.warning("Could not create gateway proxy MCP server: %s", exc)
            return None

    async def _cleanup_mcp(self, coder) -> None:
        """Disconnect MCP servers managed by the coder's McpServerManager."""
        if coder is None:
            return
        mgr = getattr(coder, "mcp_manager", None)
        if mgr is None:
            return
        try:
            await mgr.disconnect_all()
        except Exception:
            log.debug("Error disconnecting MCP servers", exc_info=True)

    @staticmethod
    def _resolve_session_context(
        chat_id: str | None, session_id: str | None,
    ) -> tuple[str | None, str | None]:
        """Auto-detect chat_id and session_id if not provided."""
        if chat_id and session_id:
            return chat_id, session_id
        try:
            from otto import config as otto_config
            from otto.sessions import get_current_session

            if not chat_id:
                state = otto_config.get_telegram_state()
                chat_id = str(state.get("chat_id") or "") or None
            if chat_id and not session_id:
                session = get_current_session(chat_id=chat_id)
                session_id = session.get("id")
        except Exception:
            pass
        return chat_id, session_id

    async def _build_coder(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        model: str,
        io: OttoInputOutput,
        chat_id: str | None = None,
        session_id: str | None = None,
    ):
        """
        Build a cecli Coder instance.

        Args:
            prompt: User prompt (system_prompt will be prepended)
            system_prompt: System prompt to prepend to user message
            cwd: Working directory
            model: Model string in provider/model format (e.g., "anthropic/claude-sonnet-4-5")
            io: OttoInputOutput instance
            chat_id: Telegram chat ID for routing notifications
            session_id: Otto session ID for context routing

        Returns:
            Configured Coder instance
        """
        if not CECLI_AVAILABLE:
            raise ImportError("cecli not installed. Install with: pip install cecli-dev")

        # Combine system prompt with user prompt (same pattern as PiBackend)
        full_message = prompt
        if system_prompt:
            full_message = f"{system_prompt}\n\n{prompt}"

        # Best-effort OAuth/API key resolution before cecli/litellm calls.
        await self._apply_auth_storage_env(model)

        # Create model - cecli uses litellm internally, so provider/model format works
        cecli_model = Model(model)

        # Get options from config
        edit_format = self._options.get("edit_format", "agent")

        # Build MCP manager with the gateway proxy so cecli can access
        # all external MCP tools through the gateway's policy engine (Pillar 3).
        # Otto's built-in tools are also exposed through the proxy.
        gateway_proxy_server = await self._create_gateway_proxy_server(io)
        servers = [gateway_proxy_server] if gateway_proxy_server else []
        mcp_mgr = McpServerManager(servers=servers, io=io)

        # cecli expects an args namespace for runtime flags. Provide
        # safe defaults so code that reads self.args.* doesn't crash.
        from types import SimpleNamespace

        args = SimpleNamespace(
            debug=False,
            yes_always_commands=True,
            disable_scraping=True,
            fancy_input=False,
            tui=False,
            use_enhanced_map=False,
            agent_config=None,
        )

        # Register Exa search tools with cecli's ToolRegistry (before Coder.create)
        exa_client = None
        try:
            from otto.backends.cecli_exa import create_exa_client, register_exa_tools

            register_exa_tools()
            exa_client = create_exa_client()
            if exa_client is not None:
                self._exa_client = exa_client
        except Exception as e:
            log.debug("Could not load Exa tools for cecli: %s", e)

        # Register Otto's built-in tools as native cecli tools (in-process,
        # no MCP overhead).  These are Otto's own tools — they don't cross
        # an external trust boundary (Pillar 3 guards external MCP servers).
        try:
            from otto.backends.cecli_otto_tools import register_otto_tools

            register_otto_tools()
        except Exception as e:
            log.debug("Could not load Otto native tools for cecli: %s", e)

        # Create coder with Otto settings
        # - auto_commits=False: no git commits
        # - use_git=False: no git operations
        # - auto_lint=False: no automatic linting
        # - stream=False: disable litellm-level streaming to avoid
        #   litellm.stream_chunk_builder bug. Otto's own streaming
        #   works independently via OttoInputOutput callbacks.
        coder = await Coder.create(
            main_model=cecli_model,
            edit_format=edit_format,
            io=io,
            fnames=[],  # No files - cecli will discover them
            auto_commits=False,
            use_git=False,
            auto_lint=False,
            stream=False,
            mcp_manager=mcp_mgr,
            args=args,
        )

        # Attach Exa client to coder for tool access
        if exa_client is not None:
            coder._exa_client = exa_client

        # Attach session context so native Otto tools (cecli_otto_tools.py)
        # can route notifications/files to the correct Telegram chat.
        resolved_chat_id, resolved_session_id = self._resolve_session_context(
            chat_id, session_id,
        )
        coder._otto_chat_id = resolved_chat_id
        coder._otto_session_id = resolved_session_id

        # Wrap tool execution to emit structured streaming events
        self._wrap_tool_events(coder, io)

        # Set working directory
        original_cwd = os.getcwd()
        os.chdir(cwd)

        # Store original dir for cleanup
        coder._otto_original_cwd = original_cwd

        return coder, full_message

    async def run_async(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
        chat_id: str | None = None,
        session_id: str | None = None,
    ) -> AgentResult:
        """
        Run the agent asynchronously.

        Args:
            prompt: User prompt
            system_prompt: System prompt
            cwd: Working directory
            timeout: Request timeout in seconds
            model: Model specification (e.g., "anthropic/claude-sonnet-4-5")
            chat_id: Telegram chat ID for routing notifications
            session_id: Otto session ID for context routing

        Returns:
            AgentResult with output and metadata
        """
        if not CECLI_AVAILABLE:
            return AgentResult(
                success=False,
                output="",
                error="cecli not installed. Install with: pip install cecli-dev",
                backend=self.name,
            )

        if not self.config.enabled:
            return AgentResult(
                success=False,
                output="",
                error=f"Backend {self.name} is not enabled",
                backend=self.name,
            )

        start_time = time.time()
        io = OttoInputOutput()
        coder = None

        try:
            # Use provided model or fall back to config
            effective_model = model or self.config.model or "anthropic/claude-sonnet-4-5"

            # Build coder
            coder, full_message = await self._build_coder(
                prompt=prompt,
                system_prompt=system_prompt,
                cwd=cwd,
                model=effective_model,
                io=io,
                chat_id=chat_id,
                session_id=session_id,
            )

            # Run coder with timeout
            try:
                await self._run_coder(coder, full_message, timeout)
            except asyncio.TimeoutError:
                return AgentResult(
                    success=False,
                    output=io.get_collected_output(),
                    error=f"Request timed out after {timeout}s",
                    backend=self.name,
                    duration_seconds=time.time() - start_time,
                )

            # Collect output
            output = io.get_collected_output()

            # Try to get cost/token info from coder if available
            cost_usd = None
            input_tokens = None
            output_tokens = None

            if hasattr(coder, "total_cost"):
                cost_usd = coder.total_cost
            if hasattr(coder, "input_tokens"):
                input_tokens = coder.input_tokens
            if hasattr(coder, "output_tokens"):
                output_tokens = coder.output_tokens

            return AgentResult(
                success=True,
                output=output,
                error=None,
                backend=self.name,
                duration_seconds=time.time() - start_time,
                cost_usd=cost_usd,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
            )

        except Exception as e:
            log.exception("Cecli execution error")
            return AgentResult(
                success=False,
                output=io.get_collected_output(),
                error=str(e),
                backend=self.name,
                duration_seconds=time.time() - start_time,
            )
        finally:
            # Restore original working directory
            if coder is not None and hasattr(coder, "_otto_original_cwd"):
                os.chdir(coder._otto_original_cwd)
            # Disconnect MCP servers (kills gateway proxy subprocess)
            await self._cleanup_mcp(coder)
            # Close Exa client
            if hasattr(self, "_exa_client") and self._exa_client:
                try:
                    await self._exa_client.close()
                except Exception:
                    pass
                self._exa_client = None

    def run_sync(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
    ) -> AgentResult:
        """Run synchronously by wrapping async."""
        return asyncio.run(self.run_async(prompt, system_prompt, cwd, timeout, model))

    async def run_async_streaming(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
        chat_id: str | None = None,
        session_id: str | None = None,
    ) -> AsyncIterator[StreamEvent]:
        """
        Run the agent with streaming output.

        Args:
            prompt: User prompt
            system_prompt: System prompt
            cwd: Working directory
            timeout: Request timeout in seconds
            model: Model specification
            chat_id: Telegram chat ID for routing notifications
            session_id: Otto session ID for context routing

        Yields:
            StreamEvent objects
        """
        from otto.streaming import StreamEvent

        if not CECLI_AVAILABLE:
            yield StreamEvent.error("cecli not installed. Install with: pip install cecli-dev")
            yield StreamEvent.done()
            return

        if not self.config.enabled:
            yield StreamEvent.error(f"Backend {self.name} is not enabled")
            yield StreamEvent.done()
            return

        # Create IO with event queue for streaming
        io = OttoInputOutput()
        io._event_queue = asyncio.Queue(maxsize=1000)
        coder = None

        try:
            # Use provided model or fall back to config
            effective_model = model or self.config.model or "anthropic/claude-sonnet-4-5"

            # Build coder
            coder, full_message = await self._build_coder(
                prompt=prompt,
                system_prompt=system_prompt,
                cwd=cwd,
                model=effective_model,
                io=io,
                chat_id=chat_id,
                session_id=session_id,
            )

            # Start thinking
            yield StreamEvent.thinking()

            # Run coder in background task
            async def run_coder():
                try:
                    await self._run_coder(coder, full_message, timeout)
                    io._event_queue.put_nowait(StreamEvent.done())
                except asyncio.TimeoutError:
                    io._event_queue.put_nowait(
                        StreamEvent.error(f"Request timed out after {timeout}s")
                    )
                    io._event_queue.put_nowait(StreamEvent.done())
                except Exception as e:
                    log.exception("Cecli streaming error")
                    io._event_queue.put_nowait(StreamEvent.error(str(e)))
                    io._event_queue.put_nowait(StreamEvent.done())

            # Start coder task
            coder_task = asyncio.create_task(run_coder())

            # Stream events from queue
            async for event in io.stream_events():
                yield event

            # Wait for coder to finish
            await coder_task

        except Exception as e:
            log.exception("Cecli streaming setup error")
            yield StreamEvent.error(str(e))
            yield StreamEvent.done()
        finally:
            # Restore original working directory
            if "coder" in locals() and hasattr(coder, "_otto_original_cwd"):
                os.chdir(coder._otto_original_cwd)
            # Disconnect MCP servers (kills gateway proxy subprocess)
            if "coder" in locals():
                await self._cleanup_mcp(coder)
            # Close Exa client
            if hasattr(self, "_exa_client") and self._exa_client:
                try:
                    await self._exa_client.close()
                except Exception:
                    pass
                self._exa_client = None

    def get_capabilities(self) -> dict:
        """Return backend capabilities."""
        return {
            "name": self.name,
            "supports_system_prompt": False,  # We prepend to user message
            "supports_json_output": False,
            "supports_sandbox": False,
            "supports_mcp": True,
            "supports_streaming": True,
            "supports_tool_use": True,
        }

    def is_available(self) -> bool:
        """Check if the backend is available and enabled."""
        if not self.config.enabled:
            return False
        return CECLI_AVAILABLE

    def supports_streaming(self) -> bool:
        """Check if this backend supports streaming."""
        return True


__all__ = ["CecliBackend", "OttoInputOutput"]
