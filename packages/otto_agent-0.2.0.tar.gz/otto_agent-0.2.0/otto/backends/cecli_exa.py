"""
Exa web/code search tools for the cecli backend.

Wraps the shared ExaMCPClient in cecli-compatible tool classes so that
cecli's AgentCoder can invoke web and code search as local tools.

The tools access the client via ``coder._exa_client``, which is attached
by CecliBackend._build_coder().
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from otto.tools.exa import ExaMCPClient

log = logging.getLogger(__name__)

MAX_OUTPUT_CHARS = 15_000


# ---------------------------------------------------------------------------
# cecli-compatible tool classes
# ---------------------------------------------------------------------------


class CecliWebSearchTool:
    """Search the web using Exa — cecli tool interface."""

    NORM_NAME = "websearch"
    SCHEMA = {
        "type": "function",
        "function": {
            "name": "WebSearch",
            "description": (
                "Search the web for current information on any topic. "
                "Returns relevant web page titles, URLs, and snippets."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "The search query",
                    },
                    "num_results": {
                        "type": "integer",
                        "description": "Number of results to return (1-20, default 5)",
                    },
                },
                "required": ["query"],
            },
        },
    }

    @classmethod
    async def execute(cls, coder: Any, query: str, num_results: int = 5, **kwargs: Any) -> str:
        client: ExaMCPClient | None = getattr(coder, "_exa_client", None)
        if client is None:
            return "Exa search is not available (no API client configured)."

        num_results = max(1, min(20, int(num_results)))

        try:
            text = await client.call_tool(
                "web_search_exa",
                {"query": query, "numResults": num_results},
            )
            output = f"## Web Search Results for: {query}\n\n{text}"
            if len(output) > MAX_OUTPUT_CHARS:
                output = output[:MAX_OUTPUT_CHARS] + "\n\n[Results truncated]"
            return output
        except Exception as e:
            log.warning("Exa web_search failed: %s", e)
            return f"Web search failed: {e}"

    @classmethod
    def process_response(cls, coder: Any, params: dict) -> Any:
        required = cls.SCHEMA["function"]["parameters"].get("required", [])
        missing = [p for p in required if p not in params]
        if missing:
            return f"Missing required parameters for WebSearch: {', '.join(missing)}"
        try:
            return cls.execute(coder, **params)
        except Exception as e:
            return f"WebSearch error: {e}"


class CecliCodeSearchTool:
    """Search code repositories using Exa — cecli tool interface."""

    NORM_NAME = "codesearch"
    SCHEMA = {
        "type": "function",
        "function": {
            "name": "CodeSearch",
            "description": (
                "Search code repositories for implementations, examples, "
                "and documentation. Returns relevant code snippets and context."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": (
                            "The code search query (e.g. 'Python async HTTP client example')"
                        ),
                    },
                    "max_tokens": {
                        "type": "integer",
                        "description": "Maximum tokens in response (1000-50000, default 5000)",
                    },
                },
                "required": ["query"],
            },
        },
    }

    @classmethod
    async def execute(cls, coder: Any, query: str, max_tokens: int = 5000, **kwargs: Any) -> str:
        client: ExaMCPClient | None = getattr(coder, "_exa_client", None)
        if client is None:
            return "Exa code search is not available (no API client configured)."

        max_tokens = max(1000, min(50000, int(max_tokens)))

        try:
            text = await client.call_tool(
                "get_code_context_exa",
                {"query": query, "tokensNum": max_tokens},
            )
            output = f"## Code Search Results for: {query}\n\n{text}"
            if len(output) > MAX_OUTPUT_CHARS:
                output = output[:MAX_OUTPUT_CHARS] + "\n\n[Results truncated]"
            return output
        except Exception as e:
            log.warning("Exa code_search failed: %s", e)
            return f"Code search failed: {e}"

    @classmethod
    def process_response(cls, coder: Any, params: dict) -> Any:
        required = cls.SCHEMA["function"]["parameters"].get("required", [])
        missing = [p for p in required if p not in params]
        if missing:
            return f"Missing required parameters for CodeSearch: {', '.join(missing)}"
        try:
            return cls.execute(coder, **params)
        except Exception as e:
            return f"CodeSearch error: {e}"


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def register_exa_tools() -> None:
    """Register Exa tools with cecli's ToolRegistry.

    Safe to call multiple times — idempotent.
    """
    try:
        from cecli.coders.agent_coder import ToolRegistry
    except ImportError:
        log.debug("cecli not available, skipping Exa tool registration")
        return

    for tool_cls in (CecliWebSearchTool, CecliCodeSearchTool):
        if tool_cls.NORM_NAME not in ToolRegistry._tools:
            ToolRegistry.register(tool_cls)
            log.debug("Registered cecli tool: %s", tool_cls.NORM_NAME)


def create_exa_client() -> ExaMCPClient | None:
    """Create an ExaMCPClient with API key from secrets.

    Returns None if the exa module is unavailable.
    """
    try:
        from otto.config import get_secret
        from otto.tools.exa import ExaMCPClient
    except ImportError:
        log.debug("Could not import exa tools, skipping client creation")
        return None

    api_key = get_secret("EXA_API_KEY")
    if api_key:
        log.info("Cecli backend: using authenticated Exa access (EXA_API_KEY set)")

    return ExaMCPClient(api_key=api_key)


__all__ = [
    "CecliWebSearchTool",
    "CecliCodeSearchTool",
    "register_exa_tools",
    "create_exa_client",
]
