"""
Native cecli tool wrappers for Otto's built-in tools.

Registers Otto's essential MCP tools (notify, memory, agents, files,
schedules) as cecli ToolRegistry classes so they run in-process without
gateway proxy overhead.  These are Otto's own tools — they don't cross
an external trust boundary, so bypassing the gateway is correct per
Pillar 3 (gateway guards external MCP servers, not Otto talking to itself).

Pattern matches cecli_exa.py: each class has NORM_NAME, SCHEMA, execute(),
and process_response().
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

log = logging.getLogger(__name__)


def _run_async(coro):
    """Run an async function from a sync/async context inside cecli."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        # Already in an async context — wrap as a task future
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(asyncio.run, coro).result(timeout=60)
    return asyncio.run(coro)


def _get_chat_id(coder: Any) -> str | None:
    return getattr(coder, "_otto_chat_id", None)


def _get_session_id(coder: Any) -> str | None:
    return getattr(coder, "_otto_session_id", None)


def _format_result(result: dict) -> str:
    """Format an Otto tool result dict as readable text."""
    if not isinstance(result, dict):
        return str(result)
    if result.get("success"):
        data = result.get("data")
        if data:
            return json.dumps(data, indent=2, default=str)
        return "OK"
    error = result.get("error", "Unknown error")
    return f"Error: {error}"


# ---------------------------------------------------------------------------
# Notify
# ---------------------------------------------------------------------------


class CecliNotifySendTool:
    """Send a notification to the user — cecli tool interface."""

    NORM_NAME = "notify_send"
    SCHEMA = {
        "type": "function",
        "function": {
            "name": "notify_send",
            "description": (
                "Send a notification message to the user via Telegram. "
                "Use this to inform the user about task completion, errors, or updates."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "message": {
                        "type": "string",
                        "description": "The notification message to send",
                    },
                    "chat_id": {
                        "type": "string",
                        "description": "Target chat ID (auto-detected if omitted)",
                    },
                },
                "required": ["message"],
            },
        },
    }

    @classmethod
    async def execute(cls, coder: Any, message: str, chat_id: str | None = None, **kw) -> str:
        from otto.mcp_tools.notify import notify_send

        chat_id = chat_id or _get_chat_id(coder)
        result = await notify_send(message=message, chat_id=chat_id)
        return _format_result(result)

    @classmethod
    def process_response(cls, coder: Any, params: dict) -> Any:
        if "message" not in params:
            return "Missing required parameter: message"
        return cls.execute(coder, **params)


# ---------------------------------------------------------------------------
# Send file
# ---------------------------------------------------------------------------


class CecliSendFileTool:
    """Send a file to the user's chat — cecli tool interface."""

    NORM_NAME = "send_file"
    SCHEMA = {
        "type": "function",
        "function": {
            "name": "send_file",
            "description": (
                "Send a file to the user's Telegram chat. "
                "Supports any file type (documents, images, code, etc.)."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "Path to the file to send",
                    },
                    "caption": {
                        "type": "string",
                        "description": "Optional caption for the file",
                    },
                    "chat_id": {
                        "type": "string",
                        "description": "Target chat ID (auto-detected if omitted)",
                    },
                },
                "required": ["file_path"],
            },
        },
    }

    @classmethod
    async def execute(
        cls, coder: Any, file_path: str, caption: str | None = None,
        chat_id: str | None = None, **kw,
    ) -> str:
        from otto.mcp_tools.platform import send_file

        chat_id = chat_id or _get_chat_id(coder)
        result = await send_file(file_path=file_path, caption=caption, chat_id=chat_id)
        return _format_result(result)

    @classmethod
    def process_response(cls, coder: Any, params: dict) -> Any:
        if "file_path" not in params:
            return "Missing required parameter: file_path"
        return cls.execute(coder, **params)


# ---------------------------------------------------------------------------
# Send buttons
# ---------------------------------------------------------------------------


class CecliSendButtonsTool:
    """Send interactive buttons to the chat — cecli tool interface."""

    NORM_NAME = "send_buttons"
    SCHEMA = {
        "type": "function",
        "function": {
            "name": "send_buttons",
            "description": (
                "Send a message with interactive inline keyboard buttons. "
                "Each button has a label and callback_data."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "Message text to accompany the buttons",
                    },
                    "buttons": {
                        "type": "array",
                        "description": "List of button objects with 'label' and 'callback_data'",
                        "items": {
                            "type": "object",
                            "properties": {
                                "label": {"type": "string"},
                                "callback_data": {"type": "string"},
                            },
                            "required": ["label", "callback_data"],
                        },
                    },
                    "chat_id": {
                        "type": "string",
                        "description": "Target chat ID (auto-detected if omitted)",
                    },
                    "columns": {
                        "type": "integer",
                        "description": "Number of button columns (default 2)",
                    },
                },
                "required": ["text", "buttons"],
            },
        },
    }

    @classmethod
    async def execute(
        cls, coder: Any, text: str, buttons: list,
        chat_id: str | None = None, columns: int = 2, **kw,
    ) -> str:
        from otto.mcp_tools.platform import send_buttons

        chat_id = chat_id or _get_chat_id(coder)
        result = await send_buttons(
            text=text, buttons=buttons, chat_id=chat_id, columns=columns,
        )
        return _format_result(result)

    @classmethod
    def process_response(cls, coder: Any, params: dict) -> Any:
        missing = [p for p in ("text", "buttons") if p not in params]
        if missing:
            return f"Missing required parameters: {', '.join(missing)}"
        return cls.execute(coder, **params)


# ---------------------------------------------------------------------------
# Memory recall
# ---------------------------------------------------------------------------


class CecliMemoryRecallTool:
    """Search memory for relevant information — cecli tool interface."""

    NORM_NAME = "memory_recall"
    SCHEMA = {
        "type": "function",
        "function": {
            "name": "memory_recall",
            "description": (
                "Search file-based memory for stored information. "
                "Returns matching content from projects, facts, and contexts."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query string",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum results to return (default 10)",
                    },
                },
                "required": ["query"],
            },
        },
    }

    @classmethod
    async def execute(cls, coder: Any, query: str, limit: int = 10, **kw) -> str:
        from otto_tools.memory import search_memory

        results = await asyncio.to_thread(search_memory, query, limit)
        if not results:
            return f"No memory matches for: {query}"
        return json.dumps({"query": query, "results": results}, indent=2, default=str)

    @classmethod
    def process_response(cls, coder: Any, params: dict) -> Any:
        if "query" not in params:
            return "Missing required parameter: query"
        return cls.execute(coder, **params)


# ---------------------------------------------------------------------------
# Memory remember
# ---------------------------------------------------------------------------


class CecliMemoryRememberTool:
    """Store information in memory — cecli tool interface."""

    NORM_NAME = "memory_remember"
    SCHEMA = {
        "type": "function",
        "function": {
            "name": "memory_remember",
            "description": (
                "Store information in file-based memory. "
                "Categories: projects, facts, contexts."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "category": {
                        "type": "string",
                        "description": "Memory category: projects, facts, or contexts",
                        "enum": ["projects", "facts", "contexts"],
                    },
                    "topic": {
                        "type": "string",
                        "description": "Topic name for the memory entry",
                    },
                    "content": {
                        "type": "string",
                        "description": "Content to store",
                    },
                },
                "required": ["category", "topic", "content"],
            },
        },
    }

    @classmethod
    async def execute(
        cls, coder: Any, category: str, topic: str, content: str, **kw,
    ) -> str:
        from datetime import datetime

        from otto.paths import MEMORY_DIR
        from otto_tools.memory import CATEGORIES, sanitize_topic

        if category not in CATEGORIES:
            return f"Invalid category '{category}'. Valid: {', '.join(CATEGORIES)}"

        def _remember():
            MEMORY_DIR.mkdir(parents=True, exist_ok=True)
            cat_dir = MEMORY_DIR / category
            cat_dir.mkdir(parents=True, exist_ok=True)
            safe_topic = sanitize_topic(topic)
            file_path = cat_dir / f"{safe_topic}.md"
            timestamp = datetime.now().isoformat()
            if file_path.exists():
                file_path.write_text(
                    file_path.read_text()
                    + f"\n\n---\n_Updated: {timestamp}_\n\n{content}"
                )
                return {"action": "updated", "file": str(file_path)}
            else:
                file_path.write_text(
                    f"# {topic}\n\n_Created: {timestamp}_\n\n{content}\n"
                )
                return {"action": "created", "file": str(file_path)}

        result = await asyncio.to_thread(_remember)
        return json.dumps(result, default=str)

    @classmethod
    def process_response(cls, coder: Any, params: dict) -> Any:
        missing = [p for p in ("category", "topic", "content") if p not in params]
        if missing:
            return f"Missing required parameters: {', '.join(missing)}"
        return cls.execute(coder, **params)


# ---------------------------------------------------------------------------
# Agent spawn
# ---------------------------------------------------------------------------


class CecliAgentSpawnTool:
    """Spawn a background agent — cecli tool interface."""

    NORM_NAME = "agent_spawn"
    SCHEMA = {
        "type": "function",
        "function": {
            "name": "agent_spawn",
            "description": (
                "Spawn a background agent to handle a task asynchronously. "
                "The agent runs independently and can notify on completion."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "prompt": {
                        "type": "string",
                        "description": "The task prompt for the agent",
                    },
                    "backend": {
                        "type": "string",
                        "description": "Backend name (default: cecli)",
                    },
                    "model": {
                        "type": "string",
                        "description": "Optional model spec for routing",
                    },
                    "task_name": {
                        "type": "string",
                        "description": "Human-readable task description",
                    },
                    "notify": {
                        "type": "boolean",
                        "description": "Notify on completion (default: true)",
                    },
                },
                "required": ["prompt"],
            },
        },
    }

    @classmethod
    async def execute(
        cls, coder: Any, prompt: str, backend: str = "cecli",
        model: str | None = None, task_name: str | None = None,
        notify: bool = True, **kw,
    ) -> str:
        from otto.mcp_tools.agent import agent_spawn

        result = await agent_spawn(
            prompt=prompt,
            backend=backend,
            model=model,
            task_name=task_name,
            notify=notify,
            session_id=_get_session_id(coder),
            chat_id=_get_chat_id(coder),
        )
        return _format_result(result)

    @classmethod
    def process_response(cls, coder: Any, params: dict) -> Any:
        if "prompt" not in params:
            return "Missing required parameter: prompt"
        return cls.execute(coder, **params)


# ---------------------------------------------------------------------------
# Agent list
# ---------------------------------------------------------------------------


class CecliAgentListTool:
    """List agents — cecli tool interface."""

    NORM_NAME = "agent_list"
    SCHEMA = {
        "type": "function",
        "function": {
            "name": "agent_list",
            "description": "List recent agents with optional status filter.",
            "parameters": {
                "type": "object",
                "properties": {
                    "status": {
                        "type": "string",
                        "description": "Filter: running, completed, failed, or all",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Max results (default 20)",
                    },
                },
            },
        },
    }

    @classmethod
    async def execute(
        cls, coder: Any, status: str | None = None, limit: int = 20, **kw,
    ) -> str:
        from otto.mcp_tools.agent import agent_list

        result = await agent_list(status=status, limit=limit)
        return _format_result(result)

    @classmethod
    def process_response(cls, coder: Any, params: dict) -> Any:
        return cls.execute(coder, **params)


# ---------------------------------------------------------------------------
# Agent output
# ---------------------------------------------------------------------------


class CecliAgentOutputTool:
    """Get output from an agent — cecli tool interface."""

    NORM_NAME = "agent_output"
    SCHEMA = {
        "type": "function",
        "function": {
            "name": "agent_output",
            "description": "Get output from a running or completed agent.",
            "parameters": {
                "type": "object",
                "properties": {
                    "agent_id": {
                        "type": "string",
                        "description": "The agent ID to get output from",
                    },
                    "tail": {
                        "type": "integer",
                        "description": "Only return the last N lines",
                    },
                },
                "required": ["agent_id"],
            },
        },
    }

    @classmethod
    async def execute(
        cls, coder: Any, agent_id: str, tail: int | None = None, **kw,
    ) -> str:
        from otto.mcp_tools.agent import agent_output

        result = await agent_output(agent_id=agent_id, tail=tail)
        return _format_result(result)

    @classmethod
    def process_response(cls, coder: Any, params: dict) -> Any:
        if "agent_id" not in params:
            return "Missing required parameter: agent_id"
        return cls.execute(coder, **params)


# ---------------------------------------------------------------------------
# Schedule task
# ---------------------------------------------------------------------------


class CecliScheduleTaskTool:
    """Schedule a task for future execution — cecli tool interface."""

    NORM_NAME = "schedule_task"
    SCHEMA = {
        "type": "function",
        "function": {
            "name": "schedule_task",
            "description": (
                "Schedule a task for future execution. "
                "Provide exactly one of: delay_seconds, run_at, or cron."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "prompt": {
                        "type": "string",
                        "description": "The task prompt to execute",
                    },
                    "delay_seconds": {
                        "type": "integer",
                        "description": "Run after this many seconds from now",
                    },
                    "run_at": {
                        "type": "string",
                        "description": "ISO-8601 datetime for one-shot execution",
                    },
                    "cron": {
                        "type": "string",
                        "description": "Cron expression for recurring execution",
                    },
                    "name": {
                        "type": "string",
                        "description": "Human-readable schedule name",
                    },
                    "notify": {
                        "type": "boolean",
                        "description": "Notify on completion (default: true)",
                    },
                },
                "required": ["prompt"],
            },
        },
    }

    @classmethod
    async def execute(
        cls, coder: Any, prompt: str,
        delay_seconds: int | None = None,
        run_at: str | None = None,
        cron: str | None = None,
        name: str | None = None,
        notify: bool = True,
        **kw,
    ) -> str:
        from otto.mcp_tools.schedule import schedule_task

        result = await schedule_task(
            prompt=prompt,
            delay_seconds=delay_seconds,
            run_at=run_at,
            cron=cron,
            name=name,
            notify=notify,
            chat_id=_get_chat_id(coder),
        )
        return _format_result(result)

    @classmethod
    def process_response(cls, coder: Any, params: dict) -> Any:
        if "prompt" not in params:
            return "Missing required parameter: prompt"
        return cls.execute(coder, **params)


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

ALL_OTTO_TOOLS = (
    CecliNotifySendTool,
    CecliSendFileTool,
    CecliSendButtonsTool,
    CecliMemoryRecallTool,
    CecliMemoryRememberTool,
    CecliAgentSpawnTool,
    CecliAgentListTool,
    CecliAgentOutputTool,
    CecliScheduleTaskTool,
)


def register_otto_tools() -> None:
    """Register Otto tools with cecli's ToolRegistry.

    Safe to call multiple times — idempotent.
    """
    try:
        from cecli.coders.agent_coder import ToolRegistry
    except ImportError:
        log.debug("cecli not available, skipping Otto tool registration")
        return

    for tool_cls in ALL_OTTO_TOOLS:
        if tool_cls.NORM_NAME not in ToolRegistry._tools:
            ToolRegistry.register(tool_cls)
            log.debug("Registered cecli tool: %s", tool_cls.NORM_NAME)


__all__ = [
    "ALL_OTTO_TOOLS",
    "register_otto_tools",
    "CecliNotifySendTool",
    "CecliSendFileTool",
    "CecliSendButtonsTool",
    "CecliMemoryRecallTool",
    "CecliMemoryRememberTool",
    "CecliAgentSpawnTool",
    "CecliAgentListTool",
    "CecliAgentOutputTool",
    "CecliScheduleTaskTool",
]
