"""
Generic backend using LiteLLM for multi-provider LLM support.

Provides tool calling via Otto-managed agentic loop with:
- Core tools: read_file, write_file, edit_file, bash, glob, grep
- MCP tools: memory, agent, pipeline, notify, platform tools
- SafeguardConfig: Same protections as other Otto backends

Supports any LiteLLM-compatible provider:
- OpenRouter: openrouter/meta-llama/llama-3.3-70b-instruct
- Ollama: ollama/qwen2.5-coder
- Gemini: gemini/gemini-2.0-flash
- OpenAI: gpt-4o
- Anthropic (direct): claude-sonnet-4-5-20250514

Example config in settings.yaml:
    agent:
      backends:
        litellm:
          enabled: true
          model: "openrouter/meta-llama/llama-3.3-70b-instruct"
          options:
            max_turns: 50
            timeout: 300
            api_base: null
            api_key_env: "OPENROUTER_API_KEY"
            safeguards:
              enabled: true
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .base import AgentBackend, AgentConfig, AgentResult

if TYPE_CHECKING:
    from otto.streaming import StreamEvent

log = logging.getLogger(__name__)


@dataclass
class GenericConfig:
    """Configuration for GenericBackend extracted from backend options."""

    max_turns: int = 50
    timeout: int = 300
    api_base: str | None = None
    api_key_env: str | None = None
    include_mcp_tools: bool = True
    include_exa_tools: bool = True

    @classmethod
    def from_options(cls, options: dict | None) -> GenericConfig:
        """Create config from options dict."""
        if not options:
            return cls()
        return cls(
            max_turns=options.get("max_turns", 50),
            timeout=options.get("timeout", 300),
            api_base=options.get("api_base"),
            api_key_env=options.get("api_key_env"),
            include_mcp_tools=options.get("include_mcp_tools", True),
            include_exa_tools=options.get("include_exa_tools", True),
        )


class GatewayToolExecutor:
    """
    Proxy executor that routes tool calls through the native gateway.

    Used by GenericBackend to execute tools from external MCP servers
    with full gateway policy enforcement (allowlist, safeguards, audit).
    """

    def __init__(self, gateway: Any, server: str, tool: str):
        self._gateway = gateway
        self._server = server
        self._tool = tool

    async def __call__(self, **kwargs: Any) -> dict[str, Any]:
        """Execute the tool through the gateway."""
        from otto.gateway import ToolRequest

        response = await self._gateway.request_tool(
            ToolRequest(
                server=self._server,
                tool=self._tool,
                arguments=kwargs,
                backend="litellm",
            )
        )
        return {
            "success": response.success,
            "data": response.output if response.success else None,
            "error": response.error,
        }


class GenericBackend(AgentBackend):
    """
    Backend using LiteLLM for multi-provider LLM support with Otto-managed tool calling.

    Key features:
    - Works with any LiteLLM-compatible provider (OpenRouter, Ollama, Gemini, etc.)
    - Otto manages the agentic loop (not relying on provider's agent features)
    - Same safeguards as Claude SDK backend (protected paths, blocked commands)
    - Includes core tools + flattened MCP tools

    Tool execution flow:
    1. Send prompt + tools to LLM
    2. If response includes tool_calls, execute them locally
    3. Append tool results to messages
    4. Repeat until no tool_calls or max_turns reached
    """

    def __init__(self, config: AgentConfig):
        super().__init__(config)

        # Extract backend options (with sdk_options fallback for migration)
        options = getattr(config, "options", None) or getattr(config, "sdk_options", None) or {}
        self.generic_config = GenericConfig.from_options(options)

        # Setup safeguards
        from otto.safeguards import SafeguardConfig

        safeguard_config = options.get("safeguards", {})
        self.safeguards = SafeguardConfig.from_config(safeguard_config)

    def _get_api_key(self, model: str | None = None) -> str | None:
        """
        Get API key from Otto's config (env vars + ~/.otto/config/.env).

        Checks in order:
        1. Provider-specific env var inferred from model (e.g., groq/* → GROQ_API_KEY)
        2. Explicitly configured api_key_env from settings (fallback)
        3. Common fallback env vars

        Uses Otto's get_secret() to check both os.environ AND ~/.otto/config/.env
        """
        from otto.config import get_secret

        # 1. Infer from model provider prefix (highest priority)
        effective_model = model or self.config.model or ""
        provider = effective_model.split("/")[0].lower() if "/" in effective_model else ""

        # Map providers to their env var names
        provider_env_vars = {
            "openrouter": "OPENROUTER_API_KEY",
            "cerebras": "CEREBRAS_API_KEY",
            "gemini": "GEMINI_API_KEY",
            "google": "GEMINI_API_KEY",
            "anthropic": "ANTHROPIC_API_KEY",
            "openai": "OPENAI_API_KEY",
            "groq": "GROQ_API_KEY",
            "together": "TOGETHER_API_KEY",
            "mistral": "MISTRAL_API_KEY",
            "cohere": "COHERE_API_KEY",
            "fireworks": "FIREWORKS_API_KEY",
            "deepseek": "DEEPSEEK_API_KEY",
            "perplexity": "PERPLEXITY_API_KEY",
        }

        if provider in provider_env_vars:
            key = get_secret(provider_env_vars[provider])
            if key:
                return key

        # 2. Explicitly configured env var (fallback for unknown providers)
        if self.generic_config.api_key_env:
            key = get_secret(self.generic_config.api_key_env)
            if key:
                return key

        # 3. Common fallbacks (for models without prefix like "gpt-4o")
        for env_var in ["OPENAI_API_KEY", "OPENROUTER_API_KEY"]:
            key = get_secret(env_var)
            if key:
                return key

        return None

    def _sanitize_error(self, error: Exception) -> str:
        """
        Convert LiteLLM exceptions to user-friendly error messages.

        Strips internal details like class names and provider prefixes.
        """
        error_str = str(error)

        # Common error patterns to make user-friendly
        error_mappings = [
            # Authentication errors
            ("Wrong API Key", "Invalid API key. Check your provider's API key is set correctly."),
            ("invalid_api_key", "Invalid API key. Check your provider's API key is set correctly."),
            ("AuthenticationError", "Authentication failed. Check your API key."),
            (
                "Incorrect API key",
                "Invalid API key. Check your provider's API key is set correctly.",
            ),
            # Rate limits
            ("rate_limit", "Rate limit exceeded. Please wait and try again."),
            ("RateLimitError", "Rate limit exceeded. Please wait and try again."),
            # Model errors
            ("model_not_found", "Model not found. Check the model name is correct."),
            ("does not exist", "Model not found. Check the model name is correct."),
            # Quota/billing
            ("quota", "API quota exceeded. Check your account billing."),
            ("insufficient_quota", "API quota exceeded. Check your account billing."),
            # Connection errors
            ("ConnectionError", "Could not connect to provider. Check your network."),
            ("timeout", "Request timed out. Try again or increase timeout."),
            # Content policy
            ("content_policy", "Content blocked by provider's safety policy."),
            ("safety", "Content blocked by provider's safety policy."),
        ]

        for pattern, friendly_msg in error_mappings:
            if pattern.lower() in error_str.lower():
                return friendly_msg

        # Remove common prefixes like "litellm.BadRequestError: CerebrasException - "
        # Look for the actual message after the last " - " or ": "
        for sep in [" - ", ": "]:
            if sep in error_str:
                parts = error_str.split(sep)
                # Take the last meaningful part
                cleaned = parts[-1].strip()
                if cleaned and len(cleaned) > 5:  # Ensure we have something useful
                    error_str = cleaned
                    break

        # If still looks like an exception, try to extract the message
        if "Error" in error_str and "(" in error_str:
            # Strip class name prefix
            if "- " in error_str:
                error_str = error_str.split("- ", 1)[-1]

        return error_str if error_str else "An unknown error occurred"

    def _build_tools(self, cwd: Path) -> tuple[list[dict], dict[str, Any]]:
        """
        Build tool schemas and executor registry.

        Returns:
            (schemas, executors): schemas is list of OpenAI-format tool defs,
                                  executors maps tool name to callable
        """
        from otto.tools import ToolRegistry
        from otto.tools.executors import create_core_tools

        # Create core tools
        core_tools = create_core_tools(cwd, self.safeguards)

        # Register in registry
        registry = ToolRegistry()
        registry.register_all(core_tools)

        # Add Exa search tools if enabled (registered as BaseTool in registry)
        if self.generic_config.include_exa_tools:
            try:
                from otto.tools.exa import create_exa_tools

                exa_tools, self._exa_client = create_exa_tools()
                registry.register_all(exa_tools)
            except Exception as e:
                log.warning("Could not load Exa tools: %s", e)

        # Get schemas and build executor mapping from registry
        schemas = registry.list_schemas()
        executors: dict[str, Any] = {}
        for tool in registry:
            executors[tool.name] = tool

        # Add MCP tools if enabled (not in registry, added separately)
        if self.generic_config.include_mcp_tools:
            try:
                from otto.tools.schemas import get_mcp_tool_executors, get_mcp_tool_schemas

                mcp_schemas = get_mcp_tool_schemas()
                mcp_executors = get_mcp_tool_executors()

                schemas.extend(mcp_schemas)
                executors.update(mcp_executors)
            except ImportError as e:
                log.warning("Could not load MCP tools: %s", e)

        # Add external MCP server tools via native gateway
        gw_schemas, gw_executors = self._build_gateway_tools()
        schemas.extend(gw_schemas)
        executors.update(gw_executors)

        return schemas, executors

    def _build_gateway_tools(self) -> tuple[list[dict], dict[str, Any]]:
        """
        Discover tools from external MCP servers via the native gateway.

        For each enabled, non-builtin server, fetches tool schemas and creates
        GatewayToolExecutor wrappers that route execution through the gateway.

        Returns:
            (schemas, executors): OpenAI-format schemas + name->executor map
        """
        from otto.gateway import get_gateway

        schemas: list[dict] = []
        executors: dict[str, Any] = {}

        try:
            gateway = get_gateway()
        except Exception as e:
            log.warning("Could not initialize gateway for tool discovery: %s", e)
            return schemas, executors

        for name, policy in gateway.list_servers().items():
            if not policy.enabled or policy.builtin:
                continue
            if not policy.transport:
                continue

            try:
                # Use asyncio to fetch tool schemas (called from sync _build_tools)
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    # We're inside an async context -- schedule coroutine
                    import concurrent.futures

                    with concurrent.futures.ThreadPoolExecutor() as pool:
                        server_schemas = pool.submit(
                            lambda: asyncio.run(gateway.get_server_tool_schemas(name))
                        ).result(timeout=15)
                else:
                    server_schemas = loop.run_until_complete(gateway.get_server_tool_schemas(name))

                for schema in server_schemas:
                    tool_name = schema["function"]["name"]
                    schemas.append(schema)
                    # Extract original tool name (after the __ namespace separator)
                    _, original_name = tool_name.split("__", 1)
                    executors[tool_name] = GatewayToolExecutor(gateway, name, original_name)
                    log.debug("Registered gateway tool: %s", tool_name)

            except Exception as e:
                log.warning("Could not discover tools from MCP server '%s': %s", name, e)

        return schemas, executors

    async def _execute_tool(
        self,
        name: str,
        tool_input: dict[str, Any],
        executors: dict[str, Any],
    ) -> str:
        """
        Execute a tool and return result string.

        Args:
            name: Tool name
            tool_input: Tool arguments
            executors: Mapping of tool name to executor

        Returns:
            Result string for inclusion in messages
        """
        executor = executors.get(name)
        if executor is None:
            return f"Error: Unknown tool '{name}'"

        try:
            # Check if it's a BaseTool instance or a raw function
            if hasattr(executor, "execute"):
                # BaseTool - use execute method
                result = await executor.execute(**tool_input)
                return result.to_message_content()
            else:
                # MCP tool - call directly
                result = await executor(**tool_input)
                # MCP tools return {"success": bool, "data": ..., "error": ...}
                if isinstance(result, dict):
                    if result.get("success"):
                        data = result.get("data")
                        if isinstance(data, dict):
                            return json.dumps(data, indent=2)
                        return str(data) if data else "Success"
                    return f"Error: {result.get('error', 'Unknown error')}"
                return str(result)
        except Exception as e:
            log.exception("Tool execution error: %s", name)
            return f"Error executing {name}: {e}"

    async def _run_agent_loop(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        model: str,
        timeout: int,
    ) -> AsyncIterator[StreamEvent]:
        """
        Run the agentic loop with tool calling.

        Yields StreamEvent objects throughout execution.
        """
        from otto.streaming import StreamEvent

        try:
            import litellm
        except ImportError:
            yield StreamEvent.error("litellm not installed. Install with: pip install litellm")
            yield StreamEvent.done()
            return

        # Build tools
        schemas, executors = self._build_tools(cwd)

        # Initialize messages
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt},
        ]

        # Setup LiteLLM options
        litellm_kwargs: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "tools": schemas if schemas else None,
            "stream": True,
            "stream_options": {"include_usage": True},
        }

        if self.generic_config.api_base:
            litellm_kwargs["api_base"] = self.generic_config.api_base

        api_key = self._get_api_key(model)
        if api_key:
            litellm_kwargs["api_key"] = api_key
        else:
            log.debug("No API key found for model %s - LiteLLM will use defaults", model)

        # Start thinking
        yield StreamEvent.thinking()

        turn = 0
        max_turns = self.generic_config.max_turns
        accumulated_text = ""
        total_input_tokens = 0
        total_output_tokens = 0
        total_cost_usd = 0.0

        try:
            while turn < max_turns:
                turn += 1
                log.debug("Agent loop turn %d/%d", turn, max_turns)

                try:
                    # Make streaming request
                    response = await asyncio.wait_for(
                        litellm.acompletion(**litellm_kwargs),
                        timeout=timeout,
                    )

                    # Process streaming response
                    tool_calls: list[dict] = []
                    current_tool_call: dict | None = None
                    text_content = ""

                    async for chunk in response:
                        delta = chunk.choices[0].delta if chunk.choices else None
                        if not delta:
                            continue

                        # Handle text content
                        if delta.content:
                            text_content += delta.content
                            yield StreamEvent.text_delta(delta.content)

                        # Handle reasoning/thinking content (DeepSeek, etc.)
                        reasoning = getattr(delta, "reasoning_content", None)
                        if reasoning:
                            yield StreamEvent.thinking(reasoning)

                        # Extract token usage from final chunk
                        usage = getattr(chunk, "usage", None)
                        if usage is not None:
                            total_input_tokens += getattr(usage, "prompt_tokens", 0) or 0
                            total_output_tokens += getattr(usage, "completion_tokens", 0) or 0

                        # Handle tool calls
                        if delta.tool_calls:
                            for tc in delta.tool_calls:
                                if tc.index is not None:
                                    # New tool call or continuation
                                    while len(tool_calls) <= tc.index:
                                        tool_calls.append(
                                            {
                                                "id": "",
                                                "function": {"name": "", "arguments": ""},
                                            }
                                        )

                                    current = tool_calls[tc.index]

                                    if tc.id:
                                        current["id"] = tc.id
                                    if tc.function:
                                        if tc.function.name:
                                            current["function"]["name"] = tc.function.name
                                        if tc.function.arguments:
                                            current["function"]["arguments"] += (
                                                tc.function.arguments
                                            )

                    # Accumulate text
                    if text_content:
                        accumulated_text += text_content

                    # Best-effort cost calculation for this turn
                    try:
                        turn_cost = litellm.completion_cost(
                            model=model,
                            prompt_tokens=getattr(usage, "prompt_tokens", 0) or 0 if usage else 0,
                            completion_tokens=getattr(usage, "completion_tokens", 0) or 0
                            if usage
                            else 0,
                        )
                        total_cost_usd += turn_cost
                    except Exception:
                        pass  # Not all models have pricing data

                    # If no tool calls, we're done
                    if not tool_calls:
                        log.debug("No tool calls, finishing")
                        break

                    # Emit all tool_use events first
                    parsed_calls = []
                    for tc in tool_calls:
                        tool_name = tc["function"]["name"]
                        try:
                            tool_input = json.loads(tc["function"]["arguments"])
                        except json.JSONDecodeError:
                            tool_input = {}
                        parsed_calls.append((tc, tool_name, tool_input))
                        yield StreamEvent.tool_use(tool_name, tool_input)
                        log.debug("Executing tool: %s with input: %s", tool_name, tool_input)

                    # Execute all tools in parallel
                    coros = [
                        self._execute_tool(name, inp, executors) for _, name, inp in parsed_calls
                    ]
                    results = await asyncio.gather(*coros)

                    # Emit all tool_result events
                    tool_results = []
                    for (tc, tool_name, _), result in zip(parsed_calls, results):
                        yield StreamEvent.tool_result(tool_name, result[:500])
                        tool_results.append(
                            {
                                "tool_call_id": tc["id"],
                                "role": "tool",
                                "content": result,
                            }
                        )

                    # Add assistant message with tool calls
                    assistant_msg: dict[str, Any] = {"role": "assistant"}
                    if text_content:
                        assistant_msg["content"] = text_content
                    if tool_calls:
                        assistant_msg["tool_calls"] = [
                            {
                                "id": tc["id"],
                                "type": "function",
                                "function": tc["function"],
                            }
                            for tc in tool_calls
                        ]
                    messages.append(assistant_msg)

                    # Add tool results
                    messages.extend(tool_results)

                    # Hot-reload: if a registry tool was called, rebuild tool list
                    # so newly installed/removed servers are immediately available
                    _gateway_tools = {
                        "registry_install",
                        "registry_remove",
                        "registry_disable",
                        "registry_enable",
                    }
                    if any(n in _gateway_tools for _, n, _ in parsed_calls):
                        log.info("Gateway-modifying tool called — rebuilding tool list")
                        schemas, executors = self._build_tools(cwd)
                        litellm_kwargs["tools"] = schemas if schemas else None

                    # Update litellm kwargs for next iteration
                    litellm_kwargs["messages"] = messages

                except asyncio.TimeoutError:
                    yield StreamEvent.error(f"Request timed out after {timeout}s")
                    break
                except Exception as e:
                    log.exception("Agent loop error on turn %d", turn)
                    yield StreamEvent.error(self._sanitize_error(e))
                    break

            if turn >= max_turns:
                log.warning("Reached max turns (%d)", max_turns)
                yield StreamEvent.text_delta(f"\n\n[Reached maximum {max_turns} turns]")

            # Send completion events with usage metadata
            complete_event = StreamEvent.text_complete(accumulated_text)
            complete_event.metadata = {
                "input_tokens": total_input_tokens,
                "output_tokens": total_output_tokens,
                "cost_usd": total_cost_usd,
                "num_turns": turn,
            }
            yield complete_event
            yield StreamEvent.done()
        finally:
            if hasattr(self, "_exa_client") and self._exa_client:
                await self._exa_client.close()
                self._exa_client = None

    async def run_async_streaming(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
    ) -> AsyncIterator[StreamEvent]:
        """
        Run the agent with streaming output.

        Args:
            prompt: User prompt
            system_prompt: System prompt
            cwd: Working directory
            timeout: Request timeout in seconds
            model: Model specification (e.g., "openrouter/meta-llama/llama-3.3-70b-instruct")

        Yields:
            StreamEvent objects
        """
        from otto.streaming import StreamEvent

        if not self.config.enabled:
            yield StreamEvent.error(f"Backend {self.name} is not enabled")
            yield StreamEvent.done()
            return

        # Use provided model or fall back to config
        effective_model = (
            model or self.config.model or "openrouter/meta-llama/llama-3.3-70b-instruct"
        )
        effective_timeout = timeout or self.generic_config.timeout

        async for event in self._run_agent_loop(
            prompt=prompt,
            system_prompt=system_prompt,
            cwd=cwd,
            model=effective_model,
            timeout=effective_timeout,
        ):
            yield event

    async def run_async(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
    ) -> AgentResult:
        """
        Run the agent and return complete result.

        Args:
            prompt: User prompt
            system_prompt: System prompt
            cwd: Working directory
            timeout: Request timeout in seconds
            model: Model specification

        Returns:
            AgentResult with output and metadata
        """
        if not self.config.enabled:
            return AgentResult(
                success=False,
                output="",
                error=f"Backend {self.name} is not enabled",
                backend=self.name,
            )

        start_time = time.time()
        output_parts: list[str] = []
        error_message: str | None = None
        usage_metadata: dict[str, Any] = {}

        try:
            async for event in self.run_async_streaming(
                prompt=prompt,
                system_prompt=system_prompt,
                cwd=cwd,
                timeout=timeout,
                model=model,
            ):
                from otto.streaming import StreamEventType

                if event.type == StreamEventType.TEXT_DELTA:
                    output_parts.append(event.content)
                elif event.type == StreamEventType.TEXT_COMPLETE:
                    usage_metadata = event.metadata or {}
                elif event.type == StreamEventType.ERROR:
                    error_message = event.error
        except asyncio.CancelledError:
            return AgentResult(
                success=False,
                output="".join(output_parts),
                error="Cancelled by user",
                backend=self.name,
                duration_seconds=time.time() - start_time,
            )
        except Exception as e:
            log.exception("run_async error (preserving partial output)")
            error_message = self._sanitize_error(e)

        duration = time.time() - start_time
        output = "".join(output_parts)

        return AgentResult(
            success=error_message is None,
            output=output,
            error=error_message,
            backend=self.name,
            duration_seconds=duration,
            cost_usd=usage_metadata.get("cost_usd") or None,
            input_tokens=usage_metadata.get("input_tokens") or None,
            output_tokens=usage_metadata.get("output_tokens") or None,
            num_turns=usage_metadata.get("num_turns") or None,
        )

    def run_sync(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
    ) -> AgentResult:
        """Run synchronously by wrapping async."""
        return asyncio.run(self.run_async(prompt, system_prompt, cwd, timeout, model))

    def is_available(self) -> bool:
        """Check if backend is available."""
        if not self.config.enabled:
            return False
        # Check if litellm is installed
        try:
            import litellm  # noqa: F401

            return True
        except ImportError:
            return False

    def get_capabilities(self) -> dict:
        """Return backend capabilities."""
        return {
            "name": self.name,
            "supports_system_prompt": True,
            "supports_json_output": True,
            "supports_sandbox": False,
            "supports_mcp": True,
            "supports_hooks": False,
            "supports_cost_tracking": True,
            "supports_streaming": True,
            "models": [
                # OpenRouter
                "openrouter/meta-llama/llama-3.3-70b-instruct",
                "openrouter/anthropic/claude-sonnet-4",
                "openrouter/google/gemini-2.0-flash",
                # Ollama
                "ollama/qwen2.5-coder",
                "ollama/llama3.2",
                # Gemini
                "gemini/gemini-2.0-flash",
                # OpenAI
                "gpt-4o",
                "gpt-4o-mini",
            ],
        }


__all__ = ["GenericBackend"]
