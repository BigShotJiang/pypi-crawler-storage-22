"""
Pi coding agent backend implementation.

Uses Pi's NDJSON-over-stdio RPC protocol (pi --mode rpc) for:
- True incremental text streaming via message_update events
- Session persistence with new_session/switch_session
- Graceful cancellation via abort command
- Connection reuse instead of spawning process each time

Protocol overview:
    Client → Server: {"type": "prompt", "id": "1", "content": "..."}
    Server → Client (response): {"type": "response", "id": "1", "success": true, "data": {...}}
    Server → Client (event): {"type": "message_update", "assistantMessageEvent": {...}}
"""

import asyncio
import glob
import json
import logging
import os
import re
import shutil
import subprocess
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from pathlib import Path

from .base import AgentBackend, AgentConfig, AgentResult

log = logging.getLogger(__name__)

# Behavior instructions prepended to prompts
OTTO_INSTRUCTIONS = """
CRITICAL BEHAVIOR RULES:
1. Be DIRECT. Never narrate what you're about to do - just do it.
2. Never say "I'll analyze...", "Let me check...", "I'm going to..." - just give results.
3. Never mention internal tools, delegating to investigators, or your process.
4. If you use tools, report RESULTS only, not the fact that you used them.
5. Keep responses concise. No preamble, no meta-commentary.
6. You ARE Otto - respond as Otto would, not as a verbose assistant.

BAD: "Right, let me analyze the codebase. I'll use my investigator tool to examine..."
GOOD: "Here's the system architecture: [direct answer]"
""".strip()

# extension_ui_request methods that expect a response (dialogs)
_DIALOG_METHODS = frozenset({"select", "confirm", "input", "editor"})

# extension_ui_request methods that are fire-and-forget (notifications)
_NOTIFY_METHODS = frozenset({"notify", "setStatus", "setWidget", "setTitle", "set_editor_text"})


class PiRpcConnection:
    """Bidirectional NDJSON RPC over stdio for Pi."""

    def __init__(self, proc: asyncio.subprocess.Process):
        self._proc = proc
        self._command_id = 0
        self._pending: dict[str, asyncio.Future] = {}
        self._notification_queue: asyncio.Queue = asyncio.Queue()
        self._reader_task: asyncio.Task | None = None
        self._stderr_task: asyncio.Task | None = None
        self._closed = False

    async def start(self) -> None:
        """Start background reader and stderr drain tasks."""
        self._reader_task = asyncio.create_task(self._read_loop())
        if self._proc.stderr is not None:
            self._stderr_task = asyncio.create_task(self._drain_stderr())

    async def _read_loop(self) -> None:
        """Route responses to pending futures, events to notification queue."""
        assert self._proc.stdout is not None

        while not self._closed:
            try:
                line = await self._proc.stdout.readline()
                if not line:
                    log.debug("EOF from pi server stdout")
                    break

                line_str = line.decode(errors="replace").strip()
                if not line_str:
                    continue

                if not line_str.startswith("{"):
                    log.debug("Non-JSON from pi: %s", line_str[:200])
                    continue

                try:
                    msg = json.loads(line_str)
                except json.JSONDecodeError:
                    log.warning("Invalid JSON from pi server: %s", line_str[:100])
                    continue

                if not isinstance(msg, dict):
                    continue

                msg_type = msg.get("type", "")

                # Auto-decline extension UI dialog requests
                if msg_type == "extension_ui_request":
                    method = msg.get("method", "")
                    req_id = msg.get("id")
                    if method in _DIALOG_METHODS and req_id is not None:
                        log.debug("Auto-declining extension_ui_request: %s (id=%s)", method, req_id)
                        await self._send_raw(
                            {
                                "type": "extension_ui_response",
                                "id": req_id,
                                "cancelled": True,
                            }
                        )
                    elif method in _NOTIFY_METHODS:
                        log.debug("Ignoring fire-and-forget extension_ui_request: %s", method)
                    else:
                        log.debug("Ignoring unknown extension_ui_request method: %s", method)
                    continue

                # Response to a command we sent
                if msg_type == "response":
                    if "id" in msg:
                        # Correlated response — resolve the pending future
                        cmd_id = str(msg["id"])
                        log.debug("Received response for command %s", cmd_id)
                        future = self._pending.pop(cmd_id, None)
                        if future and not future.done():
                            if not msg.get("success", True):
                                error_msg = msg.get("error", msg.get("message", "Command failed"))
                                log.warning("Command %s failed: %s", cmd_id, error_msg)
                                future.set_exception(RuntimeError(str(error_msg)))
                            else:
                                future.set_result(msg.get("data", {}))
                    elif not msg.get("success", True):
                        # Id-less error response (e.g. prompt failures like
                        # missing API keys).  Push to event queue so the
                        # streaming loop can surface it.
                        error_msg = msg.get("error", msg.get("message", "Command failed"))
                        cmd = msg.get("command", "unknown")
                        log.warning("Pi %s failed: %s", cmd, error_msg)
                        await self._notification_queue.put(msg)
                    else:
                        log.debug("Pi response (no id): command=%s", msg.get("command"))
                    continue

                # Everything else is an event/notification
                log.debug("Queuing event: %s", msg_type)
                await self._notification_queue.put(msg)

            except asyncio.CancelledError:
                break
            except Exception as e:
                log.debug("Error reading from pi server: %s", e)
                break

        # Signal end to any waiting readers
        await self._notification_queue.put(None)

    async def _drain_stderr(self) -> None:
        """Continuously read stderr to prevent pipe buffer from filling.

        If the Pi process writes warnings, debug info, or errors to stderr
        and nobody reads it, the OS pipe buffer (~64KB) fills up and the
        process blocks on the next write — deadlocking stdout too.
        """
        assert self._proc.stderr is not None
        while not self._closed:
            try:
                line = await self._proc.stderr.readline()
                if not line:
                    break
                msg = line.decode(errors="replace").rstrip()
                if msg:
                    log.debug("pi stderr: %s", msg[:500])
            except asyncio.CancelledError:
                break
            except Exception:
                break

    async def _send_raw(self, msg: dict) -> None:
        """Send a raw JSON message to the process stdin."""
        if self._closed or self._proc.returncode is not None:
            return
        assert self._proc.stdin is not None
        self._proc.stdin.write(json.dumps(msg).encode() + b"\n")
        await self._proc.stdin.drain()

    async def send_command(self, cmd_type: str, **params) -> dict:
        """Send a command and await response."""
        if self._closed or self._proc.returncode is not None:
            raise RuntimeError("Connection closed")

        self._command_id += 1
        cmd_id = str(self._command_id)

        command = {"type": cmd_type, "id": cmd_id, **params}

        loop = asyncio.get_event_loop()
        future: asyncio.Future = loop.create_future()
        self._pending[cmd_id] = future

        try:
            log.debug("Sending command %s: %s", cmd_id, cmd_type)
            await self._send_raw(command)
        except Exception as e:
            self._pending.pop(cmd_id, None)
            raise RuntimeError(f"Failed to send command: {e}") from e

        log.debug("Waiting for response to command %s...", cmd_id)
        return await future

    async def send_fire_and_forget(self, cmd_type: str, **params) -> None:
        """Send a command without waiting for a response."""
        if self._closed or self._proc.returncode is not None:
            raise RuntimeError("Connection closed")

        command = {"type": cmd_type, **params}
        log.debug("Sending fire-and-forget: %s", cmd_type)
        await self._send_raw(command)

    async def read_event(self, timeout: float | None = None) -> dict:
        """Read next event from the notification queue."""
        try:
            msg = await asyncio.wait_for(self._notification_queue.get(), timeout=timeout)
            if msg is None:
                raise RuntimeError("Connection closed")
            return msg
        except asyncio.TimeoutError:
            raise

    async def close(self) -> None:
        """Clean shutdown."""
        self._closed = True

        for task in (self._reader_task, self._stderr_task):
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

        # Cancel pending requests
        for future in self._pending.values():
            if not future.done():
                future.cancel()
        self._pending.clear()

        if self._proc.returncode is None:
            self._proc.terminate()
            try:
                await asyncio.wait_for(self._proc.wait(), timeout=5)
            except asyncio.TimeoutError:
                self._proc.kill()
                await self._proc.wait()


@dataclass
class PiSession:
    """Active session with the Pi RPC server."""

    process: asyncio.subprocess.Process
    connection: PiRpcConnection
    session_id: str | None = None


class PiBackend(AgentBackend):
    """
    Backend using Pi's NDJSON RPC protocol.

    Key benefits:
    - True incremental text streaming (message_update events)
    - Session persistence with new_session/switch_session
    - Graceful cancellation via abort
    - Connection reuse
    """

    def __init__(self, config: AgentConfig):
        super().__init__(config)
        self._sessions: dict[Path, PiSession] = {}
        self.__lock: asyncio.Lock | None = None  # Created lazily per-loop
        self._streaming = False  # True while agent is actively streaming

        # Resolve the actual binary path: configured path → shutil.which fallback
        self._resolved_path = self._resolve_path()

        # Derive bin path from the resolved binary location
        self._bin_path = self._resolved_path.parent if self._resolved_path else None

        # Backend options
        opts = getattr(config, "options", None) or getattr(config, "sdk_options", None) or {}
        self.reuse_session = opts.get("reuse_session", True)
        self.connection_timeout = opts.get("connection_timeout", 60)
        self.thinking_level = opts.get("thinking_level", "medium")
        self.auto_compaction = opts.get("auto_compaction", True)

    @property
    def _lock(self) -> asyncio.Lock:
        """Get the lock, creating it lazily to bind to current event loop."""
        if self.__lock is None:
            self.__lock = asyncio.Lock()
        return self.__lock

    def _parse_model(self) -> tuple[str | None, str | None]:
        """Parse provider/model from the config model field.

        Split on the first ``/`` so that compound model names survive:
        - ``anthropic/claude-haiku-4-5``  → (``anthropic``, ``claude-haiku-4-5``)
        - ``ollama/llama3:14b``           → (``ollama``, ``llama3:14b``)
        - ``openrouter/google/gemini-2.0-flash`` → (``openrouter``, ``google/gemini-2.0-flash``)
        - ``claude-haiku-4-5`` (no slash)  → (None, ``claude-haiku-4-5``)
        - None / empty                    → (None, None)
        """
        raw = self.config.model
        if not raw:
            return None, None
        if "/" in raw:
            provider, _, model_name = raw.partition("/")
            return provider, model_name
        return None, raw

    def _resolve_path(self) -> Path | None:
        """Resolve the pi binary path with multiple fallback strategies.

        Search order:
        1. Configured path (from settings.yaml)
        2. shutil.which (current $PATH)
        3. Well-known node global bin dirs (proto, nvm, fnm, volta, system npm)
        """
        # 1. Configured path
        if self.config.path and self.config.path.exists():
            return self.config.path

        # 2. $PATH lookup
        found = shutil.which("pi")
        if found:
            resolved = Path(found)
            log.debug("pi found via PATH at %s", resolved)
            return resolved

        # 3. Probe well-known node manager bin directories.
        #    Service processes often lack the full interactive-shell PATH,
        #    so shutil.which misses npm-global binaries.
        home = Path.home()
        candidates = [
            # proto (any node version)
            *sorted(glob.glob(str(home / ".proto/tools/node/*/bin/pi")), reverse=True),
            # nvm
            *sorted(glob.glob(str(home / ".nvm/versions/node/*/bin/pi")), reverse=True),
            # fnm
            *sorted(
                glob.glob(str(home / ".local/share/fnm/node-versions/*/installation/bin/pi")),
                reverse=True,
            ),
            # volta
            str(home / ".volta/bin/pi"),
            # system npm global
            "/usr/local/bin/pi",
        ]
        for candidate in candidates:
            p = Path(candidate)
            if p.is_file() and os.access(p, os.X_OK):
                log.debug("pi found at well-known location: %s", p)
                return p

        log.warning(
            "pi binary not found at %s, on PATH, or in well-known node locations", self.config.path
        )
        return None

    @classmethod
    def discover_models(cls, binary_path: Path) -> list[dict]:
        """Run ``pi --list-models`` and parse the tabular output.

        Returns a list of dicts with keys:
            provider, model, context, thinking (bool)
        Falls back to an empty list on any error.
        """
        try:
            env = {**os.environ, "NO_COLOR": "1", "FORCE_COLOR": "0"}
            # Ensure the binary's directory is on PATH
            bin_dir = str(binary_path.parent)
            if bin_dir not in env.get("PATH", ""):
                env["PATH"] = f"{bin_dir}:{env.get('PATH', '')}"

            result = subprocess.run(
                [str(binary_path), "--list-models"],
                capture_output=True,
                text=True,
                timeout=10,
                env=env,
            )
            if result.returncode != 0:
                log.warning(
                    "pi --list-models failed (rc=%d): %s", result.returncode, result.stderr[:200]
                )
                return []

            return cls._parse_model_table(result.stdout)
        except Exception as e:
            log.warning("Failed to discover pi models: %s", e)
            return []

    @staticmethod
    def _parse_model_table(raw: str) -> list[dict]:
        """Parse the space-delimited table from ``pi --list-models``."""
        lines = raw.strip().splitlines()
        if not lines:
            return []

        # First line is the header — use it to discover column positions
        header = lines[0]
        # Split on 2+ spaces to get column names
        col_names = re.split(r"\s{2,}", header.strip().lower())

        models: list[dict] = []
        for line in lines[1:]:
            line = line.strip()
            if not line:
                continue
            parts = re.split(r"\s{2,}", line)
            if len(parts) < 2:
                continue

            row: dict = {}
            for i, name in enumerate(col_names):
                row[name] = parts[i] if i < len(parts) else ""

            models.append(
                {
                    "provider": row.get("provider", ""),
                    "model": row.get("model", ""),
                    "context": row.get("context", ""),
                    "thinking": row.get("thinking", "").lower() in ("yes", "true", "1"),
                }
            )

        return models

    def get_available_models(self) -> list[dict]:
        """Get models available from this Pi installation."""
        if self._resolved_path:
            return self.discover_models(self._resolved_path)
        return []

    def get_capabilities(self) -> dict:
        """Return backend capabilities."""
        return {
            "name": self.name,
            "supports_system_prompt": False,  # Prepended to prompt
            "supports_json_output": False,
            "supports_sandbox": False,
            "supports_mcp": True,
            "supports_streaming": True,
            "supports_session_reuse": True,
            "supports_tool_use": True,
            "supports_steer": True,
        }

    def is_available(self) -> bool:
        """Check if backend is available and enabled."""
        return self.config.enabled and self._resolved_path is not None

    def _get_env(self) -> dict:
        """Get environment variables for subprocess."""
        env = {**os.environ}

        # Ensure pi binary dir is on PATH
        if self._bin_path:
            bin_dir = str(self._bin_path)
            current_path = env.get("PATH", "")
            if bin_dir not in current_path:
                env["PATH"] = f"{bin_dir}:{current_path}"

        # Disable color codes for clean output
        env["NO_COLOR"] = "1"
        env["FORCE_COLOR"] = "0"

        return env

    def _prepare_prompt(self, system_prompt: str, user_prompt: str) -> str:
        """Prepare combined prompt for input."""
        parts = []
        if system_prompt:
            parts.append(system_prompt)
        parts.append(OTTO_INSTRUCTIONS)
        if user_prompt:
            parts.append(f"USER QUERY: {user_prompt}")
        return "\n\n".join(parts)

    async def _ensure_connection(self, cwd: Path) -> PiSession:
        """Get or create session with automatic reconnection."""
        async with self._lock:
            session = self._sessions.get(cwd)

            # Check if process died
            if session and session.process.returncode is not None:
                log.info("Pi server process died, reconnecting...")
                await session.connection.close()
                del self._sessions[cwd]
                session = None

            if not session:
                session = await asyncio.wait_for(
                    self._start_server(cwd), timeout=self.connection_timeout
                )
                self._sessions[cwd] = session

            return session

    async def _start_server(self, cwd: Path) -> PiSession:
        """Spawn pi --mode rpc server."""
        if not self._resolved_path:
            raise RuntimeError("pi binary not found")

        log.info("Starting pi RPC server for %s (binary: %s)", cwd, self._resolved_path)

        cmd = [str(self._resolved_path), "--mode", "rpc"]

        # Parse provider/model from config (e.g. "anthropic/claude-haiku-4-5")
        provider, model_name = self._parse_model()

        # Add provider if present
        if provider:
            cmd.extend(["--provider", provider])

        # Add model if configured
        if model_name:
            cmd.extend(["--model", model_name])

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=str(cwd),
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=self._get_env(),
        )

        conn = PiRpcConnection(proc)
        await conn.start()

        # Brief pause to let the process fail fast if the binary is broken,
        # missing deps, etc.  If it exits immediately we catch it here
        # instead of caching a dead session.
        await asyncio.sleep(0.1)
        if proc.returncode is not None:
            stderr_out = ""
            if proc.stderr:
                try:
                    raw = await asyncio.wait_for(proc.stderr.read(4096), timeout=1)
                    stderr_out = raw.decode(errors="replace").strip()
                except Exception:
                    pass
            await conn.close()
            raise RuntimeError(
                f"pi exited immediately (rc={proc.returncode})"
                + (f": {stderr_out}" if stderr_out else "")
            )

        # Pi requires a new_session before accepting prompts — without it,
        # internal session state is undefined and prompts fail with
        # "Cannot read properties of undefined (reading 'startsWith')".
        try:
            result = await conn.send_command("new_session")
            cancelled = result.get("cancelled", False) if isinstance(result, dict) else False
            if cancelled:
                log.warning("Pi new_session was cancelled by extension")
            else:
                log.info("Pi RPC server started with new session (pid=%s)", proc.pid)
        except Exception as e:
            log.warning("Pi new_session failed (non-fatal): %s", e)
            log.info("Pi RPC server started (pid=%s)", proc.pid)

        return PiSession(
            process=proc,
            connection=conn,
        )

    async def run_async_streaming(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
    ) -> AsyncIterator:
        """
        Run Pi with true incremental streaming via RPC.

        Yields StreamEvent objects as the response is generated.
        """
        from otto.streaming import StreamEvent

        if not self.is_available():
            yield StreamEvent.error(f"Backend {self.name} is not available")
            yield StreamEvent.done()
            return

        # Establish connection
        try:
            session = await self._ensure_connection(cwd)
        except asyncio.TimeoutError:
            yield StreamEvent.error(f"Connection timeout after {self.connection_timeout}s")
            yield StreamEvent.done()
            return
        except Exception as e:
            yield StreamEvent.error(f"Connection failed: {e}")
            yield StreamEvent.done()
            return

        # Build prompt with system context
        full_prompt = self._prepare_prompt(system_prompt, prompt)

        # Send prompt as fire-and-forget.  Pi does NOT send a correlated
        # response for prompt commands — it starts streaming events
        # immediately.  Using send_command here would block forever waiting
        # for a response that never arrives.
        # NOTE: Pi expects the prompt text in a "message" field, NOT "content".
        try:
            await session.connection.send_fire_and_forget(
                "prompt",
                message=full_prompt,
            )
        except Exception as e:
            log.exception("Failed to send prompt")
            yield StreamEvent.error(f"Failed to send prompt: {e}")
            yield StreamEvent.done()
            return

        self._streaming = True
        yield StreamEvent.thinking()

        # State tracking
        accumulated_text = ""

        try:
            deadline = time.time() + timeout

            while True:
                remaining = deadline - time.time()
                if remaining <= 0:
                    raise asyncio.TimeoutError()

                try:
                    log.debug("Waiting for event (remaining: %.1fs)...", remaining)
                    event = await session.connection.read_event(timeout=remaining)
                except asyncio.TimeoutError:
                    raise

                etype = event.get("type", "")
                log.debug("Received: %s", etype)

                # --- Agent lifecycle ---
                if etype == "agent_start":
                    yield StreamEvent.thinking()
                    continue

                if etype == "agent_end":
                    self._streaming = False
                    # Agent finished - emit text_complete if we accumulated text
                    if accumulated_text.strip():
                        yield StreamEvent.text_complete(accumulated_text.strip())
                    break

                # --- Message updates ---
                if etype == "message_update":
                    ame = event.get("assistantMessageEvent", {})
                    ame_type = ame.get("type", "")

                    if ame_type == "text_delta":
                        delta = ame.get("delta", "")
                        if delta:
                            accumulated_text += delta
                            yield StreamEvent.text_delta(delta)
                        continue

                    if ame_type == "thinking_delta":
                        delta = ame.get("delta", "")
                        if delta:
                            yield StreamEvent.thinking(delta)
                        continue

                    if ame_type == "done":
                        reason = ame.get("reason", "")
                        log.debug("Message done (reason=%s)", reason)
                        if accumulated_text.strip():
                            yield StreamEvent.text_complete(accumulated_text.strip())
                            accumulated_text = ""
                        continue

                    if ame_type == "error":
                        reason = ame.get("reason", "")
                        error_msg = ame.get("message", ame.get("error", "Unknown error"))
                        log.debug("Message error (reason=%s): %s", reason, error_msg)
                        yield StreamEvent.error(str(error_msg))
                        continue

                    if ame_type == "toolcall_end":
                        log.debug("Tool call ended: %s", ame.get("toolName", "unknown"))
                        continue

                    if ame_type in (
                        "start",
                        "text_start",
                        "text_end",
                        "thinking_start",
                        "thinking_end",
                        "toolcall_start",
                        "toolcall_delta",
                    ):
                        log.debug("assistantMessageEvent: %s", ame_type)
                        continue

                    log.debug("Unhandled assistantMessageEvent type: %s", ame_type)
                    continue

                # --- Tool execution ---
                if etype == "tool_execution_start":
                    tool_name = event.get("toolName", event.get("tool", "unknown"))
                    tool_args = event.get("args", event.get("input", {}))
                    yield StreamEvent.tool_use(
                        str(tool_name), tool_args if isinstance(tool_args, dict) else None
                    )
                    continue

                if etype == "tool_execution_update":
                    log.debug("Tool execution update: %s", event.get("toolCallId", ""))
                    continue

                if etype == "tool_execution_end":
                    tool_name = event.get("toolName", event.get("tool", "unknown"))
                    is_error = event.get("isError", False)
                    if is_error:
                        log.warning("Tool %s completed with error", tool_name)
                    raw_result = event.get("result", event.get("output", ""))
                    # Pi returns structured result: {"content": [{"type":"text","text":"..."}]}
                    result_text = ""
                    if isinstance(raw_result, dict):
                        for block in raw_result.get("content", []):
                            if isinstance(block, dict) and block.get("type") == "text":
                                result_text += block.get("text", "")
                    if not result_text:
                        result_text = str(raw_result)
                    yield StreamEvent.tool_result(str(tool_name), result_text[:500])
                    continue

                # --- Turn / message lifecycle ---
                if etype in ("turn_start", "turn_end", "message_start", "message_end"):
                    log.debug("Pi lifecycle: %s", etype)
                    continue

                # --- Compaction / retry ---
                if etype == "auto_compaction_start":
                    log.info("Pi auto-compaction started")
                    continue

                if etype == "auto_compaction_end":
                    log.info("Pi auto-compaction ended")
                    continue

                if etype == "auto_retry_start":
                    attempt = event.get("attempt", "?")
                    max_attempts = event.get("maxAttempts", "?")
                    delay_ms = event.get("delayMs", "?")
                    error_msg = event.get("errorMessage", "")
                    log.info(
                        "Pi auto-retry %s/%s (delay=%sms): %s",
                        attempt,
                        max_attempts,
                        delay_ms,
                        error_msg,
                    )
                    continue

                if etype == "auto_retry_end":
                    success = event.get("success", None)
                    log.info("Pi auto-retry ended (success=%s)", success)
                    continue

                # --- Extension errors ---
                if etype == "extension_error":
                    ext_path = event.get("extensionPath", "unknown")
                    ext_error = event.get("error", "unknown")
                    log.warning("Pi extension error (%s): %s", ext_path, ext_error)
                    continue

                # --- Id-less error responses (e.g. missing API key) ---
                if etype == "response" and not event.get("success", True):
                    error_msg = event.get("error", event.get("message", "Unknown error"))
                    yield StreamEvent.error(str(error_msg))
                    break

                # --- Catch-all ---
                log.debug("Unhandled pi event type: %s", etype)

        except asyncio.TimeoutError:
            self._streaming = False
            # Send abort command and drain remaining events
            log.warning("Pi request timed out after %ds, sending abort", timeout)
            try:
                await session.connection.send_fire_and_forget("abort")
                # Drain events until agent_end or give up
                for _ in range(10):
                    try:
                        drain_event = await session.connection.read_event(timeout=5)
                        if drain_event.get("type") == "agent_end":
                            break
                    except (asyncio.TimeoutError, RuntimeError):
                        break
            except Exception as e:
                log.debug("Error during abort/drain: %s", e)

            yield StreamEvent.error(f"Request timed out after {timeout}s")

        except Exception as e:
            self._streaming = False
            log.exception("Pi server streaming error")
            yield StreamEvent.error(str(e))

        finally:
            self._streaming = False
            yield StreamEvent.done()

    async def run_async(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
    ) -> AgentResult:
        """Non-streaming execution - collect streaming results."""
        output_parts = []
        error = None
        start_time = time.time()

        async for event in self.run_async_streaming(prompt, system_prompt, cwd, timeout, model):
            from otto.streaming import StreamEventType

            if event.type == StreamEventType.TEXT_DELTA:
                output_parts.append(event.content)
            elif event.type == StreamEventType.TEXT_COMPLETE:
                output_parts = [event.content]  # Replace with final
            elif event.type == StreamEventType.ERROR:
                error = event.error

        return AgentResult(
            success=error is None,
            output="".join(output_parts),
            error=error,
            backend=self.name,
            duration_seconds=time.time() - start_time,
        )

    def run_sync(
        self,
        prompt: str,
        system_prompt: str,
        cwd: Path,
        timeout: int = 300,
        model: str | None = None,
    ) -> AgentResult:
        """Run synchronously by wrapping async.

        Note: asyncio.run() creates a new event loop each time, so we must
        close any cached state to avoid "bound to a different event loop"
        errors on asyncio primitives (Lock, Queue, Event).
        """
        # Clear cached sessions and lock since they're bound to a stale event loop
        self._sessions.clear()
        self.__lock = None
        self._streaming = False
        return asyncio.run(self.run_async(prompt, system_prompt, cwd, timeout, model))

    @property
    def is_streaming(self) -> bool:
        """Whether the backend is actively streaming a response."""
        return self._streaming

    async def steer(self, message: str, cwd: Path) -> None:
        """Send a steering message to interrupt the agent mid-run."""
        session = await self._ensure_connection(cwd)
        await session.connection.send_command("steer", message=message)

    async def follow_up(self, message: str, cwd: Path) -> None:
        """Queue a follow-up message for after the agent finishes."""
        session = await self._ensure_connection(cwd)
        await session.connection.send_command("follow_up", message=message)

    async def close_all_sessions(self) -> None:
        """Close all active sessions."""
        async with self._lock:
            for session in self._sessions.values():
                await session.connection.close()
            self._sessions.clear()

    async def close_session(self, cwd: Path) -> bool:
        """Close session for a specific working directory."""
        async with self._lock:
            session = self._sessions.pop(cwd, None)
            if session:
                await session.connection.close()
                return True
            return False
