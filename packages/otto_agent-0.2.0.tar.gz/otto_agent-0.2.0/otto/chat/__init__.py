"""
Chat platform abstraction for Otto.

Provides a unified interface for different chat platforms.

Platform implementations:
- TelegramPlatform: Rich UI with inline keyboards, buttons, HTML formatting

Adapters provide security:
- SecurityAdapter: Authorization, permissions, and security context
"""

from .telegram import (
    ChatCore,
    ChatContext,
    ChatMessage,
    ChatPlatform,
    Permission,
    PlatformCapabilities,
    SecurityAdapter,
    SecurityContext,
    SecurityLevel,
)
from .commands import CommandHandler, CommandResult, CommandRouter, get_command_router

__all__ = [
    # Base types
    "ChatPlatform",
    "PlatformCapabilities",
    "ChatContext",
    "ChatMessage",
    # Core logic
    "ChatCore",
    # Commands
    "CommandRouter",
    "CommandHandler",
    "CommandResult",
    "get_command_router",
    # Adapters
    "SecurityAdapter",
    "SecurityContext",
    "Permission",
    "SecurityLevel",
]
