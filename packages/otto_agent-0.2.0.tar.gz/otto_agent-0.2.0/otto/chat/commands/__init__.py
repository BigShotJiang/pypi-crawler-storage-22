"""
Command router for handling slash commands across platforms.

Commands are text-based responses that don't require LLM processing.
Works for rich platforms (Telegram).
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from ..types import ChatContext


@dataclass
class CommandResult:
    """Result of a command execution.

    Commands return structured data that platforms render appropriately:
    - Telegram: Inline keyboards, buttons, interactive menus
    """

    text: str
    success: bool = True

    # Structured data for rich rendering
    data: Any = None  # Arbitrary structured data
    options: list[dict[str, Any]] | None = None  # [{id, label, description?}]
    action: str | None = None  # "confirm", "select", "input"

    # For stateful flows (callbacks)
    next_handler: str | None = None  # Callback to invoke on response

    # Legacy button support (deprecated, use options instead)
    buttons: list[dict[str, str]] | None = None  # [{label, callback_data}]

    # Platform-specific passthrough (e.g., Telegram InlineKeyboardMarkup)
    reply_markup: Any | None = None

    @classmethod
    def ok(cls, text: str, **kwargs) -> CommandResult:
        return cls(text=text, success=True, **kwargs)

    @classmethod
    def error(cls, text: str) -> CommandResult:
        return cls(text=text, success=False)

    @classmethod
    def confirm(cls, text: str, handler: str, **kwargs) -> CommandResult:
        """Create a confirmation prompt."""
        return cls(text=text, success=True, action="confirm", next_handler=handler, **kwargs)

    @classmethod
    def select(
        cls, text: str, options: list[dict[str, Any]], handler: str, **kwargs
    ) -> CommandResult:
        """Create a selection prompt."""
        return cls(
            text=text,
            success=True,
            action="select",
            options=options,
            next_handler=handler,
            **kwargs,
        )


# Type alias for command handlers
CommandHandler = Callable[["ChatContext", list[str]], Awaitable[CommandResult]]


# Type alias for callback handlers
CallbackHandler = Callable[["ChatContext", str], Awaitable[CommandResult]]


class CommandRouter:
    """
    Routes slash commands to handlers.

    Usage:
        router = CommandRouter()

        @router.command("help")
        async def cmd_help(ctx, args):
            return CommandResult.ok("Help text here...")

        @router.callback("backend")
        async def cb_backend(ctx, value):
            # value is the selected option (e.g., "pi")
            return CommandResult.ok(f"Switched to {value}")

        # In message handler:
        result = await router.handle(ctx, "/help")

        # In callback handler:
        result = await router.handle_callback(ctx, "backend", "pi")
    """

    def __init__(self):
        self._handlers: dict[str, CommandHandler] = {}
        self._callbacks: dict[str, CallbackHandler] = {}
        self._aliases: dict[str, str] = {}

    def command(self, name: str, aliases: list[str] | None = None):
        """Decorator to register a command handler."""

        def decorator(func: CommandHandler) -> CommandHandler:
            self._handlers[name.lower()] = func
            if aliases:
                for alias in aliases:
                    self._aliases[alias.lower()] = name.lower()
            return func

        return decorator

    def callback(self, action: str):
        """Decorator to register a callback handler.

        Callbacks are invoked when a user responds to an interactive element
        (button press, selection, etc.)

        Args:
            action: The callback action name (e.g., "backend", "restart")

        Example:
            @router.callback("backend")
            async def cb_backend(ctx, value):
                # value is the selection (e.g., "pi")
                set_active_backend(value)
                return CommandResult.ok(f"Switched to {value}")
        """

        def decorator(func: CallbackHandler) -> CallbackHandler:
            self._callbacks[action.lower()] = func
            return func

        return decorator

    def register_callback(self, action: str, handler: CallbackHandler) -> None:
        """Register a callback handler programmatically."""
        self._callbacks[action.lower()] = handler

    def register(
        self, name: str, handler: CommandHandler, aliases: list[str] | None = None
    ) -> None:
        """Register a command handler programmatically."""
        self._handlers[name.lower()] = handler
        if aliases:
            for alias in aliases:
                self._aliases[alias.lower()] = name.lower()

    def is_command(self, text: str) -> bool:
        """Check if text is a command."""
        return text.strip().startswith("/")

    def parse_command(self, text: str) -> tuple[str, list[str]]:
        """Parse command name and arguments from text."""
        text = text.strip()
        if not text.startswith("/"):
            return "", []

        parts = text.split()
        cmd = parts[0][1:].lower()  # Remove leading /
        args = parts[1:] if len(parts) > 1 else []

        return cmd, args

    async def handle(self, ctx: ChatContext, text: str) -> CommandResult | None:
        """
        Handle a command if text is a valid command.

        Returns None if not a command or command not found.
        """
        if not self.is_command(text):
            return None

        cmd, args = self.parse_command(text)

        # Resolve aliases
        if cmd in self._aliases:
            cmd = self._aliases[cmd]

        # Find handler
        handler = self._handlers.get(cmd)
        if not handler:
            return CommandResult.error(
                f"Unknown command: /{cmd}\n\nUse /help for available commands."
            )

        try:
            return await handler(ctx, args)
        except Exception as e:
            return CommandResult.error(f"Command error: {e}")

    async def handle_callback(
        self, ctx: ChatContext, action: str, value: str | None = None
    ) -> CommandResult:
        """
        Handle a callback (button press, selection) for a command.

        Args:
            ctx: Chat context
            action: The callback action name (e.g., "backend")
            value: The selected value (e.g., "pi")

        Returns:
            CommandResult with the response
        """
        handler = self._callbacks.get(action.lower())
        if not handler:
            return CommandResult.error(f"Unknown callback: {action}")

        try:
            return await handler(ctx, value or "")
        except Exception as e:
            return CommandResult.error(f"Callback error: {e}")

    def list_commands(self) -> list[str]:
        """Get list of registered commands."""
        return list(self._handlers.keys())

    def list_callbacks(self) -> list[str]:
        """Get list of registered callback handlers."""
        return list(self._callbacks.keys())


# Global command router instance
_router: CommandRouter | None = None


def get_command_router() -> CommandRouter:
    """Get the global command router."""
    global _router
    if _router is None:
        _router = CommandRouter()

        # Register core commands from submodules
        from . import agents, mcp, memory, sessions, system

        agents.register(_router)
        mcp.register(_router)
        memory.register(_router)
        sessions.register(_router)
        system.register(_router)

    return _router
