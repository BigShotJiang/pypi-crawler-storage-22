"""Agent-related commands: /agents /stop /backend /thinking"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from . import CommandResult, CommandRouter

if TYPE_CHECKING:
    from ..types import ChatContext


def _agent_duration(created_at: str) -> str:
    """Format duration from created_at to now."""
    from datetime import datetime

    if not created_at:
        return ""
    try:
        start = datetime.fromisoformat(created_at)
        total_secs = int((datetime.now() - start).total_seconds())
        if total_secs < 0:
            return ""
        if total_secs < 60:
            return f"{total_secs}s"
        mins, secs = divmod(total_secs, 60)
        if mins < 60:
            return f"{mins}m {secs}s"
        hours, mins = divmod(mins, 60)
        return f"{hours}h {mins}m"
    except (ValueError, TypeError):
        return ""


def _build_agents_view(show_history: bool = False) -> CommandResult:
    """Build the agents view (active or history)."""
    from otto.jobs.queue import JobQueue

    queue = JobQueue()
    jobs = queue.list(job_type="agent", limit=50)

    agents: list[dict] = []
    for job in jobs:
        payload = job.get("payload") or {}
        agent_id = job.get("external_id") or payload.get("agent_id") or str(job.get("id", "?"))
        agents.append(
            {
                "id": agent_id,
                "job_id": job.get("id"),
                "task": payload.get("task") or payload.get("task_description") or "",
                "backend": payload.get("backend") or "",
                "status": job.get("status") or "unknown",
                "created_at": job.get("created_at") or "",
                "updated_at": job.get("updated_at") or "",
                "output_file": payload.get("output_file") or "",
            }
        )

    active = [a for a in agents if a.get("status") in ("pending", "running")]
    finished = [a for a in agents if a.get("status") in ("completed", "failed", "cancelled")]

    if show_history:
        return _render_agents_history(finished)
    return _render_agents_active(active, finished)


def _render_agents_active(active: list[dict], finished: list[dict]) -> CommandResult:
    """Render the active agents view with per-agent action buttons."""
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup

    if not active:
        text = "<b>Agents</b>\n\nNo agents running. I'll spawn agents automatically when needed."
        rows = []
        if finished:
            rows.append([InlineKeyboardButton("Show History", callback_data="ag_hist:1")])
        markup = InlineKeyboardMarkup(rows) if rows else None
        return CommandResult.ok(text, reply_markup=markup)

    # Summary line
    running = sum(1 for a in active if a["status"] == "running")
    pending = sum(1 for a in active if a["status"] == "pending")
    parts = []
    if running:
        parts.append(f"{running} running")
    if pending:
        parts.append(f"{pending} pending")

    lines = [f"<b>Agents</b> — {', '.join(parts)}\n"]
    keyboard_rows: list[list] = []

    for agent in active:
        status = agent["status"]
        aid = agent["id"]
        task = (agent.get("task") or "")[:40]
        duration = _agent_duration(agent.get("created_at", ""))
        short_id = aid[:20]

        if status == "running":
            dur_str = f" ({duration})" if duration else ""
            lines.append(f"⏳ <code>{aid[:12]}</code>{dur_str}\n   {task}")
            keyboard_rows.append(
                [
                    InlineKeyboardButton("Stop", callback_data=f"ag_stop:{short_id}"),
                    InlineKeyboardButton("Details", callback_data=f"ag_dtl:{short_id}"),
                ]
            )
        elif status == "pending":
            lines.append(f"⏸ <code>{aid[:12]}</code>\n   {task}")
            keyboard_rows.append(
                [
                    InlineKeyboardButton("Cancel", callback_data=f"ag_cancel:{short_id}"),
                    InlineKeyboardButton("Details", callback_data=f"ag_dtl:{short_id}"),
                ]
            )

    # Footer
    footer = []
    if finished:
        footer.append(InlineKeyboardButton("Show History", callback_data="ag_hist:1"))
    footer.append(InlineKeyboardButton("Refresh", callback_data="ag_ref:1"))
    keyboard_rows.append(footer)

    markup = InlineKeyboardMarkup(keyboard_rows)
    return CommandResult.ok("\n".join(lines), reply_markup=markup)


def _render_agents_history(finished: list[dict]) -> CommandResult:
    """Render history view of completed/failed agents."""
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup

    if not finished:
        text = "<b>Agent History</b>\n\nNo completed agents yet."
        markup = InlineKeyboardMarkup(
            [[InlineKeyboardButton("Back to Active", callback_data="ag_ref:1")]]
        )
        return CommandResult.ok(text, reply_markup=markup)

    recent = finished[:8]
    lines = ["<b>Agent History</b>\n"]
    keyboard_rows: list[list] = []

    for agent in recent:
        status = agent["status"]
        aid = agent["id"]
        task = (agent.get("task") or "")[:40]
        short_id = aid[:20]

        icon = {"completed": "✓", "failed": "✗", "cancelled": "○"}.get(status, "?")
        lines.append(f"{icon} <code>{aid[:12]}</code>\n   {task}")

        row = []
        if status == "completed" and agent.get("output_file"):
            row.append(InlineKeyboardButton("Output", callback_data=f"ag_out:{short_id}"))
        row.append(InlineKeyboardButton("Details", callback_data=f"ag_dtl:{short_id}"))
        keyboard_rows.append(row)

    if len(finished) > 8:
        lines.append(f"\n<i>({len(finished) - 8} older agents not shown)</i>")

    keyboard_rows.append(
        [
            InlineKeyboardButton("Back to Active", callback_data="ag_ref:1"),
        ]
    )

    markup = InlineKeyboardMarkup(keyboard_rows)
    return CommandResult.ok("\n".join(lines), reply_markup=markup)


def _build_model_options(backend_name: str) -> list[dict[str, Any]]:
    """Build model option list for the inline keyboard."""
    from otto.backends import get_available_models, get_backend_model

    current_model = get_backend_model(backend_name)
    models = get_available_models(backend_name)

    options = []
    for m in models:
        model_id = m["id"]
        label = m["label"]
        is_current = current_model and model_id == current_model
        thinking = m.get("thinking", False)

        parts = []
        if is_current:
            parts.append("✓")
        parts.append(label)
        if thinking:
            parts.append("💭")

        options.append({"id": model_id, "label": " ".join(parts)})

    return options


def register(router: CommandRouter) -> None:
    from otto.backends import get_active_backend_name, list_backends

    @router.command("stop", aliases=["cancel"])
    async def cmd_stop(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Cancel in-progress response or manage tool access.

        Usage:
            /stop              — Cancel current response
            /stop tools        — Kill switch: revoke ALL MCP tool access
            /stop tools off    — Restore tool access (deactivate kill switch)
        """
        if args and args[0].lower() == "tools":
            from otto.gateway import (
                activate_kill_switch,
                deactivate_kill_switch,
                is_kill_switch_active,
            )

            if len(args) > 1 and args[1].lower() in ("off", "resume", "restore"):
                deactivate_kill_switch()
                return CommandResult.ok("✅ MCP tool access restored.")

            if is_kill_switch_active():
                return CommandResult.ok(
                    "🔴 Kill switch is already active.\n\n"
                    "Use <code>/stop tools off</code> to restore access."
                )

            activate_kill_switch()
            return CommandResult.ok(
                "🔴 <b>MCP Kill Switch Activated</b>\n\n"
                "All tool access is now revoked.\n"
                "Use <code>/stop tools off</code> to restore."
            )

        core = ctx.platform.core if hasattr(ctx.platform, "core") else None
        if core and core.cancel_request(ctx.message.chat_id):
            return CommandResult.ok("Stopped.")
        return CommandResult.ok("Nothing running.")

    @router.command("agents")
    async def cmd_agents(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Show active sub-agents with inline actions."""
        from otto.jobs.queue import JobQueue

        # Handle cancel subcommand for text-only platforms: /agents cancel <id|all>
        if args and args[0].lower() == "cancel":
            queue = JobQueue()
            target = args[1] if len(args) > 1 else None
            if not target:
                return CommandResult.error("Usage: /agents cancel <id|all>")

            if target.lower() == "all":
                count = queue.force_cancel_all_running(job_type="agent")
                if count:
                    return CommandResult.ok(f"Cancelled {count} agent(s).")
                return CommandResult.ok("No active agents to cancel.")

            job = queue.get_by_external_id(target, job_type="agent")
            if not job:
                return CommandResult.error(f"Agent {target} not found.")
            if queue.force_cancel(int(job["id"])):
                return CommandResult.ok(f"Cancelled agent {target}.")
            return CommandResult.error(f"Agent {target} is already finished.")

        return _build_agents_view(show_history=False)

    @router.command("backend")
    async def cmd_backend(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Show or switch backend/model.

        Usage:
            /backend              - Show current backend and model
            /backend <name>       - Switch to backend
            /backend <name> <model> - Switch to backend with specific model
            /backend . <model>    - Change model for current backend
        """
        from otto.backends import (
            get_backend_model,
            get_known_models,
            set_active_backend,
            set_backend_model,
        )

        active = get_active_backend_name()
        backends = list_backends()
        current_model = get_backend_model(active)

        if not args:
            # Show status with options for UI
            model_str = current_model or "(default)"
            known = get_known_models(active)
            lines = [f"Backend: {active}", f"Model: {model_str}\n"]
            lines.append("Backends:")

            # Build options for all backends (show disabled ones too)
            backend_options = []
            for name, info in backends.items():
                enabled = info.get("enabled", False)
                status = "✓" if enabled else "○"
                marker = " ←" if name == active else ""

                # Add description for backends
                desc = ""
                if name == "pi":
                    desc = " (Pi coding agent)"
                elif name == "litellm":
                    desc = " (LiteLLM multi-provider)"
                elif name == "cecli":
                    desc = " (agentic coder)"

                lines.append(f"  {status} {name}{desc}{marker}")

                # Show all backends as options, mark current with ✓
                if name == active:
                    label = f"✓ {name}"
                elif not enabled:
                    label = f"○ {name}"
                else:
                    label = name
                backend_options.append({"id": name, "label": label})

            if known:
                lines.append(f"\nKnown models for {active}:")
                # Format model list nicely
                if active == "litellm":
                    # Group by provider for litellm backend
                    lines.append("  OpenRouter: openrouter/<model>")
                    lines.append("  Ollama: ollama/<model>")
                    lines.append("  Gemini: gemini/<model>")
                    lines.append("  OpenAI: gpt-4o, gpt-4o-mini")
                else:
                    lines.append(f"  {', '.join(known)}")

            # Add API key hint for litellm backend
            if active == "litellm":
                lines.append("\nAPI keys via env vars:")
                lines.append("  OPENROUTER_API_KEY, OPENAI_API_KEY, etc.")

            # Return with options for Telegram inline keyboard
            return CommandResult(
                text="\n".join(lines),
                success=True,
                options=backend_options,
                action="select",
                next_handler="backend",
            )

        target_backend = args[0].lower()
        target_model = args[1] if len(args) > 1 else None

        # Handle "." meaning current backend
        if target_backend == ".":
            target_backend = active
        elif target_backend not in backends:
            return CommandResult.error(f"Unknown backend: {target_backend}")

        # Switch backend if different
        if target_backend != active:
            set_active_backend(target_backend)

        # Set model if specified
        if target_model:
            set_backend_model(target_model, target_backend)
            return CommandResult.ok(f"Switched to {target_backend} ({target_model}).")
        elif target_backend != active:
            return CommandResult.ok(f"Switched to {target_backend}.")
        else:
            return CommandResult.ok(f"Already on {target_backend}.")

    @router.command("thinking")
    async def cmd_thinking(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Configure extended thinking for AI models."""
        from otto.config import get_setting

        thinking_enabled = get_setting("agent.thinking.enabled", True)
        show_in_chat = get_setting("agent.thinking.show_in_chat", True)

        # Build status text
        status_icon = "✓" if thinking_enabled else "○"
        display_icon = "✓" if show_in_chat else "○"

        text = "<b>Thinking Configuration</b>\n\n"
        text += f"{status_icon} Extended thinking: {'ON' if thinking_enabled else 'OFF'}\n"
        text += f"{display_icon} Show in chat: {'ON' if show_in_chat else 'OFF'}\n\n"

        if thinking_enabled:
            text += "The model will use extended reasoning for complex tasks."
            if show_in_chat:
                text += " Thinking content will be visible."
            else:
                text += " Thinking will be hidden."
        else:
            text += "Extended thinking is disabled. Faster but less thorough."

        # Build options
        options = []
        if thinking_enabled:
            options.append({"id": "disable_thinking", "label": "Disable Thinking"})
            if show_in_chat:
                options.append({"id": "hide_thinking", "label": "Hide in Chat"})
            else:
                options.append({"id": "show_thinking", "label": "Show in Chat"})
        else:
            options.append({"id": "enable_thinking", "label": "Enable Thinking"})

        return CommandResult(
            text=text,
            options=options,
            action="select",
            next_handler="thinking",
            data={"enabled": thinking_enabled, "show_in_chat": show_in_chat},
        )

    # --- Agent callback handlers ---

    @router.callback("ag_stop")
    async def cb_agents_stop(ctx: ChatContext, value: str) -> CommandResult:
        """Stop a running agent."""
        from otto.jobs.queue import JobQueue

        if not value:
            return CommandResult.error("Missing agent ID.")
        queue = JobQueue()
        job = queue.get_by_external_id(value, job_type="agent")
        if not job:
            return CommandResult.error(f"Agent not found: {value[:12]}")
        if queue.force_cancel(int(job["id"])):
            return _build_agents_view(show_history=False)
        return CommandResult.error(f"Agent {value[:12]} already finished.")

    @router.callback("ag_cancel")
    async def cb_agents_cancel(ctx: ChatContext, value: str) -> CommandResult:
        """Cancel a pending agent."""
        from otto.jobs.queue import JobQueue

        if not value:
            return CommandResult.error("Missing agent ID.")
        queue = JobQueue()
        job = queue.get_by_external_id(value, job_type="agent")
        if not job:
            return CommandResult.error(f"Agent not found: {value[:12]}")
        if queue.force_cancel(int(job["id"])):
            return _build_agents_view(show_history=False)
        return CommandResult.error(f"Agent {value[:12]} already finished.")

    @router.callback("ag_out")
    async def cb_agents_output(ctx: ChatContext, value: str) -> CommandResult:
        """Show agent output file contents."""
        from pathlib import Path

        from otto.jobs.queue import JobQueue

        if not value:
            return CommandResult.error("Missing agent ID.")

        queue = JobQueue()
        job = queue.get_by_external_id(value, job_type="agent")
        if not job:
            return CommandResult.error(f"Agent not found: {value[:12]}")

        payload = job.get("payload") or {}
        output_file = payload.get("output_file") or ""

        if not output_file or not Path(output_file).exists():
            return CommandResult.ok(f"No output file for agent {value[:12]}.")

        try:
            content = Path(output_file).read_text()[:2000]
            if not content.strip():
                return CommandResult.ok(f"Output file is empty for agent {value[:12]}.")
            return CommandResult.ok(
                f"<b>Output</b> — <code>{value[:12]}</code>\n\n<pre>{content}</pre>"
            )
        except Exception as e:
            return CommandResult.error(f"Error reading output: {e}")

    @router.callback("ag_dtl")
    async def cb_agents_detail(ctx: ChatContext, value: str) -> CommandResult:
        """Show full agent details."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        from otto.jobs.queue import JobQueue

        if not value:
            return CommandResult.error("Missing agent ID.")

        queue = JobQueue()
        job = queue.get_by_external_id(value, job_type="agent")
        if not job:
            return CommandResult.error(f"Agent not found: {value[:12]}")

        payload = job.get("payload") or {}
        status = job.get("status") or "unknown"
        task = payload.get("task") or payload.get("task_description") or "(no task)"
        backend = payload.get("backend") or "?"
        created = job.get("created_at") or "?"
        attempts = job.get("attempts") or 0
        last_error = job.get("last_error") or ""
        duration = _agent_duration(job.get("created_at", ""))

        icon = {
            "pending": "⏸",
            "running": "⏳",
            "completed": "✓",
            "failed": "✗",
            "cancelled": "○",
        }.get(status, "?")

        lines = [
            "<b>Agent Details</b>\n",
            f"{icon} Status: {status}",
            f"ID: <code>{value}</code>",
            f"Backend: {backend}",
            f"Created: {created[:19]}",
        ]
        if duration:
            lines.append(f"Duration: {duration}")
        if attempts > 1:
            lines.append(f"Attempts: {attempts}")
        if last_error:
            lines.append(f"Error: {last_error[:200]}")
        lines.append(f"\nTask: {task[:200]}")

        short_id = value[:20]
        rows: list[list] = []
        if status == "running":
            rows.append([InlineKeyboardButton("Stop", callback_data=f"ag_stop:{short_id}")])
        elif status == "pending":
            rows.append([InlineKeyboardButton("Cancel", callback_data=f"ag_cancel:{short_id}")])
        elif status == "completed" and payload.get("output_file"):
            rows.append([InlineKeyboardButton("Output", callback_data=f"ag_out:{short_id}")])
        rows.append([InlineKeyboardButton("Back to Active", callback_data="ag_ref:1")])

        markup = InlineKeyboardMarkup(rows)
        return CommandResult.ok("\n".join(lines), reply_markup=markup)

    @router.callback("ag_hist")
    async def cb_agents_history(ctx: ChatContext, value: str) -> CommandResult:
        """Show agent history."""
        return _build_agents_view(show_history=True)

    @router.callback("ag_ref")
    async def cb_agents_refresh(ctx: ChatContext, value: str) -> CommandResult:
        """Refresh the active agents view."""
        return _build_agents_view(show_history=False)

    @router.callback("backend")
    async def cb_backend(ctx: ChatContext, value: str) -> CommandResult:
        """Handle backend selection, then show model picker."""
        from otto.backends import get_backend, get_backend_model, set_active_backend
        from otto.config import set_setting

        if value == "cancel":
            return CommandResult.ok("Backend unchanged.")

        active = get_active_backend_name()
        backends = list_backends()
        if value not in backends:
            return CommandResult.error(f"Unknown backend: {value}")

        # Switch backend (or stay on current)
        switched = value != active
        if switched:
            # Check if backend is enabled, enable it if not
            backend_cfg = backends.get(value, {})
            if not backend_cfg.get("enabled", False):
                set_setting(f"agent.backends.{value}.enabled", True)

            try:
                backend = get_backend(value)
                if not backend.is_available():
                    if value == "litellm":
                        return CommandResult.error(
                            f"Backend {value} requires litellm.\n\n"
                            "Install with:\n"
                            "<code>pip install litellm</code>"
                        )
                    if value == "cecli":
                        return CommandResult.error(
                            f"Backend {value} requires cecli-dev.\n\n"
                            "Install with:\n"
                            "<code>pip install cecli-dev</code>"
                        )
                    return CommandResult.error(
                        f"Backend {value} is not available (check path/config)"
                    )
                set_active_backend(value)
            except Exception as e:
                return CommandResult.error(f"Failed: {e}")

        # Build model options for this backend
        model_options = _build_model_options(value)

        if not model_options:
            # No models to show — just confirm the switch
            if switched:
                return CommandResult.ok(f"Switched to {value}")
            return CommandResult.ok(f"Already using {value}")

        # Show model selector
        current_model = get_backend_model(value)
        header = f"Switched to {value}" if switched else f"Backend: {value}"
        model_str = current_model or "(default)"
        text = f"{header}\nModel: {model_str}\n\nSelect model:"

        model_options.append({"id": "keep", "label": "Keep current"})

        return CommandResult(
            text=text,
            success=True,
            options=model_options,
            action="select",
            next_handler="model",
            data={"columns": 1},
        )

    @router.callback("model")
    async def cb_model(ctx: ChatContext, value: str) -> CommandResult:
        """Handle model selection from inline keyboard."""
        from otto.backends import set_backend_model

        if value in ("cancel", "keep"):
            return CommandResult.ok("Model unchanged.")

        set_backend_model(value)
        return CommandResult.ok(f"Model set to {value}")

    @router.callback("thinking")
    async def cb_thinking(ctx: ChatContext, value: str) -> CommandResult:
        """Handle thinking configuration toggle."""
        from otto.config import set_setting

        if value == "cancel":
            return CommandResult.ok("Thinking config unchanged.")

        if value == "enable_thinking":
            set_setting("agent.thinking.enabled", True)
            return CommandResult.ok("✓ Extended thinking enabled")

        if value == "disable_thinking":
            set_setting("agent.thinking.enabled", False)
            return CommandResult.ok("○ Extended thinking disabled")

        if value == "show_thinking":
            set_setting("agent.thinking.show_in_chat", True)
            return CommandResult.ok("✓ Thinking will be shown in chat")

        if value == "hide_thinking":
            set_setting("agent.thinking.show_in_chat", False)
            return CommandResult.ok("○ Thinking will be hidden in chat")

        return CommandResult.error(f"Unknown action: {value}")
