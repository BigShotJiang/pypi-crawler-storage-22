"""MCP server management commands: /mcp /audit /activity /pause"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING
from . import CommandResult, CommandRouter

if TYPE_CHECKING:
    from ..types import ChatContext


def _mcp_server_status() -> tuple[dict[str, Any], dict[str, dict]]:
    """Return (gateway_servers, empty_catalog) for building the MCP views.

    gateway_servers: {name: ServerPolicy} from otto.gateway
    catalog: empty dict (Docker catalog removed, all servers in gateway)
    """
    try:
        from otto.gateway import get_gateway

        servers = get_gateway().list_servers()
    except Exception:
        servers = {}

    return servers, {}


def _render_mcp_list() -> CommandResult:
    """Render the MCP server list with inline keyboard."""
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup

    servers, catalog = _mcp_server_status()
    all_names = sorted(set(servers.keys()) | set(catalog.keys()))

    if not all_names:
        return CommandResult.ok(
            "<b>MCP Servers</b>\n\n"
            "No servers configured.\n\n"
            "Add servers in <code>~/.otto/settings.yaml</code> under "
            "<code>gateway.servers</code>"
        )

    enabled_names = []
    available_names = []

    for name in all_names:
        sp = servers.get(name)
        if sp and sp.enabled:
            enabled_names.append(name)
        else:
            available_names.append(name)

    lines = ["<b>MCP Servers</b>\n"]

    if enabled_names:
        lines.append("<b>Enabled:</b>")
        for name in enabled_names:
            desc = _mcp_short_desc(name, servers, catalog)
            lines.append(f"✓ {name} — {desc}" if desc else f"✓ {name}")

    if available_names:
        lines.append("\n<b>Available:</b>")
        for name in available_names:
            desc = _mcp_short_desc(name, servers, catalog)
            lines.append(f"○ {name} — {desc}" if desc else f"○ {name}")

    n = len(enabled_names)
    lines.append(f"\n<i>{n} active server{'s' if n != 1 else ''}</i>")

    # Build keyboard: per-server info buttons, 2 per row
    rows: list[list[InlineKeyboardButton]] = []
    btn_row: list[InlineKeyboardButton] = []

    for name in enabled_names:
        btn_row.append(InlineKeyboardButton(f"{name} ✓", callback_data=f"mcp:info_{name[:50]}"))
        if len(btn_row) == 2:
            rows.append(btn_row)
            btn_row = []

    for name in available_names:
        btn_row.append(InlineKeyboardButton(name, callback_data=f"mcp:info_{name[:50]}"))
        if len(btn_row) == 2:
            rows.append(btn_row)
            btn_row = []
    if btn_row:
        rows.append(btn_row)

    rows.append(
        [
            InlineKeyboardButton("📦 Catalog", callback_data="mcp:catalog"),
            InlineKeyboardButton("Gateway", callback_data="mcp:gateway"),
            InlineKeyboardButton("🧪 Test", callback_data="mcp:test"),
            InlineKeyboardButton("↻", callback_data="mcp:refresh"),
        ]
    )

    return CommandResult.ok(
        "\n".join(lines),
        reply_markup=InlineKeyboardMarkup(rows),
    )


def _mcp_short_desc(name: str, servers: dict, catalog: dict) -> str:
    """Get a short description for a server."""
    sp = servers.get(name)
    if sp:
        t = sp.transport.get("type", "builtin" if sp.builtin else "")
        tools = ""
        if sp.allowed_tools is not None:
            tools = f", {len(sp.allowed_tools)} tools"
        return f"{t}{tools}" if t else ""
    cat = catalog.get(name, {})
    desc = cat.get("desc", "")
    # Take the part after " - " if present for brevity
    if " - " in desc:
        return desc.split(" - ", 1)[1][:40]
    return desc[:40]


def _render_mcp_info(name: str) -> CommandResult:
    """Render detail view for a single MCP server."""
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup

    servers, catalog = _mcp_server_status()
    name_lower = name.lower()

    sp = servers.get(name_lower)
    cat = catalog.get(name_lower, {})
    is_enabled = sp.enabled if sp else False

    lines = [f"<b>{name_lower}</b>\n"]

    if cat:
        lines.append(cat.get("desc", ""))
        lines.append(f"\nStatus: {'enabled' if is_enabled else 'disabled'}")
        if "url" in cat:
            lines.append("Type: URL endpoint")
            lines.append(f"URL: {cat['url']}")
        elif "image" in cat:
            lines.append("Type: Docker container")
            lines.append(f"Image: {cat['image']}")
    elif sp:
        t = sp.transport.get("type", "builtin" if sp.builtin else "unknown")
        lines.append(f"Status: {'enabled' if is_enabled else 'disabled'}")
        lines.append(f"Type: {t}")
        if sp.allowed_tools is not None:
            lines.append(f"Allowed tools: {len(sp.allowed_tools)}")
        if sp.blocked_tools:
            lines.append(f"Blocked tools: {len(sp.blocked_tools)}")
    else:
        lines.append("Server not found in gateway or catalog.")

    # Action buttons
    rows: list[list[InlineKeyboardButton]] = []
    if is_enabled:
        rows.append(
            [InlineKeyboardButton("Disable", callback_data=f"mcp:disable_{name_lower[:50]}")]
        )
    else:
        rows.append([InlineKeyboardButton("Enable", callback_data=f"mcp:enable_{name_lower[:50]}")])
    rows.append([InlineKeyboardButton("« Back to Servers", callback_data="mcp:back")])

    return CommandResult.ok(
        "\n".join(lines),
        reply_markup=InlineKeyboardMarkup(rows),
    )


def _mcp_toggle(name: str, *, enable: bool) -> CommandResult:
    """Toggle server enabled/disabled in gateway policy."""
    action = "enable" if enable else "disable"
    return CommandResult.error(
        f"Cannot {action} '{name}' at runtime.\n\n"
        f"Edit <code>settings.yaml</code> → <code>gateway.servers.{name}.enabled</code> "
        f"and reload the gateway."
    )


def _mcp_search(query: str) -> CommandResult:
    """Search configured MCP servers by name/keyword."""
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup

    from otto.gateway import get_gateway

    q = query.lower()
    gateway = get_gateway()
    results: list[tuple[str, str]] = []

    for name, policy in gateway.list_servers().items():
        if q in name.lower():
            transport_type = "builtin" if policy.builtin else policy.transport.get("type", "?")
            status = "enabled" if policy.enabled else "disabled"
            results.append((name, f"{transport_type} ({status})"))

    if not results:
        rows = [[InlineKeyboardButton("« Back to Servers", callback_data="mcp:back")]]
        return CommandResult.ok(
            f"No servers matching: {query}\n\nCheck gateway.servers in settings.yaml.",
            reply_markup=InlineKeyboardMarkup(rows),
        )

    lines = [f"<b>MCP Search:</b> <i>{query}</i>\n"]
    rows: list[list[InlineKeyboardButton]] = []

    for name, desc in results[:10]:
        lines.append(f"• <b>{name}</b> - {desc}")
        rows.append([InlineKeyboardButton(name, callback_data=f"mcp:info_{name[:50]}")])

    rows.append([InlineKeyboardButton("« Back to Servers", callback_data="mcp:back")])

    return CommandResult.ok(
        "\n".join(lines),
        reply_markup=InlineKeyboardMarkup(rows),
    )


def _render_mcp_gateway() -> CommandResult:
    """Render native gateway status inline."""
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup

    from otto.gateway import get_gateway

    lines = ["<b>MCP Gateway</b> (native)\n"]

    try:
        gateway = get_gateway()
        servers = gateway.list_servers()
        enabled = sum(1 for p in servers.values() if p.enabled)
        builtin = sum(1 for p in servers.values() if p.builtin)
        external = enabled - builtin

        # Kill switch status
        ks_status = "🔴 ACTIVE" if gateway.policy.kill_switch else "🟢 Off"
        lines.append(f"Kill Switch: {ks_status}")

        lines.append(f"Servers: {len(servers)} total, {enabled} enabled")
        lines.append(f"Built-in: {builtin}")
        lines.append(f"External: {external}")
        lines.append(f"Audit: {'on' if gateway.policy.audit_enabled else 'off'}")

        if gateway.policy.allowed_paths:
            lines.append(f"\n<b>Allowed paths:</b> {', '.join(gateway.policy.allowed_paths)}")

        if gateway.policy.permissions:
            lines.append("\n<b>Permissions:</b>")
            for op, verdict in gateway.policy.permissions.items():
                lines.append(f"  {op}: {verdict.value}")
    except Exception as e:
        lines.append("Status: <b>error</b>")
        lines.append(f"\n<i>{e}</i>")

    rows = []
    try:
        if gateway.policy.kill_switch:
            rows.append(
                [InlineKeyboardButton("🟢 Deactivate Kill Switch", callback_data="mcp:ks_off")]
            )
        else:
            rows.append(
                [InlineKeyboardButton("🔴 Activate Kill Switch", callback_data="mcp:ks_on")]
            )
    except Exception:
        pass
    rows.append([InlineKeyboardButton("« Back to Servers", callback_data="mcp:back")])
    return CommandResult.ok(
        "\n".join(lines),
        reply_markup=InlineKeyboardMarkup(rows),
    )


def _gateway_validate() -> CommandResult:
    """Validate the gateway policy configuration and show effective policies."""
    from otto.config import get_setting
    from otto.policy import (
        PolicyConfig,
        PolicyEngine,
        validate_policy_config,
    )

    lines = ["<b>Gateway Policy Validation</b>\n"]

    policy_raw = get_setting("gateway.policy") or {}

    # 1. Validate config structure
    errors = validate_policy_config(policy_raw)
    if errors:
        lines.append("❌ <b>Config errors:</b>")
        for err in errors:
            lines.append(f"  • {err}")
    else:
        lines.append("✅ Config syntax is valid")

    # 2. Show active preset and defaults
    policy_config = PolicyConfig.from_config(policy_raw)
    engine = PolicyEngine(policy_config)

    lines.append(f"\n<b>Preset:</b> {policy_config.preset}")
    lines.append(f"<b>Default verdict:</b> {policy_config.defaults.verdict.value}")
    if policy_config.defaults.rate_limit:
        lines.append(f"<b>Default rate limit:</b> {policy_config.defaults.rate_limit}/min")

    # 3. Show global tool verdicts (from preset)
    if policy_config.tool_verdicts:
        lines.append("\n<b>Global tool verdicts:</b>")
        for tool, verdict in sorted(policy_config.tool_verdicts.items()):
            lines.append(f"  {tool}: {verdict.value}")

    # 4. Show per-server effective policies
    if policy_config.servers:
        lines.append("\n<b>Server policies:</b>")
        for srv_name, srv_pol in sorted(policy_config.servers.items()):
            lines.append(f"\n  <b>{srv_name}</b>: {srv_pol.verdict.value}")
            if srv_pol.rate_limit:
                lines.append(f"    rate_limit: {srv_pol.rate_limit}/min")
            if srv_pol.args:
                lines.append(f"    arg_rules: {', '.join(srv_pol.args.keys())}")
            for tool_name, tool_pol in sorted(srv_pol.tools.items()):
                lines.append(f"    {tool_name}: {tool_pol.verdict.value}")
                if tool_pol.rate_limit:
                    lines.append(f"      rate_limit: {tool_pol.rate_limit}/min")
                if tool_pol.args:
                    for arg_name, rule in tool_pol.args.items():
                        parts = []
                        if rule.required:
                            parts.append("required")
                        if rule.must_match:
                            parts.append(f"match: {rule.must_match}")
                        if rule.must_not_match:
                            parts.append(f"block: {rule.must_not_match}")
                        if rule.blocked_values:
                            parts.append(f"blocked: {rule.blocked_values}")
                        if rule.max_length:
                            parts.append(f"max_len: {rule.max_length}")
                        lines.append(f"      {arg_name}: {', '.join(parts)}")

    # 5. Show argument templates
    if policy_config.arg_templates:
        lines.append("\n<b>Argument templates:</b>")
        for tmpl_name, tmpl in sorted(policy_config.arg_templates.items()):
            lines.append(f"  {tmpl_name}: {', '.join(tmpl.args.keys())}")

    # 6. Check catalog inheritance
    try:
        from otto.gateway import get_gateway

        gw = get_gateway()
        catalog_count = 0
        gw_policy_raw = policy_raw.get("servers") or {}
        for srv_name in gw.policy_engine.config.servers:
            if srv_name not in gw_policy_raw:
                catalog_count += 1
        if catalog_count:
            lines.append(f"\n<i>{catalog_count} server(s) inherited policy from catalog</i>")
    except Exception:
        pass

    return CommandResult.ok("\n".join(lines))


def _gateway_test_policy(args: list[str]) -> CommandResult:
    """Test a policy against a mock request."""
    from otto.policy_ext import MockToolRequest, evaluate_mock_request

    if len(args) < 2:
        return CommandResult.error(
            "Usage: /mcp gateway test-policy &lt;server&gt; &lt;tool&gt; [arg=val ...]\n\n"
            "Example:\n"
            "  /mcp gateway test-policy filesystem write_file path=/tmp/test.txt\n"
            "  /mcp gateway test-policy bash exec command='rm -rf /'"
        )

    server = args[0]
    tool = args[1]

    # Parse key=value arguments
    arguments: dict[str, Any] = {}
    for arg in args[2:]:
        if "=" in arg:
            key, value = arg.split("=", 1)
            arguments[key.strip()] = value.strip()
        else:
            arguments[arg] = ""

    request = MockToolRequest(server=server, tool=tool, arguments=arguments)
    result = evaluate_mock_request(request)

    verdict_icon = {"allow": "✅", "deny": "❌", "ask": "❓"}.get(result.verdict, "❓")

    lines = [
        "<b>Policy Test Result</b>\n",
        f"{verdict_icon} <b>Verdict:</b> {result.verdict.upper()}",
        f"<b>Source:</b> {result.source}",
        f"<b>Reason:</b> {result.reason}",
    ]

    if result.arg_errors:
        lines.append("\n<b>Argument errors:</b>")
        for err in result.arg_errors:
            lines.append(f"  • {err}")

    if result.expression_matched:
        lines.append(f"\n<i>Expression: {result.expression_matched}</i>")
    if result.plugin_matched:
        lines.append(f"\n<i>Plugin: {result.plugin_matched}</i>")

    lines.append(f"\n<b>Request:</b> {server}.{tool}")
    if arguments:
        lines.append("<b>Args:</b> " + ", ".join(f"{k}={v}" for k, v in arguments.items()))

    return CommandResult.ok("\n".join(lines))


def _gateway_export_policy(args: list[str]) -> CommandResult:
    """Export current policy as a shareable pack."""
    from otto.policy_ext import PACKS_DIR, ensure_policy_dirs, export_current_policy

    name = args[0] if args else "exported"
    description = " ".join(args[1:]) if len(args) > 1 else ""

    try:
        pack = export_current_policy(name, description)
        ensure_policy_dirs()
        dest = PACKS_DIR / f"{name}.yaml"
        pack.export(dest)
        return CommandResult.ok(
            f"✅ Policy exported as pack <b>{name}</b>\n"
            f"📁 {dest}\n\n"
            f"Share this file or import with:\n"
            f"<code>/mcp gateway import-policy {dest}</code>"
        )
    except Exception as e:
        return CommandResult.error(f"Failed to export: {e}")


def _gateway_import_policy(args: list[str]) -> CommandResult:
    """Import a policy pack file."""
    from pathlib import Path

    from otto.policy_ext import install_pack

    if not args:
        return CommandResult.error(
            "Usage: /mcp gateway import-policy &lt;path&gt;\n\nPath to a .yaml policy pack file."
        )

    pack_path = Path(args[0]).expanduser()
    success, message = install_pack(pack_path)

    if success:
        return CommandResult.ok(f"✅ {message}")
    return CommandResult.error(f"❌ {message}")


def _gateway_list_packs() -> CommandResult:
    """List installed policy packs."""
    from otto.policy_ext import PACKS_DIR, list_packs

    packs = list_packs()

    if not packs:
        return CommandResult.ok(
            "<b>Policy Packs</b>\n\n"
            "No packs installed.\n\n"
            f"Add packs to <code>{PACKS_DIR}</code> or export current policy with:\n"
            "<code>/mcp gateway export-policy my-pack</code>"
        )

    lines = ["<b>Policy Packs</b>\n"]
    for pack in packs:
        lines.append(f"📦 <b>{pack.name}</b> v{pack.version}")
        if pack.description:
            lines.append(f"   {pack.description}")
        if pack.author:
            lines.append(f"   by {pack.author}")
        if pack.source_path:
            lines.append(f"   📁 {pack.source_path}")

        # Validate
        errors = pack.validate()
        if errors:
            lines.append(f"   ⚠️ {len(errors)} validation issue(s)")

    return CommandResult.ok("\n".join(lines))


def _render_mcp_catalog(category: str | None = None) -> CommandResult:
    """Render the curated MCP server catalog for browsing."""
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup

    from otto.catalog import list_catalog, list_categories

    entries = list_catalog(category=category)
    categories = list_categories()

    if not entries:
        if category:
            text = f"<b>MCP Catalog</b>\n\nNo servers in category: {category}"
        else:
            text = "<b>MCP Catalog</b>\n\nCatalog is empty."
        rows = [[InlineKeyboardButton("« Back to Servers", callback_data="mcp:back")]]
        return CommandResult.ok(text, reply_markup=InlineKeyboardMarkup(rows))

    # Check which are already installed
    try:
        from otto.gateway import get_gateway

        installed = set(get_gateway().list_servers().keys())
    except Exception:
        installed = set()

    if category:
        title = f"<b>MCP Catalog</b> — {category}\n"
    else:
        title = f"<b>MCP Catalog</b> ({len(entries)} servers)\n"

    lines = [title]

    # Group by category if showing all
    if not category:
        by_cat: dict[str, list] = {}
        for e in entries:
            by_cat.setdefault(e.category, []).append(e)

        for cat_name in sorted(by_cat.keys()):
            cat_entries = by_cat[cat_name]
            icon = cat_entries[0].category_icon if cat_entries else "📦"
            lines.append(f"\n<b>{icon} {cat_name}</b>")
            for e in cat_entries:
                status = "✓" if e.name in installed else "○"
                lines.append(f"  {status} <b>{e.name}</b> — {e.description[:45]}")
    else:
        for e in entries:
            status = "✓" if e.name in installed else "○"
            risk = e.risk_icon
            lines.append(f"{status} {risk} <b>{e.name}</b>\n   {e.description[:60]}")

    lines.append("\n<i>✓ = installed, ○ = available</i>")

    # Build keyboard
    rows: list[list[InlineKeyboardButton]] = []

    # Category filter buttons (if showing all)
    if not category and len(categories) > 1:
        cat_row: list[InlineKeyboardButton] = []
        for cat in categories[:4]:
            cat_row.append(InlineKeyboardButton(cat.title(), callback_data=f"mcp:cat_{cat[:20]}"))
        rows.append(cat_row)

    # Per-server install/info buttons
    btn_row: list[InlineKeyboardButton] = []
    for e in entries[:12]:  # Limit buttons
        if e.name in installed:
            btn_row.append(
                InlineKeyboardButton(f"{e.name} ✓", callback_data=f"mcp:info_{e.name[:50]}")
            )
        else:
            btn_row.append(
                InlineKeyboardButton(f"+ {e.name}", callback_data=f"mcp:inst_{e.name[:50]}")
            )
        if len(btn_row) == 2:
            rows.append(btn_row)
            btn_row = []
    if btn_row:
        rows.append(btn_row)

    rows.append(
        [
            InlineKeyboardButton("« Back to Servers", callback_data="mcp:back"),
        ]
    )

    return CommandResult.ok(
        "\n".join(lines),
        reply_markup=InlineKeyboardMarkup(rows),
    )


def _render_mcp_catalog_detail(name: str) -> CommandResult:
    """Render detail view for a catalog entry (pre-install)."""
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup

    from otto.catalog import get_catalog_entry

    entry = get_catalog_entry(name)
    if entry is None:
        return CommandResult.error(f"'{name}' not found in catalog")

    # Check if already installed
    try:
        from otto.gateway import get_gateway

        installed = name in get_gateway().list_servers()
    except Exception:
        installed = False

    lines = [
        f"<b>{entry.name}</b> {entry.risk_icon}\n",
        entry.description,
        f"\nCategory: {entry.category_icon} {entry.category}",
        f"Risk: {entry.risk_icon} {entry.risk_level}",
        f"Transport: {entry.transport.get('type', '?')}",
    ]

    if entry.requires_env:
        missing = entry.check_env()
        if missing:
            lines.append(f"\n⚠️ Missing env: {', '.join(missing)}")
        else:
            lines.append("\n✓ Required env vars set")

    if entry.install_hint:
        lines.append(f"\nInstall: {entry.install_hint}")

    if entry.homepage:
        lines.append(f"Homepage: {entry.homepage}")

    rows: list[list[InlineKeyboardButton]] = []
    if installed:
        rows.append(
            [
                InlineKeyboardButton("Remove", callback_data=f"mcp:rm_{name[:50]}"),
                InlineKeyboardButton("Info", callback_data=f"mcp:info_{name[:50]}"),
            ]
        )
    else:
        rows.append(
            [
                InlineKeyboardButton("Install", callback_data=f"mcp:inst_{name[:50]}"),
            ]
        )
    rows.append(
        [
            InlineKeyboardButton("« Back to Catalog", callback_data="mcp:catalog"),
        ]
    )

    return CommandResult.ok(
        "\n".join(lines),
        reply_markup=InlineKeyboardMarkup(rows),
    )


def _mcp_install(name: str) -> CommandResult:
    """Install a server from the catalog into settings.yaml."""
    from otto.catalog import install_server
    from otto.gateway import reload_gateway

    ok, msg = install_server(name)
    if ok:
        # Reload gateway to pick up new server
        reload_gateway()
    return CommandResult.ok(f"{'✓' if ok else '✗'} {msg}")


def _mcp_remove(name: str) -> CommandResult:
    """Remove a server from settings.yaml."""
    from otto.catalog import remove_server
    from otto.gateway import reload_gateway

    ok, msg = remove_server(name)
    if ok:
        reload_gateway()
    return CommandResult.ok(f"{'✓' if ok else '✗'} {msg}")


async def _mcp_test(name: str | None = None) -> CommandResult:
    """Test MCP server connection(s)."""
    from otto.catalog import _test_server_async, test_all_servers
    from otto.gateway import get_gateway

    if name:
        result = await _test_server_async(name)
        results = [result]
    else:
        gateway = get_gateway()
        servers = gateway.list_servers()
        external = [n for n, p in servers.items() if p.enabled and not p.builtin]

        if not external:
            return CommandResult.ok(
                "<b>MCP Test</b>\n\nNo external servers configured.\n"
                "Install one with /mcp install &lt;name&gt;"
            )

        results = await test_all_servers()

    lines = ["<b>MCP Connection Test</b>\n"]
    for r in results:
        if r.success:
            lines.append(
                f"{r.status_icon} <b>{r.server}</b> — {len(r.tools)} tools ({r.latency_ms:.0f}ms)"
            )
        else:
            lines.append(f"{r.status_icon} <b>{r.server}</b> — {r.error}")

    passed = sum(1 for r in results if r.success)
    failed = len(results) - passed
    lines.append(f"\n<i>{passed} passed, {failed} failed</i>")

    return CommandResult.ok("\n".join(lines))


def _render_boundaries() -> CommandResult:
    """Render the agent boundary configuration and live status."""
    from otto.gateway import get_gateway

    try:
        gw = get_gateway()
        b = gw.policy.boundaries

        lines = ["<b>🔒 Agent Boundaries</b>\n"]

        # Config
        lines.append("<b>Configuration:</b>")
        max_turn = b.max_calls_per_turn
        lines.append(f"  Max calls/turn: {max_turn if max_turn > 0 else 'unlimited'}")
        turn_timeout = b.turn_timeout
        lines.append(f"  Turn timeout: {f'{turn_timeout}s' if turn_timeout > 0 else 'none'}")
        cd = b.cooldown_seconds
        lines.append(f"  Global cooldown: {f'{cd}s' if cd > 0 else 'none'}")

        if b.server_cooldowns:
            lines.append("\n  <b>Server cooldowns:</b>")
            for srv, secs in sorted(b.server_cooldowns.items()):
                lines.append(f"    • {srv}: {secs}s")

        # Session quota
        quota = gw._quota
        if quota.max_calls > 0:
            lines.append(f"\n  Session quota: {quota.count}/{quota.max_calls}")
        else:
            lines.append(f"\n  Session quota: unlimited ({quota.count} used)")

        # Live status
        lines.append("\n<b>Live Status:</b>")

        # Kill switch
        if gw.policy.kill_switch:
            lines.append("  🔴 Kill switch: <b>ACTIVE</b>")
        else:
            lines.append("  🟢 Kill switch: Off")

        # Paused servers
        paused = gw.paused_servers
        if paused:
            lines.append(f"  ⏸ Paused servers: {', '.join(sorted(paused.keys()))}")
        else:
            lines.append("  ▶️ All servers active")

        # Current turn
        turn_count = gw.turn_tracker.turn_count
        if max_turn > 0:
            pct = (turn_count / max_turn * 100) if max_turn else 0
            lines.append(f"  Turn progress: {turn_count}/{max_turn} ({pct:.0f}%)")
        elif turn_count > 0:
            lines.append(f"  Calls this turn: {turn_count}")

        return CommandResult.ok("\n".join(lines))
    except Exception as exc:
        return CommandResult.error(f"Could not load boundaries: {exc}")


def register(router: CommandRouter) -> None:

    @router.command("pause")
    async def cmd_pause(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Pause or resume a specific MCP server at runtime.

        Usage:
            /pause <server>        — Pause server (deny all tool calls)
            /pause <server> off    — Resume server
            /pause list            — Show paused servers
        """
        from otto.gateway import get_gateway

        if not args:
            return CommandResult.error(
                "<b>Usage:</b>\n"
                "  /pause &lt;server&gt; — Pause a server\n"
                "  /pause &lt;server&gt; off — Resume a server\n"
                "  /pause list — Show paused servers"
            )

        sub = args[0].lower()

        if sub == "list":
            gw = get_gateway()
            paused = gw.paused_servers
            if not paused:
                return CommandResult.ok("No servers are currently paused.")
            lines = ["<b>Paused Servers</b>\n"]
            for name in sorted(paused.keys()):
                lines.append(f"  ⏸ {name}")
            lines.append("\nResume with: <code>/pause &lt;name&gt; off</code>")
            return CommandResult.ok("\n".join(lines))

        server_name = sub
        gw = get_gateway()

        # Resume?
        if len(args) > 1 and args[1].lower() in ("off", "resume", "restore"):
            if gw.resume_server(server_name):
                return CommandResult.ok(f"▶️ Server <b>{server_name}</b> resumed.")
            return CommandResult.error(f"Server '{server_name}' is not paused.")

        # Pause
        if gw.pause_server(server_name):
            return CommandResult.ok(
                f"⏸ Server <b>{server_name}</b> paused.\n\n"
                f"All tool calls to this server will be denied.\n"
                f"Resume with: <code>/pause {server_name} off</code>"
            )
        return CommandResult.error(
            f"Server '{server_name}' not found in gateway.\n"
            f"Available: {', '.join(sorted(gw.list_servers().keys())) or 'none'}"
        )

    @router.command("mcp")
    async def cmd_mcp(ctx: ChatContext, args: list[str]) -> CommandResult:
        """MCP server management with inline keyboards."""
        if not args:
            return _render_mcp_list()

        subcmd = args[0].lower()
        rest = args[1:] if len(args) > 1 else []

        if subcmd == "list":
            return _render_mcp_list()
        if subcmd == "info" and rest:
            return _render_mcp_info(rest[0])
        if subcmd == "enable" and rest:
            return _mcp_toggle(rest[0], enable=True)
        if subcmd == "disable" and rest:
            return _mcp_toggle(rest[0], enable=False)
        if subcmd == "search" and rest:
            return _mcp_search(" ".join(rest))
        if subcmd == "gateway":
            if rest and rest[0].lower() == "validate":
                return _gateway_validate()
            if rest and rest[0].lower() == "test-policy":
                return _gateway_test_policy(rest[1:])
            if rest and rest[0].lower() == "export-policy":
                return _gateway_export_policy(rest[1:])
            if rest and rest[0].lower() == "import-policy":
                return _gateway_import_policy(rest[1:])
            if rest and rest[0].lower() == "packs":
                return _gateway_list_packs()
            return _render_mcp_gateway()
        if subcmd == "catalog":
            category = rest[0] if rest else None
            return _render_mcp_catalog(category)
        if subcmd == "install" and rest:
            return _mcp_install(rest[0])
        if subcmd == "remove" and rest:
            return _mcp_remove(rest[0])
        if subcmd == "test":
            server_name = rest[0] if rest else None
            return await _mcp_test(server_name)
        if subcmd == "add" and rest:
            return _mcp_install(rest[0])

        return CommandResult.error(
            "Usage:\n"
            "  /mcp — Server list\n"
            "  /mcp catalog — Browse available servers\n"
            "  /mcp install &lt;name&gt; — Install from catalog\n"
            "  /mcp remove &lt;name&gt; — Remove server\n"
            "  /mcp test [name] — Test server connection\n"
            "  /mcp gateway — Gateway status\n"
            "  /mcp gateway validate — Validate policy config\n"
            "  /mcp gateway test-policy &lt;server&gt; &lt;tool&gt; [arg=val ...] — Test policy\n"
            "  /mcp gateway export-policy [name] — Export policy as pack\n"
            "  /mcp gateway import-policy &lt;path&gt; — Import policy pack\n"
            "  /mcp gateway packs — List installed packs\n"
            "  /mcp info &lt;name&gt;\n"
            "  /mcp search &lt;query&gt;"
        )

    @router.command("audit")
    async def cmd_audit(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Query the gateway audit log.

        Usage:
            /audit                — Show audit stats summary
            /audit list [N]       — Show last N entries (default 20)
            /audit search <term>  — Search audit entries
            /audit denials [N]    — Show recent denials
            /audit server <name>  — Show entries for a server
            /audit tool <name>    — Show entries for a tool
        """
        from otto.audit import audit_stats, format_logs, query_audit

        if not args:
            # Show summary stats
            stats = audit_stats()
            lines = [
                "<b>📊 Audit Summary</b>\n",
                f"Total entries: <b>{stats['total']}</b>",
                f"Denials: <b>{stats['denials']}</b>",
            ]

            if stats["by_verdict"]:
                lines.append("\n<b>By verdict:</b>")
                for verdict, count in sorted(stats["by_verdict"].items()):
                    icon = {"allow": "✅", "deny": "🚫", "prompt": "❓"}.get(verdict, "•")
                    lines.append(f"  {icon} {verdict}: {count}")

            if stats["by_server"]:
                lines.append("\n<b>Top servers:</b>")
                for srv, count in list(stats["by_server"].items())[:5]:
                    lines.append(f"  • {srv}: {count}")

            if stats["by_type"]:
                lines.append("\n<b>By type:</b>")
                for t, count in sorted(stats["by_type"].items()):
                    lines.append(f"  • {t}: {count}")

            lines.append("\n<i>Use /audit list, /audit search, /audit denials</i>")
            return CommandResult.ok("\n".join(lines))

        sub = args[0].lower()
        rest = args[1:]

        if sub == "list":
            limit = int(rest[0]) if rest and rest[0].isdigit() else 20
            entries = query_audit(limit=limit)
            if not entries:
                return CommandResult.ok("No audit entries found.")
            header = f"<b>📋 Last {len(entries)} audit entries</b>\n\n"
            return CommandResult.ok(header + f"<pre>{format_logs(entries)}</pre>")

        elif sub == "search":
            if not rest:
                return CommandResult.error("Usage: /audit search &lt;term&gt;")
            term = " ".join(rest)
            entries = query_audit(search=term, limit=30)
            if not entries:
                return CommandResult.ok(f"No entries matching '{term}'.")
            header = f"<b>🔍 Audit search: '{term}' ({len(entries)} results)</b>\n\n"
            return CommandResult.ok(header + f"<pre>{format_logs(entries)}</pre>")

        elif sub == "denials":
            limit = int(rest[0]) if rest and rest[0].isdigit() else 20
            entries = query_audit(verdict="deny", limit=limit)
            if not entries:
                return CommandResult.ok("No denials found. 🎉")
            header = f"<b>🚫 Recent denials ({len(entries)})</b>\n\n"
            return CommandResult.ok(header + f"<pre>{format_logs(entries)}</pre>")

        elif sub == "server":
            if not rest:
                return CommandResult.error("Usage: /audit server &lt;name&gt;")
            entries = query_audit(server=rest[0], limit=30)
            if not entries:
                return CommandResult.ok(f"No entries for server '{rest[0]}'.")
            header = f"<b>📋 Audit for server '{rest[0]}' ({len(entries)} entries)</b>\n\n"
            return CommandResult.ok(header + f"<pre>{format_logs(entries)}</pre>")

        elif sub == "tool":
            if not rest:
                return CommandResult.error("Usage: /audit tool &lt;name&gt;")
            entries = query_audit(tool=rest[0], limit=30)
            if not entries:
                return CommandResult.ok(f"No entries for tool '{rest[0]}'.")
            header = f"<b>📋 Audit for tool '{rest[0]}' ({len(entries)} entries)</b>\n\n"
            return CommandResult.ok(header + f"<pre>{format_logs(entries)}</pre>")

        else:
            return CommandResult.error(
                "<b>Usage:</b>\n"
                "  /audit — Summary stats\n"
                "  /audit list [N] — Last N entries\n"
                "  /audit search &lt;term&gt;\n"
                "  /audit denials [N]\n"
                "  /audit server &lt;name&gt;\n"
                "  /audit tool &lt;name&gt;"
            )

    @router.command("activity", aliases=["tools"])
    async def cmd_activity(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Live MCP tool activity dashboard.

        Usage:
            /activity              — 24h activity dashboard
            /activity [N]h         — Last N hours (e.g., /activity 6h)
            /activity anomalies    — Recent anomaly alerts
            /activity replay [N]   — Last N tool calls (session replay)
            /activity summary      — Generate daily summary
            /activity boundaries   — Show agent boundary status
        """
        from otto.observability import (
            format_activity_dashboard,
            format_anomalies,
            generate_daily_summary,
            get_activity_summary,
            get_detector,
            get_session_replay,
        )

        if not args:
            summary = get_activity_summary(hours=24)
            text = format_activity_dashboard(summary)

            # Append live status section
            try:
                from otto.gateway import get_gateway

                gw = get_gateway()
                status_parts = []

                # Kill switch
                if gw.policy.kill_switch:
                    status_parts.append("🔴 Kill switch: <b>ACTIVE</b>")

                # Paused servers
                paused = gw.paused_servers
                if paused:
                    names = ", ".join(sorted(paused.keys()))
                    status_parts.append(f"⏸ Paused: {names}")

                # Turn tracker
                turn_count = gw.turn_tracker.turn_count
                max_turn = gw.policy.boundaries.max_calls_per_turn
                if max_turn > 0:
                    status_parts.append(f"Turn: {turn_count}/{max_turn}")

                # Quota
                if gw._quota.max_calls > 0:
                    status_parts.append(f"Quota: {gw._quota.count}/{gw._quota.max_calls}")

                if status_parts:
                    text += "\n\n<b>Live Status:</b>\n" + "\n".join(f"  {p}" for p in status_parts)
            except Exception:
                pass

            return CommandResult.ok(text)

        sub = args[0].lower()

        # /activity 6h — custom time window
        if sub.endswith("h") and sub[:-1].isdigit():
            hours = int(sub[:-1])
            hours = max(1, min(hours, 720))  # 1h to 30 days
            summary = get_activity_summary(hours=hours)
            return CommandResult.ok(format_activity_dashboard(summary))

        if sub == "anomalies":
            detector = get_detector()
            anomalies = detector.anomalies
            return CommandResult.ok(format_anomalies(anomalies))

        if sub == "replay":
            limit = int(args[1]) if len(args) > 1 and args[1].isdigit() else 20
            entries = get_session_replay(limit=limit)
            if not entries:
                return CommandResult.ok("No tool call history found.")
            from otto.audit import format_logs

            header = f"<b>🔄 Session Replay ({len(entries)} entries)</b>\n\n"
            return CommandResult.ok(header + f"<pre>{format_logs(entries)}</pre>")

        if sub == "summary":
            text = generate_daily_summary()
            return CommandResult.ok(text)

        if sub == "boundaries":
            return _render_boundaries()

        return CommandResult.error(
            "<b>Usage:</b>\n"
            "  /activity — 24h dashboard\n"
            "  /activity [N]h — Last N hours\n"
            "  /activity anomalies — Anomaly alerts\n"
            "  /activity replay [N] — Tool call history\n"
            "  /activity summary — Daily summary\n"
            "  /activity boundaries — Agent boundary status"
        )

    @router.callback("mcp")
    async def cb_mcp(ctx: ChatContext, value: str) -> CommandResult:
        """Route MCP callbacks: info_*, enable_*, disable_*, gateway, refresh, back."""
        if not value:
            return _render_mcp_list()

        if value == "refresh" or value == "back":
            return _render_mcp_list()

        if value == "gateway":
            return _render_mcp_gateway()

        if value.startswith("info_"):
            return _render_mcp_info(value[5:])

        if value.startswith("enable_"):
            return _mcp_toggle(value[7:], enable=True)

        if value.startswith("disable_"):
            return _mcp_toggle(value[8:], enable=False)

        if value == "ks_on":
            from otto.gateway import activate_kill_switch

            activate_kill_switch()
            return _render_mcp_gateway()

        if value == "ks_off":
            from otto.gateway import deactivate_kill_switch

            deactivate_kill_switch()
            return _render_mcp_gateway()

        # Catalog callbacks
        if value == "catalog":
            return _render_mcp_catalog()

        if value.startswith("cat_"):
            return _render_mcp_catalog(value[4:])

        if value.startswith("catinfo_"):
            return _render_mcp_catalog_detail(value[8:])

        if value.startswith("inst_"):
            return _mcp_install(value[5:])

        if value.startswith("rm_"):
            return _mcp_remove(value[3:])

        if value == "test":
            return await _mcp_test()

        if value.startswith("test_"):
            return await _mcp_test(value[5:])

        return CommandResult.error(f"Unknown MCP action: {value}")
