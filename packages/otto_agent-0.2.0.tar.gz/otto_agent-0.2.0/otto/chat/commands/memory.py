"""Memory and tasks commands: /memory /vtt /tasks /poll /reindex"""

from __future__ import annotations

from typing import TYPE_CHECKING
from . import CommandResult, CommandRouter

if TYPE_CHECKING:
    from ..types import ChatContext


def register(router: CommandRouter) -> None:
    from otto import memory_search_formatted, memory_stats

    @router.command("memory")
    async def cmd_memory(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Search memory or show stats."""
        if not args:
            stats = memory_stats()
            chunks = stats.get("total_chunks", 0)
            if chunks == 0:
                return CommandResult.ok(
                    "Memory index is empty.\n\n"
                    "Use /reindex to build the index from your knowledge files and sessions."
                )
            return CommandResult.ok(
                f"Memory: {chunks} chunks indexed\nUse /memory <query> to search."
            )

        query = " ".join(args)
        results = memory_search_formatted(query, limit=3)
        if not results:
            return CommandResult.ok(
                f"Nothing found for: {query}\n\n"
                "Try broader terms, or /reindex to rebuild the index."
            )
        return CommandResult.ok(results)

    @router.command("vtt")
    async def cmd_vtt(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Toggle voice-to-text transcription."""
        try:
            from otto_tools.vtt import is_model_ready
            from otto_tools.vtt import load_config as vtt_load_config

            vtt_config = vtt_load_config()
            vtt_enabled = vtt_config.get("enabled", False)
            model = vtt_config.get("model", "base")
            model_ready = is_model_ready()
        except ImportError:
            return CommandResult.error("VTT not available\n\nModule otto_tools.vtt not found.")

        status = "enabled" if vtt_enabled else "disabled"
        model_status = "ready" if model_ready else "not downloaded"

        text = f"Voice-to-Text: {status.upper()}\nModel: {model} ({model_status})"
        if vtt_enabled:
            text += "\n\nVoice messages will be transcribed."
        else:
            text += "\n\nEnable to transcribe voice messages."

        # Build options based on current state
        if vtt_enabled:
            options = [{"id": "disable", "label": "Disable VTT"}]
        else:
            options = [{"id": "enable", "label": "Enable VTT"}]
            if not model_ready:
                options.append({"id": "download", "label": "Download Model"})

        return CommandResult(
            text=text,
            options=options,
            action="select",
            next_handler="vtt_toggle",
            data={"enabled": vtt_enabled, "model": model, "model_ready": model_ready},
        )

    @router.command("reindex")
    async def cmd_reindex(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Re-index memory."""
        stats = memory_stats()
        return CommandResult.confirm(
            f"Re-index Memory?\n\nCurrent: {stats.get('total_chunks', 0)} chunks\n\n"
            "This will rebuild the search index from:\n"
            "• Knowledge files\n"
            "• Project notes\n"
            "• Session history",
            handler="reindex",
            data=stats,
        )

    @router.command("tasks")
    async def cmd_tasks(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Manage task checklists."""
        import re

        from otto.services.tasks import (
            create_checklist,
            get_checklist,
            get_task_manager,
            render_checklist,
        )

        raw = (ctx.message.text or "").strip()
        rest = raw[len("/tasks") :].strip() if raw.lower().startswith("/tasks") else " ".join(args)

        if rest.lower().startswith("new"):
            spec = rest[3:].strip()
            if not spec:
                return CommandResult.error("Usage: /tasks new <title> | <task1>; <task2>; ...")

            if "|" in spec:
                title, tasks_part = spec.split("|", 1)
                title = title.strip()
                tasks = [t.strip() for t in re.split(r"[;\n]", tasks_part) if t.strip()]
            else:
                title = spec.strip()
                tasks = []

            if not title:
                return CommandResult.error("Checklist title required.")

            checklist = create_checklist(title, int(ctx.message.chat_id), tasks, created_by="otto")
            text, keyboard = render_checklist(checklist)
            return CommandResult.ok(
                text,
                reply_markup=keyboard,
                data={"task_checklist_id": checklist.id},
            )

        if rest.lower().startswith("show"):
            parts = rest.split(maxsplit=2)
            if len(parts) < 2:
                return CommandResult.error("Usage: /tasks show <checklist_id>")
            checklist_id = parts[1]
            checklist = get_checklist(checklist_id)
            if not checklist:
                return CommandResult.error("Checklist not found.")
            text, keyboard = render_checklist(checklist)
            return CommandResult.ok(
                text, reply_markup=keyboard, data={"task_checklist_id": checklist.id}
            )

        if rest.lower().startswith("add"):
            parts = rest.split(maxsplit=2)
            if len(parts) < 3:
                return CommandResult.error("Usage: /tasks add <checklist_id> <task>")
            checklist_id = parts[1]
            content = parts[2].strip()
            if not content:
                return CommandResult.error("Task content required.")
            mgr = get_task_manager()
            task = mgr.add_task_to_checklist(checklist_id, content, created_by="user")
            if not task:
                return CommandResult.error("Checklist not found.")
            checklist = get_checklist(checklist_id)
            if not checklist:
                return CommandResult.error("Checklist not found.")
            text, keyboard = render_checklist(checklist)
            return CommandResult.ok(
                text, reply_markup=keyboard, data={"task_checklist_id": checklist.id}
            )

        # Default: list active checklists with buttons.
        mgr = get_task_manager()
        checklists = mgr.get_active_checklists(int(ctx.message.chat_id), limit=10)
        if not checklists:
            return CommandResult.ok(
                "No active task lists.\n\n"
                "Create one: <code>/tasks new Title | task 1; task 2</code>\n"
                "Or just ask me to make a checklist for you."
            )

        options = [{"id": cl.id, "label": cl.title[:40]} for cl in checklists]
        lines = ["<b>Tasks</b>\n", "Select a checklist:"]
        for cl in checklists:
            lines.append(f"• <code>{cl.id}</code> — {cl.title[:60]}")

        return CommandResult.select("\n".join(lines), options=options, handler="tasks")

    @router.command("poll")
    async def cmd_poll(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Create or view polls.

        Usage:
            /poll                              - Show active polls
            /poll "Question?" opt1; opt2; opt3 - Create new poll
        """
        import re

        from otto.services.tasks import get_poll_manager, render_poll

        raw = (ctx.message.text or "").strip()
        rest = raw[len("/poll") :].strip() if raw.lower().startswith("/poll") else " ".join(args)

        if not rest:
            # List active (open) polls for this chat
            mgr = get_poll_manager()
            import sqlite3

            with sqlite3.connect(mgr.db_path) as conn:
                conn.row_factory = sqlite3.Row
                rows = conn.execute(
                    """SELECT id, question FROM polls
                       WHERE chat_id = ? AND closed = 0
                       ORDER BY created_at DESC LIMIT 10""",
                    (int(ctx.message.chat_id),),
                ).fetchall()

            if not rows:
                return CommandResult.ok(
                    "No active polls.\n\n"
                    'Create one: <code>/poll "Question?" opt1; opt2; opt3</code>'
                )

            lines = ["<b>Active Polls</b>\n"]
            options = []
            for row in rows:
                lines.append(f"• {row['question'][:50]}")
                options.append({"id": row["id"], "label": row["question"][:30]})

            return CommandResult.select("\n".join(lines), options=options, handler="poll_show")

        # Parse: "Question?" option1; option2; option3
        # The question can be quoted or unquoted (ends at ? or first ;)
        match = re.match(r'^"([^"]+)"\s*(.*)', rest)
        if match:
            question = match.group(1).strip()
            opts_str = match.group(2).strip()
        else:
            # Try splitting on ? as question delimiter
            if "?" in rest and ";" in rest:
                q_end = rest.index("?")
                question = rest[: q_end + 1].strip()
                opts_str = rest[q_end + 1 :].strip()
            else:
                return CommandResult.error('Usage: <code>/poll "Question?" opt1; opt2; opt3</code>')

        # Parse options
        opt_list = [o.strip() for o in opts_str.split(";") if o.strip()]
        if len(opt_list) < 2:
            return CommandResult.error("Polls need at least 2 options (separated by ;)")

        # Build options dict {key: label}
        options_dict = {}
        for i, opt in enumerate(opt_list):
            options_dict[str(i)] = opt

        mgr = get_poll_manager()
        poll = mgr.create_poll(
            chat_id=int(ctx.message.chat_id),
            question=question,
            options=options_dict,
            created_by="user",
        )

        user_id = ctx.message.user_id or "0"
        text, keyboard = render_poll(poll, user_id)
        return CommandResult.ok(text, reply_markup=keyboard, data={"poll_id": poll.id})

    # --- Callbacks ---

    @router.callback("vtt_toggle")
    async def cb_vtt_toggle(ctx: ChatContext, value: str) -> CommandResult:
        """Handle VTT toggle."""
        if value in ("no", "cancel"):
            return CommandResult.ok("VTT unchanged.")

        try:
            from otto_tools.vtt import download_model, load_config, save_config

            if value == "download":
                # Download the model
                try:
                    download_model()
                    return CommandResult.ok("Model downloaded. Enable VTT to use.")
                except Exception as e:
                    return CommandResult.error(f"Download failed: {e}")

            config = load_config()

            if value == "enable":
                config["enabled"] = True
            elif value == "disable":
                config["enabled"] = False
            else:
                # Legacy toggle behavior
                config["enabled"] = not config.get("enabled", False)

            save_config(config)
            new_state = "enabled" if config["enabled"] else "disabled"
            return CommandResult.ok(f"Voice-to-Text {new_state}")
        except ImportError:
            return CommandResult.error("VTT module not available")
        except Exception as e:
            return CommandResult.error(f"Error: {e}")

    @router.callback("reindex")
    async def cb_reindex(ctx: ChatContext, value: str) -> CommandResult:
        """Handle reindex confirmation."""
        if value != "yes":
            return CommandResult.ok("Reindex cancelled.")

        from otto import index_memory

        try:
            counts = index_memory(force=True)
            return CommandResult.ok(
                f"Indexed: {counts.get('total', 0)} chunks\n"
                f"Knowledge: {counts.get('knowledge', 0)}\n"
                f"Projects: {counts.get('projects', 0)}\n"
                f"Sessions: {counts.get('sessions', 0)}"
            )
        except Exception as e:
            return CommandResult.error(f"Indexing failed: {e}")

    @router.callback("tasks")
    async def cb_tasks(ctx: ChatContext, value: str) -> CommandResult:
        """Open a checklist from /tasks selection."""
        from otto.services.tasks import get_checklist, get_task_manager, render_checklist

        if value == "cancel":
            return CommandResult.ok("Cancelled.")

        checklist = get_checklist(value)
        if not checklist:
            return CommandResult.error("Checklist not found.")

        # Track the Telegram message_id that now represents this checklist.
        if ctx.message.message_id:
            try:
                get_task_manager().update_checklist_message_id(value, int(ctx.message.message_id))
                checklist.message_id = int(ctx.message.message_id)
            except Exception:
                pass

        text, keyboard = render_checklist(checklist)
        return CommandResult.ok(
            text, reply_markup=keyboard, data={"task_checklist_id": checklist.id}
        )

    @router.callback("task_toggle")
    async def cb_task_toggle(ctx: ChatContext, value: str) -> CommandResult:
        """Toggle a task and refresh the checklist UI."""
        from otto.services.tasks import (
            get_checklist,
            get_task_manager,
            render_checklist,
            toggle_task,
        )

        if not value:
            return CommandResult.error("Missing task ID.")

        task = toggle_task(value, toggled_by="user")
        if not task or not task.checklist_id:
            return CommandResult.error("Task not found.")

        checklist_id = str(task.checklist_id)
        checklist = get_checklist(checklist_id)
        if not checklist:
            return CommandResult.error("Checklist not found.")

        if ctx.message.message_id:
            try:
                get_task_manager().update_checklist_message_id(
                    checklist_id, int(ctx.message.message_id)
                )
                checklist.message_id = int(ctx.message.message_id)
            except Exception:
                pass

        text, keyboard = render_checklist(checklist)
        return CommandResult.ok(
            text, reply_markup=keyboard, data={"task_checklist_id": checklist.id}
        )

    @router.callback("task_done")
    async def cb_task_done(ctx: ChatContext, value: str) -> CommandResult:
        """Close a checklist UI (hide the keyboard)."""
        from otto.services.tasks import get_checklist, render_checklist

        if not value:
            return CommandResult.error("Missing checklist ID.")

        checklist = get_checklist(value)
        if not checklist:
            return CommandResult.error("Checklist not found.")

        text, _keyboard = render_checklist(checklist)
        return CommandResult.ok(f"{text}\n\n<i>(Checklist closed)</i>")

    @router.callback("poll_show")
    async def cb_poll_show(ctx: ChatContext, value: str) -> CommandResult:
        """Show a poll from the poll list selection."""
        from otto.services.tasks import get_poll_manager, render_poll

        if value == "cancel":
            return CommandResult.ok("Cancelled.")

        mgr = get_poll_manager()
        poll = mgr.get_poll(value)
        if not poll:
            return CommandResult.error("Poll not found.")

        user_id = ctx.message.user_id or "0"
        text, keyboard = render_poll(poll, user_id)
        return CommandResult.ok(text, reply_markup=keyboard, data={"poll_id": poll.id})

    @router.callback("poll_vote")
    async def cb_poll_vote(ctx: ChatContext, value: str) -> CommandResult:
        """Toggle vote on a poll option. Value format: {poll_id}:{option_key}"""
        from otto.services.tasks import get_poll_manager, render_poll

        if not value or ":" not in value:
            return CommandResult.error("Invalid vote data.")

        poll_id, option_key = value.split(":", 1)
        user_id = ctx.message.user_id or "0"

        mgr = get_poll_manager()
        poll = mgr.get_poll(poll_id)
        if not poll:
            return CommandResult.error("Poll not found.")

        if poll.closed:
            text = mgr.render_poll_text(poll)
            return CommandResult.ok(text)

        mgr.toggle_vote(poll_id, user_id, option_key)

        # Re-fetch poll with updated votes
        poll = mgr.get_poll(poll_id)
        text, keyboard = render_poll(poll, user_id)
        return CommandResult.ok(text, reply_markup=keyboard, data={"poll_id": poll.id})

    @router.callback("poll_results")
    async def cb_poll_results(ctx: ChatContext, value: str) -> CommandResult:
        """Show poll results view."""
        from otto.services.tasks import get_poll_manager

        mgr = get_poll_manager()
        poll = mgr.get_poll(value)
        if not poll:
            return CommandResult.error("Poll not found.")

        text = mgr.render_poll_text(poll)
        return CommandResult.ok(text)

    @router.callback("poll_close")
    async def cb_poll_close(ctx: ChatContext, value: str) -> CommandResult:
        """Close a poll to voting."""
        from otto.services.tasks import get_poll_manager

        mgr = get_poll_manager()
        poll = mgr.get_poll(value)
        if not poll:
            return CommandResult.error("Poll not found.")

        mgr.close_poll(value)

        # Re-fetch with closed state
        poll = mgr.get_poll(value)
        text = mgr.render_poll_text(poll)
        return CommandResult.ok(text)
