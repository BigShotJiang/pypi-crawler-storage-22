from __future__ import annotations

from typing import TYPE_CHECKING
from . import CommandResult, CommandRouter

if TYPE_CHECKING:
    from ..types import ChatContext

from otto import (
    delete_session,
    get_current_session,
    list_sessions,
    new_session,
    load_session,
)
from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def _relative_time(iso_str: str | None) -> str:
    """Convert an ISO timestamp to a human-readable relative time."""
    if not iso_str:
        return ""
    try:
        from datetime import datetime, timezone

        dt = datetime.fromisoformat(iso_str)
        if dt.tzinfo is None:
            # Timestamps are stored as naive local time, compare with local now
            now = datetime.now()
        else:
            now = datetime.now(timezone.utc)
        diff = now - dt
        secs = int(diff.total_seconds())
        if secs < 0:
            return "just now"
        if secs < 60:
            return "just now"
        if secs < 3600:
            return f"{secs // 60}m ago"
        if secs < 86400:
            return f"{secs // 3600}h ago"
        d = secs // 86400
        if d == 1:
            return "yesterday"
        if d < 30:
            return f"{d}d ago"
        return f"{d // 30}mo ago"
    except Exception:
        return ""


def _render_sessions_page(page: int = 0, chat_id: str | None = None) -> CommandResult:
    """Render a page of sessions with inline keyboard."""

    PAGE_SIZE = 5
    all_sessions = list_sessions(chat_id=chat_id) or []

    if not all_sessions:
        return CommandResult.ok(
            "<b>Sessions</b>\n\n"
            "No sessions yet.\n\n"
            "Use /new to start a fresh session — your current chat will be saved."
        )

    current_session = get_current_session(chat_id=chat_id)
    current_id = current_session.get("id", "")

    total = len(all_sessions)
    total_pages = (total + PAGE_SIZE - 1) // PAGE_SIZE
    page = min(page, total_pages - 1)
    start = page * PAGE_SIZE
    page_sessions = all_sessions[start : start + PAGE_SIZE]

    lines = [f"<b>Sessions</b> ({total} total)\n"]

    buttons: list[list[InlineKeyboardButton]] = []
    for s in page_sessions:
        sid = s.get("id") or "?"
        topic = (s.get("topic") or "")[:25] or "(no topic)"
        msg_count = s.get("message_count", 0)
        age = _relative_time(s.get("last_activity") or s.get("created"))
        is_current = s.get("is_current", False) or sid == current_id

        marker = " ← current" if is_current else ""
        lines.append(
            f"{'▸' if is_current else '•'} <b>{topic}</b>{marker}\n  {msg_count} msgs · {age}"
        )

        # Per-session action buttons
        row = []
        if not is_current:
            # callback_data max 64 bytes: "sess_sw:{id}" must fit
            sw_data = f"sess_sw:{sid[:50]}"
            row.append(InlineKeyboardButton("Switch", callback_data=sw_data))
        del_data = f"sess_del:{sid[:50]}"
        row.append(InlineKeyboardButton("Delete", callback_data=del_data))
        if row:
            buttons.append(row)

    # Pagination buttons
    nav_row: list[InlineKeyboardButton] = []
    if page > 0:
        nav_row.append(InlineKeyboardButton("« Prev", callback_data=f"sess_pg:{page - 1}"))
    if page < total_pages - 1:
        nav_row.append(InlineKeyboardButton("Next »", callback_data=f"sess_pg:{page + 1}"))
    if nav_row:
        buttons.append(nav_row)

    return CommandResult.ok(
        "\n".join(lines),
        reply_markup=InlineKeyboardMarkup(buttons) if buttons else None,
    )


def register(router: CommandRouter):
    @router.command("new", aliases=["clear"])
    async def cmd_new(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Start a fresh session."""
        from otto.sessions import maybe_auto_title

        # Auto-title the outgoing session before archiving (fire-and-forget)
        try:
            await maybe_auto_title(chat_id=ctx.message.chat_id, force=True)
        except Exception:
            pass

        topic = " ".join(args) if args else None
        new_session(topic=topic, archive_current=True, chat_id=ctx.message.chat_id)
        if topic:
            return CommandResult.ok(f"Fresh session started: {topic}")
        return CommandResult.ok("Fresh session started.")

    @router.command("sessions")
    async def cmd_sessions(ctx: ChatContext, args: list[str]) -> CommandResult:
        """List sessions with topic, message count, relative age, and pagination."""

        # Parse page number from args
        page = 0
        if args:
            try:
                page = max(0, int(args[0]) - 1)
            except ValueError:
                pass

        return _render_sessions_page(page, chat_id=ctx.message.chat_id)

    @router.command("switch")
    async def cmd_switch(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Switch to a different session."""
        from otto.sessions import maybe_auto_title

        if not args:
            return CommandResult.error("Usage: /switch <session_id>")

        # Auto-title the outgoing session before switching (fire-and-forget)
        try:
            await maybe_auto_title(chat_id=ctx.message.chat_id, force=True)
        except Exception:
            pass

        session_id = args[0]
        session = load_session(session_id, chat_id=ctx.message.chat_id)
        if session:
            topic = session.get("topic") or session_id[:15]
            return CommandResult.ok(f"Resumed session: {topic}")
        return CommandResult.error(f"Session not found: {session_id}")

    @router.callback("session")
    async def cb_session(ctx: ChatContext, value: str) -> CommandResult:
        """Handle session switch (legacy)."""
        if value == "cancel":
            return CommandResult.ok("Session unchanged.")

        session = load_session(value, chat_id=ctx.message.chat_id)
        if session:
            topic = session.get("topic") or value[:15]
            return CommandResult.ok(f"Resumed session: {topic}")
        return CommandResult.error(f"Session not found: {value}")

    @router.callback("sess_pg")
    async def cb_session_page(ctx: ChatContext, value: str) -> CommandResult:
        """Navigate session pages."""
        try:
            page = int(value)
        except ValueError:
            page = 0
        return _render_sessions_page(page, chat_id=ctx.message.chat_id)

    @router.callback("sess_sw")
    async def cb_session_switch(ctx: ChatContext, value: str) -> CommandResult:
        """Switch to a session."""
        if not value:
            return CommandResult.error("Missing session ID.")

        session = load_session(value, chat_id=ctx.message.chat_id)
        if session:
            topic = session.get("topic") or value[:15]
            return CommandResult.ok(f"Switched to: {topic}")
        return CommandResult.error(f"Session not found: {value}")

    @router.callback("sess_del")
    async def cb_session_delete_confirm(ctx: ChatContext, value: str) -> CommandResult:
        """Ask for delete confirmation."""
        if not value:
            return CommandResult.error("Missing session ID.")

        buttons = InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("Yes, delete", callback_data=f"sess_rm:{value[:52]}"),
                    InlineKeyboardButton("Cancel", callback_data="sess_pg:0"),
                ]
            ]
        )

        return CommandResult.ok(
            f"Delete session <code>{value[:20]}</code>?\n\nThis cannot be undone.",
            reply_markup=buttons,
        )

    @router.callback("sess_rm")
    async def cb_session_delete(ctx: ChatContext, value: str) -> CommandResult:
        """Actually delete a session and return to list."""
        if not value:
            return CommandResult.error("Missing session ID.")

        if delete_session(value):
            return _render_sessions_page(0)
        return CommandResult.error(f"Session not found: {value}")
