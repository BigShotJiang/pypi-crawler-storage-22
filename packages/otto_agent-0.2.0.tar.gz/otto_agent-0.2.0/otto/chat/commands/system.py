"""System commands: /help /status /restart /jobs /schedules /heartbeat + callbacks"""

from __future__ import annotations

from typing import TYPE_CHECKING
from . import CommandResult, CommandRouter

if TYPE_CHECKING:
    from ..types import ChatContext


def _cron_to_human(expr: str) -> str:
    """Convert a cron expression to a human-readable description."""
    parts = expr.strip().split()
    if len(parts) != 5:
        return expr
    mn, hr, dom, mon, dow = parts
    # Common patterns
    if expr == "* * * * *":
        return "Every minute"
    if mn != "*" and hr != "*" and dom == "*" and mon == "*" and dow == "*":
        return f"Daily at {hr.zfill(2)}:{mn.zfill(2)}"
    if mn != "*" and hr != "*" and dom == "*" and mon == "*" and dow != "*":
        day_names = {
            "0": "Sun",
            "1": "Mon",
            "2": "Tue",
            "3": "Wed",
            "4": "Thu",
            "5": "Fri",
            "6": "Sat",
            "7": "Sun",
        }
        days = ",".join(day_names.get(d.strip(), d.strip()) for d in dow.split(","))
        return f"{days} at {hr.zfill(2)}:{mn.zfill(2)}"
    if mn.startswith("*/"):
        return f"Every {mn[2:]} min"
    if mn != "*" and hr == "*":
        return f"Hourly at :{mn.zfill(2)}"
    return expr


def _next_cron_run(expr: str) -> str:
    """Calculate next run time from a cron expression."""
    try:
        from datetime import datetime

        from croniter import croniter

        now = datetime.now()
        cron = croniter(expr, now)
        nxt = cron.get_next(datetime)
        diff = nxt - now
        secs = int(diff.total_seconds())
        if secs < 60:
            return "in <1m"
        if secs < 3600:
            return f"in {secs // 60}m"
        if secs < 86400:
            h = secs // 3600
            m = (secs % 3600) // 60
            return f"in {h}h{m}m" if m else f"in {h}h"
        return f"in {secs // 86400}d"
    except Exception:
        return ""


def register(router: CommandRouter) -> None:
    from otto import get_current_session, memory_stats
    from otto.backends import get_active_backend_name, list_backends

    @router.command("help")
    async def cmd_help(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Show interactive help menu with categories."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        text = (
            "<b>Otto Commands</b>\n\n"
            "<b>Conversations</b> — Sessions, new, stop\n"
            "<b>AI &amp; Agents</b> — Backend, thinking, agents\n"
            "<b>Memory &amp; Tasks</b> — Memory, tasks, polls, jobs\n"
            "<b>MCP &amp; Tools</b> — MCP, activity, audit, pause\n"
            "<b>System</b> — Status, VTT, reindex, restart\n\n"
            "<i>Tap a category or quick-launch below.</i>"
        )

        buttons = [
            [
                InlineKeyboardButton("Conversations", callback_data="help_cat:conv"),
                InlineKeyboardButton("AI & Agents", callback_data="help_cat:ai"),
            ],
            [
                InlineKeyboardButton("Memory & Tasks", callback_data="help_cat:mem"),
                InlineKeyboardButton("MCP & Tools", callback_data="help_cat:tools"),
                InlineKeyboardButton("System", callback_data="help_cat:sys"),
            ],
            [
                InlineKeyboardButton("/new", callback_data="help_run:new"),
                InlineKeyboardButton("/status", callback_data="help_run:status"),
                InlineKeyboardButton("/agents", callback_data="help_run:agents"),
            ],
        ]

        return CommandResult.ok(text, reply_markup=InlineKeyboardMarkup(buttons))

    @router.command("status")
    async def cmd_status(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Show system status with live data and quick actions."""
        import platform as _platform

        from otto.backends import get_backend_model
        from otto.config import get_setting
        from otto.daemon import format_uptime
        from otto.daemon import status as service_status

        session = get_current_session(chat_id=ctx.message.chat_id)
        session_id = session.get("id", "none")[:20]
        session_topic = session.get("topic", "")
        msg_count = len(session.get("messages", []))
        active_backend = get_active_backend_name()
        current_model = get_backend_model(active_backend)
        mem = memory_stats()
        thinking_on = get_setting("agent.thinking.enabled", True)

        # Uptime
        info = service_status("telegram-bot")
        uptime_str = format_uptime(info.uptime_seconds)

        # Agent counts
        agent_active = 0
        agent_pending = 0
        try:
            from otto.jobs.queue import JobQueue

            q = JobQueue()
            jobs = q.list(job_type="agent", limit=100)
            for j in jobs:
                st = j.get("status")
                if st == "running":
                    agent_active += 1
                elif st == "pending":
                    agent_pending += 1
        except Exception:
            pass

        # Build status text
        lines = ["<b>Otto Status</b>\n"]

        # System
        lines.append("<b>System</b>")
        lines.append(f"  Uptime: {uptime_str}")
        lines.append(f"  Platform: {_platform.system()} {_platform.release()}")

        # Backend
        backend_str = active_backend
        if current_model:
            backend_str = f"{active_backend} ({current_model})"
        lines.append("\n<b>Backend</b>")
        lines.append(f"  {backend_str}")
        lines.append(f"  Thinking: {'ON' if thinking_on else 'OFF'}")

        # Session
        lines.append("\n<b>Session</b>")
        lines.append(f"  ID: <code>{session_id}</code>")
        if session_topic:
            lines.append(f"  Topic: {session_topic}")
        lines.append(f"  Messages: {msg_count}")

        # Agents (only if any exist)
        if agent_active or agent_pending:
            lines.append("\n<b>Agents</b>")
            parts = []
            if agent_active:
                parts.append(f"{agent_active} running")
            if agent_pending:
                parts.append(f"{agent_pending} pending")
            lines.append(f"  {', '.join(parts)}")

        # Memory
        lines.append("\n<b>Memory</b>")
        lines.append(f"  {mem.get('total_chunks', 0)} chunks indexed")

        text = "\n".join(lines)

        # Quick action buttons
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        buttons = [
            [
                InlineKeyboardButton("Switch Backend", callback_data="status_action:backend"),
                InlineKeyboardButton("New Session", callback_data="status_action:new"),
            ],
            [
                InlineKeyboardButton("Refresh", callback_data="status_action:refresh"),
            ],
        ]
        # Add Agents button only if agents exist
        if agent_active or agent_pending:
            buttons[1].append(InlineKeyboardButton("Agents", callback_data="status_action:agents"))

        return CommandResult.ok(text, reply_markup=InlineKeyboardMarkup(buttons))

    @router.command("restart")
    async def cmd_restart(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Request bot restart (confirmation needed on rich platforms)."""
        return CommandResult.confirm(
            "Restart Otto?\n\nThis will respawn the bot process. Back in a few seconds.",
            handler="restart",
        )

    @router.command("schedules")
    async def cmd_schedules(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Show dynamic schedules created by agents."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        from otto import schedule_state, schedule_store

        try:
            schedules = schedule_store.list_schedules(include_disabled=False)
        except Exception as e:
            return CommandResult.error(f"Error loading schedules: {e}")

        if not schedules:
            return CommandResult.ok(
                "<b>Schedules</b>\n\n"
                "No active schedules.\n\n"
                "Ask me to schedule something:\n"
                '<i>"Remind me to check email in 2 minutes"</i>\n'
                '<i>"Search HN for AI news every day at 9am"</i>'
            )

        lines = [f"<b>Schedules</b> ({len(schedules)} active)\n"]
        buttons: list[list[InlineKeyboardButton]] = []

        for sched in schedules:
            sid = sched["id"]
            name = (sched.get("name") or "")[:40]
            stype = sched.get("schedule_type", "once")

            if stype == "recurring" and sched.get("cron_expr"):
                human = _cron_to_human(sched["cron_expr"])
                nxt = _next_cron_run(sched["cron_expr"])
                type_str = f"🔄 {human} ({nxt})"
            elif sched.get("run_at"):
                try:
                    from datetime import datetime as dt

                    target = dt.fromisoformat(sched["run_at"])
                    diff = target - dt.now()
                    secs = int(diff.total_seconds())
                    if secs <= 0:
                        nxt = "due now"
                    elif secs < 60:
                        nxt = f"in {secs}s"
                    elif secs < 3600:
                        nxt = f"in {secs // 60}m"
                    elif secs < 86400:
                        h = secs // 3600
                        m = (secs % 3600) // 60
                        nxt = f"in {h}h{m}m" if m else f"in {h}h"
                    else:
                        nxt = f"in {secs // 86400}d"
                except Exception:
                    nxt = ""
                type_str = f"⏱ One-shot ({nxt})" if nxt else "⏱ One-shot"
            else:
                type_str = "⏱ One-shot"

            # Load run state
            state = schedule_state.load(sid)
            run_count = state.get("run_count", 0)
            last_status = state.get("last_status", "")
            status_str = ""
            if run_count:
                icon = (
                    "✓" if last_status == "completed" else "✗" if last_status == "failed" else "?"
                )
                status_str = f" | {icon} {run_count} runs"

            lines.append(f"<b>{name}</b>")
            lines.append(f"  {type_str}{status_str}")
            lines.append(f"  <code>{sid}</code>")
            lines.append("")

            short_id = sid[:20]
            row = [
                InlineKeyboardButton("Cancel", callback_data=f"sched_cancel:{short_id}"),
                InlineKeyboardButton("Run Now", callback_data=f"sched_run:{short_id}"),
            ]
            buttons.append(row)

        buttons.append([InlineKeyboardButton("Refresh", callback_data="sched_ref:1")])

        return CommandResult.ok(
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup(buttons),
        )

    @router.command("jobs")
    async def cmd_jobs(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Show scheduled jobs with human-readable schedules and actions."""
        import yaml
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        from otto.paths import BRAINFILE

        no_jobs_msg = (
            "<b>Scheduled Jobs</b>\n\n"
            "No jobs configured.\n\n"
            "Add jobs to <code>~/.otto/brainfile.md</code>:\n"
            "<code>---\njobs:\n"
            "  - id: backup\n"
            '    schedule: "0 2 * * *"\n'
            "    task: run backup\n"
            "---</code>"
        )

        if not BRAINFILE.exists():
            return CommandResult.ok(no_jobs_msg)

        try:
            content = BRAINFILE.read_text()
            if not content.startswith("---"):
                return CommandResult.ok(no_jobs_msg)

            end = content.find("\n---", 3)
            if end == -1:
                return CommandResult.ok(no_jobs_msg)

            data = yaml.safe_load(content[4:end]) or {}
            jobs = data.get("jobs", [])
        except Exception as e:
            return CommandResult.error(f"Error reading jobs: {e}")

        if not jobs:
            return CommandResult.ok(no_jobs_msg)

        enabled_count = sum(1 for j in jobs if j.get("enabled", True))
        lines = [f"<b>Scheduled Jobs</b>  ({len(jobs)} jobs, {enabled_count} enabled)\n"]

        buttons = []
        for j in jobs:
            enabled = j.get("enabled", True)
            job_id = j.get("id", "?")
            schedule = j.get("schedule", "?")
            task = j.get("task", "")

            icon = "ON" if enabled else "OFF"
            human = _cron_to_human(schedule)
            nxt = _next_cron_run(schedule) if enabled else "paused"

            lines.append(f"{'>' if enabled else '  '} <b>{job_id}</b>  [{icon}]")
            lines.append(f"    {human}  ({nxt})")
            if task:
                lines.append(f"    <i>{task[:60]}</i>")
            lines.append("")

            # Per-job action buttons
            toggle_label = "Disable" if enabled else "Enable"
            toggle_icon = "OFF" if enabled else "ON"
            row = [
                InlineKeyboardButton(
                    f"{toggle_icon} {toggle_label}", callback_data=f"job_tgl:{job_id}"
                ),
                InlineKeyboardButton("Run Now", callback_data=f"job_run:{job_id}"),
            ]
            buttons.append(row)

        keyboard = InlineKeyboardMarkup(buttons)
        return CommandResult.ok("\n".join(lines), reply_markup=keyboard)

    @router.command("heartbeat", aliases=["hb"])
    async def cmd_heartbeat(ctx: ChatContext, args: list[str]) -> CommandResult:
        """Show heartbeat monitoring status and managed agents."""
        try:
            from otto.heartbeat.integration import get_heartbeat
        except ImportError:
            return CommandResult.error("Heartbeat module not available")

        hb = get_heartbeat()
        status = hb.get_status()
        config = status["config"]
        agents = status["agents"]
        retries = status["retries"]

        lines = ["<b>Heartbeat Monitor</b>\n"]

        # Daemon status
        running = "🟢 Running" if status["running"] else "🔴 Stopped"
        lines.append(f"<b>Daemon:</b> {running}")
        lines.append(
            f"<b>Config:</b> retry={'ON' if config['auto_retry'] else 'OFF'}, "
            f"max={config['max_retries']}"
        )

        # Agent summary
        total = agents.get("total", 0)
        if total:
            lines.append(f"\n<b>Agents</b> ({total} tracked)")
            parts = []
            if agents.get("running"):
                parts.append(f"🏃 {agents['running']} running")
            if agents.get("completed"):
                parts.append(f"✅ {agents['completed']} completed")
            if agents.get("failed"):
                parts.append(f"❌ {agents['failed']} failed")
            if agents.get("retrying"):
                parts.append(f"🔄 {agents['retrying']} retrying")
            if agents.get("pending"):
                parts.append(f"⏳ {agents['pending']} pending")
            lines.append("  " + ", ".join(parts))
        else:
            lines.append("\nNo agents being tracked.")

        # Retry info
        if retries.get("pending_retries") or retries.get("agents_retrying"):
            lines.append("\n<b>Retries</b>")
            if retries.get("pending_retries"):
                lines.append(f"  ⏱ {retries['pending_retries']} pending")
            if retries.get("retries_exhausted"):
                lines.append(f"  ⚠️ {retries['retries_exhausted']} exhausted")

        # Subcommands
        if args:
            sub = args[0].lower()
            if sub == "start":
                from otto.heartbeat.integration import start_heartbeat

                await start_heartbeat()
                return CommandResult.ok("✅ Heartbeat daemon started")
            elif sub == "stop":
                from otto.heartbeat.integration import stop_heartbeat

                await stop_heartbeat()
                return CommandResult.ok("🛑 Heartbeat daemon stopped")
            elif sub == "clear":
                state = hb.state_manager.load_state()
                count = len(state.agents)
                state.agents.clear()
                hb.state_manager.save_state(state)
                return CommandResult.ok(f"🧹 Cleared {count} agent(s) from heartbeat state")

        return CommandResult.ok("\n".join(lines))

    # -------------------------------------------------------------------------
    # Callback handlers
    # -------------------------------------------------------------------------

    @router.callback("restart")
    async def cb_restart(ctx: ChatContext, value: str) -> CommandResult:
        """Handle restart confirmation."""
        if value == "yes":
            # Platform will handle the actual restart
            return CommandResult.ok(
                "Restarting...",
                data={"action": "do_restart"},
            )
        return CommandResult.ok("Restart cancelled.")

    @router.callback("status_action")
    async def cb_status_action(ctx: ChatContext, value: str) -> CommandResult:
        """Route status quick actions to appropriate commands."""
        # Use the router to dispatch cross-module commands
        from . import get_command_router

        r = get_command_router()
        if value == "refresh":
            return await cmd_status(ctx, [])
        elif value == "backend":
            return await r.handle(ctx, "/backend")  # type: ignore[return-value]
        elif value == "new":
            return await r.handle(ctx, "/new")  # type: ignore[return-value]
        elif value == "agents":
            return await r.handle(ctx, "/agents")  # type: ignore[return-value]
        return CommandResult.error(f"Unknown status action: {value}")

    @router.callback("help_cat")
    async def cb_help_cat(ctx: ChatContext, value: str) -> CommandResult:
        """Show commands in a help category."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        categories = {
            "conv": (
                "<b>Conversations</b>\n\n"
                "/new [topic] — Start fresh session\n"
                "/sessions — List/switch sessions\n"
                "/stop — Cancel current response"
            ),
            "ai": (
                "<b>AI &amp; Agents</b>\n\n"
                "/backend [name] — Show/switch backend\n"
                "/thinking — Toggle extended thinking\n"
                "/agents [limit] — List sub-agents\n"
                "/agents cancel &lt;id|all&gt; — Cancel agents"
            ),
            "mem": (
                "<b>Memory &amp; Tasks</b>\n\n"
                "/memory [query] — Search memory\n"
                "/tasks — Task checklists\n"
                "/poll — Create or view polls\n"
                "/jobs — Brainfile scheduled jobs"
            ),
            "tools": (
                "<b>MCP &amp; Tools</b>\n\n"
                "/mcp [subcmd] — Manage MCP servers\n"
                "/activity — Tool activity dashboard\n"
                "/audit [subcmd] — Query audit log\n"
                "/pause &lt;server&gt; — Pause/resume MCP server"
            ),
            "sys": (
                "<b>System</b>\n\n"
                "/status — Live system status\n"
                "/heartbeat — Agent monitoring status\n"
                "/vtt — Toggle voice-to-text\n"
                "/reindex — Rebuild memory index\n"
                "/restart — Restart Otto safely\n"
                "/schedules — Dynamic agent schedules"
            ),
        }

        text = categories.get(value)
        if not text:
            return CommandResult.error(f"Unknown category: {value}")

        back_btn = InlineKeyboardButton("« Back", callback_data="help_back:main")
        buttons = [[back_btn]]

        return CommandResult.ok(text, reply_markup=InlineKeyboardMarkup(buttons))

    @router.callback("help_back")
    async def cb_help_back(ctx: ChatContext, value: str) -> CommandResult:
        """Return to main help menu."""
        return await cmd_help(ctx, [])

    @router.callback("help_run")
    async def cb_help_run(ctx: ChatContext, value: str) -> CommandResult:
        """Execute a command directly from help menu."""
        from . import get_command_router

        r = get_command_router()
        if value == "status":
            return await cmd_status(ctx, [])
        # Dispatch cross-module commands through the router
        result = await r.handle(ctx, f"/{value}")
        if result is not None:
            return result
        return CommandResult.error(f"Unknown command: {value}")

    @router.callback("sched_cancel")
    async def cb_sched_cancel(ctx: ChatContext, value: str) -> CommandResult:
        """Cancel a dynamic schedule."""
        from otto import schedule_state, schedule_store

        if not value:
            return CommandResult.error("Missing schedule ID.")

        sched = schedule_store.get_schedule(value)
        if not sched:
            return CommandResult.error(f"Schedule not found: {value}")

        schedule_store.disable_schedule(value)
        state = schedule_state.load(value)
        state["disabled"] = True
        schedule_state.save(value, state)

        return await cmd_schedules(ctx, [])

    @router.callback("sched_run")
    async def cb_sched_run(ctx: ChatContext, value: str) -> CommandResult:
        """Trigger immediate execution of a dynamic schedule."""
        from otto import schedule_store

        if not value:
            return CommandResult.error("Missing schedule ID.")

        sched = schedule_store.get_schedule(value)
        if not sched:
            return CommandResult.error(f"Schedule not found: {value}")

        prompt = sched.get("prompt", "")
        if not prompt:
            return CommandResult.error("Schedule has no prompt.")

        return CommandResult.ok(
            f"Running schedule <b>{sched.get('name', value)[:40]}</b>...\n\n<i>{prompt[:100]}</i>",
            data={"run_job": value, "prompt": prompt},
        )

    @router.callback("sched_ref")
    async def cb_sched_refresh(ctx: ChatContext, value: str) -> CommandResult:
        """Refresh schedules view."""
        return await cmd_schedules(ctx, [])

    @router.callback("job_tgl")
    async def cb_job_toggle(ctx: ChatContext, value: str) -> CommandResult:
        """Toggle a job's enabled state."""
        import yaml

        from otto.paths import BRAINFILE

        job_id = value

        try:
            content = BRAINFILE.read_text()
            if not content.startswith("---"):
                return CommandResult.error("No jobs in brainfile.")

            end = content.find("\n---", 3)
            if end == -1:
                return CommandResult.error("Invalid brainfile format.")

            data = yaml.safe_load(content[4:end]) or {}
            markdown = content[end + 4 :].strip()
            jobs = data.get("jobs", [])

            found = False
            new_state = False
            for j in jobs:
                if j.get("id") == job_id:
                    current = j.get("enabled", True)
                    new_state = not current
                    j["enabled"] = new_state
                    found = True
                    break

            if not found:
                return CommandResult.error(f"Job not found: {job_id}")

            new_content = "---\n"
            new_content += yaml.dump(
                data, default_flow_style=False, allow_unicode=True, sort_keys=False
            )
            new_content += "---\n\n"
            new_content += markdown
            BRAINFILE.write_text(new_content)

            status = "enabled" if new_state else "disabled"
            return CommandResult.ok(f"Job <b>{job_id}</b> {status}.")
        except Exception as e:
            return CommandResult.error(f"Failed: {e}")

    @router.callback("job_run")
    async def cb_job_run(ctx: ChatContext, value: str) -> CommandResult:
        """Trigger immediate execution of a job."""
        import yaml

        from otto.paths import BRAINFILE

        job_id = value

        try:
            content = BRAINFILE.read_text()
            if not content.startswith("---"):
                return CommandResult.error("No jobs in brainfile.")

            end = content.find("\n---", 3)
            if end == -1:
                return CommandResult.error("Invalid brainfile format.")

            data = yaml.safe_load(content[4:end]) or {}
            jobs = data.get("jobs", [])

            target = None
            for j in jobs:
                if j.get("id") == job_id:
                    target = j
                    break

            if not target:
                return CommandResult.error(f"Job not found: {job_id}")

            task_prompt = target.get("task", "")
            if not task_prompt:
                return CommandResult.error(f"Job {job_id} has no task defined.")

            # Queue the job as a message for the pipeline to process
            return CommandResult.ok(
                f"Running job <b>{job_id}</b>...\n\n<i>{task_prompt[:100]}</i>",
                data={"run_job": job_id, "prompt": task_prompt},
            )
        except Exception as e:
            return CommandResult.error(f"Failed: {e}")
