"""
Telegram platform implementation.
"""

from .callbacks import TelegramCallbackHandler
from .core import ChatCore
from .platform import TelegramPlatform
from .renderer import TelegramRenderer, render_result
from .security import (
    Permission,
    SecurityAdapter,
    SecurityContext,
    SecurityLevel,
)
from .types import ChatContext, ChatMessage, ChatPlatform, PlatformCapabilities
from .ui import confirm, choice, menu, grid, parse_callback

__all__ = [
    # Platform
    "TelegramPlatform",
    "TelegramRenderer",
    "TelegramCallbackHandler",
    "render_result",
    # Core
    "ChatCore",
    # Types
    "ChatPlatform",
    "PlatformCapabilities",
    "ChatContext",
    "ChatMessage",
    # Security
    "SecurityAdapter",
    "SecurityContext",
    "Permission",
    "SecurityLevel",
    # UI helpers
    "confirm",
    "choice",
    "menu",
    "grid",
    "parse_callback",
]
