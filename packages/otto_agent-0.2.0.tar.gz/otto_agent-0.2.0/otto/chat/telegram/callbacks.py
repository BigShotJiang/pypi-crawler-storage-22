"""
Telegram callback handler.

Routes button callbacks back to the command system and handles
platform-specific callback operations (VTT setup, restart, etc.)
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

from telegram import Update
from telegram.ext import ContextTypes

from ..commands import CommandResult, get_command_router
from .renderer import TelegramRenderer
from .types import ChatContext, ChatMessage

if TYPE_CHECKING:
    from .platform import TelegramPlatform

log = logging.getLogger(__name__)


class TelegramCallbackHandler:
    """Routes Telegram button callbacks to command handlers."""

    def __init__(self, platform: TelegramPlatform):
        self.platform = platform
        self.renderer = TelegramRenderer()

    async def handle(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """
        Handle a callback query from an inline keyboard button.

        Parses callback_data and routes to the appropriate handler.
        """
        query = update.callback_query
        if not query:
            return

        data = query.data or ""
        log.info("Callback: %s from user %s", data, update.effective_user.id)

        # Parse action and value from callback_data
        # Preferred format: "{action}:{value}" (supports underscores in action names)
        # Legacy format: "{action}_{value}"
        if ":" in data:
            action, value = data.split(":", 1)
        else:
            parts = data.split("_", 1)
            action = parts[0]
            value = parts[1] if len(parts) > 1 else ""

        # Create a minimal context for permission checks and callbacks.
        chat_message = ChatMessage(
            text=data,
            user_id=str(update.effective_user.id),
            user_name=update.effective_user.username or update.effective_user.first_name or "User",
            chat_id=str(query.message.chat_id),
            platform="telegram",
            raw_message=query,
            message_id=str(query.message.message_id) if query.message else None,
        )
        ctx = ChatContext(message=chat_message, platform=self.platform)
        ctx.security = self.platform.security.create_context(
            user_id=chat_message.user_id,
            user_name=chat_message.user_name,
            platform=chat_message.platform,
        )

        if not self.platform._is_authorized(ctx):
            await query.answer("Access denied. This bot is private.", show_alert=True)
            return

        await query.answer()

        # Check for special platform-specific handlers
        if action in self._special_handlers:
            result = await self._special_handlers[action](self, query, context, value)
        else:
            # Route through command router
            router = get_command_router()
            result = await router.handle_callback(ctx, action, value)

            # If callback is unknown, treat it as user input (Approach A)
            # This allows buttons to act as quick-reply shortcuts
            log.info(
                "Callback result: success=%s, text=%r",
                result.success,
                result.text[:100] if result.text else None,
            )
            if not result.success and "Unknown callback" in result.text:
                # Send the callback data as a message to continue conversation
                log.info("Routing unknown callback as message: %s", data)
                await self._route_as_message(query, context, data)
                return

        # Special handlers may handle delivery themselves.
        if result is None:
            return

        # Handle the result
        await self._handle_result(query, context, result)

    async def _handle_result(
        self, query, context: ContextTypes.DEFAULT_TYPE, result: CommandResult
    ) -> None:
        """Process the result and update the message."""
        from telegram.constants import ParseMode

        text, markup = self.renderer.render(result)

        # Check for special actions in result data
        if result.data and isinstance(result.data, dict):
            action = result.data.get("action")
            if action == "do_restart":
                await self._do_restart(query, context)
                return

        try:
            await query.edit_message_text(
                text=text,
                parse_mode=ParseMode.HTML,
                reply_markup=markup,
            )
        except Exception as e:
            # Message might be unchanged
            log.debug("Could not edit message: %s", e)
            try:
                # Try without HTML if parsing failed
                await query.edit_message_text(text=text, reply_markup=markup)
            except Exception:
                pass

    # -------------------------------------------------------------------------
    # Special platform-specific handlers
    # -------------------------------------------------------------------------

    async def _handle_vtt_enable(
        self, query, context: ContextTypes.DEFAULT_TYPE, value: str
    ) -> CommandResult:
        """Handle VTT enable with model download."""
        if value == "enable_download":
            return await self._vtt_enable_and_download(query, context)
        elif value == "enable":
            return await self._vtt_enable(query, context)
        elif value == "download":
            return await self._vtt_download(query, context)
        elif value == "skip":
            return CommandResult.ok("VTT remains disabled.")
        else:
            # Route to standard callback
            router = get_command_router()
            return await router.handle_callback(None, "vtt_toggle", value)

    async def _vtt_enable(self, query, context) -> CommandResult:
        """Enable VTT without downloading."""
        try:
            from otto_tools.vtt import load_config, save_config

            config = load_config()
            config["enabled"] = True
            save_config(config)
            return CommandResult.ok("Voice-to-Text enabled.\n\nSend a voice message to transcribe.")
        except Exception as e:
            return CommandResult.error(f"Error enabling VTT: {e}")

    async def _vtt_enable_and_download(self, query, context) -> CommandResult:
        """Enable VTT and download the model."""
        from telegram.constants import ParseMode

        # Enable VTT first
        try:
            from otto_tools.vtt import load_config, save_config

            config = load_config()
            config["enabled"] = True
            save_config(config)
        except Exception as e:
            return CommandResult.error(f"Error enabling VTT: {e}")

        # Update message to show progress
        await query.edit_message_text(
            "<b>Setting up Voice-to-Text</b>\n\nStep 1/2: Installing faster-whisper (if needed)...",
            parse_mode=ParseMode.HTML,
        )

        try:
            from otto_tools.vtt import _ensure_faster_whisper_installed, get_transcriber

            installed = await asyncio.to_thread(_ensure_faster_whisper_installed, auto_install=True)
            if not installed:
                return CommandResult.error(
                    "Couldn't install faster-whisper automatically.\n"
                    "Try manually:\n"
                    "uv pip install -U faster-whisper"
                )

            await query.edit_message_text(
                "<b>Setting up Voice-to-Text</b>\n\n"
                "Step 2/2: Downloading Whisper model (one-time)...\n"
                "<i>This may take several minutes.</i>",
                parse_mode=ParseMode.HTML,
            )

            transcriber = get_transcriber()
            await asyncio.to_thread(transcriber._load_model)

            return CommandResult.ok("Voice-to-Text ready!\n\nSend a voice message to transcribe.")
        except Exception as e:
            return CommandResult.error(f"Setup failed: {e}")

    async def _vtt_download(self, query, context) -> CommandResult:
        """Download VTT model only."""
        from telegram.constants import ParseMode

        await query.edit_message_text(
            "<b>Downloading Whisper model</b>\n\n<i>This may take several minutes...</i>",
            parse_mode=ParseMode.HTML,
        )

        try:
            from otto_tools.vtt import _ensure_faster_whisper_installed, get_transcriber

            installed = await asyncio.to_thread(_ensure_faster_whisper_installed, auto_install=True)
            if not installed:
                return CommandResult.error("Couldn't install faster-whisper")

            transcriber = get_transcriber()
            await asyncio.to_thread(transcriber._load_model)

            return CommandResult.ok("Model downloaded!\n\nSend a voice message to transcribe.")
        except Exception as e:
            return CommandResult.error(f"Download failed: {e}")

    async def _do_restart(self, query, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Execute the actual bot restart using graceful restart mechanism."""
        import sys

        from telegram.constants import ParseMode

        from otto.daemon import schedule_restart_notification, start

        # Get user info for notification
        user_id = str(query.from_user.id) if query.from_user else None
        user_name = (
            query.from_user.username or query.from_user.first_name if query.from_user else None
        )
        chat_id = str(query.message.chat_id) if query.message else None

        await query.edit_message_text(
            "<b>Restarting Otto...</b>\n\n"
            "Spawning new process and shutting down gracefully.\n"
            "I'll message you when I'm back online.",
            parse_mode=ParseMode.HTML,
        )

        # Schedule notification for when bot comes back
        if chat_id:
            schedule_restart_notification(
                "telegram-bot",
                chat_id=chat_id,
                user_id=user_id,
                user_name=user_name,
                reason="graceful_restart",
            )

        # Start new bot process using daemon.py
        bot_command = [sys.executable, "-m", "otto.services.telegram"]

        try:
            ok, msg = start("telegram-bot", bot_command, check_running=False)
            if not ok:
                log.error("Failed to start new bot: %s", msg)
                await query.edit_message_text(f"Restart failed: {msg}")
                return
            log.info("Started new bot process: %s", msg)
        except Exception as e:
            log.error("Failed to spawn new process: %s", e)
            await query.edit_message_text(f"Restart failed: {e}")
            return

        # Give the new process a moment to initialize
        await asyncio.sleep(2)

        # Stop current instance - new process will take over
        log.info("Stopping current bot instance for restart")
        context.application.stop_running()

    async def _handle_task_add(self, query, context: ContextTypes.DEFAULT_TYPE, value: str):
        """Prompt the user to send a new task line for a checklist."""
        checklist_id = value
        if not checklist_id:
            await query.message.reply_text("No checklist ID.")
            return None

        # Persist pending add state in Telegram's per-user storage.
        try:
            message_id = query.message.message_id if query.message else None
            chat_id = query.message.chat_id if query.message else None
            context.user_data["awaiting_task_add"] = {
                "checklist_id": checklist_id,
                "message_id": message_id,
                "chat_id": chat_id,
            }
        except Exception:
            context.user_data["awaiting_task_add"] = {"checklist_id": checklist_id}

        await query.message.reply_text(
            "<b>Add task</b>\n\nSend the new task text as a message.",
            parse_mode="HTML",
        )
        return None

    async def _route_as_message(self, query, context: ContextTypes.DEFAULT_TYPE, data: str) -> None:
        """
        Route a callback as if it were a text message.

        This enables Approach A: button taps become user messages that
        continue the conversation naturally.
        """
        import asyncio

        from telegram.constants import ParseMode

        # Remove the buttons from the original message to indicate selection
        try:
            original_text = query.message.text or ""
            await query.edit_message_text(
                text=f"{original_text}\n\n<i>Selected: {data}</i>",
                parse_mode=ParseMode.HTML,
                reply_markup=None,  # Remove buttons
            )
        except Exception as e:
            log.debug("Could not update button message: %s", e)

        # Create context as if user sent this message
        chat_message = ChatMessage(
            text=data,
            user_id=str(query.from_user.id) if query.from_user else "unknown",
            user_name=query.from_user.username or query.from_user.first_name
            if query.from_user
            else "User",
            chat_id=str(query.message.chat_id),
            platform="telegram",
            raw_message=query.message,
        )
        ctx = ChatContext(message=chat_message, platform=self.platform)
        ctx.security = self.platform.security.create_context(
            user_id=chat_message.user_id,
            user_name=chat_message.user_name,
            platform=chat_message.platform,
        )

        # Show typing indicator while processing
        stop = asyncio.Event()
        typing_task = asyncio.create_task(self.platform._keep_typing(query.message.chat_id, stop))

        try:
            # Process through the chat core as a normal message
            await self.platform.core.process_with_agent(ctx)
        finally:
            stop.set()
            await typing_task

    async def _handle_gateway_permit(
        self, query, context: ContextTypes.DEFAULT_TYPE, value: str
    ) -> CommandResult | None:
        """Handle gateway permission approval/denial buttons."""
        from otto.gateway import TelegramPermissionCallback

        # value is "{request_id}:{allow|deny}"
        parts = value.split(":", 1)
        if len(parts) != 2:
            return CommandResult.error("Invalid permission callback format")

        request_id, decision = parts
        allowed = decision == "allow"

        resolved = TelegramPermissionCallback.resolve(request_id, allowed)

        if resolved:
            icon = "✅" if allowed else "❌"
            label = "Allowed" if allowed else "Denied"
            return CommandResult.ok(f"{icon} Permission {label}")
        else:
            return CommandResult.ok("⏳ Permission request expired or already resolved")

    async def _handle_sess_new(
        self, query, context: ContextTypes.DEFAULT_TYPE, value: str
    ) -> CommandResult:
        """Handle session new/fork choice from inline buttons."""
        from otto.sessions import fork_session, maybe_auto_title, new_session

        parts = value.split(":", 1)
        mode = (parts[0] if parts else "").strip().lower()
        topic = parts[1].strip() if len(parts) > 1 else None
        topic = topic or None

        if mode == "cancel":
            return CommandResult.ok("Session creation cancelled.")
        if mode not in {"fork", "fresh"}:
            return CommandResult.error("Invalid session creation mode.")

        chat_id = str(query.message.chat_id) if query.message else None

        # Auto-title outgoing session before archiving.
        try:
            await maybe_auto_title(chat_id=chat_id, force=True)
        except Exception:
            pass

        if mode == "fork":
            session = await asyncio.to_thread(fork_session, topic=topic, chat_id=chat_id)
            forked_from = session.get("metadata", {}).get("forked_from", "")
            topic_display = session.get("topic") or "(untitled)"
            message_count = session.get("metadata", {}).get(
                "message_count", len(session.get("messages", []))
            )
            return CommandResult.ok(
                f"<b>Session forked</b>\n\n"
                f"Topic: {topic_display}\n"
                f"Messages carried over: {message_count}\n"
                f"Forked from: <code>{forked_from[:20]}</code>"
            )

        session = await asyncio.to_thread(
            new_session,
            topic=topic,
            archive_current=True,
            chat_id=chat_id,
        )
        topic_display = session.get("topic") or "(no topic)"
        return CommandResult.ok(f"<b>Fresh session started</b>\n\nTopic: {topic_display}")

    # Map of special handlers that bypass the command router
    _special_handlers = {
        "vtt": _handle_vtt_enable,
        "task_add": _handle_task_add,
        "gw_permit": _handle_gateway_permit,
        "sess_new": _handle_sess_new,
    }


def parse_callback_data(data: str) -> tuple[str, str]:
    """
    Parse callback data into action and value.

    Args:
        data: Callback data string (e.g., "backend:pi")

    Returns:
        Tuple of (action, value)
    """
    if ":" in data:
        action, value = data.split(":", 1)
        return action, value
    parts = data.split("_", 1)
    action = parts[0]
    value = parts[1] if len(parts) > 1 else ""
    return action, value
