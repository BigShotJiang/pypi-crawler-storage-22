"""
Core chat logic shared across all platforms.

Handles agent execution, session management, memory search, etc.
Platform-specific code uses ChatCore instead of duplicating this logic.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Literal

from .types import ChatContext, ChatMessage, ChatPlatform
from ..commands import CommandResult, get_command_router

log = logging.getLogger(__name__)


class ChatCore:
    """
    Core chat functionality shared across platforms.

    Usage:
        core = ChatCore(platform)

        # Handle incoming message
        response = await core.handle_message(ctx)

        # Or just run agent
        output, backend = await core.run_agent(prompt)
    """

    MAX_CONV_MESSAGES = 150

    def __init__(self, platform: ChatPlatform):
        self.platform = platform
        self._typing_tasks: dict[str, asyncio.Task] = {}
        self._active_tasks: dict[str, asyncio.Task] = {}  # chat_id -> processing task

    def cancel_request(self, chat_id: str) -> bool:
        """Cancel the active processing task for a chat.

        Returns True if a task was cancelled, False if nothing was running.
        """
        task = self._active_tasks.get(chat_id)
        if task and not task.done():
            task.cancel()
            return True
        return False

    async def handle_message(self, ctx: ChatContext) -> str | CommandResult | None:
        """
        Handle an incoming message.

        Checks for commands first, then processes through agent.
        Returns the response text or CommandResult.
        """
        text = ctx.message.text.strip()

        # Check for commands first
        router = get_command_router()
        if router.is_command(text):
            result = await router.handle(ctx, text)
            if result:
                await self._send_command_result(ctx, result)
                return result

        # Regular message - process through agent
        return await self.process_with_agent(ctx)

    async def handle_callback(self, ctx: ChatContext, action: str, value: str) -> CommandResult:
        """
        Handle a callback (button press, selection) for a command.

        Routes through the command router's callback system.
        """
        router = get_command_router()
        return await router.handle_callback(ctx, action, value)

    async def process_with_agent(self, ctx: ChatContext) -> str:
        """Process message through the AI agent."""
        text = ctx.message.text
        chat_id = ctx.message.chat_id

        # Add to session (scoped to this chat)
        self._add_message("user", text, chat_id=chat_id)

        # Check if we should use streaming
        if self.platform.capabilities.edit_messages:
            coro = self._process_with_streaming(ctx, text)
        else:
            coro = self._process_without_streaming(ctx, text)

        # Wrap in a tracked task so /stop can cancel it
        task = asyncio.current_task()
        self._active_tasks[chat_id] = task
        try:
            return await coro
        except asyncio.CancelledError:
            log.info("Request cancelled for chat %s", chat_id)
            await ctx.reply("(Stopped)")
            return "(Stopped)"
        finally:
            self._active_tasks.pop(chat_id, None)

    async def _process_without_streaming(self, ctx: ChatContext, text: str) -> str:
        """Process message without streaming (original behavior)."""
        chat_id = ctx.message.chat_id

        # Start typing indicator
        typing_task = None
        if self.platform.capabilities.typing_indicator:
            typing_task = asyncio.create_task(self._keep_typing(chat_id))

        try:
            # Run agent
            output, backend = await self.run_agent(text, chat_id=chat_id)

            # Add response to session
            self._add_message("assistant", output, backend=backend, chat_id=chat_id)

            # Send response
            await self._send_response(ctx, output)

            return output

        finally:
            if typing_task:
                typing_task.cancel()
                try:
                    await typing_task
                except asyncio.CancelledError:
                    pass

    async def _process_with_streaming(self, ctx: ChatContext, text: str) -> str:
        """Process message with streaming updates."""
        from otto import get_backend, memory_search_gated
        from otto.backends import get_backend_model, get_orchestration_config
        from otto.paths import get_workdir
        from otto.sessions import get_session_for_prompt
        from otto.streaming import StreamEventType, create_stream_handler

        chat_id = ctx.message.chat_id
        system_prompt = self._get_system_prompt()

        # Build context using centralized session manager
        context_parts: list[str] = []

        session_context = get_session_for_prompt(
            max_messages=self.MAX_CONV_MESSAGES, chat_id=chat_id
        )
        if session_context:
            context_parts.append(
                f"<recent_conversation>\n{session_context}\n</recent_conversation>\n"
            )

        # Auto-search memory on every turn (gated to skip trivial messages)
        # Pass session_context to deduplicate — avoid recalling what's already in recent history
        recalled = memory_search_gated(text, limit=5, exclude_context=session_context)
        if recalled:
            context_parts.append(f"\n{recalled}\n")

        context_parts.append(f"User: {text}")
        full_prompt = "\n".join(context_parts)

        try:
            backend = get_backend()
            orch_config = get_orchestration_config()
            timeout = orch_config.get("default_timeout", 3600)
            model = get_backend_model(backend.config.name)

            # Check if backend supports streaming
            if not backend.supports_streaming():
                log.debug("Backend doesn't support streaming, falling back")
                return await self._process_without_streaming(ctx, text)

            # Create stream handler for this platform
            handler = create_stream_handler(self.platform, ctx.message.chat_id)
            log.debug("Created stream handler for chat %s", ctx.message.chat_id)

            # Stream the response
            event_count = 0
            async for event in backend.run_async_streaming(
                full_prompt, system_prompt, get_workdir(), timeout, model=model
            ):
                event_count += 1
                log.debug("Stream event %d: %s", event_count, event.type.name)
                await handler.handle(event)

                # Break on done or error
                if event.type in (StreamEventType.DONE, StreamEventType.ERROR):
                    log.debug("Stream ended with %s after %d events", event.type.name, event_count)
                    break

            # Finalize (send final message state)
            await handler.finalize()

            # Get final output from buffer
            output = handler.buffer.text or handler.buffer.error or ""

            # Fallback: if streaming handler failed to send any message, send directly
            # This can happen if _send_tool_message() fails (e.g., Telegram API error)
            # Skip fallback if:
            # - show_thinking is False (finalize sent the message)
            # - _final_message_id is set (finalize sent the message)
            # - message_id is set (tool message was sent)
            final_msg_id = getattr(handler, "_final_message_id", None)
            tool_msg_id = getattr(handler, "message_id", None)
            if not handler.show_thinking:
                pass  # finalize() already sent the final message
            elif final_msg_id or tool_msg_id:
                pass  # handler successfully sent a message
            else:
                log.warning("Streaming handler failed to send message, using direct send")
                if output.strip():
                    await self._send_response(ctx, output)

            # Add response to session
            self._add_message("assistant", output, backend=backend.config.name, chat_id=chat_id)

            return output

        except Exception:
            log.exception("Streaming agent error")
            # Fall back to non-streaming on error
            return await self._process_without_streaming(ctx, text)

    async def process_internal_event(self, chat_id: str, prompt: str) -> str:
        """Process an internal event through the agent and notify the user.

        The event prompt (e.g. agent completion with output summary) is stored
        as a system message so it persists in conversation context for future
        turns.  Otto's response is also stored as usual.
        """
        ctx = ChatContext(
            message=ChatMessage(
                text=prompt,
                user_id="system",
                user_name="Otto",
                chat_id=str(chat_id),
                platform=self.platform.name.lower(),
                raw_message=None,
                message_id=None,
            ),
            platform=self.platform,
        )

        typing_task = None
        if self.platform.capabilities.typing_indicator:
            typing_task = asyncio.create_task(self._keep_typing(ctx.message.chat_id))

        try:
            # Store the event context so future turns can reference it
            self._add_message("user", prompt[:3000], chat_id=str(chat_id))
            output, backend = await self.run_agent(prompt, source="internal", chat_id=str(chat_id))
            self._add_message("assistant", output, backend=backend, chat_id=str(chat_id))
            await self._send_response(ctx, output)
            return output
        finally:
            if typing_task:
                typing_task.cancel()
                try:
                    await typing_task
                except asyncio.CancelledError:
                    pass

    async def process_with_image(
        self, ctx: ChatContext, image_path: Path, caption: str | None = None
    ) -> str:
        """Process message with an attached image."""
        chat_id = ctx.message.chat_id
        prompt = caption or "What's in this image?"

        # Add to session
        self._add_message("user", f"{prompt} [image: {image_path.name}]", chat_id=chat_id)

        # Start typing
        typing_task = None
        if self.platform.capabilities.typing_indicator:
            typing_task = asyncio.create_task(self._keep_typing(chat_id))

        try:
            output, backend = await self.run_agent_with_image(prompt, image_path, chat_id=chat_id)
            self._add_message("assistant", output, backend=backend, chat_id=chat_id)
            await self._send_response(ctx, output)
            return output
        finally:
            if typing_task:
                typing_task.cancel()
                try:
                    await typing_task
                except asyncio.CancelledError:
                    pass

    async def process_with_voice(self, ctx: ChatContext, audio_path: Path) -> str | CommandResult:
        """
        Process voice message - transcribe if VTT enabled, otherwise prompt.

        Returns either the response text or a CommandResult prompting to enable VTT.
        """
        try:
            from otto_tools.vtt import is_model_ready
            from otto_tools.vtt import load_config as vtt_load_config

            vtt_config = vtt_load_config()
            vtt_enabled = vtt_config.get("enabled", False)
        except ImportError:
            return CommandResult.error("Voice-to-text not available (otto_tools.vtt not found)")

        if not vtt_enabled:
            return CommandResult(
                text="Voice messages require transcription. Enable VTT?",
                action="confirm",
                next_handler="vtt_enable",
                data={"audio_path": str(audio_path)},
            )

        if not is_model_ready():
            return CommandResult(
                text="Whisper model not downloaded. Download now?",
                action="confirm",
                next_handler="vtt_download",
                data={"audio_path": str(audio_path)},
            )

        # Transcribe
        try:
            from otto_tools.vtt import transcribe_async

            transcript = await transcribe_async(audio_path)

            if not transcript.strip():
                return "(No speech detected)"

            # Process as text
            chat_id = ctx.message.chat_id
            ctx.message.text = f"[Voice transcription] {transcript}"
            self._add_message("user", f"[voice] {transcript[:200]}", chat_id=chat_id)

            # Run agent with the transcription
            output, backend = await self.run_agent(
                f'The user sent a voice message. Transcription: "{transcript}"\n\nRespond naturally to what they said.',
                chat_id=chat_id,
            )
            self._add_message("assistant", output, backend=backend, chat_id=chat_id)
            await self._send_response(ctx, output)
            return output

        except Exception as e:
            log.exception("Transcription failed")
            return CommandResult.error(f"Transcription error: {e}")

    async def run_agent(
        self,
        prompt: str,
        backend_name: str | None = None,
        *,
        source: Literal["user", "internal"] = "user",
        chat_id: str | None = None,
    ) -> tuple[str, str | None]:
        """
        Run the AI agent with context and memory.

        Returns (output, backend_name).
        """
        from otto import get_backend, memory_search_gated
        from otto.paths import get_workdir
        from otto.sessions import get_session_for_prompt

        system_prompt = self._get_system_prompt()

        # Build context using centralized session manager
        context_parts: list[str] = []

        session_context = get_session_for_prompt(
            max_messages=self.MAX_CONV_MESSAGES, chat_id=chat_id
        )
        if session_context:
            context_parts.append(
                f"<recent_conversation>\n{session_context}\n</recent_conversation>\n"
            )

        # Auto-search memory on every turn (gated to skip trivial messages)
        # Pass session_context to deduplicate — avoid recalling what's already in recent history
        if source == "user":
            recalled = memory_search_gated(prompt, limit=5, exclude_context=session_context)
            if recalled:
                context_parts.append(f"\n{recalled}\n")

        speaker = "User" if source == "user" else "System"
        context_parts.append(f"{speaker}: {prompt}")
        full_prompt = "\n".join(context_parts)

        try:
            from otto.backends import get_backend_model, get_orchestration_config

            backend = get_backend(backend_name)
            orch_config = get_orchestration_config()
            timeout = orch_config.get("default_timeout", 3600)

            # Get model spec (e.g., "ollama/qwen3-coder" for dynamic routing)
            model = get_backend_model(backend.config.name)

            result = await backend.run_async(
                full_prompt, system_prompt, get_workdir(), timeout, model=model
            )
            if result.success:
                return result.output, backend.config.name
            return f"Error: {result.error}", None
        except Exception as e:
            log.exception("Agent error")
            return f"Error: {e}", None

    async def run_agent_with_image(
        self,
        prompt: str,
        image_path: Path,
        backend_name: str | None = None,
        *,
        chat_id: str | None = None,
    ) -> tuple[str, str | None]:
        """Run agent with an image file."""
        from otto import get_backend
        from otto.backends import get_orchestration_config
        from otto.paths import get_workdir
        from otto.sessions import get_session_for_prompt

        system_prompt = self._get_system_prompt()

        # Build context using centralized session manager
        context_parts: list[str] = []

        session_context = get_session_for_prompt(
            max_messages=self.MAX_CONV_MESSAGES, chat_id=chat_id
        )
        if session_context:
            context_parts.append(
                f"<recent_conversation>\n{session_context}\n</recent_conversation>\n"
            )

        context_parts.append(f"User: {prompt}")
        context_parts.append(f"\n[The user sent an image. Read the file at: {image_path}]")
        full_prompt = "\n".join(context_parts)

        try:
            from otto.backends import get_backend_model

            backend = get_backend(backend_name)
            orch_config = get_orchestration_config()
            timeout = orch_config.get("default_timeout", 3600)

            # Get model spec for dynamic routing
            model = get_backend_model(backend.config.name)

            result = await backend.run_async(
                full_prompt, system_prompt, get_workdir(), timeout, model=model
            )
            if result.success:
                return result.output, backend.config.name
            return f"Error: {result.error}", None
        except Exception as e:
            log.exception("Agent error with image")
            return f"Error: {e}", None

    def _get_skill_prompt(self) -> str:
        """Get skill prompt XML from otto skills command."""
        import shutil
        import subprocess

        # Use the official otto CLI
        otto_bin = shutil.which("otto")
        if not otto_bin:
            return ""

        try:
            result = subprocess.run(
                [otto_bin, "skills", "prompt"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass
        return ""

    def _get_system_prompt(self) -> str:
        """Build system prompt from brainfile, adapted for platform."""
        import yaml

        from otto.paths import BRAINFILE

        if not BRAINFILE.exists():
            return f"You are Otto, a personal assistant. Responding via {self.platform.name}."

        content = BRAINFILE.read_text()
        if not content.startswith("---"):
            return content

        end = content.find("\n---", 3)
        if end == -1:
            return content

        try:
            data = yaml.safe_load(content[4:end]) or {}
        except yaml.YAMLError:
            return content

        persona = data.get("persona", {})
        context = data.get("context", {})
        rules = data.get("rules", {})

        identity = persona.get("identity", f"You are {persona.get('name', 'Otto')}.")
        capabilities = rules.get("capabilities", "")
        output_handling = rules.get("output_handling", "")

        # Platform-specific formatting instructions
        if self.platform.capabilities.rich_formatting:
            formatting = "Use Telegram HTML only (<b>, <i>, <code>, <pre>). No markdown."
        else:
            formatting = "Use plain text only. No HTML or markdown formatting."

        # Get skill prompts
        skills_prompt = self._get_skill_prompt()
        skills_section = f"\n\nSkills:\n{skills_prompt}" if skills_prompt else ""

        # Format user context properly (not raw Python dict/list)
        user_ctx = context.get("user", {})
        if isinstance(user_ctx, dict):
            user_lines = [f"  {k}: {v}" for k, v in user_ctx.items()]
            user_str = "\n".join(user_lines) if user_lines else "(none)"
        else:
            user_str = str(user_ctx) if user_ctx else "(none)"

        prefs = context.get("preferences", [])
        if isinstance(prefs, list):
            prefs_str = "\n".join(f"  - {p}" for p in prefs) if prefs else "(none)"
        else:
            prefs_str = str(prefs) if prefs else "(none)"

        values = persona.get("values", [])
        values_str = ", ".join(values) if values else "(none)"

        governance = rules.get("governance", "") or "(none)"

        # Otto tools section - always include to guide tool prioritization
        otto_tools_section = """
OTTO TOOLS (prefer these for automation tasks):
- agent_spawn: Launch background agents for complex/long-running tasks
- schedule_task: Schedule delayed or recurring tasks (cron supported)
- pipeline_run: Multi-step workflows with dependencies
- session_new/session_switch/session_list: Conversation management
- memory_recall/memory_remember: Search and store knowledge
- notify_send: Send notifications to user
- send_file/send_buttons: Rich message formatting
- registry_search/registry_install: Discover and install MCP servers
- audit_list/audit_search: Review action history

When a task involves scheduling, background work, or automation, use these Otto tools."""

        return f"""{identity}

Role: {persona.get("role", "personal assistant")}
Style: {persona.get("style", "brief, natural")}
Values: {values_str}

User:
{user_str}

Preferences:
{prefs_str}

Rules: {governance}
Output handling: {output_handling}

Capabilities: {capabilities}{skills_section}
{otto_tools_section}

FORMATTING: {formatting} Be brief.

CONTEXT: You are responding via {self.platform.name}."""

    def _add_message(
        self, role: str, content: str, backend: str | None = None, chat_id: str | None = None
    ) -> None:
        """Add message to session and trigger auto-titling if needed."""
        from otto import add_message as session_add_message

        session_add_message(
            role, content, backend=backend, max_messages=self.MAX_CONV_MESSAGES, chat_id=chat_id
        )

        # Fire-and-forget auto-titling check (only on assistant messages to avoid double-fire)
        if role == "assistant":
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(self._auto_title(chat_id))
            except RuntimeError:
                pass  # No event loop running

    async def _auto_title(self, chat_id: str | None) -> None:
        """Background auto-title generation."""
        try:
            from otto.sessions import maybe_auto_title

            await maybe_auto_title(chat_id=chat_id)
        except Exception as e:
            log.debug("Auto-title skipped: %s", e)

    async def _send_command_result(self, ctx: ChatContext, result: CommandResult) -> None:
        """Send command result to user."""
        text = result.text

        # For rich platforms, could add buttons here
        if self.platform.capabilities.buttons and result.buttons:
            # Platform-specific button handling would go here
            pass

        await self._send_response(ctx, text)

    async def _send_response(self, ctx: ChatContext, text: str) -> None:
        """Send response, chunking if necessary."""
        max_len = self.platform.capabilities.max_message_length

        if len(text) <= max_len:
            await ctx.reply(text)
            return

        # Prefer file attachment over chat spam on platforms that support it.
        if self.platform.capabilities.file_attachments:
            try:
                import uuid

                from otto.paths import OUTPUTS_DIR, ensure_dirs

                ensure_dirs()
                output_id = uuid.uuid4().hex[:8]
                output_file = OUTPUTS_DIR / f"{output_id}.txt"
                output_file.write_text(text, encoding="utf-8")

                try:
                    display_path = str(output_file).replace(str(Path.home()), "~", 1)
                except Exception:
                    display_path = str(output_file)

                await ctx.send_file(output_file, caption=f"Full output: {output_file.name}")
                await ctx.reply(f"Full output: <code>{display_path}</code>")
                return
            except Exception as e:
                log.warning("Failed to send output as file (%s); falling back to chunking", e)

        # Chunk long responses
        chunks = self._chunk_text(text, max_len)
        for chunk in chunks:
            await ctx.reply(chunk)
            await asyncio.sleep(0.1)  # Small delay between chunks

    def _chunk_text(self, text: str, max_len: int) -> list[str]:
        """Split text into chunks at natural boundaries."""
        if len(text) <= max_len:
            return [text]

        chunks = []
        while text:
            if len(text) <= max_len:
                chunks.append(text)
                break

            # Find a good break point
            chunk = text[:max_len]

            # Try to break at newline
            last_newline = chunk.rfind("\n")
            if last_newline > max_len // 2:
                chunk = text[:last_newline]
                text = text[last_newline + 1 :]
            else:
                # Break at space
                last_space = chunk.rfind(" ")
                if last_space > max_len // 2:
                    chunk = text[:last_space]
                    text = text[last_space + 1 :]
                else:
                    # Hard break
                    text = text[max_len:]

            chunks.append(chunk.strip())

        return chunks

    async def _keep_typing(self, chat_id: str) -> None:
        """Keep sending typing indicator."""
        while True:
            try:
                await self.platform.send_typing(chat_id)
                await asyncio.sleep(4.0)
            except asyncio.CancelledError:
                break
            except Exception:
                break
