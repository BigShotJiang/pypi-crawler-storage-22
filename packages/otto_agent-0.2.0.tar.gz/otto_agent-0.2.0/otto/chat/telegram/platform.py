"""
Telegram platform implementation using ChatPlatform abstraction.

Provides full Telegram bot functionality through the unified chat interface.
"""

from __future__ import annotations

import asyncio
import logging
import re
import signal
from datetime import datetime
from pathlib import Path
from typing import Any

from telegram import BotCommand, Update
from telegram.constants import ChatAction, ParseMode
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from .security import SecurityAdapter
from .types import ChatContext, ChatMessage, ChatPlatform, PlatformCapabilities
from ..commands import CommandResult, get_command_router
from .core import ChatCore
from .callbacks import TelegramCallbackHandler
from .renderer import TelegramRenderer

log = logging.getLogger(__name__)

# Bot menu commands — top 10 by usage frequency.
# Removed commands still work as /slash commands; they just don't appear in the menu.
BOT_COMMANDS = [
    BotCommand("new", "New session"),
    BotCommand("status", "System status"),
    BotCommand("backend", "Show/switch AI backend"),
    BotCommand("agents", "Running sub-agents"),
    BotCommand("sessions", "List/switch sessions"),
    BotCommand("memory", "Search memory"),
    BotCommand("tasks", "Task lists"),
    BotCommand("mcp", "Manage MCP servers"),
    BotCommand("jobs", "Scheduled jobs"),
    BotCommand("help", "Commands & reference"),
]


class TelegramPlatform(ChatPlatform):
    """
    Telegram platform using python-telegram-bot.

    Features:
    - Inline keyboards and buttons
    - HTML formatting
    - Voice message transcription
    - Photo analysis
    - Message editing
    - Typing indicators
    - Ephemeral cross-session notifications with reply-to session switching
    """

    name = "Telegram"

    capabilities = PlatformCapabilities(
        inline_keyboards=True,
        buttons=True,
        rich_formatting=True,
        voice_messages=True,
        file_attachments=True,
        photos=True,
        edit_messages=True,
        reactions=False,
        typing_indicator=True,
        max_message_length=4096,
    )

    def __init__(
        self,
        token: str,
    ):
        self.token = token

        from otto import config as otto_config

        self.security = SecurityAdapter(config_module=otto_config)

        self.app: Application | None = None
        self.core: ChatCore | None = None
        self.renderer = TelegramRenderer()
        self.callback_handler: TelegramCallbackHandler | None = None

        self._chat_id: int | None = None
        self._username: str | None = None

        # Per-user locks for LLM requests - prevents concurrent LLM calls per user
        # while still allowing commands to run immediately
        self._user_locks: dict[int, asyncio.Lock] = {}

        # Ephemeral notification tracking: telegram_msg_id -> notification metadata
        # Used for reply-to session switching and context exclusion
        self._ephemeral_notifications: dict[int, dict] = {}

    async def start(self) -> None:
        """Start the Telegram bot (async version for use with asyncio.run)."""
        log.info("Starting Telegram platform")

        # Initialize core
        self.core = ChatCore(self)
        self.callback_handler = TelegramCallbackHandler(self)

        # Build application with concurrent updates enabled
        # This allows commands like /status to respond while LLM is processing
        self.app = (
            Application.builder()
            .token(self.token)
            .concurrent_updates(True)
            .post_init(self._post_init)
            .build()
        )
        self.app.add_error_handler(self._error_handler)

        # Register handlers
        self._register_handlers()

        # Set up SIGHUP for config reload
        self._setup_signal_handlers()

        # Initialize and start
        await self.app.initialize()
        await self.app.start()
        await self.app.updater.start_polling(allowed_updates=Update.ALL_TYPES)

        # Keep running until stop is called
        try:
            while True:
                await asyncio.sleep(1)
        except asyncio.CancelledError:
            pass
        finally:
            await self.app.updater.stop()
            await self.app.stop()
            await self.app.shutdown()

    def run(self) -> None:
        """Run the Telegram bot (blocking, manages own event loop)."""
        log.info("Starting Telegram platform")

        # Initialize core
        self.core = ChatCore(self)
        self.callback_handler = TelegramCallbackHandler(self)

        # Build application with concurrent updates enabled
        # This allows commands like /status to respond while LLM is processing
        self.app = (
            Application.builder()
            .token(self.token)
            .concurrent_updates(True)
            .post_init(self._post_init)
            .build()
        )
        self.app.add_error_handler(self._error_handler)

        # Register handlers
        self._register_handlers()

        # Set up SIGHUP for config reload
        self._setup_signal_handlers()

        # Run polling (blocking call that manages its own event loop)
        try:
            self.app.run_polling(allowed_updates=Update.ALL_TYPES)
        finally:
            # Clear ready marker on shutdown
            from otto.daemon import clear_ready_marker

            clear_ready_marker("telegram-bot")
            log.info("Bot stopped, ready marker cleared")

    async def stop(self) -> None:
        """Stop the Telegram bot."""
        from otto.daemon import clear_ready_marker

        log.info("Stopping Telegram platform")

        # Stop heartbeat monitoring
        try:
            from otto.heartbeat.integration import stop_heartbeat

            await stop_heartbeat()
        except Exception:
            log.debug("Heartbeat stop skipped", exc_info=True)

        clear_ready_marker("telegram-bot")
        if self.app:
            self.app.stop_running()

    def _register_handlers(self) -> None:
        """Register all message and callback handlers."""
        # Log all updates (debug)
        self.app.add_handler(MessageHandler(filters.ALL, self._log_update), group=-1)

        # Command handlers - route through unified command system
        self.app.add_handler(CommandHandler("start", self._handle_start))

        # All other commands go through the router
        self.app.add_handler(MessageHandler(filters.COMMAND, self._handle_command))

        # Message handlers
        self.app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self._handle_text))
        self.app.add_handler(MessageHandler(filters.PHOTO, self._handle_photo))
        self.app.add_handler(MessageHandler(filters.VOICE | filters.AUDIO, self._handle_voice))

        # Callback handler for all button presses
        self.app.add_handler(CallbackQueryHandler(self.callback_handler.handle))

    async def _post_init(self, application: Application) -> None:
        """Called after application initialization."""
        from otto.daemon import get_pending_restart_notification, write_ready_marker

        await application.bot.set_my_commands(BOT_COMMANDS)
        log.info("Bot commands registered")

        # Start internal message processor
        job_queue = application.job_queue
        if job_queue:
            job_queue.run_repeating(
                self._process_internal_messages,
                interval=10,
                first=5,
                name="internal_message_processor",
            )
            log.info("Internal message processor started")

        # Start heartbeat monitoring daemon
        try:
            from otto.heartbeat.integration import start_heartbeat

            await start_heartbeat()
            log.info("Heartbeat monitoring started")
        except Exception:
            log.debug("Heartbeat start skipped", exc_info=True)

        # Write ready marker to signal we're fully initialized
        write_ready_marker("telegram-bot")
        log.info("Ready marker written")

        # Check for pending restart notification
        notification = get_pending_restart_notification("telegram-bot")
        if notification:
            await self._send_restart_notification(application, notification)

    async def _send_restart_notification(
        self, application: Application, notification: dict
    ) -> None:
        """Send notification to user who triggered restart."""
        chat_id = notification.get("chat_id")
        user_name = notification.get("user_name")
        reason = notification.get("reason", "restart")

        if not chat_id:
            log.warning("Restart notification missing chat_id")
            return

        try:
            # Build a friendly message
            if user_name:
                message = f"Hey {user_name}, I'm back online! ✓"
            else:
                message = "I'm back online! ✓"

            if reason == "graceful_restart":
                message += "\n\nRestart completed successfully."

            await application.bot.send_message(
                chat_id=int(chat_id),
                text=message,
                parse_mode=ParseMode.HTML,
            )
            log.info("Sent restart notification to chat %s", chat_id)
        except Exception as e:
            log.error("Failed to send restart notification: %s", e)

    def _setup_signal_handlers(self) -> None:
        """Set up signal handlers for config reload and graceful restart."""

        def _handle_sighup(signum, frame):
            log.info("Received SIGHUP, reloading configuration...")
            try:
                from otto.backends import reload_config

                reload_config()
                log.info("Configuration reloaded successfully")
            except Exception as e:
                log.error("Config reload failed: %s", e)

        def _handle_sigusr1(signum, frame):
            log.info("Received SIGUSR1, initiating graceful restart...")
            # Stop the bot - the caller is expected to have spawned a new process
            if self.app:
                self.app.stop_running()

        signal.signal(signal.SIGHUP, _handle_sighup)
        signal.signal(signal.SIGUSR1, _handle_sigusr1)

    # -------------------------------------------------------------------------
    # Authorization
    # -------------------------------------------------------------------------

    def _is_authorized(self, ctx: ChatContext) -> bool:
        """Check if this request is authorized (and emit audit logs)."""
        from otto import audit

        if ctx.security is None:
            return True

        if ctx.security.is_authorized:
            if ctx.security.bootstrapped_owner:
                audit.log_security(
                    "owner_bootstrapped",
                    user_id=ctx.message.user_id,
                    username=ctx.message.user_name,
                    data={"platform": ctx.message.platform},
                )
            return True

        audit.log_security(
            "auth_denied",
            user_id=ctx.message.user_id,
            username=ctx.message.user_name,
            success=False,
            data={"reason": "not_in_allowed_users"},
        )
        return False

    # -------------------------------------------------------------------------
    # Message handlers
    # -------------------------------------------------------------------------

    async def _log_update(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Log all updates for debugging."""
        log.info("Update received: %s", update.to_json())

    async def _handle_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /start command."""
        from otto import audit
        from otto import config as otto_config

        user_id = update.effective_user.id
        username = update.effective_user.username

        ctx = self._create_context(update)
        if not self._is_authorized(ctx):
            log.warning("Unauthorized /start from user %s (%s)", user_id, username)
            await update.message.reply_text("Access denied. This bot is private.")
            return

        # Save state
        self._chat_id = update.effective_chat.id
        self._username = username or update.effective_user.first_name

        otto_config.set_telegram_chat(self._chat_id, self._username)
        audit.log_action(
            "cmd_start",
            user_id=user_id,
            username=username,
            data={"chat_id": self._chat_id},
        )

        if ctx.security and ctx.security.bootstrapped_owner:
            await update.message.reply_text(
                "Connected to Otto.\n\n"
                "You are now the <b>owner</b> (auto-bootstrapped).\n\n"
                "Just message me. I can help with anything.",
                parse_mode=ParseMode.HTML,
            )
        else:
            await update.message.reply_text(
                "Connected to Otto.\n\nJust message me. I can help with anything.",
                parse_mode=ParseMode.HTML,
            )

    async def _handle_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle slash commands through the router."""
        ctx = self._create_context(update)
        if not self._is_authorized(ctx):
            return

        text = update.message.text

        router = get_command_router()
        result = await router.handle(ctx, text)

        if result:
            await self._send_result(update.message, result)
        else:
            # Unknown command
            await update.message.reply_text(
                f"Unknown command: {text.split()[0]}\n\nUse /help for available commands."
            )

    async def _handle_text(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle regular text messages."""
        from otto import audit

        user_id = update.effective_user.id
        username = update.effective_user.username

        ctx = self._create_context(update)
        if not self._is_authorized(ctx):
            return

        text = update.message.text
        if not text:
            return

        # Check if this is a reply to an ephemeral notification → session switch
        reply_to = update.message.reply_to_message
        if reply_to and reply_to.message_id in self._ephemeral_notifications:
            notif = self._ephemeral_notifications.pop(reply_to.message_id)
            source_session_id = notif.get("source_session")
            agent_result_ref = notif.get("agent_result_ref")

            if source_session_id:
                try:
                    from otto.sessions import load_session

                    loaded = load_session(source_session_id, chat_id=ctx.message.chat_id)
                    if loaded:
                        log.info(
                            "Session switch via reply-to: %s -> %s",
                            notif.get("current_session"),
                            source_session_id,
                        )
                        # Delete the ephemeral notification message
                        try:
                            await self.delete_message(
                                str(update.message.chat_id), str(reply_to.message_id)
                            )
                        except Exception:
                            pass

                        topic = loaded.get("topic") or source_session_id
                        await update.message.reply_text(
                            f"📂 Switched to session: <b>{topic}</b>",
                            parse_mode=ParseMode.HTML,
                        )
                except Exception as e:
                    log.warning("Failed to switch session via reply-to: %s", e)

            # Continue processing the user's message in the (now switched) session
            # Fall through to normal processing below

        # Check for pending prompts in user_data
        if context.user_data.get("awaiting_memory_search"):
            context.user_data.pop("awaiting_memory_search", None)
            await self._handle_memory_search(update, text)
            return
        if context.user_data.get("awaiting_task_add"):
            pending = context.user_data.pop("awaiting_task_add", None) or {}
            checklist_id = pending.get("checklist_id")
            target_message_id = pending.get("message_id")

            if checklist_id and target_message_id:
                try:
                    from otto.services.tasks import (
                        get_checklist,
                        get_task_manager,
                        render_checklist,
                    )

                    mgr = get_task_manager()
                    mgr.add_task_to_checklist(str(checklist_id), text.strip(), created_by="user")
                    mgr.update_checklist_message_id(str(checklist_id), int(target_message_id))
                    checklist = get_checklist(str(checklist_id))
                    if checklist:
                        checklist.message_id = int(target_message_id)
                        rendered_text, keyboard = render_checklist(checklist)
                        await self.edit_message(
                            str(update.message.chat_id),
                            str(target_message_id),
                            rendered_text,
                            reply_markup=keyboard,
                            parse_mode=ParseMode.HTML,
                        )
                        await update.message.reply_text("Added.")
                        return
                except Exception as e:
                    await update.message.reply_text(f"Couldn't add task: {e}")
                    return

        log.info("Message from %s: %s", username, text[:80])

        # Audit log
        from otto import get_current_session

        session = get_current_session(chat_id=ctx.message.chat_id)
        audit.log_message(
            "user",
            text,
            user_id=user_id,
            username=username,
            session_id=session.get("id"),
        )

        # Get per-user lock to prevent concurrent LLM requests
        # Commands bypass this - they always respond immediately
        lock = self._get_user_lock(user_id)

        if lock.locked():
            # User sent a message while the agent is still working.
            # If the active backend supports mid-stream steering, redirect
            # the agent instead of rejecting the message.
            steered = await self._try_steer(text)
            if steered:
                await update.message.reply_text(
                    "↪ Redirecting the agent with your new message...",
                    parse_mode=ParseMode.HTML,
                )
            else:
                await update.message.reply_text(
                    "⏳ Still working on your previous message...\n"
                    "<i>Use /status or /agents while you wait.</i>",
                    parse_mode=ParseMode.HTML,
                )
            return

        async with lock:
            # Process through core
            await self._send_with_typing(update.message, ctx)

    async def _handle_photo(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle photo messages."""
        from otto import audit
        from otto.paths import PHOTOS_DIR

        ctx = self._create_context(update)
        if not self._is_authorized(ctx):
            return

        user_id = update.effective_user.id
        username = update.effective_user.username

        photo = update.message.photo[-1]
        caption = update.message.caption or "What's in this image?"

        # Download photo
        PHOTOS_DIR.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        photo_path = PHOTOS_DIR / f"photo_{timestamp}.jpg"

        try:
            file = await context.bot.get_file(photo.file_id)
            await file.download_to_drive(photo_path)
            audit.log_media(
                "photo",
                user_id=user_id,
                username=username,
                file_path=str(photo_path),
                file_size=photo.file_size,
            )
        except Exception as e:
            log.error("Failed to download photo: %s", e)
            await update.message.reply_text(f"Couldn't download photo: {e}")
            return

        # Get per-user lock
        lock = self._get_user_lock(user_id)
        if lock.locked():
            steered = await self._try_steer(caption)
            if steered:
                await update.message.reply_text(
                    "↪ Redirecting the agent with your new message...",
                    parse_mode=ParseMode.HTML,
                )
            else:
                await update.message.reply_text(
                    "⏳ Still working on your previous message...",
                    parse_mode=ParseMode.HTML,
                )
            return

        async with lock:
            # Process with image
            await self._send_with_typing_image(update.message, ctx, photo_path, caption)

    async def _handle_voice(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle voice messages."""
        from otto import audit
        from otto.paths import DATA_DIR

        ctx = self._create_context(update)
        if not self._is_authorized(ctx):
            return

        user_id = update.effective_user.id
        username = update.effective_user.username

        voice = update.message.voice
        audio = update.message.audio
        caption = update.message.caption or ""

        if voice:
            file_obj = voice
            ext = "ogg"
            file_type = "voice"
            duration = voice.duration
        elif audio:
            file_obj = audio
            ext = (
                audio.file_name.split(".")[-1]
                if audio.file_name and "." in audio.file_name
                else "mp3"
            )
            file_type = "audio"
            duration = audio.duration
        else:
            return

        # Check VTT status
        try:
            from otto_tools.vtt import load_config as vtt_load_config

            vtt_config = vtt_load_config()
            vtt_enabled = vtt_config.get("enabled", False)
        except ImportError:
            vtt_enabled = False
            vtt_config = {}

        # Save audio file
        audio_dir = DATA_DIR / "audio"
        audio_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        audio_path = audio_dir / f"{file_type}_{timestamp}.{ext}"

        try:
            file = await context.bot.get_file(file_obj.file_id)
            await file.download_to_drive(audio_path)
            audit.log_media(
                "voice",
                user_id=user_id,
                username=username,
                file_path=str(audio_path),
                file_size=file_obj.file_size,
                duration=duration,
            )
        except Exception as e:
            log.error("Failed to download %s: %s", file_type, e)
            await update.message.reply_text(f"Couldn't download {file_type}: {e}")
            return

        # Store for callback
        context.user_data["pending_audio"] = str(audio_path)
        context.user_data["pending_audio_caption"] = caption

        if not vtt_enabled:
            # Offer to enable VTT
            await self._offer_vtt_enable(update.message, vtt_config.get("model", "base"), file_type)
            return

        # Get per-user lock
        lock = self._get_user_lock(user_id)
        if lock.locked():
            await update.message.reply_text(
                "⏳ Still working on your previous message...",
                parse_mode=ParseMode.HTML,
            )
            return

        async with lock:
            # Transcribe and respond
            await self._transcribe_and_respond(update.message, context, audio_path, caption)

    # -------------------------------------------------------------------------
    # Helper methods
    # -------------------------------------------------------------------------

    def _get_user_lock(self, user_id: int) -> asyncio.Lock:
        """Get or create a lock for a specific user.

        This ensures only one LLM request per user runs at a time,
        while still allowing commands to respond immediately.
        """
        if user_id not in self._user_locks:
            self._user_locks[user_id] = asyncio.Lock()
        return self._user_locks[user_id]

    async def _try_steer(self, message: str) -> bool:
        """Try to steer the active backend with a new message mid-stream.

        Returns True if the steer was sent, False if the backend doesn't
        support it or isn't actively streaming.
        """
        try:
            from otto import get_backend
            from otto.paths import get_workdir

            backend = get_backend()
            caps = backend.get_capabilities()
            if not caps.get("supports_steer"):
                return False

            # Only steer if the agent is actively streaming (between
            # agent_start and agent_end).  If it already finished and
            # we're just doing post-processing, steer won't reach it.
            if not getattr(backend, "is_streaming", False):
                return False

            await backend.steer(message, get_workdir())
            log.info("Steered active Pi agent with new user message")
            return True
        except Exception as e:
            log.warning("Steer failed: %s", e)
            return False

    def _create_context(self, update: Update) -> ChatContext:
        """Create a ChatContext from a Telegram Update."""
        message = update.message or update.callback_query.message

        chat_message = ChatMessage(
            text=message.text or message.caption or "",
            user_id=str(update.effective_user.id),
            user_name=update.effective_user.username or update.effective_user.first_name or "User",
            chat_id=str(message.chat_id),
            platform="telegram",
            raw_message=message,
            message_id=str(message.message_id),
        )

        ctx = ChatContext(message=chat_message, platform=self)
        ctx.security = self.security.create_context(
            user_id=chat_message.user_id,
            user_name=chat_message.user_name,
            platform=chat_message.platform,
        )
        return ctx

    async def _send_result(self, message, result: CommandResult) -> None:
        """Send a CommandResult as a Telegram message."""
        text, markup = self.renderer.render(result)

        sent = None
        try:
            sent = await message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=markup)
        except Exception:
            # Fallback without HTML
            sent = await message.reply_text(text, reply_markup=markup)

        # Best-effort: persist checklist message_id for live task updates.
        try:
            if (
                sent
                and result.data
                and isinstance(result.data, dict)
                and result.data.get("task_checklist_id")
            ):
                from otto.services.tasks import get_task_manager

                get_task_manager().update_checklist_message_id(
                    str(result.data["task_checklist_id"]), int(sent.message_id)
                )
        except Exception:
            pass

    async def _send_with_typing(self, message, ctx: ChatContext) -> None:
        """Send response with typing indicator."""
        stop = asyncio.Event()
        typing_task = asyncio.create_task(self._keep_typing(message.chat_id, stop))

        try:
            # ChatCore sends the response via ctx.reply (platform.send_message).
            await self.core.process_with_agent(ctx)
        finally:
            stop.set()
            await typing_task

    async def _send_with_typing_image(
        self, message, ctx: ChatContext, image_path: Path, caption: str
    ) -> None:
        """Send response for image with typing indicator."""
        stop = asyncio.Event()
        typing_task = asyncio.create_task(self._keep_typing(message.chat_id, stop))

        try:
            # ChatCore sends the response via ctx.reply (platform.send_message).
            await self.core.process_with_image(ctx, image_path, caption)
        finally:
            stop.set()
            await typing_task

    async def _send_chunked(self, message, text: str) -> None:
        """Send text, chunking if necessary."""
        max_len = self.capabilities.max_message_length

        if len(text) <= max_len:
            try:
                await message.reply_text(text, parse_mode=ParseMode.HTML)
            except Exception:
                await message.reply_text(text)
            return

        # Chunk the text
        chunks = self._chunk_text(text, max_len)
        for chunk in chunks:
            try:
                await message.reply_text(chunk, parse_mode=ParseMode.HTML)
            except Exception:
                await message.reply_text(chunk)
            await asyncio.sleep(0.1)

    def _chunk_text(self, text: str, max_len: int) -> list[str]:
        """Split text into chunks at natural boundaries."""
        if len(text) <= max_len:
            return [text]

        chunks = []
        while text:
            if len(text) <= max_len:
                chunks.append(text)
                break

            chunk = text[:max_len]

            # Try to break at newline
            last_newline = chunk.rfind("\n")
            if last_newline > max_len // 2:
                chunk = text[:last_newline]
                text = text[last_newline + 1 :]
            else:
                # Break at space
                last_space = chunk.rfind(" ")
                if last_space > max_len // 2:
                    chunk = text[:last_space]
                    text = text[last_space + 1 :]
                else:
                    text = text[max_len:]

            chunks.append(chunk.strip())

        return chunks

    async def _keep_typing(self, chat_id: int, stop: asyncio.Event) -> None:
        """Keep sending typing indicator."""
        while not stop.is_set():
            try:
                await self.app.bot.send_chat_action(chat_id=chat_id, action=ChatAction.TYPING)
                await asyncio.wait_for(stop.wait(), timeout=4.0)
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception:
                break

    async def _offer_vtt_enable(self, message, model: str, file_type: str) -> None:
        """Offer to enable VTT when voice message received."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        keyboard = InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("Enable + Download", callback_data="vtt:enable_download")],
                [
                    InlineKeyboardButton("Enable VTT", callback_data="vtt:enable"),
                    InlineKeyboardButton("Skip", callback_data="vtt:skip"),
                ],
            ]
        )

        await message.reply_text(
            f"<b>Voice-to-Text disabled</b>\n\n"
            f"I see {file_type}. Want me to enable transcription?\n"
            f"<i>First use will download Whisper model ({model}, one-time)</i>",
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard,
        )

    async def _transcribe_and_respond(
        self, message, context: ContextTypes.DEFAULT_TYPE, audio_path: Path, caption: str
    ) -> None:
        """Transcribe audio and process with agent."""
        from otto import add_message as session_add_message

        stop = asyncio.Event()
        typing_task = asyncio.create_task(self._keep_typing(message.chat_id, stop))

        try:
            from otto_tools.vtt import is_model_ready, transcribe_async

            if not is_model_ready():
                stop.set()
                await typing_task
                await self._offer_vtt_download(message)
                return

            # Transcribe
            text = await transcribe_async(audio_path)

            if not text.strip():
                await message.reply_text("(No speech detected)")
                return

            # Show transcription
            await message.reply_text(
                f"<b>Transcription:</b>\n<i>{text}</i>",
                parse_mode=ParseMode.HTML,
            )

            # Process with agent
            if caption:
                prompt = f'The user sent audio. Transcription: "{text}"\n\nTheir question/request: {caption}'
            else:
                prompt = f'The user sent a voice message. Transcription: "{text}"\n\nRespond naturally to what they said.'

            session_add_message("user", f"[voice] {text[:200]}", chat_id=str(message.chat_id))

            # Create context for agent
            ctx = ChatContext(
                message=ChatMessage(
                    text=prompt,
                    user_id=str(message.from_user.id) if message.from_user else "unknown",
                    user_name=message.from_user.username if message.from_user else "User",
                    chat_id=str(message.chat_id),
                    platform="telegram",
                    raw_message=message,
                ),
                platform=self,
            )

            # ChatCore sends the response via ctx.reply (platform.send_message).
            await self.core.process_with_agent(ctx)

        except Exception as e:
            log.error("Transcription failed: %s", e)
            await message.reply_text(f"Transcription error: {e}")
        finally:
            stop.set()
            try:
                await typing_task
            except asyncio.CancelledError:
                pass

        # Clear pending audio
        context.user_data.pop("pending_audio", None)
        context.user_data.pop("pending_audio_caption", None)

    async def _offer_vtt_download(self, message) -> None:
        """Offer to download VTT model."""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        keyboard = InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("Download now", callback_data="vtt:download"),
                    InlineKeyboardButton("Cancel", callback_data="vtt:skip"),
                ]
            ]
        )

        await message.reply_text(
            "<b>Model not downloaded</b>\n\n"
            "Whisper model needs to download first.\n"
            "This is a one-time setup.",
            parse_mode=ParseMode.HTML,
            reply_markup=keyboard,
        )

    async def _handle_memory_search(self, update: Update, query: str) -> None:
        """Handle memory search input."""
        from otto import memory_search_formatted

        results = memory_search_formatted(query, limit=3)
        if results:
            await update.message.reply_text(
                f"<b>Memory search:</b> {query}\n\n{results[:3000]}",
                parse_mode=ParseMode.HTML,
            )
        else:
            await update.message.reply_text(f"Nothing found for: {query}")

    async def _process_internal_messages(self, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Process pending internal messages from background agents."""
        from otto import config as otto_config
        from otto.internal_messages import (
            claim_pending_messages,
            format_agent_completion,
            format_batch_completion,
            format_event_batch,
            format_pipeline_completed,
            format_scheduled_job_event,
            format_system_event,
            get_batch_status,
            mark_failed,
            mark_processed,
        )

        # Get chat_id
        state = otto_config.get_telegram_state()
        chat_id = state.get("chat_id")
        if not chat_id:
            log.warning("No chat_id in state, can't deliver internal messages")
            return

        # Always apply task updates first (cheap + keeps checklists fresh).
        task_updates = claim_pending_messages(
            worker_id="telegram-bot",
            limit=25,
            types=["task_update"],
        )
        for msg in task_updates:
            try:
                await self._apply_task_update(chat_id, msg.payload)
                mark_processed(msg.id, status="processed")
            except Exception as e:
                log.error("Failed to apply task update %s: %s", msg.id, e)
                mark_failed(msg.id, str(e))

        # Batch low-priority events.
        batch_cfg = otto_config.get_setting("agent.orchestration.batch", {}) or {}
        threshold = int(batch_cfg.get("low_priority_threshold", 3) or 3)
        max_wait = float(batch_cfg.get("low_priority_max_wait_minutes", 5) or 5)
        use_ai_batch_summary = bool(batch_cfg.get("batch_with_ai_summary", True))

        try:
            batch_status = get_batch_status()
        except Exception:
            batch_status = {"count": 0, "oldest_age_minutes": 0}

        # Process high/normal events first (priority order), then batch low-priority.
        messages = claim_pending_messages(
            worker_id="telegram-bot",
            limit=25,
            types=["agent_completed", "scheduled_job", "system_event", "pipeline_completed"],
            min_priority=0,
        )

        for msg in messages:
            try:
                # Extract session_id from payload for cross-session routing
                event_session_id = msg.payload.get("session_id")

                if msg.type == "agent_completed":
                    # Pipeline awareness: skip if this agent has pending/running children
                    # The child's completion will trigger the full pipeline summary
                    agent_id = msg.payload.get("agent_id")
                    if agent_id and self._is_pipeline_multi(agent_id):
                        log.debug(
                            "Agent %s is part of a multi-stage pipeline, suppressing notification",
                            agent_id,
                        )
                        mark_processed(msg.id, status="suppressed")
                        continue
                    if agent_id and self._has_active_children(agent_id):
                        log.debug("Agent %s has active children, deferring notification", agent_id)
                        mark_processed(msg.id, status="deferred")
                        continue
                    prompt = format_agent_completion(msg.payload)
                    await self._deliver_internal_event(
                        chat_id, prompt, event_session_id=event_session_id
                    )
                    # Only attach output for same-session events (cross-session gets ephemeral)
                    if not event_session_id or self._is_current_session(chat_id, event_session_id):
                        await self._attach_agent_output(chat_id, msg.payload)
                elif msg.type == "pipeline_completed":
                    prompt = format_pipeline_completed(msg.payload)
                    await self._deliver_internal_event(
                        chat_id, prompt, event_session_id=event_session_id
                    )
                    # Don't attach individual files for pipelines - Otto will read and synthesize
                elif msg.type == "scheduled_job":
                    prompt = format_scheduled_job_event(msg.payload)
                    event_session_id = msg.payload.get("session_id")
                    await self._deliver_internal_event(
                        chat_id, prompt, event_session_id=event_session_id
                    )
                elif msg.type == "system_event":
                    prompt = format_system_event(msg.payload)
                    await self._deliver_internal_event(chat_id, prompt)
                else:
                    prompt = (
                        "[SYSTEM: An internal event occurred]\n"
                        f"Type: {msg.type}\n"
                        f"Payload: {msg.payload}\n\n"
                        "[Summarize this briefly to the user.]"
                    )
                    await self._deliver_internal_event(chat_id, prompt)

                mark_processed(msg.id, status="processed")
            except Exception as e:
                log.error("Failed to process internal message %s: %s", msg.id, e)
                mark_failed(msg.id, str(e))

        should_batch = bool(
            batch_status.get("count", 0) >= threshold
            or batch_status.get("oldest_age_minutes", 0) >= max_wait
        )

        if not should_batch:
            return

        low_msgs = claim_pending_messages(
            worker_id="telegram-bot",
            limit=25,
            types=["agent_completed", "scheduled_job", "system_event"],
            max_priority=-1,
        )
        if not low_msgs:
            return

        try:
            if use_ai_batch_summary and all(m.type == "agent_completed" for m in low_msgs):
                prompt = format_batch_completion([m.payload for m in low_msgs])
            else:
                prompt = format_event_batch(low_msgs)
            await self._deliver_internal_event(chat_id, prompt)

            for m in low_msgs:
                mark_processed(m.id, status="processed")
        except Exception as e:
            log.error("Failed to process low-priority batch: %s", e)
            for m in low_msgs:
                mark_failed(m.id, str(e))

    def _has_active_children(self, agent_id: str) -> bool:
        """Check if agent has pending/running/waiting children (part of an incomplete pipeline)."""
        if not agent_id:
            return False
        try:
            from otto.jobs.queue import JobQueue

            q = JobQueue()
            # Check for any children in non-terminal states
            with q._conn() as conn:
                cursor = conn.execute(
                    """
                    SELECT COUNT(*) as count FROM jobs
                    WHERE depends_on_id = ? AND status IN ('pending', 'running', 'waiting')
                    """,
                    (agent_id,),
                )
                return cursor.fetchone()["count"] > 0
        except Exception as e:
            log.warning("Failed to check for active children: %s", e)
            return False

    def _is_current_session(self, chat_id: int, session_id: str) -> bool:
        """Check if session_id matches the currently active session for this chat."""
        try:
            from otto.sessions import get_current_session

            current = get_current_session(chat_id=str(chat_id))
            return current.get("id") == session_id
        except Exception:
            return True  # Assume same session on error (safe default)

    def _is_pipeline_multi(self, agent_id: str) -> bool:
        """Check if agent belongs to a pipeline with multiple members."""
        if not agent_id:
            return False
        try:
            from otto.jobs.queue import JobQueue

            q = JobQueue()
            _complete, members = q.is_pipeline_complete(agent_id)
            return len(members) > 1
        except Exception as e:
            log.warning("Failed to check pipeline membership: %s", e)
            return False

    async def _deliver_internal_event(
        self,
        chat_id: int,
        prompt: str,
        *,
        event_session_id: str | None = None,
    ) -> None:
        """Run an internal event through ChatCore and deliver a conversational notification.

        If the event's source session differs from the currently active session,
        sends an ephemeral notification instead of polluting the current context.
        Reply-to the notification to switch sessions.
        """
        if not self.core:
            raise RuntimeError("ChatCore not initialized")

        # Determine if this is a cross-session event
        if event_session_id:
            try:
                from otto.sessions import get_current_session

                current = get_current_session(chat_id=str(chat_id))
                current_session_id = current.get("id")

                if current_session_id and event_session_id != current_session_id:
                    # Cross-session! Send ephemeral notification instead
                    await self._send_ephemeral_notification(
                        chat_id=chat_id,
                        event_session_id=event_session_id,
                        current_session_id=current_session_id,
                        prompt=prompt,
                    )
                    return
            except Exception as e:
                log.warning("Cross-session check failed, delivering normally: %s", e)

        # Same session or no session info — deliver normally
        await self.core.process_internal_event(str(chat_id), prompt)

    async def _send_ephemeral_notification(
        self,
        chat_id: int,
        event_session_id: str,
        current_session_id: str,
        prompt: str,
    ) -> None:
        """Send a brief ephemeral notification for a cross-session event.

        The notification is:
        - Visible to the user in Telegram
        - NOT added to the current session's LLM context
        - Reply-able to switch to the source session
        """
        # Extract task info from the prompt for a concise notification
        task_line = ""
        success_indicator = ""
        for line in prompt.split("\n"):
            if line.startswith("Task:"):
                task_line = line.replace("Task:", "").strip()
            if "completed successfully" in line.lower():
                success_indicator = "✅"
            elif "failed" in line.lower():
                success_indicator = "❌"

        # Try to get session topic for display
        session_label = event_session_id
        try:
            import json

            from otto.sessions import ARCHIVE_DIR

            # Check archive for the session
            archive_file = ARCHIVE_DIR / f"{event_session_id}.json"
            if archive_file.exists():
                session_data = json.loads(archive_file.read_text())
                session_label = session_data.get("topic") or event_session_id
        except Exception:
            pass

        summary = task_line[:80] if task_line else "Task completed"
        notification_text = (
            f"{success_indicator} {summary}\n"
            f"<i>Session: {session_label}</i>\n\n"
            f"<i>↩️ Reply to switch to this session</i>"
        )

        try:
            sent = await self.send_message(
                str(chat_id),
                notification_text,
                parse_mode=ParseMode.HTML,
            )

            if sent and hasattr(sent, "message_id"):
                # Track this notification for reply-to detection
                self._ephemeral_notifications[sent.message_id] = {
                    "source_session": event_session_id,
                    "current_session": current_session_id,
                    "agent_result_ref": task_line,
                    "timestamp": datetime.now().isoformat(),
                }

                # Also store the event prompt so we can deliver it when they switch
                # Store in the source session as an ephemeral message
                from otto import add_message as session_add_message

                session_add_message(
                    "user",
                    prompt[:3000],
                    chat_id=str(chat_id),
                    ephemeral=True,
                )

                # Prune old ephemeral notifications (keep last 50)
                if len(self._ephemeral_notifications) > 50:
                    oldest_keys = sorted(self._ephemeral_notifications.keys())
                    for k in oldest_keys[: len(oldest_keys) - 50]:
                        del self._ephemeral_notifications[k]

        except Exception as e:
            log.warning("Failed to send ephemeral notification: %s", e)

    async def _attach_agent_output(self, chat_id: int, payload: dict) -> None:
        """Attach an agent output file when available (preferred over dumping long output in chat)."""
        output_file = payload.get("output_file")
        if not output_file:
            return

        try:
            path = Path(str(output_file)).expanduser()
            if not (path.exists() and path.is_file()):
                return

            # Keep a safe margin under Telegram's file size limits.
            max_size_bytes = 45 * 1024 * 1024
            if path.stat().st_size <= max_size_bytes:
                await self.send_file(str(chat_id), path, caption=f"Output: {path.name}")
                return

            try:
                display_path = str(path).replace(str(Path.home()), "~", 1)
            except Exception:
                display_path = str(path)

            await self.send_message(
                str(chat_id),
                f"Output file is too large to send: <code>{display_path}</code>",
                parse_mode=ParseMode.HTML,
            )
        except Exception as e:
            log.warning("Failed to attach agent output file: %s", e)

    async def _apply_task_update(self, chat_id: int, payload: dict) -> None:
        """Apply a queued task update and refresh any tracked Telegram checklist message."""
        from otto.services.tasks import (
            TaskStatus,
            get_checklist,
            get_task_manager,
            render_checklist,
        )

        checklist_id = payload.get("checklist_id")
        if not checklist_id:
            return

        action = (payload.get("action") or "toggle").lower()
        task_id = payload.get("task_id")
        task_content = payload.get("task_content")

        mgr = get_task_manager()

        if action == "toggle" and task_id:
            mgr.toggle_task(str(task_id), toggled_by="otto")
        elif action == "complete" and task_id:
            mgr.set_task_status(str(task_id), TaskStatus.COMPLETED, updated_by="otto")
        elif action == "add" and task_content:
            mgr.add_task_to_checklist(str(checklist_id), str(task_content), created_by="otto")

        checklist = get_checklist(str(checklist_id))
        if not checklist:
            return

        # If there's a live Telegram message, edit it in-place.
        if checklist.message_id:
            text, keyboard = render_checklist(checklist)
            await self.edit_message(
                str(chat_id),
                str(checklist.message_id),
                text,
                reply_markup=keyboard,
                parse_mode=ParseMode.HTML,
            )

    async def _error_handler(self, update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle errors in the bot."""
        log.error("Exception while handling an update:", exc_info=context.error)

    # -------------------------------------------------------------------------
    # ChatPlatform interface implementation
    # -------------------------------------------------------------------------

    async def send_message(
        self,
        chat_id: str,
        text: str,
        parse_mode: str | None = None,
        reply_markup: Any = None,
        **kwargs,
    ) -> Any:
        """Send a text message."""
        if not self.app:
            raise RuntimeError("Telegram app not initialized")

        return await self.app.bot.send_message(
            chat_id=int(chat_id),
            text=text,
            parse_mode=parse_mode or ParseMode.HTML,
            reply_markup=reply_markup,
            **kwargs,
        )

    async def send_typing(self, chat_id: str) -> None:
        """Send typing indicator."""
        if self.app:
            await self.app.bot.send_chat_action(chat_id=int(chat_id), action=ChatAction.TYPING)

    async def edit_message(self, chat_id: str, message_id: str, text: str, **kwargs) -> Any:
        """Edit an existing message."""
        if not self.app:
            raise RuntimeError("Telegram app not initialized")

        return await self.app.bot.edit_message_text(
            chat_id=int(chat_id),
            message_id=int(message_id),
            text=text,
            parse_mode=kwargs.get("parse_mode", ParseMode.HTML),
            **{k: v for k, v in kwargs.items() if k != "parse_mode"},
        )

    async def delete_message(self, chat_id: str, message_id: str) -> bool:
        """Delete a message."""
        if not self.app:
            raise RuntimeError("Telegram app not initialized")

        try:
            await self.app.bot.delete_message(
                chat_id=int(chat_id),
                message_id=int(message_id),
            )
            return True
        except Exception as e:
            log.warning("Failed to delete message %s: %s", message_id, e)
            return False

    async def send_file(
        self, chat_id: str, file_path: Path, caption: str | None = None, **kwargs
    ) -> Any:
        """Send a file attachment."""
        if not self.app:
            raise RuntimeError("Telegram app not initialized")

        with open(file_path, "rb") as f:
            return await self.app.bot.send_document(
                chat_id=int(chat_id), document=f, caption=caption, **kwargs
            )

    async def download_file(self, file_id: str, destination: Path) -> Path:
        """Download a file from Telegram."""
        if not self.app:
            raise RuntimeError("Telegram app not initialized")

        file = await self.app.bot.get_file(file_id)
        await file.download_to_drive(destination)
        return destination

    def format_text(
        self, text: str, bold: bool = False, code: bool = False, pre: bool = False
    ) -> str:
        """Format text for Telegram HTML."""
        if pre:
            return f"<pre>{text}</pre>"
        if code:
            return f"<code>{text}</code>"
        if bold:
            return f"<b>{text}</b>"
        return text

    def strip_formatting(self, text: str) -> str:
        """Strip HTML formatting from text."""
        return re.sub(r"<[^>]+>", "", text)
