"""
Core types for Otto chat system.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable


@dataclass
class PlatformCapabilities:
    """Capabilities supported by a chat platform."""

    inline_keyboards: bool = False
    buttons: bool = False
    rich_formatting: bool = False
    voice_messages: bool = False
    file_attachments: bool = False
    photos: bool = False
    edit_messages: bool = False
    reactions: bool = False
    typing_indicator: bool = False
    max_message_length: int = 4096


@dataclass
class ChatMessage:
    """A unified chat message."""

    text: str
    user_id: str
    user_name: str
    chat_id: str
    platform: str
    raw_message: Any = None
    message_id: str | None = None


class ChatContext:
    """Context for a chat interaction."""

    def __init__(self, message: ChatMessage, platform: Any):
        self.message = message
        self.platform = platform
        self.security: Any | None = None
        self.user_data: dict[str, Any] = {}

    async def reply(self, text: str, **kwargs) -> Any:
        """Reply to the message."""
        return await self.platform.send_message(self.message.chat_id, text, **kwargs)

    async def send_file(self, path: Any, caption: str | None = None, **kwargs) -> Any:
        """Send a file attachment."""
        if hasattr(self.platform, "send_file"):
            return await self.platform.send_file(
                self.message.chat_id, path, caption=caption, **kwargs
            )
        return None


@runtime_checkable
class ChatPlatform(Protocol):
    """Protocol for chat platform implementations."""

    name: str
    capabilities: PlatformCapabilities

    async def send_message(self, chat_id: str, text: str, **kwargs) -> Any: ...
    async def send_typing(self, chat_id: str) -> None: ...
    async def edit_message(self, chat_id: str, message_id: str, text: str, **kwargs) -> Any: ...
