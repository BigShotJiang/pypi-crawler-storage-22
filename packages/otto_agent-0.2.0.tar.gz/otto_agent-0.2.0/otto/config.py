"""
Central configuration management for Otto.

Single source of truth for all configuration:
- Secrets: API tokens, keys (loaded from environment/.env)
- Settings: User preferences, allowlist, feature flags
- State: Runtime state (bot chat_id, etc.)

Config file: ~/.otto/config/settings.yaml
Secrets: ~/.otto/config/.env (existing, not touched)
State: ~/.otto/config/state.yaml (replaces bot_state.json)
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml

from .paths import CONFIG_DIR, ensure_dirs

# Config files
SETTINGS_FILE = CONFIG_DIR / "settings.yaml"
STATE_FILE = CONFIG_DIR / "state.yaml"
ENV_FILE = CONFIG_DIR / ".env"

# Defaults
DEFAULT_SETTINGS = {
    "access": {
        "allowed_users": [],  # List of {id: int, name: str, added: str}
        "owner_id": None,  # Primary owner user ID
        # Bootstrap behavior when Otto has no owner configured yet.
        # - first_user: first Telegram user to interact becomes owner
        # - disabled: never auto-assign owner
        "bootstrap": {
            "mode": "first_user",
        },
    },
    "telegram": {
        "enabled": True,
    },
    "vtt": {
        "enabled": False,
        "model": "base",
        "device": "auto",
        "compute_type": "auto",
        "language": "auto",
        "beam_size": 1,
        "vad_filter": True,
    },
    "agent": {
        "active": "pi",
        "thinking": {
            "enabled": True,  # Enable extended thinking for supported models
            "show_in_chat": True,  # Display thinking content in chat messages
            "tools_only": True,  # Only show tool names during processing, not narration text
        },
        "backends": {
            "pi": {
                "enabled": True,
                "path": "~/.local/bin/pi",
                "model": "anthropic/claude-sonnet-4-5-thinking",
                "options": {
                    "reuse_session": True,
                    "connection_timeout": 60,
                    "thinking_level": "medium",
                    "auto_compaction": True,
                },
            },
            "litellm": {
                "enabled": False,
                "model": "openrouter/meta-llama/llama-3.3-70b-instruct",
                "options": {
                    "max_turns": 50,
                    "timeout": 300,
                    "api_base": None,
                    "api_key_env": "OPENROUTER_API_KEY",
                    "include_mcp_tools": True,
                    "safeguards": {
                        "enabled": True,
                        "protected_paths": [],
                        "blocked_patterns": [],
                    },
                },
            },
            "cecli": {
                "enabled": False,
                "model": "anthropic/claude-sonnet-4-5",
                "options": {
                    "edit_format": "agent",
                    "auto_commits": False,
                    "use_git": False,
                    "auto_lint": False,
                    "auto_test": False,
                    "timeout": 300,
                },
            },
        },
        "orchestration": {
            "max_parallel": 5,
            "worker_concurrency": 4,
            "default_timeout": 3600,
            "retry": {
                # Number of retries after the first failure (total attempts = 1 + max_retries).
                "max_retries": 3,
                # Exponential backoff: delay = base_delay_seconds * (backoff_factor ** attempts)
                # where `attempts` is the 1-based attempt count for the job.
                "base_delay_seconds": 30,
                "backoff_factor": 2,
                "max_delay_seconds": 300,
            },
            "batch": {
                "low_priority_threshold": 3,  # Min messages to trigger batch
                "low_priority_max_wait_minutes": 5,  # Max wait before batch
                "batch_with_ai_summary": True,  # Use AI to summarize batch
            },
            "heartbeat": {
                "enabled": True,
                "auto_retry": True,
                "max_retries": 3,
                "poll_interval": 30,  # Seconds between agent checks
                "timeout_seconds": 3600,  # Max agent runtime before timeout
                "escalate_to_llm": True,
                "notify_on": ["agent_failed", "schedule_missed", "critical_error"],
            },
        },
    },
    "gateway": {
        "kill_switch": False,
        "dry_run": False,
        "max_calls_per_session": 0,  # 0 = unlimited
        "servers": {},
        "blocked_paths": [
            "~/.ssh",
            "~/.gnupg",
            "/etc",
        ],
        "allowed_paths": [],
        "permissions": {
            "file_write": "auto",
            "file_delete": "prompt",
            "shell_exec": "auto",
            "network_access": "auto",
        },
        "audit": {
            "enabled": True,
            "log_allowed": True,
            "log_tool_args": False,
        },
    },
    "supervisor": {
        "enabled": True,
        "alert_after_failures": 3,
        "check_mcp": True,
    },
}

DEFAULT_STATE = {
    "telegram": {
        "chat_id": None,
        "user": None,
        "registered_at": None,
    },
}


# In-memory cache
_settings_cache: dict | None = None
_state_cache: dict | None = None
_env_cache: dict | None = None


def _load_env() -> dict[str, str]:
    """Load environment variables from .env file."""
    global _env_cache
    if _env_cache is not None:
        return _env_cache

    env = {}
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                env[key.strip()] = value.strip().strip('"').strip("'")
    _env_cache = env
    return env


def _load_yaml(path: Path, defaults: dict) -> dict:
    """Load a YAML file, creating with defaults if missing."""
    if not path.exists():
        return defaults.copy()
    try:
        content = yaml.safe_load(path.read_text()) or {}
        # Deep merge with defaults
        return _deep_merge(defaults.copy(), content)
    except Exception:
        return defaults.copy()


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base."""
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _save_yaml(path: Path, data: dict) -> None:
    """Save data to YAML file with secure permissions."""
    ensure_dirs()
    path.parent.mkdir(parents=True, exist_ok=True)

    # Write atomically
    tmp_path = path.with_suffix(".tmp")
    tmp_path.write_text(
        yaml.dump(data, default_flow_style=False, allow_unicode=True, sort_keys=False)
    )
    tmp_path.chmod(0o600)  # Secure permissions
    tmp_path.rename(path)


def load_settings() -> dict:
    """Load settings, using cache if available."""
    global _settings_cache
    if _settings_cache is None:
        _settings_cache = _load_yaml(SETTINGS_FILE, DEFAULT_SETTINGS)
    return _settings_cache


def save_settings(settings: dict) -> None:
    """Save settings to file."""
    global _settings_cache
    _save_yaml(SETTINGS_FILE, settings)
    _settings_cache = settings


def load_state() -> dict:
    """Load runtime state."""
    global _state_cache
    if _state_cache is None:
        _state_cache = _load_yaml(STATE_FILE, DEFAULT_STATE)
    return _state_cache


def save_state(state: dict) -> None:
    """Save runtime state."""
    global _state_cache
    _save_yaml(STATE_FILE, state)
    _state_cache = state


def reload() -> None:
    """Clear caches and reload all config."""
    global _settings_cache, _state_cache, _env_cache
    _settings_cache = None
    _state_cache = None
    _env_cache = None


# Convenience accessors
def get_secret(key: str, default: str | None = None) -> str | None:
    """Get a secret from environment or .env file."""
    # Environment takes precedence
    value = os.environ.get(key)
    if value:
        return value
    env = _load_env()
    return env.get(key, default)


def get_setting(path: str, default: Any = None) -> Any:
    """
    Get a nested setting by dot-separated path.

    Example: get_setting("vtt.enabled") -> True/False
    """
    settings = load_settings()
    keys = path.split(".")
    value = settings
    for key in keys:
        if isinstance(value, dict):
            value = value.get(key)
        else:
            return default
        if value is None:
            return default
    return value


def set_setting(path: str, value: Any) -> None:
    """
    Set a nested setting by dot-separated path.

    Example: set_setting("vtt.enabled", True)
    """
    settings = load_settings()
    keys = path.split(".")
    current = settings

    for key in keys[:-1]:
        if key not in current or not isinstance(current[key], dict):
            current[key] = {}
        current = current[key]

    current[keys[-1]] = value
    save_settings(settings)


# Access control helpers
def get_allowed_user_ids() -> set[int]:
    """Get set of allowed Telegram user IDs."""
    settings = load_settings()
    access = settings.get("access", {})

    allowed = set()

    # Owner is always allowed
    owner_id = access.get("owner_id")
    if owner_id:
        allowed.add(int(owner_id))

    # Add all users from allowlist
    for user in access.get("allowed_users", []):
        if isinstance(user, dict) and user.get("id"):
            allowed.add(int(user["id"]))
        elif isinstance(user, int):
            allowed.add(user)

    return allowed


def is_authorized(user_id: int) -> bool:
    """Check if a user is authorized to use the bot."""
    return user_id in get_allowed_user_ids()


def bootstrap_owner_if_needed(user_id: int, name: str = "") -> bool:
    """
    If no owner/allowlist is configured yet, promote the first user to owner.

    Returns True if the owner was set by this call.
    """
    mode = str(get_setting("access.bootstrap.mode", "first_user") or "").strip().lower()
    if mode not in {"first_user", "true", "1", "yes"}:
        return False

    settings = load_settings()
    access = settings.get("access", {})
    owner_id = access.get("owner_id")
    allowed_users = access.get("allowed_users", [])

    # Only bootstrap when no auth config exists.
    if owner_id or allowed_users:
        return False

    # Persist owner + allowlist entry.
    set_owner(user_id, name)
    return True


def add_user(user_id: int, name: str = "") -> bool:
    """Add a user to the allowlist. Returns True if added, False if already exists."""
    from datetime import datetime

    settings = load_settings()
    if "access" not in settings:
        settings["access"] = {}
    if "allowed_users" not in settings["access"]:
        settings["access"]["allowed_users"] = []

    # Check if already exists
    for user in settings["access"]["allowed_users"]:
        if isinstance(user, dict) and user.get("id") == user_id:
            return False
        if user == user_id:
            return False

    settings["access"]["allowed_users"].append(
        {
            "id": user_id,
            "name": name,
            "added": datetime.now().isoformat(),
        }
    )
    save_settings(settings)
    return True


def remove_user(user_id: int) -> bool:
    """Remove a user from the allowlist. Returns True if removed."""
    settings = load_settings()
    access = settings.get("access", {})
    users = access.get("allowed_users", [])

    original_len = len(users)
    users = [
        u for u in users if not ((isinstance(u, dict) and u.get("id") == user_id) or u == user_id)
    ]

    if len(users) < original_len:
        settings["access"]["allowed_users"] = users
        save_settings(settings)
        return True
    return False


def set_owner(user_id: int, name: str = "") -> None:
    """Set the owner user ID."""
    settings = load_settings()
    if "access" not in settings:
        settings["access"] = {}
    settings["access"]["owner_id"] = user_id

    # Also add to allowed_users if not present
    add_user(user_id, name)
    save_settings(settings)


# VTT helpers (replaces vtt.json)
def get_vtt_config() -> dict:
    """Get VTT configuration."""
    return get_setting("vtt", DEFAULT_SETTINGS["vtt"])


def set_vtt_enabled(enabled: bool) -> None:
    """Enable or disable VTT."""
    set_setting("vtt.enabled", enabled)


def set_vtt_downloaded(downloaded: bool) -> None:
    """Mark VTT model as downloaded."""
    set_setting("vtt.downloaded", downloaded)


# Telegram state helpers (replaces bot_state.json)
def get_telegram_state() -> dict:
    """Get Telegram bot state."""
    state = load_state()
    return state.get("telegram", DEFAULT_STATE["telegram"])


def set_telegram_chat(chat_id: int, user: str) -> None:
    """Set Telegram chat info."""
    from datetime import datetime

    state = load_state()
    if "telegram" not in state:
        state["telegram"] = {}

    state["telegram"]["chat_id"] = chat_id
    state["telegram"]["user"] = user
    if not state["telegram"].get("registered_at"):
        state["telegram"]["registered_at"] = datetime.now().isoformat()

    save_state(state)


# Migration helper
def migrate_existing_configs() -> dict:
    """
    Migrate existing config files to new unified format.
    Returns dict with migration status.

    Deprecated: this migration runs once for users upgrading from pre-v1
    config format. Will be removed in a future version.
    """
    import json

    results = {
        "migrated": [],
        "skipped": [],
        "errors": [],
    }

    settings = load_settings()
    state = load_state()

    # 1. Migrate bot_state.json -> state.yaml
    old_state = CONFIG_DIR / "bot_state.json"
    if old_state.exists():
        try:
            old_data = json.loads(old_state.read_text())

            # Copy to new state format
            if "telegram" not in state:
                state["telegram"] = {}

            if old_data.get("chat_id"):
                state["telegram"]["chat_id"] = old_data["chat_id"]
            if old_data.get("user"):
                state["telegram"]["user"] = old_data["user"]
            if old_data.get("registered_at"):
                state["telegram"]["registered_at"] = old_data["registered_at"]

            # Also set owner from old state
            if old_data.get("chat_id") and not settings.get("access", {}).get("owner_id"):
                if "access" not in settings:
                    settings["access"] = {}
                settings["access"]["owner_id"] = old_data["chat_id"]

            save_state(state)
            old_state.rename(old_state.with_suffix(".json.bak"))
            results["migrated"].append("bot_state.json")
        except Exception as e:
            results["errors"].append(f"bot_state.json: {e}")
    else:
        results["skipped"].append("bot_state.json (not found)")

    # 2. Migrate vtt.json -> settings.yaml
    old_vtt = CONFIG_DIR / "vtt.json"
    if old_vtt.exists():
        try:
            old_data = json.loads(old_vtt.read_text())

            # Merge into settings
            if "vtt" not in settings:
                settings["vtt"] = {}

            for key in [
                "enabled",
                "model",
                "device",
                "compute_type",
                "language",
                "beam_size",
                "vad_filter",
                "downloaded",
            ]:
                if key in old_data:
                    settings["vtt"][key] = old_data[key]

            old_vtt.rename(old_vtt.with_suffix(".json.bak"))
            results["migrated"].append("vtt.json")
        except Exception as e:
            results["errors"].append(f"vtt.json: {e}")
    else:
        results["skipped"].append("vtt.json (not found)")

    save_settings(settings)

    return results


# Export the main interface
__all__ = [
    "load_settings",
    "save_settings",
    "load_state",
    "save_state",
    "reload",
    "get_secret",
    "get_setting",
    "set_setting",
    "get_allowed_user_ids",
    "is_authorized",
    "bootstrap_owner_if_needed",
    "add_user",
    "remove_user",
    "set_owner",
    "get_vtt_config",
    "set_vtt_enabled",
    "set_vtt_downloaded",
    "get_telegram_state",
    "set_telegram_chat",
    "migrate_existing_configs",
    "SETTINGS_FILE",
    "STATE_FILE",
    "ENV_FILE",
]
