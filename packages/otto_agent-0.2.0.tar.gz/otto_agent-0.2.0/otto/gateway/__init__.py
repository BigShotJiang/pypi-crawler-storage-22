"""
Otto Security & Control Gateway (Pillar 3).

This package defines the native MCP bridge interface contract -- the single
trust boundary through which ALL backend tool access is mediated.

All public symbols are re-exported here for backward compatibility:
    from otto.gateway import LocalGateway, GatewayPolicy, ...
"""

from __future__ import annotations

import logging

from otto.gateway.audit import AuditCallback
from otto.gateway.boundaries import AgentBoundaries
from otto.gateway.connections import StdioConnection
from otto.gateway.models import ToolRequest, ToolResponse
from otto.gateway.permissions import PermissionCallback, TelegramPermissionCallback
from otto.gateway.policy import GatewayPolicy, PolicyVerdict, ServerPolicy
from otto.gateway.ratelimit import CooldownTracker, QuotaTracker, RateLimiter, TurnTracker
from otto.gateway.server import (
    Gateway,
    LocalGateway,
    load_gateway_policy,
)
from otto.gateway.server import (
    _extract_mcp_text as _extract_mcp_text,
)

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Gateway singleton
# ---------------------------------------------------------------------------

_gateway: LocalGateway | None = None


def _maybe_enable_extended_policy(gw: LocalGateway) -> None:
    """Enable extended policy engine if rules/plugins/packs are configured."""
    from otto.config import get_setting

    policy_raw = get_setting("gateway.policy") or {}
    has_rules = bool(policy_raw.get("rules"))
    has_plugins = bool(policy_raw.get("plugins", {}).get("enabled", False))
    has_packs = bool(policy_raw.get("packs"))

    if has_rules or has_plugins or has_packs:
        gw.enable_extended_policy(policy_raw)
        log.info(
            "Extended policy engine enabled: rules=%s, plugins=%s, packs=%s",
            has_rules,
            has_plugins,
            has_packs,
        )


def get_gateway() -> LocalGateway:
    """
    Get the module-level gateway singleton.

    Lazily initializes from settings.yaml on first call. Thread-safe
    (though typically called from a single async event loop).

    The gateway is initialized with a TelegramPermissionCallback so that
    PROMPT verdicts send approval buttons to Telegram.

    Returns:
        The shared LocalGateway instance.
    """
    global _gateway
    if _gateway is None:
        policy = load_gateway_policy()
        _gateway = LocalGateway(
            policy,
            permission_callback=TelegramPermissionCallback(),
        )
        # Enable extended policy engine if rules/plugins/packs are configured
        _maybe_enable_extended_policy(_gateway)
        log.info(
            "Gateway initialized: %d server(s), kill_switch=%s, dry_run=%s, quota=%s",
            len(policy.servers),
            policy.kill_switch,
            policy.dry_run,
            policy.max_calls_per_session or "unlimited",
        )
    return _gateway


async def close_gateway() -> None:
    """Close the gateway singleton and release all connections."""
    global _gateway
    if _gateway is not None:
        await _gateway.close()
        _gateway = None
        log.info("Gateway closed")


def reload_gateway() -> LocalGateway:
    """
    Reload gateway policy from settings.yaml and create a new instance.

    Useful for SIGHUP config reload. The old gateway is NOT closed here --
    callers should ``await close_gateway()`` first if the old instance
    has active connections.

    Returns:
        The new LocalGateway instance (also stored as singleton).
    """
    global _gateway
    policy = load_gateway_policy()
    _gateway = LocalGateway(
        policy,
        permission_callback=TelegramPermissionCallback(),
    )
    # Enable extended policy engine if rules/plugins/packs are configured
    _maybe_enable_extended_policy(_gateway)
    log.info(
        "Gateway reloaded: %d server(s), kill_switch=%s, dry_run=%s, quota=%s",
        len(policy.servers),
        policy.kill_switch,
        policy.dry_run,
        policy.max_calls_per_session or "unlimited",
    )
    return _gateway


def activate_kill_switch() -> None:
    """
    Activate the MCP kill switch — instantly revoke ALL tool access.

    This persists to settings.yaml AND takes effect immediately on the
    in-memory gateway singleton. All subsequent tool requests are denied.
    """
    from otto.config import set_setting

    set_setting("gateway.kill_switch", True)
    gw = get_gateway()
    gw._policy.kill_switch = True
    log.warning("MCP KILL SWITCH ACTIVATED — all tool access revoked")


def deactivate_kill_switch() -> None:
    """
    Deactivate the MCP kill switch — restore normal tool access.

    Clears the kill_switch flag in settings.yaml and on the
    in-memory gateway singleton.
    """
    from otto.config import set_setting

    set_setting("gateway.kill_switch", False)
    gw = get_gateway()
    gw._policy.kill_switch = False
    log.info("MCP kill switch deactivated — tool access restored")


def is_kill_switch_active() -> bool:
    """Check if the MCP kill switch is currently active."""
    return get_gateway()._policy.kill_switch


__all__ = [
    # Core types
    "PolicyVerdict",
    "ToolRequest",
    "ToolResponse",
    "ServerPolicy",
    "GatewayPolicy",
    # Protocols
    "PermissionCallback",
    "AuditCallback",
    # Gateway
    "Gateway",
    "LocalGateway",
    # Rate limiting & quota
    "RateLimiter",
    "QuotaTracker",
    # Agent boundaries (Phase 4)
    "AgentBoundaries",
    "TurnTracker",
    "CooldownTracker",
    # Singleton
    "get_gateway",
    "close_gateway",
    "reload_gateway",
    # Kill switch
    "activate_kill_switch",
    "deactivate_kill_switch",
    "is_kill_switch_active",
    # Permission callbacks
    "TelegramPermissionCallback",
    # Internal (for testing)
    "StdioConnection",
    # Helpers
    "load_gateway_policy",
]
