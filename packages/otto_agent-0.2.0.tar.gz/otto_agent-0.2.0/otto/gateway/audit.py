from __future__ import annotations

from typing import Protocol, runtime_checkable

from otto.gateway.models import ToolRequest, ToolResponse


@runtime_checkable
class AuditCallback(Protocol):
    """
    Callback for audit logging of gateway operations.

    Implementations can log to file, database, or external service.
    The gateway calls this for every tool invocation (if audit is enabled).
    """

    async def __call__(
        self,
        request: ToolRequest,
        response: ToolResponse,
    ) -> None:
        """
        Record a tool invocation in the audit log.

        Args:
            request: The original tool request
            response: The gateway's response (includes verdict)
        """
        ...
