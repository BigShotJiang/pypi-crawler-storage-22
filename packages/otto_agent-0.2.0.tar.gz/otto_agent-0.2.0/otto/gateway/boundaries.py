from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class AgentBoundaries:
    """
    Configurable boundaries for agent tool usage.

    Controls how many tool calls an agent can make per turn, per session,
    and enforces cooldown periods between calls to prevent runaway behavior.

    Config schema (settings.yaml):
        gateway:
          boundaries:
            max_calls_per_turn: 50       # Max tool calls in a single agent turn
            turn_timeout: 300            # Seconds before a turn is auto-expired
            cooldown_seconds: 0          # Min seconds between calls to same tool
            server_cooldowns:            # Per-server cooldown overrides
              filesystem: 0.5
              exa: 2.0
    """

    # Max tool calls per agent turn (0 = unlimited)
    max_calls_per_turn: int = 0
    # Seconds before a turn is considered expired (0 = no timeout)
    turn_timeout: int = 0
    # Global cooldown between calls to the same server.tool (seconds, 0 = none)
    cooldown_seconds: float = 0.0
    # Per-server cooldown overrides (server_name -> seconds)
    server_cooldowns: dict[str, float] = field(default_factory=dict)

    @classmethod
    def from_config(cls, config: dict[str, Any] | None) -> AgentBoundaries:
        """Load from settings.yaml gateway.boundaries section."""
        if not config:
            return cls()
        return cls(
            max_calls_per_turn=int(config.get("max_calls_per_turn", 0)),
            turn_timeout=int(config.get("turn_timeout", 0)),
            cooldown_seconds=float(config.get("cooldown_seconds", 0)),
            server_cooldowns={
                str(k): float(v) for k, v in (config.get("server_cooldowns") or {}).items()
            },
        )
