from __future__ import annotations

import asyncio
import json
import logging
import os
from typing import Any

log = logging.getLogger(__name__)

_MCP_PROTOCOL_VERSION = "2024-11-05"
_MCP_CLIENT_INFO = {"name": "otto", "version": "1.0"}
_DEFAULT_TOOL_TIMEOUT = 30.0  # seconds
_PROCESS_SHUTDOWN_TIMEOUT = 5.0  # seconds


class StdioConnection:
    """
    JSON-RPC 2.0 connection to an MCP server over stdio.

    Spawns the server as a subprocess and communicates via stdin/stdout.
    Handles the MCP initialize handshake and provides ``call_tool()`` for
    tool invocations.

    Adapted from ``otto.backends.codex.JsonRpcConnection`` with MCP-specific
    protocol additions (initialize handshake, tools/call method, content
    array response format).
    """

    def __init__(self, proc: asyncio.subprocess.Process, server_name: str):
        self._proc = proc
        self._server_name = server_name
        self._request_id = 0
        self._pending: dict[int, asyncio.Future[dict[str, Any]]] = {}
        self._reader_task: asyncio.Task[None] | None = None
        self._closed = False
        self._initialized = False

    @classmethod
    async def connect(
        cls,
        server_name: str,
        command: str,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
    ) -> StdioConnection:
        """
        Spawn an MCP server subprocess and perform the initialize handshake.

        Args:
            server_name: Identifier for logging/pooling
            command: Executable to run
            args: Command-line arguments
            env: Extra environment variables (merged with current env)

        Returns:
            Ready-to-use StdioConnection

        Raises:
            RuntimeError: If the subprocess fails to start or handshake fails
        """
        full_env = dict(os.environ)
        if env:
            full_env.update(env)

        try:
            proc = await asyncio.create_subprocess_exec(
                command,
                *(args or []),
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=full_env,
            )
        except (FileNotFoundError, PermissionError, OSError) as exc:
            raise RuntimeError(f"Failed to start MCP server '{server_name}': {exc}") from exc

        conn = cls(proc, server_name)
        conn._reader_task = asyncio.create_task(conn._read_loop())
        await conn._initialize()
        return conn

    @property
    def alive(self) -> bool:
        """Whether the subprocess is still running."""
        return not self._closed and self._proc.returncode is None

    async def _read_loop(self) -> None:
        """Route JSON-RPC responses to pending futures."""
        assert self._proc.stdout is not None

        while not self._closed:
            try:
                line = await self._proc.stdout.readline()
                if not line:
                    log.debug("EOF from MCP server '%s'", self._server_name)
                    break

                line_str = line.decode(errors="replace").strip()
                if not line_str:
                    continue

                if not line_str.startswith("{"):
                    log.debug(
                        "Non-JSON from MCP server '%s': %s",
                        self._server_name,
                        line_str[:200],
                    )
                    continue

                try:
                    msg = json.loads(line_str)
                except json.JSONDecodeError:
                    log.warning(
                        "Invalid JSON from MCP server '%s': %s",
                        self._server_name,
                        line_str[:100],
                    )
                    continue

                if not isinstance(msg, dict):
                    continue

                if "id" in msg:
                    request_id = msg["id"]
                    future = self._pending.pop(request_id, None)
                    if future and not future.done():
                        if "error" in msg:
                            future.set_exception(
                                RuntimeError(msg["error"].get("message", str(msg["error"])))
                            )
                        else:
                            future.set_result(msg.get("result", {}))
                # Notifications from the server are logged but not queued
                # (we don't need them for tool calls)

            except asyncio.CancelledError:
                break
            except Exception:
                log.debug(
                    "Error reading from MCP server '%s'",
                    self._server_name,
                    exc_info=True,
                )
                break

    async def send_request(
        self, method: str, params: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Send a JSON-RPC request and await the response."""
        if self._closed or self._proc.returncode is not None:
            raise RuntimeError(f"Connection to '{self._server_name}' is closed")

        self._request_id += 1
        request_id = self._request_id
        request = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
            "params": params or {},
        }

        loop = asyncio.get_running_loop()
        future: asyncio.Future[dict[str, Any]] = loop.create_future()
        self._pending[request_id] = future

        assert self._proc.stdin is not None
        try:
            self._proc.stdin.write(json.dumps(request).encode() + b"\n")
            await self._proc.stdin.drain()
        except Exception as exc:
            self._pending.pop(request_id, None)
            raise RuntimeError(f"Failed to send to '{self._server_name}': {exc}") from exc

        return await future

    async def send_notification(self, method: str, params: dict[str, Any] | None = None) -> None:
        """Send a JSON-RPC notification (no response expected)."""
        if self._closed or self._proc.returncode is not None:
            raise RuntimeError(f"Connection to '{self._server_name}' is closed")

        msg = {"jsonrpc": "2.0", "method": method, "params": params or {}}

        assert self._proc.stdin is not None
        self._proc.stdin.write(json.dumps(msg).encode() + b"\n")
        await self._proc.stdin.drain()

    async def _initialize(self) -> None:
        """Perform the MCP initialize handshake."""
        result = await self.send_request(
            "initialize",
            {
                "protocolVersion": _MCP_PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": _MCP_CLIENT_INFO,
            },
        )
        log.debug(
            "MCP server '%s' initialized: %s",
            self._server_name,
            result.get("serverInfo", {}),
        )
        await self.send_notification("notifications/initialized")
        self._initialized = True

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any],
        timeout: float = _DEFAULT_TOOL_TIMEOUT,
    ) -> dict[str, Any]:
        """
        Invoke a tool on the MCP server.

        Args:
            name: Tool name
            arguments: Tool arguments
            timeout: Seconds to wait for response

        Returns:
            MCP result dict (typically has "content" array)

        Raises:
            RuntimeError: On communication failure
            asyncio.TimeoutError: If tool doesn't respond in time
        """
        return await asyncio.wait_for(
            self.send_request("tools/call", {"name": name, "arguments": arguments}),
            timeout=timeout,
        )

    async def close(self) -> None:
        """Gracefully shut down the connection and subprocess."""
        self._closed = True

        if self._reader_task:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass

        for future in self._pending.values():
            if not future.done():
                future.cancel()
        self._pending.clear()

        if self._proc.returncode is None:
            self._proc.terminate()
            try:
                await asyncio.wait_for(self._proc.wait(), timeout=_PROCESS_SHUTDOWN_TIMEOUT)
            except asyncio.TimeoutError:
                self._proc.kill()
                await self._proc.wait()
