from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from otto.gateway.policy import PolicyVerdict


@dataclass(frozen=True)
class ToolRequest:
    """
    A request from a backend to invoke a tool through the gateway.

    This is the canonical input to the gateway's policy engine.

    Attributes:
        server: MCP server name (e.g., "filesystem", "exa", "otto")
        tool: Tool name within the server (e.g., "read_file", "write_file")
        arguments: Tool-specific arguments
        backend: Name of the requesting backend (e.g., "pi", "litellm")
        context: Optional opaque context from the backend (session IDs, etc.)
    """

    server: str
    tool: str
    arguments: dict[str, Any] = field(default_factory=dict)
    backend: str = ""
    context: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ToolResponse:
    """
    Result returned by the gateway after tool execution.

    Attributes:
        success: Whether the tool executed successfully
        output: Tool output (text content)
        error: Error message if success is False
        verdict: The policy verdict that was applied
        audit_id: Unique ID for this operation in the audit log
    """

    success: bool
    output: str
    error: str | None = None
    verdict: PolicyVerdict = PolicyVerdict.ALLOW
    audit_id: str | None = None
