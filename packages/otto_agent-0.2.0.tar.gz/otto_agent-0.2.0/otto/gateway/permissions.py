from __future__ import annotations

import asyncio
import logging
from typing import Protocol, runtime_checkable

from otto.gateway.models import ToolRequest

log = logging.getLogger(__name__)


@runtime_checkable
class PermissionCallback(Protocol):
    """
    Callback for prompting the user on sensitive operations.

    Implementations should present the operation to the user and return
    True (allow) or False (deny). This is used when a policy verdict
    is PROMPT.

    The gateway calls this when:
    - A tool invocation hits a permission rule set to "prompt"
    - A safeguard detects a potentially dangerous operation that the
      user may want to allow on a case-by-case basis
    """

    async def __call__(
        self,
        request: ToolRequest,
        reason: str,
    ) -> bool:
        """
        Ask the user whether to allow a tool invocation.

        Args:
            request: The tool request being evaluated
            reason: Human-readable explanation of why permission is needed

        Returns:
            True to allow, False to deny
        """
        ...


class TelegramPermissionCallback:
    """
    Permission callback that sends Telegram inline-keyboard buttons
    and waits for the user to approve or deny.

    Uses Otto's send_buttons MCP tool to render the approval UI and
    polls for the callback response.
    """

    _pending: dict[str, asyncio.Future[bool]] = {}

    def __init__(self, timeout: float = 120.0):
        self._timeout = timeout

    async def __call__(self, request: ToolRequest, reason: str) -> bool:
        """Send approval buttons to Telegram and wait for user response."""
        import uuid

        from otto.mcp_tools.platform import send_buttons

        request_id = uuid.uuid4().hex[:12]
        loop = asyncio.get_running_loop()
        future: asyncio.Future[bool] = loop.create_future()
        TelegramPermissionCallback._pending[request_id] = future

        text = (
            f"🔐 <b>Permission Required</b>\n\n"
            f"<b>Tool:</b> <code>{request.server}.{request.tool}</code>\n"
            f"<b>Reason:</b> {reason}\n"
            f"<b>Backend:</b> {request.backend or 'unknown'}"
        )

        buttons = [
            {"label": "✅ Allow", "callback_data": f"gw_permit:{request_id}:allow"},
            {"label": "❌ Deny", "callback_data": f"gw_permit:{request_id}:deny"},
        ]

        result = await send_buttons(text=text, buttons=buttons, columns=2)

        if not result.get("success"):
            log.warning("Failed to send permission prompt: %s", result.get("error"))
            # Fall back to deny when we can't reach the user
            TelegramPermissionCallback._pending.pop(request_id, None)
            return False

        try:
            return await asyncio.wait_for(future, timeout=self._timeout)
        except asyncio.TimeoutError:
            log.warning(
                "Permission request timed out for %s.%s (request_id=%s)",
                request.server,
                request.tool,
                request_id,
            )
            return False
        finally:
            TelegramPermissionCallback._pending.pop(request_id, None)

    @classmethod
    def resolve(cls, request_id: str, allowed: bool) -> bool:
        """
        Resolve a pending permission request (called from callback handler).

        Args:
            request_id: The request ID from the callback_data
            allowed: True to allow, False to deny

        Returns:
            True if the request was found and resolved, False if not found
        """
        future = cls._pending.get(request_id)
        if future is not None and not future.done():
            future.set_result(allowed)
            return True
        return False
