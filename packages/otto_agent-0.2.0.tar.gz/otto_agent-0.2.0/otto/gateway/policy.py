from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from otto.policy import PolicyConfig, ServerToolPolicy
from otto.safeguards import SafeguardConfig
from otto.gateway.boundaries import AgentBoundaries


class PolicyVerdict(Enum):
    """Result of a gateway policy check."""

    ALLOW = "allow"
    DENY = "deny"
    PROMPT = "prompt"  # Ask user before proceeding


@dataclass
class ServerPolicy:
    """
    Policy for a single MCP server.

    Defines which tools are accessible and how the server connects.

    Attributes:
        name: Server identifier
        enabled: Whether this server is active
        transport: Connection config (type, command/url, args, env, headers)
        builtin: True for Otto's built-in tools (no external transport)
        allowed_tools: Whitelist of tool names. None = all tools allowed.
        blocked_tools: Blacklist of tool names. Applied after allowed_tools.
    """

    name: str
    enabled: bool = True
    transport: dict[str, Any] = field(default_factory=dict)
    builtin: bool = False
    allowed_tools: list[str] | None = None
    blocked_tools: list[str] = field(default_factory=list)

    def is_tool_allowed(self, tool_name: str) -> bool:
        """
        Check if a specific tool is allowed by this server's policy.

        Rules applied in order:
        1. If server is disabled, nothing is allowed.
        2. If blocked_tools contains the tool, deny.
        3. If allowed_tools is set and tool is not in it, deny.
        4. Otherwise, allow.
        """
        if not self.enabled:
            return False
        if tool_name in self.blocked_tools:
            return False
        if self.allowed_tools is not None and tool_name not in self.allowed_tools:
            return False
        return True


@dataclass
class GatewayPolicy:
    """
    Complete gateway policy loaded from user configuration.

    This is the single source of truth for what agents can and cannot do.

    Attributes:
        servers: Map of server name -> ServerPolicy
        safeguards: SafeguardConfig for path/command protection
        permissions: Map of operation category -> PolicyVerdict
        audit_enabled: Whether to log operations
        audit_log_allowed: Whether to log allowed operations (not just denials)
        audit_log_tool_args: Whether to include tool arguments in audit log
        kill_switch: When True, ALL MCP access is instantly revoked
        allowed_paths: List of directory prefixes agents may access.
            If non-empty, file operations outside these directories are denied.
            Works as a complement to blocked_paths (safeguards): blocked_paths
            always deny, allowed_paths constrains what's reachable.
    """

    servers: dict[str, ServerPolicy] = field(default_factory=dict)
    safeguards: SafeguardConfig = field(default_factory=SafeguardConfig)
    permissions: dict[str, PolicyVerdict] = field(default_factory=dict)
    audit_enabled: bool = True
    audit_log_allowed: bool = True
    audit_log_tool_args: bool = False
    kill_switch: bool = False
    allowed_paths: list[str] = field(default_factory=list)
    # Rate limiting: max calls per minute per server (0 = unlimited)
    rate_limits: dict[str, int] = field(default_factory=dict)
    # Rate limiting per tool: "server.tool" -> max per minute (0 = unlimited)
    tool_rate_limits: dict[str, int] = field(default_factory=dict)
    # Budget/quota: max total tool calls per session (0 = unlimited)
    max_calls_per_session: int = 0
    # Dry-run: log tool calls but don't execute
    dry_run: bool = False
    # Granular tool policy configuration (Phase 3)
    policy_config: PolicyConfig = field(default_factory=PolicyConfig)
    # Agent behavior boundaries (Phase 4)
    boundaries: AgentBoundaries = field(default_factory=lambda: AgentBoundaries())

    @classmethod
    def from_config(cls, config: dict[str, Any] | None) -> GatewayPolicy:
        """
        Load gateway policy from settings.yaml gateway section.

        Args:
            config: The 'gateway' dict from settings.yaml, or None for defaults.

        Returns:
            Fully resolved GatewayPolicy with defaults applied.
        """
        if not config:
            return cls()

        # Parse servers (with catalog resolution)
        servers: dict[str, ServerPolicy] = {}
        for name, srv_conf in (config.get("servers") or {}).items():
            if not isinstance(srv_conf, dict):
                continue

            # Resolve from_catalog references
            if "from_catalog" in srv_conf:
                from otto.catalog import resolve_from_catalog

                srv_conf = resolve_from_catalog(name, srv_conf)

            servers[name] = ServerPolicy(
                name=name,
                enabled=srv_conf.get("enabled", True),
                transport=srv_conf.get("transport", {}),
                builtin=srv_conf.get("builtin", False),
                allowed_tools=srv_conf.get("allowed_tools"),
                blocked_tools=srv_conf.get("blocked_tools", []),
            )

        # Build safeguards from gateway config + defaults
        extra_paths = config.get("blocked_paths", [])
        extra_patterns = config.get("blocked_commands", [])
        safeguards = SafeguardConfig(
            enabled=True,
            protected_paths=extra_paths,  # SafeguardConfig merges with defaults
            blocked_patterns=extra_patterns,
        )

        # Parse permissions
        permission_map = {
            "auto": PolicyVerdict.ALLOW,
            "allow": PolicyVerdict.ALLOW,
            "prompt": PolicyVerdict.PROMPT,
            "deny": PolicyVerdict.DENY,
        }
        permissions: dict[str, PolicyVerdict] = {}
        for op, verdict_str in (config.get("permissions") or {}).items():
            verdict = permission_map.get(str(verdict_str).lower(), PolicyVerdict.ALLOW)
            permissions[op] = verdict

        # Audit config
        audit_conf = config.get("audit", {})

        # Kill switch — instant MCP revocation
        kill_switch = bool(config.get("kill_switch", False))

        # Allowed paths — constrain file access to these directories
        allowed_paths = config.get("allowed_paths", [])

        # Rate limits per server: {server_name: max_calls_per_minute}
        rate_limits: dict[str, int] = {}
        for name, srv_conf in (config.get("servers") or {}).items():
            if isinstance(srv_conf, dict):
                limit = srv_conf.get("max_calls_per_minute", 0)
                if limit and int(limit) > 0:
                    rate_limits[name] = int(limit)

        # Rate limits per tool: {"server.tool": max_calls_per_minute}
        tool_rate_limits: dict[str, int] = {}
        for name, srv_conf in (config.get("servers") or {}).items():
            if isinstance(srv_conf, dict):
                tool_limits = srv_conf.get("tool_rate_limits", {})
                for tool_name, limit in tool_limits.items():
                    if limit and int(limit) > 0:
                        tool_rate_limits[f"{name}.{tool_name}"] = int(limit)

        # Budget/quota: max total calls per session
        max_calls_per_session = int(config.get("max_calls_per_session", 0))

        # Dry-run mode
        dry_run = bool(config.get("dry_run", False))

        # Granular tool policy (Phase 3)
        policy_config = PolicyConfig.from_config(config.get("policy"))

        # Inherit recommended_policy from catalog entries (Phase 3, subtask 4)
        # Catalog policies act as defaults — user-defined server policies take precedence.

        for name, srv_conf in (config.get("servers") or {}).items():
            if not isinstance(srv_conf, dict):
                continue
            # Resolve catalog first so recommended_policy is available
            resolved = srv_conf
            if "from_catalog" in srv_conf:
                from otto.catalog import resolve_from_catalog

                resolved = resolve_from_catalog(name, srv_conf)
            rec = resolved.get("recommended_policy")
            if rec and isinstance(rec, dict) and name not in policy_config.servers:
                policy_config.servers[name] = ServerToolPolicy.from_config(rec)

        # Agent behavior boundaries (Phase 4)
        boundaries = AgentBoundaries.from_config(config.get("boundaries"))

        return cls(
            servers=servers,
            safeguards=safeguards,
            permissions=permissions,
            audit_enabled=audit_conf.get("enabled", True),
            audit_log_allowed=audit_conf.get("log_allowed", True),
            audit_log_tool_args=audit_conf.get("log_tool_args", False),
            kill_switch=kill_switch,
            allowed_paths=allowed_paths,
            rate_limits=rate_limits,
            tool_rate_limits=tool_rate_limits,
            max_calls_per_session=max_calls_per_session,
            dry_run=dry_run,
            policy_config=policy_config,
            boundaries=boundaries,
        )
