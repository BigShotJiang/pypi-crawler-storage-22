from __future__ import annotations

import time
from collections import defaultdict, deque

from otto.gateway.boundaries import AgentBoundaries


class TurnTracker:
    """
    Track tool calls within agent turns for boundary enforcement.

    A "turn" is a burst of tool calls from a single agent invocation.
    The turn auto-resets after ``turn_timeout`` seconds of inactivity.
    """

    def __init__(self, boundaries: AgentBoundaries):
        self._boundaries = boundaries
        self._turn_count: int = 0
        self._turn_start: float = 0.0
        self._last_call: float = 0.0

    @property
    def turn_count(self) -> int:
        """Number of calls in the current turn."""
        self._maybe_reset_turn()
        return self._turn_count

    def check(self) -> bool:
        """Check if another call is allowed in this turn."""
        self._maybe_reset_turn()
        max_per_turn = self._boundaries.max_calls_per_turn
        if max_per_turn <= 0:
            return True
        return self._turn_count < max_per_turn

    def record(self) -> None:
        """Record a tool call in the current turn."""
        now = time.monotonic()
        if self._turn_count == 0:
            self._turn_start = now
        self._turn_count += 1
        self._last_call = now

    def reset(self) -> None:
        """Manually reset the turn counter."""
        self._turn_count = 0
        self._turn_start = 0.0
        self._last_call = 0.0

    def _maybe_reset_turn(self) -> None:
        """Auto-reset turn if timeout has elapsed since last call."""
        timeout = self._boundaries.turn_timeout
        if timeout <= 0 or self._turn_count == 0:
            return
        now = time.monotonic()
        if now - self._last_call > timeout:
            self.reset()


class CooldownTracker:
    """
    Enforce minimum time between tool calls to the same server/tool.

    Prevents rapid-fire repeated calls that could indicate runaway behavior.
    """

    def __init__(self, boundaries: AgentBoundaries):
        self._boundaries = boundaries
        # key -> last call timestamp (monotonic)
        self._last_calls: dict[str, float] = {}

    def check(self, server: str, tool: str) -> tuple[bool, float]:
        """
        Check if a call is allowed given cooldown constraints.

        Returns:
            (allowed, wait_seconds) — if not allowed, wait_seconds > 0
        """
        cooldown = self._boundaries.server_cooldowns.get(server, self._boundaries.cooldown_seconds)
        if cooldown <= 0:
            return True, 0.0

        key = f"{server}.{tool}"
        last = self._last_calls.get(key)
        if last is None:
            return True, 0.0

        elapsed = time.monotonic() - last
        if elapsed >= cooldown:
            return True, 0.0

        return False, cooldown - elapsed

    def record(self, server: str, tool: str) -> None:
        """Record a tool call timestamp."""
        key = f"{server}.{tool}"
        self._last_calls[key] = time.monotonic()

    def reset(self) -> None:
        """Clear all cooldown state."""
        self._last_calls.clear()


class RateLimiter:
    """
    Sliding-window rate limiter for tool calls.

    Tracks timestamps of recent calls per key (server or server.tool)
    and enforces max-calls-per-minute limits.
    """

    def __init__(self) -> None:
        # key -> deque of timestamps (monotonic seconds)
        self._windows: dict[str, deque[float]] = defaultdict(deque)

    def check(self, key: str, max_per_minute: int) -> bool:
        """
        Check if a call is allowed under the rate limit.

        Returns True if allowed, False if rate-limited.
        Does NOT record the call — call ``record()`` after successful execution.
        """
        if max_per_minute <= 0:
            return True

        now = time.monotonic()
        window = self._windows[key]
        cutoff = now - 60.0

        # Purge old entries
        while window and window[0] < cutoff:
            window.popleft()

        return len(window) < max_per_minute

    def record(self, key: str) -> None:
        """Record a call for rate-limiting purposes."""
        self._windows[key].append(time.monotonic())

    def remaining(self, key: str, max_per_minute: int) -> int:
        """Return how many calls remain in the current window."""
        if max_per_minute <= 0:
            return -1  # unlimited

        now = time.monotonic()
        window = self._windows[key]
        cutoff = now - 60.0
        while window and window[0] < cutoff:
            window.popleft()

        return max(0, max_per_minute - len(window))


class QuotaTracker:
    """
    Session-level quota tracker.

    Enforces a hard cap on total tool calls per gateway lifetime (session).
    """

    def __init__(self, max_calls: int = 0) -> None:
        self._max = max_calls  # 0 = unlimited
        self._count = 0

    @property
    def count(self) -> int:
        return self._count

    @property
    def max_calls(self) -> int:
        return self._max

    @property
    def remaining(self) -> int:
        if self._max <= 0:
            return -1  # unlimited
        return max(0, self._max - self._count)

    def check(self) -> bool:
        """Return True if a call is allowed."""
        if self._max <= 0:
            return True
        return self._count < self._max

    def record(self) -> None:
        """Record a successful tool call."""
        self._count += 1
