"""
Otto Security & Control Gateway (Pillar 3).

This module defines the native MCP bridge interface contract -- the single
trust boundary through which ALL backend tool access is mediated.

Architecture:
    Backends (Claude SDK, Codex, Generic) never access tools directly.
    Every tool invocation flows through the Gateway:

        Backend  -->  Gateway.request_tool()  -->  Policy check  -->  Executor
                                                       |
                                                  DENY / ALLOW
                                                       |
                                              PermissionCallback
                                              (if sensitive op)

    For Claude SDK specifically, a Gateway Proxy MCP Server
    (otto.mcp_gateway_proxy) acts as the intermediary:

        Claude SDK --> stdio --> GatewayProxyServer --> gateway.request_tool()
                                                             |
                                                     Policy enforcement
                                                     Safeguard checks
                                                     Audit logging

    This ensures Claude SDK's native MCP connections are policy-enforced
    instead of connecting to MCP servers directly.

Security Invariants:
    1. SINGLE ENFORCEMENT POINT: All tool access goes through Gateway.
       Backends MUST NOT bypass the gateway to invoke tools directly.
    2. POLICY-FIRST: The gateway loads policy once from config. Every
       request is checked against the active policy before execution.
    3. DENY-BY-DEFAULT for unrecognized servers/tools (unless policy
       explicitly allows via allowlist or wildcard).
    4. SAFEGUARDS ARE NON-NEGOTIABLE: Default protected paths and blocked
       command patterns are always enforced, even when a tool is allowed
       by policy. Users can extend protections but cannot disable the
       catastrophic-prevention defaults without explicit opt-out.
    5. GATEWAY-LEVEL, NOT PER-CLIENT: Users define policy once in
       settings.yaml; all backends respect the same rules.
"""

from __future__ import annotations

import asyncio
import json
import logging
from abc import ABC, abstractmethod
from typing import Any

from otto.gateway.audit import AuditCallback
from otto.gateway.connections import _DEFAULT_TOOL_TIMEOUT, StdioConnection
from otto.gateway.models import ToolRequest, ToolResponse
from otto.gateway.permissions import PermissionCallback
from otto.gateway.policy import GatewayPolicy, PolicyVerdict, ServerPolicy
from otto.gateway.ratelimit import (
    CooldownTracker,
    QuotaTracker,
    RateLimiter,
    TurnTracker,
)
from otto.policy import PolicyEngine, ToolVerdict
from otto.policy_ext import ExtendedPolicyEngine

log = logging.getLogger(__name__)


class Gateway(ABC):
    """
    The Security & Control Gateway -- Otto's trust boundary.

    This is the abstract interface that all gateway implementations must
    satisfy. It mediates ALL tool access from backends to external services.

    Backends interact with the gateway through two methods:
    - request_tool(): Submit a tool invocation for policy evaluation + execution
    - check_tool(): Pre-flight check whether a tool would be allowed (no execution)

    The gateway is initialized with a GatewayPolicy and optional callbacks.
    Policy is immutable after initialization -- to change policy, create a
    new gateway instance (this prevents mid-session policy drift).

    Subclasses:
    - LocalGateway: In-process gateway for direct tool execution
    - (Future) RemoteGateway: HTTP gateway for distributed setups
    """

    def __init__(
        self,
        policy: GatewayPolicy,
        permission_callback: PermissionCallback | None = None,
        audit_callback: AuditCallback | None = None,
    ):
        self._policy = policy
        self._permission_callback = permission_callback
        self._audit_callback = audit_callback
        self._rate_limiter = RateLimiter()
        self._quota = QuotaTracker(max_calls=policy.max_calls_per_session)
        self._policy_engine = PolicyEngine(policy.policy_config)
        # Extended policy engine with expression rules + plugins (Phase 5)
        self._extended_engine: ExtendedPolicyEngine | None = None
        # Agent boundaries (Phase 4)
        self._turn_tracker = TurnTracker(policy.boundaries)
        self._cooldown_tracker = CooldownTracker(policy.boundaries)
        # Runtime-paused servers (name -> True); not persisted to config
        self._paused_servers: dict[str, bool] = {}

    @property
    def policy(self) -> GatewayPolicy:
        """The active gateway policy. Read-only after initialization."""
        return self._policy

    @property
    def policy_engine(self) -> PolicyEngine:
        """The active policy engine. Read-only after initialization."""
        return self._policy_engine

    @property
    def extended_engine(self) -> ExtendedPolicyEngine | None:
        """The extended policy engine (expressions + plugins). None if not configured."""
        return self._extended_engine

    def enable_extended_policy(self, raw_config: dict[str, Any] | None = None) -> None:
        """
        Enable the extended policy engine with expression rules and plugins.

        Called during gateway setup when the policy config contains
        'rules', 'plugins', or 'packs' sections.
        """
        if raw_config is None:
            from otto.config import get_setting

            raw_config = get_setting("gateway.policy") or {}

        self._extended_engine = ExtendedPolicyEngine(raw_config)

    @property
    def turn_tracker(self) -> TurnTracker:
        """The agent turn tracker."""
        return self._turn_tracker

    @property
    def cooldown_tracker(self) -> CooldownTracker:
        """The tool cooldown tracker."""
        return self._cooldown_tracker

    @property
    def paused_servers(self) -> dict[str, bool]:
        """Map of runtime-paused server names."""
        return dict(self._paused_servers)

    def pause_server(self, server_name: str) -> bool:
        """
        Temporarily pause a server at runtime (no config change).

        Returns True if the server was found and paused.
        """
        if server_name in self._policy.servers:
            self._paused_servers[server_name] = True
            log.info("Server '%s' paused at runtime", server_name)
            return True
        return False

    def resume_server(self, server_name: str) -> bool:
        """
        Resume a runtime-paused server.

        Returns True if the server was paused and is now resumed.
        """
        if self._paused_servers.pop(server_name, None):
            log.info("Server '%s' resumed", server_name)
            return True
        return False

    def is_server_paused(self, server_name: str) -> bool:
        """Check if a server is currently paused."""
        return self._paused_servers.get(server_name, False)

    async def request_tool(self, request: ToolRequest) -> ToolResponse:
        """
        Submit a tool invocation through the gateway.

        This is the ONLY way backends should invoke tools. The method:
        1. Checks server allowlist (is this server known and enabled?)
        2. Checks tool filtering (is this tool allowed on this server?)
        3. Checks safeguards (path protection, command blocking)
        4. Checks permission policy (auto/prompt/deny for this operation category)
        5. If PROMPT, calls the permission callback
        6. If ALLOW, delegates to the executor
        7. Logs the operation via audit callback

        Args:
            request: The tool request to evaluate and potentially execute

        Returns:
            ToolResponse with the result or denial reason

        Security note:
            This method NEVER raises exceptions for policy denials.
            Denials are returned as ToolResponse(success=False, verdict=DENY).
            Only unexpected executor errors may raise.
        """
        # Step 0: Kill switch — instantly revoke ALL MCP access
        if self._policy.kill_switch:
            response = ToolResponse(
                success=False,
                output="",
                error="MCP access revoked: kill switch is active",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 0b: Runtime-paused server check
        if self.is_server_paused(request.server):
            response = ToolResponse(
                success=False,
                output="",
                error=f"Server '{request.server}' is temporarily paused",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 0c: Agent turn boundary check
        if not self._turn_tracker.check():
            max_per_turn = self._policy.boundaries.max_calls_per_turn
            response = ToolResponse(
                success=False,
                output="",
                error=f"Turn boundary exceeded: {self._turn_tracker.turn_count}/{max_per_turn} calls this turn",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 0d: Cooldown check
        cd_allowed, cd_wait = self._cooldown_tracker.check(request.server, request.tool)
        if not cd_allowed:
            response = ToolResponse(
                success=False,
                output="",
                error=f"Cooldown active for {request.server}.{request.tool}: wait {cd_wait:.1f}s",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 1: Server allowlist
        server_policy = self._policy.servers.get(request.server)
        if server_policy is None:
            response = ToolResponse(
                success=False,
                output="",
                error=f"Server '{request.server}' is not in the allowlist",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        if not server_policy.enabled:
            response = ToolResponse(
                success=False,
                output="",
                error=f"Server '{request.server}' is disabled",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 2: Tool filtering
        if not server_policy.is_tool_allowed(request.tool):
            response = ToolResponse(
                success=False,
                output="",
                error=f"Tool '{request.tool}' is not allowed on server '{request.server}'",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 2.5: Granular tool policy evaluation (Phase 3 + Phase 5)
        # Use extended engine (expressions + plugins) if available,
        # otherwise fall back to standard engine.
        if self._extended_engine is not None:
            policy_result = self._extended_engine.evaluate(
                request.server, request.tool, request.arguments
            )
        else:
            policy_result = self._policy_engine.evaluate(
                request.server, request.tool, request.arguments
            )

        # Argument validation errors are always a hard deny
        if policy_result.arg_errors:
            response = ToolResponse(
                success=False,
                output="",
                error=f"Policy argument validation failed: {'; '.join(policy_result.arg_errors)}",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Policy engine deny verdict
        if policy_result.verdict == ToolVerdict.DENY:
            response = ToolResponse(
                success=False,
                output="",
                error=f"Denied by tool policy: {policy_result.reason}",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Policy engine rate limit (applies alongside legacy rate limits)
        if policy_result.rate_limit > 0:
            rl_key = f"policy.{request.server}.{request.tool}"
            if not self._rate_limiter.check(rl_key, policy_result.rate_limit):
                response = ToolResponse(
                    success=False,
                    output="",
                    error=f"Rate limited by tool policy: {request.server}.{request.tool} "
                    f"({policy_result.rate_limit}/min)",
                    verdict=PolicyVerdict.DENY,
                )
                await self._audit(request, response)
                return response

        # Step 3: Safeguard checks
        denial = self._check_safeguards(request)
        if denial is not None:
            await self._audit(request, denial)
            return denial

        # Step 4: Permission policy
        # Policy engine ASK verdict upgrades to PROMPT
        if policy_result.verdict == ToolVerdict.ASK:
            verdict = PolicyVerdict.PROMPT
        else:
            op_category = self._classify_operation(request)
            verdict = self._policy.permissions.get(op_category, PolicyVerdict.ALLOW)

        if verdict == PolicyVerdict.DENY:
            response = ToolResponse(
                success=False,
                output="",
                error=f"Operation category '{self._classify_operation(request)}' is denied by policy",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 5: Prompt user if needed
        if verdict == PolicyVerdict.PROMPT:
            if self._permission_callback is not None:
                reason = (
                    policy_result.reason
                    if policy_result.verdict == ToolVerdict.ASK
                    else (
                        f"Tool '{request.tool}' on '{request.server}' requires permission "
                        f"(category: {self._classify_operation(request)})"
                    )
                )
                allowed = await self._permission_callback(
                    request,
                    reason=reason,
                )
                if not allowed:
                    response = ToolResponse(
                        success=False,
                        output="",
                        error="User denied permission",
                        verdict=PolicyVerdict.DENY,
                    )
                    await self._audit(request, response)
                    return response
            else:
                # No callback available -- deny for safety
                response = ToolResponse(
                    success=False,
                    output="",
                    error="Operation requires permission but no callback is registered",
                    verdict=PolicyVerdict.DENY,
                )
                await self._audit(request, response)
                return response

        # Step 5b: Rate limiting per server
        server_limit = self._policy.rate_limits.get(request.server, 0)
        if server_limit > 0 and not self._rate_limiter.check(request.server, server_limit):
            response = ToolResponse(
                success=False,
                output="",
                error=f"Rate limited: server '{request.server}' exceeds {server_limit} calls/min",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 5c: Rate limiting per tool
        tool_key = f"{request.server}.{request.tool}"
        tool_limit = self._policy.tool_rate_limits.get(tool_key, 0)
        if tool_limit > 0 and not self._rate_limiter.check(tool_key, tool_limit):
            response = ToolResponse(
                success=False,
                output="",
                error=f"Rate limited: tool '{tool_key}' exceeds {tool_limit} calls/min",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 5d: Session quota check
        if not self._quota.check():
            response = ToolResponse(
                success=False,
                output="",
                error=f"Session quota exhausted: {self._quota.count}/{self._quota.max_calls} calls used",
                verdict=PolicyVerdict.DENY,
            )
            await self._audit(request, response)
            return response

        # Step 6: Dry-run mode — log but don't execute
        if self._policy.dry_run:
            response = ToolResponse(
                success=True,
                output=f"[DRY RUN] Would execute {request.server}.{request.tool}",
                verdict=PolicyVerdict.ALLOW,
            )
            await self._audit(request, response)
            return response

        # Step 7: Execute
        response = await self._execute(request, server_policy)

        # Record rate limit + quota + boundaries after successful execution
        if server_limit > 0:
            self._rate_limiter.record(request.server)
        if tool_limit > 0:
            self._rate_limiter.record(tool_key)
        if policy_result.rate_limit > 0:
            rl_key = f"policy.{request.server}.{request.tool}"
            self._rate_limiter.record(rl_key)
        self._quota.record()
        self._turn_tracker.record()
        self._cooldown_tracker.record(request.server, request.tool)

        # Step 8: Audit
        await self._audit(request, response)

        return response

    async def check_tool(self, request: ToolRequest) -> PolicyVerdict:
        """
        Pre-flight check: would this tool request be allowed?

        Does NOT execute the tool. Useful for backends that want to
        know ahead of time whether a tool call would succeed before
        committing to it (e.g., for SDK permission callbacks).

        Args:
            request: The tool request to evaluate

        Returns:
            PolicyVerdict indicating whether the request would be allowed
        """
        if self._policy.kill_switch:
            return PolicyVerdict.DENY

        server_policy = self._policy.servers.get(request.server)
        if server_policy is None or not server_policy.enabled:
            return PolicyVerdict.DENY

        if not server_policy.is_tool_allowed(request.tool):
            return PolicyVerdict.DENY

        # Granular tool policy (Phase 3 + Phase 5)
        if self._extended_engine is not None:
            policy_result = self._extended_engine.evaluate(
                request.server, request.tool, request.arguments
            )
        else:
            policy_result = self._policy_engine.evaluate(
                request.server, request.tool, request.arguments
            )
        if policy_result.denied:
            return PolicyVerdict.DENY
        if policy_result.needs_prompt:
            return PolicyVerdict.PROMPT

        denial = self._check_safeguards(request)
        if denial is not None:
            return PolicyVerdict.DENY

        op_category = self._classify_operation(request)
        return self._policy.permissions.get(op_category, PolicyVerdict.ALLOW)

    def get_server_tools(self, server_name: str) -> list[str] | None:
        """
        Get the list of allowed tools for a server.

        Returns None if the server allows all tools (no whitelist).
        Returns empty list if server is disabled or not found.

        Args:
            server_name: The MCP server name

        Returns:
            List of allowed tool names, None for "all", or [] for "none"
        """
        policy = self._policy.servers.get(server_name)
        if policy is None or not policy.enabled:
            return []
        return policy.allowed_tools  # None means all tools

    def list_servers(self) -> dict[str, ServerPolicy]:
        """Return all configured server policies."""
        return dict(self._policy.servers)

    def get_mcp_server_configs(self) -> dict[str, dict[str, Any]]:
        """
        Export MCP server transport configs for backend consumption.

        Returns a dict suitable for passing to Claude SDK's mcp_servers
        option or Codex's MCP config. Only includes enabled, non-builtin
        servers with transport configuration.

        Returns:
            Dict mapping server name -> transport config dict
        """
        configs: dict[str, dict[str, Any]] = {}
        for name, policy in self._policy.servers.items():
            if not policy.enabled:
                continue
            if policy.builtin:
                continue
            if not policy.transport:
                continue
            configs[name] = dict(policy.transport)
        return configs

    # -----------------------------------------------------------------------
    # Internal methods
    # -----------------------------------------------------------------------

    def _check_safeguards(self, request: ToolRequest) -> ToolResponse | None:
        """
        Check safeguards (path protection, command blocking, allowed paths).

        Returns a DENY ToolResponse if safeguards block the request,
        or None if the request passes all checks.
        """
        safeguards = self._policy.safeguards

        # Check path protection for file operations
        file_path = (
            request.arguments.get("file_path")
            or request.arguments.get("path")
            or request.arguments.get("file")
        )
        if file_path:
            # Blocked paths always deny (standard safeguards)
            if safeguards.is_path_protected(str(file_path)):
                return ToolResponse(
                    success=False,
                    output="",
                    error=f"Protected path: {file_path}",
                    verdict=PolicyVerdict.DENY,
                )

            # Allowed paths — if configured, restrict to these directories
            if self._policy.allowed_paths:
                if not self._is_path_within_allowed(str(file_path)):
                    return ToolResponse(
                        success=False,
                        output="",
                        error=f"Path outside allowed directories: {file_path}",
                        verdict=PolicyVerdict.DENY,
                    )

        # Check command blocking for shell operations
        command = request.arguments.get("command") or request.arguments.get("cmd")
        if command:
            blocked, pattern = safeguards.is_command_blocked(str(command))
            if blocked:
                return ToolResponse(
                    success=False,
                    output="",
                    error=f"Blocked command pattern: {pattern}",
                    verdict=PolicyVerdict.DENY,
                )

        return None

    def _is_path_within_allowed(self, file_path: str) -> bool:
        """
        Check if a path falls within one of the allowed directories.

        Returns True if allowed_paths is empty (no restriction) or
        if the path is under at least one allowed directory.
        """
        from pathlib import Path as _Path

        if not self._policy.allowed_paths:
            return True

        try:
            target = _Path(file_path).expanduser().resolve()
        except (ValueError, OSError):
            return False

        for allowed in self._policy.allowed_paths:
            try:
                allowed_path = _Path(allowed).expanduser().resolve()
                if target == allowed_path or allowed_path in target.parents:
                    return True
            except (ValueError, OSError):
                continue

        return False

    @staticmethod
    def _classify_operation(request: ToolRequest) -> str:
        """
        Classify a tool request into an operation category for permission lookup.

        Categories:
        - file_write: Tools that modify the filesystem
        - file_delete: Tools that remove files
        - shell_exec: Shell/command execution
        - network_access: HTTP requests, web searches, API calls

        Returns:
            Operation category string matching permissions config keys
        """
        tool = request.tool.lower()

        # File write operations
        if tool in ("write_file", "edit_file", "write", "edit", "multiedit", "patch"):
            return "file_write"

        # File delete operations
        if tool in ("delete_file", "remove", "unlink"):
            return "file_delete"

        # Shell execution
        if tool in ("bash", "shell", "exec", "commandexecution", "run_command"):
            return "shell_exec"

        # Network access
        if tool in ("web_search", "fetch", "http_request", "websearch", "webfetch"):
            return "network_access"

        # Default: no special permission needed
        return "general"

    @abstractmethod
    async def _execute(self, request: ToolRequest, server_policy: ServerPolicy) -> ToolResponse:
        """
        Execute a tool request that has passed all policy checks.

        Subclasses implement the actual MCP server communication here.

        Args:
            request: The validated tool request
            server_policy: The server's policy (includes transport config)

        Returns:
            ToolResponse with execution result
        """
        ...

    async def _audit(self, request: ToolRequest, response: ToolResponse) -> None:
        """Log the operation via the audit callback and SQLite audit DB."""
        if not self._policy.audit_enabled:
            return

        # Skip logging allowed operations if configured
        if response.verdict == PolicyVerdict.ALLOW and not self._policy.audit_log_allowed:
            return

        # Always write to structured SQLite audit log
        from otto.audit import log_tool_call

        log_tool_call(
            server=request.server,
            tool=request.tool,
            verdict=response.verdict.value,
            backend=request.backend or None,
            success=response.success,
            error=response.error,
            arguments=request.arguments if self._policy.audit_log_tool_args else None,
            dry_run=self._policy.dry_run,
        )

        if self._audit_callback is not None:
            try:
                await self._audit_callback(request, response)
            except Exception:
                log.warning("Audit callback failed", exc_info=True)
        else:
            # Default: log to Python logger
            level = logging.INFO if response.verdict == PolicyVerdict.ALLOW else logging.WARNING
            args_str = ""
            if self._policy.audit_log_tool_args:
                args_str = f" args={request.arguments}"
            log.log(
                level,
                "gateway: %s %s.%s [%s] backend=%s%s%s",
                response.verdict.value.upper(),
                request.server,
                request.tool,
                response.error or "ok",
                request.backend,
                args_str,
                f" audit_id={response.audit_id}" if response.audit_id else "",
            )


# ---------------------------------------------------------------------------
# Convenience: load gateway from Otto's config
# ---------------------------------------------------------------------------


def load_gateway_policy() -> GatewayPolicy:
    """
    Load the gateway policy from Otto's settings.yaml.

    Reads the 'gateway' section from settings and constructs a
    GatewayPolicy. If no gateway config exists, returns defaults
    (all safeguards active, no servers configured).

    Returns:
        GatewayPolicy ready for Gateway initialization
    """
    from otto.config import get_setting

    gateway_config = get_setting("gateway")
    return GatewayPolicy.from_config(gateway_config)


# ---------------------------------------------------------------------------
# Helper: extract text from MCP result
# ---------------------------------------------------------------------------


def _extract_mcp_text(result: dict[str, Any]) -> str:
    """
    Extract text output from an MCP tools/call result.

    MCP results have a ``content`` array of typed blocks. This extracts
    and concatenates all text blocks.
    """
    content = result.get("content")
    if content is None or not isinstance(content, list):
        # Some servers return a plain string or dict
        if isinstance(result, str):
            return result
        return json.dumps(result) if result else ""
    if not content:
        return ""

    parts: list[str] = []
    for block in content:
        if isinstance(block, dict) and block.get("type") == "text":
            parts.append(block.get("text", ""))
        elif isinstance(block, str):
            parts.append(block)
    return "\n".join(parts) if parts else json.dumps(content)


# ---------------------------------------------------------------------------
# LocalGateway: concrete in-process gateway
# ---------------------------------------------------------------------------


class LocalGateway(Gateway):
    """
    In-process gateway that communicates with MCP servers directly.

    Handles three transport types:
    - **stdio**: Launches MCP server as subprocess, communicates via JSON-RPC
    - **http/sse**: Connects to remote MCP server via HTTP (stub, not yet needed)
    - **builtin**: Routes to Otto's built-in tools (no subprocess)

    Maintains a connection pool for stdio servers to reuse processes across
    tool calls. Dead connections are detected and replaced automatically.

    Usage::

        policy = load_gateway_policy()
        gw = LocalGateway(policy, permission_callback=my_cb)
        response = await gw.request_tool(ToolRequest(
            server="filesystem", tool="read_file",
            arguments={"path": "/tmp/test.txt"},
        ))
        await gw.close()  # cleanup when done
    """

    def __init__(
        self,
        policy: GatewayPolicy,
        permission_callback: PermissionCallback | None = None,
        audit_callback: AuditCallback | None = None,
    ):
        super().__init__(policy, permission_callback, audit_callback)
        self._connections: dict[str, StdioConnection] = {}
        self._builtin_executors: dict[str, Any] | None = None
        self._tool_cache: dict[str, list[dict[str, Any]]] = {}

    async def _execute(self, request: ToolRequest, server_policy: ServerPolicy) -> ToolResponse:
        """
        Execute a tool request by routing to the appropriate transport.

        This method only runs AFTER all policy checks have passed.
        """
        try:
            if server_policy.builtin:
                return await self._execute_builtin(request)

            transport_type = server_policy.transport.get("type", "").lower()

            if transport_type == "stdio":
                return await self._execute_stdio(request, server_policy)
            elif transport_type in ("http", "sse"):
                return await self._execute_http(request, server_policy)
            else:
                return ToolResponse(
                    success=False,
                    output="",
                    error=f"Unknown transport type: '{transport_type}' "
                    f"for server '{server_policy.name}'",
                    verdict=PolicyVerdict.ALLOW,
                )
        except Exception as exc:
            log.error(
                "Gateway execute error for %s.%s: %s",
                request.server,
                request.tool,
                exc,
                exc_info=True,
            )
            return ToolResponse(
                success=False,
                output="",
                error=str(exc),
                verdict=PolicyVerdict.ALLOW,
            )

    async def _execute_builtin(self, request: ToolRequest) -> ToolResponse:
        """Route to Otto's built-in MCP tools."""
        if self._builtin_executors is None:
            from otto.tools.schemas import get_mcp_tool_executors

            self._builtin_executors = get_mcp_tool_executors()

        executor = self._builtin_executors.get(request.tool)
        if executor is None:
            return ToolResponse(
                success=False,
                output="",
                error=f"Unknown builtin tool: '{request.tool}'",
                verdict=PolicyVerdict.ALLOW,
            )

        result = await executor(**request.arguments)

        if isinstance(result, dict):
            success = result.get("success", True)
            if success:
                data = result.get("data")
                output = json.dumps(data) if data is not None else ""
            else:
                output = ""
            return ToolResponse(
                success=success,
                output=output,
                error=result.get("error") if not success else None,
                verdict=PolicyVerdict.ALLOW,
            )

        return ToolResponse(
            success=True,
            output=str(result) if result else "",
            verdict=PolicyVerdict.ALLOW,
        )

    async def _execute_stdio(
        self, request: ToolRequest, server_policy: ServerPolicy
    ) -> ToolResponse:
        """Execute via stdio MCP server with connection pooling."""
        conn = await self._get_connection(server_policy)

        timeout = float(server_policy.transport.get("timeout", _DEFAULT_TOOL_TIMEOUT))

        try:
            result = await conn.call_tool(request.tool, request.arguments, timeout)
        except (RuntimeError, asyncio.TimeoutError) as exc:
            # Connection may be dead -- try once with a fresh connection
            if not conn.alive:
                log.warning("MCP server '%s' died, reconnecting...", server_policy.name)
                await self._close_connection(server_policy.name)
                conn = await self._get_connection(server_policy)
                try:
                    result = await conn.call_tool(request.tool, request.arguments, timeout)
                except Exception as retry_exc:
                    return ToolResponse(
                        success=False,
                        output="",
                        error=f"MCP server '{server_policy.name}' retry failed: {retry_exc}",
                        verdict=PolicyVerdict.ALLOW,
                    )
            else:
                return ToolResponse(
                    success=False,
                    output="",
                    error=f"MCP server '{server_policy.name}' error: {exc}",
                    verdict=PolicyVerdict.ALLOW,
                )

        # Check for MCP-level isError flag
        is_error = result.get("isError", False)
        text = _extract_mcp_text(result)

        return ToolResponse(
            success=not is_error,
            output=text if not is_error else "",
            error=text if is_error else None,
            verdict=PolicyVerdict.ALLOW,
        )

    async def _execute_http(
        self, request: ToolRequest, server_policy: ServerPolicy
    ) -> ToolResponse:
        """HTTP/SSE transport stub."""
        return ToolResponse(
            success=False,
            output="",
            error=f"HTTP/SSE transport not yet implemented for server '{server_policy.name}'",
            verdict=PolicyVerdict.ALLOW,
        )

    async def _get_connection(self, server_policy: ServerPolicy) -> StdioConnection:
        """
        Get or create a stdio connection for a server.

        Reuses existing connections. If the existing connection is dead,
        closes it and creates a fresh one.
        """
        name = server_policy.name
        conn = self._connections.get(name)

        if conn is not None and conn.alive:
            return conn

        # Close dead connection if present
        if conn is not None:
            await self._close_connection(name)

        transport = server_policy.transport
        command = transport.get("command")
        if not command:
            raise RuntimeError(f"No command configured for stdio server '{name}'")

        args = transport.get("args", [])
        env = transport.get("env")

        conn = await StdioConnection.connect(name, command, args, env)
        self._connections[name] = conn
        return conn

    async def _close_connection(self, server_name: str) -> None:
        """Close and remove a single connection from the pool."""
        conn = self._connections.pop(server_name, None)
        if conn is not None:
            try:
                await conn.close()
            except Exception:
                log.debug("Error closing connection to '%s'", server_name, exc_info=True)

    async def list_tools(self, server_name: str) -> list[dict[str, Any]]:
        """
        Fetch the tools/list from an MCP server.

        Returns the raw MCP tool list (array of tool descriptors).
        Results are cached per server for the lifetime of this gateway.

        Args:
            server_name: Name of the MCP server

        Returns:
            List of MCP tool descriptors (name, description, inputSchema)

        Raises:
            RuntimeError: If the server is unknown, disabled, or has no transport
        """
        if server_name in self._tool_cache:
            return self._tool_cache[server_name]

        server_policy = self._policy.servers.get(server_name)
        if server_policy is None:
            raise RuntimeError(f"Unknown server: '{server_name}'")
        if not server_policy.enabled:
            raise RuntimeError(f"Server '{server_name}' is disabled")
        if server_policy.builtin:
            # Builtin tools are handled via Otto's tool registry, not MCP
            raise RuntimeError(f"Server '{server_name}' is builtin (use tool registry)")
        if not server_policy.transport:
            raise RuntimeError(f"Server '{server_name}' has no transport config")

        transport_type = server_policy.transport.get("type", "").lower()
        if transport_type != "stdio":
            raise RuntimeError(f"list_tools only supports stdio transport, got '{transport_type}'")

        conn = await self._get_connection(server_policy)
        result = await conn.send_request("tools/list", {})
        tools = result.get("tools", [])

        # Filter through server policy
        filtered = []
        for tool in tools:
            tool_name = tool.get("name", "")
            if server_policy.is_tool_allowed(tool_name):
                filtered.append(tool)

        self._tool_cache[server_name] = filtered
        return filtered

    async def get_server_tool_schemas(self, server_name: str) -> list[dict[str, Any]]:
        """
        Get OpenAI-format tool schemas for an MCP server's tools.

        Fetches tools/list from the server, filters through policy, and
        converts to OpenAI function-calling format. Cached per server.

        Args:
            server_name: Name of the MCP server

        Returns:
            List of OpenAI-format tool schemas ready for LLM consumption
        """
        mcp_tools = await self.list_tools(server_name)

        schemas: list[dict[str, Any]] = []
        for tool in mcp_tools:
            schema = {
                "type": "function",
                "function": {
                    "name": f"{server_name}__{tool['name']}",
                    "description": tool.get("description", ""),
                    "parameters": tool.get("inputSchema", {"type": "object", "properties": {}}),
                },
            }
            schemas.append(schema)

        return schemas

    async def close(self) -> None:
        """Close all MCP server connections. Call on shutdown."""
        names = list(self._connections.keys())
        for name in names:
            await self._close_connection(name)
