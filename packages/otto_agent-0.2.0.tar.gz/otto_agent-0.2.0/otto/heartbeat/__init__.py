"""
Otto Heartbeat - Self-monitoring system.

Heartbeat periodically checks state files for changes using hash comparison,
auto-retries failed agents with exponential backoff, and escalates to LLM
or notifies the user when intervention is needed.
"""

from .daemon import HeartbeatDaemon
from .escalate import (
    EscalationEngine,
    EscalationOutcome,
    EscalationResult,
    EscalationTier,
)
from .heartbeat import Heartbeat
from .integration import (
    get_heartbeat,
    on_agent_complete,
    on_agent_fail,
    on_agent_start,
    start_heartbeat,
    stop_heartbeat,
)
from .notify import (
    notify_completion,
    notify_diagnosis,
    notify_escalation,
    notify_exhausted,
    notify_failure,
    notify_retry,
)
from .retry import (
    PendingRetry,
    RetryDecision,
    RetryOrchestrator,
    RetryPolicy,
    RetryResult,
)
from .state import StateManager
from .triage import TriageCategory, TriageEngine, TriageResult
from .checks import CheckDefinition, get_most_overdue_check, is_heartbeat_ok, load_checks
from .types import (
    AgentState,
    AgentStatus,
    CheckState,
    ErrorSeverity,
    HeartbeatConfig,
    HeartbeatState,
    ScheduleState,
    StateChecksums,
)

__all__ = [
    # Main API
    "Heartbeat",
    # Integration hooks
    "get_heartbeat",
    "start_heartbeat",
    "stop_heartbeat",
    "on_agent_start",
    "on_agent_complete",
    "on_agent_fail",
    # Daemon
    "HeartbeatDaemon",
    # Escalation
    "EscalationEngine",
    "EscalationOutcome",
    "EscalationResult",
    "EscalationTier",
    # Notifications
    "notify_completion",
    "notify_failure",
    "notify_retry",
    "notify_exhausted",
    "notify_escalation",
    "notify_diagnosis",
    # State management
    "StateManager",
    # Retry orchestration
    "RetryOrchestrator",
    "RetryPolicy",
    "RetryDecision",
    "RetryResult",
    "PendingRetry",
    # Triage
    "TriageEngine",
    "TriageCategory",
    "TriageResult",
    # Types
    "AgentStatus",
    "ErrorSeverity",
    "AgentState",
    "ScheduleState",
    "CheckState",
    "HeartbeatState",
    "StateChecksums",
    "HeartbeatConfig",
    # User-defined checks
    "CheckDefinition",
    "load_checks",
    "get_most_overdue_check",
    "is_heartbeat_ok",
]
