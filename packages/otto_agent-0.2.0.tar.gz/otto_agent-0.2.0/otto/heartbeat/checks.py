"""
User-defined heartbeat checks.

Loads check definitions from ~/.otto/heartbeat/checks.yaml and provides
cadence-based scheduling with time window support.
"""

import logging
import re
from datetime import datetime, time, timedelta, timezone
from pathlib import Path
from typing import Optional

import yaml
from pydantic import BaseModel, Field

from otto.paths import HEARTBEAT_DIR

logger = logging.getLogger(__name__)

CHECKS_FILE = HEARTBEAT_DIR / "checks.yaml"


class CheckDefinition(BaseModel):
    """A single check definition from checks.yaml."""

    id: str
    prompt: str
    cadence: str = "1h"  # e.g., "30m", "1h", "4h", "24h"
    window: str = "always"  # e.g., "09:00-21:00" or "always"
    enabled: bool = True
    backend: str = "pi"
    notify: bool = True
    suppress_ok: bool = True  # Don't notify if result is "HEARTBEAT_OK"

    def cadence_seconds(self) -> int:
        """Parse cadence string to seconds."""
        match = re.match(r"^(\d+)(m|h|d)$", self.cadence.strip().lower())
        if not match:
            logger.warning(
                "Invalid cadence '%s' for check %s, defaulting to 1h", self.cadence, self.id
            )
            return 3600

        value, unit = int(match.group(1)), match.group(2)
        multipliers = {"m": 60, "h": 3600, "d": 86400}
        return value * multipliers[unit]

    def is_in_window(self, dt: Optional[datetime] = None) -> bool:
        """Check if the given time is within the check's time window."""
        if self.window.lower() == "always":
            return True

        dt = dt or datetime.now(timezone.utc)
        # Convert to local time for window comparison
        local_dt = dt.astimezone()
        current_time = local_dt.time()

        # Parse window like "09:00-21:00"
        match = re.match(r"^(\d{1,2}):(\d{2})-(\d{1,2}):(\d{2})$", self.window.strip())
        if not match:
            logger.warning(
                "Invalid window '%s' for check %s, treating as 'always'", self.window, self.id
            )
            return True

        start_hour, start_min, end_hour, end_min = map(int, match.groups())
        start_time = time(start_hour, start_min)
        end_time = time(end_hour, end_min)

        # Handle windows that cross midnight (e.g., "22:00-06:00")
        if start_time <= end_time:
            return start_time <= current_time <= end_time
        else:
            return current_time >= start_time or current_time <= end_time


class ChecksConfig(BaseModel):
    """Root config loaded from checks.yaml."""

    checks: list[CheckDefinition] = Field(default_factory=list)


def load_checks() -> list[CheckDefinition]:
    """Load check definitions from checks.yaml."""
    if not CHECKS_FILE.exists():
        logger.debug("No checks.yaml found at %s", CHECKS_FILE)
        return []

    try:
        content = CHECKS_FILE.read_text()
        data = yaml.safe_load(content) or {}

        # Handle empty or comment-only files
        if not data or not isinstance(data, dict):
            return []

        checks_list = data.get("checks", [])
        if not checks_list:
            return []

        config = ChecksConfig(
            checks=[CheckDefinition(**c) for c in checks_list if isinstance(c, dict)]
        )
        enabled = [c for c in config.checks if c.enabled]
        logger.debug("Loaded %d enabled checks from %s", len(enabled), CHECKS_FILE)
        return enabled

    except Exception as e:
        logger.error("Failed to load checks.yaml: %s", e)
        return []


def get_most_overdue_check(
    checks: list[CheckDefinition],
    check_states: dict,
    now: Optional[datetime] = None,
) -> Optional[CheckDefinition]:
    """
    Find the most overdue check that is within its time window.

    Uses "most overdue first" rotation to ensure fair scheduling.

    Args:
        checks: List of enabled check definitions
        check_states: Dict of check_id -> CheckState from heartbeat state
        now: Current time (defaults to UTC now)

    Returns:
        The most overdue CheckDefinition, or None if nothing is due
    """
    now = now or datetime.now(timezone.utc)
    candidates = []

    for check in checks:
        # Skip if not in time window
        if not check.is_in_window(now):
            continue

        state = check_states.get(check.id)
        cadence_secs = check.cadence_seconds()

        if state and state.last_run:
            # Normalize timezone
            last_run = state.last_run
            if last_run.tzinfo is None:
                last_run = last_run.replace(tzinfo=timezone.utc)

            # Calculate overdue amount
            due_at = last_run + timedelta(seconds=cadence_secs)
            overdue_seconds = (now - due_at).total_seconds()
        else:
            # Never run - treat as maximally overdue
            overdue_seconds = float("inf")

        if overdue_seconds >= 0:
            candidates.append((overdue_seconds, check))

    if not candidates:
        return None

    # Sort by most overdue (highest overdue_seconds first)
    candidates.sort(key=lambda x: x[0], reverse=True)
    return candidates[0][1]


def is_heartbeat_ok(output: str) -> bool:
    """Check if output indicates nothing to report."""
    if not output:
        return False

    output_lower = output.strip().lower()

    # Explicit marker
    if "heartbeat_ok" in output_lower:
        return True

    # Common "nothing to report" phrases
    ok_phrases = [
        "nothing to report",
        "no urgent",
        "no action needed",
        "no action required",
        "all clear",
        "no new",
        "no important",
        "inbox is clear",
        "no messages",
        "everything looks good",
        "no issues found",
    ]

    return any(phrase in output_lower for phrase in ok_phrases)
