"""
Heartbeat Daemon Runner.

Background asyncio task that monitors running agents via StateManager,
detecting completion, timeout, and failure conditions. Updates agent
state and provides structured logging.

Also runs user-defined checks from ~/.otto/heartbeat/checks.yaml with
cadence-based scheduling and time window support.
"""

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Callable, Optional

from .checks import CheckDefinition, get_most_overdue_check, is_heartbeat_ok, load_checks
from .state import StateManager
from .types import AgentState, AgentStatus, CheckState, ErrorSeverity

logger = logging.getLogger(__name__)


class HeartbeatDaemon:
    """
    Background daemon that monitors agent lifecycle and runs user-defined checks.

    Polls StateManager at configurable intervals to detect:
    - Agent completion (status transitioned to COMPLETED)
    - Agent timeout (running too long without update)
    - Agent failure (errors or crash detection)

    Also runs user-defined checks from checks.yaml:
    - Picks the most overdue check each poll
    - Respects time windows
    - Suppresses HEARTBEAT_OK notifications

    Example:
        daemon = HeartbeatDaemon(poll_interval=30)
        await daemon.start()
        # ... later
        await daemon.stop()
    """

    def __init__(
        self,
        state_manager: Optional[StateManager] = None,
        poll_interval: float = 30.0,
        timeout_seconds: float = 3600.0,  # 1 hour default
        on_completion: Optional[Callable[[str, AgentState], None]] = None,
        on_timeout: Optional[Callable[[str, AgentState], None]] = None,
        on_failure: Optional[Callable[[str, AgentState, str], None]] = None,
        on_check_result: Optional[Callable[[CheckDefinition, str, bool], None]] = None,
    ) -> None:
        """
        Initialize HeartbeatDaemon.

        Args:
            state_manager: StateManager instance. Creates default if None.
            poll_interval: Seconds between agent status checks.
            timeout_seconds: Max seconds an agent can run before timeout.
            on_completion: Callback for completed agents (agent_id, state).
            on_timeout: Callback for timed-out agents (agent_id, state).
            on_failure: Callback for failed agents (agent_id, state, error).
            on_check_result: Callback for check results (check, output, is_ok).
        """
        self.state_manager = state_manager or StateManager()
        self.poll_interval = poll_interval
        self.timeout_seconds = timeout_seconds

        # Callbacks
        self._on_completion = on_completion
        self._on_timeout = on_timeout
        self._on_failure = on_failure
        self._on_check_result = on_check_result

        # Internal state
        self._task: Optional[asyncio.Task] = None
        self._running = False
        self._shutdown_event: Optional[asyncio.Event] = None  # Created lazily per-loop
        self._check_running = False  # Prevents overlapping check runs

    @property
    def is_running(self) -> bool:
        """Check if daemon is currently running."""
        return self._running and self._task is not None

    async def start(self) -> None:
        """
        Start the heartbeat daemon.

        Spawns a background asyncio task that polls agents.
        Idempotent - safe to call multiple times.
        """
        if self._running:
            logger.warning("heartbeat_daemon_already_running")
            return

        self._running = True
        # Create event in the current event loop to avoid cross-loop binding issues
        self._shutdown_event = asyncio.Event()
        self._task = asyncio.create_task(self._run_loop())

        logger.info(
            "heartbeat_daemon_started",
            extra={
                "poll_interval": self.poll_interval,
                "timeout_seconds": self.timeout_seconds,
            },
        )

    async def stop(self, timeout: float = 5.0) -> None:
        """
        Stop the heartbeat daemon gracefully.

        Signals shutdown and waits for the polling loop to exit.

        Args:
            timeout: Max seconds to wait for graceful shutdown.
        """
        if not self._running:
            return

        logger.info("heartbeat_daemon_stopping")
        self._running = False
        if self._shutdown_event is not None:
            self._shutdown_event.set()

        if self._task:
            try:
                await asyncio.wait_for(self._task, timeout=timeout)
            except asyncio.TimeoutError:
                logger.warning("heartbeat_daemon_force_cancel")
                self._task.cancel()
                try:
                    await self._task
                except asyncio.CancelledError:
                    pass
            finally:
                self._task = None

        logger.info("heartbeat_daemon_stopped")

    async def _run_loop(self) -> None:
        """Main polling loop."""
        while self._running:
            try:
                await self._poll_agents()
            except Exception as e:
                logger.exception(
                    "heartbeat_poll_error",
                    extra={"error": str(e)},
                )

            # Run user-defined checks (non-blocking)
            try:
                await self._run_checks()
            except Exception as e:
                logger.exception(
                    "heartbeat_checks_error",
                    extra={"error": str(e)},
                )

            # Wait for next poll or shutdown
            try:
                await asyncio.wait_for(
                    self._shutdown_event.wait(),
                    timeout=self.poll_interval,
                )
                # Shutdown signaled
                break
            except asyncio.TimeoutError:
                # Normal timeout - continue polling
                pass

    async def _poll_agents(self) -> None:
        """
        Check status of all running agents.

        Detects completion, timeout, and failure conditions.
        Updates state and invokes callbacks as needed.
        """
        state = self.state_manager.load_state()
        now = datetime.now(timezone.utc)

        # Update last_check timestamp
        state.last_check = now
        state.next_check = now + timedelta(seconds=self.poll_interval)

        running_count = 0
        checked_count = 0

        for agent_id, agent in list(state.agents.items()):
            if agent.status not in (AgentStatus.RUNNING, AgentStatus.PENDING):
                continue

            running_count += 1
            checked_count += 1

            # Normalize datetime for comparison
            updated_at = agent.updated_at
            if updated_at.tzinfo is None:
                updated_at = updated_at.replace(tzinfo=timezone.utc)

            created_at = agent.created_at
            if created_at.tzinfo is None:
                created_at = created_at.replace(tzinfo=timezone.utc)

            # Check for timeout
            age_seconds = (now - created_at).total_seconds()
            if age_seconds > self.timeout_seconds:
                await self._handle_timeout(agent_id)
                continue

            # Check for stale agent (no update in 2x poll interval)
            stale_threshold = timedelta(seconds=self.poll_interval * 2)
            if now - updated_at > stale_threshold:
                logger.debug(
                    "heartbeat_agent_stale",
                    extra={
                        "agent_id": agent_id,
                        "last_update": updated_at.isoformat(),
                        "age_seconds": age_seconds,
                    },
                )

        # Save updated check timestamps
        self.state_manager.save_state(state)

        logger.debug(
            "heartbeat_poll_complete",
            extra={
                "running_agents": running_count,
                "checked": checked_count,
            },
        )

    async def _handle_completion(self, agent_id: str) -> None:
        """
        Process a completed agent.

        Updates state to COMPLETED and invokes callback.

        Args:
            agent_id: ID of the completed agent.
        """
        agent = self.state_manager.get_agent_state(agent_id)
        if not agent:
            logger.warning(
                "heartbeat_completion_missing_agent",
                extra={"agent_id": agent_id},
            )
            return

        now = datetime.now(timezone.utc)
        updated_agent = AgentState(
            id=agent.id,
            status=AgentStatus.COMPLETED,
            error=None,
            error_type=None,
            retry_count=agent.retry_count,
            max_retries=agent.max_retries,
            created_at=agent.created_at,
            updated_at=now,
            last_error_at=agent.last_error_at,
        )

        self.state_manager.update_agent_state(agent_id, updated_agent)

        logger.info(
            "heartbeat_agent_completed",
            extra={
                "agent_id": agent_id,
                "duration_seconds": (now - agent.created_at).total_seconds(),
            },
        )

        if self._on_completion:
            try:
                self._on_completion(agent_id, updated_agent)
            except Exception as e:
                logger.exception(
                    "heartbeat_completion_callback_error",
                    extra={"agent_id": agent_id, "error": str(e)},
                )

    async def _handle_timeout(self, agent_id: str) -> None:
        """
        Mark an agent as timed out.

        Updates state to FAILED with timeout error.

        Args:
            agent_id: ID of the timed-out agent.
        """
        agent = self.state_manager.get_agent_state(agent_id)
        if not agent:
            logger.warning(
                "heartbeat_timeout_missing_agent",
                extra={"agent_id": agent_id},
            )
            return

        now = datetime.now(timezone.utc)
        error_msg = f"Agent timed out after {self.timeout_seconds}s"

        updated_agent = AgentState(
            id=agent.id,
            status=AgentStatus.FAILED,
            error=error_msg,
            error_type=ErrorSeverity.RECOVERABLE,
            retry_count=agent.retry_count,
            max_retries=agent.max_retries,
            created_at=agent.created_at,
            updated_at=now,
            last_error_at=now,
        )

        self.state_manager.update_agent_state(agent_id, updated_agent)

        logger.warning(
            "heartbeat_agent_timeout",
            extra={
                "agent_id": agent_id,
                "timeout_seconds": self.timeout_seconds,
                "age_seconds": (now - agent.created_at).total_seconds(),
            },
        )

        if self._on_timeout:
            try:
                self._on_timeout(agent_id, updated_agent)
            except Exception as e:
                logger.exception(
                    "heartbeat_timeout_callback_error",
                    extra={"agent_id": agent_id, "error": str(e)},
                )

    async def _handle_failure(self, agent_id: str, error: str) -> None:
        """
        Record an agent failure.

        Updates state to FAILED or RETRYING based on retry count.

        Args:
            agent_id: ID of the failed agent.
            error: Error message describing the failure.
        """
        agent = self.state_manager.get_agent_state(agent_id)
        if not agent:
            logger.warning(
                "heartbeat_failure_missing_agent",
                extra={"agent_id": agent_id},
            )
            return

        now = datetime.now(timezone.utc)
        new_retry_count = agent.retry_count + 1

        # Determine if we should retry or mark as permanently failed
        if new_retry_count < agent.max_retries:
            new_status = AgentStatus.RETRYING
        else:
            new_status = AgentStatus.FAILED

        updated_agent = AgentState(
            id=agent.id,
            status=new_status,
            error=error,
            error_type=ErrorSeverity.UNKNOWN,
            retry_count=new_retry_count,
            max_retries=agent.max_retries,
            created_at=agent.created_at,
            updated_at=now,
            last_error_at=now,
        )

        self.state_manager.update_agent_state(agent_id, updated_agent)

        logger.error(
            "heartbeat_agent_failed",
            extra={
                "agent_id": agent_id,
                "error": error,
                "retry_count": new_retry_count,
                "max_retries": agent.max_retries,
                "will_retry": new_status == AgentStatus.RETRYING,
            },
        )

        if self._on_failure:
            try:
                self._on_failure(agent_id, updated_agent, error)
            except Exception as e:
                logger.exception(
                    "heartbeat_failure_callback_error",
                    extra={"agent_id": agent_id, "error": str(e)},
                )

    def mark_completed(self, agent_id: str) -> None:
        """
        Synchronously mark an agent as completed.

        Convenience method for external callers.

        Args:
            agent_id: ID of the agent to mark complete.
        """
        asyncio.create_task(self._handle_completion(agent_id))

    def mark_failed(self, agent_id: str, error: str) -> None:
        """
        Synchronously mark an agent as failed.

        Convenience method for external callers.

        Args:
            agent_id: ID of the agent to mark failed.
            error: Error message.
        """
        asyncio.create_task(self._handle_failure(agent_id, error))

    async def _run_checks(self) -> None:
        """
        Run user-defined checks from checks.yaml.

        Picks the most overdue check that's in its time window
        and spawns an agent to execute it.
        """
        # Prevent overlapping check runs
        if self._check_running:
            logger.debug("heartbeat_check_already_running")
            return

        # Load checks and state
        checks = load_checks()
        if not checks:
            return

        state = self.state_manager.load_state()
        now = datetime.now(timezone.utc)

        # Find most overdue check
        check = get_most_overdue_check(checks, state.checks, now)
        if not check:
            logger.debug("heartbeat_no_checks_due")
            return

        logger.info(
            "heartbeat_running_check",
            extra={"check_id": check.id, "prompt": check.prompt[:50]},
        )

        self._check_running = True
        try:
            output, success = await self._execute_check(check)

            # Update check state
            check_state = state.checks.get(check.id) or CheckState(id=check.id)
            check_state.last_run = now
            check_state.next_run = now + timedelta(seconds=check.cadence_seconds())
            check_state.run_count += 1

            is_ok = is_heartbeat_ok(output)
            if success:
                check_state.last_status = "ok" if is_ok else "action"
                check_state.last_output = output[:500] if output else None
            else:
                check_state.last_status = "error"
                check_state.last_output = output[:500] if output else None
                check_state.error_count += 1

            state.checks[check.id] = check_state
            self.state_manager.save_state(state)

            # Notify unless suppressed
            should_notify = check.notify
            if should_notify and check.suppress_ok and is_ok:
                should_notify = False
                logger.debug(
                    "heartbeat_check_suppressed",
                    extra={"check_id": check.id, "reason": "HEARTBEAT_OK"},
                )

            if should_notify and self._on_check_result:
                try:
                    self._on_check_result(check, output, is_ok)
                except Exception as e:
                    logger.exception(
                        "heartbeat_check_callback_error",
                        extra={"check_id": check.id, "error": str(e)},
                    )

            logger.info(
                "heartbeat_check_complete",
                extra={
                    "check_id": check.id,
                    "status": check_state.last_status,
                    "is_ok": is_ok,
                    "notified": should_notify,
                },
            )

        finally:
            self._check_running = False

    async def _execute_check(self, check: CheckDefinition) -> tuple[str, bool]:
        """
        Execute a check by spawning an agent.

        Args:
            check: The check definition to execute.

        Returns:
            Tuple of (output, success).
        """
        try:
            from otto import get_backend
            from otto.paths import get_workdir

            backend = get_backend(check.backend)

            # Build system prompt for heartbeat check
            system_prompt = (
                "You are running a heartbeat check. Be brief and actionable.\n"
                "If there's nothing to report, respond with: HEARTBEAT_OK\n"
                "If there IS something noteworthy, summarize it clearly.\n"
                "Format output for Telegram (HTML tags only)."
            )

            # Run synchronously in thread pool to avoid blocking
            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None,
                lambda: backend.run_sync(
                    check.prompt,
                    system_prompt,
                    get_workdir(),
                    timeout=300,  # 5 min timeout for checks
                ),
            )

            return result.output or "", result.success

        except Exception as e:
            logger.exception(
                "heartbeat_check_execute_error",
                extra={"check_id": check.id, "error": str(e)},
            )
            return str(e), False
