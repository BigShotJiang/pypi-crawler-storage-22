"""
LLM Escalation Engine (Tier 2).

When the retry engine exhausts retries or triage classifies a failure as
PERMANENT/UNKNOWN, the escalation engine spawns a diagnostic "triage agent"
that reads the failed agent's output, analyzes the error in context, and
either proposes a fix or escalates to user notification (Tier 3).

Escalation tiers:
  Tier 1 — auto-retry (handled by RetryOrchestrator)
  Tier 2 — LLM diagnostic agent (this module)
  Tier 3 — user notification (fallback when Tier 2 can't resolve)
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from .state import StateManager
from .triage import TriageCategory, TriageResult
from .types import AgentState

logger = logging.getLogger(__name__)


class EscalationTier(str, Enum):
    """Which escalation tier handled the failure."""

    RETRY = "retry"  # Tier 1: auto-retry
    LLM = "llm"  # Tier 2: diagnostic agent
    HUMAN = "human"  # Tier 3: user notification


class EscalationOutcome(str, Enum):
    """Result of an escalation attempt."""

    SPAWNED = "spawned"  # Diagnostic agent launched
    DIAGNOSED = "diagnosed"  # Agent returned a diagnosis
    FIX_SUGGESTED = "fix_suggested"  # Agent suggested a concrete fix
    TIER3_ESCALATED = "tier3_escalated"  # Fell through to user notification
    DISABLED = "disabled"  # escalate_to_llm is off
    SKIPPED = "skipped"  # Not eligible for escalation


@dataclass
class EscalationResult:
    """Result of an escalation attempt."""

    agent_id: str
    tier: EscalationTier
    outcome: EscalationOutcome
    diagnostic_agent_id: Optional[str] = None
    diagnosis: Optional[str] = None
    suggested_fix: Optional[str] = None
    error: Optional[str] = None
    escalated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


# ---------------------------------------------------------------------------
# Diagnostic prompt template
# ---------------------------------------------------------------------------

_DIAGNOSTIC_PROMPT_TEMPLATE = """\
You are a diagnostic triage agent for Otto, an AI agent orchestration system.

A spawned agent has failed and automatic retries have been exhausted. Your job
is to analyze the failure and either:
1. Suggest a concrete fix (e.g. corrected prompt, missing config, env issue)
2. Explain why the failure is unrecoverable so the user can take action

## Failed Agent Details
- Agent ID: {agent_id}
- Error Category: {category}
- Confidence: {confidence}
- Matched Pattern: {matched_pattern}
- Triage Analysis: {analysis}
- Retry Count: {retry_count}/{max_retries}

## Error Context
{error_text}

## Agent Output (last {output_lines} lines)
{agent_output}

## Instructions
1. Read the error context and agent output carefully.
2. Identify the root cause of the failure.
3. If you can suggest a fix (corrected command, config change, etc.), state it
   clearly under a "## Suggested Fix" heading.
4. If the error is truly unrecoverable (e.g. missing credentials the user must
   provide), explain what the user needs to do under a "## User Action Required"
   heading.
5. Be concise — this output will be sent as a notification.
"""


class EscalationEngine:
    """
    Tier 2 LLM escalation for agent failures.

    When retries are exhausted or triage yields PERMANENT/UNKNOWN, this engine
    spawns a lightweight diagnostic agent that analyzes the failure context and
    attempts to produce an actionable diagnosis.

    The diagnostic agent's output is parsed for fix suggestions; if none are
    found, the failure is escalated to Tier 3 (user notification).

    Example:
        engine = EscalationEngine(enabled=True)
        result = await engine.escalate(
            agent_id="agent-123",
            agent_state=agent,
            triage_result=triage,
            agent_output="/path/to/output.txt",
        )
        if result.outcome == EscalationOutcome.FIX_SUGGESTED:
            print(result.suggested_fix)
    """

    def __init__(
        self,
        enabled: bool = True,
        output_tail_lines: int = 80,
        diagnostic_backend: str = "pi",
        state_manager: Optional[StateManager] = None,
    ) -> None:
        """
        Initialize EscalationEngine.

        Args:
            enabled: Whether LLM escalation is active (maps to escalate_to_llm config).
            output_tail_lines: Max lines to read from failed agent's output file.
            diagnostic_backend: Backend to use for the diagnostic agent.
            state_manager: StateManager instance for persistence. Creates default if None.
        """
        self.enabled = enabled
        self.output_tail_lines = output_tail_lines
        self.diagnostic_backend = diagnostic_backend
        self.state_manager = state_manager or StateManager()

        # Track escalation history
        self._history: dict[str, list[EscalationResult]] = {}
        # Pending diagnostic agents: diagnostic_agent_id -> original_agent_id
        self._pending_diagnostics: dict[str, str] = {}

        # Restore from persisted state
        self._load_from_state()

    def _load_from_state(self) -> None:
        """Restore pending diagnostics from persisted state."""
        try:
            self._pending_diagnostics = self.state_manager.load_pending_diagnostics()
        except Exception:
            logger.debug("escalation_state_restore_skipped", exc_info=True)

    def _persist_diagnostics(self) -> None:
        """Persist pending diagnostics to state file."""
        self.state_manager.save_pending_diagnostics(dict(self._pending_diagnostics))

    async def escalate(
        self,
        agent_id: str,
        agent_state: AgentState,
        triage_result: TriageResult,
        agent_output: Optional[str | Path] = None,
    ) -> EscalationResult:
        """
        Attempt Tier 2 LLM escalation for a failed agent.

        Spawns a diagnostic agent to analyze the failure. If escalation is
        disabled or the failure isn't eligible, returns immediately with
        the appropriate outcome.

        Args:
            agent_id: The failed agent's ID.
            agent_state: Current state of the failed agent.
            triage_result: Triage classification of the failure.
            agent_output: Path to output file, or raw output string.

        Returns:
            EscalationResult describing what happened.
        """
        # Gate: check if escalation is enabled
        if not self.enabled:
            result = EscalationResult(
                agent_id=agent_id,
                tier=EscalationTier.HUMAN,
                outcome=EscalationOutcome.DISABLED,
            )
            self._record(result)
            return result

        # Gate: only escalate for permanent/unknown failures
        category = triage_result.category
        if isinstance(category, str):
            category = TriageCategory(category)

        if category == TriageCategory.TRANSIENT:
            result = EscalationResult(
                agent_id=agent_id,
                tier=EscalationTier.RETRY,
                outcome=EscalationOutcome.SKIPPED,
                diagnosis="Transient error — should be retried, not escalated.",
            )
            self._record(result)
            return result

        # Read agent output
        output_text = self._read_output(agent_output)

        # Build diagnostic prompt
        prompt = self._build_diagnostic_prompt(
            agent_id=agent_id,
            agent_state=agent_state,
            triage_result=triage_result,
            output_text=output_text,
        )

        # Spawn diagnostic agent
        try:
            diagnostic_agent_id = await self._spawn_diagnostic(prompt)
        except Exception as e:
            logger.exception(
                "escalation_spawn_failed",
                extra={"agent_id": agent_id, "error": str(e)},
            )
            # Fall through to Tier 3
            result = EscalationResult(
                agent_id=agent_id,
                tier=EscalationTier.HUMAN,
                outcome=EscalationOutcome.TIER3_ESCALATED,
                error=f"Failed to spawn diagnostic agent: {e}",
            )
            self._record(result)
            return result

        # Track the pending diagnostic
        self._pending_diagnostics[diagnostic_agent_id] = agent_id
        self._persist_diagnostics()

        logger.info(
            "escalation_diagnostic_spawned",
            extra={
                "agent_id": agent_id,
                "diagnostic_agent_id": diagnostic_agent_id,
                "category": str(category),
            },
        )

        result = EscalationResult(
            agent_id=agent_id,
            tier=EscalationTier.LLM,
            outcome=EscalationOutcome.SPAWNED,
            diagnostic_agent_id=diagnostic_agent_id,
        )
        self._record(result)
        return result

    def parse_diagnostic_output(
        self,
        diagnostic_agent_id: str,
        output: str,
    ) -> EscalationResult:
        """
        Parse the diagnostic agent's output to extract diagnosis and fixes.

        Called when the diagnostic agent completes. Looks for structured
        headings to determine whether a fix was suggested or if Tier 3
        escalation is needed.

        Args:
            diagnostic_agent_id: ID of the completed diagnostic agent.
            output: Raw output text from the diagnostic agent.

        Returns:
            Updated EscalationResult with diagnosis details.
        """
        original_agent_id = self._pending_diagnostics.pop(diagnostic_agent_id, diagnostic_agent_id)
        self._persist_diagnostics()

        suggested_fix = self._extract_section(output, "Suggested Fix")
        user_action = self._extract_section(output, "User Action Required")

        if suggested_fix:
            result = EscalationResult(
                agent_id=original_agent_id,
                tier=EscalationTier.LLM,
                outcome=EscalationOutcome.FIX_SUGGESTED,
                diagnostic_agent_id=diagnostic_agent_id,
                diagnosis=output[:500],
                suggested_fix=suggested_fix[:500],
            )
        elif user_action:
            result = EscalationResult(
                agent_id=original_agent_id,
                tier=EscalationTier.HUMAN,
                outcome=EscalationOutcome.TIER3_ESCALATED,
                diagnostic_agent_id=diagnostic_agent_id,
                diagnosis=output[:500],
                suggested_fix=user_action[:500],
            )
        else:
            # Diagnostic produced output but no structured fix
            result = EscalationResult(
                agent_id=original_agent_id,
                tier=EscalationTier.LLM,
                outcome=EscalationOutcome.DIAGNOSED,
                diagnostic_agent_id=diagnostic_agent_id,
                diagnosis=output[:500],
            )

        self._record(result)
        return result

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_diagnostic_prompt(
        self,
        agent_id: str,
        agent_state: AgentState,
        triage_result: TriageResult,
        output_text: str,
    ) -> str:
        """Build the prompt for the diagnostic triage agent."""
        error_text = agent_state.error or "No error message recorded."
        matched_pattern = triage_result.matched_pattern or "none"

        category = triage_result.category
        if isinstance(category, TriageCategory):
            category = category.value

        return _DIAGNOSTIC_PROMPT_TEMPLATE.format(
            agent_id=agent_id,
            category=category,
            confidence=triage_result.confidence,
            matched_pattern=matched_pattern,
            analysis=triage_result.analysis,
            retry_count=agent_state.retry_count,
            max_retries=agent_state.max_retries,
            error_text=error_text[:500],
            output_lines=self.output_tail_lines,
            agent_output=output_text[:3000],
        )

    def _read_output(self, source: Optional[str | Path]) -> str:
        """
        Read agent output from a file path or return raw string.

        Args:
            source: Path to output file, raw string, or None.

        Returns:
            Output text (possibly truncated to tail lines).
        """
        if source is None:
            return "(no output available)"

        if isinstance(source, Path):
            return self._read_output_file(source)

        # If it looks like a file path string, try reading it
        if isinstance(source, str):
            path = Path(source)
            if path.suffix and path.parent != path:
                try:
                    return self._read_output_file(path)
                except Exception:
                    pass
            # Treat as raw output
            return self._tail_text(source)

        return "(no output available)"

    def _read_output_file(self, path: Path) -> str:
        """Read and tail an output file."""
        try:
            content = path.read_text(errors="replace")
            return self._tail_text(content)
        except FileNotFoundError:
            return f"(output file not found: {path})"
        except OSError as e:
            return f"(failed to read output: {e})"

    def _tail_text(self, text: str) -> str:
        """Return the last N lines of text."""
        lines = text.strip().splitlines()
        if len(lines) > self.output_tail_lines:
            lines = lines[-self.output_tail_lines :]
            return f"... (truncated, showing last {self.output_tail_lines} lines)\n" + "\n".join(
                lines
            )
        return "\n".join(lines)

    @staticmethod
    def _extract_section(text: str, heading: str) -> Optional[str]:
        """
        Extract content under a markdown heading.

        Looks for '## <heading>' and captures everything until the next
        '## ' heading or end of text.

        Args:
            text: Full text to search.
            heading: Heading name (without ##).

        Returns:
            Section content, or None if not found.
        """
        import re

        # Split on '## ' boundaries, then find our heading
        pattern = rf"^##\s*{re.escape(heading)}\s*$"
        lines = text.split("\n")

        start_idx = None
        for i, line in enumerate(lines):
            if re.match(pattern, line.strip(), re.IGNORECASE):
                start_idx = i + 1
                break

        if start_idx is None:
            return None

        # Collect lines until next heading or end
        content_lines: list[str] = []
        for line in lines[start_idx:]:
            if line.strip().startswith("## "):
                break
            content_lines.append(line)

        content = "\n".join(content_lines).strip()
        return content if content else None

    async def _spawn_diagnostic(self, prompt: str) -> str:
        """
        Spawn a diagnostic triage agent.

        Args:
            prompt: The diagnostic prompt.

        Returns:
            The diagnostic agent's ID.

        Raises:
            RuntimeError: If spawn fails.
        """
        try:
            from otto.mcp_tools.agent import agent_spawn

            result = await agent_spawn(
                prompt=prompt,
                backend=self.diagnostic_backend,
                task_name="Heartbeat diagnostic triage",
                notify=False,  # We handle notification ourselves
                background=True,
            )

            if not result.get("success"):
                raise RuntimeError(result.get("error", "diagnostic spawn failed"))

            data = result.get("data", {})
            agent_id = data.get("agent_id")
            if not agent_id:
                raise RuntimeError("No agent_id in spawn response")

            return agent_id

        except ImportError:
            # Fallback for testing without otto.mcp_tools
            logger.warning("escalation_spawn_import_fallback")
            import uuid

            return f"diag-{uuid.uuid4().hex[:8]}"

    def _record(self, result: EscalationResult) -> None:
        """Record an escalation result in history."""
        if result.agent_id not in self._history:
            self._history[result.agent_id] = []
        self._history[result.agent_id].append(result)

    # ------------------------------------------------------------------
    # Public query methods
    # ------------------------------------------------------------------

    def get_history(self, agent_id: str) -> list[EscalationResult]:
        """
        Get escalation history for an agent.

        Args:
            agent_id: The agent ID to look up.

        Returns:
            List of EscalationResult objects, oldest first.
        """
        return list(self._history.get(agent_id, []))

    def get_pending_diagnostics(self) -> dict[str, str]:
        """
        Get all pending diagnostic agents.

        Returns:
            Dict mapping diagnostic_agent_id -> original_agent_id.
        """
        return dict(self._pending_diagnostics)

    def is_diagnostic_agent(self, agent_id: str) -> bool:
        """
        Check if an agent ID is a pending diagnostic agent.

        Args:
            agent_id: The agent ID to check.

        Returns:
            True if this is a diagnostic agent we're tracking.
        """
        return agent_id in self._pending_diagnostics

    def get_original_agent_id(self, diagnostic_agent_id: str) -> Optional[str]:
        """
        Get the original failed agent ID for a diagnostic agent.

        Args:
            diagnostic_agent_id: The diagnostic agent's ID.

        Returns:
            Original agent ID, or None if not found.
        """
        return self._pending_diagnostics.get(diagnostic_agent_id)

    def get_stats(self) -> dict[str, Any]:
        """
        Get escalation statistics.

        Returns:
            Dict with counts by outcome and tier.
        """
        stats: dict[str, int] = {
            "total": 0,
            "spawned": 0,
            "diagnosed": 0,
            "fix_suggested": 0,
            "tier3_escalated": 0,
            "disabled": 0,
            "skipped": 0,
            "pending_diagnostics": len(self._pending_diagnostics),
        }

        for results in self._history.values():
            for result in results:
                stats["total"] += 1
                outcome = result.outcome
                if isinstance(outcome, str):
                    key = outcome
                else:
                    key = outcome.value
                if key in stats:
                    stats[key] += 1

        return stats

    def clear_history(self, agent_id: Optional[str] = None) -> None:
        """
        Clear escalation history.

        Args:
            agent_id: Specific agent to clear, or None for all.
        """
        if agent_id:
            self._history.pop(agent_id, None)
        else:
            self._history.clear()

    def clear_pending(self) -> None:
        """Clear all pending diagnostic tracking."""
        self._pending_diagnostics.clear()
        self._persist_diagnostics()
