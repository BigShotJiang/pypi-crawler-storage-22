"""
Heartbeat Integration Layer.

Main entry point that wires all heartbeat modules together into a
simple, user-facing API for monitoring and auto-recovering agents.
"""

import asyncio
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from .daemon import HeartbeatDaemon
from .escalate import EscalationEngine, EscalationOutcome
from .notify import (
    notify_completion,
    notify_diagnosis,
    notify_escalation,
    notify_exhausted,
    notify_failure,
    notify_retry,
)
from .retry import RetryOrchestrator, RetryPolicy
from .state import StateManager
from .triage import TriageCategory, TriageEngine
from .types import AgentState, AgentStatus, HeartbeatConfig

logger = logging.getLogger(__name__)


class Heartbeat:
    """
    Main heartbeat orchestrator that ties together monitoring, triage, and retry.

    Provides a simple API for:
    - Starting/stopping background monitoring
    - Registering agents for tracking
    - Querying agent status

    Internally wires:
    - StateManager: Persistent agent state
    - HeartbeatDaemon: Background polling
    - TriageEngine: Error classification
    - RetryOrchestrator: Auto-retry with backoff

    Example:
        heartbeat = Heartbeat()
        await heartbeat.start()

        # Register an agent for monitoring
        heartbeat.register_agent("agent-123", "do something", "pi")

        # Check status
        status = heartbeat.get_status()

        # Cleanup
        await heartbeat.stop()
    """

    def __init__(
        self,
        config: Optional[HeartbeatConfig] = None,
        state_path: Optional[Path] = None,
        poll_interval: float = 30.0,
        timeout_seconds: float = 3600.0,
        auto_notify: bool = True,
    ) -> None:
        """
        Initialize Heartbeat.

        Args:
            config: HeartbeatConfig from settings. Uses defaults if None.
            state_path: Path to state file. Uses default if None.
            poll_interval: Seconds between agent checks.
            timeout_seconds: Max agent runtime before timeout.
            auto_notify: Whether to send Telegram notifications.
        """
        self.config = config or HeartbeatConfig()
        self._auto_notify = auto_notify

        # Track agent metadata (prompt, backend) for retry
        self._agent_metadata: dict[str, dict[str, str]] = {}

        # Initialize components
        self.state_manager = StateManager(path=state_path)
        self.triage = TriageEngine()
        self.retry = RetryOrchestrator(
            state_manager=self.state_manager,
            policy=RetryPolicy(max_retries=self.config.max_retries),
        )
        self.escalation = EscalationEngine(
            enabled=self.config.escalate_to_llm,
            state_manager=self.state_manager,
        )

        # Daemon with callbacks wired
        self.daemon = HeartbeatDaemon(
            state_manager=self.state_manager,
            poll_interval=poll_interval,
            timeout_seconds=timeout_seconds,
            on_completion=self._handle_completion,
            on_timeout=self._handle_timeout,
            on_failure=self._handle_failure,
        )

    @property
    def is_running(self) -> bool:
        """Check if heartbeat is currently running."""
        return self.daemon.is_running

    async def start(self) -> None:
        """
        Start the heartbeat monitoring daemon.

        Idempotent - safe to call multiple times.
        """
        if not self.config.enabled:
            logger.info("heartbeat_disabled_by_config")
            return

        await self.daemon.start()
        logger.info("heartbeat_started")

    async def stop(self, timeout: float = 5.0) -> None:
        """
        Stop the heartbeat monitoring daemon.

        Args:
            timeout: Max seconds to wait for graceful shutdown.
        """
        await self.daemon.stop(timeout=timeout)
        logger.info("heartbeat_stopped")

    def register_agent(
        self,
        agent_id: str,
        prompt: str,
        backend: str = "pi",
        max_retries: Optional[int] = None,
    ) -> AgentState:
        """
        Register a new agent for monitoring.

        Creates initial state and stores metadata for potential retry.

        Args:
            agent_id: Unique agent identifier.
            prompt: The task prompt (stored for retry).
            backend: Backend being used (for example: "pi", "litellm").
            max_retries: Max retry attempts. Uses config default if None.

        Returns:
            The created AgentState.
        """
        now = datetime.now(timezone.utc)

        agent = AgentState(
            id=agent_id,
            status=AgentStatus.RUNNING,
            retry_count=0,
            max_retries=max_retries or self.config.max_retries,
            created_at=now,
            updated_at=now,
        )

        self.state_manager.update_agent_state(agent_id, agent)

        # Store metadata for retry
        self._agent_metadata[agent_id] = {
            "prompt": prompt,
            "backend": backend,
        }

        logger.info(
            "heartbeat_agent_registered",
            extra={"agent_id": agent_id, "backend": backend},
        )

        return agent

    def unregister_agent(self, agent_id: str) -> bool:
        """
        Remove an agent from monitoring.

        Args:
            agent_id: The agent to remove.

        Returns:
            True if removed, False if not found.
        """
        self._agent_metadata.pop(agent_id, None)
        self.retry.cancel_retry(agent_id)
        return self.state_manager.remove_agent_state(agent_id)

    def get_agent(self, agent_id: str) -> Optional[AgentState]:
        """
        Get state for a specific agent.

        Args:
            agent_id: The agent ID to look up.

        Returns:
            AgentState if found, None otherwise.
        """
        return self.state_manager.get_agent_state(agent_id)

    def get_status(self) -> dict[str, Any]:
        """
        Get summary status of all tracked agents.

        Returns:
            Dict with counts, running status, and recent activity.
        """
        state_stats = self.state_manager.get_stats()
        retry_stats = self.retry.get_stats()
        triage_stats = self.triage.get_stats()
        escalation_stats = self.escalation.get_stats()

        return {
            "running": self.is_running,
            "agents": state_stats,
            "retries": retry_stats,
            "triages": triage_stats,
            "escalations": escalation_stats,
            "config": {
                "enabled": self.config.enabled,
                "auto_retry": self.config.auto_retry,
                "max_retries": self.config.max_retries,
                "escalate_to_llm": self.config.escalate_to_llm,
            },
        }

    def mark_completed(self, agent_id: str) -> None:
        """
        Externally mark an agent as completed.

        Use when agent completion is detected outside the daemon.

        Args:
            agent_id: The agent to mark complete.
        """
        self.daemon.mark_completed(agent_id)

    def mark_failed(self, agent_id: str, error: str) -> None:
        """
        Externally mark an agent as failed.

        Use when agent failure is detected outside the daemon.

        Args:
            agent_id: The agent to mark failed.
            error: Error message.
        """
        self.daemon.mark_failed(agent_id, error)

    # -------------------------------------------------------------------------
    # Callback handlers - wired to daemon events
    # -------------------------------------------------------------------------

    def _handle_completion(self, agent_id: str, agent: AgentState) -> None:
        """Handle agent completion callback from daemon."""
        logger.info("heartbeat_on_completion", extra={"agent_id": agent_id})

        # Check if this is a diagnostic agent completing
        if self.escalation.is_diagnostic_agent(agent_id):
            self._handle_diagnostic_completion(agent_id, agent)
            return

        # Calculate duration
        duration = None
        if agent.created_at:
            created = agent.created_at
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            duration = (datetime.now(timezone.utc) - created).total_seconds()

        # Get task name from metadata
        task_name = self._agent_metadata.get(agent_id, {}).get("prompt", "")[:50]

        # Send notification
        if self._auto_notify:
            self._send_notification(
                notify_completion(agent, task_name=task_name, duration_seconds=duration)
            )

        # Cleanup metadata
        self._agent_metadata.pop(agent_id, None)

    def _handle_timeout(self, agent_id: str, agent: AgentState) -> None:
        """Handle agent timeout callback from daemon."""
        logger.warning("heartbeat_on_timeout", extra={"agent_id": agent_id})

        # Triage the timeout
        triage_result = self.triage.analyze_content(
            agent_id,
            agent.error or "Agent timed out",
        )

        self._process_failure(agent_id, agent, triage_result)

    def _handle_failure(self, agent_id: str, agent: AgentState, error: str) -> None:
        """Handle agent failure callback from daemon."""
        logger.error(
            "heartbeat_on_failure",
            extra={"agent_id": agent_id, "error": error},
        )

        # Triage the failure
        triage_result = self.triage.analyze_content(agent_id, error)

        self._process_failure(agent_id, agent, triage_result)

    def _process_failure(
        self,
        agent_id: str,
        agent: AgentState,
        triage_result: Any,
    ) -> None:
        """
        Process a failure based on triage result.

        Decides whether to retry, escalate to LLM (Tier 2), or notify user (Tier 3).
        """
        self.retry.record_triage(triage_result)

        category = triage_result.category
        if isinstance(category, str):
            category_enum = TriageCategory(category)
        else:
            category_enum = category

        # PERMANENT errors - attempt LLM escalation, then notify
        if category_enum == TriageCategory.PERMANENT:
            logger.warning(
                "heartbeat_permanent_failure",
                extra={
                    "agent_id": agent_id,
                    "pattern": triage_result.matched_pattern,
                },
            )
            if self._auto_notify:
                self._send_notification(notify_failure(agent, triage_result))
            # Attempt Tier 2 LLM escalation
            self._attempt_escalation(agent_id, agent, triage_result)
            return

        # Check if should retry
        if self.config.auto_retry and self.retry.should_retry(agent_id):
            self._schedule_retry(agent_id, agent, triage_result)
        else:
            # Retries exhausted or disabled
            logger.warning(
                "heartbeat_retries_exhausted",
                extra={"agent_id": agent_id, "retry_count": agent.retry_count},
            )
            if self._auto_notify:
                self._send_notification(notify_exhausted(agent, triage_result))
            # Attempt Tier 2 LLM escalation before giving up
            self._attempt_escalation(agent_id, agent, triage_result)

    def _attempt_escalation(
        self,
        agent_id: str,
        agent: AgentState,
        triage_result: Any,
    ) -> None:
        """
        Attempt Tier 2 LLM escalation for a failed agent.

        Spawns a diagnostic agent to analyze the failure. On completion,
        the diagnostic output is parsed and the user is notified with
        the diagnosis or escalated to Tier 3.
        """
        if not self.escalation.enabled:
            # Escalation disabled — clean up metadata
            self._agent_metadata.pop(agent_id, None)
            return

        # Get agent output path if available
        agent_output = self._get_agent_output_path(agent_id)

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            # No event loop — skip escalation
            logger.debug("heartbeat_escalation_no_loop", extra={"agent_id": agent_id})
            self._agent_metadata.pop(agent_id, None)
            return

        loop.create_task(self._run_escalation(agent_id, agent, triage_result, agent_output))

    async def _run_escalation(
        self,
        agent_id: str,
        agent: AgentState,
        triage_result: Any,
        agent_output: Optional[str] = None,
    ) -> None:
        """Execute the escalation and handle the result."""
        try:
            result = await self.escalation.escalate(
                agent_id=agent_id,
                agent_state=agent,
                triage_result=triage_result,
                agent_output=agent_output,
            )

            if result.outcome == EscalationOutcome.SPAWNED and self._auto_notify:
                task_name = self._agent_metadata.get(agent_id, {}).get("prompt", "")[:50]
                self._send_notification(notify_escalation(agent, result, task_name=task_name))

            # Note: diagnostic agent completion will be detected by the daemon
            # and handled via _handle_completion → _handle_diagnostic_completion

        except Exception as e:
            logger.exception(
                "heartbeat_escalation_error",
                extra={"agent_id": agent_id, "error": str(e)},
            )
        finally:
            # Clean up metadata for the original agent (diagnostic agent has its own lifecycle)
            self._agent_metadata.pop(agent_id, None)

    def _get_agent_output_path(self, agent_id: str) -> Optional[str]:
        """Get the output file path for an agent, if it exists."""
        try:
            from otto.paths import OUTPUTS_DIR

            output_path = OUTPUTS_DIR / f"{agent_id}.txt"
            if output_path.exists():
                return str(output_path)
        except ImportError:
            pass
        return None

    def _handle_diagnostic_completion(
        self,
        agent_id: str,
        agent: AgentState,
    ) -> None:
        """
        Handle completion of a diagnostic triage agent.

        Parses the diagnostic output and sends the appropriate notification.
        """
        original_agent_id = self.escalation.get_original_agent_id(agent_id)

        # Read diagnostic output
        output_text = ""
        output_path = self._get_agent_output_path(agent_id)
        if output_path:
            try:
                output_text = Path(output_path).read_text(errors="replace")
            except OSError:
                pass

        # Parse the diagnostic output
        result = self.escalation.parse_diagnostic_output(agent_id, output_text)

        # Get original agent state for notification
        original_agent = None
        if original_agent_id:
            original_agent = self.state_manager.get_agent_state(original_agent_id)

        notify_agent = original_agent or agent
        task_name = self._agent_metadata.get(original_agent_id or agent_id, {}).get("prompt", "")[
            :50
        ]

        if self._auto_notify:
            self._send_notification(notify_diagnosis(notify_agent, result, task_name=task_name))

        logger.info(
            "heartbeat_diagnostic_complete",
            extra={
                "diagnostic_agent_id": agent_id,
                "original_agent_id": original_agent_id,
                "outcome": str(result.outcome),
            },
        )

    def _schedule_retry(
        self,
        agent_id: str,
        agent: AgentState,
        triage_result: Any,
    ) -> None:
        """Schedule a retry with exponential backoff."""
        metadata = self._agent_metadata.get(agent_id, {})
        prompt = metadata.get("prompt", "")
        backend = metadata.get("backend", "pi")

        try:
            delay = self.retry.schedule_retry(
                agent_id,
                prompt=prompt,
                backend=backend,
            )

            logger.info(
                "heartbeat_retry_scheduled",
                extra={
                    "agent_id": agent_id,
                    "delay_seconds": delay,
                    "attempt": agent.retry_count + 1,
                },
            )

            if self._auto_notify:
                self._send_notification(notify_retry(agent, delay))

            # Schedule the actual retry execution
            asyncio.create_task(self._execute_retry_after_delay(agent_id, delay))

        except ValueError as e:
            logger.error(
                "heartbeat_retry_schedule_failed",
                extra={"agent_id": agent_id, "error": str(e)},
            )

    async def _execute_retry_after_delay(self, agent_id: str, delay: float) -> None:
        """Execute retry after waiting for backoff delay."""
        await asyncio.sleep(delay)

        result = await self.retry.execute_retry(agent_id)

        if result.success:
            # Register the new agent for monitoring
            metadata = self._agent_metadata.get(agent_id, {})
            if result.new_agent_id and metadata:
                self._agent_metadata[result.new_agent_id] = metadata

                # Create state for new agent
                now = datetime.now(timezone.utc)
                new_agent = AgentState(
                    id=result.new_agent_id,
                    status=AgentStatus.RUNNING,
                    retry_count=0,
                    max_retries=self.config.max_retries,
                    created_at=now,
                    updated_at=now,
                )
                self.state_manager.update_agent_state(result.new_agent_id, new_agent)

            logger.info(
                "heartbeat_retry_executed",
                extra={
                    "original_agent_id": agent_id,
                    "new_agent_id": result.new_agent_id,
                },
            )
        else:
            logger.error(
                "heartbeat_retry_failed",
                extra={
                    "agent_id": agent_id,
                    "error": result.error,
                },
            )

    def _send_notification(self, message: str) -> None:
        """Send notification via Otto gateway."""
        try:
            # Fire-and-forget notification
            asyncio.create_task(self._async_notify(message))
        except RuntimeError:
            # No event loop - skip notification
            logger.debug("heartbeat_notify_no_loop")

    async def _async_notify(self, message: str) -> None:
        """Async notification sender."""
        try:
            from otto.mcp_tools.notifications import notify_send

            await notify_send(message=message)
        except ImportError:
            logger.debug("heartbeat_notify_import_unavailable")
        except Exception as e:
            logger.warning(
                "heartbeat_notify_failed",
                extra={"error": str(e)},
            )
