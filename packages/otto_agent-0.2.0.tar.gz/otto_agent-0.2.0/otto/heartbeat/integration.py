"""
Heartbeat Integration — Singleton + Worker/Bot Hooks.

Provides a shared Heartbeat instance and hook functions
for wiring into Otto's worker lifecycle and bot startup.

Usage in worker:
    from otto.heartbeat.integration import on_agent_start, on_agent_complete, on_agent_fail
    on_agent_start(agent_id, prompt, backend)
    on_agent_complete(agent_id)
    on_agent_fail(agent_id, error)

Usage in bot startup:
    from otto.heartbeat.integration import start_heartbeat, stop_heartbeat
    await start_heartbeat()
"""

from __future__ import annotations

import asyncio
import logging
from typing import Optional

from .heartbeat import Heartbeat
from .types import HeartbeatConfig

logger = logging.getLogger(__name__)

# Module-level singleton
_instance: Optional[Heartbeat] = None
_start_lock: Optional[asyncio.Lock] = None


def _load_config() -> HeartbeatConfig:
    """Load heartbeat config from Otto settings."""
    try:
        from otto.backends import get_orchestration_config

        orch = get_orchestration_config()
        hb_cfg = orch.get("heartbeat", {}) or {}
        return HeartbeatConfig(
            enabled=bool(hb_cfg.get("enabled", True)),
            auto_retry=bool(hb_cfg.get("auto_retry", True)),
            max_retries=int(hb_cfg.get("max_retries", 3)),
            interval_seconds=int(hb_cfg.get("poll_interval", 30)),
        )
    except Exception:
        return HeartbeatConfig()


def _load_timeout() -> float:
    """Load timeout_seconds from Otto settings."""
    try:
        from otto.backends import get_orchestration_config

        orch = get_orchestration_config()
        hb_cfg = orch.get("heartbeat", {}) or {}
        return float(hb_cfg.get("timeout_seconds", 3600))
    except Exception:
        return 3600.0


def get_heartbeat() -> Heartbeat:
    """Get or create the shared Heartbeat instance (sync, no daemon start)."""
    global _instance
    if _instance is None:
        config = _load_config()
        timeout = _load_timeout()
        _instance = Heartbeat(
            config=config,
            poll_interval=float(config.interval_seconds),
            timeout_seconds=timeout,
        )
        logger.info("heartbeat_instance_created")
    return _instance


async def start_heartbeat() -> Heartbeat:
    """Start the heartbeat daemon. Idempotent."""
    global _instance, _start_lock
    # Create lock lazily in the current event loop
    if _start_lock is None:
        _start_lock = asyncio.Lock()
    async with _start_lock:
        hb = get_heartbeat()
        if not hb.is_running:
            await hb.start()
            logger.info("heartbeat_daemon_started_via_integration")
        return hb


async def stop_heartbeat() -> None:
    """Stop the heartbeat daemon."""
    global _instance, _start_lock
    if _instance and _instance.is_running:
        await _instance.stop()
        logger.info("heartbeat_daemon_stopped_via_integration")
    # Reset lock so it gets recreated for the next event loop
    _start_lock = None


# ---------------------------------------------------------------------------
# Worker lifecycle hooks (sync-safe — called from worker threads)
# ---------------------------------------------------------------------------


def on_agent_start(agent_id: str, prompt: str, backend: str = "pi") -> None:
    """Register an agent for heartbeat monitoring. Thread-safe."""
    try:
        hb = get_heartbeat()
        hb.register_agent(agent_id, prompt, backend)
    except Exception:
        logger.debug("heartbeat_register_skipped", exc_info=True)


def on_agent_complete(agent_id: str) -> None:
    """Mark an agent as completed. Thread-safe."""
    try:
        hb = get_heartbeat()
        agent = hb.get_agent(agent_id)
        if agent is None:
            return  # Not tracked by heartbeat
        # Use state_manager directly (sync) rather than daemon.mark_completed (async)
        from datetime import datetime, timezone

        from .types import AgentState, AgentStatus

        now = datetime.now(timezone.utc)
        updated = AgentState(
            id=agent.id,
            status=AgentStatus.COMPLETED,
            error=None,
            error_type=None,
            retry_count=agent.retry_count,
            max_retries=agent.max_retries,
            created_at=agent.created_at,
            updated_at=now,
            last_error_at=agent.last_error_at,
        )
        hb.state_manager.update_agent_state(agent_id, updated)
        hb.unregister_agent(agent_id)
        logger.info("heartbeat_agent_completed_sync", extra={"agent_id": agent_id})
    except Exception:
        logger.debug("heartbeat_complete_skipped", exc_info=True)


def on_agent_fail(agent_id: str, error: str) -> None:
    """Mark an agent as failed. Thread-safe."""
    try:
        hb = get_heartbeat()
        agent = hb.get_agent(agent_id)
        if agent is None:
            return  # Not tracked by heartbeat
        from datetime import datetime, timezone

        from .types import AgentState, AgentStatus, ErrorSeverity

        now = datetime.now(timezone.utc)
        new_retry_count = agent.retry_count + 1
        if new_retry_count < agent.max_retries:
            new_status = AgentStatus.RETRYING
        else:
            new_status = AgentStatus.FAILED

        updated = AgentState(
            id=agent.id,
            status=new_status,
            error=error[:500] if error else None,
            error_type=ErrorSeverity.UNKNOWN,
            retry_count=new_retry_count,
            max_retries=agent.max_retries,
            created_at=agent.created_at,
            updated_at=now,
            last_error_at=now,
        )
        hb.state_manager.update_agent_state(agent_id, updated)
        logger.info(
            "heartbeat_agent_failed_sync",
            extra={"agent_id": agent_id, "status": new_status},
        )
    except Exception:
        logger.debug("heartbeat_fail_skipped", exc_info=True)
