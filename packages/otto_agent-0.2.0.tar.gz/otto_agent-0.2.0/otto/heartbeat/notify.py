"""
Notification message formatting for Heartbeat.

Formats agent status messages for Telegram using HTML formatting.
The actual sending is done via otto-gateway's notify_send tool.
"""

from typing import TYPE_CHECKING, Optional

from .triage import TriageCategory, TriageResult
from .types import AgentState

if TYPE_CHECKING:
    from .escalate import EscalationResult


def _format_duration(seconds: float) -> str:
    """Format duration in human-readable form."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        minutes = seconds / 60
        return f"{minutes:.1f}m"
    else:
        hours = seconds / 3600
        return f"{hours:.1f}h"


def _truncate(text: str, max_len: int = 100) -> str:
    """Truncate text with ellipsis if too long."""
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."


def _escape_html(text: str) -> str:
    """Escape HTML special characters for Telegram."""
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def notify_completion(
    agent: AgentState,
    task_name: Optional[str] = None,
    duration_seconds: Optional[float] = None,
) -> str:
    """
    Format a success notification for agent completion.

    Args:
        agent: The completed agent state.
        task_name: Optional human-readable task name.
        duration_seconds: Optional duration the agent ran.

    Returns:
        HTML-formatted message for Telegram.
    """
    name = task_name or agent.id
    name_escaped = _escape_html(name)

    parts = [f"✅ <b>Agent completed</b>: {name_escaped}"]

    if duration_seconds is not None:
        parts.append(f"⏱ Duration: {_format_duration(duration_seconds)}")

    parts.append(f"<code>{agent.id}</code>")

    return "\n".join(parts)


def notify_failure(
    agent: AgentState,
    triage: TriageResult,
    task_name: Optional[str] = None,
    duration_seconds: Optional[float] = None,
) -> str:
    """
    Format a failure notification with triage info.

    Args:
        agent: The failed agent state.
        triage: Triage result with classification.
        task_name: Optional human-readable task name.
        duration_seconds: Optional duration before failure.

    Returns:
        HTML-formatted message for Telegram.
    """
    name = task_name or agent.id
    name_escaped = _escape_html(name)

    # Category emoji
    cat_emoji = {
        TriageCategory.TRANSIENT: "🔄",
        TriageCategory.PERMANENT: "🚫",
        TriageCategory.UNKNOWN: "❓",
    }
    # Handle both enum and string values
    category = triage.category
    if isinstance(category, str):
        emoji = {"transient": "🔄", "permanent": "🚫", "unknown": "❓"}.get(category, "❓")
        cat_label = category
    else:
        emoji = cat_emoji.get(category, "❓")
        cat_label = category.value

    parts = [f"❌ <b>Agent failed</b>: {name_escaped}"]
    parts.append(f"{emoji} Category: <b>{cat_label}</b>")

    if triage.matched_pattern:
        parts.append(f"🔍 Pattern: {_escape_html(triage.matched_pattern)}")

    if duration_seconds is not None:
        parts.append(f"⏱ Duration: {_format_duration(duration_seconds)}")

    if agent.error:
        error_short = _truncate(_escape_html(agent.error), 80)
        parts.append(f"<pre>{error_short}</pre>")

    parts.append(f"<code>{agent.id}</code>")

    return "\n".join(parts)


def notify_retry(
    agent: AgentState,
    delay_seconds: float,
    task_name: Optional[str] = None,
) -> str:
    """
    Format a retry scheduled notification.

    Args:
        agent: The agent being retried.
        delay_seconds: Seconds until retry.
        task_name: Optional human-readable task name.

    Returns:
        HTML-formatted message for Telegram.
    """
    name = task_name or agent.id
    name_escaped = _escape_html(name)

    retry_num = agent.retry_count + 1
    max_retries = agent.max_retries

    parts = [f"🔄 <b>Retrying agent</b>: {name_escaped}"]
    parts.append(f"Attempt {retry_num}/{max_retries} in {_format_duration(delay_seconds)}")
    parts.append(f"<code>{agent.id}</code>")

    return "\n".join(parts)


def notify_exhausted(
    agent: AgentState,
    triage: TriageResult,
    task_name: Optional[str] = None,
) -> str:
    """
    Format a max retries exhausted notification.

    Args:
        agent: The agent that exhausted retries.
        triage: Final triage result.
        task_name: Optional human-readable task name.

    Returns:
        HTML-formatted message for Telegram.
    """
    name = task_name or agent.id
    name_escaped = _escape_html(name)

    parts = [f"⚠️ <b>Retries exhausted</b>: {name_escaped}"]
    parts.append(f"Attempted {agent.retry_count}/{agent.max_retries} times")

    # Show triage analysis
    analysis_short = _truncate(_escape_html(triage.analysis), 120)
    parts.append(f"📋 {analysis_short}")

    if agent.error:
        error_short = _truncate(_escape_html(agent.error), 80)
        parts.append(f"<pre>{error_short}</pre>")

    parts.append("👀 <b>Needs human review</b>")
    parts.append(f"<code>{agent.id}</code>")

    return "\n".join(parts)


def notify_escalation(
    agent: AgentState,
    escalation: "EscalationResult",
    task_name: Optional[str] = None,
) -> str:
    """
    Format an LLM escalation notification (Tier 2 diagnostic spawned).

    Args:
        agent: The failed agent state.
        escalation: Escalation result from EscalationEngine.
        task_name: Optional human-readable task name.

    Returns:
        HTML-formatted message for Telegram.
    """
    name = task_name or agent.id
    name_escaped = _escape_html(name)

    parts = [f"🧠 <b>LLM escalation</b>: {name_escaped}"]
    parts.append("A diagnostic agent is analyzing the failure.")

    if escalation.diagnostic_agent_id:
        parts.append(f"🔬 Diagnostic: <code>{escalation.diagnostic_agent_id}</code>")

    parts.append(f"<code>{agent.id}</code>")

    return "\n".join(parts)


def notify_diagnosis(
    agent: AgentState,
    escalation: "EscalationResult",
    task_name: Optional[str] = None,
) -> str:
    """
    Format a completed diagnosis notification.

    Args:
        agent: The original failed agent state.
        escalation: Escalation result with diagnosis details.
        task_name: Optional human-readable task name.

    Returns:
        HTML-formatted message for Telegram.
    """
    name = task_name or agent.id
    name_escaped = _escape_html(name)

    from .escalate import EscalationOutcome

    outcome = escalation.outcome
    if isinstance(outcome, str):
        outcome = EscalationOutcome(outcome)

    if outcome == EscalationOutcome.FIX_SUGGESTED:
        parts = [f"💡 <b>Fix suggested</b>: {name_escaped}"]
        if escalation.suggested_fix:
            fix_short = _truncate(_escape_html(escalation.suggested_fix), 200)
            parts.append(f"<pre>{fix_short}</pre>")
    elif outcome == EscalationOutcome.TIER3_ESCALATED:
        parts = [f"🚨 <b>Needs your attention</b>: {name_escaped}"]
        if escalation.suggested_fix:
            action_short = _truncate(_escape_html(escalation.suggested_fix), 200)
            parts.append(f"📋 {action_short}")
    else:
        parts = [f"🔍 <b>Diagnosis complete</b>: {name_escaped}"]

    if escalation.diagnosis:
        diag_short = _truncate(_escape_html(escalation.diagnosis), 150)
        parts.append(f"📋 {diag_short}")

    parts.append(f"<code>{agent.id}</code>")

    return "\n".join(parts)
