"""
Retry Orchestrator for Failed Agents.

Manages retry decisions, exponential backoff scheduling, and re-spawning
of failed agents based on triage results. Integrates with StateManager
for persistent retry tracking.
"""

import asyncio
import logging
import random
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

from .state import StateManager
from .triage import TriageCategory, TriageResult
from .types import AgentState, AgentStatus

logger = logging.getLogger(__name__)


@dataclass
class RetryPolicy:
    """Configuration for retry behavior."""

    max_retries: int = 3
    base_delay: float = 60.0  # Base delay in seconds
    max_delay: float = 3600.0  # Max delay cap in seconds (1 hour)
    jitter_factor: float = 0.25  # +/- 25% randomization
    backoff_multiplier: float = 2.0  # Exponential backoff factor


@dataclass
class RetryDecision:
    """Result of retry decision logic."""

    should_retry: bool
    reason: str
    delay_seconds: float = 0.0
    attempt_number: int = 0


@dataclass
class RetryResult:
    """Result of executing a retry."""

    success: bool
    agent_id: str
    new_agent_id: Optional[str] = None
    error: Optional[str] = None
    attempt_number: int = 0


@dataclass
class PendingRetry:
    """Tracks a scheduled retry."""

    agent_id: str
    original_prompt: str
    backend: str
    scheduled_at: datetime
    execute_at: datetime
    attempt_number: int
    triage_result: Optional[TriageResult] = None


class RetryOrchestrator:
    """
    Manages retry decisions and execution for failed agents.

    Takes triage results from TriageEngine and decides whether to retry,
    calculates exponential backoff delays, and spawns replacement agents.

    Example:
        orchestrator = RetryOrchestrator()
        if orchestrator.should_retry("agent-123"):
            delay = orchestrator.schedule_retry("agent-123")
            # Wait for delay...
            result = await orchestrator.execute_retry("agent-123")
    """

    def __init__(
        self,
        state_manager: Optional[StateManager] = None,
        policy: Optional[RetryPolicy] = None,
    ) -> None:
        """
        Initialize RetryOrchestrator.

        Args:
            state_manager: StateManager instance. Creates default if None.
            policy: RetryPolicy configuration. Uses defaults if None.
        """
        self.state_manager = state_manager or StateManager()
        self.policy = policy or RetryPolicy()

        # In-memory tracking for pending retries, loaded from persistent state
        self._pending_retries: dict[str, PendingRetry] = {}
        self._triage_cache: dict[str, TriageResult] = {}

        # Restore from persisted state
        self._load_from_state()

    def _load_from_state(self) -> None:
        """Restore pending retries and triage cache from persisted state."""
        try:
            raw_retries = self.state_manager.load_pending_retries()
            for agent_id, data in raw_retries.items():
                try:
                    # Reconstruct PendingRetry from dict
                    triage_data = data.get("triage_result")
                    triage = TriageResult.model_validate(triage_data) if triage_data else None
                    self._pending_retries[agent_id] = PendingRetry(
                        agent_id=data["agent_id"],
                        original_prompt=data["original_prompt"],
                        backend=data["backend"],
                        scheduled_at=datetime.fromisoformat(data["scheduled_at"]),
                        execute_at=datetime.fromisoformat(data["execute_at"]),
                        attempt_number=data["attempt_number"],
                        triage_result=triage,
                    )
                except Exception:
                    logger.debug("retry_load_skip_entry", extra={"agent_id": agent_id})

            raw_cache = self.state_manager.load_triage_cache()
            for agent_id, data in raw_cache.items():
                try:
                    self._triage_cache[agent_id] = TriageResult.model_validate(data)
                except Exception:
                    logger.debug("triage_cache_load_skip", extra={"agent_id": agent_id})
        except Exception:
            logger.debug("retry_state_restore_skipped", exc_info=True)

    def _persist_retries(self) -> None:
        """Persist pending retries to state file."""
        data: dict[str, dict] = {}
        for agent_id, pr in self._pending_retries.items():
            entry: dict = {
                "agent_id": pr.agent_id,
                "original_prompt": pr.original_prompt,
                "backend": pr.backend,
                "scheduled_at": pr.scheduled_at.isoformat(),
                "execute_at": pr.execute_at.isoformat(),
                "attempt_number": pr.attempt_number,
                "triage_result": pr.triage_result.model_dump(mode="json")
                if pr.triage_result
                else None,
            }
            data[agent_id] = entry
        self.state_manager.save_pending_retries(data)

    def _persist_triage_cache(self) -> None:
        """Persist triage cache to state file."""
        data: dict[str, dict] = {}
        for agent_id, tr in self._triage_cache.items():
            data[agent_id] = tr.model_dump(mode="json")
        self.state_manager.save_triage_cache(data)

    def record_triage(self, triage_result: TriageResult) -> None:
        """
        Record a triage result for later retry decisions.

        Args:
            triage_result: TriageResult from TriageEngine.
        """
        self._triage_cache[triage_result.agent_id] = triage_result
        self._persist_triage_cache()
        logger.debug(
            "retry_triage_recorded",
            extra={
                "agent_id": triage_result.agent_id,
                "category": triage_result.category,
                "confidence": triage_result.confidence,
            },
        )

    def should_retry(self, agent_id: str) -> bool:
        """
        Determine if an agent should be retried.

        Checks:
        1. Agent exists and is in a retriable state (FAILED/RETRYING)
        2. Retry count hasn't exceeded max_retries
        3. Triage category allows retry (TRANSIENT or UNKNOWN with retries left)

        Args:
            agent_id: The agent ID to check.

        Returns:
            True if agent should be retried, False otherwise.
        """
        decision = self.get_retry_decision(agent_id)
        return decision.should_retry

    def get_retry_decision(self, agent_id: str) -> RetryDecision:
        """
        Get detailed retry decision for an agent.

        Args:
            agent_id: The agent ID to evaluate.

        Returns:
            RetryDecision with reasoning and parameters.
        """
        agent = self.state_manager.get_agent_state(agent_id)

        if not agent:
            return RetryDecision(
                should_retry=False,
                reason="agent_not_found",
            )

        # Check status
        if agent.status not in (AgentStatus.FAILED, AgentStatus.RETRYING):
            return RetryDecision(
                should_retry=False,
                reason=f"invalid_status_{agent.status}",
            )

        # Check retry count against policy and agent's own max
        max_retries = min(self.policy.max_retries, agent.max_retries)
        if agent.retry_count >= max_retries:
            return RetryDecision(
                should_retry=False,
                reason="max_retries_exceeded",
                attempt_number=agent.retry_count,
            )

        # Check triage result if available
        triage = self._triage_cache.get(agent_id)
        if triage:
            if triage.category == TriageCategory.PERMANENT:
                return RetryDecision(
                    should_retry=False,
                    reason="permanent_error",
                    attempt_number=agent.retry_count,
                )

            if triage.category == TriageCategory.TRANSIENT:
                return RetryDecision(
                    should_retry=True,
                    reason="transient_error",
                    delay_seconds=self._calculate_delay(agent.retry_count),
                    attempt_number=agent.retry_count + 1,
                )

            # UNKNOWN - retry with caution if retries remain
            return RetryDecision(
                should_retry=True,
                reason="unknown_error_with_retries",
                delay_seconds=self._calculate_delay(agent.retry_count),
                attempt_number=agent.retry_count + 1,
            )

        # No triage result - default to retry if count allows
        return RetryDecision(
            should_retry=True,
            reason="no_triage_default_retry",
            delay_seconds=self._calculate_delay(agent.retry_count),
            attempt_number=agent.retry_count + 1,
        )

    def _calculate_delay(self, retry_count: int) -> float:
        """
        Calculate exponential backoff delay with jitter.

        Formula: base_delay * (multiplier ^ retry_count) * (1 +/- jitter)

        Args:
            retry_count: Current retry attempt number (0-indexed).

        Returns:
            Delay in seconds.
        """
        # Exponential backoff
        delay = self.policy.base_delay * (self.policy.backoff_multiplier**retry_count)

        # Cap at max delay
        delay = min(delay, self.policy.max_delay)

        # Add jitter: random factor between (1 - jitter) and (1 + jitter)
        jitter = 1.0 + random.uniform(
            -self.policy.jitter_factor,
            self.policy.jitter_factor,
        )
        delay *= jitter

        return round(delay, 2)

    def schedule_retry(
        self,
        agent_id: str,
        prompt: Optional[str] = None,
        backend: str = "pi",
    ) -> float:
        """
        Schedule a retry for an agent and return the delay.

        Updates agent state to RETRYING and calculates backoff delay.
        Does NOT execute the retry - use execute_retry() after delay.

        Args:
            agent_id: The agent ID to schedule retry for.
            prompt: Original prompt (required for retry execution).
            backend: Backend to use for retry.

        Returns:
            Delay in seconds before retry should execute.

        Raises:
            ValueError: If agent not found or shouldn't be retried.
        """
        decision = self.get_retry_decision(agent_id)

        if not decision.should_retry:
            raise ValueError(f"Cannot retry agent {agent_id}: {decision.reason}")

        agent = self.state_manager.get_agent_state(agent_id)
        if not agent:
            raise ValueError(f"Agent not found: {agent_id}")

        # Update agent state to RETRYING
        now = datetime.now(timezone.utc)
        updated_agent = AgentState(
            id=agent.id,
            status=AgentStatus.RETRYING,
            error=agent.error,
            error_type=agent.error_type,
            retry_count=agent.retry_count,  # Don't increment until execute
            max_retries=agent.max_retries,
            created_at=agent.created_at,
            updated_at=now,
            last_error_at=agent.last_error_at,
        )
        self.state_manager.update_agent_state(agent_id, updated_agent)

        # Track pending retry
        execute_at = datetime.fromtimestamp(
            now.timestamp() + decision.delay_seconds,
            tz=timezone.utc,
        )

        self._pending_retries[agent_id] = PendingRetry(
            agent_id=agent_id,
            original_prompt=prompt or "",
            backend=backend,
            scheduled_at=now,
            execute_at=execute_at,
            attempt_number=decision.attempt_number,
            triage_result=self._triage_cache.get(agent_id),
        )
        self._persist_retries()

        logger.info(
            "retry_scheduled",
            extra={
                "agent_id": agent_id,
                "delay_seconds": decision.delay_seconds,
                "attempt_number": decision.attempt_number,
                "execute_at": execute_at.isoformat(),
            },
        )

        return decision.delay_seconds

    async def execute_retry(
        self,
        agent_id: str,
        prompt: Optional[str] = None,
        backend: Optional[str] = None,
    ) -> RetryResult:
        """
        Execute a retry by spawning a new agent with the same prompt.

        Increments retry_count in state and spawns a replacement agent.
        If prompt is not provided, attempts to use cached pending retry info.

        Args:
            agent_id: The original agent ID being retried.
            prompt: The prompt to retry (uses cached if not provided).
            backend: Backend to use (uses cached if not provided).

        Returns:
            RetryResult with success status and new agent info.
        """
        # Get pending retry info if available
        pending = self._pending_retries.get(agent_id)

        if not prompt:
            if pending:
                prompt = pending.original_prompt
            else:
                return RetryResult(
                    success=False,
                    agent_id=agent_id,
                    error="prompt_required_for_retry",
                )

        if not backend:
            backend = pending.backend if pending else "pi"

        # Guard: skip retry if prompt is empty or too vague to produce useful work
        if self._is_empty_prompt(prompt):
            logger.warning(
                "retry_skipped_empty_prompt",
                extra={"agent_id": agent_id, "prompt": prompt[:80]},
            )
            return RetryResult(
                success=False,
                agent_id=agent_id,
                error="prompt_too_vague_for_retry",
            )

        # Get current agent state
        agent = self.state_manager.get_agent_state(agent_id)
        if not agent:
            return RetryResult(
                success=False,
                agent_id=agent_id,
                error="agent_not_found",
            )

        # Verify still retriable
        if not self.should_retry(agent_id):
            decision = self.get_retry_decision(agent_id)
            return RetryResult(
                success=False,
                agent_id=agent_id,
                error=f"retry_not_allowed: {decision.reason}",
            )

        # Spawn new agent
        try:
            new_agent_id = await self._spawn_agent(prompt, backend)
        except Exception as e:
            logger.exception(
                "retry_spawn_failed",
                extra={"agent_id": agent_id, "error": str(e)},
            )
            return RetryResult(
                success=False,
                agent_id=agent_id,
                error=str(e),
                attempt_number=agent.retry_count + 1,
            )

        # Update original agent state with incremented retry count
        now = datetime.now(timezone.utc)
        updated_agent = AgentState(
            id=agent.id,
            status=AgentStatus.RETRYING,
            error=agent.error,
            error_type=agent.error_type,
            retry_count=agent.retry_count + 1,
            max_retries=agent.max_retries,
            created_at=agent.created_at,
            updated_at=now,
            last_error_at=agent.last_error_at,
        )
        self.state_manager.update_agent_state(agent_id, updated_agent)

        # Clean up pending retry
        self._pending_retries.pop(agent_id, None)
        self._triage_cache.pop(agent_id, None)
        self._persist_retries()
        self._persist_triage_cache()

        logger.info(
            "retry_executed",
            extra={
                "original_agent_id": agent_id,
                "new_agent_id": new_agent_id,
                "attempt_number": agent.retry_count + 1,
                "backend": backend,
            },
        )

        return RetryResult(
            success=True,
            agent_id=agent_id,
            new_agent_id=new_agent_id,
            attempt_number=agent.retry_count + 1,
        )

    async def _spawn_agent(self, prompt: str, backend: str) -> str:
        """
        Spawn a new agent with the given prompt.

        Uses Otto's agent_spawn mechanism.

        Args:
            prompt: The task prompt.
            backend: Backend to use.

        Returns:
            New agent ID.

        Raises:
            RuntimeError: If spawn fails.
        """
        try:
            from otto.mcp_tools.agent import agent_spawn

            result = await agent_spawn(
                prompt=prompt,
                backend=backend,
                notify=True,
                background=True,
            )

            if not result.get("success"):
                raise RuntimeError(result.get("error", "spawn failed"))

            data = result.get("data", {})
            return data.get("agent_id", "unknown")

        except ImportError:
            # Fallback for testing or when otto.mcp_tools not available
            logger.warning("retry_spawn_import_fallback")
            import uuid

            return uuid.uuid4().hex[:8]

    @staticmethod
    def _is_empty_prompt(prompt: str) -> bool:
        """
        Check if a prompt is too vague/empty to produce useful agent output.

        Short, context-free prompts like "retry this" or "do something" just
        cause agents to respond with "I need more context" and loop forever.

        Args:
            prompt: The task prompt to check.

        Returns:
            True if prompt should NOT be retried.
        """
        if not prompt or not prompt.strip():
            return True

        cleaned = prompt.strip().lower()

        # Too short to be actionable (under 15 chars, e.g. "retry this", "do something")
        if len(cleaned) < 15:
            return True

        # Known vague prompts that produce no useful output
        vague_patterns = [
            "retry this",
            "do something",
            "try again",
            "run again",
            "redo this",
            "help me",
            "do it",
        ]
        for pattern in vague_patterns:
            if cleaned == pattern or cleaned.startswith(pattern + " "):
                return True

        return False

    def get_pending_retries(self) -> list[PendingRetry]:
        """
        Get all pending retries.

        Returns:
            List of PendingRetry objects.
        """
        return list(self._pending_retries.values())

    def cancel_retry(self, agent_id: str) -> bool:
        """
        Cancel a scheduled retry.

        Args:
            agent_id: The agent ID to cancel retry for.

        Returns:
            True if cancelled, False if not found.
        """
        if agent_id in self._pending_retries:
            del self._pending_retries[agent_id]
            self._persist_retries()
            logger.info("retry_cancelled", extra={"agent_id": agent_id})
            return True
        return False

    def get_stats(self) -> dict[str, Any]:
        """
        Get retry statistics.

        Returns:
            Dict with retry counts and pending info.
        """
        # Count from state manager
        state = self.state_manager.load_state()
        retrying_count = 0
        exhausted_count = 0

        for agent in state.agents.values():
            if agent.status == AgentStatus.RETRYING:
                retrying_count += 1
            elif agent.status == AgentStatus.FAILED:
                if agent.retry_count >= agent.max_retries:
                    exhausted_count += 1

        return {
            "pending_retries": len(self._pending_retries),
            "agents_retrying": retrying_count,
            "retries_exhausted": exhausted_count,
            "cached_triages": len(self._triage_cache),
        }

    def clear_caches(self) -> None:
        """Clear all in-memory caches and persisted state."""
        self._pending_retries.clear()
        self._triage_cache.clear()
        self._persist_retries()
        self._persist_triage_cache()
        logger.debug("retry_caches_cleared")
