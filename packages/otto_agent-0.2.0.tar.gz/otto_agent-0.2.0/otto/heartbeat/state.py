"""
State File Manager for Heartbeat.

Handles loading, saving, and managing heartbeat state with:
- Atomic writes (temp file + rename)
- File locking for concurrent access
- Auto-backup before overwrites
- JSON serialization via Pydantic
"""

import fcntl
import json
import shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Optional

from .types import AgentState, AgentStatus, HeartbeatState

# Default state file location
DEFAULT_STATE_PATH = Path.home() / ".otto" / "heartbeat" / "state.json"
BACKUP_SUFFIX = ".backup"


class StateManager:
    """
    Manages heartbeat state file with atomic writes and locking.

    Provides safe concurrent access to the shared state file,
    automatic backups, and convenience methods for agent state queries.

    Example:
        manager = StateManager()
        state = manager.load_state()
        manager.update_agent_state("agent-123", new_state)
        manager.save_state(state)
    """

    def __init__(self, path: Optional[Path] = None) -> None:
        """
        Initialize StateManager.

        Args:
            path: Path to state file. Defaults to ~/.otto/heartbeat/state.json
        """
        self.path = path or DEFAULT_STATE_PATH
        self._ensure_dir()

    def _ensure_dir(self) -> None:
        """Ensure state directory exists."""
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def load_state(self, path: Optional[Path] = None) -> HeartbeatState:
        """
        Load state from file.

        Uses file locking to prevent concurrent read/write issues.
        Returns empty state if file doesn't exist.

        Args:
            path: Override path for this operation.

        Returns:
            HeartbeatState loaded from file or fresh empty state.
        """
        target = path or self.path

        if not target.exists():
            return HeartbeatState()

        try:
            with open(target, "r") as f:
                # Shared lock for reading
                fcntl.flock(f.fileno(), fcntl.LOCK_SH)
                try:
                    data = json.load(f)
                    return HeartbeatState.model_validate(data)
                finally:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        except (json.JSONDecodeError, OSError) as e:
            # Corrupted file - try backup
            backup_path = target.with_suffix(target.suffix + BACKUP_SUFFIX)
            if backup_path.exists():
                try:
                    data = json.loads(backup_path.read_text())
                    return HeartbeatState.model_validate(data)
                except (json.JSONDecodeError, OSError):
                    pass
            # Return fresh state if all recovery fails
            return HeartbeatState()

    def save_state(self, state: HeartbeatState, path: Optional[Path] = None) -> None:
        """
        Save state to file atomically.

        Uses temp file + rename pattern for atomicity.
        Creates backup of existing file before overwrite.
        File locking prevents concurrent writes.

        Args:
            state: HeartbeatState to save.
            path: Override path for this operation.
        """
        target = path or self.path
        self._ensure_dir()

        # Serialize state
        data = state.model_dump(mode="json")
        content = json.dumps(data, indent=2, default=str)

        # Backup existing file
        if target.exists():
            backup_path = target.with_suffix(target.suffix + BACKUP_SUFFIX)
            shutil.copy2(target, backup_path)

        # Atomic write: temp file in same dir, then rename
        temp_fd = NamedTemporaryFile(
            mode="w",
            dir=target.parent,
            prefix=".state_",
            suffix=".tmp",
            delete=False,
        )
        try:
            # Exclusive lock for writing
            fcntl.flock(temp_fd.fileno(), fcntl.LOCK_EX)
            try:
                temp_fd.write(content)
                temp_fd.flush()
            finally:
                fcntl.flock(temp_fd.fileno(), fcntl.LOCK_UN)
            temp_fd.close()

            # Atomic rename
            Path(temp_fd.name).rename(target)
        except Exception:
            # Cleanup temp file on failure
            Path(temp_fd.name).unlink(missing_ok=True)
            raise

    def get_agent_state(self, agent_id: str) -> Optional[AgentState]:
        """
        Get state for a specific agent.

        Args:
            agent_id: The agent ID to look up.

        Returns:
            AgentState if found, None otherwise.
        """
        state = self.load_state()
        return state.agents.get(agent_id)

    def update_agent_state(self, agent_id: str, agent_state: AgentState) -> None:
        """
        Update state for a specific agent.

        Loads current state, updates the agent, and saves atomically.

        Args:
            agent_id: The agent ID to update.
            agent_state: New state for the agent.
        """
        state = self.load_state()
        state.agents[agent_id] = agent_state
        self.save_state(state)

    def remove_agent_state(self, agent_id: str) -> bool:
        """
        Remove an agent from state.

        Args:
            agent_id: The agent ID to remove.

        Returns:
            True if agent was removed, False if not found.
        """
        state = self.load_state()
        if agent_id in state.agents:
            del state.agents[agent_id]
            self.save_state(state)
            return True
        return False

    def get_pending_retries(self) -> list[AgentState]:
        """
        Get all agents that need retry.

        Returns agents with status FAILED or RETRYING that
        haven't exceeded max_retries.

        Returns:
            List of AgentState objects eligible for retry.
        """
        state = self.load_state()
        pending = []
        for agent in state.agents.values():
            if agent.status in (AgentStatus.FAILED, AgentStatus.RETRYING):
                if agent.retry_count < agent.max_retries:
                    pending.append(agent)
        return pending

    def get_failed_agents(self) -> list[AgentState]:
        """
        Get all failed agents (exhausted retries).

        Returns agents that have failed and exceeded max_retries.

        Returns:
            List of permanently failed AgentState objects.
        """
        state = self.load_state()
        failed = []
        for agent in state.agents.values():
            if agent.status == AgentStatus.FAILED:
                if agent.retry_count >= agent.max_retries:
                    failed.append(agent)
        return failed

    def cleanup_old_states(self, max_age_hours: int = 24) -> int:
        """
        Remove completed agents older than max_age.

        Only removes COMPLETED agents. Failed agents are kept
        for investigation.

        Args:
            max_age_hours: Maximum age in hours for completed agents.

        Returns:
            Number of agents removed.
        """
        state = self.load_state()
        cutoff = datetime.now(timezone.utc) - timedelta(hours=max_age_hours)
        removed = 0

        agents_to_remove = []
        for agent_id, agent in state.agents.items():
            if agent.status == AgentStatus.COMPLETED:
                # Handle both naive and aware datetimes
                updated = agent.updated_at
                if updated.tzinfo is None:
                    updated = updated.replace(tzinfo=timezone.utc)
                if updated < cutoff:
                    agents_to_remove.append(agent_id)

        for agent_id in agents_to_remove:
            del state.agents[agent_id]
            removed += 1

        if removed > 0:
            self.save_state(state)

        return removed

    # ------------------------------------------------------------------
    # Cache persistence for retry / triage / escalation
    # ------------------------------------------------------------------

    def load_pending_retries(self) -> dict[str, dict]:
        """Load persisted pending retries from state file."""
        state = self.load_state()
        return dict(state.pending_retries)

    def save_pending_retries(self, retries: dict[str, dict]) -> None:
        """Save pending retries to state file."""
        state = self.load_state()
        state.pending_retries = retries
        self.save_state(state)

    def load_triage_cache(self) -> dict[str, dict]:
        """Load persisted triage cache from state file."""
        state = self.load_state()
        return dict(state.triage_cache)

    def save_triage_cache(self, cache: dict[str, dict]) -> None:
        """Save triage cache to state file."""
        state = self.load_state()
        state.triage_cache = cache
        self.save_state(state)

    def load_pending_diagnostics(self) -> dict[str, str]:
        """Load persisted pending diagnostics from state file."""
        state = self.load_state()
        return dict(state.pending_diagnostics)

    def save_pending_diagnostics(self, diagnostics: dict[str, str]) -> None:
        """Save pending diagnostics to state file."""
        state = self.load_state()
        state.pending_diagnostics = diagnostics
        self.save_state(state)

    def get_stats(self) -> dict[str, int]:
        """
        Get summary statistics of current state.

        Returns:
            Dict with counts by status.
        """
        state = self.load_state()
        stats: dict[str, int] = {
            "total": len(state.agents),
            "pending": 0,
            "running": 0,
            "completed": 0,
            "failed": 0,
            "retrying": 0,
        }
        for agent in state.agents.values():
            status_key = agent.status.value if hasattr(agent.status, "value") else agent.status
            if status_key in stats:
                stats[status_key] += 1
        return stats
