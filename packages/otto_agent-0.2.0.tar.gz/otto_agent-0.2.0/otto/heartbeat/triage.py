"""
Programmatic Triage for Failed Agents.

Analyzes agent output to classify failures and suggest actions:
- TRANSIENT: Retry-worthy errors (rate limits, timeouts)
- PERMANENT: Fatal errors (auth, syntax)
- UNKNOWN: Needs human review
"""

import re
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Optional

from pydantic import BaseModel, Field


class TriageCategory(str, Enum):
    """Classification of failure type for retry/escalation decisions."""

    TRANSIENT = "transient"  # Worth retrying (rate limits, timeouts)
    PERMANENT = "permanent"  # Fatal, needs escalation (auth, syntax)
    UNKNOWN = "unknown"  # Unclassified, needs human review


class TriageResult(BaseModel):
    """Result of analyzing an agent failure."""

    agent_id: str
    category: TriageCategory
    confidence: float = Field(ge=0.0, le=1.0)
    suggested_action: str
    analysis: str
    matched_pattern: Optional[str] = None
    triaged_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    class Config:
        use_enum_values = True


# Pattern definitions: (regex, category, confidence, description)
ERROR_PATTERNS: list[tuple[str, TriageCategory, float, str]] = [
    # Rate limiting - TRANSIENT
    (r"rate.?limit", TriageCategory.TRANSIENT, 0.95, "Rate limit hit"),
    (r"too many requests", TriageCategory.TRANSIENT, 0.95, "Too many requests"),
    (r"429", TriageCategory.TRANSIENT, 0.90, "HTTP 429 rate limit"),
    (r"quota.?exceeded", TriageCategory.TRANSIENT, 0.90, "Quota exceeded"),
    (r"throttl", TriageCategory.TRANSIENT, 0.85, "Request throttled"),
    # Network/timeout - TRANSIENT
    (r"timeout", TriageCategory.TRANSIENT, 0.85, "Request timeout"),
    (r"timed?\s*out", TriageCategory.TRANSIENT, 0.85, "Operation timed out"),
    (r"connection.?(refused|reset|closed)", TriageCategory.TRANSIENT, 0.80, "Connection error"),
    (r"ECONNREFUSED", TriageCategory.TRANSIENT, 0.90, "Connection refused"),
    (r"ETIMEDOUT", TriageCategory.TRANSIENT, 0.90, "Connection timeout"),
    (r"network.?(error|unreachable)", TriageCategory.TRANSIENT, 0.80, "Network error"),
    (r"503", TriageCategory.TRANSIENT, 0.75, "HTTP 503 service unavailable"),
    (r"502", TriageCategory.TRANSIENT, 0.75, "HTTP 502 bad gateway"),
    (r"temporary.?failure", TriageCategory.TRANSIENT, 0.85, "Temporary failure"),
    (r"service.?unavailable", TriageCategory.TRANSIENT, 0.80, "Service unavailable"),
    # Auth failures - PERMANENT
    (
        r"auth(entication|orization)?.?(fail|error|denied)",
        TriageCategory.PERMANENT,
        0.95,
        "Authentication failure",
    ),
    (r"401", TriageCategory.PERMANENT, 0.90, "HTTP 401 unauthorized"),
    (r"403", TriageCategory.PERMANENT, 0.85, "HTTP 403 forbidden"),
    (r"invalid.?(api.?)?key", TriageCategory.PERMANENT, 0.95, "Invalid API key"),
    (r"expired.?(token|key|credential)", TriageCategory.PERMANENT, 0.95, "Expired credentials"),
    (r"permission.?denied", TriageCategory.PERMANENT, 0.90, "Permission denied"),
    (r"access.?denied", TriageCategory.PERMANENT, 0.90, "Access denied"),
    # Syntax/code errors - PERMANENT
    (r"syntax.?error", TriageCategory.PERMANENT, 0.95, "Syntax error"),
    (r"SyntaxError", TriageCategory.PERMANENT, 0.95, "Python syntax error"),
    (r"IndentationError", TriageCategory.PERMANENT, 0.95, "Indentation error"),
    (r"NameError", TriageCategory.PERMANENT, 0.90, "Undefined name"),
    (r"TypeError", TriageCategory.PERMANENT, 0.85, "Type error"),
    (r"AttributeError", TriageCategory.PERMANENT, 0.85, "Attribute error"),
    (r"ImportError", TriageCategory.PERMANENT, 0.90, "Import error"),
    (r"ModuleNotFoundError", TriageCategory.PERMANENT, 0.90, "Module not found"),
    (r"FileNotFoundError", TriageCategory.PERMANENT, 0.80, "File not found"),
    (r"ValueError", TriageCategory.PERMANENT, 0.75, "Value error"),
    # Resource issues - can be either
    (r"out.?of.?memory", TriageCategory.TRANSIENT, 0.70, "Out of memory"),
    (r"disk.?full", TriageCategory.PERMANENT, 0.85, "Disk full"),
    (r"no.?space.?left", TriageCategory.PERMANENT, 0.85, "No disk space"),
    # No-context agents - completed but produced no useful output (PERMANENT, don't retry)
    (
        r"I('d|\s+would)\s+(be\s+)?happy\s+to\s+help.*but\s+I\s+need.*more\s+context",
        TriageCategory.PERMANENT,
        0.95,
        "No-context agent output",
    ),
    (
        r"need\s+a\s+bit\s+more\s+(context|direction|information).*what\s+(would|do)\s+you",
        TriageCategory.PERMANENT,
        0.90,
        "No-context agent output",
    ),
    (
        r"what\s+would\s+you\s+like\s+me\s+to\s+(retry|do|help)",
        TriageCategory.PERMANENT,
        0.85,
        "No-context agent output",
    ),
]


class TriageEngine:
    """
    Automated failure analysis for agent outputs.

    Analyzes agent output files to classify failures and suggest
    appropriate actions (retry, escalate, or human review).

    Example:
        engine = TriageEngine()
        result = engine.analyze("agent-123", Path("/path/to/output.txt"))
        if result.category == TriageCategory.TRANSIENT:
            # Retry the agent
            pass
    """

    def __init__(self) -> None:
        """Initialize TriageEngine with compiled patterns."""
        self._compiled_patterns: list[tuple[re.Pattern, TriageCategory, float, str]] = [
            (re.compile(pattern, re.IGNORECASE), cat, conf, desc)
            for pattern, cat, conf, desc in ERROR_PATTERNS
        ]
        self._history: dict[str, list[TriageResult]] = {}

    def analyze(self, agent_id: str, output_path: Path) -> TriageResult:
        """
        Main entry point: analyze agent output file.

        Args:
            agent_id: The agent ID being analyzed.
            output_path: Path to the agent's output file.

        Returns:
            TriageResult with classification and suggested action.
        """
        # Read output content
        try:
            content = output_path.read_text(errors="replace")
        except FileNotFoundError:
            result = TriageResult(
                agent_id=agent_id,
                category=TriageCategory.UNKNOWN,
                confidence=0.5,
                suggested_action="investigate",
                analysis="Output file not found - cannot analyze",
            )
            self._record_history(result)
            return result
        except OSError as e:
            result = TriageResult(
                agent_id=agent_id,
                category=TriageCategory.UNKNOWN,
                confidence=0.5,
                suggested_action="investigate",
                analysis=f"Failed to read output file: {e}",
            )
            self._record_history(result)
            return result

        # Classify the error
        category, confidence, matched_pattern = self._classify_error(content)

        # Build result
        result = TriageResult(
            agent_id=agent_id,
            category=category,
            confidence=confidence,
            suggested_action=self._suggest_action(category),
            analysis=self._build_analysis(category, matched_pattern, content),
            matched_pattern=matched_pattern,
        )

        self._record_history(result)
        return result

    def analyze_content(self, agent_id: str, content: str) -> TriageResult:
        """
        Analyze raw content instead of file.

        Useful when output is already in memory.

        Args:
            agent_id: The agent ID being analyzed.
            content: Raw output content to analyze.

        Returns:
            TriageResult with classification and suggested action.
        """
        category, confidence, matched_pattern = self._classify_error(content)

        result = TriageResult(
            agent_id=agent_id,
            category=category,
            confidence=confidence,
            suggested_action=self._suggest_action(category),
            analysis=self._build_analysis(category, matched_pattern, content),
            matched_pattern=matched_pattern,
        )

        self._record_history(result)
        return result

    def _classify_error(self, content: str) -> tuple[TriageCategory, float, Optional[str]]:
        """
        Pattern matching to classify error type.

        Scans content for known error patterns and returns the
        highest-confidence match.

        Args:
            content: Output content to analyze.

        Returns:
            Tuple of (category, confidence, matched_pattern_description).
        """
        if not content or not content.strip():
            return TriageCategory.UNKNOWN, 0.3, None

        best_match: tuple[TriageCategory, float, str] | None = None

        for pattern, category, confidence, description in self._compiled_patterns:
            if pattern.search(content):
                if best_match is None or confidence > best_match[1]:
                    best_match = (category, confidence, description)

        if best_match:
            return best_match

        # No pattern matched
        return TriageCategory.UNKNOWN, 0.5, None

    def _suggest_action(self, category: TriageCategory) -> str:
        """
        Determine what to do based on category.

        Args:
            category: The triage category.

        Returns:
            Suggested action string.
        """
        actions = {
            TriageCategory.TRANSIENT: "retry",
            TriageCategory.PERMANENT: "escalate",
            TriageCategory.UNKNOWN: "human_review",
        }
        return actions.get(category, "human_review")

    def _build_analysis(
        self,
        category: TriageCategory,
        matched_pattern: Optional[str],
        content: str,
    ) -> str:
        """
        Build human-readable analysis summary.

        Args:
            category: The determined category.
            matched_pattern: Pattern that matched (if any).
            content: Original content.

        Returns:
            Analysis string.
        """
        if matched_pattern:
            return f"Detected '{matched_pattern}' - classified as {category.value}"

        # Extract last few lines for context if no pattern matched
        lines = content.strip().split("\n")
        last_lines = lines[-3:] if len(lines) > 3 else lines
        context = " | ".join(line.strip()[:50] for line in last_lines if line.strip())

        if context:
            return f"No known pattern matched. Last output: {context[:150]}"
        return "No known pattern matched and output was empty or unreadable"

    def _record_history(self, result: TriageResult) -> None:
        """Record triage result in history."""
        if result.agent_id not in self._history:
            self._history[result.agent_id] = []
        self._history[result.agent_id].append(result)

    def get_triage_history(self, agent_id: str) -> list[TriageResult]:
        """
        Get past triage results for an agent.

        Args:
            agent_id: The agent ID to look up.

        Returns:
            List of TriageResult objects, oldest first.
        """
        return self._history.get(agent_id, [])

    def clear_history(self, agent_id: Optional[str] = None) -> None:
        """
        Clear triage history.

        Args:
            agent_id: Specific agent to clear, or None for all.
        """
        if agent_id:
            self._history.pop(agent_id, None)
        else:
            self._history.clear()

    def get_stats(self) -> dict[str, int]:
        """
        Get summary statistics of triage history.

        Returns:
            Dict with counts by category.
        """
        stats = {
            "total": 0,
            "transient": 0,
            "permanent": 0,
            "unknown": 0,
        }

        for results in self._history.values():
            for result in results:
                stats["total"] += 1
                cat = result.category
                if isinstance(cat, str):
                    stats[cat] += 1
                else:
                    stats[cat.value] += 1

        return stats
