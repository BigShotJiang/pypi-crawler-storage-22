"""
Heartbeat state schema types.

Pydantic models for Otto's self-monitoring heartbeat system that:
- Tracks agent states and failures
- Monitors scheduled task execution
- Detects changes via hash checksums
- Supports auto-retry and escalation
"""

from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class AgentStatus(str, Enum):
    """Lifecycle status of a spawned agent."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYING = "retrying"


class ErrorSeverity(str, Enum):
    """Classification of error severity for retry/escalation decisions."""

    RECOVERABLE = "recoverable"  # Transient errors, worth retrying
    CRITICAL = "critical"  # Fatal errors, needs human intervention
    UNKNOWN = "unknown"  # Unclassified, default to retry with caution


class AgentState(BaseModel):
    """State of a single spawned agent."""

    id: str
    status: AgentStatus
    error: Optional[str] = None
    error_type: Optional[ErrorSeverity] = None
    retry_count: int = 0
    max_retries: int = 3
    created_at: datetime
    updated_at: datetime
    last_error_at: Optional[datetime] = None

    class Config:
        use_enum_values = True


class ScheduleState(BaseModel):
    """State of a scheduled task."""

    id: str
    name: str
    next_run: Optional[datetime] = None
    last_run: Optional[datetime] = None
    last_status: Optional[str] = None
    missed_count: int = 0


class CheckState(BaseModel):
    """State of a user-defined heartbeat check."""

    id: str
    last_run: Optional[datetime] = None
    next_run: Optional[datetime] = None
    last_status: Optional[str] = None  # "ok", "action", "error"
    last_output: Optional[str] = None  # Brief summary of last result
    run_count: int = 0
    error_count: int = 0


class HeartbeatState(BaseModel):
    """Overall heartbeat state tracking agents and schedules."""

    last_check: Optional[datetime] = None
    next_check: Optional[datetime] = None
    interval_seconds: int = 300  # 5 min default
    agents: dict[str, AgentState] = Field(default_factory=dict)
    schedules: dict[str, ScheduleState] = Field(default_factory=dict)
    checks: dict[str, CheckState] = Field(default_factory=dict)  # user-defined checks

    # Persisted caches for restart resilience
    pending_retries: dict[str, dict] = Field(default_factory=dict)
    triage_cache: dict[str, dict] = Field(default_factory=dict)
    pending_diagnostics: dict[str, str] = Field(default_factory=dict)


class StateChecksums(BaseModel):
    """Hash checksums for quick change detection.

    Heartbeat compares these hashes to detect state changes
    without loading full state files.
    """

    agents_hash: Optional[str] = None
    schedules_hash: Optional[str] = None
    errors_hash: Optional[str] = None
    checked_at: datetime


class HeartbeatConfig(BaseModel):
    """Heartbeat configuration from settings.yaml."""

    enabled: bool = True
    interval: str = "5m"  # Human-readable interval
    interval_seconds: int = 300
    auto_retry: bool = True
    max_retries: int = 3
    escalate_to_llm: bool = True
    notify_on: list[str] = Field(
        default_factory=lambda: ["agent_failed", "schedule_missed", "critical_error"]
    )
