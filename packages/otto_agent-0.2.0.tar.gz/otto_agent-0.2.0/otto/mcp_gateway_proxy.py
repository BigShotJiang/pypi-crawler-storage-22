"""
Gateway MCP Proxy Server — routes Claude SDK tool calls through the gateway.

Problem:
    When Claude SDK receives mcp_servers configs, it connects to MCP servers
    DIRECTLY, bypassing the gateway's policy engine (safeguards, tool filtering,
    permissions, audit logging).

Solution:
    This module creates a single MCP server that acts as a proxy. Instead of
    passing raw transport configs to the SDK, we pass this proxy server. It:
    1. Discovers tools from all gateway-managed external MCP servers
    2. Exposes them as namespaced tools (server__tool_name)
    3. Routes every call through gateway.request_tool() for full policy enforcement
    4. Also includes Otto's built-in tools (memory, agents, pipelines, etc.)

    This means ALL tool calls from Claude SDK go through the same 7-step
    pipeline (allowlist → filtering → safeguards → permissions → prompt → execute → audit)
    that GenericBackend already uses.

Usage:
    # Instead of passing raw configs:
    #   mcp_servers = gateway.get_mcp_server_configs()
    # Use the proxy:
    #   mcp_servers = {"otto-gateway": get_gateway_proxy_config()}

Architecture:
    Claude SDK → stdio → GatewayProxyServer → gateway.request_tool() → MCP servers
                                                      ↓
                                               Policy enforcement
                                               Safeguard checks
                                               Audit logging
"""

from __future__ import annotations

import asyncio
import logging
import sys
from typing import Any

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Tool discovery & proxy registration
# ---------------------------------------------------------------------------


async def _discover_gateway_tools() -> list[dict[str, Any]]:
    """
    Discover tools from all gateway-managed external MCP servers.

    Returns a list of tool descriptors with server/tool binding info:
    [{"namespaced": "server__tool", "server": "server", "tool": "tool",
      "description": "...", "input_schema": {...}}, ...]
    """
    from otto.gateway import get_gateway

    gateway = get_gateway()
    discovered: list[dict[str, Any]] = []

    for name, policy in gateway.list_servers().items():
        if not policy.enabled or policy.builtin or not policy.transport:
            continue

        try:
            tools = await gateway.list_tools(name)
        except Exception as exc:
            log.warning("Failed to discover tools for server '%s': %s", name, exc)
            continue

        for tool_desc in tools:
            tool_name = tool_desc.get("name", "")
            if not tool_name:
                continue

            discovered.append(
                {
                    "namespaced": f"{name}__{tool_name}",
                    "server": name,
                    "tool": tool_name,
                    "description": tool_desc.get("description", f"{tool_name} from {name}"),
                    "input_schema": tool_desc.get(
                        "inputSchema", {"type": "object", "properties": {}}
                    ),
                }
            )

    log.info(
        "Gateway proxy: discovered %d tools from %d servers",
        len(discovered),
        len(gateway.list_servers()),
    )
    return discovered


def _make_proxy_handler(server_name: str, tool_name: str):
    """
    Create an async proxy handler that routes through gateway.request_tool().

    The handler is a closure that captures the server/tool binding.
    """
    _server = server_name
    _tool = tool_name

    async def proxy_handler(**kwargs: Any) -> str:
        from otto.gateway import ToolRequest, get_gateway

        gateway = get_gateway()
        request = ToolRequest(
            server=_server,
            tool=_tool,
            arguments=kwargs,
            backend="pi",
        )

        response = await gateway.request_tool(request)

        if response.success:
            return response.output or ""
        else:
            # Return error as text — MCP protocol handles error signaling
            return f"Error: {response.error or 'Unknown error'}"

    return proxy_handler


def _register_proxy_tools(server, tools: list[dict[str, Any]]) -> int:
    """
    Register discovered gateway tools as proxy handlers on a FastMCP server.

    Overrides FastMCP's auto-generated parameter schema with the real schema
    from the external MCP server so that clients see the correct parameters
    (not an opaque ``kwargs`` blob).

    Returns count of registered tools.
    """
    count = 0
    for tool_info in tools:
        handler = _make_proxy_handler(tool_info["server"], tool_info["tool"])
        handler.__name__ = tool_info["namespaced"]
        handler.__qualname__ = tool_info["namespaced"]
        handler.__doc__ = tool_info["description"]

        server.tool(
            name=tool_info["namespaced"],
            description=tool_info["description"],
        )(handler)

        # Patch the registered Tool's parameter schema and arg_model so that
        # FastMCP exposes the real input schema from the external server and
        # validates/passes arguments correctly instead of wrapping them in a
        # single ``kwargs`` parameter.
        registered_tool = server._tool_manager._tools.get(tool_info["namespaced"])
        if registered_tool is not None:
            input_schema = tool_info.get("input_schema", {})
            _patch_tool_schema(registered_tool, input_schema)

        count += 1

    return count


def _patch_tool_schema(tool, input_schema: dict[str, Any]) -> None:
    """
    Replace a FastMCP Tool's auto-generated schema with a real one.

    Creates a dynamic Pydantic model from the external server's input schema
    so that FastMCP's arg validation passes arguments through correctly.
    """
    from mcp.server.fastmcp.utilities.func_metadata import (
        ArgModelBase,
        FuncMetadata,
    )
    from pydantic import create_model

    properties = input_schema.get("properties", {})
    required = set(input_schema.get("required", []))

    if not properties:
        return  # nothing to patch

    # Build pydantic field definitions: {name: (type, default)}
    field_defs: dict[str, Any] = {}
    for name, prop in properties.items():
        annotation = _json_type_to_python(prop)
        if name in required:
            field_defs[name] = (annotation, ...)
        else:
            field_defs[name] = (annotation, None)

    # Create a dynamic Pydantic model that extends ArgModelBase
    DynModel = create_model(
        f"{tool.name}Arguments",
        __base__=ArgModelBase,
        **field_defs,
    )

    # Replace the parameters schema exposed to MCP clients
    tool.parameters = input_schema

    # Replace the fn_metadata so arg validation uses the real model
    tool.fn_metadata = FuncMetadata(
        arg_model=DynModel,
        output_schema=None,
        output_model=None,
        wrap_output=False,
    )


def _json_type_to_python(prop: dict[str, Any]) -> type:
    """Map a JSON schema property to a Python type annotation."""
    json_type = prop.get("type", "string")
    if json_type == "string":
        return str
    elif json_type == "integer":
        return int
    elif json_type == "number":
        return float
    elif json_type == "boolean":
        return bool
    elif json_type == "array":
        return list
    elif json_type == "object":
        return dict
    return str  # fallback


# ---------------------------------------------------------------------------
# Server creation & entry point
# ---------------------------------------------------------------------------


def _build_server(gateway_tools: list[dict[str, Any]]):
    """
    Build the complete proxy FastMCP server with all tools.

    Includes:
    1. External MCP server tools (routed through gateway)
    2. Otto's built-in MCP tools (memory, agents, pipelines, platform, schedules)
    """
    from mcp.server.fastmcp import FastMCP

    from otto.mcp_tools import register_tools

    server = FastMCP("otto-gateway-proxy")

    # 1. Register external MCP tools as gateway-proxied handlers
    proxy_count = _register_proxy_tools(server, gateway_tools)
    log.info("Registered %d gateway-proxied tools", proxy_count)

    # 2. Register Otto's built-in tools (agent_spawn, memory_recall, etc.)
    register_tools(server)

    # 3. Register file-based memory tools (memory_recall, memory_remember, etc.)
    # These are separate from the MCP tools in mcp_tools/ — they use
    # file-based storage and FTS5 search directly.
    _register_memory_tools(server)

    return server


def _register_memory_tools(server) -> None:
    """Register the file-based memory tools on the server."""
    import asyncio
    from datetime import datetime
    from pathlib import Path

    from otto import memory as memory_index
    from otto.paths import MEMORY_DIR
    from otto_tools.memory import CATEGORIES, sanitize_topic, search_memory

    def _ensure_memory_dir() -> Path:
        MEMORY_DIR.mkdir(parents=True, exist_ok=True)
        return MEMORY_DIR

    @server.tool()
    async def memory_recall(query: str, limit: int = 10) -> dict[str, Any]:
        """
        Search file-based memory for matching content.

        Args:
            query: Search query string
            limit: Maximum results to return
        """
        try:
            if not query.strip():
                return {"success": False, "data": None, "error": "query is required"}
            results = await asyncio.to_thread(search_memory, query, limit)
            return {"success": True, "data": {"query": query, "results": results}, "error": None}
        except Exception as exc:
            return {"success": False, "data": None, "error": str(exc)}

    @server.tool()
    async def memory_remember(category: str, topic: str, content: str) -> dict[str, Any]:
        """
        Store information in memory files.

        Args:
            category: Memory category (projects, facts, contexts)
            topic: Topic name
            content: Content to store
        """
        try:
            if category not in CATEGORIES:
                return {
                    "success": False,
                    "data": None,
                    "error": f"invalid category '{category}' (valid: {', '.join(CATEGORIES)})",
                }
            if not content.strip():
                return {"success": False, "data": None, "error": "content is required"}

            def _remember():
                memory_dir = _ensure_memory_dir()
                cat_dir = memory_dir / category
                cat_dir.mkdir(parents=True, exist_ok=True)
                safe_topic = sanitize_topic(topic)
                file_path = cat_dir / f"{safe_topic}.md"
                timestamp = datetime.now().isoformat()
                if file_path.exists():
                    file_path.write_text(
                        file_path.read_text() + f"\n\n---\n_Updated: {timestamp}_\n\n{content}"
                    )
                    return {"action": "updated", "file": str(file_path)}
                else:
                    file_path.write_text(f"# {topic}\n\n_Created: {timestamp}_\n\n{content}\n")
                    return {"action": "created", "file": str(file_path)}

            result = await asyncio.to_thread(_remember)
            return {"success": True, "data": result, "error": None}
        except Exception as exc:
            return {"success": False, "data": None, "error": str(exc)}

    @server.tool()
    async def memory_list(category: str | None = None) -> dict[str, Any]:
        """
        List stored memory files.

        Args:
            category: Optional category filter
        """
        try:
            if category and category not in CATEGORIES:
                return {
                    "success": False,
                    "data": None,
                    "error": f"invalid category '{category}' (valid: {', '.join(CATEGORIES)})",
                }

            def _list():
                memory_dir = _ensure_memory_dir()
                categories = [category] if category else list(CATEGORIES)
                result = {}
                for cat in categories:
                    cat_dir = memory_dir / cat
                    if not cat_dir.exists():
                        continue
                    files = []
                    for file in sorted(cat_dir.glob("*.md")):
                        stat = file.stat()
                        files.append(
                            {
                                "name": file.stem,
                                "size": stat.st_size,
                                "modified": int(stat.st_mtime),
                            }
                        )
                    if files:
                        result[cat] = files
                return result

            result = await asyncio.to_thread(_list)
            return {"success": True, "data": result, "error": None}
        except Exception as exc:
            return {"success": False, "data": None, "error": str(exc)}

    @server.tool()
    async def memory_forget(category: str, topic: str) -> dict[str, Any]:
        """
        Delete a memory file.

        Args:
            category: Memory category
            topic: Topic name
        """
        try:
            if category not in CATEGORIES:
                return {
                    "success": False,
                    "data": None,
                    "error": f"invalid category '{category}' (valid: {', '.join(CATEGORIES)})",
                }

            def _forget():
                memory_dir = _ensure_memory_dir()
                safe_topic = sanitize_topic(topic)
                file_path = memory_dir / category / f"{safe_topic}.md"
                if not file_path.exists():
                    return None
                file_path.unlink()
                return {"deleted": str(file_path)}

            result = await asyncio.to_thread(_forget)
            if result is None:
                return {
                    "success": False,
                    "data": None,
                    "error": f"not_found: {MEMORY_DIR / category / f'{sanitize_topic(topic)}.md'}",
                }
            return {"success": True, "data": result, "error": None}
        except Exception as exc:
            return {"success": False, "data": None, "error": str(exc)}

    @server.tool()
    async def memory_search_fts(
        query: str, limit: int = 5, source_types: list[str] | None = None
    ) -> dict[str, Any]:
        """
        Search indexed memory using FTS5.

        Args:
            query: Search query
            limit: Max results
            source_types: Optional filter (knowledge, project, session)
        """
        try:
            if not query.strip():
                return {"success": False, "data": None, "error": "query is required"}
            results = await asyncio.to_thread(
                memory_index.search, query, limit=limit, source_types=source_types
            )
            return {"success": True, "data": {"query": query, "results": results}, "error": None}
        except Exception as exc:
            return {"success": False, "data": None, "error": str(exc)}


async def _discover_and_reset() -> list[dict[str, Any]]:
    """
    Discover tools from external MCP servers, then close/reset the gateway.

    The gateway singleton holds stdio connections tied to the *current*
    event loop.  ``server.run(transport="stdio")`` creates a **new** loop,
    so any connections from discovery would be dead.  By closing the
    gateway here we ensure it gets lazily re-created (with fresh
    connections) the first time a tool call arrives in the serving loop.
    """
    tools = await _discover_gateway_tools()

    from otto.gateway import close_gateway

    await close_gateway()

    return tools


def run() -> None:
    """
    Run the gateway proxy MCP server on stdio.

    This is the entry point when invoked as: python -m otto.mcp_gateway_proxy
    Tool discovery is async (needs gateway connections), so we run it
    before starting the synchronous FastMCP server.
    """
    # Phase 1: Async discovery of external MCP server tools
    # Also resets the gateway singleton so connections are re-created
    # in the serving event loop (see _discover_and_reset docstring).
    gateway_tools = asyncio.run(_discover_and_reset())

    # Phase 2: Build server with all tools (sync)
    server = _build_server(gateway_tools)

    # Phase 3: Run on stdio (blocking)
    server.run(transport="stdio")


def get_gateway_proxy_config() -> dict[str, Any]:
    """
    Get MCP server config for the gateway proxy.

    Returns a stdio transport config that can be passed to Claude SDK's
    mcp_servers option. The proxy server handles ALL external MCP tools
    (routed through gateway for policy enforcement) plus Otto's built-in
    tools (memory, agents, pipelines, etc.).

    Returns:
        MCP server config dict: {"type": "stdio", "command": ..., "args": ...}
    """
    return {
        "type": "stdio",
        "command": sys.executable,
        "args": ["-m", "otto.mcp_gateway_proxy"],
    }


if __name__ == "__main__":
    run()
