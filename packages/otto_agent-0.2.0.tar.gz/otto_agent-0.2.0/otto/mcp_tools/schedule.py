"""MCP tools for agent self-scheduling."""

from __future__ import annotations

import asyncio
import sqlite3
import uuid
from datetime import datetime, timedelta
from typing import Any

from otto import schedule_state, schedule_store
from otto.jobs.queue import JobQueue
from otto.paths import OUTPUTS_DIR
from otto.prompts import build_agent_system_prompt


def _ok(data: dict[str, Any]) -> dict[str, Any]:
    return {"success": True, "data": data, "error": None}


def _error(message: str) -> dict[str, Any]:
    return {"success": False, "data": None, "error": message}


def _derive_task_name(prompt: str) -> str:
    cleaned = " ".join(line.strip() for line in prompt.splitlines() if line.strip())
    if not cleaned:
        return "Untitled schedule"
    return cleaned[:120]


def _build_agent_payload(
    *,
    schedule_id: str,
    prompt: str,
    task_name: str,
    backend: str,
    model: str | None,
    notify: str,
    system_prompt: str,
    timeout: int,
) -> dict[str, Any]:
    """Build payload matching what handle_agent expects."""
    output_file = OUTPUTS_DIR / f"{schedule_id}.txt"
    return {
        "agent_id": schedule_id,
        "prompt": prompt,
        "system": system_prompt,
        "task": task_name,
        "backend": backend,
        "model": model,
        "timeout": timeout,
        "notify": notify,
        "priority": "normal",
        "output_file": str(output_file),
    }


async def schedule_task(
    prompt: str,
    delay_seconds: int | None = None,
    run_at: str | None = None,
    cron: str | None = None,
    name: str | None = None,
    backend: str = "pi",
    model: str | None = None,
    notify: bool = True,
    chat_id: str | None = None,
) -> dict[str, Any]:
    """Schedule a task for future execution.

    Exactly one of delay_seconds, run_at, or cron must be provided.
    Tasks are executed as agents with full backend/model routing and
    reliable notification delivery.

    Args:
        prompt: The task prompt to execute
        delay_seconds: Run after this many seconds from now
        run_at: ISO-8601 datetime string for when to run (one-shot)
        cron: Cron expression for recurring execution (e.g. "0 9 * * *")
        name: Human-readable name (derived from prompt if omitted)
        backend: Backend to use ("pi", "litellm")
        model: Optional model override (e.g. "cerebras/zai-glm-4.7")
        notify: Whether to send notification on completion
        chat_id: Chat ID for targeted notification delivery
    """
    try:
        if not prompt or not prompt.strip():
            return _error("prompt is required")

        # Validate exactly one scheduling method
        methods = sum(1 for m in (delay_seconds, run_at, cron) if m is not None)
        if methods == 0:
            return _error("exactly one of delay_seconds, run_at, or cron is required")
        if methods > 1:
            return _error("only one of delay_seconds, run_at, or cron may be provided")

        schedule_id = "sched_" + uuid.uuid4().hex[:8]
        resolved_name = name.strip() if name and name.strip() else _derive_task_name(prompt)
        notify_mode = "always" if notify else "never"
        now = datetime.now()

        schedule_type: str
        cron_expr: str | None = None
        run_at_iso: str | None = None
        next_run: str

        if delay_seconds is not None:
            if not isinstance(delay_seconds, (int, float)) or delay_seconds < 0:
                return _error("delay_seconds must be a non-negative number")
            target = now + timedelta(seconds=int(delay_seconds))
            run_at_iso = target.isoformat()
            schedule_type = "once"
            next_run = run_at_iso

        elif run_at is not None:
            try:
                parsed = datetime.fromisoformat(str(run_at))
            except ValueError:
                return _error(f"run_at must be a valid ISO-8601 datetime, got: {run_at}")
            run_at_iso = parsed.isoformat()
            schedule_type = "once"
            next_run = run_at_iso

        else:  # cron
            try:
                from croniter import croniter
            except ImportError:
                return _error("croniter is required for cron schedules")
            cron_str = str(cron).strip()
            if not croniter.is_valid(cron_str):
                return _error(f"invalid cron expression: {cron_str}")
            cron_expr = cron_str
            schedule_type = "recurring"
            next_run = croniter(cron_str, now).get_next(datetime).isoformat()

        # Store in dynamic_schedules table (for listing/cancellation)
        await asyncio.to_thread(
            schedule_store.create_schedule,
            id=schedule_id,
            name=resolved_name,
            prompt=prompt,
            schedule_type=schedule_type,
            cron_expr=cron_expr,
            run_at=run_at_iso,
            backend=backend,
            model=model,
            notify=notify_mode,
            chat_id=chat_id,
        )

        # Short delay optimization: enqueue agent directly for delays <= 5 minutes
        if delay_seconds is not None and delay_seconds <= 300:
            from otto.backends import get_orchestration_config

            orch_config = await asyncio.to_thread(get_orchestration_config)
            default_timeout = orch_config.get("default_timeout", 3600)
            system_prompt = await asyncio.to_thread(build_agent_system_prompt)

            await asyncio.to_thread(OUTPUTS_DIR.mkdir, parents=True, exist_ok=True)

            payload = _build_agent_payload(
                schedule_id=schedule_id,
                prompt=prompt,
                task_name=resolved_name,
                backend=backend,
                model=model,
                notify=notify_mode,
                system_prompt=system_prompt,
                timeout=default_timeout,
            )

            def _enqueue():
                queue = JobQueue()
                try:
                    queue.add("agent", payload, external_id=schedule_id)
                except sqlite3.IntegrityError:
                    pass  # Already enqueued (dedup)

            await asyncio.to_thread(_enqueue)

        return _ok(
            {
                "schedule_id": schedule_id,
                "name": resolved_name,
                "schedule_type": schedule_type,
                "next_run": next_run,
                "enabled": True,
            }
        )
    except Exception as exc:
        return _error(str(exc))


async def schedule_list(
    include_disabled: bool = False,
) -> dict[str, Any]:
    """List dynamic schedules with status information.

    Args:
        include_disabled: Include cancelled/disabled schedules
    """
    try:
        schedules = await asyncio.to_thread(
            schedule_store.list_schedules, include_disabled=include_disabled
        )

        items: list[dict[str, Any]] = []
        for sched in schedules:
            sid = sched["id"]
            info: dict[str, Any] = {
                "schedule_id": sid,
                "name": sched["name"],
                "prompt": sched["prompt"][:200],
                "schedule_type": sched["schedule_type"],
                "backend": sched["backend"],
                "enabled": sched["enabled"],
                "created_at": sched["created_at"],
            }

            # Compute next_run
            if sched["schedule_type"] == "recurring" and sched.get("cron_expr"):
                try:
                    from croniter import croniter

                    nxt = croniter(sched["cron_expr"], datetime.now()).get_next(datetime)
                    info["next_run"] = nxt.isoformat()
                    info["cron"] = sched["cron_expr"]
                except Exception:
                    info["next_run"] = None
                    info["cron"] = sched["cron_expr"]
            elif sched.get("run_at"):
                info["next_run"] = sched["run_at"]
            else:
                info["next_run"] = None

            # Load durable state for run history
            state = await asyncio.to_thread(schedule_state.load, sid)
            info["last_run_at"] = state.get("last_run_at")
            info["last_status"] = state.get("last_status")
            info["run_count"] = state.get("run_count", 0)

            items.append(info)

        return _ok({"schedules": items, "total": len(items)})
    except Exception as exc:
        return _error(str(exc))


async def schedule_cancel(
    schedule_id: str,
) -> dict[str, Any]:
    """Cancel (disable) a dynamic schedule.

    Args:
        schedule_id: The schedule ID to cancel
    """
    try:
        if not schedule_id or not schedule_id.strip():
            return _error("schedule_id is required")

        schedule_id = schedule_id.strip()

        sched = await asyncio.to_thread(schedule_store.get_schedule, schedule_id)
        if not sched:
            return _error(f"schedule not found: {schedule_id}")

        await asyncio.to_thread(schedule_store.disable_schedule, schedule_id)

        # Also mark in durable state
        state = await asyncio.to_thread(schedule_state.load, schedule_id)
        state["disabled"] = True
        await asyncio.to_thread(schedule_state.save, schedule_id, state)

        return _ok(
            {
                "schedule_id": schedule_id,
                "name": sched["name"],
                "cancelled": True,
            }
        )
    except Exception as exc:
        return _error(str(exc))
