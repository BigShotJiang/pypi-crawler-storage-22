"""
Memory system for Otto.

Uses SQLite FTS5 for full-text search across:
- memory/knowledge.md (core facts)
- memory/projects/*.md (project context)
- sessions/archive/*.json (past conversations)
- active sessions (indexed incrementally per-message)

The memory is one continuous brain - sessions are bookmarks, not walls.
"""

import hashlib
import json
import re
import sqlite3
from datetime import datetime
from pathlib import Path

from .paths import OTTO_HOME

OTTO_DIR = OTTO_HOME
MEMORY_DIR = OTTO_DIR / "memory"
SESSIONS_DIR = OTTO_DIR / "sessions"
ARCHIVE_DIR = SESSIONS_DIR / "archive"
DB_PATH = OTTO_DIR / "memory.sqlite"

# Chunk size for indexing (in characters)
CHUNK_SIZE = 1500
CHUNK_OVERLAP = 200


def _get_db() -> sqlite3.Connection:
    """Get database connection, creating schema if needed."""
    OTTO_DIR.mkdir(parents=True, exist_ok=True)

    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row

    # Create FTS5 virtual table if not exists
    db.executescript("""
        CREATE TABLE IF NOT EXISTS memory_chunks (
            id INTEGER PRIMARY KEY,
            source_type TEXT NOT NULL,  -- 'knowledge', 'project', 'session'
            source_path TEXT NOT NULL,  -- file path
            source_id TEXT,             -- session id or project name
            chunk_index INTEGER,        -- position in source
            content TEXT NOT NULL,
            content_hash TEXT NOT NULL,
            indexed_at TEXT NOT NULL,
            metadata TEXT               -- JSON metadata
        );

        CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
            content,
            source_type,
            source_id,
            content='memory_chunks',
            content_rowid='id'
        );

        -- Triggers to keep FTS in sync
        CREATE TRIGGER IF NOT EXISTS memory_ai AFTER INSERT ON memory_chunks BEGIN
            INSERT INTO memory_fts(rowid, content, source_type, source_id)
            VALUES (new.id, new.content, new.source_type, new.source_id);
        END;

        CREATE TRIGGER IF NOT EXISTS memory_ad AFTER DELETE ON memory_chunks BEGIN
            INSERT INTO memory_fts(memory_fts, rowid, content, source_type, source_id)
            VALUES ('delete', old.id, old.content, old.source_type, old.source_id);
        END;

        CREATE TRIGGER IF NOT EXISTS memory_au AFTER UPDATE ON memory_chunks BEGIN
            INSERT INTO memory_fts(memory_fts, rowid, content, source_type, source_id)
            VALUES ('delete', old.id, old.content, old.source_type, old.source_id);
            INSERT INTO memory_fts(rowid, content, source_type, source_id)
            VALUES (new.id, new.content, new.source_type, new.source_id);
        END;

        -- Index for efficient lookups
        CREATE INDEX IF NOT EXISTS idx_chunks_source ON memory_chunks(source_path);
        CREATE INDEX IF NOT EXISTS idx_chunks_hash ON memory_chunks(content_hash);
    """)

    return db


def _snap_to_boundary(text: str, pos: int) -> int:
    """Advance pos to the nearest sentence/paragraph boundary in text.

    Searches forward up to 300 chars for a clean break point so chunks
    don't start mid-word or mid-sentence.
    """
    if pos <= 0 or pos >= len(text):
        return pos

    search_end = min(pos + 300, len(text))
    # Prefer paragraph break
    para = text.find("\n\n", pos, search_end)
    if para != -1:
        return para + 2
    # Then sentence break
    for delim in (". ", ".\n", "? ", "! ", "?\n", "!\n"):
        sb = text.find(delim, pos, search_end)
        if sb != -1:
            return sb + len(delim)
    # Then any newline
    nl = text.find("\n", pos, search_end)
    if nl != -1:
        return nl + 1
    return pos


def _chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """Split text into overlapping chunks with clean boundaries."""
    if len(text) <= chunk_size:
        return [text]

    chunks = []
    start = 0

    while start < len(text):
        end = start + chunk_size

        # Try to break at paragraph or sentence boundary (end of chunk)
        if end < len(text):
            # Look for paragraph break
            para_break = text.rfind("\n\n", start, end)
            if para_break > start + chunk_size // 2:
                end = para_break + 2
            else:
                # Look for sentence break
                sentence_break = max(
                    text.rfind(". ", start, end),
                    text.rfind(".\n", start, end),
                    text.rfind("? ", start, end),
                    text.rfind("! ", start, end),
                )
                if sentence_break > start + chunk_size // 2:
                    end = sentence_break + 2

        chunks.append(text[start:end].strip())

        # Next chunk start: back up by overlap, then snap forward to boundary
        next_start = end - overlap
        if next_start > start:
            next_start = _snap_to_boundary(text, next_start)
        start = max(next_start, end - overlap) if next_start <= start else next_start

    return [c for c in chunks if c]  # Filter empty chunks


def _content_hash(content: str) -> str:
    """Generate hash of content for change detection."""
    return hashlib.md5(content.encode()).hexdigest()


def index_file(
    path: Path, source_type: str, source_id: str | None = None, force: bool = False
) -> int:
    """
    Index a file into the memory database.

    Args:
        path: Path to file
        source_type: 'knowledge', 'project', or 'session'
        source_id: Identifier (project name, session id)
        force: Re-index even if unchanged

    Returns:
        Number of chunks indexed
    """
    if not path.exists():
        return 0

    source_path = str(path)

    # Read content
    if path.suffix == ".json":
        # Session file - extract conversation
        try:
            data = json.loads(path.read_text())
            messages = data.get("messages", [])
            topic = data.get("topic", "")

            # Format conversation for indexing
            lines = [f"Session: {topic}"] if topic else []
            for msg in messages:
                role = msg.get("role", "")
                content = msg.get("content", "")
                lines.append(f"{role}: {content}")

            content = "\n".join(lines)
            source_id = source_id or data.get("id", path.stem)
        except json.JSONDecodeError:
            return 0
    elif path.suffix == ".jsonl":
        # Overflow file - JSONL format, one message per line
        try:
            messages = []
            with open(path, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            messages.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue

            lines = []
            for msg in messages:
                role = msg.get("role", "")
                content = msg.get("content", "")
                lines.append(f"{role}: {content}")

            content = "\n".join(lines)
            # Derive source_id from filename: "412407481.overflow.jsonl" -> "412407481"
            source_id = source_id or path.stem.split(".")[0]
        except OSError:
            return 0
    else:
        content = path.read_text()
        source_id = source_id or path.stem

    if not content.strip():
        return 0

    db = _get_db()
    try:
        content_hash = _content_hash(content)

        # Check if already indexed with same hash
        if not force:
            existing = db.execute(
                "SELECT content_hash FROM memory_chunks WHERE source_path = ? LIMIT 1",
                (source_path,),
            ).fetchone()

            if existing and existing["content_hash"] == content_hash:
                return 0  # Already up to date

        # Remove old chunks for this file
        db.execute("DELETE FROM memory_chunks WHERE source_path = ?", (source_path,))

        # Chunk and index
        chunks = _chunk_text(content)
        now = datetime.now().isoformat()

        for i, chunk in enumerate(chunks):
            db.execute(
                """
                INSERT INTO memory_chunks
                (source_type, source_path, source_id, chunk_index, content, content_hash, indexed_at, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    source_type,
                    source_path,
                    source_id,
                    i,
                    chunk,
                    content_hash,
                    now,
                    json.dumps({"total_chunks": len(chunks)}),
                ),
            )

        db.commit()
    finally:
        db.close()

    return len(chunks)


def index_message(
    role: str,
    content: str,
    session_id: str | None = None,
    chat_id: str | None = None,
    timestamp: str | None = None,
) -> bool:
    """
    Index a single message into the FTS database immediately.

    Lightweight path for real-time indexing — no chunking, no file I/O.
    Called from add_message() so the active session is always searchable.

    Args:
        role: 'user' or 'assistant'
        content: Message text
        session_id: Session ID for grouping
        chat_id: Chat ID for source path
        timestamp: Message timestamp

    Returns:
        True if indexed successfully
    """
    content = (content or "").strip()
    if not content or len(content) < 10:
        return False  # Skip trivial messages

    # Skip ephemeral/system noise
    if role not in ("user", "assistant"):
        return False

    source_id = session_id or "active"
    source_path = f"session:live:{chat_id or '_default'}"
    ts = timestamp or datetime.now().isoformat()

    # Prefix with role for searchability
    indexed_content = f"{role}: {content}"

    # For long messages, chunk them; for short ones, index directly
    if len(indexed_content) > CHUNK_SIZE:
        chunks = _chunk_text(indexed_content)
    else:
        chunks = [indexed_content]

    try:
        db = _get_db()
        now = datetime.now().isoformat()
        content_hash = _content_hash(indexed_content)

        for i, chunk in enumerate(chunks):
            db.execute(
                """
                INSERT INTO memory_chunks
                (source_type, source_path, source_id, chunk_index, content, content_hash, indexed_at, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "session",
                    source_path,
                    source_id,
                    i,
                    chunk,
                    content_hash,
                    now,
                    json.dumps({"ts": ts, "role": role, "live": True}),
                ),
            )

        db.commit()
        db.close()
        return True
    except Exception:
        # Non-fatal — don't break message flow for indexing failures
        return False


def cleanup_live_index(chat_id: str | None = None) -> int:
    """
    Remove live-indexed messages for a chat (e.g. after archiving).

    When a session is archived and re-indexed as a file, the live entries
    become redundant. Call this after index_file() on the archived session.

    Returns:
        Number of rows deleted
    """
    source_path = f"session:live:{chat_id or '_default'}"
    try:
        db = _get_db()
        cursor = db.execute("DELETE FROM memory_chunks WHERE source_path = ?", (source_path,))
        deleted = cursor.rowcount
        db.commit()
        db.close()
        return deleted
    except Exception:
        return 0


def index_all(force: bool = False) -> dict:
    """
    Index all memory sources.

    Returns:
        Dict with counts: {knowledge, projects, sessions, total}
    """
    counts = {"knowledge": 0, "projects": 0, "sessions": 0, "total": 0}

    # Index knowledge.md
    knowledge_file = MEMORY_DIR / "knowledge.md"
    if knowledge_file.exists():
        counts["knowledge"] = index_file(knowledge_file, "knowledge", "core", force=force)

    # Index project files
    projects_dir = MEMORY_DIR / "projects"
    if projects_dir.exists():
        for project_file in projects_dir.glob("*.md"):
            n = index_file(project_file, "project", project_file.stem, force=force)
            counts["projects"] += n

    # Index archived sessions
    if ARCHIVE_DIR.exists():
        for session_file in ARCHIVE_DIR.glob("*.json"):
            n = index_file(session_file, "session", force=force)
            counts["sessions"] += n

    # Index active sessions (ensures current conversations are searchable on startup)
    active_dir = SESSIONS_DIR / "active"
    if active_dir.exists():
        for session_file in active_dir.glob("*.json"):
            n = index_file(session_file, "session", force=force)
            counts["sessions"] += n
        # Also index overflow files (older messages rotated out of session JSON)
        for overflow_file in active_dir.glob("*.overflow.jsonl"):
            n = index_file(overflow_file, "session", force=force)
            counts["sessions"] += n

    # Cleanup: remove orphaned index entries for deleted source files
    try:
        db = _get_db()
        rows = db.execute(
            "SELECT DISTINCT source_path FROM memory_chunks WHERE source_path NOT LIKE 'session:live:%'"
        ).fetchall()
        for row in rows:
            if not Path(row["source_path"]).exists():
                db.execute("DELETE FROM memory_chunks WHERE source_path = ?", (row["source_path"],))
        db.commit()
        db.close()
    except Exception:
        pass  # Non-fatal cleanup

    counts["total"] = counts["knowledge"] + counts["projects"] + counts["sessions"]
    return counts


def search(query: str, limit: int = 5, source_types: list[str] | None = None) -> list[dict]:
    """
    Search memory for relevant content.

    Args:
        query: Search query
        limit: Max results
        source_types: Filter by type ('knowledge', 'project', 'session')

    Returns:
        List of results with content, source info, and relevance score
    """
    db = _get_db()

    # Build FTS query
    # Escape special characters and add prefix matching
    safe_query = re.sub(r"[^\w\s]", " ", query)
    terms = safe_query.split()
    fts_query = " OR ".join(f'"{term}"*' for term in terms if term)

    if not fts_query:
        db.close()
        return []

    # Build SQL
    sql = """
        SELECT
            c.id,
            c.source_type,
            c.source_path,
            c.source_id,
            c.content,
            c.chunk_index,
            c.metadata,
            bm25(memory_fts) as score
        FROM memory_fts f
        JOIN memory_chunks c ON f.rowid = c.id
        WHERE memory_fts MATCH ?
    """

    params = [fts_query]

    if source_types:
        placeholders = ",".join("?" * len(source_types))
        sql += f" AND c.source_type IN ({placeholders})"
        params.extend(source_types)

    sql += " ORDER BY score LIMIT ?"
    params.append(limit)

    try:
        rows = db.execute(sql, params).fetchall()
    except sqlite3.OperationalError:
        # FTS query syntax error - try simpler query
        simple_query = " ".join(f'"{term}"' for term in terms if term)
        try:
            params[0] = simple_query
            rows = db.execute(sql, params).fetchall()
        except sqlite3.OperationalError:
            db.close()
            return []

    results = []
    for row in rows:
        results.append(
            {
                "content": row["content"],
                "source_type": row["source_type"],
                "source_id": row["source_id"],
                "source_path": row["source_path"],
                "chunk_index": row["chunk_index"],
                "score": row["score"],
                "metadata": json.loads(row["metadata"]) if row["metadata"] else {},
            }
        )

    db.close()
    return results


def _smart_truncate(text: str, max_length: int = 1500) -> str:
    """
    Truncate text at a natural boundary (sentence or word).

    Finds the last complete sentence within the limit, or falls back
    to the last word boundary if no sentence break exists.
    """
    if len(text) <= max_length:
        return text

    # Look for sentence boundaries within limit
    truncated = text[:max_length]

    # Try to find last complete sentence (. ! ? followed by space or end)
    sentence_end = -1
    for pattern in (". ", ".\n", "? ", "?\n", "! ", "!\n"):
        pos = truncated.rfind(pattern)
        if pos > sentence_end and pos > max_length // 2:
            sentence_end = pos + 1  # Include the punctuation

    if sentence_end > 0:
        return text[:sentence_end].rstrip()

    # Fall back to word boundary
    last_space = truncated.rfind(" ")
    if last_space > max_length // 2:
        return text[:last_space].rstrip() + "..."

    # No good break point - just truncate
    return truncated.rstrip() + "..."


def _is_redundant(chunk_text: str, reference_text: str, threshold: float = 0.7) -> bool:
    """
    Check if a memory chunk is substantially present in the reference text.

    Uses line-level overlap: if >= threshold of the chunk's lines appear
    in the reference, it's considered redundant.
    """
    if not chunk_text or not reference_text:
        return False

    # Split chunk into meaningful lines (skip very short ones)
    chunk_lines = [ln.strip() for ln in chunk_text.splitlines() if len(ln.strip()) > 20]
    if not chunk_lines:
        return False

    # Check how many chunk lines appear in the reference
    matches = sum(1 for ln in chunk_lines if ln in reference_text)
    overlap = matches / len(chunk_lines)
    return overlap >= threshold


def search_formatted(query: str, limit: int = 5, exclude_context: str = "") -> str:
    """
    Search memory and return formatted results for prompt injection.

    Groups chunks from the same source together chronologically,
    uses smart truncation, and deduplicates against existing context
    (e.g. recent_conversation) to avoid wasting tokens on redundant content.

    Args:
        query: Search query
        limit: Max results
        exclude_context: Text already present in prompt (e.g. recent_conversation).
            Chunks substantially overlapping this text are filtered out.

    Returns:
        Formatted string with tagged results
    """
    results = search(query, limit)

    if not results:
        return ""

    # Group results by source_id to merge related chunks
    grouped: dict[str, list[dict]] = {}
    for r in results:
        key = f"{r['source_type']}/{r['source_id']}"
        if key not in grouped:
            grouped[key] = []
        grouped[key].append(r)

    lines = ["Recalled from memory:"]
    has_content = False

    for source_label, chunks in grouped.items():
        # Sort chunks by chunk_index for chronological order
        chunks.sort(key=lambda c: c.get("chunk_index", 0))

        # Merge content from related chunks
        merged_content = "\n".join(c["content"] for c in chunks)

        # Skip if this chunk is already in the recent conversation
        if exclude_context and _is_redundant(merged_content, exclude_context):
            continue

        # Smart truncate at natural boundary (1500 chars to match chunk size)
        content = _smart_truncate(merged_content, max_length=1500)

        lines.append(f"\n[from: {source_label}]")
        lines.append(content)
        has_content = True

    if not has_content:
        return ""

    return "\n".join(lines)


# Minimum query length to trigger auto-search (short messages are filler)
AUTO_SEARCH_MIN_LENGTH = 20

# Stop words that shouldn't trigger memory search on their own
_STOP_PHRASES = frozenset(
    {
        "yes",
        "no",
        "ok",
        "okay",
        "sure",
        "thanks",
        "thank you",
        "ty",
        "hi",
        "hello",
        "hey",
        "yo",
        "sup",
        "lol",
        "lmao",
        "haha",
        "hmm",
        "hm",
        "ah",
        "oh",
        "uh",
        "um",
        "idk",
        "do it",
        "go ahead",
        "sounds good",
        "got it",
        "cool",
        "nice",
        "please",
        "pls",
        "nah",
        "nope",
        "yep",
        "yeah",
        "yea",
    }
)


def should_auto_search(query: str) -> bool:
    """
    Determine if a query is worth searching memory for.

    Filters out trivial messages (filler, acknowledgements, emoji-only)
    that would only return noise from FTS.

    Returns:
        True if the query is substantive enough to search
    """
    clean = query.strip()

    # Too short
    if len(clean) < AUTO_SEARCH_MIN_LENGTH:
        # Allow short queries if they contain real content words
        normalized = re.sub(r"[^\w\s]", "", clean).lower().strip()
        if normalized in _STOP_PHRASES:
            return False
        # Check multi-word stop phrases (e.g. "ok do it")
        if any(
            normalized.startswith(p) or normalized.endswith(p)
            for p in _STOP_PHRASES
            if len(p) > 2 and p in normalized
        ):
            return False
        # Very short and no meaningful words
        words = normalized.split()
        if len(words) <= 3 and all(len(w) <= 4 for w in words):
            return False

    # Emoji-only or punctuation-only
    text_chars = re.sub(r"[\s\U00010000-\U0010FFFF\u2600-\u27BF\u2300-\u23FF!?.,:;]", "", clean)
    if not text_chars:
        return False

    return True


def search_gated(query: str, limit: int = 5, exclude_context: str = "") -> str:
    """
    Gated memory search — only searches if the query is substantive.

    Use this for auto-search on every turn. Returns empty string for
    trivial messages instead of injecting noise.

    Args:
        query: User message text
        limit: Max results
        exclude_context: Text already in prompt to deduplicate against

    Returns:
        Formatted string with tagged results, or "" if gated out
    """
    if not should_auto_search(query):
        return ""
    return search_formatted(query, limit=limit, exclude_context=exclude_context)


def get_stats() -> dict:
    """Get memory index statistics."""
    db = _get_db()

    stats = {"total_chunks": 0, "by_type": {}, "sources": []}

    # Total chunks
    row = db.execute("SELECT COUNT(*) as count FROM memory_chunks").fetchone()
    stats["total_chunks"] = row["count"]

    # By type
    for row in db.execute(
        "SELECT source_type, COUNT(*) as count FROM memory_chunks GROUP BY source_type"
    ):
        stats["by_type"][row["source_type"]] = row["count"]

    # Unique sources
    for row in db.execute(
        "SELECT DISTINCT source_path, source_type, source_id FROM memory_chunks ORDER BY source_type"
    ):
        stats["sources"].append(
            {"path": row["source_path"], "type": row["source_type"], "id": row["source_id"]}
        )

    db.close()
    return stats


def clear_index():
    """Clear all indexed content."""
    db = _get_db()
    db.execute("DELETE FROM memory_chunks")
    db.commit()
    db.close()


def index_otto_docs(force: bool = False) -> int:
    """
    Index Otto's own documentation into memory.

    This enables Otto to answer questions about its own configuration
    and usage without polluting user memory files.

    Returns:
        Number of chunks indexed
    """
    import importlib.resources

    total_chunks = 0

    # Try to find docs in the package or known locations
    doc_sources = []

    # Check for installed package docs
    try:
        # Try to find docs relative to otto package
        otto_pkg = importlib.resources.files("otto")
        pkg_path = Path(str(otto_pkg))
        docs_path = pkg_path.parent / "docs" / "guide"
        if docs_path.exists():
            doc_sources.append(docs_path)
    except Exception:
        pass

    # Check common development locations
    for check_path in [
        Path.home() / "Projects" / "core" / "otto" / "docs" / "guide",
        Path.home() / "agent" / "docs" / "guide",
        Path("/home/george/Projects/core/otto/docs/guide"),
    ]:
        if check_path.exists():
            doc_sources.append(check_path)
            break

    # Also index skill reference docs
    skills_path = OTTO_DIR / "skills"
    if skills_path.exists():
        for skill_dir in skills_path.iterdir():
            if skill_dir.is_dir():
                refs_dir = skill_dir / "references"
                if refs_dir.exists():
                    doc_sources.append(refs_dir)

    # Index all found documentation
    for docs_dir in doc_sources:
        for doc_file in docs_dir.glob("*.md"):
            n = index_file(
                doc_file,
                source_type="knowledge",
                source_id=f"otto-docs/{doc_file.stem}",
                force=force,
            )
            total_chunks += n

    return total_chunks
