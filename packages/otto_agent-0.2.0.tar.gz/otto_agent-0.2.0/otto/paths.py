# Codex was here
"""
Filesystem layout and path helpers for the Otto application.

This module centralizes the canonical locations of Otto's configuration, runtime
state, and user-installed extensions. It exposes `pathlib.Path` constants for
directories and files under `OTTO_HOME` (default: `~/.otto`, override via the
`OTTO_HOME` environment variable) and includes small helpers such as
`ensure_dirs()` to create the expected directory structure.

Contract:
- Everything under OTTO_HOME (default ~/.otto) is runtime state, config, and extensions.
- The codebase itself must not assume a checkout path like ~/agent.
"""

from __future__ import annotations

import os
from pathlib import Path


def _expand_dir(value: str | None, default: Path) -> Path:
    if not value:
        return default
    return Path(value).expanduser()


def _resolve_home() -> Path:
    explicit_otto = os.environ.get("OTTO_HOME")
    if explicit_otto:
        return Path(explicit_otto).expanduser()

    return Path.home() / ".otto"


# Root runtime directory
OTTO_HOME: Path = _resolve_home()

# Core config/state
CONFIG_DIR: Path = OTTO_HOME / "config"
ENV_FILE: Path = CONFIG_DIR / ".env"
BOT_STATE_FILE: Path = CONFIG_DIR / "bot_state.json"
BRAINFILE: Path = OTTO_HOME / "brainfile.md"

# Runtime data
LOGS_DIR: Path = OTTO_HOME / "logs"
DATA_DIR: Path = OTTO_HOME / "data"
PHOTOS_DIR: Path = OTTO_HOME / "photos"
OUTPUTS_DIR: Path = OTTO_HOME / "outputs"
PIDS_DIR: Path = OTTO_HOME / "pids"
RUN_DIR: Path = OTTO_HOME / "run"  # Transient runtime files (ready markers, restart notifications)

# Feature directories
MEMORY_DIR: Path = OTTO_HOME / "memory"
SESSIONS_DIR: Path = OTTO_HOME / "sessions"
SCHEDULES_DIR: Path = OTTO_HOME / "schedules"
SKILLS_DIR: Path = OTTO_HOME / "skills"
POLICIES_DIR: Path = OTTO_HOME / "policies"
HEARTBEAT_DIR: Path = OTTO_HOME / "heartbeat"


def ensure_dirs() -> None:
    """Create Otto runtime directories if missing."""
    for d in (
        OTTO_HOME,
        CONFIG_DIR,
        LOGS_DIR,
        DATA_DIR,
        PHOTOS_DIR,
        OUTPUTS_DIR,
        PIDS_DIR,
        RUN_DIR,
        MEMORY_DIR,
        SESSIONS_DIR,
        SCHEDULES_DIR,
        SKILLS_DIR,
        POLICIES_DIR,
        HEARTBEAT_DIR,
    ):
        d.mkdir(parents=True, exist_ok=True)

    # Soft-patch bundled skills (non-destructive)
    patch_skills()


def patch_skills() -> None:
    """
    Soft-patch bundled skills into ~/.otto/skills.

    This is non-destructive:
    - Only copies skills that don't exist in user's skills dir
    - Never overwrites user customizations
    - Runs automatically on every startup via ensure_dirs()

    New skills shipped with Otto updates are automatically available
    without breaking existing user configurations.
    """
    import shutil

    # Find bundled skills in package
    try:
        import otto_tools.bundled_skills as bundled

        bundled_dir = Path(bundled.__file__).parent
    except (ImportError, AttributeError):
        return  # No bundled skills module

    if not bundled_dir.exists():
        return

    # Iterate bundled skills
    for skill_src in bundled_dir.iterdir():
        if not skill_src.is_dir() or skill_src.name.startswith(("_", ".")):
            continue

        skill_dst = SKILLS_DIR / skill_src.name

        # Only copy if skill doesn't exist (soft patch)
        if not skill_dst.exists():
            shutil.copytree(skill_src, skill_dst)
        else:
            # Skill exists - check for new reference files only
            src_refs = skill_src / "references"
            dst_refs = skill_dst / "references"

            if src_refs.exists():
                dst_refs.mkdir(exist_ok=True)
                for ref_file in src_refs.iterdir():
                    if ref_file.is_file():
                        dst_file = dst_refs / ref_file.name
                        # Only copy new reference files, don't overwrite
                        if not dst_file.exists():
                            shutil.copy2(ref_file, dst_file)


def get_workdir() -> Path:
    """Get the working directory for backend execution."""
    value = os.environ.get("OTTO_WORKDIR")
    if value:
        return Path(value).expanduser()
    return Path.cwd()


def build_agent_system_prompt() -> str:
    """
    Backward-compatible proxy for ``otto.prompts.build_agent_system_prompt``.

    Import lazily to avoid an import cycle when ``otto.prompts`` imports
    ``otto.paths`` for ``BRAINFILE``.
    """
    from otto.prompts import build_agent_system_prompt as _build

    return _build()
