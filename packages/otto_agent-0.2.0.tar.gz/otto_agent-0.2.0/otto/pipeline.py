"""
Pipeline Runner - Execute multi-step skill pipelines via the job queue.

Pipelines are YAML-defined multi-step workflows that leverage the job queue's
dependency system (depends_on_id) to chain agent executions.

Example pipeline.yaml:
    name: code-write
    description: Write and review code
    steps:
      - id: write
        backend: opus
        prompt: Write the implementation for: {task}

      - id: review
        backend: litellm
        depends_on: write
        prompt: Review the code from the previous step
"""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from otto.jobs.queue import JobQueue
from otto.paths import OUTPUTS_DIR, SKILLS_DIR
from otto.prompts import build_agent_system_prompt


@dataclass
class PipelineStep:
    """A single step in a pipeline."""

    id: str
    prompt: str
    backend: str = "pi"
    model: str | None = None  # For dynamic routing (e.g., "openrouter/provider/model")
    depends_on: str | None = None
    timeout: int | None = None
    notify: bool = False


@dataclass
class Pipeline:
    """A multi-step pipeline definition."""

    name: str
    description: str
    steps: list[PipelineStep] = field(default_factory=list)
    default_backend: str = "pi"
    default_model: str | None = None  # For dynamic routing (e.g., "openrouter/provider/model")
    default_timeout: int = 3600
    skill_path: Path | None = None

    def validate(self) -> list[str]:
        """Validate pipeline definition. Returns list of errors."""
        errors = []

        if not self.name:
            errors.append("Pipeline must have a name")

        if not self.steps:
            errors.append("Pipeline must have at least one step")
            return errors

        step_ids = set()
        for step in self.steps:
            if not step.id:
                errors.append("Each step must have an id")
            elif step.id in step_ids:
                errors.append(f"Duplicate step id: {step.id}")
            else:
                step_ids.add(step.id)

            if not step.prompt:
                errors.append(f"Step '{step.id}' must have a prompt")

            if step.depends_on and step.depends_on not in step_ids:
                # Note: depends_on must reference an earlier step
                errors.append(f"Step '{step.id}' depends on unknown step '{step.depends_on}'")

        return errors


def load_pipeline(skill_path: Path) -> Pipeline | None:
    """
    Load a pipeline from a skill directory.

    Looks for pipeline.yaml in the skill directory.

    Args:
        skill_path: Path to skill directory

    Returns:
        Pipeline object or None if no pipeline.yaml exists
    """
    pipeline_file = skill_path / "pipeline.yaml"
    if not pipeline_file.exists():
        return None

    content = pipeline_file.read_text()
    data = yaml.safe_load(content)

    if not data:
        return None

    # Parse steps
    default_backend = data.get("default_backend", "pi")
    default_model = data.get("default_model")  # e.g., "openrouter/provider/model"

    steps = []
    for step_data in data.get("steps", []):
        steps.append(
            PipelineStep(
                id=step_data.get("id", ""),
                prompt=step_data.get("prompt", ""),
                backend=step_data.get("backend", default_backend),
                model=step_data.get("model", default_model),
                depends_on=step_data.get("depends_on"),
                timeout=step_data.get("timeout"),
                notify=step_data.get("notify", False),
            )
        )

    return Pipeline(
        name=data.get("name", skill_path.name),
        description=data.get("description", ""),
        steps=steps,
        default_backend=default_backend,
        default_model=default_model,
        default_timeout=data.get("default_timeout", 3600),
        skill_path=skill_path,
    )


def discover_pipelines() -> list[Pipeline]:
    """Discover all pipelines in the skills directory."""
    pipelines = []

    if not SKILLS_DIR.exists():
        return pipelines

    for entry in SKILLS_DIR.iterdir():
        if not entry.is_dir():
            continue

        pipeline = load_pipeline(entry)
        if pipeline:
            pipelines.append(pipeline)

    return pipelines


def get_pipeline(name: str) -> Pipeline | None:
    """Get a pipeline by name."""
    skill_path = SKILLS_DIR / name
    if skill_path.exists():
        return load_pipeline(skill_path)
    return None


@dataclass
class PipelineRun:
    """Represents a running pipeline instance."""

    pipeline_id: str
    pipeline_name: str
    root_agent_id: str
    step_agents: dict[str, str]  # step_id -> agent_id
    variables: dict[str, str]


def run_pipeline(
    pipeline: Pipeline,
    variables: dict[str, str] | None = None,
    notify_on_complete: bool = True,
    priority: str = "normal",
) -> PipelineRun:
    """
    Run a pipeline by enqueuing jobs with dependencies.

    Each step becomes an agent job. Dependencies are expressed via
    depends_on_id in the job queue.

    Args:
        pipeline: The pipeline to run
        variables: Variables to substitute in prompts (e.g., {task})
        notify_on_complete: Send notification when pipeline completes
        priority: Priority level (high/normal/low)

    Returns:
        PipelineRun with agent IDs for each step
    """
    from otto.backends import get_orchestration_config

    queue = JobQueue()
    variables = variables or {}

    # Generate pipeline run ID
    pipeline_id = uuid.uuid4().hex[:8]

    # Inject pipeline_id as a variable for prompt substitution
    variables["pipeline_id"] = pipeline_id

    # Build clean, model-agnostic system prompt
    system_prompt = build_agent_system_prompt()

    # Get retry config
    orch_config = get_orchestration_config()
    retry_cfg = orch_config.get("retry", {}) or {}
    max_retries = int(retry_cfg.get("max_retries", 3))
    if max_retries < 0:
        max_retries = 0
    max_attempts = 1 + max_retries

    # Map step_id -> agent_id
    step_agents: dict[str, str] = {}

    # Queue priority mapping
    queue_priority = {"high": 10, "normal": 0, "low": -10}.get(priority, 0)

    # Process steps in order
    for step in pipeline.steps:
        agent_id = f"{pipeline_id}-{step.id}"
        step_agents[step.id] = agent_id

        # Substitute variables in prompt
        prompt = step.prompt
        for key, value in variables.items():
            prompt = prompt.replace(f"{{{key}}}", value)

        # Add pipeline context to prompt
        prompt_parts = [
            f"Pipeline: {pipeline.name}",
            f"Step: {step.id}",
            "",
            prompt,
        ]

        # Determine dependency
        depends_on_id: str | None = None
        depends_on_status: str | None = None
        if step.depends_on:
            depends_on_id = step_agents.get(step.depends_on)
            depends_on_status = "success"

        # Determine if this step should notify
        # Last step always notifies if notify_on_complete is True
        is_last_step = step == pipeline.steps[-1]
        should_notify = step.notify or (is_last_step and notify_on_complete)

        # Task fingerprint for dedup
        task_desc = f"{pipeline.name}:{step.id}"
        task_fingerprint = hashlib.sha256(task_desc.encode()).hexdigest()[:16]

        # Build payload
        payload = {
            "agent_id": agent_id,
            "prompt": "\n".join(prompt_parts),
            "system": system_prompt,
            "task": f"[{pipeline.name}] {step.id}",
            "task_description": f"Pipeline {pipeline.name}, step {step.id}",
            "backend": step.backend,
            "model": step.model,  # For dynamic routing (e.g., "openrouter/provider/model")
            "timeout": step.timeout or pipeline.default_timeout,
            "notify": should_notify,
            "priority": priority,
            "output_file": str(OUTPUTS_DIR / f"{agent_id}.txt"),
            "task_fingerprint": task_fingerprint,
            # Pipeline metadata
            "_pipeline": {
                "id": pipeline_id,
                "name": pipeline.name,
                "step_id": step.id,
                "step_index": pipeline.steps.index(step),
                "total_steps": len(pipeline.steps),
            },
        }

        # Enqueue the job
        queue.add(
            "agent",
            payload,
            priority=queue_priority,
            max_attempts=max_attempts,
            external_id=agent_id,
            depends_on_id=depends_on_id,
            depends_on_status=depends_on_status,
        )

    # Get the first step's agent_id as root
    root_agent_id = step_agents[pipeline.steps[0].id]

    return PipelineRun(
        pipeline_id=pipeline_id,
        pipeline_name=pipeline.name,
        root_agent_id=root_agent_id,
        step_agents=step_agents,
        variables=variables,
    )


def get_pipeline_status(pipeline_id: str) -> dict | None:
    """
    Get status of a running pipeline.

    Args:
        pipeline_id: The pipeline run ID

    Returns:
        Dict with status info for each step, or None if not found
    """
    queue = JobQueue()

    # Find all jobs with this pipeline_id prefix
    jobs = queue.list(job_type="agent", limit=100)
    pipeline_jobs = []

    for job in jobs:
        external_id = job.get("external_id", "")
        if external_id.startswith(f"{pipeline_id}-"):
            pipeline_jobs.append(job)

    if not pipeline_jobs:
        return None

    # Build status map
    steps = []
    for job in pipeline_jobs:
        payload = job.get("payload", {})
        pipe_meta = payload.get("_pipeline", {})

        steps.append(
            {
                "step_id": pipe_meta.get("step_id"),
                "agent_id": job.get("external_id"),
                "status": job.get("status"),
                "backend": payload.get("backend"),
                "output_file": payload.get("output_file"),
            }
        )

    # Sort by step index
    steps.sort(key=lambda x: x.get("step_id", ""))

    # Determine overall status
    statuses = [s["status"] for s in steps]
    if all(s == "completed" for s in statuses):
        overall = "completed"
    elif any(s == "failed" for s in statuses):
        overall = "failed"
    elif any(s == "running" for s in statuses):
        overall = "running"
    elif any(s == "pending" for s in statuses):
        overall = "pending"
    elif all(s == "waiting" for s in statuses):
        overall = "waiting"
    else:
        overall = "unknown"

    return {
        "pipeline_id": pipeline_id,
        "status": overall,
        "steps": steps,
    }


def cancel_pipeline(pipeline_id: str) -> int:
    """
    Cancel a running pipeline.

    Args:
        pipeline_id: The pipeline run ID

    Returns:
        Number of jobs cancelled
    """
    queue = JobQueue()
    jobs = queue.list(job_type="agent", limit=100)
    cancelled = 0

    for job in jobs:
        external_id = job.get("external_id", "")
        if external_id.startswith(f"{pipeline_id}-"):
            status = job.get("status")
            if status in ("pending", "waiting"):
                queue.cancel(int(job["id"]))
                cancelled += 1

    return cancelled
