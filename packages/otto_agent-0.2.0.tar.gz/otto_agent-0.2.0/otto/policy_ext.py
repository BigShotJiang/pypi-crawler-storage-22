"""
User-Defined Policies as Code (Phase 5, Pillar 3).

Extends the Phase 3 policy engine with:
1. Policy expressions — Python expressions in YAML rules evaluated safely

Architecture:
    The expression engine provides a restricted evaluation sandbox.
    Only whitelisted builtins and a controlled namespace are available:

        when: "args.get('path', '').startswith('/tmp')"
        when: "tool == 'bash' and 'rm' in args.get('command', '')"
        when: "server == 'filesystem' and not path_ok(args.get('path', ''))"

Config schema (settings.yaml):
    gateway:
      policy:
        # Expression rules evaluated in order; first match wins
        rules:
          - when: "tool == 'bash' and 'sudo' in args.get('command', '')"
            action: deny
            reason: "sudo commands are blocked"
          - when: "server == 'filesystem' and args.get('path', '').startswith('/tmp')"
            action: allow
            reason: "/tmp is always allowed"
"""

from __future__ import annotations

import ast
import logging
import re
import signal
import threading
from dataclasses import dataclass, field
from typing import Any

from otto.paths import OTTO_HOME
from otto.policy import PolicyConfig, PolicyEngine, PolicyResult, ToolVerdict

log = logging.getLogger(__name__)

_EXPRESSION_TIMEOUT_SECONDS = 2.0


# ---------------------------------------------------------------------------
# 1. Policy Expressions Engine
# ---------------------------------------------------------------------------

# Safe builtins for expression evaluation
_SAFE_BUILTINS: dict[str, Any] = {
    "True": True,
    "False": False,
    "None": None,
    "len": len,
    "str": str,
    "int": int,
    "float": float,
    "bool": bool,
    "list": list,
    "dict": dict,
    "set": set,
    "tuple": tuple,
    "any": any,
    "all": all,
    "min": min,
    "max": max,
    "abs": abs,
    "sorted": sorted,
    "isinstance": isinstance,
    "hasattr": hasattr,
    "getattr": getattr,
}


class ExpressionError(Exception):
    """Raised when a policy expression is invalid or unsafe."""


def _validate_expression_ast(expr: str) -> None:
    """
    Validate that an expression AST contains only safe operations.

    Blocks:
    - Import statements
    - Function/class definitions
    - Attribute access to dunder methods
    - exec/eval/compile calls
    - __builtins__ access
    """
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as e:
        raise ExpressionError(f"Syntax error in expression: {e}") from e

    _BLOCKED_NAMES = {
        "exec",
        "eval",
        "compile",
        "__import__",
        "open",
        "getattr",
        "setattr",
        "delattr",
        "globals",
        "locals",
        "vars",
        "__builtins__",
        "breakpoint",
        "exit",
        "quit",
        "input",
        "print",
    }
    # Note: getattr is in _SAFE_BUILTINS for controlled use, but we block
    # raw access to the name in expressions as a precaution. The safe version
    # is available via the namespace.

    for node in ast.walk(tree):
        # Block imports
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            raise ExpressionError("Import statements not allowed in expressions")

        # Block function/class definitions
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            raise ExpressionError("Definitions not allowed in expressions")

        # Block dunder attribute access
        if isinstance(node, ast.Attribute):
            if node.attr.startswith("__") and node.attr.endswith("__"):
                raise ExpressionError(f"Dunder attribute access not allowed: {node.attr}")

        # Block dangerous name references
        if isinstance(node, ast.Name):
            if node.id in _BLOCKED_NAMES:
                raise ExpressionError(f"Name '{node.id}' not allowed in expressions")

        # Block starred expressions (prevent unpacking attacks)
        if isinstance(node, ast.Starred):
            raise ExpressionError("Starred expressions not allowed")


def validate_expression(expr: str) -> list[str]:
    """
    Validate a policy expression and return list of errors (empty if valid).

    This is the public validation API — does NOT execute the expression.
    """
    errors: list[str] = []
    try:
        _validate_expression_ast(expr)
    except ExpressionError as e:
        errors.append(str(e))
    except Exception as e:
        errors.append(f"Unexpected error validating expression: {e}")
    return errors


def evaluate_expression(
    expr: str,
    server: str,
    tool: str,
    args: dict[str, Any],
) -> bool:
    """
    Safely evaluate a policy expression in a restricted namespace.

    The expression has access to:
    - server: str — MCP server name
    - tool: str — tool name
    - args: dict — tool arguments
    - re: re module (for pattern matching)
    - path_ok(p): helper that checks path doesn't contain traversal

    Returns the boolean result of the expression.
    Raises ExpressionError on invalid expressions.
    """
    _validate_expression_ast(expr)

    def _path_ok(path: str) -> bool:
        """Check that a path doesn't contain traversal or access sensitive dirs."""
        if not path:
            return False
        blocked = ["..", "~/.ssh", "~/.gnupg", "~/.aws", "/etc/shadow", "/etc/passwd"]
        return not any(b in path for b in blocked)

    namespace: dict[str, Any] = {
        "__builtins__": {},  # Block all builtins
        # Safe builtins
        **_SAFE_BUILTINS,
        # Request context
        "server": server,
        "tool": tool,
        "args": dict(args),  # defensive copy
        # Utility functions
        "re": re,
        "path_ok": _path_ok,
        "match": lambda pattern, string: bool(re.search(pattern, str(string))),
    }

    def _evaluate() -> Any:
        return eval(expr, namespace)  # noqa: S307

    def _run_with_signal_timeout(timeout_seconds: float) -> Any:
        def _timeout_handler(signum: int, frame: Any) -> None:
            raise TimeoutError("expression evaluation timed out")

        old_handler = signal.getsignal(signal.SIGALRM)
        old_timer = signal.setitimer(signal.ITIMER_REAL, 0.0)
        try:
            signal.signal(signal.SIGALRM, _timeout_handler)
            signal.setitimer(signal.ITIMER_REAL, timeout_seconds)
            return _evaluate()
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0.0)
            signal.signal(signal.SIGALRM, old_handler)
            if old_timer != (0.0, 0.0):
                signal.setitimer(signal.ITIMER_REAL, old_timer[0], old_timer[1])

    def _run_with_thread_timeout(timeout_seconds: float) -> Any:
        result: dict[str, Any] = {}
        error: dict[str, BaseException] = {}
        done = threading.Event()

        def _target() -> None:
            try:
                result["value"] = _evaluate()
            except BaseException as e:  # pragma: no cover - best-effort fallback
                error["exc"] = e
            finally:
                done.set()

        worker = threading.Thread(target=_target, daemon=True)
        worker.start()
        if not done.wait(timeout_seconds):
            raise ExpressionError(f"Expression evaluation timed out after {timeout_seconds:.1f}s")
        if "exc" in error:
            raise error["exc"]
        return result.get("value")

    try:
        can_use_signal_timeout = (
            hasattr(signal, "setitimer") and threading.current_thread() is threading.main_thread()
        )
        if can_use_signal_timeout:
            result = _run_with_signal_timeout(_EXPRESSION_TIMEOUT_SECONDS)
        else:
            result = _run_with_thread_timeout(_EXPRESSION_TIMEOUT_SECONDS)
        return bool(result)
    except TimeoutError as e:
        raise ExpressionError(
            f"Expression evaluation timed out after {_EXPRESSION_TIMEOUT_SECONDS:.1f}s"
        ) from e
    except ExpressionError:
        raise
    except Exception as e:
        raise ExpressionError(f"Error evaluating expression '{expr}': {e}") from e


@dataclass
class ExpressionRule:
    """
    A policy rule with a Python expression condition.

    Attributes:
        when: Python expression that evaluates to bool
        action: Verdict to apply when expression is true (allow/deny/ask)
        reason: Human-readable reason for the rule
        priority: Lower number = higher priority (default 100)
    """

    when: str
    action: str  # "allow", "deny", "ask"
    reason: str = ""
    priority: int = 100

    def __post_init__(self) -> None:
        if self.action not in {"allow", "deny", "ask"}:
            raise ValueError(f"Invalid action '{self.action}', must be allow/deny/ask")

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> ExpressionRule:
        """Parse from YAML config."""
        return cls(
            when=str(config.get("when", "False")),
            action=str(config.get("action", "deny")).lower(),
            reason=str(config.get("reason", "")),
            priority=int(config.get("priority", 100)),
        )

    def matches(self, server: str, tool: str, args: dict[str, Any]) -> bool:
        """Evaluate the expression against a request. Returns True if rule matches."""
        try:
            return evaluate_expression(self.when, server, tool, args)
        except ExpressionError as e:
            log.warning("Expression rule error: %s — skipping rule", e)
            return False


@dataclass
class ExpressionEngine:
    """
    Evaluates a list of expression rules against tool requests.

    Rules are evaluated in priority order (lower = higher priority).
    First matching rule wins. If no rule matches, returns None
    (fallback to standard policy engine).
    """

    rules: list[ExpressionRule] = field(default_factory=list)

    @classmethod
    def from_config(cls, config: list[dict[str, Any]] | None) -> ExpressionEngine:
        """Parse from the gateway.policy.rules section of settings.yaml."""
        if not config:
            return cls()
        rules = []
        for rule_conf in config:
            if isinstance(rule_conf, dict):
                try:
                    rules.append(ExpressionRule.from_config(rule_conf))
                except (ValueError, ExpressionError) as e:
                    log.warning("Skipping invalid expression rule: %s", e)
        # Sort by priority (lower = higher priority)
        rules.sort(key=lambda r: r.priority)
        return cls(rules=rules)

    def evaluate(self, server: str, tool: str, args: dict[str, Any]) -> tuple[str, str] | None:
        """
        Evaluate rules against a request.

        Returns (action, reason) for the first matching rule, or None if
        no rule matches.
        """
        for rule in self.rules:
            if rule.matches(server, tool, args):
                return rule.action, rule.reason or f"Matched rule: {rule.when}"
        return None


# ---------------------------------------------------------------------------
# Integration: Extended PolicyEngine that includes expressions
# ---------------------------------------------------------------------------


class ExtendedPolicyEngine:
    """
    Full policy evaluation pipeline combining:
    1. Expression rules
    2. Standard PolicyEngine cascade

    This is the recommended entry point for runtime policy evaluation.
    """

    def __init__(
        self,
        policy_config: dict[str, Any] | None = None,
        plugin_dir: Any = None,  # kept for compatibility but unused
    ):
        self._raw_config = policy_config or {}

        # Expression engine from 'rules' section
        self._expr_engine = ExpressionEngine.from_config(self._raw_config.get("rules"))

        # Standard engine (strip 'rules')
        engine_config = {
            k: v for k, v in self._raw_config.items() if k not in {"rules", "plugins", "packs"}
        }
        self._policy_config = PolicyConfig.from_config(engine_config)
        self._engine = PolicyEngine(self._policy_config)

    @property
    def expression_engine(self) -> ExpressionEngine:
        return self._expr_engine

    @property
    def policy_engine(self) -> PolicyEngine:
        return self._engine

    def evaluate(
        self,
        server: str,
        tool: str,
        arguments: dict[str, Any] | None = None,
    ) -> PolicyResult:
        """
        Full evaluation pipeline.

        Returns a PolicyResult (from otto.policy).
        Expression overrides are converted to PolicyResult.
        """
        arguments = arguments or {}
        verdict_map = {
            "allow": ToolVerdict.ALLOW,
            "deny": ToolVerdict.DENY,
            "ask": ToolVerdict.ASK,
        }

        # 1. Expression rules (first match wins)
        expr_result = self._expr_engine.evaluate(server, tool, arguments)
        if expr_result:
            action, reason = expr_result
            return PolicyResult(
                verdict=verdict_map.get(action, ToolVerdict.DENY),
                reason=f"[expression] {reason}",
            )

        # 2. Standard policy engine
        return self._engine.evaluate(server, tool, arguments)


__all__ = [
    "ExpressionError",
    "ExpressionRule",
    "ExpressionEngine",
    "ExtendedPolicyEngine",
    "evaluate_expression",
    "validate_expression",
]
