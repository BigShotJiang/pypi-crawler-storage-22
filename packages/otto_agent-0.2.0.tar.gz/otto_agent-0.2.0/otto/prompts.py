"""
Prompt construction for Otto agents.

This module builds model-agnostic system prompts from the brainfile,
extracting persona/context/rules while excluding internal configurations.
"""

from __future__ import annotations

from otto.paths import BRAINFILE

_DEFAULT_AGENT_PROMPT = "You are a helpful assistant completing a task."


def build_agent_system_prompt() -> str:
    """
    Build a clean, model-agnostic system prompt for agents.

    Extracts only persona/context/rules from brainfile, excluding:
    - Internal backend configurations
    - Orchestration settings
    - Job queue state
    - Any mention of specific AI systems (Claude, etc.)

    This ensures the prompt works correctly when routing to
    non-Anthropic models via Ollama, OpenRouter, etc.
    """
    import yaml

    if not BRAINFILE.exists():
        return _DEFAULT_AGENT_PROMPT

    content = BRAINFILE.read_text()

    # Parse YAML frontmatter if present
    if not content.startswith("---"):
        # No frontmatter, use content directly
        return content

    end = content.find("\n---", 3)
    if end == -1:
        return _DEFAULT_AGENT_PROMPT

    try:
        data = yaml.safe_load(content[4:end]) or {}
    except yaml.YAMLError:
        return _DEFAULT_AGENT_PROMPT

    # Extract only relevant sections
    persona = data.get("persona", {})
    context = data.get("context", {})
    rules = data.get("rules", {})

    # Build clean prompt
    parts = []

    # Identity (without mentioning specific AI systems)
    identity = persona.get("identity", "")
    if identity:
        parts.append(identity)
    elif persona.get("name"):
        parts.append(f"You are {persona['name']}.")

    # Role and style
    if persona.get("role"):
        parts.append(f"Role: {persona['role']}")
    if persona.get("style"):
        parts.append(f"Style: {persona['style']}")

    # Values
    values = persona.get("values", [])
    if values:
        parts.append(f"Values: {', '.join(values)}")

    # User context (if any)
    user_ctx = context.get("user", {})
    if user_ctx and isinstance(user_ctx, dict):
        user_lines = [f"  {k}: {v}" for k, v in user_ctx.items() if v]
        if user_lines:
            parts.append("User context:")
            parts.extend(user_lines)

    # Preferences
    prefs = context.get("preferences", [])
    if prefs:
        parts.append("Preferences:")
        for p in prefs:
            parts.append(f"  - {p}")

    # Rules/governance
    if rules.get("governance"):
        parts.append(f"Rules: {rules['governance']}")
    if rules.get("output_handling"):
        parts.append(f"Output: {rules['output_handling']}")
    if rules.get("capabilities"):
        parts.append(f"Capabilities: {rules['capabilities']}")

    # Get markdown content after frontmatter (skip internal tool docs)
    markdown_content = content[end + 4 :].strip()
    # Only include markdown if it's not just default tool documentation
    if markdown_content and "# Otto Brainfile" not in markdown_content:
        parts.append("")
        parts.append(markdown_content)

    if not parts:
        return _DEFAULT_AGENT_PROMPT

    return "\n".join(parts)
