"""
Scheduler tick for Otto.

Scheduling model:
- Job definitions live in ~/.otto/brainfile.md (config source of truth)
- Durable schedule metadata lives in SQLite (see `otto.schedule_state`)
- Runnable work is enqueued to SQLite (see `otto.jobs.queue`)

Run:
  otto job schedule tick
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable

import yaml

from otto import schedule_store
from otto.jobs.queue import JobQueue
from otto.notify import send as send_notification
from otto.paths import BRAINFILE, OUTPUTS_DIR, SCHEDULES_DIR, ensure_dirs
from otto.prompts import build_agent_system_prompt
from otto.schedule_state import load as load_state
from otto.schedule_state import mark_enqueued
from otto.schedule_state import save as save_state
from otto.services.supervisor import supervise

_NOTIFY_MODES = {"always", "on_error", "on_action", "never"}


def _normalize_notify_mode(value: object) -> str:
    """Normalize job notify config to a supported mode."""
    if value is None:
        return "on_error"
    if isinstance(value, bool):
        return "always" if value else "never"
    mode = str(value).strip().lower()
    if mode in ("true", "yes", "1"):
        return "always"
    if mode in ("false", "no", "0"):
        return "never"
    return mode if mode in _NOTIFY_MODES else "on_error"


def _acquire_lock(lock_path: Path):
    """Cross-process lock to keep `tick` single-instance."""
    import fcntl

    lock_path.parent.mkdir(parents=True, exist_ok=True)
    fd = open(lock_path, "w")
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        fd.close()
        return None
    return fd


def _parse_brainfile_jobs() -> list[dict]:
    if not BRAINFILE.exists():
        return []

    content = BRAINFILE.read_text()
    if not content.startswith("---"):
        return []

    end = content.find("\n---", 3)
    if end == -1:
        return []

    data = yaml.safe_load(content[4:end]) or {}
    jobs = data.get("jobs", [])
    return jobs if isinstance(jobs, list) else []


_DAILY_SUMMARY_ID = "__observability_daily__"
_WEEKLY_SUMMARY_ID = "__observability_weekly__"


def _check_observability_summaries(now: datetime, *, dry_run: bool = False) -> dict:
    """
    Check and send daily/weekly MCP activity summaries.

    Uses schedule_state to track when last summary was sent.
    Configurable in settings.yaml:
        gateway:
          observability:
            daily_summary: true
            daily_summary_hour: 9
            weekly_summary: true
            weekly_summary_day: 1  # Monday
            weekly_summary_hour: 9
    """
    results: dict = {"daily": None, "weekly": None}

    try:
        from otto.config import get_setting

        obs_config = get_setting("gateway.observability") or {}

        # Daily summary
        if obs_config.get("daily_summary", False):
            target_hour = int(obs_config.get("daily_summary_hour", 9))
            state = load_state(_DAILY_SUMMARY_ID)
            last_sent = state.get("last_sent_date")
            today = now.strftime("%Y-%m-%d")

            if last_sent != today and now.hour >= target_hour:
                if dry_run:
                    results["daily"] = {"would_send": True, "date": today}
                else:
                    try:
                        from otto.observability import generate_daily_summary

                        text = generate_daily_summary()
                        send_notification(text)
                        state["last_sent_date"] = today
                        state["last_sent_at"] = now.isoformat()
                        save_state(_DAILY_SUMMARY_ID, state)
                        results["daily"] = {"sent": True, "date": today}
                    except Exception as e:
                        results["daily"] = {"error": str(e)[:200]}

        # Weekly summary
        if obs_config.get("weekly_summary", False):
            target_day = int(obs_config.get("weekly_summary_day", 1))  # 0=Mon in ISO
            target_hour = int(obs_config.get("weekly_summary_hour", 9))
            state = load_state(_WEEKLY_SUMMARY_ID)
            last_sent_week = state.get("last_sent_week")
            current_week = now.strftime("%Y-W%W")

            # Check if it's the right day (isoweekday: 1=Mon, 7=Sun)
            if (
                last_sent_week != current_week
                and now.isoweekday() == target_day
                and now.hour >= target_hour
            ):
                if dry_run:
                    results["weekly"] = {"would_send": True, "week": current_week}
                else:
                    try:
                        from otto.observability import generate_weekly_summary

                        text = generate_weekly_summary()
                        send_notification(text)
                        state["last_sent_week"] = current_week
                        state["last_sent_at"] = now.isoformat()
                        save_state(_WEEKLY_SUMMARY_ID, state)
                        results["weekly"] = {"sent": True, "week": current_week}
                    except Exception as e:
                        results["weekly"] = {"error": str(e)[:200]}

    except Exception as e:
        results["error"] = str(e)[:200]

    return results


# ---------------------------------------------------------------------------
# Unified catch-up enqueue helper
# ---------------------------------------------------------------------------


def _enqueue_catchup(
    *,
    job_id: str,
    cron_expr: str,
    now: datetime,
    queue: JobQueue,
    build_payload: Callable[[datetime], dict],
    job_type: str,
    catch_up_limit: int = 5,
    dry_run: bool = False,
    source: str | None = None,
    post_enqueue: Callable[[], None] | None = None,
) -> list[dict]:
    """
    Shared catch-up enqueue loop used by brainfile static jobs,
    dynamic recurring schedules, and (conceptually) one-shot schedules.

    Returns a list of enqueue-result dicts for the caller to extend into
    its ``enqueued`` accumulator.
    """
    from croniter import croniter

    results: list[dict] = []

    state = load_state(job_id)
    if state.get("disabled"):
        return results

    last_enq_str = state.get("last_enqueued_for")
    base = now - timedelta(minutes=1)
    if isinstance(last_enq_str, str):
        try:
            base = datetime.fromisoformat(last_enq_str).replace(second=0, microsecond=0)
        except ValueError:
            base = now - timedelta(minutes=1)

    it = croniter(cron_expr, base)
    emitted = 0

    while True:
        next_run = it.get_next(datetime).replace(second=0, microsecond=0)
        if next_run > now:
            break
        emitted += 1
        if emitted > catch_up_limit:
            break

        entry: dict = {"job_id": job_id, "scheduled_for": next_run.isoformat()}
        if source:
            entry["source"] = source

        if dry_run:
            entry["dry_run"] = True
            results.append(entry)
            continue

        payload = build_payload(next_run)
        external_id = payload.pop("_external_id", f"scheduled:{job_id}:{next_run.isoformat()}")
        priority = payload.pop("_priority", 0)

        try:
            queue.add(job_type, payload, priority=priority, external_id=external_id)
        except sqlite3.IntegrityError:
            entry["deduped"] = True
            results.append(entry)
            mark_enqueued(job_id, next_run)
            if post_enqueue:
                post_enqueue()
            continue

        mark_enqueued(job_id, next_run)
        if post_enqueue:
            post_enqueue()
        results.append(entry)

    return results


def tick(*, dry_run: bool = False) -> dict:
    """
    Evaluate schedules and enqueue due jobs.

    Returns stats dict for logging/testing.
    """
    ensure_dirs()

    lock_fd = _acquire_lock(SCHEDULES_DIR / ".tick.lock")
    if lock_fd is None:
        return {"skipped": True, "reason": "locked"}

    try:
        jobs = _parse_brainfile_jobs()
        now = datetime.now().replace(second=0, microsecond=0)

        try:
            from croniter import croniter  # noqa: F401 – validate availability
        except ImportError as e:  # pragma: no cover
            raise RuntimeError("Missing dependency: croniter (add it to your environment)") from e

        queue = JobQueue()
        enqueued: list[dict] = []

        # Get default timeout from config
        from otto.backends import get_orchestration_config

        orch_config = get_orchestration_config()
        default_timeout = orch_config.get("default_timeout", 3600)

        # --- Brainfile static jobs ---
        for job in jobs:
            if not isinstance(job, dict):
                continue
            if not job.get("enabled", True):
                continue

            job_id = job.get("id")
            schedule = job.get("schedule")
            prompt = job.get("prompt")

            if not job_id or not schedule or not prompt:
                continue

            try:

                def _build_static_payload(next_run: datetime, _job=job) -> dict:
                    return {
                        "job_id": _job["id"],
                        "prompt": _job["prompt"],
                        "notify": _normalize_notify_mode(_job.get("notify", "on_error")),
                        "one_shot": bool(_job.get("one_shot", False)),
                        "backend": _job.get("backend"),
                        "timeout": int(_job.get("timeout", default_timeout)),
                        "scheduled_for": next_run.isoformat(),
                        "_external_id": f"scheduled:{_job['id']}:{next_run.isoformat()}",
                        "_priority": int(_job.get("priority", 0)),
                    }

                results = _enqueue_catchup(
                    job_id=job_id,
                    cron_expr=schedule,
                    now=now,
                    queue=queue,
                    build_payload=_build_static_payload,
                    job_type="scheduled",
                    catch_up_limit=int(job.get("catch_up_limit", 5)),
                    dry_run=dry_run,
                )
                enqueued.extend(results)
            except Exception as e:
                err = str(e)[:500]
                enqueued.append({"job_id": job_id, "error": err})
                if not dry_run:
                    try:
                        state = load_state(job_id)
                        state["last_error"] = err
                        state["last_failed_at"] = datetime.now().isoformat()
                        save_state(job_id, state)
                    except Exception:
                        pass
                continue

        # --- Dynamic schedules: enqueue as agent jobs for reliable notification ---
        try:
            system_prompt = build_agent_system_prompt()
        except Exception:
            system_prompt = "You are Otto, a helpful assistant running a scheduled task."

        try:
            OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

        def _build_dynamic_agent_payload(sched: dict, scheduled_for: str) -> dict:
            sid = sched["id"]
            task_name = (sched.get("name") or "")[:120] or "Scheduled task"
            output_file = OUTPUTS_DIR / f"{sid}.txt"
            return {
                "agent_id": sid,
                "prompt": sched["prompt"],
                "system": system_prompt,
                "task": task_name,
                "backend": sched.get("backend"),
                "model": sched.get("model"),
                "timeout": default_timeout,
                "notify": sched.get("notify", "always"),
                "priority": "normal",
                "output_file": str(output_file),
            }

        # --- Dynamic one-shot schedules ---
        try:
            due_oneshots = schedule_store.get_enabled_oneshot(now)
        except Exception:
            due_oneshots = []

        for sched in due_oneshots:
            try:
                sid = sched["id"]
                if dry_run:
                    enqueued.append(
                        {
                            "job_id": sid,
                            "scheduled_for": sched.get("run_at"),
                            "dry_run": True,
                            "source": "dynamic",
                        }
                    )
                    continue

                payload = _build_dynamic_agent_payload(sched, sched.get("run_at", ""))
                try:
                    queue.add("agent", payload, external_id=sid)
                except sqlite3.IntegrityError:
                    enqueued.append(
                        {
                            "job_id": sid,
                            "scheduled_for": sched.get("run_at"),
                            "deduped": True,
                            "source": "dynamic",
                        }
                    )
                    mark_enqueued(sid, now)
                    schedule_store.disable_schedule(sid)
                    continue

                mark_enqueued(sid, now)
                schedule_store.disable_schedule(sid)
                enqueued.append(
                    {"job_id": sid, "scheduled_for": sched.get("run_at"), "source": "dynamic"}
                )
            except Exception as e:
                err = str(e)[:500]
                enqueued.append({"job_id": sched.get("id", "?"), "error": err, "source": "dynamic"})

        # --- Dynamic recurring schedules ---
        try:
            recurring = schedule_store.get_enabled_recurring()
        except Exception:
            recurring = []

        for sched in recurring:
            try:
                sid = sched["id"]
                cron_expr = sched.get("cron_expr")
                if not cron_expr:
                    continue

                def _build_recurring_payload(next_run: datetime, _sched=sched) -> dict:
                    p = _build_dynamic_agent_payload(_sched, next_run.isoformat())
                    p["_external_id"] = f"{_sched['id']}:{next_run.isoformat()}"
                    return p

                results = _enqueue_catchup(
                    job_id=sid,
                    cron_expr=cron_expr,
                    now=now,
                    queue=queue,
                    build_payload=_build_recurring_payload,
                    job_type="agent",
                    catch_up_limit=5,
                    dry_run=dry_run,
                    source="dynamic",
                )
                enqueued.extend(results)
            except Exception as e:
                err = str(e)[:500]
                enqueued.append({"job_id": sched.get("id", "?"), "error": err, "source": "dynamic"})

        # --- Built-in observability summaries ---
        summary_results = _check_observability_summaries(now, dry_run=dry_run)

        supervisor = supervise(dry_run=dry_run)
        return {
            "skipped": False,
            "enqueued": enqueued,
            "now": now.isoformat(),
            "supervisor": supervisor,
            "observability": summary_results,
        }
    finally:
        try:
            import fcntl

            fcntl.flock(lock_fd, fcntl.LOCK_UN)
        finally:
            lock_fd.close()


if __name__ == "__main__":
    print(json.dumps(tick(dry_run=True), indent=2))
