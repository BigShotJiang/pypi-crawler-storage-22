"""Durable schedule metadata stored in SQLite (same DB as jobs.sqlite)."""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime
from typing import Any

from otto.jobs.queue import DEFAULT_DB


def _ensure_table(conn: sqlite3.Connection) -> None:
    conn.execute(
        """CREATE TABLE IF NOT EXISTS schedule_state (
            job_id         TEXT PRIMARY KEY,
            last_enqueued_for TEXT,
            run_count      INTEGER DEFAULT 0,
            last_status    TEXT,
            last_error     TEXT,
            disabled       INTEGER DEFAULT 0,
            last_run_at    TEXT,
            last_failed_at TEXT,
            last_sent_date TEXT,
            last_sent_week TEXT,
            last_sent_at   TEXT,
            last_checked_at TEXT,
            services       TEXT,
            updated_at     TEXT
        )"""
    )


@contextmanager
def _conn():
    db_path = DEFAULT_DB
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path), timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    _ensure_table(conn)
    try:
        yield conn
    finally:
        conn.close()


# Columns that store simple scalar values (not JSON-encoded)
_SCALAR_COLS = {
    "job_id",
    "last_enqueued_for",
    "run_count",
    "last_status",
    "last_error",
    "disabled",
    "last_run_at",
    "last_failed_at",
    "last_sent_date",
    "last_sent_week",
    "last_sent_at",
    "last_checked_at",
    "updated_at",
}


def load(job_id: str) -> dict[str, Any]:
    with _conn() as conn:
        row = conn.execute("SELECT * FROM schedule_state WHERE job_id = ?", (job_id,)).fetchone()

    if row is None:
        return {
            "job_id": job_id,
            "disabled": False,
            "run_count": 0,
        }

    state: dict[str, Any] = {}
    for key in row.keys():
        val = row[key]
        if key == "disabled":
            state[key] = bool(val)
        elif key == "services" and val is not None:
            import json

            try:
                state[key] = json.loads(val)
            except (json.JSONDecodeError, TypeError):
                state[key] = {}
        else:
            state[key] = val

    # Ensure run_count is int
    state["run_count"] = int(state.get("run_count") or 0)
    return state


def save(job_id: str, state: dict[str, Any]) -> None:
    import json

    state = dict(state)
    state["job_id"] = job_id
    state["updated_at"] = datetime.now().isoformat()

    # Serialize services dict to JSON string
    if "services" in state and isinstance(state["services"], dict):
        state["services"] = json.dumps(state["services"])

    # Convert disabled bool to int for SQLite
    if "disabled" in state:
        state["disabled"] = int(bool(state["disabled"]))

    with _conn() as conn:
        # Get existing columns
        cursor = conn.execute("PRAGMA table_info(schedule_state)")
        existing_cols = {r["name"] for r in cursor.fetchall()}

        # Filter to known columns only
        filtered = {k: v for k, v in state.items() if k in existing_cols}

        cols = list(filtered.keys())
        placeholders = ", ".join(["?"] * len(cols))
        col_names = ", ".join(cols)
        updates = ", ".join(f"{c} = excluded.{c}" for c in cols if c != "job_id")

        conn.execute(
            f"INSERT INTO schedule_state ({col_names}) VALUES ({placeholders}) "
            f"ON CONFLICT(job_id) DO UPDATE SET {updates}",
            [filtered[c] for c in cols],
        )
        conn.commit()


def mark_enqueued(job_id: str, scheduled_for: datetime) -> None:
    state = load(job_id)
    state["last_enqueued_for"] = scheduled_for.replace(second=0, microsecond=0).isoformat()
    save(job_id, state)


def mark_run(job_id: str, *, status: str, error: str | None = None, one_shot: bool = False) -> None:
    state = load(job_id)
    state["last_run_at"] = datetime.now().isoformat()
    state["last_status"] = status
    if error:
        state["last_error"] = error
    state["run_count"] = int(state.get("run_count", 0) or 0) + 1
    if one_shot and status == "completed":
        state["disabled"] = True
    save(job_id, state)
