#!/usr/bin/env python3
"""
Heartbeat service - background agent monitor.

This module provides the entry point for the heartbeat daemon using the
HeartbeatDaemon class. Run via:

    otto service start heartbeat
    otto service start all  # includes heartbeat

Or directly:

    python -m otto.services.heartbeat
"""

from __future__ import annotations

import asyncio
import logging
import os
import signal
from logging.handlers import RotatingFileHandler

from otto.paths import LOGS_DIR, ensure_dirs

SERVICE_NAME = "heartbeat"


def _setup_logging() -> logging.Logger:
    """Set up logging for the heartbeat service."""
    ensure_dirs()
    LOGS_DIR.mkdir(parents=True, exist_ok=True)

    handlers = [
        RotatingFileHandler(
            LOGS_DIR / "heartbeat.log",
            maxBytes=5 * 1024 * 1024,
            backupCount=3,
            encoding="utf-8",
        ),
        logging.StreamHandler(),
    ]
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(message)s",
        level=logging.INFO,
        handlers=handlers,
    )

    # Reduce noise from libraries
    logging.getLogger("asyncio").setLevel(logging.WARNING)

    return logging.getLogger(__name__)


def _on_check_result(check, output: str, is_ok: bool) -> None:
    """Handle check result notification."""
    from otto.internal_messages import InternalMessage, queue_message

    # Build notification message
    msg = InternalMessage.create(
        "heartbeat_check",
        {
            "check_id": check.id,
            "prompt": check.prompt[:100],
            "output": output[:1500] if output else None,
            "is_ok": is_ok,
            "backend": check.backend,
        },
    )
    queue_message(msg)


def main() -> None:
    """Main entry point for the heartbeat service."""
    from otto.daemon import ServiceStatus, cleanup_own_pid, status, write_own_pid
    from otto.heartbeat import HeartbeatDaemon

    log = _setup_logging()

    # Check for already running instance
    info = status(SERVICE_NAME)
    if info.status == ServiceStatus.RUNNING and info.pid != os.getpid():
        log.error(
            "Heartbeat service is already running (PID %s). "
            "Stop it first with: otto service stop heartbeat",
            info.pid,
        )
        return

    # Write our PID file
    write_own_pid(SERVICE_NAME)

    # Create daemon instance with check callback
    daemon = HeartbeatDaemon(
        poll_interval=30.0,
        timeout_seconds=3600.0,  # 1 hour
        on_check_result=_on_check_result,
    )

    async def run_daemon():
        """Run the daemon until shutdown."""
        loop = asyncio.get_running_loop()
        shutdown_event = asyncio.Event()

        def handle_signal():
            """Handle shutdown signals."""
            log.info("Received shutdown signal, stopping...")
            shutdown_event.set()

        # Register signal handlers with the event loop
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, handle_signal)

        try:
            await daemon.start()
            log.info("Heartbeat daemon started (PID %s)", os.getpid())

            # Wait for shutdown signal
            await shutdown_event.wait()

            log.info("Shutting down heartbeat daemon...")
            await daemon.stop()
        except Exception as e:
            log.exception("Heartbeat daemon error: %s", e)
            raise
        finally:
            # Remove signal handlers
            for sig in (signal.SIGTERM, signal.SIGINT):
                loop.remove_signal_handler(sig)

    try:
        asyncio.run(run_daemon())
    except KeyboardInterrupt:
        log.info("Interrupted by user")
    finally:
        cleanup_own_pid(SERVICE_NAME)
        log.info("Heartbeat service stopped")


if __name__ == "__main__":
    main()
