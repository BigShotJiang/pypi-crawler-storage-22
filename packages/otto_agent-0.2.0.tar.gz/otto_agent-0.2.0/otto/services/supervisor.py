"""
Service supervisor – monitors and self-heals critical Otto services.

Extracted from otto.schedule to keep scheduling logic focused on job
orchestration while supervision lives alongside other services.
"""

from __future__ import annotations

from datetime import datetime

from otto.notify import send as send_notification
from otto.schedule_state import load as load_state
from otto.schedule_state import save as save_state

_SUPERVISOR_JOB_ID = "__service_supervisor__"


def _supervisor_config() -> dict:
    from otto import config as otto_config

    return {
        "enabled": bool(otto_config.get_setting("supervisor.enabled", True)),
        "alert_after_failures": int(
            otto_config.get_setting("supervisor.alert_after_failures", 3) or 3
        ),
        "check_mcp": bool(otto_config.get_setting("supervisor.check_mcp", True)),
    }


def _get_supervisor_state() -> dict:
    state = load_state(_SUPERVISOR_JOB_ID)
    if not isinstance(state.get("services"), dict):
        state["services"] = {}
    return state


def _update_service_state(
    state: dict, *, key: str, healthy: bool, threshold: int, details: str
) -> None:
    services = state.setdefault("services", {})
    svc = services.setdefault(key, {"consecutive_failures": 0, "alerted": False})
    if not isinstance(svc, dict):
        svc = {"consecutive_failures": 0, "alerted": False}
        services[key] = svc

    if healthy:
        svc["consecutive_failures"] = 0
        svc["alerted"] = False
        svc["last_ok"] = datetime.now().isoformat()
        svc.pop("last_error", None)
        return

    svc["consecutive_failures"] = int(svc.get("consecutive_failures", 0) or 0) + 1
    svc["last_error"] = details[:500] if details else "unhealthy"
    svc["last_failed_at"] = datetime.now().isoformat()

    if threshold <= 0:
        return
    if svc.get("alerted"):
        return
    if int(svc["consecutive_failures"]) < threshold:
        return

    svc["alerted"] = True
    try:
        send_notification(
            "\n".join(
                [
                    "<b>Supervisor</b>: service unhealthy",
                    f"- <code>{key}</code>",
                    f"- failures: {svc['consecutive_failures']}",
                    f"- last_error: {svc.get('last_error', '')}",
                ]
            )
        )
    except Exception:
        # Best-effort: never break scheduling.
        pass


def supervise(*, dry_run: bool = False) -> dict:
    """Check critical service health and self-heal when possible."""
    from otto.daemon import ServiceStatus, check_mcp_health, default_service_commands, start, status

    cfg = _supervisor_config()
    if not cfg["enabled"]:
        return {"enabled": False}

    threshold = int(cfg["alert_after_failures"])
    alert_threshold = 0 if dry_run else threshold
    state = _get_supervisor_state()
    state["last_checked_at"] = datetime.now().isoformat()

    results: dict[str, dict] = {}

    for service, cmd in default_service_commands().items():
        info = status(service)
        action = None
        healthy = info.status == ServiceStatus.RUNNING

        if not healthy and not dry_run:
            ok, msg = start(service, cmd)
            action = msg
            info = status(service)
            healthy = info.status == ServiceStatus.RUNNING
            if not healthy and ok:
                # Start said ok but status disagrees; treat as unhealthy.
                pass

        details = action or info.status.value
        results[service] = {
            "status": info.status.value,
            "pid": info.pid,
            "healthy": healthy,
            "action": action,
        }
        _update_service_state(
            state,
            key=service,
            healthy=healthy,
            threshold=alert_threshold,
            details=details,
        )

    if cfg["check_mcp"]:
        mcp_ok, mcp_msg = (True, "dry-run") if dry_run else check_mcp_health()
        results["mcp"] = {"healthy": bool(mcp_ok), "details": mcp_msg}
        _update_service_state(
            state,
            key="mcp",
            healthy=bool(mcp_ok),
            threshold=alert_threshold,
            details=mcp_msg,
        )

    if not dry_run:
        save_state(_SUPERVISOR_JOB_ID, state)

    return {"enabled": True, "results": results}
