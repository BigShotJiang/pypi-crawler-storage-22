"""
Job Worker - processes jobs from the SQLite queue.

This module is the installable entrypoint used by `otto service start worker`.
"""

from __future__ import annotations

import logging
import os
import signal
import time
from concurrent.futures import Future, ThreadPoolExecutor
from logging.handlers import RotatingFileHandler

from otto import get_backend
from otto.heartbeat.integration import on_agent_complete, on_agent_fail, on_agent_start
from otto.jobs.queue import JobQueue
from otto.paths import LOGS_DIR, ensure_dirs

from .handlers import (
    HANDLERS,
    _normalize_notify_mode,
    handle_agent,
    handle_chain,
    handle_http,
    handle_notify,
    handle_scheduled,
    handle_shell,
    handler,
)
from .pipelines import (
    _get_upstream_context,
    _handle_agent_notification,
)

ensure_dirs()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        RotatingFileHandler(
            LOGS_DIR / "worker.log",
            maxBytes=5 * 1024 * 1024,
            backupCount=5,
            encoding="utf-8",
        ),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger(__name__)


class Worker:
    # Heartbeat interval (minutes) - should be well under stale lock timeout (30 min)
    HEARTBEAT_INTERVAL_MINUTES: float = 5.0  # Can override via env WORKER_HEARTBEAT_MIN

    def __init__(self, worker_id: str | None = None, concurrency: int = 1):
        self.queue = JobQueue()
        self.worker_id = worker_id or f"worker-{os.getpid()}"
        self.running = True
        self.poll_interval = 5
        self.concurrency = max(1, concurrency)
        self._last_tick_at: float = time.monotonic()
        self._tick_interval: float = 60.0

        # Allow env var override for testing
        env_hb = os.environ.get("WORKER_HEARTBEAT_MIN")
        if env_hb:
            try:
                self.HEARTBEAT_INTERVAL_MINUTES = float(env_hb)
            except ValueError:
                pass

        signal.signal(signal.SIGTERM, self._shutdown)
        signal.signal(signal.SIGINT, self._shutdown)

    def _shutdown(self, signum, frame):
        log.info("Received signal %s, shutting down...", signum)
        self.running = False

    def _maybe_tick(self) -> None:
        """Run scheduler tick if enough time has elapsed since the last one."""
        now = time.monotonic()
        if now - self._last_tick_at < self._tick_interval:
            return
        self._last_tick_at = now
        try:
            from otto.schedule import tick

            result = tick(dry_run=False)
            if result.get("skipped"):
                return
            enqueued = result.get("enqueued", [])
            if enqueued:
                log.info("Scheduler tick enqueued %d job(s)", len(enqueued))
        except Exception:
            log.exception("Scheduler tick failed")

    def _run_with_heartbeat(self, job_id: int, job_type: str, handler_func, payload: dict) -> str:
        """Run a handler with periodic heartbeat updates.

        Creates a per-job heartbeat thread that runs independently.
        Used by both single-threaded and concurrent modes.
        """
        import threading

        stop_event = threading.Event()

        def _heartbeat():
            interval_seconds = self.HEARTBEAT_INTERVAL_MINUTES * 60
            while not stop_event.is_set():
                time.sleep(interval_seconds)
                if stop_event.is_set():
                    break
                try:
                    self.queue.heartbeat(job_id)
                except Exception:
                    log.exception("Heartbeat failed for job #%s", job_id)

        # Start heartbeat thread
        thread = threading.Thread(target=_heartbeat, daemon=True)
        thread.start()
        log.debug(
            "Started heartbeat for job #%s (interval=%.1f min)",
            job_id,
            self.HEARTBEAT_INTERVAL_MINUTES,
        )

        try:
            return handler_func(payload)
        finally:
            stop_event.set()
            # Give thread a moment to exit cleanly
            thread.join(timeout=1.0)

    def process_one(self) -> bool:
        job = self.queue.next(self.worker_id)
        if not job:
            return False

        job_id = job["id"]
        job_type = job["type"]
        payload = job["payload"]

        log.info("Processing job #%s [%s]", job_id, job_type)
        self.queue.set_pid(job_id, os.getpid())

        # Best-effort metadata for handlers (helps with retries/notifications).
        if isinstance(payload, dict):
            payload["_job"] = {
                "id": job_id,
                "type": job_type,
                "external_id": job.get("external_id"),
                "attempt": job.get("attempts"),
                "max_attempts": job.get("max_attempts"),
                "depends_on_id": job.get("depends_on_id"),
            }

            # Inject upstream context for pipeline jobs
            depends_on_id = job.get("depends_on_id")
            if depends_on_id and job_type == "agent":
                upstream_context = self._get_upstream_context(depends_on_id)
                if upstream_context:
                    payload["_upstream_context"] = upstream_context

        handler_func = HANDLERS.get(job_type)
        if not handler_func:
            error = f"No handler for job type: {job_type}"
            log.error(error)
            self.queue.fail(job_id, error)
            return True

        # Register with heartbeat monitoring
        if job_type in ("agent", "claude"):
            _hb_agent_id = job.get("external_id") or (
                payload.get("agent_id") if isinstance(payload, dict) else None
            )
            if _hb_agent_id:
                _hb_prompt = (
                    (payload.get("prompt") or "")[:200] if isinstance(payload, dict) else ""
                )
                _hb_backend = (
                    (payload.get("backend") or "pi") if isinstance(payload, dict) else "pi"
                )
                on_agent_start(str(_hb_agent_id), _hb_prompt, _hb_backend)

        try:
            # Run with heartbeat for long-running job types
            if job_type in ("agent", "scheduled", "claude"):
                result = self._run_with_heartbeat(job_id, job_type, handler_func, payload)
            else:
                result = handler_func(payload)

            # Check if job was cancelled while running (force_cancel from CLI/chat)
            job_now = self.queue.get(job_id)
            if job_now and job_now.get("status") == "cancelled":
                log.info("Job #%s was cancelled while running, discarding result", job_id)
                return True

            self.queue.complete(job_id)

            if job_type == "agent":
                agent_id = job.get("external_id") or payload.get("agent_id") or payload.get("id")
                if agent_id:
                    self.queue.activate_dependents(str(agent_id), "completed")
                    on_agent_complete(str(agent_id))

                # Handle notifications AFTER job is marked complete so pipeline checks are accurate
                notify_meta = payload.get("_notify_meta")
                if notify_meta:
                    self._handle_agent_notification(notify_meta, success=True)

            if "on_success" in payload:
                self._handle_callback(payload["on_success"], str(result))
        except Exception as e:
            error = str(e)
            log.error("Job #%s failed: %s", job_id, error)

            # Check if job was cancelled while running
            job_now = self.queue.get(job_id)
            if job_now and job_now.get("status") == "cancelled":
                log.info("Job #%s was cancelled while running, not marking as failed", job_id)
                return True

            self.queue.fail(job_id, error)

            if job_type == "agent":
                agent_id = job.get("external_id") or payload.get("agent_id") or payload.get("id")
                job_after = self.queue.get(job_id)
                if agent_id and job_after and job_after.get("status") == "failed":
                    self.queue.activate_dependents(str(agent_id), "failed")
                if agent_id:
                    on_agent_fail(str(agent_id), error)

                # Handle notifications AFTER job is marked failed so pipeline checks are accurate
                notify_meta = payload.get("_notify_meta")
                if notify_meta:
                    # Update meta with failure info
                    notify_meta["success"] = False
                    notify_meta["error"] = error[:200] if error else None
                    self._handle_agent_notification(notify_meta, success=False)

            if "on_failure" in payload:
                self._handle_callback(payload["on_failure"], error)

        return True

    def _handle_callback(self, callback: dict, data: str) -> None:
        callback_type = callback.get("type", "notify")
        callback_payload = callback.get("payload", {})
        callback_payload["_data"] = data
        self.queue.add(callback_type, callback_payload)

    def _get_upstream_context(self, parent_agent_id: str) -> dict | None:
        """Get output from upstream pipeline stage to inject into downstream prompt."""
        return _get_upstream_context(self.queue, parent_agent_id)

    def _handle_agent_notification(self, meta: dict, *, success: bool) -> None:
        """Handle agent completion notification after job is marked complete."""
        _handle_agent_notification(self.queue, meta, success=success)

    def run_all(self) -> int:
        count = 0
        while self.running and self.process_one():
            count += 1
        log.info("Processed %s jobs", count)
        return count

    def run_daemon(self) -> None:
        if self.concurrency > 1:
            self.run_daemon_concurrent()
            return
        log.info("Worker %s starting daemon mode (single-threaded)", self.worker_id)
        # Run first tick shortly after startup
        self._last_tick_at = time.monotonic() - self._tick_interval + 5.0
        while self.running:
            self._maybe_tick()
            if not self.process_one():
                time.sleep(self.poll_interval)
        log.info("Worker stopped")

    def run_daemon_concurrent(self) -> None:
        log.info(
            "Worker %s starting daemon mode (concurrency=%d)",
            self.worker_id,
            self.concurrency,
        )
        futures: list[Future] = []
        pool = ThreadPoolExecutor(max_workers=self.concurrency)
        # Run first tick shortly after startup
        self._last_tick_at = time.monotonic() - self._tick_interval + 5.0
        try:
            while self.running:
                self._maybe_tick()

                # Collect completed futures
                done = [f for f in futures if f.done()]
                for f in done:
                    futures.remove(f)
                    try:
                        f.result()
                    except Exception:
                        log.exception("Worker thread error")

                # Submit new jobs if free slots available
                submitted = False
                while self.running and len(futures) < self.concurrency:
                    job = self.queue.next(self.worker_id)
                    if not job:
                        break
                    futures.append(pool.submit(self._process_job, job))
                    submitted = True

                if not submitted and not done:
                    time.sleep(self.poll_interval)
        finally:
            # Wait for in-flight jobs to finish
            log.info("Waiting for %d in-flight job(s) to complete...", len(futures))
            for f in futures:
                try:
                    f.result(timeout=60)
                except Exception:
                    log.exception("Error in in-flight job during shutdown")
            pool.shutdown(wait=False)
            log.info("Worker stopped")

    def _process_job(self, job: dict) -> None:
        """Process a single job (used by concurrent mode)."""
        job_id = job["id"]
        job_type = job["type"]
        payload = job["payload"]

        log.info("Processing job #%s [%s]", job_id, job_type)
        self.queue.set_pid(job_id, os.getpid())

        if isinstance(payload, dict):
            payload["_job"] = {
                "id": job_id,
                "type": job_type,
                "external_id": job.get("external_id"),
                "attempt": job.get("attempts"),
                "max_attempts": job.get("max_attempts"),
                "depends_on_id": job.get("depends_on_id"),
            }
            depends_on_id = job.get("depends_on_id")
            if depends_on_id and job_type == "agent":
                upstream_context = self._get_upstream_context(depends_on_id)
                if upstream_context:
                    payload["_upstream_context"] = upstream_context

        handler_func = HANDLERS.get(job_type)
        if not handler_func:
            error = f"No handler for job type: {job_type}"
            log.error(error)
            self.queue.fail(job_id, error)
            return

        # Register with heartbeat monitoring
        if job_type in ("agent", "claude"):
            _hb_agent_id = job.get("external_id") or (
                payload.get("agent_id") if isinstance(payload, dict) else None
            )
            if _hb_agent_id:
                _hb_prompt = (
                    (payload.get("prompt") or "")[:200] if isinstance(payload, dict) else ""
                )
                _hb_backend = (
                    (payload.get("backend") or "pi") if isinstance(payload, dict) else "pi"
                )
                on_agent_start(str(_hb_agent_id), _hb_prompt, _hb_backend)

        try:
            # Run with heartbeat for long-running job types
            if job_type in ("agent", "scheduled", "claude"):
                result = self._run_with_heartbeat(job_id, job_type, handler_func, payload)
            else:
                result = handler_func(payload)

            # Check if job was cancelled while running (force_cancel from CLI/chat)
            job_now = self.queue.get(job_id)
            if job_now and job_now.get("status") == "cancelled":
                log.info("Job #%s was cancelled while running, discarding result", job_id)
                return

            self.queue.complete(job_id)

            if job_type == "agent":
                agent_id = job.get("external_id") or payload.get("agent_id") or payload.get("id")
                if agent_id:
                    self.queue.activate_dependents(str(agent_id), "completed")
                    on_agent_complete(str(agent_id))
                notify_meta = payload.get("_notify_meta")
                if notify_meta:
                    self._handle_agent_notification(notify_meta, success=True)

            if "on_success" in payload:
                self._handle_callback(payload["on_success"], str(result))
        except Exception as e:
            error = str(e)
            log.error("Job #%s failed: %s", job_id, error)

            # Check if job was cancelled while running
            job_now = self.queue.get(job_id)
            if job_now and job_now.get("status") == "cancelled":
                log.info("Job #%s was cancelled while running, not marking as failed", job_id)
                return

            self.queue.fail(job_id, error)

            if job_type == "agent":
                agent_id = job.get("external_id") or payload.get("agent_id") or payload.get("id")
                job_after = self.queue.get(job_id)
                if agent_id and job_after and job_after.get("status") == "failed":
                    self.queue.activate_dependents(str(agent_id), "failed")
                if agent_id:
                    on_agent_fail(str(agent_id), error)
                notify_meta = payload.get("_notify_meta")
                if notify_meta:
                    notify_meta["success"] = False
                    notify_meta["error"] = error[:200] if error else None
                    self._handle_agent_notification(notify_meta, success=False)

            if "on_failure" in payload:
                self._handle_callback(payload["on_failure"], error)


SERVICE_NAME = "job-worker"


def main(*, daemon: bool = False, once: bool = False, worker_id: str | None = None) -> None:
    import signal

    from otto.backends import reload_config
    from otto.daemon import ServiceStatus, cleanup_own_pid, status, write_own_pid

    (LOGS_DIR).mkdir(parents=True, exist_ok=True)

    # For daemon mode, check for already running instance (skip if the PID is
    # ourself - happens when started via daemon.start() which writes our PID first)
    if daemon:
        info = status(SERVICE_NAME)
        if info.status == ServiceStatus.RUNNING and info.pid != os.getpid():
            log.error(
                "Worker is already running (PID %s). Stop it first with: otto service stop worker",
                info.pid,
            )
            return

        # Write our PID file (may already exist if started via daemon.start())
        write_own_pid(SERVICE_NAME)

    # Set up SIGHUP handler for config reload
    def _handle_sighup(signum, frame):
        log.info("Received SIGHUP, reloading configuration...")
        try:
            reload_config()
            log.info("Configuration reloaded successfully")
        except Exception as e:
            log.error("Config reload failed: %s", e)

    signal.signal(signal.SIGHUP, _handle_sighup)

    try:
        from otto.backends import get_orchestration_config

        orch_config = get_orchestration_config()
        concurrency = int(orch_config.get("worker_concurrency", 1))
        worker = Worker(worker_id=worker_id, concurrency=concurrency)
        if daemon:
            worker.run_daemon()
            return
        if once:
            worker.process_one()
            return
        worker.run_all()
    finally:
        # Clean up PID file if we wrote one
        if daemon:
            cleanup_own_pid(SERVICE_NAME)
