from . import main

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Job queue worker")
    parser.add_argument("--daemon", action="store_true", help="Run forever")
    parser.add_argument("--once", action="store_true", help="Process one job only")
    parser.add_argument("--id", default=None, help="Worker ID")
    args = parser.parse_args()

    main(daemon=args.daemon, once=args.once, worker_id=args.id)
