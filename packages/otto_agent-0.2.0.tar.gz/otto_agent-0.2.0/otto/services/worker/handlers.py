from __future__ import annotations

import logging
import subprocess
import urllib.error
import urllib.request
from collections.abc import Callable
from pathlib import Path

from otto.notify import send as send_notification
from otto.paths import BRAINFILE, OUTPUTS_DIR, get_workdir
from otto.schedule_state import mark_run


def _get_backend(name=None):
    """Resolve get_backend at call time so monkeypatching works.

    Tests monkeypatch ``otto.services.worker.get_backend`` (the package-level
    attribute).  By looking it up through the package at call time rather than
    binding at import time, we honour that patch transparently.
    """
    import otto.services.worker as _pkg

    _fn = getattr(_pkg, "get_backend", None)
    if _fn is not None:
        return _fn(name)
    # Fallback: use otto.get_backend directly
    from otto import get_backend

    return get_backend(name)


log = logging.getLogger(__name__)

HANDLERS: dict[str, Callable[[dict], str]] = {}

_NOTIFY_MODES = {"always", "on_error", "on_action", "never"}


def _normalize_notify_mode(value: object, *, default: str = "never") -> str:
    """Normalize notify config to a supported mode."""
    if value is None:
        return default
    if isinstance(value, bool):
        return "always" if value else "never"
    mode = str(value).strip().lower()
    if mode in ("true", "yes", "1"):
        return "always"
    if mode in ("false", "no", "0"):
        return "never"
    return mode if mode in _NOTIFY_MODES else default


def handler(job_type: str):
    """Decorator to register a job handler."""

    def decorator(func):
        HANDLERS[job_type] = func
        return func

    return decorator


@handler("notify")
def handle_notify(payload: dict) -> str:
    message = payload.get("message", "")
    if not message:
        raise ValueError("No message in payload")
    send_notification(message)
    return "Notification sent"


@handler("claude")
@handler("agent")
def handle_agent(payload: dict) -> str:
    from otto.backends import get_orchestration_config

    prompt = payload.get("prompt", "")
    if not prompt:
        raise ValueError("No prompt in payload")

    # Inject upstream context for pipeline jobs
    upstream = payload.get("_upstream_context")
    if upstream and upstream.get("parent_output"):
        context_block = [
            "<upstream_pipeline_context>",
            f"Previous stage: {upstream.get('parent_task', 'unknown')}",
            f"Status: {upstream.get('parent_status', 'unknown')}",
            "",
            "Output from previous stage:",
            upstream.get("parent_output", ""),
            "</upstream_pipeline_context>",
            "",
            "Your task (continue the pipeline):",
        ]
        prompt = "\n".join(context_block) + "\n" + prompt

    system = (
        payload.get("system")
        or payload.get("system_prompt")
        or "You are Otto, a helpful assistant."
    )
    # Get default timeout from config
    orch_config = get_orchestration_config()
    default_timeout = orch_config.get("default_timeout", 3600)
    timeout = int(payload.get("timeout", default_timeout))
    backend_name = payload.get("backend")  # None uses active backend
    model = payload.get("model")  # For dynamic routing (e.g., "openrouter/provider/model")
    notify_mode = _normalize_notify_mode(payload.get("notify"), default="never")
    pipeline_grace = int(orch_config.get("pipeline_notify_grace_seconds", 8) or 0)
    if pipeline_grace < 0:
        pipeline_grace = 0

    backend = _get_backend(backend_name)
    result = backend.run_sync(prompt, system, get_workdir(), timeout, model=model)

    agent_id = str(payload.get("agent_id") or payload.get("id") or "")[:32]
    task_desc = str(payload.get("task") or payload.get("task_description") or "").strip()
    priority = str(payload.get("priority") or "normal")

    output_file = payload.get("output_file")
    if output_file:
        output_path = Path(str(output_file)).expanduser()
    elif agent_id:
        output_path = OUTPUTS_DIR / f"{agent_id}.txt"
    else:
        output_path = None

    if output_path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        content = [
            f"Task: {task_desc}" if task_desc else "Task: (unspecified)",
            f"Backend: {backend_name or backend.name}",
            f"Success: {result.success}",
            f"Duration: {result.duration_seconds:.2f}s",
            "",
            "=" * 50,
            "",
            result.output or "",
        ]
        if result.error:
            content.extend(["", f"Error: {result.error}"])
        output_path.write_text("\n".join(content))

    job_meta = payload.get("_job") if isinstance(payload.get("_job"), dict) else {}
    attempt = int(job_meta.get("attempt", 0) or 0)
    max_attempts = int(job_meta.get("max_attempts", 0) or 0)
    is_final_attempt = max_attempts > 0 and attempt >= max_attempts

    output_text = (result.output or "").strip()
    should_notify = False
    if notify_mode == "always":
        should_notify = result.success or is_final_attempt
    elif notify_mode == "on_error":
        should_notify = (not result.success) and is_final_attempt
    elif notify_mode == "on_action":
        should_notify = (bool(output_text) and result.success) or (
            (not result.success) and is_final_attempt
        )

    # Store notification metadata for the worker to handle AFTER job is marked complete.
    # This ensures pipeline completion checks see accurate job statuses.
    if should_notify:
        payload["_notify_meta"] = {
            "agent_id": agent_id or None,
            "task": task_desc or None,
            "backend": backend_name or backend.name,
            "success": result.success,
            "attempt": attempt or None,
            "max_attempts": max_attempts or None,
            "duration": result.duration_seconds,
            "output_file": str(output_path) if output_path else None,
            "output_summary": output_text[:2000] or None,
            "error": (result.error[:200] if result.error else None),
            "priority": priority,
            "pipeline_grace": pipeline_grace,
            "session_id": payload.get("session_id"),
            "chat_id": payload.get("chat_id"),
        }
        if not job_meta.get("id"):
            from otto.internal_messages import InternalMessage, queue_message

            msg = InternalMessage.create(
                "agent_completed",
                {
                    "agent_id": agent_id or None,
                    "task": task_desc or None,
                    "backend": backend_name or backend.name,
                    "success": result.success,
                    "attempt": attempt or None,
                    "max_attempts": max_attempts or None,
                    "duration": result.duration_seconds,
                    "output_file": str(output_path) if output_path else None,
                    "output_summary": output_text[:2000] or None,
                    "error": (result.error[:200] if result.error else None),
                    "priority": priority,
                    "session_id": payload.get("session_id"),
                    "chat_id": payload.get("chat_id"),
                },
            )
            queue_message(msg)

    if not result.success:
        raise RuntimeError(f"Agent failed: {result.error}")
    return result.output


@handler("shell")
def handle_shell(payload: dict) -> str:
    command = payload.get("command", "")
    if not command:
        raise ValueError("No command in payload")

    timeout = int(payload.get("timeout", 60))
    cwd = payload.get("cwd") or str(get_workdir())

    result = subprocess.run(
        command,
        shell=True,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )

    output = result.stdout + result.stderr
    if result.returncode != 0:
        raise RuntimeError(f"Command failed (exit {result.returncode}): {output}")

    return output.strip()


@handler("http")
def handle_http(payload: dict) -> str:
    url = payload.get("url", "")
    if not url:
        raise ValueError("No URL in payload")

    method = payload.get("method", "GET")
    headers = payload.get("headers", {})
    data = payload.get("data")
    timeout = int(payload.get("timeout", 30))

    req = urllib.request.Request(
        url,
        method=method,
        headers=headers,
        data=data.encode() if data else None,
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return f"{resp.status}: {resp.read().decode()[:1000]}"
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HTTP {e.code}: {e.reason}")


def _substitute_result(obj, result: str):
    if isinstance(obj, str):
        return obj.replace("{{result}}", result)
    if isinstance(obj, dict):
        return {k: _substitute_result(v, result) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_substitute_result(item, result) for item in obj]
    return obj


@handler("chain")
def handle_chain(payload: dict) -> str:
    jobs = payload.get("jobs", [])
    if not jobs:
        return "No jobs to chain"

    last_result = ""
    results = []

    for i, job_spec in enumerate(jobs):
        job_type = job_spec.get("type")
        job_payload = _substitute_result(job_spec.get("payload", {}), last_result)

        handler_func = HANDLERS.get(job_type)
        if not handler_func:
            raise RuntimeError(f"Step {i + 1}: No handler for {job_type}")

        log.info("Chain step %s/%s: %s", i + 1, len(jobs), job_type)
        last_result = handler_func(job_payload)
        results.append(f"Step {i + 1} ({job_type}): {str(last_result)[:50]}")

    return "\n".join(results)


@handler("scheduled")
def handle_scheduled(payload: dict) -> str:
    from datetime import datetime

    import yaml

    from otto.backends import get_orchestration_config
    from otto.internal_messages import InternalMessage, queue_message

    job_id = payload.get("job_id", "")
    prompt = payload.get("prompt", "")
    notify_mode = str(payload.get("notify", "on_error") or "on_error").strip().lower()
    backend_name = payload.get("backend")  # None uses active
    model = payload.get("model")  # For dynamic routing
    one_shot = bool(payload.get("one_shot", False))
    scheduled_for = payload.get("scheduled_for")
    # Get default timeout from config
    orch_config = get_orchestration_config()
    default_timeout = orch_config.get("default_timeout", 3600)
    timeout = int(payload.get("timeout", default_timeout))

    if not job_id:
        raise ValueError("No job_id in scheduled job payload")
    if not prompt:
        raise ValueError("No prompt in scheduled job payload")

    # Parse brainfile for context
    data = None
    if BRAINFILE.exists():
        content = BRAINFILE.read_text()
        if content.startswith("---"):
            end = content.find("\n---", 3)
            if end != -1:
                data = yaml.safe_load(content[4:end])

    if data:
        persona = data.get("persona", {})
        identity = persona.get("identity", "You are Otto.")
        context = data.get("context", {})
        rules = data.get("rules", {})

        system_parts = [
            identity,
            "You are running a scheduled job autonomously.",
            f"Context: {context}",
            f"Rules: {rules}",
            "Respond briefly. Take action if needed. Format for Telegram (HTML tags only).",
        ]
        system_prompt = "\n".join(str(p) for p in system_parts)
    else:
        system_prompt = "You are Otto, a helpful assistant running a scheduled job."

    backend = _get_backend(backend_name)
    result = backend.run_sync(prompt, system_prompt, get_workdir(), timeout, model=model)

    success = result.success
    output = result.output if success else (result.error or "")

    # Normalize notify semantics.
    if notify_mode in ("true", "yes", "1"):
        notify_mode = "always"
    if notify_mode in ("false", "no", "0"):
        notify_mode = "never"
    if notify_mode not in ("always", "on_error", "on_action", "never"):
        notify_mode = "on_error"

    # Update schedule state (durable JSON; brainfile stays config-only).
    mark_run(
        job_id,
        status="completed" if success else "failed",
        error=None if success else output[:500],
        one_shot=one_shot,
    )

    # Persist output for later review (avoid chat spam).
    output_path = None
    try:
        OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
        stamp = (
            str(scheduled_for).replace(":", "").replace("-", "").replace("T", "-")[:15]
            if scheduled_for
            else datetime.now().strftime("%Y%m%d-%H%M%S")
        )
        output_path = OUTPUTS_DIR / f"job-{job_id}-{stamp}.txt"
        content = [
            f"Job: {job_id}",
            f"Scheduled for: {scheduled_for}" if scheduled_for else "Scheduled for: (unknown)",
            f"Backend: {backend_name or backend.name}",
            f"Success: {success}",
            f"Duration: {result.duration_seconds:.2f}s",
            "",
            "=" * 50,
            "",
            result.output or "",
        ]
        if result.error:
            content.extend(["", f"Error: {result.error}"])
        output_path.write_text("\n".join(content), encoding="utf-8")
    except Exception:
        output_path = None

    # Notifications (via internal event queue, delivered conversationally by the bot).
    output_text = (result.output or "").strip()
    should_notify = False
    if notify_mode == "always":
        should_notify = True
    elif notify_mode == "on_error":
        should_notify = not success
    elif notify_mode == "on_action":
        should_notify = bool(output_text) or (not success)
    elif notify_mode == "never":
        should_notify = False

    if should_notify:
        output_summary = output_text[:800]
        if len(output_text) > 800:
            output_summary += "..."

        msg = InternalMessage.create(
            "scheduled_job",
            {
                "job_id": job_id,
                "scheduled_for": scheduled_for,
                "backend": backend_name or backend.name,
                "success": success,
                "duration_seconds": result.duration_seconds,
                "output_file": str(output_path) if output_path else None,
                "output_summary": output_summary or None,
                "error": (result.error[:800] if result.error else None),
                "chat_id": payload.get("chat_id"),
            },
        )
        queue_message(msg)

    if not success:
        raise RuntimeError(f"Scheduled job failed: {output[:500]}")

    return f"Scheduled job {job_id} completed: {output[:200]}"
