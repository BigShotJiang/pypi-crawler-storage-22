from __future__ import annotations

import logging

from otto.internal_messages import InternalMessage, queue_message
from otto.jobs.queue import JobQueue
from otto.paths import OUTPUTS_DIR

log = logging.getLogger(__name__)


def _get_upstream_context(queue: JobQueue, parent_agent_id: str) -> dict | None:
    """Get output from upstream pipeline stage to inject into downstream prompt."""
    if not parent_agent_id:
        return None

    # Get parent job info
    parent_job = queue.get_by_external_id(parent_agent_id, job_type="agent")
    if not parent_job:
        return None

    parent_payload = parent_job.get("payload", {})
    parent_task = parent_payload.get("task") or parent_payload.get("task_description") or ""
    parent_status = parent_job.get("status", "unknown")

    # Try to read parent's output file
    output_file = OUTPUTS_DIR / f"{parent_agent_id}.txt"
    output_content = None
    if output_file.exists():
        try:
            raw = output_file.read_text(encoding="utf-8")
            # Extract just the output portion (after the separator line)
            if "=" * 50 in raw:
                output_content = raw.split("=" * 50, 1)[-1].strip()
            else:
                output_content = raw.strip()
            # Limit size to avoid prompt bloat
            if len(output_content) > 4000:
                output_content = output_content[:4000] + "\n... (truncated)"
        except Exception:
            pass

    return {
        "parent_agent_id": parent_agent_id,
        "parent_task": parent_task,
        "parent_status": parent_status,
        "parent_output": output_content,
    }


def _handle_agent_notification(queue: JobQueue, meta: dict, *, success: bool) -> None:
    """Handle agent completion notification after job is marked complete."""
    agent_id = meta.get("agent_id")
    priority = meta.get("priority", "normal")
    pipeline_grace = meta.get("pipeline_grace", 0)

    if agent_id:
        # Check pipeline completion now that job status is accurate in DB
        is_complete, pipeline_members = queue.is_pipeline_complete(agent_id)

        if not is_complete:
            log.info(
                "Agent %s is part of an incomplete pipeline, deferring notification",
                agent_id,
            )
            return

        if len(pipeline_members) > 1:
            # Pipeline completed! Send a single event with all members.
            root_id = queue.get_pipeline_root(agent_id)
            log.info("Pipeline completed for root agent %s.", root_id)
            msg = InternalMessage.create(
                "pipeline_completed",
                {
                    "root_agent_id": root_id,
                    "final_agent_id": agent_id,
                    "members": [
                        {
                            "agent_id": m.get("external_id"),
                            "task": (m.get("payload") or {}).get("task")
                            or (m.get("payload") or {}).get("task_description"),
                            "status": m.get("status"),
                            "output_file": str(OUTPUTS_DIR / f"{m.get('external_id')}.txt")
                            if m.get("external_id")
                            else None,
                        }
                        for m in pipeline_members
                    ],
                    "all_success": all(m.get("status") == "completed" for m in pipeline_members),
                    "priority": priority,
                    "session_id": meta.get("session_id"),
                    "chat_id": meta.get("chat_id"),
                },
            )
            queue_message(msg)
        else:
            # Single agent completed - send normal notification.
            msg = InternalMessage.create(
                "agent_completed",
                {
                    "agent_id": agent_id,
                    "task": meta.get("task"),
                    "backend": meta.get("backend"),
                    "success": meta.get("success"),
                    "attempt": meta.get("attempt"),
                    "max_attempts": meta.get("max_attempts"),
                    "duration": meta.get("duration"),
                    "output_file": meta.get("output_file"),
                    "output_summary": meta.get("output_summary"),
                    "error": meta.get("error"),
                    "priority": priority,
                    "session_id": meta.get("session_id"),
                    "chat_id": meta.get("chat_id"),
                },
            )
            queue_message(msg, delay_seconds=pipeline_grace if pipeline_grace else None)
    else:
        # No agent_id - send basic notification without pipeline logic
        msg = InternalMessage.create(
            "agent_completed",
            {
                "agent_id": None,
                "task": meta.get("task"),
                "backend": meta.get("backend"),
                "success": meta.get("success"),
                "attempt": meta.get("attempt"),
                "max_attempts": meta.get("max_attempts"),
                "duration": meta.get("duration"),
                "output_file": meta.get("output_file"),
                "output_summary": meta.get("output_summary"),
                "error": meta.get("error"),
                "priority": priority,
                "session_id": meta.get("session_id"),
                "chat_id": meta.get("chat_id"),
            },
        )
        queue_message(msg)
