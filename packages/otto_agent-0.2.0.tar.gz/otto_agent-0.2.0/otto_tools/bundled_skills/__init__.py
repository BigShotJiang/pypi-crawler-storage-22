"""
Bundled skills that ship with Otto.

These are soft-patched into ~/.otto/skills/ on startup:
- Skills are copied only if they don't already exist
- User customizations are never overwritten
- New reference files can be added to existing skills

This allows Otto updates to ship new skills without breaking
existing user configurations.
"""
