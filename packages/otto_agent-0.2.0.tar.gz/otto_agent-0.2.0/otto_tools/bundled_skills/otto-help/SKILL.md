---
name: otto-help
description: Get help with Otto configuration, setup, and usage. Invoke when users ask how to configure Otto, use its features, or troubleshoot issues.
compatibility: "claude codex generic"
allowed-tools: Read Glob memory_recall memory_search_fts
metadata:
  version: "1.0.0"
  triggers:
    - "how do I configure"
    - "how do I set up"
    - "otto configuration"
    - "settings.yaml"
    - "how to use otto"
---

# Otto Help Skill

Help the user with Otto configuration, setup, or usage.

## Key Locations
- Config: ~/.otto/config/settings.yaml
- Secrets: ~/.otto/config/.env (NEVER share via chat)
- Brainfile: ~/.otto/brainfile.md
- Skills: ~/.otto/skills/

## Common Commands
- `/backend [name]` - Switch backend
- `/status` - System status
- `/new [topic]` - New session
- `otto doctor` - Health check
- `otto mcp list` - List MCP servers
- `otto skills list` - List available skills

## Configuration Hierarchy
1. ~/.otto/config/.env - Secrets (API keys, tokens)
2. ~/.otto/config/settings.yaml - Runtime settings
3. ~/.otto/brainfile.md - Persona and identity

Read references/ for detailed documentation.
