# Otto Configuration Reference

## File Locations

| File | Purpose |
|------|---------|
| `~/.otto/config/settings.yaml` | Runtime settings (non-secrets) |
| `~/.otto/config/.env` | Secrets (API keys, tokens) |
| `~/.otto/brainfile.md` | Persona, identity, context |

## settings.yaml Structure

```yaml
users: {}

backends:
  default: claude
  available:
    - claude
    - codex
    - generic

features:
  voice_to_text: false
  mcp_gateway: false

telegram:
  polling: true
```

## Backend Configuration

### Claude (default)
Uses Claude Code CLI with claude-agent-sdk.
```yaml
agent:
  active: claude
  backends:
    claude:
      enabled: true
      path: "~/.local/bin/claude"
      flags: ["--dangerously-skip-permissions"]
```

### Codex
Uses OpenAI Codex CLI.
```yaml
agent:
  active: codex
  backends:
    codex:
      enabled: true
      path: "~/.nvm/versions/node/v22.22.0/bin/codex"
      flags: ["--dangerously-bypass-approvals-and-sandbox"]
```

### Generic (LiteLLM)
Uses any OpenAI-compatible API via LiteLLM.
```yaml
agent:
  active: generic
  backends:
    generic:
      enabled: true
      model: "openrouter/anthropic/claude-3.5-sonnet"
      options:
        api_base: "http://localhost:8000/v1"  # optional
        api_key_env: "OPENROUTER_API_KEY"
        max_turns: 50
        timeout: 300
```

## Environment Variables (.env)

```bash
# Required
OTTO_TELEGRAM_BOT_TOKEN=123456789:ABC...

# Optional - depends on backend
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
OPENROUTER_API_KEY=sk-or-...
AZURE_API_KEY=...
```

## Commands

| Command | Description |
|---------|-------------|
| `otto init` | Interactive setup wizard |
| `otto doctor` | Health check |
| `otto config set KEY VALUE` | Update setting |
| `otto config get KEY` | Read setting |
| `/backend [name]` | Switch backend (in chat) |
