# MCP Gateway Reference

The MCP Gateway proxies Model Context Protocol (MCP) servers, providing:
- Tool discovery and invocation
- Policy-based access control
- Audit logging

## Configuration

In `~/.otto/config/settings.yaml`:

```yaml
gateway:
  servers:
    filesystem:
      command: npx
      args: ["-y", "@anthropic/mcp-filesystem-server", "/home/user/projects"]
      enabled: true

    exa:
      command: uvx
      args: ["mcp-exa"]
      env:
        EXA_API_KEY: "${EXA_API_KEY}"
      enabled: true
```

## Commands

```bash
# List configured servers
otto mcp list

# Test server connection
otto mcp test <server-name>

# View server tools
otto mcp tools <server-name>

# Start gateway
otto service start gateway
```

## Server Configuration

Each server can have:

| Field | Type | Description |
|-------|------|-------------|
| `command` | string | Executable (npx, uvx, python, etc.) |
| `args` | list | Command arguments |
| `env` | dict | Environment variables |
| `enabled` | bool | Whether to load on startup |

## Policy Control

Policies in `~/.otto/policies/`:

```yaml
# allow.yaml - always allow
tools:
  - "filesystem:read_file"
  - "filesystem:list_directory"

# deny.yaml - always deny
tools:
  - "filesystem:delete_file"

# prompt.yaml - ask user
tools:
  - "filesystem:write_file"
```

## Audit Logs

```bash
# View recent tool calls
otto audit list

# Search by server
otto audit search filesystem
```

## Adding Custom Servers

1. Find server on npm/pypi or write your own
2. Add to settings.yaml under `gateway.servers`
3. Test with `otto mcp test <name>`
4. Use tools in chat

## Troubleshooting

- **Server not loading**: Check `otto mcp test <name>` for errors
- **Tools not appearing**: Ensure `enabled: true` in config
- **Permission denied**: Check policies or run with `--allow-all`
