# Skills Reference

Skills are reusable prompt templates that extend Otto's capabilities.

## Location

Skills live in `~/.otto/skills/<skill-name>/`:

```
~/.otto/skills/
  otto-help/
    SKILL.md          # Main skill file (required)
    references/       # Supporting docs (optional)
      configuration.md
      mcp-gateway.md
```

## SKILL.md Format

```markdown
---
name: my-skill
description: Short description for discovery
compatibility: "claude codex generic"
allowed-tools: Read Glob Bash
metadata:
  version: "1.0.0"
  triggers:
    - "keyword one"
    - "keyword two"
---

# Skill Instructions

Instructions for the LLM when this skill is invoked.

## Context
- Important context
- Files to read

## Steps
1. Step one
2. Step two
```

## Commands

```bash
# List available skills
otto skills list

# Show skill details
otto skills show <name>

# Generate skill prompt XML
otto skills prompt
```

## Invoking Skills

In Telegram chat, type the skill name or trigger keywords.
Otto will detect and load the skill automatically.

## Creating Skills

1. Create directory: `~/.otto/skills/my-skill/`
2. Add `SKILL.md` with frontmatter
3. Add reference docs in `references/`
4. Test with `otto skills show my-skill`

## Built-in Skills

| Skill | Description |
|-------|-------------|
| `otto-help` | Otto configuration and usage help |

## Skill Frontmatter Fields

| Field | Required | Description |
|-------|----------|-------------|
| `name` | Yes | Unique skill identifier |
| `description` | Yes | Short description for discovery |
| `compatibility` | No | Space-separated backend names |
| `allowed-tools` | No | Tools this skill can use |
| `metadata.triggers` | No | Keywords that invoke the skill |

## Tips

- Keep skills focused on one task
- Include example outputs in references
- Use triggers for natural invocation
- Reference docs are injected into context
