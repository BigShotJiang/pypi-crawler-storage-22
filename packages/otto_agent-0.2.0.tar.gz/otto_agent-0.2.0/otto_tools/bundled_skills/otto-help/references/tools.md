# Otto Tools Reference

Otto exposes MCP tools that the LLM can invoke directly.

## Core Tools

### Agent Management
| Tool | Description |
|------|-------------|
| `agent_spawn` | Launch background agent for complex tasks |
| `agent_list` | List running/completed agents |
| `agent_output` | Get agent output by ID |

### Scheduling
| Tool | Description |
|------|-------------|
| `schedule_task` | Schedule delayed or recurring tasks |
| `schedule_list` | List scheduled tasks |
| `schedule_cancel` | Cancel a scheduled task |

### Pipelines
| Tool | Description |
|------|-------------|
| `pipeline_run` | Execute multi-step pipeline |
| `pipeline_status` | Check pipeline progress |
| `pipeline_cancel` | Cancel running pipeline |
| `pipeline_list` | List recent pipelines |

### Sessions
| Tool | Description |
|------|-------------|
| `session_list` | List conversation sessions |
| `session_switch` | Switch to different session |
| `session_new` | Create new session |

### Memory
| Tool | Description |
|------|-------------|
| `memory_recall` | Search file-based memory |
| `memory_remember` | Store information |
| `memory_list` | List memory files |
| `memory_forget` | Delete memory entry |
| `memory_search_fts` | Full-text search indexed memory |

### Notifications
| Tool | Description |
|------|-------------|
| `notify_send` | Send Telegram notification |
| `send_buttons` | Send interactive buttons |
| `send_file` | Send file to chat |
| `send_progress` | Update progress indicator |
| `edit_message` | Edit previously sent message |

### MCP Registry
| Tool | Description |
|------|-------------|
| `registry_search` | Search MCP server registry |
| `registry_install` | Install server from registry |
| `registry_info` | Get server details |
| `registry_remove` | Remove installed server |
| `registry_enable` | Enable disabled server |
| `registry_disable` | Disable server without removing |

### Audit
| Tool | Description |
|------|-------------|
| `audit_list` | List audit log entries |
| `audit_search` | Search audit logs |
| `audit_stats_tool` | Get audit statistics |

### Documentation
| Tool | Description |
|------|-------------|
| `context7__resolve-library-id` | Find library docs |
| `context7__query-docs` | Query library documentation |

## Usage Examples

### Spawn Background Agent
```
agent_spawn(
  prompt="Analyze the codebase and summarize the architecture",
  task_name="Architecture analysis",
  background=true
)
```

### Schedule Task
```
schedule_task(
  prompt="Check for new emails and summarize",
  cron="0 9 * * *",  # Daily at 9am
  name="Daily email summary"
)
```

### Search Memory
```
memory_search_fts(
  query="API authentication",
  limit=5
)
```

## Tool Priority

When solving problems, prefer Otto's native tools:
1. `agent_spawn` for complex multi-step tasks
2. `schedule_task` for delayed/recurring work
3. `memory_*` for knowledge persistence
4. `pipeline_run` for coordinated workflows
