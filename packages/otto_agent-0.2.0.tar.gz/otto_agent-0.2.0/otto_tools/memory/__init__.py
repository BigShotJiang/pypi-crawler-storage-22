"""
Memory operations for Otto.

Commands:
- remember: Store information in memory
- list: List all stored memories
- forget: Remove a memory file
"""

import json
import re
import sys
from datetime import datetime

import typer
from rich.console import Console

from ..config import get_memory_dir

app = typer.Typer(
    name="memory",
    help="Store and retrieve information from Otto's memory.",
    no_args_is_help=True,
)

console = Console()
err_console = Console(stderr=True)

CATEGORIES = ["projects", "facts", "contexts"]


def sanitize_topic(topic: str) -> str:
    """Sanitize a topic name for use as a filename."""
    safe = topic.lower()
    safe = re.sub(r"[^a-z0-9-]", "-", safe)
    safe = re.sub(r"-+", "-", safe)
    return safe.strip("-")


def search_memory(query: str, limit: int = 10) -> list[dict]:
    """Search memory files for matching content."""
    memory_dir = get_memory_dir()
    results = []

    for category in CATEGORIES:
        cat_dir = memory_dir / category
        if not cat_dir.exists():
            continue

        for file in cat_dir.glob("*.md"):
            try:
                content = file.read_text()
                matches = []
                for i, line in enumerate(content.split("\n"), 1):
                    if query.lower() in line.lower():
                        matches.append({"line": i, "text": line.strip()})

                if matches:
                    results.append(
                        {
                            "file": f"{category}/{file.name}",
                            "path": str(file),
                            "matches": matches[:5],  # Limit matches per file
                        }
                    )
            except Exception:
                continue

    return results[:limit]


@app.command()
def remember(
    category: str = typer.Argument(..., help="Category: projects, facts, or contexts"),
    topic: str = typer.Argument(..., help="Topic name for the memory"),
    content: list[str] | None = typer.Argument(None, help="Content to store"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    Store information in Otto's memory.

    Content can be provided as arguments or piped via stdin.

    Examples:
        otto memory remember facts user-prefs "Prefers dark mode"
        echo "API key in 1password" | otto memory remember facts secrets-location
    """
    if category not in CATEGORIES:
        err_console.print(f"[red]Error: Invalid category '{category}'[/red]")
        err_console.print(f"Valid categories: {', '.join(CATEGORIES)}")
        raise typer.Exit(1)

    # Get content from args or stdin
    if content:
        content_str = " ".join(content)
    elif not sys.stdin.isatty():
        content_str = sys.stdin.read().strip()
    else:
        err_console.print("[red]Error: No content provided[/red]")
        raise typer.Exit(1)

    if not content_str:
        err_console.print("[red]Error: Empty content[/red]")
        raise typer.Exit(1)

    memory_dir = get_memory_dir()
    cat_dir = memory_dir / category
    cat_dir.mkdir(parents=True, exist_ok=True)

    safe_topic = sanitize_topic(topic)
    file_path = cat_dir / f"{safe_topic}.md"

    timestamp = datetime.now().isoformat()

    if file_path.exists():
        # Append to existing
        with open(file_path, "a") as f:
            f.write(f"\n\n---\n_Updated: {timestamp}_\n\n{content_str}")
        action = "Updated"
    else:
        # Create new
        with open(file_path, "w") as f:
            f.write(f"# {topic}\n\n_Created: {timestamp}_\n\n{content_str}\n")
        action = "Created"

    if json_output:
        output = {
            "action": action.lower(),
            "category": category,
            "topic": topic,
            "file": str(file_path),
        }
        print(json.dumps(output, indent=2))
    else:
        console.print(f"[green]{action}:[/green] {file_path}")


@app.command("list")
def list_memories(
    category: str | None = typer.Argument(None, help="Category to list (optional)"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    List all stored memories.

    Optionally filter by category (projects, facts, contexts).
    """
    memory_dir = get_memory_dir()

    if category and category not in CATEGORIES:
        err_console.print(f"[red]Error: Invalid category '{category}'[/red]")
        err_console.print(f"Valid categories: {', '.join(CATEGORIES)}")
        raise typer.Exit(1)

    categories_to_list = [category] if category else CATEGORIES
    result = {}

    for cat in categories_to_list:
        cat_dir = memory_dir / cat
        if not cat_dir.exists():
            continue

        files = []
        for file in sorted(cat_dir.glob("*.md")):
            stat = file.stat()
            files.append(
                {
                    "name": file.stem,
                    "size": stat.st_size,
                    "modified": int(stat.st_mtime),
                }
            )

        if files:
            result[cat] = files

    if json_output:
        print(json.dumps(result, indent=2))
    else:
        if not result:
            console.print("No memories found.")
            return

        for cat, files in result.items():
            console.print(f"[bold cyan]{cat}/[/bold cyan]")
            for f in files:
                console.print(f"  - {f['name']} ({f['size']} bytes)")
            console.print()


@app.command()
def forget(
    category: str = typer.Argument(..., help="Category: projects, facts, or contexts"),
    topic: str = typer.Argument(..., help="Topic name to forget"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    Remove a memory file.

    Use with caution - this permanently deletes the memory.
    """
    if category not in CATEGORIES:
        err_console.print(f"[red]Error: Invalid category '{category}'[/red]")
        raise typer.Exit(1)

    memory_dir = get_memory_dir()
    safe_topic = sanitize_topic(topic)
    file_path = memory_dir / category / f"{safe_topic}.md"

    if not file_path.exists():
        if json_output:
            print(json.dumps({"error": "not_found", "file": str(file_path)}))
        else:
            err_console.print(f"[red]Error: Memory not found: {file_path}[/red]")
        raise typer.Exit(1)

    if not force and not json_output:
        confirm = typer.confirm(f"Delete {file_path}?")
        if not confirm:
            console.print("Cancelled.")
            raise typer.Exit(0)

    file_path.unlink()

    if json_output:
        print(json.dumps({"deleted": str(file_path)}))
    else:
        console.print(f"[green]Deleted:[/green] {file_path}")


@app.command()
def index(
    force: bool = typer.Option(False, "--force", "-f", help="Force re-index all"),
    include_docs: bool = typer.Option(True, "--docs/--no-docs", help="Include Otto docs"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    Index memory files for FTS search.

    Indexes knowledge, projects, sessions, and optionally Otto's own documentation.
    This enables memory_search_fts to find relevant information.
    """
    from otto.memory import index_all, index_otto_docs

    results = {"memory": {}, "docs": 0}

    # Index user memory
    results["memory"] = index_all(force=force)

    # Index Otto documentation
    if include_docs:
        results["docs"] = index_otto_docs(force=force)

    total = results["memory"].get("total", 0) + results["docs"]

    if json_output:
        print(json.dumps(results, indent=2))
    else:
        console.print("[bold]Memory Index Results:[/bold]")
        console.print(f"  Knowledge: {results['memory'].get('knowledge', 0)} chunks")
        console.print(f"  Projects: {results['memory'].get('projects', 0)} chunks")
        console.print(f"  Sessions: {results['memory'].get('sessions', 0)} chunks")
        if include_docs:
            console.print(f"  Otto Docs: {results['docs']} chunks")
        console.print(f"\n[green]Total: {total} chunks indexed[/green]")


@app.command()
def search_fts(
    query: list[str] = typer.Argument(..., help="Search query"),
    limit: int = typer.Option(5, "--limit", "-n", help="Maximum results"),
    source_type: str | None = typer.Option(None, "--type", "-t", help="Filter by type"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    Search memory using full-text search (FTS5).

    This searches the indexed memory database for relevant content.
    Run 'otto memory index' first to index content.
    """
    from otto.memory import search

    query_str = " ".join(query)
    source_types = [source_type] if source_type else None

    results = search(query_str, limit=limit, source_types=source_types)

    if json_output:
        print(json.dumps({"query": query_str, "results": results}, indent=2))
    else:
        if not results:
            console.print(f"No results found for: {query_str}")
            return

        console.print(f"[bold]Search results for:[/bold] {query_str}\n")

        for r in results:
            source_label = f"{r['source_type']}/{r['source_id']}"
            console.print(f"[cyan]━━━ {source_label} ━━━[/cyan]")
            # Truncate long content
            content = r["content"][:500] + "..." if len(r["content"]) > 500 else r["content"]
            console.print(content)
            console.print()
