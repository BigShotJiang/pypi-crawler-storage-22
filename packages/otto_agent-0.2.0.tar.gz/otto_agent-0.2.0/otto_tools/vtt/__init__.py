"""
Voice-to-Text (VTT) module for Otto.

Uses OpenAI Whisper via `faster-whisper` for fast, reliable transcription.
Lazy-loads model on first use (size depends on model).

Commands:
- status: Show VTT configuration and model status
- enable: Enable VTT feature
- disable: Disable VTT feature
- transcribe: Transcribe an audio file
- download: Download the configured model without transcribing
"""

import json
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.markup import escape

from otto import config as otto_config
from otto.paths import DATA_DIR

app = typer.Typer(
    name="vtt",
    help="Voice-to-Text transcription using faster-whisper (OpenAI Whisper).",
    no_args_is_help=True,
)

console = Console()
err_console = Console(stderr=True)

# VTT configuration is stored in the central settings.yaml.
VTT_CONFIG_FILE = otto_config.SETTINGS_FILE

# Model cache directory
VTT_MODEL_DIR = DATA_DIR / "vtt_models"

# Default config (used for fallback/reference)
DEFAULT_CONFIG = {
    "enabled": False,
    "model": "base",
    "device": "auto",
    "compute_type": "auto",
    "language": "auto",
    "beam_size": 1,
    "vad_filter": True,
    "downloaded": False,
}


def _is_legacy_model_id(model: str) -> bool:
    """Check if model ID is a legacy format that needs migration."""
    value = (model or "").strip().lower()
    if not value:
        return False
    # Legacy model IDs that are no longer supported
    return value.startswith("nvidia/")


def load_config() -> dict:
    """Load VTT configuration from central config."""
    config = otto_config.get_vtt_config()
    # Handle legacy model migration
    model = str(config.get("model") or "")
    if _is_legacy_model_id(model):
        otto_config.set_setting("vtt.model", DEFAULT_CONFIG["model"])
        otto_config.set_setting("vtt.downloaded", False)
        config = otto_config.get_vtt_config()
    return {**DEFAULT_CONFIG, **config}


def save_config(config: dict) -> None:
    """Save VTT configuration to central config."""
    for key, value in config.items():
        otto_config.set_setting(f"vtt.{key}", value)


def is_enabled() -> bool:
    """Check if VTT is enabled."""
    return load_config().get("enabled", False)


def is_model_ready() -> bool:
    """Check if model is downloaded and ready."""
    config = load_config()
    return config.get("downloaded", False) and config.get("enabled", False)


class Transcriber:
    """Lazy-loading faster-whisper transcriber."""

    _instance: Optional["Transcriber"] = None
    _model = None

    def _configure_model_caches(self) -> None:
        """Configure cache dirs to keep downloads under ~/.otto."""
        import os

        VTT_MODEL_DIR.mkdir(parents=True, exist_ok=True)

        # Hugging Face cache (used by faster-whisper for model downloads).
        hf_home = VTT_MODEL_DIR / "huggingface"
        hf_home.mkdir(parents=True, exist_ok=True)
        os.environ.setdefault("HF_HOME", str(hf_home))

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def _cuda_device_count(self) -> int:
        try:
            import ctranslate2  # type: ignore

            fn = getattr(ctranslate2, "get_cuda_device_count", None)
            if callable(fn):
                return int(fn())
        except Exception:
            pass
        return 0

    def _resolve_device(self, device: str) -> str:
        if device != "auto":
            return device
        return "cuda" if self._cuda_device_count() > 0 else "cpu"

    def _resolve_compute_type(self, compute_type: str, device: str) -> str:
        if compute_type != "auto":
            return compute_type
        return "float16" if device == "cuda" else "int8"

    def _load_model(self):
        """Load the Whisper model (downloads if needed)."""
        if self._model is not None:
            return

        config = load_config()
        model_name = (config.get("model") or DEFAULT_CONFIG["model"]).strip()
        device = self._resolve_device((config.get("device") or "auto").strip())
        compute_type = self._resolve_compute_type(
            (config.get("compute_type") or "auto").strip(), device
        )

        self._configure_model_caches()

        try:
            from faster_whisper import WhisperModel  # type: ignore
        except ImportError:
            raise RuntimeError(
                "faster-whisper not available.\n"
                "This is a core dependency and should be installed automatically.\n"
                "Try reinstalling otto: uv pip install -U otto-agent"
            )

        download_root = VTT_MODEL_DIR / "whisper"
        download_root.mkdir(parents=True, exist_ok=True)

        console.print(f"[dim]Loading Whisper ({model_name}) on {device} ({compute_type})...[/dim]")

        self._model = WhisperModel(
            model_name,
            device=device,
            compute_type=compute_type,
            download_root=str(download_root),
        )

        # Mark as downloaded
        config["downloaded"] = True
        save_config(config)

        console.print("[green]Model loaded.[/green]")

    def transcribe(self, audio_path: Path | str) -> str:
        """Transcribe an audio file."""
        config = load_config()
        if not config.get("enabled"):
            raise RuntimeError("VTT is disabled. Enable with: otto vtt enable")

        self._load_model()

        audio_path = Path(audio_path)
        if not audio_path.exists():
            raise FileNotFoundError(f"Audio file not found: {audio_path}")

        audio_path = self._prepare_audio(audio_path)

        language = (config.get("language") or "auto").strip().lower()
        if language in ("", "auto", "none"):
            language = None

        beam_size = int(config.get("beam_size") or DEFAULT_CONFIG["beam_size"])
        vad_filter = bool(config.get("vad_filter", DEFAULT_CONFIG["vad_filter"]))

        segments, _info = self._model.transcribe(
            str(audio_path),
            language=language,
            beam_size=beam_size,
            vad_filter=vad_filter,
        )

        text = "".join(s.text for s in segments).strip()
        return text

    def _prepare_audio(self, audio_path: Path) -> Path:
        """Ensure audio is a WAV file for consistent decoding."""
        if audio_path.suffix.lower() == ".wav":
            return audio_path

        import shutil
        import subprocess

        ffmpeg_path = shutil.which("ffmpeg") or shutil.which("avconv")
        if not ffmpeg_path:
            raise RuntimeError(
                "Audio conversion requires ffmpeg. Install it and retry.\n"
                "Ubuntu/Debian: sudo apt-get install -y ffmpeg\n"
                "macOS: brew install ffmpeg"
            )

        wav_path = audio_path.with_suffix(".wav")
        if wav_path.exists():
            return wav_path

        result = subprocess.run(
            [
                ffmpeg_path,
                "-y",
                "-i",
                str(audio_path),
                "-ac",
                "1",
                "-ar",
                "16000",
                "-acodec",
                "pcm_s16le",
                str(wav_path),
            ],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            stderr = (result.stderr or "").strip()
            tail = "\n".join(stderr.splitlines()[-10:]) if stderr else ""
            raise RuntimeError(f"ffmpeg conversion failed.\n{tail}".strip())

        return wav_path


def get_transcriber() -> Transcriber:
    """Get the singleton transcriber instance."""
    return Transcriber()


def download_model(auto_install: bool = True) -> bool:
    """Download the Whisper model.

    Args:
        auto_install: Ignored (kept for API compatibility)

    Returns:
        True if model is ready, False otherwise

    Raises:
        RuntimeError: If model download fails
    """
    # Sanity check - faster-whisper should always be available now
    if not _ensure_faster_whisper_installed():
        raise RuntimeError(
            "faster-whisper not available.\n"
            "Try reinstalling: uv pip install -U otto-agent"
        )

    # Enable VTT if not already
    config = load_config()
    if not config.get("enabled"):
        config["enabled"] = True
        save_config(config)

    # Load/download the model
    transcriber = get_transcriber()
    transcriber._load_model()

    return True


async def transcribe_async(audio_path: Path | str) -> str:
    """Async wrapper for transcription (runs in thread pool)."""
    import asyncio

    loop = asyncio.get_running_loop()
    transcriber = get_transcriber()

    return await loop.run_in_executor(None, transcriber.transcribe, audio_path)


@app.command()
def status(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Show VTT configuration and model status."""
    config = load_config()

    # Check if faster-whisper is installed
    import importlib.util

    faster_whisper_installed = importlib.util.find_spec("faster_whisper") is not None

    # Check CUDA availability via ctranslate2 (used by faster-whisper)
    cuda_device_count = 0
    try:
        import ctranslate2  # type: ignore

        fn = getattr(ctranslate2, "get_cuda_device_count", None)
        if callable(fn):
            cuda_device_count = int(fn())
    except Exception:
        cuda_device_count = 0

    # Check ffmpeg availability (required for converting Telegram voice .ogg to wav)
    import shutil

    ffmpeg_path = shutil.which("ffmpeg") or shutil.which("avconv")

    status_data = {
        "enabled": config.get("enabled", False),
        "model": config.get("model", DEFAULT_CONFIG["model"]),
        "device": config.get("device", "auto"),
        "compute_type": config.get("compute_type", DEFAULT_CONFIG["compute_type"]),
        "language": config.get("language", DEFAULT_CONFIG["language"]),
        "beam_size": config.get("beam_size", DEFAULT_CONFIG["beam_size"]),
        "vad_filter": config.get("vad_filter", DEFAULT_CONFIG["vad_filter"]),
        "model_downloaded": config.get("downloaded", False),
        "faster_whisper_installed": faster_whisper_installed,
        "cuda_device_count": cuda_device_count,
        "ffmpeg_installed": bool(ffmpeg_path),
        "ffmpeg_path": ffmpeg_path,
        "config_file": str(VTT_CONFIG_FILE),
        "model_cache": str(VTT_MODEL_DIR),
    }

    if json_output:
        print(json.dumps(status_data, indent=2))
        return

    enabled_str = (
        "[green]enabled[/green]" if status_data["enabled"] else "[yellow]disabled[/yellow]"
    )
    console.print("[bold]Voice-to-Text Status[/bold]\n")
    console.print(f"Status: {enabled_str}")
    console.print(f"Model: {status_data['model']}")
    console.print(
        f"Device: {status_data['device']} (CUDA devices: {status_data['cuda_device_count']})"
    )
    console.print(f"Compute type: {status_data['compute_type']}")
    console.print(f"Language: {status_data['language']}")
    console.print(f"Model downloaded: {'✓' if status_data['model_downloaded'] else '✗'}")
    console.print(f"faster-whisper installed: {'✓' if faster_whisper_installed else '✗'}")
    console.print(f"ffmpeg installed: {'✓' if status_data['ffmpeg_installed'] else '✗'}")
    console.print(f"\nConfig: {status_data['config_file']}")
    console.print(f"Model cache: {status_data['model_cache']}")

    if not faster_whisper_installed:
        console.print()
        console.print("faster-whisper should be installed automatically.", style="yellow", markup=False)
        console.print("Try: uv pip install -U otto-agent", style="dim", markup=False)


@app.command()
def enable(
    download_now: bool = typer.Option(False, "--download", "-d", help="Download model immediately"),
    yes: bool = typer.Option(
        False, "--yes", "-y", help="Auto-install dependencies without prompting"
    ),
):
    """Enable VTT feature."""
    config = load_config()
    config["enabled"] = True
    save_config(config)

    console.print("[green]VTT enabled.[/green]")

    if download_now:
        # Ensure faster-whisper is installed first
        if not _ensure_faster_whisper_installed(auto_install=yes):
            raise typer.Exit(1)

        console.print("\n[dim]Downloading model (one-time)...[/dim]")
        try:
            transcriber = get_transcriber()
            transcriber._load_model()
            console.print("[green]Model ready.[/green]")
        except Exception as e:
            err_console.print(f"[red]Download failed: {escape(str(e))}[/red]")
            raise typer.Exit(1)
    elif not config.get("downloaded"):
        console.print("[dim]Model will download on first use.[/dim]")


@app.command()
def disable():
    """Disable VTT feature."""
    config = load_config()
    config["enabled"] = False
    save_config(config)
    console.print("[yellow]VTT disabled.[/yellow]")


@app.command()
def transcribe(
    audio_file: Path = typer.Argument(..., help="Audio file to transcribe"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Transcribe an audio file."""
    config = load_config()

    if not config.get("enabled"):
        err_console.print("[red]VTT is disabled.[/red]")
        err_console.print("Enable with: otto vtt enable")
        raise typer.Exit(1)

    if not audio_file.exists():
        err_console.print(f"[red]File not found: {audio_file}[/red]")
        raise typer.Exit(1)

    try:
        transcriber = get_transcriber()
        text = transcriber.transcribe(audio_file)

        if json_output:
            print(
                json.dumps(
                    {
                        "success": True,
                        "file": str(audio_file),
                        "text": text,
                    },
                    indent=2,
                )
            )
        else:
            console.print(text)

    except Exception as e:
        if json_output:
            print(
                json.dumps(
                    {
                        "success": False,
                        "file": str(audio_file),
                        "error": str(e),
                    },
                    indent=2,
                )
            )
        else:
            err_console.print(f"[red]Transcription failed: {escape(str(e))}[/red]")
        raise typer.Exit(1)


def _ensure_faster_whisper_installed(auto_install: bool = False) -> bool:
    """Check if faster-whisper is available.

    Since faster-whisper is now a core dependency, this should always return True.
    Kept for backwards compatibility with existing code that calls it.

    Args:
        auto_install: Ignored (kept for API compatibility)

    Returns:
        True if faster-whisper is importable, False otherwise.
    """
    try:
        import importlib
        importlib.import_module("faster_whisper")
        return True
    except ImportError:
        err_console.print("[red]faster-whisper not available.[/red]")
        err_console.print("[dim]This is a core dependency - try reinstalling otto:[/dim]")
        err_console.print("  uv pip install -U otto-agent")
        return False


@app.command()
def download(
    yes: bool = typer.Option(
        False, "--yes", "-y", help="Auto-install dependencies without prompting"
    ),
):
    """Download the Whisper model without transcribing."""
    config = load_config()

    if not config.get("enabled"):
        err_console.print("[yellow]Enabling VTT first...[/yellow]")
        config["enabled"] = True
        save_config(config)

    # Ensure faster-whisper is installed first
    if not _ensure_faster_whisper_installed(auto_install=yes):
        raise typer.Exit(1)

    console.print(f"[dim]Downloading {config.get('model', DEFAULT_CONFIG['model'])}...[/dim]")
    console.print("[dim]This may take a few minutes (one-time).[/dim]\n")

    try:
        transcriber = get_transcriber()
        transcriber._load_model()
        console.print("[green]✓ Model downloaded and ready.[/green]")
    except Exception as e:
        err_console.print(f"[red]Download failed: {escape(str(e))}[/red]")
        raise typer.Exit(1)
