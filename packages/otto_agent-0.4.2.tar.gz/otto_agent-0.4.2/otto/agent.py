from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

import litellm

from otto.auth import AuthStorage
from otto.auth.base import OAuthProvider
from otto.auth.registry import (
    get_litellm_overrides,
    get_oauth_provider,
    is_oauth_model,
    needs_custom_provider,
)
from otto.log import get_logger

log = get_logger("otto.agent")

litellm.suppress_debug_info = True
for _logger_name in ("litellm", "LiteLLM"):
    logging.getLogger(_logger_name).setLevel(logging.CRITICAL)


@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    parameters: dict
    execute: Callable[..., Awaitable[str]]


@dataclass(frozen=True)
class Turn:
    text: str | None
    tool_calls: list[dict]
    usage: dict


@dataclass(frozen=True)
class AgentResult:
    text: str
    turns: list[Turn]
    total_usage: dict


async def run(
    model: str,
    system: str,
    messages: list[dict],
    tools: list[Tool],
    *,
    auth_storage: AuthStorage | None = None,
    max_turns: int = 50,
    on_text: Callable[[str], None] | None = None,
    on_tool_start: Callable[[str, dict], None] | None = None,
    on_tool_end: Callable[[str, str], None] | None = None,
) -> AgentResult:
    tool_schemas = [_tool_to_schema(tool) for tool in tools]
    tools_by_name = {tool.name: tool for tool in tools}

    turns: list[Turn] = []
    total_prompt_tokens = 0
    total_completion_tokens = 0
    total_cost = 0.0
    final_text = ""

    if max_turns <= 0:
        return AgentResult(
            text=final_text,
            turns=turns,
            total_usage={
                "prompt_tokens": total_prompt_tokens,
                "completion_tokens": total_completion_tokens,
                "cost": total_cost,
            },
        )

    oauth_provider: OAuthProvider | None = None
    oauth_overrides: dict[str, Any] | None = None
    if auth_storage is not None:
        try:
            oauth_overrides = await _get_oauth_overrides(model, auth_storage)
        except Exception as exc:
            log.error("oauth override setup failed", model=model, error=str(exc))
            raise

        if oauth_overrides is not None:
            log.info("oauth litellm overrides selected", model=model, keys=list(oauth_overrides))
        elif needs_custom_provider(model) and is_oauth_model(model, auth_storage):
            try:
                oauth_provider = await get_oauth_provider(model, auth_storage=auth_storage)
            except Exception as exc:
                log.error("oauth provider setup failed", model=model, error=str(exc))
                raise
            log.info(
                "oauth provider selected",
                model=model,
                provider=getattr(oauth_provider, "provider_name", "unknown"),
            )

    for turn_index in range(max_turns):
        try:
            if oauth_provider is not None:
                effective_system = system
                system_prompt_prefix = getattr(oauth_provider, "system_prompt_prefix", None)
                if system_prompt_prefix:
                    effective_system = f"{system_prompt_prefix.strip()}\n\n{system}"
                messages = _trim_to_context_window(model, effective_system, messages)
                log.info("oauth request", model=model, turn=turn_index, messages=len(messages))
                try:
                    oauth_response_stream = oauth_provider.stream_completion(
                        model=model,
                        messages=_messages_for_request(effective_system, messages),
                        tools=tool_schemas,
                        tool_choice="auto" if tool_schemas else None,
                        system_prompt=effective_system,
                    )
                    if isinstance(oauth_response_stream, Awaitable):
                        oauth_response_stream = await oauth_response_stream
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    log.error(
                        "oauth request failed", model=model, turn=turn_index, error=str(exc)
                    )
                    raise
                turn_text, streamed_tool_calls, usage_obj = await _consume_stream(
                    oauth_response_stream, on_text
                )
            else:
                messages = _trim_to_context_window(model, system, messages)
                log.info("llm request", model=model, turn=turn_index, messages=len(messages))
                try:
                    completion_kwargs: dict[str, Any] = {
                        "model": model,
                        "messages": _messages_for_request(system, messages),
                        "tools": tool_schemas,
                        "stream": True,
                        "num_retries": 3,
                        "request_timeout": 120,
                        "extra_headers": {"X-Title": "Otto"},
                    }
                    if oauth_overrides is not None:
                        completion_kwargs.update(
                            {
                                key: value
                                for key, value in oauth_overrides.items()
                                if key != "extra_headers"
                            }
                        )
                        override_headers = oauth_overrides.get("extra_headers")
                        if isinstance(override_headers, dict):
                            completion_kwargs["extra_headers"] = {
                                **completion_kwargs["extra_headers"],
                                **override_headers,
                            }

                    response_stream = await litellm.acompletion(**completion_kwargs)
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    log.error(
                        "llm request failed", model=model, turn=turn_index, error=str(exc)
                    )
                    raise

                turn_text, streamed_tool_calls, usage_obj = await _consume_stream(
                    response_stream, on_text
                )
            usage = _normalize_usage(usage_obj)

            total_prompt_tokens += usage["prompt_tokens"]
            total_completion_tokens += usage["completion_tokens"]
            total_cost += _completion_cost(
                model=model,
                prompt_tokens=usage["prompt_tokens"],
                completion_tokens=usage["completion_tokens"],
            )

            normalized_calls = _normalize_tool_calls(streamed_tool_calls, turn_index)
            log.info(
                "llm response",
                model=model,
                turn=turn_index,
                prompt_tokens=usage["prompt_tokens"],
                completion_tokens=usage["completion_tokens"],
                tool_calls=len(normalized_calls),
                has_text=turn_text is not None,
            )

            if not normalized_calls:
                turns.append(Turn(text=turn_text, tool_calls=[], usage=usage))
                final_text = turn_text or final_text
                break

            assistant_tool_calls = [
                {
                    "id": call["id"],
                    "type": "function",
                    "function": {"name": call["name"], "arguments": call["arguments"]},
                }
                for call in normalized_calls
            ]
            assistant_message: dict[str, Any] = {
                "role": "assistant",
                "tool_calls": assistant_tool_calls,
            }
            if turn_text is not None:
                assistant_message["content"] = turn_text
            messages.append(assistant_message)

            executed_calls = await asyncio.gather(
                *[
                    _execute_tool_call(
                        call=call,
                        tools_by_name=tools_by_name,
                        on_tool_start=on_tool_start,
                        on_tool_end=on_tool_end,
                    )
                    for call in normalized_calls
                ]
            )

            turn_tool_calls: list[dict] = []
            for executed in executed_calls:
                turn_tool_calls.append(
                    {
                        "name": executed["name"],
                        "args": executed["args"],
                        "result": executed["result"],
                    }
                )
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": executed["id"],
                        "name": executed["name"],
                        "content": executed["result"],
                    }
                )

            turns.append(Turn(text=turn_text, tool_calls=turn_tool_calls, usage=usage))
            final_text = turn_text or final_text
        except asyncio.CancelledError:
            log.info("agent cancelled", turn=turn_index)
            raise

    return AgentResult(
        text=final_text,
        turns=turns,
        total_usage={
            "prompt_tokens": total_prompt_tokens,
            "completion_tokens": total_completion_tokens,
            "cost": total_cost,
        },
    )


def _tool_to_schema(tool: Tool) -> dict[str, dict[str, Any] | str]:
    return {
        "type": "function",
        "function": {
            "name": tool.name,
            "description": tool.description,
            "parameters": tool.parameters,
        },
    }


async def _get_oauth_overrides(
    model: str,
    auth_storage: AuthStorage,
) -> dict[str, Any] | None:
    if needs_custom_provider(model):
        return None
    return await get_litellm_overrides(model, auth_storage)


def _messages_for_request(system: str, messages: list[dict]) -> list[dict]:
    if not system:
        return list(messages)
    return [{"role": "system", "content": system}, *messages]


def _trim_to_context_window(model: str, system: str, messages: list[dict]) -> list[dict]:
    min_turn_messages = 8

    try:
        model_info = litellm.get_model_info(model)
        max_input_tokens = int((model_info or {}).get("max_input_tokens") or 0)
    except Exception:
        return messages

    if max_input_tokens <= 0:
        return messages

    threshold = max_input_tokens * 0.8
    request_messages = _messages_for_request(system, messages)
    try:
        current_tokens = int(litellm.token_counter(model=model, messages=request_messages) or 0)
    except Exception:
        return messages

    if current_tokens <= threshold:
        return messages

    original_tokens = current_tokens
    dropped_messages = 0

    while current_tokens > threshold:
        turn_indices = [
            idx
            for idx, message in enumerate(messages)
            if message.get("role") in {"user", "assistant"}
        ]
        if len(turn_indices) - 2 < min_turn_messages:
            break

        next_turn_index = turn_indices[2]
        dropped_messages += next_turn_index
        del messages[:next_turn_index]

        try:
            current_tokens = int(
                litellm.token_counter(
                    model=model,
                    messages=_messages_for_request(system, messages),
                )
                or 0
            )
        except Exception:
            return messages

    if dropped_messages > 0:
        log.warning(
            "context trimmed",
            model=model,
            original_tokens=original_tokens,
            trimmed_tokens=current_tokens,
            messages_dropped=dropped_messages,
        )

    return messages


async def _consume_stream(
    stream: Any, on_text: Callable[[str], None] | None
) -> tuple[str | None, list[dict[str, str]], Any]:
    text_parts: list[str] = []
    tool_calls: list[dict[str, str]] = []
    usage_obj: Any = None

    async for chunk in stream:
        chunk_usage = getattr(chunk, "usage", None)
        if chunk_usage is not None:
            usage_obj = chunk_usage

        choices = getattr(chunk, "choices", None)
        if not choices:
            continue

        delta = getattr(choices[0], "delta", None)
        if delta is None:
            continue

        content = getattr(delta, "content", None)
        if content:
            text_parts.append(content)
            if on_text is not None:
                on_text(content)

        delta_tool_calls = getattr(delta, "tool_calls", None) or []
        for delta_tool_call in delta_tool_calls:
            index = getattr(delta_tool_call, "index", None)
            if index is None or index < 0:
                continue

            while len(tool_calls) <= index:
                tool_calls.append({"id": "", "name": "", "arguments": ""})

            current = tool_calls[index]
            tool_call_id = getattr(delta_tool_call, "id", None)
            if tool_call_id:
                current["id"] = tool_call_id

            function = getattr(delta_tool_call, "function", None)
            if function is None:
                continue

            function_name = getattr(function, "name", None)
            if function_name:
                current["name"] = function_name

            function_arguments = getattr(function, "arguments", None)
            if function_arguments:
                current["arguments"] += function_arguments

    text = "".join(text_parts)
    return (text if text else None), tool_calls, usage_obj


def _normalize_tool_calls(
    tool_calls: list[dict[str, str]], turn_index: int
) -> list[dict[str, str]]:
    normalized: list[dict[str, str]] = []
    for index, tool_call in enumerate(tool_calls):
        name = tool_call.get("name", "").strip()
        if not name:
            log.warning("skipping tool call with empty name", turn=turn_index, index=index)
            continue
        normalized.append(
            {
                "id": tool_call.get("id") or f"tool_call_{turn_index}_{index}",
                "name": name,
                "arguments": tool_call.get("arguments", ""),
            }
        )
    return normalized


async def _execute_tool_call(
    *,
    call: dict[str, str],
    tools_by_name: dict[str, Tool],
    on_tool_start: Callable[[str, dict], None] | None,
    on_tool_end: Callable[[str, str], None] | None,
) -> dict[str, Any]:
    tool_name = call["name"]

    try:
        parsed_args = _parse_tool_arguments(call["arguments"])
    except ValueError as error:
        parsed_args = {}
        result = str(error)
        if on_tool_start is not None:
            on_tool_start(tool_name, parsed_args)
        if on_tool_end is not None:
            on_tool_end(tool_name, result)
        return {"id": call["id"], "name": tool_name, "args": parsed_args, "result": result}

    if on_tool_start is not None:
        on_tool_start(tool_name, parsed_args)

    tool = tools_by_name.get(tool_name)
    if tool is None:
        log.warning("unknown tool", tool=tool_name)
        result = f"Unknown tool name: {tool_name}"
        if on_tool_end is not None:
            on_tool_end(tool_name, result)
        return {"id": call["id"], "name": tool_name, "args": parsed_args, "result": result}

    log.info("tool executing", tool=tool_name, **_log_args(parsed_args))
    try:
        execution_result = await tool.execute(**parsed_args)
        result = str(execution_result)
    except TypeError as error:
        error_msg = str(error)
        if "required" in error_msg and "argument" in error_msg:
            log.warning("tool missing required args", tool=tool_name, error=error_msg)
            required = _get_required_params(tool)
            result = (
                f"Error: missing required arguments for '{tool_name}'. "
                f"Required parameters: {required}. "
                f"You provided: {list(parsed_args.keys()) or '(none)'}. "
                f"Please retry with the required arguments."
            )
        else:
            log.error("tool failed", tool=tool_name, error=error_msg)
            result = f"Tool execution error: {error}"
    except Exception as error:  # pragma: no cover - defensive path for arbitrary tool errors
        log.error("tool failed", tool=tool_name, error=str(error))
        result = f"Tool execution error: {error}"

    if on_tool_end is not None:
        on_tool_end(tool_name, result)

    return {"id": call["id"], "name": tool_name, "args": parsed_args, "result": result}


def _get_required_params(tool: Tool) -> list[str]:
    props = tool.parameters.get("properties", {})
    required = tool.parameters.get("required", [])
    if required:
        return list(required)
    return [k for k, v in props.items() if not v.get("default")]


def _log_args(args: dict) -> dict[str, str]:
    """Extract loggable fields from tool args (paths, commands, queries — not content)."""
    out: dict[str, str] = {}
    for key in ("path", "command", "query", "pattern", "key", "name", "url", "text"):
        if key in args:
            value = str(args[key])
            out[key] = value[:120] if len(value) > 120 else value
    return out


def _parse_tool_arguments(arguments: str) -> dict:
    raw = arguments.strip()
    if not raw:
        return {}

    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as error:
        raise ValueError(f"Tool argument JSON parse error: {error.msg}") from error

    if not isinstance(parsed, dict):
        raise ValueError("Tool argument JSON parse error: expected a JSON object")

    return parsed


def _normalize_usage(usage_obj: Any) -> dict[str, int]:
    prompt_tokens = _get_usage_value(usage_obj, "prompt_tokens")
    completion_tokens = _get_usage_value(usage_obj, "completion_tokens")
    return {"prompt_tokens": prompt_tokens, "completion_tokens": completion_tokens}


def _get_usage_value(usage_obj: Any, field: str) -> int:
    if usage_obj is None:
        return 0

    value: Any
    if isinstance(usage_obj, dict):
        value = usage_obj.get(field, 0)
    else:
        value = getattr(usage_obj, field, 0)

    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _completion_cost(model: str, prompt_tokens: int, completion_tokens: int) -> float:
    completion_cost_fn = getattr(litellm, "completion_cost", None)
    if not callable(completion_cost_fn):
        return 0.0

    try:
        cost = completion_cost_fn(
            model=model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
        )
    except Exception:
        return 0.0

    try:
        return float(cost)
    except (TypeError, ValueError):
        return 0.0
