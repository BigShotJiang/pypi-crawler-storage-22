"""Anthropic OAuth provider yielding LiteLLM-style ProviderChunk deltas."""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from typing import Any

import aiohttp

from ..base import OAuthProvider, OAuthProviderError, ProviderChunk
from ..registry import register_provider

_MESSAGES_ENDPOINT = "https://api.anthropic.com/v1/messages"
_BETA_FEATURES = [
    "claude-code-20250219",
    "oauth-2025-04-20",
    "fine-grained-tool-streaming-2025-05-14",
    "interleaved-thinking-2025-05-14",
]
_CONNECT_TIMEOUT_SECONDS = 20
_READ_TIMEOUT_SECONDS = 45
_MAX_RETRIES = 1
_MAX_RETRY_DELAY_SECONDS = 5.0


def _sanitize_text(text: str) -> str:
    return text.encode("utf-8", errors="surrogatepass").decode("utf-8", errors="replace")


def _coerce_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


@register_provider
class AnthropicOAuthProvider(OAuthProvider):
    provider_name = "anthropic_oauth"
    model_prefixes = ["claude-code"]
    system_prompt_prefix = "You are Claude Code, Anthropic's official CLI for Claude."

    def __init__(self, credentials: dict[str, Any]):
        super().__init__(credentials)
        token = credentials.get("token")
        if not isinstance(token, str) or not token.strip():
            token = credentials.get("access")
        if not isinstance(token, str) or not token.strip():
            raise OAuthProviderError("Missing Anthropic OAuth access token in credentials")
        self._access_token = token

    async def stream_completion(
        self,
        model: str,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        system_prompt: str | None = None,
        session_id: str | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[ProviderChunk]:
        _ = tool_choice, session_id, kwargs
        request_body = self._build_request_body(
            model=model,
            messages=messages,
            tools=tools,
            temperature=temperature,
            max_tokens=max_tokens,
            system_prompt=system_prompt,
        )
        headers = {
            "Authorization": f"Bearer {self._access_token}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "anthropic-version": "2023-06-01",
            "anthropic-beta": ",".join(_BETA_FEATURES),
            "anthropic-dangerous-direct-browser-access": "true",
            "user-agent": "claude-cli/2.1.2 (external, cli)",
            "x-app": "cli",
        }

        timeout = aiohttp.ClientTimeout(
            total=None,
            connect=_CONNECT_TIMEOUT_SECONDS,
            sock_connect=_CONNECT_TIMEOUT_SECONDS,
            sock_read=_READ_TIMEOUT_SECONDS,
        )
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                response = await self._request_with_retry(
                    session,
                    "POST",
                    _MESSAGES_ENDPOINT,
                    headers=headers,
                    json_body=request_body,
                    max_retries=_MAX_RETRIES,
                    max_retry_delay=_MAX_RETRY_DELAY_SECONDS,
                )
                async with response:
                    if response.status != 200:
                        body = await response.text()
                        raise OAuthProviderError(
                            f"Anthropic OAuth request failed ({response.status}): {body}"
                        )

                    async for chunk in self._stream_sse(response):
                        yield chunk
        except TimeoutError as exc:
            raise OAuthProviderError("Anthropic OAuth stream timed out") from exc

    def _build_request_body(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None,
        temperature: float | None,
        max_tokens: int | None,
        system_prompt: str | None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "model": self._extract_model_id(model),
            "messages": self._convert_messages(messages),
            "system": self._build_system_blocks(system_prompt),
            "stream": True,
            "max_tokens": int(max_tokens) if max_tokens is not None else 8192,
        }
        if temperature is not None:
            body["temperature"] = temperature
        if tools:
            converted_tools = self._convert_tools(tools)
            if converted_tools:
                body["tools"] = converted_tools
        return body

    @staticmethod
    def _extract_model_id(model: str) -> str:
        if model.lower().startswith("claude-code/"):
            return model.split("/", 1)[1]
        return model

    def _build_system_blocks(self, system_prompt: str | None) -> list[dict[str, Any]]:
        blocks: list[dict[str, Any]] = [
            {
                "type": "text",
                "text": self.system_prompt_prefix,
                "cache_control": {"type": "ephemeral"},
            }
        ]
        if system_prompt:
            blocks.append(
                {
                    "type": "text",
                    "text": _sanitize_text(system_prompt),
                    "cache_control": {"type": "ephemeral"},
                }
            )
        return blocks

    def _convert_messages(self, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        converted: list[dict[str, Any]] = []

        for message in messages:
            role = str(message.get("role", "user"))
            content = message.get("content", "")

            if role == "system":
                continue

            if role == "tool":
                converted.append(
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "tool_result",
                                "tool_use_id": str(message.get("tool_call_id", "")),
                                "content": _sanitize_text(str(content)),
                            }
                        ],
                    }
                )
                continue

            if role == "assistant":
                assistant_blocks: list[dict[str, Any]] = []
                assistant_blocks.extend(self._convert_content_blocks(content))

                tool_calls = message.get("tool_calls")
                if isinstance(tool_calls, list):
                    for tool_call in tool_calls:
                        if not isinstance(tool_call, dict):
                            continue
                        function = tool_call.get("function")
                        function_data = function if isinstance(function, dict) else {}
                        raw_arguments = str(function_data.get("arguments", "{}"))
                        try:
                            tool_input = json.loads(raw_arguments)
                        except json.JSONDecodeError:
                            tool_input = {}
                        if not isinstance(tool_input, dict):
                            tool_input = {}

                        assistant_blocks.append(
                            {
                                "type": "tool_use",
                                "id": str(tool_call.get("id", "")),
                                "name": str(function_data.get("name", "")),
                                "input": tool_input,
                            }
                        )

                if assistant_blocks:
                    converted.append({"role": "assistant", "content": assistant_blocks})
                continue

            target_role = "assistant" if role == "assistant" else "user"
            if isinstance(content, str):
                if content:
                    converted.append({"role": target_role, "content": _sanitize_text(content)})
                continue

            blocks = self._convert_content_blocks(content)
            if blocks:
                converted.append({"role": target_role, "content": blocks})

        return converted

    @staticmethod
    def _convert_content_blocks(content: Any) -> list[dict[str, Any]]:
        blocks: list[dict[str, Any]] = []
        if isinstance(content, str):
            if content:
                blocks.append({"type": "text", "text": _sanitize_text(content)})
            return blocks

        if not isinstance(content, list):
            return blocks

        for item in content:
            if not isinstance(item, dict):
                continue
            if item.get("type") == "text":
                text = str(item.get("text", ""))
                if text:
                    blocks.append({"type": "text", "text": _sanitize_text(text)})
        return blocks

    @staticmethod
    def _convert_tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        converted: list[dict[str, Any]] = []
        for tool in tools:
            if tool.get("type") != "function":
                continue
            function = tool.get("function")
            function_data = function if isinstance(function, dict) else {}
            converted.append(
                {
                    "name": str(function_data.get("name", "")),
                    "description": str(function_data.get("description", "")),
                    "input_schema": function_data.get(
                        "parameters",
                        {"type": "object", "properties": {}},
                    ),
                }
            )
        return converted

    async def _stream_sse(self, response: aiohttp.ClientResponse) -> AsyncIterator[ProviderChunk]:
        buffer = ""
        usage: dict[str, int] | None = None
        final_emitted = False

        async for chunk in response.content:
            buffer += chunk.decode("utf-8", errors="replace").replace("\r\n", "\n").replace("\r", "\n")

            while "\n\n" in buffer:
                raw_event, buffer = buffer.split("\n\n", 1)
                data_lines = []
                for line in raw_event.splitlines():
                    if line.startswith("data:"):
                        data_lines.append(line[5:].lstrip())
                if not data_lines:
                    continue

                payload = "\n".join(data_lines).strip()
                if not payload or payload == "[DONE]":
                    continue

                try:
                    event = json.loads(payload)
                except json.JSONDecodeError:
                    continue

                event_type = str(event.get("type", ""))

                if event_type == "error":
                    error_obj = event.get("error")
                    error_data = error_obj if isinstance(error_obj, dict) else {}
                    message = str(error_data.get("message", "Anthropic OAuth stream error"))
                    raise OAuthProviderError(message)

                if event_type == "message_start":
                    message = event.get("message")
                    if isinstance(message, dict):
                        usage = self._merge_usage(usage, message.get("usage"))
                    usage = self._merge_usage(usage, event.get("usage"))
                    continue

                if event_type == "content_block_start":
                    content_block = event.get("content_block")
                    if not isinstance(content_block, dict):
                        continue
                    if content_block.get("type") != "tool_use":
                        continue
                    index = _coerce_int(event.get("index")) or 0
                    tool_id = content_block.get("id")
                    tool_name = content_block.get("name")
                    yield self._tool_call_chunk(
                        index,
                        str(tool_id) if tool_id is not None else None,
                        str(tool_name) if tool_name is not None else None,
                        None,
                    )
                    continue

                if event_type == "content_block_delta":
                    delta = event.get("delta")
                    if not isinstance(delta, dict):
                        continue
                    delta_type = str(delta.get("type", ""))
                    if delta_type == "text_delta":
                        text = delta.get("text")
                        if isinstance(text, str) and text:
                            yield self._text_chunk(text)
                    elif delta_type == "input_json_delta":
                        partial_json = delta.get("partial_json")
                        if isinstance(partial_json, str):
                            index = _coerce_int(event.get("index")) or 0
                            yield self._tool_call_chunk(index, None, None, partial_json)
                    continue

                if event_type == "message_delta":
                    usage = self._merge_usage(usage, event.get("usage"))
                    delta = event.get("delta")
                    stop_reason: str | None = None
                    if isinstance(delta, dict):
                        raw_stop = delta.get("stop_reason")
                        if raw_stop is not None:
                            stop_reason = str(raw_stop)
                    if stop_reason is None:
                        raw_stop = event.get("stop_reason")
                        if raw_stop is not None:
                            stop_reason = str(raw_stop)

                    yield self._final_chunk(stop_reason or "stop", usage)
                    final_emitted = True
                    continue

                if event_type == "message_stop":
                    if final_emitted:
                        continue
                    usage = self._merge_usage(usage, event.get("usage"))
                    raw_stop = event.get("stop_reason")
                    stop_reason = str(raw_stop) if raw_stop is not None else "stop"
                    yield self._final_chunk(stop_reason, usage)
                    final_emitted = True

    @staticmethod
    def _merge_usage(
        current_usage: dict[str, int] | None,
        event_usage: Any,
    ) -> dict[str, int] | None:
        usage = dict(current_usage or {})
        if isinstance(event_usage, dict):
            prompt = event_usage.get("prompt_tokens", event_usage.get("input_tokens"))
            completion = event_usage.get("completion_tokens", event_usage.get("output_tokens"))
            total = event_usage.get("total_tokens")

            prompt_tokens = _coerce_int(prompt)
            completion_tokens = _coerce_int(completion)
            total_tokens = _coerce_int(total)

            if prompt_tokens is not None:
                usage["prompt_tokens"] = prompt_tokens
            if completion_tokens is not None:
                usage["completion_tokens"] = completion_tokens
            if total_tokens is not None:
                usage["total_tokens"] = total_tokens

        if not usage:
            return None

        usage.setdefault("prompt_tokens", 0)
        usage.setdefault("completion_tokens", 0)
        usage.setdefault("total_tokens", usage["prompt_tokens"] + usage["completion_tokens"])
        return usage
