from __future__ import annotations

import asyncio
import inspect
from collections.abc import Awaitable, Callable
from typing import Any, Protocol

from otto.agent import Tool, run
from otto.auth import AuthStorage
from otto.config import Config
from otto.gateway import Gateway
from otto.memory import Memory
from otto.prompts import IDENTITY_KEY, build_system_prompt
from otto.scheduler import Scheduler
from otto.sessions import SessionStore
from otto.tools import create_session_tools

MODEL_PRESETS: list[tuple[str, str]] = [
    ("Claude Sonnet", "anthropic/claude-sonnet-4-5-20250514"),
    ("Claude Haiku", "anthropic/claude-haiku-4-5-20251001"),
    ("GPT-4o", "openai/gpt-4o"),
    ("GPT-4o Mini", "openai/gpt-4o-mini"),
]


class Renderer(Protocol):
    def on_text(self, chunk: str) -> None:
        """Receive a streaming text chunk."""
        ...

    def on_tool_start(self, name: str, args: dict) -> None:
        """Handle tool execution start."""
        ...

    def on_tool_end(self, name: str, result: str) -> None:
        """Handle tool execution completion."""
        ...

    async def send_text(self, text: str) -> None:
        """Send a complete text message."""
        ...

    async def send_with_buttons(self, text: str, buttons: list[list[tuple[str, str]]]) -> None:
        """Send text with optional inline buttons. buttons: list of rows, each row is list of (label, callback_data) tuples."""
        ...

    async def show_error(self, error: str) -> None:
        """Display an error message."""
        ...

    async def send_file(self, path: str, caption: str | None = None) -> None:
        """Send a file to the user."""
        ...

    async def flush(self) -> None:
        """Flush any buffered content."""
        ...


type CommandHandler = Callable[["Chat", str, str, str | None, "Renderer"], Awaitable[None]]


HELP_CATEGORIES: dict[str, dict[str, Any]] = {
    "chat": {
        "label": "Chat",
        "summary": "New, clear, stop",
        "title": "Chat Commands",
        "commands": [
            ("/new", "Start fresh session"),
            ("/clear", "Clear session history"),
            ("/stop", "Cancel current response"),
        ],
    },
    "ai": {
        "label": "AI",
        "summary": "Model, status, tools",
        "title": "AI Commands",
        "commands": [
            ("/model", "Show or change current model"),
            ("/status", "System status"),
            ("/tools", "List available tools"),
        ],
    },
    "info": {
        "label": "Info",
        "summary": "History, memory",
        "title": "Info Commands",
        "commands": [
            ("/history", "Show session info"),
            ("/help", "Show this help menu"),
            ("/status", "Show model and memory status"),
        ],
    },
}

HELP_QUICK_COMMANDS = ["status", "new", "model"]


def get_help_data() -> dict[str, Any]:
    """Return structured help data used by command + callback handlers."""
    categories: dict[str, dict[str, Any]] = {}
    for key, value in HELP_CATEGORIES.items():
        categories[key] = {
            "label": value["label"],
            "summary": value["summary"],
            "title": value["title"],
            "commands": list(value["commands"]),
        }
    return {
        "title": "Otto Commands",
        "categories": categories,
        "quick_launch": list(HELP_QUICK_COMMANDS),
    }


def build_help_main_view() -> tuple[str, list[list[tuple[str, str]]]]:
    help_data = get_help_data()
    categories: dict[str, dict[str, Any]] = help_data["categories"]
    category_order = ["chat", "ai", "info"]
    lines = [
        "<b>Otto Commands</b>",
        "",
    ]
    for key in category_order:
        category = categories[key]
        lines.append(f"<b>{category['label']}</b> — {category['summary']}")
    lines.extend(["", "Tap a category below."])
    buttons = [
        [(categories[key]["label"], f"help:{key}") for key in category_order],
        [(f"/{command}", f"help:run:{command}") for command in help_data["quick_launch"]],
    ]
    return "\n".join(lines), buttons


def build_help_category_view(category_key: str) -> tuple[str, list[list[tuple[str, str]]]] | None:
    help_data = get_help_data()
    categories: dict[str, dict[str, Any]] = help_data["categories"]
    category = categories.get(category_key)
    if category is None:
        return None
    lines = [f"<b>{category['title']}</b>", ""]
    for command, description in category["commands"]:
        lines.append(f"{command} — {description}")
    buttons = [[("« Back", "help:back")]]
    return "\n".join(lines), buttons


def build_help_plaintext() -> str:
    help_data = get_help_data()
    categories: dict[str, dict[str, Any]] = help_data["categories"]
    lines = ["Available commands:"]
    for category_key in ["chat", "ai", "info"]:
        category = categories[category_key]
        for command, description in category["commands"]:
            lines.append(f"{command} - {description}")
    return "\n".join(lines)


async def _cmd_help(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = chat, chat_id, args, bot_id
    html_text, buttons = build_help_main_view()
    plain_text = build_help_plaintext()
    try:
        result = renderer.send_with_buttons(html_text, buttons)
    except AttributeError:
        await renderer.send_text(plain_text)
        return
    if inspect.isawaitable(result):
        await result
        return
    await renderer.send_text(plain_text)


async def _cmd_status(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    context_key = chat._context_key(chat_id, bot_id=bot_id)
    model = chat._model_overrides.get(context_key, chat._config.agent.model)
    session = chat._load_session(chat_id, bot_id=bot_id)
    tools = chat._gateway.tools()
    html_lines = [
        "<b>Otto Status</b>",
        "",
        f"<b>Model:</b>  {model}",
        f"<b>Session:</b>  {len(session.messages)} messages",
        f"<b>Tools:</b>  {len(tools)} registered",
        "<b>Memory:</b>  active",
    ]
    plain_lines = [
        "Otto Status",
        "",
        f"Model: {model}",
        f"Messages: {len(session.messages)}",
        f"Tools: {len(tools)} registered",
        "Memory: active",
    ]
    buttons = [
        [("Change Model", "status:model"), ("New Session", "status:new")],
        [("Refresh", "status:refresh")],
    ]
    html_text = "\n".join(html_lines)
    plain_text = "\n".join(plain_lines)
    try:
        result = renderer.send_with_buttons(html_text, buttons)
    except AttributeError:
        await renderer.send_text(plain_text)
        return
    if inspect.isawaitable(result):
        await result
        return
    await renderer.send_text(plain_text)


async def _cmd_model(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    context_key = chat._context_key(chat_id, bot_id=bot_id)
    model_name = args.strip()
    if model_name:
        chat._model_overrides[context_key] = model_name
        text = (
            f"Model set: {model_name}"
            if inspect.iscoroutinefunction(getattr(renderer, "send_with_buttons", None))
            else f"Model set for this session: {model_name}"
        )
        await renderer.send_text(text)
        return
    current = chat._model_overrides.get(context_key, chat._config.agent.model)
    text = f"<b>Current Model</b>\n{current}\n\nSelect a model:"
    buttons = [
        [(label, f"model:{model_id}") for label, model_id in MODEL_PRESETS[i : i + 2]]
        for i in range(0, len(MODEL_PRESETS), 2)
    ]
    buttons.append([("Custom...", "model:custom")])
    buttons.append([("Cancel", "model:cancel")])
    try:
        result = renderer.send_with_buttons(text, buttons)
    except AttributeError:
        await renderer.send_text(f"Current model: {current}")
        return
    if inspect.isawaitable(result):
        await result
        return
    await renderer.send_text(f"Current model: {current}")


async def _cmd_new(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    session = chat._load_session(chat_id, bot_id=bot_id)
    session.messages.clear()
    chat._save_session(session, bot_id=bot_id)
    await renderer.send_text("New session started.")


async def _cmd_clear(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    session = chat._load_session(chat_id, bot_id=bot_id)
    session.messages.clear()
    chat._save_session(session, bot_id=bot_id)
    await renderer.send_text("Session history cleared.")


async def _cmd_history(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    session = chat._load_session(chat_id, bot_id=bot_id)
    context_key = chat._context_key(chat_id, bot_id=bot_id)
    model = chat._model_overrides.get(context_key, chat._config.agent.model)
    await renderer.send_text(
        "\n".join(
            [
                f"Chat ID: {chat_id}",
                f"Messages: {len(session.messages)}",
                f"Model: {model}",
            ]
        )
    )


async def _cmd_tools(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    gateway_tools = chat._scope_gateway_tools(chat._gateway.tools(), bot_id=bot_id)
    session_tools = create_session_tools(
        chat_id=chat._context_key(chat_id, bot_id=bot_id),
        scheduler=chat._scheduler,
        notify=lambda t: None,  # type: ignore[arg-type, return-value]
        send_file=lambda p, c: None,  # type: ignore[arg-type, return-value]
    )
    all_tools = gateway_tools + session_tools
    if not all_tools:
        await renderer.send_text("No tools available.")
        return
    tool_lines = [f"- {tool.name}" for tool in all_tools]
    await renderer.send_text("Available tools:\n" + "\n".join(tool_lines))


async def _cmd_stop(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    if chat.stop(chat_id, bot_id=bot_id):
        await renderer.send_text("Stopping...")
    else:
        await renderer.send_text("Nothing running.")


COMMANDS: dict[str, CommandHandler] = {
    "help": _cmd_help,
    "status": _cmd_status,
    "model": _cmd_model,
    "new": _cmd_new,
    "clear": _cmd_clear,
    "history": _cmd_history,
    "tools": _cmd_tools,
    "stop": _cmd_stop,
}


class Chat:
    def __init__(
        self,
        config: Config,
        gateway: Gateway,
        session_store: SessionStore,
        memory: Memory,
        scheduler: Scheduler | None = None,
    ):
        self._config = config
        self._gateway = gateway
        self._session_store = session_store
        self._memory = memory
        self._scheduler = scheduler
        self._model_overrides: dict[str, str] = {}
        self._auth_storage = AuthStorage()
        self._active_tasks: dict[str, asyncio.Task] = {}

    @staticmethod
    def _context_key(chat_id: str, *, bot_id: str | None = None) -> str:
        if bot_id:
            return f"{bot_id}:{chat_id}"
        return chat_id

    @staticmethod
    def _memory_key(key: str, *, bot_id: str | None = None) -> str:
        if bot_id:
            return f"bot:{bot_id}:{key}"
        return key

    @classmethod
    def _scope_memory_results(cls, results: list[dict], *, bot_id: str | None = None) -> list[dict]:
        if not bot_id:
            return results

        prefix = cls._memory_key("", bot_id=bot_id)
        scoped: list[dict] = []
        for item in results:
            key = str(item.get("key", ""))
            if not key.startswith(prefix):
                continue
            scoped_item = dict(item)
            scoped_item["key"] = key[len(prefix) :]
            scoped.append(scoped_item)
        return scoped

    def _scope_gateway_tools(self, tools: list[Tool], *, bot_id: str | None = None) -> list[Tool]:
        if not bot_id:
            return tools

        scoped_tools: list[Tool] = []
        for tool in tools:
            if tool.name == "memory_store":

                async def _memory_store(
                    key: str,
                    content: str,
                    *,
                    _bot_id: str = bot_id,
                    _memory: Memory = self._memory,
                ) -> str:
                    scoped_key = self._memory_key(key, bot_id=_bot_id)
                    _memory.store(scoped_key, content)
                    return f"Stored memory entry: {key}"

                scoped_tools.append(
                    Tool(
                        name=tool.name,
                        description=tool.description,
                        parameters=tool.parameters,
                        execute=_memory_store,
                    )
                )
                continue

            if tool.name == "memory_search":

                async def _memory_search(
                    query: str,
                    limit: int = 5,
                    *,
                    _bot_id: str = bot_id,
                    _memory: Memory = self._memory,
                ) -> str:
                    normalized_limit = int(limit if limit is not None else 5)
                    raw_results = _memory.search(query, limit=normalized_limit)
                    scoped_results = self._scope_memory_results(raw_results, bot_id=_bot_id)
                    return "\n".join(
                        f"{str(item.get('key', ''))}: {str(item.get('snippet', ''))}"
                        for item in scoped_results
                    )

                scoped_tools.append(
                    Tool(
                        name=tool.name,
                        description=tool.description,
                        parameters=tool.parameters,
                        execute=_memory_search,
                    )
                )
                continue

            scoped_tools.append(tool)
        return scoped_tools

    def _load_session(self, chat_id: str, *, bot_id: str | None = None):
        if bot_id:
            return self._session_store.load(chat_id, bot_id=bot_id)
        return self._session_store.load(chat_id)

    def _save_session(self, session, *, bot_id: str | None = None) -> None:
        if bot_id:
            self._session_store.save(session, bot_id=bot_id)
            return
        self._session_store.save(session)

    def stop(self, chat_id: str, bot_id: str | None = None) -> bool:
        """Cancel any active agent run for this chat. Returns True if a task was cancelled."""
        context_key = self._context_key(chat_id, bot_id=bot_id)
        task = self._active_tasks.get(context_key)
        if task and not task.done():
            task.cancel()
            return True
        return False

    async def handle_message(
        self, chat_id: str, text: str, renderer: Renderer, bot_id: str | None = None,
        *, background: bool = False,
    ) -> None:
        """Main entry point. Routes slash commands or runs the agent.

        Args:
            background: True when invoked by the scheduler. Enables the send_message
                        tool so the agent can proactively notify the user. During normal
                        chat the streaming response already reaches the user via flush(),
                        so send_message is omitted to prevent duplicate delivery loops.
        """
        if text.startswith("/"):
            command_text = text[1:].strip()
            if not command_text:
                await renderer.show_error("Unknown command: /")
                return
            parts = command_text.split(None, 1)
            command = parts[0]
            args = parts[1] if len(parts) > 1 else ""
            await self.handle_command(
                chat_id=chat_id,
                command=command,
                args=args,
                renderer=renderer,
                bot_id=bot_id,
            )
            return

        context_key = self._context_key(chat_id, bot_id=bot_id)
        task = asyncio.current_task()
        if task:
            self._active_tasks[context_key] = task

        try:
            session = self._load_session(chat_id, bot_id=bot_id)
            session.messages.append({"role": "user", "content": text})

            memory_context: list[dict] = []
            try:
                memory_context = self._scope_memory_results(
                    self._memory.search(text, limit=5),
                    bot_id=bot_id,
                )
            except Exception:
                memory_context = []

            identity = self._memory.get(self._memory_key(IDENTITY_KEY, bot_id=bot_id))
            system_prompt = build_system_prompt(memory_context=memory_context, identity=identity)
            model = self._model_overrides.get(context_key, self._config.agent.model)
            gateway_tools = self._scope_gateway_tools(self._gateway.tools(), bot_id=bot_id)

            async def _notify(text: str) -> None:
                await renderer.send_text(text)

            async def _send_file(path: str, caption: str | None = None) -> None:
                await renderer.send_file(path, caption)

            session_tools = create_session_tools(
                chat_id=context_key,
                scheduler=self._scheduler,
                notify=_notify if background else None,
                send_file=_send_file,
            )
            all_tools = gateway_tools + session_tools

            result = await run(
                model=model,
                system=system_prompt,
                messages=session.messages,
                tools=all_tools,
                auth_storage=self._auth_storage,
                on_text=renderer.on_text,
                on_tool_start=renderer.on_tool_start,
                on_tool_end=renderer.on_tool_end,
            )
            await renderer.flush()

            session.messages.append({"role": "assistant", "content": result.text})
            self._save_session(session, bot_id=bot_id)
        finally:
            if task and self._active_tasks.get(context_key) is task:
                self._active_tasks.pop(context_key, None)

    async def handle_command(
        self,
        chat_id: str,
        command: str,
        args: str,
        renderer: Renderer,
        bot_id: str | None = None,
    ) -> None:
        """Dispatch slash commands."""
        name = command.strip().lstrip("/").lower()
        handler = COMMANDS.get(name)
        if handler:
            await handler(self, chat_id, args, bot_id, renderer)
        else:
            await renderer.show_error(f"Unknown command: /{name}")
