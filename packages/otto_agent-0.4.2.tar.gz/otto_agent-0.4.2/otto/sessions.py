from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import quote, unquote


@dataclass
class Session:
    chat_id: str
    messages: list[dict]
    created_at: str
    updated_at: str
    bot_id: str | None = None


_SCOPED_PREFIX = "__bot__"
_SCOPED_SEPARATOR = "__chat__"


class SessionStore:
    def __init__(self, sessions_dir: Path):
        self._sessions_dir = sessions_dir
        self._sessions_dir.mkdir(parents=True, exist_ok=True)

    def load(self, chat_id: str, bot_id: str | None = None) -> Session:
        """Load a session from JSONL, returning an empty one when missing."""
        path = self._session_path(chat_id, bot_id=bot_id)
        if not path.exists():
            now = _now_iso()
            return Session(
                chat_id=chat_id,
                messages=[],
                created_at=now,
                updated_at=now,
                bot_id=bot_id,
            )

        lines = _read_non_empty_lines(path)
        if not lines:
            now = _now_iso()
            return Session(
                chat_id=chat_id,
                messages=[],
                created_at=now,
                updated_at=now,
                bot_id=bot_id,
            )

        first = _parse_line(path, lines[0], line_number=1)
        metadata: dict | None = (
            first if isinstance(first, dict) and first.get("_meta") is True else None
        )

        if metadata is None:
            created_at = _now_iso()
            updated_at = created_at
            resolved_chat_id = chat_id
            resolved_bot_id = bot_id
            message_values = [_ensure_message_dict(first, path=path, line_number=1)]
            for index, raw_line in enumerate(lines[1:], start=2):
                message_values.append(
                    _ensure_message_dict(
                        _parse_line(path, raw_line, line_number=index), path=path, line_number=index
                    )
                )
        else:
            created_at = str(metadata.get("created_at") or _now_iso())
            updated_at = str(metadata.get("updated_at") or created_at)
            resolved_chat_id = str(metadata.get("chat_id") or chat_id)
            resolved_bot = metadata.get("bot_id")
            resolved_bot_id = str(resolved_bot) if resolved_bot is not None else bot_id
            message_values = []
            for index, raw_line in enumerate(lines[1:], start=2):
                message_values.append(
                    _ensure_message_dict(
                        _parse_line(path, raw_line, line_number=index), path=path, line_number=index
                    )
                )

        return Session(
            chat_id=resolved_chat_id,
            messages=message_values,
            created_at=created_at,
            updated_at=updated_at,
            bot_id=resolved_bot_id,
        )

    def save(self, session: Session, bot_id: str | None = None) -> None:
        """Persist a session to JSONL with metadata first and one message per line."""
        resolved_bot_id = session.bot_id if session.bot_id is not None else bot_id
        path = self._session_path(session.chat_id, bot_id=resolved_bot_id)
        created_at = session.created_at or _now_iso()
        updated_at = session.updated_at or created_at

        metadata = {
            "_meta": True,
            "chat_id": session.chat_id,
            "created_at": created_at,
            "updated_at": updated_at,
        }
        if resolved_bot_id:
            metadata["bot_id"] = resolved_bot_id

        with path.open("w", encoding="utf-8") as file:
            file.write(json.dumps(metadata, ensure_ascii=False) + "\n")
            for message in session.messages:
                file.write(json.dumps(message, ensure_ascii=False) + "\n")

    def append(self, chat_id: str, message: dict, bot_id: str | None = None) -> None:
        """Append one message, creating a new session file when needed."""
        path = self._session_path(chat_id, bot_id=bot_id)
        now = _now_iso()

        if not path.exists():
            self.save(
                Session(
                    chat_id=chat_id,
                    messages=[message],
                    created_at=now,
                    updated_at=now,
                    bot_id=bot_id,
                ),
                bot_id=bot_id,
            )
            return

        session = self.load(chat_id, bot_id=bot_id)
        session.chat_id = chat_id
        session.bot_id = bot_id
        if not session.created_at:
            session.created_at = now
        session.updated_at = now
        session.messages.append(message)
        self.save(session, bot_id=bot_id)

    def list_sessions(self, bot_id: str | None = None) -> list[str]:
        """Return all chat IDs that have persisted sessions."""
        chat_ids: list[str] = []
        for path in self._sessions_dir.glob("*.jsonl"):
            if not path.is_file():
                continue
            stem = path.name.removesuffix(".jsonl")
            scoped_parts = _parse_scoped_stem(stem)
            if bot_id:
                if scoped_parts is None:
                    continue
                scoped_bot_id, scoped_chat_id = scoped_parts
                if scoped_bot_id == bot_id:
                    chat_ids.append(scoped_chat_id)
                continue

            if scoped_parts is None:
                chat_ids.append(stem)
        return sorted(chat_ids)

    def delete(self, chat_id: str, bot_id: str | None = None) -> None:
        """Delete a persisted session file."""
        self._session_path(chat_id, bot_id=bot_id).unlink(missing_ok=True)

    def _session_path(self, chat_id: str, bot_id: str | None = None) -> Path:
        if bot_id:
            stem = (
                f"{_SCOPED_PREFIX}"
                f"{_encode_path_component(bot_id)}"
                f"{_SCOPED_SEPARATOR}"
                f"{_encode_path_component(chat_id)}"
            )
            return self._sessions_dir / f"{stem}.jsonl"
        return self._sessions_dir / f"{chat_id}.jsonl"


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _read_non_empty_lines(path: Path) -> list[str]:
    with path.open("r", encoding="utf-8") as file:
        return [line.strip() for line in file if line.strip()]


def _parse_line(path: Path, raw_line: str, *, line_number: int):
    try:
        return json.loads(raw_line)
    except json.JSONDecodeError as exc:  # pragma: no cover - defensive path
        raise ValueError(f"Invalid JSON in {path} on line {line_number}") from exc


def _ensure_message_dict(value, *, path: Path, line_number: int) -> dict:
    if not isinstance(value, dict):
        raise ValueError(f"Invalid message in {path} on line {line_number}: expected JSON object")
    return value


def _encode_path_component(value: str) -> str:
    return quote(value, safe="")


def _decode_path_component(value: str) -> str:
    return unquote(value)


def _parse_scoped_stem(stem: str) -> tuple[str, str] | None:
    if not stem.startswith(_SCOPED_PREFIX):
        return None
    encoded = stem[len(_SCOPED_PREFIX) :]
    separator_index = encoded.find(_SCOPED_SEPARATOR)
    if separator_index <= 0:
        return None
    encoded_bot_id = encoded[:separator_index]
    encoded_chat_id = encoded[separator_index + len(_SCOPED_SEPARATOR) :]
    if not encoded_chat_id:
        return None
    return _decode_path_component(encoded_bot_id), _decode_path_component(encoded_chat_id)
