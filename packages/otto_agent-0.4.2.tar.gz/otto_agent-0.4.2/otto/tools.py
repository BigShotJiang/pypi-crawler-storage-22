from __future__ import annotations

import asyncio
import fnmatch
import json
import os
import re
import urllib.error
import urllib.request
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Any

from otto.agent import Tool
from otto.config import OTTO_HOME

if TYPE_CHECKING:
    from otto.memory import Memory
    from otto.scheduler import Scheduler

_EXA_ENDPOINT = "https://mcp.exa.ai/mcp"
_WORKSPACE_MODE_ENV = "OTTO_WORKSPACE_MODE"
_WORKSPACE_ROOT_ENV = "OTTO_WORKSPACE_ROOT"


@dataclass(frozen=True)
class _WorkspaceContext:
    strict_mode: bool
    root: Path | None = None
    error: str | None = None


# === Tool Registry ===
# Format: (name, description, schema_fn, execute_fn)
def _tool_registry(
    workspace: _WorkspaceContext,
) -> list[tuple[str, str, Callable[[], dict[str, Any]], Callable[..., Any]]]:
    async def _read_file(path: str, offset: int = 0, limit: int = 2000) -> str:
        return await _read_file_execute(path, offset=offset, limit=limit, workspace=workspace)

    async def _write_file(path: str, content: str) -> str:
        return await _write_file_execute(path, content, workspace=workspace)

    async def _edit_file(
        path: str,
        old_text: str,
        new_text: str,
        replace_all: bool = False,
    ) -> str:
        return await _edit_file_execute(
            path, old_text, new_text, replace_all=replace_all, workspace=workspace
        )

    async def _glob(pattern: str, path: str | None = None) -> str:
        return await _glob_execute(pattern, path=path, workspace=workspace)

    async def _grep(pattern: str, path: str | None = None, include: str | None = None) -> str:
        return await _grep_execute(pattern, path=path, include=include, workspace=workspace)

    async def _list_dir(path: str = ".", show_hidden: bool = False) -> str:
        return await _list_dir_execute(path=path, show_hidden=show_hidden, workspace=workspace)

    async def _bash(command: str, timeout: int = 120) -> str:
        return await _bash_execute(command, timeout=timeout, workspace=workspace)

    return [
        # File tools
        (
            "read_file",
            "Read file contents with optional line offset/limit.",
            _read_file_schema,
            _read_file,
        ),
        (
            "write_file",
            "Write text to a file, creating parent directories.",
            _write_file_schema,
            _write_file,
        ),
        ("edit_file", "Replace exact text in a file.", _edit_file_schema, _edit_file),
        ("glob", "Find files matching a glob pattern.", _glob_schema, _glob),
        ("grep", "Search files for regex matches.", _grep_schema, _grep),
        (
            "list_dir",
            "List directory contents with basic type markers.",
            _list_dir_schema,
            _list_dir,
        ),
        # System tools
        ("bash", "Run a shell command and return combined output.", _bash_schema, _bash),
        # Web tools
        ("web_search", "Search the web via Exa MCP.", _web_search_schema, _web_search_execute),
        ("fetch", "Fetch content from a URL.", _fetch_schema, _fetch_execute),
    ]


# === Registry Builder ===
def create_tools(
    *,
    memory: Memory | None = None,
    workspace_mode: str | None = None,
    workspace_root: str | Path | None = None,
) -> list[Tool]:
    """Return all built-in tools."""
    workspace = _workspace_context(workspace_mode=workspace_mode, workspace_root=workspace_root)
    tools = [
        Tool(name, desc, schema_fn(), exec_fn)
        for name, desc, schema_fn, exec_fn in _tool_registry(workspace)
    ]
    tools.extend(_create_skill_tools())
    if memory is not None:
        tools.extend(_create_memory_tools(memory))
    return tools


def create_session_tools(
    *,
    chat_id: str,
    scheduler: Scheduler | None = None,
    notify: Callable[[str], Awaitable[None]] | None = None,
    send_file: Callable[[str, str | None], Awaitable[None]] | None = None,
) -> list[Tool]:
    """Create tools that need per-conversation context."""
    tools: list[Tool] = []
    if scheduler is not None:
        tools.extend(_create_scheduler_tools(chat_id, scheduler))
    if notify is not None:
        tools.extend(_create_notify_tools(notify))
    if send_file is not None:
        tools.extend(_create_send_file_tools(send_file))
    return tools


def _create_memory_tools(memory: Memory) -> list[Tool]:
    async def _memory_search(query: str, limit: int = 5) -> str:
        return await _memory_search_execute(memory, query, limit=limit)

    async def _memory_store(key: str, content: str) -> str:
        return await _memory_store_execute(memory, key, content)

    return [
        Tool(
            "memory_search",
            "Search memory for relevant context",
            _memory_search_schema(),
            _memory_search,
        ),
        Tool(
            "memory_store", "Store a fact or note in memory", _memory_store_schema(), _memory_store
        ),
    ]


def _create_skill_tools() -> list[Tool]:
    async def _create_skill(
        name: str,
        description: str,
        content: str,
        license: str | None = None,
        compatibility: str | None = None,
        scripts: dict[str, Any] | None = None,
    ) -> str:
        return await _create_skill_execute(
            name,
            description,
            content,
            license=license,
            compatibility=compatibility,
            scripts=scripts,
        )

    async def _use_skill(name: str) -> str:
        return await _use_skill_execute(name)

    return [
        Tool(
            "create_skill",
            "Create a new agent skill with SKILL.md and optional scripts",
            _create_skill_schema(),
            _create_skill,
        ),
        Tool(
            "use_skill",
            "Load a skill's full instructions into context",
            _use_skill_schema(),
            _use_skill,
        ),
    ]


# === Scheduler Tools ===
def _create_scheduler_tools(chat_id: str, scheduler: Scheduler) -> list[Tool]:
    async def _set_reminder(message: str, delay: str) -> str:
        return await _set_reminder_execute(chat_id, scheduler, message, delay)

    async def _schedule(prompt: str, cron: str) -> str:
        return await _schedule_execute(chat_id, scheduler, prompt, cron)

    async def _list_schedules() -> str:
        return await _list_schedules_execute(chat_id, scheduler)

    async def _cancel_schedule(task_id: str) -> str:
        return await _cancel_schedule_execute(scheduler, task_id)

    return [
        Tool(
            "set_reminder",
            "Set a reminder that will notify you after a delay",
            _set_reminder_schema(),
            _set_reminder,
        ),
        Tool(
            "schedule",
            "Schedule a recurring task using cron syntax",
            _schedule_schema(),
            _schedule,
        ),
        Tool(
            "list_schedules",
            "List your scheduled tasks and reminders",
            _list_schedules_schema(),
            _list_schedules,
        ),
        Tool(
            "cancel_schedule",
            "Cancel a scheduled task or reminder",
            _cancel_schedule_schema(),
            _cancel_schedule,
        ),
    ]


def _set_reminder_schema() -> dict[str, Any]:
    return _schema(
        {
            "message": {"type": "string", "description": "Reminder message to send"},
            "delay": {
                "type": "string",
                "description": 'Delay from now (e.g. "2h", "30m", "1d")',
            },
        },
        ["message", "delay"],
    )


def _parse_delay(delay: str) -> timedelta | None:
    match = re.fullmatch(r"(\d+)([smhd])", delay.strip().lower())
    if match is None:
        return None
    amount = int(match.group(1))
    unit = match.group(2)
    if unit == "s":
        return timedelta(seconds=amount)
    if unit == "m":
        return timedelta(minutes=amount)
    if unit == "h":
        return timedelta(hours=amount)
    if unit == "d":
        return timedelta(days=amount)
    return None


def _humanize_datetime(value: datetime | None) -> str:
    if value is None:
        return "unknown"
    return value.astimezone(UTC).strftime("%Y-%m-%d %H:%M:%S UTC")


def _utc_now() -> datetime:
    return datetime.now(UTC)


async def _set_reminder_execute(
    chat_id: str, scheduler: Scheduler, message: str, delay: str
) -> str:
    delta = _parse_delay(delay)
    if delta is None:
        return 'Invalid delay. Use format like "30m", "2h", or "1d".'
    run_at = _utc_now() + delta
    try:
        task = scheduler.add(chat_id, f"__notify__:{message}", run_at=run_at)
    except Exception as exc:
        return f"Failed to set reminder: {exc}"
    return f"Reminder set for {_humanize_datetime(task.run_at)}."


def _schedule_schema() -> dict[str, Any]:
    return _schema(
        {
            "prompt": {"type": "string", "description": "Prompt to run on schedule"},
            "cron": {"type": "string", "description": 'Cron expression (e.g. "0 9 * * *")'},
        },
        ["prompt", "cron"],
    )


async def _schedule_execute(chat_id: str, scheduler: Scheduler, prompt: str, cron: str) -> str:
    try:
        task = scheduler.add(chat_id, prompt, cron=cron)
    except Exception as exc:
        return f"Failed to schedule task: {exc}"
    return f"Scheduled task {task.id}. Next run: {_humanize_datetime(task.run_at)}"


def _list_schedules_schema() -> dict[str, Any]:
    return _schema({}, [])


async def _list_schedules_execute(chat_id: str, scheduler: Scheduler) -> str:
    try:
        tasks = scheduler.list(chat_id)
    except Exception as exc:
        return f"Failed to list schedules: {exc}"

    lines = ["ID | Type | Next Run | Prompt"]
    for task in tasks:
        task_type = task.cron if task.cron is not None else "(one-shot)"
        lines.append(f"{task.id} | {task_type} | {_humanize_datetime(task.run_at)} | {task.prompt}")
    return "\n".join(lines)


def _cancel_schedule_schema() -> dict[str, Any]:
    return _schema({"task_id": {"type": "string", "description": "Task ID to cancel"}}, ["task_id"])


async def _cancel_schedule_execute(scheduler: Scheduler, task_id: str) -> str:
    try:
        removed = scheduler.remove(task_id)
    except Exception as exc:
        return f"Failed to cancel schedule: {exc}"
    if removed:
        return f"Cancelled schedule: {task_id}"
    return f"Schedule not found: {task_id}"


# === Notify Tools ===
def _create_notify_tools(notify: Callable[[str], Awaitable[None]]) -> list[Tool]:
    async def _send_message(text: str) -> str:
        return await _send_message_execute(notify, text)

    return [
        Tool(
            "send_message",
            "Send a message to the user proactively",
            _send_message_schema(),
            _send_message,
        )
    ]


def _send_message_schema() -> dict[str, Any]:
    return _schema({"text": {"type": "string", "description": "Message text"}}, ["text"])


async def _send_message_execute(notify: Callable[[str], Awaitable[None]], text: str) -> str:
    await notify(text)
    return "Message sent."


# === Send File Tools ===
def _create_send_file_tools(
    send_file: Callable[[str, str | None], Awaitable[None]],
) -> list[Tool]:
    async def _send_file(path: str, caption: str = "") -> str:
        return await _send_file_execute(send_file, path, caption or None)

    return [
        Tool(
            "send_file",
            "Send a file to the user (documents, images, PDFs, etc.)",
            _send_file_schema(),
            _send_file,
        )
    ]


def _send_file_schema() -> dict[str, Any]:
    return _schema(
        {
            "path": {"type": "string", "description": "Absolute path to the file to send"},
            "caption": {"type": "string", "description": "Optional caption for the file"},
        },
        ["path"],
    )


async def _send_file_execute(
    send_file: Callable[[str, str | None], Awaitable[None]],
    path: str,
    caption: str | None,
) -> str:
    resolved = Path(path).expanduser()
    if not resolved.is_file():
        return f"File not found: {path}"
    await send_file(str(resolved), caption)
    return f"Sent file: {resolved.name}"


# === Implementation ===


# === Schema Helpers ===
def _schema(properties: dict[str, Any], required: list[str]) -> dict[str, Any]:
    return {"type": "object", "properties": properties, "required": required}


# === File Tools ===
def _workspace_context(
    *,
    workspace_mode: str | None = None,
    workspace_root: str | Path | None = None,
) -> _WorkspaceContext:
    raw_mode = (
        workspace_mode
        if workspace_mode is not None
        else os.getenv(_WORKSPACE_MODE_ENV, "default")
    )
    strict_mode = str(raw_mode).strip().lower() == "strict"
    if not strict_mode:
        return _WorkspaceContext(strict_mode=False)

    configured_root = workspace_root if workspace_root is not None else os.getenv(_WORKSPACE_ROOT_ENV)
    if configured_root is None or not str(configured_root).strip():
        return _WorkspaceContext(
            strict_mode=True,
            error=(
                f"{_WORKSPACE_ROOT_ENV} is required when "
                f"{_WORKSPACE_MODE_ENV}=strict"
            ),
        )

    root = Path(str(configured_root)).expanduser()
    try:
        resolved_root = root.resolve(strict=True)
    except Exception as exc:
        return _WorkspaceContext(
            strict_mode=True,
            error=f"workspace root '{root}' is invalid: {exc}",
        )

    if not resolved_root.is_dir():
        return _WorkspaceContext(
            strict_mode=True,
            error=f"workspace root '{resolved_root}' is not a directory",
        )
    return _WorkspaceContext(strict_mode=True, root=resolved_root)


def _strict_denial(reason: str) -> str:
    return f"Strict workspace mode denied: {reason}"


def _is_within_workspace(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _resolve_tool_path(
    raw_path: str | None,
    *,
    workspace: _WorkspaceContext,
    default_path: str = ".",
) -> tuple[Path | None, str | None]:
    candidate_text = default_path if raw_path is None else str(raw_path)
    if candidate_text == "":
        candidate_text = default_path

    candidate = Path(candidate_text).expanduser()
    if not workspace.strict_mode:
        return candidate, None

    if workspace.error:
        return None, _strict_denial(workspace.error)

    root = workspace.root
    if root is None:
        return None, _strict_denial("workspace root is not configured")

    scoped = candidate if candidate.is_absolute() else root / candidate
    try:
        resolved = scoped.resolve(strict=False)
    except Exception as exc:
        return None, _strict_denial(f"path '{candidate_text}' could not be resolved: {exc}")

    if not _is_within_workspace(resolved, root):
        return (
            None,
            _strict_denial(
                f"path '{candidate_text}' resolves outside workspace root '{root}'"
            ),
        )
    return resolved, None


def _workspace_or_default(workspace: _WorkspaceContext | None) -> _WorkspaceContext:
    return workspace if workspace is not None else _WorkspaceContext(strict_mode=False)


def _candidate_within_workspace(path: Path, workspace: _WorkspaceContext) -> bool:
    if not workspace.strict_mode:
        return True
    root = workspace.root
    if root is None:
        return False
    try:
        return _is_within_workspace(path.resolve(strict=False), root)
    except Exception:
        return False


def _bash_disabled_message() -> str:
    return "bash is disabled in strict workspace mode (v0)."


def _read_file_schema() -> dict[str, Any]:
    return _schema(
        {
            "path": {"type": "string", "description": "Path to file to read"},
            "offset": {"type": "integer", "description": "Zero-based line offset"},
            "limit": {"type": "integer", "description": "Maximum lines to read (max 2000)"},
        },
        ["path"],
    )


async def _read_file_execute(
    path: str,
    offset: int = 0,
    limit: int = 2000,
    *,
    workspace: _WorkspaceContext | None = None,
) -> str:
    workspace_ctx = _workspace_or_default(workspace)
    file_path, denial = _resolve_tool_path(path, workspace=workspace_ctx)
    if denial is not None:
        return denial
    if file_path is None:
        return f"File not found: {path}"

    if not file_path.exists():
        return f"File not found: {path}"
    if not file_path.is_file():
        return f"Not a file: {path}"

    try:
        content = await asyncio.to_thread(file_path.read_text, encoding="utf-8", errors="replace")
    except Exception as exc:
        return f"Failed to read file: {exc}"

    start = max(0, int(offset or 0))
    max_lines = max(1, min(int(limit or 2000), 2000))
    selected = content.splitlines()[start : start + max_lines]
    return "\n".join(f"{line_no:>3}| {line}" for line_no, line in enumerate(selected, start + 1))


def _write_file_schema() -> dict[str, Any]:
    return _schema(
        {
            "path": {"type": "string", "description": "Path to file to write"},
            "content": {"type": "string", "description": "Content to write"},
        },
        ["path", "content"],
    )


async def _write_file_execute(
    path: str,
    content: str,
    *,
    workspace: _WorkspaceContext | None = None,
) -> str:
    workspace_ctx = _workspace_or_default(workspace)
    file_path, denial = _resolve_tool_path(path, workspace=workspace_ctx)
    if denial is not None:
        return denial
    if file_path is None:
        return f"Failed to write file: invalid path '{path}'"

    try:
        await asyncio.to_thread(file_path.parent.mkdir, parents=True, exist_ok=True)
        await asyncio.to_thread(file_path.write_text, content, encoding="utf-8")
    except Exception as exc:
        return f"Failed to write file: {exc}"
    return f"Wrote {len(content)} bytes to {path}"


def _edit_file_schema() -> dict[str, Any]:
    return _schema(
        {
            "path": {"type": "string", "description": "Path to file to edit"},
            "old_text": {"type": "string", "description": "Exact text to replace"},
            "new_text": {"type": "string", "description": "Replacement text"},
            "replace_all": {"type": "boolean", "description": "Replace every occurrence"},
        },
        ["path", "old_text", "new_text"],
    )


async def _edit_file_execute(
    path: str,
    old_text: str,
    new_text: str,
    replace_all: bool = False,
    *,
    workspace: _WorkspaceContext | None = None,
) -> str:
    if old_text == "":
        return "old_text cannot be empty"

    workspace_ctx = _workspace_or_default(workspace)
    file_path, denial = _resolve_tool_path(path, workspace=workspace_ctx)
    if denial is not None:
        return denial
    if file_path is None:
        return f"File not found: {path}"

    if not file_path.exists():
        return f"File not found: {path}"
    if not file_path.is_file():
        return f"Not a file: {path}"

    try:
        content = await asyncio.to_thread(file_path.read_text, encoding="utf-8", errors="replace")
    except Exception as exc:
        return f"Failed to read file: {exc}"

    count = content.count(old_text)
    if count == 0:
        return "old_text not found in file"

    if count > 1 and not replace_all:
        return (
            f"old_text appears {count} times. "
            "Set replace_all=true or provide more specific old_text."
        )

    replacement_count = count if replace_all else 1
    updated = content.replace(old_text, new_text, count if replace_all else 1)

    try:
        await asyncio.to_thread(file_path.write_text, updated, encoding="utf-8")
    except Exception as exc:
        return f"Failed to write file: {exc}"

    return f"Replaced {replacement_count} occurrence(s) in {path}"


def _glob_schema() -> dict[str, Any]:
    return _schema(
        {
            "pattern": {"type": "string", "description": "Glob pattern to match files"},
            "path": {"type": "string", "description": "Base directory to search"},
        },
        ["pattern"],
    )


async def _glob_execute(
    pattern: str,
    path: str | None = None,
    *,
    workspace: _WorkspaceContext | None = None,
) -> str:
    workspace_ctx = _workspace_or_default(workspace)
    base, denial = _resolve_tool_path(path, workspace=workspace_ctx, default_path=".")
    if denial is not None:
        return denial
    if base is None:
        return f"Path not found: {path or '.'}"

    if not base.exists():
        return f"Path not found: {base}"

    def _collect() -> list[Path]:
        if base.is_file():
            return [base] if fnmatch.fnmatch(base.name, pattern) else []
        files = [
            candidate
            for candidate in base.glob(pattern)
            if candidate.is_file() and _candidate_within_workspace(candidate, workspace_ctx)
        ]
        files.sort(key=lambda item: (item.stat().st_mtime, str(item)), reverse=True)
        return files[:500]

    try:
        matches = await asyncio.to_thread(_collect)
    except Exception as exc:
        return f"glob failed: {exc}"

    if base.is_file():
        return str(base) if matches else ""
    return "\n".join(str(candidate.relative_to(base)) for candidate in matches)


def _grep_schema() -> dict[str, Any]:
    return _schema(
        {
            "pattern": {"type": "string", "description": "Regex pattern to search for"},
            "path": {"type": "string", "description": "File or directory to search"},
            "include": {"type": "string", "description": "Glob filter for file paths"},
        },
        ["pattern"],
    )


async def _grep_execute(
    pattern: str,
    path: str | None = None,
    include: str | None = None,
    *,
    workspace: _WorkspaceContext | None = None,
) -> str:
    workspace_ctx = _workspace_or_default(workspace)
    base, denial = _resolve_tool_path(path, workspace=workspace_ctx, default_path=".")
    if denial is not None:
        return denial
    if base is None:
        return f"Path not found: {path or '.'}"

    if not base.exists():
        return f"Path not found: {base}"

    try:
        regex = re.compile(pattern)
    except re.error as exc:
        return f"Invalid regex: {exc}"

    def _search() -> list[str]:
        files = (
            [base]
            if base.is_file()
            else [candidate for candidate in base.rglob("*") if candidate.is_file()]
        )
        root = base.parent if base.is_file() else base
        results: list[str] = []

        for file_path in files:
            if not _candidate_within_workspace(file_path, workspace_ctx):
                continue
            rel = str(file_path.relative_to(root))
            if include and not fnmatch.fnmatch(rel, include):
                continue
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            display = str(file_path if base.is_file() else file_path.relative_to(base))
            for line_no, line in enumerate(content.splitlines(), 1):
                if regex.search(line):
                    results.append(f"{display}:{line_no}:{line}")
                    if len(results) >= 100:
                        return results
        return results

    try:
        return "\n".join(await asyncio.to_thread(_search))
    except Exception as exc:
        return f"grep failed: {exc}"


def _list_dir_schema() -> dict[str, Any]:
    return _schema(
        {
            "path": {
                "type": "string",
                "description": "Directory to list",
                "default": ".",
            },
            "show_hidden": {
                "type": "boolean",
                "description": "Include entries starting with '.'",
                "default": False,
            },
        },
        [],
    )


async def _list_dir_execute(
    path: str = ".",
    show_hidden: bool = False,
    *,
    workspace: _WorkspaceContext | None = None,
) -> str:
    workspace_ctx = _workspace_or_default(workspace)
    base, denial = _resolve_tool_path(path or ".", workspace=workspace_ctx, default_path=".")
    if denial is not None:
        return denial
    if base is None:
        return f"Path not found: {path or '.'}"

    if not base.exists():
        return f"Path not found: {base}"
    if not base.is_dir():
        return f"Not a directory: {base}"

    def _collect() -> str:
        lines: list[str] = []
        for entry in sorted(base.iterdir(), key=lambda item: item.name):
            if not show_hidden and entry.name.startswith("."):
                continue
            if entry.is_symlink():
                lines.append(f"symlink@  {entry.name}")
            elif entry.is_dir():
                lines.append(f"dir/  {entry.name}/")
            else:
                lines.append(f"file  {entry.name}")
        return "\n".join(lines)

    try:
        return await asyncio.to_thread(_collect)
    except Exception as exc:
        return f"list_dir failed: {exc}"


# === System Tools ===
def _bash_schema() -> dict[str, Any]:
    return _schema(
        {
            "command": {"type": "string", "description": "Shell command to execute"},
            "timeout": {"type": "integer", "description": "Timeout in seconds (default 120)"},
        },
        ["command"],
    )


def _truncate(text: str, max_chars: int = 30000) -> str:
    return text if len(text) <= max_chars else text[:max_chars] + "\n... (truncated)"


async def _bash_execute(
    command: str,
    timeout: int = 120,
    *,
    workspace: _WorkspaceContext | None = None,
) -> str:
    workspace_ctx = _workspace_or_default(workspace)
    if workspace_ctx.strict_mode:
        return _bash_disabled_message()

    try:
        proc = await asyncio.create_subprocess_shell(
            command, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
    except Exception as exc:
        return f"Failed to start command: {exc}"

    try:
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(), timeout=max(1, int(timeout or 120))
        )
    except TimeoutError:
        proc.kill()
        await proc.wait()
        return f"Command timed out after {timeout} seconds"

    output = ((stdout or b"") + (stderr or b"")).decode("utf-8", errors="replace")
    output = _truncate(output)
    if proc.returncode != 0:
        return f"{output}\nCommand exited with code {proc.returncode}".strip()
    return output or "(no output)"


# === Web Tools ===
def _web_search_schema() -> dict[str, Any]:
    return _schema(
        {
            "query": {"type": "string", "description": "Web search query"},
            "num_results": {"type": "integer", "description": "Number of results to return (1-20)"},
        },
        ["query"],
    )


def _parse_jsonrpc_result(raw_response: str) -> tuple[Any | None, str | None]:
    def _extract(obj: Any) -> tuple[Any | None, str | None]:
        if not isinstance(obj, dict):
            return None, "Could not parse Exa response"
        if "error" in obj:
            error = obj["error"]
            return None, str(error.get("message", error) if isinstance(error, dict) else error)
        if "result" in obj:
            return obj["result"], None
        return None, "Exa response missing result"

    for line in raw_response.splitlines():
        line = line.strip()
        if not line.startswith("data:"):
            continue
        payload = line[5:].strip()
        if not payload or payload == "[DONE]":
            continue
        try:
            return _extract(json.loads(payload))
        except json.JSONDecodeError:
            continue
    try:
        return _extract(json.loads(raw_response))
    except json.JSONDecodeError:
        return None, "Could not parse Exa response"


def _extract_mcp_text(result: Any) -> str:
    if isinstance(result, dict) and isinstance(result.get("content"), list):
        chunks = [
            item.get("text", "")
            for item in result["content"]
            if isinstance(item, dict) and item.get("type") == "text"
        ]
        if chunks:
            return "\n".join(chunk for chunk in chunks if chunk)
    return "" if result is None else str(result)


def _do_web_search_request(query: str, num_results: int) -> str:
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {
            "name": "web_search_exa",
            "arguments": {"query": query, "numResults": num_results},
        },
    }
    headers = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream"}
    if api_key := os.getenv("EXA_API_KEY"):
        headers["Authorization"] = f"Bearer {api_key}"

    request = urllib.request.Request(
        _EXA_ENDPOINT, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST"
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.read().decode("utf-8", errors="replace")


async def _web_search_execute(query: str, num_results: int = 5) -> str:
    text_query = query.strip()
    if not text_query:
        return "query is required"

    count = max(1, min(20, int(num_results or 5)))

    try:
        raw_response = await asyncio.to_thread(_do_web_search_request, text_query, count)
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace") if hasattr(exc, "read") else ""
        return f"web_search HTTP {exc.code}: {body[:200] or exc.reason}"
    except urllib.error.URLError as exc:
        return f"web_search request failed: {exc.reason}"
    except Exception as exc:
        return f"web_search failed: {exc}"

    result, error = _parse_jsonrpc_result(raw_response)
    if error:
        return f"web_search error: {error}"

    formatted = _extract_mcp_text(result).strip()
    return (
        f"Web search results for: {text_query}\n\n{formatted}"
        if formatted
        else f"No search results for: {text_query}"
    )


def _fetch_schema() -> dict[str, Any]:
    return _schema(
        {
            "url": {"type": "string", "description": "URL to fetch"},
            "timeout": {"type": "integer", "description": "Timeout in seconds (default 30)"},
        },
        ["url"],
    )


async def _fetch_execute(url: str, timeout: int = 30) -> str:
    if not url:
        return "url is required"

    headers = {
        "User-Agent": "Otto/1.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }

    try:
        request = urllib.request.Request(url, headers=headers, method="GET")
        with urllib.request.urlopen(request, timeout=max(1, int(timeout or 30))) as response:
            content = response.read().decode("utf-8", errors="replace")
            content_type = response.headers.get("Content-Type", "")
            if "html" in content_type.lower():
                content = re.sub(r"<[^>]+>", "", content)
                content = re.sub(r"\s+", " ", content).strip()
            content = _truncate(content, max_chars=50000)
            return f"URL: {url}\nContent-Type: {content_type}\n\n{content}"
    except urllib.error.HTTPError as exc:
        return f"fetch HTTP {exc.code}: {exc.reason}"
    except urllib.error.URLError as exc:
        return f"fetch request failed: {exc.reason}"
    except Exception as exc:
        return f"fetch failed: {exc}"


# === Skill Tools ===
def _create_skill_schema() -> dict[str, Any]:
    return _schema(
        {
            "name": {"type": "string", "description": "Skill directory name"},
            "description": {"type": "string", "description": "Skill description"},
            "content": {
                "type": "string",
                "description": "Markdown body for SKILL.md (after frontmatter)",
            },
            "license": {"type": "string", "description": "Optional skill license"},
            "compatibility": {"type": "string", "description": "Optional compatibility metadata"},
            "scripts": {
                "type": "object",
                "description": "Optional map of scripts/<filename> to file content",
                "additionalProperties": {"type": "string"},
            },
        },
        ["name", "description", "content"],
    )


async def _create_skill_execute(
    name: str,
    description: str,
    content: str,
    license: str | None = None,
    compatibility: str | None = None,
    scripts: dict[str, Any] | None = None,
) -> str:
    import yaml

    from otto.skills import validate_frontmatter

    frontmatter: dict[str, Any] = {"name": name, "description": description}
    if license is not None:
        frontmatter["license"] = license
    if compatibility is not None:
        frontmatter["compatibility"] = compatibility

    errors = validate_frontmatter(frontmatter)
    if errors:
        return "\n".join(errors)

    script_map = scripts if scripts is not None else {}
    if not isinstance(script_map, dict):
        return "scripts must be an object mapping filename to content"

    for filename, script_content in script_map.items():
        if not isinstance(filename, str) or not filename.strip():
            return "scripts keys must be non-empty strings"
        if not isinstance(script_content, str):
            return f"scripts entry '{filename}' must be a string"
        script_path = Path(filename)
        if script_path.is_absolute() or ".." in script_path.parts:
            return f"Invalid script filename: {filename}"

    frontmatter_text = yaml.dump(frontmatter, sort_keys=False).strip()
    skill_text = f"---\n{frontmatter_text}\n---\n\n{content}"
    skill_dir = OTTO_HOME / "skills" / name
    skill_file = skill_dir / "SKILL.md"

    try:
        await asyncio.to_thread(skill_dir.mkdir, parents=True, exist_ok=True)
        await asyncio.to_thread(skill_file.write_text, skill_text, encoding="utf-8")
        if script_map:
            scripts_dir = skill_dir / "scripts"
            await asyncio.to_thread(scripts_dir.mkdir, parents=True, exist_ok=True)
            for filename, script_content in script_map.items():
                target = scripts_dir / filename
                await asyncio.to_thread(target.parent.mkdir, parents=True, exist_ok=True)
                await asyncio.to_thread(target.write_text, script_content, encoding="utf-8")
    except Exception as exc:
        return f"Failed to create skill: {exc}"

    return f"Created skill: {skill_file}"


def _use_skill_schema() -> dict[str, Any]:
    return _schema({"name": {"type": "string", "description": "Skill name to load"}}, ["name"])


async def _use_skill_execute(name: str) -> str:
    from otto.skills import read_skill

    try:
        content = read_skill(OTTO_HOME / "skills", name)
    except Exception as exc:
        return f"Failed to load skill: {exc}"
    if content is None:
        return f"Skill not found: {name}"
    return content


# === Memory Tools ===
def _memory_search_schema() -> dict[str, Any]:
    return _schema(
        {
            "query": {"type": "string", "description": "Search query"},
            "limit": {
                "type": "integer",
                "description": "Maximum number of matches to return",
                "default": 5,
            },
        },
        ["query"],
    )


async def _memory_search_execute(memory: Memory, query: str, limit: int = 5) -> str:
    results = memory.search(query, limit=int(limit if limit is not None else 5))
    return "\n".join(
        f"{str(item.get('key', ''))}: {str(item.get('snippet', ''))}" for item in results
    )


def _memory_store_schema() -> dict[str, Any]:
    return _schema(
        {
            "key": {"type": "string", "description": "Unique memory key"},
            "content": {"type": "string", "description": "Text content to store"},
        },
        ["key", "content"],
    )


async def _memory_store_execute(memory: Memory, key: str, content: str) -> str:
    memory.store(key, content)
    return f"Stored memory entry: {key}"
