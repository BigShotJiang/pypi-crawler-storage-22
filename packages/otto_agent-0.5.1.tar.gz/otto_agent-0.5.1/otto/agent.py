from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

import litellm

from otto.auth import AuthStorage
from otto.log import get_logger
from otto.providers import OAuthStreamProvider, resolve_provider

log = get_logger("otto.agent")

_CLAUDE_CODE_MAX_TURNS = 80
_CLAUDE_CODE_MAX_TOOL_ROUNDS = 60
_DEFAULT_MAX_OUTPUT_TOKENS = 16384
_MAX_TOOL_RESULT_CHARS = 2400


def _max_output_tokens(model: str) -> int:
    """Compute max output tokens as model_max / 3, with a floor of 16384."""
    litellm_model = model.split("/", 1)[-1] if "/" in model else model
    try:
        info = litellm.get_model_info(litellm_model)
        max_output = int((info or {}).get("max_output_tokens") or 0)
    except Exception:
        max_output = 0
    if max_output > 0:
        return max(max_output // 3, _DEFAULT_MAX_OUTPUT_TOKENS)
    return _DEFAULT_MAX_OUTPUT_TOKENS


litellm.suppress_debug_info = True
for _logger_name in ("litellm", "LiteLLM"):
    logging.getLogger(_logger_name).setLevel(logging.CRITICAL)


@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    parameters: dict
    execute: Callable[..., Awaitable[str]]


@dataclass(frozen=True)
class Turn:
    text: str | None
    tool_calls: list[dict]
    usage: dict


@dataclass(frozen=True)
class AgentResult:
    text: str
    turns: list[Turn]
    total_usage: dict


async def run(
    model: str,
    system: str,
    messages: list[dict],
    tools: list[Tool],
    *,
    auth_storage: AuthStorage | None = None,
    max_turns: int = 50,
    on_text: Callable[[str], None] | None = None,
    on_tool_start: Callable[[str, dict], None] | None = None,
    on_tool_end: Callable[[str, str], None] | None = None,
) -> AgentResult:
    tool_schemas = [_tool_to_schema(tool) for tool in tools]
    tools_by_name = {tool.name: tool for tool in tools}

    turns: list[Turn] = []
    total_prompt_tokens = 0
    total_completion_tokens = 0
    total_cost = 0.0
    final_text = ""

    if model.lower().startswith("claude-code/"):
        max_turns = min(max_turns, _CLAUDE_CODE_MAX_TURNS)

    if max_turns <= 0:
        return AgentResult(
            text=final_text,
            turns=turns,
            total_usage={
                "prompt_tokens": total_prompt_tokens,
                "completion_tokens": total_completion_tokens,
                "cost": total_cost,
            },
        )

    is_claude_code = model.lower().startswith("claude-code/")
    tool_rounds = 0
    clean_exit = False
    provider = await resolve_provider(model, system, auth_storage=auth_storage)

    for turn_index in range(max_turns):
        try:
            effective_system = system
            if isinstance(provider, OAuthStreamProvider):
                effective_system = provider.effective_system(system)
            messages = _trim_to_context_window(model, effective_system, messages)
            log.info("llm request", model=model, turn=turn_index, messages=len(messages))
            try:
                response_stream = await provider.stream_completion(
                    model=model,
                    messages=_messages_for_request(effective_system, messages),
                    tools=tool_schemas,
                    tool_choice="auto" if tool_schemas else None,
                    max_tokens=_max_output_tokens(model) if is_claude_code else None,
                )
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                log.error("llm request failed", model=model, turn=turn_index, error=str(exc))
                raise
            turn_text, streamed_tool_calls, usage_obj, finish_reason = await _consume_stream(
                response_stream, on_text
            )
            usage = _normalize_usage(usage_obj)

            total_prompt_tokens += usage["prompt_tokens"]
            total_completion_tokens += usage["completion_tokens"]
            total_cost += _completion_cost(
                model=model,
                prompt_tokens=usage["prompt_tokens"],
                completion_tokens=usage["completion_tokens"],
            )

            normalized_calls = _normalize_tool_calls(streamed_tool_calls, turn_index)
            log.info(
                "llm response",
                model=model,
                turn=turn_index,
                prompt_tokens=usage["prompt_tokens"],
                completion_tokens=usage["completion_tokens"],
                total_prompt_tokens=total_prompt_tokens,
                total_completion_tokens=total_completion_tokens,
                tool_calls=len(normalized_calls),
                tool_rounds=tool_rounds,
                has_text=turn_text is not None,
            )

            if not normalized_calls:
                if finish_reason == "max_tokens":
                    log.warning(
                        "response truncated by max_tokens",
                        model=model,
                        turn=turn_index,
                    )
                    turn_text = (turn_text or "") + (
                        "\n\n(Response was truncated due to output token limit)"
                    )
                elif finish_reason == "incomplete":
                    turn_text = (turn_text or "") + "\n\n(Response may be incomplete)"
                turns.append(Turn(text=turn_text, tool_calls=[], usage=usage))
                final_text = turn_text or final_text
                clean_exit = True
                break

            tool_rounds += 1
            if is_claude_code and tool_rounds > _CLAUDE_CODE_MAX_TOOL_ROUNDS:
                log.warning(
                    "tool round limit reached",
                    model=model,
                    turn=turn_index,
                    tool_rounds=tool_rounds,
                    max_tool_rounds=_CLAUDE_CODE_MAX_TOOL_ROUNDS,
                )
                turn_text = (turn_text or "") + "\n\n(Stopped: reached tool round limit)"
                turns.append(Turn(text=turn_text, tool_calls=[], usage=usage))
                final_text = turn_text or final_text
                clean_exit = True
                break

            assistant_tool_calls = []
            for call in normalized_calls:
                tool_call_payload: dict[str, Any] = {
                    "id": call["id"],
                    "type": "function",
                    "function": {"name": call["name"], "arguments": call["arguments"]},
                }
                thought_signature = str(call.get("thought_signature", "")).strip()
                if thought_signature:
                    tool_call_payload["extra_content"] = {
                        "google": {"thought_signature": thought_signature}
                    }
                assistant_tool_calls.append(tool_call_payload)
            assistant_message: dict[str, Any] = {
                "role": "assistant",
                "tool_calls": assistant_tool_calls,
            }
            if turn_text is not None:
                assistant_message["content"] = turn_text
            messages.append(assistant_message)

            executed_calls = await asyncio.gather(
                *[
                    _execute_tool_call(
                        call=call,
                        tools_by_name=tools_by_name,
                        on_tool_start=on_tool_start,
                        on_tool_end=on_tool_end,
                    )
                    for call in normalized_calls
                ]
            )

            turn_tool_calls: list[dict] = []
            for executed in executed_calls:
                turn_tool_calls.append(
                    {
                        "name": executed["name"],
                        "args": executed["args"],
                        "result": executed["result"],
                    }
                )
                tool_result_for_model = _compact_tool_result(executed["result"])
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": executed["id"],
                        "name": executed["name"],
                        "content": tool_result_for_model,
                    }
                )

            turns.append(Turn(text=turn_text, tool_calls=turn_tool_calls, usage=usage))
            final_text = turn_text or final_text
        except asyncio.CancelledError:
            log.info("agent cancelled", turn=turn_index)
            raise

    if not clean_exit and max_turns > 0:
        # Loop exhausted — make one final call without tools to get a summary
        try:
            effective_system = system
            if isinstance(provider, OAuthStreamProvider):
                effective_system = provider.effective_system(system)
            messages = _trim_to_context_window(model, effective_system, messages)
            summary_stream = await provider.stream_completion(
                model=model,
                messages=_messages_for_request(effective_system, messages),
                tools=[],
                tool_choice=None,
                max_tokens=_max_output_tokens(model) if is_claude_code else None,
            )
            summary_text, _, summary_usage, _ = await _consume_stream(summary_stream, on_text)
            if summary_text:
                final_text = summary_text
                usage = _normalize_usage(summary_usage)
                total_prompt_tokens += usage["prompt_tokens"]
                total_completion_tokens += usage["completion_tokens"]
                turns.append(Turn(text=summary_text, tool_calls=[], usage=usage))
        except Exception as exc:
            log.warning("summary call after loop exhaustion failed", error=str(exc))

        if not final_text or not final_text.strip():
            final_text = "(Stopped: reached maximum turns without producing a response)"

    return AgentResult(
        text=final_text,
        turns=turns,
        total_usage={
            "prompt_tokens": total_prompt_tokens,
            "completion_tokens": total_completion_tokens,
            "cost": total_cost,
        },
    )


def _tool_to_schema(tool: Tool) -> dict[str, dict[str, Any] | str]:
    return {
        "type": "function",
        "function": {
            "name": tool.name,
            "description": tool.description,
            "parameters": tool.parameters,
        },
    }


def _messages_for_request(system: str, messages: list[dict]) -> list[dict]:
    if not system:
        return list(messages)
    return [{"role": "system", "content": system}, *messages]


def _trim_to_context_window(model: str, system: str, messages: list[dict]) -> list[dict]:
    min_turn_messages = 8

    # Strip custom routing prefixes (e.g. "claude-code/claude-haiku-4-5" → "claude-haiku-4-5")
    # so litellm can resolve model metadata and count tokens correctly.
    litellm_model = model.split("/", 1)[-1] if "/" in model else model

    try:
        model_info = litellm.get_model_info(litellm_model)
        max_input_tokens = int((model_info or {}).get("max_input_tokens") or 0)
    except Exception:
        max_input_tokens = 0

    if max_input_tokens <= 0:
        if "claude" in model.lower():
            max_input_tokens = 200_000
        elif "gpt-4" in model.lower():
            max_input_tokens = 128_000
        else:
            return messages

    threshold = max_input_tokens * 0.8
    request_messages = _messages_for_request(system, messages)
    try:
        current_tokens = int(
            litellm.token_counter(model=litellm_model, messages=request_messages) or 0
        )
    except Exception:
        # Conservative fallback: ~500 tokens per message
        current_tokens = len(request_messages) * 500

    if current_tokens <= threshold:
        return messages

    original_tokens = current_tokens
    dropped_messages = 0

    while current_tokens > threshold:
        turn_indices = [
            idx
            for idx, message in enumerate(messages)
            if message.get("role") in {"user", "assistant"}
        ]
        if len(turn_indices) - 2 < min_turn_messages:
            break

        next_turn_index = turn_indices[2]
        dropped_messages += next_turn_index
        del messages[:next_turn_index]

        try:
            current_tokens = int(
                litellm.token_counter(
                    model=litellm_model,
                    messages=_messages_for_request(system, messages),
                )
                or 0
            )
        except Exception:
            current_tokens = len(_messages_for_request(system, messages)) * 500

    if dropped_messages > 0:
        log.warning(
            "context trimmed",
            model=model,
            original_tokens=original_tokens,
            trimmed_tokens=current_tokens,
            messages_dropped=dropped_messages,
        )

    return messages


async def _consume_stream(
    stream: Any, on_text: Callable[[str], None] | None
) -> tuple[str | None, list[dict[str, str]], Any, str | None]:
    text_parts: list[str] = []
    tool_calls: list[dict[str, str]] = []
    usage_obj: Any = None
    finish_reason: str | None = None

    async for chunk in stream:
        chunk_usage = getattr(chunk, "usage", None)
        if chunk_usage is not None:
            usage_obj = chunk_usage

        choices = getattr(chunk, "choices", None)
        if not choices:
            continue

        choice = choices[0]
        chunk_finish_reason = getattr(choice, "finish_reason", None)
        if chunk_finish_reason is not None:
            finish_reason = chunk_finish_reason

        delta = getattr(choice, "delta", None)
        if delta is None:
            continue

        content = getattr(delta, "content", None)
        if content:
            text_parts.append(content)
            if on_text is not None:
                on_text(content)

        delta_tool_calls = getattr(delta, "tool_calls", None) or []
        for delta_tool_call in delta_tool_calls:
            index = getattr(delta_tool_call, "index", None)
            if index is None or index < 0:
                continue

            while len(tool_calls) <= index:
                tool_calls.append(
                    {
                        "id": "",
                        "name": "",
                        "arguments": "",
                        "thought_signature": "",
                    }
                )

            current = tool_calls[index]
            tool_call_id = getattr(delta_tool_call, "id", None)
            if tool_call_id:
                current["id"] = tool_call_id

            thought_signature = getattr(delta_tool_call, "thought_signature", None)
            if thought_signature:
                current["thought_signature"] = thought_signature

            function = getattr(delta_tool_call, "function", None)
            if function is None:
                continue

            function_name = getattr(function, "name", None)
            if function_name:
                current["name"] = function_name

            function_arguments = getattr(function, "arguments", None)
            if function_arguments:
                current["arguments"] += function_arguments

    text = "".join(text_parts)
    if finish_reason is None:
        finish_reason = "incomplete"
    return (text if text else None), tool_calls, usage_obj, finish_reason


def _normalize_tool_calls(
    tool_calls: list[dict[str, str]], turn_index: int
) -> list[dict[str, str]]:
    normalized: list[dict[str, str]] = []
    for index, tool_call in enumerate(tool_calls):
        name = tool_call.get("name", "").strip()
        if not name:
            log.warning("skipping tool call with empty name", turn=turn_index, index=index)
            continue
        normalized_item = {
            "id": tool_call.get("id") or f"tool_call_{turn_index}_{index}",
            "name": name,
            "arguments": tool_call.get("arguments", ""),
        }
        thought_signature = tool_call.get("thought_signature", "").strip()
        if thought_signature:
            normalized_item["thought_signature"] = thought_signature
        normalized.append(normalized_item)
    return normalized


async def _execute_tool_call(
    *,
    call: dict[str, str],
    tools_by_name: dict[str, Tool],
    on_tool_start: Callable[[str, dict], None] | None,
    on_tool_end: Callable[[str, str], None] | None,
) -> dict[str, Any]:
    tool_name = call["name"]

    try:
        parsed_args = _parse_tool_arguments(call["arguments"])
    except ValueError as error:
        parsed_args = {}
        result = str(error)
        if on_tool_start is not None:
            on_tool_start(tool_name, parsed_args)
        if on_tool_end is not None:
            on_tool_end(tool_name, result)
        return {"id": call["id"], "name": tool_name, "args": parsed_args, "result": result}

    if on_tool_start is not None:
        on_tool_start(tool_name, parsed_args)

    tool = tools_by_name.get(tool_name)
    if tool is None:
        log.warning("unknown tool", tool=tool_name)
        result = f"Unknown tool name: {tool_name}"
        if on_tool_end is not None:
            on_tool_end(tool_name, result)
        return {"id": call["id"], "name": tool_name, "args": parsed_args, "result": result}

    log.info("tool executing", tool=tool_name, **_log_args(parsed_args))
    try:
        execution_result = await tool.execute(**parsed_args)
        result = str(execution_result)
    except TypeError as error:
        error_msg = str(error)
        if "required" in error_msg and "argument" in error_msg:
            log.warning("tool missing required args", tool=tool_name, error=error_msg)
            required = _get_required_params(tool)
            result = (
                f"Error: missing required arguments for '{tool_name}'. "
                f"Required parameters: {required}. "
                f"You provided: {list(parsed_args.keys()) or '(none)'}. "
                f"Please retry with the required arguments."
            )
        else:
            log.error("tool failed", tool=tool_name, error=error_msg)
            result = f"Tool execution error: {error}"
    except Exception as error:  # pragma: no cover - defensive path for arbitrary tool errors
        log.error("tool failed", tool=tool_name, error=str(error))
        result = f"Tool execution error: {error}"

    if on_tool_end is not None:
        on_tool_end(tool_name, result)

    return {"id": call["id"], "name": tool_name, "args": parsed_args, "result": result}


def _get_required_params(tool: Tool) -> list[str]:
    props = tool.parameters.get("properties", {})
    required = tool.parameters.get("required", [])
    if required:
        return list(required)
    return [k for k, v in props.items() if not v.get("default")]


def _log_args(args: dict) -> dict[str, str]:
    """Extract loggable fields from tool args (paths, commands, queries — not content)."""
    out: dict[str, str] = {}
    for key in ("path", "command", "query", "pattern", "key", "name", "url", "text"):
        if key in args:
            value = str(args[key])
            out[key] = value[:120] if len(value) > 120 else value
    return out


def _compact_tool_result(result: str) -> str:
    if len(result) <= _MAX_TOOL_RESULT_CHARS:
        return result
    omitted = len(result) - _MAX_TOOL_RESULT_CHARS
    return (
        result[:_MAX_TOOL_RESULT_CHARS]
        + f"\n\n[truncated tool output: omitted {omitted} characters]"
    )


def _parse_tool_arguments(arguments: str) -> dict:
    raw = arguments.strip()
    if not raw:
        return {}

    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as error:
        raise ValueError(f"Tool argument JSON parse error: {error.msg}") from error

    if not isinstance(parsed, dict):
        raise ValueError("Tool argument JSON parse error: expected a JSON object")

    return parsed


def _normalize_usage(usage_obj: Any) -> dict[str, int]:
    prompt_tokens = _get_usage_value(usage_obj, "prompt_tokens")
    completion_tokens = _get_usage_value(usage_obj, "completion_tokens")
    return {"prompt_tokens": prompt_tokens, "completion_tokens": completion_tokens}


def _get_usage_value(usage_obj: Any, field: str) -> int:
    if usage_obj is None:
        return 0

    value: Any
    if isinstance(usage_obj, dict):
        value = usage_obj.get(field, 0)
    else:
        value = getattr(usage_obj, field, 0)

    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _completion_cost(model: str, prompt_tokens: int, completion_tokens: int) -> float:
    completion_cost_fn = getattr(litellm, "completion_cost", None)
    if not callable(completion_cost_fn):
        return 0.0

    try:
        cost = completion_cost_fn(
            model=model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
        )
    except Exception:
        return 0.0

    try:
        return float(cost)
    except (TypeError, ValueError):
        return 0.0
