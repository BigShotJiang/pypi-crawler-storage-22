from __future__ import annotations

import asyncio
import fnmatch
import inspect
import logging
import re
from collections.abc import Awaitable, Callable
from typing import Any, Protocol

from otto.agent import Tool, run
from otto.auth import AuthStorage
from otto.config import Config, save_config
from otto.gateway import Gateway
from otto.memory import Memory
from otto.prompts import (
    IDENTITY_KEY,
    build_system_prompt,
)
from otto.scheduler import Scheduler
from otto.sessions import Session, SessionStore, _now_iso
from otto.tools import create_session_tools

# Reverse of auth/registry._PREFIX_MAP: litellm_provider -> otto_prefix
_OTTO_PREFIX_MAP: dict[str, str] = {
    "anthropic": "claude-code",
    "vertex_ai": "gemini-cli",
    "google": "gemini-cli",
}

_DEFAULT_MODEL_PATTERNS: list[str] = [
    "claude-sonnet-*",
    "claude-haiku-*",
    "gpt-4o*",
    "gemini-2.5*",
]

_MAX_PICKER_MODELS = 20


def _to_otto_model_id(litellm_key: str) -> str:
    """Convert a litellm model key to an Otto-prefixed model identifier."""
    if "/" in litellm_key:
        provider, model = litellm_key.split("/", 1)
    else:
        provider, model = "", litellm_key
    otto_prefix = _OTTO_PREFIX_MAP.get(provider)
    if otto_prefix:
        return f"{otto_prefix}/{model}"
    return litellm_key


def _make_display_name(model_key: str) -> str:
    """Build a human-readable display name from a litellm model key."""
    # Strip provider prefix
    if "/" in model_key:
        _, name = model_key.split("/", 1)
    else:
        name = model_key
    # Remove date suffixes like -20250514
    name = re.sub(r"-\d{8}$", "", name)
    # Replace hyphens with spaces, titlecase
    return name.replace("-", " ").replace("_", " ").title()


def _dedup_base_name(key: str) -> str:
    """Return the base name without dated suffix for dedup grouping."""
    if "/" in key:
        _, name = key.split("/", 1)
    else:
        name = key
    return re.sub(r"-\d{8}$", "", name)


def _build_model_presets(model_list: list[str]) -> list[tuple[str, str]]:
    """Build model presets dynamically from litellm's model registry.

    Returns a list of (display_name, otto_model_id) tuples.
    """
    try:
        import litellm
    except ImportError:
        return []

    patterns = model_list if model_list else _DEFAULT_MODEL_PATTERNS
    all_keys = list(litellm.model_cost.keys())

    # Filter keys matching any pattern
    matched: list[str] = []
    for key in all_keys:
        # Match against the model name part (without provider prefix)
        if "/" in key:
            _, model_part = key.split("/", 1)
        else:
            model_part = key
        for pattern in patterns:
            if fnmatch.fnmatch(model_part, pattern) or fnmatch.fnmatch(key, pattern):
                matched.append(key)
                break

    # Deduplicate: for models with dated versions, keep only the latest
    base_groups: dict[str, list[str]] = {}
    for key in matched:
        base = _dedup_base_name(key)
        base_groups.setdefault(base, []).append(key)

    deduped: list[str] = []
    for group in base_groups.values():
        # Sort to get the latest date suffix last; pick it
        group.sort()
        deduped.append(group[-1])

    # Build display name + otto ID pairs
    results: list[tuple[str, str]] = []
    for key in deduped:
        display = _make_display_name(key)
        otto_id = _to_otto_model_id(key)
        results.append((display, otto_id))

    # Sort by provider then display name
    def _sort_key(item: tuple[str, str]) -> tuple[str, str]:
        otto_id = item[1]
        if "/" in otto_id:
            provider, _ = otto_id.split("/", 1)
        else:
            provider = ""
        return (provider, item[0])

    results.sort(key=_sort_key)

    return results[:_MAX_PICKER_MODELS]


class Renderer(Protocol):
    def on_text(self, chunk: str) -> None:
        """Receive a streaming text chunk."""
        ...

    def on_tool_start(self, name: str, args: dict) -> None:
        """Handle tool execution start."""
        ...

    def on_tool_end(self, name: str, result: str) -> None:
        """Handle tool execution completion."""
        ...

    async def send_text(self, text: str) -> None:
        """Send a complete text message."""
        ...

    async def send_with_buttons(self, text: str, buttons: list[list[tuple[str, str]]]) -> None:
        """Send text with optional inline buttons. buttons: list of rows, each row is list of (label, callback_data) tuples."""
        ...

    async def show_error(self, error: str) -> None:
        """Display an error message."""
        ...

    async def send_file(self, path: str, caption: str | None = None) -> None:
        """Send a file to the user."""
        ...

    async def flush(self) -> None:
        """Flush any buffered content."""
        ...


type CommandHandler = Callable[["Chat", str, str, str | None, "Renderer"], Awaitable[None]]


HELP_CATEGORIES: dict[str, dict[str, Any]] = {
    "chat": {
        "label": "Chat",
        "summary": "New, clear, stop",
        "title": "Chat Commands",
        "commands": [
            ("/new", "Start fresh session"),
            ("/clear", "Clear session history"),
            ("/stop", "Cancel current response"),
        ],
    },
    "ai": {
        "label": "AI",
        "summary": "Model, status, tools",
        "title": "AI Commands",
        "commands": [
            ("/model", "Show or change current model"),
            ("/status", "System status"),
            ("/tools", "List available tools"),
        ],
    },
    "info": {
        "label": "Info",
        "summary": "History, memory",
        "title": "Info Commands",
        "commands": [
            ("/history", "Show session info"),
            ("/help", "Show this help menu"),
            ("/status", "Show model and memory status"),
        ],
    },
}

HELP_QUICK_COMMANDS = ["status", "new", "model"]


def get_help_data() -> dict[str, Any]:
    """Return structured help data used by command + callback handlers."""
    categories: dict[str, dict[str, Any]] = {}
    for key, value in HELP_CATEGORIES.items():
        categories[key] = {
            "label": value["label"],
            "summary": value["summary"],
            "title": value["title"],
            "commands": list(value["commands"]),
        }
    return {
        "title": "Otto Commands",
        "categories": categories,
        "quick_launch": list(HELP_QUICK_COMMANDS),
    }


def build_help_main_view() -> tuple[str, list[list[tuple[str, str]]]]:
    help_data = get_help_data()
    categories: dict[str, dict[str, Any]] = help_data["categories"]
    category_order = ["chat", "ai", "info"]
    lines = [
        "<b>Otto Commands</b>",
        "",
    ]
    for key in category_order:
        category = categories[key]
        lines.append(f"<b>{category['label']}</b> — {category['summary']}")
    lines.extend(["", "Tap a category below."])
    buttons = [
        [(categories[key]["label"], f"help:{key}") for key in category_order],
        [(f"/{command}", f"help:run:{command}") for command in help_data["quick_launch"]],
    ]
    return "\n".join(lines), buttons


def build_help_category_view(category_key: str) -> tuple[str, list[list[tuple[str, str]]]] | None:
    help_data = get_help_data()
    categories: dict[str, dict[str, Any]] = help_data["categories"]
    category = categories.get(category_key)
    if category is None:
        return None
    lines = [f"<b>{category['title']}</b>", ""]
    for command, description in category["commands"]:
        lines.append(f"{command} — {description}")
    buttons = [[("« Back", "help:back")]]
    return "\n".join(lines), buttons


def build_help_plaintext() -> str:
    help_data = get_help_data()
    categories: dict[str, dict[str, Any]] = help_data["categories"]
    lines = ["Available commands:"]
    for category_key in ["chat", "ai", "info"]:
        category = categories[category_key]
        for command, description in category["commands"]:
            lines.append(f"{command} - {description}")
    return "\n".join(lines)


async def _cmd_help(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = chat, chat_id, args, bot_id
    html_text, buttons = build_help_main_view()
    plain_text = build_help_plaintext()
    try:
        result = renderer.send_with_buttons(html_text, buttons)
    except AttributeError:
        await renderer.send_text(plain_text)
        return
    if inspect.isawaitable(result):
        await result
        return
    await renderer.send_text(plain_text)


async def _cmd_status(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    context_key = chat._context_key(chat_id, bot_id=bot_id)
    model = chat._model_overrides.get(context_key, chat._config.agent.model)
    session = chat._load_session(chat_id, bot_id=bot_id)
    tools = chat._gateway.tools()
    html_lines = [
        "<b>Otto Status</b>",
        "",
        f"<b>Model:</b>  {model}",
        f"<b>Session:</b>  {len(session.messages)} messages",
        f"<b>Tools:</b>  {len(tools)} registered",
        "<b>Memory:</b>  active",
    ]
    plain_lines = [
        "Otto Status",
        "",
        f"Model: {model}",
        f"Messages: {len(session.messages)}",
        f"Tools: {len(tools)} registered",
        "Memory: active",
    ]
    buttons = [
        [("Change Model", "status:model"), ("New Session", "status:new")],
        [("Refresh", "status:refresh")],
    ]
    html_text = "\n".join(html_lines)
    plain_text = "\n".join(plain_lines)
    try:
        result = renderer.send_with_buttons(html_text, buttons)
    except AttributeError:
        await renderer.send_text(plain_text)
        return
    if inspect.isawaitable(result):
        await result
        return
    await renderer.send_text(plain_text)


async def _cmd_model(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    context_key = chat._context_key(chat_id, bot_id=bot_id)
    model_name = args.strip()
    if model_name:
        chat._model_overrides[context_key] = model_name
        _persist_model(chat._config, model_name, bot_id=bot_id)
        text = (
            f"Model set: {model_name}"
            if inspect.iscoroutinefunction(getattr(renderer, "send_with_buttons", None))
            else f"Model set for this session: {model_name}"
        )
        await renderer.send_text(text)
        return
    current = chat._model_overrides.get(context_key, chat._config.agent.model)
    presets = _build_model_presets(chat._config.agent.model_list)
    if not presets:
        # Fallback when litellm is unavailable
        presets = [
            ("Claude Sonnet", "claude-code/claude-sonnet-4-5-20250514"),
            ("Claude Haiku", "claude-code/claude-haiku-4-5-20251001"),
            ("GPT-4o", "gpt-4o"),
            ("GPT-4o Mini", "gpt-4o-mini"),
        ]
    text = f"<b>Current Model</b>\n{current}\n\nSelect a model:"
    buttons = [
        [(label, f"model:{model_id}") for label, model_id in presets[i : i + 2]]
        for i in range(0, len(presets), 2)
    ]
    buttons.append([("Custom...", "model:custom")])
    buttons.append([("Cancel", "model:cancel")])
    try:
        result = renderer.send_with_buttons(text, buttons)
    except AttributeError:
        await renderer.send_text(f"Current model: {current}")
        return
    if inspect.isawaitable(result):
        await result
        return
    await renderer.send_text(f"Current model: {current}")


def _persist_model(config: Config, model: str, *, bot_id: str | None = None) -> None:
    """Persist model selection to config.toml."""
    if bot_id:
        # Find the matching bot and update its model
        new_bots = []
        for bot_cfg in config.telegram.bots:
            if bot_cfg.alias == bot_id:
                new_bot = object.__new__(type(bot_cfg))
                object.__setattr__(new_bot, "alias", bot_cfg.alias)
                object.__setattr__(new_bot, "token", bot_cfg.token)
                object.__setattr__(new_bot, "model", model)
                new_bots.append(new_bot)
            else:
                new_bots.append(bot_cfg)
        tc = config.telegram
        new_tc = type(tc)(
            token=tc.token,
            owner_id=tc.owner_id,
            allowed_users=tc.allowed_users,
            bootstrap=tc.bootstrap,
            bots=new_bots,
        )
        object.__setattr__(config, "telegram", new_tc)
    else:
        new_agent = type(config.agent)(
            model=model,
            model_list=config.agent.model_list,
            history_tool_results_keep=config.agent.history_tool_results_keep,
        )
        object.__setattr__(config, "agent", new_agent)
    try:
        save_config(config)
    except Exception:
        pass


async def _cmd_new(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    now = _now_iso()
    session = Session(chat_id=chat_id, messages=[], created_at=now, updated_at=now, bot_id=bot_id)
    chat._save_session(session, bot_id=bot_id)
    prefix = chat._memory_key(f"chat:{chat_id}:", bot_id=bot_id)
    chat._memory.delete_prefix(prefix)
    await renderer.send_text("New session started.")


async def _cmd_clear(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    now = _now_iso()
    session = Session(chat_id=chat_id, messages=[], created_at=now, updated_at=now, bot_id=bot_id)
    chat._save_session(session, bot_id=bot_id)
    prefix = chat._memory_key(f"chat:{chat_id}:", bot_id=bot_id)
    chat._memory.delete_prefix(prefix)
    await renderer.send_text("Session history cleared.")


async def _cmd_history(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    session = chat._load_session(chat_id, bot_id=bot_id)
    context_key = chat._context_key(chat_id, bot_id=bot_id)
    model = chat._model_overrides.get(context_key, chat._config.agent.model)
    await renderer.send_text(
        "\n".join(
            [
                f"Chat ID: {chat_id}",
                f"Messages: {len(session.messages)}",
                f"Model: {model}",
            ]
        )
    )


async def _cmd_tools(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    gateway_tools = chat._scope_gateway_tools(chat._gateway.tools(), bot_id=bot_id)
    session_tools = create_session_tools(
        chat_id=chat._context_key(chat_id, bot_id=bot_id),
        scheduler=chat._scheduler,
        notify=lambda t: None,  # type: ignore[arg-type, return-value]
        send_file=lambda p, c: None,  # type: ignore[arg-type, return-value]
    )
    all_tools = gateway_tools + session_tools
    if not all_tools:
        await renderer.send_text("No tools available.")
        return
    tool_lines = [f"- {tool.name}" for tool in all_tools]
    await renderer.send_text("Available tools:\n" + "\n".join(tool_lines))


async def _cmd_stop(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    _ = args
    if chat.stop(chat_id, bot_id=bot_id):
        await renderer.send_text("Stopping...")
    else:
        await renderer.send_text("Nothing running.")


_log = logging.getLogger(__name__)


def _model_supports_vision(model: str) -> bool:
    """Check if a model supports vision/image inputs via litellm model info."""
    try:
        import litellm

        litellm_model = model.split("/", 1)[-1] if "/" in model else model
        info = litellm.get_model_info(model=litellm_model)
        return bool(info.get("supports_vision", False))
    except Exception:
        return False


def _build_content_blocks(
    text: str,
    attachments: list[dict],
    model: str,
) -> list[dict]:
    """Build OpenAI-style content blocks from text and attachments.

    Returns a list of content block dicts suitable for the user message
    sent to the LLM. Image attachments are converted to image_url blocks
    with data URIs; if the model lacks vision support, a text note is
    substituted instead.
    """
    blocks: list[dict] = [{"type": "text", "text": text or ""}]
    has_vision = _model_supports_vision(model)
    for att in attachments:
        if att["type"] == "image":
            if has_vision:
                blocks.append(
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:{att['mime']};base64,{att['data']}"},
                    }
                )
            else:
                blocks.append(
                    {
                        "type": "text",
                        "text": (
                            "(User sent an image, but the current model does not support vision.)"
                        ),
                    }
                )
        elif att["type"] == "text":
            label = att.get("filename", "attachment")
            blocks.append({"type": "text", "text": f"[{label}]\n{att['content']}"})
    return blocks


def _attachment_summary(text: str, attachments: list[dict]) -> str:
    """Build a text-only summary for session storage (no base64 data)."""
    parts = [text] if text else []
    for att in attachments:
        if att["type"] == "image":
            parts.append("[User sent an image]")
        elif att["type"] == "text":
            label = att.get("filename", "attachment")
            parts.append(f"[{label}] {att['content']}")
    return "\n".join(parts) if parts else ""


def _count_tokens(messages: list[dict], model: str = "claude-sonnet-4-5-20250514") -> int:
    """Count tokens in messages using litellm, falling back to len-based estimate."""
    try:
        import litellm

        litellm_model = model.split("/", 1)[-1] if "/" in model else model
        return litellm.token_counter(model=litellm_model, messages=messages)
    except Exception:
        total = 0
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                total += len(content)
            elif isinstance(content, list):
                for part in content:
                    if isinstance(part, dict):
                        total += len(str(part.get("text", "")))
            # Account for tool_calls
            if "tool_calls" in msg:
                for tc in msg["tool_calls"]:
                    fn = tc.get("function", {})
                    total += len(str(fn.get("name", ""))) + len(str(fn.get("arguments", "")))
        # Rough char-to-token ratio: ~4 chars per token, but spec says len*500?
        # The spec says "fall back to len*500 estimate" which likely means
        # len(content) as a rough token proxy (generous overcount).
        # Actually re-reading: "fall back to len*500 estimate" probably means
        # estimate = total_chars / 4 or similar. But the spec literally says len*500.
        # That would be enormous. Let me interpret as: each message ~500 tokens estimate.
        # No wait - re-reading the task: "fall back to len*500 estimate on error"
        # This likely means: fallback = len(messages) * 500
        return len(messages) * 500


def _cap_session_history(
    messages: list[dict], max_tokens: int = 30_000, min_keep: int = 6
) -> list[dict]:
    """Trim session history from the front to fit within a token budget.

    Preserves at least min_keep recent messages. Never splits an assistant
    message with tool_calls from its subsequent tool result messages.
    """
    if not messages:
        return messages

    token_count = _count_tokens(messages)
    if token_count <= max_tokens:
        return messages

    if len(messages) <= min_keep:
        return messages

    # Build "turn groups" — sequences of messages that must stay together.
    # A turn group is one of:
    #   - A user message (standalone)
    #   - An assistant message WITHOUT tool_calls (standalone)
    #   - An assistant message WITH tool_calls + all following tool messages
    groups: list[list[int]] = []
    i = 0
    while i < len(messages):
        msg = messages[i]
        if msg.get("role") == "assistant" and "tool_calls" in msg:
            # Collect this assistant + all following tool messages
            group = [i]
            j = i + 1
            while j < len(messages) and messages[j].get("role") == "tool":
                group.append(j)
                j += 1
            groups.append(group)
            i = j
        else:
            groups.append([i])
            i += 1

    # Find the minimum number of groups from the end that covers min_keep messages
    kept_msg_count = 0
    min_groups_from_end = 0
    for g in reversed(groups):
        if kept_msg_count >= min_keep:
            break
        kept_msg_count += len(g)
        min_groups_from_end += 1

    # Try trimming groups from the front until under budget
    trim_from = 0
    max_trim = len(groups) - min_groups_from_end
    for trim_from in range(1, max_trim + 1):
        kept_indices = []
        for g in groups[trim_from:]:
            kept_indices.extend(g)
        kept = [messages[idx] for idx in kept_indices]
        if _count_tokens(kept) <= max_tokens:
            break
    else:
        # Even trimming to min_keep didn't fit — just keep min_keep messages
        trim_from = max_trim

    kept_indices = []
    for g in groups[trim_from:]:
        kept_indices.extend(g)
    result = [messages[idx] for idx in kept_indices]

    if trim_from > 0:
        result.insert(
            0,
            {
                "role": "user",
                "content": "[Earlier conversation history was trimmed to save context]",
            },
        )

    return result


def _collapse_tool_rounds(messages: list[dict], original_count: int) -> list[dict]:
    """Remove intermediate tool call/result messages added during agent.run().

    Everything from original_count onward was appended by the agent loop
    (assistant+tool_calls and tool result messages). Strip those out — the
    final assistant text response gets appended separately after this call.
    """
    if original_count >= len(messages):
        return messages

    # Keep everything before the agent run started
    return list(messages[:original_count])


COMMANDS: dict[str, CommandHandler] = {
    "help": _cmd_help,
    "status": _cmd_status,
    "model": _cmd_model,
    "new": _cmd_new,
    "clear": _cmd_clear,
    "history": _cmd_history,
    "tools": _cmd_tools,
    "stop": _cmd_stop,
}


class Chat:
    def __init__(
        self,
        config: Config,
        gateway: Gateway,
        session_store: SessionStore,
        memory: Memory,
        scheduler: Scheduler | None = None,
    ):
        self._config = config
        self._gateway = gateway
        self._session_store = session_store
        self._memory = memory
        self._scheduler = scheduler
        self._model_overrides: dict[str, str] = {}
        self._auth_storage = AuthStorage()
        self._active_tasks: dict[str, asyncio.Task] = {}

    @staticmethod
    def _context_key(chat_id: str, *, bot_id: str | None = None) -> str:
        if bot_id:
            return f"{bot_id}:{chat_id}"
        return chat_id

    @staticmethod
    def _memory_key(key: str, *, bot_id: str | None = None) -> str:
        if bot_id:
            return f"bot:{bot_id}:{key}"
        return key

    @classmethod
    def _scope_memory_results(cls, results: list[dict], *, bot_id: str | None = None) -> list[dict]:
        if not bot_id:
            return results

        prefix = cls._memory_key("", bot_id=bot_id)
        scoped: list[dict] = []
        for item in results:
            key = str(item.get("key", ""))
            if not key.startswith(prefix):
                continue
            scoped_item = dict(item)
            scoped_item["key"] = key[len(prefix) :]
            scoped.append(scoped_item)
        return scoped

    def _scope_gateway_tools(self, tools: list[Tool], *, bot_id: str | None = None) -> list[Tool]:
        if not bot_id:
            return tools

        scoped_tools: list[Tool] = []
        for tool in tools:
            if tool.name == "memory_store":

                async def _memory_store(
                    key: str,
                    content: str,
                    *,
                    _bot_id: str = bot_id,
                    _memory: Memory = self._memory,
                ) -> str:
                    scoped_key = self._memory_key(key, bot_id=_bot_id)
                    _memory.store(scoped_key, content)
                    return f"Stored memory entry: {key}"

                scoped_tools.append(
                    Tool(
                        name=tool.name,
                        description=tool.description,
                        parameters=tool.parameters,
                        execute=_memory_store,
                    )
                )
                continue

            if tool.name == "memory_search":

                async def _memory_search(
                    query: str,
                    limit: int = 5,
                    *,
                    _bot_id: str = bot_id,
                    _memory: Memory = self._memory,
                ) -> str:
                    normalized_limit = int(limit if limit is not None else 5)
                    raw_results = _memory.search(query, limit=normalized_limit)
                    scoped_results = self._scope_memory_results(raw_results, bot_id=_bot_id)
                    return "\n".join(
                        f"{str(item.get('key', ''))}: {str(item.get('snippet', ''))}"
                        for item in scoped_results
                    )

                scoped_tools.append(
                    Tool(
                        name=tool.name,
                        description=tool.description,
                        parameters=tool.parameters,
                        execute=_memory_search,
                    )
                )
                continue

            scoped_tools.append(tool)
        return scoped_tools

    def _load_session(self, chat_id: str, *, bot_id: str | None = None):
        if bot_id:
            return self._session_store.load(chat_id, bot_id=bot_id)
        return self._session_store.load(chat_id)

    def _save_session(self, session, *, bot_id: str | None = None) -> None:
        if bot_id:
            self._session_store.save(session, bot_id=bot_id)
            return
        self._session_store.save(session)

    def stop(self, chat_id: str, bot_id: str | None = None) -> bool:
        """Cancel any active agent run for this chat. Returns True if a task was cancelled."""
        context_key = self._context_key(chat_id, bot_id=bot_id)
        task = self._active_tasks.get(context_key)
        if task and not task.done():
            task.cancel()
            return True
        return False

    async def handle_message(
        self,
        chat_id: str,
        text: str,
        renderer: Renderer,
        bot_id: str | None = None,
        *,
        background: bool = False,
        attachments: list[dict] | None = None,
    ) -> None:
        """Main entry point. Routes slash commands or runs the agent.

        Args:
            background: True when invoked by the scheduler. Enables the send_message
                        tool so the agent can proactively notify the user. During normal
                        chat the streaming response already reaches the user via flush(),
                        so send_message is omitted to prevent duplicate delivery loops.
        """
        if text.startswith("/"):
            command_text = text[1:].strip()
            if not command_text:
                await renderer.show_error("Unknown command: /")
                return
            parts = command_text.split(None, 1)
            command = parts[0]
            args = parts[1] if len(parts) > 1 else ""
            await self.handle_command(
                chat_id=chat_id,
                command=command,
                args=args,
                renderer=renderer,
                bot_id=bot_id,
            )
            return

        context_key = self._context_key(chat_id, bot_id=bot_id)
        task = asyncio.current_task()
        if task:
            self._active_tasks[context_key] = task

        try:
            # Save user message to full session history (text-only, no base64)
            session = self._load_session(chat_id, bot_id=bot_id)
            if attachments:
                session_text = _attachment_summary(text, attachments)
            else:
                session_text = text
            session.messages.append({"role": "user", "content": session_text})
            self._save_session(session, bot_id=bot_id)

            # Build LLM context with pruning + compaction
            tool_results_keep = self._config.agent.history_tool_results_keep
            llm_messages = self._session_store.load_for_llm(
                chat_id, bot_id=bot_id, tool_results_keep=tool_results_keep
            )
            llm_messages = _cap_session_history(llm_messages)

            # Replace last user message with multimodal content blocks if needed
            if attachments and llm_messages:
                model = self._model_overrides.get(context_key, self._config.agent.model)
                content_blocks = _build_content_blocks(text, attachments, model)
                # Find the last user message and replace its content
                for i in range(len(llm_messages) - 1, -1, -1):
                    if llm_messages[i].get("role") == "user":
                        llm_messages[i] = dict(llm_messages[i])
                        llm_messages[i]["content"] = content_blocks
                        break

            memory_context: list[dict] = []
            try:
                memory_context = self._scope_memory_results(
                    self._memory.search(text, limit=5),
                    bot_id=bot_id,
                )
            except Exception:
                memory_context = []

            identity = self._memory.get(self._memory_key(IDENTITY_KEY, bot_id=bot_id))
            system_prompt = build_system_prompt(memory_context=memory_context, identity=identity)
            model = self._model_overrides.get(context_key, self._config.agent.model)
            gateway_tools = self._scope_gateway_tools(self._gateway.tools(), bot_id=bot_id)

            async def _notify(text: str) -> None:
                await renderer.send_text(text)

            async def _send_file(path: str, caption: str | None = None) -> None:
                await renderer.send_file(path, caption)

            session_tools = create_session_tools(
                chat_id=context_key,
                scheduler=self._scheduler,
                notify=_notify if background else None,
                send_file=_send_file,
            )
            all_tools = gateway_tools + session_tools

            result = await run(
                model=model,
                system=system_prompt,
                messages=llm_messages,
                tools=all_tools,
                auth_storage=self._auth_storage,
                on_text=renderer.on_text,
                on_tool_start=renderer.on_tool_start,
                on_tool_end=renderer.on_tool_end,
            )
            await renderer.flush()

            # Save assistant response to full session (reload to get latest)
            session = self._load_session(chat_id, bot_id=bot_id)
            session.messages.append({"role": "assistant", "content": result.text})
            self._save_session(session, bot_id=bot_id)

        finally:
            if task and self._active_tasks.get(context_key) is task:
                self._active_tasks.pop(context_key, None)

    async def handle_command(
        self,
        chat_id: str,
        command: str,
        args: str,
        renderer: Renderer,
        bot_id: str | None = None,
    ) -> None:
        """Dispatch slash commands."""
        name = command.strip().lstrip("/").lower()
        handler = COMMANDS.get(name)
        if handler:
            await handler(self, chat_id, args, bot_id, renderer)
        else:
            await renderer.show_error(f"Unknown command: /{name}")
