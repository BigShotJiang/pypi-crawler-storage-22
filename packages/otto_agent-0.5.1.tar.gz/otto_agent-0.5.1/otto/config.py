from __future__ import annotations

import copy
import os
import re
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import tomlkit

OTTO_HOME = Path(os.environ.get("OTTO_HOME", "~/.otto")).expanduser()
CONFIG_FILE = OTTO_HOME / "config.toml"
DATA_DIR = OTTO_HOME / "data"
LOGS_DIR = OTTO_HOME / "logs"
SESSIONS_DIR = OTTO_HOME / "sessions"

_ENV_REF_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")
_MISSING = object()


class ConfigError(ValueError):
    """Raised when configuration is invalid or incomplete."""


@dataclass(frozen=True)
class TelegramBotConfig:
    alias: str
    token: str
    model: str | None = None


@dataclass(frozen=True)
class TelegramConfig:
    token: str
    owner_id: int | None
    allowed_users: list[int]
    bootstrap: str
    bots: list[TelegramBotConfig] = field(default_factory=list)


@dataclass(frozen=True)
class AgentConfig:
    model: str
    model_list: list[str] = field(default_factory=list)
    history_tool_results_keep: int = 4


@dataclass(frozen=True)
class WebConfig:
    enabled: bool = False
    port: int = 7070


@dataclass(frozen=True)
class WorkspaceConfig:
    root: Path
    mode: str = "default"
    sandbox: str = "none"


@dataclass(frozen=True)
class Config:
    telegram: TelegramConfig
    agent: AgentConfig
    log_level: str
    workdir: Path
    env_file: str | None
    workspace: WorkspaceConfig | None = None
    web: WebConfig = field(default_factory=WebConfig)

    def __post_init__(self) -> None:
        if self.workspace is None:
            workspace = WorkspaceConfig(root=self.workdir)
            object.__setattr__(self, "workspace", workspace)
        else:
            workspace = self.workspace

        object.__setattr__(self, "workdir", workspace.root.expanduser())


def ensure_dirs() -> None:
    """Create the standard Otto directory tree."""
    for directory in (OTTO_HOME, DATA_DIR, LOGS_DIR, SESSIONS_DIR):
        directory.mkdir(parents=True, exist_ok=True)


def load_config(path: Path | None = None) -> Config:
    """Load, validate, and resolve Otto configuration from TOML."""
    source_path = path or CONFIG_FILE
    raw_data = _read_toml(source_path)

    env_file_raw = raw_data.get("env_file")
    if env_file_raw is not None:
        _validate_type(env_file_raw, str, "env_file", source_path)
        _load_env_file(_resolve_env_file_path(_resolve_string(env_file_raw, "env_file")))

    resolved_data = _resolve_env_refs(copy.deepcopy(raw_data), "")
    config = _build_config(resolved_data, source_path)

    # Keep the original unresolved values so save_config can preserve ${VAR} references.
    object.__setattr__(config, "_raw_values", raw_data)
    return config


def save_config(config: Config, path: Path | None = None) -> None:
    """Write Otto configuration to TOML."""
    target_path = path or CONFIG_FILE
    target_path.parent.mkdir(parents=True, exist_ok=True)

    raw_values = getattr(config, "_raw_values", None)
    preserve_legacy = isinstance(raw_values, dict)
    if preserve_legacy:
        values = copy.deepcopy(raw_values)
    else:
        values = _serialize_config(config)

    doc = tomlkit.document()
    if "env_file" in values:
        doc["env_file"] = values["env_file"]
    elif config.env_file is not None:
        doc["env_file"] = config.env_file
    doc["log_level"] = values.get("log_level", config.log_level)
    doc["workdir"] = values.get("workdir", str(config.workdir))

    workspace_values = values.get("workspace", {})
    if not isinstance(workspace_values, dict):
        workspace_values = {}
    workspace_table = tomlkit.table()
    workspace_table["root"] = workspace_values.get(
        "root", values.get("workdir", str(config.workspace.root))
    )
    workspace_table["mode"] = workspace_values.get("mode", config.workspace.mode)
    workspace_table["sandbox"] = workspace_values.get("sandbox", config.workspace.sandbox)
    doc["workspace"] = workspace_table

    telegram_values = values.get("telegram", {})
    if not isinstance(telegram_values, dict):
        telegram_values = {}
    doc["telegram"] = _build_telegram_table(
        config.telegram, telegram_values, preserve_legacy=preserve_legacy
    )

    agent_values = values.get("agent", {})
    agent_table = tomlkit.table()
    agent_table["model"] = agent_values.get("model", config.agent.model)
    model_list = config.agent.model_list
    if model_list:
        agent_table["model_list"] = model_list
    agent_table["history_tool_results_keep"] = agent_values.get(
        "history_tool_results_keep", config.agent.history_tool_results_keep
    )
    doc["agent"] = agent_table

    web_values = values.get("web", {})
    web_table = tomlkit.table()
    web_table["enabled"] = web_values.get("enabled", config.web.enabled)
    web_table["port"] = web_values.get("port", config.web.port)
    doc["web"] = web_table

    target_path.write_text(tomlkit.dumps(doc), encoding="utf-8")


def _build_telegram_table(
    config: TelegramConfig, raw_values: dict[str, Any], *, preserve_legacy: bool
) -> Any:
    table = tomlkit.table()
    has_raw_token = "token" in raw_values
    has_raw_bots = "bots" in raw_values

    # Keep writing legacy token unless this file was explicitly using only telegram.bots.
    if has_raw_token or not has_raw_bots:
        table["token"] = raw_values.get("token", config.token)
    table["owner_id"] = raw_values.get("owner_id", config.owner_id)
    table["allowed_users"] = raw_values.get("allowed_users", list(config.allowed_users))
    table["bootstrap"] = raw_values.get("bootstrap", config.bootstrap)

    if has_raw_bots:
        raw_bots = raw_values.get("bots")
        bots_values = _normalize_raw_bots(raw_bots)
    elif preserve_legacy:
        bots_values = []
    else:
        bots_values = _serialize_telegram_bots(config.bots)

    if bots_values:
        bots_aot = tomlkit.aot()
        for bot_idx, bot in enumerate(bots_values):
            bot_table = tomlkit.table()
            bot_table["alias"] = bot.get("alias", "")
            bot_table["token"] = bot.get("token", "")
            # Merge persisted model from the config dataclass if not in raw values
            bot_model = bot.get("model")
            if bot_model is None and bot_idx < len(config.bots):
                bot_model = config.bots[bot_idx].model
            if bot_model is not None:
                bot_table["model"] = bot_model
            bots_aot.append(bot_table)
        table["bots"] = bots_aot

    return table


def _serialize_config(config: Config) -> dict[str, Any]:
    data: dict[str, Any] = {
        "log_level": config.log_level,
        "workdir": str(config.workspace.root),
        "workspace": {
            "root": str(config.workspace.root),
            "mode": config.workspace.mode,
            "sandbox": config.workspace.sandbox,
        },
        "telegram": _serialize_telegram_config(config.telegram),
        "agent": {
            "model": config.agent.model,
            "model_list": config.agent.model_list,
            "history_tool_results_keep": config.agent.history_tool_results_keep,
        },
        "web": {
            "enabled": config.web.enabled,
            "port": config.web.port,
        },
    }
    if config.env_file is not None:
        data["env_file"] = config.env_file
    return data


def _serialize_telegram_config(config: TelegramConfig) -> dict[str, Any]:
    data: dict[str, Any] = {
        "token": config.token,
        "owner_id": config.owner_id,
        "allowed_users": list(config.allowed_users),
        "bootstrap": config.bootstrap,
    }
    bots = _serialize_telegram_bots(config.bots)
    if bots:
        data["bots"] = bots
    return data


def _serialize_telegram_bots(bots: list[TelegramBotConfig]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for bot in bots:
        entry: dict[str, Any] = {"alias": bot.alias, "token": bot.token}
        if bot.model is not None:
            entry["model"] = bot.model
        result.append(entry)
    return result


def _normalize_raw_bots(raw_bots: Any) -> list[dict[str, Any]]:
    if isinstance(raw_bots, list):
        return [bot for bot in raw_bots if isinstance(bot, dict)]

    if isinstance(raw_bots, dict):
        converted: list[dict[str, Any]] = []
        for alias, bot in raw_bots.items():
            if not isinstance(bot, dict):
                continue
            entry = copy.deepcopy(bot)
            entry.setdefault("alias", alias)
            converted.append(entry)
        return converted

    return []


def _read_toml(path: Path) -> dict[str, Any]:
    try:
        with path.open("rb") as file:
            data = tomllib.load(file)
    except FileNotFoundError as exc:
        raise ConfigError(
            f"Config file not found: {path}. Create it with required fields before starting Otto."
        ) from exc
    except tomllib.TOMLDecodeError as exc:
        raise ConfigError(f"Invalid TOML in {path}: {exc}") from exc

    if not isinstance(data, dict):
        raise ConfigError(
            f"Invalid config structure in {path}. Expected a TOML table at top level."
        )
    return data


def _load_env_file(path: Path) -> None:
    if not path.exists():
        return

    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line.removeprefix("export ").strip()
        if "=" not in line:
            continue

        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            continue

        if len(value) >= 2 and value[0] in {"'", '"'} and value[-1] == value[0]:
            value = value[1:-1]
        os.environ.setdefault(key, value)


def _resolve_env_file_path(value: str) -> Path:
    candidate = Path(value).expanduser()
    if not candidate.is_absolute():
        candidate = OTTO_HOME / candidate
    return candidate


def _resolve_env_refs(value: Any, field_path: str) -> Any:
    if isinstance(value, dict):
        resolved: dict[str, Any] = {}
        for key, nested_value in value.items():
            nested_path = f"{field_path}.{key}" if field_path else str(key)
            resolved[key] = _resolve_env_refs(nested_value, nested_path)
        return resolved

    if isinstance(value, list):
        return [
            _resolve_env_refs(item, f"{field_path}[{index}]") for index, item in enumerate(value)
        ]

    if isinstance(value, str):
        return _resolve_string(value, field_path)

    return value


def _resolve_string(value: str, field_path: str) -> str:
    def replace(match: re.Match[str]) -> str:
        variable_name = match.group(1)
        resolved = os.environ.get(variable_name)
        if resolved is None:
            raise ConfigError(
                f"Environment variable '{variable_name}' referenced by '{field_path}' is not set. "
                f"Set it in your environment or env_file."
            )
        return resolved

    return _ENV_REF_PATTERN.sub(replace, value)


def _build_config(data: dict[str, Any], source_path: Path) -> Config:
    telegram_table = _require_mapping(
        _require_field(data, "telegram", source_path), "telegram", source_path
    )
    agent_table = _require_mapping(_require_field(data, "agent", source_path), "agent", source_path)
    workspace_table_raw = data.get("workspace", {})
    workspace_table = _require_mapping(workspace_table_raw, "workspace", source_path)
    web_table_raw = data.get("web", {})
    web_table = _require_mapping(web_table_raw, "web", source_path)

    token_raw = telegram_table.get("token", _MISSING)
    bots_raw = telegram_table.get("bots", _MISSING)

    if bots_raw is _MISSING:
        token = _require_field(telegram_table, "token", source_path, field_path="telegram.token")
        _validate_type(token, str, "telegram.token", source_path)
        bots = [TelegramBotConfig(alias="default", token=token)]
    else:
        bots = _parse_telegram_bots(bots_raw, source_path)
        if token_raw is _MISSING:
            token = bots[0].token
        else:
            _validate_type(token_raw, str, "telegram.token", source_path)
            token = token_raw

    owner_id = _require_field(
        telegram_table, "owner_id", source_path, field_path="telegram.owner_id"
    )
    if owner_id is not None and not isinstance(owner_id, int):
        raise ConfigError(_type_error("telegram.owner_id", "int | None", source_path))

    allowed_users = _require_field(
        telegram_table, "allowed_users", source_path, field_path="telegram.allowed_users"
    )
    if not isinstance(allowed_users, list):
        raise ConfigError(_type_error("telegram.allowed_users", "list[int]", source_path))
    if not all(isinstance(item, int) for item in allowed_users):
        raise ConfigError(
            f"Invalid value for 'telegram.allowed_users' in {source_path}. "
            "Expected every entry to be an integer user id."
        )

    bootstrap = _require_field(
        telegram_table, "bootstrap", source_path, field_path="telegram.bootstrap"
    )
    _validate_type(bootstrap, str, "telegram.bootstrap", source_path)
    if bootstrap not in {"first_user", "disabled"}:
        raise ConfigError(
            f"Invalid value for 'telegram.bootstrap' in {source_path}. "
            "Expected 'first_user' or 'disabled'."
        )

    model = _require_field(agent_table, "model", source_path, field_path="agent.model")
    _validate_type(model, str, "agent.model", source_path)

    history_tool_results_keep_raw = agent_table.get("history_tool_results_keep", 4)
    _validate_type(
        history_tool_results_keep_raw, int, "agent.history_tool_results_keep", source_path
    )
    history_tool_results_keep = int(history_tool_results_keep_raw)

    model_list_raw = agent_table.get("model_list", [])
    if not isinstance(model_list_raw, list):
        raise ConfigError(_type_error("agent.model_list", "list[str]", source_path))
    for idx, item in enumerate(model_list_raw):
        _validate_type(item, str, f"agent.model_list[{idx}]", source_path)

    web_enabled = web_table.get("enabled", False)
    _validate_type(web_enabled, bool, "web.enabled", source_path)

    web_port = web_table.get("port", 7070)
    _validate_type(web_port, int, "web.port", source_path)

    log_level = _require_field(data, "log_level", source_path)
    _validate_type(log_level, str, "log_level", source_path)

    workdir_raw = data.get("workdir", _MISSING)
    if workdir_raw is not _MISSING:
        _validate_type(workdir_raw, str, "workdir", source_path)

    workspace_root_raw = workspace_table.get("root", workdir_raw)
    if workspace_root_raw is _MISSING:
        workspace_root_raw = "~"
    _validate_type(workspace_root_raw, str, "workspace.root", source_path)

    workspace_mode = workspace_table.get("mode", "default")
    _validate_type(workspace_mode, str, "workspace.mode", source_path)
    if workspace_mode not in {"default", "strict"}:
        raise ConfigError(
            f"Invalid value for 'workspace.mode' in {source_path}. Expected 'strict' or 'default'."
        )

    workspace_sandbox = workspace_table.get("sandbox", "none")
    _validate_type(workspace_sandbox, str, "workspace.sandbox", source_path)
    if workspace_sandbox not in {"none", "bubblewrap"}:
        raise ConfigError(
            f"Invalid value for 'workspace.sandbox' in {source_path}. "
            "Expected 'none' or 'bubblewrap'."
        )

    workspace_root = Path(workspace_root_raw).expanduser()
    workdir_value = str(workspace_root)

    env_file = data.get("env_file")
    if env_file is not None:
        _validate_type(env_file, str, "env_file", source_path)

    return Config(
        telegram=TelegramConfig(
            token=token,
            owner_id=owner_id,
            allowed_users=allowed_users,
            bootstrap=bootstrap,
            bots=bots,
        ),
        agent=AgentConfig(
            model=model,
            model_list=list(model_list_raw),
            history_tool_results_keep=history_tool_results_keep,
        ),
        log_level=log_level,
        workdir=Path(workdir_value).expanduser(),
        env_file=env_file,
        workspace=WorkspaceConfig(
            root=workspace_root,
            mode=workspace_mode,
            sandbox=workspace_sandbox,
        ),
        web=WebConfig(enabled=web_enabled, port=web_port),
    )


def _parse_telegram_bots(value: Any, source_path: Path) -> list[TelegramBotConfig]:
    bots: list[TelegramBotConfig] = []
    seen_aliases: set[str] = set()
    seen_tokens: dict[str, str] = {}

    def add_bot(
        alias: Any, token: Any, alias_field: str, token_field: str, bot_model: str | None = None
    ) -> None:
        _validate_type(alias, str, alias_field, source_path)
        if not alias.strip():
            raise ConfigError(
                f"Invalid value for '{alias_field}' in {source_path}. Alias cannot be empty."
            )
        if alias in seen_aliases:
            raise ConfigError(
                f"Duplicate telegram bot alias '{alias}' in {source_path}. "
                "Each entry in 'telegram.bots' must use a unique alias."
            )
        seen_aliases.add(alias)

        _validate_type(token, str, token_field, source_path)
        if not token.strip():
            raise ConfigError(
                f"Invalid value for '{token_field}' in {source_path}. Token cannot be empty."
            )

        first_alias = seen_tokens.get(token)
        if first_alias is not None:
            raise ConfigError(
                f"Duplicate telegram bot token in {source_path}. "
                f"Aliases '{first_alias}' and '{alias}' must use different tokens."
            )
        seen_tokens[token] = alias
        bots.append(TelegramBotConfig(alias=alias, token=token, model=bot_model))

    if isinstance(value, list):
        if not value:
            raise ConfigError(
                f"Invalid value for 'telegram.bots' in {source_path}. "
                "Expected at least one bot entry."
            )

        for index, bot_value in enumerate(value):
            bot_path = f"telegram.bots[{index}]"
            bot_table = _require_mapping(bot_value, bot_path, source_path)
            alias = _require_field(bot_table, "alias", source_path, field_path=f"{bot_path}.alias")
            token = _require_field(bot_table, "token", source_path, field_path=f"{bot_path}.token")
            bot_model_raw = bot_table.get("model")
            if bot_model_raw is not None:
                _validate_type(bot_model_raw, str, f"{bot_path}.model", source_path)
            add_bot(alias, token, f"{bot_path}.alias", f"{bot_path}.token", bot_model=bot_model_raw)
        return bots

    if isinstance(value, dict):
        if not value:
            raise ConfigError(
                f"Invalid value for 'telegram.bots' in {source_path}. "
                "Expected at least one bot entry."
            )

        for alias_key, bot_value in value.items():
            bot_path = f"telegram.bots.{alias_key}"
            bot_table = _require_mapping(bot_value, bot_path, source_path)
            alias = bot_table.get("alias", alias_key)
            token = _require_field(bot_table, "token", source_path, field_path=f"{bot_path}.token")
            bot_model_raw = bot_table.get("model")
            if bot_model_raw is not None:
                _validate_type(bot_model_raw, str, f"{bot_path}.model", source_path)
            add_bot(alias, token, f"{bot_path}.alias", f"{bot_path}.token", bot_model=bot_model_raw)
        return bots

    raise ConfigError(_type_error("telegram.bots", "list[table] | table", source_path))


def _require_field(
    mapping: dict[str, Any], key: str, source_path: Path, *, field_path: str | None = None
) -> Any:
    value = mapping.get(key, _MISSING)
    name = field_path or key
    if value is _MISSING:
        raise ConfigError(
            f"Missing required config field '{name}' in {source_path}. "
            f"Add '{name}' to the config file."
        )
    return value


def _require_mapping(value: Any, field_path: str, source_path: Path) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ConfigError(_type_error(field_path, "table", source_path))
    return value


def _validate_type(value: Any, expected_type: type, field_path: str, source_path: Path) -> None:
    if not isinstance(value, expected_type):
        raise ConfigError(_type_error(field_path, expected_type.__name__, source_path))


def _type_error(field_path: str, expected: str, source_path: Path) -> str:
    return f"Invalid type for '{field_path}' in {source_path}. Expected {expected}."


__all__ = [
    "AgentConfig",
    "CONFIG_FILE",
    "Config",
    "ConfigError",
    "DATA_DIR",
    "LOGS_DIR",
    "OTTO_HOME",
    "SESSIONS_DIR",
    "TelegramBotConfig",
    "TelegramConfig",
    "WebConfig",
    "WorkspaceConfig",
    "ensure_dirs",
    "load_config",
    "save_config",
]
