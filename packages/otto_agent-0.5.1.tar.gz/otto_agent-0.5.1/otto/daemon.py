from __future__ import annotations

import asyncio
import os
import signal
import subprocess
from collections.abc import Awaitable, Callable
from contextlib import suppress
from pathlib import Path
from typing import Any

from filelock import FileLock
from filelock import Timeout as LockTimeout

from otto.chat import Chat
from otto.config import OTTO_HOME, Config, TelegramConfig, load_config
from otto.gateway import Gateway, Policy
from otto.log import get_logger
from otto.log import setup as log_setup
from otto.memory import Memory
from otto.scheduler import Scheduler
from otto.sessions import SessionStore
from otto.telegram import TelegramBot, TelegramRenderer

log = get_logger("otto.daemon")

_PID_FILE_NAME = "otto.pid"
_LOCK_FILE_NAME = "otto.lock"
_SCHEDULER_TICK_SECONDS = 30


def _normalize_workspace_mode(value: Any) -> str:
    if isinstance(value, str):
        mode = value.strip().lower()
        if mode in {"default", "strict"}:
            return mode
    return "default"


def _coerce_path(value: Any, *, fallback: Path) -> Path:
    if isinstance(value, Path):
        path = value
    elif isinstance(value, str) and value.strip():
        path = Path(value.strip())
    else:
        path = fallback

    path = path.expanduser()
    if not path.is_absolute():
        path = Path.cwd() / path
    return path


def _workspace_runtime(config: Config) -> tuple[str, Path]:
    workspace = getattr(config, "workspace", None)
    mode = _normalize_workspace_mode(getattr(workspace, "mode", "default"))
    fallback_root = _coerce_path(getattr(config, "workdir", None), fallback=Path.cwd())
    root = _coerce_path(getattr(workspace, "root", None), fallback=fallback_root)
    return mode, root


def _pid_file(alias: str | None = None) -> Path:
    name = f"otto.{alias}.pid" if alias else _PID_FILE_NAME
    return OTTO_HOME / name


def _lock_file(alias: str | None = None) -> Path:
    name = f"otto.{alias}.lock" if alias else _LOCK_FILE_NAME
    return OTTO_HOME / name


def _write_pid_file(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"{os.getpid()}\n", encoding="utf-8")


def _read_pid(path: Path) -> int | None:
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None


def _pid_exists(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except PermissionError:
        return True
    except ProcessLookupError:
        return False
    except OSError:
        return False


def _discover_run_pids(alias: str | None = None) -> list[int]:
    """Find all live `python -m otto.cli run` processes."""
    try:
        output = subprocess.check_output(
            ["ps", "-eo", "pid=,args="],
            text=True,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        return []

    pids: list[int] = []
    current_pid = os.getpid()
    search_str = " -m otto.cli run"
    if alias:
        search_str += f" {alias}"

    for raw_line in output.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        parts = line.split(maxsplit=1)
        if len(parts) != 2:
            continue
        pid_text, args = parts
        if search_str not in args:
            continue
        try:
            pid = int(pid_text)
        except ValueError:
            continue
        if pid != current_pid:
            pids.append(pid)
    return pids


def _split_scoped_chat_id(raw_chat_id: str, *, aliases: set[str]) -> tuple[str | None, str]:
    """Parse chat IDs encoded as '<bot_id>:<chat_id>'."""
    if ":" not in raw_chat_id:
        return None, raw_chat_id
    candidate_bot_id, candidate_chat_id = raw_chat_id.split(":", 1)
    if candidate_bot_id in aliases and candidate_chat_id:
        return candidate_bot_id, candidate_chat_id
    return None, raw_chat_id


async def _scheduler_loop(
    scheduler: Scheduler,
    fire: Callable[[str, str], Awaitable[None]],
    shutdown_event: asyncio.Event,
) -> None:
    while not shutdown_event.is_set():
        await scheduler.tick(fire)
        try:
            await asyncio.wait_for(shutdown_event.wait(), timeout=_SCHEDULER_TICK_SECONDS)
        except TimeoutError:
            continue


async def start_services(config: Config, bot_alias: str | None = None) -> None:
    """Start Otto services and keep running until a shutdown signal arrives."""
    log_file = OTTO_HOME / "logs" / (f"otto.{bot_alias}.log" if bot_alias else "otto.log")
    log_setup(level=config.log_level, log_file=log_file)
    log.info("Starting Otto services...", bot=bot_alias or "all")
    workspace_mode, workspace_root = _workspace_runtime(config)
    runtime_workdir = (
        workspace_root
        if workspace_mode == "default"
        else _coerce_path(getattr(config, "workdir", None), fallback=workspace_root)
    )
    original_cwd = Path.cwd()
    changed_cwd = False

    memory = Memory(OTTO_HOME / "data" / "memory.db")
    # Default workspace mode intentionally keeps full-disk tool access (non-strict).
    gateway = Gateway(Policy(blocked_paths=[], max_calls_per_session=0, allowed_servers=None))

    from otto.tools import create_tools

    gateway.add_tools(create_tools(memory=memory))
    log.info("registered tools", count=len(gateway.tools()))

    session_store = SessionStore(OTTO_HOME / "sessions")
    scheduler = Scheduler(OTTO_HOME / "data" / "scheduler.db")
    chat = Chat(config, gateway, session_store, memory, scheduler)

    bots = []
    # Track aliases to avoid duplicates (main/default are usually the same)
    seen_aliases = {"main", "default"}

    if not bot_alias or bot_alias == "main":
        bots.append(TelegramBot(chat, config, config.telegram, alias="main"))

    if not bot_alias:
        for bot_conf in config.telegram.bots:
            if bot_conf.alias not in seen_aliases:
                sub_bot_config = TelegramConfig(
                    token=bot_conf.token,
                    owner_id=config.telegram.owner_id,
                    allowed_users=config.telegram.allowed_users,
                    bootstrap=config.telegram.bootstrap,
                )
                bots.append(TelegramBot(chat, config, sub_bot_config, alias=bot_conf.alias))
                seen_aliases.add(bot_conf.alias)
    elif bot_alias != "main":
        bot_conf = next((b for b in config.telegram.bots if b.alias == bot_alias), None)
        if bot_conf:
            sub_bot_config = TelegramConfig(
                token=bot_conf.token,
                owner_id=config.telegram.owner_id,
                allowed_users=config.telegram.allowed_users,
                bootstrap=config.telegram.bootstrap,
            )
            bots.append(TelegramBot(chat, config, sub_bot_config, alias=bot_alias))
        else:
            raise RuntimeError(f"Bot alias '{bot_alias}' not found in config.")

    async def fire(chat_id: str, prompt: str) -> None:
        bot_by_alias = {bot.alias: bot for bot in bots}
        if "main" in bot_by_alias and "default" not in bot_by_alias:
            bot_by_alias["default"] = bot_by_alias["main"]

        scoped_bot_id, scoped_chat_id = _split_scoped_chat_id(chat_id, aliases=set(bot_by_alias))
        if scoped_bot_id is not None:
            bot = bot_by_alias.get(scoped_bot_id)
        else:
            bot = next((candidate for candidate in bots if candidate._app is not None), None)
        if bot is None or bot._app is None:
            return

        try:
            renderer = TelegramRenderer(bot._app.bot, int(scoped_chat_id))
        except ValueError:
            log.warning(
                "scheduler task has non-telegram chat id; skipping",
                chat_id=chat_id,
                bot=scoped_bot_id,
            )
            return

        if prompt.startswith("__notify__:"):
            await renderer.send_text(prompt[len("__notify__:") :])
        else:
            await chat.handle_message(
                chat_id=scoped_chat_id,
                text=prompt,
                renderer=renderer,
                bot_id=scoped_bot_id,
                background=True,
            )

    stop_event = asyncio.Event()
    loop = asyncio.get_running_loop()
    registered_async_signals: list[signal.Signals] = []
    previous_sync_handlers: dict[signal.Signals, Any] = {}
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop_event.set)
            registered_async_signals.append(sig)
        except (NotImplementedError, RuntimeError):
            previous_handler = signal.getsignal(sig)

            def _sync_handler(signum, frame) -> None:  # pragma: no cover - platform fallback
                _ = signum, frame
                stop_event.set()

            try:
                signal.signal(sig, _sync_handler)
                previous_sync_handlers[sig] = previous_handler
            except ValueError:  # pragma: no cover - non-main thread fallback
                continue

    pid_file = _pid_file(bot_alias)
    lock = FileLock(str(_lock_file(bot_alias)))
    scheduler_task: asyncio.Task[None] | None = None
    shutdown_wait_task: asyncio.Task[None] | None = None
    web_server: Any | None = None

    try:
        try:
            lock.acquire(timeout=0)
        except LockTimeout as exc:
            raise RuntimeError(
                f"Otto ({bot_alias or 'all'}) is already running. Use 'otto stop' before starting again."
            ) from exc

        # Cleanup stale pid files left by unclean exits.
        existing_pid = _read_pid(pid_file)
        if existing_pid is None:
            pid_file.unlink(missing_ok=True)
        elif existing_pid != os.getpid() and not _pid_exists(existing_pid):
            pid_file.unlink(missing_ok=True)

        if workspace_mode == "default":
            runtime_workdir.mkdir(parents=True, exist_ok=True)
            if runtime_workdir != original_cwd:
                os.chdir(runtime_workdir)
                changed_cwd = True

        log.info(
            "workspace runtime configured",
            mode=workspace_mode,
            root=str(workspace_root),
            cwd=str(Path.cwd()),
        )

        for bot in bots:
            await bot.start()
            log.info("Telegram bot polling started", bot=bot.alias)

        # Only start web UI if specifically enabled AND this is either the global daemon or the 'main' bot.
        if config.web.enabled and (not bot_alias or bot_alias == "main"):
            from otto.web import ConfigServer

            web_server = ConfigServer(config, port=config.web.port, bots=bots)
            await web_server.start()
            log.info(f"web ui started on http://127.0.0.1:{config.web.port}")
        scheduler_task = asyncio.create_task(_scheduler_loop(scheduler, fire, stop_event))
        _write_pid_file(pid_file)
        log.info("Otto is running (PID %s). Waiting for messages...", os.getpid())

        shutdown_wait_task = asyncio.create_task(stop_event.wait())
        done, _ = await asyncio.wait(
            {shutdown_wait_task, scheduler_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        if scheduler_task in done:
            scheduler_task.result()
    finally:
        stop_event.set()

        for task in (shutdown_wait_task, scheduler_task):
            if task is None:
                continue
            task.cancel()
            with suppress(asyncio.CancelledError):
                await task

        for bot in bots:
            with suppress(Exception):
                await bot.stop()
        if web_server is not None:
            with suppress(Exception):
                await web_server.stop()
        with suppress(Exception):
            scheduler.close()
        with suppress(Exception):
            memory.close()
        with suppress(Exception):
            await gateway.close()
        pid_file.unlink(missing_ok=True)
        with suppress(Exception):
            if lock.is_locked:
                lock.release()

        for sig in registered_async_signals:
            with suppress(Exception):
                loop.remove_signal_handler(sig)
        for sig, previous_handler in previous_sync_handlers.items():
            with suppress(Exception):
                signal.signal(sig, previous_handler)
        if changed_cwd:
            with suppress(Exception):
                os.chdir(original_cwd)


def start_daemon(bot_alias: str | None = None) -> None:
    """Load config and run Otto services."""
    config = load_config()
    asyncio.run(start_services(config, bot_alias=bot_alias))


def stop_daemon(bot_alias: str | None = None) -> None:
    """Send SIGTERM to all detected Otto daemon processes or a specific bot."""
    pid_file = _pid_file(bot_alias)
    pids: set[int] = set(_discover_run_pids(bot_alias))
    tracked_pid = _read_pid(pid_file)
    if tracked_pid is not None:
        pids.add(tracked_pid)

    if not pids:
        pid_file.unlink(missing_ok=True)
        if bot_alias:
            print(f"Otto ({bot_alias}) is not running.")
        else:
            print("Otto is not running.")
        return

    stopped: list[int] = []
    for pid in sorted(pids):
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            continue
        stopped.append(pid)

    pid_file.unlink(missing_ok=True)

    if not stopped:
        if bot_alias:
            print(f"Otto ({bot_alias}) is not running.")
        else:
            print("Otto is not running.")
        return

    target = f"Otto ({bot_alias})" if bot_alias else "Otto"
    if len(stopped) == 1:
        print(f"Sent stop signal to {target} (PID {stopped[0]}).")
        return
    joined = ", ".join(str(pid) for pid in stopped)
    print(f"Sent stop signal to {target} processes: {joined}.")


def is_running(bot_alias: str | None = None) -> bool:
    """Return whether a live daemon process exists."""
    pid_file = _pid_file(bot_alias)
    pid = _read_pid(pid_file)
    if pid is None:
        pid_file.unlink(missing_ok=True)
    elif _pid_exists(pid):
        return True

    if pid is not None:
        pid_file.unlink(missing_ok=True)

    return bool(_discover_run_pids(bot_alias))


__all__ = ["is_running", "start_daemon", "start_services", "stop_daemon"]
