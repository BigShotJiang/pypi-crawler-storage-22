from __future__ import annotations

from datetime import UTC, datetime

from otto.config import OTTO_HOME
from otto.skills import discover, format_skills_prompt

DEFAULT_NAME = "Otto"
IDENTITY_KEY = "identity"

_CORE = """You are {name}, a personal AI assistant that takes action.

Be concise. No filler. No emoji unless asked."""

_FORMAT = """
Output format: Format ALL responses in Telegram HTML. Supported tags: <b>, <i>, <u>, <s>, <code>, <pre>, <a href="...">, <blockquote>. Do NOT use Markdown syntax — no **, no ```, no #. Escape &, <, > as &amp; &lt; &gt; in plain text."""

_BEHAVIORAL = """
Default behavior (follow unless your identity instructions say otherwise): Use tools to accomplish tasks — don't explain how to do something when you can just do it. When the user asks you to do something and you have tools for it, do it immediately. Don't narrate a plan and ask "Shall I proceed?" — just execute. If a step requires confirmation (destructive, costly, irreversible), ask about that specific step only."""

_IDENTITY_INSTRUCTION = """
If the user asks you to change your name, persona, or behavior style, use memory_store with key "{identity_key}" to save it. Include both identity (name/personality) and any behavioral rules they specify. This persists across sessions."""


def build_system_prompt(
    *,
    memory_context: list[dict] | None = None,
    identity: str | None = None,
    provider_prefix: str | None = None,
) -> str:
    if identity:
        parts = [identity.strip()]
    else:
        parts = [_CORE.format(name=DEFAULT_NAME)]

    parts.append(_FORMAT)
    parts.append(_BEHAVIORAL)

    if provider_prefix:
        parts.insert(0, provider_prefix.strip())

    now = datetime.now(UTC).strftime("%A, %B %d, %Y %H:%M UTC")
    parts.append(f"\nCurrent date and time: {now}")
    parts.append(_IDENTITY_INSTRUCTION.format(identity_key=IDENTITY_KEY))

    if memory_context:
        lines = ["", "Relevant memories:"]
        for item in memory_context:
            lines.append(f"- {item['key']}: {item['snippet']}")
        parts.append("\n".join(lines))

    skills = discover(OTTO_HOME / "skills")
    if skills:
        parts.append(format_skills_prompt(skills))

    return "\n".join(parts)
