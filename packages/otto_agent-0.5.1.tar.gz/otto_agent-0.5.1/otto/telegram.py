from __future__ import annotations

import asyncio
import base64
import contextlib
import io
import os
import tempfile
import time
from typing import Any

from telegram import BotCommand
from telegram.constants import ChatAction

from otto.chat import Chat, Renderer, _persist_model, build_help_category_view, build_help_main_view
from otto.config import Config, TelegramConfig, save_config
from otto.log import get_logger

log = get_logger("otto.telegram")


BOT_COMMANDS = [
    BotCommand("help", "Commands & reference"),
    BotCommand("status", "System status"),
    BotCommand("model", "Show/switch AI model"),
    BotCommand("new", "New session"),
    BotCommand("clear", "Clear session history"),
    BotCommand("tools", "List available tools"),
    BotCommand("stop", "Cancel current response"),
]


TELEGRAM_MAX_MESSAGE_LEN = 4096
_CHUNK_SEND_DELAY_SECONDS = 0.1
_ERROR_TAIL_CHARS = 2000
_ERROR_TRUNCATED_PREFIX = "... (truncated)\n"
_BUSY_CHAT_MESSAGE = "Still working on your previous message. Send /stop to cancel it."


def _find_split_index(text: str, max_len: int) -> int:
    if max_len <= 0:
        return 1
    window = text[:max_len]
    if not window:
        return 1

    for separator in ("\n\n", "\n"):
        split_index = window.rfind(separator)
        if split_index > 0:
            return split_index + len(separator)

    for separator in (" ", "\t"):
        split_index = window.rfind(separator)
        if split_index > 0:
            return split_index + 1

    return max_len


def _split_text_for_telegram(text: str, max_len: int = TELEGRAM_MAX_MESSAGE_LEN) -> list[str]:
    if not text:
        return []
    chunk_len = max(1, max_len)
    if len(text) <= chunk_len:
        return [text]

    chunks: list[str] = []
    remaining = text
    while remaining:
        if len(remaining) <= chunk_len:
            chunks.append(remaining)
            break
        split_index = _find_split_index(remaining, chunk_len)
        chunks.append(remaining[:split_index])
        remaining = remaining[split_index:]
    return chunks


async def _send_chunked(message: Any, text: str, **kwargs: Any) -> list[Any]:
    """Send text via reply_* methods, splitting content at Telegram's message limit."""
    method_name = kwargs.pop("_send_method", "reply_text")
    send = getattr(message, method_name)
    chunks = _split_text_for_telegram(text, TELEGRAM_MAX_MESSAGE_LEN)
    sent_messages: list[Any] = []
    for index, chunk in enumerate(chunks):
        sent_messages.append(await send(chunk, **kwargs))
        if index + 1 < len(chunks):
            await asyncio.sleep(_CHUNK_SEND_DELAY_SECONDS)
    return sent_messages


def _truncate_error(error: str) -> str:
    if len(error) <= _ERROR_TAIL_CHARS:
        return error
    return f"{_ERROR_TRUNCATED_PREFIX}{error[-_ERROR_TAIL_CHARS:]}"


class TelegramRenderer:
    """Renders chat events as Telegram messages.

    Tool status: single-line message edited in-place showing current tool.
    Response text: sent as one message after agent completes (no streaming).
    """

    def __init__(self, bot: Any, chat_id: int, max_len: int = TELEGRAM_MAX_MESSAGE_LEN):
        self._bot = bot
        self._chat_id = chat_id
        self._max_len = max_len
        self._buffer: list[str] = []
        self._tools_used: list[str] = []
        self._tool_message_id: int | None = None
        self._last_tool_flush: float = 0.0

    def on_text(self, chunk: str) -> None:
        self._buffer.append(chunk)

    def on_tool_start(self, name: str, args: dict) -> None:
        _ = args
        self._tools_used.append(self._format_tool_name(name))
        self._buffer.clear()  # discard intermediate thinking text

    def on_tool_end(self, name: str, result: str) -> None:
        _ = name, result

    async def send_text(self, text: str) -> None:
        await self._send(text)

    async def send_with_buttons(self, text: str, buttons: list[list[tuple[str, str]]]) -> None:
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        keyboard = [
            [InlineKeyboardButton(label, callback_data=data) for label, data in row]
            for row in buttons
        ]
        markup = InlineKeyboardMarkup(keyboard)
        try:
            await self._bot.send_message(
                chat_id=self._chat_id,
                text=text,
                parse_mode="HTML",
                reply_markup=markup,
            )
        except Exception:
            await self._bot.send_message(
                chat_id=self._chat_id,
                text=text,
                reply_markup=markup,
            )

    async def send_file(self, path: str, caption: str | None = None) -> None:
        from pathlib import Path as _Path

        file_path = _Path(path)
        try:
            with file_path.open("rb") as f:
                await self._bot.send_document(
                    chat_id=self._chat_id,
                    document=f,
                    filename=file_path.name,
                    caption=caption,
                )
        except Exception as exc:
            await self._send(f"Failed to send file: {exc}")

    async def show_error(self, error: str) -> None:
        await self._send(f"Error: {_truncate_error(error)}")

    async def flush(self) -> None:
        """Finalize tool status, then send complete response as one message."""
        await self._finalize_tools()
        text = "".join(self._buffer)
        self._buffer.clear()
        if not text:
            return
        await self._send(text)

    async def tick(self) -> None:
        """Update tool status message (called periodically while agent runs)."""
        await self._update_tool_message()

    async def _send(self, text: str) -> Any:
        chunks = self._split_text(text, self._max_len)
        if not chunks:
            return None

        sent_message: Any = None
        for index, chunk in enumerate(chunks):
            try:
                sent_message = await self._bot.send_message(
                    chat_id=self._chat_id,
                    text=chunk,
                    parse_mode="HTML",
                )
            except Exception as exc:
                if _is_retry_after(exc):
                    return None
                sent_message = await self._bot.send_message(
                    chat_id=self._chat_id,
                    text=chunk,
                )
            if index + 1 < len(chunks):
                await asyncio.sleep(_CHUNK_SEND_DELAY_SECONDS)
        return sent_message

    async def _update_tool_message(self) -> None:
        if not self._tools_used:
            return
        now = time.monotonic()
        if self._last_tool_flush and (now - self._last_tool_flush) < 2.0:
            return
        self._last_tool_flush = now

        current_tool = self._tools_used[-1]
        text = f"🔧 {current_tool}..."
        if self._tool_message_id is None:
            message = await self._send(text)
            self._tool_message_id = getattr(message, "message_id", None)
            return
        await self._safe_edit_tool_message(text)

    async def _finalize_tools(self) -> None:
        if not self._tools_used:
            return
        count = len(self._tools_used)
        text = f"✓ Used {count} tool{'s' if count != 1 else ''}"
        if self._tool_message_id is None:
            message = await self._send(text)
            self._tool_message_id = getattr(message, "message_id", None)
        else:
            await self._safe_edit_tool_message(text)
        self._tools_used.clear()  # prevent tick from overwriting finalize

    @staticmethod
    def _split_text(text: str, max_len: int) -> list[str]:
        return _split_text_for_telegram(text, max_len)

    @staticmethod
    def _format_tool_name(name: str) -> str:
        clean = name.removeprefix("mcp__").replace("_", " ")
        return clean.title()

    async def _safe_edit_tool_message(self, text: str) -> None:
        if self._tool_message_id is None:
            return
        try:
            await self._bot.edit_message_text(
                chat_id=self._chat_id,
                message_id=self._tool_message_id,
                text=text,
                parse_mode="HTML",
            )
        except Exception as exc:
            if _is_retry_after(exc):
                return
            try:
                await self._bot.edit_message_text(
                    chat_id=self._chat_id,
                    message_id=self._tool_message_id,
                    text=text,
                )
            except Exception:
                pass


def _is_retry_after(exc: BaseException) -> bool:
    return "RetryAfter" in type(exc).__name__ or "Flood control" in str(exc)


class TelegramBot:
    def __init__(
        self,
        chat: Chat,
        config: Config,
        telegram_config: TelegramConfig | None = None,
        alias: str | None = None,
    ):
        self._chat = chat
        self._config = config
        self._telegram_config = telegram_config or config.telegram
        self._alias = alias
        self._app: Any | None = None
        self._running_tasks: dict[str, asyncio.Task] = {}  # chat_id -> agent task
        self._active_chats: set[str] = set()
        self._active_chats_lock = asyncio.Lock()
        self._log = log.bind(bot=self.alias)

    def _get_bot_model_default(self) -> str | None:
        """Return the per-bot model default from config, if set."""
        for bot_cfg in self._config.telegram.bots:
            if bot_cfg.alias == self.alias:
                return bot_cfg.model
        return None

    def _apply_bot_default_model(self, chat_id: str) -> None:
        """Set the per-bot model default for a chat if no override exists yet."""
        bot_model = self._get_bot_model_default()
        if not bot_model:
            return
        context_key = self._chat._context_key(chat_id, bot_id=self.alias)
        if context_key not in self._chat._model_overrides:
            self._chat._model_overrides[context_key] = bot_model

    @property
    def alias(self) -> str:
        return self._alias or "default"

    async def start(self) -> None:
        """Build application, register handlers, and start polling."""
        from telegram.ext import (
            Application,
            CallbackQueryHandler,
            CommandHandler,
            MessageHandler,
            filters,
        )

        self._log.info("starting bot")
        self._app = Application.builder().token(self._telegram_config.token).build()

        # Run text handlers in background so /stop can be processed while a response is active.
        self._app.add_handler(
            MessageHandler(filters.TEXT & ~filters.COMMAND, self._on_message, block=False)
        )
        self._app.add_handler(MessageHandler(filters.PHOTO, self._on_photo, block=False))
        self._app.add_handler(
            MessageHandler(filters.VOICE | filters.AUDIO, self._on_voice, block=False)
        )
        self._app.add_handler(MessageHandler(filters.Document.ALL, self._on_document, block=False))
        self._app.add_handler(CommandHandler("start", self._on_start))
        self._app.add_handler(MessageHandler(filters.COMMAND, self._on_command))
        self._app.add_handler(CallbackQueryHandler(self._on_callback))

        await self._app.initialize()
        try:
            await self._app.bot.set_my_commands(BOT_COMMANDS)
        except Exception:
            pass
        await self._app.start()

        if self._app.updater is not None:
            await self._app.updater.start_polling(drop_pending_updates=True)

    async def stop(self) -> None:
        """Gracefully stop polling and shutdown the app."""
        if self._app is None:
            return

        self._log.info("stopping bot")
        if self._app.updater is not None:
            await self._app.updater.stop()
        await self._app.stop()
        await self._app.shutdown()

    async def _run_with_renderer(
        self,
        chat_id_int: int,
        chat_id_str: str,
        context: Any,
        handler_coro,
    ) -> None:
        """Shared lifecycle: claim slot, typing indicator, tick loop, run handler, cleanup."""
        if not await self._claim_chat_slot(chat_id_str):
            return False

        renderer = TelegramRenderer(context.bot, chat_id_int)
        stop_event = asyncio.Event()
        typing_task = asyncio.create_task(self._keep_typing(chat_id_int, stop_event))
        tick_task = asyncio.create_task(self._tick_loop(renderer, stop_event))

        agent_task = asyncio.create_task(handler_coro(renderer))
        self._running_tasks[chat_id_str] = agent_task
        try:
            await agent_task
        except asyncio.CancelledError:
            await renderer.send_text("Stopped.")
        except Exception as exc:
            await renderer.show_error(str(exc))
        finally:
            self._running_tasks.pop(chat_id_str, None)
            stop_event.set()
            await typing_task
            tick_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await tick_task
            await self._release_chat_slot(chat_id_str)

    def _authorize_or_bootstrap(self, user: Any, *, event: str) -> bool:
        """Authorize user or bootstrap ownership once when allowed."""
        if self._is_authorized(user.id):
            return True
        if not self._try_bootstrap(user):
            self._log.warning(f"unauthorized {event}", user_id=user.id)
            return False
        self._log.info("user bootstrapped as owner", user_id=user.id)
        return True

    async def _run_handler_with_busy_notice(
        self,
        message: Any,
        chat_id_int: int,
        chat_id_str: str,
        context: Any,
        handler_coro,
    ) -> None:
        """Mirror _on_message slot behavior for all message handlers."""
        if not await self._claim_chat_slot(chat_id_str):
            await _send_chunked(message, _BUSY_CHAT_MESSAGE)
            return
        # _run_with_renderer handles lifecycle; release so it can claim again.
        await self._release_chat_slot(chat_id_str)
        await self._run_with_renderer(chat_id_int, chat_id_str, context, handler_coro)

    async def _on_message(self, update: Any, context: Any) -> None:
        """Handle non-command text messages."""
        user = getattr(update, "effective_user", None)
        chat = getattr(update, "effective_chat", None)
        message = getattr(update, "message", None)
        if user is None or chat is None or message is None or message.text is None:
            return

        if not self._authorize_or_bootstrap(user, event="message"):
            return

        bound = self._log.bind(chat_id=chat.id, user_id=user.id)
        bound.info("message received", text=message.text[:80])

        chat_id_str = str(chat.id)
        self._apply_bot_default_model(chat_id_str)

        async def _handler(renderer):
            await self._chat.handle_message(
                chat_id=chat_id_str,
                text=message.text,
                renderer=renderer,
                bot_id=self.alias,
            )

        await self._run_handler_with_busy_notice(message, chat.id, chat_id_str, context, _handler)
        bound.info("message handled")

    async def _on_photo(self, update: Any, context: Any) -> None:
        """Handle photo messages."""
        user = getattr(update, "effective_user", None)
        chat = getattr(update, "effective_chat", None)
        message = getattr(update, "message", None)
        if user is None or chat is None or message is None:
            return
        if not message.photo:
            return

        if not self._authorize_or_bootstrap(user, event="photo"):
            return

        chat_id_str = str(chat.id)
        self._apply_bot_default_model(chat_id_str)

        caption = message.caption or ""

        async def _handler(renderer):
            photo = message.photo[-1]  # highest resolution
            file = await photo.get_file()
            data = await file.download_as_bytearray()
            b64 = base64.b64encode(bytes(data)).decode("ascii")
            await self._chat.handle_message(
                chat_id=chat_id_str,
                text=caption,
                renderer=renderer,
                bot_id=self.alias,
                attachments=[{"type": "image", "data": b64, "mime": "image/jpeg"}],
            )

        await self._run_handler_with_busy_notice(message, chat.id, chat_id_str, context, _handler)

    async def _on_voice(self, update: Any, context: Any) -> None:
        """Handle voice and audio messages."""
        user = getattr(update, "effective_user", None)
        chat = getattr(update, "effective_chat", None)
        message = getattr(update, "message", None)
        if user is None or chat is None or message is None:
            return

        voice = message.voice or message.audio
        if voice is None:
            return

        if not self._authorize_or_bootstrap(user, event="voice"):
            return

        chat_id_str = str(chat.id)
        self._apply_bot_default_model(chat_id_str)

        async def _handler(renderer):
            file = await voice.get_file()
            data = await file.download_as_bytearray()

            tmp_path = None
            try:
                with tempfile.NamedTemporaryFile(delete=False, suffix=".ogg") as tmp:
                    tmp.write(bytes(data))
                    tmp_path = tmp.name

                try:
                    from otto.transcribe import transcribe
                except ImportError:
                    await renderer.send_text(
                        "Voice transcription requires faster-whisper. "
                        "Install with: uv pip install faster-whisper"
                    )
                    return

                text = await transcribe(tmp_path)
                await self._chat.handle_message(
                    chat_id=chat_id_str,
                    text=text,
                    renderer=renderer,
                    bot_id=self.alias,
                )
            finally:
                if tmp_path:
                    with contextlib.suppress(OSError):
                        os.unlink(tmp_path)

        await self._run_handler_with_busy_notice(message, chat.id, chat_id_str, context, _handler)

    async def _on_document(self, update: Any, context: Any) -> None:
        """Handle document messages."""
        user = getattr(update, "effective_user", None)
        chat = getattr(update, "effective_chat", None)
        message = getattr(update, "message", None)
        if user is None or chat is None or message is None:
            return

        doc = message.document
        if doc is None:
            return

        if not self._authorize_or_bootstrap(user, event="document"):
            return

        chat_id_str = str(chat.id)
        self._apply_bot_default_model(chat_id_str)

        caption = message.caption or ""

        text_extensions = {
            ".txt",
            ".py",
            ".json",
            ".md",
            ".csv",
            ".log",
            ".xml",
            ".yaml",
            ".toml",
            ".sh",
            ".js",
            ".ts",
            ".html",
            ".css",
            ".sql",
            ".rs",
            ".go",
            ".c",
            ".h",
            ".cpp",
            ".java",
            ".rb",
            ".php",
            ".r",
            ".swift",
            ".kt",
        }

        async def _handler(renderer):
            file = await doc.get_file()
            data = await file.download_as_bytearray()
            filename = doc.file_name or "document"

            ext = os.path.splitext(filename)[1].lower()
            if ext in text_extensions:
                extracted = bytes(data).decode("utf-8", errors="replace")
            elif ext == ".pdf":
                try:
                    import pdfplumber

                    pages_text = []
                    with pdfplumber.open(io.BytesIO(bytes(data))) as pdf:
                        for page in pdf.pages:
                            page_text = page.extract_text()
                            if page_text:
                                pages_text.append(page_text)
                    extracted = "\n".join(pages_text)
                except ImportError:
                    extracted = (
                        "PDF processing requires pdfplumber. "
                        f"User sent file: {filename} ({len(data)} bytes)"
                    )
            else:
                extracted = f"User sent file: {filename} ({len(data)} bytes)"

            await self._chat.handle_message(
                chat_id=chat_id_str,
                text=caption,
                renderer=renderer,
                bot_id=self.alias,
                attachments=[{"type": "text", "filename": filename, "content": extracted}],
            )

        await self._run_handler_with_busy_notice(message, chat.id, chat_id_str, context, _handler)

    async def _keep_typing(self, chat_id: int, stop: asyncio.Event) -> None:
        """Send periodic typing indicators while work is in progress."""
        while not stop.is_set():
            try:
                if self._app is None:
                    break
                await self._app.bot.send_chat_action(chat_id=chat_id, action=ChatAction.TYPING)
                await asyncio.wait_for(stop.wait(), timeout=4.0)
            except TimeoutError:
                continue
            except (asyncio.CancelledError, Exception):
                break

    @staticmethod
    async def _tick_loop(renderer: TelegramRenderer, stop: asyncio.Event) -> None:
        """Call renderer.tick() periodically to update tool status."""
        while not stop.is_set():
            try:
                await renderer.tick()
                await asyncio.wait_for(stop.wait(), timeout=1.0)
            except TimeoutError:
                continue
            except (asyncio.CancelledError, Exception):
                break

    async def _on_command(self, update: Any, context: Any) -> None:
        """Handle slash commands via Chat."""
        user = getattr(update, "effective_user", None)
        chat = getattr(update, "effective_chat", None)
        message = getattr(update, "message", None)
        if user is None or chat is None or message is None or message.text is None:
            return

        if not self._is_authorized(user.id):
            return

        parts = message.text.split(None, 1)
        command = parts[0].lstrip("/").split("@", 1)[0]
        args = parts[1] if len(parts) > 1 else ""
        chat_id_str = str(chat.id)
        self._apply_bot_default_model(chat_id_str)

        # /stop cancels any running agent task for this chat (silent if nothing running)
        if command == "stop":
            task = self._running_tasks.get(chat_id_str)
            if task and not task.done():
                task.cancel()
            return

        renderer = TelegramRenderer(context.bot, chat.id)
        await self._chat.handle_command(
            chat_id=chat_id_str,
            command=command,
            args=args,
            renderer=renderer,
            bot_id=self.alias,
        )

    async def _on_callback(self, update: Any, context: Any) -> None:
        """Handle inline keyboard button presses."""
        query = getattr(update, "callback_query", None)
        if query is None:
            return

        user = getattr(update, "effective_user", None)
        if user is None or not self._is_authorized(user.id):
            await query.answer("Access denied.", show_alert=True)
            return

        data = getattr(query, "data", "") or ""
        if ":" not in data:
            await query.answer()
            return

        prefix, action = data.split(":", 1)
        await query.answer()

        chat_id = str(query.message.chat_id) if query.message else None
        if chat_id is None:
            return

        if prefix == "status":
            await self._handle_status_callback(query, chat_id, action, context)
        elif prefix == "model":
            await self._handle_model_callback(query, chat_id, action)
        elif prefix == "help":
            await self._handle_help_callback(query, chat_id, action, context)

    async def _handle_status_callback(
        self, query: Any, chat_id: str, action: str, context: Any
    ) -> None:
        """Handle status button callbacks."""
        if action == "model":
            context_key = self._chat._context_key(chat_id, bot_id=self.alias)
            model = self._chat._model_overrides.get(context_key, self._config.agent.model)
            await self._edit_callback_message(query, f"Current model: {model}")
        elif action == "new":
            renderer: Renderer = TelegramRenderer(context.bot, int(chat_id))
            await self._chat.handle_command(
                chat_id=chat_id,
                command="new",
                args="",
                renderer=renderer,
                bot_id=self.alias,
            )
            await self._edit_callback_message(query, "New session started.")
        elif action == "refresh":
            renderer = TelegramRenderer(context.bot, int(chat_id))
            await self._chat.handle_command(
                chat_id=chat_id,
                command="status",
                args="",
                renderer=renderer,
                bot_id=self.alias,
            )

    async def _handle_model_callback(self, query: Any, chat_id: str, action: str) -> None:
        """Handle model picker button callbacks."""
        if action == "cancel":
            await self._edit_callback_message(query, "Model unchanged.")
        elif action == "custom":
            await self._edit_callback_message(
                query, "Send the model string as a message.\nExample: <code>openai/gpt-4o</code>"
            )
        else:
            context_key = self._chat._context_key(chat_id, bot_id=self.alias)
            self._chat._model_overrides[context_key] = action
            _persist_model(self._config, action, bot_id=self.alias)
            await self._edit_callback_message(query, f"Model set: <b>{action}</b>")

    async def _handle_help_callback(
        self, query: Any, chat_id: str, action: str, context: Any
    ) -> None:
        """Handle /help menu category navigation and quick launch actions."""
        if action == "back":
            text, buttons = build_help_main_view()
            await self._edit_callback_message(query, text, buttons=buttons)
            return

        if action.startswith("run:"):
            command = action.split(":", 1)[1].strip().lstrip("/")
            if not command:
                await self._edit_callback_message(query, "Unknown command.")
                return
            renderer: Renderer = TelegramRenderer(context.bot, int(chat_id))
            await self._chat.handle_command(
                chat_id=chat_id,
                command=command,
                args="",
                renderer=renderer,
                bot_id=self.alias,
            )
            return

        category_view = build_help_category_view(action)
        if category_view is None:
            await self._edit_callback_message(query, "Unknown help category.")
            return

        text, buttons = category_view
        await self._edit_callback_message(query, text, buttons=buttons)

    @staticmethod
    def _build_inline_markup(buttons: list[list[tuple[str, str]]]) -> Any:
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        keyboard = [
            [InlineKeyboardButton(label, callback_data=data) for label, data in row]
            for row in buttons
        ]
        return InlineKeyboardMarkup(keyboard)

    async def _edit_callback_message(
        self,
        query: Any,
        text: str,
        *,
        buttons: list[list[tuple[str, str]]] | None = None,
    ) -> None:
        """Edit a callback query message with fallback."""
        markup = self._build_inline_markup(buttons) if buttons else None
        try:
            await query.edit_message_text(text=text, parse_mode="HTML", reply_markup=markup)
        except Exception:
            try:
                await query.edit_message_text(text=text, reply_markup=markup)
            except Exception:
                pass

    async def _on_start(self, update: Any, context: Any) -> None:
        """Handle /start with bootstrap-ready messaging."""
        _ = context
        user = getattr(update, "effective_user", None)
        message = getattr(update, "message", None)
        if user is None or message is None:
            return

        if self._try_bootstrap(user):
            await _send_chunked(message, "Welcome! You are now the owner of this Otto instance.")
            return

        if self._is_authorized(user.id):
            await _send_chunked(message, "Otto is ready.")

    def _is_authorized(self, user_id: int) -> bool:
        if self._telegram_config.owner_id and user_id == self._telegram_config.owner_id:
            return True
        return user_id in self._telegram_config.allowed_users

    def _try_bootstrap(self, user: Any) -> bool:
        """If bootstrap=first_user and no owner set, claim ownership."""
        if self._telegram_config.bootstrap != "first_user":
            return False
        # owner_id 0 means unset
        if self._telegram_config.owner_id and self._telegram_config.owner_id != 0:
            return False
        user_id = getattr(user, "id", None)
        if user_id is None:
            return False
        # Claim ownership and persist to disk
        tc = self._telegram_config
        new_tc = TelegramConfig(
            token=tc.token,
            owner_id=user_id,
            allowed_users=[user_id, *tc.allowed_users],
            bootstrap="disabled",
            bots=tc.bots,
        )
        self._telegram_config = new_tc

        # If this is the main bot, update the root config
        if tc is self._config.telegram:
            object.__setattr__(self._config, "telegram", new_tc)

        # Update _raw_values so save_config writes the new values (not stale snapshot)
        raw = getattr(self._config, "_raw_values", None)
        if isinstance(raw, dict) and "telegram" in raw:
            # TODO: This doesn't handle nested bots bootstrapping well in _raw_values.
            # But for the main bot it works as before.
            if tc is self._config.telegram:
                raw["telegram"]["owner_id"] = user_id
                raw["telegram"]["allowed_users"] = [user_id, *tc.allowed_users]
                raw["telegram"]["bootstrap"] = "disabled"
        try:
            save_config(self._config)
            self._log.info("bootstrap persisted", owner_id=user_id)
        except Exception as exc:
            self._log.error("failed to persist bootstrap", error=str(exc))
        return True

    async def _claim_chat_slot(self, chat_id: str) -> bool:
        """Reserve a chat for one active text message run at a time."""
        async with self._active_chats_lock:
            if chat_id in self._active_chats:
                return False
            self._active_chats.add(chat_id)
            return True

    async def _release_chat_slot(self, chat_id: str) -> None:
        """Release a previously reserved chat slot."""
        async with self._active_chats_lock:
            self._active_chats.discard(chat_id)


__all__ = ["TelegramBot", "TelegramRenderer"]
