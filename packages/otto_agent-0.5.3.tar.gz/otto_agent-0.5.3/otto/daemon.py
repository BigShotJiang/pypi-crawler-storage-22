from __future__ import annotations

import asyncio
import os
import signal
import subprocess
from collections.abc import Awaitable, Callable
from contextlib import suppress
from pathlib import Path
from typing import Any

from filelock import FileLock
from filelock import Timeout as LockTimeout

from otto.chat import Chat
from otto.config import OTTO_HOME, Config, TelegramConfig, load_config
from otto.gateway import Gateway, Policy
from otto.log import get_logger
from otto.log import setup as log_setup
from otto.memory import Memory
from otto.scheduler import Scheduler
from otto.sessions import SessionStore
from otto.telegram import TelegramBot, TelegramRenderer

log = get_logger("otto.daemon")

_PID_FILE_NAME = "otto.pid"
_LOCK_FILE_NAME = "otto.lock"
_SCHEDULER_TICK_SECONDS = 30


def _normalize_workspace_mode(value: Any) -> str:
    if isinstance(value, str):
        mode = value.strip().lower()
        if mode in {"default", "strict"}:
            return mode
    return "default"


def _coerce_path(value: Any, *, fallback: Path) -> Path:
    if isinstance(value, Path):
        path = value
    elif isinstance(value, str) and value.strip():
        path = Path(value.strip())
    else:
        path = fallback

    path = path.expanduser()
    if not path.is_absolute():
        path = Path.cwd() / path
    return path


def _workspace_runtime(config: Config) -> tuple[str, Path]:
    workspace = getattr(config, "workspace", None)
    mode = _normalize_workspace_mode(getattr(workspace, "mode", "default"))
    fallback_root = _coerce_path(getattr(config, "workdir", None), fallback=Path.cwd())
    root = _coerce_path(getattr(workspace, "root", None), fallback=fallback_root)
    return mode, root


def _pid_file(alias: str | None = None) -> Path:
    name = f"otto.{alias}.pid" if alias else _PID_FILE_NAME
    return OTTO_HOME / name


def _lock_file(alias: str | None = None) -> Path:
    name = f"otto.{alias}.lock" if alias else _LOCK_FILE_NAME
    return OTTO_HOME / name


def _write_pid_file(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"{os.getpid()}\n", encoding="utf-8")


def _read_pid(path: Path) -> int | None:
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None


def _pid_exists(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except PermissionError:
        return True
    except ProcessLookupError:
        return False
    except OSError:
        return False


def _discover_run_pids(alias: str | None = None) -> list[int]:
    """Find all live `python -m otto.cli run` processes."""
    try:
        output = subprocess.check_output(
            ["ps", "-eo", "pid=,args="],
            text=True,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        return []

    pids: list[int] = []
    current_pid = os.getpid()
    search_str = " -m otto.cli run"
    if alias:
        search_str += f" {alias}"

    for raw_line in output.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        parts = line.split(maxsplit=1)
        if len(parts) != 2:
            continue
        pid_text, args = parts
        if search_str not in args:
            continue
        try:
            pid = int(pid_text)
        except ValueError:
            continue
        if pid != current_pid:
            pids.append(pid)
    return pids


async def _scheduler_loop(
    scheduler: Scheduler,
    fire: Callable[[str, str], Awaitable[None]],
    shutdown_event: asyncio.Event,
) -> None:
    while not shutdown_event.is_set():
        await scheduler.tick(fire)
        try:
            await asyncio.wait_for(shutdown_event.wait(), timeout=_SCHEDULER_TICK_SECONDS)
        except TimeoutError:
            continue


async def start_services(
    config: Config,
    bot_alias: str | None = None,
    cli_bot: str | None = None,
    cli_resume_id: str | None = None,
) -> None:
    """Start Otto services and keep running until a shutdown signal arrives.

    When *cli_bot* is set (e.g. ``"auto"``), a CLI chat channel is attached to
    the first eligible bot and runs as the foreground blocking task.  When the
    CLI channel exits (ctrl+C / ctrl+D) the entire service shuts down.
    """
    log_file = OTTO_HOME / "logs" / (f"otto.{bot_alias}.log" if bot_alias else "otto.log")
    log_setup(level=config.log_level, log_file=log_file, console=cli_bot is None)
    log.info("Starting Otto services...", bot=bot_alias or "all")
    workspace_mode, workspace_root = _workspace_runtime(config)
    runtime_workdir = (
        workspace_root
        if workspace_mode == "default"
        else _coerce_path(getattr(config, "workdir", None), fallback=workspace_root)
    )
    original_cwd = Path.cwd()
    changed_cwd = False

    # Shared scheduler — single instance across all bots.
    scheduler = Scheduler(OTTO_HOME / "data" / "scheduler.db")

    bots: list[Any] = []
    memories: list[Memory] = []
    chats_by_bot: dict[str, Chat] = {}
    legacy_chat: Chat | None = None

    if getattr(config, "bots", None):
        # ------------------------------------------------------------------
        # New schema: per-bot resources — each bot gets its own Gateway
        # with workspace-scoped tools and isolated memory.
        # ------------------------------------------------------------------
        from otto.tools import create_tools

        bot_configs = config.bots
        if bot_alias:
            bot_configs = [b for b in config.bots if b.name == bot_alias]
            if not bot_configs:
                raise RuntimeError(f"Bot alias '{bot_alias}' not found in config.")

        for bot_conf in bot_configs:
            bot_home = OTTO_HOME / "bots" / bot_conf.name
            bot_home.mkdir(parents=True, exist_ok=True)

            memory = Memory(bot_home / "data" / "memory.db")
            memories.append(memory)

            ws_mode = bot_conf.workspace.mode
            ws_root = str(bot_conf.workspace.root)

            bot_gateway = Gateway(
                Policy(blocked_paths=[], max_calls_per_session=0, allowed_servers=None)
            )
            bot_gateway.add_tools(
                create_tools(
                    memory=memory,
                    workspace_mode=ws_mode,
                    workspace_root=ws_root,
                )
            )
            log.info(
                "registered per-bot tools",
                bot=bot_conf.name,
                count=len(bot_gateway.tools()),
                workspace_mode=ws_mode,
            )

            session_store = SessionStore(bot_home / "sessions")
            chat = Chat(
                config,
                bot_gateway,
                session_store,
                memory,
                scheduler,
                bot_name=bot_conf.name,
                workspace_mode=ws_mode,
                workspace_root=ws_root,
            )
            chats_by_bot[bot_conf.name] = chat

            for channel in bot_conf.channels:
                if channel.type == "telegram" and channel.token:
                    bots.append(
                        TelegramBot(
                            chat,
                            config,
                            bot_config=bot_conf,
                            channel_config=channel,
                        )
                    )
    else:
        # ------------------------------------------------------------------
        # Legacy schema: single shared resources from config.telegram
        # ------------------------------------------------------------------
        memory = Memory(OTTO_HOME / "data" / "memory.db")
        memories.append(memory)

        from otto.tools import create_tools

        gateway = Gateway(Policy(blocked_paths=[], max_calls_per_session=0, allowed_servers=None))
        gateway.add_tools(
            create_tools(
                memory=memory,
                workspace_mode=workspace_mode,
                workspace_root=str(workspace_root),
            )
        )
        log.info("registered tools", count=len(gateway.tools()))

        session_store = SessionStore(OTTO_HOME / "sessions")
        chat = Chat(
            config,
            gateway,
            session_store,
            memory,
            scheduler,
            workspace_mode=workspace_mode,
            workspace_root=str(workspace_root),
        )
        legacy_chat = chat

        seen_aliases = {"main", "default"}

        if not bot_alias or bot_alias == "main":
            bots.append(TelegramBot(chat, config, config.telegram, alias="main"))

        if not bot_alias:
            for bot_conf in config.telegram.bots:
                if bot_conf.alias not in seen_aliases:
                    sub_bot_config = TelegramConfig(
                        token=bot_conf.token,
                        owner_id=config.telegram.owner_id,
                        allowed_users=config.telegram.allowed_users,
                        bootstrap=config.telegram.bootstrap,
                    )
                    bots.append(TelegramBot(chat, config, sub_bot_config, alias=bot_conf.alias))
                    seen_aliases.add(bot_conf.alias)
        elif bot_alias != "main":
            bot_conf = next((b for b in config.telegram.bots if b.alias == bot_alias), None)
            if bot_conf:
                sub_bot_config = TelegramConfig(
                    token=bot_conf.token,
                    owner_id=config.telegram.owner_id,
                    allowed_users=config.telegram.allowed_users,
                    bootstrap=config.telegram.bootstrap,
                )
                bots.append(TelegramBot(chat, config, sub_bot_config, alias=bot_alias))
            else:
                raise RuntimeError(f"Bot alias '{bot_alias}' not found in config.")

    # ------------------------------------------------------------------
    # CLI channel (foreground mode)
    # ------------------------------------------------------------------
    cli_channel: Any | None = None
    if cli_bot is not None:
        from otto.cli_chat import CLIChatChannel
        from otto.config import BotAuthConfig, BotConfig, ChannelConfig

        # Resolve which bot to attach the CLI channel to.
        _cli_chat: Chat | None = None
        _cli_bot_config: BotConfig | None = None

        if getattr(config, "bots", None):
            # New schema: look for a bot with a cli channel, or use first bot.
            target = None
            if cli_bot != "auto":
                target = next((b for b in config.bots if b.name == cli_bot), None)
            if target is None:
                # Find first bot with a cli channel type, or fall back to first bot.
                target = next(
                    (b for b in config.bots if any(c.type == "cli" for c in b.channels)),
                    None,
                )
            if target is None and config.bots:
                target = config.bots[0]
            if target is not None:
                _cli_bot_config = target
                _cli_chat = chats_by_bot.get(target.name)
                if _cli_chat is None:
                    # Build per-bot resources if not already built (e.g. bot_alias filter).
                    from otto.tools import create_tools as _ct

                    bot_home = OTTO_HOME / "bots" / target.name
                    bot_home.mkdir(parents=True, exist_ok=True)
                    _cli_memory = Memory(bot_home / "data" / "memory.db")
                    memories.append(_cli_memory)

                    _ws_mode = target.workspace.mode
                    _ws_root = str(target.workspace.root)
                    _cli_gateway = Gateway(
                        Policy(
                            blocked_paths=[],
                            max_calls_per_session=0,
                            allowed_servers=None,
                        )
                    )
                    _cli_gateway.add_tools(
                        _ct(
                            memory=_cli_memory,
                            workspace_mode=_ws_mode,
                            workspace_root=_ws_root,
                        )
                    )

                    _cli_session_store = SessionStore(bot_home / "sessions")
                    _cli_chat = Chat(
                        config,
                        _cli_gateway,
                        _cli_session_store,
                        _cli_memory,
                        scheduler,
                        bot_name=target.name,
                        workspace_mode=_ws_mode,
                        workspace_root=_ws_root,
                    )
                    chats_by_bot[target.name] = _cli_chat
        else:
            # Legacy schema: use the shared chat.
            _cli_chat = legacy_chat

            # Build a synthetic BotConfig for the CLI channel.
            _cli_bot_config = BotConfig(
                name="default",
                model=config.agent.model,
                auth=BotAuthConfig(owner="cli", allowed_users=[]),
                workspace=config.workspace,
            )

        if _cli_chat is not None and _cli_bot_config is not None:
            cli_channel_config = ChannelConfig(type="cli")
            cli_channel = CLIChatChannel(
                _cli_chat,
                _cli_bot_config,
                cli_channel_config,
                resume_id=cli_resume_id,
            )
            log.info("CLI chat channel attached", bot=_cli_bot_config.name)

    async def fire(chat_id: str, prompt: str) -> None:
        bot_by_alias = {bot.alias: bot for bot in bots}
        if "main" in bot_by_alias and "default" not in bot_by_alias:
            bot_by_alias["default"] = bot_by_alias["main"]

        # Find the bot to send through.
        bot = next((candidate for candidate in bots if candidate._app is not None), None)
        if bot is None or bot._app is None:
            return

        try:
            renderer = TelegramRenderer(bot._app.bot, int(chat_id))
        except ValueError:
            log.warning(
                "scheduler task has non-telegram chat id; skipping",
                chat_id=chat_id,
            )
            return

        if prompt.startswith("__notify__:"):
            await renderer.send_text(prompt[len("__notify__:") :])
        else:
            # Use the bot's Chat instance if available, otherwise fall back.
            bot_chat = chats_by_bot.get(bot.alias) if chats_by_bot else None
            if bot_chat is None:
                # Legacy path: single shared chat
                bot_chat = bots[0]._chat if bots else None
            if bot_chat is None:
                return
            await bot_chat.handle_message(
                chat_id=chat_id,
                text=prompt,
                renderer=renderer,
                background=True,
            )

    stop_event = asyncio.Event()
    loop = asyncio.get_running_loop()
    registered_async_signals: list[signal.Signals] = []
    previous_sync_handlers: dict[signal.Signals, Any] = {}
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop_event.set)
            registered_async_signals.append(sig)
        except (NotImplementedError, RuntimeError):
            previous_handler = signal.getsignal(sig)

            def _sync_handler(signum, frame) -> None:  # pragma: no cover - platform fallback
                _ = signum, frame
                stop_event.set()

            try:
                signal.signal(sig, _sync_handler)
                previous_sync_handlers[sig] = previous_handler
            except ValueError:  # pragma: no cover - non-main thread fallback
                continue

    pid_file = _pid_file(bot_alias)
    lock = FileLock(str(_lock_file(bot_alias)))
    scheduler_task: asyncio.Task[None] | None = None
    shutdown_wait_task: asyncio.Task[None] | None = None
    cli_task: asyncio.Task[None] | None = None
    web_server: Any | None = None

    try:
        try:
            lock.acquire(timeout=0)
        except LockTimeout as exc:
            raise RuntimeError(
                f"Otto ({bot_alias or 'all'}) is already running. Use 'otto stop' before starting again."
            ) from exc

        # Cleanup stale pid files left by unclean exits.
        existing_pid = _read_pid(pid_file)
        if existing_pid is None:
            pid_file.unlink(missing_ok=True)
        elif existing_pid != os.getpid() and not _pid_exists(existing_pid):
            pid_file.unlink(missing_ok=True)

        if workspace_mode == "default":
            runtime_workdir.mkdir(parents=True, exist_ok=True)
            if runtime_workdir != original_cwd:
                os.chdir(runtime_workdir)
                changed_cwd = True

        log.info(
            "workspace runtime configured",
            mode=workspace_mode,
            root=str(workspace_root),
            cwd=str(Path.cwd()),
        )

        for bot in bots:
            await bot.start()
            log.info("Telegram bot polling started", bot=bot.alias)

        # Only start web UI if specifically enabled AND this is either the global daemon or the 'main' bot.
        if config.web.enabled and (not bot_alias or bot_alias == "main"):
            from otto.web import ConfigServer

            web_server = ConfigServer(config, port=config.web.port, bots=bots)
            await web_server.start()
            log.info(f"web ui started on http://127.0.0.1:{config.web.port}")
        scheduler_task = asyncio.create_task(_scheduler_loop(scheduler, fire, stop_event))
        _write_pid_file(pid_file)
        log.info("Otto is running (PID %s). Waiting for messages...", os.getpid())

        # If a CLI channel is attached, run it as the foreground blocking task.
        # When the CLI exits, we trigger a full shutdown.
        if cli_channel is not None:
            cli_task = asyncio.create_task(cli_channel.start())

        wait_tasks: set[asyncio.Task[None]] = {scheduler_task}
        shutdown_wait_task = asyncio.create_task(stop_event.wait())
        wait_tasks.add(shutdown_wait_task)
        if cli_task is not None:
            wait_tasks.add(cli_task)

        done, _ = await asyncio.wait(wait_tasks, return_when=asyncio.FIRST_COMPLETED)

        # If the CLI channel finished, trigger shutdown.
        if cli_task is not None and cli_task in done:
            stop_event.set()

        if scheduler_task in done:
            scheduler_task.result()
    finally:
        stop_event.set()

        for task in (shutdown_wait_task, scheduler_task, cli_task):
            if task is None:
                continue
            task.cancel()
            with suppress(asyncio.CancelledError):
                await task

        if cli_channel is not None:
            with suppress(Exception):
                await cli_channel.stop()

        for bot in bots:
            with suppress(Exception):
                await bot.stop()
        if web_server is not None:
            with suppress(Exception):
                await web_server.stop()
        with suppress(Exception):
            scheduler.close()
        for memory in memories:
            with suppress(Exception):
                memory.close()
        with suppress(Exception):
            await gateway.close()
        pid_file.unlink(missing_ok=True)
        with suppress(Exception):
            if lock.is_locked:
                lock.release()

        for sig in registered_async_signals:
            with suppress(Exception):
                loop.remove_signal_handler(sig)
        for sig, previous_handler in previous_sync_handlers.items():
            with suppress(Exception):
                signal.signal(sig, previous_handler)
        if changed_cwd:
            with suppress(Exception):
                os.chdir(original_cwd)


def start_daemon(bot_alias: str | None = None) -> None:
    """Load config and run Otto services."""
    config = load_config()
    asyncio.run(start_services(config, bot_alias=bot_alias))


def stop_daemon(bot_alias: str | None = None) -> None:
    """Send SIGTERM to all detected Otto daemon processes or a specific bot."""
    pid_file = _pid_file(bot_alias)
    pids: set[int] = set(_discover_run_pids(bot_alias))
    tracked_pid = _read_pid(pid_file)
    if tracked_pid is not None:
        pids.add(tracked_pid)

    if not pids:
        pid_file.unlink(missing_ok=True)
        if bot_alias:
            print(f"Otto ({bot_alias}) is not running.")
        else:
            print("Otto is not running.")
        return

    stopped: list[int] = []
    for pid in sorted(pids):
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            continue
        stopped.append(pid)

    pid_file.unlink(missing_ok=True)

    if not stopped:
        if bot_alias:
            print(f"Otto ({bot_alias}) is not running.")
        else:
            print("Otto is not running.")
        return

    target = f"Otto ({bot_alias})" if bot_alias else "Otto"
    if len(stopped) == 1:
        print(f"Sent stop signal to {target} (PID {stopped[0]}).")
        return
    joined = ", ".join(str(pid) for pid in stopped)
    print(f"Sent stop signal to {target} processes: {joined}.")


def is_running(bot_alias: str | None = None) -> bool:
    """Return whether a live daemon process exists."""
    pid_file = _pid_file(bot_alias)
    pid = _read_pid(pid_file)
    if pid is None:
        pid_file.unlink(missing_ok=True)
    elif _pid_exists(pid):
        return True

    if pid is not None:
        pid_file.unlink(missing_ok=True)

    return bool(_discover_run_pids(bot_alias))


__all__ = ["is_running", "start_daemon", "start_services", "stop_daemon"]
