from __future__ import annotations

import logging
from datetime import UTC, datetime
from pathlib import Path

from otto.config import OTTO_HOME
from otto.skills import discover, format_skills_prompt

logger = logging.getLogger(__name__)

DEFAULT_NAME = "Otto"
IDENTITY_KEY = "identity"
MAX_MEMORY_ITEMS = 10

_CORE = """You are {name}, an autonomous AI assistant that acts on the user's behalf."""

_FORMAT_TELEGRAM_HTML = """
Output format: Format ALL responses in Telegram HTML. Supported tags: <b>, <i>, <u>, <s>, <code>, <pre>, <a href="...">, <blockquote>. Do NOT use Markdown syntax — no **, no ```, no #. Escape &, <, > as &amp; &lt; &gt; in plain text."""

_FORMAT_MARKDOWN = """
Output format: Use standard Markdown formatting."""

_ENV_CLI = """
Environment: You are running in the user's terminal (CLI). The user is at their computer with direct filesystem access. You can reference local file paths, suggest shell commands, and output code blocks they can copy-paste. Be technical and direct. Prefer showing over explaining — output commands, code, and file contents inline rather than describing what to do. Long responses are fine when the content is useful (code, data, configs)."""

_ENV_TELEGRAM = """
Environment: You are in a Telegram chat. The user may be on mobile. Keep responses concise — avoid long code blocks or verbose output. When referencing files, send them as attachments rather than inlining content. Summarize rather than dump. If the user needs detailed output, ask if they want it or offer to send it as a file."""

# Legacy alias — kept so existing imports/tests referencing _FORMAT still work.
_FORMAT = _FORMAT_TELEGRAM_HTML

_BEHAVIORAL = """
Default behavior (these are defaults — identity/persona instructions override them):
Be concise. No filler. No emoji unless asked. Don't narrate a plan and ask "Shall I proceed?" — just execute. If a step requires confirmation (destructive, costly, irreversible), ask about that specific step only."""

_STRUCTURAL = """
Use tools to accomplish tasks — don't explain how to do something when you can just do it. When the user asks you to do something and you have tools for it, do it immediately.
Your capabilities (always available):
- memory_store / memory_get / memory_search: persist and recall information across sessions
- read_file / write_file / edit_file: filesystem access within workspace
- list_dir / glob / grep: explore and search files
- bash: run shell commands
- web_search / fetch / browse: search and read web content
- set_reminder / schedule / cancel_schedule: time-based tasks
- send_message / send_file: send content to the user
- create_skill / use_skill: extend your own capabilities
When a tool call fails, report the error concisely and try an alternative approach. Don't retry the same call repeatedly.
Identity/persona instructions override default behavior but not these structural capabilities."""

_IDENTITY_INSTRUCTION = """
If the user asks you to change your name, persona, or behavior style, use memory_store with key "{identity_key}" to save it. Include both identity (name/personality) and any behavioral rules they specify. This persists across sessions."""


def _categorize_memory(key: str) -> str | None:
    """Infer a display category from a memory key. Returns None to skip the item."""
    lower = key.lower()
    if lower.startswith("pref:") or lower.startswith("preference:"):
        return "preference"
    if lower == "identity":
        return None
    if lower.startswith("fact:"):
        return "fact"
    return "context"


def _format_block(output_format: str) -> str | None:
    """Return the format instruction block for the given output_format, or None to omit.

    Recognized values: "telegram_html", "markdown", "plain".
    Unknown values are treated as "plain" (no format block) with a warning logged.
    """
    if output_format == "telegram_html":
        return _FORMAT_TELEGRAM_HTML
    if output_format == "markdown":
        return _FORMAT_MARKDOWN
    if output_format != "plain":
        logger.warning("Unknown output_format %r, falling back to plain", output_format)
    return None


def build_system_prompt(
    *,
    memory_context: list[dict] | None = None,
    identity: str | None = None,
    provider_prefix: str | None = None,
    output_format: str = "telegram_html",
    skills_dirs: list[Path] | None = None,
    repo_context: str | None = None,
) -> str:
    parts: list[str] = []

    # 1. Provider prefix (if any).
    if provider_prefix:
        parts.append(provider_prefix.strip())

    # 2. Identity OR defaults (_CORE + _BEHAVIORAL).
    if identity:
        parts.append(identity.strip())
    else:
        parts.append(_CORE.format(name=DEFAULT_NAME))
        parts.append(_BEHAVIORAL)

    # 3. Structural capabilities (always present).
    parts.append(_STRUCTURAL)

    # 3.5. Active repo context (injected by repo_map tool).
    if repo_context:
        parts.append(repo_context)

    # 4. Format + environment.
    fmt = _format_block(output_format)
    if fmt is not None:
        parts.append(fmt)
    if output_format == "markdown":
        parts.append(_ENV_CLI)
    elif output_format == "telegram_html":
        parts.append(_ENV_TELEGRAM)

    # 5. Datetime.
    now = datetime.now(UTC).strftime("%A, %B %d, %Y %H:%M UTC")
    parts.append(f"\nCurrent date and time: {now}")

    # 6. Memory / identity instruction.
    parts.append(_IDENTITY_INSTRUCTION.format(identity_key=IDENTITY_KEY))

    # 7. Memory context (capped, categorized).
    if memory_context:
        lines = ["", "Relevant memories:"]
        for item in memory_context[:MAX_MEMORY_ITEMS]:
            cat = _categorize_memory(item["key"])
            if cat is None:
                continue
            lines.append(f"- [{cat}] {item['key']}: {item['snippet']}")
        if len(lines) > 2:
            parts.append("\n".join(lines))

    # 8. Skills.
    dirs = skills_dirs if skills_dirs is not None else [OTTO_HOME / "skills"]
    seen_names: set[str] = set()
    all_skills = []
    for d in dirs:
        for skill in discover(d):
            if skill.name not in seen_names:
                seen_names.add(skill.name)
                all_skills.append(skill)
    if all_skills:
        parts.append(format_skills_prompt(all_skills))

    return "\n".join(parts)
