from __future__ import annotations

import asyncio
import difflib
import fnmatch
import json
import os
import re
import shutil
import socket
import ssl
import urllib.error
import urllib.request
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Any
from zoneinfo import ZoneInfo

from otto.agent import Tool
from otto.config import OTTO_HOME
from otto.lint import auto_lint

if TYPE_CHECKING:
    from otto.memory import Memory
    from otto.scheduler import Scheduler

_EXA_ENDPOINT = "https://mcp.exa.ai/mcp"
_WORKSPACE_MODE_ENV = "OTTO_WORKSPACE_MODE"
_WORKSPACE_ROOT_ENV = "OTTO_WORKSPACE_ROOT"
_RG_PATH: str | None = shutil.which("rg")


@dataclass(frozen=True)
class _WorkspaceContext:
    strict_mode: bool
    root: Path | None = None
    error: str | None = None


# === Tool Registry ===
# Format: (name, description, schema_fn, execute_fn)
def _tool_registry(
    workspace: _WorkspaceContext,
) -> list[tuple[str, str, Callable[[], dict[str, Any]], Callable[..., Any]]]:
    edit_failures: dict[str, int] = {}

    async def _read_file(path: str, offset: int = 0, limit: int = 2000, raw: bool = False) -> str:
        return await _read_file_execute(
            path, offset=offset, limit=limit, raw=raw, workspace=workspace
        )

    async def _write_file(path: str, content: str) -> str:
        return await _write_file_execute(path, content, workspace=workspace)

    async def _edit_file(
        path: str,
        old_text: str = "",
        new_text: str = "",
        replace_all: bool = False,
        diff: str = "",
    ) -> str:
        return await _edit_file_execute(
            path,
            old_text,
            new_text,
            replace_all=replace_all,
            diff=diff,
            workspace=workspace,
            edit_failures=edit_failures,
        )

    async def _glob(pattern: str, path: str | None = None) -> str:
        return await _glob_execute(pattern, path=path, workspace=workspace)

    async def _grep(
        pattern: str,
        path: str | None = None,
        include: str | None = None,
        context: int = 0,
        type: str | None = None,
    ) -> str:
        return await _grep_execute(
            pattern,
            path=path,
            include=include,
            context=context,
            file_type=type,
            workspace=workspace,
        )

    async def _list_dir(path: str = ".", show_hidden: bool = False) -> str:
        return await _list_dir_execute(path=path, show_hidden=show_hidden, workspace=workspace)

    async def _bash(command: str, timeout: int = 120) -> str:
        return await _bash_execute(command, timeout=timeout, workspace=workspace)

    return [
        # File tools
        (
            "read_file",
            "Read file contents with optional line offset/limit.",
            _read_file_schema,
            _read_file,
        ),
        (
            "write_file",
            (
                "Write text to a file (creates parent dirs). Use ONLY for new files or"
                " as a last resort after edit_file fails. Prefer edit_file for modifying"
                " existing files."
            ),
            _write_file_schema,
            _write_file,
        ),
        (
            "edit_file",
            (
                "Edit a file. Preferred mode: pass a unified diff string."
                " Fallback: pass old_text/new_text for exact string replacement."
                " Always read_file first before editing."
            ),
            _edit_file_schema,
            _edit_file,
        ),
        (
            "glob",
            "Find files by name pattern. Uses Python glob syntax: *.py (top-level), **/*.py"
            " (recursive), auth/*.py (subdirectory). Returns relative paths sorted by"
            " modification time (newest first), capped at 500 results. Searches hidden"
            " directories. Always use read_file to inspect matches.",
            _glob_schema,
            _glob,
        ),
        (
            "grep",
            "Search file contents with regex. Returns file:line:match format, capped at 500"
            " lines. Supports context lines around matches, file type filters (py, js, ts),"
            " and glob-based path filters. Searches recursively from path (default: cwd)."
            " Use for finding function definitions, imports, string literals, or any text"
            " pattern across a codebase.",
            _grep_schema,
            _grep,
        ),
        (
            "list_dir",
            "List directory contents with basic type markers.",
            _list_dir_schema,
            _list_dir,
        ),
        # System tools
        ("bash", "Run a shell command and return combined output.", _bash_schema, _bash),
        # Web tools
        ("web_search", "Search the web via Exa MCP.", _web_search_schema, _web_search_execute),
        ("fetch", "Fetch content from a URL.", _fetch_schema, _fetch_execute),
        # Vision tools
        (
            "view_image",
            "View an image file. Returns the image so you can see and describe its contents.",
            _view_image_schema,
            _view_image_execute,
        ),
        # Browser tools
        (
            "browse",
            (
                "Open a web page in a headless browser. Can take screenshots, extract text,"
                " click elements, or fill forms. Returns screenshots as viewable images."
            ),
            _browse_schema,
            _browse_execute,
        ),
    ]


# === Registry Builder ===
def create_tools(
    *,
    memory: Memory | None = None,
    workspace_mode: str | None = None,
    workspace_root: str | Path | None = None,
) -> list[Tool]:
    """Return all built-in tools."""
    workspace = _workspace_context(workspace_mode=workspace_mode, workspace_root=workspace_root)
    tools = [
        Tool(name, desc, schema_fn(), exec_fn)
        for name, desc, schema_fn, exec_fn in _tool_registry(workspace)
    ]
    tools.extend(_create_skill_tools())
    if memory is not None:
        tools.extend(_create_memory_tools(memory))
    tools.extend(_create_list_skills_tool(tools))
    return tools


def _resolve_timezone(timezone: str | None) -> ZoneInfo | None:
    if timezone is None or timezone == "UTC":
        return None
    try:
        return ZoneInfo(timezone)
    except (KeyError, ValueError):
        return None


def create_session_tools(
    *,
    chat_id: str,
    scheduler: Scheduler | None = None,
    notify: Callable[[str], Awaitable[None]] | None = None,
    send_file: Callable[[str, str | None], Awaitable[None]] | None = None,
    timezone: str | None = None,
    workspace_mode: str | None = None,
    workspace_root: str | Path | None = None,
) -> list[Tool]:
    """Create tools that need per-conversation context."""
    tz = _resolve_timezone(timezone)
    tools: list[Tool] = []
    if scheduler is not None:
        tools.extend(_create_scheduler_tools(chat_id, scheduler, tz=tz))
    if notify is not None:
        tools.extend(_create_notify_tools(notify))
    if send_file is not None:
        tools.extend(_create_send_file_tools(send_file))
    workspace = _workspace_context(workspace_mode=workspace_mode, workspace_root=workspace_root)
    tools.extend(_create_repomap_tool(chat_id, workspace))
    return tools


def _create_memory_tools(memory: Memory) -> list[Tool]:
    async def _memory_search(query: str, limit: int = 5) -> str:
        return await _memory_search_execute(memory, query, limit=limit)

    async def _memory_store(key: str, content: str) -> str:
        return await _memory_store_execute(memory, key, content)

    return [
        Tool(
            "memory_search",
            "Search memory for relevant context",
            _memory_search_schema(),
            _memory_search,
        ),
        Tool(
            "memory_store", "Store a fact or note in memory", _memory_store_schema(), _memory_store
        ),
    ]


def _create_skill_tools() -> list[Tool]:
    async def _create_skill(
        name: str,
        description: str,
        content: str,
        license: str | None = None,
        compatibility: str | None = None,
        scripts: dict[str, Any] | None = None,
    ) -> str:
        return await _create_skill_execute(
            name,
            description,
            content,
            license=license,
            compatibility=compatibility,
            scripts=scripts,
        )

    async def _use_skill(name: str) -> str:
        return await _use_skill_execute(name)

    return [
        Tool(
            "create_skill",
            "Create a new agent skill with SKILL.md and optional scripts",
            _create_skill_schema(),
            _create_skill,
        ),
        Tool(
            "use_skill",
            "Load a skill's full instructions into context",
            _use_skill_schema(),
            _use_skill,
        ),
    ]


# === List Skills Tool ===
def _list_skills_schema() -> dict[str, Any]:
    return _schema(
        {
            "filter": {
                "type": "string",
                "description": "Optional keyword to filter tools by name or description",
                "default": "",
            },
        },
        [],
    )


def _list_skills_execute(tools: list[Tool], *, filter: str = "") -> str:
    keyword = filter.strip().lower()
    lines: list[str] = []
    for tool in tools:
        if keyword and keyword not in tool.name.lower() and keyword not in tool.description.lower():
            continue
        lines.append(f"{tool.name} — {tool.description}")
    if not lines:
        return f"No tools matching '{filter}'" if keyword else "No tools available"
    return "\n".join(lines)


def _create_list_skills_tool(tools: list[Tool]) -> list[Tool]:
    async def _list_skills(filter: str = "") -> str:
        return _list_skills_execute(tools, filter=filter)

    return [
        Tool(
            "list_skills",
            "List available tools and skills with optional keyword filter.",
            _list_skills_schema(),
            _list_skills,
        )
    ]


# === Repo Map Tool (optional — requires tree-sitter) ===

# Cache RepoMap instances per resolved root so repeated calls are fast.
_repomap_cache: dict[Path, Any] = {}


def _create_repomap_tool(chat_id: str, workspace: _WorkspaceContext) -> list[Tool]:
    try:
        from otto.repomap import RepoMap
    except ImportError:
        return []

    from otto.repo_context import set_context

    default_root = workspace.root if workspace.root else Path.cwd()

    def _resolve_root(raw_path: str | None) -> Path:
        """Resolve a user-supplied path to an absolute project root."""
        if raw_path is None or raw_path.strip() in ("", "."):
            return default_root.resolve()
        p = Path(raw_path).expanduser()
        if not p.is_absolute():
            p = default_root / p
        return p.resolve()

    def _get_or_build(root: Path) -> Any:
        if root not in _repomap_cache:
            _repomap_cache[root] = RepoMap(root=root)
        return _repomap_cache[root]

    async def _repo_map(query: str = "", path: str | None = None, max_results: int = 60) -> str:
        query = query or ""

        # UX: when users call repo_map with a single positional argument, it often ends up
        # in `query` even if it's actually a filesystem path. Detect that case.
        raw = query.strip()
        if path is None and raw and raw.startswith(("/", "~", ".", "\\")):
            path = raw
            query = ""

        root = _resolve_root(path)
        repo = _get_or_build(root)
        skeleton = await asyncio.to_thread(repo.query, query, max_results)
        # Persist for system prompt injection on subsequent turns.
        set_context(chat_id, root, skeleton)
        return skeleton

    schema: dict[str, Any] = {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": (
                    "Natural language description of what you're looking for."
                    " If empty, returns a general project overview."
                    " If you pass a path as the only argument, it will be treated as `path`."
                ),
                "default": "",
            },
            "path": {
                "type": "string",
                "description": (
                    "Root directory of the project to map."
                    " Defaults to the current workspace directory."
                ),
            },
            "max_results": {
                "type": "integer",
                "description": "Maximum number of symbols to return (default 60).",
                "default": 60,
            },
        },
    }

    return [
        Tool(
            "repo_map",
            (
                "Get a structural overview of a codebase — function/class"
                " signatures ranked by relevance to your query. The result is"
                " automatically kept in context for the rest of the session."
                " Use when starting work on a project to understand its structure."
            ),
            schema,
            _repo_map,
        )
    ]


# === Scheduler Tools ===
def _create_scheduler_tools(
    chat_id: str, scheduler: Scheduler, *, tz: ZoneInfo | None = None
) -> list[Tool]:
    async def _set_reminder(message: str, delay: str) -> str:
        return await _set_reminder_execute(chat_id, scheduler, message, delay, tz=tz)

    async def _schedule(prompt: str, cron: str) -> str:
        return await _schedule_execute(chat_id, scheduler, prompt, cron, tz=tz)

    async def _list_schedules() -> str:
        return await _list_schedules_execute(chat_id, scheduler, tz=tz)

    async def _cancel_schedule(task_id: str) -> str:
        return await _cancel_schedule_execute(scheduler, task_id)

    return [
        Tool(
            "set_reminder",
            "Set a reminder that will notify you after a delay",
            _set_reminder_schema(),
            _set_reminder,
        ),
        Tool(
            "schedule",
            "Schedule a recurring task using cron syntax",
            _schedule_schema(),
            _schedule,
        ),
        Tool(
            "list_schedules",
            "List your scheduled tasks and reminders",
            _list_schedules_schema(),
            _list_schedules,
        ),
        Tool(
            "cancel_schedule",
            "Cancel a scheduled task or reminder",
            _cancel_schedule_schema(),
            _cancel_schedule,
        ),
    ]


def _set_reminder_schema() -> dict[str, Any]:
    return _schema(
        {
            "message": {"type": "string", "description": "Reminder message to send"},
            "delay": {
                "type": "string",
                "description": 'Delay from now (e.g. "2h", "30m", "1d")',
            },
        },
        ["message", "delay"],
    )


def _parse_delay(delay: str) -> timedelta | None:
    match = re.fullmatch(r"(\d+)([smhd])", delay.strip().lower())
    if match is None:
        return None
    amount = int(match.group(1))
    unit = match.group(2)
    if unit == "s":
        return timedelta(seconds=amount)
    if unit == "m":
        return timedelta(minutes=amount)
    if unit == "h":
        return timedelta(hours=amount)
    if unit == "d":
        return timedelta(days=amount)
    return None


def _humanize_datetime(value: datetime | None, tz: ZoneInfo | None = None) -> str:
    if value is None:
        return "unknown"
    target = tz if tz is not None else UTC
    converted = value.astimezone(target)
    label = converted.strftime("%Z") or str(target)
    return converted.strftime(f"%Y-%m-%d %H:%M:%S {label}")


def _utc_now() -> datetime:
    return datetime.now(UTC)


async def _set_reminder_execute(
    chat_id: str,
    scheduler: Scheduler,
    message: str,
    delay: str,
    *,
    tz: ZoneInfo | None = None,
) -> str:
    delta = _parse_delay(delay)
    if delta is None:
        return 'Invalid delay. Use format like "30m", "2h", or "1d".'
    run_at = _utc_now() + delta
    try:
        task = scheduler.add(chat_id, f"__notify__:{message}", run_at=run_at)
    except Exception as exc:
        return f"Failed to set reminder: {exc}"
    return f"Reminder set for {_humanize_datetime(task.run_at, tz=tz)}."


def _schedule_schema() -> dict[str, Any]:
    return _schema(
        {
            "prompt": {"type": "string", "description": "Prompt to run on schedule"},
            "cron": {"type": "string", "description": 'Cron expression (e.g. "0 9 * * *")'},
        },
        ["prompt", "cron"],
    )


async def _schedule_execute(
    chat_id: str,
    scheduler: Scheduler,
    prompt: str,
    cron: str,
    *,
    tz: ZoneInfo | None = None,
) -> str:
    try:
        task = scheduler.add(chat_id, prompt, cron=cron)
    except Exception as exc:
        return f"Failed to schedule task: {exc}"
    return f"Scheduled task {task.id}. Next run: {_humanize_datetime(task.run_at, tz=tz)}"


def _list_schedules_schema() -> dict[str, Any]:
    return _schema({}, [])


async def _list_schedules_execute(
    chat_id: str, scheduler: Scheduler, *, tz: ZoneInfo | None = None
) -> str:
    try:
        tasks = scheduler.list(chat_id)
    except Exception as exc:
        return f"Failed to list schedules: {exc}"

    lines = ["ID | Type | Next Run | Prompt"]
    for task in tasks:
        task_type = task.cron if task.cron is not None else "(one-shot)"
        lines.append(
            f"{task.id} | {task_type} | {_humanize_datetime(task.run_at, tz=tz)} | {task.prompt}"
        )
    return "\n".join(lines)


def _cancel_schedule_schema() -> dict[str, Any]:
    return _schema({"task_id": {"type": "string", "description": "Task ID to cancel"}}, ["task_id"])


async def _cancel_schedule_execute(scheduler: Scheduler, task_id: str) -> str:
    try:
        removed = scheduler.remove(task_id)
    except Exception as exc:
        return f"Failed to cancel schedule: {exc}"
    if removed:
        return f"Cancelled schedule: {task_id}"
    return f"Schedule not found: {task_id}"


# === Notify Tools ===
def _create_notify_tools(notify: Callable[[str], Awaitable[None]]) -> list[Tool]:
    async def _send_message(text: str) -> str:
        return await _send_message_execute(notify, text)

    return [
        Tool(
            "send_message",
            "Send a message to the user proactively",
            _send_message_schema(),
            _send_message,
        )
    ]


def _send_message_schema() -> dict[str, Any]:
    return _schema({"text": {"type": "string", "description": "Message text"}}, ["text"])


async def _send_message_execute(notify: Callable[[str], Awaitable[None]], text: str) -> str:
    await notify(text)
    return "Message sent."


# === Send File Tools ===
def _create_send_file_tools(
    send_file: Callable[[str, str | None], Awaitable[None]],
) -> list[Tool]:
    async def _send_file(path: str, caption: str = "") -> str:
        return await _send_file_execute(send_file, path, caption or None)

    return [
        Tool(
            "send_file",
            "Send a file to the user (documents, images, PDFs, etc.)",
            _send_file_schema(),
            _send_file,
        )
    ]


def _send_file_schema() -> dict[str, Any]:
    return _schema(
        {
            "path": {"type": "string", "description": "Absolute path to the file to send"},
            "caption": {"type": "string", "description": "Optional caption for the file"},
        },
        ["path"],
    )


async def _send_file_execute(
    send_file: Callable[[str, str | None], Awaitable[None]],
    path: str,
    caption: str | None,
) -> str:
    resolved = Path(path).expanduser()
    if not resolved.is_file():
        return f"File not found: {path}"
    await send_file(str(resolved), caption)
    return f"Sent file: {resolved.name}"


# === Implementation ===


# === Schema Helpers ===
def _schema(properties: dict[str, Any], required: list[str]) -> dict[str, Any]:
    return {"type": "object", "properties": properties, "required": required}


# === File Tools ===
def _workspace_context(
    *,
    workspace_mode: str | None = None,
    workspace_root: str | Path | None = None,
) -> _WorkspaceContext:
    raw_mode = (
        workspace_mode if workspace_mode is not None else os.getenv(_WORKSPACE_MODE_ENV, "default")
    )
    strict_mode = str(raw_mode).strip().lower() == "strict"
    if not strict_mode:
        return _WorkspaceContext(strict_mode=False)

    configured_root = (
        workspace_root if workspace_root is not None else os.getenv(_WORKSPACE_ROOT_ENV)
    )
    if configured_root is None or not str(configured_root).strip():
        return _WorkspaceContext(
            strict_mode=True,
            error=(f"{_WORKSPACE_ROOT_ENV} is required when {_WORKSPACE_MODE_ENV}=strict"),
        )

    root = Path(str(configured_root)).expanduser()
    try:
        resolved_root = root.resolve(strict=True)
    except Exception as exc:
        return _WorkspaceContext(
            strict_mode=True,
            error=f"workspace root '{root}' is invalid: {exc}",
        )

    if not resolved_root.is_dir():
        return _WorkspaceContext(
            strict_mode=True,
            error=f"workspace root '{resolved_root}' is not a directory",
        )
    return _WorkspaceContext(strict_mode=True, root=resolved_root)


def _strict_denial(reason: str) -> str:
    return f"Strict workspace mode denied: {reason}"


def _is_within_workspace(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _resolve_tool_path(
    raw_path: str | None,
    *,
    workspace: _WorkspaceContext,
    default_path: str = ".",
) -> tuple[Path | None, str | None]:
    candidate_text = default_path if raw_path is None else str(raw_path)
    if candidate_text == "":
        candidate_text = default_path

    candidate = Path(candidate_text).expanduser()
    if not workspace.strict_mode:
        return candidate, None

    if workspace.error:
        return None, _strict_denial(workspace.error)

    root = workspace.root
    if root is None:
        return None, _strict_denial("workspace root is not configured")

    scoped = candidate if candidate.is_absolute() else root / candidate
    try:
        resolved = scoped.resolve(strict=False)
    except Exception as exc:
        return None, _strict_denial(f"path '{candidate_text}' could not be resolved: {exc}")

    if not _is_within_workspace(resolved, root):
        return (
            None,
            _strict_denial(f"path '{candidate_text}' resolves outside workspace root '{root}'"),
        )
    return resolved, None


def _workspace_or_default(workspace: _WorkspaceContext | None) -> _WorkspaceContext:
    return workspace if workspace is not None else _WorkspaceContext(strict_mode=False)


def _candidate_within_workspace(path: Path, workspace: _WorkspaceContext) -> bool:
    if not workspace.strict_mode:
        return True
    root = workspace.root
    if root is None:
        return False
    try:
        return _is_within_workspace(path.resolve(strict=False), root)
    except Exception:
        return False


def _bash_disabled_message() -> str:
    return "bash is disabled in strict workspace mode (v0)."


def _read_file_schema() -> dict[str, Any]:
    return _schema(
        {
            "path": {"type": "string", "description": "Path to file to read"},
            "offset": {"type": "integer", "description": "Zero-based line offset"},
            "limit": {"type": "integer", "description": "Maximum lines to read (max 2000)"},
            "raw": {
                "type": "boolean",
                "description": "Output without line-number prefixes (for copy-paste into diffs)",
                "default": False,
            },
        },
        ["path"],
    )


async def _read_file_execute(
    path: str,
    offset: int = 0,
    limit: int = 2000,
    raw: bool = False,
    *,
    workspace: _WorkspaceContext | None = None,
) -> str:
    workspace_ctx = _workspace_or_default(workspace)
    file_path, denial = _resolve_tool_path(path, workspace=workspace_ctx)
    if denial is not None:
        return denial
    if file_path is None:
        return f"File not found: {path}"

    if not file_path.exists():
        return f"File not found: {path}"
    if not file_path.is_file():
        return f"Not a file: {path}"

    try:
        content = await asyncio.to_thread(file_path.read_text, encoding="utf-8", errors="replace")
    except Exception as exc:
        return f"Failed to read file: {exc}"

    start = max(0, int(offset or 0))
    max_lines = max(1, min(int(limit or 2000), 2000))
    selected = content.splitlines()[start : start + max_lines]
    if raw:
        return "\n".join(selected)
    return "\n".join(f"{line_no:>3}| {line}" for line_no, line in enumerate(selected, start + 1))


def _write_file_schema() -> dict[str, Any]:
    return _schema(
        {
            "path": {"type": "string", "description": "Path to file to write"},
            "content": {"type": "string", "description": "Content to write"},
        },
        ["path", "content"],
    )


async def _write_file_execute(
    path: str,
    content: str,
    *,
    workspace: _WorkspaceContext | None = None,
) -> str:
    workspace_ctx = _workspace_or_default(workspace)
    file_path, denial = _resolve_tool_path(path, workspace=workspace_ctx)
    if denial is not None:
        return denial
    if file_path is None:
        return f"Failed to write file: invalid path '{path}'"

    try:
        await asyncio.to_thread(file_path.parent.mkdir, parents=True, exist_ok=True)
        await asyncio.to_thread(file_path.write_text, content, encoding="utf-8")
    except Exception as exc:
        return f"Failed to write file: {exc}"
    return await _append_lint(file_path, f"Wrote {len(content)} bytes to {path}")


def _edit_file_schema() -> dict[str, Any]:
    return _schema(
        {
            "path": {"type": "string", "description": "Path to file to edit"},
            "old_text": {"type": "string", "description": "Exact text to replace"},
            "new_text": {"type": "string", "description": "Replacement text"},
            "replace_all": {"type": "boolean", "description": "Replace every occurrence"},
            "diff": {
                "type": "string",
                "description": "Unified diff to apply (preferred over old_text/new_text)",
            },
        },
        [],
    )


_LINE_PREFIX_RE = re.compile(r"^\s*\d+\| ")


def _strip_line_prefix(line: str) -> str:
    return _LINE_PREFIX_RE.sub("", line)


def _apply_diff(content: str, diff_text: str) -> tuple[str | None, str | None]:
    lines = content.splitlines(keepends=True)
    if lines and not lines[-1].endswith("\n"):
        lines[-1] += "\n"

    hunks: list[tuple[int, int, list[str]]] = []
    current_start = 0
    current_count = 0
    current_ops: list[str] = []
    in_hunk = False

    for raw_line in diff_text.splitlines():
        hunk_match = re.match(r"^@@ -(\d+)(?:,(\d+))? \+\d+(?:,\d+)? @@", raw_line)
        if hunk_match:
            if in_hunk:
                hunks.append((current_start, current_count, current_ops))
            current_start = int(hunk_match.group(1)) - 1
            current_count = int(hunk_match.group(2)) if hunk_match.group(2) else 1
            current_ops = []
            in_hunk = True
            continue

        if not in_hunk:
            continue

        if raw_line.startswith("---") or raw_line.startswith("+++"):
            continue

        current_ops.append(raw_line)

    if in_hunk:
        hunks.append((current_start, current_count, current_ops))

    if not hunks:
        return None, "No valid hunks found in diff"

    hunks.sort(key=lambda h: h[0], reverse=True)

    for start, _count, ops in hunks:
        ctx_idx = start
        new_lines: list[str] = []
        for op in ops:
            if op.startswith("+"):
                payload = op[1:]
                new_lines.append(payload + "\n")
            elif op.startswith("-"):
                payload = _strip_line_prefix(op[1:])
                if ctx_idx >= len(lines):
                    return None, _diff_context_error(lines, ctx_idx, payload)
                actual = lines[ctx_idx].rstrip("\n")
                if actual != payload:
                    return None, _diff_context_error(lines, ctx_idx, payload)
                ctx_idx += 1
            else:
                payload = _strip_line_prefix(op[1:] if op.startswith(" ") else op)
                if ctx_idx >= len(lines):
                    return None, _diff_context_error(lines, ctx_idx, payload)
                actual = lines[ctx_idx].rstrip("\n")
                if actual != payload:
                    return None, _diff_context_error(lines, ctx_idx, payload)
                new_lines.append(lines[ctx_idx])
                ctx_idx += 1

        lines[start:ctx_idx] = new_lines

    result = "".join(lines)
    if content and not content.endswith("\n"):
        result = result.rstrip("\n")
    return result, None


def _diff_context_error(lines: list[str], idx: int, expected: str) -> str:
    total = len(lines)
    start = max(0, idx - 3)
    end = min(total, idx + 4)
    context_lines = []
    for i in range(start, end):
        marker = ">>>" if i == idx else "   "
        context_lines.append(f"{marker} {i + 1:>3}| {lines[i].rstrip(chr(10))}")
    context = "\n".join(context_lines)
    actual = lines[idx].rstrip("\n") if idx < total else "(past end of file)"
    return (
        f"Diff context mismatch at line {idx + 1}:\n"
        f"  expected: {expected}\n"
        f"  actual:   {actual}\n"
        f"Nearby content:\n{context}"
    )


def _find_closest_match(content: str, old_text: str) -> str | None:
    old_lines = old_text.splitlines()
    content_lines = content.splitlines()
    if not old_lines or not content_lines:
        return None

    best_ratio = 0.0
    best_start = 0
    window = len(old_lines)

    for i in range(max(1, len(content_lines) - window + 1)):
        candidate = content_lines[i : i + window]
        ratio = difflib.SequenceMatcher(None, old_lines, candidate).ratio()
        if ratio > best_ratio:
            best_ratio = ratio
            best_start = i

    if best_ratio < 0.6:
        return None

    candidate_lines = content_lines[best_start : best_start + window]
    diff_lines = list(difflib.unified_diff(old_lines, candidate_lines, lineterm="", n=1))
    if not diff_lines:
        return None

    location = f"lines {best_start + 1}-{best_start + window}"
    return f"Closest match ({best_ratio:.0%} similar) at {location}:\n" + "\n".join(diff_lines[2:])


def _has_line_prefix_pattern(text: str) -> bool:
    return bool(re.search(r"^\s*\d+\| ", text, re.MULTILINE))


@dataclass(frozen=True)
class _FuzzyMatch:
    """Result of a whitespace-normalized fuzzy match."""

    ratio: float
    start: int  # char offset in original content
    end: int  # char offset in original content
    start_line: int  # 1-indexed
    end_line: int  # 1-indexed
    matched_text: str


def _normalize_ws(line: str) -> str:
    """Collapse trailing whitespace and normalize tabs to spaces."""
    return line.replace("\t", "    ").rstrip()


def _fuzzy_find(content: str, old_text: str) -> _FuzzyMatch | None:
    """Find the best whitespace-normalized match for *old_text* in *content*.

    Returns a ``_FuzzyMatch`` with the similarity ratio and positions in the
    original content, or ``None`` if no match exceeds the 0.60 floor.
    """
    old_lines = old_text.splitlines()
    content_lines = content.splitlines()
    if not old_lines or not content_lines:
        return None

    norm_old = [_normalize_ws(ln) for ln in old_lines]
    norm_content = [_normalize_ws(ln) for ln in content_lines]
    window = len(norm_old)

    best_ratio = 0.0
    best_start = 0

    for i in range(max(1, len(norm_content) - window + 1)):
        candidate = norm_content[i : i + window]
        ratio = difflib.SequenceMatcher(None, norm_old, candidate).ratio()
        if ratio > best_ratio:
            best_ratio = ratio
            best_start = i

    if best_ratio < 0.6:
        return None

    # Map back to character offsets in the original content.
    lines_before = content_lines[:best_start]
    char_start = sum(len(ln) + 1 for ln in lines_before)  # +1 for newline
    matched_lines = content_lines[best_start : best_start + window]
    matched_text = "\n".join(matched_lines)
    char_end = char_start + len(matched_text)

    return _FuzzyMatch(
        ratio=best_ratio,
        start=char_start,
        end=char_end,
        start_line=best_start + 1,
        end_line=best_start + window,
        matched_text=matched_text,
    )


async def _edit_file_execute(
    path: str,
    old_text: str = "",
    new_text: str = "",
    replace_all: bool = False,
    diff: str = "",
    *,
    workspace: _WorkspaceContext | None = None,
    edit_failures: dict[str, int] | None = None,
) -> str:
    has_diff = bool(diff and diff.strip())
    has_old_new = bool(old_text)

    if not has_diff and not has_old_new:
        return "Provide either 'diff' or 'old_text'+'new_text'"

    workspace_ctx = _workspace_or_default(workspace)
    file_path, denial = _resolve_tool_path(path, workspace=workspace_ctx)
    if denial is not None:
        return denial
    if file_path is None:
        return f"File not found: {path}"

    if not file_path.exists():
        return f"File not found: {path}"
    if not file_path.is_file():
        return f"Not a file: {path}"

    try:
        content = await asyncio.to_thread(file_path.read_text, encoding="utf-8", errors="replace")
    except Exception as exc:
        return f"Failed to read file: {exc}"

    failures = edit_failures if edit_failures is not None else {}

    if has_diff:
        result, error = _apply_diff(content, diff)
        if error:
            failures[path] = failures.get(path, 0) + 1
            fail_count = failures[path]
            msg = f"Diff failed: {error}"
            if fail_count >= 3:
                msg += "\nConsider using write_file to replace the full file content."
            return msg
        assert result is not None

        try:
            await asyncio.to_thread(file_path.write_text, result, encoding="utf-8")
        except Exception as exc:
            return f"Failed to write file: {exc}"

        failures.pop(path, None)
        return await _append_lint(file_path, f"Applied diff to {path}")

    count = content.count(old_text)
    if count == 0:
        # ---- Tiered fuzzy matching ----
        fuzzy = _fuzzy_find(content, old_text)
        if fuzzy and fuzzy.ratio >= 0.98:
            # Auto-apply — almost certainly whitespace-only mismatch.
            updated = content[: fuzzy.start] + new_text + content[fuzzy.end :]
            try:
                await asyncio.to_thread(file_path.write_text, updated, encoding="utf-8")
            except Exception as exc:
                return f"Failed to write file: {exc}"
            failures.pop(path, None)
            return await _append_lint(
                file_path,
                f"Replaced 1 occurrence in {path}"
                f" (fuzzy match, {fuzzy.ratio:.0%} similar — whitespace normalized)",
            )

        failures[path] = failures.get(path, 0) + 1
        fail_count = failures[path]

        parts = ["old_text not found in file"]

        if _has_line_prefix_pattern(old_text):
            parts.append(
                "Hint: old_text contains line number prefixes from read_file"
                " — strip them and retry."
            )

        if fuzzy and fuzzy.ratio >= 0.90:
            parts.append(
                f"Fuzzy match ({fuzzy.ratio:.0%} similar) found at "
                f"lines {fuzzy.start_line}-{fuzzy.end_line}. "
                f"Retry with the exact text from the file."
            )
        else:
            closest = _find_closest_match(content, old_text)
            if closest:
                parts.append(closest)

        if fail_count >= 3:
            lines = content.splitlines()
            preview = "\n".join(f"{i + 1:>3}| {line}" for i, line in enumerate(lines[:20]))
            parts.append(f"File content (first 20 lines):\n{preview}")
            parts.append("Consider using write_file to replace the full file content.")

        return "\n".join(parts)

    if count > 1 and not replace_all:
        return (
            f"old_text appears {count} times. "
            "Set replace_all=true or provide more specific old_text."
        )

    replacement_count = count if replace_all else 1
    updated = content.replace(old_text, new_text, count if replace_all else 1)

    try:
        await asyncio.to_thread(file_path.write_text, updated, encoding="utf-8")
    except Exception as exc:
        return f"Failed to write file: {exc}"

    failures.pop(path, None)
    return await _append_lint(file_path, f"Replaced {replacement_count} occurrence(s) in {path}")


async def _append_lint(file_path: Path, result_msg: str) -> str:
    """Append lint results to a success message if lint errors are detected."""
    try:
        lint_output = await auto_lint(file_path)
    except Exception:
        return result_msg
    if lint_output:
        return f"{result_msg}\n\nLint errors detected:\n{lint_output}"
    return result_msg


def _glob_schema() -> dict[str, Any]:
    return _schema(
        {
            "pattern": {
                "type": "string",
                "description": "Glob pattern: *.py (top-level), **/*.py (recursive),"
                " auth/**/*.py (within subdir), test_*.py (prefix match)",
            },
            "path": {
                "type": "string",
                "description": "Base directory to search (default: current working directory)",
            },
        },
        ["pattern"],
    )


async def _glob_execute(
    pattern: str,
    path: str | None = None,
    *,
    workspace: _WorkspaceContext | None = None,
) -> str:
    workspace_ctx = _workspace_or_default(workspace)
    base, denial = _resolve_tool_path(path, workspace=workspace_ctx, default_path=".")
    if denial is not None:
        return denial
    if base is None:
        return f"Path not found: {path or '.'}"

    if not base.exists():
        return f"Path not found: {base}"

    if _RG_PATH and not workspace_ctx.strict_mode and not base.is_file():
        return await _glob_rg(pattern, base, workspace=workspace_ctx)

    return await _glob_python(pattern, base, workspace=workspace_ctx)


async def _glob_rg(pattern: str, base: Path, workspace: _WorkspaceContext) -> str:
    cmd = [
        _RG_PATH,
        "--files",
        "--color=never",
        "--hidden",
        "--glob",
        pattern,
        str(base),
    ]

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        stdout, _stderr = await asyncio.wait_for(proc.communicate(), timeout=30)
    except TimeoutError:
        return "glob timed out after 30 seconds"
    except Exception as exc:
        return f"glob failed: {exc}"

    output = (stdout or b"").decode("utf-8", errors="replace")
    if not output.strip():
        # rg glob semantics differ from Python — fall back to Python glob
        return await _glob_python(pattern, base, workspace=workspace)

    base_prefix = str(base) + "/"
    lines = [line.removeprefix(base_prefix) for line in output.splitlines() if line.strip()]
    lines.sort()
    if len(lines) > 500:
        lines = lines[:500]
    return "\n".join(lines)


async def _glob_python(
    pattern: str,
    base: Path,
    *,
    workspace: _WorkspaceContext,
) -> str:
    def _collect() -> list[Path]:
        if base.is_file():
            return [base] if fnmatch.fnmatch(base.name, pattern) else []
        files = [
            candidate
            for candidate in base.glob(pattern)
            if candidate.is_file() and _candidate_within_workspace(candidate, workspace)
        ]
        files.sort(key=lambda item: (item.stat().st_mtime, str(item)), reverse=True)
        return files[:500]

    try:
        matches = await asyncio.to_thread(_collect)
    except Exception as exc:
        return f"glob failed: {exc}"

    if base.is_file():
        return str(base) if matches else f"No matches for pattern: {pattern}"
    if not matches:
        return f"No matches for pattern: {pattern} in {base}"
    return "\n".join(str(candidate.relative_to(base)) for candidate in matches)


def _grep_schema() -> dict[str, Any]:
    return _schema(
        {
            "pattern": {
                "type": "string",
                "description": "Regex pattern: def main, import\\s+os, TODO|FIXME, class\\s+\\w+",
            },
            "path": {
                "type": "string",
                "description": "File or directory to search (default: current working directory)",
            },
            "include": {
                "type": "string",
                "description": "Glob filter for file paths, e.g. *.py, tests/*.py",
            },
            "context": {
                "type": "integer",
                "description": "Lines of context before and after each match (requires rg)",
            },
            "type": {
                "type": "string",
                "description": "File type filter: py, js, ts, rust, go, yaml, json, etc.",
            },
        },
        ["pattern"],
    )


async def _grep_execute(
    pattern: str,
    path: str | None = None,
    include: str | None = None,
    context: int = 0,
    file_type: str | None = None,
    *,
    workspace: _WorkspaceContext | None = None,
) -> str:
    workspace_ctx = _workspace_or_default(workspace)
    base, denial = _resolve_tool_path(path, workspace=workspace_ctx, default_path=".")
    if denial is not None:
        return denial
    if base is None:
        return f"Path not found: {path or '.'}"

    if not base.exists():
        return f"Path not found: {base}"

    if _RG_PATH and not workspace_ctx.strict_mode:
        return await _grep_rg(
            pattern,
            base,
            include=include,
            context=context,
            file_type=file_type,
        )

    return await _grep_python(pattern, base, include=include, workspace=workspace_ctx)


async def _grep_rg(
    pattern: str,
    base: Path,
    *,
    include: str | None = None,
    context: int = 0,
    file_type: str | None = None,
) -> str:
    cmd = [
        _RG_PATH,
        "--no-heading",
        "--line-number",
        "--color=never",
        "--max-columns=500",
        "--max-columns-preview",
    ]

    ctx = max(0, int(context or 0))
    if ctx > 0:
        cmd.extend(["-C", str(ctx)])

    if file_type:
        cmd.extend(["-t", file_type])
    if include:
        cmd.extend(["--glob", include])

    cmd.extend(["--", pattern, str(base)])

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)
    except TimeoutError:
        return "grep timed out after 30 seconds"
    except Exception as exc:
        return f"grep failed: {exc}"

    if proc.returncode == 2:
        err = (stderr or b"").decode("utf-8", errors="replace").strip()
        return f"grep failed: {err}" if err else "grep failed: rg error"

    output = (stdout or b"").decode("utf-8", errors="replace")
    lines = output.splitlines()
    if len(lines) > 500:
        lines = lines[:500]
        lines.append("... (truncated at 500 lines)")

    # Strip the base path prefix for cleaner output
    base_prefix = str(base) + "/"
    if not base.is_file():
        lines = [line.removeprefix(base_prefix) for line in lines]

    return "\n".join(lines)


async def _grep_python(
    pattern: str,
    base: Path,
    *,
    include: str | None = None,
    workspace: _WorkspaceContext,
) -> str:
    try:
        regex = re.compile(pattern)
    except re.error as exc:
        return f"Invalid regex: {exc}"

    def _search() -> list[str]:
        files = (
            [base]
            if base.is_file()
            else [candidate for candidate in base.rglob("*") if candidate.is_file()]
        )
        root = base.parent if base.is_file() else base
        results: list[str] = []

        for file_path in files:
            if not _candidate_within_workspace(file_path, workspace):
                continue
            rel = str(file_path.relative_to(root))
            if include and not fnmatch.fnmatch(rel, include):
                continue
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            display = str(file_path if base.is_file() else file_path.relative_to(base))
            for line_no, line in enumerate(content.splitlines(), 1):
                if regex.search(line):
                    results.append(f"{display}:{line_no}:{line}")
                    if len(results) >= 100:
                        return results
        return results

    try:
        return "\n".join(await asyncio.to_thread(_search))
    except Exception as exc:
        return f"grep failed: {exc}"


def _list_dir_schema() -> dict[str, Any]:
    return _schema(
        {
            "path": {
                "type": "string",
                "description": "Directory to list",
                "default": ".",
            },
            "show_hidden": {
                "type": "boolean",
                "description": "Include entries starting with '.'",
                "default": False,
            },
        },
        [],
    )


async def _list_dir_execute(
    path: str = ".",
    show_hidden: bool = False,
    *,
    workspace: _WorkspaceContext | None = None,
) -> str:
    workspace_ctx = _workspace_or_default(workspace)
    base, denial = _resolve_tool_path(path or ".", workspace=workspace_ctx, default_path=".")
    if denial is not None:
        return denial
    if base is None:
        return f"Path not found: {path or '.'}"

    if not base.exists():
        return f"Path not found: {base}"
    if not base.is_dir():
        return f"Not a directory: {base}"

    def _collect() -> str:
        lines: list[str] = []
        for entry in sorted(base.iterdir(), key=lambda item: item.name):
            if not show_hidden and entry.name.startswith("."):
                continue
            if entry.is_symlink():
                lines.append(f"symlink@  {entry.name}")
            elif entry.is_dir():
                lines.append(f"dir/  {entry.name}/")
            else:
                lines.append(f"file  {entry.name}")
        return "\n".join(lines)

    try:
        return await asyncio.to_thread(_collect)
    except Exception as exc:
        return f"list_dir failed: {exc}"


# === System Tools ===
def _bash_schema() -> dict[str, Any]:
    return _schema(
        {
            "command": {"type": "string", "description": "Shell command to execute"},
            "timeout": {"type": "integer", "description": "Timeout in seconds (default 120)"},
        },
        ["command"],
    )


def _truncate(text: str, max_chars: int = 30000) -> str:
    return text if len(text) <= max_chars else text[:max_chars] + "\n... (truncated)"


async def _bash_execute(
    command: str,
    timeout: int = 120,
    *,
    workspace: _WorkspaceContext | None = None,
) -> str:
    workspace_ctx = _workspace_or_default(workspace)
    if workspace_ctx.strict_mode:
        return _bash_disabled_message()

    try:
        proc = await asyncio.create_subprocess_shell(
            command, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
    except Exception as exc:
        return f"Failed to start command: {exc}"

    try:
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(), timeout=max(1, int(timeout or 120))
        )
    except TimeoutError:
        proc.kill()
        await proc.wait()
        return f"Command timed out after {timeout} seconds"

    output = ((stdout or b"") + (stderr or b"")).decode("utf-8", errors="replace")
    output = _truncate(output)
    if proc.returncode != 0:
        return f"{output}\nCommand exited with code {proc.returncode}".strip()
    return output or "(no output)"


# === Web Tools ===
def _web_search_schema() -> dict[str, Any]:
    return _schema(
        {
            "query": {"type": "string", "description": "Web search query"},
            "num_results": {"type": "integer", "description": "Number of results to return (1-20)"},
        },
        ["query"],
    )


def _parse_jsonrpc_result(raw_response: str) -> tuple[Any | None, str | None]:
    def _extract(obj: Any) -> tuple[Any | None, str | None]:
        if not isinstance(obj, dict):
            return None, "Could not parse Exa response"
        if "error" in obj:
            error = obj["error"]
            return None, str(error.get("message", error) if isinstance(error, dict) else error)
        if "result" in obj:
            return obj["result"], None
        return None, "Exa response missing result"

    for line in raw_response.splitlines():
        line = line.strip()
        if not line.startswith("data:"):
            continue
        payload = line[5:].strip()
        if not payload or payload == "[DONE]":
            continue
        try:
            return _extract(json.loads(payload))
        except json.JSONDecodeError:
            continue
    try:
        return _extract(json.loads(raw_response))
    except json.JSONDecodeError:
        return None, "Could not parse Exa response"


def _extract_mcp_text(result: Any) -> str:
    if isinstance(result, dict) and isinstance(result.get("content"), list):
        chunks = [
            item.get("text", "")
            for item in result["content"]
            if isinstance(item, dict) and item.get("type") == "text"
        ]
        if chunks:
            return "\n".join(chunk for chunk in chunks if chunk)
    return "" if result is None else str(result)


def _do_web_search_request(query: str, num_results: int) -> str:
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {
            "name": "web_search_exa",
            "arguments": {"query": query, "numResults": num_results},
        },
    }
    headers = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream"}
    if api_key := os.getenv("EXA_API_KEY"):
        headers["Authorization"] = f"Bearer {api_key}"

    request = urllib.request.Request(
        _EXA_ENDPOINT, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST"
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.read().decode("utf-8", errors="replace")


async def _web_search_execute(query: str, num_results: int = 5) -> str:
    text_query = query.strip()
    if not text_query:
        return "query is required"

    count = max(1, min(20, int(num_results or 5)))

    try:
        raw_response = await asyncio.to_thread(_do_web_search_request, text_query, count)
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace") if hasattr(exc, "read") else ""
        return f"web_search HTTP {exc.code}: {body[:200] or exc.reason}"
    except urllib.error.URLError as exc:
        return f"web_search request failed: {exc.reason}"
    except Exception as exc:
        return f"web_search failed: {exc}"

    result, error = _parse_jsonrpc_result(raw_response)
    if error:
        return f"web_search error: {error}"

    formatted = _extract_mcp_text(result).strip()
    return (
        f"Web search results for: {text_query}\n\n{formatted}"
        if formatted
        else f"No search results for: {text_query}"
    )


def _fetch_schema() -> dict[str, Any]:
    return _schema(
        {
            "url": {"type": "string", "description": "URL to fetch"},
            "timeout": {
                "type": "integer",
                "description": "Timeout in seconds (default 30, max 60)",
            },
        },
        ["url"],
    )


async def _fetch_execute(url: str, timeout: int = 30) -> str:
    if not url:
        return "url is required"

    effective_timeout = max(1, min(int(timeout or 30), 60))
    headers = {
        "User-Agent": "Otto/1.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }

    try:
        request = urllib.request.Request(url, headers=headers, method="GET")
        with urllib.request.urlopen(request, timeout=effective_timeout) as response:
            content = response.read().decode("utf-8", errors="replace")
            content_type = response.headers.get("Content-Type", "")
            status = response.status
            if "html" in content_type.lower():
                content = re.sub(
                    r"<(script|style)[^>]*>.*?</\1>",
                    "",
                    content,
                    flags=re.DOTALL | re.IGNORECASE,
                )
                content = re.sub(r"<[^>]+>", "", content)
                content = re.sub(r"\s+", " ", content).strip()
            content = _truncate(content, max_chars=50000)
            return f"URL: {url}\nStatus: {status}\nContent-Type: {content_type}\n\n{content}"
    except urllib.error.HTTPError as exc:
        return f"fetch HTTP {exc.code}: {exc.reason}"
    except urllib.error.URLError as exc:
        reason = exc.reason
        if isinstance(reason, socket.timeout):
            return f"fetch timed out after {effective_timeout}s"
        if isinstance(reason, ssl.SSLError):
            return f"fetch SSL error: {reason}"
        if isinstance(reason, OSError) and reason.errno == 111:
            return f"fetch connection refused: {url}"
        if isinstance(reason, socket.gaierror):
            from urllib.parse import urlparse

            host = urlparse(url).hostname or url
            return f"fetch DNS resolution failed for {host}"
        return f"fetch request failed: {reason}"
    except TimeoutError:
        return f"fetch timed out after {effective_timeout}s"
    except Exception as exc:
        return f"fetch failed: {exc}"


# === Vision Tools ===
_VIEW_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp"}
_VIEW_IMAGE_MAX_BYTES = 10 * 1024 * 1024  # 10 MB
_VIEW_IMAGE_MIME = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
}


def _view_image_schema() -> dict[str, Any]:
    return _schema(
        {
            "path": {"type": "string", "description": "Path to the image file"},
            "max_dimension": {
                "type": "integer",
                "description": "Max width/height to resize to (default 1568)",
                "default": 1568,
            },
        },
        ["path"],
    )


async def _view_image_execute(path: str, max_dimension: int = 1568) -> dict | str:
    import base64

    file_path = Path(path).expanduser()
    if not file_path.exists():
        return f"File not found: {path}"
    if not file_path.is_file():
        return f"Not a file: {path}"

    ext = file_path.suffix.lower()
    if ext not in _VIEW_IMAGE_EXTENSIONS:
        return f"Unsupported image format: {ext}. Supported: {', '.join(sorted(_VIEW_IMAGE_EXTENSIONS))}"

    try:
        file_size = file_path.stat().st_size
    except OSError as exc:
        return f"Cannot read file: {exc}"

    if file_size > _VIEW_IMAGE_MAX_BYTES:
        mb = file_size / (1024 * 1024)
        return f"File too large: {mb:.1f}MB (max 10MB)"

    mime = _VIEW_IMAGE_MIME[ext]
    max_dim = max(1, int(max_dimension or 1568))

    def _process() -> tuple[bytes, int, int, str]:
        raw = file_path.read_bytes()
        try:
            from PIL import Image

            img = Image.open(file_path)
            w, h = img.size
            if w > max_dim or h > max_dim:
                img.thumbnail((max_dim, max_dim))
                w, h = img.size
                import io

                buf = io.BytesIO()
                out_format = (
                    "PNG"
                    if ext == ".png"
                    else "JPEG"
                    if ext in (".jpg", ".jpeg")
                    else ext.lstrip(".").upper()
                )
                if out_format == "WEBP":
                    out_format = "WEBP"
                img.save(buf, format=out_format)
                raw = buf.getvalue()
            return raw, w, h, mime
        except ImportError:
            # Pillow not installed — send raw bytes, dimensions unknown
            return raw, 0, 0, mime

    try:
        data, width, height, out_mime = await asyncio.to_thread(_process)
    except Exception as exc:
        return f"Failed to process image: {exc}"

    encoded = base64.b64encode(data).decode("ascii")
    dim_str = f" ({width}x{height})" if width and height else ""
    return {
        "text": f"Image: {file_path.name}{dim_str}",
        "images": [{"mime": out_mime, "data": encoded}],
    }


# === Browser Tools ===
_BROWSE_ACTIONS = {"screenshot", "text", "click", "fill", "pdf"}
_BROWSE_USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
    " (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)
_browser_instance: Any = None
_browser_lock: asyncio.Lock | None = None


def _get_browser_lock() -> asyncio.Lock:
    global _browser_lock
    if _browser_lock is None:
        _browser_lock = asyncio.Lock()
    return _browser_lock


async def _get_browser() -> Any:
    global _browser_instance
    lock = _get_browser_lock()
    async with lock:
        if _browser_instance is not None and _browser_instance.is_connected():
            return _browser_instance
        try:
            from playwright.async_api import async_playwright
        except ImportError:
            return None
        pw = await async_playwright().start()
        _browser_instance = await pw.chromium.launch(headless=True)
        return _browser_instance


def _browse_schema() -> dict[str, Any]:
    return _schema(
        {
            "url": {"type": "string", "description": "URL to navigate to"},
            "action": {
                "type": "string",
                "description": 'Action: "screenshot" (default), "text", "click", "fill", "pdf"',
                "default": "screenshot",
            },
            "selector": {
                "type": "string",
                "description": "CSS selector for click/fill actions",
            },
            "value": {
                "type": "string",
                "description": "Value for fill action",
            },
            "wait": {
                "type": "integer",
                "description": "Seconds to wait after navigation/action (default 2)",
                "default": 2,
            },
            "full_page": {
                "type": "boolean",
                "description": "Capture full page screenshot vs viewport (default false)",
                "default": False,
            },
            "save_path": {
                "type": "string",
                "description": "Optional file path to save the screenshot PNG to disk",
            },
        },
        ["url"],
    )


async def _browse_execute(
    url: str,
    action: str = "screenshot",
    selector: str | None = None,
    value: str | None = None,
    wait: int = 2,
    full_page: bool = False,
    save_path: str | None = None,
) -> dict[str, Any] | str:
    import base64

    if not url:
        return "url is required"

    action = (action or "screenshot").strip().lower()
    if action not in _BROWSE_ACTIONS:
        return f"Invalid action: {action}. Must be one of: {', '.join(sorted(_BROWSE_ACTIONS))}"

    if action == "click" and not selector:
        return "selector is required for click action"
    if action == "fill" and (not selector or not value):
        return "selector and value are required for fill action"

    browser = await _get_browser()
    if browser is None:
        return (
            "playwright is not installed. Install it with: "
            "pip install 'otto-agent[browser]' && playwright install chromium"
        )

    wait_ms = max(0, int(wait or 2)) * 1000

    try:
        page = await browser.new_page(
            viewport={"width": 1280, "height": 720},
            user_agent=_BROWSE_USER_AGENT,
        )
        page.set_default_navigation_timeout(30000)
        page.set_default_timeout(10000)

        try:
            await page.goto(url, wait_until="domcontentloaded")
        except Exception as exc:
            await page.close()
            return f"Failed to navigate to {url}: {exc}"

        if wait_ms > 0:
            await page.wait_for_timeout(wait_ms)

        if action == "text":
            try:
                text = await page.inner_text("body")
            except Exception as exc:
                await page.close()
                return f"Failed to extract text: {exc}"
            await page.close()
            return _truncate(text.strip(), max_chars=50000)

        if action == "click":
            try:
                await page.click(selector)
            except Exception as exc:
                await page.close()
                return f"Failed to click '{selector}': {exc}"
            if wait_ms > 0:
                await page.wait_for_timeout(wait_ms)

        if action == "fill":
            try:
                await page.fill(selector, value)
            except Exception as exc:
                await page.close()
                return f"Failed to fill '{selector}': {exc}"
            if wait_ms > 0:
                await page.wait_for_timeout(wait_ms)

        if action == "pdf":
            import tempfile

            try:
                pdf_bytes = await page.pdf()
            except Exception as exc:
                await page.close()
                return f"Failed to generate PDF: {exc}"
            await page.close()
            fd, tmp_path = tempfile.mkstemp(suffix=".pdf")
            os.close(fd)
            Path(tmp_path).write_bytes(pdf_bytes)
            return f"PDF saved to {tmp_path}"

        # screenshot (default), or screenshot after click/fill
        try:
            png_bytes = await page.screenshot(full_page=full_page)
            viewport = page.viewport_size or {"width": 1280, "height": 720}
            w, h = viewport["width"], viewport["height"]
        except Exception as exc:
            await page.close()
            return f"Failed to take screenshot: {exc}"
        await page.close()

        if save_path:
            save_target = Path(save_path).expanduser()
            save_target.parent.mkdir(parents=True, exist_ok=True)
            save_target.write_bytes(png_bytes)

        encoded = base64.b64encode(png_bytes).decode("ascii")
        text = f"Screenshot of {url} ({w}x{h})"
        if save_path:
            text += f" — saved to {save_path}"
        return {
            "text": text,
            "images": [{"mime": "image/png", "data": encoded}],
        }

    except Exception as exc:
        return f"Browser error: {exc}"


# === Skill Tools ===
def _create_skill_schema() -> dict[str, Any]:
    return _schema(
        {
            "name": {"type": "string", "description": "Skill directory name"},
            "description": {"type": "string", "description": "Skill description"},
            "content": {
                "type": "string",
                "description": "Markdown body for SKILL.md (after frontmatter)",
            },
            "license": {"type": "string", "description": "Optional skill license"},
            "compatibility": {"type": "string", "description": "Optional compatibility metadata"},
            "scripts": {
                "type": "object",
                "description": "Optional map of scripts/<filename> to file content",
                "additionalProperties": {"type": "string"},
            },
        },
        ["name", "description", "content"],
    )


async def _create_skill_execute(
    name: str,
    description: str,
    content: str,
    license: str | None = None,
    compatibility: str | None = None,
    scripts: dict[str, Any] | None = None,
) -> str:
    import yaml

    from otto.skills import validate_frontmatter

    frontmatter: dict[str, Any] = {"name": name, "description": description}
    if license is not None:
        frontmatter["license"] = license
    if compatibility is not None:
        frontmatter["compatibility"] = compatibility

    errors = validate_frontmatter(frontmatter)
    if errors:
        return "\n".join(errors)

    script_map = scripts if scripts is not None else {}
    if not isinstance(script_map, dict):
        return "scripts must be an object mapping filename to content"

    for filename, script_content in script_map.items():
        if not isinstance(filename, str) or not filename.strip():
            return "scripts keys must be non-empty strings"
        if not isinstance(script_content, str):
            return f"scripts entry '{filename}' must be a string"
        script_path = Path(filename)
        if script_path.is_absolute() or ".." in script_path.parts:
            return f"Invalid script filename: {filename}"

    frontmatter_text = yaml.dump(frontmatter, sort_keys=False).strip()
    skill_text = f"---\n{frontmatter_text}\n---\n\n{content}"
    skill_dir = OTTO_HOME / "skills" / name
    skill_file = skill_dir / "SKILL.md"

    try:
        await asyncio.to_thread(skill_dir.mkdir, parents=True, exist_ok=True)
        await asyncio.to_thread(skill_file.write_text, skill_text, encoding="utf-8")
        if script_map:
            scripts_dir = skill_dir / "scripts"
            await asyncio.to_thread(scripts_dir.mkdir, parents=True, exist_ok=True)
            for filename, script_content in script_map.items():
                target = scripts_dir / filename
                await asyncio.to_thread(target.parent.mkdir, parents=True, exist_ok=True)
                await asyncio.to_thread(target.write_text, script_content, encoding="utf-8")
    except Exception as exc:
        return f"Failed to create skill: {exc}"

    return f"Created skill: {skill_file}"


def _use_skill_schema() -> dict[str, Any]:
    return _schema({"name": {"type": "string", "description": "Skill name to load"}}, ["name"])


_SKILL_CONTENT_PREFIX = "__skill_content__:"


async def _use_skill_execute(name: str) -> str:
    from otto.skills import read_skill

    try:
        content = read_skill(OTTO_HOME / "skills", name)
    except Exception as exc:
        return f"Failed to load skill: {exc}"
    if content is None:
        return f"Skill not found: {name}"
    return f"{_SKILL_CONTENT_PREFIX}{name}\n{content}"


# === Memory Tools ===
def _memory_search_schema() -> dict[str, Any]:
    return _schema(
        {
            "query": {"type": "string", "description": "Search query"},
            "limit": {
                "type": "integer",
                "description": "Maximum number of matches to return",
                "default": 5,
            },
        },
        ["query"],
    )


def _parse_boolean_query(query: str) -> dict[str, Any] | None:
    """Parse a query with AND/OR/NOT operators into a structured representation.

    Returns None if no boolean operators are present (plain query).
    Otherwise returns {"must": [...], "should": [...], "must_not": [...]}.
    """
    tokens = query.split()
    operators = {"AND", "OR", "NOT"}
    has_operators = any(t in operators for t in tokens)
    if not has_operators:
        return None

    must: list[str] = []
    should: list[str] = []
    must_not: list[str] = []

    i = 0
    # Default mode: terms before any operator are AND (must match)
    mode = "AND"
    negate = False
    # Track the last non-operator term index for OR retroactive reclassification
    last_term_target: str | None = None

    while i < len(tokens):
        token = tokens[i]
        if token == "AND":
            mode = "AND"
            negate = False
            i += 1
            continue
        if token == "OR":
            mode = "OR"
            negate = False
            # Retroactively move the previous term from must to should
            if last_term_target == "must" and must:
                should.append(must.pop())
            i += 1
            continue
        if token == "NOT":
            negate = True
            i += 1
            continue

        term = token
        if negate:
            must_not.append(term)
            negate = False
            last_term_target = "must_not"
        elif mode == "OR":
            should.append(term)
            last_term_target = "should"
        else:
            must.append(term)
            last_term_target = "must"

        i += 1

    if not must and not should and not must_not:
        return None
    return {"must": must, "should": should, "must_not": must_not}


def _result_matches_term(item: dict[str, str], term: str) -> bool:
    """Check if a memory result's key or snippet contains the term (case-insensitive)."""
    lower_term = term.lower()
    key = str(item.get("key", "")).lower()
    snippet = str(item.get("snippet", "")).lower()
    return lower_term in key or lower_term in snippet


async def _memory_search_execute(memory: Memory, query: str, limit: int = 5) -> str:
    effective_limit = int(limit if limit is not None else 5)
    parsed = _parse_boolean_query(query)

    if parsed is None:
        results = memory.search(query, limit=effective_limit)
        return "\n".join(
            f"{str(item.get('key', ''))}: {str(item.get('snippet', ''))}" for item in results
        )

    # Collect candidate results from all positive terms
    all_terms = parsed["must"] + parsed["should"]
    if not all_terms:
        # Only NOT terms — search with first NOT term to get candidates, then filter
        all_terms = parsed["must_not"][:1]

    seen_keys: set[str] = set()
    candidates: list[dict[str, str]] = []
    # Fetch more than needed to allow for filtering
    fetch_limit = effective_limit * 3

    for term in all_terms:
        for item in memory.search(term, limit=fetch_limit):
            key = str(item.get("key", ""))
            if key not in seen_keys:
                seen_keys.add(key)
                candidates.append(item)

    # Apply boolean filters
    filtered: list[dict[str, str]] = []
    for item in candidates:
        # must_not: exclude if any NOT term matches
        if any(_result_matches_term(item, t) for t in parsed["must_not"]):
            continue

        # must: all AND terms must match
        if parsed["must"] and not all(_result_matches_term(item, t) for t in parsed["must"]):
            continue

        # should: if there are OR terms (and no must terms), at least one must match
        if parsed["should"] and not parsed["must"]:
            if not any(_result_matches_term(item, t) for t in parsed["should"]):
                continue

        filtered.append(item)
        if len(filtered) >= effective_limit:
            break

    return "\n".join(
        f"{str(item.get('key', ''))}: {str(item.get('snippet', ''))}" for item in filtered
    )


def _memory_store_schema() -> dict[str, Any]:
    return _schema(
        {
            "key": {"type": "string", "description": "Unique memory key"},
            "content": {"type": "string", "description": "Text content to store"},
        },
        ["key", "content"],
    )


async def _memory_store_execute(memory: Memory, key: str, content: str) -> str:
    memory.store(key, content)
    return f"Stored memory entry: {key}"
