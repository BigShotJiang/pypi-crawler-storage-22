# Ouroboros Documentation

> The serpent that devours itself to be reborn anew.

Ouroboros is a self-improving AI workflow system that transforms ambiguous human requirements into clear, executable specifications through Socratic questioning and ontological analysis.

## Documentation Index

### Getting Started

- [Getting Started Guide](./getting-started.md) - Installation, configuration, and quick start tutorial

### Architecture

- [System Architecture](./architecture.md) - Overview of the six-phase architecture and core concepts

### API Reference

- [API Reference Index](./api/README.md) - Complete API documentation
  - [Core Module](./api/core.md) - Result type, Seed, and error handling
  - [MCP Module](./api/mcp.md) - Model Context Protocol integration

### Guides

- [Quick Start](./guides/quick-start.md) - Get running in under 10 minutes
- [Seed Authoring Guide](./guides/seed-authoring.md) - YAML structure, field reference, examples
- [TUI Usage Guide](./guides/tui-usage.md) - Dashboard, screens, keyboard shortcuts
- [CLI Usage Guide](./guides/cli-usage.md) - Command-line interface reference
- [Common Workflows](./guides/common-workflows.md) - Recipes for typical scenarios

### Contributing

- [Contributing Guide](../CONTRIBUTING.md) - How to set up, code, test, and submit PRs
- [Architecture for Contributors](./contributing/architecture-overview.md) - How modules connect
- [Testing Guide](./contributing/testing-guide.md) - Writing and running tests
- [Key Patterns](./contributing/key-patterns.md) - Result type, immutability, event sourcing, protocols

### Design Documents

- [Execution Deep Dive](./design/execution-deep-dive.md) - Recursive decomposition, atomicity, parallel execution
- [Evaluation Pipeline Deep Dive](./design/evaluation-pipeline-deep-dive.md) - Three stages, trigger matrix, deliberative consensus
- [Evaluation Pipeline Flexibility](./design/evaluation-pipeline-flexibility.md) - Supporting non-code workflows
- [CLI UX Redesign](./design/cli-ux-redesign.md) - v0.8.0 CLI shorthand and orchestrator defaults

## Key Concepts

### The Six Phases

1. **Big Bang (Phase 0)** - Socratic and ontological questioning to crystallize requirements into a Seed (Ambiguity <= 0.2)
2. **PAL Router (Phase 1)** - Progressive Adaptive LLM selection (Frugal -> Standard -> Frontier)
3. **Double Diamond (Phase 2)** - Discover, Define, Design, Deliver with recursive decomposition
4. **Resilience (Phase 3)** - Stagnation detection and lateral thinking via persona rotation
5. **Evaluation (Phase 4)** - Three-stage verification (Mechanical, Semantic, Consensus)
6. **Secondary Loop (Phase 5)** - TODO registry and batch processing

### Economic Model

| Tier | Cost | When |
|:----:|:----:|------|
| FRUGAL | 1x | complexity < 0.4 |
| STANDARD | 10x | complexity < 0.7 |
| FRONTIER | 30x | critical decisions |

### Core Principles

- **Frugal by default, rigorous in verification** - Start with the simplest approach, escalate only when needed
- **Ambiguity threshold** - Requirements must have ambiguity score <= 0.2 before execution begins
- **Lateral thinking** - When stuck, switch persona and think differently rather than retry harder

## Quick Links

- [GitHub Repository](https://github.com/Q00/ouroboros)
- [PyPI Package](https://pypi.org/project/ouroboros/)

## License

MIT License
