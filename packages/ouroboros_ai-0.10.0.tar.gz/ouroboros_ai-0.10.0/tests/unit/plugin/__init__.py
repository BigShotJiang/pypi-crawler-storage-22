"""Tests for plugin module."""
