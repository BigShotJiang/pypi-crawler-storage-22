"""Valence Core - Shared primitives for the knowledge substrate."""

from .attestation_service import (
    AttestationFilter,
    AttestationService,
    AttestationStats,
    TrustSignal,
)
from .config import (
    clear_config_cache,
    get_config,
)
from .dimension_registry import (
    DimensionRegistry,
    DimensionSchema,
    ValidationResult,
)
from .dimension_registry import (
    get_registry as get_dimension_registry,
)
from .dimension_registry import (
    reset_registry as reset_dimension_registry,
)
from .exceptions import (
    ConfigException,
    ConflictError,
    DatabaseException,
    EmbeddingException,
    MCPException,
    NotFoundError,
    ValenceException,
    ValidationException,
)
from .external_sources import (
    ContentMatchResult,
    DOIPrefix,
    DOIStatus,
    DOIVerificationResult,
    ExternalSourceConstants,
    ExternalSourceVerification,
    ExternalSourceVerificationService,
    L4SourceRequirements,
    LivenessCheckResult,
    SourceCategory,
    SourceLivenessStatus,
    SourceReliabilityScore,
    SourceVerificationStatus,
    TrustedDomain,
    TrustedSourceRegistry,
    check_belief_l4_readiness,
    get_registry,
    verify_external_source,
)
from .health import (
    HealthStatus,
    require_healthy,
    run_health_check,
    startup_checks,
    validate_database,
    validate_environment,
)
from .logging import (
    ToolCallLogger,
    configure_logging,
    get_logger,
    tool_logger,
)
from .lru_cache import (
    DEFAULT_CACHE_MAX_SIZE,
    BoundedList,
    LRUDict,
    get_cache_max_size,
)
from .resource_sharing import (
    AccessResult,
    DefaultTrustProvider,
    InMemoryResourceStore,
    ResourceSharingService,
    SafetyScanResult,
    ShareResult,
    scan_content,
)
from .resources import (
    Resource,
    ResourceReport,
    ResourceType,
    SafetyStatus,
    UsageAttestation,
)
from .temporal import TemporalValidity
from .verification import (
    ContradictionType,
    DiscrepancyBounty,
    Dispute,
    DisputeOutcome,
    DisputeStatus,
    DisputeType,
    Evidence,
    EvidenceContribution,
    EvidenceType,
    ReputationScore,
    Stake,
    StakeType,
    Verification,
    VerificationResult,
    VerificationService,
    VerificationStatus,
    calculate_bounty,
    calculate_max_stake,
    calculate_min_stake,
    create_evidence,
)

__all__ = [
    # Config
    "get_config",
    "clear_config_cache",
    # Attestation Service
    "AttestationService",
    "AttestationFilter",
    "AttestationStats",
    "TrustSignal",
    # Dimension Registry
    "DimensionSchema",
    "DimensionRegistry",
    "ValidationResult",
    "get_dimension_registry",
    "reset_dimension_registry",
    # Exceptions
    "ValenceException",
    "DatabaseException",
    "ValidationException",
    "ConfigException",
    "NotFoundError",
    "ConflictError",
    "EmbeddingException",
    "MCPException",
    # External Source Verification
    "ExternalSourceConstants",
    "SourceCategory",
    "SourceVerificationStatus",
    "DOIStatus",
    "SourceLivenessStatus",
    "TrustedDomain",
    "DOIPrefix",
    "TrustedSourceRegistry",
    "get_registry",
    "LivenessCheckResult",
    "ContentMatchResult",
    "DOIVerificationResult",
    "SourceReliabilityScore",
    "ExternalSourceVerification",
    "L4SourceRequirements",
    "ExternalSourceVerificationService",
    "verify_external_source",
    "check_belief_l4_readiness",
    # Health
    "HealthStatus",
    "run_health_check",
    "require_healthy",
    "startup_checks",
    "validate_environment",
    "validate_database",
    # Logging
    "configure_logging",
    "get_logger",
    "ToolCallLogger",
    "tool_logger",
    # LRU Cache
    "LRUDict",
    "BoundedList",
    "get_cache_max_size",
    "DEFAULT_CACHE_MAX_SIZE",
    # Resources
    "Resource",
    "ResourceType",
    "SafetyStatus",
    "ResourceReport",
    "UsageAttestation",
    "ResourceSharingService",
    "InMemoryResourceStore",
    "DefaultTrustProvider",
    "ShareResult",
    "AccessResult",
    "SafetyScanResult",
    "scan_content",
    # Temporal
    "TemporalValidity",
    # Verification Protocol
    "VerificationResult",
    "VerificationStatus",
    "StakeType",
    "EvidenceType",
    "EvidenceContribution",
    "ContradictionType",
    "DisputeType",
    "DisputeOutcome",
    "DisputeStatus",
    "Evidence",
    "Verification",
    "Dispute",
    "Stake",
    "ReputationScore",
    "DiscrepancyBounty",
    "VerificationService",
    "calculate_min_stake",
    "calculate_max_stake",
    "calculate_bounty",
    "create_evidence",
]
