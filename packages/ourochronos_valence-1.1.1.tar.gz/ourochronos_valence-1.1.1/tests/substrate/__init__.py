"""Tests for substrate module."""
