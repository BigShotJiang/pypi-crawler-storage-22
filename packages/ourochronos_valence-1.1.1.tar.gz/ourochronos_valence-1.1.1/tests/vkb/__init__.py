"""Tests for vkb module."""
