# Outpost9 Python SDK

Deploy AI agents with one decorator.

## Installation

```bash
pip install outpost9
```

## Quick Start

```python
from outpost9 import route

@route("/research")
async def research(topic: str):
    print(f"Researching: {topic}")  # Streams via SSE
    result = await run_research(topic)
    return {"report": result}
```

## How It Works

1. The `@route` decorator registers your function as an HTTP endpoint
2. `print()` statements are captured and streamed via Server-Sent Events
3. The final return value is sent as the result

## Running Locally

```bash
outpost9-serve
```

This starts a local server with all registered routes.
