"""
Outpost9 Python SDK - Deploy AI agents with one decorator.

Example:
    from outpost9 import route, runtime

    @route("/research")
    async def research(topic: str):
        print(f"Researching: {topic}")  # Auto-captured via SSE

        # Wrap SDK calls with runtime.capture for observability
        async for msg in runtime.capture(client.receive_response()):
            process(msg)

        return {"report": result}
"""

import os

from .decorators import route
from .app import create_app, run_server
from . import runtime

__version__ = "0.0.1"
__all__ = ["route", "create_app", "run_server", "runtime"]

# Auto-detect Outpost9 environment and set up stdout logging
_AGENT_ID = os.environ.get("OUTPOST9_AGENT_ID")
_LOG_URL = os.environ.get("OUTPOST9_LOG_URL")

if _AGENT_ID and _LOG_URL:
    from ._internal.auto_logging import _setup_auto_logging
    _setup_auto_logging(_AGENT_ID, _LOG_URL)
