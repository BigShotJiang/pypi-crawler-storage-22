"""Internal SDK modules - not part of public API."""
