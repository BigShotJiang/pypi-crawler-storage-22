"""Route decorator for registering agent endpoints."""

from typing import Callable, List, Optional, Any
from functools import wraps

# Global route registry
_routes: dict[str, dict[str, Any]] = {}


def route(
    path: str,
    methods: Optional[List[str]] = None,
    name: Optional[str] = None,
) -> Callable:
    """
    Decorator to register a function as an HTTP endpoint.

    Args:
        path: URL path for the endpoint (e.g., "/research")
        methods: HTTP methods allowed (default: ["GET", "POST"])
        name: Optional name for the route

    Example:
        @route("/research", methods=["POST"])
        async def research(topic: str):
            print(f"Researching: {topic}")
            return {"result": "done"}
    """
    if methods is None:
        methods = ["GET", "POST"]

    def decorator(func: Callable) -> Callable:
        # Store route metadata on the function
        func._route_path = path  # type: ignore
        func._route_methods = methods  # type: ignore
        func._route_name = name or func.__name__  # type: ignore

        # Register in global registry
        _routes[path] = {
            "func": func,
            "path": path,
            "methods": methods,
            "name": name or func.__name__,
        }

        @wraps(func)
        async def wrapper(*args, **kwargs):
            return await func(*args, **kwargs)

        return wrapper

    return decorator


def get_routes() -> dict[str, dict[str, Any]]:
    """Get all registered routes."""
    return _routes.copy()


def clear_routes() -> None:
    """Clear all registered routes (useful for testing)."""
    _routes.clear()
