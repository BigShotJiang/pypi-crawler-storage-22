"""
Overcast SDK for Python — one-line install, captures everything.

Usage::

    import overcast_sdk
    overcast_sdk.init(api_key="oc_...", service_name="my-api")

That's it.  Logging, exceptions, HTTP calls, and framework requests
are captured automatically.

New in v2:
* Breadcrumbs — trail of events leading up to an error.
* Scoped context — per-request tags, user info, and extra data.
* ``before_send`` hook — filter or modify events before sending.
* Gzip compression, rate-limiting, and health monitoring.
* Modular integration framework with auto-discovery.
"""

from overcast_sdk.api import (
    init,
    error,
    warn,
    info,
    debug,
    capture_exception,
    set_tag,
    set_user,
    set_extra,
    set_context,
    add_breadcrumb,
    flush,
    shutdown,
    Overcast,
)
from overcast_sdk.integrations._flask import middleware_flask
from overcast_sdk.integrations._django import middleware_django
from overcast_sdk.integrations._asgi import middleware_asgi

__version__ = "2.0.0"
__all__ = [
    # Init / lifecycle
    "init", "flush", "shutdown",
    # Manual logging
    "error", "warn", "info", "debug", "capture_exception",
    # Scope helpers
    "set_tag", "set_user", "set_extra", "set_context", "add_breadcrumb",
    # Framework middleware
    "middleware_flask", "middleware_django", "middleware_asgi",
    # OOP interface
    "Overcast",
]
