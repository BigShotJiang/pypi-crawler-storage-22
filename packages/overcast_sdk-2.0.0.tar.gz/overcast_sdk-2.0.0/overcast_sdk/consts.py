"""
Overcast SDK constants, defaults, and resource limits.

All tuneable limits and default configuration values live here
so they can be referenced from any module without circular imports.
"""

import os

# ── SDK identity ──────────────────────────────────────────────────────────────
SDK_VERSION = "2.0.0"
SDK_NAME = "overcast-python"

# ── Resource limits ───────────────────────────────────────────────────────────
MAX_BREADCRUMBS = 100
MAX_BUFFER_SIZE = 1000
MAX_QUEUE_SIZE = 100
MAX_PAYLOAD_SIZE = 512 * 1024       # 512 KB
MAX_STRING_LENGTH = 2048
MAX_LOG_MESSAGE_LENGTH = 8192
MAX_TRACEBACK_LENGTH = 8192
MAX_SERIALIZE_DEPTH = 5
MAX_SERIALIZE_BREADTH = 50
MAX_STACK_FRAMES = 500
MAX_REQUEUE_ON_FAILURE = 50

# ── Transport defaults ────────────────────────────────────────────────────────
DEFAULT_BATCH_SIZE = 50
DEFAULT_FLUSH_INTERVAL = 5.0        # seconds
DEFAULT_SEND_TIMEOUT = 10           # seconds
DEFAULT_BASE_URL = "https://platform.overcastsre.com"
INGEST_ENDPOINT = "/ingest/logs"

# ── Health monitor ────────────────────────────────────────────────────────────
HEALTH_CHECK_INTERVAL = 10          # seconds
MAX_DOWNSAMPLE_FACTOR = 5           # 2^5 = 32x max reduction

# ── Default configuration ─────────────────────────────────────────────────────
DEFAULT_OPTIONS = {
    "api_key": "",
    "service_name": "python-app",
    "environment": os.environ.get(
        "OVERCAST_ENVIRONMENT",
        os.environ.get("PYTHON_ENV", os.environ.get("ENV", "production")),
    ),
    "base_url": DEFAULT_BASE_URL,
    "version": "",

    # Capture toggles
    "capture_logging": True,
    "capture_stdout": True,
    "capture_stderr": True,
    "capture_exceptions": True,
    "capture_threads": True,
    "capture_http": True,
    "capture_signals": True,

    # Thresholds
    "slow_request_threshold": 5.0,

    # Batching / transport
    "batch_size": DEFAULT_BATCH_SIZE,
    "flush_interval": DEFAULT_FLUSH_INTERVAL,
    "max_buffer_size": MAX_BUFFER_SIZE,
    "queue_size": MAX_QUEUE_SIZE,
    "enable_compression": True,

    # Sampling
    "log_sampling_rate": 1.0,

    # Security / PII
    "encrypt_payload": False,
    "encryption_key": "",
    "sanitize": True,
    "send_default_pii": False,

    # Hooks (callables)
    "before_send": None,
    "before_breadcrumb": None,

    # Debug
    "debug": False,
}
