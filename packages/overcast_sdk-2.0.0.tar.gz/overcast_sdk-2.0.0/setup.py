from setuptools import setup, find_packages

setup(
    name="overcast-sdk",
    version="2.0.0",
    description="Overcast SRE monitoring SDK for Python — one-line install, captures everything.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Overcast SRE",
    author_email="sdk@overcastsre.com",
    url="https://github.com/overcast/sdk-python",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[],  # Zero dependencies — uses only stdlib
    extras_require={
        "flask": ["flask>=2.0"],
        "django": ["django>=3.2"],
        "fastapi": ["fastapi", "starlette"],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: System :: Monitoring",
    ],
    keywords="overcast monitoring logging error-tracking observability apm",
)
