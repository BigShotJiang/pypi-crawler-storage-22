"""
OVERSIGHT SDK - HTTP Client
Matches existing backend API exactly

Backend Contract:
- URL: https://oversight-protocol.onrender.com
- Endpoint: POST /process-payment
- Payload: { "wallet_address": str, "amount": float, "vendor": str }
- Headers: { "apikey": key, "Authorization": "Bearer {key}" }
- Response: { "status": str, "new_balance": float, "tax_collected": float, "vendor_paid": float, "detail": str }
"""

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from typing import Optional
import logging

from .types import PaymentResponse


# Configure logger
logger = logging.getLogger("oversight.client")


class OversightClient:
    """
    OVERSIGHT API Client
    
    Connects to OVERSIGHT backend for payment processing.
    Automatically handles retries with exponential backoff.
    
    Attributes:
        api_key: API key for authentication
        base_url: Backend API base URL
        timeout: Request timeout in seconds
        session: HTTP session with retry logic
    
    Example:
        >>> client = OversightClient(api_key="ovr_test")
        >>> response = client.pay(
        ...     wallet_address="0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb",
        ...     amount=25.50,
        ...     vendor="Amazon"
        ... )
        >>> print(f"Status: {response.status}")
        >>> print(f"Vendor paid: ${response.vendor_paid}")
    """
    
    DEFAULT_BASE_URL = "https://oversight-protocol.onrender.com"
    DEFAULT_TIMEOUT = 30  # seconds
    
    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = 3
    ):
        """
        Initialize OVERSIGHT client
        
        Args:
            api_key: API key for authentication (e.g., "ovr_test")
            base_url: API base URL (default: production URL)
            timeout: Request timeout in seconds (default: 30)
            max_retries: Maximum retry attempts (default: 3)
        
        Example:
            >>> client = OversightClient(
            ...     api_key="ovr_test",
            ...     base_url="http://127.0.0.1:8000"
            ... )
        """
        self.api_key = api_key
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip('/')
        self.timeout = timeout
        
        # Create session with retry strategy
        self.session = self._create_session(max_retries)
        
        logger.info(f"OVERSIGHT client initialized: {self.base_url}")
    
    def _create_session(self, max_retries: int) -> requests.Session:
        """
        Create requests session with retry strategy
        
        Implements exponential backoff:
        - Retry 1: Wait 1 second
        - Retry 2: Wait 2 seconds
        - Retry 3: Wait 4 seconds
        
        Retries on:
        - Server errors (500, 502, 503, 504)
        - Connection errors
        - Timeouts
        
        Args:
            max_retries: Maximum number of retry attempts
            
        Returns:
            Configured requests.Session with retry adapter
        """
        session = requests.Session()
        
        # Configure retry strategy with exponential backoff
        retry_strategy = Retry(
            total=max_retries,
            backoff_factor=1,  # Wait 1s, 2s, 4s between retries
            status_forcelist=[500, 502, 503, 504],  # Server errors
            allowed_methods=["GET", "POST"],
            raise_on_status=False  # Handle status codes manually
        )
        
        # Create HTTP adapter with retry strategy
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=10,
            pool_maxsize=20
        )
        
        # Mount adapter for both HTTP and HTTPS
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        # Set default headers
        session.headers.update({
            "Content-Type": "application/json",
            "User-Agent": "oversight-sdk-python/1.0.0"
        })
        
        return session
    
    def pay(
        self,
        wallet_address: str,
        amount: float,
        vendor: str
    ) -> PaymentResponse:
        """
        Process a payment transaction
        
        Sends POST request to /process-payment endpoint with:
        - 10% tax withholding
        - Automatic spending limit validation
        - Idempotent transaction handling
        
        Args:
            wallet_address: Agent's blockchain wallet address
            amount: Transaction amount (will be converted to float)
            vendor: Vendor/recipient name
            
        Returns:
            PaymentResponse with transaction details including:
            - status: APPROVED or DENIED
            - vendor_paid: Amount sent to vendor (90%)
            - tax_collected: Tax withheld (10%)
            - new_balance: Updated wallet balance
            - detail: Transaction description
            
        Raises:
            requests.HTTPError: If API returns 4xx/5xx status code
            requests.Timeout: If request times out
            requests.ConnectionError: If connection fails
            requests.RequestException: For other network errors
            
        Example:
            >>> response = client.pay(
            ...     wallet_address="0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb",
            ...     amount=100.00,
            ...     vendor="OpenAI"
            ... )
            >>> 
            >>> if response.status == "APPROVED":
            ...     print(f"✅ Payment approved")
            ...     print(f"Vendor paid: ${response.vendor_paid}")
            ...     print(f"Tax: ${response.tax_collected}")
            ...     print(f"New balance: ${response.new_balance}")
            ... else:
            ...     print(f"❌ Payment denied: {response.detail}")
        """
        # Ensure amount is float (strict type conversion)
        amount = float(amount)
        
        # Prepare request payload (exact match to backend contract)
        payload = {
            "wallet_address": wallet_address,
            "amount": amount,
            "vendor": vendor
        }
        
        # Prepare authentication headers
        headers = {
            "apikey": self.api_key,
            "Authorization": f"Bearer {self.api_key}"
        }
        
        # Construct endpoint URL
        url = f"{self.base_url}/process-payment"
        
        logger.info(
            f"POST {url} - wallet: {wallet_address[:10]}..., "
            f"amount: ${amount:.2f}, vendor: {vendor}"
        )
        
        try:
            # Make POST request
            response = self.session.post(
                url,
                json=payload,
                headers=headers,
                timeout=self.timeout
            )
            
            # Log response status
            logger.info(f"Response status: {response.status_code}")
            
            # Raise exception for error status codes (4xx, 5xx)
            response.raise_for_status()
            
            # Parse JSON response
            data = response.json()
            
            logger.info(f"Payment {data.get('status', 'UNKNOWN')}")
            
            # Return typed response
            return PaymentResponse(**data)
            
        except requests.exceptions.Timeout as e:
            logger.error(f"Request timeout after {self.timeout}s: {url}")
            raise
        
        except requests.exceptions.HTTPError as e:
            logger.error(
                f"HTTP error {e.response.status_code}: {e.response.text}"
            )
            raise
        
        except requests.exceptions.ConnectionError as e:
            logger.error(f"Connection error: {url}")
            raise
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Request failed: {str(e)}")
            raise
        
        except Exception as e:
            logger.error(f"Unexpected error: {str(e)}")
            raise
    
    def close(self):
        """
        Close HTTP session and cleanup resources
        
        Call this when you're done using the client to free resources.
        
        Example:
            >>> client = OversightClient(api_key="ovr_test")
            >>> try:
            ...     response = client.pay(...)
            ... finally:
            ...     client.close()
        """
        self.session.close()
        logger.info("OVERSIGHT client closed")
    
    def __enter__(self):
        """
        Context manager entry
        
        Example:
            >>> with OversightClient(api_key="ovr_test") as client:
            ...     response = client.pay(...)
        """
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - automatically closes session"""
        self.close()
    
    def __repr__(self) -> str:
        """Developer representation"""
        return f"OversightClient(base_url={self.base_url!r})"
    
    def __str__(self) -> str:
        """User-friendly representation"""
        return f"OversightClient connected to {self.base_url}"