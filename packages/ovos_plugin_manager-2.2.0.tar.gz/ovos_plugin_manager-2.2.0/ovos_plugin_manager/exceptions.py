class PipException(RuntimeError):
    """ failed to run pip """
