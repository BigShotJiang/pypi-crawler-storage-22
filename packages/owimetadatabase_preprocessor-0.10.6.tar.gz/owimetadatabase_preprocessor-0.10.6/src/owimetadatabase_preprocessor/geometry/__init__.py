"""A module to handle geometry data."""
