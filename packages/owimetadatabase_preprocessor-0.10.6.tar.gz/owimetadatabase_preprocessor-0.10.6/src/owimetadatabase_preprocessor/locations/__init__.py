"""A module to handle locations data."""
