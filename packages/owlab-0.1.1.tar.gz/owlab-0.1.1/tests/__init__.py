"""Tests for OwLab."""
