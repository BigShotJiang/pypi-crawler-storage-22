"""Storage modules for OwLab."""

from owlab.storage.local_storage import LocalStorage

__all__ = ["LocalStorage"]
