
#!/usr/bin/env python3
##
## OwlMind Framework - experimentation environment for Generative Intelligence Systems.
## cli.py — Command-line interface.
##
# Copyright (c) 2025, The Generative Intelligence Lab
#    https://github.com/genilab/owlmind
#
# Disclosure:
# This framework was developed using a 'vibe coding' . AI-synthesized logic was 
# subjected to human review and manual refinement to guarantee functional 
# integrity and structural clarity.
#

import argparse
import os
import sys
import logging
from owlmind import __version__
from owlmind.models import Ollama

class Dispatcher:
    """Orchestrates components using the OwlMind Launch standards."""

    DEFAULT_LOG_LEVEL = Ollama.LOG_CRITICAL

    @staticmethod
    def load_env(filepath=".env"):
        """Manually parses a .env file and injects into os.environ."""
        if not os.path.exists(filepath):
            return
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    key, value = line.split("=", 1)
                    key, value = key.strip(), value.strip().strip("'").strip('"')
                    if key not in os.environ:
                        os.environ[key] = value
        except Exception as e:
            print(f"Warning: Could not load .env file: {e}", file=sys.stderr)

    @staticmethod
    def parse_params(raw_params: list) -> dict:
        """
        Parses parameters into a typed dictionary.
        Handles: -p k=v,k2=v2 AND -p k=v -p k2=v2
        """
        params = {}
        if not raw_params:
            return params
            
        # 1. Flatten the list and split by commas
        # If raw_params is ['temp=1', 'seed=42,top_k=10'], this flattens it correctly
        tokens = []
        for item in raw_params:
            tokens.extend(item.split(','))
            
        for kv in tokens:
            if "=" not in kv:
                continue
            
            k, v = kv.split("=", 1)
            k, v = k.strip(), v.strip()
            
            # 2. Type Inference (Boolean, Int, Float, String)
            if v.lower() == "true":
                v = True
            elif v.lower() == "false":
                v = False
            else:
                try:
                    # Try Integer
                    v = int(v)
                except ValueError:
                    try:
                        # Try Float
                        v = float(v)
                    except ValueError:
                        # Keep as string (e.g., stop sequences or system prompts)
                        pass 
            params[k] = v
            
        return params


    @staticmethod
    def dispatch(args):
        # 1. Start with context
        context = vars(args).copy()

        # 2. Logic for Logging / Debug using Component constants
        # We check the debug flag and map it to our integer constants
        target_level = Ollama.LOG_DEBUG if context.get('debug') else Dispatcher.DEFAULT_LOG_LEVEL
        
        # Set global logging level
        logging.getLogger().setLevel(target_level)
        logging.getLogger("httpx").setLevel(target_level)
        
        # Pass the integer level into the context so it hits the property setter
        context['log_level'] = target_level

        # 3. Dynamic Parameter Parsing
        dynamic_params = Dispatcher.parse_params(context.pop('params', []))
        context.update(dynamic_params)

        # 4. Resolve Input Logic
        if args.command == "query":
            user_input = Dispatcher.resolve_prompt(args)
            if not user_input:
                print("Error: No prompt provided.", file=sys.stderr)
                sys.exit(1)
            context['input'] = user_input

        # 5. Initialize Component
        # At this point, context contains everything (debug, command, url, model, etc.)
        api = Ollama(**context)

        # 6. TELL OLLAMA TO OBFUSCATE THE PLUMBING
        # This moves the argparse noise to private _attributes
        api.obfuscate(['debug', 'command', 'input_file', 'prompt'])

        # 7. Route Command
        if args.command == "ping":
            Dispatcher.handle_ping(api)
        elif args.command == "info":
            Dispatcher.handle_info(api)
        elif args.command == "query":
            Dispatcher.handle_query(api)
        
        return



    @staticmethod
    def resolve_prompt(args):
        if getattr(args, 'input_file', None):
            return Dispatcher.load_file(args.input_file)
        prompt_val = getattr(args, 'prompt', None)
        if prompt_val and prompt_val.startswith("@"):
            return Dispatcher.load_file(prompt_val[1:])
        return prompt_val

    @staticmethod
    def load_file(filepath):
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return f.read().strip()
        except Exception as e:
            print(f"Error loading {filepath}: {e}", file=sys.stderr)
            sys.exit(1)

    @staticmethod
    def handle_ping(api):
        status = "ONLINE" if api.ping() else "OFFLINE"
        print(f"Status: {status} (Host: {api.url})")

    @staticmethod
    def handle_info(api):
        data = api.info()

        print("-" * 40)
        print(f"Status  : {data['status']}")
        print(f"Host    : {api.url}")
        print(f"Model   : {api.model}")

        print("-" * 40)
        models_list = data.get('models', [])
        print(f"Available Models: {len(models_list)}")
        for m in models_list:
            print(f"  - {m}")

        print("-" * 40)
        return

    @staticmethod
    def handle_query(api):
        if not api.ping():
            print(f"Error: Server {api.url} unreachable.", file=sys.stderr)
            sys.exit(1)

        # step() yields chunks; we print them in real-time
        if api.log_level == api.LOG_DEBUG:
            print(f"--- Inference: {api.model} ---")
        for chunk in api.step():
            print(chunk, end="", flush=True)
        
        print()
        return 

def get_parser():
    parser = argparse.ArgumentParser(prog="owlmind")
    
    # Generate the helpers
    param_list = ", ".join(Ollama.OLLAMA_PARAMS.keys())
    param_help = f"Supports k=v; (k1=v1,k2=v2), or multiple flags. Options: {param_list}"

    # Global arguments
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--debug", action="store_true", help="Enable verbose telemetry and internal logs")
    parser.add_argument("--url", dest="url", default=os.environ.get("OLLAMA_HOST", Ollama.DEFAULT_SERVER))
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    # ping / info
    subparsers.add_parser("ping")
    subparsers.add_parser("info")

    # query
    qp = subparsers.add_parser("query")
    qp.add_argument("prompt", nargs="?", default=None)
    qp.add_argument("--input", "-i", dest="input_file")
    qp.add_argument("--model", "-m", default=os.environ.get("OLLAMA_MODEL", Ollama.DEFAULT_MODEL))
    qp.add_argument("--params", "-p", action="append", dest="params", help=param_help)

    return parser


##
## ENTRY POINT
##

def main():
    Dispatcher.load_env()
    parser = get_parser()
    args = parser.parse_args()
    Dispatcher.dispatch(args)


##
## EXECUTOR
##
if __name__ == "__main__":
    main()