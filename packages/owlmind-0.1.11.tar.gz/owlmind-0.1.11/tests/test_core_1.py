##
## OwlMind Framework - experimentation environment for Generative Intelligence Systems.
## TEsts for core elements - Component
##
# Copyright (c) 2025, Dr. Fernando Koch
#    https://github.com/genilab/owlmind
#

# pip install -e .
# python3 tests/test_core_1.py

import os
import json
import logging
from typing import Iterator, Any
from owlmind.core import Component

# Concrete implementation for testing purposes
class MyComponent(Component):
    def ping(self) -> bool: return True
    def info(self) -> dict: return {"name": "TestComponent"}
    def step(self) -> Iterator[Any]: 
        yield "test-result"
        return

# ============================================================
#  TESTS / EXPERIMENTS
# ============================================================

if __name__ == "__main__":

    print(f"\n🚀 STARTED: [{os.path.basename(__file__)}].")

    ####
    ## Experiment 1 — Initialization & Logger Sync
    ####
    print("\nExperiment 1: Initialization & Logger Sync")
    # Initializing with string; testing mapping to internal _logger_
    comp = MyComponent(log_level="DEBUG", user_id="FK-2026")

    assert comp.log_level == MyComponent.LOG_DEBUG
    assert comp._logger_.level == 10  # Standard logging.DEBUG
    assert hasattr(comp, '_logger_')  # Verify _name_ convention
    
    print(json.dumps(comp.session(), indent=2))
    print("✅ CHECKED")


    ####
    ## Experiment 2 — Dynamic Level Updates
    ####
    print("\nExperiment 2: Dynamic Level Updates")
    comp = MyComponent(log_level=MyComponent.LOG_INFO)

    assert comp._logger_.level == 20
    comp.log_level = "WARNING" # Testing string-to-int setter conversion
    
    assert comp._logger_.level == MyComponent.LOG_WARNING
    assert comp.log_level == 30

    print(f"Updated Level (int): {comp.log_level}")
    print("✅ CHECKED")


    ####
    ## Experiment 3 — Session Cleanliness
    ####
    print("\nExperiment 3: Session Cleanliness")
    comp = MyComponent(log_level=MyComponent.LOG_DEBUG, api_key="sk-12345", project="OwlMind")
    comp.obfuscate("api_key")
    session_data = comp.session()
    
    # Internal plumbing (starting with _) and obfuscated keys must not leak
    assert "_logger_" not in session_data
    assert "log_level" not in session_data
    assert "api_key" not in session_data
    assert "project" in session_data

    print(json.dumps(session_data, indent=2))
    print("✅ CHECKED")


    ####
    ## Experiment 4 — Functional Logging Output
    ####
    print("\nExperiment 4: Functional Logging Output")
    # Force reconfiguration to capture output for this test
    logging.basicConfig(format='%(name)s - %(levelname)s - %(message)s', force=True)
    comp = MyComponent(log_level="DEBUG")
    
    print("Should see a DEBUG log below:")
    comp.log("This is a test log message at DEBUG level.", level=MyComponent.LOG_DEBUG)
    
    comp.log_level = MyComponent.LOG_ERROR
    print(f"Level is now: {comp.log_level} (ERROR)")
    print("Should NOT see a DEBUG log below (suppression test):")
    comp.log("This message should be suppressed.", level=MyComponent.LOG_DEBUG)
    print("✅ CHECKED")


    ####
    ## Experiment 5 — I/O Persistence & Framework Attributes
    ####
    print("\nExperiment 5: I/O Persistence & Framework Attributes")
    comp = MyComponent(input="InputData", weight=50)
    
    # Check I/O Mapping
    assert comp.input == "InputData"
    assert comp._input_ == "InputData"
    
    # Check inheritance from Node
    assert comp._weight_ == 50
    assert "input" not in comp.session() # Properties are not in __dict__
    
    print(f"Component Weight: {comp._weight_}")
    print("✅ CHECKED")



    ####
    ## Experiment 6 — Deep Obfuscation & Property Masking
    ####
    print("\nExperiment 6: Deep Obfuscation & Property Masking")
    # Setting up a component with public data, internal framework data, and sensitive data
    comp = MyComponent(
        session={"public_id": "PUB-99"}, 
        secret_token="tok_8822", 
        internal_config="v1.0.4",
        log_level="INFO"
    )

    # Before obfuscation: secret_token should be visible, log_level/internal _vars should not
    pre_session = comp.session()
    assert "secret_token" in pre_session
    assert "log_level" not in pre_session
    assert "_logger_" not in pre_session
    
    # Applying obfuscation to the sensitive key
    comp.obfuscate("secret_token")
    # Also obfuscating 'internal_config' just to be sure
    comp.obfuscate("internal_config")
    
    post_session = comp.session()
    
    assert "public_id" in post_session
    assert "secret_token" not in post_session
    assert "internal_config" not in post_session
    
    print("Session after obfuscation:")
    print(json.dumps(post_session, indent=2))
    print("✅ CHECKED: Only public keys remain.")


    ####
    ## Experiment 7 — Multi-Key Obfuscation & Collision Check
    ####
    print("\nExperiment 7: Multi-Key Obfuscation & Collision Check")
    comp = MyComponent(user="neo", credit_card="4111...", ssn="000-00-0000")
    
    # Testing passing a list of keys to obfuscate
    comp.obfuscate(["credit_card", "ssn"])
    
    # Testing "By-Mistake" collision: User adds a variable starting with _
    # It should be filtered automatically by the session() logic
    comp._user_injected_internal = "Should not be here"
    
    final_session = comp.session()
    
    assert "user" in final_session
    assert "credit_card" not in final_session
    assert "ssn" not in final_session
    assert "_user_injected_internal" not in final_session
    
    print("Final session cleanup:")
    print(json.dumps(final_session, indent=2))
    print("✅ CHECKED: List obfuscation and '_' filtering successful.")


    print(f"\n🎉 SUCCESS!! [{os.path.basename(__file__)}] completed.")