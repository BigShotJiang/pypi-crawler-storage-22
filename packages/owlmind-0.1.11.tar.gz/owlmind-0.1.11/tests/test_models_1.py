##
## OwlMind Framework - experimentation environment for Generative Intelligence Systems.
## Basic tests for Ollama
##
# Copyright (c) 2025, Dr. Fernando Koch
#    https://github.com/genilab/owlmind
#



# pip install -e .
# python3 tests/test_models_1.py

import os
import json
import logging
from typing import Iterator, Any
from dotenv import load_dotenv
from owlmind.models import Ollama

# ============================================================
#  TESTS / EXPERIMENTS
# ============================================================

if __name__ == "__main__":

    print(f"\n🚀 STARTED: [{os.path.basename(__file__)}].")

    # Load variables from .env into os.environ
    load_dotenv()

    # Retrieve with fallbacks
    ENV_SERVER = os.getenv("OLLAMA_HOST", "http://localhost:11434")
    ENV_MODEL = os.getenv("OLLAMA_MODEL", "llama3")
    Ollama.DEFAULT_LOG_LEVEL = logging.DEBUG

    ####
    ## Experiment 1 — Env Injection & Sparse Config
    ####
    print("\nExperiment 1: Env Injection & Sparse Config Visualization")
    # Inject variables; notice we only pass what we want to change
    model = Ollama(url=ENV_SERVER, model=ENV_MODEL, temperature=0.5)
    
    info = model.info()
    session = info["session"]

    # Verify None-filtering: seed/top_p should be absent from session
    assert "url" in session
    assert "temperature" in session
    assert "seed" not in session
    # Verify framework attributes are hidden
    assert "_client_" not in session

    print(f"Server detected: {model.url}")
    print(json.dumps(info, indent=2))
    print("✅ CHECKED")


    ####
    ## Experiment 2 — Model Listing & Connectivity
    ####
    print("\nExperiment 2: Model Listing & Connectivity")
    info = model.info()
    print(f"Status: {info['status']}")
    
    # Check internal cache naming convention alignment
    assert hasattr(model, '_models_cache_')
    
    if info['status'] == "online":
        assert isinstance(info['models'], list)
        if len(info['models']) == 0:
            print("⚠️ ALERT: Connection successful but list is empty. Check OLLAMA_HOST.")
        else:
            print(f"✅ Found {len(info['models'])} models.")
    
    print("✅ CHECKED")


    ####
    ## Experiment 3 — Hello World Request
    ####
    print("\nExperiment 3: Hello World Request")
    model.input = "Say 'Hello OwlMind!'"
    
    if model.ping():
        print(f"Sending request to {model.model}...")
        for chunk in model.step():
            print(f"Yield: {chunk}")
        
        # Verify property access vs internal storage
        assert model.output is not None
        assert hasattr(model, '_output_')
        assert "Hello" in model.output
        
        # Double check privacy: input and output (as internal _) should NOT be in session
        session_data = model.session()
        assert "input" not in session_data
        assert "output" not in session_data
        
        print(f"Final Output: {model.output}")
    else:
        print("⚠️ Skipping request: Server offline.")
    
    print("✅ CHECKED")


    ####
    ## Experiment 4 — Creative Variation (High Temp)
    ####
    print("\nExperiment 4: Creative Variation (High Temp)")
    # Testing log_level setter via string
    model = Ollama(url=ENV_SERVER, model=ENV_MODEL, temperature=1.5, log_level="DEBUG")
    
    model.input = "Write a one-sentence surrealist poem."
    for _ in model.step(): pass
    
    # Verifying session logic via info()
    session = model.info()["session"]
    assert "input" not in session
    assert "output" not in session
    assert session["temperature"] == 1.5
    
    print(f"Captured Output: {model.output}")
    print("✅ CHECKED")


    ####
    ## Experiment 5 — Precise Variation (Low Temp + Seed)
    ####
    print("\nExperiment 5: Precise Variation (Low Temp + Seed)")
    model = Ollama(
        url=ENV_SERVER, 
        model=ENV_MODEL, 
        temperature=0.0, 
        seed=42,
        log_level="DEBUG"
    )
    model.input = "What is the square root of 144?"
    
    for chunk in model.step(): 
        print(f"Yield: {chunk}")

    # Verify parameters that are NOT None appear in the session
    assert model.session()["seed"] == 42
    print("✅ CHECKED")


    ####
    ## Experiment 6 — Long Context Configuration
    ####
    print("\nExperiment 6: Long Context Configuration")
    model = Ollama(
        url=ENV_SERVER, 
        model=ENV_MODEL, 
        num_ctx=8192, 
        repeat_penalty=1.2
    )
    model.input = "Explain the difference between a Class and an Instance in Python."
    
    for _ in model.step(): pass

    assert model.num_ctx == 8192
    print(f"Context verified: {model.num_ctx} tokens.")
    print("✅ CHECKED")


    ####
    ## Experiment 7 — System Prompt Override
    ####
    print("\nExperiment 7: System Prompt Override")
    model = Ollama(url=ENV_SERVER, model=ENV_MODEL, system="Talk like a pirate")
    model.input = "Where is the treasure?"
    
    for chunk in model.step():
        print(f"Yield: {chunk}")
        
    print("✅ CHECKED")


    ####
    ## Experiment 8 — Full Parameter Blast (Stress Test)
    ####
    print("\nExperiment 8: Full Parameter Blast")
    params = {
        "temperature": 0.9,
        "top_p": 0.8,
        "top_k": 20,
        "num_predict": 50,
        "repeat_penalty": 1.1,
        "seed": 99
    }
    model = Ollama(url=ENV_SERVER, model=ENV_MODEL, **params)
    model.input = "Give me a 5-word sci-fi writing prompt."
    
    for _ in model.step(): pass

    # Verify all 6 params are in the cleaned session dictionary
    # because they were initialized with non-None values.
    session_data = model.session()
    session_params = [k for k in session_data if k in model.OLLAMA_PARAMS]
    assert len(session_params) == 6
    
    print("Full session export (None-values and _internals_ absent):")
    print(json.dumps(model.session(), indent=2))
    print("✅ CHECKED")

    print(f"\n🎉 SUCCESS!! [{os.path.basename(__file__)}] completed.")

