##
## GraphK - Framework for Graph programming.
## pipeline.py — data structure for Processing Lines.        
##
# Copyright (c) 2025, Dr. Fernando Koch
#    http://github.com/kochf1/graphk
#
# Disclosure:
# This code was developed through 'vibe coding'. Certain components
# required manual implementation, and human-in-the-loop review and refinement
# were applied throughout the project.
#


from abc import ABC, abstractmethod
from typing import Union, Callable, List, Any, Iterator
from .node import Node

class Pipeline(Node):
    """
    Orchestrator for a sequence of Nodes. 
    Compatible with GraphK Node and Gate structures.
    """
    # Execution Policies
    SKIP_ON_FAIL = 0   
    STOP_ON_FAIL = 1

    def __init__(self, 
                 nodes: Iterable[Node] = None, 
                 _session: dict = None, 
                 fail_policy: int = STOP_ON_FAIL,
                 **kwargs):
        """
        Initialize the pipeline as a Node containing other Nodes.
        """
        super().__init__(_session=_session, **kwargs)
        self.nodes = list(nodes) if nodes else []
        self.fail_policy = fail_policy
        self.obfuscate(['nodes', 'fail_policy'])

    # --- Node Access (Pythonic Interface) ---

    def __len__(self) -> int: return len(self.nodes)

    def __getitem__(self, index): return self.nodes[index]

    def add(self, node: Node): 
        self.nodes.append(node)
        return self

    # --- Execution Logic ---

    def ping(self) -> bool:
        """Pipeline is healthy if all internal nodes are healthy."""
        return all(n.ping() for n in self.nodes)

    def info(self) -> dict:
        return {
            "type": "Pipeline",
            "node_count": len(self.nodes),
            "nodes": [type(n).__name__ for n in self.nodes]
        }

    def step(self) -> Iterator[Any]:
        """
        Executes the pipeline sequence. 
        Passes output of one node as input to the next.
        """
        current_input = getattr(self, 'input', None)

        for node in self.nodes:
            # 1. Check Condition Gate (if assigned to the node)
            if hasattr(node, 'can_proceed') and not node.can_proceed(current_input):
                if self.fail_policy == self.STOP_ON_FAIL: break
                continue

            # 2. Set input and execute
            node.input = current_input
            
            # 3. Collect output (assuming step() returns an iterator)
            node_output = None
            for chunk in node.step():
                node_output = chunk # Capture last chunk as the state
                yield chunk

            # 4. Check Validation Gate
            if hasattr(node, 'is_valid') and not node.is_valid(node_output):
                if self.fail_policy == self.STOP_ON_FAIL: break
            
            # 5. Chain output to next input
            current_input = node_output

        self._output = current_input

