
##
## OwlMind Framework - experimentation environment for Generative Intelligence Systems.
## core/ollama.py — Ollama-backed implementation of the Component interface.
##
# Copyright (c) 2025, The Generative Intelligence Lab
#    https://github.com/genilab/owlmind
#
# Disclosure:
# This framework was developed using a 'vibe coding' . AI-synthesized logic was 
# subjected to human review and manual refinement to guarantee functional 
# integrity and structural clarity.
#

import logging
import ollama
from typing import Any, Iterator
from owlmind.core import Component

class Ollama(Component):
    """
    Implementation of Ollama model access component.
    Configuration and parameters are strictly managed via attributes.
    """

    DEFAULT_SERVER = "http://localhost:11434"
    DEFAULT_MODEL = "llama3"
    DEFAULT_TIMEOUT = 10
    DEFAULT_LOG_LEVEL = logging.INFO

    OLLAMA_PARAMS = {
        "temperature": None, "top_p": None, "seed": None,
        "num_ctx": None, "num_predict": None, "repeat_penalty": None,
        "top_k": None, "stop": None, "system": None
    }

    def __init__(self, session: dict = None, **kwargs):
        # Internal framework storage using _name_ convention
        self._models_cache_ = None
        self._client_ = None
        
        # Establish loggign level
        log_level = kwargs.pop('log_level', self.DEFAULT_LOG_LEVEL)

        # Initialize Component (which handles _logger_, _input_, etc.)
        super().__init__(session=session, log_level=log_level, **kwargs)
        
        # Ensure public config attributes exist in __dict__ for session()
        if not hasattr(self, 'url'): self.url = self.DEFAULT_SERVER
        if not hasattr(self, 'model'): self.model = self.DEFAULT_MODEL
        
        # Map parameters; if None, they stay in session() as None unless filtered
        for param, default_value in self.OLLAMA_PARAMS.items():
            if not hasattr(self, param): setattr(self, param, default_value)

        # Initialize the client using the framework internal
        self._client_ = ollama.Client(host=self.url, timeout=self.DEFAULT_TIMEOUT)
        
        # Obfuscate the client-related keys just in case
        self.obfuscate(['_client_', '_models_cache_'])
        return

    def ping(self) -> bool:
        """Health check for Ollama server."""
        is_alive = False
        try:
            self._client_.list()
            is_alive = True
        except Exception as e:
            self.log(f"Ping failed at {self.url}: {e}", level=self.LOG_WARNING)
        
        return is_alive

    def info(self) -> dict:
        """Capability reporting including available models."""
        if self._models_cache_ is None:
            try:
                response = self._client_.list()
                # Handle varying response structures from Ollama library
                models_list = getattr(response, 'models', response.get('models', []))
                self._models_cache_ = [
                    getattr(m, 'model', getattr(m, 'name', m.get('model', m.get('name')))) 
                    for m in models_list if m
                ]
            except Exception:
                self._models_cache_ = []

        # Filter out None values for a cleaner info report
        clean_session = {k: v for k, v in self.session().items() if v is not None}
        
        return {
            "status": "online" if self.ping() else "offline",
            "session": clean_session,
            "models": self._models_cache_
        }

    def step(self) -> Iterator[str]:
        """Execution: Performs LLM inference."""
        # Fail Fast: No input
        if not self.input:
            self.log("Step skipped: No input provided.", level=self.LOG_WARNING)
            yield "No input found."
            return

        # Prepare parameters for Ollama API
        options = {p: getattr(self, p) for p in self.OLLAMA_PARAMS if getattr(self, p) is not None}

        self.log(f"Inference: {self.model} @ {self.url}", level=self.LOG_INFO)
        self.log(f"Parameters: {options}", level=self.LOG_DEBUG)

        result = ""
        try:
            response = self._client_.generate(model=self.model, prompt=self.input, options=options)
            result = response.get('response', '')
            self.output = result # Using property setter
        except Exception as e:
            self.log(f"Ollama Error: {e}", level=self.LOG_ERROR)
            result = f"Error: {str(e)}"
        
        yield result
        return