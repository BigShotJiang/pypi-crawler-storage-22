//\! Pretty printing configuration

