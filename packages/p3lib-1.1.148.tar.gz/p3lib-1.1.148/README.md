# A Python3 library
A group of python modules for networking, plotting data, config storage, automating boot scripts, ssh access and user input output.

## Installation
p3lib is available on pypi and can be installed using the following command.

```
pip3 install p3lib
```
