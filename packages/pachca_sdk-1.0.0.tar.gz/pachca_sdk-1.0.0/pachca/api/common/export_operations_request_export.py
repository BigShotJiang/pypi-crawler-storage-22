from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.api_error import ApiError
from ...models.empty_response import EmptyResponse
from ...models.export_request import ExportRequest
from ...models.o_auth_error import OAuthError
from typing import cast



def _get_kwargs(
    *,
    body: ExportRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/chats/exports",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ApiError | ApiError | OAuthError | EmptyResponse | OAuthError | None:
    if response.status_code == 204:
        response_204 = EmptyResponse.from_dict(response.json())



        return response_204

    if response.status_code == 400:
        response_400 = ApiError.from_dict(response.json())



        return response_400

    if response.status_code == 401:
        response_401 = OAuthError.from_dict(response.json())



        return response_401

    if response.status_code == 403:
        def _parse_response_403(data: object) -> ApiError | OAuthError:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_403_type_0 = ApiError.from_dict(data)



                return response_403_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_403_type_1 = OAuthError.from_dict(data)



            return response_403_type_1

        response_403 = _parse_response_403(response.json())

        return response_403

    if response.status_code == 422:
        response_422 = ApiError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ApiError | ApiError | OAuthError | EmptyResponse | OAuthError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ExportRequest,

) -> Response[ApiError | ApiError | OAuthError | EmptyResponse | OAuthError]:
    """  Экспорт сообщений

    #corporation_price_only #owner_access_token_required

    Метод для запрашивания экспорта сообщений за указанный период.

    Args:
        body (ExportRequest): Запрос на экспорт сообщений

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | ApiError | OAuthError | EmptyResponse | OAuthError]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: ExportRequest,

) -> ApiError | ApiError | OAuthError | EmptyResponse | OAuthError | None:
    """  Экспорт сообщений

    #corporation_price_only #owner_access_token_required

    Метод для запрашивания экспорта сообщений за указанный период.

    Args:
        body (ExportRequest): Запрос на экспорт сообщений

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | ApiError | OAuthError | EmptyResponse | OAuthError
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ExportRequest,

) -> Response[ApiError | ApiError | OAuthError | EmptyResponse | OAuthError]:
    """  Экспорт сообщений

    #corporation_price_only #owner_access_token_required

    Метод для запрашивания экспорта сообщений за указанный период.

    Args:
        body (ExportRequest): Запрос на экспорт сообщений

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiError | ApiError | OAuthError | EmptyResponse | OAuthError]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: ExportRequest,

) -> ApiError | ApiError | OAuthError | EmptyResponse | OAuthError | None:
    """  Экспорт сообщений

    #corporation_price_only #owner_access_token_required

    Метод для запрашивания экспорта сообщений за указанный период.

    Args:
        body (ExportRequest): Запрос на экспорт сообщений

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiError | ApiError | OAuthError | EmptyResponse | OAuthError
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
