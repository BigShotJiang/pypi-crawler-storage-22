from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="BotUpdateRequestBotWebhook")



@_attrs_define
class BotUpdateRequestBotWebhook:
    """ Объект параметров вебхука

        Attributes:
            outgoing_url (str): URL исходящего вебхука Example: https://www.website.com/tasks/new.
     """

    outgoing_url: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        outgoing_url = self.outgoing_url


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "outgoing_url": outgoing_url,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        outgoing_url = d.pop("outgoing_url")

        bot_update_request_bot_webhook = cls(
            outgoing_url=outgoing_url,
        )


        bot_update_request_bot_webhook.additional_properties = d
        return bot_update_request_bot_webhook

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
