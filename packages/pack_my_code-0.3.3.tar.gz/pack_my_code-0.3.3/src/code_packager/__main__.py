"""主入口模块

支持通过 python -m code_packager 方式运行程序。
"""

from .main import main

if __name__ == '__main__':
    main()