"""Package for fetching latest versions of mise-supported tools."""

from .functions import fetch_latest_tool_version

__all__ = ["fetch_latest_tool_version"]
