<ls-tool>
List directory contents with file info (name, type, size, modified time).

<best-practices>
- Use ignore parameter to filter out unwanted entries (logs, cache, node_modules)
- For recursive file search: use glob instead
- For content search: use grep instead
</best-practices>
</ls-tool>
