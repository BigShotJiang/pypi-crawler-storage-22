<search-tool>
Search the web for information using search APIs.

<best-practices>
- Keep queries concise and specific for better results
- Refine broad queries by reducing keywords if results are not ideal
</best-practices>
</search-tool>
