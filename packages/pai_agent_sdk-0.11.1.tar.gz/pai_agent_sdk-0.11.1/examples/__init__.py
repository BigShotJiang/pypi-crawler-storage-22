"""Example scripts for pai-agent-sdk.

This package contains example scripts demonstrating various use cases.
To use these examples, install with the examples extra:

    pip install "pai-agent-sdk[examples]"

Or for development:

    uv sync --extra examples
"""
