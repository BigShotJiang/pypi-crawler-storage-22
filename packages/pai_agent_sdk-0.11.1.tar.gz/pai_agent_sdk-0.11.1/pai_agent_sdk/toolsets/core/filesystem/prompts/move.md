<move-tool>
Move files or directories within the working directory.

<best-practices>
- Use pairs parameter for multiple moves in one call
- Set overwrite=true only when intentionally replacing files
- Verify source exists with ls or glob before moving
</best-practices>
</move-tool>
