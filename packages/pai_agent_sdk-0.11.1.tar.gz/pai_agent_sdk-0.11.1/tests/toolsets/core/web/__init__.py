"""Tests for pai_agent_sdk.toolsets.core.web module."""
