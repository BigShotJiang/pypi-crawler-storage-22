"""Internal test fixtures for pain001."""
