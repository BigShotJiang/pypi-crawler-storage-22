
---

## 3️⃣ Init Git (di folder PALASIK)

```bash
cd ~/palasik
git init
```
