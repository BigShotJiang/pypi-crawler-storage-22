"""
PALASIK IoT Security Framework
"""

