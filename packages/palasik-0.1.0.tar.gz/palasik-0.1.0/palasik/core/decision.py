from enum import Enum

class Decision(Enum):
    ALLOW = "ALLOW"
    DENY = "DENY"
