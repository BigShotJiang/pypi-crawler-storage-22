#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
二维码精准替换工具
==================
将目标图片中的二维码无缝替换为新的源二维码。

技术路线:
  1. pyzbar   — 检测并定位二维码的多边形角点
  2. OpenCV   — 透视变换 + 泊松无缝融合
  3. NumPy    — 辅助矩阵与掩膜运算

用法:
  python qr_replacer.py --target bg.jpg --source new_qr.png --output result.jpg
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np
from pyzbar.pyzbar import decode, ZBarSymbol


# ───────────────────────── 工具函数 ─────────────────────────


def _order_points(pts: np.ndarray) -> np.ndarray:
    """
    将 4 个角点按 [左上, 右上, 右下, 左下] 的顺序排列。
    这是透视变换的前提条件，保证源与目标角点一一对应。
    """
    rect = np.zeros((4, 2), dtype=np.float32)

    # 左上角: x+y 最小；右下角: x+y 最大
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]
    rect[2] = pts[np.argmax(s)]

    # 右上角: y-x 最小；左下角: y-x 最大
    d = np.diff(pts, axis=1).ravel()
    rect[1] = pts[np.argmin(d)]
    rect[3] = pts[np.argmax(d)]

    return rect


def detect_qr_polygon(image: np.ndarray, label: str) -> np.ndarray:
    """
    使用 pyzbar 检测图片中的二维码，并返回排序后的 4 个角点坐标。
    尝试多种预处理方式以提高检测成功率。

    参数:
        image: BGR 格式图片
        label: 图片标签（用于日志输出）

    返回:
        shape=(4, 2), dtype=float32 的角点数组
    """
    
    # 预处理策略列表: (处理函数, 描述)
    def to_gray(img): return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    def to_thresh(img): 
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        return cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
    def scale_up(img): return cv2.resize(img, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
    def scale_down(img): return cv2.resize(img, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)

    strategies = [
        (lambda x: x, "原始图像"),
        (to_gray, "灰度化"),
        (to_thresh, "自适应二值化"),
        (scale_up, "放大 2x"),
        (scale_down, "缩小 0.5x"),
    ]

    for preprocess, desc in strategies:
        try:
            processed = preprocess(image)
            results = decode(processed, symbols=[ZBarSymbol.QRCODE])
            if results:
                print(f"[信息] 在 {label} 中检测到二维码 (策略: {desc})")
                
                qr = results[0]
                polygon = np.array([(p.x, p.y) for p in qr.polygon], dtype=np.float32)

                # 如果有过缩放，需要还原坐标
                if desc == "放大 2x":
                    polygon /= 2.0
                elif desc == "缩小 0.5x":
                    polygon *= 2.0

                if len(polygon) != 4:
                    print(f"[警告] {label} 二维码角点数不为 4 ({len(polygon)})，尝试下一个策略...")
                    continue

                ordered = _order_points(polygon)
                print(f"[信息] {label} 二维码角点（左上→右上→右下→左下）:")
                for i, name in enumerate(["左上", "右上", "右下", "左下"]):
                    print(f"       {name}: ({ordered[i][0]:.1f}, {ordered[i][1]:.1f})")
                
                return ordered
        except Exception as e:
            print(f"[调试] 策略 {desc} 执行失败: {e}")
            continue

    print(f"[错误] 在 {label} 中尝试所有策略后仍未检测到有效的二维码。")
    sys.exit(1)


def inpaint_qr(image: np.ndarray, dst_pts: np.ndarray, dilation: int = 5, radius: int = 3) -> np.ndarray:
    """
    使用 OpenCV 的 inpaint 方法去除原图中的二维码，生成干净的背景。
    
    参数:
        image: 原始图片
        dst_pts: 二维码角点
        dilation: 掩膜膨胀像素数，确保覆盖二维码边缘
        radius: inpaint 算法的半径
    
    返回:
        去除二维码后的图片
    """
    # 1. 创建掩膜
    mask = np.zeros(image.shape[:2], dtype=np.uint8)
    hull = cv2.convexHull(dst_pts.astype(np.int32))
    cv2.fillConvexPoly(mask, hull, 255)
    
    # 2. 膨胀掩膜，确保覆盖边缘
    if dilation > 0:
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (dilation*2+1, dilation*2+1))
        mask = cv2.dilate(mask, kernel, iterations=1)
        
    # 3. 执行修复 (Inpainting)
    # INPAINT_TELEA: 基于快速行进算法 (Fast Marching Method)
    # INPAINT_NS: 基于纳维-斯托克斯方程 (Navier-Stokes)
    # 通常 Telea 速度更快且对于小区域效果不错
    inpainted = cv2.inpaint(image, mask, radius, cv2.INPAINT_TELEA)
    print(f"[信息] 已对原二维码区域进行背景修复 (膨胀: {dilation}, 半径: {radius})。")
    
    return inpainted


def build_convex_mask(warped: np.ndarray, dst_pts: np.ndarray) -> np.ndarray:
    """
    根据目标角点构建凸多边形掩膜，用于泊松融合。
    掩膜内部为白色 (255)，外部为黑色 (0)。
    """
    mask = np.zeros(warped.shape[:2], dtype=np.uint8)
    hull = cv2.convexHull(dst_pts.astype(np.int32))
    cv2.fillConvexPoly(mask, hull, 255)
    return mask



def start_tone_matching(source: np.ndarray, target: np.ndarray, dst_pts: np.ndarray) -> np.ndarray:
    """
    色调匹配: 分析目标图中二维码区域的亮部和暗部，将源二维码的色值映射过去。
    """
    # 1. 提取目标区域
    mask = np.zeros(target.shape[:2], dtype=np.uint8)
    hull = cv2.convexHull(dst_pts.astype(np.int32))
    cv2.fillConvexPoly(mask, hull, 255)
    
    # 缩小掩膜以避开边缘杂色
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (10, 10))
    inner_mask = cv2.erode(mask, kernel, iterations=1)
    
    target_region = cv2.bitwise_and(target, target, mask=inner_mask)
    
    # 2. 统计目标区域的颜色分布 (Simple: Mean of brightest and darkest pixels)
    # 转换为灰度来找亮暗点
    gray = cv2.cvtColor(target_region, cv2.COLOR_BGR2GRAY)
    
    # 取样区域内的像素
    valid_pixels = target_region[inner_mask == 255]
    valid_gray = gray[inner_mask == 255]
    
    if len(valid_gray) == 0:
        return source

    # 简单策略：取亮度前 10% 作为“白”，后 10% 作为“黑”
    # 更稳健的策略：K-Means (2 classes)
    from sklearn.cluster import MiniBatchKMeans
    
    # 降采样以加速聚类
    if len(valid_pixels) > 1000:
        indices = np.random.choice(len(valid_pixels), 1000, replace=False)
        samples = valid_pixels[indices]
    else:
        samples = valid_pixels

    # K-Means 聚类找黑白两簇
    kmeans = MiniBatchKMeans(n_clusters=2, random_state=0, n_init=3).fit(samples)
    centers = kmeans.cluster_centers_  # shape (2, 3) BGR
    
    # 判断哪个中心是亮色（白），哪个是暗色（黑）
    # 用亮度 (Luma) 判断: Y = 0.299R + 0.587G + 0.114B
    lumas = np.dot(centers, [0.114, 0.587, 0.299])
    
    if lumas[0] > lumas[1]:
        target_white = centers[0]
        target_black = centers[1]
    else:
        target_white = centers[1]
        target_black = centers[0]
        
    print(f"[信息] 色调分析 (黑/白): [{int(target_black[0])},{int(target_black[1])},{int(target_black[2])}] / [{int(target_white[0])},{int(target_white[1])},{int(target_white[2])}]")
    
    # 3. 映射源图片颜色
    # Source (0-255) -> Target (Black-White)
    # Formula: Result = Black + (Source / 255.0) * (White - Black)
    
    source_float = source.astype(np.float32) / 255.0
    
    target_black_full = np.full_like(source_float, target_black)
    target_white_full = np.full_like(source_float, target_white)
    
    diff = target_white_full - target_black_full
    matched = target_black_full + source_float * diff
    
    return np.clip(matched, 0, 255).astype(np.uint8)



def add_gaussian_noise(image: np.ndarray, strength: float = 10.0) -> np.ndarray:
    """
    添加单色高斯噪点以模拟相机 ISO 颗粒感（避免彩色噪点）。
    """
    row, col, ch = image.shape
    mean = 0
    sigma = strength
    
    # 生成单通道噪点并扩展到 3 通道
    gauss = np.random.normal(mean, sigma, (row, col, 1))
    gauss = np.repeat(gauss, ch, axis=2)
    
    noisy = image.astype(np.float32) + gauss
    return np.clip(noisy, 0, 255).astype(np.uint8)


# ───────────────────────── 核心流程 ─────────────────────────


def replace_qr(target_path: str, source_path: str, output_path: str, mode: str = "soft", padding: int = -2, blur_radius: int = 1, inpaint: bool = True, inpaint_dilation: int = 5, match_tone: bool = True, noise: float = 0.0, content_blur: float = 0.0) -> None:
    """
    核心替换流程:
      ① 读取目标图与源图
      ② 分别检测二维码角点
      ③ (可选) 智能擦除原二维码
      ④ 透视变换：将源二维码扭曲到目标位置
      ⑤ 图像融合：Alpha Blending (soft) 或 泊松 (seamless)
      ⑥ 保存结果
    """
    # ── ① 读取图片 ──────────────────────────────────────────
    target = cv2.imread(target_path, cv2.IMREAD_COLOR)
    source = cv2.imread(source_path, cv2.IMREAD_COLOR)

    if target is None:
        print(f"[错误] 无法读取目标图片: {target_path}")
        sys.exit(1)
    if source is None:
        print(f"[错误] 无法读取源图片: {source_path}")
        sys.exit(1)

    print(f"[信息] 目标图片尺寸: {target.shape[1]}×{target.shape[0]}")
    print(f"[信息] 源图片尺寸:   {source.shape[1]}×{source.shape[0]}")

    # ── ② 检测二维码角点 ────────────────────────────────────
    dst_pts = detect_qr_polygon(target, "目标图片")
    src_pts = detect_qr_polygon(source, "源图片")
    
    # ── ③ 智能擦除 (Inpainting) ──────────────────────────────
    # 在进行透视变换和融合之前，先将原图中的二维码擦除
    # 这样即使新二维码尺寸略小或对齐有偏差，露出来的也是背景纹理，而非旧二维码
    background_img = target
    if inpaint:
        background_img = inpaint_qr(target, dst_pts, dilation=inpaint_dilation)

    # ── [NEW] 色调匹配与噪点/模糊模拟 ────────────────────────
    processed_source = source.copy()
    
    if match_tone:
        try:
            processed_source = start_tone_matching(processed_source, target, dst_pts)
        except Exception as e:
            print(f"[警告] 色调匹配失败 ({e})，跳过...")
            
    # 模拟内容模糊 (Simulate soft focus / low resolution)
    if content_blur > 0:
        # 确保核大小是奇数
        ksize = int(content_blur) * 2 + 1
        processed_source = cv2.GaussianBlur(processed_source, (ksize, ksize), 0)
        print(f"[信息] 已应用内容模糊 (半径: {content_blur})。")

    if noise > 0:
        processed_source = add_gaussian_noise(processed_source, strength=noise)
        print(f"[信息] 已添加高斯噪点 (强度: {noise})。")

    # ── ④ 透视变换 ──────────────────────────────────────────
    # 计算从 源二维码角点 → 目标二维码角点 的透视变换矩阵
    M = cv2.getPerspectiveTransform(src_pts, dst_pts)

    # 将整张源图片按透视矩阵变换到目标图片的坐标空间
    h_dst, w_dst = target.shape[:2]
    warped_source = cv2.warpPerspective(
        processed_source, M, (w_dst, h_dst),
        flags=cv2.INTER_LANCZOS4,          # 高质量插值
        borderMode=cv2.BORDER_CONSTANT,     # 边界填黑
        borderValue=(0, 0, 0),
    )
    print("[信息] 透视变换完成。")

    # ── ⑤ 图像融合 (Alpha Blending 优化) ──────────────────────
    # 5a. 构建初始掩膜 (0 or 255)
    mask = build_convex_mask(warped_source, dst_pts)

    # 5b. 边缘调整 (Padding/Erosion)
    # 默认向内收缩 (-2) 以去除原图残留边框
    if padding != 0:
        if padding > 0:
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (padding*2+1, padding*2+1))
            mask = cv2.dilate(mask, kernel, iterations=1)
        else:
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (abs(padding)*2+1, abs(padding)*2+1))
            mask = cv2.erode(mask, kernel, iterations=1)

    # 5c. 边缘羽化 (Soft Edges)
    # 将掩膜转换为 float [0, 1] 并进行高斯模糊，消除锯齿
    mask_float = mask.astype(np.float32) / 255.0
    
    # 只有在非 seamless 模式下才应用模糊羽化
    # seamlessClone 需要硬边缘掩膜 (int 255)
    if mode != "seamless" and mode != "mixed":
        if blur_radius > 0:
            # 确保核大小是奇数
            ksize = int(blur_radius) * 2 + 1
            mask_float = cv2.GaussianBlur(mask_float, (ksize, ksize), 0)

    # 5d. 合成
    # 注意：这里使用 background_img (可能是修复后的背景) 代替 original target
    if mode == "seamless" or mode == "mixed":
        # 泊松融合需要 uint8 掩膜
        mask_uint8 = (mask_float * 255).astype(np.uint8)
        
        moments = cv2.moments(mask_uint8)
        if moments["m00"] == 0:
            print("[错误] 掩膜面积为零，无法计算融合中心。")
            sys.exit(1)
        cx = int(moments["m10"] / moments["m00"])
        cy = int(moments["m01"] / moments["m00"])
        center = (cx, cy)
        
        try:
            clone_mode = cv2.NORMAL_CLONE if mode == "seamless" else cv2.MIXED_CLONE
            result = cv2.seamlessClone(
                warped_source, background_img, mask_uint8, center,
                clone_mode,
            )
            print(f"[信息] 泊松融合完成 ({mode})。")
        except cv2.error as e:
            print(f"[警告] 泊松融合失败 ({e})，回退到 Soft Overlay...")
            # 回退逻辑 -> 继续执行下方的 alpha blending
            mode = "soft"

    if mode == "soft" or mode == "overlay":
        # Alpha Blending: Result = Source * Alpha + Background * (1 - Alpha)
        # 扩展掩膜为 3 通道
        alpha = cv2.merge([mask_float, mask_float, mask_float])
        
        target_float = background_img.astype(np.float32)
        source_float = warped_source.astype(np.float32)
        
        # 混合
        blended = source_float * alpha + target_float * (1.0 - alpha)
        result = blended.astype(np.uint8)
        print(f"[信息] Alpha 混合完成 (模式: {mode}, 羽化: {blur_radius})。")


    # ── ⑤ 保存结果 ──────────────────────────────────────────
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)

    # 根据扩展名选择编码参数
    ext = output.suffix.lower()
    params: list[int] = []
    if ext in (".jpg", ".jpeg"):
        params = [cv2.IMWRITE_JPEG_QUALITY, 98]   # 高质量 JPEG
    elif ext == ".png":
        params = [cv2.IMWRITE_PNG_COMPRESSION, 3]  # 适度压缩 PNG
    elif ext == ".webp":
        params = [cv2.IMWRITE_WEBP_QUALITY, 98]

    success = cv2.imwrite(str(output), result, params)
    if success:
        print(f"[完成] 替换结果已保存至: {output.resolve()}")
    else:
        print(f"[错误] 保存失败，请检查输出路径: {output_path}")
        sys.exit(1)


# ───────────────────────── CLI 入口 ─────────────────────────


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="精准且无缝地替换目标图片中的二维码",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "示例:\n"
            "  python qr_replacer.py -t bg.jpg -s new.png --mode soft --padding -2 --blur 1\n"
            "  python qr_replacer.py -t bg.jpg -s new.png --mode seamless --inpaint-dilation 10\n"
        ),
    )

    parser.add_argument(
        "-t", "--target",
        required=False,
        help="目标图片路径（含有待替换二维码的背景图）",
    )
    parser.add_argument(
        "-s", "--source",
        required=False,
        help="源图片路径（新的纯净二维码图片）",
    )
    parser.add_argument(
        "-b", "--blur",
        type=int,
        default=2,
        help="边缘羽化半径 (仅 soft/overlay 模式有效)，默认 2",
    )
    parser.add_argument(
        "--no-inpaint",
        action="store_true",
        help="禁用智能擦除原二维码功能",
    )
    parser.add_argument(
        "--inpaint-dilation",
        type=int,
        default=5,
        help="智能擦除时的掩膜膨胀像素，默认 5",
    )
    parser.add_argument(
        "--no-tone",
        action="store_true",
        help="禁用色调匹配 (默认根据原图二维码颜色自动调整)",
    )
    parser.add_argument(
        "--noise",
        type=float,
        default=0.0,
        help="添加高斯噪点强度 (模拟相机颗粒感), 默认 0 (不添加)",
    )
    parser.add_argument(
        "--content-blur",
        type=float,
        default=0.0,
        help="源二维码模糊半径 (模拟对焦/分辨率差异), 默认 0 (不模糊)",
    )
    parser.add_argument(
        "-o", "--output",
        default="output.jpg",
        help="输出图片路径（默认: output.jpg）",
    )
    parser.add_argument(
        "-m", "--mode",
        choices=["seamless", "mixed", "soft", "overlay"],
        default="soft",
        help="融合模式: soft(推荐,边缘羽化), seamless(泊松), mixed(混合), overlay(硬覆盖)",
    )
    parser.add_argument(
        "-p", "--padding",
        type=int,
        default=-2,
        help="掩膜边缘缩放 (负数内缩去除白边)，默认 -2",
    )
    return parser.parse_args()


def select_file_gui(title: str) -> str:
    """如果不带参数运行，弹出文件选择框"""
    import tkinter as tk
    from tkinter import filedialog
    
    root = tk.Tk()
    root.withdraw()  # 隐藏主窗口
    
    path = filedialog.askopenfilename(
        title=title,
        filetypes=[("Images", "*.jpg *.jpeg *.png *.webp *.bmp")]
    )
    
    root.destroy()
    return path


def main() -> None:
    args = parse_args()
    
    # 如果没有提供参数，且在非 headless 环境，尝试交互式选择
    if not args.target or not args.source:
        print("[提示] 未检测到命令行参数，进入交互模式...")
        try:
            if not args.target:
                print(">>> 请选择【背景图片】(含有旧二维码)...")
                args.target = select_file_gui("选择背景图片 (Target)")
                if not args.target:
                    print("未选择图片，程序退出。")
                    return

            if not args.source:
                print(">>> 请选择【新二维码】(替换源)...")
                args.source = select_file_gui("选择新二维码图片 (Source)")
                if not args.source:
                    print("未选择图片，程序退出。")
                    return
                    
            # 交互模式下，如果未指定输出，自动生成默认名
            if args.output == "output.jpg":
                target_path = Path(args.target)
                args.output = str(target_path.parent /f"{target_path.stem}_replaced{target_path.suffix}")
                
        except Exception as e:
            print(f"[错误] 启动交互模式失败: {e}")
            print("请使用命令行参数运行: python qr_replacer.py -t bg.jpg -s new.png")
            sys.exit(1)

    inpaint = not args.no_inpaint
    match_tone = not args.no_tone

    print("=" * 50)
    print("  二维码无缝替换工具 (最新版 defaults=最佳效果)")
    print("=" * 50)
    print(f"  目标图片: {args.target}")
    print(f"  源图片:   {args.source}")
    print(f"  输出路径: {args.output}")
    print(f"  融合模式: {args.mode}")
    print(f"  边缘内缩: {args.padding} px")
    print(f"  边缘羽化: {args.blur} px")
    print(f"  智能擦除: {'启用' if inpaint else '禁用'} (膨胀: {args.inpaint_dilation})")
    print(f"  色调匹配: {'启用' if match_tone else '禁用'}")
    print(f"  模拟噪点: {args.noise}")
    print(f"  内容模糊: {args.content_blur}")
    print("=" * 50)

    try:
        replace_qr(args.target, args.source, args.output, args.mode, args.padding, args.blur, inpaint, args.inpaint_dilation, match_tone, args.noise, args.content_blur)
        
        # 如果是交互模式（可能是双击运行），暂停一下让用户看到结果
        if len(sys.argv) == 1:
            input("\n按回车键退出...")
            
    except Exception as e:
        print(f"\n[致命错误] {e}")
        import traceback
        traceback.print_exc()
        if len(sys.argv) == 1:
            input("\n程序异常，按回车键退出...")
        sys.exit(1)


if __name__ == "__main__":
    main()
