#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hyper-qr.cli
============
Command Line Interface and entry point.
"""

import sys
import argparse
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

# Import core logic
try:
    from .core import process_image
except ImportError:
    # Allow running directly for testing
    sys.path.append(str(Path(__file__).parent.parent))
    from palimpsest.core import process_image


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="hyper-qr",
        description="Hyper-Realistic QR Code Replacer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  hyper-qr -t bg.jpg -s new.png\n"
            "  hyper-qr -t bg.jpg -s new.png --noise 10.0 --content-blur 2.0\n"
        ),
    )

    parser.add_argument(
        "-t", "--target",
        required=False,
        help="Path to target image (background)",
    )
    parser.add_argument(
        "-s", "--source",
        required=False,
        help="Path to source image (new QR)",
    )
    parser.add_argument(
        "-o", "--output",
        default=None,
        help="Path to output image (default: derived from target filename)",
    )
    parser.add_argument(
        "-m", "--mode",
        choices=["seamless", "mixed", "soft", "overlay"],
        default="soft",
        help="Blending mode: soft (default), seamless, mixed, overlay",
    )
    parser.add_argument(
        "-p", "--padding",
        type=int,
        default=-2,
        help="Mask padding (negative to shrink), default -2",
    )
    parser.add_argument(
        "-b", "--blur",
        type=int,
        default=2,
        help="Mask blur radius (for soft/overlay), default 2",
    )
    parser.add_argument(
        "--no-inpaint",
        action="store_true",
        help="Disable intelligent inpainting",
    )
    parser.add_argument(
        "--inpaint-dilation",
        type=int,
        default=5,
        help="Inpainting mask dilation, default 5",
    )
    parser.add_argument(
        "--no-tone",
        action="store_true",
        help="Disable tone matching",
    )
    parser.add_argument(
        "--noise",
        type=float,
        default=0.0,
        help="Gaussian noise strength (0.0 to disable)",
    )
    parser.add_argument(
        "--content-blur",
        type=float,
        default=0.0,
        help="Content blur radius (0.0 to disable)",
    )
    return parser.parse_args()


def select_file_gui(title: str) -> str:
    """Open file dialog if no arguments provided."""
    try:
        import tkinter as tk
        from tkinter import filedialog
        
        root = tk.Tk()
        root.withdraw()
        
        path = filedialog.askopenfilename(
            title=title,
            filetypes=[("Images", "*.jpg *.jpeg *.png *.webp *.bmp")]
        )
        
        root.destroy()
        return path
    except ImportError:
        print("[Error] Tkinter not available for interactive mode.")
        return ""


def main() -> None:
    args = parse_args()
    
    # Interactive Mode
    if not args.target or not args.source:
        print("[Info] No arguments provided. Entering Interactive Mode...")
        try:
            if not args.target:
                print(">>> Select Background Image...")
                args.target = select_file_gui("Select Target (Background) Image")
                if not args.target:
                    print("No file selected. Exiting.")
                    return

            if not args.source:
                print(">>> Select New QR Image...")
                args.source = select_file_gui("Select Source (QR) Image")
                if not args.source:
                    print("No file selected. Exiting.")
                    return
        except Exception as e:
            print(f"[Error] Interactive mode failed: {e}")
            sys.exit(1)

    # Determine Output Path
    if args.output is None:
        target_path = Path(args.target)
        args.output = str(target_path.parent / f"{target_path.stem}_replaced{target_path.suffix}")

    # Booleans
    inpaint = not args.no_inpaint
    match_tone = not args.no_tone

    print("=" * 50)
    print("  Hyper-QR Replacer")
    print("=" * 50)
    print(f"  Target:   {args.target}")
    print(f"  Source:   {args.source}")
    print(f"  Output:   {args.output}")
    print(f"  Mode:     {args.mode}")
    print(f"  Inpaint:  {inpaint}")
    print(f"  Tone:     {match_tone}")
    print(f"  Noise:    {args.noise}")
    print("=" * 50)

    try:
        result = process_image(
            target_path=args.target,
            source_path=args.source,
            mode=args.mode,
            padding=args.padding,
            blur_radius=args.blur,
            inpaint=inpaint,
            inpaint_dilation=args.inpaint_dilation,
            match_tone=match_tone,
            noise=args.noise,
            content_blur=args.content_blur
        )
        
        if result is not None:
            # Save
            output_path = Path(args.output)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Compression params
            ext = output_path.suffix.lower()
            params = []
            if ext in (".jpg", ".jpeg"):
                params = [cv2.IMWRITE_JPEG_QUALITY, 98]
            elif ext == ".png":
                params = [cv2.IMWRITE_PNG_COMPRESSION, 3]
            
            success = cv2.imwrite(str(output_path), result, params)
            
            if success:
                print(f"[Success] Saved to: {output_path.resolve()}")
            else:
                print(f"[Error] Failed to save image.")
                sys.exit(1)
            
            # Pause if interactive
            if len(sys.argv) == 1:
                input("\nPress Enter to exit...")
        else:
            print("[Error] Image processing returned None.")
            if len(sys.argv) == 1:
                input("\nPress Enter to exit...")
            sys.exit(1)

    except Exception as e:
        print(f"\n[Fatal Error] {e}")
        import traceback
        traceback.print_exc()
        if len(sys.argv) == 1:
            input("\nPress Enter to exit...")
        sys.exit(1)


if __name__ == "__main__":
    main()
