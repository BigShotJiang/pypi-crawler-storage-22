#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hyper-qr.core
=============
Core logic for QR code detection, processing, and replacement.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

import cv2
import numpy as np
from pyzbar.pyzbar import decode, ZBarSymbol

# ───────────────────────── QR Detection Logic ─────────────────────────

def _order_points(pts: np.ndarray) -> np.ndarray:
    """
    Order points: [top-left, top-right, bottom-right, bottom-left].
    Required for perspective transform.
    """
    rect = np.zeros((4, 2), dtype=np.float32)

    # Top-left: min(x+y); Bottom-right: max(x+y)
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]
    rect[2] = pts[np.argmax(s)]

    # Top-right: min(y-x); Bottom-left: max(y-x)
    d = np.diff(pts, axis=1).ravel()
    rect[1] = pts[np.argmin(d)]
    rect[3] = pts[np.argmax(d)]

    return rect


def detect_qr_polygon(image: np.ndarray, label: str = "Image") -> np.ndarray:
    """
    Detect QR code using pyzbar with multiple preprocessing strategies.
    Returns ordered corner points (4, 2).
    """
    
    # Preprocessing strategies
    def to_gray(img): return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    def to_thresh(img): 
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        return cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
    def scale_up(img): return cv2.resize(img, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
    def scale_down(img): return cv2.resize(img, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)

    strategies = [
        (lambda x: x, "Original"),
        (to_gray, "Grayscale"),
        (to_thresh, "Adaptive Threshold"),
        (scale_up, "Scale 2x"),
        (scale_down, "Scale 0.5x"),
    ]

    for preprocess, desc in strategies:
        try:
            processed = preprocess(image)
            results = decode(processed, symbols=[ZBarSymbol.QRCODE])
            if results:
                # print(f"[Info] QR detected in {label} (Strategy: {desc})")
                
                qr = results[0]
                polygon = np.array([(p.x, p.y) for p in qr.polygon], dtype=np.float32)

                # Restore coordinates if scaled
                if desc == "Scale 2x":
                    polygon /= 2.0
                elif desc == "Scale 0.5x":
                    polygon *= 2.0

                if len(polygon) != 4:
                    # print(f"[Warn] {label} has {len(polygon)} corners, skipping strategy...")
                    continue

                ordered = _order_points(polygon)
                return ordered
        except Exception:
            # print(f"[Debug] Strategy {desc} failed: {e}")
            continue

    raise ValueError(f"No QR code detected in {label} after trying all strategies.")


# ───────────────────────── Image Processing Tools ─────────────────────────

def inpaint_qr(image: np.ndarray, dst_pts: np.ndarray, dilation: int = 5, radius: int = 3) -> np.ndarray:
    """
    Remove the original QR code using inpainting (Telea algorithm).
    """
    # 1. Create mask
    mask = np.zeros(image.shape[:2], dtype=np.uint8)
    hull = cv2.convexHull(dst_pts.astype(np.int32))
    cv2.fillConvexPoly(mask, hull, 255)
    
    # 2. Dilate mask
    if dilation > 0:
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (dilation*2+1, dilation*2+1))
        mask = cv2.dilate(mask, kernel, iterations=1)
        
    # 3. Inpaint
    inpainted = cv2.inpaint(image, mask, radius, cv2.INPAINT_TELEA)
    return inpainted


def build_convex_mask(warped: np.ndarray, dst_pts: np.ndarray) -> np.ndarray:
    """
    Build convex hull mask for blending.
    """
    mask = np.zeros(warped.shape[:2], dtype=np.uint8)
    hull = cv2.convexHull(dst_pts.astype(np.int32))
    cv2.fillConvexPoly(mask, hull, 255)
    return mask


def start_tone_matching(source: np.ndarray, target: np.ndarray, dst_pts: np.ndarray) -> np.ndarray:
    """
    Tone Matching: Map source QR colors to target QR area's darkest and brightest levels.
    """
    # 1. Extract target region
    mask = np.zeros(target.shape[:2], dtype=np.uint8)
    hull = cv2.convexHull(dst_pts.astype(np.int32))
    cv2.fillConvexPoly(mask, hull, 255)
    
    # Erode mask to avoid edge artifacts
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (10, 10))
    inner_mask = cv2.erode(mask, kernel, iterations=1)
    
    target_region = cv2.bitwise_and(target, target, mask=inner_mask)
    
    # 2. Analyze color distribution
    gray = cv2.cvtColor(target_region, cv2.COLOR_BGR2GRAY)
    valid_pixels = target_region[inner_mask == 255]
    valid_gray = gray[inner_mask == 255]
    
    if len(valid_gray) == 0:
        return source

    # K-Means clustering (2 classes: Black & White)
    from sklearn.cluster import MiniBatchKMeans
    
    if len(valid_pixels) > 1000:
        indices = np.random.choice(len(valid_pixels), 1000, replace=False)
        samples = valid_pixels[indices]
    else:
        samples = valid_pixels

    kmeans = MiniBatchKMeans(n_clusters=2, random_state=0, n_init=3).fit(samples)
    centers = kmeans.cluster_centers_  # shape (2, 3) BGR
    
    # Determine which center is brighter (White)
    lumas = np.dot(centers, [0.114, 0.587, 0.299])
    
    if lumas[0] > lumas[1]:
        target_white = centers[0]
        target_black = centers[1]
    else:
        target_white = centers[1]
        target_black = centers[0]
        
    # 3. Map colors
    source_float = source.astype(np.float32) / 255.0
    target_black_full = np.full_like(source_float, target_black)
    target_white_full = np.full_like(source_float, target_white)
    
    diff = target_white_full - target_black_full
    matched = target_black_full + source_float * diff
    
    return np.clip(matched, 0, 255).astype(np.uint8)


def add_gaussian_noise(image: np.ndarray, strength: float = 10.0) -> np.ndarray:
    """
    Add monochromatic Gaussian noise to simulate camera grain.
    """
    row, col, ch = image.shape
    mean = 0
    sigma = strength
    
    # Generate single-channel noise and repeat
    gauss = np.random.normal(mean, sigma, (row, col, 1))
    gauss = np.repeat(gauss, ch, axis=2)
    
    noisy = image.astype(np.float32) + gauss
    return np.clip(noisy, 0, 255).astype(np.uint8)


# ───────────────────────── Main Replacement Logic ─────────────────────────

def process_image(
    target_path: str, 
    source_path: str, 
    mode: str = "soft", 
    padding: int = -2, 
    blur_radius: int = 1, 
    inpaint: bool = True, 
    inpaint_dilation: int = 5, 
    match_tone: bool = True, 
    noise: float = 0.0, 
    content_blur: float = 0.0
) -> Optional[np.ndarray]:
    """
    Core function to process images and return the result as a numpy array.
    """
    # 1. Load Images
    target = cv2.imread(target_path, cv2.IMREAD_COLOR)
    source = cv2.imread(source_path, cv2.IMREAD_COLOR)

    if target is None:
        raise FileNotFoundError(f"Cannot load target image: {target_path}")
    if source is None:
        raise FileNotFoundError(f"Cannot load source image: {source_path}")

    # 2. Detect QR Corners
    try:
        dst_pts = detect_qr_polygon(target, "Target Image")
        src_pts = detect_qr_polygon(source, "Source Image")
    except ValueError as e:
        print(f"[Error] {e}")
        return None
    
    # 3. Inpainting (Background Clean-up)
    background_img = target
    if inpaint:
        try:
            background_img = inpaint_qr(target, dst_pts, dilation=inpaint_dilation)
        except Exception as e:
            print(f"[Warn] Inpainting failed: {e}")

    # 4. Process Source (Tone Match, Noise, Blur)
    processed_source = source.copy()
    
    if match_tone:
        try:
            processed_source = start_tone_matching(processed_source, target, dst_pts)
        except Exception as e:
            print(f"[Warn] Tone matching failed: {e}")
            
    if content_blur > 0:
        ksize = int(content_blur) * 2 + 1
        processed_source = cv2.GaussianBlur(processed_source, (ksize, ksize), 0)

    if noise > 0:
        processed_source = add_gaussian_noise(processed_source, strength=noise)

    # 5. Perspective Transform
    M = cv2.getPerspectiveTransform(src_pts, dst_pts)
    h_dst, w_dst = target.shape[:2]
    warped_source = cv2.warpPerspective(
        processed_source, M, (w_dst, h_dst),
        flags=cv2.INTER_LANCZOS4,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=(0, 0, 0),
    )

    # 6. Blending
    mask = build_convex_mask(warped_source, dst_pts)

    # 6a. Mask Adjustment (Padding)
    if padding != 0:
        if padding > 0:
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (padding*2+1, padding*2+1))
            mask = cv2.dilate(mask, kernel, iterations=1)
        else:
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (abs(padding)*2+1, abs(padding)*2+1))
            mask = cv2.erode(mask, kernel, iterations=1)

    # 6b. Soft Edges (Feathering)
    mask_float = mask.astype(np.float32) / 255.0
    
    if mode != "seamless" and mode != "mixed":
        if blur_radius > 0:
            ksize = int(blur_radius) * 2 + 1
            mask_float = cv2.GaussianBlur(mask_float, (ksize, ksize), 0)

    # 6c. Composition
    result = None
    
    if mode == "seamless" or mode == "mixed":
        # Poisson Blending
        mask_uint8 = (mask_float * 255).astype(np.uint8)
        moments = cv2.moments(mask_uint8)
        if moments["m00"] > 0:
            cx = int(moments["m10"] / moments["m00"])
            cy = int(moments["m01"] / moments["m00"])
            center = (cx, cy)
            try:
                clone_mode = cv2.NORMAL_CLONE if mode == "seamless" else cv2.MIXED_CLONE
                result = cv2.seamlessClone(warped_source, background_img, mask_uint8, center, clone_mode)
            except cv2.error:
                print(f"[Warn] Seamless cloning failed, falling back to soft blending.")
                mode = "soft"  # Fallback
        else:
            print("[Error] Mask area is zero.")
            mode = "soft" # Fallback

    if mode == "soft" or mode == "overlay":
        # Alpha Blending
        alpha = cv2.merge([mask_float, mask_float, mask_float])
        target_float = background_img.astype(np.float32)
        source_float = warped_source.astype(np.float32)
        blended = source_float * alpha + target_float * (1.0 - alpha)
        result = blended.astype(np.uint8)

    return result
