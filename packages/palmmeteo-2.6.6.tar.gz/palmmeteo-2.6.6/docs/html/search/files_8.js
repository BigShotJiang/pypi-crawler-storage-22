var searchData=
[
  ['plot_2epy_0',['plot.py',['../plot_8py.html',1,'']]],
  ['plugins_2epy_1',['plugins.py',['../plugins_8py.html',1,'']]]
];
