#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from . import __doc__, __version__, main
main()
