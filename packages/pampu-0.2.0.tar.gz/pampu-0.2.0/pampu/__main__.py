"""Allow running as python -m pampu."""

from pampu.cli import main

if __name__ == "__main__":
    main()
