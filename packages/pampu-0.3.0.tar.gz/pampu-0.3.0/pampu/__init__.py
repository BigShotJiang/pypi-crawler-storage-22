"""Pampu - CLI for Atlassian Bamboo."""

__version__ = "0.0.0.dev0"
