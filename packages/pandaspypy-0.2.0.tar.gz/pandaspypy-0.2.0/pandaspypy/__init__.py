from .practs import list_all, show
