from setuptools import setup, find_packages

setup(
    name="pandaspypy", 
    version="0.2.0", 
    author="hmm",
    description="something",
    packages=find_packages(),
    python_requires='>=3.6',
    entry_points={
        'console_scripts': [
            'pandaspypy=pandaspypy.practs:main',
        ],
    },
    package_data={
        "pandaspypy.practicals": ["*.py"],
    },
    install_requires=[],
)