# Imputation Utils

A small utility package to compare missing value imputation results in pandas.

## Installation

```bash
pip install panditor
