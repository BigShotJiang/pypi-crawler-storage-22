import pandas as pd
from io import StringIO

def basic_checker(df: pd.DataFrame):
    """
    Perform basic sanity checks on a pandas DataFrame.

    Returns:
        dict containing head, tail, describe output, and info summary.
    """

    # Capture info() output as string instead of printing
    buffer = StringIO()
    df.info(buf=buffer)

    return {
        "head": df.head(),
        "tail": df.tail(),
        "describe": df.describe(include="all"),
        "info": buffer.getvalue(),
        "shape": df.shape,
        "missing_values": df.isnull().sum()
    }