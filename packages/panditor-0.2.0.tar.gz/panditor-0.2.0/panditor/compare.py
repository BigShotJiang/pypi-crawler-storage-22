import pandas as pd

def compare_imputation(df_before, df_after, column_name):
    missing_indices = {
        col: df_before[df_before[col].isnull()].index.to_list()
        for col in df_before.columns
        if df_before[col].isnull().any()
    }

    if column_name not in missing_indices:
        print(f"No missing values were found in column '{column_name}'")
        return None

    idx_list = missing_indices[column_name]

    comparison = pd.DataFrame({
        "Before": df_before.loc[idx_list, column_name],
        "After": df_after.loc[idx_list, column_name],
    })

    print(f"Changes in column : {column_name}")
    return comparison
