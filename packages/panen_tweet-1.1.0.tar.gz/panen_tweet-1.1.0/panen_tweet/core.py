"""
Core functionality untuk scraping Twitter/X
"""
import time
import pandas as pd
from urllib.parse import quote
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException
from webdriver_manager.chrome import ChromeDriverManager
import datetime
import tempfile
import shutil
import requests
import os


class TwitterScraper:
    """Kelas utama untuk scraping Twitter/X"""

    def __init__(self, auth_token=None, scroll_pause_time=5, headless=True, chrome_binary_path=None):
        """
        Inisialisasi TwitterScraper

        Args:
            auth_token (str): Cookie auth_token untuk login
            scroll_pause_time (int): Waktu jeda antara scroll (dalam detik)
            headless (bool): Jalankan browser dalam mode headless
            chrome_binary_path (str): Lokasi file executable Chrome (opsional)
        """
        self.auth_token = auth_token
        self.scroll_pause_time = scroll_pause_time
        self.headless = headless
        self.chrome_binary_path = chrome_binary_path
        self.driver = None
        self.user_data_dir = None

    def setup_driver(self):
        """Menyiapkan instance WebDriver untuk Chrome"""
        print("Mencoba menyiapkan WebDriver...")
        chrome_options = Options()

        if self.chrome_binary_path:
            chrome_options.binary_location = self.chrome_binary_path
            print(f"Menggunakan binary Chrome kustom: {self.chrome_binary_path}")

        if self.headless:
            chrome_options.add_argument("--headless=new")

        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--window-size=1920,1080")
        chrome_options.add_argument("--log-level=3")
        chrome_options.add_argument(
            'user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
            'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        )

        try:
            service = Service(ChromeDriverManager().install())
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            print("WebDriver berhasil disiapkan.")
            return True
        except Exception as e:
            print("❌ Error saat menyiapkan WebDriver.")
            print(f"Detail error: {str(e)}")

            if "cannot find Chrome binary" in str(e):
                import platform
                if platform.system() == "Linux":
                    print("\n⚠️  DETEKSI LINUX/COLAB: Google Chrome belum terinstall!")
                    print("Silakan jalankan perintah berikut di terminal/sel Anda untuk menginstall:")
                    print("-" * 50)
                    print("!wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb")
                    print("!dpkg -i google-chrome-stable_current_amd64.deb")
                    print("!apt-get install -f -y")
                    print("-" * 50)
                    print("Setelah install, restart runtime/kernel Anda.")

            return False

    def login(self):
        """Login menggunakan cookie auth_token"""
        if not self.auth_token or self.auth_token == "cookie kalian":
            print("PERINGATAN: Cookie tidak diatur. Script mungkin akan terhadang halaman login.")
            return False

        print("Mengunjungi x.com untuk menyuntikkan cookie login...")
        self.driver.get("https://x.com")
        time.sleep(2)

        cookie = {'name': 'auth_token', 'value': self.auth_token, 'domain': '.x.com'}
        self.driver.add_cookie(cookie)
        print("Cookie berhasil disuntikkan.")
        return True

        return True

    def download_media(self, media_url, output_folder):
        """
        Download media dari URL ke folder tujuan
        """
        if not media_url:
            return None

        try:
            if not os.path.exists(output_folder):
                os.makedirs(output_folder)

            # Simple filename from URL
            filename = os.path.join(output_folder, os.path.basename(media_url.split('?')[0]))

            if os.path.exists(filename):
                return filename

            response = requests.get(media_url, stream=True, timeout=10)
            if response.status_code == 200:
                with open(filename, 'wb') as f:
                    for chunk in response.iter_content(1024):
                        f.write(chunk)
                return filename
        except Exception as e:
            print(f"Gagal mengunduh media {media_url}: {str(e)}")
            return None

    def scrape_tweets(self, query, target_count, search_type='top'):
        """
        Mengekstrak data tweet dari halaman pencarian

        Args:
            query (str): Query pencarian yang sudah di-encode
            target_count (int): Jumlah target tweet yang ingin diambil
            search_type (str): 'top' untuk tweet teratas, 'latest' untuk terbaru

        Returns:
            list: List dictionary berisi data tweet
        """
        # Membuat URL dasar
        search_url = f"https://x.com/search?q={query}&src=typed_query"
        if search_type == 'latest':
            search_url += "&f=live"

        print(f"Mengunjungi halaman pencarian: {search_url}")
        self.driver.get(search_url)

        try:
            WebDriverWait(self.driver, 20).until(
                EC.presence_of_element_located((By.XPATH, "//article[@data-testid='tweet']"))
            )
            print("Konten tweet terdeteksi. Memulai proses pengambilan data.")
        except TimeoutException:
            print("Batas waktu menunggu habis. Tidak ada tweet yang ditemukan untuk sesi ini.")
            print("Ini bisa terjadi jika tidak ada tweet pada rentang tanggal ini atau karena masalah jaringan.")
            return []

        # Scroll hingga target tercapai
        tweets_data = {}
        last_height = self.driver.execute_script("return document.body.scrollHeight")
        scroll_attempts = 0

        while len(tweets_data) < target_count:
            print(f"\nTweet terkumpul sesi ini: {len(tweets_data)}/{target_count}. Melakukan scroll...")

            tweet_articles = self.driver.find_elements(By.XPATH, "//article[@data-testid='tweet']")

            for tweet in tweet_articles:
                try:
                    # Menggunakan URL sebagai ID unik untuk menghindari duplikasi
                    tweet_url_elements = tweet.find_elements(By.XPATH, ".//a[contains(@href, '/status/')]")
                    tweet_url = tweet_url_elements[0].get_attribute('href') if tweet_url_elements else None

                    if tweet_url and tweet_url not in tweets_data:
                        username = tweet.find_element(By.XPATH, ".//div[@data-testid='User-Name']//span").text
                        handle = tweet.find_element(By.XPATH, ".//span[contains(text(), '@')]").text
                        timestamp = tweet.find_element(By.XPATH, ".//time").get_attribute('datetime')
                        tweet_text = tweet.find_element(By.XPATH, ".//div[@data-testid='tweetText']").text.replace('\n', ' ')
                        reply_count = tweet.find_element(By.XPATH, ".//button[@data-testid='reply']").text or "0"
                        retweet_count = tweet.find_element(By.XPATH, ".//button[@data-testid='retweet']").text or "0"
                        like_count = tweet.find_element(By.XPATH, ".//button[@data-testid='like']").text or "0"

                        tweets_data[tweet_url] = {
                            "username": username,
                            "handle": handle,
                            "timestamp": timestamp,
                            "tweet_text": tweet_text,
                            "url": tweet_url,
                            "reply_count": reply_count,
                            "retweet_count": retweet_count,
                            "like_count": like_count,
                            "media_urls": []
                        }

                        # Extract Media URLs (Images)
                        try:
                            media_elements = tweet.find_elements(By.XPATH, ".//div[@data-testid='tweetPhoto']//img")
                            for el in media_elements:
                                src = el.get_attribute('src')
                                if src and src not in tweets_data[tweet_url]["media_urls"]:
                                    tweets_data[tweet_url]["media_urls"].append(src)
                        except:
                            pass

                        # Extract Video Thumbnails (simple approach)
                        try:
                            video_elements = tweet.find_elements(By.XPATH, ".//div[@data-testid='videoPlayer']//video")
                            for el in video_elements:
                                poster = el.get_attribute('poster')
                                if poster and poster not in tweets_data[tweet_url]["media_urls"]:
                                    tweets_data[tweet_url]["media_urls"].append(poster)
                        except:
                            pass

                except Exception:
                    continue

            if len(tweets_data) >= target_count:
                print(f"Target {target_count} tweet untuk sesi ini telah tercapai.")
                break

            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(self.scroll_pause_time)

            new_height = self.driver.execute_script("return document.body.scrollHeight")
            if new_height == last_height:
                scroll_attempts += 1
                print("Sudah mencapai akhir halaman untuk sesi ini...")
                if scroll_attempts > 3:
                    print("Tidak ada tweet baru yang dimuat. Mengakhiri sesi ini.")
                    break
            else:
                scroll_attempts = 0
            last_height = new_height

        return list(tweets_data.values())[:target_count]

    def scrape_with_date_range(self, keyword, target_per_session, start_date, end_date,
                                interval_days, lang='id', search_type='top',
                                resume=False, output_filename='scraped_data.csv',
                                download_media=False, media_dir='media'):

        """
        Scraping tweet dengan rentang tanggal dan interval

        Args:
            keyword (str): Kata kunci pencarian
            target_per_session (int): Jumlah target tweet per sesi
            start_date (datetime): Tanggal mulai
            end_date (datetime): Tanggal selesai
            interval_days (int): Interval hari per sesi
            lang (str): Kode bahasa (misal: 'id', 'en')
            search_type (str): 'top' atau 'latest'

        Returns:
            pd.DataFrame: DataFrame berisi semua tweet yang berhasil diambil
        """
        if not self.setup_driver():
            return None

        try:
            self.login()

            self.login()

            all_scraped_data = []
            current_date = start_date

            # Auto-Resume Logic
            if resume and os.path.exists(output_filename):
                try:
                    print(f"Mengecek file existing untuk resume: {output_filename}")
                    df_existing = pd.read_csv(output_filename)
                    if not df_existing.empty and 'timestamp' in df_existing.columns:
                        # Convert to datetime to find max
                        df_existing['timestamp'] = pd.to_datetime(df_existing['timestamp'])
                        last_date_scraped = df_existing['timestamp'].max()

                        if pd.notna(last_date_scraped):
                            # Start from next day of last scraped date
                            next_start_date = last_date_scraped.date() + datetime.timedelta(days=1)
                            if next_start_date > current_date.date(): # Assuming start_date input is datetime
                                print(f"Resuming scraping dari tanggal: {next_start_date}")
                                # Adjust current_date to next_start_date (keeping time if needed, but usually 00:00)
                                current_date = datetime.datetime.combine(next_start_date, datetime.time.min)
                except Exception as e:
                    print(f"Gagal melakukan resume otomatis: {str(e)}")

            # Loop utama untuk scraping per interval
            try:
                while current_date <= end_date:
                    chunk_end_date = current_date + datetime.timedelta(days=interval_days)

                    since_str = current_date.strftime('%Y-%m-%d')
                    until_str = chunk_end_date.strftime('%Y-%m-%d')

                    print("\n" + "="*50)
                    print(f"--- MEMULAI SESI UNTUK TANGGAL: {since_str} hingga {until_str} ---")
                    print("="*50)

                    search_query_raw = f"{keyword} lang:{lang} until:{until_str} since:{since_str}"
                    search_query = quote(search_query_raw)

                    session_data = self.scrape_tweets(search_query, target_per_session, search_type)

                    if session_data:
                        all_scraped_data.extend(session_data)

                        # Incremental Save & Media Download
                        if output_filename:
                            df_session = pd.DataFrame(session_data)
                            # Convert list to string for CSV
                            if 'media_urls' in df_session.columns:
                                df_session['media_urls'] = df_session['media_urls'].apply(lambda x: ';'.join(x) if isinstance(x, list) else x)

                            header = not os.path.exists(output_filename)
                            # Determine mode: 'a' if appending, 'w' if new file
                            mode = 'a' if os.path.exists(output_filename) else 'w'

                            df_session.to_csv(output_filename, mode=mode, header=header, index=False, encoding='utf-8-sig')
                            print(f"Saved {len(session_data)} tweets to {output_filename} (Incremental)")

                        if download_media:
                            print(f"Downloading media for {len(session_data)} tweets...")
                            for tweet in session_data:
                                for url in tweet.get('media_urls', []):
                                    if url:
                                        self.download_media(url, media_dir)

                    print(f"\nSesi untuk {since_str} - {until_str} selesai.")
                    print(f"Total tweet terkumpul sejauh ini: {len(all_scraped_data)}")

                    current_date = chunk_end_date

                    if current_date <= end_date:
                        print("Memberi jeda 10 detik sebelum sesi berikutnya...")
                        time.sleep(10)
            except KeyboardInterrupt:
                print("\n\n⚠️  PROSES DIHENTIKAN OLEH PENGGUNA (CTRL+C)!")
                print("🛑 Menghentikan sisa antrian scraping...")
                print("💾 Memproses dan menyimpan data yang sudah terkumpul sejauh ini...")
                # Kita tidak raise error lagi, tapi membiarkan flow lanjut ke bawah
                # untuk menyimpan data yang ada di all_scraped_data

            # Proses setelah semua sesi selesai
            if not all_scraped_data:
                print("\nTidak ada data yang berhasil diambil dari seluruh sesi.")
                return None

            print("\n--- SEMUA SESI SELESAI ---")
            print("Menggabungkan dan membersihkan data duplikat...")

            df = pd.DataFrame(all_scraped_data)
            df.drop_duplicates(subset=['url'], inplace=True, keep='first')

            print(f"Total tweet unik yang berhasil diambil: {len(df)}")
            return df

        finally:
            self.quit()

    def quit(self):
        """Tutup browser dan bersihkan resource"""
        if self.driver:
            print("\nMenutup browser...")
            self.driver.quit()
        if self.user_data_dir:
            print(f"Membersihkan direktori sementara: {self.user_data_dir}")
            shutil.rmtree(self.user_data_dir, ignore_errors=True)

    def save_to_csv(self, df, filename):
        """
        Simpan DataFrame ke file CSV

        Args:
            df (pd.DataFrame): DataFrame yang akan disimpan
            filename (str): Nama file output
        """
        df.to_csv(filename, index=False, encoding='utf-8-sig')
        print(f"\nData telah disimpan di file: {filename}")
