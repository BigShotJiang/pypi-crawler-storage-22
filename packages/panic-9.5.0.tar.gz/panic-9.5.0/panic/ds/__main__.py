import sys
from .PyAlarm import main
main(sys.argv)
