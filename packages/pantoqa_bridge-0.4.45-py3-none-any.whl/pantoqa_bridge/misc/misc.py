from lxml import etree as ET
from lxml.etree import _Element

from pantoqa_bridge.server_synced_models.node_element import NodeElement


def find_element_by_coordinates(xml_content: str | ET._Element, x: int,
                                y: int) -> NodeElement | None:
  if not xml_content:
    return None

  xml_root = ET.fromstring(xml_content.encode('utf-8')) if isinstance(xml_content,
                                                                      str) else xml_content

  candidates: list[NodeElement] = []

  for node in xml_root.iter():
    if not isinstance(node, _Element):
      continue
    elem = NodeElement.from_xml_node(node)
    if not elem.bounds:
      continue
    x1, y1, x2, y2 = elem.parsed_bounds
    if x1 <= x <= x2 and y1 <= y <= y2:
      candidates.append(elem)

  if not candidates:
    return None

  candidates.sort(key=lambda e: e.get_area())
  return candidates[0]
