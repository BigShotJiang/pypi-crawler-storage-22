from fastapi import APIRouter
from pydantic import BaseModel

from pantoqa_bridge.logger import logger
from pantoqa_bridge.misc.misc import find_element_by_coordinates
from pantoqa_bridge.models.misc import Action
from pantoqa_bridge.utils.service_manager import get_adb_service

router = APIRouter()


class DirectActionRequestModel(BaseModel):
  action: Action
  device_serial_no: str | None = None


class StepContext(BaseModel):
  activity_name: str | None = None
  screenshot_path: str | None = None
  scaled_screenshot_path: str | None = None
  xml_dump_path: str | None = None


class BaseRecordedStep(BaseModel):
  context: StepContext | None = None
  result: str | None = None
  action_type: str | None = None


class SwipeCoord(BaseModel):
  x1: int
  y1: int
  x2: int
  y2: int


class RecordedSwipeStep(BaseRecordedStep):
  coord: SwipeCoord
  duration: int


class ElemData(BaseModel):
  resource_id: str | None = None
  text: str | None = None
  content_desc: str | None = None
  xpath: str | None = None


class Coord(BaseModel):
  x: int
  y: int


class RecordedClickStep(BaseRecordedStep):
  elem: ElemData | None = None
  coord: Coord | None = None


class DirectActionResponseModel(BaseModel):
  data: RecordedClickStep | RecordedSwipeStep


@router.post('/direct-action', response_model=DirectActionResponseModel)
async def perform_direct_action(request: DirectActionRequestModel):
  supported_actions = {"click", "swipe"}
  if request.action.action_type not in supported_actions:
    raise ValueError(f"Only supported actions are: {supported_actions}")

  srv_manager = get_adb_service(request.device_serial_no)

  # Perform the action
  if request.action.action_type == "click":
    assert request.action.params, "Params are required for click action."

    context = StepContext(
      activity_name=srv_manager.srv.get_current_app_activity(),
      xml_dump_path=None,
      screenshot_path=None,
      scaled_screenshot_path=None,
    )
    x = int(request.action.params['x'])
    y = int(request.action.params['y'])
    # Take XML dump before performing the action
    xml_dump = srv_manager.srv.get_ui_dump()
    matched_element = find_element_by_coordinates(xml_dump, x, y)
    result = srv_manager.srv.click(x, y)
    resource_id, unique_xpath = matched_element.get_unique_selectors() if matched_element else (
      None, None)

    elem_data = ElemData(
      resource_id=resource_id,
      text=matched_element.text if matched_element else None,
      content_desc=matched_element.content_desc if matched_element else None,
      xpath=unique_xpath,
    ) if matched_element else None

    recorded_data = RecordedClickStep(
      elem=elem_data,
      coord=Coord(x=x, y=y),
      result=result,
      context=context,
      action_type="click",
    )

    return DirectActionResponseModel(data=recorded_data)

  elif request.action.action_type == "swipe":
    assert request.action.params, "Params are required for swipe action."

    context = StepContext(
      activity_name=srv_manager.srv.get_current_app_activity(),
      xml_dump_path=None,
      screenshot_path=None,
      scaled_screenshot_path=None,
    )
    x1 = int(request.action.params['x1'])
    y1 = int(request.action.params['y1'])
    x2 = int(request.action.params['x2'])
    y2 = int(request.action.params['y2'])
    duration = int(request.action.params['duration'])
    logger.info(f"Swiping from ({x1}, {y1}) to ({x2}, {y2}) with duration {duration}ms")
    result = srv_manager.srv.swipe(x1, y1, x2, y2, duration=duration)
    recorded_swipe_data = RecordedSwipeStep(
      result=result,
      context=context,
      coord=SwipeCoord(x1=x1, y1=y1, x2=x2, y2=y2),
      duration=duration,
      action_type="swipe",
    )

    return DirectActionResponseModel(data=recorded_swipe_data)
  raise ValueError(f"Unhandled action type: {request.action.action_type}")
