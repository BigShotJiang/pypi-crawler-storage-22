import asyncio
import base64
from contextlib import asynccontextmanager
from io import BytesIO

from lxml import etree as ET
from lxml.etree import _Element
from PIL import Image

from pantoqa_bridge.server_synced_models.node_element import NodeElement
from pantoqa_bridge.utils.service_manager import get_adb_service


@asynccontextmanager
async def verify_change(
  device_serial_no: str | None,
  x: int,
  y: int,
  check_delay: float = 0.5,
  check_lens_size: int = 100,
  check_threshold: float = 10.0,
):
  srv_manager = get_adb_service(device_serial_no)

  # Capture screenshot before action
  ss_before_action_b64 = srv_manager.srv.take_screenshot()
  ss_before_action_img = Image.open(BytesIO(base64.b64decode(ss_before_action_b64)))

  async def is_changed() -> tuple[bool, str, str]:
    await asyncio.sleep(check_delay)
    ss_after_action_b64 = srv_manager.srv.take_screenshot()
    ss_after_action_img = Image.open(BytesIO(base64.b64decode(ss_after_action_b64)))
    ss_before_cropped = crop_rectangle_full_width(ss_before_action_img, y, size=check_lens_size)
    ss_after_cropped = crop_rectangle_full_width(ss_after_action_img, y, size=check_lens_size)

    return not is_similar_image(
      ss_before_cropped,
      ss_after_cropped,
      threshold=100.0 - check_threshold,
    ), ss_before_action_b64, ss_after_action_b64

  yield is_changed


def find_element_by_coordinates(xml_content: str | ET._Element, x: int,
                                y: int) -> NodeElement | None:
  if not xml_content:
    return None

  xml_root = ET.fromstring(xml_content.encode('utf-8')) if isinstance(xml_content,
                                                                      str) else xml_content

  candidates: list[NodeElement] = []

  for node in xml_root.iter():
    if not isinstance(node, _Element):
      continue
    elem = NodeElement.from_xml_node(node)
    if not elem.bounds:
      continue
    x1, y1, x2, y2 = elem.parsed_bounds
    if x1 <= x <= x2 and y1 <= y <= y2:
      candidates.append(elem)

  if not candidates:
    return None

  candidates.sort(key=lambda e: e.get_area())
  return candidates[0]


def is_similar_image(
  image1: Image.Image,
  image2: Image.Image,
  threshold: float,
) -> bool:
  if not (0 <= threshold <= 100):
    raise ValueError("threshold must be between 0 and 100.")
  import imagehash

  hash1 = imagehash.dhash(image1)
  hash2 = imagehash.dhash(image2)

  hash_diff = hash1 - hash2
  max_bits = hash1.hash.size  # usually 64 for dhash

  similarity_percent = (1 - (hash_diff / max_bits)) * 100

  return similarity_percent >= threshold


def crop_around(
  img: Image.Image,
  x: int,
  y: int,
  size: int = 100,
) -> Image.Image:
  left = max(x - size // 2, 0)
  upper = max(y - size // 2, 0)
  right = min(x + size // 2, img.width)
  lower = min(y + size // 2, img.height)
  cropped = img.crop((left, upper, right, lower))
  return cropped


def crop_rectangle_full_width(
  img: Image.Image,
  p: int,
  size: int = 100,
) -> Image.Image:
  left = 0
  upper = max(p - size // 2, 0)
  right = img.width
  lower = min(p + size // 2, img.height)
  cropped = img.crop((left, upper, right, lower))
  return cropped
