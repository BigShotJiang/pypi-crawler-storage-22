# don't modify this file
import re

from lxml import etree as ET
from pydantic import BaseModel


class BoxCoord(BaseModel):
  x1: int
  y1: int
  x2: int
  y2: int


def normalise_xml_dump(xml_dump: str) -> str | None:
  xml_root = ET.fromstring(xml_dump.encode('utf-8')) if xml_dump else None
  if xml_root is None:
    return None
  for node in xml_root.iter():
    class_attrib = node.attrib.get("class")
    if node.tag == "node" and class_attrib:
      try:
        node.tag = class_attrib
      except ValueError:
        node.tag = re.sub(r"[^a-zA-Z0-9_.-]", ".", class_attrib)
  normalise_xml_dump = ET.tostring(xml_root, encoding="unicode")
  return normalise_xml_dump
