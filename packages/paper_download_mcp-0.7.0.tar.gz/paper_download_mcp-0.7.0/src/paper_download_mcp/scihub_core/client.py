"""
Main Sci-Hub client providing high-level interface with multi-source support.
"""

import os
import re
import time
from html import unescape
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from .config.settings import settings
from .converters.pdf_to_md import PdfToMarkdownConverter
from .core.doi_processor import DOIProcessor
from .core.downloader import FileDownloader
from .core.file_manager import FileManager
from .core.mirror_manager import MirrorManager
from .core.parser import ContentParser
from .core.source_manager import SourceManager
from .models import DownloadProgress, DownloadResult, ProgressCallback
from .network.session import BasicSession
from .sources.arxiv_source import ArxivSource
from .sources.core_source import CORESource
from .sources.direct_pdf_source import DirectPDFSource
from .sources.html_landing_source import HTMLLandingSource
from .sources.pmc_source import PMCSource
from .sources.scihub_source import SciHubSource
from .sources.unpaywall_source import UnpaywallSource
from .utils.logging import get_logger
from .utils.retry import RetryConfig

logger = get_logger(__name__)


class SciHubClient:
    """Main client interface with multi-source support (Sci-Hub, Unpaywall, arXiv, CORE)."""

    def __init__(
        self,
        output_dir: str = None,
        mirrors: list[str] = None,
        timeout: int = None,
        retries: int = None,
        email: str = None,
        mirror_manager: MirrorManager = None,
        parser: ContentParser = None,
        file_manager: FileManager = None,
        downloader: FileDownloader = None,
        source_manager: SourceManager = None,
        convert_to_md: bool = False,
        md_output_dir: str | None = None,
        md_backend: str = "pymupdf4llm",
        md_strict: bool = True,
        md_overwrite: bool = False,
        md_converter: PdfToMarkdownConverter | None = None,
        trace_html: bool = False,
        trace_html_dir: str | None = None,
        trace_html_max_chars: int = 2_000_000,
    ):
        """Initialize client with optional dependency injection."""

        # Configuration
        self.output_dir = output_dir or settings.output_dir
        self.timeout = timeout or settings.timeout
        self.retry_config = RetryConfig(max_attempts=retries or settings.retries)
        self.email = email or settings.email

        self.convert_to_md = convert_to_md
        self.md_output_dir = md_output_dir
        self.md_backend = md_backend
        self.md_strict = md_strict
        self.md_overwrite = md_overwrite
        self.md_converter = md_converter
        self.trace_html = trace_html
        self.trace_html_dir = trace_html_dir
        self.trace_html_max_chars = trace_html_max_chars

        # Dependency injection with defaults
        self.mirror_manager = mirror_manager or MirrorManager(mirrors, self.timeout)
        self.parser = parser or ContentParser()
        self.file_manager = file_manager or FileManager(self.output_dir)
        self.downloader = downloader or FileDownloader(BasicSession(self.timeout))

        # DOI processor (stateless)
        self.doi_processor = DOIProcessor()

        # Multi-source support
        if source_manager is None:
            # Initialize paper sources
            sources = [
                SciHubSource(
                    mirror_manager=self.mirror_manager,
                    parser=self.parser,
                    doi_processor=self.doi_processor,
                    downloader=self.downloader,
                )
            ]

            # Direct URL sources: enable direct PDF and PMC handling for URL inputs
            sources.insert(0, HTMLLandingSource(downloader=self.downloader))
            sources.insert(0, PMCSource(downloader=self.downloader))
            sources.insert(0, DirectPDFSource())

            # arXiv: Free and open, always enabled (high priority for preprints)
            sources.insert(0, ArxivSource(timeout=self.timeout))

            # Only enable Unpaywall when email is provided
            if self.email:
                sources.insert(0, UnpaywallSource(email=self.email, timeout=self.timeout))

            # CORE does not require email, keep as OA fallback
            sources.append(CORESource(api_key=settings.core_api_key, timeout=self.timeout))

            self.source_manager = SourceManager(
                sources=sources,
                year_threshold=settings.year_threshold,
                enable_year_routing=settings.enable_year_routing,
            )
        else:
            self.source_manager = source_manager

    def download_paper(
        self, identifier: str, progress_callback: ProgressCallback | None = None
    ) -> DownloadResult:
        """
        Download a paper given its DOI or URL.

        Uses fine-grained retry at lower layers (download, API calls).
        No coarse-grained retry at this level.
        """
        doi = self.doi_processor.normalize_doi(identifier)
        logger.info(f"Downloading paper: {doi}")

        return self._download_single_paper(
            identifier=identifier, normalized_identifier=doi, progress_callback=progress_callback
        )

    def _download_single_paper(
        self,
        identifier: str,
        normalized_identifier: str,
        progress_callback: ProgressCallback | None = None,
    ) -> DownloadResult:
        """
        Single download attempt using multi-source manager.

        Gets URL and metadata in one pass to avoid duplicate API calls.
        """
        start_time = time.time()
        html_events: list[dict[str, Any]] = []

        def _build_result(
            *,
            success: bool,
            file_path: str | None = None,
            file_size: int | None = None,
            metadata: dict | None = None,
            source: str | None = None,
            download_url: str | None = None,
            error: str | None = None,
            md_path: str | None = None,
            md_success: bool | None = None,
            md_error: str | None = None,
            source_attempts: list[dict[str, Any]] | None = None,
            html_snapshots: list[dict[str, Any]] | None = None,
        ) -> DownloadResult:
            title = metadata.get("title") if isinstance(metadata, dict) else None
            year = metadata.get("year") if isinstance(metadata, dict) else None
            return DownloadResult(
                identifier=identifier,
                normalized_identifier=normalized_identifier,
                success=success,
                file_path=file_path,
                file_size=file_size,
                source=source,
                metadata=metadata,
                title=title,
                year=year,
                download_url=download_url,
                download_time=time.time() - start_time,
                error=error,
                md_path=md_path,
                md_success=md_success,
                md_error=md_error,
                source_attempts=source_attempts,
                html_snapshots=html_snapshots,
            )

        def _collect_html_snapshot(snapshot: dict[str, Any]) -> None:
            if self.trace_html:
                html_events.append(dict(snapshot))

        source_attempts: list[dict[str, Any]]
        # Get PDF URL and metadata together (avoids duplicate API calls)
        if hasattr(self.source_manager, "get_pdf_url_with_metadata_and_trace"):
            download_url, metadata, source, source_attempts = (
                self.source_manager.get_pdf_url_with_metadata_and_trace(
                    normalized_identifier,
                    html_snapshot_callback=_collect_html_snapshot if self.trace_html else None,
                )
            )
        else:
            download_url, metadata, source = self.source_manager.get_pdf_url_with_metadata(
                normalized_identifier
            )
            source_attempts = []

        if not download_url:
            error = f"Could not find PDF URL for {normalized_identifier} from any source"
            logger.error(error)
            return _build_result(
                success=False,
                metadata=metadata,
                source=source,
                error=error,
                source_attempts=source_attempts,
                html_snapshots=self._persist_html_snapshots(identifier, html_events),
            )

        download_candidates = self._collect_download_candidates(
            primary_url=download_url,
            source=source,
            metadata=metadata,
        )
        if not download_candidates:
            error = f"No valid download URL candidates for {normalized_identifier}"
            logger.error(error)
            return _build_result(
                success=False,
                metadata=metadata,
                source=source,
                download_url=download_url,
                error=error,
                source_attempts=source_attempts,
                html_snapshots=self._persist_html_snapshots(identifier, html_events),
            )
        logger.debug(f"Download URL candidates ({len(download_candidates)}): {download_candidates}")

        # Generate filename from metadata if available
        filename = self._generate_filename(normalized_identifier, metadata)
        output_path = self.file_manager.get_output_path(filename)

        progress_state = {"bytes": 0, "total": None}
        active_download_url = {"url": download_candidates[0]}

        def _handle_progress(bytes_downloaded: int, total_bytes: int | None) -> None:
            progress_state["bytes"] = bytes_downloaded
            progress_state["total"] = total_bytes
            if progress_callback:
                progress_callback(
                    DownloadProgress(
                        identifier=identifier,
                        url=active_download_url["url"],
                        bytes_downloaded=bytes_downloaded,
                        total_bytes=total_bytes,
                        done=False,
                    )
                )

        # Download the PDF (with automatic retry at download layer)
        success = False
        error_msg: str | None = None
        attempted_errors: list[tuple[str, str]] = []

        for index, candidate_url in enumerate(download_candidates, start=1):
            active_download_url["url"] = candidate_url
            logger.info(
                f"Downloading via candidate URL ({index}/{len(download_candidates)}): {candidate_url}"
            )
            push_trace = getattr(self.downloader, "push_trace_context", None)
            clear_trace = getattr(self.downloader, "clear_trace_context", None)
            use_download_trace = self.trace_html and callable(push_trace) and callable(clear_trace)

            if use_download_trace:
                push_trace(
                    {
                        "identifier": normalized_identifier,
                        "source": source or "unknown_source",
                        "phase": "download",
                        "candidate_index": index,
                        "candidate_total": len(download_candidates),
                    },
                    html_snapshot_callback=_collect_html_snapshot,
                )
            try:
                success, error_msg = self.downloader.download_file(
                    candidate_url,
                    output_path,
                    progress_callback=_handle_progress if progress_callback else None,
                )
            finally:
                if use_download_trace:
                    clear_trace()
            if success:
                if self.file_manager.validate_file(output_path):
                    download_url = candidate_url
                    break

                error_msg = "Downloaded file validation failed"
                logger.error(error_msg)
                if os.path.exists(output_path):
                    os.unlink(output_path)
                success = False

            if "sci-hub" in candidate_url.lower():
                logger.warning("Sci-Hub download failed, invalidating mirror cache")
                scihub = [s for s in self.source_manager.sources.values() if s.name == "Sci-Hub"]
                if scihub:
                    scihub[0].mirror_manager.invalidate_cache()

            attempted_errors.append((candidate_url, error_msg or "Download failed"))

        if progress_callback:
            progress_callback(
                DownloadProgress(
                    identifier=identifier,
                    url=active_download_url["url"],
                    bytes_downloaded=progress_state["bytes"],
                    total_bytes=progress_state["total"],
                    done=True,
                )
            )
        if not success:
            error_msg = error_msg or "Download failed"
            if len(attempted_errors) > 1:
                details = "; ".join(f"{url} => {reason}" for url, reason in attempted_errors)
                error_msg = f"{error_msg}. Tried {len(attempted_errors)} candidate URLs: {details}"
            logger.error(f"Failed to download {normalized_identifier}: {error_msg}")
            return _build_result(
                success=False,
                metadata=metadata,
                source=source,
                download_url=active_download_url["url"],
                error=error_msg,
                source_attempts=source_attempts,
                html_snapshots=self._persist_html_snapshots(identifier, html_events),
            )

        md_path: str | None = None
        md_success: bool | None = None
        md_error: str | None = None
        if self.convert_to_md:
            try:
                md_path, md_success, md_error = self._convert_pdf_to_markdown(output_path)
            except Exception as e:
                md_success = False
                md_error = str(e)

        file_size = os.path.getsize(output_path)
        logger.info(f"Successfully downloaded {normalized_identifier} ({file_size} bytes)")
        return _build_result(
            success=True,
            file_path=output_path,
            file_size=file_size,
            metadata=metadata,
            source=source,
            download_url=download_url,
            md_path=md_path,
            md_success=md_success,
            md_error=md_error,
            source_attempts=source_attempts,
        )

    def _persist_html_snapshots(
        self, identifier: str, snapshots: list[dict[str, Any]]
    ) -> list[dict[str, Any]] | None:
        """
        Persist captured HTML snapshots to disk and return metadata records.

        Snapshots are only persisted when trace_html is enabled.
        """
        if not self.trace_html or not snapshots:
            return None

        base_dir = (
            Path(self.trace_html_dir)
            if self.trace_html_dir
            else Path(self.output_dir) / "trace-html"
        )
        identifier_dir = base_dir / self._safe_trace_token(identifier)
        identifier_dir.mkdir(parents=True, exist_ok=True)

        saved_records: list[dict[str, Any]] = []
        for index, snapshot in enumerate(snapshots, start=1):
            record = {k: v for k, v in snapshot.items() if k != "html"}

            raw_html = snapshot.get("html")
            html_text = raw_html if isinstance(raw_html, str) else None
            record["html_chars"] = len(html_text) if html_text is not None else 0

            status_part = str(
                snapshot.get("status_code") if snapshot.get("status_code") is not None else "na"
            )
            source_part = self._safe_trace_token(str(snapshot.get("source") or "unknown_source"))
            fetcher_part = self._safe_trace_token(str(snapshot.get("fetcher") or "requests"))

            if not html_text:
                record["file_path"] = None
                saved_records.append(record)
                continue

            truncated = False
            if len(html_text) > self.trace_html_max_chars:
                html_text = html_text[: self.trace_html_max_chars]
                truncated = True

            record["truncated"] = truncated
            target = identifier_dir / f"{index:03d}_{source_part}_{fetcher_part}_{status_part}.html"
            try:
                target.write_text(html_text, encoding="utf-8", errors="ignore")
                record["file_path"] = str(target)
            except Exception as e:
                record["file_path"] = None
                record["snapshot_error"] = str(e)

            saved_records.append(record)

        return saved_records

    @staticmethod
    def _safe_trace_token(value: str) -> str:
        cleaned = re.sub(r"[^a-zA-Z0-9._-]+", "_", value).strip("._-")
        if not cleaned:
            return "unknown"
        return cleaned[:120]

    def _collect_download_candidates(
        self,
        *,
        primary_url: str,
        source: str | None,
        metadata: dict[str, Any] | None,
    ) -> list[str]:
        """
        Collect candidate URLs for final file download.

        For CORE results, try additional metadata URLs when the primary URL fails.
        """
        seen: set[str] = set()
        candidates: list[str] = []

        def _add(candidate: Any) -> None:
            if not isinstance(candidate, str):
                return
            cleaned = self._normalize_download_candidate(candidate)
            if not cleaned or cleaned in seen:
                return
            seen.add(cleaned)
            candidates.append(cleaned)

        _add(primary_url)
        if isinstance(metadata, dict):
            _add(metadata.get("pdf_url"))

        if source == "CORE" and isinstance(metadata, dict):
            for key in ("source_fulltext_urls", "links_download_urls"):
                values = metadata.get(key)
                if isinstance(values, list):
                    for value in values:
                        _add(value)
            links = metadata.get("links")
            if isinstance(links, list):
                for item in links:
                    if not isinstance(item, dict):
                        continue
                    if str(item.get("type", "")).lower() != "download":
                        continue
                    _add(item.get("url"))
            _add(metadata.get("core_download_url"))

        return candidates

    @staticmethod
    def _normalize_download_candidate(candidate: str) -> str | None:
        cleaned = unescape(candidate.strip())
        if not cleaned:
            return None
        parsed = urlparse(cleaned)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            return None
        return cleaned

    def _convert_pdf_to_markdown(self, pdf_path: str) -> tuple[str | None, bool | None, str | None]:
        from .converters.pdf_to_md import MarkdownConvertOptions

        pdf = Path(pdf_path)
        output_dir = Path(self.md_output_dir) if self.md_output_dir else pdf.parent / "md"
        md_path = output_dir / f"{pdf.stem}.md"
        output_dir.mkdir(parents=True, exist_ok=True)

        if md_path.exists() and not self.md_overwrite:
            return str(md_path), True, None

        backend = (self.md_backend or "pymupdf4llm").lower().strip()
        converter = self.md_converter
        if converter is None:
            if backend != "pymupdf4llm":
                return str(md_path), False, f"Unsupported markdown backend: {self.md_backend}"
            from .converters.pymupdf4llm_converter import Pymupdf4llmConverter

            converter = Pymupdf4llmConverter()

        ok, error = converter.convert(
            str(pdf),
            str(md_path),
            options=MarkdownConvertOptions(overwrite=self.md_overwrite),
        )
        if not ok:
            return str(md_path), False, error or "Markdown conversion failed"
        return str(md_path), True, None

    def _generate_filename(self, doi: str, metadata: dict | None) -> str:
        """
        Generate filename from metadata or DOI.

        Args:
            doi: The DOI
            metadata: Optional metadata dict from source

        Returns:
            Generated filename
        """
        if metadata and metadata.get("title"):
            try:
                from .metadata_utils import generate_filename_from_metadata

                return generate_filename_from_metadata(
                    metadata.get("title", ""), metadata.get("year", ""), doi
                )
            except Exception as e:
                logger.debug(f"Could not generate filename from metadata: {e}")

        # If the identifier is a URL (e.g., direct PDF link), use URL-based naming.
        parsed = urlparse(doi)
        if parsed.scheme in {"http", "https"} and parsed.netloc:
            return self.file_manager.generate_filename_from_url(doi)

        # Fallback to DOI-based filename
        return self.file_manager.generate_filename(doi, html_content=None)

    def download_from_file(
        self,
        input_file: str,
        parallel: int = None,
        progress_callback: ProgressCallback | None = None,
    ) -> list[DownloadResult]:
        """Download papers from a file containing DOIs or URLs."""
        parallel = parallel or settings.parallel
        parallel = max(1, parallel)

        # Read input file
        try:
            with open(input_file, encoding="utf-8") as f:
                lines = f.readlines()
        except Exception as e:
            logger.error(f"Error reading input file: {e}")
            return []

        # Filter out comments and empty lines
        identifiers = [
            line.strip() for line in lines if line.strip() and not line.strip().startswith("#")
        ]

        logger.info(f"Found {len(identifiers)} papers to download")

        if parallel == 1 or len(identifiers) <= 1:
            results = []
            for i, identifier in enumerate(identifiers):
                logger.info(f"Processing {i + 1}/{len(identifiers)}: {identifier}")
                result = self.download_paper(identifier, progress_callback=progress_callback)
                results.append(result)

                # Add a small delay between sequential downloads
                if i < len(identifiers) - 1:
                    time.sleep(2)
        else:
            from concurrent.futures import ThreadPoolExecutor, as_completed

            results: list[DownloadResult | None] = [None] * len(identifiers)
            workers = min(parallel, len(identifiers))
            logger.info(f"Downloading {len(identifiers)} papers with {workers} workers")

            def _download_one(index: int, identifier: str) -> tuple[int, DownloadResult]:
                return index, self.download_paper(identifier, progress_callback=progress_callback)

            with ThreadPoolExecutor(max_workers=workers) as executor:
                future_to_index = {
                    executor.submit(_download_one, index, identifier): index
                    for index, identifier in enumerate(identifiers)
                }
                for future in as_completed(future_to_index):
                    index, result = future.result()
                    results[index] = result

            results = [result for result in results if result is not None]

        successful = sum(1 for result in results if result.success)
        logger.info(f"Downloaded {successful}/{len(identifiers)} papers")

        return results
