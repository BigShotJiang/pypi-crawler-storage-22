# Core module initialization
