"""CLI commands."""

from paperctl.cli.main import app

__all__ = ["app"]
