from .paper import Paper, PaperResult  # noqa
from .researcher import Researcher, ResearcherResult  # noqa
