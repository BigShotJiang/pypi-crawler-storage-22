"""
Folder for the metadata dumps from biorxiv, medrxiv and chemrxiv API.
No code here but will be populated with your local `.jsonl` files.
"""
