import typing

import requests


class CaaSPart:
    """
    Creates a CaaS "connection"
    """
    def __caas_base_url(self) -> str:
        host = self.part_get_env("PART_CAAS_HOST", "localhost")
        port = int(self.part_get_env("PART_CAAS_PORT", "8000"))
        return f"http://{host}:{port}"

    def __caas_headers(self) -> dict:
        api_key = self.part_get_env("PART_CAAS_API_KEY", "")
        return {"Authorization": f"Bearer {api_key}"}

    #region make request method
    def __make_request(
        self,
        req_type: str,
        url: str,
        params: typing.Optional[typing.Dict[str, typing.Any]],
    ) -> typing.Dict[str, typing.Any]:
        """
        Centralized internal method for making requests
        """
        if req_type not in ['get', 'post', 'delete']:
            raise ValueError('Unknown req_type: {}'.format(str(req_type)))

        res = None
        try:
            if req_type == 'get':
                res = requests.get(url, headers=self.__caas_headers(), params=params)
            if req_type == 'post':
                res = requests.post(url, headers=self.__caas_headers(), params=params)
            if req_type == 'delete':
                res = requests.delete(url, headers=self.__caas_headers(), params=params)
            res.raise_for_status()
            return res.json()
        except:
            print(res.status_code)
            print(res.text)
            raise

    #endregion

    #region session
    def caas_create_session(
        self,
        session_params: typing.Dict[str, typing.Any],
    ) -> typing.Dict[str, typing.Any]:
        """
        Creates a session in the CaaS server
        ##### Parameters
        - session_params: the parameters to create the session with (CaasCreateSession)
        """
        full_url = self.__caas_base_url() + '/create_session'
        data = self.__make_request('post', full_url, session_params)
        return data

    def caas_delete_session(self, session_id: typing.Union[str, int]) -> None:
        """
        Deletes a session from the CaaS server
        ##### Parameters
        - session_id: The id of the session to delete
        """
        full_url = self.__caas_base_url() + '/delete_session'
        params = {
            'session_id': session_id
        }
        self.__make_request('delete', full_url, params)
    #endregion

    #region profile
    def caas_create_profile(
        self,
        profile_Id: typing.Union[str, int],
    ) -> typing.Dict[str, typing.Any]:
        """
        Creates a profile on the CaaS server
        ##### Parameters
        - profile_id: The id of the profile to create
        """
        full_url = self.__caas_base_url() + '/create_profile'
        params = {
            'profile_id': profile_Id
        }
        data = self.__make_request('post', full_url, params)
        return data
    
    def caas_get_profile(
        self,
        profile_id: typing.Union[str, int],
    ) -> typing.Dict[str, typing.Any]:
        """
        Gets a profile from the CaaS server
        ##### Parameters
        - profile_id: The id of the profile to get
        """
        full_url = self.__caas_base_url() + '/get_profile'
        params = {
            'profile_id': profile_id
        }
        data = self.__make_request('get', full_url, params)
        return data

    def caas_delete_profile(self, profile_id: typing.Union[str, int]) -> None:
        """
        Deletes a profile from the CaaS server
        ##### Parameters
        - profile_id: The id of the profile to delete
        """
        full_url = self.__caas_base_url() + '/delete_profile'
        params = {
            'profile_id': profile_id
        }
        self.__make_request('delete', full_url, params)
    #endregion


