import base64
import re
import typing

import requests
import capsolver

if typing.TYPE_CHECKING:
    from part.part_class import Part


class CapsolverPlaywrightSyncPart:
    """
    This part utilizes JS/evals, it's the only way to batch commands like typing and clicking.
    Each Playwright CDP call has a few hundred millisecond roundtrip.
    This part does a lot of checks clicks etc; which add up really quick.
    The result: from 90-150 seconds per solve down to 15-20.
    This has the added benefit of being way more stable.
    Using JS batching is not recommended however due to it being a pain to debug.
    """
    #region browser methods
    def __get_element_text(
        self: "Part",
        selector: str,
        iframe: int = 2,
    ) -> typing.Optional[str]:
        if iframe == 1:
            _iframe = self.__iframe1
        else:
            _iframe = self.__iframe2
        return _iframe.text_content(
            selector=selector,
            timeout=1000
            )
    #endregion


    #region captcha methods
    def __wait_for_new_images(self: "Part") -> None:
        self.__iframe2.evaluate("""
            () => new Promise(resolve => {
                const unselected = document.querySelectorAll('td.rc-imageselect-tile:not(.rc-imageselect-tileselected) img');
                const selected = document.querySelectorAll('td.rc-imageselect-tile.rc-imageselect-tileselected img');
                const all = [...unselected, ...selected];
                if (all.length === 0) { resolve(); return; }
                let done = 0;
                const check = () => { if (++done === all.length) resolve(); };
                all.forEach(img => {
                    if (img.complete && img.naturalWidth > 0) check();
                    else {
                        img.onload = check;
                        img.onerror = check;
                        setTimeout(check, 5000);
                    }
                });
            })
        """)

    def __get_challenge_data(self: "Part") -> typing.Dict[str, typing.Any]:
        #question related
        questions_dict = {
            "taxis": "/m/0pg52",
            "bus": "/m/01bjv",
            "buses": "/m/01bjv",
            "school bus": "/m/02yvhj",
            "motorcycles": "/m/04_sv",
            "tractors": "/m/013xlm",
            "chimneys": "/m/01jk_4",
            "crosswalks": "/m/014xcs",
            "traffic lights": "/m/015qff",
            "bicycles": "/m/0199g",
            "parking meters": "/m/015qbp",
            "cars": "/m/0k4j",
            "bridges": "/m/015kr",
            "boats": "/m/019jd",
            "palm trees": "/m/0cdl1",
            "mountains or hills": "/m/09d_r",
            "fire hydrants": "/m/01pns0",
            "a fire hydrant": "/m/01pns0",
            "stairs": "/m/01lynh"
        }
        question = self.__get_element_text('//div[contains(@class,"rc-imageselect-desc")]/strong')
        if not question:
            raise Exception('Question did not scrape properly')
        
        #continious or not
        continious_text = self.__get_element_text('//div[contains(@class,"rc-imageselect-desc")]/span')
        if continious_text in [
            'Click verify once there are none left',
            'Click verify once there are none left.'
        ]:
            continious = True
        elif continious_text in [
            'If there are none, click skip',
            None
        ]:
            continious = False
        else:
            print('"' + continious_text + '"')
            raise Exception('unknown continious text')

        #wait for images (single evaluate: poll until 9 or 16 tile images, max 10s)
        wait_result = self.__iframe2.evaluate("""
            () => new Promise((resolve) => {
                const maxTries = 1000;
                const intervalMs = 10;
                let tries = 0;
                const check = () => {
                    const count = document.querySelectorAll('td.rc-imageselect-tile img').length;
                    if (count === 9 || count === 16) {
                        resolve({ count, done: true });
                        return;
                    }
                    tries++;
                    if (tries > maxTries) {
                        resolve({ count, done: false });
                        return;
                    }
                    setTimeout(check, intervalMs);
                };
                check();
            })
        """)
        if not wait_result['done']:
            raise Exception('unknown amount of tile images {}'.format(wait_result['count']))
        tile_count = wait_result['count']

        #get tiles data
        tiles = self.__iframe2.evaluate("""
            () => {
                const imgs = document.querySelectorAll('td.rc-imageselect-tile img');
                return Array.from(imgs).map(img => {
                    const width = img.getBoundingClientRect().width;
                    const src = img.getAttribute('src');
                    return { src, big: width >= 300 };
                });
            }
        """)
        obj = {
            'question': questions_dict[question],
            'tiles': tiles,
            'grid_size': 3 if tile_count == 9 else 4,
            'continious': continious
        }
        return obj

    def __process_challenge_normal(
        self: "Part",
        challenge_data: typing.Dict[str, typing.Any],
    ) -> None:
        #data
        question = challenge_data.get('question')
        tiles = challenge_data.get('tiles')

        if len(tiles) not in [9, 16]:
            raise Exception('not 9 or 16 images: {}'.format(len(tiles)))

        #find big image
        url = None
        for tile in tiles:
            if tile['big']:
                url = tile['src']
                break
        if not url:
            raise Exception('no big url found')
        res = requests.get(url, timeout=30)
        res.raise_for_status()
        encoded_image = base64.b64encode(res.content).decode("ascii")

        #solve
        solution = capsolver.solve({
            'type':'ReCaptchaV2Classification',
            'image': encoded_image,
            'question': question
        })

        #click the images
        self.__click_images(solution, submit=True)

    def __process_challenge_continious(
        self: "Part",
        challenge_data: typing.Dict[str, typing.Any],
    ) -> typing.Dict[str, typing.Any]:
        #data
        question = challenge_data.get('question')
        tiles = challenge_data.get('tiles')

        if len(tiles) not in [9, 16]:
            raise Exception('not 9 or 16 images: {}'.format(len(tiles)))

        #check the state of continious captcha, if it has only big images its 1st stage
        #if it has atleast 1 small image its at later stage
        big_image = None
        small_image = None
        for t in tiles:
            if t['big']:
                big_image = t['src']
            else:
                small_image = t['src']

        if big_image is None:
            raise Exception('critical error, no big image')

        #there are small images, we need to send them one by one
        #we 
        if small_image:
            #get all small images
            new_solution = {}
            new_solution['objects'] = []
            for i, t in enumerate(tiles):
                if not t['big']:
                    #download image
                    res = requests.get(t['src'], timeout=30)
                    res.raise_for_status()
                    encoded_image = base64.b64encode(res.content).decode("ascii")
                    #solve
                    solution = capsolver.solve({
                        'type':'ReCaptchaV2Classification',
                        'image': encoded_image,
                        'question': question
                    })
                    if solution['hasObject']:
                        new_solution['objects'].append(i)
            solution = new_solution

        #only big image - make single request
        else:
            res = requests.get(big_image, timeout=30)
            res.raise_for_status()
            encoded_image = base64.b64encode(res.content).decode("ascii")

            solution = capsolver.solve({
                'type':'ReCaptchaV2Classification',
                'image': encoded_image,
                'question': question
            })
            
        #click the images
        self.__click_images(solution)
        return solution

    def __click_images(
        self: "Part",
        click_data: typing.Dict[str, typing.Any],
        submit: bool = False,
    ) -> None:
        indexes = click_data.get('objects')
        if not indexes:
            self.__iframe2.evaluate("""
                () => { document.querySelector('button#recaptcha-verify-button').click(); }
            """)
            self.wait(1)
            return

        self.__iframe2.evaluate("""
            (args) => {
                const { indexes, submit } = args;
                const delayMs = 100;
                return indexes.reduce((p, i) => p.then(() => {
                    const el = document.querySelector('td.rc-imageselect-tile[id="' + i + '"]');
                    if (el) el.click();
                    return new Promise(r => setTimeout(r, delayMs));
                }), Promise.resolve()).then(() => {
                    if (submit) {
                        const btn = document.querySelector('button#recaptcha-verify-button');
                        if (btn) btn.click();
                    }
                });
            }
        """, {'indexes': indexes, 'submit': submit})
    #endregion
        

    #region automatic handler
    def capsolver_pw_v2_invisible_handler(
        self: "Part",
        success_xpath: str,
        suppress_detached: bool,
        *_: typing.Any,
        **__: typing.Any,
    ) -> typing.Callable[..., typing.Any]:
        """
        Playwright handler that will handle invisible recaptcha v2
        First read how Playwright add_locator_handler works

        ##### Parameters
        - success_xpath: If this exists it means captcha was solved successfuly
        - suppress_detached: It will suppress "Frame was detached" error which means captcha was hidden which means it was solved
        """
        api_key = self.part_require_env("PART_CAPSOLVER_API_KEY")

        def handler(*args: typing.Any, **kwargs: typing.Any) -> None:
            capsolver.api_key = api_key
            minor_loop_i = 0
            minor_loop_tries = 15
            self.__iframe2 = self.pw_page.frame(url=re.compile("/recaptcha/api2/bframe"))
            while True:
                try:
                    #check
                    if self.playwright_sync_element_exists(selector=success_xpath, wait=True, timeout=1000):
                        return
                    #wait for lazy load images
                    self.__wait_for_new_images()
                    #scrape challange and get data
                    challenge = self.__get_challenge_data()
                    #decide which type it is and solve accordingly
                    if challenge['continious']:
                        self.__process_challenge_continious(challenge)
                    else:
                        self.__process_challenge_normal(challenge)
                    minor_loop_i += 1
                    if minor_loop_i > minor_loop_tries:
                        raise Exception('Unable to solve captcha after minor retries > {}'.format(minor_loop_tries))
                except Exception as e:
                    if  'Frame was detached' in str(e) or \
                        'Target page, context or browser has been closed' in str(e):
                        if suppress_detached:
                            return
                        else:
                            raise CapsolverPlaywrightSyncPartError('Frame was detached/Page was closed')
                    elif 'ms exceeded.' in str(e): # ex. Frame.text_content: Timeout 30000ms exceeded.
                        pass
                    else:
                        raise e
        
        return handler
    #endregion


class CapsolverPlaywrightSyncPartError(Exception):
    pass

