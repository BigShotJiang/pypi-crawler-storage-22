import email
import imaplib
import ssl
import time
import typing

class EmailPart:
    def email_create_imap_connection(self) -> imaplib.IMAP4_SSL:
        """
        Create and authenticate an IMAP SSL connection.
        """
        imap_host = self.part_require_env("PART_EMAIL_IMAP_HOST")
        imap_port = int(self.part_get_env("PART_EMAIL_IMAP_PORT", "993"))
        imap_username = self.part_require_env("PART_EMAIL_IMAP_USERNAME")
        imap_password = self.part_require_env("PART_EMAIL_IMAP_PASSWORD")
        context = ssl.create_default_context()
        connection = imaplib.IMAP4_SSL(
            imap_host,
            imap_port,
            ssl_context=context
        )
        connection.login(imap_username, imap_password)
        return connection

    def email_close_imap_connection(
        self,
        connection: typing.Optional[imaplib.IMAP4_SSL],
    ) -> None:
        """
        Close an IMAP connection safely.
        """
        if connection is None:
            return
        try:
            connection.logout()
        except Exception:
            pass

    def email_extract_message_body(
        self,
        message: typing.Any,
    ) -> typing.Optional[str]:
        """
        Extract best-effort message body from plain text or HTML content.
        """
        if message.is_multipart():
            text_part = None
            html_part = None

            for part in message.walk():
                content_type = part.get_content_type()
                content_disposition = str(part.get("Content-Disposition") or "").lower()

                if "attachment" in content_disposition:
                    continue
                if content_type == "text/plain" and text_part is None:
                    text_part = part
                elif content_type == "text/html" and html_part is None:
                    html_part = part

            chosen_part = text_part or html_part
            if chosen_part is None:
                return None

            payload = chosen_part.get_payload(decode=True)
            if payload is None:
                return None
            charset = chosen_part.get_content_charset() or "utf-8"
            return payload.decode(charset, errors="replace")

        payload = message.get_payload(decode=True)
        if payload is None:
            return None
        charset = message.get_content_charset() or "utf-8"
        return payload.decode(charset, errors="replace")

    def email_search_latest_message_body(
        self,
        from_address: str,
        to_address: str,
        wait: bool = False,
    ) -> typing.Optional[str]:
        """
        Search inbox for the latest message body from sender to recipient.
        Uses a new IMAP connection per call.
        """
        connection = None
        try:
            connection = self.email_create_imap_connection()
            connection.select("INBOX")

            for _ in range(30 if wait else 1):
                _, data = connection.search(None, f'FROM "{from_address}" TO "{to_address}"')
                message_numbers = data[0].split()

                if message_numbers:
                    last_email = message_numbers[-1]
                    _, fetch_data = connection.fetch(last_email, "(RFC822)")
                    raw_email = fetch_data[0][1]
                    parsed_message = email.message_from_bytes(raw_email)
                    body = self.email_extract_message_body(parsed_message)
                    if body is not None:
                        return body

                time.sleep(1)
            return None
        finally:
            self.email_close_imap_connection(connection)


