import typing

import requests

from part.core_parts.primitive import KnownException


class EvomiPart:
    def evomi_generate_proxy(
        self,
        *,
        product: typing.Optional[str] = "rpc",
        countries: typing.Optional[typing.Sequence[str]] = ("US",),
        session: typing.Optional[str] = "sticky",
        amount: typing.Optional[int] = 1,
        format: typing.Optional[int] = 1,
        prepend_protocol: typing.Optional[bool] = True,
        protocol: typing.Optional[str] = "http",
        lifetime: typing.Optional[int] = 1440,
    ) -> str:
        """
        DD>11
        Generate a proxy using the Evomi Public API.
        Only non-None request params are sent to Evomi.
        `countries` is serialized as comma-separated country codes (ex. "GB,US,CA").
        """
        #setup
        url = 'https://api.evomi.com/public/generate'
        api_key = self.part_require_env("PART_EVOMI_API_KEY")
        headers = {
            'x-apikey': api_key
        }
        params: typing.Dict[str, typing.Any] = {}
        if product is not None:
            params['product'] = product
        if countries is not None:
            params['countries'] = ",".join([c.strip().upper() for c in countries if c and c.strip()])
        if session is not None:
            params['session'] = session
        if amount is not None:
            params['amount'] = amount
        if format is not None:
            params['format'] = format
        if prepend_protocol is not None:
            params['prepend_protocol'] = str(prepend_protocol).lower()
        if protocol is not None:
            params['protocol'] = protocol
        if lifetime is not None:
            params['lifetime'] = lifetime

        #request
        res = requests.get(
            url=url,
            headers=headers,
            params=params
        )
        res.raise_for_status()

        #response
        status_code = res.status_code
        text = res.text
        if status_code != 200:
            raise KnownException('Error creating a proxy. Status code: {} \nError: {}'.format(status_code, text))
        
        #add some extras
        parsed = self.evomi_parse_proxy_string(text)
        extras = '_latency-500_localdns-1' # DD>11
        new_password = str(parsed['full_password']) + str(extras)

        #construct new proxy_string
        proxy_string = parsed['protocol'] + parsed['username'] + ':' + new_password + '@' + parsed['host'] + ':' + parsed['port']

        return proxy_string
    
    def evomi_parse_proxy_string(self, proxy_string: str) -> typing.Dict[str, str]:
        """
        Parses an evomi proxy string into a dict with all details as k/v pairs
        ##### Parameters
        - proxy_string
        """
        obj = {}
        #remove protocol
        if 'http://' in proxy_string:
            obj['protocol'] = 'http://'
            proxy_string = proxy_string.replace('http://', '')
        elif 'https://' in proxy_string:
            obj['protocol'] = 'https://'
            proxy_string = proxy_string.replace('https://', '')
        else:
            raise ValueError('Unknown protocol')

        #split
        credentials = proxy_string.split('@')[0]
        address = proxy_string.split('@')[1]

        #host/port
        obj['host'] = address.split(':')[0]
        obj['port'] = address.split(':')[1]

        #username/password
        obj['username'] = credentials.split(':')[0]
        obj['full_password'] = credentials.split(':')[1]

        #parameters
        parameters = obj['full_password'].split('_')
        for p in parameters:
            if '-' not in p:
                k = 'password'
                v = p
            else:
                k = p.split('-')[0]
                v = p.split('-')[1]
            obj[k] = v
        
        return obj


