from time import sleep as wait
import sys
import random
import typing

import asyncio
from playwright.sync_api import sync_playwright

from part.core_parts.primitive import PrimitivePart, KnownException
    

#fix windows being shit
if sys.platform.startswith("win"):
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())


class PlaywrightSyncPart:
    """
    using it with a remote browser will make the automation slow, due to cdp command roundtrips
    """
    # region browser connection    
    def playwright_sync_create_connection(
        self,
        host: str,
        cdp_port: typing.Union[str, int],
    ) -> None:
        """
        DD>8
        """
        self.host = host
        self.cdp_port = cdp_port
        endpoint_url = 'http://' + str(self.host) + ':' + str(self.cdp_port)
        self.pw = sync_playwright().start()
        self.pw_browser = None
        for _ in range(200): # 20sec
            try:
                self.pw_browser = self.pw.chromium.connect_over_cdp(
                    endpoint_url=endpoint_url # DD>16
                )
            except:
                self.wait(0.1)
                pass
            else:
                break
        if self.pw_browser is None:
            raise KnownException('Failed to connect to session')
        self.pw_default_context = self.pw_browser.contexts[0]
        self.pw_page = self.pw_default_context.pages[0]
    #endregion

    #region tab/page control
    def playwright_sync_create_page(self, name: str) -> None:
        if not hasattr(self, "sb_pages") or self.sb_pages is None:
            self.sb_pages = {}
        if name in self.sb_pages:
            self.sb.switch_to_tab(self.sb_pages[name])
            return
        self.sb_pages[name] = self.sb.get_active_tab()

    def playwright_sync_switch_to_tab(self, url_string: str = 'https') -> None:
        """
        Switch to tab based on a url
        ##### Parameters
        - url_string: URL or a URL part to match
        """
        found_pw_page = False
        for p in self.pw_default_context.pages:
            if url_string.lower() in p.url.lower():
                self.pw_page = p
                found_pw_page = True
                break
        if not found_pw_page:
            raise KnownException('Playwright page not found')

    def playwright_sync_wait_for_tab(
        self,
        url_string: str = 'https',
        timeout: int = 10,
    ) -> None:
        for _ in range(10*timeout):
            pages = [p.url.lower() for p in self.pw_default_context.pages]
            if url_string.lower() in pages:
                break
            self.wait(0.1)

    def playwright_sync_tab_exists(
        self,
        url_string: str = 'https',
        wait: bool = True,
        timeout: int = 10,
    ) -> bool:
        for _ in range(10*timeout):
            pages = [p.url.lower() for p in self.pw_default_context.pages]
            if url_string.lower() in pages:
                return True
            else:
                if wait:
                    self.wait(0.1)
                    continue
                return False
        return False
    #endregion


    #region browser methods
    def playwright_sync_navigate(
        self,
        url: typing.Optional[str] = None,
        tries: int = 1,
        success_selector: typing.Optional[str] = None,
        success_selector_timeout: int = 10000,
    ) -> None:
        wait_until = 'commit' if success_selector else 'domcontentloaded'
        err = None
        for _ in range(tries):
            try:
                self.pw_page.goto(
                    url,
                    wait_until=wait_until
                )
                if not success_selector:
                    return
                if self.playwright_sync_element_exists(success_selector, wait=True, timeout=success_selector_timeout):
                    return
                raise Exception('success_selector not found after navigating')
            except TimeoutError as e:
                self.playwright_sync_wait(1000)
                err = e
                continue
            except Exception as e:
                if "ERR_TUNNEL_CONNECTION_FAILED" in str(e):
                    self.playwright_sync_wait(1000)
                    err = e
                    continue
                if "success_selector not found after navigating" in str(e):
                    self.playwright_sync_wait(1000)
                    err = e
                    continue
                raise e
        raise err

    def playwright_sync_refresh(self, timeout: int = 10000) -> None:
        self.pw_page.reload(
            timeout=timeout,
            wait_until="domcontentloaded"
        )

    def playwright_sync_element_exists(
        self,
        selector: str,
        wait: bool = True,
        timeout: int = 10000,
        state: typing.Optional[str] = None,
    ) -> bool:
        """
        dae
        """
        selector = self.__convert_to_xpath(selector)
        try:
            if wait:
                self.pw_page.wait_for_selector(selector, timeout=timeout, state=state)
                return True
            else:
                element = self.pw_page.query_selector(selector)
                return element is not None
        except:
            return False

    def playwright_sync_wait_for_element(
        self,
        selector: str,
        timeout: int = 10000,
    ) -> None:
        selector = self.__convert_to_xpath(selector)
        try:
            self.pw_page.wait_for_selector(selector, timeout=timeout)
        except:
            pass

    def playwright_sync_wait_for_page_to_change(
        self,
        selector: str,
        timeout: int = 10000,
    ) -> None:
        selector = self.__convert_to_xpath(selector)
        seconds = int(timeout / 1000)
        for _ in range(seconds):
            if not self.playwright_sync_element_exists(selector, wait=False):
                return
            wait(1)
        raise KnownException('page did not change')

    def playwright_sync_click_element(
        self,
        selector: typing.Optional[str] = None,
        strict: bool = True,
        timeout: int = 10000,
        trial: bool = False,
        no_wait_after: typing.Optional[bool] = None,
    ) -> None:
        """
        Clicks an element
        ##### Parameters
        - selector: An XPath selector for the element to click
        - strict: If True and the selector resolves to more than one element, the method will throw (default is True)
        - timeout: Maximum amount of time (in milliseconds) the method will wait for the element to resolve, after which it will throw (default is 5000)
        - trial: If True it will perform only the actionability checks and will not click (default is False)
        - no_wait_after: If True, when a click has initiated page load it will not wait for that to finish
        """
        selector = self.__convert_to_xpath(selector)
        self.pw_page.click(
            selector=selector,
            strict=strict,
            timeout=timeout,
            trial=trial,
            no_wait_after=no_wait_after
        )

    def playwright_sync_move_mouse_to_element(self, selector: str) -> None:
        selector = self.__convert_to_xpath(selector)
        element = self.pw_page.query_selector(selector)
        self.pw_page.mouse.move(
            x=element.bounding_box()['x'],
            y=element.bounding_box()['y'],
            steps=random.randint(10, 100)
        )

    def playwright_sync_type_text(
        self,
        selector: str,
        text: str,
        submit: bool = True,
    ) -> None:
        selector = self.__convert_to_xpath(selector)
        text = str(text)
        self.pw_page.fill(selector, text)
        if submit:
            # self.pw_page.focus(selector)
            self.pw_page.press(selector, "Enter")

    def playwright_press_key(self, key: str) -> None:
        self.pw_page.keyboard.press(key)

    def playwright_sync_scrape_element_text(self, selector: str) -> typing.Optional[str]:
        selector = self.__convert_to_xpath(selector)
        return self.pw_page.query_selector(selector).text_content()
    
    def playwright_sync_scrape_element_attribute(
        self,
        selector: str,
        attribute: str,
    ) -> typing.Optional[str]:
        selector = self.__convert_to_xpath(selector)
        el = self.pw_page.query_selector(selector)
        return el.get_attribute(attribute)

    def playwright_sync_scrape_elements_attribute(
        self,
        selector: str,
        attribute: str,
    ) -> typing.List[typing.Optional[str]]:
        selector = self.__convert_to_xpath(selector)
        elements = self.pw_page.query_selector_all(selector)
        return [el.get_attribute(attribute) for el in elements]
    
    def playwright_sync_switch_to_frame(self, name: typing.Optional[str] = None) -> None:
        if name is None:
            self.pw_page.frame(0)
        else:            
            self.pw_page.frame(name=name)

    def playwright_sync_switch_to_default_content(self) -> None:
        self.pw_page.frame_reset()

    def playwright_sync_change_dropdown_option(
        self,
        selector: str,
        option_text: str,
    ) -> None:
        selector = self.__convert_to_xpath(selector)
        el = self.pw_page.query_selector(selector)
        el.select_option(option_text)

    def playwright_sync_scroll_to_bottom(self) -> None:
        self.pw_page.evaluate('window.scrollTo(0, document.body.scrollHeight)')

    def playwright_sync_scroll_to_element(self, selector: str) -> None:
        selector = self.__convert_to_xpath(selector)
        element = self.pw_page.wait_for_selector(selector, timeout=1000, strict=True)
        element.scroll_into_view_if_needed()

    def playwright_sync_run_javascript(self, script: str) -> None:
        self.pw_page.evaluate(script)

    def playwright_sync_run_javascript_on_element(
        self,
        selector: str,
        script: str,
    ) -> typing.Any:
        selector = self.__convert_to_xpath(selector)
        element = self.pw_page.query_selector(selector)
        return element.evaluate(script)

    def playwright_sync_get_element(self, selector: str) -> typing.Any:
        selector = self.__convert_to_xpath(selector)
        return self.pw_page.query_selector(selector)

    def playwright_sync_get_title(self) -> str:
        return self.pw_page.title()

    def playwright_sync_get_current_url(self) -> str:
        return self.pw_page.url

    def playwright_sync_add_locator_handler(
        self,
        selector: str,
        callable: typing.Callable[..., typing.Any],
        no_wait_after: typing.Optional[bool] = None,
        times: typing.Optional[int] = None,
        preremove: bool = False,
    ) -> None:
        """
        Wrapper for Playwright page.add_locator_handler, the callable will be triggered when both:
        - the selector resolves
        - a command with actionability checks enabled is executed
        Playwright's actionability checks is what "triggers" the callable, thus only providing a selector is not sufficient.
        Element that the selector resolves to must exist in the DOM and must be interactible (no display:none and height>0 and width>0 etc.)
        Please read the add_locator_handler docstring
        ##### Parameters
        - selector: selector for the element
        - callable: the method to call when triggered
        - no_wait_after: wait for the element to disappear before continuing 
        - times: how many times to trigger the callable
        - preremove: remove all handlers from the element before adding the new one
        """
        selector = self.__convert_to_xpath(selector)
        if preremove:
            self.playwright_sync_remove_locator_handler(
                selector=selector,
            )
        locator = self.pw_page.locator(selector)
        self.pw_page.add_locator_handler(
            locator=locator,
            handler=callable,
            no_wait_after=no_wait_after,
            times=times
        )
            
    def playwright_sync_remove_locator_handler(self, selector: str) -> None:
        selector = self.__convert_to_xpath(selector)
        locator = self.pw_page.locator(selector)
        self.pw_page.remove_locator_handler(
            locator=locator
        )
    #endregion


#region other
    def playwright_sync_wait(self, timeout: int = 10000) -> None:
        """
        From ChatGPT: time.sleep() blocks Playwright's internal event loop/driver plumbing in sync mode, 
        so things like Cloudflare Turnstile (which relies on timers, postMessage, workers, etc.) stop initializing. 
        Async works because asyncio.sleep() yields control.
        Use this instead of time.sleep().
        ##### Parameters
        - timeout: wait in milliseconds
        """
        self.pw_page.wait_for_timeout(timeout)

    def __convert_to_xpath(self, selector: str) -> str:
        """
        Ensures selector starts with "xpath="
        ##### Parameters
        - selector
        """
        if not selector.startswith('xpath='):
            return 'xpath=' + str(selector)
        return selector

    def playwright_sync_generate_resolution(self, type: str) -> str:
        if type.lower() not in ['hd', 'fullhd', 'hdplus']:
            raise ValueError('Resolution not supported')
        res = {
            'hd_w': 1280,
            'hd_h': 720,
            'fullhd_w': 1920,
            'fullhd_h': 1080,
            'hdplus_w': 1600,
            'hdplus_h': 900
        }
        base_w = res[f'{type.lower()}_w']
        base_h = res[f'{type.lower()}_h']
        w_rand_1 = random.randint(0, 9)
        w_rand_2 = random.randint(0, 9)
        h_rand_1 = random.randint(0, 9)
        h_rand_2 = random.randint(0, 9)
        final_w = int(str(base_w)[:-2] + f"{w_rand_1}{w_rand_2}")
        final_h = int(str(base_h)[:-2] + f"{h_rand_1}{h_rand_2}")
        return f"{final_w}x{final_h}"

    def playwright_sync_get_ip(self) -> typing.Dict[str, typing.Any]:
        return self.pw_page.evaluate("""
            async () => {
                const r = await fetch("https://api.ipify.org?format=json", {
                    cache: "no-store"
                });
                return await r.json();
            }
        """)
    #endregion


