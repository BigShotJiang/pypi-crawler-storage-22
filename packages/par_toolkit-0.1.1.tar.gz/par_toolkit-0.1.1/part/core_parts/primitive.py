from time import sleep as wait
import random
import string
import os
import typing


class PrimitivePart:
    def part_get_env(
        self,
        key: str,
        default: typing.Optional[str] = None,
    ) -> typing.Optional[str]:
        return os.getenv(key, default)

    def part_require_env(self, key: str) -> str:
        value = os.getenv(key)
        if value is None or value.strip() == "":
            raise KnownException(f"Missing required env var: {key}")
        return value

    def generate_password(self, length: int = 14) -> str:
        symbols = "!@#$%_+?"
        while True:
            passw = ''.join(random.choices(string.ascii_letters + string.digits + symbols, k=length))
            if (
                any(c.islower() for c in passw)
                and any(c.isupper() for c in passw)
                and any(c.isdigit() for c in passw)
                and any(c in symbols for c in passw)
            ):
                return passw

    def wait(self, seconds: int) -> None:
        """
        DD>14
        Basic sleep helper.
        """
        wait(seconds)


class KnownException(Exception):
    pass

class SilentException(Exception):
    pass