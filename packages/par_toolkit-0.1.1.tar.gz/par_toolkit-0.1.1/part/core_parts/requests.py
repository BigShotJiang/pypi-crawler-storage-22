import typing

import requests


class RequestsPart:
    def requests_get(
        self,
        url: str,
        params: typing.Optional[typing.Dict[str, typing.Any]] = None,
        headers: typing.Optional[typing.Dict[str, typing.Any]] = None,
        proxies: typing.Optional[typing.Union[str, typing.Dict[str, str]]] = None,
        timeout: int = 30,
        allow_redirects: bool = True,
        raise_for_status: bool = True,
    ) -> requests.Response:
        """
        Perform a GET request and return the raw requests.Response object.
        - `proxies` can be either:
          - a proxy string, e.g. "http://user:pass@host:port"
          - a requests-style proxy dict, e.g. {"http": "...", "https": "..."}
        """
        request_proxies: typing.Optional[typing.Dict[str, str]]
        if isinstance(proxies, str):
            request_proxies = {"http": proxies, "https": proxies}
        else:
            request_proxies = proxies

        response = requests.get(
            url=url,
            params=params,
            headers=headers,
            proxies=request_proxies,
            timeout=timeout,
            allow_redirects=allow_redirects,
        )
        if raise_for_status:
            response.raise_for_status()
        return response


