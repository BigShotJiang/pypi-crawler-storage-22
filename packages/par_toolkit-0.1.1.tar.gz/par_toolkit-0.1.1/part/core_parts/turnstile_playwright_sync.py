import typing

if typing.TYPE_CHECKING:
    from part.part_class import Part


class TurnstilePlaywrightSyncPart:
    def turnstile_pw_sync_solve(
        self: "Part",
        focus_element_selector: str,
        tab_count: int,
    ) -> None:
        #main loop (try a few times)
        for _ in range(60): # 30 sec
            #focus on element that can be interacted with
            self.pw_page.focus(focus_element_selector, strict=True)
            #press tab X amount of times to focus on the checkbox
            for _ in range(tab_count):
                self.playwright_press_key('Tab')
            #get the focused element's data
            checkbox_element = self.pw_page.evaluate("""
            () => {
                const el = document.activeElement?.querySelector('input');
                if (!el) return null;
                return {
                    tag: el.tagName,
                    name: el.getAttribute('name'),
                    value: el.value
                };
            }
            """)
            #if solved return
            if checkbox_element['tag'] == 'INPUT' and checkbox_element['name'] == 'cf-turnstile-response' and len(str(checkbox_element['value'])) > 0:
                return
            #click continiously (has no side effects if the checkbox hasn't loaded yet)
            if checkbox_element['tag'] == 'INPUT' and checkbox_element['name'] == 'cf-turnstile-response':
                self.playwright_press_key('Space')
            self.playwright_sync_wait(500)
        raise TurnstilePlaywrightSyncPartError('Failed to solve turnstile challenge')


class TurnstilePlaywrightSyncPartError(Exception):
    pass
