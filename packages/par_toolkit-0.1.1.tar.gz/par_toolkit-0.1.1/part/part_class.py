import typing

from part.src.custom_logger import get_custom_logger
from part.core_parts.primitive import PrimitivePart
from part.core_parts.email import EmailPart
from part.core_parts.evomi import EvomiPart
from part.core_parts.capsolver_playwright_sync import CapsolverPlaywrightSyncPart
from part.core_parts.turnstile_playwright_sync import TurnstilePlaywrightSyncPart
from part.core_parts.caas import CaaSPart
from part.core_parts.playwright_sync import PlaywrightSyncPart
from part.core_parts.requests import RequestsPart


class Part(
    PrimitivePart,
    EmailPart,
    EvomiPart,
    CapsolverPlaywrightSyncPart,
    TurnstilePlaywrightSyncPart,
    CaaSPart,
    RequestsPart,
    PlaywrightSyncPart,
):
    """
    God-class with all core mixins available on a single object.
    """

    def __init__(
        self,
        logger: typing.Optional[typing.Any] = None,
    ) -> None:
        self.log = logger or get_custom_logger()

    @classmethod
    def create_many(cls, count: int, **kwargs: typing.Any) -> typing.List["Part"]:
        if count < 1:
            raise ValueError("count must be >= 1")
        return [cls(**kwargs) for _ in range(count)]
