import logging
import re
import typing


class ColorFormatter(logging.Formatter):
    """
    DD>2
    """
    COLORS = {
        logging.DEBUG: "\033[36m",      # cyan
        logging.INFO: "\033[32m",       # green
        logging.WARNING: "\033[33m",    # yellow
        logging.ERROR: "\033[31m",      # red
        logging.CRITICAL: "\033[41m",   # red background
    }

    HIGHLIGHT = "\033[36m"
    RESET = "\033[0m"
    PATTERN = re.compile(r"\\\\part\\\\")

    def format(self, record: logging.LogRecord) -> str:
        text = super().format(record)
        lines = text.splitlines()
        first_line = lines[0]
        base_color = self.COLORS.get(record.levelno, "")
        first_line = f"{base_color}{first_line}{self.RESET}"
        rest = []
        for line in lines[1:]:
            colored_line = line
            if self.PATTERN.search(line):
                colored_line = f"{self.HIGHLIGHT}{line}{self.RESET}"
            rest.append(colored_line)
        if rest:
            return "\n".join([first_line] + rest) + self.RESET
        else:
            return first_line + self.RESET

def get_custom_logger() -> logging.Logger:
    logger = logging.getLogger("imhotep.colored")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(ColorFormatter("%(levelname)s: %(message)s"))
        logger.addHandler(handler)
    return logger
