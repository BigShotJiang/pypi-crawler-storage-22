import os
import typing

import mysql.connector


class DatabaseManager:
    """
    DD>1
    """
    def __enter__(self) -> "DatabaseManager":
        self.conn = mysql.connector.connect(
            host=os.getenv("PART_DB_HOST", "localhost"),
            port=int(os.getenv("PART_DB_PORT", "3306")),
            database=os.getenv("PART_DB_NAME", ""),
            user=os.getenv("PART_DB_USER", ""),
            password=os.getenv("PART_DB_PASS", "")
        )
        self.cursor = self.conn.cursor(dictionary=True)
        return self

    def __exit__(
        self,
        exc_type: typing.Optional[type],
        exc: typing.Optional[BaseException],
        tb: typing.Optional[typing.Any],
    ) -> None:
        if exc is not None:
            self.conn.rollback()
        else:
            self.conn.commit()

        self.cursor.close()
        self.conn.close()

    def query_one(
        self,
        query: str,
        params: typing.Optional[typing.Union[tuple, dict]] = None,
    ) -> typing.Optional[typing.Dict[str, typing.Any]]:
        self.cursor.execute(query, params)
        return self.cursor.fetchone()

    def query_all(
        self,
        query: str,
        params: typing.Optional[typing.Union[tuple, dict]] = None,
    ) -> typing.List[typing.Dict[str, typing.Any]]:
        self.cursor.execute(query, params)
        return self.cursor.fetchall()

    def update(
        self,
        query: str,
        params: typing.Optional[typing.Union[tuple, dict]] = None,
    ) -> None:
        self.cursor.execute(query, params)
        self.conn.commit()

    def insert(
        self,
        query: str,
        params: typing.Optional[typing.Union[tuple, dict]] = None,
    ) -> int:
        self.cursor.execute(query, params)
        self.conn.commit()
        return self.cursor.lastrowid

    def delete(
        self,
        query: str,
        params: typing.Optional[typing.Union[tuple, dict]] = None,
    ) -> None:
        self.cursor.execute(query, params)
        self.conn.commit()
