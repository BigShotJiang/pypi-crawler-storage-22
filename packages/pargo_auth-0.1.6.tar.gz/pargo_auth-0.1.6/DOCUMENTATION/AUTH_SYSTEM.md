# PARGO Authentication System

This document describes the authentication architecture for PARGO applications.

## Overview

PARGO uses a hybrid authentication approach:
- **Supabase Auth** (EU-hosted) handles identity/login (Google, Apple, Email/Password)
- **pargo-auth service** validates JWTs and manages user data in our own Postgres
- **User data** is stored in Hetzner Postgres, giving us full control

## Architecture

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Flutter    │────▶│  Supabase   │     │   Hetzner   │
│    App      │     │    Auth     │     │  Postgres   │
└─────────────┘     └─────────────┘     └─────────────┘
       │                   │                   ▲
       │                   │ JWT               │
       │                   ▼                   │
       │            ┌─────────────┐            │
       └───────────▶│ pargo-auth  │────────────┘
         API calls  │  service    │  user data
                    └─────────────┘
```

## Components

### 1. Supabase Auth (Identity Provider)
- **URL**: `https://cmnowxzhwrskkixukyif.supabase.co`
- **Purpose**: Handle login flows, issue JWTs
- **Providers**: Email/Password, Google, Apple (pending)
- **We use**: Only authentication, NOT Supabase database

### 2. pargo-auth Service
- **URL**: `https://prod.pargo.dk/auth/`
- **Port**: 8040
- **Purpose**: 
  - Validate Supabase JWTs
  - Provide user management API
  - Store user data in our Postgres

### 3. pargo-auth PyPI Package
- **Package**: `pargo-auth` on PyPI
- **Purpose**: JWT verification middleware for other PARGO backends
- **Usage**: `pip install pargo-auth`

## API Endpoints

### pargo-auth Service

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/health` | No | Health check |
| GET | `/v1/me` | Yes | Get current user profile + settings |
| PATCH | `/v1/me` | Yes | Update user profile |
| PATCH | `/v1/me/settings` | Yes | Update user settings |

### Supabase Auth (via SDK)

| Action | SDK Method |
|--------|------------|
| Sign up | `supabase.auth.signUp()` |
| Sign in (email) | `supabase.auth.signInWithPassword()` |
| Sign in (Google) | `supabase.auth.signInWithOAuth(OAuthProvider.google)` |
| Sign in (Apple) | `supabase.auth.signInWithOAuth(OAuthProvider.apple)` |
| Sign out | `supabase.auth.signOut()` |
| Refresh token | Automatic via SDK |

## Database Schema

User data is stored in Hetzner Postgres under the `auth` schema:

```sql
-- Main user table
auth.users (
    id              UUID PRIMARY KEY,
    supabase_uid    TEXT UNIQUE NOT NULL,  -- Links to Supabase
    email           TEXT,
    email_verified  BOOLEAN,
    display_name    TEXT,
    avatar_url      TEXT,
    preferred_lang  VARCHAR(5) DEFAULT 'da',
    created_at      TIMESTAMPTZ,
    updated_at      TIMESTAMPTZ,
    last_login_at   TIMESTAMPTZ,
    deleted_at      TIMESTAMPTZ            -- Soft delete
)

-- User settings
auth.user_settings (
    user_id         UUID PRIMARY KEY REFERENCES auth.users(id),
    push_enabled    BOOLEAN DEFAULT TRUE,
    email_enabled   BOOLEAN DEFAULT TRUE,
    map_style       VARCHAR(20) DEFAULT 'standard',
    settings_json   JSONB DEFAULT '{}'
)

-- Login providers (Google, Apple, etc.)
auth.user_identities (
    id              UUID PRIMARY KEY,
    user_id         UUID REFERENCES auth.users(id),
    provider        VARCHAR(50),           -- 'google', 'apple', 'email'
    provider_uid    TEXT,
    email           TEXT,
    created_at      TIMESTAMPTZ
)
```

## JWT Structure

Supabase JWTs contain:

```json
{
  "sub": "c2de269a-b357-4502-8efb-d92a463dda91",  // Supabase user ID
  "email": "user@example.com",
  "app_metadata": {
    "provider": "google",
    "providers": ["google"]
  },
  "user_metadata": {
    "full_name": "John Doe",
    "avatar_url": "https://..."
  },
  "exp": 1770096078,
  "iat": 1770092478
}
```

## Using pargo-auth in Other Services

### Installation

```bash
pip install pargo-auth
```

### Required Auth

```python
from pargo_auth import SupabaseAuth, AuthenticatedUser
from fastapi import Depends

auth = SupabaseAuth()

@app.get("/protected")
async def protected_route(user: AuthenticatedUser = Depends(auth.get_user)):
    return {"user_id": user.sub, "email": user.email}
```

### Optional Auth (for migration)

```python
@app.get("/public")
async def public_route(user: AuthenticatedUser | None = Depends(auth.get_user_optional)):
    if user:
        return {"authenticated": True, "user_id": user.sub}
    return {"authenticated": False}
```

## Configuration

### Environment Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `SUPABASE_URL` | Supabase project URL | `https://xxx.supabase.co` |
| `DATABASE_URL` | Postgres connection | `postgresql://user:pass@host:5432/db` |
| `ENV` | Environment | `prod` or `test` |

### Supabase Dashboard Settings

- **Site URL**: `https://prod.pargo.dk`
- **Redirect URLs**: `https://prod.pargo.dk/**`

## Security Notes

1. **JWTs are validated server-side** using Supabase's JWKS endpoint
2. **Tokens expire after 1 hour** - the SDK handles refresh automatically
3. **User data is in our control** - Supabase only stores auth credentials
4. **Soft deletes** preserve data for potential recovery

## Current Status

| Provider | Status |
|----------|--------|
| Email/Password | ✅ Working |
| Google OAuth | ✅ Working |
| Apple Sign In | ⏳ Pending setup |

---

*Last updated: 2026-02-03*
