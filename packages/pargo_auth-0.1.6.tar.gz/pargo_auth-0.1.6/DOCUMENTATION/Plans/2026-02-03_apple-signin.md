# Plan: Add Apple Sign In Support

## Status: Pending

Apple Sign In is required for iOS App Store compliance (any app with social login must offer Apple).

## Prerequisites

- [ ] Access to Apple Developer account
- [ ] PARGO app already registered with App ID

## Steps

### 1. Create Services ID in Apple Developer Console

1. Go to [Certificates, Identifiers & Profiles](https://developer.apple.com/account/resources/identifiers/list)
2. Click **+** → Select **Services IDs** → Continue
3. Fill in:
   - Description: `PARGO Auth`
   - Identifier: `dk.pargo.auth`
4. Click **Continue** → **Register**

### 2. Configure Services ID for Sign In with Apple

1. Click on the Services ID you created
2. Enable **Sign In with Apple**
3. Click **Configure**
4. Set:
   - Primary App ID: Your PARGO app
   - Domains: `cmnowxzhwrskkixukyif.supabase.co`
   - Return URLs: `https://cmnowxzhwrskkixukyif.supabase.co/auth/v1/callback`
5. Click **Save** → **Continue** → **Save**

### 3. Create a Key for Sign In with Apple

1. Go to **Keys** in Apple Developer
2. Click **+**
3. Fill in:
   - Name: `PARGO Supabase Auth`
4. Enable **Sign In with Apple**
5. Click **Configure** → Select your Primary App ID → **Save**
6. Click **Continue** → **Register**
7. **IMPORTANT**: Download the `.p8` key file immediately (one-time download!)
8. Note the **Key ID** shown

### 4. Gather Required Information

You'll need these values for Supabase:

| Item | Where to find it | Example |
|------|------------------|---------|
| Services ID | Step 1 identifier | `dk.pargo.auth` |
| Team ID | Top-right of Apple Developer page | `ABC123XYZ` |
| Key ID | Shown after creating key | `DEFG456` |
| Private Key | Contents of `.p8` file | `-----BEGIN PRIVATE KEY-----...` |

### 5. Configure Supabase

1. Go to [Supabase Auth Providers](https://supabase.com/dashboard/project/cmnowxzhwrskkixukyif/auth/providers)
2. Find **Apple** and enable it
3. Enter:
   - **Service ID**: `dk.pargo.auth`
   - **Team ID**: (from Apple Developer)
   - **Key ID**: (from step 3)
   - **Private Key**: (paste entire `.p8` contents)
4. Click **Save**

### 6. Test Apple Sign In

```bash
# Open this URL in Safari (Apple Sign In works best in Safari)
open "https://cmnowxzhwrskkixukyif.supabase.co/auth/v1/authorize?provider=apple&redirect_to=https://prod.pargo.dk/auth/v1/me"
```

### 7. Verify in Database

```bash
# Check user was created
ssh thor@prod.pargo.dk "docker exec -i postgres-server psql -U postgres -d pargo_prod -c \"SELECT email, created_at FROM auth.users ORDER BY created_at DESC LIMIT 3;\""
```

## iOS App Configuration

For native Apple Sign In in Flutter (recommended for better UX):

1. In Xcode, enable **Sign In with Apple** capability
2. Add to `ios/Runner/Runner.entitlements`:
   ```xml
   <key>com.apple.developer.applesignin</key>
   <array>
       <string>Default</string>
   </array>
   ```

## Notes

- Apple Sign In is **required** by App Store if you have any social login
- Apple may hide user's real email (relay address like `xxx@privaterelay.appleid.com`)
- First login returns user's name, subsequent logins may not - store it on first login
- The `.p8` key file can only be downloaded ONCE - store it securely

## Estimated Time

- Apple Developer setup: 15-20 minutes
- Supabase configuration: 5 minutes
- Testing: 10 minutes

---

*Created: 2026-02-03*
