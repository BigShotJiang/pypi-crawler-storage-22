"""Service configuration."""

import os
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings from environment variables."""
    
    # Environment
    env: str = "local"
    
    # Database
    database_url: str = "postgresql://postgres:password@postgres:5432/pargo_prod"
    
    # Supabase (for JWT verification)
    supabase_url: str = "https://cmnowxzhwrskkixukyif.supabase.co"


settings = Settings()

# Set environment for pargo_auth library
os.environ.setdefault("SUPABASE_URL", settings.supabase_url)
os.environ.setdefault("ENV", settings.env)
