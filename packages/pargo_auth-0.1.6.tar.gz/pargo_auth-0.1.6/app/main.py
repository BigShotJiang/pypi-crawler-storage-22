"""pargo-auth service - User management API."""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.routes.users import router as users_router
from app.services.db import init_db, close_db

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan - startup and shutdown."""
    # Startup
    logger.info("Starting pargo-auth service...")
    await init_db()
    logger.info("pargo-auth service ready")
    
    yield
    
    # Shutdown
    logger.info("Shutting down pargo-auth service...")
    await close_db()


app = FastAPI(
    title="Pargo Auth",
    description="User management service for PARGO",
    version="0.1.0",
    lifespan=lifespan,
)

# Include routers
app.include_router(users_router)


@app.get("/health")
def health():
    """Health check endpoint."""
    return {"status": "ok", "service": "pargo-auth"}
