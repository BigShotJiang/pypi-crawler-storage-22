"""User profile and settings endpoints."""

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from pargo_auth import AuthenticatedUser, SupabaseAuth

from app.services import user_service

router = APIRouter(prefix="/v1", tags=["users"])

# Auth dependency (required - these endpoints need authentication)
_auth = SupabaseAuth()


# === Request/Response Models ===

class UserResponse(BaseModel):
    """User profile response."""
    id: str
    supabase_uid: str
    email: Optional[str] = None
    email_verified: bool = False
    display_name: Optional[str] = None
    avatar_url: Optional[str] = None
    preferred_lang: str = "da"
    is_anonymous: bool = False
    created_at: str
    updated_at: str
    last_login_at: Optional[str] = None


class UserSettingsResponse(BaseModel):
    """User settings response."""
    push_enabled: bool = True
    email_enabled: bool = True
    map_style: str = "standard"
    settings_json: dict = {}


class MeResponse(BaseModel):
    """Combined user + settings response for /me."""
    user: UserResponse
    settings: UserSettingsResponse


class UpdateProfileRequest(BaseModel):
    """Request to update user profile."""
    display_name: Optional[str] = None
    avatar_url: Optional[str] = None
    preferred_lang: Optional[str] = None


class UpdateSettingsRequest(BaseModel):
    """Request to update user settings."""
    push_enabled: Optional[bool] = None
    email_enabled: Optional[bool] = None
    map_style: Optional[str] = None
    settings_json: Optional[dict] = None


# === Endpoints ===

@router.get("/me", response_model=MeResponse)
async def get_me(auth_user: AuthenticatedUser = Depends(_auth.get_user)):
    """
    Get current user profile and settings.
    
    Creates user on first call (bootstrapping from Supabase JWT).
    Updates last_login_at and syncs email on each call.
    """
    # Get or create user from JWT claims
    user_data = await user_service.get_or_create_user(auth_user)
    
    # Get settings
    settings_data = await user_service.get_user_settings(user_data["id"])
    
    return MeResponse(
        user=UserResponse(
            id=str(user_data["id"]),
            supabase_uid=user_data["supabase_uid"],
            email=user_data["email"],
            email_verified=user_data["email_verified"] or False,
            display_name=user_data["display_name"],
            avatar_url=user_data["avatar_url"],
            preferred_lang=user_data["preferred_lang"] or "da",
            is_anonymous=user_data["is_anonymous"] or False,
            created_at=user_data["created_at"].isoformat() if user_data["created_at"] else None,
            updated_at=user_data["updated_at"].isoformat() if user_data["updated_at"] else None,
            last_login_at=user_data["last_login_at"].isoformat() if user_data["last_login_at"] else None,
        ),
        settings=UserSettingsResponse(
            push_enabled=settings_data.get("push_enabled", True),
            email_enabled=settings_data.get("email_enabled", True),
            map_style=settings_data.get("map_style", "standard"),
            settings_json=settings_data.get("settings_json", {}),
        ),
    )


@router.patch("/me", response_model=UserResponse)
async def update_me(
    body: UpdateProfileRequest,
    auth_user: AuthenticatedUser = Depends(_auth.get_user),
):
    """Update current user profile."""
    # First ensure user exists
    user_data = await user_service.get_or_create_user(auth_user)
    
    # Update profile
    updated = await user_service.update_user_profile(
        user_data["id"],
        body.model_dump(exclude_none=True),
    )
    
    return UserResponse(
        id=str(updated["id"]),
        supabase_uid=updated["supabase_uid"],
        email=updated["email"],
        email_verified=updated["email_verified"] or False,
        display_name=updated["display_name"],
        avatar_url=updated["avatar_url"],
        preferred_lang=updated["preferred_lang"] or "da",
        is_anonymous=updated["is_anonymous"] or False,
        created_at=updated["created_at"].isoformat() if updated["created_at"] else None,
        updated_at=updated["updated_at"].isoformat() if updated["updated_at"] else None,
        last_login_at=updated["last_login_at"].isoformat() if updated["last_login_at"] else None,
    )


@router.patch("/me/settings", response_model=UserSettingsResponse)
async def update_settings(
    body: UpdateSettingsRequest,
    auth_user: AuthenticatedUser = Depends(_auth.get_user),
):
    """Update current user settings."""
    # First ensure user exists
    user_data = await user_service.get_or_create_user(auth_user)
    
    # Update settings
    updated = await user_service.update_user_settings(
        user_data["id"],
        body.model_dump(exclude_none=True),
    )
    
    return UserSettingsResponse(
        push_enabled=updated.get("push_enabled", True),
        email_enabled=updated.get("email_enabled", True),
        map_style=updated.get("map_style", "standard"),
        settings_json=updated.get("settings_json", {}),
    )


@router.delete("/me", status_code=204)
async def delete_me(auth_user: AuthenticatedUser = Depends(_auth.get_user)):
    """
    Delete current user account (soft delete).
    
    This marks the account as deleted but preserves data for potential recovery.
    """
    user_data = await user_service.get_or_create_user(auth_user)
    success = await user_service.delete_user(user_data["id"])
    
    if not success:
        raise HTTPException(status_code=404, detail="User not found or already deleted")
