"""Database connection pool."""

import json
import logging
from contextlib import asynccontextmanager
from typing import AsyncGenerator

import asyncpg

from app.config import settings

logger = logging.getLogger(__name__)

# Global connection pool
_pool: asyncpg.Pool | None = None


async def _setup_json_codec(conn: asyncpg.Connection):
    """Configure connection to decode JSONB as Python dicts."""
    await conn.set_type_codec(
        'jsonb',
        encoder=json.dumps,
        decoder=json.loads,
        schema='pg_catalog'
    )
    await conn.set_type_codec(
        'json',
        encoder=json.dumps,
        decoder=json.loads,
        schema='pg_catalog'
    )


async def init_db():
    """Initialize database connection pool."""
    global _pool
    if _pool is None:
        logger.info(f"Connecting to database...")
        _pool = await asyncpg.create_pool(
            settings.database_url,
            min_size=2,
            max_size=10,
            init=_setup_json_codec,  # Configure JSON codec on each connection
        )
        logger.info("Database pool created")


async def close_db():
    """Close database connection pool."""
    global _pool
    if _pool:
        await _pool.close()
        _pool = None
        logger.info("Database pool closed")


@asynccontextmanager
async def get_db() -> AsyncGenerator[asyncpg.Connection, None]:
    """Get a database connection from the pool."""
    if _pool is None:
        await init_db()
    async with _pool.acquire() as conn:
        yield conn
