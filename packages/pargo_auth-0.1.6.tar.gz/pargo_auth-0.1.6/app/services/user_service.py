"""User management service - handles auth.users table operations."""

import logging
from datetime import datetime
from typing import Optional
from uuid import UUID

from pargo_auth import AuthenticatedUser

from app.services.db import get_db

logger = logging.getLogger(__name__)


async def get_or_create_user(auth_user: AuthenticatedUser) -> dict:
    """
    Get existing user or create new one from Supabase JWT claims.
    
    Called on every authenticated request to /me.
    Updates email/last_login if changed.
    Supports both anonymous and authenticated users.
    
    Returns user dict with all fields.
    """
    async with get_db() as conn:
        # Try to find existing user
        user = await conn.fetchrow(
            """
            SELECT id, supabase_uid, email, email_verified, display_name, 
                   avatar_url, preferred_lang, is_anonymous, created_at, updated_at, last_login_at
            FROM auth.users 
            WHERE supabase_uid = $1 AND deleted_at IS NULL
            """,
            auth_user.sub
        )
        
        if user:
            # Update last_login and sync email/is_anonymous if changed
            # Note: is_anonymous can go from True to False when user upgrades account
            updated = await conn.fetchrow(
                """
                UPDATE auth.users 
                SET last_login_at = now(),
                    email = COALESCE($2, email),
                    email_verified = COALESCE($3, email_verified),
                    is_anonymous = $4,
                    updated_at = now()
                WHERE supabase_uid = $1
                RETURNING id, supabase_uid, email, email_verified, display_name,
                          avatar_url, preferred_lang, is_anonymous, created_at, updated_at, last_login_at
                """,
                auth_user.sub,
                auth_user.email,
                auth_user.email_verified,
                auth_user.is_anonymous,
            )
            logger.debug(f"Updated existing user: {auth_user.sub} (anonymous={auth_user.is_anonymous})")
            return dict(updated)
        
        # Create new user
        new_user = await conn.fetchrow(
            """
            INSERT INTO auth.users (supabase_uid, email, email_verified, is_anonymous, last_login_at)
            VALUES ($1, $2, $3, $4, now())
            RETURNING id, supabase_uid, email, email_verified, display_name,
                      avatar_url, preferred_lang, is_anonymous, created_at, updated_at, last_login_at
            """,
            auth_user.sub,
            auth_user.email,
            auth_user.email_verified,
            auth_user.is_anonymous,
        )
        logger.info(f"Created new user: {auth_user.sub} (anonymous={auth_user.is_anonymous})")
        
        # Also create default settings
        await conn.execute(
            """
            INSERT INTO auth.user_settings (user_id)
            VALUES ($1)
            ON CONFLICT (user_id) DO NOTHING
            """,
            new_user["id"]
        )
        
        return dict(new_user)


async def get_user_settings(user_id: UUID) -> dict:
    """Get user settings."""
    async with get_db() as conn:
        settings = await conn.fetchrow(
            """
            SELECT user_id, push_enabled, email_enabled, map_style, settings_json, updated_at
            FROM auth.user_settings
            WHERE user_id = $1
            """,
            user_id
        )
        return dict(settings) if settings else {}


async def update_user_profile(user_id: UUID, updates: dict) -> dict:
    """
    Update user profile fields.
    
    Allowed fields: display_name, avatar_url, preferred_lang
    """
    allowed = {"display_name", "avatar_url", "preferred_lang"}
    filtered = {k: v for k, v in updates.items() if k in allowed and v is not None}
    
    if not filtered:
        # No valid updates, just return current user
        async with get_db() as conn:
            user = await conn.fetchrow(
                """
                SELECT id, supabase_uid, email, email_verified, display_name,
                       avatar_url, preferred_lang, is_anonymous, created_at, updated_at, last_login_at
                FROM auth.users WHERE id = $1
                """,
                user_id
            )
            return dict(user) if user else {}
    
    # Build dynamic UPDATE query
    set_clauses = ", ".join(f"{k} = ${i+2}" for i, k in enumerate(filtered.keys()))
    values = [user_id] + list(filtered.values())
    
    async with get_db() as conn:
        updated = await conn.fetchrow(
            f"""
            UPDATE auth.users 
            SET {set_clauses}, updated_at = now()
            WHERE id = $1
            RETURNING id, supabase_uid, email, email_verified, display_name,
                      avatar_url, preferred_lang, is_anonymous, created_at, updated_at, last_login_at
            """,
            *values
        )
        return dict(updated) if updated else {}


async def update_user_settings(user_id: UUID, updates: dict) -> dict:
    """
    Update user settings.
    
    Allowed fields: push_enabled, email_enabled, map_style, settings_json
    """
    allowed = {"push_enabled", "email_enabled", "map_style", "settings_json"}
    filtered = {k: v for k, v in updates.items() if k in allowed and v is not None}
    
    if not filtered:
        return await get_user_settings(user_id)
    
    # Build dynamic UPDATE query
    set_clauses = ", ".join(f"{k} = ${i+2}" for i, k in enumerate(filtered.keys()))
    values = [user_id] + list(filtered.values())
    
    async with get_db() as conn:
        updated = await conn.fetchrow(
            f"""
            UPDATE auth.user_settings
            SET {set_clauses}, updated_at = now()
            WHERE user_id = $1
            RETURNING user_id, push_enabled, email_enabled, map_style, settings_json, updated_at
            """,
            *values
        )
        return dict(updated) if updated else {}


async def delete_user(user_id: UUID) -> bool:
    """Soft delete user account."""
    async with get_db() as conn:
        result = await conn.execute(
            """
            UPDATE auth.users 
            SET deleted_at = now(), updated_at = now()
            WHERE id = $1 AND deleted_at IS NULL
            """,
            user_id
        )
        return result == "UPDATE 1"
