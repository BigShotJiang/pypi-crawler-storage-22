"""PARGO Auth - Shared authentication middleware for PARGO backend services."""

__version__ = "0.1.6"

from .middleware import SupabaseAuth, get_current_user, require_auth
from .models import AuthenticatedUser
from .exceptions import AuthError, InvalidTokenError, ExpiredTokenError

__all__ = [
    "SupabaseAuth",
    "get_current_user",
    "require_auth",
    "AuthenticatedUser",
    "AuthError",
    "InvalidTokenError",
    "ExpiredTokenError",
]
