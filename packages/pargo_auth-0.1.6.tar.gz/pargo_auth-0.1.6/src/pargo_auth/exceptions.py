"""Authentication exceptions."""


class AuthError(Exception):
    """Base authentication error."""
    
    def __init__(self, message: str = "Authentication failed", status_code: int = 401):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class InvalidTokenError(AuthError):
    """Token is malformed or signature is invalid."""
    
    def __init__(self, message: str = "Invalid token"):
        super().__init__(message, status_code=401)


class ExpiredTokenError(AuthError):
    """Token has expired."""
    
    def __init__(self, message: str = "Token expired"):
        super().__init__(message, status_code=401)


class MissingTokenError(AuthError):
    """No token provided."""
    
    def __init__(self, message: str = "Missing authorization header"):
        super().__init__(message, status_code=401)
