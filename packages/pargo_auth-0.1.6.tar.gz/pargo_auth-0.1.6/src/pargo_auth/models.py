"""Data models for authentication."""

from dataclasses import dataclass
from typing import Optional


@dataclass
class AuthenticatedUser:
    """Represents an authenticated user from Supabase JWT."""
    
    sub: str  # Supabase user ID (stable, use as canonical identity)
    email: Optional[str] = None
    email_verified: bool = False
    
    # Raw claims for extensibility
    raw_claims: Optional[dict] = None
    
    @property
    def supabase_uid(self) -> str:
        """Alias for sub - the Supabase user ID."""
        return self.sub
    
    @property
    def is_anonymous(self) -> bool:
        """
        Check if this is an anonymous user (signed in with signInAnonymously).
        
        Anonymous users have valid JWTs but no email/provider linked.
        They can later upgrade to a real account by linking email/Google/Apple.
        """
        if self.raw_claims:
            return self.raw_claims.get("is_anonymous", False)
        return False
