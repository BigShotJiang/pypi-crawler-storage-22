"""Tests for auth middleware."""

import pytest
from pargo_auth import AuthenticatedUser
from pargo_auth.exceptions import InvalidTokenError, ExpiredTokenError


def test_authenticated_user_creation():
    """Test AuthenticatedUser dataclass."""
    user = AuthenticatedUser(
        sub="user-123",
        email="test@example.com",
        email_verified=True,
    )
    
    assert user.sub == "user-123"
    assert user.supabase_uid == "user-123"  # Alias
    assert user.email == "test@example.com"
    assert user.email_verified is True


def test_authenticated_user_minimal():
    """Test AuthenticatedUser with minimal fields."""
    user = AuthenticatedUser(sub="user-456")
    
    assert user.sub == "user-456"
    assert user.email is None
    assert user.email_verified is False


def test_invalid_token_error():
    """Test InvalidTokenError."""
    error = InvalidTokenError("bad token")
    assert error.status_code == 401
    assert error.message == "bad token"


def test_expired_token_error():
    """Test ExpiredTokenError."""
    error = ExpiredTokenError()
    assert error.status_code == 401
    assert "expired" in error.message.lower()
