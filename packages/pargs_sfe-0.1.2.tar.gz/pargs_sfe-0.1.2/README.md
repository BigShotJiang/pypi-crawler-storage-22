# Pargs

> [!WARNING]
> This is not yet production ready, please wait for the 1.0.0 release

A small python extensible argument system.

## Supported sources

Native supported sources are command arguments, file (json and toml) and
environment variables.
You can glue them together with the `MultiParser` and give them priorities,
to control which arguments may overwrite each other.

## Syntax

Simple example:

```python
from pargs import configure

@dataclass
class Config:
    url: str
    secret: str
    use_tls: bool = True
    log_level: int = 2
...
def main():
    config = configure(Config)
```

## Comparison

Compared to the `argparse` module provided in the standard library,
this provides much fewer features.
This allows for a very small runtime-footprint (>10x faster).
