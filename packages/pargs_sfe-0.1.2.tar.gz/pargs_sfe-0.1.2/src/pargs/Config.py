import dataclasses
from typing import Any, List, Type, cast

from .Parsers import CliParser, EnvParser, MultiParser
from .Parameters import KwParam, Parameter, TypeCallback

def get_args(cls: Type) -> List[Parameter[Any]]:
    params = []
    for k,v in cls.__dataclass_fields__.items():
        default_exists, default = (True, v.default) if  dataclasses.MISSING != v.default else (False, None)
        params.append(KwParam.new_simple(k, tp=cast(TypeCallback,v.type) , default=default, required=default_exists == False, help=v.__doc__ or ""))
    return params

__pargs_singletons = {}

def configure[T](cls: Type[T]) -> T:
    if singleton := __pargs_singletons.get(cls):
        return singleton
    parser = MultiParser({
        0: CliParser(),
        1: EnvParser()
    }).add_params(get_args(cls))
    __pargs_singletons[cls] = cls(**parser.parse().ns.__dict__)
    return __pargs_singletons[cls]
