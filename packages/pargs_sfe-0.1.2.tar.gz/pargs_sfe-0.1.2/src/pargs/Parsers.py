from typing import Protocol, Self, List, Dict, Any, Sequence, runtime_checkable
from abc import abstractmethod
import os
import sys
import json
import tomllib

from .Parameters import FlagParam, KwParam, Parameter, Namespace, PositionalParam
from .Exceptions import PargsMissingArgument, PargsUnkownArgument, PargsException


class BaseParser:
    """Base class for parsers implementing some functionality"""

    def __init__(self):
        self._params: List[Parameter] = list()
        self._values: Dict[str, Any] = dict()

    def __repr__(self) -> str:
        return f"BaseParser{self._params!r}"

    def param_taken(self, param: Parameter) -> bool:
        """test wether the parameter is already present"""
        return any([p == param for p in self._params])

    @abstractmethod
    def parse(self, allow_missing: bool = False) -> Self:
        """resolve parameters"""
        ...

    def add_param(self, param: Parameter[Any]) -> Self:
        """add single param"""
        if self.param_taken(param):
            raise ValueError(f"Parameter already exists: {param}")
        self._params.append(param)
        return self

    def add_params(self, params: Sequence[Parameter[Any]]) -> Self:
        """add multiple params"""
        for p in params:
            self.add_param(p)
        return self

    def vars(self) -> Namespace:
        """return a namespace generated from the found values"""
        return Namespace(**{k: v for k, v in self._values.items()})

    def clear(self) -> Self:
        """clear the contents of the parser, effectively resetting it"""
        self._values.clear()
        self._params.clear()
        return self

    def help(self, prog: str = "") -> None:
        """
        Build and print a nicely formatted help/usage string from a list of parameters.
        """
        prog = prog or sys.argv[0]
        lines: list[str] = []
        lines.append("Usage:")
        lines.append(f"  {prog} [OPTIONS]")
        lines.append("\nOptions:")

        for p in self._params:
            match p:
                case KwParam(short=short, long=long, help=help_text, default=default):
                    opt = []
                    if short:
                        opt.append(f"-{short}")
                    if long:
                        opt.append(f"--{long}")
                    opts = ", ".join(opt)
                    default_str = (
                        f" (default: {default})" if default is not None else ""
                    )
                    lines.append(f"  {opts:<15}{help_text}{default_str}")

                case FlagParam(short=short, long=long, help=help_text, default=default):
                    opt = []
                    if short:
                        opt.append(f"-{short}")
                    if long:
                        opt.append(f"--{long}")
                    opts = ", ".join(opt)
                    default_str = f" [default: {'on' if default else 'off'}]"
                    lines.append(f"  {opts:<15}{help_text}{default_str}")

                case PositionalParam(target=target, help=help_text, default=default):
                    default_str = (
                        f" (default: {default})" if default is not None else ""
                    )
                    lines.append(f"  {target} {help_text}{default_str}")

                case _:
                    lines.append(f"  {p.target:<15} {p.help}")

        sys.stderr.write("\n".join(lines) + "\n")


class CliParser(BaseParser):
    """parse cli arguments"""

    def __init__(self):
        super().__init__()
        self.argv: List[str] = sys.argv[1:]

    def parse(self, allow_missing: bool = False) -> Self:
        """resolve parameters"""
        found_long: dict[str, int] = dict()
        found_short: dict[str, int] = dict()
        positional: dict[int, str] = dict()

        def _parse_single(param, idx) -> None:
            value = positional.get(idx + 1, None)
            try:
                self._values[param.target] = param.parse(value)
            except Exception as e:
                raise ValueError(
                    f"Exception occured when converting {param.target!r}; {idx=!r}; {e=!r}"
                )
            # Remove the consumed value from positional
            positional.pop(idx + 1, None)

        for i, item in enumerate(self.argv):
            match item:
                case str(s) if s.startswith("--") and len(s) > 2:
                    found_long[item[2:]] = i
                case str(s) if s.startswith("-") and len(s) == 2 and s[1] != "-":
                    found_short[s] = i
                case _:
                    positional[i] = item
        for param in self._params:
            match param:
                case FlagParam(long=long, short=short):
                    # Flags are set to True when present, False otherwise
                    if long and long in found_long:
                        self._values[param.target] = True
                    elif short and f"-{short}" in found_short:
                        self._values[param.target] = True
                case KwParam(long=long, short=short):
                    if long and (arg := found_long.get(long, None)) is not None:
                        _parse_single(param, arg)
                    elif short and (arg := found_short.get(f"-{short}", None)) is not None:
                        _parse_single(param, arg)
                    elif param.required:
                        raise PargsMissingArgument([param.target])
                case PositionalParam():
                    continue
                case _:
                    raise NotImplementedError(
                        "Other types of parameters are not supported"
                    )

        for param in [p for p in self._params if isinstance(p, PositionalParam)]:
            if param.position is not None:
                value = param.parse(positional.get(param.position))
                self._values[param.target] = value
                positional.pop(param.position)
        if len(positional) != 0:
            raise PargsUnkownArgument(list(positional.values()))

        # Apply defaults and check requirements for parameters that weren't set
        for param in self._params:
            if param.target not in self._values:
                value = param.parse(None)
                self._values[param.target] = value
                if value is None and param.required and not allow_missing:
                    raise PargsMissingArgument([param.target])

        return self


@runtime_checkable
class ArgParser(Protocol):
    """runtime checkable protocol for argument parsers"""

    def parse(self, allow_missing: bool) -> Self: ...
    def add_param(self, param: Parameter) -> Self: ...
    def vars(self) -> Namespace: ...


class EnvParser(BaseParser):
    """parse environment using optional prefix for all arguments"""

    def __init__(self, prefix: str = ""):
        self.prefix = prefix + "_" if prefix and prefix[-1] != "_" else ""
        super().__init__()

    def parse(self, allow_missing: bool = False):
        """resolve parameters"""
        for param in self._params:
            env_key = self.prefix + param.target.upper().replace("-", "_")
            value = param.parse(os.environ.get(env_key, None))
            self._values[param.target] = value
            if value is None and param.required and not allow_missing:
                raise PargsMissingArgument([param.target])
        return self


class FileParser(BaseParser):
    """base parser for file contents, could be extended for e.g. yaml"""

    def __init__(self, path: str):
        self.path: str = path
        super().__init__()


class JsonParser(FileParser):
    """parse a json file"""

    def parse(self, allow_missing: bool = False, **kwargs) -> Self:
        """
        parse the specified file as json.
        A list at top level is parsed as
        positional arguments
        :kwargs -- forward to `json.load`
        """
        with open(self.path) as f:
            d = json.load(f, **kwargs)
        if isinstance(d, list):
            for p in self._params:
                match p:
                    case PositionalParam(target=target, position=pos):
                        if (pos := p.position) and len(d) > pos:
                            self._values[target] = p.parse(d[pos])
                        elif p.required and not allow_missing:
                            raise PargsMissingArgument([p.target])
        elif isinstance(d, dict):
            for p in self._params:
                match p:
                    case PositionalParam(target=target):
                        raise PargsUnkownArgument([target])
                    case (
                        KwParam(target=target, long=long)
                        | FlagParam(target=target, long=long)
                    ):
                        self._values[target] = p.parse(
                            d.get(target, None) or d.get(long, None)
                        )
                    case Parameter(target=target):
                        self._values[target] = p.parse(d.get(target, None))
                    case _:
                        raise PargsUnkownArgument([p.target])

        return self


class TomlParser(FileParser):
    """parses a toml file, positional arguments are not allowed"""

    def add_param(self, param: Parameter) -> Self:
        if isinstance(param, PositionalParam):
            raise PargsUnkownArgument([param.target])
        return super().add_param(param)

    def parse(self, allow_missing: bool = False, parse_float=float) -> Self:
        """
        parse the spefified file as toml.

        positional arguments
        :parse_float -- forward to `tomllib.load`
        """
        _ = allow_missing
        with open(self.path, "rb") as f:
            d = tomllib.load(f, parse_float=parse_float)
        for p in self._params:
            match p:
                case (
                    KwParam(target=target, long=long)
                    | FlagParam(target=target, long=long)
                ):
                    value = d.get(target, None) or d.get(long, None)
                    self._values[p.target] = p.parse(value)
                case Parameter(target=target):
                    self._values[target] = d.get(target, None)
                case _:
                    raise PargsUnkownArgument([p.target])

        return self


class MultiParser(BaseParser):
    """glue to add multiple sources for configuration together"""

    def __init__(self, parsers: Dict[int, ArgParser] = {}):
        super().__init__()
        self.parsers: Dict[int, ArgParser] = parsers
        self.ns: Namespace = Namespace()
        self.max = max(parsers.keys()) if parsers else 0

    def add_parser(self, parser: ArgParser, priority: int = -1) -> Self:
        """add parser as source for config, priority defaults to next available value"""
        if priority < 0:
            self.parsers[self.max] = parser
            self.max += 1
        elif old := self.parsers.get(priority):
            raise PargsException(
                f"Parser with priority {priority} already exists ({old.__class__.__name__})"
            )
        else:
            self.parsers[priority] = parser
            if priority > self.max:
                self.max = priority + 1

        return self

    def parse(self, allow_missing: bool = True) -> Self:
        for _, parser in sorted(
            self.parsers.items(), key=lambda pp: pp[0], reverse=True
        ):
            for p in self._params:
                parser.add_param(p)
            self.ns |= parser.parse(allow_missing=allow_missing).vars()
        return self

    def vars(self) -> Namespace:
        return self.ns

class FastCliParser(BaseParser):
    """Minimal, fast CLI argument parser with O(n) complexity"""
    
    __slots__ = ('_params', '_values', '_param_map', 'argv')
    
    def __init__(self, argv: List[str] | None = None):
        self._params: List[Parameter] = []
        self._values: Dict[str, Any] = {}
        # Fast lookup maps
        self._param_map: Dict[str, Parameter] = {}
        self.argv = argv or sys.argv[1:]  # Skip program name
    
    def add_param(self, param: Parameter) -> Self:
        """Add parameter with O(1) lookup mapping"""
        if isinstance(param, (KwParam, FlagParam)):
            if param.short:
                key = f"-{param.short}"
                if key in self._param_map:
                    raise ValueError(f"Duplicate parameter: {key}")
                self._param_map[key] = param
            if param.long:
                key = f"--{param.long}"
                if key in self._param_map:
                    raise ValueError(f"Duplicate parameter: {key}")
                self._param_map[key] = param
        
        self._params.append(param)
        return self
    
    def parse(self, allow_missing: bool = False) -> Self:
        """Fast single-pass parser with O(n) complexity"""
        i = 0
        positional_values: List[str] = []
        positional_params = [p for p in self._params if isinstance(p, PositionalParam)]
        
        while i < len(self.argv):
            arg = self.argv[i]
            
            # Handle long option with = syntax: --key=value
            if arg.startswith('--') and '=' in arg:
                key, value = arg.split('=', 1)
                param = self._param_map.get(key)
                if param is None:
                    raise PargsUnkownArgument([arg])
                self._values[param.target] = param.parse(value)
                i += 1
                continue
            
            # Handle short/long options
            if arg.startswith('-'):
                param = self._param_map.get(arg)
                if param is None:
                    raise PargsUnkownArgument([arg])

                if isinstance(param, FlagParam):
                    # Flags don't consume next argument, set directly to True
                    self._values[param.target] = True
                else:
                    # KwParam needs a value
                    if i + 1 >= len(self.argv):
                        raise PargsMissingArgument([param.target])
                    self._values[param.target] = param.parse(self.argv[i + 1])
                    i += 2
                    continue
                i += 1
                continue
            
            # Collect positional arguments
            positional_values.append(arg)
            i += 1
        
        # Process positional parameters
        positional_params.sort(key=lambda p: p.position)
        for param in positional_params:
            if param.position < len(positional_values):
                value = positional_values[param.position]
                self._values[param.target] = param.parse(value)
            elif param.required:
                raise PargsMissingArgument([param.target])
            elif param.default is not None:
                self._values[param.target] = param.default
        
        # Check for extra positional arguments
        expected_positional = len(positional_params)
        if len(positional_values) > expected_positional:
            extra = positional_values[expected_positional:]
            raise PargsUnkownArgument(extra)
        
        # Check required parameters and set defaults
        for param in self._params:
            if param.target not in self._values:
                if param.required:
                    raise PargsMissingArgument([param.target])
                elif hasattr(param, "default") and param.default is not None: # pyright: ignore
                    self._values[param.target] = param.default # pyright: ignore
        
        return self
    
    def vars(self) -> Namespace:
        """Return namespace with parsed values"""
        return Namespace(**self._values)
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get parsed value directly"""
        return self._values.get(key, default)
    
    def __getitem__(self, key: str) -> Any:
        """Dict-like access to parsed values"""
        return self._values[key]
    
    def clear(self) -> Self:
        """Reset parser state"""
        self._values.clear()
        return self
    
    def __repr__(self) -> str:
        return f"FastCliParser(params={len(self._params)}, values={self._values})"


class MinimalCliParser(BaseParser):
    """Even more minimal parser - only supports keyword args and flags"""
    
    __slots__ = ('_params', '_values', 'argv')
    
    def __init__(self, argv: List[str] | None = None):
        super().__init__()
        self.argv = argv or sys.argv[1:]
    
    def parse(self, allow_missing: bool = False) -> Self:
        """Ultra-fast parser - builds lookup dict on-the-fly"""
        # Build lookup map
        param_map: Dict[str, KwParam | FlagParam] = {}
        for p in self._params:
            if isinstance(p, (KwParam, FlagParam)):
                if p.short:
                    param_map[f"-{p.short}"] = p
                if p.long:
                    param_map[f"--{p.long}"] = p

        i = 0
        while i < len(self.argv):
            arg = self.argv[i]

            # Handle --key=value
            if '=' in arg and arg.startswith('-'):
                key, value = arg.split('=', 1)
                param = param_map.get(key)
                if param and isinstance(param, KwParam) and not isinstance(param, FlagParam):
                    self._values[param.target] = param.parse(value)
                i += 1
                continue

            param = param_map.get(arg)
            if param:
                if isinstance(param, FlagParam):
                    self._values[param.target] = True
                    i += 1
                else:
                    if i + 1 < len(self.argv):
                        self._values[param.target] = param.parse(self.argv[i + 1])
                        i += 2
                    else:
                        i += 1
            else:
                i += 1

        # Set defaults for missing values
        for p in self._params:
            if p.target not in self._values:
                if hasattr(p, "default") and p.default is not None: # pyright: ignore
                    self._values[p.target] = p.default # pyright: ignore

        return self

    def add_param(self, param: Parameter[Any]) -> Self:
        if type(param) in [KwParam, FlagParam]:
            return super().add_param(param)
        else:
            raise NotImplementedError(f"MinimalCliParser does not implement param {type(param)}")
    
    def vars(self) -> Namespace:
        return Namespace(**self._values)
    
    def get(self, key: str, default: Any = None) -> Any:
        return self._values.get(key, default)
