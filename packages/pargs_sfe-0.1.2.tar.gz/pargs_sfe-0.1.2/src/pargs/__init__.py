from .Config import (
    configure
)

__all__ = [
    "configure"
]

__version__ = "0.1.1"
