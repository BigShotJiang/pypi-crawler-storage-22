"""Personal AI Chat Web UI."""

__version__ = "0.5.3"
