"""Camera calibration data files."""
