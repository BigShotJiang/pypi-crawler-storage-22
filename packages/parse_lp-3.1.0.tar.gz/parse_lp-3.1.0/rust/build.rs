fn main() {
    lalrpop::process_root().unwrap();
}
