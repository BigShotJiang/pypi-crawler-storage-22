API reference
=============

parsel.csstranslator
--------------------

.. automodule:: parsel.csstranslator
    :members:
    :undoc-members:
    :show-inheritance:


.. _topics-selectors-ref:

parsel.selector
---------------

.. automodule:: parsel.selector
    :members:
    :undoc-members:
    :show-inheritance:


parsel.utils
------------

.. automodule:: parsel.utils
    :members:
    :undoc-members:
    :show-inheritance:
