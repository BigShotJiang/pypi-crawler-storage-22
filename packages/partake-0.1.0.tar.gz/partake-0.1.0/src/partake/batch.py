from dataclasses import dataclass
import io
from typing import Tuple

@dataclass
class Batch:
    data: bytes
    start: int | None = None
    end: int | None = None

    def extract_line_count(self) -> int:
        """
        Returns:
            int: number of lines in 'data'
        """
        if not self.data:
            return 0

        newline_count = self.data.count(b'\n')

        # Check against ASCII integer 10
        if self.data[-1] != 10:
            return newline_count + 1
            
        return newline_count

    @property
    def byte_count(self) -> int:
        """
        Returns:
            int: number of bytes in 'data'
        """
        return len(self.data)

    @property
    def has_line_count(self) -> bool:
        """
        Returns:
            bool: If True, line_count has been extracted
        """
        return (self.start is not None) and (self.end is not None)

    @property
    def line_count(self) -> int | None:
        """
        Returns:
            int | None: Number of lines extracted by 'extract_line_count' if it has been called,
            otherwise None.
        """
        if self.has_line_count:
            return self.end - self.start
        else:
            return None

    @property
    def line_bounds(self) -> Tuple[int,int] | None:
        if self.has_line_count:
            return tuple([self.start, self.end])
        else:
            return None

def read_batch(io: io.BufferedIOBase, size: int) -> Batch | None:
    """
    Rapidly read bytes from source, guaranteeing it ends on newline/EOF.

    Blocks until read is complete. Output is Batch with 'size' bytes of data plus
    small extension to reach newline. When EOF is detected, actual data size
    is typically less than 'size.' Returns None if no data read.
    """
    data = b""

    # Get large block of bytes (high throughput)
    if size > 0:
        data += io.read(size)
    # Tack on rest of line (small read)
    data += io.readline()
    # Output guaranteed to end on newline or EOF
    if data:
        return Batch(data=data)