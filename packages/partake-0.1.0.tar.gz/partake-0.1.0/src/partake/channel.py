from abc import ABC, abstractmethod
from dataclasses import dataclass
import subprocess
import os
from typing import Any, Tuple, IO
from pathlib import Path

@dataclass
class Channel(ABC):
    io: IO | None = None

    @abstractmethod
    def create(self, **kwargs) -> Any:
        pass

    @abstractmethod
    def open(self, mode: str = "rb") -> Any:
        pass

    def close(self):
        if self.io is not None:
            self.io.close()

    def write(self, data: bytes):
        self.io.write(data)
        self.io.flush()

@dataclass
class SubprocessChannel(Channel):
    """Represents the standard stdin/stdout/stderr streams."""
    def create(self, **kwargs) -> int:
        return subprocess.PIPE
    
    def open(self, mode: str = "rb") -> int:
        return subprocess.PIPE

@dataclass
class AnonChannel(Channel):
    """
    An in-memory anonymous pipe.
    Usage: 'open()' wraps the raw FD in a Python file object.
    Warning: Do not open the same mode twice, or the FD may be double-closed.
    """
    r: int | None = None
    w: int | None = None
    
    def create(self, **kwargs) -> Tuple[int, int]:
        self.r, self.w = os.pipe()
        return self.r, self.w
    
    def open(self, mode: str = "rb") -> IO:
        if "r" in mode:
            if self.r is None: raise ValueError("Pipe not created")
            return os.fdopen(self.r, mode)
        elif "w" in mode:
            if self.w is None: raise ValueError("Pipe not created")
            return os.fdopen(self.w, mode)
        raise ValueError(f"Invalid mode for AnonChannel: {mode}")

@dataclass
class PathChannel(Channel):
    """Abstract base for channels that live on the filesystem."""
    name: str | None = None
    template: str | None = None

    def set_name(self, **kwargs):
        if self.name:
            pass
        elif self.template:
            self.name = self.template.format(task_id=kwargs.get("task_id"))
        else:
            raise ValueError("No name or template specified.")

class FifoChannel(PathChannel):
    """A named pipe (FIFO) on the filesystem."""
    def create(self, **kwargs) -> str:
        self.set_name(**kwargs)
        try:
            os.mkfifo(self.name)
        except FileExistsError:
            pass
        return self.name

    def open(self, mode: str = "rb") -> IO:
        """
        Open FIFO. Blocks until the other end is opened (unless O_NONBLOCK used).
        """
        if not self.name: raise ValueError("Name not set")
        if not Path(self.name).exists(): raise FileNotFoundError(f"{self.name} not found.")
        
        # We use os.open first to allow flag control (if needed later)
        # and to ensure correct FIFO handling behavior.
        try:
            flags = os.O_WRONLY if "w" in mode else os.O_RDONLY
            fd = os.open(self.name, flags)
            return os.fdopen(fd, mode)
        except OSError:
            raise

@dataclass
class FileChannel(PathChannel):
    """A standard file on disk."""
    def create(self, **kwargs):
        self.set_name(**kwargs)
        # touch() ensures the file exists so open() doesn't fail on read,
        # but standard open('wb') would create it anyway. 
        # Keeping this for consistency with the 'create/open' lifecycle.
        Path(self.name).touch(mode=0o666, exist_ok=True)

    def open(self, mode: str = "rb") -> IO:
        if not self.name: raise ValueError("Name not set")
        # Standard open provides buffering and creation logic
        return open(self.name, mode=mode)