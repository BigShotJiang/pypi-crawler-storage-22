import sys
import click
from typing import Tuple
from functools import partial
from .channel import SubprocessChannel, AnonChannel, FifoChannel, FileChannel
from .log import update_logger
from .task import Task
from .source import Source
from .worker import Worker
from .manager import Manager


def get_size_unit(size_unit_string: str, unit: str) -> Tuple[float,str] | None:
    try:
        unit_idx = size_unit_string.index(unit)
        size = float(size_unit_string[:unit_idx])

        return size, unit
    except:
        return None

def get_size_bytes(size: str) -> int:
    
    try:
        # Is size an integer?
        return int(size)
    except:
        pass
    
    try:
        # Is 'size' a multiplication expression?
        op_pos = size.index("*")
        a = float(size[:op_pos])
        b = float(size[op_pos+1:])
        return int(a*b)
    except:
        pass

    # Is 'size' a value, then unit in B, KB, MB, GB, TB?
    # I.e. 1MB or 1 MB
    size_unit = get_size_unit(size, "B")
    if size_unit:
        result = size_unit[0]
    size_unit = get_size_unit(size, "KB")
    if size_unit:
        result = size_unit[0] * 1024
    size_unit = get_size_unit(size, "MB")
    if size_unit:
        result = size_unit[0] * 1024**2
    size_unit = get_size_unit(size, "GB")
    if size_unit:
        result = size_unit[0] * 1024**3
    size_unit = get_size_unit(size, "TB")
    if size_unit:
        result = size_unit[0] * 1024**4
    try:
        return int(result)
    except:
        raise ValueError(f"Unable to parse size {size}")    

def get_stream_type(template: str, is_pipe: bool):
    if template:
        if is_pipe:
            StreamType = partial(FifoChannel, template=template)
        else:
            StreamType = partial(FileChannel, template=template)
    else:
        StreamType = SubprocessChannel
    return StreamType


@click.command()
@click.option("-w", "--workers", "n_workers", type=int, default=1)
@click.option("-i", "--input", "job_input", type=str, default="-")
@click.option("-o", "--output", "output_template", type=str, default="{job}.out")
@click.option("-e", "--error", "error_template", type=str, default="{job}.err")
@click.option("--po/--fo", "--pipe-output/--file-output", "pipe_output", is_flag=True, default=False)
@click.option("--pe/--fe", "--pipe-error/--file-error", "pipe_error", is_flag=True, default=False)
@click.option("-s", "--size", type=str, default="50 MB")
@click.option("--bg", is_flag=True, default=False)
@click.option("-n", "--line-numbers", "join_line_numbers", is_flag=True, default=False)
@click.option("-v", "--verbosity", "log_level", type=click.Choice(["DEBUG", "INFO", "ERROR"]), default="INFO")
@click.argument("command", type=str)
def partake_cli(n_workers, job_input, output_template, error_template, pipe_output, pipe_error, size, bg, join_line_numbers, log_level, command):
    """
    Shard text to persistent parallel jobs at the rate of a pipe.
    """
    update_logger(log_level)
    source_io = open(job_input, "r") if (job_input and job_input != "-") else sys.stdin.buffer
    size_bytes = get_size_bytes(size)
    OutputStreamType = get_stream_type(output_template, pipe_output)
    ErrorStreamType = get_stream_type(error_template, pipe_error)  

    source = Source(
        io = source_io,
        size = size_bytes
    )
    workers = [
        Worker(
            task = Task(
                command = command,
                stdin = SubprocessChannel(),
                line_numbers = AnonChannel(),
                stdout = OutputStreamType(),
                stderr = ErrorStreamType()
            )
        )
        for _ in range(n_workers)
    ]
    manager = Manager(
        source = source,
        workers = workers
    )
    manager.run(daemonize = bg, join_lines = True, join_line_numbers = join_line_numbers)