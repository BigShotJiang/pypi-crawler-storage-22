from dataclasses import dataclass, field
from threading import Event
from queue import Queue, Empty
from .batch import Batch
from .source import Source
from .log import logger, Logger

@dataclass
class Coordinator:
    batch_queue: Queue = field(default_factory = lambda: Queue())
    error_event: Event = field(default_factory = lambda: Event())
    eof: Event = field(default_factory = lambda: Event())
    timeout: float = 1.
    log: Logger | None = None

    def __post_init__(self):
        self.log = logger.bind(object = "Coordinator")

    @property
    def getting_batches(self) -> bool:
        "Check if workers should be getting batches"
        return (
            not self.error_event.is_set()
            and not self.eof.is_set()
        )
    
    @property
    def writing_batches(self) -> bool:
        return not self.error_event.is_set()

    def scatter(self, source: Source):
        """Read batches and transfer to common queue"""
        self.log.debug("Scattering")
        start = 0
        while batch := source.read_batch():
            logger.debug("Read batch")
            batch.start = start
            batch.end = batch.start + batch.extract_line_count()
            start = batch.end
            self.batch_queue.put(batch)
        
        logger.debug("Joining on batch_queue")
        self.batch_queue.join()

    def get_batch(self) -> Batch | None:
        "Returns a new Batch or None on timeout"
        try:
            return self.batch_queue.get(timeout = self.timeout)
        except Empty:
            return None

    def task_done(self):
        self.batch_queue.task_done()