import sys
import faulthandler
import signal
from loguru import logger
from loguru._logger import Logger

# Dumps stack trace of all running threads
faulthandler.register(signal.SIGUSR1)

# Remove default handler
def update_logger(level: str = "DEBUG"):
    logger.remove()

    # Add concurrency-friendly handler
    logger.add(
        sys.stderr, 
        format="<green>{time:HH:mm:ss.SSS}</green> | "
            "<cyan>{thread.name: <15}</cyan> | "
            "<level>{message}</level> | "
            "<dim>{extra}</dim>",
        level=level,
        enqueue=True  # Thread-safe logging queue
    )