from dataclasses import dataclass, field
from threading import Thread, Event
from queue import Queue
import sys
import os
from typing import List
from .coordinator import Coordinator, Source
from .worker import Worker
from .log import logger, Logger

@dataclass
class Manager:
    source: Source
    workers: List[Worker]
    log: Logger | None = None

    def __post_init__(self):
        self.log = logger.bind(object = "Manager")

    def run(self, daemonize: bool = False, join_lines: bool = True, join_line_numbers: bool = False):
        coordinator = self.create()
        if daemonize:
            self.daemonize()
        self.start(coordinator = coordinator)
        coordinator.scatter(self.source)
        self.join(lines = join_lines, line_numbers = join_line_numbers)
        self.close()

    def create(self) -> Coordinator:
        self.log.debug("Create")
        coordinator = Coordinator()
        for worker in self.workers:
            worker.coordinator = coordinator
            worker.create()
        return coordinator
    
    def start(self, coordinator: Coordinator):
        self.log.debug("Starting")
        for worker in self.workers:
            worker.start(coordinator = coordinator)

    def join(self, lines: bool, line_numbers: bool):
        self.log.debug("Joining")
        join_threads = []
        if lines:
            self.log.debug("Joining on lines writer")
            join_threads.append(Thread(target = self.join_lines))
        if line_numbers:
            self.log.debug("Joining on line_numbers writer")
            join_threads.append(Thread(target = self.join_line_numbers))
        for thread in join_threads:
            thread.start()
            thread.join()

    def join_lines(self):
        for worker in self.workers:
            worker.line_queue.join()
    
    def join_line_numbers(self):
        for worker in self.workers:
            worker.line_number_queue.join()

    def close(self):
        self.log.debug("Closing")
        self.source.close()
        for worker in self.workers:
            worker.close()

    def daemonize(self, log_file: str = "/dev/null"):
        """
        Detach from the terminal using the Double Fork pattern.
        """
        self.log.debug("Daemonizing")
        # 1. Flush buffers
        sys.stdout.flush()
        sys.stderr.flush()

        # 2. PRESERVE INPUT
        # If source is stdin (FD 0), move it to a safe FD (e.g. 3) before nuking FD 0.
        if hasattr(self.source, "fileno") and self.source.fileno() == 0:
            saved_fd = os.dup(0)
            # Re-wrap the safe FD into a new file object.
            # buffering=0 is standard for pipe throughput; adjust if line-buffering is preferred.
            self.source = os.fdopen(saved_fd, "rb", buffering=0)

        # 3. FORK #1 (Detach from Parent)
        try:
            if os.fork() > 0:
                sys.exit(0) # Parent returns to shell
        except OSError as e:
            sys.exit(f"Fork #1 failed: {e}")

        # --- CHILD (Session Leader) ---
        
        # 4. NEW SESSION
        os.setsid()

        # 5. FORK #2 (Prevent TTY Acquisition)
        try:
            if os.fork() > 0:
                sys.exit(0) # Leader dies
        except OSError as e:
            sys.exit(f"Fork #2 failed: {e}")

        # --- GRANDCHILD (Daemon) ---

        # 6. REDIRECT STREAMS
        # Point 0, 1, 2 to /dev/null or logfile
        devnull = os.open(os.devnull, os.O_RDWR)
        log_fd = os.open(log_file, os.O_WRONLY | os.O_CREAT | os.O_APPEND)

        # stdin -> /dev/null (We already saved the real input to self.source)
        os.dup2(devnull, 0)
        # stdout -> log
        os.dup2(log_fd, 1)
        # stderr -> log
        os.dup2(log_fd, 2)

        if devnull > 2: os.close(devnull)
        if log_fd > 2: os.close(log_fd)



