from dataclasses import dataclass
from typing import IO
from .batch import Batch, read_batch

@dataclass
class Source:
    io: IO | None = None
    size: int = 50 * 1024 ** 2

    def read_batch(self) -> Batch | None:
        return read_batch(io = self.io, size = self.size)

    def close(self):
        if self.io is not None:
            self.io.close()
