import time
import os
import sys
from dataclasses import dataclass, field
from threading import Thread, Event
from queue import Queue, Empty
from typing import List, Literal, ClassVar, Dict, Tuple
from subprocess import Popen
from .channel import Channel, AnonChannel, PathChannel
from .log import logger, Logger

@dataclass
class Task:
    command: str | List[str] | None = None
    stdin: Channel | None = None
    line_numbers: AnonChannel | PathChannel | None = None
    stdout: Channel | None = None
    stderr: Channel | None = None
    process: Popen | None = None
    started: Event = field(default_factory = lambda: Event())
    task_id: int = field(default_factory = lambda: Task.get_task_id())
    log: Logger | None = None

    NEXT_TASK_ID: ClassVar[int] = 0

    def __post_init__(self):
        self.log = logger.bind(task_id = self.task_id)

    @staticmethod
    def get_task_id() -> int:
        "Get auto-incrementing task ID"
        task_id = Task.NEXT_TASK_ID
        Task.NEXT_TASK_ID += 1
        return task_id
    
    def create(self):
        self.log.debug("Creating channels")
        self.stdin.create(task_id = self.task_id)
        self.line_numbers.create(task_id = self.task_id)
        self.stdout.create(task_id = self.task_id)
        self.stderr.create(task_id = self.task_id)        

    def start_side_channels(self) -> Tuple[Dict[str,str], List[int]]:
        "Update environment with side channel FDs and create"
        self.log.debug("Creating side channels")
        env = os.environ.copy()
        env["PARTAKE_TASK_ID"] = str(self.task_id)

        self.line_numbers.create(task_id = self.task_id)
        pass_fds = []
        match self.line_numbers:
            case AnonChannel():
                env["PARTAKE_LINE_NUMBERS_FD"] = str(self.line_numbers.r)
                pass_fds = [self.line_numbers.r]
            case PathChannel():
                env["PARTAKE_LINE_NUMBERS_PATH"] = str(self.line_numbers.path)
            case _:
                raise TypeError(f"line_numbers must be AnonChannel or PathChannel, not {type(self.line_numbers)}")
        return env, pass_fds

    def close_unneeded_fds(self):
        "Close unneeded anonymous pipe ends"
        self.log.debug("Closing unneeded FDs")
        def close_anon(channel: Channel, which: Literal["w", "r"]):
            if isinstance(channel, AnonChannel):
                fd = channel.w if which == "w" else channel.r
                os.close(fd)
        close_anon(self.stdin, "r")
        close_anon(self.line_numbers, "r")
        close_anon(self.stdout, "w")
        close_anon(self.stderr, "w")

    def open_channels(self):
        "Open channel 'io' handles"
        self.log.debug("Opening channels")
        self.stdin.io = self.process.stdin
        self.line_numbers.io = self.line_numbers.open("wb")
        self.stdout.io = self.process.stdout
        self.stderr.io = self.process.stderr

    def start(self):
        "Create process and open channels"
        self.log.debug("Starting task")
        env, pass_fds = self.start_side_channels()
        self.process = Popen(
            args = self.command,
            shell = isinstance(self.command, str),
            stdin = self.stdin.open("rb"),
            stdout = self.stdout.open("wb"),
            stderr = self.stdout.open("wb"),
            env = env,
            pass_fds = pass_fds,
            close_fds = True
        )
        self.open_channels()
        self.close_unneeded_fds()
        self.started.set()

    def write(self, channel: Literal["lines", "line_numbers"], data: bytes):
        "Write data type to appropriate channel"
        self.log.debug(f"Writing {channel}")
        match channel:
            case "lines": self.stdin.write(data)
            case "line_numbers": self.line_numbers.write(data)

    def close(self):
        self.log.debug("Closing task")
        self.stdin.close()
        self.line_numbers.close()
        self.stdout.close()
        self.stderr.close()