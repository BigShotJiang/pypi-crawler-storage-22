import time
from dataclasses import dataclass, field
from threading import Thread, Event
from queue import Queue, Empty
from typing import List, Literal, Tuple
from .coordinator import Coordinator
from .batch import Batch
from .task import Task
from .log import logger, Logger


@dataclass
class Worker:
    task: Task | None = None
    coordinator: Coordinator | None = None
    threads: List[Thread] | None = None
    line_queue: Queue | None = None
    line_bounds_queue: Queue | None = None
    started: Event = field(default_factory = lambda: Event())
    timeout: float = 1.0
    log: Logger | None = None

    def __post_init__(self):
        self.log = logger.bind(object = "Worker", task_id = self.task.task_id)

    def create(self):
        self.task.create()

    def start(self, coordinator: Coordinator):
        "Start setup, batch, and writer threads"
        self.log.debug("Starting")
        self.coordinator = coordinator
        self.line_queue = Queue()
        self.line_bounds_queue = Queue()
        self.threads = [
            Thread(target = self.task.start),
            Thread(target = self.get_batches),
            Thread(target = self.write_lines),
            Thread(target = self.write_line_numbers)
        ]
        for thread in self.threads:
            thread.start()
        self.started.set()

    def close(self):
        self.task.close()

    @property
    def ready(self) -> bool:
        "Is task and worker started?"
        return self.task.started.is_set() and self.started.is_set()

    @property
    def starting(self) -> bool:
        "Is coordinator working, but task or worker is not started?"
        return self.coordinator.getting_batches and not self.ready

    def wait_until_started(self):
        "Delay until setup is complete"
        self.log.debug("Waiting until started")
        while self.starting:
            time.sleep(.01)

    def get_batches(self) -> Batch | None:
        "Distribute data from common Batch queue to writer threads"
        self.wait_until_started()

        self.log.debug("Getting batches")
        while self.coordinator.getting_batches:
            batch = self.coordinator.get_batch()
            
            if batch is None:
                continue

            self.line_queue.put(batch.data)

            batch.extract_line_count()
            self.line_bounds_queue.put(batch.line_bounds)
            self.coordinator.task_done()

    def write(self, channel: Literal["lines", "line_numbers"], data: bytes, data_queue: Queue):
        "Write data to channel and mark task as done"
        try:
            self.task.write(channel, data)
            data_queue.task_done()
        except:
            self.coordinator.error_event.set()

    def write_lines(self):
        self.wait_until_started()

        self.log.debug("Writing lines")
        while self.coordinator.writing_batches:
            try:
                lines = self.line_queue.get(timeout = self.timeout)
            except Empty:
                continue
            self.log.debug("Writing batch lines")
            self.write("lines", lines, self.line_queue)
            self.log.debug("Done writing batch lines")

    def get_line_numbers(self, line_bounds: Tuple[int, int]) -> bytes:
        "Convert first and last line index to bytes"
        return b"".join([
            str(line_number).encode() 
            for line_number 
            in range(*line_bounds)
        ])

    def write_line_numbers(self):
        self.wait_until_started()

        self.log.debug("Writing line numbers")
        while self.coordinator.writing_batches:
            try:
                line_bounds = self.line_bounds_queue.get(timeout = self.timeout)
            except Empty:
                continue
            line_numbers = self.get_line_numbers(line_bounds)

            self.log.debug("Writing batch line_numbers")
            self.write("line_numbers", line_numbers, self.line_bounds_queue)
            self.log.debug("Done writing batch line_numbers")
            
