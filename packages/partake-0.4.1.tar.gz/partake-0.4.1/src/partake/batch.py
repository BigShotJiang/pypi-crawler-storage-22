from dataclasses import dataclass
import io
from typing import Tuple

@dataclass
class Batch:
    text: bytes
    start: int | None = None
    end: int | None = None

    def extract_line_count(self) -> int:
        """
        Returns:
            int: number of lines in 'data'
        """
        if not self.text:
            return 0

        newline_count = self.text.count(b'\n')

        # Check against ASCII integer 10
        if self.text[-1] != 10:
            return newline_count + 1
            
        return newline_count

    @property
    def byte_count(self) -> int:
        """
        Returns:
            int: number of bytes in 'data'
        """
        return len(self.text)

    @property
    def has_line_count(self) -> bool:
        """
        Returns:
            bool: If True, line_count has been extracted
        """
        return (self.start is not None) and (self.end is not None)

    @property
    def line_count(self) -> int | None:
        """
        Returns:
            int | None: Number of lines extracted by 'extract_line_count' if it has been called,
            otherwise None.
        """
        if self.has_line_count:
            return self.end - self.start
        else:
            return None

    @property
    def line_bounds(self) -> Tuple[int,int] | None:
        if self.has_line_count:
            return tuple([self.start, self.end])
        else:
            return None

    @property
    def line_numbers(self) -> bytes:
        line_bounds = self.line_bounds
        if line_bounds is None:
            return b""
        else:
            return b"".join([str(num).encode() for num in range(self.start, self.end)])

def read_batch(source: io.BufferedIOBase, size: int) -> Batch | None:
    """
    Rapidly read bytes from source, guaranteeing it ends on newline/EOF.

    Blocks until read is complete. Output is Batch with 'size' bytes of data plus
    small extension to reach newline. When EOF is detected, actual data size
    is typically less than 'size.' Returns None if no data read.
    """
    text = b""

    # Get large block of bytes (high throughput)
    if size > 0:
        text += source.read(size)
    # Tack on rest of line (small read)
    text += source.readline()
    # Output guaranteed to end on newline or EOF
    if text:
        return Batch(text=text)