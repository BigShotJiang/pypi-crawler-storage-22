import sys
import click
from typing import Tuple
import threading
from functools import partial
from importlib.metadata import version
from subfeed import *
from .batch import Batch, read_batch

def get_size_unit(size_unit_string: str, unit: str) -> Tuple[float,str] | None:
    try:
        unit_idx = size_unit_string.index(unit)
        size = float(size_unit_string[:unit_idx])

        return size, unit
    except:
        return None

def get_size_bytes(size: str) -> int:
    
    try:
        # Is size an integer?
        return int(size)
    except:
        pass
    
    try:
        # Is 'size' a multiplication expression?
        op_pos = size.index("*")
        a = float(size[:op_pos])
        b = float(size[op_pos+1:])
        return int(a*b)
    except:
        pass

    # Is 'size' a value, then unit in B, KB, MB, GB, TB?
    # I.e. 1MB or 1 MB
    size_unit = get_size_unit(size, "B")
    if size_unit:
        result = size_unit[0]
    size_unit = get_size_unit(size, "KB")
    if size_unit:
        result = size_unit[0] * 1024
    size_unit = get_size_unit(size, "MB")
    if size_unit:
        result = size_unit[0] * 1024**2
    size_unit = get_size_unit(size, "GB")
    if size_unit:
        result = size_unit[0] * 1024**3
    size_unit = get_size_unit(size, "TB")
    if size_unit:
        result = size_unit[0] * 1024**4
    try:
        return int(result)
    except:
        raise ValueError(f"Unable to parse size {size}")    

def get_stream_type(template: str, is_pipe: bool):
    if template:
        if is_pipe:
            # TODO
            raise NotImplementedError("FifoChannel not implemented yet")
            StreamType = partial(FifoChannel, template=template)
        else:
            StreamType = partial(FileChannel, template=template)
    else:
        StreamType = SubprocessChannel
    return StreamType

@click.command(context_settings={"help_option_names": ["-h", "--help"]})
@click.option(
    "-n", "--workers", "n_workers", 
    type=int, 
    default=1, 
    show_default=True, 
    help="Number of persistent parallel worker processes to spawn."
)
@click.option(
    "-i", "--input", "input_path", 
    type=str, 
    default="-", 
    show_default=True,
    help="Input source. Use '-' for stdin."
)
@click.option(
    "-o", "--output", "output_template", 
    type=str, 
    default="{id}.out", 
    show_default=True,
    help="Template for worker stdout. Use '{id}' for the worker index (e.g. 'part_{id}.txt')."
)
@click.option(
    "-e", "--error", "error_template", 
    type=str, 
    default="{id}.err", 
    show_default=True,
    help="Template for worker stderr. Use '{id}' for the worker index."
)
# @click.option(
#     "--po/--fo", "--pipe-output/--file-output", "pipe_output", 
#     is_flag=True, 
#     default=False, 
#     help="Create named pipes (FIFOs) for output instead of standard files."
# )
# @click.option(
#     "--pe/--fe", "--pipe-error/--file-error", "pipe_error", 
#     is_flag=True, 
#     default=False, 
#     help="Create named pipes (FIFOs) for error streams instead of standard files."
# )
@click.option(
    "-s", "--size", "batch_size", 
    type=str, 
    default="50 MB", 
    show_default=True,
    help="Target size for each batch. Accepts units (KB, MB, GB)."
)
@click.option(
    "-x", "--idx", "--row-index", "--line-numbers", "write_all_line_numbers", 
    is_flag=True, 
    default=False, 
    help="Enable line number tracking via side channel (useful for reconstruction)."
)
@click.option(
    "--bg", 
    is_flag=True, 
    default=False, 
    help="Run as a background daemon."
)
# @click.option(
#     "--bg-log", 
#     type=str, 
#     default="/dev/null", 
#     help="Log file path when running in background mode."
# )
@click.version_option(
    version=version("partake"), 
    prog_name="partake",
    message="%(prog)s %(version)s"
)
@click.argument("command", type=str)
def partake_cli(
        n_workers, 
        input_path, 
        output_template, 
        error_template, 
        # pipe_output, 
        # pipe_error, 
        batch_size, 
        write_all_line_numbers, 
        bg,
        # bg_log,
        command
    ):
    """
    Shard text streams to persistent parallel jobs at raw pipe speed.
    
    Partake reads input (from stdin or file), splits it into batches, and 
    scatters them to a pool of persistent worker processes.
    
    \b
    EXAMPLES:
        # Distribute a huge CSV to 4 instances of a python script
        cat data.csv | partake -w 4 "python process_data.py"
    """
    class TextWriter(Writer):
        def filter(self, batch: Batch):
            return batch.text

    class LineNumbersWriter(Writer):
        def filter(self, batch: Batch):
            start, end = batch.line_bounds
            line_numbers = [str(n).encode() for n in range(start, end)]
            return b"".join(line_numbers) + b"\n"

    template = TaskTemplate(
        args=command,
        stdout=FileChannel(output_template) if output_template else None,
        stderr=FileChannel(error_template) if error_template else None,
        sidein={"PARTAKE_LINE_NUMBERS": AnonChannel()}
    )

    specs = {
        "stdin": WriterSpec(TextWriter),
        "PARTAKE_LINE_NUMBERS": WriterSpec(
            LineNumbersWriter, 
            exhaust=write_all_line_numbers
        )
    }

    with Coordinator(
            template=template, 
            count=n_workers, 
            writer_specs=specs,
            daemonize = bg,
        ) as swarm:
        source = sys.stdin.buffer if input_path == "-" else open(input_path, "rb")
        size_bytes = get_size_bytes(batch_size)
        lines_read = 0
        while batch := read_batch(source, size_bytes):
            batch.start = lines_read
            batch.end = batch.start + batch.extract_line_count()
            lines_read = batch.end
            swarm.feed(batch)


            


