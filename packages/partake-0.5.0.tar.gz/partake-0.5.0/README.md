# partake
**Shard input to persistent parallel jobs at the rate of a pipe.**

# Example

```bash
seq 0 10000000 | partake -n 10 'cat'
```

# Install

CLI version:
```bash
pip install partake
```
With development dependencies:
```bash
pip install partake[dev]
```