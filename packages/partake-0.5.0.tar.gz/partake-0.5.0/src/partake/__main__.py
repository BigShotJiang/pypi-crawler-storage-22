from .cli import partake_cli

if __name__ == "__main__":
    partake_cli()