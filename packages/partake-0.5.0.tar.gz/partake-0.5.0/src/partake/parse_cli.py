from typing import Tuple
import click
from functools import partial
from subfeed import FileChannel, SubprocessPipe

def get_size_unit(size_unit_string: str, unit: str) -> Tuple[float,str] | None:
    try:
        unit_idx = size_unit_string.index(unit)
        size = float(size_unit_string[:unit_idx])

        return size, unit
    except:
        return None

def get_size_bytes(size: str) -> int:
    
    try:
        # Is size an integer?
        return int(size)
    except:
        pass

    # Is 'size' a value, then unit in B, KB, MB, GB, TB?
    # I.e. 1MB or 1 MB
    size_unit = get_size_unit(size, "B")
    if size_unit:
        result = size_unit[0]
    size_unit = get_size_unit(size, "KB")
    if size_unit:
        result = size_unit[0] * 1024
    size_unit = get_size_unit(size, "MB")
    if size_unit:
        result = size_unit[0] * 1024**2
    size_unit = get_size_unit(size, "GB")
    if size_unit:
        result = size_unit[0] * 1024**3
    size_unit = get_size_unit(size, "TB")
    if size_unit:
        result = size_unit[0] * 1024**4
    try:
        return int(result)
    except:
        raise ValueError(f"Unable to parse size {size}")    

def get_stream_type(template: str, is_pipe: bool):
    if template:
        if is_pipe:
            # TODO
            raise NotImplementedError("FifoChannel not implemented yet")
            StreamType = partial(FifoChannel, template=template)
        else:
            StreamType = partial(FileChannel, template=template)
    else:
        StreamType = SubprocessPipe
    return StreamType

def unescape_delimiter(ctx, param, value):
    """
    Converts string with escape sequences (like \n, \t, \x00) into actual bytes.
    """
    if not value:
        return b"\n"
    try:
        # 1. Encode to bytes (utf-8)
        # 2. Decode using 'unicode_escape' to process \n, \t, \x...
        # 3. Re-encode to bytes for the Splitter
        return bytes(value, "utf-8").decode("unicode_escape").encode("utf-8")
    except Exception as e:
        raise click.BadParameter(f"Invalid escape sequence in delimiter: {value}")