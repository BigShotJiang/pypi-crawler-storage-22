import warnings
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Literal, IO, Optional

def get_bytes(source: IO, size: int) -> bytes:
    return source.read(size)

@dataclass
class Batch(ABC):
    data: bytes
    batch_offset: int
    start_byte: int
    end_byte: int

    @property
    @abstractmethod
    def unit(self) -> str:
        pass

@dataclass
class ByteBatch(Batch):
    block_size_bytes: Optional[int]

    @property
    def unit(self) -> str:
        return "bytes"


@dataclass
class Splitter(ABC):
    # Input control
    source: IO

    # Output control
    read_size_bytes: int
    block_size: Optional[int] = None
    
    # Error handling
    err_incomplete_block: Literal["pass", "warn", "error"] = "error" 

    # Output tracking
    current_batch_offset: int = field(init=False)
    current_byte_offset: int = field(init=False)

    @abstractmethod
    def read_batch(self) -> Optional[Batch]:
        pass

    def handle_size_mismatch(self, size: int, cum_size: int, unit: str):
        """
        Handle response to incomplete block at end of file.
        """
        # Implicit string concatenation (no commas)
        msg = (
            f"{self.err_incomplete_block.upper()}: Block size set to "
            f"{self.block_size} {unit}, but actually contained {size} {unit} "
            f"({cum_size} {unit} read so far). "
            "Action taken: {action}"
        )

        if self.err_incomplete_block == "pass":
            return
        elif self.err_incomplete_block == "warn":
            warnings.warn(msg.format(action="Issued warning and continued processing."))
        elif self.err_incomplete_block == "error":
            raise ValueError(msg.format(action="Crashed before last write."))

    def __post_init__(self):
        self.current_batch_offset = 0
        self.current_byte_offset = 0
        if self.read_size_bytes <= 0:
            raise ValueError(
                "In Splitter, read_size_bytes must be positive integer. "
                f"{self}"
            )

@dataclass
class ByteSplitter(Splitter):
    def read_batch(self) -> Optional[ByteBatch]:
        """Return batches of text with intact line block structure
        """
        # Get large block of bytes (high throughput)
        data = get_bytes(self.source, self.read_size_bytes)
        data_size_bytes = len(data)
        
        # Check the byte block size if relevant
        if self.block_size:
            if data_size_bytes % self.block_size:
                # Handle size mismatch. Should only occur at end of file,
                # but for safety, check everywhere.
                self.handle_size_mismatch(
                    data_size_bytes,
                    self.current_byte_offset + data_size_bytes,
                    "bytes"
                )

        if data:
            # Get bounds for batch
            batch_offset = self.current_batch_offset
            start_byte = self.current_byte_offset
            end_byte = start_byte + data_size_bytes
            
            # Update position trackers
            self.current_batch_offset += 1
            self.current_byte_offset = end_byte

            return ByteBatch(data, batch_offset, start_byte, end_byte, self.block_size)
        
        # Return None on no data (EOF)

    def __post_init__(self):
        super().__post_init__()
        
        if self.block_size and self.read_size_bytes % self.block_size != 0:
            raise ValueError(
                "In ByteSplitter, read_size_bytes must be multiple of block_size."
                f"{self}"
            )

@dataclass
class LineReader:
    delimiter: bytes = b"\n"
    scan_chunk_size: int = 300
    unprocessed: bytes = field(default=b"", init=False)
    delimiter_size_bytes: int = field(init=False)

    def get_bytes(self, source: IO, read_size_bytes: int) -> bytes:
        # 1. Drain the 'tail' from the previous read
        data = self.unprocessed
        self.unprocessed = b""
        
        # 2. Bulk read (fastest possible IO)
        # We clamp to 0 to avoid reading the whole file if unprocessed > target
        read_amount = max(read_size_bytes - len(data), 0)
        if read_amount > 0:
            data += get_bytes(source, read_amount)
            
        # 3. Extend to the next delimiter
        data += self.get_line(source)
        
        return data

    def get_line(self, source: IO) -> bytes:
        # --- OPTIMIZED PATH (Standard Text) ---
        if self.delimiter == b"\n":
            if self.unprocessed:
                # This branch shouldn't be hit in \n mode but safe to keep
                ret = self.unprocessed + source.readline()
                self.unprocessed = b""
                return ret
            else:
                # Direct C-speed call
                return source.readline()
        
        # --- CUSTOM DELIMITER PATH ---
        else:
            while True:
                # Check buffer first (in case we have data from previous reads)
                delimiter_offset = self.unprocessed.find(self.delimiter)
                
                if delimiter_offset != -1:
                    # Found delimiter: Cut, Save Tail, Return Head
                    line1_end = delimiter_offset + self.delimiter_size_bytes
                    line1 = self.unprocessed[:line1_end]
                    self.unprocessed = self.unprocessed[line1_end:]
                    return line1
                
                # No delimiter: Read more
                new_bytes = get_bytes(source, self.scan_chunk_size)
                if not new_bytes:
                    # EOF: Return remainder and CLEAR buffer
                    line1 = self.unprocessed
                    self.unprocessed = b"" 
                    return line1
                
                self.unprocessed += new_bytes
    
    def get_line_count(self, text: bytes) -> int:
        return text.count(self.delimiter)

    def __post_init__(self):
        if not self.delimiter:
            raise ValueError("No delimiter specified.")
        self.delimiter_size_bytes = len(self.delimiter)

@dataclass
class LineBatch(Batch):
    start_line: int
    end_line: int
    delimiter: bytes

    @property
    def unit(self) -> str:
        return "lines"

@dataclass
class LineSplitter(Splitter):
    # Input control
    line_reader: LineReader = field(default_factory=LineReader)
    
    # Output tracking
    current_line_offset: int = field(init=False)

    def read_batch(self) -> Optional[LineBatch]:
        """
        Return batches of text with intact line block structure
        """
        # Get large block of bytes (high throughput)
        # Guarantee text ends on a newline (small extra read)
        # Do this now to simplify vetting this function.
        data = self.line_reader.get_bytes(self.source, self.read_size_bytes)
        
        # Tack on rest of the line block (small reads)
        # Add lines to a small string to avoid recopying the large batch
        # over and over with every addition.
        line_count = self.line_reader.get_line_count(data)
        add_lines = b""
        while self.block_size and (line_count % self.block_size != 0):
            # 1. Read one more line
            next_line = self.line_reader.get_line(self.source)
            
            if not next_line:
                # Handle case where last line block is incomplete
                delim = self.line_reader.delimiter
                self.handle_size_mismatch(
                    line_count,
                    self.current_line_offset + line_count,
                    f"lines (delimiter '{delim}')"
                )
                # Exit the loop with an accurate line count on pass/warn
                break

            # 2. Store the new line
            add_lines += next_line
            line_count += 1

        # 3. Fill out the line block
        if add_lines:
            data += add_lines

        # Output guaranteed to end on newline or EOF
        if data:
            # Get bounds for batch
            data_size_bytes = len(data)
            batch_offset = self.current_batch_offset
            start_byte = self.current_byte_offset
            end_byte = start_byte + data_size_bytes
            start_line = self.current_line_offset
            end_line = start_line + line_count

            # Update position trackers
            self.current_batch_offset += 1
            self.current_byte_offset = end_byte
            self.current_line_offset = end_line

            return LineBatch(
                data, 
                batch_offset, 
                start_byte, 
                end_byte, 
                start_line, 
                end_line,
                self.line_reader.delimiter
            )
        
        # Return None on no data (EOF)

    def __post_init__(self):
        super().__post_init__()
        self.current_line_offset = 0



