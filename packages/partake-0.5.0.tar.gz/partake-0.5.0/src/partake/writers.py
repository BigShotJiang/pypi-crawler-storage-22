from dataclasses import dataclass, field
from typing import IO, Literal, Iterable, ClassVar
from .splitter import Batch, ByteBatch, ByteSplitter, LineSplitter, LineBatch, LineReader
from subfeed import Writer

class PartakeConfig:
    output_delimiter: ClassVar[bytes] = b"\n"

class DataWriter(Writer):
    def filter(self, batch: Batch):
        if isinstance(batch, LineBatch) and batch.delimiter != PartakeConfig.output_delimiter:
            
            return batch.data.replace(batch.delimiter, PartakeConfig.output_delimiter)
        else:
            return batch.data

class ByteOffsetsWriter(Writer):
    def filter(self, batch: ByteBatch):
        if batch.block_size_bytes:
            byte_offsets = range(batch.start_byte, batch.end_byte, batch.block_size_bytes)
            return PartakeConfig.output_delimiter.join([str(n).encode() for n in byte_offsets]) + PartakeConfig.output_delimiter
        else:
            return str(batch.start_byte).encode()

class LineNumbersWriter(Writer):
    def filter(self, batch: LineBatch):
        line_numbers = range(batch.start_line, batch.end_line)
        return PartakeConfig.output_delimiter.join([str(n).encode() for n in line_numbers]) + PartakeConfig.output_delimiter
    