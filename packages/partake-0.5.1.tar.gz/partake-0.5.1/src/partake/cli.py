import sys
import click
from typing import Tuple
import threading
from functools import partial
from importlib.metadata import version
from subfeed import *
from .splitter import Batch, ByteBatch, LineBatch, ByteSplitter, LineSplitter, LineReader
from .parse_cli import get_size_unit, get_size_bytes, get_stream_type, unescape_delimiter
from .writers import DataWriter, ByteOffsetsWriter, LineNumbersWriter, PartakeConfig

@click.command(context_settings={"help_option_names": ["-h", "--help"]})
# --- PARALLELIZATION OPTIONS ---
@click.option(
    "-n", "--workers", "n_workers", 
    type=int, default=1, show_default=True, 
    help="Number of persistent parallel worker processes to spawn."
)
@click.option(
    "--bg", 
    is_flag=True, 
    default=False, 
    help="Run as a background daemon."
)
# --- I/O OPTIONS ---
@click.option(
    "-i", "--input", "input_path", 
    type=str, default="-", show_default=True,
    help="Input source. Use '-' for stdin."
)
@click.option(
    "-o", "--output", "output_template", 
    type=str, default="{id}.out", show_default=True,
    help="Template for worker stdout. {id} will be replaced with worker ID."
)
@click.option(
    "-e", "--error", "error_template", 
    type=str, default="{id}.err", show_default=True,
    help="Template for worker stderr. {id} will be replaced with worker ID."
)
@click.option(
    "--wo", "--write-offsets", "write_all_offsets", 
    is_flag=True, 
    default=False, 
    help="Block until all line numbers are consumed by worker."
)
# --- BATCHING OPTIONS ---
@click.option(
    "-r", "--read-size", "read_size_str", 
    type=str, 
    default="50 MB", 
    show_default=True,
    help="Target size for each batch. Accepts units (e.g. 10MB, 500KB)."
)
@click.option(
    "-s", "--block-size", "block_size_str",
    type=str,
    default=None,
    help=(
        "Enforce strict block boundaries.\n"
        "- If integer (e.g. '4'): Groups of N lines (modulus).\n"
        "- If byte size (e.g. '1MB'): Fixed-width binary chunks."
        "- If none (default): No checking."
    )
)
# --- DELIMITER OPTIONS ---
@click.option(
    "--id", "--input-delimiter", "input_delimiter",
    default="\\n", # Default is escaped string representation
    callback=unescape_delimiter,
    help="Row delimiter. Supports escape sequences (e.g. '\\n', '\\t', '\\x00')."
)
@click.option(
    "--od", "--output-delimiter", "output_delimiter",
    default="\\n", # Default is escaped string representation
    callback=unescape_delimiter,
    help="Row delimiter. Supports escape sequences (e.g. '\\n', '\\t', '\\x00')."
)
@click.option(
    "--i0", "--input-null", "input_use_null",
    is_flag=True,
    default=False,
    help="Use null byte (\\0) as input delimiter. Overrides --id."
)
@click.option(
    "--o0", "--output-null", "output_use_null",
    is_flag=True,
    default=False,
    help="Use null byte (\\0) as output delimiter. Overrides --od."
)
# --- PERFORMANCE / ERROR HANDLING ---
@click.option(
    "--scan-window", "scan_window_str",
    type=str,
    default="300B",
    show_default=True,
    help="Internal read buffer size for delimiter scanning."
)
@click.option(
    "--err-incomplete-block", "--err-incomplete", "err_incomplete_block",
    type=click.Choice(["pass", "warn", "error"]),
    default="error",
    show_default=True,
    help=(
        "Define how to handle incomplete block if --block-size specified."
    )
)
@click.version_option(
    version=version("partake"), 
    prog_name="partake",
    message="%(prog)s %(version)s"
)
@click.argument("command", type=str)
def partake_cli(
        n_workers, 
        bg,
        input_path, 
        output_template, 
        error_template,
        write_all_offsets, 
        read_size_str,
        block_size_str,
        input_delimiter,
        output_delimiter,
        input_use_null,
        output_use_null,
        scan_window_str,
        err_incomplete_block,
        command
    ):
    """
    Shard input to persistent jobs at raw pipe speed.
    
    Partake reads input (from stdin or file), splits it into batches, and 
    scatters them to a pool of persistent worker processes.
    
    \b
    EXAMPLES:
        # Distribute ~50MB blocks from a .fastq file to 10 instances of a python script,
        # ensuring 4-line read blocks are contiguous in the batch.
        cat data.fastq | partake -w 10 -s 4 "python process_reads.py"
    """
    source = sys.stdin.buffer if input_path == "-" else open(input_path, "rb")
    read_size_bytes = get_size_bytes(read_size_str)
    scan_chunk_size = get_size_bytes(scan_window_str)
    
    PartakeConfig.output_delimiter = "\0" if output_use_null else output_delimiter
    

    try:
        # Try interpreting as lines (int with no unit)
        block_size = int(block_size_str)
        splitter = LineSplitter(
            source,
            read_size_bytes,
            block_size,
            err_incomplete_block,
            LineReader(
                '\0' if input_use_null else input_delimiter,
                scan_chunk_size
            )
        )
        sidein={"PARTAKE_LINE_NUMBERS": AnonChannel()}
        offset_specs={
            "PARTAKE_LINE_NUMBERS": WriterSpec(
                LineNumbersWriter,
                exhaust=write_all_offsets
            )
        }

    except:
        # Fall back to interpreting as byte size
        block_size = get_size_bytes(block_size_str) if block_size_str else None
        splitter = ByteSplitter(
            source,
            read_size_bytes,
            block_size,
            err_incomplete_block
        )
        sidein={
            "PARTAKE_BYTE_OFFSETS": AnonChannel()
        }
        offset_specs={
            "PARTAKE_BYTE_OFFSETS": WriterSpec(
                ByteOffsetsWriter,
                exhaust=write_all_offsets
            )
        }

    template = TaskTemplate(
        args=command,
        stdout=FileChannel(output_template) if output_template else None,
        stderr=FileChannel(error_template) if error_template else None,
        sidein=sidein
    )

    specs = {
        "stdin": WriterSpec(DataWriter),
        **offset_specs
    }
    with Coordinator(
            template=template, 
            count=n_workers, 
            writer_specs=specs,
            daemonize = bg,
        ) as swarm:
        while batch := splitter.read_batch():
            swarm.feed(batch)




            

 
# @click.option(
#     "--po/--fo", "--pipe-output/--file-output", "pipe_output", 
#     is_flag=True, 
#     default=False, 
#     help="Create named pipes (FIFOs) for output instead of standard files."
# )
# @click.option(
#     "--pe/--fe", "--pipe-error/--file-error", "pipe_error", 
#     is_flag=True, 
#     default=False, 
#     help="Create named pipes (FIFOs) for error streams instead of standard files."
# )
# @click.option(
#     "--bg-log", 
#     type=str, 
#     default="/dev/null", 
#     help="Log file path when running in background mode."
# )