# Partial QR Code Decoder

An aggressive QR code decoder that can recover data from partially missing or damaged QR codes.

## Usage

```bash
partial-qr --input path/to/qr_code_matrix.txt
```

The input must be either a text file, containing a matrix of characters, or an image file.

When the input is a text file, the content must be a grid of characters, where each character
is one of:

- `#`, `X`, `1` - representing a black module
- ` `, `.`, `0` - representing a white module
- `?` - representing the unknown cells that the decoder will try to recover

When the input is an image file, the program will try to detect the size of the QR code, but it
can sometimes misdetect it, and in that case, the `--qr-version` option can be used to specify
the version of the QR code (1-40). The image must only contain the QR code, in a well-aligned grid
with no perspective distortion. Recognizing QR codes from photographs or heavily distorted images
is not in the scope of this project, and will not be supported.
Each cell in the QR image must be close to a solid black, solid white, or middle gray color,
and the program will classify them as black, white, or unknown based on a simple thresholding
of the lightness.

If the input is too corrupted, bruteforce strength can be increased, but beware of the exponential
runtime increase, especially for higher versions:

```bash
partial-qr --input path/to/qr_code_matrix.txt --max-brute-bits 24
```

Additional hints can be provided to the bruteforce to speed it up:

`--ascii` - Assume the data is ASCII, which reduces the search space significantly.

`--url` - Assume the data is a URL, so it must start with either `http://` or `https://`.

`--parallel` - Enable parallel bruteforce using all available CPU cores.
