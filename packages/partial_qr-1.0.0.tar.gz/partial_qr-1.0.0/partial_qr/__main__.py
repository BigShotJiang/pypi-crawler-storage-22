import logging
import sys

import click

from .decoders.data.decode import decode_qr_data, matrix_to_image, reconstruct_matrix
from .decoders.formatinfo import decode_format_version_information
from .decoders.mask import apply_mask
from .decoders.version import decode_version_information
from .matrix import load_matrix_from_file

logger = logging.getLogger(__name__)

VERBOSITY_MAP = {0: logging.WARNING, 1: logging.INFO, 2: logging.DEBUG}


def _configure_logging(verbosity: int) -> None:
    level = VERBOSITY_MAP.get(min(verbosity, 2), logging.DEBUG)
    logging.basicConfig(
        level=level,
        format=(
            "%(levelname)s: %(message)s"
            if verbosity < 2
            else "%(levelname)s [%(name)s]: %(message)s"
        ),
        stream=sys.stderr,
    )


@click.command()
@click.option(
    "-i",
    "--input-file",
    type=click.Path(exists=True),
    required=True,
    help="Path to the input data file.",
)
@click.option(
    "--ascii",
    "assume_ascii",
    is_flag=True,
    default=False,
    help="Assume payload is printable ASCII text (byte mode, MSB=0 per byte).",
)
@click.option(
    "--url",
    "assume_url",
    is_flag=True,
    default=False,
    help="Assume data starts with http:// or https:// (implies --ascii).",
)
@click.option(
    "--max-brute-bits",
    type=int,
    default=10,
    show_default=True,
    help="Max unknown bits to brute-force per RS block (2^N combinations).",
)
@click.option(
    "--parallel",
    is_flag=True,
    default=False,
    help="Distribute brute-force work across all CPU cores.",
)
@click.option(
    "--qr-version",
    type=int,
    default=None,
    help="Override QR version (1-40) for image loading instead of auto-detecting.",
)
@click.option(
    "--reconstruct",
    type=click.Path(),
    default=None,
    help="Save the reconstructed QR code as an image to the given path.",
)
@click.option(
    "-v",
    "--verbose",
    count=True,
    help="Increase output verbosity (-v for info, -vv for debug).",
)
def main(
    input_file: str,
    assume_ascii: bool,
    assume_url: bool,
    max_brute_bits: int,
    parallel: bool,
    qr_version: int | None,
    reconstruct: str | None,
    verbose: int,
) -> None:
    _configure_logging(verbose)

    matrix = load_matrix_from_file(input_file, qr_version=qr_version)
    logging.debug(f"Loaded matrix:\n{matrix}")

    format_info = decode_format_version_information(matrix)
    transposed_format_info = decode_format_version_information(matrix.transpose())
    is_transposed = transposed_format_info.hamming_distance < format_info.hamming_distance
    if is_transposed:
        logger.info("Transposed orientation has better format info, flipping matrix")
        matrix = matrix.transpose()
        format_info = transposed_format_info

    version_info = decode_version_information(matrix)

    if format_info.mask_pattern is None:
        print("Error: cannot decode format information.", file=sys.stderr)
        sys.exit(1)

    flipped = apply_mask(matrix, format_info.mask_pattern, version_info.version)

    if format_info.error_correction_level is None:
        print("Error: cannot decode error correction level.", file=sys.stderr)
        sys.exit(1)

    result = decode_qr_data(
        flipped,
        version_info.version,
        format_info.error_correction_level,
        assume_ascii=assume_ascii,
        assume_url=assume_url,
        max_brute_bits=max_brute_bits,
        parallel=parallel,
    )

    if reconstruct:
        recovered = reconstruct_matrix(matrix, result, format_info.mask_pattern)
        if is_transposed:
            recovered = recovered.transpose()
        matrix_to_image(recovered, reconstruct)
        logger.info("Reconstructed QR code saved to: %s", reconstruct)

    if result.decoded.segments:
        print(result.decoded.raw_text)
    else:
        total_erasures = (
            result.total_data_codewords
            + result.total_ec_codewords
            - result.known_data_codewords
            - result.known_ec_codewords
        )
        avg_erasures = total_erasures // result.block_info.total_blocks
        print(
            f"Error: decoding failed (~{avg_erasures} erasures/block,"
            f" RS capacity is {result.block_info.ec_codewords_per_block})",
            file=sys.stderr,
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
