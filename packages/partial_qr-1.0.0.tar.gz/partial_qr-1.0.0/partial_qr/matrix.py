from __future__ import annotations

import logging
import os
from enum import Enum

logger = logging.getLogger(__name__)

VALID_QR_SIZES = [4 * v + 17 for v in range(1, 41)]
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tiff", ".webp"}


class Cell(Enum):
    EMPTY = 0
    FILLED = 1
    UNKNOWN = 2

    def __or__(self, value: Cell) -> Cell:
        if self != Cell.UNKNOWN:
            return self
        return value


class Matrix:
    def __init__(self, width: int, height: int) -> None:
        self.width = width
        self.height = height
        self.cells = [[Cell.UNKNOWN for _ in range(width)] for _ in range(height)]

    def __str__(self) -> str:
        return "\n".join(
            "".join(
                "x" if cell == Cell.FILLED else "." if cell == Cell.EMPTY else "?" for cell in row
            )
            for row in self.cells
        )

    def transpose(self) -> Matrix:
        """Return a new matrix mirrored along the main diagonal (rows become columns)."""
        result = Matrix(self.height, self.width)
        for y in range(self.height):
            for x in range(self.width):
                result.cells[x][y] = self.cells[y][x]
        return result


def load_matrix_from_string(s: str) -> Matrix:
    lines = s.splitlines()
    height = len(lines)
    if height == 0:
        return Matrix(0, 0)
    width = max(len(line.strip("\n")) for line in lines)
    if width == 0:
        return Matrix(0, height)

    matrix = Matrix(width, height)
    for y, line in enumerate(lines):
        for x, char in enumerate(line.strip("\n")):
            if char.lower() in ["#", "x", "1"]:
                matrix.cells[y][x] = Cell.FILLED
            elif char.lower() in [".", " ", "0"]:
                matrix.cells[y][x] = Cell.EMPTY
            elif char.lower() in ["?"]:
                matrix.cells[y][x] = Cell.UNKNOWN
            else:
                raise ValueError(f"Invalid character '{char}' at ({x}, {y})")
        else:
            for x in range(len(line.strip("\n")), width):
                matrix.cells[y][x] = Cell.EMPTY

    return matrix


def load_matrix_from_image(filename: str, qr_version: int | None = None) -> Matrix:
    """Load a QR matrix from an image file.

    Auto-detects the QR module grid size by finding the content bounding box
    and testing all 40 valid QR sizes (21..177) for the best pixel-grid fit.
    If qr_version is given, skips auto-detection and uses that version directly.
    Classifies each module as black (<1/3 brightness), white (>2/3), or gray (unknown).
    """
    from PIL import Image

    img = Image.open(filename).convert("L")
    pixels = img.load()
    assert pixels is not None

    # Find bounding box of non-white content (gray modules are included)
    content = img.point(lambda p: 1 if p < 200 else 0)
    bbox = content.getbbox()
    if bbox is None:
        raise ValueError("Image appears to be entirely white")

    left, top, right, bottom = bbox
    bbox_w = right - left
    bbox_h = bottom - top

    if qr_version is not None:
        if not 1 <= qr_version <= 40:
            raise ValueError(f"QR version must be 1-40, got {qr_version}")
        qr_size = 4 * qr_version + 17
    else:
        candidates = [s for s in VALID_QR_SIZES if bbox_w / s >= 1 and bbox_h / s >= 1]
        if not candidates:
            raise ValueError(
                f"Image content area ({bbox_w}x{bbox_h}) too small for any QR version"
            )

        def _fractional_score(qr_size: int) -> float:
            mod_w = bbox_w / qr_size
            mod_h = bbox_h / qr_size
            fw = mod_w % 1
            fh = mod_h % 1
            return min(fw, 1 - fw) + min(fh, 1 - fh)

        qr_size = min(candidates, key=_fractional_score)
    version = (qr_size - 17) // 4
    mod_w = bbox_w / qr_size
    mod_h = bbox_h / qr_size
    logger.info(
        f"Detected QR version {version} ({qr_size}x{qr_size} modules,"
        f" ~{mod_w:.1f}x{mod_h:.1f} px/module)"
    )

    matrix = Matrix(qr_size, qr_size)
    cropped = img.crop(bbox).resize((qr_size, qr_size), Image.Resampling.BOX)
    resized_pixels = cropped.load()
    assert resized_pixels is not None
    for r in range(qr_size):
        for c in range(qr_size):
            val = resized_pixels[c, r]
            assert isinstance(val, (int, float))
            lightness = val / 255.0

            if lightness < 1 / 3:
                matrix.cells[r][c] = Cell.FILLED
            elif lightness > 2 / 3:
                matrix.cells[r][c] = Cell.EMPTY
            else:
                matrix.cells[r][c] = Cell.UNKNOWN

    return matrix


def load_matrix_from_file(filename: str, qr_version: int | None = None) -> Matrix:
    ext = os.path.splitext(filename)[1].lower()
    if ext in IMAGE_EXTENSIONS:
        return load_matrix_from_image(filename, qr_version=qr_version)
    if qr_version is not None:
        logger.warning("--qr-version is ignored for text input files")
    with open(filename, "r") as f:
        return load_matrix_from_string(f.read())
