from paskia.sansio import Passkey

__all__ = ["Passkey"]
