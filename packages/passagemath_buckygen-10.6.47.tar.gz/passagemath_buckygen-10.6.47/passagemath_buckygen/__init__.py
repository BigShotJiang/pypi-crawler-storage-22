# sage_setup: distribution = sagemath-buckygen

from sage.all__sagemath_buckygen import *
