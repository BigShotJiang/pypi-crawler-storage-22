# sage_setup: distribution = sagemath-categories
from sage.data_structures.all__sagemath_categories import *
