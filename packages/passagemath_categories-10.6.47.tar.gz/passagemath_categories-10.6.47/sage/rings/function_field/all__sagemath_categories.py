# sage_setup: distribution = sagemath-categories
from sage.rings.function_field.constructor import FunctionField
