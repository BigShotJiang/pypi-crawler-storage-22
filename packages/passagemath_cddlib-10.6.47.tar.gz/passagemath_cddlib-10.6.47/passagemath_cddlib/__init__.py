# sage_setup: distribution = sagemath-cddlib

from sage.all__sagemath_cddlib import *
