# sage_setup: distribution = sagemath-combinat

from sage.all__sagemath_combinat import *
