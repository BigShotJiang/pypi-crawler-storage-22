# sage_setup: distribution = sagemath-database-stein-watkins-mini
