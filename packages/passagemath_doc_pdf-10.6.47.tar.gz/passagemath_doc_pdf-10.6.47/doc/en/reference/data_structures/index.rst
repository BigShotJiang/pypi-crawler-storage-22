Data Structures
===============

.. toctree::
   :maxdepth: 1

   sage/misc/binary_tree
   sage/data_structures/bitset
   sage/data_structures/bounded_integer_sequences
   sage/data_structures/stream
   sage/data_structures/mutable_poset
   sage/data_structures/pairing_heap

.. include:: ../footer.txt
