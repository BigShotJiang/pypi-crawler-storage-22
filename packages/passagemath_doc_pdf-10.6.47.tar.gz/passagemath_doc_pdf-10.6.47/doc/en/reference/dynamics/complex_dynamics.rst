Plotting of Mandelbrot and Julia Sets
========================================================

.. toctree::
   :maxdepth: 1

   ../sage/dynamics/complex_dynamics/mandel_julia
