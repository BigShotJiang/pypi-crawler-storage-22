Symbolic Logic
==============

.. toctree::
   :maxdepth: 1

   sage/logic/propcalc
   sage/logic/boolformula
   sage/logic/booleval
   sage/logic/logicparser
   sage/logic/logic
   sage/logic/logictable

.. include:: ../footer.txt
