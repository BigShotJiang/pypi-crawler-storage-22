.. _spkg_graphs:

graphs: A database of combinatorial graphs
==========================================

Description
-----------

A database of graphs. Created by Emily Kirkman based on the work of
Jason Grout. Since April 2012 it also contains the ISGCI graph database.


Upstream Contact
----------------

-  https://jasongrout.org/graph_database

-  For ISGCI:

   H.N. de Ridder (hnridder@graphclasses.org)

-  For Andries Brouwer's database:

   The data is taken from from Andries E. Brouwer's website
   (https://www.win.tue.nl/~aeb/). Anything related to the data should
   be
   reported to him directly (aeb@cwi.nl)

   The code used to parse the data and create the .json file is
   available at
   https://github.com/nathanncohen/strongly_regular_graphs_database.



Type
----

standard


Dependencies
------------



Version Information
-------------------

package-version.txt::

    20210214.p0

See https://repology.org/project/sagemath-graphs/versions

Installation commands
---------------------

.. tab:: Sage distribution:

   .. CODE-BLOCK:: bash

       $ sage -i graphs

.. tab:: Arch Linux:

   .. CODE-BLOCK:: bash

       $ sudo pacman -S sage-data-graphs

.. tab:: conda-forge:

   .. CODE-BLOCK:: bash

       $ conda install sagemath-db-graphs


However, these system packages will not be used for building Sage
because ``spkg-configure.m4`` has not been written for this package;
see :issue:`27330` for more information.
