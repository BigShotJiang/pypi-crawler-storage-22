# sage_setup: distribution = sagemath-eclib

from sage.all__sagemath_eclib import *
