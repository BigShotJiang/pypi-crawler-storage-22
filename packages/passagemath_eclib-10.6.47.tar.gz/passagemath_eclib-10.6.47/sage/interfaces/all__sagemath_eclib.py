# sage_setup: distribution = sagemath-eclib
