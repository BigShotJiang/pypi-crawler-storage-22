# sage_setup: distribution = sagemath-environment

from sage.all__sagemath_environment import *
