# sage_setup: distribution = sagemath-frobby

from sage.all__sagemath_frobby import *
