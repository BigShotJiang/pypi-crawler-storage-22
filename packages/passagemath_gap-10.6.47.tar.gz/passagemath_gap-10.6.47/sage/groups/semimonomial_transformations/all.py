# sage_setup: distribution = sagemath-groups
