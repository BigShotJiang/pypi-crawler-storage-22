# sage_setup: distribution = sagemath-gap-pkg-caratinterface

from sage.all__sagemath_gap_pkg_caratinterface import *
