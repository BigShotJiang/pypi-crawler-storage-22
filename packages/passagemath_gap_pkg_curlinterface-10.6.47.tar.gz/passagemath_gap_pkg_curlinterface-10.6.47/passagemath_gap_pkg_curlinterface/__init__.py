# sage_setup: distribution = sagemath-gap-pkg-curlinterface

from sage.all__sagemath_gap_pkg_curlinterface import *
