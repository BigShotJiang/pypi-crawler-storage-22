# sage_setup: distribution = sagemath-glpk
