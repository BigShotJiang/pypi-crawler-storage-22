# sage_setup: distribution = sagemath-homfly
# delvewheel: patch

from sage.all__sagemath_graphs import *
