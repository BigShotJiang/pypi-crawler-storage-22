# sage_setup: distribution = sagemath-iml

from sage.all__sagemath_iml import *
