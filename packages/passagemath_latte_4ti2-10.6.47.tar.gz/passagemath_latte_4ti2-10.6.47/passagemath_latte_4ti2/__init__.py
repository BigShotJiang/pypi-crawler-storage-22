# sage_setup: distribution = sagemath-latte-4ti2

from sage.all__sagemath_latte_4ti2 import *
