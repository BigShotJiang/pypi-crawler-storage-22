# sage_setup: distribution = sagemath-lcalc

from sage.all__sagemath_lcalc import *
