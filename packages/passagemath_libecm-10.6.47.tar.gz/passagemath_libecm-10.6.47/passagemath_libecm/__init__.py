# sage_setup: distribution = sagemath-libecm

from sage.all__sagemath_libecm import *
