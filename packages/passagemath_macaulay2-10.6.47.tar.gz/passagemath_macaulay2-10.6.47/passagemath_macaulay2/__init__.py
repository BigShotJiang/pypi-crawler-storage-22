# sage_setup: distribution = sagemath-macaulay2

from sage.all__sagemath_macaulay2 import *
