# sage_setup: distribution = sagemath-macaulay2
