# sage_setup: distribution = sagemath-modules

from sage.all__sagemath_modules import *
