# sage_setup: distribution = sagemath-modules
from sage.misc.lazy_import import lazy_import

lazy_import('sage.crypto.public_key.blum_goldwasser', 'BlumGoldwasser')
del lazy_import
