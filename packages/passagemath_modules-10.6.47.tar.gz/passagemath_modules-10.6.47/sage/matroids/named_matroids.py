# sage_setup: distribution = sagemath-modules
from sage.misc.superseded import deprecation
from sage.matroids.database_matroids import *
deprecation(36842, "named_matroids is deprecated, use catalog instead")
del deprecation
