# sage_setup: distribution = sagemath-modules
from sage.tensor.modules.all import *
