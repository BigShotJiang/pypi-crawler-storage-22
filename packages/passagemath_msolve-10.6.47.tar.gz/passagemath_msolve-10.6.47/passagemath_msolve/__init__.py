# sage_setup: distribution = sagemath-msolve

from sage.all__sagemath_msolve import *
