# sage_setup: distribution = sagemath-ntl

from sage.all__sagemath_ntl import *
