# sage_setup: distribution = sagemath-pari

from sage.all__sagemath_pari import *
