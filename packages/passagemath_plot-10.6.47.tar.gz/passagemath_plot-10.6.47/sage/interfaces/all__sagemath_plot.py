# sage_setup: distribution = sagemath-plot
