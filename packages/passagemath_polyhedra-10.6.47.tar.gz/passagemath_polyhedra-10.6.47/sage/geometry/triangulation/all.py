# sage_setup: distribution = sagemath-polyhedra
from sage.geometry.triangulation.point_configuration import PointConfiguration
