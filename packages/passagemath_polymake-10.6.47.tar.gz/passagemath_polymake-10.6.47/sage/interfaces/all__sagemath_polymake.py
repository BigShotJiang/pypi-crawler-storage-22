# sage_setup: distribution = sagemath-polymake
