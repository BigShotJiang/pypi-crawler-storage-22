# sage_setup: distribution = sagemath-schemes

from sage.all__sagemath_schemes import *
