# sage_setup: distribution = sagemath-singular

from sage.all__sagemath_singular import *
