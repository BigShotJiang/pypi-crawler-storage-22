#ifndef _PYNAC_CONFIG_H
#define _PYNAC_CONFIG_H 1

/* GiNaC archive file version age */
#define PYNAC_ARCHIVE_AGE 0

/* Current GiNaC archive file version number */
#define PYNAC_ARCHIVE_VERSION 3

/* once: _PYNAC_CONFIG_H */
#endif
