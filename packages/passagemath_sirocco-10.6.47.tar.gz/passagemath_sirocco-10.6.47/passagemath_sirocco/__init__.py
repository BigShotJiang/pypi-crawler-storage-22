# sage_setup: distribution = sagemath-sirocco

from sage.all__sagemath_sirocco import *
