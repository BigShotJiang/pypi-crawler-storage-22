# sage_setup: distribution = sagemath-symbolics

from sage.all__sagemath_symbolics import *
