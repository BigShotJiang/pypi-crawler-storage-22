# sage_setup: distribution = sagemath-topcom

from sage.all__sagemath_topcom import *
