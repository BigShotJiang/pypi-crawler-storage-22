const s=globalThis.__sveltekit_18uh3gf?.base??"",a=globalThis.__sveltekit_18uh3gf?.assets??s??"";export{a,s as b};
