"""
Command-line entry point for pathway subtyping framework.
"""

from .cli import main

if __name__ == "__main__":
    main()
