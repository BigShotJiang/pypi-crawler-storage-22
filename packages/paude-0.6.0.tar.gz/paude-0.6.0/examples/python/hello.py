print('Hello from Python')
