from .ccavenue import CCAvenue  # noqa

__version__ = "1.1.0"
