"""
Data models for the Paygent SDK.
"""

from dataclasses import dataclass
from typing import Dict, Optional, Any

@dataclass
class UsageData:
    """Represents the usage data structure."""
    service_provider: str
    model: str
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    cached_tokens: Optional[int] = None  # Optional cached tokens


@dataclass
class UsageDataWithStrings:
    """Represents the usage data structure with prompt and output strings."""
    service_provider: str
    model: str
    prompt_string: str
    output_string: str


@dataclass
class APIRequest:
    """Represents the request body for the API call."""
    agent_id: str
    customer_id: str
    indicator: str
    amount: float


@dataclass
class SttUsageData:
    """Represents the STT usage data structure."""
    service_provider: str
    model: str
    audio_duration: int  # Duration in seconds


@dataclass
class TtsUsageData:
    """Represents the TTS usage data structure."""
    service_provider: str
    model: str
    character_count: int  # Number of characters


# New data models for V2 API and customer management

@dataclass
class RawUsageData:
    """Raw usage data for V2 API (server-side cost calculation)."""
    provider: str
    model: str
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    cached_tokens: Optional[int] = None
    audio_duration: Optional[int] = None  # for STT (in seconds)
    character_count: Optional[int] = None  # for TTS


@dataclass
class CostBreakdown:
    """Cost breakdown details."""
    input_cost: float
    output_cost: float
    cached_cost: float
    audio_cost: float
    total_cost: float


@dataclass
class SendUsageV2Response:
    """Response from V2 usage API."""
    cp_data_id: str
    calculated_cost: float
    breakdown: CostBreakdown
    model_metadata: Dict[str, Any]


@dataclass
class Customer:
    """Customer data model."""
    id: str
    external_id: str
    name: str
    email: Optional[str] = None
    website: Optional[str] = None
    phone: Optional[str] = None
    address_line1: Optional[str] = None
    address_line2: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zip_code: Optional[str] = None
    country: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass
class CustomerCreateOrGetRequest:
    """Request model for creating or getting a customer."""
    name: str
    external_id: str
    email: Optional[str] = None
    website: Optional[str] = None
    phone: Optional[str] = None
    address_line1: Optional[str] = None
    address_line2: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zip_code: Optional[str] = None
    country: Optional[str] = None

