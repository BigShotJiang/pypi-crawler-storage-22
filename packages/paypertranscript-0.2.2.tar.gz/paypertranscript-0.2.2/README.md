<p align="center">
  <h1 align="center">PayPerTranscript</h1>
  <p align="center">
    Open-Source Voice-to-Text für Windows — Pay-per-Use statt Abo.
    <br />
    Hotkey drücken, sprechen, loslassen — Text erscheint an der Cursor-Position.
  </p>
</p>

---

## Warum PayPerTranscript?

Kommerzielle Diktierdienste kosten $12–15 pro Monat — egal ob du sie 5 Minuten oder 5 Stunden nutzt.

PayPerTranscript nutzt Cloud-basierte KI-Modelle direkt über deinen eigenen API-Key. Du zahlst nur, was du tatsächlich verbrauchst: **~0.024 Cent pro Transkription**.

> 100 Transkriptionen kosten ca. 2.4 Cent. Ein kommerzielles Abo kostet dafür $15/Monat.

---

## Features

| Feature | Beschreibung |
|---------|-------------|
| **Hold-to-Record** | Hotkey halten, sprechen, loslassen — Text erscheint |
| **Toggle-Modus** | Alternativ: einmal drücken = Start, nochmal = Stop |
| **App-spezifische Formatierung** | Chat-Apps: locker. E-Mail: professionell. Per LLM, frei konfigurierbar. |
| **Wortliste** | Namen und Fachbegriffe immer korrekt transkribieren |
| **Kosten-Dashboard** | Jederzeit sehen, was verbraucht wurde |
| **Privatsphäre** | Dein API-Key, deine Daten. Keine Telemetrie, kein Tracking. |
| **Open Source** | MIT-Lizenz — vollständig transparent und erweiterbar |

---

## Installation

**Voraussetzungen:** Windows 10/11, Python 3.12+

### Option 1: pip install (empfohlen)

```bash
pip install paypertranscript
```

Nach der Installation einfach starten:

```bash
paypertranscript
```

Beim ersten Start öffnet sich ein **Setup-Wizard**, der durch die Konfiguration führt.

### Option 2: Aus dem Quellcode

```bash
# Repository klonen
git clone https://github.com/jxnxts/PayPerTranscript.git
cd PayPerTranscript

# Virtuelle Umgebung erstellen & aktivieren
python -m venv venv
venv\Scripts\activate

# Im Entwicklungsmodus installieren
pip install -e .

# App starten
paypertranscript

# Oder mit Debug-Logging
python -m paypertranscript --debug
```

---

## Nutzung

1. **Hotkey halten** — `Ctrl+Win` gedrückt halten und sprechen
2. **Loslassen** — die Aufnahme stoppt, Text wird transkribiert
3. **Text erscheint** — direkt an der Cursor-Position eingefügt
4. **Tray-Icon** — Rechtsklick für Einstellungen, Statistiken und mehr

### Kosten

| Dienst | Preis |
|--------|-------|
| STT (Whisper) | $0.04 pro Stunde Audio (~0.01 Cent pro 10s) |
| LLM-Formatierung | ~$0.00002 pro Transkription (optional) |
| **Gesamt** | **~0.024 Cent pro Transkription** |

Alle Preise basieren auf GroqCloud-Tarifen. Du nutzt deinen eigenen API-Key — kein Abo, kein Mittelsmann.

---

## Konfiguration

Die gesamte Konfiguration ist über die grafische Oberfläche möglich:

- **Einstellungen** — Sprache, Hotkeys, API-Key, Overlay-Position
- **Wortliste** — Namen und Fachbegriffe für korrekte Transkription
- **Fenster-Zuordnung** — Welche App bekommt welchen Schreibstil (casual, professionell, ...)
- **Statistiken** — Kosten, Nutzung, Ersparnis gegenüber Abo-Diensten

Alle Daten werden lokal unter `%APPDATA%\PayPerTranscript\` gespeichert.

---

## FAQ

### Text wird nicht in Admin-Fenster eingefügt

Windows blockiert Tastatureingaben von nicht-erhöhten Prozessen in erhöhte Fenster (UAC). Wenn du PayPerTranscript in Admin-Fenstern nutzen möchtest, starte die App als Administrator.

### Mikrofon wird nicht erkannt

- Prüfe, ob ein Mikrofon angeschlossen und in den Windows-Soundeinstellungen aktiviert ist
- Prüfe die Datenschutz-Einstellungen: Windows-Einstellungen → Datenschutz → Mikrofon

### Wie erhalte ich einen API-Key?

1. Erstelle einen Account bei [GroqCloud](https://console.groq.com)
2. Gehe zu API Keys → "Create API Key"
3. Kopiere den Key und füge ihn im Setup-Wizard ein

---

## Lizenz

MIT — siehe [LICENSE](LICENSE)
