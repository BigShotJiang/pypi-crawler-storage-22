﻿"""Schnellzugriff-Dashboard für PayPerTranscript.

Wird bei Linksklick auf das Tray-Icon angezeigt.
Bietet Buttons für alle Hauptfunktionen und schließt sich beim Öffnen eines Dialogs.
"""

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QDialog,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from paypertranscript.core.logging import get_logger

log = get_logger("ui.dashboard")


class DashboardDialog(QDialog):
    """Schnellzugriff-Dashboard bei Tray-Linksklick."""

    open_settings = Signal()
    open_statistics = Signal()
    open_word_list = Signal()
    open_window_mapping = Signal()
    quit_app = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._setup_ui()

    def _setup_ui(self) -> None:
        self.setWindowTitle("PayPerTranscript")
        self.setFixedSize(280, 320)
        self.setWindowFlags(
            Qt.WindowType.Window
            | Qt.WindowType.WindowCloseButtonHint
            | Qt.WindowType.WindowStaysOnTopHint
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(10)

        # Titel
        title = QLabel("PayPerTranscript")
        title.setProperty("heading", True)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        layout.addSpacing(8)

        # Aktions-Buttons
        for label, callback in [
            ("Einstellungen", self._on_settings),
            ("Statistiken", self._on_statistics),
            ("Wortliste", self._on_word_list),
            ("Fenster-Zuordnung", self._on_window_mapping),
        ]:
            btn = QPushButton(label)
            btn.clicked.connect(callback)
            layout.addWidget(btn)

        layout.addStretch()

        # Beenden-Button
        btn_quit = QPushButton("Beenden")
        btn_quit.setStyleSheet("color: #e94560;")
        btn_quit.clicked.connect(self._on_quit)
        layout.addWidget(btn_quit)

    def _on_settings(self) -> None:
        self.open_settings.emit()
        self.close()

    def _on_statistics(self) -> None:
        self.open_statistics.emit()
        self.close()

    def _on_word_list(self) -> None:
        self.open_word_list.emit()
        self.close()

    def _on_window_mapping(self) -> None:
        self.open_window_mapping.emit()
        self.close()

    def _on_quit(self) -> None:
        self.quit_app.emit()
        self.close()
