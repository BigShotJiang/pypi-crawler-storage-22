﻿"""Einstellungsfenster für PayPerTranscript.

Tab-basiertes Settings-Fenster: Allgemein, API, Overlay, Daten.
Alle Änderungen werden sofort in der Config gespeichert (Auto-Save).
"""

import threading

from PySide6.QtCore import QObject, Qt, Signal, Slot
from PySide6.QtWidgets import (
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QDialog,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QRadioButton,
    QSpinBox,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from paypertranscript.core.config import ConfigManager, load_api_key, save_api_key
from paypertranscript.core.hotkey import HotkeyListener
from paypertranscript.core.logging import get_logger

log = get_logger("ui.settings")

# Sprachen für Whisper (ISO-639-1 → Anzeigename) — identisch mit setup_wizard.py
_LANGUAGES = [
    ("de", "Deutsch"),
    ("en", "English"),
    ("fr", "Fran\u00e7ais"),
    ("es", "Espa\u00f1ol"),
    ("it", "Italiano"),
    ("pt", "Portugu\u00eas"),
    ("nl", "Nederlands"),
    ("pl", "Polski"),
    ("ru", "\u0420\u0443\u0441\u0441\u043a\u0438\u0439"),
    ("ja", "\u65e5\u672c\u8a9e"),
    ("zh", "\u4e2d\u6587"),
    ("ko", "\ud55c\uad6d\uc5b4"),
    ("tr", "T\u00fcrk\u00e7e"),
    ("ar", "\u0627\u0644\u0639\u0631\u0628\u064a\u0629"),
    ("uk", "\u0423\u043a\u0440\u0430\u0457\u043d\u0441\u044c\u043a\u0430"),
]

# Hotkey-Presets — identisch mit setup_wizard.py
_HOLD_PRESETS: list[tuple[str, list[str]]] = [
    ("Ctrl + Win", ["ctrl", "cmd"]),
    ("Ctrl + Alt", ["ctrl", "alt"]),
    ("Ctrl + Shift", ["ctrl", "shift"]),
]

_TOGGLE_PRESETS: list[tuple[str, list[str] | None]] = [
    ("Keiner", None),
    ("Ctrl + Win", ["ctrl", "cmd"]),
    ("Ctrl + Alt", ["ctrl", "alt"]),
    ("Ctrl + Shift", ["ctrl", "shift"]),
]

# STT-Modelle
_STT_MODELS = [
    "whisper-large-v3-turbo",
    "whisper-large-v3",
]

# LLM-Modelle
_LLM_MODELS = [
    "openai/gpt-oss-20b",
]


class _ApiTestSignals(QObject):
    """Signals für die API-Key-Validierung im Background-Thread."""

    success = Signal()
    failure = Signal(str)


class SettingsDialog(QDialog):
    """Einstellungsfenster mit 4 Tabs: Allgemein, API, Overlay, Daten."""

    def __init__(
        self,
        config: ConfigManager,
        hotkey_listener: HotkeyListener | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._config = config
        self._hotkey_listener = hotkey_listener
        self._updating = False  # Verhindert Endlos-Loops bei Widget-Updates

        # API-Test Signals
        self._api_signals = _ApiTestSignals()
        self._api_signals.success.connect(self._on_api_test_success)
        self._api_signals.failure.connect(self._on_api_test_failure)

        self._setup_ui()
        self._load_values()
        log.info("Einstellungsfenster geöffnet")

    def _setup_ui(self) -> None:
        self.setWindowTitle("PayPerTranscript — Einstellungen")
        self.setFixedSize(560, 580)
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowCloseButtonHint)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        # Überschrift
        title = QLabel("Einstellungen")
        title.setProperty("heading", True)
        layout.addWidget(title)

        # Tabs
        self._tabs = QTabWidget()
        self._tabs.addTab(self._build_general_tab(), "Allgemein")
        self._tabs.addTab(self._build_api_tab(), "API")
        self._tabs.addTab(self._build_overlay_tab(), "Overlay")
        self._tabs.addTab(self._build_data_tab(), "Daten")
        self._tabs.addTab(self._build_updates_tab(), "Updates")
        layout.addWidget(self._tabs, 1)

        # Schließen
        btn_close = QPushButton("Schließen")
        btn_close.clicked.connect(self.close)
        layout.addWidget(btn_close)

    # -- Tab: Allgemein --

    def _build_general_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        # Sprache
        lang_label = QLabel("Transkriptions-Sprache:")
        layout.addWidget(lang_label)

        self._lang_combo = QComboBox()
        for code, name in _LANGUAGES:
            self._lang_combo.addItem(name, code)
        self._lang_combo.currentIndexChanged.connect(self._on_language_changed)
        layout.addWidget(self._lang_combo)

        # Checkboxen
        self._chk_sound = QCheckBox("Sound-Feedback bei Aufnahme")
        self._chk_sound.stateChanged.connect(self._on_sound_changed)
        layout.addWidget(self._chk_sound)

        self._chk_autostart = QCheckBox("Autostart mit Windows")
        self._chk_autostart.stateChanged.connect(self._on_autostart_changed)
        layout.addWidget(self._chk_autostart)

        self._chk_streaming = QCheckBox("Streaming-Typing (experimentell)")
        self._chk_streaming.setToolTip(
            "Text wird w\u00e4hrend der LLM-Formatierung live Zeichen f\u00fcr Zeichen eingef\u00fcgt.\n"
            "Kann in manchen Anwendungen Probleme verursachen."
        )
        self._chk_streaming.stateChanged.connect(self._on_streaming_changed)
        layout.addWidget(self._chk_streaming)

        # Hotkeys
        hotkey_group = QGroupBox("Hotkeys")
        hotkey_layout = QVBoxLayout(hotkey_group)
        hotkey_layout.setSpacing(8)
        hotkey_layout.setContentsMargins(12, 20, 12, 12)

        hold_label = QLabel("Hold-to-Record (gedr\u00fcckt halten = Aufnahme):")
        hotkey_layout.addWidget(hold_label)

        self._hold_combo = QComboBox()
        for name, _keys in _HOLD_PRESETS:
            self._hold_combo.addItem(name)
        self._hold_combo.currentIndexChanged.connect(self._on_hold_hotkey_changed)
        hotkey_layout.addWidget(self._hold_combo)

        hotkey_layout.addSpacing(8)

        toggle_label = QLabel("Toggle-Hotkey (einmal dr\u00fccken = Start/Stop):")
        hotkey_layout.addWidget(toggle_label)

        self._toggle_combo = QComboBox()
        for name, _keys in _TOGGLE_PRESETS:
            self._toggle_combo.addItem(name)
        self._toggle_combo.currentIndexChanged.connect(self._on_toggle_hotkey_changed)
        hotkey_layout.addWidget(self._toggle_combo)

        layout.addWidget(hotkey_group)
        layout.addStretch()
        return page

    # -- Tab: API --

    def _build_api_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        # API-Key
        key_label = QLabel("GroqCloud API-Key:")
        layout.addWidget(key_label)

        self._key_input = QLineEdit()
        self._key_input.setPlaceholderText("gsk_...")
        self._key_input.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(self._key_input)

        # Buttons: Anzeigen + Testen
        btn_row = QHBoxLayout()

        self._btn_show_key = QPushButton("Key anzeigen")
        self._btn_show_key.setFixedWidth(120)
        self._btn_show_key.setCheckable(True)
        self._btn_show_key.toggled.connect(self._on_toggle_key_visibility)
        btn_row.addWidget(self._btn_show_key)

        btn_row.addStretch()

        self._btn_save_key = QPushButton("Key speichern")
        self._btn_save_key.setFixedWidth(120)
        self._btn_save_key.clicked.connect(self._on_save_api_key)
        btn_row.addWidget(self._btn_save_key)

        self._btn_test_key = QPushButton("Key testen")
        self._btn_test_key.setFixedWidth(120)
        self._btn_test_key.clicked.connect(self._on_test_api_key)
        btn_row.addWidget(self._btn_test_key)

        layout.addLayout(btn_row)

        # Status
        self._api_status = QLabel("")
        self._api_status.setWordWrap(True)
        layout.addWidget(self._api_status)

        layout.addSpacing(16)

        # STT-Modell
        stt_label = QLabel("STT-Modell:")
        layout.addWidget(stt_label)

        self._stt_combo = QComboBox()
        self._stt_combo.addItems(_STT_MODELS)
        self._stt_combo.currentTextChanged.connect(self._on_stt_model_changed)
        layout.addWidget(self._stt_combo)

        # LLM-Modell
        llm_label = QLabel("LLM-Modell:")
        layout.addWidget(llm_label)

        self._llm_combo = QComboBox()
        self._llm_combo.addItems(_LLM_MODELS)
        self._llm_combo.currentTextChanged.connect(self._on_llm_model_changed)
        layout.addWidget(self._llm_combo)

        # Hinweis
        hint = QLabel("Modell-\u00c4nderungen werden nach Neustart wirksam.")
        hint.setProperty("subheading", True)
        layout.addWidget(hint)

        layout.addStretch()
        return page

    # -- Tab: Overlay --

    def _build_overlay_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        desc = QLabel("Position des Status-Overlays w\u00e4hrend der Transkription:")
        desc.setWordWrap(True)
        layout.addWidget(desc)

        layout.addSpacing(8)

        self._radio_mouse = QRadioButton("An Maus-Position (Standard)")
        self._radio_center = QRadioButton("Bildschirm-Mitte unten")

        self._overlay_group = QButtonGroup(self)
        self._overlay_group.addButton(self._radio_mouse, 0)
        self._overlay_group.addButton(self._radio_center, 1)
        self._overlay_group.idClicked.connect(self._on_overlay_position_changed)

        layout.addWidget(self._radio_mouse)
        layout.addWidget(self._radio_center)

        layout.addStretch()
        return page

    # -- Tab: Daten --

    def _build_data_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        # Audio-Retention
        retention_label = QLabel("Audio-Dateien behalten:")
        layout.addWidget(retention_label)

        retention_row = QHBoxLayout()
        self._retention_spin = QSpinBox()
        self._retention_spin.setRange(0, 720)
        self._retention_spin.setSuffix(" Stunden")
        self._retention_spin.setSpecialValueText("Sofort l\u00f6schen")
        self._retention_spin.valueChanged.connect(self._on_retention_changed)
        retention_row.addWidget(self._retention_spin)
        retention_row.addStretch()
        layout.addLayout(retention_row)

        retention_hint = QLabel("0 = sofort nach Transkription l\u00f6schen")
        retention_hint.setProperty("subheading", True)
        layout.addWidget(retention_hint)

        layout.addSpacing(16)

        # Transkripte speichern
        self._chk_transcripts = QCheckBox("Transkripte speichern")
        self._chk_transcripts.setToolTip(
            "Speichert den transkribierten Text in der Tracking-Datei.\n"
            "Deaktiviert = nur Metadaten (Kosten, Dauer etc.) werden gespeichert."
        )
        self._chk_transcripts.stateChanged.connect(self._on_transcripts_changed)
        layout.addWidget(self._chk_transcripts)

        layout.addStretch()
        return page

    # -- Tab: Updates --

    def _build_updates_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        # Auto-Update Toggle
        self._chk_auto_update = QCheckBox("Automatische Updates")
        self._chk_auto_update.setToolTip(
            "Pr\u00fcft beim Start und periodisch auf neue Versionen.\n"
            "Updates werden automatisch installiert."
        )
        self._chk_auto_update.stateChanged.connect(self._on_auto_update_changed)
        layout.addWidget(self._chk_auto_update)

        layout.addSpacing(8)

        # Check-Intervall
        interval_label = QLabel("Pr\u00fcfintervall:")
        layout.addWidget(interval_label)

        interval_row = QHBoxLayout()
        self._interval_spin = QSpinBox()
        self._interval_spin.setRange(1, 168)
        self._interval_spin.setSuffix(" Stunden")
        self._interval_spin.valueChanged.connect(self._on_interval_changed)
        interval_row.addWidget(self._interval_spin)
        interval_row.addStretch()
        layout.addLayout(interval_row)

        interval_hint = QLabel("Wie oft w\u00e4hrend der Laufzeit gepr\u00fcft wird")
        interval_hint.setProperty("subheading", True)
        layout.addWidget(interval_hint)

        layout.addSpacing(16)

        # Aktuelle Version
        from paypertranscript import __version__

        version_label = QLabel(f"Installierte Version: {__version__}")
        layout.addWidget(version_label)

        layout.addStretch()
        return page

    # -- Werte laden --

    def _load_values(self) -> None:
        """Lädt alle Config-Werte in die Widgets."""
        self._updating = True

        # Allgemein
        language = self._config.get("general.language", "de")
        for i in range(self._lang_combo.count()):
            if self._lang_combo.itemData(i) == language:
                self._lang_combo.setCurrentIndex(i)
                break

        self._chk_sound.setChecked(self._config.get("general.sound_enabled", False))
        self._chk_autostart.setChecked(self._config.get("general.autostart", False))
        self._chk_streaming.setChecked(self._config.get("general.streaming_typing", False))

        # Hotkeys
        hold = self._config.get("general.hold_hotkey", ["ctrl", "cmd"])
        for i, (_name, keys) in enumerate(_HOLD_PRESETS):
            if keys == hold:
                self._hold_combo.setCurrentIndex(i)
                break

        toggle = self._config.get("general.toggle_hotkey")
        for i, (_name, keys) in enumerate(_TOGGLE_PRESETS):
            if keys == toggle:
                self._toggle_combo.setCurrentIndex(i)
                break

        # API
        api_key = load_api_key() or ""
        self._key_input.setText(api_key)

        stt_model = self._config.get("api.stt_model", "whisper-large-v3-turbo")
        idx = self._stt_combo.findText(stt_model)
        if idx >= 0:
            self._stt_combo.setCurrentIndex(idx)

        llm_model = self._config.get("api.llm_model", "openai/gpt-oss-20b")
        idx = self._llm_combo.findText(llm_model)
        if idx >= 0:
            self._llm_combo.setCurrentIndex(idx)

        # Overlay
        position = self._config.get("general.overlay_position", "mouse_cursor")
        if position == "bottom_center":
            self._radio_center.setChecked(True)
        else:
            self._radio_mouse.setChecked(True)

        # Daten
        self._retention_spin.setValue(self._config.get("data.audio_retention_hours", 24))
        self._chk_transcripts.setChecked(self._config.get("data.save_transcripts", False))

        # Updates
        self._chk_auto_update.setChecked(self._config.get("updates.auto_update", True))
        self._interval_spin.setValue(self._config.get("updates.check_interval_hours", 24))

        self._updating = False

    # -- Callbacks: Allgemein --

    def _on_language_changed(self, index: int) -> None:
        if self._updating:
            return
        code = self._lang_combo.itemData(index)
        self._config.set("general.language", code)
        log.info("Sprache geändert: %s", code)

    def _on_sound_changed(self, state: int) -> None:
        if self._updating:
            return
        checked = state == Qt.CheckState.Checked.value
        self._config.set("general.sound_enabled", checked)

    def _on_autostart_changed(self, state: int) -> None:
        if self._updating:
            return
        checked = state == Qt.CheckState.Checked.value
        from paypertranscript.core.config import disable_autostart, enable_autostart

        success = enable_autostart() if checked else disable_autostart()
        if success:
            self._config.set("general.autostart", checked)
        else:
            self._updating = True
            self._chk_autostart.setChecked(not checked)
            self._updating = False

    def _on_streaming_changed(self, state: int) -> None:
        if self._updating:
            return
        checked = state == Qt.CheckState.Checked.value
        self._config.set("general.streaming_typing", checked)

    def _on_hold_hotkey_changed(self, index: int) -> None:
        if self._updating:
            return
        _name, keys = _HOLD_PRESETS[index]
        self._config.set("general.hold_hotkey", keys)
        if self._hotkey_listener:
            self._hotkey_listener.update_hotkeys(hold_hotkey=keys)
        log.info("Hold-Hotkey geändert: %s", _name)

    def _on_toggle_hotkey_changed(self, index: int) -> None:
        if self._updating:
            return
        _name, keys = _TOGGLE_PRESETS[index]
        self._config.set("general.toggle_hotkey", keys)
        if self._hotkey_listener and keys is not None:
            self._hotkey_listener.update_hotkeys(toggle_hotkey=keys)
        log.info("Toggle-Hotkey geändert: %s", _name)

    # -- Callbacks: API --

    def _on_toggle_key_visibility(self, checked: bool) -> None:
        if checked:
            self._key_input.setEchoMode(QLineEdit.EchoMode.Normal)
            self._btn_show_key.setText("Key verbergen")
        else:
            self._key_input.setEchoMode(QLineEdit.EchoMode.Password)
            self._btn_show_key.setText("Key anzeigen")

    def _on_save_api_key(self) -> None:
        key = self._key_input.text().strip()
        if not key:
            self._api_status.setText("Bitte API-Key eingeben.")
            self._api_status.setStyleSheet("color: #e94560;")
            return
        try:
            save_api_key(key)
            self._api_status.setText("API-Key gespeichert.")
            self._api_status.setStyleSheet("color: #ffffff;")
            log.info("API-Key im Keyring gespeichert")
        except Exception as e:
            self._api_status.setText(f"Fehler beim Speichern: {e}")
            self._api_status.setStyleSheet("color: #e94560;")
            log.error("API-Key konnte nicht gespeichert werden: %s", e)

    def _on_test_api_key(self) -> None:
        key = self._key_input.text().strip()
        if not key:
            self._api_status.setText("Bitte API-Key eingeben.")
            self._api_status.setStyleSheet("color: #e94560;")
            return

        self._api_status.setText("Wird gepr\u00fcft...")
        self._api_status.setStyleSheet("color: #a0a0a0;")
        self._btn_test_key.setEnabled(False)

        signals = self._api_signals

        def _test() -> None:
            try:
                import groq

                client = groq.Groq(api_key=key)
                client.models.list()
                signals.success.emit()
            except Exception as e:
                signals.failure.emit(str(e))

        threading.Thread(target=_test, daemon=True).start()

    @Slot()
    def _on_api_test_success(self) -> None:
        self._btn_test_key.setEnabled(True)
        self._api_status.setText("API-Key ist g\u00fcltig!")
        self._api_status.setStyleSheet("color: #ffffff; font-weight: bold;")

    @Slot(str)
    def _on_api_test_failure(self, message: str) -> None:
        self._btn_test_key.setEnabled(True)
        if "AuthenticationError" in message or "401" in message:
            text = "API-Key ist ung\u00fcltig."
        elif "Connection" in message:
            text = "Keine Verbindung zu GroqCloud."
        else:
            text = f"Fehler: {message}"
        self._api_status.setText(text)
        self._api_status.setStyleSheet("color: #e94560;")

    def _on_stt_model_changed(self, text: str) -> None:
        if self._updating:
            return
        self._config.set("api.stt_model", text)

    def _on_llm_model_changed(self, text: str) -> None:
        if self._updating:
            return
        self._config.set("api.llm_model", text)

    # -- Callbacks: Overlay --

    def _on_overlay_position_changed(self, button_id: int) -> None:
        if self._updating:
            return
        position = "mouse_cursor" if button_id == 0 else "bottom_center"
        self._config.set("general.overlay_position", position)
        log.info("Overlay-Position geändert: %s", position)

    # -- Callbacks: Daten --

    def _on_retention_changed(self, value: int) -> None:
        if self._updating:
            return
        self._config.set("data.audio_retention_hours", value)

    def _on_transcripts_changed(self, state: int) -> None:
        if self._updating:
            return
        checked = state == Qt.CheckState.Checked.value
        self._config.set("data.save_transcripts", checked)

    # -- Callbacks: Updates --

    def _on_auto_update_changed(self, state: int) -> None:
        if self._updating:
            return
        checked = state == Qt.CheckState.Checked.value
        self._config.set("updates.auto_update", checked)

    def _on_interval_changed(self, value: int) -> None:
        if self._updating:
            return
        self._config.set("updates.check_interval_hours", value)
