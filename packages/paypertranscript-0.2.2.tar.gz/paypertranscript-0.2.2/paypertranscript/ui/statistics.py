﻿"""Statistik-Dashboard fuer PayPerTranscript.

Zeigt Nutzungsstatistiken, Kosten und Abo-Vergleichsrechnung.
"""

from collections import defaultdict
from datetime import datetime, timedelta, timezone

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont, QPainter
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from paypertranscript.core.logging import get_logger
from paypertranscript.core.session_logger import SessionLogger

log = get_logger("ui.statistics")

# Ungefaehrer Wechselkurs (statisch, koennte spaeter konfigurierbar werden)
_USD_TO_EUR = 0.92


class _StatCard(QFrame):
    """Einzelne Statistik-Karte mit Titel und Wert."""

    def __init__(self, title: str, value: str = "—", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setStyleSheet(
            "background-color: #1c1c24; border: 1px solid #333340; border-radius: 8px;"
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(4)

        self._title_label = QLabel(title)
        self._title_label.setStyleSheet("color: #a0a0a0; font-size: 8pt; border: none;")
        layout.addWidget(self._title_label)

        self._value_label = QLabel(value)
        self._value_label.setStyleSheet("color: #ffffff; font-size: 13pt; font-weight: bold; border: none;")
        layout.addWidget(self._value_label)

    def set_value(self, value: str) -> None:
        """Setzt den angezeigten Wert."""
        self._value_label.setText(value)

    def set_color(self, color: str) -> None:
        """Setzt die Farbe des Werts."""
        self._value_label.setStyleSheet(
            f"color: {color}; font-size: 13pt; font-weight: bold; border: none;"
        )


class _CostSplitBar(QWidget):
    """Horizontaler Proportionsbalken: Transkription vs. Formatierung."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._stt_ratio = 0.0  # 0.0 – 1.0
        self._stt_label = ""
        self._llm_label = ""
        self.setFixedHeight(48)
        self.setStyleSheet("background-color: transparent;")

    def set_data(self, stt_cost: float, llm_cost: float) -> None:
        """Setzt die Kostendaten.

        Args:
            stt_cost: STT-Kosten in USD.
            llm_cost: LLM-Kosten in USD.
        """
        total = stt_cost + llm_cost
        if total > 0:
            self._stt_ratio = stt_cost / total
        else:
            self._stt_ratio = 1.0

        stt_pct = self._stt_ratio * 100
        llm_pct = 100 - stt_pct
        self._stt_label = f"Transkription ${stt_cost:.4f} ({stt_pct:.0f}%)"
        self._llm_label = f"Formatierung ${llm_cost:.4f} ({llm_pct:.0f}%)"
        self.update()

    def paintEvent(self, event: object) -> None:
        """Zeichnet den Proportionsbalken."""
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        w = self.width()
        bar_y = 0
        bar_h = 20
        radius = 4

        # Hintergrund (LLM-Anteil)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#e94560"))
        p.drawRoundedRect(0, bar_y, w, bar_h, radius, radius)

        # STT-Anteil (ueberlagert links)
        stt_w = max(0, int(w * self._stt_ratio))
        if stt_w > 0:
            p.setBrush(QColor("#ffffff"))
            if stt_w >= w:
                p.drawRoundedRect(0, bar_y, stt_w, bar_h, radius, radius)
            else:
                # Linke Seite abgerundet, rechte Kante gerade
                p.drawRoundedRect(0, bar_y, stt_w + radius, bar_h, radius, radius)
                p.drawRect(stt_w, bar_y, radius, bar_h)

        # Labels unter dem Balken
        font = QFont("Segoe UI", 9)
        p.setFont(font)

        p.setPen(QColor("#a0a0a0"))
        if self._stt_label:
            p.drawText(0, bar_y + bar_h + 16, self._stt_label)
        if self._llm_label:
            fm = p.fontMetrics()
            text_w = fm.horizontalAdvance(self._llm_label)
            p.drawText(w - text_w, bar_y + bar_h + 16, self._llm_label)

        p.end()


class _CostBarChart(QWidget):
    """Einfaches Balkendiagramm fuer Kosten-Verlauf (letzte 7/30 Tage)."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._data: list[tuple[str, float]] = []
        self.setMinimumHeight(120)
        self.setStyleSheet("background-color: transparent;")

    def set_data(self, data: list[tuple[str, float]]) -> None:
        """Setzt die Daten fuer das Diagramm.

        Args:
            data: Liste von (Datums-Label, Kosten in USD).
        """
        self._data = data
        self.update()

    def paintEvent(self, event: object) -> None:
        """Zeichnet das Balkendiagramm."""
        if not self._data:
            return

        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        w = self.width()
        h = self.height()
        margin_bottom = 20
        margin_top = 10
        chart_h = h - margin_bottom - margin_top

        max_val = max((v for _, v in self._data), default=0.0)
        if max_val <= 0:
            max_val = 0.001

        bar_count = len(self._data)
        if bar_count == 0:
            p.end()
            return

        gap = 4
        bar_w = max(4, (w - (bar_count + 1) * gap) / bar_count)

        font = QFont("Segoe UI", 7)
        p.setFont(font)

        for i, (label, value) in enumerate(self._data):
            x = gap + i * (bar_w + gap)
            bar_h = max(2, (value / max_val) * chart_h)
            y = margin_top + chart_h - bar_h

            # Balken
            color = QColor("#ffffff")
            color.setAlpha(180)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(color)
            p.drawRoundedRect(int(x), int(y), int(bar_w), int(bar_h), 2, 2)

            # Datums-Labels (nur einige anzeigen fuer Lesbarkeit)
            if bar_count <= 7 or i % 5 == 0 or i == bar_count - 1:
                p.setPen(QColor("#a0a0a0"))
                p.drawText(int(x), h - 2, label)

        p.end()


class StatisticsDialog(QDialog):
    """Statistik-Dashboard mit Kosten, Nutzung und Vergleich."""

    def __init__(
        self,
        session_logger: SessionLogger,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._logger = session_logger
        self._setup_ui()
        self._refresh_data()
        log.info("Statistik-Dialog geoeffnet")

    def _setup_ui(self) -> None:
        """Erstellt das UI-Layout."""
        self.setWindowTitle("PayPerTranscript — Statistiken")
        self.setFixedSize(520, 700)
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowCloseButtonHint)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        # Titel
        title = QLabel("Statistiken")
        title.setProperty("heading", True)
        layout.addWidget(title)

        # Haupt-Karten: 2x2 Grid
        grid = QGridLayout()
        grid.setSpacing(10)

        self._card_total_cost = _StatCard("Gesamtkosten")
        self._card_monthly_projection = _StatCard("Hochrechnung / Monat")
        self._card_sessions = _StatCard("Transkriptionen")
        self._card_audio_time = _StatCard("Audio-Dauer gesamt")

        grid.addWidget(self._card_total_cost, 0, 0)
        grid.addWidget(self._card_monthly_projection, 0, 1)
        grid.addWidget(self._card_sessions, 1, 0)
        grid.addWidget(self._card_audio_time, 1, 1)
        layout.addLayout(grid)

        # Zusaetzliche Metriken
        metrics_row = QHBoxLayout()
        metrics_row.setSpacing(10)

        self._card_avg_duration = _StatCard("Durchschn. Aufnahme")
        self._card_avg_cost = _StatCard("Durchschn. Kosten")
        metrics_row.addWidget(self._card_avg_duration)
        metrics_row.addWidget(self._card_avg_cost)
        layout.addLayout(metrics_row)

        # Kostenaufteilung
        split_label = QLabel("Kostenaufteilung")
        split_label.setStyleSheet("font-weight: bold; color: #ffffff;")
        layout.addWidget(split_label)

        self._cost_split = _CostSplitBar()
        layout.addWidget(self._cost_split)

        # Kosten-Verlauf
        chart_header = QHBoxLayout()
        chart_label = QLabel("Kosten-Verlauf")
        chart_label.setStyleSheet("font-weight: bold; color: #ffffff;")
        chart_header.addWidget(chart_label)
        chart_header.addStretch()

        self._period_combo = QComboBox()
        self._period_combo.addItems(["Letzte 7 Tage", "Letzte 30 Tage"])
        self._period_combo.currentIndexChanged.connect(self._on_period_changed)
        self._period_combo.setFixedWidth(140)
        chart_header.addWidget(self._period_combo)
        layout.addLayout(chart_header)

        self._cost_chart = _CostBarChart()
        layout.addWidget(self._cost_chart)

        # Top Apps
        apps_label = QLabel("Meistgenutzte Apps")
        apps_label.setStyleSheet("font-weight: bold; color: #ffffff;")
        layout.addWidget(apps_label)

        self._apps_label = QLabel("—")
        self._apps_label.setProperty("subheading", True)
        self._apps_label.setWordWrap(True)
        layout.addWidget(self._apps_label)

        layout.addStretch()

        # Schliessen-Button
        btn_close = QPushButton("Schliessen")
        btn_close.clicked.connect(self.close)
        layout.addWidget(btn_close)

    def _refresh_data(self) -> None:
        """Laedt alle Daten und aktualisiert die Anzeige."""
        totals = self._logger.get_totals()
        sessions = self._logger.get_sessions()

        # Gemeinsame Werte
        total_usd = totals.get("total_cost_usd", 0.0)
        total_eur = total_usd * _USD_TO_EUR
        count = totals.get("session_count", 0)

        # Gesamtkosten
        self._card_total_cost.set_value(f"${total_usd:.4f} (~{total_eur:.4f} EUR)")

        # Anzahl Sessions
        self._card_sessions.set_value(str(count))

        # Hochrechnung: Kosten pro Monat bei aktuellem Nutzungstempo
        if sessions and count > 0:
            first_ts = sessions[0].get("timestamp", "")
            try:
                first_dt = datetime.fromisoformat(first_ts)
                now = datetime.now(timezone.utc)
                days_active = max(1, (now - first_dt).days)
            except (ValueError, TypeError):
                days_active = 1

            daily_cost = total_usd / days_active
            monthly_usd = daily_cost * 30
            monthly_eur = monthly_usd * _USD_TO_EUR
            self._card_monthly_projection.set_value(f"~${monthly_usd:.4f} (~{monthly_eur:.4f} EUR)")
        else:
            self._card_monthly_projection.set_value("—")

        # Audio-Gesamtdauer
        total_seconds = totals.get("total_audio_seconds", 0.0)
        minutes = total_seconds / 60.0
        if minutes >= 60:
            self._card_audio_time.set_value(f"{minutes / 60:.1f} Stunden")
        else:
            self._card_audio_time.set_value(f"{minutes:.1f} Minuten")

        # Durchschnittliche Aufnahmedauer
        if count > 0:
            avg_sec = total_seconds / count
            self._card_avg_duration.set_value(f"{avg_sec:.1f}s")
        else:
            self._card_avg_duration.set_value("—")

        # Durchschnittliche Kosten pro Session
        if count > 0:
            avg_cost = total_usd / count
            self._card_avg_cost.set_value(f"${avg_cost:.6f}")
        else:
            self._card_avg_cost.set_value("—")

        # Kostenaufteilung (STT vs. LLM)
        stt_cost = totals.get("total_stt_cost_usd", 0.0)
        llm_cost = totals.get("total_llm_cost_usd", 0.0)
        self._cost_split.set_data(stt_cost, llm_cost)

        # Kosten-Diagramm (Standard: 7 Tage)
        self._update_chart(7)

        # Top Apps
        self._update_top_apps(sessions)

    def _on_period_changed(self, index: int) -> None:
        """Handler fuer Perioden-Wechsel im Dropdown."""
        days = 7 if index == 0 else 30
        self._update_chart(days)

    def _update_chart(self, days: int) -> None:
        """Aktualisiert das Balkendiagramm fuer die letzten N Tage."""
        sessions = self._logger.get_sessions(days=days)

        # Kosten nach Tag gruppieren
        daily_costs: dict[str, float] = defaultdict(float)
        for s in sessions:
            try:
                dt = datetime.fromisoformat(s["timestamp"])
                day_key = dt.strftime("%d.%m")
                daily_costs[day_key] += s.get("total_cost_usd", 0.0)
            except (KeyError, ValueError):
                pass

        # Fehlende Tage auffuellen
        chart_data: list[tuple[str, float]] = []
        now = datetime.now(timezone.utc)
        for i in range(days - 1, -1, -1):
            day = now - timedelta(days=i)
            key = day.strftime("%d.%m")
            chart_data.append((key, daily_costs.get(key, 0.0)))

        self._cost_chart.set_data(chart_data)

    def _update_top_apps(self, sessions: list[dict]) -> None:
        """Aktualisiert die Anzeige der meistgenutzten Apps."""
        app_counts: dict[str, int] = defaultdict(int)
        for s in sessions:
            proc = s.get("window_process", "")
            if proc:
                app_counts[proc] += 1

        if not app_counts:
            self._apps_label.setText("Noch keine Daten")
            return

        top5 = sorted(app_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        lines = [f"{name} ({count}x)" for name, count in top5]
        self._apps_label.setText("  |  ".join(lines))

    def showEvent(self, event: object) -> None:
        """Daten bei jedem Anzeigen aktualisieren."""
        super().showEvent(event)
        self._refresh_data()
