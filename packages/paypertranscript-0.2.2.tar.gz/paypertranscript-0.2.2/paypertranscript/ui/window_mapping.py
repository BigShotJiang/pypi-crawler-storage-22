﻿"""Fenster-Zuordnungs-Editor für PayPerTranscript.

Verwaltet Window-Mappings (Prozessname → Kategorie) und Kategorien (Name + System-Prompt).
Alle Änderungen werden sofort in der Config gespeichert (Auto-Save).
"""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from paypertranscript.core.config import ConfigManager
from paypertranscript.core.logging import get_logger

log = get_logger("ui.window_mapping")


class WindowMappingDialog(QDialog):
    """Editor für Fenster-Zuordnungen und Formatierungs-Kategorien."""

    def __init__(self, config: ConfigManager, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._config = config
        self._current_category_key: str | None = None
        self._updating = False
        self._setup_ui()
        self._reload_all()
        log.info("Fenster-Zuordnungs-Editor geöffnet")

    def _setup_ui(self) -> None:
        self.setWindowTitle("PayPerTranscript — Fenster-Zuordnung")
        self.setFixedSize(560, 520)
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowCloseButtonHint)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        # Überschrift
        title = QLabel("Fenster-Zuordnung")
        title.setProperty("heading", True)
        layout.addWidget(title)

        desc = QLabel(
            "Ordne Anwendungen einer Formatierungs-Kategorie zu. "
            "Der transkribierte Text wird dann automatisch per LLM formatiert."
        )
        desc.setProperty("subheading", True)
        desc.setWordWrap(True)
        layout.addWidget(desc)

        # Tabs
        self._tabs = QTabWidget()
        self._tabs.addTab(self._create_mappings_tab(), "Zuordnungen")
        self._tabs.addTab(self._create_categories_tab(), "Kategorien")
        layout.addWidget(self._tabs, 1)

        # Schließen
        btn_close = QPushButton("Schließen")
        btn_close.clicked.connect(self.close)
        layout.addWidget(btn_close)

    # -- Tab: Zuordnungen --

    def _create_mappings_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(8, 12, 8, 8)
        layout.setSpacing(10)

        # Liste der Zuordnungen (Doppelklick zum Bearbeiten)
        self._mapping_list = QListWidget()
        self._mapping_list.itemDoubleClicked.connect(self._edit_mapping)
        layout.addWidget(self._mapping_list, 1)

        # Hinzufügen-Bereich
        add_label = QLabel("Neue Zuordnung:")
        add_label.setProperty("subheading", True)
        layout.addWidget(add_label)

        row1 = QHBoxLayout()
        row1.setSpacing(8)

        proc_label = QLabel("Prozess:")
        proc_label.setFixedWidth(52)
        row1.addWidget(proc_label)

        self._process_combo = QComboBox()
        self._process_combo.setEditable(True)
        self._process_combo.lineEdit().setPlaceholderText("z.\u202fB. chrome.exe")
        row1.addWidget(self._process_combo, 1)
        layout.addLayout(row1)

        row2 = QHBoxLayout()
        row2.setSpacing(8)

        cat_label = QLabel("Kategorie:")
        cat_label.setFixedWidth(52)
        row2.addWidget(cat_label)

        self._mapping_category_combo = QComboBox()
        row2.addWidget(self._mapping_category_combo, 1)
        layout.addLayout(row2)

        # Buttons
        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)

        btn_add = QPushButton("Hinzufügen")
        btn_add.setProperty("primary", True)
        btn_add.clicked.connect(self._add_mapping)
        btn_row.addWidget(btn_add)

        btn_edit = QPushButton("Bearbeiten")
        btn_edit.clicked.connect(self._edit_mapping)
        btn_row.addWidget(btn_edit)

        btn_remove = QPushButton("Entfernen")
        btn_remove.clicked.connect(self._remove_mapping)
        btn_row.addWidget(btn_remove)

        btn_row.addStretch()
        layout.addLayout(btn_row)

        return tab

    # -- Tab: Kategorien --

    def _create_categories_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(8, 12, 8, 8)
        layout.setSpacing(10)

        # Oberer Bereich: Liste + Editor nebeneinander
        content = QHBoxLayout()
        content.setSpacing(12)

        # Links: Kategorie-Liste
        left = QVBoxLayout()
        left.setSpacing(6)

        self._cat_list = QListWidget()
        self._cat_list.setFixedWidth(150)
        self._cat_list.currentItemChanged.connect(self._on_category_selected)
        left.addWidget(self._cat_list, 1)

        btn_new = QPushButton("Neue Kategorie")
        btn_new.clicked.connect(self._new_category)
        left.addWidget(btn_new)

        btn_del = QPushButton("Löschen")
        btn_del.clicked.connect(self._delete_category)
        left.addWidget(btn_del)

        content.addLayout(left)

        # Rechts: Name + Prompt
        right = QVBoxLayout()
        right.setSpacing(6)

        name_label = QLabel("Anzeigename:")
        right.addWidget(name_label)

        self._cat_name_input = QLineEdit()
        self._cat_name_input.setPlaceholderText("z.\u202fB. E-Mail, Notizen...")
        right.addWidget(self._cat_name_input)

        prompt_label = QLabel("System-Prompt:")
        right.addWidget(prompt_label)

        self._cat_prompt_input = QTextEdit()
        self._cat_prompt_input.setPlaceholderText(
            "Anweisung für das LLM...\n\n"
            "z.\u202fB. \"Formatiere den Text als professionelle E-Mail.\""
        )
        right.addWidget(self._cat_prompt_input, 1)

        btn_save = QPushButton("Speichern")
        btn_save.setProperty("primary", True)
        btn_save.clicked.connect(self._save_category)
        right.addWidget(btn_save)

        content.addLayout(right, 1)
        layout.addLayout(content, 1)

        return tab

    # -- Daten laden --

    def _reload_all(self) -> None:
        """Lädt alle Daten aus der Config in die UI."""
        self._updating = True
        self._load_categories()
        self._load_mappings()
        self._populate_process_combo()
        self._updating = False

    def _load_categories(self) -> None:
        """Lädt die Kategorien in Liste und Dropdowns."""
        categories = self._config.get("formatting.categories", {})

        # Kategorie-Liste (Tab 2)
        self._cat_list.clear()
        for key, cat in categories.items():
            item = QListWidgetItem(cat.get("name", key))
            item.setData(Qt.ItemDataRole.UserRole, key)
            self._cat_list.addItem(item)

        # Kategorie-Dropdown (Tab 1, für neue Zuordnungen)
        self._mapping_category_combo.clear()
        for key, cat in categories.items():
            self._mapping_category_combo.addItem(cat.get("name", key), key)

        # Bearbeitungsfelder leeren
        self._current_category_key = None
        self._cat_name_input.clear()
        self._cat_prompt_input.clear()

    def _load_mappings(self) -> None:
        """Lädt die Zuordnungen in die Mapping-Liste."""
        mappings = self._config.get("formatting.window_mappings", {})
        categories = self._config.get("formatting.categories", {})

        self._mapping_list.clear()
        for process_name, category_key in mappings.items():
            cat_name = categories.get(category_key, {}).get("name", category_key)
            display = f"{process_name}  \u2192  {cat_name}"
            item = QListWidgetItem(display)
            item.setData(Qt.ItemDataRole.UserRole, process_name)
            self._mapping_list.addItem(item)

    def _populate_process_combo(self) -> None:
        """Befüllt das Prozess-Dropdown mit laufenden Prozessen."""
        processes: set[str] = set()
        try:
            import psutil

            for proc in psutil.process_iter(["name"]):
                try:
                    name = proc.info["name"]
                    if name and name.endswith(".exe"):
                        processes.add(name)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
        except Exception:
            log.debug("Prozessliste konnte nicht geladen werden")

        self._process_combo.clear()
        for name in sorted(processes):
            self._process_combo.addItem(name)
        self._process_combo.setCurrentText("")

    # -- Zuordnungen --

    def _add_mapping(self) -> None:
        """Fügt eine neue Zuordnung hinzu."""
        process = self._process_combo.currentText().strip()
        if not process:
            return

        category_key = self._mapping_category_combo.currentData()
        if not category_key:
            return

        mappings = self._config.get("formatting.window_mappings", {})
        if process in mappings:
            QMessageBox.information(
                self,
                "Zuordnung existiert",
                f"'{process}' ist bereits zugeordnet.\n"
                "Entferne die bestehende Zuordnung zuerst.",
            )
            return

        mappings[process] = category_key
        self._config.set("formatting.window_mappings", mappings)
        self._process_combo.setCurrentText("")
        log.info("Zuordnung hinzugefügt: %s → %s", process, category_key)
        self._reload_all()

    def _edit_mapping(self) -> None:
        """Ändert die Kategorie-Zuordnung des ausgewählten Mappings."""
        current = self._mapping_list.currentItem()
        if not current:
            return

        process = current.data(Qt.ItemDataRole.UserRole)
        categories = self._config.get("formatting.categories", {})
        if not categories:
            return

        cat_names = [cat.get("name", key) for key, cat in categories.items()]
        cat_keys = list(categories.keys())

        mappings = self._config.get("formatting.window_mappings", {})
        current_cat_key = mappings.get(process, "")
        current_index = cat_keys.index(current_cat_key) if current_cat_key in cat_keys else 0

        chosen_name, ok = QInputDialog.getItem(
            self,
            "Kategorie ändern",
            f"Neue Kategorie für '{process}':",
            cat_names,
            current_index,
            False,
        )
        if not ok:
            return

        chosen_idx = cat_names.index(chosen_name)
        new_key = cat_keys[chosen_idx]

        mappings[process] = new_key
        self._config.set("formatting.window_mappings", mappings)
        log.info("Zuordnung geändert: %s → %s", process, new_key)
        self._reload_all()

    def _remove_mapping(self) -> None:
        """Entfernt die ausgewählte Zuordnung."""
        current = self._mapping_list.currentItem()
        if not current:
            return

        process = current.data(Qt.ItemDataRole.UserRole)
        mappings = self._config.get("formatting.window_mappings", {})
        mappings.pop(process, None)
        self._config.set("formatting.window_mappings", mappings)
        log.info("Zuordnung entfernt: %s", process)
        self._reload_all()

    # -- Kategorien --

    def _on_category_selected(
        self, current: QListWidgetItem | None, _previous: QListWidgetItem | None
    ) -> None:
        """Eine Kategorie wurde in der Liste ausgewählt."""
        if current is None:
            self._current_category_key = None
            self._cat_name_input.clear()
            self._cat_prompt_input.clear()
            return

        key = current.data(Qt.ItemDataRole.UserRole)
        self._current_category_key = key

        categories = self._config.get("formatting.categories", {})
        cat = categories.get(key, {})
        self._cat_name_input.setText(cat.get("name", ""))
        self._cat_prompt_input.setPlainText(cat.get("prompt", ""))

    def _save_category(self) -> None:
        """Speichert die bearbeitete Kategorie."""
        key = self._current_category_key
        if not key:
            return

        name = self._cat_name_input.text().strip()
        prompt = self._cat_prompt_input.toPlainText().strip()

        if not name:
            QMessageBox.warning(self, "Fehler", "Bitte einen Anzeigenamen eingeben.")
            return

        categories = self._config.get("formatting.categories", {})
        categories[key] = {"name": name, "prompt": prompt}
        self._config.set("formatting.categories", categories)
        log.info("Kategorie gespeichert: %s (%s)", key, name)

        # Liste + Mappings aktualisieren (Name könnte sich geändert haben)
        self._reload_all()

        # Vorherige Selektion wiederherstellen
        for i in range(self._cat_list.count()):
            item = self._cat_list.item(i)
            if item and item.data(Qt.ItemDataRole.UserRole) == key:
                self._cat_list.setCurrentItem(item)
                break

    def _new_category(self) -> None:
        """Erstellt eine neue Kategorie."""
        key, ok = QInputDialog.getText(
            self,
            "Neue Kategorie",
            "Interner Name (z.\u202fB. 'technical', 'notes'):",
        )
        if not ok or not key.strip():
            return

        key = key.strip().lower().replace(" ", "_")

        categories = self._config.get("formatting.categories", {})
        if key in categories:
            QMessageBox.warning(
                self,
                "Kategorie existiert",
                f"Eine Kategorie mit dem Key '{key}' existiert bereits.",
            )
            return

        categories[key] = {"name": key.replace("_", " ").title(), "prompt": ""}
        self._config.set("formatting.categories", categories)
        log.info("Neue Kategorie erstellt: %s", key)
        self._reload_all()

        # Neue Kategorie auswählen
        for i in range(self._cat_list.count()):
            item = self._cat_list.item(i)
            if item and item.data(Qt.ItemDataRole.UserRole) == key:
                self._cat_list.setCurrentItem(item)
                break

    def _delete_category(self) -> None:
        """Löscht die ausgewählte Kategorie und alle zugehörigen Mappings."""
        key = self._current_category_key
        if not key:
            return

        categories = self._config.get("formatting.categories", {})
        cat_name = categories.get(key, {}).get("name", key)

        reply = QMessageBox.question(
            self,
            "Kategorie löschen",
            f"Kategorie '{cat_name}' wirklich löschen?\n\n"
            "Alle zugehörigen Fenster-Zuordnungen werden ebenfalls entfernt.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return

        # Kategorie entfernen
        categories.pop(key, None)
        self._config.set("formatting.categories", categories)

        # Zugehörige Mappings entfernen
        mappings = self._config.get("formatting.window_mappings", {})
        cleaned = {k: v for k, v in mappings.items() if v != key}
        if len(cleaned) != len(mappings):
            self._config.set("formatting.window_mappings", cleaned)

        log.info(
            "Kategorie gelöscht: %s (+ %d Zuordnungen entfernt)",
            key,
            len(mappings) - len(cleaned),
        )
        self._reload_all()
