﻿"""Wortlisten-Editor für PayPerTranscript.

Verwaltet die Liste korrekt zu schreibender Wörter (Whisper-Prompt).
Wörter werden sofort in der Config gespeichert (Auto-Save).
"""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from paypertranscript.core.config import ConfigManager
from paypertranscript.core.logging import get_logger

log = get_logger("ui.word_list")

# Maximale Zeichenanzahl für den Whisper-Prompt (224 Tokens × ~4 Zeichen)
_MAX_PROMPT_CHARS = 896
_PROMPT_PREFIX = "Korrekte Schreibweisen: "


class WordListDialog(QDialog):
    """Editor für die Wortliste (Whisper Misspelled-Words-Prompt)."""

    def __init__(self, config: ConfigManager, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._config = config
        self._updating = False
        self._setup_ui()
        self._load_words()
        log.info("Wortlisten-Editor geöffnet")

    def _setup_ui(self) -> None:
        self.setWindowTitle("PayPerTranscript — Wortliste")
        self.setFixedSize(460, 460)
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowCloseButtonHint)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        # Überschrift
        title = QLabel("Wortliste")
        title.setProperty("heading", True)
        layout.addWidget(title)

        desc = QLabel(
            "Wörter die Whisper korrekt schreiben soll — "
            "z.\u202fB. deinen Namen, Fachbegriffe oder Produktnamen."
        )
        desc.setProperty("subheading", True)
        desc.setWordWrap(True)
        layout.addWidget(desc)

        # Eingabezeile + Hinzufügen
        input_row = QHBoxLayout()
        self._word_input = QLineEdit()
        self._word_input.setPlaceholderText("Neues Wort...")
        self._word_input.returnPressed.connect(self._add_word)
        input_row.addWidget(self._word_input)

        btn_add = QPushButton("Hinzufügen")
        btn_add.setProperty("primary", True)
        btn_add.setFixedWidth(100)
        btn_add.clicked.connect(self._add_word)
        input_row.addWidget(btn_add)
        layout.addLayout(input_row)

        # Wortliste (Doppelklick zum Bearbeiten)
        self._list = QListWidget()
        self._list.itemChanged.connect(self._on_word_edited)
        layout.addWidget(self._list, 1)

        # Entfernen + Token-Counter
        action_row = QHBoxLayout()
        btn_remove = QPushButton("Entfernen")
        btn_remove.setFixedWidth(100)
        btn_remove.clicked.connect(self._remove_word)
        action_row.addWidget(btn_remove)

        action_row.addStretch()

        self._counter_label = QLabel("")
        action_row.addWidget(self._counter_label)
        layout.addLayout(action_row)

        # Schließen
        btn_close = QPushButton("Schließen")
        btn_close.clicked.connect(self.close)
        layout.addWidget(btn_close)

    def _load_words(self) -> None:
        """Lädt die Wortliste aus der Config in die UI."""
        self._updating = True
        words = self._config.get("words.misspelled_words", [])
        self._list.clear()
        for word in words:
            item = QListWidgetItem(word)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsEditable)
            self._list.addItem(item)
        self._update_counter()
        self._updating = False

    def _save_words(self) -> None:
        """Speichert die aktuelle Wortliste in die Config."""
        words = [self._list.item(i).text() for i in range(self._list.count())]
        self._config.set("words.misspelled_words", words)
        self._update_counter()

    def _add_word(self) -> None:
        """Fügt ein neues Wort zur Liste hinzu."""
        word = self._word_input.text().strip()
        if not word:
            return

        # Duplikate prüfen
        for i in range(self._list.count()):
            if self._list.item(i).text().lower() == word.lower():
                self._word_input.clear()
                return

        item = QListWidgetItem(word)
        item.setFlags(item.flags() | Qt.ItemFlag.ItemIsEditable)
        self._list.addItem(item)
        self._word_input.clear()
        self._word_input.setFocus()
        self._save_words()
        log.info("Wort hinzugefügt: %s", word)

    def _remove_word(self) -> None:
        """Entfernt das ausgewählte Wort aus der Liste."""
        current = self._list.currentRow()
        if current < 0:
            return
        item = self._list.takeItem(current)
        if item:
            log.info("Wort entfernt: %s", item.text())
        self._save_words()

    def _on_word_edited(self, item: QListWidgetItem) -> None:
        """Verarbeitet Inline-Bearbeitung eines Wortes (Doppelklick)."""
        if self._updating:
            return
        new_text = item.text().strip()
        if not new_text:
            self._list.takeItem(self._list.row(item))
            self._save_words()
            return
        # Duplikat-Prüfung
        for i in range(self._list.count()):
            other = self._list.item(i)
            if other is not item and other.text().lower() == new_text.lower():
                self._load_words()
                return
        self._save_words()
        log.info("Wort bearbeitet: %s", new_text)

    def _update_counter(self) -> None:
        """Aktualisiert die Zeichenanzeige."""
        words = [self._list.item(i).text() for i in range(self._list.count())]
        if words:
            prompt = _PROMPT_PREFIX + ", ".join(words)
        else:
            prompt = ""
        chars_used = len(prompt)
        percentage = (chars_used / _MAX_PROMPT_CHARS) * 100 if _MAX_PROMPT_CHARS > 0 else 0

        self._counter_label.setText(f"{chars_used} / {_MAX_PROMPT_CHARS} Zeichen")

        if percentage > 90:
            self._counter_label.setStyleSheet("color: #e94560;")
        elif percentage > 75:
            self._counter_label.setStyleSheet("color: #f0a500;")
        else:
            self._counter_label.setStyleSheet("color: #ffffff;")
