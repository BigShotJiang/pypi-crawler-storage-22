from setuptools import setup

setup(
    name='payspace_sdk',
    version='0.1.0',    
    description='A simple SDK for interacting with the Payspace API',
    url='https://github.com/jb-tech1999/payspace_sdk',
    author='Jandre Badenhorst',
    author_email='j.badenhorst@decisioninc.com',
    packages=['payspace_sdk'],
    install_requires=['requests'],

    classifiers=[
        'Intended Audience :: Developers', 
        'Operating System :: POSIX :: Linux',        

        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
    ],
)