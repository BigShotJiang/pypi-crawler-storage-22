# -*- coding: utf-8 -*-
"""
pb_calibration：PB 标定文件校验、解析为 YAML、从 YAML 组装为 .pb.txt

提供 3 个功能：
1. check(pb_path) - 反序列化检查 pb.txt 是否存在格式问题
2. parse(pb_path, yaml_dir) - 解析 pb.txt 为每个单独的 yaml 文件，输出到指定目录（与组合位置一致）
3. build(yaml_dir, output_pb_path) - 按顺序将 yaml 目录中的文件组装成 pb.txt
"""

from .api import check, parse, build

__version__ = "0.1.0"
__all__ = ["check", "parse", "build", "__version__"]
