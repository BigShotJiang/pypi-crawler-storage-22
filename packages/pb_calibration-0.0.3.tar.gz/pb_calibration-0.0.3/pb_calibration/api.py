# -*- coding: utf-8 -*-
"""
对外 API：check、parse、build。

- 输出位置与组合位置一致：parse 输出到指定 yaml_dir，build 从同一 yaml_dir 读取并写出 pb.txt。
- yaml_dir 可任意指定，保证解析输出与组装输入使用同一目录即可。
"""

from pathlib import Path
from typing import Tuple, Optional

from ._parser import PBParser
from ._builder import PBBuilder
from ._proto_io import parse_pb_text


def check(
    pb_path: str,
    proto_templates_dir: Optional[str] = None,
) -> Tuple[bool, Optional[str]]:
    """
    反序列化检查 pb.txt 是否存在格式问题。
    严格按 calibration.proto 定义做标准反序列化，成功即通过。

    :param pb_path: .pb.txt 文件路径
    :param proto_templates_dir: 可选，保留兼容，检查时未使用
    :return: (是否通过, 错误信息)，通过时错误信息为 None
    """
    try:
        with open(pb_path, "r", encoding="utf-8") as f:
            content = f.read()
        parse_pb_text(content)
        return True, None
    except Exception as e:
        return False, str(e)


def parse(
    pb_path: str,
    yaml_dir: str,
    proto_templates_dir: Optional[str] = None,
) -> Tuple[dict, dict]:
    """
    解析 pb.txt 为每个单独的 yaml 文件，输出到指定目录。
    该目录与后续 build 时使用的「组合位置」一致，可指定为同一路径。

    :param pb_path: .pb.txt 文件路径
    :param yaml_dir: 输出目录（与 build 的输入目录一致，可指定）
    :param proto_templates_dir: 可选，proto 模板目录
    :return: (解析后的结构化数据, 缺项/漏项报告)
    :raises: 解析失败时抛出异常
    """
    parser = PBParser(proto_templates_dir=proto_templates_dir)
    return parser.parse_and_dump(pb_path, yaml_dir)


def build(
    yaml_dir: str,
    output_pb_path: str,
    proto_templates_dir: Optional[str] = None,
) -> None:
    """
    按顺序将 yaml_dir 中的单独 yaml 文件组装成 pb.txt。
    输入目录应与 parse 时的输出目录一致（可指定为同一路径）。

    :param yaml_dir: 包含 order_manifest.yaml 及分组 yaml 的目录（与 parse 输出位置一致）
    :param output_pb_path: 输出的 .pb.txt 文件路径
    :param proto_templates_dir: 可选，proto 模板目录
    """
    builder = PBBuilder(proto_templates_dir=proto_templates_dir)
    builder.build_file(yaml_dir, output_pb_path)
