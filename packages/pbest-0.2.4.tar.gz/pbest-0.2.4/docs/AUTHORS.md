# Authors of pbest:

The maintainers of the pbest project are:
* Ezequiel Valencia (@Ezequiel-Valencia)
* Logan C.W. Drescher (@CodeByDrescher)
