### This file will hold the complex code of version resolution and package allowances, once
### there is a need for such levels of inspection
