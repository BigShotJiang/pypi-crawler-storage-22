# pbs-installer

[![PyPI](https://img.shields.io/pypi/v/pbs-installer)](https://pypi.org/project/pbs-installer)

An installer for @indygreg's [python-build-standalone](https://github.com/astral-sh/python-build-standalone)

The list of python versions are kept sync with the upstream automatically, via a periodically GitHub Action.

[📖 Read the docs](http://pbs-installer.readthedocs.io/)
