# 📦 pccc-checker

[![PyPI version](https://img.shields.io/pypi/v/pccc-checker.svg)](https://pypi.org/project/pccc-checker/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**pccc-checker**는 관세청(UNI-PASS) 오픈 API를 활용하여 **개인통관고유부호(PCCC)**의 유효성을 간편하게 검증하는 Python 라이브러리입니다.

사용자의 성명, 전화번호, 통관번호가 일치하는지 실시간으로 확인하며, 보안을 위해 별도의 로그를 남기지 않고 HTTPS 통신만을 사용합니다.
  
---

## ✨ 주요 기능

* **실시간 유효성 검사**: 관세청 DB를 통해 성명/전화번호/부호 일치 여부 확인.
* **보안 중심**: 개인정보 및 API 키가 외부에 노출되거나 로그에 남지 않도록 설계.
* **간결한 인터페이스**: 단 몇 줄의 코드로 통합 가능.

---

## 🚀 설치 방법

```bash
pip install pccc-checker
```

---

## 🔑 API 키 발급 안내

이 라이브러리를 사용하려면 **관세청 UNI-PASS**의 오픈 API 키가 필요합니다.

1. [관세청 UNI-PASS 포털](https://unipass.customs.go.kr/) 접속 및 로그인.
2. **서비스 신청 > My메뉴(우측 상단) > 서비스관리(좌측 메뉴) > OpenAPI 사용관리 > OPEN API 신청** 메뉴 이동.
3. `수입신고 개인통관고유부호 검증` 서비스 신청.
4. 승인 후 발급된 **인증키(Customer Key)**를 복사하여 사용하세요.

---

## 💻 사용 예제

```python
from pccc_checker import PCCCValidator

# 1. 객체 생성 (관세청에서 발급받은 API 키 입력)
api_key = "YOUR_UNI_PASS_API_KEY"
checker = PCCCValidator(api_key)

# 2. 정보 검증 (성명, 전화번호, 통관부호)
result = checker.validate(
    name="홍길동",
    phone="01012345678",
    pccc="P123456789012"
)

# 3. 결과 확인
if result["success"]:
    print(f"✅ 확인 성공: {result['message']}")
else:
    print(f"❌ 확인 실패: {result['message']}")
```

---

## 📄 라이선스

이 프로젝트는 **MIT License**에 따라 자유롭게 수정 및 배포가 가능합니다!