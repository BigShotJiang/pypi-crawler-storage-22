// Simple program to test Windows resource file compilation
#include <stdio.h>

int main(void) {
    printf("Hello from Windows resource example!\n");
    return 0;
}
