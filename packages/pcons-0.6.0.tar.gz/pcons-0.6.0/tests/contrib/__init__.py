# SPDX-License-Identifier: MIT
"""Tests for pcons.contrib modules."""
