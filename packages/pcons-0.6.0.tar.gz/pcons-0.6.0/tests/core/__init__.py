# SPDX-License-Identifier: MIT
"""Tests for pcons.core modules."""
