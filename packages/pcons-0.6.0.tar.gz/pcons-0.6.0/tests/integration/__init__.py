# SPDX-License-Identifier: MIT
"""Integration tests for pcons."""
