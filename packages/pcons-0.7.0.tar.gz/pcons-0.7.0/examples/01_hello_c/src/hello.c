/*
 * Simple Hello World program
 * Demonstrates basic C compilation with pcons
 */

#include <stdio.h>

int main(void) {
    printf("Hello from pcons!\n");
    return 0;
}
