/* Library header */
#ifndef FOO_H
#define FOO_H

void foo_greet(const char* name);

#endif /* FOO_H */
