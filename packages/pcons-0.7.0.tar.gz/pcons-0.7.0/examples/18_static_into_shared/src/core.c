/* SPDX-License-Identifier: MIT */
/* Core functionality - compiled into a static library. */

int core_value(void)
{
    return 42;
}
