/* SPDX-License-Identifier: MIT */
/* Core library public header. */

#ifndef CORE_H
#define CORE_H

int core_value(void);

#endif /* CORE_H */
