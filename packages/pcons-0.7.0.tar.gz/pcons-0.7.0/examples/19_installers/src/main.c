// SPDX-License-Identifier: MIT
// Simple hello world program for installer example

#include <stdio.h>

int main(void) {
    printf("Hello from pcons installer example!\n");
    return 0;
}
