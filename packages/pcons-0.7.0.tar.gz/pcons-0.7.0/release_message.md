    Gary Oberbrunner (12):
          Fix graph generators: path-based labels and directory containment edges
          Add `pcons info --targets` to list all build targets
          Update CHANGELOG for graph generator fixes and info --targets
          Auto-detect directory sources in Install builder at resolve time
          Use proper github repo: DarkStarSystems/pcons
          Fix Install directory detection when build_dir is absolute
          Remove output_dir parameter from Generator.generate()
          Improve build_dir prefix warning in normalize_target_path
          Fix Install directory detection regression for relative build_dir
          Fix Install directory detection regression for relative build_dir
          Fix canonicalize test for Windows: use platform-absolute path
          Bump version to v0.7.0

