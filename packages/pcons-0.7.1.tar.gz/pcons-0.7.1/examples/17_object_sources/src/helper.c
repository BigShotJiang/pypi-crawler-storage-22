/* SPDX-License-Identifier: MIT */
/* Helper module compiled with special flags (e.g., different optimization). */

int get_value(void)
{
    return 42;
}
