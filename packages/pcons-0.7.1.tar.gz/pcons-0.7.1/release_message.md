    Gary Oberbrunner (7):
          Add Codecov token to CI workflow
          Add auto-generate to `pcons build` and improve CLI help
          Fix Install directory deps and node deduplication for ninja paths
          Refactor: Project as single authority for node creation
          Fix post_build $out expansion and InstallDir implicit deps
          Add $SRCDIR variable, target.depends(), and Command depends= parameter
          Bump version to v0.7.1

