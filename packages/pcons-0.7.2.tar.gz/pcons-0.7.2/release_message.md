    Gary Oberbrunner (3):
          Code simplification pass (-163 lines, no functional changes)
          Add msvcup contrib module for MSVC installation without Visual Studio (#9)
          Bump version to v0.7.2

