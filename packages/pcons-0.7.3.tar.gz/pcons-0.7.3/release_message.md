    Gary Oberbrunner (3):
          Add GitHub and ReadTheDocs links to --help output
          Fix C++ flags leaking to C compilation in mixed-language targets
          Bump version to v0.7.3

