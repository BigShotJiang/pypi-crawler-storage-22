import pandas as pd
import numpy as np
from pandas.api.types import is_numeric_dtype, is_datetime64_any_dtype


@pd.api.extensions.register_dataframe_accessor("schema_report")
class SchemaReportAccessor:
    def __init__(self, pandas_obj: pd.DataFrame):
        self._df = pandas_obj

    def __call__(self) -> pd.DataFrame:
        rows = []

        for col in self._df.columns:
            s = self._df[col]
            n = len(s)

            missing = s.isna().sum()
            missing_pct = (missing / n * 100) if n else 0.0

            rows.append({
                "column": col,
                "dtype": str(s.dtype),
                "nullable": missing > 0,
                "missing_pct": missing_pct,
                "unique": s.nunique(dropna=True),
                "min": self._min(s),
                "max": self._max(s),
                "example": self._example(s),
            })

        return pd.DataFrame(rows).set_index("column")

    @staticmethod
    def _min(s):
        if is_numeric_dtype(s) or is_datetime64_any_dtype(s):
            return s.min()
        return np.nan

    @staticmethod
    def _max(s):
        if is_numeric_dtype(s) or is_datetime64_any_dtype(s):
            return s.max()
        return np.nan

    @staticmethod
    def _example(s):
        try:
            return s.dropna().iloc[0]
        except IndexError:
            return np.nan
