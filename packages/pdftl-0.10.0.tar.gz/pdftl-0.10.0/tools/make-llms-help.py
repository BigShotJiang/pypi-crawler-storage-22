#!/usr/bin/env python

from pdftl.cli.help import print_help

print_help("all", None, True)
print_help("examples", None, True)
