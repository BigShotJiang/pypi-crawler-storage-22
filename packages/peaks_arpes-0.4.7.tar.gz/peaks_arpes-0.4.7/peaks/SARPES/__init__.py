"""Functions used for spin-resolved ARPES data."""

raise NotImplementedError(
    "The SARPES module is not yet ported from `pyphoto`. Please check back later."
)
