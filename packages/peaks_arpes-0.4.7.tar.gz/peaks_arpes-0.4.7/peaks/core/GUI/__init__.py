"""Functions used to generate graphical user interfaces."""
