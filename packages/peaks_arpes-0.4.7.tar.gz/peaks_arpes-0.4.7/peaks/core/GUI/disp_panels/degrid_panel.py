"""Functions for the mesh grid remover display panel."""

# Brendan Edwards 07/11/2023


def degrid():
    raise NotImplementedError("This UI is not yet implemented.")
