"""Functions used for fitting."""
