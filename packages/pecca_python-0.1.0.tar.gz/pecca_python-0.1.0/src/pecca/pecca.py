import requests
import os


class Pecca:
    BASE_URL = "https://pecca-core-engine-dev.politerock-4db9b7c6.southindia.azurecontainerapps.io"
    HEADERS = {"Accept": "application/json"}

    def __init__(self, api_key):
        self.api_key = api_key

    def ask_pecca(self, user_query, use_only_knowledge_base=False, generate_graph=False):
        payload = {
            "api_key": self.api_key,
            "user_query": user_query,
            "use_only_knowledge_base": use_only_knowledge_base,
            "generate_graph": generate_graph,
        }
        resp = requests.post(f"{self.BASE_URL}/query", json=payload, headers=self.HEADERS)
        return resp.json()

    def view_knowledge_base(self):
        params = {"api_key": self.api_key}
        resp = requests.get(f"{self.BASE_URL}/view", params=params, headers=self.HEADERS)
        return resp.json()

    def download_chart(self, inference_id):
        params = {"api_key": self.api_key, "inference_id": inference_id}
        resp = requests.get(f"{self.BASE_URL}/download-chart", params=params)
        return resp.text

    def upload_to_knowledge_base(self, file_path):
        data = {"api_key": self.api_key}
        with open(file_path, "rb") as f:
            files = {"file": (file_path, f, "application/pdf")}
            resp = requests.post(f"{self.BASE_URL}/upload", files=files, data=data, headers=self.HEADERS)
        return resp.json()

    def download_from_knowledge_base(self, file_name, output_path):
        params = {"api_key": self.api_key, "file_name": file_name}
        resp = requests.get(f"{self.BASE_URL}/download", params=params, stream=True)
        resp.raise_for_status()
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
        return {"status": "success", "message": f"File downloaded successfully to {output_path}"}

    def delete_from_knowledge_base(self, file_name):
        params = {"api_key": self.api_key, "file_name": file_name}
        resp = requests.delete(f"{self.BASE_URL}/delete", params=params, headers=self.HEADERS)
        return resp.json()
