from __future__ import annotations

import sys


PYPY = hasattr(sys, "pypy_version_info")
