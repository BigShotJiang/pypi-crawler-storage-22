# (c) Copyright 2025 Perceptic Technologies Ltd. All rights reserved.
#
# AUTO-GENERATED FILE - DO NOT EDIT
# Generated from: agent-input.schema.json

from __future__ import annotations

from typing import Generic, TypeVar

from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_camel

T = TypeVar("T")


class AgentInput(BaseModel, Generic[T]):
    """Input to an agent within a workflow conversation."""

    model_config = ConfigDict(
        alias_generator=to_camel, populate_by_name=True, frozen=True
    )

    run_rid: str
    """Resource identifier for the workflow run."""

    user_id: str
    """Identifier of the user providing input."""

    payload: T | None = None
    """Optional JSON payload containing the input data."""
