# (c) Copyright 2025 Perceptic Technologies Ltd. All rights reserved.
#
# AUTO-GENERATED FILE - DO NOT EDIT
# Generated from: agent-output.schema.json

from __future__ import annotations

from typing import Generic, TypeVar

from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_camel

T = TypeVar("T")


class AgentOutput(BaseModel, Generic[T]):
    """Output from an agent within a workflow conversation."""

    model_config = ConfigDict(
        alias_generator=to_camel, populate_by_name=True, frozen=True
    )

    payload: T
    """JSON payload containing the output data."""
