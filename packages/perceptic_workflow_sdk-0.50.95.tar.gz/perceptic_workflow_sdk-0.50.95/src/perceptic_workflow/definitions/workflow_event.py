# (c) Copyright 2025 Perceptic Technologies Ltd. All rights reserved.
#
# AUTO-GENERATED FILE - DO NOT EDIT
# Generated from: workflow-event.schema.json

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Union

from perceptic_workflow.definitions.workflow_checkpoint_status import WorkflowCheckpointStatus


@dataclass(frozen=True)
class InfoEvent:
    """Generic information event with a type and payload."""

    eventId: int
    """"""
    type: str
    """The type identifier for this info event."""
    payload: dict[str, Any]
    """JSON payload containing event-specific data."""
    timestamp: datetime
    """"""


@dataclass(frozen=True)
class UserInputEvent:
    """Event representing user input submitted to the workflow."""

    eventId: int
    """"""
    input: dict[str, Any]
    """The user input data."""
    timestamp: datetime
    """"""


@dataclass(frozen=True)
class UserInputRequestEvent:
    """Event requesting user input from the client."""

    eventId: int
    """"""
    requestedData: dict[str, Any]
    """Schema describing the requested input."""
    timestamp: datetime
    """"""


@dataclass(frozen=True)
class CheckpointEvent:
    """Event representing a workflow checkpoint status update."""

    eventId: int
    """"""
    checkpointName: str
    """Name of the checkpoint."""
    updateId: str
    """Unique identifier for this update."""
    status: WorkflowCheckpointStatus
    """"""
    payload: dict[str, Any]
    """Additional checkpoint data."""
    timestamp: datetime
    """"""


# Union type representing all WorkflowEvent variants
WorkflowEvent = Union[InfoEvent, UserInputEvent, UserInputRequestEvent, CheckpointEvent]
