# (c) Copyright 2025 Perceptic Technologies Ltd. All rights reserved.
#
# AUTO-GENERATED FILE - DO NOT EDIT

"""Workflow interfaces and mixins."""

from perceptic_workflow.workflows.perceptic_workflow_mixin import PercepticWorkflowMixin

__all__ = ["PercepticWorkflowMixin"]
