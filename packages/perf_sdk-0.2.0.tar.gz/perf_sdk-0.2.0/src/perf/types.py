"""Type definitions for Perf SDK using Pydantic."""

from typing import List, Optional, Union, Literal, Dict, Any
from pydantic import BaseModel, Field


# ============================================
# Content Part Types (Multimodal)
# ============================================

class TextContent(BaseModel):
    type: Literal["text"] = "text"
    text: str


class ImageUrlDetail(BaseModel):
    url: str
    detail: Optional[Literal["low", "high", "auto"]] = None


class ImageUrlContent(BaseModel):
    type: Literal["image_url"] = "image_url"
    image_url: ImageUrlDetail


class AudioData(BaseModel):
    data: str  # Base64 encoded
    format: Literal["wav", "mp3", "webm", "m4a", "ogg", "flac"]


class AudioContent(BaseModel):
    type: Literal["input_audio"] = "input_audio"
    input_audio: AudioData


class VideoUrlDetail(BaseModel):
    url: str


class VideoContent(BaseModel):
    type: Literal["video_url"] = "video_url"
    video_url: VideoUrlDetail


class DocumentData(BaseModel):
    type: Literal["pdf", "docx", "txt"]
    data: str  # Base64 encoded
    name: Optional[str] = None


class DocumentContent(BaseModel):
    type: Literal["document"] = "document"
    document: DocumentData


ContentPart = Union[TextContent, ImageUrlContent, AudioContent, VideoContent, DocumentContent]


class Message(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: Union[str, List[ContentPart]]
    name: Optional[str] = None


# ============================================
# Request Types
# ============================================

class ResponseFormat(BaseModel):
    type: Literal["json_object", "text"]


class ChatRequest(BaseModel):
    messages: List[Message]
    model: Optional[str] = None
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    stream: bool = False
    max_cost_per_call: Optional[float] = None
    metadata: Optional[Dict[str, str]] = None
    # Schema enforcement - use alias for 'schema' since it's reserved in Pydantic
    schema_: Optional[Dict[str, Any]] = Field(default=None, alias="schema")
    schema_id: Optional[str] = None
    schema_strict: Optional[bool] = None
    # Response format
    response_format: Optional[ResponseFormat] = None

    model_config = {"populate_by_name": True}


# ============================================
# Schema Validation Types
# ============================================

class SchemaValidation(BaseModel):
    enabled: bool
    passed: bool
    repaired: Optional[bool] = None
    schema_source: Optional[Literal["inline", "project_default", "schema_id"]] = None


# ============================================
# Semantic Validation Types
# ============================================

class SemanticCorrection(BaseModel):
    field: str
    original: Any
    corrected: Any
    reason: str
    confidence: float


class SemanticWarning(BaseModel):
    field: str
    message: str
    action: str


class SemanticValidation(BaseModel):
    result: Literal["pass", "corrected", "failed"]
    corrections: Optional[List[SemanticCorrection]] = None
    warnings: Optional[List[SemanticWarning]] = None
    latency_ms: float


# ============================================
# Response Types
# ============================================

class Usage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class PerfMetadata(BaseModel):
    request_id: str
    task_type: str
    complexity: float
    model_selected: str
    model_used: str
    cost_usd: float
    latency_ms: int
    fallback_used: bool
    validation_passed: bool
    # Schema enforcement
    schema_validation: Optional[SchemaValidation] = None
    # Semantic validation
    semantic_validation: Optional[SemanticValidation] = None


class ResponseMessage(BaseModel):
    role: Literal["assistant"]
    content: str


class Choice(BaseModel):
    index: int
    message: ResponseMessage
    finish_reason: Optional[Literal["stop", "length", "content_filter"]] = None


class ChatResponse(BaseModel):
    id: str
    object: Literal["chat.completion"] = "chat.completion"
    created: int
    model: str
    choices: List[Choice]
    usage: Usage
    perf: PerfMetadata


# ============================================
# Streaming Types
# ============================================

class DeltaContent(BaseModel):
    role: Optional[Literal["assistant"]] = None
    content: Optional[str] = None


class StreamChoice(BaseModel):
    index: int
    delta: DeltaContent
    finish_reason: Optional[Literal["stop", "length"]] = None


class ChatStreamChunk(BaseModel):
    id: str
    object: Literal["chat.completion.chunk"] = "chat.completion.chunk"
    created: int
    model: str
    choices: List[StreamChoice]
