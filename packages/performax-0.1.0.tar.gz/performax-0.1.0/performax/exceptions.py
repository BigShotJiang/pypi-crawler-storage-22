class ProfilingError(Exception):
    pass
