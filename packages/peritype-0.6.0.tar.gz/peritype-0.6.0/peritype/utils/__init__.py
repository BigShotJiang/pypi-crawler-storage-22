from peritype.utils._cache import use_cache as use_cache
from peritype.utils._typing import (
    is_generic as is_generic,
    WithOriginClass as WithOriginClass,
    WithParameters as WithParameters,
    WithTypeParams as WithTypeParams,
)
