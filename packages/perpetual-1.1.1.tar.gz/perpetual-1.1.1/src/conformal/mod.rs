//! Conformal
//!
//!

pub mod cqr;
