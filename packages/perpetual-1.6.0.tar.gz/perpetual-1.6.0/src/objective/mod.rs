//! Objective Functions
//!
//! This module defines the various loss functions and their gradients/hessians
//! used by the GBM to optimize the model's performance.
//!
//! Custom objectives need only implement [`ObjectiveFunction::loss`] and
//! [`ObjectiveFunction::gradient`]; the remaining trait methods have sensible
//! defaults.

mod adaptive_huber_loss;
mod huber_loss;
mod listnet_loss;
mod log_loss;
mod quantile_loss;
mod squared_loss;

pub use adaptive_huber_loss::AdaptiveHuberLoss;
pub use huber_loss::HuberLoss;
pub use listnet_loss::ListNetLoss;
pub use log_loss::LogLoss;
pub use quantile_loss::QuantileLoss;
pub use squared_loss::SquaredLoss;

pub mod core;
pub use core::Objective;
pub use core::ObjectiveFunction;
