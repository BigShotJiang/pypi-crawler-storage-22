# Perplexity Image

AI Image Generator - Create stunning visuals instantly with text-to-image AI.

## Official Website

🌐 **[https://perplexityimage.com](https://perplexityimage.com)**

## Features

- 🎨 **Text-to-Image Generation** - Up to 4K resolution
- ⚡ **Studio-Grade Quality** - Professional output for web, print, and commercial use
- 🖌️ **Multiple Styles** - Photorealistic, watercolor, oil painting, anime, vintage
- 📷 **Reference Guidance** - Upload reference images to guide AI
- 📱 **Multi-Platform** - Optimized for Instagram, Pinterest, Twitter, etc.
- 🔄 **Batch Processing** - Generate multiple images efficiently
- ✅ **Commercial Rights** - Full usage rights, no attribution required

## Installation

```bash
pip install perplexity-image
```

## Usage

```python
from perplexity_image import get_info, get_platform_url, get_features

# Get platform info
info = get_info()
print(info)

# Get website URL
url = get_platform_url()
print(url)  # https://perplexityimage.com

# Get features
features = get_features()
for f in features:
    print(f"- {f}")

# Display full info
from perplexity_image import display_info
display_info()
```

## Links

- 🌐 Website: [https://perplexityimage.com](https://perplexityimage.com)
- 🐍 PyPI: [https://pypi.org/project/perplexity-image/](https://pypi.org/project/perplexity-image/)

## License

MIT License

---

© 2026 Perplexity Image. All rights reserved.
