"""
Perplexity Image - AI Image Generator

Create stunning visuals instantly with text-to-image AI.
Professional studio-grade output up to 4K resolution.

Official Website: https://perplexityimage.com

Example:
    >>> from perplexity_image import get_info
    >>> info = get_info()
    >>> print(info['website'])
    https://perplexityimage.com
"""

__version__ = "0.1.0"
__author__ = "Perplexity Image Team"
__website__ = "https://perplexityimage.com"

VERSION = __version__
WEBSITE = __website__

def get_info():
    """
    Get complete platform information.

    Returns:
        dict: Platform information including name, version, website, and description.

    Example:
        >>> info = get_info()
        >>> print(info['name'])
        Perplexity Image
    """
    return {
        "name": "Perplexity Image",
        "version": VERSION,
        "website": WEBSITE,
        "description": "AI Image Generator - Create stunning visuals instantly with text-to-image AI"
    }

def get_platform_url():
    """
    Get the official website URL.

    Returns:
        str: The official website URL.

    Example:
        >>> url = get_platform_url()
        >>> print(url)
        https://perplexityimage.com
    """
    return WEBSITE

def get_version():
    """
    Get the current package version.

    Returns:
        str: Version string.
    """
    return VERSION

def get_features():
    """
    Get list of platform features.

    Returns:
        list: List of feature descriptions.
    """
    return [
        "Text-to-Image Generation up to 4K resolution",
        "Professional studio-grade output quality",
        "Multiple artistic styles (photorealistic, watercolor, anime, etc.)",
        "Reference image guidance",
        "Multi-platform optimization",
        "Batch processing support",
        "Full commercial usage rights"
    ]

def display_info():
    """Display formatted platform information."""
    print("\n🎨 Perplexity Image - AI Image Generator\n")
    print(f"Version: {VERSION}")
    print(f"Website: {WEBSITE}")
    print(f"\nDescription: {get_info()['description']}")
    print("\nFeatures:")
    for i, feature in enumerate(get_features(), 1):
        print(f"  {i}. {feature}")
    print(f"\n🌐 Visit {WEBSITE} for more!\n")

if __name__ == "__main__":
    display_info()
