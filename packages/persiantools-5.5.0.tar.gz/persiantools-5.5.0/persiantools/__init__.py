#                           _             __              __
#     ____  ___  __________(_)___ _____  / /_____  ____  / /____
#    / __ \/ _ \/ ___/ ___/ / __ `/ __ \/ __/ __ \/ __ \/ / ___/
#   / /_/ /  __/ /  (__  ) / /_/ / / / / /_/ /_/ / /_/ / (__  )
#  / .___/\___/_/  /____/_/\__,_/_/ /_/\__/\____/\____/_/____/
# /_/

__title__ = "persiantools"
__url__ = "https://github.com/majiidd/persiantools"
__version__ = "5.5.0"
__build__ = __version__
__author__ = "Majid Hajiloo"
__author_email__ = "majid.hajiloo@gmail.com"
__license__ = "MIT"
__copyright__ = "Copyright (c) 2016-2025 Majid Hajiloo"
