from persidict.safe_str_tuple import SafeStrTuple

def test():
    s = SafeStrTuple("key1")
    k = "key1"
    
    try:
        print(f"s < k: {s < k}")
    except TypeError as e:
        print(f"s < k failed: {e}")

    try:
        print(f"k < s: {k < s}")
    except TypeError as e:
        print(f"k < s failed: {e}")

if __name__ == "__main__":
    test()
