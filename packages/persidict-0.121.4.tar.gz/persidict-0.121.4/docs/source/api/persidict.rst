persidict package
=================

.. automodule:: persidict
   :members:
   :undoc-members:
   :show-inheritance:
   :imported-members:
