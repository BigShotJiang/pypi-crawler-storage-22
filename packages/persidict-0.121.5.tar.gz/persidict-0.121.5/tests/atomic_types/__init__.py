# Tests for atomic types serialization in PersiDict
