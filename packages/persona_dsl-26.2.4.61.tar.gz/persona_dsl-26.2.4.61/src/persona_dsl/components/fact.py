from .step import Step


class Fact(Step):
    """
    Алиас для Step, предназначенный для story-стиля.
    Не содержит собственной логики.
    """

    pass
