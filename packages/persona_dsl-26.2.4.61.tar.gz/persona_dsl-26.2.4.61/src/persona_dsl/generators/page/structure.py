from typing import Any, Dict, List, Optional
import re
from .utils import INTERESTING_ROLES, derive_base_name, get_unique_name


class StructureParser:
    """
    Handles parsing of ARIA snapshots into a flat list of elements and
    structural analysis (sections identification).
    """

    def __init__(self, test_id_prefix: Optional[str] = None):
        self._test_id_prefix = test_id_prefix

    def parse_aria_node_recursive(
        self,
        nodes: List[Dict[str, Any]] | Dict[str, Any],
        used_names: set[str],
        context: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """
        Строит внутреннее дерево элементов из JSON-структуры (от Runtime).
        """
        if isinstance(nodes, dict):
            nodes = [nodes]

        result = []
        for node in nodes:
            if isinstance(node, str):
                # Handle text node as generic text element or just text property?
                # For now, wrap in generic with name? Or ignore?
                # Previous logic: Text maps to child node string.
                # Codegen handles 'children' as strings? No, codegen expects elements with dicts.
                result.append(
                    {
                        "role": "text",
                        "name": node,
                        "var_name": "text",
                        "init_kwargs": {"text": node},
                        "children": [],
                        "test_id": None,
                        "node_ref": {
                            "text": node
                        },  # Needed for derive_base_name if accessing node_ref
                    }
                )
                continue

            role = node.get("role", "")
            name = node.get("name", "")
            test_id = node.get("test_id")
            if not test_id and "props" in node and isinstance(node["props"], dict):
                test_id = node["props"].get("testId")

            placeholder = node.get("placeholder")
            if not placeholder and "props" in node and isinstance(node["props"], dict):
                placeholder = node["props"].get("placeholder")

            value = node.get("value")
            if not value and "props" in node and isinstance(node["props"], dict):
                value = node["props"].get("value")

            text = node.get("text")
            if not text and "props" in node and isinstance(node["props"], dict):
                text = node["props"].get("text")

            # --- 1. PRE-FILTERING ---

            # Пропускаем "служебные" узлы, если это Generic без имени/test_id
            if role in ("generic", "", "none") and not name and not test_id:
                # Но если у ноды есть дети, мы должны их обработать и поднять наверх
                if "children" in node and node["children"]:
                    children = self.parse_aria_node_recursive(
                        node["children"], used_names, context
                    )
                    result.extend(children)
                continue

            # Игнорируем role="img" без имени (декоративные)
            if role == "img" and not name:
                continue

            # --- 2. ATTRIBUTE EXTRACTION ---

            # Smart Logic for test_id prefix stripping
            # (Assuming context might have common prefix if calculated appropriately)
            # For now passing raw test_id. Prefix logic can be applied later or here.
            # Using self._test_id_prefix if available to clean it.
            cleaned_test_id = test_id
            if (
                test_id
                and self._test_id_prefix
                and test_id.startswith(f"{self._test_id_prefix}-")
            ):
                cleaned_test_id = test_id[len(self._test_id_prefix) + 1 :]
            elif (
                test_id
                and self._test_id_prefix
                and test_id.startswith(f"{self._test_id_prefix}_")
            ):
                cleaned_test_id = test_id[len(self._test_id_prefix) + 1 :]

            # --- 3. NAME GENERATION ---
            base_name = derive_base_name(
                role, name, cleaned_test_id, text, placeholder  # text_prop
            )

            # Генерируем уникальное имя
            unique_name = get_unique_name(base_name, used_names)
            used_names.add(unique_name)

            # --- 4. ATTRIBUTE PREPARATION ---
            # Формируем словарь для атрибутов __init__
            # role/name/test_id всегда идут как базовые
            init_kwargs = {"name": unique_name}

            if placeholder:
                init_kwargs["placeholder"] = placeholder
            if value:
                init_kwargs["value"] = value

            # Если есть accessible name
            # Check if name is dynamic (equals value) or looks like transient data (date/time)
            is_dynamic_name = False
            if value and name == value:
                is_dynamic_name = True

            # Simple heuristic for dates (common sources of flakiness)
            # Matches DD.MM.YYYY, YYYY-MM-DD.
            # We ALLOW Time (HH:MM) as it is often static structure (calendar slots).
            if re.search(r"\d{2}\.\d{2}\.\d{4}", name) or re.search(
                r"\d{4}-\d{2}-\d{2}", name
            ):
                is_dynamic_name = True

            # Use name if valid, else try text prop
            acc_name = name
            if not acc_name and text and not value:
                # If name is missing but we have text (and it's not a value input), use text
                acc_name = text

            if acc_name and not is_dynamic_name:
                init_kwargs["accessible_name"] = acc_name

            if (
                role and role != "group"
            ):  # role is usually implicit by class, but allowed explicitly
                # However, Persona classes handle role internally usually.
                # Only if generic Element is used do we need role.
                # Note: PageGenerator codegen logic will decide class.
                pass

            if cleaned_test_id:
                init_kwargs["test_id"] = cleaned_test_id

            # --- 5. RECURSION ---
            children_list = []
            if "children" in node:
                children_list = self.parse_aria_node_recursive(
                    node["children"], used_names, context
                )

            # --- 6. ELEMENT CONSTRUCTION ---
            element_def = {
                "var_name": unique_name,
                "role": role,
                "name": name,  # raw accessible name
                "text": text,  # text content (if any)
                "test_id": cleaned_test_id,  # for logic
                "original_test_id": test_id,  # for prefix calc
                "children": children_list,
                "init_kwargs": init_kwargs,
                "node_ref": node,  # link to original node
                "is_section": False,  # Flag for wrapping
                "is_complex_section": False,  # Flag for extracting
            }

            # Extract aria_ref if present (support both ref and aria_ref keys)
            aria_ref = node.get("ref") or node.get("aria_ref")
            if aria_ref:
                init_kwargs["aria_ref"] = aria_ref

            result.append(element_def)

        return result

    def collect_consumed_refs(self, elements: List[Dict[str, Any]]) -> set[str]:
        """Собирает все ID (aria_ref) элементов, которые используются как лейблы другими элементами."""
        refs = set()
        for el in elements:
            # Check if this element consumes refs?
            # (Logic depends on if 'labelled_by' is in element dict, usually extracted from Node)
            # Assuming node_ref has it
            node = el.get("node_ref", {})

            # Check standard keys
            if "labelledby" in node:
                refs.add(node["labelledby"])
            if "describedby" in node:
                refs.add(node["describedby"])

            # Check snapshot property keys (common in RichAriaSnapshot yaml/json)
            # Value might be list or string representation of list: "['ref1', 'ref2']"
            # Also check inside 'props' dictionary where properties often reside

            targets = [node]
            if "props" in node:
                targets.append(node["props"])

            for target in targets:
                for key in [
                    "/labelledByRefs",
                    "labelledByRefs",
                    "/describedByRefs",
                    "describedByRefs",
                ]:
                    val = target.get(key)
                    if val:
                        if isinstance(val, list):
                            refs.update(val)
                        elif isinstance(val, str):
                            # Try to parse string list "['a', 'b']"
                            import ast

                            try:
                                parsed = ast.literal_eval(val)
                                if isinstance(parsed, list):
                                    refs.update(parsed)
                                else:
                                    refs.add(val)
                            except Exception:
                                refs.add(val)

            if el["children"]:
                refs = refs.union(self.collect_consumed_refs(el["children"]))
        return refs

    def flatten_tree_recursive(
        self, elements: List[Dict[str, Any]], consumed_refs: set[str] | None = None
    ) -> List[Dict[str, Any]]:
        """
        Рекурсивно проходит дерево и делает служебные generic-обёртки прозрачными.
        Также удаляет элементы, помеченные как "consumed" (лейблы) или как вспомогательные.
        """
        consumed_refs = consumed_refs or set()
        flat_list = []

        for el in elements:
            role = el["role"]
            name = el["name"]

            # 1. Скрываем consumed элементы (если они используются как лейблы)
            # Note: Need 'ref' from node (RichAriaSnapshot uses 'ref')
            node = el.get("node_ref", {})
            node_id = node.get("ref") or node.get("aria_ref") or node.get("id")

            if node_id and node_id in consumed_refs:
                # Skip adding this element to list, but process children?
                # Usually labels are leaf nodes. If not, we might lose children.
                # Heuristic: skip only if leaf or text-only logic
                if not el["children"]:
                    continue

            # 2. Generic-обёртки: если роль generic/none и нет полезных атрибутов -> поднимаем детей
            # We ignore 'name' for these roles because they are usually layout/content wrappers,
            # not semantic regions (use role='region' or 'group' for those).
            # FIX: Restoring named generics (user requirement). ONLY filter if name is empty.
            # But filter 'text'/'paragraph' even if named (usually just labels).
            if role in ("paragraph", "presentation"):
                is_uninteresting_generic = not el.get("test_id")
            else:
                is_uninteresting_generic = (
                    (role in ("generic", "", "none"))
                    and not name
                    and not el.get("test_id")
                )

            if is_uninteresting_generic:
                if el["children"]:
                    # Recurse on children and add them to THIS level
                    flattened_children = self.flatten_tree_recursive(
                        el["children"], consumed_refs
                    )
                    flat_list.extend(flattened_children)
            else:
                # Оставляем элемент, но его children тоже нужно "сплющить" внутри него
                if el["children"]:
                    el["children"] = self.flatten_tree_recursive(
                        el["children"], consumed_refs
                    )
                flat_list.append(el)

        return flat_list

    def recalculate_names(self, elements: List[Dict[str, Any]]) -> None:
        """
        Полностью пересчитывает имена (var_name) для списка элементов.
        Это нужно вызывать после фильтрации/схлопывания, чтобы освободившиеся
        красивые имена (например 'login' вместо 'login_1') достались оставшимся элементам.
        """
        # Scoped within each level
        # We need to traverse tree level by level and recalculate uniqueness per level

        def process_level(
            level_elements: List[Dict[str, Any]], inherited_used_names: set[str]
        ) -> None:
            # Collect base names again
            current_level_names: set[str] = set()

            # Prioritize interactive elements for better naming (e.g. login input > login text)

            # level_elements.sort(key=sort_key) # DISABLED: Preserving DOM order to prevent layout shifts

            for el in level_elements:
                # Re-derive base name based on current data
                # (Logic implies re-running base_name derivation or storing it)
                # Re-running is safer.
                base_name = derive_base_name(
                    el["role"],
                    el["name"],
                    el["test_id"],
                    (
                        el["node_ref"].get("text")
                        or (el["node_ref"].get("props") or {}).get("text")
                    ),
                    (
                        el["node_ref"].get("placeholder")
                        or (el["node_ref"].get("props") or {}).get("placeholder")
                    ),
                )

                # Unique in current context
                unique = get_unique_name(base_name, current_level_names)
                current_level_names.add(unique)

                el["var_name"] = unique
                el["init_kwargs"]["name"] = unique

                if el["children"]:
                    process_level(el["children"], set())  # New scope for children

        process_level(elements, set())

    def promote_semantic_wrappers(
        self, elements: List[Dict[str, Any]], used_names: set[str]
    ) -> None:
        """
        Находит семантические группы (group, region, form, etc.) без имени.
        Пытается найти внутри них заголовок (Heading) и использовать его текст как имя группы.
        Если находит -> переименовывает группу и делает её 'named region'.
        """
        for el in elements:
            role = el["role"]
            name = el["name"]

            # Recurse first
            if el["children"]:
                self.promote_semantic_wrappers(el["children"], used_names)

            # Logic: If un-named semantic container
            if role in ("group", "region", "form", "section", "article") and not name:
                heading_el = self._find_first_heading(el)
                if heading_el and heading_el.get("name"):
                    # Found a heading! Promote this wrapper.
                    new_name_text = heading_el["name"]

                    # Generate new var_name
                    base_name = derive_base_name(role, new_name_text, None, None, None)
                    unique = get_unique_name(base_name, used_names)
                    used_names.add(unique)

                    el["var_name"] = unique
                    el["name"] = new_name_text
                    el["init_kwargs"]["name"] = unique
                    el["init_kwargs"]["accessible_name"] = new_name_text

                    # Also, ideally, we might construct a 'locator' based on this heading
                    # This is advanced, sticking to Name promotion for now.

    def _find_first_heading(
        self, element: Dict[str, Any], depth: int = 0, max_depth: int = 2
    ) -> Optional[Dict[str, Any]]:
        """
        Рекурсивный поиск первого заголовка для именования секции.
        Останавливается, если встречает уже именованную семантическую группу.
        """
        if depth > max_depth:
            return None

        role = element.get("role")
        if role == "heading":
            return element

        if "children" in element:
            for child in element["children"]:
                # Stop if child is a significant landmark itself
                if (
                    child.get("role")
                    in (
                        "region",
                        "form",
                        "banner",
                        "main",
                    )
                    and child.get("name")
                    or child.get("is_semantic_group")
                ):
                    continue

                found = self._find_first_heading(child, depth + 1, max_depth)
                if found:
                    return found
        return None

    def identify_complex_sections(self, elements: List[Dict[str, Any]]) -> None:
        """
        Identifies elements that should be extracted into nested classes.
        Criteria:
        1. Specific Role (banner, contentinfo, form, etc.)
        2. Complexity (e.g. > 1 meaningful children)
        """
        for el in elements:
            role = el.get("role")
            children = el.get("children", [])

            # Recurse first
            if children:
                self.identify_complex_sections(children)

            # Check criteria
            is_interesting = role in INTERESTING_ROLES

            # Count meaningful children (not pure layout wrappers if we have any left)
            # Essentially, if it has children that will generate code.
            # has_children = len(children) > 0  # Simple check

            # Additional heuristic: Don't extract simple wrappers with 1 child
            # unless it's a critical role like 'main' or 'banner'
            is_complex = len(children) >= 1

            if is_interesting and is_complex:
                el["is_complex_section"] = True
                # If it's complex, we will generate a class for it.
                # The class name will be derived from var_name in codegen.

    def identify_table_prototypes(self, elements: List[Dict[str, Any]]) -> None:
        """
        Analyzes Tables to detect repetitive Row patterns.
        Delegates to external analyzer.
        """
        from .table_analysis import identify_table_prototypes

        identify_table_prototypes(elements)
