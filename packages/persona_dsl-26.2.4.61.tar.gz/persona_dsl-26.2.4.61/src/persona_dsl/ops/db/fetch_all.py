from typing import Any, Optional, List

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_database import UseDatabase


class FetchAll(Ops):
    """
    Низкоуровневая операция: выполняет SQL-запрос и возвращает все строки.
    """

    def __init__(self, query: str, params: Optional[Any] = None):
        self.query = query
        self.params = params

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} получает все записи по SQL-запросу: {self.query[:100]}"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> List[Any]:
        db: UseDatabase = persona.skill(SkillId.DB)
        conn = db.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(self.query, self.params or ())
            result = cursor.fetchall()
            return result
        finally:
            cursor.close()
