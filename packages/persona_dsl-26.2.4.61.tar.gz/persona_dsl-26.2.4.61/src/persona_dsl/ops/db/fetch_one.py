from typing import Any, Optional

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_database import UseDatabase


class FetchOne(Ops):
    """
    Низкоуровневая операция: выполняет SQL-запрос и возвращает первую строку.
    """

    def __init__(self, query: str, params: Optional[Any] = None):
        self.query = query
        self.params = params

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} получает одну запись по SQL-запросу: {self.query[:100]}"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> Any:
        db: UseDatabase = persona.skill(SkillId.DB)
        return db.execute(self.query, self.params)
