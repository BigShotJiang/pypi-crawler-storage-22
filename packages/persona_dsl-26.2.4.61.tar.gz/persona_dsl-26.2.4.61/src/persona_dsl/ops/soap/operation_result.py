from typing import Any

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_soap import UseSOAP


class OperationResult(Ops):
    """
    Низкоуровневая операция: вызывает SOAP-операцию и возвращает результат.
    """

    def __init__(self, service: str, operation: str, *args: Any, **kwargs: Any):
        self.service = service
        self.operation = operation
        self.args = args
        self.kwargs = kwargs

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} получает результат SOAP операции '{self.operation}' сервиса '{self.service}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> Any:
        soap: UseSOAP = persona.skill(SkillId.SOAP)
        return soap.call(self.service, self.operation, *self.args, **self.kwargs)
