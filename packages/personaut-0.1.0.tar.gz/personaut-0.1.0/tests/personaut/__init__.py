"""Tests for Personaut package."""
