"""Tests for prompt components."""
