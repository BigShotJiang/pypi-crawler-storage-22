# perspective-cli

## Installation

### `pip`

```bash
pip install perspective-cli
```

### `uv`

```bash
uv add perspective-cli
```

## Next Steps

Proceed to the [official documentation](dev.meetperspective.com/docs/catalog/) for next steps and detailed guides on how to utilize `perspective-cli` effectively.
