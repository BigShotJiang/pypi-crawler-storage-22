"""Perspective CLI."""
