"""Exceptions for CLI commands."""


class DbtArtifactValidationError(Exception):
    """Exception raised for errors in the dbt artifact validation process."""

    def __init__(self, version: str | None = None):  # noqa: D107
        message = f"Unsupported dbt version: {version}."
        super().__init__(message)


class ExtractionError(Exception):
    """Raised when an error occurs during data extraction."""

    pass
