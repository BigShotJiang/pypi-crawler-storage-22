"""Power BI ingestion dlt pipeline."""

from collections.abc import Generator

from perspective.ingest.sources.bi.powerbi.extract import powerbi
from perspective.ingest.sources.bi.powerbi.models import DataflowDetails, WorkspaceInfo
from perspective.ingest.sources.bi.powerbi.transform import transform
from perspective.models.dashboards import DashboardManifest


def pipeline() -> Generator[DashboardManifest, None, None]:
    """Power BI ingestion pipeline."""
    source = powerbi()
    lineage = source.workspaces_lineage
    dataflows = source.dataflows_details
    dashboard_metadata = WorkspaceInfo(**next(iter(lineage)))
    dataflows_metadata = [DataflowDetails(**item) for item in dataflows]
    yield transform(dashboard_metadata, dataflows_metadata)


if __name__ == "__main__":
    from pathlib import Path

    manifest = next(iter(pipeline()))

    Path("powerbi_extracted.json").write_text(
        manifest.model_dump_json(by_alias=True), encoding="utf-8"
    )
    # print(manifest)
