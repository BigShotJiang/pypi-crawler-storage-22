"""Pydantic models for Qlik Sense APIs responses."""

from pydantic import BaseModel, EmailStr


class AppDetailsQRS(BaseModel):
    id: str
    name: str
    description: str | None
    owner: EmailStr | None
    created_at: str
    updated_at: str


class Table(BaseModel):
    qDiscriminator: str
    qStatement: str | None = None


class AppDetailsEngine(BaseModel):
    app_id: str
    lineage: list[Table]
