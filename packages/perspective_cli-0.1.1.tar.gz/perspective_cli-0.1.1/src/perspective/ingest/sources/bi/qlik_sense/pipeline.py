"""dlt pipeline to load Qlik Sense metadata into DuckDB."""

import dlt

from perspective.ingest.sources.bi.qlik_sense.extract import qlik_sense


pipe = dlt.pipeline(
    pipeline_name="qlik_to_duckdb",
    destination=dlt.destinations.duckdb("db.duckdb"),
    dataset_name="qlik_sense",
)

if __name__ == "__main__":
    from loguru import logger

    # load_package = pipe.run(qlik().add_limit(5), refresh="drop_data") # For testing.
    load_package = pipe.run(qlik_sense().add_limit(5))
    logger.info(load_package)
