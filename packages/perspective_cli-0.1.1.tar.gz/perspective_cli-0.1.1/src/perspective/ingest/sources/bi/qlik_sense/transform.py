"""Transform Qlik Sense metadata into Perspective DashboardManifest format."""

import json
from pathlib import Path

from perspective.ingest.sources.bi.qlik_sense.models import (
    AppDetailsEngine,
    AppDetailsQRS,
)
from perspective.models.dashboards import (
    Dashboard,
    DashboardManifest,
    DashboardSchemaMetadata,
    DataModel,
)


def transform(
    app_details_qrs: AppDetailsQRS, app_details_engine: AppDetailsEngine
) -> DashboardManifest:
    # Extract tables from the Qlik Sense metadata.
    # tables = extract_tables(workspace_info)
    # reports = extract_reports(workspace_info, tables=tables)

    # return DashboardManifest(
    #     metadata=DashboardSchemaMetadata(schema="dashboard", version=1),
    #     payload=reports,
    # )
    """Join app metadata from the two sources: QRS API and Engine JSON API.

    Args:
        app_details_qrs (list[AppDetailsQRS]): List of app details from QRS API.
        app_details_engine (list[AppDetailsEngine]): List of app details from Engine
            JSON API.
    """
    apps = []
    for app in app_details_qrs:
        app_parsed = {
            "external_id": app["id"],
            "url": f"{app['resourceId']}/hub/{app['id']}",
            "type": "qliksense",
            "name": app["name"],
            "workspace": app.get("stream", {}).get("name", "My Work"),
            "created_at": app.get("createdDate"),
            "modified_at": app.get("modifiedDate"),
            "owners": [
                {
                    "user_id": app.get("owner", {}).get("userId", ""),
                    "username": app.get("owner", {}).get("userDirectory", ""),
                    "name": app.get("owner", {}).get("name", ""),
                }
            ],
            "parent_models": [],
        }

        apps.append(app_parsed)

    return DashboardManifest(
        metadata=DashboardSchemaMetadata(schema="dashboard", version=1),
        payload=apps,
    )


if __name__ == "__main__":
    from loguru import logger

    with Path("app_details_qrs.json").open(encoding="utf-8") as f:
        app_details_qrs = json.load(f)

    with Path("app_details_engine.json").open(encoding="utf-8") as f:
        app_details_engine = json.load(f)

    dashboard_manifest = transform(
        app_details_qrs=app_details_qrs, app_details_engine=app_details_engine
    )
    logger.info(dashboard_manifest)
