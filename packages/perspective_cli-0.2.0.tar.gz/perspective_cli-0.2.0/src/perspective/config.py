"""Manage Perspective instance configuration."""

from contextlib import suppress
from pathlib import Path
from urllib.parse import urljoin

from requests.models import Response
from rich.panel import Panel
import typer
import yaml

from perspective.models.configs import Config
from perspective.utils import console, send_request
from perspective.utils.options import (
    ConfigDir,
    DryRun,
    Force,
    PerspectiveApiToken,
    PerspectiveURL,
)


app = typer.Typer(
    name="config", no_args_is_help=True, pretty_exceptions_show_locals=False
)

CONFIG_YAML_EXAMPLE = """# Example:
#
# groups:
#   - meta_key: "domain"
#     slug: "domains"
#     label_plural: "Domains"
#     label_singular: "Domain"
#     icon: "Cube"
#     in_sidebar: true
#     visible: true
#   - meta_key: "true_source"
#     slug: "sources"
#     label_plural: "Sources"
#     label_singular: "Source"
#     icon: "Cloud"
#     in_sidebar: true
"""

OWNERS_YAML_EXAMPLE = """# Example:
#
# owners:
#   - email: "some@one.com"
#     first_name: "Dave"
#     last_name: "Smith"
#     title: "Director"
#   - email: "other@person.com"
#     first_name: "Michelle"
#     last_name: "Dunne"
#     title: "CTO"
#   - email: "someone@else.com"
#     first_name: "Dana"
#     last_name: "Pawlak"
#     title: "HR Manager"
"""


def init_config(config_dir: Path | str = "./.perspective", force: bool = False) -> None:
    """Initialize configuration files in the specified directory.

    Args:
        config_dir (Path | str, optional): The directory where configuration files
            will be created. Defaults to "./.perspective".
        force (bool, optional): If True, existing configuration files will be
            overwritten. Defaults to False.

    Raises:
        FileExistsError: If configuration files already exist and `force` is not set to
            True.
    """
    config_dir = Path(config_dir)

    config_path = config_dir / "config.yaml"
    owners_path = config_dir / "owners.yaml"

    if force:
        config_path.unlink(missing_ok=True)
        owners_path.unlink(missing_ok=True)
        with suppress(FileNotFoundError):
            config_dir.rmdir()

    if not config_path.exists() and not owners_path.exists():
        config_dir.mkdir(exist_ok=True)
        config_path.touch(exist_ok=False)
        owners_path.touch(exist_ok=False)
    else:
        raise FileExistsError

    config_path.write_text(CONFIG_YAML_EXAMPLE)
    owners_path.write_text(OWNERS_YAML_EXAMPLE)


def get_config(config_dir: Path | str = "./.perspective") -> Config | None:
    """Retrieve configuration data from YAML files in the specified directory.

    Args:
        config_dir (Path | str, optional): The directory containing the
            configuration files. Defaults to "./.perspective".

    Returns:
        optional[Config]: The configuration object if the configuration is successfully
            loaded, otherwise None.

    Raises:
        FileNotFoundError: If the configuration files are missing.
        typer.Abort: If there is an error parsing the YAML files.
    """
    config_dir = Path(config_dir)

    config_path = config_dir / "config.yaml"
    owners_path = config_dir / "owners.yaml"

    config_missing = True
    owners_missing = True

    config_dict = {}
    config_data = {}
    owners_data = {}

    if config_path.exists():
        config_missing = False
        with config_path.open("r") as f:
            try:
                config_data: dict | None = yaml.safe_load(f)
            except yaml.YAMLError as e:
                console.print(f"Error parsing YAML file: {e}")
                raise typer.Abort() from e

    if owners_path.exists():
        owners_missing = False
        with owners_path.open("r") as f:
            try:
                owners_data: dict | None = yaml.safe_load(f)

            except yaml.YAMLError as e:
                console.print(f"Error parsing YAML file: {e}")
                raise typer.Abort() from e

    if config_missing and owners_missing:
        raise FileNotFoundError

    if config_data is not None:
        config_dict.update(config_data)

    if owners_data is not None:
        config_dict.update(owners_data)

    return Config(**config_dict)


def send_config(
    config: Config,
    perspective_url: str,
    api_token: str | None = None,
    verify: bool = True,
) -> Response:
    """Send configuration data to a specified URL.

    Args:
        config (Config): The configuration data to be sent.
        perspective_url (str): The URL where the configuration data will be sent.
        api_token (str | None, optional): The API token for authentication. Defaults to
            None.
        verify (bool): Whether to verify the server's TLS certificate. Defaults to True.

    Returns:
        Response: The response from the server after sending the configuration data.

    Raises:
        typer.Exit: If there is an error in sending the configuration data.
    """
    console.print(Panel("[yellow]Sending config info to Perspective...[/yellow]"))

    return send_request(  # type: ignore
        url=urljoin(perspective_url, "config"),
        payload=config.model_dump(by_alias=True),
        headers={"Authorization": f"Bearer {api_token}"} if api_token else None,
        verify=verify,
    )


@app.command(help="Initialize the configuration.")
def init(config_dir: Path = ConfigDir, force: bool = Force) -> None:
    """Initialize the configuration.

    Args:
        config_dir (Path): The directory to write the configuration files.
        force (bool): If True, overwrite the configuration if it already exists.

    Raises FileExistsError if the configuration already exists and 'force' is not True.
    """
    try:
        init_config(config_dir=config_dir, force=force)
        console.print(f"[green]Config initialized at[/green] {config_dir}")
    except FileExistsError as e:
        console.print(
            f"[red]Error![/red] [red]Config files already exist at[/red] {config_dir}\n"
            f"[yellow]If you want to override run with flag [/yellow][red]--force/-f[/red]"
        )
        raise typer.Exit(1) from e


@app.command(help="Display the current configuration information.")
def show(config_dir: Path = ConfigDir) -> None:
    """Display current configuration from the specified directory."""
    try:
        config = get_config(config_dir=config_dir)
        console.print(config)
    except FileNotFoundError as e:
        console.print(
            f"[red]Error![/red] [red]Config files not found at[/red] {config_dir}\n"
            "[yellow]To generate config files use [/yellow][white]'luma config init'[/white]"
        )
        raise typer.Exit(1) from e


@app.command(help="Send the current configuration information to luma")
def send(
    config_dir: Path = ConfigDir,
    perspective_url: str = PerspectiveURL,
    api_token: str = PerspectiveApiToken,
    dry_run: bool = DryRun,
) -> None:
    """Send configuration to the specified Perspective URL.

    In dry run mode, the configuration is printed but not sent.
    """
    try:
        config = get_config(config_dir=config_dir)

        if dry_run:
            console.print(config.model_dump(by_alias=True))
            return

        if config:
            response = send_config(
                config=config, perspective_url=perspective_url, api_token=api_token
            )
            if not response.ok:
                raise typer.Exit(1)
        else:
            console.print(
                f"[red]No Config detected under {config_dir}[/red]\n"
                f"[yellow]To generate config files use [/yellow][white]'perspective config init'[/white]"
            )

    except FileNotFoundError as e:
        console.print(
            f"[red]Error![/red] [red]Config files not found at[/red] {config_dir}\n"
            f"[yellow]To generate config files use [/yellow][white]'perspective config init'[/white]"
        )
        raise typer.Exit(1) from e
