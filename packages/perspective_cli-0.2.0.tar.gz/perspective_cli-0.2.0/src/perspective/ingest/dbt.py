"""Ingest dbt metadata into Luma."""

from collections.abc import Callable
import json
from pathlib import Path
import time
from typing import Any
from urllib.parse import urljoin

from dbt_artifacts_parser.parser import (
    parse_catalog,
    parse_manifest,
    parse_run_results,
)
from pydantic import ValidationError
from rich.panel import Panel
from typer import Context, Exit, Typer

from perspective.exceptions import DbtArtifactValidationError
from perspective.utils import (
    IngestionStatus,
    check_ingestion_results,
    check_ingestion_status,
    console,
    send_request,
)
from perspective.utils.options import (
    DryRun,
    Follow,
    IsDbtTestResultsIngestion,
    MetadataDir,
    PerspectiveApiToken,
    PerspectiveURL,
)


app = Typer(no_args_is_help=True, pretty_exceptions_show_locals=False)


def _validate_artifacts(artifacts: dict[str, Callable]) -> dict[str, Any]:
    """Validate and parse dbt artifacts."""
    file_names = [Path(path).name for path in artifacts]
    console.print(
        Panel(
            f"📦 Validating dbt artifacts: [cyan]{file_names}[/cyan] for ingestion..."
        )
    )
    parsed_artifacts = {}
    for artifact_path, parsing_func in artifacts.items():
        try:
            with Path(artifact_path).open("r", encoding="utf-8") as f:
                artifact = json.load(f)
        except FileNotFoundError as e:
            msg = f"Artifact file not found: {artifact_path}"
            console.print("[red]✘ " + msg + "[/red]")
            raise DbtArtifactValidationError(msg) from e
        try:
            parsed_artifact = parsing_func(artifact)
        except ValidationError as e:
            msg = f"Artifact validation failed for {artifact_path}: {e!r}"
            console.print("[red]✘ " + msg + "[/red]")
            raise DbtArtifactValidationError(msg) from e
        parsed_artifacts[artifact_path] = parsed_artifact.model_dump(
            by_alias=True, mode="json"
        )
        console.print(f"[green]✔ {artifact_path} validated and loaded.[/green]")

    return parsed_artifacts


@app.callback(invoke_without_command=True)
def ingest(
    ctx: Context,  # noqa: ARG001
    metadata_dir: Path = MetadataDir,
    perspective_url: str = PerspectiveURL,
    api_token: str = PerspectiveApiToken,
    dry_run: bool = DryRun,
    follow: bool = Follow,
    is_test_results_ingestion: bool = IsDbtTestResultsIngestion,
) -> None:
    """Validate and ingest dbt artifacts from the specified directory.

    By default, ingests `manifest.json` and `catalog.json`. If `--test-results` flag is
    set, only ingests `run_results.json` instead.
    """
    # Validate and load artifacts
    if is_test_results_ingestion:
        artifacts = {str(metadata_dir / "run_results.json"): parse_run_results}
        parsed_artifacts = _validate_artifacts(artifacts)
        payload = parsed_artifacts[str(metadata_dir / "run_results.json")]
        url = urljoin(perspective_url, "catalog/ingest/dbt/run_results")
    else:
        artifacts = {
            str(metadata_dir / "manifest.json"): parse_manifest,
            str(metadata_dir / "catalog.json"): parse_catalog,
        }
        parsed_artifacts = _validate_artifacts(artifacts)
        payload = {
            "manifest_json": parsed_artifacts[str(metadata_dir / "manifest.json")],
            "catalog_json": parsed_artifacts[str(metadata_dir / "catalog.json")],
        }
        url = urljoin(perspective_url, "catalog/ingest/dbt")

    # If in dry run mode, print the bundle and exit.
    if dry_run:
        console.print("Dry run mode: Payload with the following keys would be sent:")
        console.print(list(payload.keys()))
        raise Exit(0)

    # Send ingestion request.
    response, ingestion_uuid = send_request(
        url=url,
        method="POST",
        payload=payload,
        headers={"Authorization": f"Bearer {api_token}"} if api_token else None,
        verify=False,
        return_response_key="ingestion_uuid",
    )

    # Wait until ingestion is complete.
    if follow and ingestion_uuid:
        ingestion_status = None

        with console.status("Waiting...", spinner="dots"):
            for _ in range(30):
                ingestion_status = check_ingestion_status(
                    perspective_url, ingestion_uuid, api_token=api_token, verify=False
                )
                if ingestion_status == IngestionStatus.successful.value:
                    response = check_ingestion_results(
                        perspective_url,
                        ingestion_uuid,
                        api_token=api_token,
                        verify=False,
                    )
                    console.print()
                    console.print(f"Ingestion results for ID {ingestion_uuid}:")
                    console.print()
                    console.print(response)
                    return

                if ingestion_status == IngestionStatus.failed.value:
                    console.print()
                    console.print(f"Ingestion failed for ID {ingestion_uuid}")
                    return

                if ingestion_status == IngestionStatus.pending.value:
                    time.sleep(1)

        if ingestion_status != IngestionStatus.successful.value:
            console.print(
                f"Ingestion did not complete successfully within the wait period. Status: {ingestion_status}"
            )


# Run the application.
if __name__ == "__main__":
    app()
