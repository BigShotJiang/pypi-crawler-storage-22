"""Ingest model metadata from various data sources."""

from importlib import import_module
import json
from time import sleep
from urllib.parse import urljoin

from loguru import logger
from typer import Exit, Typer

from perspective.ingest import dbt, postgres
from perspective.utils import (
    IngestionStatus,
    check_ingestion_results,
    check_ingestion_status,
    console,
    send_request,
)
from perspective.utils.options import (
    DryRun,
    Follow,
    FollowTimeout,
    IngestionId,
    PerspectiveApiToken,
    PerspectiveURL,
)


app = Typer(name="ingest", no_args_is_help=True, pretty_exceptions_show_locals=False)


@app.command()
def status(
    ingestion_id: IngestionId,
    perspective_url: str = PerspectiveURL,
    api_token: str = PerspectiveApiToken,
) -> str | dict:
    """Retrieve the status of an ingestion."""
    return check_ingestion_status(perspective_url, ingestion_id, api_token=api_token)


# Add sub-apps for custom source implementations
app.add_typer(dbt.app, name="dbt", help="Ingest metadata from dbt.")
app.add_typer(postgres.app, name="postgres", help="Ingest metadata from Postgres.")


@app.command()
def powerbi(
    perspective_url: str = PerspectiveURL,
    api_token: str = PerspectiveApiToken,
    dry_run: bool = DryRun,
    follow: bool = Follow,
    follow_timeout: int = FollowTimeout,
) -> None:
    """Ingest metadata from Power BI."""
    return _ingest_generic_source(  # type: ignore
        source_name="powerbi",
        perspective_url=perspective_url,
        api_token=api_token,
        dry_run=dry_run,
        follow=follow,
        follow_timeout=follow_timeout,
    )


@app.command()
def qlik_sense(
    perspective_url: str = PerspectiveURL,
    api_token: str = PerspectiveApiToken,
    dry_run: bool = DryRun,
    follow: bool = Follow,
    follow_timeout: int = FollowTimeout,
) -> None:
    """Ingest metadata from Qlik Sense."""
    return _ingest_generic_source(  # type: ignore
        source_name="qlik_sense",
        perspective_url=perspective_url,
        api_token=api_token,
        dry_run=dry_run,
        follow=follow,
        follow_timeout=follow_timeout,
    )


@app.command()
def sap(
    perspective_url: str = PerspectiveURL,
    api_token: str = PerspectiveApiToken,
    dry_run: bool = DryRun,
    follow: bool = Follow,
    follow_timeout: int = FollowTimeout,
) -> None:
    """Ingest metadata from SAP."""
    return _ingest_generic_source(  # type: ignore
        source_name="sap",
        perspective_url=perspective_url,
        api_token=api_token,
        dry_run=dry_run,
        follow=follow,
        follow_timeout=follow_timeout,
    )


def _ingest_generic_source(
    source_name: str,
    perspective_url: str,
    dry_run: bool,
    follow: bool,
    follow_timeout: int,
    api_token: str | None = None,
) -> tuple[list, list]:
    """Generic ingestion logic for standard sources."""
    try:
        module = import_module(
            f"perspective.ingest.sources.database.{source_name}.pipeline"
        )
        source_type = "database"
    except ModuleNotFoundError:
        try:
            module = import_module(
                f"perspective.ingest.sources.bi.{source_name}.pipeline"
            )
            source_type = "dashboard"
        except ModuleNotFoundError:
            console.print(f"Unsupported metadata source: {source_name}")
            raise

    endpoint = urljoin(perspective_url, f"/ingest/{source_type}")
    manifests = module.pipeline()
    responses = []
    ingestion_ids = []
    for manifest in manifests:
        payload = json.loads(manifest.json(by_alias=True))
        n_items = len(payload["payload"])

        logger.debug(
            f"Sending {n_items} items from {source_name} metadata source to Perspective Catalog at {perspective_url}..."
        )

        # If in dry run mode, print the bundle and exit.
        if dry_run:
            console.print(payload)
            raise Exit(0)

        # Send ingestion request.
        response, ingestion_id = send_request(
            url=endpoint,
            payload=payload,
            headers={"Authorization": f"Bearer {api_token}"} if api_token else None,
            return_response_key="ingestion_id",
            verify=False,
        )

        if follow and ingestion_id:
            ingestion_status = None

            with console.status("Waiting...", spinner="dots"):
                for _ in range(follow_timeout):
                    ingestion_status = check_ingestion_status(
                        perspective_url, ingestion_id, api_token=api_token
                    )
                    if ingestion_status == IngestionStatus.successful.value:
                        response = check_ingestion_results(
                            perspective_url, ingestion_id, api_token=api_token
                        )
                        console.print()
                        console.print(f"Ingestion results for ID {ingestion_id}:")
                        console.print()
                        console.print(response)

                    if ingestion_status == IngestionStatus.failed.value:
                        console.print()
                        console.print(f"Ingestion failed for ID {ingestion_id}")

                    if ingestion_status == IngestionStatus.pending.value:
                        sleep(1)

            if ingestion_status != IngestionStatus.successful.value:
                status_human_readable = IngestionStatus(ingestion_status).name
                console.print(
                    f"Ingestion did not complete successfully within {follow_timeout} seconds. Status: {status_human_readable}."
                )

        responses.append(response)
        ingestion_ids.append(ingestion_id)

    return responses, ingestion_ids
