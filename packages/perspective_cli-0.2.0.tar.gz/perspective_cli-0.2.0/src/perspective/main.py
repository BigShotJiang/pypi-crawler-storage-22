"""A command-line interface (CLI) for the Perspective application.

Provides commands for database operations, configuration management, and more.
"""

import sys

from loguru import logger
import typer
import urllib3

from perspective import __version__, config
from perspective.ingest import ingest


# Set the logging level to INFO by default.
logger.remove()
logger.add(sys.stdout, level="INFO")


# Disable warnings related to insecure requests for specific cases
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


# Create a Typer application with configured properties
app = typer.Typer(
    name="perspective",
    no_args_is_help=True,
    pretty_exceptions_enable=True,
    pretty_exceptions_show_locals=False,
    pretty_exceptions_short=True,
)


def version_callback(show_version: bool) -> str | None:
    """Print the version of the application.

    Args:
        show_version (bool): If True, shows the version.
    """
    if show_version:
        typer.echo(__version__)
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        None,
        "--version",
        "-v",
        callback=version_callback,
        is_eager=True,
        help="Show the version and exit.",
    ),
) -> None:
    """Main function for the Typer application.

    Args:
        version (bool): Flag to show the version and exit.
        config_dir (str): The directory containing the Perspective configuration file.
    """
    pass


app.add_typer(
    config.app, name="config", help="Manage Perspective instance configuration."
)
app.add_typer(
    ingest.app, name="ingest", help="Ingest model metadata from various data sources."
)
