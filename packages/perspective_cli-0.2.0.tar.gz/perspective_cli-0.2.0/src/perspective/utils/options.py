"""Common Typer options."""

import os
from pathlib import Path
from typing import Annotated

import typer


MetadataDir: Path = typer.Option(
    Path(os.getenv("DBT_PROFILES_DIR", ".")) / "target",
    "--metadata-dir",
    "-m",
    help="Specify the directory with dbt metadata files. Defaults to $DBT_PROFILES_DIR/target or ./target if not set.",
    exists=True,
    dir_okay=True,
    resolve_path=True,
)

ConfigDir: Path = typer.Option(
    "./.perspective",
    "--config-dir",
    "-c",
    help="Specify the directory with the config files. Defaults to ./.perspective",
    envvar="PERSPECTIVE_CONFIG_DIR",
    dir_okay=True,
    resolve_path=True,
)

Force: bool = typer.Option(
    False,
    "--force",
    "-f",
    help="Force the operation.",
)

DryRun: bool = typer.Option(
    False,
    "--dry-run",
    "-D",
    help="Perform a dry run. Print the payload but do not send it.",
)

NoConfig: bool = typer.Option(
    False,
    "--no-config",
    "-n",
    help="Set this flag to prevent sending configuration data along with the request.",
)

Follow: bool = typer.Option(
    False, "--follow", help="Follow the ingestion process until it's completed."
)

IngestionId = Annotated[str, typer.Argument(help="Ingestion ID.")]

PerspectiveURL: str = typer.Option(
    "http://localhost:8000/api/v1/",
    "--url",
    "-u",
    help="URL of the Perspective API.",
    envvar="PERSPECTIVE_API_URL",
)

PerspectiveApiToken: str = typer.Option(
    None,
    "--token",
    "-t",
    help="API token for authenticating with the Perspective API.",
    envvar="PERSPECTIVE_API_TOKEN",
)

FollowTimeout: int = typer.Option(
    30,
    "--follow-timeout",
    "-w",
    help="How many seconds to wait for the ingestion process to complete.",
    envvar="PERSPECTIVE_TIMEOUT",
)

IsDbtTestResultsIngestion: bool = typer.Option(
    False,
    "--test-results",
    help="Set this flag to only ingest dbt test results.",
)
