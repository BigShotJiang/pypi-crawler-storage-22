"""Utility functions."""

from enum import Enum
import json
from pathlib import Path
import subprocess  # noqa: S404
from traceback import format_exc
from urllib.parse import urljoin

from requests import Response, request
from requests.exceptions import ConnectionError as RequestsConnectionError
from requests.exceptions import HTTPError, Timeout
from rich import print as rprint
from rich.console import Console
from rich.panel import Panel
import typer

from perspective import __version__


console = Console()


class IngestionStatus(Enum):
    """Ingestion status values."""

    successful = 0
    failed = 1
    pending = 2


class HttpMethod(str, Enum):
    """HTTP methods."""

    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    HEAD = "HEAD"
    OPTIONS = "OPTIONS"
    PATCH = "PATCH"


def safe_json_load(path: str | Path) -> dict | None:
    """Reads a JSON file into a Python dictionary.

    Args:
        path (str | Path): The path to the JSON file.

    Returns:
        dict | None: A dictionary representation of the JSON file, or None if an error
            occurs.
    """
    try:
        with Path(path).open("r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = None
    return data


def run_command(command: str, capture_output: bool = False) -> str | None:
    """Execute a shell command and optionally capture its output.

    Args:
        command (str): The shell command to be executed.
        capture_output (bool, optional): Flag to determine if the command's output
            should be captured. Defaults to False.

    Returns:
        str | None: The standard output of the command if `capture_output` is True,
            otherwise None.

    Raises:
        typer.Exit: Exits the script if the command execution fails.
    """
    try:
        result = subprocess.run(  # noqa: S602
            command,
            shell=True,
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as e:
        console.print(
            Panel.fit(
                f"[bold red]ERROR[/bold red]: An error occurred while running the command: [bold yellow]{e}[/bold yellow]",
                title="Error",
                border_style="red",
            )
        )
        if e.output:
            console.print(f"[bold cyan]Output[/bold cyan]: {e.output}")
        if e.stderr:
            console.print(f"[bold red]Error[/bold red]: {e.stderr}")
        raise typer.Exit(1) from e

    if capture_output:
        return result.stdout.strip()

    return None


def print_response(response: Response) -> None:
    """Print an API response.

    Args:
        response (requests.Response): The response to print.
    """
    try:
        parsed_response = response.json()
    except Exception:
        parsed_response = None

    if response.ok:
        msg = "[green]The request was successful.[/green]"
        if parsed_response:
            msg += f"\n[yellow]Response:\n{parsed_response}[/yellow]"
        else:
            msg += f"\n[green]Raw response:\n{response.text}[/green]"
    else:
        if parsed_response:
            error_msg = f"\n\nError message: {parsed_response['message']}"
        else:
            error_msg = f"Raw response:\n{response.text}"
        msg = f"[red]The request failed with status code {response.status_code}.{error_msg}[/red]"

    rprint(msg)

    if not response.ok or parsed_response is None:
        raise typer.Exit(1)


def send_request(
    url: str,
    payload: dict | list | None = None,
    verify: bool = True,
    method: HttpMethod = HttpMethod.POST,
    timeout: (float | tuple[float, float] | tuple[float, None]) = (21.05, 60 * 30),
    headers: dict[str, str] | None = None,
    params: dict[str, str | int | float] | None = None,
    return_response_key: str | None = None,
) -> Response | tuple[Response, str | None]:
    """Send an HTTP request.

    Args:
        url (str): The URL for the request.
        payload (dict | list | None): The payload for the request, if any.
        verify (bool, optional): Whether to verify the server's TLS certificate.
            Defaults to True.
        method (HttpMethod, optional): _description_. Defaults to HttpMethod.POST.
        timeout (optional[float | tuple[float, float] | tuple[float, None]]): The
            timeout for the request. Defaults to (20, 60 * 30).
        headers (optional[dict[str, str]], optional): Headers to be sent with the
            request. Defaults to None.
        params (optional[dict[str, str | int | float]]): URL parameters for the request.
            Defaults to None.
        return_response_key (str | None, optional): Key to extract from the response.
            Defaults to None.

    Raises:
        typer.Exit: In case of timeout or connection error.

    Returns:
        [requests.Response | tuple[requests.Response, str | None]]: The HTTP response
            and a value extracted from the response (if `return_response_key` is
            provided).
    """
    rprint("[yellow]Sending request to Perspective...[/yellow]")

    default_headers = {"User-Agent": f"perspective-cli/{__version__}"}

    # Catch timeouts/connection errors separately to provide more specific guidance.
    try:
        response = request(
            method=method,
            url=url,
            headers={**default_headers, **(headers or {})},
            params=params,
            json=payload,
            verify=verify,
            timeout=timeout,
        )
    except (Timeout, RequestsConnectionError) as e:
        error_message = (
            "The request has failed. Please check your connection and try again."
        )
        if isinstance(e, Timeout):
            error_message += " If you're using a VPN, ensure it's properly connected or try disabling it temporarily."
        else:
            error_message += " This could be due to maximum retries being exceeded or failure to establish a new connection. Please check your network configuration."

        rprint(Panel(f"[red]{error_message}[/red]"))

        # Print the traceback
        traceback_info = format_exc()
        rprint(Panel(f"[red]{traceback_info}[/red]"))

        raise typer.Exit(1) from e

    # Catch all other HTTP errors.
    try:
        response.raise_for_status()
    except HTTPError as e:
        rprint(
            Panel(
                f"[red]The request to {url} FAILED with status: {response.status_code} ({response.reason})[/red]\n"
                + (f"[red]API response:[/red]\n{e.response.text}")
            )
        )
        raise typer.Exit(1) from e

    print_response(response)

    if return_response_key:
        extracted_value = response.json().get(return_response_key)
        return response, extracted_value
    return response


def check_ingestion_status(
    perspective_url: str,
    ingestion_uuid: str,
    api_token: str | None = None,
    verify: bool = True,
) -> str:
    """Fetches the status for a specific ingestion ID from Perspective.

    Args:
        perspective_url (str): The URL of the Perspective instance.
        ingestion_uuid (str): The ingestion ID to fetch the status for.
        api_token (str | None, optional): The API token for authentication. Defaults to
            None.
        verify (bool): Whether to verify the server's TLS certificate. Defaults to True.

    Returns:
        str: The status of the ingestion process.
    """
    status_endpoint = urljoin(perspective_url, "catalog/ingestions/")
    response = send_request(
        method="GET",
        url=status_endpoint,
        params={"uuid": ingestion_uuid},
        headers={"Authorization": f"Bearer {api_token}"} if api_token else None,
        verify=verify,
    )
    ingestion = response.json().get("data")
    return ingestion.get("status")


def check_ingestion_results(
    perspective_url: str,
    ingestion_uuid: str,
    api_token: str | None = None,
    verify: bool = True,
) -> str | dict:
    """Fetche and interpret the results for a specific ingestion ID.

    Args:
        perspective_url (str): The URL of the Perspective instance.
        ingestion_uuid (str): The ingestion ID to check the results for.
        api_token (str | None, optional): The API token for authentication. Defaults to
            None.
        verify (bool): Whether to verify the server's TLS certificate. Defaults to True.

    Returns:
        str | dict: A message describing the status of the ingestion process or
            the JSON response for successful completions.
    """
    status_endpoint = urljoin(perspective_url, "catalog/ingestions/")
    response = send_request(
        method="GET",
        url=status_endpoint,
        params={"uuid": ingestion_uuid},
        headers={"Authorization": f"Bearer {api_token}"} if api_token else None,
        verify=verify,
    )
    ingestion = response.json().get("data")
    status = ingestion.get("status")

    if status == IngestionStatus.pending.value:
        return f"Ingestion ID {ingestion_uuid} is still pending."

    if status == IngestionStatus.failed.value:
        error_details = ingestion.get("error", "No additional error details provided.")
        return (
            f"Ingestion ID {ingestion_uuid} has failed. Error details: {error_details}"
        )

    if status == IngestionStatus.successful.value:
        # Return the entire JSON response for successful completions
        return ingestion.get("summary")

    return f"Unrecognized status for ingestion ID {ingestion_uuid}: {status}"
