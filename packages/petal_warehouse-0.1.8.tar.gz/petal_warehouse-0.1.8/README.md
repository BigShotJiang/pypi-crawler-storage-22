# petal-warehouse

Needs these dependencies

```bash
sudo apt-get update
sudo apt-get install -y portaudio19-dev libasound2-dev libportaudiocpp0
sudo apt-get install -y ffmpeg        # installs ffmpeg, ffprobe, ffplay
```
