.. _reference:

Reference
=========

.. autosummary::
   :toctree: reference/

   petsc4py
   petsc4py.typing
   petsc4py.PETSc
