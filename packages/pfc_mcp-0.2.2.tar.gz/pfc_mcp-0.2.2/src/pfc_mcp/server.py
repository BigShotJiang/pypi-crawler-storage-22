"""PFC MCP Server - ITASCA PFC tools exposed over MCP."""

import argparse
import asyncio
import logging

from fastmcp import FastMCP
from pfc_mcp import __version__
from pfc_mcp.bridge import close_bridge_client

from pfc_mcp.tools import (
    browse_commands,
    browse_python_api,
    browse_reference,
    capture_plot,
    check_task_status,
    execute_task,
    interrupt_task,
    list_tasks,
    query_command,
    query_python_api,
)

mcp = FastMCP(
    "PFC MCP Server",
    instructions=(
        "PFC (Particle Flow Code) documentation server. "
        "Provides tools for browsing/searching documentation and for executing tasks "
        "through a pfc-bridge WebSocket service running inside PFC GUI."
    ),
)

logger = logging.getLogger("pfc-mcp.server")

# Register documentation tools
browse_commands.register(mcp)
browse_python_api.register(mcp)
browse_reference.register(mcp)
query_command.register(mcp)
query_python_api.register(mcp)

# Register execution tools
execute_task.register(mcp)
check_task_status.register(mcp)
list_tasks.register(mcp)
interrupt_task.register(mcp)
capture_plot.register(mcp)


def main():
    """Entry point for the PFC MCP server."""
    parser = argparse.ArgumentParser(
        prog="pfc-mcp",
        description="PFC MCP Server - ITASCA PFC tools exposed over MCP",
    )
    parser.add_argument(
        "--version", "-v", action="version", version=f"pfc-mcp {__version__}"
    )
    parser.parse_args()

    try:
        mcp.run(transport="stdio", show_banner=False)
    finally:
        try:
            asyncio.run(close_bridge_client())
        except Exception as exc:
            logger.debug("Bridge client cleanup skipped: %s", exc)


if __name__ == "__main__":
    main()
