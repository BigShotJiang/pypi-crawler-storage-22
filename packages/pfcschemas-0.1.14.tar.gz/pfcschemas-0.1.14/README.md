# PFCSchemas

Pydantic schemas for the pyflightcoach libraries

to install:
```
    pip install pfcschemas
```