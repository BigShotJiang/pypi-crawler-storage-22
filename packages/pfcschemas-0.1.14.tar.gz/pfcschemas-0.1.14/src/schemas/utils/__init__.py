from .files import validate_json
from .enum import EnumStr