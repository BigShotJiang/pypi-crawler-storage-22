"""
Helpers compartilhados do pftcli.
"""
