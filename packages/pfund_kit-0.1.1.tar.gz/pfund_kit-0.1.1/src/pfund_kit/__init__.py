from importlib.metadata import version


__version__ = version("pfund-kit")
# __all__ = ()
