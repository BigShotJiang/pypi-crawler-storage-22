import copy
import gc
import json
import logging
import math
import pprint
from datetime import timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, Mapping, Optional, Tuple, Type
from uuid import uuid4

import matplotlib.pyplot as plt
import numpy as np
import optuna
import pandas as pd
import plotly.graph_objects as go
import torch
import torch.nn.functional as F
from matplotlib.figure import Figure
from sklearn.metrics import (
    average_precision_score,
    classification_report,
    jaccard_score,
    matthews_corrcoef,
)
from sklearn.model_selection import train_test_split
from snpio import SNPioMultiQC
from snpio.utils.logging import LoggerManager
from snpio.utils.misc import validate_input_type

from pgsui.data_processing.transformers import SimMissingTransformer
from pgsui.impute.unsupervised.nn_scorers import Scorer
from pgsui.utils.classification_viz import ClassificationReportVisualizer
from pgsui.utils.logging_utils import (
    configure_logger,
    configure_optuna_best_trial_logger,
)
from pgsui.utils.plotting import Plotting
from pgsui.utils.pretty_metrics import PrettyMetrics

if TYPE_CHECKING:
    from snpio.read_input.genotype_data import GenotypeData


class _MaskedNumpyDataset(torch.utils.data.Dataset):
    def __init__(self, X: np.ndarray, y: np.ndarray, mask: np.ndarray):
        self.X = X
        self.y = y
        self.mask = mask.astype(np.bool_, copy=False)

    def __len__(self) -> int:
        return self.X.shape[0]

    def __getitem__(self, idx: int):
        return self.X[idx], self.y[idx], self.mask[idx]


class BaseNNImputer:
    """Abstract base class for neural network-based imputers.

    This class provides shared infrastructure for NN imputers (e.g., directory/logging setup, Optuna tuning, model construction helpers, class-weight utilities, standardized plotting/scoring, and IUPAC decoding). It is not intended to be instantiated directly; subclasses must implement the abstract methods.
    """

    def __init__(
        self,
        model_name: str,
        genotype_data: "GenotypeData",
        prefix: str,
        *,
        device: Literal["gpu", "cpu", "mps"] = "cpu",
        verbose: bool = False,
        debug: bool = False,
    ):
        """Initializes the base class for neural network imputers.

        This constructor sets up the device (CPU, GPU, or MPS), creates the necessary output directories for models and results, and a logger. It also initializes a genotype encoder for handling genotype data.

        Args:
            model_name (str): The model class name used in output paths and logs.
            genotype_data (GenotypeData): Backing genotype data object.
            prefix (str): A prefix used to name the output directory (e.g., 'pgsui_output').
            device (Literal["gpu", "cpu", "mps"]): The device to use for PyTorch operations. If 'gpu' or 'mps' is chosen, it will fall back to 'cpu' if the required hardware is not available. Defaults to "cpu".
            verbose (bool): If True, enables detailed logging output. Defaults to False.
            debug (bool): If True, enables debug mode. Defaults to False.
        """
        self.model_name = model_name
        self.genotype_data = genotype_data

        if not hasattr(self, "tree_parser"):
            self.tree_parser = None
        if not hasattr(self, "sim_kwargs"):
            self.sim_kwargs = {}

        self.prefix = prefix
        self.verbose = verbose
        self.debug = debug

        # Quiet Matplotlib/fontTools INFO logging when saving PDF/SVG
        for name in (
            "fontTools",
            "fontTools.subset",
            "fontTools.ttLib",
            "matplotlib.font_manager",
        ):
            lg = logging.getLogger(name)
            lg.setLevel(logging.WARNING)
            lg.propagate = False

        self.device = self._select_device(device)
        self.num_embeddings: int = 0
        self.total_samples_: int = 0

        # Prepare directory structure
        outdirs = ["models", "plots", "metrics", "optimize", "parameters"]
        self._create_model_directories(prefix, outdirs)

        # Initialize loggers
        kwargs = {"prefix": prefix, "verbose": verbose, "debug": debug}
        logman = LoggerManager(__name__, **kwargs)
        self.logger = configure_logger(
            logman.get_logger(), verbose=self.verbose, debug=self.debug
        )
        self.logger.propagate = False

        self.logger.info(f"Using PyTorch device: {self.device.type}.")

        # To be initialized by child classes or fit method
        self.tune_save_db: bool = False
        self.tune_resume: bool = False
        self.n_trials: int = 100
        self.model_params: dict[str, Any] = {}
        self.tune_metric: str = "f1"
        self.primary_metric: str
        self.learning_rate: float = 1e-3
        self.plotter_: "Plotting"
        self.num_features_: int = 0
        self.num_tuned_params_: int = 0
        self.num_classes_: int = 3
        self.plot_format: Literal["pdf", "png", "jpg", "jpeg", "svg"] = "pdf"
        self.plot_fontsize: int = 10
        self.plot_dpi: int = 300
        self.title_fontsize: int = 12
        self.use_multiqc: bool = True
        self.despine: bool = True
        self.show_plots: bool = False
        self.scoring_averaging: Literal["macro", "weighted"] = "macro"
        self.pgenc: Any = None
        self.is_haploid_: bool = False
        self.ploidy: int = 2
        self.beta: float = 0.9999
        self.max_ratio: Optional[float] = None
        self.sim_strategy: str = "random"
        self.sim_prop: float = 0.2
        self.seed: Optional[int] = None
        self.rng: np.random.Generator = np.random.default_rng(self.seed)
        self.ground_truth_: np.ndarray
        self.validation_split: float = 0.2
        self.batch_size: int = 64
        self.best_params_: dict[str, Any] = {}

        self.optimize_dir: Path
        self.models_dir: Path
        self.plots_dir: Path
        self.metrics_dir: Path
        self.parameters_dir: Path
        self.epochs: int
        self.study_db: Optional[Path] = None
        self.X_model_input_: Optional[np.ndarray] = None
        self.class_weights_: Optional[torch.Tensor] = None

        self.sim_mask_train_: np.ndarray
        self.sim_mask_val_: np.ndarray
        self.sim_mask_test_: np.ndarray
        self.orig_mask_train_: np.ndarray
        self.orig_mask_val_: np.ndarray
        self.orig_mask_test_: np.ndarray

    def tune_hyperparameters(self) -> dict[str, Any]:
        """Tunes model hyperparameters using an Optuna study.

        This method orchestrates the hyperparameter search process. It creates an Optuna study that aims to maximize the metric defined in ``self.tune_metric``. The search is driven by the ``_objective`` method, which must be implemented by the child class. After the search, the best parameters are logged, saved to a JSON file, and visualizations of the study are generated.

        Raises:
            NotImplementedError: If the ``_objective`` or ``_set_best_params`` methods are not implemented in the inheriting child class.
        """
        self.logger.info("Tuning hyperparameters. This might take a while...")

        # NOTE: _objective() must be implemented in the child class.
        if not hasattr(self, "_objective") or not hasattr(self, "_set_best_params"):
            if not hasattr(self, "_objective"):
                msg = "_objective() must be implemented in the child class."
                self.logger.error(msg)
                raise NotImplementedError(msg)
            if not hasattr(self, "_set_best_params"):
                msg = "_set_best_params() must be implemented in the child class."
                self.logger.error(msg)
                raise NotImplementedError(msg)

        is_verbose = self.verbose or self.debug
        lvl = optuna.logging.INFO if is_verbose else optuna.logging.WARNING
        optuna.logging.set_verbosity(lvl)

        study_db = None
        load_if_exists = False
        if self.tune_save_db:
            uid = uuid4().hex
            outdir = self.optimize_dir / "study_database"
            study_db = outdir / f"optuna_study_{uid}.db"
            outdir.mkdir(parents=True, exist_ok=True)

            if study_db.exists():
                msg = f"Optuna study database already exists at: {study_db}"
                self.logger.info(msg)
                if self.tune_resume:
                    msg = "Resuming tuning from existing database."
                    self.logger.info(msg)
                    load_if_exists = True
                else:
                    msg = "Creating a new study database with a unique ID."
                    self.logger.info(msg)
                    uid = uuid4().hex
                    study_db = study_db.with_name(f"optuna_study_{uid}.db")

        self.study_db = study_db
        study_name = f"{self.prefix} {self.model_name} Model Optimization"
        storage = f"sqlite:///{study_db}" if self.tune_save_db else None

        if self.num_tuned_params_ == 0:
            msg = "Number of tuned parameters is zero. Ensure that the child class sets 'num_tuned_params_'."
            self.logger.warning(msg)
            n_params = None
        else:
            n_params = self.num_tuned_params_

        n_startup = self._compute_tpe_startup_trials(
            n_trials=self.n_trials, n_params=n_params
        )
        sampler = optuna.samplers.TPESampler(seed=self.seed, n_startup_trials=n_startup)

        # 1. Define the base pruner (Hyperband for efficiency)
        base_pruner = optuna.pruners.HyperbandPruner(
            min_resource=max(10, int(self.epochs * 0.2)),  # 10 or 20% of epochs
            max_resource=self.epochs,  # Max number of epochs
            reduction_factor=3,  # 1/3 of trials survive each round
        )
        pruner = optuna.pruners.PatientPruner(
            base_pruner,
            patience=3,  # Non-improving steps before pruning
            min_delta=0,  # Minimum improvement to reset patience
        )
        study_kwargs = {
            "study_name": study_name,
            "storage": storage,
            "load_if_exists": load_if_exists,
            "pruner": pruner,
            "sampler": sampler,
        }

        direction, directions = "maximize", ["maximize"] * len(self.tune_metric)
        if isinstance(self.tune_metric, (list, tuple)):
            msg = f"Tuning multiple metrics: {', '.join(self.tune_metric)}"
            self.logger.info(msg)
            study = optuna.create_study(directions=directions, **study_kwargs)
        else:
            msg = f"Tuning single metric: {self.tune_metric}"
            self.logger.info(msg)
            study = optuna.create_study(direction=direction, **study_kwargs)

        self.n_jobs = getattr(self, "n_jobs", 1)
        if self.n_jobs < -1 or self.n_jobs == 0:
            msg = f"Invalid n_jobs={self.n_jobs}. Setting n_jobs=1."
            self.logger.warning(msg)
            self.n_jobs = 1

        bar = not self.verbose and not self.debug and self.n_jobs == 1

        # Custom logger
        optlog = configure_optuna_best_trial_logger(min_delta=0.0)
        optlog.start(study, self.n_trials)
        study.optimize(
            lambda trial: self._objective(trial),
            n_trials=self.n_trials,
            n_jobs=self.n_jobs,
            gc_after_trial=True,
            show_progress_bar=bar,
            callbacks=[optlog.callback],
        )
        optlog.finish(study)

        try:
            best_metric = study.best_value
            best_params = study.best_params
        except Exception:
            try:
                best_metric = study.best_trials[0].values
                best_params = study.best_trials[0].params
            except Exception:
                msg = f"[{self.model_name}] Tuning failed: No successful trials completed. Try enabling debug mode for more details."
                self.logger.error(msg)
                raise RuntimeError(msg)

        if isinstance(best_metric, (list, tuple)) and isinstance(
            self.tune_metric, (list, tuple)
        ):
            best_metric_str = ", ".join(
                f"Best {m} metric: {v:.4f}"
                for m, v in zip(self.tune_metric, best_metric)
            )
        else:
            best_metric_str = f"Best {self.tune_metric} metric: {best_metric:.4f}"

        self.best_params_ = self._set_best_params(best_params)
        self.model_params.update(self.best_params_)
        best_params_tmp = copy.deepcopy(best_params)
        best_params_tmp["learning_rate"] = self.learning_rate

        tn = f"{self.primary_metric} Value"

        if self.show_plots:
            self.plotter_.plot_tuning(
                study, self.model_name, self.optimize_dir / "plots", target_name=tn
            )

        if study.trials:
            start_time = study.trials[0].datetime_start
            end_time = study.trials[-1].datetime_complete
            mean_trial_duration = None
            if start_time is not None and end_time is not None:
                duration = end_time - start_time
                if len(study.trials) > 0:
                    mean_trial_duration = sum(
                        (
                            t.duration
                            for t in study.trials
                            if study.trials is not None and t.duration is not None
                        ),
                        timedelta(0),
                    ) / len(study.trials)
                    stddev_trial_duration_seconds = (
                        sum(
                            (
                                (t.duration - mean_trial_duration).total_seconds() ** 2
                                for t in study.trials
                                if study.trials is not None and t.duration is not None
                            ),
                        )
                        / len(study.trials)
                    ) ** 0.5
                    stddev_trial_duration = timedelta(
                        seconds=stddev_trial_duration_seconds
                    )
        else:
            duration = None
            mean_trial_duration = None
            stddev_trial_duration = None

        self.logger.info("")
        self.logger.info("************ TUNING SUMMARY ************")
        self.logger.info("")
        if duration is not None:
            self.logger.info(
                f"Tuning completed in: {duration} (HH:MM:SS) for {len(study.trials)} trials."
            )
        if mean_trial_duration is not None:
            self.logger.info("")
            self.logger.info(f"Average trial duration: {mean_trial_duration}")
        if stddev_trial_duration is not None:
            self.logger.info("")
            self.logger.info(
                f"Trial duration standard deviation: {stddev_trial_duration}"
            )
        self.logger.info("")
        self.logger.info(best_metric_str)
        self.logger.info("")
        self.logger.info("Best tuned parameters:")
        self.logger.info("")
        self.logger.info(pprint.pformat(self.best_params_, indent=4, width=72))
        self.logger.info("")

        self.logger.info("Tuning completed!")

        return best_params_tmp

    @staticmethod
    def initialize_weights(module: torch.nn.Module) -> None:
        """Initializes model weights using Xavier/Glorot Uniform distribution.

        Switching from Kaiming to Xavier is safer for deep VAEs to prevent
        exploding gradients or dead neurons in the early epochs.
        """
        if isinstance(
            module, (torch.nn.Linear, torch.nn.Conv1d, torch.nn.ConvTranspose1d)
        ):
            # Xavier is generally more stable for VAEs than Kaiming
            torch.nn.init.xavier_uniform_(module.weight)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)

    def build_model(
        self,
        Model: Type[torch.nn.Module],
        model_params: dict[str, Any],
    ) -> torch.nn.Module:
        """Builds and initializes a neural network model instance.

        This method instantiates a model by combining fixed, data-dependent parameters (like `n_features`) with variable hyperparameters (like `latent_dim`). The resulting model is then moved to the appropriate compute device.

        Args:
            Model (torch.nn.Module): The model class to be instantiated.
            model_params (dict[str, Any]): A dictionary of variable model hyperparameters, typically sampled during a hyperparameter search.

        Returns:
            torch.nn.Module: The constructed model instance, ready for training.

        Raises:
            TypeError: If `model_params` is not a dictionary.
            AttributeError: If a required data-dependent attribute like `num_features_` has not been set, typically by calling `fit` first.
        """
        if not isinstance(model_params, dict):
            msg = f"'model_params' must be a dictionary, but got {type(model_params)}."
            self.logger.error(msg)
            raise TypeError(msg)

        if not hasattr(self, "num_features_"):
            msg = (
                "Attribute 'num_features_' is not set. Call fit() before build_model()."
            )
            self.logger.error(msg)
            raise AttributeError(msg)

        all_params = {
            "n_features": self.num_features_,
            "prefix": self.prefix,
            "num_classes": self.num_classes_,
            "verbose": self.verbose,
            "debug": self.debug,
            "device": self.device,
        }

        if self.model_name in {f"ImputeUBP", "ImputeNLPCA"}:
            all_params["num_embeddings"] = getattr(self, "total_samples_", 0)
            if self.total_samples_ == 0:
                msg = "Attribute 'total_samples_' is not set. Call fit() before build_model()."
                self.logger.error(msg)
                raise AttributeError(msg)

        # Update with the variable hyperparameters
        all_params.update(model_params)

        return Model(**all_params).to(self.device)

    def initialize_plotting_and_scorers(self) -> tuple[Plotting, Scorer]:
        """Initializes and returns the plotting and scoring utility classes.

        This method should be called within a `fit` method to set up the standardized utilities for generating plots and calculating performance metrics.

        Returns:
            tuple[Plotting, Scorer]: A tuple containing the initialized Plotting and Scorer objects.
        """
        fmt = self.plot_format

        # Initialize plotter.
        plotter = Plotting(
            model_name=self.model_name,
            prefix=self.prefix,
            plot_format=fmt,
            plot_fontsize=self.plot_fontsize,
            plot_dpi=self.plot_dpi,
            title_fontsize=self.title_fontsize,
            despine=self.despine,
            show_plots=self.show_plots,
            verbose=self.verbose,
            debug=self.debug,
            multiqc=self.use_multiqc,
            multiqc_section=f"PG-SUI: {self.model_name} Model Imputation",
        )

        # Metrics
        scorers = Scorer(
            prefix=self.prefix,
            average=self.scoring_averaging,
            verbose=self.verbose,
            debug=self.debug,
        )

        return plotter, scorers

    def _objective(self, trial: optuna.Trial) -> float:
        """Defines the objective function for Optuna hyperparameter tuning.

        This abstract method must be implemented by the child class. It should define a single hyperparameter tuning trial, which typically involves building, training, and evaluating a model with a set of sampled hyperparameters.

        Args:
            trial (optuna.Trial): The Optuna trial object, used to sample hyperparameters.

        Returns:
            float: The value of the metric to be optimized (e.g., validation accuracy, F1-score).
        """
        msg = "Method `_objective()` must be implemented in the child class."
        self.logger.error(msg)
        raise NotImplementedError(msg)

    def fit(self, X: np.ndarray | pd.DataFrame | list | None = None) -> "BaseNNImputer":
        """Fits the imputer model to the data.

        This abstract method must be implemented by the child class. It should contain the logic for training the neural network model on the provided input data `X`.

        Args:
            X (np.ndarray | pd.DataFrame | list | None): The input data, which may contain missing values.

        Returns:
            BaseNNImputer: The fitted imputer instance.
        """
        msg = "Method ``fit()`` must be implemented in the child class."
        self.logger.error(msg)
        raise NotImplementedError(msg)

    def transform(
        self, X: np.ndarray | pd.DataFrame | list | None = None
    ) -> np.ndarray:
        """Imputes missing values in the data using the trained model.

        This abstract method must be implemented by the child class. It should use the fitted model to fill in missing values in the provided data `X`.

        Args:
            X (np.ndarray | pd.DataFrame | list | None): The input data with missing values.

        Returns:
            np.ndarray: IUPAC strings with missing values imputed.
        """
        msg = "Method ``transform()`` must be implemented in the child class."
        self.logger.error(msg)
        raise NotImplementedError(msg)

    def _select_device(self, device: Literal["gpu", "cpu", "mps"]) -> torch.device:
        """Selects the appropriate PyTorch device based on user preference and availability.

        This method checks the user's device preference ('gpu', 'cpu', or 'mps') and verifies if the requested hardware is available. If the preferred device is not available, it falls back to CPU and logs a warning.

        Args:
            device (Literal["gpu", "cpu", "mps"]): The preferred device type for PyTorch operations.

        Returns:
            torch.device: The selected PyTorch device.
        """
        dvc = device.lower().strip()
        if dvc == "cpu":
            self.logger.debug("Using CPU as the compute device.")
            return torch.device("cpu")
        if dvc == "mps":
            if torch.backends.mps.is_available():
                self.logger.debug("Using Apple MPS as the compute device.")
                return torch.device("mps")

            self.logger.debug("Apple MPS is unavailable. Falling back to CPU.")
            return torch.device("cpu")
        if torch.cuda.is_available():
            self.logger.debug("Using CUDA GPU as the compute device.")
            return torch.device("cuda")

        self.logger.debug("CUDA GPU is unavailable. Falling back to CPU.")
        return torch.device("cpu")

    def _create_model_directories(
        self, prefix: str, outdirs: list[str], *, outdir: Path | str | None = None
    ) -> None:
        """Creates the directory structure for storing model outputs.

        This method sets up a standardized folder hierarchy for saving models, plots, metrics, and optimization results, organized under a main directory named after the provided prefix. The current implementation always uses `<cwd>/<prefix>_output`` regardless of ``outdir``.

        Args:
            prefix (str): The prefix for the main output directory.
            outdirs (list[str]): A list of subdirectory names to create within the main directory.
            outdir (Path | str | None): Requested base output directory (currently ignored).

        Raises:
            Exception: If any of the directories cannot be created.
        """
        base_root = Path(outdir) if outdir is not None else Path.cwd()
        formatted_output_dir = base_root / f"{prefix}_output"
        formatted_output_dir = Path(f"{prefix}_output")
        base_dir = formatted_output_dir / "Unsupervised"

        self.logger.debug(f"Creating output directories under: {base_dir}")

        for d in outdirs:
            subdir = base_dir / d / self.model_name
            setattr(self, f"{d}_dir", subdir)
            try:
                getattr(self, f"{d}_dir").mkdir(parents=True, exist_ok=True)
            except Exception as e:
                msg = f"Failed to create directory {getattr(self, f'{d}_dir')}: {e}"
                self.logger.error(msg)
                raise Exception(msg)

    def _clear_resources(self, model: torch.nn.Module) -> None:
        """Releases GPU and CPU memory after an Optuna trial.

        This is a crucial step during hyperparameter tuning to prevent memory leaks between trials, ensuring that each trial runs in a clean environment.

        Args:
            model (torch.nn.Module): The model from the completed trial.
        """
        try:
            del model
        except NameError:
            pass

        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        elif hasattr(torch, "mps") and torch.backends.mps.is_available():
            try:
                torch.mps.empty_cache()
            except Exception:
                pass

    def _additional_metrics(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        labels: list[int],
        report_names: list[str],
        report: dict,
    ) -> dict[str, dict[str, float] | float]:
        """Compute additional metrics and augment the report dictionary.

        Args:
            y_true (np.ndarray): True genotypes.
            y_pred (np.ndarray): Predicted genotypes.
            labels (list[int]): List of label indices.
            report_names (list[str]): List of report names corresponding to labels.
            report (dict): Classification report dictionary to augment.

        Returns:
            dict[str, dict[str, float] | float]: Augmented report dictionary.
        """
        n_classes = len(report_names)

        y_true_int = np.array(y_true, dtype=int).reshape(-1)
        y_pred_int = np.array(y_pred, dtype=int).reshape(-1)
        valid = (
            (y_true_int >= 0)
            & (y_true_int < n_classes)
            & (y_pred_int >= 0)
            & (y_pred_int < n_classes)
        )
        if not bool(valid.any()):
            msg = (
                f"[{self.model_name}] No valid labels available for additional metrics "
                f"(n_classes={n_classes})."
            )
            self.logger.error(msg)
            raise ValueError(msg)
        dropped = int(valid.size - int(valid.sum()))
        if dropped > 0:
            self.logger.warning(
                f"[{self.model_name}] Dropping {dropped} out-of-range labels before additional metrics."
            )

        y_true_int = y_true_int[valid]
        y_pred_int = y_pred_int[valid]

        # --- Enforce Multilabel Format for AP Score ---
        # Explicitly One-Hot Encode (OHE) y_true to shape (N, n_classes).
        # This forces return of array of shape (n_classes,)
        # even if n_classes == 2.

        # 1. OHE Truth
        y_true_ohe = np.eye(n_classes)[y_true_int]

        # 2. OHE Predictions (Scores)
        # Using hard predictions as scores (coarse, but matches logic)
        y_score_ohe = np.eye(n_classes)[y_pred_int]

        # Per-class metrics
        # average=None on OHE inputs returns an array (C,)
        ap_pc = average_precision_score(y_true_ohe, y_score_ohe, average=None)
        ap_macro = average_precision_score(y_true_ohe, y_score_ohe, average="macro")
        ap_weighted = average_precision_score(
            y_true_ohe, y_score_ohe, average="weighted"
        )

        # Jaccard similarity coefficient
        # (Jaccard handles 1D inputs for average=None, returning an array)
        jaccard_pc = jaccard_score(
            y_true_int, y_pred_int, average=None, labels=labels, zero_division=0
        )
        jaccard_macro = jaccard_score(
            y_true_int, y_pred_int, average="macro", zero_division=0
        )
        jaccard_weighted = jaccard_score(
            y_true_int, y_pred_int, average="weighted", zero_division=0
        )

        # Matthews correlation coefficient (MCC)
        mcc = matthews_corrcoef(y_true_int, y_pred_int)

        # These checks should now pass for both binary and multiclass
        if not isinstance(ap_pc, np.ndarray):
            msg = f"average_precision_score return type {type(ap_pc)} is not np.ndarray (ap_pc={ap_pc})."
            self.logger.error(msg)
            raise TypeError(msg)

        if not isinstance(jaccard_pc, np.ndarray):
            msg = "jaccard_score did not return np.ndarray as expected."
            self.logger.error(msg)
            raise TypeError(msg)

        # Add per-class metrics
        report_full = {}
        dd_subset = {
            k: v for k, v in report.items() if k in report_names and isinstance(v, dict)
        }
        for i, class_name in enumerate(report_names):
            class_report: dict[str, float] = {}
            if class_name in dd_subset:
                class_report = dd_subset[class_name]

            if isinstance(class_report, float) or not class_report:
                continue

            report_full[class_name] = dict(class_report)
            report_full[class_name]["average-precision"] = float(ap_pc[i])
            report_full[class_name]["jaccard"] = float(jaccard_pc[i])

        macro_avg = report.get("macro avg")
        if isinstance(macro_avg, dict):
            report_full["macro avg"] = dict(macro_avg)
            report_full["macro avg"]["average-precision"] = float(ap_macro)
            report_full["macro avg"]["jaccard"] = float(jaccard_macro)

        weighted_avg = report.get("weighted avg")
        if isinstance(weighted_avg, dict):
            report_full["weighted avg"] = dict(weighted_avg)
            report_full["weighted avg"]["average-precision"] = float(ap_weighted)
            report_full["weighted avg"]["jaccard"] = float(jaccard_weighted)

        # Add scalar summary metrics
        report_full["mcc"] = float(mcc)
        accuracy_val = report.get("accuracy")

        if isinstance(accuracy_val, (int, float)):
            report_full["accuracy"] = float(accuracy_val)

        return report_full

    def _make_class_reports(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        metrics: dict[str, float],
        y_pred_proba: np.ndarray | None = None,
        labels: list[str] = ["REF", "HET", "ALT"],
    ) -> None:
        """Generate and save detailed classification reports and visualizations.

        3-class (zygosity) or 10-class (IUPAC) depending on `labels` length.

        Args:
            y_true (np.ndarray): True labels (1D array).
            y_pred (np.ndarray): Predicted labels (1D array).
            metrics (dict[str, float]): Computed metrics.
            y_pred_proba (np.ndarray | None): Predicted probabilities (2D array). Defaults to None.
            labels (list[str]): Class label names (default: ["REF", "HET", "ALT"] for 3-class).
        """
        report_name = "zygosity" if len(labels) <= 3 else "iupac"
        middle = "IUPAC" if report_name == "iupac" else "Zygosity"

        y_true_arr = np.asarray(y_true).reshape(-1)
        y_pred_arr = np.asarray(y_pred).reshape(-1)
        n_classes = int(len(labels))
        valid = (
            (y_true_arr >= 0)
            & (y_true_arr < n_classes)
            & (y_pred_arr >= 0)
            & (y_pred_arr < n_classes)
        )
        if not bool(valid.any()):
            self.logger.warning(
                f"[{self.model_name}] Skipping {middle} report: no valid labels in [0, {n_classes - 1}]."
            )
            return

        dropped = int(valid.size - int(valid.sum()))
        if dropped > 0:
            self.logger.warning(
                f"[{self.model_name}] Dropping {dropped} out-of-range entries before {middle} report."
            )

        y_true_arr = y_true_arr[valid].astype(np.int64, copy=False)
        y_pred_arr = y_pred_arr[valid].astype(np.int64, copy=False)

        y_pred_proba_arr = None
        if y_pred_proba is not None:
            y_pred_proba_arr = np.asarray(y_pred_proba)
            if y_pred_proba_arr.ndim != 2:
                self.logger.warning(
                    f"[{self.model_name}] Ignoring probability matrix with invalid ndim={y_pred_proba_arr.ndim}."
                )
                y_pred_proba_arr = None
            elif y_pred_proba_arr.shape[0] != valid.size:
                self.logger.warning(
                    f"[{self.model_name}] Ignoring probability matrix with row mismatch: "
                    f"n_proba={y_pred_proba_arr.shape[0]}, n_labels={valid.size}."
                )
                y_pred_proba_arr = None
            else:
                y_pred_proba_arr = y_pred_proba_arr[valid]

        msg = f"{middle} Report (on {y_pred_arr.size} total genotypes)"
        self.logger.info(msg)

        if y_pred_proba_arr is not None:
            if self.show_plots:
                self.plotter_.plot_metrics(
                    y_true_arr,
                    y_pred_proba_arr,
                    metrics,
                    label_names=labels,
                    prefix=report_name,
                )

            if self.show_plots:
                self.plotter_.plot_confusion_matrix(
                    y_true_arr, y_pred_arr, label_names=labels, prefix=report_name
                )

        report: str | dict = classification_report(
            y_true_arr,
            y_pred_arr,
            labels=list(range(len(labels))),
            target_names=labels,
            zero_division=0,
            output_dict=True,
        )

        if not isinstance(report, dict):
            msg = "Expected classification_report to return a dict."
            self.logger.error(msg, exc_info=True)
            raise ValueError(msg)

        if self.show_plots:
            viz = ClassificationReportVisualizer(reset_kwargs=self.plotter_.param_dict)
            try:
                plots = viz.plot_all(
                    report,  # type: ignore
                    title_prefix=f"{self.model_name} {middle} Report",
                    show=self.show_plots,
                    heatmap_classes_only=True,
                )
            finally:
                viz._reset_mpl_style()

            for name, fig in plots.items():
                fout = (
                    self.plots_dir / f"{report_name}_report_{name}.{self.plot_format}"
                )
                if hasattr(fig, "savefig") and isinstance(fig, Figure):
                    fig.savefig(fout, dpi=300, facecolor="#111122")
                    plt.close(fig)
                elif hasattr(fig, "write_html") and isinstance(fig, go.Figure):
                    fout_html = fout.with_suffix(".html")
                    fig.write_html(file=fout_html)

                    SNPioMultiQC.queue_html(
                        fout_html,
                        panel_id=f"pgsui_{self.model_name.lower()}_{report_name}_radar",
                        section=f"PG-SUI: {self.model_name} Model Imputation",
                        title=f"{self.model_name} {middle} Radar Plot",
                        index_label=name,
                        description=f"{self.model_name} {middle} {len(labels)}-base Radar Plot. This radar plot visualizes model performance for three metrics per-class: precision, recall, and F1-score. Each axis represents one of these metrics, allowing for a quick visual assessment of the model's strengths and weaknesses. Higher values towards the outer edge indicate better performance.",
                    )

            if not self.is_haploid_:
                msg = f"Ploidy: {self.ploidy}. Evaluating per genotype (REF, HET, ALT)."
                self.logger.info(msg)

        report_full = self._additional_metrics(
            y_true_arr,
            y_pred_arr,
            labels=list(range(len(labels))),
            report_names=labels,
            report=report,
        )

        if self.verbose or self.debug:
            pm = PrettyMetrics(
                report_full,
                precision=2,
                title=f"{self.model_name} {middle} Report",
            )
            pm.render()

        with open(self.metrics_dir / f"{report_name}_report.json", "w") as f:
            json.dump(report_full, f, indent=4)

    def _convert_int_iupac_ploidy(
        self,
        X: np.ndarray,
        *,
        ploidy: int,
        encodings_dict: Optional[Mapping[str, int]] = None,
        ref: Optional[np.ndarray] = None,
        alt: Optional[np.ndarray] = None,
        ambiguity_mode: str = "ref_alt",
    ) -> np.ndarray:
        """Convert IUPAC genotype calls to integer encodings with ploidy-aware behavior.

        For diploid data (ploidy=2), preserves IUPAC ambiguity codes (W/R/M/K/Y/S) as distinct classes. For haploid data (ploidy=1), forbids heterozygous ambiguity codes and collapses them to A/C/G/T (or N) deterministically.

        Args:
            X (np.ndarray): IUPAC array of shape (N, L) or (L,) containing characters like
                A/C/G/T/W/R/M/K/Y/S/N (case-insensitive).
            ploidy (int): 1 for haploid, 2 for diploid.
            encodings_dict (Mapping[str, int] | None): Mapping from IUPAC char -> int.
                If None, a sensible default is used:
                - Diploid default: A,C,G,T,W,R,M,K,Y,S,N -> 0..9,-1
                - Haploid default: A,C,G,T,N -> 0..3,-1
            ref (np.ndarray | None): Optional per-locus REF alleles (shape (L,)). Used only when
                ploidy=1 and ambiguity_mode="ref_alt".
            alt (np.ndarray | None): Optional per-locus ALT alleles (shape (L,)). Used only when
                ploidy=1 and ambiguity_mode="ref_alt".
            ambiguity_mode (str): How to collapse ambiguity codes when ploidy=1:
                - "ref_alt": choose REF if the ambiguity contains REF else ALT if contains ALT else first-base
                - "first_base": deterministic map W->A, R->A, M->A, K->G, Y->C, S->C
                - "N": convert all ambiguity codes to N (-1)

        Returns:
            np.ndarray: Integer array with same shape as X.

        Raises:
            ValueError: If ploidy is not 1 or 2, or ambiguity_mode is invalid, or ref/alt shapes mismatch.
        """
        if int(ploidy) not in (1, 2):
            raise ValueError(f"ploidy must be 1 or 2; got {ploidy}.")

        Xc = np.asarray(X)
        if Xc.dtype.kind not in {"U", "S", "O"}:
            # If someone passes numeric, just return as-is after int cast
            return Xc.astype(np.int16, copy=False)

        # Normalize to uppercase single-character strings
        Xu = Xc.astype("U1", copy=False)
        Xu = np.char.upper(Xu)

        if ploidy == 2:
            # Preserve current behavior
            # (diploid, ambiguity codes are real classes)
            if encodings_dict is None:
                encodings_dict = {
                    "A": 0,
                    "C": 1,
                    "G": 2,
                    "T": 3,
                    "W": 4,
                    "R": 5,
                    "M": 6,
                    "K": 7,
                    "Y": 8,
                    "S": 9,
                    "N": -1,
                }
            return self._map_chars_to_int(Xu, encodings_dict)

        # ---- Haploid path: collapse ambiguities to A/C/G/T/N only ----
        if encodings_dict is None:
            encodings_dict = {"A": 0, "C": 1, "G": 2, "T": 3, "N": -1}

        if ambiguity_mode not in {"ref_alt", "first_base", "N"}:
            msg = f"Invalid ambiguity_mode: {ambiguity_mode!r}. Must be one of 'ref_alt', 'first_base', or 'N'."
            self.logger.error(msg)
            raise ValueError(msg)

        # Quick exit: if no ambiguity chars are present, just map A/C/G/T/N
        ambig_chars = np.array(["W", "R", "M", "K", "Y", "S"], dtype="U1")
        ambig_mask = np.isin(Xu, ambig_chars)
        if ambig_mask.any():
            Xu = Xu.copy()
            Xu[ambig_mask] = self._collapse_ambiguity_haploid(
                Xu[ambig_mask],
                full_matrix=Xu,
                ambig_mask=ambig_mask,
                ref=ref,
                alt=alt,
                mode=ambiguity_mode,
            )

        # Any remaining unknowns should be treated as N
        valid = np.isin(Xu, np.array(["A", "C", "G", "T", "N"], dtype="U1"))
        if not bool(valid.all()):
            Xu = Xu.copy()
            Xu[~valid] = "N"

        return self._map_chars_to_int(Xu, encodings_dict)

    def _sanitize_haploid_decoded_output(self, decoded: np.ndarray) -> np.ndarray:
        """Normalize haploid decoded calls to strict A/C/G/T/N.

        This is a safety pass for haploid outputs after ``decode_012``. Any ambiguity codes (W/R/M/K/Y/S) are collapsed using ``_convert_int_iupac_ploidy(..., ploidy=1, ambiguity_mode='ref_alt')`` and mapped back to single-base nucleotides.

        Args:
            decoded (np.ndarray): Decoded IUPAC calls, shape (N, L).

        Returns:
            np.ndarray: Sanitized calls with only A/C/G/T/N.
        """
        arr = np.asarray(decoded)
        if arr.ndim != 2:
            msg = (
                f"[{self.model_name}] Expected decoded haploid array to be 2D; got "
                f"shape={arr.shape}."
            )
            self.logger.error(msg)
            raise ValueError(msg)

        arr_u1 = arr.astype("<U1", copy=False)

        ref = getattr(self.genotype_data, "ref", None)
        alt = getattr(self.genotype_data, "alt", None)

        try:
            ints = self._convert_int_iupac_ploidy(
                arr_u1,
                ploidy=1,
                encodings_dict={"A": 0, "C": 1, "G": 2, "T": 3, "N": -1},
                ref=ref,
                alt=alt,
                ambiguity_mode="ref_alt",
            )
        except Exception as e:
            self.logger.warning(
                f"[{self.model_name}] Haploid decoded sanitization with ref/alt failed: {e}. "
                "Falling back to ambiguity collapse without ref/alt metadata."
            )
            ints = self._convert_int_iupac_ploidy(
                arr_u1,
                ploidy=1,
                encodings_dict={"A": 0, "C": 1, "G": 2, "T": 3, "N": -1},
                ref=None,
                alt=None,
                ambiguity_mode="ref_alt",
            )

        out = np.full(arr_u1.shape, "N", dtype="<U1")
        out[ints == 0] = "A"
        out[ints == 1] = "C"
        out[ints == 2] = "G"
        out[ints == 3] = "T"
        return out

    def _map_chars_to_int(
        self, Xu: np.ndarray, mapping: Mapping[str, int]
    ) -> np.ndarray:
        """Vectorized char->int mapping with safe fallback to N/-1."""
        # Build dense lookup table for ASCII A..Z plus fallback
        # This is fast and avoids Python loops.
        lut = np.full(256, -1, dtype=np.int16)
        for k, v in mapping.items():
            if not k:
                continue
            lut[ord(str(k).upper()[0])] = int(v)

        # Convert array of 'U1' to bytes of first char
        # Works for Xu dtype 'U1' or 'S1' after astype.
        xb = Xu.astype("S1", copy=False).view(np.uint8)
        out = lut[xb].astype(np.int16, copy=False)
        return out

    def _collapse_ambiguity_haploid(
        self,
        ambig_values: np.ndarray,
        *,
        full_matrix: np.ndarray,
        ambig_mask: np.ndarray,
        ref: Optional[np.ndarray],
        alt: Optional[np.ndarray],
        mode: str,
    ) -> np.ndarray:
        """Collapse ambiguity codes to haploid bases (A/C/G/T/N).

        Supports multiallelic ALT encodings (e.g., 'A,G' strings or list/tuple per locus) by deterministically selecting a single representative ALT base for haploid collapse.
        """
        if mode == "N":
            return np.full(ambig_values.shape, "N", dtype="U1")

        if mode == "first_base":
            first = {
                "W": "A",  # A/T
                "R": "A",  # A/G
                "M": "A",  # A/C
                "K": "G",  # G/T
                "Y": "C",  # C/T
                "S": "C",  # C/G
            }
            out = ambig_values.copy()
            for k, v in first.items():
                out[ambig_values == k] = v
            return out.astype("U1", copy=False)

        # mode == "ref_alt"
        if ref is None or alt is None:
            return self._collapse_ambiguity_haploid(
                ambig_values,
                full_matrix=full_matrix,
                ambig_mask=ambig_mask,
                ref=None,
                alt=None,
                mode="first_base",
            )

        # Canonicalize ref/alt to 1D single-base strings
        def _norm_base1(x) -> str:
            """Return single A/C/G/T base else 'N'."""
            b = str(x).upper()[:1]
            return b if b in {"A", "C", "G", "T"} else "N"

        def _first_allele_base(x) -> str:
            """Extract a single representative ALT base from multi-allelic encodings.

            Accepts:
            - "A,G" -> "A"
            - ["A","G"] -> "A"
            - ("A","G") -> "A"
            - np.ndarray([...]) -> first element
            - anything else -> first character of string representation
            Then normalizes to A/C/G/T or N.
            """
            if x is None:
                return "N"

            # list/tuple/ndarray of alleles
            if isinstance(x, (list, tuple, np.ndarray)):
                if len(x) == 0:
                    return "N"
                return _norm_base1(x[0])

            # strings like "A,G" or "A"
            s = str(x).upper()
            if "," in s:
                s = s.split(",", 1)[0]
            return _norm_base1(s)

        # Build clean 1D arrays (Python pass is required for ragged ALT)
        ref_list = list(ref) if not isinstance(ref, list) else ref
        alt_list = list(alt) if not isinstance(alt, list) else alt

        if len(ref_list) != len(alt_list):
            raise ValueError(
                f"ref/alt must have same length; got len(ref)={len(ref_list)}, len(alt)={len(alt_list)}."
            )

        ref_norm = np.array([_norm_base1(x) for x in ref_list], dtype="U1")
        alt_norm = np.array([_first_allele_base(x) for x in alt_list], dtype="U1")

        # Identify (row,col) for ambiguity cells
        rr, cc = np.where(ambig_mask)
        if rr.size == 0:
            return ambig_values.astype("U1", copy=False)

        amb = full_matrix[rr, cc].astype("U1", copy=False)

        contains = {
            "W": ("A", "T"),
            "R": ("A", "G"),
            "M": ("A", "C"),
            "K": ("G", "T"),
            "Y": ("C", "T"),
            "S": ("C", "G"),
        }

        out = amb.copy()
        for code, (b1, b2) in contains.items():
            m = amb == code
            if not bool(m.any()):
                continue

            rloc = ref_norm[cc[m]]
            aloc = alt_norm[cc[m]]

            choose_ref = (rloc == b1) | (rloc == b2)
            choose_alt = (~choose_ref) & ((aloc == b1) | (aloc == b2))

            out[m] = np.where(
                choose_ref,
                rloc,
                np.where(choose_alt, aloc, b1),  # fallback: deterministic first base
            )

        valid = np.isin(out, np.array(["A", "C", "G", "T"], dtype="U1"))
        if not bool(valid.all()):
            out[~valid] = "N"

        return out.astype("U1", copy=False)

    def _canonicalize_ref_alt_single_base(
        self,
        ref: Any,
        alt: Any,
        *,
        L: int,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Return (ref_s, alt_s) as (L,) arrays of single bases 'A/C/G/T/N'.

        Args:
            ref (Any): REF metadata (array-like length L).
            alt (Any): ALT metadata (array-like length L; may be ragged per locus).
            L (int): Number of loci/features.

        Returns:
            (ref_s, alt_s): Two arrays of dtype '<U1' and shape (L,).

        Notes:
            Handles multiallelic ALT encodings:
                - ALT per locus as list/tuple/np.ndarray (ragged): takes the first valid base allele
                - ALT per locus as string "A,G": takes first token before comma that is a valid base
                - Scalars: takes first character

        Raises:
            ValueError: If lengths are incompatible with L.
        """

        def _norm_base1(x: Any) -> str:
            b = str(x).upper()[:1]
            return b if b in {"A", "C", "G", "T"} else "N"

        def _alt_first_valid_base(x: Any) -> str:
            """Pick a single representative ALT base from multiallelic encodings."""
            if x is None:
                return "N"

            # Ragged list/tuple/ndarray of alleles: pick first valid A/C/G/T if possible.
            if isinstance(x, (list, tuple, np.ndarray)):
                if len(x) == 0:
                    return "N"
                for a in x:
                    b = _norm_base1(a)
                    if b != "N":
                        return b
                return "N"

            # Strings like "A,G" or "A"
            s = str(x).upper()
            if "," in s:
                # Prefer first valid allele in the comma-delimited list
                for tok in s.split(","):
                    b = _norm_base1(tok)
                    if b != "N":
                        return b
                return "N"

            return _norm_base1(s)

        ref_list = list(ref) if not isinstance(ref, list) else ref
        alt_list = list(alt) if not isinstance(alt, list) else alt

        if len(ref_list) != L or len(alt_list) != L:
            raise ValueError(
                f"[{self.model_name}] ref/alt length mismatch: expected L={L}, "
                f"got len(ref)={len(ref_list)}, len(alt)={len(alt_list)}."
            )

        ref_s = np.array([_norm_base1(x) for x in ref_list], dtype="<U1")
        alt_s = np.array([_alt_first_valid_base(x) for x in alt_list], dtype="<U1")
        return ref_s, alt_s

    def _compute_hidden_layer_sizes(
        self,
        n_inputs: int,
        n_outputs: int,
        n_samples: int,
        n_hidden: int,
        latent_dim: int,
        *,
        alpha: float = 4.0,
        schedule: str = "pyramid",
        min_size: int = 16,
        max_size: int | None = None,
        multiple_of: int = 8,
        decay: float | None = None,
        cap_by_inputs: bool = True,
    ) -> list[int]:
        """Compute hidden layer sizes given problem scale and a layer count.

        Notes:
            - Returns sizes for *hidden layers only* (length = n_hidden).
            - Does NOT include the input layer (n_inputs) or the latent layer (latent_dim).
            - Enforces a latent-aware minimum: one discrete level above latent_dim, where a level is `multiple_of`.
            - Enforces *strictly decreasing* hidden sizes (no repeats). This may require bumping `base` upward.

        Args:
            n_inputs: Number of input features (e.g., flattened one-hot: num_features * num_classes).
            n_outputs: Number of output classes (often equals num_classes).
            n_samples: Number of training samples.
            n_hidden: Number of hidden layers (excluding input and latent layers).
            latent_dim: Latent dimensionality (not returned, used only to set a floor).
            alpha: Scaling factor for base layer size.
            schedule: Size schedule ("pyramid" or "linear").
            min_size: Minimum layer size floor before latent-aware adjustment.
            max_size: Maximum layer size cap. If None, a heuristic cap is used.
            multiple_of: Hidden sizes are multiples of this value.
            decay: Pyramid decay factor. If None, computed to land near the target.
            cap_by_inputs: If True, cap layer sizes to n_inputs.

        Returns:
            list[int]: Hidden layer sizes (len = n_hidden).

        Raises:
            ValueError: On invalid arguments or conflicting constraints.
        """
        # Basic validation
        if n_hidden < 0:
            msg = f"n_hidden must be >= 0, got {n_hidden}."
            self.logger.error(msg)
            raise ValueError(msg)

        if n_hidden == 0:
            return []

        if n_inputs <= 0:
            msg = f"n_inputs must be > 0, got {n_inputs}."
            self.logger.error(msg)
            raise ValueError(msg)

        if n_outputs <= 0:
            msg = f"n_outputs must be > 0, got {n_outputs}."
            self.logger.error(msg)
            raise ValueError(msg)

        if n_samples <= 0:
            msg = f"n_samples must be > 0, got {n_samples}."
            self.logger.error(msg)
            raise ValueError(msg)

        if latent_dim <= 0:
            msg = f"latent_dim must be > 0, got {latent_dim}."
            self.logger.error(msg)
            raise ValueError(msg)

        if multiple_of <= 0:
            msg = f"multiple_of must be > 0, got {multiple_of}."
            self.logger.error(msg)
            raise ValueError(msg)

        if alpha <= 0:
            msg = f"alpha must be > 0, got {alpha}."
            self.logger.error(msg)
            raise ValueError(msg)

        schedule = str(schedule).lower().strip()
        if schedule not in {"pyramid", "linear"}:
            msg = f"Invalid schedule '{schedule}'. Must be 'pyramid' or 'linear'."
            self.logger.error(msg)
            raise ValueError(msg)

        # Latent-aware minimum floor
        # Smallest multiple_of strictly greater than latent_dim
        min_hidden_floor = int(np.ceil((latent_dim + 1) / multiple_of) * multiple_of)
        effective_min = max(int(min_size), min_hidden_floor)

        if cap_by_inputs and n_inputs < effective_min:
            msg = (
                "Cannot satisfy latent-aware minimum hidden size with cap_by_inputs=True. "
                f"Required hidden size >= {effective_min} (one level above latent_dim={latent_dim}), "
                f"but n_inputs={n_inputs}. Set cap_by_inputs=False or reduce latent_dim/multiple_of."
            )
            self.logger.error(msg)
            raise ValueError(msg)

        # Infer num_features
        # (if using flattened one-hot: n_inputs = num_features * num_classes)
        if n_inputs % n_outputs == 0:
            num_features = n_inputs // n_outputs
        else:
            num_features = n_inputs
            self.logger.warning(
                "n_inputs is not divisible by n_outputs; falling back to num_features=n_inputs "
                f"(n_inputs={n_inputs}, n_outputs={n_outputs}). If using one-hot flattening, "
                "pass n_outputs=num_classes so num_features can be inferred correctly."
            )

        # Base size heuristic
        # (feature-matrix aware; avoids collapse for huge n_inputs)
        # Conservative scaling: depends on sample size,
        # but also grows slowly with feature count.
        feature_factor = float(np.sqrt(np.log1p(float(num_features))))
        base = int(np.ceil(float(alpha) * np.sqrt(float(n_samples)) * feature_factor))

        # Determine max_size
        if max_size is None:
            max_size = max(int(n_inputs), int(base), int(effective_min))

        if cap_by_inputs:
            max_size = min(int(max_size), int(n_inputs))
        else:
            max_size = int(max_size)

        if max_size < effective_min:
            msg = (
                f"max_size ({max_size}) must be >= effective_min ({effective_min}), where effective_min "
                f"is max(min_size={min_size}, one-level-above latent_dim={latent_dim})."
            )
            self.logger.error(msg)
            raise ValueError(msg)

        # Round base up to a multiple and clip to bounds
        base = int(np.clip(base, effective_min, max_size))
        base = int(np.ceil(base / multiple_of) * multiple_of)
        base = int(np.clip(base, effective_min, max_size))

        # Enforce "no repeats" feasibility in discrete levels
        # Need n_hidden distinct multiples between base and effective_min:
        # base >= effective_min + (n_hidden - 1) * multiple_of
        required_min_base = effective_min + (n_hidden - 1) * multiple_of

        if required_min_base > max_size:
            msg = (
                "Cannot build strictly-decreasing (no-repeat) hidden sizes under current constraints. "
                f"Need base >= {required_min_base} to fit n_hidden={n_hidden} distinct layers "
                f"with multiple_of={multiple_of} down to effective_min={effective_min}, "
                f"but max_size={max_size}. Reduce n_hidden, reduce multiple_of, lower latent_dim/min_size, "
                "or increase max_size / set cap_by_inputs=False."
            )
            self.logger.error(msg)
            raise ValueError(msg)

        if base < required_min_base:
            # Bump base upward so a strict staircase is possible
            base = required_min_base
            base = int(np.ceil(base / multiple_of) * multiple_of)
            base = int(np.clip(base, effective_min, max_size))

        # Work in "levels" of multiple_of for guaranteed uniqueness
        start_level = base // multiple_of
        end_level = effective_min // multiple_of

        # Sanity: distinct levels available
        if (start_level - end_level) < (n_hidden - 1):
            # This should not happen due to required_min_base logic, but keep a hard guard.
            msg = (
                "Internal constraint failure: insufficient discrete levels to enforce no repeats. "
                f"start_level={start_level}, end_level={end_level}, n_hidden={n_hidden}."
            )
            self.logger.error(msg)
            raise ValueError(msg)

        # Build schedule in level space (integers), then convert to sizes
        if n_hidden == 1:
            levels = np.array([start_level], dtype=int)

        elif schedule == "linear":
            # Linear interpolation in level space, then strictify
            levels = np.round(np.linspace(start_level, end_level, num=n_hidden)).astype(
                int
            )

            # Enforce bounds then strict decrease
            levels = np.clip(levels, end_level, start_level)

            for i in range(1, n_hidden):
                if levels[i] >= levels[i - 1]:
                    levels[i] = levels[i - 1] - 1

            if levels[-1] < end_level:
                msg = (
                    "Failed to enforce strictly-decreasing linear schedule without violating the floor. "
                    f"(levels[-1]={levels[-1]} < end_level={end_level}). "
                    "Reduce n_hidden or multiple_of, or increase max_size."
                )
                self.logger.error(msg)
                raise ValueError(msg)

            # Force exact floor at the end (still strict because we have enough room by construction)
            levels[-1] = end_level
            for i in range(n_hidden - 2, -1, -1):
                if levels[i] <= levels[i + 1]:
                    levels[i] = levels[i + 1] + 1

            if levels[0] > start_level:
                # If this happens, we would need an even larger base;
                # handle by raising base once.
                needed_base = int(levels[0] * multiple_of)
                if needed_base > max_size:
                    msg = (
                        "Cannot enforce strictly-decreasing linear schedule after floor anchoring; "
                        f"would require base={needed_base} > max_size={max_size}."
                    )
                    self.logger.error(msg)
                    raise ValueError(msg)
                # Rebuild with bumped base
                start_level = needed_base // multiple_of
                levels = np.arange(start_level, start_level - n_hidden, -1, dtype=int)
                levels[-1] = end_level  # keep floor
                # Ensure strict with backward adjust
                for i in range(n_hidden - 2, -1, -1):
                    if levels[i] <= levels[i + 1]:
                        levels[i] = levels[i + 1] + 1

        elif schedule == "pyramid":
            # Geometric decay in level space
            # (more aggressive early taper than linear)
            if decay is not None:
                dcy = float(decay)
            else:
                # Choose decay to land exactly at end_level (in float space)
                dcy = (float(end_level) / float(start_level)) ** (
                    1.0 / float(n_hidden - 1)
                )

            # Keep it in a sensible range
            dcy = float(np.clip(dcy, 0.05, 0.99))

            exponents = np.arange(n_hidden, dtype=float)
            levels_float = float(start_level) * (dcy**exponents)

            levels = np.round(levels_float).astype(int)
            levels = np.clip(levels, end_level, start_level)

            # Anchor the last layer at the floor, then strictify backward
            levels[-1] = end_level
            for i in range(n_hidden - 2, -1, -1):
                if levels[i] <= levels[i + 1]:
                    levels[i] = levels[i + 1] + 1

            # If we overshot the start,
            # bump base (once) if possible, then rebuild
            if levels[0] > start_level:
                needed_base = int(levels[0] * multiple_of)
                if needed_base > max_size:
                    msg = (
                        "Cannot enforce strictly-decreasing pyramid schedule; "
                        f"would require base={needed_base} > max_size={max_size}."
                    )
                    self.logger.error(msg)
                    raise ValueError(msg)

                start_level = needed_base // multiple_of
                # Recompute with new start_level and same decay
                # (or recompute decay if decay is None)
                if decay is None:
                    dcy = (float(end_level) / float(start_level)) ** (
                        1.0 / float(n_hidden - 1)
                    )
                    dcy = float(np.clip(dcy, 0.05, 0.99))

                levels_float = float(start_level) * (dcy**exponents)
                levels = np.round(levels_float).astype(int)
                levels = np.clip(levels, end_level, start_level)
                levels[-1] = end_level
                for i in range(n_hidden - 2, -1, -1):
                    if levels[i] <= levels[i + 1]:
                        levels[i] = levels[i + 1] + 1

        else:
            msg = f"Unknown schedule '{schedule}'. Use 'pyramid' or 'linear' (constant disallowed with no repeats)."
            self.logger.error(msg)
            raise ValueError(msg)

        # Convert levels -> sizes
        sizes = (levels * multiple_of).astype(int)

        # Final clip (should be redundant, but safe)
        sizes = np.clip(sizes, effective_min, max_size).astype(int)

        # Final strict no-repeat assertion
        if np.any(np.diff(sizes) >= 0):
            msg = f"Internal error: produced non-decreasing or repeated hidden sizes after strict enforcement. sizes={sizes.tolist()}"
            self.logger.error(msg)
            raise ValueError(msg)

        self.logger.debug(f"Final hidden layer sizes: {sizes.tolist()}")

        return sizes.tolist()

    def _class_weights_from_zygosity(
        self,
        X: np.ndarray,
        train_mask: Optional[np.ndarray] = None,
        *,
        inverse: bool = False,
        normalize: bool = False,
        power: float = 1.0,
        max_ratio: float | None = None,
        eps: float = 1e-12,
    ) -> torch.Tensor:
        """Compute class weights for zygosity labels.

        If inverse=False (default):
            w_c = N / (K * n_c)   ("balanced")

        If inverse=True:
            w_c = N / n_c         (same ratios, scaled by K)

        If power != 1.0:
            w_c <- w_c ** power   (amplifies or softens imbalance handling)

        If normalize=True:
            rescales nonzero weights so mean(nonzero_weights) == 1.

        Returns:
            torch.Tensor: Class weights of shape (num_classes,) on self.device.
        """
        y = np.asarray(X).ravel().astype(np.int8)

        m = y >= 0
        if train_mask is not None:
            tm = np.asarray(train_mask, dtype=bool).ravel()
            if tm.shape != y.shape:
                msg = "train_mask must have the same shape as X."
                self.logger.error(msg)
                raise ValueError(msg)
            m &= tm

        is_hap = bool(getattr(self, "is_haploid_", False))
        num_classes = 2 if is_hap else int(self.num_classes_)

        if not np.any(m):
            return torch.ones(num_classes, dtype=torch.float32).to(self.device)

        if is_hap:
            y = y.copy()
            y[(y > 0) & m] = 1

        y_m = y[m]
        if y_m.size:
            ymin = int(y_m.min())
            ymax = int(y_m.max())
            if ymin < 0 or ymax >= num_classes:
                msg = (
                    f"Found out-of-range labels under mask: min={ymin}, max={ymax}, "
                    f"expected in [0, {num_classes - 1}]."
                )
                self.logger.error(msg)
                raise ValueError(msg)

        counts = np.bincount(y_m, minlength=num_classes).astype(np.float32)
        N = float(counts.sum())
        K = float(num_classes)

        w = np.zeros(num_classes, dtype=np.float32)
        nz = counts > 0

        if np.any(nz):
            if inverse:
                w[nz] = N / (counts[nz] + eps)
            else:
                w[nz] = N / (K * (counts[nz] + eps))

            # Amplify / soften class contrast
            if power <= 0.0:
                msg = "power must be > 0."
                self.logger.error(msg)
                raise ValueError(msg)
            if power != 1.0:
                w[nz] = np.power(w[nz], power)

        if np.any(~nz):
            self.logger.warning(
                "Some classes have zero count under the provided mask: "
                f"{np.where(~nz)[0].tolist()}. Setting their weights to 0."
            )

        # Cap ratio among observed classes
        if max_ratio is not None and np.any(nz):
            cap = float(max_ratio)
            if cap <= 1.0:
                msg = "max_ratio must be > 1.0 or None."
                self.logger.error(msg)
                raise ValueError(msg)

            wmin = max(float(w[nz].min()), eps)
            wmax = wmin * cap
            w[nz] = np.clip(w[nz], wmin, wmax)

        # Optional normalization: mean(nonzero) -> 1.0
        if normalize and np.any(nz):
            mean_nz = float(w[nz].mean())
            if mean_nz > 0.0:
                w[nz] /= mean_nz
            else:
                self.logger.warning(
                    "normalize=True requested, but mean of nonzero weights is negative or zero; skipping normalization."
                )

        self.logger.debug(f"Class counts: {counts.astype(np.int64)}")
        self.logger.debug(
            f"Class weights (inverse={inverse}, power={power}, normalize={normalize}): {w}"
        )

        return torch.as_tensor(w, dtype=torch.float32).to(self.device)

    def _one_hot_encode_012(
        self, X: np.ndarray | torch.Tensor, num_classes: int | None
    ) -> torch.Tensor:
        """One-hot encode genotype calls. Missing inputs (<0) result in a vector of -1 values.

        Args:
            X (np.ndarray | torch.Tensor): Input genotype calls as integers (0,1, 2, etc.).
            num_classes (int | None): Number of classes (K). If None, uses self.num_classes_.

        Returns:
            torch.Tensor: One-hot encoded tensor of shape (B, L, K) with dtype
                ``torch.int``. Valid calls are 0/1, missing calls are all -1.

        Notes:
            - Valid classes must be integers in [0, K-1]
            - Missing is any value < 0; these positions become [-1, -1, ..., -1]
            - If K==2 (Haploid), any value >= 1 is mapped to 1 (0=Ref, 1=Alt).
        """
        Xt = (
            torch.from_numpy(X).to(self.device)
            if isinstance(X, np.ndarray)
            else X.to(self.device)
        )

        # Make sure we have integer class labels
        if Xt.dtype.is_floating_point:
            # Convert NaN -> -1 and cast to int
            Xt = torch.nan_to_num(Xt, nan=-1.0).int()
        else:
            Xt = Xt.int()

        B, L = Xt.shape
        K = int(num_classes) if num_classes is not None else int(self.num_classes_)

        # Missing is anything < 0 (covers -1, -9, etc.)
        valid = Xt >= 0

        # --- Haploidization ---
        # If binary mode (K=2), we force all non-ref variants (1, 2, etc.) to 1.
        # This handles inputs like {0, 2} (HomAlt encoded) OR {0, 1, 2} (Diploid encoded).
        if K == 2:
            mask_gt1 = valid & (Xt > 1)
            if torch.any(mask_gt1):
                Xt = Xt.clone()
                Xt[mask_gt1] = 1

        # Enforce the one-hot precondition
        if torch.any(valid & (Xt >= K)):
            bad_vals = torch.unique(Xt[valid & (Xt >= K)]).detach().cpu().tolist()
            all_vals = torch.unique(Xt[valid]).detach().cpu().tolist()
            msg = f"_one_hot_encode_012 received class values outside [0, {K-1}]. num_classes={K}, offending_values={bad_vals}, observed_values={all_vals}. Upstream encoding mismatch (e.g., passing 0/1/2 with num_classes=2)."
            self.logger.error(msg)
            raise ValueError(msg)

        # Initialize with -1 to ensure missing values are represented
        X_ohe = torch.full((B, L, K), -1).long().to(self.device)

        idx = Xt[valid].long()

        if idx.numel() > 0:
            # Overwrite valid positions with the correct one-hot vectors
            X_ohe[valid] = F.one_hot(idx, num_classes=K).long()

        self.logger.debug(
            f"_one_hot_encode_012: input shape {X.shape} -> output shape {X_ohe.shape}"
        )

        return X_ohe

    def decode_012(
        self, X: np.ndarray | pd.DataFrame | list[list[int]], is_nuc: bool = False
    ) -> np.ndarray:
        """Decode 012-encodings to IUPAC chars with metadata repair.

        Supports:
        - is_nuc=True: direct 0..9 -> IUPAC mapping
        - is_nuc=False: ref/alt-based decoding with metadata repair

        Additional behavior:
        - Multiallelic ALT is allowed. The ALT used for decoding is chosen as the
            most common alternate base (A/C/G/T) observed in the source SNP column.
        - If REF/ALT are missing or ambiguous, they are inferred from observed
            base counts in the source SNP column (if available).

        Returns:
            np.ndarray: IUPAC strings as a 2D array of shape (n_samples, n_snps).
        """
        df = validate_input_type(X, return_type="df")
        if not isinstance(df, pd.DataFrame):
            msg = f"Expected a pandas.DataFrame in 'decode_012', but got: {type(df)}."
            self.logger.error(msg)
            raise ValueError(msg)

        # IUPAC Definitions
        iupac_to_bases: dict[str, set[str]] = {
            "A": {"A"},
            "C": {"C"},
            "G": {"G"},
            "T": {"T"},
            "R": {"A", "G"},
            "Y": {"C", "T"},
            "S": {"G", "C"},
            "W": {"A", "T"},
            "K": {"G", "T"},
            "M": {"A", "C"},
            "B": {"C", "G", "T"},
            "D": {"A", "G", "T"},
            "H": {"A", "C", "T"},
            "V": {"A", "C", "G"},
            "N": set(),
        }
        bases_to_iupac = {
            frozenset(v): k for k, v in iupac_to_bases.items() if k != "N"
        }
        missing_codes = {"", ".", "N", "NONE", "-", "?", "./.", ".|.", "NAN", "nan"}

        def _normalize_iupac(value: object) -> str | None:
            """Normalize an input into a single IUPAC code token or None."""
            if value is None:
                return None
            if isinstance(value, (bytes, np.bytes_)):
                value = bytes(value).decode("utf-8", errors="ignore")

            if isinstance(value, (list, tuple, pd.Series, np.ndarray)):
                if isinstance(value, pd.Series):
                    arr = value.to_numpy()
                else:
                    arr = value
                if isinstance(arr, np.ndarray) and arr.ndim == 0:
                    return _normalize_iupac(arr.item())
                if len(arr) == 0:
                    return None
                for item in arr:
                    code = _normalize_iupac(item)
                    if code is not None:
                        return code
                return None

            s = str(value).upper().strip()
            if not s or s in missing_codes:
                return None

            if "," in s:
                for tok in (t.strip() for t in s.split(",")):
                    if tok and tok not in missing_codes and tok in iupac_to_bases:
                        return tok
                return None

            return s if s in iupac_to_bases else None

        def _extract_candidates(value: object) -> list[str]:
            """Extract all candidate IUPAC tokens from multiallelic/list-like metadata."""
            if value is None:
                return []

            if isinstance(value, (bytes, np.bytes_)):
                value = bytes(value).decode("utf-8", errors="ignore")

            # list-like: flatten
            if isinstance(value, (list, tuple, pd.Series, np.ndarray)):
                if isinstance(value, pd.Series):
                    seq = value.to_numpy()
                else:
                    seq = value
                out: list[str] = []
                for item in seq:
                    out.extend(_extract_candidates(item))
                return out

            s = str(value).upper().strip()
            if not s or s in missing_codes:
                return []

            toks = [t.strip() for t in s.split(",")] if "," in s else [s]
            out: list[str] = []
            for tok in toks:
                if not tok or tok in missing_codes:
                    continue
                if tok in iupac_to_bases:
                    out.append(tok)
            return out

        def _base_counts_from_column(
            col: np.ndarray, *, max_scan: int = 5000
        ) -> dict[str, int]:
            """Count A/C/G/T from a source SNP column of IUPAC codes.

            Counting rule:
            - Homozygote (single-base) contributes +2 to that base
            - Heterozygote/ambiguity contributes +1 to each base in the set
            """
            counts = {"A": 0, "C": 0, "G": 0, "T": 0}
            seen = 0
            for val in col:
                code = _normalize_iupac(val)
                if code is None or code == "N":
                    continue
                bases = iupac_to_bases.get(code, set())
                if not bases:
                    continue
                if len(bases) == 1:
                    b = next(iter(bases))
                    if b in counts:
                        counts[b] += 2
                else:
                    for b in bases:
                        if b in counts:
                            counts[b] += 1
                seen += 1
                if seen >= max_scan:
                    break
            return counts

        def _choose_single_base(
            token: str | None, counts: dict[str, int]
        ) -> str | None:
            """If token is ambiguous, pick the most frequent constituent base; else return token."""
            if token is None:
                return None
            bases = iupac_to_bases.get(token, set())
            if not bases:
                return None
            if len(bases) == 1:
                b = next(iter(bases))
                return b if b in {"A", "C", "G", "T"} else token
            # Ambiguous: choose most common base in observed counts
            best = None
            best_ct = -1
            for b in bases:
                ct = counts.get(b, 0)
                if ct > best_ct:
                    best_ct = ct
                    best = b
            return best if best in {"A", "C", "G", "T"} else None

        def _choose_alt_from_candidates(
            ref_base: str | None,
            alt_candidates: list[str],
            counts: dict[str, int],
        ) -> str | None:
            """Pick ALT as the most common base among candidates, excluding REF."""
            # Reduce candidates to base set
            base_cands: set[str] = set()
            for tok in alt_candidates:
                bases = iupac_to_bases.get(tok, set())
                for b in bases:
                    if b in {"A", "C", "G", "T"}:
                        base_cands.add(b)

            if ref_base in base_cands:
                base_cands.remove(ref_base)

            if not base_cands:
                return None

            # Most common by counts; deterministic tie-breaker by base order
            order = {"A": 0, "C": 1, "G": 2, "T": 3}
            best = max(base_cands, key=lambda b: (counts.get(b, 0), -order[b]))
            return best

        # numeric codes
        codes_df = df.apply(pd.to_numeric, errors="coerce")
        codes = codes_df.fillna(-1).astype(np.int8).to_numpy()
        n_rows, n_cols = codes.shape

        if is_nuc:
            iupac_list = np.array(
                ["A", "C", "G", "T", "W", "R", "M", "K", "Y", "S"], dtype="<U1"
            )
            out = np.full((n_rows, n_cols), "N", dtype="<U1")
            mask = (codes >= 0) & (codes <= 9)
            out[mask] = iupac_list[codes[mask]]
            return out

        # Metadata fetch
        ref_alleles = getattr(self.genotype_data, "ref", [])
        alt_alleles = getattr(self.genotype_data, "alt", [])

        if len(ref_alleles) != n_cols:
            ref_alleles = getattr(self, "_ref", [None] * n_cols)
        if len(alt_alleles) != n_cols:
            alt_alleles = getattr(self, "_alt", [None] * n_cols)

        if len(ref_alleles) != n_cols:
            ref_alleles = [None] * n_cols
        if len(alt_alleles) != n_cols:
            alt_alleles = [None] * n_cols

        out = np.full((n_rows, n_cols), "N", dtype="<U1")

        # Lazy-load source SNP data once
        source_snp_data = None
        if getattr(self.genotype_data, "snp_data", None) is not None:
            try:
                source_snp_data = np.asarray(self.genotype_data.snp_data)
            except Exception:
                source_snp_data = None

        for j in range(n_cols):
            ref_tok = _normalize_iupac(ref_alleles[j])
            alt_toks = _extract_candidates(alt_alleles[j])  # multiallelic-safe

            # Column base counts (if we have source data)
            counts = {"A": 0, "C": 0, "G": 0, "T": 0}
            if (
                source_snp_data is not None
                and source_snp_data.ndim == 2
                and source_snp_data.shape[1] > j
            ):
                try:
                    counts = _base_counts_from_column(source_snp_data[:, j])
                except Exception:
                    counts = {"A": 0, "C": 0, "G": 0, "T": 0}

            # Canonicalize REF to a single base if possible
            ref_base = _choose_single_base(ref_tok, counts)

            # Choose ALT:
            #  - if multiallelic candidates exist, pick most common base among them
            #  - else if single ALT token exists, canonicalize it
            alt_base = None
            if alt_toks:
                alt_base = _choose_alt_from_candidates(ref_base, alt_toks, counts)
                if alt_base is None and len(alt_toks) == 1:
                    alt_base = _choose_single_base(alt_toks[0], counts)
            else:
                # no ALT candidates in metadata
                alt_base = None

            # --- REPAIR LOGIC (frequency-aware) ---
            # If still missing, infer from observed counts in source column:
            if (ref_base is None or alt_base is None) and any(
                v > 0 for v in counts.values()
            ):
                # Sort bases by count desc, then A/C/G/T deterministic
                order = {"A": 0, "C": 1, "G": 2, "T": 3}
                ranked = sorted(counts.keys(), key=lambda b: (-counts[b], order[b]))
                if ref_base is None:
                    ref_base = ranked[0]
                if alt_base is None:
                    alt_base = next(
                        (b for b in ranked if b != ref_base and counts[b] > 0), None
                    )

            # --- DEFAULTS FOR MISSING ---
            if ref_base is None and alt_base is None:
                ref_base = "N"
                alt_base = "N"
            elif ref_base is None:
                ref_base = alt_base if alt_base is not None else "N"
            elif alt_base is None:
                # Monomorphic or truly no alt info -> treat as ref
                alt_base = ref_base

            ref = ref_base
            alt = alt_base

            # --- COMPUTE HET CODE ---
            if ref == alt:
                het_code = ref
            else:
                union_set = frozenset({ref, alt})
                het_code = bases_to_iupac.get(union_set, "N")

            col_codes = codes[:, j]

            # Case 0: REF
            if ref != "N":
                out[col_codes == 0, j] = ref

            # Case 1: HET
            if het_code != "N":
                out[col_codes == 1, j] = het_code
            else:
                # fallback to REF if het is not representable
                if ref != "N":
                    out[col_codes == 1, j] = ref

            # Case 2: ALT
            if alt != "N":
                out[col_codes == 2, j] = alt
            else:
                if ref != "N":
                    out[col_codes == 2, j] = ref

        return out

    def _sanitize_for_json(self, obj) -> dict | list:
        """Recursively remove non-JSON-serializable objects (e.g., torch.Tensors)."""
        if isinstance(obj, dict):
            return {
                k: self._sanitize_for_json(v)
                for k, v in obj.items()
                if not isinstance(v, (torch.Tensor, torch.device)) and k != "debug"
            }
        elif isinstance(obj, (list, tuple)):
            return [
                self._sanitize_for_json(v)
                for v in obj
                if not isinstance(v, (torch.Tensor, torch.device)) and v != "debug"
            ]
        return obj

    def _save_best_params(
        self, best_params: dict[str, Any], objective_mode: bool = False
    ) -> None:
        """Save the best hyperparameters to a JSON file.

        This method saves the best hyperparameters found during hyperparameter tuning to a JSON file in the optimization directory. The filename includes the model name for easy identification.

        Args:
            best_params (dict[str, Any]): A dictionary of the best hyperparameters to save.
        """
        if not hasattr(self, "parameters_dir"):
            msg = "Attribute 'parameters_dir' not found. Ensure _create_model_directories() has been called."
            self.logger.error(msg)
            raise AttributeError(msg)

        if objective_mode:
            fout = self.optimize_dir / "parameters" / "best_tuned_parameters.json"
        else:
            fout = self.parameters_dir / "best_parameters.json"

        fout.parent.mkdir(parents=True, exist_ok=True)

        # Create the clean dictionary
        bp = self._sanitize_for_json(best_params)

        if not isinstance(bp, dict):
            msg = "Best parameters must be a dictionary after sanitization."
            self.logger.error(msg)
            raise TypeError(msg)

        with open(fout, "w") as f:
            json.dump(bp, f, indent=4)

    def _set_best_params(
        self, params: dict[str, Any], objective_mode: bool = False
    ) -> dict[str, Any]:
        """An abstract method for setting best parameters."""
        raise NotImplementedError

    def sim_missing_transform(
        self, X: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Simulate missing data according to the specified strategy.

        Args:
            X (np.ndarray): Genotype matrix to simulate missing data on.

        Returns:
            X_for_model (np.ndarray): Genotype matrix with simulated missing data.
            sim_mask (np.ndarray): Boolean mask of simulated missing entries.
            orig_mask (np.ndarray): Boolean mask of original missing entries.
        """
        if (
            not hasattr(self, "sim_prop")
            or self.sim_prop <= 0.0
            or self.sim_prop >= 1.0
        ):
            msg = f"sim_prop must be set and between 0.0 and 1.0, but got: {self.sim_prop}."
            self.logger.error(msg)
            raise AttributeError(msg)

        if not hasattr(self, "tree_parser") and "nonrandom" in self.sim_strategy:
            msg = f"tree_parser must be set to use 'nonrandom' or 'nonrandom_weighted' sim_strategy, but got: {getattr(self, 'tree_parser', None)}."
            self.logger.error(msg)
            raise AttributeError(msg)

        # --- Simulate missing data ---
        X_for_sim = X.astype(np.float32, copy=True)

        self.logger.debug(
            f"Simulating missing data with strategy: {self.sim_strategy}, proportion: {self.sim_prop}"
        )

        self.logger.debug(f"Input data shape for simulation: {X_for_sim.shape}")

        tr = SimMissingTransformer(
            genotype_data=self.genotype_data,
            tree_parser=self.tree_parser,
            prop_missing=self.sim_prop,
            strategy=self.sim_strategy,
            missing_val=-1,
            mask_missing=True,
            verbose=self.verbose,
            seed=self.seed,
            **self.sim_kwargs,
        )
        tr.fit(X_for_sim.copy())
        X_for_model = tr.transform(X_for_sim.copy())
        sim_mask = tr.sim_missing_mask_.astype(bool)
        orig_mask = tr.original_missing_mask_.astype(bool)

        self.logger.debug(f"Simulated data shape: {X_for_model.shape}")
        self.logger.debug(f"Simulated missing mask shape: {sim_mask.shape}")
        self.logger.debug(f"Original missing mask shape: {orig_mask.shape}")

        # --- Hard leakage guards ---
        if sim_mask.shape != orig_mask.shape:
            msg = (
                f"[{self.model_name}] Mask shape mismatch: "
                f"sim_mask{sim_mask.shape} vs orig_mask{orig_mask.shape}."
            )
            self.logger.error(msg)
            raise ValueError(msg)

        overlap = sim_mask & orig_mask
        if bool(overlap.any()):
            n = int(overlap.sum())
            msg = (
                f"[{self.model_name}] sim_missing_mask overlaps original_missing_mask "
                f"at {n} positions. This violates the no-overlap contract and biases evaluation."
            )
            self.logger.error(msg)
            raise ValueError(msg)

        self.logger.debug(
            f"Percent missing in simulated mask: {100.0 * sim_mask.sum() / sim_mask.size:.2f}%"
        )
        self.logger.debug(
            f"Percent missing in original mask: {100.0 * orig_mask.sum() / orig_mask.size:.2f}%"
        )

        return X_for_model, sim_mask, orig_mask

    def _train_val_test_split(
        self, X: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Split data into train, validation, and test sets.

        Args:
            X (np.ndarray): Genotype matrix to split.

        Returns:
            tuple[np.ndarray, np.ndarray, np.ndarray]: Indices for train, validation, and test sets.

        Raises:
            ValueError: If there are not enough samples for splitting.
            ValueError: If validation_split is not in (0.0, 1.0).
        """
        n_samples = X.shape[0]

        if n_samples < 3:
            msg = f"Not enough samples ({n_samples}) for train/val/test split."
            self.logger.error(msg)
            raise ValueError(msg)

        if not (0.0 < float(self.validation_split) < 1.0):
            msg = f"validation_split must be in (0.0, 1.0), but got {self.validation_split}."
            self.logger.error(msg)
            raise ValueError(msg)

        # Train/Val split
        indices = np.arange(n_samples)
        train_idx, val_test_idx = train_test_split(
            indices,
            test_size=self.validation_split,
            random_state=self.seed,
        )

        if not val_test_idx.size >= 4:
            msg = f"Not enough samples ({val_test_idx.size}) for validation/test split."
            self.logger.error(msg)
            raise ValueError(msg)

        # Split val and test equally
        val_idx, test_idx = train_test_split(
            val_test_idx, test_size=0.5, random_state=self.seed
        )

        return train_idx, val_idx, test_idx

    def _get_data_loaders(
        self,
        X: np.ndarray,
        y: np.ndarray,
        mask: np.ndarray,
        batch_size: int,
        *,
        shuffle: bool = True,
    ) -> torch.utils.data.DataLoader:
        """Create DataLoader for training and validation.

        Args:
            X (np.ndarray): One-hot encoded 0/1/2 (diploid) or 0/1 (haploid) input matrix.
            y (np.ndarray): 0/1/2-encoded matrix with -1 for missing.
            mask (np.ndarray): Boolean mask of entries to score in the loss.
            batch_size (int): Batch size.
            shuffle (bool): Whether to shuffle batches. Defaults to True.

        Returns:
            The DataLoader.
        """
        if not isinstance(X, np.ndarray):
            msg = "_get_data_loaders requires X to be a numpy ndarray."
            self.logger.error(msg)
            raise TypeError(msg)
        if not isinstance(y, np.ndarray):
            msg = "_get_data_loaders requires y to be a numpy ndarray."
            self.logger.error(msg)
            raise TypeError(msg)
        if not isinstance(mask, np.ndarray):
            msg = "_get_data_loaders requires mask to be a numpy ndarray."
            self.logger.error(msg)
            raise TypeError(msg)
        if X.shape[0] != y.shape[0] or X.shape[0] != mask.shape[0]:
            msg = f"Shape mismatch among X, y, and mask: X{X.shape}, y{y.shape}, mask{mask.shape}."
            self.logger.error(msg)
            raise ValueError(msg)
        if not X.ndim == 2 or not y.ndim == 2 or not mask.ndim == 2:
            msg = f"_get_data_loaders requires X, y, and mask to be 2D, but got shapes X{X.shape}, y{y.shape}, mask{mask.shape}."
            self.logger.error(msg)
            raise ValueError(msg)

        dataset = _MaskedNumpyDataset(X, y, mask)

        return torch.utils.data.DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=shuffle,
            pin_memory=(str(self.device).startswith("cuda")),
        )

    def _update_anneal_schedule(
        self,
        final: float,
        warm: int,
        ramp: int,
        epoch: int,
        *,
        init_val: float = 0.0,
    ) -> torch.Tensor:
        """Update annealed hyperparameter value based on epoch.

        Args:
            final (float): Final value after annealing.
            warm (int): Number of warm-up epochs.
            ramp (int): Number of ramp-up epochs.
            epoch (int): Current epoch number.
            init_val (float): Initial value before annealing starts.

        Returns:
            torch.Tensor: Current value of the hyperparameter.
        """
        if epoch < warm:
            val = torch.tensor(init_val, dtype=torch.float32)
        elif epoch < warm + ramp:
            val = torch.tensor(final * ((epoch - warm) / ramp), dtype=torch.float32)
        else:
            val = torch.tensor(final, dtype=torch.float32)
        return val.to(self.device)

    def _anneal_config(
        self,
        params: Optional[dict],
        key: str,
        default: float,
        max_epochs: int,
        *,
        warm_alt: int = 50,
        ramp_alt: int = 100,
    ) -> tuple[float, int, int]:
        """Configure annealing schedule for a hyperparameter.

        Args:
            params (Optional[dict]): Dictionary of parameters to extract from.
            key (str): Key to look for in params.
            default (float): Default final value if not specified in params.
            max_epochs (int): Total number of training epochs.
            warm_alt (int): Alternative warm-up period if 10% of epochs is too long
            ramp_alt (int): Alternative ramp-up period if 20% of epochs is too long

        Returns:
            tuple[float, int, int]: Final value, warm-up epochs, ramp-up epochs.
        """
        val = None
        if params is not None and params:
            if not hasattr(self, key):
                msg = f"Attribute '{key}' not found for anneal_config."
                self.logger.error(msg)
                raise AttributeError(msg)

            val = params.get(key, getattr(self, key))

        if val is not None and isinstance(val, (float, int)):
            final = float(val)
        else:
            final = default

        warm, ramp = min(int(0.1 * max_epochs), warm_alt), min(
            int(0.2 * max_epochs), ramp_alt
        )
        return final, warm, ramp

    def _aligned_ref_alt(self, L: int) -> tuple[list[object], list[object]]:
        """Return REF/ALT aligned to the genotype matrix columns.

        Args:
            L (int): Number of loci (columns in genotype matrix).

        Returns:
            tuple[list[object], list[object]]: Aligned REF and ALT lists.
        """
        refs = getattr(self.genotype_data, "ref", None)
        alts = getattr(self.genotype_data, "alt", None)

        if refs is None or alts is None:
            msg = "genotype_data.ref/alt are required but missing."
            self.logger.error(msg)
            raise ValueError(msg)

        refs_arr = np.asarray(refs, dtype=object)
        alts_arr = np.asarray(alts, dtype=object)

        if refs_arr.shape[0] != L or alts_arr.shape[0] != L:
            msg = f"REF/ALT length mismatch vs matrix columns: L={L}, len(ref)={refs_arr.shape[0]}, len(alt)={alts_arr.shape[0]}. You are using REF/ALT metadata that is not aligned to pgenc.genotypes_012 columns. Fix by subsetting/refiltering ref/alt with the same locus mask used for the genotype matrix."
            self.logger.error(msg)
            raise ValueError(msg)

        # Unwrap singleton ALT arrays like array(['T'], dtype=object)
        def unwrap(x: object) -> object:
            if isinstance(x, np.ndarray):
                if x.size == 0:
                    return None
                if x.size == 1:
                    return x.item()
            return x

        refs_list = [unwrap(x) for x in refs_arr.tolist()]
        alts_list = [unwrap(x) for x in alts_arr.tolist()]
        return refs_list, alts_list

    def validate_tuning_metric(self) -> str:
        """Validate and return the primary tuning metric.

        Returns:
            str: The primary tuning metric.

        Raises:
            ValueError: If the tuning metric is invalid.
            TypeError: If the tuning metric is not a string or list/tuple of strings.
        """
        if isinstance(self.tune_metric, (list, tuple)):
            if len(self.tune_metric) == 0:
                msg = f"[{self.model_name}] tune_metric list cannot be empty."
                self.logger.error(msg)
                raise ValueError(msg)
            return self.tune_metric[0]

        elif isinstance(self.tune_metric, str):
            return self.tune_metric

        else:
            msg = f"[{self.model_name}] tune_metric must be a string or list/tuple of strings."
            self.logger.error(msg)
            raise TypeError(msg)

    def _compute_tpe_startup_trials(
        self,
        n_trials: int,
        *,
        n_params: Optional[int] = None,
        frac: float = 0.10,
        min_startup: int = 5,
        max_startup: int = 50,
        min_tpe_trials: int = 5,
    ) -> int:
        """Compute a meaningful ``n_startup_trials`` for Optuna's TPESampler.

        Notes:
            - Allocate ~`frac` of the total budget to pure-random exploration.
            - Enforce absolute lower/upper bounds (min_startup/max_startup).
            - Ensure at least `min_tpe_trials` remain for model-based TPE suggestions.
            - Optionally scale startup with the number of tuned parameters (n_params).

        Args:
            n_trials (int): Total trial budget for the study (must be >= 1).
            n_params (Optional[int]): Optional count of parameters being tuned (dimensionality proxy).
            frac (float): Fraction of trials to use as startup (random) trials.
            min_startup (int): Minimum number of startup trials (when budget permits).
            max_startup (int): Maximum number of startup trials.
            min_tpe_trials (int): Minimum number of trials reserved for TPE after startup.

        Returns:
            int: ``n_startup_trials`` to pass to optuna.samplers.TPESampler.
        """
        if n_trials <= 0:
            msg = "n_trials must be >= 1."
            self.logger.error(msg)
            raise ValueError(msg)

        # If there's essentially no budget, don't pretend TPE will help.
        if n_trials <= 2:
            self.logger.warning(
                f"[{self.model_name}] n_trials <= 2; Optuna tuning may not be effective. It essentially reduces to random parameter search."
            )
            return max(0, n_trials - 1)

        # Leave room for TPE to actually run.
        max_allowed = max(1, n_trials - min_tpe_trials)

        # Fractional exploration budget (ceil avoids 0 for small n_trials).
        startup = math.ceil(frac * n_trials)

        # Dimensionality-aware floor (mild, not overly aggressive).
        if n_params is not None and n_params > 0:
            startup = max(startup, min_startup, min(n_params, max_startup))
        else:
            startup = max(startup, min_startup)

        # Hard caps.
        startup = min(startup, max_startup, max_allowed)

        p = "None" if n_params is None else int(n_params)
        self.logger.debug(
            f"[{self.model_name}] n_startup_trials={int(startup)} for Optuna TPE sampler. Total trials={int(n_trials)}, n_params={p}."
        )

        return int(startup)

    def _validate_sim_and_orig_masks(
        self,
        *,
        sim_mask: np.ndarray,
        orig_mask: np.ndarray,
        context: str,
        min_eval: int = 100,
    ) -> None:
        """Sanity checks to prevent leakage and degenerate evaluation.

        Args:
            sim_mask (np.ndarray): True where simulated missingness was applied.
            orig_mask (np.ndarray): True where original (real) missingness exists.
            context (str): Label used in error messages (e.g., "full", "train", "val", "test").
            min_eval (int): Minimum number of evaluable positions required (sim & ~orig).
        """
        if sim_mask.shape != orig_mask.shape:
            msg = f"[{self.model_name}] Mask shape mismatch ({context}): sim_mask ({sim_mask.shape}) vs orig_mask ({orig_mask.shape})."
            self.logger.error(msg)
            raise ValueError(msg)

        if sim_mask.dtype != bool:
            sim_mask = sim_mask.astype(bool, copy=False)
        if orig_mask.dtype != bool:
            orig_mask = orig_mask.astype(bool, copy=False)

        overlap = sim_mask & orig_mask
        if bool(overlap.any()):
            n = int(overlap.sum())
            msg = f"[{self.model_name}] sim_mask overlaps orig_mask context=({context}) at {n} positions. This violates the no-overlap contract and can bias metrics."
            self.logger.error(msg)
            raise ValueError(msg)

        eval_mask = sim_mask & ~orig_mask
        n_eval = int(eval_mask.sum())
        if n_eval < int(min_eval):
            # This can happen with tiny datasets, sim_prop ~ 0,
            #  or heavy original missingness.
            self.logger.warning(
                f"[{self.model_name}] Only {n_eval} evaluable positions ({context}) after applying sim_mask and excluding orig_mask. Consider increasing sim_prop or using a larger dataset to ensure reliable evaluation."
            )

        self.logger.debug(
            f"[{self.model_name}] {n_eval} evaluable positions after applying sim_mask and excluding orig_mask."
        )

    def _log_class_weights(self) -> None:
        """Log the computed class weights.

        Outputs class weights (if available) to logs.
        """
        if self.class_weights_ is not None:
            genotypes = self.class_weights_.numpy(force=True)
            res = genotypes.astype(float).tolist()
            if len(res) == 3:
                ref, het, alt = res
                self.logger.info(
                    f"class_weights=[REF={ref:.2f}, HET={het:.2f}, ALT={alt:.2f}]"
                )
            else:
                ref, alt = res
                self.logger.info(f"class_weights=[REF={ref:.2f}, ALT={alt:.2f}]")

    def _richprint_best_params(
        self, d: dict[str, Any], title: str, *, precision=3
    ) -> None:
        """Pretty-print the best hyperparameters using PrettyMetrics.

        This method utilizes the PrettyMetrics utility to display the best hyperparameters in a structured format. It checks if verbose or debug logging is enabled before printing.

        Args:
            d (dict[str, Any]): A dictionary of the best hyperparameters to print.
            precision (int): Number of decimal places for floating-point values. Defaults to 3.
        """
        if self.verbose or self.debug:
            self.logger.info(f"[{self.model_name}] model parameters:")
            title = f"[{self.model_name}] Model Hyperparameters"
            pm = PrettyMetrics(d, precision=precision, title=title)
            pm.render()

    def _save_display_model_params(self, *, is_tuned: bool) -> None:
        """Save and display the model hyperparameters.

        This method handles the saving and displaying of model hyperparameters. It sanitizes the best parameters for JSON serialization, saves them to a file, and pretty-prints them if verbose or debug logging is enabled.

        Args:
            is_tuned (bool): Whether the model was tuned or used fixed parameters.

        Notes:
            - Saves the best parameters to a JSON file.
            - Pretty-prints the parameters if verbose or debug logging is enabled.
        """
        bp = self._sanitize_for_json(self.best_params_)

        if not isinstance(bp, dict):
            msg = "Best parameters must be a dictionary after sanitization."
            self.logger.error(msg)
            raise TypeError(msg)

        # Save model parameters to a JSON file.
        self._save_best_params(bp, objective_mode=False)

        if is_tuned:
            # Pretty print best params
            title = f"[{self.model_name}] Optimized Model Parameters"
            self._richprint_best_params(bp, title, precision=3)

            # Save best parameters to a JSON file.
            self._save_best_params(bp, objective_mode=True)
        else:
            self.logger.info(f"[{self.model_name}] Model used fixed parameters")
            title = f"[{self.model_name}] Fixed Model Parameters"
            self._richprint_best_params(bp, title, precision=3)

    def _validate_mask_splits(
        self, sim_mask: np.ndarray, orig_mask: np.ndarray, *, context: str = "full"
    ) -> None:
        """Validate simulated and original masks for train/val/test splits.

        Args:
            sim_mask (np.ndarray): The simulated mask to validate.
            orig_mask (np.ndarray): The original mask to validate.
            context (str): Context label for error messages (e.g., "full", "train", "val", "test").
        """
        self._validate_sim_and_orig_masks(
            sim_mask=sim_mask, orig_mask=orig_mask, context=context
        )

    def _log_mask_counts(
        self, train: np.ndarray, val: np.ndarray, test: np.ndarray, dset: str
    ) -> None:
        """Log counts of missing entries in train/val/test splits.

        Args:
            train (np.ndarray): Mask for the training set.
            val (np.ndarray): Mask for the validation set.
            test (np.ndarray): Mask for the test set.
            dset (str): Dataset type label (e.g., "Simulated" or "Real").
        """
        self.logger.info(f"Train Set {dset} Counts: {np.count_nonzero(train)}")
        self.logger.info(f"Val Set {dset} Counts: {np.count_nonzero(val)}")
        self.logger.info(f"Test Set {dset} Counts: {np.count_nonzero(test)}")

        self.logger.info(
            f"Total known genotypes per split (sim_strategy={self.sim_strategy}): train set={np.count_nonzero(~train)}, val set={np.count_nonzero(~val)}, test set={np.count_nonzero(~test)}"
        )

    def validate_and_log_masks(self) -> None:
        """Validate and log simulated and original masks for train/val/test splits.

        Raises:
            TypeError: If any of the required masks are not set.
        """
        masks = [
            (self.sim_mask_train_, self.sim_mask_val_, self.sim_mask_test_),
            (self.orig_mask_train_, self.orig_mask_val_, self.orig_mask_test_),
        ]
        if any(mask is None for masks_pair in masks for mask in masks_pair):
            msg = "Simulated and original masks for train/val/test splits must be set before validation."
            self.logger.error(msg)
            raise TypeError(msg)

        for i, mask in enumerate(masks):
            self._log_mask_counts(*mask, "Simulated" if i == 0 else "Real")

        sm = (self.sim_mask_train_, self.sim_mask_val_, self.sim_mask_test_)
        om = (self.orig_mask_train_, self.orig_mask_val_, self.orig_mask_test_)
        contexts = ("train", "val", "test")
        for sim_mask, orig_mask, context in zip(sm, om, contexts):
            self._validate_mask_splits(sim_mask, orig_mask, context=context)

    def _extract_masks_indices(
        self, mask: np.ndarray, indices: tuple[np.ndarray, np.ndarray, np.ndarray]
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Extract train/val/test masks from full mask using provided indices.

        Args:
            mask (np.ndarray): Full mask array of shape (n_samples, n_loci).
            indices (tuple[np.ndarray, np.ndarray, np.ndarray]): Tuple of train, val, test indices.

        Returns:
            tuple[np.ndarray, np.ndarray, np.ndarray]: Train, val, test masks.
        """
        if not len(indices) == 3:
            msg = "Indices tuple must contain exactly three elements: (train_idx, val_idx, test_idx)."
            self.logger.error(msg)
            raise ValueError(msg)

        train_idx, val_idx, test_idx = indices

        train_mask = mask[train_idx].copy()
        val_mask = mask[val_idx].copy()
        test_mask = mask[test_idx].copy()
        return train_mask, val_mask, test_mask
