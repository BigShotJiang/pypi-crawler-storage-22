"""Framework adapters for pgmemory."""
