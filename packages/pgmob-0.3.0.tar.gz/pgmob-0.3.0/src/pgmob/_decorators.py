import functools
import inspect
import warnings
from collections.abc import Callable
from typing import Any, TypeVar

T = TypeVar("T")
LAZY_PREFIX = "_pgmlazy_"


class RefreshProperty:
    """An instance of this class marks a lazy-evaluated property as requiring a refresh"""

    def __eq__(self, __o: object) -> bool:
        return self.__class__ == __o.__class__


def get_lazy_property[T](obj: object, name: str, func: Callable[..., T], *args: Any, **kwargs: Any) -> T:
    """Retrieves a lazy property value"""
    attribute = LAZY_PREFIX + name
    has_attribute = hasattr(obj, attribute)
    if not has_attribute or (has_attribute and getattr(obj, attribute) == RefreshProperty()):
        setattr(obj, attribute, func(*args, **kwargs))
    return getattr(obj, attribute)


def lazy_property(func):
    # not used for now because of https://github.com/microsoft/pylance-release/discussions/2716
    # get_lazy_property implements that logic without having to use a decorator

    @property
    @functools.wraps(func)
    def _wrapper(self):
        return get_lazy_property(self, func.__name__, func, self)

    return _wrapper


class DeprecatedWarning(UserWarning):
    pass


def deprecated(instructions):
    """Flags a method as deprecated.

    Args:
        instructions: A warning displayed to a user. E.g. 'Use my_func() instead.'
    """

    def decorator(func):
        """This is a decorator which can be used to mark functions
        as deprecated. It will result in a warning being emitted
        when the function is used."""

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            message = f"Call to deprecated function {func.__name__}. {instructions}"

            frame = inspect.currentframe()
            if frame is not None:
                frame = frame.f_back

            if frame is not None:
                warnings.warn_explicit(
                    message,
                    category=DeprecatedWarning,
                    filename=inspect.getfile(frame.f_code),
                    lineno=frame.f_lineno,
                )
            else:
                warnings.warn(message, category=DeprecatedWarning, stacklevel=2)

            return func(*args, **kwargs)

        return wrapper

    return decorator
