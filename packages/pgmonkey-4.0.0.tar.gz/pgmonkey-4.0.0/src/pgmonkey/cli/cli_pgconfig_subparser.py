from pgmonkey.managers.pgconfig_manager import PGConfigManager
from pgmonkey.managers.pgcodegen_manager import PGCodegenManager
from pathlib import Path

CONNECTION_TYPE_CHOICES = ['normal', 'pool', 'async', 'async_pool']


def cli_pgconfig_subparser(subparsers):
    pgconfig_manager = PGConfigManager()
    pgcodegen_manager = PGCodegenManager()

    pgconfig_parser = subparsers.add_parser('pgconfig', help='Manage database configurations')
    pgconfig_subparsers = pgconfig_parser.add_subparsers(dest='pgconfig_command', help='pgconfig commands')

    # The "create" subcommand
    create_parser = pgconfig_subparsers.add_parser('create', help='Create a new database configuration file.')
    create_parser.add_argument('--type', choices=['pg'], default='pg', required=False,
                               help='Database type for the configuration template. Default is "pg".')
    create_parser.add_argument('--filepath', '--connconfig', required=True,
                               help='Path to where you want your configuration file created.')
    create_parser.set_defaults(func=pgconfig_create_handler, pgconfig_manager=pgconfig_manager)

    # The "test" subcommand
    test_parser = pgconfig_subparsers.add_parser('test',
                                                 help='Test the database connection using a configuration file.')
    test_parser.add_argument('--filepath', '--connconfig', required=True,
                             help='Path to the configuration file you want to test.')
    test_parser.add_argument('--connection-type', choices=CONNECTION_TYPE_CHOICES, default=None,
                             help='Connection type to test. Overrides the value in the config file.')
    test_parser.add_argument('--resolve-env', action='store_true', default=False,
                             help='Resolve ${VAR} environment variable references and '
                                  'from_env/from_file secret references in the config file.')
    test_parser.add_argument('--allow-sensitive-defaults', action='store_true', default=False,
                             help='Allow ${VAR:-default} fallback values for sensitive keys '
                                  'like password. Only useful with --resolve-env.')
    test_parser.set_defaults(func=pgconfig_test_handler, pgconfig_manager=pgconfig_manager)

    # The "generate-code" subcommand
    code_parser = pgconfig_subparsers.add_parser('generate-code',
                                                 help='Generate Python code to connect using a configuration file.')
    code_parser.add_argument('--filepath', '--connconfig', required=True,
                             help='Path to the configuration file you want to use.')
    code_parser.add_argument('--connection-type', choices=CONNECTION_TYPE_CHOICES, default=None,
                             help='Connection type for generated code. Overrides the value in the config file.')
    code_parser.add_argument('--library', choices=['pgmonkey', 'psycopg'], default='pgmonkey',
                             help='Target library for generated code. '
                                  '"pgmonkey" (default) generates code using pgmonkey. '
                                  '"psycopg" generates code using psycopg/psycopg_pool directly.')
    code_parser.add_argument('--resolve-env', action='store_true', default=False,
                             help='Resolve ${VAR} environment variable references and '
                                  'from_env/from_file secret references in the config file.')
    code_parser.set_defaults(func=pgconfig_generate_code_handler, pgcodegen_manager=pgcodegen_manager)


def pgconfig_create_handler(args):
    pgconfig_manager = args.pgconfig_manager
    filepath = Path(args.filepath)
    if filepath.exists():
        print(f'Configuration file already exists: {filepath}\nEdit this file to update settings.')
    else:
        config_template_text = pgconfig_manager.get_config_template_text(args.type)
        pgconfig_manager.write_config_template_text(filepath, config_template_text)


def pgconfig_test_handler(args):
    pgconfig_manager = args.pgconfig_manager
    connection_type = getattr(args, 'connection_type', None)
    resolve_env = getattr(args, 'resolve_env', False)
    allow_sensitive_defaults = getattr(args, 'allow_sensitive_defaults', False)
    pgconfig_manager.test_connection(
        args.filepath, connection_type, resolve_env=resolve_env,
        allow_sensitive_defaults=allow_sensitive_defaults,
    )


def pgconfig_generate_code_handler(args):
    pgcodegen_manager = args.pgcodegen_manager
    connection_type = getattr(args, 'connection_type', None)
    library = getattr(args, 'library', 'pgmonkey')
    resolve_env = getattr(args, 'resolve_env', False)
    pgcodegen_manager.generate_connection_code(
        args.filepath, connection_type, library=library, resolve_env=resolve_env,
    )
