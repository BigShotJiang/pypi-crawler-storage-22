
from typing import Any

async def stealth_async(context: Any) -> None:
    """
    Apply stealth evasions to a Playwright context.
    
    This function injects JavaScript to mask automation signals, including:
    - navigator.webdriver
    - navigator.plugins / mimeTypes
    - chrome.runtime
    - navigator.permissions
    - navigator.languages
    - webgl parameters
    - iframe contentWindow patching
    """
    
    # 1. Remove navigator.webdriver
    await context.add_init_script("""
        Object.defineProperty(navigator, 'webdriver', {
            get: () => undefined
        });
    """)
    
    # 2. Emulate Plugins and MimeTypes
    # Basic emulation of standard Chrome plugins
    await context.add_init_script("""
        // Mock plugins
        const mockPlugins = [
            {
                name: "PDF Viewer",
                filename: "internal-pdf-viewer",
                description: "Portable Document Format",
            },
            {
                name: "Chrome PDF Viewer",
                filename: "internal-pdf-viewer",
                description: "Portable Document Format",
            },
            {
                name: "Chromium PDF Viewer",
                filename: "internal-pdf-viewer",
                description: "Portable Document Format",
            }
        ];

        // Mock mimeTypes
        const mockMimeTypes = [
            {
                type: "application/pdf",
                suffixes: "pdf",
                description: "Portable Document Format",
                __pluginName: "Chrome PDF Viewer"
            },
             {
                type: "text/pdf",
                suffixes: "pdf",
                description: "Portable Document Format",
                __pluginName: "Chrome PDF Viewer"
            }
        ];

        // Utils to create Plugin and MimeType objects (simplified)
        // A full implementation would need to properly mimic PluginArray and MimeTypeArray behavior
        // including item(), namedItem(), refresh(), and length properties.
        
        // For brevity and robustness, we often override the getter for navigator.plugins 
        // to return a mocked object that looks like the real thing.
        
        function mockPluginArray() {
            const arr = mockPlugins;
            // Add item and namedItem methods if needed, or just rely on array behavior if checks are simple
            // But strict checks verify prototype.
            // Let's rely on a simpler approach for now: overriding the property descriptor.
            return arr;
        }

        Object.defineProperty(navigator, 'plugins', {
            get: () => {
                const arr = mockPlugins;
                arr.item = (index) => arr[index];
                arr.namedItem = (name) => arr.find(p => p.name === name);
                arr.refresh = () => {};
                return arr;
            }
        });

        Object.defineProperty(navigator, 'mimeTypes', {
             get: () => {
                const arr = mockMimeTypes;
                arr.item = (index) => arr[index];
                arr.namedItem = (name) => arr.find(m => m.type === name);
                return arr;
            }
        });
    """)
    
    # 3. Chrome Runtime
    await context.add_init_script("""
        window.chrome = {
            runtime: {},
            loadTimes: function() {},
            csi: function() {},
            app: {}
        };
    """)
    
    # 4. Navigator Permissions
    await context.add_init_script("""
        const originalQuery = window.navigator.permissions.query;
        window.navigator.permissions.query = (parameters) => (
            parameters.name === 'notifications' ?
                Promise.resolve({ state: 'denied' }) :
                originalQuery(parameters)
        );
    """)
    
    # 5. WebGL Vendor/Renderer
    await context.add_init_script("""
        const getParameter = WebGLRenderingContext.prototype.getParameter;
        WebGLRenderingContext.prototype.getParameter = function(parameter) {
            // UNMASKED_VENDOR_WEBGL
            if (parameter === 37445) {
                return 'Intel Inc.';
            }
            // UNMASKED_RENDERER_WEBGL
            if (parameter === 37446) {
                return 'Intel Iris OpenGL Engine';
            }
            return getParameter.apply(this, [parameter]);
        };
    """)

    # 6. Iframe contentWindow patching (Hairline/Headchr)
    # This is trickier and often requires evaluating on every frame or overriding HTMLIFrameElement.prototype.contentWindow
    await context.add_init_script("""
         // Very basic iframe evasion
         // Real implementations are more complex, but this helps with basic checks.
         Object.defineProperty(HTMLIFrameElement.prototype, 'contentWindow', {
            get: function() {
                const win = window; 
                // This is a naive stub. Real stealth requires proxying.
                // But preventing null/undefined for cross-origin or automation checks might help.
                return super.contentWindow; 
            }
         });
    """)

    # 7. Navigator Languages
    await context.add_init_script("""
        Object.defineProperty(navigator, 'languages', {
            get: () => ['en-US', 'en']
        });
    """)
    
    # 8. User Agent (removing Headless)
    # This is best done via context options, but as a fallback:
    await context.add_init_script("""
        // If UA contains HeadlessChrome, replace it
        const ua = navigator.userAgent;
        const newUA = ua.replace('HeadlessChrome/', 'Chrome/');
        if (ua !== newUA) {
            Object.defineProperty(navigator, 'userAgent', {
                get: () => newUA
            });
        }
    """)

