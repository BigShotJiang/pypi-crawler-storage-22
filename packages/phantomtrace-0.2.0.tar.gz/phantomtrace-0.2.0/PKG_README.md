# PhantomTrace

A Python library implementing an experimental mathematical framework where numbers can exist in two states: **present** or **absent**. It defines five operations that interact with these states in consistent, rule-based ways.

Zero is redefined: `0` is not emptiness — it's one absence (`1(0)`). This means every operation has a defined result, including division by zero.

**Read the paper**: [Absence Theory](https://www.academia.edu/150254484/Absence_Theory_Quantified_Absence_and_State_Aware_Arithmetic_within_Domains_of_Reference)

## Installation

```bash
pip install phantomtrace
```

## Quick Start

```python
from absence_calculator import AbsentNumber, add, subtract, multiply, divide, erase, format_result

# Create numbers — present (default) or absent
five = AbsentNumber(5)             # 5 (present)
three_absent = AbsentNumber(3, 1)  # 3(0) (absent)

# Addition — same state combines, mixed state is unresolved
result = add(AbsentNumber(5), AbsentNumber(3))
print(result)  # 8

# Subtraction — equal values cancel to void
result = subtract(AbsentNumber(7), AbsentNumber(7))
print(result)  # void

# Multiplication — states combine (like XOR)
result = multiply(AbsentNumber(5, 1), AbsentNumber(3))
print(result)  # 15(0)

# Erasure — flips the state of the erased portion
result = erase(AbsentNumber(5), AbsentNumber(3))
print(result)  # 2 + 3(0)

# Over-erasure — excess becomes erased debt
result = erase(AbsentNumber(7), AbsentNumber(10))
print(result)  # 7(0) + erased 3

# Resolve erased excess by adding
from absence_calculator import ErasedExcess
resolved = add(result, AbsentNumber(3))
print(resolved)  # 10(0)

# Division by zero — defined! (0 is one absence)
result = divide(AbsentNumber(10), AbsentNumber(1, 1))
print(result)  # 10(0)
```

## Using the Expression Solver

```python
from absence_calculator import solve, format_result

# Parse and solve string expressions
print(format_result(solve("5 + 3")))           # 8
print(format_result(solve("5(0) + 3(0)")))     # 8(0)
print(format_result(solve("7 - 7")))           # void
print(format_result(solve("5(0) * 3")))        # 15(0)
print(format_result(solve("5 erased 3")))      # 2 + 3(0)
print(format_result(solve("7 erased 10")))     # 7(0) + erased 3 (over-erasure)
print(format_result(solve("5(0)(0)")))         # 5 (double absence = present)

# Parenthesized expressions (operations on unresolved inputs)
print(format_result(solve("(1 + 5(0)) erased 1")))  # 6(0)

# Zero operations
print(format_result(solve("0 + 0")))           # 2(0) (two absences)
print(format_result(solve("0 * 0")))           # 1 (absence of absence = presence)
print(format_result(solve("10 * 0")))          # 10(0)
print(format_result(solve("10 / 0")))          # 10(0)
```

## Interactive Calculator

After installing, you can run the interactive calculator from the command line:

```bash
phantomtrace
```

Or as a Python module:

```bash
python -m absence_calculator
```

This gives you a `calc >>` prompt where you can type expressions and see results.

## Core Concepts

### Objects and States

An object is a number that has both a **value** and a **state**:
- **Present** (default): Written normally, e.g. `5`. Present quantities reflect the presence of a given unit of interest. (e.g. if the unit is a cat, then 5 represents 5 cats that are there or in a present state)
- **Absent**: Written with `(0)`, e.g. `5(0)` — think of it as `5 * 0`. Absent quantities reflect the absence of a given unit of interest. (e.g. if the unit is a phone, then 5(0) represents 5 phones that are not currently there but are still considered for computation)

### Absence
  
- **Zero**: `0` is not emptiness, it's one absence (`1(0) = 1 * 0 = 0`)
- **Absence of absence** returns to present: `5(0)(0) = 5`, and `0(0) = 1`

### Operations

| Operation | Symbol | Rule |
|-----------|--------|------|
| Addition | `+` | Expands the amount of objects under consideration. Same state: magnitudes combine. Mixed: unresolved |
| Subtraction | `-` | Contracts the amount of objects under consideration. (If the domain of consideration is constricted to nothing then the result is void. Void is not an object, nor the new zero, it simply means we are not considering anything on which to act.) Same state: magnitudes reduce. Mixed: unresolved|
| Multiplication | `*` | Magnitudes multiply. States combine (present*present=present, absent*present=absent, absent*absent=present) |
| Division | `/` | Magnitudes divide. States combine same as multiplication. Division by 0 is defined! |
| Erasure | `erased` | Same state required. Remainder keeps state, erased portion flips state. Over-erasure creates erased excess |

### Over-Erasure (v0.2.0)

When you erase more than the total, the result carries an **erased excess** (erasure debt):

- `7 erased 10` = `7(0) + erased 3` — all 7 flip state, 3 excess erasure persists
- Adding resolves excess: `(7(0) + erased 3) + 3` = `10(0)`
- Erasing erased: `(erased 3) erased (erased 3)` = `erased 3(0)` (absence of erased)

### Compound Expressions (v0.2.0)

Operations can now accept unresolved expressions as inputs:

- `(1 + 5(0)) erased 1` = `6(0)` — erases the present part, combining with the absent part

### Result Types

- **AbsentNumber**: A number with a state (present or absent)
- **Void**: Complete cancellation — not zero, but the absence of any quantity under consideration
- **ErasureResult**: Two parts — remainder (keeps state) and erased portion (flipped state)
- **ErasedExcess**: Excess erasure debt that persists until resolved
- **Unresolved**: An expression that cannot be simplified (e.g., adding present + absent)

## Toggle Module (v0.2.0)

The toggle module applies erasure logic to vectors using pattern-based index selection.

```python
from absence_calculator import toggle

vector = [4, 7, 19, 22, 26]

# toggle.ys(pattern, range, vector)
# Pattern determines which indices to toggle
# Range is (start, end) inclusive — inputs to the pattern function
result = toggle.ys("x^2", (1, 4), vector)
# i=1: 1^2=1, toggle index 1 (7 -> 7(0))
# i=2: 2^2=4, toggle index 4 (26 -> 26(0))
# i=3: 3^2=9, out of bounds, skip
# i=4: 4^2=16, out of bounds, skip
print(result)  # [4, 7(0), 19, 22, 26(0)]

# Also accepts lambda functions as patterns
result = toggle.ys(lambda x: x * 2, (0, 2), [10, 20, 30, 40, 50])
print(result)  # [10(0), 20, 30(0), 40, 50(0)]

# toggle.nt — flips everything EXCEPT the targeted indices (inverse of ys)
result = toggle.nt(lambda x: x * 2, (0, 2), [10, 20, 30, 40, 50])
print(result)  # [10, 20(0), 30, 40(0), 50]
```

## API Reference

### Types

- `AbsentNumber(value, absence_level=0)` — A number with a state. `absence_level` 0 = present, 1 = absent
- `Void` / `VOID` — Represents complete cancellation
- `ErasureResult(remainder, erased)` — Result of an erasure operation
- `ErasedExcess(value, absence_level=0)` — Excess erasure debt from over-erasure
- `Unresolved(left, op, right)` — An expression that can't be simplified

### Functions

- `add(x, y)` — Add two values (supports compound inputs with excess resolution)
- `subtract(x, y)` — Subtract two AbsentNumbers
- `multiply(x, y)` — Multiply two AbsentNumbers
- `divide(x, y)` — Divide two AbsentNumbers
- `erase(x, y)` — Erase y from x (supports over-erasure and compound inputs)
- `solve(expr_string)` — Parse and evaluate a string expression (supports parentheses)
- `format_result(result)` — Convert any result to a readable string
- `parse_number(s)` — Parse a string like `"5(0)"` into an AbsentNumber

### Toggle

- `toggle.ys(pattern, range, vector)` — Toggle vector elements at pattern-computed indices
- `toggle.nt(pattern, range, vector)` — Toggle all elements NOT at pattern-computed indices (inverse of ys)

### Constants

- `ALL_OPERATIONS` — Dictionary describing all operations with rules and examples

## License

MIT
