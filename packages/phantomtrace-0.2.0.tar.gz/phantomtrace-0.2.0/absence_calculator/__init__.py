from absence_calculator.core import (
    AbsentNumber, Void, VOID, Unresolved, ErasureResult, ErasedExcess,
    add, subtract, multiply, divide, erase,
    solve, format_result, parse_number, ALL_OPERATIONS
)
from absence_calculator import toggle

__version__ = "0.2.0"
