import ast
import operator


class Void:
    def __repr__(self):
        return "void"

    def __eq__(self, other):
        return isinstance(other, Void)

VOID = Void()


class AbsentNumber:
    def __init__(self, value, absence_level=0):
        self.value = value
        self.absence_level = absence_level % 2

    @property
    def state(self):
        return "absent" if self.absence_level == 1 else "present"

    @property
    def is_present(self):
        return self.absence_level == 0

    @property
    def is_absent(self):
        return self.absence_level == 1

    def apply_absence(self):
        return AbsentNumber(self.value, self.absence_level + 1)

    def toggle(self):
        return AbsentNumber(self.value, self.absence_level + 1)

    def _format_value(self):
        if isinstance(self.value, float) and self.value == int(self.value):
            return str(int(self.value))
        return str(self.value)

    def __repr__(self):
        if self.value == 1 and self.absence_level == 1:
            return "0"
        v = self._format_value()
        if self.absence_level == 0:
            return v
        else:
            return f"{v}(0)"

    def __eq__(self, other):
        if isinstance(other, AbsentNumber):
            return self.value == other.value and self.absence_level == other.absence_level
        return False


class ErasedExcess:
    def __init__(self, value, absence_level=0):
        self.value = value
        self.absence_level = absence_level % 2

    def apply_absence(self):
        return ErasedExcess(self.value, self.absence_level + 1)

    def _format_value(self):
        if isinstance(self.value, float) and self.value == int(self.value):
            return str(int(self.value))
        return str(self.value)

    def __repr__(self):
        v = self._format_value()
        if self.absence_level == 0:
            return f"erased {v}"
        else:
            return f"erased {v}(0)"

    def __eq__(self, other):
        if isinstance(other, ErasedExcess):
            return self.value == other.value and self.absence_level == other.absence_level
        return False


class ErasureResult:
    def __init__(self, remainder, erased):
        self.remainder = remainder
        self.erased = erased

    def __repr__(self):
        parts = []
        if self.remainder is not None:
            parts.append(str(self.remainder))
        if self.erased is not None:
            parts.append(str(self.erased))
        return " + ".join(parts) if parts else "void"

    def __eq__(self, other):
        if isinstance(other, ErasureResult):
            return self.remainder == other.remainder and self.erased == other.erased
        return False


class Unresolved:
    def __init__(self, left, op, right):
        self.left = left
        self.op = op
        self.right = right

    def __repr__(self):
        return f"{self.left} {self.op} {self.right}"

    def __eq__(self, other):
        if isinstance(other, Unresolved):
            return self.left == other.left and self.op == other.op and self.right == other.right
        return False


def _collect_terms(result):
    present = 0
    absent = 0
    excesses = []
    unresolvable = []

    if result is None or isinstance(result, Void):
        pass
    elif isinstance(result, AbsentNumber):
        if result.is_present:
            present += result.value
        else:
            absent += result.value
    elif isinstance(result, ErasedExcess):
        excesses.append(result)
    elif isinstance(result, ErasureResult):
        p1, a1, e1, u1 = _collect_terms(result.remainder)
        p2, a2, e2, u2 = _collect_terms(result.erased)
        present += p1 + p2
        absent += a1 + a2
        excesses.extend(e1 + e2)
        unresolvable.extend(u1 + u2)
    elif isinstance(result, Unresolved) and result.op == "+":
        p1, a1, e1, u1 = _collect_terms(result.left)
        p2, a2, e2, u2 = _collect_terms(result.right)
        present += p1 + p2
        absent += a1 + a2
        excesses.extend(e1 + e2)
        unresolvable.extend(u1 + u2)
    else:
        unresolvable.append(result)

    return present, absent, excesses, unresolvable


def _build_result(present, absent, excesses, unresolvable=None):
    if unresolvable is None:
        unresolvable = []

    remaining_excesses = []
    for ex in excesses:
        if ex.absence_level == 0 and present > 0:
            if present >= ex.value:
                present -= ex.value
                absent += ex.value
            else:
                absent += present
                remaining_excesses.append(ErasedExcess(ex.value - present, ex.absence_level))
                present = 0
        else:
            remaining_excesses.append(ex)

    parts = []
    if present > 0:
        parts.append(AbsentNumber(present, 0))
    if absent > 0:
        parts.append(AbsentNumber(absent, 1))
    parts.extend(remaining_excesses)
    parts.extend(unresolvable)

    if not parts:
        return VOID

    result = parts[0]
    for p in parts[1:]:
        if isinstance(result, AbsentNumber) and isinstance(p, AbsentNumber):
            if result.absence_level == p.absence_level:
                result = AbsentNumber(result.value + p.value, result.absence_level)
            else:
                result = Unresolved(result, "+", p)
        elif isinstance(p, ErasedExcess):
            result = ErasureResult(result, p)
        else:
            result = Unresolved(result, "+", p)

    return result


def add(x, y):
    if isinstance(x, AbsentNumber) and isinstance(y, AbsentNumber):
        if x.absence_level == y.absence_level:
            return AbsentNumber(x.value + y.value, x.absence_level)
        else:
            return Unresolved(x, "+", y)

    px, ax, ex, ux = _collect_terms(x)
    py, ay, ey, uy = _collect_terms(y)
    return _build_result(px + py, ax + ay, ex + ey, ux + uy)


def subtract(x, y):
    if isinstance(x, AbsentNumber) and isinstance(y, AbsentNumber):
        if x.absence_level != y.absence_level:
            return Unresolved(x, "-", y)
        if x.value == y.value:
            return VOID
        if x.value > y.value:
            return AbsentNumber(x.value - y.value, x.absence_level)
        else:
            return Unresolved(x, "-", y)

    return Unresolved(x, "-", y)


def multiply(x, y):
    if isinstance(x, AbsentNumber) and isinstance(y, AbsentNumber):
        result_value = x.value * y.value
        result_level = (x.absence_level + y.absence_level) % 2
        return AbsentNumber(result_value, result_level)

    return Unresolved(x, "*", y)


def divide(x, y):
    if isinstance(x, AbsentNumber) and isinstance(y, AbsentNumber):
        if y.value == 0:
            return VOID
        result_level = (x.absence_level + y.absence_level) % 2
        if x.value % y.value == 0:
            return AbsentNumber(x.value // y.value, result_level)
        result_value = round(x.value / y.value, 10)
        if result_value == int(result_value):
            return AbsentNumber(int(result_value), result_level)
        return AbsentNumber(result_value, result_level)

    return Unresolved(x, "/", y)


def erase(x, y):
    if isinstance(x, AbsentNumber) and isinstance(y, AbsentNumber):
        if x.absence_level != y.absence_level:
            raise ValueError("Erasure requires same state")

        if x.value >= y.value:
            remainder_val = x.value - y.value
            erased_val = y.value
            new_level = (y.absence_level + 1) % 2

            remainder = AbsentNumber(remainder_val, x.absence_level) if remainder_val > 0 else None
            erased = AbsentNumber(erased_val, new_level) if erased_val > 0 else None

            if remainder is None and erased is None:
                return VOID
            if remainder is None:
                return erased
            if erased is None:
                return remainder
            return ErasureResult(remainder, erased)
        else:
            flipped = AbsentNumber(x.value, (x.absence_level + 1) % 2)
            excess_val = y.value - x.value
            excess = ErasedExcess(excess_val)
            return ErasureResult(flipped, excess)

    if isinstance(x, ErasedExcess) and isinstance(y, ErasedExcess):
        if x.value >= y.value:
            remainder_val = x.value - y.value
            erased_part = ErasedExcess(y.value, (y.absence_level + 1) % 2)

            if remainder_val == 0:
                return erased_part

            remainder = ErasedExcess(remainder_val, x.absence_level)
            return ErasureResult(remainder, erased_part)
        else:
            flipped = ErasedExcess(x.value, (x.absence_level + 1) % 2)
            excess_val = y.value - x.value
            remaining_excess = ErasedExcess(excess_val, y.absence_level)
            return ErasureResult(flipped, remaining_excess)

    if isinstance(x, (Unresolved, ErasureResult)) and isinstance(y, AbsentNumber):
        px, ax, ex, ux = _collect_terms(x)

        if y.is_present and px > 0:
            if px >= y.value:
                new_present = px - y.value
                new_absent = ax + y.value
                return _build_result(new_present, new_absent, ex, ux)
            else:
                new_absent = ax + px
                excess = ErasedExcess(y.value - px)
                return _build_result(0, new_absent, ex + [excess], ux)
        elif y.is_absent and ax > 0:
            if ax >= y.value:
                new_absent = ax - y.value
                new_present = px + y.value
                return _build_result(new_present, new_absent, ex, ux)
            else:
                new_present = px + ax
                excess = ErasedExcess(y.value - ax)
                return _build_result(new_present, 0, ex + [excess], ux)

        raise ValueError(f"Cannot erase {y} from {x}")

    raise ValueError(f"Cannot erase {y} from {x}")


def _find_top_level_op(expr):
    depth = 0
    rightmost_low = None
    rightmost_high = None

    i = 0
    while i < len(expr):
        c = expr[i]
        if c == '(':
            depth += 1
            i += 1
        elif c == ')':
            depth -= 1
            i += 1
        elif depth == 0:
            remaining = expr[i:]
            if (remaining.startswith('erased')
                    and i > 0
                    and (len(remaining) <= 6 or not remaining[6].isalnum())):
                prev = expr[:i].rstrip()
                if prev and (prev[-1].isdigit() or prev[-1] == ')'):
                    rightmost_low = (i, 'erased')
                i += 6
            elif c in '+-' and i > 0:
                j = i - 1
                while j >= 0 and expr[j] == ' ':
                    j -= 1
                if j >= 0 and (expr[j].isdigit() or expr[j] == ')'):
                    rightmost_low = (i, c)
                i += 1
            elif c in '*/':
                rightmost_high = (i, c)
                i += 1
            else:
                i += 1
        else:
            i += 1

    if rightmost_low is not None:
        return rightmost_low
    if rightmost_high is not None:
        return rightmost_high
    return None, None


def solve(expr_string):
    expr_string = expr_string.strip()

    if not expr_string:
        return VOID

    pos, op = _find_top_level_op(expr_string)

    if pos is not None:
        if op == 'erased':
            left_str = expr_string[:pos].strip()
            right_str = expr_string[pos + 6:].strip()
        else:
            left_str = expr_string[:pos].strip()
            right_str = expr_string[pos + 1:].strip()

        left = solve(left_str)
        right = solve(right_str)

        if op == '+':
            return add(left, right)
        elif op == '-':
            return subtract(left, right)
        elif op == '*':
            return multiply(left, right)
        elif op == '/':
            return divide(left, right)
        elif op == 'erased':
            return erase(left, right)

    if expr_string.startswith('('):
        depth = 0
        match_pos = -1
        for i, c in enumerate(expr_string):
            if c == '(':
                depth += 1
            elif c == ')':
                depth -= 1
                if depth == 0:
                    match_pos = i
                    break

        if match_pos >= 0:
            inner = expr_string[1:match_pos]
            rest = expr_string[match_pos + 1:]

            if inner == '0' and (rest == '' or all(rest[j:j+3] == '(0)' for j in range(0, len(rest), 3))):
                return parse_number(expr_string)

            result = solve(inner)

            while rest.startswith('(0)'):
                if isinstance(result, AbsentNumber):
                    result = result.apply_absence()
                rest = rest[3:]

            return result

    if expr_string.startswith('erased '):
        value_str = expr_string[7:].strip()
        num = parse_number(value_str)
        return ErasedExcess(num.value, num.absence_level)

    return parse_number(expr_string)


def parse_number(s):
    s = s.strip()
    absence_level = 0
    while s.endswith("(0)"):
        absence_level += 1
        s = s[:-3]
    if not s:
        return AbsentNumber(1, absence_level)
    value = float(s)
    if value == int(value):
        value = int(value)
    if value == 0:
        value = 1
        absence_level += 1
    return AbsentNumber(value, absence_level)


def format_result(result):
    return str(result)


ALL_OPERATIONS = {
    "addition": {
        "symbol": "+",
        "rule": "Same state: magnitudes combine (domain expansion). Mixed state: unresolved",
        "examples": ["5 + 3 = 8", "7(0) + 3(0) = 10(0)", "7 + 5(0) = 7 + 5(0) [unresolved]"]
    },
    "subtraction": {
        "symbol": "-",
        "rule": "Same state: magnitudes reduce (domain contraction). Equal values: void. Mixed: unresolved",
        "examples": ["7 - 3 = 4", "5(0) - 3(0) = 2(0)", "7 - 7 = void", "7(0) - 5 = 7(0) - 5 [unresolved]"]
    },
    "multiplication": {
        "symbol": "*",
        "rule": "Magnitudes multiply. States combine: present*present=present, absent*present=absent, absent*absent=present",
        "examples": ["10 * 9 = 90", "5(0) * 5 = 25(0)", "25(0) * 4(0) = 100"]
    },
    "division": {
        "symbol": "/",
        "rule": "Magnitudes divide (decimals allowed). States combine same as multiplication",
        "examples": ["90 / 9 = 10", "25(0) / 5 = 5(0)", "6(0) / 8(0) = 0.75", "100(0) / 4(0) = 25"]
    },
    "erasure": {
        "symbol": "erased",
        "rule": "Same state required. Flips state of erased portion, remainder keeps state. Over-erasure creates erased excess",
        "examples": [
            "5 erased 3 = 2 + 3(0)",
            "7 erased 7 = 7(0)",
            "7 erased 10 = 7(0) + erased 3",
            "(erased 3) erased (erased 3) = erased 3(0)"
        ]
    },
    "absence": {
        "symbol": "(0)",
        "rule": "Flips state. x(0) = absent x. x(0)(0) = x (double absence = presence)",
        "examples": ["5(0) = absent 5", "5(0)(0) = 5"]
    }
}
