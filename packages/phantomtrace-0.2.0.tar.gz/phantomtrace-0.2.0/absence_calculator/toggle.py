import ast
import operator as op_module
from absence_calculator.core import AbsentNumber


_SAFE_OPS = {
    ast.Add: op_module.add,
    ast.Sub: op_module.sub,
    ast.Mult: op_module.mul,
    ast.Div: op_module.truediv,
    ast.FloorDiv: op_module.floordiv,
    ast.Mod: op_module.mod,
    ast.Pow: op_module.pow,
}


def _eval_node(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    elif isinstance(node, ast.BinOp):
        left = _eval_node(node.left)
        right = _eval_node(node.right)
        func = _SAFE_OPS.get(type(node.op))
        if func is None:
            raise ValueError(f"Unsupported operator in pattern")
        return func(left, right)
    elif isinstance(node, ast.UnaryOp):
        operand = _eval_node(node.operand)
        if isinstance(node.op, ast.USub):
            return -operand
        elif isinstance(node.op, ast.UAdd):
            return operand
        raise ValueError("Unsupported unary operator in pattern")
    else:
        raise ValueError(f"Unsupported expression in pattern: {ast.dump(node)}")


def _safe_eval_pattern(expr_str, x_val):
    expr = expr_str.replace('^', '**')
    expr = expr.replace('x', str(x_val))
    tree = ast.parse(expr, mode='eval')
    return _eval_node(tree.body)


def _to_absent_number(item):
    if isinstance(item, AbsentNumber):
        return item
    elif isinstance(item, (int, float)):
        return AbsentNumber(item, 0)
    else:
        raise TypeError(f"Cannot convert {type(item).__name__} to AbsentNumber")


def _compute_target_indices(pattern, range_tuple, vector_len):
    start, end = range_tuple
    targets = set()
    for i in range(start, end + 1):
        if callable(pattern):
            target_index = int(pattern(i))
        else:
            target_index = int(_safe_eval_pattern(pattern, i))
        if 0 <= target_index < vector_len:
            targets.add(target_index)
    return targets


def ys(pattern, range_tuple, vector):
    result = [_to_absent_number(v) for v in vector]
    targets = _compute_target_indices(pattern, range_tuple, len(result))

    for idx in targets:
        result[idx] = result[idx].toggle()

    return result


def nt(pattern, range_tuple, vector):
    result = [_to_absent_number(v) for v in vector]
    targets = _compute_target_indices(pattern, range_tuple, len(result))

    for idx in range(len(result)):
        if idx not in targets:
            result[idx] = result[idx].toggle()

    return result
