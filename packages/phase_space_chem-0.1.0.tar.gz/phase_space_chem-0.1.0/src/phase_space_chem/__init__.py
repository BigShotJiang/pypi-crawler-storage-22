"""
PhaseSpaceChem: A library for Electron Transfer, Diabatic Couplings, 
and Vibronic Energy Gaps in a Phase Space Framework.
"""
