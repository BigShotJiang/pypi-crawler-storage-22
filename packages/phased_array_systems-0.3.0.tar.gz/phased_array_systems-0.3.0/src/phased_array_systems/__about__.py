"""Version and metadata for phased-array-systems."""

__version__ = "0.3.0"
__author__ = "phased-array-systems contributors"
