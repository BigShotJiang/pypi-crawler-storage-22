from setuptools import setup

setup(
    name="phasenet-plus",
    version="0.1.0",
    long_description="phasenet-plus",
    long_description_content_type="text/markdown",
    packages=["phasenet-plus"],
    install_requires=["numpy",  "h5py", "matplotlib", "pandas"],
)
