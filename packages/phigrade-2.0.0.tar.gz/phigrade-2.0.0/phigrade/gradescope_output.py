import json
import os
import tempfile
from typing import Any, Dict, List


def write_gradescope_json_file(out_file: str, results: list) -> None:
    """
    Writes the collected test results to a Gradescope-compatible JSON file.

    The output file will follow the following format. This method will include the per-test scores and
    information and skip the global information when possible for simplicity.

    { "score": 44.0, // optional, but required if not on each test case below. Overrides total of tests if specified.
    "execution_time": 136, // optional, seconds
    "output": "Text relevant to the entire submission", // optional
    "output_format": "simple_format", // Optional output format settings, see "Output String Formatting" below
    "test_output_format": "text", // Optional default output format for test case outputs, see "Output String Formatting" below
    "test_name_format": "text", // Optional default output format for test case names, see "Output String Formatting" below
    "visibility": "after_due_date", // Optional visibility setting
    "stdout_visibility": "visible", // Optional stdout visibility setting
    "extra_data": {}, // Optional extra data to be stored
    "tests": // Optional, but required if no top-level score
        [
            {
                "score": 2.0, // optional, but required if not on top level submission
                "max_score": 2.0, // optional
                "status": "passed", // optional, see "Test case status" below
                "name": "Your name here", // optional
                "name_format": "text", // optional formatting for the test case name, see "Output String Formatting" below
                "number": "1.1", // optional (will just be numbered in order of array if no number given)
                "output": "Giant multiline string that will be placed in a <pre> tag and collapsed by default", // optional
                "output_format": "text", // optional formatting for the test case output, see "Output String Formatting" below
                "tags": ["tag1", "tag2", "tag3"], // optional
                "visibility": "visible", // Optional visibility setting
                "extra_data": {} // Optional extra data to be stored
            },
            // and more test cases...
        ],
    "leaderboard": // Optional, will set up leaderboards for these values
        [
        {"name": "Accuracy", "value": .926},
        {"name": "Time", "value": 15.1, "order": "asc"},
        {"name": "Stars", "value": "*****"}
        ]
    }
    """
    # Validation
    if not out_file:
        raise ValueError("out_file cannot be empty")
    if not isinstance(results, list):
        raise TypeError("results must be a list")

    # Handle empty results
    if not results:
        gradescope_json = {"score": 0.0, "tests": []}
        _write_json_atomically(out_file, gradescope_json)
        return

    # Group comparisons by utest_name
    tests_by_name: Dict[str, Dict[str, Any]] = {}
    for result in results:
        utest_name = result.get("utest_name")
        if not utest_name:
            continue  # Skip if missing required field

        if utest_name not in tests_by_name:
            tests_by_name[utest_name] = {
                "comparisons": [],
                "max_points": result.get("max_points", 0.0),
                "num_comparisons": result.get("num_comparisons", 0),
            }

        tests_by_name[utest_name]["comparisons"].append(result)

    # Build test entries
    tests = []
    total_score = 0.0

    for utest_name, test_data in tests_by_name.items():
        comparisons = test_data["comparisons"]
        max_points = test_data["max_points"]

        # Aggregate scores for this test
        total_points = test_data["num_comparisons"]
        if total_points == 0:
            test_score = 0.0
        else:
            test_score = sum(c.get("score", 0.0) for c in comparisons) / total_points * max_points 
        all_correct = all(c.get("is_correct", False) for c in comparisons)

        # Build output string with comparison details
        output_lines = []
        for comp in comparisons:
            comp_name = comp.get("comparison_name", "unknown")
            is_correct = comp.get("is_correct", False)
            status = "PASSED" if is_correct else "FAILED"
            student_out = comp.get("student_output")

            output_lines.append(f"Comparison '{comp_name}': {status}")
            output_lines.append(f"  Student output: {_format_output(student_out)}")

        # Create test entry
        test_entry = {
            "name": utest_name,
            "score": test_score,
            "max_score": max_points,
            "status": "passed" if all_correct else "failed",
            "output": "\n".join(output_lines)
        }
        tests.append(test_entry)
        total_score += test_score

    # Build final JSON structure
    gradescope_json = {
        "score": total_score,
        "tests": tests
    }

    # Write to file atomically
    try:
        _write_json_atomically(out_file, gradescope_json)
    except (IOError, OSError) as e:
        # Log warning but don't crash test execution
        print(f"Warning: Failed to write Gradescope JSON to {out_file}: {e}")


def _format_output(value: Any) -> str:
    """Format output value for display in Gradescope."""
    if isinstance(value, str):
        return repr(value)
    elif isinstance(value, (int, float, bool, type(None))):
        return str(value)
    elif isinstance(value, (list, dict)):
        return json.dumps(value, indent=2)
    else:
        return str(value)


def _write_json_atomically(file_path: str, data: dict) -> None:
    """Write JSON file atomically to avoid partial writes."""
    # Write to temporary file first
    dir_name = os.path.dirname(file_path) or "."
    with tempfile.NamedTemporaryFile(
        mode='w',
        dir=dir_name,
        delete=False,
        suffix='.tmp'
    ) as tmp_file:
        json.dump(data, tmp_file, indent=2)
        tmp_file.flush()
        os.fsync(tmp_file.fileno())
        tmp_name = tmp_file.name

    # Atomic rename (overwrites existing file)
    os.replace(tmp_name, file_path)    
