# Copyright (c) 2025 Zhaoxi Technology Co., Ltd.
# All rights reserved.
# 本软件版权归 重庆昭析科技有限责任公司所有。
# 请根据许可协议使用本软件。


class PhilVaultError(Exception):
    """Base error for the PhilVault SDK."""


class PhilVaultHTTPError(PhilVaultError):
    """HTTP error returned by the PhilVault API."""

    def __init__(self, status_code: int, message: str, payload=None):
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload
