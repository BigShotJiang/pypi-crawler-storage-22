"""
Structured logging helpers for Phlo.

Provides centralized logging setup and a hook-based log router.
"""

from __future__ import annotations

import contextvars
import logging
import os
import sys
import traceback
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, MutableMapping

import structlog

from phlo.config import get_settings
from phlo.hooks.events import LogEvent

_STANDARD_LOG_RECORD_FIELDS = set(
    logging.LogRecord(
        name="", level=0, pathname="", lineno=0, msg="", args=(), exc_info=None
    ).__dict__.keys()
)
_CORRELATION_FIELDS = ("run_id", "asset_key", "job_name", "partition_key", "check_name")
_ROUTER_ACTIVE = contextvars.ContextVar("phlo_log_router_active", default=False)
_LOGGING_CONFIGURED = False


@dataclass(frozen=True)
class LoggingSettings:
    level: str = "INFO"
    log_format: str = "auto"
    router_enabled: bool = True
    service_name: str = "phlo"
    log_file_template: str | None = None

    @classmethod
    def from_settings(cls) -> "LoggingSettings":
        settings = get_settings()
        return cls(
            level=settings.phlo_log_level,
            log_format=settings.phlo_log_format,
            router_enabled=settings.phlo_log_router_enabled,
            service_name=settings.phlo_log_service_name,
            log_file_template=settings.phlo_log_file_template,
        )


def setup_logging(settings: LoggingSettings | None = None, *, force: bool = False) -> None:
    """Configure structlog + stdlib logging with configurable output and routing."""

    global _LOGGING_CONFIGURED
    if _LOGGING_CONFIGURED and not force:
        return

    resolved = settings or LoggingSettings.from_settings()
    level = _coerce_log_level(resolved.level)
    log_format = resolved.log_format.lower()
    service_name = resolved.service_name

    def add_service(
        _: Any, __: str, event_dict: MutableMapping[str, Any]
    ) -> MutableMapping[str, Any]:
        event_dict.setdefault("service", service_name)
        return event_dict

    processors = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_logger_name,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso", utc=True, key="timestamp"),
        add_service,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
    ]

    structlog.configure(
        processors=processors,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    if log_format == "console":
        stream_renderer = structlog.dev.ConsoleRenderer()
    elif log_format == "auto":
        stream_renderer = (
            structlog.dev.ConsoleRenderer()
            if sys.stdout.isatty()
            else structlog.processors.JSONRenderer()
        )
    else:
        stream_renderer = structlog.processors.JSONRenderer()
    file_renderer = structlog.processors.JSONRenderer()

    foreign_pre_chain = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_logger_name,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso", utc=True, key="timestamp"),
        add_service,
    ]

    stream_formatter = structlog.stdlib.ProcessorFormatter(
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            stream_renderer,
        ],
        foreign_pre_chain=foreign_pre_chain,
    )
    file_formatter = structlog.stdlib.ProcessorFormatter(
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            file_renderer,
        ],
        foreign_pre_chain=foreign_pre_chain,
    )

    root = logging.getLogger()
    root.setLevel(level)
    _remove_phlo_handlers(root)

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setLevel(level)
    stream_handler.setFormatter(stream_formatter)
    _mark_phlo_handler(stream_handler)
    root.addHandler(stream_handler)

    if resolved.log_file_template:
        file_handler = _build_file_handler(resolved.log_file_template, file_formatter)
        if file_handler is not None:
            file_handler.setLevel(level)
            _mark_phlo_handler(file_handler)
            root.addHandler(file_handler)

    if resolved.router_enabled:
        router_handler = LogRouterHandler(service_name=service_name, level=level)
        _mark_phlo_handler(router_handler)
        root.addHandler(router_handler)

    logging.captureWarnings(True)
    _LOGGING_CONFIGURED = True


def get_logger(
    name: str | None = None, *, service: str | None = None
) -> structlog.stdlib.BoundLogger:
    """Return a structlog logger, configuring logging on first use."""

    if not _LOGGING_CONFIGURED:
        setup_logging()
    logger = structlog.get_logger(name)
    if service:
        return logger.bind(service=service)
    return logger


def bind_context(**fields: Any) -> None:
    """Bind fields to the current contextvars scope for structured logging."""

    structlog.contextvars.bind_contextvars(**fields)


def clear_context() -> None:
    """Clear all structlog contextvars fields for the current scope."""

    structlog.contextvars.clear_contextvars()


@contextmanager
def suppress_log_routing() -> Any:
    """Temporarily disable log routing to the hook bus."""

    token = _ROUTER_ACTIVE.set(True)
    try:
        yield
    finally:
        _ROUTER_ACTIVE.reset(token)


class LogRouterHandler(logging.Handler):
    """Route log records to the hook bus as LogEvent payloads."""

    def __init__(self, *, service_name: str, level: int = logging.NOTSET) -> None:
        super().__init__(level=level)
        self._service_name = service_name

    def emit(self, record: logging.LogRecord) -> None:
        if _ROUTER_ACTIVE.get():
            return
        token = _ROUTER_ACTIVE.set(True)
        try:
            event = _record_to_event(record, self._service_name)
            if event is None:
                return
            from phlo.hooks.bus import get_hook_bus

            get_hook_bus().emit(event)
        except Exception:
            self.handleError(record)
        finally:
            _ROUTER_ACTIVE.reset(token)


def _record_to_event(record: logging.LogRecord, default_service: str) -> LogEvent | None:
    message, extra = _extract_message_and_extra(record)
    if message is None:
        return None

    service = _pop_value(extra, "service") or default_service
    tags = _pop_tags(extra)
    if service:
        tags.setdefault("service", service)

    correlation = {field: _pop_value(extra, field) for field in _CORRELATION_FIELDS}
    metadata = _build_metadata(record, extra)

    return LogEvent(
        event_type="log.record",
        timestamp=datetime.fromtimestamp(record.created, tz=timezone.utc),
        logger=record.name,
        level=record.levelname.lower(),
        message=message,
        service=service,
        run_id=correlation.get("run_id"),
        asset_key=correlation.get("asset_key"),
        job_name=correlation.get("job_name"),
        partition_key=correlation.get("partition_key"),
        check_name=correlation.get("check_name"),
        metadata=metadata,
        tags=tags,
    )


def _extract_message_and_extra(
    record: logging.LogRecord,
) -> tuple[str | None, dict[str, Any]]:
    extra = {
        key: value
        for key, value in record.__dict__.items()
        if key not in _STANDARD_LOG_RECORD_FIELDS and not key.startswith("_")
    }

    event_dict: dict[str, Any] | None = None
    if isinstance(record.msg, Mapping):
        event_dict = dict(record.msg)
    elif isinstance(record.msg, (list, tuple)) and len(record.msg) == 1:
        if isinstance(record.msg[0], Mapping):
            event_dict = dict(record.msg[0])

    if event_dict:
        extra.update(event_dict)
        message = str(event_dict.pop("event", ""))
    else:
        message = record.getMessage()

    message = message.strip()
    if not message:
        return None, extra
    extra.pop("event", None)
    extra.pop("level", None)
    extra.pop("timestamp", None)
    extra.pop("logger", None)
    return message, extra


def _build_metadata(record: logging.LogRecord, extra: dict[str, Any]) -> dict[str, Any]:
    metadata = {
        **extra,
        "module": record.module,
        "function": record.funcName,
        "line": record.lineno,
        "pathname": record.pathname,
        "process": record.process,
        "thread": record.thread,
    }
    if record.exc_info:
        metadata["exception"] = "".join(traceback.format_exception(*record.exc_info))
    return metadata


def _build_file_handler(
    template: str,
    formatter: logging.Formatter,
) -> logging.Handler | None:
    path = _render_log_file_path(template)
    if path is None:
        return None
    handler = logging.FileHandler(path, encoding="utf-8")
    handler.setFormatter(formatter)
    return handler


def _render_log_file_path(template: str) -> Path | None:
    now = datetime.now(timezone.utc)
    tokens = {
        "YMD": now.strftime("%Y%m%d"),
        "YM": now.strftime("%Y%m"),
        "Y": now.strftime("%Y"),
        "YYYY": now.strftime("%Y"),
        "M": now.strftime("%m"),
        "MM": now.strftime("%m"),
        "D": now.strftime("%d"),
        "DD": now.strftime("%d"),
        "H": now.strftime("%H"),
        "HM": now.strftime("%H%M"),
        "HMS": now.strftime("%H%M%S"),
        "DATE": now.strftime("%Y-%m-%d"),
        "TIMESTAMP": now.strftime("%Y%m%d%H%M%S"),
    }
    try:
        rendered = template.format(**tokens)
    except KeyError as exc:
        logging.getLogger(__name__).warning(
            "Unknown log file template placeholder: %s",
            exc,
        )
        return None
    path = Path(rendered)
    if not path.is_absolute():
        project_root = os.environ.get("PHLO_PROJECT_PATH")
        base_path = Path(project_root) if project_root else Path.cwd()
        path = base_path / path
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _pop_tags(extra: dict[str, Any]) -> dict[str, str]:
    tags_value = extra.pop("tags", None)
    if isinstance(tags_value, Mapping):
        return {str(key): str(value) for key, value in tags_value.items()}
    return {}


def _pop_value(extra: dict[str, Any], key: str) -> str | None:
    value = extra.pop(key, None)
    if value is None:
        return None
    return str(value)


def _coerce_log_level(level: str) -> int:
    return logging._nameToLevel.get(level.upper(), logging.INFO)


def _mark_phlo_handler(handler: logging.Handler) -> None:
    setattr(handler, "_phlo_handler", True)


def _remove_phlo_handlers(root: logging.Logger) -> None:
    for handler in list(root.handlers):
        if getattr(handler, "_phlo_handler", False):
            root.removeHandler(handler)
