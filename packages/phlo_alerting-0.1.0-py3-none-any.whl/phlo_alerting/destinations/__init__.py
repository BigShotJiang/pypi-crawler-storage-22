"""Alert destination implementations."""
