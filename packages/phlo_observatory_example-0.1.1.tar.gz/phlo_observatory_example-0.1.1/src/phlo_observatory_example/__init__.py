"""Example Observatory extension package."""
