# Architecture Overview - phononkit

## Vision
phononkit is a modular Python library for phonon analysis, refactored from the monolithic phonproj package. It emphasizes clean separation of concerns, type safety, and maintainability.

## Layered Architecture

The package follows a strict layered dependency architecture to prevent circular dependencies and promote modularity.

### Layer 0: Foundation (No Dependencies)
- **core**: Foundational types (TypedDict contracts) and physical constants.
- **qpoints**: Pure mathematical operations for q-point grids, commensurate points, and paths.

### Layer 1: Domain Model (Depends on Layer 0)
- **modes**: Core representation of phonon modes (`PhononMode`, `PhononModeCollection`) and gauge transformations.

### Layer 2: Operations (Depends on Layers 0 & 1)
- **displacements**: Algorithms for generating atomic displacements and thermal patterns.
- **projections**: Mass-weighted projections and orthonormality verification.
- **supercells**: Logic for building supercells and handling phase factors.
- **analysis**: High-level structural and symmetry analysis.
- **io**: Data import/export (phonopy integration, MCIF export).

## Design Principles

1. **Focused Modules**: Each module has a single responsibility and is kept under 500 lines.
2. **Type-Safe Boundaries**: Modules communicate via explicit TypedDict contracts defined in `core.types`.
3. **Immutability**: Preference for returning new objects rather than modifying in-place (e.g., `PhononMode.copy()`).
4. **LLM-Friendly**: Clear directory structure, explicit interfaces, and comprehensive docstrings.

## Key Data Structures

- **PhononMode**: Represents a single vibrational mode at a q-point.
- **PhononModeCollection**: A managed group of modes with filtering capabilities.
- **Atoms (ASE)**: Standard structure representation used throughout.

## Workflow Pattern

Typical usage involves:
1. Loading data via `io.phonopy_loader`.
2. Managing modes via `modes.PhononModeCollection`.
3. Performing operations like `displacements.generate_displacement` or `projections.project_onto_modes`.
4. Exporting results via `io.mcif`.
