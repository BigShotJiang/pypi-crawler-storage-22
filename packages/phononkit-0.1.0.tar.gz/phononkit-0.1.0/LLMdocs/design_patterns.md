# Design Patterns - phononkit

This document describes the common design patterns and coding conventions used in phononkit.

## Functional Core, Imperative Shell

Most core logic in phononkit is implemented as pure functions that operate on data structures (`PhononMode`, `Atoms`, `numpy` arrays). This makes the code easier to test and reason about.

```python
# Functional core
displacement = generate_displacement(mode, amplitude)

# Imperative shell (I/O, object creation)
save_mcif_file(modes, filename="modes.mcif")
```

## Immutable Data Representations

While `numpy` arrays and ASE `Atoms` are mutable, the library prefers returning new objects.

```python
# Correct: Returns a new object
new_mode = transform_phonon_mode_gauge(mode, 'r')

# Avoid: Modifying in place
# mode.eigenvector = transformed_eigvec
```

## Type Hinting and Static Analysis

Every function and class is fully type-hinted. We use `TypedDict` for complex data structures to balance flexibility with static safety.

- **Strict Mode**: The project aims for 100% compliance with `pyright` strict mode.
- **Generic Types**: Generic `np.ndarray` are used with shape comments for clarity.

## Unit Testing Patterns

We follow a systematic testing pattern:

1. **Property-Based Testing**: Validating mathematical constraints (e.g., orthonormality) rather than just comparing to saved outputs.
2. **Numerical Equivalence**: Migrated tests from phonproj validate that the refactored code produces identical results for identical inputs.
3. **Fixture-Based**: Standard test structures and data are shared via `tests/conftest.py`.

## Coding Style

- **PEP 8 Compliance**: Strictly followed.
- **Numpy-style Docstrings**: Used for all public functions and classes.
- **Modularization**: No file exceeds 500 lines. If a file grows too large, it is split into logical sub-modules.
