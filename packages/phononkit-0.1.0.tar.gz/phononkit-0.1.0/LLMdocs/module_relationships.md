# Module Relationships - phononkit

This document details how modules in phononkit interact and the data contracts between them.

## Dependency Graph

```mermaid
graph TD
    subgraph Layer 0
        core[core]
        qpoints[qpoints]
    end

    subgraph Layer 1
        modes[modes]
    end

    subgraph Layer 2
        displacements[displacements]
        projections[projections]
        supercells[supercells]
        analysis[analysis]
        io[io]
    end

    modes --> core
    displacements --> modes
    displacements --> core
    projections --> modes
    projections --> core
    supercells --> modes
    supercells --> qpoints
    analysis --> modes
    analysis --> supercells
    io --> modes
    io --> analysis
```

## Data Contracts (TypedDict)

Modules communicate using `TypedDict` objects defined in `phononkit.core.types`. This ensures type safety and documentation of data structures.

### `PhononModeData`
- **Source**: `io.phonopy_loader`
- **Consumer**: `modes.PhononMode`
- **Fields**: `frequencies`, `eigenvectors`, `qpoint`, `structure`

### `DisplacementData`
- **Source**: `displacements.generator`
- **Consumer**: `supercells.builder`, `io.mcif`
- **Fields**: `displacement`, `amplitude`, `mode_index`

### `ProjectionResult`
- **Source**: `projections.mass_weighted`
- **Consumer**: `analysis.symmetry`
- **Fields**: `coefficients`, `residual`

## Integration Points

### Phonopy Integration
`phononkit.io.phonopy_loader` uses the `phonopy` library to load YAML files and converts them into `PhononMode` objects. It is the primary entry point for external data.

### ASE Integration
ASE `Atoms` objects are used for structure representation. All modules that handle atomic positions or cells depend on `ase`.

### Supercell-Qpoint Relationship
`supercells.builder` uses `qpoints.commensurate` to validate that a supercell can properly represent a specific q-point.
