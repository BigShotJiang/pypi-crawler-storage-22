# Phonon Kit Examples

This directory contains practical examples demonstrating how to use phononkit with real phonopy data.

## Available Examples

### 1. Mode Decomposition (`mode_decomposition.py`)
**What it does:** Loads real phonon data and performs complete analysis

**Key features:**
- Load phonon modes from phonopy YAML file
- Display mode summary with frequencies
- Filter modes by frequency
- Generate thermal displacements at 300K
- Export to MCIF format for visualization

**Run it:**
```bash
python examples/mode_decomposition.py
```

**Output:**
- Console output with mode information
- MCIF file for visualization in VESTA

### 2. Supercell Analysis (`supercell_analysis.py`)
**What it does:** Demonstrates supercell construction and q-point analysis

**Key features:**
- Build supercells from primitive cells
- Check q-point commensurability
- Apply phase factors to modes

**Run it:**
```bash
python examples/supercell_analysis.py
```

## Data Files

The `data/` directory contains real phonopy YAML files:

- **phonopy.yaml**: PbTiO3 (Lead Titanate) phonon data
  - 5 atoms per primitive cell
  - 15 phonon modes
  - Includes force constants and eigenvectors

You can use your own phonopy YAML files by replacing the path in the examples.

## Requirements

Install phononkit first:
```bash
pip install phononkit
```

Or install from source:
```bash
cd /path/to/phonon_kit
pip install -e .
```

## Quick Start

The fastest way to get started:

```python
from phononkit import load_from_phonopy_yaml
from phononkit import generate_thermal_structure

# Load your data
structure, modes = load_from_phonopy_yaml('path/to/phonopy_params.yaml')

# Generate thermal structure at 300K
thermal = generate_thermal_structure(modes, temperature=300.0)

# Save it
from ase.io import write
write('thermal.vasp', thermal)
```

## Visualization

### MCIF Files
MCIF files can be opened in:
- **VESTA** (recommended): https://jp-minerals.org/vesta/
- **Jmol**: http://jmol.sourceforge.net/
- **Ovito**: https://www.ovito.org/

### VASP Files
VASP POSCAR files can be viewed in:
- VESTA
- ASE GUI: `ase gui thermal.vasp`
- Any crystallographic viewer

## Customizing Examples

### Using Your Own Data

Replace the path in the examples:
```python
# Change this line
yaml_path = Path(__file__).parent / "data" / "phonopy.yaml"

# To your own data file
yaml_path = Path("/path/to/your/phonopy_params.yaml")
```

### Changing Temperature

Modify the temperature parameter:
```python
# Room temperature
thermal = generate_thermal_structure(modes, temperature=300.0)

# High temperature
thermal = generate_thermal_structure(modes, temperature=800.0)

# Low temperature
thermal = generate_thermal_structure(modes, temperature=50.0)
```

### Filtering Different Modes

Filter by frequency range:
```python
# Only acoustic modes (< 3 THz)
acoustic = modes.filter_by_frequency(freq_max=3.0)

# Optical modes only
optical = modes.filter_by_frequency(freq_min=3.0, freq_max=15.0)

# Specific range
specific = modes.filter_by_frequency(freq_min=5.0, freq_max=10.0)
```

## Troubleshooting

### File not found
Make sure the YAML file exists:
```python
from pathlib import Path

yaml_file = Path('phonopy_params.yaml')
if yaml_file.exists():
    structure, modes = load_from_phonopy_yaml(str(yaml_file))
else:
    print(f"File not found: {yaml_file}")
```

### Import errors
If you get import errors, ensure phononkit is installed:
```bash
python -c "import phononkit; print(phononkit.__version__)"
```

### Complex number warnings
ASE may warn about complex displacements. This is normal - the real part is used for visualization and is physically meaningful.

## Next Steps

1. Read the User Guide: `docs/user_guide/getting_started.md`
2. Check API documentation: `docs/api/`
3. Review methodology: `docs/methodology/`
4. Look at LLM docs: `LLMdocs/` (for AI/LLM integration)

## Support

- GitHub Issues: https://github.com/phonontools/phonon_kit/issues
- Documentation: See `docs/` directory
- Examples: You're looking at them!
