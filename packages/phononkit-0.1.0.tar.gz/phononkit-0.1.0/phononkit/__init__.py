"""phononkit - A clean, modular Python library for phonon analysis.

This package provides tools for:
- Phonon mode representation and analysis
- Displacement generation and projections
- Supercell operations with commensurate q-points
- Structure analysis and symmetry
- Data I/O (MCIF export, phonopy integration)

The package is organized into domain-driven modules:
- core: Type definitions and constants
- qpoints: Q-point mathematics and grids
- modes: Phonon mode representation
- displacements: Displacement generation
- projections: Mass-weighted projections
- supercells: Supercell operations
- analysis: Structure analysis and symmetry
- io: Data import/export

All modules follow single responsibility principle (< 500 lines per file)
and strict layering with no circular dependencies.
"""

__version__ = "0.1.0"

from typing import Optional, List

from phononkit.modes import PhononMode, PhononModeCollection
from phononkit.displacements import (
    generate_displacement,
    generate_displaced_structure,
    generate_mode_displacement,
    generate_thermal_displacement,
    generate_thermal_structure,
)
from phononkit.io import (
    load_from_phonopy_yaml,
    create_mode_from_phonopy_data,
    export_to_mcif,
    save_mcif_file,
)
from phononkit.supercells import (
    build_supercell,
    build_supercell_for_qpoint,
    create_supercell_mode,
)
from phononkit.qpoints import (
    is_commensurate_qpoint,
    find_commensurate_qpoints,
    validate_supercell_commensurability,
)


def generate_structure_for_mode(
    yaml_path: str,
    qpoint: List,
    mode_index: int,
    amplitude: float = 1.0,
    supercell: Optional[List] = None,
):
    """Generate displaced structure for a specific phonon mode.

    Simple one-function API to load phonon data and generate a displaced
    structure for a specific mode at a given q-point, optionally in a supercell.

    Parameters:
        yaml_path: Path to phonopy YAML file
        qpoint: Q-point coordinates [qx, qy, qz] (e.g., [0, 0, 0] for Gamma)
        mode_index: Index of the mode at that q-point (0-based)
        amplitude: Displacement amplitude in Angstroms (default: 1.0)
        supercell: Supercell specification (optional):
            - 3-vector [n1, n2, n3] for diagonal matrix (e.g., [2, 2, 2])
            - Full 3x3 matrix [[n1, 0, 0], [0, n2, 0], [0, 0, n3]]
            If None, uses primitive cell

    Returns:
        ASE Atoms object with displacements applied

    Examples:
        >>> # Primitive cell - 3rd mode at Gamma with 0.5 Å amplitude
        >>> structure = generate_structure_for_mode(
        ...     'phonopy_params.yaml',
        ...     qpoint=[0, 0, 0],
        ...     mode_index=2,
        ...     amplitude=0.5
        ... )

        >>> # 2x2x2 Supercell using diagonal notation
        >>> structure = generate_structure_for_mode(
        ...     'phonopy_params.yaml',
        ...     qpoint=[0, 0, 0],
        ...     mode_index=2,
        ...     amplitude=0.5,
        ...     supercell=[2, 2, 2]
        ... )

        >>> # Save to file
        >>> from ase.io import write
        >>> write('displaced.vasp', structure)
    """
    import numpy as np

    # Load phonon data
    primitive_structure, modes = load_from_phonopy_yaml(yaml_path)

    # Filter modes by q-point
    qpoint_array = np.array(qpoint)
    qpoint_modes = modes.filter_by_qpoint(qpoint_array)

    # Check if mode_index is valid
    if mode_index >= qpoint_modes.n_modes:
        raise ValueError(
            f"Mode index {mode_index} out of range. "
            f"Only {qpoint_modes.n_modes} modes at q-point {qpoint}."
        )

    # Select the mode
    selected_mode = qpoint_modes[mode_index]

    # Handle supercell
    if supercell is not None:
        supercell_array = np.array(supercell)

        # Convert 3-vector to 3x3 diagonal matrix
        if supercell_array.ndim == 1 and len(supercell_array) == 3:
            supercell_matrix = np.diag(supercell_array)
        elif supercell_array.shape == (3, 3):
            supercell_matrix = supercell_array
        else:
            raise ValueError(
                f"Invalid supercell format. "
                f"Expected 3-vector [n1,n2,n3] or 3x3 matrix, got {supercell}"
            )

        # Create supercell mode (handles tiling and phase factors)
        from phononkit.supercells import create_supercell_mode

        supercell_mode = create_supercell_mode(selected_mode, supercell_matrix)

        # Generate displacement for supercell mode
        displaced_structure = generate_mode_displacement(supercell_mode, amplitude)
    else:
        # Use primitive mode directly
        displaced_structure = generate_mode_displacement(selected_mode, amplitude)

    return displaced_structure


__all__ = [
    "__version__",
    "PhononMode",
    "PhononModeCollection",
    "generate_structure_for_mode",  # Simple API
    "generate_displacement",
    "generate_displaced_structure",
    "generate_mode_displacement",
    "generate_thermal_displacement",
    "generate_thermal_structure",
    "load_from_phonopy_yaml",
    "create_mode_from_phonopy_data",
    "export_to_mcif",
    "save_mcif_file",
    "build_supercell",
    "build_supercell_for_qpoint",
    "create_supercell_mode",
    "is_commensurate_qpoint",
    "find_commensurate_qpoints",
    "validate_supercell_commensurability",
]
