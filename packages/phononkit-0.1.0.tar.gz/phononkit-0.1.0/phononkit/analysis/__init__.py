"""Structure analysis, species substitution, and symmetry.

This module provides:
- Atomic correspondence between structures
- Species substitution handling
- Symmetry analysis and irreducible representations
"""

from phononkit.analysis.structure import (
    find_atomic_correspondence,
    apply_atomic_mapping,
)
from phononkit.analysis.substitution import (
    create_substitution_map,
    validate_substitution,
)
from phononkit.analysis.symmetry import (
    find_degenerate_modes,
    classify_mode_symmetry,
    generate_mode_summary,
)
from phononkit.analysis.irreps import (
    analyze_irreps,
    IrRepsEigen,
)

__all__ = [
    "find_atomic_correspondence",
    "apply_atomic_mapping",
    "create_substitution_map",
    "validate_substitution",
    "find_degenerate_modes",
    "classify_mode_symmetry",
    "generate_mode_summary",
    "analyze_irreps",
    "IrRepsEigen",
]
