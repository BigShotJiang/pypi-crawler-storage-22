"""Structure matching and atomic correspondence.

This module provides functions for finding atomic correspondences
between related structures.
"""

import numpy as np
from ase import Atoms
from typing import Tuple, List


def find_atomic_correspondence(
    structure1: Atoms, structure2: Atoms, tol: float = 0.1
) -> Tuple[np.ndarray, np.ndarray]:
    """Find atomic correspondence between two structures.

    Matches atoms by finding the closest atoms in structure2 to each
    atom in structure1 based on positions.

    Parameters:
        structure1: First structure
        structure2: Second structure to match to
        tol: Position matching tolerance in Angstroms

    Returns:
        (mapping, distances) - Mapping from structure1 to structure2 and distances

    Examples:
        >>> mapping, dists = find_atomic_correspondence(atoms1, atoms2)
        >>> mapping.shape
        (4,)
    """
    if len(structure1) != len(structure2):
        raise ValueError(
            f"Structures must have same number of atoms: "
            f"{len(structure1)} vs {len(structure2)}"
        )

    mapping = np.zeros(len(structure1), dtype=int)
    distances = np.zeros(len(structure1))

    pos1 = structure1.get_positions()
    pos2 = structure2.get_positions()

    for i in range(len(structure1)):
        dists = np.linalg.norm(pos2 - pos1[i], axis=1)
        nearest_idx = int(np.argmin(dists))
        mapping[i] = nearest_idx
        distances[i] = dists[nearest_idx]

    return mapping, distances


def apply_atomic_mapping(displacement: np.ndarray, mapping: np.ndarray) -> np.ndarray:
    """Apply atomic mapping to a displacement array.

    Parameters:
        displacement: Original displacement, shape (n_atoms1, 3)
        mapping: Mapping from structure1 indices to structure2 indices

    Returns:
        Mapped displacement, shape (n_atoms2, 3)

    Examples:
        >>> mapped = apply_atomic_mapping(disp1, mapping)
    """
    n_atoms1, n_dim = displacement.shape

    if len(mapping) != n_atoms1:
        raise ValueError(
            f"Mapping length ({len(mapping)}) must match displacement rows ({n_atoms1})"
        )

    mapped = np.zeros((n_atoms1, n_dim))

    for i, target_idx in enumerate(mapping):
        for j in range(n_atoms1):
            if mapping[j] == target_idx:
                mapped[j] = displacement[i]

    return mapped


def substitute_species(structure: Atoms, substitution_map: dict) -> Atoms:
    """Apply species substitution to a structure.

    Parameters:
        structure: Original atomic structure
        substitution_map: Dictionary mapping old species to new species
                          e.g., {'Ti': 'Zr', 'O': 'O'}

    Returns:
        New structure with substituted species

    Examples:
        >>> new_structure = substitute_species(old_structure, {'Fe': 'Co'})
    """
    new_structure = structure.copy()
    symbols = np.array(new_structure.get_chemical_symbols())

    for old_species, new_species in substitution_map.items():
        symbols[symbols == old_species] = new_species

    new_structure.set_chemical_symbols(symbols)

    return new_structure
