"""Core type definitions and constants.

This module provides foundational data structures and physical constants
used throughout the phononkit package.
"""

from phononkit.core.types import (
    PhononModeData,
    DisplacementData,
    ProjectionResult,
    SupercellData,
    QpointGridData,
)
from phononkit.core.constants import (
    AMU,
    H,
    HBAR,
    KB,
    ME,
    BOHR,
    C,
    RY,
    ANGSTROM_TO_METER,
    METER_TO_ANGSTROM,
    THZ_TO_JOULE,
    JOULE_TO_THZ,
    THZ_TO_MEV,
    MEV_TO_THZ,
    AMU_TO_KG,
    KG_TO_AMU,
    ANGSTROM_INV_TO_METER_INV,
    PI,
)

__all__ = [
    # Type definitions
    "PhononModeData",
    "DisplacementData",
    "ProjectionResult",
    "SupercellData",
    "QpointGridData",
    # Constants
    "AMU",
    "H",
    "HBAR",
    "KB",
    "ME",
    "BOHR",
    "C",
    "RY",
    "ANGSTROM_TO_METER",
    "METER_TO_ANGSTROM",
    "THZ_TO_JOULE",
    "JOULE_TO_THZ",
    "THZ_TO_MEV",
    "MEV_TO_THZ",
    "AMU_TO_KG",
    "KG_TO_AMU",
    "ANGSTROM_INV_TO_METER_INV",
    "PI",
]
