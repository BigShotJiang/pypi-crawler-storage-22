"""Physical constants and conversion factors for phonon analysis.

This module defines commonly used physical constants with units and references
to ensure consistency across the codebase.

All constants are in SI units unless otherwise noted.
"""

import numpy as np


# Atomic mass unit (kg)
AMU = 1.66053906660e-27


# Planck constant (J*s)
H = 6.62607015e-34


# Reduced Planck constant (J*s)
HBAR = H / (2.0 * np.pi)


# Boltzmann constant (J/K)
KB = 1.380649e-23


# Electron mass (kg)
ME = 9.1093837015e-31


# Bohr radius (m)
BOHR = 5.29177210903e-11


# Speed of light in vacuum (m/s)
C = 299792458.0


# Rydberg constant (J)
RY = 13.605693122994 * 1.602176634e-19


# Angstrom to meter conversion
ANGSTROM_TO_METER = 1.0e-10


# Meter to Angstrom conversion
METER_TO_ANGSTROM = 1.0 / ANGSTROM_TO_METER


# THz to Joule conversion factor (E = h * f)
THZ_TO_JOULE = H * 1e12


# Joule to THz conversion factor
JOULE_TO_THZ = 1.0 / THZ_TO_JOULE


# THz to meV conversion factor (E = h * f / e)
THZ_TO_MEV = (H * 1e12) / 1.602176634e-22


# meV to THz conversion factor
MEV_TO_THZ = 1.0 / THZ_TO_MEV


# Atomic mass unit to kg
AMU_TO_KG = AMU


# kg to atomic mass unit
KG_TO_AMU = 1.0 / AMU


# Angstrom^-1 to meter^-1 conversion
ANGSTROM_INV_TO_METER_INV = 1.0e10


# pi
PI = np.pi
