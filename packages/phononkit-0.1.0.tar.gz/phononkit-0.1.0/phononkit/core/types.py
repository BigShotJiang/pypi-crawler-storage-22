"""Core type definitions for phononkit module boundaries.

This module defines TypedDict contracts for data exchange between modules,
ensuring type-safe interfaces and explicit data structure expectations.
"""

from typing import TypedDict, Any
import numpy as np
from ase import Atoms


class PhononModeData(TypedDict):
    """Type-safe contract for phonon mode data.

    Used for passing phonon mode information between modules (e.g., from io.phonopy_loader
    to modes.PhononMode).

    Attributes:
        frequencies: Array of phonon frequencies in THz, shape (n_modes,)
        eigenvectors: Complex eigenvectors, shape (n_modes, n_atoms * 3)
        qpoint: Q-point in reduced coordinates, shape (3,)
        structure: Atomic structure with positions and masses
    """

    frequencies: np.ndarray
    eigenvectors: np.ndarray
    qpoint: np.ndarray
    structure: Atoms


class DisplacementData(TypedDict):
    """Type-safe contract for displacement generation results.

    Used for passing displacement data between modules (e.g., from
    displacements.generator to supercells.builder).

    Attributes:
        displacement: Atomic displacements in Cartesian coordinates, shape (n_atoms, 3)
        amplitude: Displacement amplitude in Angstroms
        mode_index: Index of the phonon mode (if applicable)
    """

    displacement: np.ndarray
    amplitude: float
    mode_index: int


class ProjectionResult(TypedDict):
    """Type-safe contract for projection calculations.

    Used for passing projection results between modules (e.g., from
    projections.mass_weighted to analysis modules).

    Attributes:
        coefficients: Projection coefficients for each mode, shape (n_modes,)
        residual: Projection error / residual after reconstruction
    """

    coefficients: np.ndarray
    residual: float


class SupercellData(TypedDict):
    """Type-safe contract for supercell construction.

    Used for passing supercell data between modules (e.g., from
    supercells.builder to displacement generation).

    Attributes:
        supercell: Supercell atomic structure
        supercell_matrix: 3x3 transformation matrix
        commensurate_qpoints: Array of commensurate q-points
    """

    supercell: Atoms
    supercell_matrix: np.ndarray
    commensurate_qpoints: np.ndarray


class QpointGridData(TypedDict):
    """Type-safe contract for q-point grid data.

    Used for passing q-point grid information between modules.

    Attributes:
        qpoints: Array of q-points in reduced coordinates, shape (n_qpoints, 3)
        weights: Integration weights for each q-point, shape (n_qpoints,)
        grid_dimensions: Grid dimensions (n1, n2, n3)
    """

    qpoints: np.ndarray
    weights: np.ndarray
    grid_dimensions: tuple[int, int, int]
