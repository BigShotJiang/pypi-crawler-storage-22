"""Displacement generation for phonon modes.

This module provides functions for generating atomic displacements
from phonon modes.
"""

import numpy as np
from ase import Atoms

from phononkit.modes.mode import PhononMode
from phononkit.core.constants import AMU_TO_KG


def generate_displacement(mode: PhononMode, amplitude: float = 1.0) -> np.ndarray:
    """Generate atomic displacement for a phonon mode.

    Parameters:
        mode: PhononMode to generate displacement for
        amplitude: Displacement amplitude in Angstroms

    Returns:
        Atomic displacements in Cartesian coordinates, shape (n_atoms, 3)

    Examples:
        >>> displacement = generate_displacement(mode, amplitude=1.0)
        >>> displacement.shape
        (4, 3)
    """
    n_atoms = mode.n_atoms

    if n_atoms == 0:
        raise ValueError("Mode has no atoms")

    displacement = amplitude * mode.eigenvector.reshape(n_atoms, 3)

    return displacement


def generate_displaced_structure(
    structure: Atoms,
    displacement: np.ndarray,
) -> Atoms:
    """Generate a structure with atomic displacements applied.

    Parameters:
        structure: Original atomic structure
        displacement: Atomic displacements in Cartesian coordinates, shape (n_atoms, 3)

    Returns:
        New Atoms object with displacements applied

    Examples:
        >>> new_atoms = generate_displaced_structure(atoms, displacement)
    """
    if len(structure) != displacement.shape[0]:
        raise ValueError(
            f"Structure has {len(structure)} atoms but "
            f"displacement has {displacement.shape[0]} rows"
        )

    new_structure = structure.copy()
    new_structure.positions = structure.positions + displacement

    return new_structure


def generate_mode_displacement(mode: PhononMode, amplitude: float = 1.0) -> Atoms:
    """Generate a displaced structure from a phonon mode.

    Parameters:
        mode: PhononMode to generate displacement for
        amplitude: Displacement amplitude in Angstroms

    Returns:
        New Atoms object with mode displacement applied

    Examples:
        >>> displaced_atoms = generate_mode_displacement(mode, amplitude=1.0)
    """
    displacement = generate_displacement(mode, amplitude)
    displaced_structure = generate_displaced_structure(mode.structure, displacement)

    return displaced_structure
