"""Thermal displacement pattern generation.

This module provides functions for generating thermal displacement
patterns at specified temperatures using Bose-Einstein statistics.
"""

import numpy as np
from ase import Atoms
from typing import Optional

from phononkit.modes.mode import PhononMode
from phononkit.modes.collection import PhononModeCollection
from phononkit.displacements.generator import generate_displacement
from phononkit.core.constants import KB, THZ_TO_JOULE, HBAR


def bose_einstein(frequencies: np.ndarray, temperature: float) -> np.ndarray:
    """Calculate Bose-Einstein occupation factors.

    Parameters:
        frequencies: Mode frequencies in THz, shape (n_modes,)
        temperature: Temperature in Kelvin

    Returns:
        Occupation factors for each mode, shape (n_modes,)

    Examples:
        >>> n = bose_einstein(np.array([1.0, 2.0, 3.0]), 300)
        >>> n[0]
        0.999...
    """
    if temperature <= 0:
        return np.zeros_like(frequencies)

    frequencies_joules = frequencies * THZ_TO_JOULE
    occupation = 1.0 / (np.exp(frequencies_joules / (KB * temperature)) - 1.0)

    return occupation


def generate_thermal_displacement(
    modes: PhononModeCollection, temperature: float = 300.0
) -> np.ndarray:
    """Generate thermal displacement pattern for a collection of modes.

    Parameters:
        modes: PhononModeCollection with multiple modes
        temperature: Temperature in Kelvin

    Returns:
        Thermal displacement pattern, shape (n_atoms, 3)

    Examples:
        >>> thermal_disp = generate_thermal_displacement(modes, temperature=300)
        >>> thermal_disp.shape
        (4, 3)
    """
    if modes.n_modes == 0:
        raise ValueError("No modes in collection")

    frequencies = modes.frequencies
    occupation = bose_einstein(frequencies, temperature)

    thermal_displacement = np.zeros((len(modes.modes[0].structure), 3))

    for mode, occ in zip(modes, occupation):
        eigenvector = mode.eigenvector.reshape(mode.n_atoms, 3)
        thermal_displacement += (
            occ
            * np.sqrt(HBAR / (2 * np.pi * np.abs(mode.frequency) * 1e12))
            * eigenvector
        )

    return thermal_displacement


def generate_thermal_structure(
    modes: PhononModeCollection, temperature: float = 300.0
) -> Atoms:
    """Generate a structure with thermal displacements applied.

    Parameters:
        modes: PhononModeCollection with multiple modes
        temperature: Temperature in Kelvin

    Returns:
        New Atoms object with thermal displacements applied

    Examples:
        >>> thermal_atoms = generate_thermal_structure(modes, temperature=300)
    """
    displacement = generate_thermal_displacement(modes, temperature)
    from phononkit.displacements.generator import generate_displaced_structure

    return generate_displaced_structure(modes.modes[0].structure, displacement)
