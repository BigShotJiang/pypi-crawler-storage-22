"""Phonopy YAML loader for creating PhononMode objects.

This module provides functionality to load phonon data from phonopy
YAML files and convert them to PhononMode objects.
"""

import numpy as np
from ase import Atoms
from pathlib import Path
from typing import List, Tuple

from phononkit.modes.mode import PhononMode
from phononkit.modes.collection import PhononModeCollection


def load_from_phonopy_yaml(yaml_path: str) -> Tuple[Atoms, PhononModeCollection]:
    """Load phonon data from a phonopy YAML file.

    Parameters:
        yaml_path: Path to phonopy YAML file

    Returns:
        (structure, modes) - Tuple of atomic structure and PhononModeCollection

    Raises:
        FileNotFoundError: If yaml_path does not exist
        ValueError: If YAML file format is invalid

    Examples:
        >>> structure, modes = load_from_phonopy_yaml('mesh.yaml')
        >>> len(modes)
        20
    """
    try:
        import phonopy
    except ImportError:
        raise ImportError(
            "phonopy is required to load YAML files. Install with: pip install phonopy"
        )

    phonopy_obj = phonopy.load(yaml_path, produce_fc=True)

    primitive = phonopy_obj.primitive
    structure = Atoms(
        symbols=primitive.symbols,
        scaled_positions=primitive.scaled_positions,
        cell=primitive.cell,
        masses=primitive.masses,
        pbc=True,
    )

    # Run mesh calculation to get frequencies and eigenvectors
    # Note: with_eigenvectors=True is required to get eigenvectors
    phonopy_obj.init_mesh()
    phonopy_obj.run_mesh(with_eigenvectors=True, is_mesh_symmetry=False)

    mesh_dict = phonopy_obj.get_mesh_dict()
    qpoints = mesh_dict["qpoints"]
    frequencies = mesh_dict["frequencies"]
    eigenvectors = mesh_dict["eigenvectors"]

    if eigenvectors is None:
        raise ValueError(
            "Eigenvectors are None. Check if phonopy data includes force constants."
        )

    n_qpoints = len(qpoints)
    n_modes_per_q = frequencies.shape[1] if len(frequencies.shape) > 1 else 1

    modes_list: List[PhononMode] = []

    for q_idx in range(n_qpoints):
        for mode_idx in range(n_modes_per_q):
            if len(frequencies.shape) == 2:
                freq = frequencies[q_idx, mode_idx]
                # Eigenvectors shape is (n_qpoints, n_modes, n_modes)
                # We need to extract the eigenvector for this mode
                eigvec = eigenvectors[q_idx, mode_idx, :]
            else:
                freq = frequencies[mode_idx]
                eigvec = eigenvectors[:, mode_idx]

            qpoint = qpoints[q_idx]

            mode = PhononMode(
                frequency=float(freq),
                eigenvector=eigvec,
                qpoint=qpoint,
                structure=structure,
                gauge="R",
            )

            modes_list.append(mode)

    modes_collection = PhononModeCollection(modes_list)

    return structure, modes_collection


def create_mode_from_phonopy_data(
    frequencies: np.ndarray,
    eigenvectors: np.ndarray,
    qpoint: np.ndarray,
    structure: Atoms,
    gauge: str = "R",
) -> PhononModeCollection:
    """Create PhononModeCollection from phonopy data arrays.

    Parameters:
        frequencies: Frequencies in THz, shape (n_modes,) or (n_qpoints, n_modes)
        eigenvectors: Eigenvectors, shape (n_modes, n_atoms*3) or
                      (n_qpoints, n_atoms, 3, n_modes)
        qpoint: Q-point in reduced coordinates, shape (3,)
        structure: Atomic structure
        gauge: Gauge convention ('R' or 'r'), default 'R'

    Returns:
        PhononModeCollection with all modes

    Examples:
        >>> modes = create_mode_from_phonopy_data(freqs, eigvecs, q, atoms)
    """
    n_atoms = len(structure)

    if len(frequencies.shape) == 1:
        n_modes = frequencies.shape[0]
        if eigenvectors.shape == (n_atoms * 3, n_modes):
            eigenvectors = eigenvectors.T
    else:
        if len(frequencies.shape) == 2:
            n_qpoints, n_modes = frequencies.shape
            if eigenvectors.shape[0] == n_modes:
                eigenvectors = eigenvectors.T
        else:
            n_modes = frequencies.shape[1]

    modes_list: List[PhononMode] = []

    for mode_idx in range(n_modes):
        if len(frequencies.shape) == 1:
            freq = frequencies[mode_idx]
            eigvec = eigenvectors[:, mode_idx]
        else:
            freq = frequencies[0, mode_idx]
            eigvec = eigenvectors[:, :, mode_idx]

        mode = PhononMode(
            frequency=float(freq),
            eigenvector=eigvec,
            qpoint=qpoint,
            structure=structure,
            gauge=gauge,
        )

        modes_list.append(mode)

    return PhononModeCollection(modes_list)
