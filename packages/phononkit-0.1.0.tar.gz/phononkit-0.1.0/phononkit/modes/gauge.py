"""Gauge transformation utilities for phonon modes.

This module provides functions for transforming phonon eigenvectors between
different gauge conventions (R and r gauges).
"""

import numpy as np
from ase import Atoms

from phononkit.modes.mode import PhononMode


def transform_eigenvector_gauge(
    eigenvector: np.ndarray,
    qpoint: np.ndarray,
    structure: Atoms,
    from_gauge: str,
    to_gauge: str,
) -> np.ndarray:
    """Transform eigenvector between R and r gauges.

    The R and r gauges differ by a phase factor that depends on
    q-point and atomic positions. The transformation is:

    R → r: Multiply by exp(-2πi * q · r)
    r → R: Multiply by exp(+2πi * q · r)

    Physical observables (e.g., atomic displacements) are gauge-invariant.

    Parameters:
        eigenvector: Eigenvector to transform, shape (n_atoms * 3,)
        qpoint: Q-point in reduced coordinates, shape (3,)
        structure: Atomic structure with positions
        from_gauge: Source gauge ('R' or 'r')
        to_gauge: Target gauge ('R' or 'r')

    Returns:
        Transformed eigenvector

    Raises:
        ValueError: If gauge values are not 'R' or 'r'
        ValueError: If from_gauge == to_gauge (no transformation needed)

    Examples:
        >>> eigvec_R = transform_eigenvector_gauge(eigvec_r, q, atoms, 'r', 'R')
    """
    if from_gauge not in ["R", "r"] or to_gauge not in ["R", "r"]:
        raise ValueError("gauge must be either 'R' or 'r'")

    if from_gauge == to_gauge:
        return eigenvector.copy()

    n_atoms = len(structure)
    if eigenvector.shape != (n_atoms * 3,):
        raise ValueError(
            f"eigenvector shape must be ({n_atoms * 3},), got {eigenvector.shape}"
        )

    if qpoint.shape != (3,):
        raise ValueError(f"qpoint shape must be (3,), got {qpoint.shape}")

    scaled_positions = structure.get_scaled_positions()

    sign = 1 if from_gauge == "r" else -1

    phases = np.exp(sign * 2j * np.pi * np.dot(scaled_positions, qpoint))

    phases_cartesian = np.repeat(phases, 3)

    transformed = eigenvector * phases_cartesian

    return transformed


def transform_phonon_mode_gauge(
    mode: PhononMode,
    new_gauge: str,
) -> PhononMode:
    """Transform a PhononMode to a different gauge.

    Parameters:
        mode: PhononMode to transform
        new_gauge: Target gauge ('R' or 'r')

    Returns:
        New PhononMode with transformed eigenvector

    Raises:
        ValueError: If gauge values are not 'R' or 'r'

    Examples:
        >>> mode_r = transform_phonon_mode_gauge(mode_R, 'r')
    """
    if new_gauge not in ["R", "r"]:
        raise ValueError("new_gauge must be either 'R' or 'r'")

    if mode.gauge == new_gauge:
        return mode.copy()

    transformed_eigvec = transform_eigenvector_gauge(
        mode.eigenvector,
        mode.qpoint,
        mode.structure,
        mode.gauge,
        new_gauge,
    )

    return PhononMode(
        frequency=mode.frequency,
        eigenvector=transformed_eigvec,
        qpoint=mode.qpoint,
        structure=mode.structure,
        atomic_masses=mode.atomic_masses,
        gauge=new_gauge,
    )
