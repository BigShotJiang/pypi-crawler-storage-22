"""Mass-weighted projection operations.

This module provides functions for mass-weighted projection of
displacements onto phonon modes.
"""

import numpy as np
from ase import Atoms
from typing import Tuple

from phononkit.modes.mode import PhononMode
from phononkit.modes.collection import PhononModeCollection
from phononkit.core.constants import AMU_TO_KG


def mass_weight_eigenvector(
    eigenvector: np.ndarray, atomic_masses: np.ndarray
) -> np.ndarray:
    """Apply mass weighting to eigenvector.

    Parameters:
        eigenvector: Eigenvector, shape (n_atoms * 3,)
        atomic_masses: Atomic masses in AMU, shape (n_atoms,)

    Returns:
        Mass-weighted eigenvector, shape (n_atoms * 3,)

    Examples:
        >>> weighted = mass_weight_eigenvector(eigvec, masses)
    """
    n_atoms = len(atomic_masses)

    if eigenvector.shape != (n_atoms * 3,):
        raise ValueError(
            f"eigenvector shape must be ({n_atoms * 3},), got {eigenvector.shape}"
        )

    masses_kg = atomic_masses * AMU_TO_KG
    masses_kg_sqrt = np.sqrt(masses_kg)

    masses_repeated = np.repeat(masses_kg_sqrt, 3)

    weighted = eigenvector * masses_repeated

    return weighted


def project_onto_modes(
    displacement: np.ndarray,
    modes: PhononModeCollection,
) -> Tuple[np.ndarray, float]:
    """Project displacement onto phonon modes.

    Parameters:
        displacement: Atomic displacement, shape (n_atoms, 3)
        modes: PhononModeCollection with target modes

    Returns:
        (coefficients, residual) - Projection coefficients and error

    Examples:
        >>> coeffs, error = project_onto_modes(displacement, modes)
    """
    n_atoms = len(modes.modes[0].structure)

    if displacement.shape != (n_atoms, 3):
        raise ValueError(
            f"displacement shape must be ({n_atoms}, 3), got {displacement.shape}"
        )

    coefficients = []
    for mode in modes:
        weighted_eigenvector = mass_weight_eigenvector(
            mode.eigenvector, mode.atomic_masses
        )
        weighted_eigenvector_flat = weighted_eigenvector.reshape(n_atoms, 3)

        inner_product = np.vdot(displacement.flatten(), weighted_eigenvector_flat)
        norm_squared = np.vdot(weighted_eigenvector_flat, weighted_eigenvector_flat)

        coeff = inner_product / norm_squared if norm_squared > 0 else 0.0

        coefficients.append(coeff)

    reconstructed = np.zeros(displacement.shape, dtype=complex)
    for coeff, mode in zip(coefficients, modes):
        weighted_eigenvector = mass_weight_eigenvector(
            mode.eigenvector, mode.atomic_masses
        )
        weighted_eigenvector_flat = weighted_eigenvector.reshape(n_atoms, 3)
        reconstructed += coeff * weighted_eigenvector_flat

    residual = float(
        np.linalg.norm(displacement - reconstructed.real) / np.linalg.norm(displacement)
    )

    return np.array(coefficients), residual
