"""Commensurate q-point operations for supercell construction.

This module provides functions for identifying and validating commensurate
q-points with respect to supercell matrices, which is essential for
phonon mode expansion in supercells.
"""

import numpy as np


def is_commensurate_qpoint(
    qpoint: np.ndarray, supercell_matrix: np.ndarray, tol: float = 1e-6
) -> bool:
    """Check if a q-point is commensurate with a supercell.

    A q-point q is commensurate with supercell matrix S if S^T @ q
    is an integer vector (i.e., the q-point maps onto the Brillouin
    zone boundary of the supercell).

    Parameters:
        qpoint: Q-point in reduced coordinates, shape (3,)
        supercell_matrix: 3x3 supercell transformation matrix
        tol: Tolerance for integer check

    Returns:
        True if q-point is commensurate, False otherwise

    Examples:
        >>> qpoint = np.array([0.5, 0.0, 0.0])
        >>> supercell_matrix = np.diag([2, 1, 1])  # 2x1x1 supercell
        >>> is_commensurate_qpoint(qpoint, supercell_matrix)
        True
    """
    if not np.allclose(qpoint, qpoint, atol=tol):
        return False

    supercell_qpoint = supercell_matrix.T @ qpoint

    return np.allclose(supercell_qpoint, np.round(supercell_qpoint), atol=tol)


def find_commensurate_qpoints(
    qpoints: np.ndarray, supercell_matrix: np.ndarray, tol: float = 1e-6
) -> np.ndarray:
    """Find commensurate q-points from a list.

    Parameters:
        qpoints: Array of q-points in reduced coordinates, shape (n_qpoints, 3)
        supercell_matrix: 3x3 supercell transformation matrix
        tol: Tolerance for integer check

    Returns:
        Boolean mask indicating which q-points are commensurate

    Examples:
        >>> qpoints = np.array([[0.5, 0.0, 0.0], [0.25, 0.0, 0.0]])
        >>> supercell_matrix = np.diag([2, 1, 1])
        >>> find_commensurate_qpoints(qpoints, supercell_matrix)
        array([ True, False])
    """
    if len(qpoints) == 0:
        return np.array([], dtype=bool)

    supercell_qpoints = qpoints @ supercell_matrix

    return np.all(
        np.isclose(supercell_qpoints, np.round(supercell_qpoints), atol=tol), axis=1
    )


def validate_supercell_commensurability(
    qpoints: np.ndarray, supercell_matrix: np.ndarray, tol: float = 1e-6
) -> bool:
    """Validate that all q-points in a set are commensurate with supercell.

    Parameters:
        qpoints: Array of q-points in reduced coordinates, shape (n_qpoints, 3)
        supercell_matrix: 3x3 supercell transformation matrix
        tol: Tolerance for integer check

    Returns:
        True if all q-points are commensurate, False otherwise

    Examples:
        >>> qpoints = np.array([[0.5, 0.0, 0.0], [0.0, 0.0, 0.0]])
        >>> supercell_matrix = np.diag([2, 1, 1])
        >>> validate_supercell_commensurability(qpoints, supercell_matrix)
        True
    """
    if len(qpoints) == 0:
        return True

    commensurate_mask = find_commensurate_qpoints(qpoints, supercell_matrix, tol)

    return np.all(commensurate_mask)


def get_commensurate_grid(
    supercell_matrix: np.ndarray, mesh: tuple[int, int, int], tol: float = 1e-6
) -> tuple[np.ndarray, np.ndarray]:
    """Generate a grid of commensurate q-points for a supercell.

    Parameters:
        supercell_matrix: 3x3 supercell transformation matrix
        mesh: Grid dimensions (n1, n2, n3)
        tol: Tolerance for integer check

    Returns:
        qpoints: Array of commensurate q-points, shape (n_qpoints, 3)
        weights: Integration weights for each q-point, shape (n_qpoints,)

    Examples:
        >>> supercell_matrix = np.diag([2, 1, 1])
        >>> qpoints, weights = get_commensurate_grid(supercell_matrix, (2, 2, 2))
        >>> len(qpoints)
        8
    """
    from phononkit.qpoints.grid import generate_monkhorst_pack_grid

    qpoints, weights = generate_monkhorst_pack_grid(mesh)

    commensurate_mask = find_commensurate_qpoints(qpoints, supercell_matrix, tol)

    return qpoints[commensurate_mask], weights[commensurate_mask]
