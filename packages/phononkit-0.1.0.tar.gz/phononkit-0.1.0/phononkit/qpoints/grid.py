"""Q-point grid generation for phonon calculations.

This module provides functions for generating uniform q-point grids
with appropriate integration weights, following conventions used in
phonopy and other phonon analysis packages.
"""

import numpy as np


def generate_monkhorst_pack_grid(
    mesh: tuple[int, int, int], shift: tuple[float, float, float] = (0.0, 0.0, 0.0)
) -> tuple[np.ndarray, np.ndarray]:
    """Generate Monkhorst-Pack q-point grid with integration weights.

    Parameters:
        mesh: Grid dimensions (n1, n2, n3)
        shift: Grid shift in reduced coordinates (dx, dy, dz)

    Returns:
        qpoints: Array of q-points in reduced coordinates, shape (n_qpoints, 3)
        weights: Integration weights for each q-point, shape (n_qpoints,)

    Examples:
        >>> qpoints, weights = generate_monkhorst_pack_grid((4, 4, 4))
        >>> qpoints.shape
        (64, 3)
    """
    n1, n2, n3 = mesh

    i, j, k = np.meshgrid(
        np.arange(n1, dtype=float),
        np.arange(n2, dtype=float),
        np.arange(n3, dtype=float),
        indexing="ij",
    )

    qpoints = np.stack(
        [
            (i + shift[0]) / n1,
            (j + shift[1]) / n2,
            (k + shift[2]) / n3,
        ],
        axis=-1,
    )
    qpoints = qpoints.reshape(-1, 3)

    weights = np.ones(len(qpoints)) / len(qpoints)

    return qpoints, weights


def generate_gamma_centered_grid(
    mesh: tuple[int, int, int], include_gamma: bool = True
) -> tuple[np.ndarray, np.ndarray]:
    """Generate gamma-centered q-point grid.

    Parameters:
        mesh: Grid dimensions (n1, n2, n3)
        include_gamma: Whether to include gamma point (0, 0, 0)

    Returns:
        qpoints: Array of q-points in reduced coordinates, shape (n_qpoints, 3)
        weights: Integration weights for each q-point, shape (n_qpoints,)

    Examples:
        >>> qpoints, weights = generate_gamma_centered_grid((4, 4, 4))
        >>> qpoints[0]  # Gamma point at origin
        array([0., 0., 0.])
    """
    n1, n2, n3 = mesh

    i, j, k = np.meshgrid(
        np.arange(n1, dtype=float),
        np.arange(n2, dtype=float),
        np.arange(n3, dtype=float),
        indexing="ij",
    )

    qpoints = np.stack(
        [
            i / (n1 if n1 > 1 else 1),
            j / (n2 if n2 > 1 else 1),
            k / (n3 if n3 > 1 else 1),
        ],
        axis=-1,
    )
    qpoints = qpoints.reshape(-1, 3)

    if not include_gamma:
        gamma_mask = ~np.all(np.isclose(qpoints, 0.0), axis=1)
        qpoints = qpoints[gamma_mask]

    weights = np.ones(len(qpoints)) / len(qpoints)

    return qpoints, weights


def reduce_qpoints_to_brillouin_zone(
    qpoints: np.ndarray, tol: float = 1e-6
) -> np.ndarray:
    """Reduce q-points to first Brillouin zone [-0.5, 0.5).

    Parameters:
        qpoints: Array of q-points in reduced coordinates, shape (n_qpoints, 3)
        tol: Tolerance for considering q-point outside BZ

    Returns:
        Reduced q-points in first Brillouin zone

    Examples:
        >>> qpoints = np.array([[0.75, 0.0, 0.0], [-0.75, 0.0, 0.0]])
        >>> reduced = reduce_qpoints_to_brillouin_zone(qpoints)
        >>> reduced
        array([[-0.25,  0.  ,  0.  ],
               [-0.25,  0.  ,  0.  ]])
    """
    reduced = qpoints.copy()

    for i in range(3):
        reduced[:, i] = np.where(
            reduced[:, i] > 0.5 + tol,
            reduced[:, i] - 1.0,
            reduced[:, i],
        )
        reduced[:, i] = np.where(
            reduced[:, i] <= -0.5 - tol,
            reduced[:, i] + 1.0,
            reduced[:, i],
        )

    return reduced
