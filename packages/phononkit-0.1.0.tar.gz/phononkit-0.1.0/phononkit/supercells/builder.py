"""Supercell construction utilities.

This module provides functions for building supercells from
primitive cells with proper phonon mode phase application.
"""

import numpy as np
from ase import Atoms
from typing import Tuple, Optional

from phononkit.modes.mode import PhononMode
from phononkit.qpoints.commensurate import is_commensurate_qpoint


def build_supercell(structure: Atoms, supercell_matrix: np.ndarray) -> Atoms:
    """Build a supercell from a primitive structure.

    Parameters:
        structure: Primitive unit cell structure
        supercell_matrix: 3x3 supercell transformation matrix

    Returns:
        Supercell Atoms object

    Examples:
        >>> supercell = build_supercell(primitive, np.diag([2, 1, 1]))
        >>> len(supercell)
        8
    """
    from ase.build import make_supercell

    supercell = make_supercell(structure, supercell_matrix)

    return supercell


def build_supercell_for_qpoint(
    structure: Atoms, qpoint: np.ndarray
) -> Tuple[Atoms, np.ndarray]:
    """Build a supercell for a commensurate q-point.

    Parameters:
        structure: Primitive unit cell structure
        qpoint: Q-point in reduced coordinates

    Returns:
        (supercell, supercell_matrix) - Tuple of supercell and transformation matrix

    Raises:
        ValueError: If q-point is not commensurate

    Examples:
        >>> supercell, matrix = build_supercell_for_qpoint(primitive, np.array([0.5, 0.0, 0.0]))
    """
    n_atoms = len(structure)

    qpoint_rational = np.round(qpoint).astype(int)

    denominator = np.abs(np.lcm.reduce(np.lcm.reduce(np.abs(qpoint_rational))))

    supercell_diag = np.zeros(3, dtype=int)
    for i in range(3):
        if denominator != 0 and qpoint_rational[i] != 0:
            supercell_diag[i] = denominator // np.gcd(
                denominator, np.abs(qpoint_rational[i])
            )

    supercell_matrix = np.diag(supercell_diag)

    if not is_commensurate_qpoint(qpoint, supercell_matrix, tol=1e-6):
        raise ValueError(
            f"q-point {qpoint} is not commensurate with supercell {supercell_matrix}"
        )

    supercell = build_supercell(structure, supercell_matrix)

    return supercell, supercell_matrix
