"""Pytest configuration and fixtures for phonon_kit tests."""

import numpy as np
import pytest
from pathlib import Path


@pytest.fixture
def test_data_dir() -> Path:
    """Path to test data directory."""
    return Path(__file__).parent.parent / "examples" / "data"


@pytest.fixture
def reference_phonproj_dir() -> Path:
    """Path to reference phonproj directory for data."""
    return Path(__file__).parent.parent.parent / "Refs" / "phonproj"


@pytest.fixture
def batio3_yaml_path(test_data_dir) -> Path:
    """Path to BaTiO3 phonopy_params.yaml file."""
    yaml_file = test_data_dir / "phonopy_params.yaml"
    if not yaml_file.exists():
        pytest.skip("BaTiO3 test data not found: phonopy_params.yaml")
    return yaml_file


@pytest.fixture
def batio3_structure_and_modes(batio3_yaml_path):
    """Load BaTiO3 structure and phonon modes from YAML."""
    from phononkit.io import load_from_phonopy_yaml

    structure, modes = load_from_phonopy_yaml(str(batio3_yaml_path))
    return structure, modes


@pytest.fixture
def batio3_structure(batio3_structure_and_modes):
    """BaTiO3 atomic structure."""
    return batio3_structure_and_modes[0]


@pytest.fixture
def batio3_modes(batio3_structure_and_modes):
    """BaTiO3 phonon modes collection."""
    return batio3_structure_and_modes[1]


@pytest.fixture
def sample_structure():
    """Create a simple cubic structure for testing."""
    from ase import Atoms

    return Atoms(
        symbols=["Cu"] * 4,
        positions=[
            [0.0, 0.0, 0.0],
            [0.5, 0.5, 0.0],
            [0.5, 0.0, 0.5],
            [0.0, 0.5, 0.5],
        ],
        cell=[1.0, 1.0, 1.0],
        pbc=True,
    )


@pytest.fixture
def sample_frequencies():
    """Sample phonon frequencies in THz."""
    return np.array([0.0, 2.5, 5.0, 7.5, 10.0])


@pytest.fixture
def sample_eigenvectors():
    """Sample orthonormal eigenvectors."""
    np.random.seed(42)
    eigvecs = np.random.randn(5, 12) + 1j * np.random.randn(5, 12)
    eigvecs = eigvecs / np.linalg.norm(eigvecs, axis=1, keepdims=True)
    return eigvecs


@pytest.fixture
def sample_qpoint():
    """Sample q-point in reduced coordinates."""
    return np.array([0.0, 0.0, 0.0])


def pytest_configure(config):
    """Configure pytest with custom markers."""
    config.addinivalue_line("markers", "slow: marks tests as slow")
    config.addinivalue_line("markers", "integration: marks tests as integration tests")
    config.addinivalue_line("markers", "unit: marks tests as unit tests")
