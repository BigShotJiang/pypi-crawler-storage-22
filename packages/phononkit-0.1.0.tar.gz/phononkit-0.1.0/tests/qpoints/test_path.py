"""Tests for q-point path generation."""

import numpy as np
import pytest


def test_interpolate_path():
    """Test linear interpolation between q-points."""
    from phononkit.qpoints.path import interpolate_path

    start = np.array([0.0, 0.0, 0.0])
    end = np.array([0.5, 0.0, 0.0])
    path = interpolate_path(start, end, 5)
    assert path.shape == (5, 3)
    assert np.allclose(path[0], start)
    assert np.allclose(path[-1], end)


def test_generate_path():
    """Test generating q-point path from labels."""
    from phononkit.qpoints.path import generate_path

    path_labels = [("Gamma", "X"), ("X", "M")]
    qpoints, labels = generate_path(path_labels, 10)
    assert len(qpoints) > 0
    assert len(labels) == 3


def test_interpolate_path_requires_min_points():
    """Test that interpolation requires at least 2 points."""
    from phononkit.qpoints.path import interpolate_path

    start = np.array([0.0, 0.0, 0.0])
    end = np.array([0.5, 0.0, 0.0])
    with pytest.raises(ValueError):
        interpolate_path(start, end, 1)
