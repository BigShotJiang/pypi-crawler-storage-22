"""Tests for q-point utility functions."""

import numpy as np
import pytest


def test_qpoint_distance():
    """Test q-point distance calculation."""
    from phononkit.qpoints.utils import qpoint_distance

    q1 = np.array([0.0, 0.0, 0.0])
    q2 = np.array([0.5, 0.0, 0.0])
    dist = qpoint_distance(q1, q2)
    assert np.isclose(dist, 0.5)


def test_reduce_qpoint():
    """Test q-point reduction."""
    from phononkit.qpoints.utils import reduce_qpoint

    qpoint = np.array([1.25, -0.3, 1.0])
    reduced = reduce_qpoint(qpoint)
    assert np.allclose(reduced[0], 0.25)
    assert np.allclose(reduced[1], 0.7)
    assert np.allclose(reduced[2], 0.0)


def test_find_nearest_qpoint():
    """Test finding nearest q-point."""
    from phononkit.qpoints.utils import find_nearest_qpoint

    target = np.array([0.1, 0.2, 0.3])
    qpoints = np.array([[0.0, 0.0, 0.0], [0.5, 0.5, 0.5]])
    idx, qp = find_nearest_qpoint(target, qpoints)
    assert idx == 0


def test_is_gamma_point():
    """Test gamma point detection."""
    from phononkit.qpoints.utils import is_gamma_point

    gamma = np.array([0.0, 0.0, 0.0])
    not_gamma = np.array([0.5, 0.0, 0.0])
    assert is_gamma_point(gamma)
    assert not is_gamma_point(not_gamma)


def test_find_nearest_qpoint_empty():
    """Test error on empty q-points array."""
    from phononkit.qpoints.utils import find_nearest_qpoint

    target = np.array([0.1, 0.2, 0.3])
    qpoints = np.array([]).reshape(0, 3)
    with pytest.raises(ValueError):
        find_nearest_qpoint(target, qpoints)
