"""Integration tests using real BaTiO3 phonopy data.

These tests use the real BaTiO3 phonopy_params.yaml file to validate
that phononkit works correctly with actual phonopy data.
"""

import pytest
import numpy as np
from pathlib import Path


@pytest.mark.integration
class TestBaTiO3Loading:
    """Tests for loading BaTiO3 data from phonopy YAML."""

    def test_load_batio3_structure(self, batio3_structure):
        """Test that BaTiO3 structure loads correctly."""
        assert batio3_structure is not None
        assert len(batio3_structure) == 5  # BaTiO3 has 5 atoms
        assert batio3_structure.get_chemical_formula() == "BaO3Ti"

    def test_load_batio3_modes(self, batio3_modes):
        """Test that BaTiO3 modes load correctly."""
        assert batio3_modes is not None
        # BaTiO3 with mesh should have many modes (q-points x 15 modes)
        assert batio3_modes.n_modes > 0
        assert len(batio3_modes) > 0

    def test_batio3_gamma_point_modes(self, batio3_modes):
        """Test filtering gamma point modes."""
        gamma_modes = batio3_modes.filter_by_qpoint([0.0, 0.0, 0.0])
        assert gamma_modes.n_modes >= 15  # 15 modes at gamma point (5 atoms x 3)

    def test_batio3_mode_frequencies(self, batio3_modes):
        """Test that BaTiO3 modes have reasonable frequencies."""
        freqs = batio3_modes.frequencies
        assert len(freqs) > 0
        # BaTiO3 should have both acoustic (low freq) and optical (high freq) modes
        assert np.min(freqs) < 5.0  # Acoustic modes
        assert np.max(freqs) > 10.0  # Optical modes


@pytest.mark.integration
class TestBaTiO3Operations:
    """Tests for operations on BaTiO3 data."""

    def test_filter_batio3_by_frequency(self, batio3_modes):
        """Test filtering BaTiO3 modes by frequency."""
        # Low frequency modes (< 8 THz)
        low_freq = batio3_modes.filter_by_frequency(freq_max=8.0)
        assert low_freq.n_modes > 0
        assert np.all(low_freq.frequencies <= 8.0)

        # High frequency modes (> 10 THz)
        high_freq = batio3_modes.filter_by_frequency(freq_min=10.0)
        assert high_freq.n_modes > 0
        assert np.all(high_freq.frequencies >= 10.0)

    def test_batio3_mode_properties(self, batio3_modes):
        """Test BaTiO3 mode properties."""
        mode = batio3_modes[0]

        # Each mode should have a frequency
        assert isinstance(mode.frequency, float)

        # Each mode should have an eigenvector
        assert mode.eigenvector is not None
        assert len(mode.eigenvector) == 15  # 5 atoms x 3 coordinates

        # Each mode should have a q-point
        assert mode.qpoint is not None
        assert len(mode.qpoint) == 3

    def test_batio3_mode_collection_iteration(self, batio3_modes):
        """Test iterating over BaTiO3 modes."""
        count = 0
        for mode in batio3_modes:
            assert mode.frequency is not None
            count += 1
            if count >= 10:  # Just test first 10 to keep it fast
                break
        assert count == 10


@pytest.mark.integration
class TestBaTiO3FileIO:
    """Tests for file I/O with BaTiO3 data."""

    def test_batio3_yaml_file_exists(self, batio3_yaml_path):
        """Test that BaTiO3 YAML file exists."""
        assert batio3_yaml_path.exists()
        assert batio3_yaml_path.suffix in [".yaml", ".yml"]

    def test_load_from_yaml_file(self, batio3_yaml_path):
        """Test loading from YAML file path."""
        from phononkit.io import load_from_phonopy_yaml

        structure, modes = load_from_phonopy_yaml(str(batio3_yaml_path))
        assert structure is not None
        assert modes is not None
        assert len(structure) == 5
