"""Tutorial 1: Loading Phonopy Data with Eigenvectors

This tutorial shows how to properly load phonopy data and retrieve
eigenvectors, which are not loaded by default for performance.

Usage:
    python tests/tutorials/01_loading_phonopy_data.py
"""

import phonopy

# Path to your phonopy YAML file
yaml_path = "examples/data/phonopy_params.yaml"

# Step 1: Load the phonopy object
print("Step 1: Loading phonopy data...")
ph = phonopy.load(yaml_path, produce_fc=True)
print(f"  Loaded structure with {len(ph.primitive)} atoms")

# Step 2: Initialize mesh (required before calculations)
print("\nStep 2: Initializing mesh...")
ph.init_mesh()

# Step 3: Run mesh WITH eigenvectors
# Note: with_eigenvectors=True is required to get eigenvectors!
print("\nStep 3: Running mesh calculation...")
ph.run_mesh(with_eigenvectors=True, is_mesh_symmetry=False)

# Step 4: Get the mesh data
print("\nStep 4: Getting mesh data...")
mesh_dict = ph.get_mesh_dict()

qpoints = mesh_dict["qpoints"]
frequencies = mesh_dict["frequencies"]
eigenvectors = mesh_dict["eigenvectors"]  # Now available!

print(f"  Q-points: {len(qpoints)}")
print(f"  Frequencies shape: {frequencies.shape}")
print(f"  Eigenvectors shape: {eigenvectors.shape}")

# Step 5: Access specific mode data
print("\nStep 5: Accessing first mode at Gamma point...")
q_idx = 0  # Gamma point
mode_idx = 0  # First mode

freq = frequencies[q_idx, mode_idx]
eigvec = eigenvectors[q_idx, mode_idx, :]

print(f"  Frequency: {freq:.3f} THz")
print(f"  Eigenvector shape: {eigvec.shape}")
print(f"  Eigenvector (first 3 components): {eigvec[:3]}")

print("\n✓ Tutorial complete!")
print("\nKey points:")
print("  - Always use run_mesh(with_eigenvectors=True) to get eigenvectors")
print("  - is_mesh_symmetry=False helps avoid symmetry-related issues")
print("  - Eigenvectors are essential for displacement calculations")
