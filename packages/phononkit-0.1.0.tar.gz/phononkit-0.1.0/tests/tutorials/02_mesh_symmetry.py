"""Tutorial 2: Understanding Mesh Symmetry Options

This tutorial explains when to use is_mesh_symmetry=False
and how it affects your phonon calculations.

Usage:
    python tests/tutorials/02_mesh_symmetry.py
"""

import phonopy
import numpy as np

# Path to your phonopy YAML file
yaml_path = "examples/data/phonopy_params.yaml"

print("Tutorial: Mesh Symmetry Options")
print("=" * 50)

# Load phonopy data
ph = phonopy.load(yaml_path, produce_fc=True)

print("\nOption 1: WITH mesh symmetry (default)")
print("-" * 50)
ph.init_mesh()
ph.run_mesh(with_eigenvectors=True)  # Default: is_mesh_symmetry=True
mesh1 = ph.get_mesh_dict()

print(f"  Q-points with symmetry: {len(mesh1['qpoints'])}")
print(f"  This uses irreducible q-points only")
print(f"  Faster calculation, less memory")

print("\nOption 2: WITHOUT mesh symmetry")
print("-" * 50)
# Must reload or create new phonopy object
ph2 = phonopy.load(yaml_path, produce_fc=True)
ph2.init_mesh()
ph2.run_mesh(with_eigenvectors=True, is_mesh_symmetry=False)
mesh2 = ph2.get_mesh_dict()

print(f"  Q-points without symmetry: {len(mesh2['qpoints'])}")
print(f"  This includes ALL q-points in the mesh")
print(f"  More complete data, but slower")

print("\nComparison:")
print("-" * 50)
print(f"  With symmetry: {len(mesh1['qpoints'])} q-points")
print(f"  Without symmetry: {len(mesh2['qpoints'])} q-points")
print(f"  Ratio: {len(mesh2['qpoints']) / len(mesh1['qpoints']):.1f}x more points")

print("\nWhen to use each:")
print("-" * 50)
print("  Use WITH symmetry (default):")
print("    - Quick calculations")
print("    - DOS calculations")
print("    - When you don't need specific q-points")
print()
print("  Use WITHOUT symmetry:")
print("    - Specific q-point analysis")
print("    - Band structure calculations")
print("    - Supercell construction")
print("    - When q-point locations matter")

print("\n✓ Tutorial complete!")
print("\nKey point: Use is_mesh_symmetry=False when you need")
print("           specific q-points in your calculations")
