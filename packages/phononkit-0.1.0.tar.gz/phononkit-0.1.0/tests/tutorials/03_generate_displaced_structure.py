"""Tutorial 3: Generate Displaced Structure for Specific Mode

This tutorial shows how to:
1. Load phonopy data
2. Find Gamma point modes
3. Select the 3rd mode
4. Generate displaced structure with specific amplitude
5. Save to file

Usage:
    python tests/tutorials/03_generate_displaced_structure.py
"""

import phononkit
from ase.io import write

# Path to phonopy data
yaml_path = "examples/data/phonopy_params.yaml"

print("Tutorial: Generate Displaced Structure")
print("=" * 50)

# Step 1: Load data
print("\nStep 1: Loading phonopy data...")
structure, modes = phononkit.load_from_phonopy_yaml(yaml_path)
print(f"  Loaded {modes.n_modes} modes")
print(f"  Structure: {structure.get_chemical_formula()}")

# Step 2: Filter Gamma point modes
print("\nStep 2: Finding Gamma point modes...")
gamma_modes = modes.filter_by_qpoint([0.0, 0.0, 0.0])
print(f"  Found {gamma_modes.n_modes} modes at Gamma point")

# Step 3: Select the 3rd mode (index 2, 0-based)
print("\nStep 3: Selecting 3rd mode at Gamma...")
mode_idx = 2  # 3rd mode (0-based indexing)
selected_mode = gamma_modes[mode_idx]
print(f"  Mode index: {mode_idx}")
print(f"  Frequency: {selected_mode.frequency:.3f} THz")
print(f"  Q-point: {selected_mode.qpoint}")

# Step 4: Generate displaced structure with amplitude 0.5 Å
print("\nStep 4: Generating displaced structure...")
amplitude = 0.5  # 0.5 Angstroms
displaced_structure = phononkit.generate_mode_displacement(
    selected_mode, amplitude=amplitude
)
print(f"  Amplitude: {amplitude} Å")
print(f"  Original positions shape: {structure.positions.shape}")
print(f"  Displaced positions shape: {displaced_structure.positions.shape}")

# Calculate actual displacement
import numpy as np

displacement = displaced_structure.positions - structure.positions
max_disp = np.max(np.abs(displacement))
print(f"  Maximum displacement: {max_disp:.4f} Å")

# Step 5: Save to file
print("\nStep 5: Saving to file...")
output_file = f"mode_{mode_idx}_gamma_displaced_{amplitude}A.vasp"
write(output_file, displaced_structure)
print(f"  Saved: {output_file}")

print("\n" + "=" * 50)
print("✓ Tutorial complete!")
print("\nSummary:")
print(f"  - Selected mode {mode_idx} at Gamma point")
print(f"  - Frequency: {selected_mode.frequency:.3f} THz")
print(f"  - Applied displacement amplitude: {amplitude} Å")
print(f"  - Saved to: {output_file}")
print("\nYou can visualize this file with VESTA or ASE GUI:")
print(f"  ase gui {output_file}")
