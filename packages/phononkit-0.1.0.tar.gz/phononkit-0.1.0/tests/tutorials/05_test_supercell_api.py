"""Test the updated generate_structure_for_mode with supercell support."""

import phononkit

yaml_path = "examples/data/phonopy_params.yaml"

print("Test 1: Primitive cell (no supercell)")
print("-" * 50)
structure1 = phononkit.generate_structure_for_mode(
    yaml_path=yaml_path, qpoint=[0, 0, 0], mode_index=2, amplitude=0.5
)
print(f"Atoms: {len(structure1)} (primitive)")
print(f"Formula: {structure1.get_chemical_formula()}")

print("\nTest 2: 2x2x2 Supercell using [2, 2, 2] notation")
print("-" * 50)
structure2 = phononkit.generate_structure_for_mode(
    yaml_path=yaml_path,
    qpoint=[0, 0, 0],
    mode_index=2,
    amplitude=0.5,
    supercell=[2, 2, 2],
)
print(f"Atoms: {len(structure2)} (should be 5*8=40)")
print(f"Formula: {structure2.get_chemical_formula()}")

print("\nTest 3: 3x1x1 Supercell using diagonal notation")
print("-" * 50)
structure3 = phononkit.generate_structure_for_mode(
    yaml_path=yaml_path,
    qpoint=[0, 0, 0],
    mode_index=2,
    amplitude=0.5,
    supercell=[3, 1, 1],
)
print(f"Atoms: {len(structure3)} (should be 5*3=15)")
print(f"Formula: {structure3.get_chemical_formula()}")

print("\n✓ All tests passed!")
print("\nSupercell input formats supported:")
print("  1. Simple diagonal: supercell=[2, 2, 2]")
print("  2. Full matrix: supercell=[[2,0,0], [0,2,0], [0,0,2]]")
