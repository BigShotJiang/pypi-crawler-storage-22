# Phonopy API Tutorials

Simple, readable tutorials demonstrating key phonopy API features.

## Tutorials

### 01_loading_phonopy_data.py
**What it teaches:** How to properly load phonopy data and retrieve eigenvectors.

**Key API features:**
- `phonopy.load(yaml_path, produce_fc=True)` - Load phonopy data
- `ph.init_mesh()` - Initialize mesh calculation
- `ph.run_mesh(with_eigenvectors=True, is_mesh_symmetry=False)` - Run mesh WITH eigenvectors
- `ph.get_mesh_dict()` - Get mesh results

**Why it matters:** Eigenvectors are essential for displacement calculations but are NOT loaded by default for performance.

**Run it:**
```bash
python tests/tutorials/01_loading_phonopy_data.py
```

### 02_mesh_symmetry.py
**What it teaches:** Understanding mesh symmetry options.

**Key API features:**
- `ph.run_mesh(with_eigenvectors=True)` - With mesh symmetry (default)
- `ph.run_mesh(with_eigenvectors=True, is_mesh_symmetry=False)` - Without mesh symmetry

**Why it matters:** Mesh symmetry reduces q-points for speed, but you need all q-points for specific calculations.

**Run it:**
```bash
python tests/tutorials/02_mesh_symmetry.py
```

### 03_generate_displaced_structure.py
**What it teaches:** How to generate a displaced structure for a specific phonon mode.

**Key API features:**
- `modes.filter_by_qpoint([0, 0, 0])` - Filter to Gamma point
- `modes[2]` - Select 3rd mode
- `phononkit.generate_mode_displacement(mode, amplitude=0.5)` - Generate displacement
- `ase.io.write()` - Save to file

**Why it matters:** Essential for visualizing phonon modes and creating input for other calculations.

**Run it:**
```bash
python tests/tutorials/03_generate_displaced_structure.py
```

### 04_simple_api.py
**What it teaches:** The simplest possible one-function API with optional supercell support.

**Key API feature:**
- `phononkit.generate_structure_for_mode(yaml_path, qpoint, mode_index, amplitude, supercell)` - Everything in one call!

**Supercell input formats:**
- Simple diagonal: `supercell=[2, 2, 2]` → 2×2×2 supercell
- Full matrix: `supercell=[[2,0,0], [0,2,0], [0,0,2]]`

**Why it matters:** When you just want a displaced structure quickly, optionally in a supercell.

**Run it:**
```bash
python tests/tutorials/04_simple_api.py
```

### 05_test_supercell_api.py
**What it teaches:** Testing supercell generation with different formats.

**Demonstrates:**
- Primitive cell (no supercell)
- 2×2×2 supercell using `[2, 2, 2]` notation
- 3×1×1 supercell using `[3, 1, 1]` notation

**Run it:**
```bash
python tests/tutorials/05_test_supercell_api.py
```

## Quick Reference

### Essential Parameters

```python
# Load with force constants
ph = phonopy.load('phonopy_params.yaml', produce_fc=True)

# Run mesh WITH eigenvectors (critical!)
ph.init_mesh()
ph.run_mesh(
    with_eigenvectors=True,    # Required to get eigenvectors
    is_mesh_symmetry=False     # Optional: get all q-points
)

# Get results
mesh = ph.get_mesh_dict()
frequencies = mesh['frequencies']      # Shape: (n_qpoints, n_modes)
eigenvectors = mesh['eigenvectors']    # Shape: (n_qpoints, n_modes, n_modes)
qpoints = mesh['qpoints']              # Shape: (n_qpoints, 3)
```

### Common Gotchas

1. **Eigenvectors are None?** → You forgot `with_eigenvectors=True`
2. **Missing q-points?** → Try `is_mesh_symmetry=False`
3. **Force constants missing?** → Use `produce_fc=True` when loading

### Simple API with Supercell

```python
import phononkit

# Primitive cell
structure = phononkit.generate_structure_for_mode(
    yaml_path='phonopy_params.yaml',
    qpoint=[0, 0, 0],
    mode_index=2,
    amplitude=0.5
)

# 2x2x2 supercell (simple notation)
structure = phononkit.generate_structure_for_mode(
    yaml_path='phonopy_params.yaml',
    qpoint=[0, 0, 0],
    mode_index=2,
    amplitude=0.5,
    supercell=[2, 2, 2]  # Simple diagonal notation
)
```

## Requirements

- phonopy >= 2.0.0
- A phonopy_params.yaml file (see examples/data/)

## More Examples

See the main `examples/` directory for complete use cases with phononkit.
