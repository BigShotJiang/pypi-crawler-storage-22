"""Validation tests for irreps labels using TmFeO3 real data."""

import pytest
import numpy as np
import phonopy
from phononkit.analysis import analyze_irreps


@pytest.mark.integration
def test_tmfeo3_irreps_labels(test_data_dir):
    """Test that irreps labels for TmFeO3 match reference data."""
    # Use the file from Refs instead of test_data_dir if needed
    yaml_path = (
        "/Users/hexu/projects/phonon_kit/Refs/TmFeO3_phonon/TmFeO3_phononpy_params.yaml"
    )

    # Load phonopy object
    ph = phonopy.load(yaml_path, produce_fc=True)

    # Run mesh at Gamma
    q = np.array([0, 0, 0])
    ph.init_mesh()
    ph.run_mesh(with_eigenvectors=True, is_mesh_symmetry=False)

    mesh_dict = ph.get_mesh_dict()
    q_idx = 0
    freqs = mesh_dict["frequencies"][q_idx]
    eigvecs = mesh_dict["eigenvectors"][q_idx]

    # Analyze irreps with high symprec to detect 'mmm' point group
    irr = analyze_irreps(ph.primitive, q, freqs, eigvecs, symprec=1e-2)

    summary = irr.get_summary_table()

    # Reference labels for some specific bands from TmFeO3_irreps.txt
    # Band 3: 2.1839 THz -> Au
    # Band 4: 3.2081 THz -> B3u
    # Band 5: 3.2489 THz -> B2g
    # Band 6: 3.4713 THz -> Ag

    assert summary[3]["label"] == "Au"
    assert summary[4]["label"] == "B3u"
    assert summary[5]["label"] == "B2g"
    assert summary[6]["label"] == "Ag"

    # Check IR/Raman activity
    # B3u is IR and Raman active in this point group (mmm)
    assert summary[4]["is_ir_active"] is True
    assert summary[4]["is_raman_active"] is True

    # Ag is Raman active but not IR active
    assert summary[6]["is_ir_active"] is False
    assert summary[6]["is_raman_active"] is True

    # Au is neither
    assert summary[3]["is_ir_active"] is False
    assert summary[3]["is_raman_active"] is False
