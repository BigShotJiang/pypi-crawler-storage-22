# photographi: MCP Server
# Part of the photographi visual intelligence engine.
# License: MIT
import os
import shutil
import argparse
import time

__version__ = "0.1.0"
import logging
import gc
from typing import Annotated, Literal

from pydantic import Field
from fastmcp import FastMCP
from tqdm import tqdm
from photo_quality_analyzer_core.analyzer import (
    evaluate_photo_quality,
    detect_objects,
    SUPPORTED_EXTENSIONS,
    create_xmp_sidecar,
    generate_color_palette,
)
from analytics import analytics

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("photographi-mcp")

# Initialize MCP server
mcp = FastMCP("photographi")

def _validate_path(path: str, must_exist: bool = True, expected_type: Literal["file", "dir", "any"] = "any") -> str:
    """
    Validates a file path for security and existence.
    Returns the absolute path if valid, raises ValueError if not.
    """
    if not path:
        raise ValueError("Path cannot be empty")
        
    abs_path = os.path.abspath(os.path.expanduser(path))
    
    if must_exist and not os.path.exists(abs_path):
        raise ValueError(f"Path not found: {path}")
        
    if must_exist:
        if expected_type == "file" and not os.path.isfile(abs_path):
            raise ValueError(f"Expected file but found directory: {path}")
        if expected_type == "dir" and not os.path.isdir(abs_path):
            raise ValueError(f"Expected directory but found file: {path}")
            
    return abs_path

def _analyze_photo_logic(image_path: str, metrics: list[str] = None, enable_subject_detection: bool = True, model_size: str = "nano") -> dict:
    """
    Core engine bridge for single image assessment.
    """
    try:
        image_path = _validate_path(image_path, expected_type="file")
    except ValueError as e:
        analytics.track_error()
        return {"error": str(e)}
        
    # Resolve relocated model path
    model_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "models")
    model_filename = "yolo26n.onnx" if model_size == "nano" else "yolo11x.onnx"
    full_model_path = os.path.join(model_dir, model_filename)
    
    # Check if we have a local model, otherwise fallback to name-only for potential download
    if os.path.exists(full_model_path):
        model_size_or_path = full_model_path
    else:
        model_size_or_path = model_size

    # Track tool invocation already handled in wrapper, 
    # but we track specific technical details here
    format_ext = os.path.splitext(image_path)[1]
    
    start_time = time.time()
    try:
        # We don't have a direct way to measure "load time" separately here 
        # because evaluate_photo_quality handles it internally, but we can 
        # measure the total processing hit.
        res = evaluate_photo_quality(image_path, requested_metrics=metrics, enable_subject_detection=enable_subject_detection, model_size=model_size_or_path)
        end_time = time.time()
        
        # Track Performance
        analytics.track_performance((end_time - start_time) * 1000)
        
        # Track Extensive Results
        cam_info = res.get("cameraInfo", {})
        analytics.track_analysis_results(
            judgement=res.get("judgement", "Unknown"), 
            format_ext=format_ext, 
            model_size=model_size,
            technical_score=res.get("technicalScore", 0),
            aesthetic_score=res.get("aestheticScore", 0),
            overall_score=res.get("overallConfidence", 0),
            camera_make=cam_info.get("make"),
            camera_model=cam_info.get("model"),
            lens_model=cam_info.get("lens")
        )
        if enable_subject_detection:
            analytics.track_feature_usage("subject_detection")
            
        # Trigger remote transmission attempt
        analytics.transmit_telemetry()
        return res
    except Exception as e:
        error_name = type(e).__name__
        analytics.track_error(error_name)
        logger.error(f"Error analyzing {image_path}: {e}")
        return {"error": str(e)}

def _analyze_folder_logic(folder_path: str, metrics: list[str] = None, enable_subject_detection: bool = True, model_size: str = "nano", limit: int = 10, offset: int = 0) -> list[dict]:
    """
    Batch processing pipeline for directory-scale analysis with pagination.
    """
    try:
        folder_path = _validate_path(folder_path, expected_type="dir")
    except ValueError as e:
        return {"error": str(e)}
    
    # Sort for stability
    image_files = sorted([f for f in os.listdir(folder_path) if f.lower().endswith(SUPPORTED_EXTENSIONS) and not f.startswith(".")])
    if not image_files:
        return {"message": "No images found in the folder."}
    
    # Apply pagination
    total_images = len(image_files)
    paginated_files = image_files[offset : offset + limit]

    if not paginated_files:
        return {
            "message": "No more images in this range.",
            "totalImages": total_images,
            "nextOffset": None
        }

    results = {}
    total_confidence = 0
    
    for filename in tqdm(paginated_files, desc=f"Analyzing {offset}-{offset+limit}"):
        image_path = os.path.join(folder_path, filename)
        format_ext = os.path.splitext(image_path)[1]
        start_time = time.time()
        try:
            result = evaluate_photo_quality(image_path, requested_metrics=metrics, enable_subject_detection=enable_subject_detection, model_size=model_size)
            end_time = time.time()
            
            total_confidence += result["overallConfidence"]
            
            # Performance & Extensive Tracking
            cam_info = result.get("cameraInfo", {})
            analytics.track_performance((end_time - start_time) * 1000)
            analytics.track_analysis_results(
                judgement=result.get("judgement", "Unknown"),
                format_ext=format_ext,
                model_size=model_size,
                technical_score=result.get("technicalScore", 0),
                aesthetic_score=result.get("aestheticScore", 0),
                overall_score=result.get("overallConfidence", 0),
                camera_make=cam_info.get("make"),
                camera_model=cam_info.get("model"),
                lens_model=cam_info.get("lens")
            )
            if enable_subject_detection:
                analytics.track_feature_usage("subject_detection")
            
            results[filename] = {
                "judgement": result["judgement"],
                "score": round(result["overallConfidence"], 3),
                "summary": result.get("reasoning", {}).get("technical", "Good.")
            }
        except Exception as e:
            analytics.track_error()
            results[filename] = {"error": str(e)}
        gc.collect()
            
    avg_conf = round(total_confidence / len(paginated_files), 3) if paginated_files else 0
    
    response = {
        "status": "Analysis Complete",
        "totalImagesInFolder": total_images,
        "scanned": len(results),
        "offset": offset,
        "limit": limit,
        "averageConfidence": avg_conf,
        "results": results
    }
    
    if offset + limit < total_images:
        response["nextOffset"] = offset + limit
        response["note"] = f"Processed items {offset} to {offset + len(results)}. Use offset={offset+limit} to continue."
        
    # Trigger remote transmission attempt
    analytics.transmit_telemetry()
    return response

def _rank_folder_logic(folder_path: str, top_n: int = 10, limit: int = 50, offset: int = 0, metrics: list[str] = None, enable_subject_detection: bool = True, model_size: str = "nano") -> list[dict]:
    """
    Burst-selection Intelligence: Finding the sharpest needle in the haystack.
    """
    try:
        folder_path = _validate_path(folder_path, expected_type="dir")
    except ValueError as e:
        return {"error": str(e)}

    # Ensure subfolders exististent pagination
    image_files = sorted([f for f in os.listdir(folder_path) if f.lower().endswith(SUPPORTED_EXTENSIONS) and not f.startswith(".")])
    if not image_files:
        return {"message": "No images found."}

    # Apply pagination
    total_images = len(image_files)
    paginated_files = image_files[offset : offset + limit]
    
    if not paginated_files:
        return {
            "message": "No more images in this range.",
            "totalImages": total_images,
            "nextOffset": None
        }
        
    scored_images = []
    # Only process the pagination window
    for filename in tqdm(paginated_files, desc=f"Ranking {offset}-{offset+limit}"):
        path = os.path.join(folder_path, filename)
        format_ext = os.path.splitext(path)[1]
        start_time = time.time()
        try:
            res = evaluate_photo_quality(path, requested_metrics=metrics, enable_subject_detection=enable_subject_detection, model_size=model_size)
            end_time = time.time()
            
            scored_images.append({
                "filename": filename,
                "score": round(res["overallConfidence"], 3),
                "judgement": res["judgement"],
                "summary": res.get("judgementDescription", ""),
                "technicalScore": round(res.get("technicalScore", 0), 2),
                "aestheticScore": round(res.get("aestheticScore", 0), 2),
                "metrics": {
                    "sharpness": round(res.get("metrics", {}).get("sharpness", {}).get("score", 0), 2),
                    "exposure": round(res.get("metrics", {}).get("exposure", {}).get("score", 0), 2),
                    "noise": round(res.get("metrics", {}).get("noise", {}).get("score", 0), 2),
                    "color": round(res.get("metrics", {}).get("color", {}).get("score", 0), 2),
                    "dynamicRange": round(res.get("metrics", {}).get("dynamicRange", {}).get("score", 0), 2),
                    "focus": round(res.get("metrics", {}).get("focus", {}).get("score", 0), 2) if "focus" in res.get("metrics", {}) else None
                }
            })
            
            # Performance & Extensive Tracking
            cam_info = res.get("cameraInfo", {})
            analytics.track_performance((end_time - start_time) * 1000)
            analytics.track_analysis_results(
                judgement=res.get("judgement", "Unknown"),
                format_ext=format_ext,
                model_size=model_size,
                technical_score=res.get("technicalScore", 0),
                aesthetic_score=res.get("aestheticScore", 0),
                overall_score=res.get("overallConfidence", 0),
                camera_make=cam_info.get("make"),
                camera_model=cam_info.get("model"),
                lens_model=cam_info.get("lens")
            )
            if enable_subject_detection:
                analytics.track_feature_usage("subject_detection")

        except Exception as e:
            analytics.track_error(type(e).__name__)
            logger.error(f"Failed to rank {filename}: {e}")
            continue
        gc.collect()
            
    scored_images.sort(key=lambda x: x["score"], reverse=True)
    # Trigger remote transmission attempt after batch
    analytics.transmit_telemetry()
    
    response = {
        "status": "Ranking Complete", 
        "totalImagesInFolder": total_images,
        "scanned": len(scored_images),
        "offset": offset,
        "limit": limit,
        "bestImages": scored_images[:top_n]
    }
    
    if offset + limit < total_images:
        response["nextOffset"] = offset + limit
        response["note"] = f"Processed items {offset} to {offset + len(scored_images)}. Use offset={offset+limit} to continue."
        
    return response

def _threshold_cull_logic(folder_path: str, min_confidence: float = 0.6, mode: str = "move", metrics: list[str] = None, enable_subject_detection: bool = True, model_size: str = "nano") -> dict:
    """
    Binary culling based on strict confidence threshold.
    
    Workflow:
    Unlike qualitative culling (Good/Fair/Poor), this uses a deterministic
    numerical threshold. Images >= min_confidence go to 'selects/', 
    others to 'rejects/'.
    
    Ideal for: High-volume shoots where you want binary decisions
    (e.g., "Keep anything above 0.7").
    """
    if not os.path.exists(folder_path) or not os.path.isdir(folder_path):
        return {"error": "Directory not found."}
        
    image_files = [f for f in os.listdir(folder_path) if f.lower().endswith(SUPPORTED_EXTENSIONS) and not f.startswith(".")]
    if not image_files:
        return {"message": "No images found."}
        
    selects_dir = os.path.join(folder_path, "selects")
    rejects_dir = os.path.join(folder_path, "rejects")
    
    if mode in ["move", "both"]:
        os.makedirs(selects_dir, exist_ok=True)
        os.makedirs(rejects_dir, exist_ok=True)
    
    selects = []
    rejects = []
    
    for filename in tqdm(image_files, desc="Threshold culling"):
        path = os.path.join(folder_path, filename)
        format_ext = os.path.splitext(path)[1]
        start_time = time.time()
        try:
            res = evaluate_photo_quality(path, requested_metrics=metrics, enable_subject_detection=enable_subject_detection, model_size=model_size)
            end_time = time.time()
            confidence = res["overallConfidence"]
            
            # Performance & Extensive Tracking
            cam_info = res.get("cameraInfo", {})
            analytics.track_performance((end_time - start_time) * 1000)
            analytics.track_analysis_results(
                judgement=res.get("judgement", "Unknown"),
                format_ext=format_ext,
                model_size=model_size,
                technical_score=res.get("technicalScore", 0),
                aesthetic_score=res.get("aestheticScore", 0),
                overall_score=res.get("overallConfidence", 0),
                camera_make=cam_info.get("make"),
                camera_model=cam_info.get("model"),
                lens_model=cam_info.get("lens")
            )
            if enable_subject_detection:
                analytics.track_feature_usage("subject_detection")

            target_list = selects if confidence >= min_confidence else rejects
            target_dir = selects_dir if confidence >= min_confidence else rejects_dir
            
            actions = []
            if mode in ["xmp", "both"]:
                status = "Keep" if confidence >= min_confidence else "Rejected"
                create_xmp_sidecar(path, status, confidence)
                actions.append("XMP-Tagged")
                analytics.track_feature_usage("xmp_sidecar")
                
            if mode in ["move", "both"]:
                try:
                    dest = os.path.join(target_dir, filename)
                    shutil.move(path, dest)
                    xmp_path = os.path.splitext(path)[0] + ".xmp"
                    if os.path.exists(xmp_path):
                        shutil.move(xmp_path, os.path.join(target_dir, os.path.basename(xmp_path)))
                    actions.append("Moved")
                except Exception as e:
                    logger.error(f"Failed to move {filename}: {e}")
                    actions.append("Move-Failed")
                    
            target_list.append({"filename": filename, "score": round(confidence, 3), "actions": actions})
            
        except Exception as e:
            logger.error(f"Failed to analyze {filename}: {e}")
            continue
        gc.collect()
    
    return {
        "status": "Threshold Culling Complete",
        "threshold": min_confidence,
        "totalImagesScanned": len(image_files),
        "selectsCount": len(selects),
        "rejectsCount": len(rejects),
        "selects": selects[:10],  # Sample
        "rejects": rejects[:10]   # Sample
    }

def _cull_folder_logic(folder_path: str, threshold: float = 0.4, keep_best_n: int = None, mode: str = "move", metrics: list[str] = None, enable_subject_detection: bool = True, model_size: str = "nano") -> dict:
    """
    Automated Content Culling and Asset Management.
    
    Decision Logic:
    1. Every photo is evaluated using the full technical + aesthetic pipeline.
    2. Any photo with an `overallConfidence` below the `threshold` is flagged.
    
    Action Modes:
    - `move`: Physically relocates rejected shots to a `culled_photos` folder.
    - `xmp`: Generates XMP sidecars with "Rejected" labels (Safe path).
    - `both`: Performs relocation and metadata tagging.
    
    Science of 'Keep Best N':
    Ensures that even in a low-quality burst, the top N frames are preserved, 
    preventing over-aggressive data loss.
    """
    if not os.path.exists(folder_path) or not os.path.isdir(folder_path):
        return {"error": "Directory not found."}
    try:
        folder_path = _validate_path(folder_path, expected_type="dir")
    except ValueError as e:
        return {"error": str(e)}
        
    image_files = [f for f in os.listdir(folder_path) if f.lower().endswith(SUPPORTED_EXTENSIONS)]
    if not image_files:
        return {"message": "No images found."}
        
    scored_images = []
    for filename in tqdm(image_files, desc="Visual intelligence analysis"):
        path = os.path.join(folder_path, filename)
        format_ext = os.path.splitext(path)[1]
        start_time = time.time()
        try:
            res = evaluate_photo_quality(path, requested_metrics=metrics, enable_subject_detection=enable_subject_detection, model_size=model_size)
            end_time = time.time()
            
            scored_images.append({"filename": filename, "path": path, "score": res["overallConfidence"], "judgement": res.get("judgement", "Unknown")})
            
            # Performance & Extensive Tracking
            cam_info = res.get("cameraInfo", {})
            analytics.track_performance((end_time - start_time) * 1000)
            analytics.track_analysis_results(
                judgement=res.get("judgement", "Unknown"),
                format_ext=format_ext,
                model_size=model_size,
                technical_score=res.get("technicalScore", 0),
                aesthetic_score=res.get("aestheticScore", 0),
                overall_score=res.get("overallConfidence", 0),
                camera_make=cam_info.get("make"),
                camera_model=cam_info.get("model"),
                lens_model=cam_info.get("lens")
            )
            if enable_subject_detection:
                analytics.track_feature_usage("subject_detection")

        except Exception as e:
            analytics.track_error(type(e).__name__)
            logger.error(f"Failed to analyze {filename}: {e}")
            continue
        gc.collect()
            
    rejects = []
    if keep_best_n is not None:
        scored_images.sort(key=lambda x: x["score"], reverse=True)
        rejects = scored_images[keep_best_n:]
    else:
        rejects = [img for img in scored_images if img["score"] < threshold]
        
    culled_results = []
    if rejects:
        culled_dir = os.path.join(folder_path, "culled_photos")
        if mode in ["move", "both"] and not os.path.exists(culled_dir):
            os.makedirs(culled_dir)
            
        for img in rejects:
            status_actions = []
            if mode in ["xmp", "both"]:
                create_xmp_sidecar(img["path"], "Rejected", img["score"])
                status_actions.append("XMP-Tagged")
                analytics.track_feature_usage("xmp_sidecar")
            if mode in ["move", "both"]:
                try:
                    dest = os.path.join(culled_dir, img["filename"])
                    shutil.move(img["path"], dest)
                    xmp_path = os.path.splitext(img["path"])[0] + ".xmp"
                    if os.path.exists(xmp_path):
                        shutil.move(xmp_path, os.path.join(culled_dir, os.path.basename(xmp_path)))
                    status_actions.append("Moved")
                except Exception as e:
                    logger.error(f"Failed to move {img['filename']}: {e}")
                    status_actions.append("Move-Failed")
            culled_results.append({"filename": img["filename"], "score": round(img["score"], 2), "actions": status_actions})
            
    summary_msg = f"SUCCESS: Analyzed {len(image_files)} photos. Culled {len(culled_results)} images into '{mode}' state."
    return {
        "status": "Action Complete",
        "message": summary_msg,
        "totalImagesScanned": len(image_files),
        "culledCount": len(culled_results)
    }

@mcp.tool()
def photographi_analyze_photo(
    image_path: Annotated[str, Field(description="Absolute path to RAW/JPEG/TIFF.")],
    metrics: Annotated[list[str], Field(description="Optional: specific metrics (sharpness, exposure, noise, focus, color, dynamicRange, composition). Defaults to all.")] = None,
    enable_subject_detection: Annotated[bool, Field(description="Enables YOLO26 for Subject-Aware Metering, ROI focus analysis, and scene content labeling.")] = True,
    model_size: Annotated[Literal["nano", "xlarge"], Field(description="YOLO model size. 'nano' is sub-second.")] = "nano"
) -> dict:
    """
    Performs Studio-Grade technical analysis on a single photo.
    
    Science:
    - Exposure: Evaluated via the Ansel Adams Zone System.
    - Sharpness: Lens-aware calculation with Diffraction Limited Aperture (DLA) detection.
    - AI Context: Uses Subject-Aware Metering to prioritize detected faces/objects.
    """
    analytics.track_tool_invocation("photographi_analyze_photo")
    return _analyze_photo_logic(image_path, metrics=metrics, enable_subject_detection=enable_subject_detection, model_size=model_size)

@mcp.tool()
def photographi_analyze_folder(
    folder_path: Annotated[str, Field(description="Absolute path to folder.")],
    metrics: Annotated[list[str], Field(description="Metrics to calculate.")] = None,
    enable_subject_detection: bool = True,
    model_size: Annotated[Literal["nano", "xlarge"], Field(description="YOLO model size.")] = "nano",
    limit: Annotated[int, Field(description="Max images to process.")] = 10,
    offset: Annotated[int, Field(description="Pagination offset.")] = 0
) -> dict:
    """
    Batch analyzes a folder with pagination.
    Returns technical quality reports for the batch.
    """
    analytics.track_tool_invocation("photographi_analyze_folder")
    return _analyze_folder_logic(folder_path, metrics=metrics, enable_subject_detection=enable_subject_detection, model_size=model_size, limit=limit, offset=offset)

@mcp.tool()
def photographi_rank_photographs(
    folder_path: Annotated[str, Field(description="Absolute path to folder.")],
    top_n: Annotated[int, Field(description="Number of top-rated images to return.")] = 1,
    limit: Annotated[int, Field(description="Max images to process to avoid timeout (default 50).")] = 50,
    offset: Annotated[int, Field(description="Pagination offset.")] = 0,
    metrics: list[str] = None,
    enable_subject_detection: bool = True,
    model_size: Annotated[Literal["nano", "xlarge"], Field(description="YOLO model size.")] = "nano"
) -> dict:
    """
    Burst Intelligence: Ranks photos by technical quality. 
    Use this to find the single sharpest, best-exposed frame in a high-speed sequence.
    """
    analytics.track_tool_invocation("photographi_rank_photographs")
    return _rank_folder_logic(folder_path, top_n=top_n, limit=limit, offset=offset, metrics=metrics, enable_subject_detection=enable_subject_detection, model_size=model_size)

@mcp.tool()
def photographi_cull_photographs(
    folder_path: Annotated[str, Field(description="Absolute path to folder.")],
    threshold: float = 0.4,
    mode: Annotated[Literal["move", "xmp", "both"], Field(description="Cull mode.")] = "move",
    enable_subject_detection: bool = True
) -> dict:
    """Filters low-quality images into a 'culled_photos' subfolder."""
    return _cull_folder_logic(folder_path, threshold, mode=mode, enable_subject_detection=enable_subject_detection)

@mcp.tool()
def photographi_threshold_cull(
    folder_path: Annotated[str, Field(description="Absolute path to folder.")],
    min_confidence: Annotated[float, Field(
        description="Minimum confidence threshold (0.0-1.0). Images below this are rejected.",
        ge=0.0,
        le=1.0
    )] = 0.6,
    mode: Annotated[Literal["move", "xmp", "both"], Field(description="Cull mode.")] = "move",
    enable_subject_detection: bool = True
) -> dict:
    """Binary culling: sorts into 'selects/' (>= threshold) and 'rejects/' (< threshold)."""
    return _threshold_cull_logic(folder_path, min_confidence, mode, enable_subject_detection=enable_subject_detection)

@mcp.tool()
def photographi_get_color_palette(
    image_path: Annotated[str, Field(description="Absolute path to image.")],
    colors: int = 5
) -> dict:
    """
    Extracts a representative color palette using K-Means Clustering.
    """
    analytics.track_tool_invocation("photographi_get_color_palette")
    palette = generate_color_palette(image_path, colors)
    analytics.track_feature_usage("color_palette")
    return {"colors": palette}

@mcp.tool()
def photographi_get_scene_content(
    image_path: Annotated[str, Field(description="Absolute path to RAW/JPEG/TIFF.")]
) -> dict:
    """
    Returns a clean list of detected objects (e.g., person, dog, car).
    Use this for quick scene indexing without full technical analysis.
    """
    analytics.track_tool_invocation("photographi_get_scene_content")
    try:
        objects = detect_objects(image_path)
        analytics.track_feature_usage("scene_content")
        return {"objects": objects}
    except Exception as e:
        logger.error(f"Failed to get scene content: {e}")
        return {"error": str(e)}

def _bulk_palette_logic(folder_path: str, colors: int = 5, limit: int = 20, offset: int = 0) -> dict:
    """
    Batch color palette extraction with pagination.
    """
    try:
        folder_path = _validate_path(folder_path, expected_type="dir")
    except ValueError as e:
        return {"error": str(e)}
        
    image_files = sorted([f for f in os.listdir(folder_path) if f.lower().endswith(SUPPORTED_EXTENSIONS) and not f.startswith(".")])
    if not image_files:
        return {"message": "No images found."}

    # Apply pagination
    total_images = len(image_files)
    paginated_files = image_files[offset : offset + limit]
    
    if not paginated_files:
        return {
            "message": "No more images in this range.",
            "totalImages": total_images,
            "nextOffset": None
        }
        
    results = {}
    
    for filename in tqdm(paginated_files, desc="Extracting palettes"):
        image_path = os.path.join(folder_path, filename)
        try:
            palette = generate_color_palette(image_path, colors)
            results[filename] = palette
            analytics.track_feature_usage("color_palette")
        except Exception as e:
            logger.error(f"Failed to extract palette for {filename}: {e}")
            results[filename] = {"error": str(e)}
            
    analytics.transmit_telemetry()
    
    response = {
        "status": "Palette Extraction Complete",
        "totalImagesInFolder": total_images,
        "returned": len(results),
        "offset": offset,
        "limit": limit,
        "palettes": results
    }

    if offset + limit < total_images:
        response["nextOffset"] = offset + limit
        response["note"] = f"Showing images {offset + 1} to {offset + len(results)} of {total_images}. Use offset={offset+limit} for next batch."
        
    return response

@mcp.tool()
def photographi_get_folder_palettes(
    folder_path: Annotated[str, Field(description="Absolute path to folder.")],
    colors: int = 5,
    limit: int = 20,
    offset: int = 0
) -> dict:
    """
    Extracts representative color palettes for a batch of images in a folder.
    Supports pagination for large folders.
    """
    analytics.track_tool_invocation("photographi_get_folder_palettes")
    return _bulk_palette_logic(folder_path, colors, limit, offset)


def main():
    parser = argparse.ArgumentParser(description="Photographi MCP Server")
    parser.add_argument("--telemetry-endpoint", help="Remote telemetry collection URL")
    parser.add_argument("--disable-telemetry", action="store_true", help="Disable all local and remote analytics")
    args, unknown = parser.parse_known_args()
    
    # Configure analytics from CLI args
    analytics.configure(
        endpoint=args.telemetry_endpoint,
        disabled=True if args.disable_telemetry else None
    )
    
    mcp.run()

if __name__ == "__main__":
    main()
