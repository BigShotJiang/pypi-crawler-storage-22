# PHOXLA

> PHOXLA ("FOX-luh") - Differentiable photonic design and simulation on XLA accelerators.

PHOXLA is a framework blueprint for building modern photonic inverse-design systems with JAX/Flax.
The goal is to treat differentiable physics as a first-class deep learning component, so photonic simulation modules can be plugged into end-to-end trainable workflows.

## Vision

- XLA-native photonic simulation and optimization (GPU/TPU first, CPU compatible)
- Differentiable physics modules usable as model layers/loss terms
- Inverse design pipelines integrated with standard deep learning tooling
- Extensible interoperability with JAX-based solvers (including FDTDX-style workflows)

## Current Status

This repository is an initial blueprint and governance scaffold.
Core simulation and training modules will be added incrementally.

## Planned Package Layout

- `src/phoxla/sim`: differentiable photonic simulation core
- `src/phoxla/nn`: NN-facing modules and differentiable operators
- `src/phoxla/inv`: inverse design workflows and optimizers
- `src/phoxla/integrations/fdtdx`: interoperability layer

## Repository Bootstrap

See:

- `docs/REPO_LAUNCH_GUIDE.md`
- `docs/REPO_ABOUT_AND_TOPICS.md`
- `docs/PACKAGE_NAMESPACE_PLAN.md`
- `docs/PYPI_CLAIM_PLAYBOOK.md`
- `docs/NAMESPACE_PRIORITY.md`
- `docs/ARCHITECTURE_BLUEPRINT.md`
- `docs/COMMIT_MESSAGE_GUIDE.md`
- `ROADMAP.md`

## License

Apache-2.0 (`LICENSE`)
