"""Basic package smoke tests."""

import phoxla


def test_version_string_exists() -> None:
    assert isinstance(phoxla.__version__, str)
    assert phoxla.__version__
