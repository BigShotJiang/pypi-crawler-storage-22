"""
PySpark UDF helpers for PHP deserialization.

This module provides ready-to-use UDFs for deserializing PHP serialized data
in PySpark DataFrames.

Example:
    >>> from php_deserialize.spark import php_deserialize_udf
    >>> deserialize = php_deserialize_udf("json")
    >>> df = df.withColumn("parsed", deserialize("serialized_col"))
"""

from typing import TYPE_CHECKING, Callable, Literal, Optional, Union

if TYPE_CHECKING:
    from pyspark.sql import Column
    from pyspark.sql.types import DataType

# Lazy imports to avoid requiring PySpark at import time
_pyspark_available: Optional[bool] = None


def _check_pyspark() -> None:
    """Check if PySpark is available."""
    global _pyspark_available
    if _pyspark_available is None:
        try:
            import pyspark  # noqa: F401
            _pyspark_available = True
        except ImportError:
            _pyspark_available = False

    if not _pyspark_available:
        raise ImportError(
            "PySpark is required for spark module. "
            "Install with: pip install phpserialize-rs[spark]"
        )


def php_deserialize_udf(
    output_format: Literal["json"] = "json",
    auto_unescape: bool = True,
) -> Callable[["Column"], "Column"]:
    """
    Create a PySpark UDF for deserializing PHP serialized data.

    Args:
        output_format: Output format - currently only "json" is supported
            - "json": Return JSON string (recommended for Spark)
        auto_unescape: Automatically handle DB-escaped strings

    Returns:
        A UDF function that can be applied to DataFrame columns

    Example:
        >>> from php_deserialize.spark import php_deserialize_udf
        >>> from pyspark.sql import functions as F
        >>>
        >>> deserialize = php_deserialize_udf("json")
        >>> df = df.withColumn("parsed", deserialize(F.col("php_data")))
        >>>
        >>> # Or with schema inference
        >>> from pyspark.sql.functions import from_json, schema_of_json
        >>> sample_json = '{"name":"Alice","age":30}'
        >>> schema = schema_of_json(sample_json)
        >>> df = df.withColumn("parsed", from_json(deserialize("php_data"), schema))
    """
    _check_pyspark()

    from pyspark.sql.functions import udf
    from pyspark.sql.types import StringType

    from php_deserialize import loads_json

    @udf(returnType=StringType())
    def _deserialize(data: Optional[bytes]) -> Optional[str]:
        if data is None:
            return None
        try:
            # Handle string input (common in Spark)
            if isinstance(data, str):
                data = data.encode("utf-8")
            return loads_json(data, auto_unescape=auto_unescape)
        except Exception:
            return None

    return _deserialize


def php_deserialize_pandas_udf(
    auto_unescape: bool = True,
) -> Callable:
    """
    Create a Pandas UDF for batch PHP deserialization.

    This is more efficient than the regular UDF for large datasets
    as it processes data in batches.

    Args:
        auto_unescape: Automatically handle DB-escaped strings

    Returns:
        A Pandas UDF function

    Example:
        >>> from php_deserialize.spark import php_deserialize_pandas_udf
        >>> deserialize = php_deserialize_pandas_udf()
        >>> df = df.withColumn("parsed", deserialize("php_data"))
    """
    _check_pyspark()

    from pyspark.sql.functions import pandas_udf
    from pyspark.sql.types import StringType

    import pandas as pd

    from php_deserialize import loads_json

    @pandas_udf(StringType())
    def _deserialize_batch(series: pd.Series) -> pd.Series:
        def safe_deserialize(data: Optional[Union[bytes, str]]) -> Optional[str]:
            if data is None or (isinstance(data, float) and pd.isna(data)):
                return None
            try:
                if isinstance(data, str):
                    data = data.encode("utf-8")
                return loads_json(data, auto_unescape=auto_unescape)
            except Exception:
                return None

        return series.apply(safe_deserialize)

    return _deserialize_batch


def register_udfs(spark: "SparkSession", prefix: str = "php_") -> None:
    """
    Register PHP deserialization UDFs with a Spark session.

    Args:
        spark: SparkSession instance
        prefix: Prefix for UDF names (default: "php_")

    Example:
        >>> from pyspark.sql import SparkSession
        >>> from php_deserialize.spark import register_udfs
        >>>
        >>> spark = SparkSession.builder.getOrCreate()
        >>> register_udfs(spark)
        >>>
        >>> # Now use in SQL
        >>> spark.sql("SELECT php_deserialize(data) FROM table")
    """
    _check_pyspark()

    from pyspark.sql.types import StringType

    from php_deserialize import loads_json

    def deserialize_udf(data: Optional[bytes]) -> Optional[str]:
        if data is None:
            return None
        try:
            if isinstance(data, str):
                data = data.encode("utf-8")
            return loads_json(data, auto_unescape=True)
        except Exception:
            return None

    spark.udf.register(f"{prefix}deserialize", deserialize_udf, StringType())


# =============================================================================
# Drop-in replacement for php2json-based UDFs
# =============================================================================

def php_to_json_udf(strict: bool = False) -> Callable[["Column"], "Column"]:
    """
    Create a drop-in replacement UDF for php2json-based php_to_json.

    This matches the exact signature used in datacube_python.functions:
        @udf(StringType(), useArrow=True)
        def php_to_json(php_text: str) -> str

    Args:
        strict: Disable automatic fallback for byte length mismatches (default: False)
            When False (default), the parser automatically recovers from string
            length mismatches caused by encoding differences (e.g., EUC-KR to UTF-8).
            When True, the parser fails immediately on mismatches.

    Migration:
        # Before (php2json)
        from datacube_python.functions import php_to_json
        df = df.withColumn("json_col", php_to_json("php_serialized_col"))

        # After (phpserialize-rs) - Option 1: Use the UDF factory
        from php_deserialize.spark import php_to_json_udf
        php_to_json = php_to_json_udf()
        df = df.withColumn("json_col", php_to_json("php_serialized_col"))

        # After (phpserialize-rs) - Option 2: Direct import (recommended)
        from php_deserialize.spark import php_to_json
        df = df.withColumn("json_col", php_to_json("php_serialized_col"))

        # Note: Automatic fallback is enabled by default, no need for lenient=True!

    Returns:
        A UDF compatible with the original php_to_json signature
    """
    _check_pyspark()

    from pyspark.sql.functions import udf
    from pyspark.sql.types import StringType

    from php_deserialize import loads_json

    @udf(StringType(), useArrow=True)
    def _php_to_json(php_text: Optional[str]) -> Optional[str]:
        if php_text is None:
            return None
        try:
            return loads_json(bytes(php_text, "utf-8"), auto_unescape=True, strict=strict)
        except Exception:
            return None

    return _php_to_json


# Pre-instantiated UDF for convenience (matches datacube_python.functions.php_to_json)
def _create_php_to_json():
    """Lazy initialization of php_to_json UDF."""
    try:
        return php_to_json_udf()
    except ImportError:
        # PySpark not available, return a placeholder
        def _placeholder(*args, **kwargs):
            raise ImportError("PySpark is required. Install with: pip install pyspark")
        return _placeholder


# This will be initialized on first use
_php_to_json_instance = None
_php_to_json_strict_instance = None


def php_to_json(col: "Column", strict: bool = False) -> "Column":
    """
    Drop-in replacement for datacube_python.functions.php_to_json.

    Converts PHP serialized string to JSON format string.
    Automatic fallback is enabled by default to handle encoding mismatches.

    Args:
        col: Column containing PHP serialized strings
        strict: Disable automatic fallback (default: False)
            When False (default), encoding mismatches are automatically handled.
            When True, parsing fails immediately on string length mismatches.

    Returns:
        Column with JSON strings

    Example:
        >>> from php_deserialize.spark import php_to_json
        >>> from pyspark.sql.functions import get_json_object
        >>>
        >>> # Convert PHP serialized column to JSON (auto-fallback enabled by default)
        >>> df = df.withColumn("json_col", php_to_json("php_serialized_col"))
        >>>
        >>> # Extract values from JSON
        >>> df = df.withColumn("value", get_json_object("json_col", "$.key"))
        >>>
        >>> # Use strict=True to disable automatic fallback
        >>> df = df.withColumn("json_col", php_to_json("php_data", strict=True))

    Note:
        This is 10-50x faster than the php2json-based implementation.
        Automatic fallback handles most encoding mismatch issues without any options.
    """
    global _php_to_json_instance, _php_to_json_strict_instance

    if strict:
        if _php_to_json_strict_instance is None:
            _php_to_json_strict_instance = php_to_json_udf(strict=True)
        return _php_to_json_strict_instance(col)
    else:
        if _php_to_json_instance is None:
            _php_to_json_instance = php_to_json_udf(strict=False)
        return _php_to_json_instance(col)


# Type alias for Spark
if TYPE_CHECKING:
    from pyspark.sql import SparkSession
