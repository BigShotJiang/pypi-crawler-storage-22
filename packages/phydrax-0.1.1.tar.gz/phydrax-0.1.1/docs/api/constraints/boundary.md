# Boundary and initial conditions

## Generic boundary constraints

::: phydrax.constraints.ContinuousDirichletBoundaryConstraint

---

::: phydrax.constraints.ContinuousNeumannBoundaryConstraint

---

::: phydrax.constraints.ContinuousRobinBoundaryConstraint

---

::: phydrax.constraints.AbsorbingBoundaryConstraint

## Generic initial constraints

::: phydrax.constraints.ContinuousInitialConstraint
