# Thermal constraints

## Boundary conditions

::: phydrax.constraints.ContinuousHeatFluxBoundaryConstraint

---

::: phydrax.constraints.ContinuousConvectionBoundaryConstraint

---

::: phydrax.constraints.DiscreteHeatFluxBoundaryConstraint

---

::: phydrax.constraints.DiscreteConvectionBoundaryConstraint

---

::: phydrax.constraints.DiscreteRobinBoundaryConstraint
