# Geometry (1D)

::: phydrax.domain.Interval1d
    options:
        members:
            - __init__
            - sample_interior
            - sample_boundary
            - length
            - bounds
