# Layers

Low-level model building blocks.

!!! note
    Key notes:

    - `Linear` supports Random Weight Factorization (RWF) and optional complex parameters.

::: phydrax.nn.Linear
    options:
        members:
            - __init__
            - __call__
