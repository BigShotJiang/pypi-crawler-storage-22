# Delay operators

::: phydrax.operators.delay_operator
