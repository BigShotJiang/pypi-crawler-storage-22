# Functional operators

::: phydrax.operators.spatial_inner_product

---

::: phydrax.operators.spatial_l2_norm

---

::: phydrax.operators.spatial_lp_norm

---

::: phydrax.operators.spatial_mean
