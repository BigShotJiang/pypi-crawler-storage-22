# Linear algebra

::: phydrax.operators.einsum

---

::: phydrax.operators.norm

---

::: phydrax.operators.trace

---

::: phydrax.operators.det
