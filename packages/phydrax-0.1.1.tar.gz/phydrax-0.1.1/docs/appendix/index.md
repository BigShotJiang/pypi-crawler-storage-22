# Appendix

This section collects longer, more technical notes and mathematical details that
support the main guides and API pages.

- [Physics-Constrained Interpolation (PCI) pipeline](physics_constrained_interpolation.md)
- [Differentiation modes](differentiation_modes.md)
