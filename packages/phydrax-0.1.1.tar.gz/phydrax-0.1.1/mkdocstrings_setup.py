#
#  Copyright © 2026 PHYDRA, Inc. All rights reserved.
#

import typing


typing.GENERATING_DOCUMENTATION = True  # ty: ignore[unresolved-attribute]
