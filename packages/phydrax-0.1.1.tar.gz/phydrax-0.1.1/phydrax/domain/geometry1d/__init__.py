#
#  Copyright © 2026 PHYDRA, Inc. All rights reserved.
#

from ._primitives import Interval1d


__all__ = [
    "Interval1d",
]
