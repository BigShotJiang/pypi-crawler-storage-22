"""Phylax CLI module."""
