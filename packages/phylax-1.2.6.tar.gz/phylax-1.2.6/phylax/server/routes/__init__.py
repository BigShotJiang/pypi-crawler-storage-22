"""Phylax Server routes."""
