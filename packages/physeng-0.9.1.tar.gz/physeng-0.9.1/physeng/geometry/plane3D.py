#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Andreas Mussgiller
"""

import math
import numbers

from physeng.units import Length, Area, Angle

from physeng.geometry.geometry import ArgumentError
import physeng.geometry.point3D as p3D
import physeng.geometry.vector3D as v3D

class Plane3D():
    
    def __init__(self, a, b, c = None):
        
        if isinstance(a, p3D.Point3D) and isinstance(b, v3D.Vector3D) and c==None:
            
            # Point and Normal
            self._point = a
            self._normal = b.unit
        
        elif isinstance(a, p3D.Point3D) and isinstance(b, p3D.Point3D) and isinstance(c, p3D.Point3D):

            # Three Points
            self._point = a
            v1 = v3D.Vector3D(a, b)
            v2 = v3D.Vector3D(a, c)
            self._normal = v1.cross(v2).unit
            
        elif isinstance(a, p3D.Point3D) and isinstance(b, v3D.Vector3D) and isinstance(c, v3D.Vector3D):
            
            # Point and two Vectors
            self._point = a
            self._normal = b.cross(c).unit
        
        else:
            
            raise ArgumentError('unsupported argument types')

    def __str__(self):
        return f'Plane3D({self._point}, {self._normal})'
    
    def __repr__(self):
        return self.__str__()
