#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Andreas Mussgiller
"""

import math
import numbers

from physeng.units import Dimensionless, Length, Area, Angle

from physeng.geometry.geometry import ArgumentError
import physeng.geometry.point2D as p2D

class Vector2D():
    
    def __init__(self, a, b):
        
        if isinstance(a, p2D.Point2D) and isinstance(b, p2D.Point2D):
            
            self._x = b.x - a.x
            self._y = b.y - a.y
        
        elif isinstance(a, Length) and isinstance(b, Length):

            self._x = a
            self._y = b
            
        elif isinstance(a, Length) and isinstance(b, Angle):

            self._x = a * math.cos(b)
            self._y = a * math.sin(b)
        
        else:
            
            raise ArgumentError('unsupported argument types')
    
    @property
    def x(self):
        return self._x

    @x.setter
    def x(self, value):
        if not isinstance(value, Length):
            raise ArgumentError('unsupported argument type: {type(value)}')
        self._x = value
    
    @property
    def y(self):
        return self._y

    @y.setter
    def y(self, value):
        if not isinstance(value, Length):
            raise ArgumentError('unsupported argument type: {type(value)}')
        self._y = value

    @property
    def length(self) -> Length:
        return Length(math.sqrt(float(self._x)**2 + float(self._y)**2))

    @length.setter
    def length(self, value):
        if not isinstance(value, Length):
            raise ArgumentError('unsupported argument type: {type(value)}')
        pass
    
    @property
    def phi(self) -> Angle:
        return Angle(math.atan2(float(self._y), float(self._x)))
    
    @property
    def unit(self):
        l = float(self.length)
        return Vector2D(self._x/l, self._y/l)
    
    def dot(self, other) -> Area:
        if not isinstance(other, Vector2D):
            raise ArgumentError('unsupported argument type: {type(other)}')
            
        x1 = float(self._x)   
        y1 = float(self._y)   
        x2 = float(other._x)   
        y2 = float(other._y)   

        return Area(x1*x2 + y1*y2)
    
    def angleBetween(self, other) -> Angle:
        if not isinstance(other, Vector2D):
            raise ArgumentError('unsupported argument type: {type(other)}')
    
        v1 = self.unit
        v2 = other.unit
        
        angle = math.acos(v1.dot(v2))
        
        return Angle(angle)
    
    def __add__(self, other):
        if isinstance(other, Vector2D):
            return Vector2D(self._x + other._x,
                            self._y + other._y)
        raise ArgumentError(f"{self.__class__.__name__}: add {other.__class__.__name__}")
    
    def __iadd__(self, other):
        if isinstance(other, Vector2D):
            self._x += other._x
            self._y += other._y
            return self
        raise ArgumentError(f"{self.__class__.__name__}: add {other.__class__.__name__}")

    def __sub__(self, other):
        if isinstance(other, Vector2D):
            return Vector2D(self._x - other._x,
                            self._y - other._y)
        raise ArgumentError(f"{self.__class__.__name__}: subtract {other.__class__.__name__}")
    
    def __isub__(self, other):
        if isinstance(other, Vector2D):
            self._x -= other._x
            self._y -= other._y
            return self
        raise ArgumentError(f"{self.__class__.__name__}: subtract {other.__class__.__name__}")
    
    def __mul__(self, other):
        if isinstance(other, numbers.Number):
            return Vector2D(self._x * other, self._y * other)
        if isinstance(other, Dimensionless):
            return Vector2D(self._x * other._value, self._y * other._value)
        if isinstance(other, Vector2D):
            return self.dot(other)
        raise TypeError
    
    def __rmul__(self, other):
        if isinstance(other, numbers.Number):
            return Vector2D(self._x * other, self._y * other)
        if isinstance(other, Dimensionless):
            return Vector2D(self._x * other._value, self._y * other._value)
        if isinstance(other, Vector2D):
            return self.dot(other)
        raise TypeError
    
    def __imul__(self, other):
        if isinstance(other, numbers.Number):
            self._x *= other
            self._y *= other
            return self
        if isinstance(other, Dimensionless):
            self._x *= other._value
            self._y *= other._value
            return self
        raise TypeError

    def __eq__(self, other):
        if isinstance(other, Vector2D):
            return self._x.__eq__(other._x) and self._y.__eq__(other._y)
        raise TypeError

    def __str__(self):
        return f'Vector2D({self._x}, {self._y})'
    
    def __repr__(self):
        return self.__str__()
