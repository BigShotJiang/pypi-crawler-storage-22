#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Andreas Mussgiller
"""

import pytest
import math
import numpy as np

from physeng.units import Length, Angle
from physeng.geometry import *

def test_Geometry2D():

    p1 = Point2D(Length(1.0), Length(1.0))
    p2 = Point2D(Length(2.0), Length(2.0))
    
    d1 = p1.distanceTo(p2)
    
    assert d1==Length(math.sqrt(2))
    
    v1a = Vector2D(p1, p2)
    v1b = p2 - p1

    assert v1a==v1b

    p3 = p1 + v1a
    p3 = p2 - v1a

    l1 = Line2D(p1, v1a)
    l2 = Line2D(p2, -1*v1b)

    assert math.isclose(l1.angleBetween(l2).asFloat('rad'),
                        Angle(180, 'deg').asFloat('rad'),
                        rel_tol=1e-5)

if __name__ == '__main__':
    test_Geometry2D()
