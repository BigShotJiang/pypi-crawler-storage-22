from enum import Enum


class MeshSubjects(Enum):
  MeshGenerated = 'mesh:generated'
  MeshDeleted = 'mesh:deleted'
