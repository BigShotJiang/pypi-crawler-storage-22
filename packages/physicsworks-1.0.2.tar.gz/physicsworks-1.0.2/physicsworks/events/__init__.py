# from enum import Enum

# from .Geometry import GeometrySubjects
# from .Mesh import MeshSubjects

# class Subjects(GeometrySubjects, MeshSubjects, Enum):
#   '''Test'''

# class Event:
#   subject: Subjects
#   data: object
