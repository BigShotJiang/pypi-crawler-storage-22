from __future__ import annotations
from frozendict import frozendict
from physiomodeler._helpers import TimeSpec

from types import NoneType


from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, overload

import numpy as np
from numpy.typing import ArrayLike

from physiomodeler._helpers import safe_call

if TYPE_CHECKING:
    from physiomodeler import Model


def convert_single_function_to_list(
    func: Callable | list[Callable],
) -> list[Callable]:
    if callable(func):
        return [func]
    return func


def convert_inputs(
    inputs: dict[str, float | Callable[[...], float]],
    time: float | ArrayLike,
    parameters: dict[str, float],
) -> dict[str, float]:
    """Converts function inputs to values at the given time point."""
    new_inputs: dict[str, float] = {}
    to_call: list[tuple[str, Callable[[...], float]]] = []
    for k, v in inputs.items():
        if callable(v):
            to_call.append((k, v))
        else:
            new_inputs[k] = v
    for k, v in to_call:
        new_inputs[k] = safe_call(
            v,
            time=time,
            parameters=frozendict(parameters),
            inputs=frozendict(new_inputs),
        )
    return new_inputs


@overload
def convert_time(
    time: float | tuple[float, float] | tuple[float, float, NoneType],
) -> tuple[float, float, None]: ...


@overload
def convert_time(
    time: TimeSpec,
) -> tuple[float, float, np.ndarray] | tuple[float, float, None]: ...


@overload
def convert_time(
    time: tuple[float, float, float] | list | np.ndarray,
) -> tuple[float, float, np.ndarray]: ...


@overload
def convert_time(
    time: float | tuple[float, float],
) -> tuple[float, float, np.ndarray]: ...


def convert_time(
    time: float
    | tuple[float, float]
    | tuple[float, float, NoneType]
    | tuple[float, float, float]
    | TimeSpec
    | list
    | np.ndarray,
) -> tuple[float, float, np.ndarray | None]:
    step: float | int | None = None
    start: float | int | None = None
    end: float | int | None = None

    match time:
        case float() | int() as end:
            start = 0.0
        case tuple([float() | int() as start, float() | int() as end]):
            pass
        case tuple([None, float() | int() as end, None]):
            start = 0.0
        case tuple([float() | int() as start, float() | int() as end, None]):
            pass
        case tuple(
            [
                float() | int() as start,
                float() | int() as end,
                float() | int() as step,
            ]
        ):
            pass
        case tuple([None, float() | int() as end, float() | int() as step]):
            start = 0.0
        case dict() as time_spec:
            start = time_spec.get("start", 0.0)
            end = time_spec["end"]
            step = time_spec.get("step", None)
        case tuple():
            msg = f"`time` should be a tuple of floats with length 2 or 3, not {time}"
            raise ValueError(msg)
        case list():
            time = np.array(time)
        case np.ndarray():
            ...
        case _:
            raise TypeError(f"Could not parse {time!r} as time.")

    if isinstance(time, np.ndarray):
        time = np.array(time, dtype=float)
        start = time[0]
        end = time[-1]
        time_ = time
    elif step:
        time_ = np.arange(start, end + step, step)
        if time_[-1] > end:
            time_ = time_[:-1]
    else:
        time_ = None

    start, end = float(start), float(end)
    if start == end:
        raise ValueError(
            f"Start and end time cannot be the same: {start = }, {end = }."
        )
    return start, end, time_


def convert_nonstr_sequence_to_list(value: list | tuple) -> list:
    if isinstance(value, Sequence) and not isinstance(value, str):
        return list(value)
    return value


def convert_model_to_function(item):
    from physiomodeler import Model

    if isinstance(item, Model):
        function = item.get_update_function()
        setattr(function, "_is_submodel_function", True)
        setattr(function, "_model", item)
        return function

    return item


def convert_models_to_functions(
    value: list[Callable | "Model"],
) -> list[Callable]:
    if not isinstance(value, list):
        return value

    converted: list[Callable] = []
    for item in value:
        converted.append(convert_model_to_function(item))
    return converted
