from frozendict import frozendict
from typing import NotRequired
from typing import TypedDict
from typing import Literal
from typing import TypeAlias
import functools
import inspect
import itertools
from functools import wraps
from typing import Callable, TypeVar

TimeUnitsType: TypeAlias = Literal[
    "W",
    "D",
    "days",
    "day",
    "hours",
    "hour",
    "hr",
    "h",
    "H",
    "m",
    "minute",
    "min",
    "minutes",
    "T",
    "s",
    "seconds",
    "sec",
    "second",
    "S",
    "ms",
    "millisecond",
    "microsecond",
    "micro",
    "micros",
    "U",
    "ns",
    "nanoseconds",
    "nano",
    "nanos",
    "nanosecond",
    "N",
]


class TimeSpec(TypedDict):
    """Time specification for simulation range.

    Attributes:
        start: Start time for simulation
        end: End time for simulation
        step: Optional time step for output points. If None, determined by solver.

    Examples:
        Positional arguments:
        >>> TimeSpec(0, 10)  # Simulate from 0 to 10, solver determines step
        >>> TimeSpec(0, 10, 0.1)  # Simulate from 0 to 10, with 0.1 step

        Explicit keyword arguments (recommended):
        >>> TimeSpec(start=0, end=10)  # Auto step
        >>> TimeSpec(start=0, end=10, step=0.1)  # Explicit step
        >>> TimeSpec(start=5, end=15, step=0.05)  # Different range
    """

    start: NotRequired[float]
    end: float
    step: NotRequired[float]


def wrap_events(
    events: list[Callable],
    state_components: list[str],
    inputs: dict[str, float | Callable],
    parameters: dict[str, float | str],
) -> list[Callable]:
    parameters = frozendict(parameters)

    def wrap_event(event) -> Callable:
        @wraps(event)
        def event_wrapper(time, state):
            state = frozendict(zip(state_components, state))
            frozen_inputs = frozendict(
                (k, v) for k, v in inputs.items() if k not in state_components
            )
            return safe_call(
                event,
                time=time,
                state=state,
                inputs=frozen_inputs,
                parameters=parameters,
            )

        if hasattr(event, "terminal"):
            setattr(event_wrapper, "terminal", event.terminal)

        if hasattr(event, "direction"):
            setattr(event_wrapper, "direction", event.direction)

        return event_wrapper

    return [wrap_event(event) for event in events]


def collect_nested_events(
    model, parents=None
) -> list[tuple[Callable, object, list[object]]]:
    """Recursively collect events from a model and all its nested submodels.

    Returns list of (event, owner_model, parent_chain) tuples where parent_chain
    is the list of ancestor models from root to immediate parent.
    """
    if parents is None:
        parents = []

    events = [(event, model, parents) for event in model.events]

    for function in model.dynamics:
        if getattr(function, "_is_submodel_function", False):
            submodel = getattr(function, "_model")
            new_parents = parents + [model]
            events.extend(collect_nested_events(submodel, new_parents))

    return events


def wrap_nested_events(
    model,
    state_components: list[str],
    inputs: dict,
    runtime_parameters: dict = None,
) -> list[Callable]:
    """Wrap all events (from parent and nested models) with proper state extraction.

    For each event, this function:
    - Extracts only the relevant state components for that model
    - Merges parameters from all ancestor models in the hierarchy plus runtime overrides
    - Filters inputs to exclude state component keys

    Args:
        model: The root model to collect events from
        state_components: List of all state component names in the system
        inputs: Dict of inputs/outputs (used to filter out state components)
        runtime_parameters: Dict of runtime parameter overrides
    """
    if runtime_parameters is None:
        runtime_parameters = {}

    all_events = collect_nested_events(model)
    wrapped = []

    for event, owner_model, parent_chain in all_events:

        @wraps(event)
        def event_wrapper(
            time, state, event=event, owner_model=owner_model, parent_chain=parent_chain
        ):
            # Convert numpy array to full state dict first
            full_state = frozendict(zip(state_components, state))

            # Extract only the owner model's state components
            local_state = frozendict(
                {k: full_state[k] for k in owner_model.state_components}
            )

            # Merge parameters from root down: root | ... | intermediate | owner | runtime
            merged_params = {}
            for ancestor in parent_chain:
                merged_params = merged_params | ancestor.parameters
            merged_params = merged_params | owner_model.parameters
            merged_params = merged_params | runtime_parameters

            local_inputs = frozendict(
                {k: v for k, v in inputs.items() if k not in state_components}
            )

            return safe_call(
                event,
                time=time,
                state=local_state,
                inputs=local_inputs,
                parameters=frozendict(merged_params),
            )

        if hasattr(event, "terminal"):
            setattr(event_wrapper, "terminal", event.terminal)
        if hasattr(event, "direction"):
            setattr(event_wrapper, "direction", event.direction)

        wrapped.append(event_wrapper)

    return wrapped


def unpack_dict_with_variable_values(
    dict_: dict | list[dict] | None,
) -> tuple[list[dict | None], set[str]]:
    if dict_ is None:
        return [None], set()

    if isinstance(dict_, list):
        # If all dicts have the same keys, find variable keys
        if all(isinstance(d, dict) for d in dict_):
            keys = set(dict_[0].keys())
            if all(set(d.keys()) == keys for d in dict_):
                variable_keys = {k for k in keys if len({d[k] for d in dict_}) > 1}
                return dict_, variable_keys
        # Otherwise, expand each dict individually
        expanded_dicts = []
        variable_keys = set()
        for d in dict_:
            expanded, keys = unpack_dict_with_variable_values(d)
            expanded_dicts.extend(expanded)
            variable_keys |= keys
        return expanded_dicts, variable_keys

    elif isinstance(dict_, dict):
        # Find keys with list values
        list_keys = [k for k, v in dict_.items() if isinstance(v, list)]
        variable_keys = set(list_keys)
        if not list_keys:
            return [dict_], variable_keys
        list_values = [dict_[k] for k in list_keys]
        expanded_dicts = []
        for combination in itertools.product(*list_values):
            new_dict = dict_.copy()
            for k, v in zip(list_keys, combination):
                new_dict[k] = v
            expanded_dicts.append(new_dict)
        return expanded_dicts, variable_keys

    else:
        raise TypeError("Input must be a dict, list of dicts, or None.")


T = TypeVar("T")


@functools.cache
def get_signature(fn: Callable[..., T]) -> tuple[bool, set]:
    """Get the signature of a function, unwrapping it if necessary."""
    sig = inspect.signature(fn)
    accepts_kwargs = any(p.kind == p.VAR_KEYWORD for p in sig.parameters.values())
    accepted_keywords = {k for k, _ in sig.parameters.items()}
    return accepts_kwargs, accepted_keywords


def safe_call(fn: Callable[..., T], **kwargs) -> T:
    """Call a function with only the kwargs it explicitly accepts."""
    accepts_kwargs, accepted_keywords = get_signature(fn)

    if accepts_kwargs:
        # TODO: write tests for safe_called function that accepts kwargs?
        return fn(**kwargs)

    return fn(**{k: kwargs[k] for k in accepted_keywords})


def unwrap(func: Callable) -> Callable:
    """Unwraps a function from any decorators."""
    if hasattr(func, "__wrapped__"):
        return unwrap(func.__wrapped__)
    return func


def compare_function_lists(a, b):
    for a_, b_ in zip(a, b, strict=True):
        if unwrap(a_) != unwrap(b_):
            return False
    return True


class SimulationResults(list):
    def select(self, keep_list=False, **kwargs):
        filtered = [
            df for df in self if all(df.attrs.get(k) == v for k, v in kwargs.items())
        ]
        if not keep_list and len(filtered) == 1:
            return filtered[0]
        if len(filtered) == 0:
            msg = f"No simulation results found for criteria: {kwargs}."
            raise ValueError(msg)
        return filtered
