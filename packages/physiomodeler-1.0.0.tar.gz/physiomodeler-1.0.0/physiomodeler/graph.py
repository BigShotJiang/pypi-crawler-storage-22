# -*- coding: utf-8 -*-
# ---
# jupyter:
#   jupytext:
#     cell_metadata_filter: -all
#     custom_cell_magics: kql
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.11.2
#   kernelspec:
#     display_name: physiomodeler (3.11.14)
#     language: python
#     name: python3
# ---

# %%
import base64
import json
import pathlib
import tempfile
from functools import wraps

import numpy as np
from IPython.display import Image, display
from playwright.sync_api import sync_playwright

from physiomodeler import _helpers as h
from physiomodeler import _converters as c


# %%
class ReadTrackingDict(dict):
    def __init__(self, data, sink):
        super().__init__(data)
        self._sink = sink

    def __getitem__(self, k):
        self._sink.add(k)
        try:
            return super().__getitem__(k)
        except KeyError:
            return 1

    def get(self, k, default=None):
        if k in self:
            self._sink.add(k)
        return super().get(k, default)


# %%
class Graph:
    def __init__(self, model):
        self.model = model

    def generate(self, lines_fun=None, return_update_function: bool = False, **kwargs):
        lines = [
            '%%{init: {"flowchart": {"defaultRenderer": "elk", "curve": "linear" ,"titleTopMargin": 0}, "securityLevel": "loose" }}%%',
        ]

        def add_line(line):
            lines.append(line)

        if not lines_fun:
            lines_fun = add_line

        def set_trace(fn):
            setattr(fn, "_is_traced_function", True)
            fn._traced_state = set()
            fn._traced_inputs = set()
            fn._traced_parameters = set()
            fn._traced_output = set()

            @wraps(fn)
            def tracer(time=None, state=None, inputs=None, parameters=None):
                state = ReadTrackingDict(state or {}, fn._traced_state)
                inputs = ReadTrackingDict(inputs or {}, fn._traced_inputs)
                parameters = ReadTrackingDict(parameters or {}, fn._traced_parameters)
                result = h.safe_call(
                    fn, time=time, state=state, inputs=inputs, parameters=parameters
                )
                fn._traced_output.update(result.keys())
                return result

            return tracer

        functions = self.model.dynamics
        new_functions = []
        for function in functions:
            if getattr(function, "_is_submodel_function", False):
                submodel = getattr(function, "_model")
                print(f"Submodel: {submodel.name or 'Unnamed Model'}")
                submodel_dynamics = Graph(submodel).generate(
                    return_update_function=True
                )
                new_model = submodel.replace(dynamics=submodel_dynamics)
                new_function = c.convert_model_to_function(new_model)
                new_functions.append(new_function)
            else:
                function = set_trace(function)
                print(function.__name__)
                new_functions.append(function)

        if return_update_function:
            return new_functions

        trace = self.model.replace(dynamics=new_functions)
        trace(time=np.array([0, 1]), **kwargs)

        lines_fun("flowchart-elk LR")
        lines_fun("classDef hidden_sub stroke:none,fill:none")
        connections = []
        all_inputs = set()
        outputs = set()
        for func in trace.dynamics:
            if getattr(func, "_is_traced_function", False):
                lines_fun(
                    f'subgraph sub_{func.__name__} ["<div style="width:0em; height:0em; display:flex; justify-content: flex-start; align-items:flex-end;"></div>"]'
                )
                connections.append(f"class sub_{func.__name__} hidden_sub")

                lines_fun(
                    f'{func.__name__}@{{ shape: subproc, label= "{func.__name__}" }}'
                )

                for output in func._traced_output:
                    lines_fun(f'{output}@{{ shape: lean-r, label: "{output}" }}')
                    connections.append(f"{func.__name__} --> {output}")
                    outputs.add(output)

                for k, v in self.model.state_derivative_label_map.items():
                    if v in func._traced_output:
                        lines_fun(
                            f'subgraph int_{k} ["<div style="width:0em; height:0em; display:flex; justify-content: flex-start; align-items:flex-end;"></div>"]'
                        )
                        connections.append(f"class int_{k} hidden_sub")
                        lines_fun(f"{v}")
                        lines_fun(f'{k}@{{ shape: das, label: "{k}" }}')
                        lines_fun(f"{v} --> I{v}[∫] --> {k}")
                        lines_fun("end")

                for state in func._traced_state:
                    connections.append(f"{state} --> {func.__name__}")

                if len(func._traced_inputs) > 0:
                    for input_ in func._traced_inputs:
                        connections.append(f"{input_} --> {func.__name__}")
                        all_inputs.add(input_)

                if len(func._traced_parameters) > 0:
                    params = r"\n".join(func._traced_parameters)
                    line = f'{func.__name__}_params@{{ shape: brace-r, label: "{params}" }} --> {func.__name__}'
                    lines_fun(line)
                lines_fun("end")
            else:
                submodel = getattr(func, "_model", None)
                if submodel is not None:
                    lines_fun(f'subgraph {submodel.name}["Model {submodel.name}"]')
                    for subfunc in submodel.dynamics:
                        if getattr(subfunc, "_is_traced_function", False):
                            lines_fun(
                                f'{subfunc.__name__}@{{ shape: subproc, label= "{subfunc.__name__}" }}'
                            )

                        for k, v in submodel.state_derivative_label_map.items():
                            if v in subfunc._traced_output:
                                lines_fun(
                                    f'subgraph int_{k} ["<div style="width:0em; height:0em; display:flex; justify-content: flex-start; align-items:flex-end;"></div>"]'
                                )
                                connections.append(f"class int_{k} hidden_sub")

                                lines_fun(f"{v}")
                                lines_fun(f'{k}@{{ shape: das, label: "{k}" }}')
                                lines_fun(f"{v} --> I{v}[∫] --> {k}")
                                lines_fun("end")

                        for state in subfunc._traced_state:
                            connections.append(f"{state} --> {subfunc.__name__}")

                        for input_ in subfunc._traced_inputs:
                            connections.append(f"{input_} --> {subfunc.__name__}")
                            all_inputs.add(input_)

                        print(f"{subfunc._traced_parameters=}")
                        if len(subfunc._traced_parameters) > 0:
                            params = r"\n".join(subfunc._traced_parameters)
                            line = f'{subfunc.__name__}_params@{{ shape: brace-r, label: "{params}" }}'
                            lines_fun(line)
                            connections.append(
                                f"{subfunc.__name__}_params --> {subfunc.__name__}"
                            )

                        for output in subfunc._traced_output:
                            if (
                                output
                                not in submodel.state_derivative_label_map.values()
                            ):
                                lines_fun(f"{output}")
                            connections.append(f"{subfunc.__name__} --> {output}")
                            outputs.add(output)

                    lines_fun("end")
        true_inputs = all_inputs - outputs - set(self.model.state_components)
        if len(true_inputs):
            lines_fun(
                'subgraph true_inputs ["<div style="width:0em; height:0em; display:flex; justify-content: flex-start; align-items:flex-end;"></div>"]'
            )
            connections.append("class true_inputs hidden_sub")
            for true_input in true_inputs:
                lines_fun(f'{true_input}@{{ shape: stadium, label: "{true_input}" }}')
            lines_fun("end")
        lines.extend(connections)
        return "\n".join(lines)

    def render(self):
        self.mm(self.generate())

    def mm_ink(self, graphbytes):
        """Given a bytes object holding a Mermaid-format graph, return a URL that will generate the image."""
        base64_bytes = base64.b64encode(graphbytes)
        base64_string = base64_bytes.decode("ascii")
        return "https://kroki.io/mermaid/png/" + base64_string

    def mm_display(self, graphbytes):
        """Given a bytes object holding a Mermaid-format graph, display it."""
        display(Image(url=self.mm_ink(graphbytes)))

    def mm(self, graph):
        """Given a string containing a Mermaid-format graph, display it."""
        graphbytes = graph.encode("utf8")
        self.mm_display(graphbytes)

    def mm_link(self, graph):
        """Given a string containing a Mermaid-format graph, return URL for display."""
        graphbytes = graph.encode("utf8")
        return self.mm_ink(graphbytes)

    def mm_path(self, path):
        """Given a path to a file containing a Mermaid-format graph, display it"""
        with open(path, "rb") as f:
            graphbytes = f.read()
        self.mm_display(graphbytes)

    def mm_save(self, graph, path):
        """Given a string containing a Mermaid-format graph, save the image to the given path."""
        url = self.mm_link(graph)
        import requests

        response = requests.get(url)
        with open(path, "wb") as f:
            f.write(response.content)


HTML_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<style>
  html,body{{margin:0;padding:0;background:transparent}}
  .mermaid{{font-family:Arial}}
</style>
</head>
<body>
<div id="mmd" class="mermaid">
{code}
</div>
<script type="module">

  import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs";
  import elkLayouts from "https://cdn.jsdelivr.net/npm/@mermaid-js/layout-elk@0.2.0/dist/mermaid-layout-elk.esm.min.mjs";
  
  mermaid.registerLayoutLoaders(elkLayouts);

  const cfg = {config};
  if (!('startOnLoad' in cfg)) cfg.startOnLoad = false;
  mermaid.initialize(cfg);
  mermaid.run({{ querySelector: '#mmd' }});
</script>
</body>
</html>
"""


def mermaid_to_files(
    code: str,
    svg_path: str,
    config: dict = {
        "startOnLoad": False,
        "securityLevel": "loose",
        "layout": "elk",
    },
    scale: float = 2.0,
):
    html = HTML_TEMPLATE.format(code=code, config=json.dumps(config))

    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".html")
    tmp.write(html.encode("utf-8"))
    tmp.flush()

    svg_path = pathlib.Path(svg_path)
    png_path = svg_path.with_suffix(".png")
    html_path = svg_path.with_suffix(".html")
    txt_path = svg_path.with_suffix(".txt")

    html_path.write_text(html)
    txt_path.write_text(code)

    with sync_playwright() as p:
        browser = p.firefox.launch()
        page = browser.new_page()
        page.goto("file://" + tmp.name)
        # Wait mermaid to finish
        page.wait_for_selector("svg")
        # Extract SVG
        svg_content = page.eval_on_selector("svg", "el => el.outerHTML")
        svg_path.write_text(svg_content, encoding="utf-8")
        if png_path:
            # Size to content
            svg = page.locator("svg")
            bb = svg.bounding_box()
            page.set_viewport_size(
                {"width": int(bb["width"] * scale), "height": int(bb["height"] * scale)}
            )
            # Screenshot only the svg element
            png_data = svg.screenshot(scale="css")
            png_path.write_bytes(png_data)
        browser.close()
    return svg_path, png_path
