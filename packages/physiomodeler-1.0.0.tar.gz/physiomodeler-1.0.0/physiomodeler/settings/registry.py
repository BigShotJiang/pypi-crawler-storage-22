from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import field, make_dataclass
from typing import TypeAlias, Union

from camel_converter import to_snake

from physiomodeler.settings.settings_base import SettingsBase


def nested_defaultdict_factory():
    return defaultdict(nested_defaultdict_factory)


RegistryType: TypeAlias = dict[str, Union[type[SettingsBase], "RegistryType"]]
_REGISTRY: RegistryType = nested_defaultdict_factory()

name_pattern = re.compile(r"^[_A-z][A-z0-9_]*$")


def register_settings(cls: type[SettingsBase], *, name: str | None = None):
    if name is None:
        name = to_snake(cls.__name__)

    if not isinstance(name, str):
        raise TypeError("Name should be a string, not a '{type(name)}'.")

    name = name.removesuffix("_settings")
    names = name.split(".")

    if not all(name_pattern.match(name) for name in names):
        raise ValueError(
            f"Name must be a valid identifier (or dot-separated identifiers), not '{name}'."
        )

    registry: RegistryType = _REGISTRY

    while len(names) > 1:
        registry: RegistryType = registry[names.pop(0)]

    stem = names[0]
    if stem in registry:
        raise KeyError(f"'{stem}' already exists in registry.")
    registry[stem] = cls


def get_settings_root_class(name: str = "Settings"):
    return get_dataclass_definition(_REGISTRY, name)


def get_dataclass_definition(registry: RegistryType, dataclass_name: str):
    attributes = []

    for name, value in registry.items():
        if not isinstance(name, str):
            raise TypeError("Name should be a string, not a '{type(name)}'.")

        if isinstance(value, type) and issubclass(value, SettingsBase):
            # attribute is a class
            attributes.append((name, value, field(default_factory=value)))

        elif isinstance(value, dict):
            # attribute is a subregistry
            value = get_dataclass_definition(value, name)
            attributes.append((name, value, field(default_factory=value)))

        else:
            raise TypeError(
                f"Unknown type '{type(value)}' for key '{name}' in registry."
            )

    return make_dataclass(dataclass_name, attributes)
