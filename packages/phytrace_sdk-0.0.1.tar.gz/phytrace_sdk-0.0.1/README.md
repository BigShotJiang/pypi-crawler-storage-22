# phytrace-sdk

PhyTrace SDK for autonomous systems telemetry capture and streaming.

**This package is under active development.** See [phyware.io](https://phyware.io) for details.
