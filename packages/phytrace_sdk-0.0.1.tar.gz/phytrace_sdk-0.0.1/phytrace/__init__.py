"""PhyTrace SDK - Telemetry capture and streaming for autonomous systems.

This package is under active development. See https://phyware.io for details.
"""

__version__ = "0.0.1"
