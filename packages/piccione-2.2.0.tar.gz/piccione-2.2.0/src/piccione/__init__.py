"""PICCIONE - Python Interface for Cloud Content Ingest and Outbound Network Export."""

__version__ = "0.1.0"
