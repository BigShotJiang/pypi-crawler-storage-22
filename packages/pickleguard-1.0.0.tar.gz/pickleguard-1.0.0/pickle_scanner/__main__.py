"""Entry point for running as python -m pickle_scanner."""

from pickle_scanner.cli import main

if __name__ == '__main__':
    main()
