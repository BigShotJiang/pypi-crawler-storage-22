"""Pickle Scanner test suite."""
