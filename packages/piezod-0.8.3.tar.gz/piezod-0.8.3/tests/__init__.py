"""Tests for piezod package."""
