import json
from pathlib import Path
from xml.etree import ElementTree as ET

def compute_sitemap(app):
    if hasattr(app, '_cached_sitemap'):
        return app._cached_sitemap
    from sphinx import addnodes
    env = app.builder.env
    master = env.config.master_doc

    def get_children(pagename):
        toc = env.tocs.get(pagename)
        if toc is None:
            return []
        children = []
        for toctree_node in toc.findall(addnodes.toctree):
            for title, ref in toctree_node['entries']:
                is_self = ref == 'self'
                if is_self:
                    ref = pagename
                if title is None:
                    title = env.titles[ref].astext() if ref in env.titles else ref
                path = app.builder.get_target_uri(ref)
                children.append({
                    'title': title,
                    'path': path,
                    'children': [] if is_self else get_children(ref),
                })
        return children

    sitemap = get_children(master)
    app._cached_sitemap = sitemap
    return sitemap

def normalize_path(path):
    import re
    path = re.sub(r'\.html$', '', path)
    path = re.sub(r'/index$', '', path)
    path = re.sub(r'/$', '', path)
    return path

def find_secnav(entries, path, parent=None, root_entries=None, root_page=None):
    if root_entries is None:
        root_entries = entries

    # For root page, show root title + top-level items with ">" suffix for expandable items
    is_root = root_page and normalize_path(path) == normalize_path(root_page['path'])
    if is_root:
        items = [{'title': root_page['title'], 'path': root_page['path'], 'type': 'link'}]
        for e in root_entries:
            suffix = ' >' if e['children'] else ''
            items.append({
                'title': e['title'] + suffix,
                'path': e['path'],
                'type': 'expandable' if e['children'] else 'link',
                'has_children': bool(e['children'])
            })
        return {'parent': None, 'items': items}

    normalized = normalize_path(path)
    for entry in entries:
        if normalize_path(entry['path']) == normalized:
            if entry['children']:
                # Show: back link, section label, "Overview" link, children
                # Back link goes to root for top-level sections
                effective_parent = root_page
                items = [
                    {'title': entry['title'], 'path': entry['path'], 'type': 'label'},
                    {'title': 'Overview', 'path': entry['path'], 'type': 'link'}
                ]
                for c in entry['children']:
                    suffix = ' >' if c['children'] else ''
                    items.append({
                        'title': c['title'] + suffix,
                        'path': c['path'],
                        'type': 'expandable' if c['children'] else 'link',
                        'has_children': bool(c['children'])
                    })
                return {
                    'parent': {'title': effective_parent['title'], 'path': effective_parent['path']},
                    'items': items,
                }
            if parent:
                # Child page within a section - show parent's items
                # Check if parent is a top-level section by comparing with root_entries
                parent_is_top_level = any(normalize_path(e['path']) == normalize_path(parent['path']) for e in root_entries)
                effective_parent = root_page if parent_is_top_level else {'title': parent['title'], 'path': parent['path']}
                items = [
                    {'title': parent['title'], 'path': parent['path'], 'type': 'label'},
                    {'title': 'Overview', 'path': parent['path'], 'type': 'link'}
                ]
                for c in parent['children']:
                    suffix = ' >' if c['children'] else ''
                    items.append({
                        'title': c['title'] + suffix,
                        'path': c['path'],
                        'type': 'expandable' if c['children'] else 'link',
                        'has_children': bool(c['children'])
                    })
                return {
                    'parent': {'title': effective_parent['title'], 'path': effective_parent['path']},
                    'items': items,
                }
            # Top-level item without children
            items = [{'title': root_page['title'], 'path': root_page['path'], 'type': 'link'}]
            for e in root_entries:
                suffix = ' >' if e['children'] else ''
                items.append({
                    'title': e['title'] + suffix,
                    'path': e['path'],
                    'type': 'expandable' if e['children'] else 'link',
                    'has_children': bool(e['children'])
                })
            return {'parent': None, 'items': items}
        if entry['children']:
            result = find_secnav(entry['children'], path, entry, root_entries, root_page)
            if result:
                return result

    # Fallback
    items = [{'title': root_page['title'], 'path': root_page['path'], 'type': 'link'}]
    for e in root_entries:
        suffix = ' >' if e['children'] else ''
        items.append({
            'title': e['title'] + suffix,
            'path': e['path'],
            'type': 'expandable' if e['children'] else 'link',
            'has_children': bool(e['children'])
        })
    return {'parent': None, 'items': items}

def strip_toc_title(toc_html):
    """Remove the H1 (document title) from the ToC, keeping only H2+ entries."""
    if not toc_html or not toc_html.strip():
        return toc_html
    try:
        root = ET.fromstring(toc_html)
        first_li = root.find('li')
        if first_li is not None:
            nested_ul = first_li.find('ul')
            if nested_ul is not None:
                return ET.tostring(nested_ul, encoding='unicode', method='html')
        return toc_html
    except ET.ParseError:
        return toc_html

def write_content_fragment(app, pagename, templatename, context, doctree):
    content_dir = Path(app.outdir) / '_content'
    content_dir.mkdir(exist_ok=True)
    body = context.get('body', '')
    content = content_dir / Path(f'{pagename}.html')
    content.parent.mkdir(exist_ok=True, parents=True)
    content.write_text(body, encoding='utf-8')
    toc_dir = Path(app.outdir) / '_toc'
    toc_dir.mkdir(exist_ok=True)
    toc = strip_toc_title(context.get('toc', ''))
    context['toc'] = toc
    tocpath = toc_dir / Path(f'{pagename}.html')
    tocpath.parent.mkdir(exist_ok=True, parents=True)
    tocpath.write_text(toc, encoding='utf-8')
    sitemap = compute_sitemap(app)
    context['sitemap_json'] = json.dumps(sitemap)
    context['sitemap_entries'] = sitemap
    env = app.builder.env
    master = env.config.master_doc
    master_title = env.titles[master].astext() if master in env.titles else 'Home'
    master_path = app.builder.get_target_uri(master)
    root_page = {'title': master_title, 'path': master_path}
    page_uri = app.builder.get_target_uri(pagename)
    context['secnav'] = find_secnav(sitemap, page_uri, root_page=root_page)
    context['root_page_json'] = json.dumps(root_page)
    # Check for nobreadcrumbs metadata
    page_meta = context.get('meta') or {}
    show_breadcrumbs = 'nobreadcrumbs' not in page_meta
    context['show_breadcrumbs'] = show_breadcrumbs
    # Write metadata JSON for SPA navigation
    meta_dir = Path(app.outdir) / '_meta'
    meta_dir.mkdir(exist_ok=True)
    metapath = meta_dir / Path(f'{pagename}.json')
    metapath.parent.mkdir(exist_ok=True, parents=True)
    metapath.write_text(json.dumps({'showBreadcrumbs': show_breadcrumbs}), encoding='utf-8')

def write_sitemap_json(app, exception):
    if exception:
        return
    sitemap = compute_sitemap(app)
    sitemap_dir = Path(app.outdir) / '_sitemap'
    sitemap_dir.mkdir(exist_ok=True)
    (sitemap_dir / 'sitemap.json').write_text(json.dumps(sitemap), encoding='utf-8')

def setup(app):
    app.add_html_theme('pimadesp', Path(__file__).resolve().parent)
    app.connect('html-page-context', write_content_fragment)
    app.connect('build-finished', write_sitemap_json)
