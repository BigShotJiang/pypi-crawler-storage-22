:github_url: https://github.com/stephane-caron/pink/tree/main/doc/limits.rst

.. _Limits:

******
Limits
******

.. automodule:: pink.limits
    :members:
