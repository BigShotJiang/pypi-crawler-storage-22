:github_url: https://github.com/stephane-caron/pink/tree/main/doc/tasks.rst

.. _Tasks:

*****
Tasks
*****

.. automodule:: pink.tasks
    :members:
