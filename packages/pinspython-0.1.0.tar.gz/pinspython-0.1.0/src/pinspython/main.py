import argparse
import os
import subprocess

def enable_powershell_shortcuts():
    # 1. Get the path to the PowerShell profile
    # We use a command to ask PowerShell where its profile is
    try:
        profile_path = subprocess.check_output(
            ["powershell", "-NoProfile", "-Command", "$PROFILE"], 
            text=True
        ).strip()
        
        # 2. Define the shortcuts we want to add
        shortcuts = '''
# --- PinsPython Shortcuts ---
function p {
    if ($args.Count -eq 0) { python --help }
    else { python "$($args[0]).py" $args[1..$args.Count] }
}
function pi { pip install $args }
# ----------------------------
'''
        
        # 3. Create the directory if it doesn't exist
        os.makedirs(os.path.dirname(profile_path), exist_ok=True)
        
        # 4. Append to the profile (or create it)
        with open(profile_path, "a" if os.path.exists(profile_path) else "w") as f:
            f.write(shortcuts)
            
        print(f"✅ Shortcuts added to: {profile_path}")
        print("👉 Restart PowerShell to start using 'p' and 'pi'!")
        
    except Exception as e:
        print(f"❌ Failed to enable shortcuts: {e}")

def main():
    parser = argparse.ArgumentParser(prog="pins", description="PinsPython CLI Tool")
    parser.add_argument("--enable-shortcuts", action="store_true", help="Setup 'p' and 'pi' in PowerShell")
    parser.add_argument("task", nargs="?", help="The task to perform")

    args = parser.parse_args()

    if args.enable_shortcuts:
        enable_powershell_shortcuts()
    elif args.task == "train":
        print("🚀 Training starting...")
    else:
        parser.print_help()

if __name__ == "__main__":
    main()