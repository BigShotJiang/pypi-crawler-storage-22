"""PIP-BOY LLM - Vault-Tec Local AI Terminal"""
__version__ = "1.0.9"
__package_name__ = "pip-boy-llm"
