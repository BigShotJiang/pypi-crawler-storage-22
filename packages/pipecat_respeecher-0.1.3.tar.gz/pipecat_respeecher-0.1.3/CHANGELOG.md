# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.3] - 2026-02-06

### Changed

- Increased timeout for audio contexts.

## [0.1.2] - 2026-01-26

### Changed

- Made the reconnection logic more robust.

## [0.1.1] - 2026-01-16

### Changed

- Adjusted the README and the publishing metadata.

## [0.1.0] - 2026-01-16

### Added

- Initial release.
