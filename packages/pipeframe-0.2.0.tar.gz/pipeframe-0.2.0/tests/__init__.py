"""Tests for PipeFrame."""
