# Trip planner example pipeline
