from pipeline_potato.exceptions.potato_exception import PotatoException


class AbortException(PotatoException):
    pass
