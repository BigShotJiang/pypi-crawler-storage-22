from pipeline_potato.exceptions.potato_exception import PotatoException


class CircularDependencyException(PotatoException):
    pass
