class PotatoException(Exception):
    pass
