from pipeline_potato.exceptions.potato_exception import PotatoException


class StepDoneException(PotatoException):
    pass
