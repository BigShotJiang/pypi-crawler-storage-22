from .semantic import SemanticOwl

__all__ = ["SemanticOwl"]