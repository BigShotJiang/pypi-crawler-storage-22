import functools
import typing
from unittest.mock import MagicMock
from unittest.mock import patch


class BotoMocks(typing.NamedTuple):
    """Data structure for boto3 mocked objects"""

    session: MagicMock
    s3_client: MagicMock


class PatchSession:
    """A Patch function for the boto3 session"""

    def __init__(self, *args, **kwargs):
        """Create decorator with arguments"""
        pass

    def __call__(self, test_function):
        """
        Decorates the specified tests function by returning a new function
        that wraps it with patching in place for mocked phalanx functions.
        """

        @patch("pipper.environment.get_session")
        def patch_session(get_session: MagicMock, *args, **kwargs):
            boto_mocks = _create_boto_mocks()
            get_session.return_value = boto_mocks.session
            test_function(boto_mocks, *args, **kwargs)

        return patch_session


def make_list_objects_response(
    contents: list | None = None, next_continuation_token: str | None = None
) -> dict:
    """..."""
    return {
        "Contents": contents or [],
        "NextContinuationToken": next_continuation_token,
    }


def _get_client(
    mocked_clients: dict[str, MagicMock], identifier: str, **kwargs
) -> MagicMock:
    """..."""
    return mocked_clients.get(identifier) or MagicMock()


def _create_boto_mocks() -> BotoMocks:
    """..."""
    s3_client = MagicMock()
    session = MagicMock()
    session.client.side_effect = functools.partial(_get_client, {"s3": s3_client})
    return BotoMocks(session=session, s3_client=s3_client)  # noqa
