"""PitLane Agent - AI agent for F1 data analysis."""

from pitlane_agent.agent import F1Agent

__version__ = "0.1.1.dev1"
__all__ = ["F1Agent", "__version__"]
