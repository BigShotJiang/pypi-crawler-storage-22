"""
Analytics (Annotations and Goals) API for Piwik PRO.
"""

from .api import AnalyticsAPI

__all__ = ["AnalyticsAPI"]
