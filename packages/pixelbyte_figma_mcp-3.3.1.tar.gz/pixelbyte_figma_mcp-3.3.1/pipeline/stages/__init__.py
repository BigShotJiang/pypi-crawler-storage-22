"""Deterministic pipeline stages."""
