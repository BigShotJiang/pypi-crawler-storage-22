"""Test suite for PixelPrompt."""
