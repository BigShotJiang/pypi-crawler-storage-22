"""Pixi-ROS: A Pixi extension for ROS package management."""

__version__ = "0.1.0"
