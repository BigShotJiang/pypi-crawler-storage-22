"""GraphQL schema for SDK server."""

import asyncio
from enum import Enum
import json
import logging
import time
import uuid
from typing import AsyncGenerator, Callable, Coroutine, Optional, cast

from graphql import GraphQLError
import janus
from pydantic import BaseModel, JsonValue
import strawberry
import strawberry.experimental.pydantic
from strawberry.scalars import JSON

from langfuse import get_client
from pixie.registry import call_application, get_application, list_applications
from pixie.session.rpc import (
    get_connected_sessions,
    send_input_to_client,
    wait_for_client_update,
)
from pixie.session.types import SessionInfo as PydanticSessionInfo
from pixie.types import (
    AppRunCancelled,
    BreakpointDetail as PydanticBreakpointDetail,
    AppRunUpdate as PydanticAppRunUpdate,
    InputRequired,
    PromptForSpan as PydanticPromptForSpan,
)
from pixie.otel_types import (
    OTLPKeyValue as PydanticOTLPKeyValue,
    OTLPSpanEvent as PydanticOTLPSpanEvent,
    OTLPSpanLink as PydanticOTLPSpanLink,
    OTLPStatus as PydanticOTLPStatus,
    OTLPSpan as PydanticOTLPSpan,
    OTLPInstrumentationScope as PydanticOTLPInstrumentationScope,
    OTLPScopeSpans as PydanticOTLPScopeSpans,
    OTLPResource as PydanticOTLPResource,
    OTLPResourceSpans as PydanticOTLPResourceSpans,
    OTLPTraceData as PydanticOTLPTraceData,
    PartialTraceData as PydanticPartialTraceData,
)

import pixie.execution_context as exec_ctx
from importlib.metadata import PackageNotFoundError, version
from pixie.prompts.graphql import (
    Mutation as PromptsMutation,
    Query as PromptsQuery,
    LlmCallInput,
    LlmCallResult,
    execute_single_llm_call,
)

from pixie.storage.graphql import (
    StorageQuery,
    StorageMutation,
)
from pixie.storage.types import Message as PydanticMessage
from pixie.agents.rating_agent import (
    RatingResult as PydanticRatingResult,
    LlmCallRatingAgentInput as PydanticLlmCallRatingInput,
    AppRunRatingAgentInput as PydanticAppRunRatingInput,
    FindBadResponseInput as PydanticFindBadResponseInput,
    FindBadLlmCallInput as PydanticFindBadLlmCallInput,
    LlmCallSpan as PydanticLlmCallSpan,
    PromptLlmCallEvalInput as PydanticPromptLlmCallEvalInput,
    rate_llm_call as execute_rate_llm_call,
    rate_app_run as execute_rate_app_run,
    find_bad_response as execute_find_bad_response,
    find_bad_llm_call as execute_find_bad_llm_call,
    rate_prompt_llm_call as execute_rate_prompt_llm_call,
)
from pixie.agents.evaluator_optimizer import (
    optimize_evaluator as execute_optimize_evaluator,
    list_optimized_evaluators as get_optimized_evaluators_list,
    get_latest_optimized_evaluator_path,
)
from pixie.strawberry_types import (
    BreakpointTiming,
    BreakpointType,
    AppRunStatus,
    Rating,
    MessageRole,
    TraceEventType,
)

# Batch size for concurrent LLM calls
BATCH_LLM_CONCURRENCY = 5


@strawberry.enum
class BatchLlmCallStatus(str, Enum):
    """Status of a batch LLM call item."""

    PENDING = "PENDING"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    ERROR = "ERROR"
    RATING = "RATING"
    """Rating is in progress for this call."""
    RATED = "RATED"
    """Rating has completed for this call."""


@strawberry.type
class BatchLlmCallRating:
    """Rating result for a batch LLM call."""

    rating: Rating
    thoughts: str


@strawberry.type
class BatchLlmCallUpdate:
    """Status update for a batch LLM call."""

    id: strawberry.ID
    """The id of the LLM call this update is for."""
    status: BatchLlmCallStatus
    result: Optional[LlmCallResult] = None
    error: Optional[str] = None
    rating_result: Optional[BatchLlmCallRating] = None
    """Rating result, present when status is RATED."""


@strawberry.type
class BatchLlmCallsUpdate:
    """Batched status updates for multiple LLM calls. Sent as a single message."""

    updates: list[BatchLlmCallUpdate]


@strawberry.type
class OptimizedEvaluatorInfo:
    """Information about an optimized evaluator version."""

    path: str
    """Full path to the evaluator file."""
    filename: str
    """Filename of the evaluator."""
    timestamp: Optional[str] = None
    """ISO timestamp when the evaluator was created."""


@strawberry.type
class OptimizeEvaluatorResult:
    """Result of evaluator optimization."""

    success: bool
    """Whether optimization was successful."""
    path: Optional[str] = None
    """Path to the saved optimized evaluator file."""
    error: Optional[str] = None
    """Error message if optimization failed."""


# Global registry for input queues per run
_input_queues: dict[str, janus.Queue] = {}


def _get_input_queue(run_id: str) -> janus.Queue:
    """Get or create the input queue for a given run ID.

    Args:
        run_id: The unique identifier of the run
    Returns:
        The queue for this run
    """
    if run_id not in _input_queues:
        _input_queues[run_id] = janus.Queue()
    return _input_queues[run_id]


logger = logging.getLogger(__name__)


# Convert Pydantic models to Strawberry types with explicit field types
@strawberry.experimental.pydantic.type(model=PydanticBreakpointDetail)
class BreakpointDetail:
    """Represents the details of a breakpoint in execution.

    This class is a data model used to define the structure of a breakpoint,
    including its name, type, timing, and optional attributes.
    """

    span_name: strawberry.auto
    breakpoint_type: BreakpointType
    breakpoint_timing: BreakpointTiming
    span_attributes: JSON | None = None


# OTLP Trace Data Strawberry Types
@strawberry.experimental.pydantic.type(model=PydanticOTLPKeyValue)
class OTLPKeyValue:
    """OTLP key-value attribute."""

    key: strawberry.auto
    value: JSON  # Dict with string_value, int_value, etc.


@strawberry.experimental.pydantic.type(model=PydanticOTLPStatus, all_fields=True)
class OTLPStatus:
    """OTLP span status."""


@strawberry.experimental.pydantic.type(model=PydanticOTLPSpanEvent, all_fields=True)
class OTLPSpanEvent:
    """OTLP span event."""


@strawberry.experimental.pydantic.type(model=PydanticOTLPSpanLink, all_fields=True)
class OTLPSpanLink:
    """OTLP span link."""


@strawberry.experimental.pydantic.type(model=PydanticOTLPSpan, all_fields=True)
class OTLPSpan:
    """OTLP span representation."""


@strawberry.experimental.pydantic.type(
    model=PydanticOTLPInstrumentationScope, all_fields=True
)
class OTLPInstrumentationScope:
    """OTLP instrumentation scope (library info)."""


@strawberry.experimental.pydantic.type(model=PydanticOTLPScopeSpans, all_fields=True)
class OTLPScopeSpans:
    """OTLP scope spans - groups spans by instrumentation scope."""


@strawberry.experimental.pydantic.type(model=PydanticOTLPResource, all_fields=True)
class OTLPResource:
    """OTLP resource - describes the entity producing telemetry."""


@strawberry.experimental.pydantic.type(model=PydanticOTLPResourceSpans, all_fields=True)
class OTLPResourceSpans:
    """OTLP resource spans - groups spans by resource."""


@strawberry.experimental.pydantic.type(model=PydanticOTLPTraceData, all_fields=True)
class OTLPTraceData:
    """Complete OTLP trace data structure.

    This matches the ExportTraceServiceRequest protobuf structure
    that Langfuse sends to its observability server.
    """


@strawberry.experimental.pydantic.type(model=PydanticPartialTraceData)
class PartialTraceData:
    """Partial trace data emitted at span start.

    Contains only the information available when a span begins,
    before it completes.
    """

    event: TraceEventType
    span_name: strawberry.auto
    trace_id: strawberry.auto
    span_id: strawberry.auto
    parent_span_id: strawberry.auto
    start_time_unix_nano: strawberry.auto
    kind: strawberry.auto
    attributes: JSON | None = None


@strawberry.type
class TraceDataUnion:
    """Union type for trace data - either complete OTLP or partial."""

    otlp_trace: Optional[OTLPTraceData] = None
    partial_trace: Optional[PartialTraceData] = None


@strawberry.experimental.pydantic.type(model=PydanticPromptForSpan)
class PromptForSpan:
    """Information about the prompt used in the application run.

    Attributes:
        trace_id: The trace ID associated with the prompt.
        span_id: The span ID associated with the prompt.
        prompt_id: Unique identifier of the prompt.
        version_id: Version identifier of the prompt.
        variables: Optional variables used in the prompt.
    """

    trace_id: strawberry.auto
    span_id: strawberry.auto
    prompt_id: strawberry.auto
    version_id: strawberry.auto
    variables: JSON | None = None


@strawberry.experimental.pydantic.type(model=PydanticMessage)
class Message:
    """Message in interaction logs."""

    role: MessageRole
    content: JSON
    time_unix_nano: Optional[str]
    user_rating: Optional[Rating] = None
    user_feedback: Optional[str] = None


@strawberry.experimental.pydantic.input(model=PydanticMessage)
class MessageInput:
    """Message input for rating requests."""

    role: MessageRole
    content: JSON
    time_unix_nano: Optional[str]
    user_rating: Optional[Rating] = None
    user_feedback: Optional[str] = None


@strawberry.experimental.pydantic.input(model=PydanticLlmCallSpan)
class LlmCallSpanInput:
    """LLM call span input for trace analysis."""

    span_type: strawberry.auto
    llm_input: JSON
    llm_output: JSON


@strawberry.experimental.pydantic.type(model=PydanticRatingResult)
class RatingResult:
    """Result of a rating operation."""

    thoughts: strawberry.auto
    rating: Rating


@strawberry.type
class AppRunUpdate:
    """Represents updates for an application run.

    This class is used to define the structure of updates related to an application run,
    including the run ID, status, data, and optional breakpoint details.

    Attributes:
        run_id: The unique identifier of the application run.
        status: The current status of the application run.
        data: Additional data associated with the application run.
        breakpoint: Optional details about a breakpoint in the application run.
        trace: Optional trace data (either complete OTLP or partial).
    """

    run_id: strawberry.ID
    status: AppRunStatus
    time_unix_nano: str
    user_input_schema: Optional[JSON] = None
    user_input: Optional[JSON] = None
    data: Optional[JSON] = None
    breakpoint: Optional[BreakpointDetail] = None
    trace: Optional[TraceDataUnion] = None
    prompt_for_span: Optional[PromptForSpan] = None

    @classmethod
    def from_pydantic(cls, instance: PydanticAppRunUpdate):
        """Convert from Pydantic AppRunUpdate to Strawberry AppRunUpdate.

        Args:
            instance: The Pydantic AppRunUpdate instance to convert.

        Returns:
            A Strawberry AppRunUpdate instance.
        """
        return cls(
            run_id=strawberry.ID(instance.run_id),
            status=AppRunStatus(instance.status),
            time_unix_nano=instance.time_unix_nano,
            user_input_schema=JSON(instance.user_input_schema),
            user_input=JSON(instance.user_input),
            data=JSON(instance.data),
            breakpoint=(
                BreakpointDetail.from_pydantic(instance.breakpoint)
                if instance.breakpoint
                else None
            ),
            trace=_convert_trace_to_union(instance.trace),
            prompt_for_span=(
                PromptForSpan.from_pydantic(instance.prompt_for_span)
                if instance.prompt_for_span
                else None
            ),
        )


@strawberry.type
class AppInfo:
    """Schema information for a registered agent.

    Attributes:
        id: The unique UUID identifier for the agent.
        name: The function name of the agent.
        qualified_name: The qualified name of the agent function.
        module: The module where the agent is defined.
        input_schema: JSON schema for the agent's input (either from Pydantic model or JsonValue type).
        user_input_schema: JSON schema for user input during execution (None for non-generator agents).
        output_schema: JSON schema for the agent's output (either from Pydantic model or JsonValue type).
    """

    id: str
    name: str
    qualified_name: str
    module: str
    short_description: Optional[str] = None
    full_description: Optional[str] = None
    input_schema: Optional[JSON] = None
    user_input_schema: Optional[JSON] = None
    output_schema: Optional[JSON] = None


@strawberry.input
class IKeyValue:
    """Key-value attribute."""

    key: str
    value: str


@strawberry.type
class TKeyValue:
    """Key-value attribute."""

    key: str
    value: str


@strawberry.experimental.pydantic.type(model=PydanticSessionInfo, all_fields=True)
class SessionInfo:
    pass


@strawberry.type
class _Query:
    """GraphQL queries."""

    @strawberry.field
    async def health_check(self) -> str:
        """Health check endpoint."""
        logger.debug("Health check endpoint called")
        try:
            version_str = version("pixie-sdk")
            logger.debug("Pixie SDK version: %s", version_str)
            return version_str
        except PackageNotFoundError as e:
            logger.warning("Failed to get Pixie SDK version: %s", str(e))
            return "0.0.0"

    @strawberry.field
    async def list_sessions(self) -> list[SessionInfo]:
        """List all active session IDs.

        Returns:
            A list of active session IDs.
        """
        sessions = await get_connected_sessions()
        return [SessionInfo.from_pydantic(s) for s in sessions]

    @strawberry.field
    def list_apps(self) -> list[AppInfo]:
        """List all registered agents with their JSON schemas.

        Returns:
            A list of AppInfo objects containing id, name, qualified_name, module,
            and input/output/user_input schemas for each registered application.
        """

        agent_schemas = []

        for app_id in list_applications():
            # Convert schema to JSON if it's a Pydantic model class
            def convert_to_json(schema_obj):
                if schema_obj is None:
                    return None
                if isinstance(schema_obj, type) and issubclass(schema_obj, BaseModel):
                    return JSON(schema_obj.model_json_schema())
                if isinstance(schema_obj, dict):
                    return JSON(schema_obj)
                return None

            app_info = get_application(app_id)
            if app_info is None:
                continue

            agent_schemas.append(
                AppInfo(
                    id=app_id,
                    name=app_info.name,
                    qualified_name=app_info.qualname,
                    module=app_info.module,
                    short_description=app_info.short_description,
                    full_description=app_info.full_description,
                    input_schema=convert_to_json(app_info.input_type),
                    user_input_schema=convert_to_json(app_info.user_input_type),
                    output_schema=convert_to_json(app_info.output_type),
                )
            )

        return agent_schemas


@strawberry.type
class _Mutation:
    """GraphQL mutations."""

    @strawberry.mutation
    async def pause_run(
        self,
        run_id: str,
        timing: BreakpointTiming = BreakpointTiming.BEFORE,
        breakpoint_types: list[BreakpointType] | None = None,
    ) -> str:
        """Pause a run at a specific breakpoint.

        Args:
            run_id: The unique identifier of the run to pause.
            timing: The timing of the breakpoint (BEFORE or AFTER).
            breakpoint_types: A list of breakpoint types to apply, or None for all.

        Returns:
            The ID of the created breakpoint configuration.
        """
        try:
            breakpt_config = exec_ctx.set_breakpoint(
                run_id,
                timing.value,
                [t.value for t in (breakpoint_types or BreakpointType)],
            )
            return breakpt_config.id
        except ValueError as e:
            raise GraphQLError(str(e)) from e

    @strawberry.mutation
    async def resume_run(self, run_id: str) -> bool:
        """Resume a paused run.

        Args:
            run_id: The unique identifier of the run to resume.

        Returns:
            A boolean indicating whether the run was successfully resumed.
        """
        return exec_ctx.resume_run(run_id)

    @strawberry.mutation
    async def send_input(self, run_id: str, input_data: JSON) -> bool:
        """Send user input to a running application.

        Args:
            run_id: The unique identifier of the run to send input to.
            input_data: The input data to send to the application.

        Returns:
            True if the input was successfully sent.

        Raises:
            GraphQLError: If sending input fails.
        """

        try:
            q = _get_input_queue(run_id)
            q.sync_q.put(input_data)
            logger.info("User input sent to run_id=%s", run_id)
            return True
        except Exception as e:
            raise GraphQLError(f"Failed to send input: {str(e)}") from e

    @strawberry.mutation
    async def send_session_input(self, session_id: str, input_data: JSON) -> bool:
        """Send user input to a running session.

        Args:
            session_id: The unique identifier of the session to send input to.
            input_data: The input data to send to the session.

        Returns:
            True if the input was successfully sent.

        Raises:
            GraphQLError: If sending input fails.
        """

        try:
            await send_input_to_client(session_id, cast(JsonValue, input_data))
            logger.info("User input sent to session_id=%s", session_id)
            return True
        except Exception as e:
            raise GraphQLError(f"Failed to send session input: {str(e)}") from e

    @strawberry.mutation
    async def rate_llm_call(
        self,
        app_description: str,
        interaction_logs_before_llm_call: list[MessageInput],
        llm_input: JSON,
        llm_output: JSON,
        llm_configuration: JSON,
        internal_logs_after_llm_call: list[JSON],
        interaction_logs_after_llm_call: list[MessageInput],
    ) -> RatingResult:
        """Rate the quality of a specific LLM call within an application execution.

        Args:
            app_description: Description of the application.
            interaction_logs_before_llm_call: Messages before the LLM call.
            llm_input: Input to the LLM.
            llm_output: Output from the LLM.
            llm_configuration: Configuration of the LLM.
            internal_logs_after_llm_call: Internal logs after the LLM call.
            interaction_logs_after_llm_call: Messages after the LLM call.

        Returns:
            RatingResult with thoughts and rating.
        """
        # Convert MessageInput to pydantic Message, manually extracting enum values
        messages_before = [
            msg.to_pydantic() for msg in interaction_logs_before_llm_call
        ]
        messages_after = [msg.to_pydantic() for msg in interaction_logs_after_llm_call]

        # Create the input signature
        rating_input = PydanticLlmCallRatingInput(
            app_description=app_description,
            interaction_logs_before_llm_call=messages_before,
            llm_input=llm_input,
            llm_output=llm_output,
            llm_configuration=llm_configuration,
            internal_logs_after_llm_call=internal_logs_after_llm_call,
            interaction_logs_after_llm_call=messages_after,
        )

        result = await execute_rate_llm_call(rating_input)
        return RatingResult.from_pydantic(result)

    @strawberry.mutation
    async def rate_run(
        self,
        run_description: str,
        interaction_logs: list[MessageInput],
    ) -> RatingResult:
        """Rate the overall quality of an app/session run.

        Args:
            run_description: Description of the run.
            interaction_logs: All messages from the run.

        Returns:
            RatingResult with thoughts and rating.
        """
        # Convert MessageInput to pydantic Message, manually extracting enum values
        messages = [
            PydanticMessage(
                role=msg.role.value,  # type: ignore
                content=msg.content,  # type: ignore
                user_rating=msg.user_rating.value if msg.user_rating else None,  # type: ignore
                user_feedback=msg.user_feedback,  # type: ignore
            )
            for msg in interaction_logs
        ]

        # Create the input signature
        rating_input = PydanticAppRunRatingInput(
            app_description=run_description,
            interaction_logs=messages,
        )

        result = await execute_rate_app_run(rating_input)
        return RatingResult.from_pydantic(result)

    @strawberry.mutation
    async def find_bad_response(
        self,
        ai_description: str,
        conversation: list[MessageInput],
        reasoning_for_negative_rating: str,
    ) -> int:
        """Find the problematic assistant message in a conversation that led to a negative rating.

        Args:
            ai_description: Description of the AI application.
            conversation: The full conversation as a list of messages.
            reasoning_for_negative_rating: Why the conversation was rated negatively.

        Returns:
            The index of the Message that was identified as the problematic response.
        """
        # Convert MessageInput to pydantic Message
        messages = [
            PydanticMessage(
                role=msg.role.value,  # type: ignore
                content=msg.content,  # type: ignore
                user_rating=msg.user_rating.value if msg.user_rating else None,  # type: ignore
                user_feedback=msg.user_feedback,  # type: ignore
            )
            for msg in conversation
        ]

        # Create the input and call the agent
        find_input = PydanticFindBadResponseInput(
            ai_description=ai_description,
            conversation=messages,
            reasoning_for_negative_rating=reasoning_for_negative_rating,
        )

        result = await execute_find_bad_response(find_input)
        return result

    @strawberry.mutation
    async def find_bad_llm_call(
        self,
        ai_description: str,
        conversation: list[MessageInput],
        trace: list[JSON],
        reasoning_for_negative_rating: str,
    ) -> int:
        """Find the problematic LLM call span in a trace that led to a bad response.

        Args:
            ai_description: Description of the AI application.
            conversation: Conversation leading up to the bad response.
                The last item is the response being labeled bad.
            trace: Server trace spans for the last message.
                Some are LLM call spans (with span_type='llm_call'), some are not.
            reasoning_for_negative_rating: Notes for the bad rating for the last
                message in conversation.

        Returns:
            The index of the LLM call span that was identified as problematic.
        """
        # Convert MessageInput to pydantic Message
        messages = [
            PydanticMessage(
                role=msg.role.value,  # type: ignore
                content=msg.content,  # type: ignore
                user_rating=msg.user_rating.value if msg.user_rating else None,  # type: ignore
                user_feedback=msg.user_feedback,  # type: ignore
            )
            for msg in conversation
        ]

        # Convert trace spans - they come as JSON dicts
        trace_spans: list[PydanticLlmCallSpan | dict] = [
            dict(span) for span in trace  # type: ignore[arg-type]
        ]

        # Create the input and call the agent
        find_input = PydanticFindBadLlmCallInput(
            ai_description=ai_description,
            conversation=messages,
            trace=trace_spans,
            reasoning_for_negative_rating=reasoning_for_negative_rating,
        )

        result = await execute_find_bad_llm_call(find_input)
        return result

    @strawberry.mutation
    async def rate_prompt_llm_call(
        self,
        prompt_description: str,
        input_messages: list[JSON],
        output: JSON,
        tools: list[JSON] | None = None,
        output_type: JSON | None = None,
    ) -> RatingResult:
        """Evaluate the quality of an LLM call using prompt template context.

        A lighter-weight evaluation that requires only the prompt description,
        input/output messages, and optional tools/output type configuration.

        Args:
            prompt_description: Description of the prompt template used to
                generate part of the input messages.
            input_messages: The input messages sent to the LLM.
            output_messages: The output messages returned by the LLM.
            tools: Optional tool definitions available to the LLM.
            output_type: Optional expected output type/schema configuration.

        Returns:
            RatingResult with thoughts and rating.
        """
        eval_input = PydanticPromptLlmCallEvalInput(
            prompt_description=prompt_description,
            input_messages=input_messages,
            output=output,
            tools=tools,
            output_type=output_type,
        )

        result = await execute_rate_prompt_llm_call(eval_input)
        return RatingResult.from_pydantic(result)

    @strawberry.mutation
    async def optimize_evaluator(
        self,
        prompt_id: str,
        max_bootstrapped_demos: int = 4,
        max_labeled_demos: int = 4,
        max_rounds: int = 5,
        train_limit: int = 100,
    ) -> OptimizeEvaluatorResult:
        """Optimize the evaluator for a specific prompt using labeled data.

        Uses BootstrapFewShot optimization with records from the LLM call storage
        that have been rated by users or system as good/bad.

        Args:
            prompt_id: The unique identifier of the prompt to optimize for.
            max_bootstrapped_demos: Maximum number of bootstrapped demonstrations.
            max_labeled_demos: Maximum number of labeled demonstrations.
            max_rounds: Maximum optimization rounds.
            train_limit: Maximum number of training examples to fetch.

        Returns:
            OptimizeEvaluatorResult with success status and path or error.
        """
        try:
            path = await execute_optimize_evaluator(
                prompt_id=prompt_id,
                max_bootstrapped_demos=max_bootstrapped_demos,
                max_labeled_demos=max_labeled_demos,
                max_rounds=max_rounds,
                train_limit=train_limit,
            )
            return OptimizeEvaluatorResult(
                success=True,
                path=str(path),
                error=None,
            )
        except Exception as e:
            logger.error(
                "Failed to optimize evaluator for prompt '%s': %s", prompt_id, str(e)
            )
            return OptimizeEvaluatorResult(
                success=False,
                path=None,
                error=str(e),
            )

    @strawberry.mutation
    async def get_optimized_evaluators(
        self,
        prompt_id: str,
    ) -> list[OptimizedEvaluatorInfo]:
        """List all optimized evaluator versions for a prompt.

        Args:
            prompt_id: The unique identifier of the prompt.

        Returns:
            List of OptimizedEvaluatorInfo for each evaluator version.
        """
        evaluators = get_optimized_evaluators_list(prompt_id)
        return [
            OptimizedEvaluatorInfo(
                path=e["path"],
                filename=e["filename"],
                timestamp=e.get("timestamp"),
            )
            for e in evaluators
        ]

    @strawberry.mutation
    async def get_latest_evaluator_path(
        self,
        prompt_id: str,
    ) -> Optional[str]:
        """Get the path to the latest optimized evaluator for a prompt.

        Args:
            prompt_id: The unique identifier of the prompt.

        Returns:
            Path to the latest evaluator file, or None if no evaluator exists.
        """
        path = get_latest_optimized_evaluator_path(prompt_id)
        return str(path) if path else None


def _convert_trace_to_union(trace_dict: dict | None) -> Optional[TraceDataUnion]:
    """Convert trace data dict to TraceDataUnion.

    Args:
        trace_dict: Dict containing either OTLP trace data or partial trace data.

    Returns:
        TraceDataUnion with the appropriate field set, or None if trace_dict is None.
    """
    if trace_dict is None:
        return None

    # Check if it's a partial trace (has 'event' field)
    if trace_dict.get("event") == "span_start":
        partial = PydanticPartialTraceData(**trace_dict)
        return TraceDataUnion(
            partial_trace=PartialTraceData.from_pydantic(partial),
            otlp_trace=None,
        )

    # Otherwise it's a complete OTLP trace
    otlp = PydanticOTLPTraceData(**trace_dict)
    return TraceDataUnion(
        otlp_trace=OTLPTraceData.from_pydantic(otlp),
        partial_trace=None,
    )


def _create_app_run_in_thread(run: Coroutine) -> tuple[Coroutine, Callable[[], None]]:
    """Create a new event loop in a thread to run the application.

    Args:
        run: The coroutine to execute in the new event loop.

    Returns:
        A tuple of (thread_coroutine, cancel_function) where thread_coroutine
        is a coroutine that runs the loop and cancel_function can cancel the task
        in a thread-safe manner.
    """
    loop = asyncio.new_event_loop()
    task: asyncio.Task | None = None

    def run_loop():
        nonlocal task
        asyncio.set_event_loop(loop)
        task = loop.create_task(run)
        try:
            loop.run_until_complete(task)
        except asyncio.CancelledError:
            pass

    def cancel():
        """Thread-safe cancellation of the task."""
        if task is not None and loop.is_running():
            loop.call_soon_threadsafe(task.cancel)

    return asyncio.to_thread(run_loop), cancel


@strawberry.type
class Subscription:
    """GraphQL subscriptions."""

    @strawberry.subscription
    async def batch_call_llm(
        self,
        calls: list[LlmCallInput],
        prompt_description: Optional[str] = None,
    ) -> AsyncGenerator[BatchLlmCallsUpdate, None]:
        """Execute multiple LLM calls and stream batched status updates.

        Uses a producer-consumer pattern with asyncio.Queue to stream updates
        as soon as each call completes, rather than waiting for entire batches.
        After each LLM call completes, runs the rating agent to evaluate it.

        Args:
            calls: List of LLM call inputs to execute.
            prompt_description: Optional description for rating context.

        Yields:
            BatchLlmCallsUpdate containing one or more status updates.
        """
        if not calls:
            return

        # First, yield pending status for all calls in a single batch
        pending_updates = [
            BatchLlmCallUpdate(
                id=call.id,
                status=BatchLlmCallStatus.PENDING,
                result=None,
                error=None,
                rating_result=None,
            )
            for call in calls
        ]
        yield BatchLlmCallsUpdate(updates=pending_updates)

        # Create a queue for streaming updates
        update_queue: asyncio.Queue[BatchLlmCallUpdate | None] = asyncio.Queue()

        async def process_single_call(call: LlmCallInput) -> None:
            """Process a single LLM call: execute, then rate."""
            call_id = call.id
            result: LlmCallResult | None = None
            error_msg: str | None = None

            # Signal that this call is running
            await update_queue.put(
                BatchLlmCallUpdate(
                    id=call_id,
                    status=BatchLlmCallStatus.RUNNING,
                    result=None,
                    error=None,
                    rating_result=None,
                )
            )

            # Execute the LLM call
            try:
                result = await execute_single_llm_call(call)
                # Yield COMPLETED status
                await update_queue.put(
                    BatchLlmCallUpdate(
                        id=call_id,
                        status=BatchLlmCallStatus.COMPLETED,
                        result=result,
                        error=None,
                        rating_result=None,
                    )
                )
            except Exception as e:
                logger.error("Error executing LLM call id=%s: %s", call_id, str(e))
                error_msg = str(e)
                # Yield ERROR status and skip rating
                await update_queue.put(
                    BatchLlmCallUpdate(
                        id=call_id,
                        status=BatchLlmCallStatus.ERROR,
                        result=None,
                        error=error_msg,
                        rating_result=None,
                    )
                )
                return

            # Now run rating if we have a successful result and prompt_description
            if result and prompt_description:
                # Signal rating in progress
                await update_queue.put(
                    BatchLlmCallUpdate(
                        id=call_id,
                        status=BatchLlmCallStatus.RATING,
                        result=result,
                        error=None,
                        rating_result=None,
                    )
                )

                try:
                    rating_input = PydanticPromptLlmCallEvalInput(
                        prompt_description=prompt_description,
                        input_messages=result.input,  # type: ignore[arg-type]
                        output=result.output,
                        tools=result.tool_calls,
                        output_type=call.output_schema,
                    )

                    rating_result = await execute_rate_prompt_llm_call(rating_input)

                    # Convert Literal rating to strawberry enum
                    rating_enum = Rating(rating_result.rating)

                    await update_queue.put(
                        BatchLlmCallUpdate(
                            id=call_id,
                            status=BatchLlmCallStatus.RATED,
                            result=result,
                            error=None,
                            rating_result=BatchLlmCallRating(
                                rating=rating_enum,
                                thoughts=rating_result.thoughts,
                            ),
                        )
                    )
                except Exception as e:
                    logger.error("Error rating LLM call id=%s: %s", call_id, str(e))
                    # Still mark as ERROR but with no rating result
                    await update_queue.put(
                        BatchLlmCallUpdate(
                            id=call_id,
                            status=BatchLlmCallStatus.ERROR,
                            result=result,
                            error=f"Rating failed: {str(e)}",
                            rating_result=None,
                        )
                    )

        async def producer(call_list: list[LlmCallInput]) -> None:
            """Process all calls using a semaphore to limit concurrency."""
            semaphore = asyncio.Semaphore(BATCH_LLM_CONCURRENCY)

            async def limited_process(call: LlmCallInput) -> None:
                async with semaphore:
                    await process_single_call(call)

            # Run all calls concurrently, limited by semaphore
            await asyncio.gather(
                *[limited_process(call) for call in call_list],
                return_exceptions=True,
            )
            # Signal completion
            await update_queue.put(None)

        # Start producer in background
        producer_task = asyncio.create_task(producer(calls))

        # Consumer: yield updates as they arrive
        try:
            while True:
                update = await update_queue.get()
                if update is None:
                    # Producer finished
                    break
                yield BatchLlmCallsUpdate(updates=[update])
        finally:
            # Ensure producer completes
            if not producer_task.done():
                producer_task.cancel()
                try:
                    await producer_task
                except asyncio.CancelledError:
                    pass

    @strawberry.subscription
    async def run_session(self, session_id: str) -> AsyncGenerator[AppRunUpdate, None]:
        """Subscribe to application run updates for a session.

        Args:
            session_id: The unique identifier of the session.
        Yields:
            AppRunUpdate: Status updates including run status, data, breakpoints, and traces.
        """
        try:
            while True:
                session_update = await wait_for_client_update(session_id)
                app_update = PydanticAppRunUpdate(
                    run_id=session_update.session_id,
                    status=session_update.status,
                    time_unix_nano=session_update.time_unix_nano,
                    user_input_schema=session_update.user_input_schema,
                    user_input=session_update.user_input,
                    data=session_update.data,
                    trace=session_update.trace,
                    prompt_for_span=session_update.prompt_for_span,
                )
                yield AppRunUpdate.from_pydantic(app_update)
                if app_update.status in (
                    "completed",
                    "error",
                    "cancelled",
                ):
                    break
        except Exception as e:
            logger.error(
                "Error in run_session subscription for session_id=%s: %s",
                session_id,
                str(e),
            )
            raise GraphQLError(f"Subscription error: {str(e)}") from e

    @strawberry.subscription
    async def run(
        self,
        id: str,
        input_data: JSON | None,
    ) -> AsyncGenerator[AppRunUpdate, None]:
        """Run an application and stream results.

        Args:
            id: The UUID identifier of the registered application.
            input_data: JSON input data (or None if the application takes no input).

        Yields:
            AppRunUpdate: Status updates including run status, data, breakpoints, and traces.
        """
        # Generate unique run ID
        run_id = str(uuid.uuid4())
        logger.info("Starting run: app=%s, run_id=%s", id, run_id)

        langfuse = get_client()

        if langfuse.auth_check():
            logger.debug("Langfuse client authenticated")
        else:
            logger.debug(
                "Langfuse authentication failed, continuing in Pixie-only mode"
            )

        # Check if application exists
        if not get_application(id):
            logger.error("Application not found: %s", id)
            pydantic_update = PydanticAppRunUpdate(
                run_id=run_id,
                status="error",
                time_unix_nano=str(time.time_ns()),
                data=json.dumps({"error": f"Application '{id}' not found"}),
            )
            yield AppRunUpdate.from_pydantic(pydantic_update)
            return

        task: Optional[asyncio.Task[None]] = None
        cancel: Optional[Callable[[], None]] = None
        ctx = exec_ctx.init_run(run_id)
        try:
            status_queue = ctx.status_queue

            # Send initial running status
            pydantic_update = PydanticAppRunUpdate(
                run_id=run_id,
                status="running",
                time_unix_nano=str(time.time_ns()),
            )
            yield AppRunUpdate.from_pydantic(pydantic_update)
            # set the context again after yield -- the fastapi/strawberry framework resets execution context
            exec_ctx.reload_run_context(run_id)

            # Create task for application execution
            async def run_application():
                app_gen = None
                try:
                    logger.debug("Executing app run_id=%s", run_id)
                    exec_ctx.reload_run_context(run_id)

                    app_gen = call_application(
                        id,
                        cast(JsonValue, input_data),
                    )

                    # Use asend pattern like in registry._wrap_generator_handler
                    user_input: JsonValue | None = None

                    try:
                        input_q = _get_input_queue(run_id)
                        while True:
                            item = await app_gen.asend(user_input)
                            # reset user input once it's sent to application
                            user_input = None

                            if isinstance(item, InputRequired):
                                exec_ctx.emit_status_update(
                                    status="waiting",
                                    user_input_requirement=item,
                                )
                                # Wait for input from queue
                                user_input = await input_q.async_q.get()
                                exec_ctx.emit_status_update(
                                    status="running",
                                    user_input=user_input,
                                )
                            else:
                                exec_ctx.emit_status_update(
                                    status="running",
                                    data=item,
                                )
                    except StopAsyncIteration:
                        pass

                    exec_ctx.emit_status_update(status="completed")
                    logger.info("Completed run_id=%s", run_id)
                except (asyncio.CancelledError, AppRunCancelled):
                    logger.info("Cancelled run_id=%s", run_id)
                    exec_ctx.emit_status_update(status="cancelled")
                    raise
                except Exception as e:  # pylint: disable=broad-except
                    logger.error("Run error run_id=%s: %s", run_id, str(e))
                    exec_ctx.emit_status_update(status="error", data={"error": str(e)})
                    raise
                finally:
                    logger.debug("Ending task run_id=%s", run_id)
                    # Close the application generator to trigger its cleanup
                    if app_gen is not None:
                        await app_gen.aclose()
                    langfuse.flush()
                    exec_ctx.emit_status_update(status=None)

            run, cancel = _create_app_run_in_thread(run_application())
            task = asyncio.create_task(run)

            # Stream status updates from queue
            while True:
                # Wait for status update with timeout
                pydantic_update = await status_queue.async_q.get()
                if pydantic_update is None:
                    break

                yield AppRunUpdate.from_pydantic(pydantic_update)
                # set the context again after yield -- the fastapi/strawberry framework resets execution context
                exec_ctx.reload_run_context(run_id)

        finally:
            # Cancel the background task if it's still running
            if task is not None and not task.done():
                logger.debug("Cancelling task run_id=%s", run_id)

                # Set cancellation flag to stop the child thread
                exec_ctx.cancel_run()

                # Cancel the child thread running the application
                if cancel:
                    cancel()

                # Cancel the asyncio task wrapper
                task.cancel()

            logger.debug("Cleanup run_id=%s", run_id)

            # Close the janus queue to release resources
            if ctx and ctx.status_queue:
                ctx.status_queue.close()
                await ctx.status_queue.wait_closed()

            exec_ctx.unregister_run(run_id)

            # Clean up input queue
            if run_id in _input_queues:
                del _input_queues[run_id]


@strawberry.type
class Query(_Query, PromptsQuery, StorageQuery):
    """Combined GraphQL query schema."""


@strawberry.type
class Mutation(_Mutation, PromptsMutation, StorageMutation):
    """Combined GraphQL mutation schema."""


# Create the schema
schema = strawberry.Schema(query=Query, mutation=Mutation, subscription=Subscription)
