from __future__ import annotations

import logging
from functools import total_ordering, wraps
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, ClassVar, TypeVar

from model_lib import Entity, dump
from pydantic import Field
from zero_3rdparty import file_utils

from pkg_ext._internal.errors import InvalidGroupSelectionError, NoPublicGroupMatch

from .py_symbols import RefSymbol
from .types import PyIdentifier, SymbolRefId, ref_id_name

if TYPE_CHECKING:  # why type checking? Can we not use the root import?
    from pkg_ext._internal.config import ProjectConfig

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=Callable)


def ensure_disk_path_updated(func: T) -> T:
    @wraps(func)
    def wrapper(self_: PublicGroups, *args: Any, **kwargs: Any) -> Any:
        try:
            return func(self_, *args, **kwargs)
        except BaseException:
            raise
        finally:
            self_.write()

    return wrapper  # type: ignore


@total_ordering
class PublicGroup(Entity):
    ROOT_GROUP_NAME: ClassVar[str] = "__ROOT__"
    name: PyIdentifier
    owned_refs: set[SymbolRefId] = Field(default_factory=set)
    owned_modules: set[str] = Field(default_factory=set)
    # Config fields (populated from GroupConfig when merging)
    dependencies: list[str] = Field(default_factory=list)
    docs_exclude: list[str] = Field(default_factory=list)
    docstring: str = ""

    @property
    def is_root(self) -> bool:
        return self.name == self.ROOT_GROUP_NAME

    @property
    def sorted_refs(self) -> list[str]:
        return sorted(self.owned_refs)

    def dump(self) -> dict:
        return self.model_dump()

    def __lt__(self, other) -> bool:
        if not isinstance(other, PublicGroup):
            raise TypeError
        return self.name < other.name


def _default_public_groups() -> list[PublicGroup]:
    return [PublicGroup(name=PublicGroup.ROOT_GROUP_NAME)]


class PublicGroups(Entity):
    groups: list[PublicGroup] = Field(default_factory=_default_public_groups)
    storage_path: Path | None = None

    @property
    def name_to_group(self) -> dict[str, PublicGroup]:
        return {group.name: group for group in self.groups}

    @property
    def groups_no_root(self) -> list[PublicGroup]:
        return sorted(group for group in self.groups if not group.is_root)

    @property
    def root_group(self) -> PublicGroup:
        root = next((group for group in self.groups if group.is_root), None)
        assert root, "root group not found"
        return root

    def matching_group(self, ref: RefSymbol) -> PublicGroup:
        if match_by_module := [group for group in self.groups if ref.module_path in group.owned_modules]:
            assert len(match_by_module) == 1, (
                f"Expected exactly one matching group for {ref.name} in {ref.module_path}, got {len(match_by_module)}"
            )
            return match_by_module[0]
        raise NoPublicGroupMatch(f"No public group found for symbol {ref.name} in module {ref.module_path}")

    def matching_group_by_module_path(self, module_path: str) -> PublicGroup:
        if match_by_module := [group for group in self.groups if module_path in group.owned_modules]:
            assert len(match_by_module) == 1, (
                f"Expected exactly one matching group for module {module_path}, got {len(match_by_module)}: {match_by_module}"
            )
            return match_by_module[0]
        raise NoPublicGroupMatch(f"No public group found for module {module_path}")

    def get_or_create_group(self, name: str) -> PublicGroup:
        group = self.name_to_group.get(name)
        if not group:
            group = PublicGroup(name=name)
            self.groups.append(group)
        return group

    @ensure_disk_path_updated
    def add_module(self, group_name: str, module_path: str) -> PublicGroup:
        group = self.get_or_create_group(group_name)
        try:
            existing = self.matching_group_by_module_path(module_path)
            if existing.name != group.name:
                raise InvalidGroupSelectionError(
                    reason=f"existing_group: {existing.name} matched for module {module_path} selected for {group_name}"
                )
            return existing
        except NoPublicGroupMatch:
            group.owned_modules.add(module_path)
            return group

    @ensure_disk_path_updated
    def add_ref(self, ref: RefSymbol, group_name: str) -> PublicGroup:
        group = self.get_or_create_group(group_name)
        try:
            matching_group = self.matching_group(ref)
            if matching_group.name != group_name:
                raise InvalidGroupSelectionError(
                    reason=f"existing_group: {matching_group.name} matched for {ref.local_id}"
                )
            group.owned_refs.add(ref.local_id)
            group.owned_modules.add(ref.module_path)
        except NoPublicGroupMatch:
            group.owned_refs.add(ref.local_id)
            group.owned_modules.add(ref.module_path)
        return group

    def merge_config(self, config: ProjectConfig) -> None:
        for name, group_cfg in config.groups.items():
            group = self.get_or_create_group(name)
            group.dependencies = group_cfg.dependencies.copy()
            group.docs_exclude = group_cfg.docs_exclude.copy()
            group.docstring = group_cfg.docstring

    def reconcile_moved_refs(self, import_id_refs: dict[str, RefSymbol]) -> int:
        """Auto-fix refs that have moved to different modules."""
        name_to_candidates: dict[str, list[RefSymbol]] = {}
        for ref in import_id_refs.values():
            name_to_candidates.setdefault(ref.name, []).append(ref)

        total_updated = 0
        for group in self.groups:
            updated_refs: set[SymbolRefId] = set()
            for ref_id in list(group.owned_refs):
                ref_name = ref_id_name(ref_id)
                candidates = name_to_candidates.get(ref_name, [])

                if not candidates:
                    updated_refs.add(ref_id)  # deleted - keep for removed_refs flow
                elif len(candidates) == 1:
                    current_id = candidates[0].local_id
                    if current_id != ref_id:
                        logger.warning(f"Symbol moved: {ref_id} -> {current_id} (group: {group.name})")
                        updated_refs.add(current_id)
                        total_updated += 1
                    else:
                        updated_refs.add(ref_id)
                elif resolved := self._resolve_ambiguous_ref(group, ref_id, candidates):
                    if resolved != ref_id:
                        logger.warning(f"Symbol moved: {ref_id} -> {resolved} (group: {group.name})")
                        total_updated += 1
                    updated_refs.add(resolved)
                else:
                    updated_refs.add(ref_id)  # unresolved - keep stale ref
            group.owned_refs = updated_refs

        if total_updated:
            self.write()
        return total_updated

    def _resolve_ambiguous_ref(
        self, group: PublicGroup, stale_ref_id: SymbolRefId, candidates: list[RefSymbol]
    ) -> SymbolRefId | None:
        # Prefer candidate in group's owned_modules
        for c in candidates:
            if c.module_path in group.owned_modules:
                return c.local_id

        # Exclude candidates owned by other groups
        other_group_refs = {ref for g in self.groups if g.name != group.name for ref in g.owned_refs}
        remaining = [c for c in candidates if c.local_id not in other_group_refs]
        if len(remaining) == 1:
            return remaining[0].local_id

        # Cannot disambiguate - log and return None
        ref_name = ref_id_name(stale_ref_id)
        logger.warning(
            f"Cannot resolve '{ref_name}' in group '{group.name}': "
            f"{len(candidates)} candidates, {len(remaining)} after exclusion"
        )
        return None

    def write(self) -> None:
        if (storage_path := self.storage_path) is None:
            return
        assert storage_path.suffix in (".yaml", ".yml")
        self.groups.sort()
        groups_dumped = []
        for group in self.groups:
            group_dict = group.model_dump(
                exclude={
                    "owned_refs",
                    "owned_modules",
                    "dependencies",
                    "docs_exclude",
                    "docstring",
                }
            )
            if owned_modules := sorted(group.owned_modules):
                group_dict["owned_modules"] = owned_modules
            if owned_refs := sorted(group.owned_refs):
                group_dict["owned_refs"] = owned_refs
            if group.dependencies:
                group_dict["dependencies"] = group.dependencies
            if group.docs_exclude:
                group_dict["docs_exclude"] = group.docs_exclude
            if group.docstring:
                group_dict["docstring"] = group.docstring
            groups_dumped.append(group_dict)
        self_dict = self.model_dump(exclude={"storage_path", "groups"})
        self_dict["groups"] = groups_dumped
        yaml_text = dump.dump_as_str(self_dict, "yaml")
        yaml_text = f"# generated by pkg-ext from pyproject.toml\n{yaml_text}"
        file_utils.ensure_parents_write_text(storage_path, yaml_text)
