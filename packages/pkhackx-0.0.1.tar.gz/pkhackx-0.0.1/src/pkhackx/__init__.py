"""
PKHackX - Pokemon Gen 3 Save File Editor

This is a placeholder package to reserve the 'pkhackx' name on PyPI.
The actual implementation is under development.

For the latest code, visit: https://github.com/EGO0118/PKHackX
"""

__version__ = "0.0.1"

def _placeholder_notice():
    """Display notice that this is a placeholder package."""
    return (
        "This is a placeholder package. "
        "The full PKHackX implementation is under development. "
        "Visit https://github.com/EGO0118/PKHackX for the latest code."
    )
