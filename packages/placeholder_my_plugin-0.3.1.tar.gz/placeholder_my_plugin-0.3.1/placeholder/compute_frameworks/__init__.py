"""Compute frameworks namespace package."""
