SECRET_KEY = "secret"
DEBUG = True

URLS_ROUTER = "app.urls.AppRouter"

INSTALLED_PACKAGES = [
    "app.test",
]

EXPLICIT_SETTING = "explicitly changed"
ENV_OVERRIDDEN_SETTING = "explicitly overridden"
