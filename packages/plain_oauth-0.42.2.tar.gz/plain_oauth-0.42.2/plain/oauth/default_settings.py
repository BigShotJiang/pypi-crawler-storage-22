from plain.runtime import Secret

OAUTH_LOGIN_PROVIDERS: Secret[dict]
