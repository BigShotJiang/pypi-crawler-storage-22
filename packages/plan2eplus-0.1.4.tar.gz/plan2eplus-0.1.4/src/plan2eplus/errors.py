# from utils4plans.printing import StyledConsole

# NotImplementedError() -> also a possibility


# TODO: whats the difference between error and an exception?
#
class IDFWritingError(Exception):
    pass


class NonExistentEpBunchTypeError(Exception):
    pass


class IDFMisunderstandingError(Exception):
    pass


class BadlyFormatedIDFError(Exception):
    pass


class InvalidPathError(Exception):
    def __init__(self, name, path):
        self.message = f"Invalid `{name}`: {path} does not exist"


# TODO add rich styling?
class InvalidEpBunchError(Exception):
    def __init__(self, expected_key, actual_key):
        self.expected_key = expected_key
        self.actual_key = actual_key

    def __str__(self):
        return f"Expected an EpBunch with key `{self.expected_key}`, but instead got one with key `{self.actual_key}`!"


class InvalidObjectError(Exception):
    def __init__(self, object_: object, name: str, param_name) -> None:
        self.object_ = object_
        self.name = name
        self.param_name = param_name

    def message(self):
        return (
            f"No object found for type {self.object_} and {self.param_name} {self.name}"
        )
