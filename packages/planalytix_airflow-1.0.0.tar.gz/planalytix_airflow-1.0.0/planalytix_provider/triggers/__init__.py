"""
Planalytix Airflow Triggers.

Deferrable triggers for Enterprise tier customers.
Coming soon - enables async waiting without occupying a worker slot.
"""

# Deferrable triggers will be added here for Enterprise customers
# These allow Airflow 2.2+ to use async waiting via triggerer
