"""Planalytix Airflow Sensors."""

from planalytix_provider.sensors.sync import PlanalytixSyncSensor

__all__ = ["PlanalytixSyncSensor"]
