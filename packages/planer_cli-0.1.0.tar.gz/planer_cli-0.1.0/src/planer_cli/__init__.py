"""Microsoft Planner CLI - Manage plans, tasks, and buckets."""

__version__ = "0.1.0"
