"""Output formatting module."""
