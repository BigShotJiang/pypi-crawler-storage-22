"""Entry point for python -m planer_cli."""

from planer_cli.cli.main import cli

if __name__ == "__main__":
    cli()
