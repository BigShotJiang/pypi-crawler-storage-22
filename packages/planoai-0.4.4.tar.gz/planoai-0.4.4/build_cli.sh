#!/bin/bash

echo "Building the cli"
uv sync
