"""Plano CLI - Intelligent Prompt Gateway."""

__version__ = "0.4.4"
