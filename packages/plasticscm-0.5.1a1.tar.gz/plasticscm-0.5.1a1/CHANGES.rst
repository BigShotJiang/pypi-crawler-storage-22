Changelog
=========

0.5.1a1 (2026-01-27)
--------------------
- 100% code linting.
- Making and mark the package typed.
- Copyright year update.
- Switched from tox to Nox for project automation.
- The documentation has been moved from Read the Docs to GitHub Pages.
- Added the nox's 'cleanup' test environment.
- Setup update (mainly dependencies) and bug fixes.

0.5.0a1 (2025-05-15)
--------------------
- The distribution is now built using 'build' instead of 'setuptools'.
- Copyright year update.
- Added support for Python 3.14
- Dropped support for Python 3.9 (due to compatibility issues).
- Added support for PyPy 3.11
- Dropped support for PyPy 3.9
- Updated Read the Docs' Python version to 3.13
- Updated tox's base_python to version 3.13
- Setup update (mainly dependencies).

0.4.0a1 (2024-09-30)
--------------------
- Dropped support for Python 3.8
- Setup update (mainly dependencies).

0.3.1a1 (2024-08-13)
--------------------
- Added support for Python 3.13
- Setup update (mainly dependencies).

0.3.0a1 (2024-01-26)
--------------------
- Setup update (now based on tox >= 4.0).
- Added support for Python 3.10, 3.11 and 3.12
- Dropped support for Python 3.7
- Added support for PyPy 3.9 and 3.10
- Copyright year update.
- The tox configuration has been moved to pyproject.toml

0.2.0a5 (2020-10-18)
--------------------
- Added support for Python 3.9
- General update, improvements and cleanup.
- Setup update and cleanup.
- Fixed docs setup.

0.1.0a6 (2020-01-17)
--------------------
- Dropped support for Python 3.5
- Added get_cm_location().
- | Forced 'query' to be a keyword-only argument for get_branches(),
  | get_labels(), get_changesets().
- Forced 'top_level' to be a keyword-only argument for create_branch().
- Fixes for get_pending_changes() and undo_pending_changes().
- Added ReadTheDocs config file.
- Setup update.

0.1.0a1 (2020-01-12)
--------------------
- Added get_item_revision().
- Docstings have been completed.
- Changes for preliminary tests.
- Added a preliminary documentation.

0.0.1a2 (2020-01-10)
--------------------
- Fixes for rename_repository() and rename_workspace().
- Changes of OperationStatus and CheckinStatus models.
- Added optional parameter 'timeout'.
- Fixes for undo_pending_changes().
- Fix for typos: delete_worskpace -> delete_workspace.
- Fixes for get_item_revision_history_*().
- Added a preliminary tests.

0.0.1a1 (2020-01-08)
--------------------
- First alpha release.

0.0.1a0 (2019-09-23)
--------------------
- Initial commit.
