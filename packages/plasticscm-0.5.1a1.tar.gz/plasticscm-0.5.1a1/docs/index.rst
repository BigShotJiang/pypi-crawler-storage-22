PlasticSCM documentation
========================

.. _readme:
.. include:: README.rst

Contents
========

.. toctree::
   :maxdepth: 2

   plasticscm.rst

.. toctree::
   :titlesonly:

   CHANGES.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
