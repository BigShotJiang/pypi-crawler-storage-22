==========
plasticscm
==========

In this section plasticscm module has been described with its classes.

plasticscm.Plastic
------------------

.. autoclass:: plasticscm.Plastic
   :members:
   :inherited-members:
