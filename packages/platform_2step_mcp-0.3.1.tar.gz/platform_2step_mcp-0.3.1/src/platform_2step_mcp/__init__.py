"""Platform-2Step MCP Server.

MCP server that enables AI agents to interact with AgendaPro's Platform API
safely through a human-in-the-loop confirmation system.
"""

__version__ = "0.1.0"

from .client import Platform2StepClient
from .config import Settings

__all__ = ["Platform2StepClient", "Settings", "__version__"]
