"""Category tools for MCP."""

import json
from typing import Any

from mcp.types import TextContent, Tool

from ..client import Platform2StepClient

CATEGORY_TOOLS: list[Tool] = [
    Tool(
        name="list_categories",
        description="List service categories for a company. Returns all active categories with their IDs, names, order, and service counts.",
        inputSchema={
            "type": "object",
            "properties": {
                "company_id": {
                    "type": "integer",
                    "description": "Company ID to list categories for",
                },
                "page": {
                    "type": "integer",
                    "description": "Page number (default 1)",
                },
                "per_page": {
                    "type": "integer",
                    "description": "Results per page (default 25, max 100)",
                },
            },
            "required": ["company_id"],
        },
    ),
    Tool(
        name="list_services_by_category",
        description="List all services grouped by category. Useful for building service menus or catalogs.",
        inputSchema={
            "type": "object",
            "properties": {
                "company_id": {
                    "type": "integer",
                    "description": "Company ID",
                },
                "active": {
                    "type": "boolean",
                    "description": "Filter services by active/inactive status (optional)",
                },
            },
            "required": ["company_id"],
        },
    ),
    Tool(
        name="get_category",
        description="Get details of a specific category.",
        inputSchema={
            "type": "object",
            "properties": {
                "category_id": {
                    "type": "integer",
                    "description": "Category ID",
                },
            },
            "required": ["category_id"],
        },
    ),
    Tool(
        name="create_category",
        description="""Create a request to add a new service category.

WARNING: This operation does NOT execute immediately.
Returns a confirmation_id that the user must approve in AgendaPro
before it expires (5-15 minutes).

The user will see a preview and can:
- Confirm: The category will be created
- Reject: The operation is discarded""",
        inputSchema={
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Category name",
                    "minLength": 1,
                    "maxLength": 255,
                },
                "company_id": {
                    "type": "integer",
                    "description": "Company ID to create the category in",
                },
                "order": {
                    "type": "integer",
                    "description": "Display order in the list (optional)",
                },
            },
            "required": ["name", "company_id"],
        },
    ),
    Tool(
        name="update_category",
        description="""Create a request to update an existing category.

WARNING: Requires human confirmation in AgendaPro.""",
        inputSchema={
            "type": "object",
            "properties": {
                "category_id": {
                    "type": "integer",
                    "description": "Category ID to update",
                },
                "name": {
                    "type": "string",
                    "description": "New name (optional)",
                },
                "order": {
                    "type": "integer",
                    "description": "New display order (optional)",
                },
            },
            "required": ["category_id"],
        },
    ),
    Tool(
        name="delete_category",
        description="""Create a request to delete a category.

WARNING: Requires human confirmation.
WARNING: This action is IRREVERSIBLE.""",
        inputSchema={
            "type": "object",
            "properties": {
                "category_id": {
                    "type": "integer",
                    "description": "Category ID to delete",
                },
            },
            "required": ["category_id"],
        },
    ),
]


async def handle_category_tool(
    name: str,
    arguments: dict[str, Any],
    client: Platform2StepClient,
) -> list[TextContent]:
    """Handle category tool calls.

    Args:
        name: Tool name.
        arguments: Tool arguments.
        client: Platform2Step HTTP client.

    Returns:
        List of TextContent with the result.
    """
    if name == "list_categories":
        result = await client.list_categories(
            company_id=arguments["company_id"],
            page=arguments.get("page", 1),
            per_page=arguments.get("per_page", 25),
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    elif name == "list_services_by_category":
        result = await client.list_services_by_category(
            company_id=arguments["company_id"],
            active=arguments.get("active"),
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    elif name == "get_category":
        result = await client.get_category(
            category_id=arguments["category_id"],
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    elif name == "create_category":
        result = await client.create_category(
            name=arguments["name"],
            company_id=arguments["company_id"],
            order=arguments.get("order"),
        )
        preview_json = json.dumps(result.preview, indent=2) if result.preview else "{}"
        return [
            TextContent(
                type="text",
                text=f"""Pending operation created successfully.

confirmation_id: {result.confirmation_id}
operation: {result.operation}
resource: {result.resource}
expires_at: {result.expires_at}

Preview:
{preview_json}

The user must confirm this operation before {result.expires_at}.
Confirm or reject: {result.get_confirm_url(client.bff_url)}""",
            )
        ]

    elif name == "update_category":
        result = await client.update_category(
            category_id=arguments["category_id"],
            name=arguments.get("name"),
            order=arguments.get("order"),
        )
        preview_json = json.dumps(result.preview, indent=2) if result.preview else "{}"
        return [
            TextContent(
                type="text",
                text=f"""Update request created successfully.

confirmation_id: {result.confirmation_id}
operation: {result.operation}
resource: {result.resource}
resource_id: {result.resource_id}
expires_at: {result.expires_at}

Preview of changes:
{preview_json}

The user must confirm this operation before {result.expires_at}.
Confirm or reject: {result.get_confirm_url(client.bff_url)}""",
            )
        ]

    elif name == "delete_category":
        result = await client.delete_category(
            category_id=arguments["category_id"],
        )
        return [
            TextContent(
                type="text",
                text=f"""Deletion request created successfully.

confirmation_id: {result.confirmation_id}
operation: {result.operation}
resource: {result.resource}
resource_id: {result.resource_id}
expires_at: {result.expires_at}

WARNING: This action is IRREVERSIBLE.
The user must confirm before the operation expires.
Confirm or reject: {result.get_confirm_url(client.bff_url)}""",
            )
        ]

    raise ValueError(f"Unknown category tool: {name}")
