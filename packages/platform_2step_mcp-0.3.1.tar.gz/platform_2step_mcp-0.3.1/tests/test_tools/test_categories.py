"""Tests for category tools."""

import pytest
import respx
from httpx import Response

from platform_2step_mcp.client import Platform2StepClient
from platform_2step_mcp.tools.categories import CATEGORY_TOOLS, handle_category_tool


class TestCategoryToolDefinitions:
    """Tests for category tool definitions."""

    def test_all_tools_defined(self):
        """Test that all expected tools are defined."""
        tool_names = [t.name for t in CATEGORY_TOOLS]
        assert "list_categories" in tool_names
        assert "list_services_by_category" in tool_names
        assert "get_category" in tool_names
        assert "create_category" in tool_names
        assert "update_category" in tool_names
        assert "delete_category" in tool_names

    def test_list_categories_schema(self):
        """Test list_categories input schema."""
        tool = next(t for t in CATEGORY_TOOLS if t.name == "list_categories")
        schema = tool.inputSchema

        assert schema["type"] == "object"
        assert "company_id" in schema["properties"]
        assert schema["required"] == ["company_id"]

    def test_create_category_schema(self):
        """Test create_category input schema."""
        tool = next(t for t in CATEGORY_TOOLS if t.name == "create_category")
        schema = tool.inputSchema

        assert "name" in schema["properties"]
        assert "company_id" in schema["properties"]
        assert "order" in schema["properties"]
        assert set(schema["required"]) == {"name", "company_id"}

    def test_create_category_description_includes_warning(self):
        """Test that create_category has confirmation warning."""
        tool = next(t for t in CATEGORY_TOOLS if t.name == "create_category")
        assert "WARNING" in tool.description
        assert "confirmation_id" in tool.description

    def test_delete_category_description_includes_irreversible(self):
        """Test that delete_category warns about irreversibility."""
        tool = next(t for t in CATEGORY_TOOLS if t.name == "delete_category")
        assert "IRREVERSIBLE" in tool.description


class TestListCategoriesHandler:
    """Tests for list_categories handler."""

    async def test_list_categories_returns_json(
        self,
        client: Platform2StepClient,
        mock_api: respx.MockRouter,
        sample_categories_response: dict,
    ):
        """Test that list_categories returns formatted JSON."""
        mock_api.get("/api/v1/categories").mock(
            return_value=Response(200, json=sample_categories_response)
        )

        result = await handle_category_tool(
            "list_categories", {"company_id": 1238}, client
        )

        assert len(result) == 1
        assert result[0].type == "text"
        assert "Cortes de Pelo" in result[0].text


class TestCreateCategoryHandler:
    """Tests for create_category handler."""

    async def test_create_category_returns_confirmation_info(
        self,
        client: Platform2StepClient,
        mock_api: respx.MockRouter,
        sample_pending_operation: dict,
    ):
        """Test that create_category returns confirmation details."""
        mock_api.post("/api/v1/categories").mock(
            return_value=Response(202, json=sample_pending_operation)
        )

        result = await handle_category_tool(
            "create_category",
            {"name": "Nueva Categoria", "company_id": 1238},
            client,
        )

        assert len(result) == 1
        text = result[0].text
        assert "confirmation_id:" in text
        assert "abc-123-def-456" in text
        assert "must confirm" in text.lower()


class TestDeleteCategoryHandler:
    """Tests for delete_category handler."""

    async def test_delete_category_includes_warning(
        self,
        client: Platform2StepClient,
        mock_api: respx.MockRouter,
    ):
        """Test that delete_category includes irreversibility warning."""
        response = {
            "confirmation_id": "del-123",
            "operation": "delete",
            "resource": "category",
            "resource_id": 123,
            "preview": None,
            "expires_at": "2024-01-15T10:05:00Z",
            "confirm_url": "/api/v1/confirmations/del-123",
        }
        mock_api.delete("/api/v1/categories/123").mock(
            return_value=Response(202, json=response)
        )

        result = await handle_category_tool(
            "delete_category", {"category_id": 123}, client
        )

        text = result[0].text
        assert "IRREVERSIBLE" in text
        assert "del-123" in text


class TestErrorHandling:
    """Tests for error handling in handlers."""

    async def test_unknown_tool_raises_error(
        self, client: Platform2StepClient, mock_api: respx.MockRouter
    ):
        """Test that unknown tool names raise ValueError."""
        with pytest.raises(ValueError, match="Unknown category tool"):
            await handle_category_tool("unknown_tool", {}, client)
