"""Quick test: fetch ATIF trajectory from local Chronos."""

from plato.chronos.sdk import Chronos

SESSION_ID = "72c229cb-26f1-49d2-a6ed-11499bd9379a"

chronos = Chronos(base_url="http://localhost:8001")
traj = chronos.get_trajectory(SESSION_ID)

print(f"Session: {traj.session_id}")
print(f"Status: {traj.status}")
agent_names = [a.agent.name for a in (traj.agents or [])]
print(f"Agents: {agent_names}")
print()

# World info
w = traj.world
if w:
    print(f"World: {w.name} (v{w.version})")
    if w.config:
        print(f"Config: {w.config}")
    if w.observation:
        print(f"Reset observation: {str(w.observation)[:200]}")
    steps = w.steps or []
    print(f"World steps: {len(steps)}")
    print()

    for ws in steps:
        duration = ""
        if ws.start_time_unix_nano and ws.end_time_unix_nano:
            ms = (ws.end_time_unix_nano - ws.start_time_unix_nano) / 1_000_000
            duration = f" ({ms:.0f}ms)"
        print(f"  Step {ws.number} [done={ws.done}]{duration}")
        if ws.observation:
            print(f"    Observation: {str(ws.observation)[:200]}")
        if ws.agents:
            for a in ws.agents:
                steps_count = len(a.trajectory.steps) if a.trajectory.steps else 0
                print(f"    Agent: {a.agent.name} ({steps_count} steps)")
        print()

# Agent details
for agent_trace in traj.agents or []:
    a = agent_trace.agent
    print(f"--- Agent: {a.name} (v{a.version}) model={a.model_name} ---")
    print(f"    Config: {a.config[:200] if a.config else None}")
    print(f"    Sandbox: {a.sandbox}")
    print(f"    Success: {a.success}")
    print(f"    Result: {a.result[:200] if a.result else None}")
    print(f"    Error: {a.error}")
    steps = agent_trace.trajectory.steps or []
    print(f"    Steps: {len(steps)}")
    print()

    for step in steps:
        src_tag = f"[{step.source}]"
        msg = step.message[:120] if step.message else ""
        print(f"  Step {step.step_id} {src_tag} {msg}")
        if step.tool_calls and isinstance(step.tool_calls, list):
            for tc in step.tool_calls:
                print(f"    -> {tc.function_name}({tc.arguments})")
        if step.observation and not isinstance(step.observation, str) and step.observation.results:
            for r in step.observation.results:
                print(f"    <- {r.content[:120]}")
        if step.screenshot:
            print(f"    [screenshot: {step.screenshot_format}, {len(step.screenshot)} chars]")
        if step.metrics:
            m = step.metrics
            parts = []
            if m.prompt_tokens is not None or m.completion_tokens is not None:
                parts.append(f"tokens: {m.prompt_tokens or 0}/{m.completion_tokens or 0}")
            if m.cost_usd is not None:
                parts.append(f"cost: ${m.cost_usd:.4f}")
            if parts:
                print(f"    {', '.join(parts)}")

    print()
    fm = agent_trace.trajectory.final_metrics
    if fm:
        total_tokens = (fm.prompt_tokens or 0) + (fm.completion_tokens or 0)
        print(f"  Total: {fm.total_steps} steps, {total_tokens} tokens, ${fm.cost_usd:.4f}")
    print()

# Artifacts
artifacts = traj.artifacts or []
if artifacts:
    print(f"Artifacts: {len(artifacts)}")
    for art in artifacts:
        print(f"  [{art.kind}] {art.url}")
    print()

chronos.close()
