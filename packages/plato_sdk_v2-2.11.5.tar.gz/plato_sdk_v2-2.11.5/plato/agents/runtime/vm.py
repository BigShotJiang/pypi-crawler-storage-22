"""VM runtime for agent execution in Firecracker VMs."""

from __future__ import annotations

import asyncio
import logging
import os
import uuid
from pathlib import Path
from typing import TYPE_CHECKING

from opentelemetry import trace
from pydantic import BaseModel

from plato.agents.runtime.base import AgentContext, OTelContext, PreparedAgent, Runtime
from plato.v2 import Env
from plato.v2.types import SimConfigCompute

if TYPE_CHECKING:
    from plato.v2.async_.environment import Environment
    from plato.v2.async_.session import Session

logger = logging.getLogger(__name__)


class VMConfig(BaseModel):
    """Configuration for agent VMs."""

    cpus: int = 1
    memory: int = 2048
    disk: int = 10240


class PlatoVMRuntime(Runtime):
    """Run agents in Firecracker VMs.

    Supports two modes:
    - Dev mode (dev_mode=True): Syncs SDK and agent code from world VM to agent VMs
      for hot-reload development
    - Non-dev mode (dev_mode=False): Uses code from Docker image, only syncs workspace

    Agent code syncing flow (dev mode only):
    1. Dev runner syncs code from local machine → world VM at /agents/<name>/
    2. World calls run_agent() with agent_code_path=/agents/<name>/ and dev_mode=True
    3. PlatoVMRuntime creates agent VM and syncs /agents/<name>/ → /app on agent VM
    4. Agent runs with the synced code
    """

    def __init__(
        self,
        session: Session,
        ssh_key_path: Path | None = None,
        vm_config: VMConfig | None = None,
    ):
        """Initialize VM runtime.

        Args:
            session: Plato session for creating VMs
            ssh_key_path: Path to SSH private key for rsync (optional, only needed for dev mode)
            vm_config: VM resource configuration
        """
        self.session = session
        self.ssh_key_path = ssh_key_path
        self.vm_config = vm_config or VMConfig()
        self._agent_envs: dict[str, Environment] = {}

    async def run(self, ctx: AgentContext) -> str:
        """Run an agent in a Firecracker VM."""
        agent_alias = f"agent-{uuid.uuid4().hex[:8]}"

        # Create agent VM
        agent_env = await self._create_vm(ctx.image, agent_alias)
        self._agent_envs[agent_alias] = agent_env

        try:
            # Setup network
            await self._setup_network()
            await self._log_hosts(agent_env.internal_hostname)

            # Sync code and workspace
            await self._sync_code(ctx, agent_env)

            # Run the agent
            await self._execute_agent(ctx, agent_env)

            # Sync workspace back to world VM
            await self._sync_workspace_back(ctx, agent_env)

            return agent_env.job_id

        except Exception:
            await self.cleanup(agent_alias)
            raise

    async def prepare(self, ctx: AgentContext) -> PreparedAgent:
        """Start agent VM with desktop/Chrome but without running the task.

        Creates the VM, sets up networking and SSH, syncs code/workspace,
        but does NOT execute the agent command.
        """
        agent_alias = f"agent-{uuid.uuid4().hex[:8]}"

        agent_env = await self._create_vm(ctx.image, agent_alias)
        self._agent_envs[agent_alias] = agent_env

        try:
            await self._setup_network()
            await self._log_hosts(agent_env.internal_hostname)
            await self._sync_code(ctx, agent_env)
        except Exception:
            await self.cleanup(agent_alias)
            raise

        return PreparedAgent(
            agent_id=agent_alias,
            hostname=agent_env.internal_hostname,
            runtime=self,
        )

    async def execute(self, prepared: PreparedAgent, ctx: AgentContext) -> None:
        """Execute agent task in a prepared VM via SSH."""
        agent_env = self._agent_envs.get(prepared.agent_id)
        if not agent_env:
            raise RuntimeError(f"No VM found for agent {prepared.agent_id}")

        await self._execute_agent(ctx, agent_env)

        # Sync workspace back after execution
        await self._sync_workspace_back(ctx, agent_env)

    async def cleanup(self, agent_id: str) -> None:
        """Clean up an agent VM."""
        # agent_id could be job_id or alias, check both
        agent_env = self._agent_envs.pop(agent_id, None)
        if not agent_env:
            # Try to find by job_id
            for alias, env in list(self._agent_envs.items()):
                if env.job_id == agent_id:
                    agent_env = self._agent_envs.pop(alias)
                    break

        if agent_env:
            try:
                logger.info(f"Cleaning up agent VM: {agent_env.job_id}")
                await self.session.remove_env(agent_env)
            except Exception as e:
                logger.warning(f"Failed to clean up agent VM: {e}")

    async def _create_vm(self, image: str, alias: str) -> Environment:
        """Create an agent VM."""
        logger.info(
            f"Creating agent VM: {alias} (image: {image}, cpus={self.vm_config.cpus}, mem={self.vm_config.memory}MB)"
        )
        logger.info("  This may take a moment if the image needs to be pulled...")

        agent_env = await self.session.add_env(
            Env.resource(
                simulator=alias,
                sim_config=SimConfigCompute(
                    cpus=self.vm_config.cpus,
                    memory=self.vm_config.memory,
                    disk=self.vm_config.disk,
                ),
                alias=alias,
                docker_image_url=image,
                upload_rootfs=False,
                rootfs_storage_backend="snapshot-store",
            ),
            timeout=600,
        )

        logger.debug(f"Agent VM ready: {agent_env.job_id}")
        return agent_env

    async def _log_hosts(self, target_hostname: str) -> None:
        """Log /etc/hosts for debugging DNS resolution."""
        try:
            logger.info(f"Resolving {target_hostname}, /etc/hosts:\n{Path('/etc/hosts').read_text()}")
        except Exception as e:
            logger.warning(f"Failed to read /etc/hosts: {e}")

    async def _setup_network(self) -> None:
        """Setup network connectivity to agent VM."""
        await self.session.connect_network()

        # If no SSH key provided, generate one for workspace sync
        if not self.ssh_key_path:
            logger.debug("Generating SSH key for agent VM access...")
            self.ssh_key_path = await self._generate_ssh_key()

        # Add public key to session for SSH access to agent VMs
        pub_key = Path(str(self.ssh_key_path) + ".pub").read_text().strip()
        await self.session.add_ssh_key(pub_key)
        logger.debug("SSH key added to session")

    async def _generate_ssh_key(self) -> Path:
        """Generate an SSH key pair for agent VM access."""
        import subprocess

        key_path = Path("/tmp/agent_ssh_key")
        if key_path.exists():
            key_path.unlink()
        if key_path.with_suffix(".pub").exists():
            key_path.with_suffix(".pub").unlink()

        # Generate key pair
        proc = subprocess.run(
            ["ssh-keygen", "-t", "ed25519", "-f", str(key_path), "-N", "", "-q"],
            capture_output=True,
        )
        if proc.returncode != 0:
            raise RuntimeError(f"Failed to generate SSH key: {proc.stderr.decode()}")

        # Ensure correct permissions
        key_path.chmod(0o600)

        return key_path

    def _parse_image_url(self, image: str) -> tuple[str, str]:
        """Extract package name and version from image URL.

        Format: .../plato-agents/claude-code:0.0.0.dev9
        Returns: (package_name, version)
        """
        # Get the last part: claude-code:0.0.0.dev9
        last_part = image.split("/")[-1]
        if ":" in last_part:
            name, version = last_part.rsplit(":", 1)
            return name, version
        return last_part, "latest"

    async def _sync_code(self, ctx: AgentContext, agent_env: Environment) -> None:
        """Sync workspace and install agent code on VM.

        Dev mode is detected by presence of /sdk on world VM (set up by DevRunner).
        In dev mode: syncs SDK and agent code for hot-reload development.
        In non-dev mode: installs agent package from PyPI.
        """
        hostname = agent_env.internal_hostname

        # Always sync workspace
        if ctx.workspace:
            workspace_path = Path(ctx.workspace)
            if workspace_path.exists():
                logger.debug(f"Syncing workspace: {workspace_path} -> /workspace")
                await self._rsync_to(workspace_path, "/workspace", hostname, chown="superman:superman")

        # Dev mode is detected by /sdk existing (DevRunner syncs it to world VM)
        sdk_path = Path("/sdk")
        is_dev_mode = sdk_path.exists()

        if is_dev_mode:
            # Dev mode: sync SDK and agent code, then install together
            # Installing together lets uv resolve the editable SDK as satisfying
            # the agent's pinned plato-sdk-v2 dependency.
            editable_paths: list[str] = []

            logger.debug(f"Syncing SDK: {sdk_path} -> /sdk")
            await self._rsync_to(sdk_path, "/sdk", hostname, chown="superman:superman")
            editable_paths.append("/sdk")

            # Auto-detect agent code: DevRunner syncs it to /agents/<name>/
            agent_code_path = ctx.agent_code_path
            if not agent_code_path:
                agents_dir = Path("/agents")
                if agents_dir.exists():
                    agent_dirs = [d for d in agents_dir.iterdir() if d.is_dir() and (d / "pyproject.toml").exists()]
                    if agent_dirs:
                        agent_code_path = agent_dirs[0]

            if agent_code_path and agent_code_path.exists():
                logger.debug(f"Syncing agent code: {agent_code_path} -> /app")
                await self._rsync_to(agent_code_path, "/app", hostname, chown="superman:superman")
                editable_paths.append("/app")

            editables = " ".join(f"-e {p}" for p in editable_paths)
            logger.debug(f"Installing packages in editable mode: {editable_paths}")
            exit_code, stdout, stderr = await self._run_ssh(
                hostname, f"uv pip install --system {editables}", timeout=300
            )
            if exit_code != 0:
                raise RuntimeError(f"Failed to install packages: {stderr or stdout}")
        else:
            # Production mode: install agent package from PyPI
            package_name, version = self._parse_image_url(ctx.image)
            logger.debug(f"Installing agent package: {package_name}=={version}")

            # Fix uv cache/tools ownership (may have been created by root)
            await self._run_ssh(
                hostname,
                "rm -rf /home/superman/.cache/uv /home/superman/.local/share/uv && "
                "mkdir -p /home/superman/.cache/uv /home/superman/.local/share/uv /home/superman/.local/bin && "
                "chown -R superman:superman /home/superman/.cache /home/superman/.local",
                timeout=30,
            )

            api_key = os.environ.get("PLATO_API_KEY", "")
            pypi_url = f"https://__token__:{api_key}@plato.so/api/v2/pypi/agents/simple/"

            install_cmd = (
                f"uv tool install plato-sdk-v2 --python 3.12 "
                f"--with '{package_name}=={version}' "
                f"--index-url 'https://pypi.org/simple/' "
                f"--extra-index-url '{pypi_url}' "
                f"--index-strategy unsafe-best-match --prerelease allow --refresh --force"
            )
            exit_code, stdout, stderr = await self._run_ssh(hostname, install_cmd, user="superman", timeout=300)
            if exit_code != 0:
                raise RuntimeError(f"Failed to install agent package: {stderr or stdout}")

    async def _execute_agent(self, ctx: AgentContext, agent_env: Environment) -> None:
        """Execute the agent on the VM."""
        # Build environment variables
        env_vars = [
            "HOME=/home/superman",
            "USER=superman",
            "NVM_DIR=/home/superman/.nvm",
            "PATH=/home/superman/.local/bin:/usr/local/bin:/usr/bin:/bin",
            f"AGENT_CONFIG_B64={ctx.config_b64}",
        ]
        if ctx.runtime_b64:
            env_vars.append(f"AGENT_RUNTIME_B64={ctx.runtime_b64}")

        # Add OTel context
        otel = OTelContext.from_env()
        env_vars.extend(otel.to_env_vars())

        logger.info(f"Agent config keys: {list(ctx.config.keys())}")
        logger.info(f"OTEL URL: {otel.otel_url}")

        # Build command
        env_exports = " ".join(f'export {k}="{v}";' for var in env_vars for k, v in [var.split("=", 1)])
        agent_cmd = f'{env_exports} cd /workspace && plato-agent-runner run --instruction-b64 "{ctx.instruction_b64}"'

        # Execute via SSH as superman user (with streaming output)
        logger.info("Executing agent command on VM via SSH as 'superman' user...")
        exit_code = await self._run_ssh_streaming(
            hostname=agent_env.internal_hostname,
            command=agent_cmd,
            user="superman",
        )

        logger.info(f"Agent command completed with exit code: {exit_code}")

        if exit_code != 0:
            raise RuntimeError(f"Agent failed with exit code {exit_code}")

    async def _rsync_to(self, local_path: Path, remote_path: str, hostname: str, chown: str | None = None) -> None:
        """Rsync a directory to the agent VM.

        Args:
            local_path: Local directory to sync
            remote_path: Remote directory on VM
            hostname: VM hostname
            chown: Optional user:group to set ownership (e.g., "superman:superman")
        """
        ssh_cmd = (
            f"ssh -i {self.ssh_key_path} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR"
        )

        cmd = [
            "rsync",
            "-az",
            "--delete",
            "--rsync-path",
            f"mkdir -p {remote_path} && rsync",
            "-e",
            ssh_cmd,
        ]

        if chown:
            cmd.extend(["--chown", chown])

        cmd.extend(
            [
                f"{local_path}/",
                f"root@{hostname}:{remote_path}/",
            ]
        )

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()

        if proc.returncode != 0:
            error_msg = stderr.decode()
            if "Could not resolve hostname" in error_msg:
                # Log /etc/hosts for debugging DNS resolution failures
                await self._log_hosts(hostname)
            raise RuntimeError(f"rsync to VM failed: {error_msg}")

    async def _rsync_from(self, remote_path: str, local_path: Path, hostname: str) -> None:
        """Rsync a directory from the agent VM back to local."""
        ssh_cmd = (
            f"ssh -i {self.ssh_key_path} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR"
        )

        # Ensure local directory exists
        local_path.mkdir(parents=True, exist_ok=True)

        cmd = [
            "rsync",
            "-az",
            "-e",
            ssh_cmd,
            f"root@{hostname}:{remote_path}/",
            f"{local_path}/",
        ]

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()

        if proc.returncode != 0:
            raise RuntimeError(f"rsync from VM failed: {stderr.decode()}")

    async def _sync_workspace_back(self, ctx: AgentContext, agent_env: Environment) -> None:
        """Sync workspace back from agent VM to world VM after agent completes."""
        if not ctx.workspace:
            return

        workspace_path = Path(ctx.workspace)
        hostname = agent_env.internal_hostname

        logger.debug(f"Syncing workspace back: /workspace -> {workspace_path}")
        await self._rsync_from("/workspace", workspace_path, hostname)

    async def _run_ssh(
        self,
        hostname: str,
        command: str,
        user: str = "root",
        timeout: int = 300,
    ) -> tuple[int, str, str]:
        """Run a command via SSH and return exit code, stdout, stderr."""
        if user != "root":
            escaped_cmd = command.replace("\\", "\\\\").replace('"', '\\"')
            command = f'su - {user} -c "{escaped_cmd}"'

        ssh_cmd = [
            "ssh",
            "-i",
            str(self.ssh_key_path),
            "-o",
            "StrictHostKeyChecking=no",
            "-o",
            "UserKnownHostsFile=/dev/null",
            "-o",
            "LogLevel=ERROR",
            f"root@{hostname}",
            command,
        ]

        logger.debug(f"SSH running command as {user}: {command[:200]}...")

        process = await asyncio.create_subprocess_exec(
            *ssh_cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        try:
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            process.kill()
            raise RuntimeError(f"SSH command timed out after {timeout}s")

        exit_code = process.returncode or 0
        stdout_str = stdout.decode("utf-8", errors="replace")
        stderr_str = stderr.decode("utf-8", errors="replace")

        if exit_code != 0:
            logger.warning(f"SSH command failed: exit_code={exit_code}")
            if stdout_str:
                logger.warning(f"SSH stdout: {stdout_str[:500]}")
            if stderr_str:
                logger.warning(f"SSH stderr: {stderr_str[:500]}")
        else:
            logger.debug(f"SSH command finished: exit_code={exit_code}")

        return exit_code, stdout_str, stderr_str

    async def _run_ssh_streaming(
        self,
        hostname: str,
        command: str,
        user: str = "root",
    ) -> int:
        """Run a command via SSH with real-time output streaming."""
        if user != "root":
            escaped_cmd = command.replace("\\", "\\\\").replace('"', '\\"')
            command = f'su - {user} -c "{escaped_cmd}"'

        ssh_cmd = [
            "ssh",
            "-i",
            str(self.ssh_key_path),
            "-o",
            "StrictHostKeyChecking=no",
            "-o",
            "UserKnownHostsFile=/dev/null",
            "-o",
            "LogLevel=ERROR",
            f"root@{hostname}",
            command,
        ]

        logger.debug(f"SSH running command as {user}: {command[:200]}...")

        process = await asyncio.create_subprocess_exec(
            *ssh_cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )

        tracer = trace.get_tracer(__name__)
        output_lines: list[str] = []
        stdout = process.stdout
        if stdout:
            with tracer.start_as_current_span("agent.execution.output") as span:
                span.set_attribute("agent.user", user)
                span.set_attribute("agent.hostname", hostname)
                while True:
                    line = await stdout.readline()
                    if not line:
                        break
                    output_lines.append(line.decode("utf-8", errors="replace").rstrip())
                span.set_attribute("agent.lines_read", len(output_lines))

        await process.wait()

        # Log agent output as a single block
        if output_lines:
            output_block = "\n".join(output_lines)
            logger.info(f"Agent output ({len(output_lines)} lines):\n{output_block}")

        logger.info(f"Agent command finished: exit_code={process.returncode}")
        return process.returncode or 0
