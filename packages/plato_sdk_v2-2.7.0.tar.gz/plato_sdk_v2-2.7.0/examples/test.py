"""Simple example of creating two VMs from resources with a network.

This script demonstrates:
1. Creating a Plato session with two VMs from resources
2. Waiting for VMs to be ready (worker allocation)
3. Connecting VMs to WireGuard network via connect_network endpoint
4. Testing VM-to-VM TCP connectivity with Redis over WireGuard

Run with: python test.py
Requires: PLATO_API_KEY environment variable
"""

import logging
import os
import time

from dotenv import load_dotenv

from plato.v2 import Env, Plato
from plato.v2.types import SimConfigCompute

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


def main():
    # Check for API key
    if not os.environ.get("PLATO_API_KEY"):
        logger.error("PLATO_API_KEY environment variable not set")
        return

    plato = Plato()
    session = None

    try:
        logger.info("=" * 60)
        logger.info("WIREGUARD NETWORK TCP (REDIS) CONNECTIVITY TEST")
        logger.info("=" * 60)

        # 1. Define resource configurations for the VMs
        vm1_config = SimConfigCompute(cpus=2, memory=4096, disk=10000)
        vm2_config = SimConfigCompute(cpus=2, memory=4096, disk=10000)

        # 2. Create session with two VMs from resources
        logger.info("[1/8] Creating session with two VMs...")
        session = plato.sessions.create(
            envs=[
                Env.resource("vm1", sim_config=vm1_config, alias="vm1"),
                Env.resource("vm2", sim_config=vm2_config, alias="vm2"),
            ],
            timeout=600,
        )

        logger.info(f"Session created: {session.session_id}")
        logger.info(f"Environments: {len(session.envs)}")

        # Get env references
        vm1 = session.envs[0] if session.envs[0].alias == "vm1" else session.envs[1]
        vm2 = session.envs[1] if session.envs[0].alias == "vm1" else session.envs[0]

        for env in session.envs:
            logger.info(f"  - {env.alias}: job_id={env.job_id}")

        # 3. Connect VMs to WireGuard network
        logger.info("[2/8] Connecting VMs to WireGuard network...")

        connect_result = session.connect_network()
        logger.info(f"  Network connected: success={connect_result.get('success')}")
        logger.info(f"  Subnet: {connect_result.get('subnet')}")
        for job_id, success in connect_result.get("results", {}).items():
            logger.info(f"    {job_id}: {'OK' if success else 'FAILED'}")

        # 4. Get WireGuard IPs
        logger.info("[3/8] Getting WireGuard IPs...")

        vm1_wg_ip = vm1.execute("ip -4 addr show wg0 | grep inet | awk '{print $2}' | cut -d/ -f1").stdout.strip()
        vm2_wg_ip = vm2.execute("ip -4 addr show wg0 | grep inet | awk '{print $2}' | cut -d/ -f1").stdout.strip()

        logger.info(f"  vm1 WireGuard IP: {vm1_wg_ip}")
        logger.info(f"  vm2 WireGuard IP: {vm2_wg_ip}")

        # 5. Install Redis on both VMs
        logger.info("[4/8] Installing Redis on VMs...")

        # Install Redis on vm1
        logger.info("  Installing Redis on vm1...")
        vm1.execute("apt-get update -qq && apt-get install -y -qq redis-server", timeout=120)

        # Install Redis on vm2
        logger.info("  Installing Redis on vm2...")
        vm2.execute("apt-get update -qq && apt-get install -y -qq redis-server", timeout=120)

        # 6. Configure and start Redis servers
        logger.info("[5/8] Configuring and starting Redis servers...")

        # Configure Redis on vm1 to bind to all interfaces
        vm1.execute("sed -i 's/^bind 127.0.0.1/bind 0.0.0.0/' /etc/redis/redis.conf")
        vm1.execute("sed -i 's/^protected-mode yes/protected-mode no/' /etc/redis/redis.conf")
        vm1.execute("systemctl restart redis-server")
        logger.info("  Redis started on vm1 (port 6379)")

        # Configure Redis on vm2 to bind to all interfaces
        vm2.execute("sed -i 's/^bind 127.0.0.1/bind 0.0.0.0/' /etc/redis/redis.conf")
        vm2.execute("sed -i 's/^protected-mode yes/protected-mode no/' /etc/redis/redis.conf")
        vm2.execute("systemctl restart redis-server")
        logger.info("  Redis started on vm2 (port 6379)")

        # Give Redis time to start
        time.sleep(2)

        # Verify Redis is running locally
        vm1_redis_check = vm1.execute("redis-cli ping")
        vm2_redis_check = vm2.execute("redis-cli ping")

        if "PONG" in vm1_redis_check.stdout:
            logger.info("  OK: vm1 Redis responding locally")
        else:
            logger.error(f"  FAIL: vm1 Redis not responding: {vm1_redis_check.stdout}")
            return

        if "PONG" in vm2_redis_check.stdout:
            logger.info("  OK: vm2 Redis responding locally")
        else:
            logger.error(f"  FAIL: vm2 Redis not responding: {vm2_redis_check.stdout}")
            return

        # 7. Set keys on each Redis
        logger.info("[6/8] Setting Redis keys...")

        vm1.execute("redis-cli SET hostname vm1")
        vm1.execute("redis-cli SET message 'Hello from VM1'")
        logger.info("  Set keys on vm1: hostname=vm1, message='Hello from VM1'")

        vm2.execute("redis-cli SET hostname vm2")
        vm2.execute("redis-cli SET message 'Hello from VM2'")
        logger.info("  Set keys on vm2: hostname=vm2, message='Hello from VM2'")

        # 8. Test TCP connectivity - connect to remote Redis over WireGuard
        logger.info("[7/8] Testing TCP connectivity (Redis over WireGuard)...")

        # Test vm1 -> vm2's Redis
        logger.info(f"  Testing TCP from vm1 to vm2 Redis ({vm2_wg_ip}:6379)...")

        vm1_to_vm2_ping = vm1.execute(f"redis-cli -h {vm2_wg_ip} ping")
        vm1_to_vm2_hostname = vm1.execute(f"redis-cli -h {vm2_wg_ip} GET hostname")
        vm1_to_vm2_message = vm1.execute(f"redis-cli -h {vm2_wg_ip} GET message")

        if "PONG" in vm1_to_vm2_ping.stdout:
            logger.info("  OK: vm1 -> vm2 Redis PING successful")
        else:
            logger.error(f"  FAIL: vm1 -> vm2 Redis PING failed: {vm1_to_vm2_ping.stdout} {vm1_to_vm2_ping.stderr}")

        if "vm2" in vm1_to_vm2_hostname.stdout:
            logger.info(f"  OK: vm1 -> vm2 Redis GET hostname = {vm1_to_vm2_hostname.stdout.strip()}")
        else:
            logger.error(f"  FAIL: vm1 -> vm2 Redis GET hostname failed: {vm1_to_vm2_hostname.stdout}")

        if "Hello from VM2" in vm1_to_vm2_message.stdout:
            logger.info(f"  OK: vm1 -> vm2 Redis GET message = {vm1_to_vm2_message.stdout.strip()}")
        else:
            logger.error(f"  FAIL: vm1 -> vm2 Redis GET message failed: {vm1_to_vm2_message.stdout}")

        # Test vm2 -> vm1's Redis
        logger.info(f"  Testing TCP from vm2 to vm1 Redis ({vm1_wg_ip}:6379)...")

        vm2_to_vm1_ping = vm2.execute(f"redis-cli -h {vm1_wg_ip} ping")
        vm2_to_vm1_hostname = vm2.execute(f"redis-cli -h {vm1_wg_ip} GET hostname")
        vm2_to_vm1_message = vm2.execute(f"redis-cli -h {vm1_wg_ip} GET message")

        if "PONG" in vm2_to_vm1_ping.stdout:
            logger.info("  OK: vm2 -> vm1 Redis PING successful")
        else:
            logger.error(f"  FAIL: vm2 -> vm1 Redis PING failed: {vm2_to_vm1_ping.stdout} {vm2_to_vm1_ping.stderr}")

        if "vm1" in vm2_to_vm1_hostname.stdout:
            logger.info(f"  OK: vm2 -> vm1 Redis GET hostname = {vm2_to_vm1_hostname.stdout.strip()}")
        else:
            logger.error(f"  FAIL: vm2 -> vm1 Redis GET hostname failed: {vm2_to_vm1_hostname.stdout}")

        if "Hello from VM1" in vm2_to_vm1_message.stdout:
            logger.info(f"  OK: vm2 -> vm1 Redis GET message = {vm2_to_vm1_message.stdout.strip()}")
        else:
            logger.error(f"  FAIL: vm2 -> vm1 Redis GET message failed: {vm2_to_vm1_message.stdout}")

        # 9. Test ping connectivity as sanity check
        logger.info("[8/8] Testing ping connectivity...")

        ping_result = vm1.execute(f"ping -c 3 -W 5 {vm2_wg_ip}")
        if ping_result.exit_code == 0:
            logger.info("  OK: vm1 -> vm2 ping successful!")
        else:
            logger.error("  FAIL: vm1 -> vm2 ping failed!")

        # Summary
        logger.info("")
        logger.info("=" * 60)
        logger.info("TEST SUMMARY")
        logger.info("=" * 60)
        logger.info(f"Session ID: {session.session_id}")
        logger.info(f"vm1 WireGuard IP: {vm1_wg_ip}")
        logger.info(f"vm2 WireGuard IP: {vm2_wg_ip}")

        # Final connectivity check
        tcp_ok = (
            "PONG" in vm1_to_vm2_ping.stdout
            and "vm2" in vm1_to_vm2_hostname.stdout
            and "PONG" in vm2_to_vm1_ping.stdout
            and "vm1" in vm2_to_vm1_hostname.stdout
        )

        if tcp_ok:
            logger.info("RESULT: WireGuard TCP (Redis) connectivity WORKING!")
        else:
            logger.error("RESULT: WireGuard TCP (Redis) connectivity FAILED!")

        logger.info("=" * 60)

    except Exception as e:
        logger.error(f"ERROR: {e}")
        import traceback

        traceback.print_exc()
        raise

    finally:
        if session:
            logger.info("Closing session...")
            session.close()
        plato.close()
        logger.info("Cleanup complete.")


if __name__ == "__main__":
    main()
