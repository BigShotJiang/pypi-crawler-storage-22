#!/usr/bin/env python3
"""Test SSH via WireGuard proxy gateway.

Creates a blank VM, connects it to the WireGuard network, and tests SSH access
through the proxy gateway.

Usage:
    export PLATO_API_KEY=your-key
    export PLATO_PROXY_HOST=gateway.plato.so
    export PLATO_PROXY_PORT=443
    python test_proxy_ssh.py
"""

import logging
import os
import subprocess
import sys
import time

from dotenv import load_dotenv

from plato.v2 import Env, Plato
from plato.v2.types import SimConfigCompute

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


def test_ssh_connection(job_id: str, proxy_host: str, proxy_port: int) -> bool:
    """Test SSH connection via proxy gateway."""
    sni = f"{job_id}--22.{proxy_host}"

    # Use openssl s_client to test TLS connection
    cmd = ["openssl", "s_client", "-connect", f"{proxy_host}:{proxy_port}", "-servername", sni, "-verify_quiet"]

    logger.info(f"Testing TLS connection to {proxy_host}:{proxy_port} with SNI={sni}")

    try:
        result = subprocess.run(cmd, input=b"", capture_output=True, timeout=10)
        if b"CONNECTED" in result.stderr or result.returncode == 0:
            logger.info("TLS connection successful!")
            return True
        else:
            logger.error(f"TLS connection failed: {result.stderr.decode()[:200]}")
            return False
    except subprocess.TimeoutExpired:
        logger.error("TLS connection timed out")
        return False
    except Exception as e:
        logger.error(f"TLS connection error: {e}")
        return False


def main():
    # Check environment
    api_key = os.environ.get("PLATO_API_KEY")
    if not api_key:
        logger.error("PLATO_API_KEY not set")
        return 1

    proxy_host = os.environ.get("PLATO_PROXY_HOST", "gateway.plato.so")
    proxy_port = int(os.environ.get("PLATO_PROXY_PORT", "443"))

    logger.info("=" * 60)
    logger.info("WIREGUARD PROXY SSH TEST")
    logger.info("=" * 60)
    logger.info(f"Proxy: {proxy_host}:{proxy_port}")

    plato = Plato()
    session = None

    try:
        # 1. Create blank VM
        logger.info("[1/4] Creating blank VM...")
        vm_config = SimConfigCompute(cpus=2, memory=2048, disk=10000)

        session = plato.sessions.create(
            envs=[Env.resource("test-vm", sim_config=vm_config, alias="test-vm")],
            timeout=600,
        )

        job_id = session.envs[0].job_id
        logger.info(f"  Session: {session.session_id}")
        logger.info(f"  Job ID:  {job_id}")

        # 2. Connect to WireGuard network
        logger.info("[2/4] Connecting to WireGuard network...")
        result = session.connect_network()

        success = result.get("success", False)
        subnet = result.get("subnet", "unknown")

        logger.info(f"  Success: {success}")
        logger.info(f"  Subnet:  {subnet}")

        if not success:
            logger.error("Failed to connect network!")
            return 1

        # 3. Get WireGuard IP from VM
        logger.info("[3/4] Getting VM WireGuard IP...")
        vm = session.envs[0]
        wg_ip = vm.execute("ip -4 addr show wg0 | grep inet | awk '{print $2}' | cut -d/ -f1").stdout.strip()
        logger.info(f"  VM WireGuard IP: {wg_ip}")

        # 4. Test SSH via proxy
        logger.info("[4/4] Testing SSH via proxy gateway...")
        ssh_ok = test_ssh_connection(job_id, proxy_host, proxy_port)

        # Summary
        logger.info("")
        logger.info("=" * 60)
        logger.info("RESULTS")
        logger.info("=" * 60)
        logger.info(f"Job ID:       {job_id}")
        logger.info(f"WireGuard IP: {wg_ip}")
        logger.info(f"SSH Test:     {'PASS' if ssh_ok else 'FAIL'}")
        logger.info("")
        logger.info("To SSH manually:")
        logger.info(f"  export PLATO_PROXY_HOST={proxy_host}")
        logger.info(f"  export PLATO_PROXY_PORT={proxy_port}")
        logger.info(f"  plato ssh {job_id} --no-verify")
        logger.info("")
        logger.info("Session alive for 600 seconds. Press Ctrl+C to exit early.")
        logger.info("=" * 60)

        # Keep alive for manual testing
        try:
            time.sleep(600)
        except KeyboardInterrupt:
            logger.info("\nInterrupted")

        return 0 if ssh_ok else 1

    except Exception as e:
        logger.error(f"Error: {e}")
        import traceback

        traceback.print_exc()
        return 1

    finally:
        if session:
            logger.info("Closing session...")
            session.close()
        plato.close()


if __name__ == "__main__":
    sys.exit(main())
