"""API endpoints."""

from . import get_status_api_status_get, get_version_info_api_version_get

__all__ = [
    "get_status_api_status_get",
    "get_version_info_api_version_get",
]
