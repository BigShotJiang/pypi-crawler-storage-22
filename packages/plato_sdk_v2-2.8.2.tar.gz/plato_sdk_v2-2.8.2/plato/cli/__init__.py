"""Plato CLI package."""

from plato.cli.main import app, cli, main

__all__ = ["app", "main", "cli"]
