#!/usr/bin/env python3
"""Start a preview local development environment.

This example:
1. Starts a blank VM with sufficient resources
2. Clones the plato repo via SSH with a deploy key
3. Checks out the preview-deployments branch
4. Starts docker-compose with the preview config
5. Waits for user input before closing

Usage:
    export PLATO_API_KEY=your-key
    python preview_local_dev.py
"""

import logging
import os
import sys
import time

from dotenv import load_dotenv

from plato.v2 import Env, Plato
from plato.v2.types import SimConfigCompute

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# GitHub repo to clone
GITHUB_REPO = "git@github.com:useplato/plato.git"
GITHUB_BRANCH = "preview-deployments"

# SSH deploy key for cloning useplato/plato (ed25519)
SSH_PRIVATE_KEY = """-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW
QyNTUxOQAAACCzSn8opb8nWXEZ8yEv3WQG8P+vVbZGwgEDjhbmSSqIsgAAAJhF9JNKRfST
SgAAAAtzc2gtZWQyNTUxOQAAACCzSn8opb8nWXEZ8yEv3WQG8P+vVbZGwgEDjhbmSSqIsg
AAAEC5AlVUuWLCtviqAI8iI+8A4LTeDiNgjL6zlGk6NJp16bNKfyilvydZcRnzIS/dZAbw
/69VtkbCAQOOFuZJKoiyAAAAD3BsYXRvLXZtLWRlcGxveQECAwQFBg==
-----END OPENSSH PRIVATE KEY-----"""


def execute_and_log(session, command: str, description: str, timeout: int = 60) -> bool:
    """Execute a command and log the result. Returns True on success."""
    logger.info(f"{description}...")
    result = session.execute(command, timeout=timeout)
    for job_id, res in result.results.items():
        if res.exit_code != 0:
            logger.error(f"  Failed (exit {res.exit_code}): {res.stderr[:500] if res.stderr else 'no stderr'}")
            return False
        if res.stdout and len(res.stdout.strip()) > 0:
            # Show first few lines of output
            lines = res.stdout.strip().split("\n")
            if len(lines) <= 5:
                for line in lines:
                    logger.info(f"  {line}")
            else:
                for line in lines[:3]:
                    logger.info(f"  {line}")
                logger.info(f"  ... ({len(lines) - 3} more lines)")
    return True


def main():
    api_key = os.environ.get("PLATO_API_KEY")
    if not api_key:
        logger.error("PLATO_API_KEY not set")
        return 1

    logger.info("=" * 70)
    logger.info("PREVIEW LOCAL DEV ENVIRONMENT")
    logger.info("=" * 70)
    logger.info(f"Repo: {GITHUB_REPO}")
    logger.info(f"Branch: {GITHUB_BRANCH}")
    logger.info("")

    plato = Plato()
    session = None

    try:
        # Create a blank VM with enough resources for docker-compose
        logger.info("Creating session with blank VM...")
        start_time = time.time()

        session = plato.sessions.create(
            envs=[
                Env.resource(
                    simulator="preview-dev",
                    sim_config=SimConfigCompute(
                        cpus=4,
                        memory=8192,  # 8GB RAM for docker
                        disk=20480,  # 20GB disk for docker images
                    ),
                    alias="dev",
                )
            ],
            timeout=600,
            connect_network=True,
        )

        elapsed = time.time() - start_time
        logger.info(f"Session created in {elapsed:.1f}s: {session.session_id}")

        env = session.envs[0]
        logger.info(f"Environment: {env.job_id}")
        logger.info(f"Public URL: {env.public_url}")
        logger.info("")

        # Start heartbeat to keep session alive
        session.start_heartbeat()

        # Setup Docker overlay (faster than vfs)
        logger.info("Setting up Docker overlay storage...")
        session.setup_sandbox(timeout=120)
        logger.info("  Docker overlay setup complete")

        # Setup SSH key for git clone
        if not execute_and_log(session, "mkdir -p /root/.ssh && chmod 700 /root/.ssh", "Creating SSH directory"):
            return 1

        # Write the SSH private key
        escaped_key = SSH_PRIVATE_KEY.replace("'", "'\\''")
        if not execute_and_log(
            session,
            f"echo '{escaped_key}' > /root/.ssh/plato_deploy && chmod 600 /root/.ssh/plato_deploy",
            "Writing SSH deploy key",
        ):
            return 1

        # Add GitHub to known hosts
        if not execute_and_log(
            session,
            "ssh-keyscan -t ed25519 github.com >> /root/.ssh/known_hosts 2>/dev/null",
            "Adding GitHub to known hosts",
        ):
            return 1

        # Clone the repo with deploy key
        logger.info(f"Cloning {GITHUB_REPO}...")
        clone_cmd = f'GIT_SSH_COMMAND="ssh -i /root/.ssh/plato_deploy -o StrictHostKeyChecking=no" git clone --depth 1 -b {GITHUB_BRANCH} {GITHUB_REPO} /root/plato'
        clone_result = session.execute(clone_cmd, timeout=300)
        for job_id, res in clone_result.results.items():
            if res.exit_code != 0:
                logger.error(f"  git clone failed: {res.stderr}")
                return 1
            logger.info("  git clone completed successfully")

        # Configure git to use deploy key for future operations
        if not execute_and_log(
            session,
            'cd /root/plato && git config core.sshCommand "ssh -i /root/.ssh/plato_deploy -o StrictHostKeyChecking=no"',
            "Configuring git SSH",
        ):
            return 1

        # Start docker-compose with preview config
        logger.info("Starting docker-compose (this may take a few minutes for first build)...")
        compose_result = session.execute(
            "cd /root/plato/local-dev && docker compose -f docker-compose.preview.yml up -d --build",
            timeout=900,  # 15 minutes for first build
        )
        for job_id, res in compose_result.results.items():
            if res.exit_code != 0:
                logger.warning(f"  docker-compose may have issues: {res.stderr[:500] if res.stderr else ''}")
                # Don't fail - might still be starting
            else:
                logger.info("  docker-compose started")

        # Wait a bit for services to initialize
        logger.info("Waiting for services to initialize (60s)...")
        session.execute("sleep 60", timeout=120)

        # Check running containers
        logger.info("Checking running containers...")
        execute_and_log(session, "docker ps --format 'table {{.Names}}\t{{.Status}}'", "Container status")

        # Check if nginx is healthy
        logger.info("Checking nginx health...")
        health_result = session.execute("curl -sf http://localhost:8080/health || echo 'not ready'", timeout=30)
        for job_id, res in health_result.results.items():
            if "not ready" in (res.stdout or ""):
                logger.warning("  Nginx not ready yet - services may still be starting")
            else:
                logger.info("  Nginx is healthy!")

        # Print access info
        logger.info("")
        logger.info("=" * 70)
        logger.info("PREVIEW ENVIRONMENT READY")
        logger.info("=" * 70)
        logger.info(f"Session ID: {session.session_id}")
        logger.info(f"Job ID: {env.job_id}")
        logger.info("")
        logger.info("Access URLs:")
        logger.info(f"  Public URL: {env.public_url}")
        logger.info(f"  Connect URL: https://{env.job_id}.connect.plato.so")
        logger.info(f"  API (via connect): https://{env.job_id}--8080.connect.plato.so")
        logger.info("")
        logger.info("SSH access (if network connected):")
        logger.info("  SSH to VM: plato sandbox ssh (from directory with .plato/state.json)")
        logger.info("")
        logger.info("Docker compose logs:")
        logger.info("  docker compose -f docker-compose.preview.yml logs -f")
        logger.info("")
        logger.info("=" * 70)
        logger.info("Press Enter to stop the session and clean up...")
        logger.info("=" * 70)

        # Wait for user input
        try:
            input()
        except EOFError:
            # Running non-interactively, wait forever
            logger.info("Running non-interactively. Press Ctrl+C to stop.")
            try:
                while True:
                    time.sleep(60)
            except KeyboardInterrupt:
                pass

        logger.info("")
        logger.info("Shutting down...")
        return 0

    except KeyboardInterrupt:
        logger.info("\nInterrupted by user")
        return 0

    except Exception as e:
        logger.error(f"Error: {e}")
        import traceback

        traceback.print_exc()
        return 1

    finally:
        if session:
            logger.info("Closing session...")
            try:
                session.close()
            except Exception as e:
                logger.warning(f"Error closing session: {e}")
        plato.close()
        logger.info("Done.")


if __name__ == "__main__":
    sys.exit(main())
