#!/usr/bin/env python3
"""Snapshot a local development environment.

This example:
1. Starts a blank VM
2. Clones the plato repo via SSH with a deploy key
3. Starts local dev docker-compose
4. Waits for user confirmation before snapshotting
5. Creates a disk snapshot

Usage:
    export PLATO_API_KEY=your-key
    python snapshot_local_dev.py
"""

import logging
import os
import time

from dotenv import load_dotenv

from plato.v2 import Env, Plato
from plato.v2.types import SimConfigCompute

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Simulator name for the snapshot
SIMULATOR_NAME = "plato-local-dev"

# GitHub repo to clone
GITHUB_REPO = "git@github.com:useplato/plato.git"
GITHUB_BRANCH = "preview-deployments"

# SSH deploy key for cloning useplato/plato (ed25519)
SSH_PRIVATE_KEY = """-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW
QyNTUxOQAAACCzSn8opb8nWXEZ8yEv3WQG8P+vVbZGwgEDjhbmSSqIsgAAAJhF9JNKRfST
SgAAAAtzc2gtZWQyNTUxOQAAACCzSn8opb8nWXEZ8yEv3WQG8P+vVbZGwgEDjhbmSSqIsg
AAAEC5AlVUuWLCtviqAI8iI+8A4LTeDiNgjL6zlGk6NJp16bNKfyilvydZcRnzIS/dZAbw
/69VtkbCAQOOFuZJKoiyAAAAD3BsYXRvLXZtLWRlcGxveQECAwQFBg==
-----END OPENSSH PRIVATE KEY-----"""


def main():
    api_key = os.environ.get("PLATO_API_KEY")
    if not api_key:
        logger.error("PLATO_API_KEY not set")
        return 1

    logger.info("=" * 70)
    logger.info("SNAPSHOT LOCAL DEV ENVIRONMENT")
    logger.info("=" * 70)
    logger.info(f"Repo: {GITHUB_REPO}")
    logger.info(f"Simulator: {SIMULATOR_NAME}")
    logger.info("")

    plato = Plato()
    session = None

    try:
        # Create a blank VM with enough resources for docker-compose
        logger.info("Creating session with blank VM...")
        session = plato.sessions.create(
            envs=[
                Env.resource(
                    simulator=SIMULATOR_NAME,
                    sim_config=SimConfigCompute(
                        cpus=2,
                        memory=4096,
                        disk=8192,  # 8GB for docker images
                    ),
                    alias="dev",
                )
            ],
            timeout=7200,  # 2 hours
            connect_network=True,
        )

        logger.info(f"Session created: {session.session_id}")
        env = session.envs[0]
        logger.info(f"Environment: {env.job_id}")

        # Setup SSH key for git clone
        logger.info("Setting up SSH key for GitHub...")
        session.execute("mkdir -p /root/.ssh && chmod 700 /root/.ssh", timeout=30)

        # Write the SSH private key
        escaped_key = SSH_PRIVATE_KEY.replace("'", "'\\''")
        session.execute(
            f"echo '{escaped_key}' > /root/.ssh/plato_deploy && chmod 600 /root/.ssh/plato_deploy",
            timeout=30,
        )

        # Add GitHub to known hosts
        session.execute(
            "ssh-keyscan -t ed25519 github.com >> /root/.ssh/known_hosts 2>/dev/null",
            timeout=30,
        )

        # Clone the repo with deploy key
        logger.info(f"Cloning {GITHUB_REPO} (branch: {GITHUB_BRANCH})...")
        clone_cmd = f'GIT_SSH_COMMAND="ssh -i /root/.ssh/plato_deploy -o StrictHostKeyChecking=no" git clone --depth 1 -b {GITHUB_BRANCH} {GITHUB_REPO} /root/plato'
        clone_result = session.execute(clone_cmd, timeout=300)
        for job_id, res in clone_result.results.items():
            if res.exit_code != 0:
                logger.error(f"  git clone failed: {res.stderr}")
                return 1
            logger.info("  git clone completed successfully")

        # Configure git to use deploy key for future operations
        session.execute(
            'cd /root/plato && git config core.sshCommand "ssh -i /root/.ssh/plato_deploy -o StrictHostKeyChecking=no"',
            timeout=30,
        )

        # Start docker-compose with preview config
        logger.info("Starting docker-compose (this may take a few minutes for first build)...")
        compose_result = session.execute(
            "cd /root/plato/local-dev && docker compose -f docker-compose.preview.yml up -d --build",
            timeout=900,  # 15 minutes for first build
        )
        for job_id, res in compose_result.results.items():
            if res.exit_code != 0:
                logger.warning(f"  docker-compose may have issues: {res.stderr[:500] if res.stderr else ''}")
            else:
                logger.info("  docker-compose started")

        # Wait for services to initialize
        logger.info("Waiting for services to initialize (60s)...")
        session.execute("sleep 60", timeout=120)

        # Check running containers
        logger.info("Checking running containers...")
        check_result = session.execute("docker ps --format 'table {{.Names}}\\t{{.Status}}'", timeout=30)
        for job_id, res in check_result.results.items():
            if res.stdout:
                for line in res.stdout.strip().split("\n"):
                    logger.info(f"  {line}")

        # Check if nginx is healthy
        logger.info("Checking nginx health...")
        health_result = session.execute("curl -sf http://localhost:8080/health || echo 'not ready'", timeout=30)
        for job_id, res in health_result.results.items():
            if "not ready" in (res.stdout or ""):
                logger.warning("  Nginx not ready yet - services may still be starting")
            else:
                logger.info("  Nginx is healthy!")

        # Wait for user confirmation before snapshotting
        logger.info("")
        logger.info("=" * 70)
        logger.info("ENVIRONMENT READY - WAITING FOR CONFIRMATION")
        logger.info("=" * 70)
        logger.info(f"Session ID: {session.session_id}")
        logger.info(f"Job ID: {env.job_id}")
        logger.info("")
        logger.info("Please verify the environment is set up correctly.")
        logger.info("Press Enter to create the disk snapshot, or Ctrl+C to abort...")
        logger.info("=" * 70)

        try:
            input()
        except EOFError:
            # Running non-interactively, wait for Ctrl+C
            logger.info("Running non-interactively. Press Ctrl+C to abort or wait 60s to continue...")
            time.sleep(60)

        # Create disk snapshot (uses snapshot-store for chunk-based dedup)
        logger.info("Creating disk snapshot...")
        snapshot_result = session.disk_snapshot(
            override_service=SIMULATOR_NAME,
            override_version="dev",
            override_dataset="local",
        )

        for job_id, info in snapshot_result.results.items():
            if info.artifact_id:
                logger.info(f"  {job_id}: artifact_id={info.artifact_id}")
            else:
                logger.error(f"  {job_id}: snapshot failed - {info.error}")

        logger.info("")
        logger.info("SUCCESS: Disk snapshot created!")
        logger.info("You can now use this artifact with:")
        logger.info(f'  Env.simulator("{SIMULATOR_NAME}", tag="dev", dataset="local")')
        return 0

    except Exception as e:
        logger.error(f"Error: {e}")
        import traceback

        traceback.print_exc()
        return 1

    finally:
        if session:
            logger.info("Closing session...")
            session.close()
        plato.close()


if __name__ == "__main__":
    exit(main())
