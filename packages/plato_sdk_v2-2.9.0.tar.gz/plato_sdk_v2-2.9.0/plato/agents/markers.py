"""Annotation markers for Plato agent configurations."""

from __future__ import annotations


class Secret:
    """Annotation marker for secret fields.

    Fields annotated with Secret are automatically loaded from environment variables.
    The env var name is the uppercase version of the field name (e.g., api_key -> API_KEY).

    Usage:
        api_key: Annotated[str, Secret(description="API key")]
    """

    def __init__(self, description: str = "", required: bool = False):
        self.description = description
        self.required = required
