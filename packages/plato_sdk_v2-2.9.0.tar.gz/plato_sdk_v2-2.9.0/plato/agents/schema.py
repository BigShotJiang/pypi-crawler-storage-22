"""JSON schema generation for Plato agent configurations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from plato.agents.markers import Secret

if TYPE_CHECKING:
    from plato.agents.config import AgentConfig


def get_field_secrets(config_cls: type[AgentConfig]) -> dict[str, Secret]:
    """Get Secret annotations for each field.

    Args:
        config_cls: The AgentConfig subclass to inspect

    Returns:
        Dict mapping field name to Secret annotation
    """
    result: dict[str, Secret] = {}

    for field_name, field_info in config_cls.model_fields.items():
        for meta in field_info.metadata:
            if isinstance(meta, Secret):
                result[field_name] = meta
                break

    return result


def get_agent_config_schema(config_cls: type[AgentConfig]) -> dict[str, Any]:
    """Get JSON schema for an agent config with secrets separated.

    Args:
        config_cls: The AgentConfig subclass to generate schema for

    Returns:
        JSON schema dict with properties, required, and secrets fields
    """
    full_schema = config_cls.model_json_schema()
    full_schema.pop("title", None)

    secrets_map = get_field_secrets(config_cls)
    properties = full_schema.get("properties", {})

    config_properties: dict[str, Any] = {}
    secrets: list[dict[str, Any]] = []

    # Skip internal fields
    internal_fields = {"logs_dir"}

    for field_name, prop_schema in properties.items():
        if field_name in internal_fields:
            continue

        if field_name in secrets_map:
            secret = secrets_map[field_name]
            secrets.append(
                {
                    "name": field_name,
                    "description": secret.description,
                    "required": secret.required,
                }
            )
        else:
            config_properties[field_name] = prop_schema

    required = [r for r in full_schema.get("required", []) if r not in internal_fields and r not in secrets_map]

    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": config_properties,
        "required": required,
        "secrets": secrets,
    }


def get_agent_schema(agent_cls: type) -> dict[str, Any]:
    """Get full schema for an agent including config and build schemas.

    Args:
        agent_cls: The BaseAgent subclass to generate schema for

    Returns:
        Dict with config and build schema sections
    """
    from plato.agents.build import BuildConfig

    config_class = agent_cls.get_config_class()
    return {
        "config": get_agent_config_schema(config_class),
        "build": BuildConfig.get_json_schema(),
    }
