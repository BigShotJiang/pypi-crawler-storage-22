# (c) 2015-2023 Acellera Ltd http://www.acellera.com
# All Rights Reserved
# Distributed under HTMD Software License Agreement
# No redistribution in whole or part
#
"""Docker/GCloud manifest backend."""

import base64
import gzip
import json
import logging
import os
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple
from playmolecule._config import _get_config

logger = logging.getLogger("playmolecule.backends.docker")

# Cached credentials and session
_cached_credentials = None
_cached_session = None

_CONFIG = _get_config()


def _image_tag_to_name(image_tag: str) -> str:
    """Convert an image tag to a name."""
    image_name = image_tag.split("/")[-2:]
    image_name = "_".join(image_name)
    image_name = image_name.replace(":", "_")
    return image_name


def _get_or_create_session():
    """Get or create a cached requests session with authentication."""
    import google.auth
    from google.auth.transport.requests import Request
    import requests

    global _cached_credentials, _cached_session

    # Check if we need to refresh credentials
    need_refresh = True
    if _cached_credentials is not None:
        expiry = getattr(_cached_credentials, "expiry", None)
        if expiry is not None:
            if expiry.tzinfo is None:
                expiry = expiry.replace(tzinfo=timezone.utc)
            if expiry > datetime.now(timezone.utc):
                need_refresh = False

    if need_refresh:
        credentials, _ = google.auth.default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"]
        )
        credentials.refresh(Request())
        _cached_credentials = credentials

    if _cached_session is None:
        _cached_session = requests.Session()

    return _cached_session, _cached_credentials.token


def _get_location_and_project_id(root: str) -> Tuple[str, str]:
    # Given a URL like this docker://europe-southwest1-docker.pkg.dev/repositories-368911
    # parse it to get the project_id and location. It could also end with a trailing slash.
    import re

    match = re.match(r"docker://(.*)-docker\.pkg\.dev/(.*)/?", root)
    if match:
        return match.group(1), match.group(2)
    else:
        raise ValueError(f"Invalid Docker URL: {root}")


class _DockerManifestBackend:
    """Backend for loading app manifests from Docker/GCloud registry."""

    def __init__(self, root: str):
        """Initialize the Docker manifest backend.

        Parameters
        ----------
        root : str
            Root path (should start with "docker")
        """
        self.root = root
        self.location, self.project_id = _get_location_and_project_id(root)

    def get_apps(self) -> Dict[str, Dict[str, dict]]:
        """Get all available apps from Docker registry.

        Returns
        -------
        dict
            Nested dict: {appname: {version: {"manifest": ..., "appdir": None, "run.sh": ...}}}
        """
        prefix = f"{self.location}-docker.pkg.dev/{self.project_id}"
        manifests = self._get_app_manifests(prefix)

        apps = {}
        for image_tag, manifest in manifests.items():
            container_config = manifest["container_config"]
            app_name = container_config["name"].lower()
            version = container_config["version"]

            # Generate run script
            run_sh = self._generate_run_script(image_tag)

            if app_name not in apps:
                apps[app_name] = {}
            apps[app_name][f"v{version}"] = {
                "manifest": manifest,
                "appdir": None,
                "run.sh": run_sh,
                "container_image": image_tag,
                "files": self._get_app_files(manifest, image_tag),
            }

        return apps

    def _get_app_files(self, manifest: Optional[dict], container_image: str) -> dict:
        """Get files associated with an app.

        Parameters
        ----------
        manifest : dict or None
            The app manifest
        container_image : str
            The container image tag

        Returns
        -------
        dict
            Dictionary of filename -> _DockerFile objects
        """
        from playmolecule._appfiles import _DockerFile

        if manifest is None:
            return {}

        files = {}
        for name, fullpath in manifest.get("files", {}).items():
            # Add parent directories
            for dir_name, dir_path in self._get_parent_dirs(name, fullpath):
                if dir_name not in files:
                    files[dir_name] = _DockerFile(dir_name, dir_path, container_image)
            files[name] = _DockerFile(name, fullpath, container_image)

        return files

    def _get_parent_dirs(self, name: str, fullpath: str):
        """Yield parent directories for a file path."""
        fullpath_p = Path(fullpath)
        name_p = Path(name)

        for i in range(1, len(name_p.parts)):
            yield str(Path(*name_p.parts[:i])), str(
                Path(*fullpath_p.parts[: -len(name_p.parts) + i])
            )

    def _generate_run_script(self, image_tag: str) -> str:
        """Generate the docker run script for an image."""
        curr_dir = os.path.dirname(os.path.abspath(__file__))
        share_dir = os.path.join(os.path.dirname(curr_dir), "share")

        if _CONFIG.runtime == "docker":
            with open(os.path.join(share_dir, "docker_run.sh"), "r") as f:
                run_sh = f.read()
        elif _CONFIG.runtime == "apptainer":
            with open(os.path.join(share_dir, "apptainer_run.sh"), "r") as f:
                run_sh = f.read()
            run_sh = run_sh.replace("{license_file_or_server}", '"27000@127.0.0.1"')
            run_sh = run_sh.replace("{sif_cache_dir}", _CONFIG.sif_cache_dir)
            run_sh = run_sh.replace("{image_name}", _image_tag_to_name(image_tag))
        else:
            raise RuntimeError(f"Unsupported runtime: {_CONFIG.runtime}")

        return run_sh.replace("{docker_image}", f'"{image_tag}"')

    def _get_app_list(self) -> list:
        """Get list of all Docker images from GCloud Artifact Registry."""
        from google.cloud import artifactregistry_v1

        ar_client = artifactregistry_v1.ArtifactRegistryClient()
        parent = f"projects/{self.project_id.strip()}/locations/{self.location}"
        registry_host = f"{self.location}-docker.pkg.dev"

        repos_request = artifactregistry_v1.ListRepositoriesRequest(parent=parent)
        repos = list(ar_client.list_repositories(request=repos_request))

        def process_repo(repo):
            if repo.format_ != artifactregistry_v1.Repository.Format.DOCKER:
                return []

            repo_id = repo.name.split("/")[-1]
            if repo_id == "acellera-docker-apps":
                return []

            try:
                pkg_request = artifactregistry_v1.ListPackagesRequest(parent=repo.name)
                packages = ar_client.list_packages(request=pkg_request)
            except Exception:
                # If we don't have permissions to list packages in that repo, return empty list
                return []

            repo_images = []
            for pkg in packages:
                image_name = pkg.name.split("/")[-1]
                full_tag = (
                    f"{registry_host}/{self.project_id}/{repo_id}/{image_name}:latest"
                )

                repo_images.append(
                    {
                        "project_id": self.project_id,
                        "location": self.location,
                        "repo": repo_id,
                        "image": image_name,
                        "tag": "latest",
                        "full_tag": full_tag,
                    }
                )
            return repo_images

        all_images = []
        with ThreadPoolExecutor(max_workers=20) as executor:
            results = executor.map(process_repo, repos)
            for result in results:
                all_images.extend(result)

        return all_images

    def _get_local_labels(self, image_tag: str) -> Optional[dict]:
        """Get all labels from the local image."""

        if _CONFIG.runtime == "docker":
            import docker

            client = docker.from_env()
            image = client.images.get(image_tag)
            return image.labels
        elif _CONFIG.runtime == "apptainer":
            # For apptainer, we need to check if we have a cached SIF file
            # and inspect it for labels
            sif_path = os.path.join(
                _CONFIG.sif_cache_dir, _image_tag_to_name(image_tag) + ".sif"
            )

            if not os.path.exists(sif_path):
                # Image not cached locally
                raise ValueError(f"Image not found locally: {image_tag}")

            # Use apptainer inspect to get labels
            try:
                result = subprocess.run(
                    ["apptainer", "inspect", "--labels", "--json", sif_path],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if result.returncode == 0:
                    labels_data = json.loads(result.stdout)
                    return (
                        labels_data.get("data", {})
                        .get("attributes", {})
                        .get("labels", {})
                    )
                else:
                    logger.error(f"Failed to inspect image {sif_path}: {result.stderr}")
                    return None
            except Exception as e:
                logger.error(f"Error inspecting apptainer image: {e}")
                return None
        else:
            raise RuntimeError(f"Unsupported runtime: {_CONFIG.runtime}")

    def _get_remote_labels(
        self,
        project_id: str,
        location: str,
        repo: str,
        image: str,
        tag: str,
    ) -> Optional[dict]:
        """Fetch all labels from the remote image."""
        t_start = time.time()
        session, token = _get_or_create_session()
        logger.debug(f"  Time to get session/token: {time.time() - t_start:.3f}s")

        base_url = f"https://{location}-docker.pkg.dev"
        image_path = f"v2/{project_id}/{repo}/{image}"

        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": (
                "application/vnd.docker.distribution.manifest.v2+json, "
                "application/vnd.oci.image.index.v1+json, "
                "application/vnd.oci.image.manifest.v1+json"
            ),
        }

        # Get manifest
        manifest_url = f"{base_url}/{image_path}/manifests/{tag}"
        t = time.time()
        r = session.get(manifest_url, headers=headers)
        if r.status_code != 200:
            raise ValueError(f"Failed to get manifest: {r.status_code} {r.text}")
        logger.debug(f"  Time to get manifest: {time.time() - t:.3f}s")

        manifest = r.json()
        media_type = r.headers.get("Content-Type", "")

        # If it's an Index, pick the first manifest in the list (usually the default)
        if "index" in media_type or "manifests" in manifest:
            # Dig deeper to get the specific manifest for the first architecture
            first_manifest_digest = manifest["manifests"][0]["digest"]

            # Fetch the actual manifest for that specific digest
            manifest_url = f"{base_url}/{image_path}/manifests/{first_manifest_digest}"
            r = session.get(manifest_url, headers=headers)
            manifest = r.json()

        # Extract config digest
        config_digest = manifest.get("config", {}).get("digest")
        if not config_digest:
            config_digest = manifest.get("manifests", [{}])[0].get("digest")
        if not config_digest:
            raise ValueError("Could not find config digest in manifest")

        # Get config blob
        blob_url = f"{base_url}/{image_path}/blobs/{config_digest}"
        t = time.time()
        r = session.get(blob_url, headers=headers)
        if r.status_code != 200:
            raise ValueError(f"Failed to get config blob: {r.status_code}")
        logger.debug(f"  Time to get config blob: {time.time() - t:.3f}s")

        config_data = r.json()

        # Extract and decode label
        labels = config_data.get("config", {}).get("Labels", {})
        return labels

    def _get_app_manifests(self, prefix: str) -> Dict[str, dict]:
        """Get manifests for all images matching prefix."""

        manifest_label = "function.manifest.compressed"
        docs_label = "function.docs.compressed"

        images = self._get_app_list()

        # Filter by prefix
        target_images = [img for img in images if img["full_tag"].startswith(prefix)]

        labels = {}

        # Separate local and remote images
        local_images = []
        remote_images = []

        if _CONFIG.runtime == "docker":
            import docker

            client = docker.from_env()

            for image_info in target_images:
                image_tag = image_info["full_tag"]
                try:
                    client.images.get(image_tag)
                    local_images.append(image_info)
                except docker.errors.ImageNotFound:
                    remote_images.append(image_info)
        elif _CONFIG.runtime == "apptainer":
            # Check for cached SIF files
            for image_info in target_images:
                image_tag = image_info["full_tag"]
                sif_path = os.path.join(
                    _CONFIG.sif_cache_dir, _image_tag_to_name(image_tag) + ".sif"
                )

                if os.path.exists(sif_path):
                    local_images.append(image_info)
                else:
                    remote_images.append(image_info)
        else:
            # No runtime available, all images are remote
            remote_images = target_images

        # Process local images
        for image_info in local_images:
            image_tag = image_info["full_tag"]

            try:
                labels[image_tag] = self._get_local_labels(image_tag)
                logger.info(f"  {image_tag} (local)")
            except Exception as e:
                logger.error(f"  Failed to get labels for {image_tag}: {e}")
                continue

        # Process remote images in parallel
        if remote_images:
            t_start = time.time()

            def fetch_remote_labels(image_info):
                try:
                    labels = self._get_remote_labels(
                        image_info["project_id"],
                        image_info["location"],
                        image_info["repo"],
                        image_info["image"],
                        image_info["tag"],
                    )
                    return image_info["full_tag"], labels, None
                except Exception as e:
                    return image_info["full_tag"], None, str(e)

            with ThreadPoolExecutor(max_workers=10) as executor:
                future_to_image = {
                    executor.submit(fetch_remote_labels, img): img
                    for img in remote_images
                }

                for future in as_completed(future_to_image):
                    image_tag, image_labels, error = future.result()

                    if error:
                        logger.error(f"  Error fetching {image_tag}: {error}")
                    elif image_labels:
                        labels[image_tag] = image_labels
                        logger.info(f"  {image_tag}")

            elapsed = time.time() - t_start
            logger.info(
                f"Loaded {len(remote_images)} app manifests in {elapsed:.2f}s "
                f"({elapsed/len(remote_images):.2f}s per app)"
            )

        manifests = {}
        for image_tag, labels in labels.items():
            try:
                manifest = labels.get(manifest_label)
                if manifest:
                    manifests[image_tag] = json.loads(
                        gzip.decompress(base64.b64decode(manifest))
                    )
            except Exception as e:
                logger.error(f"Failed to decompress manifest for {image_tag}: {e}")
                continue
            try:
                docs = labels.get(docs_label)
                if docs:
                    manifests[image_tag]["docs"] = json.loads(
                        gzip.decompress(base64.b64decode(docs))
                    )
            except Exception as e:
                logger.error(f"Failed to decompress docs for {image_tag}: {e}")
                continue

        return manifests


def _update_docker_apps_from_gcloud() -> None:
    """Pull updates for container images that already exist locally from GCloud Artifact Registry.

    Parameters
    ----------
    project_id : str
        GCloud project ID
    location : str
        GCloud location
    """
    # Find the docker registry in the registries list
    docker_registry = [
        registry for registry in _CONFIG.registries if registry.startswith("docker")
    ]
    if len(docker_registry) == 0:
        raise ValueError("No docker registry found in registries list")
    docker_registry = docker_registry[0]

    backend = _DockerManifestBackend(docker_registry)
    images = backend._get_app_list()

    if _CONFIG.runtime == "docker":
        import docker

        docker_client = docker.from_env()

        # Filter to only update images that already exist locally
        for image_info in images:
            tag = image_info["full_tag"]
            try:
                # Check if image exists locally
                docker_client.images.get(tag)
                # If we get here, the image exists locally, so update it
                logger.info(f"Updating existing image: {tag} ...")
                docker_client.images.pull(tag)
            except docker.errors.ImageNotFound:
                # Image doesn't exist locally, skip it
                logger.debug(f"Skipping {tag} - not found locally")
            except Exception as e:
                logger.error(f"Failed to pull {tag}: {e}")
    elif _CONFIG.runtime == "apptainer":
        os.makedirs(_CONFIG.sif_cache_dir, exist_ok=True)

        for image_info in images:
            tag = image_info["full_tag"]
            image_name = _image_tag_to_name(tag)
            sif_path = os.path.join(_CONFIG.sif_cache_dir, image_name + ".sif")

            if os.path.exists(sif_path):
                # Image exists locally, update it
                logger.info(f"Updating existing image: {tag} ...")

                try:
                    # Remove old image
                    os.remove(sif_path)
                    # Pull new version
                    result = subprocess.run(
                        ["apptainer", "pull", sif_path, f"docker://{tag}"],
                        capture_output=True,
                        text=True,
                        timeout=300,  # 5 minute timeout
                    )
                    if result.returncode != 0:
                        logger.error(f"Failed to pull {tag}: {result.stderr}")
                except Exception as e:
                    logger.error(f"Failed to update {tag}: {e}")
            else:
                # Image doesn't exist locally, skip it
                logger.debug(f"Skipping {tag} - not found locally")
    else:
        raise RuntimeError(f"Unsupported runtime: {_CONFIG.runtime}")
