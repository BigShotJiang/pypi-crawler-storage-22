# PlexiSMS Python SDK

The official Python library for the [PlexiSMS](https://plexisms.com) API. Send SMS, manage OTPs, and check detailed analytics with our reliable Tier-1 network.

## Installation

Install the package via pip:

```bash
pip install plexisms
```


## Usage

### 1. Initialize the Client

You need your API Key from the PlexiSMS Dashboard.

```python
import os
from plexisms import Client

# Option 1: Pass API Key directly
client = Client(api_key="your_api_key_here")

# Option 2: Use environment variable 'PLEXISMS_API_KEY'
# export PLEXISMS_API_KEY="your_api_key_here"
# client = Client()
```

### 2. Send an SMS

```python
try:
    response = client.messages.create(
        to="+243970000000", # Change the phone number
        body="Hello from Python! 🚀",
        sender_id="MyApp"  # Your Name or Brand
    )
    print(f"SMS Sent! ID: {response['message_id']}")
    
except Exception as e:
    print(f"Error: {e}")
```

### 3. Send Bulk SMS

```python
client.messages.create_bulk(
    phone_numbers=["+243970000000", "+243810000000"],
    body="Bulk message test",
    sender_id="MyApp"
)
```

### 4. OTP Verification

```python
# Step 1: Send OTP
otp_res = client.otp.send(to="+243970000000", brand="MyService")
verification_id = otp_res['verification_id']

# Step 2: Verify Code (user input)
user_code = input("Enter code: ")
verify_res = client.otp.verify(verification_id=verification_id, code=user_code)

if verify_res['verified']:
    print("User verified successfully!")
else:
    print("Invalid code.")
```

### 5. Check Balance

```python
balance = client.account.balance()
print(f"Current Balance: {balance['amount']} {balance['currency']}")
```

## Error Handling

The SDK raises specific exceptions for better control flow:

```python
from plexisms import Client, AuthenticationError, BalanceError

try:
    client.messages.create(...)
except AuthenticationError:
    print("Invalid API Key")
except BalanceError:
    print("Please recharge your account")
except Exception as e:
    print(f"Unexpected error: {e}")
```

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

Distributed under the MIT License. See `LICENSE` for more information.
