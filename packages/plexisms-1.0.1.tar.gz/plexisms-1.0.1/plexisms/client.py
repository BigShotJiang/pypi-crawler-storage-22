import requests
import os
from typing import List, Optional, Dict, Union
from .exceptions import (
    AuthenticationError,
    BalanceError,
    ValidationError,
    APIError,
    PlexismsError
)

class Client:
    """
    Main client for interacting with the PlexiSMS API.
    """
    
    DEFAULT_BASE_URL = "https://server.plexisms.com"
    
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        """
        Initialize the client.
        
        :param api_key: Your PlexiSMS API Key. If not provided, looks for PLEXISMS_API_KEY env var.
        :param base_url: API Base URL (optional override).
        """
        self.api_key = api_key or os.getenv('PLEXISMS_API_KEY')
        if not self.api_key:
            raise AuthenticationError("API Key is required. Pass it to the constructor or set PLEXISMS_API_KEY environment variable.")
            
        self.base_url = (base_url or os.getenv('PLEXISMS_BASE_URL', self.DEFAULT_BASE_URL)).rstrip('/')
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f'Token {self.api_key}',
            'Content-Type': 'application/json',
            'User-Agent': 'plexisms-python/1.0.0'
        })
        
        # Shortcuts for resources
        self.messages = Messages(self)
        self.otp = OTP(self)
        self.account = Account(self)

    def _request(self, method: str, endpoint: str, data: Optional[Dict] = None, params: Optional[Dict] = None) -> Dict:
        """Internal method to handle requests and error mapping."""
        url = f"{self.base_url}{endpoint}"
        
        try:
            response = self.session.request(method, url, json=data, params=params)
        except requests.RequestException as e:
            raise APIError(f"Connection failed: {str(e)}") from e
            
        if response.status_code >= 400:
            self._handle_error(response)
            
        try:
            return response.json()
        except ValueError:
            return {}

    def _handle_error(self, response):
        """Map HTTP status codes to specific exceptions."""
        try:
            error_data = response.json()
            error_message = error_data.get('error') or error_data.get('detail') or str(error_data)
        except ValueError:
            error_message = response.text
            
        if response.status_code == 401:
            raise AuthenticationError(f"Unauthorized: {error_message}")
        elif response.status_code == 402:
            raise BalanceError(f"Insufficient funds: {error_message}")
        elif response.status_code == 400:
            raise ValidationError(f"Bad Request: {error_message}")
        elif response.status_code == 403:
             raise AuthenticationError(f"Forbidden: {error_message}")
        elif response.status_code == 422:
            raise ValidationError(f"Validation Error: {error_message}")
        elif response.status_code >= 500:
            raise APIError(f"Server Error ({response.status_code}): {error_message}", status_code=response.status_code)
        else:
            raise APIError(f"API Error ({response.status_code}): {error_message}", status_code=response.status_code)


class Messages:
    """Methods for sending and managing SMS."""
    
    def __init__(self, client: Client):
        self.client = client
        
    def create(self, to: str, body: str, sender_id: Optional[str] = None, sms_type: str = 'transactional') -> Dict:
        """
        Send a single SMS.
        
        :param to: Recipient phone number (E.164 format, e.g., +243...)
        :param body: Message content
        :param sender_id: Custom Sender ID (max 11 chars alphanumeric)
        :param sms_type: 'transactional' or 'promotional'
        :return: Response dict with message details
        """
        payload = {
            "phone_number": to,
            "message": body,
            "sms_type": sms_type
        }
        if sender_id:
            payload["sender_id"] = sender_id
            
        return self.client._request("POST", "/api/sms/send/", data=payload)

    def create_bulk(self, phone_numbers: List[str], body: str, sender_id: Optional[str] = None, sms_type: str = 'transactional') -> Dict:
        """
        Send bulk SMS to multiple recipients.
        
        :param phone_numbers: List of E.164 phone numbers
        :param body: Message content
        :param sender_id: Custom Sender ID
        :param sms_type: 'transactional' or 'promotional'
        """
        payload = {
            "phone_numbers": phone_numbers,
            "message": body,
            "sms_type": sms_type
        }
        if sender_id:
            payload["sender_id"] = sender_id
            
        return self.client._request("POST", "/api/sms/send-bulk/", data=payload)
        
    def get(self, message_id: Union[str, int]) -> Dict:
        """
        Get the status and details of a specific message.
        """
        return self.client._request("GET", f"/api/sms/{message_id}/status/")


class OTP:
    """Methods for One-Time Passwords."""
    
    def __init__(self, client: Client):
        self.client = client
        
    def send(self, to: str, brand: str = "PlexiSMS") -> Dict:
        """
        Send an OTP code to a phone number.
        """
        payload = {
            "phone_number": to,
            "brand": brand
        }
        return self.client._request("POST", "/api/sms/send-otp/", data=payload)
        
    def verify(self, verification_id: str, code: str) -> Dict:
        """
        Verify a received OTP code.
        """
        payload = {
            "verification_id": verification_id,
            "otp_code": code
        }
        return self.client._request("POST", "/api/sms/verify-otp/", data=payload)


class Account:
    """Methods for account management."""
    
    def __init__(self, client: Client):
        self.client = client
        
    def balance(self) -> Dict:
        """
        Check current account balance.
        """
        return self.client._request("GET", "/api/sms/balance/")
