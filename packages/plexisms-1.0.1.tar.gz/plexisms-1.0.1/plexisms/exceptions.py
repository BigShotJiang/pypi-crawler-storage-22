class PlexismsError(Exception):
    """Base exception for all PlexiSMS errors."""
    pass

class AuthenticationError(PlexismsError):
    """Raised when API key is invalid or missing."""
    pass

class BalanceError(PlexismsError):
    """Raised when account balance is insufficient."""
    pass

class ValidationError(PlexismsError):
    """Raised when input data is invalid."""
    pass

class APIError(PlexismsError):
    """Raised when the API returns a server error or unexpected status."""
    def __init__(self, message, status_code=None, response_body=None):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body
