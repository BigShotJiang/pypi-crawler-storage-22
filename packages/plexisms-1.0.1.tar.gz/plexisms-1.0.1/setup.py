from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="plexisms",
    version="1.0.1",
    author="PlexiSMS Team",
    author_email="dev@plexisms.com",
    description="Official Python SDK for PlexiSMS API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/plexisms/sdk-plexisms-python",
    project_urls={
        "Bug Tracker": "https://github.com/plexisms/sdk-plexisms-python/issues",
        "Documentation": "https://plexisms.com/developers",
    },
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Communications :: Telephony",
    ],
    package_dir={"": "."},
    packages=find_packages(),
    python_requires=">=3.6",
    install_requires=[
        "requests>=2.25.0",
    ],
)
