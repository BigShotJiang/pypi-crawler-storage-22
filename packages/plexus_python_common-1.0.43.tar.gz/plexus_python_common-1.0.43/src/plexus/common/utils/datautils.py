import dataclasses
import datetime
import textwrap
from collections.abc import Callable, Generator, Mapping, Sequence
from typing import Any

import jinja2
import pyparsing as pp
import ujson as json
from iker.common.utils.funcutils import singleton
from iker.common.utils.iterutils import dicttree
from iker.common.utils.iterutils import dicttree_add, dicttree_remove
from iker.common.utils.iterutils import dicttree_children, dicttree_lineage, dicttree_subtree
from iker.common.utils.iterutils import head_or_none
from iker.common.utils.jsonutils import JsonObject, JsonType
from iker.common.utils.randutils import randomizer
from iker.common.utils.strutils import is_blank

from plexus.common.resources.tags import predefined_tagset_specs
from plexus.common.utils.strutils import BagName, UserName, VehicleName
from plexus.common.utils.strutils import colon_tag_parser, slash_tag_parser
from plexus.common.utils.strutils import dot_case_parser, kebab_case_parser, snake_case_parser
from plexus.common.utils.strutils import hex_string_parser
from plexus.common.utils.strutils import parse_bag_name, parse_user_name, parse_vehicle_name
from plexus.common.utils.strutils import semver_parser, uuid_parser
from plexus.common.utils.strutils import strict_abspath_parser, strict_relpath_parser
from plexus.common.utils.strutils import strict_fragmented_abspath_parser, strict_fragmented_relpath_parser
from plexus.common.utils.strutils import topic_parser, vin_code_chars, vin_code_parser

__all__ = [
    "compute_vin_code_check_digit",
    "validate_hex_string",
    "validate_snake_case",
    "validate_kebab_case",
    "validate_dot_case",
    "validate_uuid",
    "validate_strict_relpath",
    "validate_strict_abspath",
    "validate_strict_fragmented_relpath",
    "validate_strict_fragmented_abspath",
    "validate_semver",
    "validate_colon_tag",
    "validate_slash_tag",
    "validate_topic",
    "validate_vin_code",
    "validate_user_name",
    "validate_vehicle_name",
    "validate_bag_name",
    "validate_dt_timezone",
    "validate_json_type_dump_size",
    "random_vin_code",
    "known_topics",
    "known_user_names",
    "known_vehicle_names",
    "random_bag_names_sequence",
    "RichDesc",
    "Tag",
    "Tagset",
    "populate_tagset",
    "predefined_tagsets",
    "render_tagset_markdown_readme",
]


def make_compute_vin_code_check_digit() -> Callable[[str], str]:
    trans_nums = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 7, 9, 2, 3, 4, 5, 6, 7, 8, 9]
    weights = [8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2]

    trans_dict = {vin_code_char: trans_num for vin_code_char, trans_num in zip(vin_code_chars, trans_nums)}

    def func(vin_code: str) -> str:
        remainder = sum(trans_dict[vin_code_char] * weight for vin_code_char, weight in zip(vin_code, weights)) % 11
        return "X" if remainder == 10 else str(remainder)

    return func


compute_vin_code_check_digit = make_compute_vin_code_check_digit()


def make_validate_string(element: pp.ParserElement) -> Callable[[str], None]:
    def func(s: str) -> None:
        try:
            if not element.parse_string(s, parse_all=True):
                raise ValueError(f"failed to parse '{s}'")
        except Exception as e:
            raise ValueError(f"encountered error while parsing '{s}'") from e

    return func


validate_hex_string = make_validate_string(hex_string_parser)

validate_snake_case = make_validate_string(snake_case_parser)
validate_kebab_case = make_validate_string(kebab_case_parser)
validate_dot_case = make_validate_string(dot_case_parser)

validate_uuid = make_validate_string(uuid_parser)

validate_strict_relpath = make_validate_string(strict_relpath_parser)
validate_strict_abspath = make_validate_string(strict_abspath_parser)
validate_strict_fragmented_relpath = make_validate_string(strict_fragmented_relpath_parser)
validate_strict_fragmented_abspath = make_validate_string(strict_fragmented_abspath_parser)

validate_semver = make_validate_string(semver_parser)

validate_colon_tag = make_validate_string(colon_tag_parser)
validate_slash_tag = make_validate_string(slash_tag_parser)

validate_topic = make_validate_string(topic_parser)


def validate_vin_code(vin_code: str):
    make_validate_string(vin_code_parser)(vin_code)
    check_digit = compute_vin_code_check_digit(vin_code)
    if check_digit != vin_code[8]:
        raise ValueError(f"get wrong VIN code check digit from '{vin_code}', expected '{check_digit}'")


def make_validate_parse_string(parse: Callable[[str], Any]) -> Callable[[str], None]:
    def func(s: str) -> None:
        try:
            if not parse(s):
                raise ValueError(f"failed to parse '{s}'")
        except Exception as e:
            raise ValueError(f"encountered error while parsing '{s}'") from e

    return func


validate_user_name = make_validate_parse_string(parse_user_name)
validate_vehicle_name = make_validate_parse_string(parse_vehicle_name)
validate_bag_name = make_validate_parse_string(parse_bag_name)


def validate_dt_timezone(dt: datetime.datetime):
    if dt.tzinfo != datetime.timezone.utc:
        raise ValueError(f"dt '{dt}' is not in UTC")


def validate_json_type_dump_size(json_type: JsonType, dump_size_limit: int = 10000):
    dump_string = json.dumps(json_type, ensure_ascii=False)
    if len(dump_string) > dump_size_limit:
        raise ValueError(f"dump size exceeds the maximum length '{dump_size_limit}'")


def random_vin_code() -> str:
    vin_code = randomizer().random_string(vin_code_chars, 17)
    check_digit = compute_vin_code_check_digit(vin_code)
    return vin_code[:8] + check_digit + vin_code[9:]


@singleton
def known_topics() -> list[str]:
    return [
        "/sensor/camera/front_center",
        "/sensor/camera/front_left",
        "/sensor/camera/front_right",
        "/sensor/camera/side_left",
        "/sensor/camera/side_right",
        "/sensor/camera/rear_left",
        "/sensor/camera/rear_right",
        "/sensor/lidar/front_center",
        "/sensor/lidar/front_left_corner",
        "/sensor/lidar/front_right_corner",
        "/sensor/lidar/side_left",
        "/sensor/lidar/side_right",
    ]


@singleton
def known_user_names() -> list[UserName]:
    return [
        UserName("adam", "anderson"),
        UserName("ben", "bennett"),
        UserName("charlie", "clark"),
        UserName("david", "dixon"),
        UserName("evan", "edwards"),
        UserName("frank", "fisher"),
        UserName("george", "graham"),
        UserName("henry", "harrison"),
        UserName("isaac", "irving"),
        UserName("jack", "jacobs"),
        UserName("kevin", "kennedy"),
        UserName("luke", "lawson"),
        UserName("michael", "mitchell"),
        UserName("nathan", "newton"),
        UserName("oscar", "owens"),
        UserName("paul", "peterson"),
        UserName("quincy", "quinn"),
        UserName("ryan", "robinson"),
        UserName("sam", "stevens"),
        UserName("tom", "thomas"),
        UserName("umar", "underwood"),
        UserName("victor", "vaughan"),
        UserName("william", "walker"),
        UserName("xander", "xavier"),
        UserName("yale", "young"),
        UserName("zane", "zimmerman"),
    ]


@singleton
def known_vehicle_names() -> list[VehicleName]:
    return [
        VehicleName("cascadia", "antelope", "00000", "3AKJGLD5XLS000000"),
        VehicleName("cascadia", "bear", "00001", "3AKJGLD51LS000001"),
        VehicleName("cascadia", "cheetah", "00002", "3AKJGLD53LS000002"),
        VehicleName("cascadia", "dolphin", "00003", "3AKJGLD55LS000003"),
        VehicleName("cascadia", "eagle", "00004", "3AKJGLD57LS000004"),
        VehicleName("cascadia", "falcon", "00005", "3AKJGLD59LS000005"),
        VehicleName("cascadia", "gorilla", "00006", "3AKJGLD50LS000006"),
        VehicleName("cascadia", "hawk", "00007", "3AKJGLD52LS000007"),
        VehicleName("cascadia", "iguana", "00008", "3AKJGLD54LS000008"),
        VehicleName("cascadia", "jaguar", "00009", "3AKJGLD56LS000009"),
        VehicleName("cascadia", "koala", "00010", "3AKJGLD52LS000010"),
        VehicleName("cascadia", "leopard", "00011", "3AKJGLD54LS000011"),
        VehicleName("cascadia", "mongoose", "00012", "3AKJGLD56LS000012"),
        VehicleName("cascadia", "narwhal", "00013", "3AKJGLD58LS000013"),
        VehicleName("cascadia", "otter", "00014", "3AKJGLD5XLS000014"),
        VehicleName("cascadia", "panther", "00015", "3AKJGLD51LS000015"),
        VehicleName("cascadia", "quail", "00016", "3AKJGLD53LS000016"),
        VehicleName("cascadia", "rhino", "00017", "3AKJGLD55LS000017"),
        VehicleName("cascadia", "snake", "00018", "3AKJGLD57LS000018"),
        VehicleName("cascadia", "tiger", "00019", "3AKJGLD59LS000019"),
        VehicleName("cascadia", "urial", "00020", "3AKJGLD55LS000020"),
        VehicleName("cascadia", "vulture", "00021", "3AKJGLD57LS000021"),
        VehicleName("cascadia", "wolf", "00022", "3AKJGLD59LS000022"),
        VehicleName("cascadia", "xerus", "00023", "3AKJGLD50LS000023"),
        VehicleName("cascadia", "yak", "00024", "3AKJGLD52LS000024"),
        VehicleName("cascadia", "zebra", "00025", "3AKJGLD54LS000025"),
    ]


def random_bag_names_sequence(
    min_record_dt: datetime.datetime,
    max_record_dt: datetime.datetime,
    min_sequence_length: int,
    max_sequence_length: int,
) -> Generator[BagName, None, None]:
    vehicle_name = randomizer().choose(known_vehicle_names())
    record_dt = randomizer().random_datetime(begin=min_record_dt, end=max_record_dt)
    bags_count = randomizer().next_int(min_sequence_length, max_sequence_length)

    for record_sn in range(bags_count):
        yield BagName(vehicle_name=vehicle_name, record_dt=record_dt, record_sn=record_sn)


@dataclasses.dataclass(frozen=True, eq=True, order=True)
class RichDesc(object):
    type: str
    text: str


@dataclasses.dataclass(frozen=True, eq=True, order=True)
class Tag(object):
    name: str
    desc: str | RichDesc | None

    @property
    def tag_parts(self) -> list[str]:
        return self.name.rsplit(":")

    @property
    def parent_tag_name(self) -> str | None:
        return head_or_none(self.name.rsplit(":", 1))


class Tagset(Sequence[Tag], Mapping[str, Tag]):
    def __init__(self, namespace: str, desc: str | RichDesc) -> None:
        super().__init__()
        self.namespace = namespace
        self.desc = desc
        self.tags: list[Tag] = []
        self.tags_dict: dict[str, Tag] = {}
        self.tags_tree: dicttree[str, Tag] = {}

    def __contains__(self, item: str | Tag) -> bool:
        tag_name = item.name if isinstance(item, Tag) else item
        return tag_name in self.tags_dict

    def __len__(self) -> int:
        return len(self.tags)

    def __getitem__(self, index: int) -> Tag:
        return self.tags[index]

    def keys(self):
        return self.tags_dict.keys()

    def values(self):
        return self.tags_dict.values()

    def items(self):
        return self.tags_dict.items()

    def get(self, item: str | Tag) -> Tag | None:
        tag_name = item.name if isinstance(item, Tag) else item
        return self.tags_dict.get(tag_name)

    @property
    def tag_names(self) -> list[str]:
        return list(self.tags_dict.keys())

    def add(self, tag: Tag) -> None:
        if tag.name in self.tags_dict:
            raise ValueError(f"duplicate tag name '{tag.name}'")

        self.tags.append(tag)
        self.tags_dict[tag.name] = tag

        dicttree_add(self.tags_tree, tag.tag_parts, tag, create_prefix=True)

    def remove(self, tag_name: str) -> None:
        tag = self.get(tag_name)
        if tag is None:
            raise ValueError(f"tag '{tag_name}' not found")

        self.tags.remove(tag)
        del self.tags_dict[tag_name]

        dicttree_remove(self.tags_tree, tag.tag_parts, recursive=True)

    def child_tags(self, parent: str | Tag) -> list[Tag]:
        if parent is None:
            return []
        if isinstance(parent, str):
            return self.child_tags(self.get(parent))

        subtree = dicttree_subtree(self.tags_tree, parent.tag_parts)
        return list(dicttree_children(subtree)) if subtree else []

    def parent_tags(self, child: str | Tag) -> list[Tag]:
        if child is None:
            return []
        if isinstance(child, str):
            return self.parent_tags(self.get(child))

        return list(dicttree_lineage(self.tags_tree, child.tag_parts[:-1]))


def populate_tagset(tagset_spec: JsonObject) -> Tagset:
    """
    Collect tags from tagset spec JSON object, validate the format along the way.

    :param tagset_spec: JSON object of tagset spec
    :return: Populated Tagset instance
    """

    def validate_and_collect(name: str, tag_def: JsonObject) -> Generator[Tag, None, None]:
        if not isinstance(tag_def, dict):
            raise ValueError(f"tag '{name}' definition is not a dict")

        if not is_blank(name):
            desc = tag_def.get("$desc")
            if isinstance(desc, dict):
                desc = RichDesc(**desc)

            yield Tag(name=name, desc=desc)

        for child_name, child_tag_def in tag_def.items():
            if child_name == "$desc":
                continue

            if not isinstance(child_name, str):
                raise ValueError(f"child '{child_name}' of tag '{name}' is not a string")
            try:
                validate_snake_case(child_name)
            except ValueError as e:
                raise ValueError(f"child '{child_name}' of tag '{name}' is not in snake case") from e

            child_name = name + ":" + child_name if name else child_name

            yield from validate_and_collect(child_name, child_tag_def)

    namespace = tagset_spec.get("$namespace")
    if namespace is None:
        raise ValueError("missing '$namespace' in tagset spec")
    try:
        validate_snake_case(namespace)
    except ValueError as e:
        raise ValueError(f"tagset namespace '{namespace}' is not in snake case") from e

    desc = tagset_spec.get("$desc")
    if desc is None:
        raise ValueError("missing '$desc' in tagset spec")
    if isinstance(desc, dict):
        desc = RichDesc(**desc)

    tags = tagset_spec.get("$tags")
    if tags is None:
        raise ValueError("missing '$tags' in tagset spec")

    tagset = Tagset(namespace=namespace, desc=desc)

    for tag in validate_and_collect("", tags):
        tagset.add(tag)

    return tagset


@singleton
def predefined_tagsets() -> dict[str, Tagset]:
    tagsets: dict[str, Tagset] = {}
    for _, tagset_spec in predefined_tagset_specs():
        tagset = populate_tagset(tagset_spec)
        tagsets[tagset.namespace] = tagset
    return tagsets


def render_tagset_markdown_readme(tagset: Tagset) -> str:
    def render_desc(desc: str | RichDesc | None) -> str:
        if desc is None:
            return ""
        if isinstance(desc, str):
            return desc
        if isinstance(desc, RichDesc):
            return desc.text
        raise ValueError(f"unsupported desc type '{type(desc)}'")

    template_str = textwrap.dedent(
        """
        # Tagset {{ tagset.namespace }}

        {{ tagset.desc | render_desc }}

        ## Contents

        {% for tag in tagset.tags %}
        - {{ tag.name }}
        {% endfor %}

        ## Tags

        {% for tag in tagset.tags %}
        ### {{ tag.name }}

        {{ tag.desc | render_desc }}

        {% endfor %}
        """
    )

    env = jinja2.Environment(trim_blocks=True, lstrip_blocks=True)
    env.filters["render_desc"] = render_desc

    return env.from_string(template_str).render(tagset=tagset)
