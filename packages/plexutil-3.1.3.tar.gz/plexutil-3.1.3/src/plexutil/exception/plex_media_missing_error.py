class PlexMediaMissingError(Exception):
    pass
