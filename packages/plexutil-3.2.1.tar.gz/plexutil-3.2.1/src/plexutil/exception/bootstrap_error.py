class BootstrapError(Exception):
    pass
