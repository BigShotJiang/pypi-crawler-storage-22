"""Plop Python SDK — receive and poll for emails in your tests and applications."""

from plop_sdk._client import AsyncPlop, Plop
from plop_sdk._errors import (
    PlopAuthError,
    PlopError,
    PlopForbiddenError,
    PlopNotFoundError,
    PlopTimeoutError,
)
from plop_sdk._resources.webhooks import verify_signature
from plop_sdk._types import (
    ApiKeyInfo,
    ApiKeyRotateResult,
    DeleteResult,
    ListMessagesResponse,
    Mailbox,
    MessageDetail,
    MessageHeader,
    MessageSummary,
    WebhookCreatedResponse,
    WebhookDelivery,
    WebhookEndpoint,
    WebhookToggleResult,
)

__all__ = [
    "ApiKeyInfo",
    "ApiKeyRotateResult",
    "AsyncPlop",
    "DeleteResult",
    "ListMessagesResponse",
    "Mailbox",
    "MessageDetail",
    "MessageHeader",
    "MessageSummary",
    "Plop",
    "PlopAuthError",
    "PlopError",
    "PlopForbiddenError",
    "PlopNotFoundError",
    "PlopTimeoutError",
    "WebhookCreatedResponse",
    "WebhookDelivery",
    "WebhookEndpoint",
    "WebhookToggleResult",
    "verify_signature",
]
