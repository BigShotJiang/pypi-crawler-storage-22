from __future__ import annotations

import os
from types import TracebackType

from plop_sdk._http import AsyncHTTP, SyncHTTP
from plop_sdk._resources.api_keys import ApiKeys, AsyncApiKeys
from plop_sdk._resources.mailboxes import AsyncMailboxes, Mailboxes
from plop_sdk._resources.messages import AsyncMessages, Messages
from plop_sdk._resources.webhooks import AsyncWebhooks, Webhooks

_DEFAULT_BASE_URL = "https://api.plop.email"
_DEFAULT_TIMEOUT = 30.0


def _resolve_api_key(api_key: str | None) -> str:
    if api_key is not None:
        return api_key
    env_key = os.environ.get("PLOP_API_KEY")
    if env_key:
        return env_key
    raise ValueError(
        "No API key provided. Pass api_key= or set "
        "the PLOP_API_KEY environment variable."
    )


class Plop:
    """Synchronous Plop client."""

    mailboxes: Mailboxes
    messages: Messages
    webhooks: Webhooks
    api_keys: ApiKeys

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        key = _resolve_api_key(api_key)
        url = base_url or os.environ.get("PLOP_BASE_URL") or _DEFAULT_BASE_URL
        self._http = SyncHTTP(base_url=url, api_key=key, timeout=timeout)
        self.mailboxes = Mailboxes(self._http)
        self.messages = Messages(self._http)
        self.webhooks = Webhooks(self._http)
        self.api_keys = ApiKeys(self._http)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._http.close()

    def __enter__(self) -> Plop:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self.close()


class AsyncPlop:
    """Asynchronous Plop client."""

    mailboxes: AsyncMailboxes
    messages: AsyncMessages
    webhooks: AsyncWebhooks
    api_keys: AsyncApiKeys

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        key = _resolve_api_key(api_key)
        url = base_url or os.environ.get("PLOP_BASE_URL") or _DEFAULT_BASE_URL
        self._http = AsyncHTTP(base_url=url, api_key=key, timeout=timeout)
        self.mailboxes = AsyncMailboxes(self._http)
        self.messages = AsyncMessages(self._http)
        self.webhooks = AsyncWebhooks(self._http)
        self.api_keys = AsyncApiKeys(self._http)

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.close()

    async def __aenter__(self) -> AsyncPlop:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.close()
