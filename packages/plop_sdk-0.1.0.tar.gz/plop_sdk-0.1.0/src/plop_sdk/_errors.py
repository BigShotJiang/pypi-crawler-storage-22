from __future__ import annotations


class PlopError(Exception):
    """Base exception for Plop SDK errors."""

    message: str
    status: int
    code: str | None
    details: dict[str, list[str]] | None

    def __init__(
        self,
        message: str,
        status: int = 0,
        code: str | None = None,
        details: dict[str, list[str]] | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status = status
        self.code = code
        self.details = details

    def __repr__(self) -> str:
        return f"{type(self).__name__}(message={self.message!r}, status={self.status})"


class PlopAuthError(PlopError):
    """Raised on 401 Unauthorized responses."""


class PlopForbiddenError(PlopError):
    """Raised on 403 Forbidden responses."""


class PlopNotFoundError(PlopError):
    """Raised on 404 Not Found responses."""


class PlopTimeoutError(PlopError):
    """Raised when wait_for exceeds its timeout."""

    def __init__(self, message: str = "Timed out waiting for email") -> None:
        super().__init__(message=message, status=0)
