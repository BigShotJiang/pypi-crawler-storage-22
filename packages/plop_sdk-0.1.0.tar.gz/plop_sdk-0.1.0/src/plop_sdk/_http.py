from __future__ import annotations

from typing import Any

import httpx

from plop_sdk._errors import (
    PlopAuthError,
    PlopError,
    PlopForbiddenError,
    PlopNotFoundError,
)

_ERROR_MAP: dict[int, type[PlopError]] = {
    401: PlopAuthError,
    403: PlopForbiddenError,
    404: PlopNotFoundError,
}


def _raise_for_status(response: httpx.Response) -> None:
    if response.status_code < 400:
        return

    try:
        body = response.json()
    except Exception:
        body = {}

    message = body.get("error", response.reason_phrase or "Unknown error")
    details = body.get("details")
    exc_cls = _ERROR_MAP.get(response.status_code, PlopError)
    raise exc_cls(
        message=message,
        status=response.status_code,
        details=details,
    )


class SyncHTTP:
    """Thin synchronous wrapper around httpx.Client."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        timeout: float,
    ) -> None:
        self._client = httpx.Client(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Accept": "application/json",
            },
            timeout=timeout,
        )

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        response = self._client.get(path, params=params)
        _raise_for_status(response)
        return response.json()

    def post(self, path: str, *, json: dict[str, Any] | None = None) -> httpx.Response:
        response = self._client.post(path, json=json)
        _raise_for_status(response)
        return response

    def patch(self, path: str, *, json: dict[str, Any] | None = None) -> httpx.Response:
        response = self._client.patch(path, json=json)
        _raise_for_status(response)
        return response

    def delete(self, path: str) -> httpx.Response:
        response = self._client.delete(path)
        _raise_for_status(response)
        return response

    def close(self) -> None:
        self._client.close()


class AsyncHTTP:
    """Thin asynchronous wrapper around httpx.AsyncClient."""

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        timeout: float,
    ) -> None:
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Accept": "application/json",
            },
            timeout=timeout,
        )

    async def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        response = await self._client.get(path, params=params)
        _raise_for_status(response)
        return response.json()

    async def post(
        self, path: str, *, json: dict[str, Any] | None = None
    ) -> httpx.Response:
        response = await self._client.post(path, json=json)
        _raise_for_status(response)
        return response

    async def patch(
        self, path: str, *, json: dict[str, Any] | None = None
    ) -> httpx.Response:
        response = await self._client.patch(path, json=json)
        _raise_for_status(response)
        return response

    async def delete(self, path: str) -> httpx.Response:
        response = await self._client.delete(path)
        _raise_for_status(response)
        return response

    async def close(self) -> None:
        await self._client.aclose()
