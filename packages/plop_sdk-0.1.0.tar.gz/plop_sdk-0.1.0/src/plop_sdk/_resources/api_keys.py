from __future__ import annotations

from plop_sdk._http import AsyncHTTP, SyncHTTP
from plop_sdk._types import ApiKeyRotateResult


class ApiKeys:
    """Synchronous API key operations."""

    def __init__(self, http: SyncHTTP) -> None:
        self._http = http

    def rotate(self) -> ApiKeyRotateResult:
        """Rotate the current API key."""
        resp = self._http.post("/v1/api-keys/rotate")
        return ApiKeyRotateResult.model_validate(resp.json()["data"])


class AsyncApiKeys:
    """Asynchronous API key operations."""

    def __init__(self, http: AsyncHTTP) -> None:
        self._http = http

    async def rotate(self) -> ApiKeyRotateResult:
        """Rotate the current API key."""
        resp = await self._http.post("/v1/api-keys/rotate")
        return ApiKeyRotateResult.model_validate(resp.json()["data"])
