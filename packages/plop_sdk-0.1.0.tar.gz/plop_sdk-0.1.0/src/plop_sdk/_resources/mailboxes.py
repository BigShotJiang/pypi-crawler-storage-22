from __future__ import annotations

from plop_sdk._http import AsyncHTTP, SyncHTTP
from plop_sdk._types import DeleteResult, Mailbox


class Mailboxes:
    """Synchronous mailbox operations."""

    def __init__(self, http: SyncHTTP) -> None:
        self._http = http

    def list(self, *, mailbox: str | None = None) -> list[Mailbox]:
        """List mailboxes, optionally filtered by local part or full address."""
        params: dict[str, str] = {}
        if mailbox is not None:
            params["mailbox"] = mailbox
        data = self._http.get("/v1/mailboxes", params=params or None)
        return [Mailbox.model_validate(item) for item in data["data"]]

    def create(self, *, name: str) -> Mailbox:
        """Create a new mailbox."""
        resp = self._http.post("/v1/mailboxes", json={"name": name})
        return Mailbox.model_validate(resp.json()["data"])

    def update(self, mailbox_id: str, *, name: str) -> Mailbox:
        """Update a mailbox."""
        resp = self._http.patch(f"/v1/mailboxes/{mailbox_id}", json={"name": name})
        return Mailbox.model_validate(resp.json()["data"])

    def delete(self, mailbox_id: str) -> DeleteResult:
        """Delete a mailbox."""
        resp = self._http.delete(f"/v1/mailboxes/{mailbox_id}")
        return DeleteResult.model_validate(resp.json()["data"])


class AsyncMailboxes:
    """Asynchronous mailbox operations."""

    def __init__(self, http: AsyncHTTP) -> None:
        self._http = http

    async def list(self, *, mailbox: str | None = None) -> list[Mailbox]:
        """List mailboxes, optionally filtered by local part or full address."""
        params: dict[str, str] = {}
        if mailbox is not None:
            params["mailbox"] = mailbox
        data = await self._http.get("/v1/mailboxes", params=params or None)
        return [Mailbox.model_validate(item) for item in data["data"]]

    async def create(self, *, name: str) -> Mailbox:
        """Create a new mailbox."""
        resp = await self._http.post("/v1/mailboxes", json={"name": name})
        return Mailbox.model_validate(resp.json()["data"])

    async def update(self, mailbox_id: str, *, name: str) -> Mailbox:
        """Update a mailbox."""
        resp = await self._http.patch(
            f"/v1/mailboxes/{mailbox_id}", json={"name": name}
        )
        return Mailbox.model_validate(resp.json()["data"])

    async def delete(self, mailbox_id: str) -> DeleteResult:
        """Delete a mailbox."""
        resp = await self._http.delete(f"/v1/mailboxes/{mailbox_id}")
        return DeleteResult.model_validate(resp.json()["data"])
