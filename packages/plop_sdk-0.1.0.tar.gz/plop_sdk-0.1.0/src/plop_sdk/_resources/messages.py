from __future__ import annotations

import asyncio
import json as json_mod
import time
from collections.abc import AsyncIterator, Iterator
from typing import Any

from plop_sdk._errors import PlopNotFoundError, PlopTimeoutError
from plop_sdk._http import AsyncHTTP, SyncHTTP, _raise_for_status
from plop_sdk._types import DeleteResult, ListMessagesResponse, MessageDetail, MessageSummary


def _build_params(**kwargs: Any) -> dict[str, Any] | None:
    """Build a query-param dict, dropping None values and renaming from_ to from."""
    params = {
        ("from" if k == "from_" else k): v
        for k, v in kwargs.items()
        if v is not None
    }
    return params or None


class Messages:
    """Synchronous message operations."""

    def __init__(self, http: SyncHTTP) -> None:
        self._http = http

    def list(
        self,
        *,
        mailbox: str | None = None,
        tag: str | None = None,
        tags: str | None = None,
        q: str | None = None,
        limit: int | None = None,
        start: str | None = None,
        end: str | None = None,
        since: str | None = None,
        to: str | None = None,
        from_: str | None = None,
        subject: str | None = None,
        after_id: str | None = None,
    ) -> ListMessagesResponse:
        """List messages with optional filters."""
        params = _build_params(
            mailbox=mailbox,
            tag=tag,
            tags=tags,
            q=q,
            limit=limit,
            start=start,
            end=end,
            since=since,
            to=to,
            from_=from_,
            subject=subject,
            after_id=after_id,
        )
        data = self._http.get("/v1/messages", params=params)
        return ListMessagesResponse.model_validate(data)

    def get(self, message_id: str) -> MessageDetail:
        """Get a message by ID."""
        data = self._http.get(f"/v1/messages/{message_id}")
        return MessageDetail.model_validate(data["data"])

    def latest(
        self,
        *,
        mailbox: str | None = None,
        tag: str | None = None,
        tags: str | None = None,
        q: str | None = None,
        start: str | None = None,
        end: str | None = None,
        since: str | None = None,
        to: str | None = None,
        from_: str | None = None,
        subject: str | None = None,
    ) -> MessageDetail:
        """Get the latest message matching the given filters."""
        params = _build_params(
            mailbox=mailbox,
            tag=tag,
            tags=tags,
            q=q,
            start=start,
            end=end,
            since=since,
            to=to,
            from_=from_,
            subject=subject,
        )
        data = self._http.get("/v1/messages/latest", params=params)
        return MessageDetail.model_validate(data["data"])

    def wait_for(
        self,
        *,
        mailbox: str | None = None,
        tag: str | None = None,
        tags: str | None = None,
        q: str | None = None,
        start: str | None = None,
        end: str | None = None,
        since: str | None = None,
        to: str | None = None,
        from_: str | None = None,
        subject: str | None = None,
        timeout: float = 30,
        interval: float = 1.0,
    ) -> MessageDetail:
        """Poll for the latest message until found or timeout.

        Polls GET /v1/messages/latest repeatedly, ignoring 404 responses,
        until a matching message appears or the timeout is exceeded.

        Raises PlopTimeoutError if no message is found within the timeout.
        """
        deadline = time.monotonic() + timeout
        params = _build_params(
            mailbox=mailbox,
            tag=tag,
            tags=tags,
            q=q,
            start=start,
            end=end,
            since=since,
            to=to,
            from_=from_,
            subject=subject,
        )
        while True:
            try:
                data = self._http.get("/v1/messages/latest", params=params)
                return MessageDetail.model_validate(data["data"])
            except PlopNotFoundError:
                if time.monotonic() >= deadline:
                    raise PlopTimeoutError()
                time.sleep(min(interval, max(0, deadline - time.monotonic())))

    def delete(self, message_id: str) -> DeleteResult:
        """Delete a message."""
        resp = self._http.delete(f"/v1/messages/{message_id}")
        return DeleteResult.model_validate(resp.json()["data"])

    def stream(
        self,
        *,
        mailbox: str | None = None,
        tag: str | None = None,
        since: str | None = None,
    ) -> Iterator[MessageSummary]:
        """Stream messages via SSE. Yields MessageSummary for each message.received event."""
        params = _build_params(mailbox=mailbox, tag=tag, since=since)
        with self._http._client.stream(
            "GET", "/v1/messages/stream", params=params
        ) as resp:
            _raise_for_status(resp)
            event_type: str | None = None
            for line in resp.iter_lines():
                if line.startswith("event: "):
                    event_type = line[7:]
                elif line.startswith("data: ") and event_type == "message.received":
                    data = json_mod.loads(line[6:])
                    yield MessageSummary.model_validate(data)
                    event_type = None
                elif line == "":
                    event_type = None


class AsyncMessages:
    """Asynchronous message operations."""

    def __init__(self, http: AsyncHTTP) -> None:
        self._http = http

    async def list(
        self,
        *,
        mailbox: str | None = None,
        tag: str | None = None,
        tags: str | None = None,
        q: str | None = None,
        limit: int | None = None,
        start: str | None = None,
        end: str | None = None,
        since: str | None = None,
        to: str | None = None,
        from_: str | None = None,
        subject: str | None = None,
        after_id: str | None = None,
    ) -> ListMessagesResponse:
        """List messages with optional filters."""
        params = _build_params(
            mailbox=mailbox,
            tag=tag,
            tags=tags,
            q=q,
            limit=limit,
            start=start,
            end=end,
            since=since,
            to=to,
            from_=from_,
            subject=subject,
            after_id=after_id,
        )
        data = await self._http.get("/v1/messages", params=params)
        return ListMessagesResponse.model_validate(data)

    async def get(self, message_id: str) -> MessageDetail:
        """Get a message by ID."""
        data = await self._http.get(f"/v1/messages/{message_id}")
        return MessageDetail.model_validate(data["data"])

    async def latest(
        self,
        *,
        mailbox: str | None = None,
        tag: str | None = None,
        tags: str | None = None,
        q: str | None = None,
        start: str | None = None,
        end: str | None = None,
        since: str | None = None,
        to: str | None = None,
        from_: str | None = None,
        subject: str | None = None,
    ) -> MessageDetail:
        """Get the latest message matching the given filters."""
        params = _build_params(
            mailbox=mailbox,
            tag=tag,
            tags=tags,
            q=q,
            start=start,
            end=end,
            since=since,
            to=to,
            from_=from_,
            subject=subject,
        )
        data = await self._http.get("/v1/messages/latest", params=params)
        return MessageDetail.model_validate(data["data"])

    async def wait_for(
        self,
        *,
        mailbox: str | None = None,
        tag: str | None = None,
        tags: str | None = None,
        q: str | None = None,
        start: str | None = None,
        end: str | None = None,
        since: str | None = None,
        to: str | None = None,
        from_: str | None = None,
        subject: str | None = None,
        timeout: float = 30,
        interval: float = 1.0,
    ) -> MessageDetail:
        """Poll for the latest message until found or timeout.

        Polls GET /v1/messages/latest repeatedly, ignoring 404 responses,
        until a matching message appears or the timeout is exceeded.

        Raises PlopTimeoutError if no message is found within the timeout.
        """
        deadline = asyncio.get_running_loop().time() + timeout
        params = _build_params(
            mailbox=mailbox,
            tag=tag,
            tags=tags,
            q=q,
            start=start,
            end=end,
            since=since,
            to=to,
            from_=from_,
            subject=subject,
        )
        while True:
            try:
                data = await self._http.get("/v1/messages/latest", params=params)
                return MessageDetail.model_validate(data["data"])
            except PlopNotFoundError:
                remaining = deadline - asyncio.get_running_loop().time()
                if remaining <= 0:
                    raise PlopTimeoutError()
                await asyncio.sleep(min(interval, remaining))

    async def delete(self, message_id: str) -> DeleteResult:
        """Delete a message."""
        resp = await self._http.delete(f"/v1/messages/{message_id}")
        return DeleteResult.model_validate(resp.json()["data"])

    async def stream(
        self,
        *,
        mailbox: str | None = None,
        tag: str | None = None,
        since: str | None = None,
    ) -> AsyncIterator[MessageSummary]:
        """Stream messages via SSE. Yields MessageSummary for each message.received event."""
        params = _build_params(mailbox=mailbox, tag=tag, since=since)
        async with self._http._client.stream(
            "GET", "/v1/messages/stream", params=params
        ) as resp:
            _raise_for_status(resp)
            event_type: str | None = None
            async for line in resp.aiter_lines():
                if line.startswith("event: "):
                    event_type = line[7:]
                elif line.startswith("data: ") and event_type == "message.received":
                    data = json_mod.loads(line[6:])
                    yield MessageSummary.model_validate(data)
                    event_type = None
                elif line == "":
                    event_type = None
