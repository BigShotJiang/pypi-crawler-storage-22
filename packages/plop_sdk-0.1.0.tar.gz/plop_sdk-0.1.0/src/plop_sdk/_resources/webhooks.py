from __future__ import annotations

import hashlib
import hmac
import time
from typing import Any

from plop_sdk._http import AsyncHTTP, SyncHTTP
from plop_sdk._types import (
    DeleteResult,
    WebhookCreatedResponse,
    WebhookDelivery,
    WebhookEndpoint,
    WebhookToggleResult,
)


def verify_signature(
    *,
    secret: str,
    signature: str,
    body: str | bytes,
    tolerance: int = 300,
) -> bool:
    """Verify a webhook signature.

    Args:
        secret: The webhook signing secret (e.g. "whsec_...").
        signature: The X-Plop-Signature header value.
            Format: "t={timestamp},v1={hex_digest}"
        body: The raw request body (str or bytes).
        tolerance: Maximum age of the signature in seconds (default 300).

    Returns:
        True if the signature is valid and within tolerance.
    """
    try:
        parts = dict(part.split("=", 1) for part in signature.split(","))
    except ValueError:
        return False

    timestamp_str = parts.get("t")
    v1 = parts.get("v1")
    if timestamp_str is None or v1 is None:
        return False

    try:
        timestamp = int(timestamp_str)
    except ValueError:
        return False

    if abs(time.time() - timestamp) > tolerance:
        return False

    raw_body = body.encode("utf-8") if isinstance(body, str) else body

    expected = hmac.new(
        secret.encode("utf-8"),
        f"{timestamp}.".encode() + raw_body,
        hashlib.sha256,
    ).hexdigest()

    return hmac.compare_digest(expected, v1)


def _build_delivery_params(
    *, limit: int | None = None, offset: int | None = None
) -> dict[str, Any] | None:
    params: dict[str, Any] = {}
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    return params or None


class Webhooks:
    """Synchronous webhook operations and signature verification."""

    def __init__(self, http: SyncHTTP) -> None:
        self._http = http

    def list(self) -> list[WebhookEndpoint]:
        """List all webhook endpoints."""
        data = self._http.get("/v1/webhooks")
        return [WebhookEndpoint.model_validate(item) for item in data["data"]]

    def create(
        self,
        *,
        url: str,
        description: str | None = None,
    ) -> WebhookCreatedResponse:
        """Create a new webhook endpoint."""
        body: dict[str, Any] = {"url": url}
        if description is not None:
            body["description"] = description
        resp = self._http.post("/v1/webhooks", json=body)
        return WebhookCreatedResponse.model_validate(resp.json()["data"])

    def delete(self, webhook_id: str) -> DeleteResult:
        """Delete a webhook endpoint."""
        resp = self._http.delete(f"/v1/webhooks/{webhook_id}")
        return DeleteResult.model_validate(resp.json()["data"])

    def toggle(self, webhook_id: str, *, active: bool) -> WebhookToggleResult:
        """Enable or disable a webhook endpoint."""
        resp = self._http.patch(
            f"/v1/webhooks/{webhook_id}", json={"active": active}
        )
        return WebhookToggleResult.model_validate(resp.json()["data"])

    def deliveries(
        self,
        webhook_id: str,
        *,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[WebhookDelivery]:
        """List deliveries for a webhook endpoint."""
        params = _build_delivery_params(limit=limit, offset=offset)
        data = self._http.get(
            f"/v1/webhooks/{webhook_id}/deliveries", params=params
        )
        return [WebhookDelivery.model_validate(item) for item in data["data"]]

    def verify(
        self,
        *,
        secret: str,
        signature: str,
        body: str | bytes,
        tolerance: int = 300,
    ) -> bool:
        """Verify a webhook signature. Delegates to module-level verify_signature()."""
        return verify_signature(
            secret=secret, signature=signature, body=body, tolerance=tolerance
        )


class AsyncWebhooks:
    """Asynchronous webhook operations and signature verification."""

    def __init__(self, http: AsyncHTTP) -> None:
        self._http = http

    async def list(self) -> list[WebhookEndpoint]:
        """List all webhook endpoints."""
        data = await self._http.get("/v1/webhooks")
        return [WebhookEndpoint.model_validate(item) for item in data["data"]]

    async def create(
        self,
        *,
        url: str,
        description: str | None = None,
    ) -> WebhookCreatedResponse:
        """Create a new webhook endpoint."""
        body: dict[str, Any] = {"url": url}
        if description is not None:
            body["description"] = description
        resp = await self._http.post("/v1/webhooks", json=body)
        return WebhookCreatedResponse.model_validate(resp.json()["data"])

    async def delete(self, webhook_id: str) -> DeleteResult:
        """Delete a webhook endpoint."""
        resp = await self._http.delete(f"/v1/webhooks/{webhook_id}")
        return DeleteResult.model_validate(resp.json()["data"])

    async def toggle(self, webhook_id: str, *, active: bool) -> WebhookToggleResult:
        """Enable or disable a webhook endpoint."""
        resp = await self._http.patch(
            f"/v1/webhooks/{webhook_id}", json={"active": active}
        )
        return WebhookToggleResult.model_validate(resp.json()["data"])

    async def deliveries(
        self,
        webhook_id: str,
        *,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[WebhookDelivery]:
        """List deliveries for a webhook endpoint."""
        params = _build_delivery_params(limit=limit, offset=offset)
        data = await self._http.get(
            f"/v1/webhooks/{webhook_id}/deliveries", params=params
        )
        return [WebhookDelivery.model_validate(item) for item in data["data"]]

    def verify(
        self,
        *,
        secret: str,
        signature: str,
        body: str | bytes,
        tolerance: int = 300,
    ) -> bool:
        """Verify a webhook signature (synchronous, no I/O needed)."""
        return verify_signature(
            secret=secret, signature=signature, body=body, tolerance=tolerance
        )
