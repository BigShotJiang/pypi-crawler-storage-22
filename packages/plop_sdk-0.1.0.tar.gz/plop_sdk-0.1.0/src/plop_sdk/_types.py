from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


def _to_camel(name: str) -> str:
    parts = name.split("_")
    return parts[0] + "".join(word.capitalize() for word in parts[1:])


class _Base(BaseModel):
    model_config = ConfigDict(
        populate_by_name=True,
        alias_generator=_to_camel,
    )


class Mailbox(_Base):
    id: str
    name: str
    domain: str | None = None
    created_at: datetime
    updated_at: datetime
    address: str


class MessageHeader(_Base):
    name: str
    value: str


class MessageSummary(_Base):
    id: str
    mailbox_id: str
    mailbox: str
    mailbox_with_tag: str
    tag: str | None = None
    from_address: str = Field(alias="from")
    to: str
    subject: str | None = None
    received_at: datetime


class MessageDetail(MessageSummary):
    headers: list[MessageHeader] = []
    html_content: str | None = None
    text_content: str | None = None
    domain: str = ""
    tenant_subdomain: str | None = None


class ListMessagesResponse(_Base):
    data: list[MessageSummary]
    has_more: bool


class DeleteResult(_Base):
    id: str


class WebhookEndpoint(_Base):
    id: str
    url: str
    description: str | None = None
    secret_masked: str
    events: list[str]
    active: bool
    created_at: datetime
    updated_at: datetime


class WebhookDelivery(_Base):
    id: str
    event: str
    message_id: str | None = None
    status: str
    http_status: int | None = None
    response_body: str | None = None
    latency_ms: int | None = None
    attempt: int
    error: str | None = None
    created_at: datetime


class WebhookCreatedResponse(_Base):
    endpoint: WebhookEndpoint
    secret: str


class WebhookToggleResult(_Base):
    id: str
    active: bool


class ApiKeyInfo(_Base):
    id: str
    name: str
    key_masked: str
    scopes: list[str]
    mailbox_name: str | None = None
    expires_at: datetime | None = None


class ApiKeyRotateResult(_Base):
    key: str
    api_key: ApiKeyInfo
