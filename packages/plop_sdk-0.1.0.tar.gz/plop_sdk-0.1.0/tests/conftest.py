from __future__ import annotations

import pytest
import respx

from plop_sdk import AsyncPlop, Plop

API_KEY = "plop_" + "a1" * 32
BASE_URL = "https://api.plop.email"

MAILBOX_JSON = {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "name": "qa",
    "domain": "in.plop.email",
    "createdAt": "2025-01-01T00:00:00Z",
    "updatedAt": "2025-01-01T00:00:00Z",
    "address": "qa@in.plop.email",
}

MESSAGE_SUMMARY_JSON = {
    "id": "660e8400-e29b-41d4-a716-446655440001",
    "mailboxId": "550e8400-e29b-41d4-a716-446655440000",
    "mailbox": "qa",
    "mailboxWithTag": "qa+login",
    "tag": "login",
    "from": "sender@example.com",
    "to": "qa+login@in.plop.email",
    "subject": "Verify your email",
    "receivedAt": "2025-06-15T10:30:00Z",
}

MESSAGE_DETAIL_JSON = {
    **MESSAGE_SUMMARY_JSON,
    "headers": [{"name": "Content-Type", "value": "text/html"}],
    "htmlContent": "<p>Your code is 123456</p>",
    "textContent": "Your code is 123456",
    "domain": "in.plop.email",
    "tenantSubdomain": None,
}

WEBHOOK_ENDPOINT_JSON = {
    "id": "wh_001",
    "url": "https://example.com/hook",
    "description": "Test webhook",
    "secretMasked": "whsec_****abcd",
    "events": ["message.received"],
    "active": True,
    "createdAt": "2025-01-01T00:00:00Z",
    "updatedAt": "2025-01-01T00:00:00Z",
}

WEBHOOK_DELIVERY_JSON = {
    "id": "del_001",
    "event": "message.received",
    "messageId": "660e8400-e29b-41d4-a716-446655440001",
    "status": "success",
    "httpStatus": 200,
    "responseBody": "OK",
    "latencyMs": 42,
    "attempt": 1,
    "error": None,
    "createdAt": "2025-06-15T10:31:00Z",
}

API_KEY_INFO_JSON = {
    "id": "key_001",
    "name": "My Key",
    "keyMasked": "plop_****abcd",
    "scopes": ["messages:read", "messages:write"],
    "mailboxName": None,
    "expiresAt": None,
}


@pytest.fixture()
def sync_client():
    client = Plop(api_key=API_KEY, base_url=BASE_URL)
    yield client
    client.close()


@pytest.fixture()
async def async_client():
    client = AsyncPlop(api_key=API_KEY, base_url=BASE_URL)
    yield client
    await client.close()


@pytest.fixture()
def mock_api():
    with respx.mock(base_url=BASE_URL) as mock:
        yield mock
