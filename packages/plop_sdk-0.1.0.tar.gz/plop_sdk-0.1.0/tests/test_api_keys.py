from __future__ import annotations

import httpx
import respx

from plop_sdk import AsyncPlop, Plop
from tests.conftest import API_KEY_INFO_JSON


class TestApiKeys:
    def test_rotate(self, sync_client: Plop, mock_api: respx.Router):
        mock_api.post("/v1/api-keys/rotate").mock(
            return_value=httpx.Response(
                200,
                json={
                    "data": {
                        "key": "plop_new_full_key",
                        "apiKey": API_KEY_INFO_JSON,
                    }
                },
            )
        )
        result = sync_client.api_keys.rotate()
        assert result.key == "plop_new_full_key"
        assert result.api_key.id == "key_001"
        assert result.api_key.name == "My Key"
        assert result.api_key.scopes == ["messages:read", "messages:write"]

    async def test_async_rotate(
        self, async_client: AsyncPlop, mock_api: respx.Router
    ):
        mock_api.post("/v1/api-keys/rotate").mock(
            return_value=httpx.Response(
                200,
                json={
                    "data": {
                        "key": "plop_new_full_key",
                        "apiKey": API_KEY_INFO_JSON,
                    }
                },
            )
        )
        result = await async_client.api_keys.rotate()
        assert result.key == "plop_new_full_key"
        assert result.api_key.id == "key_001"
