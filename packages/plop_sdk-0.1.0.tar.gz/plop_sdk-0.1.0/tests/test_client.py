from __future__ import annotations

import httpx
import pytest
import respx

from plop_sdk import (
    AsyncPlop,
    Plop,
    PlopAuthError,
    PlopError,
    PlopForbiddenError,
    PlopNotFoundError,
)
from tests.conftest import API_KEY, BASE_URL, MAILBOX_JSON


class TestClientInit:
    def test_api_key_from_arg(self):
        client = Plop(api_key=API_KEY, base_url=BASE_URL)
        client.close()

    def test_api_key_from_env(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("PLOP_API_KEY", API_KEY)
        client = Plop(base_url=BASE_URL)
        client.close()

    def test_missing_api_key_raises(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.delenv("PLOP_API_KEY", raising=False)
        with pytest.raises(ValueError, match="No API key"):
            Plop()

    def test_base_url_from_env(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("PLOP_BASE_URL", "https://custom.api.example.com")
        client = Plop(api_key=API_KEY)
        assert client._http._client.base_url == httpx.URL(
            "https://custom.api.example.com"
        )
        client.close()

    def test_context_manager(self):
        with Plop(api_key=API_KEY, base_url=BASE_URL) as client:
            assert client.mailboxes is not None

    async def test_async_context_manager(self):
        async with AsyncPlop(api_key=API_KEY, base_url=BASE_URL) as client:
            assert client.mailboxes is not None


class TestErrorHandling:
    def test_401_raises_auth_error(self, sync_client: Plop, mock_api: respx.Router):
        mock_api.get("/v1/mailboxes").mock(
            return_value=httpx.Response(401, json={"error": "Invalid API key"})
        )
        with pytest.raises(PlopAuthError, match="Invalid API key") as exc_info:
            sync_client.mailboxes.list()
        assert exc_info.value.status == 401

    def test_403_raises_forbidden_error(
        self, sync_client: Plop, mock_api: respx.Router
    ):
        mock_api.get("/v1/mailboxes").mock(
            return_value=httpx.Response(403, json={"error": "Access denied"})
        )
        with pytest.raises(PlopForbiddenError, match="Access denied"):
            sync_client.mailboxes.list()

    def test_404_raises_not_found_error(
        self, sync_client: Plop, mock_api: respx.Router
    ):
        mock_api.get("/v1/messages/bad-id").mock(
            return_value=httpx.Response(404, json={"error": "Not found"})
        )
        with pytest.raises(PlopNotFoundError, match="Not found"):
            sync_client.messages.get("bad-id")

    def test_400_raises_plop_error_with_details(
        self, sync_client: Plop, mock_api: respx.Router
    ):
        mock_api.get("/v1/messages").mock(
            return_value=httpx.Response(
                400,
                json={
                    "error": "Bad input",
                    "details": {"limit": ["must be between 1 and 200"]},
                },
            )
        )
        with pytest.raises(PlopError) as exc_info:
            sync_client.messages.list(limit=999)
        assert exc_info.value.details == {"limit": ["must be between 1 and 200"]}


class TestMailboxes:
    def test_list_all(self, sync_client: Plop, mock_api: respx.Router):
        mock_api.get("/v1/mailboxes").mock(
            return_value=httpx.Response(200, json={"data": [MAILBOX_JSON]})
        )
        mailboxes = sync_client.mailboxes.list()
        assert len(mailboxes) == 1
        assert mailboxes[0].name == "qa"
        assert mailboxes[0].address == "qa@in.plop.email"

    def test_list_filtered(self, sync_client: Plop, mock_api: respx.Router):
        route = mock_api.get("/v1/mailboxes").mock(
            return_value=httpx.Response(200, json={"data": [MAILBOX_JSON]})
        )
        sync_client.mailboxes.list(mailbox="qa")
        assert route.calls[0].request.url.params["mailbox"] == "qa"

    async def test_async_list(self, async_client: AsyncPlop, mock_api: respx.Router):
        mock_api.get("/v1/mailboxes").mock(
            return_value=httpx.Response(200, json={"data": [MAILBOX_JSON]})
        )
        mailboxes = await async_client.mailboxes.list()
        assert len(mailboxes) == 1
        assert mailboxes[0].name == "qa"

    def test_create(self, sync_client: Plop, mock_api: respx.Router):
        mock_api.post("/v1/mailboxes").mock(
            return_value=httpx.Response(200, json={"data": MAILBOX_JSON})
        )
        mailbox = sync_client.mailboxes.create(name="qa")
        assert mailbox.name == "qa"

    def test_update(self, sync_client: Plop, mock_api: respx.Router):
        mid = MAILBOX_JSON["id"]
        updated = {**MAILBOX_JSON, "name": "renamed"}
        mock_api.patch(f"/v1/mailboxes/{mid}").mock(
            return_value=httpx.Response(200, json={"data": updated})
        )
        mailbox = sync_client.mailboxes.update(mid, name="renamed")
        assert mailbox.name == "renamed"

    def test_delete(self, sync_client: Plop, mock_api: respx.Router):
        mid = MAILBOX_JSON["id"]
        mock_api.delete(f"/v1/mailboxes/{mid}").mock(
            return_value=httpx.Response(200, json={"data": {"id": mid}})
        )
        result = sync_client.mailboxes.delete(mid)
        assert result.id == mid

    async def test_async_create(
        self, async_client: AsyncPlop, mock_api: respx.Router
    ):
        mock_api.post("/v1/mailboxes").mock(
            return_value=httpx.Response(200, json={"data": MAILBOX_JSON})
        )
        mailbox = await async_client.mailboxes.create(name="qa")
        assert mailbox.name == "qa"

    async def test_async_update(
        self, async_client: AsyncPlop, mock_api: respx.Router
    ):
        mid = MAILBOX_JSON["id"]
        updated = {**MAILBOX_JSON, "name": "renamed"}
        mock_api.patch(f"/v1/mailboxes/{mid}").mock(
            return_value=httpx.Response(200, json={"data": updated})
        )
        mailbox = await async_client.mailboxes.update(mid, name="renamed")
        assert mailbox.name == "renamed"

    async def test_async_delete(
        self, async_client: AsyncPlop, mock_api: respx.Router
    ):
        mid = MAILBOX_JSON["id"]
        mock_api.delete(f"/v1/mailboxes/{mid}").mock(
            return_value=httpx.Response(200, json={"data": {"id": mid}})
        )
        result = await async_client.mailboxes.delete(mid)
        assert result.id == mid
