from __future__ import annotations

from unittest.mock import patch

import httpx
import pytest
import respx

from plop_sdk import AsyncPlop, Plop, PlopNotFoundError, PlopTimeoutError
from tests.conftest import (
    MESSAGE_DETAIL_JSON,
    MESSAGE_SUMMARY_JSON,
)


class TestMessagesList:
    def test_list_messages(self, sync_client: Plop, mock_api: respx.Router):
        mock_api.get("/v1/messages").mock(
            return_value=httpx.Response(
                200,
                json={"data": [MESSAGE_SUMMARY_JSON], "hasMore": False},
            )
        )
        result = sync_client.messages.list(mailbox="qa")
        assert len(result.data) == 1
        assert result.has_more is False
        msg = result.data[0]
        assert msg.mailbox == "qa"
        assert msg.tag == "login"
        assert msg.from_address == "sender@example.com"
        assert msg.subject == "Verify your email"

    def test_list_has_more(self, sync_client: Plop, mock_api: respx.Router):
        mock_api.get("/v1/messages").mock(
            return_value=httpx.Response(
                200,
                json={"data": [MESSAGE_SUMMARY_JSON], "hasMore": True},
            )
        )
        result = sync_client.messages.list(limit=1)
        assert result.has_more is True

    def test_list_passes_params(self, sync_client: Plop, mock_api: respx.Router):
        route = mock_api.get("/v1/messages").mock(
            return_value=httpx.Response(
                200, json={"data": [], "hasMore": False}
            )
        )
        sync_client.messages.list(
            mailbox="qa", tag="otp", limit=10, from_="user@example.com"
        )
        params = route.calls[0].request.url.params
        assert params["mailbox"] == "qa"
        assert params["tag"] == "otp"
        assert params["limit"] == "10"
        assert params["from"] == "user@example.com"

    def test_list_after_id(self, sync_client: Plop, mock_api: respx.Router):
        route = mock_api.get("/v1/messages").mock(
            return_value=httpx.Response(
                200, json={"data": [], "hasMore": False}
            )
        )
        sync_client.messages.list(after_id="msg_123")
        params = route.calls[0].request.url.params
        assert params["after_id"] == "msg_123"

    async def test_async_list(self, async_client: AsyncPlop, mock_api: respx.Router):
        mock_api.get("/v1/messages").mock(
            return_value=httpx.Response(
                200,
                json={"data": [MESSAGE_SUMMARY_JSON], "hasMore": False},
            )
        )
        result = await async_client.messages.list()
        assert len(result.data) == 1
        assert result.has_more is False


class TestMessagesGet:
    def test_get_message(self, sync_client: Plop, mock_api: respx.Router):
        mid = MESSAGE_DETAIL_JSON["id"]
        mock_api.get(f"/v1/messages/{mid}").mock(
            return_value=httpx.Response(200, json={"data": MESSAGE_DETAIL_JSON})
        )
        message = sync_client.messages.get(mid)
        assert message.id == mid
        assert message.html_content == "<p>Your code is 123456</p>"
        assert message.text_content == "Your code is 123456"
        assert len(message.headers) == 1
        assert message.headers[0].name == "Content-Type"

    def test_get_not_found(self, sync_client: Plop, mock_api: respx.Router):
        mock_api.get("/v1/messages/nonexistent").mock(
            return_value=httpx.Response(404, json={"error": "Not found"})
        )
        with pytest.raises(PlopNotFoundError):
            sync_client.messages.get("nonexistent")

    async def test_async_get(self, async_client: AsyncPlop, mock_api: respx.Router):
        mid = MESSAGE_DETAIL_JSON["id"]
        mock_api.get(f"/v1/messages/{mid}").mock(
            return_value=httpx.Response(200, json={"data": MESSAGE_DETAIL_JSON})
        )
        message = await async_client.messages.get(mid)
        assert message.id == mid


class TestMessagesLatest:
    def test_latest(self, sync_client: Plop, mock_api: respx.Router):
        mock_api.get("/v1/messages/latest").mock(
            return_value=httpx.Response(200, json={"data": MESSAGE_DETAIL_JSON})
        )
        message = sync_client.messages.latest(mailbox="qa")
        assert message.mailbox == "qa"
        assert message.html_content is not None

    def test_latest_not_found(self, sync_client: Plop, mock_api: respx.Router):
        mock_api.get("/v1/messages/latest").mock(
            return_value=httpx.Response(404, json={"error": "No messages found"})
        )
        with pytest.raises(PlopNotFoundError):
            sync_client.messages.latest()


class TestMessagesDelete:
    def test_delete(self, sync_client: Plop, mock_api: respx.Router):
        mid = MESSAGE_DETAIL_JSON["id"]
        mock_api.delete(f"/v1/messages/{mid}").mock(
            return_value=httpx.Response(200, json={"data": {"id": mid}})
        )
        result = sync_client.messages.delete(mid)
        assert result.id == mid

    async def test_async_delete(
        self, async_client: AsyncPlop, mock_api: respx.Router
    ):
        mid = MESSAGE_DETAIL_JSON["id"]
        mock_api.delete(f"/v1/messages/{mid}").mock(
            return_value=httpx.Response(200, json={"data": {"id": mid}})
        )
        result = await async_client.messages.delete(mid)
        assert result.id == mid


class TestWaitFor:
    def test_wait_for_immediate(self, sync_client: Plop, mock_api: respx.Router):
        """Message found on the first poll."""
        mock_api.get("/v1/messages/latest").mock(
            return_value=httpx.Response(200, json={"data": MESSAGE_DETAIL_JSON})
        )
        message = sync_client.messages.wait_for(mailbox="qa", tag="login", timeout=5)
        assert message.id == MESSAGE_DETAIL_JSON["id"]

    def test_wait_for_after_retries(self, sync_client: Plop, mock_api: respx.Router):
        """Message appears after 2 failed polls."""
        responses = [
            httpx.Response(404, json={"error": "No messages found"}),
            httpx.Response(404, json={"error": "No messages found"}),
            httpx.Response(200, json={"data": MESSAGE_DETAIL_JSON}),
        ]
        mock_api.get("/v1/messages/latest").mock(side_effect=responses)

        with patch("plop_sdk._resources.messages.time.sleep"):
            message = sync_client.messages.wait_for(
                mailbox="qa", tag="login", timeout=10, interval=0.01
            )
        assert message.id == MESSAGE_DETAIL_JSON["id"]

    def test_wait_for_timeout(self, sync_client: Plop, mock_api: respx.Router):
        """Times out when no message appears."""
        mock_api.get("/v1/messages/latest").mock(
            return_value=httpx.Response(404, json={"error": "No messages found"})
        )
        # monotonic calls: deadline=0+30=30, check>=30? no (0), sleep min calc (0),
        #                   check>=30? yes (31) -> timeout
        with patch("plop_sdk._resources.messages.time.sleep"):
            with patch(
                "plop_sdk._resources.messages.time.monotonic",
                side_effect=[0, 0, 0, 31],
            ):
                with pytest.raises(PlopTimeoutError):
                    sync_client.messages.wait_for(mailbox="qa", timeout=30, interval=1)

    async def test_async_wait_for_immediate(
        self, async_client: AsyncPlop, mock_api: respx.Router
    ):
        mock_api.get("/v1/messages/latest").mock(
            return_value=httpx.Response(200, json={"data": MESSAGE_DETAIL_JSON})
        )
        message = await async_client.messages.wait_for(
            mailbox="qa", tag="login", timeout=5
        )
        assert message.id == MESSAGE_DETAIL_JSON["id"]

    async def test_async_wait_for_after_retries(
        self, async_client: AsyncPlop, mock_api: respx.Router
    ):
        responses = [
            httpx.Response(404, json={"error": "No messages found"}),
            httpx.Response(200, json={"data": MESSAGE_DETAIL_JSON}),
        ]
        mock_api.get("/v1/messages/latest").mock(side_effect=responses)

        import asyncio

        original_sleep = asyncio.sleep

        async def fast_sleep(seconds: float) -> None:
            await original_sleep(0)

        with patch(
            "plop_sdk._resources.messages.asyncio.sleep",
            side_effect=fast_sleep,
        ):
            message = await async_client.messages.wait_for(
                mailbox="qa", timeout=10, interval=0.01
            )
        assert message.id == MESSAGE_DETAIL_JSON["id"]
