from __future__ import annotations

import hashlib
import hmac
import time

import httpx
import respx

from plop_sdk import AsyncPlop, Plop, verify_signature
from tests.conftest import (
    WEBHOOK_DELIVERY_JSON,
    WEBHOOK_ENDPOINT_JSON,
)

SECRET = "whsec_test_secret_123"
BODY = '{"event":"message.received","data":{}}'


def _make_signature(
    secret: str, body: str | bytes, timestamp: int | None = None
) -> str:
    if timestamp is None:
        timestamp = int(time.time())
    if isinstance(body, str):
        body = body.encode("utf-8")
    mac = hmac.new(
        secret.encode("utf-8"),
        f"{timestamp}.".encode() + body,
        hashlib.sha256,
    ).hexdigest()
    return f"t={timestamp},v1={mac}"


class TestWebhookVerification:
    """Tests for the standalone verify_signature function and its instance wrapper."""

    def test_valid_signature(self):
        ts = int(time.time())
        sig = _make_signature(SECRET, BODY, ts)
        assert verify_signature(secret=SECRET, signature=sig, body=BODY) is True

    def test_valid_signature_bytes_body(self):
        ts = int(time.time())
        body_bytes = BODY.encode("utf-8")
        sig = _make_signature(SECRET, body_bytes, ts)
        assert verify_signature(secret=SECRET, signature=sig, body=body_bytes) is True

    def test_wrong_secret(self):
        ts = int(time.time())
        sig = _make_signature(SECRET, BODY, ts)
        assert (
            verify_signature(
                secret="whsec_wrong_secret", signature=sig, body=BODY
            )
            is False
        )

    def test_tampered_body(self):
        ts = int(time.time())
        sig = _make_signature(SECRET, BODY, ts)
        assert (
            verify_signature(
                secret=SECRET, signature=sig, body='{"tampered": true}'
            )
            is False
        )

    def test_expired_signature(self):
        old_ts = int(time.time()) - 600
        sig = _make_signature(SECRET, BODY, old_ts)
        assert verify_signature(secret=SECRET, signature=sig, body=BODY) is False

    def test_custom_tolerance(self):
        old_ts = int(time.time()) - 600
        sig = _make_signature(SECRET, BODY, old_ts)
        assert (
            verify_signature(
                secret=SECRET, signature=sig, body=BODY, tolerance=3600
            )
            is True
        )

    def test_malformed_signature_no_v1(self):
        assert (
            verify_signature(secret=SECRET, signature="t=12345", body=BODY) is False
        )

    def test_malformed_signature_no_t(self):
        assert (
            verify_signature(secret=SECRET, signature="v1=abcdef", body=BODY) is False
        )

    def test_malformed_signature_garbage(self):
        assert (
            verify_signature(secret=SECRET, signature="garbage", body=BODY) is False
        )

    def test_empty_signature(self):
        assert verify_signature(secret=SECRET, signature="", body=BODY) is False

    def test_invalid_timestamp(self):
        assert (
            verify_signature(
                secret=SECRET, signature="t=notanumber,v1=abc", body=BODY
            )
            is False
        )

    def test_instance_method_delegates(self, sync_client: Plop):
        """The instance .verify() method delegates to verify_signature."""
        ts = int(time.time())
        sig = _make_signature(SECRET, BODY, ts)
        assert (
            sync_client.webhooks.verify(
                secret=SECRET, signature=sig, body=BODY
            )
            is True
        )


class TestWebhookAPI:
    def test_list(self, sync_client: Plop, mock_api: respx.Router):
        mock_api.get("/v1/webhooks").mock(
            return_value=httpx.Response(
                200, json={"data": [WEBHOOK_ENDPOINT_JSON]}
            )
        )
        endpoints = sync_client.webhooks.list()
        assert len(endpoints) == 1
        assert endpoints[0].id == "wh_001"
        assert endpoints[0].url == "https://example.com/hook"
        assert endpoints[0].active is True

    def test_create(self, sync_client: Plop, mock_api: respx.Router):
        mock_api.post("/v1/webhooks").mock(
            return_value=httpx.Response(
                200,
                json={
                    "data": {
                        "endpoint": WEBHOOK_ENDPOINT_JSON,
                        "secret": "whsec_full_secret",
                    }
                },
            )
        )
        result = sync_client.webhooks.create(
            url="https://example.com/hook", description="Test webhook"
        )
        assert result.endpoint.id == "wh_001"
        assert result.secret == "whsec_full_secret"

    def test_delete(self, sync_client: Plop, mock_api: respx.Router):
        mock_api.delete("/v1/webhooks/wh_001").mock(
            return_value=httpx.Response(200, json={"data": {"id": "wh_001"}})
        )
        result = sync_client.webhooks.delete("wh_001")
        assert result.id == "wh_001"

    def test_toggle(self, sync_client: Plop, mock_api: respx.Router):
        mock_api.patch("/v1/webhooks/wh_001").mock(
            return_value=httpx.Response(
                200, json={"data": {"id": "wh_001", "active": False}}
            )
        )
        result = sync_client.webhooks.toggle("wh_001", active=False)
        assert result.id == "wh_001"
        assert result.active is False

    def test_deliveries(self, sync_client: Plop, mock_api: respx.Router):
        mock_api.get("/v1/webhooks/wh_001/deliveries").mock(
            return_value=httpx.Response(
                200, json={"data": [WEBHOOK_DELIVERY_JSON]}
            )
        )
        deliveries = sync_client.webhooks.deliveries("wh_001")
        assert len(deliveries) == 1
        assert deliveries[0].id == "del_001"
        assert deliveries[0].http_status == 200
        assert deliveries[0].latency_ms == 42

    def test_deliveries_with_params(
        self, sync_client: Plop, mock_api: respx.Router
    ):
        route = mock_api.get("/v1/webhooks/wh_001/deliveries").mock(
            return_value=httpx.Response(200, json={"data": []})
        )
        sync_client.webhooks.deliveries("wh_001", limit=5, offset=10)
        params = route.calls[0].request.url.params
        assert params["limit"] == "5"
        assert params["offset"] == "10"

    async def test_async_list(
        self, async_client: AsyncPlop, mock_api: respx.Router
    ):
        mock_api.get("/v1/webhooks").mock(
            return_value=httpx.Response(
                200, json={"data": [WEBHOOK_ENDPOINT_JSON]}
            )
        )
        endpoints = await async_client.webhooks.list()
        assert len(endpoints) == 1
        assert endpoints[0].id == "wh_001"

    async def test_async_create(
        self, async_client: AsyncPlop, mock_api: respx.Router
    ):
        mock_api.post("/v1/webhooks").mock(
            return_value=httpx.Response(
                200,
                json={
                    "data": {
                        "endpoint": WEBHOOK_ENDPOINT_JSON,
                        "secret": "whsec_full_secret",
                    }
                },
            )
        )
        result = await async_client.webhooks.create(url="https://example.com/hook")
        assert result.endpoint.id == "wh_001"
        assert result.secret == "whsec_full_secret"

    async def test_async_delete(
        self, async_client: AsyncPlop, mock_api: respx.Router
    ):
        mock_api.delete("/v1/webhooks/wh_001").mock(
            return_value=httpx.Response(200, json={"data": {"id": "wh_001"}})
        )
        result = await async_client.webhooks.delete("wh_001")
        assert result.id == "wh_001"

    async def test_async_toggle(
        self, async_client: AsyncPlop, mock_api: respx.Router
    ):
        mock_api.patch("/v1/webhooks/wh_001").mock(
            return_value=httpx.Response(
                200, json={"data": {"id": "wh_001", "active": True}}
            )
        )
        result = await async_client.webhooks.toggle("wh_001", active=True)
        assert result.id == "wh_001"
        assert result.active is True

    async def test_async_deliveries(
        self, async_client: AsyncPlop, mock_api: respx.Router
    ):
        mock_api.get("/v1/webhooks/wh_001/deliveries").mock(
            return_value=httpx.Response(
                200, json={"data": [WEBHOOK_DELIVERY_JSON]}
            )
        )
        deliveries = await async_client.webhooks.deliveries("wh_001")
        assert len(deliveries) == 1
        assert deliveries[0].id == "del_001"
