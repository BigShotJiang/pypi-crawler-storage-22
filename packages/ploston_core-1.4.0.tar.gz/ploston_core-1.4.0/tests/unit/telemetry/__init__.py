"""Telemetry unit tests."""
