# plotaris

[![PyPI Version][pypi-v-image]][pypi-v-link]
[![Build Status][GHAction-image]][GHAction-link]
[![Coverage Status][codecov-image]][codecov-link]
[![Python Version][python-v-image]][python-v-link]

<!-- Badges -->

[pypi-v-image]: https://img.shields.io/pypi/v/plotaris.svg
[pypi-v-link]: https://pypi.org/project/plotaris/
[GHAction-image]: https://github.com/daizutabi/plotaris/actions/workflows/ci.yaml/badge.svg?branch=main&event=push
[GHAction-link]: https://github.com/daizutabi/plotaris/actions?query=event%3Apush+branch%3Amain
[codecov-image]: https://codecov.io/github/daizutabi/plotaris/graph/badge.svg?token=Yu6lAdVVnd
[codecov-link]: https://codecov.io/github/daizutabi/plotaris?branch=main
[python-v-image]: https://img.shields.io/pypi/pyversions/plotaris.svg
[python-v-link]: https://pypi.org/project/plotaris
