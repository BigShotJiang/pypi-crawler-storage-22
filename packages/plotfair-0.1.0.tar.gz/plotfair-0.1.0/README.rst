plotfair
========

Beautiful color and plotting utilities for matplotlib and plotly.

.. image:: https://img.shields.io/pypi/v/plotfair.svg
   :target: https://pypi.org/project/plotfair/
   :alt: PyPI version

.. image:: https://img.shields.io/pypi/pyversions/plotfair.svg
   :target: https://pypi.org/project/plotfair/
   :alt: Python versions

.. image:: https://readthedocs.org/projects/plotfair/badge/?version=latest
   :target: https://plotfair.readthedocs.io/
   :alt: Documentation Status

.. image:: https://img.shields.io/pypi/l/plotfair.svg
   :target: https://github.com/barton-muller/plotfair/blob/main/LICENSE
   :alt: License

**plotfair** provides curated color palettes, perceptually uniform colormaps,
and convenient wrappers to create publication-quality figures with consistent
styling across matplotlib, plotly, and interplot backends.

Features
--------

* **PaintKit Color System** - Curated color swatches with filtering by saturation
  (bright, dark, muted) and color family. Includes the `Flexoki <https://stephango.com/flexoki>`_ color scheme.

* **Perceptual Colormaps** - Create colormaps that are perceptually uniform using
  CIECAM02 color space, ensuring smooth gradients for data visualization.

* **Matplotlib Presets** - Publication-ready defaults with enhanced DPI, clean
  styling, and automatic figure saving to organized folders.

* **Plotly Wrapper** - Matplotlib-like interface for Plotly via the ``Plty`` class.

* **Interplot Integration** - Pre-configured settings for interplot with
  matplotlib-style plotting via the ``Iplt`` class.

Installation
------------

.. code-block:: bash

   pip install plotfair

Quick Start
-----------

.. code-block:: python

   import plotfair as pf
   import matplotlib as mpl

   # Set a color scheme
   scheme = pf.paintkit.filter(tags={'dark'}).ordered_swatches(pf.full_rainbow)
   mpl.rcParams['axes.prop_cycle'] = scheme.to_cycler()

   # Create a perceptual colormap
   colors = [s.hex for s in pf.paintkit.ordered_swatches(['blue', 'pink', 'orange']).colors]
   cmap = pf.colormaps.perceptual_colormap_nonuniform(colors, [0.0, 0.5, 1.0])
   pf.show_colormap(cmap, name='Custom Colormap')

Color Schemes
^^^^^^^^^^^^^

Filter colors by saturation (``bright``, ``dark``, ``muted``) or color family:

.. code-block:: python

   bright = pf.paintkit.filter(tags={'bright'})
   blues = pf.paintkit.filter(tags={'blue'})
   flexoki = pf.paintkit.filter(tags={'flexoki'})

Use predefined orderings:

.. code-block:: python

   # Available: pf.rainbow, pf.full_rainbow, pf.tab10, pf.flexoki
   scheme = pf.paintkit.filter(tags={'bright'}).ordered_swatches(pf.tab10)

Plotly Wrapper
^^^^^^^^^^^^^^

.. code-block:: python

   from plotfair import Plty
   import numpy as np

   plty = Plty()
   x = np.linspace(0, 10, 100)

   plty.plot(x, np.sin(x), label='sin(x)')
   plty.xlabel('x')
   plty.ylabel('y')
   plty.show()

Documentation
-------------

Full documentation is available at `plotfair.readthedocs.io <https://plotfair.readthedocs.io/>`_.

Requirements
------------

* Python 3.9+
* matplotlib
* numpy
* colorspacious
* plotly >= 6.5.2
* interplot >= 1.1.1

License
-------

MIT License. See `LICENSE <https://github.com/barton-muller/plotfair/blob/main/LICENSE>`_ for details.

Flexoki color scheme © Stephen Ango, licensed under the MIT License.

Links
-----

* `Documentation <https://plotfair.readthedocs.io/>`_
* `Source Code <https://github.com/barton-muller/plotfair>`_
* `Issue Tracker <https://github.com/barton-muller/plotfair/issues>`_