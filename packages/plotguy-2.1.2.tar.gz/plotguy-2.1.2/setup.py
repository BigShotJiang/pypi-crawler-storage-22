import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="plotguy",
    version="2.1.2",
    author="Plotguy Team",
    author_email="plotguy.info@gmail.com",
    description="Plotguy",
    long_description=long_description,
    long_description_content_type="text/markdown",
    install_requires=[         
        'setuptools',  
        'numpy==2.4.2',  
        'pandas==2.3.3',  
        'hkfdb', 
        'pyarrow==23.0.0',
        'fastparquet',
        'polars==0.18.15',
        'plotly==5.18.0',
        'lxml',        
        'dash==2.9.3',
        'dash_bootstrap_components',
        'dash_daq',
        'dash_dangerously_set_inner_html',
    ],
    url="https://pypi.org/project/plotguy/",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)