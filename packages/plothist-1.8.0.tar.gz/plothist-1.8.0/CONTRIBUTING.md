For contributing, refer to the chapter [Contributing](https://plothist.readthedocs.io/en/latest/CONTRIBUTING.html) in the documentation.
