Example gallery
===============

Gallery of images that are used in the doc.

.. note::
   Click on an image to see the source code that generates it.
