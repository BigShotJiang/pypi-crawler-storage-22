Other advanced plots
--------------------

Gallery of images that are used in the other advanced plots section.
