Plot simple functions
---------------------

Gallery of images that are used in the basic function section.
