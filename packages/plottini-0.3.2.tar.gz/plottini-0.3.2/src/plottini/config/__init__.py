"""Configuration management for Plottini."""
