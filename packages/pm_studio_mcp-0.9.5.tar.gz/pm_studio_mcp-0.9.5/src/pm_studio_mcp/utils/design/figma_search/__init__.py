"""
Figma search functionality for MCP server.
"""
