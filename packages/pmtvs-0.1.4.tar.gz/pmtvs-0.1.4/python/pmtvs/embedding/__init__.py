"""Embedding primitives."""
