"""Pairwise signal primitives."""
