"""Topology primitives."""
