int read_elf(char *fn);
