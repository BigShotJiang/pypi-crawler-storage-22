print ("pneumoultramicroscopicossilicovulcanoconiose")
