# PocketCoder

**AI coding agent that runs with any LLM — local or cloud.**

Stop paying $20/month for cloud AI coding tools. PocketCoder works with free local models like Qwen, Llama, or DeepSeek running on your own machine via Ollama. Or connect to OpenAI/Claude if you prefer.

## Why PocketCoder?

Most AI coding assistants are locked to expensive cloud APIs. PocketCoder is different:

- **Run locally for free** — Use Ollama with open-source models (7B-14B work great)
- **Session memory** — Agent remembers what you're working on across requests
- **Project awareness** — RepoMap shows your codebase structure to the LLM
- **Multi-step tasks** — TODO tracking, automatic planning, checkpoint progress
- **Any LLM provider** — Ollama, OpenAI, Anthropic, vLLM, LM Studio, or any OpenAI-compatible API

## Installation

```bash
pip install pocketcoder
```

## Quick Start

```bash
# Start in your project directory
pocketcoder

# First run opens setup wizard to configure your LLM
```

### With Ollama (free, local)

```bash
# Install Ollama: https://ollama.com
ollama pull qwen2.5-coder:7b
pocketcoder
```

### With OpenAI

```bash
export OPENAI_API_KEY="sk-..."
pocketcoder --provider openai --model gpt-4o
```

## How It Works

PocketCoder is a coding agent, not a chatbot. When you give it a task:

1. **Understands context** — Reads your files, understands project structure
2. **Plans the work** — Breaks complex tasks into steps
3. **Executes tools** — Reads files, writes code, runs commands
4. **Validates results** — Checks its own work before marking done

```
> add authentication to the API

[TODO] Read existing API structure
[TODO] Create auth middleware
[TODO] Add login/logout endpoints
[TODO] Update existing routes

Reading api/routes.py...
Creating api/auth.py...
Done: Added JWT authentication with login/logout endpoints
```

## Commands

| Command | Description |
|---------|-------------|
| `/help` | Show available commands |
| `/model` | Switch LLM model |
| `/add <file>` | Add file to context |
| `/drop <file>` | Remove file from context |
| `/files` | List files in context |
| `/undo` | Undo last file change |
| `/clear` | Clear conversation history |
| `/quit` | Exit |

## Supported Providers

| Provider | Type | Setup |
|----------|------|-------|
| Ollama | Local | `ollama serve` then `ollama pull model` |
| OpenAI | Cloud | Set `OPENAI_API_KEY` |
| Anthropic | Cloud | Set `ANTHROPIC_API_KEY` |
| vLLM | Local/Cloud | Any OpenAI-compatible endpoint |
| LM Studio | Local | Run server, point to localhost |

## Configuration

Config stored in `~/.pocketcoder/config.yaml`:

```yaml
provider:
  type: ollama
  base_url: http://localhost:11434
  default_model: qwen2.5-coder:7b

thinking:
  mode: smart           # smart | always | never
  show_reasoning: true  # show agent's thinking process
```

## Recommended Models

For local use with 16GB+ RAM:

| Model | Size | Speed | Quality |
|-------|------|-------|---------|
| qwen2.5-coder:7b | 4.7GB | Fast | Good |
| qwen2.5-coder:14b | 9GB | Medium | Better |
| deepseek-coder:6.7b | 4GB | Fast | Good |
| codellama:13b | 7GB | Medium | Good |

## Project Structure

PocketCoder stores session data in `.pocketcoder/` directory (like `.git/`):

```
.pocketcoder/
  project_context.json  # Current session state
  episodes.jsonl        # Conversation history
  memory.json           # Long-term facts
```

## Development

```bash
git clone https://github.com/Chashchin-Dmitry/pocketcoder.git
cd pocketcoder
pip install -e ".[dev]"
pytest
```

## Support the Project

If PocketCoder saves you money on AI subscriptions, consider supporting development:

| Network | Address |
|---------|---------|
| ETH / USDT (ERC-20) | `0xdF5e04d590d44603FDAdDb9f311b9dF7E5dE797c` |
| BTC | `bc1q3q25vw4jm8v4xe2g6uezq35q2uyn5jt6e00mj9` |
| USDT (TRC-20) | `TQj3X5nFQWqPEmRUWNFPjkaRUUFLxmCdok` |
| SOL | `5s5uP66VmnLMSApjq8ro639tXvSp59XEwQittzxF64mF` |

## License

MIT License
