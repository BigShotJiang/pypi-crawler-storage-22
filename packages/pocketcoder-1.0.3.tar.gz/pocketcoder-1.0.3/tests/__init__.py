"""
PocketCoder test suite.
"""
