"""Podex Pod - Self-hosted compute agent for Podex."""

__version__ = "0.0.1"


def main():
    """Placeholder entry point."""
    print("""
  Podex Pod - Coming Soon!

  Self-hosted compute agent for Podex.

  Currently, install the existing package:
    pip install podex-local-pod

  Learn more: https://podex.dev
  Documentation: https://docs.podex.dev/local-pods
""")


if __name__ == "__main__":
    main()
