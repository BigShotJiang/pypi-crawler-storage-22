from .core.file import File
from .sdk import Podonos, Client

__version__ = "0.33.0"

init = Podonos.init
