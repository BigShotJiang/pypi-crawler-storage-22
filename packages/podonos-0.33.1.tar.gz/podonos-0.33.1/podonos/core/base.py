# Base package for every SDK files.

import glog as log  # type: ignore

log.setLevel("INFO")  # type: ignore
