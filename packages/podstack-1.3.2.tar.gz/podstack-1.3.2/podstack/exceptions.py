"""
Podstack Exception Classes

Custom exceptions for handling various error conditions in the Podstack SDK.
"""


class PodstackError(Exception):
    """Base exception for all Podstack errors"""

    def __init__(self, message: str, code: str = None, details: dict = None):
        super().__init__(message)
        self.message = message
        self.code = code
        self.details = details or {}

    def __str__(self):
        if self.code:
            return f"[{self.code}] {self.message}"
        return self.message

    def __repr__(self):
        return f"{self.__class__.__name__}(message={self.message!r}, code={self.code!r})"


class AuthenticationError(PodstackError):
    """Raised when API authentication fails"""

    def __init__(self, message: str = "Invalid or missing API key"):
        super().__init__(message, code="authentication_error")


class NotFoundError(PodstackError):
    """Raised when a requested resource is not found"""

    def __init__(self, resource_type: str, resource_id: str):
        message = f"{resource_type} '{resource_id}' not found"
        super().__init__(message, code="not_found")
        self.resource_type = resource_type
        self.resource_id = resource_id


class RateLimitError(PodstackError):
    """Raised when API rate limit is exceeded"""

    def __init__(self, retry_after: int = None):
        message = "Rate limit exceeded"
        if retry_after:
            message += f". Retry after {retry_after} seconds"
        super().__init__(message, code="rate_limit_exceeded")
        self.retry_after = retry_after


class GPUNotAvailableError(PodstackError):
    """Raised when the requested GPU type is not available"""

    def __init__(self, gpu_type: str, available_types: list = None):
        message = f"GPU type '{gpu_type}' is not available"
        super().__init__(message, code="gpu_not_available")
        self.gpu_type = gpu_type
        self.available_types = available_types or []


class ExecutionTimeoutError(PodstackError):
    """Raised when code execution times out"""

    def __init__(self, execution_id: str, timeout_seconds: int):
        message = f"Execution '{execution_id}' timed out after {timeout_seconds} seconds"
        super().__init__(message, code="execution_timeout")
        self.execution_id = execution_id
        self.timeout_seconds = timeout_seconds


class ValidationError(PodstackError):
    """Raised when request validation fails"""

    def __init__(self, message: str, field: str = None):
        super().__init__(message, code="validation_error")
        self.field = field


class QuotaExceededError(PodstackError):
    """Raised when account quota is exceeded"""

    def __init__(self, quota_type: str, limit: int, current: int):
        message = f"{quota_type} quota exceeded: {current}/{limit}"
        super().__init__(message, code="quota_exceeded")
        self.quota_type = quota_type
        self.limit = limit
        self.current = current


class InsufficientBalanceError(PodstackError):
    """Raised when wallet balance is insufficient"""

    def __init__(self, required: float, available: float):
        message = f"Insufficient balance: required ${required:.2f}, available ${available:.2f}"
        super().__init__(message, code="insufficient_balance")
        self.required = required
        self.available = available


class NotebookStateError(PodstackError):
    """Raised when notebook is in an invalid state for the operation"""

    def __init__(self, notebook_id: str, current_state: str, required_state: str):
        message = f"Notebook '{notebook_id}' is {current_state}, must be {required_state}"
        super().__init__(message, code="invalid_notebook_state")
        self.notebook_id = notebook_id
        self.current_state = current_state
        self.required_state = required_state


class ConnectionError(PodstackError):
    """Raised when connection to the API fails"""

    def __init__(self, message: str = "Failed to connect to Podstack API"):
        super().__init__(message, code="connection_error")


class WebSocketError(PodstackError):
    """Raised when WebSocket connection fails"""

    def __init__(self, message: str = "WebSocket connection error"):
        super().__init__(message, code="websocket_error")
