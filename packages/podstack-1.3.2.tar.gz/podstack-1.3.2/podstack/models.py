"""
Podstack Data Models

Data classes representing various resources in the Podstack API.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List, Dict, Any
from enum import Enum


class GPUType(str, Enum):
    """Available GPU types"""
    A10 = "A10"
    A100_40GB = "A100_40GB"
    A100_80GB = "A100_80GB"
    H100 = "H100"
    H100_80GB = "H100_80GB"
    L4 = "L4"
    L40S = "L40S"
    T4 = "T4"
    RTX_4090 = "RTX_4090"
    RTX_6000_ADA = "RTX_6000_ADA"

    @property
    def memory_gb(self) -> int:
        """Get GPU memory in GB"""
        memory_map = {
            "A10": 24,
            "A100_40GB": 40,
            "A100_80GB": 80,
            "H100": 80,
            "H100_80GB": 80,
            "L4": 24,
            "L40S": 48,
            "T4": 16,
            "RTX_4090": 24,
            "RTX_6000_ADA": 48,
        }
        return memory_map.get(self.value, 0)

    @property
    def price_per_hour_cents(self) -> int:
        """Get price per hour in cents"""
        price_map = {
            "A10": 90,
            "A100_40GB": 250,
            "A100_80GB": 350,
            "H100": 500,
            "H100_80GB": 550,
            "L4": 70,
            "L40S": 120,
            "T4": 50,
            "RTX_4090": 80,
            "RTX_6000_ADA": 130,
        }
        return price_map.get(self.value, 0)


class Environment(str, Enum):
    """Pre-configured environments"""
    PYTORCH = "pytorch"
    TENSORFLOW = "tensorflow"
    JAX = "jax"
    RAPIDS = "rapids"
    HUGGINGFACE = "huggingface"
    CUSTOM = "custom"


@dataclass
class GPUInfo:
    """Information about an available GPU type"""
    type: str
    name: str
    memory_gb: int
    price_per_hour_cents: int
    available: int
    total: int

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GPUInfo":
        return cls(
            type=data["type"],
            name=data["name"],
            memory_gb=data["memory_gb"],
            price_per_hour_cents=data["price_per_hour_cents"],
            available=data["available"],
            total=data["total"]
        )


@dataclass
class Project:
    """A project for organizing notebooks"""
    id: str
    name: str
    description: Optional[str]
    created_at: datetime
    updated_at: datetime
    notebook_count: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Project":
        return cls(
            id=data["id"],
            name=data["name"],
            description=data.get("description"),
            created_at=datetime.fromisoformat(data["created_at"].replace("Z", "+00:00")),
            updated_at=datetime.fromisoformat(data["updated_at"].replace("Z", "+00:00")),
            notebook_count=data.get("notebook_count", 0),
            metadata=data.get("metadata", {})
        )


@dataclass
class Version:
    """A notebook version (checkpoint)"""
    id: str
    notebook_id: str
    version_number: int
    message: Optional[str]
    created_at: datetime
    cells_hash: str
    parent_version_id: Optional[str] = None
    branch_name: str = "main"
    is_auto_checkpoint: bool = False

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Version":
        return cls(
            id=data["id"],
            notebook_id=data["notebook_id"],
            version_number=data["version_number"],
            message=data.get("message"),
            created_at=datetime.fromisoformat(data["created_at"].replace("Z", "+00:00")),
            cells_hash=data["cells_hash"],
            parent_version_id=data.get("parent_version_id"),
            branch_name=data.get("branch_name", "main"),
            is_auto_checkpoint=data.get("is_auto_checkpoint", False)
        )


@dataclass
class WalletBalance:
    """User's wallet balance information"""
    balance_cents: int
    currency: str
    last_updated: datetime
    pending_charges_cents: int = 0

    @property
    def balance(self) -> float:
        """Get balance in dollars"""
        return self.balance_cents / 100

    @property
    def available_balance(self) -> float:
        """Get available balance (minus pending charges)"""
        return (self.balance_cents - self.pending_charges_cents) / 100

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WalletBalance":
        return cls(
            balance_cents=data["balance_cents"],
            currency=data.get("currency", "USD"),
            last_updated=datetime.fromisoformat(data["last_updated"].replace("Z", "+00:00")),
            pending_charges_cents=data.get("pending_charges_cents", 0)
        )


@dataclass
class UsageRecord:
    """Usage record for billing"""
    date: str
    gpu_type: str
    gpu_seconds: int
    cost_cents: int
    notebook_id: Optional[str] = None

    @property
    def cost(self) -> float:
        """Get cost in dollars"""
        return self.cost_cents / 100

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "UsageRecord":
        return cls(
            date=data["date"],
            gpu_type=data["gpu_type"],
            gpu_seconds=data["gpu_seconds"],
            cost_cents=data["cost_cents"],
            notebook_id=data.get("notebook_id")
        )


@dataclass
class UsageSummary:
    """Summary of usage for a period"""
    total_cost_cents: int
    total_gpu_seconds: int
    breakdown: List[UsageRecord]
    start_date: Optional[str] = None
    end_date: Optional[str] = None

    @property
    def total_cost(self) -> float:
        """Get total cost in dollars"""
        return self.total_cost_cents / 100

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "UsageSummary":
        return cls(
            total_cost_cents=data["total_cost_cents"],
            total_gpu_seconds=data["total_gpu_seconds"],
            breakdown=[UsageRecord.from_dict(r) for r in data.get("breakdown", [])],
            start_date=data.get("start_date"),
            end_date=data.get("end_date")
        )


@dataclass
class Webhook:
    """Webhook configuration"""
    id: str
    url: str
    events: List[str]
    created_at: datetime
    is_active: bool = True
    secret: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Webhook":
        return cls(
            id=data["id"],
            url=data["url"],
            events=data["events"],
            created_at=datetime.fromisoformat(data["created_at"].replace("Z", "+00:00")),
            is_active=data.get("is_active", True),
            secret=data.get("secret")
        )


@dataclass
class Cell:
    """A notebook cell"""
    id: str
    cell_type: str  # "code" or "markdown"
    source: str
    outputs: List[Dict[str, Any]] = field(default_factory=list)
    execution_count: Optional[int] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Cell":
        return cls(
            id=data["id"],
            cell_type=data["cell_type"],
            source=data["source"],
            outputs=data.get("outputs", []),
            execution_count=data.get("execution_count"),
            metadata=data.get("metadata", {})
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "cell_type": self.cell_type,
            "source": self.source,
            "outputs": self.outputs,
            "execution_count": self.execution_count,
            "metadata": self.metadata
        }
