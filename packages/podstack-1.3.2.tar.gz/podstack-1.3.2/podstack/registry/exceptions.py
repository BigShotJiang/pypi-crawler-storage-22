"""
Registry Exception Classes

Custom exceptions for the Podstack Registry SDK.
"""

from ..exceptions import PodstackError


class RegistryError(PodstackError):
    """Base exception for registry errors"""

    def __init__(self, message: str, code: str = "registry_error"):
        super().__init__(message, code=code)


class ExperimentNotFoundError(RegistryError):
    """Raised when an experiment is not found"""

    def __init__(self, experiment_id: str):
        message = f"Experiment '{experiment_id}' not found"
        super().__init__(message, code="experiment_not_found")
        self.experiment_id = experiment_id


class RunNotFoundError(RegistryError):
    """Raised when a run is not found"""

    def __init__(self, run_id: str):
        message = f"Run '{run_id}' not found"
        super().__init__(message, code="run_not_found")
        self.run_id = run_id


class ModelNotFoundError(RegistryError):
    """Raised when a model is not found"""

    def __init__(self, model_id: str):
        message = f"Model '{model_id}' not found"
        super().__init__(message, code="model_not_found")
        self.model_id = model_id


class NoActiveRunError(RegistryError):
    """Raised when trying to log without an active run"""

    def __init__(self):
        message = "No active run. Call start_run() first."
        super().__init__(message, code="no_active_run")


class NoExperimentSetError(RegistryError):
    """Raised when trying to create a run without setting an experiment"""

    def __init__(self):
        message = "No experiment set. Call set_experiment() first."
        super().__init__(message, code="no_experiment_set")


class InvalidStageError(RegistryError):
    """Raised when an invalid stage is specified"""

    VALID_STAGES = ["development", "staging", "production", "archived"]

    def __init__(self, stage: str):
        message = f"Invalid stage '{stage}'. Must be one of: {', '.join(self.VALID_STAGES)}"
        super().__init__(message, code="invalid_stage")
        self.stage = stage


class ModelVersionNotFoundError(RegistryError):
    """Raised when a model version is not found"""

    def __init__(self, model_name: str, version: int):
        message = f"Version {version} of model '{model_name}' not found"
        super().__init__(message, code="model_version_not_found")
        self.model_name = model_name
        self.version = version


class ArtifactNotFoundError(RegistryError):
    """Raised when a requested artifact cannot be found"""

    def __init__(self, run_id: str, artifact_path: str):
        message = f"Artifact '{artifact_path}' not found in run '{run_id}'"
        super().__init__(message, code="artifact_not_found")
        self.run_id = run_id
        self.artifact_path = artifact_path


class ModelSerializationError(RegistryError):
    """Raised when model serialization or deserialization fails"""

    def __init__(self, message: str):
        super().__init__(message, code="model_serialization_error")


class FrameworkNotInstalledError(RegistryError):
    """Raised when a required ML framework is not installed"""

    def __init__(self, framework: str):
        message = (
            f"Framework '{framework}' is not installed. "
            f"Install it with: pip install podstack[{framework}]"
        )
        super().__init__(message, code="framework_not_installed")
        self.framework = framework
