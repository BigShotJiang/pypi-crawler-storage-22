"""
Experiment and Run Classes

Data classes for experiment tracking.
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
from datetime import datetime


@dataclass
class Experiment:
    """Represents an experiment in the registry."""

    id: str
    project_id: str
    name: str
    description: Optional[str] = None
    artifact_location: Optional[str] = None
    status: str = "active"
    tags: Dict[str, str] = field(default_factory=dict)
    run_count: int = 0
    last_run_at: Optional[datetime] = None
    created_by_user_id: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Experiment":
        """Create an Experiment from a dict."""
        return cls(
            id=data.get("id", ""),
            project_id=data.get("project_id", ""),
            name=data.get("name", ""),
            description=data.get("description"),
            artifact_location=data.get("artifact_location"),
            status=data.get("status", "active"),
            tags=data.get("tags") or {},
            run_count=data.get("run_count", 0),
            last_run_at=_parse_datetime(data.get("last_run_at")),
            created_by_user_id=data.get("created_by_user_id"),
            created_at=_parse_datetime(data.get("created_at")),
            updated_at=_parse_datetime(data.get("updated_at")),
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict."""
        return {
            "id": self.id,
            "project_id": self.project_id,
            "name": self.name,
            "description": self.description,
            "artifact_location": self.artifact_location,
            "status": self.status,
            "tags": self.tags,
            "run_count": self.run_count,
            "last_run_at": self.last_run_at.isoformat() if self.last_run_at else None,
            "created_by_user_id": self.created_by_user_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


@dataclass
class Metric:
    """Represents a logged metric."""

    key: str
    value: float
    timestamp: Optional[int] = None
    step: Optional[int] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Metric":
        return cls(
            key=data.get("key", ""),
            value=data.get("value", 0.0),
            timestamp=data.get("timestamp"),
            step=data.get("step"),
        )


@dataclass
class Param:
    """Represents a logged parameter."""

    key: str
    value: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Param":
        return cls(
            key=data.get("key", ""),
            value=data.get("value", ""),
        )


@dataclass
class Run:
    """
    Represents a run in an experiment.

    Can be used as a context manager:
        with registry.start_run(name="training") as run:
            registry.log_params({"lr": 0.001})
            registry.log_metrics({"loss": 0.5})
    """

    id: str
    project_id: str
    experiment_id: str
    user_id: Optional[str] = None
    name: Optional[str] = None
    status: str = "running"
    source_type: Optional[str] = None
    source_name: Optional[str] = None
    artifact_uri: Optional[str] = None
    start_time: Optional[int] = None
    end_time: Optional[int] = None
    duration_ms: int = 0
    tags: Dict[str, str] = field(default_factory=dict)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    # Reference to client for context manager
    _client: Any = field(default=None, repr=False)

    @classmethod
    def from_dict(cls, data: Dict[str, Any], client: Any = None) -> "Run":
        """Create a Run from a dict."""
        return cls(
            id=data.get("id", ""),
            project_id=data.get("project_id", ""),
            experiment_id=data.get("experiment_id", ""),
            user_id=data.get("user_id"),
            name=data.get("name"),
            status=data.get("status", "running"),
            source_type=data.get("source_type"),
            source_name=data.get("source_name"),
            artifact_uri=data.get("artifact_uri"),
            start_time=data.get("start_time"),
            end_time=data.get("end_time"),
            duration_ms=data.get("duration_ms", 0),
            tags=data.get("tags") or {},
            created_at=_parse_datetime(data.get("created_at")),
            updated_at=_parse_datetime(data.get("updated_at")),
            _client=client,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict."""
        return {
            "id": self.id,
            "project_id": self.project_id,
            "experiment_id": self.experiment_id,
            "user_id": self.user_id,
            "name": self.name,
            "status": self.status,
            "source_type": self.source_type,
            "source_name": self.source_name,
            "artifact_uri": self.artifact_uri,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_ms": self.duration_ms,
            "tags": self.tags,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

    def __enter__(self) -> "Run":
        """Enter context manager."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context manager, ending the run."""
        if self._client:
            if exc_type is not None:
                # Exception occurred, mark as failed
                self._client.end_run(status="failed")
            else:
                self._client.end_run(status="completed")
        return False  # Don't suppress exceptions

    def log_params(self, params: Dict[str, Any]):
        """Log parameters for this run."""
        if self._client:
            self._client.log_params(params)

    def log_metrics(self, metrics: Dict[str, float], step: int = None):
        """Log metrics for this run."""
        if self._client:
            self._client.log_metrics(metrics, step)

    def log_artifact(self, local_path: str, artifact_path: str = None):
        """Log an artifact for this run."""
        if self._client:
            self._client.log_artifact(local_path, artifact_path)

    def set_tag(self, key: str, value: str):
        """Set a tag on this run."""
        if self._client:
            self._client.set_tag(key, value)
        self.tags[key] = value

    def end(self, status: str = "completed"):
        """End this run."""
        if self._client:
            self._client.end_run(status)
        self.status = status


def _parse_datetime(value: Any) -> Optional[datetime]:
    """Parse a datetime from string or return None."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        try:
            # Handle ISO format with Z suffix
            if value.endswith("Z"):
                value = value[:-1] + "+00:00"
            return datetime.fromisoformat(value)
        except ValueError:
            return None
    return None
