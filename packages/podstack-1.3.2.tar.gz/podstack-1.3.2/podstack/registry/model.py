"""
Model Registry Classes

Data classes for model registry.
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
from datetime import datetime


@dataclass
class RegisteredModel:
    """Represents a registered model in the registry."""

    id: str
    project_id: str
    name: str
    description: Optional[str] = None
    tags: Dict[str, str] = field(default_factory=dict)
    version_count: int = 0
    latest_version: int = 0
    created_by_user_id: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    # Loaded lazily
    _versions: Optional[List["ModelVersion"]] = field(default=None, repr=False)
    _aliases: Optional[List["ModelAlias"]] = field(default=None, repr=False)
    _client: Any = field(default=None, repr=False)

    @classmethod
    def from_dict(cls, data: Dict[str, Any], client: Any = None) -> "RegisteredModel":
        """Create a RegisteredModel from a dict."""
        return cls(
            id=data.get("id", ""),
            project_id=data.get("project_id", ""),
            name=data.get("name", ""),
            description=data.get("description"),
            tags=data.get("tags") or {},
            version_count=data.get("version_count", 0),
            latest_version=data.get("latest_version", 0),
            created_by_user_id=data.get("created_by_user_id"),
            created_at=_parse_datetime(data.get("created_at")),
            updated_at=_parse_datetime(data.get("updated_at")),
            _client=client,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict."""
        return {
            "id": self.id,
            "project_id": self.project_id,
            "name": self.name,
            "description": self.description,
            "tags": self.tags,
            "version_count": self.version_count,
            "latest_version": self.latest_version,
            "created_by_user_id": self.created_by_user_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

    def get_version(self, version: int) -> "ModelVersion":
        """Get a specific version of this model."""
        if self._client:
            return self._client.get_model_version(self.id, version)
        raise RuntimeError("Model not connected to client")

    def list_versions(self, limit: int = 20, offset: int = 0) -> List["ModelVersion"]:
        """List versions of this model."""
        if self._client:
            return self._client.list_model_versions(self.id, limit, offset)
        raise RuntimeError("Model not connected to client")

    def create_version(
        self,
        run_id: str = None,
        source: str = None,
        description: str = None
    ) -> "ModelVersion":
        """Create a new version of this model."""
        if self._client:
            return self._client.create_model_version(
                self.id, run_id=run_id, source=source, description=description
            )
        raise RuntimeError("Model not connected to client")

    def set_alias(self, alias: str, version: int) -> "ModelAlias":
        """Set an alias for a version of this model."""
        if self._client:
            return self._client.set_model_alias(self.name, alias, version)
        raise RuntimeError("Model not connected to client")

    def get_aliases(self) -> List["ModelAlias"]:
        """Get all aliases for this model."""
        if self._client:
            return self._client.get_model_aliases(self.id)
        raise RuntimeError("Model not connected to client")


@dataclass
class ModelVersion:
    """Represents a version of a registered model."""

    id: str
    model_id: str
    project_id: str
    version: int
    run_id: Optional[str] = None
    source: Optional[str] = None
    status: str = "ready"
    stage: str = "development"
    description: Optional[str] = None
    tags: Dict[str, str] = field(default_factory=dict)
    created_by_user_id: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    _client: Any = field(default=None, repr=False)

    @classmethod
    def from_dict(cls, data: Dict[str, Any], client: Any = None) -> "ModelVersion":
        """Create a ModelVersion from a dict."""
        return cls(
            id=data.get("id", ""),
            model_id=data.get("model_id", ""),
            project_id=data.get("project_id", ""),
            version=data.get("version", 0),
            run_id=data.get("run_id"),
            source=data.get("source"),
            status=data.get("status", "ready"),
            stage=data.get("stage", "development"),
            description=data.get("description"),
            tags=data.get("tags") or {},
            created_by_user_id=data.get("created_by_user_id"),
            created_at=_parse_datetime(data.get("created_at")),
            updated_at=_parse_datetime(data.get("updated_at")),
            _client=client,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict."""
        return {
            "id": self.id,
            "model_id": self.model_id,
            "project_id": self.project_id,
            "version": self.version,
            "run_id": self.run_id,
            "source": self.source,
            "status": self.status,
            "stage": self.stage,
            "description": self.description,
            "tags": self.tags,
            "created_by_user_id": self.created_by_user_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

    def transition_stage(self, stage: str, comment: str = None) -> "ModelVersion":
        """Transition this version to a new stage."""
        if self._client:
            return self._client.transition_model_stage(
                self.model_id, self.version, stage, comment
            )
        raise RuntimeError("ModelVersion not connected to client")


@dataclass
class ModelAlias:
    """Represents an alias for a model version."""

    id: str
    model_id: str
    project_id: str
    alias: str
    model_version_id: str
    version: int
    created_by_user_id: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ModelAlias":
        """Create a ModelAlias from a dict."""
        return cls(
            id=data.get("id", ""),
            model_id=data.get("model_id", ""),
            project_id=data.get("project_id", ""),
            alias=data.get("alias", ""),
            model_version_id=data.get("model_version_id", ""),
            version=data.get("version", 0),
            created_by_user_id=data.get("created_by_user_id"),
            created_at=_parse_datetime(data.get("created_at")),
            updated_at=_parse_datetime(data.get("updated_at")),
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict."""
        return {
            "id": self.id,
            "model_id": self.model_id,
            "project_id": self.project_id,
            "alias": self.alias,
            "model_version_id": self.model_version_id,
            "version": self.version,
            "created_by_user_id": self.created_by_user_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


@dataclass
class StageTransition:
    """Represents a stage transition history record."""

    id: str
    model_id: str
    model_version_id: str
    project_id: str
    version: int
    from_stage: Optional[str] = None
    to_stage: str = ""
    transitioned_by: Optional[str] = None
    comment: Optional[str] = None
    created_at: Optional[datetime] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "StageTransition":
        """Create a StageTransition from a dict."""
        return cls(
            id=data.get("id", ""),
            model_id=data.get("model_id", ""),
            model_version_id=data.get("model_version_id", ""),
            project_id=data.get("project_id", ""),
            version=data.get("version", 0),
            from_stage=data.get("from_stage"),
            to_stage=data.get("to_stage", ""),
            transitioned_by=data.get("transitioned_by"),
            comment=data.get("comment"),
            created_at=_parse_datetime(data.get("created_at")),
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict."""
        return {
            "id": self.id,
            "model_id": self.model_id,
            "model_version_id": self.model_version_id,
            "project_id": self.project_id,
            "version": self.version,
            "from_stage": self.from_stage,
            "to_stage": self.to_stage,
            "transitioned_by": self.transitioned_by,
            "comment": self.comment,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


def _parse_datetime(value: Any) -> Optional[datetime]:
    """Parse a datetime from string or return None."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        try:
            if value.endswith("Z"):
                value = value[:-1] + "+00:00"
            return datetime.fromisoformat(value)
        except ValueError:
            return None
    return None
