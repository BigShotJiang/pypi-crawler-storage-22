"""
Model Utilities

Framework-agnostic model serialization and deserialization helpers.
All framework imports are lazy — no hard dependencies on any ML framework.
"""

import os
import pickle
from typing import Any, Optional

from .exceptions import ModelSerializationError, FrameworkNotInstalledError


# Framework detection mapping: module prefix -> framework name
_FRAMEWORK_MODULE_MAP = {
    "torch": "pytorch",
    "tensorflow": "tensorflow",
    "keras": "tensorflow",
    "sklearn": "sklearn",
    "transformers": "huggingface",
}


def detect_framework(model: Any) -> str:
    """
    Auto-detect the ML framework from a model object.

    Args:
        model: A model object from any supported framework.

    Returns:
        Framework name string: "pytorch", "tensorflow", "sklearn", "huggingface", or "pickle".
    """
    module = type(model).__module__ or ""

    for prefix, framework in _FRAMEWORK_MODULE_MAP.items():
        if module.startswith(prefix):
            return framework

    # Fallback: check for common base classes by name to avoid imports
    type_name = type(model).__name__
    type_mro = [cls.__module__ + "." + cls.__name__ for cls in type(model).__mro__]

    for entry in type_mro:
        for prefix, framework in _FRAMEWORK_MODULE_MAP.items():
            if entry.startswith(prefix):
                return framework

    return "pickle"


def save_model(model: Any, path: str, framework: Optional[str] = None) -> str:
    """
    Serialize a model to disk.

    Args:
        model: The model object to save.
        path: Directory path to save the model into.
        framework: Framework name. Auto-detected if not provided.
            One of: "pytorch", "tensorflow", "sklearn", "huggingface", "pickle".

    Returns:
        Path to the saved model file/directory.

    Raises:
        FrameworkNotInstalledError: If the required framework is not installed.
        ModelSerializationError: If serialization fails.
    """
    if framework is None:
        framework = detect_framework(model)

    os.makedirs(path, exist_ok=True)

    try:
        if framework == "pytorch":
            return _save_pytorch(model, path)
        elif framework == "tensorflow":
            return _save_tensorflow(model, path)
        elif framework == "sklearn":
            return _save_sklearn(model, path)
        elif framework == "huggingface":
            return _save_huggingface(model, path)
        else:
            return _save_pickle(model, path)
    except FrameworkNotInstalledError:
        raise
    except Exception as e:
        raise ModelSerializationError(f"Failed to save {framework} model: {e}")


def load_model_from_path(path: str, framework: str) -> Any:
    """
    Deserialize a model from disk.

    Args:
        path: Path to the saved model file or directory.
        framework: Framework name used to save the model.
            One of: "pytorch", "tensorflow", "sklearn", "huggingface", "pickle".

    Returns:
        The loaded model object.

    Raises:
        FrameworkNotInstalledError: If the required framework is not installed.
        ModelSerializationError: If deserialization fails.
    """
    try:
        if framework == "pytorch":
            return _load_pytorch(path)
        elif framework == "tensorflow":
            return _load_tensorflow(path)
        elif framework == "sklearn":
            return _load_sklearn(path)
        elif framework == "huggingface":
            return _load_huggingface(path)
        else:
            return _load_pickle(path)
    except FrameworkNotInstalledError:
        raise
    except Exception as e:
        raise ModelSerializationError(f"Failed to load {framework} model: {e}")


# ==================== PyTorch ====================

def _save_pytorch(model: Any, path: str) -> str:
    try:
        import torch
    except ImportError:
        raise FrameworkNotInstalledError("torch")

    filepath = os.path.join(path, "model.pt")
    torch.save(model.state_dict() if hasattr(model, "state_dict") else model, filepath)
    return filepath


def _load_pytorch(path: str) -> Any:
    try:
        import torch
    except ImportError:
        raise FrameworkNotInstalledError("torch")

    filepath = path if os.path.isfile(path) else os.path.join(path, "model.pt")
    return torch.load(filepath, map_location="cpu", weights_only=False)


# ==================== TensorFlow / Keras ====================

def _save_tensorflow(model: Any, path: str) -> str:
    try:
        import tensorflow  # noqa: F401
    except ImportError:
        raise FrameworkNotInstalledError("tensorflow")

    save_dir = os.path.join(path, "saved_model")
    model.save(save_dir)
    return save_dir


def _load_tensorflow(path: str) -> Any:
    try:
        import tensorflow as tf
    except ImportError:
        raise FrameworkNotInstalledError("tensorflow")

    load_dir = path if os.path.isdir(path) and os.path.exists(os.path.join(path, "saved_model.pb")) else os.path.join(path, "saved_model")
    return tf.keras.models.load_model(load_dir)


# ==================== Scikit-learn ====================

def _save_sklearn(model: Any, path: str) -> str:
    try:
        import sklearn  # noqa: F401
    except ImportError:
        raise FrameworkNotInstalledError("sklearn")

    filepath = os.path.join(path, "model.pkl")
    with open(filepath, "wb") as f:
        pickle.dump(model, f)
    return filepath


def _load_sklearn(path: str) -> Any:
    try:
        import sklearn  # noqa: F401
    except ImportError:
        raise FrameworkNotInstalledError("sklearn")

    filepath = path if os.path.isfile(path) else os.path.join(path, "model.pkl")
    with open(filepath, "rb") as f:
        return pickle.load(f)


# ==================== Hugging Face ====================

def _save_huggingface(model: Any, path: str) -> str:
    try:
        import transformers  # noqa: F401
    except ImportError:
        raise FrameworkNotInstalledError("huggingface")

    save_dir = os.path.join(path, "hf_model")
    model.save_pretrained(save_dir)
    return save_dir


def _load_huggingface(path: str) -> Any:
    try:
        from transformers import AutoModel
    except ImportError:
        raise FrameworkNotInstalledError("huggingface")

    load_dir = path if os.path.isdir(path) and os.path.exists(os.path.join(path, "config.json")) else os.path.join(path, "hf_model")
    return AutoModel.from_pretrained(load_dir)


# ==================== Pickle (fallback) ====================

def _save_pickle(model: Any, path: str) -> str:
    filepath = os.path.join(path, "model.pkl")
    with open(filepath, "wb") as f:
        pickle.dump(model, f)
    return filepath


def _load_pickle(path: str) -> Any:
    filepath = path if os.path.isfile(path) else os.path.join(path, "model.pkl")
    with open(filepath, "rb") as f:
        return pickle.load(f)
