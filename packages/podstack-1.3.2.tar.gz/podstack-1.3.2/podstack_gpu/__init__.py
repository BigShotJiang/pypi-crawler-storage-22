"""
Podstack GPU SDK - Run code on cloud GPUs.

Example usage:
    import podstack

    # Define an image with dependencies
    image = (
        podstack.Image.debian_slim()
        .pip_install("torch", "transformers")
    )

    # Or use a preset environment
    image = podstack.Image.ml()

    # Or install from requirements.txt
    image = podstack.Image.debian_slim().pip_install_from_requirements("requirements.txt")

    # Create an app
    app = podstack.App("my-app")

    # Define a GPU function with full GPU
    @app.function(gpu="H100", image=image)
    def train(epochs: int):
        import torch
        # Print GPU info at start
        podstack.print_gpu_status()
        print(f"Training for {epochs} epochs on {torch.cuda.get_device_name()}")
        return {"status": "done"}

    # Use fractional GPU for cost savings (25%, 50%, 75%, or 100%)
    @app.function(gpu="L40S", fraction=25, image=image)
    def inference(data):
        # Uses 25% of an L40S GPU - great for inference workloads
        return model.predict(data)

    # Run remotely with real-time status tracking
    call = train.spawn(epochs=10)
    for update in call.stream_status():
        print(f"Status: {update.status}")
        if update.queue_position:
            print(f"  Queue position: {update.queue_position}")
    result = call.get()

    # Or use the low-level runner
    # Supports psk_xxx tokens (from cloud.podstack.ai portal) or pjt_xxx tokens (project tokens)
    gpu = podstack.GPURunner(token="psk_xxx", project_id="xxx")
    result = gpu.run("print('hello')", gpu="L40S", fraction=50)  # 50% GPU

    # Custom API URL (optional - defaults to PODSTACK_API_URL env var or production URL)
    gpu = podstack.GPURunner(token="psk_xxx", project_id="xxx", api_url="https://your-api.example.com")

GPU Utilities (use inside your GPU functions):
    podstack.nvidia_smi()        # Get nvidia-smi output
    podstack.gpu_info()          # Get GPU info as dict
    podstack.cuda_available()    # Check if CUDA is available
    podstack.cuda_device_count() # Get number of GPUs
    podstack.print_gpu_status()  # Print formatted GPU status

GPU Types:
    - A10: Entry-level, good for inference
    - L40, L40S: Mid-range, balanced performance
    - A100-40G, A100-80G: High-end training
    - H100: Top-tier performance

Fractional GPU:
    - fraction=25: 25% of GPU (lowest cost, good for small inference)
    - fraction=50: 50% of GPU (balanced)
    - fraction=75: 75% of GPU
    - fraction=100: Full GPU (default, best for training)
"""

from .runner import GPURunner, ExecutionResult, StatusUpdate
from .image import Image, ImageDefinition
from .app import App, Function, FunctionCall, method
from .volume import Volume, CloudBucketMount
from .secret import Secret, SecretDict
from .utils import (
    nvidia_smi,
    gpu_info,
    cuda_available,
    cuda_device_count,
    print_gpu_status,
)
from .exceptions import (
    PodstackError,
    ExecutionError,
    AuthenticationError,
    ValidationError,
    TimeoutError,
    InsufficientBalanceError,
)

__version__ = "0.3.3"

__all__ = [
    # Core classes
    "App",
    "Function",
    "FunctionCall",
    "Image",
    "ImageDefinition",
    "Volume",
    "CloudBucketMount",
    "Secret",
    "SecretDict",
    # Low-level runner
    "GPURunner",
    "ExecutionResult",
    "StatusUpdate",
    # GPU utilities
    "nvidia_smi",
    "gpu_info",
    "cuda_available",
    "cuda_device_count",
    "print_gpu_status",
    # Decorators
    "method",
    # Exceptions
    "PodstackError",
    "ExecutionError",
    "AuthenticationError",
    "ValidationError",
    "TimeoutError",
    "InsufficientBalanceError",
]
