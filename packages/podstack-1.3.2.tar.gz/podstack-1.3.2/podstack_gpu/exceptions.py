"""Podstack SDK exceptions."""


class PodstackError(Exception):
    """Base exception for Podstack SDK."""
    pass


class AuthenticationError(PodstackError):
    """Authentication failed - invalid or expired token."""
    pass


class ValidationError(PodstackError):
    """Invalid parameters or annotation."""
    pass


class ExecutionError(PodstackError):
    """GPU execution failed."""

    def __init__(self, message: str, execution_id: str = None, status: str = None):
        super().__init__(message)
        self.execution_id = execution_id
        self.status = status


class TimeoutError(PodstackError):
    """Execution timed out."""
    pass


class InsufficientBalanceError(PodstackError):
    """Insufficient wallet balance."""
    pass
