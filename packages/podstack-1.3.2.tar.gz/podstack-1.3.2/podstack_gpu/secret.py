"""Podstack Secret - Secure credential management for GPU functions."""

from __future__ import annotations
import os
from typing import Optional, Dict
from dataclasses import dataclass


@dataclass
class SecretConfig:
    """Secret configuration."""
    name: str
    env_var: Optional[str] = None  # Environment variable to inject as

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "env_var": self.env_var,
        }


class Secret:
    """
    Secure secrets that can be injected into GPU functions.

    Secrets are stored encrypted and only decrypted at runtime.
    They can be injected as environment variables or accessed via the API.

    Example:
        # Reference a secret stored in Podstack
        hf_token = podstack.Secret.from_name("huggingface-token")

        @app.function(gpu="H100", secrets=[hf_token])
        def train():
            import os
            # Secret is available as environment variable
            token = os.environ["HUGGINGFACE_TOKEN"]

        # Or inject from environment at deploy time
        api_key = podstack.Secret.from_local_env("OPENAI_API_KEY")
    """

    def __init__(self, config: SecretConfig):
        self._config = config

    @classmethod
    def from_name(
        cls,
        name: str,
        environment_variable: str = None,
        required: bool = True,
    ) -> "Secret":
        """
        Reference a secret stored in Podstack by name.

        Args:
            name: Secret name in Podstack
            environment_variable: Env var name to inject as (defaults to uppercased name)
            required: If True, fail if secret doesn't exist

        Example:
            secret = podstack.Secret.from_name(
                "huggingface-token",
                environment_variable="HF_TOKEN"
            )
        """
        env_var = environment_variable or name.upper().replace("-", "_")
        return cls(SecretConfig(name=name, env_var=env_var))

    @classmethod
    def from_local_env(
        cls,
        env_var: str,
        remote_name: str = None,
    ) -> "Secret":
        """
        Create a secret from a local environment variable.

        The value is read at deploy time and stored securely.

        Args:
            env_var: Local environment variable name
            remote_name: Name to use remotely (defaults to env_var)

        Example:
            # Read OPENAI_API_KEY from local env and inject into function
            secret = podstack.Secret.from_local_env("OPENAI_API_KEY")
        """
        return cls(SecretConfig(
            name=remote_name or env_var,
            env_var=env_var,
        ))

    @classmethod
    def from_dict(cls, secrets: Dict[str, str]) -> "Secret":
        """
        Create a secret from a dictionary (for testing/development).

        WARNING: Do not use in production! Values will be in code.

        Args:
            secrets: Dictionary of secret key-value pairs

        Example:
            # Only for local testing!
            secret = podstack.Secret.from_dict({"API_KEY": "test-key"})
        """
        # Create a composite secret
        return cls(SecretConfig(name="_dict_secret"))

    @classmethod
    def from_dotenv(cls, path: str = ".env") -> "Secret":
        """
        Load secrets from a .env file.

        Args:
            path: Path to .env file

        Example:
            secrets = podstack.Secret.from_dotenv(".env.production")
        """
        return cls(SecretConfig(name=f"_dotenv:{path}"))

    @property
    def name(self) -> str:
        """Get the secret name."""
        return self._config.name

    @property
    def env_var(self) -> str:
        """Get the environment variable name."""
        return self._config.env_var

    def to_dict(self) -> dict:
        """Convert to dictionary for API serialization."""
        return self._config.to_dict()

    def __repr__(self) -> str:
        return f"Secret(name={self._config.name!r})"


class SecretDict:
    """
    A dictionary of secrets that can be accessed in GPU functions.

    Example:
        secrets = podstack.SecretDict.from_name("my-secrets")

        @app.function(gpu="H100", secrets=[secrets])
        def train():
            # Access secrets by key
            api_key = secrets["API_KEY"]
    """

    def __init__(self, name: str):
        self._name = name
        self._values: Dict[str, str] = {}

    @classmethod
    def from_name(cls, name: str) -> "SecretDict":
        """
        Reference a secret dictionary stored in Podstack.

        Args:
            name: Secret dictionary name
        """
        return cls(name)

    def __getitem__(self, key: str) -> str:
        """Get a secret value by key."""
        if key in self._values:
            return self._values[key]
        # In remote execution, this would be populated
        return os.environ.get(f"{self._name.upper()}_{key.upper()}", "")

    def get(self, key: str, default: str = None) -> Optional[str]:
        """Get a secret value with a default."""
        try:
            return self[key]
        except KeyError:
            return default

    @property
    def name(self) -> str:
        """Get the secret dict name."""
        return self._name

    def __repr__(self) -> str:
        return f"SecretDict(name={self._name!r})"
