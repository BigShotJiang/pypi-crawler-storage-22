"""Podstack GPU Utilities - Helper functions for GPU operations."""

import subprocess
import os
from typing import Optional, Dict, Any, List


def nvidia_smi(format: str = "text") -> str:
    """
    Get nvidia-smi output.

    This function runs nvidia-smi and returns the output.
    Use this inside your GPU functions to check GPU status.

    Args:
        format: Output format - "text" (default), "csv", or "xml"

    Returns:
        nvidia-smi output as string

    Example:
        @app.function(gpu="L40S")
        def check_gpu():
            from podstack import nvidia_smi
            print(nvidia_smi())
            return {"gpu_info": nvidia_smi("csv")}
    """
    try:
        if format == "csv":
            cmd = ["nvidia-smi", "--query-gpu=name,memory.total,memory.used,memory.free,utilization.gpu,temperature.gpu", "--format=csv"]
        elif format == "xml":
            cmd = ["nvidia-smi", "-x", "-q"]
        else:
            cmd = ["nvidia-smi"]

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        return result.stdout if result.returncode == 0 else result.stderr
    except FileNotFoundError:
        return "nvidia-smi not found. Make sure NVIDIA drivers are installed."
    except subprocess.TimeoutExpired:
        return "nvidia-smi timed out"
    except Exception as e:
        return f"Error running nvidia-smi: {e}"


def gpu_info() -> Dict[str, Any]:
    """
    Get GPU information as a dictionary.

    Returns:
        Dictionary with GPU information including:
        - name: GPU model name
        - memory_total: Total memory in MB
        - memory_used: Used memory in MB
        - memory_free: Free memory in MB
        - utilization: GPU utilization percentage
        - temperature: GPU temperature in Celsius
        - count: Number of GPUs

    Example:
        @app.function(gpu="L40S")
        def check_resources():
            from podstack import gpu_info
            info = gpu_info()
            print(f"GPU: {info['name']}")
            print(f"Memory: {info['memory_used']}/{info['memory_total']} MB")
            return info
    """
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,memory.total,memory.used,memory.free,utilization.gpu,temperature.gpu,count", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=10
        )

        if result.returncode != 0:
            return {"error": result.stderr}

        lines = result.stdout.strip().split("\n")
        gpus = []

        for line in lines:
            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 6:
                gpus.append({
                    "name": parts[0],
                    "memory_total": int(parts[1]) if parts[1].isdigit() else parts[1],
                    "memory_used": int(parts[2]) if parts[2].isdigit() else parts[2],
                    "memory_free": int(parts[3]) if parts[3].isdigit() else parts[3],
                    "utilization": int(parts[4]) if parts[4].isdigit() else parts[4],
                    "temperature": int(parts[5]) if parts[5].isdigit() else parts[5],
                })

        if len(gpus) == 1:
            return gpus[0]

        return {
            "count": len(gpus),
            "gpus": gpus,
            "name": gpus[0]["name"] if gpus else "Unknown",
            "memory_total": sum(g.get("memory_total", 0) for g in gpus if isinstance(g.get("memory_total"), int)),
            "memory_used": sum(g.get("memory_used", 0) for g in gpus if isinstance(g.get("memory_used"), int)),
            "memory_free": sum(g.get("memory_free", 0) for g in gpus if isinstance(g.get("memory_free"), int)),
        }

    except FileNotFoundError:
        return {"error": "nvidia-smi not found"}
    except Exception as e:
        return {"error": str(e)}


def cuda_available() -> bool:
    """
    Check if CUDA is available.

    Returns:
        True if CUDA is available, False otherwise

    Example:
        @app.function(gpu="L40S")
        def train():
            from podstack import cuda_available
            if cuda_available():
                print("CUDA is ready!")
            else:
                print("Warning: CUDA not available")
    """
    try:
        import torch
        return torch.cuda.is_available()
    except ImportError:
        # Fallback to checking nvidia-smi
        try:
            result = subprocess.run(["nvidia-smi"], capture_output=True, timeout=5)
            return result.returncode == 0
        except:
            return False


def cuda_device_count() -> int:
    """
    Get the number of available CUDA devices.

    Returns:
        Number of CUDA devices

    Example:
        @app.function(gpu="A100-80G", count=4)
        def distributed_train():
            from podstack import cuda_device_count
            print(f"Training on {cuda_device_count()} GPUs")
    """
    try:
        import torch
        return torch.cuda.device_count()
    except ImportError:
        # Fallback
        info = gpu_info()
        return info.get("count", 1) if "error" not in info else 0


def print_gpu_status():
    """
    Print a formatted GPU status summary.

    Example:
        @app.function(gpu="L40S")
        def my_function():
            from podstack import print_gpu_status
            print_gpu_status()
            # ... your code ...
    """
    print("=" * 60)
    print("GPU STATUS")
    print("=" * 60)

    info = gpu_info()

    if "error" in info:
        print(f"Error: {info['error']}")
        return

    if "gpus" in info:
        # Multiple GPUs
        print(f"Total GPUs: {info['count']}")
        print(f"Total Memory: {info['memory_used']:,} / {info['memory_total']:,} MB")
        print("-" * 60)
        for i, gpu in enumerate(info["gpus"]):
            print(f"GPU {i}: {gpu['name']}")
            print(f"  Memory: {gpu['memory_used']:,} / {gpu['memory_total']:,} MB ({gpu['memory_free']:,} MB free)")
            print(f"  Utilization: {gpu['utilization']}%")
            print(f"  Temperature: {gpu['temperature']}°C")
    else:
        # Single GPU
        print(f"GPU: {info.get('name', 'Unknown')}")
        mem_used = info.get('memory_used', 0)
        mem_total = info.get('memory_total', 0)
        mem_free = info.get('memory_free', 0)
        if isinstance(mem_used, int) and isinstance(mem_total, int):
            print(f"Memory: {mem_used:,} / {mem_total:,} MB ({mem_free:,} MB free)")
        print(f"Utilization: {info.get('utilization', 'N/A')}%")
        print(f"Temperature: {info.get('temperature', 'N/A')}°C")

    print("=" * 60)
