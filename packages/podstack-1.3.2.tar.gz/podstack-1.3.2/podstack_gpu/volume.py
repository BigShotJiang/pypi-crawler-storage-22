"""Podstack Volume - Persistent storage for GPU functions."""

from __future__ import annotations
import os
from typing import Optional
from dataclasses import dataclass


@dataclass
class VolumeConfig:
    """Volume configuration."""
    name: str
    size_gb: int = 10
    region: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "size_gb": self.size_gb,
            "region": self.region,
        }


class Volume:
    """
    Persistent network storage that can be attached to GPU functions.

    Volumes persist data across function invocations and can be shared
    between functions.

    Example:
        # Create a volume
        model_volume = podstack.Volume.from_name("model-cache", create_if_missing=True)

        @app.function(gpu="H100", volumes={"/models": model_volume})
        def train():
            # Save models to /models - they persist!
            torch.save(model, "/models/checkpoint.pt")

        @app.function(gpu="H100", volumes={"/models": model_volume})
        def inference():
            # Load the model saved during training
            model = torch.load("/models/checkpoint.pt")
    """

    def __init__(self, config: VolumeConfig):
        self._config = config
        self._persisted = False

    @classmethod
    def from_name(
        cls,
        name: str,
        create_if_missing: bool = True,
        size_gb: int = 10,
        region: str = None,
    ) -> "Volume":
        """
        Get or create a volume by name.

        Args:
            name: Volume name (must be unique within project)
            create_if_missing: Create the volume if it doesn't exist
            size_gb: Size in GB (only used when creating)
            region: Region for the volume (optional)

        Example:
            volume = podstack.Volume.from_name("my-data", size_gb=100)
        """
        return cls(VolumeConfig(
            name=name,
            size_gb=size_gb,
            region=region,
        ))

    @classmethod
    def ephemeral(cls, size_gb: int = 10) -> "Volume":
        """
        Create an ephemeral volume that only lasts for the function invocation.

        Useful for temporary storage during execution.

        Args:
            size_gb: Size in GB

        Example:
            temp = podstack.Volume.ephemeral(size_gb=50)

            @app.function(gpu="H100", volumes={"/scratch": temp})
            def process():
                # Use /scratch for temporary files
                ...
        """
        import uuid
        return cls(VolumeConfig(
            name=f"ephemeral-{uuid.uuid4().hex[:8]}",
            size_gb=size_gb,
        ))

    @property
    def name(self) -> str:
        """Get the volume name."""
        return self._config.name

    @property
    def size_gb(self) -> int:
        """Get the volume size in GB."""
        return self._config.size_gb

    def to_dict(self) -> dict:
        """Convert to dictionary for API serialization."""
        return self._config.to_dict()

    def __repr__(self) -> str:
        return f"Volume(name={self._config.name!r}, size_gb={self._config.size_gb})"


class CloudBucketMount:
    """
    Mount a cloud storage bucket (S3, GCS, etc.) as a volume.

    Example:
        bucket = podstack.CloudBucketMount.from_s3(
            bucket_name="my-training-data",
            secret=podstack.Secret.from_name("aws-credentials"),
        )

        @app.function(gpu="H100", volumes={"/data": bucket})
        def train():
            # Access S3 data at /data
            data = load_data("/data/dataset.parquet")
    """

    def __init__(
        self,
        bucket_name: str,
        provider: str,
        secret: "Secret" = None,
        read_only: bool = False,
        prefix: str = None,
    ):
        self._bucket_name = bucket_name
        self._provider = provider
        self._secret = secret
        self._read_only = read_only
        self._prefix = prefix

    @classmethod
    def from_s3(
        cls,
        bucket_name: str,
        secret: "Secret" = None,
        read_only: bool = False,
        prefix: str = None,
    ) -> "CloudBucketMount":
        """
        Mount an S3 bucket.

        Args:
            bucket_name: S3 bucket name
            secret: Secret containing AWS credentials
            read_only: Mount as read-only
            prefix: Only mount objects with this prefix
        """
        return cls(bucket_name, "s3", secret, read_only, prefix)

    @classmethod
    def from_gcs(
        cls,
        bucket_name: str,
        secret: "Secret" = None,
        read_only: bool = False,
        prefix: str = None,
    ) -> "CloudBucketMount":
        """
        Mount a Google Cloud Storage bucket.

        Args:
            bucket_name: GCS bucket name
            secret: Secret containing GCP credentials
            read_only: Mount as read-only
            prefix: Only mount objects with this prefix
        """
        return cls(bucket_name, "gcs", secret, read_only, prefix)

    def to_dict(self) -> dict:
        """Convert to dictionary for API serialization."""
        return {
            "type": "cloud_bucket",
            "bucket_name": self._bucket_name,
            "provider": self._provider,
            "secret": self._secret.name if self._secret else None,
            "read_only": self._read_only,
            "prefix": self._prefix,
        }

    def __repr__(self) -> str:
        return f"CloudBucketMount({self._provider}://{self._bucket_name})"
