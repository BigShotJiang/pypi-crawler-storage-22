"""Healthcheck command for pointguard CLI."""

from .cli import healthcheck

__all__ = ["healthcheck"]
