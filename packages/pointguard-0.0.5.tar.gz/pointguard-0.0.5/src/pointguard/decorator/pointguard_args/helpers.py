import inspect
import logging
from typing import Any, Dict, Optional, Callable

from .. import arguments_helpers
from ...api_objects import trace, data_helpers
from . import api_classes


LOGGER = logging.getLogger(__name__)


def extract_pointguard_args(
    kwargs: Dict[str, Any], func: Callable
) -> Optional[api_classes.pointguardArgs]:
    """
    Extracts pointguard_args from kwargs and returns the parsed pointguardArgs or None.

    Mutates kwargs in place by removing "pointguard_args" if the function does not explicitly
    declare pointguard_args as a parameter.

    Args:
        kwargs: Function keyword arguments
        func: The function being decorated

    Returns:
        pointguard_args if found, otherwise None.
    """

    # Check if a function has pointguard_args in its signature
    try:
        sig = inspect.signature(func)
        has_pointguard_args_param = "pointguard_args" in sig.parameters
    except (ValueError, TypeError):
        # If we can't inspect the signature, assume no pointguard_args parameter
        has_pointguard_args_param = False

    # If function explicitly has pointguard_args parameter, just get it without popping
    if has_pointguard_args_param:
        pointguard_args_dict = kwargs.get("pointguard_args", None)
    else:
        # If function doesn't have pointguard_args parameter, pop it from kwargs
        pointguard_args_dict = kwargs.pop("pointguard_args", None)

    if pointguard_args_dict is None:
        return None

    return api_classes.pointguardArgs.from_dict(pointguard_args_dict)


def apply_pointguard_args_to_trace(
    pointguard_args: Optional[api_classes.pointguardArgs],
    trace_data: Optional[trace.TraceData],
) -> None:
    """
    Apply pointguard_args to the trace data, including thread_id, tags, and metadata.

    Args:
        pointguard_args: The configuration extracted from function arguments
        trace_data: The current trace data to modify
    """
    if pointguard_args is None or pointguard_args.trace_args is None or trace_data is None:
        return

    # Handle thread_id
    if pointguard_args.trace_args.thread_id is not None:
        # Check for thread_id conflict
        if (
            trace_data.thread_id is not None
            and trace_data.thread_id != pointguard_args.trace_args.thread_id
        ):
            LOGGER.warning(
                "Trace already has thread_id='%s', but pointguard_args specifies thread_id='%s'. Keeping existing thread_id.",
                trace_data.thread_id,
                pointguard_args.trace_args.thread_id,
            )
        else:
            # Apply thread_id to trace
            trace_data.thread_id = pointguard_args.trace_args.thread_id

    # Apply trace tags if specified
    if pointguard_args.trace_args.tags:
        existing_tags = trace_data.tags or []
        merged_tags = data_helpers.merge_tags(existing_tags, pointguard_args.trace_args.tags)
        trace_data.tags = merged_tags

    # Apply trace metadata if specified
    if pointguard_args.trace_args.metadata:
        existing_metadata = trace_data.metadata or {}
        merged_metadata = data_helpers.merge_metadata(
            existing_metadata, pointguard_args.trace_args.metadata
        )
        trace_data.metadata = merged_metadata


def apply_pointguard_args_to_start_span_params(
    params: arguments_helpers.StartSpanParameters,
    pointguard_args: Optional[api_classes.pointguardArgs],
) -> arguments_helpers.StartSpanParameters:
    """Apply pointguard_args to StartSpanParameters, merging tags and metadata."""
    if pointguard_args is None or pointguard_args.span_args is None:
        return params

    span_config = pointguard_args.span_args

    # Merge tags and metadata
    merged_tags = data_helpers.merge_tags(params.tags, span_config.tags)
    merged_metadata = data_helpers.merge_metadata(params.metadata, span_config.metadata)

    # Create updated parameters
    return arguments_helpers.StartSpanParameters(
        type=params.type,
        name=params.name,
        tags=merged_tags,
        metadata=merged_metadata,
        input=params.input,
        project_name=params.project_name,
        model=params.model,
        provider=params.provider,
    )
