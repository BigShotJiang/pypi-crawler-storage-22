from typing import Dict, Any


def add_pointguard_tracer_to_params(params: Dict[str, Any]) -> Dict[str, Any]:
    from pointguard.integrations.langchain import pointguardTracer

    pointguard_tracer = pointguardTracer()

    if "config" not in params:
        params["config"] = {}

    if "callbacks" not in params["config"]:
        params["config"]["callbacks"] = [pointguard_tracer]
        return params

    callbacks = params["config"]["callbacks"]
    for callback in callbacks:
        if isinstance(callback, pointguard_tracer.__class__):
            return params

    callbacks.append(pointguard_tracer)

    return params
