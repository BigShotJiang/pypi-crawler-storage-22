import functools
from typing import Any, Dict, Optional, TYPE_CHECKING

import pointguard.config as config
import pointguard.pointguard_context as pointguard_context

if TYPE_CHECKING:
    import litellm


def lazy_import_pointguardLogger() -> Optional["litellm.integrations.pointguard.pointguard.pointguardLogger"]:
    try:
        from litellm.integrations.pointguard.pointguard import pointguardLogger

        return pointguardLogger
    except ImportError:
        return None


def try_add_pointguard_monitoring_to_params(params: Dict[str, Any]) -> Dict[str, Any]:
    if lazy_import_pointguardLogger() is None:
        return params

    import litellm

    already_decorated = hasattr(litellm.completion, "pointguard_tracked")
    if already_decorated:
        return params

    params = _add_span_metadata_to_params(params)
    params = _ensure_params_have_callback(params)
    return params


@functools.lru_cache
def enabled_in_config() -> bool:
    config_ = config.pointguardConfig()
    return config_.enable_litellm_models_monitoring


@functools.lru_cache
def pointguard_is_misconfigured() -> bool:
    config_ = config.pointguardConfig()
    return config_.check_for_known_misconfigurations()


def _add_span_metadata_to_params(params: Dict[str, Any]) -> Dict[str, Any]:
    current_span = pointguard_context.get_current_span_data()

    if current_span is None:
        return params

    if "current_span_data" in params.get("metadata", {}).get("pointguard", {}):
        return params

    metadata = {
        **params.get("metadata", {}),
        "pointguard": {
            **params.get("metadata", {}).get("pointguard", {}),
            "current_span_data": current_span,
        },
    }
    if current_span.project_name is not None:
        metadata["pointguard"]["project_name"] = current_span.project_name

    return {**params, "metadata": metadata}


def _ensure_params_have_callback(params: Dict[str, Any]) -> Dict[str, Any]:
    import litellm

    has_global_pointguard_logger = False
    has_local_pointguard_logger = False

    if pointguardLoggerClass := lazy_import_pointguardLogger():
        has_global_pointguard_logger = any(
            isinstance(callback, pointguardLoggerClass) for callback in litellm.callbacks
        )

        has_local_pointguard_logger = any(
            isinstance(callback, pointguardLoggerClass)
            for callback in params.get("success_callback", [])
        )

    if has_global_pointguard_logger or has_local_pointguard_logger:
        return params

    pointguard_logger = _callback_instance()

    return {
        **params,
        "success_callback": [pointguard_logger, *params.get("success_callback", [])],
        "failure_callback": [pointguard_logger, *params.get("error_callback", [])],
    }


@functools.lru_cache()
def _callback_instance() -> "litellm.integrations.pointguard.pointguard.pointguardLogger":  # type: ignore
    pointguardLoggerClass = lazy_import_pointguardLogger()
    assert pointguardLoggerClass is not None
    return pointguardLoggerClass()
