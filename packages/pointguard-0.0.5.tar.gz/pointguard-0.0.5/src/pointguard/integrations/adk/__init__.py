import google.adk
from pointguard import semantic_version

if semantic_version.SemanticVersion.parse(google.adk.__version__) < "1.3.0":  # type: ignore
    from .legacy_pointguard_tracer import LegacypointguardTracer as pointguardTracer
else:
    # Keep this import second to avoid static analyzers confusion
    from .pointguard_tracer import pointguardTracer  # type: ignore

from .recursive_callback_injector import track_adk_agent_recursive
from .graph.mermaid_graph_builder import build_mermaid_graph_definition


__all__ = ["pointguardTracer", "track_adk_agent_recursive", "build_mermaid_graph_definition"]
