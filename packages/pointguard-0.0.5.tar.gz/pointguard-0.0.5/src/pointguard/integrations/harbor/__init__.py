"""
pointguard integration for Harbor benchmark evaluation framework.

Example:
    >>> from pointguard.integrations.harbor import track_harbor
    >>> job = Job(config)
    >>> tracked_job = track_harbor(job)
    >>> result = await tracked_job.run()

Or enable tracking globally (for CLI usage):
    >>> from pointguard.integrations.harbor import track_harbor
    >>> track_harbor()
"""

from .pointguard_tracker import track_harbor, reset_harbor_tracking

__all__ = ["track_harbor", "reset_harbor_tracking"]
