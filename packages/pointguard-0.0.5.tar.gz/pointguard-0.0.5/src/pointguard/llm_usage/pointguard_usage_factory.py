import logging
from typing import Any, Callable, Dict, List, Optional, Union

from pointguard.types import LLMProvider
from . import pointguard_usage


# One provider can have multiple formats of usage dicts, so it can have more than 1 build function
_PROVIDER_TO_pointguard_USAGE_BUILDERS: Dict[
    Union[str, LLMProvider],
    List[Callable[[Dict[str, Any]], pointguard_usage.pointguardUsage]],
] = {
    LLMProvider.OPENAI: [
        pointguard_usage.pointguardUsage.from_openai_completions_dict,
        pointguard_usage.pointguardUsage.from_openai_responses_dict,
    ],
    LLMProvider.GOOGLE_VERTEXAI: [pointguard_usage.pointguardUsage.from_google_dict],
    LLMProvider.GOOGLE_AI: [pointguard_usage.pointguardUsage.from_google_dict],
    LLMProvider.ANTHROPIC: [pointguard_usage.pointguardUsage.from_anthropic_dict],
    LLMProvider.BEDROCK: [pointguard_usage.pointguardUsage.from_bedrock_dict],
}


def build_pointguard_usage(
    provider: Union[str, LLMProvider],
    usage: Dict[str, Any],
) -> pointguard_usage.pointguardUsage:
    build_functions = _PROVIDER_TO_pointguard_USAGE_BUILDERS[provider]

    exc = None
    for build_function in build_functions:
        try:
            result = build_function(usage)
            return result
        except Exception as exc_info:
            exc = exc_info
            pass

    raise ValueError(
        f"Failed to build pointguardUsage for provider {provider} and usage {usage}, reason: {exc}"
    )


def build_pointguard_usage_from_unknown_provider(
    usage: Dict[str, Any],
) -> pointguard_usage.pointguardUsage:
    for build_functions in _PROVIDER_TO_pointguard_USAGE_BUILDERS.values():
        for build_function in build_functions:
            try:
                pointguard_usage_ = build_function(usage)
                return pointguard_usage_
            except Exception:
                pass

    return pointguard_usage.pointguardUsage.from_unknown_usage_dict(usage)


def try_build_pointguard_usage_or_log_error(
    provider: Union[str, LLMProvider],
    usage: Dict[str, Any],
    logger: logging.Logger,
    error_message: str,
) -> Optional[pointguard_usage.pointguardUsage]:
    try:
        return build_pointguard_usage(provider=provider, usage=usage)
    except Exception:
        logger.error(error_message, exc_info=True)
        return None
