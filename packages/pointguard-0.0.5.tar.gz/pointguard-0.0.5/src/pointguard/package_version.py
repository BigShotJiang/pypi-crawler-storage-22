import importlib.metadata


def _get_package_version() -> str:
    try:
        return importlib.metadata.version("pointguard")
    except importlib.metadata.PackageNotFoundError:
        return "Please install pointguard with `pip install pointguard`"


VERSION = _get_package_version()
