"""
Polarity Network Motifs - A Python package for detecting and analyzing network motifs in signed/typed networks.

This package provides tools for:
- Enumerating subgraphs in directed networks using various algorithms
- Identifying statistically significant motifs via comparison to random networks
- Supporting polarity/sign-aware motif detection
- Extensible plugin architecture for custom loaders, algorithms, and randomizers
"""

from .api import MotifSearch, MotifResults
from .loaders import from_networkx, from_scipy_sparse, from_edgelist
from .network import Network

# Export ABC base classes for user extensions
from .subgraphs.sub_graphs_abc import SubGraphsABC
from .random_networks.network_randomizer_abc import NetworkRandomizer

# Export built-in algorithms
from .subgraphs.mfinder_enum_induced import MFinderInduced
from .subgraphs.mfinder_enum_none_induced import MFinderNoneInduced
from .subgraphs.fanmod_esu import FanmodESU
from .subgraphs.triadic_census import TriadicCensus
from .subgraphs.netsci_wrapper import NetsciWrapper

# Export built-in randomizers
from .random_networks.markov_chain_switching import MarkovChainSwitching
from .random_networks.erdos_renyi import ErdosRenyi
from .random_networks.barabasi_albert import BarabasiAlbert
from .random_networks.configuration_model import ConfigurationModel

__version__ = "0.1.0"
__all__ = [
    # Main API
    "MotifSearch",
    "MotifResults",
    # Convenience loaders
    "from_networkx",
    "from_scipy_sparse",
    "from_edgelist",
    "Network",
    # Base classes for extensions
    "SubGraphsABC",
    "NetworkRandomizer",
    # Built-in algorithms
    "MFinderInduced",
    "MFinderNoneInduced",
    "FanmodESU",
    "TriadicCensus",
    "NetsciWrapper",
    # Built-in randomizers
    "MarkovChainSwitching",
    "ErdosRenyi",
    "BarabasiAlbert",
    "ConfigurationModel",
]
