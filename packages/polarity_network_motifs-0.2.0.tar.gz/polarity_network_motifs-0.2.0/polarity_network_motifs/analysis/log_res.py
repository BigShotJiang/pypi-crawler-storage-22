"""
Result display utilities for motif analysis.
"""
from tabulate import tabulate
from polarity_network_motifs.api import MotifResults, MotifSearch
from polarity_network_motifs.utils.types import Motif, MotifCriteriaResults


def print_motifs_table(motifs: list[Motif], verbose: bool = False):
    """
    Print a formatted table of motif results.

    Args:
        motifs: List of Motif objects to display
        verbose: If True, show detailed information including node appearances
    """
    if not motifs:
        print("No motifs to display")
        return

    # Sort motifs by ID (extract int from id which could be int or string)
    sorted_motifs = sorted(motifs, key=lambda m: int(str(m.id).split()[0]))

    table = []
    for motif in sorted_motifs:
        motif_criteria_res = motif.motif_criteria if motif.motif_criteria is not None else MotifCriteriaResults(
            n_real=motif.n_real,
        )

        row = [
            motif.id,
            motif.name,
            motif_criteria_res.n_real,
            f"{motif_criteria_res.n_rand:.2f}" if motif_criteria_res.n_rand else "N/A",
            f"{motif_criteria_res.std:.2f}" if motif_criteria_res.std else "N/A",
            (f"{motif_criteria_res.z_score:.2f}"
             if motif_criteria_res.z_score else "N/A"),
            (motif_criteria_res.is_statistically_significant
             if motif_criteria_res.is_statistically_significant is not None
             else "N/A"),
            motif_criteria_res.is_motif if motif_criteria_res.is_motif else "N/A",
        ]
        table.append(row)

    headers = ['ID', 'Name', 'N_real', 'N_rand', 'Std', 'Z-score', 'Significant', 'Type']

    print("\n" + "=" * 80)
    print("MOTIF ANALYSIS RESULTS")
    print("=" * 80)
    print(tabulate(table, headers=headers, tablefmt="grid", numalign="center", stralign="center"))

    # Show detailed information if verbose
    if verbose:
        print("\n" + "=" * 80)
        print("DETAILED MOTIF INFORMATION")
        print("=" * 80)

        for motif in sorted_motifs:
            if motif.n_real == 0:
                continue

            print(f"\nMotif ID: {motif.id}")
            print(f"Name: {motif.name}")
            print(f"Role pattern: {motif.role_pattern}")

            if motif.node_appearances:
                print(f"Node appearances: {motif.node_appearances}")

            if motif.node_roles:
                for role in motif.node_roles:
                    print(f"  Role {role}: {motif.node_roles[role]}")

            if motif.polarity_motifs:
                print("Polarity variants:")
                for pol_motif in motif.polarity_motifs:
                    if pol_motif.n_real:
                        print(f"  {pol_motif.polarity}: {pol_motif.n_real}")


def print_search_summary(search: MotifSearch):
    """
    Print a summary of the motif search results and configuration.

    Args:
        search: MotifSearch object
    """
    results: MotifResults = search.results
    if results is None:
        print("No search results available. Run search.run() first.")
        return

    print("\n" + "=" * 80)
    print("MOTIF SEARCH SUMMARY")
    print("=" * 80)

    motifs_list = list(results.motifs.values())
    non_zero_found = sum(1 for m in motifs_list if m.n_real > 0)
    total_sub_graphs = sum(m.n_real for m in motifs_list)

    print(f"Total motif candidates found: {non_zero_found}")
    print(f"Total sub-graphs enumerated: {total_sub_graphs}")
    print(f"Analysis completed in: {results.elapsed_time:.2f} seconds")

    # Show significant motifs
    significant = results.get_significant_motifs()
    if significant:
        print(f"Statistically significant motifs: {len(significant)}")

    # Show configuration
    print("\nSearch Configuration:")
    print(f"  motif size (k): {search.k}")
    print(f"  algorithm: {search.algorithm.__name__}")
    print(f"  randomizer: {search.randomizer.__name__ if search.randomizer else 'None'}")
    print(f"  num_random_networks: {search.num_random_networks}")
    print(f"  alpha: {search.motif_criteria.alpha}")
    print(f"  frequency_threshold: {search.motif_criteria.frequency_threshold}")
    print(f"  allow_self_loops: {search.allow_self_loops}")
    print(f"  use_isomorphic_mapping: {search.use_isomorphic_mapping}")

    print("=" * 80)
