"""
Mock test for plot_large module.

This is a simple test to verify the plotting functions work without errors.
"""
# import matplotlib
# matplotlib.use('Agg')  # Use non-GUI backend for testing

import matplotlib.pyplot as plt
import numpy as np
from polarity_network_motifs.utils.types import Motif, MotifCriteriaResults
from polarity_network_motifs.analysis.plot_large import draw_motif, plot_motifs_z, plot_z_score_scatter


def create_mock_motif(motif_id, name, n_real=10, z_score=2.5):
    """Create a mock motif for testing."""
    # Create simple adjacency matrix for a triangle
    adj_mat = np.array([[0, 1, 1],
                       [0, 0, 1],
                       [0, 0, 0]])

    role_pattern = [('a', 'b'), ('a', 'c'), ('b', 'c')]

    motif_criteria = MotifCriteriaResults(
        n_real=n_real,
        z_score=z_score,
        std=1.0,
        n_rand=5.0,
        is_statistically_significant=True
    )

    motif = Motif(
        name=name,
        id=motif_id,
        adj_mat=adj_mat,
        role_pattern=role_pattern,
        n_real=n_real,
        motif_criteria=motif_criteria
    )

    return motif


def create_mock_polarity_motif():
    """Create a mock motif with polarity."""
    motif = create_mock_motif(38, "feed_forward", n_real=15, z_score=3.2)
    motif.polarity = ['+', '-', '+']
    return motif


def test_draw_motif():
    """Test drawing a single motif."""
    print("Testing draw_motif()...")
    motif = create_mock_motif(38, "feed_forward")

    fig, ax = plt.subplots(figsize=(4, 4))
    draw_motif(motif, ax)
    plt.show()
    print("✓ draw_motif() completed successfully")


def test_draw_motif_with_polarity():
    """Test drawing a motif with polarity."""
    print("Testing draw_motif() with polarity...")
    motif = create_mock_polarity_motif()

    fig, ax = plt.subplots(figsize=(4, 4))
    draw_motif(motif, ax)
    plt.show()
    print("✓ draw_motif() with polarity completed successfully")


def test_plot_motifs_z():
    """Test plotting motifs sorted by Z-score."""
    print("Testing plot_motifs_z()...")
    motifs = [
        create_mock_motif(38, "feed_forward", n_real=15, z_score=3.2),
        create_mock_motif(14, "mutual_out", n_real=10, z_score=2.1),
        create_mock_motif(74, "mutual_in", n_real=8, z_score=-1.5),
        create_mock_motif(6, "fan_out", n_real=5, z_score=0.8),
    ]

    fig, axes = plot_motifs_z(motifs, title="Test Motifs Z-score")
    if fig:
        plt.show()
    print("✓ plot_motifs_z() completed successfully")


def test_plot_z_score_scatter():
    """Test Z-score scatter plot."""
    print("Testing plot_z_score_scatter()...")
    motifs = [
        create_mock_motif(38, "feed_forward", n_real=15, z_score=3.2),
        create_mock_motif(14, "mutual_out", n_real=10, z_score=2.1),
        create_mock_motif(74, "mutual_in", n_real=8, z_score=-1.5),
        create_mock_motif(6, "fan_out", n_real=5, z_score=0.8),
        create_mock_motif(12, "cascade", n_real=3, z_score=-0.5),
    ]

    fig, ax = plot_z_score_scatter(motifs, title="Test Z-score vs N_real")
    if fig:
        plt.show()
    print("✓ plot_z_score_scatter() completed successfully")


def test_empty_motifs():
    """Test with empty motif list."""
    print("Testing with empty motifs...")
    fig, axes = plot_motifs_z([], title="Empty Test")
    assert fig is None
    print("✓ Empty motifs handled correctly")


def test_motifs_without_criteria():
    """Test with motifs without criteria."""
    print("Testing with motifs without criteria...")
    motif = Motif(
        name="test",
        id=1,
        adj_mat=np.array([[0, 1], [0, 0]]),
        role_pattern=[('a', 'b')],
        n_real=5
    )

    fig, axes = plot_motifs_z([motif], title="No Criteria Test")
    assert fig is None
    print("✓ Motifs without criteria handled correctly")


def main():
    """Run all tests."""
    print("=" * 70)
    print("Running plot_large mock tests")
    print("=" * 70)
    print()

    test_draw_motif()
    test_draw_motif_with_polarity()
    test_plot_motifs_z()
    test_plot_z_score_scatter()
    test_empty_motifs()
    test_motifs_without_criteria()

    print()
    print("=" * 70)
    print("All tests passed! ✓")
    print("=" * 70)


if __name__ == '__main__':
    main()
