"""
Mock plotting script for manual testing of plot functions.
Run this script to visually test the plotting logic.
"""
import numpy as np
import matplotlib.pyplot as plt
from plots import plot_Z_nice


class MockMotifCriteria:
    """Mock motif criteria for testing."""

    def __init__(self, z_score=0.0):
        self.z_score = z_score


class MockMotif:
    """Mock motif for testing plots."""

    def __init__(self, motif_id, name, role_pattern, n_real=10, z_score=0.0, polarity=None):
        self.id = motif_id
        self.name = name
        self.role_pattern = role_pattern
        self.n_real = n_real
        self.motif_criteria = MockMotifCriteria(z_score)
        self.polarity = polarity or []
        self.adj_mat = np.array([[0, 1], [0, 0]]) if len(role_pattern) == 1 else np.array([[0, 1, 0], [0, 0, 1], [1, 0, 0]])


def test_k2_motifs():
    """Test plotting k=2 motifs."""
    print("Testing k=2 motifs...")

    # Create mock k=2 motifs
    motif1 = MockMotif(
        motif_id=2,
        name="unidirectional",
        role_pattern=[('a', 'b')],
        n_real=50,
        z_score=2.5,
        polarity=['+']
    )

    motif2 = MockMotif(
        motif_id=6,
        name="mutual regulation",
        role_pattern=[('a', 'b'), ('b', 'a')],
        n_real=30,
        z_score=-1.5,
        polarity=['+', '-']
    )

    motifs = [motif1, motif2]

    # Test plotting
    plot_Z_nice(motifs)
    plt.show()
    plt.close('all')


def test_k3_motifs():
    """Test plotting k=3 motifs."""
    print("\nTesting k=3 motifs...")

    # Create mock k=3 motifs
    motif1 = MockMotif(
        motif_id=38,
        name="feed forward",
        role_pattern=[('a', 'b'), ('b', 'c'), ('a', 'c')],
        n_real=100,
        z_score=3.2,
        polarity=['+', '+', '-']
    )

    motif2 = MockMotif(
        motif_id=78,
        name="bi-mutual",
        role_pattern=[('a', 'b'), ('b', 'a'), ('b', 'c'), ('c', 'b')],
        n_real=25,
        z_score=-2.1,
        polarity=['+', '-', '+', '-']
    )

    motif3 = MockMotif(
        motif_id=110,
        name="semi clique",
        role_pattern=[('a', 'b'), ('a', 'c')],
        n_real=0,
        z_score=None,  # Test None z_score
        polarity=['+', '+']
    )

    motifs = [motif1, motif2, motif3]

    # Test plotting
    plot_Z_nice(motifs)
    plt.show()
    plt.close('all')


def test_mixed_motifs():
    """Test plotting mixed k=2 and k=3 motifs together."""
    print("\nTesting mixed k=2 and k=3 motifs...")

    motif_k2 = MockMotif(
        motif_id=2,
        name="unidirectional",
        role_pattern=[('a', 'b')],
        n_real=40,
        z_score=1.8,
        polarity=['+']
    )

    motif_k3 = MockMotif(
        motif_id=38,
        name="feed forward",
        role_pattern=[('a', 'b'), ('b', 'c'), ('a', 'c')],
        n_real=60,
        z_score=2.5,
        polarity=['+', '+', '-']
    )

    motifs = [motif_k2, motif_k3]

    # Test plotting
    plot_Z_nice(motifs)
    plt.show()
    plt.close('all')


if __name__ == '__main__':
    print("=" * 70)
    print("Mock Plot Testing")
    print("=" * 70)

    test_k2_motifs()
    test_k3_motifs()
    test_mixed_motifs()

    print("\n" + "=" * 70)
    print("All tests completed!")
    print("=" * 70)
