"""
Plotting utilities for large motifs (K=4 and K=5).

These functions are adapted from the old master branch motif_analysis.ipynb
for visualizing motifs and their Z-scores.
"""
import matplotlib.pyplot as plt
import networkx as nx
from matplotlib.patches import ArrowStyle
from polarity_network_motifs.utils.types import Motif


def draw_motif(motif: Motif, ax):
    """
    Draw a single motif graph.

    Args:
        motif: Motif object to draw
        ax: Matplotlib axis to draw on
    """
    as_ = ArrowStyle("simple", head_length=1.5, head_width=2.5, tail_width=.4)
    ax.axis('off')

    motif_id = motif.id.replace('complex', 'c') if isinstance(motif.id, str) else motif.id
    title = f'{motif.name}-{motif_id}' if motif.name != 'n/a' else motif_id
    ax.set_title(title, fontsize=7.5)

    graph = nx.DiGraph(motif.role_pattern)
    pos = nx.circular_layout(graph)
    nx.draw_networkx(graph, pos, ax=ax, arrowsize=5, arrowstyle=as_)

    if motif.polarity:
        for role, pol in zip(motif.role_pattern, motif.polarity):
            s, t = role
            graph[s][t]['polarity'] = 'c' if pol == 'complex' else pol

        edge_labels = nx.get_edge_attributes(graph, 'polarity')
        nx.draw_networkx_edge_labels(graph, pos, edge_labels=edge_labels, ax=ax,
                                     font_color='k', font_weight='bold', label_pos=0.3)


def plot_motifs_z(motifs: list[Motif], title: str = "Motifs Z-score", figsize=(12, 8)):
    """
    Plot motifs sorted by Z-score with their visualizations.

    Args:
        motifs: List of Motif objects to plot
        title: Plot title
        figsize: Figure size tuple

    Returns:
        tuple: (fig, axes) matplotlib figure and axes
    """
    # Filter motifs with valid Z-scores and sort by Z-score
    valid_motifs = [m for m in motifs if m.motif_criteria and m.motif_criteria.z_score is not None]
    sorted_motifs = sorted(valid_motifs, key=lambda m: m.motif_criteria.z_score, reverse=True)

    if not sorted_motifs:
        print("No motifs with Z-scores to plot")
        return None, None

    # Calculate grid dimensions
    num_motifs = len(sorted_motifs)
    cols = min(5, num_motifs)
    rows = (num_motifs + cols - 1) // cols

    fig, axes = plt.subplots(nrows=rows, ncols=cols, figsize=figsize)
    fig.suptitle(title, fontsize=14, fontweight='bold')

    # Handle single row/column cases
    if rows == 1 and cols == 1:
        axes = [[axes]]
    elif rows == 1:
        axes = [axes]
    elif cols == 1:
        axes = [[ax] for ax in axes]

    # Plot each motif
    for idx, motif in enumerate(sorted_motifs):
        row = idx // cols
        col = idx % cols
        ax = axes[row][col]

        draw_motif(motif, ax)

        # Add Z-score to title
        z_score = motif.motif_criteria.z_score
        current_title = ax.get_title()
        ax.set_title(f"{current_title}\nZ={z_score:.2f}", fontsize=7.5)

    # Remove empty subplots
    for idx in range(num_motifs, rows * cols):
        row = idx // cols
        col = idx % cols
        fig.delaxes(axes[row][col])

    plt.tight_layout()
    return fig, axes


def plot_motifs_grid(motifs: list[Motif], title: str = "Motifs", figsize=(11, 6.5), cols=5):
    """
    Plot motifs in a grid layout.

    Args:
        motifs: List of Motif objects to plot
        title: Plot title
        figsize: Figure size tuple
        cols: Number of columns in grid

    Returns:
        tuple: (fig, axes) matplotlib figure and axes
    """
    num_motifs = len(motifs)
    if num_motifs == 0:
        print("No motifs to plot")
        return None, None

    rows = (num_motifs + cols - 1) // cols

    fig, axes = plt.subplots(nrows=rows, ncols=cols, figsize=figsize)
    fig.suptitle(title, fontsize=14, fontweight='bold')

    # Handle single row/column cases
    if rows == 1 and cols == 1:
        axes = [[axes]]
    elif rows == 1:
        axes = [axes]
    elif cols == 1:
        axes = [[ax] for ax in axes]

    # Plot each motif
    for idx, motif in enumerate(motifs):
        row = idx // cols
        col = idx % cols
        ax = axes[row][col]

        draw_motif(motif, ax)

    # Remove empty subplots
    for idx in range(num_motifs, rows * cols):
        row = idx // cols
        col = idx % cols
        fig.delaxes(axes[row][col])

    plt.tight_layout()
    return fig, axes


def plot_z_score_scatter(motifs: list[Motif], title: str = "Motif Z-scores vs N_real",
                         figsize=(10, 6)):
    """
    Scatter plot of Z-scores vs number of occurrences in real network.

    Args:
        motifs: List of Motif objects to plot
        title: Plot title
        figsize: Figure size tuple

    Returns:
        tuple: (fig, ax) matplotlib figure and axis
    """
    # Filter motifs with valid data
    valid_motifs = [m for m in motifs
                    if m.motif_criteria and m.motif_criteria.z_score is not None and m.n_real > 0]

    if not valid_motifs:
        print("No valid motifs to plot")
        return None, None

    fig, ax = plt.subplots(figsize=figsize)

    x = [m.n_real for m in valid_motifs]
    y = [m.motif_criteria.z_score for m in valid_motifs]
    colors = ['red' if m.motif_criteria.z_score > 0 else 'blue' for m in valid_motifs]

    ax.scatter(x, y, c=colors, alpha=0.6, s=100)
    ax.axhline(y=0, color='black', linestyle='--', linewidth=0.5)
    ax.set_xlabel('N_real (Occurrences in real network)', fontsize=12)
    ax.set_ylabel('Z-score', fontsize=12)
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)

    # Add labels for significant motifs
    for motif in valid_motifs:
        if abs(motif.motif_criteria.z_score) > 2:  # Significant motifs
            ax.annotate(str(motif.id),
                        (motif.n_real, motif.motif_criteria.z_score),
                        xytext=(5, 5), textcoords='offset points',
                        fontsize=8, alpha=0.7)

    plt.tight_layout()
    return fig, ax
