import matplotlib.pyplot as plt
import matplotlib.transforms as mtransforms
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from matplotlib.patches import FancyArrowPatch
import networkx as nx
import matplotlib.colors as mcolors


def draw_motif_geometric(motif, ax, k2_circle_radius=0.10, k2_spacing=0.65,
                         arrow_mutation_scale=None, arrow_linewidth=None):
    """
    Draws the motif geometrically.
    - Iterates STRICTLY over `motif.role_pattern` to match polarity indices.
    - Pushes text LABELS outwards for bidirectional edges to prevent overlapping.
    - Adds node LABELS ('a', 'b', 'c') inside the circles.

    Args:
        motif: The motif to draw
        ax: The matplotlib axis
        k2_circle_radius: Radius of circles for k=2 motifs (default: 0.10)
        k2_spacing: Distance between nodes for k=2 motifs (default: 0.65)
        arrow_mutation_scale: Size of arrowheads (default: 12 for k>=3, 12 for k=2)
        arrow_linewidth: Width of arrow lines (default: 1.5 for k>=3, 1.5 for k=2)
    """
    ax.set_aspect('equal')
    ax.axis('off')

    # Get unique nodes to determine k
    unique_nodes = sorted(list(set(u for u, v in motif.role_pattern) | set(v for u, v in motif.role_pattern)))
    k = len(unique_nodes)

    # Coordinates based on motif size
    if k == 2:
        # Horizontal layout for k=2 (wider spacing)
        center = 0.5
        half_spacing = k2_spacing / 2
        coords = {
            0: (center - half_spacing, 0.5),
            1: (center + half_spacing, 0.5)
        }
        circle_radius = k2_circle_radius
        shrink = int(k2_circle_radius * 120)  # Scale shrink with radius
    else:  # k >= 3
        # Triangle layout for k=3
        coords = {
            0: (0.2, 0.2),
            1: (0.5, 0.8),
            2: (0.8, 0.2)
        }
        circle_radius = 0.09
        shrink = 8

    # Set arrow parameters with defaults if not provided
    if arrow_mutation_scale is None:
        arrow_mutation_scale = 12
    if arrow_linewidth is None:
        arrow_linewidth = 1.5

    # Colors for positions
    colors = {0: '#5da5da', 1: '#faa43a', 2: '#60bd68'}

    # 1. Create Node Map (a->0, b->1, c->2)
    # Sorting ensures consistent positioning
    node_map = {n: i for i, n in enumerate(unique_nodes)}

    # 2. Get Polarity List
    polarities = getattr(motif, 'polarity', [])

    # 3. Draw Edges (Iterate strictly over the pattern list)
    for i, (u, v) in enumerate(motif.role_pattern):

        start = coords[node_map[u]]
        end = coords[node_map[v]]

        # Check for bidirectional edge to apply curvature
        is_bidirectional = (v, u) in motif.role_pattern

        # rad=0.1 curves the arrow to the RIGHT relative to direction
        connectionstyle = "arc3,rad=0.1" if is_bidirectional else "arc3,rad=0"

        arrow = FancyArrowPatch(
            posA=start, posB=end,
            arrowstyle='-|>',
            connectionstyle=connectionstyle,
            mutation_scale=arrow_mutation_scale,
            color='#333333',
            linewidth=arrow_linewidth,
            shrinkA=shrink, shrinkB=shrink
        )
        ax.add_patch(arrow)

        # 4. Draw Polarity Symbol
        if polarities and i < len(polarities):
            symbol = polarities[i]

            mid_x = (start[0] + end[0]) / 2
            mid_y = (start[1] + end[1]) / 2

            if is_bidirectional:
                # Calculate vector (dx, dy)
                dx = end[0] - start[0]
                dy = end[1] - start[1]

                # We want to push the text to the RIGHT (matching the arc curve)
                # The normal vector pointing Right is (dy, -dx)
                # (Previous code used -dy, dx which pointed Left/Inside)
                mid_x += dy * 0.12
                mid_y += -dx * 0.12

            ax.text(mid_x, mid_y, symbol,
                    fontsize=12,
                    fontweight='bold',
                    color='black',
                    ha='center', va='center',
                    bbox=dict(boxstyle='circle,pad=0.1', fc='white', ec='none', alpha=0.9),
                    zorder=12)

    # 5. Draw Nodes with Labels
    for i, (x, y) in coords.items():
        # Draw Circle
        circle = plt.Circle((x, y), circle_radius, color=colors[i], zorder=10)
        ax.add_patch(circle)

        # Draw Border
        ax.add_patch(plt.Circle((x, y), circle_radius, color='black', fill=False, lw=0.5, zorder=11))

        # Draw Node ID (a, b, c) inside the circle
        if i < len(unique_nodes):
            node_label = unique_nodes[i]
            ax.text(x, y, node_label,
                    color='white',
                    fontsize=9,
                    fontweight='bold',
                    ha='center', va='center',
                    zorder=13)


def plot_Z_nice(motif_list: list, k2_circle_radius=0.10, k2_spacing=0.65):
    """
    Plot motif counts with Z-scores as bar colors.

    Args:
        motif_list: List of motif objects to plot
        k2_circle_radius: Radius of circles for k=2 motifs (default: 0.10)
        k2_spacing: Distance between nodes for k=2 motifs (default: 0.65)
    """
    # Sort motifs by ID (extract int from id which could be int or string)
    sorted_motifs = sorted(motif_list, key=lambda m: int(str(m.id).split()[0]))

    # cmap = mcolors.LinearSegmentedColormap.from_list("RedGreyGreen", ["#f30a02", "#dad7d7", "#0cf21f"])
    cmap = mcolors.LinearSegmentedColormap.from_list("RedGreyGreen", ['#f15854', '#95a5a6', '#60bd68'])
    norm = mcolors.Normalize(vmin=-3, vmax=3)
    bar_colors = [cmap(norm(z if (z := getattr(m.motif_criteria, 'z_score', 0)) is not None else 0)) for m in sorted_motifs]

    # Setup Data
    counts = [m.n_real for m in sorted_motifs]
    x_coords = range(len(sorted_motifs))

    # Create Figure (Wide enough to fit everything)
    fig, ax = plt.subplots(figsize=(20, 8))

    # Draw Bars
    bars = ax.bar(x_coords, counts, width=0.6, color=bar_colors, alpha=0.9)

    # Format Main Axis
    ax.set_ylabel('Frequency', fontsize=14)
    ax.set_title('Motif Counts', fontsize=18, pad=20)
    ax.set_xticks([])  # Hide default x-axis ticks
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.set_xlim(-0.7, len(sorted_motifs) - 0.3)

    # Add Count Labels on Bars
    max_val = max(counts) if counts else 1
    for bar in bars:
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2., height + (max_val * 0.01),
                f'{int(height)}', ha='center', va='bottom', fontsize=14)

    # Create Blended Transform
    # X matches Data (0, 1, 2...), Y matches Axes (0.0 to 1.0)
    trans = mtransforms.blended_transform_factory(ax.transData, ax.transAxes)

    for i, motif in enumerate(sorted_motifs):

        # 1. Create Inset Axis for the Triangle
        # bbox_to_anchor=(x, y, w, h)
        # x = i (center of bar)
        # y = -0.12 (The vertical position - adjust this to move motifs up/down)
        # width/height = 1 (dummy units, real size set by width=1.1 below)

        ax_inset = inset_axes(ax,
                              width=1.1, height=1.1,  # Physical size in inches
                              loc='center',
                              bbox_to_anchor=(i - 0.5, -0.625, 1, 1),
                              bbox_transform=trans,
                              borderpad=0)

        # Draw the clean geometric motif
        draw_motif_geometric(motif, ax_inset, k2_circle_radius, k2_spacing)

        # 2. Add Text Labels (ID and Name)
        # We place this text relative to the bar position 'i'
        # y = -0.24 puts it below the motif inset
        if motif.name != "n/a":
            label_text = f"ID: {motif.id}\n{motif.name}"
        else:
            label_text = f"ID:\n{motif.id}"
        ax.text(i - 0.2, -0.225, label_text, transform=trans, rotation=45,
                ha='center', va='top', fontsize=12, linespacing=1.4)

    sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
    sm.set_array([])
    cbar = plt.colorbar(sm, ax=ax, orientation='vertical', pad=0.01, aspect=30)
    cbar.set_label('Z-Score', fontsize=14)
    # Adjust bottom margin to make space for the motifs and text
    plt.subplots_adjust(bottom=0.35)


def plot_motif_roles(motif, top=10, roles_to_plot=None):
    """
    Plot the frequency of nodes in each role of a motif as horizontal bar charts.

    Args:
        motif: Motif object with node_roles populated
        top: Number of top nodes to show per role (default: 10)
        roles_to_plot: List of roles to plot (e.g., ['a', 'b']). If None, plots all roles.

    Returns:
        matplotlib figure and axes

    Example:
        >>> plot_motif_roles(ffl_motif, top=10, roles_to_plot=['a'])
        >>> plot_motif_roles(ffl_motif, top=5, roles_to_plot=['a', 'b', 'c'])
    """
    import numpy as np

    if not motif.node_roles:
        print(f"No node role data available for motif {motif.id}")
        print("Call populate_node_data(motif, neuron_names) first to populate node_roles.")
        return None, None

    # Filter roles if specified
    if roles_to_plot:
        node_roles_to_plot = {r: motif.node_roles[r] for r in roles_to_plot if r in motif.node_roles}
        if not node_roles_to_plot:
            print(f"Roles {roles_to_plot} not found in motif {motif.id}")
            print(f"Available roles: {list(motif.node_roles.keys())}")
            return None, None
    else:
        node_roles_to_plot = motif.node_roles

    n_roles = len(node_roles_to_plot)
    if n_roles == 0:
        print("No roles to plot")
        return None, None

    # Create subplots
    fig, axes = plt.subplots(1, n_roles, figsize=(5 * n_roles, 6))

    # Handle single role case
    if n_roles == 1:
        axes = [axes]

    # Plot each role
    for idx, (role, node_freq) in enumerate(node_roles_to_plot.items()):
        ax = axes[idx]

        # Get top N nodes
        top_nodes = list(node_freq.items())[:top]
        if not top_nodes:
            ax.text(0.5, 0.5, f'No data for role {role}',
                    ha='center', va='center', transform=ax.transAxes)
            ax.axis('off')
            continue

        nodes = [str(n) for n, _ in top_nodes]
        freqs = [f for _, f in top_nodes]

        # Create horizontal bar plot
        y_pos = np.arange(len(nodes))
        ax.barh(y_pos, freqs, color='steelblue', alpha=0.8)
        ax.set_yticks(y_pos)
        ax.set_yticklabels(nodes)
        ax.invert_yaxis()  # Top node at top
        ax.set_xlabel('Frequency', fontsize=11)
        ax.set_title(f'Role: {role}', fontsize=12, fontweight='bold')
        ax.grid(axis='x', alpha=0.3)

    plt.suptitle(f'Node Role Frequencies - Motif {motif.id}', fontsize=14, fontweight='bold')
    plt.tight_layout()

    return fig, axes


def draw_sub_graph(network, nodes, neuron_names=None, center=None, full_polarity=True, figsize=(8, 8)):
    """
    Draw a subgraph induced by the given nodes using NetworkX.

    Args:
        network: NetworkX DiGraph with integer node IDs and edge attributes 'polarity'
        nodes: List of node identifiers (names or indices) to include in the subgraph
        neuron_names: Optional list of neuron names for mapping string names to integer IDs
        center: Optional node (name or index) to place at the center of the layout
        full_polarity: If True, use 'full_polarity' edge attribute, otherwise use 'polarity'
        figsize: Figure size (default: (8, 8))

    Returns:
        matplotlib figure and axis

    Example:
        >>> neighbors = ['Mi1', 'Mi2', 'Mi13', 'Mi12', 'L1', 'Mi4']
        >>> draw_sub_graph(network.graph, neighbors, neuron_names=network.neuron_names, center='Mi1')
    """
    import numpy as np

    # Convert string names to integer indices if neuron_names provided
    node_indices = []
    center_name = None

    for node in nodes:
        if neuron_names and isinstance(node, str):
            idx = neuron_names.index(node)
            node_indices.append(idx)
        else:
            node_indices.append(node)

    if center is not None:
        if neuron_names and isinstance(center, str):
            center_name = center
        else:
            center_name = neuron_names[center] if neuron_names else center

    # Create induced subgraph with integer indices
    induced_sub_graph = network.subgraph(node_indices)

    # Relabel nodes with neuron names if available
    if neuron_names:
        mapping = {i: neuron_names[i] for i in node_indices}
        graph = nx.relabel_nodes(induced_sub_graph, mapping)
    else:
        graph = induced_sub_graph

    if len(graph.edges) == 0:
        print('empty graph')
        return None, None

    # Create layout
    pos = nx.circular_layout(graph)
    if center_name and center_name in pos:
        pos[center_name] = np.array([0, 0])

    # Get polarity attributes
    full_pol_attr = nx.get_edge_attributes(graph, 'full_polarity')
    pol_attr = nx.get_edge_attributes(graph, 'polarity')
    for label in pol_attr:
        if pol_attr[label] == 'complex':
            pol_attr[label] = 'c'

    if full_polarity and full_pol_attr:
        polarity_data = full_pol_attr
        font_size = 8
    else:
        polarity_data = pol_attr
        font_size = 10

    # Get edge weights and colors
    synapse = nx.get_edge_attributes(graph, 'synapse')
    gap = nx.get_edge_attributes(graph, 'gap')

    if synapse or gap:
        # Use synapse/gap attributes for width and color
        widths = {}
        colors = []
        for edge in graph.edges():
            syn_count = synapse.get(edge, 0)
            gap_count = gap.get(edge, 0)
            widths[edge] = syn_count + gap_count

            if syn_count > 0 and gap_count > 0:
                colors.append('black')
            elif syn_count > 0:
                colors.append('blue')
            elif gap_count > 0:
                colors.append('red')
            else:
                colors.append('gray')

        width = list(widths.values())
        if width:
            width_max = max(width)
            width = list(np.array(width) / width_max)
        else:
            width = 1
    else:
        # Default styling if no synapse/gap attributes
        colors = 'gray'
        width = 1

    # Draw
    fig, ax = plt.subplots(nrows=1, ncols=1, figsize=figsize)
    ax.axis('off')

    nx.draw_networkx(graph, pos=pos, ax=ax, node_size=600, node_color='lightgreen',
                     width=width, edge_color=colors, connectionstyle="arc3,rad=0.1")

    nx.draw_networkx_edge_labels(graph, pos=pos, ax=ax, edge_labels=polarity_data,
                                 font_color='k', label_pos=0.3, font_size=font_size)

    return fig, ax
