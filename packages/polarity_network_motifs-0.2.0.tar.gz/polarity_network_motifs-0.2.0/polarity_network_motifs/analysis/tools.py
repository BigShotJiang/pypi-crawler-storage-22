"""
Post-motif analysis tools for comparing networks, analyzing node roles,
and filtering/ranking subgraphs.

Important: node_roles and node_appearances are NOT saved to .h5 files to minimize
file size. They are computed on-demand from sub_graphs when needed. Call
populate_node_data() or populate_all_node_data() manually before using analysis functions.
"""
from typing import Union, Dict, Literal
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from numpy import linalg as LA
from tqdm import tqdm
from polarity_network_motifs.isomorphic.isomorphic import get_sub_graph_mapping_to_motif
from polarity_network_motifs.utils.export_import import import_results
from polarity_network_motifs.utils.types import Motif


def populate_node_data(motif: Motif, neuron_names: list = None) -> Motif:
    """
    Ensure node_roles and node_appearances are populated from sub_graphs.

    Since these fields are not saved to .h5 files (to minimize size), they need
    to be computed on-demand when loaded from disk.

    Args:
        motif: Motif object to populate
        neuron_names: Optional list of neuron names for mapping

    Returns:
        Motif with populated node_roles and node_appearances
    """
    if motif.node_roles and motif.node_appearances:
        return motif

    if not motif.sub_graphs:
        motif.node_roles = {}
        motif.node_appearances = {}
        return motif

    from polarity_network_motifs.utils.node_counter import (
        sort_node_roles_in_sub_graph,
        sort_node_appearances_in_sub_graph
    )

    motif.node_roles = sort_node_roles_in_sub_graph(
        appearances=motif.sub_graphs,
        neuron_names=neuron_names or [],
        motif=motif
    )
    motif.node_appearances = sort_node_appearances_in_sub_graph(
        appearances=motif.sub_graphs,
        neuron_names=neuron_names or []
    )

    return motif


def populate_all_node_data(motifs: Dict[Union[int, str], Motif], neuron_names: list = None) -> Dict[Union[int, str], Motif]:
    """
    Ensure node_roles and node_appearances are populated for all motifs.

    Args:
        motifs: Dictionary of motif_id -> Motif objects
        neuron_names: Optional list of neuron names for mapping

    Returns:
        Updated motifs dictionary
    """
    for motif_id, motif in motifs.items():
        populate_node_data(motif, neuron_names)

        # Also populate polarity sub-motifs
        if motif.polarity_motifs:
            for polarity_motif in motif.polarity_motifs:
                populate_node_data(polarity_motif, neuron_names)

    return motifs


def _discretized_z_scores(z: float) -> float:
    """
    Discretize Z-scores into bins: ±4, ±2, or 0.

    Args:
        z: Z-score value

    Returns:
        Discretized Z-score
    """
    thresholds = [4, 2]
    for pos_th in thresholds:
        if z >= pos_th:
            return pos_th
    for neg_th in [-4, -2]:
        if z <= neg_th:
            return neg_th
    return 0


def compare_networks_z_scores(
    result_files: list[str],
    network_names: list[str],
    motif_size: int = 3,
    mode: Literal['raw', 'norm', 'disc'] = 'raw',
    title: str = "Network Motif Z-score Comparison",
    figsize: tuple = (12, 6)
):
    """
    Compare Z-scores across multiple networks in a single plot.

    Args:
        result_files: List of paths to .h5 result files
        network_names: List of network names for legend
        motif_size: Size of motifs to compare (default: 3)
        mode: Z-score transformation mode:
            - 'raw': Raw Z-scores (default)
            - 'norm': L2-normalized Z-scores per network
            - 'disc': Discretized Z-scores (bins: ±4, ±2, 0)
        title: Plot title
        figsize: Figure size tuple

    Returns:
        tuple: (fig, ax) matplotlib figure and axis
    """
    if len(result_files) != len(network_names):
        raise ValueError("Number of result files must match number of network names")

    fig, ax = plt.subplots(figsize=figsize)

    # Color palette for different networks
    colors = plt.cm.tab10(range(len(result_files)))

    # Collect all unique motif IDs across all networks
    all_motif_ids = set()
    for result_file in result_files:
        results = import_results(result_file)
        for motif_id in results['motifs'].keys():
            try:
                id_num = int(str(motif_id).split()[0])
                all_motif_ids.add(id_num)
            except BaseException:
                pass

    motif_ids_sorted = sorted(list(all_motif_ids))
    x_positions = range(len(motif_ids_sorted))

    for idx, (result_file, name) in enumerate(zip(result_files, network_names)):
        # Load results
        results = import_results(result_file)
        motifs = results['motifs']

        # Extract Z-scores for all motif IDs
        z_scores = []
        for motif_id in motif_ids_sorted:
            if motif_id in motifs:
                motif = motifs[motif_id]
                if motif.motif_criteria and motif.motif_criteria.z_score is not None:
                    z_scores.append(motif.motif_criteria.z_score)
                else:
                    z_scores.append(0)
            else:
                z_scores.append(0)

        # Apply transformation based on mode
        z_scores = np.array(z_scores)
        if mode == 'norm':
            # L2 normalization
            norm = LA.norm(z_scores)
            if norm > 0:
                z_scores = z_scores / norm
            ylabel = 'Normalized Z-score'
        elif mode == 'disc':
            # Discretize into bins
            z_scores = list(map(_discretized_z_scores, z_scores))
            ylabel = 'Discretized Z-score'
        else:  # raw
            ylabel = 'Z-score'

        # Plot line for this network with dashed style
        ax.plot(x_positions, z_scores, marker='o', label=name,
                color=colors[idx], linestyle='--', linewidth=2, markersize=8)

    # Add horizontal line at Z=0
    ax.axhline(y=0, color='black', linestyle='-', linewidth=1, alpha=0.5)

    # Set x-axis to show motif IDs
    ax.set_xticks(x_positions)
    ax.set_xticklabels(motif_ids_sorted)

    ax.set_xlabel('Motif ID', fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.legend(loc='best', frameon=True, shadow=True)
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    return fig, ax


def get_motif_sub_graphs(motif: Motif, neuron_names: list, node=None, role=None):
    """
    Get subgraphs from a motif, optionally filtered by node and/or role.

    Args:
        motif: Motif object with sub_graphs populated
        neuron_names: List of neuron/node names for mapping indices to names
        node: Optional node identifier (name or index) to filter by
        role: Optional role ('a', 'b', 'c' or 0, 1, 2) to filter by

    Returns:
        list: List of role-to-neuron-name dictionaries for each matching subgraph

    Example:
        >>> subgraphs = get_motif_sub_graphs(motif, neuron_names, node='Mi1', role='a')
    """

    # Convert node to index if it's a name
    node_idx = None
    if node is not None:
        node_idx = neuron_names.index(node) if isinstance(node, str) else node

    # Convert role to string format if numeric
    target_role = None
    if role is not None:
        if isinstance(role, int):
            target_role = chr(ord('a') + role)
        else:
            target_role = role.lower()

    res = []
    for sub_graph in motif.sub_graphs:
        try:
            role_nodes_mapping = get_sub_graph_mapping_to_motif(
                sub_graph,
                motif.role_pattern,
                motif.polarity if hasattr(motif, 'polarity') else []
            )

            # Filter by role if specified
            if target_role is not None and role_nodes_mapping.get(target_role) != node_idx:
                continue

            # Filter by node if specified
            if node_idx is not None and node_idx not in role_nodes_mapping.values():
                continue

            # Convert indices to neuron names
            if neuron_names:
                role_nodes_mapping_w_neuron_names = {
                    k: neuron_names[role_nodes_mapping[k]] for k in role_nodes_mapping
                }
                res.append(role_nodes_mapping_w_neuron_names)
            else:
                res.append(role_nodes_mapping)

        except Exception:
            continue

    return res


def get_node_neighbors_in_motif(node, motif, neuron_names: list, role=None) -> list:
    """
    Get all co-occurring nodes (neighbors) of a given node in a motif.

    Finds all nodes that appear in the same subgraph instances as the given node,
    optionally filtering by the role the node plays.

    Args:
        node: Node identifier (name or index) to find neighbors for
        motif: Motif object with sub_graphs populated
        neuron_names: List of neuron/node names for mapping
        role: Optional role filter ('a', 'b', 'c', or 0, 1, 2, etc.)

    Returns:
        list: Sorted list of unique nodes that co-occur with the given node

    Example:
        >>> node_name = 'Mi1'
        >>> neighbors = get_node_neighbors_in_motif(node_name, ffl_motif, neuron_names, role='a')
        >>> print(f"Nodes co-occurring with {node_name} in role 'a': {neighbors}")
    """
    neighbors = set()
    for subgraph in get_motif_sub_graphs(motif, neuron_names, node=node, role=role):
        neighbors.update(set(list(subgraph.values())))

    if node in neighbors:
        neighbors.remove(node)

    return sorted(list(neighbors))


def get_motif_roles_freq_csv(motif: Motif, neuron_names: list):
    all_nodes_data = []
    for node in tqdm(neuron_names):
        node_data_dict = {}
        for role in motif.node_roles.keys():
            node_data_dict[f'{motif.id}_{role}'] = motif.node_roles[role].get(node, 0)
        all_nodes_data.append(node_data_dict)

    node_roles_df = pd.DataFrame(all_nodes_data)
    node_roles_df.to_csv(f'motif_{motif.id}_roles_freq.csv', index=True)


def get_motif_subgraphs_csv(motif: Motif):
    all_subgraphs_data = []
    for sub_graph in tqdm(motif.sub_graphs):
        all_subgraphs_data.append(get_sub_graph_mapping_to_motif(sub_graph,
                                                                 motif.role_pattern,
                                                                 motif.polarity if hasattr(motif, 'polarity') else []))

    sub_graphs_df = pd.DataFrame(all_subgraphs_data)
    sub_graphs_df.to_csv(f'motif_{motif.id}_subgraphs.csv', index=True)
