"""
Programmatic API for network motif detection.
"""
from typing import Optional, Union, Type, Dict
from dataclasses import dataclass
import time

from tqdm import tqdm

from polarity_network_motifs.network import Network
from polarity_network_motifs.subgraphs.sub_graphs_abc import SubGraphsABC
from polarity_network_motifs.random_networks.network_randomizer_abc import (
    NetworkRandomizer
)
from polarity_network_motifs.isomorphic.isomorphic import (
    match_two_fsl_id_lists,
    IsomorphicMotifMatch,
)
from polarity_network_motifs.motif_criteria import MotifCriteria
from polarity_network_motifs.utils.types import Motif, MotifCriteriaArgs
from polarity_network_motifs.utils.sub_graphs import create_base_motif
from polarity_network_motifs.utils.node_counter import sort_node_appearances_in_sub_graph, sort_node_roles_in_sub_graph
from polarity_network_motifs.utils.polarity_counter import get_polarity_frequencies
from polarity_network_motifs.utils.export_import import export_results
from polarity_network_motifs.utils.types import SearchResultBinaryFile
from polarity_network_motifs.utils.export_import import import_results
from polarity_network_motifs.subgraphs.mfinder_enum_induced import MFinderInduced


@dataclass
class MotifResults:
    """Results from motif detection."""
    motifs: Dict[Union[str, int], Motif]
    elapsed_time: float

    def get_significant_motifs(self) -> Dict[Union[str, int], Motif]:
        """Return only statistically significant motifs."""
        return {k: v for k, v in self.motifs.items()
                if v.motif_criteria and hasattr(v.motif_criteria, 'is_significant') and v.motif_criteria.is_significant}

    def save(self, filepath: str, search_config: dict = None):
        export_results(SearchResultBinaryFile(args=search_config, motifs=self.motifs), filepath=filepath)

    @classmethod
    def load(cls, filepath: str, motif_ids: list = None) -> 'MotifResults':
        data = import_results(filepath, motif_ids=motif_ids)
        return cls(motifs=data['motifs'], elapsed_time=0.0)


class MotifSearch:
    """
    Main API for network motif detection.
    """

    def __init__(
        self,
        network: Network,
        k: int = 3,
        algorithm: Type[SubGraphsABC] = None,
        randomizer: Optional[Type[NetworkRandomizer]] = None,
        num_random_networks: int = 100,
        switch_factor: int = 10,
        alpha: float = 0.01,
        frequency_threshold: float = 0.1,
        uniqueness_threshold: int = 3,
        use_uniqueness: bool = False,
        allow_self_loops: bool = False,
        use_isomorphic_mapping: bool = True,
        random_seed: Optional[int] = None,
        verbose: bool = True
    ):
        """
        Initialize motif search.

        Args:
            network: Network object to analyze
            k: Size of motifs to detect (default: 3)
            algorithm: Subgraph enumeration algorithm class (must inherit from SubGraphsABC)
            randomizer: Random network generator class (must inherit from NetworkRandomizer)
            num_random_networks: Number of random networks to generate (default: 100)
            switch_factor: For Markov chain randomizer (default: 10)
            alpha: Statistical significance threshold (default: 0.01)
            frequency_threshold: Minimum frequency threshold (default: 0.1)
            uniqueness_threshold: Minimum uniqueness threshold (default: 3)
            use_uniqueness: Whether to apply uniqueness test (default: False)
            allow_self_loops: Whether to allow self-loops in motifs (default: False)
            use_isomorphic_mapping: Use precomputed isomorphic mappings (default: True)
            random_seed: Random seed for reproducibility (default: None)
            verbose: Show progress bars and logging (default: True)
        """
        if algorithm is None:
            algorithm = MFinderInduced

        self.network = network
        self.k = k
        self.algorithm = algorithm
        self.randomizer = randomizer
        self.num_random_networks = num_random_networks
        self.switch_factor = switch_factor
        self.allow_self_loops = allow_self_loops
        self.use_isomorphic_mapping = use_isomorphic_mapping
        self.verbose = verbose

        # Set random seed if provided
        if random_seed is not None:
            import random
            random.seed(random_seed)

        # Initialize motif criteria
        self.motif_criteria = MotifCriteria(MotifCriteriaArgs(
            alpha=alpha,
            frequency_threshold=frequency_threshold,
            uniqueness_threshold=uniqueness_threshold,
            use_uniq_criteria=use_uniqueness
        ))

        # Initialize isomorphic matcher
        polarity_options = network.polarity_options if network.use_polarity else None
        self.iso_matcher = IsomorphicMotifMatch(
            k=k,
            polarity_options=polarity_options,
            allow_self_loops=allow_self_loops,
            use_mapping=use_isomorphic_mapping
        )

        self.isomorphic_mapping = self.iso_matcher.isomorphic_mapping
        self.isomorphic_graphs = self.iso_matcher.isomorphic_graphs

        self.results = None

    def get_search_config(self) -> dict:
        """Get search configuration for saving with results."""
        return {
            'k': self.k,
            'algorithm': self.algorithm.__name__,
            'randomizer': self.randomizer.__name__ if self.randomizer else None,
            'num_random_networks': self.num_random_networks,
            'switch_factor': self.switch_factor,
            'alpha': self.motif_criteria.alpha,
            'frequency_threshold': self.motif_criteria.frequency_threshold,
            'uniqueness_threshold': self.motif_criteria.uniqueness_threshold,
            'use_uniqueness': self.motif_criteria.use_uniqueness,
            'allow_self_loops': self.allow_self_loops,
            'use_isomorphic_mapping': self.use_isomorphic_mapping,
        }

    def _populate_motif(self, motif: Motif, sub_graphs: list):
        """Populate motif with node roles and appearances."""
        motif.node_roles = sort_node_roles_in_sub_graph(
            appearances=sub_graphs,
            neuron_names=self.network.neuron_names,
            motif=motif
        )
        motif.node_appearances = sort_node_appearances_in_sub_graph(
            appearances=sub_graphs,
            neuron_names=self.network.neuron_names
        )

    def _enumerate_subgraphs(self) -> Dict[Union[str, int], Motif]:
        """Enumerate all subgraphs in the network."""
        # Run main subgraph enumeration
        algo = self.algorithm(self.network.graph, self.isomorphic_mapping)
        search_result = algo.search_sub_graphs(k=self.k, allow_self_loops=self.allow_self_loops)

        # Build motif candidates
        motifs = {}
        loop_over = self.isomorphic_graphs if self.isomorphic_graphs else search_result.fsl

        for sub_id in loop_over:
            motif = create_base_motif(sub_id=sub_id, k=self.k)
            motif.n_real = search_result.fsl.get(sub_id, 0)
            motif.sub_graphs = search_result.fsl_fully_mapped.get(sub_id, [])
            self._populate_motif(motif=motif, sub_graphs=motif.sub_graphs)
            motifs[sub_id] = motif

        # Handle polarity motifs
        if self.network.use_polarity:
            for sub_id in motifs:
                motif = motifs[sub_id]
                polarity_frequencies = get_polarity_frequencies(
                    appearances=motif.sub_graphs,
                    roles=motif.role_pattern,
                    polarity_options=self.network.polarity_options,
                    iso_matcher=self.iso_matcher,
                    motif_id=sub_id
                )

                for motif_pol_freq in polarity_frequencies:
                    polarity_motif = create_base_motif(sub_id=sub_id, k=self.k)

                    polarity_motif.polarity = motif_pol_freq.polarity
                    polarity_motif.id = f'{sub_id} {str(motif_pol_freq.polarity)}'
                    polarity_motif.n_real = motif_pol_freq.frequency
                    polarity_motif.sub_graphs = motif_pol_freq.sub_graphs
                    self._populate_motif(motif=polarity_motif, sub_graphs=polarity_motif.sub_graphs)
                    motif.polarity_motifs.append(polarity_motif)

        return motifs

    def run(self) -> MotifResults:
        """
        Run motif detection.

        Returns:
            MotifResults object containing detected motifs and metadata
        """
        start_time = time.time()

        # Step 1: Enumerate subgraphs
        if self.verbose:
            print('Enumerating subgraphs in original network...')

        step1_start = time.time()
        motif_candidates = self._enumerate_subgraphs()
        if self.verbose:
            print(f'Done enumerating subgraphs in original network ({time.time() - step1_start:.2f}s)')

        # Step 2: Generate random networks and compute statistics (if randomizer provided)
        if self.randomizer is not None:
            if self.verbose:
                print(f'Generating {self.num_random_networks} random networks...')

            # Initialize randomizer
            if hasattr(self.randomizer, '__name__') and 'MarkovChain' in self.randomizer.__name__:
                randomizer_instance = self.randomizer(self.network, switch_factor=self.switch_factor)
            else:
                randomizer_instance = self.randomizer(self.network)

            # Generate random networks
            gen_start = time.time()
            random_networks = randomizer_instance.generate(amount=self.num_random_networks)
            if self.verbose:
                print(f'Generated {self.num_random_networks} random networks in {time.time() - gen_start:.2f}s')

            # Enumerate subgraphs in random networks
            if self.verbose:
                print('Enumerating subgraphs in random networks...')

            random_results = []
            iterator = tqdm(random_networks, desc="Random networks") if self.verbose else random_networks

            for rand_network in iterator:
                algo = self.algorithm(rand_network, self.isomorphic_mapping)
                search_result = algo.search_sub_graphs(k=self.k, allow_self_loops=self.allow_self_loops)
                random_results.append(search_result)

            # Handle isomorphic mapping for large k
            if not self.isomorphic_graphs:
                n_real_ids = [m.id for m in motif_candidates.values() if isinstance(m.id, int)]
                rand_network_ids = [[k for k in rand_res.fsl.keys() if isinstance(k, int)]
                                    for rand_res in random_results]

                iso_mappings = [match_two_fsl_id_lists(n_real_ids, rand_ids, k=self.k)
                                for rand_ids in rand_network_ids]

                for iso_map, rand_res in zip(iso_mappings, random_results):
                    for src in iso_map:
                        tar = iso_map[src]
                        if src != tar:
                            rand_res.fsl[src] = rand_res.fsl.pop(tar, 0)
                            rand_res.fsl_fully_mapped[src] = rand_res.fsl_fully_mapped.pop(tar, [])

            # Compute statistics for main motifs
            stat_iterator = tqdm(motif_candidates, desc="Calculating statistics") if self.verbose else motif_candidates

            for sub_id in stat_iterator:
                random_samples = [rand_res.fsl.get(sub_id, 0) for rand_res in random_results]
                motif_candidates[sub_id].random_network_samples = random_samples
                motif_candidates[sub_id].motif_criteria = self.motif_criteria.is_motif(motif_candidates[sub_id])

                # Compute statistics for polarity sub-motifs
                if motif_candidates[sub_id].polarity_motifs:
                    # Pre-compute role pattern once
                    role_pattern = motif_candidates[sub_id].role_pattern

                    # OPTIMIZATION: Calculate polarity frequencies for all random networks ONCE
                    # instead of re-calculating for every polarity variant
                    random_polarity_freqs_cache = []

                    for rand_res in random_results:
                        rand_subgraphs = rand_res.fsl_fully_mapped.get(sub_id, [])
                        if not rand_subgraphs:
                            random_polarity_freqs_cache.append({})
                            continue

                        # Use the existing polarity counting function
                        pol_freqs = get_polarity_frequencies(
                            rand_subgraphs,
                            role_pattern,
                            self.network.polarity_options,
                            sub_id,
                            self.iso_matcher
                        )
                        # Map polarity pattern -> frequency
                        random_polarity_freqs_cache.append({tuple(pf.polarity): pf.frequency for pf in pol_freqs})

                    for polarity_motif in motif_candidates[sub_id].polarity_motifs:
                        # Get polarity pattern for this variant
                        polarity_pattern = polarity_motif.polarity

                        # Count occurrences of this polarity pattern in each random network using cache
                        polarity_random_samples = []
                        for pol_counts in random_polarity_freqs_cache:
                            polarity_random_samples.append(pol_counts.get(tuple(polarity_pattern), 0))

                        polarity_motif.random_network_samples = polarity_random_samples
                        polarity_motif.motif_criteria = self.motif_criteria.is_motif(polarity_motif)

        elapsed = time.time() - start_time

        self.results = MotifResults(motifs=motif_candidates, elapsed_time=elapsed)
        return self.results
