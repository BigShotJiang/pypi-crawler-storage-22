from typing import Optional, List
import networkx as nx
import numpy as np
from scipy.sparse import spmatrix

from polarity_network_motifs.network import Network


def from_networkx(
    graph: nx.DiGraph,
    polarity_attr: Optional[str] = None,
    polarity_values: Optional[List] = None,
    node_names: Optional[List[str | int]] = None
) -> Network:
    """
    Create a Network from a NetworkX DiGraph.

    Args:
        graph: NetworkX directed graph
        polarity_attr: Name of edge attribute containing polarity/sign (e.g., 'sign', 'weight', 'type')
        polarity_values: Expected polarity values (e.g., ['+', '-'] or [1, -1])
        node_names: Optional list of node names (assumes nodes are numbered 0..N-1)

    Returns:
        Network object ready for motif detection

    """
    network = Network()
    network.graph = graph.copy()

    # Set up polarity if specified
    if polarity_attr is not None:
        network.use_polarity = True
        if polarity_values is not None:
            network.polarity_options = polarity_values
        else:
            # Infer polarity values from the graph
            all_polarities = set()
            for u, v, data in graph.edges(data=True):
                if polarity_attr in data:
                    all_polarities.add(data[polarity_attr])
            network.polarity_options = sorted(list(all_polarities))

        # Ensure all edges have the polarity attribute and copy to 'polarity'
        for u, v in network.graph.edges():
            if polarity_attr not in graph[u][v]:
                raise ValueError(f"Edge ({u}, {v}) missing polarity attribute '{polarity_attr}'")
            # Copy to 'polarity' for internal consistency
            network.graph[u][v]['polarity'] = graph[u][v][polarity_attr]

    # Set up node names
    if node_names is not None:
        network.neuron_names = list(node_names)
    else:
        # Check if nodes are sequential integers starting from 0
        nodes = sorted(network.graph.nodes())
        if nodes and all(isinstance(n, int) for n in nodes) and nodes == list(range(len(nodes))):
            # Nodes are already 0..N-1, create default string labels
            network.neuron_names = [str(i) for i in nodes]
        else:
            # Nodes are arbitrary (strings or non-sequential), need to relabel
            # Create mapping from original nodes to sequential integers
            node_mapping = {node: i for i, node in enumerate(nodes)}
            network.graph = nx.relabel_nodes(network.graph, node_mapping, copy=False)
            # Store original node labels as neuron_names
            network.neuron_names = nodes

    network.calc_polarity_ratio()

    return network


def from_scipy_sparse(
    adjacency_matrix: spmatrix,
    polarity_vector: Optional[np.ndarray] = None,
    polarity_values: Optional[List] = None,
    node_names: Optional[List[str | int]] = None
) -> Network:
    """
    Create a Network from a scipy sparse adjacency matrix.

    Args:
        adjacency_matrix: Scipy sparse matrix (e.g., csr_matrix, coo_matrix)
        polarity_vector: Optional 1D array with polarity for each edge (in same order as matrix entries)
        polarity_values: Expected polarity values (e.g., ['+', '-'] or [1, -1])
        node_names: Optional list of node names (must match matrix dimensions)

    Returns:
        Network object ready for motif detection

    """
    network = Network()

    # Convert sparse matrix to NetworkX graph
    graph = nx.DiGraph()

    # Get COO format for easy iteration
    coo = adjacency_matrix.tocoo()

    # Add edges
    edge_idx = 0
    for i, j, weight in zip(coo.row, coo.col, coo.data):
        edge_attrs = {'weight': weight, 'synapse': weight, 'gap': 0}

        # Add polarity if provided
        if polarity_vector is not None:
            if edge_idx >= len(polarity_vector):
                raise ValueError("Polarity vector length doesn't match number of edges")
            edge_attrs['polarity'] = polarity_vector[edge_idx]

        graph.add_edge(i, j, **edge_attrs)
        edge_idx += 1

    network.graph = graph

    # Set up polarity
    if polarity_vector is not None:
        network.use_polarity = True
        if polarity_values is not None:
            network.polarity_options = polarity_values
        else:
            network.polarity_options = sorted(list(set(polarity_vector)))

    # Set up node names
    if node_names is not None:
        if len(node_names) != adjacency_matrix.shape[0]:
            raise ValueError("Node names length doesn't match matrix dimensions")
        network.neuron_names = list(node_names)
    else:
        network.neuron_names = [f"node_{i}" for i in range(adjacency_matrix.shape[0])]

    network.calc_polarity_ratio()

    return network


def from_edgelist(
    filepath: str,
    polarity_col: Optional[int] = None,
    polarity_values: Optional[List] = None,
    delimiter: str = ' ',
    comments: str = '#',
    nodetype: type = str
) -> Network:
    """
    Create a Network from an edge list file.

    Args:
        filepath: Path to edge list file (format: source target [weight] [polarity])
        polarity_col: Column index for polarity (0-indexed), if present
        polarity_values: Expected polarity values
        delimiter: Column delimiter (default: space)
        comments: Comment character (default: '#')
        nodetype: Type to convert node IDs to (default: str, use int for integer nodes)

    Returns:
        Network object ready for motif detection

    """
    network = Network()

    graph = nx.DiGraph()

    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith(comments):
                continue

            parts = line.split(delimiter)
            if len(parts) < 2:
                continue

            source, target = nodetype(parts[0]), nodetype(parts[1])
            weight = float(parts[2]) if len(parts) > 2 else 1.0

            edge_attrs = {'weight': weight, 'synapse': weight, 'gap': 0}

            if polarity_col is not None and len(parts) > polarity_col:
                edge_attrs['polarity'] = parts[polarity_col]

            graph.add_edge(source, target, **edge_attrs)

    network.graph = graph

    # Set up polarity
    if polarity_col is not None:
        network.use_polarity = True
        if polarity_values is not None:
            network.polarity_options = polarity_values
        else:
            # Infer from graph
            all_polarities = set()
            for u, v, data in graph.edges(data=True):
                if 'polarity' in data:
                    all_polarities.add(data['polarity'])
            network.polarity_options = sorted(list(all_polarities))

    # Set up node names
    nodes = sorted(graph.nodes())
    if nodes and all(isinstance(n, int) for n in nodes) and nodes == list(range(len(nodes))):
        # Nodes are already 0..N-1, create default string labels
        network.neuron_names = [str(i) for i in nodes]
    else:
        # Nodes are arbitrary (strings or non-sequential), need to relabel
        # Create mapping from original nodes to sequential integers
        node_mapping = {node: i for i, node in enumerate(nodes)}
        network.graph = nx.relabel_nodes(network.graph, node_mapping, copy=False)
        # Store original node labels as neuron_names
        network.neuron_names = nodes

    network.calc_polarity_ratio()

    return network


__all__ = ['from_networkx', 'from_scipy_sparse', 'from_edgelist']
