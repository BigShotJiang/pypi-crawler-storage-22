import collections

import networkx as nx

from polarity_network_motifs.utils.polarity_counter import count_network_polarity_ratio


class Network:
    """
    Wrapper around NetworkX DiGraph with polarity network support.

    Attributes:
        graph: NetworkX DiGraph
        neuron_names: List of node names (index corresponds to node ID)
        use_polarity: Whether network has polarity information
        polarity_ratio: Distribution of polarity types
        polarity_options: Available polarity values
    """

    def __init__(self):
        self.graph = nx.DiGraph()
        self.neuron_names: list[str | int] = []

        # Polarity configuration
        self.use_polarity = False
        self.polarity_ratio = collections.Counter([])
        self.polarity_options: list[str] = []

    def calc_polarity_ratio(self):
        """Calculate polarity distribution from edge attributes."""
        polarities = []
        for s, t in self.graph.edges:
            if 'polarity' not in self.graph[s][t]:
                return
            polarities.append(self.graph.get_edge_data(s, t)['polarity'])

        self.polarity_ratio = count_network_polarity_ratio(polarities)
        self.polarity_options = list(self.polarity_ratio.keys())
        self.use_polarity = True
