import networkx as nx
from networkx import DiGraph
from tqdm import tqdm

from polarity_network_motifs.network import Network
from polarity_network_motifs.random_networks.network_randomizer_abc import (
    NetworkRandomizer
)


class ConfigurationModel(NetworkRandomizer):
    """
    Configuration Model preserving degree sequences with polarity assignment.

    Uses NetworkX's directed_configuration_model to generate random networks
    matching the in/out-degree sequences of the original network. Polarity is
    then randomly assigned to match the original network's polarity ratio.

    Properties preserved:
        * Per-node in-degree sequence
        * Per-node total out-degree sequence
        * Overall polarity ratio (e.g., 60% '+', 40% '-')
        * No self-loops (removed)
        * No multi-edges (converted to simple graph)

    Properties NOT preserved:
        * Per-node, per-polarity out-degree (use MarkovChainSwitching for this)
        * Mutual/reciprocal edges count
        * Higher-order network structure

    This is much faster than MarkovChainSwitching
    (O(E) vs O(E × switch_factor))
    but provides a weaker null model since polarity assignment is randomized
    rather than preserving per-node polarity patterns.

    Args:
        network: Network instance with polarity information
    """

    def __init__(self, network: Network):
        super().__init__(network)

        if not network.use_polarity:
            raise ValueError(
                "ConfigurationModel requires a polarity network. "
                "Set use_polarity=True when loading the network."
            )

        # Extract degree sequences
        self.in_degrees = [d for n, d in network.graph.in_degree()]
        self.out_degrees = [d for n, d in network.graph.out_degree()]
        self.nodes = list(network.graph.nodes())

    def generate(self, amount: int) -> list[DiGraph]:
        """
        Generate random networks with matching degree sequences.

        Args:
            amount: Number of random networks to generate

        Returns:
            List of generated DiGraph instances with polarity attributes
        """
        random_networks = []

        for _ in tqdm(range(amount)):
            # Generate network using NetworkX configuration model
            multi_graph = nx.directed_configuration_model(
                self.in_degrees,
                self.out_degrees,
                create_using=nx.MultiDiGraph
            )

            # Convert to simple DiGraph (removes multi-edges, keeps one)
            graph = DiGraph(multi_graph)

            # Remove self-loops
            graph.remove_edges_from(nx.selfloop_edges(graph))

            # Relabel nodes to match original network
            mapping = {i: self.nodes[i] for i in range(len(self.nodes))}
            graph = nx.relabel_nodes(graph, mapping)

            # Assign polarity to match original network's polarity ratio
            self._assign_polarity(graph)

            random_networks.append(graph)

        self._log_avg_num_of_generated_edges(random_networks, amount)

        return random_networks
