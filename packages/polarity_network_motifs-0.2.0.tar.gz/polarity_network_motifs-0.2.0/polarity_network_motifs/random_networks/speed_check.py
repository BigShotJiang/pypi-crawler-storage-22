"""
Performance comparison between randomizers.

This script demonstrates the speed difference between the randomizers
while preserving different levels of network structure.
"""
import time
import networkx as nx

from polarity_network_motifs import (
    from_networkx,
    MarkovChainSwitching,
    ConfigurationModel,
    ErdosRenyi,
    BarabasiAlbert
)


def create_test_network(num_nodes=50, avg_degree=10):
    """
    Create a test network with binary polarity.

    Args:
        num_nodes: Number of nodes in the network
        avg_degree: Average degree per node

    Returns:
        Network with binary polarity attributes
    """
    # Create a scale-free network
    G = nx.scale_free_graph(num_nodes, seed=42)

    # Convert to directed graph
    DG = nx.DiGraph()
    for u, v in G.edges():
        # Add edge in both directions with 50% probability
        if hash((u, v)) % 2 == 0:
            polarity = '+' if hash((u, v)) % 3 == 0 else '-'
            DG.add_edge(u, v, polarity=polarity)
        if hash((v, u)) % 2 == 0:
            polarity = '+' if hash((v, u)) % 3 == 0 else '-'
            DG.add_edge(v, u, polarity=polarity)

    # Convert to Network object
    network = from_networkx(
        DG, polarity_attr='polarity', polarity_values=['+', '-']
    )

    return network


def benchmark_randomizer(randomizer_class, network, num_networks, **kwargs):
    """
    Benchmark a randomizer.

    Args:
        randomizer_class: Randomizer class to test
        network: Network to randomize
        num_networks: Number of random networks to generate
        **kwargs: Additional arguments for randomizer constructor

    Returns:
        Tuple of (elapsed_time, random_networks)
    """
    print(f"\n{'='*60}")
    print(f"Testing {randomizer_class.__name__}")
    print(f"{'='*60}")

    randomizer = randomizer_class(network, **kwargs)

    start_time = time.time()
    random_networks = randomizer.generate(num_networks)
    elapsed_time = time.time() - start_time

    return elapsed_time, random_networks


def verify_properties(original_network, random_networks, randomizer_name):
    """
    Verify that key properties are preserved.

    Args:
        original_network: Original network
        random_networks: List of generated random networks
        randomizer_name: Name of the randomizer for reporting
    """
    print(f"\n{'-'*60}")
    print(f"Property Verification for {randomizer_name}")
    print(f"{'-'*60}")

    # Check first random network
    rand_net = random_networks[0]

    # Node count
    orig_nodes = original_network.graph.number_of_nodes()
    rand_nodes = rand_net.number_of_nodes()
    print(f"Nodes: {orig_nodes} (original) → {rand_nodes} (random) "
          f"{'✅' if orig_nodes == rand_nodes else '❌'}")

    # Edge count
    orig_edges = original_network.graph.number_of_edges()
    rand_edges = rand_net.number_of_edges()
    edge_ratio = rand_edges / orig_edges if orig_edges > 0 else 0
    print(f"Edges: {orig_edges} (original) → {rand_edges} (random) "
          f"[{edge_ratio:.1%}]")

    # Degree sequence
    orig_in_deg = sorted([d for n, d in original_network.graph.in_degree()])
    rand_in_deg = sorted([d for n, d in rand_net.in_degree()])
    deg_match = orig_in_deg == rand_in_deg
    status = '✅ Exact match' if deg_match else '❌ Not preserved'
    print(f"In-degree sequence: {status}")

    orig_out_deg = sorted([d for n, d in original_network.graph.out_degree()])
    rand_out_deg = sorted([d for n, d in rand_net.out_degree()])
    deg_match = orig_out_deg == rand_out_deg
    status = '✅ Exact match' if deg_match else '❌ Not preserved'
    print(f"Out-degree sequence: {status}")

    # Polarity ratio
    orig_pol_counts = {'+': 0, '-': 0}
    for u, v in original_network.graph.edges():
        if 'polarity' in original_network.graph[u][v]:
            pol = original_network.graph[u][v]['polarity']
            orig_pol_counts[pol] += 1
        
    rand_pol_counts = {'+': 0, '-': 0}
    for u, v in rand_net.edges():
        if 'polarity' in rand_net[u][v]:
            pol = rand_net[u][v]['polarity']
            rand_pol_counts[pol] += 1
            
    orig_total = orig_pol_counts['+'] + orig_pol_counts['-']
    rand_total = rand_pol_counts['+'] + rand_pol_counts['-']

    orig_ratio = (orig_pol_counts['+'] / orig_total) if orig_total > 0 else 0
    rand_ratio = (rand_pol_counts['+'] / rand_total) if rand_total > 0 else 0
    
    print(
        f"Polarity ratio (+): {orig_ratio:.2%} (original) → "
        f"{rand_ratio:.2%} (random)"
    )


def main():
    """Run the performance comparison."""
    print("="*60)
    print("Random Network Generator Performance Comparison")
    print("="*60)

    # Create test network
    print("\nCreating test network...")
    network = create_test_network(num_nodes=50, avg_degree=10)

    print("\nNetwork statistics:")
    print(f"  Nodes: {network.graph.number_of_nodes()}")
    print(f"  Edges: {network.graph.number_of_edges()}")
    print("  Polarity ratio: " + str(network.polarity_ratio))

    num_networks = 100
    print(f"\nGenerating {num_networks} random networks with each method...")

    # Benchmark MarkovChainSwitching
    markov_time, markov_networks = benchmark_randomizer(
        MarkovChainSwitching,
        network,
        num_networks,
        switch_factor=10
    )
    verify_properties(network, markov_networks, "MarkovChainSwitching")

    # Benchmark ConfigurationModel
    cfg_time, cfg_networks = benchmark_randomizer(
        ConfigurationModel,
        network,
        num_networks
    )
    verify_properties(network, cfg_networks, "ConfigurationModel")

    # Benchmark ErdosRenyi
    er_time, er_networks = benchmark_randomizer(
        ErdosRenyi,
        network,
        num_networks
    )
    verify_properties(network, er_networks, "ErdosRenyi")
    
    # Benchmark BarabasiAlbert
    ba_time, ba_networks = benchmark_randomizer(
        BarabasiAlbert,
        network,
        num_networks
    )
    verify_properties(network, ba_networks, "BarabasiAlbert")

    # Summary
    print("\n" + "="*60)
    print("PERFORMANCE SUMMARY")
    print("="*60)
    print(f"MarkovChainSwitching: {markov_time:.2f} seconds")
    print(f"ConfigurationModel:   {cfg_time:.2f} seconds")
    print(f"ErdosRenyi:           {er_time:.2f} seconds")
    print(f"BarabasiAlbert:       {ba_time:.2f} seconds")

    print(f"\nSpeedup (vs MarkovChainSwitching):")
    print(f"  ConfigurationModel: {markov_time / cfg_time:.1f}x faster")
    print(f"  ErdosRenyi:         {markov_time / er_time:.1f}x faster")
    print(f"  BarabasiAlbert:     {markov_time / ba_time:.1f}x faster")

    print(
        "\nNote: MarkovChainSwitching preserves per-node, "
        "per-polarity degrees."
    )
    print(
        "      ConfigurationModel randomizes polarity assignment "
        "for speed."
    )


if __name__ == "__main__":
    main()
