from networkx import DiGraph

from polarity_network_motifs.subgraphs.sub_graphs_abc import SubGraphsABC
import networkx as nx

from polarity_network_motifs.utils.types import SubGraphSearchResult
import netsci.metrics.motifs as nsm


# https://github.com/gialdetti/netsci
class NetsciWrapper(SubGraphsABC):
    """
    This class wrap Netsci package and uses the louzoun algorithm which
    support accessing the actual sub graphs.
    This class support k=3 only without self loops!

    netsci package:
    * Gal, E., Perin, R., Markram, H., London, M., and Segev, I. (2019).
      Neuron Geometry Underlies a Universal Local Architecture in
      Neuronal Networks. BioRxiv 656058.

    louzoun algorithm:
    * Itzhack, R., Mogilevski, Y., and Louzoun, Y. (2007). An optimal algorithm for counting network motifs.
      Phys. A Stat. Mech. Its Appl. 381, 482-490.
    """

    def __init__(self, network: DiGraph, isomorphic_mapping: dict):
        super().__init__(network, isomorphic_mapping)
        self.motif_keys = [12, 36, 6, 38, 14, 74, 98, 78, 102, 46, 108, 110, 238]

    def search_sub_graphs(self, k: int, allow_self_loops: bool) -> SubGraphSearchResult:
        if k != 3:
            raise Exception('Netsci Wrapper support k=3 only')
        if allow_self_loops:
            raise Exception('Netsci Wrapper does not support self loops')

        # Relabel nodes to be 0-indexed for netsci compatibility
        node_mapping = {node: i for i, node in enumerate(sorted(self.network.nodes()))}
        reverse_mapping = {i: node for node, i in node_mapping.items()}
        relabeled_graph = nx.relabel_nodes(self.network, node_mapping, copy=True)

        # Convert to binary adjacency matrix (netsci expects integer 0/1, not float)
        # Use weight=None to ensure all edges are treated as 1, avoiding issues where float weights < 1 become 0
        # CRITICAL: Must provide nodelist to ensure row i corresponds to node index i
        nodelist = sorted(relabeled_graph.nodes())
        bin_mat_sparse = nx.to_scipy_sparse_array(relabeled_graph, nodelist=nodelist, dtype=int, weight=None)
        bin_mat_sparse[bin_mat_sparse > 1] = 1

        n_reals, participating_nodes = nsm.motifs(bin_mat_sparse, algorithm='louzoun', participation=True)
        n_reals = n_reals[3:]
        participating_nodes = participating_nodes[3:]

        fsl = {self.motif_keys[i]: amount for (i, amount) in enumerate(n_reals)}

        # Map the participating nodes back to original node IDs and retrieve induced edges
        fsl_fully_mapped = {}
        for i, nodes_list in enumerate(participating_nodes):
            mapped_instances = []
            for instance_nodes_indices in nodes_list:
                # Convert indices to original node labels
                original_nodes = [reverse_mapping[n] for n in instance_nodes_indices]

                # Create induced subgraph to get the edges
                sub_graph = self.network.subgraph(original_nodes)

                if not self.use_polarity:
                    edges = tuple(list(sub_graph.edges))
                else:
                    polarities = nx.get_edge_attributes(sub_graph, 'polarity')
                    pol_edges = []
                    for u, v in sub_graph.edges:
                        pol = polarities.get((u, v))
                        pol_edges.append((u, v, {'polarity': pol}))
                    edges = tuple(pol_edges)

                mapped_instances.append(edges)

            fsl_fully_mapped[self.motif_keys[i]] = mapped_instances

        return SubGraphSearchResult(fsl=fsl, fsl_fully_mapped=fsl_fully_mapped)
