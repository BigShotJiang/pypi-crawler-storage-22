"""
Unit tests for the programmatic API and convenience loaders.
"""
import pytest
import networkx as nx
import numpy as np
from scipy.sparse import csr_matrix

from polarity_network_motifs import (
    from_networkx,
    from_scipy_sparse,
    MotifSearch,
    MFinderInduced,
    MarkovChainSwitching
)
from polarity_network_motifs.loaders import from_edgelist


class TestConvenienceLoaders:
    """Test the convenience loader functions."""

    def test_from_networkx_simple(self):
        """Test loading a simple NetworkX graph."""
        G = nx.DiGraph()
        G.add_edge('A', 'B')
        G.add_edge('B', 'C')
        G.add_edge('C', 'A')

        network = from_networkx(G)

        assert network.graph.number_of_nodes() == 3
        assert network.graph.number_of_edges() == 3
        assert not network.use_polarity

    def test_from_networkx_with_polarity(self):
        """Test loading a NetworkX graph with polarity."""
        G = nx.DiGraph()
        G.add_edge('A', 'B', sign='+')
        G.add_edge('B', 'C', sign='-')
        G.add_edge('C', 'A', sign='+')

        network = from_networkx(G, polarity_attr='sign', polarity_values=['+', '-'])

        assert network.use_polarity
        assert set(network.polarity_options) == {'+', '-'}
        # Check the network's graph (nodes are relabeled to 0, 1, 2)
        # Original: A->0, B->1, C->2 (sorted order)
        assert network.graph[0][1]['polarity'] == '+'
        assert network.graph[1][2]['polarity'] == '-'
        # Check neuron_names preserves original labels
        assert network.neuron_names == ['A', 'B', 'C']

    def test_from_networkx_polarity_inferred(self):
        """Test that polarity values can be inferred from graph."""
        G = nx.DiGraph()
        G.add_edge(1, 2, weight=1)
        G.add_edge(2, 3, weight=-1)
        G.add_edge(3, 1, weight=1)

        network = from_networkx(G, polarity_attr='weight')

        assert network.use_polarity
        assert set(network.polarity_options) == {1, -1}

    def test_from_scipy_sparse_simple(self):
        """Test loading from scipy sparse matrix."""
        # Create a simple 3x3 adjacency matrix
        adj = csr_matrix([
            [0, 1, 0],
            [0, 0, 1],
            [1, 0, 0]
        ])

        network = from_scipy_sparse(adj)

        assert network.graph.number_of_nodes() == 3
        assert network.graph.number_of_edges() == 3
        assert not network.use_polarity

    def test_from_scipy_sparse_with_polarity(self):
        """Test loading from scipy sparse matrix with polarity vector."""
        adj = csr_matrix([
            [0, 1, 0],
            [0, 0, 1],
            [1, 0, 0]
        ])
        polarity = np.array(['+', '-', '+'])

        network = from_scipy_sparse(adj, polarity_vector=polarity, polarity_values=['+', '-'])

        assert network.use_polarity
        assert network.graph.number_of_edges() == 3

    def test_from_scipy_sparse_with_names(self):
        """Test loading from scipy sparse matrix with node names."""
        adj = csr_matrix([
            [0, 1],
            [1, 0]
        ])
        names = ['Node_A', 'Node_B']

        network = from_scipy_sparse(adj, node_names=names)

        assert network.neuron_names[0] == 'Node_A'
        assert network.neuron_names[1] == 'Node_B'

    def test_from_edgelist_simple(self, tmp_path):
        """Test loading from edgelist file."""
        # Create temporary edgelist file
        edgelist_file = tmp_path / "test.edgelist"
        with open(edgelist_file, 'w') as f:
            f.write("A B\n")
            f.write("B C\n")
            f.write("C A\n")

        network = from_edgelist(str(edgelist_file))

        assert network.graph.number_of_nodes() == 3
        assert network.graph.number_of_edges() == 3

    def test_from_edgelist_with_weights(self, tmp_path):
        """Test loading from edgelist with weights."""
        edgelist_file = tmp_path / "test.edgelist"
        with open(edgelist_file, 'w') as f:
            f.write("A B 2.5\n")
            f.write("B C 1.0\n")
            f.write("C A 3.0\n")

        network = from_edgelist(str(edgelist_file))

        # Nodes are relabeled to integers: A->0, B->1, C->2 (sorted order)
        assert network.graph[0][1]['weight'] == 2.5
        assert network.graph[2][0]['weight'] == 3.0
        # Check neuron_names preserves original labels
        assert network.neuron_names == ['A', 'B', 'C']


class TestMotifSearchAPI:
    """Test the MotifSearch programmatic API."""

    def test_motif_search_simple(self):
        """Test basic motif search without randomization."""
        # Create a simple triangle graph
        G = nx.DiGraph()
        G.add_edge(1, 2)
        G.add_edge(2, 3)
        G.add_edge(3, 1)

        network = from_networkx(G)

        search = MotifSearch(
            network=network,
            k=3,
            algorithm=MFinderInduced,
            randomizer=None,  # No statistical testing
            verbose=False
        )

        results = search.run()

        assert len(results.motifs) >= 1
        assert results.elapsed_time > 0

    def test_motif_search_with_randomizer(self):
        """Test motif search with random network generation."""
        # Create a small test graph
        G = nx.DiGraph()
        edges = [(1, 2), (2, 3), (3, 1), (2, 4), (4, 1)]
        G.add_edges_from(edges)

        network = from_networkx(G)

        search = MotifSearch(
            network=network,
            k=3,
            algorithm=MFinderInduced,
            randomizer=MarkovChainSwitching,
            num_random_networks=10,  # Small number for testing
            random_seed=42,
            verbose=False
        )

        results = search.run()

        # Check that statistical testing was performed
        for motif_id, motif in results.motifs.items():
            if motif.random_network_samples:
                assert len(motif.random_network_samples) == 10
                assert motif.motif_criteria is not None

    def test_motif_search_polarity(self):
        """Test motif search with polarity networks."""
        G = nx.DiGraph()
        G.add_edge('A', 'B', sign='+')
        G.add_edge('B', 'C', sign='-')
        G.add_edge('C', 'A', sign='+')

        network = from_networkx(G, polarity_attr='sign', polarity_values=['+', '-'])

        search = MotifSearch(
            network=network,
            k=3,
            algorithm=MFinderInduced,
            randomizer=None,
            verbose=False
        )

        results = search.run()

        assert len(results.motifs) >= 1
        # Check that polarity motifs were created
        for motif_id, motif in results.motifs.items():
            if motif.polarity_motifs:
                assert len(motif.polarity_motifs) > 0

    def test_motif_results_filtering(self):
        """Test filtering significant motifs from results."""
        G = nx.DiGraph()
        edges = [(1, 2), (2, 3), (3, 1), (2, 4), (4, 1), (4, 2)]
        G.add_edges_from(edges)

        network = from_networkx(G)

        search = MotifSearch(
            network=network,
            k=3,
            algorithm=MFinderInduced,
            randomizer=MarkovChainSwitching,
            num_random_networks=10,
            random_seed=42,
            verbose=False
        )

        results = search.run()

        # Test filtering
        significant = results.get_significant_motifs()
        assert isinstance(significant, dict)

        # All significant motifs should have is_significant=True
        for motif_id, motif in significant.items():
            assert motif.motif_criteria.is_significant

    def test_motif_search_k2(self):
        """Test motif search with k=2 (dyads)."""
        G = nx.DiGraph()
        G.add_edge(1, 2)
        G.add_edge(2, 1)  # Reciprocal edge
        G.add_edge(3, 4)  # Unidirectional

        network = from_networkx(G)

        search = MotifSearch(
            network=network,
            k=2,
            algorithm=MFinderInduced,
            randomizer=None,
            verbose=False
        )

        results = search.run()

        assert len(results.motifs) >= 1

    def test_motif_search_self_loops(self):
        """Test motif search with self-loops."""
        G = nx.DiGraph()
        G.add_edge(1, 1)  # Self-loop
        G.add_edge(1, 2)
        G.add_edge(2, 1)

        network = from_networkx(G)

        search = MotifSearch(
            network=network,
            k=2,
            algorithm=MFinderInduced,
            allow_self_loops=True,
            randomizer=None,
            verbose=False
        )

        results = search.run()

        # Should find motifs including the self-loop
        assert len(results.motifs) >= 1


class TestEdgeCases:
    """Test edge cases and error handling."""

    def test_empty_graph(self):
        """Test with an empty graph."""
        G = nx.DiGraph()
        network = from_networkx(G)

        assert network.graph.number_of_nodes() == 0
        assert network.graph.number_of_edges() == 0

    def test_single_node(self):
        """Test with a single node graph."""
        G = nx.DiGraph()
        G.add_node(1)

        network = from_networkx(G)

        assert network.graph.number_of_nodes() == 1
        assert network.graph.number_of_edges() == 0

    def test_missing_polarity_attribute(self):
        """Test error when polarity attribute is missing."""
        G = nx.DiGraph()
        G.add_edge(1, 2, other_attr='value')

        with pytest.raises(ValueError, match="missing polarity attribute"):
            from_networkx(G, polarity_attr='sign')

    def test_save_load_results(self):
        """Test saving and loading results."""
        import os
        import tempfile
        from polarity_network_motifs import MotifResults

        # Create a simple network and run motif detection
        G = nx.DiGraph()
        G.add_edges_from([(1, 2), (2, 3), (3, 1), (2, 4), (4, 5)])
        network = from_networkx(G)

        search = MotifSearch(
            network=network,
            k=3,
            algorithm=MFinderInduced,
            randomizer=MarkovChainSwitching,
            num_random_networks=10,
            random_seed=42,
            verbose=False
        )
        results = search.run()

        # Save to temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix='.bin') as tmp:
            tmp_path = tmp.name

        try:
            # Save results
            results.save(tmp_path)
            assert os.path.exists(tmp_path)

            # Load results
            loaded = MotifResults.load(tmp_path)

            # Verify loaded data matches original
            assert len(loaded.motifs) == len(results.motifs)
            assert set(loaded.motifs.keys()) == set(results.motifs.keys())

        finally:
            # Clean up
            if os.path.exists(tmp_path):
                os.remove(tmp_path)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
