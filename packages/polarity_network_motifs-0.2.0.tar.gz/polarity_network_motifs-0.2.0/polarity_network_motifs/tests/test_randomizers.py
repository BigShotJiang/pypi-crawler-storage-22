"""
Unit tests for network randomizers.
"""
import networkx as nx
import pytest

from polarity_network_motifs import (
    from_networkx,
    MarkovChainSwitching,
    ErdosRenyi,
    BarabasiAlbert,
    ConfigurationModel
)


def _create_simple_network():
    """Create a simple test network without polarity."""
    G = nx.DiGraph()
    G.add_edges_from([(0, 1), (1, 2), (2, 0), (0, 3), (3, 4)])
    return from_networkx(G)


def _create_polarity_network():
    """Create a test network with binary polarity."""
    G = nx.DiGraph()
    G.add_edge(0, 1, sign='+')
    G.add_edge(1, 2, sign='-')
    G.add_edge(2, 0, sign='+')
    G.add_edge(0, 3, sign='-')
    return from_networkx(G, polarity_attr='sign', polarity_values=['+', '-'])


def _create_large_network():
    """Create a larger test network for statistical tests."""
    G = nx.DiGraph()
    edges = [(i, (i + 1) % 20, {'sign': '+' if i % 2 == 0 else '-'}) for i in range(20)]
    edges.extend([(i, (i + 2) % 20, {'sign': '-' if i % 2 == 0 else '+'}) for i in range(0, 20, 2)])
    for u, v, data in edges:
        G.add_edge(u, v, **data)
    return from_networkx(G, polarity_attr='sign', polarity_values=['+', '-'])


def _networks_are_different(net1, net2):
    """Check if two networks have different edge sets."""
    edges1 = set(net1.edges())
    edges2 = set(net2.edges())
    return edges1 != edges2


class TestRandomizerCommon:
    """Common tests for all randomizers."""

    @pytest.mark.parametrize("randomizer_class,network_factory,kwargs", [
        (MarkovChainSwitching, _create_simple_network, {'switch_factor': 10}),
        (ErdosRenyi, _create_simple_network, {}),
        (BarabasiAlbert, _create_simple_network, {}),
        (ConfigurationModel, _create_polarity_network, {}),
    ])
    def test_generates_correct_number_of_networks(
        self, randomizer_class, network_factory, kwargs
    ):
        """Test that randomizers generate the requested number of networks."""
        network = network_factory()
        randomizer = randomizer_class(network, **kwargs)
        random_networks = randomizer.generate(5)
        assert len(random_networks) == 5

    @pytest.mark.parametrize("randomizer_class,network_factory,kwargs", [
        (MarkovChainSwitching, _create_simple_network, {'switch_factor': 10}),
        (ErdosRenyi, _create_simple_network, {}),
        (BarabasiAlbert, _create_simple_network, {}),
        (ConfigurationModel, _create_polarity_network, {}),
    ])
    def test_preserves_number_of_nodes(
        self, randomizer_class, network_factory, kwargs
    ):
        """Test that generated networks have the same number of nodes."""
        network = network_factory()
        original_nodes = network.graph.number_of_nodes()

        randomizer = randomizer_class(network, **kwargs)
        random_networks = randomizer.generate(10)

        for rand_net in random_networks:
            # Allow slight variation for BA model
            if randomizer_class == BarabasiAlbert:
                max_diff = max(1, original_nodes * 0.1)
                assert abs(rand_net.number_of_nodes() - original_nodes) <= max_diff
            else:
                assert rand_net.number_of_nodes() == original_nodes

    @pytest.mark.parametrize("randomizer_class,network_factory,kwargs", [
        (MarkovChainSwitching, _create_polarity_network, {'switch_factor': 10}),
        (ErdosRenyi, _create_polarity_network, {}),
        (BarabasiAlbert, _create_polarity_network, {}),
        (ConfigurationModel, _create_polarity_network, {}),
    ])
    def test_works_with_polarity(
        self, randomizer_class, network_factory, kwargs
    ):
        """Test that randomizers work with polarity networks."""
        network = network_factory()
        randomizer = randomizer_class(network, **kwargs)
        random_networks = randomizer.generate(5)

        assert len(random_networks) == 5
        for rand_net in random_networks:
            if rand_net.number_of_edges() > 0:
                for u, v, data in rand_net.edges(data=True):
                    assert 'polarity' in data
                    assert data['polarity'] in ['+', '-']

    @pytest.mark.parametrize("randomizer_class,network_factory,kwargs", [
        (MarkovChainSwitching, _create_large_network, {'switch_factor': 10}),
        (ErdosRenyi, _create_large_network, {}),
        (BarabasiAlbert, _create_large_network, {}),
        (ConfigurationModel, _create_large_network, {}),
    ])
    def test_generates_different_networks(
        self, randomizer_class, network_factory, kwargs
    ):
        """Test that generated networks are actually random and different."""
        network = network_factory()
        randomizer = randomizer_class(network, **kwargs)
        random_networks = randomizer.generate(10)

        # Check that at least some networks are different from each other
        different_count = 0
        for i in range(len(random_networks) - 1):
            if _networks_are_different(random_networks[i], random_networks[i + 1]):
                different_count += 1

        # At least 80% should be different (allowing some rare duplicates)
        assert different_count >= len(random_networks) * 0.8


class TestMarkovChainSwitching:
    """Specific tests for Markov Chain Switching randomizer."""

    def test_preserves_exact_edge_count(self):
        """Test that generated networks have exact same number of edges."""
        network = _create_simple_network()
        original_edges = network.graph.number_of_edges()

        randomizer = MarkovChainSwitching(network, switch_factor=10)
        random_networks = randomizer.generate(10)

        for rand_net in random_networks:
            assert rand_net.number_of_edges() == original_edges

    def test_preserves_per_node_polarity_degrees(self):
        """Test that per-node, per-polarity out-degrees are preserved."""
        G = nx.DiGraph()
        G.add_edge(0, 1, sign='+')
        G.add_edge(0, 2, sign='+')
        G.add_edge(0, 3, sign='-')
        G.add_edge(1, 2, sign='+')
        G.add_edge(1, 3, sign='-')
        G.add_edge(1, 4, sign='-')
        network = from_networkx(G, polarity_attr='sign', polarity_values=['+', '-'])

        # Calculate original per-node, per-polarity out-degrees
        original_pol_deg = {}
        for node in network.graph.nodes():
            original_pol_deg[node] = {'+': 0, '-': 0}
            for _, target in network.graph.out_edges(node):
                pol = network.graph[node][target]['polarity']
                original_pol_deg[node][pol] += 1

        randomizer = MarkovChainSwitching(network, switch_factor=10)
        random_networks = randomizer.generate(10)

        for rand_net in random_networks:
            rand_pol_deg = {}
            for node in rand_net.nodes():
                rand_pol_deg[node] = {'+': 0, '-': 0}
                for _, target in rand_net.out_edges(node):
                    pol = rand_net[node][target]['polarity']
                    rand_pol_deg[node][pol] += 1
            assert rand_pol_deg == original_pol_deg


class TestErdosRenyi:
    """Specific tests for Erdos-Renyi randomizer."""

    def test_approximate_edge_count(self):
        """Test that average edge count is close to original."""
        network = _create_large_network()
        original_edges = network.graph.number_of_edges()

        randomizer = ErdosRenyi(network)
        random_networks = randomizer.generate(100)

        avg = sum(net.number_of_edges() for net in random_networks)
        avg_edges = avg / len(random_networks)
        assert abs(avg_edges - original_edges) < original_edges * 0.3


class TestBarabasiAlbert:
    """Specific tests for Barabasi-Albert randomizer."""

    def test_approximate_edge_count(self):
        """Test that edge count is close to original."""
        G = nx.DiGraph()
        edges = [(i, (i + 1) % 15) for i in range(15)]
        edges.extend([(i, (i + 2) % 15) for i in range(0, 15, 2)])
        G.add_edges_from(edges)
        network = from_networkx(G)
        original_edges = network.graph.number_of_edges()

        randomizer = BarabasiAlbert(network)
        random_networks = randomizer.generate(50)

        avg = sum(net.number_of_edges() for net in random_networks)
        avg_edges = avg / len(random_networks)
        assert abs(avg_edges - original_edges) < 2


class TestConfigurationModel:
    """Specific tests for Configuration Model randomizer."""

    def test_preserves_approximate_edge_count(self):
        """Test that generated networks preserve reasonable edge counts."""
        network = _create_large_network()
        original_edges = network.graph.number_of_edges()

        randomizer = ConfigurationModel(network)
        random_networks = randomizer.generate(10)

        avg = sum(net.number_of_edges() for net in random_networks)
        avg_edges = avg / len(random_networks)
        assert avg_edges >= original_edges * 0.7

    def test_no_self_loops(self):
        """Test that self-loops are removed."""
        network = _create_polarity_network()
        randomizer = ConfigurationModel(network)
        random_networks = randomizer.generate(20)

        for rand_net in random_networks:
            for u, v in rand_net.edges():
                assert u != v

    def test_no_multi_edges(self):
        """Test that multi-edges are not created."""
        network = _create_polarity_network()
        randomizer = ConfigurationModel(network)
        random_networks = randomizer.generate(20)

        for rand_net in random_networks:
            edge_set = set()
            for u, v in rand_net.edges():
                edge_pair = (u, v)
                assert edge_pair not in edge_set
                edge_set.add(edge_pair)

    def test_preserves_polarity_ratio(self):
        """Test that overall polarity ratio is approximately preserved."""
        G = nx.DiGraph()
        G.add_edge(0, 1, sign='+')
        G.add_edge(0, 2, sign='+')
        G.add_edge(0, 3, sign='+')
        G.add_edge(1, 2, sign='-')
        G.add_edge(2, 3, sign='-')
        network = from_networkx(G, polarity_attr='sign', polarity_values=['+', '-'])

        randomizer = ConfigurationModel(network)
        random_networks = randomizer.generate(10)

        for rand_net in random_networks:
            if rand_net.number_of_edges() > 0:
                plus_count = sum(
                    1 for u, v in rand_net.edges()
                    if rand_net[u][v]['polarity'] == '+'
                )
                minus_count = sum(
                    1 for u, v in rand_net.edges()
                    if rand_net[u][v]['polarity'] == '-'
                )
                total = plus_count + minus_count
                assert abs(plus_count / total - 0.6) < 0.15

    def test_raises_error_for_non_polarity_network(self):
        """Test that error is raised for networks without polarity."""
        network = _create_simple_network()
        with pytest.raises(ValueError, match="requires a polarity network"):
            ConfigurationModel(network)

    def test_works_with_three_polarity_values(self):
        """Test that the randomizer works with three polarity values."""
        G = nx.DiGraph()
        G.add_edge(0, 1, sign='+')
        G.add_edge(0, 2, sign='-')
        G.add_edge(1, 2, sign='complex')
        G.add_edge(2, 3, sign='+')
        G.add_edge(3, 0, sign='complex')
        network = from_networkx(
            G, polarity_attr='sign',
            polarity_values=['+', '-', 'complex']
        )

        randomizer = ConfigurationModel(network)
        random_networks = randomizer.generate(5)

        assert len(random_networks) == 5
        for rand_net in random_networks:
            for u, v, data in rand_net.edges(data=True):
                assert 'polarity' in data
                assert data['polarity'] in ['+', '-', 'complex']
