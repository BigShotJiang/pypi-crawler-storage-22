import networkx as nx
import pytest
from pathlib import Path

from polarity_network_motifs.loaders import from_edgelist
from polarity_network_motifs.subgraphs.fanmod_esu import FanmodESU
from polarity_network_motifs.subgraphs.mfinder_enum_induced import MFinderInduced
from polarity_network_motifs.subgraphs.mfinder_enum_none_induced import MFinderNoneInduced
from polarity_network_motifs.isomorphic.isomorphic import match_two_fsl_id_lists, IsomorphicMotifMatch
from polarity_network_motifs.subgraphs.netsci_wrapper import NetsciWrapper
from polarity_network_motifs.utils.sub_graphs import get_sub_id_name
from polarity_network_motifs.subgraphs.triadic_census import TriadicCensus
from polarity_network_motifs.utils.types import SubGraphSearchResult


# Get the data directory path
DATA_DIR = Path(__file__).parent / "data"


def _compare(k: int, expected_sub_graphs: dict, actual_sub_graphs: SubGraphSearchResult, test_specific=True):
    """Compare expected and actual subgraph counts."""
    for sub_id in actual_sub_graphs.fsl:
        if test_specific:
            sub_name = get_sub_id_name(sub_id=sub_id, k=k)
            if sub_name not in expected_sub_graphs:
                continue
            assert actual_sub_graphs.fsl[sub_id] == expected_sub_graphs[sub_name]
        else:
            assert actual_sub_graphs.fsl[sub_id] == expected_sub_graphs[sub_id]


# Test data from Uri Alon 2002 paper "Network Motifs: Simple Building Blocks of Complex Networks"
paper_example_induced = (
    DATA_DIR / "example.txt",
    {"cascade": 10, "fan out": 3, "feed forward": 5}
)

paper_ecoli_induced = (
    DATA_DIR / "coliInterNoAutoRegVec.txt",
    {"cascade": 162, "fan out": 226, "feed forward": 40}
)

paper_example_none_induced = (
    DATA_DIR / "example.txt",
    {"cascade": 15, "fan out": 8, "feed forward": 5}
)

paper_ecoli_none_induced = (
    DATA_DIR / "coliInterNoAutoRegVec.txt",
    {"cascade": 202, "fan out": 266, "feed forward": 40}
)


@pytest.mark.parametrize("network_file,expected", [paper_example_induced, paper_ecoli_induced])
def test_three_sub_graphs_induced(network_file, expected):
    """Test k=3 induced subgraph enumeration across all algorithms."""
    k = 3

    # Load network using the standard loader
    network = from_edgelist(str(network_file), nodetype=int)

    # Create isomorphic mapping (no polarity for these tests)
    iso_matcher = IsomorphicMotifMatch(k=k, polarity_options=[])
    isomorphic_mapping = iso_matcher.isomorphic_mapping

    # Test MFinder induced
    mfinder = MFinderInduced(network.graph, isomorphic_mapping)
    mfinder_sub_graphs = mfinder.search_sub_graphs(k=k, allow_self_loops=False)
    _compare(k, expected, mfinder_sub_graphs)

    # Test Fanmod ESU
    fanmod = FanmodESU(network.graph, isomorphic_mapping)
    fanmod_sub_graphs = fanmod.search_sub_graphs(k=k, allow_self_loops=False)
    _compare(k, expected, fanmod_sub_graphs)

    # Test Triadic Census
    triadic_census = TriadicCensus(network.graph, isomorphic_mapping)
    triadic_census_sub_graphs = triadic_census.search_sub_graphs(k=k, allow_self_loops=False)
    _compare(k, expected, triadic_census_sub_graphs)

    # Test NetSci wrapper
    netsci_wrap = NetsciWrapper(network.graph, isomorphic_mapping)
    netsci_wrap_sub_graphs = netsci_wrap.search_sub_graphs(k=k, allow_self_loops=False)
    _compare(k, expected, netsci_wrap_sub_graphs)


@pytest.mark.parametrize("network_file,expected", [paper_example_none_induced, paper_ecoli_none_induced])
def test_three_sub_graphs_none_induced(network_file, expected):
    """Test k=3 non-induced subgraph enumeration."""
    k = 3

    # Load network using the standard loader
    network = from_edgelist(str(network_file), nodetype=int)

    # Create isomorphic mapping (no polarity for these tests)
    iso_matcher = IsomorphicMotifMatch(k=k, polarity_options=[])
    isomorphic_mapping = iso_matcher.isomorphic_mapping

    # Test MFinder non-induced
    mfinder = MFinderNoneInduced(network.graph, isomorphic_mapping)
    mfinder_sub_graphs = mfinder.search_sub_graphs(k=k, allow_self_loops=False)
    _compare(k, expected, mfinder_sub_graphs)


def test_k_2_with_self_loops():
    """Test k=2 motifs with self-loops allowed."""
    k = 2

    # Create isomorphic mapping with self-loops
    iso_matcher = IsomorphicMotifMatch(k=k, polarity_options=[], allow_self_loops=True)
    isomorphic_mapping = iso_matcher.isomorphic_mapping

    # Create test graph with self-loops
    graph = nx.DiGraph([(1, 2), (1, 1), (1, 3), (3, 2), (3, 4), (4, 4)])
    expected = {2: 1, 3: 2, 5: 1}

    # Test MFinder
    mfinder = MFinderInduced(graph, isomorphic_mapping)
    mfinder_sub_graphs = mfinder.search_sub_graphs(k=k, allow_self_loops=True)
    _compare(k, expected, mfinder_sub_graphs, test_specific=False)

    # Test Fanmod
    fanmod = FanmodESU(graph, isomorphic_mapping)
    fanmod_sub_graphs = fanmod.search_sub_graphs(k=k, allow_self_loops=True)
    _compare(k, expected, fanmod_sub_graphs, test_specific=False)


def test_k_2_with_self_loops_wo_iso_mapping():
    """Test k=2 motifs with self-loops but without pre-computed isomorphic mapping."""
    k = 2

    # Create test graph with self-loops
    graph = nx.DiGraph([(1, 2), (1, 1), (1, 3), (3, 2), (3, 4), (4, 4)])
    expected = {2: 1, 3: 2, 5: 1}

    # Test MFinder without isomorphic mapping
    mfinder = MFinderInduced(graph, isomorphic_mapping={})
    mfinder_sub_graphs = mfinder.search_sub_graphs(k=k, allow_self_loops=True)

    # Match FSL IDs dynamically
    ids_iso_mapping = match_two_fsl_id_lists(
        list(mfinder_sub_graphs.fsl.keys()),
        list(expected.keys()),
        k=k
    )
    for src_id in ids_iso_mapping:
        tar_id = ids_iso_mapping[src_id]
        assert mfinder_sub_graphs.fsl[src_id] == expected[tar_id]

    # Test Fanmod without isomorphic mapping
    fanmod = FanmodESU(graph, isomorphic_mapping={})
    fanmod_sub_graphs = fanmod.search_sub_graphs(k=k, allow_self_loops=True)

    # Match FSL IDs dynamically
    ids_iso_mapping = match_two_fsl_id_lists(
        list(fanmod_sub_graphs.fsl.keys()),
        list(expected.keys()),
        k=k
    )
    for src_id in ids_iso_mapping:
        tar_id = ids_iso_mapping[src_id]
        assert fanmod_sub_graphs.fsl[src_id] == expected[tar_id]
