import pytest
import networkx as nx
from pathlib import Path
from polarity_network_motifs.loaders import from_edgelist, from_networkx
from polarity_network_motifs.subgraphs.mfinder_enum_induced import MFinderInduced
from polarity_network_motifs.subgraphs.netsci_wrapper import NetsciWrapper
from polarity_network_motifs.isomorphic.isomorphic import IsomorphicMotifMatch

# Define path to the example file
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
POLARITY_EXAMPLE_PATH = PROJECT_ROOT / "examples" / "polarity_and_large_examples" / "polarity_example.txt"


def normalize_participants(participants):
    """
    Normalize structure of participating subgraphs for comparison.
    participants is a list of tuples (edges). Each edge is (u, v, attr).
    """
    normalized = []
    for subgraph_edges in participants:
        edges_set = []
        for item in subgraph_edges:
            if len(item) == 3:
                u, v, d = item
                # Convert dict to tuple of items for hashing/sorting
                d_tuple = tuple(sorted(d.items()))
                edges_set.append((u, v, d_tuple))
            else:
                edges_set.append(item)

        edges_set.sort()
        normalized.append(tuple(edges_set))

    normalized.sort()
    return normalized


def _run_comparison(network, k=3):
    """
    Helper to run MFinder vs Netsci comparison.
    """
    iso_matcher = IsomorphicMotifMatch(k=k, polarity_options=network.polarity_options)
    isomorphic_mapping = iso_matcher.isomorphic_mapping

    # Run MFinder (Oracle)
    print("Running MFinderInduced...")
    mfinder = MFinderInduced(network.graph, isomorphic_mapping)
    res_mfinder = mfinder.search_sub_graphs(k=k, allow_self_loops=False)

    # Run NetsciWrapper (Target)
    print("Running NetsciWrapper...")
    netsci = NetsciWrapper(network.graph, isomorphic_mapping)
    res_netsci = netsci.search_sub_graphs(k=k, allow_self_loops=False)

    # Compare FSL counts
    print(f"MFinder FSL: {res_mfinder.fsl}")
    print(f"Netsci FSL: {res_netsci.fsl}")

    all_keys = set(res_mfinder.fsl.keys()) | set(res_netsci.fsl.keys())
    for key in all_keys:
        if isinstance(key, int):
            count_mf = res_mfinder.fsl.get(key, 0)
            count_ns = res_netsci.fsl.get(key, 0)
            assert count_mf == count_ns, f"Count mismatch for motif {key}: MF={count_mf}, NS={count_ns}"

    # Compare Participants
    for key in all_keys:
        if isinstance(key, int) and res_mfinder.fsl.get(key, 0) > 0:
            parts_mf = res_mfinder.fsl_fully_mapped.get(key, [])
            parts_ns = res_netsci.fsl_fully_mapped.get(key, [])

            assert len(parts_mf) == len(parts_ns), f"Instance count mismatch for {key}"

            norm_mf = normalize_participants(parts_mf)
            norm_ns = normalize_participants(parts_ns)

            # Allow for different ordering of instances in the list
            assert norm_mf == norm_ns, f"Participants mismatch for {key}.\nMF: {norm_mf}\nNS: {norm_ns}"


def test_polarity_subgraphs_comparison_file():
    """
    Test comparison on the example file.
    """
    if not POLARITY_EXAMPLE_PATH.exists():
        pytest.fail(f"Polarity example file not found at {POLARITY_EXAMPLE_PATH}")

    print(f"\nRunning File Test: {POLARITY_EXAMPLE_PATH}")
    network = from_edgelist(
        str(POLARITY_EXAMPLE_PATH),
        polarity_col=3,
        polarity_values=['+', '-'],
        delimiter=' ',
        comments='#'
    )

    _run_comparison(network, k=3)


def test_netsci_wrapper_string_node_mapping():
    """
    Test NetsciWrapper with string node names that are inserted in a non-sorted order.
    Ref: The bug where nx.to_scipy_sparse_array used insertion order vs sorted order.
    """
    print("\nRunning String Node Mapping Test...")
    G = nx.DiGraph()
    # Insert nodes/edges in an order that differs from sorted order ('A', 'C', 'B' order)
    # Sorted: A, B, C

    # Motif: Feed Forward Loop (A->B, B->C, A->C)
    # With polarity all '1' (or '+')

    # We add edges in mixed order
    G.add_edge('A', 'C', polarity='+')
    G.add_edge('B', 'C', polarity='+')
    G.add_edge('A', 'B', polarity='+')

    # Add a disjoint pair to ensure gaps in indexing or order don't matter
    # Z -> X (Sorted: X, Z)
    G.add_edge('Z', 'X', polarity='+')

    network = from_networkx(G, polarity_attr='polarity', polarity_values=['+'])

    # We expect Motif 38 (FFL) for the A,B,C triangle.
    _run_comparison(network, k=3)


if __name__ == "__main__":
    test_polarity_subgraphs_comparison_file()
    test_netsci_wrapper_string_node_mapping()
