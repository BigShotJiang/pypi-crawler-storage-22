import pickle
import h5py
import numpy as np
from polarity_network_motifs.utils.types import SearchResultBinaryFile


def export_results(data: SearchResultBinaryFile, filepath: str = None):
    """Export results to HDF5 file with efficient storage and partial loading support.

    Args:
        data: Results data to export
        filepath: Path to save file (.h5 extension)
    """
    if filepath is None:
        raise ValueError("filepath is required")

    with h5py.File(filepath, 'w') as f:
        # Save configuration as attributes
        config_group = f.create_group('config')
        if data['args']:
            for key, value in data['args'].items():
                if value is not None:
                    config_group.attrs[key] = value if not isinstance(value, (list, dict)) else str(value)

        # Save motifs
        motifs_group = f.create_group('motifs')
        for motif_id, motif in data['motifs'].items():
            motif_group = motifs_group.create_group(str(motif_id))

            # Save motif metadata
            motif_group.attrs['id'] = motif_id
            motif_group.attrs['name'] = motif.name
            motif_group.attrs['n_real'] = motif.n_real

            # Store adjacency matrix and role_pattern as datasets
            motif_group.create_dataset('adj_mat', data=motif.adj_mat, compression='gzip')
            motif_group.create_dataset('role_pattern', data=np.void(pickle.dumps(motif.role_pattern)))

            # Save motif criteria if available
            if motif.motif_criteria:
                mc = motif.motif_criteria
                motif_group.attrs['z_score'] = mc.z_score if mc.z_score else -999.0
                motif_group.attrs['n_rand'] = mc.n_rand if mc.n_rand else 0.0
                motif_group.attrs['std'] = mc.std if mc.std else 0.0
                motif_group.attrs['is_significant'] = mc.is_statistically_significant or False

            # Save subgraph appearances (can be huge - stored as dataset for efficiency)
            if motif.sub_graphs:
                # Pickle entire list and store as single binary blob
                pickled_data = np.void(pickle.dumps(motif.sub_graphs))
                motif_group.create_dataset('subgraphs', data=pickled_data)

            # Save random network samples if available
            if hasattr(motif, 'random_network_samples') and motif.random_network_samples:
                motif_group.create_dataset('random_samples', data=motif.random_network_samples, compression='gzip')

            # Save polarity motifs
            if motif.polarity_motifs:
                pol_group = motif_group.create_group('polarity_motifs')
                for idx, pol_motif in enumerate(motif.polarity_motifs):
                    pol_motif_group = pol_group.create_group(f'variant_{idx}')
                    pol_motif_group.attrs['polarity'] = str(pol_motif.polarity)
                    pol_motif_group.attrs['n_real'] = pol_motif.n_real

                    if pol_motif.motif_criteria:
                        pmc = pol_motif.motif_criteria
                        pol_motif_group.attrs['z_score'] = pmc.z_score if pmc.z_score else -999.0
                        pol_motif_group.attrs['n_rand'] = pmc.n_rand if pmc.n_rand else 0.0
                        pol_motif_group.attrs['std'] = pmc.std if pmc.std else 0.0
                        pol_motif_group.attrs['is_significant'] = pmc.is_statistically_significant or False

                    if pol_motif.sub_graphs:
                        pickled_data = np.void(pickle.dumps(pol_motif.sub_graphs))
                        pol_motif_group.create_dataset('subgraphs', data=pickled_data)


def import_results(file_path: str, motif_ids: list = None) -> SearchResultBinaryFile:
    """Import results from HDF5 file with optional partial loading.

    Args:
        file_path: Path to HDF5 file
        motif_ids: Optional list of specific motif IDs to load (for partial loading)

    Returns:
        SearchResultBinaryFile with loaded data
    """
    from polarity_network_motifs.utils.types import Motif, MotifCriteriaResults

    with h5py.File(file_path, 'r') as f:
        # Load configuration
        config = {}
        if 'config' in f:
            for key, value in f['config'].attrs.items():
                config[key] = value

        # Load motifs
        motifs = {}
        motifs_group = f['motifs']

        # Determine which motifs to load
        if motif_ids is None:
            motif_keys = list(motifs_group.keys())
        else:
            motif_keys = [str(mid) for mid in motif_ids if str(mid) in motifs_group]

        for motif_key in motif_keys:
            motif_group = motifs_group[motif_key]

            # Load basic motif data
            motif_id = motif_group.attrs['id']
            adj_mat = motif_group['adj_mat'][:]
            role_pattern = pickle.loads(bytes(motif_group['role_pattern'][()]))

            # Load subgraphs if present
            sub_graphs = []
            if 'subgraphs' in motif_group:
                sub_graphs = pickle.loads(bytes(motif_group['subgraphs'][()]))

            # Load motif criteria
            motif_criteria = None
            if 'z_score' in motif_group.attrs:
                z_score = motif_group.attrs['z_score']
                motif_criteria = MotifCriteriaResults(
                    n_real=motif_group.attrs['n_real'],
                    z_score=z_score if z_score != -999.0 else None,
                    n_rand=motif_group.attrs.get('n_rand', 0.0),
                    std=motif_group.attrs.get('std', 0.0),
                    is_statistically_significant=motif_group.attrs.get('is_significant', False)
                )

            # Create motif object (use construct to bypass validation for loaded data)
            motif = Motif.model_construct(
                id=motif_id,
                name=motif_group.attrs['name'],
                adj_mat=adj_mat,
                role_pattern=role_pattern,
                n_real=motif_group.attrs['n_real'],
                sub_graphs=sub_graphs,
                motif_criteria=motif_criteria
            )

            # Load random samples if present
            if 'random_samples' in motif_group:
                motif.random_network_samples = list(motif_group['random_samples'][:])

            # Load polarity motifs if present
            if 'polarity_motifs' in motif_group:
                pol_group = motif_group['polarity_motifs']
                motif.polarity_motifs = []

                for pol_key in sorted(pol_group.keys()):
                    pol_motif_group = pol_group[pol_key]

                    pol_sub_graphs = []
                    if 'subgraphs' in pol_motif_group:
                        pol_sub_graphs = pickle.loads(bytes(pol_motif_group['subgraphs'][()]))

                    pol_criteria = None
                    if 'z_score' in pol_motif_group.attrs:
                        z_score = pol_motif_group.attrs['z_score']
                        pol_criteria = MotifCriteriaResults(
                            n_real=pol_motif_group.attrs['n_real'],
                            z_score=z_score if z_score != -999.0 else None,
                            n_rand=pol_motif_group.attrs.get('n_rand', 0.0),
                            std=pol_motif_group.attrs.get('std', 0.0),
                            is_statistically_significant=pol_motif_group.attrs.get('is_significant', False)
                        )

                    pol_motif = Motif.model_construct(
                        id=f"{motif_id} {pol_motif_group.attrs['polarity']}",
                        name=motif.name,
                        adj_mat=adj_mat,
                        role_pattern=role_pattern,
                        polarity=eval(pol_motif_group.attrs['polarity']),
                        n_real=pol_motif_group.attrs['n_real'],
                        sub_graphs=pol_sub_graphs,
                        motif_criteria=pol_criteria
                    )
                    motif.polarity_motifs.append(pol_motif)

            motifs[motif_id] = motif

        # Sort motifs dictionary by ID
        sorted_motifs = dict(sorted(motifs.items(), key=lambda item: int(str(item[0]).split()[0])))

        return SearchResultBinaryFile(args=config if config else None, motifs=sorted_motifs)
