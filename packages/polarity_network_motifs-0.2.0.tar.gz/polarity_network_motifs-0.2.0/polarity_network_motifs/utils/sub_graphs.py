import networkx as nx
import numpy as np
from networkx import DiGraph
from polarity_network_motifs.utils.common import get_decimal_from_bin_vec, get_bin_vec_from_decimal
from polarity_network_motifs.utils.types import Motif


class HashedGraph:
    def __init__(self, graph: tuple):
        self.graph = graph

    def __eq__(self, other):
        return sorted(self.graph) == sorted(other.graph)

    def __hash__(self):
        return hash(tuple(sorted(self.graph)))

    def __str__(self):
        return str(self.graph)


def graph_to_hashed_graph(g: DiGraph) -> HashedGraph:
    graph_tuple = tuple(list(g.edges))
    return HashedGraph(graph_tuple)


tuples_names = {
    2: "unidirectional",
    6: "reciprocal",
}


triplets_names = {
    14: "mutual out",
    38: "feed forward",
    46: "regulating mutual",
    74: "mutual in",
    78: "bi-mutual",
    102: "mutual cascade",
    108: "regulated mutual",
    110: "semi clique",
    6: "fan out",
    12: "cascade",
    36: "fan in",
    98: "feed backward",
    238: "clique"
}


quadruplets_names = {
    204: "bi-fan",
    904: "bi-parallel",
    14: "sim-3"
}


def get_sub_id_name(sub_id: int, k: int) -> str:
    if k not in [2, 3, 4]:
        return "n/a"
    if k == 2:
        return tuples_names.get(sub_id, "n/a")
    elif k == 3:
        return triplets_names.get(sub_id, "n/a")
    else:
        return quadruplets_names.get(sub_id, "n/a")


def get_adjacency_matrix(graph: DiGraph) -> np.ndarray:
    nodes = list(graph.nodes)
    nodes.sort()
    adj_mat = nx.adjacency_matrix(graph, nodelist=nodes).todense()
    # Convert to binary (0/1) - any non-zero weight becomes 1
    return (adj_mat > 0).astype(int)


def get_id(graph: DiGraph) -> int:
    adj_mat = get_adjacency_matrix(graph)
    vec = adj_mat.flatten()
    decimal_id = get_decimal_from_bin_vec(list(vec))
    return decimal_id


def get_sub_graph_from_id(decimal: int, k: int) -> DiGraph:
    bin_digits = get_bin_vec_from_decimal(decimal=decimal, pad_to=k ** 2)
    bin_digits.reverse()
    adj_mat = np.array(bin_digits).reshape(k, k)
    return nx.DiGraph(adj_mat)


def get_number_of_disjoint_group_nodes(sub_graphs: list[tuple[tuple]]) -> int:
    """
    :param sub_graphs: all the sub graphs (list of edges) participating in a candidate motif sub graph
    :return: the number of completely disjoint groups of nodes
    """
    graph = nx.DiGraph()
    for sub_graph in sub_graphs:
        graph.add_edges_from(sub_graph)

    return nx.number_weakly_connected_components(graph)


def get_role_pattern(adj_mat: np.ndarray) -> list[tuple]:
    """
    :param adj_mat: the adjacency matrix of the motif
    :return: list of tuples with roles of the motif, in the format: (a,b), (b,c)
    """
    ascii_start = 97
    roles: list[tuple] = []
    for src, arr in enumerate(adj_mat):
        for tar, val in enumerate(arr):
            if val != 1:
                continue
            roles.append((chr(src + ascii_start), chr(tar + ascii_start)))
    return roles


def create_base_motif(sub_id: int, k: int) -> Motif:
    name = get_sub_id_name(sub_id=sub_id, k=k)
    sub_graph = get_sub_graph_from_id(decimal=sub_id, k=k)
    adj_mat = nx.adjacency_matrix(sub_graph).todense()
    role_pattern = get_role_pattern(adj_mat)
    return Motif(name=name, id=sub_id, adj_mat=adj_mat, role_pattern=role_pattern)
