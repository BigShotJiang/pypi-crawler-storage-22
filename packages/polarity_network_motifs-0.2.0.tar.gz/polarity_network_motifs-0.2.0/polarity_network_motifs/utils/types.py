from argparse import Namespace
from enum import Enum
from typing import Optional, Union, TypedDict

import numpy as np
from networkx import DiGraph
from pydantic import BaseModel, ConfigDict


class NetworkLoaderArgs(BaseModel):
    weight_threshold: int = 0
    filter_polarity: Optional[list[str]] = None
    allow_self_loops: Optional[bool] = False


class SubGraphAlgoName(str, Enum):
    mfinder_induced = 'mfinder_i'
    mfinder_none_induced = 'mfinder_ni'
    fanmod_esu = 'fanmod'
    triadic_census = 'triadic_census'
    netsci_wrapper = 'netsci_wrapper'


class RandomGeneratorAlgoName(str, Enum):
    markov_chain_switching = 'markov_chain'
    erdos_renyi = 'erdos_renyi'
    barabasi = 'barabasi'


class MotifType(str, Enum):
    motif = 'motif'
    anti_motif = 'anti-motif'
    none = 'none'


class MotifCriteriaArgs(BaseModel):
    alpha: float
    uniqueness_threshold: int
    use_uniq_criteria: bool
    frequency_threshold: float


class MotifCriteriaResults(BaseModel):
    n_real: int
    is_statistically_significant: Optional[bool] = False
    n_rand: Optional[float] = 0.0
    z_score: Optional[float] = 0.0
    std: Optional[float] = 0.0
    p_value: Optional[float] = 0.0
    uniq: Optional[int] = -1
    is_motif_frequent: Optional[bool] = False
    is_anti_motif_frequent: Optional[bool] = False
    is_uniq: Optional[Union[bool, str]] = False
    is_motif: Optional[MotifType] = MotifType.none


class PolarityFrequencies(BaseModel):
    frequency: int
    polarity: list[str]
    sub_graphs: list


class Motif(BaseModel):
    """
    Motif representation with structural and statistical information.

    Note: node_roles and node_appearances are NOT saved to .h5 files to minimize file size.
    They are computed on-demand from sub_graphs when needed by analysis tools.
    Use polarity_network_motifs.analysis.tools.populate_node_data() to populate these fields.
    """
    model_config = ConfigDict(arbitrary_types_allowed=True)
    name: str
    id: Union[int, str]  # motif if / sub graph id
    adj_mat: np.ndarray  # adjacency matrix
    role_pattern: list[tuple]  # the adjacency matrix in an edge tuple format: e.g.: (a,b), (a,c)
    n_real: Optional[int] = 0  # number of appearances in the real network
    motif_criteria: Optional[MotifCriteriaResults] = None
    random_network_samples: Optional[list[int]] = []  # number of appearances of this motif id in the random networks

    # all the isomorphic sub graphs appearances - in a tuple-edge format: (s,t,polarity)
    sub_graphs: Optional[list[tuple[tuple]]] = []
    # dict of dicts, key=role. value = dict where keys are node name and value are their freq.
    # COMPUTED ON DEMAND - not saved to disk, call populate_node_data() to populate
    node_roles: Optional[dict] = {}

    # a sorted dict of the nodes that appear in this motif
    # the key is either a neuron name or node id
    # COMPUTED ON DEMAND - not saved to disk, call populate_node_data() to populate
    node_appearances: Optional[dict[Union[int, str], int]] = {}

    polarity_motifs: Optional[list['Motif']] = []
    polarity: Optional[list[str]] = []


class SubGraphSearchResult(BaseModel):
    # frequent sub graph list: key=motif id, value is the frequency
    fsl: dict[Union[str, int], int]
    # same fsl, the value is the list of sub graphs
    fsl_fully_mapped: dict[Union[str, int], list[tuple]]


class SearchResultBinaryFile(TypedDict):
    args: Namespace
    motifs: dict[Union[str, int], Motif]


class NetworkBinaryFile(TypedDict):
    graph: DiGraph
    participating_nodes: set
    neuron_names: list
