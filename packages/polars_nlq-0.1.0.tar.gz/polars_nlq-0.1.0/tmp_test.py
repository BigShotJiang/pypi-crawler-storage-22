from __future__ import annotations

import instructor
import polars as pl
from openai import OpenAI

from polars_nlq import execute_plan, nl_query


def main() -> None:
    # lf = pl.scan_csv("city_sales.csv")
    lf = pl.scan_csv("/Users/miniml/Downloads/customers-100000.csv")
    # lf = pl.scan_ndjson("/Users/miniml/tmp/news/news.jsonl")
    df = lf.collect()
    openai_client = OpenAI(base_url="http://localhost:8080/v1", api_key="dummy")
    client = instructor.from_openai(openai_client, mode=instructor.Mode.JSON)
    # plan = nl_query(client, lf.collect_schema(), "sum of sales by city, with at least 20 sales")
    plan = nl_query(client, lf.collect_schema(), "count of customers, by country then city")
    print(plan)
    result = execute_plan(df, plan).collect()

    print(result.sort(result.columns[-1]))
    


if __name__ == "__main__":
    main()
