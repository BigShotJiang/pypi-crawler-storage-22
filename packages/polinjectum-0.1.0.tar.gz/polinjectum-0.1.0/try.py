from polinjectum import PolInjectumContainer, Lifecycle, injectable

class A:
    pass

class D:
    pass

@injectable(A, qualifier="first")
class B(A):
    pass

@injectable(A)
class C(A):
    pass

c = PolInjectumContainer().get_me(A)
print(1)