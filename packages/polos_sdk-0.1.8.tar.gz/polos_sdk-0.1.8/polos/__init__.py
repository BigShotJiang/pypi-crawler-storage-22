# Version is managed by hatch-vcs from git tags
__version__ = "0.1.0"  # This will be replaced by hatch-vcs during build

# Core imports
from .agents.agent import (
    Agent,
    AgentStreamHandle,
    StreamResult,
)
from .agents.stop_conditions import (
    ExecutedToolConfig,
    HasTextConfig,
    MaxStepsConfig,
    MaxTokensConfig,
    StopConditionContext,
    executed_tool,
    has_text,
    max_steps,
    max_tokens,
    stop_condition,
)
from .core.context import AgentContext, WorkflowContext
from .core.state import WorkflowState
from .core.workflow import (
    StepExecutionError,
    Workflow,
    WorkflowTimeoutError,
    get_all_workflows,
    get_workflow,
    workflow,
)
from .execution import (
    DockerEnvironment,
    DockerEnvironmentConfig,
    E2BEnvironmentConfig,
    EnvironmentInfo,
    ExecOptions,
    ExecResult,
    ExecToolConfig,
    ExecutionEnvironment,
    GlobOptions,
    GrepMatch,
    GrepOptions,
    LocalEnvironment,
    LocalEnvironmentConfig,
    SandboxToolsConfig,
    SandboxToolsResult,
    sandbox_tools,
)
from .features import events, schedules
from .features.events import BatchEventPayload, EventPayload
from .features.schedules import SchedulePayload
from .middleware.guardrail import GuardrailContext, GuardrailResult, guardrail
from .middleware.hook import HookAction, HookContext, HookResult, hook
from .runtime.batch import batch_agent_invoke, batch_invoke
from .runtime.client import ExecutionHandle, PolosClient
from .runtime.queue import Queue, queue
from .runtime.worker import Worker
from .tools.ask_user import AskUserField, AskUserFieldOption, AskUserInput, create_ask_user_tool
from .tools.tool import Tool, ToolApproval, tool
from .tools.web_search import (
    WebSearchFunction,
    WebSearchOptions,
    WebSearchResult,
    WebSearchResultItem,
    WebSearchToolConfig,
    create_web_search_tool,
)
from .types.types import (
    AgentConfig,
    BatchStepResult,
    BatchWorkflowInput,
    Step,
    ToolCall,
    ToolCallFunction,
    ToolResult,
    Usage,
)

__all__ = [
    "workflow",
    "Workflow",
    "get_workflow",
    "get_all_workflows",
    "PolosClient",
    "ExecutionHandle",
    "Queue",
    "queue",
    "batch_invoke",
    "batch_agent_invoke",
    "Agent",
    "AgentStreamHandle",
    "StreamResult",
    "stop_condition",
    "max_steps",
    "max_tokens",
    "executed_tool",
    "has_text",
    "MaxTokensConfig",
    "MaxStepsConfig",
    "ExecutedToolConfig",
    "HasTextConfig",
    "StopConditionContext",
    "tool",
    "Tool",
    "ToolApproval",
    "hook",
    "HookContext",
    "HookResult",
    "HookAction",
    "guardrail",
    "GuardrailContext",
    "GuardrailResult",
    "Worker",
    "WorkflowContext",
    "AgentContext",
    "WorkflowState",
    "events",
    "schedules",
    "SchedulePayload",
    "EventPayload",
    "BatchEventPayload",
    "BatchStepResult",
    "Step",
    "Usage",
    "ToolCall",
    "ToolResult",
    "ToolCallFunction",
    "AgentConfig",
    "WorkflowTimeoutError",
    "StepExecutionError",
    "BatchWorkflowInput",
    # Execution framework
    "sandbox_tools",
    "SandboxToolsResult",
    "SandboxToolsConfig",
    "ExecutionEnvironment",
    "DockerEnvironment",
    "LocalEnvironment",
    "DockerEnvironmentConfig",
    "E2BEnvironmentConfig",
    "LocalEnvironmentConfig",
    "ExecToolConfig",
    "ExecOptions",
    "ExecResult",
    "GlobOptions",
    "GrepOptions",
    "GrepMatch",
    "EnvironmentInfo",
    # Tools
    "create_ask_user_tool",
    "AskUserInput",
    "AskUserField",
    "AskUserFieldOption",
    "create_web_search_tool",
    "WebSearchToolConfig",
    "WebSearchResult",
    "WebSearchResultItem",
    "WebSearchOptions",
    "WebSearchFunction",
]
