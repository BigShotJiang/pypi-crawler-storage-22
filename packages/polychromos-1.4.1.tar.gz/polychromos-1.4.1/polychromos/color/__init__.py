"""
Classes encapsulating colors in different formats.
"""

from .color import *
