class BaseExporter(object):
    """
    Base abstract class for PolyglotDB exporters

    Not implemented yet.
    """

    pass
