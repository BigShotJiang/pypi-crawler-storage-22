from .query import GraphQuery, SplitQuery
