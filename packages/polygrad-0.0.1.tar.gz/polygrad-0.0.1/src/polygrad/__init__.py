# polygrad - portable tensor compiler
__version__ = '0.0.1'
