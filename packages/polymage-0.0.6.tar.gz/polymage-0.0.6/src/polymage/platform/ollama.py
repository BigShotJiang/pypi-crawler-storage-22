import json
import logging
import ollama

from typing import Optional, List, Any
from pydantic import BaseModel
from PIL import Image
from tenacity import retry, stop_after_attempt, retry_if_exception_type

from polymage.model.model import Model
from polymage.media.media import Media
from polymage.media.image_media import ImageMedia
from polymage.platform.platform import Platform


logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class OllamaPlatform(Platform):
	"""
	Platform implementation for interacting with Ollama models.

	This class provides integrations for text-to-text, structured data extraction from
	text inputs, and image-to-text operations using Ollama's local inference capabilities.
	It extends the base Platform class and implements specific methods for these modalities,
	leveraging Ollama's client library. The platform supports model configuration via
	host address and utilizes retry mechanisms for structured outputs to handle invalid
	JSON responses.

	The class abstracts model interactions and handles format-specific requests such as
	image encoding to base64 for vision capabilities. Text-to-image and image-to-image
	generation are explicitly marked as unsupported.

	Methods:
	    _text2text: Performs text-to-text inference.
	    _text2data: Extracts structured data from text with retry on JSON errors.
	    _image2text: Converts an image input into textual output.
	    _text2image: Text-to-image generation (unsupported).
	    _image2image: Image-to-image transformation (unsupported).

	Attributes:
	    None publicly exposed.
	"""
	def __init__(self, host: str = "127.0.0.1:11434", **kwargs: Any) -> None:
		super().__init__('ollama', **kwargs)
		self._host = host
		self._api_key = "ollama"  # Dummy key (Ollama doesn't require real keys)


	def _text2text(self, model: Model, prompt: str, media: Optional[List[Media]] = None, response_model: Optional[BaseModel] = None, **kwargs: Any) -> str:
		system_prompt: Optional[str] = kwargs.get("system_prompt", "")
		client = ollama.Client(host=self._host)
		response = client.chat(
			model=model.internal_name(),
			messages=[
				{"role": "system", "content": system_prompt},
				{"role": "user", "content": prompt}
			],
			options={
				'temperature': kwargs.get('temperature', 0.2),
				# Disable reasoning for models that support thinking (like DeepSeek R1)
				'reasoning_format': 'none',
			}
		)
		return response['message']['content'].strip()

	#
	# using structured data may sometime fail, because the result is not a valid JSON
	# if the JSON is not valid, retry 3 times
	#
	@retry(retry=retry_if_exception_type(json.JSONDecodeError), stop=stop_after_attempt(3))
	def _text2data(self, model: Model, prompt: str, response_model: BaseModel, media: Optional[List[Media]] = None, **kwargs: Any) -> str:
		system_prompt: Optional[str] = kwargs.get("system_prompt", "")
		client = ollama.Client(host=self._host)

		json_schema = response_model.model_json_schema()

		response = client.chat(
			model=model.internal_name(),
			messages=[
				{"role": "system", "content": system_prompt},
				{"role": "user", "content": prompt}
			],
			format=json_schema,
			options={
				'temperature': kwargs.get('temperature', 0.2),
				# Disable reasoning for models that support thinking (like DeepSeek R1)
				'reasoning_format': 'none',
			}
		)
		json_string = response.message.content.strip()
		# return a python Dict
		return json.loads(json_string)



	def _image2text(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any) -> str:
		client = ollama.Client(host=self._host)
		if len(media) == 0:
			return ""
		else:
			image = media[0]
			base64_image = image.to_base64()

		response = client.chat(
			model=model.internal_name(),
			messages=[
				{
					'role': 'user',
					'content': prompt,
					'images': [base64_image],
				}
			],
			options={
				'temperature': kwargs.get('temperature', 0.2),
				# Disable reasoning for models that support thinking (like DeepSeek R1)
				'reasoning_format': 'none',
			}
		)
		return response.message.content





	def _text2image(self, model: str, prompt: str, **kwargs: Any) -> Image.Image:
		"""Not supported"""
		pass

	def _image2image(self, model: str, prompt: str, image: Image.Image, **kwargs: Any) -> Image.Image:
		"""Not supported"""
		pass

