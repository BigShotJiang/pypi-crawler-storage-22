"""
PolyPoll SDK

Unified SDK for prediction market data aggregation across
Polymarket, Kalshi, Manifold, Metaculus, and PredictIt.

Example:
    ```python
    from polypoll_sdk import PolyPollSDK

    sdk = PolyPollSDK()

    # Get all markets
    markets = await sdk.get_all_markets()

    # Search markets
    trump = await sdk.search_markets("trump")

    # Find similar markets
    similar = await sdk.get_similar_markets(market_id="...")

    # Detect arbitrage
    arb = await sdk.get_arbitrage_opportunities()
    ```
"""

from polypoll_sdk.client import PolyPollSDK
from polypoll_sdk.config import Platform, SDKConfig
from polypoll_sdk.models import (
    ArbitrageOpportunity,
    MarketOption,
    MarketStatus,
    MarketType,
    SimilarMarket,
    UnifiedMarket,
)

__version__ = "0.1.2"
__author__ = "PolyPoll Team"

__all__ = [
    # Main SDK
    "PolyPollSDK",
    # Config
    "Platform",
    "SDKConfig",
    # Models
    "ArbitrageOpportunity",
    "MarketOption",
    "MarketStatus",
    "MarketType",
    "SimilarMarket",
    "UnifiedMarket",
    # Version
    "__version__",
]
