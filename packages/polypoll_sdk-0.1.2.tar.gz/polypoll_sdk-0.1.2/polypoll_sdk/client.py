"""
PolyPoll SDK Client

Main entry point for the PolyPoll SDK.
"""

import asyncio
import logging
from typing import Dict, List, Optional

from polypoll_sdk.config import Platform, SDKConfig, get_config, set_config
from polypoll_sdk.models.market import ArbitrageOpportunity, SimilarMarket, UnifiedMarket
from polypoll_sdk.providers import (
    BaseProvider,
    KalshiProvider,
    ManifoldProvider,
    MetaculusProvider,
    PolymarketProvider,
    PredictItProvider,
)

logger = logging.getLogger(__name__)


class PolyPollSDK:
    """
    Unified SDK for prediction market data aggregation.

    Provides a single interface to fetch and analyze markets from:
    - Polymarket (crypto prediction markets)
    - Kalshi (US regulated markets)
    - Manifold Markets (play-money)
    - Metaculus (expert forecasting)
    - PredictIt (US political)

    Example:
        ```python
        from polypoll_sdk import PolyPollSDK

        sdk = PolyPollSDK()

        # Get all markets from all platforms
        markets = await sdk.get_all_markets()

        # Get markets from specific platform
        polymarket = await sdk.get_markets(platform="polymarket")

        # Search for markets
        trump_markets = await sdk.search_markets("trump")

        # Find similar markets across platforms
        similar = await sdk.get_similar_markets(market_id="polymarket_123")

        # Detect arbitrage opportunities
        arbitrage = await sdk.get_arbitrage_opportunities()
        ```
    """

    def __init__(
        self,
        exa_api_key: Optional[str] = None,
        groq_api_key: Optional[str] = None,
        kalshi_api_key: Optional[str] = None,
        cache_ttl: int = 10800,
    ):
        """
        Initialize the PolyPoll SDK.

        All API keys are optional. Core features work without any keys.
        AI features (deep_research, get_ai_odds) require EXA and GROQ keys.

        Args:
            exa_api_key: API key for Exa search (optional)
            groq_api_key: API key for Groq LLM (optional)
            kalshi_api_key: API key for Kalshi (optional)
            cache_ttl: Cache time-to-live in seconds (default: 3 hours)
        """
        # Configure SDK
        config = SDKConfig(
            exa_api_key=exa_api_key,
            groq_api_key=groq_api_key,
            kalshi_api_key=kalshi_api_key,
            cache_ttl=cache_ttl,
        )
        set_config(config)
        self.config = config

        # Initialize providers
        self._providers: Dict[str, BaseProvider] = {
            Platform.POLYMARKET: PolymarketProvider(config),
            Platform.KALSHI: KalshiProvider(config),
            Platform.MANIFOLD: ManifoldProvider(config),
            Platform.METACULUS: MetaculusProvider(config),
            Platform.PREDICTIT: PredictItProvider(config),
        }

        # Market cache
        self._cache: Dict[str, List[UnifiedMarket]] = {}

        logger.info("PolyPoll SDK initialized")

    # =========================================================================
    # Layer 1: Data Aggregation
    # =========================================================================

    async def get_all_markets(self, limit_per_platform: int = 100) -> List[UnifiedMarket]:
        """
        Fetch markets from all platforms.

        Args:
            limit_per_platform: Maximum markets per platform.

        Returns:
            List of UnifiedMarket from all platforms.
        """
        tasks = [
            self._providers[platform].get_markets(limit=limit_per_platform)
            for platform in Platform.ALL
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)

        all_markets = []
        for platform, result in zip(Platform.ALL, results):
            if isinstance(result, Exception):
                logger.error(f"[{platform}] Error fetching markets: {result}")
            else:
                all_markets.extend(result)
                self._cache[platform] = result

        logger.info(f"Fetched {len(all_markets)} markets from {len(Platform.ALL)} platforms")
        return all_markets

    async def get_markets(
        self,
        platform: str,
        limit: int = 100
    ) -> List[UnifiedMarket]:
        """
        Fetch markets from a specific platform.

        Args:
            platform: Platform name (polymarket, kalshi, manifold, metaculus, predictit)
            limit: Maximum number of markets.

        Returns:
            List of UnifiedMarket from the platform.
        """
        if platform not in self._providers:
            raise ValueError(f"Unknown platform: {platform}. Valid: {Platform.ALL}")

        markets = await self._providers[platform].get_markets(limit=limit)
        self._cache[platform] = markets
        return markets

    async def search_markets(
        self,
        query: str,
        platforms: Optional[List[str]] = None,
        limit: int = 50,
        min_score: float = 50.0
    ) -> List[UnifiedMarket]:
        """
        Search markets by keyword across platforms using fuzzy matching.

        Uses entity-aware fuzzy matching that:
        - Disables partial_ratio for short queries (≤3 chars) to avoid false matches
        - Penalizes results where key entities don't overlap
        - Uses weighted scoring: 50% ratio + 30% token_sort + 20% partial

        Args:
            query: Search query string.
            platforms: List of platforms to search (default: all)
            limit: Maximum total results.
            min_score: Minimum similarity score (0-100, default: 50)

        Returns:
            List of matching UnifiedMarket sorted by similarity score.
        """
        from polypoll_sdk.utils.similarity import calculate_similarity

        platforms = platforms or Platform.ALL

        # First, get all markets from specified platforms
        all_markets = []
        for platform in platforms:
            if platform in self._providers:
                # Use cache if available, otherwise fetch
                if platform in self._cache:
                    all_markets.extend(self._cache[platform])
                else:
                    try:
                        markets = await self._providers[platform].get_markets(limit=500)
                        self._cache[platform] = markets
                        all_markets.extend(markets)
                    except Exception as e:
                        logger.warning(f"[{platform}] Error fetching markets: {e}")

        # Calculate fuzzy similarity scores with entity awareness
        scored_markets = []

        for market in all_markets:
            title = market.title or ""
            if not title:
                continue

            # Use entity-aware similarity (returns raw_score, adjusted_score)
            _, adjusted_score = calculate_similarity(query, title)

            if adjusted_score >= min_score:
                scored_markets.append((market, adjusted_score))

        # Sort by score descending
        scored_markets.sort(key=lambda x: x[1], reverse=True)

        # Return top results
        results = [m for m, _ in scored_markets[:limit]]
        logger.info(f"Search '{query}' found {len(results)} markets (min_score={min_score})")
        return results

    # =========================================================================
    # Layer 2: Cross-Platform Matching
    # =========================================================================

    async def get_similar_markets(
        self,
        market_id: str,
        platform: Optional[str] = None,
        min_similarity: float = 65.0
    ) -> List[SimilarMarket]:
        """
        Find similar markets across all platforms.

        Args:
            market_id: Market ID to find similar markets for.
            platform: Platform of the source market (auto-detected if None)
            min_similarity: Minimum similarity score (0-100)

        Returns:
            List of SimilarMarket with similarity scores.
        """
        # Import matcher service
        from polypoll_sdk.services.matcher import MarketMatcher

        matcher = MarketMatcher(self.config)

        # Find the source market
        source_market = await self._find_market(market_id, platform)
        if not source_market:
            logger.warning(f"Market not found: {market_id}")
            return []

        # Get all markets from other platforms
        all_markets = await self.get_all_markets()

        # Find similar markets
        similar = matcher.find_similar(
            source_market,
            all_markets,
            min_similarity=min_similarity
        )

        return similar

    async def _find_market(
        self,
        market_id: str,
        platform: Optional[str] = None
    ) -> Optional[UnifiedMarket]:
        """Find a market by ID."""
        # If platform specified, search only that platform
        if platform:
            markets = self._cache.get(platform) or await self.get_markets(platform)
            for m in markets:
                if m.market_id == market_id:
                    return m
            return None

        # Search all cached markets
        for markets in self._cache.values():
            for m in markets:
                if m.market_id == market_id:
                    return m

        # If not in cache, fetch all and search
        all_markets = await self.get_all_markets()
        for m in all_markets:
            if m.market_id == market_id:
                return m

        return None

    # =========================================================================
    # Layer 5: Arbitrage Detection
    # =========================================================================

    async def get_arbitrage_opportunities(
        self,
        min_profit: float = 0.5,
        min_similarity: float = 75.0
    ) -> List[ArbitrageOpportunity]:
        """
        Detect cross-platform arbitrage opportunities.

        Finds markets on different platforms representing the same event
        with price differences that could yield profit.

        Args:
            min_profit: Minimum profit percentage to report.
            min_similarity: Minimum similarity score for matching.

        Returns:
            List of ArbitrageOpportunity sorted by profit.
        """
        from polypoll_sdk.services.arbitrage import ArbitrageDetector

        detector = ArbitrageDetector(self.config)

        # Get all markets
        all_markets = await self.get_all_markets()

        # Detect arbitrage
        opportunities = detector.detect(
            all_markets,
            min_profit=min_profit,
            min_similarity=min_similarity
        )

        return opportunities

    # =========================================================================
    # Layer 6: Market Grouping (Cross-Platform Event Identification)
    # =========================================================================

    async def get_grouped_markets(
        self,
        min_similarity: float = 80.0,
        limit_per_platform: int = 100
    ) -> Dict[str, List[UnifiedMarket]]:
        """
        Get all markets grouped by event (cross-platform).

        Markets representing the same event across different platforms
        will share the same group_id.

        Args:
            min_similarity: Minimum similarity threshold (0-100) for grouping.
                           Default is 80% as per deduplication requirements.
            limit_per_platform: Maximum markets to fetch per platform.

        Returns:
            Dictionary mapping group_id to list of markets.

        Example:
            ```python
            groups = await sdk.get_grouped_markets()
            for group_id, markets in groups.items():
                print(f"Group {group_id}: {len(markets)} markets")
                for m in markets:
                    print(f"  - [{m.platform}] {m.title} ({m.yes_price:.0%})")
            ```
        """
        from polypoll_sdk.services.grouping import MarketGrouper

        # Fetch all markets
        all_markets = await self.get_all_markets(limit_per_platform=limit_per_platform)

        # Group markets
        grouper = MarketGrouper(self.config, min_similarity=min_similarity)
        grouper.assign_group_ids(all_markets)

        # Store grouper for later use
        self._grouper = grouper

        return grouper.get_groups()

    async def get_markets_by_group(
        self,
        group_id: str
    ) -> List[UnifiedMarket]:
        """
        Get all markets for a specific group_id.

        Args:
            group_id: The group identifier (e.g., "politics_2024_trump_election_a3f2c1")

        Returns:
            List of markets in that group.
        """
        if hasattr(self, '_grouper') and self._grouper:
            return self._grouper.get_group(group_id)

        # If no grouper exists, need to fetch and group first
        groups = await self.get_grouped_markets()
        return groups.get(group_id, [])

    def get_grouping_stats(self) -> Dict[str, any]:
        """
        Get statistics about the current market grouping.

        Returns:
            Dictionary with grouping statistics.
        """
        if hasattr(self, '_grouper') and self._grouper:
            return self._grouper.get_stats()
        return {
            "total_groups": 0,
            "total_markets": 0,
            "cross_platform_groups": 0,
            "single_market_groups": 0,
            "avg_markets_per_group": 0.0
        }

    # =========================================================================
    # Properties
    # =========================================================================

    @property
    def has_ai_capabilities(self) -> bool:
        """Check if AI features are available."""
        return self.config.has_ai_capabilities

    @property
    def supported_platforms(self) -> List[str]:
        """List of supported platforms."""
        return Platform.ALL
