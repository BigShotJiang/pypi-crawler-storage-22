"""
PolyPoll MCP Server

Model Context Protocol server for prediction market data.
Allows AI agents (Claude, etc.) to query prediction markets.

Usage:
    polypoll-mcp

Configure in Claude Desktop:
    {
        "mcpServers": {
            "polypoll": {
                "command": "polypoll-mcp"
            }
        }
    }
"""

import asyncio
import json
import logging
from typing import Any

try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import Tool, TextContent
    MCP_AVAILABLE = True
except ImportError:
    MCP_AVAILABLE = False

from polypoll_sdk import PolyPollSDK, Platform

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def market_to_dict(market) -> dict:
    """Convert UnifiedMarket to dict."""
    return {
        "platform": market.platform,
        "market_id": market.market_id,
        "title": market.title,
        "url": market.url,
        "yes_price": market.yes_price,
        "no_price": market.no_price,
        "volume": market.volume,
        "status": market.status.value if market.status else None,
        "category": market.category,
        "group_id": market.group_id,
    }


if MCP_AVAILABLE:
    # Create MCP server
    server = Server("polypoll")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        """List available tools."""
        return [
            Tool(
                name="get_markets",
                description="Get prediction markets from specified platform(s). Returns market data including prices, volumes, and metadata.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "platform": {
                            "type": "string",
                            "description": f"Platform to fetch from. Options: {', '.join(Platform.ALL)}. Leave empty for all platforms.",
                            "enum": Platform.ALL,
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Maximum number of markets to return (default: 20)",
                            "default": 20,
                        },
                    },
                },
            ),
            Tool(
                name="search_markets",
                description="Search for prediction markets by keyword across all platforms. Uses fuzzy matching.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query (e.g., 'trump', 'bitcoin', 'election')",
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Maximum results (default: 10)",
                            "default": 10,
                        },
                    },
                    "required": ["query"],
                },
            ),
            Tool(
                name="get_arbitrage",
                description="Find arbitrage opportunities across platforms. Detects when the same event has different prices on different platforms.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "min_profit": {
                            "type": "number",
                            "description": "Minimum profit percentage to report (default: 0.5)",
                            "default": 0.5,
                        },
                        "min_similarity": {
                            "type": "number",
                            "description": "Minimum similarity score for matching (default: 75)",
                            "default": 75.0,
                        },
                    },
                },
            ),
            Tool(
                name="get_groups",
                description="Get markets grouped by event. Markets on different platforms representing the same event are grouped together.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "min_similarity": {
                            "type": "number",
                            "description": "Minimum similarity for grouping (default: 80)",
                            "default": 80.0,
                        },
                    },
                },
            ),
            Tool(
                name="get_similar_markets",
                description="Find markets similar to a given market across all platforms.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "market_id": {
                            "type": "string",
                            "description": "Market ID to find similar markets for",
                        },
                        "platform": {
                            "type": "string",
                            "description": "Platform of the source market",
                            "enum": Platform.ALL,
                        },
                        "min_similarity": {
                            "type": "number",
                            "description": "Minimum similarity score (default: 65)",
                            "default": 65.0,
                        },
                    },
                    "required": ["market_id"],
                },
            ),
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        """Handle tool calls."""
        sdk = PolyPollSDK()

        try:
            if name == "get_markets":
                platform = arguments.get("platform")
                limit = arguments.get("limit", 20)

                if platform:
                    markets = await sdk.get_markets(platform, limit=limit)
                else:
                    markets = await sdk.get_all_markets(limit_per_platform=limit)

                result = {
                    "markets": [market_to_dict(m) for m in markets],
                    "count": len(markets),
                }

            elif name == "search_markets":
                query = arguments["query"]
                limit = arguments.get("limit", 10)

                markets = await sdk.search_markets(query, limit=limit)

                result = {
                    "query": query,
                    "markets": [market_to_dict(m) for m in markets],
                    "count": len(markets),
                }

            elif name == "get_arbitrage":
                min_profit = arguments.get("min_profit", 0.5)
                min_similarity = arguments.get("min_similarity", 75.0)

                opportunities = await sdk.get_arbitrage_opportunities(
                    min_profit=min_profit,
                    min_similarity=min_similarity
                )

                result = {
                    "arbitrage_opportunities": [
                        {
                            "market1": {
                                "platform": opp.market1.platform,
                                "title": opp.market1.title,
                                "yes_price": opp.market1.yes_price,
                                "url": opp.market1.url,
                            },
                            "market2": {
                                "platform": opp.market2.platform,
                                "title": opp.market2.title,
                                "yes_price": opp.market2.yes_price,
                                "url": opp.market2.url,
                            },
                            "price_diff": opp.price_diff,
                            "potential_profit": opp.potential_profit,
                            "similarity_score": opp.similarity_score,
                        }
                        for opp in opportunities[:20]
                    ],
                    "count": len(opportunities),
                }

            elif name == "get_groups":
                min_similarity = arguments.get("min_similarity", 80.0)

                groups = await sdk.get_grouped_markets(min_similarity=min_similarity)

                # Filter to cross-platform groups
                cross_platform = {}
                for group_id, markets in groups.items():
                    platforms = list(set(m.platform for m in markets))
                    if len(platforms) > 1:
                        cross_platform[group_id] = {
                            "markets": [market_to_dict(m) for m in markets],
                            "platforms": platforms,
                            "count": len(markets),
                        }

                result = {
                    "groups": cross_platform,
                    "total_groups": len(groups),
                    "cross_platform_groups": len(cross_platform),
                }

            elif name == "get_similar_markets":
                market_id = arguments["market_id"]
                platform = arguments.get("platform")
                min_similarity = arguments.get("min_similarity", 65.0)

                similar = await sdk.get_similar_markets(
                    market_id=market_id,
                    platform=platform,
                    min_similarity=min_similarity
                )

                result = {
                    "source_market_id": market_id,
                    "similar_markets": [
                        {
                            "market": market_to_dict(sm.market),
                            "similarity_score": sm.similarity_score,
                            "price_diff": sm.price_diff,
                        }
                        for sm in similar[:10]
                    ],
                    "count": len(similar),
                }

            else:
                result = {"error": f"Unknown tool: {name}"}

            return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]

        except Exception as e:
            logger.error(f"Error in tool {name}: {e}")
            return [TextContent(type="text", text=json.dumps({"error": str(e)}))]


def main():
    """Run the MCP server."""
    if not MCP_AVAILABLE:
        print("Error: MCP package not installed.")
        print("Install with: pip install polypoll-sdk[mcp]")
        return

    async def run():
        async with stdio_server() as (read_stream, write_stream):
            await server.run(read_stream, write_stream, server.create_initialization_options())

    asyncio.run(run())


if __name__ == "__main__":
    main()
