"""
Market Grouping Service

Provides cross-platform market grouping using fuzzy matching and Union-Find algorithm.
Markets representing the same event across different platforms are assigned the same group_id.
"""

import hashlib
import json
import logging
import re
from datetime import datetime
from typing import Dict, List, Optional, Set, Tuple

from rapidfuzz import fuzz

from polypoll_sdk.config import SDKConfig
from polypoll_sdk.models.market import UnifiedMarket

logger = logging.getLogger(__name__)


class UnionFind:
    """
    Union-Find (Disjoint Set) data structure for efficient grouping.

    Used to merge similar markets into groups efficiently.
    """

    def __init__(self, n: int):
        self.parent = list(range(n))
        self.rank = [0] * n

    def find(self, x: int) -> int:
        """Find the root of element x with path compression."""
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, x: int, y: int) -> bool:
        """
        Unite the sets containing x and y.

        Returns True if they were in different sets (merged), False if already same set.
        """
        root_x = self.find(x)
        root_y = self.find(y)

        if root_x == root_y:
            return False

        # Union by rank
        if self.rank[root_x] < self.rank[root_y]:
            self.parent[root_x] = root_y
        elif self.rank[root_x] > self.rank[root_y]:
            self.parent[root_y] = root_x
        else:
            self.parent[root_y] = root_x
            self.rank[root_x] += 1

        return True


class MarketGrouper:
    """
    Service for grouping similar markets across platforms.

    Uses fuzzy string matching to identify markets representing the same event,
    then assigns them a unified group_id.

    Example:
        ```python
        grouper = MarketGrouper(min_similarity=80.0)

        # Assign group IDs to markets
        grouped_markets = grouper.assign_group_ids(all_markets)

        # Get all groups
        groups = grouper.get_groups()

        # Get markets for a specific group
        trump_markets = grouper.get_group("politics_2024_trump_election_a3f2c1")
        ```
    """

    def __init__(
        self,
        config: Optional[SDKConfig] = None,
        min_similarity: float = 80.0
    ):
        """
        Initialize the grouper.

        Args:
            config: SDK configuration (optional).
            min_similarity: Minimum similarity threshold (0-100) for grouping.
                           Default is 80% as per meeting requirements.
        """
        self.config = config
        self.min_similarity = min_similarity
        self._groups: Dict[str, List[UnifiedMarket]] = {}
        self._market_to_group: Dict[str, str] = {}  # market_id -> group_id

    def assign_group_ids(
        self,
        markets: List[UnifiedMarket]
    ) -> List[UnifiedMarket]:
        """
        Assign group_id to all markets based on fuzzy similarity.

        Markets with >= min_similarity are considered the same event
        and will share the same group_id.

        Args:
            markets: List of markets to group.

        Returns:
            List of markets with group_id assigned.
        """
        if not markets:
            return []

        n = len(markets)
        logger.info(f"Grouping {n} markets with {self.min_similarity}% similarity threshold")

        # Step 1: Find all similar pairs using fuzzy matching
        uf = UnionFind(n)
        similar_pairs = 0

        for i in range(n):
            for j in range(i + 1, n):
                # Skip if same platform (we want cross-platform grouping)
                if markets[i].platform == markets[j].platform:
                    continue

                similarity = self._calculate_similarity(
                    markets[i].title,
                    markets[j].title
                )

                if similarity >= self.min_similarity:
                    uf.union(i, j)
                    similar_pairs += 1

        logger.info(f"Found {similar_pairs} similar market pairs")

        # Step 2: Group markets by their Union-Find root
        root_to_indices: Dict[int, List[int]] = {}
        for i in range(n):
            root = uf.find(i)
            if root not in root_to_indices:
                root_to_indices[root] = []
            root_to_indices[root].append(i)

        # Step 3: Generate group_id for each group and assign to markets
        self._groups.clear()
        self._market_to_group.clear()

        for root, indices in root_to_indices.items():
            group_markets = [markets[i] for i in indices]

            # Use the first market (by title length, prefer longer/more descriptive) as representative
            representative = max(group_markets, key=lambda m: len(m.title))
            group_id = self._generate_group_id(representative, group_markets)

            # Assign group_id to all markets in this group
            for i in indices:
                markets[i].group_id = group_id
                self._market_to_group[f"{markets[i].platform}_{markets[i].market_id}"] = group_id

            self._groups[group_id] = group_markets

        logger.info(f"Created {len(self._groups)} groups from {n} markets")
        return markets

    def _calculate_similarity(self, text1: str, text2: str) -> float:
        """
        Calculate weighted fuzzy similarity between two strings.

        Uses entity-aware matching from the unified similarity module:
        - Base score: 50% ratio + 30% token_sort + 20% partial
        - Entity penalty: reduces score if key entities don't overlap

        Args:
            text1: First text.
            text2: Second text.

        Returns:
            Similarity score (0-100).
        """
        if not text1 or not text2:
            return 0.0

        from polypoll_sdk.utils.similarity import calculate_similarity

        # Use the unified entity-aware similarity calculation
        _, adjusted_score = calculate_similarity(text1, text2)
        return adjusted_score

    def _generate_group_id(
        self,
        representative: UnifiedMarket,
        group_markets: List[UnifiedMarket]
    ) -> str:
        """
        Generate a unique group_id for a group of markets.

        Format: {category}_{year}_{topic_slug}_{hash[:6]}
        Example: politics_2024_trump_election_a3f2c1

        Args:
            representative: The representative market for this group.
            group_markets: All markets in this group.

        Returns:
            Generated group_id string.
        """
        # Extract category (default to "general" if not available)
        category = representative.category or "general"
        category = self._slugify(category)

        # Extract year from close_time or current year
        year = datetime.now().year
        if representative.close_time:
            year = representative.close_time.year

        # Generate topic slug from title
        topic_slug = self._extract_topic_slug(representative.title)

        # Generate hash from all market IDs in the group for uniqueness
        hash_input = "_".join(sorted([
            f"{m.platform}_{m.market_id}" for m in group_markets
        ]))
        hash_suffix = hashlib.md5(hash_input.encode()).hexdigest()[:6]

        return f"{category}_{year}_{topic_slug}_{hash_suffix}"

    def _extract_topic_slug(self, title: str, max_words: int = 3) -> str:
        """
        Extract a slug from the market title.

        Args:
            title: Market title.
            max_words: Maximum number of words to include.

        Returns:
            Slugified topic string.
        """
        # Remove common question words and punctuation
        stop_words = {
            'will', 'the', 'a', 'an', 'be', 'to', 'in', 'on', 'at', 'by',
            'is', 'are', 'was', 'were', 'has', 'have', 'had', 'do', 'does',
            'did', 'can', 'could', 'would', 'should', 'may', 'might',
            'this', 'that', 'these', 'those', 'what', 'which', 'who',
            'before', 'after', 'during', 'between', 'into', 'through',
            'for', 'with', 'about', 'against', 'over', 'under', 'again'
        }

        # Clean and split
        words = re.findall(r'\b[a-zA-Z0-9]+\b', title.lower())

        # Filter stop words and take first N meaningful words
        meaningful = [w for w in words if w not in stop_words and len(w) > 2]
        topic_words = meaningful[:max_words]

        if not topic_words:
            # Fallback: use first few words regardless
            topic_words = words[:max_words] if words else ["market"]

        return "_".join(topic_words)

    def _slugify(self, text: str) -> str:
        """Convert text to a URL-safe slug."""
        # Convert to lowercase, replace spaces with underscores
        slug = text.lower().strip()
        slug = re.sub(r'[^a-z0-9]+', '_', slug)
        slug = slug.strip('_')
        return slug or "general"

    def get_groups(self) -> Dict[str, List[UnifiedMarket]]:
        """
        Get all market groups.

        Returns:
            Dictionary mapping group_id to list of markets.
        """
        return self._groups.copy()

    def get_group(self, group_id: str) -> List[UnifiedMarket]:
        """
        Get markets for a specific group.

        Args:
            group_id: The group identifier.

        Returns:
            List of markets in the group, or empty list if not found.
        """
        return self._groups.get(group_id, [])

    def get_group_for_market(self, platform: str, market_id: str) -> Optional[str]:
        """
        Get the group_id for a specific market.

        Args:
            platform: Platform name.
            market_id: Market ID on that platform.

        Returns:
            group_id if found, None otherwise.
        """
        key = f"{platform}_{market_id}"
        return self._market_to_group.get(key)

    def get_cross_platform_markets(self, group_id: str) -> Dict[str, UnifiedMarket]:
        """
        Get markets from a group organized by platform.

        Args:
            group_id: The group identifier.

        Returns:
            Dictionary mapping platform name to market.
        """
        markets = self.get_group(group_id)
        return {m.platform: m for m in markets}

    def save_groups(self, path: str) -> None:
        """
        Save groups to a JSON file for persistence.

        Args:
            path: File path to save to.
        """
        data = {
            "min_similarity": self.min_similarity,
            "groups": {
                group_id: [m.to_dict() for m in markets]
                for group_id, markets in self._groups.items()
            },
            "market_to_group": self._market_to_group,
            "created_at": datetime.now().isoformat()
        }

        with open(path, 'w') as f:
            json.dump(data, f, indent=2, default=str)

        logger.info(f"Saved {len(self._groups)} groups to {path}")

    def load_groups(self, path: str) -> None:
        """
        Load groups from a JSON file.

        Note: This only loads the group_id mappings, not full market objects.
        Use this to restore group assignments for markets fetched later.

        Args:
            path: File path to load from.
        """
        with open(path, 'r') as f:
            data = json.load(f)

        self.min_similarity = data.get("min_similarity", self.min_similarity)
        self._market_to_group = data.get("market_to_group", {})

        logger.info(f"Loaded group mappings from {path}")

    def get_stats(self) -> Dict[str, any]:
        """
        Get grouping statistics.

        Returns:
            Dictionary with stats about the current grouping.
        """
        if not self._groups:
            return {
                "total_groups": 0,
                "total_markets": 0,
                "cross_platform_groups": 0,
                "single_market_groups": 0,
                "avg_markets_per_group": 0.0
            }

        total_markets = sum(len(markets) for markets in self._groups.values())
        cross_platform = sum(
            1 for markets in self._groups.values()
            if len(set(m.platform for m in markets)) > 1
        )
        single_market = sum(
            1 for markets in self._groups.values()
            if len(markets) == 1
        )

        return {
            "total_groups": len(self._groups),
            "total_markets": total_markets,
            "cross_platform_groups": cross_platform,
            "single_market_groups": single_market,
            "avg_markets_per_group": total_markets / len(self._groups)
        }
