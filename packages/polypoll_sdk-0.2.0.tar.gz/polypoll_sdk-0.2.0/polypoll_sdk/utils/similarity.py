"""
Similarity Calculation Utilities

Provides robust fuzzy matching with entity-aware scoring to avoid false positives.
"""

import re
from typing import Set, Tuple

from rapidfuzz import fuzz


# Common stop words to ignore in entity detection
STOP_WORDS = {
    'will', 'the', 'a', 'an', 'be', 'to', 'in', 'on', 'at', 'by', 'for', 'with',
    'is', 'are', 'was', 'were', 'has', 'have', 'had', 'do', 'does', 'did',
    'can', 'could', 'would', 'should', 'may', 'might', 'must',
    'this', 'that', 'these', 'those', 'what', 'which', 'who', 'whom',
    'before', 'after', 'during', 'between', 'into', 'through', 'from',
    'about', 'against', 'over', 'under', 'again', 'and', 'or', 'but', 'if',
    'us', 'presidential', 'election', 'win', 'wins', 'winning', 'winner',
    'market', 'price', 'yes', 'no', 'any', 'end', 'before', 'after'
}


def extract_key_entities(text: str) -> Set[str]:
    """
    Extract key entity words from text (names, organizations, numbers).

    These are the "core" words that distinguish one market from another.

    Args:
        text: Input text

    Returns:
        Set of key entity words (lowercase)
    """
    words = set(re.findall(r'\b[a-zA-Z0-9]+\b', text.lower()))

    # Remove stop words
    entities = words - STOP_WORDS

    # Also extract capitalized words from original text (likely proper nouns)
    capitalized = set(re.findall(r'\b[A-Z][a-z]+\b', text))
    for word in capitalized:
        entities.add(word.lower())

    # Extract numbers (years, amounts, etc.)
    numbers = set(re.findall(r'\b\d+\b', text))
    entities.update(numbers)

    return entities


def calculate_similarity(
    text1: str,
    text2: str,
    short_query_threshold: int = 3
) -> Tuple[float, float]:
    """
    Calculate similarity between two texts with entity-aware scoring.

    Returns both raw score and entity-adjusted score.

    Algorithm:
    1. Base score: 50% ratio + 30% token_sort + 20% partial
    2. For short queries (≤3 chars): disable partial_ratio to avoid false matches
    3. Entity penalty: if key entities don't overlap, reduce score by 50%

    Args:
        text1: First text
        text2: Second text
        short_query_threshold: Disable partial_ratio for queries shorter than this

    Returns:
        Tuple of (raw_score, entity_adjusted_score)
    """
    if not text1 or not text2:
        return 0.0, 0.0

    text1_lower = text1.lower().strip()
    text2_lower = text2.lower().strip()

    # Calculate base fuzzy scores
    ratio = fuzz.ratio(text1_lower, text2_lower)
    token_sort = fuzz.token_sort_ratio(text1_lower, text2_lower)

    # For short queries, disable partial_ratio (causes false positives)
    min_len = min(len(text1_lower), len(text2_lower))
    if min_len <= short_query_threshold:
        # Short query: use only ratio and token_sort
        raw_score = (ratio * 0.6) + (token_sort * 0.4)
    else:
        # Normal query: include partial_ratio
        partial = fuzz.partial_ratio(text1_lower, text2_lower)
        raw_score = (ratio * 0.5) + (token_sort * 0.3) + (partial * 0.2)

    # Extract key entities
    entities1 = extract_key_entities(text1)
    entities2 = extract_key_entities(text2)

    # Separate name entities (non-numeric, likely proper nouns) from other entities
    name_entities1 = {e for e in entities1 if not e.isdigit()}
    name_entities2 = {e for e in entities2 if not e.isdigit()}

    # Calculate entity overlap with focus on name entities
    # Use MAX denominator to catch cases where one set is a subset
    # e.g., {"katie", "britt"} vs {"republican"} should have LOW overlap
    if name_entities1 and name_entities2:
        common_names = name_entities1 & name_entities2
        max_names = max(len(name_entities1), len(name_entities2))
        name_overlap = len(common_names) / max_names if max_names > 0 else 0

        # If name entities don't overlap well (<40%), apply penalty
        # This catches "Katie Britt" vs "Republican nomination" (overlap=0/2=0%)
        if name_overlap < 0.4:
            entity_adjusted_score = raw_score * 0.5
        else:
            entity_adjusted_score = raw_score
    elif entities1 and entities2:
        # Fallback: use all entities if no name entities
        common_entities = entities1 & entities2
        max_entities = max(len(entities1), len(entities2))
        entity_overlap = len(common_entities) / max_entities if max_entities > 0 else 0

        if entity_overlap < 0.3:
            entity_adjusted_score = raw_score * 0.5
        else:
            entity_adjusted_score = raw_score
    else:
        entity_adjusted_score = raw_score

    return raw_score, entity_adjusted_score


def calculate_search_score(query: str, title: str, min_score: float = 40.0) -> float:
    """
    Calculate search relevance score optimized for keyword search.

    Uses entity-adjusted scoring to avoid false positives like:
    - "AI" matching "Daily Coinflip"
    - "Fed" matching "GOOG ATH in Feb"

    Args:
        query: Search query
        title: Market title
        min_score: Minimum score threshold

    Returns:
        Relevance score (0-100), or 0 if below threshold
    """
    _, adjusted_score = calculate_similarity(query, title)
    return adjusted_score if adjusted_score >= min_score else 0


def calculate_match_score(text1: str, text2: str, min_score: float = 75.0) -> float:
    """
    Calculate cross-platform matching score optimized to avoid false positives.

    Uses entity-adjusted scoring to avoid matches like:
    - "Tim Walz win 2028" matching "party win 2028"

    Args:
        text1: First market title
        text2: Second market title
        min_score: Minimum score threshold

    Returns:
        Match score (0-100), or 0 if below threshold
    """
    _, adjusted_score = calculate_similarity(text1, text2)
    return adjusted_score if adjusted_score >= min_score else 0
