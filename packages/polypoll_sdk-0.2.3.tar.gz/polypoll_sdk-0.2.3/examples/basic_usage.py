"""
Basic Usage Example

Demonstrates core SDK functionality:
- Fetching markets from all platforms
- Searching markets
- Finding similar markets
- Detecting arbitrage
"""

import asyncio
import sys
sys.path.insert(0, '..')

from polypoll_sdk import PolyPollSDK


async def main():
    print("=" * 60)
    print("PolyPoll SDK - Basic Usage Example")
    print("=" * 60)

    # Initialize SDK (no API keys needed for core features)
    sdk = PolyPollSDK()
    print(f"\nSupported platforms: {sdk.supported_platforms}")
    print(f"AI capabilities available: {sdk.has_ai_capabilities}")

    # 1. Get all markets
    print("\n" + "=" * 60)
    print("1. FETCHING ALL MARKETS")
    print("=" * 60)

    markets = await sdk.get_all_markets(limit_per_platform=10)
    print(f"\nTotal markets: {len(markets)}")

    # Count by platform
    by_platform = {}
    for m in markets:
        by_platform[m.platform] = by_platform.get(m.platform, 0) + 1

    for platform, count in by_platform.items():
        print(f"  - {platform}: {count} markets")

    # 2. Show sample markets
    print("\n" + "=" * 60)
    print("2. SAMPLE MARKETS")
    print("=" * 60)

    for market in markets[:5]:
        print(f"\n[{market.platform}] {market.title[:60]}...")
        print(f"  YES: {market.yes_price:.1%} | NO: {market.no_price:.1%}")
        print(f"  Volume: ${market.volume:,.0f}")
        print(f"  URL: {market.url}")

    # 3. Search markets
    print("\n" + "=" * 60)
    print("3. SEARCHING MARKETS")
    print("=" * 60)

    search_results = await sdk.search_markets("bitcoin", limit=5)
    print(f"\nSearch 'bitcoin': {len(search_results)} results")

    for market in search_results[:3]:
        print(f"  [{market.platform}] {market.title[:50]}...")

    # 4. Find similar markets (if we have enough data)
    print("\n" + "=" * 60)
    print("4. SIMILAR MARKETS")
    print("=" * 60)

    if markets:
        source = markets[0]
        print(f"\nFinding markets similar to:")
        print(f"  [{source.platform}] {source.title[:60]}...")

        similar = await sdk.get_similar_markets(
            market_id=source.market_id,
            platform=source.platform,
            min_similarity=50
        )

        print(f"\nFound {len(similar)} similar markets:")
        for match in similar[:5]:
            print(f"  {match.similarity_score:.0f}% [{match.market.platform}] "
                  f"{match.market.title[:40]}...")
            if match.price_diff:
                print(f"       Price diff: {match.price_diff:.1%}")

    # 5. Arbitrage opportunities
    print("\n" + "=" * 60)
    print("5. ARBITRAGE OPPORTUNITIES")
    print("=" * 60)

    arbitrage = await sdk.get_arbitrage_opportunities(
        min_profit=0.1,
        min_similarity=70
    )

    print(f"\nFound {len(arbitrage)} arbitrage opportunities:")
    for opp in arbitrage[:5]:
        print(f"\n  {opp.profit_pct:.1f}% profit potential")
        print(f"  {opp.strategy}")
        print(f"  Similarity: {opp.similarity_score:.0f}%")

    print("\n" + "=" * 60)
    print("DONE!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
