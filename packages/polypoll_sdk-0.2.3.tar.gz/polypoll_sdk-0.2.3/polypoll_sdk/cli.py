"""
PolyPoll SDK CLI

Command-line interface for prediction market data aggregation.
Designed for both humans and AI agents.

Usage:
    polypoll markets [--platform NAME] [--limit N]
    polypoll search QUERY [--limit N]
    polypoll arbitrage [--min-profit N]
    polypoll groups [--min-similarity N]
    polypoll market MARKET_ID [--platform NAME]
"""

import asyncio
import json
import sys
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from polypoll_sdk import PolyPollSDK, Platform, __version__

app = typer.Typer(
    name="polypoll",
    help="Unified CLI for prediction market data across 5 platforms",
    add_completion=False,
)
console = Console()


def run_async(coro):
    """Run async function in sync context."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        # No running loop, create new one
        return asyncio.run(coro)
    else:
        # Already in async context (shouldn't happen in CLI)
        return loop.run_until_complete(coro)


def output_json(data, pretty: bool = False):
    """Output data as JSON (agent-friendly)."""
    if pretty:
        print(json.dumps(data, indent=2, default=str))
    else:
        print(json.dumps(data, default=str))


def market_to_dict(market) -> dict:
    """Convert UnifiedMarket to dict for JSON output."""
    return {
        "platform": market.platform,
        "market_id": market.market_id,
        "title": market.title,
        "url": market.url,
        "yes_price": market.yes_price,
        "no_price": market.no_price,
        "volume": market.volume,
        "status": market.status.value if market.status else None,
        "category": market.category,
        "group_id": market.group_id,
    }


@app.command()
def version():
    """Show version information."""
    print(f"polypoll-sdk v{__version__}")


@app.command()
def platforms():
    """List all supported platforms."""
    output_json({
        "platforms": Platform.ALL,
        "count": len(Platform.ALL)
    }, pretty=True)


@app.command()
def markets(
    platform: Optional[str] = typer.Option(None, "--platform", "-p", help="Filter by platform"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
    json_output: bool = typer.Option(True, "--json/--table", help="Output format"),
):
    """
    Get markets from prediction platforms.

    Examples:
        polypoll markets
        polypoll markets --platform polymarket --limit 5
        polypoll markets -p kalshi -l 20
    """
    async def _fetch():
        sdk = PolyPollSDK()
        if platform:
            return await sdk.get_markets(platform, limit=limit)
        else:
            return await sdk.get_all_markets(limit_per_platform=limit)

    try:
        results = run_async(_fetch())

        if json_output:
            output_json({
                "markets": [market_to_dict(m) for m in results],
                "count": len(results)
            }, pretty=True)
        else:
            table = Table(title="Markets")
            table.add_column("Platform", style="cyan")
            table.add_column("Title", style="white")
            table.add_column("Yes", style="green")
            table.add_column("Volume", style="yellow")

            for m in results[:limit]:
                table.add_row(
                    m.platform,
                    m.title[:50] + "..." if len(m.title) > 50 else m.title,
                    f"{m.yes_price:.1%}",
                    f"${m.volume:,.0f}" if m.volume else "N/A"
                )
            console.print(table)

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)


@app.command()
def search(
    query: str = typer.Argument(..., help="Search query"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
    platform: Optional[str] = typer.Option(None, "--platform", "-p", help="Filter by platform"),
    min_score: float = typer.Option(40.0, "--min-score", help="Minimum similarity score"),
):
    """
    Search markets by keyword across all platforms.

    Examples:
        polypoll search trump
        polypoll search "bitcoin price" --limit 5
        polypoll search election --platform polymarket
    """
    async def _search():
        sdk = PolyPollSDK()
        platforms_filter = [platform] if platform else None
        return await sdk.search_markets(query, platforms=platforms_filter, limit=limit, min_score=min_score)

    try:
        results = run_async(_search())
        output_json({
            "query": query,
            "markets": [market_to_dict(m) for m in results],
            "count": len(results)
        }, pretty=True)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)


@app.command()
def arbitrage(
    min_profit: float = typer.Option(0.5, "--min-profit", help="Minimum profit percentage"),
    min_similarity: float = typer.Option(75.0, "--min-similarity", help="Minimum similarity score"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
):
    """
    Find arbitrage opportunities across platforms.

    Detects price discrepancies for the same event on different platforms.

    Examples:
        polypoll arbitrage
        polypoll arbitrage --min-profit 1.0
        polypoll arbitrage --min-similarity 80
    """
    async def _arbitrage():
        sdk = PolyPollSDK()
        return await sdk.get_arbitrage_opportunities(
            min_profit=min_profit,
            min_similarity=min_similarity
        )

    try:
        results = run_async(_arbitrage())

        opportunities = []
        for opp in results[:limit]:
            opportunities.append({
                "market1": {
                    "platform": opp.market1.platform,
                    "title": opp.market1.title,
                    "yes_price": opp.market1.yes_price,
                    "url": opp.market1.url,
                },
                "market2": {
                    "platform": opp.market2.platform,
                    "title": opp.market2.title,
                    "yes_price": opp.market2.yes_price,
                    "url": opp.market2.url,
                },
                "profit_pct": opp.profit_pct,
                "expected_return": opp.expected_return,
                "similarity_score": opp.similarity_score,
            })

        output_json({
            "arbitrage_opportunities": opportunities,
            "count": len(opportunities)
        }, pretty=True)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)


@app.command()
def groups(
    min_similarity: float = typer.Option(80.0, "--min-similarity", help="Minimum similarity for grouping"),
    limit: int = typer.Option(100, "--limit", "-l", help="Markets per platform"),
):
    """
    Get markets grouped by event across platforms.

    Markets representing the same event on different platforms are grouped together.

    Examples:
        polypoll groups
        polypoll groups --min-similarity 85
    """
    async def _groups():
        sdk = PolyPollSDK()
        return await sdk.get_grouped_markets(
            min_similarity=min_similarity,
            limit_per_platform=limit
        )

    try:
        results = run_async(_groups())

        groups_output = {}
        for group_id, markets in results.items():
            groups_output[group_id] = {
                "markets": [market_to_dict(m) for m in markets],
                "platforms": list(set(m.platform for m in markets)),
                "count": len(markets)
            }

        # Filter to only cross-platform groups
        cross_platform = {
            k: v for k, v in groups_output.items()
            if len(v["platforms"]) > 1
        }

        output_json({
            "groups": cross_platform,
            "total_groups": len(groups_output),
            "cross_platform_groups": len(cross_platform)
        }, pretty=True)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)


@app.command()
def market(
    market_id: str = typer.Argument(..., help="Market ID"),
    platform: Optional[str] = typer.Option(None, "--platform", "-p", help="Platform name"),
):
    """
    Get details for a specific market.

    Examples:
        polypoll market abc123 --platform polymarket
        polypoll market TRUMP-2024 -p kalshi
    """
    async def _get_market():
        sdk = PolyPollSDK()
        # Search across platforms
        if platform:
            markets = await sdk.get_markets(platform)
        else:
            markets = await sdk.get_all_markets()

        for m in markets:
            if m.market_id == market_id:
                return m
        return None

    try:
        result = run_async(_get_market())

        if result:
            output_json(market_to_dict(result), pretty=True)
        else:
            console.print(f"[yellow]Market not found: {market_id}[/yellow]")
            sys.exit(1)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)


@app.command()
def similar(
    market_id: str = typer.Argument(..., help="Market ID to find similar markets for"),
    platform: Optional[str] = typer.Option(None, "--platform", "-p", help="Platform of the market"),
    min_similarity: float = typer.Option(65.0, "--min-similarity", help="Minimum similarity score"),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum results"),
):
    """
    Find similar markets across platforms.

    Examples:
        polypoll similar abc123 --platform polymarket
        polypoll similar TRUMP-2024 -p kalshi --min-similarity 70
    """
    async def _similar():
        sdk = PolyPollSDK()
        return await sdk.get_similar_markets(
            market_id=market_id,
            platform=platform,
            min_similarity=min_similarity
        )

    try:
        results = run_async(_similar())

        similar_markets = []
        for sm in results[:limit]:
            similar_markets.append({
                "market": market_to_dict(sm.market),
                "similarity_score": sm.similarity_score,
                "price_diff": sm.price_diff,
            })

        output_json({
            "source_market_id": market_id,
            "similar_markets": similar_markets,
            "count": len(similar_markets)
        }, pretty=True)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)


def main():
    """Entry point for the CLI."""
    app()


if __name__ == "__main__":
    main()
