"""
PolyPoll SDK Configuration

Manages API keys and settings for the SDK.
AI features are optional - the SDK works without API keys.
"""

import os
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SDKConfig:
    """
    Configuration for PolyPoll SDK.

    All API keys are optional. Core features (market fetching, matching, arbitrage)
    work without any API keys. AI features require EXA_API_KEY and GROQ_API_KEY.

    Attributes:
        exa_api_key: API key for Exa search (optional, for AI research)
        groq_api_key: API key for Groq LLM (optional, for AI odds)
        kalshi_api_key: API key for Kalshi (optional, increases rate limits)
        cache_ttl: Cache time-to-live in seconds (default: 3 hours)
        request_timeout: HTTP request timeout in seconds (default: 15)
    """

    exa_api_key: Optional[str] = field(default_factory=lambda: os.getenv("EXA_API_KEY"))
    groq_api_key: Optional[str] = field(default_factory=lambda: os.getenv("GROQ_API_KEY"))
    kalshi_api_key: Optional[str] = field(default_factory=lambda: os.getenv("KALSHI_API_KEY"))
    cache_ttl: int = field(default=10800)  # 3 hours
    request_timeout: int = field(default=15)

    @property
    def has_ai_capabilities(self) -> bool:
        """Check if AI features are available."""
        return bool(self.exa_api_key and self.groq_api_key)

    @property
    def has_exa(self) -> bool:
        """Check if Exa search is available."""
        return bool(self.exa_api_key)

    @property
    def has_groq(self) -> bool:
        """Check if Groq LLM is available."""
        return bool(self.groq_api_key)


# API Endpoints
class APIEndpoints:
    """API endpoints for prediction market platforms."""

    POLYMARKET = "https://gamma-api.polymarket.com"
    KALSHI = "https://api.elections.kalshi.com/trade-api/v2"
    MANIFOLD = "https://api.manifold.markets/v0"
    METACULUS = "https://www.metaculus.com/api2"
    PREDICTIT = "https://www.predictit.org/api"


# Platform identifiers
class Platform:
    """Platform identifiers."""

    POLYMARKET = "polymarket"
    KALSHI = "kalshi"
    MANIFOLD = "manifold"
    METACULUS = "metaculus"
    PREDICTIT = "predictit"
    POLYPOLL = "polypoll"

    ALL = [POLYMARKET, KALSHI, MANIFOLD, METACULUS, PREDICTIT]


# Default configuration instance
_default_config: Optional[SDKConfig] = None


def get_config() -> SDKConfig:
    """Get the default SDK configuration."""
    global _default_config
    if _default_config is None:
        _default_config = SDKConfig()
    return _default_config


def set_config(config: SDKConfig) -> None:
    """Set the default SDK configuration."""
    global _default_config
    _default_config = config
