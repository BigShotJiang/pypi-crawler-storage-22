"""
Unified Market Model

Provides a standardized data model for prediction markets across all platforms.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional
from enum import Enum


class MarketStatus(str, Enum):
    """Market status enum."""
    OPEN = "open"
    CLOSED = "closed"
    RESOLVED = "resolved"
    CANCELED = "canceled"


class MarketType(str, Enum):
    """Market type enum."""
    BINARY = "binary"
    MULTIPLE_CHOICE = "multiple_choice"
    SCALAR = "scalar"


@dataclass
class MarketOption:
    """Option in a multiple-choice market."""
    id: str
    name: str
    price: float  # 0-1
    volume: Optional[float] = None


@dataclass
class UnifiedMarket:
    """
    Unified market schema for all prediction market platforms.

    This dataclass provides a standardized view of markets from:
    - Polymarket (crypto prediction markets)
    - Kalshi (regulated prediction markets)
    - Manifold Markets (play-money forecasting)
    - Metaculus (expert forecasting)
    - PredictIt (US political markets)

    Core fields are always present. Optional fields may be None if not
    available from a particular platform.
    """

    # Core Identification (required)
    platform: str
    market_id: str
    title: str
    url: str

    # Pricing & Odds (required for binary markets)
    yes_price: float  # 0-1 probability
    no_price: float  # 0-1 probability

    # Cross-Platform Grouping (assigned by MarketGrouper)
    group_id: Optional[str] = None  # Unified event ID across platforms (e.g., "politics_2024_trump_election_a3f2c1")

    # Volume & Liquidity
    volume: float = 0.0
    volume_24h: float = 0.0
    liquidity: Optional[float] = None
    total_pool: float = 0.0

    # Status & Timing
    status: MarketStatus = MarketStatus.OPEN
    is_resolved: bool = False
    close_time: Optional[datetime] = None
    created_at: Optional[datetime] = None

    # Metadata
    slug: Optional[str] = None
    category: Optional[str] = None
    description: Optional[str] = None
    image_url: Optional[str] = None
    creator: Optional[str] = None
    tags: List[str] = field(default_factory=list)

    # Market Type
    market_type: MarketType = MarketType.BINARY
    options: List[MarketOption] = field(default_factory=list)

    # Trading Fields
    last_trade_price: Optional[float] = None
    best_bid: Optional[float] = None
    best_ask: Optional[float] = None
    min_bet: Optional[float] = None
    max_bet: Optional[float] = None
    trading_fee: Optional[float] = None

    # Platform-specific
    num_traders: Optional[int] = None
    forecaster_count: Optional[int] = None

    # Resolution
    resolution: Optional[Any] = None
    resolution_source: Optional[str] = None

    # Blockchain (for Polymarket)
    contract_address: Optional[str] = None
    condition_id: Optional[str] = None
    token_id: Optional[str] = None

    # Raw data for debugging
    _raw: Dict[str, Any] = field(default_factory=dict, repr=False)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "platform": self.platform,
            "market_id": self.market_id,
            "title": self.title,
            "url": self.url,
            "yes_price": self.yes_price,
            "no_price": self.no_price,
            "group_id": self.group_id,
            "volume": self.volume,
            "volume_24h": self.volume_24h,
            "liquidity": self.liquidity,
            "total_pool": self.total_pool,
            "status": self.status.value,
            "is_resolved": self.is_resolved,
            "close_time": self.close_time.isoformat() if self.close_time else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "slug": self.slug,
            "category": self.category,
            "description": self.description,
            "image_url": self.image_url,
            "creator": self.creator,
            "tags": self.tags,
            "market_type": self.market_type.value,
            "options": [{"id": o.id, "name": o.name, "price": o.price} for o in self.options],
            "last_trade_price": self.last_trade_price,
            "best_bid": self.best_bid,
            "best_ask": self.best_ask,
            "min_bet": self.min_bet,
            "max_bet": self.max_bet,
            "trading_fee": self.trading_fee,
            "num_traders": self.num_traders,
            "forecaster_count": self.forecaster_count,
            "resolution": self.resolution,
            "resolution_source": self.resolution_source,
            "contract_address": self.contract_address,
            "condition_id": self.condition_id,
            "token_id": self.token_id,
        }


@dataclass
class SimilarMarket:
    """A market similar to a query, with similarity score."""
    market: UnifiedMarket
    similarity_score: float  # 0-100
    price_diff: Optional[float] = None  # Difference in yes_price

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "market": self.market.to_dict(),
            "similarity_score": self.similarity_score,
            "price_diff": self.price_diff,
        }


@dataclass
class ArbitrageOpportunity:
    """Cross-platform arbitrage opportunity."""
    market1: UnifiedMarket
    market2: UnifiedMarket
    similarity_score: float
    profit_pct: float
    strategy: str  # e.g., "Buy YES on Polymarket, Buy NO on Kalshi"
    cost: float  # Total cost to execute
    expected_return: float

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "market1": self.market1.to_dict(),
            "market2": self.market2.to_dict(),
            "similarity_score": self.similarity_score,
            "profit_pct": self.profit_pct,
            "strategy": self.strategy,
            "cost": self.cost,
            "expected_return": self.expected_return,
        }
