"""
Base Provider

Abstract base class for all prediction market providers.
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
import aiohttp
import ssl
import certifi
import logging

from polypoll_sdk.models.market import UnifiedMarket
from polypoll_sdk.config import SDKConfig, get_config

logger = logging.getLogger(__name__)


class BaseProvider(ABC):
    """
    Abstract base class for prediction market data providers.

    Each platform (Polymarket, Kalshi, etc.) implements this interface
    to provide a consistent API for fetching and normalizing market data.
    """

    def __init__(self, config: Optional[SDKConfig] = None):
        """
        Initialize the provider.

        Args:
            config: SDK configuration. Uses default if not provided.
        """
        self.config = config or get_config()
        self._ssl_context = ssl.create_default_context(cafile=certifi.where())

    @property
    @abstractmethod
    def platform_name(self) -> str:
        """Return the platform identifier (e.g., 'polymarket', 'kalshi')."""
        pass

    @property
    @abstractmethod
    def api_base_url(self) -> str:
        """Return the base URL for the platform's API."""
        pass

    @abstractmethod
    async def fetch_markets(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Fetch raw market data from the platform.

        Args:
            limit: Maximum number of markets to fetch.

        Returns:
            List of raw market dictionaries from the platform API.
        """
        pass

    @abstractmethod
    def normalize(self, raw_market: Dict[str, Any]) -> UnifiedMarket:
        """
        Convert raw platform-specific market data to unified schema.

        Args:
            raw_market: Raw market data from the platform API.

        Returns:
            UnifiedMarket instance with standardized fields.
        """
        pass

    async def get_markets(self, limit: int = 100) -> List[UnifiedMarket]:
        """
        Fetch and normalize markets from the platform.

        Args:
            limit: Maximum number of markets to fetch.

        Returns:
            List of UnifiedMarket instances.
        """
        raw_markets = await self.fetch_markets(limit)
        markets = []

        for raw in raw_markets:
            try:
                market = self.normalize(raw)
                markets.append(market)
            except Exception as e:
                logger.warning(f"[{self.platform_name}] Failed to normalize market: {e}")
                continue

        logger.info(f"[{self.platform_name}] Fetched and normalized {len(markets)} markets")
        return markets

    async def search_markets(self, query: str, limit: int = 50) -> List[UnifiedMarket]:
        """
        Search markets by keyword.

        Default implementation fetches all markets and filters locally.
        Override this method if the platform has a search API.

        Args:
            query: Search query string.
            limit: Maximum number of results.

        Returns:
            List of matching UnifiedMarket instances.
        """
        all_markets = await self.get_markets(limit=1000)
        query_lower = query.lower()

        matching = [
            m for m in all_markets
            if query_lower in m.title.lower()
        ]

        return matching[:limit]

    def _create_connector(self) -> aiohttp.TCPConnector:
        """Create an aiohttp connector with SSL context."""
        return aiohttp.TCPConnector(ssl=self._ssl_context)

    def _get_timeout(self) -> aiohttp.ClientTimeout:
        """Get the request timeout from config."""
        return aiohttp.ClientTimeout(total=self.config.request_timeout)
