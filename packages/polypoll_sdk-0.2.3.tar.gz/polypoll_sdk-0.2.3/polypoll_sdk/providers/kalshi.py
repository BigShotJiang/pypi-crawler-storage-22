"""
Kalshi Provider

Fetches and normalizes market data from Kalshi's API.
Kalshi is a US-regulated prediction market using real USD.
"""

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

import aiohttp

from polypoll_sdk.config import APIEndpoints, Platform, SDKConfig
from polypoll_sdk.models.market import MarketStatus, MarketType, UnifiedMarket
from polypoll_sdk.providers.base import BaseProvider

logger = logging.getLogger(__name__)


class KalshiProvider(BaseProvider):
    """
    Provider for Kalshi prediction markets.

    Kalshi is a CFTC-regulated exchange for event contracts in the US.
    Prices are in cents (0-100), which we normalize to 0-1.
    """

    def __init__(self, config: Optional[SDKConfig] = None):
        super().__init__(config)
        self._api_key = self.config.kalshi_api_key

    @property
    def platform_name(self) -> str:
        return Platform.KALSHI

    @property
    def api_base_url(self) -> str:
        return APIEndpoints.KALSHI

    async def fetch_markets(self, limit: int = 1000) -> List[Dict[str, Any]]:
        """
        Fetch markets from Kalshi API.

        Args:
            limit: Maximum number of markets to fetch.

        Returns:
            List of raw market dictionaries.
        """
        logger.info(f"[Kalshi] Fetching markets (limit={limit})")

        markets = []
        cursor = None
        max_pages = 10

        connector = self._create_connector()

        async with aiohttp.ClientSession(connector=connector) as session:
            for page in range(max_pages):
                if len(markets) >= limit:
                    break

                try:
                    params = {
                        "limit": min(limit, 1000),
                        "status": "open"
                    }

                    if cursor:
                        params["cursor"] = cursor

                    headers = {}
                    if self._api_key:
                        headers["Authorization"] = f"Bearer {self._api_key}"

                    url = f"{self.api_base_url}/markets"

                    async with session.get(
                        url,
                        params=params,
                        headers=headers,
                        timeout=self._get_timeout()
                    ) as response:
                        if response.status == 200:
                            data = await response.json()
                            page_markets = data.get("markets", [])

                            if not page_markets:
                                break

                            markets.extend(page_markets)
                            logger.debug(
                                f"[Kalshi] Page {page + 1}: "
                                f"{len(page_markets)} markets (total: {len(markets)})"
                            )

                            cursor = data.get("cursor")
                            if not cursor:
                                break
                        else:
                            logger.warning(f"[Kalshi] API returned status {response.status}")
                            break

                except Exception as e:
                    logger.error(f"[Kalshi] Error fetching page {page + 1}: {e}")
                    break

        logger.info(f"[Kalshi] Total markets fetched: {len(markets)}")
        return markets[:limit]

    def normalize(self, raw_market: Dict[str, Any]) -> UnifiedMarket:
        """
        Convert Kalshi market to unified schema.

        Kalshi prices are in cents (0-100), so we divide by 100.

        Args:
            raw_market: Raw market data from Kalshi API.

        Returns:
            UnifiedMarket instance.
        """
        # Kalshi prices are in cents (0-100)
        yes_bid = raw_market.get("yes_bid", 0) or 0
        yes_ask = raw_market.get("yes_ask", 0) or 0
        last_price = raw_market.get("last_price", 0) or 0

        # Use midpoint or last price
        if yes_bid and yes_ask:
            yes_price = (yes_bid + yes_ask) / 200  # Convert to 0-1
        else:
            yes_price = last_price / 100 if last_price else 0.5

        no_price = 1 - yes_price

        # Build URL
        ticker = raw_market.get("ticker", "")
        market_url = f"https://kalshi.com/markets/{ticker}" if ticker else "https://kalshi.com"

        # Parse status
        status_str = raw_market.get("status", "open")
        if status_str == "open":
            status = MarketStatus.OPEN
        elif status_str == "closed":
            status = MarketStatus.CLOSED
        elif status_str == "settled":
            status = MarketStatus.RESOLVED
        else:
            status = MarketStatus.OPEN

        # Parse timestamps
        close_time = self._parse_timestamp(raw_market.get("close_time"))
        created_at = self._parse_timestamp(raw_market.get("open_time"))

        return UnifiedMarket(
            platform=self.platform_name,
            market_id=raw_market.get("ticker", str(raw_market.get("id", ""))),
            title=raw_market.get("title", ""),
            url=market_url,
            yes_price=yes_price,
            no_price=no_price,
            volume=float(raw_market.get("volume", 0) or 0),
            volume_24h=float(raw_market.get("volume_24h", 0) or 0),
            liquidity=float(raw_market.get("open_interest", 0) or 0),
            total_pool=float(raw_market.get("open_interest", 0) or 0),
            status=status,
            is_resolved=status == MarketStatus.RESOLVED,
            close_time=close_time,
            created_at=created_at,
            slug=ticker,
            category=raw_market.get("category"),
            description=raw_market.get("subtitle"),
            image_url=None,  # Kalshi API doesn't provide images
            market_type=MarketType.BINARY,
            last_trade_price=last_price / 100 if last_price else None,
            best_bid=yes_bid / 100 if yes_bid else None,
            best_ask=yes_ask / 100 if yes_ask else None,
            min_bet=raw_market.get("floor_strike"),
            max_bet=raw_market.get("cap_strike"),
            _raw=raw_market,
        )

    @staticmethod
    def _parse_timestamp(value: Optional[str]) -> Optional[datetime]:
        """Parse ISO timestamp string to datetime."""
        if not value:
            return None
        try:
            value = value.replace("Z", "+00:00")
            return datetime.fromisoformat(value)
        except (ValueError, TypeError):
            return None
