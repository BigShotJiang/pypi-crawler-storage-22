"""
Manifold Provider

Fetches and normalizes market data from Manifold Markets API.
Manifold is a play-money prediction market platform using virtual currency (Mana).
"""

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

import aiohttp

from polypoll_sdk.config import APIEndpoints, Platform
from polypoll_sdk.models.market import MarketStatus, MarketType, UnifiedMarket
from polypoll_sdk.providers.base import BaseProvider

logger = logging.getLogger(__name__)


class ManifoldProvider(BaseProvider):
    """
    Provider for Manifold Markets.

    Manifold is a play-money platform where users trade with "Mana".
    Probabilities are stored directly (0-1), no conversion needed.
    """

    @property
    def platform_name(self) -> str:
        return Platform.MANIFOLD

    @property
    def api_base_url(self) -> str:
        return APIEndpoints.MANIFOLD

    async def fetch_markets(self, limit: int = 1000) -> List[Dict[str, Any]]:
        """
        Fetch markets from Manifold Markets API.

        Args:
            limit: Maximum number of markets to fetch.

        Returns:
            List of raw market dictionaries.
        """
        logger.info(f"[Manifold] Fetching markets (limit={limit})")

        connector = self._create_connector()

        async with aiohttp.ClientSession(connector=connector) as session:
            try:
                url = f"{self.api_base_url}/markets"
                params = {"limit": min(limit, 1000)}

                async with session.get(
                    url,
                    params=params,
                    timeout=self._get_timeout()
                ) as response:
                    if response.status == 200:
                        markets = await response.json()

                        # Filter for open markets
                        markets = [m for m in markets if not m.get('isResolved', False)]

                        logger.info(f"[Manifold] Fetched {len(markets)} open markets")
                        return markets[:limit]
                    else:
                        logger.warning(f"[Manifold] API returned status {response.status}")
                        return []

            except Exception as e:
                logger.error(f"[Manifold] Error fetching markets: {e}")
                return []

    def normalize(self, raw_market: Dict[str, Any]) -> UnifiedMarket:
        """
        Convert Manifold market to unified schema.

        Args:
            raw_market: Raw market data from Manifold API.

        Returns:
            UnifiedMarket instance.
        """
        # Manifold stores probability directly (0-1)
        probability = raw_market.get("probability", 0.5)
        yes_price = float(probability)
        no_price = 1 - yes_price

        # Build URL
        slug = raw_market.get("slug", "")
        creator_username = raw_market.get("creatorUsername", "")
        if slug and creator_username:
            market_url = f"https://manifold.markets/{creator_username}/{slug}"
        else:
            market_url = f"https://manifold.markets/market/{raw_market.get('id', '')}"

        # Parse status
        is_resolved = raw_market.get("isResolved", False)
        if is_resolved:
            status = MarketStatus.RESOLVED
        elif raw_market.get("closeTime") and datetime.now().timestamp() * 1000 > raw_market.get("closeTime", 0):
            status = MarketStatus.CLOSED
        else:
            status = MarketStatus.OPEN

        # Parse timestamps (Manifold uses milliseconds)
        close_time = self._parse_ms_timestamp(raw_market.get("closeTime"))
        created_at = self._parse_ms_timestamp(raw_market.get("createdTime"))

        # Determine market type
        outcome_type = raw_market.get("outcomeType", "BINARY")
        if outcome_type == "BINARY":
            market_type = MarketType.BINARY
        elif outcome_type in ["MULTIPLE_CHOICE", "FREE_RESPONSE"]:
            market_type = MarketType.MULTIPLE_CHOICE
        else:
            market_type = MarketType.SCALAR

        return UnifiedMarket(
            platform=self.platform_name,
            market_id=raw_market.get("id", ""),
            title=raw_market.get("question", ""),
            url=market_url,
            yes_price=yes_price,
            no_price=no_price,
            volume=float(raw_market.get("volume", 0) or 0),
            volume_24h=float(raw_market.get("volume24Hours", 0) or 0),
            liquidity=float(raw_market.get("totalLiquidity", 0) or 0),
            total_pool=float(raw_market.get("pool", {}).get("YES", 0) or 0) +
                       float(raw_market.get("pool", {}).get("NO", 0) or 0),
            status=status,
            is_resolved=is_resolved,
            close_time=close_time,
            created_at=created_at,
            slug=slug,
            category=raw_market.get("groupSlugs", [None])[0] if raw_market.get("groupSlugs") else None,
            description=raw_market.get("description"),
            image_url=raw_market.get("coverImageUrl"),
            creator=creator_username,
            tags=raw_market.get("groupSlugs", []) or [],
            market_type=market_type,
            num_traders=raw_market.get("uniqueBettorCount"),
            resolution=raw_market.get("resolution"),
            _raw=raw_market,
        )

    @staticmethod
    def _parse_ms_timestamp(value: Optional[int]) -> Optional[datetime]:
        """Parse millisecond timestamp to datetime."""
        if not value:
            return None
        try:
            return datetime.fromtimestamp(value / 1000)
        except (ValueError, TypeError, OSError):
            return None
