"""
Metaculus Provider

Fetches and normalizes prediction data from Metaculus API.
Metaculus is an expert forecasting platform with no real trading.
"""

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

import aiohttp

from polypoll_sdk.config import APIEndpoints, Platform
from polypoll_sdk.models.market import MarketStatus, MarketType, UnifiedMarket
from polypoll_sdk.providers.base import BaseProvider

logger = logging.getLogger(__name__)


class MetaculusProvider(BaseProvider):
    """
    Provider for Metaculus predictions.

    Metaculus is an expert forecasting platform where users make
    probability estimates without real-money trading.
    """

    @property
    def platform_name(self) -> str:
        return Platform.METACULUS

    @property
    def api_base_url(self) -> str:
        return APIEndpoints.METACULUS

    async def fetch_markets(self, limit: int = 500) -> List[Dict[str, Any]]:
        """
        Fetch questions from Metaculus API.

        Args:
            limit: Maximum number of questions to fetch.

        Returns:
            List of raw question dictionaries.
        """
        logger.info(f"[Metaculus] Fetching questions (limit={limit})")

        connector = self._create_connector()

        async with aiohttp.ClientSession(connector=connector) as session:
            try:
                url = f"{self.api_base_url}/questions/"
                params = {
                    "limit": min(limit, 100),  # Metaculus has smaller page size
                    "status": "open",
                    "type": "forecast"
                }

                async with session.get(
                    url,
                    params=params,
                    timeout=self._get_timeout()
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        markets = data.get("results", [])
                        logger.info(f"[Metaculus] Fetched {len(markets)} questions")
                        return markets[:limit]
                    else:
                        logger.warning(f"[Metaculus] API returned status {response.status}")
                        return []

            except Exception as e:
                logger.error(f"[Metaculus] Error fetching questions: {e}")
                return []

    def normalize(self, raw_market: Dict[str, Any]) -> UnifiedMarket:
        """
        Convert Metaculus question to unified schema.

        Args:
            raw_market: Raw question data from Metaculus API.

        Returns:
            UnifiedMarket instance.
        """
        # Get community prediction
        community_prediction = raw_market.get("community_prediction", {})
        if isinstance(community_prediction, dict):
            # Binary questions have a 'full' field with 'q2' (median)
            full = community_prediction.get("full", {})
            yes_price = full.get("q2", 0.5) if full else 0.5
        else:
            yes_price = float(community_prediction) if community_prediction else 0.5

        no_price = 1 - yes_price

        # Build URL
        question_id = raw_market.get("id", "")
        market_url = f"https://www.metaculus.com/questions/{question_id}/"

        # Parse status
        status_str = raw_market.get("status", "")
        if status_str == "open":
            status = MarketStatus.OPEN
        elif status_str in ["closed", "pending_resolution"]:
            status = MarketStatus.CLOSED
        elif status_str == "resolved":
            status = MarketStatus.RESOLVED
        else:
            status = MarketStatus.OPEN

        # Parse timestamps
        close_time = self._parse_timestamp(raw_market.get("scheduled_resolve_time"))
        created_at = self._parse_timestamp(raw_market.get("created_time"))

        # Determine market type
        question_type = raw_market.get("type", "binary")
        if question_type == "binary":
            market_type = MarketType.BINARY
        elif question_type == "multiple_choice":
            market_type = MarketType.MULTIPLE_CHOICE
        else:
            market_type = MarketType.SCALAR

        return UnifiedMarket(
            platform=self.platform_name,
            market_id=str(question_id),
            title=raw_market.get("title", ""),
            url=market_url,
            yes_price=yes_price,
            no_price=no_price,
            volume=0,  # Metaculus has no trading volume
            volume_24h=0,
            liquidity=None,
            total_pool=0,
            status=status,
            is_resolved=status == MarketStatus.RESOLVED,
            close_time=close_time,
            created_at=created_at,
            slug=raw_market.get("url_title"),
            category=raw_market.get("group", {}).get("name") if raw_market.get("group") else None,
            description=raw_market.get("description"),
            image_url=None,  # Metaculus doesn't provide images via API
            creator=raw_market.get("author", {}).get("username") if raw_market.get("author") else None,
            market_type=market_type,
            forecaster_count=raw_market.get("prediction_count"),
            resolution=raw_market.get("resolution"),
            resolution_source=raw_market.get("resolution_criteria"),
            _raw=raw_market,
        )

    @staticmethod
    def _parse_timestamp(value: Optional[str]) -> Optional[datetime]:
        """Parse ISO timestamp string to datetime."""
        if not value:
            return None
        try:
            value = value.replace("Z", "+00:00")
            return datetime.fromisoformat(value)
        except (ValueError, TypeError):
            return None
