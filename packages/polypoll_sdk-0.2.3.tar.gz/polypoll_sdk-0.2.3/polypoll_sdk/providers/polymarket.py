"""
Polymarket Provider

Fetches and normalizes market data from Polymarket's Gamma API.
Polymarket is a crypto-based prediction market platform on Polygon using USDC.
"""

import json
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

import aiohttp

from polypoll_sdk.config import APIEndpoints, Platform
from polypoll_sdk.models.market import MarketStatus, MarketType, UnifiedMarket, MarketOption
from polypoll_sdk.providers.base import BaseProvider

logger = logging.getLogger(__name__)


class PolymarketProvider(BaseProvider):
    """
    Provider for Polymarket prediction markets.

    Uses the Gamma API to fetch market data. Polymarket markets trade
    using USDC with AMM-style pricing on Polygon.
    """

    @property
    def platform_name(self) -> str:
        return Platform.POLYMARKET

    @property
    def api_base_url(self) -> str:
        return APIEndpoints.POLYMARKET

    async def fetch_markets(self, limit: int = 1000) -> List[Dict[str, Any]]:
        """
        Fetch markets from Polymarket Gamma API.

        Args:
            limit: Maximum number of markets to fetch.

        Returns:
            List of raw market dictionaries.
        """
        logger.info(f"[Polymarket] Fetching markets (limit={limit})")

        markets = []
        offset = 0
        page_size = 100
        max_pages = limit // page_size + 1

        connector = self._create_connector()

        async with aiohttp.ClientSession(connector=connector) as session:
            for page in range(max_pages):
                if len(markets) >= limit:
                    break

                try:
                    params = {
                        "limit": page_size,
                        "offset": offset,
                        "closed": "false"  # Only fetch active markets
                    }

                    url = f"{self.api_base_url}/events"

                    async with session.get(
                        url,
                        params=params,
                        timeout=self._get_timeout()
                    ) as response:
                        if response.status == 200:
                            events = await response.json()

                            if not events:
                                break

                            # Extract markets from events
                            for event in events:
                                event_markets = event.get('markets', [])
                                markets.extend(event_markets)

                            logger.debug(
                                f"[Polymarket] Page {page + 1}: "
                                f"{len(events)} events, {len(markets)} total markets"
                            )

                            if len(events) < page_size:
                                break

                            offset += page_size
                        else:
                            logger.warning(f"[Polymarket] API returned status {response.status}")
                            break

                except Exception as e:
                    logger.error(f"[Polymarket] Error fetching page {page + 1}: {e}")
                    break

        # Sort by volume descending
        markets.sort(key=lambda m: float(m.get('volume', 0) or 0), reverse=True)

        logger.info(f"[Polymarket] Total markets fetched: {len(markets)}")
        return markets[:limit]

    async def search_markets(self, query: str, limit: int = 50) -> List[UnifiedMarket]:
        """
        Search Polymarket markets by keyword.

        Args:
            query: Search query string.
            limit: Maximum number of results.

        Returns:
            List of matching UnifiedMarket instances.
        """
        logger.info(f"[Polymarket] Searching for: '{query}'")

        connector = self._create_connector()

        async with aiohttp.ClientSession(connector=connector) as session:
            try:
                params = {"limit": limit, "query": query}
                url = f"{self.api_base_url}/markets"

                async with session.get(
                    url,
                    params=params,
                    timeout=self._get_timeout()
                ) as response:
                    if response.status == 200:
                        raw_markets = await response.json()
                        return [self.normalize(m) for m in raw_markets]
                    else:
                        logger.warning(f"[Polymarket] Search returned status {response.status}")
                        return []

            except Exception as e:
                logger.error(f"[Polymarket] Search error: {e}")
                return []

    def normalize(self, raw_market: Dict[str, Any]) -> UnifiedMarket:
        """
        Convert Polymarket market to unified schema.

        Args:
            raw_market: Raw market data from Polymarket API.

        Returns:
            UnifiedMarket instance.
        """
        # Parse outcome prices
        outcome_prices = self._parse_json_field(
            raw_market.get("outcomePrices", "[]"),
            default=[]
        )

        yes_price = float(outcome_prices[0]) if len(outcome_prices) > 0 else 0.5
        no_price = float(outcome_prices[1]) if len(outcome_prices) > 1 else 0.5

        # Build URLs
        slug = raw_market.get("slug", "")
        market_url = f"https://polymarket.com/event/{slug}" if slug else "https://polymarket.com"

        # Parse status
        is_closed = raw_market.get("closed", False)
        is_resolved = raw_market.get("resolved", False)

        if is_resolved:
            status = MarketStatus.RESOLVED
        elif is_closed:
            status = MarketStatus.CLOSED
        else:
            status = MarketStatus.OPEN

        # Parse timestamps
        close_time = self._parse_timestamp(raw_market.get("endDate"))
        created_at = self._parse_timestamp(raw_market.get("createdAt"))

        # Build options for multi-outcome markets
        options = []
        outcomes = self._parse_json_field(raw_market.get("outcomes", "[]"), default=[])
        for i, outcome in enumerate(outcomes):
            price = float(outcome_prices[i]) if i < len(outcome_prices) else 0.5
            options.append(MarketOption(
                id=str(i),
                name=str(outcome),
                price=price
            ))

        market_type = MarketType.BINARY if len(options) <= 2 else MarketType.MULTIPLE_CHOICE

        return UnifiedMarket(
            platform=self.platform_name,
            market_id=str(raw_market.get("id", "")),
            title=raw_market.get("question", raw_market.get("title", "")),
            url=market_url,
            yes_price=yes_price,
            no_price=no_price,
            volume=float(raw_market.get("volume", 0) or 0),
            volume_24h=float(raw_market.get("volume24hr", 0) or 0),
            liquidity=float(raw_market.get("liquidity", 0) or 0),
            total_pool=float(raw_market.get("liquidity", 0) or 0),
            status=status,
            is_resolved=is_resolved,
            close_time=close_time,
            created_at=created_at,
            slug=slug,
            category=raw_market.get("category"),
            description=raw_market.get("description"),
            image_url=raw_market.get("image"),
            creator=raw_market.get("creator"),
            tags=raw_market.get("tags", []) or [],
            market_type=market_type,
            options=options,
            last_trade_price=float(outcome_prices[0]) if outcome_prices else None,
            num_traders=raw_market.get("numTraders"),
            condition_id=raw_market.get("conditionId"),
            token_id=raw_market.get("tokenId"),
            _raw=raw_market,
        )

    @staticmethod
    def _parse_json_field(field: Any, default: Any = None) -> Any:
        """Parse a field that might be JSON string or already parsed."""
        if isinstance(field, str):
            try:
                return json.loads(field)
            except (json.JSONDecodeError, ValueError):
                return default
        return field if field is not None else default

    @staticmethod
    def _parse_timestamp(value: Optional[str]) -> Optional[datetime]:
        """Parse ISO timestamp string to datetime."""
        if not value:
            return None
        try:
            # Handle various timestamp formats
            value = value.replace("Z", "+00:00")
            return datetime.fromisoformat(value)
        except (ValueError, TypeError):
            return None
