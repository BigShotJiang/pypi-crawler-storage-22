"""
PredictIt Provider

Fetches and normalizes market data from PredictIt API.
PredictIt is a US political prediction market with real-money contracts.
"""

import asyncio
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

import aiohttp

from polypoll_sdk.config import APIEndpoints, Platform
from polypoll_sdk.models.market import MarketStatus, MarketType, UnifiedMarket, MarketOption
from polypoll_sdk.providers.base import BaseProvider

logger = logging.getLogger(__name__)

# Retry configuration
MAX_RETRIES = 3
RETRY_DELAYS = [1, 2, 4]  # Exponential backoff: 1s, 2s, 4s


class PredictItProvider(BaseProvider):
    """
    Provider for PredictIt prediction markets.

    PredictIt is a real-money political prediction market.
    Each market can have multiple contracts (options).
    Prices are stored as decimals (0-1).
    """

    @property
    def platform_name(self) -> str:
        return Platform.PREDICTIT

    @property
    def api_base_url(self) -> str:
        return APIEndpoints.PREDICTIT

    async def fetch_markets(self, limit: int = 500) -> List[Dict[str, Any]]:
        """
        Fetch all markets from PredictIt API.

        PredictIt has a single endpoint that returns all markets.
        Includes exponential backoff retry for rate limiting (429 errors).

        Args:
            limit: Maximum number of markets to return.

        Returns:
            List of raw market dictionaries.
        """
        logger.info(f"[PredictIt] Fetching markets")

        connector = self._create_connector()

        async with aiohttp.ClientSession(connector=connector) as session:
            url = f"{self.api_base_url}/marketdata/all"

            for attempt in range(MAX_RETRIES):
                try:
                    async with session.get(
                        url,
                        timeout=self._get_timeout()
                    ) as response:
                        if response.status == 200:
                            data = await response.json()
                            markets = data.get("markets", [])
                            logger.info(f"[PredictIt] Fetched {len(markets)} markets")
                            return markets[:limit]
                        elif response.status == 429:
                            # Rate limited - retry with exponential backoff
                            if attempt < MAX_RETRIES - 1:
                                delay = RETRY_DELAYS[attempt]
                                logger.warning(f"[PredictIt] Rate limited (429), retrying in {delay}s (attempt {attempt + 1}/{MAX_RETRIES})")
                                await asyncio.sleep(delay)
                                continue
                            else:
                                logger.error(f"[PredictIt] Rate limited after {MAX_RETRIES} retries")
                                return []
                        else:
                            logger.warning(f"[PredictIt] API returned status {response.status}")
                            return []

                except asyncio.TimeoutError:
                    if attempt < MAX_RETRIES - 1:
                        delay = RETRY_DELAYS[attempt]
                        logger.warning(f"[PredictIt] Timeout, retrying in {delay}s (attempt {attempt + 1}/{MAX_RETRIES})")
                        await asyncio.sleep(delay)
                        continue
                    else:
                        logger.error(f"[PredictIt] Timeout after {MAX_RETRIES} retries")
                        return []

                except Exception as e:
                    logger.error(f"[PredictIt] Error fetching markets: {e}")
                    return []

        return []

    def normalize(self, raw_market: Dict[str, Any]) -> UnifiedMarket:
        """
        Convert PredictIt market to unified schema.

        PredictIt markets can have multiple contracts. We treat each
        market as a multiple-choice market with contracts as options.

        Args:
            raw_market: Raw market data from PredictIt API.

        Returns:
            UnifiedMarket instance.
        """
        contracts = raw_market.get("contracts", [])

        # For binary markets (1-2 contracts), get yes/no prices
        if len(contracts) <= 2 and contracts:
            # First contract is typically the "main" option
            first_contract = contracts[0]
            yes_price = float(first_contract.get("lastTradePrice", 0.5) or 0.5)
            no_price = 1 - yes_price
            market_type = MarketType.BINARY
        else:
            # Multiple choice - use first contract's price
            yes_price = float(contracts[0].get("lastTradePrice", 0.5) or 0.5) if contracts else 0.5
            no_price = 1 - yes_price
            market_type = MarketType.MULTIPLE_CHOICE

        # Build options from contracts
        options = []
        for contract in contracts:
            options.append(MarketOption(
                id=str(contract.get("id", "")),
                name=contract.get("name", ""),
                price=float(contract.get("lastTradePrice", 0) or 0),
                volume=contract.get("totalSharesTraded")
            ))

        # Calculate total volume from all contracts
        total_volume = sum(
            float(c.get("totalSharesTraded", 0) or 0)
            for c in contracts
        )

        # Build URL
        market_url = raw_market.get("url", "https://www.predictit.org")

        # Parse status - PredictIt doesn't have explicit status field
        status = MarketStatus.OPEN  # Assume open since API only returns active markets

        # Parse timestamps
        close_time = self._parse_timestamp(raw_market.get("dateEnd"))

        return UnifiedMarket(
            platform=self.platform_name,
            market_id=str(raw_market.get("id", "")),
            title=raw_market.get("name", raw_market.get("shortName", "")),
            url=market_url,
            yes_price=yes_price,
            no_price=no_price,
            volume=total_volume,
            volume_24h=0,  # PredictIt doesn't provide 24h volume
            liquidity=None,
            total_pool=total_volume,
            status=status,
            is_resolved=False,
            close_time=close_time,
            created_at=None,
            slug=None,
            category="politics",  # PredictIt is primarily political
            description=raw_market.get("longName"),
            image_url=raw_market.get("image"),
            market_type=market_type,
            options=options,
            _raw=raw_market,
        )

    @staticmethod
    def _parse_timestamp(value: Optional[str]) -> Optional[datetime]:
        """Parse PredictIt timestamp to datetime."""
        if not value:
            return None
        try:
            # PredictIt uses format like "2024-11-05T00:00:00"
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except (ValueError, TypeError):
            return None
