"""
PolyPoll SDK REST API Server

FastAPI wrapper for the PolyPoll SDK, enabling REST API deployment.

Usage:
    # Run directly
    python -m polypoll_sdk.server

    # Or with uvicorn
    uvicorn polypoll_sdk.server:app --reload

Endpoints:
    GET  /                    - API info
    GET  /health              - Health check
    GET  /markets             - Get all markets
    GET  /markets/{platform}  - Get markets from specific platform
    GET  /search              - Search markets by query
    GET  /groups              - Get grouped markets (cross-platform)
    GET  /groups/{group_id}   - Get markets by group ID
    GET  /similar/{market_id} - Find similar markets
    GET  /arbitrage           - Detect arbitrage opportunities
"""

import asyncio
import logging
import os
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from polypoll_sdk import PolyPollSDK, Platform, __version__

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="PolyPoll SDK API",
    description="Unified REST API for prediction market data across Polymarket, Kalshi, Manifold, Metaculus, and PredictIt",
    version=__version__,
    docs_url="/docs",
    redoc_url="/redoc",
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize SDK (singleton)
sdk: Optional[PolyPollSDK] = None


def get_sdk() -> PolyPollSDK:
    """Get or create SDK instance."""
    global sdk
    if sdk is None:
        sdk = PolyPollSDK(
            exa_api_key=os.getenv("EXA_API_KEY"),
            groq_api_key=os.getenv("GROQ_API_KEY"),
            kalshi_api_key=os.getenv("KALSHI_API_KEY"),
        )
    return sdk


# ============================================================================
# Response Models
# ============================================================================

class MarketResponse(BaseModel):
    """Market response model."""
    platform: str
    market_id: str
    title: str
    url: str
    yes_price: float
    no_price: float
    group_id: Optional[str] = None
    volume: float = 0.0
    volume_24h: float = 0.0
    liquidity: Optional[float] = None
    status: str
    is_resolved: bool = False
    close_time: Optional[str] = None
    category: Optional[str] = None
    description: Optional[str] = None
    image_url: Optional[str] = None


class SimilarMarketResponse(BaseModel):
    """Similar market response."""
    market: MarketResponse
    similarity_score: float
    price_diff: Optional[float] = None


class ArbitrageResponse(BaseModel):
    """Arbitrage opportunity response."""
    market1: MarketResponse
    market2: MarketResponse
    similarity_score: float
    profit_pct: float
    strategy: str
    cost: float
    expected_return: float


class GroupingStatsResponse(BaseModel):
    """Grouping statistics response."""
    total_groups: int
    total_markets: int
    cross_platform_groups: int
    single_market_groups: int
    avg_markets_per_group: float


class HealthResponse(BaseModel):
    """Health check response."""
    status: str
    version: str
    platforms: List[str]


class InfoResponse(BaseModel):
    """API info response."""
    name: str
    version: str
    description: str
    platforms: List[str]
    endpoints: List[str]


# ============================================================================
# Utility Functions
# ============================================================================

def market_to_response(market) -> Dict[str, Any]:
    """Convert UnifiedMarket to response dict."""
    return {
        "platform": market.platform,
        "market_id": market.market_id,
        "title": market.title,
        "url": market.url,
        "yes_price": market.yes_price,
        "no_price": market.no_price,
        "group_id": market.group_id,
        "volume": market.volume,
        "volume_24h": market.volume_24h,
        "liquidity": market.liquidity,
        "status": market.status.value if hasattr(market.status, 'value') else str(market.status),
        "is_resolved": market.is_resolved,
        "close_time": market.close_time.isoformat() if market.close_time else None,
        "category": market.category,
        "description": market.description,
        "image_url": market.image_url,
    }


# ============================================================================
# Endpoints
# ============================================================================

@app.get("/", response_model=InfoResponse)
async def root():
    """Get API info."""
    return {
        "name": "PolyPoll SDK API",
        "version": __version__,
        "description": "Unified REST API for prediction market data",
        "platforms": Platform.ALL,
        "endpoints": [
            "GET /health",
            "GET /markets",
            "GET /markets/{platform}",
            "GET /search?q={query}",
            "GET /groups",
            "GET /groups/{group_id}",
            "GET /similar/{market_id}",
            "GET /arbitrage",
        ],
    }


@app.get("/health", response_model=HealthResponse)
async def health():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "version": __version__,
        "platforms": Platform.ALL,
    }


@app.get("/markets")
async def get_all_markets(
    limit: int = Query(100, ge=1, le=500, description="Max markets per platform")
) -> List[Dict[str, Any]]:
    """
    Get markets from all platforms.

    Args:
        limit: Maximum markets per platform (1-500)

    Returns:
        List of markets from all platforms
    """
    try:
        sdk = get_sdk()
        markets = await sdk.get_all_markets(limit_per_platform=limit)
        return [market_to_response(m) for m in markets]
    except Exception as e:
        logger.error(f"Error fetching markets: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/markets/{platform}")
async def get_platform_markets(
    platform: str,
    limit: int = Query(100, ge=1, le=500, description="Maximum markets to return")
) -> List[Dict[str, Any]]:
    """
    Get markets from a specific platform.

    Args:
        platform: Platform name (polymarket, kalshi, manifold, metaculus, predictit)
        limit: Maximum markets to return (1-500)

    Returns:
        List of markets from the platform
    """
    if platform not in Platform.ALL:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid platform '{platform}'. Valid platforms: {Platform.ALL}"
        )

    try:
        sdk = get_sdk()
        markets = await sdk.get_markets(platform=platform, limit=limit)
        return [market_to_response(m) for m in markets]
    except Exception as e:
        logger.error(f"Error fetching {platform} markets: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/search")
async def search_markets(
    q: str = Query(..., min_length=1, description="Search query"),
    platforms: Optional[str] = Query(None, description="Comma-separated platforms to search"),
    limit: int = Query(50, ge=1, le=200, description="Maximum results"),
    min_score: float = Query(30.0, ge=0, le=100, description="Minimum similarity score")
) -> List[Dict[str, Any]]:
    """
    Search markets by keyword using fuzzy matching.

    Args:
        q: Search query string
        platforms: Comma-separated list of platforms (default: all)
        limit: Maximum results (1-200)
        min_score: Minimum similarity score (0-100)

    Returns:
        List of matching markets sorted by relevance
    """
    try:
        sdk = get_sdk()
        platform_list = platforms.split(",") if platforms else None
        markets = await sdk.search_markets(
            query=q,
            platforms=platform_list,
            limit=limit,
            min_score=min_score
        )
        return [market_to_response(m) for m in markets]
    except Exception as e:
        logger.error(f"Error searching markets: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/groups")
async def get_grouped_markets(
    min_similarity: float = Query(80.0, ge=50, le=100, description="Minimum similarity for grouping"),
    limit_per_platform: int = Query(100, ge=1, le=500, description="Max markets per platform")
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Get markets grouped by event across platforms.

    Markets representing the same event on different platforms
    will share the same group_id.

    Args:
        min_similarity: Similarity threshold (default: 80%)
        limit_per_platform: Max markets per platform

    Returns:
        Dictionary mapping group_id to list of markets
    """
    try:
        sdk = get_sdk()
        groups = await sdk.get_grouped_markets(
            min_similarity=min_similarity,
            limit_per_platform=limit_per_platform
        )
        return {
            group_id: [market_to_response(m) for m in markets]
            for group_id, markets in groups.items()
        }
    except Exception as e:
        logger.error(f"Error getting grouped markets: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/groups/stats", response_model=GroupingStatsResponse)
async def get_grouping_stats() -> Dict[str, Any]:
    """
    Get statistics about market grouping.

    Returns:
        Grouping statistics
    """
    try:
        sdk = get_sdk()
        stats = sdk.get_grouping_stats()
        return stats
    except Exception as e:
        logger.error(f"Error getting grouping stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/groups/{group_id}")
async def get_group_markets(group_id: str) -> List[Dict[str, Any]]:
    """
    Get all markets for a specific group.

    Args:
        group_id: The group identifier

    Returns:
        List of markets in the group
    """
    try:
        sdk = get_sdk()
        markets = await sdk.get_markets_by_group(group_id)
        if not markets:
            raise HTTPException(
                status_code=404,
                detail=f"Group '{group_id}' not found"
            )
        return [market_to_response(m) for m in markets]
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting group markets: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/similar/{market_id}")
async def get_similar_markets(
    market_id: str,
    platform: Optional[str] = Query(None, description="Platform of the source market"),
    min_similarity: float = Query(65.0, ge=0, le=100, description="Minimum similarity score")
) -> List[Dict[str, Any]]:
    """
    Find similar markets across platforms.

    Args:
        market_id: Market ID to find similar markets for
        platform: Platform of the source market (auto-detected if None)
        min_similarity: Minimum similarity score (0-100)

    Returns:
        List of similar markets with scores
    """
    try:
        sdk = get_sdk()
        similar = await sdk.get_similar_markets(
            market_id=market_id,
            platform=platform,
            min_similarity=min_similarity
        )
        return [
            {
                "market": market_to_response(s.market),
                "similarity_score": s.similarity_score,
                "price_diff": s.price_diff,
            }
            for s in similar
        ]
    except Exception as e:
        logger.error(f"Error finding similar markets: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/arbitrage")
async def get_arbitrage_opportunities(
    min_profit: float = Query(0.5, ge=0, le=50, description="Minimum profit percentage"),
    min_similarity: float = Query(75.0, ge=50, le=100, description="Minimum similarity score")
) -> List[Dict[str, Any]]:
    """
    Detect cross-platform arbitrage opportunities.

    Finds markets on different platforms representing the same event
    with price differences that could yield profit.

    Args:
        min_profit: Minimum profit percentage to report
        min_similarity: Minimum similarity for market matching

    Returns:
        List of arbitrage opportunities sorted by profit
    """
    try:
        sdk = get_sdk()
        opportunities = await sdk.get_arbitrage_opportunities(
            min_profit=min_profit,
            min_similarity=min_similarity
        )
        return [
            {
                "market1": market_to_response(opp.market1),
                "market2": market_to_response(opp.market2),
                "similarity_score": opp.similarity_score,
                "profit_pct": opp.profit_pct,
                "strategy": opp.strategy,
                "cost": opp.cost,
                "expected_return": opp.expected_return,
            }
            for opp in opportunities
        ]
    except Exception as e:
        logger.error(f"Error detecting arbitrage: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# Main
# ============================================================================

def main():
    """Run the server."""
    import uvicorn

    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8080"))

    logger.info(f"Starting PolyPoll SDK API on {host}:{port}")
    uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    main()
