"""
Arbitrage Detection Service

Detects cross-platform arbitrage opportunities in prediction markets.
"""

import logging
from typing import List

from polypoll_sdk.config import SDKConfig
from polypoll_sdk.models.market import ArbitrageOpportunity, UnifiedMarket
from polypoll_sdk.services.matcher import MarketMatcher

logger = logging.getLogger(__name__)


class ArbitrageDetector:
    """
    Service for detecting cross-platform arbitrage opportunities.

    Arbitrage exists when the same event has different prices on
    different platforms, allowing risk-free profit.

    Strategy:
    - Buy YES on platform with lower yes_price
    - Buy NO on platform with higher yes_price
    - If total cost < 1, guaranteed profit
    """

    def __init__(self, config: SDKConfig):
        """
        Initialize the detector.

        Args:
            config: SDK configuration.
        """
        self.config = config
        self.matcher = MarketMatcher(config)

    def detect(
        self,
        markets: List[UnifiedMarket],
        min_profit: float = 0.5,
        min_similarity: float = 75.0,
        limit: int = 100
    ) -> List[ArbitrageOpportunity]:
        """
        Detect arbitrage opportunities across platforms.

        Args:
            markets: List of markets from all platforms.
            min_profit: Minimum profit percentage to report.
            min_similarity: Minimum similarity score for matching.
            limit: Maximum opportunities to return.

        Returns:
            List of ArbitrageOpportunity sorted by profit descending.
        """
        # Find all similar market pairs
        matches = self.matcher.match_all(markets, min_similarity=min_similarity)

        opportunities = []

        for market1, market2, similarity in matches:
            # Skip if same platform
            if market1.platform == market2.platform:
                continue

            # Calculate arbitrage for both strategies
            opp = self._calculate_arbitrage(market1, market2, similarity)

            if opp and opp.profit_pct >= min_profit:
                opportunities.append(opp)

        # Sort by profit descending
        opportunities.sort(key=lambda x: x.profit_pct, reverse=True)

        logger.info(f"Found {len(opportunities)} arbitrage opportunities")
        return opportunities[:limit]

    def _calculate_arbitrage(
        self,
        market1: UnifiedMarket,
        market2: UnifiedMarket,
        similarity: float
    ) -> ArbitrageOpportunity | None:
        """
        Calculate arbitrage opportunity between two markets.

        Two strategies:
        1. Buy YES on market1, Buy NO on market2
        2. Buy NO on market1, Buy YES on market2

        Args:
            market1: First market.
            market2: Second market.
            similarity: Similarity score between markets.

        Returns:
            ArbitrageOpportunity if profitable, None otherwise.
        """
        # Strategy 1: Buy YES on market1 + Buy NO on market2
        cost1 = market1.yes_price + market2.no_price
        if cost1 < 1:
            profit1 = ((1 - cost1) / cost1) * 100
        else:
            profit1 = 0

        # Strategy 2: Buy NO on market1 + Buy YES on market2
        cost2 = market1.no_price + market2.yes_price
        if cost2 < 1:
            profit2 = ((1 - cost2) / cost2) * 100
        else:
            profit2 = 0

        # Choose best strategy
        if profit1 > profit2 and profit1 > 0:
            return ArbitrageOpportunity(
                market1=market1,
                market2=market2,
                similarity_score=similarity,
                profit_pct=profit1,
                strategy=f"Buy YES on {market1.platform} (${market1.yes_price:.2f}), "
                        f"Buy NO on {market2.platform} (${market2.no_price:.2f})",
                cost=cost1,
                expected_return=1.0
            )
        elif profit2 > 0:
            return ArbitrageOpportunity(
                market1=market1,
                market2=market2,
                similarity_score=similarity,
                profit_pct=profit2,
                strategy=f"Buy NO on {market1.platform} (${market1.no_price:.2f}), "
                        f"Buy YES on {market2.platform} (${market2.yes_price:.2f})",
                cost=cost2,
                expected_return=1.0
            )

        return None
