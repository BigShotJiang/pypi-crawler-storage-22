"""
Market Matcher Service

Provides fuzzy matching to find similar markets across platforms.
Uses RapidFuzz for efficient string matching.
"""

import logging
from typing import List

from rapidfuzz import fuzz

from polypoll_sdk.config import SDKConfig
from polypoll_sdk.models.market import SimilarMarket, UnifiedMarket

logger = logging.getLogger(__name__)


class MarketMatcher:
    """
    Service for finding similar markets using fuzzy string matching.

    Uses a weighted combination of:
    - Full string ratio (50%)
    - Token sort ratio (30%)
    - Partial ratio (20%)
    """

    def __init__(self, config: SDKConfig):
        """
        Initialize the matcher.

        Args:
            config: SDK configuration.
        """
        self.config = config

    def find_similar(
        self,
        source: UnifiedMarket,
        candidates: List[UnifiedMarket],
        min_similarity: float = 65.0,
        limit: int = 20
    ) -> List[SimilarMarket]:
        """
        Find markets similar to the source market.

        Args:
            source: Source market to match against.
            candidates: List of candidate markets.
            min_similarity: Minimum similarity score (0-100).
            limit: Maximum number of results.

        Returns:
            List of SimilarMarket sorted by similarity score descending.
        """
        similar_markets = []

        for candidate in candidates:
            # Skip same market
            if (
                candidate.platform == source.platform and
                candidate.market_id == source.market_id
            ):
                continue

            # Calculate similarity
            score = self._calculate_similarity(source.title, candidate.title)

            if score >= min_similarity:
                # Calculate price difference
                price_diff = abs(source.yes_price - candidate.yes_price)

                similar_markets.append(SimilarMarket(
                    market=candidate,
                    similarity_score=score,
                    price_diff=price_diff
                ))

        # Sort by similarity descending
        similar_markets.sort(key=lambda x: x.similarity_score, reverse=True)

        logger.info(
            f"Found {len(similar_markets)} similar markets for '{source.title[:50]}...'"
        )

        return similar_markets[:limit]

    def _calculate_similarity(self, text1: str, text2: str) -> float:
        """
        Calculate weighted similarity score between two market titles.

        Uses entity-aware matching to identify if two markets represent
        the same event across different platforms.

        Algorithm:
        - Base score: 50% ratio + 30% token_sort + 20% partial
        - Entity penalty: reduces score if key entities don't overlap
        - This prevents false positives like "Katie Britt" matching "Republican nomination"

        Args:
            text1: First market title.
            text2: Second market title.

        Returns:
            Similarity score (0-100).
        """
        from polypoll_sdk.utils.similarity import calculate_match_score

        # Use the match algorithm (with entity penalty)
        return calculate_match_score(text1, text2, min_score=0.0)

    def match_all(
        self,
        markets: List[UnifiedMarket],
        min_similarity: float = 75.0
    ) -> List[tuple[UnifiedMarket, UnifiedMarket, float]]:
        """
        Find all similar market pairs across platforms.

        Args:
            markets: List of markets from all platforms.
            min_similarity: Minimum similarity score.

        Returns:
            List of (market1, market2, similarity_score) tuples.
        """
        # Group markets by platform
        by_platform = {}
        for market in markets:
            if market.platform not in by_platform:
                by_platform[market.platform] = []
            by_platform[market.platform].append(market)

        matches = []
        platforms = list(by_platform.keys())

        # Compare each platform pair
        for i, platform1 in enumerate(platforms):
            for platform2 in platforms[i + 1:]:
                for m1 in by_platform[platform1]:
                    for m2 in by_platform[platform2]:
                        score = self._calculate_similarity(m1.title, m2.title)
                        if score >= min_similarity:
                            matches.append((m1, m2, score))

        # Sort by similarity descending
        matches.sort(key=lambda x: x[2], reverse=True)

        logger.info(f"Found {len(matches)} cross-platform matches")
        return matches
