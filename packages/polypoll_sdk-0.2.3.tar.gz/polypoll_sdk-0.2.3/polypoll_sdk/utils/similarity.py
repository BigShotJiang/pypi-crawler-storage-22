"""
Similarity Calculation Utilities

Provides TWO SEPARATE algorithms for two different use cases:

1. SEARCH (calculate_search_score):
   - Purpose: Find markets containing the search keyword
   - Algorithm: Check if query words exist in title, then use fuzzy for ranking
   - Example: "Trump" → "Will Trump win 2024" ✓

2. MATCH (calculate_match_score):
   - Purpose: Compare two market titles to see if they represent the same event
   - Algorithm: Fuzzy matching with entity penalty to avoid false positives
   - Example: "Trump wins 2024" ↔ "Will Trump win 2024" ✓
             "Katie Britt VP" ↔ "Republican nomination" ✗

These are SEPARATE concerns and should NOT share the same penalty logic.
"""

import re
from typing import Set

from rapidfuzz import fuzz


# Common stop words to ignore in entity detection
STOP_WORDS = {
    'will', 'the', 'a', 'an', 'be', 'to', 'in', 'on', 'at', 'by', 'for', 'with',
    'is', 'are', 'was', 'were', 'has', 'have', 'had', 'do', 'does', 'did',
    'can', 'could', 'would', 'should', 'may', 'might', 'must',
    'this', 'that', 'these', 'those', 'what', 'which', 'who', 'whom',
    'before', 'after', 'during', 'between', 'into', 'through', 'from',
    'about', 'against', 'over', 'under', 'again', 'and', 'or', 'but', 'if',
    'us', 'presidential', 'election', 'win', 'wins', 'winning', 'winner',
    'market', 'price', 'yes', 'no', 'any', 'end'
}


def extract_key_entities(text: str) -> Set[str]:
    """
    Extract key entity words from text (names, organizations, numbers).

    These are the "core" words that distinguish one market from another.

    Args:
        text: Input text

    Returns:
        Set of key entity words (lowercase)
    """
    # Extract all words
    words = set(re.findall(r'\b[a-zA-Z]+\b', text.lower()))

    # Remove stop words
    entities = words - STOP_WORDS

    # Extract numbers (years, amounts, etc.)
    numbers = set(re.findall(r'\b\d+\b', text))
    entities.update(numbers)

    return entities


def _get_words(text: str) -> Set[str]:
    """Extract lowercase words from text."""
    return set(re.findall(r'\b[a-zA-Z0-9]+\b', text.lower()))


# =============================================================================
# SEARCH ALGORITHM
# =============================================================================

def calculate_search_score(query: str, title: str, min_score: float = 40.0) -> float:
    """
    Calculate search relevance score optimized for KEYWORD SEARCH.

    Algorithm:
    1. Check if ALL query words appear in title → High confidence, use fuzzy for ranking
    2. Check if ANY query word appears in title → Medium confidence
    3. No word match → Require higher fuzzy score (for typos/variations)

    This approach:
    - "Trump" matches "Will Trump win 2024" ✓ (word found)
    - "Trump" does NOT match "Republican VP nominee" ✗ (word not found, fuzzy too low)
    - "AI" does NOT match "Daily Coinflip" ✗ (word not found, fuzzy too low)
    - "Bitcoin" matches "Bitcoin price 2024" ✓ (word found)

    Args:
        query: Search query
        title: Market title
        min_score: Minimum score threshold (default: 40)

    Returns:
        Relevance score (0-100), or 0 if below threshold
    """
    if not query or not title:
        return 0.0

    query_lower = query.lower().strip()
    title_lower = title.lower().strip()

    # Extract words
    query_words = _get_words(query)
    title_words = _get_words(title)

    if not query_words:
        return 0.0

    # Calculate fuzzy score for ranking
    fuzzy_score = fuzz.token_sort_ratio(query_lower, title_lower)

    # Check word overlap
    common_words = query_words & title_words
    overlap_ratio = len(common_words) / len(query_words)

    if overlap_ratio >= 1.0:
        # ALL query words found in title - high confidence match
        # Give high base score (80), use fuzzy for minor ranking adjustments
        # This prevents short queries like "Trump" from getting low scores
        # against long titles like "Will Trump win the 2024 election"
        score = 80.0 + (fuzzy_score - 50) * 0.2  # Range: 70-90
    elif overlap_ratio > 0:
        # SOME query words found - medium confidence
        # Base score scales with overlap ratio
        score = 50.0 + overlap_ratio * 30.0  # Range: 50-80
    else:
        # NO query words found - low confidence
        # Only match if fuzzy score is very high (for typos/abbreviations)
        if fuzzy_score >= 70:
            score = fuzzy_score * 0.5
        else:
            score = 0.0

    return score if score >= min_score else 0.0


# =============================================================================
# MATCH ALGORITHM (for cross-platform comparison)
# =============================================================================

def calculate_match_score(title1: str, title2: str, min_score: float = 75.0) -> float:
    """
    Calculate cross-platform matching score to identify THE SAME EVENT.

    Algorithm:
    1. Calculate weighted fuzzy score (ratio + token_sort + partial)
    2. Extract key entities from both titles
    3. If entity overlap is low (<40%), apply 50% penalty
    4. This prevents false positives like "Katie Britt VP" matching "Republican nomination"

    Args:
        title1: First market title
        title2: Second market title
        min_score: Minimum score threshold (default: 75)

    Returns:
        Match score (0-100), or 0 if below threshold
    """
    if not title1 or not title2:
        return 0.0

    title1_lower = title1.lower().strip()
    title2_lower = title2.lower().strip()

    # Calculate weighted fuzzy score
    ratio = fuzz.ratio(title1_lower, title2_lower)
    token_sort = fuzz.token_sort_ratio(title1_lower, title2_lower)
    partial = fuzz.partial_ratio(title1_lower, title2_lower)

    raw_score = (ratio * 0.5) + (token_sort * 0.3) + (partial * 0.2)

    # Extract key entities
    entities1 = extract_key_entities(title1)
    entities2 = extract_key_entities(title2)

    # Calculate entity overlap
    if entities1 and entities2:
        common_entities = entities1 & entities2
        max_entities = max(len(entities1), len(entities2))
        overlap = len(common_entities) / max_entities if max_entities > 0 else 0

        # If entity overlap is low, apply penalty
        # This catches "Katie Britt VP" vs "Republican nomination 2024"
        # where entities {"katie", "britt"} don't overlap with {"republican", "nomination"}
        if overlap < 0.4:
            adjusted_score = raw_score * 0.5
        else:
            adjusted_score = raw_score
    else:
        adjusted_score = raw_score

    return adjusted_score if adjusted_score >= min_score else 0.0


# =============================================================================
# BACKWARD COMPATIBILITY (for existing code that uses calculate_similarity)
# =============================================================================

def calculate_similarity(
    text1: str,
    text2: str,
    short_query_threshold: int = 3,
    is_search_query: bool = False
) -> tuple[float, float]:
    """
    Calculate similarity between two texts.

    DEPRECATED: Use calculate_search_score or calculate_match_score instead.

    This function is kept for backward compatibility but routes to the
    appropriate new function based on context.

    Args:
        text1: First text (query for search, title for matching)
        text2: Second text (title for search, title for matching)
        short_query_threshold: Unused, kept for compatibility
        is_search_query: If True, use search algorithm; otherwise use match algorithm

    Returns:
        Tuple of (raw_score, adjusted_score)
    """
    if not text1 or not text2:
        return 0.0, 0.0

    text1_lower = text1.lower().strip()
    text2_lower = text2.lower().strip()

    # Calculate raw fuzzy score
    ratio = fuzz.ratio(text1_lower, text2_lower)
    token_sort = fuzz.token_sort_ratio(text1_lower, text2_lower)
    partial = fuzz.partial_ratio(text1_lower, text2_lower)
    raw_score = (ratio * 0.5) + (token_sort * 0.3) + (partial * 0.2)

    if is_search_query:
        # For search, use the new search algorithm
        adjusted_score = calculate_search_score(text1, text2, min_score=0.0)
    else:
        # For matching, use the new match algorithm
        adjusted_score = calculate_match_score(text1, text2, min_score=0.0)

    return raw_score, adjusted_score
