public class ChallengermodeConnectPopup : BasicPopup
{
}
