public class ClimatePicker : StylePicker
{
}
