from sage.matrix.constructor import matrix
from sage.functions.other import sqrt
import warnings
from sage.plot.polygon import polygon
from badic import *
from badic.cautomata import is_dark_mode, order_matrix
from badic.misc import is_Matrix
from sage.modules.free_module_element import vector
from sage.geometry.polyhedron.all import Polyhedron
from sage.misc.misc_c import prod
from sage.matrix.special import identity_matrix
from sage.plot.circle import circle
from sage.plot.graphics import Graphics

# list of regular simplices
RegSimplex = [matrix([[0],[1]]).transpose(), matrix([(0,0),(1,0),(.5, sqrt(3.)/2)]).transpose(), matrix([(0,0,0),(1,0,0),(.5, sqrt(3.)/2,0), (0.500000000000000, sqrt(3.)/6, 1/3*sqrt(3)*sqrt(2))]).transpose()]

from badic.density import split_polyhedron

def simplex_volume(m, f=None):
	"""
	Return the volume of the projective simplex.
	It is the volume of the intersection of the cone m R_+^d with the half-space (1...1)x < 0.
	
	INPUT:
		- ``m`` - matrix -- defining a projective polytope m R_+^d
		- ``f`` - linear form (default: ``None``) -- the linear form used
	
	"""
	if f is None:
		f = vector((1 for _ in range(m.nrows())))
	return abs(m.det())/prod([f*c for c in m.columns()])

def polytope_volume(m, f=None, verb=0):
	"""
	Returns the volume of the projective polytope.
	It is the volume of the intersection of the cone m R_+^d with the half-space (1...1)x < 0.
	
	INPUT:
		- ``m`` - matrix -- defining a projective polytope m R_+^d
		- ``f`` - linear form (default: ``None``) -- the linear form used
	"""
	ls = split_polyhedron_stellar(m, f=f)
	if verb > 0:
		print(ls)
	return sum([simplex_volume(m2, f=f) for m2 in ls])

def proj_to_pt (v, f=None):
	"""
	Convert a pt of projective space to a pt in the regular simplex.
	"""
	if len(v) not in [2,3,4]:
		raise NotImplementedError("Sorry, this function is implemented only for vectors of size 2,3 or 4.")
	if f is None:
		f = vector((1 for _ in range(len(v))))
	v = vector(v)
	return RegSimplex[len(v)-2]*v/(f*v)

def plot_poly (lv, f=None, d=None, color=None, alpha=1, fill=False, text=True, text_colors=None, thickness=None):
	"""
	Plot a polytope from projective coordinates of vertices.

	INPUT:
	
		- ``lv`` - list or matrix -- coordinates of vertices

		- ``f`` - linear form (default: ``None``) -- used to plot (it takes (1, ..., 1) by default).

		- ``d`` - int -- number of coordinates

		- ``color`` -- color
		
		- ``alpha`` - float (default: ``1``) -- transparency
		
		- ``fill`` - boolean (default: ``False``) -- fill the polygon ?
		
		- ``text`` - boolean (default: ``True``) -- draw numbers on vertices ?
	
	OUTPUT:
		A Graphics object.

	EXAMPLES::
		sage: from polytope_graph.polytope_graph import plot_poly
		sage: plot_poly(identity_matrix(3))
		Graphics object consisting of 4 graphics primitives
	"""
	dark = is_dark_mode()
	if is_Matrix(lv):
		lv = lv.columns()
	if d is None:
		d = len(lv[0])
	if color is None:
		if d == 3:
			if dark == 1:
				color = "white"
			elif dark == 2:
				color = "#808080"
			else:
				color = "black"
		else:
			color = "blue"
	lC = RegSimplex[d-2].columns()
	pts = [proj_to_pt(p, f=f) for p in lv]
	if d == 4:
		from sage.plot.plot3d.shapes2 import line3d
		if thickness is None:
			thickness = 2
		p = Polyhedron(rays = lv)
		g = Graphics()
		for face in p.faces(2):
			g += line3d([proj_to_pt(r, f=f) for r in face.rays()], alpha = alpha, color=color, thickness=thickness)
		m = 0
	else:
		g = polygon(pts, fill=fill, color=color, alpha=alpha, thickness=thickness)
	if text:
		m = sum(pts)/len(lv)
		if text_colors is None:
			text_colors = [color for _ in lv]
		for idx, p in enumerate(pts):
			if d == 4:
				from sage.plot.plot3d.shapes2 import text3d
				g += text3d("%s" % idx, 1.03*(p - m) + m, color=text_colors[idx])
			else:
				from sage.plot.text import text
				g += text("%s" % idx, 1.03*(p - m) + m, color=text_colors[idx])
	if dark == 2 and d < 4:
		g.SHOW_OPTIONS['transparent'] = 1
	return g

def num_to_hex(i):
	i = int(i*255)
	return hex(i//16)[2:]+hex(i%16)[2:]

def color_to_html (c):
	return "#"+num_to_hex(c[0])+num_to_hex(c[1])+num_to_hex(c[2])

def split_polyhedron_stellar(P, f=None):
	r"""
	Decompose a polyhedron into a quasi-disjoint union of simplicies using stellar subdivision 
	(by placing a point at the center of the polyhedron and connecting it to all facets).
	Return square matrices whose columns are the vertices of the simplicies.
	
	INPUT:
		- ``f`` - linear form used to normalize
	"""
	from badic.density import simplify_polyhedron
	from sage.geometry.polyhedron.all import Polyhedron
	if is_Matrix(P):
		if P.is_zero():
			return []
		if f is None:
			f = vector((1 for _ in range(P.nrows())))
		P = Polyhedron([c/(f*c) for c in P.columns()])
	
	d = P.dimension()
	
	if len(P.vertices()) <= d+1:
		return [simplify_polyhedron(matrix(P.vertices()).transpose())]
	
	# Barycenter
	vertices = list(P.vertices())
	center = sum(vector(v) for v in vertices) / len(vertices)
	
	simplicies = []
	
	# For each (d-1)-dimensional facet
	for facet in P.facets():
		facet_poly = facet.as_polyhedron()
		
		# Triangulate the facet
		facet_simplicies = split_polyhedron_stellar(facet_poly)
		
		# For each simplex in the facet triangulation
		for facet_simplex_matrix in facet_simplicies:
			facet_simplex_vertices = [vector(col) for col in facet_simplex_matrix.columns()]
			# Create an ambient simplex by adding the barycenter
			simplex_vertices = facet_simplex_vertices + [center]
			# Convert to matrix and simplify
			simplicies.append(simplify_polyhedron(matrix(simplex_vertices).transpose()))
	
	return simplicies

def polytope_linear_form(m):
	"""
	Returns a linear form f such that f*m is positive.
	"""
	# try the default linear form
	f = vector((1 for _ in range(m.nrows())))
	if all((t > 0 for t in f*m)):
		return f
	p = Polyhedron(rays = m.columns())
	if p.lines():
		raise ValueError("Incorrect data: the cone with matrix\n%s\ncontains 0." % m)
	return sum([vector(i)[1:] for i in p.inequalities()])

def pseudo_inverse(m, B, verb=0):
	# complete to a base of the whole space
	E = m.transpose().image()
	mc = matrix(B.columns() + E.complement().basis()).transpose()
	# invert it
	Bi = mc.inverse()
	if verb > 0:
		print(Bi*B)
	# take the submatrix
	d = B.ncols()
	return Bi.submatrix(nrows=d)

class PolytopeGraph(DetAutomaton):
	"""
	Polytope graph.
	It is a graph where
	 - states are associated to a polytope, represented by a matrix m (the projective polytope is m R_+^d).
		The polytope graph can also be a degenerated subgraph, where each state is associated to couple (m, F) where m is the matrix of a polytope and F is a face of m.
	 - edges are labeled by matrices
	
	EXAMPLES::
		sage: from polytope_graph import *

		# simple example
		sage: m1 = matrix([[1,1,0],[0,1,0],[0,0,1]])
		sage: m2 = matrix([[1,0,0],[1,1,0],[0,0,1]])
		sage: PolytopeGraph([identity_matrix(3)], [(0,0,m1), (0,0,m2)])
		PolytopeGraph of dimension 3, with 1 vertices and 2 edges

		# Cassaigne example
		sage: PolytopeGraph(dag.Cassaigne())
		PolytopeGraph of dimension 3, with 1 vertices and 2 edges

		# Cassaigne win-lose
		sage: PolytopeGraph(dag.CassaigneWinLose())
		PolytopeGraph of dimension 3, with 3 vertices and 6 edges

		# Example coming from Rauzy induction
		sage: rg = rauzy_graph(("ABC", "CBA"))
		sage: a = PolytopeGraph(rg)
		sage: a.plot()
		... image
		sage: a2 = a2 = rauzy_to_polytope_graph2(rg)
		sage: a2.plot()
		... image
		sage: ad = a2.degenerate_subgraph(2, matrix([[1],[-1],[-1]]))
		sage: ad.plot()
		... image
		sage: a2.degenerate_subgraph(0, matrix([[0,0],[0,1],[-1,-1]]))
		PolytopeGraph of dimension 3, with 3 vertices and 4 edges

		# non-ergodic (degenerating) example
		sage: m1 = matrix([[1,0,1],[0,1,0],[0,1,1]])
		sage: m2 = matrix([[1,0,0],[0,1,1],[0,0,1]])
		sage: m3 = matrix([[1,0,0],[0,1,0],[1,1,1]])
		sage: m4 = matrix([[1,0,0],[0,1,0],[0,0,1]])
		sage: s1 = matrix([[1,0,0,1],[0,1,1,0],[0,0,1,1]])
		sage: s2 = matrix([[1,0,0],[0,1,0],[0,0,1]])
		sage: PolytopeGraph([s1, s2], [(0,1,m1),(0,1,m2),(1,1,m3),(1,0,m4)])
		PolytopeGraph of dimension 3, with 2 vertices and 4 edges

		# ergodic (non-degenerating) example
		sage: m1 = matrix([[1,0,1],[0,1,1],[0,0,1]]).transpose()
		sage: m2 = matrix([[1,0,0],[0,1,0],[0,0,1]]).transpose()
		sage: m3 = matrix([[1,0,0],[0,1,0],[1,0,1]]).transpose()
		sage: m4 = matrix([[1,0,1],[0,1,0],[0,1,1]]).transpose()
		sage: m5 = matrix([[0,0,1],[1,0,0],[0,1,0]]).transpose()
		sage: m6 = matrix([[1,1,0],[0,1,0],[0,1,1]]).transpose()
		sage: s1_mat = matrix([[1,0,0],[0,1,0],[0,0,1]])
		sage: s2_mat = matrix([[1,0,0,1],[0,1,1,0],[0,0,1,1]])
		sage: PolytopeGraph([s1_mat, s2_mat, s1_mat], [(0,0,m1),(0,1,m2),(1,0,m3),(1,2,m4),(2,1,m5),(2,2,m6)])
		PolytopeGraph of dimension 3, with 3 vertices and 6 edges

	TESTS::
		sage: m1 = matrix([[1,1,0],[0,1,0],[0,0,1]])
		sage: m2 = matrix([[1,0,0],[0,1,1],[0,0,1]])
		sage: PolytopeGraph([identity_matrix(3)], [(0,0,m1), (0,0,m2)])
		In state 0, two pieces intersect.
		...
		PolytopeGraph of dimension 3, with 1 vertices and 2 edges

		sage: m1 = matrix([[1,1,0],[0,1,0],[0,0,1]])
		sage: m2 = matrix([[1,0,0],[1,1,1],[0,0,1]])
		sage: PolytopeGraph([identity_matrix(3)], [(0,0,m1), (0,0,m2)])
		In state 0, the sum of volumes 3/4 is not equal to the volume 1 of the polytope.
		...
	"""

	def __init__(self, lm, le=None, lf=None, A=None, check=None, nochange=0, verb=0):
		r"""
		INPUT:
	
		-``lm`` - a list of matrices for the states or a DetAutomaton describing a win-lose graph or a matrices graph (it tries to convert to matrices graph)
	
		- ``le`` - a list of edges, where the states are represented by the indices from lm

		- ``lf`` - list of linear forms of states

		- ``check`` -- if True, test if the polytope graph is valid

		OUTPUT:
			Return a instance of :class:`PolytopeGraph`.
		"""
		
		from badic.density import simplify_polyhedron
		from polytope_graph.rauzy import choose_base

		if le is None:
			try:
				a = lm
				le = a.graphe.edges()
				from badic.density import simplify_polyhedron
				a.build_polyhedra()
				ls = [simplify_polyhedron(matrix(p.vertices()).transpose()) for p in a.polyhedron.values()]
				lB = [choose_base(m) for m in ls]
				lsi = [pseudo_inverse(m, b) for (m,b) in zip(ls,lB)]
				lm = [mi*m for mi,m in zip(lsi, ls)]
				le = [(i, k, lsi[i]*m*lB[k]) for i,k,m in a.graphe.edges() if m is not None]
				self.__init__(lm, le)
			except Exception as e:
				if verb:
					print(e)
				# assume lm is a DetAutomaton
				if nochange:
					return super().__init__(lm)
				a = lm.matrices_graph() # convert it to matrices graph
				d = a.alphabet[0].nrows()
				if verb > 0:
					print("d =", d)
					print("edges:")
					print(a.edges())
				return self.__init__([identity_matrix(d) for _ in range(a.n_states)], a.edges(), check=check)
		else:
			if is_Matrix(lm[0]):
				m = lm[0]
				if check is None:
					check = True
			else:
				m = lm[0][0]
				if check is None:
					check = False
			d = m.nrows()
		if verb > 2:
			print(lm)
			print(le)
		if lf is None:
			self.lf = [None for _ in range(len(lm))] # linear form used for each state
		else:
			self.lf = lf
		for im,(m,f) in enumerate(zip(lm, self.lf)):
			if is_Matrix(m):
				m.set_immutable()
				m2 = m
			else:
				m[0].set_immutable()
				m[1].set_immutable()
				m2 = m[0]
			if self.lf[im] is None:
				self.lf[im] = polytope_linear_form(m2)
			elif check:
				if not all((t > 0 for t in f*m2)):
					warnings.warn("Change the linear form used for state %s" % im)
		for edge in le:
			edge[2].set_immutable()
		le = [(i,j,k) for i,k,j in le]
		super().__init__(le, A=A, avoidDiGraph=True)
		self.set_states([lm[i] for i in self.states])
		if check:
			try:
				if not self.check_partition(lf=self.lf):
					self.check_partition(lf=self.lf, verb=1)
					warnings.warn(f"The graph is not correct. Try self.check_partition(verb=2) to print more information.")
			except Exception as e:
				print(e)
				warnings.warn(f"Test of correctness fails ! The graph may not be correct. Try self.check_partition(verb=2) to print more information.")

	def __repr__(self):
		return "PolytopeGraph of dimension %s, with %s vertices and %s edges" % (self.dim(), self.n_states, len(self.edges()))

	def check_state_partition(a, i, f=None, verb=0):
		"""
		Check that polytopes given by outgoing edges from state i is a partition of the polytope of state i.
		
		INPUT:
			- ``i`` - int -- index of vertex
			- ``f`` - linear form (default: ``None``)-- used to compute the volume
		
		OUTPUT:
			A Boolean.
		"""
		if f is None:
			f = a.lf[i]
		l = [] # partition of this state
		for j in range(a.n_letters):
			k = a.succ(i, j)
			if k != -1:
				l.append(Polyhedron(rays = (a.alphabet[j] * a.states[k]).transpose()))
				if verb > 1:
					print("%s --%s--> %s" % (i, j, k))
					print(a.alphabet[j] * a.states[k])
		# check that it is a partition
		for p1 in l:
			for p2 in l:
				if p1 != p2:
					if p1.intersection(p2).dimension() == p1.dimension():
						if verb > 0:
							print("In state %s, two pieces intersect." % i)
						if verb > 1:
							print("p1 = ")
							print(matrix(p1.rays()).transpose())
							print("p2 = ")
							print(matrix(p2.rays()).transpose())
							print("p1 inter p2 = ")
							print(matrix(p1.intersection(p2).rays()).transpose())
						return False
		p2 = Polyhedron(rays = a.states[i].transpose())
		# Compute convex hull of all pieces instead of union
		all_rays = []
		vol = 0
		for p3 in l:
			all_rays.extend(p3.rays())
			vol += polytope_volume(matrix(p3.rays()).transpose(), f=f)
		p = Polyhedron(rays=all_rays)
		if p != p2:
			if verb > 0:
				print("The union in state %s does not equals the polytope of the state." % i)
			if verb > 1:
				print("p=")
				print(p)
				print("p2=")
				print(p2)
				print('p vertices:')
				print(p.vertices())
				print('p2 vertices:')
				print(p2.vertices())
				return p
			return False
		vol2 = polytope_volume(a.states[i], f=f)
		if vol != vol2:
			if verb:
				print("In state %s, the sum of volumes %s is not equal to the volume %s of the polytope." % (i, vol, vol2))
			return False
		return True

	def check_partition(a, lf=None, verb=0):
		"""
		Check that the polytope graph is correct.
		
		INPUT:
			- ``lf`` - list of linear forms (default: ``None``) -- linear form used for each state to compute volume and split
		"""
		if lf is None:
			lf = a.lf
		for i in range(a.n_states):
			if not a.check_state_partition(i, f=lf[i], verb=verb):
				return False
		return True
	
	def dim(a):
		"""
		Return the number of dimensions (projective dimension is d-1)
		"""
		if is_Matrix(a.states[0]):
			return a.states[0].nrows()
		else:
			return a.states[0][0].nrows()
	
	def state_partition(a, i, niter=1):
		"""
		Compute the partition for state i following niter edges.
		"""
		d = a.dim()
		to_see = [(i, identity_matrix(d), niter)]
		res = []
		while to_see:
			i, m, n = to_see.pop()
			if n == 0:
				m2 = a.states[i]
				if not is_Matrix(m2):
					m2, _ = a.states[i]
				res.append((m*m2, i))
			else:
				for j in range(a.n_letters):
					k = a.succ(i, j)
					if k != -1:
						m2 = m*a.alphabet[j]
						to_see.append((k, m2, n-1))
		return res
	
	def plot_state_partition(a, i, niter=1, f=None, colors='Set2'):
		"""
		Plot the partition for state i following paths of niter edges.
		
		INPUT:
			- ``i`` - int -- index of the state
			- ``f`` - linear form (default: ``None``) - used to plot this state
			- ``niter`` - int (default: ``1``) -- length of paths
			- ``colors`` - str or list (default: ``Set2``) -- colors used to plot the partition. See matplotlib.cm.__dict__.keys() for the list of possible str.
		"""
		dark = is_dark_mode()
		if dark == 1:
			color = 'white'
		elif dark == 2:
			color = '#808080'
		else:
			color = 'black'
		if f is None:
			f = a.lf[i]
		
		p = a.state_partition(i, niter, f=f)
		
		if isinstance(colors, str):
			from matplotlib import cm
			if colors not in cm.datad:
				raise ValueError("Color map %s is unknown. See matplotlib.cm.__dict__.keys() for the list of possibilities." % colors)
			cols = cm.__dict__[colors]
			colors = []
			for j in range(len(p)):
				colors.append(cols(float(j)/float(len(p)))[:3])

		g = plot_poly(a.states[i])
		for j,(m, i) in enumerate(p):
			g += plot_poly(m, f=f, fill=1, color=colors[j], text=0)
		if a.states[0].nrows() < 4:
			g.axes(0)
		return g
	
	def plot_state_partition2(a, i, niter=1, f=None, colors='Set2'):
		"""
		Plot the partition for state i following niter edges.
		
		INPUT:
			- ``i`` - int -- index of the state
			- ``f`` - linear form (default: ``None``) - used to plot this state
			- ``niter`` - int (default: ``1``) -- length of paths
			- ``colors`` - str or list (default: ``Set2``) -- colors used to plot the partition. See matplotlib.cm.__dict__.keys() for the list of possible str.
		"""
		dark = is_dark_mode()
		if dark == 1:
			color = 'white'
		elif dark == 2:
			color = '#808080'
		else:
			color = 'black'
		if f is None:
			f = a.lf[i]
		
		if isinstance(colors, str):
			from matplotlib import cm
			if colors not in cm.datad:
				raise ValueError("Color map %s is unknown. See matplotlib.cm.__dict__.keys() for the list of possibilities." % colors)
			cols = cm.__dict__[colors]
			colors = []
			for j in range(a.n_states):
				colors.append(cols(float(j)/float(a.n_states))[:3])

		m = a.states[i]
		if not is_Matrix(m):
			m, _ = a.states[i]
		g = plot_poly(m, f=f)
		
		d = a.dim()
		to_see = [(i, identity_matrix(d), niter)]
		while to_see:
			i, m, n = to_see.pop()
			if n == 0:
				m2 = a.states[i]
				if not is_Matrix(m2):
					m2, _ = a.states[i]
				g += plot_poly(m*m2, f=f, fill=1, color=colors[i], text=0)
			else:
				for j in range(a.n_letters):
					k = a.succ(i, j)
					if k != -1:
						m2 = m*a.alphabet[j]
						to_see.append((k, m2, n-1))
		
		if d < 4:
			g.axes(0)
		return g
	
	def plot_state(a, i, face = None, f=None, colors='Set2', verb = 0):
		"""
		Plot the state of the polytope graph, with decomposition given by outgoing edges.
	
		INPUT:
			``a`` : a :class:`DetAutomaton`
			``i`` : index of the state
			``colors`` : str or list (default: ``Set2``) -- colors used to plot the partition. See matplotlib.cm.__dict__.keys() for the list of possible str.
			- ``f`` - linear form (default: ``None``) - used to plot this state

		OUTPUT:
			A Graphics object.

		EXAMPLES::
			sage: from polytope_graph import *
			sage: a = PolytopeGraph(dag.Cassaigne())
			sage: a.plot_state(0)
			Graphics object consisting of 6 graphics primitives
		"""
		if f is None:
			f = a.lf[i]
		if verb:
			print("use linear form %s to plot state %s" % (f, i))
		dark = is_dark_mode()
		if dark == 1:
			color = 'white'
		elif dark == 2:
			color = '#808080'
		else:
			color = 'black'
		if isinstance(colors, str):
			from matplotlib import cm
			if colors not in cm.datad:
				raise ValueError("Color map %s is unknown. See matplotlib.cm.__dict__.keys() for the list of possibilities." % colors)
			cols = cm.__dict__[colors]
			colors = []
			for j in range(a.n_letters):
				colors.append(cols(float(j)/float(a.n_letters))[:3])
			
		m = a.states[i]
		if not is_Matrix(m):
			if face is None:
				m, face = a.states[i]
			else:
				m, _ = a.states[i]
		if verb > 1:
			print("print polytope of state:")
			print(m)
		g = plot_poly(m, f=f)
		for j in range(a.n_letters):
			k = a.succ(i, j)
			if k != -1:
				m2 = a.states[k]
				if not is_Matrix(m2):
					m2, _ = a.states[k]
				m = a.alphabet[j]*m2
				if verb > 1:
					print(m)
					print()
				g += plot_poly(m, f=f, fill=1, color=colors[j], text=0)
		if face is not None:
			if face.ncols() == 1:
				g += circle(proj_to_pt(face.columns()[0], f=f), .01, fill=1, thickness=4, color=color)
			else:
				g += plot_poly(face, f=f, thickness=5, text=False, color=color)
		if a.dim() < 4:
			g.axes(0)
		return g
	
	def dot(a, file="a.dot", colors='Set2', lf=None, size=(10., 8.), verb = 0):
		"""
		Save a dot file and images for each state that allows to plot the polytope graph with dot command.
	
		INPUT:
			- ``file`` - str -- the file used to save the dot code
			- ``colors`` - str or list of colors used to plot the partition -- see matplotlib.cm.__dict__.keys() for the list of possible str.
			- ``lf`` - list of linear form (default: ``None``) -- used to plot each state
		"""
		if lf is None:
			lf = a.lf
		dark = is_dark_mode()
		for i in range(a.n_states):
			g = a.plot_state(i, f=lf[i], colors=colors, verb=verb)
			g.save(str(i)+".png")
		txt = 'digraph Automaton {\n'
		if dark == 1:
			#txt += '	bgcolor="#181818";\n\n'
			txt += '	bgcolor="#000000";\n\n'
			txt += '	node [fontsize=20, fontcolor = "#FFFFFF", style = filled, color = "#FFFFFF", fillcolor = "#333333"];\n'
			txt += '	edge [fontsize=20, arrowhead=open, color = "#FFFFFF", fontcolor = "#FFFFFF"];\n'
		elif dark == 2:
			txt += '	bgcolor="transparent";\n\n'
			txt += '	node [fontsize=20, fontcolor = "#808080", style = filled, color = "#808080", fillcolor = "#333333"];\n'
			txt += '	edge [fontsize=20, arrowhead=open, color = "#808080", fontcolor = "#808080"];\n'
		else:
			txt += '	node[fontsize=20];\n'
			txt += '	edge[fontsize=20, arrowhead=open];\n'
		txt += '	rankdir=LR;\n'
		txt += '	size="%s, %s";\n' % size
		txt += '	center=1;\n'
		txt += '	nodesep=1.5;\n'
		txt += '	ranksep=2.0;\n'
		txt += '	splines=true;\n'
		#
		if isinstance(colors, str):
			from matplotlib import cm
			if colors not in cm.datad:
				raise ValueError("Color map %s is unknown. See matplotlib.cm.__dict__.keys() for the list of possibilities." % colors)
			cols = cm.__dict__[colors]
			colors = []
			for j in range(a.n_letters):
				colors.append(cols(float(j)/float(a.n_letters))[:3])
		#
		for i in range(a.n_states):
			txt +=str(i)+' [shape=none, style=solid, image="'+str(i)+'.png", fontsize=20, margin=0]\n'
			for j in range(a.n_letters):
				k = a.succ(i, j)
				if k != -1:
					if colors is None:
						txt += '%s -> %s [label="%s"]\n' % (i, k, a.alphabet[j])
					else:
						txt += '%s -> %s [label="%s", color="%s", fontcolor="%s"]\n' % (i, k, a.alphabet[j], color_to_html(colors[j]), color_to_html(colors[j]))
		txt += '}'
		with open(file, "w") as f:
			f.write(txt)
		
	def plot(a, file="a.dot", colors='Set2', lf = None, size=(10., 8.), verb = 0):
		"""
		plot the polytope graph
		
		
		INPUT:
			- ``file`` - str -- the file used to save the dot code
			- ``colors`` - str or list of colors used to plot the partition -- see matplotlib.cm.__dict__.keys() for the list of possible str.
			- ``lf`` - list of linear form (default: ``None``) -- used to plot each state
		"""
		a.dot(file=file, colors=colors, lf=lf, size=size, verb=verb)
		#import subprocess
		#subprocess.run("dot", "-Tpdf", file, ">", "a.png")
		import os
		os.system("dot -Tpng %s > %s" % (file, "a.png"))
		from badic.cautomata import png_to_display
		return png_to_display("a.png")
	
	def faces(a, i, max_dim=None):
		"""
		Return all faces of any dimension of the polytope for the vertex i
		"""
		if max_dim is None:
			max_dim = a.states[0].nrows()
		p = Polyhedron(rays = a.states[i].transpose())
		return [order_matrix(matrix(p2.rays()).transpose()) for p2 in p.face_generator() if p2.dimension() > 0 and p2.dimension() <= max_dim]
	
	def face_intersections(a, i, face):
		"""
		Check which edges have images that intersect the given face.
		
		INPUT:
			a : a DetAutomaton
			i : index of the state
			face : a face matrix from faces(a, i)
		
		OUTPUT:
			List of tuples (j, k) where j is the letter and k is the resulting state
			for edges where M(j)*a[k] intersects with the face
		"""
		# Create polyhedron for the state
		p_face = Polyhedron(rays=face.transpose())
		
		intersecting_edges = []
		
		for j in range(a.n_letters):
			k = a.succ(i, j)
			if k != -1:
				# Compute M(j)*a[k]
				m_image = a.alphabet[j] * a.states[k]
				
				# Create polyhedron for the image
				p_image = Polyhedron(rays=m_image.transpose())
				
				# Check the intersection
				intersection = p_face.intersection(p_image)
				
				if intersection.dimension() == p_face.dimension():
					m = order_matrix(a.alphabet[j].inverse()*matrix(intersection.rays()).transpose())
					intersecting_edges.append((j, k, m))
		
		return intersecting_edges
	
	def degenerate_subgraph(a, i=None, face=None, check=1, getl=0, verb=0):
		"""
		Return the degenerate subgraph corresponding to face of vertex i
		
		INPUT:
			- ``i`` - int (default: ``None``) -- index of the vertex. If ``i`` and ``face`` are None, compute the whole degenerate graph.
			- ``face`` - matrix (default: ``None``) -- face of the polytope of vertex i. If ``i`` and ``face`` are None, compute the whole degenerate graph.
		
		OUTPUT:
			A PolytopeGraph.
		
		EXAMPLES::
			sage: from polytope_graph import *
			sage: a = PolytopeGraph(rauzy_graph(("ABC", "CBA")))
			sage: a.degenerate_subgraph()
			PolytopeGraph of dimension 3, with 9 vertices and 12 edges

			sage: a.degenerate_subgraph(0, matrix([[1],[0],[0]]))
			PolytopeGraph of dimension 3, with 2 vertices and 2 edges

			sage: a = PolytopeGraph(rauzy_graph(("ABCD", "DCBA")))
			sage: a.degenerate_subgraph()
			PolytopeGraph of dimension 4, with 70 vertices and 98 edges
			
			sage: rg = rauzy_polytope_graph2(("ABC", "CBA"))
			sage: rg.degenerate_subgraph()
			PolytopeGraph of dimension 3, with 10 vertices and 12 edges
		"""
		if i is None or face is None:
			if i is not None or face is not None:
				raise ValueError("You must give the vertex and the face, or give nothing.")
			d = a.dim()
			to_see = []
			lv = []
			dlv = {}
			for i in range(a.n_states):
				for face in a.faces(i, max_dim=d-2):
					face.set_immutable()
					dlv[(i, face)] = len(to_see)
					to_see.append((i,face))
					lv.append((i, face))
		else:
			if check:
				# check that face is indeed a face
				m = a.states[i]
				if not is_Matrix(m):
					m = m[0]
				for r in face.columns():
					if r not in m.columns():
						warnings.warn("%s\nis not a face of state %s" % (face, i))
			face.set_immutable()
			to_see = [(i,face)]
			lv = [(i, face)]
			dlv = {(i, face): 0}
		#seen = set(to_see)
		R = []
		while to_see:
			i, face = to_see.pop()
			ii = dlv[(i, face)]
			for j, k, face2 in a.face_intersections(i, face):
				face2.set_immutable()
				v2 = (k, face2)
				if v2 not in dlv:
					to_see.append(v2)
					dlv[v2] = len(lv)
					lv.append(v2)
				i2 = dlv[v2]
				if verb > 1:
					print("edge %s --> %s" % (ii, i2))
				R.append((ii, i2, a.alphabet[j]))
		lv = [(a.states[i], F) for i,F in lv]
		if getl:
			return lv, R
		return PolytopeGraph(lv, R)

	def Fougeron_Coulbois_criterion(b, verb=0):
		"""
		Check if the PolytopeGraph satisfies the Coulbois-Fougeron's criterion.
		This criterion implies the existence of a unique invariant ergodic measure absolutely continuous with respect to Lebesgue.
		
		OUTPUT:
			A boolean.
		
		EXAMPLES::
			sage: from polytope_graph import *
			sage: a = PolytopeGraph(rauzy_graph(("ABC", "CBA")))
			sage: a.Fougeron_Coulbois_criterion()
			True

			sage: a = PolytopeGraph(rauzy_graph(("ABCD", "DCBA")))
			sage: a.Fougeron_Coulbois_criterion()
			False
		"""
		dg = b.degenerate_subgraph()
		return dg.Fougeron_Coulbois_criterion_for_subgraph(verb)		
	
	def Fougeron_Coulbois_criterion_for_subgraph(b2, verb=0):
		for c in b2.strongly_connected_components():
			if verb > 1:
				print(c)
			a = b2.sub_automaton(c)
			for i in range(a.n_states):
				idx = 0
				if len(a.succs(i)) > 1:
					if verb > 1:
						print("several outgoing edges from state %s" % c[i])
					for j in range(a.n_letters):
						k = a.succ(i,j)
						if k != -1:
							F = Polyhedron(rays = a.states[i][1].columns())
							fPv = Polyhedron(rays = (a.alphabet[j] * a.states[k][0]).columns())
							Pw = Polyhedron(rays = a.states[i][0].columns())
		
							li = fPv.inequalities()
							for ineq in li:
								if verb > 1:
									print('check inequality %s' % ineq)
								# check that F satisfies this inequality
								for r in F.rays():
									if ineq*r < 0:
										break
								else:
									# check that at least one point of Pw satisfies the inequality
									for r in Pw.rays():
										if ineq*r > 0:
											break
									else:
										continue
									# check that at least one point of Pw does not satisfies the inequality
									for r in Pw.rays():
										if ineq*r < 0:
											idx += 1
											break
									else:
										continue
									break
				if idx > 1:
					if verb > 0:
						print("State %s does not satisfies the criterion" % c[i])
					return False
		return True
	
	def dual(a):
		"""
		Try to find the dual algorithm, where edges are reversed and matrices are transposed
		"""
		lm = a.find_invariant_polyhedra()
		return PolytopeGraph(lm, [(k,i,m.transpose()) for i,k,m in a.edges()])

	def subgraph(a, c, verb=0):
		"""
		Return the subgraph corresponding to set of vertices c.
		
		INPUT:
			- ``c`` - list of int -- list of indices of vertices to keep

		OUTPUT:
			A PolytopeGraph.

		EXAMPLES::
			sage: from polytope_graph import *
			sage: rg = rauzy_graph(("ABC", "CBA"))
			sage: a = PolytopeGraph(rg)
			sage: a.subgraph([0,1])
			PolytopeGraph of dimension 3, with 2 vertices and 3 edges
		"""
		a2 = a.sub_automaton(c)
		if verb > 0:
			print(a2)
		p = PolytopeGraph(a2, nochange=1)
		if verb > 0:
			print(p)
		#p.set_states([lm[i] for i in c])
		p.lf = [a.lf[i] for i in c]
		return p

	def base_change(a, lP, lf=None, check=1, verb=0):
		"""
		Return a new PolytopeGraph where we change basis of vertices.
		It allows to change the ways the polytopes are represented, without changing the continued fraction algorithm.
		
		INPUT:
			- ``lP`` - list of matrix -- matrices of base change for each state
		
		OUTPUT:
			A PolytopeGraph.
		"""
		lm = [P*m for (P,m) in zip(lP, a.states)]
		le = [(i, k, lP[i]*m*lP[k].inverse()) for i,k,m in a.edges()]
		if lf is None:
			lf = a.lf
			for i,f in enumerate(a.lf):
				if f is not None:
					lf[i] = f*lP[i].inverse()
		return PolytopeGraph(lm, le, lf=lf, check=check, verb=verb)

	def python_code(a):
		"""
		Return a Sagemath code allowing to define a.
		"""
		res = ""
		for i,m in enumerate(a.states):
			res += "s%s = matrix([" % i
			for j,l in enumerate(m):
				res += str(l)
				if j != m.nrows()-1:
					res += ", "
			res += "])\n"
		for j,m in enumerate(a.alphabet):
			res += "m%s = matrix([" % j
			for i,l in enumerate(m):
				res += str(l)
				if i != m.nrows()-1:
					res += ", "
			res += "])\n"
		res += "PolytopeGraph(["
		for i in range(a.n_states):
			res += "s%s" % i
			if i != a.n_states-1:
				res += ", "
		res += "], ["
		first = True
		for i in range(a.n_states):
			for j in range(a.n_letters):
				k = a.succ(i, j)
				if k != -1:
					if not first:
						res += ", "
					res += "(%s, %s, m%s)" % (i,k,j)
					first = False
		res += "])"
		return res
	
