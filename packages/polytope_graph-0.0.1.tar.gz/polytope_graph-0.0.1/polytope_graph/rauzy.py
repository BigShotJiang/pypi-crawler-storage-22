from sage.groups.perm_gps.permgroup_named import SymmetricGroup
from sage.modules.free_module_element import zero_vector
from sage.matrix.constructor import matrix
from sage.matrix.special import identity_matrix
from sage.geometry.polyhedron.all import Polyhedron
from copy import copy
from badic import *
from .polytope_graph import PolytopeGraph
from sage.misc.prandom import shuffle

A = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

def T(i,j,d):
	"""
	Returns the transvection (i,j) with dimension d.
	"""
	m = identity_matrix(d)
	m[i,j] = 1
	return m

def induce1(e, top=0):
	e = list(e)
	if top:
		i = 0
		j = 1
	else:
		i = 1
		j = 0
	l = e[j][-1] # loosing letter
	k = e[j].index(e[i][-1])+1
	e[j] = "%s%s%s" % (e[j][:k], e[j][-1], e[j][k:-1])
	return tuple(e), l

def is_irreducible(e):
	"""
	Test if state e of Rauzy graph is irreducible.
	"""
	for i in range(1, len(e[0])):
		if set(e[0][:i]) == set(e[1][:i]):
			return False
	return True

def rauzy_graph(e, tuples=0, get_list=0, verb=0):
	"""
	Returns the Rauzy graph.
	
	INPUT:
		- ``e`` - a couple -- state from which we compute the strongly connected component
		- ``tuples`` - int (default: ``0``) -- if not 0, put couples as states, otherwise put it as str
	
	OUTPUT:
		Return the Rauzy graph as DetAutomaton.

	EXAMPLES::
		sage: from polytope_graph import *
		sage: rauzy_graph(("ABC", "CBA"))
		DetAutomaton with 3 states and an alphabet of 3 letters
	"""
	to_see = [e]
	if verb > 0:
		print(to_see)
	seen = set(to_see)
	res = []
	states = ["%s\n%s" % e]
	while to_see:
		e = to_see.pop()
		for t in range(2):
			f, l = induce1(e, t)
			if f not in seen:
				seen.add(f)
				to_see.append(f)
				states.append("%s\n%s" % f)
			if tuples:
				res.append((e,l,f))
			else:
				res.append(("%s\n%s"%e,l,"%s\n%s"%f))
	if get_list:
		return res
	return DetAutomaton(res, A=list(A[:rauzy_nletters(e)]), S=states, avoidDiGraph=1)

def rauzy_state_tuple(e):
	if isinstance(e, str):
		d = len(e)//2
		return (e[:d], e[d+1:])
	return e

def rauzy_nletters(e):
	if isinstance(e, str):
		return len(e)//2
	return len(e[0])

def rauzy_state_to_tuple(e):
	e = rauzy_state_tuple(e)
	return tuple(e[1].index(e[0][i]) for i in range(len(e[0])))

def permutation_to_rauzy_state(p, d):
	return (A[:d], ''.join([p(a) for a in A[:d]]))

def rauzy_graphs(d, verb=0):
	"""
	Compute the list of classes of Rauzy graphs with d letters.
	
	INPUT:
		- ``d`` - int -- number of letters

	OUTPUT:
		Return a list of Rauzy graphs as DetAutomaton.
	
	EXAMPLES::
		sage: from polytope_graph import *
		sage: rauzy_graphs(4)
		[DetAutomaton with 12 states and an alphabet of 4 letters,
		 DetAutomaton with 7 states and an alphabet of 4 letters]
	"""
	lg = []
	G = SymmetricGroup(list(A[:d]))
	seen = set()
	for p in G:
		e = permutation_to_rauzy_state(p, d)
		t = rauzy_state_to_tuple(e)
		if is_irreducible(e) and t not in seen:
			if verb:
				print(e)
			g = rauzy_graph(e)
			lg.append(g)
			for e in g.states:
				seen.add(rauzy_state_to_tuple(e))
	return lg

def rauzy_state_matrix(e):
	"""
	Return the matrix giving coordinates b_1, ..., b_{2(d-1)} from tau_1, ..., tau_d
	"""
	if isinstance(e, str):
		d = len(e)//2
		e = (e[:d], e[d+1:])
	M = []
	d = len(e[0])
	for i in range(2):
		v = zero_vector(d)
		for l in e[i][:-1]:
			v[A.index(l)] = (-1)**i
			M.append(copy(v))
	return matrix(M)

def rauzy_state_polytope(e):
	"""
	Return the polytope associated to this Rauzy state in dimension 2(d-1).
	
	OUTPUT:
		A matrix.
	"""
	M = rauzy_state_matrix(e)
	Id = identity_matrix(M.nrows())
	p = Polyhedron(ieqs = [[0]+list(v) for v in Id], eqns = [[0]+list(v) for v in M.kernel().basis()])
	return matrix(p.rays()).transpose()

def rauzy_state_polytope2(e):
	"""
	Return the polytope associated to this Rauzy state with tau coordinates.
	
	OUTPUT:
		A matrix.
	"""
	M = rauzy_state_matrix(e)
	p = Polyhedron(ieqs = [[0]+list(v) for v in M])
	return matrix(p.rays()).transpose()

def choose_base(m, rand=1):
	"""
	Choose a base for the polytope of matrix m.
	"""
	B = []
	l = list(m.columns())
	if rand:
		shuffle(l)
	for v in l:
		if v not in matrix(B).image():
			B.append(v)
	return matrix(B).transpose()

def change_of_base(m, B, M, verb=0):
	"""
	Return a matrix giving coordinates in base B of the image of m from tau coordinates,
	and the polytope m in these coordinates.
	"""
	# complete to a base of the whole space
	E = m.transpose().image()
	mc = matrix(B.columns() + E.complement().basis()).transpose()
	# invert it
	Bi = mc.inverse()
	if verb > 0:
		print(Bi*B)
	# take the submatrix
	d = B.ncols()
	Bi = Bi.submatrix(nrows=d)
	# matrix of change of basis
	return Bi*M, Bi*m

# convert the rauzy graph to a PolytopeGraph
def rauzy_to_polytope_graph(rg, rand=1, check=1, verb=0):
	if not rg.is_strongly_connected():
		raise ValueError("The PolytopeGraph must be strongly connected.")
	# choose base for each state
	lP = [] # list of matrix of basis change
	lm = [] # list of polytopes of states
	for i in range(rg.n_states):
		e = rg.states[i]
		M = rauzy_state_matrix(e)
		m = rauzy_state_polytope(e)
		B = choose_base(m, rand=rand)
		P,m = change_of_base(m, B, M)
		lm.append(m)
		lP.append(P)
	if verb > 1:
		print("list of change of basis:")
		print(lP)
		print("list of polytopes of states:")
		print(lm)
	# browse the graph
	to_see = [0]
	seen = set(to_see)
	res = []
	d = lP[0].nrows()
	while to_see:
		i = to_see.pop()
		ll = [j for j in range(rg.n_letters) if rg.succ(i, j) != -1]
		assert(len(ll) == 2)
		a = A.index(rg.alphabet[ll[0]]) # index of letter of first edge
		b = A.index(rg.alphabet[ll[1]]) # index of letter of second edge
		lT = [T(b,a,d).inverse(), T(a,b,d).inverse()] # transposition matrices, action on tau
		for j, t in zip(ll, lT):
			k = rg.succ(i, j)
			if k not in seen:
				seen.add(k)
				to_see.append(k)
			res.append((k, i, lP[k]*t*lP[i].inverse()))
	return PolytopeGraph(lm, res, check=check, verb=verb)

# convert the rauzy graph to a PolytopeGraph
def rauzy_to_polytope_graph2(rg, check=1, verb=0):
	if not rg.is_strongly_connected():
		raise ValueError("The PolytopeGraph must be strongly connected.")
	# browse the graph
	to_see = [0]
	seen = set(to_see)
	res = []
	d = len(rg.states[0])//2
	if verb > 0:
		print("d =",d)
	lm = [rauzy_state_polytope2(e) for e in rg.states]
	if verb > 0:
		print("lm =")
		print(lm)
	while to_see:
		i = to_see.pop()
		ll = [j for j in range(rg.n_letters) if rg.succ(i, j) != -1]
		assert(len(ll) == 2)
		a = A.index(rg.alphabet[ll[0]]) # index of letter of first edge
		b = A.index(rg.alphabet[ll[1]]) # index of letter of second edge
		lT = [T(b,a,d).inverse(), T(a,b,d).inverse()] # transposition matrices, action on tau
		for j, t in zip(ll, lT):
			k = rg.succ(i, j)
			if k not in seen:
				seen.add(k)
				to_see.append(k)
			res.append((k, i, t))
	return PolytopeGraph(lm, res, check=check, verb=verb)

def rauzy_polytope_graph(e, rand=1, check=1, verb=0):
	"""
	Return the Rauzy graph as a PolytopeGraph from state e.

	EXAMPLES::
		sage: from polytope_graph import *
		sage: rauzy_polytope_graph(("ABC", "CBA"))
		PolytopeGraph of dimension 3, with 3 vertices and 6 edges
	"""
	return rauzy_to_polytope_graph(rauzy_graph(e), rand=rand, check=check, verb=verb)

def rauzy_polytope_graph2(e, check=1, verb=0):
	"""
	Return the Rauzy graph as a PolytopeGraph from state e.

	EXAMPLES::
		sage: from polytope_graph import *
		sage: rauzy_polytope_graph2(("ABC", "CBA"))
		PolytopeGraph of dimension 3, with 3 vertices and 6 edges
	"""
	return rauzy_to_polytope_graph2(rauzy_graph(e), check=check, verb=verb)

