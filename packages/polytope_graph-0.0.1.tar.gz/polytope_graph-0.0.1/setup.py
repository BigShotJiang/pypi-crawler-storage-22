## -*- encoding: utf-8 -*-
import os
import sys
from setuptools import setup
from codecs import open # To open the README file with proper encoding
#from setuptools.command.test import test as TestCommand # for tests
from distutils.command.build_ext import build_ext as _build_ext

from setuptools.extension import Extension

# Get information from separate files (README, VERSION)
def readfile(filename):
    with open(filename,  encoding='utf-8') as f:
        return f.read()

class build_ext(_build_ext):
    def finalize_options(self):
        import subprocess
        from Cython.Build import cythonize
        import json

        # run the configure script
        subprocess.check_call(["make", "configure"])
        try:
            subprocess.check_call(["sh", "./configure"])
        except subprocess.CalledProcessError:
            subprocess.check_call(["cat", "config.log"])

        # configure created config.json that we can no read
        config = json.load(open("./config.json"))

        self.distribution.ext_modules[:] = cythonize(
            self.distribution.ext_modules, include_path=sys.path)
        _build_ext.finalize_options(self)

# For the tests
#class SageTest(TestCommand):
#    def run_tests(self):
#        errno = os.system("sage -t --force-lib eigenmorphic")
#        if errno != 0:
#            sys.exit(1)



# Source - https://stackoverflow.com/a/53069528
# Posted by hayj, modified by community. See post 'Timeline' for change history
# Retrieved 2026-02-02, License - CC BY-SA 4.0
import os
lib_folder = os.path.dirname(os.path.realpath(__file__))
requirement_path = f"{lib_folder}/requirements.txt"
install_requires = [] # Here we'll add: ["gunicorn", "docutils>=0.3", "lxml==0.5a7"]
if os.path.isfile(requirement_path):
    with open(requirement_path) as f:
        install_requires = f.read().splitlines()

setup(
    name = "polytope_graph",
    version = readfile("VERSION"), # the VERSION file is shared with the documentation
    description='Polytope graphs in Sagemath',
    long_description = readfile("README.md"), # get the long description from the README
    long_description_content_type = 'text/markdown',
    url='https://gitlab.com/davidsiukaev/polytopegraphs-in-sagemath',
    author='Paul Mercat and David Siukaev',
    author_email='paul.mercat@univ-amu.fr', # choose a main contact email
    license='GPL-3.0-or-later', # This should be consistent with the LICENCE file
    keywords = "Polytope graphs in SageMath",
    packages = ['polytope_graph'],
    install_requires=install_requires
    #cmdclass = { 'test': SageTest}, # adding a special setup command for tests
)

