"""Pomera AI Commander - Text processing toolkit with MCP tools for AI assistants."""
from pomera.version import __version__

__all__ = ["__version__"]
