# Development Slash Commands

These are slash commands used for **developing Pongogo itself**. They are NOT distributed to users.

For the commands that ship to users via `pongogo init`, see `seed/skills.jsonl` and [wiki/Slash-Commands.md](../../wiki/Slash-Commands.md).

## MCP Server Control

Commands for controlling the knowledge routing MCP server during development. See the [three-state model](../../.pongogo/instructions/architecture/pongogo_slash_commands.instructions.md) for details.

| Command | Description |
|---------|-------------|
| `/pongogo-enable` | Enable production mode (routing + read-write) |
| `/pongogo-disable` | Disable to baseline mode (no routing, for A/B testing) |
| `/pongogo-simulate-enable` | Enable testing mode (routing + read-only protection) |
| `/pongogo-simulate-disable` | Return to production mode from simulate |
| `/pongogo-dry-run` | Test routing without state change or logging |
| `/pongogo-status` | Quick health check |
| `/pongogo-reindex` | Force knowledge base reindex |
| `/pongogo-switch-engine` | Switch routing engine version or list available engines |
| `/pongogo-config` | View and edit Pongogo preferences |

## Workflow

Commands for development productivity — learning loops, work logging, session management.

| Command | Description |
|---------|-------------|
| `/conduct-learning-loop` | Execute full 4-step learning loop (ANALYZE → EXTRACT → CODIFY → DOCUMENT) |
| `/add-work-log-entry` | Add structured entry to the project work log |
| `/stash-work` | Save current work state for later resume |
| `/pick-up-work` | Resume previously stashed work with context validation |

## Maintenance

Repository housekeeping tools.

| Command | Description |
|---------|-------------|
| `/pongogo-prune-instructions` | Audit and prune instruction files |
| `/pongogo-prune-open-issues` | Triage and prune open GitHub issues |
