---
description: Add structured work log entry to current month's work log
---

# Add Work Log Entry

You are being asked to add a structured work log entry following Pongogo's work log standards.

**IMPORTANT**: Follow these guidelines:
- `docs/processes/work_log_policy.md` - Policy for work log maintenance, update frequency, amendment procedures
- `knowledge/instructions/pongogo/project_management/work_logging.instructions.md` - Complete work logging guidance including two-level learning framework

**Command Usage**:
- Interactive: `/add-work-log-entry` (then answer questions)
- With text: `/add-work-log-entry [your entry description here]`

## Step 0: Check for Arguments

**If user provided text after the command** (e.g., `/add-work-log-entry an entry about X`):
1. Infer the entry type from the text:
   - Contains "decision", "chose", "selected" → Decision
   - Contains "learned", "discovered", "pattern" → Learning
   - Contains "blocker", "blocked", "issue" → Blocker
   - Contains "completed", "finished", "done" → Completion
   - Contains "starting", "beginning", "resuming" → Session Start
   - Otherwise → Ask user to clarify type
2. Use the provided text as the entry content/description
3. Prompt for any missing critical details (evidence, rationale, etc.)
4. Skip to Step 4 (Generate Entry)

**If no arguments provided**:
- Continue to Step 1 (interactive mode)

## Step 1: Identify Entry Type (Interactive Mode Only)

Ask the user:

**"What type of work log entry?"**

Options:
1. 🟢 **Session Start** - Beginning work on Task/Epic
2. 🔵 **Decision** - Key decision made
3. 🟠 **Blocker** - Obstacle encountered or resolved
4. 🟣 **Completion** - Task/Epic/Milestone complete
5. 🟡 **Learning** - Ah-ha moment or pattern discovered
6. ⚪ **Session End** - Brief progress summary

## Step 2: Load Entry Template

Based on user's selection, use the appropriate template:

### 🟢 Session Start
```markdown
### Session: [Brief Title]
**Category**: `session`

Starting work on [Task/Epic name]. [Brief context about what will be worked on]

**Goals for this session**:
- [Goal 1]
- [Goal 2]

**Context**: [Any relevant background or dependencies]
```

### 🔵 Decision
```markdown
### Decision: [Brief Title]
**Category**: `decision`

[Description of what decision was made]

**Context**: [Why this decision was needed]

**Options Considered**:
1. [Option 1]: [Brief description]
2. [Option 2]: [Brief description]

**Decision**: [What was chosen]

**Rationale**: [Why this option was chosen]

**Trade-offs**: [What was gained vs what was given up]

**Evidence**: [Commits, files, or references]

**Related**: [[Decision-Archive]] ([decision ID if applicable])
```

### 🟠 Blocker
```markdown
### Blocker: [Brief Title]
**Category**: `blocker`
**Status**: [Encountered/Resolved]

**Issue**: [Description of blocker]

**Impact**: [What work is blocked]

**Attempted Solutions**:
- [Attempt 1]
- [Attempt 2]

[If resolved:]
**Resolution**: [How it was resolved]
**Time Lost**: [Estimate of impact]
**Prevention**: [How to prevent in future]

**Evidence**: [Commits, files, or references]
```

### 🟣 Completion
```markdown
### [Task/Epic/Milestone]: [Name] ✅
**Category**: `[task|epic|milestone]`

[Summary of what was completed]

**Key Deliverables**:
- [Deliverable 1]
- [Deliverable 2]

**Metrics** (if applicable):
- [Metric 1]: [value]
- [Metric 2]: [value]

**Learnings**:
- [Learning 1]
- [Learning 2]

**Evidence**: [Commits, files, documents]

**Related**: [[Pattern-Library]], [[Strategic-Insights]], [[Retrospectives]]
```

### 🟡 Learning
```markdown
### Learning: [Brief Title]
**Category**: `learning`

[Description of what was learned]

**Context**: [Where this learning came from]

**Type**: [Technical/Process/Collaboration]

**Application**: [How this can be used in future]

**Frequency**: [Appeared X times / First occurrence]

**Related**: [[Pattern-Library]], [[Strategic-Insights]]
```

### ⚪ Session End
```markdown
### Session End: [Brief Summary]
**Category**: `session`

Completed [X hours/Y items] of work on [Task/Epic name].

**Progress**:
- ✅ [Completed item 1]
- ✅ [Completed item 2]
- 🔄 [In progress item]

**Next Session**:
- [ ] [Next item to work on]

**Blockers**: [Any blockers encountered, or "None"]
```

## Step 3: Gather Details from User

Based on the entry type, ask for:

**Session Start**:
- What are you working on?
- What are the goals for this session?

**Decision**:
- What decision was made?
- What options were considered?
- Why was this option chosen?
- What are the trade-offs?

**Blocker**:
- What is the blocker?
- What have you tried?
- [If resolved] How was it resolved?

**Completion**:
- What was completed?
- What were the key deliverables?
- Any metrics to capture?
- What did you learn?

**Learning**:
- What was learned?
- Where did this come from?
- How can it be applied?

**Session End**:
- What was accomplished?
- What's in progress?
- What's next?
- Any blockers?

## Step 4: Generate Entry

Create the work log entry with:
1. Clear title (with emoji indicator)
2. Appropriate category tag
3. All relevant details from user
4. Evidence links (commits, files, wiki pages)
5. Related wiki page cross-references

## Step 5: Add to Work Log

Determine current month's work log file: `wiki/Work-Log-YYYY-MM.md`

Insert entry at top of the date section (most recent first), creating new date section if needed:

```markdown
## [Month] [Day], [Year]

[New entry here]

---

[Previous entries...]
```

## Step 6: Confirm and Commit

Show user the entry and ask:

**"Entry added to work log. Should I commit this now?"**

If yes:
1. Stage `wiki/Work-Log-YYYY-MM.md`
2. Commit with message: "Add work log entry: [entry title]"
3. Push to wiki remote (if user confirms)

## Entry Type Guidance

### When to Use Each Type

**Session Start** 🟢:
- Beginning work on new Task or Epic
- Resuming work after break/diversion
- Starting new work day/session

**Decision** 🔵:
- Architecture choice made
- Approach selected between alternatives
- Process pivot decided
- Trade-off resolved

**Blocker** 🟠:
- Hit obstacle that stops progress
- Waiting on external dependency
- Technical issue encountered
- UPDATE when resolved with solution

**Completion** 🟣:
- Task fully complete
- Epic wrapped up
- Milestone reached
- Phase finished

**Learning** 🟡:
- Discovered new pattern
- Had ah-ha moment
- Learned from mistake
- Identified improvement

**Session End** ⚪:
- Wrapping up work session
- End of work day
- Context switch to different work

### Progressive Disclosure Pattern

Use work log entries throughout work:
1. **Start**: 🟢 Session Start (set context)
2. **During**: 🔵 Decisions, 🟠 Blockers, 🟡 Learnings (capture as they happen)
3. **End**: ⚪ Session End (summarize progress)
4. **Complete**: 🟣 Completion (comprehensive summary)

**Benefit**: Work log shows both journey (during) and destination (complete)

## Example Flows

### Example 1: Interactive Mode (No Arguments)

```
User invokes: /add-work-log-entry

Agent: "What type of work log entry?"
1. 🟢 Session Start
2. 🔵 Decision
[...options...]

User: "2 - Decision"

Agent: "Great! Let me gather the details for a decision entry.
       What decision was made?"

User: "We decided to simplify templates before using them in M2"

Agent: "What options did you consider?"

User: [provides options]

[Agent gathers all details...]

Agent: "Here's the work log entry I'll add:

### Decision: Template Simplification
**Category**: `decision`
[...complete entry...]

Should I add this to wiki/Work-Log-2025-10.md and commit?"

User: "Yes"

Agent: [Adds entry, commits, confirms]
```

### Example 2: With Arguments (Quick Entry)

```
User invokes: /add-work-log-entry learned that retrospectives should never be altered - add postscripts for new discoveries

Agent: "I see you want to add a learning entry. Let me create that for you.

### Learning: Retrospective Integrity Principle
**Category**: `learning`

Learned that retrospectives should never be altered - add postscripts for new discoveries instead.

**Context**: Discovered during [M##] → [Milestone] naming fix
**Type**: Process
**Application**: When subsequent issues found in retrospectives, add postscript sections rather than modifying original examples

Would you like me to add any additional details (evidence, frequency, related patterns)?"

User: "Add evidence: commit 588d4a6, related to Retrospective Integrity Principle"

Agent: [Updates entry, adds to work log]

"Entry added. Should I commit this?"
```

### Example 3: Ambiguous Text (Clarification Needed)

```
User invokes: /add-work-log-entry fixed the naming issue

Agent: "I see you want to log something about fixing a naming issue.
       Is this:
       1. 🟣 Completion - Task completed
       2. 🟡 Learning - Something learned
       3. 🔵 Decision - Decision made about approach

User: "1 - Completion"

Agent: [Creates completion entry with provided text as starting point]
```

## Tips for Quality Entries

1. **Be Specific**: "Updated 3 files" → "Updated trust_based_task_execution.instructions.md (22 refs removed)"
2. **Include Evidence**: Link commits, files, documents
3. **Capture Context**: Why this work matters
4. **Note Learnings**: What you discovered along the way
5. **Cross-Reference**: Link to wiki pages, patterns, decisions

## Validation

Before committing, check:
- [ ] Category tag present
- [ ] Title is descriptive
- [ ] Evidence links included (if applicable)
- [ ] Cross-references added (if applicable)
- [ ] Entry added to correct date section
- [ ] Most recent entry at top of date section

---

**Instruction Source**: `knowledge/instructions/pongogo/project_management/work_logging.instructions.md`

**Related**: Progressive Disclosure in Work Logs pattern (Strategic Insights)
