---
description: Conduct structured learning loop with appropriate scope for work type
---

# Conduct Learning Loop

You are being asked to conduct a structured learning loop following Pongogo's learning capture standards.

**IMPORTANT**: Follow these guidelines and reference documents:
- `docs/processes/learning_loop_workflow.md` - Complete workflow specification
- `docs/processes/retrospective_framework.md` - 4-question and 6-question retrospective frameworks with examples
- `docs/processes/learning_and_context_framework.md` - Complete Context Principle, learning triggers, 3+ instance rule, self-improving loop
- `docs/processes/work_log_policy.md` - Work log maintenance policy
- `knowledge/instructions/pongogo/process/process_learning_capture.instructions.md` - Pause point types and scope guidance
- `knowledge/instructions/pongogo/project_management/work_logging.instructions.md` - Two-level learning framework for work log entries

**Command Usage**:
- Interactive: `/conduct-learning-loop` (then answer questions)
- With type: `/conduct-learning-loop task` or `/conduct-learning-loop epic` or `/conduct-learning-loop milestone`
- With details: `/conduct-learning-loop task hello world mcp server` or `/conduct-learning-loop epic PM methodology`

Follow these steps:

## Step 0: Check for Arguments

**If user provided text after the command** (e.g., `/conduct-learning-loop task naming fixes`):
1. Parse the work type from first word:
   - "task" or "tasks" → Task Completion
   - "epic" or "epics" → Epic Completion
   - "milestone" or "m1" or "m2" etc. → Milestone Completion
   - "bug" or "bugfix" or "debugging" → Problem Solving / Bug Fix
   - "interrupt" or "diversion" or "divergence" → Unplanned Work Interrupt
   - Otherwise → Ask user to clarify
2. Use remaining text as context/name of what's being analyzed
3. Skip to Step 2 with identified pause point type

**If no arguments provided**:
- Continue to Step 1 (interactive mode)

## Step 1: Identify Pause Point Type (Interactive Mode Only)

Ask the user:

**"What type of work are we analyzing?"**

Options:
1. **Task Completion** (~hours to days of work)
2. **Epic Completion** (~1-2 weeks of work)
3. **Milestone Completion** (~1-3 months of work)
4. **Unplanned Work Interrupt** (context switch/diversion)
5. **Problem Solving / Bug Fix** (debugging session)

## Step 2: Load Appropriate Scope Guidance

Based on user's selection, apply the appropriate scope:

### For Task Completion:
**Scope**: Tactical workflow for THIS specific task
**Time Investment**: 5-10 min reflection
**Look for**:
- What worked/didn't work for THIS task
- Patterns that appeared 2-3+ times within task
- Tool/technique effectiveness
**Boundaries**: Don't generalize to all tasks, don't change project-wide processes

### For Epic Completion:
**Scope**: Workflow patterns across multiple related tasks
**Time Investment**: 30-60 min analysis
**Look for**:
- Patterns repeated across 3+ tasks within Epic
- Domain-specific improvements
- Cross-task coordination issues
**Boundaries**: Don't change unrelated domains, don't make platform changes

### For Milestone Completion:
**Scope**: Strategic process changes across multiple domains
**Time Investment**: 2-3 hours comprehensive retrospective
**Look for**:
- Patterns repeated across 5+ Epics or 10+ tasks
- Cross-domain improvements
- Platform/tooling gaps
- Meta-process improvements
**Can**: Make project-wide process changes, update core methodology

### For Unplanned Work Interrupt:
**Scope**: Document divergence and decision
**Time Investment**: 5-10 min work log entry
**Look for**:
- Why did we divert?
- What changed about planned work?
- Should we return or pivot?
**Boundaries**: Don't over-analyze, don't change process from single diversion

### For Problem Solving / Bug Fix:
**Scope**: Root cause and prevention
**Time Investment**: 5-10 min work log entry
**Look for**:
- Root cause
- What prevented earlier detection?
- Systematic prevention
**Boundaries**: Don't create overhead from single bug

## Step 3: Conduct Learning Analysis

Walk through this structure (adapt depth based on pause point type):

### A. What Was Accomplished?
- Summarize the work completed
- Reference specific commits, files, deliverables
- Include quantitative metrics if available

### B. What Worked Well? (with evidence)
- Identify 2-4 things that went well
- Provide specific evidence for each
- Note frequency of occurrence (appeared X times)

### C. What Could Be Improved? (with evidence)
- Identify 2-4 areas for improvement
- Provide specific evidence for each
- Estimate impact of improvement

### D. Patterns Observed
**Validation Check**: For each potential pattern, ask:
- Did this appear 3+ times within the work scope?
- If yes: Extract pattern with examples
- If no: Note for potential validation in larger scope

### E. Insights Gained
**Scope Check**: For each insight, validate:
- Task scope → Tactical insights only
- Epic scope → Domain-specific insights
- Milestone scope → Strategic/cross-domain insights

### F. Recommendations
- Immediate actions (if applicable)
- Future work considerations
- Process improvements to codify

## Step 4: Generate Retrospective Document

Create retrospective document at:
- Task: Work log entry in `wiki/Work-Log-YYYY-MM.md`
- Epic: Retrospective entry in `wiki/Retrospectives.md`
- Milestone: Full analysis in `docs/retrospectives/YYYY_MM_DD_milestone_name.md`

**Document Structure**:
```markdown
# [Type] Retrospective: [Name]

**Date**: YYYY-MM-DD
**Duration**: [time span]
**Scope**: [what was analyzed]

## What We Did
[Summary of work]

## What Worked Well
1. [Item with evidence]
2. [Item with evidence]

## What Could Be Improved
1. [Item with evidence]
2. [Item with evidence]

## Patterns Observed
[Only patterns that appeared 3+ times]

## Insights Gained
[Scoped appropriately to work type]

## Metrics
[Quantitative results if available]

## Recommendations
[Next steps]

## Evidence Trail
[Commits, files, documents]
```

## Step 5: EXTRACT Opportunities for Improvement

**Purpose**: Identify concrete improvements to implement

### First: Check Potential Improvements Tracking

**IMPORTANT**: Before extracting new opportunities, review existing potential improvements to see if current work provides validation evidence.

**Actions**:
1. **Review tracking file**: `docs/project_management/potential_improvements.md`
2. **Check for relevant candidates**: Did any pattern from current work match existing candidates?
3. **Update evidence if applicable**: If existing pattern appeared again, update PI-XXX file with new evidence
4. **Recalculate confidence**: Did evidence count reach threshold (3+ for MEDIUM, 5+ for HIGH)?
5. **Promote if ready**: If threshold reached, add to validated opportunities list for immediate implementation

**Quick Check**:
- PI-001: Archive with Comprehensive Context (currently 2/3) - did we archive anything?
- PI-002: Decision Criteria Before Action (currently 1/3) - did we do bulk operations?
- [Other active candidates...]

---

### Extract New Opportunities

Ask user to review analysis and identify:

### What Opportunities?

**Three Types**:
1. **Process Improvements** - Better workflows, updated instructions
2. **Platform Capabilities** - New tools, automation, metrics
3. **Knowledge Codification** - Patterns, insights, decisions

For each opportunity, determine:
- **Level**: Codebase / Process / Meta-Process
- **Priority**: P0 (blocking) / P1 (high value) / P2 (nice to have)
- **Effort**: Time estimate
- **Impact**: Expected benefit

### Validation Check

**Critical**: Apply 3+ occurrences threshold

```
For each improvement:
├─ Did this appear 3+ times within scope?
│  ├─ YES → Valid for extraction
│  └─ NO → Note for validation at higher scope
```

**Scope-Appropriate Extraction**:
- **Task**: Tactical improvements (3+ times in THIS task)
- **Epic**: Domain patterns (3+ tasks in THIS epic)
- **Milestone**: Strategic insights (5+ epics)

### Output

Create improvement list with:
- Validated opportunities (3+ occurrences)
- Categorized by level/priority/effort
- Deferred opportunities (note for validation)

---

## Step 6: CODIFY New Processes

**Purpose**: Implement improvements NOW (don't just document)

Walk through each validated improvement:

### For Process Improvements:

1. **Identify target file(s)**:
   - Instruction files: `knowledge/instructions/pongogo/`
   - Process guides: `docs/processes/`
   - Templates: `docs/templates/`

2. **Implement change**:
   - Add new section or update existing
   - Include examples from the work
   - Show user the change for approval

3. **Commit**:
   - Descriptive message
   - Evidence of validation (occurred X times)

### For Pattern Extraction:

**Epic+ Only** (Task-level waits for Epic validation):

1. **Draft pattern** using Pattern Library format:
   ```markdown
   ## Pattern Name ⭐⭐

   **Context**: When does this apply?
   **Pattern**: What to do
   **Applicability**: Where to use
   **Anti-Pattern**: What NOT to do
   **Evidence**: Where validated (commits, work)
   ```

2. **Add to Pattern Library**:
   - Appropriate section in `wiki/Pattern-Library.md`
   - Update version number (v[X.Y.Z] → v[X.Y.Z+1])

3. **Commit** to wiki

### For Strategic Insights:

**Milestone Only**:

1. **Draft insight**:
   ```markdown
   ## Insight Name

   **Discovery**: What was learned
   **Evidence**: Data supporting this
   **Principle**: Core takeaway
   **Application**: How to use in future
   ```

2. **Add to Strategic Insights**:
   - Appropriate section in `wiki/Strategic-Insights.md`

3. **Commit** to wiki

### For Platform Capabilities:

**Milestone/M3+**:

1. **Document requirement** in M3 plan or future milestone
2. **Specify** what capability is needed
3. **Link** to evidence from this work

---

## Step 7: DOCUMENT Learnings

**Purpose**: Preserve knowledge at appropriate level

### Task Completion → Work Log Entry

**Location**: `wiki/Work-Log-YYYY-MM.md`

Generate and add:
```markdown
### [Task Name] ✅
**Category**: `task`

[Summary]

**Key Deliverables**:
- [Item 1]

**Learnings**:
- [Learning 1]

**Improvements Made**:
- [Improvement 1]: [What was codified]

**Patterns Noted for Epic Validation**:
- [Pattern candidate] (occurred X times, need 3+ for extraction)

**Evidence**: [Commits]

**Related**: [[Pattern-Library]], [[Strategic-Insights]]
```

**Action**: Commit work log update

---

### Epic Completion → Retrospective Entry

**Location**: `wiki/Retrospectives.md`

Generate and add:
```markdown
### [Epic Name] (YYYY-MM-DD)
**Category**: `epic`
**Duration**: [timespan]

[Summary paragraph]

**What Worked**:
- [Item 1 with evidence]

**What Could Improve**:
- [Item 1 with evidence]

**Patterns Extracted** (validated across 3+ Tasks):
- [Pattern 1] → Added to Pattern Library v[X.Y.Z]

**Improvements Implemented**:
- [Improvement 1]: [What was done]

**Metrics**:
- [Metric]: [value]

**Evidence**: [Commits]

**Related**: [[Pattern-Library]] v[X.Y.Z], [[Work-Log-YYYY-MM]]
```

**Action**: Commit retrospectives update + Pattern Library if updated

---

### Milestone Completion → Full Retrospective

**Location**: `docs/retrospectives/YYYY_MM_DD_milestone_name.md`

Create comprehensive document with sections:
1. Executive Summary
2. What We Did
3. What Worked Well
4. What Could Be Improved
5. Patterns That Emerged (5-10)
6. Strategic Insights (3-5)
7. Process Efficiency Metrics
8. Recommendations
9. Evidence Trail

**Also add** entry to `wiki/Retrospectives.md` linking to full doc

**Action**: Commit retrospective doc + Pattern Library + Strategic Insights updates

---

## Step 8: Validation & Push

### Validation Checklist

Confirm with user:

**Analysis**:
- [ ] Work analyzed (what worked, what didn't, patterns, insights)
- [ ] Opportunities extracted (validated by 3+ occurrences)

**Codification**:
- [ ] Process improvements implemented (instruction files updated)
- [ ] Patterns extracted (if Epic+, added to Pattern Library)
- [ ] Strategic insights added (if Milestone)

**Documentation**:
- [ ] Work log entry added (Task) OR
- [ ] Retrospective entry added (Epic) OR
- [ ] Full retrospective document created (Milestone)
- [ ] All cross-references bidirectional
- [ ] Evidence trail complete

**Commits**:
- [ ] All changes committed with descriptive messages
- [ ] Ready to push to remote

### Push Changes

Ask user: **"All changes committed. Push to remote now?"**

If yes:
1. `git push` (main repo)
2. `git -C wiki push` (if wiki updated)
3. Confirm success

---

## Critical Reminders

**Complete the Loop**: Don't stop at analysis - EXTRACT, CODIFY, DOCUMENT

**Validation Threshold**: Pattern must appear 3+ times in scope

**Scope Matching**: Insight breadth must match corpus size
- Task → Tactical
- Epic → Domain
- Milestone → Strategic

**Evidence-Based**: Every claim needs specific evidence

**Quantify When Possible**: Use metrics, commit counts, time measurements

**Implement NOW**: Codify improvements during loop, not later

---

## Example Flows

### Example 1: Interactive Mode (No Arguments)

```
User invokes: /conduct-learning-loop

Agent: "What type of work are we analyzing?"
1. Task Completion
2. Epic Completion
[...options...]

User: "1 - Task Completion"

Agent: "For Task-level, we'll do: ANALYZE → EXTRACT → CODIFY → DOCUMENT (5-10 min total)"

=== STEP 1: ANALYZE ===
Agent: "What was accomplished in this task?"
[User provides details, walks through what worked, what didn't, patterns, insights...]

=== STEP 2: EXTRACT ===
Agent: "I found 2 potential improvements:
1. 'Automation decision tree' - appeared 3 times ✅
2. 'Interactive design pattern' - appeared 2 times (needs Epic validation)

Which should we implement now?"

User: "Let's do #1"

=== STEP 3: CODIFY ===
Agent: "I'll add automation decision tree to development_workflow_essentials.instructions.md"
[Makes change, shows user, commits]

=== STEP 4: DOCUMENT ===
Agent: "Creating work log entry..."
[Generates entry, adds to work log, commits]

Agent: "Learning loop complete!
- 1 improvement codified (automation decision tree)
- 1 pattern noted for Epic validation
- Work log entry added

Push changes now?"
```

### Example 2: With Type Argument

```
User invokes: /conduct-learning-loop task

Agent: "Conducting Task-level learning loop: ANALYZE → EXTRACT → CODIFY → DOCUMENT (5-10 min total)

What task are we analyzing?"

User: "The naming consistency fix we just completed"

Agent: "Got it - analyzing the naming consistency fix task.

What was accomplished?"
[Continues with analysis steps...]
```

### Example 3: With Type and Name Arguments

```
User invokes: /conduct-learning-loop task hello world mcp server

Agent: "Conducting Task-level learning loop for: hello world mcp server

This will take 5-10 min: ANALYZE → EXTRACT → CODIFY → DOCUMENT

Let's start with what was accomplished. Can you summarize what was completed in this task?"

[User provides details, analysis continues...]
```

### Example 4: Milestone with Shorthand

```
User invokes: /conduct-learning-loop m1

Agent: "Conducting Milestone-level learning loop for: Milestone 1

This is comprehensive analysis (2-3 hours): ANALYZE → EXTRACT → CODIFY → DOCUMENT

Milestone learning loops look for:
- Patterns repeated across 5+ Epics or 10+ tasks
- Cross-domain improvements
- Platform/tooling gaps
- Meta-process improvements

Can make project-wide process changes and strategic insights.

Let's start - what was accomplished in Milestone 1?"

[Comprehensive analysis continues...]
```

---

**Instruction Sources**:
- `docs/processes/learning_loop_workflow.md` - Complete workflow specification (primary)
- `docs/processes/retrospective_framework.md` - Retrospective methodology and frameworks
- `docs/processes/learning_and_context_framework.md` - Foundational principles and pattern extraction
- `docs/processes/work_log_policy.md` - Work log maintenance standards
- `knowledge/instructions/pongogo/process/process_learning_capture.instructions.md` - Pause point types and scope
- `knowledge/instructions/pongogo/project_management/work_logging.instructions.md` - Two-level learning framework
