---
description: Pick up previously stashed work with context validation
---

# Pick Up Work

You are being asked to pick up previously stashed work. This loads context from stashed work state, verifies current state, and prepares for continuation.

---

## Step 1: Check for Handoff Context

Look for session handoff document:

**Primary**: `SESSION_HANDOFF.md` (repository root)
**Alternative**: Recent work log entries in `wiki/Work-Log-YYYY-MM.md`

If SESSION_HANDOFF.md exists:
```bash
# Read the handoff document
cat SESSION_HANDOFF.md
```

If no SESSION_HANDOFF.md:
- Check recent work log entries (last 3-5 days)
- Check PROJECT_TRACKING.md for current state
- Inform user: "No SESSION_HANDOFF.md found. Loading context from work log..."

---

## Step 2: Verify Current State

Run diagnostics to ensure clean environment:

**Git Status**:
```bash
git status
```

**Current Branch**:
```bash
git branch --show-current
```

**Recent Commits** (last 5):
```bash
git log --oneline -5
```

**Uncommitted Changes** (if any):
```bash
git status --short
```

**Validation**:
- ✅ Clean working directory = Ready to proceed
- ⚠️ Uncommitted changes = Ask user: "You have uncommitted changes. Should we commit them first?"
- ⚠️ Wrong branch = Ask user: "You're on [branch]. Should we switch to [expected branch]?"

---

## Step 3: Parse Handoff Context

Extract key information from SESSION_HANDOFF.md:

**Parse for**:
1. **Status** - Where we left off
2. **Next Steps** - What to do now (look for "What to Do Next" section)
3. **Core Achievement** - What was accomplished
4. **Success Criteria** - How to validate progress
5. **Key Files** - Files to reference
6. **Commits** - Evidence trail

**Create Summary**:
```markdown
## Session Resume Summary

**Where We Left Off**: [Brief context from handoff]

**What Was Accomplished**:
- [Key achievement 1]
- [Key achievement 2]

**Current State**: [Status from handoff]

**Next Steps** (from handoff):
1. [Immediate next step with time estimate]
2. [Alternative step if applicable]

**Key Files to Reference**:
- [File 1] - [Purpose]
- [File 2] - [Purpose]

**Recent Commits**:
- [hash] - [Description]
```

---

## Step 4: Confirm Understanding

Ask the user:

**"I've loaded the session context. Here's where we are:"**

[Show Session Resume Summary from Step 3]

**"Does this match your understanding? Are we ready to proceed with [next step]?"**

Options:
1. ✅ **Yes, proceed** → Continue to Step 5
2. 🔄 **Update needed** → Ask user what changed
3. 📋 **Different priority** → Ask user what to work on instead

---

## Step 5: Prepare to Resume Work

Based on user confirmation:

### If Proceeding with Handoff Plan:

**Verify Prerequisites**:
- Required files exist?
- Dependencies installed?
- Tests passing? (if applicable)

**Load Context**:
- Read key files mentioned in handoff
- Review recent commits for context
- Check current milestone/epic/task status

**Ask**: "Should I create a work log session start entry?"

If yes → Proceed to Step 6
If no → Skip to Step 7

---

## Step 6: Create Work Log Session Start Entry (Optional)

Use `/work-log` format for session start:

```markdown
### Session: [Work description from handoff]
**Category**: `session`

Resuming work from [previous session date]. Context loaded from SESSION_HANDOFF.md.

**Picking Up From**:
- [Last thing completed]
- [Current state]

**This Session Goals**:
- [Next step from handoff]
- [Additional goals if applicable]

**Evidence**: SESSION_HANDOFF.md
```

Add to `wiki/Work-Log-YYYY-MM.md`:
- Place in most recent date section
- If new date, create new date section

**Ask**: "Work log session start entry created. Should I commit this?"

If yes:
```bash
git -C wiki add Work-Log-YYYY-MM.md
git -C wiki commit -m "Add session start entry: [work description]"
git -C wiki push
# Update main repo submodule pointer
git add wiki
git commit -m "Update wiki submodule: Session start"
git push
```

---

## Step 7: Ready to Work

Confirm with user:

**"Session resumed! ✅"**

**Current State**:
- [Status from handoff]

**Next Step**:
- [Immediate action from handoff]

**I'm ready to proceed when you are. Should I start with [next step], or would you like to adjust the plan?**

---

## Resume Best Practices

### Do Include:
- ✅ Complete context summary (not just "I read the file")
- ✅ Verification of current state (git status, branch, etc.)
- ✅ Explicit next step from handoff
- ✅ User confirmation before proceeding
- ✅ Work log session start (captures resume point)

### Don't Include:
- ❌ Starting work without user confirmation
- ❌ Assuming handoff is current (verify git state)
- ❌ Skipping verification steps (could be stale context)
- ❌ Overwhelming detail (summarize, don't dump)

---

## Handle Missing Handoff

If no SESSION_HANDOFF.md exists:

1. **Check work log** for recent entries:
   ```bash
   # Read last 50 lines of current month's work log
   tail -50 wiki/Work-Log-YYYY-MM.md
   ```

2. **Check PROJECT_TRACKING.md** for current state:
   ```bash
   cat docs/project_management/PROJECT_TRACKING.md
   ```

3. **Ask user**:
   **"No handoff document found. Here's what I found from work log and PROJECT_TRACKING.md:"**

   [Show summary of recent work]

   **"What should we work on?"**

---

## Handle Stale Handoff

If handoff is old (>7 days):

**Warn user**:
⚠️ **"The handoff document is from [date] - that's [X] days ago. Let me verify current state..."**

1. Check recent commits (since handoff date)
2. Check work log entries (since handoff date)
3. Show what's changed since handoff

**Ask**: "The handoff may be stale. Should I create a fresh context summary, or is the handoff still accurate?"

---

## Integration with Other Commands

**Resume → Work Flow**:
```
/resume → Load context → Create session start entry → Begin work
```

**Resume → Learning Loop** (if work was complete):
```
/resume → Recognize work complete → Suggest: "Should we run /learning-loop on [completed work]?"
```

**Resume → Handoff** (if still not ready):
```
/resume → User: "Actually not ready yet" → Run /handoff again with updated context
```

---

## Example Resume Scenarios

### Scenario 1: After Restart (Slash Commands)

```
User: /resume
Agent: [Loads SESSION_HANDOFF.md]
Agent: "We restarted to activate slash commands. Handoff says to test them."
Agent: "Ready to test /learning-loop, /work-log, /handoff?"
User: "Yes"
Agent: "Starting with /learning-loop test..."
```

### Scenario 2: Next Day Continuation

```
User: /resume
Agent: [Loads SESSION_HANDOFF.md from yesterday]
Agent: "Yesterday we completed Template Simplification Phase B. Next step: Run learning loop."
Agent: "Should I create session start entry and proceed with learning loop?"
User: "Yes"
Agent: [Creates work log entry, starts learning loop]
```

### Scenario 3: No Handoff Available

```
User: /resume
Agent: "No SESSION_HANDOFF.md found. Checking work log..."
Agent: [Shows last 3 work log entries]
Agent: "Looks like we were working on Milestone 1 institutionalization. What should we focus on?"
User: "Let's continue with Epic validations"
Agent: "Got it. Starting with Epic validation work..."
```

### Scenario 4: Stale Handoff

```
User: /resume
Agent: "⚠️ Handoff from Oct 28 (3 days ago). Recent commits show work continued..."
Agent: [Shows commits since handoff]
Agent: "Should I use the old handoff or load fresh context from work log?"
User: "Load fresh context"
Agent: [Reads recent work log, creates new summary]
```

---

## Critical Reminders

**Resume is the inbound flow**:
- Handoff (outbound) → SESSION_HANDOFF.md → Resume (inbound)
- Must validate context, not just read and assume

**Verification matters**:
- Git state could have changed
- Handoff could be stale
- User priorities could have shifted

**User confirmation required**:
- Don't start work without confirming plan
- Handoff is a guide, not a command

**Work log completes the loop**:
- Session end entry (before handoff)
- → Pause →
- Session start entry (after resume)
- Shows bidirectional journey

---

## Handoff + Resume Workflow

**Complete Bidirectional Flow**:

```
End Session:
  /work-log (session end) → Optional
  /handoff → Create SESSION_HANDOFF.md

=== Pause / Restart ===

Resume Session:
  /resume → Load SESSION_HANDOFF.md
  /work-log (session start) → Optional
  Begin work
```

**Context Preservation**:
- Handoff captures: What was done, current state, next steps
- Resume validates: Git state, handoff freshness, user priorities
- Work log documents: Session boundaries, continuation points

---

**Instruction Source**: Discovered gap in bidirectional workflow (2025-10-31) - had outbound (/handoff) but not inbound (/resume)
