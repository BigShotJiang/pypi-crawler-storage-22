---
description: Disable knowledge routing MCP server
---

# Disable Pongogo MCP Server

Disable the Pongogo knowledge routing MCP server to return to baseline Claude behavior without knowledge routing.

## Your Task

Execute the following steps to disable Pongogo MCP server:

### 1. Check Current State

Read the state file to check if already disabled:

```bash
if [ -f .pongogo-mcp-state.json ]; then
  cat .pongogo-mcp-state.json
fi
```

**If state shows `"mode": "disabled"` or file doesn't exist**:
- Display: "⚠️ Pongogo MCP already disabled"
- Stop execution

### 2. Update State File

Use the toggle script to update state atomically:

```bash
python3 scripts/toggle_pongogo_mode.py --mode disabled
```

**Note**: The script automatically removes `log_comment` field when disabling (no routing = no logging) and handles timestamp generation and toggle counting.

### 3. Display Success Message

Show confirmation message:

```
✅ Pongogo MCP disabled. Knowledge routing inactive.

Claude will now operate without Pongogo knowledge routing:
- Standard tool selection behavior
- No automatic instruction file routing
- Baseline context management

To re-enable: /pongogo-enable
```

## Important Notes

- **State Persistence**: State file ensures MCP remains disabled across sessions
- **No Claude Code Restart**: Changes take effect immediately
- **A/B Testing**: Use this to compare Claude performance with/without knowledge routing
- **Baseline Behavior**: Disabling returns to standard Claude Code operation

## Use Cases

**A/B Comparison**:
1. Disable Pongogo (`/pongogo-disable`)
2. Ask question: "How do I create an Epic?"
3. Note Claude's response (baseline)
4. Enable Pongogo (`/pongogo-enable`)
5. Ask same question: "How do I create an Epic?"
6. Compare responses (with vs without knowledge routing)

**Troubleshooting**:
- If MCP server causing issues, disable to isolate problem
- Temporary disable during debugging
- Performance comparison

## Success Criteria

- State file updated with `"mode": "disabled"`
- `log_comment` field removed from state (no routing = no logging)
- User sees clear success message
- Knowledge routing tools no longer invoked by Claude
- Can re-enable with `/pongogo-enable` when needed
