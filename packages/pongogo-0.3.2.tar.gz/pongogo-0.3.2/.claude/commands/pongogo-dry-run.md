---
description: Test routing in dry-run mode (no side effects)
---

# Simulate Pongogo Knowledge Routing (Dry-Run)

Test what the Pongogo MCP server would recommend for a given query without side effects or observability logging.

## Prerequisites

**Container must be running BEFORE starting Claude Code session.**

MCP tools are discovered once at session start. Starting the container mid-session enables routing via hooks but MCP tools remain unavailable.

**Before executing, verify Pongogo MCP tools are available:**
- If you see `mcp__pongogo-knowledge__*` tools in your available tools → Proceed
- If NOT → Container wasn't running at session start. Inform user:
  ```
  ⚠️ MCP tools not available - container wasn't running when session started.

  To fix:
  1. Run: docker-compose up -d knowledge-hub
  2. Restart your Claude Code session
  ```

## Your Task

Execute a dry-run simulation of Pongogo's knowledge routing to see which instruction files would be recommended.

## Usage

This slash command accepts a query parameter. The user will invoke it as:

```
/pongogo-dry-run "How do I create an Epic?"
```

You will receive the query text after the command.

## Execution Steps

### 1. Validate Query Parameter

**If no query provided**:
- Display: "Usage: /pongogo-dry-run '<query>'"
- Display: "Example: /pongogo-dry-run 'How do I create an Epic?'"
- Stop execution

### 2. Check MCP Server Running

Verify knowledge-hub container is running:

```bash
docker-compose ps knowledge-hub
```

**If container not running**:
- Display: "❌ MCP server not responding - check Docker: `docker-compose ps`"
- Suggest: "Run `docker-compose up -d knowledge-hub` to start the server"
- Stop execution

### 3. Call MCP Route Instructions Tool

Use the MCP tool to route the query:

```
mcp__pongogo-knowledge__route_instructions(
  message="<user's query>",
  limit=3
)
```

**Important**: This is a DRY-RUN - do not log to observability system, do not track as "file accessed", no side effects.

### 4. Format and Display Results

Present the simulation results in this format:

```
Pongogo Simulation (dry-run):

Query: '<user's query>'

Top 3 Predicted Files:
1. <filename> (confidence: <score>)
   - Reason: <why this file matched>
   - Category: <file category>
   - Path: <relative path>

2. <filename> (confidence: <score>)
   - Reason: <why this file matched>
   - Category: <file category>
   - Path: <relative path>

3. <filename> (confidence: <score>)
   - Reason: <why this file matched>
   - Category: <file category>
   - Path: <relative path>

Routing Analysis:
<explain routing decision - why these files, what matched, what the relationship is>

Note: This was a dry-run simulation. No observability logging occurred.
```

## Error Handling

**MCP Server Not Responding**:
- Display: "❌ MCP server not responding"
- Suggest: "Check server status with /pongogo-status"
- Suggest: "Check logs: `docker-compose logs knowledge-hub`"

**No Matches Found**:
- Display: "No instruction files matched query: '<query>'"
- Suggest: "Try a different query or check instruction file coverage"
- Suggest: "Use /pongogo-status to verify server health"

**MCP Tool Error**:
- Display: "❌ Error calling route_instructions: <error message>"
- Suggest: "Check MCP server configuration: ~/.claude/mcp_settings.json"

## Use Cases

### Use Case 1: Test Routing Before Asking

Preview what Pongogo would recommend without actually invoking it:

```
/pongogo-dry-run "How do I create a release?"

Result shows:
1. release_management.md (0.92)
2. github_actions_guide.md (0.78)
3. validation_framework.md (0.65)

Now I know what files Pongogo will surface before I ask the real question.
```

### Use Case 2: Debug Routing Issues

Understand why wrong file is being returned:

```
/pongogo-dry-run "How do I handle sub-issues?"

Expected: sub_issues_guide.md #1
Actual: epic_management_guide.md #1

Analysis: Sub-issues mentioned in epic guide, need better keyword weighting
Action: Update sub_issues_guide.md metadata
```

### Use Case 3: Validate Coverage

Confirm new instruction files are discoverable:

```
Create new file: sprint_planning.instructions.md

/pongogo-dry-run "How do I plan a sprint?"

Check if new file appears in top 3
If missing: adjust file keywords/frontmatter
```

### Use Case 4: A/B Comparison Setup

See what Pongogo recommends, then compare with actual behavior:

```
1. /pongogo-dry-run "How do I create an Epic?"
   → Pongogo would recommend: epic_management_guide.md

2. /pongogo-disable
3. Ask: "How do I create an Epic?"
   → Claude answers without Pongogo

4. /pongogo-enable
5. Ask: "How do I create an Epic?"
   → Claude answers with Pongogo

Compare all 3 to evaluate routing effectiveness
```

## Important Notes

- **Dry-Run Mode**: No side effects, no logging, no observability tracking
- **One-Off Test**: Does NOT change your persistent mode (use /pongogo-simulate-enable for persistent testing mode)
- **Direct Tool Call**: Bypasses Claude's decision layer to test routing directly
- **Debugging Tool**: Helps validate and improve routing quality
- **Coverage Validation**: Confirms instruction files are discoverable
- **A/B Testing**: Enables comparison between prediction and actual invocation

## Success Criteria

- Query parameter validated before execution
- MCP server connectivity confirmed
- Top 3 files displayed with confidence scores
- Clear routing explanation provided
- No observability logging (dry-run respected)
- Helpful error messages for common issues
- User understands what Pongogo would recommend
