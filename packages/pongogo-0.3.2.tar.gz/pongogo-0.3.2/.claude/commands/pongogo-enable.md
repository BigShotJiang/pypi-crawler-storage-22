---
description: Enable knowledge routing MCP server
---

# Enable Pongogo MCP Server

Enable the Pongogo knowledge routing MCP server for enhanced agent context and instruction discovery.

## Your Task

Execute the following steps to enable Pongogo MCP server:

### 1. Parse Command Parameters

Check if the user provided a `log_comment` parameter in their command invocation.

**Valid values**: `testing`, `learning`, or empty/unset (for standard production logging)

**Example invocations**:
- `/pongogo-enable` → Standard production logging
- `/pongogo-enable log_comment=testing` → Testing logs (logs/logs-testing/ directory)
- `/pongogo-enable log_comment=learning` → Learning logs (logs/logs-learning/ directory)

**Set variable**:
- `log_comment_value` = extracted value ('testing', 'learning', or '')

### 2. Check Current State

Read the state file to check if already enabled:

```bash
if [ -f .pongogo-mcp-state.json ]; then
  cat .pongogo-mcp-state.json
fi
```

**If state shows `"mode": "enabled"`**:
- Display: "⚠️ Pongogo production mode already active"
- Stop execution

### 3. Verify MCP Server Running

Check if the knowledge-hub Docker container is running:

```bash
docker-compose ps knowledge-hub
```

**If container not running**:
- Display: "❌ MCP server not responding - check Docker: `docker-compose ps`"
- Suggest: "Run `docker-compose up -d knowledge-hub` to start the server"
- Stop execution

### 4. Update State File

Use the toggle script to update state atomically:

```bash
# Standard production (no log_comment)
python3 scripts/toggle_pongogo_mode.py --mode enabled

# With log_comment (testing or learning)
python3 scripts/toggle_pongogo_mode.py --mode enabled --log-comment testing
python3 scripts/toggle_pongogo_mode.py --mode enabled --log-comment learning
```

**Note**: The script handles timestamp generation, toggle counting, and atomic file updates automatically.

**Log Comment Behavior** (unified schema v3.0.0):
- **Unset or empty**: Standard production logs (`logs/logs-production/` and `.pongogo/pongogo.db`)
- **`testing`**: Test isolation logs (`logs/logs-testing/` and `.pongogo/pongogo-test.db`)
- **`learning`**: Learning dataset logs (`logs/logs-learning/` and `.pongogo/pongogo-learning.db`)

### 5. Display Success Message

Show confirmation message (adapt based on log_comment value):

**If log_comment is empty/unset (standard production)**:
```
✅ Pongogo MCP enabled with ALWAYS-ON ROUTING

🔄 Always-On Routing Active (Default Behavior):
- EVERY message automatically routes through Pongogo
- Relevant instructions injected as context BEFORE Claude processes
- Standards enforcement automatic (not manual)
- Expected impact: 44% violations → <5%

📊 Performance:
- Target latency: < 50ms per message
- Session caching: Route once per conversation (1-hour TTL)
- Target cache hit rate: > 70% after first message

🔍 Monitoring:
- Check logs: tail -f ~/.claude/logs/always-on-routing.log
- Check status: /pongogo-status
- Look for "## Relevant Pongogo Instructions" in responses
- Observability: logs/logs-production/ and .pongogo/pongogo.db (standard production)
```

**If log_comment is 'testing'**:
```
✅ Pongogo MCP enabled with ALWAYS-ON ROUTING (TESTING MODE)

🧪 Test Isolation Active:
- Log location: logs/logs-testing/ and .pongogo/pongogo-test.db
- Isolated from production logs
- Use for automated tests, benchmarks, investigations

🔄 Always-On Routing Active (Default Behavior):
- EVERY message automatically routes through Pongogo
- Relevant instructions injected as context BEFORE Claude processes
- Standards enforcement automatic (not manual)

📊 Performance:
- Target latency: < 50ms per message
- Session caching: Route once per conversation (1-hour TTL)
- Target cache hit rate: > 70% after first message

🔍 Monitoring:
- Check logs: tail -f ~/.claude/logs/always-on-routing.log
- Check status: /pongogo-status
- Look for "## Relevant Pongogo Instructions" in responses
- Observability: logs/logs-testing/ and .pongogo/pongogo-test.db (TESTING)
```

**If log_comment is 'learning'**:
```
✅ Pongogo MCP enabled with ALWAYS-ON ROUTING (LEARNING MODE)

📚 Learning Dataset Collection Active:
- Log location: logs/logs-learning/ and .pongogo/pongogo-learning.db
- Production usage for training data
- Captured for learning loop analysis

🔄 Always-On Routing Active (Default Behavior):
- EVERY message automatically routes through Pongogo
- Relevant instructions injected as context BEFORE Claude processes
- Standards enforcement automatic (not manual)

📊 Performance:
- Target latency: < 50ms per message
- Session caching: Route once per conversation (1-hour TTL)
- Target cache hit rate: > 70% after first message

🔍 Monitoring:
- Check logs: tail -f ~/.claude/logs/always-on-routing.log
- Check status: /pongogo-status
- Look for "## Relevant Pongogo Instructions" in responses
- Observability: logs/logs-learning/ and .pongogo/pongogo-learning.db (LEARNING)

🛠️ Manual MCP Tools (also available):
- mcp__pongogo-knowledge__route_instructions
- mcp__pongogo-knowledge__search_instructions
- mcp__pongogo-knowledge__get_instructions

⚙️ Three-State Model:
- Enabled (current): Production mode (routing + injection + read-write)
- Disabled: Baseline mode (no routing, A/B testing)
  → Use /pongogo-disable to switch
- Simulate: Testing mode (routing + injection + read-only)
  → Use /pongogo-simulate-enable to switch

Try asking: "How do I create an Epic?"
```

## Important Notes

- **Always-On by Default**: `enabled: true` means always-on routing is active - automatic context injection is core behavior
- **State Persistence**: State file ensures Pongogo remains enabled across sessions
- **No Claude Code Restart**: Changes take effect immediately
- **Validation**: Always verify Docker container running before enabling
- **Error Handling**: Provide clear, actionable error messages
- **Three-State Model**: Enabled (production, read-write), Disabled (baseline), Simulate (testing, read-only)

## Success Criteria

- State file updated with `"mode": "enabled"`
- MCP server confirmed running and responding
- User sees clear success message with always-on routing guidance
- Knowledge routing tools available for immediate use
- Always-on routing active (automatic context injection on every message)
- Read-write access to knowledge system enabled
