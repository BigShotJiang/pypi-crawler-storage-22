# Prune Instruction Files

Conduct a comprehensive overlap, conflict, and optimization assessment for instruction files.

**Purpose**: Ensure instruction files are correctly positioned in the ring hierarchy, minimize overlaps, resolve conflicts, and optimize for agent consumption. This is a **knowledge quality** exercise, not just file count reduction.

## The Concentric Circles Model

Pongogo instruction files exist in four rings, from innermost (most universal) to outermost (most specific):

```
Ring 1: Universal Core (seed files)
  └─ Ships with Pongogo, immutable by users
  └─ Location: instructions/ in package (not .pongogo/)
  └─ Examples: collaboration, planning, issue_closure

Ring 2: Working Rules (immutable guardrails)
  └─ Validated patterns, 3+ occurrences, team-wide
  └─ Location: .pongogo/instructions/{category}/
  └─ Criteria: Proven through use, generalizable

Ring 3: Working Preferences (observed/instructed methods)
  └─ Team conventions, style preferences, project-specific
  └─ Location: .pongogo/instructions/{category}/
  └─ Criteria: Works for this team, may not generalize

Ring 4: Individual Preferences (unique elements)
  └─ Personal workflow quirks, may not translate
  └─ Location: .pongogo/instructions/personal/ or user-specific
  └─ Criteria: Individual only, not for collaboration
```

### Ring Hierarchy Conflict Resolution

**Inner ring ALWAYS wins.** When outer ring contradicts inner ring:
- Outer ring is wrong, or
- Outer ring needs clarification to avoid conflict, or
- Inner ring needs promotion of the insight (rare)

## Rigor Levels

**IMPORTANT**: Select rigor level at the start. Default to higher rigor when uncertain.

| Level | Use Case | Time | Scope |
|-------|----------|------|-------|
| **Quick Scan** | Spot-check after minor additions | < 1 hour | New files only, obvious overlaps |
| **Standard** | Regular maintenance, post-milestone | 2-4 hours | Full ring classification + overlap detection |
| **Comprehensive** | First prune, major refactoring, pre-release | Half-day+ | All files read, cross-ring conflict analysis |

**Defaults**:
- First prune of a codebase: **Comprehensive**
- Post-milestone maintenance: **Standard**
- After adding 1-3 files: **Quick Scan**

## Pre-Flight Checks

**MANDATORY before starting any prune:**

### File Inventory
```bash
# Count instruction files by category
find .pongogo/instructions -name "*.md" -type f | wc -l

# List categories with file counts
find .pongogo/instructions -mindepth 1 -maxdepth 1 -type d | while read dir; do
  count=$(find "$dir" -name "*.md" | wc -l | tr -d ' ')
  echo "$count $(basename "$dir")"
done | sort -rn
```

### Seed Comparison (if available)
```bash
# Compare against shipped seed files
# This shows what's unique to this installation
diff -rq instructions/ .pongogo/instructions/ 2>/dev/null || echo "No seed comparison available"
```

### Prior Prune Check
- Check for prior prune documents in `tmp/instruction_prune_*.md`
- If prior prune exists, expect **minimal delta**
- Note prior date for delta tracking

## Running Notes Requirement

**MANDATORY: Create detailed progress tracking file before starting.**

```bash
touch tmp/instruction_prune_$(date +%Y-%m-%d).md
```

**Required contents**:
1. **Ring Classification Table**: File → Ring assignment with rationale
2. **Overlap Detection Log**: File pairs with overlap percentage
3. **Conflict Detection Log**: Cross-ring contradictions found
4. **Action Log**: Decisions made, actions taken

## Phase 1: Ring Classification

For each instruction file (excluding Ring 1 seed files), determine ring assignment.

### Classification Criteria

| Ring | Criteria | Evidence Required |
|------|----------|-------------------|
| **Ring 2** | Validated pattern, 3+ occurrences, generalizable | PI reference, RCA source, cross-project applicability |
| **Ring 3** | Team convention, project-specific, works for us | Team agreement, local context dependency |
| **Ring 4** | Individual preference, may not translate | Single-user origin, collaboration friction risk |

### Classification Workflow

For each file:

1. **Read full file** (not from memory)
2. **Check source field** in YAML frontmatter
3. **Assess generalizability**: Would this apply to ANY Pongogo user?
4. **Check validation evidence**: PI reference? RCA source? Occurrence count?
5. **Assign ring** with documented rationale

**Recording Format**:
```markdown
| File | Current Category | Assigned Ring | Rationale |
|------|-----------------|---------------|-----------|
| learning_loop_execution.instructions.md | learning | Ring 2 | RCA-driven, 5+ occurrences, generalizable |
| pongogo_to_go_development.instructions.md | development | Ring 3 | Pongogo-specific, not generalizable |
```

### Ring Mismatch Actions

| Current State | Should Be | Action |
|--------------|-----------|--------|
| Ring 3 file acts like Ring 2 | Ring 2 | **PROMOTE**: Validate, move to appropriate category |
| Ring 2 file is project-specific | Ring 3 | **DEMOTE**: Add project context, mark as preference |
| Ring 4 file works for team | Ring 3 | **PROMOTE**: Validate with team, generalize language |
| Any ring file is obsolete | Archive | **ARCHIVE**: Move to archive/ with rationale |

## Phase 2: Intra-Ring Overlap Detection

Find files within the same ring that have significant content overlap.

### Overlap Detection Methods

**Method 1: Title/Purpose Similarity**
```bash
# Extract titles and descriptions
grep -h "^title:\|^description:" .pongogo/instructions/*/*.md | paste - -
```

**Method 2: Keyword Overlap**
```bash
# For each file pair, compare routing keywords
# High keyword overlap = potential content overlap
```

**Method 3: Full Content Comparison** (Comprehensive rigor only)
- Read both files completely
- Identify overlapping sections
- Estimate overlap percentage

### Overlap Thresholds

| Overlap % | Classification | Action |
|-----------|---------------|--------|
| < 20% | Distinct | No action |
| 20-40% | Related | Clarify boundaries, add cross-references |
| 40-70% | Significant | Consider merging OR splitting scope clearly |
| > 70% | Duplicate | MERGE (preserve unique content from both) |

### Recording Format
```markdown
| File A | File B | Overlap % | Finding | Action |
|--------|--------|-----------|---------|--------|
| strategic_checkpoint.md | strategic_checkpoint_framework.md | 65% | Complementary (WHEN vs HOW) | MERGE |
| github_essentials.md | github_mcp_essentials.md | 25% | Related but distinct | Add cross-references |
```

## Phase 3: Cross-Ring Conflict Detection

Find cases where outer ring instructions contradict inner ring.

### Conflict Types

| Type | Example | Resolution |
|------|---------|------------|
| **Direct Contradiction** | Ring 3 says "always X", Ring 2 says "never X" | Ring 2 wins, update Ring 3 |
| **Scope Collision** | Both rings claim same decision authority | Clarify which ring owns decision |
| **Implicit Override** | Ring 3 effectively bypasses Ring 2 guardrail | Remove bypass, enforce guardrail |
| **Terminology Conflict** | Same term, different meanings across rings | Standardize terminology |

### Detection Workflow

1. **Identify Ring 2 guardrails**: Rules that should never be violated
2. **Scan Ring 3-4 for conflicts**: Check each outer ring file against guardrails
3. **Document conflicts**: File pair, conflict type, resolution

### Recording Format
```markdown
| Inner Ring File | Outer Ring File | Conflict Type | Description | Resolution |
|-----------------|-----------------|---------------|-------------|------------|
| issue_closure.md | quick_close.md | Direct Contradiction | quick_close skips approval | Remove quick_close |
```

## Phase 4: Optimization Assessment

Assess each file for agent consumption quality.

### Assessment Criteria

| Criterion | Good | Needs Work |
|-----------|------|------------|
| **File Size** | 200-1500 lines | < 100 (too brief) or > 2000 (too long) |
| **Structure** | Clear sections, Quick Reference, Examples | Wall of text, no navigation |
| **Routing Keywords** | 10-20 specific keywords | < 5 (under-routed) or > 30 (over-routed) |
| **Related Instructions** | 2-5 relevant cross-references | None or > 10 |
| **Examples** | Concrete, actionable | Abstract or missing |
| **Anti-Patterns** | Documented with prevention | Not documented |

### Recording Format
```markdown
| File | Size | Structure | Routing | Related | Examples | Anti-Patterns | Grade |
|------|------|-----------|---------|---------|----------|---------------|-------|
| learning_loop.md | 659 | Good | Good | Good | Good | Good | A |
| quick_fix.md | 89 | Poor | Poor | None | None | None | F |
```

## Phase 5: Interactive Decision Workflow

After completing analysis, guide user through decisions.

### Decision Categories (in order)

1. **ARCHIVE**: Files that are obsolete, superseded, or Ring 4 that won't translate
2. **MERGE**: Overlapping files that should be combined
3. **DEMOTE**: Ring 2 files that are actually Ring 3
4. **PROMOTE**: Ring 3 files that should be Ring 2
5. **CLARIFY**: Conflicting files that need updates
6. **OPTIMIZE**: Files needing structural improvements

### Decision Prompts

For each category, use AskUserQuestion with multiselect where appropriate.

**Example for MERGE decisions**:
```
Question: "Which overlapping file pairs should be merged?"
Options:
- "strategic_checkpoint + strategic_checkpoint_framework → learning/strategic_checkpoint.md"
- "process_learning_capture + learning_loop_execution → learning/learning_loop_execution.md"
- "Keep both separate with clarified scope"
Header: "Merge files"
multiSelect: true
```

## Phase 6: Execute Actions

Execute approved actions immediately after each category's approval.

### MERGE Action
```bash
# 1. Create merged file (manual - requires reading both files)
# 2. Update related_instructions references in other files
# 3. Remove source files
rm .pongogo/instructions/{category}/{source_file}.md

# 4. Update routing (if applicable)
# 5. Commit
git add .pongogo/instructions/
git commit -m "Merge instruction files: [description]"
```

### ARCHIVE Action
```bash
# 1. Create archive directory if needed
mkdir -p .pongogo/instructions/_archive/

# 2. Move file with datestamp
mv .pongogo/instructions/{category}/{file}.md \
   .pongogo/instructions/_archive/{file}_$(date +%Y-%m-%d).md

# 3. Document reason in archived file header
# 4. Commit
```

### PROMOTE/DEMOTE Action
```bash
# 1. Move to appropriate category
mv .pongogo/instructions/{old_category}/{file}.md \
   .pongogo/instructions/{new_category}/

# 2. Update frontmatter (domains, priority)
# 3. Update related_instructions references
# 4. Commit
```

## Knowledge Preservation Requirements

**MANDATORY before any destructive action:**

| Action | Preservation Requirement |
|--------|-------------------------|
| **MERGE** | All unique content from both files preserved in merged file |
| **ARCHIVE** | Archived file retains full content + rationale header |
| **DELETE** | Only if content fully absorbed elsewhere (document where) |

**Merge Preservation Checklist**:
- [ ] All unique sections from File A preserved
- [ ] All unique sections from File B preserved
- [ ] All unique examples preserved
- [ ] All unique anti-patterns preserved
- [ ] Related instructions updated in both directions
- [ ] Routing keywords combined (deduplicated)

## Audit Trail

### Work Log Entry

After completing prune:

```markdown
### Instruction File Prune - $(date +%Y-%m-%d)

**Category**: `chore`
**Rigor Level**: [Quick Scan / Standard / Comprehensive]

Conducted instruction file prune for .pongogo/instructions/.

**Assessment Summary**:
- Total files assessed: N
- Ring 2: X files
- Ring 3: X files
- Ring 4: X files (if any)

**Actions Taken**:
- MERGED: X file pairs
- ARCHIVED: X files
- PROMOTED: X files
- DEMOTED: X files
- CLARIFIED: X files
- OPTIMIZED: X files

**Key Findings**:
- [Notable finding 1]
- [Notable finding 2]

**Delta vs Prior Prune**: [If applicable]
```

### Archive to Wiki

```bash
# Copy findings to wiki
cp tmp/instruction_prune_$(date +%Y-%m-%d).md \
   wiki/Audit-InstructionPrune-$(date +%Y-%m-%d).md

# Edit to archive format
# Commit wiki
cd wiki && git add . && git commit -m "Add instruction prune audit" && git push && cd ..
git add wiki && git commit -m "Update wiki: instruction prune audit"
```

## Frequency

Run this assessment:
- **Pre-release**: Before shipping new Pongogo version (Comprehensive)
- **Post-major-learning**: After significant RCAs or pattern validation (Standard)
- **Quarterly**: Regular hygiene (Standard)
- **After adding files**: Quick validation (Quick Scan)

## Relationship to Seed Files

### What Goes in Seed (Ring 1)

Files should be promoted to seed when:
- Validated across multiple projects (not just Super Pongogo)
- Universal applicability (any Pongogo user would benefit)
- Stable (not frequently changing)
- Core to Pongogo methodology (not optional preference)

### Seed Promotion Workflow

1. Identify candidate from Ring 2
2. Validate in external project (Howl, future users)
3. Create issue for seed promotion
4. Update `seed/instructions.jsonl`
5. Remove from `.pongogo/instructions/` (now bundled)

## Anti-Patterns

### Anti-Pattern 1: Deleting Without Preservation

**Problem**: Removing file content without ensuring it's captured elsewhere
**Prevention**: Complete merge/preservation checklist before any deletion

### Anti-Pattern 2: Over-Merging

**Problem**: Combining files that should remain separate (different audiences, contexts)
**Prevention**: If overlap < 40%, prefer clarifying boundaries over merging

### Anti-Pattern 3: Ring Inflation

**Problem**: Treating Ring 3 preferences as Ring 2 rules
**Prevention**: Require validation evidence (PI, RCA, 3+ occurrences) for Ring 2

### Anti-Pattern 4: Ignoring Cross-Ring Conflicts

**Problem**: Allowing outer rings to effectively override inner rings
**Prevention**: Inner ring always wins; outer ring must adapt or be removed
