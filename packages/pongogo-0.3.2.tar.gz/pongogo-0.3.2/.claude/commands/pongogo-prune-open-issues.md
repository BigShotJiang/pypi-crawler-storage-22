# Prune Open Issues

Conduct a comprehensive staleness and overlap assessment for issues on the project board.

**Purpose**: Ensure each issue represents valid, actionable work with unique scope. This is a **knowledge preservation** exercise, not just issue count reduction. Minimal changes after prior triage is a validation signal (expected), not a failure.

## Rigor Levels

**IMPORTANT**: Select rigor level at the start. Default to higher rigor when uncertain.

| Level | Use Case | Time | Cross-Reference Scope |
|-------|----------|------|----------------------|
| **Quick Scan** | Spot-check after minor changes | < 1 hour | Title review + obvious staleness only |
| **Standard** | Regular triage, re-triage after prior pass | 2-4 hours | 4-step methodology with cluster comparison |
| **Comprehensive** | First triage, major milestone boundaries | Half-day+ | 7-step methodology reading ALL open issues |

**Defaults**:
- First triage of a scope: **Comprehensive** (establish baseline)
- Re-triage after prior pass: **Standard** (validate, expect minimal changes)
- Quick board hygiene: **Quick Scan** (spot-check only)

**User should explicitly confirm rigor level** before starting. If unclear, use Comprehensive.

## Pre-Flight Checks

**MANDATORY before starting any triage:**

### Infrastructure Readiness
```bash
# Check work log size (use summaries if > 5000 lines)
wc -l wiki/Work-Log-$(date +%Y-%m).md

# If > 5000 lines, use weekly summaries instead:
cat wiki/Work-Log-$(date +%Y-%m)-Weekly.md
```

### Scope Assessment
```bash
# Count total open issues
gh issue list --repo pongogo/pongogo --state open --limit 1000 | wc -l

# If > 50 issues, consider batching by cluster
# If > 100 issues, batching by cluster is REQUIRED
```

### Prior Triage Check
- Check for prior triage documents in `wiki/Audit-Triage-*.md`
- If prior triage exists, expect **minimal delta** (validation signal)
- Note prior date for delta tracking

**If any blocker identified, resolve BEFORE starting main work.**

## Prerequisites

Before running this command:
1. Ensure you have access to the GitHub Project Board (Project #1)
2. Work log should be up to date (`wiki/Work-Log-YYYY-MM.md`) or summaries available
3. Pre-flight checks completed (see above)
4. Rigor level confirmed with user

## Running Notes Requirement

**MANDATORY: Create detailed progress tracking before starting.**

### For Standard Methodology

```bash
# Create single tracking file
touch tmp/triage_findings_$(date +%Y-%m-%d).md
```

**Required contents**:
1. **Status tracker**: Phase progress, counts, completion status
2. **Issue-by-issue table**: Number, cluster, analysis steps completed, classification
3. **Classification annotations**: Record immediately after each determination
4. **Cross-reference notes**: Evidence for overlap/no-overlap determinations

### For Comprehensive Methodology (6-Pass)

```bash
# Create phase-based directory structure
mkdir -p tmp/triage_$(date +%Y-%m-%d)/{phase_01_evaluations,phase_02_analysis}
touch tmp/triage_$(date +%Y-%m-%d)/phase_00_structure.md
```

**Required phase files** (see Multi-Pass Methodology section):
- `phase_00_structure.md` - Issue tree snapshot
- `phase_01_evaluations/cluster_X_evaluation.md` - Per-cluster evaluations
- `phase_02_analysis/{overlap,contradiction,uniqueness}_analysis.md` - Three-axis analysis
- `phase_03_resolutions.md` - Contradiction resolutions
- `phase_04_consolidations.md` - Overlap consolidations
- `phase_05_final_report.md` - Final assessment

**Purpose**: Enable recovery after context loss (auto-compact). Without running notes, session recovery is impossible.

### Iteration Pattern (CRITICAL)

**Process one item at a time. Never batch or skip ahead.**

```
❌ WRONG: "I'll read all the issues then analyze them"
✅ CORRECT: "Reading issue #X... [document findings]... Moving to issue #Y"
```

This explicit iteration prevents the premature completion claim anti-pattern.

## Cluster Detection

**Before individual analysis, identify issue clusters:**

1. **Scan all issue titles** in target scope
2. **Group by source/theme**: Same Epic, same domain, same type
3. **Label clusters** (A, B, C, etc.) with brief description
4. **Process clusters together** to identify within-cluster relationships

**Example clusters**:
- Cluster A: "Learning Loop Documentation" (#79, #80, #81, #82)
- Cluster B: "Epic #2 Documentation Gaps" (#43, #44, #45)
- Cluster C: "Infrastructure Maintenance" (#55, #56, #57)

**Document clusters in tracking file** before starting individual analysis.

## Execution Order

**Always prune in this order:**
1. **Up Next** first (highest priority, smallest set)
2. **Backlog** second (larger set, informs by Up Next decisions)
3. **Icebox** optionally (if validating frozen items)

This sequence ensures Up Next is clean before assessing Backlog overlap.

## Process Overview

**Rigor-dependent methodology:**

| Rigor Level | Methodology | Steps |
|-------------|-------------|-------|
| Quick Scan | Title review only | 1-2 steps (retrieve, scan titles) |
| Standard | 4-step with clusters | Full 4-step per issue, cluster comparison |
| Comprehensive | 6-pass with three-axis analysis | Full 6-pass methodology, cross-reference ALL open issues |

## Multi-Pass Methodology (Comprehensive)

**Adapted from instruction file refinement process. Use for first triage or major milestone boundaries.**

The comprehensive methodology uses a **6-pass layered approach** with explicit phase documentation:

### Phase Structure

```
tmp/triage_YYYY-MM-DD/
├── phase_00_structure.md           # Issue tree snapshot by status
├── phase_01_evaluations/           # Per-cluster evaluation files
│   ├── cluster_A_evaluation.md
│   ├── cluster_B_evaluation.md
│   └── ...
├── phase_02_analysis/
│   ├── overlap_analysis.md         # Issues with >30% scope overlap
│   ├── contradiction_analysis.md   # Issues with conflicting acceptance criteria
│   └── uniqueness_analysis.md      # Issues with verified unique scope
├── phase_03_resolutions.md         # Contradiction resolution tracking
├── phase_04_consolidations.md      # Overlap consolidation tracking
└── phase_05_final_report.md        # Final assessment and actions
```

### Pass 1: Structure Mapping

**Goal**: Create complete snapshot of all open issues organized by status.

1. Retrieve ALL project items using GraphQL (see Step 1 below)
2. Create `phase_00_structure.md` with three tables:
   - **Table 1**: Issue counts by status column
   - **Table 2**: All open issues (number, title, status, milestone)
   - **Table 3**: Issues organized by cluster (tree view)

**Output**: Clear picture of scope before analysis begins.

### Pass 2: Individual Evaluation

**Goal**: Read and document each issue, one at a time.

For each cluster identified in Pass 1:
1. Create `phase_01_evaluations/cluster_X_evaluation.md`
2. **Read each issue in the cluster using `gh issue view`**
3. Document for each issue:
   - Issue number and title
   - Scope summary (1-2 sentences)
   - Current status and blockers
   - Acceptance criteria (if defined)
   - Parent Epic/Task relationship

**CRITICAL**: Process **one issue at a time**. Do not skip ahead. Record findings immediately after reading each issue.

### Pass 3: Three-Axis Analysis

**Goal**: Analyze all evaluations for overlap, contradiction, and uniqueness.

Create three files in `phase_02_analysis/`:

#### 3.1 Overlap Analysis (`overlap_analysis.md`)

Look for issues with >30% scope overlap:

```markdown
## Overlap Theme: [Theme Name]

| Issue A | Issue B | Overlap Description | Overlap % | Primary |
|---------|---------|---------------------|-----------|---------|
| #X | #Y | Both cover [scope] | ~40% | #Y (newer) |
```

Organize by theme (one table per theme).

#### 3.2 Contradiction Analysis (`contradiction_analysis.md`)

Look for issues with conflicting acceptance criteria or approaches:

```markdown
## Contradiction: [Description]

| Issue | Conflicting Claim | Evidence |
|-------|-------------------|----------|
| #X | "Should use approach A" | Line from acceptance criteria |
| #Y | "Should use approach B" | Line from acceptance criteria |

**Resolution Required**: [Yes/No]
```

One table per contradiction.

#### 3.3 Uniqueness Analysis (`uniqueness_analysis.md`)

Issues with verified unique scope (no overlaps, no contradictions):

```markdown
| Issue | Title | Unique Scope Summary | Verified Against |
|-------|-------|---------------------|------------------|
| #X | Title | Does [unique thing] | All N issues checked |
```

### Pass 4: Resolve Contradictions

**Goal**: Fix contradictions identified in Pass 3.

1. Read `phase_02_analysis/contradiction_analysis.md`
2. For each contradiction table:
   - **Read each referenced issue** using `gh issue view`
   - Determine correct approach
   - Document resolution in `phase_03_resolutions.md`
   - Update issue(s) if needed (add comment clarifying)
3. **Process one table at a time**. Complete all issues in table before moving to next.

### Pass 5: Consolidate Overlaps

**Goal**: Merge overlapping issues per recency bias principle.

1. Read `phase_02_analysis/overlap_analysis.md`
2. For each overlap theme table:
   - **Read each referenced issue** using `gh issue view`
   - Identify primary issue (typically newer, per recency bias)
   - Consolidate unique details from secondary into primary
   - Document in `phase_04_consolidations.md`
   - Mark secondary issues for closure
3. Copy unique issues from `uniqueness_analysis.md` to final valid list

### Pass 6: Final Classification and Actions

**Goal**: Produce final assessment report and execute actions.

1. Compile findings into `phase_05_final_report.md`
2. Classify all issues using standard categories (see Classification section)
3. Present to user for approval using interactive workflow
4. Execute approved actions
5. Archive to `wiki/Audit-Triage-YYYY-MM-DD.md`

### Standard Methodology (4-Step)

This command implements a 4-step iterative assessment for each issue:

1. **Complete Issue Review** - Read full body and all comments
2. **Work Log Cross-Reference** - Check if work has been partially/fully completed
3. **Cross-Column Comparison** - Compare against issues in other columns for overlap
4. **Reconciliation Planning** - Create plan for duplicates/overlaps

### Comprehensive Methodology (6-Pass with Three-Axis Analysis)

**Use when**: First triage, major milestone boundaries, when Standard reveals uncertainty.

**See "Multi-Pass Methodology" section above for full 6-pass process.**

Key differentiators from Standard:
- **Phase-based documentation**: Explicit tracking files per phase
- **Three-axis analysis**: Overlap + Contradiction + Uniqueness (not just staleness)
- **Explicit iteration**: "One issue at a time, one table at a time" pattern
- **Cross-reference ALL issues**: Every open issue compared against every other

**Evidence annotation format**:
```
VALID - Backlog (6-pass verified YYYY-MM-DD: 3-axis analysis complete, N issues cross-referenced)
```

**Three-Axis Analysis Summary**:

| Axis | What It Detects | Output |
|------|-----------------|--------|
| **Overlap** | Issues with >30% scope overlap | Consolidation candidates |
| **Contradiction** | Conflicting acceptance criteria | Resolution required |
| **Uniqueness** | Verified unique scope | Valid issues |

## Recency Bias Principle

**When resolving overlapping or duplicative issues, favor newer issues.**

Rationale:
- More recent issues contain more up-to-date context
- Newer issues reflect current understanding and priorities
- Information in older issues may be stale or superseded by decisions made since creation

**Application**:
- When two issues cover similar scope, the **newer** issue is typically the "primary"
- Consolidate unique details from older issue INTO newer issue
- Close the older issue as SUPERSEDED, linking to newer issue
- Exception: If older issue has significantly more detail or active work, it may remain primary

## Step 1: Retrieve All Issues from Target Column

Use GraphQL API with pagination to get complete issue list (never use `gh project item-list` which has pagination issues):

```bash
# Save to temp file to avoid jq escaping issues
gh api graphql --paginate -f query='
query($endCursor: String) {
  organization(login: "pongogo") {
    projectV2(number: 1) {
      items(first: 100, after: $endCursor) {
        pageInfo { hasNextPage endCursor }
        nodes {
          fieldValueByName(name: "Status") { ... on ProjectV2ItemFieldSingleSelectValue { name } }
          content { ... on Issue { number title state body } }
        }
      }
    }
  }
}' > /tmp/all_project_items.json
```

Filter for target status (adjust status name as needed):

```bash
# Create jq filter file (avoids bash escaping issues with != null)
cat > /tmp/filter_status.jq << 'EOF'
[.data.organization.projectV2.items.nodes[] | select(.fieldValueByName.name == "Up Next") | .content | select(. != null)] | sort_by(.number) | .[] | {number, title, state}
EOF

jq -f /tmp/filter_status.jq /tmp/all_project_items.json
```

**IMPORTANT**: Verify the count matches expectations. If you expect N issues, ensure you retrieved N issues.

## Step 2: For Each Issue - Complete Assessment

For each issue in the target column, perform this 4-step assessment:

### 2.1 Complete Issue Review

Read the FULL issue body and ALL comments:

```bash
# Get full issue details
gh issue view ISSUE_NUMBER --repo pongogo/pongogo

# Get all comments
gh api repos/pongogo/pongogo/issues/ISSUE_NUMBER/comments
```

**Assess for staleness indicators**:
- **Blocker Resolved**: Issue was blocked by something now complete (e.g., Epic dependency closed)
- **Orphaned**: Sub-task whose parent Epic/Task is now closed
- **Scope Superseded**: Work addressed by newer, more comprehensive Epic/Task
- **Premature Timing**: Issue belongs to future Milestone (wrong timing)
- **Stale Blocker**: Issue depends on something that's been deprioritized indefinitely

### 2.2 Work Log Cross-Reference

Check work log for evidence of partial/full completion:

```bash
# Read current month's work log
cat wiki/Work-Log-$(date +%Y-%m).md

# Search for issue number references
grep -n "Issue #ISSUE_NUMBER\|#ISSUE_NUMBER\|Task #ISSUE_NUMBER" wiki/Work-Log-*.md
```

**Evidence to look for**:
- Direct completion entries
- Related work that addresses the issue's scope
- Decisions that make the issue obsolete
- Learnings that change the issue's relevance

### 2.3 Backlog Comparison

If issue appears valid, compare against ALL Backlog issues:

```bash
# Get all Backlog issues
cat > /tmp/filter_backlog.jq << 'EOF'
[.data.organization.projectV2.items.nodes[] | select(.fieldValueByName.name == "Backlog") | .content | select(. != null)] | sort_by(.number) | .[] | {number, title, state}
EOF

jq -f /tmp/filter_backlog.jq /tmp/all_project_items.json
```

For each Backlog issue that might overlap:
- Read full body: `gh issue view BACKLOG_ISSUE_NUMBER --repo pongogo/pongogo`
- Assess overlap percentage
- Determine which issue is more comprehensive/current

### 2.4 Classification

Classify each issue into one of these categories:

| Category | Sub-Type | Definition | Action |
|----------|----------|------------|--------|
| **NO LONGER NEEDED** | SUPERSEDED | Scope addressed by newer, more comprehensive issue | Close, link to superseding issue |
| | ORPHANED | Sub-task whose parent Epic/Task closed without completing this work | Close with orphan explanation |
| | IRRELEVANT | Context changed, making issue no longer applicable | Close with context explanation |
| **STALE** | - | Blocker resolved, needs reassessment before execution | Reassess dependencies, may become VALID |
| **DUPLICATE** | - | Same scope as another issue | Close duplicate, consolidate to primary |
| **OVERLAPPING** | - | Partial scope overlap (>30%) requiring reconciliation | Reconciliation plan needed |
| **CONTRADICTING** | - | Acceptance criteria conflict with another issue | Resolution required before either can proceed |
| **PREMATURE** | - | Valid but wrong Milestone timing | Move to Backlog with timing note |
| **VALID** | Ready | Dependencies satisfied, can execute immediately | Keep, ready for work |
| | Appropriate | Correctly positioned, no changes needed | Keep in current status |
| | Unique | Three-axis verified: no overlap, no contradiction | Keep with high confidence |

**NO LONGER NEEDED Sub-Type Guidance**:
- **SUPERSEDED**: Newer issue explicitly covers this scope (apply recency bias)
- **ORPHANED**: Parent Epic/Task closed; work wasn't completed but parent scope is done
- **IRRELEVANT**: Technology decision, project direction, or context change invalidates the issue

## Step 3: Create Assessment Report

Create a structured report of findings:

```markdown
## Issue Staleness Assessment - [DATE]

### Target Column: [STATUS]
**Total Issues Assessed**: N

### Summary by Category
- NO LONGER NEEDED: X issues (Y SUPERSEDED, Z ORPHANED, W IRRELEVANT)
- CONTRADICTING: X issue pairs
- STALE: X issues
- DUPLICATE: X issues
- OVERLAPPING: X issues
- PREMATURE: X issues
- VALID: X issues (Y Ready, Z Appropriate, W Unique)

### Detailed Findings

**Include Summary column** for context without requiring full issue review.

#### NO LONGER NEEDED Issues
| Issue | Title | Summary | Sub-Type | Recommended Action |
|-------|-------|---------|----------|-------------------|
| #N | Title | 1-2 sentence scope/status summary | SUPERSEDED/ORPHANED/IRRELEVANT | Action |

#### STALE Issues
| Issue | Title | Summary | Blocker Status | Recommended Action |
|-------|-------|---------|----------------|-------------------|
| #N | Title | 1-2 sentence scope summary | Was: #X (now CLOSED) | Reassess |

#### CONTRADICTING Issues
| Issue A | Issue B | Contradiction | Recommended Resolution |
|---------|---------|---------------|------------------------|
| #N | #M | [Description of conflict] | [Resolution approach] |

#### OVERLAPPING Issues
| Issue | Title | Summary | Overlaps With | Overlap % | Recommended Action |
|-------|-------|---------|---------------|-----------|-------------------|
| #N | Title | 1-2 sentence scope summary | #M | ~X% | Consolidate/Reconcile |

#### PREMATURE Issues
| Issue | Title | Summary | Why Premature | Recommended Action |
|-------|-------|---------|---------------|-------------------|
| #N | Title | 1-2 sentence scope summary | M3 work / blocked by X | Move to Backlog |

#### VALID Issues (Informational)
| Issue | Title | Summary | Status |
|-------|-------|---------|--------|
| #N | Title | 1-2 sentence scope summary | Ready / Appropriate |

### Reconciliation Plans Needed
1. **#A and #B overlap**: [Description of overlap and proposed resolution]
```

## Step 4: Interactive Decision Workflow

After creating the assessment report, guide the user through decisions category-by-category using this interactive workflow:

### 4.1 Present Summary First

Display the assessment summary showing counts per category:
```
Assessment complete. Found:
- NO LONGER NEEDED: 3 issues (2 SUPERSEDED, 1 ORPHANED)
- CONTRADICTING: 1 issue pair
- STALE: 2 issues
- PREMATURE: 2 issues
- OVERLAPPING: 1 issue pair
- VALID: 5 issues (3 Ready, 2 Unique)
```

### 4.2 Walk Through Each Decision Category

Process categories in this order (actionable decisions first):

**Order**: NO LONGER NEEDED → CONTRADICTING → STALE → PREMATURE → OVERLAPPING → VALID

For each category with issues:

1. **Present the issues** in that category with brief context
2. **Ask for confirmation** using AskUserQuestion with multiselect
3. **Execute approved actions** immediately
4. **Move to next category**

### 4.3 Category-Specific Prompts

**NO LONGER NEEDED** (requires closure approval):
```
Use AskUserQuestion:
- Question: "Which NO LONGER NEEDED issues should be closed?"
- Options: List each issue with sub-type (e.g., "#22 - SUPERSEDED by Epic #42")
- multiSelect: true
- Header: "Close issues"
```

**CONTRADICTING** (requires resolution decision):
```
Use AskUserQuestion:
- Question: "How should we resolve this contradiction between issues?"
- Options per contradiction:
  - "#X approach is correct (update #Y)"
  - "#Y approach is correct (update #X)"
  - "Both valid for different contexts (clarify scope)"
  - "Need more information (add comments to both)"
- multiSelect: false
- Header: "Resolve contradiction"
```

**STALE** (requires reassessment decision):
```
Use AskUserQuestion:
- Question: "How should we handle these STALE issues (blockers resolved)?"
- Options per issue: "Keep in Up Next (ready to work)", "Move to Backlog (needs more context)", "Close (no longer relevant)"
- multiSelect: false (one decision per issue)
- Header: "Stale issues"
```

**PREMATURE** (requires move approval):
```
Use AskUserQuestion:
- Question: "Which PREMATURE issues should be moved to Backlog?"
- Options: List each issue with timing reason
- multiSelect: true
- Header: "Move to Backlog"
```

**OVERLAPPING** (requires reconciliation decision):
```
Use AskUserQuestion:
- Question: "How should we reconcile these overlapping issues?"
- Options: Present reconciliation options (e.g., "Merge #A into #B", "Keep both with clarified scope", "Close #A as duplicate")
- multiSelect: false
- Header: "Reconcile overlap"
```

**VALID** (informational only):
```
Present VALID issues for awareness - no decision needed.
"These issues are appropriately positioned and ready for work: #X, #Y, #Z"
```

### 4.4 Execute and Confirm

After each category's decisions:
1. Execute the approved actions immediately
2. Confirm completion: "Closed #22, #23. Moving to STALE issues..."
3. Continue to next category

## Step 5: Execute Actions

**IMPORTANT**: Execute actions immediately after each category's approval (not batched at end).

For each approved action:

### Close Stale/Superseded/Duplicate Issues

```bash
# Add closure comment explaining rationale
gh issue comment ISSUE_NUMBER --repo pongogo/pongogo --body "Closing as [STALE/SUPERSEDED/DUPLICATE]: [Explanation]

Related: #[RELATED_ISSUE] (if applicable)

Identified during staleness assessment on [DATE]."

# Close the issue
gh issue close ISSUE_NUMBER --repo pongogo/pongogo --reason "not_planned"

# Update project board status to Done
gh project item-edit --project-id PVT_kwDODiLik84BGfkl --id [ITEM_ID] --field-id [STATUS_FIELD_ID] --single-select-option-id [DONE_OPTION_ID]
```

### Move Premature Issues to Backlog

```bash
# Add comment explaining move
gh issue comment ISSUE_NUMBER --repo pongogo/pongogo --body "Moving to Backlog: This issue is valid but premature for current Milestone. Will be addressed in [FUTURE_MILESTONE].

Identified during staleness assessment on [DATE]."

# Update project board status to Backlog
gh project item-edit --project-id PVT_kwDODiLik84BGfkl --id [ITEM_ID] --field-id [STATUS_FIELD_ID] --single-select-option-id 94603997
```

### Execute Reconciliation Plans

For overlapping issues, execute the approved reconciliation:
- Consolidate scope into primary issue
- Update both issue bodies to reflect reconciliation
- Close secondary issue with link to primary

## Step 5: Work Log Entry

After completing the assessment, create a work log entry:

```markdown
### Issue Staleness Assessment - [STATUS] Column

**Category**: `chore`

Conducted comprehensive staleness assessment for [STATUS] column issues.

**Assessment Summary**:
- Total issues assessed: N
- STALE: X (closed)
- SUPERSEDED: X (closed)
- DUPLICATE: X (closed)
- OVERLAPPING: X (reconciled)
- PREMATURE: X (moved to Backlog)
- VALID: X (retained)

**Key Findings**:
- [Notable finding 1]
- [Notable finding 2]

**Actions Taken**:
- Closed issues: #A, #B, #C
- Moved to Backlog: #D, #E
- Reconciled: #F into #G

**Related**: [Task #206](https://github.com/pongogo/pongogo/issues/206)
```

## Knowledge Preservation Checklist

**MANDATORY before closing ANY issue:**

Before closing an issue, answer: **"Where does this knowledge go?"**

| Closure Reason | Knowledge Destination | Action Required |
|---------------|----------------------|-----------------|
| **SUPERSEDED** | Newer issue | Verify scope captured in superseding issue |
| **ORPHANED** | Parent Epic/Task context | Document orphan reason in closure comment |
| **IRRELEVANT** | Decision Archive (if significant) | Capture why context changed |
| **DUPLICATE** | Primary issue | Consolidate any unique details first |
| **COMPLETE** | Work log + relevant docs | Verify completion documented |

**Example closure comment with knowledge preservation**:
```
Closing as SUPERSEDED by #42 (Epic Routing Operationalization).

Knowledge preserved:
- Original scope (template standardization) absorbed into Epic #42 deliverables
- Specific requirements migrated to Epic #42 acceptance criteria on 2025-11-15

Identified during staleness assessment on 2025-11-29.
```

## Scope Verification After Context Loss

**CRITICAL: If session resumes after auto-compact, verify scope BEFORE claiming completion.**

### Verification Checklist

After context loss (auto-compact, session break), MUST complete before any completion claim:

1. **Read tracking file**: `cat tmp/triage_findings_*.md`
2. **Verify scope**: "How many issues was I triaging? Have I addressed ALL of them?"
3. **Check progress table**: Confirm all issue rows have classification
4. **Explicit count validation**: "Processed X of Y issues" matches expectation
5. **No completion claim** until verification passes

### Anti-Pattern

❌ **WRONG**: "I think I'm done with triage" (based on memory after context loss)
✅ **CORRECT**: "According to tracking file, I've processed 45/45 issues. Verification complete."

**Recovery pattern**: If tracking file shows incomplete progress, resume from last recorded position—do NOT restart.

## Delta Tracking

**Track changes vs prior triage (not just absolute counts).**

### Purpose

Delta tracking reveals backlog management health over time:
- **Large delta** after first triage: Expected (baseline establishment)
- **Small delta** after re-triage: Expected (validates prior work)
- **Large delta** after re-triage: Concerning (process gap or major project shift)

### Delta Metrics

In assessment report and work log, include:

| Metric | Count | Prior Triage | Delta |
|--------|-------|--------------|-------|
| Issues Closed | X | Y | +/- Z |
| Moved to Icebox | X | Y | +/- Z |
| Moved to Backlog | X | Y | +/- Z |
| Confirmed Valid | X | Y | +/- Z |

### Interpretation Guide

- **Minimal delta after prior triage**: ✅ Validation signal (prior work was effective)
- **High close rate on first triage**: ✅ Expected (clearing accumulated staleness)
- **High close rate on re-triage**: ⚠️ Investigate (why did so many become stale so quickly?)

## Audit Trail Archival

**MANDATORY: Archive findings to wiki after triage completion.**

### Archive Location

```
wiki/Audit-Triage-YYYY-MM-DD.md
```

### Archive Contents

1. **Summary**: Issue counts, classifications, key patterns
2. **Cluster Analysis**: What clusters were identified, relationships found
3. **Delta Tracking**: Changes vs prior triage (if applicable)
4. **Lessons Learned**: Process observations, improvement ideas
5. **Methodology Used**: Rigor level, any deviations from standard process

### Archive Template

```markdown
# Triage Audit: YYYY-MM-DD

**Rigor Level**: [Quick Scan / Standard / Comprehensive]
**Scope**: [Columns assessed]
**Prior Triage**: [Date or "First triage"]

## Summary

- Total issues assessed: N
- Closed: X (breakdown by reason)
- Moved to Icebox: X
- Moved to Backlog: X
- Confirmed Valid: X

## Delta vs Prior Triage

[Delta tracking table]

## Clusters Identified

[Cluster list with descriptions]

## Key Findings

[Notable patterns, relationships, concerns]

## Lessons Learned

[Process observations, improvement ideas]

---

*Archived from `tmp/triage_findings_YYYY-MM-DD.md` after completion.*
```

### Commit Pattern

```bash
# Copy to wiki
cp tmp/triage_findings_*.md wiki/Audit-Triage-$(date +%Y-%m-%d).md

# Edit to archive format (trim working notes, add summary)
# ... edit wiki/Audit-Triage-*.md ...

# Commit wiki
cd wiki && git add . && git commit -m "Add triage audit: YYYY-MM-DD" && git push && cd ..

# Update main repo submodule
git add wiki && git commit -m "Update wiki submodule: Add triage audit" && git push
```

## Project Board Field Reference

Current field IDs (refresh if errors occur):

```bash
# Get fresh field IDs
gh project field-list 1 --owner pongogo --format json | jq '.fields[] | {name, id}'
```

**Known IDs** (verified 2026-02-03):
- Project ID: `PVT_kwDODiLik84BGfkl`
- Status Field ID: `PVTSSF_lADODiLik84BGfklzg3hdDI`
- Status Options:
  - Icebox: `be5e16a1`
  - Backlog: `94603997`
  - Up Next: `f75ad846`
  - In Progress: `47fc9ee4`
  - On Hold: `0e8fe7c1`
  - Ready for Review: `591668bf`
  - Done: `98236657`

## Common Patterns

### Staleness After Epic Completion

When an Epic closes, check for:
1. **Orphaned sub-tasks**: Sub-issues that weren't completed but parent closed
2. **Unblocked dependents**: Issues that were waiting on the Epic
3. **Superseded scope**: Issues whose work was absorbed into Epic

### Milestone Boundary Assessment

At Milestone boundaries:
1. All issues tagged for completing Milestone should be Done
2. Issues for next Milestone should be in Backlog or Up Next
3. No issues should reference the completed Milestone as a blocker

## Frequency

Run this assessment:
- After completing any Epic
- At Milestone boundaries
- When project board feels cluttered
- Before starting major new work
- Monthly as hygiene practice

## Future Enhancement: Always-On Agent

This process is designed to become an always-running agent that:
1. Monitors for Epic/Milestone completions
2. Automatically identifies potentially stale issues
3. Proposes reconciliation plans
4. Maintains project board hygiene continuously

Until that agent exists, run this command manually at the triggers listed above.
