# Pongogo Reindex Command

Manually trigger knowledge base reindex for the Pongogo Knowledge MCP server.

## Prerequisites

**Container must be running BEFORE starting Claude Code session.**

MCP tools are discovered once at session start. Starting the container mid-session enables routing via hooks but MCP tools remain unavailable.

**Before executing, verify Pongogo MCP tools are available:**
- If you see `mcp__pongogo-knowledge__*` tools in your available tools → Proceed
- If NOT → Container wasn't running at session start. Inform user:
  ```
  ⚠️ MCP tools not available - container wasn't running when session started.

  To fix:
  1. Run: docker-compose up -d knowledge-hub
  2. Restart your Claude Code session

  Note: The reindex already happened when the container started (check logs with:
  docker logs knowledge-hub --tail 20)
  ```

## What This Does

Calls the `reindex_knowledge_base()` MCP tool to reload all instruction files from disk.

Use cases:
- After bulk file updates (multiple instruction files created/modified)
- Testing new instruction files immediately without waiting for file watcher
- Forcing a fresh index if something seems stale

## Spam Prevention

The reindex tool has built-in spam prevention:
- **Minimum interval**: 10 seconds between manual reindexes
- **Auto-skip**: If called too frequently, will return skip message with wait time
- **Bypass**: Use `force=true` parameter to override spam prevention (for testing)

## How to Use

**Standard reindex** (with spam prevention):
```
Use the GitHub MCP tool mcp__pongogo-knowledge__reindex_knowledge_base to trigger a manual reindex of instruction files.
```

**Force reindex** (bypass spam prevention):
```
Use the GitHub MCP tool mcp__pongogo-knowledge__reindex_knowledge_base with force=true to trigger an immediate reindex bypassing spam prevention.
```

## Expected Output

Success response:
```json
{
  "success": true,
  "old_count": 54,
  "new_count": 58,
  "elapsed_ms": 125.3,
  "timestamp": "2025-11-15T15:45:00"
}
```

Spam prevention skip:
```json
{
  "success": false,
  "skipped": true,
  "reason": "spam_prevention",
  "wait_seconds": 7.2,
  "hint": "Wait 7.2s or use force=true to bypass"
}
```

## Automatic Reindexing

**You usually don't need this command!** The knowledge MCP server has automatic reindexing:

1. **File Watcher** (Primary): Detects file changes and auto-reindexes
   - 3-second debouncing for batch changes
   - Watches `knowledge/instructions/pongogo/**/*.instructions.md`

2. **Health Check** (Reliability): Every 5 minutes compares disk vs cache
   - Auto-triggers reindex if mismatch detected
   - Ensures consistency even if file watcher misses events

**Use this command when**:
- Testing new instruction files immediately
- File watcher isn't running (server not started)
- You want immediate feedback (don't want to wait for debouncing)

## Implementation

This command expansion will be detected by the Pongogo knowledge routing system, which will surface the `reindex_knowledge_base()` MCP tool for Claude to invoke.

**Created**: 2025-11-15 (Task #123)
**Version**: 1.0
**Related**: `pongogo-knowledge-server/server.py` - MCP tool implementation
