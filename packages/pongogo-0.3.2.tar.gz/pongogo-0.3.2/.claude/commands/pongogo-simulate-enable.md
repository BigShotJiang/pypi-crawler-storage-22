---
description: Enable simulate mode (persistent testing with full routing visibility)
---

# Enable Pongogo Simulate Mode

Enable Pongogo simulate mode for persistent testing with routing active but knowledge system writes disabled (read-only).

## Your Task

Execute the following steps to enable Pongogo simulate mode:

### 1. Parse Command Parameters

Check if the user provided a `log_comment` parameter in their command invocation.

**Valid values**: `testing`, `learning`, or empty/unset

**Example invocations**:
- `/pongogo-simulate-enable` → Standard simulate logging
- `/pongogo-simulate-enable log_comment=testing` → Testing logs (isolated directory)
- `/pongogo-simulate-enable log_comment=learning` → Learning logs (isolated directory)

### 2. Check Current State

Read the state file to check current mode:

```bash
if [ -f .pongogo-mcp-state.json ]; then
  cat .pongogo-mcp-state.json
fi
```

**If state shows `"mode": "simulate"`**:
- Display: "⚠️ Pongogo simulate mode already active"
- Stop execution

### 3. Verify MCP Server Running

Check if the knowledge-hub Docker container is running:

```bash
docker-compose ps knowledge-hub
```

**If container not running**:
- Display: "❌ MCP server not responding - check Docker: `docker-compose ps`"
- Suggest: "Run `docker-compose up -d knowledge-hub` to start the server"
- Stop execution

### 4. Update State File

Use the toggle script to update state atomically:

```bash
# Standard simulate (no log_comment)
python3 scripts/toggle_pongogo_mode.py --mode simulate

# With log_comment (testing or learning)
python3 scripts/toggle_pongogo_mode.py --mode simulate --log-comment testing
python3 scripts/toggle_pongogo_mode.py --mode simulate --log-comment learning
```

### 5. Display Success Message

Show confirmation message:

```
✅ Pongogo simulate mode enabled

🧪 SIMULATE MODE (Read-Only Testing):
- Routing engine ACTIVE (full production logic)
- Context injection ACTIVE (see what Pongogo recommends)
- Structured logging ACTIVE (observability with "mode": "simulate")
- Cache updates ACTIVE (performance testing)
- Knowledge system writes DISABLED (read-only, no changes)

Use simulate mode for:
- Testing routing without modifying knowledge base
- Validating Pongogo recommendations before production
- A/B testing with full visibility into routing results
- Debugging routing issues with complete observability

To return to production: /pongogo-simulate-disable
To disable completely: /pongogo-disable
```

**If log_comment is 'testing'**:
```
✅ Pongogo simulate mode enabled (TESTING LOGS)

🧪 SIMULATE MODE (Read-Only Testing):
- Routing engine ACTIVE (full production logic)
- Context injection ACTIVE (see what Pongogo recommends)
- Structured logging ACTIVE (observability with "mode": "simulate")
- Cache updates ACTIVE (performance testing)
- Knowledge system writes DISABLED (read-only, no changes)

📁 Log Isolation:
- Logs: logs/logs-testing/
- Database: .pongogo/pongogo-test.db

To return to production: /pongogo-simulate-disable
```

## Three-State Model

Pongogo uses a three-state model:

| Mode | Routing | Logging | Knowledge Writes |
|------|---------|---------|------------------|
| **enabled** | ✓ | ✓ | ✓ (read-write) |
| **disabled** | ✗ | ✗ | ✗ (baseline) |
| **simulate** | ✓ | ✓ | ✗ (read-only) |

**State Transitions**:
```
Production (enabled) ─┬─ /pongogo-disable ────────→ Baseline (disabled)
                      └─ /pongogo-simulate-enable → Testing (simulate)

Testing (simulate) ────/pongogo-simulate-disable ─→ Production (enabled)

Baseline (disabled) ───/pongogo-enable ───────────→ Production (enabled)
                    ───/pongogo-simulate-enable ──→ Testing (simulate)
```

## Important Notes

- **Read-Only Protection**: Simulate mode prevents accidental knowledge base modifications during testing
- **Full Observability**: All routing events logged with "mode": "simulate" marker
- **Returns to Production**: /pongogo-simulate-disable returns to enabled (not disabled)
- **Distinct from dry-run**: dry-run is one-off with no logging; simulate is persistent with full logging

## Success Criteria

- State file updated with `"mode": "simulate"`
- MCP server confirmed running and responding
- User sees clear success message with simulate mode guidance
- Read-only protection active for knowledge system
