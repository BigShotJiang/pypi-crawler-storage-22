---
description: Switch routing engine version or list available engines
---

# Pongogo Switch Routing Engine

Switch between different routing engine versions for A/B testing and development.

## Your Task

Execute the appropriate action based on user input:

### If No Engine Version Specified (Interactive Menu Mode)

**Step 1:** Call the MCP tool to get available engines:

```
mcp__pongogo-knowledge__switch_engine()
```

**Step 2:** Present an interactive menu using AskUserQuestion tool:

Use the AskUserQuestion tool to present the available engines as selectable options:

- **Question**: "Which routing engine would you like to use?"
- **Header**: "Engine"
- **Options**: Build from the available_engines list returned by the MCP tool
  - Each option label: engine version (e.g., "durian-0.5")
  - Each option description: Include current status and feature count
    - Example: "Current engine - 6 features enabled"
    - Example: "Baseline engine - no configurable features"

Example AskUserQuestion call:
```python
AskUserQuestion(questions=[{
    "question": "Which routing engine would you like to use?",
    "header": "Engine",
    "multiSelect": False,
    "options": [
        {"label": "durian-0.5", "description": "Current stable - 6 features (violation_detection, approval_suppression, ...)"},
        {"label": "durian-00-frozen", "description": "Baseline engine for A/B comparison"}
    ]
}])
```

**Step 3:** If user selects an engine (not "Other"), switch to it using:
```
mcp__pongogo-knowledge__switch_engine(engine_version="[selected-version]")
```

**Step 4:** Verify the switch with a test routing call:

```
mcp__pongogo-knowledge__route_instructions(message="verification test", limit=1)
```

Check that the response includes `routing_engine_version` matching the newly switched engine.

**Step 5:** Display the switch result with verification status (see "Display the results" section below).

### If Engine Version Specified (Direct Switch Mode)

**Step 1:** Switch directly:

```
mcp__pongogo-knowledge__switch_engine(engine_version="[specified-version]")
```

**Step 2:** Verify with test routing call:

```
mcp__pongogo-knowledge__route_instructions(message="verification test", limit=1)
```

**Step 3:** Display results with verification status.

### Display the Results

**On Success:**
```
✅ Engine Switched Successfully

Previous: [old-version]
Current:  [new-version]

Description: [engine description]

Active Features:
- violation_detection: ✅ enabled
- approval_suppression: ✅ enabled
- foundational: ✅ enabled

Verification: routing_engine_version = [version] ✅
```

**On Success with Verification Mismatch:**
```
⚠️ Engine Switched but Verification Failed

Previous: [old-version]
Current:  [new-version]

Verification: Expected [new-version] but routing returned [actual-version]

This may indicate:
- Adapter not reading router.version dynamically
- Container needs rebuild
- Configuration mismatch
```

**If Already Using Requested Engine:**
```
ℹ️ Already using engine: [version]

No change needed.
```

**On Error (Unknown Engine):**
```
❌ Unknown engine: [requested-version]

Available engines:
- durian-0.5
- durian-00-frozen

Usage: /pongogo-switch-engine [engine-version]
```

## Use Cases

### A/B Testing
Compare routing quality between engine versions:
1. `/pongogo-switch-engine durian-00-frozen` - Baseline
2. Test routing with baseline
3. `/pongogo-switch-engine durian-0.5` - Stable
4. Test routing with development version
5. Compare results

### Development
Test new engine features in isolation:
1. `/pongogo-switch-engine` - See available engines
2. `/pongogo-switch-engine [new-version]` - Switch to test
3. Validate routing behavior
4. Switch back if needed

### Debugging
Isolate routing issues:
1. Note current behavior
2. `/pongogo-switch-engine durian-00-frozen` - Use baseline
3. If issue persists → problem is not engine-specific
4. If issue resolves → problem is in newer engine features

## Arguments

This command accepts an optional engine version argument:

- **No argument**: Opens interactive menu to select an engine
- **With argument**: Switch directly to the specified engine version

Examples:
- `/pongogo-switch-engine` - Interactive menu to choose engine
- `/pongogo-switch-engine durian-0.5` - Switch directly to stable engine
- `/pongogo-switch-engine durian-00-frozen` - Switch directly to frozen baseline

## Error Handling

**MCP Server Not Running:**
```
❌ Cannot switch engine - MCP server not responding

Check server status: /pongogo-status
Start server: docker-compose up -d knowledge-hub
```

**Invalid Engine Version:**
```
❌ Unknown engine: [version]

Use /pongogo-switch-engine (no arguments) to see available engines.
```

## Success Criteria

- Clear display of available engines when listing
- Confirmation message when switching
- Show old and new engine versions on switch
- Display active features for current engine
- **Verification step confirms routing returns correct version** (Task #270)
- Actionable error messages if issues occur
